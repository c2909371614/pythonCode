!function e(t,n,a){function i(r,o){if(!n[r]){if(!t[r]){var s="function"==typeof require&&require
if(!o&&s)return s(r,!0)
if(c)return c(r,!0)
var l=new Error("Cannot find module '"+r+"'")
throw l.code="MODULE_NOT_FOUND",l}var u=n[r]={exports:{}}
t[r][0].call(u.exports,(function(e){return i(t[r][1][e]||e)}),u,u.exports,e,t,n,a)}return n[r].exports}for(var c="function"==typeof require&&require,r=0;r<a.length;r++)i(a[r])
return i}({1:[function(e,t,n){"use strict"
window._settingsJson={CocosEngine:"3.6.3",engine:{debug:!1,platform:"wechatgame",customLayers:[{name:"WATER_TILE",bit:0}],macros:{ENABLE_MULTI_TOUCH:!1,ENABLE_TILEDMAP_CULLING:!1,
CLEANUP_IMAGE_CACHE:!0,MAX_LABEL_CANVAS_POOL_SIZE:0},
builtinAssets:["60f7195c-ec2a-45eb-ba94-8955f60e81d0","1c02ae6f-4492-4915-b8f8-7492a3b1e4cd","810e96e4-e456-4468-9b59-f4e8f39732c0","efe8e2a3-eace-427b-b4f1-cb8a937ec77d","e9aa9a3e-5b2b-4ac7-a2c7-073de2b2b24f","8bbdbcdd-5cd4-4100-b6d5-b7c9625b6107","50f4348b-c883-4e2f-8f11-ce233b859fa1","fda095cb-831d-4601-ad94-846013963de8","f92806d7-1768-443f-afe8-12bcde84d0f0","dd3a144d-ab7f-41f0-82b8-2e43a090d496","f0416e68-0200-4b77-a926-4f9d16e494da","ff9be190-20a4-4e48-b68c-76e3c7cff085","970b0598-bcb0-4714-91fb-2e81440dccd8","bcd64cc6-2dd9-43f6-abbe-66318d332032","d930590d-bb92-4cc8-8bd1-23cd027f9edf","a3cd009f-0ab0-420d-9278-b9fdab939bbc","9361fd90-ba52-4f84-aa93-6e878fd576ca","871c3b6c-7379-419d-bda3-794b239ab90d"]
},animation:{customJointTextureLayouts:[]},assets:{server:"https://res.gmryxyx.elk20.com/gmryxyx_res_andiod_trunk/",remoteBundles:["launch","preload","wealth"],subpackages:[],
preloadBundles:[{bundle:"main"}],bundleVers:{internal:["a1532"],launch:["6e43e"],main:["5c746","mini_5c746"],preload:["0976a"],wealth:["329fe"]},preloadAssets:[],
projectBundles:["internal","launch","main","preload","wealth"]},plugins:{jsList:[]},scripting:{scriptPackages:[]},launch:{launchScene:"db://assets/Main.scene"},screen:{
exactFitScreen:!0,designResolution:{width:1280,height:720,policy:3}},physics:{physicsEngine:"",gravity:{x:0,y:-10,z:0},allowSleep:!0,sleepThreshold:.1,autoSimulation:!0,
fixedTimeStep:.0166667,maxSubSteps:1,defaultMaterial:{friction:.5,rollingFriction:.1,spinningFriction:.1,restitution:.1}},rendering:{renderPipeline:""},splashScreen:{
displayRatio:0,totalTime:0,effect:"",clearColor:{x:.88,y:.88,z:.88,w:1},displayWatermark:!1,
base64src:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQImWNgYGD4DwABBAEAfbLI3wAAAABJRU5ErkJggg=="},IpConfig:{
remoteCDN:"https://res.gmryxyx.elk20.com/",remoteCDNBranch:"gmryxyx_res_andiod_trunk",remoteWebresRoot:"./remote/webres",isLocMode:!1,localServerList:"",
__cacheDir__:"D:\\MULite_Cache",randomVersion:"20230426_005537",subpackages:{paths:{base_rYJNbq:"src/subpackages/base_e26f9e873e55b70a20d2202b211edcad.js",
"global-chunk_feEF7n":"src/subpackages/global-chunk_91e60b28c3944a24a486726e3e8b5b39.js","global-chunk_bU7b6n":"src/subpackages/global-chunk_59cb8362f720220ae11d4012e8372ed8.js",
"global-chunk_JzMNri":"src/subpackages/global-chunk_5f005c51e1167988a5568b9251002e14.js","global-chunk_aMf2ae":"src/subpackages/global-chunk_dcf7b31c0e796f0340c80c0c3b6b545a.js",
"global-chunk_Qnamye":"src/subpackages/global-chunk_0900d55c86c932d1a1cc3367dd13142c.js","global-chunk_Anaiiu":"src/subpackages/global-chunk_58eecb2a041c48eecfac5e0fc72580ca.js",
"global-chunk_IrQjIf":"src/subpackages/global-chunk_2642bb638ea7e4ca306e512335629cea.js","global-chunk_2yAbyy":"src/subpackages/global-chunk_90244e3daac27ff3ffb162f51ca2eba8.js",
"global-chunk_m6Rrqy":"src/subpackages/global-chunk_ddff8eec87289bbd14d761de89d6af23.js","global-chunk_bmiE7b":"src/subpackages/global-chunk_3a50b7363dab4e5bd2a03a7aae4d07a9.js",
"global-chunk_EbaEnq":"src/subpackages/global-chunk_11872b7a3760c73fe8d35286e59b3e20.js","global-chunk_2meyiu":"src/subpackages/global-chunk_f3d6059ae01b96f812bb30b01199849a.js",
global_ZneIfi:"src/subpackages/global_20176c50569a7508001f9a3db0c7142e.js",md5:"src/subpackages/md5_4a0c0a7a0a69a7cdda928d51c4b955e2.js",
zlib:"src/subpackages/zlib_f0e4e9d49301954f16087a229228aa91.js",preload:"bundle",wealth:"bundle"},preload:[["base_rYJNbq","zlib","preload"]],
logic:[["global-chunk_feEF7n","global-chunk_bU7b6n","global-chunk_JzMNri","global-chunk_aMf2ae","global-chunk_Qnamye","global-chunk_Anaiiu","global-chunk_IrQjIf","global-chunk_2yAbyy","global-chunk_m6Rrqy","global-chunk_bmiE7b","global-chunk_EbaEnq","global-chunk_2meyiu","wealth"],["global_ZneIfi"]]
}}}
var a={main:{importBase:"import",nativeBase:"native",name:"main",deps:[],
uuids:["0dfe84ab7","a0RCsyOqRPZZemzq5be5pE","d706Qm29hBXbZQKoBZc9nG","fdcrP1F05P4KasQBUaiQSW","fdjsU2o1RKF5x0TziDw3jI"],paths:{
4:["db:/internal/default_renderpipeline/builtin-forward",0]},scenes:{"db://assets/Main.scene":1},packs:{"0dfe84ab7":["1","2","3"]},versions:{import:[],native:[]},redirect:[],
debug:!1,extensionMap:{},isZip:!0,zipVersion:"19a62",types:["cc.RenderPipeline"]},internal:{importBase:"import",nativeBase:"native",name:"internal",deps:[],
uuids:["068f0ae49","0ba503733","0dfe1b9d0","0e7a008af","1cAq5vRJJJFbj4dJKjseTN","609xlc7CpF67qUiVX2DoHQ","81Dpbk5FZEaJtZ9OjzlzLA","8bvbzdXNRBALbVt8liW2EH","a3zQCfCrBCDZJ4uf2rk5u8","bc1kzGLdlD9qu+ZjGNMyAy","ef6OKj6s5Ce7Txy4qTfsd9","f0QW5oAgBLd6kmT50W5JTa","509DSLyINOL48RziM7hZ+h","87HDtsc3lBnb2jeUsjmrkN","93Yf2QulJPhKqTboeP1XbK","97CwWYvLBHFJH7LoFEDczY","d9MFkNu5JMyIvRI80Cf57f","ddOhRNq39B8IK4LkOgkNSW","e9qpo+WytKx6LHBz3isrJP","f9KAbXF2hEP6/oErzehNDw","fdoJXLgx1GAa2UhGATlj3o","ffm+GQIKROSLaMduPHz/CF"],
paths:{4:["db:/internal/effects/builtin-graphics",0],5:["db:/internal/effects/builtin-sprite",0],6:["db:/internal/effects/builtin-clear-stencil",0],
7:["db:/internal/default_materials/default-clear-stencil",1],8:["db:/internal/effects/builtin-unlit",0],9:["db:/internal/default_materials/missing-effect-material",1],
10:["db:/internal/default_materials/ui-sprite-gray-material",1],11:["db:/internal/default_materials/ui-graphics-material",1],
12:["db:/internal/default_materials/ui-alpha-test-material",1],13:["db:/internal/effects/util/profiler",0],14:["db:/internal/effects/pipeline/planar-shadow",0],
15:["db:/internal/effects/util/splash-screen",0],16:["db:/internal/default_materials/missing-material",1],17:["db:/internal/default_materials/ui-sprite-gray-alpha-sep-material",1],
18:["db:/internal/default_materials/ui-base-material",1],19:["db:/internal/default_materials/ui-sprite-alpha-sep-material",1],
20:["db:/internal/default_materials/ui-sprite-material",1],21:["db:/internal/effects/builtin-debug-renderer",0]},scenes:{},packs:{"068f0ae49":["5","10"],"0ba503733":["8","9"],
"0dfe1b9d0":["6","7"],"0e7a008af":["4","11"]},versions:{import:[],native:[]},redirect:[],debug:!1,extensionMap:{},isZip:!0,zipVersion:"4a921",types:["cc.EffectAsset","cc.Material"]
}
},i=e("./cache-manager"),c=window.fsUtils,r=c.fs,o=c.downloadFile,s=c.readText,l=c.readArrayBuffer,u=c.readJson,d=c.loadSubpackage,f=c.getUserDataPath,h=c.exists,b=/^https?:\/\/.*/,p=cc.assetManager.downloader,m=cc.assetManager.parser,g=cc.assetManager.presets
p.maxConcurrency=8,p.maxRequestsPerFrame=64,g.scene.maxConcurrency=10,g.scene.maxRequestsPerFrame=64
var _={},y=cc.sys
function v(t,n,a){b.test(t)?a&&a(new Error("Can not load remote scripts")):(y.platform!==y.Platform.TAOBAO_CREATIVE_APP&&e("../../../"+t),a&&a(null))}function w(e,t,n){
cc.AudioPlayer.load(e).then((function(t){var a={player:t,url:e,duration:t.duration,type:t.type}
n(null,a)})).catch((function(e){n(e)}))}function k(e,t,n,a,c){var r=function(e,t){var n=!1,a=!1
if(e.startsWith(f()))n=!0
else if(b.test(e)){if(!t.reload){var c=i.cachedFiles.get(e)
if(c)a=!0,e=c.url
else{var r=i.tempFiles.get(e)
r&&(n=!0,e=r)}}}else n=!0
return{url:e,inLocal:n,inCache:a}}(e,n)
r.inLocal?t(r.url,n,c):r.inCache?(i.updateLastTime(e),t(r.url,n,(function(t,n){t&&i.removeCache(e),c(t,n)}))):o(e,null,n.header,a,(function(a,r){a?c(a,null):t(r,n,(function(t,a){
t||(i.tempFiles.add(e,r),i.cacheFile(e,r,n.cacheEnabled,n.__cacheBundleRoot__,!0)),c(t,a)}))}))}function E(e,t,n){l(e,n)}function A(e,t,n){s(e,n)}function F(e,t,n){u(e,n)}
function x(e,t,n){k(e,F,t,t.onFileProgress,n)}function P(e,t,n){k(e,E,t,t.onFileProgress,n)}function C(e,t,n){n(null,__globalAdapter.loadFont(e)||"Arial")}function T(e,t,n){
h(e,(function(t){t?n(null,e):n(new Error("file ".concat(e," does not exist!")))}))}function S(e,t,n){k(e,T,t,t.onFileProgress,n)}
y.platform===y.Platform.BAIDU_MINI_GAME&&(e=__baiduRequire)
function M(e){var t,n
System.register(`chunks:///${e}.js`,[],(function(){return{execute:function(){}}})),t=`virtual:///prerequisite-imports/${e}`,n=`chunks:///${e}.js`,
System.register(t,[n],(function(e,t){return{setters:[function(t){var n={}
for(var a in t)"default"!==a&&"__esModule"!==a&&(n[a]=t[a])
e(n)}],execute:function(){}}}))}var D=m.parsePVRTex,B=function(e,t,n){l(e,(function(e,a){if(e)return n(e)
D(a,t,n)}))},I=m.parsePKMTex,O=function(e,t,n){l(e,(function(e,a){if(e)return n(e)
I(a,t,n)}))},j=m.parseASTCTex,L=function(e,t,n){l(e,(function(e,a){if(e)return n(e)
j(a,t,n)}))},R=m.parsePlist,K=function(e,t,n){s(e,(function(e,a){if(e)return n(e)
R(a,t,n)}))}
p.downloadScript=v,m.parsePVRTex=B,m.parsePKMTex=O,m.parseASTCTex=L,m.parsePlist=K,p.register({".js":v,".mp3":S,".ogg":S,".wav":S,".m4a":S,".png":S,".jpg":S,".bmp":S,".jpeg":S,
".gif":S,".ico":S,".tiff":S,".image":S,".webp":S,".pvr":S,".pkm":S,".astc":S,".font":S,".eot":S,".ttf":S,".woff":S,".svg":S,".ttc":S,".ccon":function(e,t,n){x(e,t,(function(t,a){
if(t)n(t)
else{var i=cc.internal.parseCCONJson(a)
Promise.all(i.chunks.map((function(t){return new Promise((function(n,a){P("".concat(cc.path.mainFileName(e)).concat(t),{},(function(e,t){e?a(e):n(new Uint8Array(t))}))}))
}))).then((function(e){var t=new cc.internal.CCON(i.document,e)
n(null,t)})).catch((function(e){n(e)}))}}))},".cconb":function(e,t,n){P(e,t,(function(e,t){if(e)n(e)
else try{var a=cc.internal.decodeCCONBinary(new Uint8Array(t))
n(null,a)}catch(e){n(e)}}))},".txt":S,".xml":S,".vsh":S,".fsh":S,".atlas":S,".tmx":S,".tsx":S,".plist":S,".fnt":S,".json":x,".ExportJson":S,".binary":S,".bin":S,".dbbin":S,
".skel":S,".mp4":S,".avi":S,".mov":S,".mpg":S,".mpeg":S,".rm":S,".rmvb":S,bundle:function(t,n,c){var s=cc.path.basename(t),l=n.version||cc.assetManager.downloader.bundleVers[s]
let u,h
l&&(Array.isArray(l)?(u=l[0],h=l[1]):(u=l,h=l))
let m=u?u+".":"",g=!1
h&&("mini"==h?(g=!0,h=""):0==h.indexOf("mini_")&&(g=!0,h=h.slice(5)))
let v=h?h+".":"",w=a[s]
if(w&&"object"!=typeof w&&(w=null),_[s]&&!g){var k="subpackages/".concat(s,"/config.").concat(m,"json")
h?d(s,n.onFileProgress,(function(e){e?c(e,null):w?(w.base="subpackages/".concat(s,"/"),c(null,w)):x(k,n,(function(e,t){t&&(t.base="subpackages/".concat(s,"/")),c(e,t)}))})):(M(s),
w?(w.base="subpackages/".concat(s,"/"),c(null,w)):x(k,n,(function(e,t){t&&(t.base="subpackages/".concat(s,"/")),c(e,t)})))}else{var E,A
g?(A="assets/".concat(s),E="src/bundle-scripts/".concat(s,"/index.").concat(v,"js"),i.makeBundleFolder(s)):b.test(t)||t.startsWith(f())?(A=t,
E="src/bundle-scripts/".concat(s,"/index.").concat(v,"js"),i.makeBundleFolder(s)):-1!==p.remoteBundles.indexOf(s)?(A="".concat(p.remoteServerAddress,"remote/").concat(s),
E="src/bundle-scripts/".concat(s,"/index.").concat(v,"js"),i.makeBundleFolder(s)):(A="assets/".concat(s),E="assets/".concat(s,"/index.").concat(v,"js")),
y.platform!==y.Platform.TAOBAO_CREATIVE_APP&&(h?e("./"+E):M(s)),n.__cacheBundleRoot__=s
k="".concat(A,"/config.").concat(m,"json")
var F=function(e,t){if(e)c&&c(e)
else if(t.isZip){var a=t.zipVersion
!function(e,t,n){var a=i.cachedFiles.get(e)
a?(i.updateLastTime(e),n&&n(null,a.url)):b.test(e)?o(e,null,t.header,t.onFileProgress,(function(a,c){a?n&&n(a):i.unzipAndCacheBundle(e,c,t.__cacheBundleRoot__,n)
})):i.unzipAndCacheBundle(e,e,t.__cacheBundleRoot__,n)}("".concat(A,"/res.").concat(a?a+".":"","zip"),n,(function(e,n){if(e)c&&c(e)
else{if(t.base=n+"/res/",y.platform===y.Platform.ALIPAY_MINI_GAME&&y.os===y.OS.ANDROID){var a=n+"res/"
r.accessSync({path:a})&&(t.base=a)}c&&c(null,t)}}))}else t.base=A+"/",c&&c(null,t)}
w?F(null,w):x(k,n,F)}},default:function(e,t,n){k(e,A,t,t.onFileProgress,n)}}),m.register({".png":p.downloadDomImage,".jpg":p.downloadDomImage,".bmp":p.downloadDomImage,
".jpeg":p.downloadDomImage,".gif":p.downloadDomImage,".ico":p.downloadDomImage,".tiff":p.downloadDomImage,".image":p.downloadDomImage,".webp":p.downloadDomImage,".pvr":B,".pkm":O,
".astc":L,".font":C,".eot":C,".ttf":C,".woff":C,".svg":C,".ttc":C,".mp3":w,".ogg":w,".wav":w,".m4a":w,".txt":A,".xml":A,".vsh":A,".fsh":A,".atlas":A,".tmx":A,".tsx":A,".fnt":A,
".plist":K,".binary":E,".bin":E,".dbbin":E,".skel":E,".ExportJson":F}),cc.assetManager.transformPipeline.append((function(e){for(var t=e.output=e.input,n=0,a=t.length;n<a;n++){
var i=t[n],c=i.options
if(i.config)c.__cacheBundleRoot__=i.config.name
else{if("bundle"===i.ext)continue
c.cacheEnabled=void 0!==c.cacheEnabled&&c.cacheEnabled}".cconb"===i.ext?i.url=i.url.replace(i.ext,".bin"):".ccon"===i.ext&&(i.url=i.url.replace(i.ext,".json"))}}))
var U=cc.assetManager.init
cc.assetManager.init=function(e){U.call(cc.assetManager,e)
var t=cc.settings.querySettings("assets","subpackages")
t&&t.forEach((function(e){return _[e]="subpackages/"+e})),i.init()}},{"./cache-manager":3}],2:[function(e,t,n){"use strict"
!function(){if(cc&&cc.internal&&cc.internal.EditBox){var e=cc.internal.EditBox,t=cc.js,n=e.KeyboardReturnType,a=null,i=null
t.extend(r,e._EditBoxImpl),e._EditBoxImpl=r,Object.assign(r.prototype,{init:function(e){e?this._delegate=e:cc.error("EditBox init failed")},beginEditing:function(){var e=this
this._editing||this._ensureKeyboardHide((function(){var t=e._delegate
e._showKeyboard(),e._registerKeyboardEvent(),e._editing=!0,i=e,t._editBoxEditingDidBegan()}))},endEditing:function(){this._hideKeyboard()
var e=this._eventListeners
e.onKeyboardComplete&&e.onKeyboardComplete()},_registerKeyboardEvent:function(){var e=this,t=this._delegate,n=this._eventListeners
n.onKeyboardInput=function(e){t._string!==e.value&&t._editBoxTextChanged(e.value)},n.onKeyboardConfirm=function(n){t._editBoxEditingReturn()
var a=e._eventListeners
a.onKeyboardComplete&&a.onKeyboardComplete()},n.onKeyboardComplete=function(){e._editing=!1,i=null,e._unregisterKeyboardEvent(),t._editBoxEditingDidEnded()},
__globalAdapter.onKeyboardInput(n.onKeyboardInput),__globalAdapter.onKeyboardConfirm(n.onKeyboardConfirm),__globalAdapter.onKeyboardComplete(n.onKeyboardComplete)},
_unregisterKeyboardEvent:function(){var e=this._eventListeners
e.onKeyboardInput&&(__globalAdapter.offKeyboardInput(e.onKeyboardInput),e.onKeyboardInput=null),e.onKeyboardConfirm&&(__globalAdapter.offKeyboardConfirm(e.onKeyboardConfirm),
e.onKeyboardConfirm=null),e.onKeyboardComplete&&(__globalAdapter.offKeyboardComplete(e.onKeyboardComplete),e.onKeyboardComplete=null)},_otherEditing:function(){
return!!i&&i!==this&&i._editing},_ensureKeyboardHide:function(e){var t=this._otherEditing()
if(!t&&!a)return e()
a&&clearTimeout(a),t&&i.endEditing(),a=setTimeout((function(){a=null,e()}),600)},_showKeyboard:function(){var t=this._delegate,n=t.inputMode===e.InputMode.ANY
__globalAdapter.showKeyboard({defaultValue:t.string,maxLength:t.maxLength<0?65535:t.maxLength,multiple:n,confirmHold:!1,confirmType:c(t.returnType),success:function(e){},
fail:function(e){cc.warn(e.errMsg)}})},_hideKeyboard:function(){__globalAdapter.hideKeyboard({success:function(e){},fail:function(e){cc.warn(e.errMsg)}})}})}function c(e){
switch(e){case n.DEFAULT:case n.DONE:return"done"
case n.SEND:return"send"
case n.SEARCH:return"search"
case n.GO:return"go"
case n.NEXT:return"next"}return"done"}function r(){this._delegate=null,this._editing=!1,this._eventListeners={onKeyboardInput:null,onKeyboardConfirm:null,onKeyboardComplete:null}}
}()},{}],3:[function(e,t,n){"use strict"
var a=window.fsUtils,i=a.getUserDataPath,c=a.readJsonSync,r=a.makeDirSync,o=a.writeFileSync,s=a.copyFile,l=a.downloadFile,u=a.deleteFile,d=a.rmdirSync,f=a.unzip,h=a.isOutOfStorage,b=!1,p=null,m=!1,g=0,_=/^https?:\/\/.*/,y={
cacheDir:"gamecaches",cachedFileName:"cacheList.json",cacheEnabled:!0,autoClear:!0,cacheInterval:500,deleteInterval:500,writeFileInterval:2e3,outOfStorage:!1,tempFiles:null,
cachedFiles:null,cacheQueue:{},version:"1.0",getCache:function(e){return this.cachedFiles.has(e)?this.cachedFiles.get(e).url:""},getTemp:function(e){
return this.tempFiles.has(e)?this.tempFiles.get(e):""},init:function(){this.cacheDir=i()+"/"+this.cacheDir
var e=this.cacheDir+"/"+this.cachedFileName,t=c(e)
t instanceof Error||!t.version?(t instanceof Error||d(this.cacheDir,!0),this.cachedFiles=new cc.AssetManager.Cache,r(this.cacheDir,!0),o(e,JSON.stringify({
files:this.cachedFiles._map,version:this.version}),"utf8")):this.cachedFiles=new cc.AssetManager.Cache(t.files),this.tempFiles=new cc.AssetManager.Cache},
updateLastTime:function(e){this.cachedFiles.has(e)&&(this.cachedFiles.get(e).lastTime=Date.now())},_write:function(){p=null,o(this.cacheDir+"/"+this.cachedFileName,JSON.stringify({
files:this.cachedFiles._map,version:this.version}),"utf8")},writeCacheFile:function(){p||(p=setTimeout(this._write.bind(this),this.writeFileInterval))},_cache:function(){b=!1
var e=this,t=""
for(var n in this.cacheQueue){t=n
break}if(t){var a=this.cacheQueue[t],i=a.srcUrl,c=a.isCopy,r=a.cacheBundleRoot,o=Date.now().toString(),u=""
u=r?"".concat(this.cacheDir,"/").concat(r,"/").concat(o).concat(g++).concat(cc.path.extname(t)):"".concat(this.cacheDir,"/").concat(o).concat(g++).concat(cc.path.extname(t)),
c?s(i,u,d):l(i,u,null,d)}function d(n){if(n){if(h(n.message))return e.outOfStorage=!0,void(e.autoClear&&e.clearLRU())}else e.cachedFiles.add(t,{bundle:r,url:u,lastTime:o}),
e.writeCacheFile()
delete e.cacheQueue[t],cc.js.isEmptyObject(e.cacheQueue)||b||(b=!0,setTimeout(e._cache.bind(e),e.cacheInterval))}},cacheFile:function(e,t,n,a,i){
!(n=void 0!==n?n:this.cacheEnabled)||this.cacheQueue[e]||this.cachedFiles.has(e)||(this.cacheQueue[e]={srcUrl:t,cacheBundleRoot:a,isCopy:i},b||this.outOfStorage||(b=!0,
setTimeout(this._cache.bind(this),this.cacheInterval)))},clearCache:function(){var e=this
d(this.cacheDir,!0),this.cachedFiles=new cc.AssetManager.Cache,r(this.cacheDir,!0),this.outOfStorage=!1,clearTimeout(p),this._write(),cc.assetManager.bundles.forEach((function(t){
_.test(t.base)&&e.makeBundleFolder(t.name)}))},clearLRU:function(){if(!m){m=!0
var e=[],t=this
if(this.cachedFiles.forEach((function(n,a){t._isZipFile(a)&&cc.assetManager.bundles.find((function(e){return-1!==e.base.indexOf(n.url)}))||e.push({originUrl:a,url:n.url,
lastTime:n.lastTime})})),e.sort((function(e,t){return e.lastTime-t.lastTime})),e.length=Math.floor(e.length/3),0!==e.length){
for(var n=0,a=e.length;n<a;n++)this.cachedFiles.remove(e[n].originUrl)
clearTimeout(p),this._write(),setTimeout((function n(){var a=e.pop()
t._isZipFile(a.originUrl)?(d(a.url,!0),t._deleteFileCB()):u(a.url,t._deleteFileCB.bind(t)),e.length>0?setTimeout(n,t.deleteInterval):m=!1}),t.deleteInterval)}}},
removeCache:function(e){if(this.cachedFiles.has(e)){var t=this.cachedFiles.remove(e).url
clearTimeout(p),this._write(),this._isZipFile(e)?(d(t,!0),this._deleteFileCB()):u(t,this._deleteFileCB.bind(this))}},_deleteFileCB:function(e){e||(this.outOfStorage=!1)},
makeBundleFolder:function(e){r(this.cacheDir+"/"+e,!0)},unzipAndCacheBundle:function(e,t,n,a){
var i=Date.now().toString(),c="".concat(this.cacheDir,"/").concat(n,"/").concat(i).concat(g++),o=this
r(c,!0),f(t,c,(function(t){if(t)return d(c,!0),h(t.message)&&(o.outOfStorage=!0,o.autoClear&&o.clearLRU()),void(a&&a(t))
o.cachedFiles.add(e,{bundle:n,url:c,lastTime:i}),o.writeCacheFile(),a&&a(null,c)}))},_isZipFile:function(e){return".zip"===e.slice(-4)}}
cc.assetManager.cacheManager=t.exports=y},{}],4:[function(e,t,n){"use strict"
e("./Editbox"),e("./AssetManager"),e("./misc")},{"./AssetManager":1,"./Editbox":2,"./misc":5}],5:[function(e,t,n){"use strict"
cc.macro.DOWNLOAD_MAX_CONCURRENT=10},{}],6:[function(e,t,n){"use strict"
function a(e){return a="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){
return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},a(e)}function i(e,t){for(var n=0;n<t.length;n++){var a=t[n]
a.enumerable=a.enumerable||!1,a.configurable=!0,"value"in a&&(a.writable=!0),Object.defineProperty(e,a.key,a)}}function c(e,t){
return!t||"object"!==a(t)&&"function"!=typeof t?function(e){if(void 0===e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called")
return e}(e):t}function r(e){return r=Object.setPrototypeOf?Object.getPrototypeOf:function(e){return e.__proto__||Object.getPrototypeOf(e)},r(e)}function o(e,t){
return o=Object.setPrototypeOf||function(e,t){return e.__proto__=t,e},o(e,t)}if(cc.internal.VideoPlayer){
var s=cc.internal.VideoPlayer.EventType,l=cc.Vec3,u=cc.mat4(),d=new l,f=new l,h=wx.getSystemInfoSync().pixelRatio
cc.internal.VideoPlayerImplManager.getImpl=function(e){return new b(e)}
var b=function(e){function t(e){return function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,t),c(this,r(t).call(this,e))}var n,a,b
return function(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function")
e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,writable:!0,configurable:!0}}),t&&o(e,t)}(t,cc.internal.VideoPlayerImpl),n=t,(a=[{key:"syncClip",value:function(e){
this.removeVideoPlayer(),e&&this.createVideoPlayer(e._nativeAsset)}},{key:"syncURL",value:function(e){this.removeVideoPlayer(),e&&this.createVideoPlayer(e)}},{key:"onCanplay",
value:function(){this._loaded||(this._loaded=!0,this.setVisible(this._visible),this.dispatchEvent(s.READY_TO_PLAY),this.delayedPlay())}},{key:"_bindEvent",value:function(){
var e=this._video,t=this
e&&(e.onPlay((function(){t._video===e&&(t._playing=!0,t.dispatchEvent(s.PLAYING))})),e.onEnded((function(){t._video===e&&(t._playing=!1,t._currentTime=t._duration,
t.dispatchEvent(s.COMPLETED))})),e.onPause((function(){t._video===e&&(t._playing=!1,t.dispatchEvent(s.PAUSED))})),e.onTimeUpdate((function(e){t._duration=e.duration,
t._currentTime=e.position})))}},{key:"_unbindEvent",value:function(){var e=this._video
e&&(e.offPlay(),e.offEnded(),e.offPause(),e.offTimeUpdate())}},{key:"createVideoPlayer",value:function(e){
__globalAdapter.createVideo?(this._video||(this._video=__globalAdapter.createVideo(),this._video.showCenterPlayBtn=!1,this._video.controls=!1,this._duration=0,this._currentTime=0,
this._loaded=!1,this.setVisible(this._visible),this._bindEvent(),this._forceUpdate=!0),this.setURL(e),this._forceUpdate=!0):console.warn("VideoPlayer not supported")}},{
key:"setURL",value:function(e){var t=this._video
if(t&&t.src!==e){t.stop(),this._unbindEvent(),t.autoplay=!0,t.src=e,t.muted=!0
var n=this
this._loaded=!1,t.onPlay((function(){t.offPlay(),n._bindEvent(),t.stop(),t.muted=!1,n._loaded=!0,n._playing=!1,n._currentTime=0,n.dispatchEvent(s.READY_TO_PLAY),t.autoplay=!1}))}}
},{key:"removeVideoPlayer",value:function(){var e=this.video
e&&(e.stop(),e.destroy(),this._playing=!1,this._loaded=!1,this._loadedMeta=!1,this._ignorePause=!1,this._cachedCurrentTime=0,this._video=null)}},{key:"setVisible",
value:function(e){var t=this._video
t&&this._visible!==e&&(t.width=e&&this._actualWidth||0,this._visible=e)}},{key:"getDuration",value:function(){return this.duration()}},{key:"duration",value:function(){
return this._duration}},{key:"syncPlaybackRate",value:function(e){var t=this._video
t&&e!==t.playbackRate&&(.5===e|.8===e|1===e|1.25===e|1.5===e?t.playbackRate=e:console.warn("The platform does not support this PlaybackRate!"))}},{key:"syncVolume",
value:function(){console.warn("The platform does not support")}},{key:"syncMute",value:function(e){var t=this._video
t&&t.muted!==e&&(t.muted=e)}},{key:"syncLoop",value:function(e){var t=this._video
t&&t.loop!==e&&(t.loop=e)}},{key:"syncStayOnBottom",value:function(){console.warn("The platform does not support")}},{key:"getCurrentTime",value:function(){
return this.video?this.currentTime():-1}},{key:"currentTime",value:function(){return this._currentTime}},{key:"seekTo",value:function(e){var t=this._video
t&&this._loaded&&t.seek(e)}},{key:"disable",value:function(e){this._video&&(e||this._video.pause(),this.setVisible(!1),this._visible=!1)}},{key:"enable",value:function(){
this._video&&(this.setVisible(!0),this._visible=!0)}},{key:"canPlay",value:function(){this._video.play(),this.syncCurrentTime()}},{key:"resume",value:function(){var e=this._video
!this._playing&&e&&e.play()}},{key:"pause",value:function(){var e=this._video
this._playing&&e&&e.pause()}},{key:"stop",value:function(){var e=this,t=this._video
t&&this._visible&&t.stop().then((function(t){!t.errMsg||t.errMsg.includes("ok")?(e._currentTime=0,e._playing=!1,
e.dispatchEvent(s.STOPPED)):console.error("failed to stop video player")}))}},{key:"canFullScreen",value:function(e){this._video&&this.setFullScreenEnabled(e)}},{
key:"setFullScreenEnabled",value:function(e){var t=this._video
t&&this._fullScreenEnabled!==e&&(e?t.requestFullScreen():t.exitFullScreen(),this._fullScreenEnabled=e)}},{key:"syncKeepAspectRatio",value:function(e){
console.warn("On wechat game videoPlayer is always keep the aspect ratio")}},{key:"syncMatrix",value:function(){if(this._video&&this._component&&this._uiTrans){var e=this.UICamera
if(e){this._component.node.getWorldMatrix(u)
var t=this._uiTrans.contentSize,n=t.width,a=t.height
if(this._forceUpdate||this._m00!==u.m00||this._m01!==u.m01||this._m04!==u.m04||this._m05!==u.m05||this._m12!==u.m12||this._m13!==u.m13||this._w!==n||this._h!==a){this._m00=u.m00,
this._m01=u.m01,this._m04=u.m04,this._m05=u.m05,this._m12=u.m12,this._m13=u.m13,this._w=n,this._h=a,cc.game.canvas.width
var i=cc.game.canvas.height,c=this._uiTrans.anchorPoint
l.set(d,-c.x*this._w,(1-c.y)*this._h,0),l.set(f,(1-c.x)*this._w,-c.y*this._h,0),l.transformMat4(d,d,u),l.transformMat4(f,f,u),e.worldToScreen(d,d),e.worldToScreen(f,f)
var r=f.x-d.x,o=d.y-f.y
this._video.x=d.x/h,this._video.y=(i-d.y)/h,this._actualWidth=this._video.width=r/h,this._video.height=o/h,this._forceUpdate=!1}}}}}])&&i(n.prototype,a),b&&i(n,b),t}()}},{}],
7:[function(e,t,n){"use strict"
e("../fs-utils"),e("../../../../common/engine/index"),e("./VideoPlayer"),e("./sprite-frame")},{"../../../../common/engine/index":4,"../fs-utils":9,"./VideoPlayer":6,
"./sprite-frame":8}],8:[function(e,t,n){"use strict"
cc.SpriteFrame&&(cc.SpriteFrame.prototype._checkPackable=function(){var e=cc.internal.dynamicAtlasManager
if(e){var t=this._texture
if(t instanceof cc.Texture2D&&!t.isCompressed){var n=this.width,a=this.height
!t.image||n>e.maxFrameSize||a>e.maxFrameSize?this._packable=!1:t.image&&t.image.getContext&&(this._packable=!0)}else this._packable=!1}})},{}],9:[function(e,t,n){"use strict"
var a=wx.getFileSystemManager?wx.getFileSystemManager():null,i=/the maximum size of the file storage/,c={fs:a,isOutOfStorage:function(e){return i.test(e)},
getUserDataPath:function(){return wx.env.USER_DATA_PATH},checkFsValid:function(){return!!a||(console.warn("can not get the file system!"),!1)},deleteFile:function(e,t){a.unlink({
filePath:e,success:function(){t&&t(null)},fail:function(n){console.warn("Delete file failed: path: ".concat(e," message: ").concat(n.errMsg)),t&&t(new Error(n.errMsg))}})},
downloadFile:function(e,t,n,a,i){var r={url:e,success:function(t){200===t.statusCode?i&&i(null,t.tempFilePath||t.filePath):(t.filePath&&c.deleteFile(t.filePath),
console.warn("Download file failed: path: ".concat(e," message: ").concat(t.statusCode)),i&&i(new Error(t.statusCode),null))},fail:function(t){
console.warn("Download file failed: path: ".concat(e," message: ").concat(t.errMsg)),i&&i(new Error(t.errMsg),null)}}
t&&(r.filePath=t),n&&(r.header=n)
var o=wx.downloadFile(r)
a&&o.onProgressUpdate(a)},saveFile:function(e,t,n){wx.saveFile({tempFilePath:e,filePath:t,success:function(e){n&&n(null)},fail:function(t){
console.warn("Save file failed: path: ".concat(e," message: ").concat(t.errMsg)),n&&n(new Error(t.errMsg))}})},copyFile:function(e,t,n){a.copyFile({srcPath:e,destPath:t,
success:function(){n&&n(null)},fail:function(t){console.warn("Copy file failed: path: ".concat(e," message: ").concat(t.errMsg)),n&&n(new Error(t.errMsg))}})},
writeFile:function(e,t,n,i){a.writeFile({filePath:e,encoding:n,data:t,success:function(){i&&i(null)},fail:function(t){
console.warn("Write file failed: path: ".concat(e," message: ").concat(t.errMsg)),i&&i(new Error(t.errMsg))}})},writeFileSync:function(e,t,n){try{return a.writeFileSync(e,t,n),null
}catch(t){return console.warn("Write file failed: path: ".concat(e," message: ").concat(t.message)),new Error(t.message)}},readFile:function(e,t,n){a.readFile({filePath:e,
encoding:t,success:function(e){n&&n(null,e.data)},fail:function(t){console.warn("Read file failed: path: ".concat(e," message: ").concat(t.errMsg)),n&&n(new Error(t.errMsg),null)}
})},readDir:function(e,t){a.readdir({dirPath:e,success:function(e){t&&t(null,e.files)},fail:function(n){
console.warn("Read directory failed: path: ".concat(e," message: ").concat(n.errMsg)),t&&t(new Error(n.errMsg),null)}})},readText:function(e,t){c.readFile(e,"utf8",t)},
readArrayBuffer:function(e,t){c.readFile(e,"",t)},readJson:function(e,t){c.readFile(e,"utf8",(function(n,a){var i=null
if(!n)try{i=JSON.parse(a)}catch(t){console.warn("Read json failed: path: ".concat(e," message: ").concat(t.message)),n=new Error(t.message)}t&&t(n,i)}))},readJsonSync:function(e){
try{var t=a.readFileSync(e,"utf8")
return JSON.parse(t)}catch(t){return console.warn("Read json failed: path: ".concat(e," message: ").concat(t.message)),new Error(t.message)}},makeDirSync:function(e,t){try{
return a.mkdirSync(e,t),null}catch(t){return console.warn("Make directory failed: path: ".concat(e," message: ").concat(t.message)),new Error(t.message)}},rmdirSync:function(e,t){
try{a.rmdirSync(e,t)}catch(t){return console.warn("rm directory failed: path: ".concat(e," message: ").concat(t.message)),new Error(t.message)}},exists:function(e,t){a.access({
path:e,success:function(){t&&t(!0)},fail:function(){t&&t(!1)}})},loadSubpackage:function(e,t,n){var a=wx.loadSubpackage({name:e,success:function(){n&&n()},fail:function(t){
console.warn("Load Subpackage failed: path: ".concat(e," message: ").concat(t.errMsg)),n&&n(new Error("Failed to load subpackage ".concat(e,": ").concat(t.errMsg)))}})
return t&&a.onProgressUpdate(t),a},unzip:function(e,t,n){a.unzip({zipFilePath:e,targetPath:t,success:function(){n&&n(null)},fail:function(t){
console.warn("unzip failed: path: ".concat(e," message: ").concat(t.errMsg)),n&&n(new Error("unzip failed: "+t.errMsg))}})}}
window.fsUtils=t.exports=c},{}]},{},[7])
