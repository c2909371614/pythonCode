function __initApp () {  // init app
globalThis.__wxRequire = require;  // FIX: require cannot work in separate engine 

!function e(t,n,r){function o(a,u){if(!n[a]){if(!t[a]){var c="function"==typeof require&&require
if(!u&&c)return c(a,!0)
if(i)return i(a,!0)
var l=new Error("Cannot find module '"+a+"'")
throw l.code="MODULE_NOT_FOUND",l}var s=n[a]={exports:{}}
t[a][0].call(s.exports,(function(e){return o(t[a][1][e]||e)}),s,s.exports,e,t,n,r)}return n[a].exports}for(var i="function"==typeof require&&require,a=0;a<r.length;a++)o(r[a])
return o}({1:[function(e,t,n){"use strict"
function r(e){this.options=e||{locator:{}}}function o(){this.cdata=!1}function i(e,t){t.lineNumber=e.lineNumber,t.columnNumber=e.columnNumber}function a(e){
if(e)return"\n@"+(e.systemId||"")+"#[line:"+e.lineNumber+",col:"+e.columnNumber+"]"}function u(e,t,n){
return"string"==typeof e?e.substr(t,n):e.length>=t+n||t?new java.lang.String(e,t,n)+"":e}function c(e,t){e.currentElement?e.currentElement.appendChild(t):e.doc.appendChild(t)}
r.prototype.parseFromString=function(e,t){var n=this.options,r=new s,i=n.domBuilder||new o,u=n.errorHandler,c=n.locator,f=n.xmlns||{},d=/\/x?html?$/.test(t),p=d?l.entityMap:{
lt:"<",gt:">",amp:"&",quot:'"',apos:"'"}
return c&&i.setDocumentLocator(c),r.errorHandler=function(e,t,n){if(!e){if(t instanceof o)return t
e=t}var r={},i=e instanceof Function
function u(t){var o=e[t]
!o&&i&&(o=2==e.length?function(n){e(t,n)}:e),r[t]=o&&function(e){o("[xmldom "+t+"]\t"+e+a(n))}||function(){}}return n=n||{},u("warning"),u("error"),u("fatalError"),r}(u,i,c),
r.domBuilder=n.domBuilder||i,d&&(f[""]="http://www.w3.org/1999/xhtml"),f.xml=f.xml||"http://www.w3.org/XML/1998/namespace",
e?r.parse(e,f,p):r.errorHandler.error("invalid doc source"),i.doc},o.prototype={startDocument:function(){this.doc=(new f).createDocument(null,null,null),
this.locator&&(this.doc.documentURI=this.locator.systemId)},startElement:function(e,t,n,r){var o=this.doc,a=o.createElementNS(e,n||t),u=r.length
c(this,a),this.currentElement=a,this.locator&&i(this.locator,a)
for(var l=0;l<u;l++){e=r.getURI(l)
var s=r.getValue(l),f=(n=r.getQName(l),o.createAttributeNS(e,n))
this.locator&&i(r.getLocator(l),f),f.value=f.nodeValue=s,a.setAttributeNode(f)}},endElement:function(e,t,n){var r=this.currentElement
r.tagName
this.currentElement=r.parentNode},startPrefixMapping:function(e,t){},endPrefixMapping:function(e){},processingInstruction:function(e,t){
var n=this.doc.createProcessingInstruction(e,t)
this.locator&&i(this.locator,n),c(this,n)},ignorableWhitespace:function(e,t,n){},characters:function(e,t,n){if(e=u.apply(this,arguments)){
if(this.cdata)var r=this.doc.createCDATASection(e)
else r=this.doc.createTextNode(e)
this.currentElement?this.currentElement.appendChild(r):/^\s*$/.test(e)&&this.doc.appendChild(r),this.locator&&i(this.locator,r)}},skippedEntity:function(e){},
endDocument:function(){this.doc.normalize()},setDocumentLocator:function(e){(this.locator=e)&&(e.lineNumber=0)},comment:function(e,t,n){e=u.apply(this,arguments)
var r=this.doc.createComment(e)
this.locator&&i(this.locator,r),c(this,r)},startCDATA:function(){this.cdata=!0},endCDATA:function(){this.cdata=!1},startDTD:function(e,t,n){var r=this.doc.implementation
if(r&&r.createDocumentType){var o=r.createDocumentType(e,t,n)
this.locator&&i(this.locator,o),c(this,o)}},warning:function(e){console.warn("[xmldom warning]\t"+e,a(this.locator))},error:function(e){
console.error("[xmldom error]\t"+e,a(this.locator))},fatalError:function(e){throw console.error("[xmldom fatalError]\t"+e,a(this.locator)),e}},
"endDTD,startEntity,endEntity,attributeDecl,elementDecl,externalEntityDecl,internalEntityDecl,resolveEntity,getExternalSubset,notationDecl,unparsedEntityDecl".replace(/\w+/g,(function(e){
o.prototype[e]=function(){return null}}))
var l=e("./entities"),s=e("./sax").XMLReader,f=n.DOMImplementation=e("./dom").DOMImplementation
n.XMLSerializer=e("./dom").XMLSerializer,n.DOMParser=r,window.DOMParser=r},{"./dom":2,"./entities":3,"./sax":4}],2:[function(e,t,n){"use strict"
function r(e){return r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){
return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},r(e)}function o(e,t){for(var n in e)t[n]=e[n]}function i(e,t){var n=e.prototype
if(!(n instanceof t)){var r=function(){}
for(var o in r.prototype=t.prototype,r=new r,n)r[o]=n[o]
e.prototype=n=r}n.constructor!=e&&("function"!=typeof e&&console.error("unknow Class:"+e),n.constructor=e)}
var a={},u=a.ELEMENT_NODE=1,c=a.ATTRIBUTE_NODE=2,l=a.TEXT_NODE=3,s=a.CDATA_SECTION_NODE=4,f=a.ENTITY_REFERENCE_NODE=5,d=a.ENTITY_NODE=6,p=a.PROCESSING_INSTRUCTION_NODE=7,E=a.COMMENT_NODE=8,h=a.DOCUMENT_NODE=9,m=a.DOCUMENT_TYPE_NODE=10,_=a.DOCUMENT_FRAGMENT_NODE=11,y=a.NOTATION_NODE=12,T={},v={},b=(T.INDEX_SIZE_ERR=(v[1]="Index size error",
1),T.DOMSTRING_SIZE_ERR=(v[2]="DOMString size error",2),T.HIERARCHY_REQUEST_ERR=(v[3]="Hierarchy request error",3)),g=(T.WRONG_DOCUMENT_ERR=(v[4]="Wrong document",4),
T.INVALID_CHARACTER_ERR=(v[5]="Invalid character",5),T.NO_DATA_ALLOWED_ERR=(v[6]="No data allowed",6),T.NO_MODIFICATION_ALLOWED_ERR=(v[7]="No modification allowed",7),
T.NOT_FOUND_ERR=(v[8]="Not found",8)),N=(T.NOT_SUPPORTED_ERR=(v[9]="Not supported",9),T.INUSE_ATTRIBUTE_ERR=(v[10]="Attribute in use",10))
T.INVALID_STATE_ERR=(v[11]="Invalid state",11),T.SYNTAX_ERR=(v[12]="Syntax error",12),T.INVALID_MODIFICATION_ERR=(v[13]="Invalid modification",13),
T.NAMESPACE_ERR=(v[14]="Invalid namespace",14),T.INVALID_ACCESS_ERR=(v[15]="Invalid access",15)
function A(e,t){if(t instanceof Error)var n=t
else n=this,Error.call(this,v[e]),this.message=v[e],Error.captureStackTrace&&Error.captureStackTrace(this,A)
return n.code=e,t&&(this.message=this.message+": "+t),n}function w(){}function R(e,t){this._node=e,this._refresh=t,O(this)}function O(e){
var t=e._node._inc||e._node.ownerDocument._inc
if(e._inc!=t){var n=e._refresh(e._node)
for(var r in ie(e,"length",n.length),n)e[r]=n[r]
e._inc=t}}function S(){}function I(e,t){for(var n=e.length;n--;)if(e[n]===t)return n}function M(e,t,n,r){if(r?t[I(t,r)]=n:t[t.length++]=n,e){n.ownerElement=e
var o=e.ownerDocument
o&&(r&&F(o,e,r),function(e,t,n){e&&e._inc++,"http://www.w3.org/2000/xmlns/"==n.namespaceURI&&(t._nsMap[n.prefix?n.localName:""]=n.value)}(o,e,n))}}function C(e,t,n){var r=I(t,n)
if(!(r>=0))throw A(g,new Error(e.tagName+"@"+n))
for(var o=t.length-1;r<o;)t[r]=t[++r]
if(t.length=o,e){var i=e.ownerDocument
i&&(F(i,e,n),n.ownerElement=null)}}function P(e){if(this._features={},e)for(var t in e)this._features=e[t]}function L(){}function D(e){
return("<"==e?"&lt;":">"==e&&"&gt;")||"&"==e&&"&amp;"||'"'==e&&"&quot;"||"&#"+e.charCodeAt()+";"}function x(e,t){if(t(e))return!0
if(e=e.firstChild)do{if(x(e,t))return!0}while(e=e.nextSibling)}function U(){}function F(e,t,n,r){e&&e._inc++,
"http://www.w3.org/2000/xmlns/"==n.namespaceURI&&delete t._nsMap[n.prefix?n.localName:""]}function j(e,t,n){if(e&&e._inc){e._inc++
var r=t.childNodes
if(n)r[r.length++]=n
else{for(var o=t.firstChild,i=0;o;)r[i++]=o,o=o.nextSibling
r.length=i}}}function B(e,t){var n=t.previousSibling,r=t.nextSibling
return n?n.nextSibling=r:e.firstChild=r,r?r.previousSibling=n:e.lastChild=n,j(e.ownerDocument,e),t}function H(e,t,n){var r=t.parentNode
if(r&&r.removeChild(t),t.nodeType===_){var o=t.firstChild
if(null==o)return t
var i=t.lastChild}else o=i=t
var a=n?n.previousSibling:e.lastChild
o.previousSibling=a,i.nextSibling=n,a?a.nextSibling=o:e.firstChild=o,null==n?e.lastChild=i:n.previousSibling=i
do{o.parentNode=e}while(o!==i&&(o=o.nextSibling))
return j(e.ownerDocument||e,e),t.nodeType==_&&(t.firstChild=t.lastChild=null),t}function k(){this._nsMap={}}function G(){}function X(){}function V(){}function W(){}function q(){}
function $(){}function Y(){}function K(){}function z(){}function Z(){}function Q(){}function J(){}function ee(e,t){
var n=[],r=9==this.nodeType&&this.documentElement||this,o=r.prefix,i=r.namespaceURI
if(i&&null==o&&null==(o=r.lookupPrefix(i)))var a=[{namespace:i,prefix:null}]
return ne(this,n,e,t,a),n.join("")}function te(e,t,n){var r=e.prefix||"",o=e.namespaceURI
if(!r&&!o)return!1
if("xml"===r&&"http://www.w3.org/XML/1998/namespace"===o||"http://www.w3.org/2000/xmlns/"==o)return!1
for(var i=n.length;i--;){var a=n[i]
if(a.prefix==r)return a.namespace!=o}return!0}function ne(e,t,n,r,o){if(r){if(!(e=r(e)))return
if("string"==typeof e)return void t.push(e)}switch(e.nodeType){case u:o||(o=[])
o.length
var i=e.attributes,a=i.length,d=e.firstChild,y=e.tagName
n="http://www.w3.org/1999/xhtml"===e.namespaceURI||n,t.push("<",y)
for(var T=0;T<a;T++){"xmlns"==(v=i.item(T)).prefix?o.push({prefix:v.localName,namespace:v.value}):"xmlns"==v.nodeName&&o.push({prefix:"",namespace:v.value})}for(T=0;T<a;T++){var v
if(te(v=i.item(T),0,o)){var b=v.prefix||"",g=v.namespaceURI,N=b?" xmlns:"+b:" xmlns"
t.push(N,'="',g,'"'),o.push({prefix:b,namespace:g})}ne(v,t,n,r,o)}if(te(e,0,o)){b=e.prefix||"",g=e.namespaceURI,N=b?" xmlns:"+b:" xmlns"
t.push(N,'="',g,'"'),o.push({prefix:b,namespace:g})}if(d||n&&!/^(?:meta|link|img|br|hr|input)$/i.test(y)){if(t.push(">"),
n&&/^script$/i.test(y))for(;d;)d.data?t.push(d.data):ne(d,t,n,r,o),d=d.nextSibling
else for(;d;)ne(d,t,n,r,o),d=d.nextSibling
t.push("</",y,">")}else t.push("/>")
return
case h:case _:for(d=e.firstChild;d;)ne(d,t,n,r,o),d=d.nextSibling
return
case c:return t.push(" ",e.name,'="',e.value.replace(/[<&"]/g,D),'"')
case l:return t.push(e.data.replace(/[<&]/g,D))
case s:return t.push("<![CDATA[",e.data,"]]>")
case E:return t.push("\x3c!--",e.data,"--\x3e")
case m:var A=e.publicId,w=e.systemId
if(t.push("<!DOCTYPE ",e.name),A)t.push(' PUBLIC "',A),w&&"."!=w&&t.push('" "',w),t.push('">')
else if(w&&"."!=w)t.push(' SYSTEM "',w,'">')
else{var R=e.internalSubset
R&&t.push(" [",R,"]"),t.push(">")}return
case p:return t.push("<?",e.target," ",e.data,"?>")
case f:return t.push("&",e.nodeName,";")
default:t.push("??",e.nodeName)}}function re(e,t,n){var r
switch(t.nodeType){case u:(r=t.cloneNode(!1)).ownerDocument=e
case _:break
case c:n=!0}if(r||(r=t.cloneNode(!1)),r.ownerDocument=e,r.parentNode=null,n)for(var o=t.firstChild;o;)r.appendChild(re(e,o,n)),o=o.nextSibling
return r}function oe(e,t,n){var o=new t.constructor
for(var i in t){var a=t[i]
"object"!=r(a)&&a!=o[i]&&(o[i]=a)}switch(t.childNodes&&(o.childNodes=new w),o.ownerDocument=e,o.nodeType){case u:var l=t.attributes,s=o.attributes=new S,f=l.length
s._ownerElement=o
for(var d=0;d<f;d++)o.setAttributeNode(oe(e,l.item(d),!0))
break
case c:n=!0}if(n)for(var p=t.firstChild;p;)o.appendChild(oe(e,p,n)),p=p.nextSibling
return o}function ie(e,t,n){e[t]=n}A.prototype=Error.prototype,o(T,A),w.prototype={length:0,item:function(e){return this[e]||null},toString:function(e,t){
for(var n=[],r=0;r<this.length;r++)ne(this[r],n,e,t)
return n.join("")}},R.prototype.item=function(e){return O(this),this[e]},i(R,w),S.prototype={length:0,item:w.prototype.item,getNamedItem:function(e){for(var t=this.length;t--;){
var n=this[t]
if(n.nodeName==e)return n}},setNamedItem:function(e){var t=e.ownerElement
if(t&&t!=this._ownerElement)throw new A(N)
var n=this.getNamedItem(e.nodeName)
return M(this._ownerElement,this,e,n),n},setNamedItemNS:function(e){var t,n=e.ownerElement
if(n&&n!=this._ownerElement)throw new A(N)
return t=this.getNamedItemNS(e.namespaceURI,e.localName),M(this._ownerElement,this,e,t),t},removeNamedItem:function(e){var t=this.getNamedItem(e)
return C(this._ownerElement,this,t),t},removeNamedItemNS:function(e,t){var n=this.getNamedItemNS(e,t)
return C(this._ownerElement,this,n),n},getNamedItemNS:function(e,t){for(var n=this.length;n--;){var r=this[n]
if(r.localName==t&&r.namespaceURI==e)return r}return null}},P.prototype={hasFeature:function(e,t){var n=this._features[e.toLowerCase()]
return!(!n||t&&!(t in n))},createDocument:function(e,t,n){var r=new U
if(r.implementation=this,r.childNodes=new w,r.doctype=n,n&&r.appendChild(n),t){var o=r.createElementNS(e,t)
r.appendChild(o)}return r},createDocumentType:function(e,t,n){var r=new $
return r.name=e,r.nodeName=e,r.publicId=t,r.systemId=n,r}},L.prototype={firstChild:null,lastChild:null,previousSibling:null,nextSibling:null,attributes:null,parentNode:null,
childNodes:null,ownerDocument:null,nodeValue:null,namespaceURI:null,prefix:null,localName:null,insertBefore:function(e,t){return H(this,e,t)},replaceChild:function(e,t){
this.insertBefore(e,t),t&&this.removeChild(t)},removeChild:function(e){return B(this,e)},appendChild:function(e){return this.insertBefore(e,null)},hasChildNodes:function(){
return null!=this.firstChild},cloneNode:function(e){return oe(this.ownerDocument||this,this,e)},normalize:function(){for(var e=this.firstChild;e;){var t=e.nextSibling
t&&t.nodeType==l&&e.nodeType==l?(this.removeChild(t),e.appendData(t.data)):(e.normalize(),e=t)}},isSupported:function(e,t){return this.ownerDocument.implementation.hasFeature(e,t)
},hasAttributes:function(){return this.attributes.length>0},lookupPrefix:function(e){for(var t=this;t;){var n=t._nsMap
if(n)for(var r in n)if(n[r]==e)return r
t=t.nodeType==c?t.ownerDocument:t.parentNode}return null},lookupNamespaceURI:function(e){for(var t=this;t;){var n=t._nsMap
if(n&&e in n)return n[e]
t=t.nodeType==c?t.ownerDocument:t.parentNode}return null},isDefaultNamespace:function(e){return null==this.lookupPrefix(e)}},o(a,L),o(a,L.prototype),U.prototype={
nodeName:"#document",nodeType:h,doctype:null,documentElement:null,_inc:1,insertBefore:function(e,t){if(e.nodeType==_){for(var n=e.firstChild;n;){var r=n.nextSibling
this.insertBefore(n,t),n=r}return e}return null==this.documentElement&&e.nodeType==u&&(this.documentElement=e),H(this,e,t),e.ownerDocument=this,e},removeChild:function(e){
return this.documentElement==e&&(this.documentElement=null),B(this,e)},importNode:function(e,t){return re(this,e,t)},getElementById:function(e){var t=null
return x(this.documentElement,(function(n){if(n.nodeType==u&&n.getAttribute("id")==e)return t=n,!0})),t},createElement:function(e){var t=new k
return t.ownerDocument=this,t.nodeName=e,t.tagName=e,t.childNodes=new w,(t.attributes=new S)._ownerElement=t,t},createDocumentFragment:function(){var e=new Z
return e.ownerDocument=this,e.childNodes=new w,e},createTextNode:function(e){var t=new V
return t.ownerDocument=this,t.appendData(e),t},createComment:function(e){var t=new W
return t.ownerDocument=this,t.appendData(e),t},createCDATASection:function(e){var t=new q
return t.ownerDocument=this,t.appendData(e),t},createProcessingInstruction:function(e,t){var n=new Q
return n.ownerDocument=this,n.tagName=n.target=e,n.nodeValue=n.data=t,n},createAttribute:function(e){var t=new G
return t.ownerDocument=this,t.name=e,t.nodeName=e,t.localName=e,t.specified=!0,t},createEntityReference:function(e){var t=new z
return t.ownerDocument=this,t.nodeName=e,t},createElementNS:function(e,t){var n=new k,r=t.split(":"),o=n.attributes=new S
return n.childNodes=new w,n.ownerDocument=this,n.nodeName=t,n.tagName=t,n.namespaceURI=e,2==r.length?(n.prefix=r[0],n.localName=r[1]):n.localName=t,o._ownerElement=n,n},
createAttributeNS:function(e,t){var n=new G,r=t.split(":")
return n.ownerDocument=this,n.nodeName=t,n.name=t,n.namespaceURI=e,n.specified=!0,2==r.length?(n.prefix=r[0],n.localName=r[1]):n.localName=t,n}},i(U,L),k.prototype={nodeType:u,
hasAttribute:function(e){return null!=this.getAttributeNode(e)},getAttribute:function(e){var t=this.getAttributeNode(e)
return t&&t.value||""},getAttributeNode:function(e){return this.attributes.getNamedItem(e)},setAttribute:function(e,t){var n=this.ownerDocument.createAttribute(e)
n.value=n.nodeValue=""+t,this.setAttributeNode(n)},removeAttribute:function(e){var t=this.getAttributeNode(e)
t&&this.removeAttributeNode(t)},appendChild:function(e){return e.nodeType===_?this.insertBefore(e,null):function(e,t){var n=t.parentNode
if(n){var r=e.lastChild
n.removeChild(t),r=e.lastChild}return r=e.lastChild,t.parentNode=e,t.previousSibling=r,t.nextSibling=null,r?r.nextSibling=t:e.firstChild=t,e.lastChild=t,j(e.ownerDocument,e,t),t
}(this,e)},setAttributeNode:function(e){return this.attributes.setNamedItem(e)},setAttributeNodeNS:function(e){return this.attributes.setNamedItemNS(e)},
removeAttributeNode:function(e){return this.attributes.removeNamedItem(e.nodeName)},removeAttributeNS:function(e,t){var n=this.getAttributeNodeNS(e,t)
n&&this.removeAttributeNode(n)},hasAttributeNS:function(e,t){return null!=this.getAttributeNodeNS(e,t)},getAttributeNS:function(e,t){var n=this.getAttributeNodeNS(e,t)
return n&&n.value||""},setAttributeNS:function(e,t,n){var r=this.ownerDocument.createAttributeNS(e,t)
r.value=r.nodeValue=""+n,this.setAttributeNode(r)},getAttributeNodeNS:function(e,t){return this.attributes.getNamedItemNS(e,t)},getElementsByTagName:function(e){
return new R(this,(function(t){var n=[]
return x(t,(function(r){r===t||r.nodeType!=u||"*"!==e&&r.tagName!=e||n.push(r)})),n}))},getElementsByTagNameNS:function(e,t){return new R(this,(function(n){var r=[]
return x(n,(function(o){o===n||o.nodeType!==u||"*"!==e&&o.namespaceURI!==e||"*"!==t&&o.localName!=t||r.push(o)})),r}))}},
U.prototype.getElementsByTagName=k.prototype.getElementsByTagName,U.prototype.getElementsByTagNameNS=k.prototype.getElementsByTagNameNS,i(k,L),G.prototype.nodeType=c,i(G,L),
X.prototype={data:"",substringData:function(e,t){return this.data.substring(e,e+t)},appendData:function(e){e=this.data+e,this.nodeValue=this.data=e,this.length=e.length},
insertData:function(e,t){this.replaceData(e,0,t)},appendChild:function(e){throw new Error(v[b])},deleteData:function(e,t){this.replaceData(e,t,"")},replaceData:function(e,t,n){
n=this.data.substring(0,e)+n+this.data.substring(e+t),this.nodeValue=this.data=n,this.length=n.length}},i(X,L),V.prototype={nodeName:"#text",nodeType:l,splitText:function(e){
var t=this.data,n=t.substring(e)
t=t.substring(0,e),this.data=this.nodeValue=t,this.length=t.length
var r=this.ownerDocument.createTextNode(n)
return this.parentNode&&this.parentNode.insertBefore(r,this.nextSibling),r}},i(V,X),W.prototype={nodeName:"#comment",nodeType:E},i(W,X),q.prototype={nodeName:"#cdata-section",
nodeType:s},i(q,X),$.prototype.nodeType=m,i($,L),Y.prototype.nodeType=y,i(Y,L),K.prototype.nodeType=d,i(K,L),z.prototype.nodeType=f,i(z,L),
Z.prototype.nodeName="#document-fragment",Z.prototype.nodeType=_,i(Z,L),Q.prototype.nodeType=p,i(Q,L),J.prototype.serializeToString=function(e,t,n){return ee.call(e,t,n)},
L.prototype.toString=ee
try{if(Object.defineProperty){var ae=function e(t){switch(t.nodeType){case u:case _:var n=[]
for(t=t.firstChild;t;)7!==t.nodeType&&8!==t.nodeType&&n.push(e(t)),t=t.nextSibling
return n.join("")
default:return t.nodeValue}}
Object.defineProperty(R.prototype,"length",{get:function(){return O(this),this.$length}}),Object.defineProperty(L.prototype,"textContent",{get:function(){return ae(this)},
set:function(e){switch(this.nodeType){case u:case _:for(;this.firstChild;)this.removeChild(this.firstChild);(e||String(e))&&this.appendChild(this.ownerDocument.createTextNode(e))
break
default:this.data=e,this.value=e,this.nodeValue=e}}}),ie=function(e,t,n){e["$"+t]=n}}}catch(e){}n.DOMImplementation=P,n.XMLSerializer=J},{}],3:[function(e,t,n){"use strict"
n.entityMap={lt:"<",gt:">",amp:"&",quot:'"',apos:"'",Agrave:"À",Aacute:"Á",Acirc:"Â",Atilde:"Ã",Auml:"Ä",Aring:"Å",AElig:"Æ",Ccedil:"Ç",Egrave:"È",Eacute:"É",Ecirc:"Ê",Euml:"Ë",
Igrave:"Ì",Iacute:"Í",Icirc:"Î",Iuml:"Ï",ETH:"Ð",Ntilde:"Ñ",Ograve:"Ò",Oacute:"Ó",Ocirc:"Ô",Otilde:"Õ",Ouml:"Ö",Oslash:"Ø",Ugrave:"Ù",Uacute:"Ú",Ucirc:"Û",Uuml:"Ü",Yacute:"Ý",
THORN:"Þ",szlig:"ß",agrave:"à",aacute:"á",acirc:"â",atilde:"ã",auml:"ä",aring:"å",aelig:"æ",ccedil:"ç",egrave:"è",eacute:"é",ecirc:"ê",euml:"ë",igrave:"ì",iacute:"í",icirc:"î",
iuml:"ï",eth:"ð",ntilde:"ñ",ograve:"ò",oacute:"ó",ocirc:"ô",otilde:"õ",ouml:"ö",oslash:"ø",ugrave:"ù",uacute:"ú",ucirc:"û",uuml:"ü",yacute:"ý",thorn:"þ",yuml:"ÿ",nbsp:" ",
iexcl:"¡",cent:"¢",pound:"£",curren:"¤",yen:"¥",brvbar:"¦",sect:"§",uml:"¨",copy:"©",ordf:"ª",laquo:"«",not:"¬",shy:"­­",reg:"®",macr:"¯",deg:"°",plusmn:"±",sup2:"²",sup3:"³",
acute:"´",micro:"µ",para:"¶",middot:"·",cedil:"¸",sup1:"¹",ordm:"º",raquo:"»",frac14:"¼",frac12:"½",frac34:"¾",iquest:"¿",times:"×",divide:"÷",forall:"∀",part:"∂",exist:"∃",
empty:"∅",nabla:"∇",isin:"∈",notin:"∉",ni:"∋",prod:"∏",sum:"∑",minus:"−",lowast:"∗",radic:"√",prop:"∝",infin:"∞",ang:"∠",and:"∧",or:"∨",cap:"∩",cup:"∪",int:"∫",there4:"∴",sim:"∼",
cong:"≅",asymp:"≈",ne:"≠",equiv:"≡",le:"≤",ge:"≥",sub:"⊂",sup:"⊃",nsub:"⊄",sube:"⊆",supe:"⊇",oplus:"⊕",otimes:"⊗",perp:"⊥",sdot:"⋅",Alpha:"Α",Beta:"Β",Gamma:"Γ",Delta:"Δ",
Epsilon:"Ε",Zeta:"Ζ",Eta:"Η",Theta:"Θ",Iota:"Ι",Kappa:"Κ",Lambda:"Λ",Mu:"Μ",Nu:"Ν",Xi:"Ξ",Omicron:"Ο",Pi:"Π",Rho:"Ρ",Sigma:"Σ",Tau:"Τ",Upsilon:"Υ",Phi:"Φ",Chi:"Χ",Psi:"Ψ",
Omega:"Ω",alpha:"α",beta:"β",gamma:"γ",delta:"δ",epsilon:"ε",zeta:"ζ",eta:"η",theta:"θ",iota:"ι",kappa:"κ",lambda:"λ",mu:"μ",nu:"ν",xi:"ξ",omicron:"ο",pi:"π",rho:"ρ",sigmaf:"ς",
sigma:"σ",tau:"τ",upsilon:"υ",phi:"φ",chi:"χ",psi:"ψ",omega:"ω",thetasym:"ϑ",upsih:"ϒ",piv:"ϖ",OElig:"Œ",oelig:"œ",Scaron:"Š",scaron:"š",Yuml:"Ÿ",fnof:"ƒ",circ:"ˆ",tilde:"˜",
ensp:" ",emsp:" ",thinsp:" ",zwnj:"‌",zwj:"‍",lrm:"‎",rlm:"‏",ndash:"–",mdash:"—",lsquo:"‘",rsquo:"’",sbquo:"‚",ldquo:"“",rdquo:"”",bdquo:"„",dagger:"†",Dagger:"‡",bull:"•",
hellip:"…",permil:"‰",prime:"′",Prime:"″",lsaquo:"‹",rsaquo:"›",oline:"‾",euro:"€",trade:"™",larr:"←",uarr:"↑",rarr:"→",darr:"↓",harr:"↔",crarr:"↵",lceil:"⌈",rceil:"⌉",lfloor:"⌊",
rfloor:"⌋",loz:"◊",spades:"♠",clubs:"♣",hearts:"♥",diams:"♦"}},{}],4:[function(e,t,n){"use strict"
var r=/[A-Z_a-z\xC0-\xD6\xD8-\xF6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/,o=new RegExp("[\\-\\.0-9"+r.source.slice(1,-1)+"\\u00B7\\u0300-\\u036F\\u203F-\\u2040]"),i=new RegExp("^"+r.source+o.source+"*(?::"+r.source+o.source+"*)?$")
function a(){}function u(e,t){return t.lineNumber=e.lineNumber,t.columnNumber=e.columnNumber,t}function c(e,t,n,r,o,i){for(var a,u=++t,c=0;;){var l=e.charAt(u)
switch(l){case"=":if(1===c)a=e.slice(t,u),c=3
else{if(2!==c)throw new Error("attribute equal must after attrName")
c=3}break
case"'":case'"':if(3===c||1===c){if(1===c&&(i.warning('attribute value must after "="'),a=e.slice(t,u)),t=u+1,
!((u=e.indexOf(l,t))>0))throw new Error("attribute value no end '"+l+"' match")
s=e.slice(t,u).replace(/&#?\w+;/g,o),n.add(a,s,t-1),c=5}else{if(4!=c)throw new Error('attribute value must after "="')
s=e.slice(t,u).replace(/&#?\w+;/g,o),n.add(a,s,t),i.warning('attribute "'+a+'" missed start quot('+l+")!!"),t=u+1,c=5}break
case"/":switch(c){case 0:n.setTagName(e.slice(t,u))
case 5:case 6:case 7:c=7,n.closed=!0
case 4:case 1:case 2:break
default:throw new Error("attribute invalid close char('/')")}break
case"":return i.error("unexpected end of input"),0==c&&n.setTagName(e.slice(t,u)),u
case">":switch(c){case 0:n.setTagName(e.slice(t,u))
case 5:case 6:case 7:break
case 4:case 1:"/"===(s=e.slice(t,u)).slice(-1)&&(n.closed=!0,s=s.slice(0,-1))
case 2:
2===c&&(s=a),4==c?(i.warning('attribute "'+s+'" missed quot(")!!'),n.add(a,s.replace(/&#?\w+;/g,o),t)):("http://www.w3.org/1999/xhtml"===r[""]&&s.match(/^(?:disabled|checked|selected)$/i)||i.warning('attribute "'+s+'" missed value!! "'+s+'" instead!!'),
n.add(s,s,t))
break
case 3:throw new Error("attribute value missed!!")}return u
case"":l=" "
default:if(l<=" ")switch(c){case 0:n.setTagName(e.slice(t,u)),c=6
break
case 1:a=e.slice(t,u),c=2
break
case 4:var s=e.slice(t,u).replace(/&#?\w+;/g,o)
i.warning('attribute "'+s+'" missed quot(")!!'),n.add(a,s,t)
case 5:c=6}else switch(c){case 2:n.tagName
"http://www.w3.org/1999/xhtml"===r[""]&&a.match(/^(?:disabled|checked|selected)$/i)||i.warning('attribute "'+a+'" missed value!! "'+a+'" instead2!!'),n.add(a,a,t),t=u,c=1
break
case 5:i.warning('attribute space is required"'+a+'"!!')
case 6:c=1,t=u
break
case 3:c=4,t=u
break
case 7:throw new Error("elements closed character '/' and '>' must be connected to")}}u++}}function l(e,t,n){for(var r=e.tagName,o=null,i=e.length;i--;){
var a=e[i],u=a.qName,c=a.value
if((p=u.indexOf(":"))>0)var l=a.prefix=u.slice(0,p),s=u.slice(p+1),f="xmlns"===l&&s
else s=u,l=null,f="xmlns"===u&&""
a.localName=s,!1!==f&&(null==o&&(o={},d(n,n={})),n[f]=o[f]=c,a.uri="http://www.w3.org/2000/xmlns/",t.startPrefixMapping(f,c))}for(i=e.length;i--;){
(l=(a=e[i]).prefix)&&("xml"===l&&(a.uri="http://www.w3.org/XML/1998/namespace"),"xmlns"!==l&&(a.uri=n[l||""]))}var p;(p=r.indexOf(":"))>0?(l=e.prefix=r.slice(0,p),
s=e.localName=r.slice(p+1)):(l=null,s=e.localName=r)
var E=e.uri=n[l||""]
if(t.startElement(E,s,r,e),!e.closed)return e.currentNSMap=n,e.localNSMap=o,!0
if(t.endElement(E,s,r),o)for(l in o)t.endPrefixMapping(l)}function s(e,t,n,r,o){if(/^(?:script|textarea)$/i.test(n)){var i=e.indexOf("</"+n+">",t),a=e.substring(t+1,i)
if(/[&<]/.test(a))return/^script$/i.test(n)?(o.characters(a,0,a.length),i):(a=a.replace(/&#?\w+;/g,r),o.characters(a,0,a.length),i)}return t+1}function f(e,t,n,r){var o=r[n]
return null==o&&((o=e.lastIndexOf("</"+n+">"))<t&&(o=e.lastIndexOf("</"+n)),r[n]=o),o<t}function d(e,t){for(var n in e)t[n]=e[n]}function p(e,t,n,r){
if("-"===e.charAt(t+2))return"-"===e.charAt(t+3)?(o=e.indexOf("--\x3e",t+4))>t?(n.comment(e,t+4,o-t-4),o+3):(r.error("Unclosed comment"),-1):-1
if("CDATA["==e.substr(t+3,6)){var o=e.indexOf("]]>",t+9)
return n.startCDATA(),n.characters(e,t+9,o-t-9),n.endCDATA(),o+3}var i=function(e,t){var n,r=[],o=/'[^']+'|"[^"]+"|[^\s<>\/=]+=?|(\/?\s*>|<)/g
o.lastIndex=t,o.exec(e)
for(;n=o.exec(e);)if(r.push(n),n[1])return r}(e,t),a=i.length
if(a>1&&/!doctype/i.test(i[0][0])){var u=i[1][0],c=a>3&&/^public$/i.test(i[2][0])&&i[3][0],l=a>4&&i[4][0],s=i[a-1]
return n.startDTD(u,c&&c.replace(/^(['"])(.*?)\1$/,"$2"),l&&l.replace(/^(['"])(.*?)\1$/,"$2")),n.endDTD(),s.index+s[0].length}return-1}function E(e,t,n){var r=e.indexOf("?>",t)
if(r){var o=e.substring(t,r).match(/^<\?(\S*)\s*([\s\S]*?)\s*$/)
if(o){o[0].length
return n.processingInstruction(o[1],o[2]),r+2}return-1}return-1}function h(e){}a.prototype={parse:function(e,t,n){var r=this.domBuilder
r.startDocument(),d(t,t={}),function(e,t,n,r,o){function i(e){if(e>65535){var t=55296+((e-=65536)>>10),n=56320+(1023&e)
return String.fromCharCode(t,n)}return String.fromCharCode(e)}function a(e){var t=e.slice(1,-1)
return t in n?n[t]:"#"===t.charAt(0)?i(parseInt(t.substr(1).replace("x","0x"))):(o.error("entity not found:"+e),e)}function d(t){if(t>N){
var n=e.substring(N,t).replace(/&#?\w+;/g,a)
v&&m(N),r.characters(n,0,t-N),N=t}}function m(t,n){for(;t>=y&&(n=T.exec(e));)_=n.index,y=_+n[0].length,v.lineNumber++
v.columnNumber=t-_+1}var _=0,y=0,T=/.*(?:\r\n?|\n)|.*$/g,v=r.locator,b=[{currentNSMap:t}],g={},N=0
for(;;){try{var A=e.indexOf("<",N)
if(A<0){if(!e.substr(N).match(/^\s*$/)){var w=r.doc,R=w.createTextNode(e.substr(N))
w.appendChild(R),r.currentElement=R}return}switch(A>N&&d(A),e.charAt(A+1)){case"/":var O=e.indexOf(">",A+3),S=e.substring(A+2,O),I=b.pop()
O<0?(S=e.substring(A+2).replace(/[\s<].*/,""),o.error("end tag name: "+S+" is not complete:"+I.tagName),O=A+1+S.length):S.match(/\s</)&&(S=S.replace(/[\s<].*/,""),
o.error("end tag name: "+S+" maybe not complete"),O=A+1+S.length)
var M=I.localNSMap,C=I.tagName==S
if(C||I.tagName&&I.tagName.toLowerCase()==S.toLowerCase()){if(r.endElement(I.uri,I.localName,S),M)for(var P in M)r.endPrefixMapping(P)
C||o.fatalError("end tag name: "+S+" is not match the current start tagName:"+I.tagName)}else b.push(I)
O++
break
case"?":v&&m(A),O=E(e,A,r)
break
case"!":v&&m(A),O=p(e,A,r,o)
break
default:v&&m(A)
var L=new h,D=b[b.length-1].currentNSMap,x=(O=c(e,A,L,D,a,o),L.length)
if(!L.closed&&f(e,O,L.tagName,g)&&(L.closed=!0,n.nbsp||o.warning("unclosed xml attribute")),v&&x){for(var U=u(v,{}),F=0;F<x;F++){var j=L[F]
m(j.offset),j.locator=u(v,{})}r.locator=U,l(L,r,D)&&b.push(L),r.locator=v}else l(L,r,D)&&b.push(L)
"http://www.w3.org/1999/xhtml"!==L.uri||L.closed?O++:O=s(e,O,L.tagName,a,r)}}catch(e){o.error("element parse error: "+e),O=-1}O>N?N=O:d(Math.max(A,N)+1)}
}(e,t,n,r,this.errorHandler),r.endDocument()}},h.prototype={setTagName:function(e){if(!i.test(e))throw new Error("invalid tagName:"+e)
this.tagName=e},add:function(e,t,n){if(!i.test(e))throw new Error("invalid attribute:"+e)
this[this.length++]={qName:e,value:t,offset:n}},length:0,getLocalName:function(e){return this[e].localName},getLocator:function(e){return this[e].locator},getQName:function(e){
return this[e].qName},getURI:function(e){return this[e].uri},getValue:function(e){return this[e].value}},n.XMLReader=a},{}],5:[function(e,t,n){"use strict"
function r(e){return r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){
return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},r(e)}Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0
var o,i=(o=e("./HTMLAudioElement"))&&o.__esModule?o:{default:o}
function a(e,t){for(var n=0;n<t.length;n++){var r=t[n]
r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}function u(e,t){
return!t||"object"!==r(t)&&"function"!=typeof t?function(e){if(void 0===e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called")
return e}(e):t}function c(e,t,n){return c="undefined"!=typeof Reflect&&Reflect.get?Reflect.get:function(e,t,n){var r=function(e,t){
for(;!Object.prototype.hasOwnProperty.call(e,t)&&null!==(e=l(e)););return e}(e,t)
if(r){var o=Object.getOwnPropertyDescriptor(r,t)
return o.get?o.get.call(n):o.value}},c(e,t,n||e)}function l(e){return l=Object.setPrototypeOf?Object.getPrototypeOf:function(e){return e.__proto__||Object.getPrototypeOf(e)},l(e)}
function s(e,t){return s=Object.setPrototypeOf||function(e,t){return e.__proto__=t,e},s(e,t)}var f=1,d={},p=function(e){function t(e){var n
!function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,t),(n=u(this,l(t).call(this)))._$sn=f++,n.HAVE_NOTHING=0,n.HAVE_METADATA=1,
n.HAVE_CURRENT_DATA=2,n.HAVE_FUTURE_DATA=3,n.HAVE_ENOUGH_DATA=4,n.readyState=0
var r=wx.createInnerAudioContext()
return d[n._$sn]=r,n._canplayEvents=["load","loadend","canplay","canplaythrough","loadedmetadata"],r.onCanplay((function(){n._loaded=!0,n.readyState=n.HAVE_CURRENT_DATA,
n._canplayEvents.forEach((function(e){n.dispatchEvent({type:e})}))})),r.onPlay((function(){n._paused=d[n._$sn].paused,n.dispatchEvent({type:"play"})})),r.onPause((function(){
n._paused=d[n._$sn].paused,n.dispatchEvent({type:"pause"})})),r.onEnded((function(){n._paused=d[n._$sn].paused,!1===d[n._$sn].loop&&n.dispatchEvent({type:"ended"}),n.readyState=4
})),r.onError((function(){n._paused=d[n._$sn].paused,n.dispatchEvent({type:"error"})})),e?n.src=e:n._src="",n._loop=r.loop,n._autoplay=r.autoplay,n._paused=r.paused,
n._volume=r.volume,n._muted=!1,n}var n,r,o
return function(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function")
e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,writable:!0,configurable:!0}}),t&&s(e,t)}(t,e),n=t,r=[{key:"addEventListener",value:function(e,n){
var r=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{}
c(l(t.prototype),"addEventListener",this).call(this,e,n,r),e=String(e).toLowerCase(),this._loaded&&-1!==this._canplayEvents.indexOf(e)&&this.dispatchEvent({type:e})}},{key:"load",
value:function(){}},{key:"play",value:function(){d[this._$sn].play()}},{key:"resume",value:function(){d[this._$sn].resume()}},{key:"pause",value:function(){d[this._$sn].pause()}},{
key:"stop",value:function(){d[this._$sn].stop()}},{key:"destroy",value:function(){d[this._$sn].destroy()}},{key:"canPlayType",value:function(){
var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:""
return"string"!=typeof e?"":e.indexOf("audio/mpeg")>-1||e.indexOf("audio/mp4")?"probably":""}},{key:"cloneNode",value:function(){var e=new t
return e.loop=this.loop,e.autoplay=this.autoplay,e.src=this.src,e}},{key:"currentTime",get:function(){return d[this._$sn].currentTime},set:function(e){d[this._$sn].seek(e)}},{
key:"duration",get:function(){return d[this._$sn].duration}},{key:"src",get:function(){return this._src},set:function(e){this._src=e,this._loaded=!1,
this.readyState=this.HAVE_NOTHING,d[this._$sn].src=e}},{key:"loop",get:function(){return this._loop},set:function(e){this._loop=e,d[this._$sn].loop=e}},{key:"autoplay",
get:function(){return this.autoplay},set:function(e){this._autoplay=e,d[this._$sn].autoplay=e}},{key:"paused",get:function(){return this._paused}},{key:"volume",get:function(){
return this._volume},set:function(e){this._volume=e,this._muted||(d[this._$sn].volume=e)}},{key:"muted",get:function(){return this._muted},set:function(e){this._muted=e,
d[this._$sn].volume=e?0:this._volume}}],r&&a(n.prototype,r),o&&a(n,o),t}(i.default)
n.default=p},{"./HTMLAudioElement":13}],6:[function(e,t,n){"use strict"
Object.defineProperty(n,"__esModule",{value:!0}),n.default=function(){var e=wx.createCanvas()
e.type="canvas"
e.getContext
return e.getBoundingClientRect=function(){return{top:0,left:0,width:window.innerWidth,height:window.innerHeight}},e.style={top:"0px",left:"0px",width:r.innerWidth+"px",
height:r.innerHeight+"px"},e.addEventListener=function(e,t){var n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{}
document.addEventListener(e,t,n)},e.removeEventListener=function(e,t){document.removeEventListener(e,t)},e.dispatchEvent=function(){
var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{}
console.log("canvas.dispatchEvent",e.type,e)},Object.defineProperty(e,"clientWidth",{enumerable:!0,get:function(){return r.innerWidth}}),Object.defineProperty(e,"clientHeight",{
enumerable:!0,get:function(){return r.innerHeight}}),e}
var r=e("./WindowProperties")},{"./WindowProperties":24}],7:[function(e,t,n){"use strict"
function r(e){return r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){
return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},r(e)}var o
function i(e){return i=Object.setPrototypeOf?Object.getPrototypeOf:function(e){return e.__proto__||Object.getPrototypeOf(e)},i(e)}function a(e){
if(void 0===e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called")
return e}function u(e,t){return u=Object.setPrototypeOf||function(e,t){return e.__proto__=t,e},u(e,t)}function c(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,
enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0
var l=function(e){function t(){var e,n,o
return function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,t),n=this,
e=!(o=i(t).call(this))||"object"!==r(o)&&"function"!=typeof o?a(n):o,c(a(e),"className",""),c(a(e),"children",[]),e}return function(e,t){
if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function")
e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,writable:!0,configurable:!0}}),t&&u(e,t)}(t,e),t}(((o=e("./Node"))&&o.__esModule?o:{default:o}).default)
n.default=l},{"./Node":21}],8:[function(e,t,n){"use strict"
Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0
n.default=function e(){!function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,e)}},{}],9:[function(e,t,n){"use strict"
Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0
var r=e("../util/index.js")
function o(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var i=function e(t){!function(e,t){
if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,e),o(this,"touches",[]),o(this,"targetTouches",[]),o(this,"changedTouches",[]),
o(this,"preventDefault",r.noop),o(this,"stopPropagation",r.noop),this.type=t,this.target=window.canvas,this.currentTarget=window.canvas}
function a(e){return function(t){var n=new i(e)
n.touches=t.touches,n.targetTouches=Array.prototype.slice.call(t.touches),n.changedTouches=t.changedTouches,n.timeStamp=t.timeStamp,document.dispatchEvent(n)}}n.default=i,
wx.onTouchStart(a("touchstart")),wx.onTouchMove(a("touchmove")),wx.onTouchEnd(a("touchend")),wx.onTouchCancel(a("touchcancel"))},{"../util/index.js":31}],10:[function(e,t,n){
"use strict"
Object.defineProperty(n,"__esModule",{value:!0}),Object.defineProperty(n,"TouchEvent",{enumerable:!0,get:function(){return r.default}}),Object.defineProperty(n,"MouseEvent",{
enumerable:!0,get:function(){return o.default}})
var r=i(e("./TouchEvent")),o=i(e("./MouseEvent"))
function i(e){return e&&e.__esModule?e:{default:e}}},{"./MouseEvent":8,"./TouchEvent":9}],11:[function(e,t,n){"use strict"
function r(e,t){for(var n=0;n<t.length;n++){var r=t[n]
r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0
var o=new WeakMap,i=function(){function e(){!function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,e),o.set(this,{})}var t,n,i
return t=e,n=[{key:"addEventListener",value:function(e,t){var n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{},r=o.get(this)
r||(r={},o.set(this,r)),r[e]||(r[e]=[]),r[e].push(t),n.capture,n.once,n.passive}},{key:"removeEventListener",value:function(e,t){var n=o.get(this)
if(n){var r=n[e]
if(r&&r.length>0)for(var i=r.length;i--;i>0)if(r[i]===t){r.splice(i,1)
break}}}},{key:"dispatchEvent",value:function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},t=o.get(this)[e.type]
if(t)for(var n=0;n<t.length;n++)t[n](e)}}],n&&r(t.prototype,n),i&&r(t,i),e}()
n.default=i},{}],12:[function(e,t,n){"use strict"
function r(e,t){for(var n=0;n<t.length;n++){var r=t[n]
r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0
var o=function(){function e(){!function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,e)}var t,n,o
return t=e,(n=[{key:"construct",value:function(){}}])&&r(t.prototype,n),o&&r(t,o),e}()
n.default=o},{}],13:[function(e,t,n){"use strict"
function r(e){return r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){
return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},r(e)}var o
function i(e,t){return!t||"object"!==r(t)&&"function"!=typeof t?function(e){if(void 0===e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called")
return e}(e):t}function a(e){return a=Object.setPrototypeOf?Object.getPrototypeOf:function(e){return e.__proto__||Object.getPrototypeOf(e)},a(e)}function u(e,t){
return u=Object.setPrototypeOf||function(e,t){return e.__proto__=t,e},u(e,t)}Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0
var c=function(e){function t(){return function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,t),i(this,a(t).call(this,"audio"))}
return function(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function")
e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,writable:!0,configurable:!0}}),t&&u(e,t)}(t,e),t}(((o=e("./HTMLMediaElement"))&&o.__esModule?o:{default:o}).default)
n.default=c},{"./HTMLMediaElement":17}],14:[function(e,t,n){"use strict"
Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0
var r,o=(r=e("./Canvas"))&&r.__esModule?r:{default:r}
GameGlobal.screencanvas=GameGlobal.screencanvas||new o.default
var i=GameGlobal.screencanvas.constructor
n.default=i},{"./Canvas":6}],15:[function(e,t,n){"use strict"
function r(e){return r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){
return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},r(e)}Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0
var o,i=(o=e("./Element"))&&o.__esModule?o:{default:o},a=e("./util/index.js"),u=e("./WindowProperties")
function c(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function l(e,t){for(var n=0;n<t.length;n++){var r=t[n]
r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}function s(e,t){
return!t||"object"!==r(t)&&"function"!=typeof t?d(e):t}function f(e){return f=Object.setPrototypeOf?Object.getPrototypeOf:function(e){return e.__proto__||Object.getPrototypeOf(e)},
f(e)}function d(e){if(void 0===e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called")
return e}function p(e,t){return p=Object.setPrototypeOf||function(e,t){return e.__proto__=t,e},p(e,t)}function E(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,
enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var h=function(e){function t(){var e,n=arguments.length>0&&void 0!==arguments[0]?arguments[0]:""
return c(this,t),E(d(e=s(this,f(t).call(this))),"className",""),E(d(e),"childern",[]),E(d(e),"style",{width:"".concat(u.innerWidth,"px"),height:"".concat(u.innerHeight,"px")}),
E(d(e),"insertBefore",a.noop),E(d(e),"innerHTML",""),e.tagName=n.toUpperCase(),e}var n,r,o
return function(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function")
e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,writable:!0,configurable:!0}}),t&&p(e,t)}(t,e),n=t,(r=[{key:"setAttribute",value:function(e,t){this[e]=t}},{
key:"getAttribute",value:function(e){return this[e]}},{key:"getBoundingClientRect",value:function(){return{top:0,left:0,width:u.innerWidth,height:u.innerHeight}}},{key:"focus",
value:function(){}},{key:"clientWidth",get:function(){var e=parseInt(this.style.fontSize,10)*this.innerHTML.length
return Number.isNaN(e)?0:e}},{key:"clientHeight",get:function(){var e=parseInt(this.style.fontSize,10)
return Number.isNaN(e)?0:e}}])&&l(n.prototype,r),o&&l(n,o),t}(i.default)
n.default=h},{"./Element":7,"./WindowProperties":24,"./util/index.js":31}],16:[function(e,t,n){"use strict"
Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0
var r=wx.createImage().constructor
n.default=r},{}],17:[function(e,t,n){"use strict"
function r(e){return r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){
return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},r(e)}var o
function i(e,t){for(var n=0;n<t.length;n++){var r=t[n]
r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}function a(e,t){
return!t||"object"!==r(t)&&"function"!=typeof t?function(e){if(void 0===e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called")
return e}(e):t}function u(e){return u=Object.setPrototypeOf?Object.getPrototypeOf:function(e){return e.__proto__||Object.getPrototypeOf(e)},u(e)}function c(e,t){
return c=Object.setPrototypeOf||function(e,t){return e.__proto__=t,e},c(e,t)}Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0
var l=function(e){function t(e){return function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,t),a(this,u(t).call(this,e))}var n,r,o
return function(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function")
e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,writable:!0,configurable:!0}}),t&&c(e,t)}(t,e),n=t,(r=[{key:"addTextTrack",value:function(){}},{key:"captureStream",
value:function(){}},{key:"fastSeek",value:function(){}},{key:"load",value:function(){}},{key:"pause",value:function(){}},{key:"play",value:function(){}}])&&i(n.prototype,r),
o&&i(n,o),t}(((o=e("./HTMLElement"))&&o.__esModule?o:{default:o}).default)
n.default=l},{"./HTMLElement":15}],18:[function(e,t,n){"use strict"
function r(e){return r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){
return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},r(e)}var o
function i(e,t){return!t||"object"!==r(t)&&"function"!=typeof t?function(e){if(void 0===e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called")
return e}(e):t}function a(e){return a=Object.setPrototypeOf?Object.getPrototypeOf:function(e){return e.__proto__||Object.getPrototypeOf(e)},a(e)}function u(e,t){
return u=Object.setPrototypeOf||function(e,t){return e.__proto__=t,e},u(e,t)}Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0
var c=function(e){function t(){return function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,t),i(this,a(t).call(this,"video"))}
return function(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function")
e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,writable:!0,configurable:!0}}),t&&u(e,t)}(t,e),t}(((o=e("./HTMLMediaElement"))&&o.__esModule?o:{default:o}).default)
n.default=c},{"./HTMLMediaElement":17}],19:[function(e,t,n){"use strict"
Object.defineProperty(n,"__esModule",{value:!0}),n.default=function(){var e=wx.createImage()
return e.premultiplyAlpha=!1,e}},{}],20:[function(e,t,n){"use strict"
Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0
n.default=function e(){!function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,e)}},{}],21:[function(e,t,n){"use strict"
function r(e){return r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){
return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},r(e)}var o
function i(e,t){for(var n=0;n<t.length;n++){var r=t[n]
r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}function a(e){
return a=Object.setPrototypeOf?Object.getPrototypeOf:function(e){return e.__proto__||Object.getPrototypeOf(e)},a(e)}function u(e){
if(void 0===e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called")
return e}function c(e,t){return c=Object.setPrototypeOf||function(e,t){return e.__proto__=t,e},c(e,t)}Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0
var l=function(e){function t(){var e,n,o
return function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,t),n=this,
e=!(o=a(t).call(this))||"object"!==r(o)&&"function"!=typeof o?u(n):o,function(e,t,n){t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n
}(u(e),"childNodes",[]),e}var n,o,l
return function(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function")
e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,writable:!0,configurable:!0}}),t&&c(e,t)}(t,e),n=t,(o=[{key:"appendChild",value:function(e){this.childNodes.push(e)}
},{key:"cloneNode",value:function(){var e=Object.create(this)
return Object.assign(e,this),e}},{key:"removeChild",value:function(e){var t=this.childNodes.findIndex((function(t){return t===e}))
return t>-1?this.childNodes.splice(t,1):null}}])&&i(n.prototype,o),l&&i(n,l),t}(((o=e("./EventTarget.js"))&&o.__esModule?o:{default:o}).default)
n.default=l},{"./EventTarget.js":11}],22:[function(e,t,n){"use strict"
Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0
var r=function e(){!function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,e)}
n.default=r,r.ACTIVE_ATTRIBUTES=35721,r.ACTIVE_TEXTURE=34016,r.ACTIVE_UNIFORMS=35718,r.ALIASED_LINE_WIDTH_RANGE=33902,r.ALIASED_POINT_SIZE_RANGE=33901,r.ALPHA=6406,
r.ALPHA_BITS=3413,r.ALWAYS=519,r.ARRAY_BUFFER=34962,r.ARRAY_BUFFER_BINDING=34964,r.ATTACHED_SHADERS=35717,r.BACK=1029,r.BLEND=3042,r.BLEND_COLOR=32773,r.BLEND_DST_ALPHA=32970,
r.BLEND_DST_RGB=32968,r.BLEND_EQUATION=32777,r.BLEND_EQUATION_ALPHA=34877,r.BLEND_EQUATION_RGB=32777,r.BLEND_SRC_ALPHA=32971,r.BLEND_SRC_RGB=32969,r.BLUE_BITS=3412,r.BOOL=35670,
r.BOOL_VEC2=35671,r.BOOL_VEC3=35672,r.BOOL_VEC4=35673,r.BROWSER_DEFAULT_WEBGL=37444,r.BUFFER_SIZE=34660,r.BUFFER_USAGE=34661,r.BYTE=5120,r.CCW=2305,r.CLAMP_TO_EDGE=33071,
r.COLOR_ATTACHMENT0=36064,r.COLOR_BUFFER_BIT=16384,r.COLOR_CLEAR_VALUE=3106,r.COLOR_WRITEMASK=3107,r.COMPILE_STATUS=35713,r.COMPRESSED_TEXTURE_FORMATS=34467,r.CONSTANT_ALPHA=32771,
r.CONSTANT_COLOR=32769,r.CONTEXT_LOST_WEBGL=37442,r.CULL_FACE=2884,r.CULL_FACE_MODE=2885,r.CURRENT_PROGRAM=35725,r.CURRENT_VERTEX_ATTRIB=34342,r.CW=2304,r.DECR=7683,
r.DECR_WRAP=34056,r.DELETE_STATUS=35712,r.DEPTH_ATTACHMENT=36096,r.DEPTH_BITS=3414,r.DEPTH_BUFFER_BIT=256,r.DEPTH_CLEAR_VALUE=2931,r.DEPTH_COMPONENT=6402,r.DEPTH_COMPONENT16=33189,
r.DEPTH_FUNC=2932,r.DEPTH_RANGE=2928,r.DEPTH_STENCIL=34041,r.DEPTH_STENCIL_ATTACHMENT=33306,r.DEPTH_TEST=2929,r.DEPTH_WRITEMASK=2930,r.DITHER=3024,r.DONT_CARE=4352,r.DST_ALPHA=772,
r.DST_COLOR=774,r.DYNAMIC_DRAW=35048,r.ELEMENT_ARRAY_BUFFER=34963,r.ELEMENT_ARRAY_BUFFER_BINDING=34965,r.EQUAL=514,r.FASTEST=4353,r.FLOAT=5126,r.FLOAT_MAT2=35674,
r.FLOAT_MAT3=35675,r.FLOAT_MAT4=35676,r.FLOAT_VEC2=35664,r.FLOAT_VEC3=35665,r.FLOAT_VEC4=35666,r.FRAGMENT_SHADER=35632,r.FRAMEBUFFER=36160,
r.FRAMEBUFFER_ATTACHMENT_OBJECT_NAME=36049,r.FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE=36048,r.FRAMEBUFFER_ATTACHMENT_TEXTURE_CUBE_MAP_FACE=36051,
r.FRAMEBUFFER_ATTACHMENT_TEXTURE_LEVEL=36050,r.FRAMEBUFFER_BINDING=36006,r.FRAMEBUFFER_COMPLETE=36053,r.FRAMEBUFFER_INCOMPLETE_ATTACHMENT=36054,
r.FRAMEBUFFER_INCOMPLETE_DIMENSIONS=36057,r.FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT=36055,r.FRAMEBUFFER_UNSUPPORTED=36061,r.FRONT=1028,r.FRONT_AND_BACK=1032,r.FRONT_FACE=2886,
r.FUNC_ADD=32774,r.FUNC_REVERSE_SUBTRACT=32779,r.FUNC_SUBTRACT=32778,r.GENERATE_MIPMAP_HINT=33170,r.GEQUAL=518,r.GREATER=516,r.GREEN_BITS=3411,r.HIGH_FLOAT=36338,r.HIGH_INT=36341,
r.IMPLEMENTATION_COLOR_READ_FORMAT=35739,r.IMPLEMENTATION_COLOR_READ_TYPE=35738,r.INCR=7682,r.INCR_WRAP=34055,r.INT=5124,r.INT_VEC2=35667,r.INT_VEC3=35668,r.INT_VEC4=35669,
r.INVALID_ENUM=1280,r.INVALID_FRAMEBUFFER_OPERATION=1286,r.INVALID_OPERATION=1282,r.INVALID_VALUE=1281,r.INVERT=5386,r.KEEP=7680,r.LEQUAL=515,r.LESS=513,r.LINEAR=9729,
r.LINEAR_MIPMAP_LINEAR=9987,r.LINEAR_MIPMAP_NEAREST=9985,r.LINES=1,r.LINE_LOOP=2,r.LINE_STRIP=3,r.LINE_WIDTH=2849,r.LINK_STATUS=35714,r.LOW_FLOAT=36336,r.LOW_INT=36339,
r.LUMINANCE=6409,r.LUMINANCE_ALPHA=6410,r.MAX_COMBINED_TEXTURE_IMAGE_UNITS=35661,r.MAX_CUBE_MAP_TEXTURE_SIZE=34076,r.MAX_FRAGMENT_UNIFORM_VECTORS=36349,
r.MAX_RENDERBUFFER_SIZE=34024,r.MAX_TEXTURE_IMAGE_UNITS=34930,r.MAX_TEXTURE_SIZE=3379,r.MAX_VARYING_VECTORS=36348,r.MAX_VERTEX_ATTRIBS=34921,r.MAX_VERTEX_TEXTURE_IMAGE_UNITS=35660,
r.MAX_VERTEX_UNIFORM_VECTORS=36347,r.MAX_VIEWPORT_DIMS=3386,r.MEDIUM_FLOAT=36337,r.MEDIUM_INT=36340,r.MIRRORED_REPEAT=33648,r.NEAREST=9728,r.NEAREST_MIPMAP_LINEAR=9986,
r.NEAREST_MIPMAP_NEAREST=9984,r.NEVER=512,r.NICEST=4354,r.NONE=0,r.NOTEQUAL=517,r.NO_ERROR=0,r.ONE=1,r.ONE_MINUS_CONSTANT_ALPHA=32772,r.ONE_MINUS_CONSTANT_COLOR=32770,
r.ONE_MINUS_DST_ALPHA=773,r.ONE_MINUS_DST_COLOR=775,r.ONE_MINUS_SRC_ALPHA=771,r.ONE_MINUS_SRC_COLOR=769,r.OUT_OF_MEMORY=1285,r.PACK_ALIGNMENT=3333,r.POINTS=0,
r.POLYGON_OFFSET_FACTOR=32824,r.POLYGON_OFFSET_FILL=32823,r.POLYGON_OFFSET_UNITS=10752,r.RED_BITS=3410,r.RENDERBUFFER=36161,r.RENDERBUFFER_ALPHA_SIZE=36179,
r.RENDERBUFFER_BINDING=36007,r.RENDERBUFFER_BLUE_SIZE=36178,r.RENDERBUFFER_DEPTH_SIZE=36180,r.RENDERBUFFER_GREEN_SIZE=36177,r.RENDERBUFFER_HEIGHT=36163,
r.RENDERBUFFER_INTERNAL_FORMAT=36164,r.RENDERBUFFER_RED_SIZE=36176,r.RENDERBUFFER_STENCIL_SIZE=36181,r.RENDERBUFFER_WIDTH=36162,r.RENDERER=7937,r.REPEAT=10497,r.REPLACE=7681,
r.RGB=6407,r.RGB5_A1=32855,r.RGB565=36194,r.RGBA=6408,r.RGBA4=32854,r.SAMPLER_2D=35678,r.SAMPLER_CUBE=35680,r.SAMPLES=32937,r.SAMPLE_ALPHA_TO_COVERAGE=32926,r.SAMPLE_BUFFERS=32936,
r.SAMPLE_COVERAGE=32928,r.SAMPLE_COVERAGE_INVERT=32939,r.SAMPLE_COVERAGE_VALUE=32938,r.SCISSOR_BOX=3088,r.SCISSOR_TEST=3089,r.SHADER_TYPE=35663,r.SHADING_LANGUAGE_VERSION=35724,
r.SHORT=5122,r.SRC_ALPHA=770,r.SRC_ALPHA_SATURATE=776,r.SRC_COLOR=768,r.STATIC_DRAW=35044,r.STENCIL_ATTACHMENT=36128,r.STENCIL_BACK_FAIL=34817,r.STENCIL_BACK_FUNC=34816,
r.STENCIL_BACK_PASS_DEPTH_FAIL=34818,r.STENCIL_BACK_PASS_DEPTH_PASS=34819,r.STENCIL_BACK_REF=36003,r.STENCIL_BACK_VALUE_MASK=36004,r.STENCIL_BACK_WRITEMASK=36005,
r.STENCIL_BITS=3415,r.STENCIL_BUFFER_BIT=1024,r.STENCIL_CLEAR_VALUE=2961,r.STENCIL_FAIL=2964,r.STENCIL_FUNC=2962,r.STENCIL_INDEX8=36168,r.STENCIL_PASS_DEPTH_FAIL=2965,
r.STENCIL_PASS_DEPTH_PASS=2966,r.STENCIL_REF=2967,r.STENCIL_TEST=2960,r.STENCIL_VALUE_MASK=2963,r.STENCIL_WRITEMASK=2968,r.STREAM_DRAW=35040,r.SUBPIXEL_BITS=3408,r.TEXTURE=5890,
r.TEXTURE0=33984,r.TEXTURE1=33985,r.TEXTURE2=33986,r.TEXTURE3=33987,r.TEXTURE4=33988,r.TEXTURE5=33989,r.TEXTURE6=33990,r.TEXTURE7=33991,r.TEXTURE8=33992,r.TEXTURE9=33993,
r.TEXTURE10=33994,r.TEXTURE11=33995,r.TEXTURE12=33996,r.TEXTURE13=33997,r.TEXTURE14=33998,r.TEXTURE15=33999,r.TEXTURE16=34e3,r.TEXTURE17=34001,r.TEXTURE18=34002,r.TEXTURE19=34003,
r.TEXTURE20=34004,r.TEXTURE21=34005,r.TEXTURE22=34006,r.TEXTURE23=34007,r.TEXTURE24=34008,r.TEXTURE25=34009,r.TEXTURE26=34010,r.TEXTURE27=34011,r.TEXTURE28=34012,r.TEXTURE29=34013,
r.TEXTURE30=34014,r.TEXTURE31=34015,r.TEXTURE_2D=3553,r.TEXTURE_BINDING_2D=32873,r.TEXTURE_BINDING_CUBE_MAP=34068,r.TEXTURE_CUBE_MAP=34067,r.TEXTURE_CUBE_MAP_NEGATIVE_X=34070,
r.TEXTURE_CUBE_MAP_NEGATIVE_Y=34072,r.TEXTURE_CUBE_MAP_NEGATIVE_Z=34074,r.TEXTURE_CUBE_MAP_POSITIVE_X=34069,r.TEXTURE_CUBE_MAP_POSITIVE_Y=34071,r.TEXTURE_CUBE_MAP_POSITIVE_Z=34073,
r.TEXTURE_MAG_FILTER=10240,r.TEXTURE_MIN_FILTER=10241,r.TEXTURE_WRAP_S=10242,r.TEXTURE_WRAP_T=10243,r.TRIANGLES=4,r.TRIANGLE_FAN=6,r.TRIANGLE_STRIP=5,r.UNPACK_ALIGNMENT=3317,
r.UNPACK_COLORSPACE_CONVERSION_WEBGL=37443,r.UNPACK_FLIP_Y_WEBGL=37440,r.UNPACK_PREMULTIPLY_ALPHA_WEBGL=37441,r.UNSIGNED_BYTE=5121,r.UNSIGNED_INT=5125,r.UNSIGNED_SHORT=5123,
r.UNSIGNED_SHORT_4_4_4_4=32819,r.UNSIGNED_SHORT_5_5_5_1=32820,r.UNSIGNED_SHORT_5_6_5=33635,r.VALIDATE_STATUS=35715,r.VENDOR=7936,r.VERSION=7938,
r.VERTEX_ATTRIB_ARRAY_BUFFER_BINDING=34975,r.VERTEX_ATTRIB_ARRAY_ENABLED=34338,r.VERTEX_ATTRIB_ARRAY_NORMALIZED=34922,r.VERTEX_ATTRIB_ARRAY_POINTER=34373,
r.VERTEX_ATTRIB_ARRAY_SIZE=34339,r.VERTEX_ATTRIB_ARRAY_STRIDE=34340,r.VERTEX_ATTRIB_ARRAY_TYPE=34341,r.VERTEX_SHADER=35633,r.VIEWPORT=2978,r.ZERO=0},{}],23:[function(e,t,n){
"use strict"
function r(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function o(e,t){for(var n=0;n<t.length;n++){var r=t[n]
r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}function i(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,
enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0
var a=new WeakMap,u=function(){function e(t){var n=this,o=arguments.length>1&&void 0!==arguments[1]?arguments[1]:[]
if(r(this,e),i(this,"binaryType",""),i(this,"bufferedAmount",0),i(this,"extensions",""),i(this,"onclose",null),i(this,"onerror",null),i(this,"onmessage",null),
i(this,"onopen",null),
i(this,"protocol",""),i(this,"readyState",3),"string"!=typeof t||!/(^ws:\/\/)|(^wss:\/\/)/.test(t))throw new TypeError("Failed to construct 'WebSocket': The URL '".concat(t,"' is invalid"))
this.url=t,this.readyState=e.CONNECTING
var u=wx.connectSocket({url:t,protocols:Array.isArray(o)?o:[o],tcpNoDelay:!0})
return a.set(this,u),u.onClose((function(t){n.readyState=e.CLOSED,"function"==typeof n.onclose&&n.onclose(t)})),u.onMessage((function(e){
"function"==typeof n.onmessage&&n.onmessage(e)})),u.onOpen((function(){n.readyState=e.OPEN,"function"==typeof n.onopen&&n.onopen()})),u.onError((function(e){
"function"==typeof n.onerror&&n.onerror(new Error(e.errMsg))})),this}var t,n,u
return t=e,(n=[{key:"close",value:function(t,n){this.readyState=e.CLOSING,a.get(this).close({code:t,reason:n})}},{key:"send",value:function(e){
if(!("string"==typeof e||e instanceof ArrayBuffer||ArrayBuffer.isView(e)))throw new TypeError("Failed to send message: The data ".concat(e," is invalid"))
a.get(this).send({data:e})}}])&&o(t.prototype,n),u&&o(t,u),e}()
n.default=u,i(u,"CONNECTING",0),i(u,"OPEN",1),i(u,"CLOSING",2),i(u,"CLOSED",3)},{}],24:[function(e,t,n){"use strict"
Object.defineProperty(n,"__esModule",{value:!0}),n.ontouchend=n.ontouchmove=n.ontouchstart=n.performance=n.screen=n.devicePixelRatio=n.innerHeight=n.innerWidth=void 0
var r=wx.getSystemInfoSync(),o=r.screenWidth,i=r.screenHeight,a=r.devicePixelRatio
n.devicePixelRatio=a
var u=o
n.innerWidth=u
var c=i
n.innerHeight=c
var l={width:o,height:i,availWidth:u,availHeight:c,availLeft:0,availTop:0}
n.screen=l
var s={now:Date.now}
n.performance=s
n.ontouchstart=null
n.ontouchmove=null
n.ontouchend=null},{}],25:[function(e,t,n){"use strict"
function r(e){return r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){
return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},r(e)}Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0
var o,i=(o=e("./EventTarget.js"))&&o.__esModule?o:{default:o}
function a(e,t){for(var n=0;n<t.length;n++){var r=t[n]
r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}function u(e){
return u=Object.setPrototypeOf?Object.getPrototypeOf:function(e){return e.__proto__||Object.getPrototypeOf(e)},u(e)}function c(e){
if(void 0===e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called")
return e}function l(e,t){return l=Object.setPrototypeOf||function(e,t){return e.__proto__=t,e},l(e,t)}function s(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,
enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var f=new WeakMap,d=new WeakMap,p=new WeakMap,E=new WeakMap,h=new WeakMap
function m(e){if("function"==typeof this["on".concat(e)]){for(var t=arguments.length,n=new Array(t>1?t-1:0),r=1;r<t;r++)n[r-1]=arguments[r]
this["on".concat(e)].apply(this,n)}}function _(e){this.readyState=e,m.call(this,"readystatechange")}var y=function(e){function t(){var e,n,o
return function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,t),n=this,
e=!(o=u(t).call(this))||"object"!==r(o)&&"function"!=typeof o?c(n):o,s(c(e),"timeout",0),s(c(e),"onabort",null),s(c(e),"onerror",null),s(c(e),"onload",null),
s(c(e),"onloadstart",null),s(c(e),"onprogress",null),s(c(e),"ontimeout",null),s(c(e),"onloadend",null),s(c(e),"onreadystatechange",null),s(c(e),"readyState",0),
s(c(e),"response",null),s(c(e),"responseText",null),s(c(e),"responseType",""),s(c(e),"responseXML",null),s(c(e),"status",0),s(c(e),"statusText",""),s(c(e),"upload",{}),
s(c(e),"withCredentials",!1),p.set(c(e),{"content-type":"application/x-www-form-urlencoded"}),E.set(c(e),{}),e}var n,o,i
return function(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function")
e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,writable:!0,configurable:!0}}),t&&l(e,t)}(t,e),n=t,o=[{key:"abort",value:function(){var e=h.get(this)
e&&e.abort()}},{key:"getAllResponseHeaders",value:function(){var e=E.get(this)
return Object.keys(e).map((function(t){return"".concat(t,": ").concat(e[t])})).join("\n")}},{key:"getResponseHeader",value:function(e){return E.get(this)[e]}},{key:"open",
value:function(e,n){d.set(this,e),f.set(this,n),_.call(this,t.OPENED)}},{key:"overrideMimeType",value:function(){}},{key:"send",value:function(){
var e=this,n=arguments.length>0&&void 0!==arguments[0]?arguments[0]:""
if(this.readyState!==t.OPENED)throw new Error("Failed to execute 'send' on 'XMLHttpRequest': The object's state must be OPENED.")
var r=wx.request({data:n,url:f.get(this),method:d.get(this),header:p.get(this),dataType:"other",responseType:"arraybuffer"===this.responseType?"arraybuffer":"text",
timeout:this.timeout||void 0,success:function(n){var r=n.data,o=n.statusCode,i=n.header
switch(e.status=o,E.set(e,i),m.call(e,"loadstart"),_.call(e,t.HEADERS_RECEIVED),_.call(e,t.LOADING),e.responseType){case"json":e.responseText=r
try{e.response=JSON.parse(r)}catch(t){e.response=null}break
case"":case"text":e.responseText=e.response=r
break
case"arraybuffer":e.response=r,e.responseText=""
for(var a=new Uint8Array(r),u=a.byteLength,c=0;c<u;c++)e.responseText+=String.fromCharCode(a[c])
break
default:e.response=null}_.call(e,t.DONE),m.call(e,"load"),m.call(e,"loadend")},fail:function(t){var n=t.errMsg
;-1!==n.indexOf("abort")?m.call(e,"abort"):-1!==n.indexOf("timeout")?m.call(e,"timeout"):m.call(e,"error",n),m.call(e,"loadend")}})
h.set(this,r)}},{key:"setRequestHeader",value:function(e,t){var n=p.get(this)
n[e]=t,p.set(this,n)}},{key:"addEventListener",value:function(e,t){if("function"==typeof t){var n=this
this["on"+e]=function(e){t.call(n,e)}}}}],o&&a(n.prototype,o),i&&a(n,i),t}(i.default)
n.default=y,s(y,"UNSEND",0),s(y,"OPENED",1),s(y,"HEADERS_RECEIVED",2),s(y,"LOADING",3),s(y,"DONE",4)},{"./EventTarget.js":11}],26:[function(e,t,n){"use strict"
function r(e){return r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){
return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},r(e)}Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0
var o=function(e){if(e&&e.__esModule)return e
if(null===e||"object"!==r(e)&&"function"!=typeof e)return{default:e}
var t=f()
if(t&&t.has(e))return t.get(e)
var n={},o=Object.defineProperty&&Object.getOwnPropertyDescriptor
for(var i in e)if(Object.prototype.hasOwnProperty.call(e,i)){var a=o?Object.getOwnPropertyDescriptor(e,i):null
a&&(a.get||a.set)?Object.defineProperty(n,i,a):n[i]=e[i]}n.default=e,t&&t.set(e,n)
return n}(e("./window")),i=s(e("./HTMLElement")),a=s(e("./HTMLVideoElement")),u=s(e("./Image")),c=s(e("./Audio")),l=s(e("./Canvas"))
function s(e){return e&&e.__esModule?e:{default:e}}function f(){if("function"!=typeof WeakMap)return null
var e=new WeakMap
return f=function(){return e},e}e("./EventIniter/index.js")
var d={},p={readyState:"complete",visibilityState:"visible",documentElement:o,hidden:!1,style:{},location:o.location,ontouchstart:null,ontouchmove:null,ontouchend:null,
head:new i.default("head"),body:new i.default("body"),createElement:function(e){
return"canvas"===e?new l.default:"audio"===e?new c.default:"img"===e?new u.default:"video"===e?new a.default:new i.default(e)},createElementNS:function(e,t){
return this.createElement(t)},getElementById:function(e){return e===o.canvas.id?o.canvas:null},getElementsByTagName:function(e){
return"head"===e?[p.head]:"body"===e?[p.body]:"canvas"===e?[o.canvas]:[]},getElementsByName:function(e){return"head"===e?[p.head]:"body"===e?[p.body]:"canvas"===e?[o.canvas]:[]},
querySelector:function(e){return"head"===e?p.head:"body"===e?p.body:"canvas"===e||e==="#".concat(o.canvas.id)?o.canvas:null},querySelectorAll:function(e){
return"head"===e?[p.head]:"body"===e?[p.body]:"canvas"===e?[o.canvas]:[]},addEventListener:function(e,t){d[e]||(d[e]=[]),d[e].push(t)},removeEventListener:function(e,t){var n=d[e]
if(n&&n.length>0)for(var r=n.length;r--;r>0)if(n[r]===t){n.splice(r,1)
break}},dispatchEvent:function(e){var t=d[e.type]
if(t)for(var n=0;n<t.length;n++)t[n](e)}},E=p
n.default=E},{"./Audio":5,"./Canvas":6,"./EventIniter/index.js":10,"./HTMLElement":15,"./HTMLVideoElement":18,"./Image":19,"./window":32}],27:[function(e,t,n){"use strict"
function r(e){return r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){
return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},r(e)}var o,i=function(e){if(e&&e.__esModule)return e
if(null===e||"object"!==r(e)&&"function"!=typeof e)return{default:e}
var t=u()
if(t&&t.has(e))return t.get(e)
var n={},o=Object.defineProperty&&Object.getOwnPropertyDescriptor
for(var i in e)if(Object.prototype.hasOwnProperty.call(e,i)){var a=o?Object.getOwnPropertyDescriptor(e,i):null
a&&(a.get||a.set)?Object.defineProperty(n,i,a):n[i]=e[i]}n.default=e,t&&t.set(e,n)
return n}(e("./window")),a=(o=e("./document"))&&o.__esModule?o:{default:o}
function u(){if("function"!=typeof WeakMap)return null
var e=new WeakMap
return u=function(){return e},e}var c=GameGlobal
GameGlobal.__isAdapterInjected||(GameGlobal.__isAdapterInjected=!0,function(){i.document=a.default,i.addEventListener=function(e,t){i.document.addEventListener(e,t)},
i.removeEventListener=function(e,t){i.document.removeEventListener(e,t)},i.dispatchEvent=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{}
console.log("window.dispatchEvent",e.type,e)}
var e=wx.getSystemInfoSync().platform
if("undefined"==typeof __devtoolssubcontext&&"devtools"===e){for(var t in i){var n=Object.getOwnPropertyDescriptor(c,t)
n&&!0!==n.configurable||Object.defineProperty(window,t,{value:i[t]})}for(var r in i.document){var o=Object.getOwnPropertyDescriptor(c.document,r)
o&&!0!==o.configurable||Object.defineProperty(c.document,r,{value:i.document[r]})}window.parent=window}else{for(var u in i)c[u]=i[u]
c.window=i,window=c,window.top=window.parent=window}}()),c.WebAssembly=c.WXWebAssembly,e("../../../../common/xmldom/dom-parser"),e("../unify")},{
"../../../../common/xmldom/dom-parser":1,"../unify":33,"./document":26,"./window":32}],28:[function(e,t,n){"use strict"
Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0
var r={get length(){return wx.getStorageInfoSync().keys.length},key:function(e){return wx.getStorageInfoSync().keys[e]},getItem:function(e){return wx.getStorageSync(e)},
setItem:function(e,t){return wx.setStorageSync(e,t)},removeItem:function(e){wx.removeStorageSync(e)},clear:function(){wx.clearStorageSync()}}
n.default=r},{}],29:[function(e,t,n){"use strict"
Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0
var r={href:"game.js",protocol:"",reload:function(){}}
n.default=r},{}],30:[function(e,t,n){"use strict"
Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0
var r=e("./util/index.js"),o=wx.getSystemInfoSync()
console.log(o)
var i=o.system,a=o.platform,u=o.language,c=o.version,l=-1!==i.toLowerCase().indexOf("android")?"Android; CPU ".concat(i):"iPhone; CPU iPhone OS ".concat(i," like Mac OS X"),s="Mozilla/5.0 (".concat(l,") AppleWebKit/603.1.30 (KHTML, like Gecko) Mobile/14E8301 MicroMessenger/").concat(c," MiniGame NetType/WIFI Language/").concat(u),f={
platform:a,language:u,appVersion:"5.0 (".concat(l,") AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13B143 Safari/601.1"),userAgent:s,onLine:!0,geolocation:{
getCurrentPosition:r.noop,watchPosition:r.noop,clearWatch:r.noop}}
wx.onNetworkStatusChange&&wx.onNetworkStatusChange((function(e){f.onLine=e.isConnected}))
var d=f
n.default=d},{"./util/index.js":31}],31:[function(e,t,n){"use strict"
Object.defineProperty(n,"__esModule",{value:!0}),n.noop=function(){}},{}],32:[function(e,t,n){"use strict"
Object.defineProperty(n,"__esModule",{value:!0})
var r={canvas:!0,setTimeout:!0,setInterval:!0,clearTimeout:!0,clearInterval:!0,requestAnimationFrame:!0,cancelAnimationFrame:!0,navigator:!0,XMLHttpRequest:!0,WebSocket:!0,
Image:!0,ImageBitmap:!0,Audio:!0,FileReader:!0,HTMLElement:!0,HTMLImageElement:!0,HTMLCanvasElement:!0,HTMLMediaElement:!0,HTMLAudioElement:!0,HTMLVideoElement:!0,
WebGLRenderingContext:!0,TouchEvent:!0,MouseEvent:!0,DeviceMotionEvent:!0,localStorage:!0,location:!0}
Object.defineProperty(n,"navigator",{enumerable:!0,get:function(){return i.default}}),Object.defineProperty(n,"XMLHttpRequest",{enumerable:!0,get:function(){return a.default}}),
Object.defineProperty(n,"WebSocket",{enumerable:!0,get:function(){return u.default}}),Object.defineProperty(n,"Image",{enumerable:!0,get:function(){return c.default}}),
Object.defineProperty(n,"ImageBitmap",{enumerable:!0,get:function(){return l.default}}),Object.defineProperty(n,"Audio",{enumerable:!0,get:function(){return s.default}}),
Object.defineProperty(n,"FileReader",{enumerable:!0,get:function(){return f.default}}),Object.defineProperty(n,"HTMLElement",{enumerable:!0,get:function(){return d.default}}),
Object.defineProperty(n,"HTMLImageElement",{enumerable:!0,get:function(){return p.default}}),Object.defineProperty(n,"HTMLCanvasElement",{enumerable:!0,get:function(){
return E.default}}),Object.defineProperty(n,"HTMLMediaElement",{enumerable:!0,get:function(){return h.default}}),Object.defineProperty(n,"HTMLAudioElement",{enumerable:!0,
get:function(){return m.default}}),Object.defineProperty(n,"HTMLVideoElement",{enumerable:!0,get:function(){return _.default}}),Object.defineProperty(n,"WebGLRenderingContext",{
enumerable:!0,get:function(){return y.default}}),Object.defineProperty(n,"TouchEvent",{enumerable:!0,get:function(){return T.TouchEvent}}),Object.defineProperty(n,"MouseEvent",{
enumerable:!0,get:function(){return T.MouseEvent}}),Object.defineProperty(n,"DeviceMotionEvent",{enumerable:!0,get:function(){return T.DeviceMotionEvent}}),
Object.defineProperty(n,"localStorage",{enumerable:!0,get:function(){return v.default}}),Object.defineProperty(n,"location",{enumerable:!0,get:function(){return b.default}}),
n.cancelAnimationFrame=n.requestAnimationFrame=n.clearInterval=n.clearTimeout=n.setInterval=n.setTimeout=n.canvas=void 0
var o=N(e("./Canvas")),i=N(e("./navigator")),a=N(e("./XMLHttpRequest")),u=N(e("./WebSocket")),c=N(e("./Image")),l=N(e("./ImageBitmap")),s=N(e("./Audio")),f=N(e("./FileReader")),d=N(e("./HTMLElement")),p=N(e("./HTMLImageElement")),E=N(e("./HTMLCanvasElement")),h=N(e("./HTMLMediaElement")),m=N(e("./HTMLAudioElement")),_=N(e("./HTMLVideoElement")),y=N(e("./WebGLRenderingContext")),T=e("./EventIniter/index.js"),v=N(e("./localStorage")),b=N(e("./location")),g=e("./WindowProperties")
function N(e){return e&&e.__esModule?e:{default:e}}Object.keys(g).forEach((function(e){
"default"!==e&&"__esModule"!==e&&(Object.prototype.hasOwnProperty.call(r,e)||Object.defineProperty(n,e,{enumerable:!0,get:function(){return g[e]}}))})),
GameGlobal.screencanvas=GameGlobal.screencanvas||new o.default
var A=GameGlobal.screencanvas
n.canvas=A
var w=GameGlobal,R=w.setTimeout,O=w.setInterval,S=w.clearTimeout,I=w.clearInterval,M=w.requestAnimationFrame,C=w.cancelAnimationFrame
n.cancelAnimationFrame=C,n.requestAnimationFrame=M,n.clearInterval=I,n.clearTimeout=S,n.setInterval=O,n.setTimeout=R},{"./Audio":5,"./Canvas":6,"./EventIniter/index.js":10,
"./FileReader":12,"./HTMLAudioElement":13,"./HTMLCanvasElement":14,"./HTMLElement":15,"./HTMLImageElement":16,"./HTMLMediaElement":17,"./HTMLVideoElement":18,"./Image":19,
"./ImageBitmap":20,"./WebGLRenderingContext":22,"./WebSocket":23,"./WindowProperties":24,"./XMLHttpRequest":25,"./localStorage":28,"./location":29,"./navigator":30}],
33:[function(e,t,n){"use strict"
var r=e("./utils")
if(window.__globalAdapter=window.__globalAdapter||{},window.__globalAdapter){var o=window.__globalAdapter,i=wx.getSystemInfoSync(),a=i.windowWidth>i.windowHeight
o.isSubContext=void 0===wx.getOpenDataContext,o.isDevTool="devtools"===i.platform,r.cloneMethod(o,wx,"getSystemInfoSync"),r.cloneMethod(o,wx,"onTouchStart"),
r.cloneMethod(o,wx,"onTouchMove"),r.cloneMethod(o,wx,"onTouchEnd"),r.cloneMethod(o,wx,"onTouchCancel"),r.cloneMethod(o,wx,"createInnerAudioContext"),
r.cloneMethod(o,wx,"onAudioInterruptionEnd"),r.cloneMethod(o,wx,"onAudioInterruptionBegin"),r.cloneMethod(o,wx,"createVideo"),r.cloneMethod(o,wx,"setPreferredFramesPerSecond"),
r.cloneMethod(o,wx,"showKeyboard"),r.cloneMethod(o,wx,"hideKeyboard"),r.cloneMethod(o,wx,"updateKeyboard"),r.cloneMethod(o,wx,"onKeyboardInput"),
r.cloneMethod(o,wx,"onKeyboardConfirm"),r.cloneMethod(o,wx,"onKeyboardComplete"),r.cloneMethod(o,wx,"offKeyboardInput"),r.cloneMethod(o,wx,"offKeyboardConfirm"),
r.cloneMethod(o,wx,"offKeyboardComplete"),r.cloneMethod(o,wx,"getOpenDataContext"),r.cloneMethod(o,wx,"onMessage"),r.cloneMethod(o,wx,"loadSubpackage"),
r.cloneMethod(o,wx,"getSharedCanvas"),r.cloneMethod(o,wx,"loadFont"),r.cloneMethod(o,wx,"onShow"),r.cloneMethod(o,wx,"onHide"),r.cloneMethod(o,wx,"onError"),
r.cloneMethod(o,wx,"offError")
var u=!1,c=1
wx.onDeviceOrientationChange&&wx.onDeviceOrientationChange((function(e){"landscape"===e.value?c=1:"landscapeReverse"===e.value&&(c=-1)})),Object.assign(o,{
startAccelerometer:function(e){u?wx.startAccelerometer&&wx.startAccelerometer({fail:function(e){console.error("start accelerometer failed",e)}}):(u=!0,
wx.onAccelerometerChange&&wx.onAccelerometerChange((function(t){var n={},r=t.x,o=t.y
if(a){var i=r
r=-o,o=i}n.x=r*c,n.y=o*c,n.z=t.z,e&&e(n)})))},stopAccelerometer:function(){wx.stopAccelerometer&&wx.stopAccelerometer({fail:function(e){console.error("stop accelerometer failed",e)
}})}})}},{"./utils":34}],34:[function(e,t,n){"use strict"
t.exports={cloneMethod:function(e,t,n,r){t[n]&&(e[r=r||n]=t[n].bind(t))}}},{}]},{},[27])

const firstScreen=function(){const e={alpha:!1,antialias:!0,depth:!0,stencil:!0,premultipliedAlpha:!1,preserveDrawingBuffer:!1,powerPreference:"default",
failIfMajorPerformanceCaveat:!1}
let r=null,t=null,n=null,a=null,o=null,i=null,u=null,l=null,T=0,_=[61/255,197/255,222/255,1],E=[100/255,111/255,118/255,1],R=null
function s(e,t){return function(e,t){var n=A(r.VERTEX_SHADER,e),a=A(r.FRAGMENT_SHADER,t),o=r.createProgram()
if(r.attachShader(o,n),r.attachShader(o,a),r.linkProgram(o),!r.getProgramParameter(o,r.LINK_STATUS)){var i=r.getProgramInfoLog(o)
console.log("Failed to link program: "+i),r.deleteProgram(o),o=null}return r.deleteShader(a),r.deleteShader(n),o}(e,t)}function A(e,t){var n=r.createShader(e)
if(r.shaderSource(n,t),r.compileShader(n),!r.getShaderParameter(n,r.COMPILE_STATUS)){var a=r.getShaderInfoLog(n)
return console.log("Failed to compile shader: "+a),r.deleteShader(n),null}return n}function f(){o=requestAnimationFrame((()=>{!function(){r.clearColor(0,0,0,0),
r.clear(r.COLOR_BUFFER_BIT),r.useProgram(n),r.activeTexture(r.TEXTURE0),r.bindTexture(r.TEXTURE_2D,i)
var e=r.getUniformLocation(n,"u_Sampler")
r.uniform1i(e,0),r.bindBuffer(r.ARRAY_BUFFER,u)
var t=r.getAttribLocation(n,"a_Position")
r.enableVertexAttribArray(t),r.vertexAttribPointer(t,2,r.FLOAT,!1,16,0)
var o=r.getAttribLocation(n,"a_TexCoord")
r.enableVertexAttribArray(o),r.vertexAttribPointer(o,2,r.FLOAT,!1,16,8),r.drawArrays(r.TRIANGLE_STRIP,0,4),r.useProgram(a)
var R=r.getUniformLocation(a,"u_CurrentProgress")
r.uniform1f(R,T)
var s=r.getUniformLocation(a,"u_ProgressBarColor")
r.uniform4fv(s,_)
var A=r.getUniformLocation(a,"u_ProgressBackground")
r.uniform4fv(A,E),r.bindBuffer(r.ARRAY_BUFFER,l),t=r.getAttribLocation(a,"a_Position"),r.enableVertexAttribArray(t),r.vertexAttribPointer(t,2,r.FLOAT,!1,12,0)
var f=r.getAttribLocation(a,"a_Progress")
r.enableVertexAttribArray(f),r.vertexAttribPointer(f,1,r.FLOAT,!1,12,8),r.drawArrays(r.TRIANGLE_STRIP,0,4)}(),f(),R&&(R(),R=null)}))}function c(e){return T=e,new Promise(((e,r)=>{
R=()=>{e()}}))}return{start:function(o,T,_){return e.alpha="true"===o,e.antialias="false"!==T,"true"===_&&(r=window.canvas.getContext("webgl2",e)),
r?window.WebGL2RenderingContext=!0:(window.WebGL2RenderingContext=!1,r=window.canvas.getContext("webgl",e)),function(){
const e=2/canvas.width,t=2/canvas.height,n=new Float32Array([e,t,1,1,e,t,1,0,-e,t,0,1,-e,t,0,0])
u=r.createBuffer(),r.bindBuffer(r.ARRAY_BUFFER,u),r.bufferData(r.ARRAY_BUFFER,n,r.STATIC_DRAW)}(),function(){
const e=.405,t=(window.devicePixelRatio>=2?6:3)/canvas.height,n=-.25,a=new Float32Array([e,n-t,1,e,n+t,1,-.405,n-t,0,-.405,n+t,0])
l=r.createBuffer(),r.bindBuffer(r.ARRAY_BUFFER,l),r.bufferData(r.ARRAY_BUFFER,a,r.STATIC_DRAW)}(),i=r.createTexture(),r.activeTexture(r.TEXTURE0),r.bindTexture(r.TEXTURE_2D,i),
r.texParameteri(r.TEXTURE_2D,r.TEXTURE_MIN_FILTER,r.LINEAR),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_MAG_FILTER,r.LINEAR),
r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_S,r.CLAMP_TO_EDGE),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_T,r.CLAMP_TO_EDGE),
r.texImage2D(r.TEXTURE_2D,0,r.RGBA,2,2,0,r.RGBA,r.UNSIGNED_BYTE,new Uint8Array([0,0,0,255,0,0,0,255,0,0,0,255,0,0,0,255])),
n=s("\n    attribute vec4 a_Position;\n    attribute vec2 a_TexCoord;\n    varying vec2 v_TexCoord;\n    void main() {\n        gl_Position = a_Position;  \n        v_TexCoord = a_TexCoord;\n    }","\n    precision mediump float;\n    uniform sampler2D u_Sampler;\n    varying vec2 v_TexCoord;\n    void main() {\n        gl_FragColor = texture2D(u_Sampler, v_TexCoord);\n    }"),
a=s("\n    precision mediump float;\n    attribute vec4 a_Position;\n    attribute float a_Progress;\n    varying float v_Progress;\n    void main() {\n        gl_Position = a_Position;  \n        v_Progress = a_Progress;\n    }","\n    precision mediump float;\n    uniform float u_CurrentProgress;\n    varying float v_Progress;\n    uniform vec4 u_ProgressBarColor;\n    uniform vec4 u_ProgressBackground;\n    void main() {\n        gl_FragColor = v_Progress <= u_CurrentProgress ? u_ProgressBarColor : u_ProgressBackground;\n    }"),
f(),(E="splash.png",new Promise(((e,r)=>{t=new Image,t.premultiplyAlpha=!1,t.onload=function(){e(t)},t.onerror=function(e){r(e)},t.src=E.replace("#","%23")
}))).then((()=>(function(){const e=t.width/canvas.width,n=t.height/canvas.height,a=new Float32Array([e,-n,1,1,e,n,1,0,-e,-n,0,1,-e,n,0,0])
r.bindBuffer(r.ARRAY_BUFFER,u),r.bufferData(r.ARRAY_BUFFER,a,r.STATIC_DRAW)}(),r.activeTexture(r.TEXTURE0),r.bindTexture(r.TEXTURE_2D,i),
r.texParameteri(r.TEXTURE_2D,r.TEXTURE_MIN_FILTER,r.LINEAR),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_MAG_FILTER,r.LINEAR),
r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_S,r.CLAMP_TO_EDGE),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_T,r.CLAMP_TO_EDGE),
r.texImage2D(r.TEXTURE_2D,0,r.RGBA,r.RGBA,r.UNSIGNED_BYTE,t),c(0))))
var E},end:function(){return c(1).then((()=>{cancelAnimationFrame(o),r.useProgram(null),r.bindTexture(r.TEXTURE_2D,null),r.bindBuffer(r.ARRAY_BUFFER,null),r.deleteTexture(i),
r.deleteBuffer(u),r.deleteBuffer(l),r.deleteProgram(n),r.deleteProgram(a)}))},setProgress:c}}()

window.SQSDK=function(){const e={payMode:"",extraData:"",fx_game_id:"215",zy_game_id:"898",c_game_id:"android.game.rydts_wxxyxtg",fx_c_game_id:"23155",
android_os_type:"android.game.rydts_xyx",other_os_type:"com.rydts.wxxyx",app_ext:"",isShowSubscribeMessage:!1,openid:"",unionid:"",uid:"",guid:"",session_key:"",wx_system_info:"",
pay_version:"",system:"",iosPayImgUrl:"https://web.oiz611.com/generalimg1/faxing/rydts/clickpay.png",shareReferer:"haxyxfx_g1_zd_rydts",shareConfigList:[],subscribeMessageKey:"",
defaultShareConfig:{imageUrl:"",title:""},wx_param:"",questionnaireAppid:"wxebadf544ddae62cb",actor_id:"",sid:""},o={
login:`https://apigameh5.shxnetwork.com/enter/37wxxyx/${e.fx_game_id}?a=quickAppEnter&pt_type=1`,
loginReport:"https://apigameh5.shxnetwork.com/index.php?c=api&a=default&appid=37wxxyx&cc=api&ca=game_login_report",
shareReport:"https://apigameh5.shxnetwork.com/index.php?c=api&a=default&appid=37wxxyx&cc=api&ca=game_share_report",
shareConfigUrl:`https://apigameh5.shxnetwork.com/index.php?c=api&a=query_platform_game_publish_config&appid=37wxxyx&key=share_config&game_id=${e.fx_game_id}`,
zyCreateOrder:"https://apipay.shxnetwork.com/paygate.php?c=wxmp&a=create_order",goPay:"https://apipay.shxnetwork.com/paygate.php?c=wxmp&a=go_pay",
payMode:"https://apipay.shxnetwork.com/paygate.php?c=wxmp&a=pmode",openKf:"https://apipay.shxnetwork.com/paygate.php?c=wxmp&a=send_pay",
subscribeMessage:`https://apigameh5.shxnetwork.com/index.php?c=api&a=default&appid=37wxxyx&game_id=${e.fx_game_id}&cc=api&ca=subscribeTempletCallback`,
questionnaire:`https://apigameh5.shxnetwork.com/index.php?c=api&a=default&appid=37wxxyx&game_id=${e.fx_game_id}&cc=api&ca=getPublicConf&conf=miniprogram_path`},a=function(o){
if(o.length>0){return o[Math.floor(Math.random()*o.length)]}return e.defaultShareConfig},t=function(e){
var o,a,t,n,r,i,c="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",d="",l=0
for(e=e.replace(/[^A-Za-z0-9\+\/\=]/g,"");l<e.length;)o=c.indexOf(e.charAt(l++))<<2|(n=c.indexOf(e.charAt(l++)))>>4,a=(15&n)<<4|(r=c.indexOf(e.charAt(l++)))>>2,
t=(3&r)<<6|(i=c.indexOf(e.charAt(l++))),d+=String.fromCharCode(o),64!=r&&(d+=String.fromCharCode(a)),64!=i&&(d+=String.fromCharCode(t))
return d=s(d)},s=function(e){for(var o="",a=0,t=0,s=0,n=0;a<e.length;)(t=e.charCodeAt(a))<128?(o+=String.fromCharCode(t),a++):t>191&&t<224?(s=e.charCodeAt(a+1),
o+=String.fromCharCode((31&t)<<6|63&s),a+=2):(s=e.charCodeAt(a+1),n=e.charCodeAt(a+2),o+=String.fromCharCode((15&t)<<12|(63&s)<<6|63&n),a+=3)
return o},n=function(e){return function(e){for(var o="0123456789abcdef",a="",t=0;t<4*e.length;t++)a+=o.charAt(e[t>>2]>>t%4*8+4&15)+o.charAt(e[t>>2]>>t%4*8&15)
return a}(function(e,o){e[o>>5]|=128<<o%32,e[14+(o+64>>>9<<4)]=o
for(var i=1732584193,c=-271733879,d=-1732584194,l=271733878,p=0;p<e.length;p+=16){var g=i,u=c,f=d,h=l
i=a(i,c,d,l,e[p+0],7,-680876936),l=a(l,i,c,d,e[p+1],12,-389564586),d=a(d,l,i,c,e[p+2],17,606105819),c=a(c,d,l,i,e[p+3],22,-1044525330),i=a(i,c,d,l,e[p+4],7,-176418897),
l=a(l,i,c,d,e[p+5],12,1200080426),d=a(d,l,i,c,e[p+6],17,-1473231341),c=a(c,d,l,i,e[p+7],22,-45705983),i=a(i,c,d,l,e[p+8],7,1770035416),l=a(l,i,c,d,e[p+9],12,-1958414417),
d=a(d,l,i,c,e[p+10],17,-42063),c=a(c,d,l,i,e[p+11],22,-1990404162),i=a(i,c,d,l,e[p+12],7,1804603682),l=a(l,i,c,d,e[p+13],12,-40341101),d=a(d,l,i,c,e[p+14],17,-1502002290),
c=a(c,d,l,i,e[p+15],22,1236535329),i=t(i,c,d,l,e[p+1],5,-165796510),l=t(l,i,c,d,e[p+6],9,-1069501632),d=t(d,l,i,c,e[p+11],14,643717713),c=t(c,d,l,i,e[p+0],20,-373897302),
i=t(i,c,d,l,e[p+5],5,-701558691),l=t(l,i,c,d,e[p+10],9,38016083),d=t(d,l,i,c,e[p+15],14,-660478335),c=t(c,d,l,i,e[p+4],20,-405537848),i=t(i,c,d,l,e[p+9],5,568446438),
l=t(l,i,c,d,e[p+14],9,-1019803690),d=t(d,l,i,c,e[p+3],14,-187363961),c=t(c,d,l,i,e[p+8],20,1163531501),i=t(i,c,d,l,e[p+13],5,-1444681467),l=t(l,i,c,d,e[p+2],9,-51403784),
d=t(d,l,i,c,e[p+7],14,1735328473),c=t(c,d,l,i,e[p+12],20,-1926607734),i=s(i,c,d,l,e[p+5],4,-378558),l=s(l,i,c,d,e[p+8],11,-2022574463),d=s(d,l,i,c,e[p+11],16,1839030562),
c=s(c,d,l,i,e[p+14],23,-35309556),i=s(i,c,d,l,e[p+1],4,-1530992060),l=s(l,i,c,d,e[p+4],11,1272893353),d=s(d,l,i,c,e[p+7],16,-155497632),c=s(c,d,l,i,e[p+10],23,-1094730640),
i=s(i,c,d,l,e[p+13],4,681279174),l=s(l,i,c,d,e[p+0],11,-358537222),d=s(d,l,i,c,e[p+3],16,-722521979),c=s(c,d,l,i,e[p+6],23,76029189),i=s(i,c,d,l,e[p+9],4,-640364487),
l=s(l,i,c,d,e[p+12],11,-421815835),d=s(d,l,i,c,e[p+15],16,530742520),c=s(c,d,l,i,e[p+2],23,-995338651),i=n(i,c,d,l,e[p+0],6,-198630844),l=n(l,i,c,d,e[p+7],10,1126891415),
d=n(d,l,i,c,e[p+14],15,-1416354905),c=n(c,d,l,i,e[p+5],21,-57434055),i=n(i,c,d,l,e[p+12],6,1700485571),l=n(l,i,c,d,e[p+3],10,-1894986606),d=n(d,l,i,c,e[p+10],15,-1051523),
c=n(c,d,l,i,e[p+1],21,-2054922799),i=n(i,c,d,l,e[p+8],6,1873313359),l=n(l,i,c,d,e[p+15],10,-30611744),d=n(d,l,i,c,e[p+6],15,-1560198380),c=n(c,d,l,i,e[p+13],21,1309151649),
i=n(i,c,d,l,e[p+4],6,-145523070),l=n(l,i,c,d,e[p+11],10,-1120210379),d=n(d,l,i,c,e[p+2],15,718787259),c=n(c,d,l,i,e[p+9],21,-343485551),i=r(i,g),c=r(c,u),d=r(d,f),l=r(l,h)}
return Array(i,c,d,l)}(function(e){for(var o=Array(),a=0;a<8*e.length;a+=8)o[a>>5]|=(255&e.charCodeAt(a/8))<<a%32
return o}(e),8*e.length))
function o(e,o,a,t,s,n){return r((i=r(r(o,e),r(t,n)))<<(c=s)|i>>>32-c,a)
var i,c}function a(e,a,t,s,n,r,i){return o(a&t|~a&s,e,a,n,r,i)}function t(e,a,t,s,n,r,i){return o(a&s|t&~s,e,a,n,r,i)}function s(e,a,t,s,n,r,i){return o(a^t^s,e,a,n,r,i)}
function n(e,a,t,s,n,r,i){return o(t^(a|~s),e,a,n,r,i)}function r(e,o){var a=(65535&e)+(65535&o)
return(e>>16)+(o>>16)+(a>>16)<<16|65535&a}},r=function(o){const a={IC:2,DF:o.system.split(" ")[0]||"",OS:o.system.split(" ")[1]||"",AT:"",DC:"",PM:o.model,BW:"",RL:"",PN:"",PV:"",
SDKV:o.SDKVersion,IDFA:"",ADID:"",UEADID:"",IMEI:"",OAID:"",LU:o.language,IDFV:"",CC:"",BT:"",DN:"",CI:"",MM:"",DISK:"",SFT:"",MODEL:"",TZ:"",CAID:"",CS:""},t=i(a)
e.device_info=function(e){var o,a,t,s,n,r,i="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="
for(t=e.length,a=0,o="";a<t;){if(s=255&e.charCodeAt(a++),a==t){o+=i.charAt(s>>2),o+=i.charAt((3&s)<<4),o+="=="
break}if(n=e.charCodeAt(a++),a==t){o+=i.charAt(s>>2),o+=i.charAt((3&s)<<4|(240&n)>>4),o+=i.charAt((15&n)<<2),o+="="
break}r=e.charCodeAt(a++),o+=i.charAt(s>>2),o+=i.charAt((3&s)<<4|(240&n)>>4),o+=i.charAt((15&n)<<2|(192&r)>>6),o+=i.charAt(63&r)}return o}(t)},i=function(e){const o=[]
for(let a in e)e.hasOwnProperty(a)&&o.push(a+"="+e[a])
return o.join("|")},c=function(){const a={guid:e.guid,game_id:e.fx_game_id,uid:e.uid,login_account:e.openid,device_info:e.device_info,app_ext:encodeURIComponent(e.app_ext),
c_game_id:e.c_game_id}
wx.request({url:o.loginReport,data:a,success(e){const o=e.data
1==+o.code?console.log("登录上报成功=====>",o):console.log("登录上报失败=====>",o)},fail(e){console.log("登录上报失败=====>",e)}})},d={share(t={}){let s="",n={}
t.extraData&&(n.extraData=t.extraData),n.referer=e.shareReferer,s=function(e,o){const a=[]
for(const t in e){let s=t,n=e[t]
o||(s=encodeURIComponent(t),n=encodeURIComponent(e[t])),a.push(s+"="+n)}return a.join("&")}(n),console.log("sq 分享携带参数-----\x3e",s)
const r=a(e.shareConfigList)
wx.shareAppMessage({title:r.title,imageUrl:r.imageUrl,query:s}),function(){const a={uid:e.uid,game_id:e.fx_game_id,c_game_id:e.c_game_id,sid:"",referer:e.shareReferer,
referer_param:"",ad_param:"",ad_type:"",bid:"",lid:"",ext:"",from_platform:"",tj_way:"",tj_from:"",device_info:e.device_info,guid:e.guid,app_ext:encodeURIComponent(e.app_ext)}
wx.request({url:o.shareReport,data:a,success(e){const o=e.data
1==+o.code?console.log("sq 分享上报成功-----\x3e",o):console.log("sq 分享上报失败-----\x3e",o)},fail(e){console.error("sq 分享上报请求失败-----\x3e",e)}})}(),
"function"==typeof t.successCb&&t.successCb()},subscribeMessage(){if(!e.app_ext)return
const a=JSON.parse(t(e.app_ext))
null===a.disposable_templet||void 0!==a.disposable_templet&&0===a.disposable_templet.length||e.isShowSubscribeMessage||wx.requestSubscribeMessage({tmplIds:a.disposable_templet,
success(a){console.log("订阅成功",a),e.isShowSubscribeMessage=!0,wx.request({url:o.subscribeMessage,data:{data:JSON.stringify(a),openid:e.openid,unionid:e.unionid,
sign:n("37wxxyx"+e.fx_game_id+e.subscribeMessageKey)},success(e){console.log("成功上报",e)},fail(e){console.error("失败上报",e)}})},fail(e){console.error("订阅失败",e)}})},
navigateToQuestionnaire(a){if(!a)throw Error("请提供 sid 和 actor_id")
if(a&&!a.sid)throw Error("请提供 sid")
if(a&&!a.actor_id)throw Error("请提供 actor_id")
e.sid=a.sid,e.actor_id=a.actor_id,wx.request({url:o.questionnaire,data:{time:Math.floor((new Date).getTime()/1e3)},success(o){const a=o.data
1==+a.code?wx.navigateToMiniProgram({appId:e.questionnaireAppid,path:`${a.data}&openid=${e.uid}`,success(e){console.log("跳转问卷成功-----\x3e",e)},fail(e){
console.log("跳转问卷失败-----\x3e",e)}}):wx.showModal({title:"温馨提示",content:a.msg,showCancel:!1})},fail(e){console.error("sq 获取问卷请求失败=====>",e),wx.showModal({title:"温馨提示",
content:"获取问卷失败，请联系客服",showCancel:!1})}})},pay(a={},s={}){console.log("sq 下单参数-----\x3e",a)
let n=!1
const r=JSON.parse(t(e.app_ext)),i=()=>(a.c_game_id=e.c_game_id,a.fx_c_game_id=e.fx_c_game_id,a.sdk_version="",a.h5_tj_data=e.device_info,a.openid=e.openid,
a.session_key=e.session_key,a.wx_param=e.wx_param,a.wx_system_info=e.wx_system_info,a.app_pst=encodeURIComponent(r.app_pst),new Promise((e=>{wx.request({url:o.zyCreateOrder,data:a,
success(o){var a=o.data
1==+a.code?e(a):1001==+a.code?wx.showToast({title:"支付成功",icon:"none",duration:2e3}):wx.showModal({title:"温馨提示",content:a.msg,showCancel:!1})},fail(e){
console.error("sq 下单失败-----\x3e",e),wx.showModal({title:"温馨提示",content:"下单失败",showCancel:!1})}})}))),c=(e,a)=>new Promise((()=>{wx.request({url:o.goPay,data:{order_id:e},
success(o){console.log("扣款发货状态======>",o)
const t=o.data
if(1==+t.code)n=!1,1===a?wx.showModal({title:"温馨提示",content:"已通过余额成功购买商品",showCancel:!1}):3===a?"function"==typeof s.pcPayCb&&s.pcPayCb({img:t.data}):wx.showModal({title:"温馨提示",
content:"商品购买成功",showCancel:!1})
else if(-2==+t.code){if(n)return void wx.showModal({title:"温馨提示",content:"很抱歉，商品发货失败，请联系客服～",showCancel:!1})
n=!0,c(e,a)}else wx.showModal({title:"温馨提示",content:t.msg,showCancel:!1})},fail(e){console.error("扣款发货接口失败======>",e),wx.showModal({title:"温馨提示",content:"商品购买失败",showCancel:!1})}})
}))
new Promise((a=>{const t=/android/i.test(e.system)?e.android_os_type:e.other_os_type
wx.request({url:o.payMode,data:{game_id:e.zy_game_id,c_game_id:t,user_id:e.uid,version:e.pay_version},success(o){var t=o.data
1==+t.code?(e.payMode=t.data.mode,1==+t.data.pay_on?a():wx.showModal({content:"目前暂不支持充值，请您敬请期待哦。",showCancel:!1})):wx.showModal({title:"温馨提示",content:t.msg,showCancel:!1})},
fail(e){console.error("sq 获取支付模式失败-----\x3e",e),wx.showModal({title:"温馨提示",content:"获取支付模式失败",showCancel:!1})}})})).then((()=>{if(1==+e.payMode)a.terminal="wechat_mgame",
i().then((e=>{console.log("sq 米大师订单创建参数-----\x3e",e),1==+e.data.enough?c(e.data.order_id,+e.data.enough):wx.requestMidasPayment({buyQuantity:e.data.buyQuantity,
currencyType:e.data.currencyType,env:e.data.env,mode:e.data.mode,offerId:e.data.offerId,platform:e.data.platform,zoneId:e.data.zoneId,success(o){
console.log("sq 米大师支付成功-----\x3e",o),c(e.data.order_id,+e.data.enough)},fail(e){console.log("sq 米大师支付失败-----\x3e",e),1!==e.errCode&&-2!==e.errCode&&wx.showModal({title:"支付结果",
content:e.errMsg,showCancel:!1})}})}))
else if(2==+e.payMode){const t=JSON.parse(e.wx_system_info).system;/macOS/.test(t)||/Windows/.test(t)?(a.terminal="wechat_pc",console.log("sq PC 下单参数-----\x3e",a),i().then((e=>{
console.log("sq PC 订单创建参数-----\x3e",e),c(e.data.order_id,3)}))):(a.terminal="wechat_pub",i().then((e=>{return console.log("sq 客服订单创建参数-----\x3e",e),o=e.data.order_id,
new Promise((e=>{wx.login({success(a){e({code:a.code,content:o})}})}))
var o})).then((a=>{return console.log("sq 打开客服参数-----\x3e",a),t=a.code,n=a.content,new Promise((()=>{wx.request({url:o.openKf,data:{game_id:e.zy_game_id,js_code:t,content:n},
success(o){var a=o.data
console.log("sq 切客服支付-----\x3e",o),1==+a.code?wx.showModal({title:"支付提示",content:"即将打开客服聊天界面，输入“cz”或者“充值”可以获取支付链接",showCancel:!1,confirmText:"我知道了",success(o){if(o.confirm){
const o=setTimeout((function(){"function"==typeof s.iosPaySuccess&&s.iosPaySuccess()}),15e3)
"function"==typeof s.iosPayShowModalCb&&s.iosPayShowModalCb(),wx.openCustomerServiceConversation({showMessageCard:!0,sendMessageImg:e.iosPayImgUrl,success:e=>{
console.log("sq 跳转客服成功-----\x3e",e),"function"==typeof s.iosPaySuccess&&s.iosPaySuccess(),clearTimeout(o)},fail:e=>{console.log("sq 跳转客服失败-----\x3e",e),
"function"==typeof s.iosPayFail&&s.iosPayFail(),clearTimeout(o)}})}}}):wx.showModal({title:"温馨提示",content:a.msg,showCancel:!1})},fail(e){console.error("sq 客服支付请求失败-----\x3e",e),
wx.showModal({title:"温馨提示",content:"前往客服支付失败",showCancel:!1})}})}))
var t,n})).catch((e=>{console.error("sq ios支付失败-----\x3e",e)})))}}))},login(a){if(!a)throw Error("请提供回调函数！")
wx.login({success:function(s){var n=s.code
n&&wx.request({url:o.login,data:{js_code:n,wx_param:e.wx_param,wx_system_info:e.wx_system_info,c_game_id:e.c_game_id,device_info:e.device_info},success:function(o){
console.log("登录成功=======>",o)
var s=o.data
1==+s.code?(e.uid=s.data.uid,e.openid=s.data.openid,e.session_key=s.data.session_key,e.guid=s.data.guid,e.fx_game_id=s.data.game_id,e.unionid=s.data.unionid,
e.app_ext=decodeURIComponent(s.data.app_ext),console.log("sq app_pst-----\x3e",JSON.parse(t(e.app_ext)).app_pst),a({code:1,data:s.data,loginReport:c,extraData:e.extraData
})):10001==+s.code?wx.showModal({title:"温馨提示",content:s.msg,showCancel:!1}):a({code:0,data:s.data?s.data:"",msg:s.msg?s.msg:""})},fail:function(e){console.error("登录失败=======>",e),
a({code:0,error:e})}})},fail:function(e){console.error("微信获取login code失败====>",e)}})}}
return function(){const o=wx.getSystemInfoSync()
console.log("sq 系统信息-----\x3e",o),e.wx_system_info=JSON.stringify(o),e.system=o.system,r(o)}(),function(){const o=wx.getLaunchOptionsSync()
console.log("sq 启动参数-----\x3e",o),o&&(e.wx_param=JSON.stringify(o.query),console.log("sq sdkData.wx_param-----\x3e",e.wx_param),
o.query&&o.query.extraData&&(e.extraData=o.query.extraData))}(),function(){wx.showShareMenu()
const t=`referer=${e.shareReferer}`
wx.request({url:o.shareConfigUrl,success(o){console.log("sq share_config----\x3e",o.data)
const s=o.data
if(1==+s.code){e.shareConfigList=s.data.share_config
const o=a(e.shareConfigList)
wx.onShareAppMessage((()=>({title:o.title,imageUrl:o.imageUrl,query:t})))}else wx.onShareAppMessage((()=>({title:defaultShareConfig.title,imageUrl:defaultShareConfig.imageUrl,
query:t})))},fail(){wx.onShareAppMessage((()=>({title:defaultShareConfig.title,imageUrl:defaultShareConfig.imageUrl})))}})}(),d}()

!function(t){"function"==typeof define&&define.amd?define(t):t()}((function(){"use strict";var t="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{};var n,r,e=(function(n){!function(t){var n={};function r(e){if(n[e])return n[e].exports;var o=n[e]={i:e,l:!1,exports:{}};return t[e].call(o.exports,o,o.exports,r),o.l=!0,o.exports}r.m=t,r.c=n,r.d=function(t,n,e){r.o(t,n)||Object.defineProperty(t,n,{enumerable:!0,get:e})},r.r=function(t){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(t,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(t,"__esModule",{value:!0})},r.t=function(t,n){if(1&n&&(t=r(t)),8&n)return t;if(4&n&&"object"==typeof t&&t&&t.__esModule)return t;var e=Object.create(null);if(r.r(e),Object.defineProperty(e,"default",{enumerable:!0,value:t}),2&n&&"string"!=typeof t)for(var o in t)r.d(e,o,function(n){return t[n]}.bind(null,o));return e},r.n=function(t){var n=t&&t.__esModule?function(){return t.default}:function(){return t};return r.d(n,"a",n),n},r.o=function(t,n){return Object.prototype.hasOwnProperty.call(t,n)},r.p="",r(r.s=0)}([function(t,n,r){t.exports=r(1)},function(t,n,r){r(2)({global:!0},{globalThis:r(3)})},function(t,n,r){var e=r(3),o=r(4).f,u=r(18),i=r(21),f=r(22),c=r(32),a=r(44);t.exports=function(t,n){var r,p,s,l,v,y=t.target,d=t.global,g=t.stat;if(r=d?e:g?e[y]||f(y,{}):(e[y]||{}).prototype)for(p in n){if(l=n[p],s=t.noTargetGet?(v=o(r,p))&&v.value:r[p],!a(d?p:y+(g?".":"#")+p,t.forced)&&void 0!==s){if(typeof l==typeof s)continue;c(l,s)}(t.sham||s&&s.sham)&&u(l,"sham",!0),i(r,p,l,t)}}},function(n,r){var e=function(t){return t&&t.Math==Math&&t};n.exports=e("object"==typeof globalThis&&globalThis)||e("object"==typeof window&&window)||e("object"==typeof self&&self)||e("object"==typeof t&&t)||Function("return this")()},function(t,n,r){var e=r(5),o=r(7),u=r(8),i=r(9),f=r(13),c=r(15),a=r(16),p=Object.getOwnPropertyDescriptor;n.f=e?p:function(t,n){if(t=i(t),n=f(n,!0),a)try{return p(t,n)}catch(t){}if(c(t,n))return u(!o.f.call(t,n),t[n])}},function(t,n,r){var e=r(6);t.exports=!e((function(){return 7!=Object.defineProperty({},1,{get:function(){return 7}})[1]}))},function(t,n){t.exports=function(t){try{return!!t()}catch(t){return!0}}},function(t,n,r){var e={}.propertyIsEnumerable,o=Object.getOwnPropertyDescriptor,u=o&&!e.call({1:2},1);n.f=u?function(t){var n=o(this,t);return!!n&&n.enumerable}:e},function(t,n){t.exports=function(t,n){return{enumerable:!(1&t),configurable:!(2&t),writable:!(4&t),value:n}}},function(t,n,r){var e=r(10),o=r(12);t.exports=function(t){return e(o(t))}},function(t,n,r){var e=r(6),o=r(11),u="".split;t.exports=e((function(){return!Object("z").propertyIsEnumerable(0)}))?function(t){return"String"==o(t)?u.call(t,""):Object(t)}:Object},function(t,n){var r={}.toString;t.exports=function(t){return r.call(t).slice(8,-1)}},function(t,n){t.exports=function(t){if(null==t)throw TypeError("Can't call method on "+t);return t}},function(t,n,r){var e=r(14);t.exports=function(t,n){if(!e(t))return t;var r,o;if(n&&"function"==typeof(r=t.toString)&&!e(o=r.call(t)))return o;if("function"==typeof(r=t.valueOf)&&!e(o=r.call(t)))return o;if(!n&&"function"==typeof(r=t.toString)&&!e(o=r.call(t)))return o;throw TypeError("Can't convert object to primitive value")}},function(t,n){t.exports=function(t){return"object"==typeof t?null!==t:"function"==typeof t}},function(t,n){var r={}.hasOwnProperty;t.exports=function(t,n){return r.call(t,n)}},function(t,n,r){var e=r(5),o=r(6),u=r(17);t.exports=!e&&!o((function(){return 7!=Object.defineProperty(u("div"),"a",{get:function(){return 7}}).a}))},function(t,n,r){var e=r(3),o=r(14),u=e.document,i=o(u)&&o(u.createElement);t.exports=function(t){return i?u.createElement(t):{}}},function(t,n,r){var e=r(5),o=r(19),u=r(8);t.exports=e?function(t,n,r){return o.f(t,n,u(1,r))}:function(t,n,r){return t[n]=r,t}},function(t,n,r){var e=r(5),o=r(16),u=r(20),i=r(13),f=Object.defineProperty;n.f=e?f:function(t,n,r){if(u(t),n=i(n,!0),u(r),o)try{return f(t,n,r)}catch(t){}if("get"in r||"set"in r)throw TypeError("Accessors not supported");return"value"in r&&(t[n]=r.value),t}},function(t,n,r){var e=r(14);t.exports=function(t){if(!e(t))throw TypeError(String(t)+" is not an object");return t}},function(t,n,r){var e=r(3),o=r(18),u=r(15),i=r(22),f=r(23),c=r(25),a=c.get,p=c.enforce,s=String(String).split("String");(t.exports=function(t,n,r,f){var c=!!f&&!!f.unsafe,a=!!f&&!!f.enumerable,l=!!f&&!!f.noTargetGet;"function"==typeof r&&("string"!=typeof n||u(r,"name")||o(r,"name",n),p(r).source=s.join("string"==typeof n?n:"")),t!==e?(c?!l&&t[n]&&(a=!0):delete t[n],a?t[n]=r:o(t,n,r)):a?t[n]=r:i(n,r)})(Function.prototype,"toString",(function(){return"function"==typeof this&&a(this).source||f(this)}))},function(t,n,r){var e=r(3),o=r(18);t.exports=function(t,n){try{o(e,t,n)}catch(r){e[t]=n}return n}},function(t,n,r){var e=r(24),o=Function.toString;"function"!=typeof e.inspectSource&&(e.inspectSource=function(t){return o.call(t)}),t.exports=e.inspectSource},function(t,n,r){var e=r(3),o=r(22),u=e["__core-js_shared__"]||o("__core-js_shared__",{});t.exports=u},function(t,n,r){var e,o,u,i=r(26),f=r(3),c=r(14),a=r(18),p=r(15),s=r(27),l=r(31),v=f.WeakMap;if(i){var y=new v,d=y.get,g=y.has,b=y.set;e=function(t,n){return b.call(y,t,n),n},o=function(t){return d.call(y,t)||{}},u=function(t){return g.call(y,t)}}else{var x=s("state");l[x]=!0,e=function(t,n){return a(t,x,n),n},o=function(t){return p(t,x)?t[x]:{}},u=function(t){return p(t,x)}}t.exports={set:e,get:o,has:u,enforce:function(t){return u(t)?o(t):e(t,{})},getterFor:function(t){return function(n){var r;if(!c(n)||(r=o(n)).type!==t)throw TypeError("Incompatible receiver, "+t+" required");return r}}}},function(t,n,r){var e=r(3),o=r(23),u=e.WeakMap;t.exports="function"==typeof u&&/native code/.test(o(u))},function(t,n,r){var e=r(28),o=r(30),u=e("keys");t.exports=function(t){return u[t]||(u[t]=o(t))}},function(t,n,r){var e=r(29),o=r(24);(t.exports=function(t,n){return o[t]||(o[t]=void 0!==n?n:{})})("versions",[]).push({version:"3.6.5",mode:e?"pure":"global",copyright:"© 2020 Denis Pushkarev (zloirock.ru)"})},function(t,n){t.exports=!1},function(t,n){var r=0,e=Math.random();t.exports=function(t){return"Symbol("+String(void 0===t?"":t)+")_"+(++r+e).toString(36)}},function(t,n){t.exports={}},function(t,n,r){var e=r(15),o=r(33),u=r(4),i=r(19);t.exports=function(t,n){for(var r=o(n),f=i.f,c=u.f,a=0;a<r.length;a++){var p=r[a];e(t,p)||f(t,p,c(n,p))}}},function(t,n,r){var e=r(34),o=r(36),u=r(43),i=r(20);t.exports=e("Reflect","ownKeys")||function(t){var n=o.f(i(t)),r=u.f;return r?n.concat(r(t)):n}},function(t,n,r){var e=r(35),o=r(3),u=function(t){return"function"==typeof t?t:void 0};t.exports=function(t,n){return arguments.length<2?u(e[t])||u(o[t]):e[t]&&e[t][n]||o[t]&&o[t][n]}},function(t,n,r){var e=r(3);t.exports=e},function(t,n,r){var e=r(37),o=r(42).concat("length","prototype");n.f=Object.getOwnPropertyNames||function(t){return e(t,o)}},function(t,n,r){var e=r(15),o=r(9),u=r(38).indexOf,i=r(31);t.exports=function(t,n){var r,f=o(t),c=0,a=[];for(r in f)!e(i,r)&&e(f,r)&&a.push(r);for(;n.length>c;)e(f,r=n[c++])&&(~u(a,r)||a.push(r));return a}},function(t,n,r){var e=r(9),o=r(39),u=r(41),i=function(t){return function(n,r,i){var f,c=e(n),a=o(c.length),p=u(i,a);if(t&&r!=r){for(;a>p;)if((f=c[p++])!=f)return!0}else for(;a>p;p++)if((t||p in c)&&c[p]===r)return t||p||0;return!t&&-1}};t.exports={includes:i(!0),indexOf:i(!1)}},function(t,n,r){var e=r(40),o=Math.min;t.exports=function(t){return t>0?o(e(t),9007199254740991):0}},function(t,n){var r=Math.ceil,e=Math.floor;t.exports=function(t){return isNaN(t=+t)?0:(t>0?e:r)(t)}},function(t,n,r){var e=r(40),o=Math.max,u=Math.min;t.exports=function(t,n){var r=e(t);return r<0?o(r+n,0):u(r,n)}},function(t,n){t.exports=["constructor","hasOwnProperty","isPrototypeOf","propertyIsEnumerable","toLocaleString","toString","valueOf"]},function(t,n){n.f=Object.getOwnPropertySymbols},function(t,n,r){var e=r(6),o=/#|\.prototype\./,u=function(t,n){var r=f[i(t)];return r==a||r!=c&&("function"==typeof n?e(n):!!n)},i=u.normalize=function(t){return String(t).replace(o,".").toLowerCase()},f=u.data={},c=u.NATIVE="N",a=u.POLYFILL="P";t.exports=u}])}(n={exports:{}},n.exports),n.exports);(r=e)&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")&&r.default}));

!function(){"use strict"
function t(t,e){return(e||"")+" (SystemJS Error#"+t+" https://git.io/JvFET#"+t+")"}
var e,n="undefined"!=typeof Symbol,r="undefined"!=typeof self,i="undefined"!=typeof document,o=r?self:global
if(i){var u=document.querySelector("base[href]")
u&&(e=u.href)}if(!e&&"undefined"!=typeof location){var l=(e=location.href.split("#")[0].split("?")[0]).lastIndexOf("/");-1!==l&&(e=e.slice(0,l+1))}var s=/\\/g
function c(t,e){if(-1!==t.indexOf("\\")&&(t=t.replace(s,"/")),"/"===t[0]&&"/"===t[1])return e.slice(0,e.indexOf(":")+1)+t
if("."===t[0]&&("/"===t[1]||"."===t[1]&&("/"===t[2]||2===t.length&&(t+="/"))||1===t.length&&(t+="/"))||"/"===t[0]){var n,r=e.slice(0,e.indexOf(":")+1)
if(n="/"===e[r.length+1]?"file:"!==r?(n=e.slice(r.length+2)).slice(n.indexOf("/")+1):e.slice(8):e.slice(r.length+("/"===e[r.length])),
"/"===t[0])return e.slice(0,e.length-n.length-1)+t
for(var i=n.slice(0,n.lastIndexOf("/")+1)+t,o=[],u=-1,l=0;l<i.length;l++)-1!==u?"/"===i[l]&&(o.push(i.slice(u,l+1)),
u=-1):"."===i[l]?"."!==i[l+1]||"/"!==i[l+2]&&l+2!==i.length?"/"===i[l+1]||l+1===i.length?l+=1:u=l:(o.pop(),l+=2):u=l
return-1!==u&&o.push(i.slice(u)),e.slice(0,e.length-n.length)+o.join("")}}function f(t,e){return c(t,e)||(-1!==t.indexOf(":")?t:c("./"+t,e))}function a(t,e,n,r,i){for(var o in t){
var u=c(o,n)||o,l=t[o]
if("string"==typeof l){var s=d(r,c(l,n)||l,i)
s?e[u]=s:p("W1",o,l,"bare specifier did not resolve")}}}function h(t,e){if(e[t])return t
var n=t.length
do{var r=t.slice(0,n+1)
if(r in e)return r}while(-1!==(n=t.lastIndexOf("/",n-1)))}function v(t,e){var n=h(t,e)
if(n){var r=e[n]
if(null===r)return
if(!(t.length>n.length&&"/"!==r[r.length-1]))return r+t.slice(n.length)
p("W2",n,r,"should have a trailing '/'")}}function p(e,n,r,i){console.warn(t(e,"Package target "+i+", resolving target '"+r+"' for "+n))}function d(t,e,n){
for(var r=t.scopes,i=n&&h(n,r);i;){var o=v(e,r[i])
if(o)return o
i=h(i.slice(0,i.lastIndexOf("/")),r)}return v(e,t.imports)||-1!==e.indexOf(":")&&e}var g=n&&Symbol.toStringTag,m=n?Symbol():"@"
function y(){this[m]={}}var w,b=y.prototype
function O(t){return t.id}function P(t,e,n,r){if(t.onload(n,e.id,e.d&&e.d.map(O),!!r),n)throw n}function E(e,n,r){var i=e[m][n]
if(i)return i
var o=[],u=Object.create(null)
g&&Object.defineProperty(u,g,{value:"Module"})
var l=Promise.resolve().then((function(){return e.instantiate(n,r)})).then((function(r){if(!r)throw Error(t(2,"Module "+n+" did not instantiate"))
var l=r[1]((function(t,e){i.h=!0
var n=!1
if("string"==typeof t)t in u&&u[t]===e||(u[t]=e,n=!0)
else{for(var r in t){e=t[r]
r in u&&u[r]===e||(u[r]=e,n=!0)}t.__esModule&&(u.__esModule=t.__esModule)}if(n)for(var l=0;l<o.length;l++){var s=o[l]
s&&s(u)}return e}),2===r[1].length?{import:function(t){return e.import(t,n)},meta:e.createContext(n)}:void 0)
return i.e=l.execute||function(){},[r[0],l.setters||[]]}),(function(t){throw i.e=null,i.er=t,P(e,i,t,!0),t})),s=l.then((function(t){return Promise.all(t[0].map((function(r,i){
var o=t[1][i]
return Promise.resolve(e.resolve(r,n)).then((function(t){var r=E(e,t,n)
return Promise.resolve(r.I).then((function(){return o&&(r.i.push(o),!r.h&&r.I||o(r.n)),r}))}))}))).then((function(t){i.d=t}))}))
return i=e[m][n]={id:n,i:o,n:u,I:l,L:s,h:!1,d:void 0,e:void 0,er:void 0,E:void 0,C:void 0,p:void 0}}function x(t,e,n,r){if(!r[e.id])return r[e.id]=!0,
Promise.resolve(e.L).then((function(){return e.p&&null!==e.p.e||(e.p=n),Promise.all(e.d.map((function(e){return x(t,e,n,r)})))})).catch((function(n){if(e.er)throw n
throw e.e=null,P(t,e,n,!1),n}))}b.import=function(t,e){var n=this
return Promise.resolve(n.prepareImport()).then((function(){return n.resolve(t,e)})).then((function(t){var e=E(n,t)
return e.C||function(t,e){return e.C=x(t,e,e,{}).then((function(){return S(t,e,{})})).then((function(){return e.n}))}(n,e)}))},b.createContext=function(t){var e=this
return{url:t,resolve:function(n,r){return Promise.resolve(e.resolve(n,r||t))}}},b.onload=function(){},b.register=function(t,e){w=[t,e]},b.getRegister=function(){var t=w
return w=void 0,t}
var I=Object.freeze(Object.create(null)),R=Promise.prototype.finally||function(t){if("function"!=typeof t)return this.then(t,t)
const e=this.constructor||Promise
return this.then((n=>e.resolve(t()).then((()=>n))),(n=>e.resolve(t()).then((()=>{throw n}))))}
function S(t,e,n){if(n[e.id])return e.E
if(n[e.id]=!0,!e.e){if(e.er)throw e.er
return e.E?e.E:void 0}const r=e.e
var i
if(e.e=null,e.d.forEach((function(r){try{var o=S(t,r,n)
o&&(i=i||[]).push(o)}catch(n){throw e.er=n,P(t,e,n,!1),n}})),i)return e.E=R.call(Promise.all(i).then(u),(function(){e.E=null}))
var o=u()
if(o)return e.E=R.call(o,(function(){e.E=null}))
function u(){try{var n=r.call(I)
if(n)return n=n.then((function(){e.C=e.n,P(t,e,null,!0)}),(function(n){throw e.er=n,P(t,e,n,!0),n}))
e.C=e.n,e.L=e.I=void 0}catch(t){throw e.er=t,t}finally{P(t,e,e.er,!0)}}}o.System=new y,b.instantiate=function(t,e){throw new Error(`Unable to instantiate ${t} from ${e}`)}
let j=e
const C={imports:{},scopes:{}}
function M(t,e){!function(t,e,n){var r
for(r in t.imports&&a(t.imports,n.imports,e,n,null),t.scopes||{}){var i=f(r,e)
a(t.scopes[r],n.scopes[i]||(n.scopes[i]={}),e,n,i)}for(r in t.depcache||{})n.depcache[f(r,e)]=t.depcache[r]
for(r in t.integrity||{})n.integrity[f(r,e)]=t.integrity[r]}(t,e||j,C)}function $(t){return function(e){const n=this
let r
try{r=t(e)}catch(t){return Promise.reject(t)}return function(t){return Boolean(t&&"function"==typeof t.then)}(r)?new Promise((t=>r.then((()=>{t(n.getRegister())
})))):n.getRegister()}}function _(t,e){const n=b.instantiate
b.instantiate=function(r,i){const o=r.substr(0,t.length)===t?r.substr(t.length):null
return null===o?n.call(this,r,i):e.call(this,o,i)}}b.resolve=function(t,e){return d(C,c(t,e=e||j)||t,e)||function(t,e){throw new Error(`Unresolved id: ${t} from parentUrl: ${e}`)
}(t,e)},function(t){var e=t.System
u(e)
var n,r=e.constructor.prototype,i=e.constructor,o=function(){i.call(this),u(this)}
function u(t){t.registerRegistry=Object.create(null)}o.prototype=r,e.constructor=o
var l=r.register
r.register=function(t,e,r){if("string"!=typeof t)return l.apply(this,arguments)
var i=[e,r]
return this.registerRegistry[t]=i,n||(n=i,Promise.resolve().then((function(){n=null}))),l.apply(this,arguments)}
var s=r.resolve
r.resolve=function(t,e){try{return s.call(this,t,e)}catch(e){if(t in this.registerRegistry)return t
throw e}}
var c=r.instantiate
r.instantiate=function(t,e){var n=this.registerRegistry[t]
return n?(this.registerRegistry[t]=null,n):c.call(this,t,e)}
var f=r.getRegister
r.getRegister=function(){var t=f.call(this),e=n||t
return n=null,e}}("undefined"!=typeof self?self:global),b.prepareImport=function(t){},b.warmup=function({pathname:t="/",importMap:e,importMapUrl:n,defaultHandler:r,handlers:i}){
if(function(t){j=t}(`no-schema:${t}`),M(e,`no-schema:/${n}`),r&&_("no-schema:",$(r)),i)for(const t of Object.keys(i))_(t,$(i[t]))}}()

// Adapt for IOS, swap if opposite
if (canvas){
    var _w = canvas.width;
    var _h = canvas.height;
    if (screen.width < screen.height) {
        if (canvas.width > canvas.height) {
            _w = canvas.height;
            _h = canvas.width;
        }
    } else {
        if (canvas.width < canvas.height) {
            _w = canvas.height;
            _h = canvas.width;
        }
    }
    canvas.width = _w;
    canvas.height = _h;
}
// Adjust initial canvas size
if (canvas && window.devicePixelRatio >= 2) {canvas.width *= 2; canvas.height *= 2;}

const importMap={imports:{cc:"./../cocos-js/cc.5cfea.js"}}

System.warmup({
    importMap,
    importMapUrl: 'import-map.js',
    defaultHandler: (urlNoSchema) => {
        require('.' + urlNoSchema);
    },
    handlers: {
        'plugin:': (urlNoSchema) => {
            requirePlugin(urlNoSchema);
        },
        'project:': (urlNoSchema) => {
            require(urlNoSchema);
        },
    },
});

var Application=function(){var t
function n(){this.settingsPath="src/settings.json",this.showFPS=!0}var i=n.prototype
return i.init=function(n){(t=n).game.onPostBaseInitDelegate.add(this.onPostInitBase.bind(this)),t.game.onPostSubsystemInitDelegate.add(this.onPostSystemInit.bind(this))},
i.onPostInitBase=function(){},i.onPostSystemInit=function(){},i.start=function(){return t.game.init({debugMode:t.DebugMode.INFO,settingsPath:this.settingsPath,overrideSettings:{
profiling:{showFPS:this.showFPS}}}).then((function(){return t.game.run()}))},n}()

firstScreen.start('default', 'default', 'false')
  .then(() => {
    return firstScreen.setProgress(0.2).then(() => Promise.resolve());
}).then(() => {
    return new Application();
}).then((application) => {
    return firstScreen.setProgress(0.4).then(() => Promise.resolve(application));
}).then((application) => {
    return onApplicationCreated(application);
}).catch((err) => {
    console.error(err);
});

function onApplicationCreated(application) {
    return System.import('cc').then((module) => {
        return firstScreen.setProgress(0.6).then(() => Promise.resolve(module));
    }).then((cc) => {
        require('./engine-adapter.bf796c');
        return application.init(cc);
    }).then(() => {
        return firstScreen.end().then(() => application.start());
    });
}

}  // init app

// NOTE: on WeChat Android end, we can only get the correct screen size at the second tick of game.
var sysInfo = wx.getSystemInfoSync();
if (sysInfo.platform.toLocaleLowerCase() === 'android') {
    GameGlobal.requestAnimationFrame (__initApp);
} else {
    __initApp();
}
