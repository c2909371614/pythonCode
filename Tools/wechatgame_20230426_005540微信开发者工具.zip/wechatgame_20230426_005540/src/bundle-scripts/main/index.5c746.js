System.register("chunks:///main.js",["cc"],(function(){"use strict"
var e,t,i,n,r,o,s,a,l,h,c,u,p,d,f,m,_,g,y,v,b,T,w,I,S,R,x,C,O,P,L,E,D,A,F,z,k,B,N,M,H,G,V,U,W,j,Y,X,$,q,J,Z,K,Q,ee,te,ie,ne,re,oe,se,ae,le,he,ce,ue,pe,de,fe,me,_e,ge,ye,ve,be,Te,we,Ie,Se
return{setters:[function(Re){e=Re.cclegacy,t=Re.Component,i=Re.CCObject,n=Re._decorator,r=Re.js,o=Re.ccenum,s=Re.UITransform,a=Re.Widget,l=Re.Node,h=Re.CCString,c=Re.NodeEventType,
u=Re.sys,p=Re.instantiate,d=Re.Label,f=Re.director,m=Re.Prefab,_=Re.isValid,g=Re.error,y=Re,v=Re.assetManager,b=Re.SpriteAtlas,T=Re.rect,w=Re.v2,I=Re.size,S=Re.Texture2D,
R=Re.Asset,x=Re.SpriteFrame,C=Re.EventTarget,O=Re.warn,P=Re.ImageAsset,L=Re.BufferAsset,E=Re.JsonAsset,D=Re.TextAsset,A=Re.settings,F=Re.Graphics,z=Re.Vec3,k=Re.view,B=Re.screen,
N=Re.Rect,M=Re.Camera,H=Re.Color,G=Re.input,V=Re.Input,U=Re.Mask,W=Re.Sprite,j=Re.RichText,Y=Re.Vec2,X=Re.KeyCode,$=Re.UIOpacity,q=Re.macro,J=Re.dynamicAtlasManager,Z=Re.game,
K=Re.isDisplayStats,Q=Re.setDisplayStats,ee=Re.ResolutionPolicy,te=Re.SafeArea,ie=Re.tween,ne=Re.Size,re=Re.path,oe=Re.gfx,se=Re.RenderData,ae=Re.Button,le=Re.CCFloat,
he=Re.CCBoolean,ce=Re.CCInteger,ue=Re.ScrollView,pe=Re.Layout,de=Re.PageViewIndicator,fe=Re.EventHandler,me=Re.Layers,_e=Re.math,ge=Re.Slider,ye=Re.Enum,ve=Re.sp,
be=Re.ToggleContainer,Te=Re.Tween,we=Re.EditBox,Ie=Re.PageView,Se=Re.EventTouch}],execute:function(){function Re(e,t,i,n,r,o,s){try{var a=e[o](s),l=a.value}catch(e){
return void i(e)}a.done?t(l):Promise.resolve(l).then(n,r)}function xe(e){return function(){var t=this,i=arguments
return new Promise((function(n,r){var o=e.apply(t,i)
function s(e){Re(o,n,r,s,a,"next",e)}function a(e){Re(o,n,r,s,a,"throw",e)}s(void 0)}))}}function Ce(e,t){for(var i=0;i<t.length;i++){var n=t[i]
n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n)}}function Oe(e,t,i){return t&&Ce(e.prototype,t),i&&Ce(e,i),
Object.defineProperty(e,"prototype",{writable:!1}),e}function Pe(){return(Pe=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var i=arguments[t]
for(var n in i)Object.prototype.hasOwnProperty.call(i,n)&&(e[n]=i[n])}return e}).apply(this,arguments)}function Le(e,t){e.prototype=Object.create(t.prototype),
e.prototype.constructor=e,Ee(e,t)}function Ee(e,t){return(Ee=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(e,t){return e.__proto__=t,e})(e,t)}function De(e){
if(void 0===e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called")
return e}function Ae(e,t){(null==t||t>e.length)&&(t=e.length)
for(var i=0,n=new Array(t);i<t;i++)n[i]=e[i]
return n}function Fe(e,t){var i="undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"]
if(i)return(i=i.call(e)).next.bind(i)
if(Array.isArray(e)||(i=function(e,t){if(e){if("string"==typeof e)return Ae(e,t)
var i=Object.prototype.toString.call(e).slice(8,-1)
return"Object"===i&&e.constructor&&(i=e.constructor.name),"Map"===i||"Set"===i?Array.from(e):"Arguments"===i||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(i)?Ae(e,t):void 0}
}(e))||t&&e&&"number"==typeof e.length){i&&(e=i)
var n=0
return function(){return n>=e.length?{done:!0}:{done:!1,value:e[n++]}}}
throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}function ze(e,t,i,n){
i&&Object.defineProperty(e,t,{enumerable:i.enumerable,configurable:i.configurable,writable:i.writable,value:i.initializer?i.initializer.call(n):void 0})}function ke(e,t,i,n,r){
var o={}
return Object.keys(n).forEach((function(e){o[e]=n[e]})),o.enumerable=!!o.enumerable,o.configurable=!!o.configurable,("value"in o||o.initializer)&&(o.writable=!0),
o=i.slice().reverse().reduce((function(i,n){return n(e,t,i)||i}),o),r&&void 0!==o.initializer&&(o.value=o.initializer?o.initializer.call(r):void 0,o.initializer=void 0),
void 0===o.initializer&&(Object.defineProperty(e,t,o),o=null),o}var Be,Ne=Object.freeze({__proto__:null,HTML5:!1,NATIVE:!1,WECHAT:!0,BAIDU:!1,XIAOMI:!1,ALIPAY:!1,TAOBAO:!1,
BYTEDANCE:!1,OPPO:!1,VIVO:!1,HUAWEI:!1,COCOSPLAY:!1,QTT:!1,LINKSURE:!1,EDITOR:false,PREVIEW:!1,BUILD:!0,TEST:!1,DEBUG:!1,DEV:!1,MINIGAME:!0,RUNTIME_BASED:!1,SUPPORT_JIT:!1,JSB:!1,
NET_MODE:0})
function Me(e,t,i,n,r){void 0===t&&(t=null),void 0===i&&(i=null),void 0===n&&(n=0),void 0===r&&(r=Be.GET)
var o=""
if(t){for(var s=Object.getOwnPropertyNames(t),a=[],l=0;l<s.length;l++){var h=s[l]
h&&"undefined"!=t[h]&&null!=t[h]&&a.push(h+"="+t[h])}a.length&&(o=a.join("&"),r==Be.GET&&(e+="?"+o))}var c=!1,u=!1,p=0
n&&(p=setTimeout((function(){u||(c=!0,p=0,i&&i(null))}),1e3*n))
var d=new XMLHttpRequest
d.open(r,e),d.setRequestHeader("Content-type","application/json"),d.onreadystatechange=function(){if(4===d.readyState){if(c)return
if(p&&(clearTimeout(p),p=0),u=!0,d.status>=200&&d.status<400){var t=d.responseText
console.log("---URL: "+e+"\n response: "+t),i&&t&&i(t)}else i&&(console.log("---URL: "+e+" fail request"),i(null))}},d.send(t&&r==Be.POST?t:null)}
e._RF.push({},"c73b9pduQtB9opwrx9XMZb+","XmlHttpUtil",void 0),function(e){e.GET="GET",e.POST="POST"}(Be||(Be={})),e._RF.pop(),
e._RF.push({},"74bdeaIZ4pEQrGTaa2mqBLT","LoaderCache",void 0)
var He={Uncache:0,RefTick:1,RefCycle:2,RefTime:3,RefConfigData:4,RefTex:5,Medium:6,Long:7}
e._RF.pop(),e._RF.push({},"d9e39u4w59D3psdxqY7/cTg","LaunchPanelId",void 0)
var Ge="Loading"
function Ve(e,t){var i=t._all_delegate_cache_
null==i&&(i=new WeakMap,t._all_delegate_cache_=i)
var n=i.get(e)
return null==n&&(n=e.bind(t),i.set(e,n)),n}e._RF.pop(),e._RF.push({},"ac00dLf/j5LCryeyd15flmq","_CreateDelegate",void 0),e._RF.pop(),
e._RF.push({},"2fe02bjgPFBa6R02QSeJcGb","_bindClsInstance",void 0)
var Ue,We,je,Ye,Xe,$e,qe,Je=new Map,Ze=t.prototype,Ke=i.Flags.LogicInit,Qe=i.Flags.LogicClear,et=i.Flags.LogicDestroyed
function tt(e,t){var i
return nt(i=1==it(t)?e.getComponent(t)||e.addComponent(t):e.getCNode(t)),i}function it(e){var t=Je.get(e)
if(null==t){for(var i=!1,n=e.prototype;null!=n;){if(n==Ze){i=!0
break}n=Object.getPrototypeOf(n)}t=i?1:2,Je.set(e,t)}return t}function nt(e){null==e._initBinder&&null==e.InitView||(null==e._objFlags&&(e._objFlags=0),
0==(e._objFlags&Ke)&&(e._objFlags|=Ke,null!=e._initBinder&&e._initBinder(),null!=e.InitView&&e.InitView()))}e._RF.pop(),
e._RF.push({},"01643CU7hJHt60N03v+dvIz","_ScriptBinder",void 0)
var rt,ot,st,at,lt,ht,ct,ut,pt,dt,ft,mt,_t,gt,yt,vt=n.ccclass,bt=n.property,Tt=n.menu,wt=(Ue=vt("app/ScriptBinder"),We=Tt("app/ScriptBinder"),je=bt({
formerlySerializedAs:"scriptName"}),Ye=bt({tooltip:'@ccclass("scriptName")'}),Ue(Xe=We((qe=ke(($e=function(e){function t(){
for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"_scriptName",qe,De(t)),t}Le(t,e)
var i=t.prototype
return i._editorCheckScriptName=function(){var e=this
REAL_EDITOR&&this.scriptName&&Editor.Message.request("cc-plugin","queryClassPath",this.scriptName).then((function(t){
t||console.error("cannot find ccclass by ScriptBinder.scriptName '"+e.scriptName+"'")}))},i.onLoad=function(){if(this.scriptName){var e=r.getClassByName(this.scriptName)
null!=e?tt(this.node,e):console.error("cannot find ccclass by ScriptBinder.scriptName '"+this.scriptName+"'")}},Oe(t,[{key:"scriptName",get:function(){return this._scriptName},
set:function(e){this._scriptName=e,REAL_EDITOR&&(this.unschedule(this._editorCheckScriptName),e&&this.scheduleOnce(this._editorCheckScriptName,.8))}}]),t
}(t)).prototype,"_scriptName",[je],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return""}}),
ke($e.prototype,"scriptName",[Ye],Object.getOwnPropertyDescriptor($e.prototype,"scriptName"),$e.prototype),Xe=$e))||Xe)||Xe)
e._RF.pop(),e._RF.push({},"78efc1zD/lClJ/HsV9YceWS","_PrefabBinderItem",void 0)
var It,St=n.ccclass,Rt=n.property
n.disallowMultiple,n.type,function(e){e[e.comp=0]="comp",e[e.node=1]="node",e[e.clsname=2]="clsname"}(It||(It={})),o(It)
var xt,Ct,Ot,Pt,Lt,Et,Dt,At,Ft,zt,kt,Bt=(rt=St("PrefabBinderItem"),ot=Rt(t),st=Rt({type:t}),at=Rt({type:It}),lt=Rt({type:It}),ht=Rt({visible:function(){
return this._propType==It.clsname}}),ct=Rt({editorOnly:!0}),ut=Rt({readonly:!0}),rt((ft=ke((dt=function(){function e(){ze(this,"propName",ft,this),ze(this,"_comp",mt,this),
ze(this,"_propType",_t,this),ze(this,"_clsName",gt,this),ze(this,"_propCls",yt,this)}return e.prototype._updateCls=function(){var e=""
switch(this.propType){case It.comp:this._comp&&(e=Nt(this._comp))
break
case It.node:e="Node"
break
case It.clsname:if(this._comp&&(!this._clsName||"LuaComponent"==this._clsName)){var t=this._comp.getComponent(wt)
t&&(this._clsName=t.scriptName)}e=this._clsName}this.propCls=e},Oe(e,[{key:"comp",get:function(){return this._comp},set:function(e){var t=null
if(e&&(this.propName||(this.propName=e.node.name),e instanceof s||e instanceof a))for(var i=e.node.components,n=0;n<i.length;n++){var r=i[n],o=Nt(r)
if("cc.UITransform"!==o&&"cc.Widget"!==o&&"app/PrefabBinder"!==o&&"app/ScriptBinder"!==o&&"app/UIBinder"!==o){t=r
break}}this._comp=t||e,this._updateCls()}},{key:"propType",get:function(){return this._propType},set:function(e){e!=this._propType&&(this._propType=e,this._updateCls())}},{
key:"clsName",get:function(){return this._clsName},set:function(e){e!=this._clsName&&(this._clsName=e,this._updateCls())}},{key:"propCls",get:function(){return this._propCls},
set:function(e){this._propCls=e}}]),e}()).prototype,"propName",[Rt],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return""}}),mt=ke(dt.prototype,"_comp",[ot],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),ke(dt.prototype,"comp",[st],Object.getOwnPropertyDescriptor(dt.prototype,"comp"),dt.prototype),
_t=ke(dt.prototype,"_propType",[at],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return It.comp}}),
ke(dt.prototype,"propType",[lt],Object.getOwnPropertyDescriptor(dt.prototype,"propType"),dt.prototype),gt=ke(dt.prototype,"_clsName",[Rt],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return""}}),ke(dt.prototype,"clsName",[ht],Object.getOwnPropertyDescriptor(dt.prototype,"clsName"),dt.prototype),
yt=ke(dt.prototype,"_propCls",[ct],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return""}}),
ke(dt.prototype,"propCls",[ut],Object.getOwnPropertyDescriptor(dt.prototype,"propCls"),dt.prototype),pt=dt))||pt)
function Nt(e){var t=e.constructor,i=r._nameToClass,n=""
for(var o in i)if(i[o]===t){n=o
break}return n||console.error("cannot find compClsName '"+t.name+"'"),n}e._RF.pop(),e._RF.push({},"b9de6+xqfJIoaNHUtnaQNUK","_PrefabBinder",void 0)
var Mt,Ht,Gt,Vt,Ut,Wt,jt,Yt,Xt,$t,qt,Jt=n.ccclass,Zt=n.property,Kt=n.disallowMultiple,Qt=n.menu,ei=(xt=Jt("app/PrefabBinder"),Ct=Qt("app/PrefabBinder"),Ot=Zt({editorOnly:!0}),
Pt=Zt(Bt),Lt=Zt({visible:!1,editorOnly:!0}),xt(Et=Ct(Et=Kt(((kt=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"filePath",At,De(t)),ze(t,"items",Ft,De(t)),ze(t,"bundle",zt,De(t)),t._inited=!1,t}Le(t,e)
var i=t.prototype
return i.onLoad=function(){this._inited||this._init()},i._init=function(){if(this._inited=!0,GAMEPLAY)for(var e=this.items,t=0;t<e.length;t++){var i=e[t]
if(i.propType==It.clsname&&i._clsName&&i._comp){var n=r.getClassByName(i._clsName)
null!=n?tt(i._comp.node,n):console.error("cannot find ccclass by PrefabBinderItem.clsName '"+i.clsName+"'")}}},t}(t)).PropType=It,At=ke((Dt=kt).prototype,"filePath",[Ot],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return""}}),Ft=ke(Dt.prototype,"items",[Pt],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){
return[]}}),zt=ke(Dt.prototype,"bundle",[Lt],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return""}}),Et=Dt))||Et)||Et)||Et)
e._RF.pop(),e._RF.push({},"c04f1VLo/NGW7bTm4bpHF/3","_UIBinder",void 0)
var ti,ii,ni=n.ccclass,ri=n.property,oi=n.disallowMultiple,si=(Mt=ni("app/UIBinder"),Ht=ri({type:[l],visible:!1}),Gt=ri({type:[t],visible:!1}),Vt=ri({type:[h],visible:!1}),Ut=ri({
visible:!1,editorOnly:!0}),Mt(Wt=oi((Yt=ke((jt=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"nodes",Yt,De(t)),ze(t,"comps",Xt,De(t)),ze(t,"cNames",$t,De(t)),ze(t,"bundle",qt,De(t)),t}return Le(t,e),t
}(t)).prototype,"nodes",[Ht],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return[]}}),Xt=ke(jt.prototype,"comps",[Gt],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return[]}}),$t=ke(jt.prototype,"cNames",[Vt],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return[]}}),
qt=ke(jt.prototype,"bundle",[Ut],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return""}}),Wt=jt))||Wt)||Wt)
function ai(e,t){if(REAL_EDITOR)try{throw new Error('cannot serialize assignBinder in Editor >>> "class '+e.constructor.name+' extends BinderComponent" <<< ???')}catch(e){
console.error(e)}else if(t._cnode)t._cnode!=e&&console.error("error assignBinder")
else{var i=t.getComponent(ei)
if(i){i._inited||i._init()
for(var n=i.items,o=0,s=n.length;o<s;o++){var a=n[o],l=a.comp
if(l)switch(a.propType){case It.comp:e[a.propName]=l
break
case It.node:e[a.propName]=l.node
break
case It.clsname:if(a.clsName){var h=r.getClassByName(a.clsName)
null!=h?e[a.propName]=tt(l.node,h):console.error("cannot find ccclass by PrefabBinderItem.clsName '"+a.clsName+"'")}}}}else{var c=t.getComponent(si)
if(!c)return
for(var u=c.nodes,p=0;p<u.length;p++){var d=u[p]
e[d.name]=d}for(var f=c.cNames,m=f.length,_=c.comps,g=_.length,y=0,v=g-m;y<v;y++)if(null!=_[y]){var b=_[y]
e[b.node.name]=b}if(m>0)for(var T=y;y<g;y++)e[f[y-T]]=_[y]}null==e.node&&(e.node=t),t._cnode=e}}e._RF.pop(),e._RF.push({},"14e73dE2yxJxasS66vLGE1j","_assignBinder",void 0),
e._RF.pop(),e._RF.push({},"edc6bLH7eNAG6U0SO+x6ccw","_BinderComponent",void 0)
var li=(0,n.ccclass)("app/BinderComponent")(((ii=function(e){function t(t){var i
return(i=e.call(this)||this).__onClick=null,i.isExclusionPanel=!1,i.isKillAllExcluded=!1,t&&ai(De(i),t),i}Le(t,e)
var i=t.prototype
return i._initializeProperty=function(){null==this._objFlags&&(this._objFlags=0),this.__onClick=null},i._initBinder=function(){},i.InitView=function(){},
i.__beforeOnEnable=function(){t.__addObserver&&t.__addObserver(this)},i.__beforeOnDisable=function(){t.__removeObserver&&t.__removeObserver(this)},i.CreateDelegate=function(e){
return Ve(e,this)},i.SetItemClickGo=function(e){this.onClick&&(e instanceof l?e.on(c.TOUCH_END,this.onClick):e.node.on(c.TOUCH_END,this.onClick))},Oe(t,[{key:"onClick",
get:function(){return this.__onClick},set:function(e){e&&this.__onClick&&this.__onClick!=e&&console.error("error onClick"),this.__onClick=e}}]),t}(t)).__addObserver=void 0,
ii.__removeObserver=void 0,ti=ii))||ti
function hi(e){return function(){return e}}e._RF.pop(),e._RF.push({},"16934A4OmNP7IgxGY8P2CGi","_MIX",void 0),e._RF.pop(),
e._RF.push({},"708b4pw14hCVZGGU2OFkF0a","LaunchProcessId",void 0)
e._RF.pop(),e._RF.push({},"e75720EH2VLAq2+0HiZHMta","LaunchLoginController",void 0)
var ci=function(){function e(){this._processedIds=new Set,this._processList=[],this._isPackageLoadStart=!1}var t=e.prototype
return t.setup=function(){var e=this,t=this._processList
MiniPlatController.sendClick(5),t.push((function(){e._localLoginProcess()})),t.push((function(){e._startLoginProcess()})),t.push((function(){e._sdkInitProcess()})),
t.push((function(){e._sdkLoginProcess()})),t.push((function(){e._importServerProcess()})),t.push((function(){e._serverListProcess()})),t.push((function(){e._loginCheckProcess()})),
t.push((function(){e._finishLoginProcess()})),this.nextProcess(1)},t._localLoginProcess=function(){if(launcher.config.isSdkMode)return this.nextProcess(2)
pn.parseLoginInfo()
var e=launcher.config
if(e.socketIp&&e.socketPort&&e.serverId&&launcher.userName)return this.nextProcess(2)
mi.ins.openLocalLoginPanel()},t._startLoginProcess=function(){console.log("--lauch start login")
var e=!1
return u.isBrowser&&"true"==new URL(window.location.href).searchParams.get("skipstart")&&(e=!0),e?(pn.parseLoginInfo(),mi.ins.switchLoadingView(!0),
this.nextProcess(3)):(mi.ins.switchLoadingView(!0),this.nextProcess(3))},t._sdkInitProcess=function(){if(console.log("--lauch sdk init"),
!launcher.config.isSdkMode)return this.nextProcess(4)
MiniPlatController.ins.sdkInitProcess()},t._sdkLoginProcess=function(){if(console.log("--lauch sdk login"),!launcher.config.isSdkMode)return this.nextProcess(5)
MiniPlatController.ins.sdkLoginProcess()},t._importServerProcess=function(){if(console.log("--lauch importServer"),!launcher.config.isSdkMode)return this.nextProcess(6)
MiniPlatController.ins.importServerProcess()},t._serverListProcess=function(){if(console.log("--lauch serverList"),!launcher.config.isSdkMode)return this.nextProcess(7)
MiniPlatController.ins.serverListProcess()},t._loginCheckProcess=function(){if(console.log("--lauch loginCheck"),!launcher.config.isSdkMode)return this.nextProcess(8)
MiniPlatController.ins.loginCheckProcess()},t._finishLoginProcess=function(){if(console.log("--lauch finishLogin"),!launcher.config.isSdkMode)return this.nextProcess(9)
MiniPlatController.ins.finishLoginProcess()},t._beginLoadingProcess=function(){mi.ins.switchLoadingView(!0)},e.nextProcess=function(e){throw new Error("Method not implemented.")},
t.loadPackageProcess=function(){this._isPackageLoadStart||(this._isPackageLoadStart=!0,MiniPlatController.sendClick(22),
hn.loadPackages(launcher.config.subpackages.preload,(function(){launcher.isSubpackLoaded=!0,
launcher.isSDKLogined&&launcher._gameBaseInterfaces&&(launcher._gameBaseInterfaces.init(),launcher._gameBaseInterfaces.preload(),launcher._gameBaseInterfaces.setup())})))},
t.nextProcess=function(e){if(this._processedIds.has(e))console.error("repeat processId '"+e+"'")
else if(this._processedIds.add(e),this._processList.length){var t=this._processList.shift()
t&&t()}},Oe(e,null,[{key:"ins",get:function(){return this._ins||(this._ins=new e),this._ins}}]),e}()
ci._ins=void 0,e._RF.pop(),e._RF.push({},"8d0d76eGENL6bPK2v+4EwOw","LaunchLoadingPanel",void 0)
var ui=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return(t=e.call.apply(e,[this].concat(n))||this)._maskW=0,t._testStartTime=0,t._testEndTime=0,t.isHideMsg=!1,t}Le(t,e)
var i=t.prototype
return i.onLoad=function(){this._maskW=this.frontimage.node.transform.width},i.onEnable=function(){
__$LaunchLogicBridge._getLaunchPanelCtrl().isMiniStageForLoginPanel?(__$LaunchLogicBridge._getLaunchPanelCtrl().isMiniStageForLoginPanel=!1,MiniPlatController.sendClick(21),
this.isHideMsg=!0,this.textContain.active=!1,this.ageBtn.node.active=!1):this.isHideMsg&&(this.isHideMsg=!1,this.textContain.active=!0,this.ageBtn.node.active=!0),
ci.ins.loadPackageProcess(),mi.ins.closeOtherView(Ge),this.ageBtn.node.on(c.TOUCH_END,this.onAgeBtnClick,this),this._testStartTime=cus.currTime,this._testEndTime=cus.currTime+1e3},
i.lateUpdate=function(){var e=launcher._loadingVo
e.percent=(cus.currTime-this._testStartTime)/(this._testEndTime-this._testStartTime),this.updatePercent(e.percent)},i.updatePercent=function(e){e<0?e=0:e>1&&(e=1),
this.frontimage.node.transform.width=this._maskW*e
var t=100*e>>0
this.progressLabel.string=t+"%"},i.onAgeBtnClick=function(){mi.ins.policyState=0,mi.ins.openPolicyPanel()},t}(hi(li)())
e._RF.pop(),e._RF.push({},"76eddDdwaxAHaArJSu/mMKT","LaunchLocalLoginPanel",void 0)
var pi=function(e){function t(){return e.apply(this,arguments)||this}Le(t,e)
var i=t.prototype
return i.onLoad=function(){
var e=this,t=u.localStorage.getItem("ip")||"",i=u.localStorage.getItem("port")||"",n=u.localStorage.getItem("op")||"mainland",r=u.localStorage.getItem("server")||"",o="",s=t&&u.localStorage.getItem(t+"username")||""
if(s){var a=JSON.parse(s)
a&&(o=a[0]||"")}this.ipt_account.string=o,this.ipt_server.string=t,this.ipt_port.string=i,this.ipt_op.string=n,this.ipt_serverId.string=r,
this.btn_login.on(c.TOUCH_END,this._onBtnLogin,this),this.serverList.node.active=!1,pn.reqLocalServerList((function(t){t&&e._renderServerList(e.serverList,t.server)}))},
i._onBtnLogin=function(){
var e=this.ipt_account.string.trim(),t=this.ipt_server.string.trim(),i=Number(this.ipt_port.string.trim()),n=this.ipt_serverId.string.trim(),r=this.ipt_op.string.trim()
if(e&&t&&i&&n){var o
u.localStorage.setItem("ip",t),u.localStorage.setItem("port",""+i),u.localStorage.setItem("server",n),u.localStorage.setItem("op",r)
var s=t+"username",a=u.localStorage.getItem(s)||""
if(a)if(o=JSON.parse(a),Array.isArray(o)){var l=o.indexOf(e)
l>=0&&o.splice(l,1),o.unshift(e)}else o=[e]
else o=[e]
if(u.localStorage.setItem(s,JSON.stringify(o)),u.isBrowser)pn.jumpWebLink(t,i,n,e,r,launcher.config.referer)
else{var h=launcher.config
h.socketIp=t,h.socketPort=i,h.serverId=n,h.op=r,launcher.userName=e,ci.ins.nextProcess(3)}}},i._renderServerList=function(e,t){if(t){e.node.active=!0
for(var i=e.content,n=Math.max(t.length,i.children.length),r=0;r<n;r++){var o=i.children[r],s=t[r]
if(s){o||(o=p(i.children[0]),i.addChild(o)),o.active=!0
var a=o.getComponentInChildren(d)
a&&(a.string=s.label),o.on(c.TOUCH_END,this._onServerItemClick,this,!1,[s])}else o&&(o.active=!1)}}},i._onServerItemClick=function(e){this.ipt_server.string=e.ip,
this.ipt_port.string=""+e.port,this.ipt_serverId.string=e.server,this.ipt_op.string=e.op||"mainland"},t}(hi(li)())
e._RF.pop(),e._RF.push({},"7386ajtOQtMxJUhTvnt7oMG","LaunchPolicyPanel",void 0)
var di=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return(t=e.call.apply(e,[this].concat(n))||this).titleArr=["适龄提示","用户协议","隐私政策"],t.jsonArr=["age","userProtocol","privacyPolicy"],t.policyState=0,t.isTrueSelect=!1,t.ageStr="",t}
Le(t,e)
var i=t.prototype
return i.onLoad=function(){
this.updateView(),this.AddOrDelEvent(!0),this.ageStr="（1）本游戏是一款角色扮演类游戏，适用于年满 16 周岁及以上的用户，建议未成年人在家长监护下使用游戏产品（2）本游戏通过游戏环境内的交互、打怪通关等玩法推进剧情。游戏中有基于文字的陌生人社交系统。（3）本游戏中有用户实名认证系统，认证为未成年人的用户将接受以下管理：游戏中部分玩法和道具需要付费。未满 8 周岁的用户不能付费；8 周岁以上未满 16 周岁的未成年人用户，单次充值金额不得超过 50 元人民币，每月充值金额累计不得超过 200 元人民币；16 周岁以上的未成年人用户，单次充值金额不得超过 100 元人民币，每月充值金额累计不得超过 400 元人民币。未成年人仅允许在周五、周六、周日及法定节假日的20时-21时进行游戏。（4）本游戏以架空时间观为主题，游戏有强策略的搭配通关玩法，需要玩家自行搭配不同的角色、互相配合和切磋，有助于培养玩家思维逻辑能力。"
},i.onEnable=function(){},i.updateView=function(){var e=this
this.policyState=__$LaunchLogicBridge._getLaunchPanelCtrl().policyState,this.contextLabel.string=this.ageStr,this.titleLabel.string=this.titleArr[this.policyState],
this.sureLabel.string="确定",hn.listenRes(hn.loadBundleRes("texts/"+this.jsonArr[this.policyState],"launch"),(function(t){e.contextLabel.string=t,
e.content.heightSet(e.contextLabel.height())}))},i.selectHandler=function(){this.isTrueSelect=!this.isTrueSelect},i.onCloseClick=function(){mi.ins.closeOtherView(Ge)},
i.AddOrDelEvent=function(e){e?this.sureBtn.node.on(c.TOUCH_END,this.onCloseClick,this):this.sureBtn.node.off(c.TOUCH_END,this.onCloseClick,this)},i.Clear=function(){},
i.Destroy=function(){},t}(hi(li)())
e._RF.pop(),e._RF.push({},"c5d6dwSAcFCmbS19orE+NT8","LaunchStartLoginPanel",void 0)
var fi=function(e){function t(){return e.apply(this,arguments)||this}Le(t,e)
var i=t.prototype
return i.onEnable=function(){this.btn_login.node.on(c.TOUCH_END,this._btnLogin,this)},i._btnLogin=function(){ci.ins.nextProcess(10)},t}(hi(li)())
e._RF.pop(),e._RF.push({},"7934bUIQG1L3pTtq8m+fJ0A","LaunchPanelController",void 0)
var mi=function(){function e(){this.policyState=0,this.isMiniStageForLoginPanel=!1,this._layerLaunch=null,this._openIds=new Set,this._openPanelNodes=new Map,
this._retainIds=new Map,this._loadingViewActive=!1}var t=e.prototype
return t.setup=function(){this._layerLaunch=f.getScene().getChildByName("UICanvas").getChildByName("LayerLaunch"),
this._layerLaunch.parent.on(c.CHILD_ADDED,this._onLayerParentChange,this),launcher._loadingVo||(launcher._loadingVo={txt0:"",percent:0})},t.openLocalLoginPanel=function(){
this.openPanel("LocalLogin",{prefab:["ui/ui_login_localloginpanel","launch"],scriptCls:pi,removeOther:!0},this._layerLaunch)},t.openStartLoginPanel=function(){
this.openPanel("StartLogin",{prefab:["ui/ui_login_view","launch"],scriptCls:fi,removeOther:!0},this._layerLaunch)},t.openPolicyPanel=function(){this.openPanel("Policy",{
prefab:["ui/ui_login_policy_view","launch"],scriptCls:di,removeOther:!1},this._layerLaunch)},t.switchLoadingView=function(e){var t=this
this._loadingViewActive=e
var i=this._openPanelNodes.get(Ge)
i&&(i.active=e),e&&!i&&this.openPanel(Ge,{prefab:["ui/ui_login_loading","launch"],scriptCls:ui,removeOther:!0},this._layerLaunch,(function(e){e.active=t._loadingViewActive}))},
t.openPanel=function(e,t,i,n){var r=this
if(this._layerLaunch&&!this._openIds.has(e)){this._openIds.add(e)
var o=hn.loadAssetFormat(t.prefab,m,He.RefTick)
this._addRetain(e,o),hn.listenRes(o,(function(o){if(r._openIds.has(e)&&r._layerLaunch&&i&&_(i,!0)){var s=p(o)
r._openPanelNodes.set(e,s),t.scriptCls&&(s.getComponent(t.scriptCls)||s.addComponent(t.scriptCls)),t.removeOther&&r.closeOtherView(e),i.addChild(s),n&&n(s)}else r._removeRetain(e)
}))}},t.closePanel=function(e){this._openIds.delete(e),this._removeRetain(e)
var t=this._openPanelNodes.get(e)
t&&(this._openPanelNodes.delete(e),t.destroy())},t.closeOtherView=function(e){var t=this
this._openIds.forEach((function(i){i!=e&&t.closePanel(i)}))},t.closeLaunchLayer=function(e){if(this._layerLaunch!=e){if(this._layerLaunch){var t=this._layerLaunch
this._layerLaunch=null,t.parent.off(c.CHILD_ADDED,this._onLayerParentChange,this),this.closeOtherView(""),t.destroy()}this._layerLaunch=e}},t.getOpenPanelNode=function(e){
return this._openPanelNodes.get(e)},t._onLayerParentChange=function(){var e=this._layerLaunch
if(e)for(var t=e.parent.children.length-1;t>=0;t--){var i=e.parent.children[t]
if(i!=e&&i.name.startsWith("Layer")){e.setSiblingIndex(t+1)
break}}},t._addRetain=function(e,t){var i=this._retainIds.get(e)
i||(i=[],this._retainIds.set(e,i)),-1==i.indexOf(t)&&(i.push(t),hn._$retainRes(t))},t._removeRetain=function(e){var t=this._retainIds.get(e)
if(t){for(var i=0;i<t.length;i++)hn._$releaseRes(t[i])
this._retainIds.delete(e)}},t.alert=function(e){function t(t,i){return e.apply(this,arguments)}return t.toString=function(){return e.toString()},t}((function(e,t){
MiniPlatController.ins.alert(e,t)})),Oe(e,null,[{key:"ins",get:function(){return this._ins||(this._ins=new e),this._ins}}]),e}()
mi._ins=void 0,e._RF.pop(),e._RF.push({},"a382az6+7JKqYYkX0txc75q","Handler",void 0)
var _i=0,gi=[],yi=function(){function e(e,t,i,n){void 0===n&&(n=!1),this.caller=null,this.method=null,this.args=null,this.once=!1,this.valid=!0,this._id=0,this.setTo(e,t,i,n)}
var t=e.prototype
return t.setTo=function(e,t,i,n){return void 0===n&&(n=!1),_i+=1,this._id=_i,this.method=t,this.caller=e,this.args=i||null,this.once=n,this},t.run=function(){
if(this.valid&&this.method){var e=this._id,t=this.method.apply(this.caller,this.args)
return e===this._id&&this.once&&this.recover(),t}},t.runWith=function(e){if(this.valid&&this.method){var t,i=this._id
return t=null==e?this.method.apply(this.caller,this.args):this.args?this.method.apply(this.caller,this.args.concat(e)):this.method.apply(this.caller,e),
i===this._id&&this.once&&this.recover(),t}},t.clear=function(){return this.caller=null,this.method=null,this.args=null,this},t.recover=function(){this._id>0&&(this._id=0,
gi.push(this.clear()))},e.create=function(t,i,n,r){return void 0===r&&(r=!1),gi.length>0?gi.pop().setTo(t,i,n,r):new e(t,i,n,r)},e}()
e._RF.pop(),e._RF.push({},"8b569jUkmdHYrJCzILYfQt2","launchBean",void 0)
var vi=Object.create(null)
function bi(e,t,i){Ti(e,t,i)}function Ti(e,t,i){var n=t.apply(void 0,[e].concat(i))
if(n>0)return n
for(var r=e.children,o=0;o<r.length;o++){var s=Ti(r[o],t,i)
if(1==s)return s}return 0}function wi(e,t){for(var i=e.components,n=0;n<i.length;n++){var r=i[n]
if(null!=r.grayscale)return r.grayscale=t,null!=r._updateRichTextStatus?2:0}return 0}e._RF.pop(),e._RF.push({},"b4f71KuYrNAR7Td3sRI6vFf","LaunchCocosUtil",void 0),e._RF.pop(),
e._RF.push({},"6e16fiNZeNLPpYBJ0WVpjSp","LaunchLogicBridge",void 0)
var Ii=function(){function e(){}return e._getLaunchPanelCtrl=function(){return mi.ins},e._switchLaunchLoading=function(e){mi.ins.switchLoadingView(e)},
e._shutdownLaunchLayer=function(e){mi.ins.closeLaunchLayer(e)},e}()
Ii.UrlPrefab=null,Ii.CList=null,Ii._Handler=yi,Ii._assignBinder=ai,Ii._initBinderObject=nt,Ii._clearBinderObject=function(e){null!=e.Clear&&(null==e._objFlags&&(e._objFlags=0),
0==(e._objFlags&Qe)&&(e._objFlags|=Qe,e.Clear()))},Ii._destroyBinderObject=function(e){null!=e.Destroy&&(null==e._objFlags&&(e._objFlags=0),0==(e._objFlags&et)&&(e._objFlags|=et,
e.Destroy(),null!=e.m_Destroyed&&(e.m_Destroyed=!0)))},Ii._travelNode=bi,Ii._MakeNodeGray=function(e,t){bi(e,wi,[!!t])},Ii._CreateDelegate=Ve,Ii._launchClsMap=vi,Ii._ccImport=y,
Ii._ccenvImport=Ne,e._RF.pop(),e._RF.push({},"d949eazbSlAyI0tUnlJTeV9","EditorLoaderDock",void 0)
var Si=function(){function e(){}return e.loadRemote=function(e,t){if(REAL_EDITOR){var i="http://localhost:8999/assets/"+e
v.loadRemote(i,(function(e,i){t(e,i)}))}},e.loadBundleRes=function(e,t,i,n){if(REAL_EDITOR){var r="db://assets/"+t+"/"+e
i==b&&(r.endsWith(".plist")||(r+=".plist")),Editor.Message.request("asset-db","query-uuid",r).then((function(e){e?v.loadAny(e,{type:i},n):console.log("error uuid '"+r+"'")}))}},e
}()
e._RF.pop(),e._RF.push({},"f6b6bZ0mdRFVaBSH+YE/o8a","MSpriteFrame",void 0),e._RF.pop(),e._RF.push({},"a8470xd44FJFoxi+QP59+wT","MResVo",void 0)
var Ri=[],xi=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return(t=e.call.apply(e,[this].concat(n))||this).id=0,t.path="",t.resUuid="",t.res=null,t.cache=He.Uncache,t.state=0,t.options=null,t.dependAsset=null,t.dependResIds=null,
t.deriveAsset=null,t.startTime=0,t.reference=0,t.needAddRef=!1,t.addRefState=0,t.isWaitDelete=!1,t.cloneSpfs=null,t}Le(t,e),t.obtain=function(){return Ri.length?Ri.pop():new t},
t.release=function(e){e.recycle(),Ri.length<100&&Ri.push(e)}
var i=t.prototype
return i.doAddRes=function(){if(this.needAddRef&&0==this.addRefState&&2===this.state){if(this.dependAsset){
if(Array.isArray(this.dependAsset))for(var e=0;e<this.dependAsset.length;e++)this.dependAsset[e].addRef()
else this.dependAsset.addRef()
this.addRefState|=1}this.res instanceof R&&(this.res.addRef(),this.addRefState|=2)}},i.addDependAsset=function(e){
e&&(this.dependAsset?Array.isArray(this.dependAsset)?this.dependAsset.push(e):this.dependAsset=[this.dependAsset,e]:this.dependAsset=e)},i.getCloneSpf=function(e,t,i){
var n=e.name+"_"+(t?1:0)+"_"+(i?1:0),r=this.cloneSpfs||(this.cloneSpfs={}),o=r[n]
return o||(function(e,t){var i=e._rect
if(i){var n=t._rect
n?(n.x=i.x,n.y=i.y,n.width=i.width,n.height=i.height):t._rect=T(i)}else t._rect=null
t._rotated=e._rotated||!1
var r=e._offset
if(r){var o=t._offset
o?(o.x=r.x,o.y=r.y):t._offset=w(r)}else t._offset=null
var s=e._originalSize
if(s){var a=t._originalSize
a?(a.width=s.width,a.height=s.height):t._originalSize=I(s)}else t._originalSize=null
var l=e.vertices
if(l){var h=t.vertices||(t.vertices={})
h.nu?h.nu.length=0:h.nu=[],h.nv?h.nv.length=0:h.nv=[],h.triangles=l.triangles,h.x=l.x,h.y=l.y,h.u=l.u,h.v=l.v}else t.vertices=null
e._texture instanceof S&&t._refreshTexture(e._texture)}(e,o=new x),t&&(o.flipUVX=!0),i&&(o.flipUVY=!0),r[n]=o),o},i.recycle=function(){this.id=0,this.path="",this.resUuid="",
this.res=null,this.cache=He.Uncache,this.state=0,this.options=null,this.dependAsset=null,this.startTime=0,this.reference=0,this.cloneSpfs=null,this.needAddRef=!1,
this.addRefState=0,this.isWaitDelete=!1,this.dependResIds=null,this.deriveAsset=null,this.removeAll("loader_complete")},t}(C)
e._RF.pop(),e._RF.push({},"c726455z4pETJa3ptOIRQyc","QueueLoader",void 0)
var Ci={},Oi=Object.create(null),Pi=!1
function Li(e,t,i,n,r){var o=Oi[e]||(Oi[e]={frame:0,queue:[]}),s=f._totalFrames
return o.frame>=s?(o.queue.push({url:t,type:i,cache:n,bundle:r}),Pi||(Pi=!0,cus.schedule(Ei)),!0):(o.frame=s+(Ci[e]||0),!1)}function Ei(){var e=!1,t=f._totalFrames
for(var i in Oi){var n=Oi[i]
if(n.queue.length)if(n.frame<t){var r=n.queue.pop()
r.bundle?hn.loadBundleRes(r.url,r.bundle,r.type,r.cache,i):hn.loadRes(r.url,r.type,r.cache,i),n.queue.length&&(e=!0)}else e=!0}e||(Pi=!1,cus.unschedule(Ei))}Ci["tileset-atlas"]=2,
e._RF.pop(),e._RF.push({},"1ccecfCAuRNKK2I8ypNpdHy","PathCenter",void 0)
var Di,Ai,Fi=function(){function e(){this._params=null,this._ver=""}var t=e.prototype
return t.setup=function(e){this._params=e
var t=launcher.config
this._ver=t.randomVersion||Math.ceil(1e6*Math.random())+"_"+Date.now(),hn.getWebresLoader().setup(t.remoteAssetsRoot)},t.getParam=function(e){return this._params[e]},e}()
e._RF.pop(),e._RF.push({},"31116+IqZhIt5E8tw+134c6","_CommonUtil",void 0)
var zi,ki=(zi="launch.CommonUtil",function(e){void 0!==vi[zi]&&g("[common] repeat clsname '"+zi+"'"),vi[zi]=e}(((Ai=function(){function e(){}return e.isSocketConnected=function(){
return!1},e.isKickOff=function(){return!1},e}()).path=new Fi,Ai.getServerTimeFunc=function(){return 0},Ai.reqServerTime=function(){},Di=Ai))||Di)
e._RF.pop(),e._RF.push({},"53dfbyIxoxOwbbADxjhKGMF","WebBundleLoader",void 0)
var Bi,Ni,Mi=/\\|\/\/|\\\/|\/\\/g,Hi=function(){function e(e){this.bundleName="",this.type="random",this.bundleVer=void 0,this.bundleDir="",this.versions=null,this.reqCBs=null,
this.bundleLoaded=!1,this.bundleName=e}var t=e.prototype
return t.setup=function(e){var t=this.bundleName,i=e,n=v.downloader?v.downloader.bundleVers:null,r=n?n[t]:void 0
if(void 0!==r)if("object"==typeof jsbcus){var o=jsbcus.gameSettings?jsbcus.gameSettings.remoteBundles:null
i=o&&-1!=o.indexOf(t)?""+e+jsbcus.gameJson.targetDir+"/assets/"+t+"/":"assets/"+t+"/"}else i=u.isNative?"assets/"+t+"/":""+assetDir+t+"/"
this.type=r?"version":null===r?"nomd5":"random",this.bundleVer=r,this.bundleDir=i},t.loadBundle=function(e){var t=this
if(this.bundleLoaded)e()
else if(this.reqCBs)this.reqCBs.push(e)
else if(this.reqCBs=[e],"version"==this.type){var i=this.bundleDir+"config."+this.bundleVer+".json"
v.loadRemote(i,(function(e,i){t.onBundleLoaded(e,i)}))}else this.onBundleLoaded(null,null)},t.loadRes=function(e,t,i){var n=this
if(this.bundleLoaded){var r=this.getRemoteUrl(e)
if(!r)return
v.loadRemote(r,t,(function(t,n){i(e,t,n)}))}else this.loadBundle((function(){n.loadRes(e,t,i)}))},t.getRemoteUrl=function(e){var t
if("random"==this.type)t=""+this.bundleDir+e+"?v="+ki.path._ver
else{var i=e.lastIndexOf("."),n=e.slice(0,i).replace(Mi,"/")
if(this.versions){var r=this.versions[n]
if(!r)return O(this.bundleName+" version not found '"+e+"'"),""
n=r}var o=e.slice(i)
t=this.bundleDir+"native/"+n+o}return t},t.onBundleLoaded=function(e,t){if(this.bundleLoaded=!0,e)return this.reqCBs=null,void g(e)
t&&(this.versions=t.json)
var i=this.reqCBs
if(i){this.reqCBs=null
for(var n=0;n<i.length;n++)i[n]()}},e}()
e._RF.pop(),e._RF.push({},"6cf10jGoE1JZIL7vYJ/mHOi","LoaderDock",void 0)
var Gi=v._releaseManager,Vi=new Map,Ui=new Map,Wi=new Map,ji=new Set,Yi=new Map,Xi=new Set,$i=null,qi=0,Ji=[],Zi=new Set,Ki=new Hi("webres"),Qi=new Hi("packin")
function en(e,t,i){var n=Vi.get(e)
return REAL_EDITOR&&n&&(sn(n),n=null),n||(n=xi.obtain(),qi+=1,n.id=qi,n.path=e,i&&(n.options=i),Xi.has(e)?n.cache=He.Long:void 0!==t&&(n.cache=t),Ui.set(n.id,n),Vi.set(e,n)),n}
function tn(e){e.state=1,e.startTime=cus.currTime}function nn(e,t,i){if(!window._isGameRestarting){var n=Vi.get(e)
if(!t&&n&&i&&1===n.state){var r,o=i,s="",a=!0
i instanceof P?(s=i._uuid,(o=x.createWithImage(i)).packable=!1,n.deriveAsset=o):i instanceof L?(o=i._buffer,a=!1):i instanceof E?(o=i.json,a=!1):i instanceof D&&(o=i.text,a=!1)
var l=n.options
if(l){n.options=null
var h=l._ResFormat_
null!=h&&(r="object"==typeof h?h:new h).parseFormat(o,l,n.id,n.path)}a?i!=o&&n.addDependAsset(i):an(i),s&&(n.resUuid=s,Wi.set(s,n)),n.state=2,n.res=r||o,n.doAddRes(),
r&&r.takeoverComplete||n.emit("loader_complete",n.res,n.id,n.path),(n.cache===He.Uncache||0===n.reference&&on(n.cache))&&rn(n,!1)}else if(n){n.state=3,
CC_INTRANET&&GAMEPLAY&&Zi.add(e),sn(n)
try{n.emit("loader_complete",null,n.id,n.path)}catch(e){g(e)}}}}function rn(e,t){e.isWaitDelete=!t
var i=e.cache,n=e.id
switch(i){case He.Uncache:case He.RefTick:t?ji.delete(n):function(e){0===ji.size&&cus.scheduleOnce(0,ln),ji.add(e)}(n)
break
case He.RefCycle:t?Yi.delete(n):Yi.set(n,0)
break
case He.RefTime:t?Yi.delete(n):Yi.set(n,cus.currTime+6e4)
break
case He.RefConfigData:t?Yi.delete(n):Yi.set(n,cus.currTime+6e5)
break
case He.RefTex:t?Yi.delete(n):Yi.set(n,cus.currTime+3e4)}}function on(e){return e>=He.RefTick}function sn(e){var t="number"==typeof e?Ui.get(e):e
if(t){var i=t.path
Vi.delete(i),Wi.delete(t.resUuid),Ui.delete(t.id),function(e){var t=e.addRefState,i=e.dependAsset
if(i){var n=0!=(1&t)
if(i instanceof R)n&&i.decRef(),an(i)
else for(var r=0;r<i.length;r++){var o=i[r]
n&&o.decRef(),an(o)}}var s=e.dependResIds
if(s){for(var a=0;a<s.length;a++)hn._$releaseRes(s[a])
s.length=0}var l=e.deriveAsset
l&&(l instanceof x?(l.texture&&(l.texture.destroy(),l._texture=null),l.destroy()):console.error("unhandle deriveAsset"))
var h=e.res
h&&(null!=h.clearFormat?h.clearFormat():h instanceof R&&(0!=(2&t)&&h.decRef(),an(h)))}(t),xi.release(t)}}function an(e){e._uuid&&Gi.tryRelease(e)}function ln(){
window._isGameRestarting||(ji.forEach((function(e){sn(e)})),ji.clear())}var hn=n.ccclass("launch.LoaderDock")(((Ni=function(){function e(){}return e.loadRemote=function(e,t,i){
var n=en(e,t,i)
if(0===n.state){if(tn(n),CC_INTRANET&&GAMEPLAY&&Zi.has(e))return cus.scheduleOnce(0,(function(){nn(e,new Error("Found 404 '"+e+"'"))})),n.id
REAL_EDITOR?Si.loadRemote(e,(function(t,i){nn(e,t,i)})):Ki.loadRes(e,i,nn)}return n.id},e.loadPackin=function(e,t,i){var n=en(e,t,i)
return 0===n.state&&(tn(n),Qi.loadRes(e,i,nn)),n.id},e.loadRes=function(e,t,i,n){var r=en(e,i)
if(0===r.state){if(n&&Li(n,e,t,i))return r.id
tn(r),REAL_EDITOR?Si.loadBundleRes(e,"wealth",t,(function(t,i){nn(e,t,i)})):$i&&$i.load(t==x?e+"/spriteFrame":e,t,(function(t,i){nn(e,t,i)}))}return r.id},
e.loadResArray=function(t,i,n){var r=this,o=n?i:void 0,s=n||i,a=!1,l=t.length,h=[],c=[]
t.forEach((function(t,i){var n="string"==typeof t?null:t,u=n?n.url:t,p=n?n.type:o,d=n&&n.cache?n.cache:He.RefTick
e.listenRes(e.loadRes(u,p,d),(function(e,t){if(!a){if(!e)return a=!0,h.length=0,r._$releaseResArray(c),void s.call(r,h,[],new Error(u))
t>0&&-1===c.indexOf(t)&&(c.push(t),r._$retainRes(t)),h[i]=e,0==(l-=1)&&(r._$releaseResArray(c),s.call(r,h,c.concat()))}}))}))},e._$releaseResArray=function(e){
for(var t=0;t<e.length;t++)this._$releaseRes(e[t])},e.loadAssetFormat=function(e,t,i){return"string"==typeof e?this.loadRemote(e,t,i):this.loadBundleRes(e[0],e[1]||"resources",t,i)
},e.loadBundleRes=function(e,t,i,n,r){var o=en(e,n)
if(0===o.state){if(r&&Li(r,e,i,n,t))return o.id
if(tn(o),REAL_EDITOR)Si.loadBundleRes(e,t,i,(function(t,i){nn(e,t,i)}))
else{var s=v.getBundle(t)
s?s.load(i==x?e+"/spriteFrame":e,i,null,(function(t,i){nn(e,t,i)})):v.loadBundle(t,(function(t,n){n.load(i==x?e+"/spriteFrame":e,i,null,(function(t,i){nn(e,t,i)}))}))}}return o.id
},e.setup=function(){$i=v.getBundle("wealth"),v.downloader.maxConcurrency=30,v.downloader.maxRequestsPerFrame=30,v.downloader.retryInterval=5e3},e.listenRes=function(e,t,i){
var n="number"==typeof e?Ui.get(e):Vi.get(e)
n?2!==n.state?3!=n.state?n.once("loader_complete",t,i):t.call(i,null,n.id,n.path):t.call(i,n.res,n.id,n.path):g("cannot listen a null mRes")},e.removeListenRes=function(e,t,i){
var n="number"==typeof e?Ui.get(e):Vi.get(e)
n&&n.off("loader_complete",t,i)},e.getResId=function(e){if(REAL_EDITOR)return 0
var t=Vi.get(e)
return t?t.id:0},e.getPath=function(e){if(REAL_EDITOR)return""
var t=""
return Vi.forEach((function(i,n){i.id==e&&(t=n)})),t},e.hasRes=function(e){return"number"==typeof e?Ui.has(e):Vi.has(e)},e.isLoading=function(e){
var t="number"==typeof e?Ui.get(e):Vi.get(e)
return!!t&&1===t.state},e.isReady=function(e){var t="number"==typeof e?Ui.get(e):Vi.get(e)
return!!t&&2===t.state},e.getRes=function(e){var t=Ui.get(e)
return t&&2===t.state?t.res:null},e.getResByPath=function(e){var t=Vi.get(e)
return t&&2===t.state?t.res:null},e.getAtalsCloneSpf=function(e,t,i,n){var r=Ui.get(e)
return r?r.getCloneSpf(t,i,n):null},e.get=function(e,t,i){return i?v.getBundle(i).get(e,t):$i.get(e,t)},e.getPrefab=function(e,t){var i=Ii.UrlPrefab[e]
return t?v.getBundle(t).get(i,m):$i.get(i,m)},e.getWealthBundle=function(){return $i},e.clearRes=function(e){sn(e)},e._removeKeyIfNotLoaded=function(e){var t=Vi.get(e)
t&&2!==t.state&&(Ui.delete(t.id),Wi.delete(t.resUuid),Vi.delete(e))},e.getRemoteAtlas=function(e){var t=Vi.get(e)
return t?t.res:void 0},e._$retainRes=function(e,t){var i=Ui.get(e)
i&&(on(i.cache)?(i.reference+=1,(t||null==t)&&(i.needAddRef=!0,i.doAddRes()),i.isWaitDelete&&rn(i,!0)):console.error("_$retainRes disabled '"+i.path+"'"))},
e._$releaseRes=function(e){var t=Ui.get(e)
t&&(t.reference>0?(t.reference-=1,0===t.reference&&2==t.state&&rn(t,!1)):g("error mRes.reference"))},e._releaseRemoteImageAsset=function(t){Ji.push(t),
1==Ji.length&&cus.lateInvoker.add(e._delayReleaseRemoteImageAsset,this)},e._delayReleaseRemoteImageAsset=function(){for(var e=0;e<Ji.length;e++){var t=Ji[e],i=Wi.get(t._uuid)
i&&i.dependAsset==t&&(0!=(1&i.addRefState)&&t.decRef(),an(t),i.dependAsset=null)}Ji.length=0},e._$dependResId=function(t,i){var n=Ui.get(t)
if(n){var r=n.dependResIds||(n.dependResIds=[]);-1==r.indexOf(i)&&(r.push(i),e._$retainRes(i))}},e._$dispatchComplete=function(e,t){var i=Ui.get(e)
i&&(null!=t&&(i.res=t),i.emit("loader_complete",i.res,i.id,i.path))},e._$releaseCocosCache=function(e){an(e)},e.getBuffer=function(e){if(e instanceof ArrayBuffer)return e
var t=e._buffer
if(t instanceof ArrayBuffer)return t
var i=e._file
if(i){if(i instanceof ArrayBuffer)return i
if((t=i.buffer)instanceof ArrayBuffer)return t}return null},e.addCacheResUrl=function(e){for(var t=0;t<e.length;t++)Xi.add(e[t])},e.clear=function(){
for(var e=Array.from(Ui.keys()),t=0;t<e.length;t++)sn(e[t])},e.loadPrefab=function(t,i){var n=e.get(t,m)
n?e._onloadPrefab(n,i):e.listenRes(e.loadRes(t,m,i.cache||He.RefTick),(function(t){t&&e._onloadPrefab(t,i)}))},e.clearPrefab=function(t){var i=e.getResId(t)
i&&e.clearRes(i)},e._onloadPrefab=function(e,t){if(!t.parent||_(t.parent)){var i
t.single&&t.single.length&&_(t.single[0])?i=t.single[0]:(i=p(e),t.single&&(t.single[0]=i))
var n=t.compCls?i.getOrAddComponent(t.compCls):null
t.parent&&(i.parent=t.parent),t.cb&&t.cb(i,n)}},e.loadPackages=function(t,i,n){void 0===n&&(n=0)
var r=t[n]
if(r&&0!=r.length){var o=r.length
console.log("--- launch load bundle: "+JSON.stringify(r))
for(var s=0;s<r.length;s++){var a=r[s],l=launcher.config.subpackages.paths[a]
if("bundle"==l)v.loadBundle(a,null,c)
else if(globalThis.window.wx&&globalThis.window.wx.loadSubpackage)globalThis.window.wx.loadSubpackage({name:a,success:c,fail:function(e){
if(e)for(var t in e)console.error("load sub fail1  "+e[t])}})
else{var h
h=""+launcher.config.remoteCDN+l,v.downloader.downloadScript(h,{},c)}}}else i()
function c(r){if(r){if(!r.errMsg||"loadSubpackage:ok"!=r.errMsg)return void g(r)
console.log("load sub suc")}if(0==(o-=1)){var s=n+1
if(s>=t.length)try{i()}catch(e){g(e)}else e.loadPackages(t,i,s)}}},e._getRemoteUrl=function(e){return Ki.getRemoteUrl(e)},e.getWebresLoader=function(){return Ki},
e.getPackinLoader=function(){return Qi},e}()).LoaderCache=He,Bi=Ni))||Bi
function cn(){if(!window._isGameRestarting){var e=Yi
if(e.size>0){var t=cus.currTime
e.forEach((function(i,n){t>=i&&(e.delete(n),sn(n))}))}cus.scheduleOnce(10,cn)}}cus.addStaticCall((function(){cus.scheduleOnce(10,cn)})),e._RF.pop(),
e._RF.push({},"de812mlB0xNnqAap1B/gUEJ","_Md5Util",void 0)
var un=function(){function e(){}return e.isEnabled=function(){return"undefined"!=typeof hex_md5},e.hex_md5=function(e){function t(t,i){return e.apply(this,arguments)}
return t.toString=function(){return e.toString()},t}((function(e,t){if(this.isEnabled())return t(hex_md5(e))
hn.loadPackages([["md5"]],(function(){t(hex_md5(e))}))})),e}()
e._RF.pop(),e._RF.push({},"22a2d0GLgRHnaOoEmaaQYWI","LaunchLoginData",void 0)
var pn=function(){function e(){}return e.reset=function(){var e=launcher.config
e.socketIp="",e.socketPort=0,e.serverId="",e.op="",e.referer=CC_INTRANET?"37wan":"",launcher.userName=""},e.parseLoginInfo=function(){var e=launcher.config
if(u.isBrowser){var t=new URL(window.location.href)
e.socketIp||(e.socketIp=t.searchParams.get("ip")||""),e.socketPort||(e.socketPort=Number(t.searchParams.get("port"))||0),e.serverId||(e.serverId=t.searchParams.get("server")||""),
e.op||(e.op=t.searchParams.get("op")||"mainland"),e.referer&&"null"!=e.referer||(e.referer=t.searchParams.get("referer")||"37wan"),
launcher.userName||(launcher.userName=t.searchParams.get("uid")||"")}},e.reqLocalServerList=function(e){var t=launcher.config.localServerList
if(null!=t)if("object"!=typeof t){if("string"!=typeof t)return console.error("error launcher.config.localServerList '"+t+"'"),void e(null)
var i=t
console.log(i),Me(i,null,(function(t){e(function(e){return"string"==typeof e?JSON.parse(e):e}(t))}))}else e(t)
else console.error("error launcher.config.localServerList")},e.jumpWebLink=function(e,t,i,n,r,o){var s=(new Date).getTime()/1e3>>0
un.hex_md5(n+r+i+s+"123456",(function(a){var l=new URL(window.location.href),h={}
if(l.search)for(var c=l.search.slice(1).split("&"),u=0;u<c.length;u++){var p=c[u].split("=")
h[p[0]]=p[1]}h.uid=n,h.ip=e,h.port=t,h.appid=r,h.server=i,h.referer=o,h.time=s,h.sign=a,h.language="zh",h.GIFT=135
var d=[]
for(var f in h)d.push(f+"="+h[f])
window.location.href=l.pathname+"?"+d.join("&")}))},Oe(e,null,[{key:"isImportServerNewUser",get:function(){var e=launcher.config
return e.importServerData&&e.importServerData.serverId==e.selectedServer.serverId&&0==e.importServerData.isolduser}}]),e}()
e._RF.pop(),e._RF.push({},"e8c4eThBlhLabCpdFAZnlNw","LaunchServerUrl",void 0)
var dn={
importListUrl:"https://oreoapis.sanqiyx.com/login/v2/gmryxyx/37wan/client/login/guide?publisher=wy&imei=$1&gid=$2&pid=$3&clientVersion=$4&serverVersion=&token=$5&os=$6&appDomain=$7&fgid=$8&guid=$9&idVerify=$a&idVerifySwitch=$b&isAdult=$c&istg=$d&nickname=$e&openid=$f&referer=$g&sharedSwitch=$h&subscribeSwitch=$i&time=$j&uid=$k&unionId=$l&wxIsSubscribe=$m",
noticeUrl:"https://res.gmryxyx.elk20.com/oreo_oss/prod/1CyPHVZKiIFZQjgswYxI/notice_article/v1/$1-$2.json",
serversUrl:"https://oreoapis.sanqiyx.com/login/v2/gmryxyx/37wan/client/main/servers?publisher=wy&imei=$1&gid=$2&pid=$3&clientVersion=$4&serverVersion=$5&os=$6&sign=$7&time=$8&account=$9",
loginCheckUrl:"https://oreoapis.sanqiyx.com/login/v2/gmryxyx/37wan/client/login/check?publisher=wy&imei=$1&gid=$2&pid=$3&clientVersion=$4&os=$5&sign=$6&time=$7&account=$8&cdn=$9&serverId=$a&serverVersion=$b",
roleRepeatUrl:"https://oreoapis.sanqiyx.com/login/v2/gmryxyx/37wan/client/role/check?publisher=wy&imei=$1&gid=$2&pid=$3&serverId=$4&os=$5&clientVersion=$6&account=$7&cdn=$8&roleName=$9",
errorUrl:"https://client-log-capture.gmryxyx.elk20.com/gmryxyx_client",
clickUrl:"https://click.gmryxyx.elk20.com/click?time=$1&plat=$2&sid=$3&pid=$4&gid=$5&account=$6&traceId=$7&type=$8",clickStream:1,
accountsUrl:"https://oreoapis.sanqiyx.com/login/v2/gmryxyx/37wan/client/main/roles?publisher=wy&imei=$1&gid=$2&pid=$3&clientVersion=$4&os=$5&account=$6&sign=$7&time=$8",
channelqueryurl:"",imeiTraceUrl:"https://oreoapis.sanqiyx.com/events/registry_traceid/import?game=gmryxyx&plat=37wan&gid=$1&pid=$2&imei=$3&time=$4",
zonesUrl:"https://oreoapis.sanqiyx.com/login/v2/gmryxyx/37wan/client/main/zones?publisher=sy&imei=&gid=&pid=&clientVersion=&serverVersion=&os=&sign=&time=&account=&qywxUid=",
copyRightInfoUrl:"https://rydts-1.oss-cn-shenzhen.aliyuncs.com/{env}//copyright_info/{gid}_{pid}.json",
versionUrl:"https://rydts-1.oss-cn-shenzhen.aliyuncs.com/prod//server_version/{os}/{serverId}.json",
rolesUrl:"https://oreoapis.sanqiyx.com/login/v2/gmryxyx/37wan/client/main/roles",recommendUrl:"https://oreoapis.sanqiyx.com/login/v2/gmryxyx/37wan/client/main/recommend"}
e._RF.pop(),e._RF.push({},"6066dR9j9lO8pZtcx8mQwgJ","LaunchUtil",void 0)
var fn={},mn=/\{(\w+?)\}/g,_n=function(){function e(){}return e.merge=function(e,t){for(var i=Object.getOwnPropertyNames(t),n=0;n<i.length;n++){var r=i[n],o=t[r]
if("object"==typeof o)if(null==o||Array.isArray(o)||o instanceof RegExp)e[r]=o
else{var s=e[r]
"object"==typeof s?null==s||Array.isArray(s)||s instanceof RegExp?e[r]=o:this.merge(s,o):e[r]=o}else e[r]=o}return e},e.relativeUrlTrans=function(e){
return u.isBrowser?0!==e.indexOf("./")?e:""+this.resolveHref+e.slice(2):e},e.localhostToIp=function(e,t){if(u.isBrowser){if(-1===e.indexOf("localhost"))return e
var i=t||window.location.href
if(console.log("href",i),"string"!=typeof i||i.startsWith("packages://")||-1!==i.indexOf("localhost"))return e
var n=new URL(i)
return e.replace("localhost",n.hostname)}return e},e.registeClass=function(e){return function(t){fn[e]&&g("[launch] repeat register class '"+e+"'"),fn[e]=t}},
e.getClass=function(e){return fn[e]},e.getConfigValue=function(e){return launcher.config[e]},e.setConfigValue=function(e,t){launcher.config[e]=t},e.getValue=function(e,t){
return e?e[t]:null},e.setValue=function(e,t,i){e[t]=i},e.getComps=function(e){return e._components},e.setRect=function(e,t,i,n,r){e.x=t,e.y=i,e.width=n,e.height=r},
e.isUrl=function(e){return!!e&&"string"==typeof e&&0==e.indexOf("http")},e._updateNodeWidget=function(t){var i=t.getComponent(a)
i&&i.enabled&&i.updateAlignment()
for(var n=t.children,r=0;r<n.length;r++)e._updateNodeWidget(n[r])},e._getFormat=function(e,t){return t?e.replace(mn,(function(e,i){
return Object.prototype.hasOwnProperty.call(t,i)?t[i]:e})):e},e._transRichTextHref=function(e){var t=(e=e.replace("<ul>","").replace("</ul>","")).match(/\<a href.*?\<\/a\>/g)
if(t&&t.length)for(var i=0;i<t.length;i++){var n=t[i],r="",o=n.match(/href=\"([^\"]*)/)
o&&(r=o[1]||"")
var s="",a=n.match(/\>([^\<]*)/)
if(a&&(s=a[1]||""),r&&s){var l='<color="#66d9ef" click="onClick" param="'+r+'"><u>'+s+"</u></color>"
e=e.replace(n,l)}else g("error href "+n)}return e},Oe(e,null,[{key:"resolveHref",get:function(){if(!this._resolveHref&&u.isBrowser){
var e=window.location.href.replace(/^(.*[\\\/])[^\\\/]*$/,"$1")
return"/"!==e.charAt(e.length-1)&&(e+="/"),this._resolveHref=e,e}return this._resolveHref}}]),e}()
_n._resolveHref=""
var gn=i.Flags.PrevIsOnEnableCalled
function yn(e){return 0!=(e._objFlags&gn)}function vn(e,t){var i=e._spriteFrame
e._spriteFrame=t,e.markForUpdateRenderData(),e._applySpriteFrame(i),REAL_EDITOR&&e.node.emit("spriteframe-changed",e)}e._RF.pop(),
e._RF.push({},"0caa09kOItPc63eHPUmBWD3","LaunchCommon",void 0)
var bn=function(){function e(){}return e.initI18nText=function(e){var t=cus._assignKeyValue(Object.create(null),e.text)
cus._setTextRecord(t)},e.initIpconfig=function(e){var t,i=A._settings.IpConfig
if(i&&_n.merge(e,i),e.isSdkMode=!e.isLocMode,launcher.isSDKLogined=!0,launcher.isSubpackLoaded=!1,launcher.config=e,launcher.config.pid="37wxxyx",launcher.config.gid="215",
launcher.isSDKLogined=!1,launcher.isSubpackLoaded=!1,launcher.config.imei=localStorage.getItem("wx$uuid"),!launcher.config.imei){var n=(t=(new Date).getTime(),
window.performance&&"function"==typeof window.performance.now&&(t+=performance.now()),"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,(function(e){
var i=(t+16*Math.random())%16|0
return t=Math.floor(t/16),("x"==e?i:3&i|8).toString(16)})))
launcher.config.imei=n,localStorage.setItem("wx$uuid",n)
var r=dn.imeiTraceUrl.replace(/\$1/g,"215")
Me(r=(r=(r=r.replace(/\$2/g,"37wxxyx")).replace(/\$3/g,n)).replace(/\$4/g,(new Date).getTime()+""))}pn.reset(),launcher._testFlag=function(e){var t=launcher.config.testFlag
return t>0&&0!=(t&e)},this.updateRemoteUrl()},e.updateRemoteUrl=function(){var e=launcher.config.remoteCDN
"/"!==(e=e.startsWith("./")?""+_n.resolveHref+e.slice(2):e?_n.localhostToIp(e):_n.resolveHref).charAt(e.length-1)&&(e+="/"),
launcher.config.remoteCDNBranch&&(e+=launcher.config.remoteCDNBranch+"/"),launcher.config.remoteCDN=e,console.log("remoteCDN",e),v.downloader._remoteServerAddress=e
var t=launcher.config.remoteWebresRoot
t.startsWith("./")?t=""+e+t.slice(2):t.startsWith("http")||console.error("unsupport remoteWebresRoot '"+t+"'"),"/"!==t.charAt(t.length-1)&&(t+="/"),
console.log("remoteWebresRoot",t),launcher.config.remoteAssetsRoot=t+"assets/"},Oe(e,null,[{key:"remoteCDN",get:function(){return launcher.config.remoteCDN},set:function(e){
e!=launcher.config.remoteCDN&&(launcher.config.remoteCDN=e,this.updateRemoteUrl())}}]),e}()
e._RF.pop(),e._RF.push({},"86b13Xs7vtG0L3CE8PK7j8a","cus",void 0),e._RF.pop(),e._RF.push({},"87dedOwNUtF47MD/oVCbw8S","i18nText",void 0)
var Tn=Object.prototype.hasOwnProperty,wn=/\{(\w+?)\}/g,In={}
"undefined"!=typeof cus&&(cus._getTextRecord=function(){return In},cus._setTextRecord=function(e){In=e},cus._assignKeyValue=function(e,t){
for(var i=t.split(/\r\n|[\r\n]/),n=/\\n/g,r=0;r<i.length;r++){var o=i[r]
if("#"!==o.charAt(0)){var s=o.indexOf("=");-1!==s&&(e[o.slice(0,s)]=o.slice(s+1).replace(n,"\n"))}}return e}),e._RF.pop(),e._RF.push({},"45592u7qDRGS55K38cbBA3b","_def",void 0)
var Sn,Rn,xn=globalThis
function Cn(){return"undefined"==typeof REAL_EDITOR&&(globalThis.REAL_EDITOR=false),REAL_EDITOR}xn.cus1=function(){},xn.getText=function(e,t){
var i,n=null!=(i=In[e])?i:"undefined("+e+")"
return t?n.replace(wn,(function(e,i){return Tn.call(t,i)?t[i]:e})):n},xn.__$LaunchLogicBridge=Ii,e._RF.pop(),e._RF.push({},"191a2EGv3hDUpOrZKz4/fSQ","graphics",void 0),
F.prototype.line=function(e,t,i,n){this.moveTo(e,t),this.lineTo(i,n)},e._RF.pop(),e._RF.push({},"63f6ewfN01IZrZN5z9tL5AX","_component",void 0),t.prototype.GetActive=function(){
return this.node.active},t.prototype.SetActive=function(e){this.node.active=e},t.prototype.CreateDelegate=function(e){return Ve(e,this)},t.prototype.TransformPoint=function(e){
return this.node.transform.convertToWorldSpaceAR(e)},e._RF.pop(),e._RF.push({},"6c337QMmERKgLqhK7biknV4","_node",void 0),l.prototype.offAll=function(){
null!=this._eventMask&&(this._eventMask=0)
var e=this._eventProcessor
e&&(e.capturingTarget&&e.capturingTarget.clear(),e.bubblingTarget&&e.bubblingTarget.clear())},l.prototype.SetLocalPositionXYZ=function(e,t,i){this.setPosition(new z(e,t,i))},
l.prototype.GetLocalPositionXYZ=function(){return[this.x,this.y,0]},l.prototype.SetLocalScaleXYZ=function(e,t,i){this.setScale(new z(e,t,i))},l.prototype.getCNode=function(e){
var t=this._cnode
if(t)return t
if(null==e){var i=this.getComponent(wt)
i&&i.scriptName&&(e=r.getClassByName(i.scriptName)),null==e&&(e=li)}1==it(e)?this.getComponent(e)||this.addComponent(e):new e(this)
var n=this._cnode
return n?(nt(n),n):null},l.prototype.getCNodeByClsName=function(e){var t=r._nameToClass[e]
if(t)return this.getCNode(t)
console.error("getCNodeByClsName error uiClsName '"+e+"'")},e._RF.pop(),e._RF.push({},"44479nKAstP4J8o6OKizeZi","isREAL_EDITOR",void 0),e._RF.pop(),
e._RF.push({},"86474cslCZEEZhE4miVo99A","_ScreenUtil",void 0)
var On=n.ccclass("app/ScreenUtil")(((Rn=function(){function e(){}return e.setup=function(){this._onSizeChange(),k.on("canvas-resize",this._onSizeChange,this)},
e._onSizeChange=function(){var e=B.windowSize,t=k.getVisibleSize()
this.screenScaleX=t.width/e.width,this.screenScaleY=t.height/e.height},e}()).screenScaleX=1,Rn.screenScaleY=1,Sn=Rn))||Sn
e._RF.pop(),e._RF.push({},"104f0B+MaZEu6ILx7o8BK8S","_inspector",void 0)
var Pn,Ln,En,Dn,An,Fn=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return(t=e.call.apply(e,[this].concat(n))||this)._uiCanvas=null,t._uiCamera=null,t._sceneCanvas=null,t._sceneCamera=null,t._isListenning=!1,t._lastTouchX=-1,t._lastTouchY=-1,
t._nodeBound=new N,t._drawG=void 0,t._nodePath="",t._wm=new WeakMap,t}Le(t,e),t.setup=function(){var e=new l("INSPECTOR_NODE")
e.addComponent(s).setContentSize(5e3,5e3),e.addComponent(t),f.getScene().getChildByName("UICanvas").addChild(e)}
var i=t.prototype
return i.onLoad=function(){this._sceneCanvas=f.getScene().getChildByName("UICanvas"),this._sceneCamera=this._sceneCanvas.getChildByName("Main Camera").getComponent(M),
this._uiCanvas=f.getScene().getChildByName("UICanvas"),this._uiCamera=this._uiCanvas.getChildByName("Camera").getComponent(M)
var e=new l("DRAW_G")
e.addComponent(s),this._drawG=e.addComponent(F),this._drawG.lineWidth=2,this._drawG.strokeColor=H.RED,this.node.addChild(e),e.active=!1,
this.node.parent.on(c.CHILD_ADDED,this.onParentChildAdded,this),G.on(V.EventType.KEY_PRESSING,this.onKeyPressing,this)},i.findTouchNode=function(e,t){
var i=this._travelNode(e,t,this._uiCanvas,this._uiCamera,"")
return i||(i=this._travelNode(e,t,this._sceneCanvas,this._sceneCamera,"")),i||null},i._travelNode=function(e,t,i,n,r){if(r=r?r+"/"+i.name:i.name,i.getComponent(U))return null
for(var o=i.children.length-1;o>=0;o--){var s=i.children[o]
if(s.active&&s.visible&&"INSPECTOR_NODE"!=s.name&&"RICHTEXT_CHILD"!=s.name&&"RICHTEXT_Image_CHILD"!=s.name&&s.opacity>0){var a=this._travelNode(e,t,s,n,r)
if(a)return a}}var l=i.transform
if(l.width&&l.height){for(var h=!1,c=i.components.length-1;c>=0;c--){var u=i.components[c]
if(u.enabled){if(u instanceof W){u.spriteFrame&&(h=!0)
break}if(u instanceof d){u.string&&(h=!0)
break}if(u instanceof j)u.string&&(h=!0)
else{if(u instanceof F){h=!0
break}if("Skeleton"==u.constructor.name){h=!0
break}}}}if(h){var p=l.getBoundingBoxToWorld(!0)
if(p.contains(Y.TEMP.set(e,t)))return this._nodePath=r,this._nodeBound.set(p),i}}return null},i.onMouseMoved=function(e){if(e.preventSwallow=!0,this._isListenning){
var t=e.getLocation(Y.TEMP)
if(t.x!=this._lastTouchX||t.y!=this._lastTouchY){this._lastTouchX=t.x*On.screenScaleX,this._lastTouchY=t.y*On.screenScaleY
var i=this.findTouchNode(this._lastTouchX,this._lastTouchY)
this.draw(i)}}},i.onTouchEnded=function(e){if(this._isListenning){var t=e.getLocation(Y.TEMP)
this._lastTouchX=t.x*On.screenScaleX,this._lastTouchY=t.y*On.screenScaleY
var i=this.findTouchNode(this._lastTouchX,this._lastTouchY)
if(this.draw(i),i){for(var n=1;void 0!==globalThis["temp"+n];)n++
var r="temp"+n
console.log(this._nodePath),console.log(r),console.log(i)
var o={}
this._wm.set(o,i),this.setWindowTemp(r,o)
for(var s=new Event("ccc-devtools-select-node"),a=[],l=i;l&&(a.unshift(l.uuid),l!=this._uiCanvas&&l!=this._sceneCanvas);)l=l.parent
s._data=a,globalThis.dispatchEvent(s)}}else e.preventSwallow=!0},i.setWindowTemp=function(e,t){var i=this._wm
Object.defineProperty(globalThis,e,{get:function(){var n=i.get(t)
return null!=n&&_(n)?n:(Object.defineProperty(globalThis,e,{configurable:!0,value:null}),null)},set:function(e){},configurable:!0})},i.draw=function(e){var t=this._drawG
if(e){t.node.active=!0
var i=this.node.parent.transform,n=this._nodeBound
t.node.setPosition(n.x-i.width/2,n.y-i.height/2),t.clear(),t.moveTo(0,0),t.lineTo(n.width,0),t.lineTo(n.width,n.height),t.lineTo(0,n.height),t.lineTo(0,0),t.stroke()
}else t.node.active&&(t.clear(),t.node.active=!1)},i.onPreventSwallow=function(e){e.preventSwallow=!0},i.onKeyPressing=function(e){
e.keyCode!=X.ALT_LEFT&&e.keyCode!=X.ALT_RIGHT||(e.type==V.EventType.KEY_PRESSING?(this.unschedule(this._cancelListen),this.scheduleOnce(this._cancelListen,.3),
this._isListenning||this._startListen()):e.type==V.EventType.KEY_UP&&(this.unschedule(this._cancelListen),this._cancelListen()))},i._startListen=function(){
this._isListenning||(this._isListenning=!0,this._lastTouchX=-1,this._lastTouchY=-1,this.node.on(c.MOUSE_MOVE,this.onMouseMoved,this),
this.node.on(c.MOUSE_DOWN,this.onPreventSwallow,this),this.node.on(c.MOUSE_UP,this.onPreventSwallow,this),this.node.on(c.MOUSE_WHEEL,this.onPreventSwallow,this),
this.node.on(c.TOUCH_END,this.onTouchEnded,this),this.node.on(c.TOUCH_MOVE,this.onPreventSwallow,this),this.node.on(c.TOUCH_CANCEL,this.onPreventSwallow,this))},
i._cancelListen=function(){this._isListenning&&(this._isListenning=!1,this._lastTouchX=-1,this._lastTouchY=-1,this.draw(null),this.node.off(c.MOUSE_MOVE,this.onMouseMoved,this),
this.node.off(c.MOUSE_DOWN,this.onPreventSwallow,this),this.node.off(c.MOUSE_UP,this.onPreventSwallow,this),this.node.off(c.MOUSE_WHEEL,this.onPreventSwallow,this),
this.node.off(c.TOUCH_END,this.onTouchEnded,this),this.node.off(c.TOUCH_MOVE,this.onPreventSwallow,this),this.node.off(c.TOUCH_END,this.onPreventSwallow,this),
this.node.off(c.TOUCH_CANCEL,this.onPreventSwallow,this))},i.onParentChildAdded=function(){this.unschedule(this._handleParentChildAdded),
this.scheduleOnce(this._handleParentChildAdded,.1)},i._handleParentChildAdded=function(){this.node.setSiblingIndex(this.node.parent.children.length)},t}(t)
e._RF.pop(),e._RF.push({},"aff08yh7gJPoZ0NOykEvGlE","LaunchScript",void 0),"undefined"==typeof launcher&&(globalThis.launcher={}),
"undefined"==typeof CC_INTRANET&&(globalThis.CC_INTRANET=!0),"undefined"==typeof GAMEPLAY&&(globalThis.GAMEPLAY=!0),Cn(),l._cls_uiopacity=$,l._cls_uitransform=s,
q.CLEANUP_IMAGE_CACHE=!0,J.enabled=!1,P._releaseRemoteImageAsset=hn._releaseRemoteImageAsset
var zn,kn=n.ccclass,Bn=n.property
Pn=Bn(E),Ln=Bn(D),kn((Dn=ke((En=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"ipConfigJson",Dn,De(t)),ze(t,"prevText",An,De(t)),t}return Le(t,e),t.prototype.onLoad=function(){Z.ttfLabelScale=1,
MiniPlatController.sendClick(1),launcher.sendClick=MiniPlatController.sendClick,launcher.sendError=MiniPlatController.sendError,globalThis.window.onerror=function(e){var t,i=0,n={}
if(e.msg)if(i=n[e.msg]){if(++i,n[e.msg]=i,i%200!=0)return!1}else i=n[e.msg]=1
t=e.detail&&e.detail.stack?"error="+e.msg+" line:"+e.line+"col"+e.column+"\n"+e.detail.stack:"error="+e.msg+" line:"+e.line+"col"+e.column,
MiniPlatController.sendError(t+"  -- errNum="+i)},On.setup(),K()&&Q(!1),cus.errorPolyfill(),cus.initRequestFrame(),cus.setupStatic(this),MiniPlatController.sendClick(2),
bn.initI18nText(this.prevText),MiniPlatController.sendClick(3),bn.initIpconfig(this.ipConfigJson.json),ki.path.setup(launcher.config),!REAL_EDITOR&&CC_INTRANET&&Fn.setup(),
MiniPlatController.sendClick(4),mi.ins.setup(),ci.ins.setup()},t}(t)).prototype,"ipConfigJson",[Pn],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}
}),An=ke(En.prototype,"prevText",[Ln],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),En)),e._RF.pop(),
e._RF.push({},"f25d81+y5BEJamSp1Cfaacr","LaunchAdapterScript",void 0)
var Nn=n.ccclass,Mn=n.executionOrder,Hn=u.getSafeAreaRect.bind(u),Gn=new N
function Vn(){return Gn}Nn(zn=Mn(10)(zn=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return(t=e.call.apply(e,[this].concat(n))||this).minDesignResolution=720,t.maxDesignResolution=1280,t}Le(t,e)
var i=t.prototype
return i.onLoad=function(){var e=u.getSafeAreaRect()
u.getSafeAreaRect=Vn,Gn.set(e.x,e.y,e.width,e.height)},i.updateResolution=function(){
var e=1280,t=B.windowSize,i=t.width,n=t.height,r=1.7777777777777777,o=k.getVisibleSize(),s=o.width,a=o.height,l=Hn()
console.log("=========================================="),console.log("=== visibleSize "+o.x+", "+o.y),console.log("=== winSize  "+t.x+", "+t.y),
console.log("=== safeArea "+l.x+", "+l.y+", "+l.width+", "+l.height),l.y=0
var h=s==l.width?1:l.width/s,c=a==l.height?1:l.height/a,u=i*h/(n*c),p=0,d=0,f=0,m=0
if(u>=r){var _=1==c?720:720/c,g=_*r
m=720,k.setDesignResolutionSize(g,_,ee.FIXED_HEIGHT)}else if(u<r){var y=1==h?e:e/h,v=y/r
f=e,k.setDesignResolutionSize(y,v,ee.FIXED_WIDTH)}t=B.windowSize,o=k.getVisibleSize(),0==f&&(f=o.width*h),0==m&&(m=o.height*c),0!=l.x&&(p=l.x/s*o.width),0!=l.y&&(d=l.y/a*o.height),
Gn.set(p,d,f,m),console.log("=========================================="),console.log("=== visibleSize "+o.x+", "+o.y),console.log("=== winSize "+t.x+", "+t.y),
console.log("=== safeArea "+Gn.toString())
var b=this.getComponent(te)
b&&b.updateArea()},t}(t))||zn),e._RF.pop(),e._RF.push({},"a33caHjlUhLq73IV96NunrV","LaunchPreloadController",void 0),e._RF.pop(),
e._RF.push({},"7b343pOiBRDK5fxXZkO550f","MiniPlatController",void 0)
var Un=function(){function e(){this._sdk=globalThis.window.SQSDK,this.serverTips={1:"服务器繁忙",3:"服务器维护中",4:"服务器维护中"}}e.isTiShen=function(){
return MiniPlatController.tiShenServers.indexOf(launcher.config.serverId)>=0},e.sendClick=function(e){var t=launcher.config
if(t){var i=dn.clickUrl.replace(/\$1/g,(new Date).getTime()+"")
Me(i=(i=(i=(i=(i=(i=(i=i.replace(/\$2/g,"37wan")).replace(/\$3/g,t.serverId?t.serverId:"")).replace(/\$4/g,t.pid?t.pid:"37wxxyx")).replace(/\$5/g,t.gid?t.gid:"215")).replace(/\$6/g,t.account?t.account:"")).replace(/\$7/g,t.imei?t.imei:"")).replace(/\$8/g,e+""))
}},e.sendError=function(e){var t=launcher.config
t&&Me(dn.errorUrl,{traceId:t.account?t.account:t.imei?t.imei:"",error:e},null,0,Be.POST)}
var t=e.prototype
return t.dataReport=function(e,t){},t.alert=function(e,t){globalThis.window.wx.showModal({title:"提示",content:e,showCancel:!1,complete:function(){t&&t()}})},t.refresh=function(){
globalThis.window.wx.restartMiniProgram?globalThis.window.wx.restartMiniProgram():globalThis.window.wx.exitMiniProgram()},t.exitGame=function(){
globalThis.window.wx.exitMiniProgram&&globalThis.window.wx.exitMiniProgram()},t.openOtherMini=function(e,t){
globalThis.window.wx.openEmbeddedMiniProgram&&globalThis.window.wx.openEmbeddedMiniProgram({appId:e,path:t,success:function(e){console.info("openOtherMini suc"+e)},
fail:function(e){console.info("openOtherMini fail"+e)}})},t.sdkInitProcess=function(){var e
launcher.config,MiniPlatController.sendClick(6),globalThis.window.qq?(e=globalThis.window.qq.getLaunchOptionsSync(),this.setQueryByShare(e.query),this.setActivity(e.query),
this.setKeepScreenOn()):(e=globalThis.window.wx.getLaunchOptionsSync(),console.log("onshow:"+JSON.stringify(e)),this.setKeepScreenOn(),this.setQueryByShare(e.query),
this.setActivity(e.query)),ci.ins.nextProcess(4)},t.sdkLoginProcess=function(){var e=globalThis.window.SQSDK,t=launcher.config
MiniPlatController.sendClick(7),e.login((function(e){var i=e.code,n=e.data,r=e.loginReport
if(e.extraData,0!=i&&n){if(t.time=n.time,t.sign=n.sign,t.pid=n.appid,t.gid=n.game_id,t.sdkData=n,t.account=n.uid+"",MiniPlatController.sendClick(8),r&&r(),
!u.isMobile||globalThis.window.qq||!globalThis.window.wx.getUpdateManager)return console.log("目前平台暂时不支持版本更新"),MiniPlatController.sendClick(13),ci.ins.nextProcess(5)
var o=globalThis.window.wx.getUpdateManager()
MiniPlatController.sendClick(9),o.onCheckForUpdate((function(e){if(!e.hasUpdate)return console.log("版本无更新,进入游戏"),MiniPlatController.sendClick(13),ci.ins.nextProcess(5)
MiniPlatController.sendClick(10),globalThis.window.wx.showLoading({title:"版本有更新,下载中",mask:!0}),console.log("微信小游戏版本有更新,下载中")})),o.onUpdateReady((function(){
MiniPlatController.sendClick(11),console.log("微信小游戏,下载好,请求重启"),o.applyUpdate()})),o.onUpdateFailed((function(){MiniPlatController.sendClick(12),
globalThis.window.wx.hideLoading({}),mi.ins.alert("版本更新失败，请退出游戏再打开")}))}else console.log("sdk登录失败")}))},t.importServerProcess=function(){
var e=this,t=launcher.config,i=dn.importListUrl.replace(/\$1/g,t.imei)
i=(i=(i=(i=(i=(i=(i=(i=(i=(i=(i=(i=(i=(i=(i=(i=(i=(i=(i=(i=(i=i.replace(/\$2/g,t.gid)).replace(/\$3/g,t.pid)).replace(/\$4/g,t.clientVersion+"")).replace(/\$5/g,t.sign)).replace(/\$6/g,"wxapp")).replace(/\$7/g,t.sdkData.app_domain)).replace(/\$8/g,t.gid)).replace(/\$9/g,t.sdkData.guid)).replace(/\$a/g,t.sdkData.id_verify)).replace(/\$b/g,t.sdkData.id_verify_switch)).replace(/\$c/g,t.sdkData.is_adult)).replace(/\$d/g,t.sdkData.is_tg)).replace(/\$e/g,t.sdkData.nickname)).replace(/\$f/g,t.sdkData.openid)).replace(/\$g/g,"")).replace(/\$h/g,t.sdkData.shared_switch)).replace(/\$i/g,t.sdkData.subscribe_switch)).replace(/\$j/g,t.sdkData.time)).replace(/\$k/g,t.sdkData.uid)).replace(/\$l/g,t.sdkData.unionid)).replace(/\$m/g,t.sdkData.wx_is_subscribe)
var n={}
n.pid=t.pid,n.gid=t.gid,n.event_name="choose_server_load",this.dataReport(n),MiniPlatController.sendClick(14),Me(i,{appExt:t.sdkData.app_ext},(function(i){
if(MiniPlatController.sendClick(15),i){var n=JSON.parse(i)
if(0==n.state){var r={}
r.pid=t.pid,r.gid=t.gid,r.event_name="choose_server_arrive",e.dataReport(r)
var o=n.data
if(t.webTime=n.data.time,t.webSign=n.data.sign,t.account=o.account,t.serverId=o.guideServer.serverId,t.importServerData=o.guideServer,t.selectedServer=o.guideServer,
t.socketIp=o.guideServer.ip,t.socketPort=o.guideServer.port,t.zoneId=o.guideServer.zoneId,r.event_name="choose_server_complete",r.dsanme=t.selectedServer.name,r.dsid=t.serverId,
e.dataReport(r),o.ext2){var s=JSON.parse(o.ext2)
t.isNewAccount=s.isNewAccount,t.wa=s.wa}return ci.ins.nextProcess(6)}console.log("---importlist data.state != 0")}else console.log("---importlist responese  null")}),0,Be.POST)},
t.serverListProcess=function(){var e=launcher.config,t=dn.noticeUrl.replace(/\$1/g,e.gid).replace(/\$2/g,e.pid)
Me(t,null,(function(t){if(t){var i=JSON.parse(t)
0!=i.state&&console.log("---noticeUrl responese  data.state!=0"),e.noticeJson=i}else console.log("---noticeUrl responese  null")})),
Me(t=(t=(t=(t=(t=(t=(t=(t=dn.accountsUrl.replace(/\$1/g,e.imei)).replace(/\$2/g,e.gid)).replace(/\$3/g,e.pid)).replace(/\$4/g,e.clientVersion+"")).replace(/\$5/g,"wxapp")).replace(/\$6/g,e.account)).replace(/\$7/g,e.webSign)).replace(/\$8/g,e.webTime),null,(function(i){
if(i){var n=JSON.parse(i)
if(0==n.state){var r=n.data.serverRoleList
if(e.serverRoleList=r,e.rolesServerList=[],r)for(var o=0;o<r.length;o++)r[o]&&r[o].server&&r[o].server.serverId&&e.rolesServerList.push(r[o].server.serverId+"")
t=(t=(t=(t=(t=(t=(t=(t=(t=dn.serversUrl.replace(/\$1/g,e.imei)).replace(/\$2/g,e.gid)).replace(/\$3/g,e.pid)).replace(/\$4/g,e.clientVersion+"")).replace(/\$5/g,"")).replace(/\$6/g,"wxapp")).replace(/\$7/g,e.webSign)).replace(/\$8/g,e.webTime)).replace(/\$9/g,e.account),
MiniPlatController.sendClick(16),Me(t,null,(function(t){if(MiniPlatController.sendClick(17),t){var i=JSON.parse(t)
if(0==i.state){var n=i.data.servers
e.serverData=n
var r=localStorage.getItem("selectServerId"+e.sdkData.uid)+""
if(n)for(var o=r||launcher.config.testServerId||MiniPlatController.tiShenServers[0],s=0;s<n.length;s++)if(n[s]&&n[s].serverId==o){e.serverId=o,e.selectedServer=n[s],
e.isNewAccount=e.rolesServerList.indexOf(o)<0
break}return launcher.isSDKLogined=!0,launcher.isSubpackLoaded&&launcher._gameBaseInterfaces&&(launcher._gameBaseInterfaces.init(),launcher._gameBaseInterfaces.preload(),
launcher._gameBaseInterfaces.setup()),ci.ins.nextProcess(7)}console.log("---serversUrl responese  data.state!=0")}else console.log("---serversUrl responese  null")}))
}else console.log("---accountsUrl responese  data.state!=0")}else console.log("---accountsUrl responese  null")}))},t.loginCheckProcess=function(){
var e=launcher.config,t=dn.loginCheckUrl.replace(/\$1/g,e.imei)
t=(t=(t=(t=(t=(t=(t=(t=(t=(t=t.replace(/\$2/g,e.gid)).replace(/\$3/g,e.pid)).replace(/\$4/g,e.clientVersion+"")).replace(/\$5/g,"wxapp")).replace(/\$6/g,e.webSign)).replace(/\$7/g,e.webTime)).replace(/\$8/g,e.account)).replace(/\$9/g,"true")).replace(/\$a/g,e.serverId)).replace(/\$b/g,e.selectedServer.serverVersion),
1!=e.selectedServer.state&&3!=e.selectedServer.state&&4!=e.selectedServer.state?(MiniPlatController.sendClick(18),Me(t,null,(function(t){if(MiniPlatController.sendClick(19),t){
var i=JSON.parse(t)
if(0==i.state){var n=i.data
if(e.referer=n.plat,e.sign=n.sign,e.time=""+n.time,e.serverId=""+n.loginServer,n.ext1){var r=JSON.parse(n.ext1)
r.domain&&(e.socketIp=r.domain),r.sslPort&&(e.socketPort=r.sslPort),r.verJs&&(e.verJs=r.verJs),e.serverName=e.selectedServer.name}return MiniPlatController.sendClick(20),
ci.ins.nextProcess(8)}console.log("---loginCheckUrl data.state != 0")}else console.log("---loginCheckUrl responese  null")
}))):this.alert(this.serverTips[e.selectedServer.state],this.exitGame)},t.finishLoginProcess=function(){return ci.ins.nextProcess(9)},t.pay=function(e){launcher.config,
this._sdk.pay(e,(function(e){console.log("--pa y")}))},t.setKeepScreenOn=function(){globalThis.window.qq?globalThis.window.qq.setKeepScreenOn({keepScreenOn:!0
}):globalThis.window.wx.setKeepScreenOn({keepScreenOn:!0})},t.setQueryByShare=function(e){},t.setActivity=function(e){},Oe(e,null,[{key:"ins",get:function(){
return this._ins||(this._ins=new e),this._ins}}]),e}()
Un._ins=void 0,Un.tiShenServers=["90001"],globalThis.MiniPlatController=Un,e._RF.pop(),e._RF.push({},"7794eDJMmZFF4cD3MyG0fsG","FlowSpriteAssembler",void 0)
var Wn=[1,2,0,3],jn={updateColor:function(e){for(var t=e.renderData,i=t.chunk.vb,n=5,r=9,o=t.floatStride,s=e.color,a=s.r/255,l=s.g/255,h=s.b/255,c=s.a/255,u=0;u<4;u++,n+=o,
r+=o)i[n]=a,i[n+1]=l,i[n+2]=h,i[n+3]=c,i[r]=Wn[u],i[r+1]=Yn(e.flowLightColor1),i[r+2]=Yn(e.flowLightColor2),i[r+3]=Yn(e.flowLightColor3)}}
function Yn(e){return e.a>0?(e.r<<16)+(e.g<<8)+e.b:0}var Xn,$n,qn,Jn,Zn,Kn,Qn,er,tr=Pe({},W.Assembler.simple,jn)
e._RF.pop(),e._RF.push({},"0b22fgwn5dN7a+e1J+ASWbu","IBinderObject",void 0),e._RF.pop(),e._RF.push({},"d2e82PeJ59MbKgKgrXDS9P9","TestScript",void 0)
var ir=n.ccclass,nr=n.type
Xn=ir("TestScript"),$n=nr(l),qn=nr(t),Jn=nr([l]),Xn((Kn=ke((Zn=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"targetNode",Kn,De(t)),ze(t,"targetComp",Qn,De(t)),ze(t,"targetNodes",er,De(t)),t}return Le(t,e),t
}(t)).prototype,"targetNode",[$n],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),Qn=ke(Zn.prototype,"targetComp",[qn],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return null}}),er=ke(Zn.prototype,"targetNodes",[Jn],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return[]}}),
Zn)),e._RF.pop(),e._RF.push({},"ece91WS1FhPrLlfQAvilmN1","TweenUtil",void 0),e._RF.pop(),e._RF.push({},"948f7BsbeJBJrPdpZ5NLO8l","parsePlist",void 0)
var rr=/[\{\}]/g
function or(e){var t=(e=e.slice(1,-1)).split(","),i=parseFloat(t[0]),n=parseFloat(t[1])
return new Y(i,n)}function sr(e){var t=(e=e.replace(rr,"")).split(",")
return new N(parseFloat(t[0])||0,parseFloat(t[1])||0,parseFloat(t[2])||0,parseFloat(t[3])||0)}e._RF.pop(),e._RF.push({},"6c116KMGH5NQ7tSbxVLvfkD","AtlasLoader",void 0)
var ar,lr,hr,cr,ur,pr,dr,fr,mr=function(){function e(){this.takeoverComplete=!0,this.atlasResId=0,this._texture=null,this._plist=null,this._atlas=null}var t=e.prototype
return t.loadPng=function(e,t){var i=this,n=hn.loadRemote(e,t)
hn._$dependResId(this.atlasResId,n),hn.listenRes(n,(function(e){i._texture=e,i._checkload()}))},t.parseFormat=function(e){this._plist=e._file,hn._$releaseCocosCache(e),
this._checkload()},t._checkload=function(){this._texture&&this._plist&&(this._atlas=function(e,t){var i,n,r,o,s=e.metadata,a=e.frames,l=new b,h=l.spriteFrames
for(var c in a){var u=a[c],p=!1,d=void 0,f=void 0,m=void 0
0===s.format?(p=!1,d="{"+u.originalWidth+","+u.originalHeight+"}",f="{"+u.offsetX+","+u.offsetY+"}",
m="{{"+u.x+","+u.y+"},{"+u.width+","+u.height+"}}"):1===s.format||2===s.format?(p=u.rotated,d=u.sourceSize,f=u.offset,m=u.frame):3===s.format&&(p=u.textureRotated,
d=u.spriteSourceSize,f=u.spriteOffset,m=u.textureRect)
var _=new x
_.reset({texture:t.texture,originalSize:(i=d,void 0,void 0,void 0,n=(i=i.slice(1,-1)).split(","),r=parseFloat(n[0]),o=parseFloat(n[1]),new ne(r,o)),offset:or(f),isRotate:!!p,
rect:sr(m)},!0),h[re.mainFileName(c)]=_}return l}(this._plist,this._texture),this._plist=null,this._texture=null,hn._$dispatchComplete(this.atlasResId,this._atlas))},
t.clearFormat=function(){this._texture=null,this._plist=null
var e=this._atlas
if(e)for(var t in this._atlas=null,e.spriteFrames)e.spriteFrames[t].destroy()},e.load=function(t,i){void 0===i&&(i=He.RefCycle)
var n=hn.getResId(t)
if(n>0)return n
if(t.startsWith("WEB:/")){(t=t.slice(5)).endsWith(".plist")||(t+=".plist")
var r=new e,o=hn.loadRemote(t,i,{_ResFormat_:r})
r.atlasResId=o
var s=t.replace(".plist",".png")
return r.loadPng(s,i),o}var a=t.indexOf("/"),l=-1==a?null:t.slice(0,a),h=t.slice(a+1)
return hn.loadBundleRes(h,l||"wealth",b,i)},e}()
e._RF.pop(),e._RF.push({},"5d853V5JQpBRpkguMaQdHp6","_UnserializableSprite",void 0)
var _r,gr,yr,vr,br,Tr,wr,Ir,Sr,Rr,xr,Cr,Or,Pr,Lr,Er,Dr,Ar,Fr,zr,kr,Br,Nr,Mr,Hr,Gr=n.ccclass,Vr=n.executeInEditMode,Ur=n.menu,Wr=n.property,jr=(ar=Gr("app/UnserializableSprite"),
lr=Ur("app/UnserializableSprite"),hr=Wr({serializable:!1,override:!0}),cr=Wr({serializable:!1,override:!0}),ar(ur=Vr(ur=lr((dr=ke((pr=function(e){function t(){
for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"_atlas",dr,De(t)),ze(t,"_spriteFrame",fr,De(t)),t}return Le(t,e),t}(W)).prototype,"_atlas",[hr],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return null}}),fr=ke(pr.prototype,"_spriteFrame",[cr],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),
ur=pr))||ur)||ur)||ur)
e._RF.pop(),e._RF.push({},"f4c99gOkw5BJ7M82W+9gyoy","_AtlasSequence",void 0),function(e){e[e.empty=0]="empty",e[e.chenghao2=1]="chenghao2"}(Hr||(Hr={})),o(Hr)
var Yr,Xr,$r,qr,Jr,Zr,Kr,Qr,eo,to,io,no=["","WEB:/chenghao/chenghao2"],ro=n.ccclass,oo=n.menu,so=n.property,ao=n.executeInEditMode,lo=n.type
function ho(e,t){return Number(e)-Number(t)}function co(e){return e>47&&e<58}_r=ro("app/AtlasSequence"),gr=oo("app/AtlasSequence"),yr=so({type:x,editorOnly:!0}),vr=so({type:x,
tooltip:"请拖入动画的某一帧，必须在图集"}),br=lo(Hr),Tr=so({type:Hr,tooltip:'路径前缀，可配置 ["", "chenghao/chenghao3"]'}),wr=so({tooltip:"可配置prefix，path直接填上特效id即可"}),Ir=so({tooltip:"=0 无限循环 >0 循环次数"}),
Sr=so({tooltip:"播放结束remove"}),Rr=so({tooltip:"播放结束回收"}),_r(xr=ao(xr=gr(((Mr=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"_spriteFrame",Or,De(t)),ze(t,"_prefix",Pr,De(t)),ze(t,"_path",Lr,De(t)),ze(t,"_atlasUrl",Er,De(t)),ze(t,"_anim",Dr,De(t)),
ze(t,"_frameRate",Ar,De(t)),ze(t,"flipX",Fr,De(t)),ze(t,"_repeat",zr,De(t)),t._dynamicRepeat=-1,ze(t,"playOverRemove",kr,De(t)),ze(t,"playOverRecover",Br,De(t)),
t.playOverHandler=null,t._atlas=null,t._resId=0,t._frameNames=null,t._frame=-1,t._invalidSize=!0,t.passTime=0,t.frameTime=0,t._isPlaying=!0,t._sprite=null,
ze(t,"animSlice",Nr,De(t)),t}Le(t,e)
var n=t.prototype
return n.play=function(e){null!=e&&(this.repeat=e),this._isPlaying||(this._isPlaying=!0,this._atlas?(this.unschedule(this.loop),this.schedule(this.loop)):this._delayLoad())},
n.replay=function(e){null!=e&&(this.repeat=e),this._resetFrame(),this.play()},n.stop=function(){this._isPlaying&&(this._isPlaying=!1,this.unschedule(this.loop))},
n.onEnable=function(){this._atlasUrl&&this._delayLoad()},n.onDisable=function(){this._releaseRes(),this.unschedule(this.loop)},n._updateUrl=function(){var e
this._path&&(this._releaseRes(),this.unschedule(this.loop),e=this._prefix>0?no[this._prefix]+"/"+this._path:this._path,this._atlasUrl=e,this._anim="",this._delayLoad())},
n._doRefreashFrameNames=function(){var e=this._frameNames
e&&(e.length=0)
var t=this._anim
if(t&&this._atlas){e||(e=[],this._frameNames=e),this.frameTime=1/this.frameRate
var i="/"==t,n=this._atlas.spriteFrames
for(var r in n){var o=-1
if(this.animSlice>0)o=this.animSlice-1
else for(var s=r.length-1;s>=0;s--)if(!co(r.charCodeAt(s))){o=s
break}-1==o?i&&e.push(r):r.slice(0,o+1)==t&&e.push(r.slice(o+1))}if(e.length>1&&e.sort(ho),!i)for(var a=0;a<e.length;a++)e[a]=""+t+e[a]}},n.loop=function(e){if(this._atlas){
var t=this._frameNames
if(t&&0!=t.length){var i=this._sprite
if(i){this.passTime+=e
for(var n=!1;this.passTime>=this.frameTime;)n=!0,this.passTime-=this.frameTime
if(-1==this._frame||n){if(this._frame+=1,this._frame>=t.length){if(REAL_EDITOR)this._frame=0
else if(-1==this._dynamicRepeat&&(this._dynamicRepeat=this.repeat),this._dynamicRepeat>0){if(this._dynamicRepeat--,0==this._dynamicRepeat){this._dynamicRepeat=-1,this.stop()
var r=this.playOverHandler
return r&&(r.once&&(this.playOverHandler=null),r.runWith([this])),this.node.emit("COMPLETE"),
void(this.playOverRecover?this.node.destroy():this.playOverRemove&&this.node.removeFromParent())}this._frame=0}else this._frame=0
this._frame=0}var o=t[this._frame],s=this._atlas.getSpriteFrame(o)
i.spriteFrame=s,i._applySpriteSize()
var a=s.getRect(N.TEMP),l=s.getOffset(Y.TEMP),h=Math.round(a.width),c=Math.round(a.height),u=l.x,p=l.y
if(i.node.transform.setContentSize(h,c),i.node.setPosition(this.flipX?-u:u,p),i.node.setScale(this.flipX?-1:1,1),0==this._frame||this._invalidSize){this._invalidSize=!1
var d=u-h/2,f=p-c/2,m=Math.max(Math.abs(d),Math.abs(d+h)),_=Math.max(Math.abs(f),Math.abs(f+c))
this.node.transform.setContentSize(2*m,2*_)}}}}}},n._delayLoad=function(){
this._atlasUrl&&this._isPlaying&&(REAL_EDITOR||yn(this))&&(REAL_EDITOR?this._doload():(this.unschedule(this._doload),this.scheduleOnce(this._doload)))},n._doload=function(){
this.unschedule(this.loop),this._releaseRes(),this._resId=mr.load(this._atlasUrl),hn._$retainRes(this._resId),hn.listenRes(this._resId,this._doloadcomplete,this)},
n._doloadcomplete=function(e){if(e instanceof b){if(this._atlas=e,!this._anim){var t=""
for(var i in e.spriteFrames){t=i
break}this._anim=this.getAnimName(t)}this._ensureSprite(),this._doRefreashFrameNames(),this.schedule(this.loop,0)}},n._editorRefreshFrame=function(){var e=xe((function*(e){
if(REAL_EDITOR){var t=""
try{t=yield Editor.Message.request("asset-db","query-url",e.atlasUuid)}catch(e){return this._spriteFrame=null,void console.error("SequenceRenderer.frame must in a atlas")}
this._spriteFrame=e,this._anim=this.getAnimName(e.name),this._resetFrame()
var i=t.replace("db://assets/","").replace(".plist","")
this._atlasUrl!=i&&(this._atlasUrl=i,this._releaseRes()),(REAL_EDITOR||yn(this))&&(this._atlas?(this._ensureSprite(),this._doRefreashFrameNames(),this.unschedule(this.loop),
this.schedule(this.loop,0)):this._delayLoad())}}))
return function(t){return e.apply(this,arguments)}}(),n._resetFrame=function(){this._frame=-1,this.passTime=0,this._invalidSize=!0,this._dynamicRepeat=this.repeat},
n._releaseRes=function(){this._frameNames&&(this._frameNames.length=0),this._resId>0&&(hn._$releaseRes(this._resId),hn.removeListenRes(this._resId,this._doloadcomplete,this),
this._resId=0),this._resetFrame(),this._atlas=null
var e=this._ensureSprite(!0)
e&&(e.spriteFrame=null)},n._ensureSprite=function(e){if(this._sprite)return this._sprite
for(var t=null,n=0;n<this.node.children.length;n++){var r=this.node.children[n]
if(("RENDERER_CHILD"==r.name||"Renderer"==r.name)&&(t=r.getComponent(W)))return this._sprite=t,t.node.layer=this.node.layer,t}if(e)return null
var o=l.createUINode("RENDERER_CHILD")
return o.hideFlags|=i.Flags.HideInHierarchy,(t=o.addComponent(jr)).sizeMode=W.SizeMode.CUSTOM,o.layer=this.node.layer,this.node.addChild(o),this._sprite=t,t},
n.getAnimName=function(e){if(this.animSlice>0)return e.slice(0,this.animSlice)
var t=-1
if(this.animSlice>0)t=this.animSlice-1
else for(var i=e.length-1;i>=0;i--)if(!co(e.charCodeAt(i))){t=i
break}return-1==t?"/":e.slice(0,t+1)},Oe(t,[{key:"spriteFrame",get:function(){return this._spriteFrame},set:function(e){REAL_EDITOR&&this._spriteFrame!=e&&(this._atlasUrl="",
this._anim="",this._prefix=Hr.empty,this._path="",this._spriteFrame=null,this.unschedule(this.loop),e?this._editorRefreshFrame(e):this._releaseRes())}},{key:"prefix",
get:function(){return this._prefix},set:function(e){e!=this._prefix&&(this._prefix=e,this._updateUrl())}},{key:"path",get:function(){return this._path},set:function(e){
e!=this._path&&(this._path=e,this._updateUrl())}},{key:"frameRate",get:function(){return this._frameRate},set:function(e){this._frameRate=e||8,this.frameTime=1/this._frameRate}},{
key:"repeat",get:function(){return this._repeat},set:function(e){this._repeat=e,this._dynamicRepeat=e}},{key:"atlasUrl",get:function(){return this._atlasUrl},set:function(e){
this._atlasUrl!=e&&(this._atlasUrl=e,this._releaseRes(),this._delayLoad())}},{key:"anim",get:function(){return this._anim},set:function(e){var t=""===e?"/":e
this._anim!=t&&(this._anim=t,this._atlas&&this._doRefreashFrameNames())}}]),t}(t)).Prefix=Hr,Or=ke((Cr=Mr).prototype,"_spriteFrame",[yr],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return null}}),ke(Cr.prototype,"spriteFrame",[vr],Object.getOwnPropertyDescriptor(Cr.prototype,"spriteFrame"),Cr.prototype),
Pr=ke(Cr.prototype,"_prefix",[br],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return Hr.empty}}),
ke(Cr.prototype,"prefix",[Tr],Object.getOwnPropertyDescriptor(Cr.prototype,"prefix"),Cr.prototype),Lr=ke(Cr.prototype,"_path",[so],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return""}}),ke(Cr.prototype,"path",[wr],Object.getOwnPropertyDescriptor(Cr.prototype,"path"),Cr.prototype),Er=ke(Cr.prototype,"_atlasUrl",[so],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return""}}),Dr=ke(Cr.prototype,"_anim",[so],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){
return""}}),Ar=ke(Cr.prototype,"_frameRate",[so],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 8}}),
ke(Cr.prototype,"frameRate",[so],Object.getOwnPropertyDescriptor(Cr.prototype,"frameRate"),Cr.prototype),Fr=ke(Cr.prototype,"flipX",[so],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return!1}}),zr=ke(Cr.prototype,"_repeat",[so],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),
ke(Cr.prototype,"repeat",[Ir],Object.getOwnPropertyDescriptor(Cr.prototype,"repeat"),Cr.prototype),kr=ke(Cr.prototype,"playOverRemove",[Sr],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return!0}}),Br=ke(Cr.prototype,"playOverRecover",[Rr,so],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!0}}),
Nr=ke(Cr.prototype,"animSlice",[so],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),xr=Cr))||xr)||xr),e._RF.pop(),
e._RF.push({},"50bd0TqI+hIFLDp1wPB0raw","_AutoFullScreenBG",void 0)
var uo,po,fo,mo,_o,go=n.ccclass,yo=(n.executeInEditMode,n.menu),vo=n.property
n.type,Yr=go("app/AutoFullScreenBG"),Xr=yo("app/AutoFullScreenBG"),$r=vo({tooltip:"是否刚好全屏拉伸"}),qr=vo({tooltip:"是否需要略微加大背景避免白边"}),Yr(Jr=Xr((Kr=ke((Zr=function(e){function t(){
for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"isAwakeAdjust",Kr,De(t)),ze(t,"isUpdateAdjust",Qr,De(t)),ze(t,"isForceFullScreen",eo,De(t)),ze(t,"isNeedExtendBg",to,De(t)),
ze(t,"extendSize",io,De(t)),t}return Le(t,e),t}(t)).prototype,"isAwakeAdjust",[vo],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),
Qr=ke(Zr.prototype,"isUpdateAdjust",[vo],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),eo=ke(Zr.prototype,"isForceFullScreen",[$r],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return!0}}),to=ke(Zr.prototype,"isNeedExtendBg",[qr],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!0}}),
io=ke(Zr.prototype,"extendSize",[vo],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return new Y(5,5)}}),Jr=Zr))||Jr),e._RF.pop(),
e._RF.push({},"899f1GZiP5Elpcj7sM3XO/f","_AutoUpdatePosition",void 0)
var bo,To,wo,Io,So=n.ccclass,Ro=(n.executeInEditMode,n.menu),xo=n.property
n.type,So("app/AutoUpdatePosition")(uo=Ro("app/AutoUpdatePosition")((fo=ke((po=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"isWorld",fo,De(t)),ze(t,"isFixedPos",mo,De(t)),ze(t,"target",_o,De(t)),t.lastPos=void 0,t}Le(t,e)
var i=t.prototype
return i.start=function(){this.lastPos=this.node.worldPosition},i.update=function(){this.AutoPos()},i.AutoPos=function(){
this.isWorld?null!=this.target&&(this.node.worldPosition=this.target.worldPosition):this.isFixedPos&&(this.node.worldPosition=this.lastPos)},Oe(t,[{key:"IsFixedPos",
set:function(e){this.isFixedPos=e,this.lastPos=this.node.worldPosition}},{key:"Target",set:function(e){this.target=e}},{key:"IsWorld",set:function(e){this.isWorld=e}}]),t
}(t)).prototype,"isWorld",[xo],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),mo=ke(po.prototype,"isFixedPos",[xo],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return!1}}),_o=ke(po.prototype,"target",[xo],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),uo=po))||uo),
e._RF.pop(),e._RF.push({},"ecc6a3IA59E1K6j0x+SdGwz","_AutoUpdateScale",void 0)
var Co,Oo,Po,Lo,Eo,Do,Ao,Fo,zo=n.ccclass,ko=(n.executeInEditMode,n.menu),Bo=n.property
n.type,zo("app/AutoUpdateScale")(bo=ko("app/AutoUpdateScale")((wo=ke((To=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"isWorld",wo,De(t)),ze(t,"fixScale",Io,De(t)),t}return Le(t,e),t}(t)).prototype,"isWorld",[Bo],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return!0}}),Io=ke(To.prototype,"fixScale",[Bo],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return new z}}),bo=To))||bo),
e._RF.pop(),e._RF.push({},"45c00jQvKlOsYSEhGPNFurq","_FilterScript",void 0)
var No,Mo,Ho,Go,Vo,Uo,Wo,jo=n.ccclass,Yo=(n.executeInEditMode,n.menu),Xo=(n.property,n.type)
Co=jo("app/FilterScript"),Oo=Yo("app/FilterScript"),Po=Xo(l),Lo=Xo(l),Co(Eo=Oo((Ao=ke((Do=function(e){function t(){
for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"texture",Ao,De(t)),ze(t,"filter",Fo,De(t)),t}return Le(t,e),t}(t)).prototype,"texture",[Po],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return null}}),Fo=ke(Do.prototype,"filter",[Lo],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),Eo=Do))||Eo),
e._RF.pop(),e._RF.push({},"5a31aJcuedO4b/H5eHQpP/A","_Image",void 0)
var $o,qo,Jo,Zo,Ko,Qo=n.ccclass,es=n.executeInEditMode,ts=n.menu,is=n.property,ns="WEB",rs=(No=Qo("app/Image"),Mo=ts("app/Image"),Ho=is({tooltip:"图片路径"}),
No(Go=es(Go=Mo((Uo=ke((Vo=function(e){function t(){var t
return ze(t=e.call(this)||this,"retain",Uo,De(t)),t._loaded=!0,t._resId=0,t._opcode=0,t._opCallback=null,ze(t,"_skin",Wo,De(t)),REAL_EDITOR&&(t.__isEditorSkinApply=!1),t}Le(t,e)
var i=t.prototype
return i.onLoad=function(){e.prototype.onLoad.call(this),this.spriteFrame||(this._loaded=!1)},i.onEnable=function(){this.spriteFrame&&!_(this.spriteFrame)&&(this.spriteFrame=null),
e.prototype.onEnable.call(this),this._skin&&!this._loaded&&this._loadSkin(this._opCallback)},i.onDisable=function(){e.prototype.onDisable.call(this),this._skin&&this._releaseRes()
},i.onDestroy=function(){e.prototype.onDestroy.call(this),this._releaseRes()},i.SetItemIconByAtlas=function(e,t,i){this.setSkin(e,null,!1,t)},i.setSkin=function(e,t,i,n){
if(n)e="atlas/"+n+"/"+e
else if(null!=e&&e.indexOf("/")<0){var r=e.indexOf("_"),o="ry"==e.substring(0,2)
r>0&&(e=o?"atlas/"+e.substring(2,r)+"/"+e:"atlas/"+e.substring(0,r)+"/"+e)}e!=this._skin?(this._loaded=!1,this._skin=e||"",this._opCallback=t||null,
this._skin&&yn(this)?((REAL_EDITOR||i)&&(this.spriteFrame=null),this._loadSkin(t)):this._releaseRes()):t&&(!e||this._loaded?t():this._opCallback=t)},i._loadSkin=function(e){
this._loaded=!1,this._opcode>0&&(hn.removeListenRes(this._opcode,this._doloadcomplete,this),this._opcode=0)
var t=function(e){return e.replace(/\\\\|\\/g,"/")}(this._skin),i=null,n=0===t.indexOf("http")
if(n)i=ns
else{var r=t.indexOf(":/");-1!==r&&(i=t.slice(0,r),t=t.slice(r+2)),i||(i="wealth")}REAL_EDITOR?this._editorDoload(t,i,n,e):this._doload(t,i,n,e)},i._doload=function(e,t,i,n){
var r=this
if(t!=ns){var o=e.split("/")
if(-1==o.indexOf("atlas"))n&&(this._opCallback=n),this._opcode=hn.loadBundleRes(e,t,x,He.RefCycle),hn.listenRes(this._opcode,this._doloadcomplete,this)
else{var s=o.pop(),a=o.length>1?o.join("/"):o[0]
a&&s?(n&&(this._opCallback=n),this._opcode=hn.loadBundleRes(a,t,b,He.RefCycle),hn.listenRes(this._opcode,this._doloadcomplete,this)):O("error image skin '"+e+"'")}}else{
if(-1!=e.indexOf("ui/temp"))return
if(i){var l=--this._opcode
v.loadRemote(e,(function(t,i){
l==r._opcode&&(r._opcode=0,r._loaded=!0,i instanceof x?0===i.width||0===i.height?O("web-server is shutdown? '"+r.node.name+"' error image skin '"+e+"'"):r._updateRes(i):O("web-server is shutdown? '"+r.node.name+"' error image skin '"+e+"'"),
n&&n())}))}else n&&(this._opCallback=n),this._opcode=hn.loadRemote(e,He.RefCycle),hn.listenRes(this._opcode,this._doloadcomplete,this)}},i._doloadcomplete=function(e,t,i){
if(this._opcode==t){this._opcode=0
var n=this._resId
if(this._resId=0,this._loaded=!0,e instanceof x)this._resId=t,this._updateRes(e)
else if(e instanceof b){var r=this._skin.split("/"),o=r[r.length-1],s=e.getSpriteFrame(o)
s?(this._resId=t,this._updateRes(s)):O("error image skin '"+i+"', cannot find spf '"+o+"'")}else O("error image skin '"+i+"'")
n!=this._resId&&(n&&hn._$releaseRes(n),this._resId&&hn._$retainRes(this._resId)),this._resId||this._updateRes()
var a=this._opCallback
a&&(this._opCallback=null,a())}else O("[Image] opcode error")},i._editorDoload=function(){var e=xe((function*(e,t,i,n){var r=this
if(REAL_EDITOR){var o=--this._opcode
if(t!=ns){var s=e.split("/")
if(-1==s.indexOf("atlas")){var a="db://assets/"+t+"/"+e+".png",l=yield Editor.Message.request("asset-db","query-uuid",a+"/spriteFrame")
l||(a="db://assets/"+t+"/"+e+".jpg",l=yield Editor.Message.request("asset-db","query-uuid",a+"/spriteFrame")),l?v.loadAny(l,{type:x},(function(t,i){if(o==r._opcode){
if(r._loaded=!0,i instanceof x)return r._forceSetSpriteFrame(i),void(n&&n())
O("'"+r.node.name+"' error image skin '"+e+"'")}})):O("'"+this.node.name+"' error image skin '"+e+"'")}else{var h=s.pop(),c=s.length>1?s.join("/"):s[0]
if(c&&h){var u="db://assets/"+t+"/"+c+".plist",p=yield Editor.Message.request("asset-db","query-uuid",u)
p?v.loadAny(p,{type:b},(function(t,i){if(o==r._opcode){if(r._loaded=!0,i instanceof b){var s=i.getSpriteFrame(h)
if(s instanceof x)return r._forceSetSpriteFrame(s),void(n&&n())}O("'"+r.node.name+"' error image skin '"+e+"'")}})):O("'"+this.node.name+"' error image skin '"+e+"'")
}else O("error image skin '"+e+"'")}}else{var d=i?e:"http://localhost:8999/assets/"+e
v.loadRemote(d,(function(t,i){if(o==r._opcode)if(r._loaded=!0,i instanceof P)if(0===i.width||0===i.height)O("web-server is shutdown? '"+r.node.name+"' error image skin '"+e+"'")
else{var s=x.createWithImage(i)
r._forceSetSpriteFrame(s),n&&n()}else O("web-server is shutdown? '"+r.node.name+"' error image skin '"+e+"'")}))}}}))
return function(t,i,n,r){return e.apply(this,arguments)}}(),i._forceSetSpriteFrame=function(e){REAL_EDITOR&&(this.__isEditorSkinApply=!0),vn(this,e),
REAL_EDITOR&&(this.__isEditorSkinApply=!1)},i._updateRes=function(e){(this.spriteFrame||e)&&(REAL_EDITOR&&(this.__isEditorSkinApply=!0),e?(this.spriteFrame=e,
this._applySpriteSize()):this.spriteFrame=null,REAL_EDITOR&&(this.__isEditorSkinApply=!1))},i._releaseRes=function(){this._resId>0&&(hn._$releaseRes(this._resId),this._resId=0),
this._opcode>0&&(hn.removeListenRes(this._opcode,this._doloadcomplete,this),this._opcode=0),this._opCallback&&(this._opCallback=null),this._loaded=!1,REAL_EDITOR||this._updateRes()
},i._spriteFrameByDrag=function(){this._resId>0&&(hn._$releaseRes(this._resId),this._resId=0),this._opcode>0&&(hn.removeListenRes(this._opcode,this._doloadcomplete,this),
this._opcode=0),this._opCallback&&(this._opCallback=null),this._skin="",this._loaded=null!=this.spriteFrame},i.spriteNameSet=function(e,t){this.setSkin(e,null,null,t)},
i.MakePixelPerfect=function(){},i.fillAmountSet=function(e){isNaN(e)||(this.fillRange=e)},Oe(t,[{key:"skin",get:function(){return this._skin},set:function(e){this.setSkin(e)}}]),t
}(W)).prototype,"retain",[is],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),Wo=ke(Vo.prototype,"_skin",[is],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return""}}),ke(Vo.prototype,"skin",[Ho],Object.getOwnPropertyDescriptor(Vo.prototype,"skin"),Vo.prototype),Go=Vo))||Go)||Go)||Go)
Cn()&&REAL_EDITOR&&(Image.prototype._applySpriteFrame=function(e){W.prototype._applySpriteFrame.call(this,e),this.__isEditorSkinApply||this._spriteFrameByDrag()}),e._RF.pop(),
e._RF.push({},"536f5wHZvFEDZ0nD0GNYE26","_FlowSprite",void 0)
var os=n.ccclass,ss=n.executeInEditMode,as=n.menu,ls=n.property,hs=[new oe.Attribute(oe.AttributeName.ATTR_POSITION,oe.Format.RGB32F),new oe.Attribute(oe.AttributeName.ATTR_TEX_COORD,oe.Format.RG32F),new oe.Attribute(oe.AttributeName.ATTR_COLOR,oe.Format.RGBA32F),new oe.Attribute(oe.AttributeName.ATTR_TEX_COORD1,oe.Format.RG32F),new oe.Attribute(oe.AttributeName.ATTR_TEX_COORD2,oe.Format.RG32F)],cs=os("app/FlowSprite")($o=ss($o=as("app/FlowSprite")((Jo=ke((qo=function(e){
function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"_flowLightColor1",Jo,De(t)),ze(t,"_flowLightColor2",Zo,De(t)),ze(t,"_flowLightColor3",Ko,De(t)),t}Le(t,e)
var i=t.prototype
return i.setLightColors=function(e,t,i){var n=!1
us(this._flowLightColor1,e)&&(n=!0),us(this._flowLightColor2,t)&&(n=!0),us(this._flowLightColor3,i)&&(n=!0),n&&this._updateColor()},i.setLightVisible=function(e,t,i){var n=!1
ps(this._flowLightColor1,e)&&(n=!0),ps(this._flowLightColor2,t)&&(n=!0),ps(this._flowLightColor3,i)&&(n=!0),n&&this._updateColor()},i.requestRenderData=function(e){
void 0===e&&(e=0)
var t=se.add(hs)
return t.initRenderDrawInfo(this,e),this._renderData=t,t},i._flushAssembler=function(){var e=tr
this._assembler!==e&&(this.destroyRenderData(),this._assembler=e),this.renderData||this._assembler&&this._assembler.createData&&(this._renderData=this._assembler.createData(this),
this.renderData.material=this.getRenderMaterial(0),this.markForUpdateRenderData(),this.spriteFrame&&this._assembler.updateUVs(this),this._updateColor()),
this._spriteFrame&&this._spriteFrame.off(x.EVENT_UV_UPDATED,this._updateUVs,this)},Oe(t,[{key:"flowLightColor1",get:function(){return this._flowLightColor1},set:function(e){
this._flowLightColor1.equals(e)||(this._flowLightColor1.set(e),this._updateColor())}},{key:"flowLightColor2",get:function(){return this._flowLightColor2},set:function(e){
this._flowLightColor2.equals(e)||(this._flowLightColor2.set(e),this._updateColor())}},{key:"flowLightColor3",get:function(){return this._flowLightColor3},set:function(e){
this._flowLightColor3.equals(e)||(this._flowLightColor3.set(e),this._updateColor())}}]),t}(rs)).prototype,"_flowLightColor1",[ls],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return new H("#FA4848")}}),ke(qo.prototype,"flowLightColor1",[ls],Object.getOwnPropertyDescriptor(qo.prototype,"flowLightColor1"),qo.prototype),
Zo=ke(qo.prototype,"_flowLightColor2",[ls],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return new H("#7ACC5F")}}),
ke(qo.prototype,"flowLightColor2",[ls],Object.getOwnPropertyDescriptor(qo.prototype,"flowLightColor2"),qo.prototype),Ko=ke(qo.prototype,"_flowLightColor3",[ls],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return new H("#53E1EC")}
}),ke(qo.prototype,"flowLightColor3",[ls],Object.getOwnPropertyDescriptor(qo.prototype,"flowLightColor3"),qo.prototype),$o=qo))||$o)||$o)||$o
function us(e,t){if(t){if(e.equals(t))return!1
e.set(t)}else{if(0==e.a)return!1
e.a=0}return!0}function ps(e,t){return 0!=e.a!=t&&(e.a=t?255:0,!0)}e._RF.pop(),e._RF.push({},"9444cu/GGNH9IxkfEUh+xi2","_FlowSpriteAssembler",void 0)
var ds,fs,ms,_s,gs=[1,2,0,3],ys={updateColor:function(e){for(var t=e.renderData,i=t.chunk.vb,n=5,r=9,o=t.floatStride,s=e.color,a=s.r/255,l=s.g/255,h=s.b/255,c=s.a/255,u=0;u<4;u++,
n+=o,r+=o)i[n]=a,i[n+1]=l,i[n+2]=h,i[n+3]=c,i[r]=gs[u],i[r+1]=vs(e.flowLightColor1),i[r+2]=vs(e.flowLightColor2),i[r+3]=vs(e.flowLightColor3)}}
function vs(e){return e.a>0?(e.r<<16)+(e.g<<8)+e.b:0}Pe({},W.Assembler.simple,ys),e._RF.pop(),e._RF.push({},"524d9Ot18VJJLyPm6Xj6UUq","_ItemIconTag",void 0)
var bs,Ts,ws,Is,Ss,Rs,xs,Cs,Os,Ps,Ls,Es=n.ccclass,Ds=(n.executeInEditMode,n.menu),As=n.property
n.type,Es("app/ItemIconTag")(ds=Ds("app/ItemIconTag")((ms=ke((fs=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"isBaseItem",ms,De(t)),ze(t,"size",_s,De(t)),t}return Le(t,e),t}(t)).prototype,"isBaseItem",[As],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return!0}}),_s=ke(fs.prototype,"size",[As],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 86}}),ds=fs))||ds),
e._RF.pop(),e._RF.push({},"bcb1dseKARBeIh5EU2LoJXB","_Joystick",void 0)
var Fs,zs,ks,Bs,Ns,Ms,Hs,Gs,Vs,Us,Ws,js,Ys,Xs,$s=n.ccclass,qs=(n.executeInEditMode,n.menu),Js=n.property,Zs=n.type
bs=$s("app/Joystick"),Ts=qs("app/Joystick"),ws=Zs(l),Is=Zs(l),Ss=Zs(l),bs(Rs=Ts((Cs=ke((xs=function(e){function t(){
for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"parentTrans",Cs,De(t)),ze(t,"texArea",Os,De(t)),ze(t,"texTouch",Ps,De(t)),ze(t,"radiusPixel",Ls,De(t)),t}return Le(t,e),t
}(t)).prototype,"parentTrans",[ws],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),Os=ke(xs.prototype,"texArea",[Is],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return null}}),Ps=ke(xs.prototype,"texTouch",[Ss],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),
Ls=ke(xs.prototype,"radiusPixel",[Js],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 40}}),Rs=xs))||Rs),e._RF.pop(),
e._RF.push({},"be0ad3Bh+ZCDZCkx/qljd3+","_ListItem",void 0)
var Ks,Qs=n.ccclass,ea=n.property,ta=n.disallowMultiple,ia=n.menu,na=n.executionOrder
!function(e){e[e.NONE=0]="NONE",e[e.TOGGLE=1]="TOGGLE",e[e.SWITCH=2]="SWITCH"}(Ks||(Ks={})),o(Ks)
var ra,oa,sa,aa,la,ha,ca,ua,pa,da,fa,ma,_a,ga,ya,va,ba,Ta,wa,Ia,Sa,Ra,xa,Ca,Oa,Pa,La,Ea,Da,Aa,Fa,za,ka,Ba,Na,Ma,Ha,Ga,Va,Ua,Wa,ja,Ya,Xa,$a,qa=(Fs=Qs("app/ListItem"),zs=ta(),
ks=ia("app/ListItem"),Bs=na(-5001),Ns=ea({type:Ks,tooltip:""}),Ms=ea({type:l,tooltip:"",visible:function(){return this.selectedMode>Ks.NONE}}),Hs=ea({type:x,tooltip:"",
visible:function(){return this.selectedMode==Ks.SWITCH}}),Gs=ea({tooltip:""}),Fs(Vs=zs(Vs=ks(Vs=Bs((Ws=ke((Us=function(e){function i(){
for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"selectedMode",Ws,De(t)),ze(t,"selectedFlag",js,De(t)),ze(t,"selectedSpriteFrame",Ys,De(t)),t._unselectedSpriteFrame=null,
ze(t,"adaptiveSize",Xs,De(t)),t._selected=!1,t._btnCom=void 0,t.list=null,t._eventReg=!1,t.listId=0,t.selectEnbale=!0,t}Le(i,e)
var n=i.prototype
return n.onLoad=function(){if(this.selectedMode==Ks.SWITCH){var e=this.selectedFlag.getComponent(W)
this._unselectedSpriteFrame=e.spriteFrame}this.selectedMode!==Ks.NONE&&this.node.on(l.EventType.TOUCH_END,this.onClickThis,this)},n.onDestroy=function(){
this.node.off(l.EventType.SIZE_CHANGED,this._onSizeChange,this),this.node.off(l.EventType.TOUCH_END,this.onClickThis,this)},n._registerEvent=function(){
this._eventReg||(this.btnCom&&this.list.selectedMode>0&&this.btnCom.clickEvents.unshift(this.createEvt(this,"onClickThis")),
this.adaptiveSize&&this.node.on(l.EventType.SIZE_CHANGED,this._onSizeChange,this),this._eventReg=!0)},n._unregisterEvent=function(){this._eventReg&&(this._eventReg=!1,
this.node.off(l.EventType.SIZE_CHANGED,this._onSizeChange,this))},n._onSizeChange=function(){this.list._onItemAdaptive(this.node)},n.createEvt=function(e,i,n){
if(void 0===n&&(n=null),!e.isValid)return null
e.comName=e.comName||e.name.match(/\<(.*?)\>/g).pop().replace(/\<|>/g,"")
var r=new t.EventHandler
return r.target=n||e.node,r.component=e.comName,r.handler=i,r},n.showAni=function(e,t,i){},n.onClickThis=function(){this.list&&this.selectEnbale&&(this.list.selectedId=this.listId)
},Oe(i,[{key:"selected",get:function(){return this._selected},set:function(e){if(this._selected=e,this.selectedFlag)switch(this.selectEnbale||(this._selected=!1),
this.selectedMode){case Ks.TOGGLE:this.selectedFlag.active=this._selected
break
case Ks.SWITCH:var t=this.selectedFlag.getComponent(W)
t&&(t.spriteFrame=this._selected?this.selectedSpriteFrame:this._unselectedSpriteFrame)}}},{key:"btnCom",get:function(){
return this._btnCom||(this._btnCom=this.node.getComponent(ae)),this._btnCom}}]),i}(t)).prototype,"selectedMode",[Ns],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return Ks.NONE}}),js=ke(Us.prototype,"selectedFlag",[Ms],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),
Ys=ke(Us.prototype,"selectedSpriteFrame",[Hs],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),Xs=ke(Us.prototype,"adaptiveSize",[Gs],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),Vs=Us))||Vs)||Vs)||Vs)||Vs)
e._RF.pop(),e._RF.push({},"36b7akJRJFJSrJK+nvmlfbk","_List",void 0)
var Ja,Za,Ka,Qa,el,tl,il,nl,rl,ol,sl,al,ll,hl,cl,ul,pl,dl,fl,ml,_l,gl,yl,vl,bl,Tl,wl,Il,Sl,Rl,xl,Cl,Ol,Pl,Ll,El,Dl,Al,Fl,zl,kl,Bl,Nl,Ml,Hl,Gl,Vl,Ul,Wl,jl,Yl,Xl,$l,ql,Jl,Zl,Kl,Ql,eh,th,ih,nh,rh,oh,sh,ah,lh,hh,ch,uh,ph,dh,fh,mh,_h,gh,yh,vh,bh,Th=n.ccclass,wh=n.property,Ih=n.disallowMultiple,Sh=n.menu,Rh=n.executionOrder
n.requireComponent,function(e){e[e.NODE=1]="NODE",e[e.PREFAB=2]="PREFAB"}(Ja||(Ja={})),o(Ja),function(e){e[e.NORMAL=1]="NORMAL",e[e.ADHERING=2]="ADHERING",e[e.PAGE=3]="PAGE"
}(Za||(Za={})),o(Za),function(e){e[e.NONE=0]="NONE",e[e.SINGLE=1]="SINGLE",e[e.MULT=2]="MULT",e[e.TOGGLE=3]="TOGGLE"}(Ka||(Ka={})),o(Ka),ra=Th("app/List"),oa=Ih(),
sa=Sh("app/List"),aa=Rh(-5e3),la=wh({type:Ja,tooltip:void 0}),ha=wh({type:l,tooltip:void 0,visible:function(){return this.templateType==Ja.NODE}}),ca=wh({type:m,tooltip:void 0,
visible:function(){return this.templateType==Ja.PREFAB}}),ua=wh({type:Za,tooltip:void 0}),pa=wh({type:le,range:[0,1,.1],tooltip:void 0,slide:!0,visible:function(){
return this._slideMode==Za.PAGE}}),da=wh({type:he,tooltip:void 0}),fa=wh({tooltip:void 0,visible:function(){var e=this.slideMode==Za.NORMAL
return e||(this.cyclic=!1),e}}),ma=wh({tooltip:void 0,visible:function(){return this.virtual}}),_a=wh({tooltip:void 0,visible:function(){var e=this.virtual&&!this.lackCenter
return e||(this.lackSlide=!1),e}}),ga=wh({type:ce}),ya=wh({type:ce,range:[0,6,1],tooltip:void 0,slide:!0}),va=wh({type:ce,range:[0,12,1],tooltip:void 0,slide:!0}),ba=wh({type:Ka,
tooltip:void 0}),Ta=wh({tooltip:void 0,visible:function(){return this.selectedMode==Ka.SINGLE}}),wa=wh({type:he,visible:function(){return!0},override:!0,tooltip:void 0}),Ia=wh({
type:ce,tooltip:void 0,visible:function(){return this._playTween}}),Sa=wh({tooltip:void 0}),Ra=wh({type:he,tooltip:void 0,visible:function(){return this.selectedMode==Ka.SINGLE}}),
xa=wh({tooltip:void 0}),Ca=wh({serializable:!1}),ra(Oa=oa(Oa=sa(Oa=aa((La=ke((Pa=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"_templateType",La,De(t)),ze(t,"tmpNode",Ea,De(t)),ze(t,"tmpPrefab",Da,De(t)),ze(t,"_slideMode",Aa,De(t)),
ze(t,"pageDistance",Fa,De(t)),t.pageChangeEvent=void 0,ze(t,"_virtual",za,De(t)),ze(t,"cyclic",ka,De(t)),ze(t,"lackCenter",Ba,De(t)),ze(t,"lackSlide",Na,De(t)),
ze(t,"_updateRate",Ma,De(t)),ze(t,"frameByFrameRenderNum",Ha,De(t)),t.onlyActiveUseFrame=!0,t._recordFrameByFrameRenderNum=0,t._logListId=void 0,t.renderEvent=void 0,
ze(t,"selectedMode",Ga,De(t)),ze(t,"repeatEventSingle",Va,De(t)),ze(t,"_playTween",Ua,De(t)),ze(t,"opacityTime",Wa,De(t)),t.tweenFn=void 0,ze(t,"initNum",ja,De(t)),
ze(t,"_selectScroll",Ya,De(t)),ze(t,"isRegisterEvent",Xa,De(t)),t.selectedEvent=void 0,t._selectedId=-1,t.multSelected=null,t.lackTop=!1,t.itemList=void 0,t.cellHeight=void 0,
t._forceUpdate=!1,t._adapterCounter=0,t.content=null,t._updateDone=!0,t._opcode=0,ze(t,"_array",$a,De(t)),t._numItems=0,t._inited=!1,t._scrollView=null,t._layout=null,
t._resizeMode=null,t._lastDisplayIds=new Set,t.displayDatas=[],t.displayIds=new Set,t._pool=null,t._itemTmp=null,t._needUpdateWidget=!1,t._itemSize=null,t._sizeType=null,
t._customSize=void 0,t._aniDelRuning=!1,t._aniDelCB=null,t._aniDelItem=void 0,t._aniDelBeforePos=null,t._doneAfterUpdate=!1,t.adhering=!1,t._adheringBarrier=!1,t.curPageNum=0,
t._scrollToSo=void 0,t._scrollItem=void 0,t._defaultInertia=!1,t.contentChildren=[],t._itemClass=void 0,t._clickfun=void 0,t._m_onReposition=null,t._callback=void 0,
t._dragEndCallback=void 0,t}Le(t,e)
var i=t.prototype
return i.setArray=function(e,t){var i=this._array
if(this._virtual&&e&&e.length&&i&&i.length){var n=new Map,r=this._customSize
r&&(this._customSize={})
var o=this._customSize,s=this._lastDisplayIds
s.size&&s.clear()
for(var a=0;a<i.length;a++)n.set(i[a],a)
for(var l=new Map,h=0;h<e.length;h++){var c=e[h],u=n.get(c)
u>=0&&(r&&null!=r[u]&&(o[h]=r[u]),l.set(u,h))}if(t)for(var p=this.contentChildren,d=0;d<p.length;d++){var f=p[d],m=f._listId
if(m>=0){var _=l.get(m)
_>=0?(f._listId=_,s.add(_)):f._listId=-1}}if(r&&0==l.size)for(var g=0;g<e.length;g++)null!=r[g]&&(o[g]=r[g])
n.size&&n.clear(),l.size&&l.clear(),this._delVirtualRedundantItem(s)}this._array=e,this._actualNumItems=this._numItems=e?e.length:0,this._updateNumItems(!0)},
i.setNumItems=function(e,t){if("number"!=typeof e||e<0)g("numItems set the wrong::",e)
else{if(!t){var i=this._lastDisplayIds
i.size&&i.clear(),this._delVirtualRedundantItem(i)}this._actualNumItems=this._numItems=e,this._updateNumItems(!0)}},i._updateNumItems=function(e){var t=this
if(t.checkInited(!1)){if(t._opcode++,e&&(t._forceUpdate=!0),t._virtual)t._scrollItem=null,t._resizeContent(),t.cyclic&&(t._numItems=t._cyclicNum*t._numItems),t._onScrolling(),
t.frameByFrameRenderNum||t.slideMode!=Za.PAGE||(t.curPageNum=t.nearestListId)
else{t.cyclic&&(t._resizeContent(),t._numItems=t._cyclicNum*t._numItems)
var i=t._layout
if(i&&(i.enabled=!0),t._delRedundantItem(),t.frameByFrameRenderNum>0){
for(var n=t.frameByFrameRenderNum>t._numItems?t._numItems:t.frameByFrameRenderNum,r=0;r<n;r++)t._createOrUpdateItem2(r)
t.frameByFrameRenderNum<t._numItems&&(t._updateCounter=t.frameByFrameRenderNum,t._updateDone=!1)}else{for(var o=0;o<t._numItems;o++)t._createOrUpdateItem2(o)
t.displayItemNum=t._numItems}}this._playTween&&this._actualNumItems>0&&(this.tweenFn?this.tweenFn(this.content):function(e,t,i,n){if(void 0===t&&(t=.25),void 0===i&&(i=0),
void 0===n&&(n=.05),0!==e.children.length){var r=e.children[0].y,o=0
e.children.forEach((function(e,s,a){var l=0===i?e:a[a.length-s-1],h=l.y
h!==r&&(r=h,o+=1),l.visible&&(e.opacity=0,function(e,t,i,n,r){void 0===n&&(n=0),ie(i).delay(n).to(e,{opacity:255}).call((function(){})).start()}(t,0,l,o*n))}))
}else console.log("content no child!")}(this.content),this._playTween=!1)}},i.onLoad=function(){this._init(),this._defaultInertia=this._scrollView.inertia},i.onDestroy=function(){
var e=this
_(e._itemTmp)&&e._itemTmp.destroy(),_(e.tmpNode)&&e.tmpNode.destroy(),e._pool&&e._pool.length&&(e._pool.length=0)},i.onEnable=function(){this._registerEvent(),this._init(),
this._aniDelRuning&&(this._aniDelRuning=!1,this._aniDelItem&&(this._aniDelBeforePos&&(this._aniDelItem.position=this._aniDelBeforePos,this._aniDelBeforePos=null),
this._aniDelBeforeScale&&(this._aniDelItem.scale=this._aniDelBeforeScale,this._aniDelBeforeScale=0),delete this._aniDelItem),this._aniDelCB&&(this._aniDelCB(),
this._aniDelCB=null)),this._scrollView.inertia=this._defaultInertia},i.onDisable=function(){this._unregisterEvent(),this._scrollView.inertia=!1},i._registerEvent=function(){
var e=this
e.node.on(l.EventType.TOUCH_START,e._onTouchStart,e),e.node.on(ue.EventType.TOUCH_UP,e._onTouchUp,e),e.node.on(l.EventType.TOUCH_CANCEL,e._onTouchCancelled,e),
e.node.on(ue.EventType.SCROLL_BEGAN,e._onScrollBegan,e),e.node.on(ue.EventType.SCROLL_ENDED,e._onScrollEnded,e),e.node.on(ue.EventType.SCROLLING,e._onScrolling,e),
e.node.on(l.EventType.SIZE_CHANGED,e._onSizeChanged,e)},i._unregisterEvent=function(){var e=this
e.node.off(l.EventType.TOUCH_START,e._onTouchStart,e),e.node.off(ue.EventType.TOUCH_UP,e._onTouchUp,e),e.node.off(l.EventType.TOUCH_CANCEL,e._onTouchCancelled,e),
e.node.off(ue.EventType.SCROLL_BEGAN,e._onScrollBegan,e),e.node.off(ue.EventType.SCROLL_ENDED,e._onScrollEnded,e),e.node.off(ue.EventType.SCROLLING,e._onScrolling,e),
e.node.off(l.EventType.SIZE_CHANGED,e._onSizeChanged,e)},i._init=function(){var e=this
if(!e._inited)if(e._scrollView=e.node.getComponent(ue),e.content=e._scrollView.content,e.content){switch(e._layout=e.content.getComponent(pe)||e.node.getComponent(pe),
e._align=e._layout.type,e._resizeMode=e._layout.resizeMode,e._startAxis=e._layout.startAxis,e._topGap=e._layout.paddingTop,e._rightGap=e._layout.paddingRight,
e._bottomGap=e._layout.paddingBottom,e._leftGap=e._layout.paddingLeft,e._columnGap=e._layout.spacingX,e._lineGap=e._layout.spacingY,e._colLineNum,
e._verticalDir=e._layout.verticalDirection,e._horizontalDir=e._layout.horizontalDirection,e._recordFrameByFrameRenderNum=e.frameByFrameRenderNum,
e.templateType==Ja.PREFAB?e.tmpPrefab?e.setTemplateItem(p(e.tmpPrefab)):g("List init with 'null tmpPrefab' and 'null tmpNode'"):e.tmpNode?e.setTemplateItem(e.tmpNode):g("List init with 'null tmpPrefab' and 'null tmpNode'"),
e._slideMode!=Za.ADHERING&&e._slideMode!=Za.PAGE||(e._scrollView.inertia=!1,e._scrollView._onMouseWheel=function(){}),e.virtual||(e.lackCenter=!1,e.lackTop=!1),
e._lastDisplayIds.clear(),e.displayDatas.length=0,e._pool=[],e._forceUpdate=!1,e._updateCounter=0,e._updateDone=!0,e.curPageNum=0,
e.cyclic&&(e._scrollView._processAutoScrolling=this._processAutoScrolling.bind(e),e._scrollView._startBounceBackIfNeeded=function(){return!1}),e._align){case pe.Type.HORIZONTAL:
switch(e._horizontalDir){case pe.HorizontalDirection.LEFT_TO_RIGHT:e._alignCalcType=1
break
case pe.HorizontalDirection.RIGHT_TO_LEFT:e._alignCalcType=2}break
case pe.Type.VERTICAL:switch(e._verticalDir){case pe.VerticalDirection.TOP_TO_BOTTOM:e._alignCalcType=3
break
case pe.VerticalDirection.BOTTOM_TO_TOP:e._alignCalcType=4}break
case pe.Type.GRID:switch(e._startAxis){case pe.AxisDirection.HORIZONTAL:switch(e._verticalDir){case pe.VerticalDirection.TOP_TO_BOTTOM:e._alignCalcType=3
break
case pe.VerticalDirection.BOTTOM_TO_TOP:e._alignCalcType=4}break
case pe.AxisDirection.VERTICAL:switch(e._horizontalDir){case pe.HorizontalDirection.LEFT_TO_RIGHT:e._alignCalcType=1
break
case pe.HorizontalDirection.RIGHT_TO_LEFT:e._alignCalcType=2}}}this.contentChildren.length=0
for(var t=e.content.children,i=t.length-1;i>=0;i--){var n=t[i]
"fitBackground"!==n.name&&(n.removeFromParent(),n!=e.tmpNode&&n.isValid&&n.destroy())}if(this._virtual&&this.initNum)for(var r=0;r<this.initNum;r++){var o=this._createNewItem(0,0)
this.content.addChild(o),this._hideForPool(o),this._pool.push(o)}
e._inited=!0,this._array&&this._array.length?this.setArray(this._array):this._actualNumItems&&this.setNumItems(this._actualNumItems)
}else g(e.node.name+"'s ScrollView unset content!")},i._processAutoScrolling=function(e){this._scrollView._autoScrollAccumulatedTime+=1*e
var t=Math.min(1,this._scrollView._autoScrollAccumulatedTime/this._scrollView._autoScrollTotalTime)
if(this._scrollView._autoScrollAttenuate){var i=t-1
t=i*i*i*i*i+1}
var n=this._scrollView._autoScrollStartPosition.add(this._scrollView._autoScrollTargetDelta.multiplyScalar(t)),r=this._scrollView.getScrollEndedEventTiming(),o=Math.abs(t-1)<=r
Math.abs(t-1)<=this._scrollView.getScrollEndedEventTiming()&&!this._scrollView._isScrollEndedWithThresholdEventFired&&(this._scrollView._dispatchEvent("scroll-ended-with-threshold"),
this._scrollView._isScrollEndedWithThresholdEventFired=!0),o&&(this._scrollView._autoScrolling=!1)
var s=n.subtract(this._scrollView.getContentPosition())
this._scrollView._moveContent(this._scrollView._clampDelta(s),o),this._scrollView._dispatchEvent("scrolling"),this._scrollView._autoScrolling||(this._scrollView._isBouncing=!1,
this._scrollView._scrolling=!1,this._scrollView._dispatchEvent("scroll-ended"))},i.setTemplateItem=function(e){if(e){var t=this
t._itemTmp=e,t._resizeMode==pe.ResizeMode.CHILDREN?t._itemSize=t._layout.cellSize:t._itemSize=I(e.transform.width,e.transform.height),this.cellHeight=t._itemSize.height
var i=e.getComponent(qa),n=!1
switch(i||(n=!0),n&&(t.selectedMode=Ka.NONE),(i=e.getComponent(a))&&i.enabled&&(t._needUpdateWidget=!0),t.selectedMode==Ka.MULT&&(t.multSelected=[]),t._align){
case pe.Type.HORIZONTAL:t._colLineNum=1,t._sizeType=!1
break
case pe.Type.VERTICAL:t._colLineNum=1,t._sizeType=!0
break
case pe.Type.GRID:switch(t._startAxis){case pe.AxisDirection.HORIZONTAL:var r=t.content.transform.width-t._leftGap-t._rightGap
t._colLineNum=Math.floor((r+t._columnGap)/(t._itemSize.width+t._columnGap)),t._sizeType=!0
break
case pe.AxisDirection.VERTICAL:var o=t.content.transform.height-t._topGap-t._bottomGap
t._colLineNum=Math.floor((o+t._lineGap)/(t._itemSize.height+t._lineGap)),t._sizeType=!1}}}},i.checkInited=function(e){return void 0===e&&(e=!0),
!!this._inited||(e&&O("List initialization not completed!"),!1)},i._resizeContent=function(){var e=this,t=0
switch(e._align){case pe.Type.HORIZONTAL:if(e._customSize){var i=e._getFixedSize(null)
t=e._leftGap+i.val+e._itemSize.width*(e._numItems-i.count)+e._columnGap*(e._numItems-1)+e._rightGap
}else t=e._leftGap+e._itemSize.width*e._numItems+e._columnGap*(e._numItems-1)+e._rightGap
break
case pe.Type.VERTICAL:if(e._customSize){var n=e._getFixedSize(null)
t=e._topGap+n.val+e._itemSize.height*(e._numItems-n.count)+e._lineGap*(e._numItems-1)+e._bottomGap
}else t=e._topGap+e._itemSize.height*e._numItems+e._lineGap*(e._numItems-1)+e._bottomGap
break
case pe.Type.GRID:switch(e.lackCenter&&(e.lackCenter=!1),e._startAxis){case pe.AxisDirection.HORIZONTAL:var r=Math.ceil(e._numItems/e._colLineNum)
t=e._topGap+e._itemSize.height*r+e._lineGap*(r-1)+e._bottomGap
break
case pe.AxisDirection.VERTICAL:var o=Math.ceil(e._numItems/e._colLineNum)
t=e._leftGap+e._itemSize.width*o+e._columnGap*(o-1)+e._rightGap}}var s=e._layout
if(s&&(s.enabled=!1),e._allItemSize=t,e._allItemSizeNoEdge=e._allItemSize-(e._sizeType?e._topGap+e._bottomGap:e._leftGap+e._rightGap),e.cyclic){
var a=e._sizeType?e.node.transform.height:e.node.transform.width
e._cyclicPos1=0,a-=e._cyclicPos1,e._cyclicNum=Math.ceil(a/e._allItemSizeNoEdge)+1
var l=e._sizeType?e._lineGap:e._columnGap
e._cyclicPos2=e._cyclicPos1+e._allItemSizeNoEdge+l,e._cyclicAllItemSize=e._allItemSize+e._allItemSizeNoEdge*(e._cyclicNum-1)+l*(e._cyclicNum-1),
e._cycilcAllItemSizeNoEdge=e._allItemSizeNoEdge*e._cyclicNum,e._cycilcAllItemSizeNoEdge+=l*(e._cyclicNum-1)}
e._lack=!e.cyclic&&e._allItemSize<(e._sizeType?e.node.transform.height:e.node.transform.width)
var h=e._lack&&e.lackCenter&&e.lackTop||!e.lackSlide?.1:0,c=e._lack?(e._sizeType?e.node.transform.height:e.node.transform.width)-h:e.cyclic?e._cyclicAllItemSize:e._allItemSize
c<0&&(c=0),e._sizeType?e.content.transform.height=c:e.content.transform.width=c},i._onScrolling=function(e){
if(this._itemTmp)if(null==this.frameCount&&(this.frameCount=this._updateRate),!this._forceUpdate&&e&&"scroll-ended"!=e.type&&this.frameCount>0)this.frameCount--
else if(this.frameCount=this._updateRate,!this._aniDelRuning){var t=this._opcode
if(this.cyclic){var i=this.content.getPosition()
i=this._sizeType?i.y:i.x
var n=this._allItemSizeNoEdge+(this._sizeType?this._lineGap:this._columnGap),r=this._sizeType?w(0,n):w(n,0)
switch(this._alignCalcType){case 1:i>-this._cyclicPos1?(this.content.x=-this._cyclicPos2,
this._scrollView.isAutoScrolling()&&(this._scrollView._autoScrollStartPosition=this._scrollView._autoScrollStartPosition.subtract(r))):i<-this._cyclicPos2&&(this.content.x=-this._cyclicPos1,
this._scrollView.isAutoScrolling()&&(this._scrollView._autoScrollStartPosition=this._scrollView._autoScrollStartPosition.add(r)))
break
case 2:
i<this._cyclicPos1?(this.content.x=this._cyclicPos2,this._scrollView.isAutoScrolling()&&(this._scrollView._autoScrollStartPosition=this._scrollView._autoScrollStartPosition.add(r))):i>this._cyclicPos2&&(this.content.x=this._cyclicPos1,
this._scrollView.isAutoScrolling()&&(this._scrollView._autoScrollStartPosition=this._scrollView._autoScrollStartPosition.subtract(r)))
break
case 3:
i<this._cyclicPos1?(this.content.y=this._cyclicPos2,this._scrollView.isAutoScrolling()&&(this._scrollView._autoScrollStartPosition=this._scrollView._autoScrollStartPosition.add(r))):i>this._cyclicPos2&&(this.content.y=this._cyclicPos1,
this._scrollView.isAutoScrolling()&&(this._scrollView._autoScrollStartPosition=this._scrollView._autoScrollStartPosition.subtract(r)))
break
case 4:
i>-this._cyclicPos1?(this.content.y=-this._cyclicPos2,this._scrollView.isAutoScrolling()&&(this._scrollView._autoScrollStartPosition=this._scrollView._autoScrollStartPosition.subtract(r))):i<-this._cyclicPos2&&(this.content.y=-this._cyclicPos1,
this._scrollView.isAutoScrolling()&&(this._scrollView._autoScrollStartPosition=this._scrollView._autoScrollStartPosition.add(r)))}}this._calcViewPos()
var o=0,s=0,a=0,l=0
if(this._sizeType?(o=this.viewTop,a=this.viewBottom):(s=this.viewRight,l=this.viewLeft),this._virtual){var h=this.displayDatas
h.length=0
var c=0,u=this._numItems-1
if(this._customSize)for(var p=!1;c<=u&&!p;c++){var d=this._calcItemPos(c)
switch(this._align){case pe.Type.HORIZONTAL:d.right>=l&&d.left<=s?h.push(d):0!=c&&h.length>0&&(p=!0)
break
case pe.Type.VERTICAL:d.bottom<=o&&d.top>=a?h.push(d):0!=c&&h.length>0&&(p=!0)
break
case pe.Type.GRID:switch(this._startAxis){case pe.AxisDirection.HORIZONTAL:d.bottom<=o&&d.top>=a?h.push(d):0!=c&&h.length>0&&(p=!0)
break
case pe.AxisDirection.VERTICAL:d.right>=l&&d.left<=s?h.push(d):0!=c&&h.length>0&&(p=!0)}}}else{var f=this._itemSize.width+this._columnGap,m=this._itemSize.height+this._lineGap
switch(this._alignCalcType){case 1:c=(l-this._leftGap)/f,u=(s-this._leftGap)/f
break
case 2:c=(-s-this._rightGap)/f,u=(-l-this._rightGap)/f
break
case 3:c=(-o-this._topGap)/m,u=(-a-this._topGap)/m
break
case 4:c=(a-this._bottomGap)/m,u=(o-this._bottomGap)/m}for(c=Math.floor(c)*this._colLineNum,u=Math.ceil(u)*this._colLineNum,c<0&&(c=0),
--u>=this._numItems&&(u=this._numItems-1);c<=u;c++)h.push(this._calcItemPos(c))}var _=h.length
this.displayItemNum=_
var g=this.displayIds,y=this._lastDisplayIds
g.size&&g.clear()
for(var v=0;v<_;v++)g.add(h[v].id)
if(y.forEach((function(e){g.has(e)||y.delete(e)})),this._delRedundantItem(),!(h.length<=0)&&this._numItems){
if(this._forceUpdate||this._adapterCounter||_!=y.size)if(this.frameByFrameRenderNum>0)this._numItems>0?(this._updateDone?this._updateCounter=0:this._doneAfterUpdate=!0,
this._updateDone=!1):(this._updateCounter=0,this._updateDone=!0)
else{for(var b=0;b<_;b++)if(this._createOrUpdateItem(h[b]),t!=this._opcode)return
this._forceUpdate=!1}this._calcNearestItem(),this._callback&&this._callback()}}}},i._calcViewPos=function(){var e=this.content.getPosition()
switch(this._alignCalcType){case 1:this.elasticLeft=e.x>0?e.x:0,this.viewLeft=(e.x<0?-e.x:0)-this.elasticLeft,this.viewRight=this.viewLeft+this.node.transform.width,
this.elasticRight=this.viewRight>this.content.transform.width?Math.abs(this.viewRight-this.content.transform.width):0,this.viewRight+=this.elasticRight
break
case 2:this.elasticRight=e.x<0?-e.x:0,this.viewRight=(e.x>0?-e.x:0)+this.elasticRight,this.viewLeft=this.viewRight-this.node.transform.width,
this.elasticLeft=this.viewLeft<-this.content.transform.width?Math.abs(this.viewLeft+this.content.transform.width):0,this.viewLeft-=this.elasticLeft
break
case 3:this.elasticTop=e.y<0?Math.abs(e.y):0,this.viewTop=(e.y>0?-e.y:0)+this.elasticTop,this.viewBottom=this.viewTop-this.node.transform.height,
this.elasticBottom=this.viewBottom<-this.content.transform.height?Math.abs(this.viewBottom+this.content.transform.height):0,this.viewBottom+=this.elasticBottom
break
case 4:this.elasticBottom=e.y>0?Math.abs(e.y):0,this.viewBottom=(e.y<0?-e.y:0)-this.elasticBottom,this.viewTop=this.viewBottom+this.node.transform.height,
this.elasticTop=this.viewTop>this.content.transform.height?Math.abs(this.viewTop-this.content.transform.height):0,this.viewTop-=this.elasticTop}},i._calcItemPos=function(e){
var t=0,i=0,n=0,r=0,o=0,s=0,a=0,l=0
switch(this._align){case pe.Type.HORIZONTAL:switch(this._horizontalDir){case pe.HorizontalDirection.LEFT_TO_RIGHT:if(this._customSize){var h=this._getFixedSize(e)
o=this._leftGap+(this._itemSize.width+this._columnGap)*(e-h.count)+(h.val+this._columnGap*h.count)
var c=this._customSize[e]
t=c>0?c:this._itemSize.width}else o=this._leftGap+(this._itemSize.width+this._columnGap)*e,t=this._itemSize.width
return this.lackCenter?(o-=this._leftGap,o+=this.content.transform.width/2-this._allItemSizeNoEdge/2):this.lackTop&&(o-=this._leftGap,
o+=this.content.transform.width-this._allItemSizeNoEdge),{id:e,left:o,right:s=o+t,x:o+this._itemTmp.transform.anchorX*t,y:this._itemTmp.y}
case pe.HorizontalDirection.RIGHT_TO_LEFT:if(this._customSize){var u=this._getFixedSize(e)
s=-this._rightGap-(this._itemSize.width+this._columnGap)*(e-u.count)-(u.val+this._columnGap*u.count)
var p=this._customSize[e]
t=p>0?p:this._itemSize.width}else s=-this._rightGap-(this._itemSize.width+this._columnGap)*e,t=this._itemSize.width
return this.lackCenter?(s+=this._rightGap,s-=this.content.transform.width/2-this._allItemSizeNoEdge/2):this.lackTop&&(s+=this._rightGap,
s-=this.content.transform.width-this._allItemSizeNoEdge),{id:e,right:s,left:o=s-t,x:o+this._itemTmp.transform.anchorX*t,y:this._itemTmp.y}}break
case pe.Type.VERTICAL:switch(this._verticalDir){case pe.VerticalDirection.TOP_TO_BOTTOM:if(this._customSize){var d=this._getFixedSize(e)
n=-this._topGap-(this._itemSize.height+this._lineGap)*(e-d.count)-(d.val+this._lineGap*d.count)
var f=this._customSize[e]
i=f>0?f:this._itemSize.height}else n=-this._topGap-(this._itemSize.height+this._lineGap)*e,i=this._itemSize.height
return this.lackCenter?(n+=this._topGap,n-=this.content.transform.height/2-this._allItemSizeNoEdge/2):this.lackTop&&(n+=this._topGap,
n-=this.content.transform.height-this._allItemSizeNoEdge),{id:e,top:n,bottom:r=n-i,x:this._itemTmp.x,y:r+this._itemTmp.transform.anchorY*i}
case pe.VerticalDirection.BOTTOM_TO_TOP:if(this._customSize){var m=this._getFixedSize(e)
r=this._bottomGap+(this._itemSize.height+this._lineGap)*(e-m.count)+(m.val+this._lineGap*m.count)
var _=this._customSize[e]
i=_>0?_:this._itemSize.height}else r=this._bottomGap+(this._itemSize.height+this._lineGap)*e,i=this._itemSize.height
return this.lackCenter?(r-=this._bottomGap,r+=this.content.transform.height/2-this._allItemSizeNoEdge/2):this.lackTop&&(r-=this._bottomGap,
r+=this.content.transform.height-this._allItemSizeNoEdge),{id:e,top:n=r+i,bottom:r,x:this._itemTmp.x,y:r+this._itemTmp.transform.anchorY*i}}case pe.Type.GRID:
var g=Math.floor(e/this._colLineNum)
switch(this._startAxis){case pe.AxisDirection.HORIZONTAL:switch(this._verticalDir){case pe.VerticalDirection.TOP_TO_BOTTOM:
l=(r=(n=-this._topGap-(this._itemSize.height+this._lineGap)*g)-this._itemSize.height)+this._itemTmp.transform.anchorY*this._itemSize.height
break
case pe.VerticalDirection.BOTTOM_TO_TOP:n=(r=this._bottomGap+(this._itemSize.height+this._lineGap)*g)+this._itemSize.height,
l=r+this._itemTmp.transform.anchorY*this._itemSize.height}switch(a=this._leftGap+e%this._colLineNum*(this._itemSize.width+this._columnGap),this._horizontalDir){
case pe.HorizontalDirection.LEFT_TO_RIGHT:a+=this._itemTmp.transform.anchorX*this._itemSize.width,a-=this.content.transform.anchorX*this.content.transform.width
break
case pe.HorizontalDirection.RIGHT_TO_LEFT:a+=(1-this._itemTmp.transform.anchorX)*this._itemSize.width,a-=(1-this.content.transform.anchorX)*this.content.transform.width,a*=-1}
return{id:e,top:n,bottom:r,x:a,y:l}
case pe.AxisDirection.VERTICAL:switch(this._horizontalDir){case pe.HorizontalDirection.LEFT_TO_RIGHT:
s=(o=this._leftGap+(this._itemSize.width+this._columnGap)*g)+this._itemSize.width,a=o+this._itemTmp.transform.anchorX*this._itemSize.width,
a-=this.content.transform.anchorX*this.content.transform.width
break
case pe.HorizontalDirection.RIGHT_TO_LEFT:
a=(o=(s=-this._rightGap-(this._itemSize.width+this._columnGap)*g)-this._itemSize.width)+this._itemTmp.transform.anchorX*this._itemSize.width,
a+=(1-this.content.transform.anchorX)*this.content.transform.width}switch(l=-this._topGap-e%this._colLineNum*(this._itemSize.height+this._lineGap),this._verticalDir){
case pe.VerticalDirection.TOP_TO_BOTTOM:l-=(1-this._itemTmp.transform.anchorY)*this._itemSize.height,l+=(1-this.content.transform.anchorY)*this.content.transform.height
break
case pe.VerticalDirection.BOTTOM_TO_TOP:l-=this._itemTmp.transform.anchorY*this._itemSize.height,l+=this.content.transform.anchorY*this.content.transform.height,l*=-1}return{id:e,
left:o,right:s,x:a,y:l}}}throw new Error("List error align '"+this._align+"' ")},i._calcExistItemPos=function(e){var t=this.getItemByListId(e)
if(!t)return null
var i={id:e,x:t.x,y:t.y}
return this._sizeType?(i.top=t.y+t.transform.height*(1-t.transform.anchorY),i.bottom=t.y-t.transform.height*t.transform.anchorY):(i.left=t.x-t.transform.width*t.transform.anchorX,
i.right=t.x+t.transform.width*(1-t.transform.anchorX)),i},i.getItemPos=function(e){return this._virtual||this.frameByFrameRenderNum?this._calcItemPos(e):this._calcExistItemPos(e)},
i._getFixedSize=function(e){if(!this._customSize)return null
null==e&&(e=this._numItems)
var t=0,i=0
for(var n in this._customSize)parseInt(n)<e&&(t+=this._customSize[n],i++)
return{val:t,count:i}},i._onScrollBegan=function(){this._beganPos=this._sizeType?this.viewTop:this.viewLeft},i._onScrollEnded=function(){var e=this
if(e.curScrollIsTouch=!1,null!=e.scrollToListId){var t=e.getItemByListId(e.scrollToListId)
e.scrollToListId=null,t&&ie(t).to(.1,{scale:1.06}).to(.1,{scale:1}).start()}e._onScrolling(),
e._slideMode!=Za.ADHERING||e.adhering?e._slideMode==Za.PAGE&&(null!=e._beganPos&&e.curScrollIsTouch?this._pageAdhere():e.adhere()):e.adhere(),
this._dragEndCallback&&this._dragEndCallback()},i._onTouchStart=function(e,t){if(!this._scrollView._hasNestedViewGroup(e,t)&&(this.curScrollIsTouch=!0,
e.eventPhase!==Event.AT_TARGET||e.target!==this.node)){for(var i=e.target;null==i._listId&&i.parent;)i=i.parent
this._scrollItem=null!=i._listId?i:e.target}},i._onTouchUp=function(){var e=this
e._scrollPos=null,e._slideMode==Za.ADHERING?(this.adhering&&(this._adheringBarrier=!0),e.adhere()):e._slideMode==Za.PAGE&&(null!=e._beganPos?this._pageAdhere():e.adhere()),
this._scrollItem=null},i._onTouchCancelled=function(e,t){var i=this
i._scrollView._hasNestedViewGroup(e,t)||e.simulate||(i._scrollPos=null,i._slideMode==Za.ADHERING?(i.adhering&&(i._adheringBarrier=!0),
i.adhere()):i._slideMode==Za.PAGE&&(null!=i._beganPos?i._pageAdhere():i.adhere()),this._scrollItem=null)},i._onSizeChanged=function(){this.checkInited(!1)&&this._onScrolling()},
i._onItemAdaptive=function(e,t){if(!e._isRendering){var i=e._listId
if(void 0!==t||(t=this._sizeType?e.transform.height:e.transform.width,!this._customSize||this._customSize[i]!=t)){(this._customSize||(this._customSize={}))[i]=t
var n=this._opcode
this._adapterCounter++,this._updateNumItems(!1),this._adapterCounter--,n+1==this._opcode&&null!=this._scrollToListId&&(this._scrollPos=null,this.unschedule(this._scrollToSo))}}},
i._preInitItemSize=function(e,t,i){var n=this._sizeType?i:t;(this._sizeType?e.transform.height:e.transform.width)!=n&&(this._customSize||(this._customSize={}),
this._customSize[e._listId]=n)},i._pageAdhere=function(){var e=this
if(e.cyclic||!(e.elasticTop>0||e.elasticRight>0||e.elasticBottom>0||e.elasticLeft>0)){
var t=e._sizeType?e.viewTop:e.viewLeft,i=(e._sizeType?e.node.transform.height:e.node.transform.width)*e.pageDistance
if(Math.abs(e._beganPos-t)>i){var n=.5
switch(e._alignCalcType){case 1:case 4:e._beganPos>t?e.prePage(n):e.nextPage(n)
break
case 2:case 3:e._beganPos<t?e.prePage(n):e.nextPage(n)}}else e.elasticTop<=0&&e.elasticRight<=0&&e.elasticBottom<=0&&e.elasticLeft<=0&&e.adhere()
e._beganPos=null}},i.adhere=function(){var e=this
if(e.checkInited()&&!(e.elasticTop>0||e.elasticRight>0||e.elasticBottom>0||e.elasticLeft>0)){e.adhering=!0,e._calcNearestItem()
var t=(e._sizeType?e._topGap:e._leftGap)/(e._sizeType?e.node.transform.height:e.node.transform.width)
e.scrollTo(e.nearestListId,.7,t)}},i.update=function(){
if(!(this.frameByFrameRenderNum<=0||this._updateDone))if(this._virtual)for(var e=this._opcode,t=this._updateCounter+this.frameByFrameRenderNum>this.displayItemNum?this.displayItemNum:this._updateCounter+this.frameByFrameRenderNum,i=this._updateCounter;i<t;i++){
var n=this.displayDatas[i]
if(n){this._updateCounter++
var r=this._updateCounter>=this.displayItemNum,o=this._doneAfterUpdate
if(r&&(this._doneAfterUpdate?(this._updateCounter=0,this._updateDone=!1,this._doneAfterUpdate=!1):(this._updateDone=!0,this._forceUpdate=!1,
this.onlyActiveUseFrame&&(this.frameByFrameRenderNum=0),this.slideMode==Za.PAGE&&(this.curPageNum=this.nearestListId))),this._createOrUpdateItem(n),e!=this._opcode)break
r&&!o&&(this._delRedundantItem(),this._calcNearestItem())}}else if(this._updateCounter<this._numItems){
for(var s=this._updateCounter+this.frameByFrameRenderNum>this._numItems?this._numItems:this._updateCounter+this.frameByFrameRenderNum,a=this._updateCounter;a<s;a++)this._createOrUpdateItem2(a)
this._updateCounter+=this.frameByFrameRenderNum}else this._updateDone=!0,this._calcNearestItem(),this.slideMode==Za.PAGE&&(this.curPageNum=this.nearestListId)},
i._createOrUpdateItem=function(e){var t=e.id,i=this.getItemByListId(t)
if(i)this._setPositionForItem(i,e.x,e.y)
else{if(!this._itemTmp)return void g("itemTmp is null")
var n=this._pool.length>0
n?(i=this._pool.pop(),this._getFromPool(i,e.x,e.y)):i=this._createNewItem(e.x,e.y),this._pushItemNode(i),i._isRendering=!0
var r=i.getComponent(qa)
i._listId=t,i.listItem=r
var o=this._itemSize
if(i.transform.width==o.width&&i.transform.height==o.height||(r&&r.adaptiveSize&&this._preInitItemSize(i,o.width,o.height),i.transform.setContentSize(o.width,o.height)),
i.parent!=this.content?this.content.addChild(i):i.setSiblingIndex(this.content.children.length-1),n&&this._needUpdateWidget){var s=i.getComponent(a)
s&&s.updateAlignment()}r&&(r.listId=t,r.list=this,r._registerEvent()),i._isRendering=!1}this._lastDisplayIds.has(t)||(this._lastDisplayIds.add(t),
this._logListId&&console.log("render listId: "+t),this._doRenderEvent(i,t%this._actualNumItems))},i._createOrUpdateItem2=function(e){var t,i=this.contentChildren[e]
if(i)this._forceUpdate&&this.renderEvent&&(t=i.getComponent(qa),i._listId=e,t&&(t.listId=e),this._doRenderEvent(i,e))
else{if(!this._itemTmp)return;(i=this._createNewItem1())._listId=e,i.parent!=this.content&&this.content.addChild(i),this._pushItemNode(i),t=i.getComponent(qa),i.listItem=t,
t&&this.isRegisterEvent&&(t.listId=e,t.list=this,t._registerEvent()),this._doRenderEvent(i,e)}t&&this._updateListItem(t),this._lastDisplayIds.add(e)},
i._createNewItem=function(e,t){var i=this._createNewItem1()
return i.setPosition(e,t),i},i._createNewItem1=function(){var e,t=this,i=this.templateType==Ja.PREFAB?p(this.tmpPrefab):p(this._itemTmp)
return this._itemClass&&(e=i.getCNode(this._itemClass)),this._clickfun&&(e.onClick=function(i){return t._clickfun(e)}),i},i._updateListItem=function(e){
if(e&&this.selectedMode>Ka.NONE){var t=e.node
switch(this.selectedMode){case Ka.SINGLE:e.selected=this.selectedId==t._listId
break
case Ka.MULT:e.selected=this.multSelected.indexOf(t._listId)>=0}}},i._setPositionForItem=function(e,t,i){e.setPosition(t,i)},i.setMultSelected=function(e,t){void 0===t&&(t=null)
var i=this
if(i.checkInited()){var n,r
if(Array.isArray(e)||(e=[e]),null==t)i.multSelected=e
else if(t)for(var o=e.length-1;o>=0;o--)n=e[o],(r=i.multSelected.indexOf(n))<0&&i.multSelected.push(n)
else for(var s=e.length-1;s>=0;s--)n=e[s],(r=i.multSelected.indexOf(n))>=0&&i.multSelected.splice(r,1)
i._forceUpdate=!0,i._lastDisplayIds.size&&i._lastDisplayIds.clear(),i.frameByFrameRenderNum=i._recordFrameByFrameRenderNum,i._onScrolling()}},i.getMultSelected=function(){
return this.multSelected},i.hasMultSelected=function(e){return this.multSelected&&this.multSelected.indexOf(e)>=0},i.updateItem=function(e){if(this.checkInited()){
Array.isArray(e)||(e=[e])
for(var t=this._lastDisplayIds,i=this.displayDatas,n=e.length-1;n>=0;n--){var r=e[n]
t.has(r)?t.delete(r):e.splice(n,1)}var o=this._opcode
if(this._virtual)for(var s=0;s<e.length;s++)for(var a=e[s],l=0;l<i.length;l++){var h=i[l]
if(h.id==a&&(this._createOrUpdateItem(h),o!=this._opcode))return}else for(var c=0,u=e.length;c<u;c++){var p=e[c]
if(this._createOrUpdateItem2(p),o!=this._opcode)return}}},i.updateItemNode=function(e){var t=e._listId
t>=0&&this.updateItem(t)},i.updateAll=function(){this.checkInited()&&(this._array?this.setArray(this._array):this.setNumItems(this._actualNumItems||0))},
i.getItemByListId=function(e){for(var t=this.contentChildren,i=t.length-1;i>=0;i--){var n=t[i]
if(n._listId==e)return n}return null},i.setItemSelected=function(e,t){var i=this.getItemByListId(e)
if(i){var n=i.getComponent(qa)
n&&(n.selected=t)}},i.getItemId=function(e){return e._listId},i.updateItemByIndex=function(e){var t=this.getItemByListId(e)
t&&this._doRenderEvent(t,e%this._actualNumItems)},i._doRenderEvent=function(e,t){if(e){var i=this._array
if(e._cnode&&e._cnode.SetData(i[t]),this.itemList||(this.itemList=new Ii.CList),this.itemList[t]=e._cnode,this._m_onReposition&&this._m_onReposition(e),this.renderEvent){
e._isRendering=!0
var n=this.renderEvent
n.once&&(this.renderEvent=void 0),n.runWith([e,t,i?i[t]:null,i,this])
var r=e.listItem
if(r&&(this._updateListItem(r),r.adaptiveSize)){var o=e.getComponent(pe)
o&&o.enabled&&o.updateLayout()
var s=this._customSize&&null!=this._customSize[e._listId]?this._customSize[e._listId]:this._sizeType?this._itemSize.height:this._itemSize.width,a=this._sizeType?e.transform.height:e.transform.width
if(s!=a)return e._isRendering=!1,this._opcode++,void this._onItemAdaptive(e,a)}e._isRendering=!1}}},i._delRedundantItem=function(){
if(this._virtual)this._delVirtualRedundantItem(this.displayIds)
else for(var e=this.contentChildren;e.length>this._numItems;)this._delSingleItem(e[e.length-1])},i._delVirtualRedundantItem=function(e){
for(var t=this._lastDisplayIds,i=this.contentChildren,n=this._scrollItem?this._scrollItem._listId:-1,r=i.length-1;r>=0;r--){var o=i[r],s=o._listId
s>=0&&s==n||e.has(s)||(i.splice(r,1),this._hideForPool(o),this._pool.push(o),e!=t&&t.delete(s))}},i._getFromPool=function(e,t,i){e.setPosition(t,i),e.visible=!0},
i._hideForPool=function(e){e.setPosition(-1e4,-1e4),e.visible=!1},i._delSingleItem=function(e){var t=this.contentChildren.indexOf(e);-1!=t&&this.contentChildren.splice(t,1),
e.removeFromParent(),e.destroy&&e.destroy()},i._pushItemNode=function(e){-1==this.contentChildren.indexOf(e)&&this.contentChildren.push(e)},i.aniDelItem=function(e,t,i){var n=this
if(!n.checkInited()||n.cyclic||!n._virtual)return g("This function is not allowed to be called!")
if(!t)return g("CallFunc are not allowed to be NULL, You need to delete the corresponding index in the data array in the CallFunc!")
if(n._aniDelRuning)return O("Please wait for the current deletion to finish!")
var r,o=n.getItemByListId(e)
if(o){r=o.getComponent(qa),n._aniDelRuning=!0,n._aniDelCB=t,n._aniDelItem=o,n._aniDelBeforePos=o.position,n._aniDelBeforeScale=o.scale
var s=n.displayDatas[n.displayDatas.length-1].id,a=r.selected
r.showAni(i,(function(){var i=null
if(s<n._numItems-2&&(i=s+1),null!=i){var r=n._calcItemPos(i)
n.displayDatas.push(r),n._virtual?n._createOrUpdateItem(r):n._createOrUpdateItem2(i)}else n._numItems--
if(n.selectedMode==Ka.SINGLE)a?n._selectedId=-1:n._selectedId-1>=0&&n._selectedId--
else if(n.selectedMode==Ka.MULT&&n.multSelected.length){var l=n.multSelected.indexOf(e)
l>=0&&n.multSelected.splice(l,1)
for(var h=n.multSelected.length-1;h>=0;h--)n.multSelected[h]>=e&&n.multSelected[h]--}if(n._customSize){n._customSize[e]&&delete n._customSize[e]
var c,u={}
for(var p in n._customSize){c=n._customSize[p]
var d=parseInt(p)
u[d-(d>=e?1:0)]=c}n._customSize=u}for(var f,m=!1,_=null!=i?i:s;_>=e+1;_--)if(o=n.getItemByListId(_)){var g=n._calcItemPos(_-1)
f=ie(o).to(.2333,{position:w(g.x,g.y)}),_<=e+1&&(m=!0,f.call((function(){n._aniDelRuning=!1,t(e),n._aniDelCB=null}))),f.start()}m||(n._aniDelRuning=!1,t(e),n._aniDelCB=null)}),!0)
}else t(e)},i.scrollTo=function(e,t,i,n){void 0===t&&(t=.5),void 0===i&&(i=null),void 0===n&&(n=!1)
var r=this
if(r.checkInited(!1)){null==t?t=.5:t<0&&(t=0),e<0?e=0:e>=r._numItems&&(e=r._numItems-1),!r._virtual&&r._layout&&r._layout.enabled&&r._layout.updateLayout()
var o,s,a=r.getItemPos(e)
if(!a)return!1
switch(r._alignCalcType){case 1:o=a.left,o-=null!=i?r.node.transform.width*i:r._leftGap,a=w(o,0)
break
case 2:o=a.right-r.node.transform.width,o+=null!=i?r.node.transform.width*i:r._rightGap,a=w(o+r.content.transform.width,0)
break
case 3:s=a.top,s+=null!=i?r.node.transform.height*i:r._topGap,a=w(0,-s)
break
case 4:s=a.bottom+r.node.transform.height,s-=null!=i?r.node.transform.height*i:r._bottomGap,a=w(0,-s+r.content.transform.height)}var l=r.content.getPosition()
l=Math.abs(r._sizeType?l.y:l.x)
var h=r._sizeType?a.y:a.x
if(Math.abs((null!=r._scrollPos?r._scrollPos:l)-h)>.5)r._scrollView.scrollToOffset(a,t),r._scrollToListId=e,r._scrollToEndTime=(new Date).getTime()/1e3+t,
r._scrollToSo=r.scheduleOnce((function(){if(r._adheringBarrier||(r.adhering=r._adheringBarrier=!1),r._scrollPos=r._scrollToListId=r._scrollToEndTime=r._scrollToSo=null,n){
var t=r.getItemByListId(e)
t&&ie(t).repeat(2,ie().to(.1,{scale:1.05}).to(.1,{scale:1})).start()}}),t+.1),t<=0&&r._onScrolling()
else if(n){var c=r.getItemByListId(e)
c&&ie(c).repeat(2,ie().to(.1,{scale:1.05}).to(.1,{scale:1})).start()}}},i.safeScrollTo=function(e,t,i){var n=this
void 0===t&&(t=null),void 0===i&&(i=!1),this.scheduleOnce((function(){n.stopAutoScroll(),n.scrollTo(e,0,t,i)}))},i.stopAutoScroll=function(){
this._scrollView&&this._scrollView.isAutoScrolling()&&this._scrollView.stopAutoScroll()},i._calcNearestItem=function(){var e,t,i,n,r,o,s=this
s.nearestListId=null,s._virtual&&s._calcViewPos(),i=s.viewTop,n=s.viewRight,r=s.viewBottom,o=s.viewLeft
for(var a=!1,l=0;l<s.contentChildren.length&&!a;l+=s._colLineNum)if(e=s._virtual?s.displayDatas[l]:s._calcExistItemPos(l))switch(t=s._sizeType?(e.top+e.bottom)/2:t=(e.left+e.right)/2,
s._alignCalcType){case 1:e.right>=o&&(s.nearestListId=e.id,o>t&&(s.nearestListId+=s._colLineNum),a=!0)
break
case 2:e.left<=n&&(s.nearestListId=e.id,n<t&&(s.nearestListId+=s._colLineNum),a=!0)
break
case 3:e.bottom<=i&&(s.nearestListId=e.id,i<t&&(s.nearestListId+=s._colLineNum),a=!0)
break
case 4:e.top>=r&&(s.nearestListId=e.id,r>t&&(s.nearestListId+=s._colLineNum),a=!0)}
if((e=s._virtual?s.displayDatas[s.displayItemNum-1]:s._calcExistItemPos(s._numItems-1))&&e.id==s._numItems-1)switch(t=s._sizeType?(e.top+e.bottom)/2:t=(e.left+e.right)/2,
s._alignCalcType){case 1:n>t&&(s.nearestListId=e.id)
break
case 2:o<t&&(s.nearestListId=e.id)
break
case 3:r<t&&(s.nearestListId=e.id)
break
case 4:i>t&&(s.nearestListId=e.id)}},i.prePage=function(e){void 0===e&&(e=.5),this.checkInited()&&this.skipPage(this.curPageNum-1,e)},i.nextPage=function(e){void 0===e&&(e=.5),
this.checkInited()&&this.skipPage(this.curPageNum+1,e)},i.skipPage=function(e,t){var i=this
if(i.checkInited()){if(i._slideMode!=Za.PAGE)return g("This function is not allowed to be called, Must SlideMode = PAGE!")
if(!(e<0||e>=i._numItems)&&i.curPageNum!=e){if(i.curPageNum=e,i.pageChangeEvent){var n=i.pageChangeEvent
n.once&&(i.pageChangeEvent=void 0),n.runWith([e])}i.scrollTo(e,t)}}},i.calcCustomSize=function(e){var t=this
if(t.checkInited()){if(!t._itemTmp)return g("Unset template item!")
if(!t.renderEvent)return g("Unset Render-Event!")
t._customSize={}
var i=p(t._itemTmp)
t.content.addChild(i),this._pushItemNode(i)
for(var n=this._array,r=0;r<e;r++){var o=t.renderEvent
o&&(o.once&&(t.renderEvent=void 0),o.runWith([i,r,n?n[r]:null,n,this])),i.height==t._itemSize.height&&i.width==t._itemSize.width||(t._customSize[r]=t._sizeType?i.height:i.width)}
return Object.keys(t._customSize).length||(t._customSize=null),i.removeFromParent(),i.destroy&&i.destroy(),t._customSize}},i.SetInitInfo=function(e,t,i,n,r){this._itemClass=i,
this._clickfun=n},i.OnReposition_set=function(e){this._m_onReposition=e},i.data_set=function(e){this.array=e},i.getItem=function(e){
return this.getItemByListId(e).getCNode(this._itemClass)},i.updateItems=function(){this.updateAll()},i.RegistonDragingMoving=function(e){this._callback=e},
i.RegistonDragFinished=function(e){this._dragEndCallback=e},i.getScrollPercent=function(){var e=this.scrollView.horizontal,t=this.scrollView._calculateMovePercentDelta({
anchor:new Y(0,0),applyToHorizontal:e,applyToVertical:!e}),i=this.scrollView.getMaxScrollOffset()
return e?t.x/i.x:t.y/i.y},i.scrollToLeft=function(){this.scrollView.scrollToLeft()},i.data_get=function(){return this._array},i.clipOffset=function(){
return this.scrollView.getScrollOffset()},i.cellWidthSet=function(e){this._itemSize=I(e,this._itemSize.height)},i.scrollToTop=function(e,t){this.scrollView.scrollToTop(e,t)},
i.ResetPosition=function(){},i.Clear=function(){},i.Reposition=function(){},i.AjustContentSize=function(){},Oe(t,[{key:"templateType",get:function(){return this._templateType},
set:function(e){null!=e&&(this._templateType=e),e===Ja.NODE?this.tmpPrefab=null:e===Ja.PREFAB&&(this.tmpNode=null)}},{key:"slideMode",get:function(){return this._slideMode},
set:function(e){this._slideMode=e}},{key:"virtual",get:function(){return this._virtual},set:function(e){null!=e&&(this._virtual=e),0!=this._numItems&&this._onScrolling()}},{
key:"updateRate",get:function(){return this._updateRate},set:function(e){e>=0&&e<=6&&(this._updateRate=e)}},{key:"playTween",get:function(){return this._playTween},set:function(e){
null!=e&&(this._playTween=e)}},{key:"selectScroll",get:function(){return this._selectScroll},set:function(e){null!=e&&(this._selectScroll=e)}},{key:"selectedId",get:function(){
return this._selectedId},set:function(e){var t,i=this
switch(i.selectedMode){case Ka.SINGLE:if(!i.repeatEventSingle&&e==i._selectedId)return
if(t=i.getItemByListId(e),i._selectedId>=0?i._lastSelectedId=i._selectedId:i._lastSelectedId=null,i._selectedId=e,t&&(t.getComponent(qa).selected=!0),
i._lastSelectedId>=0&&i._lastSelectedId!=i._selectedId){var n=i.getItemByListId(i._lastSelectedId)
n&&(n.getComponent(qa).selected=!1)}if(i.selectedEvent&&t){var r=i.selectedEvent
r.once&&(i.selectedEvent=void 0)
var o=this._array,s=e%this._actualNumItems
r.runWith([t,s,null==i._lastSelectedId?null:i._lastSelectedId%this._actualNumItems,o?o[s]:null])}var a=this.displayDatas
a.length&&this._selectScroll&&(i.selectedId===a[a.length-1].id?this.scrollTo(i._selectedId-a.length+3):i.selectedId-1<=a[0].id&&this.scrollTo(i._selectedId-1))
break
case Ka.MULT:if(!(t=i.getItemByListId(e)))return
var l=t.getComponent(qa)
i._selectedId>=0&&(i._lastSelectedId=i._selectedId),i._selectedId=e
var h=!l.selected
l.selected=h
var c=i.multSelected.indexOf(e)
if(h&&c<0?i.multSelected.push(e):!h&&c>=0&&i.multSelected.splice(c,1),i.selectedEvent){var u=i.selectedEvent
u.once&&(i.selectedEvent=void 0),u.runWith([t,e%this._actualNumItems,null==i._lastSelectedId?null:i._lastSelectedId%this._actualNumItems,h])}break
case Ka.TOGGLE:if(e===i._selectedId&&(e=-1),t=i.getItemByListId(e),i._selectedId>=0?i._lastSelectedId=i._selectedId:i._lastSelectedId=null,i._selectedId=e,
t&&(t.getComponent(qa).selected=!0),i._lastSelectedId>=0&&i._lastSelectedId!=i._selectedId){var p=i.getItemByListId(i._lastSelectedId)
p&&(p.getComponent(qa).selected=!1)}if(i.selectedEvent){var d=i.selectedEvent
d.once&&(i.selectedEvent=void 0),d.runWith([t,e%this._actualNumItems,null==i._lastSelectedId?null:i._lastSelectedId%this._actualNumItems])}}}},{key:"array",get:function(){
return this._array},set:function(e){this.setArray(e)}},{key:"numItems",get:function(){return this._actualNumItems},set:function(e){this.setNumItems(e)}},{key:"scrollView",
get:function(){return this._scrollView}}]),t}(t)).prototype,"_templateType",[wh],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return Ja.NODE}}),
ke(Pa.prototype,"templateType",[la],Object.getOwnPropertyDescriptor(Pa.prototype,"templateType"),Pa.prototype),Ea=ke(Pa.prototype,"tmpNode",[ha],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return null}}),Da=ke(Pa.prototype,"tmpPrefab",[ca],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),
Aa=ke(Pa.prototype,"_slideMode",[wh],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return Za.NORMAL}}),
ke(Pa.prototype,"slideMode",[ua],Object.getOwnPropertyDescriptor(Pa.prototype,"slideMode"),Pa.prototype),Fa=ke(Pa.prototype,"pageDistance",[pa],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return.3}}),za=ke(Pa.prototype,"_virtual",[wh],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!0}}),
ke(Pa.prototype,"virtual",[da],Object.getOwnPropertyDescriptor(Pa.prototype,"virtual"),Pa.prototype),ka=ke(Pa.prototype,"cyclic",[fa],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return!1}}),Ba=ke(Pa.prototype,"lackCenter",[ma],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),
Na=ke(Pa.prototype,"lackSlide",[_a],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),Ma=ke(Pa.prototype,"_updateRate",[ga],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return 0}}),ke(Pa.prototype,"updateRate",[ya],Object.getOwnPropertyDescriptor(Pa.prototype,"updateRate"),Pa.prototype),
Ha=ke(Pa.prototype,"frameByFrameRenderNum",[va],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),Ga=ke(Pa.prototype,"selectedMode",[ba],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return Ka.NONE}}),Va=ke(Pa.prototype,"repeatEventSingle",[Ta],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return!1}}),Ua=ke(Pa.prototype,"_playTween",[wh],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),
ke(Pa.prototype,"playTween",[wa],Object.getOwnPropertyDescriptor(Pa.prototype,"playTween"),Pa.prototype),Wa=ke(Pa.prototype,"opacityTime",[Ia],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return.25}}),ja=ke(Pa.prototype,"initNum",[Sa],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),
Ya=ke(Pa.prototype,"_selectScroll",[wh],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),
ke(Pa.prototype,"selectScroll",[Ra],Object.getOwnPropertyDescriptor(Pa.prototype,"selectScroll"),Pa.prototype),Xa=ke(Pa.prototype,"isRegisterEvent",[xa],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return!0}}),$a=ke(Pa.prototype,"_array",[Ca],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),
Oa=Pa))||Oa)||Oa)||Oa),e._RF.pop(),e._RF.push({},"069468N9eJCepbYsc9DrQAK","_LuaMyUIGrid",void 0)
var xh,Ch,Oh,Ph=n.ccclass,Lh=n.property,Eh=n.requireComponent,Dh=n.menu,Ah=1e-5
!function(e){e[e.HORIZONTAL=0]="HORIZONTAL",e[e.VERTICAL=1]="VERTICAL"}(xh||(xh={})),o(xh),function(e){e[e.TOP_TO_BOTTOM=0]="TOP_TO_BOTTOM",e[e.BOTTOM_TO_TOP=1]="BOTTOM_TO_TOP"
}(Ch||(Ch={})),o(Ch),function(e){e[e.LEFT_TO_RIGHT=0]="LEFT_TO_RIGHT",e[e.RIGHT_TO_LEFT=1]="RIGHT_TO_LEFT"}(Oh||(Oh={})),o(Oh)
var Fh,zh,kh,Bh
!function(e){e[e.TOP=0]="TOP",e[e.BOTTOM=1]="BOTTOM"}(Fh||(Fh={})),o(Fh),function(e){e[e.LEFT=0]="LEFT",e[e.RIGHT=1]="RIGHT"}(zh||(zh={})),o(zh),function(e){e[e.NODE=1]="NODE",
e[e.PREFAB=2]="PREFAB"}(kh||(kh={})),o(kh),Qa=Ph("app/LuaMyUIGrid"),el=Eh(s),tl=Dh("app/LuaMyUIGrid"),il=Lh(s),nl=Lh({type:kh,tooltip:void 0}),rl=Lh({type:l,tooltip:void 0,
visible:function(){return this.templateType==kh.NODE}}),ol=Lh({type:m,tooltip:void 0,visible:function(){return this.templateType==kh.PREFAB}}),sl=Lh({type:xh}),al=Lh({type:Fh,
visible:function(){return this.layoutType==xh.VERTICAL&&!this.autoCenter}}),ll=Lh({type:zh,visible:function(){return this.layoutType==xh.HORIZONTAL&&!this.autoCenter}}),hl=Lh({
type:Ch}),cl=Lh({type:Oh}),ul=Lh({tooltip:"最小值=1，大于1就是Grid模式"}),pl=Lh({tooltip:"决定最多创建Prefab的数量"}),dl=Lh({tooltip:"顶部填充"}),fl=Lh({tooltip:"底部填充"}),ml=Lh({tooltip:"左侧填充"}),_l=Lh({
tooltip:"右侧填充"}),gl=Lh({tooltip:"横轴间距"}),yl=Lh({tooltip:"纵轴间距"}),vl=Lh({tooltip:"计算缩放后的尺寸"}),bl=Lh({tooltip:"开启翻页模式"}),Tl=Lh({tooltip:"CellWidth"}),wl=Lh({tooltip:"CellHeight"}),
Il=Lh({tooltip:"rowLimit",visible:function(){return this.layoutType==xh.VERTICAL}}),Sl=Lh({tooltip:"colLimit",visible:function(){return this.layoutType==xh.HORIZONTAL}}),Rl=Lh({
tooltip:"每个页面翻页时所需时间。单位：秒",visible:function(){return this.isPageView}}),xl=Lh({type:de,visible:function(){return this.isPageView}}),Cl=Lh({slide:!0,range:[0,1,.01],
tooltip:"滚动临界值，默认单位百分比，当拖拽超出该数值时，松开会自动滚动下一页，小于时则还原",visible:function(){return this.isPageView}}),Ol=Lh({
tooltip:"快速滑动翻页临界值。当用户快速滑动时，会根据滑动开始和结束的距离与时间计算出一个速度值,该值与此临界值相比较，如果大于临界值，则进行自动翻页",visible:function(){return this.isPageView}}),Pl=Lh({type:fe,visible:function(){
return this.isPageView}}),Ll=Lh({tooltip:"开启自动居中",visible:function(){return!this.isPageView}}),El=Lh({tooltip:"自动居中的滚动时间",visible:function(){return this.autoCenter}}),Dl=Lh({
type:l,tooltip:"自动居中的参考节点，如果为空、则默认选择View中心",visible:function(){return this.autoCenter}}),Al=Lh({tooltip:"自动居中时、Item的居中锚点",visible:function(){return this.autoCenter}}),Fl=Lh({
tooltip:"上/左 无限循环"}),zl=Lh({tooltip:"下/右 无限循环"}),kl=Lh(fe),Qa(Bl=el(Bl=tl(((bh=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"view",Ml,De(t)),ze(t,"_templateType",Hl,De(t)),ze(t,"tmpNode",Gl,De(t)),ze(t,"tmpPrefab",Vl,De(t)),ze(t,"layoutType",Ul,De(t)),
ze(t,"indexVerticalAxisDirection",Wl,De(t)),ze(t,"indexHorizontalAxisDirection",jl,De(t)),ze(t,"verticalAxisDirection",Yl,De(t)),ze(t,"horizontalAxisDirection",Xl,De(t)),
ze(t,"groupItemTotal",$l,De(t)),ze(t,"multiple",ql,De(t)),ze(t,"paddingTop",Jl,De(t)),ze(t,"paddingBottom",Zl,De(t)),ze(t,"paddingLeft",Kl,De(t)),ze(t,"paddingRight",Ql,De(t)),
ze(t,"spacingX",eh,De(t)),ze(t,"spacingY",th,De(t)),ze(t,"affectedByScale",ih,De(t)),ze(t,"isPageView",nh,De(t)),ze(t,"cellWidth",rh,De(t)),ze(t,"cellHeight",oh,De(t)),
ze(t,"rowLimit",sh,De(t)),ze(t,"colLimit",ah,De(t)),ze(t,"pageTurningSpeed",lh,De(t)),ze(t,"indicator",hh,De(t)),ze(t,"scrollThreshold",ch,De(t)),
ze(t,"autoPageTurningThreshold",uh,De(t)),ze(t,"pageEvents",ph,De(t)),ze(t,"autoCenter",dh,De(t)),ze(t,"centerTime",fh,De(t)),ze(t,"centerNode",mh,De(t)),
ze(t,"centerAnchor",_h,De(t)),ze(t,"headerLoop",gh,De(t)),ze(t,"footerLoop",yh,De(t)),ze(t,"refreshItemEvents",vh,De(t)),t.stretchLock={},t.renderEvent=null,t._itemCls=null,
t._itemClick=null,t._currPageIndex=0,t._lastPageIndex=0,t.isRestart=!1,t.scrollDirection=0,t.prevPos=new z(0,0,0),t._maxPrefabTotal=0,t.currentCreateItemTotal=0,t._itemTotal=0,
t.m_onReposition=null,t._array=null,t.itemList=void 0,t}Le(t,e)
var i=t.prototype
return i.SetInitInfo=function(e,t,i,n,r){t&&(this.renderEvent=t),this._itemCls=i,this._itemClick=n},i.onLoad=function(){var e,t
this.view&&(null==(e=this.transform)||e.setContentSize(this.view.contentSize),null==(t=this.transform)||t.setAnchorPoint(new Y(.5,.5)),this.node.setPosition(z.ZERO)),
this.isPageView&&(this.autoCenter=!1),this.tmpNode&&this.tmpNode.removeFromParent()},i.onEnable=function(){this.addEventListener()},i.onDisable=function(){
this.removeEventListener()},i.total=function(e,t){void 0===t&&(t=!1),this.currentCreateItemTotal=e,this.createItems(e,t)
var i=e-this.itemTotal
return this._itemTotal=e,this.refreshItems(i,t),t||this.updateItems(),this.autoCenter&&this.scrollToCenter(),this.m_onReposition&&this.m_onReposition(),this},
i.OnReposition_set=function(e){this.m_onReposition=e},i.data_set=function(e){this._array=e,this.total(e?e.length:0)},i.data_get=function(){return this._array},
i.setArray=function(){var e=xe((function*(e){this._array=e,yield this.total(e?e.length:0)}))
return function(t){return e.apply(this,arguments)}}(),i.updateItems=function(){return this.resetIndexStartToEnd(this.headerIndex),this},i.updateItemSize=function(e,t){
this.groupItemTotal>1||e&&t&&(e.__runtime_size=t,this.onChangeChildSize(e._uiProps.uiTransformComp))},i.scrollToCenter=function(){this.soonFinish()},i.scrollToHeader=function(e){
var t,i,n=0
if(this.vertical)this.verticalAxisDirection==Ch.TOP_TO_BOTTOM?(n=this.viewHeaderBoundary,
this.indexVerticalAxisDirection==Fh.BOTTOM&&(n-=(null==(t=this.header)?void 0:t.height)+this.paddingTop+this.paddingBottom)):(n=this.viewFooterBoundary,
this.indexVerticalAxisDirection==Fh.TOP&&(n+=(null==(i=this.header)?void 0:i.height)+this.paddingTop+this.paddingBottom))
else if(this.horizontalAxisDirection==Oh.LEFT_TO_RIGHT){var r
n=this.viewHeaderBoundary,this.indexHorizontalAxisDirection==zh.RIGHT&&(n+=(null==(r=this.header)?void 0:r.width)+this.paddingLeft+this.paddingRight)}else{var o
n=this.viewFooterBoundary,this.indexHorizontalAxisDirection==zh.LEFT&&(n-=(null==(o=this.header)?void 0:o.width)+this.paddingLeft+this.paddingRight)}
this.scrollToIndex(0,e,new z(n,n))},i.scrollToFooter=function(e){var t=0
if(this.vertical){if(this.fixedItemHeight<this.viewHeight)return
var i,n
this.verticalAxisDirection==Ch.TOP_TO_BOTTOM?(t=this.viewFooterBoundary,this.indexVerticalAxisDirection==Fh.BOTTOM&&(t+=(null==(i=this.footer)?void 0:i.height)+this.paddingTop+this.paddingBottom)):(t=this.viewHeaderBoundary,
this.indexVerticalAxisDirection==Fh.TOP&&(t-=(null==(n=this.footer)?void 0:n.height)+this.paddingTop+this.paddingBottom))}else{if(this.fixedItemWidth<this.viewWidth)return
var r,o
this.horizontalAxisDirection==Oh.LEFT_TO_RIGHT?(t=this.viewFooterBoundary,this.indexHorizontalAxisDirection==zh.RIGHT&&(t-=(null==(r=this.footer)?void 0:r.width)+this.paddingLeft+this.paddingRight)):(t=this.viewHeaderBoundary,
this.indexHorizontalAxisDirection==zh.LEFT&&(t+=(null==(o=this.footer)?void 0:o.width)+this.paddingLeft+this.paddingRight))}this.scrollToIndex(this.itemTotal-1,e,new z(t,t),!0)},
i.isNearFooter=function(e){var t=!1
if(e>this.footerIndex&&e<this.headerIndex){var i=Math.abs(e-this.headerIndex)<Math.abs(e-this.footerIndex)
t=this.vertical?this.verticalAxisDirection==Ch.TOP_TO_BOTTOM?!i:i:this.horizontalAxisDirection==Oh.LEFT_TO_RIGHT?!i:i
}else e>this.footerIndex?t=this.vertical?this.verticalAxisDirection==Ch.TOP_TO_BOTTOM:this.horizontalAxisDirection==Oh.LEFT_TO_RIGHT:e<this.headerIndex&&(t=this.vertical?this.verticalAxisDirection!=Ch.TOP_TO_BOTTOM:this.horizontalAxisDirection!=Oh.LEFT_TO_RIGHT)
return t},i.getFooterOffset=function(e){var t=this.footerIndex%this.groupItemTotal
return e%this.groupItemTotal-t+this.groupItemTotal},i.getHeaderOffset=function(e){return this.headerIndex%this.groupItemTotal-e%this.groupItemTotal+this.groupItemTotal},
i.offsetToHeader=function(e){var t=0
t=this.vertical?this.verticalAxisDirection==Ch.TOP_TO_BOTTOM?this.getHeaderOffset(e):this.getFooterOffset(e):this.horizontalAxisDirection==Oh.LEFT_TO_RIGHT?this.getHeaderOffset(e):this.getFooterOffset(e),
t-=this.groupItemTotal
for(var i=0;i<t;i++)this.pushToHeader(!0)},i.offsetToFooter=function(e){var t=0
t=this.vertical?this.verticalAxisDirection==Ch.TOP_TO_BOTTOM?this.getFooterOffset(e):this.getHeaderOffset(e):this.horizontalAxisDirection==Oh.LEFT_TO_RIGHT?this.getFooterOffset(e):this.getHeaderOffset(e),
t-=this.groupItemTotal
for(var i=0;i<t;i++)this.pushToFooter(!0)},i.resetIndexStartToEnd=function(e){for(var t=0;t<this.node.children.length;t++){var i=this.node.children[t]
i.__index=e,e++,(this.headerLoop||this.footerLoop)&&(e<0||e>=this.itemTotal)&&(e=0),this.notifyRefreshItem(i)}},i.resetIndexEndToStart=function(e){
for(var t=this.node.children.length-1;t>=0;t--){var i=this.node.children[t]
i.__index=e,e--,(this.headerLoop||this.footerLoop)&&e<0&&(e=this.itemTotal-1),this.notifyRefreshItem(i)}},i.scrollToIndex=function(e,t,i,n){var r
if(void 0===n&&(n=!1),!(isNaN(e)||e<0||e>this.itemTotal-1)){var o=this.node.children.find((function(t){return t.__index==e})),s=this.isNearFooter(e)
if(this.stretchLock.index=e,this.stretchLock.timeInSecond=t,this.stretchLock.boundary=i,this.stretchLock.reverse=n,!o){0==e&&this.pushToHeader(),
e==this.itemTotal-1&&this.pushToFooter()
var a=this.vertical&&this.verticalAxisDirection==Ch.TOP_TO_BOTTOM||!this.vertical&&this.horizontalAxisDirection==Oh.LEFT_TO_RIGHT
s?(this.offsetToFooter(e),a?this.resetIndexEndToStart(e):this.resetIndexStartToEnd(e)):(this.offsetToHeader(e),a?this.resetIndexStartToEnd(e):this.resetIndexEndToStart(e)),
o=this.node.children.find((function(t){return t.__index==e}))}if(o){var l=o.getPosition().clone()
this.autoCenter||(this.vertical?this.indexVerticalAxisDirection==Fh.TOP?l.y=n?this.getItemYMin(o._uiProps.uiTransformComp)-this.paddingBottom:this.getItemYMax(o._uiProps.uiTransformComp)+this.paddingTop:l.y=n?this.getItemYMax(o._uiProps.uiTransformComp)+this.paddingTop:this.getItemYMin(o._uiProps.uiTransformComp)-this.paddingBottom:this.indexHorizontalAxisDirection==zh.LEFT?l.x=n?this.getItemXMax(o._uiProps.uiTransformComp)+this.paddingRight:this.getItemXMin(o._uiProps.uiTransformComp)-this.paddingLeft:l.x=n?this.getItemXMin(o._uiProps.uiTransformComp)-this.paddingLeft:this.getItemXMax(o._uiProps.uiTransformComp)+this.paddingRight)
var h,c=null==(r=this.transform)?void 0:r.convertToWorldSpaceAR(l),u=this.view.convertToNodeSpaceAR(c)
h=!this.autoCenter&&i?i:this.getCenterAnchor(o._uiProps.uiTransformComp,this.centerPosition),u.multiply(new z(-1,-1,1)).add(h)}}},i.onViewSizeChange=function(){
var e=xe((function*(){this.isRestart=!0,this.createItems(this.currentCreateItemTotal),this.resetChilds(!0),this.scrollToHeader()
for(var e=0;e<this.node.children.length;e++){var t=this.node.children[e]._uiProps.uiTransformComp
this.setAndSaveSizeAndScale(t)}this.isRestart=!1}))
return function(){return e.apply(this,arguments)}}(),i.setAndSaveSizeAndScale=function(e){e.setContentSize(this.getItemSize(e)),e.node.__size=e.contentSize.clone(),
e.node.__scale=e.node.getScale().clone()},i.getCenterAnchor=function(e,t){var i=t.clone()
if(this.vertical){var n=e.height*this.centerAnchor.y,r=e.height*e.anchorY
i.y-=n-r}else{var o=e.width*this.centerAnchor.x,s=e.width*e.anchorX
i.x+=o-s}return i},i.soonFinish=function(){if(this.autoCenter){for(var e=new z(999999,999999),t=0;t<this.node.children.length;t++){
var i,n=this.node.children[t],r=null==(i=this.transform)?void 0:i.convertToWorldSpaceAR(n.position),o=this.view.convertToNodeSpaceAR(r),s={width:!1,height:!1
},a=this.getCenterAnchor(n._uiProps.uiTransformComp,this.centerPosition),l=o.subtract(a)
s.width=Math.abs(l.x)<Math.abs(e.x),s.height=Math.abs(l.y)<Math.abs(e.y),(this.vertical&&s.height||!this.vertical&&s.width)&&(e=l)}e.multiply(new z(-1,-1,1))}},
i.getItemSize=function(e){var t=new ne
return t.width=this.cellWidth,t.height=this.cellHeight,t},i.getItemYMax=function(e){if(!e)return 0
var t=this.getScaleHeight(e)*(1-e.anchorY)
return e.node.position.y+t},i.getItemYMin=function(e){if(!e)return 0
var t=this.getScaleHeight(e)*e.anchorY
return e.node.position.y-t},i.getItemXMax=function(e){if(!e)return 0
var t=this.getScaleWidth(e)*(1-e.anchorX)
return e.node.position.x+t},i.getItemXMin=function(e){if(!e)return 0
var t=this.getScaleWidth(e)*e.anchorX
return e.node.position.x-t},i.getStartX=function(e){return e?(this.horizontalAxisDirection,Oh.LEFT_TO_RIGHT,this.viewStartPoint.x):0},i.getEndX=function(e){if(!e)return 0
var t=0
if(this.horizontalAxisDirection==Oh.LEFT_TO_RIGHT){var i=this.cellWidth*(1-e.anchorX)
t=-this.viewStartPoint.x-i-this.paddingRight+this.paddingLeft}else{var n=this.cellWidth*e.anchorX
t=-this.viewStartPoint.x+n+this.paddingLeft-this.paddingRight}return t},i.getStartY=function(e){return e?(this.verticalAxisDirection,Ch.TOP_TO_BOTTOM,this.viewStartPoint.y):0},
i.getEndY=function(e){if(!e)return 0
var t=0
if(this.verticalAxisDirection==Ch.TOP_TO_BOTTOM){var i=this.getScaleHeight(e)*e.anchorY
t=-this.viewStartPoint.y+i+this.paddingBottom-this.paddingTop}else{var n=this.getScaleHeight(e)*(1-e.anchorY)
t=-this.viewStartPoint.y-n-this.paddingTop+this.paddingBottom}return t},i.isAccommodateByTop=function(e){return this.getItemYMax(e)+this.paddingTop<.5*this.accommodHeight},
i.isAccommodateByBottom=function(e){return this.getItemYMin(e)-this.paddingBottom>-.5*this.accommodHeight},i.isAccommodateByLeft=function(e){
return this.getItemXMin(e)-this.paddingLeft>-.5*this.accommodWidth},i.isAccommodateByRight=function(e){return this.getItemXMax(e)+this.paddingRight<.5*this.accommodWidth},
i.getRelativeByLeft=function(e,t){return t.node.position.x-this.spacingX-this.cellWidth},i.getRelativeByRight=function(e,t){return t.node.position.x+this.spacingX+this.cellWidth},
i.getRelativeByTop=function(e,t){return t.node.position.y+this.spacingY+this.cellHeight},i.getRelativeByBottom=function(e,t){return t.node.position.y-this.spacingY-this.cellHeight
},i.setItemPosition=function(e,t,i,n){void 0===i&&(i=!1),void 0===n&&(n=!1)
var r=new z
n?(r.x=this.getStartX(e),r.y=this.getStartY(e)):r=this.vertical?this.getVerticalRelativePosition(e,t,i):this.getHorizontalRelativePosition(e,t,i),e.node.setPosition(r)},
i.getVerticalRelativePosition=function(e,t,i){var n,r=new z
return n=this.horizontalAxisDirection==Oh.LEFT_TO_RIGHT?i?this.isAccommodateByLeft(t):this.isAccommodateByRight(t):i?this.isAccommodateByRight(t):this.isAccommodateByLeft(t),
this.horizontalAxisDirection==Oh.LEFT_TO_RIGHT?r.x=i?n?this.getRelativeByLeft(e,t):this.getEndX(e):n?this.getRelativeByRight(e,t):this.getStartX(e):r.x=i?n?this.getRelativeByRight(e,t):this.getEndX(e):n?this.getRelativeByLeft(e,t):this.getStartX(e),
this.verticalAxisDirection==Ch.TOP_TO_BOTTOM?r.y=i?n?t.node.position.y:this.getRelativeByTop(e,t):n?t.node.position.y:this.getRelativeByBottom(e,t):r.y=i?n?t.node.position.y:this.getRelativeByBottom(e,t):n?t.node.position.y:this.getRelativeByTop(e,t),
r},i.getHorizontalRelativePosition=function(e,t,i){var n,r=new z
return n=this.verticalAxisDirection==Ch.TOP_TO_BOTTOM?i?this.isAccommodateByTop(t):this.isAccommodateByBottom(t):i?this.isAccommodateByBottom(t):this.isAccommodateByTop(t),
this.verticalAxisDirection==Ch.TOP_TO_BOTTOM?r.y=i?n?this.getRelativeByTop(e,t):this.getEndY(e):n?this.getRelativeByBottom(e,t):this.getStartY(e):r.y=i?n?this.getRelativeByBottom(e,t):this.getEndY(e):n?this.getRelativeByTop(e,t):this.getStartY(e),
this.horizontalAxisDirection==Oh.LEFT_TO_RIGHT?r.x=i?n?t.node.position.x:this.getRelativeByLeft(e,t):n?t.node.position.x:this.getRelativeByRight(e,t):r.x=i?n?t.node.position.x:this.getRelativeByRight(e,t):n?t.node.position.x:this.getRelativeByLeft(e,t),
r},i.refreshItems=function(e,t){if(void 0===t&&(t=!1),e<0){for(var i=0;i<-e;i++)this.headerLoop||this.footerLoop?this.pushToHeader():(this.pushToHeader(!0),this.pushToFooter())
var n=this.headerIndex>0?this.headerIndex:0
n+this.node.children.length>this.itemTotal&&(n+=e),n<0&&(n=0)
for(var r=0;r<this.node.children.length;r++){var o=this.node.children[r];(this.headerLoop||this.footerLoop)&&n>this.itemTotal-1&&(n=0),o.__index=n,n++,t&&this.notifyRefreshItem(o)}
}else for(var s=0;s<this.node.children.length;s++)this.vertical?this.verticalAxisDirection==Ch.TOP_TO_BOTTOM?this.pushToFooter():this.pushToHeader():this.horizontalAxisDirection==Oh.LEFT_TO_RIGHT?this.pushToFooter():this.pushToHeader()
},i.createItems=function(e,t){var i=this
if(this.node.children.length>e)this.removeItems(e)
else if(this.needAddPrefab()||!(this._maxPrefabTotal>0)||this._maxPrefabTotal!=this.node.children.length){var n=e-this.node.children.length
n>0&&!this.itemList&&(this.itemList=new Ii.CList)
for(var r=function(e){var t=p(i.templateType==kh.NODE?i.tmpNode:i.tmpPrefab),n=t._uiProps.uiTransformComp
if(i.setAndSaveSizeAndScale(n),t.__index=i.node.children.length,i.node.addChild(t),i._itemCls){var r=t.getCNode(i._itemCls)
i.itemList[t.__index]=r,i._itemClick&&(r.onClick=function(e){return i._itemClick(r)})
}else i.renderEvent&&(i.itemList[t.__index]=i.renderEvent([t,e,i._array?i._array[t.__index]:void 0]),nt(i.itemList[t.__index]))
var o=i.node.children.length-2
if(0==t.__index?i.footer:i.node.children[o]._uiProps.uiTransformComp,t.on(l.EventType.SIZE_CHANGED,(function(){i.onChangeChildSize(n)}),i,!0),
t.on(l.EventType.TRANSFORM_CHANGED,(function(e){i.onChangeChildScale(e,n)}),i,!0),i.notifyRefreshItem(t),i.setItemPos(t._uiProps.uiTransformComp,t.__index),
!i.needAddPrefab())return i._maxPrefabTotal=i.node.children.length,console.log("已固定item数量",i._maxPrefabTotal),"break"},o=0;o<n&&"break"!==r(o);o++);}},i.setItemPos=function(e,t){
var i=new z,n=this.vertical?this.rowLimit:this.colLimit
i.x=Math.floor(t/n)*this.cellWidth,i.y=-t%n*this.cellHeight,e.node.position=i},i.needAddPrefab=function(){return!0},i.onChangeChildSize=function(){var e=xe((function*(e){
var t=e.node
if(this.groupItemTotal>1){var i=t.__size
return e.setContentSize(i),void console.warn("表格布局不支持动态修改 Size,如果你非要修改，那你把我注释掉看效果")}
this.stretchLock.index==t.__index&&this.scrollToIndex(this.stretchLock.index,this.stretchLock.timeInSecond,this.stretchLock.boundary,this.stretchLock.reverse),
this.resetStrectchItems()}))
return function(t){return e.apply(this,arguments)}}(),i.onChangeChildScale=function(){var e=xe((function*(e,t){if(e===l.TransformBit.SCALE&&this.affectedByScale){var i=t.node
if(this.groupItemTotal>1){var n=i.__scale
return t.node.setScale(n),void console.warn("表格布局不支持动态修改 Scale,如果你非要修改，那你把我注释掉看效果")}
this.stretchLock.index==i.__index&&this.scrollToIndex(this.stretchLock.index,this.stretchLock.timeInSecond,this.stretchLock.boundary,this.stretchLock.reverse),
this.resetStrectchItems()}}))
return function(t,i){return e.apply(this,arguments)}}(),i.resetStrectchItems=function(){var e=this
if(!isNaN(this.stretchLock.index)){var t=this.node.children.findIndex((function(t){return t.__index==e.stretchLock.index}))
if(-1!=t){for(var i=t;i>=0;i--){var n=this.node.children[i]
i!=t&&i<t&&this.setItemPosition(n._uiProps.uiTransformComp,this.node.children[i+1]._uiProps.uiTransformComp,!0)}for(var r=t;r<this.node.children.length;r++){
var o=this.node.children[r]
r!=t&&this.setItemPosition(o._uiProps.uiTransformComp,this.node.children[r-1]._uiProps.uiTransformComp)}return}}1==this.scrollDirection?(this.unschedule(this.stretchToFooter),
this.scheduleOnce(this.stretchToFooter)):(this.unschedule(this.stretchToHeader),this.scheduleOnce(this.stretchToHeader))},i.stretchToHeader=function(){
for(var e=this.node.children.length-1;e>=0;e--){var t=this.node.children[e]
e!=this.node.children.length-1&&this.setItemPosition(t._uiProps.uiTransformComp,this.node.children[e+1]._uiProps.uiTransformComp,!0)}},i.stretchToFooter=function(){
for(var e=0;e<this.node.children.length;e++){var t=this.node.children[e]
0!=e&&this.setItemPosition(t._uiProps.uiTransformComp,this.node.children[e-1]._uiProps.uiTransformComp)}},i.removeItems=function(e){
for(var t=this.node.children.length-e,i=0;i<t;i++){var n=this.node.children[this.node.children.length-1]
n.off(l.EventType.SIZE_CHANGED),n.off(l.EventType.TRANSFORM_CHANGED),this.node.removeChild(n),n!=this.tmpNode&&n.destroy()}},i.addEventListener=function(){
this.node.on(c.TRANSFORM_CHANGED,this.onPositionChanged,this)},i.removeEventListener=function(){this.node.off(c.TRANSFORM_CHANGED,this.onPositionChanged,this)},
i.resetChilds=function(e){if(void 0===e&&(e=!1),this.vertical&&this.fixedItemHeight<=this.viewHeight||!this.vertical&&this.fixedItemWidth<=this.viewWidth){
var t,i=this.getStartX(this.header),n=this.getStartY(this.header)
null==(t=this.header)||t.node.setPosition(new z(i,n))}if(e)if(this.vertical){var r,o=this.getStartX(this.header)
null==(r=this.header)||r.node.setPosition(new z(o,this.header.node.position.y))}else{var s,a=this.getStartY(this.header)
null==(s=this.header)||s.node.setPosition(new z(this.header.node.position.x,a))}this.stretchToFooter()},i.onTouchBegin=function(){this.stretchLock={}},
i.getUsedScaleValue=function(e){return this.affectedByScale?Math.abs(e):1},i.getScaleWidth=function(e){if(!e)return 0
var t=e.node.__runtime_size
return(t?t.width:e.width)*this.getUsedScaleValue(e.node.scale.x)},i.getScaleHeight=function(e){if(!e)return 0
var t=e.node.__runtime_size
return(t?t.height:e.height)*this.getUsedScaleValue(e.node.scale.y)},i.onPositionChanged=function(){if(!this.isRestart){if(this.vertical||(this.scrollDirection=0),
this.vertical)for(var e=0;e<this.node.children.length;e++)Math.abs(this.prevPos.y-this.node.position.y)>Ah&&(this.prevPos.y<this.node.position.y?this.pushToFooter():this.prevPos.y>this.node.position.y&&this.pushToHeader())
else for(var t=0;t<this.node.children.length;t++)Math.abs(this.prevPos.x-this.node.position.x)>Ah&&(this.prevPos.x>this.node.position.x?this.pushToFooter():this.prevPos.x<this.node.position.x&&this.pushToHeader())
this.prevPos=this.node.position.clone()}},i.pushToFooter=function(e){var t,i,n
if(void 0===e&&(e=!1),this.vertical)this.verticalAxisDirection==Ch.TOP_TO_BOTTOM?(e||this.headerBoundary-this.paddingTop>this.viewHeaderBoundary+(null==(n=this.header)?void 0:n.height))&&this.pushToFooterHandler():(e||this.footerBoundary-this.paddingTop>this.viewHeaderBoundary+(null==(i=this.header)?void 0:i.height))&&this.pushToHeaderHandler()
else if(this.horizontalAxisDirection==Oh.LEFT_TO_RIGHT){var r
;(e||this.headerBoundary+this.paddingLeft<this.viewHeaderBoundary-(null==(r=this.header)?void 0:r.width))&&this.pushToFooterHandler()
}else(e||this.footerBoundary+this.paddingLeft<this.viewHeaderBoundary-(null==(t=this.header)?void 0:t.width))&&this.pushToHeaderHandler()},i.pushToHeader=function(e){var t,i,n
if(void 0===e&&(e=!1),this.vertical)this.verticalAxisDirection==Ch.TOP_TO_BOTTOM?(e||this.footerBoundary+this.paddingBottom<this.viewFooterBoundary-(null==(n=this.footer)?void 0:n.height))&&this.pushToHeaderHandler():(e||this.headerBoundary+this.paddingBottom<this.viewFooterBoundary-(null==(i=this.footer)?void 0:i.height))&&this.pushToFooterHandler()
else if(this.horizontalAxisDirection==Oh.LEFT_TO_RIGHT){var r
;(e||this.footerBoundary-this.paddingRight>this.viewFooterBoundary+(null==(r=this.footer)?void 0:r.width))&&this.pushToHeaderHandler()
}else(e||this.headerBoundary-this.paddingRight>this.viewFooterBoundary+(null==(t=this.footer)?void 0:t.width))&&this.pushToFooterHandler()},i.pushToFooterHandler=function(){
var e,t,i=null==(e=this.header)?void 0:e.node
if(this.vertical?this.verticalAxisDirection==Ch.TOP_TO_BOTTOM?this.footerLoop:this.headerLoop:this.horizontalAxisDirection==Oh.LEFT_TO_RIGHT?this.footerLoop:this.headerLoop)this.footerIndex>=this.itemTotal-1?i.__index=0:i.__index=this.footerIndex+1
else{if(!this.footer||this.footerIndex>=this.itemTotal-1)return
i.__index=this.footerIndex+1}i.__index>0&&i.__index<this.currentCreateItemTotal&&this.notifyRefreshItem(i),this.setItemPosition(this.header,this.footer),
null==(t=this.header)||t.node.setSiblingIndex(this.node.children.length)},i.Reposition=function(e){},i.pushToHeaderHandler=function(){
var e,t,i,n=null==(e=this.footer)?void 0:e.node
if((i=this.vertical?this.verticalAxisDirection==Ch.TOP_TO_BOTTOM?this.headerLoop:this.footerLoop:this.horizontalAxisDirection==Oh.LEFT_TO_RIGHT?this.headerLoop:this.footerLoop)||0!=this.headerIndex||(this.vertical?this.horizontalAxisDirection==Oh.LEFT_TO_RIGHT?this.isAccommodateByLeft(this.header):this.isAccommodateByRight(this.header):this.verticalAxisDirection==Ch.TOP_TO_BOTTOM?this.isAccommodateByTop(this.header):this.isAccommodateByBottom(this.header))&&this.resetChilds(!0),
i)0==this.headerIndex?n.__index=this.itemTotal-1:n.__index=this.headerIndex-1
else{if(!this.header||0==this.headerIndex)return
n.__index=this.headerIndex-1}n.__index>0&&n.__index<this.currentCreateItemTotal&&this.notifyRefreshItem(n),this.setItemPosition(this.footer,this.header,!0),
null==(t=this.footer)||t.node.setSiblingIndex(0)},i.notifyRefreshItem=function(e){var t=e.__index
this.itemList[t].SetData(this._array?this._array[t]:void 0)},Oe(t,[{key:"templateType",get:function(){return this._templateType},set:function(e){null!=e&&(this._templateType=e),
e===kh.NODE?this.tmpPrefab=null:e===kh.PREFAB&&(this.tmpNode=null)}},{key:"currPageIndex",get:function(){return this._currPageIndex},set:function(e){this._currPageIndex=e}},{
key:"lastPageIndex",get:function(){return this._lastPageIndex},set:function(e){this._lastPageIndex=e}},{key:"vertical",get:function(){return this.layoutType==xh.VERTICAL}},{
key:"horizontal",get:function(){return this.layoutType==xh.HORIZONTAL}},{key:"transform",get:function(){return this.node._uiProps.uiTransformComp}},{key:"accommodWidth",
get:function(){return this.viewWidth+this.paddingLeft+this.paddingRight}},{key:"accommodHeight",get:function(){return this.viewHeight+this.paddingTop+this.paddingBottom}},{
key:"header",get:function(){return 0==this.node.children.length?null:this.node.children[0]._uiProps.uiTransformComp}},{key:"footer",get:function(){
return 0==this.node.children.length?null:this.node.children[this.node.children.length-1]._uiProps.uiTransformComp}},{key:"headerIndex",get:function(){
return this.header?this.header.node.__index:-1}},{key:"footerIndex",get:function(){return this.footer?this.footer.node.__index:-1}},{key:"viewStartPoint",get:function(){var e=new z
return this.horizontalAxisDirection==Oh.LEFT_TO_RIGHT?e.x=-.5*this.viewWidth+this.paddingLeft:e.x=.5*this.viewWidth-this.paddingRight,
this.verticalAxisDirection==Ch.TOP_TO_BOTTOM?e.y=.5*this.viewHeight-this.paddingTop:e.y=-.5*this.viewHeight+this.paddingBottom,e}},{key:"viewWidth",get:function(){
return 0==this._itemTotal?0:this.layoutType==xh.VERTICAL?Math.ceil(this._itemTotal/this.rowLimit)*this.cellWidth:this._itemTotal>=this.colLimit?this.colLimit*this.cellHeight:this._itemTotal*this.cellHeight
}},{key:"viewHeight",get:function(){
return 0==this._itemTotal?0:this.layoutType==xh.VERTICAL?this._itemTotal>=this.rowLimit?this.rowLimit*this.cellHeight:this._itemTotal*this.cellHeight:Math.ceil(this._itemTotal/this.colLimit)*this.cellHeight
}},{key:"viewHeaderBoundary",get:function(){return this.vertical?.5*this.viewHeight:-.5*this.viewWidth}},{key:"viewFooterBoundary",get:function(){
return this.vertical?-.5*this.viewHeight:.5*this.viewWidth}},{key:"headerBoundary",get:function(){
return this.header?this.vertical?this.verticalAxisDirection==Ch.TOP_TO_BOTTOM?this.node.position.y+this.getItemYMax(this.header)+this.paddingTop:this.node.position.y+this.getItemYMin(this.header)-this.paddingBottom:this.horizontalAxisDirection==Oh.LEFT_TO_RIGHT?this.node.position.x+this.getItemXMin(this.header)-this.paddingLeft:this.node.position.x+this.getItemXMax(this.header)+this.paddingRight:0
}},{key:"footerBoundary",get:function(){
return this.footer?this.vertical?this.verticalAxisDirection==Ch.TOP_TO_BOTTOM?this.node.position.y+this.getItemYMin(this.footer)-this.paddingBottom:this.node.position.y+this.getItemYMax(this.footer)+this.paddingTop:this.horizontalAxisDirection==Oh.LEFT_TO_RIGHT?this.node.position.x+this.getItemXMax(this.footer)+this.paddingRight:this.node.position.x+this.getItemXMin(this.footer)-this.paddingLeft:0
}},{key:"centerHeaderBoundary",get:function(){var e,t=this.vertical?"y":"x"
return e=this.centerNode?this.viewHeaderBoundary-this.centerNode.position[t]:this.viewHeaderBoundary-this.view.node.position[t],
this.vertical&&this.verticalAxisDirection==Ch.TOP_TO_BOTTOM||this.horizontal&&this.horizontalAxisDirection==Oh.LEFT_TO_RIGHT?this.headerBoundary+e:this.footerBoundary+e}},{
key:"centerFooterBoundary",get:function(){var e,t=this.vertical?"y":"x"
return e=this.centerNode?this.viewFooterBoundary-this.centerNode.position[t]:this.viewFooterBoundary-this.view.node.position[t],
this.vertical&&this.verticalAxisDirection==Ch.TOP_TO_BOTTOM||this.horizontal&&this.horizontalAxisDirection==Oh.LEFT_TO_RIGHT?this.footerBoundary+e:this.headerBoundary+e}},{
key:"isOfLeftBoundary",get:function(){if(this.vertical)return 0
if(this.autoCenter)return 1==this.scrollDirection?this.centerHeaderBoundary:0
if(this.headerLoop)return this.header?0:this.viewHeaderBoundary+this.node.position.x
if(!this.header||this.fixedItemWidth<=this.viewWidth)return this.viewHeaderBoundary+this.node.position.x
if(this.horizontalAxisDirection==Oh.LEFT_TO_RIGHT){if(0==this.headerIndex)return this.headerBoundary}else if(this.footerIndex==this.itemTotal-1)return this.footerBoundary
return 0}},{key:"isOfTopBoundary",get:function(){if(!this.vertical)return 0
if(this.autoCenter)return 1==this.scrollDirection?this.centerHeaderBoundary:0
if(this.headerLoop)return this.header?0:this.viewHeaderBoundary+this.node.position.y
if(!this.header||this.fixedItemHeight<=this.viewHeight)return this.viewHeaderBoundary+this.node.position.y
if(this.verticalAxisDirection==Ch.TOP_TO_BOTTOM){if(0==this.headerIndex)return this.headerBoundary}else if(this.footerIndex==this.itemTotal-1)return this.footerBoundary
return 0}},{key:"isOfRightBoundary",get:function(){if(this.vertical)return 0
if(this.autoCenter)return 2==this.scrollDirection?this.centerFooterBoundary:0
if(this.footerLoop)return this.footer?0:this.viewFooterBoundary+this.node.position.x
if(!this.footer||this.fixedItemWidth<=this.viewWidth)return this.viewFooterBoundary+this.node.position.x
if(this.horizontalAxisDirection==Oh.LEFT_TO_RIGHT){if(this.footerIndex==this.itemTotal-1)return this.footerBoundary}else if(0==this.headerIndex)return this.headerBoundary
return 0}},{key:"isOfButtomBoundary",get:function(){if(!this.vertical)return 0
if(this.autoCenter)return 2==this.scrollDirection?this.centerFooterBoundary:0
if(this.footerLoop)return this.footer?0:this.viewFooterBoundary+this.node.position.y
if(!this.footer||this.fixedItemHeight<=this.viewHeight)return this.viewFooterBoundary+this.node.position.y
if(this.verticalAxisDirection==Ch.TOP_TO_BOTTOM){if(this.footerIndex==this.itemTotal-1)return this.footerBoundary}else if(0==this.headerIndex)return this.headerBoundary
return 0}},{key:"fixedItemHeight",get:function(){
return this.header?this.verticalAxisDirection==Ch.TOP_TO_BOTTOM?Math.abs(this.getItemYMax(this.header))+Math.abs(this.getItemYMin(this.footer)):Math.abs(this.getItemYMin(this.header))+Math.abs(this.getItemYMax(this.footer)):0
}},{key:"fixedItemWidth",get:function(){
return this.header?this.horizontalAxisDirection==Oh.LEFT_TO_RIGHT?Math.abs(this.getItemXMin(this.header))+Math.abs(this.getItemXMax(this.footer)):Math.abs(this.getItemXMax(this.header))+Math.abs(this.getItemXMin(this.footer)):0
}},{key:"contentSize",get:function(){return 0==this.node.children.length?new ne(0,0):new ne(this.viewWidth,this.viewHeight)}},{key:"maxPrefabTotal",get:function(){
return this._maxPrefabTotal}},{key:"itemTotal",get:function(){return this._itemTotal}},{key:"centerPosition",get:function(){if(!this._centerPosition)if(this._centerPosition=new z,
this.autoCenter){if(this.centerNode){var e,t,i=null==(e=this.centerNode.parent)||null==(t=e._uiProps.uiTransformComp)?void 0:t.convertToWorldSpaceAR(this.centerNode.position)
this._centerPosition=this.view.convertToNodeSpaceAR(i)}
}else this.vertical?this.indexVerticalAxisDirection==Fh.TOP?this._centerPosition.y=this.viewHeaderBoundary:this._centerPosition.y=this.viewFooterBoundary:this.indexHorizontalAxisDirection==zh.LEFT?this._centerPosition.x=this.viewHeaderBoundary:this._centerPosition.x=this.viewFooterBoundary
return this._centerPosition}},{key:"array",get:function(){return this._array},set:function(e){this._array=e,this.total(e?e.length:0)}}]),t}(t)).VerticalAxisDirection=Ch,
bh.HorizontalAxisDirection=Oh,Ml=ke((Nl=bh).prototype,"view",[il],{configurable:!0,enumerable:!0,writable:!0,initializer:null}),Hl=ke(Nl.prototype,"_templateType",[Lh],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return kh.NODE}}),
ke(Nl.prototype,"templateType",[nl],Object.getOwnPropertyDescriptor(Nl.prototype,"templateType"),Nl.prototype),Gl=ke(Nl.prototype,"tmpNode",[rl],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return null}}),Vl=ke(Nl.prototype,"tmpPrefab",[ol],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),
Ul=ke(Nl.prototype,"layoutType",[sl],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return xh.VERTICAL}}),Wl=ke(Nl.prototype,"indexVerticalAxisDirection",[al],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return Fh.TOP}}),jl=ke(Nl.prototype,"indexHorizontalAxisDirection",[ll],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return zh.LEFT}}),Yl=ke(Nl.prototype,"verticalAxisDirection",[hl],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return Ch.TOP_TO_BOTTOM}
}),Xl=ke(Nl.prototype,"horizontalAxisDirection",[cl],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return Oh.LEFT_TO_RIGHT}}),
$l=ke(Nl.prototype,"groupItemTotal",[ul],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 1}}),ql=ke(Nl.prototype,"multiple",[pl],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return 2}}),Jl=ke(Nl.prototype,"paddingTop",[dl],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),
Zl=ke(Nl.prototype,"paddingBottom",[fl],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),Kl=ke(Nl.prototype,"paddingLeft",[ml],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return 0}}),Ql=ke(Nl.prototype,"paddingRight",[_l],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),
eh=ke(Nl.prototype,"spacingX",[gl],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),th=ke(Nl.prototype,"spacingY",[yl],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return 0}}),ih=ke(Nl.prototype,"affectedByScale",[vl],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),
nh=ke(Nl.prototype,"isPageView",[bl],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),rh=ke(Nl.prototype,"cellWidth",[Tl],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return 10}}),oh=ke(Nl.prototype,"cellHeight",[wl],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 10}}),
sh=ke(Nl.prototype,"rowLimit",[Il],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 1}}),ah=ke(Nl.prototype,"colLimit",[Sl],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return 1}}),lh=ke(Nl.prototype,"pageTurningSpeed",[Rl],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return.3}}),
hh=ke(Nl.prototype,"indicator",[xl],{configurable:!0,enumerable:!0,writable:!0,initializer:null}),ch=ke(Nl.prototype,"scrollThreshold",[Cl],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return.5}}),uh=ke(Nl.prototype,"autoPageTurningThreshold",[Ol],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 100}}),
ph=ke(Nl.prototype,"pageEvents",[Pl],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return[]}}),dh=ke(Nl.prototype,"autoCenter",[Ll],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return!1}}),fh=ke(Nl.prototype,"centerTime",[El],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 1}}),
mh=ke(Nl.prototype,"centerNode",[Dl],{configurable:!0,enumerable:!0,writable:!0,initializer:null}),_h=ke(Nl.prototype,"centerAnchor",[Al],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return new Y(.5,.5)}}),gh=ke(Nl.prototype,"headerLoop",[Fl],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),
yh=ke(Nl.prototype,"footerLoop",[zl],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),vh=ke(Nl.prototype,"refreshItemEvents",[kl],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return[]}}),Bl=Nl))||Bl)||Bl),e._RF.pop(),e._RF.push({},"68f0dsri9JH+5W5gYcXzArH","_LuaTableComponent",void 0)
var Nh,Mh,Hh,Gh,Vh,Uh,Wh,jh,Yh,Xh,$h,qh,Jh,Zh=n.ccclass,Kh=(n.executeInEditMode,n.menu)
n.property,n.type,Zh("app/LuaTableComponent")(Bh=Kh("app/LuaTableComponent")(Bh=function(e){function t(){return e.apply(this,arguments)||this}return Le(t,e),t}(t))||Bh),
e._RF.pop(),e._RF.push({},"83198uCVbdGjK3mxZZJxz+h","_MButton",void 0)
var Qh,ec,tc,ic,nc,rc,oc,sc,ac,lc,hc,cc,uc,pc=n.ccclass,dc=n.executeInEditMode,fc=n.menu,mc=n.property,_c=n.type
Nh=pc("app/MButton"),Mh=fc("app/MButton"),Hh=mc({type:d}),Gh=mc({type:j}),Vh=_c(d),Uh=_c(j),Wh=mc({type:W}),jh=_c(W),Nh(Yh=dc(Yh=Mh(($h=ke((Xh=function(e){function t(){
for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"_label",$h,De(t)),ze(t,"_richText",qh,De(t)),ze(t,"_bgSprite",Jh,De(t)),t}Le(t,e)
var i=t.prototype
return i.SetText=function(e){if(this._label)this._label.string=e
else{var t=this.getComponentInChildren(d)
t&&(t.string=e)}if(this._richText)this._richText.string=e
else{var i=this.getComponentInChildren(j)
i&&(i.string=e)}},i.SetActive=function(e){this.node.active=e},i.AddEventHandler=function(e){this.node.on(c.TOUCH_END,e)},i.RemoveEventHandler=function(e){
this.node.off(c.TOUCH_END,e)},Oe(t,[{key:"label",get:function(){return this._label},set:function(e){this._label=e}},{key:"richText",get:function(){return this._richText},
set:function(e){this._richText=e}},{key:"bgSprite",get:function(){return this._bgSprite},set:function(e){this._bgSprite=e}}]),t}(ae)).prototype,"_label",[Hh],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return null}}),qh=ke(Xh.prototype,"_richText",[Gh],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}
}),ke(Xh.prototype,"label",[Vh],Object.getOwnPropertyDescriptor(Xh.prototype,"label"),Xh.prototype),
ke(Xh.prototype,"richText",[Uh],Object.getOwnPropertyDescriptor(Xh.prototype,"richText"),Xh.prototype),Jh=ke(Xh.prototype,"_bgSprite",[Wh],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return null}}),ke(Xh.prototype,"bgSprite",[jh],Object.getOwnPropertyDescriptor(Xh.prototype,"bgSprite"),Xh.prototype),Yh=Xh))||Yh)||Yh),
e._RF.pop(),e._RF.push({},"cac70shw35DP4u+9dX/HwH9","_MSpriteFrame",void 0),e._RF.pop(),e._RF.push({},"c3d30nJK4lGnZPyLEYgn98W","_MirrorImage",void 0)
var gc,yc,vc,bc,Tc,wc,Ic,Sc,Rc,xc,Cc,Oc,Pc,Lc,Ec,Dc,Ac,Fc,zc,kc,Bc,Nc,Mc,Hc,Gc,Vc,Uc,Wc,jc,Yc,Xc,$c,qc,Jc,Zc,Kc,Qc,eu,tu,iu=n.ccclass,nu=n.executeInEditMode,ru=n.menu,ou=n.property,su=n.type
!function(e){e[e.H_LEFT=0]="H_LEFT",e[e.H_RIGHT=1]="H_RIGHT",e[e.V_TOP=2]="V_TOP",e[e.V_BOTTOM=3]="V_BOTTOM"}(gc||(gc={})),o(gc),Qh=iu("app/MirrorImage"),ec=ru("app/MirrorImage"),
tc=su(x),ic=su(x),nc=su([x]),rc=su(gc),oc=su(ce),Qh(sc=nu(sc=ec((lc=ke((ac=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"_spriteFrame",lc,De(t)),ze(t,"spfs",hc,De(t)),ze(t,"_flipType",cc,De(t)),ze(t,"_space",uc,De(t)),t}return Le(t,e),
t.prototype._refresh=function(){for(var e=null,t=null,n=0;n<this.node.children.length;n++){var r=this.node.children[n]
"RENDERER_CHILD"!=r.name&&"Renderer"!=r.name||(e?t||(t=r):e=r)}if(this._spriteFrame){e||((e=l.createUINode("RENDERER_CHILD")).addComponent(W),e.hideFlags|=i.Flags.HideInHierarchy,
this.node.addChild(e)),t||((t=l.createUINode("RENDERER_CHILD")).addComponent(W),t.hideFlags|=i.Flags.HideInHierarchy,this.node.addChild(t)),
e.getComponent(W).spriteFrame=this._spriteFrame,t.getComponent(W).spriteFrame=this._spriteFrame
var o=this._space,s=this._flipType,a=e.transform,h=a.width,c=a.height
if(s==gc.H_LEFT||s==gc.H_RIGHT){var u=o+h/2
e.setXY(-u,0),t.setXY(u,0)
var p=s==gc.H_LEFT?1:-1
e.setScale(p,1),t.setScale(-p,1),this.node.transform.setContentSize(2*(o+h),c)}else{var d=o+c/2
e.setXY(0,d),t.setXY(0,-d)
var f=s==gc.V_TOP?1:-1
e.setScale(1,f),t.setScale(1,-f),this.node.transform.setContentSize(h,2*(o+c))}}else{if(e){var m=e.getComponent(W)
m&&(m.spriteFrame=null)}if(t){var _=t.getComponent(W)
_&&(_.spriteFrame=null)}}},Oe(t,[{key:"spriteFrame",get:function(){return this._spriteFrame},set:function(e){e!=this._spriteFrame&&(this._spriteFrame=e,this._refresh())}},{
key:"flipType",get:function(){return this._flipType},set:function(e){e!=this._flipType&&(this._flipType=e,this._refresh())}},{key:"space",get:function(){return this._space},
set:function(e){e!=this._space&&(this._space=e,this._refresh())}}]),t}(t)).prototype,"_spriteFrame",[tc],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){
return null}}),ke(ac.prototype,"spriteFrame",[ic],Object.getOwnPropertyDescriptor(ac.prototype,"spriteFrame"),ac.prototype),hc=ke(ac.prototype,"spfs",[nc],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return[]}}),cc=ke(ac.prototype,"_flipType",[ou],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return gc.H_LEFT}
}),ke(ac.prototype,"flipType",[rc],Object.getOwnPropertyDescriptor(ac.prototype,"flipType"),ac.prototype),uc=ke(ac.prototype,"_space",[ou],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return 0}}),ke(ac.prototype,"space",[oc],Object.getOwnPropertyDescriptor(ac.prototype,"space"),ac.prototype),sc=ac))||sc)||sc),e._RF.pop(),
e._RF.push({},"df9038KCmRJvp/0w0MmrdmO","luaEnums",void 0),function(e){e[e.eHorizontal=0]="eHorizontal",e[e.eVertical=1]="eVertical",e[e.eUnrestricted=2]="eUnrestricted",
e[e.eCustom=3]="eCustom"}(yc||(yc={})),o(yc),function(e){e[e.eNone=0]="eNone",e[e.eMomentum=1]="eMomentum",e[e.eMomentumAndSpring=2]="eMomentumAndSpring"}(vc||(vc={})),o(vc),
function(e){e[e.eAlways=0]="eAlways",e[e.eOnlyIfNeeded=1]="eOnlyIfNeeded",e[e.eWhenDragging=2]="eWhenDragging"}(bc||(bc={})),o(bc),function(e){e[e.eTopLeft=0]="eTopLeft",
e[e.eTop=1]="eTop",e[e.eTopRight=2]="eTopRight",e[e.eLeft=3]="eLeft",e[e.eCenter=4]="eCenter",e[e.eRight=5]="eRight",e[e.eBottomLeft=6]="eBottomLeft",e[e.eBottom=7]="eBottom",
e[e.eBottomRight=8]="eBottomRight"}(Tc||(Tc={})),o(Tc),function(e){e[e.eHorizontal=0]="eHorizontal",e[e.eVertical=1]="eVertical",e[e.eCellSnap=2]="eCellSnap"}(wc||(wc={})),o(wc),
function(e){e[e.eNone=0]="eNone",e[e.eAlphabetic=1]="eAlphabetic",e[e.eHorizontal=2]="eHorizontal",e[e.eVertical=3]="eVertical",e[e.eCustom=4]="eCustom"}(Ic||(Ic={})),o(Ic),
function(e){e[e.eFree=0]="eFree",e[e.eBasedOnWidth=1]="eBasedOnWidth",e[e.eBasedOnHeight=2]="eBasedOnHeight"}(Sc||(Sc={})),o(Sc),function(e){e[e.eOnce=0]="eOnce",
e[e.eLoop=1]="eLoop",e[e.ePingPong=2]="ePingPong"}(Rc||(Rc={})),o(Rc),function(e){e[e.None=0]="None",e[e.In=1]="In",e[e.Out=2]="Out",e[e.Both=3]="Both"}(xc||(xc={})),o(xc),
function(e){e[e.eLeftToRight=0]="eLeftToRight",e[e.eRightToLeft=1]="eRightToLeft",e[e.eBottomToTop=2]="eBottomToTop",e[e.eTopToBottom=3]="eTopToBottom"}(Cc||(Cc={})),o(Cc),
function(e){e[e.eStandard=0]="eStandard",e[e.eAutoCorrect=1]="eAutoCorrect",e[e.ePassword=2]="ePassword"}(Oc||(Oc={})),o(Oc),function(e){e[e.eDefault=0]="eDefault",
e[e.eSubmit=1]="eSubmit",e[e.eNewLine=2]="eNewLine"}(Pc||(Pc={})),o(Pc),function(e){e[e.eDefault=0]="eDefault",e[e.eASCIICapable=1]="eASCIICapable",
e[e.eNumbersAndPunctuation=2]="eNumbersAndPunctuation",e[e.eURL=3]="eURL",e[e.eNumberPad=4]="eNumberPad",e[e.ePhonePad=5]="ePhonePad",e[e.eNamePhonePad=6]="eNamePhonePad",
e[e.eEmailAddress=7]="eEmailAddress"}(Lc||(Lc={})),o(Lc),function(e){e[e.eOrientaton=0]="eOrientaton",e[e.eVertical=1]="eVertical",e[e.eDefault=-1]="eDefault"}(Ec||(Ec={})),o(Ec),
function(e){e[e.eDown=0]="eDown",e[e.eUp=1]="eUp"}(Dc||(Dc={})),o(Dc),function(e){e[e.Smooth=0]="Smooth",e[e.Instant=1]="Instant"}(Ac||(Ac={})),o(Ac),function(e){
e[e.eLinear=0]="eLinear",e[e.eEaseIn=1]="eEaseIn",e[e.eEaseOut=2]="eEaseOut",e[e.eEaseInOut=3]="eEaseInOut",e[e.eBounceIn=4]="eBounceIn",e[e.eBounceOut=5]="eBounceOut"
}(Fc||(Fc={})),o(Fc),function(e){e[e.eBottomLeft=0]="eBottomLeft",e[e.eLeft=1]="eLeft",e[e.eTopLeft=2]="eTopLeft",e[e.eTop=3]="eTop",e[e.eTopRight=4]="eTopRight",
e[e.eRight=5]="eRight",e[e.eBottomRight=6]="eBottomRight",e[e.eBottom=7]="eBottom",e[e.eCenter=8]="eCenter"}(zc||(zc={})),o(zc),function(e){e[e.eOnClick=0]="eOnClick",
e[e.eOnMouseOver=1]="eOnMouseOver",e[e.eOnMouseOut=2]="eOnMouseOut",e[e.eOnPress=3]="eOnPress",e[e.eOnRelease=4]="eOnRelease",e[e.eCustom=5]="eCustom",e[e.eOnEnable=6]="eOnEnable",
e[e.eOnDisable=7]="eOnDisable"}(kc||(kc={})),o(kc),function(e){e[e.eHorizontal=0]="eHorizontal",e[e.eVertical=1]="eVertical",e[e.eUpgraded=2]="eUpgraded"}(Bc||(Bc={})),o(Bc),
function(e){e[e.eOnClick=0]="eOnClick",e[e.eOnHover=1]="eOnHover",e[e.eOnPress=2]="eOnPress",e[e.eOnHoverTrue=3]="eOnHoverTrue",e[e.eOnHoverFalse=4]="eOnHoverFalse",
e[e.eOnPressTrue=5]="eOnPressTrue",e[e.eOnPressFalse=6]="eOnPressFalse",e[e.eOnActivate=7]="eOnActivate",e[e.eOnActivateTrue=8]="eOnActivateTrue",
e[e.eOnActivateFalse=9]="eOnActivateFalse",e[e.eOnDoubleClick=10]="eOnDoubleClick",e[e.eOnSelect=11]="eOnSelect",e[e.eOnSelectTrue=12]="eOnSelectTrue",
e[e.eOnSelectFalse=13]="eOnSelectFalse",e[e.eNonAuto=14]="eNonAuto"}(Nc||(Nc={})),o(Nc),function(e){e[e.eReverse=-1]="eReverse",e[e.eToggle=0]="eToggle",e[e.eForward=1]="eForward"
}(Mc||(Mc={})),o(Mc),function(e){e[e.eDoNothing=0]="eDoNothing",e[e.eEnableThenPlay=1]="eEnableThenPlay",e[e.eIgnoreDisabledState=2]="eIgnoreDisabledState"}(Hc||(Hc={})),o(Hc),
function(e){e[e.ContinueFromCurrent=0]="ContinueFromCurrent",e[e.RestartTween=1]="RestartTween",e[e.RestartIfNotPlaying=2]="RestartIfNotPlaying"}(Gc||(Gc={})),o(Gc),function(e){
e[e.eDisableAfterReverse=-1]="eDisableAfterReverse",e[e.eDoNotDisable=0]="eDoNotDisable",e[e.eDisableAfterForward=1]="eDisableAfterForward"}(Vc||(Vc={})),o(Vc),function(e){
e[e.eNone=0]="eNone",e[e.eToUppercase=1]="eToUppercase",e[e.eToLowercase=2]="eToLowercase",e[e.eCustom=255]="eCustom"}(Uc||(Uc={})),o(Uc),function(e){
e[e.eShrinkContent=0]="eShrinkContent",e[e.eClampContent=1]="eClampContent",e[e.eResizeFreely=2]="eResizeFreely",e[e.eResizeHeight=3]="eResizeHeight"}(Wc||(Wc={})),o(Wc),
function(e){e[e.eA_Automatic=0]="eA_Automatic",e[e.eA_Left=1]="eA_Left",e[e.eA_Center=2]="eA_Center",e[e.eA_Right=3]="eA_Right",e[e.eA_Justified=4]="eA_Justified"}(jc||(jc={})),
o(jc),function(e){e[e.eNever=0]="eNever",e[e.eOnDesktop=1]="eOnDesktop",e[e.eAlways=2]="eAlways"}(Yc||(Yc={})),o(Yc),function(e){e[e.eNone=0]="eNone",e[e.eShadow=1]="eShadow",
e[e.eOutline=2]="eOutline",e[e.eOutline8=3]="eOutline8",e[e.eOutlight=4]="eOutlight"}(Xc||(Xc={})),o(Xc),function(e){e[e.eSimple=0]="eSimple",e[e.eSliced=1]="eSliced",
e[e.eTiled=2]="eTiled",e[e.eFilled=3]="eFilled",e[e.eAdvanced=4]="eAdvanced",e[e.eMirror=5]="eMirror",e[e.eMirrorSliced=6]="eMirrorSliced"}($c||($c={})),o($c),function(e){
e[e.eNothing=0]="eNothing",e[e.eHorizontally=1]="eHorizontally",e[e.eVertically=2]="eVertically",e[e.eBoth=3]="eBoth"}(qc||(qc={})),o(qc),function(e){
e[e.eHorizontal=0]="eHorizontal",e[e.eVertical=1]="eVertical",e[e.eRadial90=2]="eRadial90",e[e.eRadial180=3]="eRadial180",e[e.eRadial360=4]="eRadial360"}(Jc||(Jc={})),o(Jc),
function(e){e[e.eNone=0]="eNone",e[e.eTextureMask=1]="eTextureMask",e[e.eSoftClip=3]="eSoftClip",e[e.eConstrainButDontClip=4]="eConstrainButDontClip"}(Zc||(Zc={})),o(Zc),
e._RF.pop(),e._RF.push({},"95725oBsj5DxqCTINZlXtps","_MyUIGridItem",void 0)
var au,lu,hu,cu,uu,pu,du,fu,mu,_u,gu,yu,vu,bu,Tu,wu,Iu,Su=n.ccclass,Ru=(n.executeInEditMode,n.menu),xu=n.property,Cu=(n.type,
Su("app/MyUIGridItem")(Kc=Ru("app/MyUIGridItem")((eu=ke((Qc=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"findId",eu,De(t)),ze(t,"sortIndex",tu,De(t)),t.index=0,t}return Le(t,e),t}(t)).prototype,"findId",[xu],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return 0}}),tu=ke(Qc.prototype,"sortIndex",[xu],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),
Kc=Qc))||Kc)||Kc)
e._RF.pop(),e._RF.push({},"6f53b8l5gxE5Z9OUjotawi9","_UIGrid",void 0)
var Ou,Pu,Lu,Eu,Du,Au,Fu=n.ccclass,zu=(n.executeInEditMode,n.menu),ku=n.property,Bu=n.type,Nu=(au=Fu("app/UIGrid"),lu=zu("app/UIGrid"),hu=Bu(wc),cu=ku({
displayName:"Row or Col Limit"}),uu=Bu(Ic),pu=Bu(Tc),au(du=lu((mu=ke((fu=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"arrangement",mu,De(t)),ze(t,"cellWidth",_u,De(t)),ze(t,"cellHeight",gu,De(t)),ze(t,"columnLimit",yu,De(t)),
ze(t,"sorting",vu,De(t)),ze(t,"pivot",bu,De(t)),ze(t,"smoothTween",Tu,De(t)),ze(t,"hideInactive",wu,De(t)),ze(t,"constrainToPanel",Iu,De(t)),t}return Le(t,e),t
}(t)).prototype,"arrangement",[hu],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return wc.eHorizontal}}),_u=ke(fu.prototype,"cellWidth",[ku],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return 200}}),gu=ke(fu.prototype,"cellHeight",[ku],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 200}}),
yu=ke(fu.prototype,"columnLimit",[cu],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),vu=ke(fu.prototype,"sorting",[uu],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return Ic.eNone}}),bu=ke(fu.prototype,"pivot",[pu],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){
return Tc.eTopLeft}}),Tu=ke(fu.prototype,"smoothTween",[ku],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),wu=ke(fu.prototype,"hideInactive",[ku],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),Iu=ke(fu.prototype,"constrainToPanel",[ku],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return!1}}),du=fu))||du)||du)
e._RF.pop(),e._RF.push({},"a89f0X/lMJBAK9/E6fnQPxt","_MyUIGrid",void 0)
var Mu,Hu,Gu,Vu,Uu,Wu,ju,Yu,Xu,$u,qu,Ju,Zu,Ku,Qu,ep=n.ccclass,tp=(n.executeInEditMode,n.menu),ip=n.property,np=(n.type,Ou=ep("app/MyUIGrid"),Pu=tp("app/MyUIGrid"),Lu=ip({type:m}),
Ou(Eu=Pu((Au=ke((Du=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return(t=e.call.apply(e,[this].concat(n))||this)._array=null,t._itemTotal=0,t.itemList=void 0,t._itemCls=null,t._itemClick=null,t.m_onReposition=null,t.renderEvent=null,
t.setPosTotal=0,t.count=0,ze(t,"tmpPrefab",Au,De(t)),t.timeId=void 0,t}Le(t,e)
var i=t.prototype
return i.OnReposition_set=function(e){this.m_onReposition=e},i.data_set=function(e,t){void 0===t&&(t=!1),this._array=e,t?(this.unschedule(this._delayDataSet),
this.scheduleOnce(this._delayDataSet,.15)):this.dataSet(this._array)},i._delayDataSet=function(){this.dataSet(this._array)},i.onDisable=function(){
this.unschedule(this._delayDataSet)},i.dataSet=function(e){this.total(e?e.length:0),this.m_onReposition&&this.m_onReposition()},i.data_get=function(){return this._array},
i.SetInitInfo=function(e,t,i,n,r){t&&(this.renderEvent=t),this._itemCls=i,this._itemClick=n,this.tmpPrefab&&this.tmpPrefab.data||(this.tmpPrefab=hn.getPrefab(e))},
i.total=function(e){this.count=e,this.createItems(e)
var t=e-this._itemTotal
return this._itemTotal=e,this.refreshItems(t),this.updateItems(),this.updatePosition(),this},i.createItems=function(e){var t=this
if(this.node.children.length>e)this.removeItems(e)
else{var i=e-this.node.children.length
i>0&&!this.itemList&&(this.itemList=new Ii.CList)
var n=this.node.children.length
this.setPosTotal=i
for(var r=0;r<i;r++)if(this.tmpPrefab){var o=p(this.tmpPrefab)
o._uiProps.uiTransformComp,o.__index=this.node.children.length,this.node.addChild(o)
var s=o.getComponent(Cu)
s||(s=o.addComponent(Cu)),this._itemCls?function(){var e=o.getCNode(t._itemCls)
t.itemList[o.__index]=e,t._itemClick&&(e.onClick=function(i){return t._itemClick(e)})
}():this.renderEvent&&(this.itemList[o.__index]=this.renderEvent([o,n,this._array?this._array[o.__index]:void 0]),nt(this.itemList[o.__index])),this.itemList[o.__index].index=n,
s.index=n,this.notifyRefreshItem(o),this.hideInactive&&!o.active||(n+=1)}else console.log("err:_MyUIGrid找不到tmpPrefab")
this.pivot==Tc.eCenter&&this.AjustItemsPosition()}},i.updatePosition=function(){
for(var e=this.node.children,t=e.length,i=0,n=0;n<t;n++)e[n]&&(e[n].active||!this.hideInactive)&&e[n]._uiProps.uiTransformComp&&e[n].getComponent(Cu)&&(this.setItemPos(e[n]._uiProps.uiTransformComp,i),
i++)
this.initGridMid()},i.removeItems=function(e){for(var t=this.node.children.length-e,i=0;i<t;i++){var n=this.node.children[this.node.children.length-1]
n.off(l.EventType.SIZE_CHANGED),n.off(l.EventType.TRANSFORM_CHANGED),this.node.removeChild(n)}this.pivot==Tc.eCenter&&this.AjustItemsPosition()},i.refreshItems=function(e,t){},
i.updateItems=function(){var e=0
if(!this.node.children)return this
for(var t=0;t<this.node.children.length;t++){var i=this.node.children[t]
i.__index=e,e++,this.notifyRefreshItem(i)}return this},i.initGridMid=function(){
if("content"==this.node.parent.name&&this.node.children.length>0&&this.node.parent.parent&&this.pivot==Tc.eCenter&&this.arrangement==wc.eHorizontal){
var e=this.node.parent.parent.transform.width,t=this.cellWidth-this.node.children[0].transform.width
if(this.node.children.length*this.cellWidth>=e)return
;.5==this.node.transform.anchorX?this.node.x=e/2-(this.node.children[0].x+this.node.children.length*this.cellWidth/2)+t/2:0==this.node.transform.anchorX&&(this.node.x=e/2-this.node.children.length*this.cellWidth/2+t/2)
}},i.notifyRefreshItem=function(e){var t=e.__index
this.itemList[t].SetData(this._array?this._array[t]:void 0)},i.setItemPos=function(e,t){var i=new z,n=this.columnLimit
if(this.pivot!=Tc.eCenter)this.arrangement!=wc.eHorizontal?(n>0?(this.pivot==Tc.eTopRight?i.x=-Math.floor(t/n)*this.cellWidth:i.x=Math.floor(t/n)*this.cellWidth,
i.y=-t%n*this.cellHeight):(i.x=0,i.y=-t*this.cellHeight),this.node.transform.height=(t+1)*this.cellHeight):n>0?(i.x=t%n*this.cellWidth,
i.y=-Math.floor(t/n)*this.cellHeight):(i.x=t*this.cellWidth,i.y=0)
else{new z(0,0,0)
var r=Math.min(n-1,this.setPosTotal-1)/2
0!=n&&t>=n&&(r+=Math.floor(t/n)*n)
var o=t>r?Math.ceil(t-r):Math.floor(t-r)
if(this.arrangement!=wc.eHorizontal)n>0?(i.x=Math.floor(t/n)*this.cellWidth,i.y=-o%(Math.floor(n/2)+1)*this.cellHeight):(i.x=0,i.y=-o*this.cellHeight),
0!=i.y&&(i.y=i.y>0?i.y-.5*this.cellHeight:i.y+.5*this.cellHeight)
else{n>0?(i.x=o%(Math.floor(n/2)+1)*this.cellWidth,i.y=-Math.floor(t/n)*this.cellHeight,n%2==0&&(i.x=i.x>0?i.x-.5*this.cellWidth:i.x+.5*this.cellWidth)):(i.x=o*this.cellWidth,
i.y=0)
var s=this.setPosTotal*this.cellWidth
0!=i.x&&(i.x=n>0?i.x>0?i.x-.5*this.node.transform.width:i.x+.5*this.node.transform.width:i.x>0?i.x-.5*s-.5*this.cellWidth:i.x-.5*s+.5*this.cellWidth)}}e.node.position=i},
i.CallReposition=function(){this.updatePosition()},i.Reposition=function(){this.updatePosition()},i.GetDataByIndex=function(e){
if(this.itemList&&this.itemList[e]&&this.itemList[e].data)return this.itemList[e].data},i.cellWidthSet=function(e){this.cellWidth=e},i.cellHeightSet=function(e){this.cellHeight=e},
i.AjustContentSize=function(e){},i.AjustItemsPosition=function(){if(this.setPosTotal=this.node.children.length,this.itemList){
for(var e=0;e<this.node.children.length;e++)this.itemList[e]&&this.setItemPos(this.itemList[e].node.transform,e)
this.initGridMid()}},i.AjustItemPosByItemHeight=function(e){if(void 0===e&&(e=30),this.arrangement!=wc.eHorizontal){
for(var t=new Ii.CList,i=0,n=0;n<this.itemList.length&&n<this._array.length;n++){var r,o=new z
o.x=0,r=i+0,o.y=r,this.itemList[n].node.position=o,t.Add(o),i-=this.itemList[n].node.transform.height}this.node.parent.transform.height=Math.abs(i)+e
}else console.error("AjustItemPosByItemHeight only support vertical")},i.heightSet=function(e){this.node.parent.transform.height=e},i.CellWidth=function(){return this.cellWidth},
i.CellHeight=function(){return this.cellHeight},i.Clear=function(){if(this.itemList){for(var e=0;e<this.itemList.length;e++)this.itemList[e].Clear&&this.itemList[e].Clear()
this.tmpPrefab=null}},i.Destroy=function(){},t}(Nu)).prototype,"tmpPrefab",[Lu],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),Eu=Du))||Eu)||Eu)
e._RF.pop(),e._RF.push({},"98520nejIlAdoIoVCz7uSzD","_MyMenuList",void 0)
var rp,op,sp,ap,lp,hp,cp,up,pp,dp,fp,mp=n.ccclass,_p=(n.executeInEditMode,n.menu),gp=n.property,yp=n.type
Mu=mp("app/MyMenuList"),Hu=_p("app/MyMenuList"),Gu=yp(np),Vu=yp([l]),Uu=yp(l),Wu=yp(l),Mu(ju=Hu((Xu=ke((Yu=function(e){function t(){
for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"myUIGrid",Xu,De(t)),ze(t,"triggerObj",$u,De(t)),ze(t,"targetMenu",qu,De(t)),ze(t,"isAutoCreatePos",Ju,De(t)),
ze(t,"isAutoAdjustBG",Zu,De(t)),ze(t,"bg",Ku,De(t)),ze(t,"curState",Qu,De(t)),t}return Le(t,e),t}(t)).prototype,"myUIGrid",[Gu],{configurable:!0,enumerable:!0,writable:!0,
initializer:null}),$u=ke(Yu.prototype,"triggerObj",[Vu],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return[]}}),qu=ke(Yu.prototype,"targetMenu",[Uu],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),Ju=ke(Yu.prototype,"isAutoCreatePos",[gp],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return!0}}),Zu=ke(Yu.prototype,"isAutoAdjustBG",[gp],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!0}}),
Ku=ke(Yu.prototype,"bg",[Wu],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),Qu=ke(Yu.prototype,"curState",[gp],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return!1}}),ju=Yu))||ju),e._RF.pop(),e._RF.push({},"b1133K+QptNrakNtUAW8yRj","_MyReusableGrid",void 0)
var vp,bp,Tp,wp,Ip,Sp,Rp,xp,Cp,Op,Pp,Lp=n.ccclass,Ep=(n.executeInEditMode,n.menu),Dp=n.property,Ap=n.type
rp=Lp("app/MyReusableGrid"),op=Ep("app/MyReusableGrid"),sp=Ap(wc),ap=Ap(Tc),rp(lp=op((cp=ke((hp=function(e){function t(){
for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"arrangement",cp,De(t)),ze(t,"pivot",up,De(t)),ze(t,"maxPerLine",pp,De(t)),ze(t,"cellWidth",dp,De(t)),
ze(t,"cellHeight",fp,De(t)),t}return Le(t,e),t}(t)).prototype,"arrangement",[sp],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return wc.eHorizontal}}),
up=ke(hp.prototype,"pivot",[ap],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return Tc.eTopLeft}}),pp=ke(hp.prototype,"maxPerLine",[Dp],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return 0}}),dp=ke(hp.prototype,"cellWidth",[Dp],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 200}}),
fp=ke(hp.prototype,"cellHeight",[Dp],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 200}}),lp=hp))||lp),e._RF.pop(),
e._RF.push({},"0f9c3G8EQ9CxqntbNrQsLjE","_MyTreeItem",void 0)
var Fp,zp,kp,Bp,Np,Mp,Hp,Gp,Vp,Up,Wp,jp,Yp,Xp,$p,qp,Jp,Zp,Kp,Qp=n.ccclass,ed=(n.executeInEditMode,n.menu),td=n.property,id=(n.type,vp=Qp("app/MyTreeItem"),bp=ed("app/MyTreeItem"),
Tp=td({type:l,tooltip:"背景"}),wp=td({type:l,tooltip:"选中"}),Ip=td({type:d,tooltip:"标题"}),vp(Sp=bp((xp=ke((Rp=function(e){function t(){
for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"bg",xp,De(t)),ze(t,"selectedImg",Cp,De(t)),ze(t,"text",Op,De(t)),ze(t,"_selected",Pp,De(t)),t.treeData=null,t.myTree=void 0,t}
Le(t,e)
var i=t.prototype
return i.start=function(){this.node.on(c.TOUCH_END,this.onClick,this)},i.SetData=function(e,t){this.treeData=e,this.text.string=e.name,this.myTree=t,this.SetIsSelect(!1)},
i.GetData=function(){return this.treeData},i.onClick=function(){this.myTree.ChangeTreeSelect(this.treeData)},i.SetIsSelect=function(e){this.selectedImg.active=e},Oe(t,[{
key:"selected",get:function(){return this._selected},set:function(e){this._selected=e}}]),t}(t)).prototype,"bg",[Tp],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return null}}),Cp=ke(Rp.prototype,"selectedImg",[wp],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),
Op=ke(Rp.prototype,"text",[Ip],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),Pp=ke(Rp.prototype,"_selected",[td],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return!1}}),ke(Rp.prototype,"selected",[td],Object.getOwnPropertyDescriptor(Rp.prototype,"selected"),Rp.prototype),Sp=Rp))||Sp)||Sp)
e._RF.pop(),e._RF.push({},"c5a641/ERRC2KLHaMUTD1DN","_MyTreeTitleItem",void 0)
var nd,rd,od,sd,ad,ld,hd,cd,ud,pd,dd,fd,md,_d,gd=n.ccclass,yd=(n.executeInEditMode,n.menu),vd=n.property,bd=(n.type,Fp=gd("app/MyTreeTitleItem"),zp=yd("app/MyTreeTitleItem"),
kp=vd({type:l,tooltip:"图标展开"}),Bp=vd({type:l,tooltip:"图标收缩"}),Np=vd({type:l,tooltip:"背景"}),Mp=vd({type:d,tooltip:"标题"}),Hp=vd({type:l}),Gp=vd({type:rs,tooltip:"图标"}),
Fp(Vp=zp((Wp=ke((Up=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"iconopen",Wp,De(t)),ze(t,"iconclose",jp,De(t)),ze(t,"bg",Yp,De(t)),ze(t,"text",Xp,De(t)),ze(t,"openBg",$p,De(t)),
ze(t,"icon",qp,De(t)),ze(t,"changeTextColor",Jp,De(t)),ze(t,"openColor",Zp,De(t)),ze(t,"closeColor",Kp,De(t)),t.m_treeData=null,t.myTree=void 0,t.isHasChild=void 0,t}Le(t,e)
var i=t.prototype
return i.start=function(){this.node.on(c.TOUCH_END,this.onClick,this)},i.GetData=function(){return this.m_treeData},i.onClick=function(){
this.myTree.ChangeTreeSelect(this.m_treeData)},i.SetData=function(e,t){this.m_treeData=e,this.text.string=e.name,this.myTree=t,this.SetHasChild(!1),this.SetIsSelect(!1),
this.SetIsOpen(!1),this.icon&&(e.iconSpName?this.icon.skin="atlas/shichang/"+e.iconSpName:this.icon.skin="atlas/shichang/ryshichang_sp_0002")},i.SetHasChild=function(e){
this.isHasChild=e,this.iconopen.active=e,this.iconclose.active=!1},i.SetIsOpen=function(e){this.iconopen.active=this.isHasChild&&!e,this.iconclose.active=this.isHasChild&&e},
i.SetIsSelect=function(e){this.openBg.active=e},t}(t)).prototype,"iconopen",[kp],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),
jp=ke(Up.prototype,"iconclose",[Bp],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),Yp=ke(Up.prototype,"bg",[Np],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return null}}),Xp=ke(Up.prototype,"text",[Mp],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),
$p=ke(Up.prototype,"openBg",[Hp],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),qp=ke(Up.prototype,"icon",[Gp],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return null}}),Jp=ke(Up.prototype,"changeTextColor",[vd],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),
Zp=ke(Up.prototype,"openColor",[vd],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return H.WHITE.clone()}}),Kp=ke(Up.prototype,"closeColor",[vd],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return H.WHITE.clone()}}),Vp=Up))||Vp)||Vp)
e._RF.pop(),e._RF.push({},"abe4eV8xuNFII4Rx9RPkdK3","_MyTree",void 0)
var Td,wd,Id,Sd,Rd,xd,Cd,Od,Pd,Ld,Ed,Dd,Ad,Fd,zd,kd=n.ccclass,Bd=(n.executeInEditMode,n.menu),Nd=n.property
n.type,nd=kd("app/MyTree"),rd=Bd("app/MyTree"),od=Nd({tooltip:"树节点的高度(标题)"}),sd=Nd({tooltip:"树节点的高度"}),ad=Nd({type:s}),ld=Nd({type:m}),hd=Nd({type:m}),
nd(cd=rd((pd=ke((ud=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"itemTitleHeight",pd,De(t)),ze(t,"itemHeight",dd,De(t)),ze(t,"scrollContent",fd,De(t)),ze(t,"titleItemPrefab",md,De(t)),
ze(t,"subItemPrefab",_d,De(t)),t.curTreeData=null,t.dataList=void 0,t.onSelectCallback=void 0,t.titleItems=null,t.id2TitleItem=null,t.id2SubItem=null,t.parentID2SubItems=null,
t.isLastShowSub=void 0,t.curShowTitleItem=void 0,t.curShowSubItem=void 0,t.titleItemPool=void 0,t.subItemPool=void 0,t}Le(t,e)
var i=t.prototype
return i.GetTitleItem=function(e){return this.id2TitleItem[e]},i.GetSubItem=function(e){return this.id2SubItem[e]},i.SetSelectCallback=function(e){this.onSelectCallback=e},
i.SetData=function(e){this.dataList=e,this.Recycle(),this.titleItems=[],this.id2TitleItem={},this.id2SubItem={},this.parentID2SubItems={},this.curTreeData=null
for(var t,i=null,n={},r=Fe(this.dataList);!(t=r()).done;){var o=t.value,s=o.parentID
if(o.isParent()){null==i&&(i=o)
var a=this.CreateTitleItem()
a.SetData(o,this),this.titleItems.push(a),this.id2TitleItem[a.GetData().id]=a}else{this.parentID2SubItems[s]||(this.parentID2SubItems[s]=[])
var l=this.CreateSubItem()
l.SetData(o,this),this.parentID2SubItems[s].push(l),n[s]=!0,this.id2SubItem[l.GetData().id]=l}}
for(var h=0;h<this.titleItems.length;h++)this.titleItems[h].SetHasChild(n[this.titleItems[h].GetData().id])
this.ChangeTreeSelect(i)},i.SelectById=function(e){for(var t,i=Fe(this.dataList);!(t=i()).done;){var n=t.value
if(n.id==e){this.ChangeTreeSelect(n)
break}}},i.ChangeTreeSelect=function(e){if(e){for(var t in this.curShowTitleItem&&(this.curShowTitleItem.SetIsSelect(!1),this.curShowTitleItem.SetIsOpen(!1)),
this.curShowSubItem&&this.curShowSubItem.SetIsSelect(!1),this.parentID2SubItems)for(var i,n=Fe(this.parentID2SubItems[t]);!(i=n()).done;)i.value.SetActive(!1)
var r=!1,o=e.id
this.curShowSubItem=null,e.isParent()?(r=!(this.curShowTitleItem&&this.curShowTitleItem.GetData().id==o&&this.isLastShowSub),
this.parentID2SubItems[e.id]&&(this.curShowSubItem=this.id2SubItem[this.parentID2SubItems[e.id][0].GetData().id])):(o=e.parentID,r=this.isLastShowSub,
this.curShowSubItem=this.id2SubItem[e.id]),this.curShowSubItem&&this.curShowSubItem.SetIsSelect(!0),this.curShowTitleItem=this.id2TitleItem[o],this.isLastShowSub=r,
this.curShowTitleItem.SetIsSelect(!0),this.curShowTitleItem.SetIsOpen(r)
for(var s=0,a=0;a<this.titleItems.length;a++)if(this.titleItems[a].node.y=-s,s+=this.itemTitleHeight,r&&this.titleItems[a].GetData().isParent()){
var l=this.titleItems[a].GetData().id
if(l==o&&this.parentID2SubItems[l])for(var h,c=Fe(this.parentID2SubItems[l]);!(h=c()).done;){var u=h.value
u.SetActive(!0),u.node.y=-s,s+=this.itemHeight}}this.scrollContent&&(this.scrollContent.height=s)
var p
p=this.curShowSubItem?this.curShowSubItem.GetData():this.curShowTitleItem.GetData(),this.curTreeData!=p&&(this.curTreeData=p,
this.onSelectCallback&&this.onSelectCallback(this.curTreeData))}},i.Recycle=function(){this.titleItemPool=[],this.subItemPool=[]
for(var e,t=Fe(this.node.children);!(e=t()).done;){var i=e.value,n=i.getComponent(bd)
n?(i.active=!1,this.titleItemPool.push(n)):(n=i.getComponent(id))&&(i.active=!1,this.subItemPool.push(n))}},i.CreateTitleItem=function(){var e
if(this.titleItemPool.length>0)(e=this.titleItemPool.pop()).node.active=!0
else{var t=p(this.titleItemPrefab)
this.node.addChild(t),e=t.getComponent(bd)}return e},i.CreateSubItem=function(){var e
if(this.subItemPool.length>0)(e=this.subItemPool.pop()).node.active=!0
else{var t=p(this.subItemPrefab)
this.node.addChild(t),e=t.getComponent(id)}return e},t}(t)).prototype,"itemTitleHeight",[od],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 68}}),
dd=ke(ud.prototype,"itemHeight",[sd],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 68}}),fd=ke(ud.prototype,"scrollContent",[ad],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return null}}),md=ke(ud.prototype,"titleItemPrefab",[ld],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){
return null}}),_d=ke(ud.prototype,"subItemPrefab",[hd],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),cd=ud))||cd),e._RF.pop(),
e._RF.push({},"a3af0n4dSZPGKFUEKVlz8L1","_UIButton",void 0)
var Md,Hd,Gd,Vd,Ud,Wd,jd,Yd,Xd,$d,qd,Jd,Zd,Kd=n.ccclass,Qd=(n.executeInEditMode,n.menu),ef=n.property,tf=(n.type,Td=Kd("app/UIButton"),wd=Qd("app/UIButton"),Id=ef({group:"UIButton"
}),Sd=ef({group:"UIButton"}),Rd=ef({group:"UIButton"}),xd=ef({group:"UIButton"}),Cd=ef({group:"UIButton"}),Td(Od=wd((Ld=ke((Pd=function(e){function t(){
for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return(t=e.call.apply(e,[this].concat(n))||this).value=!0,ze(t,"dragHighlight",Ld,De(t)),ze(t,"normalGray",Ed,De(t)),ze(t,"hoverGray",Dd,De(t)),ze(t,"pressGray",Ad,De(t)),
ze(t,"disabledGray",Fd,De(t)),ze(t,"pixelSnap",zd,De(t)),t}Le(t,e)
var i=t.prototype
return i.SetValue=function(e){this.value=e},i.GetValue=function(){return this.value},i.AddEventHandler=function(e){this.node.on(c.TOUCH_END,e)},i.RemoveEventHandler=function(e){
this.node.off(c.TOUCH_END,e)},t}(ae)).prototype,"dragHighlight",[ef],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),
Ed=ke(Pd.prototype,"normalGray",[Id],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),Dd=ke(Pd.prototype,"hoverGray",[Sd],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return!1}}),Ad=ke(Pd.prototype,"pressGray",[Rd],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),
Fd=ke(Pd.prototype,"disabledGray",[xd],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),zd=ke(Pd.prototype,"pixelSnap",[Cd],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return!1}}),Od=Pd))||Od)||Od)
e._RF.pop(),e._RF.push({},"10c6cnbRsZF/ZUina2HYgn7","_MyUIButton",void 0)
var nf=n.ccclass,rf=(n.executeInEditMode,n.menu),of=n.property,sf=n.type
Md=nf("app/MyUIButton"),Hd=rf("app/MyUIButton"),Gd=sf(d),Vd=sf(j),Ud=sf(W),Wd=sf(W),Md(jd=Hd((Xd=ke((Yd=function(e){function t(){
for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"text",Xd,De(t)),ze(t,"richText",$d,De(t)),ze(t,"bgSprite",qd,De(t)),ze(t,"extraSprite",Jd,De(t)),ze(t,"isHideBg",Zd,De(t)),
t.eUIButtonState={eNormal:0,eHover:1,ePressed:2,eDisabled:3},t}Le(t,e)
var i=t.prototype
return i.SetText=function(t){this.richText?this.richText.string=t:this.text&&e.prototype.SetText.call(this,t)},i.SetState=function(e,t){var i=this.target.getComponent(rs)
e==this.eUIButtonState.eNormal?i&&(i.spriteFrame=this.normalSprite):i&&(i.spriteFrame=this.pressedSprite)},t}(tf)).prototype,"text",[Gd],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return null}}),$d=ke(Yd.prototype,"richText",[Vd],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),
qd=ke(Yd.prototype,"bgSprite",[Ud],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),Jd=ke(Yd.prototype,"extraSprite",[Wd],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return null}}),Zd=ke(Yd.prototype,"isHideBg",[of],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),
jd=Yd))||jd),e._RF.pop(),e._RF.push({},"46b00LpCAxIoI1E/VCbWSkd","AvatarDir",void 0)
var af
e._RF.pop(),e._RF.push({},"84fa0ng/oFDTrcvFjgXcimx","VMCDirData",void 0)
var lf,hf=(0,n.ccclass)("VMCDirData")(af=function(){this.dirName="",this.offset=null,this.frames=null,this.vmcHeight=0})||af
e._RF.pop(),e._RF.push({},"d9b1amKtP1DA6uOGUTlpHz5","VMCData",void 0)
var cf=(0,n.ccclass)("VMCData")(lf=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return(t=e.call.apply(e,[this].concat(n))||this)._dirDatas=new Map,t.inters=null,t.frameCount=0,t.cfgsScale=1,t.effectTime=0,t.effectFrame=0,t.releaseTime=0,t.releaseFrame=0,
t.offsetX=0,t.offsetY=0,t.rotate360=!1,t.dirs=null,t.metaPrefix="",t._url="",t}Le(t,e)
var i=t.prototype
return i.hasDirName=function(e){return this._dirDatas.has(e)},i.getDirData=function(e){return this._dirDatas.get(e)||null},i.getDirData1=function(e){
return this._dirDatas.get(function(e){if(0==e)return 0
switch(e<0?e=-e:e<=7&&(e=function(e){return 7===e?1:6===e?2:5===e?3:e}(e)),e){case 1:case 45:return 45
case 2:case 90:return 90
case 3:case 135:return 135
case 4:case 180:return 180}throw new Error("error dir "+e)}(e).toString())||null},i.getDirs0=function(){if(this.dirs&&this.dirs[0])return this.dirs[0]
var e=""
return this._dirDatas.forEach((function(t,i){e||(e=i)})),e},i.parseFormat=function(e,t,i,n){var r,o,s,a,l,h,c,u,p=this
this.url=n
var d=this._dirDatas
d.clear()
var f=e.cfgs
this.inters=f.inter,this.frameCount=this.inters.length
var m=null!=(r=f.scale)?r:1
if(1!=m&&(m=1/m),this.cfgsScale=m,this.effectTime=null!=(o=f.effectTime)?o:0,this.effectFrame=null!=(s=f.effectFrame)?s:0,this.releaseTime=null!=(a=f.releaseTime)?a:0,
this.releaseFrame=null!=(l=f.releaseFrame)?l:0,this.offsetX=null!=(h=f.offsetX)?h:0,this.offsetY=null!=f.offsetY?uf(f.offsetY):0,1!=m&&(this.offsetX&&(this.offsetX*=m),
this.offsetY&&(this.offsetY*=m)),this.rotate360=null!=(c=f.rotate360)&&c,this.dirs=e.dirs||null,this.metaPrefix=null!=(u=e.meta.prefix)?u:"",
this.metaPrefix)throw new Error("metaPrefix = '"+this.metaPrefix+"', need support")
if(!f.offset)throw new Error("cfgs.offset is null")
if(Array.isArray(f.offset))throw new Error("cfgs.offset is Array, need support")
Object.keys(f.offset).forEach((function(t){var i=p._readDirData(e,t,f.offset[t])
d.set(t,i)}))},i._readDirData=function(e,t,i){for(var n=i.length,r=[],o=0;o<n;o++){for(var s=i[o],a=0;a<s.length;a++)s[a]=uf(s[a])
var l=t+"_"+o+".png",h=e.frames[l]
h?r[o]=h.frame:(r[o]=null,console.error("cannot find frame png name '"+l+"'"))}var c=new hf
return c.dirName=t,c.offset=i,c.frames=r,c.vmcHeight=i[0][1]*this.cfgsScale,c},i.clearFormat=function(){},Oe(t,[{key:"url",get:function(){return this._url},set:function(e){
this._url=e}}]),t}(C))||lf
function uf(e){return"number"==typeof e?e:parseFloat(e)}e._RF.pop(),e._RF.push({},"9e04bwCJcdFOY0mUwpWd+s1","VMCDirTex",void 0)
var pf={rect:new N,isRotate:!1,texture:null},df=[],ff=function(){function e(e,t){this._spf=null,this._spfs=[],this._frames=null,this._spf=e,this._frames=t}var t=e.prototype
return t.getFrameTex=function(e){var t=this._spfs
if(!t)return null
var i=t[e]
if(i)return i
if(!this._spf)return null
var n=this._frames[e]
return n?(pf.rect.set(n.x,n.y,n.w,n.h),pf.isRotate=!!n.rotated,pf.texture=this._spf.texture,df.length?i=df.pop():(i=new x).packable=!1,i.reset(pf,!0),pf.texture=null,t[e]=i,i):null
},t.clear=function(){var e=this._spfs
this._spfs=null
for(var t=0;t<e.length;t++){var i=e[t]
i&&i.destroy()}e.length=0,this._spf=null,this._frames=null},e}()
e._RF.pop(),e._RF.push({},"e700119BZNOrJ4vNTlMIwlU","VMCTex",void 0)
var mf,_f,gf=function(){function e(){this._spf=null,this._dirTexs=new Map,this.url=""}var t=e.prototype
return t.getDirTex=function(e){var t=this._dirTexs.get(e.dirName)
return t||(t=new ff(this._spf,e.frames),this._dirTexs.set(e.dirName,t)),t},t.parseFormat=function(e,t,i,n){this.url=n,this._spf=e,this._spf&&(this._spf.packable=!1)},
t.clearFormat=function(){this._dirTexs.forEach((function(e){e.clear()})),this._dirTexs.clear(),this._dirTexs=null,this._spf=null},e}()
e._RF.pop(),e._RF.push({},"b32bdRJyCdGNKcDQSe12ulS","VMCView",void 0)
var yf,vf=[[],[],[],[]],bf=new z
!function(e){e[e.SELF=0]="SELF",e[e.CHILD=1]="CHILD",e[e.SELF_FLOW=2]="SELF_FLOW",e[e.CHILD_FLOW=3]="CHILD_FLOW"}(yf||(yf={}))
var Tf,wf,If,Sf,Rf,xf,Cf,Of,Pf,Lf,Ef,Df,Af,Ff=(0,n.ccclass)("VMCView")(((_f=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return(t=e.call.apply(e,[this].concat(n))||this)._playOverRecover=!1,t._playOverRemove=!1,t.interval=0,t._customInterval=0,t._customTotalTime=0,t._poseProgress=-1,t._isPlaying=!0,
t._isLoop=!1,t._url=null,t._texUrl=null,t.backToFirstFrame=!1,t._actName=null,t._direct=0,t._roleScale=1,t._roleScaleY=0,t._appendList=null,t._loadCompleteHand=null,
t._resloadCompleteHand=null,t.backToLastFrame=!1,t._repeat=0,t._dynamicRepeat=0,t._lastPoseTime=0,t._playInterMultiple=1,t._nodeX=0,t._nodeY=0,t._type=yf.CHILD,t.__x=0,t.__y=0,
t._sprite=null,t._dirName=null,t.actCompleteCallBack=null,t.stopCallBack=null,t.isSon=!1,t.isNotAppendPos=!1,t.isBody=!1,t.isRolePart=!1,t._offsetY=0,t._resClearTime=6e3,
t._hided=!1,t._targetFrame=-1,t._onTargetHandler=null,t._onlyOnce=!1,t._frameChangeHandler=null,t._paintHandler=null,t.m_pauseFrame=null,t.m_interPauseFrame=null,
t.m_recoverUndisplay=!1,t.m_unDisplayRecoverCallBack=null,t._lastTexX=0,t._lastTexY=0,t._recovered=!1,t._vmcData=null,t._vmcDataResId=0,t._vmcTex=null,t._vmcDirTex=null,
t._vmcTexResId=0,t._preVmcTexResId=0,t._vmcDirData=null,t._renderEnabled=!0,t._poseStartTime=0,t.part="none",t.partId="",t.baseOffsetX=0,t.baseOffsetY=0,t}Le(t,e)
var i=t.prototype
return i.setUndisplayRecover=function(e,t){this.m_recoverUndisplay=e,this.m_unDisplayRecoverCallBack=t},i.onTargetFramehandler=function(e,t,i){void 0===i&&(i=!0),
this._targetFrame=e,this._onTargetHandler=t,this._onlyOnce=i},i.frameChangeHandler=function(e){this._frameChangeHandler=e},i.paintHandler=function(e){this._paintHandler=e},
t.createVMC=function(e,i){void 0===e&&(e=yf.CHILD),void 0===i&&(i=!1)
var n=vf[e]
if(n.length){var r=n.pop()
return r._recovered||console.error("error createVMC"),r._recovered=!1,r.setCameraLayer(!i),r}var o,s,a=l.createUINode("VMCView")
if(a.transform.setAnchorPoint(0,1),e==yf.SELF||e==yf.SELF_FLOW?o=a:((o=l.createUINode("RENDERER")).transform.setAnchorPoint(0,1),a.addChild(o)),e==yf.SELF_FLOW||e==yf.CHILD_FLOW){
s=o.addComponent(cs)
var h=hn.getResByPath("materials/sprite_flow")
s.customMaterial=h}else s=o.addComponent(W)
s.sizeMode=W.SizeMode.CUSTOM
var c=a.addComponent(t)
return c._type=e,c._sprite=s,c.setCameraLayer(!i),c},i.setCameraLayer=function(e){var t=this._sprite.node
e?(t.layer|=me.Enum.UI_2D,t.layer&=~me.Enum.DEFAULT):(t.layer&=~me.Enum.UI_2D,t.layer|=me.Enum.DEFAULT)},i.reset=function(){this._url=null,this.stop()},
i.updateRenderEnabled=function(e){this._renderEnabled=e,this._updateRender()},i.isRenderEnabled=function(){return this._renderEnabled},i.clearRender=function(){
this._renderEnabled=!1,this._isPlaying=!1,this._updateRender(),this.unload()},i._updateRender=function(e){var t=this._isPlaying&&(REAL_EDITOR||yn(this)),i=this._renderEnabled
;-1==this._dynamicRepeat&&(this._dynamicRepeat=this.repeat),t&&(i||this._dynamicRepeat>0)?this._isLoop||(this._isLoop=!0,this.schedule(this.loop,0)):this._isLoop&&(this._isLoop=!1,
this.unschedule(this.loop)),e||(t&&i&&this._url?(this.loadVMCData(this._url),this.loadTex()):this.unload())},i.play=function(e){if(null!=e&&(this.repeat=e),
this._url&&(!this.isSon||this.isNotAppendPos)){if(-1==this._dynamicRepeat&&(this._dynamicRepeat=this.repeat),!this._isPlaying){this._isPlaying=!0
var t=this._vmcData?this._vmcData.frameCount:0
this.poseProgress>=t-1&&(this.poseProgress=-1)}this._updateRender()}},i.replay=function(e){null!=e&&(this.repeat=e),this._dynamicRepeat=this.repeat,this.poseProgress=-1,this.play()
},i.updateFlow=function(e,t,i){this._sprite instanceof cs&&this._sprite.setLightColors(e,t,i)},i.loop=function(){if(this._renderEnabled){
if(this._vmcData&&this._isPlaying&&(!this.isSon||this.isNotAppendPos)&&this._vmcDirData){var e=cus.currTime
if(0==this._lastPoseTime||e-this._lastPoseTime>1e3)this._lastPoseTime=e,this.nextFrame()
else for(var t=this._url;e-this._lastPoseTime>this.interval;)if(this._lastPoseTime+=this.interval>0?this.interval:30,this.nextFrame(),!this._isPlaying||this._url!=t)return
this.countInter(),this._isPlaying&&this.paint()}}else{var i=this._dynamicRepeat*this._customTotalTime*this._playInterMultiple
cus.currTime-this._poseStartTime>=i&&this._playComplete()}},i.nextFrame=function(){var e=this._vmcData?this._vmcData.frameCount:0
if(!(e<=0)){var t=!1
this.backToLastFrame&&(this._poseProgress=e-1),this._poseProgress<e-1?++this._poseProgress:(-1==this._dynamicRepeat&&(this._dynamicRepeat=this.repeat),
this._dynamicRepeat>0?(this._dynamicRepeat--,0==this._dynamicRepeat?(this._dynamicRepeat=-1,this.backToFirstFrame&&(this._poseProgress=0),
t=!0):this._poseProgress=0):this._poseProgress=0),this._targetFrame==this._poseProgress&&this._onTargetHandler&&(this._onTargetHandler.run(),
this._onlyOnce&&(this._onTargetHandler=null,this._targetFrame=-1)),this._frameChangeHandler&&this._frameChangeHandler.runWith([this._poseProgress]),t&&this._playComplete()}},
i._playComplete=function(){var e=this._url
this.node.emit("COMPLETE",this),null!=this.actCompleteCallBack&&(this.actCompleteCallBack.run(),this.actCompleteCallBack=null),
this._url==e&&(this._playOverRemove&&this.removeSelf(),this._playOverRecover?this.recover():this.stop())},i.paint=function(){
var e=this._sprite,t=this._vmcDirData,i=this._poseProgress
if(t){if(!this._vmcDirTex)return
var n=this.baseOffsetX,r=this.baseOffsetY,o=t.offset
if(i<o.length){var s=o[i]
if(!s)return
var a=this.node.getScale(bf)
n+=s[0]+this.__x/a.x,r+=s[1]+this.__y/a.y}this._lastTexX=n,this._lastTexY=r
var l=t.frames[i]
if(!l)return
var h=this._vmcDirTex.getFrameTex(i)
e.spriteFrame=h,e.node.transform.setContentSize(l.w,l.h),this._preVmcTexResId>0&&(hn._$releaseRes(this._preVmcTexResId),this._preVmcTexResId=0)
var c=this._vmcData?this._vmcData.cfgsScale:1,u=c*this._roleScale*(this._direct>=0?1:-1),p=c*(0==this._roleScaleY?1:this._roleScaleY)
if(e.node.setScale(u,p),this.isRendererSelf?e.node.setPosition(this._nodeX+n*u,this._nodeY-r*p):e.node.setPosition(n*u,-r*p),
this._appendList&&this._appendList.length>0)for(var d=0;d<this._appendList.length;++d){var f=this._appendList[d]
f&&this.paintAppendView(f)}}else e&&e.spriteFrame&&(e.spriteFrame=null)},i.removeSelf=function(){return this.node.removeFromParent(),this.node},i.checkAppendChange=function(){
this._isPlaying&&this.isSon&&!this.isNotAppendPos&&(this._isPlaying=!1,this._updateRender())},i.stop=function(){var e=this._isPlaying
if(this._isPlaying=!1,this._isLoop=!1,this.unschedule(this.loop),e&&null!=this.stopCallBack){var t=this.stopCallBack
this.stopCallBack=null,t.run()}},i.updatePose=function(e,i,n,r,o,s,a,l,h,c,u){if(void 0===i&&(i=90),void 0===n&&(n=0),void 0===r&&(r=!1),void 0===o&&(o=!1),void 0===s&&(s=""),
void 0===a&&(a=!1),void 0===l&&(l=!1),void 0===h&&(h=null),void 0===c&&(c=null),void 0===u&&(u=!1),e){if(CC_INTRANET){var p=t.normalizePath(e)
p!=e&&(console.error("should normalizePath '"+e+"'"),e=p)}this._url=e,this._texUrl=e.replace(".json",".png"),this._direct=function(e){return e>0&&e<=7&&(e*=45),function(e){
if(isNaN(e))return 0
var t=e%360
return(t=(t+360)%360)>180&&(t-=360),t}(e)}(i),this.backToFirstFrame=a,this.backToLastFrame=u,
this._actName=s?s.replace("90",Math.abs(this._direct).toString()):Math.abs(this._direct).toString(),this.interval=0,this._repeat=n,this._dynamicRepeat=n,this._playOverRemove=r,
this._playOverRecover=o,this._poseStartTime=cus.currTime,this.poseProgress=-1,this.m_pauseFrame=null,this.m_interPauseFrame=null,this.isNotAppendPos=l,this.checkAppendChange(),
this._loadCompleteHand=h,this._resloadCompleteHand=c,this._isPlaying=!0,this._updateRender()}},i.loadVMCData=function(e){var t=hn.getResId(e)
t>0&&t==this._vmcDataResId?this._vmcData&&this._initVMCData(this._vmcData):(this._vmcData&&(this._vmcData=null),this._vmcDirData&&(this._vmcDirData=null),
this._vmcDirTex&&(this._vmcDirTex=null),this._vmcDataResId>0&&(hn._$releaseRes(this._vmcDataResId),hn.removeListenRes(this._vmcDataResId,this._onVMCDataLoaded,this),
this._vmcDataResId=0),this._vmcDataResId=hn.loadRemote(e,He.RefConfigData,{_ResFormat_:cf}),hn._$retainRes(this._vmcDataResId),
hn.listenRes(this._vmcDataResId,this._onVMCDataLoaded,this))},i.loadTex=function(){var e=this._texUrl,t=hn.getResId(e)
if(t>0&&t==this._vmcTexResId)this._vmcTex&&this._updateDirInfo()
else{if(this._vmcTex&&(this._vmcTex=null),this._vmcDirTex&&(this._vmcDirTex=null),this._preVmcTexResId>0){
if(this._preVmcTexResId==this._vmcTexResId)throw new Error("preVmcTexResId")
hn._$releaseRes(this._preVmcTexResId),hn.removeListenRes(this._preVmcTexResId,this._onVMCTexLoaded,this),this._preVmcTexResId=0,
this._sprite.spriteFrame&&(this._sprite.spriteFrame=null)}this._vmcTexResId>0&&(hn.removeListenRes(this._vmcTexResId,this._onVMCTexLoaded,this),
this._preVmcTexResId=this._vmcTexResId),this._vmcTexResId=hn.loadRemote(e,He.RefTex,{_ResFormat_:gf}),hn._$retainRes(this._vmcTexResId),
hn.listenRes(this._vmcTexResId,this._onVMCTexLoaded,this)}},i.unload=function(){this._vmcData&&(this._vmcData=null),this._vmcDirData&&(this._vmcDirData=null),
this._vmcDirTex&&(this._vmcDirTex=null),this._vmcTex&&(this._vmcTex=null),this._sprite&&this._sprite.spriteFrame&&(this._sprite.spriteFrame=null),
this._vmcDataResId>0&&(hn._$releaseRes(this._vmcDataResId),hn.removeListenRes(this._vmcDataResId,this._onVMCDataLoaded,this),this._vmcDataResId=0),
this._preVmcTexResId>0&&this._preVmcTexResId!=this._vmcTexResId&&(hn._$releaseRes(this._preVmcTexResId),hn.removeListenRes(this._preVmcTexResId,this._onVMCTexLoaded,this),
this._preVmcTexResId=0),this._vmcTexResId>0&&(hn._$releaseRes(this._vmcTexResId),hn.removeListenRes(this._vmcTexResId,this._onVMCTexLoaded,this),this._vmcTexResId=0)},
i._onVMCDataLoaded=function(e){e?(this._initVMCData(e),this.node.emit(t.DATA_COMPLETE,e)):this.node.emit(t.DATA_COMPLETE,null)},i._initVMCData=function(e){this._vmcData=e,
this._customTotalTime>0&&(this.customTotalTime=this._customTotalTime),this.checkPauseFrame(),this._updateDirInfo()},i._onVMCTexLoaded=function(e,t){e&&(this._vmcTex=e,
this._updateDirInfo())},i._updateDirInfo=function(){if(this._vmcTex&&this._vmcData){this._vmcDirData=null,this._vmcDirTex=null
var e=this._vmcData.getDirData(this._actName)
if(!e){var t=this._vmcData.getDirs0()
t&&(e=this._vmcData.getDirData(t))}e&&(this._vmcDirData=e,this._vmcDirTex=this._vmcTex.getDirTex(e)),-1==this._poseProgress?this.loop():this.paint()}},i.setPauseFrame=function(e){
this.m_pauseFrame=e,this.checkPauseFrame()},i.checkPauseFrame=function(){if(this._vmcData&&this.m_pauseFrame){var e=0
this.m_interPauseFrame=[]
for(var t=this._vmcData.inters,i=0;i<t.length;++i){var n=0,r=e
e+=t[i]
for(var o=0;o<this.m_pauseFrame.length;o++){var s=this.m_pauseFrame[o]
s.delay>=r&&s.delay<e&&(n+=s.time)}this.m_interPauseFrame.push(n)}this.countInter()}},i.isEffect=function(){
return!!(this._vmcData&&this._poseProgress>0)&&this._poseProgress>=this._vmcData.effectFrame},i.countInter=function(){if(this._vmcData&&(this.customInterval=this.customInterval,
1!=this._playInterMultiple&&(this.interval=Math.ceil(this.interval*this._playInterMultiple)),this.m_interPauseFrame)){var e=this.m_interPauseFrame[this._poseProgress]
1!=this._playInterMultiple&&(e=Math.ceil(e*this._playInterMultiple)),this.interval+=e}},i.clearAppendList=function(){this._appendList&&(this._appendList.length=0)},
i.appendView=function(e){this._appendList||(this._appendList=[]),-1==this._appendList.indexOf(e)&&this._appendList.push(e),e.isSon=!0,this.paintAppendView(e),e.checkAppendChange()
},i.removeAppend=function(e){if(this._appendList&&this._appendList.length>0){var t=this._appendList.indexOf(e);-1!=t&&this._appendList.splice(t,1),e.isSon=!1}e.checkAppendChange()
},i.paintAppendView=function(e){e.isNotAppendPos||(e.poseProgress=this._poseProgress,e.paint())},i.setPosition=function(e,t){e==this._nodeX&&t==this._nodeY||(this._nodeX=e,
this._nodeY=t,this.isRendererSelf?this.node.setPosition(e+this._lastTexX,t-this._lastTexY):this.node.setPosition(e,t))},i.move=function(e,t){this.__x==e&&this.__y==t||(this.__x=e,
this.__y=t)},i.initVMCRender=function(){this._recovered=!1,this._playOverRecover=!1,this._playOverRemove=!1,this._poseStartTime=0,this.interval=0,this._customInterval=0,
this._customTotalTime=0,this._poseProgress=-1,this._isPlaying=!0,this._isLoop=!1,this._url=null,this._texUrl=null,this.backToFirstFrame=!1,this._actName=null,this._direct=0,
this._roleScale=1,this._roleScaleY=0,this._appendList=null,this._loadCompleteHand&&(this._loadCompleteHand.recover(),this._loadCompleteHand=null),
this._resloadCompleteHand&&(this._resloadCompleteHand.recover(),this._resloadCompleteHand=null),this.backToLastFrame=!1,this._repeat=0,this._dynamicRepeat=0,this._lastPoseTime=0,
this._playInterMultiple=1,this._nodeX=0,this._nodeY=0,this.__x=0,this.__y=0,this._dirName=null,this.actCompleteCallBack&&(this.actCompleteCallBack.recover(),
this.actCompleteCallBack=null),this.stopCallBack&&(this.stopCallBack.recover(),this.stopCallBack=null),this.isSon=!1,this.isNotAppendPos=!1,this.isBody=!1,this.isRolePart=!1,
this._resClearTime=6e3,this._hided=!1,this.m_pauseFrame=null,this.m_interPauseFrame=null,this.m_recoverUndisplay=!1,this.m_unDisplayRecoverCallBack=null,this._targetFrame=-1,
this._onlyOnce=!1,this._onTargetHandler&&(this._onTargetHandler.recover(),this._onTargetHandler=null),this._frameChangeHandler&&(this._frameChangeHandler.recover(),
this._frameChangeHandler=null),this._paintHandler=null,this._lastTexX=0,this._lastTexY=0,this._offsetY=0,this._nodeX=0,this._nodeY=0,this.node.setPosition(0,0),this.part="none",
this.partId="",this.baseOffsetX=0,this.baseOffsetY=0},i.recover=function(){this._recovered||(this.unload(),this.node.removeFromParent(),this.stop(),this.clearAppendList(),
this.initVMCRender(),this.node.scale2d=1,this.node.name="VMCView",this._renderEnabled=!0,this._recovered=!0,vf[this._type].push(this),this.node.emit(t.EVENT_VIEW_RECOVER))},
i.onEnable=function(){this._updateRender()},i.onDisable=function(){this._updateRender(),this.unload()},i.onDestroy=function(){this.unload()},t.normalizePath=function(e){
return e.replace(/\\\\|\\|\/\//g,"/")},Oe(t,[{key:"direct",get:function(){return this._direct}},{key:"resUrl",get:function(){return this._url}},{key:"sprite",get:function(){
return this._sprite}},{key:"resClearTime",get:function(){return this._resClearTime},set:function(e){this._resClearTime=e}},{key:"roleScale",get:function(){return this._roleScale},
set:function(e){this._roleScale!=e&&(this._roleScale=e)}},{key:"roleScaleY",get:function(){return this._roleScaleY},set:function(e){this._roleScaleY!=e&&(this._roleScaleY=e)}},{
key:"repeat",get:function(){return this._repeat},set:function(e){this._repeat=e,this._dynamicRepeat=e}},{key:"vmcHeight",get:function(){
return this._vmcDirData?this._vmcDirData.vmcHeight:0}},{key:"dirName",get:function(){return this._dirName}},{key:"isPlaying",get:function(){return this._isPlaying}},{key:"hided",
get:function(){return this._hided},set:function(e){this._hided!=e&&(this._hided=e)}},{key:"vmcData",get:function(){return this._vmcData}},{key:"customInterval",get:function(){
return this._customInterval},set:function(e){this._customInterval=e,this.interval=e>0?e:120}},{key:"customTotalTime",get:function(){return this._customTotalTime},set:function(e){
this._customTotalTime=e,e>0?this._vmcData&&(this.customInterval=e/this._vmcData.frameCount>>0):this.customInterval=0}},{key:"actName",get:function(){return this._actName},
set:function(e){e!=this._actName&&(this._actName=e,this._updateDirInfo())}},{key:"isRendererSelf",get:function(){return this._type==yf.SELF||this._type==yf.SELF_FLOW}},{
key:"lastTexX",get:function(){return this._lastTexX}},{key:"lastTexY",get:function(){return this._lastTexY}},{key:"paintHandle",get:function(){return this._paintHandler}},{
key:"poseProgress",get:function(){return this._poseProgress},set:function(e){this._poseProgress=e}},{key:"count",get:function(){return this._vmcData?this._vmcData.frameCount:0}},{
key:"offsetX",get:function(){return this._vmcData?this._vmcData.offsetX*this._roleScale:0}},{key:"offsetY",get:function(){
return this._offsetY>0?this._offsetY:this._vmcData?this._vmcData.offsetY:0},set:function(e){this._offsetY=e}},{key:"effectTime",get:function(){
return this._vmcData?this._vmcData.effectTime:0}},{key:"x",get:function(){return this._nodeX},set:function(e){e!=this._nodeX&&this.setPosition(e,this._nodeY)}},{key:"y",
get:function(){return this._nodeY},set:function(e){e!=this._nodeY&&this.setPosition(this._nodeX,e)}},{key:"px",get:function(){return this.__x},set:function(e){
this.__x!=e&&(this.__x=e)}},{key:"py",get:function(){return this.__y},set:function(e){this.__y!=e&&(this.__y=e)}},{key:"playInterMultiple",get:function(){
return this._playInterMultiple},set:function(e){this._playInterMultiple=e}}]),t}(t)).DATA_COMPLETE="DATA_COMPLETE",_f.EVENT_VIEW_RECOVER="EVENT_VIEW_RECOVER",_f.VMCType=yf,
_f.hasRoleData=!1,mf=_f))||mf
e._RF.pop(),e._RF.push({},"399e4aDYyFIqrJb/PbxCGnD","_UIAnchor",void 0)
var zf,kf,Bf,Nf,Mf,Hf,Gf,Vf,Uf,Wf,jf,Yf,Xf,$f,qf,Jf,Zf,Kf,Qf=n.ccclass,em=(n.executeInEditMode,n.menu),tm=n.property,im=n.type,nm=(Tf=Qf("app/UIAnchor"),wf=em("app/UIAnchor"),
If=im(l),Sf=im(l),Rf=im(zc),Tf(xf=wf((Of=ke((Cf=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"uiCamera",Of,De(t)),ze(t,"container",Pf,De(t)),ze(t,"side",Lf,De(t)),ze(t,"runOnlyOnce",Ef,De(t)),
ze(t,"relativeOffset",Df,De(t)),ze(t,"pixelOffset",Af,De(t)),t}return Le(t,e),t}(t)).prototype,"uiCamera",[If],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){
return null}}),Pf=ke(Cf.prototype,"container",[Sf],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),Lf=ke(Cf.prototype,"side",[Rf],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return zc.eCenter}}),Ef=ke(Cf.prototype,"runOnlyOnce",[tm],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){
return!0}}),Df=ke(Cf.prototype,"relativeOffset",[tm],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return new Y}}),Af=ke(Cf.prototype,"pixelOffset",[tm],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return new Y}}),xf=Cf))||xf)||xf)
e._RF.pop(),e._RF.push({},"c6746CIRGhOZqJB5/bSSStk","_UIScrollView",void 0)
var rm,om,sm,am,lm,hm,cm,um,pm,dm,fm=n.ccclass,mm=(n.executeInEditMode,n.menu),_m=n.property,gm=n.type,ym=(zf=fm("app/UIScrollView"),kf=mm("app/UIScrollView"),Bf=gm(Tc),Nf=gm(yc),
Mf=gm(vc),zf(Hf=kf((Vf=ke((Gf=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"contentPivot",Vf,De(t)),ze(t,"movement",Uf,De(t)),ze(t,"dragEffect",Wf,De(t)),ze(t,"scrollWheelFactor",jf,De(t)),
ze(t,"momentumAmount",Yf,De(t)),ze(t,"restrictWithinPanel",Xf,De(t)),ze(t,"constrainOnDrag",$f,De(t)),ze(t,"disableDragIfFits",qf,De(t)),ze(t,"smoothDragStart",Jf,De(t)),
ze(t,"iOSDragEmulation",Zf,De(t)),ze(t,"searchMaskDepth",Kf,De(t)),t.maxDepth=6,t}Le(t,e)
var i=t.prototype
return i.clipOffset=function(){return this.getScrollOffset()},i.clipOffsetSet=function(e){this.scrollToOffset(e)},i.ResetPosition=function(){this.AdjustContentSize()},
i.AdjustContentSize=function(){var e=this.GetNodeAllChildrenRectPos(this.content,0),t=e[0],i=e[1],n=e[2],r=e[3]
this.horizontal&&(this.content.transform.width=i-t),this.vertical&&(this.content.transform.height=r-n),i!=t&&r!=n&&(this.horizontal&&(this.content.transform.anchorX=(0-t)/(i-t)),
this.vertical&&(this.content.transform.anchorY=(0-n)/(r-n)))},i.GetNodeAllChildrenRectPos=function(e,t){var i=0,n=0,r=0,o=0,s=5e3,a=-5e3,l=5e3,h=-5e3
if(t>this.maxDepth||!e.active)return[s,a,l,h]
var c=e.children
if(c)for(var u=0;u<c.length;u++){var p=this.GetNodeAllChildrenRectPos(c[u],t+1)
i=p[0],n=p[1],r=p[2],o=p[3],s=Math.min(s,i),a=Math.max(a,n),l=Math.min(l,r),h=Math.max(h,o)}
if(e.active&&e.transform&&(e.name!=this.content.name||e.parent.name!=this.content.parent.name)){if(e.transform.height<2||e.transform.width<2||e.components.length<=1)return[s,a,l,h]
if(!this.CheckNodeComp(e))return[s,a,l,h]
var d=this.TransNodePosToNodeB(e,this.content),f=this.GetNodeRectPos(d)
i=f[0],n=f[1],r=f[2],o=f[3],s=Math.min(s,i),a=Math.max(a,n),l=Math.min(l,r),h=Math.max(h,o)}return[s,a,l,h]},i.GetNodeChildrenRectPos=function(e){
for(var t=0,i=0,n=0,r=0,o=5e3,s=-5e3,a=5e3,l=-5e3,h=e.children,c=0;c<h.length;c++)if(e.transform){var u=this.GetNodeRectPos(h[c])
t=u[0],i=u[1],n=u[2],r=u[3],o=Math.min(o,t),s=Math.max(s,i),a=Math.min(a,n),l=Math.max(l,r)}return[o,s,a,l]},i.GetNodeRectPos=function(e){
var t=e.x-e.transform.anchorX*e.transform.width,i=t+e.transform.width,n=e.y-e.transform.anchorY*e.transform.height
return[t,i,n,n+e.transform.height]},i.GetSelfNodeRectPos=function(e){var t=0-e.transform.anchorX*e.transform.width,i=t+e.transform.width,n=0-e.transform.anchorY*e.transform.height
return[t,i,n,n+e.transform.height]},i.AdjustContentPos=function(){if(this.contentPivot==Tc.eTopLeft){var e=this.GetSelfNodeRectPos(this.node),t=e[0],i=(e[1],e[2],
e[3]),n=new _e.Vec2
n.x=this.content.transform.anchorX*this.content.transform.width+t,n.y=this.content.transform.anchorY*this.content.transform.height+i-this.content.transform.height,
this.content.position=new _e.Vec3(n.x,n.y,0)}},i.TransNodePosToNodeB=function(e,t){var i=e.getWorldPosition(),n=t.transform.convertToNodeSpaceAR(i),r=p(e)
return r.position=n,r},i.CheckNodeComp=function(e){for(var t=e.components.length-1;t>=0;t--)if(e.components[t]instanceof Ff)return!1
for(var i=e.components.length-1;i>=0;i--){var n=e.components[i]
if(n instanceof W)return!0
if(n instanceof rs)return!0
if(n instanceof d)return!0
if(n instanceof j)return!0
if(n instanceof ae)return!0
if(n instanceof nm)return!0}return!1},t}(ue)).prototype,"contentPivot",[Bf],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return Tc.eTopLeft}}),
Uf=ke(Gf.prototype,"movement",[Nf],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return yc.eHorizontal}}),Wf=ke(Gf.prototype,"dragEffect",[Mf],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return vc.eMomentumAndSpring}}),jf=ke(Gf.prototype,"scrollWheelFactor",[_m],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return.8}}),Yf=ke(Gf.prototype,"momentumAmount",[_m],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 35}}),
Xf=ke(Gf.prototype,"restrictWithinPanel",[_m],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!0}}),$f=ke(Gf.prototype,"constrainOnDrag",[_m],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),qf=ke(Gf.prototype,"disableDragIfFits",[_m],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return!1}}),Jf=ke(Gf.prototype,"smoothDragStart",[_m],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!0}}),
Zf=ke(Gf.prototype,"iOSDragEmulation",[_m],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!0}}),Kf=ke(Gf.prototype,"searchMaskDepth",[_m],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return 3}}),Hf=Gf))||Hf)||Hf)
e._RF.pop(),e._RF.push({},"3de69PVGj9ILIB2MMJJTGai","_MyUIDragScrollView",void 0)
var vm,bm,Tm,wm,Im,Sm,Rm=n.ccclass,xm=(n.executeInEditMode,n.menu),Cm=n.property,Om=n.type
rm=Rm("app/MyUIDragScrollView"),om=xm("app/MyUIDragScrollView"),sm=Om(ym),am=Om(s),rm(lm=om((cm=ke((hm=function(e){function t(){
for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"scrollView",cm,De(t)),ze(t,"trans",um,De(t)),ze(t,"autoFind",pm,De(t)),ze(t,"started",dm,De(t)),t}Le(t,e)
var i=t.prototype
return i.widthSet=function(e){this.node.transform.width=e},i.widthGet=function(e){return this.node.transform.width},i.heightSet=function(e){this.node.transform.height=e},
i.heightGet=function(){return this.node.transform.height},t}(t)).prototype,"scrollView",[sm],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),
um=ke(hm.prototype,"trans",[am],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),pm=ke(hm.prototype,"autoFind",[Cm],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return!1}}),dm=ke(hm.prototype,"started",[Cm],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),lm=hm))||lm),
e._RF.pop(),e._RF.push({},"f8a440N7alOQ7tUynBlVs3n","_MyUIGridEx",void 0)
var Pm,Lm,Em,Dm,Am,Fm,zm,km,Bm,Nm,Mm,Hm,Gm=n.ccclass,Vm=(n.executeInEditMode,n.menu),Um=(n.property,n.type)
vm=Gm("app/MyUIGridEx"),bm=Vm("app/MyUIGridEx"),Tm=Um(ym),vm(wm=bm((Sm=ke((Im=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"parentScrollView",Sm,De(t)),t}return Le(t,e),t}(np)).prototype,"parentScrollView",[Tm],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return null}}),wm=Im))||wm),e._RF.pop(),e._RF.push({},"c9f9fULg7xGT5mlYoEwbNJh","_UISlider",void 0)
var Wm,jm,Ym,Xm,$m,qm,Jm,Zm,Km=n.ccclass,Qm=(n.executeInEditMode,n.menu),e_=n.property,t_=n.type,i_=(Pm=Km("app/UISlider"),Lm=Qm("app/UISlider"),Em=e_({tooltip:"进度条,进度条x轴锚点为0"}),
Dm=t_(W),Am=t_(l),Fm=e_({tooltip:"进度条的最大长度,slider所在节点的x轴锚点必须为0.5"}),Pm(zm=Lm((Bm=ke((km=function(e){function t(){
for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"steps",Bm,De(t)),ze(t,"foreground",Nm,De(t)),ze(t,"background",Mm,De(t)),ze(t,"maxWidth",Hm,De(t)),t.callBack=null,
t.endCallBack=null,t}Le(t,e)
var i=t.prototype
return i.changeProgress=function(){this.foreground&&(this.foreground.node.getComponent(s).width=this.maxWidth*this.progress)},i._updateHandlePosition=function(){
this.handle&&(e.prototype._updateHandlePosition.call(this),this.changeProgress(),this.callBack&&this.callBack())},i._onTouchEnded=function(){
this.handle&&(e.prototype._onTouchEnded.call(this),this.endCallBack&&this.endCallBack())},Oe(t,[{key:"value",get:function(){return this.progress},set:function(e){this.progress=e}
}]),t}(ge)).prototype,"steps",[e_],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),Nm=ke(km.prototype,"foreground",[Em,Dm],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return null}}),Mm=ke(km.prototype,"background",[Am],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}
}),Hm=ke(km.prototype,"maxWidth",[Fm],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),zm=km))||zm)||zm)
e._RF.pop(),e._RF.push({},"f003dOmobhKlpp3b+I8QaNk","_UIScrollBar",void 0)
var n_,r_,o_,s_,a_,l_,h_,c_,u_,p_=n.ccclass,d_=(n.executeInEditMode,n.menu),f_=n.property,m_=(n.type,Wm=p_("app/UIScrollBar"),jm=d_("app/UIScrollBar"),Ym=f_({range:[0,1],slide:!0,
step:.01}),Xm=f_({range:[0,1],slide:!0,step:.01}),Wm($m=jm((Jm=ke((qm=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"_size",Jm,De(t)),ze(t,"_alpha",Zm,De(t)),t}return Le(t,e),Oe(t,[{key:"size",get:function(){return this._size},set:function(e){
this._size=e}},{key:"alpha",get:function(){return this._alpha},set:function(e){this._alpha=e}}]),t}(i_)).prototype,"_size",[f_],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return 1}}),ke(qm.prototype,"size",[Ym],Object.getOwnPropertyDescriptor(qm.prototype,"size"),qm.prototype),Zm=ke(qm.prototype,"_alpha",[f_],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return 1}}),ke(qm.prototype,"alpha",[Xm],Object.getOwnPropertyDescriptor(qm.prototype,"alpha"),qm.prototype),$m=qm))||$m)||$m)
e._RF.pop(),e._RF.push({},"238bdnPR/tCjqTSrta4hK9b","_MyUIScrollBar",void 0)
var __,g_,y_,v_,b_,T_,w_,I_,S_,R_,x_,C_=n.ccclass,O_=(n.executeInEditMode,n.menu),P_=n.property,L_=n.type
n_=C_("app/MyUIScrollBar"),r_=O_("app/MyUIScrollBar"),o_=L_(l),s_=L_(l),n_(a_=r_((h_=ke((l_=function(e){function t(){
for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"minusBtn",h_,De(t)),ze(t,"addBtn",c_,De(t)),ze(t,"btnStep",u_,De(t)),t}return Le(t,e),t}(m_)).prototype,"minusBtn",[o_],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),c_=ke(l_.prototype,"addBtn",[s_],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){
return null}}),u_=ke(l_.prototype,"btnStep",[P_],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return.1}}),a_=l_))||a_),e._RF.pop(),
e._RF.push({},"a8db1axgidO7ZXNdmYwrVO+","_MyUIScrollView",void 0)
var E_,D_,A_,F_,z_,k_,B_,N_,M_,H_,G_,V_,U_,W_,j_,Y_,X_,$_,q_,J_,Z_=n.ccclass,K_=(n.executeInEditMode,n.menu),Q_=n.property,eg=n.type
__=Z_("app/MyUIScrollView"),g_=K_("app/MyUIScrollView"),y_=eg(bc),__(v_=g_((T_=ke((b_=function(e){function t(){
for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"dampenStrength",T_,De(t)),ze(t,"showScrollBars",w_,De(t)),ze(t,"customMovement",I_,De(t)),ze(t,"CalcCellSize",S_,De(t)),
ze(t,"springBack",R_,De(t)),ze(t,"pixelFix",x_,De(t)),t}Le(t,e)
var i=t.prototype
return i.RegistonDragBegan=function(e){this.node.on(ue.EventType.SCROLL_BEGAN,e,this)},i.RegistonDragFinished=function(e){this.node.on(ue.EventType.SCROLL_ENDED,e,this)},
i.RegistonDragStarted=function(e){this.node.on(ue.EventType.SCROLL_BEGAN,e,this)},i.RegistonDragingMoving=function(e){this.node.on(ue.EventType.SCROLLING,e,this)},
i.RemoveonDragBegan=function(e){this.node.off(ue.EventType.SCROLL_BEGAN,e,this)},i.RemoveonDragFinished=function(e){this.node.off(ue.EventType.SCROLL_ENDED,e,this)},
i.RemoveonDragMoving=function(e){this.node.off(ue.EventType.SCROLLING,e,this)},i.RemoveonDragStarted=function(e){this.node.off(ue.EventType.SCROLL_BEGAN,e,this)},
i.ResetPosition=function(){e.prototype.ResetPosition.call(this)},i.SetValue=function(e){
0==e?this.scrollToTop():this.horizontal?this.scrollToPercentHorizontal(e,1,!0):this.scrollToPercentVertical(e,1,!0)},i.getScrollPercent=function(){
var e=this.horizontal,t=this._calculateMovePercentDelta({anchor:new Y(0,0),applyToHorizontal:e,applyToVertical:!e}),i=this.getMaxScrollOffset()
return e?t.x/i.x:t.y/i.y},i.setRectPosAndWH=function(e,t,i,n){var r=this.node.getChildByName("view")
r.x=e,r.y=t,r.transform.width=i,r.transform.height=n},t}(ym)).prototype,"dampenStrength",[Q_],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 9}}),
w_=ke(b_.prototype,"showScrollBars",[y_],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return bc.eOnlyIfNeeded}}),I_=ke(b_.prototype,"customMovement",[Q_],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return new Y(1,0)}}),S_=ke(b_.prototype,"CalcCellSize",[Q_],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return!1}}),R_=ke(b_.prototype,"springBack",[Q_],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!0}}),
x_=ke(b_.prototype,"pixelFix",[Q_],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!0}}),v_=b_))||v_),e._RF.pop(),
e._RF.push({},"3233cz7/wZHWbzrbs3fsaiM","_MyUISlider",void 0)
var tg,ig,ng,rg,og,sg,ag,lg,hg,cg,ug,pg,dg,fg,mg,_g,gg,yg,vg,bg,Tg,wg,Ig,Sg,Rg,xg,Cg=n.ccclass,Og=(n.executeInEditMode,n.menu),Pg=n.property,Lg=n.type
E_=Cg("app/MyUISlider"),D_=Og("app/MyUISlider"),A_=Lg(W),F_=Lg(W),z_=Lg(d),k_=Lg(s),B_=Lg(W),E_(N_=D_((H_=ke((M_=function(e){function t(){
for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"decimalDigits",H_,De(t)),ze(t,"FG",G_,De(t)),ze(t,"BG",V_,De(t)),ze(t,"Dir",U_,De(t)),ze(t,"lblText",W_,De(t)),
ze(t,"effectTrans",j_,De(t)),ze(t,"growTime",Y_,De(t)),ze(t,"cursor",X_,De(t)),ze(t,"cursor_offset",$_,De(t)),ze(t,"isAutoClear",q_,De(t)),ze(t,"w1",J_,De(t)),t._fillRange=0,t}
Le(t,e)
var i=t.prototype
return i.DoF_SetValueEx=function(e,t){},i.DoF_SetValue=function(e,t){var i=this.node.transform.width
this.BG&&(i=this.BG.node.transform.width),this.FG.node.transform.width=Math.min(e/t,1)*i},Oe(t,[{key:"fillRange",set:function(e){e=Math.min(e,1),this._fillRange=e
var t=this.node.transform.width
this.BG&&(t=this.BG.node.transform.width),this.FG.node.transform.width=e*t}}]),t}(t)).prototype,"decimalDigits",[Pg],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return 0}}),G_=ke(M_.prototype,"FG",[A_],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),V_=ke(M_.prototype,"BG",[F_],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),U_=ke(M_.prototype,"Dir",[Pg],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){
return 3}}),W_=ke(M_.prototype,"lblText",[z_],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),j_=ke(M_.prototype,"effectTrans",[k_],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),Y_=ke(M_.prototype,"growTime",[Pg],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return.8}}),X_=ke(M_.prototype,"cursor",[B_],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),
$_=ke(M_.prototype,"cursor_offset",[Pg],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),q_=ke(M_.prototype,"isAutoClear",[Pg],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return!1}}),J_=ke(M_.prototype,"w1",[Pg],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),
N_=M_))||N_),e._RF.pop(),e._RF.push({},"66607NahQpArYWyGKDh9zD4","_MyUITab",void 0)
var Eg,Dg,Ag,Fg,zg,kg,Bg,Ng,Mg,Hg,Gg,Vg,Ug,Wg,jg,Yg,Xg=n.ccclass,$g=n.executeInEditMode,qg=n.menu,Jg=n.property
n.type,tg=Xg("app/MyUITab"),ig=qg("app/MyUITab"),ng=Jg({tooltip:"标签面板之间间距"}),rg=Jg({tooltip:"间距是否增加按钮尺寸"}),og=Jg({type:Ec,tooltip:"方向（横向，竖向）,默认横向"}),sg=Jg({type:[l],
tooltip:"正在显示的标签面板"}),ag=Jg({type:[l],tooltip:"正在显示的标签视图"}),lg=Jg({type:[ce],tooltip:"隐藏标签索引列表"}),hg=Jg({tooltip:"选中标签回调,具体执行交给selectHandlerId绑定的函数进行处理"}),cg=Jg({
tooltip:"在代码设置位置时是否使用默认间距"}),ug=Jg({tooltip:"是否等回调以后设置按钮状态"}),pg=Jg({tooltip:"选中开关选项"}),tg(dg=$g(dg=ig((mg=ke((fg=function(e){function t(){
for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"defaultIndex",mg,De(t)),ze(t,"tabSpace",_g,De(t)),ze(t,"isSpaceAddBtnSize",gg,De(t)),ze(t,"direction",yg,De(t)),
ze(t,"isSetPos",vg,De(t)),ze(t,"buttons",bg,De(t)),ze(t,"contents",Tg,De(t)),ze(t,"hideIndexs",wg,De(t)),ze(t,"selectHandlerId",Ig,De(t)),ze(t,"isUseDefaultPading",Sg,De(t)),
ze(t,"isDelaySetBtnState",Rg,De(t)),ze(t,"enableSelect",xg,De(t)),t.curSetlect=void 0,t.onSelectCallback=void 0,t}Le(t,e)
var i=t.prototype
return i.SetSelectHandler=function(e){this.selectHandlerId=e,this.onSelectCallback=e
for(var t=0;t<this.buttons.length;t++)this.buttons[t].on(c.TOUCH_END,this.ChangeTabSelect,this,!1,[t])},i.ChangeTabSelect=function(e){this.curSetlect=e,
this.onSelectCallback(this.curSetlect)},i.SetSelectIndex=function(e,t){void 0===t&&(t=!1),this.curSetlect==e||(this.curSetlect=e),
t&&null!=this.onSelectCallback&&this.onSelectCallback(this.curSetlect)},i.GetSelectIndex=function(){return this.curSetlect},i.Clear=function(){
if(this.buttons)for(var e=0;e<this.buttons.length;e++)this.buttons[e].offAll()},t}(t)).prototype,"defaultIndex",[Jg],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return 0}}),_g=ke(fg.prototype,"tabSpace",[ng],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 1}}),
gg=ke(fg.prototype,"isSpaceAddBtnSize",[rg],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!0}}),yg=ke(fg.prototype,"direction",[og],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return Ec.eOrientaton}}),vg=ke(fg.prototype,"isSetPos",[Jg],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){
return!1}}),bg=ke(fg.prototype,"buttons",[sg],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return[]}}),Tg=ke(fg.prototype,"contents",[ag],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return[]}}),wg=ke(fg.prototype,"hideIndexs",[lg],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return[]}}),
Ig=ke(fg.prototype,"selectHandlerId",[hg],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),Sg=ke(fg.prototype,"isUseDefaultPading",[cg],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),Rg=ke(fg.prototype,"isDelaySetBtnState",[ug],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return!0}}),xg=ke(fg.prototype,"enableSelect",[pg],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!0}}),dg=fg))||dg)||dg),
e._RF.pop(),e._RF.push({},"ae219KM97lAs7SozU9lHBp2","_UITable",void 0)
var Zg,Kg,Qg,ey,ty,iy,ny,ry,oy,sy,ay,ly,hy,cy,uy,py,dy=n.ccclass,fy=(n.executeInEditMode,n.menu),my=n.property,_y=n.type,gy=(Eg=dy("app/UITable"),Dg=fy("app/UITable"),Ag=_y(Dc),
Fg=_y(Ic),zg=_y(Tc),kg=_y(Tc),Eg(Bg=Dg((Mg=ke((Ng=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"columns",Mg,De(t)),ze(t,"direction",Hg,De(t)),ze(t,"sorting",Gg,De(t)),ze(t,"pivot",Vg,De(t)),ze(t,"cellAlignment",Ug,De(t)),
ze(t,"hideInactive",Wg,De(t)),ze(t,"keepWithinPanel",jg,De(t)),ze(t,"padding",Yg,De(t)),t}return Le(t,e),t}(t)).prototype,"columns",[my],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return 0}}),Hg=ke(Ng.prototype,"direction",[Ag],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return Dc.eDown}}),
Gg=ke(Ng.prototype,"sorting",[Fg],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return Ic.eNone}}),Vg=ke(Ng.prototype,"pivot",[zg],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return Tc.eTopLeft}}),Ug=ke(Ng.prototype,"cellAlignment",[kg],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){
return Tc.eTopLeft}}),Wg=ke(Ng.prototype,"hideInactive",[my],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!0}}),
jg=ke(Ng.prototype,"keepWithinPanel",[my],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),Yg=ke(Ng.prototype,"padding",[my],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return new Y}}),Bg=Ng))||Bg)||Bg)
e._RF.pop(),e._RF.push({},"cf88aE4tOxPcaRtrVjxDwX3","_MyUITable",void 0)
var yy,vy,by,Ty,wy,Iy,Sy,Ry,xy,Cy,Oy,Py,Ly=n.ccclass,Ey=(n.executeInEditMode,n.menu),Dy=n.property
n.type,Zg=Ly("app/MyUITable"),Kg=Ey("app/MyUITable"),Qg=Dy({tooltip:"项是否滑出"}),ey=Dy({tooltip:"默认从右到左"}),ty=Dy({tooltip:"临时"}),iy=Dy({tooltip:"临时"}),ny=Dy({type:m}),
Zg(ry=Kg((sy=ke((oy=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"isMoveTween",sy,De(t)),ze(t,"isRight2Left",ay,De(t)),ze(t,"xOffset",ly,De(t)),ze(t,"yOffset",hy,De(t)),
ze(t,"cellWidth",cy,De(t)),ze(t,"cellHeight",uy,De(t)),t._array=null,t._itemTotal=0,t.itemList=void 0,t._itemCls=null,t._itemClick=null,t.m_onReposition=null,t.renderEvent=null,
t.tableCreateItems=void 0,ze(t,"tmpPrefab",py,De(t)),t}Le(t,e)
var i=t.prototype
return i.OnReposition_set=function(e){this.m_onReposition=e},i.data_set=function(e){this._array=e,this.total(e?e.length:0)},i.data_get=function(){return this._array},
i.SetInitInfo=function(e,t,i,n,r){t&&(this.renderEvent=t),this._itemCls=i,this._itemClick=n},i.total=function(e){this.tableCreateItems||(this.tableCreateItems=new Ii.CList),
this.createItems(e)
var t=e-this._itemTotal
return this._itemTotal=e,this.refreshItems(t),this.updateItems(),this.m_onReposition&&this.m_onReposition(),this},i.createItems=function(e){var t=this
if(this.tableCreateItems.count>e)return this.removeItems(e),void this.updateTableWidthAndHeight()
var i=e-this.tableCreateItems.count
i>0&&!this.itemList&&(this.itemList=new Ii.CList)
for(var n=0;n<i;n++){var r=p(this.tmpPrefab)
r._uiProps.uiTransformComp,r.__index=this.tableCreateItems.count,this.node.addChild(r),this.tableCreateItems.Add(r),this._itemCls?function(){var e=r.getCNode(t._itemCls)
t.itemList[r.__index]=e,t._itemClick&&(e.onClick=function(i){return t._itemClick(e)})
}():this.renderEvent&&(this.itemList[r.__index]=this.renderEvent([r,n,this._array?this._array[r.__index]:void 0]),nt(this.itemList[r.__index])),this.tableCreateItems.count,
this.notifyRefreshItem(r),this.setItemPos(r._uiProps.uiTransformComp,r.__index)}this.updateTableWidthAndHeight()},i.removeItems=function(e){
for(var t=this.tableCreateItems.count-e,i=0;i<t;i++){var n=this.tableCreateItems[this.tableCreateItems.count-1]
n.off(l.EventType.SIZE_CHANGED),n.off(l.EventType.TRANSFORM_CHANGED),this.node.removeChild(n),this.tableCreateItems.RemoveAt(this.tableCreateItems.count-1)}},
i.updateTableWidthAndHeight=function(){var e=0,t=0,i=0,n=0,r=null,o=null
if(0==this.columns)for(var s=0;s<this.node.children.length;s++)r=this.node.children[s],this.hideInactive&&!r.active||(e+=r.transform.width,o=r.position,
r.setPosition(new _e.Vec3(i+r.transform.width*r.transform.anchorPoint.x,o.y,o.z)),i+=r.transform.width,t<r.transform.height&&(t=r.transform.height))
if(1==this.columns)for(var a=0;a<this.node.children.length;a++)r=this.node.children[a],this.hideInactive&&!r.active||(t+=r.transform.height,o=r.position,
r.setPosition(new _e.Vec3(o.x,n,o.z)),n-=r.transform.height,e<r.transform.width&&(e=r.transform.width))
if(this.node.transform.width=e,this.node.transform.height=t,this.cellAlignment==Tc.eCenter&&0==this.columns)for(var l=0;l<this.node.children.length;l++)if(r=this.node.children[l],
!this.hideInactive||r.active){var h=r.position
r.position.set(h.x-e/2,h.y,h.z)}this.cellHeight&&this.cellHeight},i.refreshItems=function(e,t){},i.updateItems=function(){for(var e=0,t=0;t<this.tableCreateItems.length;t++){
var i=this.tableCreateItems[t]
i.__index=e,e++,this.notifyRefreshItem(i)}return this.updateTableWidthAndHeight(),this},i.notifyRefreshItem=function(e){var t=e.__index
this.itemList[t].SetData(this._array?this._array[t]:void 0)},i.setItemPos=function(e,t){var i=new z,n=this.columns
n>0?(i.x=t%n*this.cellWidth,i.y=-Math.floor(t/n)*this.cellHeight):(i.x=t*this.cellWidth,i.y=0),e.node.position=i},i.Reposition=function(){this.updateTableWidthAndHeight()},
i.GetDataByIndex=function(e){if(this.itemList&&this.itemList[e]&&this.itemList[e].data)return this.itemList[e].data},i.cellWidthSet=function(e){this.cellWidth=e},
i.cellHeightSet=function(e){this.cellHeight=e},i.AjustContentSize=function(e){},i.AjustItemsPosition=function(){
if(this.itemList)for(var e=0;e<this.itemList.length;e++)this.itemList[e]&&this.setItemPos(this.itemList[e].node.transform,e)},i.Clear=function(){
if(this.itemList)for(var e=0;e<this.itemList.length;e++)this.itemList[e].Clear&&this.itemList[e].Clear()},i.AjustItemPosByItemHeight=function(e){
for(var t=new Ii.CList,i=0,n=0;n<this.itemList.length&&n<this._array.length;n++){var r,o=new z
o.x=0,r=i+0,o.y=r,this.itemList[n].node.position=o,t.Add(o),i-=this.itemList[n].node.transform.height}this.node.parent,this.node.transform.height=Math.abs(i)},t
}(gy)).prototype,"isMoveTween",[Qg],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),ay=ke(oy.prototype,"isRight2Left",[ey],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return!0}}),ly=ke(oy.prototype,"xOffset",[Dy],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),
hy=ke(oy.prototype,"yOffset",[Dy],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),cy=ke(oy.prototype,"cellWidth",[ty],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return 0}}),uy=ke(oy.prototype,"cellHeight",[iy],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),
py=ke(oy.prototype,"tmpPrefab",[ny],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),ry=oy))||ry),e._RF.pop(),
e._RF.push({},"5aaa9mV/pRKzbjSKGMQPGJl","_SortingGroup",void 0)
var Ay,Fy=n.ccclass,zy=n.property,ky=n.type,By=n.disallowMultiple,Ny=n.requireComponent,My=n.executeInEditMode
!function(e){e[e.DEFAULT=0]="DEFAULT",e[e.TEST_LIST_ITEM=1]="TEST_LIST_ITEM"}(Ay||(Ay={})),o(Ay)
var Hy,Gy,Vy,Uy,Wy,jy,Yy,Xy,$y,qy=1e5
yy=Fy("app/SortingGroup"),vy=Ny(s),by=By(!0),Ty=My(!0),wy=ky(Ay),Iy=ky(Ay),Sy=zy({type:le,min:0,max:qy}),Ry=zy({type:le,min:0,max:qy}),yy(xy=vy(xy=by(xy=Ty((Oy=ke((Cy=function(e){
function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"_sortingLayer",Oy,De(t)),ze(t,"_orderInLayer",Py,De(t)),t}Le(t,e)
var i=t.prototype
return i.onEnable=function(){this.node.transform.sortingPriority=Math.sign(this._sortingLayer)*(Math.abs(this._sortingLayer)*qy+this._orderInLayer),
this.node.transform.sortingEnabled=!0},i.onDisable=function(){this.node.transform.sortingPriority=0,this.node.transform.sortingEnabled=!1},Oe(t,[{key:"sortingLayer",get:function(){
return this._sortingLayer},set:function(e){
this._sortingLayer=e,this.node.transform.sortingPriority=Math.sign(this._sortingLayer)*(Math.abs(this._sortingLayer)*qy+this._orderInLayer)}},{key:"orderInLayer",get:function(){
return this._orderInLayer},set:function(e){
this._orderInLayer=e,this.node.transform.sortingPriority=Math.sign(this._sortingLayer)*(Math.abs(this._sortingLayer)*qy+this._orderInLayer)}}]),t
}(t)).prototype,"_sortingLayer",[wy],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return Ay.DEFAULT}}),
ke(Cy.prototype,"sortingLayer",[Iy],Object.getOwnPropertyDescriptor(Cy.prototype,"sortingLayer"),Cy.prototype),Py=ke(Cy.prototype,"_orderInLayer",[Sy],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return 0}}),ke(Cy.prototype,"orderInLayer",[Ry],Object.getOwnPropertyDescriptor(Cy.prototype,"orderInLayer"),Cy.prototype),
xy=Cy))||xy)||xy)||xy),e._RF.pop(),e._RF.push({},"e4c6eQ72+ZCVKyTl8Zo5S6K","_SpineProvider",void 0)
var Jy,Zy,Ky=n.ccclass,Qy=n.property,ev=n.executeInEditMode,tv=n.menu,iv="spine_npc",nv="scene"
!function(e){e[e.SpineNpc=0]="SpineNpc",e[e.SpineUI=1]="SpineUI",e[e.SpineBusiness=2]="SpineBusiness",e[e.SpineDis=3]="SpineDis",e[e.SceneEff=4]="SceneEff",
e[e.SpineFuli=5]="SpineFuli"}(Jy||(Jy={})),Hy=Ky("app/SpineProvider"),Gy=tv("app/SpineProvider"),Vy=Qy({tooltip:"spine类型",type:ye(Jy)}),Hy(Uy=Gy(Uy=ev((jy=ke((Wy=function(e){
function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"_skeletonName",jy,De(t)),ze(t,"_animationName",Yy,De(t)),ze(t,"_replay",Xy,De(t)),t._tenabled=!0,t._skinName="default",
ze(t,"_spineNumType",$y,De(t)),t.speed=1,t._cacheMode=-1,t._pause=!1,t._pauseEnd=!1,t._spine=null,t._animationNames=null,t._skins=null,t._resId=0,t._opcode=0,t._endListener=null,
t.onLoadListener=null,t.isWorkEff=!1,t}Le(t,e)
var i=t.prototype
return i.getFixedAnimationName=function(){return this._animationName},i.setGray=function(){var e=xe((function*(e){}))
return function(t){return e.apply(this,arguments)}}(),i.setPaused=function(e,t,i){this._pause=e,this._pauseEnd=-1==t,!this._spine||!i&&e||(this._spine.paused=e)},
i.onLoad=function(){this.getSkeleton(),REAL_EDITOR&&this.schedule(this._checkEditorSpine,0)},i._checkEditorSpine=function(){var e=this.getSkeleton(),t=e._N$skeletonData
t&&t.name!=this._skeletonName&&(this.initSpine(e,!0),this.initSkeletonData(e,t,!0))},i.play=function(e,t){if(null!=t&&(this._animationName=t||"idle"),this._endListener=e,
_(this.node)){var i=this.getSkeleton()
this._skeletonName&&(0!=this._resId&&i.skeletonData&&i.skeletonData.name==this._skeletonName?this._doPlay():REAL_EDITOR?this.loadByEditor(i,this._skeletonName):this.load(this._skeletonName))
}},i._doPlay=function(){var e=this,t=this.getSkeleton()
if(t.isValid&&t.skeletonData.isValid){if(t.loop=this.replay,t.timeScale=this.speed,t.paused=!1,t.setStartListener((function(){t.paused=e.paused,e.node.emit("start")})),
this._endListener){var i=this._endListener
this._endListener=null,t.setEndListener(i)}else t.setEndListener((function(){}))
t.setAnimation(0,this.getFixedAnimationName(),this.replay)}},i._pauseEndListener=function(){if(this.paused){var e=this.getSkeleton()
this._pauseEnd?e.paused=!0:e.setAnimation(0,this.getFixedAnimationName(),this.replay)}},i.load=function(e){this._opcode&&hn.removeListenRes(this._opcode,this._listenCallback,this),
this.getSkeleton().enabled=!1
var t=!1,i=e
i.startsWith("build_")&&(i=i.split("_")[1],t=!0),this._opcode=hn.loadBundleRes(this.spineType+"/"+e+"/"+i,"remotes",ve.SkeletonData,this.spineType==iv||t?He.Long:He.RefCycle),
hn.listenRes(this._opcode,this._listenCallback,this)},i._listenCallback=function(e,t){if(this._opcode=0,this._resId!=t&&(this._resId&&hn._$releaseRes(this._resId),this._resId=t,
t&&hn._$retainRes(t)),e){this.getSkeleton().enabled=this._tenabled
var i=this.getSkeleton(),n=this._cacheMode
if(-1==n){var r=this.spineType
n=r==iv||r==nv?ve.Skeleton.AnimationCacheMode.SHARED_CACHE:ve.Skeleton.AnimationCacheMode.PRIVATE_CACHE}i.setAnimationCacheMode(n),i.skeletonData=e,this.initSkeletonData(i,e),
this.isWorkEff&&this.confirmWorkEffAnimation(!0),this._doPlay(),this.onLoadListener&&this.onLoadListener()}else this.onLoadListener&&this.onLoadListener()},
i.loadByEditor=function(e,t){REAL_EDITOR&&this.spineType},i.confirmWorkEffAnimation=function(e){if(this._animationNames&&this._animationNames.length){
for(var t="",i=!1,n=0;n<this._animationNames.length;n++){var r=this._animationNames[n]
t||"stand"==r||(t=r),r==this._animationName&&(i=!0)}i||"stand"==this._animationName&&!e||(this._animationName=t)}},i.enableSkeleton=function(e){this._tenabled=e,
this._resId>0&&0==this._opcode&&(this.getSkeleton().enabled=e)},i.getSkeleton=function(){if(!this._spine){var e=!1,t=this.getComponent(ve.Skeleton)
t||(e=!0,t=this.addComponent(ve.Skeleton)),this._spine=t,t.skeletonData&&this.initSkeletonData(t,t.skeletonData,!0),this.initSpine(t,e)}return this._spine},
i.initSpine=function(e,t){t&&(e.premultipliedAlpha=!1)},i.initSkeletonData=function(e,i,n){n&&(!REAL_EDITOR&&this._skeletonName||(this.skeletonName=i.name))
var r=i.textures?i.textures[0]:null
if(r&&r._premultiplyAlpha!=e.premultipliedAlpha&&(e.premultipliedAlpha=r._premultiplyAlpha,e._updateMaterial(),e.markForRender(!0)),this._animationNames=t.getAnimationNames(e),
this._animationName&&i.getRuntimeData().findAnimation(this.getFixedAnimationName())||(this.animationName=t.getFirstAnimationName(e,this._animationNames)),this._animationName){
var o=t.getSkinNames(e)
if(this._skins=o,"default"==this._skinName||-1==o.indexOf(this._skinName))for(var s=0;s<o.length;s++){var a=o[s]
if("default"!=a){this._skinName=a
break}}e.setSkin(this._skinName)}else g("SpineProvider error skeletonData")
REAL_EDITOR&&e._N$skeletonData},i.onDestroy=function(){this.releaseRes(!0)},i.remove=function(){this.releaseRes(),this.node.removeFromParent(),this._pause=!1,this._tenabled=!0,
this._cacheMode=-1,this._spine&&(this._spine.paused=!1)},i.releaseRes=function(e){!e&&this._spine&&(this._spine.enabled=!1),this._resId>0&&(hn._$releaseRes(this._resId),
this._resId=0),this._opcode&&(hn.removeListenRes(this._opcode,this._listenCallback,this),this._opcode=0)},t.getAnimationNames=function(e){var t=e.skeletonData
if(t){if(t._skeletonCache){var i=[],n=t._skeletonCache.animations
if(n)for(var r=0;r<n.length;r++)i.push(n[r].name)
return i}if(t.skeletonJson)return t.skeletonJson.animations?Object.getOwnPropertyNames(t.skeletonJson.animations):[]}return[]},t.getFirstAnimationName=function(e,i){
var n=i||t.getAnimationNames(e)
if(n.length>0){for(var r=0;r<n.length;r++){var o=n[r]
if("stand"==o||"idle"==o)return o}return n[0]}return""},t.getSkinNames=function(e){var t=[],i=e.skeletonData
if(i)if(i._skeletonCache){var n=i._skeletonCache.skins
if(n)for(var r=0;r<n.length;r++)t.push(n[r].name)}else if(e.skeletonData.skeletonJson){var o=i.skeletonJson.skins
if(o)for(var s=0;s<o.length;s++)t.push(o[s].name)}return t},Oe(t,[{key:"skeletonName",get:function(){return this._skeletonName},set:function(e){
this._skeletonName!=e&&(this._skeletonName=e)}},{key:"animationName",get:function(){return this._animationName},set:function(e){this._animationName!=e&&(this._animationName=e,
this.isWorkEff&&this.confirmWorkEffAnimation())}},{key:"replay",get:function(){return this._replay},set:function(e){this._replay=e}},{key:"skinName",get:function(){
return this._skinName},set:function(e){e!=this._skinName&&(this._skinName=e,this._spine&&this._spine.setSkin(e))}},{key:"spineNumType",get:function(){return this._spineNumType},
set:function(e){this._spineNumType=e}},{key:"spineType",get:function(){var e=iv
switch(this._spineNumType){case 0:e=iv
break
case 1:e="spine_ui"
break
case 2:e="spine_bus"
break
case 3:e="spine_dis"
break
case 4:e=nv
break
case 5:e="spine_fuli"
break
default:g("unsupport spineNumType "+this._spineNumType)}return e}},{key:"cacheMode",get:function(){return this._cacheMode},set:function(e){this._cacheMode=e}},{key:"paused",
get:function(){return this._pause},set:function(e){this._pause=e,this._spine&&(this._spine.paused=e)}}]),t}(t)).prototype,"_skeletonName",[Qy],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return""}}),ke(Wy.prototype,"skeletonName",[Qy],Object.getOwnPropertyDescriptor(Wy.prototype,"skeletonName"),Wy.prototype),
Yy=ke(Wy.prototype,"_animationName",[Qy],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return""}}),
ke(Wy.prototype,"animationName",[Qy],Object.getOwnPropertyDescriptor(Wy.prototype,"animationName"),Wy.prototype),Xy=ke(Wy.prototype,"_replay",[Qy],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return!0}}),ke(Wy.prototype,"replay",[Qy],Object.getOwnPropertyDescriptor(Wy.prototype,"replay"),Wy.prototype),
$y=ke(Wy.prototype,"_spineNumType",[Qy],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return Jy.SpineUI}}),
ke(Wy.prototype,"spineNumType",[Vy],Object.getOwnPropertyDescriptor(Wy.prototype,"spineNumType"),Wy.prototype),Uy=Wy))||Uy)||Uy),e._RF.pop(),
e._RF.push({},"84459P7uCBCyZEbtwFoq3wA","_ToggleBox",void 0)
var rv,ov,sv,av,lv,hv,cv,uv,pv,dv,fv,mv,_v=n.ccclass,gv=n.executeInEditMode
n.property,_v("app/ToggleBox")(Zy=gv(Zy=function(e){function t(){return e.apply(this,arguments)||this}Le(t,e)
var i=t.prototype
return i.onEnable=function(){e.prototype.onEnable.call(this)},i.onDisable=function(){e.prototype.onDisable.call(this)},t}(be))||Zy),e._RF.pop(),
e._RF.push({},"e2564MD3qtDSJCLqIIPw8Ra","UAnimationKeyFrame",void 0)
var yv,vv,bv,Tv,wv,Iv=n.ccclass,Sv=n.property,Rv=(n.disallowMultiple,n.type),xv=(rv=Iv("UAnimationKeyFrame"),ov=Rv(xc),rv((lv=ke((av=function(){ze(this,"time",lv,this),
ze(this,"value",hv,this),ze(this,"inTangent",cv,this),ze(this,"outTangent",uv,this),ze(this,"inWeight",pv,this),ze(this,"outWeight",dv,this),ze(this,"weightedMode",fv,this),
ze(this,"tangentMode",mv,this)}).prototype,"time",[Sv],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),hv=ke(av.prototype,"value",[Sv],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),cv=ke(av.prototype,"inTangent",[Sv],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){
return 0}}),uv=ke(av.prototype,"outTangent",[Sv],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),pv=ke(av.prototype,"inWeight",[Sv],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return 0}}),dv=ke(av.prototype,"outWeight",[Sv],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),
fv=ke(av.prototype,"weightedMode",[ov],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return xc.None}}),mv=ke(av.prototype,"tangentMode",[Sv],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return 0}}),sv=av))||sv)
e._RF.pop(),e._RF.push({},"d6d99EJTldHqIuKfecg99ml","UAnimationCurve",void 0)
var Cv,Ov,Pv,Lv,Ev,Dv,Av,Fv,zv,kv,Bv,Nv,Mv,Hv,Gv,Vv,Uv,Wv,jv,Yv,Xv,$v,qv=n.ccclass,Jv=(n.property,n.disallowMultiple,n.type),Zv=(yv=qv("UAnimationCurve"),vv=Jv([xv]),
yv((wv=ke((Tv=function(){ze(this,"keyFrames",wv,this)}).prototype,"keyFrames",[vv],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return[]}}),bv=Tv))||bv)
e._RF.pop(),e._RF.push({},"a9d9d094PFL+41zi2ssjkvq","_UITweener",void 0)
var Kv,Qv,eb,tb,ib,nb,rb,ob,sb=n.ccclass,ab=(n.executeInEditMode,n.menu),lb=n.property,hb=(n.type,Cv=sb("app/UITweener"),Ov=ab("app/UITweener"),Pv=lb({type:Fc,group:"tweener"}),
Lv=lb({type:Rc,group:"tweener"}),Ev=lb({type:Zv,visible:!1,group:"tweener"}),Dv=lb({group:"tweener"}),Av=lb({group:"tweener"}),Fv=lb({group:"tweener"}),zv=lb({group:"tweener"}),
kv=lb({group:"tweener"}),Bv=lb({group:"tweener"}),Cv(Nv=Ov((Hv=ke((Mv=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"method",Hv,De(t)),ze(t,"playStyle",Gv,De(t)),ze(t,"animationCurve",Vv,De(t)),ze(t,"duration",Uv,De(t)),
ze(t,"startDelay",Wv,De(t)),ze(t,"tweenGroup",jv,De(t)),ze(t,"ignoreTimeScale",Yv,De(t)),ze(t,"useFixedUpdate",Xv,De(t)),ze(t,"isRepeatForever",$v,De(t)),t.callbackIdList=null,t}
Le(t,e)
var i=t.prototype
return i.AddEventHandler=function(e){this.callbackIdList||(this.callbackIdList=new Ii.CList),this.callbackIdList.Add(e)},i.RemoveEventHandler=function(e){
this.callbackIdList&&this.callbackIdList.Contains(e)&&this.callbackIdList.Remove(e)},i.PlayForward=function(e,t){var i=this
void 0===t&&(t=0),this.onEnable&&this.onEnable(),setTimeout((function(){e&&e()
for(var t=0;i.callbackIdList&&t<i.callbackIdList.length;t++)i.callbackIdList[t]&&i.callbackIdList[t]()}),1e3*this.duration+t+1e3*this.startDelay),this.ExecuteTween()},
i.ExecuteTween=function(){},t}(t)).prototype,"method",[Pv],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return Fc.eLinear}}),
Gv=ke(Mv.prototype,"playStyle",[Lv],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return Rc.eOnce}}),Vv=ke(Mv.prototype,"animationCurve",[Ev],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return new Zv}}),Uv=ke(Mv.prototype,"duration",[Dv],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 1}}),
Wv=ke(Mv.prototype,"startDelay",[Av],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),jv=ke(Mv.prototype,"tweenGroup",[Fv],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return 0}}),Yv=ke(Mv.prototype,"ignoreTimeScale",[zv],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!0}
}),Xv=ke(Mv.prototype,"useFixedUpdate",[kv],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),$v=ke(Mv.prototype,"isRepeatForever",[Bv],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),Nv=Mv))||Nv)||Nv)
e._RF.pop(),e._RF.push({},"acbaa6xehdC0ZSVnByMG1qp","_TweenAlpha",void 0)
var cb,ub,pb,db,fb,mb,_b,gb,yb,vb,bb,Tb,wb=n.ccclass,Ib=(n.executeInEditMode,n.menu),Sb=n.property
n.type,Kv=wb("app/TweenAlpha"),Qv=Ib("app/TweenAlpha"),eb=Sb({range:[0,1],slide:!0,step:.01}),tb=Sb({range:[0,1],slide:!0,step:.01}),Kv(ib=Qv((rb=ke((nb=function(e){function t(){
for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"from",rb,De(t)),ze(t,"to",ob,De(t)),t.opacityMax=255,t}Le(t,e)
var i=t.prototype
return i.onEnable=function(){if(this.node.opacity=this.from*this.opacityMax,this.isRepeatForever){var e=new Te(this.node).delay(this.startDelay).to(0,{
opacity:this.from*this.opacityMax}).to(this.duration,{opacity:this.to*this.opacityMax},{easing:"linear"})
new Te(this.node).repeatForever(e).start()}else new Te(this.node).delay(this.startDelay).to(this.duration,{opacity:this.to*this.opacityMax},{easing:"linear"}).start()},
i.Play=function(){this.PlayForward()},i.SetFrom=function(e){this.from=e},i.GetFrom=function(){return this.from},i.SetTo=function(e){this.to=e},i.GetTo=function(){return this.to},
i.durationSet=function(e){this.duration=e},i.ResetToBeginning=function(){this.node.opacity=this.from*this.opacityMax},t}(hb)).prototype,"from",[eb],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return 1}}),ob=ke(nb.prototype,"to",[tb],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 1}}),ib=nb))||ib),e._RF.pop(),
e._RF.push({},"850a4L5jUZMUrpLIQ76qcVm","_TweenCallback",void 0)
var Rb,xb,Cb,Ob,Pb=n.ccclass,Lb=(n.executeInEditMode,n.menu),Eb=n.property
n.type,Pb("app/TweenCallback")(cb=Lb("app/TweenCallback")((pb=ke((ub=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"from",pb,De(t)),ze(t,"to",db,De(t)),ze(t,"fromVec",fb,De(t)),ze(t,"toVec",mb,De(t)),ze(t,"fromInt",_b,De(t)),
ze(t,"toInt",gb,De(t)),ze(t,"fromColor",yb,De(t)),ze(t,"toColor",vb,De(t)),ze(t,"fromDouble",bb,De(t)),ze(t,"toDouble",Tb,De(t)),t}return Le(t,e),t}(hb)).prototype,"from",[Eb],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),db=ke(ub.prototype,"to",[Eb],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0
}}),fb=ke(ub.prototype,"fromVec",[Eb],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return new z}}),mb=ke(ub.prototype,"toVec",[Eb],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return new z}}),_b=ke(ub.prototype,"fromInt",[Eb],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),
gb=ke(ub.prototype,"toInt",[Eb],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),yb=ke(ub.prototype,"fromColor",[Eb],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return H.WHITE.clone()}}),vb=ke(ub.prototype,"toColor",[Eb],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){
return H.WHITE.clone()}}),bb=ke(ub.prototype,"fromDouble",[Eb],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),Tb=ke(ub.prototype,"toDouble",[Eb],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),cb=ub))||cb),e._RF.pop(),e._RF.push({},"8d2aa/0RRFG04DGaU7v3vqS","_TweenColor",void 0)
var Db,Ab,Fb,zb,kb,Bb=n.ccclass,Nb=(n.executeInEditMode,n.menu),Mb=n.property
n.type,Bb("app/TweenColor")(Rb=Nb("app/TweenColor")((Cb=ke((xb=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"from",Cb,De(t)),ze(t,"to",Ob,De(t)),t}return Le(t,e),t}(hb)).prototype,"from",[Mb],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return H.WHITE.clone()}}),Ob=ke(xb.prototype,"to",[Mb],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return H.WHITE.clone()}}),
Rb=xb))||Rb),e._RF.pop(),e._RF.push({},"a9da8scQg9KJLA1HvetGc6I","_TweenHeight",void 0)
var Hb,Gb,Vb,Ub,Wb=n.ccclass,jb=(n.executeInEditMode,n.menu),Yb=n.property
n.type,Wb("app/TweenHeight")(Db=jb("app/TweenHeight")((Fb=ke((Ab=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"from",Fb,De(t)),ze(t,"to",zb,De(t)),ze(t,"updateTable",kb,De(t)),t}return Le(t,e),t}(hb)).prototype,"from",[Yb],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 100}}),zb=ke(Ab.prototype,"to",[Yb],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){
return 100}}),kb=ke(Ab.prototype,"updateTable",[Yb],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),Db=Ab))||Db),e._RF.pop(),
e._RF.push({},"f9814lBEpZOtJR5yGQA43Sa","_TweenPosition",void 0)
var Xb,$b,qb,Jb,Zb,Kb=n.ccclass,Qb=(n.executeInEditMode,n.menu),eT=n.property
n.type,Kb("app/TweenPosition")(Hb=Qb("app/TweenPosition")((Vb=ke((Gb=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"from",Vb,De(t)),ze(t,"to",Ub,De(t)),t.handler=null,t._text=null,t}Le(t,e)
var i=t.prototype
return i.start=function(){this.ExecuteTween()},i.ExecuteTween=function(){if(this.node.position=this.from,this.isRepeatForever){var e=new Te(this.node).delay(this.startDelay).to(0,{
position:this.from}).to(this.duration,{position:this.to},{easing:"linear"}).to(this.duration,{position:this.from},{easing:"linear"})
new Te(this.node).repeatForever(e).start()}else new Te(this.node).delay(this.startDelay).to(this.duration,{position:this.to},{easing:"linear"}).start()},i.SetFrom=function(e){
this.from.set(e)},i.GetFrom=function(){return this.from},i.SetDelay=function(e){this.startDelay=e},i.SetTo=function(e){this.to.set(e)},i.GetTo=function(){return this.to},
i.textSet=function(e){var t=this.text
t&&(t.string=e)},i.widthSet=function(e){this.node.transform.width=e,this.text.maxWidth&&(this.text.maxWidth=e)},i.heightSet=function(e){this.node.transform.height=e},
i.printedSize=function(){var e=this.text
return this.GetLabelLineSizeByStr(e,e.string)},i.sizeSet=function(e){this.node.transform.width=e.x,this.node.transform.height=e.y},i.durationSet=function(e){this.duration=e},
i.ResetToBeginning=function(){this.node.position=this.from},i.GetUrlAtPositionVec3=function(e){return this.node.transform.convertToNodeSpaceAR(e),""},
i.GetLabelLineSizeByStr=function(e,t){var i=t,n=new l
n.parent=e.node.parent,n.active=!0
var r=n.addComponent(d)
r.fontSize=e.fontSize,r.lineHeight=e.lineHeight,r.horizontalAlign=e.horizontalAlign,r.verticalAlign=e.verticalAlign,e instanceof j&&(i=this.GetRichtTextLabel(t),
0==e.maxWidth&&(r.enableWrapText=!1)),r.string=i,r.updateRenderData()
var o=r.node.transform.contentSize
return n.parent=null,o},i.GetRichtTextLabel=function(e){for(var t=e,i=/\<.*?\>/,n=t.match(i);null!=n;)n=(t=t.replace(i,"")).match(i)
var r=t.match(/\[url=.*?\[\/url\]/g)
if(r&&r.length)for(var o=0;o<r.length;o++){var s=r[o],a="",l=s.match(/\].*?\[\//g)
if(l&&(a=l[0].substring(1,l[0].length-2)||""),a){var h=""+a
t=t.replace(s,h)}}var c=/\[.*?\]/g,u=/\\\[.*?\\\]/
if((r=t.match(c))&&r.length)for(var p=0;p<r.length;p++){var d=r[p]
null==d.match(/\\/)&&d.substring(1,d.length-1)&&(t=t.replace(d,""))}n=t.match(c)
var f=t.match(u),m=""
for(f=t.match(u);null!=f;)m=f[0].slice(2,f[0].length-2),f=(t=t.replace(u,"["+m+"]")).match(u)
return t},i.getPrintLength=function(e){for(var t=e,i=/\<.*?\>/,n=t.match(i);null!=n;)n=(t=t.replace(i,"")).match(i)
var r=t.match(/\[url=.*?\[\/url\]/g)
if(r&&r.length)for(var o=0;o<r.length;o++){var s=r[o],a="",l=s.match(/\].*?\[\//g)
if(l&&(a=l[0].substring(1,l[0].length-2)||""),a){var h=""+a
t=t.replace(s,h)}}var c=/\[.*?\]/g,u=/\\\[.*?\\\]/
if((r=t.match(c))&&r.length)for(var p=0;p<r.length;p++){var d=r[p]
null==d.match(/\\/)&&d.substring(1,d.length-1)&&(t=t.replace(d,""))}n=t.match(c)
var f=t.match(u),m=""
for(f=t.match(u);null!=f;)m=f[0].slice(2,f[0].length-2),f=(t=t.replace(u,"["+m+"]")).match(u)
return t.length},Oe(t,[{key:"text",get:function(){return this._text||(this._text=this.node.getComponent(d),this._text||(this._text=this.node.getComponent(j))),this._text}}]),t
}(hb)).prototype,"from",[eT],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return new z}}),Ub=ke(Gb.prototype,"to",[eT],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return new z}}),Hb=Gb))||Hb),e._RF.pop(),e._RF.push({},"c4039kI30xCfqRq0JUW14Zp","_TweenRotation",void 0)
var tT,iT,nT,rT,oT,sT=n.ccclass,aT=(n.executeInEditMode,n.menu),lT=n.property
n.type,sT("app/TweenRotation")(Xb=aT("app/TweenRotation")((qb=ke(($b=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"from",qb,De(t)),ze(t,"to",Jb,De(t)),ze(t,"quaternionLerp",Zb,De(t)),t}Le(t,e)
var i=t.prototype
return i.onEnable=function(){if(this.node.eulerAngles=this.from,this.isRepeatForever){var e=new Te(this.node).delay(this.startDelay).to(0,{eulerAngles:this.from
}).to(this.duration,{eulerAngles:this.to},{easing:"linear"}).to(this.duration,{eulerAngles:this.from},{easing:"linear"})
new Te(this.node).repeatForever(e).start()}else new Te(this.node).delay(this.startDelay).to(this.duration,{eulerAngles:this.to},{easing:"linear"}).start()},
i.durationSet=function(e){},i.SetFrom=function(e){this.from=e},i.SetTo=function(e){this.to=e},t}(hb)).prototype,"from",[lT],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return new z}}),Jb=ke($b.prototype,"to",[lT],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return new z}}),
Zb=ke($b.prototype,"quaternionLerp",[lT],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),Xb=$b))||Xb),e._RF.pop(),
e._RF.push({},"37687SHWkFK2p31LgSaBrrq","_TweenScale",void 0)
var hT,cT,uT,pT,dT,fT,mT,_T,gT,yT,vT,bT,TT,wT,IT,ST,RT,xT,CT,OT,PT,LT,ET,DT=n.ccclass,AT=(n.executeInEditMode,n.menu),FT=n.property
n.type,DT("app/TweenScale")(tT=AT("app/TweenScale")((nT=ke((iT=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"from",nT,De(t)),ze(t,"to",rT,De(t)),ze(t,"updateTable",oT,De(t)),t}Le(t,e)
var i=t.prototype
return i.onEnable=function(){if(this.node.scale=this.from,this.isRepeatForever){var e=new Te(this.node).delay(this.startDelay).to(0,{scale:this.from}).to(this.duration,{
scale:this.to},{easing:"linear"})
new Te(this.node).repeatForever(e).start()}else new Te(this.node).delay(this.startDelay).to(this.duration,{scale:this.to},{easing:"linear"}).start()},i.SetFrom=function(e){
this.from.set(e)},i.SetTo=function(e){this.to.set(e)},i.durationSet=function(e){this.duration=e},i.SetToXYZ=function(e,t,i){this.to=new z(e,t,e)},i.SetEnabled=function(e){
this.enabled=e},i.ResetToBeginning=function(){this.node.scale=this.from},i.Play=function(){this.PlayForward()},t}(hb)).prototype,"from",[FT],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return new z(1,1,1)}}),rT=ke(iT.prototype,"to",[FT],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return new z(1,1,1)}}),
oT=ke(iT.prototype,"updateTable",[FT],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),tT=iT))||tT),e._RF.pop(),
e._RF.push({},"d188dsCZOdGn6YHul8iTntt","_UIAvatar",void 0)
var zT,kT,BT,NT,MT,HT,GT,VT,UT,WT=n.ccclass,jT=n.property,YT=n.menu
hT=WT("app/UIAvatar"),cT=YT("app/UIAvatar"),uT=jT({formerlySerializedAs:"_isTalkHD"}),pT=jT({tooltip:"高清展示资源"}),dT=jT({displayName:"套装id",tooltip:"mid"}),fT=jT({displayName:"翅膀id",
tooltip:"wgid"}),mT=jT({displayName:"双手武器",tooltip:"wid"}),_T=jT({displayName:"左手武器",tooltip:"widL"}),gT=jT({displayName:"右手武器",tooltip:"widR"}),yT=jT({displayName:"坐骑",
tooltip:"mount"}),vT=jT({displayName:"动作id",tooltip:"act"}),bT=jT({displayName:"方向",range:[0,7],step:1,tooltip:"方向0-7, 0朝上，顺时针"}),hT(TT=cT((IT=ke((wT=function(e){function t(){
for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"_mid",IT,De(t)),ze(t,"_wgid",ST,De(t)),ze(t,"_wid",RT,De(t)),ze(t,"_widL",xT,De(t)),ze(t,"_widR",CT,De(t)),
ze(t,"_mount",OT,De(t)),ze(t,"_act",PT,De(t)),ze(t,"_dir",LT,De(t)),ze(t,"_resHD",ET,De(t)),t.render=null,t}Le(t,e)
var i=t.prototype
return i.onLoad=function(){this.updateRender()},i.updateRender=function(){this.unschedule(this._delayUpdate),this.scheduleOnce(this._delayUpdate,0)},i._delayUpdate=function(){
var e=this.render
if(!e){var t=r.getClassByName("engine.AvatarRender")
if(null==t)return;(e=this.node.getComponent(t)||this.node.addComponent(t)).uiMode=!0,this.render=e}
this._mid?e.mainPartId="mid":this._wgid?e.mainPartId="wgid":this._wid?e.mainPartId="wid":this._widL?e.mainPartId="widL":this._widR?e.mainPartId="widR":this._mount&&(e.mainPartId="mount"),
e.resShow=this.resHD,this._act&&e.setAct(this._act),e.loadPart("mid",this._mid),e.loadPart("wgid",this._wgid),e.loadPart("wid",this._wid),e.loadPart("widL",this._widL),
e.loadPart("widR",this._widR),e.loadPart("mount",this._mount),e.currDir=this._dir},Oe(t,[{key:"resHD",get:function(){return this._resHD},set:function(e){
this._resHD!=e&&(this._resHD=e,Cn()||REAL_EDITOR||this.updateRender())}},{key:"mid",get:function(){return this._mid},set:function(e){this._mid!=e&&(this._mid=e,
Cn()||REAL_EDITOR||this.updateRender())}},{key:"wgid",get:function(){return this._wgid},set:function(e){this._wgid!=e&&(this._wgid=e,Cn()||REAL_EDITOR||this.updateRender())}},{
key:"wid",get:function(){return this._wid},set:function(e){this._wid!=e&&(this._wid=e,Cn()||REAL_EDITOR||this.updateRender())}},{key:"widL",get:function(){return this._widL},
set:function(e){this._widL!=e&&(this._widL=e,Cn()||REAL_EDITOR||this.updateRender())}},{key:"widR",get:function(){return this._widR},set:function(e){this._widR!=e&&(this._widR=e,
Cn()||REAL_EDITOR||this.updateRender())}},{key:"mount",get:function(){return this._mount},set:function(e){this._mount!=e&&(this._mount=e,Cn()||REAL_EDITOR||this.updateRender())}},{
key:"act",get:function(){return this._act},set:function(e){this._act!=e&&(this._act=e,Cn()||REAL_EDITOR||this.updateRender())}},{key:"dir",get:function(){return this._dir},
set:function(e){this._dir!=e&&(this._dir=e,this.render&&(this.render.currDir=e))}}]),t}(t)).prototype,"_mid",[jT],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){
return""}}),ST=ke(wT.prototype,"_wgid",[jT],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return""}}),RT=ke(wT.prototype,"_wid",[jT],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return""}}),xT=ke(wT.prototype,"_widL",[jT],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return""}}),
CT=ke(wT.prototype,"_widR",[jT],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return""}}),OT=ke(wT.prototype,"_mount",[jT],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return""}}),PT=ke(wT.prototype,"_act",[jT],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return""}}),
LT=ke(wT.prototype,"_dir",[jT],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),ET=ke(wT.prototype,"_resHD",[uT],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return!1}}),ke(wT.prototype,"resHD",[pT],Object.getOwnPropertyDescriptor(wT.prototype,"resHD"),wT.prototype),
ke(wT.prototype,"mid",[dT],Object.getOwnPropertyDescriptor(wT.prototype,"mid"),wT.prototype),
ke(wT.prototype,"wgid",[fT],Object.getOwnPropertyDescriptor(wT.prototype,"wgid"),wT.prototype),
ke(wT.prototype,"wid",[mT],Object.getOwnPropertyDescriptor(wT.prototype,"wid"),wT.prototype),
ke(wT.prototype,"widL",[_T],Object.getOwnPropertyDescriptor(wT.prototype,"widL"),wT.prototype),
ke(wT.prototype,"widR",[gT],Object.getOwnPropertyDescriptor(wT.prototype,"widR"),wT.prototype),
ke(wT.prototype,"mount",[yT],Object.getOwnPropertyDescriptor(wT.prototype,"mount"),wT.prototype),
ke(wT.prototype,"act",[vT],Object.getOwnPropertyDescriptor(wT.prototype,"act"),wT.prototype),
ke(wT.prototype,"dir",[bT],Object.getOwnPropertyDescriptor(wT.prototype,"dir"),wT.prototype),TT=wT))||TT),e._RF.pop(),
e._RF.push({},"49197Sk4bNE4a8irFzvFr9z","_UIButtonScale",void 0)
var XT,$T,qT,JT,ZT=n.ccclass,KT=(n.executeInEditMode,n.menu),QT=n.property,ew=n.type
zT=ZT("app/UIButtonScale"),kT=KT("app/UIButtonScale"),BT=ew(l),zT(NT=kT((HT=ke((MT=function(e){function t(){
for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"tweenTarget",HT,De(t)),ze(t,"hover",GT,De(t)),ze(t,"pressed",VT,De(t)),ze(t,"duration",UT,De(t)),t}return Le(t,e),t
}(t)).prototype,"tweenTarget",[BT],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),GT=ke(MT.prototype,"hover",[QT],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return new z(1,1,1)}}),VT=ke(MT.prototype,"pressed",[QT],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){
return new z(.95,.95,.95)}}),UT=ke(MT.prototype,"duration",[QT],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return.2}}),NT=MT))||NT),e._RF.pop(),
e._RF.push({},"22886hStedJq4cBeIkNLOPp","_UICenterOnChild",void 0)
var tw,iw,nw,rw,ow,sw,aw,lw,hw,cw,uw=n.ccclass,pw=(n.executeInEditMode,n.menu),dw=n.property
n.type,uw("app/UICenterOnChild")(XT=pw("app/UICenterOnChild")((qT=ke(($T=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"springStrength",qT,De(t)),ze(t,"nextPageThreshold",JT,De(t)),t}return Le(t,e),t}(t)).prototype,"springStrength",[dw],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 8}}),JT=ke($T.prototype,"nextPageThreshold",[dw],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return 0}}),XT=$T))||XT),e._RF.pop(),e._RF.push({},"8e13do2xK5HJrQnhcoJ4zol","_UICenterOnSelect",void 0)
var fw,mw,_w,gw,yw,vw,bw=n.ccclass,Tw=(n.executeInEditMode,n.menu),ww=n.property
n.type,tw=bw("app/UICenterOnSelect"),iw=Tw("app/UICenterOnSelect"),nw=ww({displayName:"是否点击对象时自动触发位置调整"}),rw=ww({displayName:"对象自动滚动到离中心点的偏移位置"}),ow=ww({displayName:"延迟响应，处理点击缩放优先"
}),tw(sw=iw((lw=ke((aw=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"isAutoTrigger",lw,De(t)),ze(t,"centerOffset",hw,De(t)),ze(t,"delay",cw,De(t)),t}return Le(t,e),t
}(t)).prototype,"isAutoTrigger",[nw],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!0}}),hw=ke(aw.prototype,"centerOffset",[rw],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return 0}}),cw=ke(aw.prototype,"delay",[ow],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),
sw=aw))||sw),e._RF.pop(),e._RF.push({},"580a4BAlMZNUJbukL0AxSU3","_UIDragScrollView",void 0)
var Iw,Sw,Rw,xw,Cw,Ow,Pw,Lw,Ew,Dw,Aw,Fw,zw,kw,Bw,Nw,Mw,Hw,Gw,Vw,Uw,Ww,jw,Yw,Xw,$w=n.ccclass,qw=(n.executeInEditMode,n.menu),Jw=(n.property,n.type)
fw=$w("app/UIDragScrollView"),mw=qw("app/UIDragScrollView"),_w=Jw(ym),fw(gw=mw((vw=ke((yw=function(e){function t(){
for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"scrollView",vw,De(t)),t}return Le(t,e),t}(t)).prototype,"scrollView",[_w],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return null}}),gw=yw))||gw),e._RF.pop(),e._RF.push({},"05882WZhzdLoK7IONT5QYoX","_UIEffect",void 0),function(e){e[e.empty=0]="empty",e[e.other=1]="other",
e[e.skill=2]="skill",e[e.skill_movie=3]="skill_movie",e[e.uiEffect=4]="uiEffect",e[e.common=5]="common"}(Xw||(Xw={})),o(Xw)
var Zw,Kw=["","other","skill","skill/movie","uiEffect","commonEffect"],Qw=n.ccclass,eI=n.property,tI=n.executeInEditMode,iI=n.type,nI=n.menu
Iw=Qw("app/UIEffect"),Sw=nI("app/UIEffect"),Rw=iI(Xw),xw=eI({type:Xw,tooltip:'路径前缀，可配置 ["", "other", "skill"]'}),Cw=eI({tooltip:"可配置prefix，path直接填上特效id即可"}),Ow=eI({
tooltip:"=0 无限循环 >0 循环次数"}),Pw=eI({tooltip:"播放结束remove"}),Lw=eI({tooltip:"播放结束回收"}),Ew=eI({tooltip:"播放结束后隐藏"}),Dw=eI({tooltip:"帧频"}),Aw=eI({tooltip:"特效方向，通常是90"}),Fw=eI({
tooltip:"特效特殊配置，如 'front_90'"}),Iw(zw=tI(zw=Sw(((Yw=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"_prefix",Bw,De(t)),ze(t,"_path",Nw,De(t)),ze(t,"repeat",Mw,De(t)),ze(t,"playOverRemove",Hw,De(t)),
ze(t,"playOverRecover",Gw,De(t)),ze(t,"playOverDeactive",Vw,De(t)),ze(t,"_frameRate",Uw,De(t)),ze(t,"_dir",Ww,De(t)),ze(t,"_actName",jw,De(t)),t.playOverHandler=null,t._vmc=null,t}
Le(t,e)
var n=t.prototype
return n.onLoad=function(){"boolean"==typeof this.repeat&&(this.repeat=this.repeat?0:1)},n.onEnable=function(){this._path&&this._updateVMC()},n.onDisable=function(){
if(REAL_EDITOR)for(var e=this.node.children,t=e.length-1;t>=0;t--){var n=e[t]
0!=(n._objFlags&i.Flags.AllHideMasks)&&n.destroy()}},n.play=function(e){null!=e&&(this.repeat=e),this._vmc&&this._vmc.play(e)},n.replay=function(e){null!=e&&(this.repeat=e),
this._vmc&&this._vmc.replay(e)},n._updateVMC=function(){if(this._path){var e,t=this._vmc
t||(t=Ff.createVMC(yf.SELF,!0),REAL_EDITOR&&(t.node._objFlags|=i.Flags.DontSave,t.node._objFlags|=i.Flags.EditorOnly,t.node._objFlags|=i.Flags.AllHideMasks),
t.node.on("COMPLETE",this.onVMCComplete,this),this.node.addChild(t.node),this._vmc=t),t.node.parent||this.node.addChild(t.node),
(e=this._prefix>0?Kw[this._prefix]+"/"+this._path:this._path).includes(".json")||(e+=".json")
var n=this._frameRate>0?this._frameRate:8
t.customInterval=1e3/n
var r=0
GAMEPLAY&&(r="boolean"==typeof this.repeat?this.repeat?0:1:this.repeat)
var o=!REAL_EDITOR&&this.playOverRemove,s=!REAL_EDITOR&&this.playOverRecover
t.updatePose(e,this.dir,r,o,s,this.actName)}},n.onVMCComplete=function(){this._vmc&&this.playOverRecover&&(this._vmc.node.off("COMPLETE",this.onVMCComplete,this),this._vmc=null)
var e=this.playOverHandler
e&&(e.once&&(this.playOverHandler=null),e.run()),this.node.emit("COMPLETE"),this.playOverRecover?this.node.destroy():this.playOverRemove?this.node.removeFromParent():this.playOverDeactive&&this.node.SetActive(!1)
},n.namePrefixSet=function(e){this.path=e},n.widthSet=function(e){this.node.transform.width=e},n.heightSet=function(e){this.node.transform.height=e},Oe(t,[{key:"prefix",
get:function(){return this._prefix},set:function(e){e!=this._prefix&&(this._prefix=e,this.unschedule(this._updateVMC),this.scheduleOnce(this._updateVMC,0))}},{key:"path",
get:function(){return this._path},set:function(e){e!=this._path&&(this._path=e,this.unschedule(this._updateVMC),this.scheduleOnce(this._updateVMC,0))}},{key:"frameRate",
get:function(){return this._frameRate},set:function(e){e!=this._frameRate&&(this._frameRate=e,this._vmc&&(e<=0&&(e=8),this._vmc.customInterval=1e3/e))}},{key:"dir",get:function(){
return this._dir},set:function(e){e!=this._dir&&(this._dir=e,this.unschedule(this._updateVMC),this.scheduleOnce(this._updateVMC,0))}},{key:"actName",get:function(){
return this._actName},set:function(e){e!=this._actName&&(this._actName=e,this.unschedule(this._updateVMC),this.scheduleOnce(this._updateVMC,0))}},{key:"vmc",get:function(){
return this._vmc}}]),t}(t)).Prefix=Xw,Bw=ke((kw=Yw).prototype,"_prefix",[Rw],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return Xw.empty}}),
ke(kw.prototype,"prefix",[xw],Object.getOwnPropertyDescriptor(kw.prototype,"prefix"),kw.prototype),Nw=ke(kw.prototype,"_path",[eI],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return""}}),ke(kw.prototype,"path",[Cw],Object.getOwnPropertyDescriptor(kw.prototype,"path"),kw.prototype),Mw=ke(kw.prototype,"repeat",[Ow],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return 0}}),Hw=ke(kw.prototype,"playOverRemove",[Pw],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!0}}),
Gw=ke(kw.prototype,"playOverRecover",[Lw,eI],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!0}}),Vw=ke(kw.prototype,"playOverDeactive",[Ew],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),Uw=ke(kw.prototype,"_frameRate",[eI],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){
return 8}}),ke(kw.prototype,"frameRate",[Dw],Object.getOwnPropertyDescriptor(kw.prototype,"frameRate"),kw.prototype),Ww=ke(kw.prototype,"_dir",[eI],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return 90}}),ke(kw.prototype,"dir",[Aw],Object.getOwnPropertyDescriptor(kw.prototype,"dir"),kw.prototype),jw=ke(kw.prototype,"_actName",[eI],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return""}}),ke(kw.prototype,"actName",[Fw],Object.getOwnPropertyDescriptor(kw.prototype,"actName"),kw.prototype),
zw=kw))||zw)||zw),e._RF.pop(),e._RF.push({},"52beeJpTdFC4KzI0oKSm9UM","_UIInput",void 0)
var rI,oI,sI,aI,lI,hI,cI,uI,pI,dI,fI,mI,_I,gI,yI,vI,bI,TI,wI,II,SI,RI,xI,CI,OI,PI,LI,EI,DI,AI,FI,zI,kI,BI,NI,MI=n.ccclass,HI=n.executeInEditMode,GI=n.menu
n.property,n.type,MI("app/UIInput")(Zw=HI(Zw=GI("app/UIInput")(Zw=function(e){function t(){return e.apply(this,arguments)||this}Le(t,e)
var i=t.prototype
return i.SetInputFilter=function(){this.node.on("text-changed",this.OnTextFilter,this)},i.RemoveInputFilter=function(){this.node.off("text-changed",this.OnTextFilter,this)},
i.OnTextFilter=function(e){for(var t=e.string,i="",n=0;n<t.length;n++)13!=t.charCodeAt(n)&&(i+=t[n])
e.string=i},i.GetText=function(){return this.string},t}(we))||Zw)||Zw),e._RF.pop(),e._RF.push({},"8030eHcCjJGKJEwRuAazUNZ","_UILabel",void 0)
var VI,UI,WI,jI,YI,XI,$I,qI,JI,ZI,KI=n.ccclass,QI=(n.executeInEditMode,n.menu),eS=n.property
n.type,rI=KI("app/UILabel"),oI=QI("app/UILabel"),sI=eS({type:Uc}),aI=eS({type:Wc}),lI=eS({type:jc}),hI=eS({type:Yc}),cI=eS({visible:function(){return this.applyGradient}}),uI=eS({
visible:function(){return this.applyGradient}}),pI=eS({type:Xc}),dI=eS({visible:function(){return this.overLink}}),rI(fI=oI((_I=ke((mI=function(e){function t(){
for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"font",_I,De(t)),ze(t,"fontSize",gI,De(t)),ze(t,"color",yI,De(t)),ze(t,"text",vI,De(t)),ze(t,"modifier",bI,De(t)),
ze(t,"overflow",TI,De(t)),ze(t,"maxWidth",wI,De(t)),ze(t,"alignment",II,De(t)),ze(t,"keepCrispWhenShrunk",SI,De(t)),ze(t,"applyGradient",RI,De(t)),ze(t,"gradientTop",xI,De(t)),
ze(t,"gradientBottom",CI,De(t)),ze(t,"effectStyle",OI,De(t)),ze(t,"effectColor",PI,De(t)),ze(t,"effectDistance",LI,De(t)),ze(t,"useFloatSpacing",EI,De(t)),
ze(t,"floatSpacing",DI,De(t)),ze(t,"spacing",AI,De(t)),ze(t,"overLink",FI,De(t)),ze(t,"overLinkColor",zI,De(t)),ze(t,"multiplyColor",kI,De(t)),ze(t,"maxLines",BI,De(t)),
ze(t,"BBCode",NI,De(t)),t}return Le(t,e),t}(t)).prototype,"font",[eS],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return""}}),
gI=ke(mI.prototype,"fontSize",[eS],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 16}}),yI=ke(mI.prototype,"color",[eS],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return H.WHITE.clone()}}),vI=ke(mI.prototype,"text",[eS],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return""}}),
bI=ke(mI.prototype,"modifier",[sI],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return Uc.eNone}}),TI=ke(mI.prototype,"overflow",[aI],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return Wc.eShrinkContent}}),wI=ke(mI.prototype,"maxWidth",[eS],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){
return 0}}),II=ke(mI.prototype,"alignment",[lI],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return jc.eA_Automatic}}),
SI=ke(mI.prototype,"keepCrispWhenShrunk",[hI],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return Yc.eOnDesktop}}),RI=ke(mI.prototype,"applyGradient",[eS],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),xI=ke(mI.prototype,"gradientTop",[cI],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return H.WHITE.clone()}}),CI=ke(mI.prototype,"gradientBottom",[uI,eS],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){
return H.WHITE.clone()}}),OI=ke(mI.prototype,"effectStyle",[pI],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return Xc.eNone}}),
PI=ke(mI.prototype,"effectColor",[eS],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return new H(0,0,0,127)}}),LI=ke(mI.prototype,"effectDistance",[eS],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return new Y(1,1)}}),EI=ke(mI.prototype,"useFloatSpacing",[eS],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return!1}}),DI=ke(mI.prototype,"floatSpacing",[eS],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return new Y}}),
AI=ke(mI.prototype,"spacing",[eS],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return new Y}}),FI=ke(mI.prototype,"overLink",[eS],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return!1}}),zI=ke(mI.prototype,"overLinkColor",[dI],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){
return new H(255,216,2)}}),kI=ke(mI.prototype,"multiplyColor",[eS],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),
BI=ke(mI.prototype,"maxLines",[eS],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),NI=ke(mI.prototype,"BBCode",[eS],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return!1}}),fI=mI))||fI),e._RF.pop(),e._RF.push({},"b33c7BFt7JDcJeJ14UIA5Bt","_UIPanel",void 0)
var tS,iS,nS,rS,oS,sS,aS,lS,hS=n.ccclass,cS=(n.executeInEditMode,n.menu),uS=n.property,pS=n.type
VI=hS("app/UIPanel"),UI=cS("app/UIPanel"),WI=pS(Zc),VI(jI=UI((XI=ke((YI=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"alpha",XI,De(t)),ze(t,"clipping",$I,De(t)),ze(t,"depth",qI,De(t)),ze(t,"clipOffset",JI,De(t)),ze(t,"clipRange",ZI,De(t)),t}
return Le(t,e),t}(t)).prototype,"alpha",[uS],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 1}}),$I=ke(YI.prototype,"clipping",[WI],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return Zc.eNone}}),qI=ke(YI.prototype,"depth",[uS],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),
JI=ke(YI.prototype,"clipOffset",[uS],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return new Y}}),ZI=ke(YI.prototype,"clipRange",[uS],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return new N(0,0,300,200)}}),jI=YI))||jI),e._RF.pop(),e._RF.push({},"3ab09mPIMFBDqIRSxh8tvg3","_UITexture",void 0)
var dS,fS=n.ccclass,mS=(n.executeInEditMode,n.menu),_S=(n.property,n.type),gS=(tS=fS("app/UITexture"),iS=mS("app/UITexture"),nS=_S(x),rS=_S(x),tS(oS=iS((aS=ke((sS=function(e){
function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"mainTexture",aS,De(t)),ze(t,"alphaTexture",lS,De(t)),t}return Le(t,e),t.prototype.SetMainTextureByPhoto=function(e){},t
}(W)).prototype,"mainTexture",[nS],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),lS=ke(sS.prototype,"alphaTexture",[rS],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return null}}),oS=sS))||oS)||oS)
e._RF.pop(),e._RF.push({},"890b9Q5e1BAroTHcD1gVy9h","_UIPhotoTexture",void 0)
var yS,vS,bS,TS,wS,IS,SS,RS,xS,CS,OS,PS=n.ccclass,LS=(n.executeInEditMode,n.menu)
n.property,n.type,PS("app/UIPhotoTexture")(dS=LS("app/UIPhotoTexture")(dS=function(e){function t(){return e.apply(this,arguments)||this}return Le(t,e),t}(gS))||dS),e._RF.pop(),
e._RF.push({},"b4b7302x/5BpLY21PNuIY04","_UIPlaySound",void 0)
var ES,DS,AS,FS,zS,kS,BS,NS,MS,HS,GS,VS,US,WS,jS,YS,XS,$S,qS=n.ccclass,JS=(n.executeInEditMode,n.menu),ZS=n.property,KS=n.type
yS=qS("app/UIPlaySound"),vS=JS("app/UIPlaySound"),bS=KS(kc),TS=ZS({range:[0,1],slide:!0,step:.01}),wS=ZS({range:[0,2],slide:!0,step:.01}),yS(IS=vS((RS=ke((SS=function(e){
function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"audioClip",RS,De(t)),ze(t,"trigger",xS,De(t)),ze(t,"volume",CS,De(t)),ze(t,"pitch",OS,De(t)),t}return Le(t,e),t
}(t)).prototype,"audioClip",[ZS],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return""}}),xS=ke(SS.prototype,"trigger",[bS],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return kc.eOnClick}}),CS=ke(SS.prototype,"volume",[TS],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 1}}),
OS=ke(SS.prototype,"pitch",[wS],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 1}}),IS=SS))||IS),e._RF.pop(),
e._RF.push({},"b8003fA4GhN6IxdaiozS9yb","_UIPlayTween",void 0)
var QS,eR,tR,iR,nR,rR,oR,sR,aR,lR,hR,cR,uR,pR,dR,fR,mR,_R,gR,yR,vR,bR,TR=n.ccclass,wR=(n.executeInEditMode,n.menu),IR=n.property,SR=n.type
ES=TR("app/UIPlayTween"),DS=wR("app/UIPlayTween"),AS=SR(l),FS=SR(Nc),zS=SR(Mc),kS=IR({type:Hc,displayName:"If target is disabled"}),BS=IR({type:Gc,displayName:"On activation"}),
NS=IR({type:Vc,displayName:"When finished"}),ES(MS=DS((GS=ke((HS=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"tweenTarget",GS,De(t)),ze(t,"includeChildren",VS,De(t)),ze(t,"tweenGroup",US,De(t)),ze(t,"trigger",WS,De(t)),
ze(t,"playDirection",jS,De(t)),ze(t,"ifDisabledOnPlay",YS,De(t)),ze(t,"resetOnPlay",XS,De(t)),ze(t,"disableWhenFinished",$S,De(t)),t}return Le(t,e),t
}(t)).prototype,"tweenTarget",[AS],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),VS=ke(HS.prototype,"includeChildren",[IR],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return!1}}),US=ke(HS.prototype,"tweenGroup",[IR],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),
WS=ke(HS.prototype,"trigger",[FS],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return Nc.eOnClick}}),jS=ke(HS.prototype,"playDirection",[zS],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return Mc.eForward}}),YS=ke(HS.prototype,"ifDisabledOnPlay",[kS],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){
return Hc.eDoNothing}}),XS=ke(HS.prototype,"resetOnPlay",[BS],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return Gc.ContinueFromCurrent}}),
$S=ke(HS.prototype,"disableWhenFinished",[NS],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return Vc.eDoNotDisable}}),MS=HS))||MS),e._RF.pop(),
e._RF.push({},"64d35GEhPxHP401Rw0THmLg","_UISprite",void 0)
var RR,xR,CR,OR,PR,LR,ER,DR,AR,FR,zR,kR,BR,NR,MR,HR,GR,VR,UR,WR=n.ccclass,jR=(n.executeInEditMode,n.menu),YR=n.property,XR=n.type
QS=WR("app/UISprite"),eR=jR("app/UISprite"),tR=YR({type:x}),iR=XR($c),nR=XR(qc),rR=XR(Jc),oR=YR({visible:function(){return this.applyGradient}}),sR=YR({visible:function(){
return this.applyGradient}}),QS(aR=eR((hR=ke((lR=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"atlasName",hR,De(t)),ze(t,"spriteFrame",cR,De(t)),ze(t,"type",uR,De(t)),ze(t,"color",pR,De(t)),ze(t,"grayscale",dR,De(t)),
ze(t,"flip",fR,De(t)),ze(t,"fillAmount",mR,De(t)),ze(t,"fillDirection",_R,De(t)),ze(t,"fillCenter",gR,De(t)),ze(t,"applyGradient",yR,De(t)),ze(t,"gradientTop",vR,De(t)),
ze(t,"gradientBottom",bR,De(t)),t}return Le(t,e),t}(t)).prototype,"atlasName",[YR],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return""}}),
cR=ke(lR.prototype,"spriteFrame",[tR],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),uR=ke(lR.prototype,"type",[iR],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return $c.eSimple}}),pR=ke(lR.prototype,"color",[YR],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){
return H.WHITE.clone()}}),dR=ke(lR.prototype,"grayscale",[YR],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),fR=ke(lR.prototype,"flip",[nR],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return qc.eNothing}}),mR=ke(lR.prototype,"fillAmount",[YR],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return 0}}),_R=ke(lR.prototype,"fillDirection",[rR],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return Jc.eRadial360}}),
gR=ke(lR.prototype,"fillCenter",[YR],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),yR=ke(lR.prototype,"applyGradient",[YR],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return!1}}),vR=ke(lR.prototype,"gradientTop",[oR],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){
return H.WHITE.clone()}}),bR=ke(lR.prototype,"gradientBottom",[sR],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return H.WHITE.clone()}}),aR=lR))||aR),
e._RF.pop(),e._RF.push({},"3d4b3HaIzJCu4ya0eQHGo+f","_UISpriteAnimation",void 0)
var $R,qR,JR,ZR,KR,QR,ex,tx,ix,nx,rx,ox,sx=n.ccclass,ax=n.executeInEditMode,lx=n.menu,hx=n.property
n.type,RR=sx("app/UISpriteAnimation"),xR=lx("app/UISpriteAnimation"),CR=hx({displayName:"手动设置前缀编号"}),OR=hx({displayName:"图集前缀名",visible:function(){return this.useClientData}}),
PR=hx({displayName:"起始编号",visible:function(){return this.useClientData}}),LR=hx({displayName:"结束编号",visible:function(){return this.useClientData}}),ER=hx({displayName:"编号字符长度",
visible:function(){return this.useClientData}}),RR(DR=ax(DR=xR((FR=ke((AR=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"frameIndex",FR,De(t)),ze(t,"frameRate",zR,De(t)),ze(t,"namePrefix",kR,De(t)),ze(t,"loop",BR,De(t)),ze(t,"pixelSnap",NR,De(t)),
ze(t,"useClientData",MR,De(t)),ze(t,"clientSpritePrefix",HR,De(t)),ze(t,"clientLoopStartIndex",GR,De(t)),ze(t,"clientLoopEndIndex",VR,De(t)),ze(t,"clientLoopIndexDigit",UR,De(t)),t
}Le(t,e)
var i=t.prototype
return i.ResetToBeginning=function(){},i.Play=function(){},i.Pause=function(){},t}(t)).prototype,"frameIndex",[hx],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return 0}}),zR=ke(AR.prototype,"frameRate",[hx],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 30}}),
kR=ke(AR.prototype,"namePrefix",[hx],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return""}}),BR=ke(AR.prototype,"loop",[hx],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return!0}}),NR=ke(AR.prototype,"pixelSnap",[hx],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!0}}),
MR=ke(AR.prototype,"useClientData",[CR],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),HR=ke(AR.prototype,"clientSpritePrefix",[OR],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return""}}),GR=ke(AR.prototype,"clientLoopStartIndex",[PR],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){
return 0}}),VR=ke(AR.prototype,"clientLoopEndIndex",[LR],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 9}}),
UR=ke(AR.prototype,"clientLoopIndexDigit",[ER],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 4}}),DR=AR))||DR)||DR),e._RF.pop(),
e._RF.push({},"36f78GlbMFDgIG/E7UGNlHF","_UIToggle",void 0)
var cx,ux,px,dx,fx,mx,_x,gx,yx,vx,bx,Tx,wx,Ix,Sx,Rx,xx,Cx,Ox,Px=n.ccclass,Lx=(n.executeInEditMode,n.menu),Ex=n.property
n.type,$R=Px("app/UIToggle"),qR=Lx("app/UIToggle"),JR=Ex({type:l,group:"State Transition"}),ZR=Ex({group:"State Transition"}),KR=Ex({type:Ac,group:"State Transition"}),
$R(QR=qR((tx=ke((ex=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"group",tx,De(t)),ze(t,"startsActive",ix,De(t)),ze(t,"activeSprite",nx,De(t)),ze(t,"invertSpriteState",rx,De(t)),
ze(t,"transition",ox,De(t)),t}Le(t,e)
var i=t.prototype
return i.SetValue=function(e){this.activeSprite&&(this.activeSprite.active=e)},i.GetValue=function(){return this.activeSprite.active},i.AddEventHandler=function(e){
this.node.on(c.TOUCH_END,e)},i.RemoveEventHandler=function(e){this.node.off(c.TOUCH_END,e)},t}(t)).prototype,"group",[Ex],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return 0}}),ix=ke(ex.prototype,"startsActive",[Ex],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),
nx=ke(ex.prototype,"activeSprite",[JR],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),rx=ke(ex.prototype,"invertSpriteState",[ZR],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),ox=ke(ex.prototype,"transition",[KR],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){
return Ac.Smooth}}),QR=ex))||QR),e._RF.pop(),e._RF.push({},"2527fQgixJJCLjpnu+bDkaF","_UIWidget",void 0)
var Dx,Ax,Fx,zx,kx,Bx,Nx,Mx,Hx,Gx,Vx,Ux=n.ccclass,Wx=(n.executeInEditMode,n.menu),jx=n.property,Yx=n.type
cx=Ux("app/UIWidget"),ux=Wx("app/UIWidget"),px=jx({displayName:"是否保持widget框位置",editorOnly:!0}),dx=jx({displayName:"是否保持子节点位置",editorOnly:!0}),fx=Yx(Tc),mx=Yx(Tc),_x=Yx(Sc),
cx(gx=ux((vx=ke((yx=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"saveWidgetPosWhenSetPivot",vx,De(t)),ze(t,"saveChildPosWhenSetPivot",bx,De(t)),ze(t,"_pivot",Tx,De(t)),ze(t,"_depth",wx,De(t)),
ze(t,"size",Ix,De(t)),ze(t,"aspect",Sx,De(t)),ze(t,"keepAspectRatio",Rx,De(t)),ze(t,"mouseThrough",xx,De(t)),ze(t,"calculateBound",Cx,De(t)),ze(t,"collider",Ox,De(t)),t}
return Le(t,e),Oe(t,[{key:"pivot",get:function(){return this._pivot},set:function(e){this._pivot=e}},{key:"depth",get:function(){return this._depth},set:function(e){this._depth=e}
}]),t}(t)).prototype,"saveWidgetPosWhenSetPivot",[px],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),
bx=ke(yx.prototype,"saveChildPosWhenSetPivot",[dx],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!0}}),Tx=ke(yx.prototype,"_pivot",[fx],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return Tc.eCenter}}),ke(yx.prototype,"pivot",[mx],Object.getOwnPropertyDescriptor(yx.prototype,"pivot"),yx.prototype),
wx=ke(yx.prototype,"_depth",[jx],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),
ke(yx.prototype,"depth",[jx],Object.getOwnPropertyDescriptor(yx.prototype,"depth"),yx.prototype),Ix=ke(yx.prototype,"size",[jx],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return new ne(0,0)}}),Sx=ke(yx.prototype,"aspect",[jx],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 1}}),
Rx=ke(yx.prototype,"keepAspectRatio",[_x],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return Sc.eFree}}),xx=ke(yx.prototype,"mouseThrough",[jx],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),Cx=ke(yx.prototype,"calculateBound",[jx],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return!0}}),Ox=ke(yx.prototype,"collider",[jx],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),gx=yx))||gx),e._RF.pop(),
e._RF.push({},"92ce000ENxBpaLSzhJi/NXI","_USprite",void 0)
var Xx,$x=n.ccclass,qx=n.executeInEditMode,Jx=n.menu,Zx=n.property,Kx=n.type
!function(e){e[e.eNothing=0]="eNothing",e[e.eHorizontally=1]="eHorizontally",e[e.eVertically=2]="eVertically",e[e.eBoth=3]="eBoth"}(Xx||(Xx={})),o(Xx)
var Qx,eC,tC,iC,nC,rC,oC,sC,aC,lC,hC,cC,uC,pC,dC,fC,mC,_C,gC,yC=Object.getOwnPropertyDescriptor(W.prototype,"spriteFrame").set
Dx=$x("app/USprite"),Ax=Jx("app/USprite"),Fx=Kx(Xx),zx=Zx({type:x,serializable:!1,override:!0}),kx=Zx({type:x,override:!0}),Bx=Zx({type:x,override:!0}),
Dx(Nx=qx(Nx=Ax((Hx=ke((Mx=function(e){function t(){for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"_flip",Hx,De(t)),ze(t,"_spriteFrame",Gx,De(t)),ze(t,"_realSpriteFrame",Vx,De(t)),t}Le(t,e)
var i=t.prototype
return i.onLoad=function(){this._realSpriteFrame&&this._refreshSpriteFrame()},i._refreshSpriteFrame=function(){var e=this._flip,t=null
this._realSpriteFrame&&(t=e===Xx.eNothing?this._realSpriteFrame:this._realSpriteFrame.clone()),
t&&(e===Xx.eHorizontally?t.flipUVX=!t.flipUVX:e===Xx.eVertically?t.flipUVY=!t.flipUVY:e===Xx.eBoth&&(t.flipUVX=!t.flipUVX,t.flipUVY=!t.flipUVY)),
REAL_EDITOR?vn(this,t):yC.call(this,t)},Oe(t,[{key:"flip",get:function(){return this._flip},set:function(e){e!=this._flip&&(this._flip=e,this._refreshSpriteFrame())}},{
key:"spriteFrame",get:function(){return this._realSpriteFrame},set:function(e){this._realSpriteFrame!==e&&(this._realSpriteFrame=e,this._refreshSpriteFrame())}}]),t
}(W)).prototype,"_flip",[Zx],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return Xx.eNothing}}),
ke(Mx.prototype,"flip",[Fx],Object.getOwnPropertyDescriptor(Mx.prototype,"flip"),Mx.prototype),Gx=ke(Mx.prototype,"_spriteFrame",[zx],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return null}}),Vx=ke(Mx.prototype,"_realSpriteFrame",[kx],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),
ke(Mx.prototype,"spriteFrame",[Bx],Object.getOwnPropertyDescriptor(Mx.prototype,"spriteFrame"),Mx.prototype),Nx=Mx))||Nx)||Nx),e._RF.pop(),
e._RF.push({},"0df26RLdwpOMrhVQiN6J6by","_cloneBinderProto",void 0),e._RF.pop(),e._RF.push({},"3f46bZE5XlO/4hinx6XW59V","_super-scrollview",void 0)
var vC,bC,TC,wC,IC,SC,RC,xC,CC,OC,PC,LC,EC,DC,AC,FC,zC,kC,BC,NC,MC,HC,GC,VC,UC,WC,jC,YC,XC,$C,qC,JC,ZC,KC,QC,eO,tO,iO,nO,rO,oO,sO,aO,lO,hO,cO,uO,pO,dO,fO,mO,_O,gO,yO,vO,bO,TO,wO,IO,SO,RO,xO,CO,OO,PO,LO,EO,DO,AO,FO,zO=n.ccclass,kO=n.property,BO=n.menu,NO=1e-4,MO=new Y,HO=(Qx=zO("app/SuperScrollview"),
eC=BO("app/SuperScrollview"),tC=kO({tooltip:"注意！向上传递事件只会发送当前滑动相反方向,如果开启horizontal则会发送vertical事件。如果开启vertical则会发送horizontal事件。同时开启horizontal和vertical 不会发送任何事件"}),iC=kO({
displayName:"顶部偏移量",tooltip:"下拉时超过此偏移会发送下拉事件",visible:function(){return this.pullRefresh}}),nC=kO({displayName:"满足触发Header的倍数",visible:function(){return this.pullRefresh}}),rC=kO({
displayName:"底部偏移量",tooltip:"上拉时超过此偏移会发送上拉事件",visible:function(){return this.pullRefresh}}),oC=kO({displayName:"满足触发Footer的倍数",visible:function(){return this.pullRefresh}}),sC=kO({
type:fe,visible:function(){return this.pullRefresh}}),aC=kO({type:fe,visible:function(){return this.pullRefresh}}),Qx(lC=eC((cC=ke((hC=function(e){function t(){
for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return(t=e.call.apply(e,[this].concat(n))||this).direction=2,ze(t,"isTransmitEvent",cC,De(t)),ze(t,"pullRefresh",uC,De(t)),ze(t,"headerOutOffset",pC,De(t)),
ze(t,"headerMultiple",dC,De(t)),ze(t,"footerOutOffset",fC,De(t)),ze(t,"footerMultiple",mC,De(t)),ze(t,"headerEvents",_C,De(t)),ze(t,"footerEvents",gC,De(t)),t.prevLocation=new Y,
t.location=new Y,t._touchBeganPosition=new Y,t._touchEndPosition=new Y,t.isMoveHeader=!1,t.isMoveFooter=!1,t.isLockHeader=!1,t.isLockFooter=!1,t.headerProgress=0,
t.footerProgress=0,t.isCustomScroll=!1,t.canTouchMove=!0,t.isCallSoonFinish=!1,t}Le(t,e)
var i=t.prototype
return i.onLoad=function(){this.layout&&this.layout.autoCenter&&(this.brake=.7)},i.onEnable=function(){e.prototype.onEnable.call(this),
this.node.on(Ie.EventType.SCROLL_ENG_WITH_THRESHOLD,this.dispatchPageTurningEvent,this)},i.onDisable=function(){e.prototype.onDisable.call(this),
this.node.off(Ie.EventType.SCROLL_ENG_WITH_THRESHOLD,this.dispatchPageTurningEvent,this)},i.getPages=function(){return new Array(this.layout.itemTotal)},
i._getContentTopBoundary=function(){return this._content?0==this.layout.isOfTopBoundary?this._topBoundary:this.layout.isOfTopBoundary:-1},i._getContentBottomBoundary=function(){
return this._content?0==this.layout.isOfButtomBoundary?this._bottomBoundary:this.layout.isOfButtomBoundary:-1},i._getContentLeftBoundary=function(){
return this._content?0==this.layout.isOfLeftBoundary?this._leftBoundary:this.layout.isOfLeftBoundary:-1},i._getContentRightBoundary=function(){
return this._content?0==this.layout.isOfRightBoundary?this._rightBoundary:this.layout.isOfRightBoundary:-1},i._onTouchBegan=function(e,t){},i._onTouchMoved=function(t,i){var n,r
if(this.isCallSoonFinish=!1,this.isCustomScroll=!1,this.canTouchMove){if(this.isTransmitEvent){if(2==this.direction){
var o=t.getStartLocation(),s=t.getLocation(),a=Math.abs(o.x-s.x),h=Math.abs(o.y-s.y)
a>h?this.direction=0:h>a&&(this.direction=1)}if(this.vertical&&0===this.direction||this.horizontal&&1==this.direction)return void this.transmitEvent(t,l.EventType.TOUCH_MOVE)}
if(this.prevLocation=null==(n=t.touch)?void 0:n.getPreviousLocation(),this.location=null==(r=t.touch)?void 0:r.getLocation(),e.prototype._onTouchMoved.call(this,t,i),
this.pullRefresh){var c=this._getHowMuchOutOfBoundary(),u=this.vertical?c.y:-c.x
u>0&&!this.isLockHeader&&!this.isLockFooter?(this.headerProgress=u<NO?0:u/this.headerOutOffset,this.isMoveHeader=this.headerProgress>=this.headerMultiple,
fe.emitEvents(this.headerEvents,this,{action:!1,progress:this.headerProgress,stage:this.isMoveHeader?"wait":"touch"}),fe.emitEvents(this.footerEvents,this,{action:!1,progress:0,
stage:"release"})):u<0&&!this.isLockHeader&&!this.isLockFooter?(this.footerProgress=-u<NO?0:-u/this.footerOutOffset,this.isMoveFooter=this.footerProgress>=this.footerMultiple,
fe.emitEvents(this.footerEvents,this,{action:!1,progress:this.footerProgress,stage:this.isMoveFooter?"wait":"touch"}),fe.emitEvents(this.headerEvents,this,{action:!1,progress:0,
stage:"release"})):0!=u||this.isLockHeader||this.isLockFooter||this.clearProgress()}}},i._onTouchEnded=function(t,i){this.isCallSoonFinish=!1,this.isCustomScroll=!1,
this.canTouchMove&&(this.layout&&this.layout.isPageView&&(t.touch.getUILocation(MO),Y.set(this._touchEndPosition,MO.x,MO.y)),e.prototype._onTouchEnded.call(this,t,i),
this.isTransmitEvent&&this.transmitEvent(t,l.EventType.TOUCH_END))},i._onTouchCancelled=function(e,t){},i.scrollToAny=function(e,t,i){void 0===i&&(i=!0),this.isCustomScroll=!0,
t?this._startAutoScroll(e,t,i,!0):this._moveContent(e)},i.release=function(){this.isMoveHeader=!1,this.isMoveFooter=!1,
(this.isLockHeader||this.isLockFooter)&&(this.vertical&&this.isLockHeader&&(this._topBoundary+=this.headerOutOffset),
this.vertical&&this.isLockFooter&&(this._bottomBoundary-=this.footerOutOffset),this.horizontal&&this.isLockHeader&&(this._leftBoundary-=this.headerOutOffset),
this.horizontal&&this.isLockFooter&&(this._rightBoundary+=this.footerOutOffset),this.clearProgress(),this.isLockHeader=!1,this.isLockFooter=!1,this.startAutoScroll())},
i.startAutoScroll=function(){this._autoScrolling=!0,this._outOfBoundaryAmountDirty=!0},i._startAutoScroll=function(t,i,n,r){if(void 0===r&&(r=!1),
this.pullRefresh&&(this.isMoveHeader&&!this.isLockHeader?(this.vertical&&(this._topBoundary-=this.headerOutOffset,t.y-=this.headerOutOffset),
this.horizontal&&(this._leftBoundary+=this.headerOutOffset,t.x+=this.headerOutOffset),this.isLockHeader=!0,fe.emitEvents(this.headerEvents,this,{action:!0,
progress:this.headerProgress,stage:"lock"})):this.isMoveFooter&&!this.isLockFooter&&(this.vertical&&(this._bottomBoundary+=this.footerOutOffset,t.y+=this.footerOutOffset),
this.horizontal&&(this._rightBoundary-=this.footerOutOffset,t.x-=this.footerOutOffset),this.isLockFooter=!0,fe.emitEvents(this.footerEvents,this,{action:!0,
progress:this.footerProgress,stage:"lock"}))),e.prototype._startAutoScroll.call(this,t,i,n),!r&&this.layout&&this.layout.autoCenter){var o=this._calculateTouchMoveVelocity()
this.isQuicklyScrollable(o)||this.soonFinish()}},i._updateScrollBar=function(t){if(e.prototype._updateScrollBar.call(this,new Y(t.x,t.y)),
!this._autoScrollBraking&&this._autoScrolling&&this.pullRefresh){var i=this.vertical?t.y:-t.x
if(i>0){var n=i<NO?0:i/this.headerOutOffset
this.isLockHeader?(this.headerProgress=1==this.headerProgress?this.headerProgress:Math.max(n,1),fe.emitEvents(this.headerEvents,this,{action:!1,progress:this.headerProgress,
stage:"lock"})):(this.headerProgress=n<this.headerProgress?n:this.headerProgress,fe.emitEvents(this.headerEvents,this,{action:!1,progress:this.headerProgress,stage:"release"}))
}else if(i<0){var r=-i<NO?0:-i/this.footerOutOffset
this.isLockFooter?(this.footerProgress=1==this.footerProgress?this.footerProgress:Math.max(r,1),fe.emitEvents(this.footerEvents,this,{action:!1,progress:this.footerProgress,
stage:"lock"})):(this.footerProgress=r<this.footerProgress?r:this.footerProgress,fe.emitEvents(this.footerEvents,this,{action:!1,progress:this.footerProgress,stage:"release"}))
}else 0==i&&(this.isLockHeader||this.isLockFooter||this.clearProgress())}},i.clearProgress=function(){fe.emitEvents(this.headerEvents,this,{action:!1,progress:0,stage:"release"}),
fe.emitEvents(this.footerEvents,this,{action:!1,progress:0,stage:"release"})},i.dispatchPageTurningEvent=function(){
null!=this.layout&&this.layout.lastPageIndex!==this.layout.currPageIndex&&(this.layout.lastPageIndex=this.layout.currPageIndex,
fe.emitEvents(this.layout.pageEvents,this,Ie.EventType.PAGE_TURNING),this.node.emit(Ie.EventType.PAGE_TURNING,this))},i._handleReleaseLogic=function(t){
this.layout&&this.layout.isPageView?(this._autoScrollToPage(),this._scrolling&&(this._scrolling=!1,
this._autoScrolling||this._dispatchEvent(ue.EventType.SCROLL_ENDED))):e.prototype._handleReleaseLogic.call(this,t)},i._autoScrollToPage=function(){
if(this._startBounceBackIfNeeded()){var e=this._getHowMuchOutOfBoundary()
this._clampDelta(e),(e.x>0||e.y<0)&&(this.layout.horizontal?this.layout.horizontalAxisDirection==KO.HorizontalAxisDirection.LEFT_TO_RIGHT?this.layout.currPageIndex=0===this.layout.itemTotal?0:this.layout.itemTotal-1:this.layout.currPageIndex=0:this.layout.verticalAxisDirection==KO.VerticalAxisDirection.TOP_TO_BOTTOM?this.layout.currPageIndex=0===this.layout.itemTotal?0:this.layout.itemTotal-1:this.layout.currPageIndex=0),
(e.x<0||e.y>0)&&(this.layout.horizontal?this.layout.horizontalAxisDirection==KO.HorizontalAxisDirection.LEFT_TO_RIGHT?this.layout.currPageIndex=0:this.layout.currPageIndex=0===this.layout.itemTotal?0:this.layout.itemTotal-1:this.layout.verticalAxisDirection==KO.VerticalAxisDirection.TOP_TO_BOTTOM?this.layout.currPageIndex=0:this.layout.currPageIndex=0===this.layout.itemTotal?0:this.layout.itemTotal-1),
this.layout.indicator&&this.layout.indicator._changedState()}else{var t=new Y
Y.subtract(t,this._touchBeganPosition,this._touchEndPosition)
var i=this.layout.currPageIndex,n=i+this.getDragDirection(t),r=this.layout.pageTurningSpeed*Math.abs(i-n)
if(this.layout.footerLoop&&n>=this.layout.itemTotal&&(n=0),this.layout.headerLoop&&n<0&&(n=this.layout.itemTotal-1),n<this.layout.itemTotal){
if(this.isScrollable(t,i,n))return void this.scrollToPage(n,r)
var o=this._calculateTouchMoveVelocity()
if(this.isQuicklyScrollable(o))return void this.scrollToPage(n,r)}this.scrollToPage(i,r)}},i.savePageIndex=function(e){
return!(e<0||e>=this.layout.itemTotal||(this.layout.currPageIndex=e,this.layout.indicator&&this.layout.indicator._changedState(),0))},i.scrollToPage=function(e,t){
void 0===t&&(t=.3),e<0||e>=this.layout.itemTotal||this.savePageIndex(e)&&this.layout.scrollToIndex(e,t)},i.isQuicklyScrollable=function(e){if(this.horizontal){
if(Math.abs(e.x)>this.layout.autoPageTurningThreshold)return!0}else if(this.vertical&&Math.abs(e.y)>this.layout.autoPageTurningThreshold)return!0
return!1},i.getDragDirection=function(e){
return this.horizontal?0===e.x?0:this.layout.horizontalAxisDirection==KO.HorizontalAxisDirection.LEFT_TO_RIGHT?e.x>0?this.layout.groupItemTotal:-this.layout.groupItemTotal:e.x<0?this.layout.groupItemTotal:-this.layout.groupItemTotal:0===e.y?0:this.layout.verticalAxisDirection==KO.VerticalAxisDirection.TOP_TO_BOTTOM?e.y<0?this.layout.groupItemTotal:-this.layout.groupItemTotal:e.y>0?this.layout.groupItemTotal:-this.layout.groupItemTotal
},i.isScrollable=function(e,t,i){var n=this.view
return!!n&&(this.horizontal?Math.abs(e.x)>=n.width*this.layout.scrollThreshold:!!this.vertical&&Math.abs(e.y)>=n.height*this.layout.scrollThreshold)},i.transmitEvent=function(e,t){
var i=new Se(e.getTouches(),e.bubbles,null)
i.type=t,i.touch=e.touch,e.target.parent.dispatchEvent(i)},i.soonFinish=function(){this.isCallSoonFinish=!0},i._processAutoScrolling=function(e){
var t=this._isNecessaryAutoScrollBrake(),i=t?.015:1
this._autoScrollAccumulatedTime+=e*(1/i)
var n,r=Math.min(1,this._autoScrollAccumulatedTime/this._autoScrollTotalTime)
this._autoScrollAttenuate&&(n=r,r=(n-=1)*n*n*n*n+1)
var o=this._autoScrollTargetDelta.clone()
o.multiplyScalar(r)
var s=this._autoScrollStartPosition.clone()
s.add(o)
var a=Math.abs(r-1)<=NO
if(Math.abs(r-1)<=this.getScrollEndedEventTiming()&&!this._isScrollEndedWithThresholdEventFired&&(this._dispatchEvent(ue.EventType.SCROLL_ENG_WITH_THRESHOLD),
this._isScrollEndedWithThresholdEventFired=!0),this.elastic){var l=s.clone()
l.subtract(this._autoScrollBrakingStartPosition),t&&l.multiplyScalar(i),s.set(this._autoScrollBrakingStartPosition),s.add(l)}else{var h=s.clone()
h.subtract(this.getContentPosition())
var c=this._getHowMuchOutOfBoundary(h)
c.equals(z.ZERO,NO)||(s.add(c),a=!0)}
a&&(this._autoScrolling=!1),this.layout&&this.layout.autoCenter&&!this.isCallSoonFinish&&!this.isCustomScroll&&(this._autoScrollTotalTime<2||r>=.8)&&this.soonFinish()
var u=s.clone()
u.subtract(this.getContentPosition()),this._clampDelta(u),this._moveContent(u,a),this._dispatchEvent(ue.EventType.SCROLLING),this._autoScrolling||(this._isBouncing=!1,
this._scrolling=!1,this._dispatchEvent(ue.EventType.SCROLL_ENDED))},Oe(t,[{key:"autoScrolling",set:function(e){this._autoScrolling=e}},{key:"layout",get:function(){var e
return this._layout||(this._layout=null==(e=this.content)?void 0:e.getComponent(KO)),this._layout}},{key:"curPageIdx",get:function(){return this.layout.currPageIndex}}]),t
}(ue)).prototype,"isTransmitEvent",[tC],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),uC=ke(hC.prototype,"pullRefresh",[kO],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return!1}}),pC=ke(hC.prototype,"headerOutOffset",[iC],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 200}
}),dC=ke(hC.prototype,"headerMultiple",[nC],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 2}}),fC=ke(hC.prototype,"footerOutOffset",[rC],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 200}}),mC=ke(hC.prototype,"footerMultiple",[oC],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return 2}}),_C=ke(hC.prototype,"headerEvents",[sC],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return[]}}),
gC=ke(hC.prototype,"footerEvents",[aC],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return[]}}),lC=hC))||lC)||lC)
e._RF.pop(),e._RF.push({},"011b5XZZMRGqYBmbn4NRMqZ","_super-layout",void 0)
var GO,VO,UO,WO=n.ccclass,jO=n.property,YO=n.requireComponent,XO=n.menu,$O=1e-5
!function(e){e[e.HORIZONTAL=0]="HORIZONTAL",e[e.VERTICAL=1]="VERTICAL"}(GO||(GO={})),o(GO),function(e){e[e.TOP_TO_BOTTOM=0]="TOP_TO_BOTTOM",e[e.BOTTOM_TO_TOP=1]="BOTTOM_TO_TOP"
}(VO||(VO={})),o(VO),function(e){e[e.LEFT_TO_RIGHT=0]="LEFT_TO_RIGHT",e[e.RIGHT_TO_LEFT=1]="RIGHT_TO_LEFT"}(UO||(UO={})),o(UO)
var qO,JO,ZO
!function(e){e[e.TOP=0]="TOP",e[e.BOTTOM=1]="BOTTOM"}(qO||(qO={})),o(qO),function(e){e[e.LEFT=0]="LEFT",e[e.RIGHT=1]="RIGHT"}(JO||(JO={})),o(JO),function(e){e[e.NODE=1]="NODE",
e[e.PREFAB=2]="PREFAB"}(ZO||(ZO={})),o(ZO)
var KO=(vC=WO("app/SuperLayout"),bC=YO(s),TC=XO("app/SuperLayout"),wC=jO(HO),IC=jO(s),SC=jO({type:ZO,tooltip:void 0}),RC=jO({type:l,tooltip:void 0,visible:function(){
return this.templateType==ZO.NODE}}),xC=jO({type:m,tooltip:void 0,visible:function(){return this.templateType==ZO.PREFAB}}),CC=jO({type:GO}),OC=jO({type:qO,visible:function(){
return this.layoutType==GO.VERTICAL&&!this.autoCenter}}),PC=jO({type:JO,visible:function(){return this.layoutType==GO.HORIZONTAL&&!this.autoCenter}}),LC=jO({type:VO}),EC=jO({
type:UO}),DC=jO({tooltip:"最小值=1，大于1就是Grid模式"}),AC=jO({tooltip:"决定最多创建Prefab的数量"}),FC=jO({tooltip:"顶部填充"}),zC=jO({tooltip:"底部填充"}),kC=jO({tooltip:"左侧填充"}),BC=jO({tooltip:"右侧填充"}),
NC=jO({tooltip:"横轴间距"}),MC=jO({tooltip:"纵轴间距"}),HC=jO({tooltip:"计算缩放后的尺寸"}),GC=jO({tooltip:"开启翻页模式"}),VC=jO({tooltip:"每个页面翻页时所需时间。单位：秒",visible:function(){return this.isPageView}
}),UC=jO({type:de,visible:function(){return this.isPageView}}),WC=jO({slide:!0,range:[0,1,.01],tooltip:"滚动临界值，默认单位百分比，当拖拽超出该数值时，松开会自动滚动下一页，小于时则还原",visible:function(){
return this.isPageView}}),jC=jO({tooltip:"快速滑动翻页临界值。当用户快速滑动时，会根据滑动开始和结束的距离与时间计算出一个速度值,该值与此临界值相比较，如果大于临界值，则进行自动翻页",visible:function(){return this.isPageView}}),YC=jO({type:fe,
visible:function(){return this.isPageView}}),XC=jO({tooltip:"开启自动居中",visible:function(){return!this.isPageView}}),$C=jO({tooltip:"自动居中的滚动时间",visible:function(){
return this.autoCenter}}),qC=jO({type:l,tooltip:"自动居中的参考节点，如果为空、则默认选择View中心",visible:function(){return this.autoCenter}}),JC=jO({tooltip:"自动居中时、Item的居中锚点",visible:function(){
return this.autoCenter}}),ZC=jO({tooltip:"上/左 无限循环"}),KC=jO({tooltip:"下/右 无限循环"}),QC=jO(fe),vC(eO=bC(eO=TC(((FO=function(e){function t(){
for(var t,i=arguments.length,n=new Array(i),r=0;r<i;r++)n[r]=arguments[r]
return ze(t=e.call.apply(e,[this].concat(n))||this,"scrollView",iO,De(t)),ze(t,"view",nO,De(t)),ze(t,"_templateType",rO,De(t)),ze(t,"tmpNode",oO,De(t)),ze(t,"tmpPrefab",sO,De(t)),
ze(t,"layoutType",aO,De(t)),ze(t,"indexVerticalAxisDirection",lO,De(t)),ze(t,"indexHorizontalAxisDirection",hO,De(t)),ze(t,"verticalAxisDirection",cO,De(t)),
ze(t,"horizontalAxisDirection",uO,De(t)),ze(t,"groupItemTotal",pO,De(t)),ze(t,"multiple",dO,De(t)),ze(t,"paddingTop",fO,De(t)),ze(t,"paddingBottom",mO,De(t)),
ze(t,"paddingLeft",_O,De(t)),ze(t,"paddingRight",gO,De(t)),ze(t,"spacingX",yO,De(t)),ze(t,"spacingY",vO,De(t)),ze(t,"affectedByScale",bO,De(t)),ze(t,"isPageView",TO,De(t)),
ze(t,"pageTurningSpeed",wO,De(t)),ze(t,"indicator",IO,De(t)),ze(t,"scrollThreshold",SO,De(t)),ze(t,"autoPageTurningThreshold",RO,De(t)),ze(t,"pageEvents",xO,De(t)),
ze(t,"autoCenter",CO,De(t)),ze(t,"centerTime",OO,De(t)),ze(t,"centerNode",PO,De(t)),ze(t,"centerAnchor",LO,De(t)),ze(t,"headerLoop",EO,De(t)),ze(t,"footerLoop",DO,De(t)),
ze(t,"refreshItemEvents",AO,De(t)),t.stretchLock={},t.renderEvent=null,t._currPageIndex=0,t._lastPageIndex=0,t.isRestart=!1,t.scrollDirection=0,t.prevPos=new z(0,0,0),
t._maxPrefabTotal=0,t.currentCreateItemTotal=0,t._itemTotal=0,t._array=null,t}Le(t,e)
var i=t.prototype
return i.onLoad=function(){var e,t,i,n=this
null==(e=this.transform)||e.setContentSize(this.view.contentSize),null==(t=this.transform)||t.setAnchorPoint(new Y(.5,.5)),this.node.setPosition(z.ZERO),
this.isPageView&&(this.autoCenter=!1),this.tmpNode&&this.tmpNode.removeFromParent(),null==(i=this.scrollView.view)||i.node.on(l.EventType.SIZE_CHANGED,this.onViewSizeChange,this),
Object.defineProperty(this.transform,"contentSize",{get:function(){return n.contentSize}}),Object.defineProperty(this.transform,"width",{get:function(){return n.contentSize.width}
}),Object.defineProperty(this.transform,"height",{get:function(){return n.contentSize.height}})},i.onEnable=function(){this.addEventListener()},i.onDisable=function(){
this.removeEventListener()},i.total=function(e,t){void 0===t&&(t=!1),this.scrollView.canTouchMove=!1,this.currentCreateItemTotal=e,this.createItems(e,t)
var i=e-this.itemTotal
return this._itemTotal=e,this.refreshItems(i,t),t||this.updateItems(),this.scrollView.release(),this.indicator&&this.indicator.setPageView(this.scrollView),
this.autoCenter&&this.scrollToCenter(),this.scrollView.canTouchMove=!0,this},i.setArray=function(){var e=xe((function*(e){this._array=e,yield this.total(e?e.length:0)}))
return function(t){return e.apply(this,arguments)}}(),i.updateItems=function(){return this.resetIndexStartToEnd(this.headerIndex),this},i.updateItemSize=function(e,t){
this.groupItemTotal>1||e&&t&&(e.__runtime_size=t,this.onChangeChildSize(e._uiProps.uiTransformComp))},i.scrollToCenter=function(){this.soonFinish()},i.scrollToHeader=function(e){
var t,i,n=0
if(this.vertical)this.verticalAxisDirection==VO.TOP_TO_BOTTOM?(n=this.viewHeaderBoundary,
this.indexVerticalAxisDirection==qO.BOTTOM&&(n-=(null==(t=this.header)?void 0:t.height)+this.paddingTop+this.paddingBottom)):(n=this.viewFooterBoundary,
this.indexVerticalAxisDirection==qO.TOP&&(n+=(null==(i=this.header)?void 0:i.height)+this.paddingTop+this.paddingBottom))
else if(this.horizontalAxisDirection==UO.LEFT_TO_RIGHT){var r
n=this.viewHeaderBoundary,this.indexHorizontalAxisDirection==JO.RIGHT&&(n+=(null==(r=this.header)?void 0:r.width)+this.paddingLeft+this.paddingRight)}else{var o
n=this.viewFooterBoundary,this.indexHorizontalAxisDirection==JO.LEFT&&(n-=(null==(o=this.header)?void 0:o.width)+this.paddingLeft+this.paddingRight)}
this.scrollToIndex(0,e,new z(n,n))},i.scrollToFooter=function(e){var t=0
if(this.vertical){if(this.fixedItemHeight<this.view.height)return
var i,n
this.verticalAxisDirection==VO.TOP_TO_BOTTOM?(t=this.viewFooterBoundary,this.indexVerticalAxisDirection==qO.BOTTOM&&(t+=(null==(i=this.footer)?void 0:i.height)+this.paddingTop+this.paddingBottom)):(t=this.viewHeaderBoundary,
this.indexVerticalAxisDirection==qO.TOP&&(t-=(null==(n=this.footer)?void 0:n.height)+this.paddingTop+this.paddingBottom))}else{if(this.fixedItemWidth<this.view.width)return
var r,o
this.horizontalAxisDirection==UO.LEFT_TO_RIGHT?(t=this.viewFooterBoundary,this.indexHorizontalAxisDirection==JO.RIGHT&&(t-=(null==(r=this.footer)?void 0:r.width)+this.paddingLeft+this.paddingRight)):(t=this.viewHeaderBoundary,
this.indexHorizontalAxisDirection==JO.LEFT&&(t+=(null==(o=this.footer)?void 0:o.width)+this.paddingLeft+this.paddingRight))}this.scrollToIndex(this.itemTotal-1,e,new z(t,t),!0)},
i.isNearFooter=function(e){var t=!1
if(e>this.footerIndex&&e<this.headerIndex){var i=Math.abs(e-this.headerIndex)<Math.abs(e-this.footerIndex)
t=this.vertical?this.verticalAxisDirection==VO.TOP_TO_BOTTOM?!i:i:this.horizontalAxisDirection==UO.LEFT_TO_RIGHT?!i:i
}else e>this.footerIndex?t=this.vertical?this.verticalAxisDirection==VO.TOP_TO_BOTTOM:this.horizontalAxisDirection==UO.LEFT_TO_RIGHT:e<this.headerIndex&&(t=this.vertical?this.verticalAxisDirection!=VO.TOP_TO_BOTTOM:this.horizontalAxisDirection!=UO.LEFT_TO_RIGHT)
return t},i.getFooterOffset=function(e){var t=this.footerIndex%this.groupItemTotal
return e%this.groupItemTotal-t+this.groupItemTotal},i.getHeaderOffset=function(e){return this.headerIndex%this.groupItemTotal-e%this.groupItemTotal+this.groupItemTotal},
i.offsetToHeader=function(e){var t=0
t=this.vertical?this.verticalAxisDirection==VO.TOP_TO_BOTTOM?this.getHeaderOffset(e):this.getFooterOffset(e):this.horizontalAxisDirection==UO.LEFT_TO_RIGHT?this.getHeaderOffset(e):this.getFooterOffset(e),
t-=this.groupItemTotal
for(var i=0;i<t;i++)this.pushToHeader(!0)},i.offsetToFooter=function(e){var t=0
t=this.vertical?this.verticalAxisDirection==VO.TOP_TO_BOTTOM?this.getFooterOffset(e):this.getHeaderOffset(e):this.horizontalAxisDirection==UO.LEFT_TO_RIGHT?this.getFooterOffset(e):this.getHeaderOffset(e),
t-=this.groupItemTotal
for(var i=0;i<t;i++)this.pushToFooter(!0)},i.resetIndexStartToEnd=function(e){for(var t=0;t<this.node.children.length;t++){var i=this.node.children[t]
i.__index=e,e++,(this.headerLoop||this.footerLoop)&&(e<0||e>=this.itemTotal)&&(e=0),this.notifyRefreshItem(i)}},i.resetIndexEndToStart=function(e){
for(var t=this.node.children.length-1;t>=0;t--){var i=this.node.children[t]
i.__index=e,e--,(this.headerLoop||this.footerLoop)&&e<0&&(e=this.itemTotal-1),this.notifyRefreshItem(i)}},i.scrollToIndex=function(e,t,i,n){var r
if(void 0===n&&(n=!1),!(isNaN(e)||e<0||e>this.itemTotal-1)){this.scrollView.stopAutoScroll(),this.isPageView&&this.scrollView.savePageIndex(e)
var o=this.node.children.find((function(t){return t.__index==e})),s=this.isNearFooter(e)
if(this.stretchLock.index=e,this.stretchLock.timeInSecond=t,this.stretchLock.boundary=i,this.stretchLock.reverse=n,!o){0==e&&this.pushToHeader(),
e==this.itemTotal-1&&this.pushToFooter()
var a=this.vertical&&this.verticalAxisDirection==VO.TOP_TO_BOTTOM||!this.vertical&&this.horizontalAxisDirection==UO.LEFT_TO_RIGHT
s?(this.offsetToFooter(e),a?this.resetIndexEndToStart(e):this.resetIndexStartToEnd(e)):(this.offsetToHeader(e),a?this.resetIndexStartToEnd(e):this.resetIndexEndToStart(e)),
o=this.node.children.find((function(t){return t.__index==e}))}if(o){var l=o.getPosition().clone()
this.autoCenter||(this.vertical?this.indexVerticalAxisDirection==qO.TOP?l.y=n?this.getItemYMin(o._uiProps.uiTransformComp)-this.paddingBottom:this.getItemYMax(o._uiProps.uiTransformComp)+this.paddingTop:l.y=n?this.getItemYMax(o._uiProps.uiTransformComp)+this.paddingTop:this.getItemYMin(o._uiProps.uiTransformComp)-this.paddingBottom:this.indexHorizontalAxisDirection==JO.LEFT?l.x=n?this.getItemXMax(o._uiProps.uiTransformComp)+this.paddingRight:this.getItemXMin(o._uiProps.uiTransformComp)-this.paddingLeft:l.x=n?this.getItemXMin(o._uiProps.uiTransformComp)-this.paddingLeft:this.getItemXMax(o._uiProps.uiTransformComp)+this.paddingRight)
var h,c=null==(r=this.transform)?void 0:r.convertToWorldSpaceAR(l),u=this.view.convertToNodeSpaceAR(c)
h=!this.autoCenter&&i?i:this.getCenterAnchor(o._uiProps.uiTransformComp,this.centerPosition),u.multiply(new z(-1,-1,1)).add(h),this.scrollView.scrollToAny(u,t,!0)}}},
i.onViewSizeChange=function(){var e=xe((function*(){this.isRestart=!0,this.createItems(this.currentCreateItemTotal),this.resetChilds(!0),this.scrollToHeader()
for(var e=0;e<this.node.children.length;e++){var t=this.node.children[e]._uiProps.uiTransformComp
this.setAndSaveSizeAndScale(t)}this.isRestart=!1}))
return function(){return e.apply(this,arguments)}}(),i.setAndSaveSizeAndScale=function(e){e.setContentSize(this.getItemSize(e)),e.node.__size=e.contentSize.clone(),
e.node.__scale=e.node.getScale().clone()},i.getCenterAnchor=function(e,t){var i=t.clone()
if(this.vertical){var n=e.height*this.centerAnchor.y,r=e.height*e.anchorY
i.y-=n-r}else{var o=e.width*this.centerAnchor.x,s=e.width*e.anchorX
i.x+=o-s}return i},i.soonFinish=function(){if(this.autoCenter&&!this.scrollView.pullRefresh){this.scrollView.stopAutoScroll()
for(var e=new z(999999,999999),t=0;t<this.node.children.length;t++){
var i,n=this.node.children[t],r=null==(i=this.transform)?void 0:i.convertToWorldSpaceAR(n.position),o=this.view.convertToNodeSpaceAR(r),s={width:!1,height:!1
},a=this.getCenterAnchor(n._uiProps.uiTransformComp,this.centerPosition),l=o.subtract(a)
s.width=Math.abs(l.x)<Math.abs(e.x),s.height=Math.abs(l.y)<Math.abs(e.y),(this.vertical&&s.height||!this.vertical&&s.width)&&(e=l)}e.multiply(new z(-1,-1,1)),
this.scrollView.scrollToAny(e,this.centerTime)}},i.getItemSize=function(e){var t=new ne
if(this.vertical){var i=this.spacingX*(this.groupItemTotal-1)
t.width=(this.accommodWidth-i)/this.groupItemTotal,t.height=e.height}else{var n=this.spacingY*(this.groupItemTotal-1)
t.height=(this.accommodHeight-n)/this.groupItemTotal,t.width=e.width}return t},i.getItemYMax=function(e){if(!e)return 0
var t=this.getScaleHeight(e)*(1-e.anchorY)
return e.node.position.y+t},i.getItemYMin=function(e){if(!e)return 0
var t=this.getScaleHeight(e)*e.anchorY
return e.node.position.y-t},i.getItemXMax=function(e){if(!e)return 0
var t=this.getScaleWidth(e)*(1-e.anchorX)
return e.node.position.x+t},i.getItemXMin=function(e){if(!e)return 0
var t=this.getScaleWidth(e)*e.anchorX
return e.node.position.x-t},i.getStartX=function(e){if(!e)return 0
var t=0
if(this.horizontalAxisDirection==UO.LEFT_TO_RIGHT){var i=this.getScaleWidth(e)*e.anchorX
t=this.viewStartPoint.x+i}else{var n=this.getScaleWidth(e)*(1-e.anchorX)
t=this.viewStartPoint.x-n}return t},i.getEndX=function(e){if(!e)return 0
var t=0
if(this.horizontalAxisDirection==UO.LEFT_TO_RIGHT){var i=this.getScaleWidth(e)*(1-e.anchorX)
t=-this.viewStartPoint.x-i-this.paddingRight+this.paddingLeft}else{var n=this.getScaleWidth(e)*e.anchorX
t=-this.viewStartPoint.x+n+this.paddingLeft-this.paddingRight}return t},i.getStartY=function(e){if(!e)return 0
var t=0
if(this.verticalAxisDirection==VO.TOP_TO_BOTTOM){var i=this.getScaleHeight(e)*(1-e.anchorY)
t=this.viewStartPoint.y-i}else{var n=this.getScaleHeight(e)*e.anchorY
t=this.viewStartPoint.y+n}return t},i.getEndY=function(e){if(!e)return 0
var t=0
if(this.verticalAxisDirection==VO.TOP_TO_BOTTOM){var i=this.getScaleHeight(e)*e.anchorY
t=-this.viewStartPoint.y+i+this.paddingBottom-this.paddingTop}else{var n=this.getScaleHeight(e)*(1-e.anchorY)
t=-this.viewStartPoint.y-n-this.paddingTop+this.paddingBottom}return t},i.isAccommodateByTop=function(e){return this.getItemYMax(e)+this.paddingTop<.5*this.accommodHeight},
i.isAccommodateByBottom=function(e){return this.getItemYMin(e)-this.paddingBottom>-.5*this.accommodHeight},i.isAccommodateByLeft=function(e){
return this.getItemXMin(e)-this.paddingLeft>-.5*this.accommodWidth},i.isAccommodateByRight=function(e){return this.getItemXMax(e)+this.paddingRight<.5*this.accommodWidth},
i.getRelativeByLeft=function(e,t){return this.getItemXMin(t)-this.spacingX-this.getScaleWidth(e)*(1-e.anchorX)},i.getRelativeByRight=function(e,t){
return this.getItemXMax(t)+this.spacingX+this.getScaleWidth(e)*e.anchorX},i.getRelativeByTop=function(e,t){return this.getItemYMax(t)+this.spacingY+this.getScaleHeight(e)*e.anchorY
},i.getRelativeByBottom=function(e,t){return this.getItemYMin(t)-this.spacingY-this.getScaleHeight(e)*(1-e.anchorY)},i.setItemPosition=function(e,t,i,n){void 0===i&&(i=!1),
void 0===n&&(n=!1)
var r=new z
n?(r.x=this.getStartX(e),r.y=this.getStartY(e)):r=this.vertical?this.getVerticalRelativePosition(e,t,i):this.getHorizontalRelativePosition(e,t,i),e.node.setPosition(r)},
i.getVerticalRelativePosition=function(e,t,i){var n,r=new z
return n=this.horizontalAxisDirection==UO.LEFT_TO_RIGHT?i?this.isAccommodateByLeft(t):this.isAccommodateByRight(t):i?this.isAccommodateByRight(t):this.isAccommodateByLeft(t),
this.horizontalAxisDirection==UO.LEFT_TO_RIGHT?r.x=i?n?this.getRelativeByLeft(e,t):this.getEndX(e):n?this.getRelativeByRight(e,t):this.getStartX(e):r.x=i?n?this.getRelativeByRight(e,t):this.getEndX(e):n?this.getRelativeByLeft(e,t):this.getStartX(e),
this.verticalAxisDirection==VO.TOP_TO_BOTTOM?r.y=i?n?t.node.position.y:this.getRelativeByTop(e,t):n?t.node.position.y:this.getRelativeByBottom(e,t):r.y=i?n?t.node.position.y:this.getRelativeByBottom(e,t):n?t.node.position.y:this.getRelativeByTop(e,t),
r},i.getHorizontalRelativePosition=function(e,t,i){var n,r=new z
return n=this.verticalAxisDirection==VO.TOP_TO_BOTTOM?i?this.isAccommodateByTop(t):this.isAccommodateByBottom(t):i?this.isAccommodateByBottom(t):this.isAccommodateByTop(t),
this.verticalAxisDirection==VO.TOP_TO_BOTTOM?r.y=i?n?this.getRelativeByTop(e,t):this.getEndY(e):n?this.getRelativeByBottom(e,t):this.getStartY(e):r.y=i?n?this.getRelativeByBottom(e,t):this.getEndY(e):n?this.getRelativeByTop(e,t):this.getStartY(e),
this.horizontalAxisDirection==UO.LEFT_TO_RIGHT?r.x=i?n?t.node.position.x:this.getRelativeByLeft(e,t):n?t.node.position.x:this.getRelativeByRight(e,t):r.x=i?n?t.node.position.x:this.getRelativeByRight(e,t):n?t.node.position.x:this.getRelativeByLeft(e,t),
r},i.refreshItems=function(e,t){if(void 0===t&&(t=!1),e<0){for(var i=0;i<-e;i++)this.headerLoop||this.footerLoop?this.pushToHeader():(this.pushToHeader(!0),this.pushToFooter())
var n=this.headerIndex>0?this.headerIndex:0
n+this.node.children.length>this.itemTotal&&(n+=e),n<0&&(n=0)
for(var r=0;r<this.node.children.length;r++){var o=this.node.children[r];(this.headerLoop||this.footerLoop)&&n>this.itemTotal-1&&(n=0),o.__index=n,n++,t&&this.notifyRefreshItem(o)}
this.scrollView.stopAutoScroll(),this.scrollView.startAutoScroll()
}else for(var s=0;s<this.node.children.length;s++)this.vertical?this.verticalAxisDirection==VO.TOP_TO_BOTTOM?this.pushToFooter():this.pushToHeader():this.horizontalAxisDirection==UO.LEFT_TO_RIGHT?this.pushToFooter():this.pushToHeader()
},i.createItems=function(e,t){var i=this
if(this.node.children.length>e)this.removeItems(e)
else if(this.needAddPrefab()||!(this._maxPrefabTotal>0)||this._maxPrefabTotal!=this.node.children.length)for(var n=e-this.node.children.length,r=function(e){
var t=p(i.templateType==ZO.NODE?i.tmpNode:i.tmpPrefab),n=t._uiProps.uiTransformComp
i.setAndSaveSizeAndScale(n),t.__index=i.node.children.length,i.node.addChild(t)
var r,o=i.node.children.length-2
if(r=0==t.__index?i.footer:i.node.children[o]._uiProps.uiTransformComp,t.on(l.EventType.SIZE_CHANGED,(function(){i.onChangeChildSize(n)}),i,!0),
t.on(l.EventType.TRANSFORM_CHANGED,(function(e){i.onChangeChildScale(e,n)}),i,!0),i.notifyRefreshItem(t),i.setItemPosition(t._uiProps.uiTransformComp,r,!1,0==t.__index),
!i.needAddPrefab())return i._maxPrefabTotal=i.node.children.length,console.log("已固定item数量",i._maxPrefabTotal),"break"},o=0;o<n&&"break"!==r();o++);},i.needAddPrefab=function(){
var e=this.vertical?this.contentSize.height:this.contentSize.width
return e>0&&e<(this.vertical?this.view.height:this.view.width)*this.multiple},i.onChangeChildSize=function(){var e=xe((function*(e){var t=e.node
if(this.groupItemTotal>1){var i=t.__size
return e.setContentSize(i),void console.warn("表格布局不支持动态修改 Size,如果你非要修改，那你把我注释掉看效果")}
this.stretchLock.index==t.__index&&this.scrollToIndex(this.stretchLock.index,this.stretchLock.timeInSecond,this.stretchLock.boundary,this.stretchLock.reverse),
this.resetStrectchItems()}))
return function(t){return e.apply(this,arguments)}}(),i.onChangeChildScale=function(){var e=xe((function*(e,t){if(e===l.TransformBit.SCALE&&this.affectedByScale){var i=t.node
if(this.groupItemTotal>1){var n=i.__scale
return t.node.setScale(n),void console.warn("表格布局不支持动态修改 Scale,如果你非要修改，那你把我注释掉看效果")}
this.stretchLock.index==i.__index&&this.scrollToIndex(this.stretchLock.index,this.stretchLock.timeInSecond,this.stretchLock.boundary,this.stretchLock.reverse),
this.resetStrectchItems()}}))
return function(t,i){return e.apply(this,arguments)}}(),i.resetStrectchItems=function(){var e=this
if(!isNaN(this.stretchLock.index)){var t=this.node.children.findIndex((function(t){return t.__index==e.stretchLock.index}))
if(-1!=t){for(var i=t;i>=0;i--){var n=this.node.children[i]
i!=t&&i<t&&this.setItemPosition(n._uiProps.uiTransformComp,this.node.children[i+1]._uiProps.uiTransformComp,!0)}for(var r=t;r<this.node.children.length;r++){
var o=this.node.children[r]
r!=t&&this.setItemPosition(o._uiProps.uiTransformComp,this.node.children[r-1]._uiProps.uiTransformComp)}return}}1==this.scrollDirection?(this.unschedule(this.stretchToFooter),
this.scheduleOnce(this.stretchToFooter)):(this.unschedule(this.stretchToHeader),this.scheduleOnce(this.stretchToHeader))},i.stretchToHeader=function(){
for(var e=this.node.children.length-1;e>=0;e--){var t=this.node.children[e]
e!=this.node.children.length-1&&this.setItemPosition(t._uiProps.uiTransformComp,this.node.children[e+1]._uiProps.uiTransformComp,!0)}},i.stretchToFooter=function(){
for(var e=0;e<this.node.children.length;e++){var t=this.node.children[e]
0!=e&&this.setItemPosition(t._uiProps.uiTransformComp,this.node.children[e-1]._uiProps.uiTransformComp)}},i.removeItems=function(e){
for(var t=this.node.children.length-e,i=0;i<t;i++){var n=this.node.children[this.node.children.length-1]
n.off(l.EventType.SIZE_CHANGED),n.off(l.EventType.TRANSFORM_CHANGED),this.node.removeChild(n),n!=this.tmpNode&&n.destroy()}},i.addEventListener=function(){
this.node.on(c.TRANSFORM_CHANGED,this.onPositionChanged,this)},i.removeEventListener=function(){this.node.off(c.TRANSFORM_CHANGED,this.onPositionChanged,this)},
i.resetChilds=function(e){if(void 0===e&&(e=!1),this.vertical&&this.fixedItemHeight<=this.view.height||!this.vertical&&this.fixedItemWidth<=this.view.width){
var t,i=this.getStartX(this.header),n=this.getStartY(this.header)
null==(t=this.header)||t.node.setPosition(new z(i,n))}if(e)if(this.vertical){var r,o=this.getStartX(this.header)
null==(r=this.header)||r.node.setPosition(new z(o,this.header.node.position.y))}else{var s,a=this.getStartY(this.header)
null==(s=this.header)||s.node.setPosition(new z(this.header.node.position.x,a))}this.stretchToFooter(),e||this.scrollView.startAutoScroll()},i.onTouchBegin=function(){
this.stretchLock={}},i.getUsedScaleValue=function(e){return this.affectedByScale?Math.abs(e):1},i.getScaleWidth=function(e){if(!e)return 0
var t=e.node.__runtime_size
return(t?t.width:e.width)*this.getUsedScaleValue(e.node.scale.x)},i.getScaleHeight=function(e){if(!e)return 0
var t=e.node.__runtime_size
return(t?t.height:e.height)*this.getUsedScaleValue(e.node.scale.y)},i.onPositionChanged=function(){if(!this.isRestart){
if(this.vertical?this.scrollView.prevLocation.y<this.scrollView.location.y?this.scrollDirection=2:this.scrollView.prevLocation.y>this.scrollView.location.y?this.scrollDirection=1:this.scrollDirection=0:this.scrollView.prevLocation.x>this.scrollView.location.x?this.scrollDirection=2:this.scrollView.prevLocation.x<this.scrollView.location.x?this.scrollDirection=1:this.scrollDirection=0,
this.vertical)for(var e=0;e<this.node.children.length;e++)Math.abs(this.prevPos.y-this.node.position.y)>$O&&(this.prevPos.y<this.node.position.y?this.pushToFooter():this.prevPos.y>this.node.position.y&&this.pushToHeader())
else for(var t=0;t<this.node.children.length;t++)Math.abs(this.prevPos.x-this.node.position.x)>$O&&(this.prevPos.x>this.node.position.x?this.pushToFooter():this.prevPos.x<this.node.position.x&&this.pushToHeader())
this.prevPos=this.node.position.clone()}},i.pushToFooter=function(e){var t,i,n
if(void 0===e&&(e=!1),this.vertical)this.verticalAxisDirection==VO.TOP_TO_BOTTOM?(e||this.headerBoundary-this.paddingTop>this.viewHeaderBoundary+(null==(n=this.header)?void 0:n.height))&&this.pushToFooterHandler():(e||this.footerBoundary-this.paddingTop>this.viewHeaderBoundary+(null==(i=this.header)?void 0:i.height))&&this.pushToHeaderHandler()
else if(this.horizontalAxisDirection==UO.LEFT_TO_RIGHT){var r
;(e||this.headerBoundary+this.paddingLeft<this.viewHeaderBoundary-(null==(r=this.header)?void 0:r.width))&&this.pushToFooterHandler()
}else(e||this.footerBoundary+this.paddingLeft<this.viewHeaderBoundary-(null==(t=this.header)?void 0:t.width))&&this.pushToHeaderHandler()},i.pushToHeader=function(e){var t,i,n
if(void 0===e&&(e=!1),this.vertical)this.verticalAxisDirection==VO.TOP_TO_BOTTOM?(e||this.footerBoundary+this.paddingBottom<this.viewFooterBoundary-(null==(n=this.footer)?void 0:n.height))&&this.pushToHeaderHandler():(e||this.headerBoundary+this.paddingBottom<this.viewFooterBoundary-(null==(i=this.footer)?void 0:i.height))&&this.pushToFooterHandler()
else if(this.horizontalAxisDirection==UO.LEFT_TO_RIGHT){var r
;(e||this.footerBoundary-this.paddingRight>this.viewFooterBoundary+(null==(r=this.footer)?void 0:r.width))&&this.pushToHeaderHandler()
}else(e||this.headerBoundary-this.paddingRight>this.viewFooterBoundary+(null==(t=this.footer)?void 0:t.width))&&this.pushToFooterHandler()},i.pushToFooterHandler=function(){
var e,t,i=null==(e=this.header)?void 0:e.node
if(this.vertical?this.verticalAxisDirection==VO.TOP_TO_BOTTOM?this.footerLoop:this.headerLoop:this.horizontalAxisDirection==UO.LEFT_TO_RIGHT?this.footerLoop:this.headerLoop)this.footerIndex>=this.itemTotal-1?i.__index=0:i.__index=this.footerIndex+1
else{if(!this.footer||this.footerIndex>=this.itemTotal-1)return
i.__index=this.footerIndex+1}i.__index>0&&i.__index<this.currentCreateItemTotal&&this.notifyRefreshItem(i),this.setItemPosition(this.header,this.footer),
null==(t=this.header)||t.node.setSiblingIndex(this.node.children.length)},i.pushToHeaderHandler=function(){var e,t,i,n=null==(e=this.footer)?void 0:e.node
if((i=this.vertical?this.verticalAxisDirection==VO.TOP_TO_BOTTOM?this.headerLoop:this.footerLoop:this.horizontalAxisDirection==UO.LEFT_TO_RIGHT?this.headerLoop:this.footerLoop)||0!=this.headerIndex||(this.vertical?this.horizontalAxisDirection==UO.LEFT_TO_RIGHT?this.isAccommodateByLeft(this.header):this.isAccommodateByRight(this.header):this.verticalAxisDirection==VO.TOP_TO_BOTTOM?this.isAccommodateByTop(this.header):this.isAccommodateByBottom(this.header))&&this.resetChilds(!0),
i)0==this.headerIndex?n.__index=this.itemTotal-1:n.__index=this.headerIndex-1
else{if(!this.header||0==this.headerIndex)return
n.__index=this.headerIndex-1}n.__index>0&&n.__index<this.currentCreateItemTotal&&this.notifyRefreshItem(n),this.setItemPosition(this.footer,this.header,!0),
null==(t=this.footer)||t.node.setSiblingIndex(0)},i.notifyRefreshItem=function(e){var t=this.renderEvent
if(t){t.once&&(this.renderEvent=null)
var i=e.__index
t.runWith([e,i,this._array?this._array[i]:void 0])}},Oe(t,[{key:"templateType",get:function(){return this._templateType},set:function(e){null!=e&&(this._templateType=e),
e===ZO.NODE?this.tmpPrefab=null:e===ZO.PREFAB&&(this.tmpNode=null)}},{key:"currPageIndex",get:function(){return this._currPageIndex},set:function(e){this._currPageIndex=e}},{
key:"lastPageIndex",get:function(){return this._lastPageIndex},set:function(e){this._lastPageIndex=e}},{key:"vertical",get:function(){return this.layoutType==GO.VERTICAL}},{
key:"horizontal",get:function(){return this.layoutType==GO.HORIZONTAL}},{key:"transform",get:function(){return this.node._uiProps.uiTransformComp}},{key:"accommodWidth",
get:function(){return this.view.width-this.paddingLeft-this.paddingRight}},{key:"accommodHeight",get:function(){return this.view.height-this.paddingTop-this.paddingBottom}},{
key:"header",get:function(){return 0==this.node.children.length?null:this.node.children[0]._uiProps.uiTransformComp}},{key:"footer",get:function(){
return 0==this.node.children.length?null:this.node.children[this.node.children.length-1]._uiProps.uiTransformComp}},{key:"headerIndex",get:function(){
return this.header?this.header.node.__index:-1}},{key:"footerIndex",get:function(){return this.footer?this.footer.node.__index:-1}},{key:"viewStartPoint",get:function(){var e=new z
return this.horizontalAxisDirection==UO.LEFT_TO_RIGHT?e.x=-.5*this.view.width+this.paddingLeft:e.x=.5*this.view.width-this.paddingRight,
this.verticalAxisDirection==VO.TOP_TO_BOTTOM?e.y=.5*this.view.height-this.paddingTop:e.y=-.5*this.view.height+this.paddingBottom,e}},{key:"viewHeaderBoundary",get:function(){
return this.vertical?.5*this.view.height:-.5*this.view.width}},{key:"viewFooterBoundary",get:function(){return this.vertical?-.5*this.view.height:.5*this.view.width}},{
key:"headerBoundary",get:function(){
return this.header?this.vertical?this.verticalAxisDirection==VO.TOP_TO_BOTTOM?this.node.position.y+this.getItemYMax(this.header)+this.paddingTop:this.node.position.y+this.getItemYMin(this.header)-this.paddingBottom:this.horizontalAxisDirection==UO.LEFT_TO_RIGHT?this.node.position.x+this.getItemXMin(this.header)-this.paddingLeft:this.node.position.x+this.getItemXMax(this.header)+this.paddingRight:0
}},{key:"footerBoundary",get:function(){
return this.footer?this.vertical?this.verticalAxisDirection==VO.TOP_TO_BOTTOM?this.node.position.y+this.getItemYMin(this.footer)-this.paddingBottom:this.node.position.y+this.getItemYMax(this.footer)+this.paddingTop:this.horizontalAxisDirection==UO.LEFT_TO_RIGHT?this.node.position.x+this.getItemXMax(this.footer)+this.paddingRight:this.node.position.x+this.getItemXMin(this.footer)-this.paddingLeft:0
}},{key:"centerHeaderBoundary",get:function(){var e,t=this.vertical?"y":"x"
return e=this.centerNode?this.viewHeaderBoundary-this.centerNode.position[t]:this.viewHeaderBoundary-this.view.node.position[t],
this.vertical&&this.verticalAxisDirection==VO.TOP_TO_BOTTOM||this.horizontal&&this.horizontalAxisDirection==UO.LEFT_TO_RIGHT?this.headerBoundary+e:this.footerBoundary+e}},{
key:"centerFooterBoundary",get:function(){var e,t=this.vertical?"y":"x"
return e=this.centerNode?this.viewFooterBoundary-this.centerNode.position[t]:this.viewFooterBoundary-this.view.node.position[t],
this.vertical&&this.verticalAxisDirection==VO.TOP_TO_BOTTOM||this.horizontal&&this.horizontalAxisDirection==UO.LEFT_TO_RIGHT?this.footerBoundary+e:this.headerBoundary+e}},{
key:"isOfLeftBoundary",get:function(){if(this.vertical)return 0
if(this.autoCenter)return 1==this.scrollDirection?this.centerHeaderBoundary:0
if(this.headerLoop)return this.header?0:this.viewHeaderBoundary+this.node.position.x
if(!this.header||this.fixedItemWidth<=this.view.width)return this.viewHeaderBoundary+this.node.position.x
if(this.horizontalAxisDirection==UO.LEFT_TO_RIGHT){if(0==this.headerIndex)return this.headerBoundary}else if(this.footerIndex==this.itemTotal-1)return this.footerBoundary
return 0}},{key:"isOfTopBoundary",get:function(){if(!this.vertical)return 0
if(this.autoCenter)return 1==this.scrollDirection?this.centerHeaderBoundary:0
if(this.headerLoop)return this.header?0:this.viewHeaderBoundary+this.node.position.y
if(!this.header||this.fixedItemHeight<=this.view.height)return this.viewHeaderBoundary+this.node.position.y
if(this.verticalAxisDirection==VO.TOP_TO_BOTTOM){if(0==this.headerIndex)return this.headerBoundary}else if(this.footerIndex==this.itemTotal-1)return this.footerBoundary
return 0}},{key:"isOfRightBoundary",get:function(){if(this.vertical)return 0
if(this.autoCenter)return 2==this.scrollDirection?this.centerFooterBoundary:0
if(this.footerLoop)return this.footer?0:this.viewFooterBoundary+this.node.position.x
if(!this.footer||this.fixedItemWidth<=this.view.width)return this.viewFooterBoundary+this.node.position.x
if(this.horizontalAxisDirection==UO.LEFT_TO_RIGHT){if(this.footerIndex==this.itemTotal-1)return this.footerBoundary}else if(0==this.headerIndex)return this.headerBoundary
return 0}},{key:"isOfButtomBoundary",get:function(){if(!this.vertical)return 0
if(this.autoCenter)return 2==this.scrollDirection?this.centerFooterBoundary:0
if(this.footerLoop)return this.footer?0:this.viewFooterBoundary+this.node.position.y
if(!this.footer||this.fixedItemHeight<=this.view.height)return this.viewFooterBoundary+this.node.position.y
if(this.verticalAxisDirection==VO.TOP_TO_BOTTOM){if(this.footerIndex==this.itemTotal-1)return this.footerBoundary}else if(0==this.headerIndex)return this.headerBoundary
return 0}},{key:"fixedItemHeight",get:function(){
return this.header?this.verticalAxisDirection==VO.TOP_TO_BOTTOM?Math.abs(this.getItemYMax(this.header))+Math.abs(this.getItemYMin(this.footer)):Math.abs(this.getItemYMin(this.header))+Math.abs(this.getItemYMax(this.footer)):0
}},{key:"fixedItemWidth",get:function(){
return this.header?this.horizontalAxisDirection==UO.LEFT_TO_RIGHT?Math.abs(this.getItemXMin(this.header))+Math.abs(this.getItemXMax(this.footer)):Math.abs(this.getItemXMax(this.header))+Math.abs(this.getItemXMin(this.footer)):0
}},{key:"contentSize",get:function(){if(0==this.node.children.length)return this.view.contentSize
var e=new ne(this.view.contentSize.width,this.view.contentSize.height)
return this.vertical?this.verticalAxisDirection==VO.TOP_TO_BOTTOM?e.height=this.headerBoundary+-this.footerBoundary:e.height=this.footerBoundary+-this.headerBoundary:this.horizontalAxisDirection==UO.LEFT_TO_RIGHT?e.width=this.footerBoundary+-this.headerBoundary:e.width=this.headerBoundary+-this.footerBoundary,
e.width<this.view.contentSize.width&&(e.width=this.view.contentSize.width),e.height<this.view.contentSize.height&&(e.height=this.view.contentSize.height),e}},{key:"maxPrefabTotal",
get:function(){return this._maxPrefabTotal}},{key:"itemTotal",get:function(){return this._itemTotal}},{key:"centerPosition",get:function(){
if(!this._centerPosition)if(this._centerPosition=new z,this.autoCenter){if(this.centerNode){
var e,t,i=null==(e=this.centerNode.parent)||null==(t=e._uiProps.uiTransformComp)?void 0:t.convertToWorldSpaceAR(this.centerNode.position)
this._centerPosition=this.view.convertToNodeSpaceAR(i)}
}else this.vertical?this.indexVerticalAxisDirection==qO.TOP?this._centerPosition.y=this.viewHeaderBoundary:this._centerPosition.y=this.viewFooterBoundary:this.indexHorizontalAxisDirection==JO.LEFT?this._centerPosition.x=this.viewHeaderBoundary:this._centerPosition.x=this.viewFooterBoundary
return this._centerPosition}},{key:"array",get:function(){return this._array},set:function(e){this._array=e,this.total(e?e.length:0)}}]),t}(t)).VerticalAxisDirection=VO,
FO.HorizontalAxisDirection=UO,iO=ke((tO=FO).prototype,"scrollView",[wC],{configurable:!0,enumerable:!0,writable:!0,initializer:null}),nO=ke(tO.prototype,"view",[IC],{
configurable:!0,enumerable:!0,writable:!0,initializer:null}),rO=ke(tO.prototype,"_templateType",[jO],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){
return ZO.NODE}}),ke(tO.prototype,"templateType",[SC],Object.getOwnPropertyDescriptor(tO.prototype,"templateType"),tO.prototype),oO=ke(tO.prototype,"tmpNode",[RC],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return null}}),sO=ke(tO.prototype,"tmpPrefab",[xC],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}
}),aO=ke(tO.prototype,"layoutType",[CC],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return GO.VERTICAL}}),
lO=ke(tO.prototype,"indexVerticalAxisDirection",[OC],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return qO.TOP}}),
hO=ke(tO.prototype,"indexHorizontalAxisDirection",[PC],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return JO.LEFT}}),
cO=ke(tO.prototype,"verticalAxisDirection",[LC],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return VO.TOP_TO_BOTTOM}}),
uO=ke(tO.prototype,"horizontalAxisDirection",[EC],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return UO.LEFT_TO_RIGHT}}),
pO=ke(tO.prototype,"groupItemTotal",[DC],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 1}}),dO=ke(tO.prototype,"multiple",[AC],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return 2}}),fO=ke(tO.prototype,"paddingTop",[FC],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),
mO=ke(tO.prototype,"paddingBottom",[zC],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),_O=ke(tO.prototype,"paddingLeft",[kC],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return 0}}),gO=ke(tO.prototype,"paddingRight",[BC],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),
yO=ke(tO.prototype,"spacingX",[NC],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 0}}),vO=ke(tO.prototype,"spacingY",[MC],{configurable:!0,enumerable:!0,
writable:!0,initializer:function(){return 0}}),bO=ke(tO.prototype,"affectedByScale",[HC],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),
TO=ke(tO.prototype,"isPageView",[GC],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),wO=ke(tO.prototype,"pageTurningSpeed",[VC],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return.3}}),IO=ke(tO.prototype,"indicator",[UC],{configurable:!0,enumerable:!0,writable:!0,initializer:null}),
SO=ke(tO.prototype,"scrollThreshold",[WC],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return.5}}),RO=ke(tO.prototype,"autoPageTurningThreshold",[jC],{
configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 100}}),xO=ke(tO.prototype,"pageEvents",[YC],{configurable:!0,enumerable:!0,writable:!0,
initializer:function(){return[]}}),CO=ke(tO.prototype,"autoCenter",[XC],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),
OO=ke(tO.prototype,"centerTime",[$C],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return 1}}),PO=ke(tO.prototype,"centerNode",[qC],{configurable:!0,
enumerable:!0,writable:!0,initializer:null}),LO=ke(tO.prototype,"centerAnchor",[JC],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return new Y(.5,.5)}}),
EO=ke(tO.prototype,"headerLoop",[ZC],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return!1}}),DO=ke(tO.prototype,"footerLoop",[KC],{configurable:!0,
enumerable:!0,writable:!0,initializer:function(){return!1}}),AO=ke(tO.prototype,"refreshItemEvents",[QC],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return[]}
}),eO=tO))||eO)||eO)||eO)
e._RF.pop(),e._RF.push({},"29da7FqeRhBL4CbbNM6/9cm","_LaunchClass",void 0),e._RF.pop(),e._RF.push({},"41d435aJqdG7LzGm+tNiaV8","IResFormat",void 0),e._RF.pop(),
e._RF.push({},"bde1fXVGeNIGaDN3Ra1rnUi","ui_chat_cell",void 0),e._RF.pop(),e._RF.push({},"873e7ourjxGgIjjqh7L7P1v","ui_login_loading",void 0),e._RF.pop(),
e._RF.push({},"1d4d8UgWXRPNYaFY01ujWPb","ui_login_localloginpanel",void 0),e._RF.pop(),e._RF.push({},"0a7f5MFIhJF1JqR9YFcn2l1","ui_login_policy_view",void 0),e._RF.pop(),
e._RF.push({},"aa73fWHwERIVrmS56RpFj6W","ui_login_view",void 0),e._RF.pop()}}})),function(e){var t,i
t="virtual:///prerequisite-imports/main",i="chunks:///main.js",System.register(t,[i],(function(e,t){return{setters:[function(t){var i={}
for(var n in t)"default"!==n&&"__esModule"!==n&&(i[n]=t[n])
e(i)}],execute:function(){}}}))}()
