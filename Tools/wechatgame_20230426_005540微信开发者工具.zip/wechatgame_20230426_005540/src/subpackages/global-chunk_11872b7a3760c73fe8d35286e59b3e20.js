"use strict";(globalThis.webpackChunkProject=globalThis.webpackChunkProject||[]).push([[128],{17838:(t,e,i)=>{i.d(e,{g:()=>r})
var s=i(38836),n=i(38045),l=i(66788),a=i(85602),o=i(81266)
class r{constructor(){this.data=null}static FillJsonData(t,e,i){null==i&&(i=!0)
let h=t.__GetFieldType
if(e)for(const[d,c]of(0,s.X)(e)){let e,s,u
if(h){let t=h(d)
t instanceof Array?(e=t[0],s=t[1],u=t[2]):e=t}
if(!e||"number"!=e&&"int"!=e&&"float"!=e&&"double"!=e)if(i&&"object"==typeof c)if(null==h&&l.Y.LogError(tType._type_full_name_+" 没__GetFieldType 方法"),
null==e&&l.Y.LogError(tType._type_full_name_+"__GetFieldType 方法没指定数组的元素的类型 "+d),e==a.Z){let e=null
if("number"==s||"int"==s||"float"==s||"double"==s||"string"==s||"boolean"==s||"bool"==s||"table"==s)e=new a.Z(c),t[d]=e
else{e=new a.Z,t[d]=e
for(let e=1;e<=c.length;e++){let n=new s
r.FillJsonData(n,c[e],i),t[d].Add(n)}}}else if("table"==e)null==t[d]&&(t[d]={}),o.E.CloneTable(t[d],c,i)
else{let s=new e
r.FillJsonData(s,c,i),t[d]=s}else t[d]=c
else t[d]=(0,n.aI)(c)}}}},96964:(t,e,i)=>{i.d(e,{o:()=>Yt})
var s=i(17409),n=i(93984),l=i(38836),a=i(86133),o=i(13687),r=i(35128),h=i(98130),d=i(98885),c=i(85602),u=i(38962),m=i(79534),I=i(42292),g=i(71409),_=i(32076),p=i(23833),C=i(98800),S=i(91238),f=i(55039),y=i(62265),w=i(45404),D=i(35907),T=i(31546),A=i(61646),v=i(73206),L=i(97461),M=i(36241),b=i(19176),R=i(26034),P=i(6700),G=i(73136),O=i(68662),E=i(2689),B=i(38935),k=i(5924),x=i(19833),V=i(56937),N=i(31222),H=i(5494),U=i(52726),F=i(995),j=i(98789),Y=i(55360),z=i(70850),q=i(92679),Z=i(74045),K=i(49067),$=i(87923),W=i(29839),X=i(85770),Q=i(48933),J=i(13476),tt=i(15782),et=i(75439),it=i(55552),st=i(47786),nt=i(38501),lt=i(36923),at=i(16707),ot=i(55212),rt=i(67716),ht=i(2955),dt=i(13234),ct=i(92415),ut=i(22662),mt=i(33828),It=i(92260),gt=i(96713),_t=i(31896),pt=i(43308),Ct=i(14792),St=i(62734),ft=i(65550),yt=i(85942),wt=i(19519),Dt=i(21334),Tt=i(19276),At=i(88934),vt=i(15771),Lt=i(71453),Mt=i(57693),bt=i(30236),Rt=i(63611)
class Pt{constructor(){this.model=null,this.timeid=0,this.inRange=!1,this.model=Lt.x.getInstance()}EnterMap(){this.ClearTimer(),this.SetTimer()}OutMap(){this.ClearTimer()}
ClearTimer(){0!=this.timeid&&(k.C.Inst_get().ClearInterval(this.timeid),this.timeid=0)}SetTimer(){this.timeid=k.C.Inst_get().SetInterval((0,_.v)(this.FrameCheck,this),1e3,-1)}
FrameCheck(){const t=Q.I.calVec0
C.Y.Inst.PrimaryRole_get().GetCurPos(t)
const e=C.Y.Inst.getMonstsAroundPos(t,4)
let i=!1
for(const[t,s]of(0,l.vy)(e)){s.Cfg_get().objectType==Rt.b.MONSTER_BOSS&&(i=!0)}i?this.EnterBossRange():this.OutBossRange()}OutBossRange(){this.inRange&&(this.inRange=!1,
this.model.RaiseEvent(Lt.x.OUT_BOSS_RANGE))}EnterBossRange(){this.inRange||(this.inRange=!0,this.model.RaiseEvent(Lt.x.OUT_BOSS_RANGE))}Test1(){return!0}S_Test(){return!0}}
var Gt,Ot,Et,Bt,kt,xt,Vt,Nt,Ht,Ut=i(93701),Ft=i(4926)
function jt(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let Yt=(Gt=(0,g.GH)(ct.k.SM_ShowTodayBestRecord),Ot=(0,g.GH)(ct.k.SM_KarimaMulData),Et=(0,
g.GH)(ct.k.SM_KarimaCursePoint),Bt=(0,g.GH)(ct.k.SM_KarimaBossInfo),kt=(0,g.GH)(ct.k.SM_KarimaInfo),xt=(0,g.GH)(ct.k.SM_LeaveKarima),Vt=(0,g.GH)(ct.k.SM_KarimaGetItems),Ht=class t{
get karimaStatusView(){return(0,s.Y)(H.I.KarimaStatusView)}get rightView(){return(0,s.Y)(H.I.KarimaRightView)}constructor(){this.tickConsume=null,this.model=null,this.mapList=null,
this.recommandList=null,this.karimaFindBossControl=null,this.effectTimeId=-1,this.playDieTimeid=0,this.gateHandle=0,this.gateElementId=0,this.lastGetItemTime=0,this.objId=null,
this.gateObj=null,this.tickConsume=new u.X,this.InitTickConsume(),this.model=Lt.x.getInstance(),this.recommandList=new u.X,this.karimaFindBossControl=new Pt,
this.InitMapRecommand(),L.i.Inst.AddEventHandler(q.g.BAG_UPDATE,(0,_.v)(this.BagUpHandler,this))}static getInstance(){return null==t.Inst&&(t.Inst=new t),t.Inst}InitTickConsume(){
const t=et.D.getInstance().getContent("KARIMA:TICKET_CONSUME").getContent().stringVal,e=d.M.Split(t,d.M.s_Arr_CCD_CHAR_DOT)
for(let t=0;t<=e.Count()-1;t++){const i=d.M.Split(e[t],"_")
this.tickConsume.LuaDic_Add(d.M.String2Int(i[0]),d.M.String2Int(i[1]))}}InitMapRecommand(){
const t=et.D.getInstance().getContent("KARIMA:RECOMMEND_LEVEL").getContent().stringVal,e=d.M.Split(t,d.M.s_Arr_CCD_CHAR_DOT)
for(let t=0;t<=e.Count()-1;t++){const i=d.M.Split(e[t],"_")
for(let t=0;t<=i.Count()-1;t++)i[t]=d.M.String2Int(i[t])+""
this.recommandList.LuaDic_Add(d.M.String2Int(i[0]),i)}}BagUpHandler(){Lt.x.Inst.CheckRedPoint()}BuyKarimaTime(t){}OnOpenDiamondTip(t){mt.Y.Inst_get().OkHandler(null)}LeaveKarima(){
this.CM_LeaveKarima()}KarimaBossAttention(t,e){this.CM_KarimaBossAttention(t,e)}GetNextVipLevel(){let t=vt.U.inst.model.level_get()
const e=this.GetVipCounts(t)
t+=1
let i=this.GetVipCounts(t)
for(;0!=i;){if(i>e)return t
t+=1,i=this.GetVipCounts(t)}return-1}HandleCursePoint(t){this.model.cursePoint=t,this.model.RaiseEvent(Lt.x.CURSEPOINT_UPDATE)}EnterKarima(t,e,i){return this.model.enterMapId=e,
null==i&&(i=1),
this.model.mtctime=i,this.InKarima()?this.KarimaInnerEnter(t,e):this.HasTimes(i)?this.IsMaxLevelMap(e)?this.HandleEnterTickets(e,t.sortId,i):this.HandleMaxLevelMap(e,t.sortId):void this.GotoVIP(!0)
}GotoVIP(t){const e=this.GetNextVipLevel()
if(-1!=e){const i=new K.B
i.infoId="KALIMA:MORE_TIMES"
const s=vt.U.inst.model.level_get()
i.replaceParams.Add(e)
const n=this.GetVipCounts(e)-this.GetVipCounts(s)
i.replaceParams.Add(n),i.cancelHandle=null,i.cancelParam=null,i.confirmHandle=(0,_.v)(this.GotoVIPConfirm,this),i.confirmParam=e,i.confirmText=(0,R._T)("立即前往"),Z.t.Inst().Open(i),
t&&ft.y.inst.ClientSysMessage(10300005)}else ft.y.inst.ClientSysMessage(10300005)}GotoVIPConfirm(t){vt.U.inst.model.defaultVipGiftIndex=t,vt.U.inst.controller.OpenPanel()}
BuyTimeConfirm(){const t=new K.B
t.infoId="KARIMA:ENTER_EXTRA_BUY",t.replaceParams.Add(this.GetTimesCost()),t.cancelHandle=null,t.cancelParam=null,t.dontClose=!0,t.confirmHandle=(0,
_.v)(this.BuyTimeConfirmCallBack,this),t.confirmParam=null,Z.t.Inst().Open(t)}BuyTimeConfirmCallBack(){this.BuyKarimaTime()}HandleEnterTickets(t,e,i){
if(this.HaveEnoughTickets())this.PrepareEnter(e)
else{ft.y.inst.ClientSysMessage(10300006)
const t=m.P.zero_get()
pt._.Inst_get().OpenByItem(this.GetTicketID(),t,null)}}PrepareEnter(t){if(this.InKarima()||W.p.inst.IsInCopy())return void ft.y.inst.ClientSysMessage(10300007)
const e=o.b.Inst.GetCurMap()
null==e||e.controllerType!=E.N.MULTIPLE_HANG?C.Y.Inst.primaryRole.InFindingPathWithOutPos()?ft.y.inst.ClientSysMessage(10300008):(this.model.findBossId=t,
N.N.inst.ClearAllPanel(!0,!0),this.model.InEntering=!0,this.PlayKarimaEffect()):ft.y.inst.ClientSysMessage(10300007)}BuyTickConfirm(t){}KarimaInnerEnter(t,e){
const i=o.b.Inst.currentMapId_get()
if(i==e)this.FindBoss(t.sortId)
else{const t=st.x.Inst().getItemById(10300003)
let s=$.l.RegexN(t.sys_messsage)
const n=Dt.p.Inst_get().GetMapById(i).name,l=Dt.p.Inst_get().GetMapById(e).name,a=new c.Z([n,l])
s=$.l.Substitute(s,a),ft.y.inst.ClientStrMsg(ut.r.SystemTipMessage,s)}}PlayKarimaEffect(){M._.getInst().endHang(),this.GenerateGate()}GenerateGate(){const e=new m.P
C.Y.Inst.PrimaryRole_get().GetCurPos(e)
let i=!1
this.model.targetpoint=new m.P,this.model.targetpoint.z=e.z+4,this.model.targetpoint.x=e.x,this.model.targetpoint.y=e.y
let s=t.Min_Dis,n=t.Max_Dis,l=0
for(i=G.c.Instance_get().CanArrive(this.model.targetpoint.x,this.model.targetpoint.z);!i;){if(l>300)return
if(l>200)s=0,n=2
else if(l>300)return s=2,void(n=4)
l+=1
const t=r.p.RandomMinMax(s,n),a=r.p.RandomMinMax(0,1)>.5?1:-1
this.model.targetpoint.x=e.x+t*a
const o=r.p.RandomMinMax(s,n),h=r.p.RandomMinMax(0,1)>.5?1:-1
this.model.targetpoint.z=e.z+o*h,i=G.c.Instance_get().CanArrive(this.model.targetpoint.x,this.model.targetpoint.z)}
const a=new T.O,o=r.p.CalYRotateDirectionXZ(e.x,e.z,this.model.targetpoint.x,this.model.targetpoint.z)
a._fDir=f.W.transDir2UnityDir(o)+180,a._displayID=209001700,a._vPos.Set(this.model.targetpoint.x,this.model.targetpoint.z),a._ImportDisplayer=!0,
this.gateHandle=w.n.Instance_get().CreateDisplayObject(a,this.objId,-1,x.X.KARIMA_GATE,(0,_.v)(this.OnGateInit,this),null,null),this.gateObj=new D.M(this.gateHandle)}OnEffectEnd(){
N.N.inst.ShowMainView(),N.N.inst.HideGlobalCollider(),0!=this.gateHandle&&w.n.Instance_get().DeleteDisplayObject(this.gateHandle)}OnGateInit(){
const t=new m.P(this.model.targetpoint.x,this.model.targetpoint.y,this.model.targetpoint.z),e=m.P.zero_get()
v.X.Inst.PlayElement(A.k.KARIMA_THUNDER_EFFECT,0,0,t,e,0)
this.gateElementId=v.X.Inst.PlayElement(A.k.KARIMA_GATE_EFFECT,0,0,t,e,0),this.ClearEffectTimer(),this.SetEffectTimer()}SetEffectTimer(){
this.effectTimeId=k.C.Inst_get().SetInterval((0,_.v)(this.IntoMap,this),4e3)}ClearEffectTimer(){this.effectTimeId>0&&(k.C.Inst_get().ClearInterval(this.effectTimeId),
this.effectTimeId=-1)}IntoMap(){this.ClearEffectTimer(),C.Y.Inst.primaryRole.gotoPoint(this.model.targetpoint,S.m.Point,(0,_.v)(this.OnArrivedGate,this))}HandleClickGate(){
C.Y.Inst.primaryRole.gotoPoint(this.model.targetpoint,S.m.Point,(0,_.v)(this.OnArrivedGate,this))}OnArrivedGate(){this.CM_EnterKarima(this.model.enterMapId,this.model.mtctime),
this.ResetGateStatus()
const t=vt.U.inst.model.level_get(),e=nt.f.Inst().getItemById(t)
_t.t.inst.CM_RedPointClickHandle(Ct.t.KARIMA_BOSS),_t.t.inst.CM_RedPointClickHandle(Ct.t.KARIMA_BOSS+e.multipleKarima),St.f.Inst.SetState(Ct.t.KARIMA_BOSS,!1)}ResetGateStatus(){
0!=this.gateHandle&&(w.n.Instance_get().DeleteDisplayObject(this.gateHandle),this.gateHandle=0),this.gateElementId>0&&v.X.Inst.DeleteElement(this.gateElementId),
this.model.InEntering=!1}FindBoss(t){At.$.Inst().Transport(t)}FindMonster(){M._.getInst().endHang(),b.S.getInst().ClearLastAttackTarget()
let t=h.GF.INT32_MAX_VALUE_get(),e=0
const i=it.h.inst.GetSpawnItemsByMapId(o.b.Inst.currentMapId_get())
for(let s=0;s<=i.Count()-1;s++){if(!p.a.inst.getObjById(i[s].objectKey).IsBoss()){
const[n,l]=C.Y.Inst.PrimaryRole_get().GetPosXZ(),a=P.L.Instance_get().GetPath(n,l,i[s].x,i[s].y),[o,r]=y.jq.GetRealPathDis(a,n,l,i[s].x,i[s].y)
t>o&&(t=o,e=s)}}const s=i[e]
if(s){const t=new m.P(s.x,0,s.y)
C.Y.Inst.PrimaryRole_get().gotoPoint(t,S.m.eRole,(0,_.v)(this.OnArriveMonster,this),null,0,Q.I.responseRadius)}}OnArriveMonster(){M._.getInst().startHang(),M._.OnChangeTaret()}
HasTimes(t){return this.model.totalEnterTimes+t<=this.GetTotalCounts()}IsMaxLevelMap(t){return t==this.GetRecommendMap()}HandleMaxLevelMap(t,e){const i=new K.B
i.infoId="KARIMA:LOW_LEVEL"
const s=this.GetRecommendMap(),n=Dt.p.Inst_get().GetMapById(s)
i.replaceParams.Add(n.name),i.cancelText=(0,a.T)("坚持前往"),i.cancelHandle=(0,_.v)(this.HandleEnterTickets,this),i.cancelParam=new c.Z([t,e]),i.confirmHandle=(0,
_.v)(this.ShowMaxLevelMap,this),i.confirmParam=null,Z.t.Inst().Open(i)}ShowMaxLevelMap(){this.model.RaiseEvent(Lt.x.CHANGE_SHOW_MAP)}HasBuyTimes(){
return this.model.buytimes<this.GetTotalCounts()}HaveEnoughTickets(t){return this.GetConsumeCount(null,t)<=z.g.Inst_get().GetItemNum(this.GetTicketID())}HandleEnterMap(){
if(this.InKarima()){if(this.karimaFindBossControl.EnterMap(),this.InitRightView(),this.OpenKarimaStatusView(),0!=this.model.findBossId){
const t=Tt.C.Inst().getItemById(this.model.findBossId),e=new m.P(t.x_get(),0,t.y_get())
C.Y.Inst.PrimaryRole_get().gotoPoint(e,S.m.eRole,(0,_.v)(this.OnArriveBoss,this),null,0,Q.I.responseRadius)}}else this.model.ResetSingleData(),this.karimaFindBossControl.OutMap(),
this.CloseKaimaStatusView(),this.CloseRightView()}OnArriveBoss(t){const e=Tt.C.Inst().getItemById(this.model.findBossId)
null!=e&&1==e.autoHang_get()&&(this.model.findBossId=0,M._.getInst().startHang())}HandleDamageListHandler(){null==this.rightView?this.InitRightView():this.rightView.HandleDamages()
}InitRightView(){const t=new V.v
t.layerType=U.F.DefaultUI,t.positionType=j.$.eCustom,t.aniDir=F.K.Left,(0,s.Yp)(H.I.BossMemberDamagePanel,t,(0,_.v)(this.LoadRightViewComplete,this))}CloseRightView(){
this.CallDestoryRightView()}OpenKarimaStatusView(){if(null==this.karimaStatusView){const t=new V.v;(0,s.Yp)(H.I.KarimaStatusView,t,(0,_.v)(this.ShowStatusViewComplete,this))
}else this.karimaStatusView.OnAddToScene()}LoadRightViewComplete(t){gt.n.inst.InitCommonRightView(t)
const e=new V.v
e.positionType=j.$.eLeft,(0,s.Yp)(H.I.KarimaRightView,e,(0,_.v)(this.LoadRightViewComplete1,this))
return gt.n.inst.commonRightView}LoadRightViewComplete1(){const t=gt.n.inst.commonRightView
return this.rightView.OnAddToScene(),t.InitTeamTipType(0),t.SetData(this.rightView.msgContainer,this.rightView.teamContainer,this.rightView.teamBtn,this.rightView.taskBtn,this.rightView.bgBtn,this.rightView.teamColider,this.rightView.taskColider,this.rightView.taskSymbol,this.rightView.teamSymbol),
t.AddToScene(),t}CallDestoryRightView(){null!=this.rightView&&((0,s.sR)(H.I.KarimaRightView),gt.n.inst.DestroyCommonRightView())}CloseKaimaStatusView(){
null!=this.karimaStatusView&&this.OnDestoryKarima()}ShowStatusViewComplete(t){return this.karimaStatusView}OnDestoryKarima(){(0,s.sR)(H.I.KarimaStatusView)}InKarima(){
const t=o.b.Inst.currentMapId_get()
return this.mapList=this.GetKarimaMap(),null!=this.mapList&&this.mapList.IndexOf(t)>-1}GetDaliyTime(){return 0}GetTicketID(){return this.GetConfigIntContent("KARIMA:TICKET")}
GetConsumeCount(t,e){null==t&&(t=this.model.totalEnterTimes),null==e&&(e=this.model.mtctime)
let i=0
for(let s=1;s<=e;s++)if(t+=1,this.tickConsume.LuaDic_ContainsKey(t))i+=this.tickConsume[t]
else{let t=0
for(const[e,i]of(0,l.vy)(this.tickConsume))i>t&&(t=i)
i+=t}return i}GetKarimaMap(){if(null==this.mapList){this.mapList=new c.Z
const t=et.D.getInstance().getContent("MAP:KARIMA_IDS").getContent().stringVal,e=d.M.Split(t,",")
for(let t=0;t<=e.Count()-1;t++)this.mapList.Add(d.M.String2Int(e[t]))}return this.mapList}GetRecommendMap(){const t=C.Y.Inst.m_primaryRoleInfo.Level_get()
for(const[e,i]of(0,l.vy)(this.recommandList))if(t>=i[1]&&t<=i[2])return i[0]}GetRecommendBoss(t){null==t&&(t=this.GetRecommendMap())
C.Y.Inst.m_primaryRoleInfo.Level_get()
const e=this.model.GetBossInfoes(t)
for(const[t,i]of(0,l.vy)(e)){const t=Tt.C.Inst().getItemById(i.sortId)
t.GetRecommendLvArea()
if(i.attention)return t}if(e.Count()>0){return Tt.C.Inst().getItemById(e[0].sortId)}return null}GetConfigIntContent(t){
const e=et.D.getInstance().getContent(t).getContent().stringVal
return d.M.String2Int(e)}GetMonsterCursePoint(t){return this.InitCurseResouce(),tt.z.GetInstance().GenGetCfgByObjectId(t.monsterId_get()).cursePoint}GetMonsterCursePointById(t){
return this.InitCurseResouce(),tt.z.GetInstance().GenGetCfgByObjectId(t).cursePoint}InitCurseResouce(){null==tt.z.GetInstance()&&Y.Y.Inst.GetOrCreateCsv(n.h.eKarimaCurseResource)}
GetTotalCounts(){const t=vt.U.inst.model.level_get()
return this.GetVipCounts(t)}GetOwnerCounts(){return this.model.buytimes}GetVipCounts(t){const e=nt.f.Inst().getItemById(t)
return null!=e?e.karimaTimes:0}HaveEnoughGold(){const t=wt.J.GetGold(C.Y.Inst.PrimaryRoleInfo_get(),wt.J.GOLD_DIAMOND),e=this.GetTimesCost()
return-1!=e&&e<t}GetTimesCost(){const t=vt.U.inst.model.vipRes_get()
if(null==t.karimaTimes)return console.log("没有可购买次数"),-1
const e=new c.Z(t.karimaTimes)
return this.model.buytimes<e.Count()?e[this.model.buytimes]:e[e.Count()-1]}ExitMap(){const t=new yt.N,e=this.model.GetMaxCurPoint()-this.model.cursePoint
e<0?this.ExitKarimaOkHandler():(t.showText=(0,a.T)("您还有[047104]")+(e+(0,a.T)("点[-]怒气触发天罚\n是否确认离开卡利玛神庙？")),t.titleText=(0,a.T)("离开提示"),t.okhandler=(0,
_.v)(this.ExitKarimaOkHandler,this),t.tipstype=2,ft.y.inst.OpenCommonMessageTips(t))}ExitKarimaOkHandler(){this.CM_LeaveKarima()}PlayDieEffect(){const t=C.Y.Inst.primaryRoleList
for(const[e,i]of(0,l.vy)(t)){const t=new m.P
i.GetCurPos(t)
m.P.zero_get(),this.PlayOneEff(t,i)
m.P.Recyle(t)}}PlayOneEff(t,e){let i=0,s=new Ft.E
return s.source=e,s.target=e,s.effRole=e,s.speedRate=1,s.SetCfg(A.k.KARIMA_THUNDER_EFFECT),s.SetPoint(t.x,t.z),i=Ut.a.ins.showEffectByData(s),i}ClearDieTime(){
this.playDieTimeid>0&&(k.C.Inst_get().ClearInterval(this.playDieTimeid),this.playDieTimeid=0)}PlayerDie(){this.ClearDieTime()
const t=C.Y.Inst.primaryRoleList
for(const[e,i]of(0,l.vy)(t))i.die()}ReqGetItem(t=null){null==t?(this.model.OpenGainPanel=!0,
this.CM_GetItem()):0==this.lastGetItemTime?this.CM_GetItem():O.D.serverMSTime_get()-this.lastGetItemTime>3e3&&(this.CM_GetItem(),this.lastGetItemTime=O.D.serverMSTime_get())}
CM_GetItem(){const t=new rt.h
B.C.Inst.F_SendMsg(t)}MergeItems(t){const e=new u.X,i=t.Count()
for(let s=0;s<=i-1;s++)e.LuaDic_ContainsKey(t[s].modelId)}OpenGainView(){this.model.OpenGainPanel=!1
const t=new V.v
t.isShowMask=!0,t.viewClass=Mt.M,(0,s.Yp)(H.I.KarimaGainView,t)}GetItemCount(){let t=0
for(let e=0;e<=X.a.Inst_get().gainItemLis.Count()-1;e++){const i=X.a.Inst_get().gainItemLis[e]
i&&i.modelId&&(t+=i.num)}return t}OpenKarimaStarView(){It.r.Inst_get().RegMsgUID(-6515,-6516,H.I.eKarimaStarView,null,null,"今日之星加载中...")
const t=new dt.O
B.C.Inst.F_SendMsg(t)
const e=new V.v
e.isShowMask=!0,e.viewClass=bt.P,(0,s.Yp)(H.I.eKarimaStarView,e)}CloseKarimaStarView(){(0,s.sR)(H.I.eKarimaStarView)}SM_ShowTodayBestRecordHandler(t){
t&&(Lt.x.getInstance().ShowTodayBestRecord=t)}SM_KarimaMulDataHandler(t){Lt.x.getInstance().HandleMultimes(t.mul,t.time)}SM_KarimaCursePointHandler(e){
t.getInstance().HandleCursePoint(e.cursePoints)}SM_KarimaBossInfoHandler(t){Lt.x.getInstance().HandleBossInfoes(t.karimaBossList)}SM_KarimaInfoHandler(t){
Lt.x.getInstance().HandleKarimaInfo(t.todayEnterTimes)}SM_LeaveKarimaHandler(t){Lt.x.getInstance().punishTime=t.punishTime.ToNum(),
Lt.x.getInstance().leaveKarimaTime=t.leaveTime.ToNum(),Lt.x.getInstance().RaiseEvent(Lt.x.LEAVETIME_CHANGE)}CM_BuyKarimaTimes(t){const e=new lt.n
e.time=t,B.C.Inst.F_SendMsg(e)}CM_EnterKarima(t,e){if(0==J.E.Instance.HasSceneID(t,"CM_EnterKarima"))return
const i=new at.r
i.mapId=t,i.multiple=e,B.C.Inst.F_SendMsg(i)}CM_LeaveKarima(){const t=new ht.O
B.C.Inst.F_SendMsg(t)}CM_KarimaBossAttention(t,e){const i=new ot.a
i.bossId=t,i.type=e,B.C.Inst.F_SendMsg(i)}SM_KarimaGetItemsHandler(e){X.a.Inst_get().gainItemLis=e.itemList,
Lt.x.getInstance().OpenGainPanel?t.getInstance().OpenGainView():(St.f.Inst.SetState(Ct.t.KARIMA_GET_ITEM,!0),Lt.x.getInstance().RaiseEvent(Lt.x.GET_COUNT_UPDATE))}Test1(){return!0}
S_Test(){return!0}},Ht.Max_Dis=8,Ht.Min_Dis=4,Ht.Inst=null,jt(Nt=Ht,"getInstance",[I.Vx],Object.getOwnPropertyDescriptor(Nt,"getInstance"),Nt),
jt(Nt.prototype,"SM_ShowTodayBestRecordHandler",[Gt],Object.getOwnPropertyDescriptor(Nt.prototype,"SM_ShowTodayBestRecordHandler"),Nt.prototype),
jt(Nt.prototype,"SM_KarimaMulDataHandler",[Ot],Object.getOwnPropertyDescriptor(Nt.prototype,"SM_KarimaMulDataHandler"),Nt.prototype),
jt(Nt.prototype,"SM_KarimaCursePointHandler",[Et],Object.getOwnPropertyDescriptor(Nt.prototype,"SM_KarimaCursePointHandler"),Nt.prototype),
jt(Nt.prototype,"SM_KarimaBossInfoHandler",[Bt],Object.getOwnPropertyDescriptor(Nt.prototype,"SM_KarimaBossInfoHandler"),Nt.prototype),
jt(Nt.prototype,"SM_KarimaInfoHandler",[kt],Object.getOwnPropertyDescriptor(Nt.prototype,"SM_KarimaInfoHandler"),Nt.prototype),
jt(Nt.prototype,"SM_LeaveKarimaHandler",[xt],Object.getOwnPropertyDescriptor(Nt.prototype,"SM_LeaveKarimaHandler"),Nt.prototype),
jt(Nt.prototype,"SM_KarimaGetItemsHandler",[Vt],Object.getOwnPropertyDescriptor(Nt.prototype,"SM_KarimaGetItemsHandler"),Nt.prototype),Nt)},71453:(t,e,i)=>{i.d(e,{x:()=>T})
var s=i(38836),n=i(23833),l=i(97461),a=i(16812),o=i(98885),r=i(85602),h=i(79534),d=i(92679),c=i(85751),u=i(87923),m=i(85770),I=i(38501),g=i(31896),_=i(14792),p=i(62734),C=i(19276),S=i(97483),f=i(22046),y=i(15771),w=i(96964)
class D{constructor(){this.id=0,this.showText=""}Test1(){return!0}S_Test(){return!0}}class T extends a.k{constructor(){super(),this.totalEnterTimes=0,this.buytimes=0,
this.cursePoint=0,this.punishTime=0,this.leaveKarimaTime=0,this.attentionLis=null,this.bossDamages=null,this.selecteddata=null,this.myDamage=null,this.willdie=!1,this.findBossId=0,
this.targetpoint=null,this.enterMapId=0,this.InEntering=!1,this.isShowRed=!1,this.OpenGainPanel=!1,this.multTimeNum=0,this.multTimeTimes=0,this.maxMTC=null,this.mtctime=1,
this.isShowMultipleRed=!1,this.ShowTodayBestRecord=null,this.bosses=null,this.bossid=null,this.attentionLis=new r.Z,this.targetpoint=new h.P(10,0,12),
this.maxMTC=I.f.Inst().GetMaxMultiKarima()}static getInstance(){return null==T.Inst&&(T.Inst=new T),T.Inst}HandleBossInfoes(t){this.bosses=t,this.RaiseEvent(T.UPDATE_BOSS),
l.i.Inst.RaiseEvent(d.g.UPDATE_ATTENTION),this.RaiseEvent(T.ITEM_STATUS_UPDATE)}HandleKarimaInfo(t,e=null){this.totalEnterTimes=t,this.CheckRedPoint(),
this.RaiseEvent(T.UPDATE_TIMES)}HandleMultimes(t,e){this.multTimeNum=t,this.multTimeTimes=e,this.RaiseEvent(T.Update_Multi_Times)}CheckRedPoint(){const t=this.GetCanenterTimes()
!g.t.inst.IsHasClick(_.t.KARIMA_BOSS)&&t>0&&w.o.Inst.HaveEnoughTickets(1)?this.isShowRed=!0:this.isShowRed=!1,p.f.Inst.SetState(_.t.KARIMA_BOSS,this.isShowRed)}GetCanenterTimes(){
return w.o.getInstance().GetTotalCounts()-this.totalEnterTimes}HandleBossesDamage(t){this.RaiseEvent(T.UPDATE_DEMAGES)}GetBossInfoes(t){const e=new r.Z
if(null==this.bosses)return e
for(const[i,n]of(0,s.vy)(this.bosses)){const i=C.C.Inst().GetItemByMonsterId(n.bossId)
if(i.mapId_get()==t){const t=new S.g(f.l.KARIMABOSS,i.id_get(),i.monsterId_get(),n,!1)
t.attention=n.attention,e.Add(t)}}return e.Sort(this.CreateDelegate(this.SortBoss)),e}SortBoss(t,e){const i=n.a.inst.getObjById(t.monsterId),s=n.a.inst.getObjById(e.monsterId)
return i.level<s.level?-1:i.level>s.level?1:0}IsAttentionCfg(t){for(const[e,i]of(0,s.vy)(this.bosses))if(i.bossId==t.monsterId_get())return i.attention
return!1}GetMaxCurPoint(){return 100}ResetSingleData(){this.leaveKarimaTime=0,this.cursePoint=0,this.willdie=!1,this.findBossId=0,this.InEntering=!1,
w.o.getInstance().ResetGateStatus(),m.a.Inst_get().gainItemLis.Clear(),p.f.Inst.SetState(_.t.KARIMA_GET_ITEM,!1)}ResetModel(){this.ResetSingleData(),this.totalEnterTimes=0,
this.buytimes=0,this.cursePoint=0,this.leaveKarimaTime=0,this.attentionLis=new r.Z,this.bossDamages=null,this.bossid=null,this.selecteddata=null,this.myDamage=null,
this.enterMapId=0,this.isShowMultipleRed=!1,w.o.getInstance().karimaFindBossControl.OutMap()}HandleLeavKarima(t){this.leaveKarimaTime=t,this.RaiseEvent(T.LEAVETIME_CHANGE)}
MultiTimesCheck(t){return y.U.inst.model.vipRes_get().multipleKarima>=t.id}CheckKarimaMultipleRedPoint(){const t=y.U.inst.model.level_get(),e=I.f.Inst().getItemById(t)
e.multipleKarima>1&&!g.t.inst.IsHasClick(_.t.KARIMA_BOSS_MULTIPLE+e.multipleBoss)?this.isShowMultipleRed=!0:this.isShowMultipleRed=!1,
p.f.Inst.SetState(_.t.KARIMA_BOSS_MULTIPLE,this.isShowMultipleRed)}GetMTCData(){const t=new r.Z,e=y.U.inst.model.vipRes_get().multipleKarima
for(let i=1;i<=this.maxMTC;i++){const s=new D
s.id=i
let n="{0}倍挑战"
if(n=o.M.Replace(n,"{0}",u.l.GetChineseDoubleNum(i)),s.id<=e)s.showText=n
else{const t=I.f.Inst().GetNextTimeLevel("multipleKarima",s.id),e=o.M.Replace(`${c.u.BrightGrayColorStr2}v{0}开启${c.u.EndSymbol}`,"{0}",t)
s.showText=n+e}t.Add(s)}return t}GetCurMTCData(t){const e=y.U.inst.model.vipRes_get().multipleKarima
for(let i=0;i<=t.Count();i++)if(e==t[i].id)return t[i]
return null}Test1(){return T.getInstance().HandleMultimes(3,4),!0}S_Test(){return!0}}T.Inst=null,T.UPDATE_TIMES="UPDATE_TIMES",T.UPDATE_BOSS="UPDATE_BOSS",
T.UPDATE_DEMAGES="UPDATE_DEMAGES",T.CHANGE_SHOW_MAP="CHANGE_SHOW_MAP",T.CURSEPOINT_UPDATE="CURSEPOINT_UPDATE",T.LEAVETIME_CHANGE="LEAVETIME_CHANGE",T.BOSS_SELECT="BOSS_SELECT",
T.ITEM_STATUS_UPDATE="ITEM_STATUS_UPDATE",T.OUT_BOSS_RANGE="OUT_BOSS_RANGE",T.SCROLL_SELECT="SCROLL_SELECT",T.GET_COUNT_UPDATE="GET_COUNT_UPDATE",
T.Update_Multi_Times="Update_Multi_Times",T.Multi_Times_Ids=new r.Z([10816])},18753:(t,e,i)=>{i.d(e,{L:()=>st})
var s,n,l=i(6847),a=i(83908),o=i(49655),r=i(46282),h=i(38836),d=i(86133),c=i(43662),u=i(23833),m=i(26055),I=i(87722),g=i(32697),_=i(20583),p=i(31546),C=i(97461),S=i(68662),f=i(82737),y=i(5924),w=i(85682),D=i(5494),T=i(98885),A=i(85602),v=i(79534),L=i(70850),M=i(63076),b=i(67885),R=i(18152),P=i(53905),G=i(92679),O=i(85751),E=i(87923),B=i(27122),k=i(65772),x=i(48933),V=i(47786),N=i(38501),H=i(68637),U=i(31896),F=i(14792),j=i(62734),Y=i(60647),z=i(13487),q=i(21334),Z=i(19276),K=i(88934),$=i(12417),W=i(24087),X=i(6251),Q=i(15771),J=i(96964),tt=i(71453),et=i(70583),it=i(57148)
let st=(0,l.s_)(o.o.KarimaBossView,r.Z.ui_treasure_karima_ry).waitPrefab(b.S.modulePathList).register()((n=class t extends((0,a.Ri)()){constructor(...t){super(...t),this.cfg=null,
this.mapid=0,this.tModel=null,this.control=null,this.model=null,this.itemHeight=114,this.itemoffsets=null,this.selectedIndex=0,this.scrollIndex=0,this.initPosY=null,
this.initScrollHeight=null,this.registerUIScId=null,this.registerUIId=null,this.sortId=null,this.bossdata=null,this.bosses=null,this.popitem=null,this.dragAmount=null,
this.lastMonId=null,this.boss=null,this._lefttimeintervalId=null,this.time=null,this.displayUIAvatarModel=null}_initBinder(){super._initBinder(),this.tModel=$._.Inst(),
this.control=J.o.getInstance(),this.model=tt.x.getInstance(),this.itemoffsets=new A.Z([25,0,25,50])}InitView(){super.InitView(),
this.dropGrid.SetInitInfo("ui_treasure_bossdropitem_big",this.CreateDelegate(this.OnRewardRefreshFun)),
this.bossTable.SetInitInfo("ui_treasure_karimaitem_ry",this.CreateDelegate(this.CreateItemHandler)),this.bossTable.OnReposition_set(this.CreateDelegate(this.OnReposition)),
this.initPosY=this.bossScrollView.content.transform.GetLocalPosition().y,this.initScrollHeight=this.bossScrollPanel.content.transform.height,this.registerUIScId=w.D.KarimaBoss,
this.registerUIId=D.I.TreasurePanel,this.gridContainer.SetActive(!1),this.multitimelab.textSet(""),
this.selectGrid.SetInitInfo("ui_select_dun_times_item",this.CreateDelegate(this.OnCreateItem))}OnCreateItem(t){const e=t[0].getCNode(it.B)
return e.clickHandler=this.CreateDelegate(this.OnPopSelected),e}CreateItemHandler(t){return t[0].getCNode(et.U)}AddBtnClick(){this.CheckGuide2(),this.control.GotoVIP()}
ShowVIPTimesInfo(){let t=Y.p.inst.GetClientLogicSetting(z.R.KARIMA_MUL)
0==t&&(t=1),tt.x.getInstance().mtctime=Number(t),this.timesContainer.SetActive(!0),this.currentSelectTimesLabel.textSet(`${E.l.GetChineseNum(tt.x.getInstance().mtctime)}倍挑战`)
const e=N.f.Inst().GetMultipleKarimaList()
this.selectGrid.data_set(e),this.UpdateTimesAndCost()}OnRareDropClick(t,e){K.$.inst.OpenDropTip()}OnRewardRefreshFun(t){return t[0].getCNode(W.j)}OnAddToScene(){
this.bossBg2.spriteNameSet("ryworldboss_sp_0037"),this.node.SetActive(!0),this.RemoveLis(),this.AddLis(),this.SelectedDefault(),this.SetData()
j.f.Inst.GetData(F.t.KARIMA_BOSS)
this.m_handlerMgr.AddRedPointTipObj(F.t.KARIMA_BOSS,this.redPoint,null),this.multipleRedPoint.SetActive(tt.x.getInstance().isShowMultipleRed)}AddLis(){
this.m_handlerMgr.AddClickEvent(this.attentionBtn,this.CreateDelegate(this.OnAttentionClick)),this.m_handlerMgr.AddClickEvent(this.tipBtn,this.CreateDelegate(this.OnTipClick)),
this.m_handlerMgr.AddClickEvent(this.searchForBossBtn,this.CreateDelegate(this.OnBossClick)),
this.m_handlerMgr.AddClickEvent(this.addtimesbtn,this.CreateDelegate(this.AddBtnClick)),this.m_handlerMgr.AddClickEvent(this.rareDropBtn,this.CreateDelegate(this.OnRareDropClick)),
this.m_handlerMgr.AddClickEvent(this.todaystar,this.CreateDelegate(this.OntodaystarClick)),
C.i.Inst.AddEventHandler(G.g.UPDATE_ATTENTION,this.CreateDelegate(this.OnUpdateAttentionInfo)),
this.m_handlerMgr.AddNotifyEvent(tt.x.getInstance(),tt.x.Update_Multi_Times,this.CreateDelegate(this.OnMultTimesChange)),
this.m_handlerMgr.AddNotifyEvent(tt.x.getInstance(),G.g.POPITEM_SELECT,this.CreateDelegate(this.OnPopSelected)),
tt.x.getInstance().AddEventHandler(tt.x.CHANGE_SHOW_MAP,this.CreateDelegate(this.ChangeShowMap)),
tt.x.getInstance().AddEventHandler(tt.x.BOSS_SELECT,this.CreateDelegate(this.BossSelectHandler)),
tt.x.getInstance().AddEventHandler(tt.x.UPDATE_TIMES,this.CreateDelegate(this.UpdateTimesAndCost)),
this.m_handlerMgr.AddClickEvent(this.showSelect.node,this.CreateDelegate(this.OnShowSelectClick)),
this.m_handlerMgr.AddClickEvent(this.selectCollision,this.CreateDelegate(this.OnHideSelectClick)),
this.bossScrollView.RegistonDragingMoving(this.CreateDelegate(this.OnDragingMoving)),C.i.Inst.AddEventHandler(G.g.BAG_UPDATE,this.CreateDelegate(this.BagUpdate))}RegGuide(){
H.c.Inst.RegGameObject(w.D.UI_BOSS_KLM_CHANEAL_BTN,this.searchForBossBtn,this.sortId),H.c.Inst.RegGameObject(w.D.UI_BOSS_KLM_FOLLOW_BTN,this.attentionBtn.node,this.sortId),
H.c.Inst.RegGameObject(w.D.UI_BOSS_KLM_ADD_BTN,this.addtimesbtn.node,this.sortId)}UnRegGuide(){
null!=this.sortId&&(H.c.Inst.UnRegGameObject(w.D.UI_BOSS_KLM_CHANEAL_BTN,this.sortId),H.c.Inst.UnRegGameObject(w.D.UI_BOSS_KLM_FOLLOW_BTN,this.sortId))}CheckGuide(){
E.l.CheckBtnClickTrigger(w.D.UI_BOSS_KLM_CHANEAL_BTN,this.sortId)}CheckGuide1(){E.l.CheckBtnClickTrigger(w.D.UI_BOSS_KLM_FOLLOW_BTN,this.sortId)}CheckGuide2(){
E.l.CheckBtnClickTrigger(w.D.UI_BOSS_KLM_ADD_BTN,this.sortId)}BagUpdate(){this.UpdateTimesAndCost()}OntodaystarClick(){J.o.getInstance().OpenKarimaStarView()}OnBossClick(){
this.CheckGuide(),this.control.EnterKarima(this.bossdata,this.mapid,this.model.mtctime)}BossSelectHandler(t){const e=t
this.bossdata=e,this.model.selecteddata=this.bossdata,this.cfg=Z.C.Inst().getItemById(this.bossdata.sortId),this.selectedIndex=this.GetBossDataIndex(),this.CalculateScrollIndex(),
this.SetData(),this.ChangeScrollPosByIndex(this.selectedIndex)}OnShowSelectClick(){const t=!this.gridContainer.active
if(this.gridContainer.SetActive(t),t){if(x.I.calVec0.Set(0,0,0),this.arrowTips.eulerAngles=x.I.calVec0,tt.x.getInstance().isShowMultipleRed){
const t=Q.U.inst.model.level_get(),e=N.f.Inst().getItemById(t)
U.t.inst.CM_RedPointClickHandle(F.t.KARIMA_BOSS_MULTIPLE+e.multipleKarima,!0),tt.x.getInstance().isShowMultipleRed=!1,j.f.Inst.SetState(F.t.KARIMA_BOSS_MULTIPLE,!1),
this.multipleRedPoint.SetActive(!1)}}else x.I.calVec0.Set(0,0,180),this.arrowTips.eulerAngles=x.I.calVec0}OnHideSelectClick(){this.OnShowSelectClick()}OnDragingMoving(){
this.DoScroll()}OnPopSelected(t){Y.p.inst.SendClientLogicSetting(z.R.KARIMA_MUL,t.multipleKarima),this.model.mtctime=t.multipleKarima,
this.currentSelectTimesLabel.textSet(`${E.l.GetChineseNum(t.multipleKarima)}倍挑战`),this.OnShowSelectClick(),this.model.CheckRedPoint(),this.UpdateTimesAndCost()}HandleScroll(){}
CalcScroll(){return this.scrollIndex}OnDragFinished(){this.ChangeScrollPosByIndex(this.scrollIndex)}ChangeScrollPosByIndex(t){if(this.DoScroll(t),
this.selectedIndex+2>=this.bosses.Count())return
const e=this.bossScrollView.content.transform.GetLocalPosition()
e.y=this.itemHeight*(t-1>0?t-1:0),this.bossScrollView.content.SetLocalPositionXYZ(0,e.y,0)}DoScroll(t){if(null==t){const e=this.bossScrollView.content.transform.GetLocalPosition()
t=(e.y-this.initPosY>0&&e.y-this.initPosY||0)/this.itemHeight}const e=this.bossTable.itemList,i=e?e.Count():0
for(let s=0;s<=i-1;s++){const i=s-t
if(i<0)e[s].SetIndex(0,0,1)
else if(i<=3){const t=Math.floor(i),n=i-t
let l=t+1
l>3&&(l=3),e[s].SetIndex(t,l,n)}else e[s].SetIndex(3,3,1)}}OnReposition(){this.ChangeScrollPosByIndex(this.scrollIndex),this.bossScrollView.ResetPosition()}RemoveLis(){
C.i.Inst.RemoveEventHandler(G.g.UPDATE_ATTENTION,this.CreateDelegate(this.OnUpdateAttentionInfo)),C.i.Inst.RemoveEventHandler(G.g.BAG_UPDATE,this.CreateDelegate(this.BagUpdate)),
tt.x.getInstance().RemoveEventHandler(tt.x.CHANGE_SHOW_MAP,this.CreateDelegate(this.ChangeShowMap)),
tt.x.getInstance().RemoveEventHandler(tt.x.BOSS_SELECT,this.CreateDelegate(this.BossSelectHandler)),
tt.x.getInstance().RemoveEventHandler(tt.x.UPDATE_TIMES,this.CreateDelegate(this.UpdateTimesAndCost)),
this.bossScrollView.RemoveonDragFinished(this.CreateDelegate(this.OnDragFinished)),this.bossScrollView.RemoveonDragMoving(this.CreateDelegate(this.OnDragingMoving)),
this.UnRegGuide()}OnAttentionClick(){this.CheckGuide1()
let t=0
t=this.selectSpt.activeInHierarchy?0:1,this.control.KarimaBossAttention(this.cfg.monsterId_get(),t)}OnTipClick(){const t=new P.w
t.position=new v.P(-385,320,0),t.width=450,t.infoId="BOSS：KALIMA_TIPS1",k.Q.Inst_get().Open(t)}OnUpdateAttentionInfo(){const t=this.model.IsAttentionCfg(this.cfg)
this.selectSpt.SetActive(t)}ChangeShowMap(){this.SelectedDefault(),this.SetData()}SetData(){this.UpdateBossView(),this.UpdateDrop(),this.UpdateTimesAndCost(),
this.UpdateMultiTimes(),this.ShowVIPTimesInfo()}OnMultTimesChange(){this.UpdateMultiTimes(),this.UpdateDrop()}UpdateMultiTimesChallenge(){const t=tt.x.getInstance().GetMTCData()
this.popitem.SetData(t),this.popitem.SetSelect(t[0],!1)}UpdateMultiTimes(){if(this.model.multTimeTimes<=0)this.multitimelab.textSet("")
else{const t=E.l.getNumStr(this.model.multTimeNum,!0),e=E.l.Substitute(`剩余{0}倍次数：${O.u.GreenColorStr2}{1}[-]`,new A.Z([t,this.model.multTimeTimes]))
this.multitimelab.textSet(e)}}SelectedDefault(){this.mapid=J.o.Inst.GetRecommendMap(),this.cfg=J.o.Inst.GetRecommendBoss(this.mapid),this.RefreshMapTitle(),this.RefreshBossGrid(),
this.model.RaiseEvent(tt.x.SCROLL_SELECT,this.bossdata)}RefreshMapTitle(){const t=J.o.getInstance().GetKarimaMap()
q.p.Inst_get().GetMapById(this.mapid)
this.layerName.textSet((0,d.T)("首领列表"))
const e=t.IndexOf(this.mapid),i=0==e
X.d.SetGray(this.layerBtnDown,i)
const s=e>=t.Count()
X.d.SetGray(this.layerBtnUp,s)}RefreshBossGrid(){const t=new A.Z,e=this.model.GetBossInfoes(this.mapid)
for(const[i,s]of(0,h.V5)(e))t.Add(s)
this.dragAmount=this.tModel.GetDragAmount(t.Count(),this.tModel.karimaDefaultIndex,$._.BOSS_NUM_PER_PAGE,2),this.bosses=e,this.bossTable.data_set(t),
this.selectedIndex=this.GetBossDataIndex(),this.bossdata=this.bosses[this.selectedIndex],this.model.selecteddata=this.bossdata,this.CalculateScrollIndex(),
this.ChangeScrollPosByIndex(this.scrollIndex)}CalculateScrollIndex(){this.scrollIndex=this.selectedIndex}GetBossDataIndex(){
for(let t=0;t<=this.bosses.Count()-1;t++)if(this.cfg.id_get()==this.bosses[t].sortId)return t}UpdateBossView(e){this.UnRegGuide(),null==e&&(e=this.cfg),
this.sortId=this.cfg.id_get(),this.RegGuide(),this.OnUpdateAttentionInfo()
const i=this.control.GetMonsterCursePoint(e)
if(this.cursepointlab.textSet(i),this.UpdateTime(),this.lastMonId!=e.monsterId_get()){this.PlayEffect(),c.M.Instance_get().ActiveStage(t.STAGE_ID)
const i=u.a.getInst().getObjById(e.monsterId_get())
if(null!=i){this.bossName.textSet(`${this.cfg.name_get()}Lv.${i.level}`)
const s=new m.O
this.ClearBoss(),this.boss=B.Q.Inst().GetObjectByName("MonsterCharacter",I._),this.boss.Info_set(s)
const n=new p.O
n._displayID=i.displayId,n._world=c.M.Instance_get().GetStageWorldType(t.STAGE_ID),n._bNeedWaitAnime=!0,n.shiledType=f.g.DT_NONE
const l=e.GetPos()
e.GetRotate()
this.boss.InitByInfo(i,n,l[1]),c.M.Instance_get().SetDisplayObject(t.STAGE_ID,this.boss.MainRole_get().handle,0),this.modelContent.node.removeAllChildren(),
this.displayUIAvatarModel?this.displayUIAvatarModel=_.x.inst.SetUIAvatarData(n,g.v.monster,this.displayUIAvatarModel):(this.displayUIAvatarModel=_.x.inst.SetUIAvatarData(n,g.v.monster),
this.displayUIAvatarModel.SetTarget(this.modelContent,!0),this.displayUIAvatarModel.setUpDragNode(this.bossTexture.node)),this.displayUIAvatarModel.SetScale(.8,.8),
this.displayUIAvatarModel.SetDir(4),this.displayUIAvatarModel.UpdateUIAvatar()}}this.lastMonId=e.monsterId_get()}ClearBoss(){null!=this.boss&&(this.boss.Destroy(),this.boss=null)}
PlayEffect(){this.worldBossEffect.SetActive(!0),this.worldBossEffect.replay(),this.tweenScale.ResetToBeginning(),this.tweenScale.PlayForward(),this.tweenAlpha.ResetToBeginning(),
this.tweenAlpha.PlayForward()}UpdateTimesAndCost(){const t=J.o.getInstance().GetTicketID(),e=new M.M(t),i=L.g.Inst_get().GetItemNum(t),s=J.o.Inst.GetConsumeCount()
i>=s?this.costCount.textSet(`${i}/${s}`):this.costCount.textSet(`[${E.l.txtRedStr}]${i}/${s}[-]`),e.guideId=w.D.UI_BOSS_KLM_COST_ITEM,e.guideParam=t,this.costitem.SetData(e)
const n=J.o.getInstance().GetTotalCounts(),l=this.model.totalEnterTimes
this.timescountlab.textSet(`${n-l}/${n}`);-1==J.o.getInstance().GetNextVipLevel()?this.addtimesbtn.node.SetActive(!1):this.addtimesbtn.node.SetActive(!0)}UpdateDrop(){
const t=this.tModel.GetRewardLis(this.cfg.id_get())
if(t.Count()>0){for(let e=0;e<=t.Count()-1;e++)t[e].iconType=R.s.KARIMA_ICON_TYPE,t[e].iconExtraData=this.model.multTimeTimes
this.dropObj.SetActive(!0),this.dropGrid.data_set(t)}else this.dropObj.SetActive(!1)}UpdateTime(){this.ClearTimer(),
null!=this.bossdata.info?(this._lefttimeintervalId=y.C.Inst_get().SetInterval(this.CreateDelegate(this.UpdateTimeHandler),1e3),
this.time=(this.bossdata.info.refreshTime.ToNum()-S.D.serverMSTime_get())/1e3+1,this.UpdateTimeHandler()):this.relivetime.textSet("")}ClearTimer(){
y.C.Inst_get().ClearInterval(this._lefttimeintervalId),this._lefttimeintervalId=-1}UpdateTimeHandler(){if(this.time<=0)return this.relivetime.textSet(`[047104]${(0,
d.T)("已复活")}[-]`),void this.ClearTimer()
this.time-=1
let t=V.x.Inst().getItemStrById(111026)
const e=E.l.GetDateFormat(this.time)
t=T.M.Replace(t,"{0}",e),this.relivetime.textSet(`[962424]${t}[-]`)}Clear(){this.RemoveLis(),this.ClearTimer(),this.bossShowItem.Clear(),this.boss,this.ClearBoss(),
this.lastMonId=null,null!=this.m_handlerMgr&&this.m_handlerMgr.Clear(),super.Clear(),this.node.SetActive(!1)}Destroy(){}Test1(){return!0}S_Test(){return!0}},n.STAGE_ID=84,s=n))||s
},70583:(t,e,i)=>{i.d(e,{U:()=>T})
var s,n,l=i(18998),a=i(83908),o=i(86133),r=i(23833),h=i(68662),d=i(5924),c=i(85682),u=i(28192),m=i(98130),I=i(98885),g=i(85602),_=i(21729),p=i(87923),C=i(47786),S=i(68637),f=i(19276),y=i(71453)
const{ccclass:w,property:D}=l._decorator
let T=w("KarimaBossitem")((n=class t extends((0,a.yk)()){constructor(...t){super(...t),this.sortId=null,this.bossData=null,this.cfg=null,this.objRes=null,
this._lefttimeintervalId=null,this.time=null,this._m_handlerMgr=null}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=u.h.Get()),this._m_handlerMgr}InitView(){
super.InitView(),this.selectbg.SetActive(!1)}Clear(){this.ClearTimer(),this.RemoveLis()}SetIndex(e,i,s){
const n=this.content.node.transform.GetLocalPosition(),l=_.N.Lerp(t.offsetlist[e],t.offsetlist[i],s)
n.x=m.GF.INT(l),this.content.node.transform.SetLocalPositionXYZ(n.x,0,0)}RegGuide(){S.c.Inst.RegGameObject(c.D.UI_BOSS_KLM_BOSS_ICON,this.node,this.sortId)}UnRegGuide(){
null!=this.sortId&&(S.c.Inst.UnRegGameObject(c.D.UI_BOSS_KLM_BOSS_ICON,this.sortId),this.sortId=null)}CheckGuide(){p.l.CheckBtnClickTrigger(c.D.UI_BOSS_KLM_BOSS_ICON,this.sortId)}
SetData(t){this.AddLis()
const e=t
this.bossData=e,this.UnRegGuide(),this.sortId=e.sortId,this.RegGuide(),this.cfg=f.C.Inst().getItemById(e.sortId),this.objRes=r.a.getInst().getObjById(e.monsterId),
this.icon.spriteNameSet(this.objRes.headResources),
this.UpdateStateObj(),null!=y.x.getInstance().selecteddata&&(y.x.getInstance().selecteddata.sortId==this.bossData.sortId?this.SetSelected(!0):this.SetSelected(!1))}AddLis(){
this.m_handlerMgr.AddClickEvent(this,this.CreateDelegate(this.ClickHandler)),y.x.getInstance().AddEventHandler(y.x.BOSS_SELECT,this.CreateDelegate(this.OnBossSelected)),
y.x.getInstance().AddEventHandler(y.x.SCROLL_SELECT,this.CreateDelegate(this.OnBossSelected))}SetSelected(t){this.selectbg.SetActive(t)}ClickHandler(){this.CheckGuide(),
y.x.getInstance().RaiseEvent(y.x.BOSS_SELECT,this.bossData)}UpdateStateObj(t){const e=this.cfg.name_get()
this.namelab.textSet(e),this.UpdateDes(),this.UpdateTime()}OnBossSelected(t){t.sortId==this.bossData.sortId?this.SetSelected(!0):this.SetSelected(!1)}UpdateTime(){
this.ClearTimer(),null!=this.bossData.info?(this._lefttimeintervalId=d.C.Inst_get().SetInterval(this.CreateDelegate(this.UpdateTimeHandler),1e3),
this.time=(this.bossData.info.refreshTime.ToNum()-h.D.serverMSTime_get())/1e3+1,this.time>0?this.deadicon.SetActive(!0):this.deadicon.SetActive(!1),
this.UpdateTimeHandler()):this.statuslab.textSet("")}ClearTimer(){d.C.Inst_get().ClearInterval(this._lefttimeintervalId),this._lefttimeintervalId=-1}UpdateTimeHandler(){
if(this.time<=0)return this.statuslab.textSet(`[047104]${(0,o.T)("已复活")}[-]`),this.deadicon.SetActive(!1),this.ClearTimer(),void this.UpdateDes()
this.time-=1
let t=C.x.Inst().getItemStrById(111026)
const e=p.l.GetDateFormat(this.time)
t=I.M.Replace(t,"{0}",e),this.statuslab.textSet(`[962424]${t}[-]`)}UpdateDes(){let t=null
t="[ceccc5]"
let e=""
e=`Lv.${this.objRes.level}`,this.levellab.textSet(`[ceccc5]${e}[-]`)}Destroy(){}RemoveLis(){
y.x.getInstance().RemoveEventHandler(y.x.BOSS_SELECT,this.CreateDelegate(this.OnBossSelected)),
y.x.getInstance().RemoveEventHandler(y.x.SCROLL_SELECT,this.CreateDelegate(this.OnBossSelected)),this.UnRegGuide()}Test1(){return!0}S_Test(){return!0}},
n.offsetlist=new g.Z([20,0,20,50]),s=n))||s},73670:(t,e,i)=>{var s,n=i(18998),l=i(83908),a=i(98800),o=i(5924),r=i(87923),h=i(20193),d=i(27610),c=i(96964),u=i(71453)
const{ccclass:m,property:I}=n._decorator
m("KarimaDemageView")(s=class extends((0,l.yk)()){constructor(...t){super(...t),this.progressWidth=null,this.model=null,this.intervalId=null}InitView(){super.InitView(),
this.progressWidth=this.myPercent.width(),this.grid.SetInitInfo("ui_bossassist_item",this.CreateDelegate(this.OnTeamDamageRankItemRefreshFun)),
this.grid.OnReposition_set(this.CreateDelegate(this.OnReposition)),this.model=u.x.getInstance()}OnReposition(){this.scrollview.ResetPosition()}OnAddToScene(){
o.C.Inst_get().ClearInterval(this.intervalId),this.intervalId=o.C.Inst_get().SetInterval(this.CreateDelegate(this.RankReq),1e3),this.RefreshView()}RankReq(){h.D.Inst_get().bossId}
RefreshView(){if(null!=h.D.inst.bossId){const t=a.Y.Inst.getMonsterById(h.D.inst.bossId)
if(null!=t){const e=t.Cfg_get().id,i=c.o.getInstance().GetMonsterCursePointById(e)
this.cursepointlab.textSet(i.toString())}if(this.grid.data_set(h.D.Inst_get().GetTeamRankData()),null!=h.D.inst.myDamage){
const t=h.D.inst.GetFirstOneDamage(),e=h.D.inst.myDamage.ToNum(),i=e/t
this.mydamage.textSet(r.l.GetRuleDecimalValByFloorToInt(e,1)),this.myPercent.widthSet(i*this.progressWidth),this.myPercent.SetActive(!0)}else this.mydamage.textSet(""),
this.myPercent.SetActive(!1)}else this.cursepointlab.textSet("0"),this.mydamage.textSet("0"),this.myPercent.SetActive(!1),this.grid.Clear()}OnTeamDamageRankItemRefreshFun(t){
return t[0].getCNode(d.X)}HandleDamages(){this.RefreshView()}Clear(){o.C.Inst_get().ClearInterval(this.intervalId),this.intervalId=-1}Destroy(){}Test1(){return!0}S_Test(){return!0}
})},57693:(t,e,i)=>{i.d(e,{M:()=>p})
var s,n=i(6847),l=i(83908),a=i(49655),o=i(46282),r=i(31222),h=i(5494),d=i(60130),c=i(85602),u=i(63076),m=i(75696),I=i(85770),g=i(14792),_=i(62734)
let p=(0,n.s_)(a.o.KarimaGainView,o.Z.ui_copybase_gainview).register()(s=class extends((0,l.Ri)()){InitView(){super.InitView(),this.grid.SetInitInfo("ui_baseitem",null,m.j)}
OnAddToScene(){this.AddLis(),_.f.Inst.SetState(g.t.KARIMA_GET_ITEM,!1),this.RefreshReward()}RefreshReward(){const t=new c.Z
if(null!=I.a.Inst_get().gainItemLis)for(let e=0;e<=I.a.Inst_get().gainItemLis.Count()-1;e++){const i=I.a.Inst_get().gainItemLis[e]
if(i&&i.modelId){const e=new u.M(i.modelId)
e.serverData_set(i),e.isShowAccess=!1,t.Add(e)}}this.hasReward.SetActive(!1),this.noReward.SetActive(!1)
const e=this.grid.node.transform.GetLocalPosition()
t.Count(),e.x=0,null!=t&&t.Count()>0?(this.hasReward.SetActive(!0),I.a.Inst_get().sortReward(t),this.grid.data_set(t)):this.noReward.SetActive(!0),
this.grid.node.transform.SetLocalPosition(e)}AddLis(){this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.PlayNormalTween)),
this.m_handlerMgr.AddClickEvent(this.closeBtn2,this.CreateDelegate(this.OnCloseBtn))}PlayNormalTween(){d.O.PlayNormalCloseTween(this.closeBtn.node,this.OnCloseBtn)}RemoveLis(){}
OnCloseBtn(){r.N.inst.CloseById(h.I.KarimaGainView)}Clear(){this.RemoveLis(),this.grid.Clear(),super.Clear()}Destroy(){}Test1(){return!0}S_Test(){return!0}})||s},5988:(t,e,i)=>{
i.d(e,{u:()=>u})
var s,n=i(6847),l=i(83908),a=i(49655),o=i(46282),r=i(86133),h=i(5924),d=i(5246),c=i(65550)
let u=(0,n.s_)(a.o.eKarimaRelivePanel,o.Z.ui_treasure_karima_relivepanel).register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),this.countDownNum=null,
this.loopInterval=null}HandleLoopTime(){d.N.Inst_get()
this.countDownNum-=1,this.countDownNum<0&&(this.countDownNum=0,d.N.Inst_get().sendReliveMsg(1),this.Close())
const t=this.countDownNum
this.label.textSet(t)}Close(){h.C.Inst_get().ClearInterval(this.loopInterval),this.loopInterval=-1,this.label.textSet("10"),c.y.inst.closeCommonMessageTips()}InitTimer(){
this.countDownNum=10,this.ClearTimer(),this.loopInterval=h.C.Inst_get().SetInterval(this.CreateDelegate(this.HandleLoopTime),1e3)}OnAddToScene(){this.label.textSet("10")
const t=d.N.Inst_get().GetMsg()
this.murderer.textSet((0,r.T)("您被[de2524] ")+(t.lastAttackerName+(0,r.T)(" [-]击败了"))),this.InitTimer()}ClearTimer(){
-1!=this.loopInterval&&(h.C.Inst_get().ClearInterval(this.loopInterval),this.loopInterval=-1)}InitView(){super.InitView()}Clear(){super.Clear()}Destroy(){}Test1(){return!0}
S_Test(){return!0}})||s},71161:(t,e,i)=>{i.d(e,{q:()=>f})
var s,n=i(18998),l=i(83908),a=i(86133),o=i(23833),r=i(68662),h=i(5924),d=i(28192),c=i(98885),u=i(85602),m=i(85751),I=i(87923),g=i(47786),_=i(19276),p=i(96964)
const{ccclass:C,property:S}=n._decorator
let f=C("KarimaRightStatusItem")(s=class extends((0,l.yk)()){constructor(...t){super(...t),this.bossData=null,this.time=null,this._lefttimeintervalId=null,this._m_handlerMgr=null}
get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=d.h.Get()),this._m_handlerMgr}InitView(){super.InitView()}Clear(){this.ClearTimer()}SetData(t){
this.m_handlerMgr.AddClickEvent(this.statusbtn,this.CreateDelegate(this.FindBoss)),this.bossData=t
const e=_.C.Inst().GetItemByBossId(t.sortId)
this.cursepoint.textSet(p.o.getInstance().GetMonsterCursePointById(e.monsterId_get()).toString())
let i=(0,a.T)("【{0}级】{1}")
const s=o.a.getInst().getObjById(t.monsterId)
i=I.l.Substitute(i,new u.Z([s.level.toString(),e.name_get().toString()])),this.desc.textSet(i),this.UpdateTime()}FindBoss(){p.o.getInstance().FindBoss(this.bossData.sortId)}
UpdateTime(){this.ClearTimer(),null!=this.bossData.info?(this.time=(this.bossData.info.refreshTime.ToNum()-r.D.serverMSTime_get())/1e3+1,
this.time>0?(this._lefttimeintervalId=h.C.Inst_get().SetInterval(this.CreateDelegate(this.UpdateTimeHandler),1e3),this.statusbtn.node.SetActive(!1),
this.UpdateTimeHandler()):(this.statusbtn.node.SetActive(!0),this.relivetime.textSet(""))):this.relivetime.textSet("")}ClearTimer(){
h.C.Inst_get().ClearInterval(this._lefttimeintervalId),this._lefttimeintervalId=-1}UpdateTimeHandler(){if(this.time<=0)return this.relivetime.textSet(""),
this.statusbtn.node.SetActive(!0),void this.ClearTimer()
this.time-=1
let t=g.x.Inst().getItemStrById(111026)
this.time<0&&(this.time=0)
const e=I.l.GetDateFormat(this.time)
t=c.M.Replace(`${m.u.BrightRedColorStr2}${t}[-]`,"{0}",e),this.relivetime.textSet(t)}Destroy(){}Test1(){return!0}S_Test(){return!0}})||s},4564:(t,e,i)=>{
var s,n=i(18998),l=i(83908),a=i(23833),o=i(68662),r=i(13687),h=i(28192),d=i(98885),c=i(55552),u=i(96964),m=i(71453),I=i(71161)
const{ccclass:g,property:_}=n._decorator
g("KarimaRightStatusView")(s=class extends((0,l.yk)()){constructor(...t){super(...t),this._m_handlerMgr=null}get m_handlerMgr(){
return this._m_handlerMgr||(this._m_handlerMgr=h.h.Get()),this._m_handlerMgr}InitView(){super.InitView(),
this.grid.SetInitInfo("ui_karima_rightstatusitem",this.CreateDelegate(this.CreateItemHandler)),this.grid.OnReposition_set(this.CreateDelegate(this.OnReposition))}OnReposition(){
this.scrollview.ResetPosition()}Clear(){m.x.getInstance().RemoveEventHandler(m.x.ITEM_STATUS_UPDATE,this.CreateDelegate(this.ItemStatusUpdateHandler))}CreateItemHandler(t){
return t[0].getCNode(I.q)}OnAddToScene(){m.x.getInstance().AddEventHandler(m.x.ITEM_STATUS_UPDATE,this.CreateDelegate(this.ItemStatusUpdateHandler)),
this.m_handlerMgr.AddClickEvent(this.monBtn,this.CreateDelegate(this.FindMonster))
const t=this.GetDataes()
this.grid.data_set(t),this.grid.Reposition()
let e=0
const i=c.h.inst.GetSpawnItemsByMapId(r.b.Inst.currentMapId_get())
for(let t=0;t<=i.Count()-1;t++){const s=a.a.inst.getObjById(i[t].objectKey)
s.IsBoss()||(0==e&&(e=s.level),e>s.level&&(e=s.level))}this.monDec.textSet(d.M.Replace("【{0}级】昆顿守卫","{0}",e.toString()))}FindMonster(){u.o.Inst.FindMonster()}
ItemStatusUpdateHandler(){const t=this.GetDataes()
this.grid.data_set(t),this.grid.Reposition()}GetDataes(){const t=r.b.Inst.currentMapId_get(),e=m.x.getInstance().GetBossInfoes(t)
return e.Sort(this.CreateDelegate(this.SortBosses)),e}SortBosses(t,e){const i=t.info.refreshTime.ToNum(),s=e.info.refreshTime.ToNum(),n=o.D.serverMSTime_get()
if(!(i-n)&&s-n)return-1
if(i-n&&!(s-n))return 1
const l=a.a.inst.getObjById(t.monsterId),r=a.a.inst.getObjById(e.monsterId)
return l.level<r.level?-1:l.level>r.level?1:0}Destroy(){super.destroy()}Test1(){return!0}S_Test(){return!0}})},30859:(t,e,i)=>{
var s,n=i(6847),l=i(83908),a=i(49655),o=i(46282),r=i(98800),h=i(92679),d=i(20193),c=i(71453);(0,
n.s_)(a.o.KarimaRightView,o.Z.ui_rykarima_rightview).waitPrefab(o.Z.ui_copybaseui_commonrightview).register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),
this.showStatus=null}InitView(){super.InitView(),this.showStatus=!1}Clear(){super.Clear(),this.showStatus=!1,
c.x.getInstance().RemoveEventHandler(c.x.OUT_BOSS_RANGE,this.CreateDelegate(this.StatusChanged))}HandleDamages(){const t=d.D.Inst_get().bossId
if(r.Y.BossDic.LuaDic_ContainsKey(t)){if(this.showStatus)return
this.ShowDemage()}}OnAddToScene(){this.ShowStatus(),this.m_handlerMgr.AddEventMgr(h.g.BOSS_REMOVE,this.CreateDelegate(this.StatusChanged)),
this.m_handlerMgr.AddEventMgr(h.g.BOSS_RIGHTPANEL_CLICK,this.CreateDelegate(this.OnBossClick))}OnBossClick(){let t=this.statusarea.node.active
t=!t,t?(this.showStatus=!0,this.ShowStatus()):(this.showStatus=!1,this.ShowDemage())}ShowDemage(){this.statusarea.node.SetActive(!1),this.damagearea.node.SetActive(!0),
this.damagearea.OnAddToScene()}ShowStatus(){this.statusarea.node.SetActive(!0),this.damagearea.node.SetActive(!1),this.statusarea.OnAddToScene()}StatusChanged(){this.showStatus=!1,
this.ShowStatus()}Destroy(){}Test1(){return!0}S_Test(){return!0}})},72942:(t,e,i)=>{i.d(e,{s:()=>h})
var s,n=i(18998),l=i(83908),a=i(75439)
const{ccclass:o,property:r}=n._decorator
let h=o("KarimaStarItem")(s=class extends((0,l.yk)()){InitView(){super.InitView()}Clear(){}Destroy(){}SetData(t){if(0==t.index?this.arrows.SetActive(!1):this.arrows.SetActive(!0),
1==t.Curse){const t=a.D.getInstance().GetIntValue("KALIMAMOSTER:LEVEL")
this.norhead.SetActive(!0),this.head.SetActive(!1),this.name.textSet(`Lv.${t}\n昆顿守卫`)}else this.norhead.SetActive(!1),this.head.SetActive(!0),
this.head.spriteNameSet(t.objcfg.headResources),this.name.textSet(`Lv.${t.objcfg.level}\n${t.objcfg.name}`)
t.num>1?this.Curse.textSet(`${t.Curse}*${t.num}`):this.Curse.textSet(t.Curse.toString())
const e=(this.Curse.width()-22)/2
this.Curse.node.SetLocalPositionXYZ(-e,-98,0)}})||s},30236:(t,e,i)=>{i.d(e,{P:()=>g})
var s=i(6847),n=i(83908),l=i(46282),a=i(5494),o=i(85602),r=i(33314),h=i(96964),d=i(71453),c=i(23833)
class u{constructor(t){this.id=0,this.num=0,this.Curse=0,this.objcfg=null,this.index=0,t&&(this.objcfg=c.a.getInst().getObjById(t,!0),this.id=this.objcfg.id,this.num=1,
this.Curse=h.o.getInstance().GetMonsterCursePointById(this.id))}}var m,I=i(72942)
let g=(0,s.s_)(a.I.eKarimaStarView,l.Z.ui_treasure_karima_starview).register()(m=class extends((0,n.Ri)()){InitView(){super.InitView(),
this.msgGrid.SetInitInfo("ui_treasure_karima_staritem",null,I.s)}Clear(){super.Clear()}Destroy(){}OnAddToScene(){this.AddLis()
const t=d.x.getInstance().ShowTodayBestRecord
if(null!=t&&t.killCurse>0&&t.killObjectKeys.Count()>0){this.noBlogTip.SetActive(!1),this.has.SetActive(!0),this.name.textSet(t.nickName),this.Curse.textSet(t.killCurse.toString()),
this.head.spriteNameSet(r.Z.GetMainUIJobIcon(t.job,t.Sex))
const e=new o.Z
for(let i=0;i<=t.killObjectKeys.Count()-1;i++){const s=e.LastItem()
if(null!=s)if(s.id==t.killObjectKeys[i])s.num+=1
else{const n=new u(t.killObjectKeys[i])
n.index=i,1==n.Curse&&1==s.Curse?s.num+=1:e.Add(n)}else{const s=new u(t.killObjectKeys[i])
s.index=i,e.Add(s)}}this.msgGrid.data_set(e)}else this.noBlogTip.SetActive(!0),this.has.SetActive(!1)}AddLis(){
this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.Close))}Close(){h.o.getInstance().CloseKarimaStarView()}})||m},32889:(t,e,i)=>{
var s,n=i(6847),l=i(83908),a=i(17409),o=i(49655),r=i(46282),h=i(26034),d=i(68662),c=i(62370),u=i(5924),m=i(60130),I=i(98130),g=i(98885),_=i(65249),p=i(92679),C=i(7098),S=i(96964),f=i(71453)
;(0,n.s_)(o.o.KarimaStatusView,r.Z.ui_rykarima_statusview).register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),this.leaveTimeId=0,this.quitTimeId=0,
this.showTips=null,this.template=null,this.sectemplate=null}InitView(){super.InitView(),this.showTips=!1}Clear(){this.RemoveLis(),this.ClearLeaveTime(),this.ClearQuitTime(),
super.Clear()}OnAddToScene(){this.AddLis(),this.ShowCurseArea(!0),this.ShowQuitTime(0!=f.x.getInstance().leaveKarimaTime),this.tips.SetActive(!1)
const t=C.A.Inst_get().GetContentById("BOSS：KALIMA_TIPS1"),e=this.GetContent(t)
this.tipslabel.textSet(e)
let i=g.M.GetLabelLineSizeByStr(this.tipslabel,e)
this.tipsbg.heightSet(i.height+83),this.template=(0,h._T)("怒气值已满,       秒后你将受到雷霆惩罚!"),this.sectemplate=(0,h._T)("秒后将退出卡利玛神庙"),this._OnUpdateAnchor()}_OnUpdateAnchor(){
m.O.SetAnchorPos(this.leftanchor,!0,!0,0,!1),m.O.SetAnchorPos(this.centeranchor,null,!0,2,!1)}GetContent(t){let e=""
const i=g.M.Split(t,g.M.s_F_SLASH_DOT)
let s=null,n=0
for(;n<i.count;){s=g.M.Split(i[n],c.o.s_UNDER_CHAR)
const t=new _.o
s.Count()>1?("0"==s[0]?t.isPoint=!1:"1"==s[0]&&(t.isPoint=!0),t.content=s[1]):t.content=s[0],e+=t.content,n!=i.count-1&&(e+="\n"),n+=1}return e}ShowCurseArea(t){
this.cursearea.SetActive(t),t&&this.HandleCursePoint()}RemoveLis(){f.x.getInstance().RemoveEventHandler(f.x.CURSEPOINT_UPDATE,this.CreateDelegate(this.CursePointUpdateHandler)),
f.x.getInstance().RemoveEventHandler(f.x.LEAVETIME_CHANGE,this.CreateDelegate(this.HandleQuitTimeUpdate)),
this.m_handlerMgr.RemoveClickEvent(this.tipbtn,this.CreateDelegate(this.TipClick))}HandleCursePoint(){this.curseslider.DoF_SetValue(f.x.getInstance().cursePoint,100),
this.progresslab.textSet(f.x.getInstance().cursePoint.toString())}ShowQuitTime(t){if(t){this.noticearea.SetActive(!0),f.x.getInstance().willdie=!0
d.D.serverMSTime_get()<f.x.getInstance().punishTime?(this.StartLeaveTime(),this.UpdateQuitTime()):(this.SetQuitTime(),this.UpdateSecQuitTime())}else this.ClearLeaveTime(),
this.noticearea.SetActive(!1)}HandleQuitTimeUpdate(){this.ShowQuitTime(!0)}AddLis(){this.m_handlerMgr.AddClickEvent(this.tipbtn,this.CreateDelegate(this.TipClick)),
f.x.getInstance().AddEventHandler(f.x.CURSEPOINT_UPDATE,this.CreateDelegate(this.CursePointUpdateHandler)),
f.x.getInstance().AddEventHandler(f.x.LEAVETIME_CHANGE,this.CreateDelegate(this.HandleQuitTimeUpdate)),
this.m_handlerMgr.AddEventMgr(p.g.UPDATE_ANCHORS,this.CreateDelegate(this._OnUpdateAnchor))}TipClick(){
const t=C.A.Inst_get().GetContentById("BOSS：KALIMA_TIPS1"),e=this.GetContent(t)
g.M.GetLabelLineSizeByStr(this.tipslabel,e)
this.showTips=!this.showTips,this.tips.SetActive(this.showTips),this.showTips?(0,a.D1)(this,this.CreateDelegate(this.FullClick)):(0,a.Rt)(this)}FullClick(){this.TipClick()}
ClearLeaveTime(){0!=this.leaveTimeId&&(u.C.Inst_get().ClearInterval(this.leaveTimeId),this.leaveTimeId=0)}StartLeaveTime(){this.ClearLeaveTime(),
this.titletips.textSet(this.template)
const t=this.timecount.node.transform.GetLocalPosition()
t.x=-50,this.timecount.node.transform.SetLocalPosition(t),this.leaveTimeId=u.C.Inst_get().SetInterval(this.CreateDelegate(this.UpdateQuitTime),100)}ClearQuitTime(){
0!=this.quitTimeId&&(u.C.Inst_get().ClearInterval(this.quitTimeId),this.quitTimeId=0)}UpdateQuitTime(){let t=f.x.getInstance().punishTime-d.D.serverMSTime_get()
if(t<=0)return this.ClearLeaveTime(),this.SetQuitTime(),this.UpdateSecQuitTime(),void S.o.getInstance().PlayDieEffect()
t=I.GF.INT(.001*t),this.timecount.textSet(t.toString())}SetQuitTime(){this.ClearQuitTime(),this.titletips.textSet(this.sectemplate)
const t=this.timecount.node.transform.GetLocalPosition()
t.x=-120,this.timecount.node.transform.SetLocalPosition(t),this.quitTimeId=u.C.Inst_get().SetInterval(this.CreateDelegate(this.UpdateSecQuitTime),100)}UpdateSecQuitTime(){
let t=I.GF.INT(f.x.getInstance().leaveKarimaTime-d.D.serverMSTime_get())
t<=0&&(this.ClearQuitTime(),this.ClearLeaveTime(),t=0),t=I.GF.INT(.001*t),this.timecount.textSet(t.toString())}CursePointUpdateHandler(){this.HandleCursePoint()}Destroy(){
this.ClearLeaveTime()}Test1(){return!0}S_Test(){return!0}})},57148:(t,e,i)=>{i.d(e,{B:()=>I})
var s,n,l=i(18998),a=i(83908),o=i(28192),r=i(88653),h=i(87923),d=i(15771),c=i(71453)
const{ccclass:u,property:m}=l._decorator
let I=u("KarimaTimesItem")((n=class t extends((0,a.yk)()){constructor(...t){super(...t),this.clickHandler=null,this.cfg=null,this._enabled=!0,this._m_handlerMgr=null}
get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=o.h.Get()),this._m_handlerMgr}InitView(){super.InitView(),this.select.SetActive(!1),
this.lockLabel.node.SetActive(!1)}SetData(t){this.cfg=t
const e=d.U.inst.model.level_get()
if(this._enabled=e>=t.level,this.nameLabel.textSet(`${h.l.GetChineseNum(t.multipleKarima)}倍挑战`),e<t.level){this.lockLabel.node.SetActive(!0),this.lockLabel.textSet(`V${t.level}开启`)
const e=new r.I(.588,.5607,.529)
this.nameLabel.SetColor(e),this.lockLabel.SetColor(e)}this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.OnClickItem)),
this.SetSelect(c.x.getInstance().mtctime==t.multipleKarima)}OnClickItem(){this.enabled&&(this.SetSelect(!0),null!=this.clickHandler&&this.clickHandler(this.cfg))}SetSelect(e){
e?(null!=t._selectItem&&t._selectItem.SetSelect(!1),t._selectItem=this,this.select.SetActive(!0)):this.select.SetActive(!1)}Clear(){}Destroy(){
null!=t._selectItem&&t._selectItem.SetSelect(!1),t._selectItem=null,this.clickHandler=null}Test1(){return!0}S_Test(){return!0}},n._selectItem=null,s=n))||s},39741:(t,e,i)=>{i.d(e,{
s:()=>d})
var s=i(76544),n=i(56937),l=i(18202),a=i(31222),o=i(5494),r=i(52726),h=i(35279)
class d{constructor(){this.levelTipView=null,this.levelOffset=0,this.delayExecutor=null,this._degf_TipCallDestory=null,this._degf_TipShowlComplete=null,this.delayExecutor=new s.p,
this._degf_TipCallDestory=()=>this.TipCallDestory(),this._degf_TipShowlComplete=t=>this.TipShowlComplete(t)}OpenTip(t){if(t<=0)return
this.levelOffset=t
const e=new n.v
e.layerType=r.F.Tip,e.isSetActiveClose=!1,a.N.inst.OpenById(o.I.LevelUpTip,this._degf_TipShowlComplete,this._degf_TipCallDestory,e)}CloseTip(){a.N.inst.CloseById(o.I.LevelUpTip)}
TipShowlComplete(t){return null==this.levelTipView&&(this.levelTipView=new h.N,this.levelTipView.setId(t,null,0)),this.levelTipView}TipCallDestory(){
l.g.DestroyUIObj(this.levelTipView),this.levelTipView=null}}d.instance=new d},35279:(t,e,i)=>{i.d(e,{N:()=>p})
var s,n=i(6847),l=i(83908),a=i(46282),o=i(98800),r=i(62370),h=i(5924),d=i(76544),c=i(61911),u=i(5494),m=i(79534),I=i(48933),g=i(41864),_=i(39741)
let p=(0,n.s_)(u.I.LevelUpTip,a.Z.ui_upgrade_panel).register()(s=class extends((0,l.pA)(c.f)()){constructor(...t){super(...t),this.delayExecutor=null,this.animLevel=0,
this.finalLevel=0,this.delay=!1,this._degf_ChangeLevel=null,this._degf_ChangeUpLevel=null,this._degf_CloseThis=null,this._degf_SetData=null,this._degf_shrinkLevel=null,
this.intervalId=null,this.playingLv=null,this.oldOneLevelW=null,this.oldMutilLevelW=null,this.oldUpLevelW=null,this.oneLevelBoundW=null,this.multiLevelBoundW=null}InitView(){
super.InitView(),this.DestoryPanelLevel=c.f.DestoryLevel0,this.intervalId=-1,this.playingLv=1,this.oldOneLevelW=0,this.oldMutilLevelW=0,this.oldUpLevelW=0,this.oneLevelBoundW=0,
this.multiLevelBoundW=0,this.delayExecutor=new d.p,this._degf_ChangeLevel=()=>this.ChangeLevel(),this._degf_ChangeUpLevel=()=>this.ChangeUpLevel(),
this._degf_CloseThis=()=>this.CloseThis(),this._degf_SetData=()=>this.SetData(),this._degf_shrinkLevel=()=>this.shrinkLevel()}OnAddToScene(){
this.node.active||this.node.SetActive(!0),this.SetData()}SetData(){const t=_.s.instance.levelOffset,e=o.Y.Inst.PrimaryRoleInfo_get().Level_get()
this.effect1.SetActive(!1),this.effect2.SetActive(!1)
const i=g.h.GetRebirthCfgLevel(e),s=g.h.GetNormalLevel(e)
if(this.ClearTimer(),1==t){this.one.SetActive(!1),this.one.SetActive(!0),this.multi.SetActive(!1)
const t=r.o.NumToString(s,0)
this.curLevel.textSet(t),this.updatePos(this.curLevel.node,this.oneSprite.node,t),this.effect1.SetActive(!1),this.effect1.SetActive(!0),
this.delayExecutor.Invoke(this._degf_CloseThis,1500),this.AdjustPos(this.curLevel,this.oneSprite)
t.length
if(this.oneLevelBoundW=45,0==i){this.changearea.SetActive(!1)
const t=this.oneLevelBoundW,e=m.P.zero_get()
e.Set(-t,205,0),this.levelarea.transform.SetLocalPosition(e)}else{this.changearea.SetActive(!0),this.changenum.textSet(i.toString())
const t=35-this.oneLevelBoundW
m.P.zero_get().Set(t,205,0)}}else{this.one.SetActive(!1),this.multi.SetActive(!1),this.multi.SetActive(!0)
const e=s-t+1
this.curLevelMulti.node.SetActive(!0),this.playingLv=1
const n=r.o.NumToString(t,0)
this.upLevel.textSet(n),this.intervalId=h.C.Inst_get().SetInterval(this._degf_ChangeUpLevel,1e3/t),h.C.Inst_get().CallLater(this.CreateDelegate(this.UpdateAnchors))
const l=this.up.transform.GetLocalPosition(),a=n.length-1
l.x=-33*a/2,this.effect2.SetActive(!0),this.finalLevel=s,this.animLevel=e
const o=r.o.NumToString(this.animLevel,0)
this.curLevelMulti.textSet(o),this.updatePos(this.curLevelMulti.node,this.multSprite.node,o)
o.length
if(this.AdjustPos(this.upLevel,this.bg5),this.AdjustPos(this.curLevelMulti,this.multSprite),0==i){this.multichangearea.SetActive(!1)
const t=this.multiLevelBoundW
I.I.calVec0.Set(-t,0,0)
const e=m.P.zero_get()
e.Set(-30,0,0),this.multilevelarea.transform.SetLocalPosition(e)}else{this.multichangearea.SetActive(!0),this.multichangenum.textSet(i.toString())
this.multiLevelBoundW
m.P.zero_get().Set(0,0,0)}this.delayExecutor.Invoke(this._degf_CloseThis,1500)}}updatePos(t,e,i){t.transform.width=27*i.length,e.x=t.x+t.transform.width+20}UpdateAnchors(){}
ChangeUpLevel(){null!=this.curLevelMulti?(this.animLevel+=1,this.curLevelMulti.textSet(r.o.NumToString(this.animLevel)),
this.updatePos(this.curLevelMulti.node,this.multSprite.node,r.o.NumToString(this.animLevel)),this.AdjustPos(this.curLevelMulti,this.multSprite),
this.animLevel>=this.finalLevel&&this.ClearTimer()):this.Clear()}AdjustPos(t,e){}startChangeLevel(){this.enlargeLevel(),this.delayExecutor.Invoke(this._degf_shrinkLevel,300),
this.delayExecutor.Invoke(this._degf_ChangeLevel,600)}enlargeLevel(){this.levelScale.SetActive(!0)}shrinkLevel(){}ChangeLevel(){
null!=this.curLevelMulti?(this.curLevelMulti.textSet(r.o.NumToString(this.animLevel,0)),
this.updatePos(this.curLevelMulti.node,this.multSprite.node,r.o.NumToString(this.animLevel,0)),this.enlargeLevel(),this.delayExecutor.Invoke(this._degf_shrinkLevel,300),
this.animLevel<this.finalLevel?(this.animLevel+=1,this.delayExecutor.Invoke(this._degf_ChangeLevel,600)):this.delayExecutor.Invoke(this._degf_CloseThis,1e3)):this.Clear()}
adjustLoc(t,e,i){}adjustLoc2(t,e,i){}CloseThis(){_.s.instance.CloseTip()}ClearTimer(){-1!=this.intervalId&&(h.C.Inst_get().ClearInterval(this.intervalId),this.intervalId=-1)}
Clear(){this.delay=!1,this.delayExecutor.Clear(),this.oldMutilLevelW=0,this.oldOneLevelW=0,this.ClearTimer(),super.Clear()}Destroy(){super.Destroy(),this.Clear()}})||s},
60447:(t,e,i)=>{i.d(e,{b:()=>h})
var s=i(77546),n=i(98800),l=i(97461),a=i(5924),o=i(85602),r=i(79534)
class h{constructor(){this._degf_EnterMapHandler=null,this._degf_Loop=null,this.code=-1,this.copyId=0,this.packet=null,this.isLive=!1,this.playerId=null,this.MVPHandleId=0,
this.FrameLoopId=-1,this.playerInfoList=null,this.posMsg=null,this.peakRoundStartTime=null,this.peakBattleRoundEnd=null,this._degf_EnterMapHandler=t=>this.EnterMapHandler(t),
this._degf_Loop=t=>this.FrameLoop(t),this.registeProtocol()}static Inst_get(){return null==h.inst&&(h.inst=new h),h.inst}registeProtocol(){}AddOrRemoveListener(t){
t?l.i.Inst.AddEventHandler(CommonEventType.EnterMap,this._degf_EnterMapHandler):l.i.Inst.RemoveEventHandler(CommonEventType.EnterMap,this._degf_EnterMapHandler)}EnterLiveRoom(){
if(1==this.code){s.s.Info("进入直播间成功"),this.AddOrRemoveListener(!0),this.isLive=!0
let t=!1
const e=new r.P
if(this.playerInfoList=new o.Z,null!=this.packet){let i=0
for(;i<this.packet.Count();){if(-1201==this.packet[i].getId()){const s=this.packet[i]
s.horseId=0,this.playerInfoList.Add(s),s.objId.Equal(this.playerId)&&(t=!0,e.Set(s.x,0,s.y))
}else-7858==this.packet[i].getId()?this.posMsg=this.packet[i]:-32383==this.packet[i].getId()?this.peakRoundStartTime=this.packet[i]:-7846==this.packet[i].getId()&&(this.peakBattleRoundEnd=this.packet[i])
i+=1}}if(t&&null!=this.playerInfoList&&2==this.playerInfoList.Count()){const t=CopyResourceCfgManager.Inst().getItemById(this.copyId)
GameMapManager.Inst.goToMap(StringProxy.String2Int(t.mapId),e,90)}else s.s.Info("没找到视角！"),this.ExitLiveRoom()}else s.s.Info(`不在直播时间，code：${this.code}`)}EnterMapHandler(){
const t=TransportMapModel.Inst_get().GetMapById(GameMapManager.Inst.currentMapId_get())
if(this.isLive){if("CROSS_ARENA_PEAK"!=t.controllerType)return this.ExitLiveRoom(),void UIShowMgr.inst.OpenUIByShortCutID(eUIShortCutType.PeakCrossArena)
CopyBaseModel.Inst_get().currentCopyId=this.copyId
const e=CopyResourceCfgManager.Inst().getItemById(this.copyId)
if(CopyBaseModel.Inst_get().curCopyType=e.controllerType,null!=this.posMsg&&SocketManager.SendMsgHandle(this.posMsg),
null!=this.peakRoundStartTime&&SocketManager.SendMsgHandle(this.peakRoundStartTime),null!=this.playerInfoList){let t=0
for(;t<this.playerInfoList.Count();){SocketManager.SendMsgHandle(this.playerInfoList[t])
const e=this.playerInfoList[t]
if(e.objId.Equal(this.playerId)){const t=n.Y.Inst.getRoleById(e.objId)
this.MVPHandleId=t.GetHandle(),LuaEngineBridgeManager.Instance_get().SetVIPObject(t.GetHandle())}t+=1}}
null!=this.peakBattleRoundEnd&&SocketManager.SendMsgHandle(this.peakBattleRoundEnd),WorldAtyArenaPlaybackControl.Inst_get().OpenWorldAtyArenaPlaybackPanel(!1),
WorldAtyArenaPlaybackControl.Inst_get().reopenType=2
n.Y.Inst.PrimaryRole_get().RealSetShow(!1),this.ClearLoop(),this.FrameLoopId=a.C.Inst_get().SetFrameLoop(this._degf_Loop,1,-1)}}FrameLoop(){
0!=this.MVPHandleId&&LuaEngineBridgeManager.Instance_get().SetVIPObject(this.MVPHandleId)}ClearLoop(){-1!=this.FrameLoopId&&(a.C.Inst_get().ClearLoop(this.FrameLoopId),
this.FrameLoopId=-1)}Reset(){this.code=-1,this.copyId=0,this.packet=null,this.isLive=!1,this.MVPHandleId=0,this.ClearLoop(),this.playerInfoList=null,this.posMsg=null,
this.peakRoundStartTime=null,this.peakBattleRoundEnd=null}RemovePlayer(t){}ExitLiveRoom(){const t=n.Y.Inst.PrimaryRole_get()
t.RealSetShow(!0),t.ChangeToStand(!0),LuaEngineBridgeManager.Instance_get().SetVIPObject(t.GetHandle()),CopyBaseModel.Inst_get().currentCopyId=0,
CopyBaseModel.Inst_get().curCopyType=0,this.Reset(),this.AddOrRemoveListener(!1)}CheckTime(){return!1}IsTimestampInRange(t,e){
const i=StringProxy.Split(t,GameStringProxy.s_Arr_UNDER_CHAR_DOT),s=StringProxy.Split(i[1],StringProxy.s_Arr_CCD_CHAR_COLON),n=StringProxy.Split(i[2],StringProxy.s_Arr_CCD_CHAR_COLON),l=os.date("*t",e)
if(l.wday-1!=StringProxy.String2Int(i[0]))return!1
l.hour=StringProxy.String2Int(s[0]),l.min=StringProxy.String2Int(s[1]),l.sec=StringProxy.String2Int(s[2])
const a=os.time(l)
l.hour=StringProxy.String2Int(n[0]),l.min=StringProxy.String2Int(n[1]),l.sec=StringProxy.String2Int(n[2])
const o=os.time(l)
return e>=a&&e<o}}h.inst=null},92260:(t,e,i)=>{i.d(e,{r:()=>c})
var s=i(17409),n=i(56937),l=i(31222),a=i(5494),o=i(52726),r=i(85602),h=i(38962)
class d{constructor(){this.uid=null,this.mCid=null,this.mSid=null,this.mCParam=null,this.mSParam=null,this.tips=null,this.state=null,this.InitData()}InitData(){this.uid=0,
this.mCid=0,this.mSid=0,this.mCParam=null,this.mSParam=null,this.tips=null,this.state=-1}CheckSendState(t,e){
return-1==this.state&&(t==this.mSid&&(null==this.mSParam||this.mSParam==e)&&(this.state=0,!0))}CheckCanShow(){return 1==this.state}CheckGetState(t,e){
return 0==this.state&&(t==this.mCid&&(null==this.mCParam||this.mCParam==e)&&(this.state=1,!0))}Clear(){this.state=-1}CheckSame(t,e,i,s,n){
if(i==this.uid&&e==this.mCid&&t==this.mSid){if(null==s){if(null!=this.mSParam)return!1}else if(s!=this.mSParam)return!1
if(null==n){if(null!=this.mCParam)return!1}else if(n!=this.mCParam)return!1
return!0}return!1}}class c{constructor(){this.UIDMsgDic=null,this.MsgCSIDDic=null,this.MsgSCIDDic=null,this.uIds=null,this.view=null,this.UIDMsgDic=new h.X,this.MsgCSIDDic=new h.X,
this.MsgSCIDDic=new h.X,this.ResetData()}RemoveMsgUID(t,e,i){let s=null
this.UIDMsgDic.LuaDic_ContainsKey(i)&&(s=this.UIDMsgDic.LuaDic_GetItem(i),this.ClearUid(i),this.RemoveData(this.MsgSCIDDic,t,s),this.RemoveData(this.MsgCSIDDic,e,s),s.Clear(),
this.UIDMsgDic.LuaDic_Remove(i))}RegMsgUID(t,e,i,s,n,l){let a=null
if(this.UIDMsgDic.LuaDic_ContainsKey(i)){if(a=this.UIDMsgDic.LuaDic_GetItem(i),a.CheckSame(t,e,i,s,n))return
this.ClearUid(i),this.RemoveData(this.MsgSCIDDic,t,a),this.RemoveData(this.MsgCSIDDic,e,a)}else a=new d,this.UIDMsgDic.LuaDic_AddOrSetItem(i,a)
a.uid=i,a.mSid=t,a.mCid=e,a.mSParam=s,a.mCParam=n,a.tips=l,this.RegData(this.MsgSCIDDic,t,a),this.RegData(this.MsgCSIDDic,e,a)}RemoveData(t,e,i){if(t.LuaDic_ContainsKey(e)){
const s=t.LuaDic_GetItem(e),n=s.count-1
for(let t=0;t<=n;t++)if(s[t]==i){s.RemoveAt(t)
break}}}GegData(t,e,i,s){if(t.LuaDic_ContainsKey(e)){const n=t.LuaDic_GetItem(e),l=n.count-1
for(let t=0;t<=l;t++){if(null==i)return n[t]
if(s){if(i==n[t].mCParam)return n[t]}else if(i==n[t].mSParam)return n[t]}}return null}RegData(t,e,i){let s=null
t.LuaDic_ContainsKey(e)?s=t.LuaDic_GetItem(e):(s=new r.Z,t.LuaDic_AddOrSetItem(e,s)),s.Add(i)}ResetData(t){if(null==this.uIds)return this.uIds=new r.Z,void this.CloseView()
const e=this.uIds.count-1
for(let t=0;t<=e;t++){const e=this.uIds[t],i=this.UIDMsgDic.LuaDic_GetItem(e)
l.N.inst.IsViewShowing(i)||l.N.inst.CloseById(i)}this.uIds.Clear(),this.CloseView()}GetNotice(){if(this.uIds.count>0){const t=this.uIds[0]
if(this.UIDMsgDic.LuaDic_ContainsKey(t)){const e=this.UIDMsgDic.LuaDic_GetItem(t)
if(null!=e.tips)return e.tips}return t}return""}ClearUid(t){if(this.UIDMsgDic.LuaDic_ContainsKey(t)){this.UIDMsgDic.LuaDic_GetItem(t).Clear()
const e=this.uIds.IndexOf(t)
e>-1&&(this.uIds.RemoveAt(e),this.CheckShowOpen())}}CheckIsWaitToShow(t){if(this.UIDMsgDic.LuaDic_ContainsKey(t)){const e=this.UIDMsgDic.LuaDic_GetItem(t)
if(!e.CheckCanShow())return!0
const i=this.uIds.IndexOf(t)
return i>-1&&(this.uIds.RemoveAt(i),this.CheckShowOpen()),e.Clear(),!1}return!1}CheckShowOpen(){this.uIds.count>0?this.OpenView():this.CloseView()}CheckMsgCId(t,e){
const i=this.GegData(this.MsgCSIDDic,t,e,!0)
null!=i&&i.CheckGetState(t,e)&&this.CheckWaitMsgShow(i.uid)&&(i.Clear(),this.uIds.Remove(i.uid),this.CheckShowOpen())}CheckWaitMsgShow(t){return l.N.inst.CheckWaitMsgShow(t)}
SetMsgSId(t,e){const i=this.GegData(this.MsgSCIDDic,t,e,!1)
null!=i&&i.CheckSendState(t,e)&&(this.uIds.Contains(i.uid)||(this.uIds.Add(i.uid),this.CheckShowOpen()))}static Inst_get(){return null==c._inst&&(c._inst=new c),c._inst}OpenView(){
const t=new n.v
t.layerType=o.F.Effect,(0,s.Yp)(a.I.eRyLoadingCircleView,t)}CloseView(){(0,s.sR)(a.I.eRyLoadingCircleView)}}c._inst=null},18572:(t,e,i)=>{
var s,n=i(6847),l=i(83908),a=i(46282),o=i(5924),r=i(5494),h=i(92260);(0,n.s_)(r.I.eRyLoadingCircleView,a.Z.ui_loading_circleview_ry).register()(s=class extends((0,l.Ri)()){
constructor(...t){super(...t),this.TimerId=null}InitView(){super.InitView()}OnAddToScene(){super.OnAddToScene()}ShowNotice(){h.r.Inst_get().ResetData()}ClearTimer(){
null!=this.TimerId&&(o.C.Inst_get().ClearInterval(this.TimerId),this.TimerId=null)}Clear(){this.ClearTimer(),super.Clear()}})},7601:(t,e,i)=>{i.d(e,{W:()=>at})
var s,n,l,a,o,r,h,d,c,u,m=i(42292),I=i(71409),g=i(39407),_=i(93984),p=i(77546),C=i(32076),S=i(38836),f=i(86133),y=i(98800),w=i(61033),D=i(97960),T=i(55039),A=i(37397),v=i(12480),L=i(59553),M=i(97461),b=i(98958),R=i(68662),P=i(13687),G=i(38935),O=i(5924),E=i(66788),B=i(35128),k=i(98130),x=i(98885),V=i(85602),N=i(38962),H=i(79534),U=i(76791),F=i(80486),j=i(84229),Y=i(70850),z=i(92679),q=i(33314),Z=i(87888),K=i(7660),$=i(75439),W=i(55617),X=i(64027),Q=i(93997),J=i(97869),tt=i(845),et=i(65550),it=i(85942),st=i(47041),nt=i(92415)
function lt(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let at=(s=(0,I.GH)(nt.k.SM_BackpackItems),n=(0,I.GH)(nt.k.SM_PlayerBaseAttributeUpdate),l=(0,
I.GH)(nt.k.SM_PlayerIpInfo),a=(0,I.GH)(nt.k.SM_LoginPlayerDetailInfo),o=(0,I.GH)(nt.k.SM_Server_Open),r=(0,I.GH)(nt.k.SM_ChangedPlayerAttribute),h=(0,I.GH)(nt.k.SM_CurrAsuramId),
d=(0,I.GH)(nt.k.SM_Heartbeat),u=class t{static get Inst(){return this._Inst||(this._Inst=new t),this._Inst}constructor(){this.heartBeatMsg=null,this._shouldCreateRole=!1,
this.registerError=null,this.isLoginEnterMap=!0,this.isInitPlayer=!1,this.idMsg=null,this.flag=!1,this.openTime=null,this.heartTimer=0,this.heartTimer2=0,this.heartSCount=0,
this.heartRCount=0,this.checkHeartIdx=0,this.checkIsWeek=!1,this.connectingStatus=0,this.noticeTime=k.GF.INT32_MIN_VALUE,this._heartCheckInterval=-1,this.isWeekNet=!1,
this.curOpenDay=0,this._backStageOffline=null,this._degf_SM_AnotherLoginHandler=null,this._degf_SM_ApplyNoticeHandle=null,this._degf_SM_BackpackItemsHandler=null,
this._degf_SM_ChangedPlayerAttributeHnadler=null,this._degf_SM_CurrAsuramIdHandle=null,this._degf_SM_DisconnectHandler=null,this._degf_SM_HeartbeatHandler=null,
this._degf_SM_LoginFailHandler=null,this._degf_SM_LoginPlayerDetailInfoHandler=null,this._degf_SM_Server_OpenHandler=null,this._degf_SM_LoginPlayerInfoListHandler=null,
this._degf_SM_PlayerApplyListHandle=null,this._degf_SM_PlayerBaseAttributeUpdateHandler=null,this._degf_SM_UpdateReconnectInfoHandler=null,this._degf_SendFocus=null,
this._degf_loadEnd=null,this._degf_OnFocusUpdate=null,this._degf_OnCheckDayUpdate=null,this.dayTimerId=null,this.checkWeekNetTime=null,this.checkHeartTimerId=null,
this.heartBeatMsg=new X.e,this.registerError=new J.$
const t=$.D.getInstance().getContent("SYSTEM:BACKSTAGE_OFFLINE")
this._backStageOffline=x.M.String2Int(t.getContent().stringVal),this._degf_SM_AnotherLoginHandler=t=>this.SM_AnotherLoginHandler(t),
this._degf_SM_ApplyNoticeHandle=t=>this.SM_ApplyNoticeHandle(t),this._degf_SM_BackpackItemsHandler=t=>this.SM_BackpackItemsHandler(t),
this._degf_SM_ChangedPlayerAttributeHnadler=t=>this.SM_ChangedPlayerAttributeHnadler(t),this._degf_SM_CurrAsuramIdHandle=t=>this.SM_CurrAsuramIdHandle(t),
this._degf_SM_DisconnectHandler=t=>this.SM_DisconnectHandler(t),this._degf_SM_HeartbeatHandler=t=>this.SM_HeartbeatHandler(t),
this._degf_SM_LoginFailHandler=t=>this.SM_LoginFailHandler(t),this._degf_SM_LoginPlayerDetailInfoHandler=t=>this.SM_LoginPlayerDetailInfoHandler(t),
this._degf_SM_Server_OpenHandler=t=>this.SM_Server_OpenHandler(t),this._degf_SM_LoginPlayerInfoListHandler=t=>this.SM_LoginPlayerInfoListHandler(t),
this._degf_SM_PlayerApplyListHandle=t=>this.SM_PlayerApplyListHandle(t),this._degf_SM_PlayerBaseAttributeUpdateHandler=t=>this.SM_PlayerBaseAttributeUpdateHandler(t),
this._degf_SM_UpdateReconnectInfoHandler=t=>this.SM_UpdateReconnectInfoHandler(t),this._degf_SendFocus=t=>this.SendFocus(t),this._degf_loadEnd=()=>this.loadEnd(),
this._degf_OnFocusUpdate=t=>this.OnFocusUpdate(t),this._degf_OnCheckDayUpdate=t=>this.OnCheckDayUpdate(t),this.AddLis()}MicroRegester(){this.regesterBaseInfo(),this.InitModuleMgr()
}regesterBaseInfo(){}SM_DoCode(t){}SM_BackpackItemsHandler(t){for(const[e,i]of(0,S.V5)(t.packMap))Y.g.Inst_get().setBagData(i,null,e)
st.N.Inst_get().CheckAllItem()}SM_PlayerBaseAttributeUpdateHandler(t){null==w.l.GetInst().baseAttributeDic&&(w.l.GetInst().baseAttributeDic=new N.X),
w.l.GetInst().baseAttributeDic.LuaDic_AddOrSetItem(t.playerId.ToKey(),t.infoDic),y.Y.Inst.PrimaryRoleInfo_get().RaiseEvent(D.A.BaseAttributesUpdate)
const e=y.Y.Inst.GetPlayerInfoById(t.playerId)
if(null!=e)for(const[i,s]of(0,S.V5)(t.infoDic))e.setAttribute(i,s)}AddLis(){}InitModuleMgr(){}SM_UpdateReconnectInfoHandler(t){}ShowServerVersionErr(){}OnReStart(t){}
SM_LoginPlayerInfoListHandler(t){}loadEnd(){}OnFocusUpdate(t){}SM_LoginFailHandler(t){}SetConnectingStatus(t){}SM_PlayerIpInfoHandler(t){launcher.config.userIploc=t.ipLocation}
SM_LoginPlayerDetailInfoHandler(t){(0,g.t4)("--- SM_LoginPlayerDetailInfo"),this.isLoginEnterMap=!0,v.y.Instance.RaiseEvent(v.y.eStateChange,v.y.eLoginComplete),
G.C.Inst.setReadMsg(null)
const e=y.Y.Inst.primaryRoleInfoList.Count(),i=t.playerDetailInfos.Count(),s=e>0&&i>e
y.Y.Inst.HandlePlayerDetailMsg(t),launcher.config.userIp=t.ip
let n=null
const l=t.mapId,a=t.playerDetailInfos[0]
this.isInitPlayer||(y.Y.Inst.AddPrimaryRole(),this.isInitPlayer=!0),s&&(n=t.playerDetailInfos[i-1].id),
s||P.b.Inst.goToMap(l,new H.P(a.x,0,a.y),T.W.transHeading2UnityDir(a.heading)),tt.g.Inst_get().SetInfo(t.clientSetting),s&&(y.Y.Inst.AddMultiPrimaryRole(),
M.i.Inst.RaiseEvent(z.g.NEWROLE_CREATE,n)),U.v.update(U.v.Flag.PLAYER_INFO),K.U.Inst().CloseCreateroleview_Ry()}AddDayTimer(){}ClearDayTimer(){}OnCheckDayUpdate(t=null){}
ResetData(){this.isInitPlayer=!1,this.SetConnectingStatus(0),this.curOpenDay=0,this.ClearDayTimer()}ResetHeartData(){t._lastRecvSM_HeartBeatTime=0,t._lastSendCM_HeartBeatTime=0,
this.heartSCount=0,this.heartRCount=0,this.ClearCheckWeekNetData(),this.SetWeekState(!1)}SM_Server_OpenHandler(t){const e=t
this.openTime=e.openTime.ToNum()}LoginPacking(){}SM_ChangedPlayerAttributeHnadler(t){E.Y.Log((0,f.T)("人物信息改变"),!0)
const e=t
y.Y.Inst.HandlePlayerAttributeChanged(e)}SM_AnotherLoginHandler(t){RelivePanelManager.Inst_get().CloseAllPanel()
const e=b.V.Inst().getStr(10457,_.h.eLangResource)
L._.Inst.ReLoginTip(e)}SM_DisconnectHandler(t){const e=b.V.Inst().getStr(10459,_.h.eLangResource)
L._.Inst.ReLoginTip(e)}SM_CurrAsuramIdHandle(t){const e=t
this.idMsg=e,this.flag=!0,this.asuramHandle()}asuramHandle(){y.Y.Inst.SM_AsuramIdHandler(this.idMsg)}SM_ApplyNoticeHandle(t){const e=t
F.K.Inst().SM_ApplyNoticeHandler(e)
const i=new W.H
G.C.Inst.F_SendMsg(i)}SM_PlayerApplyListHandle(t){const e=t,i=new V.Z
for(const[t,s]of(0,S.V5)(e.applyList))i.Add(s)
j.Q.Inst_get().AppliedList_set(i)}StartHeartbeat(){R.D.ResetRecordInfo(),this.ResetHeartData(),0==this.heartTimer&&(this.heartTimer=O.C.Inst_get().SetInterval((0,
C.v)(this.CM_HeartBeatHandler,this),t.HEART_BEAT_DURATION),this.heartTimer2=O.C.Inst_get().SetInterval((0,C.v)(this._CheckNetConnect,this),3e3),this.CM_HeartBeatHandler())}
StopHeartbeat(){R.D.ResetRecordInfo(),t._lastSendCM_HeartBeatTime=0,0!=this.heartTimer&&(this.heartTimer=O.C.Inst_get().ClearInterval(this.heartTimer),
this.heartTimer2=O.C.Inst_get().ClearInterval(this.heartTimer2))}CM_HeartBeatHandler(){const e=k.GF.Timer_get()
this.CheckWeekNet(e),t._lastSendCM_HeartBeatTime=e,t._lastRecvSM_HeartBeatTime=0,this.heartSCount+=1,G.C.Inst.F_SendMsg(this.heartBeatMsg)}_CheckNetConnect(){
if(this._heartCheckInterval=k.GF.Timer_get(),t._lastRecvSM_HeartBeatTime<=0&&t._lastSendCM_HeartBeatTime>0&&A._.Inst.IsLoginCompleted()){
k.GF.Timer_get()-t._lastSendCM_HeartBeatTime>5&&(E.Y.Log("_CheckNetConnect Max"),t._lastSendCM_HeartBeatTime=0)}}SM_HeartbeatHandler(e){this.isWeekNet=!1,
t._lastRecvSM_HeartBeatTime=k.GF.Timer_get()
const i=e
this.heartRCount+=1,this.heartRCount>this.heartSCount&&(this.heartRCount=this.heartSCount),R.D.ResetServerTime(i.time.ToNum()),this.CheckWeekNet()}CheckWeekNet(e){
if(this.checkIsWeek){if(this.checkHeartIdx==this.heartRCount){const t=k.GF.Timer_get()
t-this.checkWeekNetTime-1e3*G.C.Inst.DTime>3e3&&G.C.Inst.IsConnected()&&this.SetWeekState(!0,t),this.ClearCheckWeekNetData()}
}else null!=e&&0==t._lastRecvSM_HeartBeatTime||(e=t._lastRecvSM_HeartBeatTime),0!=t._lastSendCM_HeartBeatTime&&(e-=t._lastSendCM_HeartBeatTime,
(e=Math.floor(1e3*e))<0||e-G.C.Inst.DTime>3e3?this.checkIsWeek||this.isWeekNet||this.SendCheckWeekNet():this.SetWeekState(!1))}SendCheckWeekNet(t){
this.checkWeekNetTime=k.GF.Timer_get(),this.checkIsWeek=!0,this.checkHeartIdx=this.heartSCount+1,
this.checkHeartTimerId=O.C.Inst_get().SetInterval(this.DelyCheckWeekNet.bind(this),1e3),this.CM_HeartBeatHandler()}DelyCheckWeekNet(){if(this.checkIsWeek){const t=k.GF.Timer_get()
G.C.Inst.DTime<200&&G.C.Inst.IsConnected()&&(this.SetWeekState(!0,t),this.ClearCheckWeekNetData())}}ClearCheckWeekNetData(){this.checkIsWeek=!1,this.checkWeekNetTime=0,
this.checkHeartIdx=0,null!=this.checkHeartTimerId&&(O.C.Inst_get().ClearInterval(this.checkHeartTimerId),this.checkHeartTimerId=null)}SetWeekState(t,e=null){
this.isWeekNet!=t&&(this.isWeekNet=t,this.isWeekNet&&(this.noticeTime=e,et.y.inst.ClientSysStrMsg(b.V.Inst().getStr(11013)),p.s.Info("进入弱网环境")),
M.i.Inst.RaiseEvent(z.g.WEEK_NET_UPDATE))}IsWeekState(){return this.isWeekNet}GetCurSystem(){return"1"}SendLogin(t){}SendFocus(t){}AddOnlineCheck(){}TryOnlineCheck(){
if(this._heartCheckInterval<=0)return
if(k.GF.Timer_get()-this._heartCheckInterval>=this._backStageOffline){const t=b.V.Inst().getStr(10459,_.h.eLangResource)
p.s.Info("TryOnlineCheck true "),L._.Inst.ReLoginTip(t,!0)}else this.CM_HeartBeatHandler()
this._heartCheckInterval=-1}CreateRole(){const t=k.GF.INT(B.p.RandomMax(q.Z.BASE_JOB.count-1e-5)),e=q.Z.BASE_JOB[t],i=this.UpdateSexByJob(e),s=v.y.Instance.GetRandomName(i)
RegisterModel.getInst().SendCreateRole(e,s,i)}EnterRole(){Q.p.inst.mapLoadingType=1
const t=v.y.Instance.loginRoleList,e=t.list
let i=null
for(let s=0;s<=e.Count()-1;s++)if(e[s].id.Equal(t.lastLogin)){i=e[s].id
break}null==i&&null!=e&&e.Count()>0&&(i=e[0].id),A._.Inst.ReqLogin(i)}UpdateSexByJob(t){let e=Z.$.Male
return e=t==q.Z.BASE_MAGICIAN?Z.$.Male:t==q.Z.BASE_ARCHER?Z.$.Female:Z.$.Male,e}SM_NoticePlayerOutHandler(t){if(p.s.Info(`SM_NoticePlayerOut22 ${t.type} ${t.content}`),1==t.type){
const e=new it.N
0,e.showText=t.content,e.tipstype=1,e.isDoOkInClose=!0,e.okhandler=this.CreateDelegate(this.ReLogin),et.y.inst.OpenCommonMessageTips(e)}else if(2==t.type){const e=new it.N
e.showText=t.content,e.tipstype=2,e.okhandler=this.CreateDelegate(this.ReLogin),et.y.inst.OpenCommonMessageTips(e)}}SM_UpdateGmLevelHandler(t){const e=t
if(null!=e){const t=y.Y.Inst.primaryRoleInfoList
for(let i=0;i<=t.Count()-1;i++)t[i].isGmOpen=e.isOpenGm}}ReLogin(){L._.Inst.ReLogin(null)}},u._Inst=null,u.HEART_BEAT_DURATION=5e3,u._lastSendCM_HeartBeatTime=0,
u._lastRecvSM_HeartBeatTime=0,lt(c=u,"Inst",[m.n],Object.getOwnPropertyDescriptor(c,"Inst"),c),
lt(c.prototype,"SM_BackpackItemsHandler",[s],Object.getOwnPropertyDescriptor(c.prototype,"SM_BackpackItemsHandler"),c.prototype),
lt(c.prototype,"SM_PlayerBaseAttributeUpdateHandler",[n],Object.getOwnPropertyDescriptor(c.prototype,"SM_PlayerBaseAttributeUpdateHandler"),c.prototype),
lt(c.prototype,"SM_PlayerIpInfoHandler",[l],Object.getOwnPropertyDescriptor(c.prototype,"SM_PlayerIpInfoHandler"),c.prototype),
lt(c.prototype,"SM_LoginPlayerDetailInfoHandler",[a],Object.getOwnPropertyDescriptor(c.prototype,"SM_LoginPlayerDetailInfoHandler"),c.prototype),
lt(c.prototype,"SM_Server_OpenHandler",[o],Object.getOwnPropertyDescriptor(c.prototype,"SM_Server_OpenHandler"),c.prototype),
lt(c.prototype,"SM_ChangedPlayerAttributeHnadler",[r],Object.getOwnPropertyDescriptor(c.prototype,"SM_ChangedPlayerAttributeHnadler"),c.prototype),
lt(c.prototype,"SM_CurrAsuramIdHandle",[h],Object.getOwnPropertyDescriptor(c.prototype,"SM_CurrAsuramIdHandle"),c.prototype),
lt(c.prototype,"SM_HeartbeatHandler",[d],Object.getOwnPropertyDescriptor(c.prototype,"SM_HeartbeatHandler"),c.prototype),c)},46352:(t,e,i)=>{i.d(e,{o:()=>l})
var s=i(31222),n=i(5494)
class l{constructor(){this.mainPanel=null,this._degf_successDestroyHandler=null,this._degf_successShowHandler=null,this.topUseDefaultTab=null,this.battlePanel=null,
this.successPanel=null,this._degf_successDestroyHandler=()=>this.successDestroyHandler(),this._degf_successShowHandler=t=>this.successShowHandler(t)}OpenPanel(t,e){null==t&&(t=!0),
this.topUseDefaultTab=t,e&&(LostAbyssModel.Inst_Get().viewType=e)
const i=this.GetFuncIdByViewType(LostAbyssModel.Inst_Get().viewType)
if(FunctionOpenModel.Inst_get().IsFunctionOpened(i)){if(null!=this.mainPanel&&this.mainPanel.isShow_get())return void this.mainPanel.OnAddToScene()
const t=new UIOpenParam
t.isShowMask=!0,t.isDefaultUITween=!0,s.N.inst.OpenById(n.I.LostAbyss,this.CreateDelegate(this.ShowComplete),this.CreateDelegate(this.CallDestory),t)
}else CommonUtil.SetFunctionTip(i)}GetFuncIdByViewType(t){return LostAbyssTabType.LOSTABYSS,FunctionType.LOST_ABYSS}ShowComplete(t){
return null==this.mainPanel&&(this.mainPanel=new LostAbyssRootView,this.mainPanel.setId(t,null,0)),this.mainPanel}CallDestory(){UIResMgr.DestroyUIObj(this.mainPanel),
this.mainPanel=null}CloseView(){s.N.inst.ClosePanel(this.mainPanel)}OpenCopyInfoPanel(){if(null==this.battlePanel){const t=new UIOpenParam
t.aniDir=LuaDirectionType.Default,t.layerType=LayerType.DefaultUI,s.N.inst.OpenById(n.I.LostAbyssBattleView,this.CreateDelegate(this.InitBattlePanelHandler),this.CreateDelegate(this.DestroyBattlePanelHandler),t)
}}InitBattlePanelHandler(t){return null==this.battlePanel&&(this.battlePanel=new LostAbyssBattleView,this.battlePanel.setId(t,null,0)),this.battlePanel}DestroyBattlePanelHandler(){
null!=this.battlePanel&&(UIResMgr.DestroyUIObj(this.battlePanel),this.battlePanel=null)}CloseBattlePanel(){s.N.inst.CloseById(n.I.LostAbyssBattleView)}OpenSuccessPanel(){
if(this.CloseBattlePanel(),null!=this.successPanel&&this.successPanel.isShow_get())this.successPanel.node.SetActive(!1),this.successPanel.Clear(),
this.successPanel.node.SetActive(!0),this.successPanel.hasRush=!0,this.successPanel.OnAddToScene()
else{const t=new UIOpenParam
t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!0,s.N.inst.OpenById(n.I.LostAbyssSuccessPanel,this._degf_successShowHandler,this._degf_successDestroyHandler,t)}}
successShowHandler(t){return this.successPanel=new LostAbyssSuccessPanel,this.successPanel.setId(t,null,0),this.successPanel}successDestroyHandler(){
null!=this.successPanel&&(UIResMgr.DestroyUIObj(this.successPanel),this.successPanel=null)}CloseSuccessPanel(){
null!=this.successPanel?s.N.inst.ClosePanel(this.successPanel):s.N.inst.UnLoading(n.I.LostAbyssSuccessPanel)}OpenDefeatePanel(){BloodDefeatControl.inst.OpenPanel()}
UpdateBattlePorss(t){LostAbyssModel.Inst_Get().UpdateCopyPross(t),null!=this.battlePanel&&this.battlePanel.isShow_get()&&this.battlePanel.UpdateCopyPross()}UpdateBattleBuff(t){
null!=this.battlePanel&&this.battlePanel.isShow_get()&&this.battlePanel.UpdateCopyBuff(t)}static Inst_Get(){return null==l.Inst&&(l.Inst=new l),l.Inst}}l.LOST=0,l.MEDAL=1,
l.Inst=null},14187:(t,e,i)=>{i.d(e,{u:()=>d})
var s=i(38836),n=i(86133),l=i(68662),a=i(16812),o=i(38962),r=i(85770),h=i(24524)
class d extends a.k{constructor(){super(),this.serverData=null,this.singleRecordMap=null,this.selectLayer=0,this.curClickCopyItemRes=null,this.remainTimes=3,this.m_evaluateVo=null,
this.settlement=null,this.IsNewStage=!1,this.stage=0,this.curStageStartTime=0,this.evaluateTimes=null,this.tryOpenPanel=!0,this.copyMode=1,this.viewType=1,this.isvipdided=!1,
this.boss_alive=!1,this.SpCopyDic1=null,this.SpCopyDic2=null,this.SM_CopyTarget=null,this.leftBuyCount=null,this.showLeftNum=null,this.showTotalNum=null,this.SpCopyDic1=new o.X,
this.SpCopyDic2=new o.X,this.ParseSpCopyLis()}ParseSpCopyLis(){const t=h.o.Inst().braveTrialList
if(null!=t)for(const[e,i]of(0,s.V5)(t))i.SpecialShowRewardValue_get().Count()>0&&(1==i.copyMode&&null!=i.braveLevel?this.SpCopyDic1.LuaDic_AddOrSetItem(i.braveLevel,i):2==i.copyMode&&null!=i.braveLevel&&this.SpCopyDic2.LuaDic_AddOrSetItem(i.braveLevel,i))
}GetSpCopyCfg(t,e){return 1==t?this.SpCopyDic1.LuaDic_GetItem(e):2==t?this.SpCopyDic2.LuaDic_GetItem(e):void 0}ResetModel(){this.copyMode=1,this.isvipdided=!1,
this.SM_CopyTarget=null,this.boss_alive=!1}serverData_set(t){this.serverData=t}SetEnterNum(){
const t=h.o.Inst().GetBraveTrialCopy(1,1),e=this.serverData.todayEnterHistory,i=t.challengesTimes-e,n=this.serverData.todayBuyTimes,l=t,a=l.controllerType,o=VipFacade.inst.model.GetCopyAddCount(a),d=RecoverModel.Inst_get().GetCopyHasRecoveredCount(a)
this.leftBuyCount=o-n
let c=0,u=0
const m=r.a.Inst_get().GetCopyRecByKey(a)
if(null!=m){c=m.todayItemTimes
for(const[t,e]of(0,s.V5)(m.sweepMap))u+=e}this.showLeftNum=i+d+n+c-u,this.showLeftNum=this.showLeftNum>0&&this.showLeftNum||0,this.showTotalNum=l.challengesTimes+d+n+c,
this.showLeftNum}GetSelectChapterIdx(){let t=0
let e=h.o.Inst().GetBraveTrialTotalLayer()
for(;e>=1;){if(this.IsChapterUnlock(e)){t=e
break}e-=1}return 0==t&&(t=1),t}IsChapterUnlock(t){const e=t-1
return!!(e<=0||this.IsChapterPass(e))}GetStageEvaluation(t,e){let i=6
const s=h.o.Inst().GetBraveTrialCopy(t,e)
return null!=s&&(i=this.GetDoneMinEvaluation(s.id)),i}IsStagePass(t,e){let i=!1
const s=h.o.Inst().GetBraveTrialCopy(t,e)
return null!=s&&(i=this.GetPassState(s.id)),i}IsStageUnlock(t,e,i){const s=h.o.Inst().GetBraveTrialCopy(t,e,i)
if(null!=s)if(s.preCopy>0){if(this.GetPassState(s.preCopy)){const i=e-1
if(i<=0||this.IsStagePass(t,i))return!0}}else{const i=e-1
if(i<=0||this.IsStagePass(t,i))return!0}return!1}GetStageData(t){if(null!=this.serverData){let e=null
if(e=this.serverData.singleRecordMap[t],null!=e)return e}return null}GetPassState(t){let e=!1
if(null!=this.serverData){const i=this.GetStageData(t)
null!=i&&(e=i.pass)}return e}GetDoneMinEvaluation(t){let e=6
if(null!=this.serverData){const i=this.GetStageData(t)
if(null!=i)for(const[t,n]of(0,s.V5)(i.evaluations))n<e&&(e=n)}return e}IsChapterPass(t){const e=h.o.Inst().GetBraveTrialCopyList(t)
if(null!=e)for(const[t,i]of(0,s.V5)(e)){if(0==this.GetPassState(i.id))return!1}return!0}UpdateEvaluate(t){this.m_evaluateVo=t,this.IsNewStage=!1,
this.curStageStartTime=l.D.serverMSTime_get(),this.stage=t.evaluateLevel,this.ParseCfg(),this.RaiseEvent(d.EVALUATE_UPDATE,t)}ParseCfg(){
const t=h.o.Inst().getItemById(r.a.Inst_get().currentCopyId)
null!=t&&(this.evaluateTimes=t.PassEvaluateValue_get().intValue.GetLuaToArray())}SM_LostAbyssCopyEnd(t){this.boss_alive=!1,this.settlement=t,this.UpdateCopyPross(null)}
UpdateCopyPross(t){this.SM_CopyTarget=t}GetCopyPross(t){let e=1
if(null!=this.SM_CopyTarget){for(const[t,i]of(0,s.vy)(this.SM_CopyTarget.list)){const i=this.SM_CopyTarget.list[t]
e=i.keyName,0==i.keyName&&(e=1,Debuger.LogError((0,n.T)("副本阶段数据异常，不应该为0")))}
return t<this.SM_CopyTarget.list[e].keyName-1?-1:t==this.SM_CopyTarget.list[e].keyName-1?this.SM_CopyTarget.list[e].value:0}return 0}static Inst_Get(){
return null==d.Inst&&(d.Inst=new d),d.Inst}}d.EVALUATE_UPDATE="EVALUATE_UPDATE",d.Inst=null},51954:(t,e,i)=>{i.d(e,{E:()=>U})
var s=i(43662),n=i(23833),l=i(98800),a=i(26055),o=i(87722),r=i(31546),h=i(70650),d=i(99294),c=i(9986),u=i(6665),m=i(9776),I=i(35880),g=i(93877),_=i(72005),p=i(16261),C=i(51868),S=i(85682),f=i(5494),y=i(61613),w=i(60130),D=i(79534),T=i(75696),A=i(53905),v=i(92679),L=i(87923),M=i(27122),b=i(65772),R=i(29839),P=i(37648),G=i(55492),O=i(24524),E=i(22662),B=i(68637),k=i(41864),x=i(65550),V=i(31931),N=i(12970),H=i(14187)
class U extends C.${constructor(...t){super(...t),this.left=null,this.right=null,this.degree=null,this.Normbtn=null,this.Hardbtn=null,this.CopyLevel=null,this.Limit=null,
this.Challengebtn=null,this.MonsterInfo=null,this.AwardInfo=null,this.ShowAwardBtn=null,this.MonsterName=null,this.ShowMonsterBtn=null,this.RewardScrollview=null,
this.rewardGrid=null,this.tipBtn=null,this.bossTexture=null,this.unlockWidget=null,this.unlockclose1=null,this.unlockclose2=null,this.unlocklab=null,this.unlockmask=null,
this.toptotal=null,this.midtotal=null,this.buttomtotal=null,this.toptotalsp=null,this.midtotalsp=null,this.buttomtotalsp=null,this.toptotaltoplab=null,this.midtotaltoplab=null,
this.buttomtotaltoplab=null,this.topcurlab=null,this.topnextlab=null,this.midcurlab=null,this.midnextlab=null,this.buttomcurlab=null,this.buttomnextlab=null,this.CopyDecs=null,
this.copyRes=null,this.boss=null,this.rotateIndex=-1,this.selectLayer=0,this.recommendStage=1,this.leftAnchor=null,this.rightAnchor=null,this.SpRewardScrollview=null,
this.SprewardGrid=null,this.pass=null,this.nextPass=null,this.bg1=null,this.bg2=null,this.Normbg=null,this.Hardbg=null}InitView(){super.InitView(),
this.left=this.CreateComponent(d.z,1),this.right=this.CreateComponent(d.z,2),this.degree=this.CreateComponent(d.z,3),this.Normbtn=this.CreateComponent(c.W,4),
this.Hardbtn=this.CreateComponent(c.W,5),this.CopyLevel=this.CreateComponent(g.Q,6),this.Limit=this.CreateComponent(g.Q,7),this.Challengebtn=this.CreateComponent(c.W,8),
this.MonsterInfo=this.CreateComponent(d.z,9),this.AwardInfo=this.CreateComponent(d.z,10),this.ShowAwardBtn=this.CreateComponent(c.W,11),
this.MonsterName=this.CreateComponent(g.Q,13),this.ShowMonsterBtn=this.CreateComponent(c.W,14),this.RewardScrollview=this.CreateComponent(m.h,15),
this.rewardGrid=this.CreateComponent(u.A,16),this.tipBtn=this.CreateComponent(c.W,17),this.bossTexture=this.CreateComponent(p.X,18),this.unlockWidget=this.CreateComponent(I.d,19),
this.unlockclose1=this.CreateComponent(c.W,20),this.unlockclose2=this.CreateComponent(c.W,21),this.unlocklab=this.CreateComponent(g.Q,22),
this.unlockmask=this.CreateComponent(d.z,23),this.toptotal=this.CreateComponent(d.z,24),this.midtotal=this.CreateComponent(d.z,25),this.buttomtotal=this.CreateComponent(d.z,26),
this.toptotalsp=this.CreateComponent(_.w,27),this.midtotalsp=this.CreateComponent(_.w,28),this.buttomtotalsp=this.CreateComponent(_.w,29),
this.toptotaltoplab=this.CreateComponent(d.z,30),this.midtotaltoplab=this.CreateComponent(d.z,31),this.buttomtotaltoplab=this.CreateComponent(d.z,32),
this.topcurlab=this.CreateComponent(g.Q,33),this.topnextlab=this.CreateComponent(g.Q,34),this.midcurlab=this.CreateComponent(g.Q,35),this.midnextlab=this.CreateComponent(g.Q,36),
this.buttomcurlab=this.CreateComponent(g.Q,37),this.buttomnextlab=this.CreateComponent(g.Q,38),this.CopyDecs=this.CreateComponent(g.Q,39),
this.leftAnchor=this.CreateComponent(d.z,40),this.rightAnchor=this.CreateComponent(d.z,41),this.SpRewardScrollview=this.CreateComponent(m.h,42),
this.SprewardGrid=this.CreateComponent(u.A,43),this.pass=this.CreateComponent(g.Q,44),this.nextPass=this.CreateComponent(g.Q,45),this.bg1=this.CreateComponent(_.w,46),
this.bg2=this.CreateComponent(_.w,47),this.Normbg=this.CreateComponent(d.z,48),this.Hardbg=this.CreateComponent(d.z,49),this.registerUIScId=S.D.LOST_ABYSS,
this.registerUIId=f.I.RYDailyPanel,this.rewardGrid.SetInitInfo("ui_baseitem",null,T.j),this.SprewardGrid.SetInitInfo("ui_baseitem",null,T.j)}Clear(){this.RemoveLis(),
null!=this.rotateIndex&&-1!=this.rotateIndex&&(h.e.GetInst().UnregDrag(this.rotateIndex),this.rotateIndex=-1),this.ClearModel(),
s.M.Instance_get().DeactiveStage(U.STAGE_ID,this.bossTexture.FatherId,this.bossTexture.ComponentId),super.Clear()}Destroy(){super.Destroy()}SetData(){this.AddLis(),
this.UpdateAnchors(),P.P.Inst_get().IsFunctionOpened(G.x.LOST_ABYSS_HARD)&&H.u.Inst_Get().IsStageUnlock(1,1,2)?this.degree.SetActive(!0):this.degree.SetActive(!1),
this.SelectCopyMode()}UpdateAnchors(){this.bg1.widthSet(y.v.GetAdaptionWidth(1178,1448)),w.O.SetAnchorPos(this.leftAnchor,!0,!1,0,!1),w.O.SetAnchorPos(this.rightAnchor,!1,!1,0,!1)}
AddLis(){this.m_handlerMgr.AddClickEvent(this.Normbtn,this.CreateDelegate(this.OnSelectModeClick)),
this.m_handlerMgr.AddClickEvent(this.Hardbtn,this.CreateDelegate(this.OnSelectModeClick)),this.m_handlerMgr.AddClickEvent(this.Challengebtn,this.CreateDelegate(this.Goto)),
this.m_handlerMgr.AddClickEvent(this.tipBtn,this.CreateDelegate(this._OnTipClick)),this.m_handlerMgr.AddClickEvent(this.ShowAwardBtn,this.CreateDelegate(this.ShowInfoClick)),
this.m_handlerMgr.AddClickEvent(this.ShowMonsterBtn,this.CreateDelegate(this.ShowInfoClick)),
this.m_handlerMgr.AddClickEvent(this.unlockclose1,this.CreateDelegate(this.UnLockCloseClick)),
this.m_handlerMgr.AddClickEvent(this.unlockclose2,this.CreateDelegate(this.UnLockCloseClick)),
this.m_handlerMgr.AddEventMgr(v.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors)),this.RegGuide()}RemoveLis(){this.UnRegGuide(),this.m_handlerMgr.Clear()}RegGuide(){
B.c.Inst.RegGameObject(S.D.UI_DAILY_LOSTABYSS_CHANEL_BTN,this.Challengebtn.node),B.c.Inst.RegGameObject(S.D.UI_DAILY_LOSTABYSS_NORMAL_BTN,this.Normbtn.node),
B.c.Inst.RegGameObject(S.D.UI_DAILY_LOSTABYSS_HARD_BTN,this.Hardbtn.node),B.c.Inst.RegGameObject(S.D.UI_DAILY_LOSTABYSS_REWARD_BTN,this.ShowAwardBtn.node)}UnRegGuide(){
B.c.Inst.UnRegGameObject(S.D.UI_DAILY_LOSTABYSS_CHANEL_BTN),B.c.Inst.UnRegGameObject(S.D.UI_DAILY_LOSTABYSS_NORMAL_BTN),B.c.Inst.UnRegGameObject(S.D.UI_DAILY_LOSTABYSS_HARD_BTN),
B.c.Inst.UnRegGameObject(S.D.UI_DAILY_LOSTABYSS_REWARD_BTN)}CheckGuide(){L.l.CheckBtnClickTrigger(S.D.UI_DAILY_LOSTABYSS_CHANEL_BTN)}CheckGuide1(){
L.l.CheckBtnClickTrigger(S.D.UI_DAILY_LOSTABYSS_NORMAL_BTN)}CheckGuide2(){L.l.CheckBtnClickTrigger(S.D.UI_DAILY_LOSTABYSS_HARD_BTN)}CheckGuide3(){
L.l.CheckBtnClickTrigger(S.D.UI_DAILY_LOSTABYSS_REWARD_BTN)}UnLockCloseClick(){this.unlockWidget.node.SetActive(!1),this.unlockmask.SetActive(!1)}OnSelectModeClick(t,e){
t==this.Normbtn.ComponentId?(this.CheckGuide1(),this.SelectCopyMode(1)):t==this.Hardbtn.ComponentId&&(this.CheckGuide2(),this.SelectCopyMode(2))}ShowInfoClick(t,e){
t==this.ShowMonsterBtn.ComponentId?this.UpdateModel():t==this.ShowAwardBtn.ComponentId&&(this.CheckGuide3(),this.UpdateAward())}Goto(){
l.Y.Inst.m_primaryRoleInfo.Level_get()<this.copyRes.minLevelLimit?x.y.inst.ClientStrMsg(E.r.SystemTipMessage,"等级不足"):(this.CheckGuide(),R.p.inst.SendEnterCopy(this.copyRes.id))}
_OnTipClick(t,e,i){const s=w.O.GetUIWidth(),n=new A.w
n.position=new D.P(-385-(s-1280)/2,320,0),n.width=450,n.infoId="LOST:TIPS",b.Q.Inst_get().Open(n)}SelectCopyMode(t){t=t||H.u.Inst_Get().copyMode,H.u.Inst_Get().copyMode=t,
1==t?(this.Normbtn.SetIsEnabled(!1),this.Hardbtn.SetIsEnabled(!0),this.Normbg.SetActive(!0),this.Hardbg.SetActive(!1),this.bg1.spriteNameSet("rylostabyss_sp_0013"),
this.bg2.spriteNameSet("rylostabyss_sp_0011")):2==t&&(this.Normbtn.SetIsEnabled(!0),this.Hardbtn.SetIsEnabled(!1),this.Normbg.SetActive(!1),this.Hardbg.SetActive(!0),
this.bg1.spriteNameSet("rylostabyss_sp_0022"),this.bg2.spriteNameSet("rylostabyss_sp_0023")),this.UpdateView()}UpdateView(){const t=H.u.Inst_Get().GetSelectChapterIdx()
this.selectLayer=t,this.copyRes=O.o.Inst().GetBraveTrialCopyList(this.selectLayer)[this.GetLastBattleStage()-1],null!=this.copyRes&&(this.UpdateModel(),
this.CopyLevel.textSet(string.format("失落深渊第%d关",this.copyRes.level)),this.UpdateTotal())}UpdateModel(){this.AwardInfo.SetActive(!1),this.MonsterInfo.SetActive(!0)
let t=this.copyRes.showRewardList_get()
null!=t&&t.Count()>0?(this.pass.node.SetActive(!0),this.rewardGrid.data_set(t)):this.pass.node.SetActive(!1)
let e=H.u.Inst_Get().GetSpCopyCfg(this.copyRes.copyMode,this.copyRes.braveLevel)
if(null!=e)if(t=e.showRewardList_get(),null!=t&&t.Count()>0){this.nextPass.node.SetActive(!0)
let i=e.level-this.copyRes.level
i<=0&&(e=H.u.Inst_Get().GetSpCopyCfg(this.copyRes.copyMode,this.copyRes.braveLevel+1),null!=e&&(i=e.level-this.copyRes.level,t=e.showRewardList_get())),
this.nextPass.textSet(`再通[5FB470]${i}[-]关可得奖励`),this.SprewardGrid.data_set(t)}else this.nextPass.node.SetActive(!1)
else this.nextPass.node.SetActive(!1)
s.M.Instance_get().ActiveStage(U.STAGE_ID)
const i=n.a.getInst().getObjById(this.copyRes.bossShow)
if(null!=i){const t=new a.O
this.ClearModel(),this.boss=M.Q.Inst().GetObjectByName("MonsterCharacter",o._),this.boss.Info_set(t)
const e=new r.O
e._displayID=i.displayId,e._world=s.M.Instance_get().GetStageWorldType(U.STAGE_ID),e._bNeedWaitAnime=!0,this.boss.InitPhotoByInfo(i,e,0),this.boss.MainRole_get().DisableShadow(),
s.M.Instance_get().SetDisplayObject(U.STAGE_ID,this.boss.MainRole_get().handle,0),s.M.Instance_get().SetWorldRotation(U.STAGE_ID,0,new D.P),this.boss.SetSize(.7*i.scale/1e4),
null!=i.rotationList&&this.boss.setDirectionXYZ(new D.P(i.rotationList[0],i.rotationList[1],i.rotationList[2])),this.bossTexture.SetMainTextureByPhoto(U.STAGE_ID),
this.bossTexture.SetUVRect(0,0,1,1),this.rotateIndex=h.e.GetInst().RegDrag(this.bossTexture.node,this.boss.MainRole_get()),this.MonsterName.textSet(i.name),
l.Y.Inst.PrimaryRoleInfo_get().Level_get()<this.copyRes.minLevelLimit?(this.Limit.node.SetActive(!0),
this.Limit.textSet(`${k.h.GetLevelStr(this.copyRes.minLevelLimit)}解锁挑战`)):this.Limit.node.SetActive(!1)}}ClearModel(){null!=this.boss&&(this.boss.Destroy(),this.boss=null)}
UpdateAward(){}GetLastBattleStage(){const t=O.o.Inst().GetBraveTrialCopyList(this.selectLayer).Count()
let e=null,i=null,s=t
for(;s>=1;){const t=O.o.Inst().GetBraveTrialCopy(this.selectLayer,s),n=N.F.getInst().GetCanEnterCopyByLvAndTransfer(t.id),l=H.u.Inst_Get().IsStageUnlock(this.selectLayer,s)
if(n==V.f.CAN&&l){if(0==H.u.Inst_Get().IsStagePass(this.selectLayer,s)){e=s
break}null==i&&(i=s)}s-=1}return this.recommendStage=null!=e?e:null!=i?i+1<=t?i+1:i:1,this.recommendStage}UpdateTotal(){
1==this.recommendStage?(this.toptotal.transform.SetLocalPositionXYZ(0,0,0),this.midtotal.transform.SetLocalPositionXYZ(0,-272,0),
this.buttomtotal.transform.SetLocalPositionXYZ(0,-453,0),this.toptotalsp.spriteNameSet("rylostabyss_sp_0010"),this.midtotalsp.spriteNameSet("rylostabyss_sp_0006"),
this.buttomtotalsp.spriteNameSet("rylostabyss_sp_0006"),this.toptotalsp.MakePixelPerfect(),this.midtotalsp.MakePixelPerfect(),this.buttomtotalsp.MakePixelPerfect(),
this.topcurlab.node.SetActive(!0),this.midcurlab.node.SetActive(!1),this.buttomcurlab.node.SetActive(!1),this.topnextlab.node.SetActive(!1),this.midnextlab.node.SetActive(!0),
this.buttomnextlab.node.SetActive(!0),this.toptotaltoplab.transform.SetLocalPositionXYZ(-20,-50,0),this.midtotaltoplab.transform.SetLocalPositionXYZ(-20,50,0),
this.buttomtotaltoplab.transform.SetLocalPositionXYZ(-20,50,0),this.topcurlab.textSet(`第${this.recommendStage}关`),this.midnextlab.textSet(`第${this.recommendStage+1}关`),
this.buttomnextlab.textSet(`第${this.recommendStage+2}关`)):2==this.recommendStage?(this.toptotal.transform.SetLocalPositionXYZ(0,130,0),
this.midtotal.transform.SetLocalPositionXYZ(0,-141,0),this.buttomtotal.transform.SetLocalPositionXYZ(0,-324,0),this.toptotalsp.spriteNameSet("rylostabyss_sp_0010"),
this.midtotalsp.spriteNameSet("rylostabyss_sp_0006"),this.buttomtotalsp.spriteNameSet("rylostabyss_sp_0006"),this.toptotalsp.MakePixelPerfect(),this.midtotalsp.MakePixelPerfect(),
this.buttomtotalsp.MakePixelPerfect(),this.topcurlab.node.SetActive(!1),this.midcurlab.node.SetActive(!0),this.buttomcurlab.node.SetActive(!1),this.topnextlab.node.SetActive(!0),
this.midnextlab.node.SetActive(!1),this.buttomnextlab.node.SetActive(!0),this.toptotaltoplab.transform.SetLocalPositionXYZ(-20,-50,0),
this.midtotaltoplab.transform.SetLocalPositionXYZ(-20,50,0),this.buttomtotaltoplab.transform.SetLocalPositionXYZ(-20,50,0),this.topnextlab.textSet(`第${this.recommendStage-1}关`),
this.midcurlab.textSet(`第${this.recommendStage}关`),
this.buttomnextlab.textSet(`第${this.recommendStage+1}关`)):this.recommendStage==O.o.Inst().GetBraveTrialCopyList(this.selectLayer).Count()?(this.toptotal.transform.SetLocalPositionXYZ(0,70,0),
this.midtotal.transform.SetLocalPositionXYZ(0,-115,0),this.buttomtotal.transform.SetLocalPositionXYZ(-26,-328,0),this.toptotalsp.spriteNameSet("rylostabyss_sp_0006"),
this.midtotalsp.spriteNameSet("rylostabyss_sp_0006"),this.buttomtotalsp.spriteNameSet("rylostabyss_sp_0009"),this.toptotalsp.MakePixelPerfect(),this.midtotalsp.MakePixelPerfect(),
this.buttomtotalsp.MakePixelPerfect(),this.topcurlab.node.SetActive(!1),this.midcurlab.node.SetActive(!1),this.buttomcurlab.node.SetActive(!0),this.topnextlab.node.SetActive(!0),
this.midnextlab.node.SetActive(!0),this.buttomnextlab.node.SetActive(!1),this.toptotaltoplab.transform.SetLocalPositionXYZ(-20,50,0),
this.midtotaltoplab.transform.SetLocalPositionXYZ(-20,50,0),this.buttomtotaltoplab.transform.SetLocalPositionXYZ(-20,70,0),this.topnextlab.textSet(`第${this.recommendStage-2}关`),
this.midnextlab.textSet(`第${this.recommendStage-1}关`),this.buttomcurlab.textSet(`第${this.recommendStage}关`)):(this.toptotal.transform.SetLocalPositionXYZ(0,45,0),
this.midtotal.transform.SetLocalPositionXYZ(0,-136,0),this.buttomtotal.transform.SetLocalPositionXYZ(0,-322,0),this.toptotalsp.spriteNameSet("rylostabyss_sp_0006"),
this.midtotalsp.spriteNameSet("rylostabyss_sp_0006"),this.buttomtotalsp.spriteNameSet("rylostabyss_sp_0006"),this.toptotalsp.MakePixelPerfect(),this.midtotalsp.MakePixelPerfect(),
this.buttomtotalsp.MakePixelPerfect(),this.topcurlab.node.SetActive(!1),this.midcurlab.node.SetActive(!0),this.buttomcurlab.node.SetActive(!1),this.topnextlab.node.SetActive(!0),
this.midnextlab.node.SetActive(!1),this.buttomnextlab.node.SetActive(!0),this.toptotaltoplab.transform.SetLocalPositionXYZ(-20,50,0),
this.midtotaltoplab.transform.SetLocalPositionXYZ(-20,50,0),this.buttomtotaltoplab.transform.SetLocalPositionXYZ(-20,50,0),this.topnextlab.textSet(`第${this.recommendStage-1}关`),
this.midcurlab.textSet(`第${this.recommendStage}关`),this.buttomnextlab.textSet(`第${this.recommendStage+1}关`))}}U.STAGE_ID=121},84632:(t,e,i)=>{i.d(e,{R:()=>j})
var s,n,l,a,o,r=i(18998),h=i(75507),d=i(42292),c=i(71409),u=i(32076),m=i(86133),I=i(97461),g=i(68662),_=i(38935),p=i(56937),C=i(31222),S=i(5494),f=i(52726),y=i(98130),w=i(98885),D=i(85602),T=i(79534),A=i(26753),v=i(92679),L=i(74045),M=i(49067),b=i(75439),R=i(54875),P=i(14695),G=i(59514),O=i(54603),E=i(92415),B=i(19983),k=i(49892),x=i(75961),V=i(65550),N=i(51198),H=i(90181),U=i(69162)
function F(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let j=(s=(0,c.GH)(E.k.SM_GetMail),n=(0,c.GH)(E.k.SM_MailUpdate),l=(0,c.GH)(E.k.SM_RewardMail),o=class t{
constructor(){this.mainView=null,this.detailView=null,this.deleteView=null,this.delectId=-1,this.panelPos=null,this._degf_DestroyDeletePanel=null,this._degf_GetMailHandler=null,
this._degf_MailUpdateHandler=null,this._degf_OnDeletePanelComplete=null,this._degf_RewardMailHandler=null,this.panelPos=new T.P(670,0),
this._degf_DestroyDeletePanel=()=>this.DestroyDeletePanel(),this._degf_GetMailHandler=t=>this.GetMailHandler(t),this._degf_MailUpdateHandler=t=>this.MailUpdateHandler(t),
this._degf_OnDeletePanelComplete=t=>this.OnDeletePanelComplete(t),this._degf_RewardMailHandler=t=>this.RewardMailHandler(t),t._model=H.x.GetInst(),this.RegistProtocol()}
static GetInst(){return null==t._inst&&(t._inst=new t),t._inst}RegistProtocol(){}OpenOrClosePanel(){
null!=this.mainView&&this.mainView.node.active||null!=this.detailView&&this.detailView.node.active?this.ShowOrHidePanel(!1):(this.ReqGetMail(),this.OpenMailMainPanel())}
ClosePanel(){(null!=this.mainView&&this.mainView.node.active||null!=this.detailView&&this.detailView.node.active)&&this.ShowOrHidePanel(!1)}OpenPanel(){this.ReqGetMail(),
this.OpenMailMainPanel()}OpenOrClosePanelFromIcon(){1==t._model.UnreadNum_get()?(t._model.OpenDetail=!0,this.OpenMailDetailPanel()):this.OpenMailMainPanel(),this.ReqGetMail()}
OpenMailMainPanel(){if(null!=this.detailView&&this.CloseMailDetailPanel(),null==this.mainView){const e=A.d.Inst_get().controller.ChatMainPanel_get()
if(null!=e){const i=h.o.getPrefab("ui_mail_main"),s=(0,r.instantiate)(i)
let n=null
n=s.getCNode(),this.mainView=n,e.Container.addChild(s),this.mainView.OnAddToScene(),t._model.UpdateNoTipId()}}else 0==this.mainView.node.active&&(this.mainView.node.SetActive(!0),
this.mainView.OnAddToScene())}OpenDeletePanel(){if(null==this.deleteView){const t=new p.v
t.layerType=f.F.Tip,C.N.inst.OpenById(S.I.MailDeletePanel,this._degf_OnDeletePanelComplete,this._degf_DestroyDeletePanel,t)}}OnDeletePanelComplete(t){
return null==this.deleteView&&(this.deleteView=new U.t,this.deleteView.setId(t,null,0)),this.deleteView}CloseDeletePanel(){
null!=this.deleteView&&C.N.inst.ClosePanel(this.deleteView)}DestroyDeletePanel(){this.deleteView=null}CloseMailMainPanel(){null!=this.mainView&&(this.mainView.node.SetActive(!1),
A.d.Inst_get().controller.ChatMainPanel_get().SetChatContentState(!0))}OpenMailDetailPanel(){if(null!=this.mainView&&this.CloseMailMainPanel(),null==this.detailView){
const t=A.d.Inst_get().controller.ChatMainPanel_get()
if(null!=t){const e=h.o.getPrefab("ui_mail_detail"),i=(0,r.instantiate)(e)
let s=null
s=i.getCNode(),this.detailView=s,t.Container.addChild(i),this.detailView.OnAddToScene()}}else 0==this.detailView.node.active&&(this.detailView.node.SetActive(!0),
this.detailView.OnAddToScene())}ShowOrHidePanel(t){null!=this.mainView&&(this.mainView.node.SetActive(t),
t?this.mainView.OnAddToScene():A.d.Inst_get().controller.ChatMainPanel_get().SetChatContentState(!0)),null!=this.detailView&&(this.detailView.node.SetActive(t),
t&&this.detailView.OnAddToScene())}CloseMailDetailPanel(){null!=this.detailView&&this.detailView.node.SetActive(!1)}DeleteSelectMail(){if(t._model.SelectMails_get().Count()>0){
const t=new M.B
t.infoId="MAIL:ONEKEY_DELETE",t.cancelHandle=null,t.cancelParam=null,t.layer=f.F.Tip,t.confirmHandle=(0,u.v)(this.DeleteAllMail,this),t.confirmParam=null,L.t.Inst().Open(t)
}else V.y.inst.ClientSysMessage(103006)}DeleteAllMail(e){const i=new D.Z
let s=t._model.SelectMails_get()
for(let t=0;t<s.Count();t++)i.Add(s[t].index)
this.ReqDeleteMail(i)}AllSelect(e){let i=0
for(;i<e.Count();)t._model.SetSelect(e[i]),i+=1
t._model.RaiseEvent(N.f.All_Select)}SetSelectMail(e,i){i?t._model.SetSelect(e):t._model.SetUnSelect(e)}ReqRewardMail(t,e){this.delectId=-1,null!=e&&e&&(this.delectId=t)
const i=new O.f
i.index=t,_.C.Inst.F_SendMsg(i)}ReqDeleteMail(t){if(0==t.Count())return void V.y.inst.ClientSysMessage(103006)
const e=new R.B
e.index=t,_.C.Inst.F_SendMsg(e)}ReqReadMail(t){const e=new G.N
e.index=t,_.C.Inst.F_SendMsg(e)}ReqGetMail(){const t=new P.f
_.C.Inst.F_SendMsg(t)}GetMailHandler(e){const i=e
null!=i&&t._model.HandleGetMail(i)}MailUpdateHandler(e){const i=e
null!=i&&t._model.HandleMailUpdate(i.mailsUpdate),null!=this.mainView&&this.mainView.HandleMsgUpdate(),null!=this.detailView&&this.detailView.HandleMsgUpdate()}HandleMailNum(e){
t._model.HandleMailNum(e)}RemoveNoticeIcon(){B.S.Inst_get().RemoveIcon(k.K.ICON_TIPS_MAIL)}AddNoticeIcon(){if(null!=this.mainView)return
const e=new x.U(k.K.ICON_TIPS_MAIL)
B.S.Inst_get().AddIcon(e),B.S.Inst_get().UpdateCount(k.K.ICON_TIPS_MAIL,t._model.UnreadNum_get())}ShowDetailPanel(e){this.CloseMailMainPanel(),t._model.CurActivateMailInfo_set(e),
t._model.GetNextMail(e),null==this.detailView?this.OpenMailDetailPanel():(this.detailView.node.SetActive(!0),this.detailView.UpdateActivateInfo(),this.detailView.OnAddToScene())}
GetTimeStr(t){let e=""
const i=w.M.String2Int(b.D.getInstance().getContent("MAIL:MAILBOX_EXPIRATION_DATE").getContent().stringVal)
t*=.001
const s=y.GF.INT(t)+86400*i-g.D.serverTime_get(),n=(0,m.T)("后过期")
return e=s>86400?y.GF.INT(s/86400)+((0,m.T)("天")+n):s>3600?y.GF.INT(s/3600)+((0,m.T)("小时")+n):(0,m.T)("即将过期"),e}RewardMailHandler(t){
null!=H.x.GetInst().CurActivateMailInfo_get()&&-1!=this.delectId&&this.delectId==H.x.GetInst().CurActivateMailInfo_get().index&&(this.delectId=-1,
I.i.Inst.RaiseEvent(v.g.MAIL_REWARD_UPDATE))}},o._inst=null,o._model=null,F(a=o,"GetInst",[d.n],Object.getOwnPropertyDescriptor(a,"GetInst"),a),
F(a.prototype,"GetMailHandler",[s],Object.getOwnPropertyDescriptor(a.prototype,"GetMailHandler"),a.prototype),
F(a.prototype,"MailUpdateHandler",[n],Object.getOwnPropertyDescriptor(a.prototype,"MailUpdateHandler"),a.prototype),
F(a.prototype,"RewardMailHandler",[l],Object.getOwnPropertyDescriptor(a.prototype,"RewardMailHandler"),a.prototype),a)},90181:(t,e,i)=>{i.d(e,{x:()=>y})
var s=i(38836),n=i(97461),l=i(16812),a=i(85602),o=i(38962),r=i(26753),h=i(92679),d=i(19983),c=i(49892),u=i(14792),m=i(62734),I=i(84632),g=i(51198),_=i(98885),p=i(87923),C=i(25449),S=i(36042)
class f{constructor(){this.index=0,this.simpleVo=null,this.detail=null,this.msg1=null}Init(t,e){this.index=e,this.simpleVo=t}InitDetail(t,e){this.index=e,this.detail=t,
null==t?this.simpleVo=null:this.RefreshSimpleVO()}Update(t){this.detail=t,null==t?this.simpleVo=null:this.RefreshSimpleVO()}RefreshSimpleVO(){if(null!=this.detail){const t=new S.u
t.mailId=this.detail.mailId,t.drawn=this.detail.drawn,t.startTime=this.detail.startTime,t.look=this.detail.look,t.titleInfos=this.detail.titleInfos,t.hasReward=this.HasReward(),
t.isGS=this.detail.isGS,this.simpleVo=t}}GetMailTitle(){let t=""
const e=C.o.GetInst().GetMailCfg(this.simpleVo.mailId)
return null!=e&&(t=p.l.Substitute(e.mailtitle,this.simpleVo.titleInfos)),t}GetMailContent(){let t=""
const e=C.o.GetInst().GetMailCfg(this.simpleVo.mailId)
return null!=e&&(t=e.mailcontent,t=_.M.Replace(t,"{name}",p.l.GainGameName()),t=p.l.Substitute(t,this.detail.contentInfos)),t}HasGetReward(){
return(null!=this.simpleVo||null!=this.detail)&&(null!=this.detail?this.detail.drawn:null!=this.simpleVo&&this.simpleVo.drawn)}GetTime(){
return null==this.simpleVo&&null==this.detail?0:null!=this.detail?this.detail.startTime.ToNum():null!=this.simpleVo?this.simpleVo.startTime.ToNum():0}HasReward(){
if(null==this.simpleVo&&null==this.detail)return!1
if(null!=this.detail){if(null!=this.detail.items&&this.detail.items.count>0&&!this.detail.drawn)return!0
if(null!=this.detail.rewards&&null!=this.detail.rewards.rewards&&this.detail.rewards.rewards.Count()>0&&!this.detail.drawn)return!0
}else if(null!=this.simpleVo&&this.simpleVo.hasReward&&!this.simpleVo.drawn)return!0
return!1}}class y extends l.k{constructor(){super(!1,0),this.m_curActivateMailInfo=null,this.m_nextMailInfo=null,this.totalMails=null,this.selectMails=null,this.m_unreadNum=0,
this.view_selectIndex=0,this.OpenDetail=!1,this.isOneClickGet=!1,this.noShowTipsMailIds=null,this._degf_CompareMail=null,this._degf_CompareTime=null,
this._degf_CompareTimeReverse=null,this.totalMails=new o.X,this.selectMails=new a.Z,this.noShowTipsMailIds=new a.Z,this._degf_CompareMail=(t,e)=>this.CompareMail(t,e),
this._degf_CompareTime=(t,e)=>this.CompareTime(t,e),this._degf_CompareTimeReverse=(t,e)=>this.CompareTimeReverse(t,e)}SelectMails_get(){return this.selectMails}SelectMails_set(t){
this.selectMails=t}UnreadNum_get(){return this.m_unreadNum}UnreadNum_set(t){const e=this.m_unreadNum
this.m_unreadNum=t,m.f.Inst.SetState(u.t.MAIL,this.m_unreadNum>0),n.i.Inst.RaiseEvent(h.g.MAIL_CNT_UPDATE)
const i=r.d.Inst_get().controller.ChatMainPanel_get()
null!=i&&i.UpdateMailRedPoint(u.t.MAIL,this.m_unreadNum>0),this.m_unreadNum>e?I.R.GetInst().AddNoticeIcon():0==this.m_unreadNum?I.R.GetInst().RemoveNoticeIcon():this.m_unreadNum==e&&this.HasShowTipId()&&I.R.GetInst().AddNoticeIcon(),
this.m_unreadNum>0&&d.S.Inst_get().UpdateCount(c.K.ICON_TIPS_MAIL,this.UnreadNum_get())}CurActivateMailInfo_get(){return this.m_curActivateMailInfo}CurActivateMailInfo_set(t){
this.m_curActivateMailInfo=t}NextMailInfo_get(){return this.m_nextMailInfo}NextMailInfo_set(t){this.m_nextMailInfo=t}static GetInst(){return null==y._inst&&(y._inst=new y),y._inst}
AddNoShowTipsMailIds(t){this.selectMails.Contains(t)||this.selectMails.Add(t)}IsNoShowTipsMailId(t){return this.selectMails.Contains(t)}RemoveNoShowTipsMailIds(t){
this.selectMails.Remove(t)}ResetModel(){this.m_unreadNum=0}SelectMailHandler(t){const e=t.Info_get()
this.SetSelect(e)}UnSelectMailHandler(t){const e=t.Info_get()
this.SetUnSelect(e)}GetTotalList(){const t=new a.Z
for(const[e,i]of(0,s.vy)(this.totalMails))null!=this.totalMails[e].simpleVo&&t.Add(this.totalMails[e])
return t.Sort(this.CompareMail),t}GetListReverse(){const t=new a.Z
for(const[e,i]of(0,s.vy)(this.totalMails))null!=this.totalMails[e].simpleVo&&(0==this.view_selectIndex?t.Add(this.totalMails[e]):1==this.view_selectIndex?this.totalMails[e].simpleVo.look&&t.Add(this.totalMails[e]):this.totalMails[e].simpleVo.look||t.Add(this.totalMails[e]))
return t.Sort(this.CompareTimeReverse),t}HandleDelMail(t){const e=this.GetTotalList()
let i=null,s=-1,n=0,l=0,a=0,o=e.Count()-1
for(;o>=0;)i=e[o],null!=i.simpleVo&&(n=i.simpleVo.startTime.ToNum(),l=t.simpleVo.startTime.ToNum(),n<l&&n>a&&(s=o,a=n)),o-=1
;-1!=s?this.CurActivateMailInfo_set(e[s]):this.CurActivateMailInfo_set(null)}CompareMail(t,e){const i=t,s=e
return i.simpleVo.isGS!=s.simpleVo.isGS?i.simpleVo.isGS?-1:1:i.simpleVo.look!=s.simpleVo.look?i.simpleVo.look?1:-1:i.HasReward()!=s.HasReward()?i.HasReward()?-1:1:0==i.simpleVo.startTime.Equal(s.simpleVo.startTime)?i.simpleVo.startTime.ToNum()<s.simpleVo.startTime.ToNum()?1:-1:0
}CompareTime(t,e){const i=t,s=e
return i.simpleVo.startTime.ToNum()<s.simpleVo.startTime.ToNum()?1:i.simpleVo.startTime.ToNum()>s.simpleVo.startTime.ToNum()?-1:0}CompareTimeReverse(t,e){
return-this.CompareTime(t,e)}GetUnreadList(){const t=new a.Z
for(const[e,i]of(0,s.vy)(this.totalMails))null==this.totalMails[e].simpleVo||this.totalMails[e].simpleVo.look||t.Add(this.totalMails[e])
return t.Sort(this.CompareTime),t}GetReadedList(){const t=new a.Z
for(const[e,i]of(0,s.vy)(this.totalMails))null!=this.totalMails[e].simpleVo&&this.totalMails[e].simpleVo.look&&t.Add(this.totalMails[e])
return t.Sort(this.CompareTime),t}HandleGetMail(t){this.totalMails.LuaDic_Clear()
let e=null
for(const[i,n]of(0,s.vy)(t.mails))e=new f,e.Init(t.mails[i],i),this.totalMails.LuaDic_AddOrSetItem(i,e)
if(this.UpdateTipNum(),this.OpenDetail){for(const[t,e]of(0,s.V5)(this.totalMails))if(!e.simpleVo.look&&null==this.CurActivateMailInfo_get()){this.CurActivateMailInfo_set(e),
this.RaiseEvent(g.f.Detail_Update_Info,e)
break}if(null==this.CurActivateMailInfo_get())for(const[t,e]of(0,s.V5)(this.totalMails))if(e.simpleVo.hasReward&&!e.simpleVo.drawn){this.CurActivateMailInfo_set(e),
this.RaiseEvent(g.f.Detail_Update_Info,e)
break}}else this.RaiseEvent(g.f.Main_Update_List)}HandleMailUpdate(t){for(const[e,i]of(0,
s.vy)(t))if(this.totalMails.LuaDic_ContainsKey(e))null!=this.CurActivateMailInfo_get()&&this.CurActivateMailInfo_get().index==e&&this.CurActivateMailInfo_get().Update(t[e]),
this.totalMails[e].Update(t[e]),null==t[e]&&this.totalMails.LuaDic_Remove(e)
else if(null!=t[e]){const i=new f
i.InitDetail(t[e],e),this.totalMails.LuaDic_AddOrSetItem(e,i)}this.UpdateTipNum(),
null!=this.CurActivateMailInfo_get()&&null!=this.CurActivateMailInfo_get().detail&&this.RaiseEvent(g.f.Detail_Update_Info,this.CurActivateMailInfo_get()),this.HandleNoticeIcon()}
UpdateNoTipId(){for(const[t,e]of(0,s.V5)(this.totalMails))null!=e.simpleVo&&this.AddNoShowTipsMailIds(e.simpleVo.mailId)}HasShowTipId(){for(const[t,e]of(0,
s.V5)(this.totalMails))if(null!=e.simpleVo&&!e.simpleVo.look&&!this.IsNoShowTipsMailId(e.simpleVo.mailId))return!0
return!1}UpdateTipNum(){let t=0
for(const[e,i]of(0,s.V5)(this.totalMails))null!=i.simpleVo&&(i.simpleVo.look?i.HasReward()&&(t+=1):t+=1)
this.UnreadNum_set(t)}IsSelected(t){let e=0
for(;e<this.selectMails.Count();){if(t.index==this.selectMails[e].index)return!0
e+=1}return!1}HandleMailNum(t){this.UnreadNum_set(t)}SetSelect(t){this.selectMails.Add(t)}SetUnSelect(t){let e=0
for(;e<this.selectMails.Count();){if(t.index==this.selectMails[e].index){this.selectMails.RemoveRange(e,1)
break}e+=1}}ClearSelect(){this.selectMails.Clear()}HasNoReward(){for(const[t,e]of(0,s.vy)(this.totalMails))if(this.totalMails[t].HasReward())return!1
return!0}HandleNoticeIcon(){if(0!=this.GetUnreadList().Count())return
this.HasNoReward()&&I.R.GetInst().RemoveNoticeIcon()}GetNoRewardList(){const t=new a.Z
for(const[e,i]of(0,s.vy)(this.totalMails)){const i=this.totalMails[e]
null!=i.simpleVo&&i.simpleVo.look&&!i.HasReward()&&t.Add(i)}return t}GetNextMail(t){const e=this.GetTotalList()
this.m_nextMailInfo=null
let i=!1,s=0
for(;s<e.Count();){const n=e[s]
if(i){this.m_nextMailInfo=n
break}n==t&&(i=!0),s+=1}}}y._inst=null},51198:(t,e,i)=>{i.d(e,{f:()=>s})
var s={SelectMailItem:"SelectMailItem",UnSelectMailItem:"UnSelectMailItem",Main_Update_List:"Main_Update_List",Detail_Update_Info:"Detail_Update_Info",All_Select:"All_Select",
Single_Toggle_Select:"Single_Toggle_Select"}},69162:(t,e,i)=>{i.d(e,{t:()=>d})
var s,n=i(18998),l=i(86133),a=i(61911),o=i(84632),r=i(90181)
const{ccclass:h}=n._decorator
let d=h("MailDeleteView")(s=class extends a.f{constructor(...t){super(...t),this.submitBtn=null,this.cancelBtn=null,this.closeBtn=null,this._degf_Close=null,this._degf_Delete=null,
this.lbContent=null}_initBinder(){super._initBinder(),this._degf_Close=(t,e)=>this.Close(t,e),this._degf_Delete=(t,e)=>this.Delete(t,e)}InitView(){super.InitView()}OnAddToScene(){
this.SetData(),this.AddClickEvent(this.submitBtn,this._degf_Delete),this.AddClickEvent(this.closeBtn,this._degf_Close),this.AddClickEvent(this.cancelBtn,this._degf_Close)}Clear(){
this.RemoveClickEvent(this.submitBtn,this._degf_Delete),this.RemoveClickEvent(this.closeBtn,this._degf_Close),this.RemoveClickEvent(this.cancelBtn,this._degf_Close)}Destroy(){
this.submitBtn=null,this.cancelBtn=null,this.closeBtn=null}Delete(t,e){o.R.GetInst().DeleteAllMail(null)}Close(t,e){o.R.GetInst().CloseDeletePanel()}SetData(){
r.x.GetInst().isOneClickGet?this.lbContent.textSet((0,l.T)("是否删除当前所有邮件?")):this.lbContent.textSet((0,l.T)("是否一键删除当前所有邮件?"))}})||s},60096:(t,e,i)=>{
var s,n=i(18998),l=i(83908),a=i(38045),o=i(97461),r=i(85602),h=i(79534),d=i(63076),c=i(26753),u=i(92679),m=i(88162),I=i(72208),g=i(18161),_=i(30459),p=i(5996),C=i(40863),S=i(69967),f=i(91517),y=i(84632),w=i(51198),D=i(90181),T=i(52212)
class A extends((0,l.yk)()){constructor(...t){super(...t),this._degf_ClickHandler=null}_initBinder(){super._initBinder(),this._degf_ClickHandler=(t,e)=>{}}InitView(){
super.InitView()}SetData(t){this.item.SetData(t),this.hasGain.SetActive(!1)}Clear(){}Destroy(){}}const{ccclass:v}=n._decorator
v("MailDetailView")(s=class extends((0,l.zB)()){constructor(...t){super(...t),this.m_info=null,this._rewardData=null,this._degf_CloseClickHandler=null,
this._degf_DeleteClickHandler=null,this._degf_DetailInfoHandler=null,this._degf_OnGridReposition=null,this._degf_OnItemRefreshFun=null,this._degf_RewardClickHandler=null,
this._degf_RewardedHandle=null}_initBinder(){super._initBinder(),this._degf_CloseClickHandler=(t,e)=>this.CloseClickHandler(t,e),
this._degf_DeleteClickHandler=(t,e)=>this.DeleteClickHandler(t,e),this._degf_DetailInfoHandler=t=>this.DetailInfoHandler(t),this._degf_OnGridReposition=()=>this.OnGridReposition(),
this._degf_OnItemRefreshFun=t=>{},this._degf_RewardClickHandler=(t,e)=>this.RewardClickHandler(t,e),this._degf_RewardedHandle=t=>this.RewardedHandle(t)}InitView(){super.InitView(),
this.grid.SetInitInfo("ui_mail_rewarditem",null,A),this.grid.OnReposition_set(this._degf_OnGridReposition)}OnAddToScene(){this.AddEvents(),
null!=D.x.GetInst().CurActivateMailInfo_get()&&(this.m_info=D.x.GetInst().CurActivateMailInfo_get(),this.UpdateInfo()),
c.d.Inst_get().controller.ChatMainPanel_get().SetChatContentState(!1)}AddEvents(){this.m_handlerMgr.AddClickEvent(this.BackBtn,this._degf_CloseClickHandler),
this.m_handlerMgr.AddClickEvent(this.GetBtn,this._degf_RewardClickHandler),this.m_handlerMgr.AddClickEvent(this.DeleteBtn,this._degf_DeleteClickHandler),
D.x.GetInst().AddEventHandler(w.f.Detail_Update_Info,this._degf_DetailInfoHandler),o.i.Inst.AddEventHandler(u.g.MAIL_REWARD_UPDATE,this._degf_RewardedHandle)}Clear(){
this.RemoveEvents()}Destroy(){D.x.GetInst().CurActivateMailInfo_set(null)}RemoveEvents(){this.m_handlerMgr.RemoveClickEvent(this.BackBtn,this._degf_CloseClickHandler),
this.m_handlerMgr.RemoveClickEvent(this.GetBtn,this._degf_RewardClickHandler),this.m_handlerMgr.RemoveClickEvent(this.DeleteBtn,this._degf_DeleteClickHandler),
D.x.GetInst().RemoveEventHandler(w.f.Detail_Update_Info,this._degf_DetailInfoHandler),o.i.Inst.RemoveEventHandler(u.g.MAIL_REWARD_UPDATE,this._degf_RewardedHandle)}
RewardClickHandler(t,e){y.R.GetInst().ReqRewardMail(this.m_info.index,null)}CloseClickHandler(t,e){y.R.GetInst().OpenMailMainPanel()}DeleteClickHandler(t,e){
this.m_info.HasReward()?y.R.GetInst().ReqRewardMail(this.m_info.index,!0):this.ReqDeleteMail()}ReqDeleteMail(){const t=new r.Z
t.Add(this.m_info.index),y.R.GetInst().ReqDeleteMail(t),null!=D.x.GetInst().NextMailInfo_get()&&null!=D.x.GetInst().NextMailInfo_get().simpleVo?y.R.GetInst().ShowDetailPanel(D.x.GetInst().NextMailInfo_get()):y.R.GetInst().OpenMailMainPanel()
}DetailInfoHandler(t){this.m_info=t,this.UpdateInfo()}UpdateActivateInfo(){this.m_info=D.x.GetInst().CurActivateMailInfo_get(),this.UpdateInfo()}UpdateInfo(){
this.UpdateMailTitle(),null!=this.m_info&&this.sysIcon.SetActive(this.m_info.simpleVo.isGS),
null!=this.m_info&&(null!=this.m_info.detail&&this.m_info.detail.look?(this.UpdateMailDetailInfo(),this.UpdateAttachItem(),
this.UpdateBtns()):y.R.GetInst().ReqReadMail(this.m_info.index))}OnGetDetailInfo(){null!=this.m_info&&null!=this.m_info.detail&&(this.UpdateMailDetailInfo(),
this.UpdateAttachItem(),this.UpdateBtns())}HandleMsgUpdate(){null!=this.grid&&(this.UpdateAttachItem(),this.UpdateBtns())}UpdateMailTitle(){
null!=this.m_info?this.mailTitle.textSet(this.m_info.GetMailTitle()):this.mailTitle.textSet("")}UpdateMailDetailInfo(){if(null!=this.m_info){
this.mailContent.textSet(`　　${this.m_info.GetMailContent()}`),this.deadline.textSet(y.R.GetInst().GetTimeStr(this.m_info.simpleVo.startTime.ToNum()))
let t=this.mailContent.node.transform.GetLocalPosition().y
t-=40+this.mailContent.height()
const e=this.deadline.node.transform.GetLocalPosition()
e.y=t,this.deadline.node.transform.SetLocalPosition(e),h.P.Recyle(e)}else this.mailContent.textSet(""),this.deadline.textSet("")
this.contentScrollView.scrollTo(T.F.zero)}OnGridReposition(){const t=this.grid.itemList
if(null!=t){if(t.Count()>0){if(null==this.m_info||null==this.m_info.detail||this.m_info.detail.drawn){let e=0
for(;e<t.Count();){t[e].hasGain.SetActive(!0),e+=1}}this.grid.node.SetActive(!0)}this.rewardContent.SetLocalPositionXYZ(0,0,0)}}UpdateAttachItem(){this.grid.node.SetActive(!1),
this.grid.data_set(this.showReward_get()),this.scrollView.scrollTo(T.F.zero)
let t=0
t=this.showReward_get().Count()%8==0?Math.floor(this.showReward_get().Count()/8-1):Math.floor(this.showReward_get().Count()/8),this.rewardContent.height=80*(t+1),
this.rewardContent.SetLocalPositionXYZ(0,0,0)}UpdateBtns(){null!=this.m_info&&this.m_info.HasReward()?(this.GetBtn.node.SetActive(!0),
this.DeleteBtn.node.SetActive(!1)):(this.GetBtn.node.SetActive(!1),this.DeleteBtn.node.SetActive(!0))}showReward_get(){if(this._rewardData=new r.Z,
null==this.m_info)return this._rewardData
if(null!=this.m_info.detail){let t=0,e=null
if(null!=this.m_info.detail.rewards){const i=this.m_info.detail.rewards.rewards.Count()
let s=null
for(t=0;t<i;){if(s=this.m_info.detail.rewards.rewards[t],(0,a.t2)(s,g.e)){const t=s
e=new d.M(t.itemModelId,null),e.count=t.num,e.isCanOperate=!1,e.isEquipCompare=!1,this._rewardData.Add(e)}else((0,a.t2)(s,S.A)||(0,a.t2)(s,I.L)||(0,a.t2)(s,_.x)||(0,
a.t2)(s,p.C)||(0,a.t2)(s,C.N)||(0,a.t2)(s,m._))&&(e=new d.M(0,null),e.virtualItemData_set(f.a.GetItemByReward(s)),e.isCanOperate=!1,e.isEquipCompare=!1,this._rewardData.Add(e))
t+=1}}if(null!=this.m_info.detail.items){const i=this.m_info.detail.items.count
let s=null
for(t=0;t<i;)s=this.m_info.detail.items[t],null!=s&&(e=new d.M(s.modelId,s),e.isCanOperate=!1,e.isEquipCompare=!1,this._rewardData.Add(e)),t+=1}}return this._rewardData}
RewardedHandle(t){this.ReqDeleteMail()}})},57367:(t,e,i)=>{
var s,n=i(18998),l=i(83908),a=i(93984),o=i(38836),r=i(98958),h=i(28192),d=i(26753),c=i(75439),u=i(84632),m=i(51198),I=i(90181),g=i(57834),_=i(87923)
class p extends((0,l.yk)()){constructor(...t){super(...t),this.m_info=null,this._degf_ClickHandler=null}_initBinder(){super._initBinder(),
this._degf_ClickHandler=(t,e)=>this.ClickHandler(t,e)}Info_get(){return this.m_info}Info_set(t){this.m_info=t}InitView(){super.InitView()}ClickHandler(t,e){
null!=this.Info_get()&&(u.R.GetInst().ShowDetailPanel(this.Info_get()),I.x.GetInst().SetSelect(this.Info_get()))}SetData(t){this.Info_set(t),
null!=this.Info_get().simpleVo&&(this.TitleLabel.textSet(this.Info_get().GetMailTitle()),this.UpdateReadStatus(),
this.RewardTip.textSet(_.l.GetDateTime(this.Info_get().GetTime(),".",!1)),this.systemMsg.SetActive(this.Info_get().simpleVo.isGS),this.UpdateReadStatus(),
g.i.Get(this.listener).RegistonClick(this._degf_ClickHandler))}UpdateReadStatus(){if(null!=this.Info_get().simpleVo){const t=_.l.GetDateTime(this.Info_get().GetTime(),".",!1)
this.Info_get().simpleVo.look?(this.StatusIcon.skin="atlas/liaotian/ryliaotian_sp_0030",this.bg.spriteNameSet("atlas/common/rycommon_sp_0127"),
this.TitleLabel.textSet(`[645a57]${this.Info_get().GetMailTitle()}[-]`),this.RewardTip.textSet(`[645a57]${t}[-]`)):(this.StatusIcon.skin="atlas/liaotian/ryliaotian_sp_0029",
this.bg.spriteNameSet("atlas/common/rycommon_sp_0128"),this.TitleLabel.textSet(`[443c39]${this.Info_get().GetMailTitle()}[-]`),this.RewardTip.textSet(`[443c39]${t}[-]`))}}Clear(){
g.i.Get(this.listener).RemoveonClick(this._degf_ClickHandler)}Destroy(){}}const{ccclass:C}=n._decorator
C("MailMainView")(s=class extends((0,l.zB)()){constructor(...t){super(...t),this.cur_InfoList=null,this._model=null,this.selectedItem=null,this._degf_DelSelectHandler=null,
this._degf_OnGridReposition=null,this._degf_OnItemRefreshFun=null,this._degf_RewardHandler=null,this._degf_UpdateList=null,this.registerUIScId=null,this.registerUIId=null,
this._m_handlerMgr=null}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=h.h.Get()),this._m_handlerMgr}_initBinder(){super._initBinder(),
this._degf_DelSelectHandler=(t,e)=>this.DelSelectHandler(t,e),this._degf_OnGridReposition=()=>this.OnGridReposition(),this._degf_OnItemRefreshFun=t=>{},
this._degf_RewardHandler=(t,e)=>this.RewardHandler(t,e),this._degf_UpdateList=t=>this.UpdateList(t)}InitView(){super.InitView(),this._model=I.x.GetInst(),
this.grid.SetInitInfo("ui_mail_infoitem",null,p),this.nomailContainer.SetActive(!1)
0==c.D.getInstance().GetIntValue("MAIL:ONECLICKCLAIM")?(this.RewardBtn.node.SetActive(!1),
this.DelBtn.node.transform.SetLocalPositionXYZ(-267,-318,0)):this.RewardBtn.node.SetActive(!0)}OnAddToScene(){this.AddEvents(),this.UpdateList(null)
const t=c.D.getInstance().getContent("MAIL:MAILBOX_DEFAULT_SIZE").getContent(),e=r.V.Inst().getStr2(10868,a.h.eLangResource,t.stringVal)
d.d.Inst_get().controller.ChatMainPanel_get().SetChatContentState(!1),this.tips.textSet(e)}RegUIShow(){}UnRegUIShow(t){
null!=this.registerUIScId&&(INS.uIShowShortCut.UnRegUIShowDic(this.registerUIScId),null!=t&&t&&(this.registerUIScId=null))}AddEvents(){
this.m_handlerMgr.AddClickEvent(this.DelBtn,this._degf_DelSelectHandler),this.m_handlerMgr.AddClickEvent(this.RewardBtn,this._degf_RewardHandler),
this._model.AddEventHandler(m.f.Main_Update_List,this._degf_UpdateList)}UpdateList(t){this.cur_InfoList=this._model.GetTotalList(),this.grid.data_set(this.cur_InfoList),
this.scrollView.ResetPosition(),this.content.SetLocalPositionXYZ(0,0,0),this.UpdateMailCount()}OnGridReposition(){}DelSelectHandler(t,e){const i=this._model.GetNoRewardList()
this._model.SelectMails_set(i),this._model.isOneClickGet=!1,u.R.GetInst().DeleteSelectMail()}RewardHandler(t,e){u.R.GetInst().ReqRewardMail(-1,null),this._model.isOneClickGet=!0}
UpdateMailCount(){0==this.cur_InfoList.Count()?this.nomailContainer.SetActive(!0):this.nomailContainer.SetActive(!1)}CheckMailCount(){let t=!1
for(const[e,i]of(0,o.V5)(this.cur_InfoList)){if(null==i.simpleVo)return!1
t=!0}return t}HandleMsgUpdate(){this.UpdateList(null)}Clear(){this.m_handlerMgr.RemoveClickEvent(this.DelBtn,this._degf_DelSelectHandler),
this.m_handlerMgr.RemoveClickEvent(this.RewardBtn,this._degf_RewardHandler),this._model.RemoveEventHandler(m.f.Main_Update_List,this._degf_UpdateList)
let t=d.d.Inst_get().controller.ChatMainPanel_get()
t&&t.SetChatContentState(!0),this.grid.Clear(),super.Clear()}Destory(){this.Clear(),this.grid.destroy()}RewardedHandle(t){}})},12605:(t,e,i)=>{i.d(e,{g:()=>h})
var s=i(19176),n=i(16812),l=i(39950),a=i(98130),o=i(38962),r=i(79534)
class h extends n.k{constructor(){super(!1,a.GF.INT(l.Y.eUISingleton)),this.iconDic=null,this.clickPos=null,this.clickIndex=1,this.menuGO=null,this.auotoBtnX=-369,
this.showAoYiSkill=!1,this.initAoYi=!1,this.iconDic=new o.X,this.clickPos=r.P.zero_get()}GetSCID(t){let e=0
for(;e<t.count;)this.iconDic.LuaDic_AddOrSetItem(e,t[e]),e+=1}static Inst_get(){return null==h._Inst&&(h._Inst=new h),h._Inst}UpdateShowAoYiSkill(){
this.SetShowAoYiSkill(s.S.getInst().IsInOrWaitHangState())}SetAuotBtnX(t){this.auotoBtnX=t,this.RaiseEvent(h.AOUTO_POS_UPDATE)}ResetData(){this.initAoYi=!1,this.showAoYiSkill=!1}
SetShowAoYiSkill(t){this.showAoYiSkill=t,this.RaiseEvent(h.AOYI_SKILL_SHOW)}}h._Inst=null,h.AOYI_SKILL_SHOW="AOYI_SKILL_SHOW",h.AOUTO_POS_UPDATE="AOYI_SKILL_SHOW"},17320:(t,e,i)=>{
i.d(e,{N:()=>n})
var s=i(16812)
class n extends s.k{constructor(...t){super(...t),this._index=0,this._cfgData=null}index_get(){return this._index}index_set(t){this._index=t}cfgData_get(){return this._cfgData}
cfgData_set(t){this._cfgData=t}}},71379:(t,e,i)=>{i.d(e,{j:()=>n})
var s=i(28501)
class n extends s.d{SetData(t){this.aoyisp.node.SetActive(!0),this.createIdx=t.createIdx,super.SetData(t.res)}Clear(){super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}
S_Test(){return!0}}},92486:(t,e,i)=>{i.d(e,{w:()=>h})
var s=i(45549),n=i(9057),l=i(57834),a=i(72005),o=i(98130),r=i(12605)
class h extends n.x{constructor(){super(),this.bg=null,this.itemImg=null,this.selectedImg=null,this.width=46,this.height=46,this.needEvent=!1,this.itemData=null,
this._degf_clickHandler=null,this._degf_hoverHandler=null,this._degf_clickHandler=(t,e)=>this.clickHandler(t,e),this._degf_hoverHandler=(t,e)=>this.hoverHandler(t,e)}InitView(){
super.InitView(),this.bg=new a.w,this.bg.setId(this.FatherId,this.FatherComponentID,1),this.itemImg=new a.w,this.itemImg.setId(this.FatherId,this.FatherComponentID,2),
this.selectedImg=new a.w,this.selectedImg.setId(this.FatherId,this.FatherComponentID,3)}setWH(t,e){this.width=t,this.height=e}Start(){this.selectedImg.node.SetActive(!1),
l.i.Get(this.node).RegistonHover(this._degf_hoverHandler),l.i.Get(this.node).RegistonClick(this._degf_clickHandler)}onCreate(){}Update(){}hoverHandler(t,e){
this.selectedImg.node.SetActive(e)}clickHandler(t,e){if(this.needEvent)if(this.selectedImg.node.SetActive(!1),null!=this.itemData){const t=this.itemData.skillid
s.x.GetInst().CM_AddShortcutKeyHandler(o.GF.INT(r.g.Inst_get().clickIndex-1),t)}else s.x.GetInst().CM_DelShortcutKeyHandler(o.GF.INT(r.g.Inst_get().clickIndex-1))}SetData(t){
if(this.itemData=t,this.itemImg.node.SetActive(!1),null!=this.itemData){const t=this.itemData.skillicon
this.itemImg.spriteNameSet(t),this.itemImg.node.SetActive(!0)}else this.itemImg.spriteNameSet("")
this.itemImg.widthSet(this.width),this.itemImg.heightSet(this.height)}callback(t){this.itemImg.widthSet(this.width),this.itemImg.heightSet(this.height),
this.itemImg.node.SetActive(!0)}Clear(){}Destroy(){l.i.Get(this.node).RemoveonHover(this._degf_hoverHandler),l.i.Get(this.node).RemoveonClick(this._degf_clickHandler)}}},
378:(t,e,i)=>{i.d(e,{Q:()=>J})
var s=i(86133),n=i(38045),l=i(75331),a=i(98800),o=i(97960),r=i(73206),h=i(97461),d=i(36241),c=i(19176),u=i(6700),m=i(68662),I=i(62370),g=i(11926),_=i(70829),p=i(21169),C=i(38770),S=i(2577),f=i(5924),y=i(99294),w=i(9986),D=i(83207),T=i(57834),A=i(8889),v=i(3522),L=i(72005),M=i(30849),b=i(60130),R=i(98130),P=i(98885),G=i(52212),O=i(79534),E=i(92984),B=i(26753),k=i(14143),x=i(64444),V=i(92679),N=i(31922),H=i(87923),U=i(60917),F=i(20837),j=i(47786),Y=i(22662),z=i(37322),q=i(34294),Z=i(64501),K=i(35259),$=i(25406),W=i(65550),X=i(75517),Q=i(17320)
class J extends M.C{constructor(){super(),this.btn=null,this.icon=null,this.normalIcon=null,this.normalBtn=null,this.isColding=!1,this.cdMask=null,this.cdProgress=null,
this.choseButton=null,this.ban=null,this.show=null,this._skillresource=null,this.caster=null,this._ShortCutItemData=null,this._timerId=-1,this.cdEffectTimerId=-1,this.press=null,
this.coldTime=1,this.cdx=1,this.isVaild=!0,this.lastCdtime=0,this.totalcdTime=0,this.finishcdTime=0,this.demand=null,this._info=null,this.skilleffect=null,this.effectpanel=null,
this.cdEffect=null,this.isshownotify=!1,this._degf_AttributeUpdate=null,this._degf_LongPressHandler=null,this._degf_OkStartSkillHandler=null,this._degf_OnFrame=null,
this._degf_ResetCdEffect=null,this._degf_OnOpenSkillBtn=null,this._degf_OnPressHandler=null,this._degf_OnValidityChange=null,this._degf_SetNewSkillData=null,
this._degf_clickHandler=null,this._degf_loopSkillChangeHandler=null,this.index=1,this.normalPress=null,this._degf_AttributeUpdate=t=>this.AttributeUpdate(t),
this._degf_LongPressHandler=(t,e)=>this.LongPressHandler(t,e),this._degf_OkStartSkillHandler=t=>this.OkStartSkillHandler(t),this._degf_OnFrame=()=>this.OnFrame(),
this._degf_ResetCdEffect=()=>this.ResetCdEffect(),this._degf_OnOpenSkillBtn=(t,e)=>this.OnOpenSkillBtn(t,e),this._degf_OnPressHandler=(t,e)=>this.OnPressHandler(t,e),
this._degf_OnValidityChange=t=>this.OnValidityChange(t),this._degf_SetNewSkillData=t=>this.SetNewSkillData(t),this._degf_clickHandler=(t,e)=>this.clickHandler(t,e),
this._degf_loopSkillChangeHandler=t=>this.loopSkillChangeHandler(t)}ShortCutItemData_get(){return this._ShortCutItemData}InitView(){super.InitView(),this.icon=new L.w,
this.icon.setId(this.FatherId,this.FatherComponentID,1),this.btn=new w.W,this.btn.setId(this.FatherId,this.FatherComponentID,2),this.cdMask=new L.w,
this.cdMask.setId(this.FatherId,this.FatherComponentID,3),this.cdProgress=new L.w,this.cdProgress.setId(this.FatherId,this.FatherComponentID,4),this.choseButton=new D.s,
this.choseButton.setId(this.FatherId,this.FatherComponentID,5),this.ban=new y.z,this.ban.setId(this.FatherId,this.FatherComponentID,6),this.show=new y.z,
this.show.setId(this.FatherId,this.FatherComponentID,7),this.normalBtn=new w.W,this.normalBtn.setId(this.FatherId,this.FatherComponentID,8),this.normalIcon=new L.w,
this.normalIcon.setId(this.FatherId,this.FatherComponentID,9),this.skilleffect=new v.k,this.skilleffect.setId(this.FatherId,this.FatherComponentID,10),this.effectpanel=new A.$,
this.effectpanel.setId(this.FatherId,this.FatherComponentID,11),this.cdEffect=new y.z,this.cdEffect.setId(this.FatherId,this.FatherComponentID,12),
b.O.AddUIEffectSortOrderBind(this.effectpanel.node),this.showNotify(!1),this.caster=a.Y.Inst.PrimaryRole_get(),
this.press=new z.c(this.btn.node,null,this._degf_LongPressHandler,this._degf_OnPressHandler),this.press.AddEvent(),
this.normalPress=new z.c(this.normalBtn.node,null,this._degf_LongPressHandler,this._degf_OnPressHandler),this.normalPress.AddEvent(),this.addEvent()}LongPressHandler(t,e){
const i=a.Y.Inst.PrimaryRole_get(),s=O.P.zero_get()
if(!i.isBeSneer)if(1==e&&this.isVaild&&null!=this._info){if(INS.skillModel.roundEffectHandleId>0)return
const t=101000003,e=103017400
if(0==this.index){const e=1
INS.skillModel.roundEffectHandleId=r.X.Inst.PlayElement(t,i.GetHandle(),0,s,s,0,null,!1,1,!1,e)
}else this._info.pointDis>0?INS.skillModel.roundEffectHandleId=r.X.Inst.PlayElement(t,i.GetHandle(),0,s,s,0,null,!1,1,!1,this._info.pointDis):this._info.targetFilter==C.b.ENEMY||this._info.targetFilter==C.b.ENEMY_MONSTER||this._info.targetFilter==C.b.ENEMY_PLAYER?INS.skillModel.roundEffectHandleId=r.X.Inst.PlayElement(t,i.GetHandle(),0,s,s,0,null,!1,1,!1,this._info.aoeRadius):0==this._info.aoeRadius?INS.skillModel.roundEffectHandleId=r.X.Inst.PlayElement(e,i.GetHandle(),0,s,s,0,null,!1,1,!1,1):INS.skillModel.roundEffectHandleId=r.X.Inst.PlayElement(e,i.GetHandle(),0,s,s,0,null,!1,1,!1,this._info.aoeRadius)
}else INS.skillModel.roundEffectHandleId>0&&(r.X.Inst.DeleteElement(INS.skillModel.roundEffectHandleId),INS.skillModel.roundEffectHandleId=0),
this.isVaild&&null!=this._info&&this.clickHandler(0,0)}IsAccumulateSkill(){return null!=this._info&&this._info.skillid==N.z.SKILL_ID_XCYN}OnPressHandler(t,e){}InitIcon(t){
this.icon.spriteNameSet(t),this.choseButton.node.SetActive(!1)}addEvent(){T.i.Get(this.choseButton.node).RegistonClick(this._degf_OnOpenSkillBtn),
T.i.Get(this.btn.node).RegistonClick(this._degf_clickHandler),T.i.Get(this.normalBtn.node).RegistonClick(this._degf_clickHandler),
h.i.Inst.AddEventHandler(S.g.NEWSKILL_CHANGE,this._degf_SetNewSkillData),h.i.Inst.AddEventHandler(S.g.SKILL_VALIDITY_CHANGE,this._degf_OnValidityChange),
a.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(o.A.AttributesUpdate,this._degf_AttributeUpdate),h.i.Inst.AddEventHandler(V.g.CHANGEQUEST_MODEL_UPDATE,this._degf_AttributeUpdate),
INS.skillModel.AddEventHandler(p.O.loopskillchange,this._degf_loopSkillChangeHandler)}OnOpenSkillBtn(t,e){q.L.Inst_get().setSkillPanelShowMode=!1,Z.B.inst.OpenSkillPanel()}
OnValidityChange(t){const e=t
e.x==this._skillresource.skillid&&(this.ban.SetActive(0==e.y),this.show.SetActive(1==e.y))}AttributeUpdate(t){if(null!=this._info){const t=new G.F(this._info.skillid,1)
this.demand=new U.P,K.C.INSTANCE.CheckSkillPointUseVaildity(this._info,null,this.demand)?this.isVaild=!0:(t.y=0,this.isVaild=!1),this.OnValidityChange(t)}}SendTempNotice(){
const t=j.x.Inst().getItemById(105043)
let e=P.M.Replace(t.sys_messsage,"{0}",this._skillresource.name)
e=P.M.Replace(e,"{1}",this.demand.type)
let i=P.M.Replace(t.sys_messsage2,"{0}",this._skillresource.name)
i=P.M.Replace(i,"{1}",this.demand.type)
const s=P.M.String2Int(this.demand.extend),n=this.demand.value-s
W.y.inst.textStr=P.M.Replace(e,"{2}",P.M.IntToString(n)),W.y.inst.textStr2=P.M.Replace(i,"{2}",P.M.IntToString(n))
const l=x.B.UI_OPEN+(I.o.s_UNDER_CHAR+t.ui),a=x.B.UI_OPEN+(I.o.s_UNDER_CHAR+t.ui2)
let o=H.l.SetLinkStr(t.tips,l,null,!0),r=H.l.SetLinkStr(t.tips2,a,null,!0)
o=H.l.SetStringColor(H.l.txtGreenStr,o),r=H.l.SetStringColor(H.l.txtGreenStr,r),
B.d.Inst_get().model.AddTipChat(k.L.NOTICE,`${W.y.inst.textStr} ${o+r}`,t.id,null,W.y.inst.textStr,!1,!1,null,!1,!1,W.y.inst.textStr2),W.y.inst.OpenPanel(Y.r.TempNotice,t.id)}
OnFrame(){if(this.cdMask.fillAmount()>.001){const t=m.D.serverMSTime_get(),e=(this.finishcdTime-t)/this.totalcdTime
this.cdMask.fillAmountSet(e),this.cdProgress.fillAmountSet(1-e),this.cdMask.fillAmount()<=.001&&(this.cdMask.fillAmountSet(0),this.cdProgress.fillAmountSet(0),
f.C.Inst_get().ClearLoop(this._timerId),this._timerId=-1,l.N.Inst.clearDynamCD(this._info.skillid),this.isVaild&&(this.cdEffect.SetActive(!1),this.cdEffect.SetActive(!0),
f.C.Inst_get().ClearInterval(this.cdEffectTimerId),this.cdEffectTimerId=f.C.Inst_get().SetFrameLoop(this._degf_ResetCdEffect,12,1)))}}StartSkill(t){}loopSkillChangeHandler(t){}
setInfo(t){if(this._info!=t&&this.cleanCD(),this._info=t,this.isVaild=!0,null!=t&&(0,n.t2)(t,F.L)){if(0==this.index)this.btn.node.SetActive(!1),this.normalBtn.node.SetActive(!0),
this.choseButton.node.SetActive(!1),
100==t.job?this.normalIcon.spriteNameSet("mainui_sp_293"):200==t.job?this.normalIcon.spriteNameSet("mainui_sp_294"):300==t.job&&this.normalIcon.spriteNameSet("mainui_sp_295")
else{const e=t.skillicon
this.InitIcon(e),this.icon.node.SetActive(!0),Z.B.isskilladd&&Z.B.isshortskilladd&&Z.B.skilladdid==t.skillid&&K.C.INSTANCE.needhide()?(this.choseButton.node.SetActive(!0),
this.btn.node.SetActive(!1),this.normalBtn.node.SetActive(!1)):(this.btn.node.SetActive(!0),this.normalBtn.node.SetActive(!1),this.choseButton.node.SetActive(!1))}
u.L.Instance_get().GetTime()
const e=1e3*this.caster.getPublicCD(),i=l.N.Inst.GetCD(t.skillid,t.publicCDGroup,this.caster.objId)
this.coldTime=i/1e3
l.N.Inst.GetPublicCD(t.skillid,t.publicCDGroup,this.caster.objId)
let s=l.N.Inst.GetSkillCDTime(t.cd,t.skillid)
if(i>0){let n=l.N.Inst.CheckCDSmallPublic(this._info.skillid,this._info.publicCDGroup,this.caster.objId)
i>t.cd&&(n=!0),n&&i<=e&&(s=R.GF.INT(e))}this.cdx=1e3*this.coldTime/s,this.coldTime>0?(this.lastCdtime=m.D.serverMSTime_get(),this.totalcdTime=s,
this.finishcdTime=1e3*this.coldTime+this.lastCdtime,this.cdMask.fillAmountSet(this.cdx),this.cdProgress.fillAmountSet(1-this.cdx),f.C.Inst_get().ClearLoop(this._timerId),
this._timerId=f.C.Inst_get().SetFrameLoop(this._degf_OnFrame,1)):this.coldTime<=0&&(this.cdMask.fillAmountSet(0),this.cdProgress.fillAmountSet(0),
f.C.Inst_get().ClearLoop(this._timerId))
const n=new G.F(t.skillid,1)
K.C.INSTANCE.CheckSkillPointUseVaildity(t)||(n.y=0,this.isVaild=!1),this.OnValidityChange(n)}else this.clean()
this.loopSkillChangeHandler(null)}cleanCD(){this.cdMask.fillAmountSet(0),this.cdProgress.fillAmountSet(0),f.C.Inst_get().ClearLoop(this._timerId),this._timerId=-1,
f.C.Inst_get().ClearInterval(this.cdEffectTimerId),this.cdEffectTimerId=-1}ResetCdEffect(){this.cdEffect.SetActive(!1),this.cdEffectTimerId=-1}clean(){this.btn.node.SetActive(!1),
this.choseButton.node.SetActive(!0),this.show.SetActive(!0),this.ban.SetActive(!1),this.icon.node.SetActive(!0),this.cdMask.fillAmountSet(0),this.cdProgress.fillAmountSet(0),
f.C.Inst_get().ClearLoop(this._timerId),this._timerId=-1,f.C.Inst_get().ClearInterval(this.cdEffectTimerId),this.cdEffectTimerId=-1,this.cdEffect.SetActive(!1)}SetIndex(t){
this.index=t}SetData(t){if(this._skillresource=t,this.setInfo(this._skillresource),null!=this._skillresource){const t=new Q.N
t.index_set(this.index),t.cfgData_set(this._skillresource),this._ShortCutItemData=t}else this._ShortCutItemData=null
INS.skillModel.currentPressSkill=null,this.showNotify(!1)}SetNewSkillData(t){const e=R.GF.INT(t)
null!=this._skillresource&&e==this._skillresource.skillid&&(this.icon.node.SetActive(!0),this.choseButton.node.SetActive(!1))}clickHandler(t,e){if(X.W.inst_get().CloseView(),
null!=E.j.Inst_get().model.IsHaveShapeShiftBuff(a.Y.Inst.PrimaryRoleInfo_get().Id_get()))return void W.y.inst.ClientStrMsg(Y.r.SystemTipMessage,(0,s.T)("变身状态下不能释放技能"))
if(g.y.Inst.IsShowAccumulateProgressView())return
if(c.S.getInst().InHang_get())return void(null!=this.skillresource_get()&&INS.skillModel.NextSkill_set(this.skillresource_get().id))
if(0==this.index){if(c.S.getInst().InHang_get())return d._.getInst().endHang(!1),a.Y.Inst.AddPkCastSkillAction(),void d._.getInst().StartStopAIHandler()
if(null==a.Y.Inst.CurTarget_get()||!a.Y.Inst.CurTarget_get().isAttackedable()){let t=this.skillresource_get()
if(null==t){const e=INS.skillModel.CurSkill_get(a.Y.Inst.PrimaryRoleInfo_get())
e>0&&(t=a.Y.Inst.PrimaryRoleInfo_get().GetSkillById(e))}if(null==t){const e=_.j.Inst().GetDefaultSkillId(a.Y.Inst.PrimaryRoleInfo_get().Job_get())
t=a.Y.Inst.PrimaryRoleInfo_get().GetSkillById(e)}null!=t&&$.U.Inst_get().ChangeOne(!0,t)}return void a.Y.Inst.AddPkCastSkillAction()}if(!this.isVaild){const t=new U.P
return K.C.INSTANCE.CheckSkillPointUseVaildity(this._info,null,t),void W.y.inst.ClientStrMsg(Y.r.SystemTipMessage,this._info.name+((0,
s.T)("还需要增加")+(t.value-P.M.String2Int(t.extend)+((0,s.T)("点")+(t.type+(0,s.T)("才能使用"))))))}if(this.IsAccumulateSkill())return
this._info
1==this.StartSkill(t)&&a.Y.Inst.AddPkCastSkillAction(!0)}OkStartSkillHandler(t){1==this.StartSkill()&&a.Y.Inst.AddPkCastSkillAction(!0)}rightClickHandler(){
null!=this._ShortCutItemData&&this._ShortCutItemData.cfgData_get()}showNotify(t){this.isshownotify!=t&&(this.isshownotify=t,t?(this.skilleffect.node.SetActive(!1),
this.skilleffect.node.SetActive(!0)):this.skilleffect.node.SetActive(!1))}skillresource_get(){return this._skillresource}skillresource_set(t){this._skillresource=t,
this.SetData(this._skillresource)}Clear(){this.press.RemoveEvent(),this.normalPress.RemoveEvent()}Destroy(){T.i.Get(this.choseButton.node).RemoveonClick(this._degf_OnOpenSkillBtn),
T.i.Get(this.btn.node).RemoveonClick(this._degf_clickHandler),T.i.Get(this.normalBtn.node).RemoveonClick(this._degf_clickHandler),
h.i.Inst.RemoveEventHandler(S.g.NEWSKILL_CHANGE,this._degf_SetNewSkillData),h.i.Inst.RemoveEventHandler(S.g.SKILL_VALIDITY_CHANGE,this._degf_OnValidityChange),
a.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(o.A.AttributesUpdate,this._degf_AttributeUpdate),
h.i.Inst.RemoveEventHandler(V.g.CHANGEQUEST_MODEL_UPDATE,this._degf_AttributeUpdate),INS.skillModel.RemoveEventHandler(p.O.loopskillchange,this._degf_loopSkillChangeHandler),
this.press.Destory(),this.normalPress.Destory()}}},79653:(t,e,i)=>{i.d(e,{I:()=>o})
var s=i(9986),n=i(57834),l=i(72005),a=i(30849)
class o extends a.C{constructor(){super(),this.isAdded=!1,this.data=null,this._degf_OnBtnClick=null,this.icon=null,this.btn=null,this._degf_OnBtnClick=(t,e)=>this.OnBtnClick(t,e)}
InitView(){this.icon=new l.w,this.icon.setId(this.FatherId,this.FatherComponentID,1),this.btn=new s.W,this.btn.setId(this.FatherId,this.FatherComponentID,2),this.AddOrRemoveLis(!0)
}SetData(t){null!=t?(this.node.SetActive(!0),this.data=t,this.icon.spriteNameSet(t.icon)):this.node.SetActive(!1)}AddOrRemoveLis(t){t&&!this.isAdded?(this.isAdded=!0,
n.i.Get(this.btn.node).RegistonClick(this._degf_OnBtnClick)):!t&&this.isAdded&&(this.isAdded=!1,n.i.Get(this.btn.node).RemoveonClick(this._degf_OnBtnClick))}OnBtnClick(t,e){
t==this.btn.ComponentId&&this.UseTalentSkill()}UseTalentSkill(){}Clear(){this.AddOrRemoveLis(!1)}Destroy(){this.icon=null,this.btn=null}}},28501:(t,e,i)=>{i.d(e,{d:()=>et})
var s=i(83908),n=i(82815),l=i(38836),a=i(86133),o=i(38045),r=i(75331),h=i(98800),d=i(84581),c=i(97960),u=i(36241),m=i(19176),I=i(6700),g=i(65530),_=i(68662),p=i(62370),C=i(11926),S=i(70829),f=i(45549),y=i(21169),w=i(38770),D=i(2577),T=i(5924),A=i(18202),v=i(83540),L=i(28192),M=i(98130),b=i(98885),R=i(94148),P=i(92984),G=i(42975),O=i(26753),E=i(14143),B=i(64444),k=i(92679),x=i(31922),V=i(87923),N=i(60917),H=i(20837),U=i(75808),F=i(47786),j=i(22662),Y=i(93061),z=i(80392),q=i(37322),Z=i(88883),K=i(54383),$=i(50748),W=i(34294),X=i(64501),Q=i(35259),J=i(65550),tt=i(17320)
class et extends((0,s.yk)()){constructor(...t){super(...t),this._m_handlerMgr=null,this.icon=null,this.selectedEffected=null,this.isColding=!1,this.coldingtype=0,
this.choseButton=null,this._selected=!1,this._skillresource=null,this.showTip=!1,this.caster=null,this._shortCutItemData=null,this.dropItem=null,this._timerId=-1,
this._listener=null,this.press=null,this.coldTime=1,this.cdx=1,this.isVaild=!0,this.lastCdtime=0,this.totalcdTime=0,this.curcoldTime=0,this.demand=null,this._info=null,
this.buffVO=null,this.buffIntervalId=-1,this.effectview=null,this._degf_AttributeUpdate=null,this._degf_LongPressHandler=null,this._degf_OkStartSkillHandler=null,
this._degf_OnFrame=null,this._degf_OnOpenSkillBtn=null,this._degf_OnPressHandler=null,this._degf_OnValidityChange=null,this._degf_SetEffectData=null,this._degf_clickHandler=null,
this._degf_closeEff=null,this._degf_loopSkillChangeHandler=null,this._degf_playEff=null,this._degf_showicon=null,this._degf_OnBuffUpdate=null,this._degf_OnSummonMonsterUpdate=null,
this._degf_OnBuffTimeUpdate=null,this.index=1,this.isPKSpecialSkill=!1,this.createIdx=null,this.roleInfo=null,this.forbidenSp=null,this.fatherId=null}get m_handlerMgr(){
return this._m_handlerMgr||(this._m_handlerMgr=L.h.Get()),this._m_handlerMgr}_initBinder(){this.demand=new N.P,this._degf_AttributeUpdate=t=>this.AttributeUpdate(t),
this._degf_LongPressHandler=(t,e)=>this.LongPressHandler(t,e),this._degf_OkStartSkillHandler=t=>this.OkStartSkillHandler(t),this._degf_OnFrame=()=>this.OnFrame(),
this._degf_OnOpenSkillBtn=(t,e)=>this.OnOpenSkillBtn(t,e),this._degf_OnPressHandler=(t,e)=>this.OnPressHandler(t,e),this._degf_OnValidityChange=t=>this.OnValidityChange(t),
this._degf_SetEffectData=t=>this.SetEffectData(t),this._degf_clickHandler=(t,e)=>this.clickHandler(t,e),this._degf_closeEff=()=>this.closeEff(),
this._degf_loopSkillChangeHandler=t=>this.loopSkillChangeHandler(t),this._degf_playEff=()=>this.playEff(),this._degf_showicon=()=>this.showicon(),
this._degf_OnBuffUpdate=t=>this.OnBuffUpdate(t),this._degf_OnSummonMonsterUpdate=t=>this.OnSummonMonsterUpdate(t),this._degf_OnBuffTimeUpdate=()=>this.OnBuffTimeUpdate()}
shortCutItemData_get(){return this._shortCutItemData}InitView(){this.icon=this.skillicon,this.selectedEffected=this.selectedeffect,this.choseButton=this.chose,
this.forbidenSp=this.forbiden,this.press=new q.c(this.node,null,this._degf_LongPressHandler,this._degf_OnPressHandler),this.press.AddEvent(),this.lab_lv.node.SetActive(!1),
this.img_ultimate.SetActive(!1),this.skillStateLabel.textSet(""),this.skillStateLabel.node.SetActive(!1),this.aoyisp.node.SetActive(!1),this.forbidenSp.SetActive(!1)}
OnBuffUpdate(t){this.SetSkillState()}OnSummonMonsterUpdate(t){this.SetSkillState()}GetRoleInfo(){
return null==this.createIdx?h.Y.Inst.m_primaryRoleInfo:h.Y.Inst.GetMultiPlayerInfoByCreateIdx(this.createIdx)}GetCaster(){
return null==this.createIdx?h.Y.Inst.primaryRole:h.Y.Inst.GetMultiPlayeByCreateIdx(this.createIdx)}LongPressHandler(t,e){if(!this.IsAccumulateSkill())if(e){
if(null!=this._skillresource&&this.showTip){const t=Q.C.INSTANCE.GetSkillByStudyDic(this._skillresource.skillid)
this._skillresource=S.j.Inst().GetSkillByIdLevel(this._skillresource.skillid,t.level),
this.isPKSpecialSkill?X.B.inst.OpenSkillMainViewTips(this._skillresource,this.node,211,-336,!0):X.B.inst.OpenSkillMainViewTips(this._skillresource,this.node)}
}else X.B.inst.CloseSkillMainViewTips()}IsAccumulateSkill(){return null!=this._info&&this._info.skillid==x.z.SKILL_ID_XCYN}OnPressHandler(t,e){}OnDragEnd(t,e){t.data,e.data}
InitIcon(t,e){A.g.SetItemIcon(this.icon,e,v.b.eSkill,!1),this.callback(null),this.choseButton.node.SetActive(!1),this.selectedEffected.SetActive(!1)}callback(t){
this.icon.widthSet(64),this.icon.heightSet(64)}AddLis(){this.m_handlerMgr.AddClickEvent(this.choseButton,this._degf_OnOpenSkillBtn),
this.m_handlerMgr.AddEventMgr(D.g.NEWSKILL_CHANGE,this._degf_SetEffectData),this.m_handlerMgr.AddEventMgr(k.g.SUMMON_MONSTER_UPDATE,this._degf_OnSummonMonsterUpdate),
this.m_handlerMgr.AddEventMgr(k.g.FORBIDEN_SKILL_USE,this.CreateDelegate(this.HandleForbiden)),
this.m_handlerMgr.AddEventMgr(k.g.CHANGEQUEST_MODEL_UPDATE,this._degf_AttributeUpdate),P.j.Inst_get().model.AddEventHandler(G.E.UPDATE_BUFF_VIEW,this._degf_OnBuffUpdate),
INS.skillModel.AddEventHandler(y.O.loopskillchange,this._degf_loopSkillChangeHandler)}RemoveLis(){
P.j.Inst_get().model.RemoveEventHandler(G.E.UPDATE_BUFF_VIEW,this._degf_OnBuffUpdate),INS.skillModel.RemoveEventHandler(y.O.loopskillchange,this._degf_loopSkillChangeHandler)}
AddRoleEvent(){this.RemoveRoleEvent(),this.roleInfo=this.GetRoleInfo(),this.roleInfo.AddEventHandlerRoleGlobal(c.A.AttributesUpdate,this._degf_AttributeUpdate)}RemoveRoleEvent(){
null!=this.roleInfo&&(this.roleInfo.RemoveEventHandlerRoleGlobal(c.A.AttributesUpdate,this._degf_AttributeUpdate),this.roleInfo=null)}OnOpenSkillBtn(t,e){
W.L.Inst_get().setSkillPanelShowMode=!0,X.B.inst.OpenSkillPanel()}OnValidityChange(t,e){t==this._skillresource.skillid&&(this.ban.SetActive(0==e),this.show.SetActive(1==e))}
AttributeUpdate(t){const e=this.roleInfo
if(null!=this._info){let t=1
this.demand.Clear(),$.m.Inst().CheckSkillPointUseVaildity(this._info,e,this.demand)?this.isVaild=!0:(t=0,this.isVaild=!1),this.OnValidityChange(this._info.skillid,t)}
Y.Z.Inst_get().AddAttrPointShow()}SendTempNotice(){const t=F.x.Inst().getItemById(105043)
let e=b.M.Replace(t.sys_messsage,"{0}",this._skillresource.name)
e=b.M.Replace(e,"{1}",this.demand.type)
let i=b.M.Replace(t.sys_messsage2,"{0}",this._skillresource.name)
i=b.M.Replace(i,"{1}",this.demand.type)
const s=b.M.String2Int(this.demand.extend),n=this.demand.value-s
J.y.inst.textStr=b.M.Replace(e,"{2}",b.M.IntToString(n)),J.y.inst.textStr2=b.M.Replace(i,"{2}",b.M.IntToString(n))
const l=B.B.UI_OPEN+(p.o.s_UNDER_CHAR+t.ui),a=B.B.UI_OPEN+(p.o.s_UNDER_CHAR+t.ui2)
let o=V.l.SetLinkStr(t.tips,l,null,!0),r=V.l.SetLinkStr(t.tips2,a,null,!0)
o=V.l.SetStringColor(V.l.txtGreenStr,o),r=V.l.SetStringColor(V.l.txtGreenStr,r),
O.d.Inst_get().model.AddTipChat(E.L.NOTICE,`${J.y.inst.textStr} ${o+r}`,t.id,null,J.y.inst.textStr,!1,!1,null,!1,!1,J.y.inst.textStr2),J.y.inst.OpenPanel(j.r.TempNotice,t.id)}
OnFrame(){if(this.isColding){const t=_.D.serverMSTime_get()-this.lastCdtime,e=(1e3*this.curcoldTime-t)/this.totalcdTime
this.shade_sprite.fillRange=e,this.shade_sprite.fillRange<=.001&&(this.shade_sprite.fillRange=0,this.isColding=!1,T.C.Inst_get().ClearLoop(this._timerId),this._timerId=-1,
r.N.Inst.clearDynamCD(this._info.skillid))}else null!=this._timerId&&this.cleanCD()}StartSkill(t){if(null==t&&(t=0),
h.Y.Inst.IsCanOperate())if(null!=this.caster&&this.caster.isdead)J.y.inst.ClientSysStrMsg("角色已死亡,无法释放技能")
else{if(null==this.caster&&(this.caster=this.GetCaster()),this.isColding)return 1==this.coldingtype?J.y.inst.ClientSysMessage(100036):void J.y.inst.ClientSysStrMsg("技能冷却中")
if(C.y.Inst.IsShowAccumulateProgressView())J.y.inst.ClientSysStrMsg("蓄力中无法操作")
else if(z.H.Inst.startTimer=_.D.serverMSTime_get(),this.roleInfo.isBeSneer)J.y.inst.ClientSysStrMsg("嘲讽状态下无法操作")
else if(null!=this.skillresource_get()){
if(this.skillresource_get().targetFilter==w.b.ENEMY||this.skillresource_get().targetFilter==w.b.ENEMY_MONSTER||this.skillresource_get().targetFilter==w.b.ENEMY_PLAYER||this.skillresource_get().targetFilter==w.b.ALL){
const t=h.Y.Inst.CurTarget_get()
if(null!=t)if(t.roletype==d.s.monster){if(t.IsRedGuard&&!K.k.Inst_get().IsCanAttckGuard())return void J.y.inst.ClientSysStrMsg("非红名玩家无法攻击守卫")
}else if(t.roletype==d.s.role&&!t.isAttackedable()){const e=t
if(K.k.Inst_get().pkModel==Z.j.PEACE_MODEL&&null!=e.Roleinfo_get()&&e.Roleinfo_get().PkPoint_get()<10)return void J.y.inst.ClientSysStrMsg("和平模式无法攻击非红名玩家")}}
if(!u._.getInst().isclickmap||this.isColding)if(m.S.getInst().InHang_get())INS.skillModel.SetPreSkill(this.createIdx,this.skillresource_get(),n.R.precastskill)
else if(null==this.caster.AISingleton_get()||this.caster.AISingleton_get().getSingletonType()!=n.R.castskill)if(this.caster.ClearMoveParam(),
this.isColding)J.y.inst.ClientSysStrMsg("技能冷却中")
else{let t=-1
if(this.caster.IsInSafeArea())return void J.y.inst.ClientSysStrMsg((0,a.T)("安全区不能使用技能"))
if(this.caster.isPrimary){const e=this.skillresource_get()
t=R.b.Inst_get().IsChariotSkill(e)?f.x.GetInst().hotCastTransformSkill(e):f.x.GetInst().hotCastSKill(e.skillid,!0),
-1!=t&&null!=h.Y.Inst.CurTarget_get()&&h.Y.Inst.AddPkCastSkillAction(!0)}else INS.skillModel.SetPreSkill(this.createIdx,this.skillresource_get())
}else INS.skillModel.SetPreSkill(this.createIdx,this.skillresource_get())
else f.x.GetInst().hotCastSKill(this.skillresource_get().skillid,!0)}}else J.y.inst.ClientSysStrMsg("当前无法操作")}loopSkillChangeHandler(t){}setInfo(t){if(this._info=t,this.isVaild=!0,
this.eff2.SetActive(!1),null!=t&&(0,o.t2)(t,H.L)){let e=1
const i=t.skillicon
this.InitIcon("pre_skill",i),X.B.isskilladd&&X.B.isshortskilladd&&X.B.skilladdid==t.skillid&&Q.C.INSTANCE.needhide()?(this.icon.node.SetActive(!1),
this.choseButton.node.SetActive(!0)):this.icon.node.SetActive(!0),t.needClear&&this.cleanCD()
const s=I.L.Instance_get().GetMsTime(),n=1e3*this.caster.getPublicCD(),l=r.N.Inst.GetCD(t.skillid,t.publicCDGroup,this.caster.objId)
this.coldTime=l/1e3
r.N.Inst.GetPublicCD(t.skillid,t.publicCDGroup,this.caster.objId)
this.coldingtype=0
let a=r.N.Inst.GetSkillCDTime(t.cd,t.skillid,this.roleInfo)
if(l>0)if(l==r.N.Inst.GetSpecialCDEndDic(t.publicCDGroup)-s)a=U.f.getInst().getGroupCD(b.M.String2Int(t.publicCDGroup)),this.coldingtype=1
else{let e=r.N.Inst.CheckCDSmallPublic(this._info.skillid,this._info.publicCDGroup,this.caster.objId)
l>t.cd&&(e=!0),e&&l<=n&&(a=M.GF.INT(n))}
this.cdx=1e3*this.coldTime/a,(this.coldTime!=this.curcoldTime||this.isColding&&this.lastCdtime!=_.D.serverMSTime_get())&&(this.isColding=!1),
!this.isColding&&this.coldTime>0&&(this.lastCdtime=_.D.serverMSTime_get(),this.totalcdTime=a,this.curcoldTime=this.coldTime,this.shade_sprite.fillRange=this.cdx,this.isColding=!0,
T.C.Inst_get().ClearLoop(this._timerId),this._timerId=T.C.Inst_get().SetFrameLoop(this._degf_OnFrame,1)),Q.C.INSTANCE.CheckSkillPointUseVaildity(t,this.roleInfo)||(e=0,
this.isVaild=!1),this.OnValidityChange(t.skillid,e),this.xuli.SetActive(this.IsAccumulateSkill()),(0==this.coldTime||this.coldTime<0&&this.isColding)&&this.cleanCD()
}else this.clean()
this.loopSkillChangeHandler(null)}cleanCD(){this.isColding=!1,this.shade_sprite.fillRange=0,T.C.Inst_get().ClearLoop(this._timerId),this.coldingtype=0,this._timerId=-1}clean(){
this.xuli.SetActive(!1),this.lab_lv.node.SetActive(!1),this.icon.node.SetActive(!1),this.choseButton.node.SetActive(!0),this.isColding=!1,this.shade_sprite.fillRange=0,
this.show.SetActive(!0),this.ban.SetActive(!1),T.C.Inst_get().ClearLoop(this._timerId),this._timerId=-1}SetData(t){if(this.caster=this.GetCaster(),
null==this.caster)return this.clean(),this.cleanCD(),this.Clear(),void this.RemoveLis()
if(this.AddRoleEvent(),this.AddLis(),this._skillresource=t,this.eff.node.SetActive(!1),this.setInfo(this._skillresource),null!=this._skillresource){
if(this.m_handlerMgr.AddClickEvent(this.node,this._degf_clickHandler),
null!=this._shortCutItemData&&this._shortCutItemData.index_get()==this.index&&this._shortCutItemData.cfgData_get().id==this._skillresource.id)return this.SetSkillState(),
void this.HandleForbiden(f.x.Inst.forbidenUseSkill)
const t=new tt.N
t.index_set(this.index),t.cfgData_set(this._skillresource),this._shortCutItemData=t}else this.m_handlerMgr.RemoveClickEvent(this.node,this._degf_clickHandler),
this._shortCutItemData=null,this.SetSkillState(),this.HandleForbiden(f.x.GetInst().forbidenUseSkill)}SetSkillState(){
if(null!=this.roleInfo)if(this.isPKSpecialSkill)if(3009==this._skillresource.skillid||3203==this._skillresource.skillid)this.skillStateLabel.node.activeInHierarchy||this.skillStateLabel.node.SetActive(!0)
else{this.buffVO=null
const t=P.j.Inst_get().model.GetBuffListBySkillId(this._skillresource.skillid),e=P.j.Inst_get().model.getBuffsByPlayerId(this.roleInfo.Id_get())
if(null!=t&&null!=e){for(const[i,s]of(0,l.V5)(t)){for(const[t,i]of(0,l.V5)(e))if(s==i.vo.id){this.buffVO=i
break}if(null!=this.buffVO)break}if(null==this.buffVO)T.C.Inst_get().ClearInterval(this.buffIntervalId),this.skillStateLabel.textSet(""),
this.skillStateLabel.node.activeInHierarchy&&this.skillStateLabel.node.SetActive(!1)
else{T.C.Inst_get().ClearInterval(this.buffIntervalId),this.buffIntervalId=T.C.Inst_get().SetInterval(this._degf_OnBuffTimeUpdate,1e3,-1),
this.skillStateLabel.node.activeInHierarchy||this.skillStateLabel.node.SetActive(!0)
const t=`${M.GF.INT(this.buffVO.vo.useEndTime_get()/1e3-_.D.serverTime_get())}s`
this.skillStateLabel.textSet(t)}}}else this.skillStateLabel.node.activeInHierarchy&&this.skillStateLabel.node.SetActive(!1),this.skillStateLabel.textSet("")}OnBuffTimeUpdate(){
if(this.isPKSpecialSkill&&null!=this.buffVO&&null!=this.buffVO.vo){const t=M.GF.INT(this.buffVO.vo.useEndTime_get()/1e3-_.D.serverTime_get())
if(t<=0)T.C.Inst_get().ClearInterval(this.buffIntervalId),this.buffIntervalId=-1,this.skillStateLabel.node.SetActive(!1),this.skillStateLabel.textSet("")
else{const e=`${t}s`
this.skillStateLabel.textSet(e)}}else T.C.Inst_get().ClearInterval(this.buffIntervalId),this.buffIntervalId=-1}SetEffectData(t){}playEff(){this.eff.node.SetActive(!0)}showicon(){
this.eff2.SetActive(!0),this.icon.node.SetActive(!0),this.choseButton.node.SetActive(!1),X.B.isskilladd=!1,X.B.isshortskilladd=!1,X.B.istippaneldstudyskill=!1,X.B.skilladdid=0}
closeEff(){this.eff.node.SetActive(!1),this.eff2.SetActive(!1),null!=this.effectview&&(this.effectview.node.SetActive(!1),this.effectview.Clear(),this.effectview.Destroy(),
A.g.DestroyUIById(this.fatherId))}onPressHandler(t,e){null==this.caster&&(this.caster=this.GetCaster()),
-1==g.x.Instance_get().CurrentTouchID()&&(e||f.x.GetInst().releaseNextSkill(this.caster))}clickHandler(t,e){if(console.log("clickHandler:点击技能",t," ",e),!this.isVaild){
const t=new N.P
return Q.C.INSTANCE.CheckSkillPointUseVaildity(this._info,null,t),void J.y.inst.ClientStrMsg(j.r.SystemTipMessage,this._info.name+((0,
a.T)("还需要增加")+(t.value-b.M.String2Int(t.extend)+((0,a.T)("点")+(t.type+(0,a.T)("才能使用"))))))}this.StartSkill(t)}HandleForbiden(t){this.forbidenSp.SetActive(t)}OkStartSkillHandler(t){
this.StartSkill()}rightClickHandler(){null!=this._shortCutItemData&&this._shortCutItemData.cfgData_get()}skillresource_get(){return this._skillresource}skillresource_set(t){
this._skillresource=t,this.SetData(this._skillresource)}Clear(){this.RemoveLis(),this.RemoveRoleEvent(),this.caster=null,T.C.Inst_get().ClearInterval(this.buffIntervalId),
this.buffIntervalId=-1}Destroy(){}}},96713:(t,e,i)=>{i.d(e,{n:()=>ce})
var s=i(56937),n=i(31222),l=i(5494),a=i(42292),o=i(17409),r=i(95721),h=i(79534),d=i(40162),c=i(11158),u=i(70478),m=i(95236),I=i(36241),g=i(68662),_=i(18202),p=i(8334),C=i(52726),S=i(995),f=i(98789),y=i(60130),w=i(41633),D=i(89719),T=i(95790),A=i(15965),v=i(22107),L=i(85430),M=i(84229),b=i(43076),R=i(22878),P=i(31922),G=i(74045),O=i(29839),E=i(78417),B=i(84333),k=i(85770),x=i(44210),V=i(83496),N=i(72800),H=i(62941),U=i(52295),F=i(47058),j=i(65973),Y=i(89145),z=i(63683),q=i(48933),Z=i(49831),K=i(46352),$=i(84632),W=i(5031),X=i(66988),Q=i(43308),J=i(26768),tt=i(6332),et=i(67345),it=i(41759),st=i(76902),nt=i(682),lt=i(38836),at=i(86133),ot=i(23833),rt=i(99294),ht=i(9986),dt=i(93877),ct=i(72005),ut=i(13113),mt=i(30849),It=i(98885),gt=i(85602),_t=i(24524)
class pt extends mt.C{constructor(...t){super(...t),this.teamContainer=null,this.copystage=null,this.targetOne=null,this.targetTwo=null,this.targetThree=null,this.targetFour=null,
this.teamBtn=null,this.teamSymbol=null,this.taskBtn=null,this.taskSymbol=null,this.copyname=null,this.msgContainer=null,this.bgBtn=null,this.teamColider=null,this.taskColider=null,
this.targetItemList=null,this.model=null}InitView(){super.InitView(),this.model=B.s.GetInst(),this.teamContainer=new RightTeamView,
this.teamContainer.setBinderId(this.FatherId,this.FatherComponentID,1),this.copystage=new dt.Q,this.copystage.setId(this.FatherId,this.FatherComponentID,2),this.targetOne=new dt.Q,
this.targetOne.setId(this.FatherId,this.FatherComponentID,3),this.targetTwo=new dt.Q,this.targetTwo.setId(this.FatherId,this.FatherComponentID,4),this.targetThree=new dt.Q,
this.targetThree.setId(this.FatherId,this.FatherComponentID,5),this.targetFour=new dt.Q,this.targetFour.setId(this.FatherId,this.FatherComponentID,6),this.teamBtn=new ht.W,
this.teamBtn.setId(this.FatherId,this.FatherComponentID,7),this.teamSymbol=new ct.w,this.teamSymbol.setId(this.FatherId,this.FatherComponentID,8),this.taskBtn=new ht.W,
this.taskBtn.setId(this.FatherId,this.FatherComponentID,9),this.taskSymbol=new ct.w,this.taskSymbol.setId(this.FatherId,this.FatherComponentID,10),this.copyname=new dt.Q,
this.copyname.setId(this.FatherId,this.FatherComponentID,11),this.msgContainer=new rt.z,this.msgContainer.setId(this.FatherId,this.FatherComponentID,12),this.bgBtn=new ht.W,
this.bgBtn.setId(this.FatherId,this.FatherComponentID,13),this.teamColider=new ut.T,this.teamColider.setId(this.FatherId,this.FatherComponentID,14),this.taskColider=new ut.T,
this.taskColider.setId(this.FatherId,this.FatherComponentID,15),this.targetItemList=new gt.Z,this.targetItemList.Add(this.targetOne),this.targetItemList.Add(this.targetTwo),
this.targetItemList.Add(this.targetThree),this.targetItemList.Add(this.targetFour)}OnAddToScene(){this.AddEvents(),
null!=this.model.msglist&&this.UpdateAsuramTaskCopyTarget(this.model.msglist),this.teamContainer.OnAddToScene(1),this.copyname.textSet((0,at.T)("魔将讨伐"))}AddEvents(){}Clear(){
null!=ce.inst.commonRightView&&ce.inst.commonRightView.Clear(),this.teamContainer.Clear()}Destroy(){this.teamContainer.Destroy()}FirstAsuramTaskCopyTarget(){
const t=_t.o.Inst().getItemById(k.a.Inst_get().currentCopyId).SuccessConditions_get().successConditionList
this.copystage.textSet(`${(0,at.T)("副本阶段：")}（${O.p.inst.curstage}/${t.Count()}）`)
let e=0
for(;e<this.targetItemList.Count();)this.targetItemList[e].node.SetActive(!1),e+=1
for(e=0;e<t[O.p.inst.curstage-1].param.MONSTERS.Count();){this.targetItemList[e].node.SetActive(!0)
const i=t[O.p.inst.curstage-1].param.MONSTERS[e].monsterId,s=ot.a.getInst().getObjById(i).name,n=t[O.p.inst.curstage-1].param.MONSTERS[e].value
this.targetItemList[e].textSet(`${(0,at.T)("击败")}[de2524]${s}（0/${n}）[-]`),e+=1}}UpdateAsuramTaskCopyTarget(t){
const e=_t.o.Inst().getItemById(k.a.Inst_get().currentCopyId).SuccessConditions_get().successConditionList
this.copystage.textSet(`${(0,at.T)("副本阶段：")}（${O.p.inst.curstage}/${e.Count()}）`)
let i=0
for(;i<this.targetItemList.Count();)this.targetItemList[i].node.SetActive(!1),i+=1
for(i=0;i<e[O.p.inst.curstage-1].param.MONSTERS.Count();){this.targetItemList[i].node.SetActive(!0)
const s=e[O.p.inst.curstage-1].param.MONSTERS[i].monsterId,n=ot.a.getInst().getObjById(s).name,l=e[O.p.inst.curstage-1].param.MONSTERS[i].value
let a=0
if(null!=t)for(const[e,i]of(0,lt.V5)(t[O.p.inst.curstage].params)){const t=It.M.String2Int(e),n=It.M.String2Int(i)
t==s&&(a+=n)}let o=null
o=a>=l?"[57ea57]":"[de2524]",this.targetItemList[i].textSet(`${(0,at.T)("击败")}${o}${n}（${a}/${l}）[-]`),i+=1}}}var Ct=i(41664),St=i(5924),ft=i(61911),yt=i(98130),wt=i(87923)
class Dt extends ft.f{constructor(){super(),this.exitTimerLabel=null,this.exitTimerLabelEx=null,this.timer=-1,this.exitTimer=0,this.preTimer=0,this._degf_StartExit=null,
this._degf_StartExit=()=>this.StartExit()}InitView(){super.InitView(),this.exitTimerLabel=new dt.Q,this.exitTimerLabel.setId(this.FatherId,this.FatherComponentID,1),
this.exitTimerLabelEx=new dt.Q,this.exitTimerLabelEx.setId(this.FatherId,this.FatherComponentID,2),this.exitTimerLabel.node.SetActive(!1),this.exitTimerLabelEx.node.SetActive(!1)}
OnAddToScene(){this.SetData(k.a.Inst_get().currentCopyId)}Clear(){-1!=this.timer&&(St.C.Inst_get().ClearInterval(this.timer),this.timer=-1)}SetData(t){
St.C.Inst_get().ClearInterval(this.timer),this.timer=-1,this.preTimer=yt.GF.INT(yt.GF.Timer_get())
const e=_t.o.Inst().getItemById(t)
null!=e&&0!=e.endTime?(this.exitTimer=e.endTime,-1==this.timer&&(this.timer=St.C.Inst_get().SetInterval(this._degf_StartExit,500),this.StartExit(),
Ct.j.Inst.PlayByDivision("CopyEndTime"))):this.EndHandler()}StartExit(){if(!this.node)return
const t=yt.GF.INT(yt.GF.Timer_get())
this.exitTimer-=t-this.preTimer,this.preTimer=t,this.exitTimer<=0?(St.C.Inst_get().ClearInterval(this.timer),this.timer=-1,
this.EndHandler()):(this.exitTimerLabel.textSet(wt.l.GetDateFormat(this.exitTimer)),this.exitTimerLabelEx.textSet(wt.l.GetDateFormat(this.exitTimer)))}EndHandler(){
ce.inst.CloseExitCopyTimerPanel()}OpenSuccessOrDefeatPanel(){const t=_t.o.Inst().getItemById(k.a.Inst_get().currentCopyId)
I._.getInst().endHang(),t.controllerType==N.S.BloodTown?u._.GetInst().OpenBloodResultPanel(N.S.BloodTown):1==k.a.Inst_get().copyEndState?c.p.inst.OpenPanel(k.a.Inst_get().currentCopyId,k.a.Inst_get().copySuccessTime,k.a.Inst_get().copySuccessReward):2==k.a.Inst_get().copyEndState&&d.v.inst.OpenPanel()
}Destroy(){this.exitTimerLabel=null,this.exitTimerLabelEx=null,-1!=this.timer&&(St.C.Inst_get().ClearInterval(this.timer),this.timer=-1)}}class Tt extends ft.f{constructor(){
super(),this.timer=-1,this._degf_DelayCloseHandler=null,this._degf_DelayCloseHandler=()=>this.DelayCloseHandler()}InitView(){super.InitView()}OnAddToScene(){this.ClearTimer()
const t=_t.o.Inst().getItemById(k.a.Inst_get().currentCopyId)
null!=t&&(t.preTime<=0?this.DelayCloseHandler():this.timer=St.C.Inst_get().SetInterval(this._degf_DelayCloseHandler,1e3*t.preTime,1))}DelayCloseHandler(){this.ClearTimer(),
ce.inst.CloseNoRecoverPanel()}ClearTimer(){St.C.Inst_get().ClearInterval(this.timer),this.timer=-1}Clear(){this.ClearTimer()}Destroy(){}}
var At=i(93984),vt=i(98800),Lt=i(97461),Mt=i(98958),bt=i(62370),Rt=i(62063),Pt=i(63062),Gt=i(57834),Ot=i(3522),Et=i(92679)
class Bt extends mt.C{constructor(){super(),this.teamContainer=null,this.taskSymbol=null,this.teamSymbol=null,this.taskBtn=null,this.teamBtn=null,this.taskColider=null,
this.teamColider=null,this.msgContainer=null,this.bgBtn=null,this.explainTxt=null,this.progressTxt=null,this.stageIcon=null,this.slider=null,this.pinjiaTxt=null,this.maxGo=null,
this.noMaxGo=null,this.iconbgBtn=null,this.icoBgBtn=null,this.scaleAnim=null,this.pingjiShowAnim=null,this.pingjiLoopAnim=null,this.pingjiUpAnim=null,this.lightSSS=null,
this.lightSS=null,this.lightS=null,this.lightA=null,this.lightB=null,this.lightC=null,this.copyname=null,this.startAnim=null,this.m_data=null,this.pingjiLightList=null,
this.animTimer=-1,this.isOne=!0,this.curTeamTipType=0,this.isShowInfoView=!0,this.isHide=!1,this.isEndStartAnim=!1,this.preProcess=0,this.stepLb=null,this.lastLb=null,
this.killCntLb=null,this.escapeLb=null,this.evaluateTimes=null,this._degf_DelayPlayNextLight=null,this._degf_FirstPanelStateHandler=null,this._degf_OnBtnClick=null,
this._degf_SetAnimStateHandler=null,this._degf_ShowStartAnimHandler=null,this._degf_StartAnimEndHandler=null,this._degf_DelayPlayNextLight=()=>this.DelayPlayNextLight(),
this._degf_FirstPanelStateHandler=t=>this.FirstPanelStateHandler(t),this._degf_OnBtnClick=(t,e)=>this.OnBtnClick(t,e),this._degf_SetAnimStateHandler=t=>this.SetAnimStateHandler(t),
this._degf_ShowStartAnimHandler=()=>this.ShowStartAnimHandler(),this._degf_StartAnimEndHandler=()=>this.StartAnimEndHandler()}InitView(){this.teamContainer=new RightTeamView,
this.teamContainer.setBinderId(this.FatherId,this.FatherComponentID,1),this.taskSymbol=new ct.w,this.taskSymbol.setId(this.FatherId,this.FatherComponentID,4),
this.teamSymbol=new ct.w,this.teamSymbol.setId(this.FatherId,this.FatherComponentID,5),this.taskBtn=new ht.W,this.taskBtn.setId(this.FatherId,this.FatherComponentID,8),
this.teamBtn=new ht.W,this.teamBtn.setId(this.FatherId,this.FatherComponentID,9),this.taskColider=new ut.T,this.taskColider.setId(this.FatherId,this.FatherComponentID,10),
this.teamColider=new ut.T,this.teamColider.setId(this.FatherId,this.FatherComponentID,11),this.msgContainer=new rt.z,
this.msgContainer.setId(this.FatherId,this.FatherComponentID,2),this.bgBtn=new ht.W,this.bgBtn.setId(this.FatherId,this.FatherComponentID,12),this.explainTxt=new dt.Q,
this.explainTxt.setId(this.FatherId,this.FatherComponentID,16),this.progressTxt=new dt.Q,this.progressTxt.setId(this.FatherId,this.FatherComponentID,17),this.stageIcon=new ct.w,
this.stageIcon.setId(this.FatherId,this.FatherComponentID,18),this.iconbgBtn=new ht.W,this.iconbgBtn.setId(this.FatherId,this.FatherComponentID,23),this.slider=new Pt.p,
this.slider.setId(this.FatherId,this.FatherComponentID,19),this.pinjiaTxt=new dt.Q,this.pinjiaTxt.setId(this.FatherId,this.FatherComponentID,20),this.maxGo=new rt.z,
this.maxGo.setId(this.FatherId,this.FatherComponentID,21),this.noMaxGo=new rt.z,this.noMaxGo.setId(this.FatherId,this.FatherComponentID,22),this.scaleAnim=new Ot.k,
this.scaleAnim.setId(this.FatherId,this.FatherComponentID,24),this.pingjiShowAnim=new Ot.k,this.pingjiShowAnim.setId(this.FatherId,this.FatherComponentID,25),
this.pingjiLoopAnim=new Ot.k,this.pingjiLoopAnim.setId(this.FatherId,this.FatherComponentID,26),this.pingjiUpAnim=new Ot.k,
this.pingjiUpAnim.setId(this.FatherId,this.FatherComponentID,27),this.lightSSS=new Ot.k,this.lightSSS.setId(this.FatherId,this.FatherComponentID,28),this.lightSS=new Ot.k,
this.lightSS.setId(this.FatherId,this.FatherComponentID,29),this.lightS=new Ot.k,this.lightS.setId(this.FatherId,this.FatherComponentID,30),this.lightA=new Ot.k,
this.lightA.setId(this.FatherId,this.FatherComponentID,31),this.lightB=new Ot.k,this.lightB.setId(this.FatherId,this.FatherComponentID,32),this.lightC=new Ot.k,
this.lightC.setId(this.FatherId,this.FatherComponentID,33),this.copyname=new dt.Q,this.copyname.setId(this.FatherId,this.FatherComponentID,34),this.startAnim=new Ot.k,
this.startAnim.setId(this.FatherId,this.FatherComponentID,35),this.stepLb=new dt.Q,this.stepLb.setId(this.FatherId,this.FatherComponentID,36),this.lastLb=new dt.Q,
this.lastLb.setId(this.FatherId,this.FatherComponentID,37),this.killCntLb=new dt.Q,this.killCntLb.setId(this.FatherId,this.FatherComponentID,38),this.escapeLb=new dt.Q,
this.escapeLb.setId(this.FatherId,this.FatherComponentID,39),this.pingjiLightList=new gt.Z,this.pingjiLightList.Add(this.lightSSS),this.pingjiLightList.Add(this.lightSS),
this.pingjiLightList.Add(this.lightS),this.pingjiLightList.Add(this.lightA),this.pingjiLightList.Add(this.lightB),this.pingjiLightList.Add(this.lightC)}OnAddToScene(){
null!=this.m_data&&this.showrefresh(this.m_data),this.teamContainer.OnAddToScene(1),this.AddLis(),
-1==this.animTimer&&(this.animTimer=St.C.Inst_get().SetFrameLoop(this._degf_ShowStartAnimHandler,8,1))
const t=k.a.Inst_get().curCopyType
t==N.S.SKY_ILLUSION?this.copyname.textSet((0,at.T)("天空幻境")+(_t.o.Inst().getSkyLandLayerById(k.a.Inst_get().currentCopyId)+(0,at.T)("层"))):t==N.S.Belial&&this.copyname.textSet((0,
at.T)("恶魔广场")+(_t.o.Inst().getBelialLayerById(k.a.Inst_get().currentCopyId)+(0,at.T)("层")))}ShowStartAnimHandler(){this.isShowInfoView&&!this.isHide&&(this.ClearAnimTimer(),
this.pingjiShowAnim.node.SetActive(!0),this.pingjiShowAnim.SetResetOnPlay(!0),this.pingjiShowAnim.Play(!0,!1),this.pingjiLoopAnim.node.SetActive(!0),
this.pingjiLoopAnim.SetResetOnPlay(!0),this.pingjiLoopAnim.Play(!0,!1),null!=this.m_data&&this.ShowPingjiaLightAnim(this.m_data.evaluateLevel),this.isOne=!1)}ClearAnimTimer(){
St.C.Inst_get().ClearLoop(this.animTimer),this.animTimer=-1}ShowPingjiaLightAnim(t){let e=0
for(;e<this.pingjiLightList.Count();)e==t?(this.pingjiLightList[e].node.SetActive(!0),this.pingjiLightList[e].SetResetOnPlay(!0),
this.pingjiLightList[e].Play(!0,!1)):this.pingjiLightList[e].node.SetActive(!1),e+=1}AddLis(){Gt.i.Get(this.iconbgBtn.node).RegistonClick(this._degf_OnBtnClick),
Rt.U.AddEventToFinishedHandler(this.startAnim.FatherId,this.startAnim.ComponentId,this._degf_StartAnimEndHandler),
Lt.i.Inst.AddEventHandler(Et.g.COPY_INFOPANEL_SHOWSTATE,this._degf_SetAnimStateHandler),Lt.i.Inst.AddEventHandler(Et.g.UITweenStateChanged,this._degf_FirstPanelStateHandler)}
FirstPanelStateHandler(t){this.isHide=t,this.SetAnimShowFunc()}SetAnimStateHandler(t){this.isShowInfoView=t,this.SetAnimShowFunc()}SetAnimShowFunc(){
!this.isHide&&this.isShowInfoView?this.ShowStartAnimHandler():this.EndAnimHandler()}OnBtnClick(t,e){I._.getInst().startPlayerHang(vt.Y.Inst.PrimaryRole_get()),
Rt.U.RemoveEventFromFinishedHandler(this.startAnim.FatherId,this.startAnim.ComponentId,this._degf_StartAnimEndHandler)}EndAnimHandler(){this.pingjiShowAnim.node.SetActive(!1),
this.pingjiLoopAnim.node.SetActive(!1),this.pingjiUpAnim.node.SetActive(!1),this.stageIcon.node.transform.SetLocalScale(h.P.one_get()),this.ShowPingjiaLightAnim(-1)}RemoveLis(){
Gt.i.Get(this.iconbgBtn.node).RemoveonClick(this._degf_OnBtnClick),Lt.i.Inst.RemoveEventHandler(Et.g.COPY_INFOPANEL_SHOWSTATE,this._degf_SetAnimStateHandler),
Lt.i.Inst.RemoveEventHandler(Et.g.UITweenStateChanged,this._degf_FirstPanelStateHandler)}StartAnimEndHandler(){this.isEndStartAnim=!0}refresh(t){this.m_data=t,
null!=this.stepLb&&this.showrefresh(t)}showrefresh(t){const e=_t.o.Inst().getItemById(k.a.Inst_get().currentCopyId)
if(this.evaluateTimes=e.EvaluateTimesVal_get(),this.stepLb.textSet((0,at.T)("第")+(t.currentRound+(0,at.T)("波"))),this.lastLb.textSet(t.aliveMonsterNum),
this.killCntLb.textSet(t.killMonsterNum),this.escapeLb.textSet(t.deleteMonsterNum),0==t.evaluateLevel)this.maxGo.SetActive(!0),this.noMaxGo.SetActive(!1)
else{this.maxGo.SetActive(!1),this.noMaxGo.SetActive(!0)
let e=wt.l.SetStringColor(wt.l.txtGreenStr,this.GetStageStr(t.evaluateLevel-1))
const i=new gt.Z
if(i.Add(e),this.pinjiaTxt.textSet(Mt.V.Inst().getStr(10543,At.h.eLangResource,i)),i.Clear(),-1!=t.currentRound){const s=this.evaluateTimes[t.evaluateLevel-1]
e=wt.l.SetStringColor(wt.l.txtGreenStr,It.M.DoubleToString(s)),i.Add(e),this.explainTxt.textSet(Mt.V.Inst().getStr(10544,At.h.eLangResource,i)),
this.progressTxt.textSet(t.killMonsterNum+(bt.o.s_F_SLASH_ONE+s)),this.slider.DoF_SetValue(t.killMonsterNum,s)}}this.stageIcon.spriteNameSet(this.GetIconStr()),
this.stageIcon.MakePixelPerfect(),this.JudgeAnimType(),this.preProcess=t.currentRound}JudgeAnimType(){
this.isOne||this.preProcess!=this.m_data.currentRound&&this.isShowInfoView&&!this.isHide&&(this.ShowPingjiaLightAnim(-1),this.pingjiUpAnim.node.SetActive(!0),
this.pingjiUpAnim.SetResetOnPlay(!0),this.pingjiUpAnim.Play(!0,!1),this.isEndStartAnim&&(this.scaleAnim.SetResetOnPlay(!0),this.scaleAnim.Play(!0,!1)),
-1==this.animTimer&&(this.animTimer=St.C.Inst_get().SetFrameLoop(this._degf_DelayPlayNextLight,7,1)))}DelayPlayNextLight(){this.ClearAnimTimer(),
this.ShowPingjiaLightAnim(this.m_data.evaluateLevel)}GetStageStr(t){return 5==t?"C":4==t?"B":3==t?"A":2==t?"S":1==t?"SS":"SSS"}GetIconStr(){
return 5==this.m_data.evaluateLevel?"mainui_sp_0188":4==this.m_data.evaluateLevel?"mainui_sp_0189":3==this.m_data.evaluateLevel?"mainui_sp_0190":2==this.m_data.evaluateLevel?"mainui_sp_0191":1==this.m_data.evaluateLevel?"mainui_sp_0192":"mainui_sp_0193"
}Clear(){this.teamContainer.Clear(),this.RemoveLis()}Destroy(){this.teamContainer.Destroy(),this.teamContainer=null,this.taskSymbol=null,this.teamSymbol=null,this.taskBtn=null,
this.teamBtn=null,this.taskColider=null,this.teamColider=null,this.msgContainer=null,this.bgBtn=null,this.explainTxt=null,this.progressTxt=null,this.stageIcon=null,
this.slider=null,this.pinjiaTxt=null,this.maxGo=null,this.noMaxGo=null,this.scaleAnim=null,this.pingjiShowAnim=null,this.pingjiLoopAnim=null,this.pingjiUpAnim=null,
this.lightSSS=null,this.lightSS=null,this.lightS=null,this.lightA=null,this.lightB=null,this.lightC=null,this.startAnim=null}}
var kt=i(4958),xt=i(66788),Vt=i(6665),Nt=i(67585),Ht=i(75696),Ut=i(37648),Ft=i(55492),jt=i(65550),Yt=i(99535),zt=i(20193),qt=i(58306)
class Zt extends ft.f{constructor(...t){super(...t),this.anchor=null,this.Help=null,this.Decs=null,this.AwardGrid=null,this.msg=null,this.taskid=0,this.intervalId=-1,
this.limit=1e4,this.countDown=0,this.assist_lefttime_view=null,this.bg=null}InitView(){super.InitView(),this.anchor=this.CreateComponent(rt.z,1),
this.Help=this.CreateComponent(ht.W,2),this.Decs=this.CreateComponent(dt.Q,3),this.AwardGrid=this.CreateComponent(Vt.A,4),
this.assist_lefttime_view=this.CreateComponentBinder(qt.F,5),this.bg=this.CreateComponent(ct.w,6),this.AwardGrid.SetInitInfo("ui_baseitem",null,Ht.j)}Clear(){this.ClearInterval(),
this.RemoveLis(),A.V.Inst_Get().TaskID=0,super.Clear()}Destroy(){this.anchor=null,this.Help=null,this.Decs=null,this.AwardGrid=null,super.Destroy()}OnAddToScene(){
this.SetAnchorPos(),this.Help.SetIsEnabled(!0),this.AddLis(),this.msg=A.V.Inst_Get().SM_CopyTarget,this.taskid=A.V.Inst_Get().GetCurTaskID(),
null==this.msg&&xt.Y.LogError("CopyTarget 为空"),this.UpdataView(this.msg,this.taskid),this.assist_lefttime_view.SetData(-93)}UpdataView(t,e){if(null!=t&&(this.msg=t),
this.taskid=null!=e?e:A.V.Inst_Get().GetCurTaskID(),zt.D.Inst_get().isAssistOther()?(this.Help.node.SetActive(!1),k.a.Inst_get().IsAssistOther=!0):(k.a.Inst_get().IsAssistOther=!1,
this.Help.node.SetActive(Ut.P.Inst_get().IsFuncOrActivityOpened(Ft.x.ASURAM_BOSS_ASSIST))),this.Help.activeSelf()?this.bg.heightSet(216):this.bg.heightSet(170),null==t)return
const i=_t.o.Inst().getItemById(this.msg.copyId)
let s=It.M.Split(i.roundDesc,bt.o.s_UNDER_CHAR)[this.msg.list[1].keyName-1]
s=It.M.Replace(s,"{0}",this.msg.list[1].value),this.Decs.textSet(s)
const n=A.V.Inst_Get().GetCurTaskRewardList()
null!=n&&n.Count()>0&&this.AwardGrid.data_set(n)}AddLis(){this.m_handlerMgr.AddClickEvent(this.Help,this.CreateDelegate(this.DoHelp))}RemoveLis(){this.m_handlerMgr.Clear()}
SetAnchorPos(){y.O.SetAnchorPos(this.anchor,!0,!0,0,!1)}DoHelp(){if(this.countDown>0)return
let t
if(this.taskid&&this.taskid>0){const e=Yt.O.Inst_get().GetConfig(this.taskid)
t=this.GetBossBymonsterId(e.tCTargetDefs_get().tCTargetDefs[0].param.monsterId)}else t=this.GetFirstBoss()
null!=t?(Nt.M.inst.Req_ReqAssist(A.V.Inst_Get().GetAssistType(),t.Info_get().id.ToString()),this.ClearInterval(),this.countDown=this.limit+1e3,
this.intervalId=St.C.Inst_get().SetInterval(this.CreateDelegate(this.CountDownFun),50),this.SetCountDownBtn()):jt.y.inst.ClientSysStrMsg((0,at.T)("BOSS还未刷新，请等待"))}CountDownFun(){
if(this.countDown-=50,this.countDown<0)return this.SetNormalHelpBtn(),void this.ClearInterval()
this.SetCountDownBtn()}SetNormalHelpBtn(){this.Help.SetText((0,at.T)("战盟求助")),this.countDown=0}SetCountDownBtn(){this.Help.SetText("已求助")}ClearInterval(){
0!=this.intervalId&&(St.C.Inst_get().ClearInterval(this.intervalId),this.intervalId=0)}GetBossBymonsterId(t){for(const[e,i]of(0,lt.V5)(vt.Y.BossDic))if(i.Cfg_get().id==t)return i
return null}GetFirstBoss(){for(const[t,e]of(0,lt.V5)(vt.Y.BossDic))if(e)return e
return null}}var Kt=i(8889)
class $t extends ft.f{constructor(){super(),this.waveCnt=null,this.countDownLb=null,this.showAni=null,this.countAni=null,this.bossOutObj=null,this.noCountObj=null,
this.CountObj=null,this.effCountObj=null,this.effNoCntObj=null,this.countEffPanel=null,this.coldInterval=-1,this.secondDown=-1,this._degf_CloseHandel=null,
this._degf_HandleColdTime=null,this._degf_CloseHandel=(t,e)=>this.ClosePanel(),this._degf_HandleColdTime=()=>this.HandleCountTime()}InitView(){this.waveCnt=new dt.Q,
this.waveCnt.setId(this.FatherId,this.FatherComponentID,1),this.countDownLb=new dt.Q,this.countDownLb.setId(this.FatherId,this.FatherComponentID,2),this.showAni=new Ot.k,
this.showAni.setId(this.FatherId,this.FatherComponentID,3),this.countAni=new Ot.k,this.countAni.setId(this.FatherId,this.FatherComponentID,4),this.bossOutObj=new rt.z,
this.bossOutObj.setId(this.FatherId,this.FatherComponentID,5),this.noCountObj=new rt.z,this.noCountObj.setId(this.FatherId,this.FatherComponentID,6),this.CountObj=new rt.z,
this.CountObj.setId(this.FatherId,this.FatherComponentID,7),this.effCountObj=new rt.z,this.effCountObj.setId(this.FatherId,this.FatherComponentID,8),this.effNoCntObj=new rt.z,
this.effNoCntObj.setId(this.FatherId,this.FatherComponentID,9),this.countEffPanel=new Kt.$,this.countEffPanel.setId(this.FatherId,this.FatherComponentID,10),
y.O.AddUIEffectSortOrderBind(this.countEffPanel.node)}OnAddToScene(){this.SetData()}Clear(){this.ClearCold()}Destroy(){}SetData(){const t=V.R.Inst_get()
this.waveCnt.textSet((0,at.T)("第")+(t.nextRound+(0,at.T)("波刷新"))),t.nextRoundExistBoss?this.waveCnt.node.transform.SetLocalPosition(new h.P(0,88,0)):this.waveCnt.node.transform.SetLocalPosition(new h.P(0,80,0)),
this.bossOutObj.SetActive(t.nextRoundExistBoss),this.CountObj.SetActive(!t.immediatelyNotice),this.effCountObj.SetActive(!t.immediatelyNotice),
this.effNoCntObj.SetActive(t.immediatelyNotice),t.immediatelyNotice?(this.showAni.SetResetOnPlay(!0),this.showAni.SetClipName("ani_tkhj_gwcx_03"),this.showAni.Play(!0,!1),
St.C.Inst_get().SetInterval(this._degf_CloseHandel,3e3,1),this.noCountObj.transform.SetLocalPosition(new h.P(0,14,0))):(this.showAni.SetResetOnPlay(!0),
this.showAni.SetClipName("ani_tkhj_gwcx_01"),this.showAni.Play(!0,!1),this.HandleCountTime(),this.coldInterval=St.C.Inst_get().SetInterval(this._degf_HandleColdTime,1e3),
this.noCountObj.transform.SetLocalPosition(new h.P(0,0,0)))}HandleCountTime(){this.secondDown<=0?(this.ClosePanel(),this.ClearCold()):(this.countAni.SetResetOnPlay(!0),
this.countAni.Play(!0,!1),this.countDownLb.textSet(this.secondDown),this.secondDown-=1)}ClearCold(){St.C.Inst_get().ClearInterval(this.coldInterval),this.coldInterval=-1}
ClosePanel(){ce.inst.CloseSkyCountDownPanel()}}var Wt=i(38045),Xt=i(33828)
class Qt extends ft.f{constructor(){super(),this.contentLb=null,this.btn_Slow=null,this.select=null,this.btn_Close=null,this.coldLb=null,this.leftTimes=null,this.isTrueSelect=!1,
this.isColding=!1,this.coldInterval=-1,this.coldEndTime=-1,this._degf_OnSlowClick=null,this._degf_OnSelectClick=null,this._degf_OnCloseClick=null,this._degf_HandleColdTime=null,
this._degf_OnOpenDiamondTip=null,this.selectedSp=null,this.coldObj=null,this.noColdObj=null,this._degf_OnSlowClick=(t,e)=>this.OnSlowClick(t,e),
this._degf_OnSelectClick=(t,e)=>this.OnSelectClick(t,e),this._degf_OnCloseClick=(t,e)=>this.OnCloseClick(t,e),this._degf_HandleColdTime=()=>this.HandleColdTime(),
this._degf_OnOpenDiamondTip=t=>this.OnOpenDiamondTip(t)}InitView(){this.contentLb=new dt.Q,this.contentLb.setId(this.FatherId,this.FatherComponentID,1),this.btn_Slow=new rt.z,
this.btn_Slow.setId(this.FatherId,this.FatherComponentID,2),this.select=new rt.z,this.select.setId(this.FatherId,this.FatherComponentID,3),this.btn_Close=new rt.z,
this.btn_Close.setId(this.FatherId,this.FatherComponentID,4),this.selectedSp=new rt.z,this.selectedSp.setId(this.FatherId,this.FatherComponentID,5),this.coldObj=new rt.z,
this.coldObj.setId(this.FatherId,this.FatherComponentID,6),this.noColdObj=new rt.z,this.noColdObj.setId(this.FatherId,this.FatherComponentID,7),this.coldLb=new dt.Q,
this.coldLb.setId(this.FatherId,this.FatherComponentID,8),this.leftTimes=new dt.Q,this.leftTimes.setId(this.FatherId,this.FatherComponentID,9)}OnAddToScene(){this.SetData(),
this.AddLis()}AddLis(){Gt.i.Get(this.btn_Slow).RegistonClick(this._degf_OnSlowClick),Gt.i.Get(this.select).RegistonClick(this._degf_OnSelectClick),
Gt.i.Get(this.btn_Close).RegistonClick(this._degf_OnCloseClick)}RemoveLis(){Gt.i.Get(this.btn_Slow).RemoveonClick(this._degf_OnSlowClick),
Gt.i.Get(this.select).RemoveonClick(this._degf_OnSelectClick),Gt.i.Get(this.btn_Close).RemoveonClick(this._degf_OnCloseClick)}Clear(){this.RemoveLis(),this.isTrueSelect=!1,
this.ClearCold()}Destroy(){}OnSlowClick(t,e){this.isColding||(ce.inst.CloseSlowDownTip(),O.p.inst.SendSlowDown())}OnOpenDiamondTip(t){Xt.Y.Inst_get().OkHandler(null)}
OnSelectClick(t,e){this.selectedSp.SetActive(!this.isTrueSelect),this.isTrueSelect=!this.isTrueSelect,V.R.Inst_get().IsAutoUsing_set(this.isTrueSelect)}OnCloseClick(t,e){
ce.inst.CloseSlowDownTip()}SetData(){const t=new gt.Z
t.Add(V.R.Inst_get().addBuffData.debuffParam),this.contentLb.textSet(Mt.V.Inst().getStr(10824,At.h.eLangResource,t))
const e=V.R.Inst_get().GetLeftSlowTimes()
let i=(0,at.T)("剩余次数：")
if(i+=e<=0?`[de2524]${(0,Wt.tw)(e)}[-]`:`[57ea57]${(0,Wt.tw)(e)}[-]`,this.leftTimes.textSet(i),this.isColding=!(e<=0)&&V.R.Inst_get().isColdingSlow,
this.coldObj.SetActive(this.isColding),this.noColdObj.SetActive(!this.isColding),this.isColding){const t=g.D.serverMSTime_get()
this.coldEndTime=V.R.Inst_get().coldEndTime,t<this.coldEndTime&&(this.HandleColdTime(),this.coldInterval=St.C.Inst_get().SetInterval(this._degf_HandleColdTime,1e3))}}
HandleColdTime(){let t=this.coldEndTime-g.D.serverMSTime_get()
t=yt.GF.INT(t/1e3),t<=0?(this.isColding=!1,this.ClearCold(),this.coldObj.SetActive(!1),this.noColdObj.SetActive(!0)):this.coldLb.textSet((0,at.T)("冷却剩余时间")+(t+(0,at.T)("秒")))}
ClearCold(){St.C.Inst_get().ClearInterval(this.coldInterval),this.coldInterval=-1}}
var Jt,te,ee=i(73865),ie=i(71881),se=i(83900),ne=i(57553),le=i(32076),ae=i(44744),oe=i(30635),re=i(62783),he=i(33065),de=i(12417)
let ce=(te=class t{static Inst_get(){return t.inst||(t.inst=new t),t.inst}get copyBloodTownTracePanel(){return(0,o.Y)(l.I.BloodTownTracePanel)}get enterView(){
return this._enterView||(this._enterView=(0,o.Y)(l.I.EnterCopyTime)),this._enterView}get soonEndView(){return this._soonEndView||(this._soonEndView=(0,
o.Y)(l.I.CopySoonEndTimePanel)),this._soonEndView}get copyInspireView(){return(0,o.Y)(l.I.CopyInspire)}get copyBloodTownLeftTimeView(){return(0,o.Y)(l.I.CopyBloodTownLeftTimePanel)
}constructor(){this.copyBelialUIView=null,this.copyAllianQuestionTracePanel=null,this._enterView=null,this.exitView=null,this._soonEndView=null,this.commonRightView=null,
this.noRecoverView=null,this.CopyPanelPos=null,this.CopyBelialPanelPos=null,this.CopyDragonAreaPanelPos=null,this.EnterPos=null,this.ExitPos=null,this.BloodTownEvaluatePos=null,
this.SiegeMsgPos=null,this.bt_loading=null,this.inAlliQuestion=!1,this.copyBelielExpPanel=null,this.copyLeftTimeView=null,this.copyBloodtownGainAwardView=null,
this.copySkylandUIView=null,this.slowDownTipPanel=null,this.skylandCountDownPanel=null,this.AsuramTaskCopyTracePanel=null,this.RyAllianceCopyTask=null,
this.copyQuentonSealUIView=null,this.copySweepView=null,this.copyGainView=null,this._degf_DestroyAllianceQuestionTraceView=null,this._degf_DestroyBTLoading=null,
this._degf_DestroyBloodTownTraceView=null,this._degf_DestroyAsuramTaskCopyTraceView=null,this._degf_DestroyCopyBelialUIView=null,this._degf_DestroyCopyBelielExpPanel=null,
this._degf_DestroyCopyBloodTownGainAwardView=null,this._degf_DestroyCopyBloodTownLeftTimeView=null,this._degf_DestroyCopyInspireView=null,this._degf_DestroyCopyLeftTimeView=null,
this._degf_DestroyCopySweepView=null,this._degf_DestroyEnterTimerPanel=null,this._degf_DestroyExitTimerPanel=null,this._degf_DestroyNoRecoverPanel=null,
this._degf_DestroySoonEndView=null,this._degf_ShowAllianceQuestionTraceHandler=null,this._degf_ShowBTLoadingComplete=null,this._degf_ShowBloodTownTraceHandler=null,
this._degf_ShowAsuramTaskCopyTraceHandler=null,this._degf_ShowCopyBelialUIViewHandler=null,this._degf_ShowCopyBelielExpPanelHandler=null,
this._degf_ShowCopyBloodTownGainAwardViewHandler=null,this._degf_ShowCopyInspireViewHandler=null,this._degf_ShowCopySweepViewHandler=null,
this._degf_ShowCopyLeftTimeViewHandler=null,this._degf_ShowHandlerThree=null,this._degf_ShowHandlerTwo=null,this._degf_ShowNoRecoverHandler=null,
this._degf_ShowSoonEndViewHandler=null,this._degf_ShowCopySkyLandUIViewHandler=null,this._degf_DestroyCopySkyLandUIViewHandler=null,this._degf_ShowSlowDownTipPanelHandler=null,
this._degf_DestroySlowDownTipPanelHandler=null,this._degf_ShowSkyCountDownPanelHandler=null,this._degf_DestroySkyCountDownPanelHandler=null,
this._degf_ShowCopyQuentonSealUIViewHandler=null,this._degf_DestroyCopyQuentonSealUIViewHandler=null,this._degf_ShowCopyGainViewHandler=null,this._degf_DestroyCopyGainView=null,
this.CopyPanelPos=new h.P,this.CopyBelialPanelPos=new h.P,this.CopyDragonAreaPanelPos=new h.P,this.EnterPos=new h.P,this.ExitPos=new h.P,this.BloodTownEvaluatePos=new h.P,
this.SiegeMsgPos=new h.P,this._degf_DestroyAllianceQuestionTraceView=()=>{},this._degf_DestroyBTLoading=()=>this.DestroyBTLoading(),
this._degf_DestroyBloodTownTraceView=()=>this.DestroyBloodTownTraceView(),this._degf_DestroyAsuramTaskCopyTraceView=()=>this.DestroyAsuramTaskCopyTraceView(),
this._degf_DestroyCopyBelialUIView=()=>this.DestroyCopyBelialUIView(),this._degf_DestroyCopyBelielExpPanel=()=>this.DestroyCopyBelielExpPanel(),
this._degf_DestroyCopyBloodTownGainAwardView=()=>this.DestroyCopyBloodTownGainAwardView(),this._degf_DestroyCopyBloodTownLeftTimeView=()=>this.DestroyCopyBloodTownLeftTimeView(),
this._degf_DestroyCopyInspireView=()=>this.DestroyCopyInspireView(),this._degf_DestroyCopyLeftTimeView=()=>this.DestroyCopyLeftTimeView(),
this._degf_DestroyCopySweepView=()=>this.DestroyCopySweepView(),this._degf_DestroyEnterTimerPanel=()=>this.DestroyEnterTimerPanel(),
this._degf_DestroyExitTimerPanel=()=>this.DestroyExitTimerPanel(),this._degf_DestroyNoRecoverPanel=()=>this.DestroyNoRecoverPanel(),
this._degf_DestroySoonEndView=()=>this.DestroySoonEndView(),this._degf_ShowAllianceQuestionTraceHandler=t=>{},this._degf_ShowBTLoadingComplete=t=>this.ShowBTLoadingComplete(t),
this._degf_ShowAsuramTaskCopyTraceHandler=t=>this.ShowAsuramTaskCopyTraceHandler(t),this._degf_ShowCopyBelialUIViewHandler=t=>this.ShowCopyBelialUIViewHandler(t),
this._degf_ShowCopyBelielExpPanelHandler=t=>this.ShowCopyBelielExpPanelHandler(t),this._degf_ShowCopyBloodTownGainAwardViewHandler=t=>this.ShowCopyBloodTownGainAwardViewHandler(t),
this._degf_ShowCopyInspireViewHandler=t=>this.ShowCopyInspireViewHandler(t),this._degf_ShowCopySweepViewHandler=t=>this.ShowCopySweepViewHandler(t),
this._degf_ShowCopyLeftTimeViewHandler=t=>this.ShowCopyLeftTimeViewHandler(t),this._degf_ShowHandlerThree=t=>this.ShowHandlerThree(t),
this._degf_ShowHandlerTwo=t=>this.ShowHandlerTwo(t),this._degf_ShowNoRecoverHandler=t=>this.ShowNoRecoverHandler(t),
this._degf_ShowSoonEndViewHandler=t=>this.ShowSoonEndViewHandler(t),this._degf_ShowCopySkyLandUIViewHandler=t=>this.ShowCopySkyLandUIViewHandler(t),
this._degf_DestroyCopySkyLandUIViewHandler=t=>this.DestroyCopySkyLandUIViewHandler(),this._degf_ShowSlowDownTipPanelHandler=t=>this.ShowSlowDownTipPanelHandler(t),
this._degf_DestroySlowDownTipPanelHandler=t=>this.DestroySlowDownTipPanelHandler(),this._degf_ShowSkyCountDownPanelHandler=t=>this.ShowSkyCountDownPanelHandler(t),
this._degf_DestroySkyCountDownPanelHandler=t=>this.DestroySkyCountDownPanelHandler(),this._degf_ShowCopyQuentonSealUIViewHandler=t=>this.ShowCopyQuentonSealUIViewHandler(t),
this._degf_DestroyCopyQuentonSealUIViewHandler=()=>this.DestroyCopyQuentonSealUIViewHandler(),this._degf_ShowCopyGainViewHandler=t=>this.ShowCopyGainViewHandler(t),
this._degf_DestroyCopyGainView=()=>this.DestroyCopyGainView(),this.CopyPanelPos=new h.P(-8,400,0).Clone(),this.CopyBelialPanelPos=new h.P(30,400,0).Clone(),
this.EnterPos=new h.P(0,50,0).Clone(),this.ExitPos=new h.P(0,0,0).Clone(),this.BloodTownEvaluatePos=new h.P(0,-40,0).Clone(),this.CopyDragonAreaPanelPos=new h.P(30,300,0).Clone(),
this.SiegeMsgPos=new h.P(0,300,0).Clone()}InitCommonRightView(t){this.DestroyCommonRightView(),null==this.commonRightView&&(this.commonRightView=(0,o.Y)(t))}
DestroyCommonRightView(){null!=this.commonRightView&&(this.commonRightView=null)}OpenCopyPanel(){}PreTimeOpenMsgPanel(){const t=k.a.Inst_get().curCopyType
t==N.S.BloodTown?(this.OpenBloodTownTraceView(),this.OpenCopyBloodTownLeftTimeView()):t==N.S.Belial?this.OpenCopyBelialUIView():t==N.S.SKY_ILLUSION?this.OpenCopySkyLandUIView():t==N.S.KUNDUN_SEAL?this.OpenCopyQuentonSealUIView():t==N.S.LoseSecrets||de._.Inst().IsVipBossCopy(t)||(t==N.S.AsuramTaskCopy?this.OpenAsuramTaskCopyTraceView():t==N.S.LostAbyss?K.o.Inst_Get().OpenCopyInfoPanel():t==N.S.Maze&&X.G.Inst_get().OpenCopyInfoPanel()),
t==N.S.AllianceHome&&(v.N.inst_get().CheckCountDownLogic(),b.w.Inst_get().checkInActivity()&&E.L.GetInst().OpenQuestionView()),
t!=N.S.AllianceBoss1&&t!=N.S.AllianceBoss2&&t!=N.S.AllianceBoss3&&t!=N.S.AllianceBoss4||(M.Q.Inst_get().m_isOpen=!1,M.Q.Inst_get().bossModel.ShowUI()),
t==N.S.RyAllianceTask&&A.V.Inst_Get().GetCurTaskID()>0&&this.OpenRyAllianceCopyTaskView(),t==N.S.RolandDefend1&&this.OpenRolandRepairCrackCopyView(),
t==N.S.RolandDefend2&&this.OpenRolandDefenseCopy2View(),t==N.S.JigsawBoss&&this.OpenRyAllianceCopyTaskView(),
t==N.S.AllianceHome&&(E.L.GetInst().IsBornFireActivityOpen()&&this.OpenRyAllianceCopyBornFireView(),E.L.GetInst().OnEnterAllianceScene()),
t==N.S.MapPassBoss?(se.N.Inst().OpenMapFbInfoView(),se.N.Inst().OpanMapPassAlertView()):t==N.S.UnlockMapBoss&&re.X.inst.OpenUnlockMapBossFbInfoView(),
t==N.S.SpringCattle&&Z.Q.Inst_get().OpenSpringCattleCopyView()}OpenCopyLoadingPanel(){const t=k.a.Inst_get().curCopyType
t==N.S.BloodTown||t==N.S.RedFortress||t==N.S.Belial||t==N.S.Arena||N.S.LoseSecrets}OpenBloodTownLoading(){
n.N.inst.OpenById(l.I.eBloodTownLoading,this._degf_ShowBTLoadingComplete,this._degf_DestroyBTLoading)}DestroyBTLoading(){_.g.DestroyUIObj(this.bt_loading),this.bt_loading=null}
ShowBTLoadingComplete(t){return null==this.bt_loading&&(this.bt_loading=new H.p,this.bt_loading.setId(t,null,0)),this.bt_loading}CloseBtLoading(){
n.N.inst.ClosePanel(this.bt_loading)}SetHangState(){}OpenEnterCopyTimerPanel(){const t=new s.v
t.positionType=f.$.eCenter,(0,o.Yp)(l.I.EnterCopyTime,t)}DestroyEnterTimerPanel(){_.g.DestroyUIObj(this.enterView)}ShowHandlerTwo(t){}JudgeCloseAllCopyPanel(){
K.o.Inst_Get().CloseBattlePanel(),he.x.Inst_get().CloseMemberDmgView(),v.N.inst_get().OpenOrDelPanel(!1,null),R.C.inst.CloseNPCTipView(),E.L.GetInst().CloseCopyUI(null),
this.CloseBloodTownTraceView(),this.CloseCopyBelialUIView(),this.CloseCopySkylandUIView(),this.CloseAsuramTaskCopyTraceView(),this.CloseCopyQuentonSealUIView(),
this.CloseRyAllianceCopyTaskView(),this.CloseRolandRepairCrackCopyView(),this.CloseRolandDefenseCopy2View(),this.CloseRyAllianceCopyBornFireView(),se.N.Inst().CloseMapFbInfoView(),
se.N.Inst().CloseMapPassAlertView(),re.X.inst.CloseUnlockMapBossFbInfoView(),X.G.Inst_get().CloseCopyInfoPanel(),Z.Q.Inst_get().CloseSpringCattleCopyView()}CloseConflictView(){
Q._.Inst_get().CloseAll(),oe.Y.Inst().Close(),it.q.inst_get().control.Close(),$.R.GetInst().CloseDeletePanel(),nt.x.Inst_get().CloseView(),
W.T.inst_get().control.ForceClosePkFuncView(),w.S.Inst_get().CloseActivityBaoKuBuy(),D.r.Inst_get().CloseActivityBaoKuReward(),E.L.GetInst().CloseCopyUI(),
Z.Q.Inst_get().CloseSpringCattleCopyView(),this.CloseAsuramTaskCopyTraceView(),this.CloseCopyQuentonSealUIView(),this.CloseRyAllianceCopyTaskView(),
this.CloseRolandRepairCrackCopyView(),this.CloseRolandDefenseCopy2View(),this.CloseRyAllianceCopyBornFireView()}OpenSuccessOrDefeatPanel(){this.CloseConflictView(),
I._.getInst().endHang()
const t=_t.o.Inst().getItemById(k.a.Inst_get().currentCopyId)
null!=t&&(t.controllerType==N.S.BloodTown?(x.w.GetInst().SetNpcTopUI(1),u._.GetInst().OpenBloodResultPanel(N.S.BloodTown),I._.getInst().endHang(),u._.GetInst().CloseStone(),
W.T.inst_get().control.CloseBuffListPanel(),
W.T.inst_get().control.CloseBuffDetailPanel()):1==k.a.Inst_get().copyEndState?de._.Inst().IsVipBossCopy(t.controllerType)?m.C.Inst_get().OpenSuccessPanel():t.controllerType==N.S.LostAbyss?K.o.Inst_Get().OpenSuccessPanel():t.controllerType==N.S.RyAllianceTask?T.k.Inst_Get().OpenSuccessPanel():t.controllerType==N.S.Belial||t.controllerType==N.S.KUNDUN_SEAL||this.OpenCommonSuccessView():2==k.a.Inst_get().copyEndState&&(de._.Inst().IsVipBossCopy(t.controllerType)?m.C.Inst_get().OpenDefeatPanel():d.v.inst.OpenPanel()),
this.ClosePanelAfterCopyEnd())}CloseSuccessOrDefeatePanel(){u._.GetInst().CloseResultView(),u._.GetInst().CloseSuccessPanel(),m.C.Inst_get().CloseSuccessPanel(),
c.p.inst.ClosePanel(),d.v.inst.ClosePanel()}ClosePanelAfterCopyEnd(){ne._.Inst.CloseCDKeyPanel(),jt.y.inst.closeCommonMessageTips(),G.t.Inst().Close(),oe.Y.Inst().CloseHeadPanel(),
ae.Z.Inst().Close(),oe.Y.Inst().CloseTargetHead(),this.CloseCopyGainView(),y.O.CloseSecondayView()}OpenExitCopyTimerPanel(){const t=new s.v
t.pos=this.ExitPos.Clone(),t.positionType=p.Z.eTop,t.aniDir=S.K.Up,n.N.inst.OpenById(l.I.ExitCopyTime,this._degf_ShowHandlerThree,this._degf_DestroyExitTimerPanel,t)}
ShowHandlerThree(t){return null==this.exitView&&(this.exitView=new Dt,this.exitView.setId(t,null,0)),this.exitView}DestroyExitTimerPanel(){
null!=this.exitView&&(_.g.DestroyUIObj(this.exitView),this.exitView=null)}CloseEnterCopyTimerPanel(){null!=this.enterView&&n.N.inst.CloseById(l.I.EnterCopyTime)}
CloseExitCopyTimerPanel(){null!=this.exitView&&n.N.inst.CloseById(l.I.ExitCopyTime)}OpenBloodTownTraceView(){if(null==this.copyBloodTownTracePanel){const t=new s.v
t.layerType=C.F.DefaultUI,t.positionType=f.$.eLeft,t.aniDir=S.K.Left,n.N.inst.OpenById(l.I.BloodTownTracePanel,null,null,t)}}CloseBloodTownTraceView(){
n.N.inst.CloseById(l.I.BloodTownTracePanel)}OpenRolandRepairCrackCopyView(){const t=new s.v
t.layerType=C.F.DefaultUI,t.positionType=f.$.eLeft,t.viewClass=et.J,n.N.inst.OpenById(l.I.RolandRepairCrackCopyView,null,null,t)}CloseRolandRepairCrackCopyView(){
n.N.inst.CloseById(l.I.RolandRepairCrackCopyView)}OpenRolandDefenseCopy2View(){const t=new s.v
t.layerType=C.F.DefaultUI,t.positionType=f.$.eLeft,t.viewClass=tt.d,n.N.inst.OpenById(l.I.RolandDefenseCopy2View,null,null,t)}CloseRolandDefenseCopy2View(){
n.N.inst.CloseById(l.I.RolandDefenseCopy2View),J.$.GetInst().AsuramBossDamageList=null}UpdateAsuramTaskCopyTraceView(t){
null!=this.AsuramTaskCopyTracePanel?this.AsuramTaskCopyTracePanel.UpdateAsuramTaskCopyTarget(t):B.s.GetInst().SetMsg(t)}UpdateRyAllianceTaskCopyTraceView(t){
null!=this.RyAllianceCopyTask?this.RyAllianceCopyTask.UpdataView(t):A.V.Inst_Get().SetMsg(t)}OpenRyAllianceCopyTaskView(){if(null==this.RyAllianceCopyTask){const t=new s.v
t.layerType=C.F.DefaultUI,t.positionType=f.$.eLeft,n.N.inst.OpenById(l.I.eRyAllianceCopyTaskView,(0,le.v)(this.RyAllianceCopyTaskCompelt,this),(0,
le.v)(this.DestroyRyAllianceCopyTask,this),t)}}CloseRyAllianceCopyTaskView(){null!=this.RyAllianceCopyTask&&n.N.inst.ClosePanel(this.RyAllianceCopyTask)}
RyAllianceCopyTaskCompelt(t){return null==this.RyAllianceCopyTask&&(this.RyAllianceCopyTask=new Zt,this.RyAllianceCopyTask.setId(t,null,0)),this.RyAllianceCopyTask}
DestroyRyAllianceCopyTask(){_.g.DestroyUIObj(this.RyAllianceCopyTask),this.RyAllianceCopyTask=null}OpenAsuramTaskCopyTraceView(){if(null==this.AsuramTaskCopyTracePanel){
const t=new s.v
t.layerType=C.F.DefaultUI,t.positionType=f.$.eCustom,t.aniDir=S.K.Right3,n.N.inst.OpenById(l.I.eAsuramTaskCopyTracePanel,this._degf_ShowAsuramTaskCopyTraceHandler,this._degf_DestroyAsuramTaskCopyTraceView,t)
}}DestroyAsuramTaskCopyTraceView(){this.AsuramTaskCopyTracePanel.Clear(),this.AsuramTaskCopyTracePanel.Destroy(),_.g.DestroyUIObj(this.AsuramTaskCopyTracePanel),
this.DestroyCommonRightView(),this.AsuramTaskCopyTracePanel=null}CloseAsuramTaskCopyTraceView(){
null!=this.commonRightView?n.N.inst.CloseById(l.I.eAsuramTaskCopyTracePanel):n.N.inst.UnLoading(l.I.eAsuramTaskCopyTracePanel)}ShowAsuramTaskCopyTraceHandler(t){
if(this.InitCommonRightView(t),null==this.AsuramTaskCopyTracePanel){const e=_.g.GetResFindId("ui_copybaseui_asuramtasktrace_panel")
this.AsuramTaskCopyTracePanel=new pt,this.AsuramTaskCopyTracePanel.setId(e,null,0),
this.AsuramTaskCopyTracePanel.node.transform.SetParent(this.commonRightView.moveContainer.FatherId,this.commonRightView.moveContainer.ComponentId),q.I.calVec0.Set(-631,-49,0),
this.AsuramTaskCopyTracePanel.node.transform.SetLocalPosition(q.I.calVec0),this.AsuramTaskCopyTracePanel.OnAddToScene(),n.N.inst.SetChildDepth(t,e),
this.commonRightView.InitTeamTipType(1),
this.commonRightView.SetData(this.AsuramTaskCopyTracePanel.msgContainer,this.AsuramTaskCopyTracePanel.teamContainer,this.AsuramTaskCopyTracePanel.teamBtn,this.AsuramTaskCopyTracePanel.taskBtn,this.AsuramTaskCopyTracePanel.bgBtn,this.AsuramTaskCopyTracePanel.teamColider,this.AsuramTaskCopyTracePanel.taskColider,this.AsuramTaskCopyTracePanel.taskSymbol,this.AsuramTaskCopyTracePanel.teamSymbol),
this.commonRightView.AddToScene()}return this.commonRightView}OpenSoonEndTimeView(){if(!O.p.inst.IsInCopy())return
if(O.p.inst.IsCopyInBloodTown())return
if(_t.o.Inst().getItemById(k.a.Inst_get().currentCopyId).controllerType!=N.S.Arena&&!(L.a.isInAllianceBossMap_get()||null!=this.soonEndView&&this.soonEndView.isShow_get())){
const t=new s.v
t.layerType=C.F.DefaultUI,(0,o.Yp)(l.I.CopySoonEndTimePanel,t)}}DestroySoonEndView(){_.g.DestroyUIObj(this.soonEndView)}ShowSoonEndViewHandler(t){}CloseSoonEndTimeView(){(0,
o.qJ)(l.I.CopySoonEndTimePanel)&&(0,o.sR)(l.I.CopySoonEndTimePanel)}OpenCopyBelialUIView(){if(null==this.copyBelialUIView){const t=new s.v
t.layerType=C.F.DefaultUI,t.positionType=f.$.eCustom,t.aniDir=S.K.Left,(0,o.Yp)(l.I.CopyBelialUIPanel,t,this._degf_ShowCopyBelialUIViewHandler)}}DestroyCopyBelialUIView(){(0,
o.sR)(l.I.CopyBelialUIPanel),this.copyBelialUIView=null}CloseCopyBelialUIView(){this.DestroyCopyBelialUIView()}ShowCopyBelialUIViewHandler(t){return this.copyBelialUIView=(0,
o.Y)(l.I.CopyBelialUIPanel),this.copyBelialUIView}OpenCopyInspireView(){const t=new s.v
t.isShowMask=!0,t.isCloseCamera=!1,(0,o.Yp)(l.I.CopyInspire,t)}DestroyCopyInspireView(){}CloseCopyInspireView(){(0,o.sR)(l.I.CopyInspire)}ShowCopyInspireViewHandler(t){}
InspireIsShow(){return null!=this.copyInspireView}ShowInspire(t,e){null!=this.copyInspireView&&this.copyInspireView.ShowInspireMsg(t,e)}ShowInspireTimes(t){
null!=this.copyInspireView&&this.copyInspireView.ShowInspireTime(t)}PlayResultAnim(t){
null!=this.copyInspireView&&(t?this.copyInspireView.PlaySuccessAnim():this.copyInspireView.PlayDefeatAnim())}OpenCopyGainView(){const t=new s.v
t.isShowMask=!0,(0,o.Yp)(l.I.CopyGain,t)}DestroyCopyGainView(){}CloseCopyGainView(){(0,o.qJ)(l.I.CopyGain)&&(0,o.sR)(l.I.CopyGain)}ShowCopyGainViewHandler(t){}
OpenCopyBelielExpPanel(){const t=new s.v
t.positionType=f.$.eCustom,t.isShowMask=!0,n.N.inst.OpenById(l.I.CopyExpBuff,this._degf_ShowCopyBelielExpPanelHandler,this._degf_DestroyCopyBelielExpPanel,t)}
DestroyCopyBelielExpPanel(){_.g.DestroyUIObj(this.copyBelielExpPanel),this.copyBelielExpPanel=null}CloseCopyBelielExpPanel(){
null!=this.copyBelielExpPanel&&n.N.inst.ClosePanel(this.copyBelielExpPanel)}ShowCopyBelielExpPanelHandler(t){return null==this.copyBelielExpPanel&&(this.copyBelielExpPanel=new F.M,
this.copyBelielExpPanel.setId(t,null,0)),this.copyBelielExpPanel}ExpPanelIsShow(){return!(null==this.copyBelielExpPanel||!this.copyBelielExpPanel.isShow_get())}
OpenCopySweepView(t){if(null==this.copySweepView||0==this.copySweepView.isShow_get()){k.a.Inst_get().copySweepVo=t
const e=new s.v
e.isShowMask=!0,e.positionType=f.$.eCenter,n.N.inst.OpenById(l.I.CopySweepView,this._degf_ShowCopySweepViewHandler,this._degf_DestroyCopySweepView,e)}}DestroyCopySweepView(){
_.g.DestroyUIObj(this.copySweepView),this.copySweepView=null}CloseCopySweepView(){null!=this.copySweepView&&n.N.inst.ClosePanel(this.copySweepView)}ShowCopySweepViewHandler(t){
return null==this.copySweepView&&(this.copySweepView=new z.N,this.copySweepView.setId(t,null,0)),this.copySweepView}UpdateCopySweepNum(t){
null!=k.a.Inst_get().copySweepVo&&(k.a.Inst_get().copySweepVo.showLeftNum=t)}OpenCopyLeftTimeView(){if(null==this.copyLeftTimeView||0==this.copyLeftTimeView.isShow_get()){
const t=new s.v
t.positionType=f.$.eTop,t.aniDir=S.K.Up,n.N.inst.OpenById(l.I.CopyLeftTimePanel,this._degf_ShowCopyLeftTimeViewHandler,this._degf_DestroyCopyLeftTimeView,t)}}
DestroyCopyLeftTimeView(){_.g.DestroyUIObj(this.copyLeftTimeView),this.copyLeftTimeView=null}CloseCopyLeftTimeView(){
null!=this.copyLeftTimeView&&n.N.inst.ClosePanel(this.copyLeftTimeView)}ShowCopyLeftTimeViewHandler(t){return null==this.copyLeftTimeView&&(this.copyLeftTimeView=new Y.W,
this.copyLeftTimeView.setId(t,null,0)),this.copyLeftTimeView}OpenDunCopyTimer(){const t=new s.v
t.positionType=f.$.eTop,t.aniDir=S.K.Up,t.viewClass=U.W,n.N.inst.OpenById(l.I.RyDunBossTimer,null,null,t)}OpenCopyBloodTownLeftTimeView(){
if(null==this.copyBloodTownLeftTimeView||0==this.copyBloodTownLeftTimeView.isShow_get()){const t=new s.v
t.positionType=f.$.eTop,t.aniDir=S.K.Up,n.N.inst.OpenById(l.I.CopyBloodTownLeftTimePanel,null,null,t)}}DestroyCopyBloodTownLeftTimeView(){
_.g.DestroyUIObj(this.copyBloodTownLeftTimeView),this.copyBloodTownLeftTimeView=null}CloseCopyBloodTownLeftTimeView(){
null!=this.copyBloodTownLeftTimeView&&n.N.inst.ClosePanel(this.copyBloodTownLeftTimeView)}updateBloodTownLeftTime(t,e){
null!=this.copyBloodTownLeftTimeView?this.copyBloodTownLeftTimeView.SetCopyTimer(t):null!=e&&e&&this.OpenCopyBloodTownLeftTimeView()}ShowCopyBloodTownLeftTimeViewHandler(t){
return this.copyBloodTownLeftTimeView}OpenCopyBloodTownGainAwardView(){if(null==this.copyBloodtownGainAwardView||0==this.copyBloodtownGainAwardView.isShow_get()){const t=new s.v
t.positionType=f.$.eTop,t.aniDir=S.K.Up,n.N.inst.OpenById(l.I.CopyBloodTownGainAwardPanel,this._degf_ShowCopyBloodTownGainAwardViewHandler,this._degf_DestroyCopyBloodTownGainAwardView,t)
}}DestroyCopyBloodTownGainAwardView(){_.g.DestroyUIObj(this.copyBloodtownGainAwardView),this.copyBloodtownGainAwardView=null}CloseCopyBloodTownGainAwardView(){
null!=this.copyBloodtownGainAwardView&&n.N.inst.ClosePanel(this.copyBloodtownGainAwardView)}ShowCopyBloodTownGainAwardViewHandler(t){
return null==this.copyBloodtownGainAwardView&&(this.copyBloodtownGainAwardView=new j.U,this.copyBloodtownGainAwardView.setId(t,null,0)),this.copyBloodtownGainAwardView}
OpenNoRecoverPanel(){const t=new s.v
t.layerType=C.F.DefaultUI,n.N.inst.OpenById(l.I.CopyMapNoRecoverPanel,this._degf_ShowNoRecoverHandler,this._degf_DestroyNoRecoverPanel,t)}ShowNoRecoverHandler(t){
return null==this.noRecoverView&&(this.noRecoverView=new Tt,this.noRecoverView.setId(t,null,0)),this.noRecoverView}DestroyNoRecoverPanel(){
null!=this.exitView&&(_.g.DestroyUIObj(this.noRecoverView),this.noRecoverView=null)}CloseNoRecoverPanel(){null!=this.noRecoverView&&n.N.inst.ClosePanel(this.noRecoverView)}
SetData(e,i){null==i&&(i=!0),i&&this.CloseEnterCopyTimerPanel()
const s=_t.o.Inst().getItemById(e)
if(null==s)return
this.PreTimeOpenMsgPanel(),null!=this.copyLeftTimeView&&this.copyLeftTimeView.SetCopyTimer(e)
const n=ee.y.Inst.GetExitBtnView()
null!=n&&n.ShowLeftTime()
const l=k.a.Inst_get().copyEnterTimer
if(l.LuaDic_ContainsKey(s.controllerType)){const e=1e3*s.overTime,i=1e3*s.showTime,n=l[s.controllerType],a=g.D.serverMSTime_get()-n
let o=e-a
a>e&&(o=0,t.inst.CloseSoonEndTimeView()),o>e&&(o=e),0!=i&&o<=i&&(r.o.IsNullOrZero(k.a.Inst_get().exiTimer)&&(k.a.Inst_get().soonEndTime=n+e),t.inst.OpenSoonEndTimeView())}
ie.P.Inst.CheckTrigger(P.z.ENTER_COPY_BY_GROUPID_END_PRE,s.id)}GetEvaluatePic(t){let e="xuesechengbao_sp_"
return e+=0==t?"0005":1==t?"0006":2==t?"0007":3==t?"0008":"0005",e}SetMessageViewMonsterNum(t){}OpenCopySkyLandUIView(){if(null==this.copySkylandUIView){const t=new s.v
t.layerType=C.F.DefaultUI,t.positionType=f.$.eCustom,t.aniDir=S.K.Right3,n.N.inst.OpenById(l.I.SkylandCopyPanel,this._degf_ShowCopySkyLandUIViewHandler,this._degf_DestroyCopySkyLandUIViewHandler,t)
}}DestroyCopySkyLandUIViewHandler(){this.copySkylandUIView.Clear(),this.copySkylandUIView.Destroy(),_.g.DestroyUIObj(this.copySkylandUIView),this.DestroyCommonRightView(),
this.copySkylandUIView=null}CloseCopySkylandUIView(){null!=this.commonRightView?n.N.inst.CloseById(l.I.SkylandCopyPanel):n.N.inst.UnLoading(l.I.SkylandCopyPanel)}
ShowCopySkyLandUIViewHandler(t){if(this.InitCommonRightView(t),null==this.copySkylandUIView){const e=_.g.GetResFindId("ui_copybaseui_skylandpanel")
this.copySkylandUIView=new Bt,this.copySkylandUIView.setId(e,null,0),this.copySkylandUIView.node.transform.SetParent(this.commonRightView.moveContainer.FatherId,this.commonRightView.moveContainer.ComponentId),
q.I.calVec0.Set(-631,-49,0),this.copySkylandUIView.node.transform.SetLocalPosition(q.I.calVec0),this.copySkylandUIView.OnAddToScene(),this.commonRightView.InitTeamTipType(1),
n.N.inst.SetChildDepth(t,e),
this.commonRightView.SetData(this.copySkylandUIView.msgContainer,this.copySkylandUIView.teamContainer,this.copySkylandUIView.teamBtn,this.copySkylandUIView.taskBtn,this.copySkylandUIView.bgBtn,this.copySkylandUIView.teamColider,this.copySkylandUIView.taskColider,this.copySkylandUIView.taskSymbol,this.copySkylandUIView.teamSymbol),
this.commonRightView.AddToScene()}const e=V.R.Inst_get().msgdata
return null!=e&&null!=this.copySkylandUIView&&this.copySkylandUIView.refresh(e),this.commonRightView}OpenSlowDownTipView(){if(null==this.slowDownTipPanel){const t=new s.v
t.layerType=C.F.Alert,t.isShowMask=!0,n.N.inst.OpenById(l.I.SlowDownTipPanel,this._degf_ShowSlowDownTipPanelHandler,this._degf_DestroySlowDownTipPanelHandler,t)}}
DestroySlowDownTipPanelHandler(){this.slowDownTipPanel.Clear(),this.slowDownTipPanel.Destroy(),_.g.DestroyUIObj(this.slowDownTipPanel),this.slowDownTipPanel=null}
CloseSlowDownTip(){n.N.inst.CloseById(l.I.SlowDownTipPanel)}ShowSlowDownTipPanelHandler(t){return null==this.slowDownTipPanel&&(this.slowDownTipPanel=new Qt,
this.slowDownTipPanel.setId(t,null,0)),this.slowDownTipPanel}OpenSkyCountDownPanel(){if(null==this.skylandCountDownPanel){const t=new s.v
t.layerType=C.F.Alert,n.N.inst.OpenById(l.I.SkylandCountDownPanel,this._degf_ShowSkyCountDownPanelHandler,this._degf_DestroySkyCountDownPanelHandler,t)}}
DestroySkyCountDownPanelHandler(){this.skylandCountDownPanel.Clear(),this.skylandCountDownPanel.Destroy(),_.g.DestroyUIObj(this.skylandCountDownPanel),
this.skylandCountDownPanel=null}CloseSkyCountDownPanel(){n.N.inst.CloseById(l.I.SkylandCountDownPanel)}ShowSkyCountDownPanelHandler(t){
return null==this.skylandCountDownPanel&&(this.skylandCountDownPanel=new $t,this.skylandCountDownPanel.setId(t,null,0)),this.skylandCountDownPanel}OpenCopyQuentonSealUIView(){
if(null==this.copyQuentonSealUIView){const t=new s.v
t.layerType=C.F.DefaultUI,t.positionType=f.$.eCustom,t.aniDir=S.K.Right3,n.N.inst.OpenById(l.I.eQuentonCopyView,this._degf_ShowCopyQuentonSealUIViewHandler,this._degf_DestroyCopyQuentonSealUIViewHandler,t)
}}DestroyCopyQuentonSealUIViewHandler(){this.copyQuentonSealUIView.Clear(),this.copyQuentonSealUIView.Destroy(),_.g.DestroyUIObj(this.copyQuentonSealUIView),
this.DestroyCommonRightView(),this.copyQuentonSealUIView=null}CloseCopyQuentonSealUIView(){
null!=this.commonRightView?n.N.inst.CloseById(l.I.eQuentonCopyView):n.N.inst.UnLoading(l.I.eQuentonCopyView)}ShowCopyQuentonSealUIViewHandler(t){}OpenRyAllianceCopyBornFireView(){
if(n.N.inst.IsViewShowing(l.I.RyAllianceCopyBornFireView,!0))return
const t=new s.v
t.layerType=C.F.DefaultUI,t.viewClass=kt.p,n.N.inst.OpenById(l.I.RyAllianceCopyBornFireView,null,null,t)}CloseRyAllianceCopyBornFireView(){
n.N.inst.CloseById(l.I.RyAllianceCopyBornFireView)}OpenCommonSuccessView(){if(n.N.inst.IsViewShowing(l.I.CopySuccessPanel,!0))return
const t=new s.v
t.layerType=C.F.MainUI,t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!0,t.viewClass=st.k,n.N.inst.OpenById(l.I.CopySuccessPanel,null,null,t)}CloseCommonSuccessView(){
n.N.inst.CloseById(l.I.CopySuccessPanel)}},te.inst=null,ue=Jt=te,me="Inst_get",Ie=[a.n],ge=Object.getOwnPropertyDescriptor(Jt,"Inst_get"),_e=Jt,pe={},
Object.keys(ge).forEach((function(t){pe[t]=ge[t]})),pe.enumerable=!!pe.enumerable,pe.configurable=!!pe.configurable,("value"in pe||pe.initializer)&&(pe.writable=!0),
pe=Ie.slice().reverse().reduce((function(t,e){return e(ue,me,t)||t}),pe),_e&&void 0!==pe.initializer&&(pe.value=pe.initializer?pe.initializer.call(_e):void 0,
pe.initializer=void 0),void 0===pe.initializer&&(Object.defineProperty(ue,me,pe),pe=null),Jt)
var ue,me,Ie,ge,_e,pe},78967:(t,e,i)=>{i.d(e,{M:()=>c})
var s=i(38836),n=i(98800),l=i(98885),a=i(85602),o=i(38962),r=i(92984),h=i(75439),d=i(33138)
class c{constructor(){this.expMediceneIdArr=null,this.coverGroups=null,this.buyMallId=0,this.useExpItemId=0,this.expJobSkillDic=null,this.showWaveTime=0,this.coverGroups=new a.Z
let t=h.D.getInstance().getContent("ITEM:EXP_MEDICINE"),e=t.getContent().stringVal
this.expMediceneIdArr=l.M.Split(e,l.M.s_SPAN_CHAR)
let i=null,n=null,c=0,u=0
for(const[t,e]of(0,s.V5)(this.expMediceneIdArr))c=l.M.String2Int(e),i=d.f.Inst().getItemById(c),u=l.M.String2Int(i.Rewards_get().typevalues[0].value),
n=r.j.Inst_get().model.GetBuffResById(u),null==n||this.coverGroups.Contains(n.coverGroup)||this.coverGroups.Add(n.coverGroup)
this.expJobSkillDic=new o.X,t=h.D.getInstance().getContent("COPY:SHAKE_TIME"),e=t.getContent().stringVal,this.showWaveTime=l.M.String2Int(e)}static Inst_get(){
return null==c._inst&&(c._inst=new c),c._inst}GetExpSkillIdAndMallId(){const t=n.Y.Inst.PrimaryRoleInfo_get()
if(null!=t){if(this.expJobSkillDic.LuaDic_ContainsKey(t.Job_get()/1e3))return this.expJobSkillDic[t.Job_get()/1e3]}return null}}c._inst=null},26205:(t,e,i)=>{i.d(e,{o:()=>y})
var s=i(86133),n=i(50089),l=i(5924),a=i(99294),o=i(9986),r=i(6665),h=i(78287),d=i(93877),c=i(72005),u=i(61911),m=i(60130),I=i(98885),g=i(15965),_=i(75696),p=i(29839),C=i(75439),S=i(99535),f=i(33065)
class y extends u.f{constructor(){super(),this.desc=null,this.rewardGrid=null,this.scrollBar=null,this.normalConfirmBtn=null,this.roleImage=null,this.bgSp=null,
this.leftAnchor=null,this.rightAnchor=null,this.time=10,this.intervalId=-1,this.rushState=0,this.copyType=0,this.leftCount=0,this.hasClickRush=!1,this._degf_OnConfirmClick=null,
this._degf_OnGridReposition=null,this._degf_OnItemInit=null,this._degf_SetCountdown=null,this._degf_SetScrollBar=null,this._degf_OnConfirmClick=(t,e)=>this.OnConfirmClick(t,e),
this._degf_OnGridReposition=()=>this.OnGridReposition(),this._degf_OnItemInit=t=>this.OnItemInit(t),this._degf_SetCountdown=()=>this.SetCountdown(),
this._degf_SetScrollBar=()=>this.SetScrollBar()}InitView(){super.InitView(),this.desc=this.CreateComponent(d.Q,1),this.rewardGrid=this.CreateComponent(r.A,3),
this.scrollBar=this.CreateComponent(h._,4),this.normalConfirmBtn=this.CreateComponent(o.W,9),this.roleImage=this.CreateComponent(a.z,10),this.bgSp=this.CreateComponent(c.w,11),
this.leftAnchor=this.CreateComponent(a.z,12),this.rightAnchor=this.CreateComponent(a.z,13),this.rewardGrid.SetInitInfo("ui_baseitem",this._degf_OnItemInit),
this.rewardGrid.OnReposition_set(this._degf_OnGridReposition),this.bgSp.widthSet(n.t.GetUIWidth()),m.O.SetAnchorPos(this.leftAnchor,!0,!1,0,!1),
m.O.SetAnchorPos(this.rightAnchor,!1,!1,0,!1)}Clear(){this.RemoveLis(),this.intervalId=this.m_handlerMgr.ClearInterval(this.intervalId),super.Clear()}Destroy(){this.desc=null,
this.rewardGrid=null,this.scrollBar=null,this.normalConfirmBtn=null,this.roleImage=null,this.bgSp=null,this.leftAnchor=null,this.rightAnchor=null,super.Destroy()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.normalConfirmBtn,this._degf_OnConfirmClick)}RemoveLis(){this.m_handlerMgr.Clear()}OnConfirmClick(){p.p.inst.ExitCopy(),
f.x.Inst_get().CloseNormalSuccessView()}OnAddToScene(){super.OnAddToScene(),this.AddLis()
const t=g.V.Inst_Get().SM_SingleMonsterPanel
if(null==t)return
let e=C.D.getInstance().GetStringValue("ASURAM_QUEST:COPY_WIN")
e=I.M.Replace(e,"{0}",t.monsterName),this.desc.textSet(e)
const i=S.O.Inst_get().GetConfig(t.questId)
if(null!=i.showRewardResult_get()){const t=i.showRewardResult_get().GetRewardBaseItemList()
null!=t&&t.Count()>0&&this.rewardGrid.data_set(t)}this.time=15,this.SetCountdown(),this.intervalId=this.m_handlerMgr.SetInterval(this._degf_SetCountdown,1e3,-1)}SetCountdown(){
this.normalConfirmBtn.SetText(`${(0,s.T)("确定")}（${this.time+(0,s.T)("秒）")}`),this.time-=1,this.time<0&&(this.intervalId=this.m_handlerMgr.ClearInterval(this.intervalId),
p.p.inst.ExitCopy(),f.x.Inst_get().CloseNormalSuccessView())}OnItemInit(t){const e=new _.j
return e.setId(t,null,0),e}OnGridReposition(){l.C.Inst_get().CallLater(this._degf_SetScrollBar)}SetScrollBar(){
this.rewardGrid&&(this.rewardGrid.data_get().Count()>8?this.scrollBar.SetValue(0):this.scrollBar.SetValue(.5))}}},8231:(t,e,i)=>{
var s,n=i(6847),l=i(83908),a=i(49655),o=i(46282),r=i(97461),h=i(5924),d=i(60130),c=i(79534),u=i(75696),m=i(92679),I=i(85770),g=i(56632),_=i(86209),p=i(24524);(0,
n.s_)(a.o.CopyBelialUIPanel,o.Z.ui_copybaseui_belialpanel).register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),this._degf_OnRewardRefreshFun=null,
this.defaultPercent=.01,this.maxDelayTime=1e3,this.changeTime=40,this.m_data=null,this.curStage=null,this.curProgress=null,this.finalProgress=null,this.targetProgress=null,
this.changePercentId=null,this.addPercent=null}_initBinder(){super._initBinder(),this._degf_OnRewardRefreshFun=t=>this.OnRewardRefreshFun(t)}InitView(){super.InitView(),
this.grid.SetInitInfo("ui_baseitem",this._degf_OnRewardRefreshFun)}OnRewardRefreshFun(t){const e=t[0].getCNode(u.j)
return e.SetBgSize(60,60),e.SetIconSize(60,60),e}OnAddToScene(){d.O.SetAnchorPos(this.widget,!0,!1,0),this.m_data=null,this.Refresh(),this.AddLis()}AddLis(){
r.i.Inst.AddEventHandler(m.g.GET_EXP_MONSTER,this.CreateDelegate(this.RefreshExp))}RemoveLis(){
r.i.Inst.RemoveEventHandler(m.g.GET_EXP_MONSTER,this.CreateDelegate(this.RefreshExp)),this.lightSpotEff.RemoveEventHandler(this.CreateDelegate(this.PlayStageEff))}UpdateDoubleGo(){
const t=g.E.Inst_get().data
let e=!1
null!=t&&(e=t.isDouble),this.doubleIcon.SetActive(e)}RefreshExp(){const t=g.E.Inst_get().data
null==this.m_data?(this.expLbl.textSet("0"),this.monsterNumLbl.textSet("0")):(null!=t&&this.expLbl.textSet(_.w.Instance.ConvertNumToString(g.E.Inst_get().curGetExp)),
this.monsterNumLbl.textSet(this.m_data.killMonsterNum))}Refresh(){const t=g.E.Inst_get().msgdata
let e=!1
if(null==this.m_data&&(e=!0),this.m_data=t,e)this.RefreshPanel(!0)
else{if(null==t)return
this.RefreshPanel()}}RefreshPanel(t){const e=g.E.Inst_get().data
null==this.m_data?(this.expLbl.textSet("0"),this.monsterNumLbl.textSet("0")):(null!=e&&this.expLbl.textSet(_.w.Instance.ConvertNumToString(g.E.Inst_get().curGetExp)),
this.monsterNumLbl.textSet(this.m_data.killMonsterNum))
let i=0
t?this.RefreshStage(t):(i=this.m_data.curStage-this.curStage,this.curStage=this.m_data.curStage),this.RefreshNewRecord(),this.RefreshRewardItem(),this.RefreshProgress(t,i),
this.UpdateDoubleGo()}RefreshRewardItem(){g.E.Inst_get().itemMsgData
this.reward.SetActive(!1)}RefreshStage(t){if(t)null!=this.m_data?(this.curStage=this.m_data.curStage,this.PlayStageEff()):this.curStage=1,
this.curStageLbl.textSet(`第${this.curStage}波`)
else{this.curStage=this.m_data.curStage
const t=new c.P(86,0,0),e=new c.P(-143,-52,0)
this.lightSpotEff.node.SetActive(!0),this.lightSpotEff.AddEventHandler(this.CreateDelegate(this.PlayStageEff)),this.lightSpotEff.SetFrom(t),this.lightSpotEff.SetTo(e),
this.lightSpotEff.durationSet(1),this.lightSpotEff.SetIsEnabled(!0),this.lightSpotEff.ResetToBeginning(),this.lightSpotEff.PlayForward(),this.PlayStageEff()}}PlayStageEff(){
this.newStageAnim.replay(1),this.curStageLbl.textSet(`第${this.curStage}波`),this.lightSpotEff.node.SetActive(!1)}RefreshNewRecord(){const t=g.E.Inst_get().data
if(null==t)this.newRecord.SetActive(!1)
else if(!t.isDouble){const e=I.a.Inst_get().copyRecordDic,i=p.o.Inst().getItemById(I.a.Inst_get().currentCopyId)
let s=null
if(e.LuaDic_ContainsKey(i.controllerType)&&0!=t.beforeEnterHistoryTopExp.ToNum()){s=e[i.controllerType].historyTopExp,this.newRecord.SetActive(g.E.Inst_get().curGetExp>s.ToNum())}}
}RefreshProgress(t,e){if(t){null!=this.m_data?(this.curProgress=this.m_data.curStageNum/this.m_data.curStageTargetNum,this.finalProgress=this.curProgress,
this.targetProgress=this.curProgress):(this.curProgress=0,this.targetProgress=0,this.finalProgress=0),this.progressEff.SetActive(!0),
this.progressBar.node.transform.width=178*this.curProgress
const t=new c.P(173*this.curProgress-86,0,0)
this.progressEff.transform.SetLocalPosition(t),this.progressEff.SetActive(!0)}else{let t=!1,i=1
;-1!=this.m_data.curStageTargetNum&&(i=this.m_data.curStageNum/this.m_data.curStageTargetNum,t=!0)
const s=e+i-this.finalProgress
this.finalProgress=i,this.AddProgressByPercent(s,t),0==t&&e>0&&this.RefreshStage()}}AddProgressByPercent(t,e){if(e)this.targetProgress+=t,this.CalculateAddPercent(),
null==this.changePercentId&&(this.changePercentId=h.C.Inst_get().SetInterval(this.CreateDelegate(this.ChangePercentHandler),this.changeTime,-1))
else{this.ClearProgressAnim(),this.targetProgress=1,this.curProgress=1,this.progressBar.node.transform.width=178
const t=new c.P(86,0,0)
this.progressEff.transform.SetLocalPosition(t),this.progressEff.SetActive(!0)}}ClearProgressAnim(){null!=this.changePercentId&&(h.C.Inst_get().ClearInterval(this.changePercentId),
this.changePercentId=null)}ChangePercentHandler(){if(0==this.addPercent)this.ClearProgressAnim()
else{const t=this.GetCarryUnitNum(this.curProgress,this.addPercent)
if(this.curProgress>=this.targetProgress)return this.curProgress=this.targetProgress,void this.ClearProgressAnim()
this.curProgress+=this.addPercent
const e=this.GetDecimal(this.curProgress)
this.progressBar.node.transform.width=178*e
const i=new c.P(173*e-86-7,0,0)
this.progressEff.transform.SetLocalPosition(i),this.progressEff.SetActive(!0),t>0&&this.RefreshStage()}}GetDecimal(t){return t-Math.floor(t)}GetCarryUnitNum(t,e){
const i=Math.floor(t),s=t+e
return Math.floor(s)-i}CalculateAddPercent(){this.targetProgress<=this.curProgress?this.addPercent=0:(this.addPercent=this.defaultPercent,
this.curProgress+this.addPercent>this.targetProgress?this.addPercent=this.targetProgress-this.curProgress:this.curProgress+Math.floor(this.maxDelayTime/this.changeTime)*this.defaultPercent>this.targetProgress&&(this.addPercent=(this.targetProgress-this.curProgress)/Math.floor(this.maxDelayTime/this.changeTime)))
}Clear(){null!=this.grid&&this.grid.Clear(),this.ClearProgressAnim(),this.RemoveLis()}})},27007:(t,e,i)=>{
var s,n=i(6847),l=i(83908),a=i(46282),o=i(98800),r=i(97461),h=i(98958),d=i(5924),c=i(5494),u=i(60130),m=i(92679),I=i(87923),g=i(29839),_=i(70478),p=i(85770),C=i(44210),S=i(90912),f=i(86209),y=i(48933),w=i(24524),D=i(10509),T=i(47786),A=i(96713)
;(0,n.s_)(c.I.BloodTownTracePanel,a.Z.ui_copybase_bloodtownetrace).register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),this._model=null,this.isShowInfoView=!0,
this.isHide=!1,this.timer=-1,this.preTimer=0,this.curTimer=0,this.exitTimer=0,this.preStage=-1,this.preEvaluate=-1,this.isPlayPreEndAnim=!1,this._degf_FirstPanelStateHandler=null,
this._degf_HangClickHandler=null,this._degf_ProgressChangeHandler=null,this._degf_SetAnimStateHandler=null,this._degf_StartExit=null,this._degf_UpdateHangStatus=null}_initBinder(){
super._initBinder(),this._degf_FirstPanelStateHandler=t=>{},this._degf_HangClickHandler=(t,e)=>{},this._degf_ProgressChangeHandler=t=>this.ProgressChangeHandler(t),
this._degf_SetAnimStateHandler=t=>this.SetAnimStateHandler(t),this._degf_StartExit=()=>this.StartExit(),this._degf_UpdateHangStatus=t=>{}}InitView(){super.InitView()}
OnAddToScene(){u.O.SetAnchorPos(this.anchor,!0,!0,0),this.isHide=!1,this._model=C.w.GetInst(),this.UpdateAnchors(),this.TweenEndHandler(),this.AddEvents(),this.UpdateStatus(),
this.UpdateScore(),this.copyNameAnim.node.SetActive(!0),this.UpdateDoubleGo()}AddEvents(){this._model.AddEventHandler(S.s.PROGRESS_UPDATE,this._degf_ProgressChangeHandler),
this._model.AddEventHandler(S.s.EVALUATE_UPDATE,this._degf_ProgressChangeHandler),r.i.Inst.AddEventHandler(m.g.COPY_INFOPANEL_SHOWSTATE,this._degf_SetAnimStateHandler),
r.i.Inst.AddEventHandler(m.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors))}TweenEndHandler(t){this.isHide?(y.I.calVec3.x=-316,y.I.calVec3.y=4):(y.I.calVec3.x=0,
y.I.calVec3.y=4),this.outWidget.transform.SetLocalPosition(y.I.calVec3)}UpdateAnchors(t){}SetAnimStateHandler(t){this.isShowInfoView=t}ProgressChangeHandler(t){
this.UpdateStageStatus()}UpdateStageStatus(){const t=_._.GetInst().GetTargetDescribe()
this.copyProgressTxt.textSet(t),this.curStage.textSet(`${this._model.stage}[c9bb9c]/${C.w.STAGE_NUM}[-]`),this.NewProgress()}ClearTime(){d.C.Inst_get().ClearInterval(this.timer),
this.timer=-1}NewProgress(){this.UpdateStage(),g.p.inst.curstage==C.w.STAGE_NUM&&o.Y.Inst.SetOperateState(!1),
-1==this.timer&&(this.timer=d.C.Inst_get().SetInterval(this._degf_StartExit,50)),this.StartExit()}UpdateStage(){const t=w.o.Inst().getItemById(p.a.Inst_get().currentCopyId)
o.Y.Inst.m_primaryRoleInfo
let e=0
null!=C.w.GetInst().bloodTownData&&(e=C.w.GetInst().bloodTownData.oldLevel)
const i=D.L.Inst().getItemById(e)
let s=t.GetRewardExpByStage(g.p.inst.curstage)
if(0==g.p.inst.curstage)return void this.stageTxt.textSet("")
let n=0
if(null!=i&&null!=i.bloodTownRatioList&&i.bloodTownRatioList.Count()>0){const t=i.bloodTownRatioList
t.Count()>1&&(n=t[1])}if(s>0){let t=0
if(1==g.p.inst.curstage?t=115500:2==g.p.inst.curstage?t=115501:3==g.p.inst.curstage?t=115502:4==g.p.inst.curstage?t=115503:5==g.p.inst.curstage?t=115504:7==g.p.inst.curstage&&(t=115506),
s*=n,t>0){let e=T.x.Inst().getItemStr2ById(t)
e=h.V.Inst().replaceLangParamOne(e,`${I.l.GetRuleDecimalVal(s)}`),this.stageTxt.textSet(e)}
}else g.p.inst.curstage==C.w.STAGE_NUM-1?this.stageTxt.textSet(T.x.Inst().getItemStr2ById(115505)):this.stageTxt.textSet("")}UpdateDoubleGo(){let t=!1
null!=C.w.GetInst().bloodTownData&&(t=C.w.GetInst().bloodTownData.isDouble),this.doubleIcon.SetActive(t)}StartExit(){this.node&&this.RefreshUI()}RefreshUI(){
if(this.exitTimer=p.a.Inst.GetCopyLeftTime(),this.exitTimer<=0||g.p.inst.curstage==C.w.STAGE_NUM)A.n.inst.CloseCopyBloodTownLeftTimeView()
else{const t=I.l.GetMSRadomEnd2(this.exitTimer)
A.n.inst.updateBloodTownLeftTime(t,C.w.GetInst().IsInAddExTimeStage())}this.preStage=this._model.stage,this.UpdateDoubleGo()}UpdateScore(){if(null!=C.w.GetInst().bloodTownData){
const t=p.a.Inst_get().copyRecordDic,e=w.o.Inst().getItemById(p.a.Inst_get().currentCopyId)
let i=null
if(t.LuaDic_ContainsKey(e.controllerType)&&!C.w.GetInst().bloodTownData.isDouble){i=t[e.controllerType].historyTopExp,
i.ToNum()>0?this.newRecord.SetActive(C.w.GetInst().bloodTownData.exp.ToNum()>i.ToNum()):this.newRecord.SetActive(!1)}this.UpdateStage(),
this.expLab.textSet(f.w.Instance.ConvertNumToString(C.w.GetInst().bloodTownData.exp.ToNum()))}else this.expLab.textSet(0)}UpdateStatus(){this.UpdateStageStatus()}RemoveList(){
this._model.RemoveEventHandler(S.s.PROGRESS_UPDATE,this._degf_ProgressChangeHandler),this._model.RemoveEventHandler(S.s.EVALUATE_UPDATE,this._degf_ProgressChangeHandler),
C.w.GetInst().RemoveEventHandler(S.s.PROGRESS_UPDATE,this._degf_ProgressChangeHandler),r.i.Inst.RemoveEventHandler(m.g.COPY_INFOPANEL_SHOWSTATE,this._degf_SetAnimStateHandler),
r.i.Inst.RemoveEventHandler(m.g.UITweenStateChanged,this._degf_FirstPanelStateHandler),r.i.Inst.RemoveEventHandler(m.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors))}
Clear(){this.RemoveList(),null!=A.n.inst.commonRightView&&A.n.inst.commonRightView.Clear(),this.ClearTime()}Destroy(){}})},96165:(t,e,i)=>{
var s,n=i(6847),l=i(83908),a=i(46282),o=i(68662),r=i(41664),h=i(5924),d=i(5494),c=i(35128),u=i(98885),m=i(85770),I=i(72800),g=i(24524),_=i(96713);(0,
n.s_)(d.I.EnterCopyTime,a.Z.ui_copybaseui_copyentertimer).register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),this.timer=-1,this.enterTimer=0,
this.frontServerTime=0,this.closeTimer=-1,this.timeNumAni=6,this.timeSpGoAni=17,this.preShowTime=-1,this.hideTimer=-1,this.hideFrameCount=0,this._degf_ShowHideAnimHandler=null,
this._degf_StartEnter=null,this.copyItem=null}_initBinder(){super._initBinder(),this._degf_ShowHideAnimHandler=()=>this.ShowHideAnimHandler(),
this._degf_StartEnter=()=>this.StartEnter()}InitView(){this.goEffect.SetActive(!1)}AnimEnding(){this.icon.SetActive(!1),_.n.inst.CloseEnterCopyTimerPanel()}OnAddToScene(){
this.SetData(m.a.Inst_get().currentCopyId)}Clear(){-1!=this.timer&&h.C.Inst_get().ClearInterval(this.timer),this.ClearHideTimer(),this.ClearCloseTimer(),this.ClearAnimData(),
m.a.Inst_get().isCopyTip=!0,m.a.Inst_get().isSiegeTip=!1,m.a.Inst_get().isArenaTip=!1,m.a.Inst_get().isInEnterTime=!1}SetData(t){h.C.Inst_get().ClearInterval(this.timer),
this.timer=-1,
this.ClearHideTimer(),this.copyItem=g.o.Inst().getItemById(t),null!=this.copyItem&&(this.copyItem.preTime<=0&&this.copyItem.controllerType!=I.S.KUNDUN_SEAL?_.n.inst.SetData(m.a.Inst_get().currentCopyId):(this.frontServerTime=o.D.serverMSTime_get(),
this.copyItem.controllerType!=I.S.KUNDUN_SEAL?this.enterTimer=m.a.Inst_get().GetOkStartTime(this.copyItem.id)-this.frontServerTime:this.enterTimer=5e3,
this.enterTimer<=0?_.n.inst.SetData(m.a.Inst_get().currentCopyId):(this.enterTimer>=1e3*this.copyItem.preTime&&this.copyItem.controllerType!=I.S.KUNDUN_SEAL&&(this.enterTimer=1e3*this.copyItem.preTime),
this.PlayAnim())))}PlayAnim(){const t=m.a.Inst_get()
t.isCopyTip=!t.isSiegeTip&&!t.isArenaTip,this.copyTip.SetActive(t.isCopyTip),this.activityTip.SetActive(t.isSiegeTip),this.obj_arenaSp.SetActive(t.isArenaTip),t.isInEnterTime=!0,
this.StartAnim()}StartAnim(){-1==this.timer&&(this.showAnim.node.SetActive(!0),this.timer=h.C.Inst_get().SetInterval(this._degf_StartEnter,200),this.StartEnter())}StartEnter(){
const t=o.D.serverMSTime_get()
this.enterTimer-=t-this.frontServerTime,m.a.Inst.preEnterTimer=this.enterTimer,this.frontServerTime=t
const e=c.p.CeilToInt(this.enterTimer/1e3)
e>9?(this.doubleNum.node.SetActive(!0),this.oneNum.node.SetActive(!1),this.doubleNum.textSet(u.M.IntToString(e))):(this.oneNum.node.SetActive(!0),this.doubleNum.node.SetActive(!1),
this.oneNum.textSet(u.M.IntToString(e))),this.enterTimer<=300?(h.C.Inst_get().ClearInterval(this.timer),this.timer=-1,m.a.Inst_get().isInEnterTime=!1,
_.n.inst.SetData(m.a.Inst_get().currentCopyId,!1),this.oneNum.node.SetActive(!1),this.doubleNum.node.SetActive(!1),this.icon.SetActive(!1),this.goEffect.SetActive(!0),
this.goEffect.replay(1),
-1==this.closeTimer&&(this.closeTimer=h.C.Inst_get().SetFrameLoop(this._degf_ShowHideAnimHandler,800,this.timeNumAni+this.timeSpGoAni))):this.preShowTime!=e&&0!=e&&(e<=5&&this.scaleAnim.node.SetActive(!0),
this.preShowTime=e,r.j.Inst.PlayByDivision("CopyStartTime"))}ShowHideAnimHandler(){this.hideFrameCount+=1,6==this.hideFrameCount&&(this.goEffect.SetActive(!0),
this.goEffect.replay(1)),
this.hideFrameCount==this.timeNumAni?this.closeAnim.node.SetActive(!0):this.hideFrameCount==this.timeNumAni+1?this.hideAnim.node.SetActive(!0):this.hideFrameCount==this.timeNumAni+this.timeSpGoAni&&(this.AnimEnding(),
this.ClearHideTimer(),this.ClearCloseTimer())}ClearHideTimer(){h.C.Inst_get().ClearLoop(this.hideTimer),this.hideTimer=-1,this.hideFrameCount=0}ClearAnimData(){
this.closeAnim.node.SetActive(!1)}ClearCloseTimer(){h.C.Inst_get().ClearLoop(this.closeTimer),this.closeTimer=-1}Destroy(){}})},58306:(t,e,i)=>{i.d(e,{F:()=>I})
var s,n=i(18998),l=i(83908),a=i(38045),o=i(28192),r=i(15965),h=i(92679),d=i(85770),c=i(72800)
const{ccclass:u,property:m}=n._decorator
let I=u("RyAllianceBossAssistLeftTimeView")(s=class extends((0,l.Ri)()){constructor(...t){super(...t),this._m_handlerMgr=null,this.isAssistOther=!1}get m_handlerMgr(){
return this._m_handlerMgr||(this._m_handlerMgr=o.h.Get()),this._m_handlerMgr}InitView(){super.InitView()}Clear(){super.Clear()}SetData(t){
this.m_handlerMgr.AddEventMgr(h.g.ALLIANCE_ASSIT_LEFTTIME,this.CreateDelegate(this.Refresh)),this.isAssistOther=d.a.Inst_get().IsAssistOther,this.anchor.SetLocalPositionXYZ(0,t,0),
this.Refresh()}Refresh(){const t=d.a.Inst_get().curCopyType
if(this.SetActive(!1),t==c.S.JigsawBoss&&this.isAssistOther){this.SetActive(!0)
const t=r.V.Inst_Get().LeftAssistTime
this.Decs.textSet(`今日协助奖励剩余次数：${(0,a.tw)(t)}`)}}Test1(){return!0}S_Test(){return!0}})||s},4958:(t,e,i)=>{i.d(e,{p:()=>G})
var s,n,l=i(6847),a=i(83908),o=i(46282),r=i(98800),h=i(91238),d=i(36241),c=i(68662),u=i(5924),m=i(61911),I=i(5494),g=i(60130),_=i(79534),p=i(62346),C=i(43076),S=i(53905),f=i(92679),y=i(85751),w=i(87923),D=i(65772),T=i(78417),A=i(84708),v=i(48933),L=i(57035),M=i(37648),b=i(55492),R=i(75439),P=i(845)
let G=(0,l.s_)(I.I.RyAllianceCopyBornFireView,o.Z.ui_alliancecopy_bornfire_ry).register()((n=class t extends((0,a.pA)(m.f)()){constructor(...t){super(...t),this.UpdateTimer=null,
this.SubmitFireBtnIsShow=!1,this._lefttimeintervalId=-1,this._lefttime=0,this._degf_OnFindPathEnd=null}static __StaticInit(){t.chatWifiSetting=P.g.Inst_get().chatWifiSetting,
t.chat4gSetting=P.g.Inst_get().chat4gSetting}_initBinder(){super._initBinder(),this._degf_OnFindPathEnd=t=>this.OnFindPathEnd()}InitView(){super.InitView()}OnAddToScene(){
this.m_handlerMgr.AddClickEvent(this.submitBtn.node,this.CreateDelegate(this.OnSubmitClick)),
this.m_handlerMgr.AddClickEvent(this.expAddTipBtn.node,this.CreateDelegate(this.OnExpAddTipClick)),
this.m_handlerMgr.AddClickEvent(this.submitFireItemBtn,this.CreateDelegate(this.OnOpenSubmitPanel)),
this.m_handlerMgr.AddClickEvent(this.questionBtn.node,this.CreateDelegate(this.OnOpenQuestionPanel)),
this.m_handlerMgr.AddEventMgr(f.g.RYALLIANCE_BOREFIRE_UPDATE,this.CreateDelegate(this.Refresh)),
this.m_handlerMgr.AddEventMgr(f.g.RYALLIANCE_REFRESHEXP,this.CreateDelegate(this.RefreshExpInfo)),
this.m_handlerMgr.AddEventMgr(f.g.RYALLIANCE_SHOWHIDE_SUBMITPANEL,this.CreateDelegate(this.ShowHideSubmitPanel)),
this.m_handlerMgr.AddEventMgr(f.g.FUNCTION_OPEN,this.CreateDelegate(this.OnFunctionOpen)),
this.m_handlerMgr.AddEventMgr(f.g.QUESTIONINFO_CHANGE,this.CreateDelegate(this.UpdateQuestionInfo)),this.Refresh(),
this.UpdateTimer||(this.UpdateTimer=u.C.Inst_get().SetInterval(this.CreateDelegate(this.RefreshLeftTime),1e3,-1)),this.SubmitFireBtnIsShow=!0,this.ShowHideSubmitFireBtn(!1),
this.UpdateQuestionInfo(),this.SetAnchorPos()}UpdateQuestionInfo(){const t=R.D.getInstance().GetIntValue("ASURAMASK_MAX"),e=C.w.Inst_get().curstage_get()
if(u.C.Inst_get().ClearInterval(this._lefttimeintervalId),this._lefttimeintervalId=-1,e==p.o.eQuestioning){this.effect.SetActive(!0)
const e=C.w.Inst_get().info_get()
if(null==e)return
this.questionLabel.textSet(`[5FB470]${e.questionProgress}/${t}[-]`)}else if(e==p.o.eQuestioncmp)this.effect.SetActive(!1),this.questionLabel.textSet(`[5FB470]${t}/${t}[-]`)
else{this.effect.SetActive(!1)
const t=C.w.Inst_get().startTime-c.D.serverTime_get()
this.showLeftOpenTime(t)}}showLeftOpenTime(t){this._lefttime=t
const e=w.l.GetDateFormatEX(this._lefttime,!1)
this.questionLabel.textSet(`${y.u.BrightGreenColorStr2}${e}[-]后开启`),-1!=this._lefttimeintervalId&&(u.C.Inst_get().ClearInterval(this._lefttimeintervalId),
this._lefttimeintervalId=-1),this._lefttimeintervalId=u.C.Inst_get().SetInterval(this.CreateDelegate(this.TimeChange),1e3)}TimeChange(){let t=""
this._lefttime-=1,this._lefttime<1&&(u.C.Inst_get().ClearInterval(this._lefttimeintervalId),this._lefttimeintervalId=-1),t=w.l.GetDateFormatEX(this._lefttime,!1),
this.questionLabel.textSet(`${y.u.BrightGreenColorStr2}${t}[-]后开启`)}Refresh(){T.L.GetInst().IsBornFireActivityOpen()?this.RefreshLeftTime():this.anchor.node.SetActive(!1)
const t=M.P.Inst_get().IsFunctionOpened(b.x.ASURAM_BORNFIRE),e=L.d.Inst_get().getItemById(b.x.ASURAM_BORNFIRE)
t?(this.limitLbl.textSet(""),this.submitBtn.node.SetActive(!0),this.questionBtn.SetActive(!0)):(this.submitBtn.node.SetActive(!1),this.limitLbl.textSet(`${e.showLevel}级后可参与烤火`),
this.questionBtn.SetActive(!1)),this.RefreshExpInfo()}OnExpAddTipClick(){const t=new S.w
t.position=new _.P(-450,120,0),t.width=450,t.infoId="ASURAMWAR:PARTY",D.Q.Inst_get().Open(t)}OnFunctionOpen(t){t==b.x.ASURAM_BORNFIRE&&this.Refresh()}OnOpenSubmitPanel(){
T.L.GetInst().OpenSubmitFireItemView()}OnOpenQuestionPanel(){T.L.GetInst().OpenQuestionView()}OnSubmitClick(){d._.getInst().endHang()
const t=r.Y.Inst.PrimaryRole_get()
t.GetCurPos(v.I.calVec0)
let e=T.L.GetInst().BornFirePos.Clone()
e=w.l.GetPosBetweenTwoPos(e,v.I.calVec0,4.5,6)
t.StopPathingByForce(!0),t.gotoPoint(e,h.m.Point,this._degf_OnFindPathEnd,null,null,.5)}OnFindPathEnd(){T.L.GetInst().OpenSubmitFireItemView()}ShowHideSubmitPanel(t){
this.anchor.node.SetActive(!t),this.submitFireRoot.node.SetActive(!t)}RefreshExpInfo(){const t=A.H.Inst_get().FireAllExp_get()
let e=null,i=null,s="",n=0,l=0
t?(s=w.l.GetRuleDecimalVal(t.exp.ToNum(),2),n=t.upLevel,l=t.upRate):l=A.H.Inst_get().ClientAddExpRate_get(),e=`[5FB470]${s}[-]`,n>0&&(e+=`(已升${n}级)`),i=`${Math.floor(l/100)}%`,
this.expAddTotal.textSet(e),this.expAdd.textSet(`[5FB470]${i}[-]`)}RefreshLeftTime(){if(A.H.Inst_get().BornFireOpen){let t=A.H.Inst_get().BornFireLeftTime_get()
t<0&&(t=0),t=Math.floor(t+.5)
const e=w.l.GetDateFormatEX(t)
this.timeName.textSet("剩余时间："),this.time.textSet(`[5FB470]${e}[-]`)}else{let t=A.H.Inst_get().SubmitFireLeftTime_get()
t=Math.floor(t+.5)
const e=w.l.GetDateFormatEX(t)
this.timeName.textSet("开始时间："),this.time.textSet(`[5FB470]${e}[-]后开始`)}}SetAnchorPos(){g.O.SetAnchorPos(this.anchor,!0,!0,0,!1)}ShowHideSubmitFireBtn(t){
this.SubmitFireBtnIsShow!=t&&(this.SubmitFireBtnIsShow=t,this.submitFireItemBtn.SetActive(t))}Clear(){P.g.Inst_get().chatWifiSetting=t.chatWifiSetting,
P.g.Inst_get().chat4gSetting=t.chat4gSetting,u.C.Inst_get().ClearInterval(this._lefttimeintervalId),this._lefttimeintervalId=-1,super.Clear(),
this.UpdateTimer&&(u.C.Inst_get().ClearInterval(this.UpdateTimer),this.UpdateTimer=null)
const e=r.Y.Inst.PrimaryRole_get()
e&&e.StopPathingByForce(!0)}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}},n.chatWifiSetting=null,n.chat4gSetting=null,s=n))||s},73814:(t,e,i)=>{i.d(e,{T:()=>I})
var s,n=i(6847),l=i(83908),a=i(46282),o=i(5924),r=i(61911),h=i(5494),d=i(98130),c=i(79534),u=i(92679),m=i(84708)
let I=(0,n.s_)(h.I.RyAllianceCopyChuanGongView,a.Z.ui_alliancecopy_chuangong_ry).register()(s=class extends((0,l.pA)(r.f)()){constructor(...t){super(...t),this.calVec=null,
this.UpdateTimer=null,this.prencent=0,this.Duration=19.2,this.tmpTime=null}_initBinder(){super._initBinder(),this.calVec=new c.P(0,0,0)}InitView(){super.InitView()}OnAddToScene(){
m.H.Inst_get().IsChuanGongNotMinXiang_get(),this.name.textSet("传功中"),this.m_handlerMgr.AddClickEvent(this.Btn.node,this.CreateDelegate(this.OnChuanGongClick)),
this.m_handlerMgr.AddEventMgr(u.g.RYALLIANCE_CHUANGONG_UPDATE,this.CreateDelegate(this.Refresh)),this.prencent=0,this.ClearTimer(),
this.UpdateTimer=o.C.Inst_get().SetFrameLoop(this.CreateDelegate(this.Refresh),0,-1),this.tmpTime=d.GF.m_fCurFrameBeginTime}Refresh(){const t=d.GF.m_fCurFrameBeginTime-this.tmpTime
this.tmpTime=d.GF.m_fCurFrameBeginTime,this.prencent+=t/this.Duration,this.prencent>=1&&(this.prencent=1,this.ClearTimer()),this.calVec.z=-360*this.prencent,
this.progress.fillRange=-1*this.prencent,this.center.transform.SetRotate(this.calVec)}OnChuanGongClick(){}ClearTimer(){
this.UpdateTimer&&(o.C.Inst_get().ClearInterval(this.UpdateTimer),this.UpdateTimer=null)}Clear(){super.Clear(),this.ClearTimer()}Destroy(){super.Destroy(),this.ClearTimer()}
Test1(){return!0}S_Test(){return!0}})||s},12195:(t,e,i)=>{
var s,n=i(6847),l=i(83908),a=i(46282),o=i(98800),r=i(5924),h=i(5494),d=i(79534),c=i(75696),u=i(86605),m=i(29839),I=i(85770),g=i(86209),_=i(24524),p=i(10509),C=i(21267),S=i(77191),f=i(41864)
;(0,n.s_)(h.I.BelialResultPanel,a.Z.ui_copybaseui_belialsquareresult_ry).register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),this._degf_AnimTimer=null,
this.addPercent=.1,this.TimerId=null,this.time=null,this.value=null,this.addTime=null,this.numLab=null,this.levelup=null,this.isDouble=null,this.oldExp=null,this.oldLevel=null,
this.newExp=null,this.newLevel=null,this.allExp=null,this.curTime=null,this.animId=null,this.maxLevel=null,this.newRecordId=null}_initBinder(){super._initBinder(),
this._degf_AnimTimer=()=>{this.RefreshExpProgress()}}InitView(){super.InitView(),this.TimerId=-1,this.time=-1,this.grid.SetInitInfo("ui_baseitem",null,c.j)}OnAddToScene(){
this.newRecordScale.node.SetActive(!1),this.newRecordEff.node.SetActive(!1),this.doubleAnim.node.SetActive(!1),this.addPercent=.1,this.value=0,this.addTime=0,
this.UpdateDoubleInfo(),1==I.a.Inst_get().copyEndState?(this.successView.SetActive(!0),this.failView.SetActive(!1),this.ShowNextExpInfo()):(this.successView.SetActive(!1),
this.failView.SetActive(!0),this.expView.node.SetActive(!1)),this.UpdateView(),this.AddEvent()}UpdateView(){const t=I.a.Inst_get().GetCurCopyRes()
null!=t&&(this.time=t.escTime-5),this.time>0&&-1==this.TimerId&&(this.TimerId=r.C.Inst_get().SetInterval(this.CreateDelegate(this.DownTimeHandler),1e3),this.DownTimeHandler())
const e=m.p.inst.copyReward
null!=e?(this.killMonsterNum.textSet(`累计击退：${e.killMonsterNum}`),this.expLab.textSet(g.w.Instance.ConvertNumToString(e.displayExp.ToNum())),this.InitExpProgress(),
this.reward.SetActive(!1)):(this.expLab.textSet("0"),this.reward.SetActive(!1))}UpdateDoubleInfo(){this.stampIcon.node.SetActive(!0)
let t=!1
const e=m.p.inst.copyReward
null!=e&&(t=e.isDouble),t?(this.isDouble=!0,this.stampIcon.node.SetActive(!1)):this.isDouble=!1,this.stampIcon.MakePixelPerfect()}GetRealExp(){
let t=m.p.inst.copyReward.displayExp.ToNum()
return this.isDouble&&(t/=2),t}InitExpProgress(){const t=m.p.inst.copyReward
this.oldExp=t.beforeCopyExp.ToNum(),this.oldLevel=t.oldLevel,this.newExp=o.Y.Inst.PrimaryRoleInfo_get().Exp_get().ToNum(),this.newLevel=o.Y.Inst.PrimaryRoleInfo_get().Level_get(),
this.CalculateMaxLevel(this.oldLevel),this.value=this.oldExp/this.GetLevelUpExpByLevel(this.oldLevel),
this.allExp=this.GetExpByLevel(this.newLevel,this.oldLevel)+this.newExp-this.oldExp,this.CalculatePercentByTime(3e3)
const e=this.oldExp/this.GetLevelUpExpByLevel(this.oldLevel)
this.RefreshProgress(e,!0),this.curTime<=0&&(this.levelProgress.fillAmountSet(this.newExp/this.GetLevelUpExpByLevel(this.oldLevel)),this.RefreshNewRecord()),
this.animId=r.C.Inst_get().SetInterval(this._degf_AnimTimer,40,this.curTime)}CalculateMaxLevel(t){const e=f.h.GetRebirthLevel(t)
this.maxLevel=S.g.ins.GetVoByRebirthLevel(e).gtlevelList[1]}ShowNextExpInfo(){
const t=m.p.inst.copyReward,e=_.o.Inst().getItemById(t.copyId),i=_.o.Inst().getItemsByCopyHierarchy(e.controllerType,e.hierarchy+1)[0]
if(null!=i){const t=i.checkPointConLis.typevalues[0].value
this.nextLevelTip.textSet(`${C.u.Inst().totalPassNum}/${t}`),this.levelLabel.textSet(`第${i.hierarchy}层`),
this.expLabel.textSet(`${Math.floor(100*(i.expGrowRate/e.expGrowRate-1)+.5)}%`)}else this.expView.node.SetActive(!1)}CalculatePercentByTime(t){
let e=0,i=this.oldExp,s=this.oldLevel,n=this.allExp,l=this.GetLevelUpExpByLevel(this.oldLevel),a=l*this.addPercent
for(;n>0&&(n>=a||n>0&&(a=n),!(n<=0));)if(e+=1,n-=a,a+i>=l){if(i=a+i-l,s+=1,s>this.maxLevel)break
l=this.GetLevelUpExpByLevel(s),a=l*this.addPercent}else i=a+i
const o=Math.floor(t/40)
e>o?(this.addPercent=Math.floor(this.addPercent*e/o*100+.5)/100,this.curTime=o):this.curTime=e}GetExpByLevel(t,e){let i=0
if(t<=e)return i
for(let s=e;s<=t-1;s++)i+=this.GetLevelUpExpByLevel(s)
return i}RefreshExpProgress(){if(this.addTime+=1,this.value+this.addPercent>=2){const t=Math.floor(this.value+this.addPercent)
this.oldLevel+t<=this.newLevel?this.oldLevel+=t:this.oldLevel=this.newLevel,this.value=this.value+this.addPercent-t
}else this.value+this.addPercent>=1?(this.value=this.value+this.addPercent-1,this.oldLevel+1<=this.newLevel&&(this.oldLevel+=1)):this.value+=this.addPercent
if(this.addTime>=this.curTime){const t=this.newExp/this.GetLevelUpExpByLevel(this.oldLevel)
this.RefreshProgress(t,!1),this.RefreshNewRecord()}else this.RefreshProgress(this.value,!0)}RefreshProgress(t,e){const i=m.p.inst.copyReward,s=f.h.GetLevelStr(i.oldLevel)
if(t>1&&(t=1),this.levelProgress.fillAmountSet(t),e){this.expEffect.SetActive(!0)
const e=new d.P(298*t-149,1,0)
this.expEffect.transform.SetLocalPosition(e),this.expEffect.SetActive(!1),this.level.textSet(`角色等级：${s}`),this.arrow.SetActive(!1),this.level2.textSet("")
}else if(this.expEffect.SetActive(!1),this.level.textSet(`角色等级：${s}`),i.oldLevel==this.oldLevel)this.arrow.SetActive(!1),this.level2.textSet("")
else{const t=f.h.GetLevelStr(this.oldLevel)
this.arrow.SetActive(!0),this.level2.textSet(t),this.levelTable.Reposition()}}ClearAnim(){-1!=this.animId&&(r.C.Inst_get().ClearInterval(this.animId),this.animId=-1,
this.expEffect.SetActive(!1))}GetLevelUpExpByLevel(t){return p.L.Inst().getItemById(t).exp}RefreshNewRecord(){this.expEffect.SetActive(!1)
const t=m.p.inst.copyReward
this.newRecord.SetActive(!1)
let e=this.newRecordEff
const i=this.GetRealExp()
let s=!1
this.isDouble?(e=this.doubleAnim,s=!0):i>t.oldHistoryTopExp.ToNum()&&(0==t.oldHistoryTopExp.ToNum()?this.expNewRecord.textSet(""):s=!0),s&&(this.expNewRecord.textSet(""),
e.node.SetActive(!0),e.replay(1),this.newRecordScale.node.SetActive(!1),this.isDouble||(this.newRecordId=r.C.Inst_get().SetInterval(this.CreateDelegate(this.PlayNewRecord),800,1)))
}PlayNewRecord(){this.newRecordScale.node.SetActive(!0)
const t=new d.P(3,3,1),e=new d.P(1,1,1)
this.newRecordScale.SetFrom(t),this.newRecordScale.SetTo(e),this.newRecordScale.ResetToBeginning(),this.newRecordScale.durationSet(.1),this.newRecordScale.Play(),
this.newRecord.SetActive(!0)}PlayNewRecordHandle(){let t=0
const e=m.p.inst.copyReward
null!=e&&(t=(e.displayExp.ToNum()-e.oldHistoryTopExp.ToNum())/e.oldHistoryTopExp.ToNum(),t>0?(t=Math.floor(1e4*t)/100,
this.expNewRecord.textSet(`经验比上次提升了${t}%`)):this.expNewRecord.textSet(""))}AddEvent(){this.AddClickEvent(this.exitBtn.node,this.CreateDelegate(this.ExitHandler)),
this.newRecordScale.AddEventHandler(this.CreateDelegate(this.PlayNewRecordHandle))}RemoveEvent(){r.C.Inst_get().ClearInterval(this.TimerId),this.TimerId=-1,
this.RemoveClickEvent(this.exitBtn.node,this.CreateDelegate(this.ExitHandler)),this.newRecordScale.RemoveEventHandler(this.CreateDelegate(this.PlayNewRecordHandle))}
DownTimeHandler(){this.time<=0?this.ExitHandler():(this.exitLab.textSet(`离开副本（${this.time}）`),this.time-=1)}ExitHandler(){u.z.Inst_get().CloseResultView(),m.p.inst.ExitCopy()}
Clear(){super.Clear(),this.grid.Clear(),this.ClearAnim(),null!=this.newRecordId&&(r.C.Inst_get().ClearInterval(this.newRecordId),this.newRecordId=null),this.RemoveEvent(),
this.time=-1}Destroy(){}})},65504:(t,e,i)=>{
var s,n=i(18998),l=i(6847),a=i(83908),o=i(46282),r=i(98800),h=i(5924),d=i(5494),c=i(60130),u=i(79534),m=i(92679),I=i(29839),g=i(70478),_=i(85770),p=i(44210),C=i(86209),S=i(24524),f=i(10509),y=i(21267),w=i(77191),D=i(41864)
;(0,l.s_)(d.I.BloodTownResultPanel,o.Z.ui_copybase_bloodtownresult_ry).register()(s=class extends((0,a.Ri)()){constructor(...t){super(...t),this._degf_AnimTimer=null,
this.addPercent=.1,this.TimerId=null,this.value=null,this.addTime=null,this.time=null,this.rewardMsg=null,this.isDouble=null,this.oldExp=null,this.oldLevel=null,this.newExp=null,
this.newLevel=null,this.allExp=null,this.curTime=null,this.animId=null,this.maxLevel=null,this.newRecordId=null}_initBinder(){super._initBinder(),this._degf_AnimTimer=()=>{
this.RefreshExpProgress()}}InitView(){super.InitView(),this.TimerId=-1}OnAddToScene(){this.addPercent=.1,this.value=0,this.addTime=0,this.newRecordEff.node.SetActive(!1),
this.newRecordScale.node.SetActive(!1),this.doubleAnim.node.SetActive(!1),this.UpdateDoubleInfo(),2!=_.a.Inst_get().copyEndState?(this.successView.SetActive(!0),
this.failView.SetActive(!1),this.ShowNextExpInfo()):(this.successView.SetActive(!1),this.failView.SetActive(!0),this.expView.node.SetActive(!1)),this.UpdateView(),this.AddEvent()}
UpdateAnchors(){c.O.SetAnchorPos(this.leftAnchor,!0,!0,0),this.bg.widthSet(c.O.GetUIWidth())}UpdateView(){const t=_.a.Inst_get().GetCurCopyRes()
null!=t&&(this.time=t.escTime-5),this.time>0&&-1==this.TimerId&&(this.TimerId=h.C.Inst_get().SetInterval(this.CreateDelegate(this.DownTimeHandler),1e3),this.DownTimeHandler())
const e=p.w.GetInst().rewardMsg
null!=e&&(this.rewardMsg=e,this.scoreLab.textSet(`血色积分: ${e.teamScore}`),this.killMonsterNum.textSet(`击败怪物: ${e.killMonsterCount}`),
this.expLab.textSet(C.w.Instance.ConvertNumToString(e.expReward.ToNum())),this.InitExpProgress())}UpdateDoubleInfo(){this.stampIcon.node.SetActive(!0)
const t=p.w.GetInst().rewardMsg
let e=!1
null!=t&&(e=t.isDouble),e?(this.isDouble=!0,this.stampIcon.node.SetActive(!1)):(this.isDouble=!1,this.stampIcon.spriteNameSet("ryresult_sp_0024"))}GetRealExp(){
let t=p.w.GetInst().rewardMsg.expReward.ToNum()
return this.isDouble&&(t/=2),t}InitExpProgress(){const t=p.w.GetInst().rewardMsg
this.oldExp=t.beforeCopyExp.ToNum(),this.oldLevel=t.oldLevel,this.newExp=r.Y.Inst.PrimaryRoleInfo_get().Exp_get().ToNum(),this.newLevel=r.Y.Inst.PrimaryRoleInfo_get().Level_get(),
this.CalculateMaxLevel(this.oldLevel),this.value=this.oldExp/this.GetLevelUpExpByLevel(this.oldLevel),
this.allExp=this.GetExpByLevel(this.newLevel,this.oldLevel)+this.newExp-this.oldExp,this.CalculatePercentByTime(3e3)
const e=this.oldExp/this.GetLevelUpExpByLevel(this.oldLevel)
this.RefreshProgress(e,!0),this.curTime<=0&&(this.levelProgress.fillRange=this.newExp/this.GetLevelUpExpByLevel(this.oldLevel),this.RefreshNewRecord()),
this.animId=h.C.Inst_get().SetInterval(this._degf_AnimTimer,40,this.curTime)}CalculateMaxLevel(t){const e=D.h.GetRebirthLevel(t)
this.maxLevel=w.g.ins.GetVoByRebirthLevel(e).gtlevelList[1]}CalculatePercentByTime(t){
let e=0,i=this.oldExp,s=this.oldLevel,n=this.allExp,l=this.GetLevelUpExpByLevel(this.oldLevel),a=l*this.addPercent
for(;n>0&&(n>=a||n>0&&(a=n),!(n<=0));)if(e+=1,n-=a,a+i>=l){if(i=a+i-l,s+=1,s>this.maxLevel)break
l=this.GetLevelUpExpByLevel(s),a=l*this.addPercent}else i=a+i
const o=Math.floor(t/40)
e>o?(this.addPercent=Math.floor(this.addPercent*e/o*100+.5)/100,this.curTime=o):this.curTime=e}GetExpByLevel(t,e){let i=0
if(t<=e)return i
for(let s=e;s<=t-1;s++)i+=this.GetLevelUpExpByLevel(s)
return i}RefreshExpProgress(){if(this.addTime+=1,this.value+this.addPercent>=2){const t=Math.floor(this.value+this.addPercent)
this.oldLevel+t<=this.newLevel?this.oldLevel+=t:this.oldLevel=this.newLevel,this.value=this.value+this.addPercent-t
}else this.value+this.addPercent>=1?(this.value=this.value+this.addPercent-1,this.oldLevel+1<=this.newLevel&&(this.oldLevel+=1)):this.value+=this.addPercent
if(this.addTime>=this.curTime){const t=this.newExp/this.GetLevelUpExpByLevel(this.oldLevel)
this.RefreshProgress(t,!1),this.RefreshNewRecord()}else this.RefreshProgress(this.value,!0)}RefreshProgress(t,e){const i=p.w.GetInst().rewardMsg,s=D.h.GetLevelStr(i.oldLevel)
if(t>1&&(t=1),this.levelProgress.fillRange=t,e){this.expEffect.SetActive(!0)
const e=new u.P(298*t-149,1,0)
this.expEffect.transform.SetLocalPosition(e),this.expEffect.SetActive(!1),this.level.textSet(`角色等级：${s}`),this.arrow.SetActive(!1),this.level2.textSet("")
}else if(this.expEffect.SetActive(!1),this.level.textSet(`角色等级：${s}`),i.oldLevel==this.oldLevel)this.arrow.SetActive(!1),this.level2.textSet("")
else{const t=D.h.GetLevelStr(this.oldLevel)
this.arrow.SetActive(!0),this.level2.textSet(t),this.levelTable.Reposition()}}ClearAnim(){-1!=this.animId&&(h.C.Inst_get().ClearInterval(this.animId),this.animId=-1,
this.expEffect.SetActive(!1))}GetLevelUpExpByLevel(t){return f.L.Inst().getItemById(t).exp}RefreshNewRecord(){this.expEffect.SetActive(!1)
const t=p.w.GetInst().rewardMsg
this.newRecord.SetActive(!1)
const e=this.GetRealExp()
let i=this.newRecordEff,s=!1
this.isDouble?(i=this.doubleAnim,s=!0):e>t.historyTopExp.ToNum()&&(0==t.historyTopExp.ToNum()?this.expNewRecord.textSet(""):s=!0),s&&(i.node.SetActive(!0),
this.newRecordScale.node.SetActive(!1),this.expNewRecord.textSet(""),this.isDouble||(this.newRecordId=h.C.Inst_get().SetInterval(this.CreateDelegate(this.PlayNewRecord),800,1)))}
PlayNewRecord(){this.newRecordScale.node.SetActive(!0)
const t=new n.Vec3(3,3,1),e=new n.Vec3(1,1,1)
this.newRecordScale.SetFrom(t),this.newRecordScale.SetTo(e),this.newRecordScale.ResetToBeginning(),this.newRecordScale.durationSet(.1),this.newRecordScale.Play(),
this.newRecord.SetActive(!0)}PlayNewRecordHandle(){let t=0
const e=p.w.GetInst().rewardMsg
null!=e&&(t=(e.expReward.ToNum()-e.historyTopExp.ToNum())/e.historyTopExp.ToNum(),t>0?(t=Math.floor(100*t),t<1&&(t=1),
this.expNewRecord.textSet(`经验比上次提升了${t}%`)):this.expNewRecord.textSet(""))}ShowNextExpInfo(){
const t=p.w.GetInst().rewardMsg,e=S.o.Inst().getItemById(t.copyId),i=S.o.Inst().getItemsByCopyHierarchy(e.controllerType,e.hierarchy+1)[0]
if(null!=i){const t=i.checkPointConLis.typevalues[0].value
this.nextLevelTip.textSet(`${y.u.Inst().totalPassNum}/${t}`),this.levelLabel.textSet(`第${i.hierarchy}层`),
this.expLabel.textSet(`${Math.floor(100*(i.expGrowRate/e.expGrowRate-1)+.5)}%`),this.expView.Reposition()}else this.expView.node.SetActive(!1)}AddEvent(){
this.m_handlerMgr.AddEventMgr(m.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors)),this.AddClickEvent(this.exitBtn.node,this.CreateDelegate(this.ExitHandler)),
this.newRecordScale.AddEventHandler(this.CreateDelegate(this.PlayNewRecordHandle))}RemoveEvent(){h.C.Inst_get().ClearInterval(this.TimerId),this.TimerId=-1,
this.RemoveClickEvent(this.exitBtn.node,this.CreateDelegate(this.ExitHandler)),this.newRecordScale.RemoveEventHandler(this.CreateDelegate(this.PlayNewRecordHandle))}
DownTimeHandler(){this.time<0?this.ExitHandler():(this.exitLab.textSet(`离开副本（${this.time}）`),this.time-=1)}ExitHandler(){g._.GetInst().CloseResultView(),I.p.inst.ExitCopy()}
Clear(){super.Clear(),null!=this.newRecordId&&(h.C.Inst_get().ClearInterval(this.newRecordId),this.newRecordId=null),this.RemoveEvent(),this.ClearAnim(),this.time=-1}Destroy(){}})
},59307:(t,e,i)=>{i.d(e,{q:()=>s})
var s={GOLD:1,GOLD_DIAMOND:2,BLUE_DIAMOND:3,BIND_DIAMOND:4,HONOUR:5,SKILL_POINT:6,CONSIGN_SCORE:7,VITALITY_NUM:13,ASURAM_CONTRIBUTION:14,REPUTATION_POINT:15,SUIT_ITEM_SCORE:16,
ASURAM_TOKEN:17,HONOUR_POINT:18,HONOURSHOP_POINT:19,TREASURES:21}},91970:(t,e,i)=>{i.d(e,{I:()=>qt})
var s=i(97461),n=i(56937),l=i(18202),a=i(31222),o=i(5494),r=i(52726),h=i(92679),d=i(37648),c=i(55492),u=i(65550),m=i(38836),I=i(98800),g=i(16812),_=i(62370),p=i(98885),C=i(85602),S=i(38962),f=i(75439)
class y{}y.Daily=0,y.Challenge=1,y.TimeTask=2
class w extends g.k{constructor(){super(),this.isfrist=!1,this.curPIdx=null,this.curRInfo=null,this.curTabIdx=y.Daily,this.defTabIdx=y.Daily,this.mulroleOpen=null,
this.collectOpen=null,this.collectnum=null,this.currVersion=-1,this.level=0,this.MaxLevel=0,this.GetAwardLevels=null,this.exp=null,this.buyTimes=null,this.RewardDatas=null,
this.ChallFollows=null,this.GainRewDic=null,this.mulroleOpen=new C.Z,this.collectOpen=new C.Z,this.collectnum=new C.Z,this.RewardDatas=new C.Z,this.ChallFollows=new C.Z,
this.GainRewDic=new S.X,this.InitLit()}static Inst_get(){return null==w._Inst&&(w._Inst=new w),w._Inst}ResetModel(){this.ChallFollows.Clear()}UpdateSelectRoleInfo(t){
this.curPIdx=t,this.curRInfo=I.Y.Inst.GetMultiPlayerInfoByCreateIdx(t)}GetNextOpen(t,e){if(e){
for(let e=0;e<=this.mulroleOpen.count_get()-1;e++)if(t<this.mulroleOpen[e]+1)return this.mulroleOpen[e]
}else for(let e=0;e<=this.collectOpen.count_get()-1;e++)if(t<this.collectOpen[e]+1)return this.collectOpen[e]
return 0}GetShopItemBuy(t){return this.buyTimes.LuaDic_ContainsKey(t)?this.buyTimes[t]:-1}InitLit(){
let t=f.D.getInstance().GetStringValue("MANUAL:ROLE_OPEN"),e=p.M.Split(t,p.M.s_CCD_CHAR_DOT)
for(const[t,i]of(0,m.V5)(e)){const t=p.M.Split(e,_.o.s_Arr_UNDER_CHAR_DOT)
let e=p.M.String2Int(t[0])
this.mulroleOpen.Add(e)}t=f.D.getInstance().GetStringValue("MANUAL:EQUIP_COLLECT_OPEN"),e=p.M.Split(t,p.M.s_CCD_CHAR_DOT)
for(const[t,i]of(0,m.V5)(e)){const t=p.M.Split(e,_.o.s_Arr_UNDER_CHAR_DOT)
let e=p.M.String2Int(t[0])
this.collectOpen.Add(e)}}IsGetReward(t){return null!=this.GetAwardLevels&&this.GetAwardLevels.Contains(t)}IsFollow(t){return!!this.ChallFollows.Contains(t)}}w._Inst=null,
w.ManualTaskId=40001
var D=i(9986),T=i(6665),A=i(57834),v=i(61911),L=i(99864)
let M=null,b=null,R=null,P=null,G=null,O=null,E=null,B=null,k=null,x=null,V=null,N=null,H=null,U=null,F=null,j=null,Y=null,z=null,q=null,Z=null,K=null,$=null,W=null,X=null,Q=null,J=null,tt=null,et=null,it=null,st=null,nt=null,lt=null,at=null
class ot extends v.f{constructor(...t){super(...t),this.OkBtn=null,this.CloseBtn=null,this.Grid=null}static __StaticInit(){M=table.insert,b=table.sort,R=table.remove,P=C.Z.new,
G=C.Z.Add,O=C.Z.AddRang,E=C.Z.Clear,B=C.Z.Contains,k=C.Z.Insert,x=C.Z.InsertRange,V=C.Z.Remove,N=C.Z.RemoveAt,H=C.Z.IndexOf,U=C.Z.Count,F=C.Z.Length,j=C.Z.RemoveRange,
Y=C.Z.GetRange,z=C.Z.Pop,q=C.Z.Reverse,Z=C.Z.Sort,K=S.X.new,$=S.X.LuaDic_Add,W=S.X.LuaDic_SetItem,X=S.X.LuaDic_IsNullValue,Q=S.X.LuaDic_GetItem,J=S.X.LuaDic_Count,
tt=S.X.LuaDic_ContainsKey,et=S.X.LuaDic_AddOrSetItem,it=S.X.LuaDic_Keys,st=S.X.LuaDic_Values,nt=S.X.LuaDic_Clear,lt=S.X.LuaDic_ContainsValue,at=S.X.LuaDic_Remove}InitView(){
super.InitView(),this.OkBtn=this.CreateComponent(D.W,1),this.CloseBtn=this.CreateComponent(D.W,2),this.Grid=this.CreateComponent(T.A,3),
this.Grid.SetInitInfo("ui_bag_baseitem",this.CreateDelegate(this.OnItemRefreshFun))}OnAddToScene(){this.addOrRemoveLis(!0)
const t=new C.Z
this.Grid.data_set(t)}addOrRemoveLis(t){(t=t||!1)?(A.i.Get(this.OkBtn.node).RegistonClick(this.CreateDelegate(this.CloseView)),
A.i.Get(this.CloseBtn.node).RegistonClick(this.CreateDelegate(this.CloseView))):(A.i.Get(this.OkBtn.node).RemoveonClick(this.CreateDelegate(this.CloseView)),
A.i.Get(this.CloseBtn.node).RemoveonClick(this.CreateDelegate(this.CloseView)))}CloseView(){qt.Inst_get().CloseGainRewPanel()}OnItemRefreshFun(t){const e=new L.P
return e.setId(t,null,0),e}Clear(){this.Grid.Clear(),this.addOrRemoveLis(),super.Clear()}Destroy(){this.Grid.Destroy(),this.OkBtn=null,this.CloseBtn=null,this.Grid=null,
super.Destroy()}}var rt=i(93877),ht=i(87923)
let dt=null,ct=null,ut=null,mt=null,It=null,gt=null,_t=null,pt=null,Ct=null,St=null,ft=null,yt=null,wt=null,Dt=null,Tt=null,At=null,vt=null,Lt=null,Mt=null,bt=null,Rt=null,Pt=null,Gt=null,Ot=null,Et=null,Bt=null,kt=null,xt=null,Vt=null,Nt=null,Ht=null,Ut=null,Ft=null
class jt extends v.f{constructor(...t){super(...t),this.isrole=!1,this.OkBtn=null,this.CloseBtn=null,this.Lab=null}static __StaticInit(){dt=table.insert,ct=table.sort,
ut=table.remove,mt=C.Z.new,It=C.Z.Add,gt=C.Z.AddRang,_t=C.Z.Clear,pt=C.Z.Contains,Ct=C.Z.Insert,St=C.Z.InsertRange,ft=C.Z.Remove,yt=C.Z.RemoveAt,wt=C.Z.IndexOf,Dt=C.Z.Count,
Tt=C.Z.Length,At=C.Z.RemoveRange,vt=C.Z.GetRange,Lt=C.Z.Pop,Mt=C.Z.Reverse,bt=C.Z.Sort,Rt=S.X.new,Pt=S.X.LuaDic_Add,Gt=S.X.LuaDic_SetItem,Ot=S.X.LuaDic_IsNullValue,
Et=S.X.LuaDic_GetItem,Bt=S.X.LuaDic_Count,kt=S.X.LuaDic_ContainsKey,xt=S.X.LuaDic_AddOrSetItem,Vt=S.X.LuaDic_Keys,Nt=S.X.LuaDic_Values,Ht=S.X.LuaDic_Clear,
Ut=S.X.LuaDic_ContainsValue,Ft=S.X.LuaDic_Remove}InitView(){super.InitView(),this.OkBtn=this.CreateComponent(D.W,1),this.CloseBtn=this.CreateComponent(D.W,2),
this.Lab=this.CreateComponent(rt.Q,3)}updataview(t,e){this.addOrremoveLis(!1),this.addOrremoveLis(!0),this.isrole=t,t?(this.Lab.textSet(`第${ht.l.getNumStr(e)}角色`),
qt.Inst_get().openRoleIndexs.Remove(e)):(this.Lab.textSet(`${e}阶装备收藏`),qt.Inst_get().openCollectStage.Remove(e))}addOrremoveLis(t){
(t=t||!1)?(A.i.Get(this.OkBtn.node).RegistonClick(this.CreateDelegate(this.GotoView)),
A.i.Get(this.CloseBtn.node).RegistonClick(this.CreateDelegate(this.CloseView))):(A.i.Get(this.OkBtn.node).RemoveonClick(this.CreateDelegate(this.GotoView)),
A.i.Get(this.CloseBtn.node).RemoveonClick(this.CreateDelegate(this.CloseView)))}CloseView(){qt.Inst_get().CloseFuncOpen(!1)}GotoView(){qt.Inst_get().CloseFuncOpen(!0,this.isrole)}
Clear(){this.addOrremoveLis(),super.Clear()}Destroy(){this.OkBtn=null,this.CloseBtn=null,this.Lab=null,super.Destroy()}}class Yt{}Yt.Award=0,Yt.Task=1,Yt.ExChange=2,Yt.COLLECT=3
class zt extends v.f{constructor(){super(),this._degf_OnClickColse=null,this._degf_OnTabClick=null,this._degf_OnClickColse=(t,e)=>this.OnClickColse(t,e),
this._degf_OnTabClick=(t,e)=>this.OnTabClick(t,e)}InitView(){}OnAddToScene(){super.OnAddToScene()}UpdateView(){}Clear(){}Destroy(){super.Destroy()}AddLis(){
this.m_handlerMgr.AddEventMgr(h.g.STRENGTHEN_PANEL_CLOSE,this._degf_OnClickColse)}RemoveLis(){}OnClickColse(t,e){qt.Inst_get().Close()}OnTabClick(t,e){}ShowTypeView(t){}
EffShow(t,e){}}zt.tabIds=new C.Z([Yt.Award,Yt.Task,Yt.ExChange,Yt.COLLECT])
class qt{constructor(){this.view=null,this.viewContainer=null,this.GainRewPanel=null,this.funcopenview=null,this.openRoleIndexs=null,this.openCollectStage=null,
this._degf_OnGainRewPanelDestroyHandler=null,this._degf_OnGainRewPanelLoadComplete=null,this._degf_OnFuncOpenDestroyHandler=null,this._degf_OnFuncOpenLoadComplete=null,
this._degf_FunctionOpenHandle=null,this.registeProtocol(),this._degf_OnGainRewPanelDestroyHandler=()=>this.OnGainRewPanelDestroyHandler(),
this._degf_OnGainRewPanelLoadComplete=t=>this.OnGainRewPanelLoadComplete(t),this._degf_OnFuncOpenDestroyHandler=()=>this.OnFuncOpenDestroyHandler(),
this._degf_OnFuncOpenLoadComplete=t=>this.OnFuncOpenLoadComplete(t),this._degf_FunctionOpenHandle=t=>this.FunctionOpenHandle(t)}static Inst_get(){
return null==qt._Inst&&(qt._Inst=new qt),qt._Inst}registeProtocol(){s.i.Inst.AddEventHandler(h.g.FUNCTION_OPEN,this._degf_FunctionOpenHandle)}FunctionOpenHandle(t){
t==c.x.MANUAL&&(w.Inst_get().isfrist=!0)}Get_View(){return this.view}Open(t){if(t=t||y.Daily,d.P.Inst_get().IsFunctionOpened(c.x.DAILY))if(w.Inst_get().defTabIdx=t,
null!=this.view&&this.view.isShow_get())this.view.UpdateView()
else{const t=new n.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!1,a.N.inst.OpenById(o.I.ManualPanel,this.CreateDelegate(this.OnViewLoadComplete),this.CreateDelegate(this.OnDestroyHandler),t)
}else u.y.inst.ClientSysMessage(100514)}Close(){null!=this.view&&a.N.inst.ClosePanel(this.view)}OpenGainRewPanel(){
if(null!=this.GainRewPanel&&this.GainRewPanel.isShow_get())this.GainRewPanel.OnAddToScene()
else{const t=new n.v
t.layerType=r.F.Tip,t.isShowMask=!0,a.N.inst.OpenById(o.I.ManualGainRewPanel,this._degf_OnGainRewPanelLoadComplete,this._degf_OnGainRewPanelDestroyHandler,t)}}CloseGainRewPanel(){
null!=this.GainRewPanel&&a.N.inst.ClosePanel(this.GainRewPanel)}OpenFuncOpenPanel(t,e){if(null!=this.funcopenview&&this.funcopenview.isShow_get())this.funcopenview.OnAddToScene(),
this.funcopenview.updataview(t,e)
else{const t=new n.v
t.layerType=r.F.Tip,t.isShowMask=!0,a.N.inst.OpenById(o.I.ManualFuncOpen,this._degf_OnFuncOpenLoadComplete,this._degf_OnFuncOpenDestroyHandler,t)}}CloseFuncOpen(t,e){
null!=this.funcopenview&&a.N.inst.ClosePanel(this.funcopenview)}OnViewLoadComplete(t){return null==this.view&&(this.view=new zt,this.view.setId(t,null,0),
this.view.isExclusionPanel=!0),this.view}OnGainRewPanelLoadComplete(t){return null==this.GainRewPanel&&(this.GainRewPanel=new ot,this.GainRewPanel.setId(t,null,0)),
this.GainRewPanel}OnFuncOpenLoadComplete(t){return null==this.funcopenview&&(this.funcopenview=new jt,this.funcopenview.setId(t,null,0)),
0!=this.openRoleIndexs.Count()?this.funcopenview.updataview(!0,this.openRoleIndexs[0]):0!=this.openCollectStage.Count()&&this.funcopenview.updataview(!1,this.openCollectStage[0]),
this.funcopenview}OnDestroyHandler(){l.g.DestroyUIObj(this.view),this.view=null}OnGainRewPanelDestroyHandler(){l.g.DestroyUIObj(this.GainRewPanel),this.GainRewPanel=null}
OnFuncOpenDestroyHandler(){l.g.DestroyUIObj(this.funcopenview),this.funcopenview=null}}qt._Inst=null},89427:(t,e,i)=>{i.d(e,{X:()=>$})
var s=i(66788),n=i(85682),l=i(98885),a=i(85602),o=i(38962),r=i(48933),h=i(43308),d=i(79878),c=i(62783),u=i(88934),m=i(22046),I=i(12417),g=i(91970)
let _=null,p=null,C=null,S=null,f=null,y=null,w=null,D=null,T=null,A=null,v=null,L=null,M=null,b=null,R=null,P=null,G=null,O=null,E=null,B=null,k=null,x=null,V=null,N=null,H=null,U=null,F=null,j=null,Y=null,z=null,q=null,Z=null,K=null
class ${static __StaticInit(){_=table.insert,p=table.sort,C=table.remove,S=a.Z.new,f=a.Z.Add,y=a.Z.AddRang,w=a.Z.Clear,D=a.Z.Contains,T=a.Z.Insert,A=a.Z.InsertRange,v=a.Z.Remove,
L=a.Z.RemoveAt,M=a.Z.IndexOf,b=a.Z.Count,R=a.Z.Length,P=a.Z.RemoveRange,G=a.Z.GetRange,O=a.Z.Pop,E=a.Z.Reverse,B=a.Z.Sort,k=o.X.new,x=o.X.LuaDic_Add,V=o.X.LuaDic_SetItem,
N=o.X.LuaDic_IsNullValue,H=o.X.LuaDic_GetItem,U=o.X.LuaDic_Count,F=o.X.LuaDic_ContainsKey,j=o.X.LuaDic_AddOrSetItem,Y=o.X.LuaDic_Keys,z=o.X.LuaDic_Values,q=o.X.LuaDic_Clear,
Z=o.X.LuaDic_ContainsValue,K=o.X.LuaDic_Remove}static DOGo(t){t&&(d.Y.GetLinkInfo(t),INS.uIShowShortCut.CheckFuncOpen(t.GetTargetOpenUI())&&g.I.Inst_get().Close(),
d.Y.DoGoTaskStep(t))}DoOpenAccess(t){r.I.calVec0.Set(0,0,0),h._.Inst_get().OpenByWay(t,r.I.calVec0)}static DoOpenShortCut(t){if(t[1]==n.D.NowMap){const e=l.M.String2Int(t[2])
c.X.inst.OpenMapPanelByMansterSpawnId(e)}else if(t[1]==n.D.Boss){const e=I._.Inst().GetBossId4WBAB(m.l.WORLDBOSS),i=l.M.String2Int(t[2])
;(e-i>=900||i-e>=900)&&s.Y.LogError(`检查goUI配置,世界boss配置的ID ${t[2]} 和推荐的ID相差900以上`),e>=i?u.$.Inst().OpenByType(m.l.WORLDBOSS,e):u.$.Inst().OpenByType(m.l.WORLDBOSS,i)
}else s.Y.LogError(`检查goUI配置,特殊参数配置的UIID ${t[1]} 没有做特殊处理`)}}},65625:(t,e,i)=>{i.d(e,{s:()=>I})
var s=i(32076),n=i(86133),l=i(5924),a=i(18202),o=i(31222),r=i(5494),h=i(22662),d=i(65550),c=i(93877),u=i(61911)
class m extends u.f{constructor(){super(),this.text=null,this.timer=-1,this._degf_StarAnimHandler=null,this._degf_StarAnimHandler=()=>this.StarAnimHandler()}InitView(){
this.text=new c.Q,this.text.setId(this.FatherId,this.FatherComponentID,1),super.InitView()}OnAddToScene(){I.GetInst().PlayEffect()}SetData(t){0==t?this.text.textSet((0,
n.T)("进入安全区")):1==t&&this.text.textSet((0,n.T)("离开安全区")),this.ClearTime(),-1==this.timer&&(this.timer=l.C.Inst_get().SetInterval(this._degf_StarAnimHandler,2e3,1))}
StarAnimHandler(){this.ClearTime(),I.GetInst().Close()}ClearTime(){l.C.Inst_get().ClearInterval(this.timer),this.timer=-1}Clear(){this.ClearTime()}Destroy(){this.text=null}}
class I{constructor(){this.view=null,this.InitedItem=!1,this.flag=0,this._needShowFlag=-1,this._showFlagTimerId=0,this._degf_CreateHandler=null,this._degf_DestroyHandler=null,
this._degf_CreateHandler=t=>this.CreateHandler(t),this._degf_DestroyHandler=()=>this.DestroyHandler()}static GetInst(){return null==I._inst&&(I._inst=new I),I._inst}InitItem(){
o.N.inst.OpenById(r.I.MapAreaTips,this._degf_CreateHandler,this._degf_DestroyHandler)}DestroyHandler(){a.g.DestroyUIObj(this.view),this.view=null}CreateHandler(t){
return null==this.view&&(this.view=new m,this.view.setId(t,null,0)),this.InitedItem=!0,this.view}Close(){null!=this.view&&this.view.node.SetActive(!1)}start(t){this.flag=t,
this._showFlagTimerId=l.C.Inst_get().ClearInterval(this._showFlagTimerId),this._showFlagTimerId=l.C.Inst_get().SetInterval((0,s.v)(this._ShowFlagDelay,this),500,1)}
_ShowFlagDelay(){this.flag!=this._needShowFlag&&(this._needShowFlag=this.flag,0==this.flag?d.y.inst.ClientStrMsg(h.r.SystemTipMessage,(0,
n.T)("进入安全区")):1==this.flag&&d.y.inst.ClientStrMsg(h.r.SystemTipMessage,(0,n.T)("离开安全区")))}PlayEffect(){null!=this.view&&(this.view.SetData(this.flag),this.view.node.SetActive(!0))
}}I._inst=null},20028:(t,e,i)=>{i.d(e,{a:()=>o})
var s,n=i(18998),l=i(83908),a=i(5924)
let o=n._decorator.ccclass("MapPassEffView")(s=class extends((0,l.Ri)()){constructor(...t){super(...t),this.interval=void 0,this.interval1=void 0}InitView(){super.InitView()}
OnAddToScene(){a.C.Inst_get().ClearInterval(this.interval),a.C.Inst_get().ClearInterval(this.interval1),
this.interval=this.m_handlerMgr.SetInterval(this.CreateDelegate(this.playEffect),0,1),this.interval1=this.m_handlerMgr.SetInterval(this.CreateDelegate(this.onPlayEnd),2200,1)}
playEffect(){this.guankaBossNode.SetActive(!0)}onPlayEnd(){this.guankaBossNode.SetActive(!1)}Destroy(){}})||s},1746:(t,e,i)=>{i.d(e,{b:()=>o})
var s,n=i(18998),l=i(83908),a=i(5924)
let o=n._decorator.ccclass("MapPassEnterEffVIew")(s=class extends((0,l.Ri)()){constructor(...t){super(...t),this.interval=void 0,this.interval1=void 0}InitView(){super.InitView()}
OnAddToScene(){a.C.Inst_get().ClearInterval(this.interval),a.C.Inst_get().ClearInterval(this.interval1),
this.interval=this.m_handlerMgr.SetInterval(this.CreateDelegate(this.playEffect),0,1),this.interval1=this.m_handlerMgr.SetInterval(this.CreateDelegate(this.onPlayEnd),2200,1)}
playEffect(){this.guankaEnterBossNode.SetActive(!0)}onPlayEnd(){this.guankaEnterBossNode.SetActive(!1)}Destroy(){}})||s},70204:(t,e,i)=>{i.d(e,{d:()=>c})
var s,n=i(6847),l=i(83908),a=i(46282),o=i(70829),r=i(80156),h=i(92679),d=i(49655)
let c=(0,n.s_)(d.o.MapPassAlertPanel,a.Z.ui_map_pass_alert_ry).register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),this.tweenFill=null}InitView(){super.InitView(),
this.tweenFill=this.tweenFill1.getComponent(r.E),this.anchor.SetActive(!1)}OnAddToScene(){this.m_handlerMgr.AddEventMgr(h.g.SKILL_ALERT,this.CreateDelegate(this.AddSkillAlert)),
this.tweenFill.AddEventHandler(this.CreateDelegate(this.OnAnimFinished1))}AddSkillAlert(t){this.anchor.SetActive(!0)
const e=t.skillId
this.tweenFill.duration=t.alertTime/1e3,this.tweenFill.ResetToBeginning(),this.tweenFill.PlayForward()
const i=o.j.Inst().GetSkillByStrId(e).showDesc
let s="ryditu_sp_0089",n="ryditu_sp_0090"
"1"==i.type?(s="ryditu_sp_0089",n="ryditu_sp_0090"):"2"==i.type?(s="ryditu_sp_0091",n="ryditu_sp_0092"):"3"==i.type?(s="ryditu_sp_0093",
n="ryditu_sp_0094"):"4"==i.type?(s="ryditu_sp_0095",n="ryditu_sp_0096"):"5"==i.type?(s="ryditu_sp_0097",n="ryditu_sp_0098"):"6"==i.type&&(s="ryditu_sp_0099",n="ryditu_sp_0100"),
this.bg.spriteNameSet("preload:/atlas/ditu/"+s),this.sliderBg.spriteNameSet("preload:/atlas/ditu/"+n),this.alertLabel.textSet(i.content)}OnAnimFinished1(){this.anchor.SetActive(!1)
}Clear(){this.tweenFill.RemoveEventHandler(this.CreateDelegate(this.OnAnimFinished1)),super.Clear()}Destroy(){this.tweenFill=null,super.destroy()}Test1(){return!0}S_Test(){return!0
}})||s},16279:(t,e,i)=>{var s,n=i(18998),l=i(83908),a=i(5924),o=i(51868),r=i(87923),h=i(61546)
const{ccclass:d}=n._decorator
d("MapPassBtnGoldHangTips")(s=class extends((0,l.pA)(o.$)()){constructor(...t){super(...t),this.timeIntervalId=null}InitView(){super.InitView(),
this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.Hide))}Clear(){super.Clear()}Destroy(){super.destroy()}UpdateExp(){
const t=r.l.SetStringColor("5fb470",`${r.l.GetRuleDecimalVal(h.X.Inst_get().hangExp,2)} /分`)
this.tipsLabel.textSet(t)}Show(){null!=this.timeIntervalId&&a.C.Inst_get().ClearLoop(this.timeIntervalId),
this.timeIntervalId=a.C.Inst_get().SetFrameLoop(this.CreateDelegate(this.UpdateExp),10)}Hide(){null!=this.timeIntervalId&&(a.C.Inst_get().ClearLoop(this.timeIntervalId),
this.timeIntervalId=null)}})},83900:(t,e,i)=>{i.d(e,{N:()=>Lt})
var s=i(42292),n=i(71409),l=i(17409),a=i(77546),o=i(32076),r=i(38836),h=i(98800),d=i(96098),c=i(97461),u=i(36241),m=i(19176),I=i(2689),g=i(13687),_=i(73674),p=i(38935),C=i(5924),S=i(56937),f=i(31222),y=i(5494),w=i(49484),D=i(52726),T=i(995),A=i(98789),v=i(85602),L=i(79534),M=i(63076),b=i(92679),R=i(24594),P=i(73423),G=i(87923),O=i(85770),E=i(72800),B=i(2457),k=i(28613),x=i(37648),V=i(55492),N=i(24524),H=i(75439),U=i(55552),F=i(36328),j=i(88518),Y=i(92415),z=i(43308),q=i(74492),Z=i(74657),K=i(62783),$=i(12970),W=i(54235),X=i(21334),Q=i(11134),J=i(70204),tt=i(91690),et=i(26478),it=i(69630),st=i(18998),nt=i(83908),lt=i(86133),at=i(23833),ot=i(50089),rt=i(66788),ht=i(98130),dt=i(98885),ct=i(75696),ut=i(10509),mt=i(77191),It=i(41864),gt=i(21267)
class _t extends((0,nt.Ri)()){constructor(...t){super(...t),this.levelProgressBar=null,this.scrollPanelWidth=null,this.cellWidth=null,this.model=null,this.exitimer=null,
this.addPercent=null,this.value=null,this.addTime=null,this.mapPassResultVo=null,this.hasClickRush=null,this.exitTime=null,this.bossExp=null,this.newExp=null,this.newLevel=null,
this.oldLevel=null,this.allExp=null,this.curTime=null,this.animId=null,this.maxLevel=null}InitView(){super.InitView(),
this.levelProgressBar=this.levelProgress.getComponent(st.ProgressBar),this.grid.SetInitInfo("ui_baseitem",null,ct.j),
this.grid.OnReposition_set(this.CreateDelegate(this.OnReposition)),this.scrollPanelWidth=this.scrollPanel.node.getComponent(st.UITransform).width,
this.cellWidth=this.grid.cellWidth,this.bgSp.widthSet(ot.t.GetUIWidth()),this.model=gt.u.Inst()}Clear(){this.ClearTimer(),this.exitimer=-1,this.grid.Clear(),this.ClearAnim(),
super.Clear()}Destroy(){this.grid.destroy(),super.destroy()}OnAddToScene(){super.OnAddToScene(),this.addPercent=.1,this.value=0,this.addTime=0,
this.mapPassResultVo=this.model.mapPassResultVo,this.exitimer=-1,this.hasClickRush=!1,this.AddLis(),this.UpdateVIew(),this.AutoExit()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.exitbtn,this.CreateDelegate(this.ExitCopyHandler))}AutoExit(){if(-1==this.exitimer){
const t=N.o.Inst().getItemById(O.a.Inst_get().currentCopyId)
null==t?(this.exitTime=0,rt.Y.LogError((0,lt.T)("没有找到当前副本id：")+(O.a.Inst_get().currentCopyId+(0,lt.T)("的副本配置")))):this.exitTime=t.escTime,this.ClearTimer(),
this.exitimer=C.C.Inst_get().SetInterval(this.CreateDelegate(this.UpdateTimerHandler),1e3),this.UpdateTimerHandler()}}UpdateTimerHandler(){this.exitTime-=1
const t=dt.M.Replace((0,lt.T)("确定({0}S)"),"{0}",this.exitTime)
this.exitlab.textSet(t),this.exitTime<=0&&this.ExitCopyHandler()}UpdateVIew(){const t=this.mapPassResultVo.mapPassVo
let e=this.model.nowFightVo
const i=t.res,s=U.h.inst.GetSpwanItemById(i.bossId).objectKey
this.bossExp=at.a.getInst().getObjById(s).exp,this.unlockLabel.textSet(i.mapName+i.name),
e.id==this.mapPassResultVo.mapPassVo.id&&i.checkpoint>1&&(e=this.model.GetMapPassVoByMapAndLevel(i.mapId,i.checkpoint-1))
const n=ht.GF.INT(i.ExpRate/e.res.ExpRate*100)/100
n>1?(this.expShow.SetActive(!0),this.oldExp.textSet(G.l.GetRuleDecimalVal(e.res.ExpRate)+(0,lt.T)("/分")),this.newExLabel.textSet(G.l.GetRuleDecimalVal(i.ExpRate)+(0,lt.T)("/分")),
this.rateUpLabel.textSet(100*n+"%")):this.expShow.SetActive(!1),this.rewardShow.SetActive(!0),this.InitExpProgress(),this.grid.data_set(this.mapPassResultVo.resultList)}
OnReposition(){const t=this.grid.itemList.Count(),e=this.grid.node.getWorldPosition()
let i=this.cellWidth*t/2
i>this.scrollPanelWidth/2&&(i=this.scrollPanelWidth/2),e.x-=i,this.grid.node.SetLocalPositionXYZ(e.x,e.y,e.z)}ClearTimer(){
this.exitimer>=0&&C.C.Inst_get().ClearInterval(this.exitimer),this.exitimer=-1}ExitCopyHandler(){O.a.Inst_get().ExitCopy(),(0,l.sR)(y.I.MapPassFbSuccessView)}InitExpProgress(){
this.newExp=h.Y.Inst.PrimaryRoleInfo_get().Exp_get().ToNum(),this.newLevel=h.Y.Inst.PrimaryRoleInfo_get().Level_get(),this.oldExp.text=this.mapPassResultVo.oldExp.ToNum(),
this.oldLevel=this.mapPassResultVo.oldLevel,this.CalculateMaxLevel(this.oldLevel),this.value=Number(this.oldExp.text)/this.GetLevelUpExpByLevel(this.oldLevel),
this.allExp=this.GetExpByLevel(this.newLevel,this.oldLevel)+this.newExp-Number(this.oldExp.text),this.CalculatePercentByTime(3e3)
const t=Number(this.oldExp.text)/this.GetLevelUpExpByLevel(this.oldLevel)
this.RefreshProgress(t,!0),this.curTime<=0&&(this.levelProgressBar.progress=this.newExp/this.GetLevelUpExpByLevel(this.oldLevel)),
this.animId=C.C.Inst_get().SetInterval(this.CreateDelegate(this.RefreshExpProgress),40,this.curTime)}RefreshProgress(t,e){const i=It.h.GetLevelStr(this.mapPassResultVo.oldLevel)
if(t>1&&(t=1),this.levelProgressBar.progress=t,e){this.expEffect.SetActive(!0)
const e=new L.P(298*t-149,1,0)
this.expEffect.transform.SetLocalPosition(e),this.expEffect.SetActive(!1),this.level.textSet(`角色等级：${i}`),this.arrow.SetActive(!1),this.level2.textSet("")
}else if(this.expEffect.SetActive(!1),this.level.textSet(`角色等级：${i}`),this.mapPassResultVo.oldLevel==this.oldLevel)this.arrow.SetActive(!1),this.level2.textSet("")
else{const t=It.h.GetLevelStr(this.oldLevel)
this.arrow.SetActive(!0),this.level2.textSet(t),this.levelTable.Reposition()}}ClearAnim(){-1!=this.animId&&(C.C.Inst_get().ClearInterval(this.animId),this.animId=-1,
this.expEffect.SetActive(!1))}CalculatePercentByTime(t){
let e=0,i=Number(this.oldExp.text),s=this.oldLevel,n=this.allExp,l=this.GetLevelUpExpByLevel(this.oldLevel),a=l*this.addPercent
for(;n>0&&(n>=a||n>0&&(a=n),!(n<=0));)if(e+=1,n-=a,a+i>=l){if(i=a+i-l,s+=1,s>this.maxLevel)break
l=this.GetLevelUpExpByLevel(s),a=l*this.addPercent}else i=a+i
const o=Math.floor(t/40)
e>o?(this.addPercent=Math.floor(this.addPercent*e/o*100+.5)/100,this.curTime=o):this.curTime=e}GetLevelUpExpByLevel(t){return ut.L.Inst().getItemById(t).exp}RefreshExpProgress(){
if(this.addTime+=1,this.value+this.addPercent>=2){const t=Math.floor(this.value+this.addPercent)
this.oldLevel+t<=this.newLevel?this.oldLevel+=t:this.oldLevel=this.newLevel,this.value=this.value+this.addPercent-t
}else this.value+this.addPercent>=1?(this.value=this.value+this.addPercent-1,this.oldLevel+1<=this.newLevel&&(this.oldLevel+=1)):this.value+=this.addPercent
if(this.addTime>=this.curTime){const t=this.newExp/this.GetLevelUpExpByLevel(this.oldLevel)
this.RefreshProgress(t,!1)}else this.RefreshProgress(this.value,!0)}CalculateMaxLevel(t){const e=It.h.GetRebirthLevel(t)
this.maxLevel=mt.g.ins.GetVoByRebirthLevel(e).gtlevelList[1]}GetExpByLevel(t,e){let i=0
if(t<=e)return i
for(let s=e;s<=t-1;s++)i+=this.GetLevelUpExpByLevel(s)
return i}}class pt{constructor(){this.resultList=null,this.mapPassVo=null,this.success=!1,this.mapid=0,this.activeGuide=!1,this.oldExp=null,this.oldLevel=0}Test1(){return!0}
S_Test(){return!0}}var Ct,St,ft,yt,wt,Dt,Tt=i(2465),At=i(87791)
function vt(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let Lt=(Ct=(0,n.GH)(Y.k.SM_MapPassInfo),St=(0,n.GH)(Y.k.SM_PassBossCopy),ft=(0,n.GH)(Y.k.SM_MapPassUpdate),yt=(0,
n.GH)(Y.k.SM_RewardMapPass),Dt=class t{static __StaticInit(){t.__SubInitClass3()}constructor(){this.mapPassBtn=null,this.delayAutoLis=null,this.AddLis()}static __SubInitClass3(){}
static Inst(){return null==t._inst&&(t._inst=new t),t._inst}AddLis(){c.i.Inst.AddEventHandler(b.g.GET_OUT_SAFE_AREA,this.UpdateSafe),
c.i.Inst.AddEventHandler(b.g.FUNCTION_INIT_COMPLETE,(0,o.v)(this.OnFunctionOpen,this)),c.i.Inst.AddEventHandler(b.g.FUNCTION_OPEN,(0,o.v)(this.OnFunctionOpen,this)),
c.i.Inst.AddEventHandler(b.g.EnterMap,(0,o.v)(this.OnEnterMap,this))}SM_MapPassInfoHandle(t){const e=t.unlockMapId
$.F.getInst().mapbossPassStatus.Clear()
for(let t=0;t<=e.Count()-1;t++)$.F.getInst().mapbossPassStatus.LuaDic_AddOrSetItem(e[t],!0)
const i=t.mapPassVoMap,s=gt.u.Inst().mapPassVoDic
for(const[t,e]of(0,r.V5)(i)){const i=s[t]
null!=i&&i.SetServerData(e)}gt.u.Inst().totalPassNum=t.totalPassNum,gt.u.Inst().UpdateProgressDic(),Q.c.Inst_Get().RaiseEvent(Q.c.Passnum_Update),
gt.u.Inst().RaiseEvent(tt.Z.UpdateMapPassInfo),c.i.Inst.RaiseEvent(b.g.UPDATE_UNLOCK_BOSS_CHANLLENGE_INFO),this.LoadDirector(),this.UpdateAreaStates()}SM_PassBossCopyHandle(t){
const e=new pt
if(e.mapPassVo=gt.u.Inst().GetMapPassVoByCopyId(O.a.Inst_get().currentCopyId),e.oldLevel=t.oldLevel,e.oldExp=t.oldExp,e.success=t.win,e.mapid=g.b.Inst.currentMapId_get(),
e.activeGuide=!0,gt.u.Inst().mapPassResultVo=e,t.win)if(e.mapPassVo.res.successUi){const i=t.items,s=new v.Z
for(let t=0;t<=i.Count()-1;t++){const e=i[t],n=new M.M(e.modelId,e)
s.Add(n)}e.resultList=s,this.OpenMapFbSuccessView()}else O.a.Inst_get().ExitCopy()
else gt.u.Inst().CalFailNum(e.mapPassVo.res.id),G.l.CheckTrigger(B.u.COND_FAIL_MAP_PASS,-1),G.l.CheckTrigger(B.u.COND_PASS_BOSS_FAIL_VAL,-1)}SM_MapPassUpdateHandle(t){
const e=t.id,i=gt.u.Inst().mapPassVoDic[e]
null!=i&&i.SetServerData(t.update),gt.u.Inst().totalPassNum=t.totalPassNum,gt.u.Inst().UpdateProgressDic(e)
const s=g.b.Inst.currentMapId_get(),n=gt.u.Inst().GetHighestGateByMap(s)
null!=n&&n.id==e&&this.CheckAutoChallengeBoss(!0),Q.c.Inst_Get().RaiseEvent(Q.c.Passnum_Update),gt.u.Inst().RaiseEvent(tt.Z.UpdateMapPassInfo),this.UpdateAreaStates()}
CM_RewardMapPassHandle(t){const e=new j.p
e.id=t,p.C.Inst.F_SendMsg(e)}CM_RewardMapAllRewardHandle(t){const e=new F.C
e.mapId=t,p.C.Inst.F_SendMsg(e)}SM_RewardMapPassHandle(t){const e=new R.V,i=t.id
for(let t=0;t<=i.length-1;t++){const s=gt.u.Inst().GetMapPassVo(i[t])
if(s.reward=!0,gt.u.Inst().UpdateProgressDic(i[t]),null!=s.res.allPassReward){const t=Z.A.GetReward(s.res.allPassReward)
e.rewardLis.AddRange(t.GetJobLimitItemList())}}gt.u.Inst().RaiseEvent(tt.Z.UpdateMapPassInfo),e.countDownTime=H.D.getInstance().GetIntValue("REWARDSHOW:TIME"),e.layer=D.F.Tip}
OpenMapPassRewardTips(t){const e=new S.v
e.layerType=D.F.Tip,e.viewClass=W.C,gt.u.Inst().rewardTipsVo=gt.u.Inst().GetMapPassVo(t),f.N.inst.OpenById(y.I.MapPassRewardTips,null,null,e)}OnFunctionOpen(e){
null!=e&&e!=V.x.PASS_MAP_MAIN_BTN||t.Inst().OpenMapPassMainBtn()}OpenMapPassMainBtn(){const t=g.b.Inst.GetCurMap()
if(!x.P.Inst_get().IsFunctionOpened(V.x.PASS_MAP_MAIN_BTN)||-1!=t.hideElementsList.IndexOf(w.p.MAP_PASS_BTN))return void this.CloseMapPassMainBtn()
if((0,l.qJ)(y.I.eMapPassMainBtn)){const t=(0,l.Y)(y.I.eMapPassMainBtn)
if(t.ForcePlayAni(),null!=t.Ani){t.Ani.GetLocalPosition()}return}const e=new S.v
e.layerType=D.F.DefaultUI,e.aniDir=T.K.Default,e.positionType=A.$.eLeftTop,(0,l.Yp)(y.I.eMapPassMainBtn,e)}ShowHandler(t){}CloseMapPassMainBtn(){(0,l.sR)(y.I.eMapPassMainBtn)}
PlayMapPassFlyEff(t,e,i){null!=this.mapPassBtn&&this.mapPassBtn.isShow_get()&&this.mapPassBtn.PlayFlyOne(t,e,i)}OpenMapPassTips(t){const e=new S.v
e.layerType=D.F.MainUI,e.viewClass=At.A,gt.u.Inst().nextTipsVo=gt.u.Inst().GetMapPassVo(t),(0,l.qJ)(y.I.eMapPassMainBtn)&&(0,l.Yp)(y.I.MapPassNextTips)}OpenMapFbInfoView(){
const t=new S.v
t.layerType=D.F.DefaultUI,t.viewClass=it.y,(0,l.Yp)(y.I.MapPassFbInfo,t)}CloseMapFbInfoView(){(0,l.sR)(y.I.MapPassFbInfo)}OpenMapFbSuccessView(){const t=new S.v
t.layerType=D.F.MainUI,t.viewClass=_t,t.isDefaultUITween=!0,t.isShowMask=!0,(0,l.Yp)(y.I.MapPassFbSuccessView,t)}CloseMapFbSuccessView(){(0,l.sR)(y.I.MapPassFbSuccessView)}
OpenMapFbFailView(){const t=new S.v
t.layerType=D.F.MainUI,t.viewClass=et.g,t.isShowMask=!0,(0,l.Yp)(y.I.MapPassFbFailView,t)}CloseMapFbFailView(){(0,l.sR)(y.I.MapPassFbFailView)}CloseAll(){this.CloseMapFbInfoView(),
this.CloseMapPassAlertView(),this.CloseMapFbSuccessView()}OnEnterMap(){let t=!1
if(gt.u.Inst().loginStartHang||(gt.u.Inst().loginStartHang=!0,this.CheckIsInGateRange(null)&&u._.getInst().startHang()),0!=g.b.Inst.lastCopyMapId){
const e=N.o.Inst().getItemById(O.a.Inst.lastCopyId)
null!=e&&(e.controllerType==E.S.MapPassBoss?(this.FindNextGateHang(),t=!0):this.CheckIsInGateRange(null)&&u._.getInst().startHang())}
t?this.UpdateAreaState():this.UpdateAreaStates(),this.CheckAutoLis(null)}UpdateSafe(){m.S.getInst().isInSafeArea&&gt.u.Inst().SetAutoPass(!1,!0)}CheckIsInGateRange(t){
const e=g.b.Inst.currentMapId_get(),i=gt.u.Inst().GetMapPassProgressVoByMapId(e)
if(null!=t){
const e=t.res.spawnId,i=U.h.GetInst().GetSpwanItemById(e),s=new L.P(h.Y.Inst.PrimaryRoleInfo_get().X_get(),0,h.Y.Inst.PrimaryRoleInfo_get().Y_get()),n=new L.P(i.x,0,i.y),l=G.l.FastDistanceVector3XZ(s,n)
return L.P.Recyle(n),l<i.bornRange*i.bornRange}if(null!=i){for(let t=1;t<=i.nowLevel;t++){
const i=gt.u.Inst().GetMapPassVoByMapAndLevel(e,t).res.spawnId,s=U.h.GetInst().GetSpwanItemById(i),n=new L.P(h.Y.Inst.PrimaryRoleInfo_get().X_get(),0,h.Y.Inst.PrimaryRoleInfo_get().Y_get()),l=new L.P(s.x,0,s.y),a=G.l.FastDistanceVector3XZ(n,l)
if(L.P.Recyle(l),a<=s.bornRange*s.bornRange)return!0}return!1}return!1}CheckAutoLis(t){this.CLeanAutoLis()
const e=gt.u.Inst().GetMapId(),i=gt.u.Inst().GetMapPassProgressVoByMapId(e)
null!=i&&i.nowLevel>0&&i.nowLevel<i.maxLevel&&(this.delayAutoLis=C.C.Inst_get().SetInterval((0,o.v)(this.CheckAutoChallengeBoss,this),1e3),t&&this.CheckAutoChallengeBoss(t))}
CLeanAutoLis(){null!=this.delayAutoLis&&C.C.Inst_get().ClearInterval(this.delayAutoLis)}FindNextGateHang(){const t=gt.u.Inst().mapPassResultVo
if(null!=t&&null!=t.mapPassVo)if(t.success)C.C.Inst_get().SetInterval((()=>{null!=t&&null!=t.mapPassVo&&this.GotoKillMonsterOrBoss(t.mapPassVo,null,null,!0)}),400,1)
else{const e=gt.u.Inst().GetHighestGateByMap(t.mapPassVo.res.mapId)
C.C.Inst_get().SetInterval((()=>{null!=e&&null!=e&&this.GotoKillMonsterOrBoss(e,null,null,!0)}),400,1)}else a.s.Info("推关BOss出来后 没有结算数据")}UpdateAreaStates(){let t=!1
const e=g.b.Inst.currentMapId_get(),i=gt.u.Inst().GetMapPassProgressVoByMapId(e)
if(null!=i&&(gt.u.Inst().poisonMapId==e&&gt.u.Inst().poisonLevel==i.nowLevel||(t=!0),t)){const t=new v.Z
for(let e=1;e<=i.nowLevel;e++){const s=gt.u.Inst().GetMapPassVoByMapAndLevel(i.mapId,e)
t.Add(s.res.fogId)}}}UpdateAreaState(){
const t=g.b.Inst.currentMapId_get(),e=gt.u.Inst().GetMapPassProgressVoByMapId(t),i=(gt.u.Inst().GetMapPassVoByMapAndLevel(e.mapId,e.nowLevel),
H.D.getInstance().GetIntValue("FOG:VANISH_LEVEL"))
h.Y.Inst.PrimaryRoleInfo_get().Level_get()}OpenMappassRewardView(){const t=new S.v
t.layerType=D.F.MainUI,t.viewClass=Tt.V,t.isShowMask=!0,t.isDefaultUITween=!0,(0,l.Yp)(y.I.MapPassRewardView,t)}CloseMappassRewardView(){(0,l.sR)(y.I.MapPassRewardView)}
GotoKillMonsterOrBoss(t,e,i,s){if(null!=t){if(i){const e=g.b.Inst.GetCurMap(),i=$.F.getInst().GetMapNotChallengeBoss()
return void(e.controllerType==I.N.SCENE&&0!=i?K.X.inst.OpenMapPanel(K.X.WORD_MAP,null,null,i):K.X.inst.OpenMapPanel(K.X.WORD_MAP,null,null,t.res.mapId))}
1==t.CanChallengeBoss()&&1!=s?e?d.B.Inst.CM_FlyShoesTransportHandle(t.res.flyId,null,null,!1):z._.Inst_get().FindWay(t.res.flyId,!0,null):e?d.B.Inst.CM_FlyShoesTransportHandle(gt.u.Inst().GetTransVoById(t.id).id,null,null,!0):z._.Inst_get().FindWay(gt.u.Inst().GetTransVoById(t.id).id,null,null)
}}RaiseMapPassGuide(){
z._.Inst_get().CloseAll(),null!=gt.u.Inst().nowFightVo&&(gt.u.Inst().nowFightVo.res.mapId==g.b.Inst.currentMapId_get()?gt.u.Inst().IsFix()&&c.i.Inst.RaiseEvent(b.g.GUIDE_EVENT,k.e.Map_Pass1):K.X.inst.OpenMapPanel(K.X.WORD_MAP,null,null,gt.u.Inst().nowFightVo.res.mapId))
}CheckAutoChallengeBoss(t){if(gt.u.Inst().autoPass){if(f.N.inst.IsViewShowing(y.I.MapChangeProgress))return
this.AutoChallenge(t)}}AutoChallenge(t){const e=g.b.Inst.currentMapId_get(),i=gt.u.Inst().GetHighestGateByMap(e),s=gt.u.Inst().GetNextPassVo(i)
if(null!=s){const e=s.CanChallengeBoss()
2==e?(t||m.S.getInst().InHang_get()&&!this.CheckIsInGateRange(i)&&!h.Y.isMapFindWay)&&this.GotoKillMonsterOrBoss(i):1!=e&&0!=e||(this.GotoKillMonsterOrBoss(s),
gt.u.Inst().lastClickMapPassId!=i.res.id&&(P.B.Inst().PlayEffect("ui_map_pass_eff",L.P.zero_get(),L.P.zero_get(),2,2e3),gt.u.Inst().lastClickMapPassId=i.res.id))}}
GetPosHasShowFog(t,e){return!1}LoadDirector(){const t=X.p.Inst_get().GetNowHightMap()
if(0!=t){const e=X.p.Inst_get().GetMapById(t)
if(0!=e.scene){q.g.Instance.GetStoryGroupNames(e.scene)}const i=X.p.Inst_get().GetNextMap(t)
if(0!=i){const t=X.p.Inst_get().GetMapById(i)
if(null!=t&&0!=t.scene){const e=q.g.Instance.GetStoryGroupNames(t.scene)
_.c.StoryChangeMapDestory.Add(e)}}}}OpanMapPassAlertView(){const t=new S.v
t.layerType=D.F.DefaultUI,t.viewClass=J.d,t.isShowMask=!1,(0,l.Yp)(y.I.MapPassAlertPanel,t)}CloseMapPassAlertView(){(0,l.sR)(y.I.MapPassAlertPanel)}},Dt._inst=null,
vt(wt=Dt,"Inst",[s.n],Object.getOwnPropertyDescriptor(wt,"Inst"),wt),
vt(wt.prototype,"SM_MapPassInfoHandle",[Ct],Object.getOwnPropertyDescriptor(wt.prototype,"SM_MapPassInfoHandle"),wt.prototype),
vt(wt.prototype,"SM_PassBossCopyHandle",[St],Object.getOwnPropertyDescriptor(wt.prototype,"SM_PassBossCopyHandle"),wt.prototype),
vt(wt.prototype,"SM_MapPassUpdateHandle",[ft],Object.getOwnPropertyDescriptor(wt.prototype,"SM_MapPassUpdateHandle"),wt.prototype),
vt(wt.prototype,"SM_RewardMapPassHandle",[yt],Object.getOwnPropertyDescriptor(wt.prototype,"SM_RewardMapPassHandle"),wt.prototype),wt)},91690:(t,e,i)=>{i.d(e,{Z:()=>s})
class s{}s.UpdateMapPassInfo="UpdateMapPassInfo",s.UpdateGetRewardState="UpdateGetRewardState"},26478:(t,e,i)=>{i.d(e,{g:()=>D})
var s,n=i(6847),l=i(83908),a=i(49655),o=i(46282),r=i(93984),h=i(86133),d=i(97461),c=i(98958),u=i(5924),m=i(98885),I=i(92679),g=i(29839),_=i(85770),p=i(24524),C=i(10909),S=i(14187),f=i(95406),y=i(83900),w=i(21267)
let D=(0,n.s_)(a.o.MapPassFbFailView,o.Z.ui_map_pass_fb_failpanel_ry).register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),this._degf_OnCreateAccessItem=null,
this.model=null,this.mapPassResultVo=null,this.timer=null,this.exitTime=null,this.exitStr=null,this.exitlab=null}InitView(){super.InitView(),
null!=this.grid&&(this._degf_OnCreateAccessItem=t=>this.OnCreateAccessItem(t),this.grid.SetInitInfo("ui_access_iconitem",null,C.j)),this.model=w.u.Inst()}OnCreateAccessItem(t){}
OnAddToScene(){this.mapPassResultVo=this.model.mapPassResultVo,this.timer=-1
const t=p.o.Inst().getItemById(_.a.Inst_get().currentCopyId)
null!=t&&(this.exitTime=t.escTime,this.exitStr=c.V.Inst().getStr(10300,r.h.eLangResource),this.AutoExit()),this.addLis(),this.ShowStrengWay()}addLis(){
this.m_handlerMgr.AddClickEvent(this.exitbtn,this.CreateDelegate(this.ExitCopyHandler)),d.i.Inst.AddEventHandler(I.g.ACCESS_ICON_CLICK,this.CreateDelegate(this.OnAccessClick))}
AutoExit(){-1==this.timer&&(this.timer=u.C.Inst_get().SetInterval(this.CreateDelegate(this.ExitCopyAnim),1e3),this.autoExit.textSet(`${(0,h.T)("离开副本(")}${this.exitTime})`))}
ExitCopyAnim(){this.exitTime-=1,this.autoExit.textSet(`${(0,h.T)("离开副本(")}${this.exitTime})`),this.exitTime<=0&&(u.C.Inst_get().ClearInterval(this.timer),this.timer=-1,
this.autoExit.textSet((0,h.T)("离开副本")),this.ExitCopyHandler())}ExitCopyHandler(){u.C.Inst_get().ClearInterval(this.timer),this.timer=-1,
g.p.inst.IsInCopy()?_.a.Inst_get().ExitCopy():y.N.Inst().CloseAll()}UpdateTimerHandler(){this.exitTime-=1
const t=m.M.Replace((0,h.T)("确定({0}S)"),"{0}",this.exitTime)
this.exitlab.textSet(t),this.exitTime<=0&&this.ExitCopyHandler()}ShowStrengWay(){}OnAccessClick(t){g.p.inst.IsInCopy()&&(f.j.accessIdAfterCopy=t,S.u.Inst_Get().tryOpenPanel=!1,
this.ExitCopyHandler())}RemoveLis(){d.i.Inst.RemoveEventHandler(I.g.ACCESS_ICON_CLICK,this.CreateDelegate(this.OnAccessClick)),
this.m_handlerMgr.AddClickEvent(this.exitbtn,this.CreateDelegate(this.ExitCopyHandler))}Clear(){u.C.Inst_get().ClearInterval(this.timer),this.RemoveLis(),this.timer=-1,
this.grid.Clear(),super.Clear()}Destroy(){this.grid.destroy(),super.destroy()}Test1(){return!0}S_Test(){return!0}})||s},69630:(t,e,i)=>{i.d(e,{y:()=>f})
var s,n=i(6847),l=i(83908),a=i(46282),o=i(40053),r=i(86133),h=i(62370),d=i(60130),c=i(98130),u=i(98885),m=i(75696),I=i(92679),g=i(87923),_=i(85770),p=i(74657),C=i(49655),S=i(21267)
let f=(0,n.s_)(C.o.MapPassFbInfo,a.Z.ui_map_pass_fb_info).waitPrefab(o.Z.RyForgeEquipListItem_baseItemPrefabs).register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),
this.model=null,this.copyId=null,this.mapPassVo=null}InitView(){super.InitView(),this.grid_item.SetInitInfo("ui_baseitem",null,m.j),this.model=S.u.Inst()}Clear(){super.Clear()}
Destroy(){super.destroy()}OnAddToScene(){if(this.m_handlerMgr.AddEventMgr(I.g.UPDATE_ANCHORS,this.CreateDelegate(this._OnUpdateAnchor)),this.copyId=_.a.Inst_get().currentCopyId,
this.text_expUp.node.SetActive(!1),this.text_exp.node.SetActive(!1),null!=this.copyId){this.mapPassVo=this.model.GetMapPassVoByCopyId(this.copyId)
const t=this.model.GetMapPassProgressVoByMapId(this.mapPassVo.res.mapId)
if(null!=this.mapPassVo){const e=this.mapPassVo.res
this.level_name.textSet(`${e.mapName}${e.name}首领`)
const i=S.u.Inst().GetHighestGateByMap(this.mapPassVo.res.mapId)
if(null==i||t.maxLevel<=i.res.checkpoint)this.unlockLevel.SetActive(!1)
else{this.unlockLevel.SetActive(!0),this.unlockMap.textSet(e.mapName+e.name)
let t=0
if(null!=i){const s=i.res.ExpRate
0!=s&&(t=c.GF.INT(e.ExpRate/s*100)/100)}if(t>1){let i=h.o.NumDigit(100*t,0)
this.text_expUp.textSet(`${i}%`),this.text_expUp.node.SetActive(!0),this.text_exp.node.SetActive(!0),this.text_exp.textSet(g.l.GetRuleDecimalVal(e.ExpRate)+(0,r.T)("/分"))
}else this.text_expUp.node.SetActive(!1),this.text_exp.node.SetActive(!0),this.text_exp.textSet(g.l.GetRuleDecimalVal(e.ExpRate)+(0,r.T)("/分"))}
const s=t.GetNextRewardLevel(),n=u.M.ReplaceOne("再通{0}关可领取：","{0}",(s-this.mapPassVo.res.checkpoint+1).toString())
this.gateLabel.textSet(n)
const l=this.model.GetMapPassVoByMapAndLevel(t.mapId,s),a=p.A.GetReward(l.res.allPassReward).GetJobLimitItemList()
this.grid_item.data_set(a)}}this._OnUpdateAnchor()}_OnUpdateAnchor(){d.O.SetAnchorPos(this.anchor,!0,!1,0,!1)}})||s},42181:(t,e,i)=>{
var s,n=i(18998),l=i(75507),a=i(6847),o=i(83908),r=i(17409),h=i(46282),d=i(98800),c=i(96098),u=i(97960),m=i(97461),I=i(13687),g=i(85682),_=i(60130),p=i(85602),C=i(79534),S=i(92679),f=i(73423),y=i(87923),w=i(2457),D=i(28613),T=i(48933),A=i(37648),v=i(55492),L=i(55552),M=i(68637),b=i(83836),R=i(61546),P=i(15821),G=i(43308),O=i(41864),E=i(15398),B=i(99535),k=i(62783),x=i(31931),V=i(12970),N=i(21334),H=i(49655),U=i(83900),F=i(91690),j=i(21267)
;(0,a.s_)(H.o.eMapPassMainBtn,h.Z.ui_map_pass_Btn).waitPrefab(h.Z.ui_goldhangTips).layerNav().register()(s=class extends((0,o.Ri)()){constructor(...t){super(...t),this.isout=null,
this.showEffstate=null,this.flyItemsPool=null,this.flyItems=null,this.model=null,this.delayUpdate=null,this.nowMapHeightVo=null,this.nextPassVo=null,this.roleInfo=null,
this.clickMapId=null}InitView(){super.InitView(),this.isout=!1,this.goldhangTips.SetActive(!1),this.pre_eff_autochallenge.SetActive(!1),this.effect.SetActive(!1),
this.fixeff.SetActive(!1),this.UpdateAnchors(),this.showEffstate=!1,this.flyItemsPool=new p.Z,this.flyItems=new p.Z,this.model=j.u.Inst()}UpdateAnchors(){
_.O.SetAnchorPos(this.anchor,!0,!0,0,!0)}Clear(){null!=this.delayUpdate&&(this.m_handlerMgr.ClearInterval(this.delayUpdate),this.delayUpdate=null),this.RemoveLis(),
this.flyItemsPool.Clear(),super.Clear()}Destroy(){if(null!=this.flyItems){const t=this.flyItems.count-1
for(let e=0;e<=t;e++)this.flyItems[e].Clear()
this.flyItems=null}super.destroy()}OnAddToScene(){super.OnAddToScene(),this.AddLis(),this.UpdateIcon()}RegGuide(){M.c.Inst.RegGameObject(g.D.UI_MAP_PASS_BTN,this.enterBtn.node)}
UnRegGuide(){M.c.Inst.UnRegGameObject(g.D.UI_MAP_PASS_BTN)}AddLis(){this.m_handlerMgr.AddClickEvent(this.enterBtn,this.CreateDelegate(this.OnClickBtnIcon)),
this.m_handlerMgr.AddClickEvent(this.autotog,this.CreateDelegate(this.OnSetAuto)),
this.m_handlerMgr.AddNotifyEvent(this.model,F.Z.UpdateMapPassInfo,this.CreateDelegate(this.DelayUpdateIcon)),
this.m_handlerMgr.AddEventMgr(S.g.EnterMap,this.CreateDelegate(this.UpdateIcon)),
this.m_handlerMgr.AddEventMgr(S.g.UITweenStateChanged,this.CreateDelegate(this.OnUITweenStateChanged)),
this.m_handlerMgr.AddEventMgr(S.g.FUNCTION_OPEN,this.CreateDelegate(this.UpdateTog)),this.m_handlerMgr.AddEventMgr(S.g.FUNCTION_INIT_COMPLETE,this.CreateDelegate(this.UpdateTog)),
this.m_handlerMgr.AddEventMgr(S.g.SHOW_MAP_PASS_BTN_EXP_TIPS,this.CreateDelegate(this.UpdateGoldHangTips)),
R.X.Inst_get().AddEventHandler(S.g.MULTIPLEHANG_OFF,this.CreateDelegate(this.UpdateGoldHangTips)),
B.O.Inst_get().AddEventHandler(E.M.INFORM_DO_REMOVE,this.CreateDelegate(this.OnUpdateTask)),B.O.Inst_get().AddEventHandler(E.M.TASK_INIT_END,this.CreateDelegate(this.UpdateIcon)),
this.m_handlerMgr.AddEventMgr(S.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors)),this.m_handlerMgr.AddEventMgr(S.g.GET_IN_SAFE_AREA,this.CreateDelegate(this.UpdateIcon)),
this.m_handlerMgr.AddEventMgr(S.g.GET_OUT_SAFE_AREA,this.CreateDelegate(this.UpdateIcon)),m.i.Inst.AddEventHandler(P.i.NEWBIE_HERO_BATTLE,this.CreateDelegate(this.OnClickBtnIcon)),
d.Y.Inst.PrimaryRoleInfo_get().AddEventHandlerRoleGlobal(u.A.LevelUpdate,this.CreateDelegate(this.UpdateIcon)),this.RegGuide()}RemoveLis(){
this.m_handlerMgr.RemoveClickEvent(this.enterBtn,this.CreateDelegate(this.OnClickBtnIcon)),this.m_handlerMgr.RemoveClickEvent(this.autotog,this.CreateDelegate(this.OnSetAuto)),
this.m_handlerMgr.AddNotifyEvent(this.model,F.Z.UpdateMapPassInfo,this.CreateDelegate(this.DelayUpdateIcon)),
this.m_handlerMgr.RemoveEventMgr(S.g.EnterMap,this.CreateDelegate(this.UpdateIcon)),
this.m_handlerMgr.RemoveEventMgr(S.g.UITweenStateChanged,this.CreateDelegate(this.OnUITweenStateChanged)),
this.m_handlerMgr.RemoveEventMgr(S.g.FUNCTION_OPEN,this.CreateDelegate(this.UpdateTog)),
this.m_handlerMgr.RemoveEventMgr(S.g.FUNCTION_INIT_COMPLETE,this.CreateDelegate(this.UpdateTog)),
this.m_handlerMgr.RemoveEventMgr(S.g.SHOW_MAP_PASS_BTN_EXP_TIPS,this.CreateDelegate(this.UpdateGoldHangTips)),
B.O.Inst_get().RemoveEventHandler(E.M.INFORM_DO_REMOVE,this.CreateDelegate(this.OnUpdateTask)),
B.O.Inst_get().RemoveEventHandler(E.M.TASK_INIT_END,this.CreateDelegate(this.UpdateIcon)),
R.X.Inst_get().RemoveEventHandler(S.g.MULTIPLEHANG_OFF,this.CreateDelegate(this.UpdateGoldHangTips)),
d.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandlerRoleGlobal(u.A.LevelUpdate,this.CreateDelegate(this.UpdateIcon)),this.UnRegGuide(),
this.m_handlerMgr.RemoveEventMgr(S.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors)),
this.m_handlerMgr.RemoveEventMgr(S.g.GET_IN_SAFE_AREA,this.CreateDelegate(this.UpdateIcon)),
this.m_handlerMgr.RemoveEventMgr(S.g.GET_OUT_SAFE_AREA,this.CreateDelegate(this.UpdateIcon)),
m.i.Inst.RemoveEventHandler(P.i.NEWBIE_HERO_BATTLE,this.CreateDelegate(this.OnClickBtnIcon))}ForcePlayAni(){this.OnUITweenStateChanged(this.isout,!0)}OnUITweenStateChanged(t,e){
null==e&&(e=!1),(this.isout!=t||e)&&(this.isout=t,this.node.visible=!t)}DelayUpdateIcon(){
null==this.delayUpdate&&(this.delayUpdate=this.m_handlerMgr.SetInterval(this.CreateDelegate(this.UpdateIcon),400,1))}UpdateIcon(){if(!(0,r.qJ)(H.o.eMapPassMainBtn))return
let t=I.b.Inst.currentMapId_get()
R.X.Inst_get().IsMultipleExpHangMap(!0)&&(t=I.b.Inst.GetCurMap().relatedMapId),this.nowMapHeightVo=this.model.GetHighestGateByMap(t),this.anchor.node.SetActive(!0)
let e=null
if(e=this.model.GetNextPassVo(this.nowMapHeightVo),null==e)if(e=this.model.GetNextPassVo(this.model.nowFightVo),null!=e);else{const t=V.F.getInst().GetMapNotChallengeBoss()
if(0!=t)e=this.model.GetMapPassVoByMapAndLevel(t,1)
else{let t=0
null!=this.model.nowFightVo&&(t=N.p.Inst_get().GetNextMap(this.model.nowFightVo.res.mapId)),0!=t&&(e=this.model.GetMapPassVoByMapAndLevel(t,1)),
null==e&&(e=this.model.GetHighestUnPassMapPassVo())}}this.nextPassVo=e,this.roleInfo=d.Y.Inst.PrimaryRoleInfo_get(),this.clickMapId=t,this.showEffstate=!1
let i=!0,s=!1
if(null!=e)if(e.res.mapId==t){const t=e.CanChallengeBoss()
if(4==t)this.nameTxt.textSet(e.res.mapName+e.res.name),this.progressTxt.textSet("继续主线任务"),i=!1
else if(3==t)this.progressTxt.textSet(`${e.res.unlockLevel}级首领`),this.nameTxt.textSet(e.res.mapName+e.res.name),i=!1
else if(1==t||2==t){if(1==e.res.checkpoint)return
this.showEffstate=!0
let t=0
e.needKill&&0!=e.needKill&&(t=this.nowMapHeightVo.killNum/e.needKill),t>1&&(t=1),this.SetAmount(t),this.nameTxt.textSet(e.res.mapName+e.res.name)
let n=this.nowMapHeightVo.killNum
n>e.needKill&&(n=e.needKill),this.progressTxt.textSet(`${n}/${e.needKill}`),this.nowMapHeightVo.killNum>=e.needKill&&(s=!0,y.l.CheckTrigger(w.u.COND_PASS_BOSS_FIX_VAL)),i=!0}}else{
const t=e.res.mapId
this.clickMapId=t
const s=V.F.getInst().GetCanEnterMapByLvAndTransfer(t)
if(s==x.f.CAN){e.CanChallengeBoss()
4==s?(this.nameTxt.textSet(""),this.progressTxt.textSet("继续主线任务")):3==s?(this.progressTxt.textSet(`${e.res.unlockLevel}可继续挑战`),
this.nameTxt.textSet("")):1!=s&&2!=s&&0!=s||(this.nameTxt.textSet(""),this.progressTxt.textSet("前往挑战关卡"))}else if(s==x.f.BOSS_LIMIT)this.nameTxt.textSet(""),
this.progressTxt.textSet("前往新地图")
else{const e=N.p.Inst_get().GetMapById(t).minLevelLimit
this.nameTxt.textSet(""),this.progressTxt.textSet(`${O.h.GetLevelStr(e)}前往新地图`)}i=!1}else this.nameTxt.textSet(""),this.anchor.node.SetActive(!0),this.progressTxt.textSet("敬请期待"),
i=!1
s?this.effect.active||(this.effect.SetActive(!0),this.fixeff.SetActive(!0)):(this.effect.SetActive(!1),this.fixeff.SetActive(!1)),this.ShoworHideSlider(i),this.UpdateTog(),
this.delayUpdate=null}UpdateGoldHangTips(){R.X.Inst_get().multiHangState==b.O.On?(this.goldhangTips.node.active||this.goldhangTips.SetActive(!0),
this.goldhangTips.Show()):this.goldhangTips.Hide()}OnUpdateTask(t){if(null!=this.nextPassVo){
const e=j.u.Inst().GetMapPassVoByMapAndLevel(this.nextPassVo.res.mapId,this.nextPassVo.res.checkpoint-1)
if(null!=e){new p.Z(e.res.questId).Contains(t.resource_get().id)&&(this.UpdateIcon(),y.l.CheckTrigger(w.u.COND_PASS_BOSS_FIX_VAL))}}}SetAmount(t){
this.progressFG.getComponent(n.ProgressBar).progress=t}UpdateTog(){A.P.Inst_get().IsFunctionOpened(v.x.AUTO_PASS_TOGGLE)&&null!=this.nextPassVo?(this.autotog.node.SetActive(!0),
this.model.autoPass?(this.autotog.SetValue(!0),this.unselectBtn.SetActive(!1),this.selectBtn.SetActive(!0),this.autotogLabel.textSet(""),
this.pre_eff_autochallenge.SetActive(!0)):(this.autotog.SetValue(!1),this.selectBtn.SetActive(!1),this.unselectBtn.SetActive(!0),this.autotogLabel.textSet("自动挑战"),
this.pre_eff_autochallenge.SetActive(!1))):this.autotog.node.SetActive(!1)}PlayFlyOne(t,e,i){if(this.showEffstate){const s=this.PoolOne()
this.flyItems.Add(s),T.I.calVec0.Set(t,e,i)
const n=_.O.WorldToUILocalPosRelative(T.I.calVec0,this.flyEffectObj.transform),l=this.flyEffectObj.x,a=this.flyEffectObj.y
s.Play(n.x,n.y,l,a,this.CreateDelegate(this.OnFlyEnd))}}PoolOne(){let t=null
if(this.flyItemsPool.Count()>0)t=this.flyItemsPool.Pop()
else{const e=l.o.getPrefab("ui_map_pass_flyeff"),i=(0,n.instantiate)(e)
t=i.getCNode(),this.flyEffectObj.addChild(i)}return t}OnFlyEnd(t){this.flyItems.Remove(t),this.flyItemsPool.Add(t)}OnClickBtnIcon(){const t=j.u.Inst().nowFightVo
if(null!=t&&R.X.Inst_get().IsMultipleExpHangMap(!0)&&null!=this.nextPassVo&&this.nextPassVo.res.mapId==I.b.Inst.GetCurMap().relatedMapId)c.B.Inst.CM_FlyShoesTransportHandle(j.u.Inst().GetTransVoById(t.id).id,null,null,null,(()=>{
U.N.Inst().AutoChallenge(null)}))
else if(null!=this.nextPassVo)if(this.nextPassVo.res.mapId==I.b.Inst.currentMapId_get()){const t=this.nextPassVo.CanChallengeBoss()
if(1==t){const t=L.h.GetInst().GetSpwanItemById(this.nextPassVo.res.bossId),e=new C.P(t.x,0,t.y)
G._.Inst_get().FindWay2(e,this.nextPassVo.res.mapId,null),this.model.lastClickMapPassId!=this.nowMapHeightVo.res.id&&(f.B.Inst().PlayEffect("ui_map_pass_eff",C.P.zero_get(),C.P.zero_get(),2,2e3),
this.model.lastClickMapPassId=this.nowMapHeightVo.res.id)
}else 4==t?m.i.Inst.RaiseEvent(S.g.GUIDE_EVENT,D.e.CLICK_MAPPASS_BTN_NEED_TASK):U.N.Inst().OpenMapPassTips(this.nextPassVo.id)
}else k.X.inst.OpenMapPanel(k.X.WORD_MAP,null,null,this.clickMapId)
else null!=this.model.nowFightVo&&U.N.Inst().GotoKillMonsterOrBoss(this.model.nowFightVo,!1,!0)}OnSetAuto(){this.model.SetAutoPass(null,null),this.UpdateTog()}ShoworHideSlider(t){
this.sliderbg.SetActive(t),0==t&&(this.SetAmount(0),this.effect.SetActive(t),this.fixeff.SetActive(t))}})},21267:(t,e,i)=>{i.d(e,{u:()=>P})
var s=i(42292),n=i(93984),l=i(38836),a=i(98800),o=i(19176),r=i(13687),h=i(16812),d=i(66788),c=i(55360),u=i(85602),m=i(38962),I=i(79534),g=i(87923),_=i(26340),p=i(9659),C=i(7708),S=i(55552),f=i(61546),y=i(65550),w=i(83900),D=i(91690)
class T{constructor(){this.maxLevel=0,this.nowLevel=0,this.isPass=!1,this.mapId=0,this.rewardDic=null,this.rewardList=null,this.mapPassList=null,this.rewardDic=new m.X,
this.rewardList=new u.Z,this.mapPassList=new u.Z}UpdateMaxLevel(t){t>this.maxLevel&&(this.maxLevel=t)}UpdateNowLevel(t){t>=this.nowLevel&&(this.nowLevel=t,
this.isPass=this.maxLevel==t)}UpdateReward(t){const e=t.res.checkpoint
t.HasRewardCfg()&&(t.CanGetReward()?this.rewardDic.LuaDic_AddOrSetItem(e,!0):this.rewardDic.LuaDic_AddOrSetItem(e,!1),this.RefreshRewardList())}RefreshRewardList(){
const t=this.rewardList
this.rewardList.Clear()
for(const[e,i]of(0,l.V5)(this.rewardDic))t.Add(e)
t.Sort(((t,e)=>Number(t)<Number(e)?-1:t>e?1:0))}GetRewardLevelList(){return this.rewardList}GetNearRewardLevelCanGet(t){const e=this.GetRewardLevelList()
let i=null
for(let s=0;s<=e.Count()-1;s++){const n=e[s]
if(this.rewardDic[n]){i=n
break}if(1!=t){const t=P.Inst().GetMapPassVoByMapAndLevel(this.mapId,n)
null!=i||t.reward||(i=n)}}return i}GetNextRewardLevel(){const t=this.GetRewardLevelList()
let e=null
for(let i=0;i<=t.Count()-1;i++){const s=t[i]
if(s>this.nowLevel){e=s
break}}return e}GetMapPassVoList(){return this.mapPassList}Clear(){this.nowLevel=0,this.isPass=!1,this.rewardDic.Clear(),this.rewardList.Clear()}}var A,v,L,M=i(98504),b=i(99535)
class R{constructor(){this.id="",this.res=null,this.killNum=0,this.state=M.s.LOCK,this.reward=!1,this.needKill=0,this.hasServer=!1}SetResData(t){this.id=t.id,this.res=t,
null!=this.res.killNum?this.needKill=this.res.killNum[1]:this.needKill=0}SetServerData(t){this.hasServer=!0,this.killNum=t.killNum,this.reward=t.reward}UpdateState(t){this.state=t}
CanGetReward(){return!(!this.hasServer||!this.HasRewardCfg()||0!=this.reward)}HasRewardCfg(){return""!=this.res.allPassReward}CanChallengeBoss(){
if(0!=this.res.bossId&&1!=this.hasServer){if(null==P.Inst().nowFightVo)return!1
let t=null
if(this.res.checkpoint>1&&(t=P.Inst().GetMapPassVoByMapAndLevel(this.res.mapId,this.res.checkpoint-1)),null==t)return 1
if(a.Y.Inst.PrimaryRoleInfo_get().Level_get()<this.res.unlockLevel)return 3
if(null!=t.res.questId){const e=new u.Z(t.res.questId)
let i=!1
0==e.Count()&&(i=!0)
for(let t=0;t<=e.Count()-1;t++)if(b.O.Inst_get().IsTaskCompleted2(e[t])){i=!0
break}if(!i)return 4}return t.killNum<this.needKill?2:1}return 0}Clear(){this.killNum=0,this.state=M.s.LOCK,this.reward=!1,this.hasServer=!1}}let P=(0,
s.gK)("MapPassModel")((L=class t extends h.k{constructor(){super(),this.csvEx=null,this.mapPassProgressDic=null,this.mapPassVoDic=null,this.spawnKeyDic=null,this.fogIndexDic=null,
this.mapDicByHierarchy=null,this.copyKeyMap=null,this.mapList=null,this.rewardTipsVo=null,this.nextTipsVo=null,this.nowFightVo=null,this.MapPassResultVo=null,this.poisonLevel=0,
this.poisonMapId=0,this.totalPassNum=0,this.failNumDic=null,this.hangUpSpawn=0,this.mapPassResultVo=null,this.autoPass=!1,this.lastClickMapPassId=null,this.sortIdList=null,
this.spawnId2TransDic=null,this.isClickAcccess=!1,this.hasRewardCanGet=null,this.loginStartHang=null,this.csvEx=c.Y.Inst.GetOrCreateCsv(n.h.eMapCheckPointResource),
this.mapPassProgressDic=new m.X,this.mapPassVoDic=new m.X,this.spawnKeyDic=new m.X,this.fogIndexDic=new m.X,this.mapDicByHierarchy=new m.X,this.copyKeyMap=new m.X,
this.mapList=new u.Z,this.failNumDic=new m.X
const t=new m.X
this.sortIdList=new u.Z
let e=_.t.GetInstance().map
for(const[i,s]of(0,l.V5)(e)){const e=s.mapId
let i=null,n=null
this.mapPassProgressDic.LuaDic_ContainsKey(e)?(i=this.mapPassProgressDic[e],n=this.fogIndexDic[e]):(i=new T,i.mapId=e,this.mapPassProgressDic.LuaDic_AddOrSetItem(e,i),
this.mapDicByHierarchy.LuaDic_AddOrSetItem(s.hierarchy,e),t.LuaDic_AddOrSetItem(e,s.hierarchy),this.mapList.Add(e),n=new m.X,this.fogIndexDic.LuaDic_AddOrSetItem(e,n)),
0!=s.copyId&&this.copyKeyMap.LuaDic_AddOrSetItem(s.copyId,s.id),n.LuaDic_AddOrSetItem(s.fogId,s.id),i.UpdateMaxLevel(s.checkpoint),
this.spawnKeyDic.LuaDic_AddOrSetItem(s.spawnId,s.id)
const l=new R
l.SetResData(s),this.mapPassVoDic.LuaDic_AddOrSetItem(l.id,l),this.sortIdList.Add(l)}for(const[t,e]of(0,l.V5)(this.mapPassProgressDic)){e.mapPassList.Clear()
for(let t=1;t<=e.maxLevel;t++){const i=this.GetMapPassVoByMapAndLevel(e.mapId,t)
e.mapPassList.Add(i)}}this.mapList.Sort(((e,i)=>t[e]<t[i]?-1:t[e]>t[i]?1:0)),t.Clear(),
this.sortIdList.Sort(((t,e)=>t.res.hierarchy<e.res.hierarchy?-1:t.res.hierarchy>e.res.hierarchy?1:t.res.checkpoint<e.res.checkpoint?-1:t.res.checkpoint>e.res.checkpoint?1:0)),
this.spawnId2TransDic=new m.X,e=C.j.GetInst().map
for(const[t,i]of(0,l.V5)(e)){const t=i.GetArrMultipleExp()
if(null!=t)for(let e=0;e<=t.Count()-1;e++){const i=t[e][2],s=p.e.Inst_get().GetCfgById(i).spawnId
this.spawnId2TransDic[s]=i}}}static Inst(){return null==t.inst&&(t.inst=new t),t.inst}Reset(){for(const[t,e]of(0,l.V5)(this.mapPassProgressDic))e.Clear()
for(const[t,e]of(0,l.V5)(this.mapPassVoDic))e.Clear()
this.rewardTipsVo=null,this.nextTipsVo=null,this.nowFightVo=null,this.MapPassResultVo=null,this.totalPassNum=0,this.poisonLevel=0,this.poisonMapId=0,this.hasRewardCanGet=!1,
this.lastClickMapPassId=null,this.autoPass=!1,this.loginStartHang=!1,this.failNumDic.Clear()}UpdateProgressDic(t){let e=0
null==t||(e=this.mapPassVoDic[t].res.mapId)
for(const[t,i]of(0,l.V5)(this.mapPassVoDic))if(0==e||i.res.mapId==e){const t=this.mapPassProgressDic[i.res.mapId]
i.hasServer&&t.UpdateNowLevel(i.res.checkpoint),t.UpdateReward(i)}for(const[t,i]of(0,l.V5)(this.mapPassVoDic))if(0==e||i.res.mapId==e){const t=this.mapPassProgressDic[i.res.mapId]
t.nowLevel>i.res.checkpoint?i.UpdateState(M.s.PASS):t.nowLevel==i.res.checkpoint&&(t.nowLevel==t.maxLevel?i.UpdateState(M.s.PASS):i.UpdateState(M.s.FIGHT),
(null==this.nowFightVo||this.nowFightVo.res.hierarchy<i.res.hierarchy||this.nowFightVo.res.hierarchy==i.res.hierarchy&&this.nowFightVo.res.checkpoint<i.res.checkpoint)&&(this.nowFightVo=i))
}this.UpdateHasReward()}GetCloseVos(t){const e=this.GetMapPassVo(t),i=this.GetMapPassProgressVoByMapId(e.res.mapId)
let[s,n,l]=[null,null,null]
const a=e.res.checkpoint
for(let t=1;t<=i.maxLevel;t++){const i=this.GetMapPassVoByMapAndLevel(e.res.mapId,t)
if(null==s)s=i
else if(null==n)n=i
else if(null==l)l=i
else{
const t=Math.abs(s.res.checkpoint-a)-Math.abs(i.res.checkpoint-a),e=Math.abs(n.res.checkpoint-a)-Math.abs(i.res.checkpoint-a),o=Math.abs(l.res.checkpoint-a)-Math.abs(i.res.checkpoint-a)
;(t>0||e>0||o>0)&&(t>e&&t>o?s=i:e>t&&e>o?n=i:o>t&&o>e&&(l=i))}}return[s.id||0,n.id||0,l.id||0]}UpdateHasReward(){const t=this.hasRewardCanGet,e=this.mapPassProgressDic
this.hasRewardCanGet=!1
for(const[t,i]of(0,l.V5)(e)){if(null!=i.GetNearRewardLevelCanGet(1)){this.hasRewardCanGet=!0
break}}t!=this.hasRewardCanGet&&this.RaiseEvent(D.Z.UpdateGetRewardState)}HasRewardGet(){return this.hasRewardCanGet}IsFix(){const t=this.GetMapId(),e=this.GetHighestGateByMap(t)
if(null==e)return!1
const i=this.GetNextPassVo(e)
if(null!=i){const t=i.CanChallengeBoss()
return 0==t||1==t}return!1}NowIsTaskLimit(){if(null!=this.nowFightVo){const t=this.GetNextPassVo(this.nowFightVo)
if(null!=t&&4==t.CanChallengeBoss())return!0}return!1}GetResBySpawnId(t){const e=this.spawnKeyDic[t]
return this.csvEx.GetItemById(e)}GetMapPassVo(t){return this.mapPassVoDic[t]}GetMapPassVoBySpawnId(t){const e=this.spawnKeyDic[t]
return this.GetMapPassVo(e)}GetMapPassVoByMapAndLevel(t,e){const i=`${t}_${e}`
return this.GetMapPassVo(i)}GetMapPassProgressVoByMapId(t){return this.mapPassProgressDic[t]}GetMaxPassMapId(t){return null!=this.nowFightVo?this.nowFightVo.res.mapId:10001}
GetMapIdByHierarchy(t){return this.mapDicByHierarchy[t]}GetNextPassVo(t,e){let i=null
if(null!=t){const s=this.GetMapPassProgressVoByMapId(t.res.mapId)
if(s.isPass){if(1==e&&this.mapList.Count()>t.res.hierarchy){const e=this.mapList[t.res.hierarchy]
i=this.GetMapPassVoByMapAndLevel(e,1)}}else i=this.GetMapPassVoByMapAndLevel(t.res.mapId,s.nowLevel+1)}return i}GetSortKeyByMapPassVo(t){const e=this.sortIdList.Count()
let i=0
if(null!=t)for(let s=0;s<=e-1;s++)this.sortIdList[s].id==t.id&&(i=s)
return i}GetMapPassVoBySortKey(t){return t<0||t>=this.sortIdList.Count()?null:this.sortIdList[t]}GetHighestUnPassMapPassVo(){const t=this.mapList
let e=null
if(null!=this.nowFightVo&&(e=this.GetNextPassVo(this.nowFightVo,!0)),null!=e)return e
for(let e=t.Count()-1;e>=0;e+=-1){const i=t[e],s=this.GetMapPassProgressVoByMapId(i)
if(!(s.nowLevel>0))return this.GetMapPassVoByMapAndLevel(i,1)
if(s.nowLevel<s.maxLevel)return this.GetMapPassVoByMapAndLevel(i,s.nowLevel+1)}}GetCurMonId(t){const e=this.GetMapId(),i=this.GetHighestGateByMap(e)
if(null!=i){const t=i.res,e=this.GetMapPassVoByMapAndLevel(t.mapId,t.checkpoint)
if(null!=e){return this.GetTransVoById(e.id).objectId}}return 0}GetTransVoById(t){const e=this.csvEx.GetItemById(t).spawnId,i=this.spawnId2TransDic[e]
return null!=i?p.e.Inst_get().GetCfgById(i):(d.Y.LogError(`找不到刷怪表id${e}对应的小飞鞋id  这个是从smallmap表里解析出来的 `),null)}GetMapPassVoByCopyId(t){const e=this.copyKeyMap[t]
return null!=e?this.GetMapPassVo(e):null}SetHangUpSpawn(){if(null!=a.Y.Inst&&null!=a.Y.Inst.PrimaryRole_get()){
const t=this.GetMapId(),e=this.GetMapPassProgressVoByMapId(t),i=new I.P,s=new I.P
this.hangUpSpawn=0,a.Y.Inst.PrimaryRole_get().GetCurPos(i)
let[n,l]=[-1,-1]
if(null!=e){for(let a=1;a<=e.nowLevel;a++){const e=this.GetMapPassVoByMapAndLevel(t,a).res.spawnId,o=S.h.GetInst().GetSpwanItemById(e)
s.Set(o.x,0,o.y)
const r=g.l.FastDistanceVector3XZ(i,s)
let h=o.exitRange
h*=h,(-1==n||n>r)&&r<=h&&(n=r,l=e)}if(-1!=l){this.hangUpSpawn=l
const t=S.h.GetInst().GetSpwanItemById(l)
o.S.getInst().hangMonsterId=new u.Z([t.objectKey])}}}}GetHighestGateByMap(t){const e=this.GetMapPassProgressVoByMapId(t)
return null!=e?this.GetMapPassVoByMapAndLevel(t,e.nowLevel):null}GetHangSpawnId(){return this.hangUpSpawn}PosIsInSpawnRange(t){
const e=S.h.GetInst().GetSpwanItemById(this.hangUpSpawn),i=new I.P(e.x,0,e.y),s=g.l.FastDistanceVector3XZ(t,i)
return I.P.Recyle(i),s<e.bornRange}SetAutoPass(t,e){const i=this.autoPass
if(null==t&&(t=!this.autoPass),t){const e=this.GetMapId(),i=this.GetMapPassProgressVoByMapId(e)
if(null==i)return void y.y.inst.ClientSysStrMsg("请前往野外挑战关卡BOSS")
if(i.nowLevel==i.maxLevel)y.y.inst.ClientSysStrMsg("已达到当前地图最大关卡不可自动")
else{const s=this.GetMapPassVoByMapAndLevel(e,i.nowLevel+1)
if(null!=s){const e=s.CanChallengeBoss()
1==e||2==e?o.S.getInst().isInSafeArea?y.y.inst.ClientSysStrMsg("请前往野外挑战关卡BOSS"):this.autoPass=t:4==e?y.y.inst.ClientSysStrMsg("继续完成主线后可自动挑战"):3==e&&y.y.inst.ClientSysStrMsg(`等级达到${s.res.unlockLevel}级后可继续挑战`)
}}}else this.autoPass=t
this.autoPass&&i!=this.autoPass&&(y.y.inst.ClientSysStrMsg("开启自动挑战成功"),w.N.Inst().CheckAutoLis(!0)),e&&i!=this.autoPass&&this.autoPass&&y.y.inst.ClientSysStrMsg("自动挑战已关闭")}
GetIdByMapIdAndFogId(t,e){const i=this.fogIndexDic[t]
return null!=i?i[e]:null}CalFailNum(t){this.failNumDic.LuaDic_ContainsKey(t)?this.failNumDic[t]=this.failNumDic[t]+1:this.failNumDic.LuaDic_AddOrSetItem(t,1)}GetFailNum(t){
const e=this.GetMapPassVo(t)
let i=0
if(null!=e){const t=e.res.hierarchy,s=e.res.checkpoint
for(const[e,n]of(0,l.vy)(this.failNumDic))if(this.failNumDic.LuaDic_ContainsKey(e)){const n=e,l=this.GetMapPassVo(n)
;(l.res.hierarchy>t||l.res.hierarchy==t&&l.res.checkpoint>=s)&&(i+=this.failNumDic[e])}}return i}GetMapId(){
return f.X.Inst_get().IsMultipleExpHangMap(!0)?r.b.Inst.GetCurMap().relatedMapId:r.b.Inst.currentMapId_get()}},L.inst=null,G=v=L,O="Inst",E=[s.Vx],
B=Object.getOwnPropertyDescriptor(v,"Inst"),k=v,x={},Object.keys(B).forEach((function(t){x[t]=B[t]})),x.enumerable=!!x.enumerable,x.configurable=!!x.configurable,
("value"in x||x.initializer)&&(x.writable=!0),x=E.slice().reverse().reduce((function(t,e){return e(G,O,t)||t}),x),
k&&void 0!==x.initializer&&(x.value=x.initializer?x.initializer.call(k):void 0,x.initializer=void 0),void 0===x.initializer&&(Object.defineProperty(G,O,x),x=null),A=v))||A
var G,O,E,B,k,x},2465:(t,e,i)=>{i.d(e,{V:()=>v})
var s=i(6847),n=i(83908),l=i(49655),a=i(46282),o=i(83900),r=i(21267),h=i(18998),d=i(32076),c=i(98800),u=i(97461),m=i(85602),I=i(79534),g=i(15821),_=i(41864),p=i(62783),C=i(31931),S=i(12970),f=i(21334),y=i(91690),w=i(74657)
class D extends((0,n.yk)()){constructor(...t){super(...t),this.baseItemData=null,this.mapPassVo=null}InitView(){super.InitView()}AddLis(){}RemoveLis(){}Clear(){
this.baseItemData=null}Destroy(){super.destroy()}SetData(t){this.AddLis()
const e=t[0],i=t[1]
this.mapPassVo=r.u.Inst().GetMapPassVoByMapAndLevel(e,i),this.levelNum.textSet(i)
const s=w.A.GetReward(this.mapPassVo.res.allPassReward).GetJobLimitItemList()[0]
this.ui_baseitem.SetData(s),this.mapPassVo.CanGetReward()?this.eff.SetActive(!0):this.eff.SetActive(!1),this.mapPassVo.reward?this.isGat.SetActive(!0):this.isGat.SetActive(!1),
this.baseItemData=s}}class T extends((0,n.yk)()){constructor(...t){super(...t),this.mapId=null,this.model=null,this.mapPassVo=null,this.hasBossChallenge=null,
this.getRewardLevel=null,this.haveRewardCanGet=null,this.index=0}InitView(){super.InitView(),this.MyGrid.SetInitInfo("ui_map_pass_reward_baseitem",null,D),
this.MyGrid.OnReposition_set(this.CreateDelegate(this.OnRepostion)),this.mapId=0,this.model=r.u.Inst()}AddLis(){this.btngo.node.on(h.NodeEventType.TOUCH_END,this.onClick1,this),
this.btnget.node.on(h.NodeEventType.TOUCH_END,this.onClick1,this),this.btnboss.node.on(h.NodeEventType.TOUCH_END,this.onClick1,this),
r.u.Inst().AddEventHandler(y.Z.UpdateMapPassInfo,this.CreateDelegate(this.UpdateView)),u.i.Inst.AddEventHandler(g.i.NEWBIE_GUANKA_REWARD,(0,d.v)(this.onExecNewbie,this))}
RemoveLis(){this.btngo.node.off(h.NodeEventType.TOUCH_END,this.onClick1,this),this.btnget.node.off(h.NodeEventType.TOUCH_END,this.onClick1,this),
this.btnboss.node.off(h.NodeEventType.TOUCH_END,this.onClick1,this),r.u.Inst().RemoveEventHandler(y.Z.UpdateMapPassInfo,this.CreateDelegate(this.UpdateView)),
u.i.Inst.RemoveEventHandler(g.i.NEWBIE_GUANKA_REWARD,(0,d.v)(this.onExecNewbie,this))}onExecNewbie(t){this.mapId==t&&o.N.Inst().CM_RewardMapAllRewardHandle(this.mapId)}onClick1(t){
let e=t.target.name
if(e==this.btnboss.node.name)p.X.inst.OpenMapPanel(p.X.WORD_MAP,this.mapId,null,null,!0),o.N.Inst().CloseMappassRewardView()
else if(e==this.btngo.node.name){const t=r.u.Inst().GetHighestGateByMap(this.mapId)
o.N.Inst().GotoKillMonsterOrBoss(t,!0,!1,!1),o.N.Inst().CloseMappassRewardView()}else e==this.btnget.node.name&&o.N.Inst().CM_RewardMapAllRewardHandle(this.mapId)}Clear(){
this.RemoveLis()}Destroy(){super.destroy()}SetData(t){this.AddLis(),this.mapId=t,this.UpdateView()}UpdateView(){this.mapPassVo=this.model.GetHighestGateByMap(this.mapId)
const t=f.p.Inst_get().GetMapById(this.mapId)
this.icon.skin="preload:/atlas/ditu/"+t.senceUi,this.nameLabel.textSet(t.name),null!=this.mapPassVo?this.text_point.textSet(this.mapPassVo.res.checkpoint):this.text_point.textSet("0")
const e=this.model.GetMapPassProgressVoByMapId(this.mapId),i=e.GetRewardLevelList()||new m.Z,s=i.Count(),n=271/s
let l=0
const a=e.nowLevel
if(s>0)for(let t=0;t<=i.Count()-1;t++){let e=0
a>=i[t]?e=1:0==t?e=a/i[t]:a>i[t-1]&&(e=(a-i[t-1])/(i[t]-i[t-1])),l+=0==t?(n-41)*e:n*e}else l=0
this.progressSlider.DoF_SetValue(l,230)
const o=new m.Z
for(let t=0;t<=i.Count()-1;t++)o.Add([this.mapId,i[t]])
this.MyGrid.data_set(o)
let r=!1
this.hasBossChallenge=!1
const h=S.F.getInst().GetCanEnterMapByLvAndTransfer(this.mapId),d=f.p.Inst_get().GetLastMapIsOpen(this.mapId)
if(h==C.f.CAN?(this.lvLabel.textSet(""),r=!0):d&&h==C.f.BOSS_LIMIT?(this.lvLabel.textSet(""),this.hasBossChallenge=!0):this.lvLabel.textSet(_.h.GetLevelStr(t.minLevelLimit)),
this.btnget.node.SetActive(!1),this.btngo.node.SetActive(!1),this.btnboss.node.SetActive(!1),this.isAllGet.SetActive(!1),r)if(this.getRewardLevel=e.GetNearRewardLevelCanGet(1),
null!=this.getRewardLevel)this.btnget.node.SetActive(!0)
else{this.haveRewardCanGet=e.GetNearRewardLevelCanGet(2)
const t=this.model.GetHighestGateByMap(this.mapId),i=this.model.GetNextPassVo(t)
null!=i&&null!=this.haveRewardCanGet?c.Y.Inst.PrimaryRoleInfo_get().Level_get()>=i.res.unlockLevel?this.btngo.node.SetActive(!0):this.lvLabel.textSet(_.h.GetLevelStr(i.res.unlockLevel)):this.isAllGet.SetActive(!0)
}else this.hasBossChallenge&&this.btnboss.node.SetActive(!0)
this.ChangeBgSprtite()}OnCreateItem(t){}OnRepostion(){this.MakeOffset()}MakeOffset(){const t=this.MyGrid.itemList.Count()
let e=1
t>0&&(e=271/t)
const i=new I.P
for(let s=0;s<=t-1;s++)i.Set(e*(s+1),0,0),this.MyGrid.itemList[s].offset.transform.SetLocalPosition(i)
I.P.Recyle(i)}ChangeBgSprtite(){const t=this.index%3
0==t?(this.bg1.skin="preload:/atlas/ditu/ryditu_sp_0076",this.bg2.skin="preload:/atlas/ditu/ryditu_sp_0073"):1==t?(this.bg1.skin="preload:/atlas/ditu/ryditu_sp_0077",
this.bg2.skin="preload:/atlas/ditu/ryditu_sp_0074"):2==t&&(this.bg1.skin="preload:/atlas/ditu/ryditu_sp_0078",this.bg2.skin="preload:/atlas/ditu/ryditu_sp_0088")}}var A
let v=(0,s.s_)(l.o.MapPassRewardView,a.Z.ui_map_pass_reward_view).waitPrefab(a.Z.ui_baseitem).register()(A=class extends((0,n.Ri)()){constructor(...t){super(...t),this.model=null,
this.isFirstEnter=!1}InitView(){super.InitView(),this.grid.SetInitInfo("ui_map_pass_reward_item",null,T),this.grid.OnReposition_set(this.CreateDelegate(this.OnReposition)),
this.model=r.u.Inst()}AddLis(){this.m_handlerMgr.AddClickEvent(this.closebtn,this.CreateDelegate(this.Close))}RemoveLis(){}Clear(){this.RemoveLis(),super.Clear()}Destroy(){
super.destroy()}OnAddToScene(){this.isFirstEnter=!0,this.AddLis()
const t=this.model.mapList
this.grid.data_set(t)}RenderItem(t,e){let i=t[0].getCNode(T)
return i.index=e,i}OnReposition(t){const e=this.model.mapList
for(let t=0;t<=e.Count()-1;t++){const i=e[t]
if(null!=r.u.Inst().GetMapPassProgressVoByMapId(i).GetNearRewardLevelCanGet(1))return void(this.isFirstEnter&&(this.grid.scrollTo(t),this.isFirstEnter=!1))}
const i=r.u.Inst().nowFightVo
if(null!=i)for(let t=0;t<=e.Count()-1;t++){if(e[t]==i.res.mapId)return void(this.isFirstEnter&&(this.grid.scrollTo(t),this.isFirstEnter=!1))}}Close(){
o.N.Inst().CloseMappassRewardView()}})||A},98504:(t,e,i)=>{i.d(e,{s:()=>s})
class s{}s.LOCK=1,s.FIGHT=2,s.PASS=3},87791:(t,e,i)=>{i.d(e,{A:()=>V})
var s,n,l=i(6847),a=i(83908),o=i(17409),r=i(49655),h=i(46282),d=i(40053),c=i(43662),u=i(5583),m=i(23833),I=i(98800),g=i(96098),_=i(91238),p=i(26055),C=i(87722),S=i(32697),f=i(20583),y=i(50838),w=i(31546),D=i(36241),T=i(13687),A=i(82737),v=i(5494),L=i(98885),M=i(85602),b=i(46899),R=i(6453),P=i(75696),G=i(27122),O=i(55552),E=i(43308),B=i(77486),k=i(79534),x=i(21267)
let V=(0,l.s_)(r.o.MapPassNextTips,h.Z.ui_map_pass_info_tip).waitPrefab(d.Z.RyForgeModel_basePrefabs).waitPrefab(d.Z.RyForgeEquipListItem_baseItemPrefabs).register()((n=class t extends((0,
a.Ri)()){constructor(...t){super(...t),this.model=null,this.mapPassVo=null,this.monsterVo=null,this.nowMapPassVo=null,this.transVo=null,this.boss=null,
this.displayUIAvatarModel=null}_initBinder(){super._initBinder(),t.STAGE_ID=115}InitView(){super.InitView(),this.wayGrid.SetInitInfo("ui_ry_forge_wayItem",null,B.Z),
this.grid_item.SetInitInfo("ui_baseitem",null,P.j),(0,o.D1)(this,this.CreateDelegate(this.Close)),this.model=x.u.Inst(),this.displayUIAvatarModel=new y.o,
this.displayUIAvatarModel.SetTarget(this.bossTexture,!0),this.bossTexture.node.scale=new k.P(.5,.5,.5)}Clear(){this.wayGrid.Clear(),this.grid_item.Clear(),this.ClearBoss()}
Destroy(){(0,o.Rt)(this),super.destroy()}OnAddToScene(){this.AddLis(),this.UpdateView()}AddLis(){this.m_handlerMgr.AddClickEvent(this.btn_go,this.CreateDelegate(this.OnClickBtnGo))
}UpdateView(){this.mapPassVo=this.model.nextTipsVo
const t=this.mapPassVo.res
I.Y.Inst.PrimaryRoleInfo_get()
if(this.monsterVo=null,0!=t.bossId){const e=O.h.GetInst().GetSpwanItemById(t.bossId).objectKey
this.monsterVo=m.a.getInst().getObjById(e)}const e=this.mapPassVo.CanChallengeBoss()
if(4==e){if(this.img_bg.heightSet(415),this.wayGrid.node.SetActive(!1),this.grid_item.node.SetActive(!0),this.btn_go.node.SetActive(!1),this.unlockShow.SetActive(!1),
this.questLabel.node.SetActive(!0),1==t.checkpoint)return
this.nowMapPassVo=this.model.GetMapPassVoByMapAndLevel(t.mapId,t.checkpoint-1)
const e=this.nowMapPassVo.res
let i=`${e.mapName}${e.name} 击败{0}只小怪可挑战${this.monsterVo.name}`
i=L.M.ReplaceOne(i,"{0}",`[5FB470]${this.nowMapPassVo.killNum}/${this.mapPassVo.needKill}[-]`),this.text_name.textSet(i),
this.transVo=this.model.GetTransVoById(this.nowMapPassVo.id),this.questLabel.textSet("继续主线任务后可挑战")}else if(3==e){this.img_bg.heightSet(485),this.grid_item.node.SetActive(!1),
this.wayGrid.node.SetActive(!0),this.btn_go.node.SetActive(!1),this.unlockShow.SetActive(!0),this.questLabel.node.SetActive(!1)
let e=""
null==this.monsterVo?e=`${this.mapPassVo.res.unlockLevel}级可开启关卡`:(e=`${this.mapPassVo.res.unlockLevel}级可继续挑战${this.monsterVo.name}`,
e=L.M.ReplaceOne(e,"{0}",this.mapPassVo.needKill)),this.text_name.textSet(e)
const i=new M.Z(t.upgradeAccess),s=b.m.FillDataList(i),n=R.R.ins.GetShowAccessData(s)
this.wayGrid.data_set(n),this.transVo=null}else if(1==e||2==e){if(this.img_bg.heightSet(415),this.wayGrid.node.SetActive(!1),this.grid_item.node.SetActive(!0),
this.btn_go.node.SetActive(!0),this.unlockShow.SetActive(!1),this.questLabel.node.SetActive(!1),1==t.checkpoint)return
this.nowMapPassVo=this.model.GetMapPassVoByMapAndLevel(t.mapId,t.checkpoint-1)
const e=this.nowMapPassVo.res
let i=`${e.mapName}${e.name} 击败{0}只小怪可挑战${this.monsterVo.name}`
i=L.M.ReplaceOne(i,"{0}",`[047104]${this.nowMapPassVo.killNum}/${this.mapPassVo.needKill}[-]`),this.text_name.textSet(i),
this.transVo=this.model.GetTransVoById(this.nowMapPassVo.id)}const i=u.L.GetRewardValuesConfig(t.successReward).GetItemList()
this.grid_item.data_set(i),this.ShowModel()}ShowModel(){c.M.Instance_get().ActiveStage(t.STAGE_ID)
const e=this.monsterVo
if(null!=e){const i=new p.O
this.ClearBoss(),this.boss=G.Q.Inst().GetObjectByName("MonsterCharacter",C._),this.boss.Info_set(i)
const s=new w.O
s._displayID=e.displayId,s._world=c.M.Instance_get().GetStageWorldType(t.STAGE_ID),s._bNeedWaitAnime=!0,s.shiledType=A.g.DT_NONE,this.boss.InitPhotoByInfo(e,s,0),
c.M.Instance_get().SetDisplayObject(t.STAGE_ID,this.boss.MainRole_get().handle,0),c.M.Instance_get().SetWorldRotation(t.STAGE_ID,0,new k.P),
0==e.scale?this.boss.SetSize(1):this.boss.SetSize(e.scale/1e4),null!=e.rotationList&&this.boss.setDirectionXYZ(new k.P(e.rotationList[0],e.rotationList[1],e.rotationList[2])),
this.displayUIAvatarModel=f.x.inst.SetUIAvatarData(s,S.v.monster,this.displayUIAvatarModel)}}ClearBoss(){null!=this.boss&&(this.boss.Destroy(),this.boss=null)}OnClickBtnGo(){
if(D._.getInst().endHang(),this.transVo.targetMapId==T.b.Inst.currentMapId_get())this.FindPath()
else{const t=this.transVo
g.B.Inst.GotoPathByPlayerTransportCfg(this.transVo,_.m.Point,(()=>{E._.Inst_get().OnGoGuaji(t)}),null,null)}this.Close()}FindPath(){E._.Inst_get().OnGoGuaji(this.transVo)}Close(){
(0,o.sR)(v.I.MapPassNextTips)}},n.STAGE_ID=null,s=n))||s},7517:(t,e,i)=>{var s,n=i(6847),l=i(83908),a=i(46282),o=i(5494);(0,
n.s_)(o.I.MapTransportMask,a.Z.ui_map_transport_mask).register()(s=class extends((0,l.Ri)()){_initBinder(){super._initBinder()}InitView(){super.InitView()}Clear(){}Destroy(){}
OnAddToScene(){this.AddLis(),this.UpdateView()}AddLis(){}UpdateView(){}})},96574:(t,e,i)=>{i.d(e,{N:()=>n})
var s=i(79534)
class n{constructor(){this.id=null,this.itemData=null,this.isGrounding=!1,this.totalPrice=0,this.auctionPrice=0,this.isAuction=!1,this.startTime=0,this.endTime=0,this.resId=0,
this.isShowTip=!0,this.isGray=!1,this.tipPos=null,this.isAutoOpenTip=!1,this.tipPos=s.P.zero_get()}}},14140:(t,e,i)=>{i.d(e,{b:()=>O})
var s=i(98800),n=i(99294),l=i(9776),a=i(93877),o=i(72005),r=i(30849),h=i(18202),d=i(83540),c=i(98885),u=i(85602),m=i(79534),I=i(87923),g=i(44498),_=i(35950),p=i(80891),C=i(91959),S=i(11751),f=i(17081),y=i(87666),w=i(6816),D=i(86676),T=i(76195),A=i(75390),v=i(78248),L=i(85174),M=i(25220),b=i(30726),R=i(75439),P=i(68561),G=i(99130)
class O extends r.C{constructor(){super(),this.scrollView=null,this.qualityBg=null,this.equipIcon=null,this.lockObj=null,this.equipLv=null,this.nameLabel=null,this.usingObj=null,
this.stepLabel=null,this.typeLabel=null,this.timeModule=null,this.demandModule=null,this.baseModule=null,this.excellenceModule=null,this.normalSuitModule=null,
this.enhanceSuitModule=null,this.enhanceWingrefineModule=null,this.descLabel=null,this.scoreLabel=null,this.scoreObj=null,this.descChannelLabel=null,this.descObj=null,
this.descChannelObj=null,this.totalScoreLabel=null,this.totalScore=null,this.auctionModule=null,this.qualityAnimOne=null,this.qualityAnimTwo=null,this.qualityAnimThree=null,
this.qualityAnimFour=null,this.qualityAnimFive=null,this.qualityAnimSix=null,this.jewelModule=null,this.legendModule=null,this.holyModule=null,this.angelModule=null,
this.specialModule=null,this.skillModule=null,this.godModule=null,this.angelSuitModule=null,this.masterSuitModule=null,this.typeModule=null,this.isCanOperate=!1,this.ir=null,
this.er=null,this.eInfo=null,this.equipment=null,this.itemData=null,this.bagItemData=null,this.role=null,this.qualityAnimList=null,this.readyCnt=0,this.excellenceCnt=0,this.star=0,
this.curData=null,this.qualityAnimList=new u.Z}ReadyCnt_get(){return this.readyCnt}ReadyCnt_set(t){this.readyCnt=t,this.readyCnt>=18&&(this.Relayout(),
this.scrollView.ResetPosition())}InitView(){super.InitView(),this.scrollView=new l.h,this.scrollView.setId(this.FatherId,this.FatherComponentID,1),this.qualityBg=new o.w,
this.qualityBg.setId(this.FatherId,this.FatherComponentID,2),this.equipIcon=new o.w,this.equipIcon.setId(this.FatherId,this.FatherComponentID,3),this.lockObj=new n.z,
this.lockObj.setId(this.FatherId,this.FatherComponentID,4),this.equipLv=new a.Q,this.equipLv.setId(this.FatherId,this.FatherComponentID,5),this.nameLabel=new a.Q,
this.nameLabel.setId(this.FatherId,this.FatherComponentID,6),this.usingObj=new n.z,this.usingObj.setId(this.FatherId,this.FatherComponentID,7),this.stepLabel=new a.Q,
this.stepLabel.setId(this.FatherId,this.FatherComponentID,8),this.typeLabel=new a.Q,this.typeLabel.setId(this.FatherId,this.FatherComponentID,9),this.timeModule=new L.I,
this.timeModule.setBinderId(this.FatherId,this.FatherComponentID,10),this.demandModule=new f.k,this.demandModule.setBinderId(this.FatherId,this.FatherComponentID,11),
this.baseModule=new S.$,this.baseModule.setBinderId(this.FatherId,this.FatherComponentID,12),this.excellenceModule=new y.f,
this.excellenceModule.setBinderId(this.FatherId,this.FatherComponentID,13),this.normalSuitModule=new v.q,this.normalSuitModule.setBinderId(this.FatherId,this.FatherComponentID,14),
this.enhanceSuitModule=new v.q,this.enhanceSuitModule.setBinderId(this.FatherId,this.FatherComponentID,15),this.descLabel=new a.Q,
this.descLabel.setId(this.FatherId,this.FatherComponentID,16),this.scoreLabel=new a.Q,this.scoreLabel.setId(this.FatherId,this.FatherComponentID,17),this.scoreObj=new n.z,
this.scoreObj.setId(this.FatherId,this.FatherComponentID,19),this.enhanceWingrefineModule=new b.g,this.enhanceWingrefineModule.setBinderId(this.FatherId,this.FatherComponentID,20),
this.descChannelLabel=new a.Q,this.descChannelLabel.setId(this.FatherId,this.FatherComponentID,21),this.descObj=new n.z,this.descObj.setId(this.FatherId,this.FatherComponentID,23),
this.descChannelObj=new n.z,this.descChannelObj.setId(this.FatherId,this.FatherComponentID,24),this.totalScoreLabel=new a.Q,
this.totalScoreLabel.setId(this.FatherId,this.FatherComponentID,25),this.totalScore=new n.z,this.totalScore.setId(this.FatherId,this.FatherComponentID,26),
this.auctionModule=new C.N,this.auctionModule.setBinderId(this.FatherId,this.FatherComponentID,27),this.qualityAnimOne=new n.z,
this.qualityAnimOne.setId(this.FatherId,this.FatherComponentID,28),this.qualityAnimTwo=new n.z,this.qualityAnimTwo.setId(this.FatherId,this.FatherComponentID,29),
this.qualityAnimThree=new n.z,this.qualityAnimThree.setId(this.FatherId,this.FatherComponentID,30),this.qualityAnimFour=new n.z,
this.qualityAnimFour.setId(this.FatherId,this.FatherComponentID,31),this.qualityAnimFive=new n.z,this.qualityAnimFive.setId(this.FatherId,this.FatherComponentID,32),
this.qualityAnimSix=new n.z,this.qualityAnimSix.setId(this.FatherId,this.FatherComponentID,33),this.holyModule=new D.D,
this.holyModule.setBinderId(this.FatherId,this.FatherComponentID,36),this.angelModule=new p.P,this.angelModule.setBinderId(this.FatherId,this.FatherComponentID,37),
this.specialModule=new A.m,this.specialModule.setBinderId(this.FatherId,this.FatherComponentID,38),this.skillModule=new T.F,
this.skillModule.setBinderId(this.FatherId,this.FatherComponentID,39),this.godModule=new w.w,this.godModule.setBinderId(this.FatherId,this.FatherComponentID,40),
this.angelSuitModule=new v.q,this.angelSuitModule.setBinderId(this.FatherId,this.FatherComponentID,41),this.masterSuitModule=new v.q,
this.masterSuitModule.setBinderId(this.FatherId,this.FatherComponentID,42),this.typeModule=new M.m,this.typeModule.setBinderId(this.FatherId,this.FatherComponentID,43),
this.qualityAnimList.Add(null),this.qualityAnimList.Add(this.qualityAnimOne),this.qualityAnimList.Add(this.qualityAnimTwo),this.qualityAnimList.Add(this.qualityAnimThree),
this.qualityAnimList.Add(this.qualityAnimFour),this.qualityAnimList.Add(this.qualityAnimFive),this.qualityAnimList.Add(this.qualityAnimSix),this.AddLis()}Clear(){
G.x.inst.RemoveFormulaValue(),this.RemoveLis(),this.timeModule.ClearTimer(),this.auctionModule.ClearTimer()}AddLis(){this.demandModule.AddLis(),this.masterSuitModule.AddLis(),
this.angelSuitModule.AddLis(),this.normalSuitModule.AddLis(),this.enhanceSuitModule.AddLis(),this.angelModule.AddLis()}RemoveLis(){this.demandModule.clear(),
this.skillModule.Clear(),this.masterSuitModule.Clear(),this.angelSuitModule.Clear(),this.normalSuitModule.Clear(),this.enhanceSuitModule.Clear(),this.angelModule.Clear()}
SetData(t){this.curData=t,this.itemData=this.curData.itemData.baseData_get(),this.bagItemData=this.curData.itemData,this.role=s.Y.Inst.PrimaryRoleInfo_get(),
this.ir=this.itemData.cfgData_get(),this.er=this.itemData.cfgEquipData_get(),this.eInfo=this.itemData.equipInfo_get(),this.equipment=this.itemData.serverData_get(),this.readyCnt=0,
h.g.SetItemIcon(this.equipIcon.FatherId,this.equipIcon.ComponentId,this.itemData.cfgData_get().icon,d.b.eItem,!0),this.lockObj.SetActive(this.itemData.IsBind())
let e=I.l.getEquipQuality(this.equipment,this.eInfo);-1==e&&(e=this.ir.Quality_get()),this.qualityBg.spriteNameSet(I.l.GetQulityBgName(e)),this.SetQualityAnim(e)
P.X.Inst_get().IsEquipHasLucky(this.equipment,this.eInfo)
this.excellenceCnt=P.X.Inst_get().GetEquipExcellenceCount(this.equipment,this.eInfo),this.star=P.X.Inst_get().GetEquipStarLevel(this.equipment,this.eInfo)
P.X.Inst_get().GetEquipEnhanceLevel(this.equipment,this.eInfo)
const i=P.X.Inst_get().GetEquipSuitProperty(this.equipment,this.eInfo),n=P.X.Inst_get().IsSpecialRing(this.equipment,this.eInfo)
P.X.Inst_get().GetEquipGodType(this.equipment,this.eInfo)
this.excellenceCnt>=0&&!n&&this.qualityBg.spriteNameSet(I.l.GetTipQulityBg(e))
const l=R.D.getInstance().GetIntValue("TIPS:MAX_NUM_WORDS"),a=I.l.SetEquipName(this.eInfo,this.ir,this.equipment)
let o=a[0]
a[1]
let r=a[2]
if((i>0||n||this.excellenceCnt>0)&&c.M.Length(r)>l){o=c.M.ReplaceOne(o,c.M.s_SPACE_CHAR,c.M.s_NN_CHAR),r=c.M.ReplaceOne(r,c.M.s_SPACE_CHAR,c.M.s_CCD_CHAR)
const t=c.M.Split(r,c.M.s_CCD_CHAR)
t.Count()>=2&&(r=t[1],c.M.Length(r)>l&&(o=c.M.ReplaceOne(o,c.M.s_SPACE_CHAR,c.M.s_NN_CHAR),o=c.M.ReplaceOne(o,c.M.s_NN_CHAR,c.M.s_SPACE_CHAR)))}this.nameLabel.textSet(o),
null!=this.equipment?(this.scoreLabel.textSet(c.M.IntToString(g.I.InitScore(this.itemData,this.role.Job_get()))),this.scoreObj.SetActive(!0),
this.totalScoreLabel.textSet(c.M.IntToString(g.I.Score(this.itemData,this.role.Job_get()))),this.totalScore.SetActive(!0)):(this.scoreLabel.textSet(""),this.scoreObj.SetActive(!1),
this.totalScoreLabel.textSet(""),this.totalScore.SetActive(!1)),this.typeModule.SetData(this.itemData,this.er,this.equipment,this,!1),
this.demandModule.SetData(this.role,this.eInfo,this.itemData,this.equipment,this,!1),this.timeModule.SetData(this.itemData,this,!1),
this.auctionModule.SetData(this.itemData,this,!1),this.baseModule.SetData(this.role,this.eInfo,this.itemData,this.er,this.ir,this.equipment,this,!1),
this.enhanceWingrefineModule.SetData(!1,this.er,this.equipment),this.excellenceModule.SetData(this.eInfo,this.itemData,this.er,this.ir,this.equipment,this,!1),
this.masterSuitModule.SetData(this.role,this.eInfo,this.er,this.equipment,_.n.eMaster,!1,-1,this,!1),
this.angelSuitModule.SetData(this.role,this.eInfo,this.er,this.equipment,_.n.eAngel,!1,-1,this,!1),
this.normalSuitModule.SetData(this.role,this.eInfo,this.er,this.equipment,_.n.eNormal,!1,-1,this,!1),
this.enhanceSuitModule.SetData(this.role,this.eInfo,this.er,this.equipment,_.n.eEnhance,!1,-1,this,!1),this.holyModule.SetData(this.er,this.equipment,this,!1),
this.angelModule.SetData(this.er,this,!1),this.specialModule.SetData(this.er,this,!1),this.skillModule.SetData(this.er,this.equipment,this,!1),
this.godModule.SetData(this.er,this.ir,this.equipment,this,!1),null==this.ir.describe||""==this.ir.describe?this.descObj.SetActive(!1):(this.descObj.SetActive(!0),
this.descLabel.textSet(this.ir.describe)),null==this.ir.describeChannel||""==this.ir.describeChannel?this.descChannelObj.SetActive(!1):(this.descChannelObj.SetActive(!0),
this.descChannelLabel.textSet(this.ir.describeChannel)),this.scrollView.ResetPosition()}Relayout(){let t=0
const e=m.P.zero_get()
let i=m.P.zero_get(),s=!0
t=this.typeModule.node.GetBoundsSize().y,t>.1&&(m.P.Recyle(i),i=this.typeModule.node.transform.GetLocalPosition(),e.x=i.x,s&&(e.y=0),
this.typeModule.node.transform.SetLocalPosition(e),e.y-=t,s=!1),t=this.timeModule.node.GetBoundsSize().y,t>.1&&(m.P.Recyle(i),i=this.timeModule.node.transform.GetLocalPosition(),
e.x=i.x,e.y-=15,s?e.y=0:e.y+=4,this.timeModule.node.transform.SetLocalPosition(e),e.y-=t,s=!1),t=this.auctionModule.node.GetBoundsSize().y,t>.1&&(m.P.Recyle(i),
i=this.auctionModule.node.transform.GetLocalPosition(),e.x=i.x,e.y-=15,s?e.y=0:e.y+=4,this.auctionModule.node.transform.SetLocalPosition(e),e.y-=t,s=!1),
t=this.demandModule.node.GetBoundsSize().y,t>.1&&(m.P.Recyle(i),i=this.demandModule.node.transform.GetLocalPosition(),e.x=i.x,e.y-=15,s?e.y=0:e.y+=4,
this.demandModule.node.transform.SetLocalPosition(e),e.y-=t,s=!1),t=this.legendModule.node.GetBoundsSize().y,t>.1&&(m.P.Recyle(i),
i=this.legendModule.node.transform.GetLocalPosition(),e.x=i.x,e.y-=15,s?e.y=0:e.y+=4,this.legendModule.node.transform.SetLocalPosition(e),e.y-=t,s=!1),
t=this.holyModule.node.GetBoundsSize().y,t>.1&&(m.P.Recyle(i),i=this.holyModule.node.transform.GetLocalPosition(),e.x=i.x,e.y-=15,s?e.y=0:e.y+=4,
this.holyModule.node.transform.SetLocalPosition(e),e.y-=t,s=!1),t=this.angelModule.node.GetBoundsSize().y,t>.1&&(m.P.Recyle(i),i=this.angelModule.node.transform.GetLocalPosition(),
e.x=i.x,e.y-=15,s?e.y=0:e.y+=4,this.angelModule.node.transform.SetLocalPosition(e),e.y-=t,s=!1),t=this.specialModule.node.GetBoundsSize().y,t>.1&&(m.P.Recyle(i),
i=this.specialModule.node.transform.GetLocalPosition(),e.x=i.x,e.y-=15,s?e.y=0:e.y+=4,this.specialModule.node.transform.SetLocalPosition(e),e.y-=t,s=!1),
t=this.skillModule.node.GetBoundsSize().y,t>.1&&(m.P.Recyle(i),i=this.skillModule.node.transform.GetLocalPosition(),e.x=i.x,e.y-=15,s?e.y=0:e.y+=4,
this.skillModule.node.transform.SetLocalPosition(e),e.y-=t,s=!1),t=this.godModule.node.GetBoundsSize().y,t>.1&&(m.P.Recyle(i),i=this.godModule.node.transform.GetLocalPosition(),
e.x=i.x,e.y-=15,s?e.y=0:e.y+=4,this.godModule.node.transform.SetLocalPosition(e),e.y-=t,s=!1),t=this.excellenceModule.luckyObj.GetBoundsSize().y,t>.1&&(m.P.Recyle(i),
i=this.excellenceModule.luckyObj.transform.GetLocalPosition(),e.x=i.x,e.y-=15,s?e.y=0:e.y+=4,this.excellenceModule.luckyObj.transform.SetLocalPosition(e),e.y-=t,s=!1),
t=this.excellenceModule.ignoreObj.GetBoundsSize().y,t>.1&&(m.P.Recyle(i),i=this.excellenceModule.ignoreObj.transform.GetLocalPosition(),e.x=i.x,e.y-=15,s?e.y=0:e.y+=4,
this.excellenceModule.ignoreObj.transform.SetLocalPosition(e),e.y-=t,s=!1),t=this.excellenceModule.excellenceObj.GetBoundsSize().y,t>.1&&(m.P.Recyle(i),
i=this.excellenceModule.excellenceObj.transform.GetLocalPosition(),e.x=i.x,e.y-=15,s?e.y=0:e.y+=4,this.excellenceModule.excellenceObj.transform.SetLocalPosition(e),e.y-=t,s=!1),
t=this.excellenceModule.auctionExcellenceObj.GetBoundsSize().y,t>.1&&(m.P.Recyle(i),i=this.excellenceModule.auctionExcellenceObj.transform.GetLocalPosition(),e.x=i.x,e.y-=15,
s?e.y=0:e.y+=4,this.excellenceModule.auctionExcellenceObj.transform.SetLocalPosition(e),e.y-=t,s=!1),t=this.excellenceModule.fourStarObj.GetBoundsSize().y,t>.1&&(m.P.Recyle(i),
i=this.excellenceModule.fourStarObj.transform.GetLocalPosition(),e.x=i.x,e.y-=15,s?e.y=0:e.y+=4,this.excellenceModule.fourStarObj.transform.SetLocalPosition(e),e.y-=t,s=!1),
t=this.excellenceModule.fiveStarObj.GetBoundsSize().y,t>.1&&(m.P.Recyle(i),i=this.excellenceModule.fiveStarObj.transform.GetLocalPosition(),e.x=i.x,e.y-=15,s?e.y=0:e.y+=4,
this.excellenceModule.fiveStarObj.transform.SetLocalPosition(e),e.y-=t,s=!1),t=this.excellenceModule.excellenceShowObj.GetBoundsSize().y,t>.1&&(m.P.Recyle(i),
i=this.excellenceModule.excellenceShowObj.transform.GetLocalPosition(),e.x=i.x,e.y-=15,s?e.y=0:e.y+=4,this.excellenceModule.excellenceShowObj.transform.SetLocalPosition(e),e.y-=t,
s=!1),t=this.masterSuitModule.node.GetBoundsSize().y,t>.1&&(m.P.Recyle(i),i=this.masterSuitModule.node.transform.GetLocalPosition(),e.x=i.x,e.y-=15,s?e.y=0:e.y+=4,
this.masterSuitModule.node.transform.SetLocalPosition(e),e.y-=t,e.y+=8,s=!1),t=this.angelSuitModule.node.GetBoundsSize().y,t>.1&&(m.P.Recyle(i),
i=this.angelSuitModule.node.transform.GetLocalPosition(),e.x=i.x,e.y-=15,s?e.y=0:e.y+=4,this.angelSuitModule.node.transform.SetLocalPosition(e),e.y-=t,e.y+=8,s=!1),
t=this.normalSuitModule.node.GetBoundsSize().y,t>.1&&(m.P.Recyle(i),i=this.normalSuitModule.node.transform.GetLocalPosition(),e.x=i.x,e.y-=15,s?e.y=0:e.y+=4,
this.normalSuitModule.node.transform.SetLocalPosition(e),e.y-=t,e.y+=8,s=!1),t=this.enhanceSuitModule.node.GetBoundsSize().y,t>.1&&(m.P.Recyle(i),
i=this.enhanceSuitModule.node.transform.GetLocalPosition(),e.x=i.x,e.y-=15,s?e.y=0:e.y+=4,this.enhanceSuitModule.node.transform.SetLocalPosition(e),e.y-=t,e.y+=8,s=!1),
t=this.enhanceWingrefineModule.node.GetBoundsSize().y,t>.1&&(m.P.Recyle(i),i=this.enhanceWingrefineModule.node.transform.GetLocalPosition(),e.x=i.x,e.y-=15,s?e.y=0:e.y+=4,
this.enhanceWingrefineModule.node.transform.SetLocalPosition(e),e.y-=t,s=!1),t=this.baseModule.node.GetBoundsSize().y,t>.1&&(m.P.Recyle(i),
i=this.baseModule.node.transform.GetLocalPosition(),e.x=i.x,e.y-=15,s?e.y=0:e.y+=4,this.baseModule.node.transform.SetLocalPosition(e),e.y-=t,s=!1),t=this.descObj.GetBoundsSize().y,
t>.1&&(m.P.Recyle(i),i=this.descObj.transform.GetLocalPosition(),e.x=i.x,e.y-=15,s?e.y=0:e.y+=4,this.descObj.transform.SetLocalPosition(e),e.y-=t,s=!1),
t=this.descChannelObj.GetBoundsSize().y,t>.1&&(m.P.Recyle(i),i=this.descChannelObj.transform.GetLocalPosition(),e.x=i.x,e.y-=8,s?e.y=0:e.y+=4,
this.descChannelObj.transform.SetLocalPosition(e),e.y-=t,s=!1),m.P.Recyle(e),m.P.Recyle(i),this.scrollView.ResetPosition()}Destroy(){this.demandModule.Destroy(),
this.timeModule.Destroy(),this.baseModule.Destroy(),this.enhanceWingrefineModule.Destroy(),this.excellenceModule.Destroy(),this.normalSuitModule.Destroy(),
this.enhanceSuitModule.Destroy()
let t=0
for(;t<this.qualityAnimList.Count();)this.qualityAnimList[t]=null,t+=1
this.qualityAnimList.Clear(),this.qualityAnimList=null}SetQualityAnim(t){let e=1
for(;e<this.qualityAnimList.Count();)this.qualityAnimList[e].SetActive(!1),e+=1
0!=t&&t<this.qualityAnimList.Count()&&this.qualityAnimList[t].SetActive(!0)}}},65669:(t,e,i)=>{i.d(e,{b:()=>K})
var s=i(38836),n=i(86133),l=i(98800),a=i(62370),o=i(99294),r=i(6665),h=i(9776),d=i(93877),c=i(72005),u=i(61911),m=i(18202),I=i(83540),g=i(98885),_=i(85602),p=i(79534),C=i(2962),S=i(3859),f=i(87923),y=i(34402),w=i(10509),D=i(63945),T=i(94998),A=i(97461),v=i(98958),L=i(30849),M=i(1240),b=i(92679),R=i(33331),P=i(48481),G=i(96574),O=i(68662),E=i(5924),B=i(9057),k=i(57834),x=i(98130),V=i(53824),N=i(15033),H=i(6251)
class U extends B.x{constructor(){super(),this.itemFather=null,this.itemName=null,this.auctionPrice=null,this.totalPrice=null,this.auctionIcon=null,this.endAuctionIcon=null,
this.auctionNoPrice=null,this.totalNoPrice=null,this.selectImg=null,this.item=null,this.groundingData=null,this.delayTimer=-1,this._degf_HideEndIconHandler=null,
this._degf_ShowTipsHandler=null,this._degf_HideEndIconHandler=()=>this.HideEndIconHandler(),this._degf_ShowTipsHandler=(t,e)=>this.ShowTipsHandler(t,e)}InitView(){
this.item=new V.Z,this.item.setBinderId(this.FatherId,this.FatherComponentID,1),this.itemName=new d.Q,this.itemName.setId(this.FatherId,this.FatherComponentID,2),
this.auctionPrice=new d.Q,this.auctionPrice.setId(this.FatherId,this.FatherComponentID,3),this.totalPrice=new d.Q,this.totalPrice.setId(this.FatherId,this.FatherComponentID,4),
this.auctionIcon=new o.z,this.auctionIcon.setId(this.FatherId,this.FatherComponentID,5),this.endAuctionIcon=new o.z,
this.endAuctionIcon.setId(this.FatherId,this.FatherComponentID,6),this.auctionNoPrice=new o.z,this.auctionNoPrice.setId(this.FatherId,this.FatherComponentID,7),
this.totalNoPrice=new o.z,this.totalNoPrice.setId(this.FatherId,this.FatherComponentID,8),this.selectImg=new o.z,this.selectImg.setId(this.FatherId,this.FatherComponentID,9),
this.AddOrRemoveLis(),super.InitView()}SetData(t){if(null==t)return
this.selectImg.SetActive(!1),this.groundingData=t,this.item.SetData(this.groundingData.itemData),this.auctionNoPrice.SetActive(this.groundingData.auctionPrice<=0),
this.totalNoPrice.SetActive(this.groundingData.totalPrice<=0),this.auctionPrice.node.SetActive(this.groundingData.auctionPrice>0),
this.totalPrice.node.SetActive(this.groundingData.totalPrice>0),this.groundingData.auctionPrice>0&&this.auctionPrice.textSet(g.M.DoubleToString(this.groundingData.auctionPrice)),
this.groundingData.totalPrice>0&&this.totalPrice.textSet(g.M.DoubleToString(this.groundingData.totalPrice))
let e=this.groundingData.endTime-O.D.serverMSTime_get()
if(this.groundingData.isShowTip||(e=1),this.auctionIcon.SetActive(this.groundingData.isAuction&&e>0),this.endAuctionIcon.SetActive(e<=0),
e>0&&-1==this.delayTimer&&this.groundingData.isShowTip&&(this.delayTimer=E.C.Inst_get().SetInterval(this._degf_HideEndIconHandler,x.GF.INT(e),1)),
e<=0)this.itemName.textSet(`[8e8279]${this.groundingData.itemData.baseData_get().cfgData_get().name}[-]`)
else if(this.groundingData.itemData.baseData_get().BagItemType_get()==N.r.Equip){
const t=f.l.SetEquipName(this.groundingData.itemData.baseData_get().equipInfo_get(),this.groundingData.itemData.baseData_get().cfgData_get(),this.groundingData.itemData.serverData_get())[0]
this.itemName.textSet(t)
}else this.itemName.textSet(f.l.GetQualityColorStr(this.groundingData.itemData.baseData_get().Quality_get(),this.groundingData.itemData.baseData_get().cfgData_get().name))
H.d.LuaMakeGoGray(this.item.FatherId,this.item.ComponentId,e<=0,!0)}HideEndIconHandler(){E.C.Inst_get().ClearInterval(this.delayTimer),this.delayTimer=-1,
this.auctionIcon.SetActive(!1),
this.endAuctionIcon.SetActive(!0),null!=this.groundingData&&null!=this.groundingData.itemData&&this.itemName.textSet(`[8e8279]${this.groundingData.itemData.baseData_get().cfgData_get().name}[-]`),
H.d.LuaMakeGoGray(this.item.FatherId,this.item.ComponentId,!0,!0)}SetSelectImgState(t){this.selectImg.SetActive(t)}Clear(){E.C.Inst_get().ClearInterval(this.delayTimer),
this.delayTimer=-1,this.groundingData=null}AddOrRemoveLis(t){
null==t&&(t=!0),t?k.i.Get(this.node).RegistonClick(this._degf_ShowTipsHandler):k.i.Get(this.node).RemoveonClick(this._degf_ShowTipsHandler)}ShowTipsHandler(t,e){
null!=this.groundingData&&null!=this.groundingData.itemData&&this.groundingData.isShowTip&&(A.i.Inst.RaiseEvent(b.g.MARKET_GROUNDING_ITEMCLICK),this.SetSelectImgState(!0),
D.x.inst.SelectOpenTipView(this.groundingData))}Destroy(){this.AddOrRemoveLis(!1),this.item.Destroy(),this.item=null,this.itemName=null,this.auctionPrice=null,this.totalPrice=null,
this.auctionIcon=null,this.endAuctionIcon=null,this.auctionNoPrice=null,this.totalNoPrice=null}}class F extends L.C{constructor(){super(),this.scrollView=null,this.grid=null,
this.noData=null,this.leftPriceLabel=null,this.leftPrice=null,this.curData=null,this.mainModel=null,this._degf_CreateItemHandler=null,this._degf_UpdateInfoHandler=null,
this._degf_CreateItemHandler=t=>this.CreateItemHandler(t),this._degf_UpdateInfoHandler=t=>this.UpdateInfoHandler(t)}InitView(){this.scrollView=new h.h,
this.scrollView.setId(this.FatherId,this.FatherComponentID,1),this.grid=new r.A,this.grid.setId(this.FatherId,this.FatherComponentID,2),this.noData=new o.z,
this.noData.setId(this.FatherId,this.FatherComponentID,3),this.leftPriceLabel=new d.Q,this.leftPriceLabel.setId(this.FatherId,this.FatherComponentID,4),this.leftPrice=new d.Q,
this.leftPrice.setId(this.FatherId,this.FatherComponentID,5),this.grid.SetInitInfo("ui_market_marketgroundingitem",this._degf_CreateItemHandler),this.mainModel=T.W.GetInst(),
this.AddOrRemoveLis(),super.InitView()}CreateItemHandler(t){const e=new U
return e.setId(t,null,0),e}InitData(t){this.curData=t,this.mainModel.SendItemAuctionTips(this.curData.itemData.serverData_get().modelId)}AddOrRemoveLis(t){null==t&&(t=!0),
t?A.i.Inst.AddEventHandler(b.g.MARKET_GROUNDING_OTHERGROUNDING_UPDATE,this._degf_UpdateInfoHandler):A.i.Inst.RemoveEventHandler(b.g.MARKET_GROUNDING_OTHERGROUNDING_UPDATE,this._degf_UpdateInfoHandler)
}UpdateInfoHandler(t){const e=new _.Z
if(this.noData.SetActive(null==this.mainModel.otherGroundingData.goods||0==this.mainModel.otherGroundingData.goods.Count()),null!=this.mainModel.otherGroundingData.goods){
let t=null,i=null,s=null,n=0
for(;n<this.mainModel.otherGroundingData.goods.Count();)t=new G.N,t.isShowTip=!1,i=new M.Y,s=new P.t,s.modelId=this.mainModel.otherGroundingData.goods[n].itemModelId,
s.num=this.mainModel.otherGroundingData.goods[n].num,i.serverData_set(s),i.baseData_get().useSelfStarLevel=this.mainModel.otherGroundingData.goods[n].star,
i.baseData_get().useSelfExcellenceCnt=this.mainModel.otherGroundingData.goods[n].excellenceCnt,i.baseData_get().useSelfHasLucky=this.mainModel.otherGroundingData.goods[n].hasLucky,
t.itemData=i,t.auctionPrice=this.mainModel.otherGroundingData.goods[n].nowPrice,t.totalPrice=this.mainModel.otherGroundingData.goods[n].buyOutPrice,e.Add(t),n+=1}
this.grid.data_set(e)
let i="",s=0
if(this.mainModel.otherGroundingData.lastPrice<=0){i=v.V.Inst().getStr2(10529)
s=R.I.Inst().getItemById(this.curData.resId).recprice}else i=v.V.Inst().getStr2(10530),s=this.mainModel.otherGroundingData.lastPrice
this.leftPriceLabel.textSet(i),this.leftPrice.textSet(g.M.IntToString(s))}ClearData(){}Destroy(){this.AddOrRemoveLis(!1),this.grid.Destroy(),this.scrollView=null,this.grid=null,
this.noData=null,this.leftPriceLabel=null,this.leftPrice=null}}var j=i(9986),Y=i(93078),z=i(98863),q=i(48933)
class Z extends L.C{constructor(){super(),this.numClick=null,this.groundingNum=null,this.addBtn=null,this.removeBtn=null,this.totalPriceClick=null,this.totalPrice=null,
this.auctionPriceClick=null,this.auctionPrice=null,this.groundingBtn=null,this.xiajiaBtn=null,this.renewGroundingBtn=null,this.xiajia2Btn=null,this.asuramGroundingBtn=null,
this.inputNumCtrl=null,this.curData=null,this.mainModel=null,this.defaultStr="",this.m_num=1,this.curAuctionPrice=0,this.curTotalPrice=0,this.curMinPrice=0,this.curMaxPrice=0,
this.showNumInputType=-1,this.curGetNum=0,this._degf_AttrAddHandler=null,this._degf_AuctionClickHandler=null,this._degf_ChangeNumHandler=null,this._degf_ClickHandler=null,
this._degf_NumClickHandler=null,this._degf_NumCloseHandler=null,this._degf_OnCancelClick=null,this._degf_OnConfirmClick=null,this._degf_OnAsuramCancelClick=null,
this._degf_OnAsuramConfirmClick=null,this._degf_TotalClickHandler=null,this._degf_AttrAddHandler=(t,e)=>this.AttrAddHandler(t,e),
this._degf_AuctionClickHandler=(t,e)=>this.AuctionClickHandler(t,e),this._degf_ChangeNumHandler=t=>this.ChangeNumHandler(t),this._degf_ClickHandler=(t,e)=>this.ClickHandler(t,e),
this._degf_NumClickHandler=(t,e)=>this.NumClickHandler(t,e),this._degf_NumCloseHandler=t=>this.NumCloseHandler(t),this._degf_OnCancelClick=t=>this.OnCancelClick(t),
this._degf_OnConfirmClick=t=>this.OnConfirmClick(t),this._degf_OnAsuramCancelClick=t=>this.OnAsuramCancelClick(t),this._degf_OnAsuramConfirmClick=t=>this.OnAsuramConfirmClick(t),
this._degf_TotalClickHandler=(t,e)=>this.TotalClickHandler(t,e)}InitView(){this.numClick=new o.z,this.numClick.setId(this.FatherId,this.FatherComponentID,2),
this.groundingNum=new d.Q,this.groundingNum.setId(this.FatherId,this.FatherComponentID,3),this.addBtn=new j.W,this.addBtn.setId(this.FatherId,this.FatherComponentID,4),
this.removeBtn=new j.W,this.removeBtn.setId(this.FatherId,this.FatherComponentID,5),this.totalPriceClick=new o.z,this.totalPriceClick.setId(this.FatherId,this.FatherComponentID,6),
this.totalPrice=new d.Q,this.totalPrice.setId(this.FatherId,this.FatherComponentID,7),this.auctionPriceClick=new o.z,
this.auctionPriceClick.setId(this.FatherId,this.FatherComponentID,8),this.auctionPrice=new d.Q,this.auctionPrice.setId(this.FatherId,this.FatherComponentID,9),
this.groundingBtn=new j.W,this.groundingBtn.setId(this.FatherId,this.FatherComponentID,10),this.xiajiaBtn=new j.W,this.xiajiaBtn.setId(this.FatherId,this.FatherComponentID,11),
this.renewGroundingBtn=new j.W,this.renewGroundingBtn.setId(this.FatherId,this.FatherComponentID,12),this.xiajia2Btn=new j.W,
this.xiajia2Btn.setId(this.FatherId,this.FatherComponentID,13),this.asuramGroundingBtn=new j.W,this.asuramGroundingBtn.setId(this.FatherId,this.FatherComponentID,14),
this.defaultStr=`[8e8279]${v.V.Inst().getStr2(10531)}[-]`,this.inputNumCtrl=new z.c(this._degf_ChangeNumHandler,this.groundingNum,this.removeBtn,this.addBtn,null),
this.AddOrRemoveLis(),this.mainModel=T.W.GetInst(),super.InitView()}ChangeNumHandler(t){this.curData.isGrounding||(this.m_num=t,this.UpdateItemNum(this.m_num))}InitData(t){
this.m_num=1,this.curAuctionPrice=0,this.curTotalPrice=0,this.curData=t
const e=O.D.serverMSTime_get()>=t.endTime
if(this.groundingBtn.node.SetActive(!this.curData.isGrounding),this.xiajiaBtn.node.SetActive(this.curData.isGrounding&&e),
this.xiajia2Btn.node.SetActive(this.curData.isGrounding&&!e),this.renewGroundingBtn.node.SetActive(this.curData.isGrounding&&e),
this.asuramGroundingBtn.node.SetActive(!this.curData.isGrounding),this.inputNumCtrl._isCanChangeNum=!this.curData.isGrounding,this.inputNumCtrl.min_set(1),
this.inputNumCtrl.num_set(1),this.inputNumCtrl.max_set(this.curData.itemData.serverData_get().num),this.asuramGroundingBtn.node.activeInHierarchy){const t=new p.P(-160,-263,0)
this.groundingBtn.node.transform.SetLocalPosition(t),p.P.Recyle(t)}else{const t=new p.P(-65,-263,0)
this.groundingBtn.node.transform.SetLocalPosition(t),p.P.Recyle(t)}if(this.curData.isGrounding){const t=v.V.Inst().getStr2(10107)
this.groundingNum.textSet(g.M.IntToString(this.curData.itemData.serverData_get().num)),this.SetPricePos(),
0==this.curData.auctionPrice?this.auctionPrice.textSet(t):this.auctionPrice.textSet(g.M.DoubleToString(this.curData.auctionPrice)),
0==this.curData.totalPrice?this.totalPrice.textSet(t):this.totalPrice.textSet(g.M.DoubleToString(this.curData.totalPrice))}else this.UpdateItemNum()}SetPricePos(){
const t=0!=this.curData.auctionPrice,e=0!=this.curData.totalPrice
this.auctionPrice.node.SetActive(t),this.totalPrice.node.SetActive(e),!t&&e?(q.I.calVec0.Set(-118,-165,0),
this.totalPrice.node.transform.SetLocalPosition(q.I.calVec0)):t&&e&&(q.I.calVec0.Set(-118,-188,0),this.totalPrice.node.transform.SetLocalPosition(q.I.calVec0))}ClearData(){}
AddOrRemoveLis(t){null==t&&(t=!0),t?(k.i.Get(this.groundingBtn.node).RegistonClick(this._degf_ClickHandler),k.i.Get(this.xiajiaBtn.node).RegistonClick(this._degf_ClickHandler),
k.i.Get(this.xiajia2Btn.node).RegistonClick(this._degf_ClickHandler),k.i.Get(this.renewGroundingBtn.node).RegistonClick(this._degf_ClickHandler),
k.i.Get(this.numClick).RegistonClick(this._degf_NumClickHandler),k.i.Get(this.auctionPriceClick).RegistonClick(this._degf_AuctionClickHandler),
k.i.Get(this.totalPriceClick).RegistonClick(this._degf_TotalClickHandler),
k.i.Get(this.asuramGroundingBtn.node).RegistonClick(this._degf_ClickHandler)):(k.i.Get(this.groundingBtn.node).RemoveonClick(this._degf_ClickHandler),
k.i.Get(this.xiajiaBtn.node).RemoveonClick(this._degf_ClickHandler),k.i.Get(this.xiajia2Btn.node).RemoveonClick(this._degf_ClickHandler),
k.i.Get(this.renewGroundingBtn.node).RemoveonClick(this._degf_ClickHandler),k.i.Get(this.numClick).RemoveonClick(this._degf_NumClickHandler),
k.i.Get(this.auctionPriceClick).RemoveonClick(this._degf_AuctionClickHandler),k.i.Get(this.totalPriceClick).RemoveonClick(this._degf_TotalClickHandler),
k.i.Get(this.asuramGroundingBtn.node).RemoveonClick(this._degf_ClickHandler))}TotalClickHandler(t,e){this.curData.isGrounding||(this.showNumInputType=2,
Y.F.Instance_get().OpenView(new p.P(-52,10,0),this._degf_AttrAddHandler,this._degf_NumCloseHandler))}AuctionClickHandler(t,e){this.curData.isGrounding||(this.showNumInputType=1,
Y.F.Instance_get().OpenView(new p.P(-52,10,0),this._degf_AttrAddHandler,this._degf_NumCloseHandler))}NumClickHandler(t,e){this.curData.isGrounding||(this.showNumInputType=0,
Y.F.Instance_get().OpenView(new p.P(-52,10,0),this._degf_AttrAddHandler,this._degf_NumCloseHandler))}NumCloseHandler(t){this.curGetNum=0,
1==this.showNumInputType?(0!=this.curAuctionPrice&&(this.curAuctionPrice<this.curMinPrice?this.curAuctionPrice=this.curMinPrice:this.curAuctionPrice>this.curMaxPrice&&(this.curAuctionPrice=this.curMaxPrice)),
this.auctionPrice.textSet(g.M.IntToString(this.curAuctionPrice))):2==this.showNumInputType&&(0!=this.curTotalPrice&&(this.curTotalPrice<this.curMinPrice?this.curTotalPrice=this.curMinPrice:this.curTotalPrice>this.curMaxPrice&&(this.curTotalPrice=this.curMaxPrice)),
this.totalPrice.textSet(g.M.IntToString(this.curTotalPrice))),this.showNumInputType=-1}AttrAddHandler(t,e){10==t?this.curGetNum=0:e?this.curGetNum=t:(this.curGetNum*=10,
this.curGetNum+=t),0==this.showNumInputType?(this.m_num=this.curGetNum,this.m_num<=0&&(this.m_num=1),
this.m_num>this.curData.itemData.serverData_get().num&&(this.m_num=this.curData.itemData.serverData_get().num),
this.UpdateItemNum(this.m_num)):1==this.showNumInputType?this.curGetNum>=0&&(this.curAuctionPrice=this.curGetNum,
this.curAuctionPrice>this.curMaxPrice&&(this.curAuctionPrice=this.curMaxPrice),
this.auctionPrice.textSet(g.M.IntToString(this.curAuctionPrice))):2==this.showNumInputType&&this.curGetNum>=0&&(this.curTotalPrice=this.curGetNum,
this.curTotalPrice>this.curMaxPrice&&(this.curTotalPrice=this.curMaxPrice),this.totalPrice.textSet(g.M.IntToString(this.curTotalPrice)))}UpdateItemNum(t){null==t&&(t=1),
this.groundingNum.textSet(g.M.IntToString(t)),this.auctionPrice.textSet(g.M.IntToString(this.curData.auctionPrice*t)),
this.totalPrice.textSet(g.M.IntToString(this.curData.totalPrice*t)),this.SetPricePos()}ClickHandler(t,e){
t==this.groundingBtn.ComponentId||t==this.asuramGroundingBtn.ComponentId||(t==this.xiajiaBtn.ComponentId||t==this.xiajia2Btn.ComponentId?this.mainModel.SendOffShelf(this.curData.id):this.renewGroundingBtn.ComponentId==t&&this.mainModel.SendReOffShelf(this.curData.id)),
D.x.inst.CloseEquipTipView(),D.x.inst.CloseItemTipView()}OnCancelClick(t){
this.mainModel.SendOnShelf(this.curData.itemData.index_get(),this.m_num,!1,this.curAuctionPrice,this.curTotalPrice)}OnConfirmClick(t){
this.mainModel.SendAppraisalItem(this.curData.itemData.index_get())}OnAsuramCancelClick(t){
this.mainModel.SendOnShelf(this.curData.itemData.index_get(),this.m_num,!0,this.curAuctionPrice,this.curTotalPrice)}OnAsuramConfirmClick(t){
this.mainModel.SendAppraisalItem(this.curData.itemData.index_get())}Destroy(){this.AddOrRemoveLis(!1),this.inputNumCtrl.removeListeners(),this.inputNumCtrl=null,this.numClick=null,
this.groundingNum=null,this.addBtn=null,this.removeBtn=null,this.totalPriceClick=null,this.totalPrice=null,this.auctionPriceClick=null,this.auctionPrice=null,
this.groundingBtn=null,this.xiajiaBtn=null,this.renewGroundingBtn=null,this.asuramGroundingBtn=null}}class K extends u.f{constructor(){super(),this.scrollView=null,
this.qualityBg=null,this.itemIcon=null,this.lockObj=null,this.nameLabel=null,this.usingObj=null,this.descLabel=null,this.priceObj=null,this.priceIcon=null,this.priceLabel=null,
this.descChannel=null,this.descObj=null,this.descChannelObj=null,this.itemType=null,this.rewardsObj=null,this.guardrewards=null,this.grade=null,this.otherView=null,
this.tipGroundingView=null,this.qualityAnimOne=null,this.qualityAnimTwo=null,this.qualityAnimThree=null,this.qualityAnimFour=null,this.qualityAnimFive=null,
this.qualityAnimSix=null,this.smeltModule=null,this.inlayExpModule=null,this._cfg=null,this.itemData=null,this.bagItemData=null,this.groundingData=null,this.qualityAnimList=null,
this.readyCnt=0,this._degf_CloseTip=null,this._degf_CreateRewardItem=null,this.demandModule=null,this.qualityAnimList=new _.Z,this._degf_CloseTip=(t,e)=>this.CloseTip(t,e),
this._degf_CreateRewardItem=t=>this.CreateRewardItem(t)}ReadyCnt_get(){return this.readyCnt}ReadyCnt_set(t){this.readyCnt=t,this.readyCnt>=7&&this.Relayout()}InitView(){
super.InitView(),this.scrollView=new h.h,this.scrollView.setId(this.FatherId,this.FatherComponentID,1),this.qualityBg=new c.w,
this.qualityBg.setId(this.FatherId,this.FatherComponentID,2),this.itemIcon=new c.w,this.itemIcon.setId(this.FatherId,this.FatherComponentID,3),this.lockObj=new o.z,
this.lockObj.setId(this.FatherId,this.FatherComponentID,4),this.nameLabel=new d.Q,this.nameLabel.setId(this.FatherId,this.FatherComponentID,5),this.usingObj=new o.z,
this.usingObj.setId(this.FatherId,this.FatherComponentID,6),this.descLabel=new d.Q,this.descLabel.setId(this.FatherId,this.FatherComponentID,9),this.priceObj=new o.z,
this.priceObj.setId(this.FatherId,this.FatherComponentID,10),this.priceIcon=new c.w,this.priceIcon.setId(this.FatherId,this.FatherComponentID,11),this.priceLabel=new d.Q,
this.priceLabel.setId(this.FatherId,this.FatherComponentID,12),this.descChannel=new d.Q,this.descChannel.setId(this.FatherId,this.FatherComponentID,13),this.descObj=new o.z,
this.descObj.setId(this.FatherId,this.FatherComponentID,14),this.descChannelObj=new o.z,this.descChannelObj.setId(this.FatherId,this.FatherComponentID,15),this.itemType=new d.Q,
this.itemType.setId(this.FatherId,this.FatherComponentID,16),this.rewardsObj=new o.z,this.rewardsObj.setId(this.FatherId,this.FatherComponentID,17),this.guardrewards=new r.A,
this.guardrewards.setId(this.FatherId,this.FatherComponentID,18),this.guardrewards.SetInitInfo("ui_guarddevelop_guarditem",this._degf_CreateRewardItem),this.grade=new c.w,
this.grade.setId(this.FatherId,this.FatherComponentID,19),this.grade.node.SetActive(!1),this.otherView=new F,this.otherView.setBinderId(this.FatherId,this.FatherComponentID,20),
this.tipGroundingView=new Z,this.tipGroundingView.setBinderId(this.FatherId,this.FatherComponentID,21),this.qualityAnimOne=new o.z,
this.qualityAnimOne.setId(this.FatherId,this.FatherComponentID,23),this.qualityAnimTwo=new o.z,this.qualityAnimTwo.setId(this.FatherId,this.FatherComponentID,24),
this.qualityAnimThree=new o.z,this.qualityAnimThree.setId(this.FatherId,this.FatherComponentID,25),this.qualityAnimFour=new o.z,
this.qualityAnimFour.setId(this.FatherId,this.FatherComponentID,26),this.qualityAnimFive=new o.z,this.qualityAnimFive.setId(this.FatherId,this.FatherComponentID,27),
this.qualityAnimSix=new o.z,this.qualityAnimSix.setId(this.FatherId,this.FatherComponentID,28),this.inlayExpModule=new C.S,
this.inlayExpModule.setBinderId(this.FatherId,this.FatherComponentID,32),this.qualityAnimList.Add(null),this.qualityAnimList.Add(this.qualityAnimOne),
this.qualityAnimList.Add(this.qualityAnimTwo),this.qualityAnimList.Add(this.qualityAnimThree),this.qualityAnimList.Add(this.qualityAnimFour),
this.qualityAnimList.Add(this.qualityAnimFive),this.qualityAnimList.Add(this.qualityAnimSix)}CreateRewardItem(t){}OnAddToScene(){this.AddLis(),
this.SetData(T.W.GetInst().curClickGroundingData)}Clear(){this.RemoveLis(),this.demandModule.clear()}AddLis(){this.AddFullScreenCollider(this.node,this._degf_CloseTip),
this.demandModule.AddLis()}CloseTip(t,e){D.x.inst.DelayCloseItemTip()}RemoveLis(){this.RemoveFullScreenCollider(this.node.FatherId)}Destroy(){this.otherView.Destroy(),
this.tipGroundingView.Destroy(),this.scrollView=null,this.qualityBg=null,this.itemIcon=null,this.lockObj=null,this.nameLabel=null,this.usingObj=null,this.demandModule.Destroy(),
this.demandModule=null,this.descLabel=null,this.priceObj=null,this.priceIcon=null,this.priceLabel=null,this.descChannel=null,this.descObj=null,this.descChannelObj=null,
this.itemType=null,this.rewardsObj=null,this.guardrewards.Destroy(),this.guardrewards=null,this.otherView=null,this.tipGroundingView=null,this.smeltModule.Destroy(),
this.smeltModule=null,this.inlayExpModule.Destroy(),this.inlayExpModule=null
let t=0
for(;t<this.qualityAnimList.Count();)this.qualityAnimList[t]=null,t+=1
this.qualityAnimList.Clear(),this.qualityAnimList=null}SetQualityAnim(t){let e=1
for(;e<this.qualityAnimList.Count();)this.qualityAnimList[e].SetActive(!1),e+=1
0!=t&&t<this.qualityAnimList.Count()&&this.qualityAnimList[t].SetActive(!0)}SetData(t){if(null==t)return
this.groundingData=t,this.itemData=this.groundingData.itemData.baseData_get(),this.bagItemData=this.groundingData.itemData,
this.node.transform.SetLocalPosition(this.groundingData.tipPos)
const e=l.Y.Inst.PrimaryRoleInfo_get()
this._cfg=this.itemData.cfgData_get()
const i=this._cfg.Rewards_get()
m.g.SetItemIcon(this.itemIcon.FatherId,this.itemIcon.ComponentId,this.itemData.cfgData_get().icon,I.b.eItem,!0),this.lockObj.SetActive(this.itemData.IsBind()),
this.qualityBg.spriteNameSet(f.l.GetQulityBgName(this.itemData.Quality_get()))
let o=`${this.GetNameStr(this.itemData.Quality_get())}${this._cfg.name}[-]`
this.nameLabel.textSet(o),this.SetQualityAnim(this.itemData.Quality_get()),this.itemType.textSet(this._cfg.describeType)
let r=null
if(i.typevalues.Count()>0&&(r=i.typevalues[0],"Skill"==r.type)){const t=g.M.Split(r.value,a.o.s_Arr_UNDER_COLON),e=g.M.String2Int(t[0])
let i=!1
const h=l.Y.Inst.PrimaryRoleInfo_get().Skills_get()
for(const[t,n]of(0,s.vy)(h)){if(h[t].id==e){i=!0
break}}i&&(o+=(0,n.T)(" [58ed58]（已学习）[-]"),this.nameLabel.textSet(o))}if(this.smeltModule.SetData(this.itemData,this,!1),this.demandModule.SetData(e,this._cfg,this,!1),
this.inlayExpModule.SetData(this.itemData,this,!1),
""!=this._cfg.describe?(this.descLabel.textSet(f.l.Substitute(g.M.Replace(this._cfg.describe,"\\n","\n"),new _.Z([this.itemData.leaderName]))),
this.descLabel.node.SetActive(!0)):(this.descLabel.textSet(""),this.descLabel.node.SetActive(!1)),
""!=this._cfg.describeChannel?(this.descChannel.textSet(this._cfg.describeChannel),this.descChannel.node.SetActive(!0),
this.descChannelObj.SetActive(!0)):(this.descChannel.textSet(""),this.descChannel.node.SetActive(!1),this.descChannelObj.SetActive(!1)),i.typevalues.Count()>0&&(r=i.typevalues[0],
"ExpDan"==r.type)){const t=g.M.Split(r.value,a.o.s_Arr_UNDER_CHAR_DOT),e=g.M.String2Int(t[0])
let i=g.M.String2Double(t[1]),s=0
s=l.Y.Inst.PrimaryRoleInfo_get().Level_get()>=e?e:l.Y.Inst.PrimaryRoleInfo_get().Level_get()
i*=w.L.Inst().getItemById(s).rexp,this.descLabel.textSet((0,n.T)("使用后获得")+(i+(0,n.T)("经验")))}this.grade.node.SetActive(!1),this.priceObj.SetActive(!1),
1==this._cfg.sell&&(this.priceObj.SetActive(!0),this.priceLabel.textSet(g.M.IntToString(this._cfg.sellPrice)),this.priceIcon.node.SetActive(!0)),this.otherView.node.SetActive(!1),
this.tipGroundingView.InitData(this.groundingData),this.Relayout()}GetVipLevelDemand(){let t=!1
if("PANDORA"==this._cfg.itemType||"VIPPANDORA"==this._cfg.itemType){y.$.Inst().getItemById(this._cfg.id).isVIPPandora&&(t=!0)}if(t){this.itemData.serverData_get()
const t=this._cfg.Conditions_get().typevalues
return"0"!=t[0].value?g.M.String2Int(t[0].value):0}return 0}GetNameStr(t){return g.M.s_LEFT_M_K_CHAR+(f.l.getColorStrByQuality(t)+g.M.s_RIGHT_M_K_CHAR)}Relayout(){let t=0
const e=p.P.zero_get()
let i=p.P.zero_get(),s=!0
t=this.smeltModule.node.GetBoundsSize().y,t>.1&&(p.P.Recyle(i),i=this.smeltModule.node.transform.GetLocalPosition(),e.x=i.x,e.y-=7,s?e.y=0:e.y+=4,
this.smeltModule.node.transform.SetLocalPosition(e),e.y-=t,s=!1),t=this.inlayExpModule.node.GetBoundsSize().y,t>.1&&(p.P.Recyle(i),
i=this.inlayExpModule.node.transform.GetLocalPosition(),e.x=i.x,e.y-=15,s?e.y=0:e.y+=4,this.inlayExpModule.node.transform.SetLocalPosition(e),e.y-=t,s=!1),
t=this.demandModule.node.GetBoundsSize().y,t>.1&&(p.P.Recyle(i),i=this.demandModule.node.transform.GetLocalPosition(),e.x=i.x,e.y-=15,s?e.y=0:e.y+=4,
this.demandModule.node.transform.SetLocalPosition(e),e.y-=t,s=!1),t=this.descObj.GetBoundsSize().y,t>.1&&(p.P.Recyle(i),i=this.descObj.transform.GetLocalPosition(),e.x=i.x,e.y-=15,
s?e.y=0:e.y+=4,this.descObj.transform.SetLocalPosition(e),e.y-=t,s=!1),t=this.rewardsObj.GetBoundsSize().y,this.itemData.cfgData_get().itemType==S.q.GUARDEGG&&(p.P.Recyle(i),
i=this.rewardsObj.transform.GetLocalPosition(),e.x=i.x,e.y-=11,s?e.y=0:e.y+=4,this.rewardsObj.transform.SetLocalPosition(e),e.y-=97,s=!1),t=this.descChannelObj.GetBoundsSize().y,
t>.1&&(p.P.Recyle(i),i=this.descChannelObj.transform.GetLocalPosition(),e.x=i.x,e.y-=8,s?e.y=0:e.y+=4,this.descChannelObj.transform.SetLocalPosition(e),e.y-=t,s=!1),
t=this.priceObj.GetBoundsSize().y,t>.1&&(p.P.Recyle(i),i=this.priceObj.transform.GetLocalPosition(),e.x=i.x,e.y-=8,s?e.y=0:e.y+=4,this.priceObj.transform.SetLocalPosition(e),
e.y-=t,s=!1),p.P.Recyle(e),p.P.Recyle(i),this.scrollView.ResetPosition()}}},52513:(t,e,i)=>{i.d(e,{O:()=>u})
var s=i(93984),n=i(38836),l=i(98800),a=i(62370),o=i(66788),r=i(55360),h=i(98885),d=i(85602),c=i(75439)
class u{constructor(){this.map=null,this.monthCardId=0,this.weekCardId=0,this.fundId=0,this.diamonds=null,this._degf_CompareTo=null,this._degf_DiamondCompare=null,
this.diamonds=new d.Z,this._degf_CompareTo=(t,e)=>this.CompareTo(t,e),this._degf_DiamondCompare=(t,e)=>this.DiamondCompare(t,e)
const t=r.Y.Inst.GetOrCreateCsv(s.h.eRechargeResource)
this.map=t.GetCsvMap()
for(const[t,e]of(0,n.V5)(this.map))2==e.type?this.monthCardId=e.id:3==e.type?this.weekCardId=e.id:e.type,0==e.type&&0==e.isHide&&this.diamonds.Add(e)
this.diamonds.Sort(this._degf_DiamondCompare)}static Inst(){return null==u._inst&&(u._inst=new u),u._inst}DiamondCompare(t,e){return t.sort-e.sort}GetDiamondIndex(t){let e=0
for(;e<this.diamonds.Count();){if(this.diamonds[e].id==t)return e
e+=1}return-1}getConfig(t){return this.map.LuaDic_ContainsKey(t)?this.map[t]:(o.Y.LogError(`没找到 RECHARGERESOURCE id ${t}`),null)}getMap(){return this.map}getLimitDict(){return null
}GetChannelRechargeShield(){const t=c.D.getInstance().GetStringValue("RECHARGE:CHANNEL_SHIELD")
return h.M.Split(t,a.o.s_Arr_UNDER_CHAR_DOT)}GetRechargeList(){l.Y.Inst.PrimaryRoleInfo_get().VipLevel_get()
const t=new d.Z
this.getLimitDict(),this.GetChannelRechargeShield()
for(const[e,i]of(0,n.V5)(this.map)){const e=i
t.Add(e)}return t}GetExamList(){const t=new d.Z
for(const[e,i]of(0,n.V5)(this.map))8!=i.type&&9!=i.type||t.Add(i)
return t}GetCfgMoney(t){return t.platformCurrency[1]}CompareTo(t,e){return t.sort-e.sort}GetConfigByType(t){new d.Z
for(const[e,i]of(0,n.V5)(this.map))if(i.type==t)return i
return null}GetConfigByTreasureId(t){for(const[e,i]of(0,n.V5)(this.map))if(i.treasureId==t)return i}}u._inst=null},31896:(t,e,i)=>{i.d(e,{t:()=>bt})
i(22267)
var s=i(42292),n=i(71409),l=i(77546),a=i(32076),o=i(38836),r=i(86133),h=i(38045),d=i(98800),c=i(38214),u=i(97461),m=i(68662),I=i(38935),g=i(5924),_=i(66788),p=i(56937),C=i(18202),S=i(31222),f=i(5494),y=i(52726),w=i(995),D=i(98789),T=i(38962),A=i(34334),v=i(20099),L=i(92679),M=i(37104),b=i(87923),R=i(91897),P=i(37648),G=i(55492),O=i(75439),E=i(92415),B=i(17870),k=i(94429),x=i(14792),V=i(62734),N=i(65550),H=i(85942),U=i(19519),F=i(63945),j=i(11162),Y=i(94998),z=i(8211),q=i(52513)
class Z{}Z.None=0,Z.SendCM_Recharge=3,Z.CallSDKPay=10,Z.SDKPAY1=11,Z.SDKPAY2=12,Z.FINISH=30
var K=i(7155),$=i(99294),W=i(57834),X=i(93877),Q=i(13113),J=i(61911),tt=i(49484),et=i(79534),it=i(5031),st=i(88010)
class nt extends J.f{constructor(){super(),this.timeLbl=null,this.box=null,this.forhide=null,this.anchor=null,this.cirleEffect=null,this.flashEffect=null,this.funId=0,
this.posTimerId=0,this.pos=null,this.disappearPos=null,this.resetTime=!1,this.firstChargeItem=null,this._degf_CountDownFun=null,this._degf_OnBgClick=null,
this._degf_UpdateViewPos=null,this._degf_OnPkUIUpdate=null,this._degf_OnMapChange=null,this.pos=et.P.zero_get(),this.disappearPos=new et.P(5e3,5e3,0),
this._degf_CountDownFun=()=>this.CountDownFun(),this._degf_OnBgClick=(t,e)=>this.OnBgClick(t,e),this._degf_UpdateViewPos=()=>this.UpdateViewPos(),
this._degf_OnPkUIUpdate=t=>this.OnPkUIUpdate(t),this._degf_OnMapChange=t=>this.OnMapChange(t)}InitView(){super.InitView(),this.timeLbl=new X.Q,
this.timeLbl.setId(this.FatherId,this.FatherComponentID,1),this.box=new $.z,this.box.setId(this.FatherId,this.FatherComponentID,2),this.forhide=new $.z,
this.forhide.setId(this.FatherId,this.FatherComponentID,3),this.anchor=new Q.T,this.anchor.setId(this.FatherId,this.FatherComponentID,4),this.cirleEffect=new $.z,
this.cirleEffect.setId(this.FatherId,this.FatherComponentID,5),this.flashEffect=new $.z,this.flashEffect.setId(this.FatherId,this.FatherComponentID,6),
W.i.Get(this.box).RegistonClick(this._degf_OnBgClick),u.i.Inst.AddEventHandler(L.g.PK_UI_UPDATE,this._degf_OnPkUIUpdate),
u.i.Inst.AddEventHandler(L.g.MAP_CHANGE_UPDATE,this._degf_OnMapChange)}Destroy(){super.Destroy(),W.i.Get(this.box).RemoveonClick(this._degf_OnBgClick),
u.i.Inst.RemoveEventHandler(L.g.PK_UI_UPDATE,this._degf_OnPkUIUpdate),u.i.Inst.RemoveEventHandler(L.g.MAP_CHANGE_UPDATE,this._degf_OnMapChange),this.ClearCountDown()}
OnPkUIUpdate(t){st.F.Inst_get().isInPkUI&&this.SetPos(this.disappearPos)}OnMapChange(t){this.SetPos(this.disappearPos),g.C.Inst_get().ClearInterval(this.posTimerId),
this.posTimerId=0}OnAddToScene(){super.OnAddToScene(),this.flashEffect.SetActive(!0),this.cirleEffect.SetActive(!1),this.pos=this.forhide.transform.GetLocalPosition().Clone(),
this.StartPosTimer(),this.resetTime=!1,this.RefreshTimeLbl(),this.ClearCountDown(),this.funId=g.C.Inst_get().SetInterval(this._degf_CountDownFun,1e3)}Clear(){super.Clear(),
this.StopPosTimer()}RefreshTimeLbl(){const t=this.GetEndTime()
if(t<0)return this.ClearCountDown(),void bt.inst.CloseNewServerTip()
this.ResetCheck()
const e=b.l.GetDateTimeInMinutes(1e3*t)
this.timeLbl.textSet(e)}ResetCheck(){const t=K.o.Inst_get().GetForseTime()
this.GetEndTime()<t&&0==this.resetTime&&(this.resetTime=!0,this.cirleEffect.SetActive(!0))}GetEndTime(){return K.o.Inst_get().endTime-m.D.serverTime_get()}SetShowOrHide(){
tt.p.Inst_get().ShowOrHideNewServerAdvantageTip()}OnBgClick(t,e){R.v.Inst_get().OpenView()}CountDownFun(){this.RefreshTimeLbl()}ClearCountDown(){
0!=this.funId&&(g.C.Inst_get().ClearInterval(this.funId),this.funId=0)}StartPosTimer(){this.UpdateViewPos(),this.StopPosTimer(),
0==this.posTimerId&&(this.posTimerId=g.C.Inst_get().SetInterval(this._degf_UpdateViewPos,200,-1))}StopPosTimer(){0!=this.posTimerId&&(g.C.Inst_get().ClearInterval(this.posTimerId),
this.posTimerId=0)}GetIsShow(){this.firstChargeItem=null
const t=it.T.inst_get().control.mainViewPanel
if(null!=t&&t.isShow_get()&&t.ui_mainview_operationentrance.node.activeInHierarchy&&(this.firstChargeItem=t.ui_mainview_operationentrance.GetFirstChargeItem()),
this.resetTime)return!0
return!(this.GetEndTime()<K.o.Inst_get().GetHideTime())&&(null!=this.firstChargeItem&&!(K.o.Inst_get().countFirstRecharge>0))}UpdateViewPos(){let t=et.P.zero_get()
if(0==this.GetIsShow())return t=this.disappearPos.Clone(),this.SetPos(t),void et.P.Recyle(t)
const e=it.T.inst_get().control.mainViewPanel
let i=0,s=!1
if(null!=e&&(i=e.ui_mainview_operationentrance.GetGridCount(),s=e.ui_mainview_operationentrance.isInPkAnime),null==this.firstChargeItem||i>3||s)t=this.disappearPos.Clone()
else{const e=this.firstChargeItem.node.transform.GetPosition(),i=this.anchor.node.transform.WorldToLocalMatrixMultiplyPoint3x4(e)
t.Set(i.x+5,i.y-33,i.z)}this.SetPos(t),et.P.Recyle(t)}SetPos(t){this.anchor.UpdateAnchors(),
t.x==this.pos.x&&t.y==this.pos.y&&t.z==this.pos.z||(this.forhide.transform.SetLocalPosition(t),this.pos=t.Clone())}}
var lt=i(43662),at=i(64213),ot=i(62370),rt=i(76544),ht=i(9986),dt=i(29562),ct=i(3522),ut=i(60130),mt=i(85602),It=i(53824),gt=i(63076),_t=i(34402),pt=i(22662)
class Ct extends J.f{constructor(){super(),this.limitLbl=null,this.closeBtn=null,this.numlbl1=null,this.numlbl2=null,this.numlbl3=null,this.numlbl4=null,this.modelTexture=null,
this.buyBtn=null,this.anim=null,this.effectBox=null,this.flagEffect=null,this.item1=null,this.item2=null,this.item3=null,this.item4=null,this.numLbls=null,this.items=null,
this.model=null,this.res=null,this.STAGE_ID=54,this.modelDisplay=null,this.displayId=0,this.delayExecutor=null,this._degf_LoadDoneModel=null,this._degf_OnBuyClick=null,
this._degf_OnCloseBtnClick=null,this._degf_PlayFlagEffect=null,this.funEnableBtnState=null,this.delayExecutor=new rt.p,this._degf_LoadDoneModel=t=>this.LoadDoneModel(t),
this._degf_OnBuyClick=(t,e)=>this.OnBuyClick(t,e),this._degf_OnCloseBtnClick=(t,e)=>this.OnCloseBtnClick(t,e),this._degf_PlayFlagEffect=()=>this.PlayFlagEffect()}InitView(){
super.InitView(),this.isExclusionPanel=!0,this.limitLbl=new X.Q,this.limitLbl.setId(this.FatherId,this.FatherComponentID,1),this.closeBtn=new ht.W,
this.closeBtn.setId(this.FatherId,this.FatherComponentID,2),this.numlbl1=new X.Q,this.numlbl1.setId(this.FatherId,this.FatherComponentID,3),this.numlbl2=new X.Q,
this.numlbl2.setId(this.FatherId,this.FatherComponentID,4),this.numlbl3=new X.Q,this.numlbl3.setId(this.FatherId,this.FatherComponentID,5),this.numlbl4=new X.Q,
this.numlbl4.setId(this.FatherId,this.FatherComponentID,6),this.modelTexture=new dt.V,this.modelTexture.setId(this.FatherId,this.FatherComponentID,11),this.buyBtn=new ht.W,
this.buyBtn.setId(this.FatherId,this.FatherComponentID,12),this.anim=new ct.k,this.anim.setId(this.FatherId,this.FatherComponentID,13),this.effectBox=new $.z,
this.effectBox.setId(this.FatherId,this.FatherComponentID,14),this.flagEffect=new $.z,this.flagEffect.setId(this.FatherId,this.FatherComponentID,15),this.item1=new It.Z,
this.item1.setBinderId(this.FatherId,this.FatherComponentID,16),this.item2=new It.Z,this.item2.setBinderId(this.FatherId,this.FatherComponentID,17),this.item3=new It.Z,
this.item3.setBinderId(this.FatherId,this.FatherComponentID,18),this.item4=new It.Z,this.item4.setBinderId(this.FatherId,this.FatherComponentID,19),
this.numLbls=new mt.Z([this.numlbl1,this.numlbl2,this.numlbl3,this.numlbl4]),this.items=new mt.Z([this.item1,this.item2,this.item3,this.item4]),this.model=K.o.Inst_get(),
this.addLis()}OnAddToScene(){this.effectBox.SetActive(!1),super.OnAddToScene(),this.PlayStartEffect(),this.res=q.O.Inst().GetConfigByType(1),this.RefreshLimit(),
this.displayId=this.res.modelId
let t=0
const e=_t.$.Inst().getItemById(this.res.treasureId).showAwards_get().showAwards
for(;t<this.items.count;){if(t<e.count){const i=e[t],s=i.itemId,n=i.num,l=new gt.M(s,null)
this.items[t].SetData(l),this.numLbls[t].textSet((0,r.T)("数量:")+ot.o.NumToString(n,0))}t+=1}}PlayStartEffect(){this.flagEffect.SetActive(!1),this.anim.Play(!0,!1),
this.delayExecutor.InvokeFrame(this._degf_PlayFlagEffect,6)}PlayFlagEffect(){this.flagEffect.SetActive(!0),this.effectBox.SetActive(!0)}OnItemClick(t,e){}RefreshLimit(){
if(null==this.res)return
const t=d.Y.Inst.PrimaryRoleInfo_get().VipLevel_get(),e=this.res.GetLimitCount(t),i=this.model.GetTodayBuyTimes(this.res.id),s=`VIP${ot.o.NumToString(t,0)}${(0,
r.T)(" 每日限购 (")}${ot.o.NumToString(i,0)}/${ot.o.NumToString(e,0)})`
0==e?this.limitLbl.node.SetActive(!1):(this.limitLbl.node.SetActive(!0),this.limitLbl.textSet(s))}OnBuyClick(t,e){
const i=d.Y.Inst.PrimaryRoleInfo_get().VipLevel_get(),s=this.res.GetLimitCount(i),n=this.model.GetTodayBuyTimes(this.res.id)
s>0&&n>=s?N.y.inst.ClientStrMsg(pt.r.SystemTipMessage,(0,r.T)("您当前的VIP等级已达到购买上限")):(this.buyBtn.SetIsEnabled(!1),ut.O.makeGoGray(this.buyBtn.node,!0,!0),
null==this.funEnableBtnState&&(this.funEnableBtnState=()=>{this.EnableBtnState()}),this.delayExecutor.Invoke(this.funEnableBtnState,2e3),bt.inst.Buy(this.res))}EnableBtnState(){
this.buyBtn.SetIsEnabled(!0),ut.O.makeGoGray(this.buyBtn.node,!1,!0)}OnCloseBtnClick(t,e){bt.inst.CloseShenbing(),bt.inst.OpenPanel()}addLis(){
W.i.Get(this.closeBtn.node).RegistonClick(this._degf_OnCloseBtnClick),W.i.Get(this.buyBtn.node).RegistonClick(this._degf_OnBuyClick)}removeLis(){
W.i.Get(this.closeBtn.node).RemoveonClick(this._degf_OnCloseBtnClick),W.i.Get(this.buyBtn.node).RemoveonClick(this._degf_OnBuyClick)}SetModel(){this.DestroyModel(),
this.displayId>0&&(this.modelDisplay=new at.r,this.modelDisplay.SetDisplayID(this.displayId,this.STAGE_ID,0,1,!0,this._degf_LoadDoneModel,!1,0,0,0))
const t=this.res.GetPos(),e=this.res.GetRotate()
lt.M.Instance_get().SetWorldRotation(this.STAGE_ID,0,new et.P(e[0],e[1],e[2])),this.modelDisplay.MainRole_get().SetPosXYZ(t[0],t[1],t[2]),
this.modelDisplay.MainRole_get().SetSize(this.res.GetScale())}LoadDoneModel(t){this.PlayBoxEffect()}PlayBoxEffect(){}DestroyModel(){
null!=this.modelDisplay&&(this.modelDisplay.Destroy(),this.modelDisplay=null)}Destroy(){super.Destroy(),this.removeLis(),this.DestroyModel(),this.delayExecutor.Clear(),
this.delayExecutor=null,lt.M.Instance_get().DeactiveStage(this.STAGE_ID,this.modelTexture.FatherId,this.modelTexture.ComponentId),this.limitLbl=null,this.closeBtn=null,
this.numlbl1=null,this.numlbl2=null,this.numlbl3=null,this.numlbl4=null,this.modelTexture=null,this.buyBtn=null,this.anim=null,this.effectBox=null,this.flagEffect=null,
this.numLbls=null,this.model=null,this.res=null}}var St,ft,yt,wt,Dt,Tt,At,vt,Lt=i(44132)
function Mt(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let bt=(St=(0,s.gK)("RechargeControl"),ft=(0,n.GH)(E.k.SM_RedPointClick),yt=(0,n.GH)(E.k.SM_RechargePay),wt=(0,
n.GH)(E.k.SM_Recharge),Dt=(0,n.GH)(E.k.SM_RechargeRecord),St((vt=class t extends Lt.D{static get inst(){return null==t._inst&&(t._inst=new t),t._inst}constructor(){super(),
this.tip=null,this.rechargeModel=null,this.advantageTip=null,this.shenbingPanel=null,this.curRechargeRes=null,this.sm_recharge=null,this.cm_recharge=null,this._rechargeStatus=null,
this._isLimitRechargeTipShowing=!1,this.isFocus=!0,this.ITEM_SELECT_EVENT="ITEM_SELECT_EVENT",this.BUY_SUCCESS_EVENT="BUY_SUCCESS_EVENT",this.hasClickRedIdDic=null,
this._degf_CallDestory=null,this._degf_GetDiamondHandler=null,this._degf_SM_RechargeHandle=null,this._degf_SM_RechargeRecordHandle=null,this._degf_ShenbingCallDestory=null,
this._degf_ShenbingShowlComplete=null,this._degf_ShowlComplete=null,this._degf_TipCallDestory=null,this._degf_TipShowlComplete=null,this._degf_ShowRechargeGiftHandler=null,
this._degf_DestroyRechargeGiftHandler=null,this._degf_OpenRechargeGiftPanelDelay=null,this.timer=null,this.resultRes=null,this.isOpenGift=null,this.giftRes=null,
this.rechargeGiftPanel=null,this.mExaminePanel=null,this._lastBuyTime=null,this._rechargeStatus=new T.X,this.hasClickRedIdDic=new T.X,this._degf_CallDestory=()=>this.CallDestory(),
this._degf_GetDiamondHandler=t=>this.GetDiamondHandler(t),this._degf_SM_RechargeHandle=t=>this.SM_RechargeHandle(t),
this._degf_SM_RechargeRecordHandle=t=>this.SM_RechargeRecordHandle(t),this._degf_ShenbingCallDestory=()=>this.ShenbingCallDestory(),
this._degf_ShenbingShowlComplete=t=>this.ShenbingShowlComplete(t),this._degf_ShowlComplete=t=>this.ShowlComplete(t),this._degf_TipCallDestory=()=>this.TipCallDestory(),
this._degf_TipShowlComplete=t=>this.TipShowlComplete(t),this._degf_ShowRechargeGiftHandler=t=>this.ShowRechargeGiftHandler(t),this._degf_DestroyRechargeGiftHandler=t=>{
this.DestroyRechargeGiftHandler()},this._degf_OpenRechargeGiftPanelDelay=()=>{this.OpenRechargeGiftPanelDelay()},this.rechargeModel=K.o.Inst_get(),
u.i.Inst.AddEventHandler(L.g.Gold_DiamondAdd,this._degf_GetDiamondHandler),u.i.Inst.AddEventHandler(L.g.CURRENCY_CHARGE_WAVEANIMEND,this._degf_OpenRechargeGiftPanelDelay),
u.i.Inst.AddEventHandler(L.g.ApplicationFocus,(0,a.v)(this.OnFocusUpdate,this))}OnFocusUpdate(t){this.isFocus=t,m.D.IsIosNew15()||0==t&&this.UpdateRechargeStatus()}
UpdateRechargeStatus(){
if(0==this.isFocus)for(const[t,e]of(0,o.V5)(this._rechargeStatus))e==Z.CallSDKPay?this.SetRechargeStatus(t,Z.SDKPAY1):e==Z.SDKPAY1&&this.SetRechargeStatus(t,Z.SDKPAY2)}
ClearTimer(){null!=this.timer&&g.C.Inst_get().ClearInterval(this.timer)}ResetData(){this.ClearTimer(),this.hasClickRedIdDic.Clear(),t._lastBuyTime=0}SM_RedPointClickHandle(t){
for(let e=0;e<=t.hasClick.Count()-1;e++){const i=t.hasClick[e]
this.hasClickRedIdDic.LuaDic_AddOrSetItem(i,!0)}u.i.Inst.RaiseEvent(L.g.CLICK_REDPOINTINFO_UPDTAE),this.RefreshRechargeRedPoint()}RefreshRechargeRedPoint(){
const t=q.O.Inst().diamonds
let e=!1
for(let i=0;i<=t.Count()-1;i++){const s=t[i]
if(0!=s.hotPoint){const t=s.id
if(!this.IsHasClick(t)){e=!0
break}}}1==O.D.getInstance().GetIntValue("MONTHCARD:REMIND_KEY")&&V.f.Inst.SetState(x.t.MONTH_CARD,!this.IsHasClick(1)),V.f.Inst.SetState(x.t.RECHARGE,e)}IsHasClick(t){
return!!this.hasClickRedIdDic.LuaDic_GetItem(t)&&this.hasClickRedIdDic[t]}CM_RedPointClickHandle(t,e){this.hasClickRedIdDic.LuaDic_AddOrSetItem(t,!0),this.RefreshRechargeRedPoint()
const i=new k.M
i.id=t,null!=e&&(i.forever=e),I.C.Inst.F_SendMsg(i)}GetDiamondHandler(t){}SM_IosReviewHandle(t){}_SM_RechargePayHandler(e){const i=e
this.sm_recharge=i
const s=t._GetLastRechargeClick()
null!=s&&v.V.SendClickData(s[1]),this.SetRechargeStatus(i.productId,Z.CallSDKPay),u.i.Inst.RaiseEvent(L.g.RECHARGE_SIGN)
{const t={},e=launcher.config
t.appid=(0,h.tw)(e.pid),t.game_id=e.gid,t.uid=(0,h.aI)(i.uid),t.sid=i.serverId,t.actor_id=i.actorID.toString(),t.order_no=i.order_no,t.money=this.cm_recharge.money,
t.game_coin=this.cm_recharge.gameCoin,t.product_id=this.cm_recharge.produceId,t.subject=this.cm_recharge.subject,t.time=i.time,t.ext=i.ext,t.sign=i.sign,t.order_ip=e.userIp,
t.referer=e.referer?e.referer:"",t.app_ext=e.sdkData.app_ext,MiniPlatController.ins.pay(t)}}static _GetLastRechargeClick(){for(let e=v.V.s_lastClickId.Count()-2;e>=0;e+=-2){
const[i,s]=[v.V.s_lastClickId[e],v.V.s_lastClickId[e+1]]
if(null!=t.s_rechargeClickIdConfig[i])return t.s_rechargeClickIdConfig[i]}return null}SM_RechargeHandle(e){const i=e
if(_.Y.Log((0,r.T)("充值id:")+(i.rechargeId+((0,r.T)(" 是否充值成功")+i.result)),!0),1==i.result){const t=q.O.Inst().getConfig(i.rechargeId)
if(null!=t&&0==t.type&&(A.O.Inst().OpenDiamondGetEffect(U.J.GOLD_DIAMOND),this.resultRes=t,this.isOpenGift=!1,0!=t.giveType)){const e=K.o.Inst_get().GetTotalBuyTimes(t.id)
2==t.giveType&&(this.isOpenGift=!0),1==t.giveType&&0==e&&(this.isOpenGift=!0)}K.o.Inst_get().RaiseEvent(this.BUY_SUCCESS_EVENT)}this.SetRechargeStatus(i.rechargeId,Z.FINISH),
l.s.Info(`支付返回:${i.rechargeId} ${i.result}`),t._lastBuyTime=0,this.ClearTimer()}OnPayResult(e,i,s){1==e?(0!=t._lastBuyTime&&(t._lastBuyTime=m.D.serverTime_get()),
this.SetRechargeStatus(i,Z.SDKPAY2)):(t._lastBuyTime=0,this.SetRechargeStatus(i,Z.None)),this.ClearTimer()
const n=t._GetLastRechargeClick()
null!=n&&(e?v.V.SendClickData(n[2]):v.V.SendClickData(n[3]))}OpenRechargeGiftPanelDelay(){this.isOpenGift&&this.OpenRechargeGiftPanel(this.resultRes),this.isOpenGift=!1}
OpenRechargeGiftPanel(t){if(this.giftRes=t,null!=this.rechargeGiftPanel)return void this.rechargeGiftPanel.OnAddToScene()
const e=new p.v
e.isShowMask=!0,e.isDefaultUITween=!0,e.maskAlpha=.8,S.N.inst.OpenById(f.I.RechargeGiftPanel,this._degf_ShowRechargeGiftHandler,this._degf_DestroyRechargeGiftHandler,e)}
ShowRechargeGiftHandler(t){}DestroyRechargeGiftHandler(){null!=this.rechargeGiftPanel&&(C.g.DestroyUIObj(this.rechargeGiftPanel),this.rechargeGiftPanel=null)}
CloseRechargeGiftView(){S.N.inst.CloseById(f.I.RechargeGiftPanel)}SM_RechargeRecordHandle(t){const e=t
this.rechargeModel.isFristRecharge=e.isFristRecharge,this.rechargeModel.ClearTime(),this.rechargeModel.SetTime(e.id2Recourd)
const i=F.x.inst.getRechargeView()
null!=i&&i.SetUIInfo(),null!=this.shenbingPanel&&this.shenbingPanel.RefreshLimit(),K.o.Inst_get().RaiseEvent(this.BUY_SUCCESS_EVENT)}IsPanelOpen(){
const t=F.x.inst.getRechargeView()
return!(null==t||!t.node.activeInHierarchy)}OpenPanel(){Y.W.GetInst().FirstChildViewType=M.$.Recharge,j.O.Inst_get().Open(1,2,-1,-1)}CommonRechargeHandle(){
if(!K.o.Inst_get().isFristRecharge)return P.P.Inst_get().IsFunctionOpened(G.x.FIRST_CHARGE)?void R.v.Inst_get().OpenView():void b.l.SetFunctionTip(G.x.FIRST_CHARGE)
P.P.Inst_get().IsFunctionOpened(G.x.MALL)&&(z.N.GetInst().CheckShopHasGoodsBuy(5,1)?j.O.Inst_get().Open(null,5,1,-1):z.N.GetInst().CheckShopHasGoodsBuy(3,1)?j.O.Inst_get().Open(null,3,1,-1):j.O.Inst_get().Open(null,2,1,-1))
}OpenBuyTip(){const t=new p.v
t.positionType=D.$.eCenter,t.layerType=y.F.Alert,S.N.inst.OpenById(f.I.RechargeBuyTip,this._degf_ShowlComplete,this._degf_CallDestory,t)}CloseBuyTip(){
S.N.inst.CloseById(f.I.RechargeBuyTip)}OnItemClick(){const t=F.x.inst.getRechargeView()
null!=t&&t.OnItemClick()}ShowlComplete(t){}CallDestory(){C.g.DestroyUIObj(this.tip),this.tip=null}OpenNewServerTip(){const t=new p.v
t.positionType=D.$.eCustom,t.layerType=y.F.DefaultUI,t.aniDir=w.K.Left,t.ReLoginOrChangeRoleIsDestroy=!1,
S.N.inst.OpenById(f.I.NewServerAdvantagePanel,this._degf_TipShowlComplete,this._degf_TipCallDestory,t)}CloseNewServerTip(){S.N.inst.CloseById(f.I.NewServerAdvantagePanel)}
UpdateNewServerLocShow(){}TipShowlComplete(t){return null==this.advantageTip&&(this.advantageTip=new nt,this.advantageTip.setId(t,null,0)),this.advantageTip}TipCallDestory(){
C.g.DestroyUIObj(this.advantageTip),this.advantageTip=null}OpenShenbing(){const t=new p.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!1,S.N.inst.OpenById(f.I.RechargeShenbing,this._degf_ShenbingShowlComplete,this._degf_ShenbingCallDestory,t)}CloseShenbing(){
S.N.inst.CloseById(f.I.RechargeShenbing)}ShenbingShowlComplete(t){return null==this.shenbingPanel&&(this.shenbingPanel=new Ct,this.shenbingPanel.setId(t,null,0)),this.shenbingPanel
}ShenbingCallDestory(){C.g.DestroyUIObj(this.shenbingPanel),this.shenbingPanel=null}RefreshExaminePanel(){null!=this.mExaminePanel&&this.mExaminePanel.RefreshUI()}
ExaminePanelDestroy(){C.g.DestroyUIObj(this.mExaminePanel),this.mExaminePanel=null}Buy(t,e,i=null){if(null==i&&(i=!0),i){if(!R.v.Inst_get().CheckFirstCharge(t))return}
null==e&&(e=q.O.Inst().GetCfgMoney(t))
const s=[t,e],n=this.GetRechargeRetainBuy(t)
_.Y.Log(`Recharge ${t.id} retain:${n}`)
const a=m.D.serverTime_get(),o=this.GetRechargeStatus(t.id)
if(a-this._lastBuyTime<2)l.s.Info(`Recharge Busy 1 status:${o} id:${t.id}`)
else{if(-1!=n&&(o==Z.SendCM_Recharge||o==Z.SDKPAY2||o==Z.CallSDKPay)){l.s.Info(`Recharge Busy 2 status:${o} id:${t.id}`),v.V.SendClickData(300200)
const e=new H.N
return e.showText="礼包发送可能存在[D41601]延迟[-]，建议你确认收到物品后再进行购买，超出次数购买将转化为[D41601]同等金额的钻石[-]",e.okhandler=this.CreateDelegate(this._TipOK),
e.cancelhandler=this.CreateDelegate(this._TipCancle),e.okText="继续购买",e.cancelText="取消购买",e.tipstype=2,e.objparams=s,e.isShowCloseBtn=!1,N.y.inst.OpenCommonMessageTips(e),
void(this._isLimitRechargeTipShowing=!0)}this._SendCMRecharge(s)}}GetRechargeStatus(t){t=(0,h.tw)(t),null==this._rechargeStatus[t]&&(this._rechargeStatus[t]=Z.None)
return this._rechargeStatus[t]}SetRechargeStatus(t,e){t=(0,h.tw)(t),l.s.Info(`SetRechargeStatus ${t} ${this.GetRechargeStatus(t)} ${e}`),this._rechargeStatus[t]=e}
GetRechargeRetainBuy(t){return 0==t.type?-1:1}_TipOK(t){v.V.SendClickData(300201),this._isLimitRechargeTipShowing=!1,this._SendCMRecharge(t)}_SendCMRecharge(e){
const i=e[0],s=e[1],n=m.D.serverTime_get()
this.ClearTimer(),t._lastBuyTime=n,l.s.Info(`CM_RechargePay ${i.id}`),_.Y.Log(`CM_RechargePay ${i.id}`),m.D.IsNoneSdk()&&this.rechargeModel.RequestRecharge(i.id),
this.curRechargeRes=i
const a=new B.h
a.actorId=d.Y.Inst.PrimaryRoleInfo_get().Id_get(),_.Y.Log(d.Y.Inst.PrimaryRoleInfo_get().Id_get().ToString()),a.uid=c.Q.Instance.uid,a.money=s,a.subject=i.productName,
a.produceId=(0,h.tw)(i.id),a.gameId=launcher.config.gid+"",a.gameId||(a.gameId=c.Q.Instance.fgid),a.sid=d.Y.Inst.PrimaryRoleInfo_get().Server_get()
const r=JSON.parse(i.diamond)
if(r&&r.wxapp){if(a.gameCoin=r.wxapp?r.wxapp:10*s,a.ext=(0,h.tw)(i.id),this.cm_recharge=a,!m.D.IsIosNew15())for(const[t,e]of(0,
o.V5)(this._rechargeStatus))e==Z.SDKPAY1&&this.SetRechargeStatus(t,Z.None)
this.SetRechargeStatus(i.id,Z.SendCM_Recharge),I.C.Inst.F_SendMsg(a)}else console.error("RECHARGERESOURCEEx  res error")}_TipCancle(){l.s.Info("_TipCancle"),
this._isLimitRechargeTipShowing=!1,v.V.SendClickData(300202)}SetClickItemInfo(t){this.curRechargeRes=t}GetClickItemInfo(){return this.curRechargeRes}},vt._inst=null,
vt.s_rechargeClickIdConfig={300003:[300004,300005,300006],300109:[300113,300117,300121],300110:[300114,300118,300121],300111:[300115,300119,300121],300112:[300116,300120,300121],
300105:[300116,300120,300121],301309:[301313,301317,301321],301310:[301314,301318,301321],301311:[301315,301319,301321],301312:[301316,301320,301321],301305:[301316,301320,301321],
310005:[310013,310021,310029],310006:[310014,310022,310029],310007:[310015,310023,310029],310008:[310016,310024,310029],310009:[310017,310025,310029],310010:[310018,310026,310029],
310011:[310019,310027,310029],310012:[310020,310028,310029],310101:[310107,310113,310119],310102:[310108,310114,310119],310103:[310109,310115,310119],310104:[310110,310116,310119],
310105:[310111,310117,310119],310106:[310112,310118,310119],310201:[310209,310217,310225],310202:[310210,310218,310225],310203:[310211,310219,310225],310204:[310212,310220,310225],
310205:[310213,310221,310225],310206:[310214,310222,310225],310207:[310215,310223,310225],310208:[310226,310224,310225],310309:[310313,310317,310321],310310:[310314,310318,310321],
310311:[310315,310319,310321],310312:[310316,310320,310321],310305:[310316,310320,310321]},vt._lastBuyTime=0,Mt(At=vt,"inst",[s.n],Object.getOwnPropertyDescriptor(At,"inst"),At),
Mt(At.prototype,"SM_RedPointClickHandle",[ft],Object.getOwnPropertyDescriptor(At.prototype,"SM_RedPointClickHandle"),At.prototype),
Mt(At.prototype,"_SM_RechargePayHandler",[yt],Object.getOwnPropertyDescriptor(At.prototype,"_SM_RechargePayHandler"),At.prototype),
Mt(At.prototype,"SM_RechargeHandle",[wt],Object.getOwnPropertyDescriptor(At.prototype,"SM_RechargeHandle"),At.prototype),
Mt(At.prototype,"SM_RechargeRecordHandle",[Dt],Object.getOwnPropertyDescriptor(At.prototype,"SM_RechargeRecordHandle"),At.prototype),Tt=At))||Tt)},7155:(t,e,i)=>{i.d(e,{o:()=>m})
var s=i(38836),n=i(16812),l=i(85602),a=i(38962),o=i(75439),r=i(34402),h=i(48946),d=i(5031),c=i(52513),u=i(31896)
class m extends n.k{constructor(){super(),this.SelectedId=-1,this._buyTimes=null,this.endTime=0,this.baoxiangTip=!1,this.countFirstRecharge=0,this.isFristRecharge=!1,
this.ExamSelectId=0,this.IsIosReview=!1,this.openRebateCount=0,this.RebateDiamondCount=0,this.DiamondRechargeCount=0,this._buyTimes=new a.X}static Inst_get(){
return null==m._Inst&&(m._Inst=new m),m._Inst}getCurConfig(){return c.O.Inst().getConfig(this.SelectedId)}getCurExamConfig(){return c.O.Inst().getConfig(this.ExamSelectId)}
GetForseTime(){return o.D.getInstance().GetIntValue("SHOW_FUNC_AHEAD")}GetHideTime(){return o.D.getInstance().GetIntValue("RECHARGE:AUTO_SHIELD_FUNC_AHEAD")}ResetModel(){
this.countFirstRecharge=0,this.openRebateCount=0,u.t.inst.isOpenGift=!1}IncreaseOpenCount(){this.countFirstRecharge+=1}ShowShenbingRedDot(){return this.baoxiangTip}ClearTime(){
this._buyTimes.LuaDic_Clear()}SetTime(t){this._buyTimes=t}GetTotalBuyTimes(t){
return null==this._buyTimes?0:this._buyTimes.LuaDic_ContainsKey(t)&&null!=this._buyTimes[t]?this._buyTimes[t].totalCount:0}GetTodayBuyTimes(t){
return null==this._buyTimes?0:this._buyTimes.LuaDic_ContainsKey(t)&&null!=this._buyTimes[t]?this._buyTimes[t].dailyCount:0}GetPandoraName(){let t=""
const e=c.O.Inst().getConfig(this.SelectedId)
if(null==e)return t
const i=r.$.Inst().getItemById(e.treasureId)
return null==i||(t=i.name),t}GetPandoraItems(){const t=new l.Z,e=c.O.Inst().getConfig(this.SelectedId)
if(null==e)return t
const i=r.$.Inst().getItemById(e.treasureId)
if(null==i)return t
for(const[e,n]of(0,s.V5)(i.showAwards_get().showAwards))0!=n.id&&t.Add(n)
return t}RequestRecharge(t){}GetExamCfgs(){return c.O.Inst().GetExamList()}GetDiamondRechargeList(){return c.O.Inst().GetRechargeList()}getRebateRedDot(){
const t=h.m.Inst_get().getItemById("TESTDIAMONDRETURN")
return d.T.inst_get().model.ShowOperation(t)}CheckRebateRedDot(){let t=!1
0==this.openRebateCount&&(t=!0)}}m._Inst=null},63945:(t,e,i)=>{i.d(e,{x:()=>be})
var s=i(42292),n=i(71409),l=i(17409),a=i(98800),o=i(97461),r=i(68662),h=i(38935),d=i(5924),c=i(56937),u=i(18202),m=i(31222),I=i(5494),g=i(52726),_=i(98130),p=i(79534),C=i(70123),S=i(63076),f=i(23628),y=i(26753),w=i(92679),D=i(37104),T=i(74045),A=i(87923),v=i(29839),L=i(37648),M=i(55492),b=i(35037),R=i(13290),P=i(50870),G=i(76577),O=i(36969),E=i(92415),B=i(78967),k=i(96297),x=i(65550),V=i(86133),N=i(98958),H=i(66788),U=i(99294),F=i(9986),j=i(57834),Y=i(93877),z=i(61911),q=i(85682),Z=i(98885),K=i(70850),$=i(75696),W=i(75321),X=i(48933),Q=i(33331),J=i(33138),tt=i(6251),et=i(94998)
class it extends z.f{constructor(){super(),this.tipGo=null,this.itemFather=null,this.startPrice=null,this.buyPrice=null,this.closeBtn=null,this.selfUseBtn=null,
this.auctionBtn=null,this.auctionGo=null,this.bottomTip=null,this._model=null,this.curModelId=0,this.id=null,this.item=null,this.index=-1,this.isCanAuction=!0,
this._degf_AuctionHandler=null,this._degf_CloseHandler=null,this._degf_SelfUseHandler=null,this._degf_AuctionHandler=(t,e)=>this.AuctionHandler(t,e),
this._degf_CloseHandler=(t,e)=>this.CloseHandler(t,e),this._degf_SelfUseHandler=(t,e)=>this.SelfUseHandler(t,e)}InitView(){if(this.tipGo=new U.z,
this.tipGo.setId(this.FatherId,this.FatherComponentID,1),this.itemFather=new U.z,this.itemFather.setId(this.FatherId,this.FatherComponentID,2),this.startPrice=new Y.Q,
this.startPrice.setId(this.FatherId,this.FatherComponentID,3),this.buyPrice=new Y.Q,this.buyPrice.setId(this.FatherId,this.FatherComponentID,4),this.closeBtn=new F.W,
this.closeBtn.setId(this.FatherId,this.FatherComponentID,5),this.selfUseBtn=new F.W,this.selfUseBtn.setId(this.FatherId,this.FatherComponentID,6),this.auctionBtn=new F.W,
this.auctionBtn.setId(this.FatherId,this.FatherComponentID,7),this.auctionGo=new U.z,this.auctionGo.setId(this.FatherId,this.FatherComponentID,8),this.bottomTip=new Y.Q,
this.bottomTip.setId(this.FatherId,this.FatherComponentID,9),null==this.item){const t=u.g.GetResFindId("ui_baseitem")
this.item=new $.j,this.item.setId(t,null,0),this.item.node.transform.SetParent(this.itemFather.FatherId,this.itemFather.ComponentId)}super.InitView(),this._model=et.W.GetInst()}
OnAddToScene(){this.addLis(),this.SetData()}Clear(){this.removeLis()}addLis(){j.i.Get(this.closeBtn.node).RegistonClick(this._degf_CloseHandler),
j.i.Get(this.selfUseBtn.node).RegistonClick(this._degf_SelfUseHandler),j.i.Get(this.auctionBtn.node).RegistonClick(this._degf_AuctionHandler)}AuctionHandler(t,e){
this.isCanAuction?null!=this.id&&this.ExitFunc():x.y.inst.ClientSysMessage(190033)}SelfUseHandler(t,e){m.N.inst.OpenUIByShortCutID(q.D.Bag),this.ExitFunc()}CloseHandler(t,e){
this.ExitFunc()}ExitFunc(){this._model.curGetAuctionViewType=0,this._model.curNeedGoundingItem=null,be.inst.CloseGetAuctionPanel()}removeLis(){
j.i.Get(this.closeBtn.node).RemoveonClick(this._degf_CloseHandler),j.i.Get(this.selfUseBtn.node).RemoveonClick(this._degf_SelfUseHandler),
j.i.Get(this.auctionBtn.node).RemoveonClick(this._degf_AuctionHandler)}SetData(){const t=this._model.curNeedGoundingItem
if(null!=t){this.curModelId=t.modelId,this.id=t.id
J.f.Inst().getItemById(this.curModelId)
this.index=K.g.Inst_get().GetItemIndexEX(this._model.curNeedGoundingItem.id)
const e=new S.M(t.modelId)
e.serverData_set(t),e.isCanOperate=!1,this.item.SetData(e)
const i=this._model.GetAucResId(e.baseData_get()),s=Q.I.Inst().getItemByFlag(i)
if(null==s)return void H.Y.LogError((0,V.T)("auctionresource表中无此ID：")+i)
this._model.autoOpenGroundingItemId=t.id,s.initPrice<=0?this.startPrice.textSet(N.V.Inst().getStr2(10107)):this.startPrice.textSet(Z.M.IntToString(s.initPrice)),
s.buyOutPrice<=0?this.buyPrice.node.SetActive(!1):this.buyPrice.node.SetActive(!0),this.buyPrice.textSet(Z.M.IntToString(s.buyOutPrice)),
this.tipGo.SetActive(0==this._model.curGetAuctionViewType),this.auctionGo.SetActive(1==this._model.curGetAuctionViewType)
let n=0
0==this._model.curGetAuctionViewType?n=162:1==this._model.curGetAuctionViewType&&(n=171),
X.I.calVec0.Set(this.closeBtn.node.transform.GetLocalPosition().x,n,this.closeBtn.node.transform.GetLocalPosition().z),this.closeBtn.node.transform.SetLocalPosition(X.I.calVec0)
let l=10745
const o=10749
let r=!1
if(e.baseData_get().isEquip_get()){l=10746
const t=e.baseData_get().cfgEquipData_get().intPosition_get()
if(null==e.baseData_get().cfgData_get()||0!=e.baseData_get().cfgData_get().job&&Math.floor(e.baseData_get().cfgData_get().job/1e3)!=Math.floor(a.Y.Inst.PrimaryRoleInfo_get().Job_get()/1e3))t!=W.C.WINGS&&(r=!0)
else{A.l.getWearPosByPosition(t)
l=10748}}this.selfUseBtn.node.SetActive(!r)
let h=-97
r&&(h=0),X.I.calVec0.Set(h,this.auctionBtn.node.transform.GetLocalPosition().y,this.auctionBtn.node.transform.GetLocalPosition().z),
this.auctionBtn.node.transform.SetLocalPosition(X.I.calVec0),this.selfUseBtn.SetText(N.V.Inst().getStr2(o)),this.bottomTip.textSet(N.V.Inst().getStr2(l)),
this.isCanAuction=1!=e.baseData_get().AuctionState_get(),tt.d.LuaMakeGoGray(this.auctionBtn.FatherId,this.auctionBtn.ComponentId,!this.isCanAuction,!0)}}Destroy(){
null!=this.item&&this.item.Destroy(),this.tipGo=null,this.item=null,this.startPrice=null,this.buyPrice=null,this.closeBtn=null,this.selfUseBtn=null,this.auctionBtn=null,
this.itemFather=null,this.auctionGo=null,this.bottomTip=null}}class st extends z.f{constructor(){super(),this.equipView=null,this.otherView=null,this.tipGroundingView=null,
this._degf_CloseTip=null,this._degf_CloseTip=(t,e)=>this.CloseTip(t,e)}InitView(){this.equipView=new MarketGroundingEquipTipView,
this.equipView.setBinderId(this.FatherId,this.FatherComponentID,1),this.otherView=new MarketGroundingOtherView,this.otherView.setBinderId(this.FatherId,this.FatherComponentID,2),
this.tipGroundingView=new MarketTipGroundingView,this.tipGroundingView.setBinderId(this.FatherId,this.FatherComponentID,3),this.AddOrRemoveLise(),super.InitView()}OnAddToScene(){
this.SetData(MarketMainModel.GetInst().curClickGroundingData)}SetData(t){null!=t&&this.node.transform.SetLocalPosition(t.tipPos),this.equipView.SetData(t),
this.tipGroundingView.InitData(t),this.otherView.node.SetActive(!1)}AddOrRemoveLise(t){null==t&&(t=!0),
t?this.AddFullScreenCollider(this.node,this._degf_CloseTip):this.RemoveFullScreenCollider(this.node.FatherId)}CloseTip(t,e){MarketControl.inst.DelayCloseEquipTip()}Clear(){
this.equipView.Clear(),this.tipGroundingView.ClearData(),this.otherView.ClearData()}Destroy(){this.AddOrRemoveLise(!1),this.equipView.Destroy(),this.tipGroundingView.Destroy(),
this.otherView.Destroy()}}
var nt=i(65669),lt=i(93984),at=i(38836),ot=i(97960),rt=i(83207),ht=i(85602),dt=i(88653),ct=i(53824),ut=i(3859),mt=i(49067),It=i(30421),gt=i(11037),_t=i(31336),pt=i(39043),Ct=i(19519)
class St extends z.f{constructor(){super(),this.itemName=null,this.oneLabel=null,this.twoLabel=null,this.threeLabel=null,this.buyBtn=null,this.cancelBtn=null,this.closeBtn=null,
this.item=null,this.hasItemNum=null,this.mainModel=null,this.roleInfo=null,this.isCanBuy=!0,this.threeLabelVal=0,this.curModelId=0,this.curOwnerType=-1,this._degf_BuyHandler=null,
this._degf_CancelHandler=null,this._degf_CloseHandler=null,this._degf_UpdatethreeLabel=null,this._degf_GiveUpBuy=null,this._degf_GotoBuy=null,this._degf_SendBuyMsg=null,
this._degf_BuyHandler=(t,e)=>this.BuyHandler(t,e),this._degf_CancelHandler=(t,e)=>this.CancelHandler(t,e),this._degf_CloseHandler=(t,e)=>this.CloseHandler(t,e),
this._degf_UpdatethreeLabel=t=>this.UpdatethreeLabel(t),this._degf_GiveUpBuy=t=>this.GiveUpBuy(t),this._degf_GotoBuy=t=>this.GotoBuy(t),this._degf_SendBuyMsg=t=>this.SendBuyMsg(t)}
InitView(){this.itemName=new Y.Q,this.itemName.setId(this.FatherId,this.FatherComponentID,1),this.oneLabel=new Y.Q,this.oneLabel.setId(this.FatherId,this.FatherComponentID,2),
this.twoLabel=new Y.Q,this.twoLabel.setId(this.FatherId,this.FatherComponentID,3),this.threeLabel=new Y.Q,this.threeLabel.setId(this.FatherId,this.FatherComponentID,4),
this.buyBtn=new rt.s,this.buyBtn.setId(this.FatherId,this.FatherComponentID,5),this.cancelBtn=new rt.s,this.cancelBtn.setId(this.FatherId,this.FatherComponentID,6),
this.closeBtn=new rt.s,this.closeBtn.setId(this.FatherId,this.FatherComponentID,7),this.item=new ct.Z,this.item.setBinderId(this.FatherId,this.FatherComponentID,8),
this.hasItemNum=new Y.Q,this.hasItemNum.setId(this.FatherId,this.FatherComponentID,9),super.InitView(),this.mainModel=et.W.GetInst(),this.roleInfo=a.Y.Inst.PrimaryRoleInfo_get()}
OnAddToScene(){this.addLis(),this.SetData()}Clear(){this.removeLis()}addLis(){j.i.Get(this.buyBtn.node).RegistonClick(this._degf_BuyHandler),
j.i.Get(this.cancelBtn.node).RegistonClick(this._degf_CancelHandler),j.i.Get(this.closeBtn.node).RegistonClick(this._degf_CloseHandler),
this.roleInfo.AddEventHandler(ot.A.Score_NumUpdate,this._degf_UpdatethreeLabel)}CloseHandler(t,e){this.ExitFunc()}CancelHandler(t,e){this.ExitFunc()}BuyHandler(t,e){
this.isCanBuy?this.CheckJob():(Ct.J.OpenSupplyCurrencyViewByType(Ct.J.Score),this.ExitFunc())}removeLis(){j.i.Get(this.buyBtn.node).RemoveonClick(this._degf_BuyHandler),
j.i.Get(this.cancelBtn.node).RemoveonClick(this._degf_CancelHandler),j.i.Get(this.closeBtn.node).RemoveonClick(this._degf_CloseHandler),
this.roleInfo.RemoveEventHandler(ot.A.Score_NumUpdate,this._degf_UpdatethreeLabel)}ExitFunc(){this.mainModel.oneItemData=null,this.mainModel.auctionOrBuy=0,
be.inst.CloseItemAuctionTipView()}SetData(){if(null==this.mainModel.oneItemData||null==this.mainModel.oneItemData.ItemData_get())return
const t=this.mainModel.oneItemData.ItemData_get()
this.mainModel.oneItemData.Num_get()
if(this.curOwnerType=this.mainModel.oneItemData.OwnerType_get(),null!=t&&null!=t.baseData_get()&&null!=t.baseData_get().cfgData_get()){let e=t.baseData_get().cfgData_get().name
const i=A.l.GetQuality(t.baseData_get())
if(this.item.SetData(t),this.itemName.textSet(A.l.GetQualityColorStr(i,e)),t.baseData_get().isEquip_get()){
e=A.l.SetEquipName(t.baseData_get().equipInfo_get(),t.baseData_get().cfgData_get(),t.baseData_get().serverData_get())[0],this.itemName.textSet(e)}
this.curModelId=t.baseData_get().cfgData_get().id,
this.hasItemNum.textSet(N.V.Inst().getStr(10782,lt.h.eLangResource,new ht.Z([Z.M.IntToString(K.g.Inst_get().GetCurHasNumInAll(t))])))}
const e=Q.I.Inst().getItemById(this.mainModel.oneItemData.ResId_get())
this.curModelId=0
let i=0,s=0
null!=e&&(i=this.mainModel.oneItemData.AuctionPrice_get(),3!=this.mainModel.oneItemData.State_get()&&(s=e.upPrice*this.mainModel.oneItemData.Num_get()),
0!=this.mainModel.oneItemData.TotalPrice_get()&&i+s>=this.mainModel.oneItemData.TotalPrice_get()&&(s=this.mainModel.oneItemData.TotalPrice_get()-i),this.twoLabel.textSet(`${s}`),
this.threeLabelVal=i+s),this.roleInfo.Sonsign_Score_get()>=i?this.oneLabel.SetColor(dt.I.white_get()):this.oneLabel.SetColor(dt.I.red_get()),this.oneLabel.textSet(`${i}`),
this.UpdatethreeLabel(null)}UpdatethreeLabel(t){if(null==this.mainModel.oneItemData)return
this.roleInfo.Sonsign_Score_get()>=this.threeLabelVal?(this.threeLabel.SetColor(new dt.I(87/255,234/255,87/255)),this.isCanBuy=!0):(this.threeLabel.SetColor(dt.I.red_get()),
this.isCanBuy=!1),this.threeLabel.textSet(`${this.threeLabelVal}`)}Destroy(){this.item.Destroy(),this.itemName=null,this.oneLabel=null,this.twoLabel=null,this.threeLabel=null,
this.buyBtn=null,this.cancelBtn=null,this.closeBtn=null,this.item=null,this.hasItemNum=null}CheckJob(){
const t=this.mainModel.oneItemData.ItemData_get(),e=a.Y.Inst.PrimaryRole_get().Horseinfo_get()
let i=!1
if(null!=t&&null!=t.baseData_get()&&null!=t.baseData_get().cfgData_get()){
if(_.GF.INT(t.baseData_get().cfgData_get().job/1e3)==_.GF.INT(a.Y.Inst.PrimaryRoleInfo_get().Job_get()/1e3)){const e=t.baseData_get().SuitBranch_get()
if(e>0&&e!=A.l.GetJobBranch(a.Y.Inst.PrimaryRoleInfo_get().Job_get())){
const e="AUCTION:BIDDING_CONFIRM",s=A.l.SetEquipName(t.baseData_get().equipInfo_get(),t.baseData_get().cfgData_get(),t.baseData_get().serverData_get())[0]
pt.V.Inst_get().GetData(pt.V.Inst_get().GetRolePrefix()+e)||(i=!0,this.OpenTipPanel(e,s,this._degf_GotoBuy,this._degf_GiveUpBuy))}
}else if(t.baseData_get().cfgData_get().itemType==ut.q.EQUIPMENT&&_.GF.INT(t.baseData_get().cfgData_get().job/1e3)!=_.GF.INT(a.Y.Inst.PrimaryRoleInfo_get().Job_get()/1e3)){
const e="AUCTION:BIDDING_CONFIRM",s=A.l.SetEquipName(t.baseData_get().equipInfo_get(),t.baseData_get().cfgData_get(),t.baseData_get().serverData_get())[0]
pt.V.Inst_get().GetData(pt.V.Inst_get().GetRolePrefix()+e)||(i=!0,this.OpenTipPanel(e,s,this._degf_GotoBuy,this._degf_GiveUpBuy))
}else if(t.baseData_get().cfgData_get().itemType==ut.q.RIDINGSOUL){const s=t.baseData_get().cfgData_get().id,n=gt.D.GetInst().getActiviteCfg(s).horseId
if(e.isActiveById(n)||K.g.Inst_get().GetItemNum(s)>0||K.g.Inst_get().CheckWareHouseItemById(s)){const t="AUCTION:BUYOUT_RINDING_CONFIRM"
pt.V.Inst_get().GetData(pt.V.Inst_get().GetRolePrefix()+t)||(i=!0,this.OpenTipPanel(t,null,this._degf_GotoBuy,this._degf_GiveUpBuy))}
}else if(null!=It.c.Inst().getItemById(t.baseData_get().cfgData_get().GetComposeID())){const e=It.c.Inst().getItemById(t.baseData_get().cfgData_get().GetComposeID())
if(e.composeTabs==_t.K.GuardTab){const t=It.c.Inst().getItemByClassify(e.oneClauses,e.composeTabs),s=new ht.Z
let n=!1,l=0
if(null!=t)for(;l<t.count;)t[l].id==e.id&&(n=!0),n&&s.Add(t[l].resultList[0].modelId),l+=1
let a=!1
for(l=0;l<s.count;){if(this.CheckEquipById(s[l])){a=!0
break}l+=1}if(!a){const t=e.itemConsumesList[1].modelId;(K.g.Inst_get().GetItemNum(t)>0||K.g.Inst_get().CheckWareHouseItemById(t))&&(a=!0)}if(a){
const t="AUCTION:BUYOUT_GUARD_CONFIRM"
pt.V.Inst_get().GetData(pt.V.Inst_get().GetRolePrefix()+t)||(i=!0,this.OpenTipPanel(t,null,this._degf_GotoBuy,this._degf_GiveUpBuy))}}}i||this.GotoBuy()}}IsWearEquipById(t){
const e=a.Y.Inst.PrimaryRoleInfo_get().AllStageEquipments_get()
let i=0
for(const[s,n]of(0,at.V5)(e))for(i=0;i<n.equipmentsGet().Count();){if(null!=n.equipmentsGet()[i]&&n.equipmentsGet()[i].modelId==t)return!0
i+=1}return!1}CheckEquipById(t){return!!(this.IsWearEquipById(t)||K.g.Inst_get().GetItemNum(t)>0||K.g.Inst_get().CheckWareHouseItemById(t))}OpenTipPanel(t,e,i,s){const n=new mt.B
n.infoId=t,null!=e&&n.replaceParams.Add(e),n.cancelText=(0,V.T)("坚持竞价"),n.cancelHandle=i,n.confirmText=(0,V.T)("放弃竞价"),n.confirmHandle=s,T.t.Inst().Open(n)}GiveUpBuy(t){
this.ExitFunc()}GotoBuy(t){let e=!1
if(this.mainModel.oneItemData.HasBidSameGoods_get()){const t="AUCTION:BUY_TOP_CONFIRM"
pt.V.Inst_get().GetData(pt.V.Inst_get().GetRolePrefix()+t)||(e=!0,this.OpenTipPanel(t,null,this._degf_SendBuyMsg,this._degf_GiveUpBuy))}e||this.SendBuyMsg()}SendBuyMsg(){
this.mainModel.SendBid(1,this.curOwnerType,_.GF.INT(this.threeLabelVal))}}class ft extends z.f{constructor(){super(),this.itemName=null,this.oneLabel=null,this.twoLabel=null,
this.threeLabel=null,this.buyBtn=null,this.cancelBtn=null,this.closeBtn=null,this.item=null,this.hasItemNum=null,this.mainModel=null,this.roleInfo=null,this.isCanBuy=!0,
this.threeLabelVal=0,this.curModelId=0,this.goodsId=null,this.beforePrice=0,this.curOwnerType=-1,this.removeMoney=0,this._degf_BuyHandler=null,this._degf_CancelHandler=null,
this._degf_CloseHandler=null,this._degf_UpdatethreeLabel=null,this._degf_GiveUpBuy=null,this._degf_GotoBuy=null,this._degf_SendBuyMsg=null,
this._degf_BuyHandler=(t,e)=>this.BuyHandler(t,e),this._degf_CancelHandler=(t,e)=>this.CancelHandler(t,e),this._degf_CloseHandler=(t,e)=>this.CloseHandler(t,e),
this._degf_UpdatethreeLabel=t=>this.UpdatethreeLabel(t),this._degf_GiveUpBuy=t=>this.GiveUpBuy(t),this._degf_GotoBuy=t=>this.GotoBuy(t),this._degf_SendBuyMsg=t=>this.SendBuyMsg(t)}
InitView(){this.itemName=new Y.Q,this.itemName.setId(this.FatherId,this.FatherComponentID,1),this.oneLabel=new Y.Q,this.oneLabel.setId(this.FatherId,this.FatherComponentID,2),
this.twoLabel=new Y.Q,this.twoLabel.setId(this.FatherId,this.FatherComponentID,3),this.threeLabel=new Y.Q,this.threeLabel.setId(this.FatherId,this.FatherComponentID,4),
this.buyBtn=new F.W,this.buyBtn.setId(this.FatherId,this.FatherComponentID,5),this.cancelBtn=new F.W,this.cancelBtn.setId(this.FatherId,this.FatherComponentID,6),
this.closeBtn=new F.W,this.closeBtn.setId(this.FatherId,this.FatherComponentID,7),this.item=new ct.Z,this.item.setBinderId(this.FatherId,this.FatherComponentID,8),
this.hasItemNum=new Y.Q,this.hasItemNum.setId(this.FatherId,this.FatherComponentID,9),super.InitView(),this.mainModel=et.W.GetInst(),this.roleInfo=a.Y.Inst.PrimaryRoleInfo_get()}
OnAddToScene(){this.addLis(),this.SetData()}Clear(){this.removeLis()}addLis(){j.i.Get(this.buyBtn.node).RegistonClick(this._degf_BuyHandler),
j.i.Get(this.cancelBtn.node).RegistonClick(this._degf_CancelHandler),j.i.Get(this.closeBtn.node).RegistonClick(this._degf_CloseHandler),
this.roleInfo.AddEventHandler(ot.A.Score_NumUpdate,this._degf_UpdatethreeLabel)}CloseHandler(t,e){this.ExitFunc()}CancelHandler(t,e){this.ExitFunc()}BuyHandler(t,e){
this.isCanBuy?this.CheckJob():(Ct.J.OpenSupplyCurrencyViewByType(Ct.J.Score),this.ExitFunc())}removeLis(){j.i.Get(this.buyBtn.node).RemoveonClick(this._degf_BuyHandler),
j.i.Get(this.cancelBtn.node).RemoveonClick(this._degf_CancelHandler),j.i.Get(this.closeBtn.node).RemoveonClick(this._degf_CloseHandler),
this.roleInfo.RemoveEventHandler(ot.A.Score_NumUpdate,this._degf_UpdatethreeLabel)}ExitFunc(){this.mainModel.oneItemData=null,this.mainModel.auctionOrBuy=0,
be.inst.CloseItemBuyTipView()}SetData(){if(null==this.mainModel.oneItemData||null==this.mainModel.oneItemData.ItemData_get())return
const t=this.mainModel.oneItemData.ItemData_get()
1==this.mainModel.oneItemData.State_get()?this.removeMoney=this.mainModel.oneItemData.AuctionPrice_get():this.removeMoney=0
const e=this.mainModel.oneItemData.Num_get()
if(this.curOwnerType=this.mainModel.oneItemData.OwnerType_get(),null!=t&&null!=t.baseData_get()&&null!=t.baseData_get().cfgData_get()){let e=t.baseData_get().cfgData_get().name
const i=A.l.GetQuality(t.baseData_get())
if(this.item.SetData(t),this.itemName.textSet(A.l.GetQualityColorStr(i,e)),t.baseData_get().isEquip_get()){
e=A.l.SetEquipName(t.baseData_get().equipInfo_get(),t.baseData_get().cfgData_get(),t.baseData_get().serverData_get())[0],this.itemName.textSet(e)}
this.curModelId=t.baseData_get().cfgData_get().id,
this.hasItemNum.textSet(N.V.Inst().getStr(10782,lt.h.eLangResource,new ht.Z([Z.M.IntToString(K.g.Inst_get().GetCurHasNumInAll(t))])))}this.curModelId=0
let i=0
i=this.mainModel.oneItemData.TotalPrice_get(),this.twoLabel.textSet(`${e}`),this.threeLabelVal=i,this.UpdatethreeLabel(null)}UpdatethreeLabel(t){
if(null==this.mainModel.oneItemData)return
const e=this.roleInfo.Sonsign_Score_get(),i=this.threeLabelVal-this.removeMoney
e>=this.threeLabelVal?this.oneLabel.SetColor(dt.I.white_get()):this.oneLabel.SetColor(dt.I.red_get()),this.oneLabel.textSet(`${this.threeLabelVal}`),
e>=i?(this.threeLabel.SetColor(new dt.I(87/255,234/255,87/255)),this.isCanBuy=!0):(this.threeLabel.SetColor(dt.I.red_get()),this.isCanBuy=!1),this.threeLabel.textSet(`${i}`)}
Destroy(){this.item.Destroy(),this.itemName=null,this.oneLabel=null,this.twoLabel=null,this.threeLabel=null,this.buyBtn=null,this.cancelBtn=null,this.closeBtn=null,this.item=null,
this.hasItemNum=null}CheckJob(){const t=this.mainModel.oneItemData.ItemData_get(),e=a.Y.Inst.PrimaryRole_get().Horseinfo_get()
let i=!1
if(null!=t&&null!=t.baseData_get()&&null!=t.baseData_get().cfgData_get()){
if(_.GF.INT(t.baseData_get().cfgData_get().job/1e3)==_.GF.INT(a.Y.Inst.PrimaryRoleInfo_get().Job_get()/1e3)){const e=t.baseData_get().SuitBranch_get()
if(e>0&&e!=A.l.GetJobBranch(a.Y.Inst.PrimaryRoleInfo_get().Job_get())){
const e="AUCTION:BUY_CONFIRM",s=A.l.SetEquipName(t.baseData_get().equipInfo_get(),t.baseData_get().cfgData_get(),t.baseData_get().serverData_get())[0]
pt.V.Inst_get().GetData(pt.V.Inst_get().GetRolePrefix()+e)||(i=!0,this.OpenTipPanel(e,s,this._degf_GotoBuy,this._degf_GiveUpBuy))}
}else if(t.baseData_get().cfgData_get().itemType==ut.q.EQUIPMENT&&_.GF.INT(t.baseData_get().cfgData_get().job/1e3)!=_.GF.INT(a.Y.Inst.PrimaryRoleInfo_get().Job_get()/1e3)){
const e="AUCTION:BUY_CONFIRM",s=A.l.SetEquipName(t.baseData_get().equipInfo_get(),t.baseData_get().cfgData_get(),t.baseData_get().serverData_get())[0]
pt.V.Inst_get().GetData(pt.V.Inst_get().GetRolePrefix()+e)||(i=!0,this.OpenTipPanel(e,s,this._degf_GotoBuy,this._degf_GiveUpBuy))
}else if(t.baseData_get().cfgData_get().itemType==ut.q.RIDINGSOUL){const s=t.baseData_get().cfgData_get().id,n=gt.D.GetInst().getActiviteCfg(s).horseId
if(e.isActiveById(n)||K.g.Inst_get().GetItemNum(s)>0||K.g.Inst_get().CheckWareHouseItemById(s)){const t="AUCTION:BUY_RINDING_CONFIRM"
pt.V.Inst_get().GetData(pt.V.Inst_get().GetRolePrefix()+t)||(i=!0,this.OpenTipPanel(t,null,this._degf_GotoBuy,this._degf_GiveUpBuy))}
}else if(null!=It.c.Inst().getItemById(t.baseData_get().cfgData_get().GetComposeID())){const e=It.c.Inst().getItemById(t.baseData_get().cfgData_get().GetComposeID())
if(e.composeTabs==_t.K.GuardTab){const t=It.c.Inst().getItemByClassify(e.oneClauses,e.composeTabs),s=new ht.Z
let n=!1,l=0
if(null!=t)for(;l<t.count;)t[l].id==e.id&&(n=!0),n&&s.Add(t[l].resultList[0].modelId),l+=1
let a=!1
for(l=0;l<s.count;){if(this.CheckEquipById(s[l])){a=!0
break}l+=1}if(!a){const t=e.itemConsumesList[1].modelId;(K.g.Inst_get().GetItemNum(t)>0||K.g.Inst_get().CheckWareHouseItemById(t))&&(a=!0)}if(a){const t="AUCTION:BUY_GUARD_CONFIRM"
pt.V.Inst_get().GetData(pt.V.Inst_get().GetRolePrefix()+t)||(i=!0,this.OpenTipPanel(t,null,this._degf_GotoBuy,this._degf_GiveUpBuy))}}}i||this.GotoBuy()}}IsWearEquipById(t){
const e=a.Y.Inst.PrimaryRoleInfo_get().AllStageEquipments_get()
let i=0
for(const[s,n]of(0,at.V5)(e))for(i=0;i<n.equipmentsGet().Count();){if(null!=n.equipmentsGet()[i]&&n.equipmentsGet()[i].modelId==t)return!0
i+=1}return!1}CheckEquipById(t){return!!(this.IsWearEquipById(t)||K.g.Inst_get().GetItemNum(t)>0||K.g.Inst_get().CheckWareHouseItemById(t))}OpenTipPanel(t,e,i,s){const n=new mt.B
n.infoId=t,null!=e&&n.replaceParams.Add(e),n.cancelText=(0,V.T)("坚持购买"),n.cancelHandle=i,n.confirmText=(0,V.T)("放弃购买"),n.confirmHandle=s,T.t.Inst().Open(n)}GiveUpBuy(t){
this.ExitFunc()}GotoBuy(t){let e=!1
if(this.mainModel.oneItemData.HasBidSameGoods_get()){const t="AUCTION:BUYOUT_TOP_CONFIRM"
pt.V.Inst_get().GetData(pt.V.Inst_get().GetRolePrefix()+t)||(e=!0,this.OpenTipPanel(t,null,this._degf_SendBuyMsg,this._degf_GiveUpBuy))}e||this.SendBuyMsg()}SendBuyMsg(){
this.mainModel.SendBid(0,this.curOwnerType)}}var yt=i(8211),wt=i(31896),Dt=i(6665),Tt=i(28287),At=i(7155),vt=i(38045),Lt=i(76544),Mt=i(9057),bt=i(72005),Rt=i(20099),Pt=i(88911)
class Gt extends Mt.x{constructor(){super(),this.rechargeIcon=null,this.light=null,this.give=null,this.currencyNum_1=null,this.currencyNum_2=null,this.currencyNum_3=null,
this.currencyNum_4=null,this.rmbLabel=null,this.giveCurrencyLabel=null,this.m_res=null,this.delayExecutor=null,this.currencyNumList=null,this._degf_OnItemClick=null,
this.model=null,this.funSetRechargeBtnEnabled=null,this.delayExecutor=new Lt.p,this.currencyNumList=new ht.Z,this._degf_OnItemClick=(t,e)=>this.OnItemClick(t,e)}InitView(){
this.rechargeIcon=new bt.w,this.rechargeIcon.setId(this.FatherId,this.FatherComponentID,1),this.light=new U.z,this.light.setId(this.FatherId,this.FatherComponentID,2),
this.give=new U.z,this.give.setId(this.FatherId,this.FatherComponentID,3),this.currencyNum_1=new bt.w,this.currencyNum_1.setId(this.FatherId,this.FatherComponentID,4),
this.currencyNum_2=new bt.w,this.currencyNum_2.setId(this.FatherId,this.FatherComponentID,5),this.currencyNum_3=new bt.w,
this.currencyNum_3.setId(this.FatherId,this.FatherComponentID,6),this.currencyNum_4=new bt.w,this.currencyNum_4.setId(this.FatherId,this.FatherComponentID,7),this.rmbLabel=new Y.Q,
this.rmbLabel.setId(this.FatherId,this.FatherComponentID,8),this.giveCurrencyLabel=new Y.Q,this.giveCurrencyLabel.setId(this.FatherId,this.FatherComponentID,9),
this.currencyNum_1.SetEnabled(!1),this.currencyNumList.Add(this.currencyNum_1),this.currencyNum_2.SetEnabled(!1),this.currencyNumList.Add(this.currencyNum_2),
this.currencyNum_3.SetEnabled(!1),this.currencyNumList.Add(this.currencyNum_3),this.currencyNum_4.SetEnabled(!1),this.currencyNumList.Add(this.currencyNum_4)}OnItemClick(t,e){
const i=this.m_res
if(1==i.type){const t=a.Y.Inst.PrimaryRoleInfo_get().VipLevel_get(),e=i.GetLimitCount(t)
if(this.model.GetTodayBuyTimes(i.id)>=e)return}Rt.V.SendClickData(Pt.p.Step_273000),(r.D.IsIos||r.D.IsEditor)&&(this.light.SetActive(!0),
null==this.funSetRechargeBtnEnabled&&(this.funSetRechargeBtnEnabled=()=>this.SetRechargeBtnEnabled()),this.delayExecutor.Invoke(this.funSetRechargeBtnEnabled,200)),wt.t.inst.Buy(i)
}SetRechargeBtnEnabled(){this.light.SetActive(!1)}SetData(t){this.m_res=t
const e=Z.M.ToCharArray((0,vt.tw)(this.m_res.diamond))
for(const[t,i]of(0,at.V5)(e))null!=i&&(this.currencyNumList[t-1].SetEnabled(!0),
"0"==i?this.currencyNumList[t-1].spriteNameSet("comm_zhanli_0010"):this.currencyNumList[t-1].spriteNameSet(`comm_zhanli_000${i}`))
6==this.m_res.rmb?this.rechargeIcon.spriteNameSet("chongzhi_icon_0008"):30==this.m_res.rmb?this.rechargeIcon.spriteNameSet("chongzhi_icon_0009"):98==this.m_res.rmb?this.rechargeIcon.spriteNameSet("chongzhi_icon_0010"):198==this.m_res.rmb?this.rechargeIcon.spriteNameSet("chongzhi_icon_0011"):328==this.m_res.rmb?this.rechargeIcon.spriteNameSet("chongzhi_icon_0012"):648==this.m_res.rmb&&this.rechargeIcon.spriteNameSet("chongzhi_icon_0013"),
null!=this.m_res.giveNum&&this.m_res.giveNum>0&&(this.give.SetEnabled(!0),this.giveCurrencyLabel.textSet(`${this.m_res.giveNum}`)),this.rmbLabel.textSet(`${this.m_res.rmb}`),
j.i.Get(this.node).RegistonClick(this._degf_OnItemClick)}Clear(){this.delayExecutor.Clear(),j.i.Get(this.node).RemoveonClick(this._degf_OnItemClick)}Destroy(){
this.rechargeIcon=null,this.light=null,this.give=null,this.currencyNum_1=null,this.currencyNum_2=null,this.currencyNum_3=null,this.currencyNum_4=null,this.rmbLabel=null,
this.giveCurrencyLabel=null,this.delayExecutor.Clear(),this.delayExecutor=null}}class Ot extends z.f{constructor(){super(),this.grid=null,this.close=null,
this._degf_OnItemRefreshFun=null,this._degf_CloseHandler=null,this.model=null,this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),
this._degf_CloseHandler=(t,e)=>this.CloseHandler(t,e)}InitView(){this.grid=new Dt.A,this.grid.setId(this.FatherId,this.FatherComponentID,1),this.close=new F.W,
this.close.setId(this.FatherId,this.FatherComponentID,2),this.model=At.o.Inst_get(),this.grid.SetInitInfo("ui_market_subpackrechargeitem",this._degf_OnItemRefreshFun)}
OnAddToScene(){this.SetUIInfo(),this.addLis()}ShowCurrencyBar_get(){return Tt._.ShowSome}SetUIInfo(){let t=new ht.Z
this.model.GetDiamondRechargeList().Count()>6?(t.Add(this.model.GetDiamondRechargeList()[0]),t.Add(this.model.GetDiamondRechargeList()[1]),
t.Add(this.model.GetDiamondRechargeList()[2]),t.Add(this.model.GetDiamondRechargeList()[3]),t.Add(this.model.GetDiamondRechargeList()[4]),
t.Add(this.model.GetDiamondRechargeList()[5])):t=this.model.GetDiamondRechargeList(),this.model.DiamondRechargeCount=t.Count(),this.grid.data_set(t)}OnItemRefreshFun(t){
const e=new Gt
return e.setId(t,null,0),e}CloseHandler(t,e){be.inst.CloseSubPackRechargeView()}addLis(){j.i.Get(this.close.node).RegistonClick(this._degf_CloseHandler)}removeLis(){
j.i.Get(this.close.node).RemoveonClick(this._degf_CloseHandler)}Clear(){this.removeLis()}Destroy(){this.grid.Destroy(),this.grid=null,this.close=null}}
var Et=i(66781),Bt=i(93078),kt=i(13796),xt=i(88199),Vt=i(51322),Nt=i(86209),Ht=i(62734),Ut=i(43662),Ft=i(65227),jt=i(64213),Yt=i(73206),zt=i(41664),qt=i(78287),Zt=i(9776),Kt=i(8889),$t=i(16261),Wt=i(60130),Xt=i(16175),Qt=i(52212),Jt=i(14792),te=i(15771),ee=i(52513)
class ie extends Mt.x{constructor(){super(),this.diamond=null,this.treasure=null,this.diamondNumLabel=null,this.diamondGiftNum=null,this.moneyLabel=null,this.limitNum=null,
this.iconLeft=null,this.selfBtn=null,this.treasureName=null,this.bgSprite=null,this.bg1=null,this.topleftbg=null,this.toplefthead=null,this.diamondHeadLeft=null,
this.treasureHeadRight=null,this.giveIcon=null,this.btnEff=null,this.res=null,this.model=null,this._degf_OnItemClick=null,this._degf_OnItemClick=(t,e)=>this.OnItemClick(t,e)}
InitView(){super.InitView(),this.diamond=new U.z,this.diamond.setId(this.FatherId,this.FatherComponentID,1),this.treasure=new U.z,
this.treasure.setId(this.FatherId,this.FatherComponentID,2),this.diamondNumLabel=new Y.Q,this.diamondNumLabel.setId(this.FatherId,this.FatherComponentID,3),
this.diamondGiftNum=new Y.Q,this.diamondGiftNum.setId(this.FatherId,this.FatherComponentID,4),this.moneyLabel=new Y.Q,this.moneyLabel.setId(this.FatherId,this.FatherComponentID,6),
this.limitNum=new Y.Q,this.limitNum.setId(this.FatherId,this.FatherComponentID,7),this.iconLeft=new bt.w,this.iconLeft.setId(this.FatherId,this.FatherComponentID,13),
this.selfBtn=new U.z,this.selfBtn.setId(this.FatherId,this.FatherComponentID,15),this.treasureName=new bt.w,this.treasureName.setId(this.FatherId,this.FatherComponentID,16),
this.bgSprite=new bt.w,this.bgSprite.setId(this.FatherId,this.FatherComponentID,17),this.bg1=new U.z,this.bg1.setId(this.FatherId,this.FatherComponentID,18),this.topleftbg=new U.z,
this.topleftbg.setId(this.FatherId,this.FatherComponentID,19),this.toplefthead=new U.z,this.toplefthead.setId(this.FatherId,this.FatherComponentID,20),this.diamondHeadLeft=new U.z,
this.diamondHeadLeft.setId(this.FatherId,this.FatherComponentID,21),this.treasureHeadRight=new U.z,this.treasureHeadRight.setId(this.FatherId,this.FatherComponentID,22),
this.giveIcon=new bt.w,this.giveIcon.setId(this.FatherId,this.FatherComponentID,23),this.btnEff=new U.z,this.btnEff.setId(this.FatherId,this.FatherComponentID,24),
this.model=At.o.Inst_get()}Clear(){j.i.Get(this.node).RemoveonClick(this._degf_OnItemClick)}Destroy(){this.diamond=null,this.treasure=null,this.diamondNumLabel=null,
this.diamondGiftNum=null,this.moneyLabel=null,this.limitNum=null,this.iconLeft=null,this.selfBtn=null,this.treasureName=null,this.bgSprite=null,this.bg1=null,this.topleftbg=null,
this.toplefthead=null,this.diamondHeadLeft=null,this.treasureHeadRight=null,this.giveIcon=null,this.btnEff=null,this.res=null,this.model=null}OnItemClick(t,e){
null!=this.res&&this.model.SelectedId!=this.res.id&&(Rt.V.SendClickData(Pt.p.Step_271000),this.model.SelectedId=this.res.id,wt.t.inst.OnItemClick())}SetData(t){if(this.res=t,
this.res.id==this.model.SelectedId?(this.bgSprite.spriteNameSet("chongzhi_bt_0002"),this.btnEff.SetActive(!0)):(this.bgSprite.spriteNameSet("chongzhi_bt_0001"),
this.btnEff.SetActive(!1)),this.model.DiamondRechargeCount>6&&this.btnEff.SetActive(!1),this.iconLeft.spriteNameSet(this.res.icon),this.iconLeft.MakePixelPerfect(),
0==this.res.type){this.diamond.SetActive(!0),this.treasure.SetActive(!1),this.diamondNumLabel.textSet(`${this.res.diamond}`),this.diamondGiftNum.textSet(`${this.res.giveNum}`),
r.D.IsFenBao(!0)?this.moneyLabel.textSet(`${this.res.rmb}元`):this.moneyLabel.textSet(`￥${this.res.rmb}`),this.diamondHeadLeft.SetActive(!0),this.treasureHeadRight.SetActive(!1),
this.diamondHeadLeft.SetActive(!0),
1==this.res.giveType?this.giveIcon.spriteNameSet(Ct.J.GetCurrencyIconUrl(Ct.J.ScoreStr)):2==this.res.giveType&&this.giveIcon.spriteNameSet(Ct.J.GetCurrencyIconUrl(Ct.J.GOLD_DIAMOND_STR))
const t=this.model.GetTotalBuyTimes(this.res.id)
0==this.res.giveNum||t>0?this.toplefthead.SetActive(!1):this.toplefthead.SetActive(!0)}else if(1==this.res.type)if(this.diamond.SetActive(!1),this.treasure.SetActive(!0),
this.treasureName.spriteNameSet(this.res.treasureName),this.toplefthead.SetActive(!1),this.res.HasLimit_get()){this.limitNum.node.SetActive(!0)
const t=a.Y.Inst.PrimaryRoleInfo_get().VipLevel_get(),e=this.res.GetLimitCount(t)
this.limitNum.textSet((0,V.T)("每日限购")+(A.l.getNumStr(e)+(0,V.T)("个")))}else this.limitNum.node.SetActive(!1)
j.i.Get(this.node).RegistonClick(this._degf_OnItemClick)}}class se extends z.f{constructor(){super(),this.rmbLbl=null,this.treasureObjs=null,this.diamondObjs=null,
this.presendDiamondNum=null,this.table=null,this.todayLimitLbl=null,this.btn=null,this.modelTexture=null,this.vipSp=null,this.meiribaoxiang=null,this.meiriBaoxiangRed=null,
this.effectDrop=null,this.vipRedDot=null,this.STAGE_ID=35,this.modelDisplay=null,this.model=null,this.effectPaths=null,this.delayExecutor=null,this.effectIndex=0,
this.soundKeyList=null,this.m_res=null,this.elementid=0,this._degf_LuaOnInitedDisplayObject=null,this._degf_OnBtnClick=null,this._degf_OnItemRefreshFun=null,
this._degf_OnMeiribaoxiangClick=null,this._degf_OnVipClick=null,this._degf_PlayDiamondEffect=null,this._degf_PlayDropEffect=null,this._degf_UpdateRedDot=null,this.scrollbar=null,
this.scrollpanel=null,this.scrollView=null,this._degf_onReposition=null,this._degf_VipUpdate=null,this.funSetRechargeBtnEnabled=null,this.delayExecutor=new Lt.p,
this._degf_LuaOnInitedDisplayObject=t=>this.LuaOnInitedDisplayObject(t),this._degf_OnBtnClick=(t,e)=>this.OnBtnClick(t,e),this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),
this._degf_OnMeiribaoxiangClick=(t,e)=>this.OnMeiribaoxiangClick(t,e),this._degf_OnVipClick=(t,e)=>this.OnVipClick(t,e),this._degf_PlayDiamondEffect=()=>this.PlayDiamondEffect(),
this._degf_PlayDropEffect=()=>this.PlayDropEffect(),this._degf_UpdateRedDot=(t,e)=>this.UpdateRedDot(t,e)}InitView(){super.InitView(),this.rmbLbl=new Y.Q,
this.rmbLbl.setId(this.FatherId,this.FatherComponentID,1),this.treasureObjs=new U.z,this.treasureObjs.setId(this.FatherId,this.FatherComponentID,2),this.diamondObjs=new U.z,
this.diamondObjs.setId(this.FatherId,this.FatherComponentID,3),this.presendDiamondNum=new Y.Q,this.presendDiamondNum.setId(this.FatherId,this.FatherComponentID,4),
this.table=new Dt.A,this.table.setId(this.FatherId,this.FatherComponentID,5),this.todayLimitLbl=new Y.Q,this.todayLimitLbl.setId(this.FatherId,this.FatherComponentID,6),
this.btn=new F.W,this.btn.setId(this.FatherId,this.FatherComponentID,7),this.modelTexture=new $t.X,this.modelTexture.setId(this.FatherId,this.FatherComponentID,8),
this.vipSp=new bt.w,this.vipSp.setId(this.FatherId,this.FatherComponentID,9),this.meiribaoxiang=new U.z,this.meiribaoxiang.setId(this.FatherId,this.FatherComponentID,10),
this.meiriBaoxiangRed=new U.z,this.meiriBaoxiangRed.setId(this.FatherId,this.FatherComponentID,11),this.effectDrop=new U.z,
this.effectDrop.setId(this.FatherId,this.FatherComponentID,12),this.vipRedDot=new U.z,this.vipRedDot.setId(this.FatherId,this.FatherComponentID,13),this.vipRedDot.SetActive(!1),
this.scrollbar=new qt._,this.scrollbar.setId(this.FatherId,this.FatherComponentID,14),this.scrollpanel=new Kt.$,this.scrollpanel.setId(this.FatherId,this.FatherComponentID,15),
this.scrollView=new Zt.h,this.scrollView.setId(this.FatherId,this.FatherComponentID,16),
this.effectPaths=new ht.Z(["pre_eff_cz_zstx01","pre_eff_cz_zstx02","pre_eff_cz_zstx06","pre_eff_cz_zstx03","pre_eff_cz_zstx04","pre_eff_cz_zstx05","pre_eff_cz_zstx05","pre_eff_cz_zstx05"]),
this.model=At.o.Inst_get(),this.table.SetInitInfo("ui_market_rechargeitem",this._degf_OnItemRefreshFun),this._degf_onReposition=()=>this.onReposition(),
this.table.OnReposition_set(this._degf_onReposition),this.meiribaoxiang.SetActive(!1),this._degf_VipUpdate=t=>this.VipUpdate(t),
a.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(ot.A.VipUpdate,this._degf_VipUpdate)}VipUpdate(t){this.SetUIInfo()}InitData(){
j.i.Get(this.btn.node).RegistonClick(this._degf_OnBtnClick),j.i.Get(this.vipSp.node).RegistonClick(this._degf_OnVipClick),
j.i.Get(this.meiribaoxiang).RegistonClick(this._degf_OnMeiribaoxiangClick),Ut.M.Instance_get().ActiveStage(this.STAGE_ID),
Ht.f.Inst.AddCallback(Jt.t.VIP_IMMORTAL_BOX,this._degf_UpdateRedDot),this.modelTexture.SetMainTextureByPhoto(this.STAGE_ID),this.UpdateUI()
const t=L.P.Inst_get().IsFunctionOpened(M.x.VIP)
this.vipSp.node.SetActive(t),this.SetRechargeBtnEnabled()}onReposition(){}HideAllEffect(){this.effectDrop.SetActive(!1)}OnVipClick(t,e){te.U.inst.controller.OpenPanel()}
OnMeiribaoxiangClick(t,e){}UpdateUI(){this.SetUIInfo(),this.m_res=this.model.getCurConfig(),null!=this.m_res&&(this.SetModel(),this.RefreshShenbingRedDot())}PlayEffect(t){
const e=ee.O.Inst().GetDiamondIndex(t)
e<0||e>=this.effectPaths.count||(this.HideAllEffect(),this.effectIndex=e,this.delayExecutor.InvokeFrame(this._degf_PlayDropEffect,3),
this.delayExecutor.InvokeFrame(this._degf_PlayDiamondEffect,20))}PlayDropEffect(){this.effectDrop.SetActive(!0),null!=this.soundKeyList&&zt.j.Inst.StopByKeyList(this.soundKeyList)
const t=this.effectIndex+1,e=`DiamonDrop0${Z.M.IntToString(t)}`
this.soundKeyList=zt.j.Inst.PlayByDivision(e,null,null,!0)}PlayDiamondEffect(){
null!=this.modelDisplay&&this.modelDisplay.AttachByName(this.effectPaths[this.effectIndex],0,_.GF.INT(Xt.d.eBuff))}RefreshShenbingRedDot(){
const t=Ht.f.Inst.GetData(Jt.t.VIP_IMMORTAL_BOX)
null!=t&&this.meiriBaoxiangRed.SetActive(t.show)}UpdateRedDot(t,e){t==Jt.t.VIP_IMMORTAL_BOX&&this.meiriBaoxiangRed.SetActive(e)}playSkillElementTest(){const t=p.P.zero_get()
this.elementid=Yt.X.Inst.PlayElement(100034700,0,0,t,t,0,null,!0,1)}destroyElements(){this.elementid>0&&Yt.X.Inst.DeleteElement(this.elementid)}SetUIInfo(){
const t=this.model.GetDiamondRechargeList(),e=new p.P(0,0,0),i=new Qt.F(0,0)
this.model.DiamondRechargeCount=t.Count(),-1==this.model.SelectedId&&(this.model.SelectedId=t[0].id),p.P.Recyle(e),Qt.F.Recycle(i),this.table.data_set(t)
const s=this.model.getCurConfig()
if(null!=s)if(0==s.type)this.diamondObjs.SetActive(!1),this.treasureObjs.SetActive(!1),this.presendDiamondNum.textSet(`${s.giveNum}`)
else if(1==s.type)if(this.diamondObjs.SetActive(!1),this.treasureObjs.SetActive(!0),s.HasLimit_get()){this.todayLimitLbl.node.SetActive(!0)
const t=a.Y.Inst.PrimaryRoleInfo_get().VipLevel_get(),e=s.GetLimitCount(t),i=this.model.GetTodayBuyTimes(s.id),n=`${(0,V.T)("今日购买次数: ")}${i}/${e}`
this.todayLimitLbl.textSet(n)}else this.todayLimitLbl.node.SetActive(!1)}DestroyModel(){null!=this.modelDisplay&&(this.modelDisplay.Destroy(),this.modelDisplay=null)}SetModel(){
const t=this.m_res.modelId
this.DestroyModel(),this.modelDisplay=new jt.r,this.HideAllEffect(),this.modelDisplay.SetDefaultHide(),this.modelDisplay.SetNeedWaitAnim(),
this.modelDisplay.SetDisplayID(t,this.STAGE_ID,0,1,!1,this._degf_LuaOnInitedDisplayObject)
const e=this.m_res.GetPos(),i=this.m_res.GetRotate()
Ut.M.Instance_get().SetWorldRotation(this.STAGE_ID,0,new p.P(i[0],i[1],i[2])),this.modelDisplay.MainRole_get().SetPosXYZ(e[0],e[1],e[2]),
this.modelDisplay.MainRole_get().SetSize(this.m_res.GetScale()),this.modelDisplay.MainRole_get().SetShow(!1)}LuaOnInitedDisplayObject(t){this.PlayRealEffect()}PlayRealEffect(){
null!=this.modelDisplay&&(this.modelDisplay.MainRole_get().SetShow(!0),this.modelDisplay.MainRole_get().PassEvent(Ft.o.attack),this.PlayEffect(this.m_res.id))}OnBtnClick(t,e){
const i=this.model.getCurConfig()
if(1==i.type){const t=a.Y.Inst.PrimaryRoleInfo_get().VipLevel_get(),e=i.GetLimitCount(t)
if(this.model.GetTodayBuyTimes(i.id)>=e)return}Rt.V.SendClickData(Pt.p.Step_273000),(r.D.IsIos||r.D.IsEditor)&&(this.btn.SetIsEnabled(!1),Wt.O.makeGoGray(this.btn.node,!0,!0),
null==this.funSetRechargeBtnEnabled&&(this.funSetRechargeBtnEnabled=()=>this.SetRechargeBtnEnabled()),this.delayExecutor.Invoke(this.funSetRechargeBtnEnabled,2e3)),wt.t.inst.Buy(i)
}SetRechargeBtnEnabled(){this.btn.SetIsEnabled(!0),Wt.O.makeGoGray(this.btn.node,!1,!0)}OnItemClick(){this.UpdateUI()}OnItemRefreshFun(t){const e=new ie
return e.setId(t,null,0),e}ClearData(){j.i.Get(this.btn.node).RemoveonClick(this._degf_OnBtnClick),j.i.Get(this.vipSp.node).RemoveonClick(this._degf_OnVipClick),
j.i.Get(this.meiribaoxiang).RemoveonClick(this._degf_OnMeiribaoxiangClick),this.DestroyModel(),
Ut.M.Instance_get().DeactiveStage(this.STAGE_ID,this.modelTexture.FatherId,this.modelTexture.ComponentId),Ht.f.Inst.RemoveCallback(Jt.t.VIP_IMMORTAL_BOX,this._degf_UpdateRedDot)}
Clear(){this.DestroyModel(),this.delayExecutor.Clear(),null!=this.soundKeyList&&(zt.j.Inst.StopByKeyList(this.soundKeyList),this.soundKeyList=null)}Destroy(){
a.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(ot.A.VipUpdate,this._degf_VipUpdate),this.model.SelectedId=-1,this.table.Destroy(),this.table=null,this.destroyElements(),
this.DestroyModel(),this.rmbLbl=null,this.treasureObjs=null,this.diamondObjs=null,this.presendDiamondNum=null,this.todayLimitLbl=null,this.btn=null,this.modelTexture=null,
this.vipSp=null,this.meiribaoxiang=null,this.meiriBaoxiangRed=null,this.effectDrop=null,this.vipRedDot=null,this.model=null,this.effectPaths=null,this.delayExecutor.Clear(),
this.delayExecutor=null,this.soundKeyList=null}OnAddToScene(){}}var ne=i(62370),le=i(30849),ae=i(5468),oe=i(38962),re=i(14207),he=i(11e3),de=i(33996)
class ce{constructor(t,e){this.id=0,this.listName=null,this.normalIcon=null,this.disableIcon=null,this.subLabel=null,this.isDefaultTab=!1,this.id=Z.M.String2Int(t[0]),
this.listName=t[1],this.subLabel=e}}class ue extends Mt.x{constructor(){super(),this.button=null,this.icon=null,this.redPoint=null,this.pointId=0,this.cfgRes=null,
this._degf_OnBtnClick=null,this._degf_UpdatePointState=null,this._degf_UpdateView=null,this._degf_OnBtnClick=(t,e)=>this.OnBtnClick(t,e),
this._degf_UpdatePointState=(t,e)=>this.UpdatePointState(t,e),this._degf_UpdateView=t=>this.UpdateView(t)}InitView(){this.button=new F.W,
this.button.setId(this.FatherId,this.FatherComponentID,1),this.icon=new bt.w,this.icon.setId(this.FatherId,this.FatherComponentID,2),this.redPoint=new U.z,
this.redPoint.setId(this.FatherId,this.FatherComponentID,3)}Clear(){this.cfgRes=null,this.AddOrRemoveLis(!1)}Destroy(){this.button=null,this.icon=null,this.redPoint=null}
SetData(t){this.redPoint.SetActive(!1),this.pointId=0,this.cfgRes=t
const e=yt.N.GetInst().friendShopTabRedIds
if(e.LuaDic_ContainsKey(this.cfgRes.subLabel)){this.pointId=e[this.cfgRes.subLabel]
const t=Ht.f.Inst.GetData(this.pointId)
null!=t&&this.redPoint.SetActive(t.show)}this.AddOrRemoveLis(),this.SetIsEnabled(!this.cfgRes.isDefaultTab),this.button.SetText(this.cfgRes.listName)}AddOrRemoveLis(t){
null==t&&(t=!0),t?(j.i.Get(this.button.node).RegistonClick(this._degf_OnBtnClick),o.i.Inst.AddEventHandler(w.g.MARKET_MALL_BTN_CLICK,this._degf_UpdateView),
0!=this.pointId&&Ht.f.Inst.AddCallback(this.pointId,this._degf_UpdatePointState)):(j.i.Get(this.button.node).RemoveonClick(this._degf_OnBtnClick),
o.i.Inst.RemoveEventHandler(w.g.MARKET_MALL_BTN_CLICK,this._degf_UpdateView),0!=this.pointId&&Ht.f.Inst.RemoveCallback(this.pointId,this._degf_UpdatePointState))}
UpdatePointState(t,e){t==this.pointId&&this.redPoint.SetActive(e)}UpdateView(t){const e=t
this.cfgRes.subLabel==e?this.SetIsEnabled(!1):this.button.GetIsEnabled()||this.SetIsEnabled(!0)}SetIsEnabled(t){this.button.SetIsEnabled(t)}OnBtnClick(t,e){
o.i.Inst.RaiseEvent(w.g.MARKET_MALL_BTN_CLICK,this.cfgRes.subLabel)}}var me=i(3522),Ie=i(21554),ge=i(11162)
class _e extends Mt.x{constructor(){super(),this.showItem=null,this.buyBtn=null,this.currencySp=null,this.priceLabel=null,this.limitLabel=null,this.stateLab=null,this.bg=null,
this.cantBuyLabel=null,this.scrollLabel=null,this.overturnAnim=null,this.hxEffect=null,this.hxAnim=null,this.buyLightAnim=null,this.mallRes=null,this.state=-1,this.cfgRes=null,
this.canBuy=!0,this.normalColor=null,this.rareItemColor=null,this.interval1=-1,this._degf_BuyItemSuccessHandler=null,this._degf_OnBuyBtnClick=null,
this._degf_OnUpdateLightAnim=null,this._degf_OpenMarketButTipNormal=null,this._degf_OpenMarketButTipSpecial=null,this.buyBtnLabel=null,this.normalColor=new dt.I(.9569,.8863,.702),
this.rareItemColor=new dt.I(1,.9098,.2951),this._degf_BuyItemSuccessHandler=t=>this.BuyItemSuccessHandler(t),this._degf_OnBuyBtnClick=(t,e)=>this.OnBuyBtnClick(t,e),
this._degf_OnUpdateLightAnim=t=>this.OnUpdateLightAnim(t),this._degf_OpenMarketButTipNormal=t=>this.OpenMarketButTipNormal(t),
this._degf_OpenMarketButTipSpecial=t=>this.OpenMarketButTipSpecial(t)}InitView(){this.showItem=new $.j,this.showItem.setBinderId(this.FatherId,this.FatherComponentID,1),
this.buyBtn=new F.W,this.buyBtn.setId(this.FatherId,this.FatherComponentID,2),this.currencySp=new bt.w,this.currencySp.setId(this.FatherId,this.FatherComponentID,3),
this.priceLabel=new Y.Q,this.priceLabel.setId(this.FatherId,this.FatherComponentID,4),this.limitLabel=new Y.Q,this.limitLabel.setId(this.FatherId,this.FatherComponentID,5),
this.stateLab=new Y.Q,this.stateLab.setId(this.FatherId,this.FatherComponentID,7),this.bg=new U.z,this.bg.setId(this.FatherId,this.FatherComponentID,8),this.cantBuyLabel=new Y.Q,
this.cantBuyLabel.setId(this.FatherId,this.FatherComponentID,9),this.scrollLabel=new Y.Q,this.scrollLabel.setBinderId(this.FatherId,this.FatherComponentID,12),
this.overturnAnim=new me.k,this.overturnAnim.setId(this.FatherId,this.FatherComponentID,13),this.buyLightAnim=new U.z,
this.buyLightAnim.setId(this.FatherId,this.FatherComponentID,16),this.buyBtnLabel=new Y.Q,this.buyBtnLabel.setBinderId(this.FatherId,this.FatherComponentID,17)}Clear(){
this.CleatInterval(),this.PlayOrPauseOverturnAnim(!1),this.AddOrRemoveLis(!1),this.showItem.Clear(),this.canBuy=!0}Destroy(){this.showItem.Destroy(),this.showItem=null,
this.buyBtn=null,this.currencySp=null,this.priceLabel=null,this.limitLabel=null,this.stateLab=null,this.bg=null,this.cantBuyLabel=null,this.scrollLabel=null,this.overturnAnim=null,
this.buyLightAnim=null}SetData(t){this.AddOrRemoveLis(),this.mallRes=t,this.cfgRes=this.mallRes.Cfg_get(),this.UpdateCurrencyType(),
this.mallRes.IsFree()?(this.priceLabel.node.SetActive(!1),
this.currencySp.node.SetActive(!1)):(this.priceLabel.textSet(Nt.w.Instance.ConvertNumToString(Z.M.String2Double(this.cfgRes.consums.costs[0].subvalue))),
this.priceLabel.node.SetActive(!0),this.currencySp.node.SetActive(!0)),this.SetLimitLabel(),this.SetScrollText(),
this.cfgRes.isRare?this.scrollLabel.SetColor(this.rareItemColor):this.scrollLabel.SetColor(this.normalColor),this.stateLab.node.SetActive(!0),
3==this.cfgRes.hot?this.stateLab.textSet(_e.duzhanIcon):4==this.cfgRes.hot?this.stateLab.textSet(_e.mustBuyIcon):2==this.cfgRes.hot?this.stateLab.textSet(this.cfgRes.discount[1]/10+_e.discountIcon):1==this.cfgRes.hot?this.stateLab.textSet(_e.hotIcon):this.stateLab.node.SetActive(!1)
const e=this.mallRes.GetBagData()
"HORSE_SHOW"==e.baseData_get().cfgData_get().sign&&(e.baseData_get().tipsPos=new p.P(45,-8,0)),e.baseData_get().isShowRecommendIcon=!1,e.baseData_get().isShowMask=!0,
e.baseData_get().isMarketItem=!0,e.baseData_get().isEquipCompare=!1,this.showItem.isAddClickLis=!1,this.showItem.SetData(e.baseData_get()),this.PlayOrPauseOverturnAnim(!1)
ge.O.Inst_get().openShopData.mallId==this.cfgRes.id?(this.OnBuyBtnClick(),this.PlayOrPauseHxAnim(!0),ge.O.Inst_get().openShopData.mallId=-1):this.PlayOrPauseHxAnim(!1)}
PlayOrPauseHxAnim(t){}PlayOrPauseOverturnAnim(t){t?(this.overturnAnim.ResumeAnim(),this.overturnAnim.Play(!0,!1)):(this.overturnAnim.SetResetOnPlay(!0),
this.overturnAnim.Play(!0,!1),this.overturnAnim.StopAnim())}SetScrollText(){const t=J.f.Inst().getItemById(this.cfgRes.itemId).name
if(this.scrollLabel.textSet(t),this.cfgRes.hot>0){const t=this.scrollLabel.width()
t>150?X.I.calVec0.Set(125,-16,0):t>110?X.I.calVec0.Set(112,-16,0):X.I.calVec0.Set(95,-16,0)}else X.I.calVec0.Set(95,-16,0)
this.scrollLabel.node.transform.SetLocalPosition(X.I.calVec0)}SetLimitLabel(){this.canBuy=!0,this.state=-1
const t=this.mallRes.IsLimitBuy()
this.limitLabel.node.SetActive(t)
let e=(0,V.T)("购买已达上限")
this.cantBuyLabel.textSet("")
let i=!0
if(t){let t=`${this.cfgRes.buyLimitDesc}${this.cfgRes.GetBuyLimit()-this.mallRes.Lastnum_get()}/`
if(0!=this.cfgRes.serverBuyLimit)this.canBuy=0!=this.mallRes.RemainNum_get(),t+=this.cfgRes.serverBuyLimit
else if(-1!=this.cfgRes.buyLimit&&(t+=this.cfgRes.GetBuyLimit(),this.canBuy=0!=this.mallRes.RemainNum_get(),this.limitLabel.textSet(t),0==this.mallRes.RemainNum_get())){
const t=this.cfgRes.GetUpVip(te.U.inst.model.level_get())
this.canBuy=!1,t>0?(0==this.cfgRes.GetBuyLimit()?(this.state=0,e=`VIP${Z.M.IntToString(t)+(0,V.T)("可购买")}`):(this.state=1,e=(0,V.T)("VIP")+(Z.M.IntToString(t)+(0,V.T)("可购买更多"))),
this.limitLabel.node.SetActive(!1),this.priceLabel.node.SetActive(!1),this.currencySp.node.SetActive(!1),this.cantBuyLabel.textSet(e)):(e=(0,V.T)("购买已达上限"),
this.cantBuyLabel.textSet(e))}}0==this.mallRes.IsCanBuyWithOtherLimit()&&(this.canBuy=!1,i=!1,this.limitLabel.node.SetActive(!1),this.priceLabel.node.SetActive(i),
this.currencySp.node.SetActive(i),this.mallRes.IsCanLevelLimitBuy()?this.cfgRes.vipLimitBuy>0&&0==this.cfgRes.transferLevelLimit?(this.state=0,
e=`VIP${Z.M.IntToString(this.cfgRes.vipLimitBuy)+(0,V.T)("可购买")}`):0==this.cfgRes.vipLimitBuy&&this.cfgRes.transferLevelLimit>0?(this.state=3,
e=Z.M.IntToString(this.cfgRes.transferLimit)+((0,V.T)("转")+(Z.M.IntToString(this.cfgRes.transferLevelLimit)+(0,V.T)("级可购买")))):(this.state=0,
e=Z.M.IntToString(this.cfgRes.transferLimit)+((0,V.T)("转")+(Z.M.IntToString(this.cfgRes.transferLevelLimit)+((0,V.T)("级或VIP")+(Z.M.IntToString(this.cfgRes.vipLimitBuy)+(0,
V.T)("可购买")))))):0==this.cfgRes.LevelMaxLimit||999==this.cfgRes.LevelMaxLimit?(this.state=3,e=`${Z.M.IntToString(this.cfgRes.LevelMinLimit)}级${(0,V.T)("可购买")}`):(this.state=3,
e=`${Z.M.IntToString(this.cfgRes.LevelMinLimit)}-${Z.M.IntToString(this.cfgRes.LevelMaxLimit)}级${(0,V.T)("可购买")}`))
const s=this.mallRes.GetOpenTimeStr()
null!=s&&(this.state=3,e=s),""!=e&&this.cantBuyLabel.textSet(e),i?X.I.calVec0.Set(95,-224,0):""!=e&&X.I.calVec0.Set(95,-204,0),
this.cantBuyLabel.node.transform.SetLocalPosition(X.I.calVec0)
let n="购 买"
this.mallRes.IsFree()&&(n="免 费"),this.buyBtnLabel.textSet(n),this.buyBtn.node.SetActive(this.canBuy),this.cantBuyLabel.node.SetActive(!this.canBuy),
this.buyLightAnim.SetActive(yt.N.GetInst().IsShowPointInFriendTab(this.mallRes))}UpdateCurrencyType(){if(!this.mallRes.IsFree()){
const t=Ct.J.GetCurrencyIconUrl(this.cfgRes.consums.costs[0].subtype)
this.currencySp.node.SetActive(!0),t!=this.currencySp.spriteName()&&this.currencySp.spriteNameSet(t)}}AddOrRemoveLis(t){null==t&&(t=!0),
t?(j.i.Get(this.buyBtn.node).RegistonClick(this._degf_OnBuyBtnClick),j.i.Get(this.bg).RegistonClick(this._degf_OnBuyBtnClick),
j.i.Get(this.showItem.node).RegistonClick(this._degf_OnBuyBtnClick),yt.N.GetInst().AddEventHandler(de.G.BUY_MALLINFO,this._degf_BuyItemSuccessHandler),
a.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(ot.A.LevelUpdate,this._degf_OnUpdateLightAnim),
a.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(ot.A.ReputationUpdate,this._degf_OnUpdateLightAnim)):(j.i.Get(this.showItem.node).RemoveonClick(this._degf_OnBuyBtnClick),
j.i.Get(this.buyBtn.node).RemoveonClick(this._degf_OnBuyBtnClick),j.i.Get(this.bg).RemoveonClick(this._degf_OnBuyBtnClick),
yt.N.GetInst().RemoveEventHandler(de.G.BUY_MALLINFO,this._degf_BuyItemSuccessHandler),o.i.Inst.RemoveEventHandler(w.g.TipsLoadCompelete,this._degf_OpenMarketButTipSpecial),
o.i.Inst.RemoveEventHandler(w.g.TipsLoadCompelete,this._degf_OpenMarketButTipNormal),
a.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(ot.A.LevelUpdate,this._degf_OnUpdateLightAnim),
a.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(ot.A.ReputationUpdate,this._degf_OnUpdateLightAnim))}OnUpdateLightAnim(t){
this.buyLightAnim.SetActive(yt.N.GetInst().IsShowPointInFriendTab(this.mallRes)),this.mallRes.Reset_RemainNum(),this.SetData(this.mallRes)}BuyItemSuccessHandler(t){
const e=_.GF.INT(t)
this.mallRes.mallid==e&&(this.mallRes=yt.N.GetInst().GetInfo(e),this.mallRes.lastRemainNum>0&&0==this.mallRes.RemainNum_get()&&this.PlayOrPauseOverturnAnim(!0),
this.SetLimitLabel())}CleatInterval(){-1!=this.interval1&&(d.C.Inst_get().ClearInterval(this.interval1),this.interval1=-1)}OnBuyBtnClick(t,e){
if(1==this.state)x.y.inst.ClientSysMessage(113007)
else if(3==this.state);else if(0==this.state)x.y.inst.ClientSysMessage(113006)
else{const t=this.mallRes.IsCanBuyWithOtherLimit()
!this.canBuy&&t&&x.y.inst.ClientSysMessage(113008)}yt.N.GetInst().selectedMallItemData=this.mallRes;(new ht.Z).Add(this.showItem._baseItemData),this.CleatInterval()
p.P.zero_get()
be.inst.CloseMarketBuyTip(),"HORSE_SHOW"==this.showItem._baseItemData.cfgData_get().sign?this.canBuy&&o.i.Inst.AddEventHandler(w.g.TipsLoadCompelete,this._degf_OpenMarketButTipSpecial):this.canBuy&&o.i.Inst.AddEventHandler(w.g.TipsLoadCompelete,this._degf_OpenMarketButTipNormal),
Ie.J.Inst_get().ShowItemTip(this.showItem._baseItemData)}OpenMarketButTipSpecial(t){be.inst.OpenMarketMallBuyTip(this.mallRes,be.BuyTipPos),
o.i.Inst.RemoveEventHandler(w.g.TipsLoadCompelete,this._degf_OpenMarketButTipSpecial)}OpenMarketButTipNormal(t){be.inst.OpenMarketMallBuyTip(this.mallRes,be.BuyTipPos),
o.i.Inst.RemoveEventHandler(w.g.TipsLoadCompelete,this._degf_OpenMarketButTipNormal)}}_e.hotIcon="热销",_e.discountIcon="折",_e.duzhanIcon="独占",_e.mustBuyIcon="必买"
class pe extends le.C{constructor(){super(),this.btn_WeekLimit=null,this.btn_Common=null,this.btn_Grow=null,this.btn_Score=null,this.btn_Hornor=null,this.widget_WeekLimit=null,
this.widget_Common=null,this.widget_Grow=null,this.widget_Score=null,this.widget_Hornor=null,this.btnGrid=null,this.Btn_Friend=null,this.Widget_FriendPoint=null,
this.leftScrollview=null,this.leftGrid=null,this.rightScrollView=null,this.rightGrid=null,this.rightScrollBar=null,this.friendRedPoint=null,this._model=null,this.tabsObj=null,
this.tabsCompoent=null,this.tabShowMallDatas=null,this.curShowMallList=ae.E.s_Empty,this._degf_BuyItemSuccessHandler=null,this._degf_GetMallDataHandler=null,
this._degf_OnItemLoaded=null,this._degf_OnMallItemReposition=null,this._degf_OnMallTopTabLoaded=null,this._degf_OnMallTopTabReposition=null,this._degf_OnTabBtnLoaded=null,
this._degf_OnTabBtnReposition=null,this._degf_SortShowItemsFunc=null,this._degf_SortTabBtnFunc=null,this._degf_UpdatePointState=null,this._degf_UpdateView=null,
this._degf_commonClickHandler=null,this._degf_friendPointClickHandler=null,this._degf_growClickHandler=null,this._degf_hornorClickHandler=null,this._degf_scoreClickHandler=null,
this._degf_weekLimitClickHandler=null,this._degf_OnMallTabSelectHandler=null,this.isLoadTab=null,this.subLabel=null,this.tabShowMallDatas=new oe.X,
this._degf_BuyItemSuccessHandler=t=>this.BuyItemSuccessHandler(t),this._degf_GetMallDataHandler=t=>this.GetMallDataHandler(t),this._degf_OnItemLoaded=t=>this.OnItemLoaded(t),
this._degf_OnMallItemReposition=()=>this.OnMallItemReposition(),this._degf_OnMallTopTabLoaded=t=>this.OnMallTopTabLoaded(t),
this._degf_OnMallTopTabReposition=()=>this.OnMallTopTabReposition(),this._degf_OnTabBtnLoaded=t=>this.OnTabBtnLoaded(t),this._degf_OnTabBtnReposition=()=>this.OnTabBtnReposition(),
this._degf_SortShowItemsFunc=(t,e)=>this.SortShowItemsFunc(t,e),this._degf_SortTabBtnFunc=(t,e)=>this.SortTabBtnFunc(t,e),
this._degf_UpdatePointState=(t,e)=>this.UpdatePointState(t,e),this._degf_UpdateView=t=>this.UpdateView(t),this._degf_commonClickHandler=(t,e)=>this.commonClickHandler(t,e),
this._degf_friendPointClickHandler=(t,e)=>this.friendPointClickHandler(t,e),this._degf_growClickHandler=(t,e)=>this.growClickHandler(t,e),
this._degf_hornorClickHandler=(t,e)=>this.hornorClickHandler(t,e),this._degf_scoreClickHandler=(t,e)=>this.scoreClickHandler(t,e),
this._degf_weekLimitClickHandler=(t,e)=>this.weekLimitClickHandler(t,e),this._degf_OnMallTabSelectHandler=t=>this.OnMallTabSelectHandle(t)}InitView(){this.btn_WeekLimit=new F.W,
this.btn_WeekLimit.setId(this.FatherId,this.FatherComponentID,1),this.btn_Common=new F.W,this.btn_Common.setId(this.FatherId,this.FatherComponentID,2),this.btn_Grow=new F.W,
this.btn_Grow.setId(this.FatherId,this.FatherComponentID,3),this.btn_Score=new F.W,this.btn_Score.setId(this.FatherId,this.FatherComponentID,5),this.btn_Hornor=new F.W,
this.btn_Hornor.setId(this.FatherId,this.FatherComponentID,6),this.widget_WeekLimit=new U.z,this.widget_WeekLimit.setId(this.FatherId,this.FatherComponentID,7),
this.widget_Common=new U.z,this.widget_Common.setId(this.FatherId,this.FatherComponentID,8),this.widget_Grow=new U.z,this.widget_Grow.setId(this.FatherId,this.FatherComponentID,9),
this.widget_Score=new U.z,this.widget_Score.setId(this.FatherId,this.FatherComponentID,11),this.widget_Hornor=new U.z,
this.widget_Hornor.setId(this.FatherId,this.FatherComponentID,12),this.btnGrid=new Dt.A,this.btnGrid.setId(this.FatherId,this.FatherComponentID,13),this.Btn_Friend=new F.W,
this.Btn_Friend.setId(this.FatherId,this.FatherComponentID,14),this.Widget_FriendPoint=new U.z,this.Widget_FriendPoint.setId(this.FatherId,this.FatherComponentID,15),
this.leftScrollview=new Zt.h,this.leftScrollview.setId(this.FatherId,this.FatherComponentID,16),this.leftGrid=new Dt.A,this.leftGrid.setId(this.FatherId,this.FatherComponentID,17),
this.rightScrollView=new Zt.h,this.rightScrollView.setId(this.FatherId,this.FatherComponentID,18),this.rightGrid=new Dt.A,
this.rightGrid.setId(this.FatherId,this.FatherComponentID,19),this.rightScrollBar=new qt._,this.rightScrollBar.setId(this.FatherId,this.FatherComponentID,20),
this.friendRedPoint=new U.z,this.friendRedPoint.setId(this.FatherId,this.FatherComponentID,21),this.btnGrid.SetInitInfo("ui_market_malltabitem",this._degf_OnMallTopTabLoaded),
this.leftGrid.SetInitInfo("ui_market_mall_btnItem",this._degf_OnTabBtnLoaded),this.leftGrid.OnReposition_set(this._degf_OnTabBtnReposition),
this.rightGrid.SetInitInfo("ui_market_mall_newMallItem",this._degf_OnItemLoaded),this.rightGrid.OnReposition_set(this._degf_OnMallItemReposition),this.isLoadTab=!1,
this._model=yt.N.GetInst(),this.tabsCompoent=new he.u}OnMallItemReposition(){this.rightScrollView.ResetPosition()}OnTabBtnReposition(){this.leftScrollview.ResetPosition()}
OnItemLoaded(t){const e=new _e
return e.setId(t,null,0),m.N.inst.SetChildDepth(be.inst.GetMarketMainPanelFatherId(),t),e}OnTabBtnLoaded(t){const e=new ue
return e.setId(t,null,0),e}OnMallTopTabLoaded(t){const e=new re.E
return e.setId(t,null,0),m.N.inst.SetChildDepth(be.inst.GetMarketMainPanelFatherId(),t),e}InitTab(){
-1==this._model.mallViewType&&(this._model.mallViewType=b.L.GetInst().defaultViewType),
this.tabsCompoent.SetData(b.L.GetInst().tabItemDataList,this.btnGrid,this.node,this._model.mallViewType),
this.tabsCompoent.AddEventHandler(w.g.TAB_BTN_SELECT,this._degf_OnMallTabSelectHandler)}InitData(){this.addLis(),this.InitTab(),this.friendRedPoint.SetActive(!1)
const t=Ht.f.Inst.GetData(Jt.t.Mall_FriendShop)
null!=t&&this.friendRedPoint.SetActive(t.show)}DoReShow(){}addLis(){j.i.Get(this.btn_WeekLimit.node).RegistonClick(this._degf_weekLimitClickHandler),
j.i.Get(this.btn_Common.node).RegistonClick(this._degf_commonClickHandler),j.i.Get(this.btn_Grow.node).RegistonClick(this._degf_growClickHandler),
j.i.Get(this.btn_Score.node).RegistonClick(this._degf_scoreClickHandler),j.i.Get(this.btn_Hornor.node).RegistonClick(this._degf_hornorClickHandler),
j.i.Get(this.Btn_Friend.node).RegistonClick(this._degf_friendPointClickHandler),o.i.Inst.AddEventHandler(w.g.MARKET_MALL_BTN_CLICK,this._degf_UpdateView),
yt.N.GetInst().AddEventHandler(de.G.BUY_MALLINFO,this._degf_BuyItemSuccessHandler),yt.N.GetInst().AddEventHandler(de.G.GET_MALLS,this._degf_GetMallDataHandler),
Ht.f.Inst.AddCallback(Jt.t.Mall_FriendShop,this._degf_UpdatePointState)}UpdatePointState(t,e){t==Jt.t.Mall_FriendShop&&this.friendRedPoint.SetActive(e)}BuyItemSuccessHandler(t){
const e=_.GF.INT(t)
for(const[t,i]of(0,at.V5)(this.tabShowMallDatas)){let t=0
for(;t<i.Count();)i[t].mallid==e&&(i[t]=this._model.GetInfo(e)),t+=1}}UpdateView(t){this.subLabel=t,this.UpdateRightItemView(this.subLabel)}removeLis(){
j.i.Get(this.btn_WeekLimit.node).RemoveonClick(this._degf_weekLimitClickHandler),j.i.Get(this.btn_Common.node).RemoveonClick(this._degf_commonClickHandler),
j.i.Get(this.btn_Grow.node).RemoveonClick(this._degf_growClickHandler),j.i.Get(this.btn_Score.node).RemoveonClick(this._degf_scoreClickHandler),
j.i.Get(this.btn_Hornor.node).RemoveonClick(this._degf_hornorClickHandler),j.i.Get(this.Btn_Friend.node).RemoveonClick(this._degf_friendPointClickHandler),
o.i.Inst.RemoveEventHandler(w.g.MARKET_MALL_BTN_CLICK,this._degf_UpdateView),yt.N.GetInst().RemoveEventHandler(de.G.BUY_MALLINFO,this._degf_BuyItemSuccessHandler),
yt.N.GetInst().RemoveEventHandler(de.G.GET_MALLS,this._degf_GetMallDataHandler),Ht.f.Inst.RemoveCallback(Jt.t.Mall_FriendShop,this._degf_UpdatePointState)}GetMallDataHandler(t){
this.showViewByType(!0)}ClearData(){this.removeLis(),this.curShowMallList=ae.E.s_Empty,this._model.mallChildViewType=-1,this._model.mallViewType=-1,this.rightGrid.Clear(),
this.leftGrid.Clear(),this.subLabel=null}OnMallTabSelectHandle(t){const e=t
this._model.mallViewType!=e&&(this._model.mallViewType=e,this.showViewByType(!0))}weekLimitClickHandler(t,e){}commonClickHandler(t,e){}growClickHandler(t,e){}
scoreClickHandler(t,e){}hornorClickHandler(t,e){}friendPointClickHandler(t,e){}UpdateLeftTabView(t){const e=new ht.Z
let i=null
for(const[t,s]of(0,at.vy)(this.tabShowMallDatas)){i=Z.M.Split(t,ne.o.s_UNDER_CHAR)
const s=new ce(i,t)
e.Add(s)}e.Sort(this._degf_SortTabBtnFunc),this.leftGrid.data_set(e)
let s=null
if(!t&&null!=this.subLabel){let t=0
for(;t<e.Count()&&(s=e[t],s.subLabel!=this.subLabel);)t+=1}if(null==s)if(-1!=this._model.defaultSonTable){let t=0
for(;t<e.Count()&&(s=e[t],s.id!=this._model.defaultSonTable);)t+=1
this._model.defaultSonTable=-1}else s=e[0]
null!=s?(s.isDefaultTab=!0,this.UpdateRightItemView(s.subLabel)):this.rightGrid.data_set(null)}SortTabBtnFunc(t,e){const i=e
return t.id-i.id}UpdateRightItemView(t){this.curShowMallList=t
const e=this.tabShowMallDatas[this.curShowMallList]
e.Sort(this._degf_SortShowItemsFunc)
const i=new ht.Z
let s=0
for(;s<e.Count();)i.Add(e[s]),s+=1
this.rightGrid.data_set(i)}SortShowItemsFunc(t,e){let i=0,s=0,n=0
return i=0,s=t.Cfg_get().order,n=e.Cfg_get().order,t.IsLimitBuy()&&0==t.RemainNum_get()&&(s=999),e.IsLimitBuy()&&0==e.RemainNum_get()&&(n=999),
s-n!=0?s-n:t.Cfg_get().order-e.Cfg_get().order}showViewByType(t){null!=this.tabsCompoent&&(null==t&&(t=!1),this.resetAllData(),this.tabShowMallDatas.LuaDic_Clear(),
this.widget_Common.SetActive(!0),this.tabShowMallDatas=this._model.GetShowLeftTabDatas(this._model.mallViewType),this.UpdateLeftTabView(t))}resetAllData(){
this.btn_WeekLimit.SetIsEnabled(!0),this.btn_Common.SetIsEnabled(!0),this.btn_Grow.SetIsEnabled(!0),this.btn_Score.SetIsEnabled(!0),this.btn_Hornor.SetIsEnabled(!0),
this.Btn_Friend.SetIsEnabled(!0),this.widget_WeekLimit.SetActive(!1),this.widget_Common.SetActive(!1),this.widget_Grow.SetActive(!1),this.widget_Score.SetActive(!1),
this.widget_Hornor.SetActive(!1),this.Widget_FriendPoint.SetActive(!1)}Destroy(){null!=this.btnGrid&&this.btnGrid.Destroy(),this.rightScrollBar=null,this.rightGrid.Destroy(),
this.leftGrid.Destroy(),this.btn_WeekLimit=null,this.btn_Common=null,this.btn_Grow=null,this.btn_Score=null,this.btn_Hornor=null,this.widget_WeekLimit=null,this.widget_Common=null,
this.widget_Grow=null,this.widget_Score=null,this.widget_Hornor=null,this.btnGrid=null,this.Btn_Friend=null,this.Widget_FriendPoint=null,this.leftScrollview=null,
this.leftGrid=null,this.rightScrollView=null,this.rightGrid=null,null!=this.tabsCompoent&&this.tabsCompoent.Destroy()}}
pe.tabIds=new ht.Z([xt.Z.MARKET_MALL_SCORE,xt.Z.MARKET_MALL_ITEM,xt.Z.MARKET_MALL_REPUTATION])
class Ce extends z.f{constructor(){super(),this.closeBtn=null,this.auctionBtn=null,this.blackMarketBtn=null,this.mallBtn=null,this.rechangeBtn=null,this.auctionWidget=null,
this.blackMarketWidget=null,this.mallWidget=null,this.rechangeWidget=null,this.auctionPoint=null,this.blackMarketPoint=null,this.mallPoint=null,this.rechangePoint=null,
this.IntergrationBtn=null,this.IntergrationPoint=null,this.IntergrationWidget=null,this.tradeBtn=null,this.tradeWidget=null,this.viewName=null,this.btnGrid=null,this.bgtop=null,
this.auctionView=null,this._model=null,this.roleInfo=null,this.rechargeView=null,this.mallView=null,this.tabsObj=null,this._degf_AuctionHandler=null,
this._degf_BlackMarketHandler=null,this._degf_CloseHandler=null,this._degf_IntergrationHandler=null,this._degf_MallHandler=null,this._degf_OnAuctionLoadComplete=null,
this._degf_OnMallLoadComplete=null,this._degf_OnRechageLoadComplete=null,this._degf_RechangeHandler=null,this._degf_TradeHandler=null,this._degf_UpdateRedPoint=null,
this.tabIds=null,this._degf_AuctionHandler=(t,e)=>this.AuctionHandler(t,e),this._degf_BlackMarketHandler=(t,e)=>this.BlackMarketHandler(t,e),
this._degf_CloseHandler=(t,e)=>this.CloseHandler(t,e),this._degf_IntergrationHandler=(t,e)=>this.IntergrationHandler(t,e),this._degf_MallHandler=(t,e)=>this.MallHandler(t,e),
this._degf_OnAuctionLoadComplete=t=>this.OnAuctionLoadComplete(t),this._degf_OnMallLoadComplete=t=>this.OnMallLoadComplete(t),
this._degf_OnRechageLoadComplete=t=>this.OnRechageLoadComplete(t),this._degf_RechangeHandler=(t,e)=>this.RechangeHandler(t,e),this._degf_TradeHandler=(t,e)=>this.TradeHandler(t,e),
this._degf_UpdateRedPoint=(t,e)=>this.UpdateRedPoint(t,e)}ShowCurrencyBar_get(){
return L.P.Inst_get().IsFunctionOpened(M.x.DAILY)?Tt._.ShowGold_Dia_BindDia:Tt._.ShowGold_Score_BindDia}InitView(){this.isExclusionPanel=!0,
this.DestoryPanelLevel=z.f.DestoryLevel4,this.closeBtn=new F.W,this.closeBtn.setId(this.FatherId,this.FatherComponentID,1),this.auctionBtn=new F.W,
this.auctionBtn.setId(this.FatherId,this.FatherComponentID,2),this.blackMarketBtn=new F.W,this.blackMarketBtn.setId(this.FatherId,this.FatherComponentID,3),this.mallBtn=new F.W,
this.mallBtn.setId(this.FatherId,this.FatherComponentID,4),this.rechangeBtn=new F.W,this.rechangeBtn.setId(this.FatherId,this.FatherComponentID,5),this.auctionWidget=new U.z,
this.auctionWidget.setId(this.FatherId,this.FatherComponentID,6),this.blackMarketWidget=new U.z,this.blackMarketWidget.setId(this.FatherId,this.FatherComponentID,7),
this.mallWidget=new U.z,this.mallWidget.setId(this.FatherId,this.FatherComponentID,8),this.rechangeWidget=new U.z,this.rechangeWidget.setId(this.FatherId,this.FatherComponentID,9),
this.auctionPoint=new bt.w,this.auctionPoint.setId(this.FatherId,this.FatherComponentID,10),this.blackMarketPoint=new bt.w,
this.blackMarketPoint.setId(this.FatherId,this.FatherComponentID,11),this.mallPoint=new bt.w,this.mallPoint.setId(this.FatherId,this.FatherComponentID,12),
this.rechangePoint=new bt.w,this.rechangePoint.setId(this.FatherId,this.FatherComponentID,13),this.IntergrationBtn=new F.W,
this.IntergrationBtn.setId(this.FatherId,this.FatherComponentID,14),this.IntergrationPoint=new U.z,this.IntergrationPoint.setId(this.FatherId,this.FatherComponentID,15),
this.IntergrationWidget=new U.z,this.IntergrationWidget.setId(this.FatherId,this.FatherComponentID,16),this.tradeBtn=new F.W,
this.tradeBtn.setId(this.FatherId,this.FatherComponentID,17),this.tradeWidget=new U.z,this.tradeWidget.setId(this.FatherId,this.FatherComponentID,18),
this.viewName=this.CreateComponent(Y.Q,19),this.btnGrid=new Dt.A,this.btnGrid.setId(this.FatherId,this.FatherComponentID,20),this.bgtop=this.CreateComponent(U.z,21),
super.InitView(),this._model=et.W.GetInst(),this.roleInfo=a.Y.Inst.PrimaryRoleInfo_get(),this.mallBtn.node.SetActive(r.D.IsFenBao(!0))}DoHide(){super.DoHide(),
Et.v.inst.CloseBuyAlert()}InitBtnTab(){this.tabIds=new ht.Z([xt.Z.MARKET_MALL])
const t=new ht.Z([this.mallBtn])
r.D.IsIosShenhe()?(this.tabIds.Add(xt.Z.MARKET_RECHARGE),t.Add(this.rechangeBtn),this.rechangeBtn.node.SetActive(!0),r.D.IsFenBao(!0)&&(this.tabIds.Remove(xt.Z.MARKET_MALL),
t.Remove(this.mallBtn),this.mallBtn.node.SetActive(!1),this.tabIds.Remove(xt.Z.MARKET_RECHARGE),t.Remove(this.rechangeBtn),
this.rechangeBtn.node.SetActive(!1))):(this.tabIds.Add(xt.Z.MARKET_RECHARGE),t.Add(this.rechangeBtn),this.rechangeBtn.node.SetActive(!0)),
this.tabsObj=new Vt.G(t,this.tabIds,this.btnGrid,this.node),this.tabsObj.RefreshTab(),this.btnGrid.Reposition()}OnAddToScene(){this.addLis(),this.InitBtnTab(),
et.W.GetInst().isShowMarketUpdate=!1,this.tabsObj.RefreshTab(),this.ShowViewByType(be.inst.topUseDefaultTab),this.InitPointState()}DoReShow(){super.DoReShow(),
this._model.FirstChildViewType==D.$.Mall&&null!=this.mallView&&this.mallView.DoReShow()}GetTradeViewFatherId(){
return null!=this.auctionView?this.auctionView.GetTradeViewFatherId():null}InitPointState(){if(null!=this._model.redPointDic){let t=null
for(const[e,i]of(0,at.vy)(this._model.redPointDic))t=Ht.f.Inst.GetData(this._model.redPointDic[e]),
null!=t&&("auctionId"==e?this.auctionPoint.node.SetActive(t.show):"mallId"==e?this.mallPoint.node.SetActive(t.show):"rechangeId"==e?this.rechangePoint.node.SetActive(t.show):"intergrationId"==e&&this.IntergrationPoint.SetActive(t.show))
}}Clear(){this.removeLis(),null!=this.rechargeView&&this.rechargeView.ClearData(),this._model.FirstChildViewType=D.$.Mall,null!=this.auctionView&&this.auctionView.ClearData(),
null!=this.mallView&&this.mallView.ClearData(),null!=this.rechargeView&&this.rechargeView.ClearData(),Bt.F.Instance_get().CloseView()}SetAllData(){this.auctionBtn.SetIsEnabled(!0),
this.blackMarketBtn.SetIsEnabled(!0),this.mallBtn.SetIsEnabled(!0),this.rechangeBtn.SetIsEnabled(!0),this.IntergrationBtn.SetIsEnabled(!0),this.auctionWidget.SetActive(!1),
this.blackMarketWidget.SetActive(!1),this.mallWidget.SetActive(!1),this.rechangeWidget.SetActive(!1),this.IntergrationWidget.SetActive(!1),
null!=this.rechargeView&&this.rechargeView.ClearData(),
null!=this.mallView&&(yt.N.GetInst().mallChildViewTypeNeedReset?this.mallView.ClearData():yt.N.GetInst().mallChildViewTypeNeedReset=!0),this.tradeBtn.SetIsEnabled(!0),
this.tradeWidget.SetActive(!1)}ShowViewByType(t){null==t&&(t=!1),this.SetAllData()
let e=0
null!=this.bgtop&&this.bgtop.SetActive(!0)
let i=0
i=t?r.D.IsIosShenhe(!1)?D.$.Recharge:kt.B.GetDefaultViewType(this.tabIds):this._model.FirstChildViewType,i==D.$.Mall?(e=10377,this.mallBtn.SetIsEnabled(!1),
this.mallWidget.SetActive(!0),
this.SetMallData(),L.P.Inst_get().IsFunctionOpened(M.x.DAILY)?Nt.w.Instance.RaiseEvent(Nt.w.eUpdateCurrency,Tt._.ShowGold_Dia_BindDia):Nt.w.Instance.RaiseEvent(Nt.w.eUpdateCurrency,Tt._.ShowGold_Score_BindDia)):i==D.$.Recharge?(e=10378,
this.rechangeBtn.SetIsEnabled(!1),this.rechangeWidget.SetActive(!0),null!=this.bgtop&&this.bgtop.SetActive(!1),
Nt.w.Instance.RaiseEvent(Nt.w.eUpdateCurrency,Tt._.ShowGold_Dia_BindDia),this.SetRechargeData()):i==D.$.Intergration?(e=10382,this.IntergrationBtn.SetIsEnabled(!1),
this.IntergrationWidget.SetActive(!0),Nt.w.Instance.RaiseEvent(Nt.w.eUpdateCurrency,Tt._.ShowGold_Dia_BindDia),this.SetIntergrationData()):i==D.$.Trade&&(e=10379,
this.tradeBtn.SetIsEnabled(!1),this.tradeWidget.SetActive(!0),Nt.w.Instance.RaiseEvent(Nt.w.eUpdateCurrency,Tt._.ShowGold_Dia_BindDia))
const s=N.V.Inst().getStr(e,lt.h.eLangResource)
null!=this.viewName&&this.viewName.textSet(s)}AttenTionEquipProItemClick(t){null!=this.auctionView&&this.auctionView.AttenTionEquipProItemClick(t)}AttenTionEquipOrderItemClick(t){
null!=this.auctionView&&this.auctionView.AttenTionEquipOrderItemClick(t)}AttenTionEquipStarItemClick(t){null!=this.auctionView&&this.auctionView.AttenTionEquipStarItemClick(t)}
SetMallData(){null==this.mallView?u.g.LoadOne("ui_market_mallview",this._degf_OnMallLoadComplete):(be.inst.ReqShowMall(),this.mallView.InitData())}OnMallLoadComplete(t){
const e=t[0]
this.m_ReadyDestory?u.g.DestroyUIById(e):(this.mallView=new pe,this.mallView.setId(e,null,0),
this.mallView.node.transform.SetParent(this.mallWidget.FatherId,this.mallWidget.ComponentId),this.SetChildDepth(e),be.inst.ReqShowMall(),this.mallView.InitData())}
SetIntergrationData(){}SetRechargeData(){null==this.rechargeView?u.g.LoadOne("ui_market_rechargepanel",this._degf_OnRechageLoadComplete):this.rechargeView.InitData()}
OnRechageLoadComplete(t){const e=t[0]
this.m_ReadyDestory?u.g.DestroyUIById(e):(this.rechargeView=new se,this.rechargeView.setId(e,null,0),
this.rechargeView.node.transform.SetParent(this.rechangeWidget.FatherId,this.rechangeWidget.ComponentId),this.SetChildDepth(e),this.rechargeView.InitData())}addLis(){
if(j.i.Get(this.closeBtn.node).RegistonClick(this._degf_CloseHandler),j.i.Get(this.auctionBtn.node).RegistonClick(this._degf_AuctionHandler),
j.i.Get(this.blackMarketBtn.node).RegistonClick(this._degf_BlackMarketHandler),j.i.Get(this.mallBtn.node).RegistonClick(this._degf_MallHandler),
j.i.Get(this.rechangeBtn.node).RegistonClick(this._degf_RechangeHandler),j.i.Get(this.IntergrationBtn.node).RegistonClick(this._degf_IntergrationHandler),
j.i.Get(this.tradeBtn.node).RegistonClick(this._degf_TradeHandler),null!=this._model.redPointDic)for(const[t,e]of(0,
at.vy)(this._model.redPointDic))"auctionId"!=t&&"blackMarketId"!=t&&"exchangeId"!=t&&"mallId"!=t&&"rechangeId"!=t&&"intergrationId"!=t||Ht.f.Inst.AddCallback(this._model.redPointDic[t],this._degf_UpdateRedPoint)
this.RegGuide()}RegGuide(){}TradeHandler(t,e){this._model.FirstChildViewType=D.$.Trade,this.ShowViewByType()}IntergrationHandler(t,e){
this._model.FirstChildViewType=D.$.Intergration,this.ShowViewByType()}RechangeHandler(t,e){Rt.V.SendClickData(Pt.p.Step_275000),this._model.FirstChildViewType=D.$.Recharge,
this.ShowViewByType()}MallHandler(t,e){this._model.FirstChildViewType=D.$.Mall,this.ShowViewByType()}BlackMarketHandler(t,e){this._model.FirstChildViewType=D.$.BlackMarket,
this.ShowViewByType()}AuctionHandler(t,e){this._model.FirstChildViewType=D.$.Auction,this.ShowViewByType()}CloseHandler(t,e){be.inst.CloseMainPanel()}removeLis(){
if(j.i.Get(this.closeBtn.node).RemoveonClick(this._degf_CloseHandler),j.i.Get(this.auctionBtn.node).RemoveonClick(this._degf_AuctionHandler),
j.i.Get(this.blackMarketBtn.node).RemoveonClick(this._degf_BlackMarketHandler),j.i.Get(this.mallBtn.node).RemoveonClick(this._degf_MallHandler),
j.i.Get(this.rechangeBtn.node).RemoveonClick(this._degf_RechangeHandler),j.i.Get(this.IntergrationBtn.node).RemoveonClick(this._degf_IntergrationHandler),
j.i.Get(this.tradeBtn.node).RemoveonClick(this._degf_TradeHandler),null!=this._model.redPointDic)for(const[t,e]of(0,
at.vy)(this._model.redPointDic))"auctionId"!=t&&"blackMarketId"!=t&&"exchangeId"!=t&&"mallId"!=t&&"rechangeId"!=t&&"intergrationId"!=t||Ht.f.Inst.RemoveCallback(this._model.redPointDic[t],this._degf_UpdateRedPoint)
this.UnRegGuide()}UnRegGuide(){}UpdateRedPoint(t,e){
for(const[i,s]of(0,at.vy)(this._model.redPointDic))t==this._model.redPointDic[i]&&("auctionId"==i?this.auctionPoint.node.SetActive(e):"mallId"==i?this.mallPoint.node.SetActive(e):"rechangeId"==i?this.rechangePoint.node.SetActive(e):"intergrationId"==i&&this.IntergrationPoint.SetActive(e))
}Destroy(){null!=this.btnGrid&&this.btnGrid.Destroy(),this.closeBtn=null,this.auctionBtn=null,this.blackMarketBtn=null,this.mallBtn=null,this.rechangeBtn=null,
this.auctionWidget=null,this.blackMarketWidget=null,this.mallWidget=null,this.rechangeWidget=null,this.auctionPoint=null,this.blackMarketPoint=null,this.mallPoint=null,
this.rechangePoint=null,this.tradeBtn=null,this.tradeWidget=null,this.viewName=null,null!=this.auctionView?(this.auctionView.ClearData(),this.auctionView.curDestory(),
u.g.DestroyUIById(this.auctionView.FatherId),this.auctionView=null):u.g.Unload(this._degf_OnAuctionLoadComplete),null!=this.mallView?(this.mallView.ClearData(),
this.mallView.Destroy(),u.g.DestroyUIById(this.mallView.FatherId),this.mallView=null):u.g.Unload(this._degf_OnMallLoadComplete),
null!=this.rechargeView?(this.rechargeView.Destroy(),u.g.DestroyUIById(this.rechargeView.FatherId),this.rechargeView=null):u.g.Unload(this._degf_OnRechageLoadComplete),
be.inst.CloseAllPanel()}getRechargePanel(){return this.rechargeView}}var Se,fe,ye,we,De,Te,Ae,ve,Le=i(49655)
function Me(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let be=(Se=(0,s.wT)("GameSys.MarketControl"),fe=(0,n.GH)(E.k.SM_OldMallGoods),ye=(0,n.GH)(E.k.SM_ShowMallRefTime),
we=(0,n.GH)(E.k.SM_MallBuy),De=(0,n.GH)(E.k.SM_ShowMall),Se(((ve=class t{static get inst(){return null==t._inst&&(t._inst=new t),t._inst}constructor(){this.mainPanel=null,
this.subPackRechargeView=null,this.itemBuyTipView=null,this.auctionView=null,this.auctionTipView=null,this.itemTipView=null,this.equipTipView=null,this.marketMallBuyTip=null,
this.m_curSelectedData=null,this.buyTipPos=null,this.marketMallAccessView=null,this.accessViewData=null,this.totalPrice=0,this.topUseDefaultTab=!1,this.mallUseDefaultTab=!1,
this.blackUseDefaultTab=!1,this.tradeUseDefaultTab=!1,this.auctionUseDefaultTab=!1,this.taxView=null,this.allianceTaxView=null,this.itemTimer=-1,this.equipTimer=-1,
this._degf_AttenTionEquipOrderItemClick=null,this._degf_AttenTionEquipProItemClick=null,this._degf_AttenTionEquipStarItemClick=null,this._degf_AuctionTipViewDestroy=null,
this._degf_AuctionTipViewHandler=null,this._degf_DestroyMainView=null,this._degf_DestroySubPackRechargeView=null,this._degf_EquipTipDestroy=null,this._degf_EquipTipEndHandler=null,
this._degf_EquipTipHandler=null,this._degf_GetAuctionDestroy=null,this._degf_ItemBuyViewDestroy=null,this._degf_ItemBuyViewHandler=null,this._degf_ItemTipDestroy=null,
this._degf_ItemTipEndHandler=null,this._degf_ItemTipHandler=null,this._degf_MainHandler=null,this._degf_SubPackRechargeHandler=null,this._degf_MallBuyHandler=null,
this._degf_MarketMallAccessViewDes=null,this._degf_MarketMallBuyTipDes=null,this._degf_MarketMallBuyTipHandler=null,this._degf_OpenRechargePanel=null,
this._degf_SM_BidBeOvertakenHandler=null,this._degf_SM_BidBeOvertakenTipsHandler=null,this._degf_SM_BidHandler=null,this._degf_SM_EquipmentFollowSettingUpdateHandler=null,
this._degf_SM_FollowHandler=null,this._degf_SM_FollowItemOnShelfHandler=null,this._degf_SM_FollowListHandler=null,this._degf_SM_ItemAuctionTipsHandler=null,
this._degf_SM_NewOnShelfHandler=null,this._degf_SM_OffShelfHandler=null,this._degf_SM_OnShelfSuccessHandler=null,this._degf_SM_PackAuctionItemTipsHandler=null,
this._degf_SM_PlayerAuctionGoodsHandler=null,this._degf_SM_PlayerPartakeGoodsHandler=null,this._degf_SM_RefreshOnceGoodsHandler=null,this._degf_SM_SearchAuctionGoodsHandler=null,
this._degf_ShowGetAuctionHandler=null,this._degf_ShowMallHandler=null,this._degf_SM_AsuramAuctionStateHandler=null,this._degf_MallRefreshTimeHandler=null,this._degf_FirstLoad=null,
this.buyTipPos=new p.P,this._degf_AttenTionEquipOrderItemClick=t=>this.AttenTionEquipOrderItemClick(t),this._degf_AttenTionEquipProItemClick=t=>this.AttenTionEquipProItemClick(t),
this._degf_AttenTionEquipStarItemClick=t=>this.AttenTionEquipStarItemClick(t),this._degf_AuctionTipViewDestroy=()=>this.AuctionTipViewDestroy(),
this._degf_AuctionTipViewHandler=t=>this.AuctionTipViewHandler(t),this._degf_DestroyMainView=()=>this.DestroyMainView(),
this._degf_DestroySubPackRechargeView=()=>this.DestroySubPackRechargeView(),this._degf_EquipTipDestroy=()=>this.EquipTipDestroy(),
this._degf_EquipTipEndHandler=()=>this.EquipTipEndHandler(),this._degf_EquipTipHandler=t=>this.EquipTipHandler(t),this._degf_GetAuctionDestroy=()=>this.GetAuctionDestroy(),
this._degf_ItemBuyViewDestroy=()=>this.ItemBuyViewDestroy(),this._degf_ItemBuyViewHandler=t=>this.ItemBuyViewHandler(t),this._degf_ItemTipDestroy=()=>this.ItemTipDestroy(),
this._degf_ItemTipEndHandler=()=>this.ItemTipEndHandler(),this._degf_ItemTipHandler=t=>this.ItemTipHandler(t),this._degf_MainHandler=t=>this.MainHandler(t),
this._degf_SubPackRechargeHandler=t=>this.SubPackRechargeHandler(t),this._degf_MallBuyHandler=t=>this.MallBuyHandler(t),
this._degf_MarketMallAccessViewDes=()=>this.MarketMallAccessViewDes(),this._degf_MarketMallBuyTipDes=()=>this.MarketMallBuyTipDes(),
this._degf_MarketMallBuyTipHandler=t=>this.MarketMallBuyTipHandler(t),this._degf_OpenRechargePanel=t=>this.OpenRechargePanel(t),
this._degf_SM_BidBeOvertakenHandler=t=>this.SM_BidBeOvertakenHandler(t),this._degf_SM_BidBeOvertakenTipsHandler=t=>this.SM_BidBeOvertakenTipsHandler(t),
this._degf_SM_BidHandler=t=>this.SM_BidHandler(t),this._degf_SM_EquipmentFollowSettingUpdateHandler=t=>this.SM_EquipmentFollowSettingUpdateHandler(t),
this._degf_SM_FollowHandler=t=>this.SM_FollowHandler(t),this._degf_SM_FollowItemOnShelfHandler=t=>this.SM_FollowItemOnShelfHandler(t),
this._degf_SM_FollowListHandler=t=>this.SM_FollowListHandler(t),this._degf_SM_ItemAuctionTipsHandler=t=>this.SM_ItemAuctionTipsHandler(t),
this._degf_SM_NewOnShelfHandler=t=>this.SM_NewOnShelfHandler(t),this._degf_SM_OffShelfHandler=t=>this.SM_OffShelfHandler(t),
this._degf_SM_OnShelfSuccessHandler=t=>this.SM_OnShelfSuccessHandler(t),this._degf_SM_PackAuctionItemTipsHandler=t=>this.SM_PackAuctionItemTipsHandler(t),
this._degf_SM_PlayerAuctionGoodsHandler=t=>this.SM_PlayerAuctionGoodsHandler(t),this._degf_SM_PlayerPartakeGoodsHandler=t=>this.SM_PlayerPartakeGoodsHandler(t),
this._degf_SM_RefreshOnceGoodsHandler=t=>this.SM_RefreshOnceGoodsHandler(t),this._degf_SM_SearchAuctionGoodsHandler=t=>this.SM_SearchAuctionGoodsHandler(t),
this._degf_ShowGetAuctionHandler=t=>this.ShowGetAuctionHandler(t),this._degf_ShowMallHandler=t=>this.ShowMallHandler(t),
this._degf_SM_AsuramAuctionStateHandler=t=>this.SM_AsuramAuctionStateHandler(t),this._degf_MallRefreshTimeHandler=t=>{this.MallRefreshTimeHandler(t)},this._degf_FirstLoad=t=>{
this.FirstLoad()},this.RegistProtocol()}CloseAllPanel(){this.CloseGetAuctionPanel(),this.CloseGetAuctionPanel(),this.CloseItemAuctionTipView(),this.CloseItemBuyTipView(),
k.v.Inst_get().CloseAllView()}RegistProtocol(){o.i.Inst.AddEventHandler(w.g.OpenRechargeView,this._degf_OpenRechargePanel),
o.i.Inst.AddEventHandler(w.g.MAP_LOGIN_LOAD_COMPELETE,this._degf_FirstLoad)}FirstLoad(){yt.N.GetInst().firstload=!0}SM_OldMallGoods(t){yt.N.GetInst().oldMallGoods=t.oldMallIds,
o.i.Inst.RaiseEvent(w.g.MARKET_OLD_GOODS_UPDATE)}CM_ClickNewMall(t){const e=new R.N
e.clickMallIds=t,h.C.Inst.F_SendMsg(e)}MallRefreshTimeHandler(t){yt.N.GetInst().HandlerGoodRefreshTime(t)}SM_AsuramAuctionStateHandler(t){}SM_PackAuctionItemTipsHandler(t){}
SM_ItemAuctionTipsHandler(t){}SM_OffShelfHandler(t){}SM_PlayerPartakeGoodsHandler(t){}SM_EquipmentFollowSettingUpdateHandler(t){}SM_RefreshOnceGoodsHandler(t){}
SM_BidBeOvertakenTipsHandler(t){}SM_NewOnShelfHandler(t){}IsInMarket(){return null!=this.mainPanel&&this.mainPanel.isShow_get()}SM_FollowItemOnShelfHandler(t){}
SM_BidBeOvertakenHandler(t){}SM_PlayerAuctionGoodsHandler(t){}SM_FollowHandler(t){}SM_FollowListHandler(t){}SM_BidHandler(t){}SM_SearchAuctionGoodsHandler(t){}
SM_OnShelfSuccessHandler(t){}OpenMarketMallBuyTip(t,e){if(this.m_curSelectedData=t,this.buyTipPos.x=e.x,this.buyTipPos.y=e.y,
null!=this.marketMallBuyTip&&this.marketMallBuyTip.isShow_get())this.marketMallBuyTip.OnAddToScene()
else{const t=new c.v
t.layerType=g.F.Tip,(0,l.Yp)(Le.o.eMarketMallBuyTip,t)}}MarketMallBuyTipHandler(t){return this.marketMallBuyTip}CloseMarketBuyTip(){m.N.inst.CloseById(I.I.eMarketMallBuyTip)}
MarketMallBuyTipDes(){u.g.DestroyUIObj(this.marketMallBuyTip),this.marketMallBuyTip=null}OpenMarketMallAccessView(t,e){this.accessViewData=t,this.totalPrice=e
var i=this.accessViewData.Cfg_get().consums.costs[0].subtype
C.W.ins.OpenCurrencyAccess(i,e)}CloseMarketAccessView(){null!=this.marketMallAccessView&&m.N.inst.CloseById(I.I.MarketAccessView)}MarketMallAccessViewDes(){
u.g.DestroyUIObj(this.marketMallAccessView),this.marketMallAccessView=null}OpenMainPanel(t){if(null==t&&(t=!1),y.d.Inst_get().controller.CloseHornPanel(),T.t.Inst().Close(),
this.topUseDefaultTab=t,this.mallUseDefaultTab=t,this.blackUseDefaultTab=t,this.tradeUseDefaultTab=t,this.auctionUseDefaultTab=t,t)this.Open()
else{const t=this.GetFuncIdByViewType()
L.P.Inst_get().IsFunctionOpened(t)||-1==t?this.Open():A.l.SetFunctionTip(t)}}Open(){if(this.CloseOtherView(),r.D.IsIosShenhe(!0)&&et.W.GetInst().FirstChildViewType==D.$.Recharge){
if(null==this.subPackRechargeView){const t=new c.v
t.isShowMask=!0,t.isDefaultUITween=!0,m.N.inst.OpenById(I.I.eSubPackRechargeView,this._degf_SubPackRechargeHandler,this._degf_DestroySubPackRechargeView,t)}
et.W.GetInst().FirstChildViewType=D.$.Mall}else if(null!=this.mainPanel&&this.mainPanel.isShow_get())this.mainPanel.ShowViewByType(this.topUseDefaultTab)
else{const t=new c.v
t.isShowMask=!0,t.isDefaultUITween=!0,m.N.inst.OpenById(I.I.MarketPanel,this._degf_MainHandler,this._degf_DestroyMainView,t)}}CloseOtherView(){k.v.Inst_get().CloseAllView()}
GetMarketMainPanelFatherId(){return this.mainPanel,0}GetFuncIdByViewType(){
return et.W.GetInst().FirstChildViewType==D.$.Recharge?M.x.RECHAGE:et.W.GetInst().FirstChildViewType==D.$.Mall?M.x.MALL:-1}DestroyMainView(){u.g.DestroyUIObj(this.mainPanel),
this.mainPanel=null}DestroySubPackRechargeView(){u.g.DestroyUIObj(this.subPackRechargeView),this.subPackRechargeView=null}GetMainPanelId(){return 0}MainHandler(t){
return null==this.mainPanel&&(this.mainPanel=new Ce,this.mainPanel.setId(t,null,0)),this.mainPanel}SubPackRechargeHandler(t){
return null==this.subPackRechargeView&&(this.subPackRechargeView=new Ot,this.subPackRechargeView.setId(t,null,0)),this.subPackRechargeView}CloseMainPanel(){
null!=this.mainPanel&&(this.CloseMarketAccessView(),m.N.inst.ClosePanel(this.mainPanel),x.y.inst.closeCommonMessageTips())}CloseSubPackRechargeView(){
null!=this.subPackRechargeView&&m.N.inst.ClosePanel(this.subPackRechargeView)}OpenItemBuyTipView(t){et.W.GetInst().oneItemData=t,
null==this.itemBuyTipView||0==this.itemBuyTipView.isShow_get()?m.N.inst.OpenById(I.I.MarketItemBuyTip,this._degf_ItemBuyViewHandler,this._degf_ItemBuyViewDestroy):this.itemBuyTipView.SetData()
}ItemBuyViewDestroy(){u.g.DestroyUIObj(this.itemBuyTipView),this.itemBuyTipView=null}CloseItemBuyTipView(){null!=this.itemBuyTipView&&m.N.inst.ClosePanel(this.itemBuyTipView)}
OpenItemAuctionTipView(t){
et.W.GetInst().oneItemData=t,null==this.auctionTipView||0==this.auctionTipView.isShow_get()?m.N.inst.OpenById(I.I.MarketItemAuctionTip,this._degf_AuctionTipViewHandler,this._degf_AuctionTipViewDestroy):this.auctionTipView.SetData()
}AuctionTipViewDestroy(){u.g.DestroyUIObj(this.auctionTipView),this.auctionTipView=null}AuctionTipViewHandler(t){return null==this.auctionTipView&&(this.auctionTipView=new St,
this.auctionTipView.setId(t,null,0)),this.auctionTipView}ItemBuyViewHandler(t){return null==this.itemBuyTipView&&(this.itemBuyTipView=new ft,this.itemBuyTipView.setId(t,null,0)),
this.itemBuyTipView}CloseItemAuctionTipView(){null!=this.auctionTipView&&m.N.inst.ClosePanel(this.auctionTipView)}OpenGetAuctionPanel(){
if(null!=this.auctionView&&this.auctionView.isShow_get())this.auctionView.SetData()
else{const t=new c.v
t.isShowMask=!0,m.N.inst.OpenById(I.I.GetAuctionPanel,this._degf_ShowGetAuctionHandler,this._degf_GetAuctionDestroy,t)}}GetAuctionDestroy(){u.g.DestroyUIObj(this.auctionView),
this.auctionView=null}CloseGetAuctionPanel(){null!=this.auctionView&&m.N.inst.CloseById(I.I.GetAuctionPanel)}ShowGetAuctionHandler(t){
return null==this.auctionView&&(this.auctionView=new it,this.auctionView.setId(t,null,0)),this.auctionView}TaxView_get(){return this.taxView}TaxView_set(t){this.taxView=t}
AllianceTaxView_get(){return this.allianceTaxView}AllianceTaxView_set(t){this.allianceTaxView=t}ReqBuyMallItem(t,e,i,s){null==i&&(i=!1),null==s&&(s=!1),yt.N.GetInst().buyNum=e
const n=new P.H
n.buyNum=e,n.mallId=t,n.autoUse=i,n.isGmBuy=s,h.C.Inst.F_SendMsg(n)}ReqMallBuyEquip(t,e){const i=a.Y.Inst.GetPlayerInfoById(e),s=yt.N.GetInst().GetInfo(t)
if(null!=s){const n=s.Cfg_get().itemId,l=new S.M(n),a=f.b.GetUpColumnAndPos(i,l)[0]
yt.N.GetInst().buyNum=1
const o=new G.X
o.mallId=t,o.playerId=e,o.column=_.GF.INT(a/100),o.index=a%100,h.C.Inst.F_SendMsg(o)}}ReqShowMall(){const t=new O.g
h.C.Inst.F_SendMsg(t),yt.N.GetInst().isMallDataRefreshed=!1}MallBuyHandler(t){const e=t
null!=e&&(e.i18nCode>0||(yt.N.GetInst().HandleBuyMallInfo(e.mallId,e.buyNum),v.p.inst.IsInCopy()&&e.mallId==B.M.Inst_get().buyMallId&&(B.M.Inst_get().buyMallId=0,
o.i.Inst.RaiseEvent(w.g.COPYEXPPANEL_BUYSUCCESS_SKILL))))}ShowMallHandler(t){null!=t&&yt.N.GetInst().HandleMallList(t.showRecord)}OpenRechargePanel(t){wt.t.inst.OpenPanel()}
SelectOpenTipView(t){et.W.GetInst().curClickGroundingData=t,"EQUIPMENT"==t.itemData.baseData_get().cfgData_get().itemType?this.OpenEquipTipView(t):this.OpenItemTipView(t)}
OpenItemTipView(t){this.CloseEquipTipView(),d.C.Inst_get().ClearInterval(this.itemTimer),this.itemTimer=-1,
null!=this.itemTipView&&this.itemTipView.isShow_get()?this.itemTipView.SetData(t):m.N.inst.OpenById(I.I.GroundingItemTipPanel,this._degf_ItemTipHandler,this._degf_ItemTipDestroy)}
ItemTipDestroy(){u.g.DestroyUIObj(this.itemTipView),this.itemTipView=null}ItemTipHandler(t){return null==this.itemTipView&&(this.itemTipView=new nt.b,
this.itemTipView.setId(t,null,0)),this.itemTipView}CloseItemTipView(){null!=this.itemTipView&&m.N.inst.ClosePanel(this.itemTipView)}DelayCloseItemTip(){
-1==this.itemTimer&&(this.itemTimer=d.C.Inst_get().SetInterval(this._degf_ItemTipEndHandler,50,1))}ItemTipEndHandler(){d.C.Inst_get().ClearInterval(this.itemTimer),
this.itemTimer=-1,this.CloseItemTipView()}OpenEquipTipView(t){this.CloseItemTipView(),d.C.Inst_get().ClearInterval(this.equipTimer),this.equipTimer=-1,
null!=this.equipTipView&&this.equipTipView.isShow_get()?this.equipTipView.SetData(t):m.N.inst.OpenById(I.I.GroundingEquipTipPanel,this._degf_EquipTipHandler,this._degf_EquipTipDestroy)
}EquipTipDestroy(){u.g.DestroyUIObj(this.equipTipView),this.equipTipView=null}EquipTipHandler(t){return null==this.equipTipView&&(this.equipTipView=new st,
this.equipTipView.setId(t,null,0)),this.equipTipView}CloseEquipTipView(){null!=this.equipTipView&&m.N.inst.ClosePanel(this.equipTipView)}DelayCloseEquipTip(){
-1==this.equipTimer&&(this.equipTimer=d.C.Inst_get().SetInterval(this._degf_EquipTipEndHandler,50,1))}EquipTipEndHandler(){d.C.Inst_get().ClearInterval(this.equipTimer),
this.equipTimer=-1,this.CloseEquipTipView()}GetTradeView(){return null!=this.mainPanel?this.mainPanel.GetTradeViewFatherId():null}getRechargeView(){
return null!=this.mainPanel?this.mainPanel.getRechargePanel():null}AttenTionEquipProItemClick(t){null!=this.mainPanel&&this.mainPanel.AttenTionEquipProItemClick(t)}
AttenTionEquipOrderItemClick(t){null!=this.mainPanel&&this.mainPanel.AttenTionEquipOrderItemClick(t)}AttenTionEquipStarItemClick(t){
null!=this.mainPanel&&this.mainPanel.AttenTionEquipStarItemClick(t)}OpenMallByMallId(t){const e=b.L.GetInst().GetCfgById(t)
null!=e&&(et.W.GetInst().FirstChildViewType=D.$.Mall,yt.N.GetInst().defaultSonTable=e.sonTableIndex,yt.N.GetInst().defaultMallId=t,yt.N.GetInst().mallViewType=e.labelId,
this.OpenMainPanel(null))}})._inst=null,ve.BuyTipPos=new p.P(156,0,0),Me(Ae=ve,"inst",[s.n],Object.getOwnPropertyDescriptor(Ae,"inst"),Ae),
Me(Ae.prototype,"SM_OldMallGoods",[fe],Object.getOwnPropertyDescriptor(Ae.prototype,"SM_OldMallGoods"),Ae.prototype),
Me(Ae.prototype,"MallRefreshTimeHandler",[ye],Object.getOwnPropertyDescriptor(Ae.prototype,"MallRefreshTimeHandler"),Ae.prototype),
Me(Ae.prototype,"MallBuyHandler",[we],Object.getOwnPropertyDescriptor(Ae.prototype,"MallBuyHandler"),Ae.prototype),
Me(Ae.prototype,"ShowMallHandler",[De],Object.getOwnPropertyDescriptor(Ae.prototype,"ShowMallHandler"),Ae.prototype),Te=Ae))||Te)},11162:(t,e,i)=>{i.d(e,{O:()=>p})
var s=i(17409),n=i(38836),l=i(98800),a=i(56937),o=i(18202),r=i(5494),h=i(73341),d=i(75439),c=i(33138),u=i(8211),m=i(34258),I=i(77697),g=i(61149),_=i(71822)
class p{constructor(){this.openShopData=null,this.checkUseLevelLableDic=null,this._degf_ShowMallHandler=null,this.goldMainView=void 0,this.mallMainView=void 0,
this.NoviceShopView=void 0,this.openShopData={openShopId:null,openSubShopId:null,mallId:-1},this._degf_ShowMallHandler=t=>{}}static Inst_get(){return null==p.inst&&(p.inst=new p),
p.inst}Open(t,e,i,s){this.CloseOtherView(),null==t&&(t=u.N.GetInst().GetShopType(e)),1==t||3==t?this.OpenMallShop(e,i,s):this.OpenGoldShop(e,i,s)}OpenGoldShop(t,e,i){(0,
s.sR)(r.I.Market_Gold_Panel_ry),this.openShopData.openShopId=t,this.openShopData.openSubShopId=e,this.openShopData.mallId=i
const n=new a.v
n.isShowMask=!0,n.isDefaultUITween=!0,n.viewClass=m.P,(0,s.Yp)(r.I.Market_Gold_Panel_ry,n)}OpenMallShop(t,e,i){this.openShopData.openShopId=t,this.openShopData.openSubShopId=e,
this.openShopData.mallId=i
const n=new a.v
n.isShowMask=!0,n.isDefaultUITween=!0,(0,s.Yp)(r.I.MarketPanel_ry,n)}CloseOtherView(){(0,s.sR)(r.I.CurrencyBar)}OpenNoviceShopView(){
if(l.Y.Inst.PrimaryRoleInfo_get().PkPoint_get()>=1)return void g.k.inst.OpenBuyTipsPanel()
const t=h.F.Inst_get().control.DPanel_get()
if(null!=t&&t.isShow_get())t.OpenNoviceShopView()
else{I.f.Inst().getItemById(u.N.GetInst().m_npcId)
h.F.Inst_get().control.Open(u.N.GetInst().m_npcId,null,null,null,null,!0)}_.g.Inst.CloseView()}CloseNoviceShopView(){h.F.Inst_get().control.ForceClose()}IsOpen(){
return null!=this.mallMainView}GetNeedUpgradeLevel(t,e){if(!this.checkUseLevelLableDic){const t=d.D.getInstance().GetIntArray("MALL_LEVELLIMIT_NOTICE")
this.checkUseLevelLableDic={}
for(const[e,i]of(0,n.V5)(t))this.checkUseLevelLableDic[i]=!0}if(this.checkUseLevelLableDic[t]){
const t=c.f.Inst().getItemById(e),i=l.Y.Inst.PrimaryRole_get().Roleinfo_get().Level_get()
if(t.level>i)return t.level-i}return 0}OnLoadMallMainView(t){return this.mallMainView}CloseMainView(){(0,s.sR)(r.I.MarketPanel_ry)}CloseGoldMainView(){(0,
s.sR)(r.I.Market_Gold_Panel_ry)}DestroyMallMainView(){null!=this.mallMainView&&(o.g.DestroyUIObj(this.mallMainView),this.mallMainView=null)}OnLoadGoldMainView(t){
return this.goldMainView}DestroyGoldMainView(){null!=this.goldMainView&&(o.g.DestroyUIObj(this.goldMainView),this.goldMainView=null)}}p.inst=null},94998:(t,e,i)=>{i.d(e,{W:()=>$})
var s=i(93984),n=i(38836),l=i(98800),a=i(97461),o=i(98958),r=i(68662),h=i(16812),d=i(38935),c=i(62370),u=i(95721),m=i(3809),I=i(98130),g=i(98885),_=i(85602),p=i(38962),C=i(51262),S=i(79534),f=i(1240),y=i(70850),w=i(63076),D=i(59686),T=i(75363),A=i(59918),v=i(76645),L=i(92679),M=i(33314),b=i(37104),R=i(87923),P=i(44498),G=i(37648),O=i(55492),E=i(33331),B=i(48481),k=i(19983),x=i(49892),V=i(75961),N=i(62734),H=i(65550),U=i(85942),F=i(63945)
class j{constructor(){this.showText="",this.type=0,this.handler=null,this.isFinalIndex=!1,this.kind=0}ShowText_get(){return this.showText}ShowText_set(t){this.showText=t}
Type_get(){return this.type}Type_set(t){this.type=t}Handler_get(){return this.handler}Handler_set(t){this.handler=t}IsFinalIndex_get(){return this.isFinalIndex}IsFinalIndex_set(t){
this.isFinalIndex=t}Kind_get(){return this.kind}Kind_set(t){this.kind=t}}var Y=i(96574)
class z{constructor(){this._itemData=null,this._id=null,this._totalPrice=0,this._isSelf=!1,this._timer=0,this._num=0,this._type=0,this._auctionPrice=0,this._state=0,
this._startTime=0,this._endTime=0,this._isSaleFail=!1,this._isCanGetIncom=!1,this._viewType=0,this._ownerNum=0,this._ownerType=0,this.asuramId=null,this.resId=0,this.initPrice=0,
this.hasBidSameGoods=!1}ItemData_get(){return this._itemData}ItemData_set(t){this._itemData=t}TotalPrice_get(){return this._totalPrice}TotalPrice_set(t){this._totalPrice=t}
IsSelf_get(){return this._isSelf}IsSelf_set(t){this._isSelf=t}Id_get(){return this._id}Id_set(t){this._id=t}Num_get(){return this._num}Num_set(t){this._num=t}Type_get(){
return this._type}Type_set(t){this._type=t}Timer_get(){return this._timer}Timer_set(t){this._timer=t}AuctionPrice_get(){return this._auctionPrice}AuctionPrice_set(t){
this._auctionPrice=t}State_get(){return this._state}State_set(t){this._state=t}StartTime_get(){return this._startTime}StartTime_set(t){this._startTime=t}EndTime_get(){
return this._endTime}EndTime_set(t){this._endTime=t}ViewType_get(){return this._viewType}ViewType_set(t){this._viewType=t}OwnerNum_get(){return this._ownerNum}OwnerNum_set(t){
this._ownerNum=t}OwnerType_get(){return this._ownerType}OwnerType_set(t){this._ownerType=t}AsuramId_get(){return this.asuramId}AsuramId_set(t){this.asuramId=t}IsSaleFail_get(){
return this._isSaleFail}IsSaleFail_set(t){this._isSaleFail=t}IsCanGetIncom_get(){return this._isCanGetIncom}IsCanGetIncom_set(t){this._isCanGetIncom=t}ResId_get(){return this.resId
}ResId_set(t){this.resId=t}InitPrice_get(){return this.initPrice}InitPrice_set(t){this.initPrice=t}HasBidSameGoods_get(){return this.hasBidSameGoods}HasBidSameGoods_set(t){
this.hasBidSameGoods=t}}class q{constructor(){this.goodsId=null,this._itemData=null,this._type=0,this._time=0,this._tradeTax=0,this._selfIncom=0,this._totalPrice=0,
this._treeType=0,this._id=null,this.getRewardType=0,this.rewardPlayerNum=0,this.buyType=!0,this.buyPlayerName=null}ItemData_get(){return this._itemData}ItemData_set(t){
this._itemData=t}Type_get(){return this._type}Type_set(t){this._type=t}Time_get(){return this._time}Time_set(t){this._time=t}TradeTax_get(){return this._tradeTax}TradeTax_set(t){
this._tradeTax=t}TotalPrice_get(){return this._totalPrice}TotalPrice_set(t){this._totalPrice=t}TreeType_get(){return this._treeType}TreeType_set(t){this._treeType=t}Id_get(){
return this._id}Id_set(t){this._id=t}SelfIncom_get(){return this._selfIncom}SelfIncom_set(t){this._selfIncom=t}GetRewardType_get(){return this.getRewardType}GetRewardType_set(t){
this.getRewardType=t}GoodsId_get(){return this.goodsId}GoodsId_set(t){this.goodsId=t}RewardPlayerNum_get(){return this.rewardPlayerNum}RewardPlayerNum_set(t){this.rewardPlayerNum=t
}BuyType_get(){return this.buyType}BuyType_set(t){this.buyType=t}BuyPlayerName_get(){return this.buyPlayerName}BuyPlayerName_set(t){this.buyPlayerName=t}}class Z{}
Z.NormalAuction=0,Z.AllianceAuction=1,Z.AuctionGrounding=2,Z.AuctionBid=3,Z.AuctionRecord=4,Z.AuctionAttention=5,Z.CrossAuction=6
class K{constructor(){this.curItemData=null,this.isAsuram=!1}}class $ extends h.k{constructor(){super(!1,0),this.tabIndex=0,this.oneItemData=null,this.auctionOrBuy=0,
this.oneShowDataList=null,this.oneShowSellDataList=null,this.tradeDataList=null,this.groundingDataList=null,this.groundingBagDataList=null,this.attentionDataList=null,
this.attentionJewelDataList=null,this.attentionGroundingList=null,this.curSortType=-1,this.isAsc=!0,this.curSellSortType=0,this.isAscSell=!0,this.curTradeSortType=0,
this.isAscTrade=!0,this.isClickAuctionPriceSort=!1,this.isClickTotalPriceSort=!1,this.curSellSelectTreeData=null,this.curTradeSelectTreeData=null,
this.curAttentionSelectTreeData=null,this.curTreeSendData=null,this.isSelectSelfItem=!1,this.isSelectSelfJob=!1,this.transActionTax=0,this.groundingTip="",
this.curNeedGoundingItem=null,this.curGetAuctionViewType=0,this.preAuctionTime=0,this.endAuctionTime=0,this.isShowMarketUpdate=!1,this.FirstChildViewType=b.$.Mall,
this.AuctionChildViewType=0,this.ExchangeChildViewType=0,this.BidBeOverTakenItemDic=null,this.canGetRewardItemList=null,this.redPointDic=null,this.sellRedPointList=null,
this.tradeRedPointList=null,this.bidBeList=null,this.followSetting=null,this.proStrDic=null,this.equipTypeStrDic=null,this.starStrDic=null,this.proMenuDataList=null,
this.equipTypeMenuDataList=null,this.starMenuDataList=null,this.otherGroundingData=null,this.curClickGroundingData=null,this.groundingNumLimit=0,this.showEndAttentionList=null,
this.auctionTax=0,this.auctionItemDataQueue=null,this.curSelectAuctionTab="",this.curBidGoodsId=-1,this.excelAttentionIdList=null,this.attentionIdList=null,this.configRes=null,
this.curProType=0,this.curOrderType=0,this.curStarType=0,this.worldAuctionType=0,this.worldAuctionEquipType=-1,this.asuramAuctionType=-1,this.asuramAuctionEquipType=-1,
this.auctionMenuStrDic=null,this.auctionEquipMenuStrDic=null,this.auctionMenuDataList=null,this.auctionEquipMenuDataList=null,this.autoSelectRemove=0,this.autoSelectAdd=0,
this.autoOpenGroundingItemId=u.o.ZERO,this.aucStartIndex=1,this.aucEndIndex=15,this.aucAddVal=15,this.auctionItems=null,this.tradeStartIndex=1,this.tradeEndIndex=15,
this.tradeAddVal=15,this.isHasAsuramAuctionItem=!1,this._degf_AuctionMenuItemCkick=null,this._degf_BidBeTipOkHandle=null,this._degf_GroundingDataSortFunc=null,
this._degf_RevertCompare=null,this._degf_SortTradeFunc=null,this.groundingDataList=new _.Z,this.excelAttentionIdList=new _.Z,this.auctionItems=new _.Z,
this._degf_AuctionMenuItemCkick=t=>this.AuctionMenuItemCkick(t),this._degf_BidBeTipOkHandle=t=>this.BidBeTipOkHandle(t),
this._degf_GroundingDataSortFunc=(t,e)=>this.GroundingDataSortFunc(t,e),this._degf_RevertCompare=(t,e)=>this.RevertCompare(t,e),
this._degf_SortTradeFunc=(t,e)=>this.SortTradeFunc(t,e),this.redPointDic=new p.X,this.sellRedPointList=new _.Z,this.tradeRedPointList=new _.Z,this.showEndAttentionList=new _.Z,
this.auctionItemDataQueue=new _.Z,this.InitData()}static GetInst(){return null==$._inst&&($._inst=new $),$._inst}GetIsAuctionItems(t){let e=-1
if(null!=this.auctionItems&&0!=this.auctionItems.Count()){let i=0
for(;i<this.auctionItems.Count();){if(this.auctionItems[i].Equal(t)){e=i
break}i+=1}}return-1!=e&&(this.auctionItems.RemoveAt(e),!0)}ResetAucIndex(){this.aucStartIndex=1,this.aucEndIndex=15}Reset(){this.auctionItems.Clear(),this.ResetAucIndex(),
this.autoOpenGroundingItemId=u.o.ZERO,this.curProType=0,this.curOrderType=0,this.curStarType=0,this.worldAuctionType=0,this.worldAuctionEquipType=-1,this.asuramAuctionType=-1,
this.asuramAuctionEquipType=-1,this.tabIndex=0,this.oneItemData=null,this.auctionOrBuy=0,this.isHasAsuramAuctionItem=!1,null!=this.oneShowDataList&&this.oneShowDataList.Clear(),
null!=this.attentionGroundingList&&this.attentionGroundingList.Clear(),this.curSelectAuctionTab="",this.showEndAttentionList.Clear(),this.curClickGroundingData=null,
this.curSortType=-1,this.isAsc=!0,this.isClickAuctionPriceSort=!1,this.isClickTotalPriceSort=!1,this.curSellSortType=0,this.isAscSell=!0,this.curTradeSortType=0,this.isAscTrade=!0,
this.curSellSelectTreeData=null,this.curTradeSelectTreeData=null,this.curAttentionSelectTreeData=null,this.curTreeSendData=null,this.isSelectSelfItem=!1,this.isSelectSelfJob=!1,
this.curNeedGoundingItem=null,this.curGetAuctionViewType=0,this.isShowMarketUpdate=!1,this.FirstChildViewType=b.$.Mall,this.AuctionChildViewType=Z.NormalAuction,
this.BidBeOverTakenItemDic=null,null!=this.canGetRewardItemList&&this.canGetRewardItemList.Clear(),null!=this.tradeDataList&&this.tradeDataList.Clear(),
null!=this.oneShowSellDataList&&this.oneShowSellDataList.Clear(),null!=this.bidBeList&&this.bidBeList.Clear(),this.followSetting=null,this.otherGroundingData=null,
this.groundingDataList.Clear(),null!=this.groundingBagDataList&&(this.groundingBagDataList=null),this.otherGroundingData=null,this.curClickGroundingData=null,
this.auctionItemDataQueue.Clear()}InitData(){this.tabIndex=0
this.attentionGroundingList=new _.Z,this.oneShowDataList=new _.Z,this.BidBeOverTakenItemDic=new p.X,this.InitAuctionEquipMenuStrList()}InitProStrList(){
this.proMenuDataList=new _.Z,this.proStrDic=new p.X
let t=o.V.Inst().getStr2(10460),e=this.GetAttentionEquipItemData(0,1,t,F.x.inst._degf_AttenTionEquipProItemClick)
this.proMenuDataList.Add(e),this.proStrDic.LuaDic_AddOrSetItem(0,t),t=o.V.Inst().getStr2(10462),e=this.GetAttentionEquipItemData(1,1,t,F.x.inst._degf_AttenTionEquipProItemClick),
this.proMenuDataList.Add(e),this.proStrDic.LuaDic_AddOrSetItem(1,t),t=o.V.Inst().getStr2(10463),e=this.GetAttentionEquipItemData(2,1,t,F.x.inst._degf_AttenTionEquipProItemClick),
this.proMenuDataList.Add(e),this.proStrDic.LuaDic_AddOrSetItem(2,t),t=o.V.Inst().getStr2(10464),e=this.GetAttentionEquipItemData(3,1,t,F.x.inst._degf_AttenTionEquipProItemClick),
e.IsFinalIndex_set(!0),this.proMenuDataList.Add(e),this.proStrDic.LuaDic_AddOrSetItem(3,t)}InitStarStrList(){this.starMenuDataList=new _.Z,this.starStrDic=new p.X
let t=o.V.Inst().getStr2(10460),e=this.GetAttentionEquipItemData(0,2,t,F.x.inst._degf_AttenTionEquipStarItemClick)
this.starMenuDataList.Add(e),this.starStrDic.LuaDic_AddOrSetItem(0,t),t=o.V.Inst().getStr2(10715),
e=this.GetAttentionEquipItemData(1,2,t,F.x.inst._degf_AttenTionEquipStarItemClick),this.starMenuDataList.Add(e),this.starStrDic.LuaDic_AddOrSetItem(1,t),
t=o.V.Inst().getStr2(10189),e=this.GetAttentionEquipItemData(2,2,t,F.x.inst._degf_AttenTionEquipStarItemClick),this.starMenuDataList.Add(e),
this.starStrDic.LuaDic_AddOrSetItem(2,t),t=o.V.Inst().getStr2(10900),e=this.GetAttentionEquipItemData(3,2,t,F.x.inst._degf_AttenTionEquipStarItemClick),
this.starMenuDataList.Add(e),this.starStrDic.LuaDic_AddOrSetItem(3,t),t=o.V.Inst().getStr2(10972),
e=this.GetAttentionEquipItemData(4,2,t,F.x.inst._degf_AttenTionEquipStarItemClick),this.starMenuDataList.Add(e),this.starStrDic.LuaDic_AddOrSetItem(4,t)}InitEquipTypeStrList(){
let t=""
this.equipTypeMenuDataList=new _.Z,this.equipTypeStrDic=new p.X,t=o.V.Inst().getStr2(10460)
const e=this.GetAttentionEquipItemData(0,3,t,F.x.inst._degf_AttenTionEquipOrderItemClick)
this.equipTypeMenuDataList.Add(e),this.equipTypeStrDic.LuaDic_AddOrSetItem(0,t)}InitAuctionEquipMenuStrList(){let t="",e=null
this.auctionEquipMenuDataList=new _.Z,this.auctionEquipMenuStrDic=new p.X,t=o.V.Inst().getStr2(10460),e=this.GetAttentionEquipItemData(-1,5,t,this._degf_AuctionMenuItemCkick),
this.auctionEquipMenuDataList.Add(e),this.auctionEquipMenuStrDic.LuaDic_AddOrSetItem(-1,t)
for(let i=1;i<=4;i++)t=o.V.Inst().getStr2(10825+i),e=this.GetAttentionEquipItemData(i-1,5,t,this._degf_AuctionMenuItemCkick),this.auctionEquipMenuDataList.Add(e),
this.auctionEquipMenuStrDic.LuaDic_AddOrSetItem(i-1,t)
t=o.V.Inst().getStr2(10715),e=this.GetAttentionEquipItemData(-2,5,t,this._degf_AuctionMenuItemCkick),this.auctionEquipMenuDataList.Add(e),
this.auctionEquipMenuStrDic.LuaDic_AddOrSetItem(-2,t),t=o.V.Inst().getStr2(10900),e=this.GetAttentionEquipItemData(-3,5,t,this._degf_AuctionMenuItemCkick),
this.auctionEquipMenuDataList.Add(e),this.auctionEquipMenuStrDic.LuaDic_AddOrSetItem(-3,t),t=o.V.Inst().getStr2(10972),
e=this.GetAttentionEquipItemData(-4,5,t,this._degf_AuctionMenuItemCkick),this.auctionEquipMenuDataList.Add(e),this.auctionEquipMenuStrDic.LuaDic_AddOrSetItem(-4,t)
const i=this.auctionEquipMenuDataList;-1==this.worldAuctionType||0==this.worldAuctionType||(this.worldAuctionType<5&&i.RemoveAt(7),
this.worldAuctionType>0&&this.worldAuctionType<4&&i.RemoveAt(6))
const s=l.Y.Inst.PrimaryRoleInfo_get()
M.Z.IsSwordman(s.Job_get())?i.RemoveAt(3):i.RemoveAt(2)}GetAttentionEquipItemData(t,e,i,s){const n=new j
return n.Type_set(t),n.Kind_set(e),n.ShowText_set(i),n.Handler_set(s),n}AuctionMenuItemCkick(t){a.i.Inst.RaiseEvent(L.g.AuctionMenuItemClickEvent,t)}GetAuctionTabTypeByItemData(t){
if(this.curSelectAuctionTab="",null!=t){let e=I.GF.INT(l.Y.Inst.PrimaryRoleInfo_get().Job_get()/1e3)
const i=t.cfgData_get().job
0!=i&&(e=I.GF.INT(i/1e3)),this.curSelectAuctionTab=`1${c.o.s_UNDER_CHAR+(g.M.IntToString(e)+(c.o.s_UNDER_CHAR+0))}`}}GetGroundingBagDataList(){this.groundingBagDataList=new _.Z
const t=new _.Z
for(const[e,i]of(0,n.V5)(y.g.Inst_get().GetBagDataList()))this.SetGroundBagData(i,t)
let e=0,i=0
for(;i<t.Count();)this.groundingBagDataList.Add(t[i]),i+=1
this.groundingBagDataList.Count()<y.g.Inst_get().bagSize_get()&&(e=y.g.Inst_get().bagSize_get()-this.groundingBagDataList.Count())
let s=0
for(;s<e;)this.groundingBagDataList.Add(new Y.N),s+=1
return this.groundingBagDataList}SetGroundBagData(t,e){if(null!=t.baseData_get()&&null!=t.baseData_get().serverData_get()){
const i=this.GetAucResId(t.baseData_get()),s=E.I.Inst().getItemByFlag(i),n=new f.Y
n.serverData_set(t.serverData_get()),n.isnew=!1,n.baseData_get().isEquipCompare=!1,n.baseData_get().isAuctionItem=!0,n.index_set(t.index_get())
const l=new Y.N
l.itemData=n,l.tipPos=new S.P(-80,0,0).Clone(),null!=s&&t.baseData_get().AuctionState_get()>1?(!this.autoOpenGroundingItemId.Equal(u.o.ZERO)&&this.autoOpenGroundingItemId.Equal(t.serverData_get().id)&&(this.autoOpenGroundingItemId=u.o.ZERO,
l.isAutoOpenTip=!0),l.resId=s.id,l.auctionPrice=s.initPrice,l.totalPrice=s.buyOutPrice,this.groundingBagDataList.Add(l)):(l.isGray=!0,n.baseData_get().isShowRecommendIcon=!1,
e.Add(l))}}GetAucResId(t){let e=""
if(v.t.IsBindState(t.serverData_get().state)&&"0"==t.cfgData_get().validTime){let i=null,s=0,n=0,l=0
if("EQUIPMENT"==t.cfgData_get().itemType&&"WINGS"!=t.cfgEquipData_get().equipType){if(i=t.serverData_get(),0==i.Enhancelevel_get()&&0==i.equipmentAdd.addLevel){l=i.excellAttrCount,
s=i.suitId,n=i.masterId,s>0&&(s=1),n>0&&(n=1)
const a=new C.H
a.Append(t.cfgEquipData_get().equipType),a.Append(c.o.s_UNDER_CHAR),a.Append(t.cfgData_get().equipStepLv),a.Append(c.o.s_UNDER_CHAR),a.Append(l),a.Append(c.o.s_UNDER_CHAR),
a.Append(s),a.Append(c.o.s_UNDER_CHAR),a.Append(0),a.Append(c.o.s_UNDER_CHAR),a.Append(n),e=a.ToString()}}else e=g.M.IntToString(t.serverData_get().modelId)}return e}
GetProStrByIndex(t){let e=""
return this.proStrDic.LuaDic_ContainsKey(t)&&(e=this.proStrDic[t]),e}GetEquipTypeStrByIndex(t){let e=""
return this.equipTypeStrDic.LuaDic_ContainsKey(t)&&(e=this.equipTypeStrDic[t]),e}GetStarStrByIndex(t){let e=""
return this.starStrDic.LuaDic_ContainsKey(t)&&(e=this.starStrDic[t]),e}GetAuctionMenuStr(t){let e="",i=-1,s=!1
return 1==t?(this.AuctionChildViewType==Z.NormalAuction?i=this.worldAuctionType:this.AuctionChildViewType==Z.AllianceAuction&&(i=this.asuramAuctionType),
s=this.auctionMenuStrDic.LuaDic_ContainsKey(i),
s&&(e=this.auctionMenuStrDic[i])):(this.AuctionChildViewType==Z.NormalAuction?i=this.worldAuctionEquipType:this.AuctionChildViewType==Z.AllianceAuction&&(i=this.asuramAuctionEquipType),
s=this.auctionEquipMenuStrDic.LuaDic_ContainsKey(i),s&&(e=this.auctionEquipMenuStrDic[i])),e}GetPointId(t){if(null!=this.redPointDic)for(const[e,i]of(0,
n.vy)(this.redPointDic))if(e==t)return this.redPointDic[e]
return 0}InitAttntionData(t,e){null==this.attentionDataList&&(this.attentionDataList=new _.Z),null==this.attentionJewelDataList&&(this.attentionJewelDataList=new _.Z)
let i=null,s=null,l=null
const a=E.I.Inst().getItemListByLevelAndType(t,e)
if(null!=a){this.attentionDataList.Clear()
for(const[t,e]of(0,n.V5)(a)){const t=g.M.String2Int(e.flag)
G.P.Inst_get().IsFunOpenByItemId(t)&&(i=new MarketAttentionItemData,l=new B.t,l.modelId=g.M.String2Int(e.flag),s=new f.Y,s.serverData_set(l),s.baseData_get().isAuctionItem=!0,
i.ItemData_set(s),this.SetItemTipPos(s),i.ResId_set(e.id),this.attentionDataList.Add(i))}}if(null==this.attentionIdList||null==this.attentionDataList)return
let o=!1
for(const[t,e]of(0,n.V5)(this.attentionDataList)){o=!1
let t=0
for(;t<this.attentionIdList.Count();){if(e.ItemData_get().serverData_get().modelId==this.attentionIdList[t]){o=!0
break}t+=1}e.IsOnShelf_set(o)}}IsInExcelAttentionList(t){let e=!1
for(const[i,s]of(0,n.V5)(this.excelAttentionIdList))if(s==t){e=!0
break}return e||this.excelAttentionIdList.Add(t),e}GetAttentionDataByType(){if(null!=this.curAttentionSelectTreeData){
const t=g.M.Split(this.curAttentionSelectTreeData.id,c.o.s_UNDER_CHAR)
if(null==t||t.count<3)return null
if("0"!=t[2]){const e=g.M.String2Int(t[1]),i=g.M.String2Int(t[2])
return this.InitAttntionData(e,i),this.attentionDataList}const e=g.M.String2Int(t[1])
return this.InitAttntionData(e,null),this.attentionDataList}return null}GetSellViewData(){return this.sortItem(this.oneShowSellDataList),this.oneShowSellDataList}SortSellByType(){}
SortTradeByType(){if(null!=this.curTradeSelectTreeData){const t=g.M.Split(this.curTradeSelectTreeData.id,c.o.s_UNDER_CHAR)
if(null==t||t.count<3)return
"1"==t[1]&&null!=this.tradeDataList&&this.tradeDataList.Sort(this._degf_SortTradeFunc)}else null!=this.tradeDataList&&this.tradeDataList.Sort(this._degf_SortTradeFunc)}
SortTradeFunc(t,e){if(null==t||null==e)return 0
const i=t,s=e
let n=0,l=0
0==this.curTradeSortType?(n=i.Time_get(),l=s.Time_get()):1==this.curTradeSortType?(n=1==i.GetRewardType_get()?3:2==i.GetRewardType_get()?2:1,
l=1==s.GetRewardType_get()?3:2==s.GetRewardType_get()?2:1,n==l&&3==n&&(n=i.SelfIncom_get()>0?2:1,
l=s.SelfIncom_get()>0?2:1)):2==this.curTradeSortType?(null!=i.ItemData_get()&&null!=i.ItemData_get().serverData_get()&&(n=i.ItemData_get().serverData_get().modelId),
null!=s.ItemData_get()&&null!=s.ItemData_get().serverData_get()&&(l=s.ItemData_get().serverData_get().modelId)):3==this.curTradeSortType&&(n=i.TotalPrice_get(),
l=s.TotalPrice_get())
let a=0
return n>l?a=1:n<l?a=-1:null!=i.Id_get()&&null!=s.Id_get()&&(n=i.Id_get().ToNum(),l=s.Id_get().ToNum(),n>l?a=1:n<l&&(a=-1)),this.isAscTrade||(a*=-1),a}getSelectEquipLevelData(t){
if(null==this.oneShowDataList)return null
const e=new _.Z
let i=-1,s=!1,l=-1
T.Y.Inst_get().GetCurBestColumn()
let a=!0
for(const[o,r]of(0,n.V5)(this.oneShowDataList))null!=r&&null!=r.ItemData_get()&&null!=r.ItemData_get().baseData_get()&&(a=!0,
t?(1!=r.Type_get()||r.IsSaleFail_get())&&(a=!1):1!=r.Type_get()||1==r.Type_get()&&r.IsSaleFail_get()||(a=!1),
a&&(r.ItemData_get().baseData_get().isEquip_get()?(i=t?this.asuramAuctionType:this.worldAuctionType,s=!1,l=r.ItemData_get().baseData_get().cfgData_get().equipStepLv,
(0==i||l==i)&&e.Add(r),s&&e.Add(r)):e.Add(r)))
return e}getHideSelectData(t){if(null==this.oneShowDataList)return null
const e=new _.Z,i=new _.Z
if(this.isSelectSelfItem)for(const[i,s]of(0,n.V5)(this.oneShowDataList))2!=s.Type_get()&&(t?1!=s.Type_get()||s.IsSaleFail_get()||e.Add(s):(1!=s.Type_get()||1==s.Type_get()&&s.IsSaleFail_get())&&e.Add(s))
else for(const[i,s]of(0,n.V5)(this.oneShowDataList))t?1!=s.Type_get()||s.IsSaleFail_get()||e.Add(s):(1!=s.Type_get()||1==s.Type_get()&&s.IsSaleFail_get())&&e.Add(s)
if(this.isSelectSelfJob){let s=-1
for(const[a,o]of(0,n.V5)(e))null!=o&&null!=o.ItemData_get()&&null!=o.ItemData_get().baseData_get()&&null!=o.ItemData_get().baseData_get().cfgData_get()&&(s=o.ItemData_get().baseData_get().cfgData_get().job,
(0==s||M.Z.IsSameJobType(s,l.Y.Inst.PrimaryRoleInfo_get().Job_get()))&&(t?1!=o.Type_get()||o.IsSaleFail_get()||i.Add(o):(1!=o.Type_get()||1==o.Type_get()&&o.IsSaleFail_get())&&i.Add(o)))
}else for(const[s,l]of(0,n.V5)(e))t?1!=l.Type_get()||l.IsSaleFail_get()||i.Add(l):(1!=l.Type_get()||1==l.Type_get()&&l.IsSaleFail_get())&&i.Add(l)
return i}sortItem(t){return null==t||0==t.Count()||t.Sort(this._degf_RevertCompare),t}RevertCompare(t,e){return this.CompareItem(t,e)}CompareItem(t,e){const i=t,s=e
let n=1
this.isAsc||(n=-1)
let l=0,a=0
if(this.isClickAuctionPriceSort||this.isClickTotalPriceSort){if(this.isClickTotalPriceSort){if(l=i.TotalPrice_get()/i.Num_get(),a=s.TotalPrice_get()/s.Num_get(),
l<=0&&(l=Number.MAX_VALUE_get()),a<=0&&(a=Number.MAX_VALUE_get()),l>a)return 1*n
if(l<a)return-1*n}else if(this.isClickAuctionPriceSort){if(l=i.AuctionPrice_get()/i.Num_get(),a=s.AuctionPrice_get()/s.Num_get(),l<=0&&(l=Number.MAX_VALUE_get()),
a<=0&&(a=Number.MAX_VALUE_get()),l>a)return 1*n
if(l<a)return-1*n}}else{const t=I.GF.INT(i.StartTime_get()/1e3),e=I.GF.INT(s.StartTime_get()/1e3)
if(t>e)return-1
if(t<e)return 1}return this.CompareItem1(i.ItemData_get().baseData_get(),s.ItemData_get().baseData_get())}CompareItem1(t,e){const i=t,s=e
return null==i&&null==s?0:null!=i&&null==s?-1:null==i&&null!=s?1:this.CompareItem2(i,s)}CompareItem2(t,e){const i=R.l.GetQualitySortValue(t),s=R.l.GetQualitySortValue(e)
let n=!1,l=!1
if(!t.isEquip_get()||t.cfgEquipData_get().equipType!=A.R.ANGELCLOTHES&&t.cfgEquipData_get().equipType!=A.R.ANGELWEAPON||(n=!0),
!e.isEquip_get()||e.cfgEquipData_get().equipType!=A.R.ANGELCLOTHES&&e.cfgEquipData_get().equipType!=A.R.ANGELWEAPON||(l=!0),n&&!l)return-1
if(!n&&l)return 1
if(i!=s)return s-i
if(t.isEquip_get()!=e.isEquip_get())return t.isEquip_get()?-1:1
const a=R.l.GetItemValidTime(t),o=R.l.GetItemValidTime(e)
if(a!=o)return a-o
if(0==t.isEquip_get()){if(t.cfgData_get().sort!=e.cfgData_get().sort)return e.cfgData_get().sort-t.cfgData_get().sort}else{
let i=P.I.GetEquipAttrStarCount(t.serverData_get()),s=P.I.GetEquipAttrStarCount(e.serverData_get())
if(i<0&&(i=0),s<0&&(s=0),i!=s)return s-i
const n=R.l.GetEquipSortValue(t.equipInfo_get().Config_get().intPosition_get()),l=R.l.GetEquipSortValue(e.equipInfo_get().Config_get().intPosition_get())
if(n!=l)return l-n
const a=I.GF.INT(t.cfgData_get().job/100),o=I.GF.INT(e.cfgData_get().job/100)
if(a!=o)return a-o}return 0}IsHasSkill(t){let e=null,i=0,s=0,a=0,o=0
const r=l.Y.Inst.PrimaryRoleInfo_get()
let h=0
if(null!=t&&null!=t.baseData_get()&&null!=t.baseData_get().cfgData_get()&&(e=t.baseData_get(),null!=e.cfgData_get().Rewards_get()&&null!=e.cfgData_get().Rewards_get().typevalues)){
const t=e.cfgData_get().Rewards_get().typevalues
let l=0,d=null,u=null,m=null
for(const[I,_]of(0,n.V5)(t))"Skill"!=_.type&&"ExtraSkill"!=_.type||(d=g.M.Split(_.value,c.o.s_Arr_UNDER_COLON),l=g.M.String2Int(d[0]),s=e.cfgData_get().job/100,
i=e.cfgData_get().id,a=y.g.Inst_get().GetItemIndex(i),o=r.Job_get()/100,0!=s&&o!=s||(m=r.Skills_get(),u=m.LuaDic_GetItem(l),h=null==u?1:2))}return h}ReceiveSearchAuctionGoods(t){
if(null!=t.goods){let e=!0,i=!0
this.AuctionChildViewType==Z.NormalAuction&&0!=t.goods.Count()&&(this.aucStartIndex=t.startIndex,this.aucEndIndex=t.endIndex),1!=t.startIndex?(i=!1,
0==t.goods.Count()&&(e=!1)):this.oneShowDataList=new _.Z
let s=null
for(const[e,i]of(0,n.V5)(t.goods))1!=t.startIndex&&this.isHasShowList(i.goodsId)||(s=this.getOneItemData(i),s.ViewType_set(0),this.oneShowDataList.Add(s))
e&&a.i.Inst.RaiseEvent(L.g.MARKET_ONEITEMCHANGEUPDATE,i)}}isHasShowList(t){let e=!1,i=null,s=0
for(;s<this.oneShowDataList.Count();){if(i=this.oneShowDataList[s],i.Id_get().Equal(t)){e=!0
break}s+=1}return e}getOneItemData(t,e){const i=new z
i.Id_set(t.goodsId),i.AsuramId_set(t.asuramId)
const s=l.Y.Inst.PrimaryRoleInfo_get()
if(null!=t.item){const e=new f.Y
e.serverData_set(t.item),e.baseData_get().isCanOperate=!1,e.baseData_get().isAuctionItem=!0,i.ItemData_set(e),this.SetItemTipPos(e),i.Num_set(t.item.num)}
if(i.AuctionPrice_set(t.nowPrice),i.InitPrice_set(t.initPrice),i.StartTime_set(t.onShelfTime.ToNum()),i.EndTime_set(t.offShelfTime.ToNum()),i.OwnerNum_set(t.ownersNum),
i.OwnerType_set(t.ownerType),i.IsSaleFail_set(t.saleFail),i.HasBidSameGoods_set(e),null!=t.ownersIds){let e=0
for(;e<t.ownersIds.count;){if(t.ownersIds[e].Equal(l.Y.Inst.PrimaryRoleInfo_get().Id_get())){i.IsCanGetIncom_set(!0)
break}e+=1}}
return i.TotalPrice_set(t.buyOutPrice),i.ResId_set(t.resId),0==t.ownerType?null!=t.playerId&&t.playerId.Equal(s.Id_get())?i.Type_set(2):i.Type_set(0):1==t.ownerType&&(s.isHaveAlliance_get()&&s.AsuramId_get().Equal(t.asuramId)?i.Type_set(1):t.saleFail?i.Type_set(3):i.Type_set(4)),
null==t.nowPlayerId||t.nowPlayerId.Equal(u.o.ZERO)?i.State_set(3):0==t.isPartake?i.State_set(2):null!=t.nowPlayerId&&t.nowPlayerId.Equal(s.Id_get())?i.State_set(1):i.State_set(0),i
}SendBagItemGounding(t){null!=t&&null!=t.serverData_get()&&(this.SendOnShelf(t.index_get(),t.serverData_get().num,!1),t.baseData_get().AuctionState_get())}
GoundingItemUseJudge(t,e){null==e&&(e=0),null!=t&&(this.curGetAuctionViewType=e,this.curNeedGoundingItem=t.serverData_get(),F.x.inst.OpenGetAuctionPanel())}ReceiveBid(t){}
ReceiveFollowList(t){if(this.InitProStrList(),this.InitEquipTypeStrList(),this.InitStarStrList(),null!=t.ids){this.attentionIdList=new _.Z
let e=0
for(;e<t.ids.Count();)this.attentionIdList.Add(t.ids[e]),e+=1
this.UpdateAttentionList()}}ReceiveFollow(t){let e=!1,i=-1
if(null!=this.attentionIdList){let s=0
for(;s<this.attentionIdList.Count();){if(this.attentionIdList[s]==t.itemModelId){e=!0,i=s
break}s+=1}t.isFollow?e||this.attentionIdList.Add(t.itemModelId):e&&-1!=i&&this.attentionIdList.RemoveAt(i),this.UpdateAttentionList()}}UpdateAttentionList(){
if(null==this.attentionIdList||null==this.attentionDataList)return
let t=!1
for(const[e,i]of(0,n.V5)(this.attentionDataList)){t=!1
let e=0
for(;e<this.attentionIdList.Count();){if(i.ItemData_get().serverData_get().modelId==this.attentionIdList[e]){t=!0
break}e+=1}i.IsOnShelf_set(t)}for(const[e,i]of(0,n.V5)(this.attentionJewelDataList)){t=!1
let e=0
for(;e<this.attentionIdList.Count();){if(i.ItemData_get().serverData_get().modelId==this.attentionIdList[e]){t=!0
break}e+=1}i.IsOnShelf_set(t)}a.i.Inst.RaiseEvent(L.g.MARKET_ATTENTIONUPDATE)}ReceivePlayerPartakeGoods(t){if(null!=t.goods){this.oneShowSellDataList=new _.Z
let e=null
for(const[i,s]of(0,n.V5)(t.goods))e=this.getOneItemData(s),e.ViewType_set(1),this.oneShowSellDataList.Add(e)
a.i.Inst.RaiseEvent(L.g.MARKET_SELLITEMCHANGEUPDATE,!0)}}ReceivePlayerAuctionGoods(t){if(null!=t.goods){this.groundingDataList.Clear()
for(const[e,i]of(0,n.V5)(t.goods))this.groundingDataList.Add(this.GetGroundingData(i))
this.RaiseGroundingDataUpdate()}}RaiseGroundingDataUpdate(){this.groundingDataList.Sort(this._degf_GroundingDataSortFunc),a.i.Inst.RaiseEvent(L.g.MARKET_GROUNDINGITEMCHANGEUPDATE)}
GetGroundingData(t){const e=new Y.N
e.id=t.goodsId
const i=new f.Y
return i.serverData_set(t.item),i.baseData_get().isEquipCompare=!1,i.baseData_get().isCanOperate=!1,i.baseData_get().tipsPos=new S.P(333,0,0),i.isnew=!1,
i.baseData_get().isAuctionItem=!0,e.itemData=i,e.isGrounding=!0,e.totalPrice=t.butOutPrice,e.auctionPrice=t.nowPrice,e.tipPos=new S.P(333,0,0).Clone(),
null==t.nowPlayerId||t.nowPlayerId.Equal(u.o.ZERO)||(e.isAuction=!0),e.startTime=t.onShelfTime.ToNum(),e.endTime=t.offShelfTime.ToNum(),e.resId=t.resId,e}
GroundingDataSortFunc(t,e){const i=t,s=e
return i.startTime>s.startTime?1:i.startTime<s.startTime?-1:0}ReceiveOffShelf(t){if(null!=t){let e=null,i=-1,s=0
for(;s<this.groundingDataList.Count();){if(e=this.groundingDataList[s],null!=e&&null!=e.id&&e.id.Equal(t)){i=s
break}s+=1}-1!=i&&this.groundingDataList.RemoveAt(i),a.i.Inst.RaiseEvent(L.g.MARKET_GROUNDINGITEMCHANGEUPDATE)}}ReceiveReOnShelf(t){if(null!=t){let e=null,i=0
for(;i<this.groundingDataList.Count();){if(e=this.groundingDataList[i],null!=e&&null!=e.id&&e.id.Equal(t.goodsId)){e.isGrounding=!0,e.totalPrice=t.butOutPrice,
e.auctionPrice=t.nowPrice,null==t.nowPlayerId||t.nowPlayerId.Equal(u.o.ZERO)||(e.isAuction=!0),e.endTime=t.offShelfTime.ToNum(),e.resId=t.resId
break}i+=1}a.i.Inst.RaiseEvent(L.g.MARKET_GROUNDINGITEMCHANGEUPDATE)}}GetTradeItemData(t,e){const i=new q
if(null!=t.item){let e=null
e=new f.Y,e.serverData_set(t.item),e.baseData_get().isCanOperate=!1,e.baseData_get().isAuctionItem=!0,i.ItemData_set(e),this.SetItemTipPos(e),i.Id_set(t.item.id)}
return i.BuyType_set(t.isBuyType),i.GoodsId_set(t.goodsId),i.Type_set(t.recordType),i.TradeTax_set(t.tax),i.SelfIncom_set(t.personalIncome),i.TotalPrice_set(t.price),
i.Time_set(t.time.ToNum()),i.GetRewardType_set(t.rewardState),i.TreeType_set(e),i.RewardPlayerNum_set(t.rewardPlayerNum),i.BuyPlayerName_set(t.buyPlayerName),i}SetItemTipPos(t){
null!=t&&null!=t.baseData_get()&&(t.baseData_get().tipPosType=D.l.Auction)}UpdateCanGetRewardList(){if(this.canGetRewardItemList=new _.Z,
null!=this.tradeDataList)for(const[t,e]of(0,n.V5)(this.tradeDataList))1==e.GetRewardType_get()&&this.canGetRewardItemList.Add(e)
let t=0
for(t=0;t<this.tradeRedPointList.Count();)N.f.Inst.SetState(this.tradeRedPointList[t],!1),t+=1}SetTradeRedPointState(t){if(null!=t){let e=`3${c.o.s_UNDER_CHAR}`
if(0==t.TreeType_get()?e+=`1${c.o.s_UNDER_CHAR+(t.Type_get()+1)}`:1==t.TreeType_get()&&(e+=`2${c.o.s_UNDER_CHAR+t.Type_get()}`),null!=this.redPointDic)for(const[t,i]of(0,
n.vy)(this.redPointDic))t==e&&N.f.Inst.SetState(this.redPointDic[t],!0)}}ReceiveBidBeOvertaken(t){null==this.bidBeList?(this.bidBeList=new _.Z,
this.bidBeList.Add(t)):this.bidBeList[0]=t
o.V.Inst().getStr(10134,s.h.eLangResource)
const e=new V.U(x.K.ICON_TIPS_MARKET_AUCTIONGOUNDING)
if(k.S.Inst_get().AddIcon(e),null!=this.bidBeList){const t=this.bidBeList.Count()
k.S.Inst_get().UpdateCount(x.K.ICON_TIPS_MARKET_AUCTIONGOUNDING,t)}}UpdateBidbeOverTakenDic(t,e,i){null==i&&(i=!0)
let s=!1
for(const[e,i]of(0,n.vy)(this.BidBeOverTakenItemDic))e.Equal(t)&&(s=!0)
s?i?this.BidBeOverTakenItemDic[t]=e:this.BidBeOverTakenItemDic.LuaDic_Remove(t):i&&this.BidBeOverTakenItemDic.LuaDic_AddOrSetItem(t,e),
a.i.Inst.RaiseEvent(L.g.MARKET_BIDBEOVERTAKEN_UPDATE)}BidBeTipHandler(){const t=new U.N
let e=""
const i=new B.t
i.modelId=this.bidBeList[0].itemModelId
const n=new w.M(this.bidBeList[0].itemModelId,i)
null!=n.cfgData_get()&&(e=R.l.GetQualityColorStr(R.l.GetQuality(n),n.cfgData_get().name))
const l=this.bidBeList[0].goldDiamond
this.curBidGoodsId=this.bidBeList[0].index
const a=this.bidBeList[0].isBuyOut
m.B.PopFront(this.bidBeList),0==this.bidBeList.Count()?k.S.Inst_get().RemoveIcon(x.K.ICON_TIPS_MARKET_AUCTIONGOUNDING):k.S.Inst_get().UpdateCount(x.K.ICON_TIPS_MARKET_AUCTIONGOUNDING,this.bidBeList.Count())
const r=new _.Z
r.Add(e),r.Add(`${l}`),a?(t.showText=o.V.Inst().getStr(10878,s.h.eLangResource,r),t.tipstype=1):(t.showText=o.V.Inst().getStr(10135,s.h.eLangResource,r),
t.okText=o.V.Inst().getStr(10043,s.h.eLangResource),t.tipstype=2,t.okhandler=this._degf_BidBeTipOkHandle),H.y.inst.OpenCommonMessageTips(t),
this.SendReadBidBeOverTaken(this.curBidGoodsId)}BidBeTipOkHandle(t){}ReceiveFollowItemOnShelf(t){if(r.D.isrelogin)return
if(this.AttentionItemIsShow(t.item.modelId))return
const e=new f.Y
e.serverData_set(t.item)
const i=new K
i.curItemData=e,i.isAsuram=t.isAsuram,m.B.PushFront(this.attentionGroundingList,i)}AttentionItemIsShow(t){let e=!1,i=0
for(;i<this.attentionGroundingList.Count();){if(this.attentionGroundingList[i].curItemData.baseData_get().modelId_get()==t){e=!0
break}i+=1}return e}GetTradeRecordType(t){let e=-1
return e="0"==t?-1:"1"==t?0:"2"==t?1:2,e}BidBeOvertakenTips(t){if(null!=this.redPointDic){const e="sellId"
this.redPointDic.LuaDic_ContainsKey(e)&&(N.f.Inst.SetState(this.redPointDic[e],t.hasBidBeOvertakenOnShelf),
this.AuctionChildViewType==Z.AuctionBid&&t.hasBidBeOvertakenOnShelf&&this.SendClearBidBeOvertakenTips())}}GetPointIdByKey(t){if(null!=this.redPointDic)for(const[e,i]of(0,
n.vy)(this.redPointDic))if(e==t)return this.redPointDic[e]
return 0}RefreshOnceGoods(t){let e=-1,i=null
if(t.isActive&&null!=t.goodsVo&&F.x.inst.OpenItemAuctionTipView(this.getOneItemData(t.goodsVo,t.hasBidSameGoods)),
this.AuctionChildViewType!=Z.AuctionBid||null==this.oneShowSellDataList){if(null!=this.oneShowDataList){let s=0
for(;s<this.oneShowDataList.Count();){if(i=this.oneShowDataList[s],null!=i&&i.Id_get().Equal(t.id)){e=s
break}s+=1}-1!=e&&(null==t.goodsVo?this.oneShowDataList.RemoveAt(e):this.oneShowDataList[e]=this.getOneItemData(t.goodsVo),this.RemoveNoTimeAuctionItem(this.oneShowDataList),
a.i.Inst.RaiseEvent(L.g.MARKET_ONEITEMCHANGEUPDATE,!1))}}else{let s=0
for(;s<this.oneShowSellDataList.Count();){if(i=this.oneShowSellDataList[s],null!=i&&i.Id_get().Equal(t.id)){e=s
break}s+=1}-1!=e&&(null==t.goodsVo?this.oneShowSellDataList.RemoveAt(e):this.oneShowSellDataList[e]=this.getOneItemData(t.goodsVo),
this.RemoveNoTimeAuctionItem(this.oneShowSellDataList),a.i.Inst.RaiseEvent(L.g.MARKET_SELLITEMCHANGEUPDATE,!1))}}RemoveNoTimeAuctionItem(t){let e=null
const i=new _.Z
let s=0
for(;s<t.Count();)e=t[s],null!=e&&r.D.serverMSTime_get()<e.EndTime_get()&&i.Add(e),s+=1
t=i}IsResetIndexInSearch(t){null==t&&(t=!0),t&&this.ResetAucIndex(),this.SendSearchAuctionGoods()}RemoveTimeEndItem(t){const e=new SM_RefreshOnceGoods
e.id=t,e.isActive=!1,e.goodsVo=null,this.RefreshOnceGoods(e)}SendSearchAuctionGoods(){let t=99,e=0
null!=this.curTreeSendData&&(t=this.curTreeSendData.MarketFirstType_get(),e=this.curTreeSendData.MarketSecondType_get())
const i=new CM_SearchAuctionGoods
i.marketFirstType=t,i.marketSecondType=e,i.startIndex=this.aucStartIndex,i.endIndex=this.aucEndIndex,
2==this.curSortType?this.isAsc?i.sortType=2:i.sortType=1:3==this.curSortType?this.isAsc?i.sortType=4:i.sortType=3:0==this.curSortType&&(this.isAsc?i.sortType=6:i.sortType=5),
i.stepLevel=this.worldAuctionType,i.suitBranch=this.worldAuctionEquipType,d.C.Inst.F_SendMsg(i)}SendSearchAsuramGoods(){let t=99,e=0
null!=this.curTreeSendData&&(t=this.curTreeSendData.MarketFirstType_get(),e=this.curTreeSendData.MarketSecondType_get())
const i=new CM_GetAsuramGoods
i.marketFirstType=t,i.marketSecondType=e,2==this.curSortType?this.isAsc?i.sortType=2:i.sortType=1:3==this.curSortType&&(this.isAsc?i.sortType=4:i.sortType=3),
i.stepLevel=this.asuramAuctionType,i.suitBranch=this.asuramAuctionEquipType,d.C.Inst.F_SendMsg(i)}SendBid(t,e,i){null==i&&(i=0)
const s=new CM_Bid
s.goodsId=this.oneItemData.Id_get(),s.bidType=t,s.bidPrice=i,s.ownerType=e,s.asuramId=this.oneItemData.AsuramId_get(),d.C.Inst.F_SendMsg(s),this.oneItemData=null,
this.auctionOrBuy=0,F.x.inst.CloseItemBuyTipView(),F.x.inst.CloseItemAuctionTipView()}SendFollow(t,e){const i=new CM_Follow
i.itemModelId=t,i.isFollow=e,d.C.Inst.F_SendMsg(i)}SendOnShelf(t,e,i,s,n){null==n&&(n=0),null==s&&(s=0)
const l=new CM_OnShelf
l.index=t,l.num=e,l.onShelfToAsuram=i,d.C.Inst.F_SendMsg(l)}SendPlayerAuctionGoods(){const t=new CM_PlayerAuctionGoods
d.C.Inst.F_SendMsg(t)}SendTransactionRecord(t){}SendReadBidBeOverTaken(t){const e=new CM_ReadBidBeOverTaken
e.index=t,d.C.Inst.F_SendMsg(e)}SendClearBidBeOvertakenTips(){const t=new CM_ClearBidBeOvertakenTips
d.C.Inst.F_SendMsg(t)}SendRefreshOnceGoods(t,e,i){const s=new CM_RefreshOnceGoods
s.goodsId=t,s.ownerType=e,s.asuramId=i,d.C.Inst.F_SendMsg(s)}SendEquipmentFollowSettingUpdate(){const t=new CM_EquipmentFollowSettingUpdate
t.equipmentFollowSetting=this.followSetting,d.C.Inst.F_SendMsg(t)}SendResetEquipmentFollowSetting(){const t=new CM_ResetEquipmentFollowSetting
d.C.Inst.F_SendMsg(t)}IsHasMarketFuncOpen(){let t=!1
return G.P.Inst_get().IsFunctionOpened(O.x.MALL)?(t=!0,this.FirstChildViewType=b.$.Mall):this.FirstChildViewType=b.$.Exchange,t}SendPlayerPartakeGoods(){
const t=new CM_PlayerPartakeGoods
d.C.Inst.F_SendMsg(t)}SendItemAuctionTips(t){const e=new CM_ItemAuctionTips
e.itemModelId=t,d.C.Inst.F_SendMsg(e)}SendOffShelf(t){const e=new CM_OffShelf
e.goodsId=t,d.C.Inst.F_SendMsg(e)}SendReOffShelf(t){}SendAppraisalItem(t){const e=new CM_AppraisalItem
e.index=t,d.C.Inst.F_SendMsg(e)}GetBuyLimit(t){return t.Cfg_get().GetBuyLimit()}}$._inst=null},70202:(t,e,i)=>{i.d(e,{L:()=>f})
var s=i(86133),n=i(98800),l=i(98885),a=i(25777),o=i(93343),r=i(84229),h=i(63076),d=i(3859),c=i(87923),u=i(33138),m=i(72835),I=i(35037),g=i(48481),_=i(56614),p=i(7601),C=i(15771),S=i(8211)
class f{constructor(t){this.mallid=null,this.lastnum=0,this.remainNum=-1,this.lastRemainNum=-1,this._cfg=null,this.needShow=!0,this.canBuy=null,this.mallid=t}IsNew(){
return null!=S.N.GetInst().oldMallGoods&&(!S.N.GetInst().oldMallGoods.Contains(this.mallid)&&0!=this.RemainNum_get())}Lastnum_get(){return this.lastnum}Reset_RemainNum(){
const t=this.lastnum
this.lastnum=0,this.Lastnum_set(t)}Lastnum_set(t){if(this.lastnum=t,this.IsLimitBuy()){const t=this.GetDynamicAddCount()
0!=this.Cfg_get().serverBuyLimit?(this.lastRemainNum=this.remainNum,this.remainNum=t+this.Cfg_get().serverBuyLimit-this.lastnum):-1!=this.Cfg_get().buyLimit&&(this.lastRemainNum=this.remainNum,
this.remainNum=t+this.GetBuyLimit()-this.lastnum),this.remainNum<0&&(this.remainNum=0)}}RemainNum_get(){return this.remainNum}Cfg_get(){
return null==this._cfg&&(this._cfg=I.L.GetInst().GetCfgById(this.mallid)),this._cfg}IsShowRare(){return!1}GetBaseItemData(t=null){const e=new h.M(this.Cfg_get().itemId)
let i=null
null==t&&(t=!1)
const s=u.f.Inst().getItemById(this.Cfg_get().itemId)
if(null!=s)return t&&(e.count=this.Cfg_get().num),s.itemType==d.q.EQUIPMENT?(i=new _.I,i.modelId=this.Cfg_get().itemId):i=new g.t,e.serverData_set(i),e.isForBag=!1,e}IsLimitBuy(){
return-1!=this.Cfg_get().buyLimit}IsLifeLimitBuy(){const t=this.Cfg_get()
return!(-1==this.Cfg_get().buyLimit||null!=t.refreshTime&&""!=t.refreshTime||null!=t.cycleTime&&""!=t.cycleTime)}IsFree(){
return 0==this.Cfg_get().consums.costs.Count()&&0==this.Cfg_get().rechargeId}GetCostByBuyCount(t){const e={},i=this.Cfg_get().buyCountCost
for(let s=0;s<=i.Count()-1;s++){const n=i[s]
if(n[0]<t){if(n[1]>=1e4){e.cost=n[2],e.index=s
break}if(t<=n[1]){e.cost=n[2],e.index=s
break}e.cost=n[2],e.index=s}}return e}GetCurrentCost(){let t=1
return 0!=this.lastnum&&(t+=this.lastnum),this.GetCostByBuyCount(t)}GetPrice(){let t=0
const e=this.GetCurrentCost().cost
return null!=e&&(t=l.M.String2Double(e.subvalue)),t}GetCostType(){let t=""
const e=this.GetCurrentCost().cost
return null!=e&&(t=e.subtype),t}GetDiscount(){const t=this.Cfg_get()
let e=0
if(2==t.hot){const i=this.GetCurrentCost().index
null!=i&&(e=t.discount[i+1])}return e}GetDynamicAddCount(){return 0}GetShowBuyLimit(){const t=this.GetCurrentCost()
if(null==t.index)return this.Cfg_get().GetBuyLimit()+this.GetDynamicAddCount()
const e=t.index,i=this.Cfg_get().consums.costs,s=i[e],n=i[e+1]
let l
if(null!=n)l=n.num
else{l=this.Cfg_get().GetBuyLimit()-s.num}return l+this.GetDynamicAddCount()}GetShowRemainTime(){const t=this.GetCurrentCost()
if(null==t.index)return this.Cfg_get().GetBuyLimit()-this.Lastnum_get()+this.GetDynamicAddCount()
const e=t.index+1,i=this.Cfg_get().consums.costs
let s
if(null!=i[e]){let t=0
for(let s=0;s<=e;s++)null!=i[s]&&(t+=i[s].num)
s=t-this.Lastnum_get()}else{s=this.Cfg_get().GetBuyLimit()-this.Lastnum_get()}return s+this.GetDynamicAddCount()}IsCanBuyWithOtherLimit(){
if(0==this.Cfg_get().vipLimitBuy&&0==this.Cfg_get().transferLevelLimit&&0==this.Cfg_get().LevelMinLimit&&this.IsCanOpendayBuy())return!0
if(!this.IsCanLevelLimitBuy())return!1
if(!this.IsCanVipLimitBuy())return!1
if(!this.IsCanTransferLimitBuy())return!1
return!!this.IsCanOpendayBuy()}IsCanBuyWithOtherAsuramLimit(){return!!this.IsCanBuyWithOtherLimit()&&!!this.IsCanAllianceShopLimitBuy()}IsCanVipLimitBuy(){
return n.Y.Inst.PrimaryRoleInfo_get().VipLevel_get()>=this.Cfg_get().vipLimitBuy}IsCanLevelLimitBuy(){if(0==this.Cfg_get().LevelMinLimit)return!0
const t=n.Y.Inst.PrimaryRoleInfo_get().Level_get()
return t>=this.Cfg_get().LevelMinLimit&&(1==this.Cfg_get().refreshLimit||!(this.Cfg_get().LevelMaxLimit>0&&t>this.Cfg_get().LevelMaxLimit))}IsCanTransferLimitBuy(){
const t=n.Y.Inst.PrimaryRoleInfo_get().Job_get(),e=n.Y.Inst.PrimaryRoleInfo_get().Level_get()
if(this.Cfg_get().transferLevelLimit>0){return m.V.Inst_get().GetJobItemById(t).time>=this.Cfg_get().transferLimit&&e>=this.Cfg_get().transferLevelLimit}return!0}IsCanOpendayBuy(){
if(0==this.Cfg_get().openDayLimit)return!0
if(null==p.W.Inst.openTime)return!1
const t=c.l.GetDayOffBySeconds(p.W.Inst.openTime/1e3)
return this._cfg.openDayLimit-t<=0}IsCanAsuramTitleLimitBuy(){if(this.Cfg_get().titleLimit>0){const t=r.Q.Inst_get().AsuramData_get()
return null!=t&&t.asuramTitleLevel>=this.Cfg_get().titleLimit}return!0}IsCanAllianceShopLimitBuy(){if(this.Cfg_get().guildMallLevelLimit>0){
return a.z.Inst_get().GetLevelByBuildType(o.L.ShopType)>=this.Cfg_get().guildMallLevelLimit}return!0}GetBuyLimit(){return this.Cfg_get().GetBuyLimit()}GetBuyState(){let t=-1
const e=this.IsLimitBuy()
if(0==this.RemainNum_get()&&(t=10),e&&-1!=this._cfg.buyLimit&&0==this.RemainNum_get()){const e=this._cfg.GetUpVip(C.U.inst.model.level_get())
this.canBuy=!1,e>0&&(t=0==this.GetBuyLimit()?0:1)}return 0==this.IsCanBuyWithOtherLimit()&&(this.canBuy=!1,
t=this.IsCanLevelLimitBuy()?this._cfg.vipLimitBuy>0&&0==this._cfg.transferLevelLimit?0:0==this._cfg.vipLimitBuy&&this._cfg.transferLevelLimit>0?2:0:3),t}GetCannotBuyTip(){let t=""
const e=this.Cfg_get()
return this.IsCanOpendayBuy()?(t=this.IsCanLevelLimitBuy()?e.vipLimitBuy>0&&0==e.transferLevelLimit?`VIP${l.M.IntToString(e.vipLimitBuy)+(0,
s.T)("可购买")}`:0==e.vipLimitBuy&&e.transferLevelLimit>0?l.M.IntToString(e.transferLimit)+((0,s.T)("转")+(l.M.IntToString(e.transferLevelLimit)+(0,
s.T)("级可购买"))):l.M.IntToString(e.transferLimit)+((0,s.T)("转")+(l.M.IntToString(e.transferLevelLimit)+((0,s.T)("级或VIP")+(l.M.IntToString(e.vipLimitBuy)+(0,
s.T)("可购买"))))):0==e.LevelMaxLimit||999==e.LevelMaxLimit?`${l.M.IntToString(e.LevelMinLimit)}级${(0,
s.T)("可购买")}`:`${l.M.IntToString(e.LevelMinLimit)}-${l.M.IntToString(e.LevelMaxLimit)}级${(0,s.T)("可购买")}`,t):this.GetOpenTimeStr()}GetOpenTimeStr(){
if(null==this._cfg&&this.Cfg_get(),0==this._cfg.openDayLimit)return null
let t=null
if(null==p.W.Inst.openTime)return t
const e=c.l.GetDayOffBySeconds(p.W.Inst.openTime/1e3),i=this._cfg.openDayLimit-e
return i>0&&(t=c.l.Substitute((0,s.T)("{0}天后可购买"),[i.toString()])),t}}},8211:(t,e,i)=>{i.d(e,{N:()=>E})
var s=i(38836),n=i(86133),l=i(38045),a=i(98800),o=i(97960),r=i(97461),h=i(68662),d=i(16812),c=i(62370),u=i(66788),m=i(5468),I=i(98885),g=i(85602),_=i(38962),p=i(92679),C=i(29839),S=i(37648),f=i(55492),y=i(75439),w=i(33138),D=i(35037),T=i(14792),A=i(62734),v=i(60647),L=i(13487),M=i(19519),b=i(63945),R=i(11162),P=i(33996),G=i(95895),O=i(70202)
class E extends d.k{constructor(){super(!1,0),this.mallDatas=null,this.MallMap=null,this.selectedMallItemData=null,this.mallChildViewType=-1,this.mallViewType=-1,
this.mallChildViewTypeNeedReset=!0,this.defaultSonTable=-1,this.defaultMallId=-1,this.buyNum=0,this.friendShopTabRedIds=null,this.shopType=1,this.m_npcId=0,
this.isMallDataRefreshed=!1,this.curPrice=0,this.curMoney=0,this.curBuyCount=1,this.allianceShopLevelLimit=-1,this.allianceShopTitleLimit=-1,this.curLabelId=-1,
this.currentSelectShopData=null,this.limitTimeGiftRefreshTime=null,this.mallShopConfig=null,this.goldShopConfig=null,this.redPointIdDict=null,this.skillBookCanBuy={},
this.firstload=!1,this.oldMallGoods=null,this.asuramGoodsShopId=null,this.asuramGoodsSubShopId=null,this._degf_LevelUp=null,this._degf_OnReputationUpdate=null,
this._degf_SortFunc=null,this.rareId=null,this.mallDatas=new g.Z,this.MallMap=new _.X,this.friendShopTabRedIds=new _.X,this.limitTimeGiftRefreshTime=new _.X,
this.redPointIdDict=new _.X
const t=y.D.getInstance().getContent("MALL:ASURAM_MATERIALS").getContent().stringVal,e=I.M.Split(t,"_")
this.asuramGoodsShopId=I.M.String2Int(e[1]),this.asuramGoodsSubShopId=I.M.String2Int(e[2]),this._degf_LevelUp=t=>this.LevelUp(t),
this._degf_OnReputationUpdate=t=>this.OnReputationUpdate(t),this._degf_SortFunc=(t,e)=>this.SortFunc(t,e),this.MallMap.LuaDic_AddOrSetItem(0,G.g.WEEK_LIMITED),
this.MallMap.LuaDic_AddOrSetItem(1,G.g.NORMAL_ITEM),this.MallMap.LuaDic_AddOrSetItem(2,G.g.GROWTH),this.MallMap.LuaDic_AddOrSetItem(3,G.g.BINDGOLD),
this.MallMap.LuaDic_AddOrSetItem(4,G.g.SCORE),this.MallMap.LuaDic_AddOrSetItem(5,G.g.HONOUR),a.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(o.A.LevelUpdate,this._degf_LevelUp),
a.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(o.A.ReputationUpdate,this._degf_OnReputationUpdate),this.rareId=y.D.getInstance().GetIntValue("SKILL:ESOTERIC_TAG")}static GetInst(){
return null==E._inst&&(E._inst=new E),E._inst}IsRareItem(t){return this.rareId==t}GetShopType(t){let e=this.GetShopIds(1)
return e.Contains(t)?1:(e=this.GetShopIds(2),e.Contains(t)?2:-1)}GetShopIds(t){
return 1==t?(null==this.mallShopConfig&&(this.mallShopConfig=y.D.getInstance().GetIntArray("MALL_FUNCTIONID")),
this.mallShopConfig):(null==this.goldShopConfig&&(this.goldShopConfig=y.D.getInstance().GetIntArray("GOLDSHOP_FUNCTIONID")),this.goldShopConfig)}GetShopTab(t){
const e=this.GetShopIds(t),i=new g.Z
for(let t=0;t<=e.Count()-1;t++){const s=D.L.GetInst().shopIdToTabs.LuaDic_GetItem(e[t])
s&&this._ShopIsFunctionOpen(e[t],s.functionId)&&i.Add(s)}return i}GetShopSubTab(t){const e=this.GetShopIds(t),i=new _.X
for(let t=0;t<=e.Count()-1;t++){const s=D.L.GetInst().shopIdToSubTabs.LuaDic_GetItem(e[t])
if(null==s||null==s[0])continue
const n=s[0]
if(this._ShopIsFunctionOpen(e[t],n.functionId)){const n=new g.Z
for(let t=0;t<=s.Count()-1;t++)this.CheckShopHasGoodsBuy(s[t].labelId,s[t].subLabelId)&&n.Add(s[t])
n.Count()>0&&(n.Sort(E.SortSubTab),i.LuaDic_SetItem(e[t],n))}}return i}_ShopIsFunctionOpen(t,e){
return!!S.P.Inst_get().IsFunctionOpened(e)&&(9!=t||!!a.Y.Inst.PrimaryRoleInfo_get().isHaveAlliance_get())}CheckShopHasGoodsBuy(t,e){let i=!1
if(t==E.GetInst().asuramGoodsShopId&&e==E.GetInst().asuramGoodsSubShopId&&!a.Y.Inst.PrimaryRoleInfo_get().isHaveAlliance_get())return!1
const s=this.GetListByType(t)
for(let t=0;t<=s.Count()-1;t++){const n=s[t]
if(n.Cfg_get().subLabelId==e){if(!n.IsLifeLimitBuy()){i=!0
break}if(!n.IsLimitBuy()){i=!0
break}if(n.RemainNum_get()>0){i=!0
break}}}return i}GetShopItems(t,e){const i=new g.Z,s=this.GetListByType(t)
let n=0,l=null
for(;n<s.Count();)l=s[n],l.Cfg_get().subLabelId==e&&l.needShow&&i.Add(s[n]),n+=1
return i.Sort(E.SortShowItemsFunc),i}SingNeedShow(){for(const[t,e]of(0,s.V5)(this.mallDatas))0==e.Cfg_get().openDayLimit&&e.IsLifeLimitBuy()&&0==e.RemainNum_get()&&(e.needShow=!1)}
SaveUnShowNew(t,e){const i=new g.Z
for(const[n,l]of(0,s.V5)(this.mallDatas))l.needShow&&l.Cfg_get().labelId==t&&l.Cfg_get().subLabelId==e&&l.IsNew()&&i.Add(l.mallid)
if(i.Count()>0){if(b.x.inst.CM_ClickNewMall(i),null==this.oldMallGoods)this.oldMallGoods=i
else for(let t=0;t<=i.Count()-1;t++)this.oldMallGoods.Contains(i[t])||this.oldMallGoods.Add(i[t])
r.i.Inst.RaiseEvent(p.g.MARKET_OLD_GOODS_UPDATE)}}HasNew(t,e=null,i=null){if(null!=E.GetInst().oldMallGoods)for(const[n,l]of(0,
s.V5)(this.mallDatas))if(l.needShow)if(null!=t&&null!=e&&null!=i){if(l.Cfg_get().functionId==t&&l.Cfg_get().labelId==e&&l.Cfg_get().subLabelId==i&&l.IsNew())return!0
}else if(null!=t){if(l.Cfg_get().functionId==t&&l.IsNew())return!0}else if(null!=e){if(l.Cfg_get().labelId==e&&l.IsNew())return!0}else if(l.IsNew())return!0
return!1}ShopHasNew(t){const e=this.GetShopIds(t)
for(let t=0;t<=e.Count()-1;t++)if(this.HasNew(null,e[t]))return!0
return!1}static SortSubTab(t,e){const i=I.M.Split(t.subLabel,c.o.s_UNDER_CHAR),s=I.M.Split(e.subLabel,c.o.s_UNDER_CHAR)
return(0,l.aI)(i[0])-(0,l.aI)(s[0])}OnReputationUpdate(t){this.UpdateFriendRedPoint()}LevelUp(t){this.UpdateFriendRedPoint()}ResetModel(){this.ResetFriendRedPoint(),
this.firstload=!1,this.oldMallGoods=null}ResetFriendRedPoint(){for(const[t,e]of(0,s.V5)(this.friendShopTabRedIds))A.f.Inst.SetState(e,!1)}GetListByType(t,e=0){null==e&&(e=0)
const i=new g.Z
for(const[l,a]of(0,s.V5)(this.mallDatas)){const s=a.Cfg_get()
if(s.labelId==t||e>0&&s.npcId==e){const t=s.itemId
null!=t&&0!=t||u.Y.LogError((0,n.T)("无此道具ID:")+s.id),S.P.Inst_get().IsFunOpenByItemId(t)?0!=e?s.npcId==e&&i.Add(a):i.Add(a):u.Y.LogError(`mallresource.csv 中配置的物品id 在 itemresource.csv 中不存在。${t}`)
}}return i.Sort(this._degf_SortFunc),i}SortFunc(t,e){return t.Cfg_get().order<e.Cfg_get().order?-1:t.Cfg_get().order>e.Cfg_get().order?1:0}HandleMallList(t){const e=this.mallDatas
this.mallDatas=new g.Z
let i=null,n=!1
for(const[l,a]of(0,s.vy)(t)){i=null
for(let t=0;t<=e.Count()-1;t++)if(e[t].mallid==l){i=e[t]
break}n=!1,null==i&&(i=new O.L(Number(l)),n=!0),null!=i.Cfg_get()&&(i.Lastnum_set(t[l]),this.mallDatas.Add(i),
n&&0==i.Cfg_get().openDayLimit&&i.IsLifeLimitBuy()&&0==i.RemainNum_get()&&(i.needShow=!1))}this.isMallDataRefreshed=!0,this.RaiseEvent(P.G.GET_MALLS,null),
r.i.Inst.RaiseEvent(P.G.GET_MALLS),this.UpdateRedPoint()
const l=v.p.inst.GetClientLogicSetting(L.R.MallNotToDayOpen)
this.firstload&&(h.D.IsIosShenhe()||1==l&&(S.P.Inst_get().IsFunctionOpened(f.x.MALL_LIMIT_TIME_GIFT)||S.P.Inst_get().IsFunctionOpened(f.x.MALL_NEW_GIFT))&&(C.p.inst.IsInCopy()?v.p.inst.SendClientLogicSetting(L.R.MallNotToDayOpen,0):this.CheckShopHasGoodsBuy(5,1)?R.O.Inst_get().Open(null,5,1):this.CheckShopHasGoodsBuy(2,1)?R.O.Inst_get().Open(null,2,1):this.CheckShopHasGoodsBuy(2,2)&&R.O.Inst_get().Open(null,2,2)),
this.firstload=!1)}HandlerGoodRefreshTime(t){for(const[e,i]of(0,s.V5)(t.mallId2RefTime)){const t=D.L.GetInst().GetCfgById(e),s=`${t.labelId}_${t.subLabelId}`
this.limitTimeGiftRefreshTime.LuaDic_AddOrSetItem(s,i)}}GetLimitTimeGiftRefreshTime(t,e){const i=`${t}_${e}`
return this.limitTimeGiftRefreshTime.LuaDic_GetItem(i)}GetLabelRedPoint(t){const e=`MALL_${t.functionId}_${t.labelId}`
let i=this.redPointIdDict.LuaDic_GetItem(e)
if(null==i){i=A.f.Inst.GetID(),this.redPointIdDict.LuaDic_AddOrSetItem(e,i)
const s=new g.Z
this.GetShopIds(2).Contains(t.labelId)?s.Add(T.t.MARKET_GOLD):s.Add(T.t.MALL),A.f.Inst.AddNode(i,s,!1)}return i}GetSubLabelRedPointId(t){
let e=`MALL_${t.functionId}_${t.labelId}_${t.subLabelId}`
t.functionId==f.x.RECHAGE&&(e=T.t.RECHARGE.toString())
let i=this.redPointIdDict.LuaDic_GetItem(e)
const s=this.GetLabelRedPoint(t)
if(null==i){i=A.f.Inst.GetID(),this.redPointIdDict.LuaDic_AddOrSetItem(e,i)
const t=new g.Z
t.Add(s),A.f.Inst.AddNode(i,t,!1)}return i}UpdateRedPoint(){for(const[t,e]of(0,s.V5)(this.redPointIdDict))A.f.Inst.SetState(e,!1)
for(const[t,e]of(0,s.V5)(this.mallDatas)){const t=e.Cfg_get(),i=this.GetSubLabelRedPointId(t)
A.f.Inst.GetData(i).show||A.f.Inst.SetState(i,e.IsFree()&&e.GetShowRemainTime()>0)}}GetInfo(t){for(const[e,i]of(0,s.V5)(this.mallDatas))if(i.mallid==t)return i
return null}GetInfoByItemId(t){for(const[e,i]of(0,s.V5)(this.mallDatas))if(null!=i.Cfg_get()&&i.Cfg_get().itemId==t)return i
return null}GetInfoByRechargeId(t){for(const[e,i]of(0,s.V5)(this.mallDatas))if(null!=i.Cfg_get()&&i.Cfg_get().rechargeId==t)return i
return null}GetInfoListByItemId(t){const e=new g.Z
for(const[i,n]of(0,s.V5)(this.mallDatas))null!=n.Cfg_get()&&n.Cfg_get().itemId==t&&e.Add(n)
return e}HandleBuyMallInfo(t,e){const i=this.GetInfo(t)
i.Lastnum_set(i.Lastnum_get()),this.UpdateRedPoint(),this.RaiseEvent(P.G.BUY_MALLINFO,t)}GetNPCShopName(t){const e=D.L.GetInst().getMap()
for(const[i,n]of(0,s.V5)(e))if(n.npcId==t)return n.npcName
return""}GetShowLeftTabDatas(t){const e=new _.X,i=this.GetListByType(t)
let s=null,n=null,l=0
for(;l<i.Count();)s=i[l].Cfg_get().subLabel,e.LuaDic_ContainsKey(s)||e.LuaDic_AddOrSetItem(s,new g.Z),n=e[s],n.Add(i[l]),l+=1
return e}static SortShowItemsFunc(t,e){let i=0,s=0,n=0
return i=0,s=t.Cfg_get().order,n=e.Cfg_get().order,t.IsLimitBuy()&&0==t.RemainNum_get()&&(s=999),e.IsLimitBuy()&&0==e.RemainNum_get()&&(n=999),
s-n!=0?s-n:t.Cfg_get().order-e.Cfg_get().order}GetMazeVoes(t){const e=new g.Z
for(const[i,n]of(0,s.V5)(this.mallDatas)){n.Cfg_get().mazeevent==t&&e.Add(n)}return e}UpdateFriendRedPoint(){if(this.ResetFriendRedPoint(),
!S.P.Inst_get().IsFunctionOpened(f.x.REPUTATION_SHOP)||0==this.mallDatas.Count())return
const t=this.GetShowLeftTabDatas(G.g.FRIENDSHOP)
let e=null,i=!1,n=0
for(const[l,a]of(0,s.vy)(t)){if(i=!1,e=t[l],null!=e&&0!=e.Count())for(n=0;n<e.Count();){if(this.IsShowPointInFriendTab(e[n])){i=!0
break}n+=1}this.friendShopTabRedIds.LuaDic_ContainsKey(l)&&A.f.Inst.SetState(this.friendShopTabRedIds[l],i)}}IsShowPointInFriendTab(t){let e=!1
if(null!=t&&null!=t.Cfg_get()&&6==t.Cfg_get().labelId&&4==t.Cfg_get().hot&&-1!=t.Cfg_get().buyLimit&&t.RemainNum_get()>0&&t.IsCanBuyWithOtherLimit()){
const i=w.f.Inst().getItemById(t.Cfg_get().itemId),s=a.Y.Inst.PrimaryRoleInfo_get()
null!=i&&null!=s&&i.level<=s.Level_get()&&M.J.IsMoneyEnough(t.Cfg_get().consums.costs[0].subtype,I.M.String2Double(t.Cfg_get().consums.costs[0].subvalue),s)&&(e=!0)}return e}
SkillBookCanBuyReset(){this.skillBookCanBuy={}}SkillBookCanBuySet(t,e){this.skillBookCanBuy[t]=e}SkillBookCanBuyGet(t){return this.skillBookCanBuy[t]}}E._inst=null,E.DIMANDLabel=4,
E.GoldLabel=1,E.HonorLabel=5,E.ALLIANCELabel=9,E.HotTableStr=m.E.s_Empty,E.NewHandTableStr=m.E.s_Empty},33996:(t,e,i)=>{i.d(e,{G:()=>s})
var s={GET_MALLS:"GET_MALLS",BUY_MALLINFO:"BUY_MALLINFO"}},95895:(t,e,i)=>{i.d(e,{g:()=>s})
var s={WEEK_LIMITED:4,NORMAL_ITEM:1,GROWTH:4,BINDGOLD:3,SCORE:2,FRIENDSHOP:6,NPCSHOP:8,ALLIANCESHOP:9,ARENA_GLORY_SHOP1:14,ARENA_GLORY_SHOP2:15,ARENA_GLORY_SHOP3:16,HONOUR:100}},
34258:(t,e,i)=>{i.d(e,{P:()=>$})
var s=i(6847),n=i(83908),l=i(49655),a=i(46282),o=i(40053),r=i(38836),h=i(36334),d=i(44255),c=i(73316),u=i(85682),m=i(5494),I=i(85602),g=i(38962),_=i(79534),p=i(53905),C=i(65772),S=i(63945),f=i(11162),y=i(8211),w=i(97461),D=i(5924),T=i(92679),A=i(28287),v=i(33996),L=i(98885),M=i(15965),b=i(70850),R=i(18152),P=i(98580),G=i(15771),O=i(3231)
class E extends((0,n.pA)(O.A)()){InitView(){super.InitView()}SetData(t){super.SetData(t)
const e=this.data.Cfg_get()
this._baseItemData.showNum=e.num>1,this._baseItemData.IconType_Set(R.s.MARKETMALL_ICON_TYPE)
const i=this._baseItemData.serverData_get()
if(i.num=e.num,null!=e.bind&&1==e.bind[1]&&(i.state=1,this._baseItemData.isShowBind=!0),this.ui_baseitem.SetData(this._baseItemData),
e.labelId==y.N.GetInst().asuramGoodsShopId&&e.subLabelId==y.N.GetInst().asuramGoodsSubShopId){const t=M.V.Inst_Get().GetTodayTaskIdList()
for(let i=0;i<=t.Count()-1;i++)if(t[i].status_get()==P.B.ACCEPTED&&t[i].isHandInTask_get()){const s=t[i].tCTargetDefs_get().tCTargetDefs[0]
if(L.M.String2Int(s.param.itemModelId)==e.itemId){const e=s.value-t[i].qVo.targets[0].value_get()
e>0&&b.g.Inst_get().GetItemNum(L.M.String2Int(s.param.itemModelId))<e&&(this.discountContainer.SetActive(!0),this.discountLabel.node.SetActive(!1),
this.discountContainer.skin="atlas/jbsd/ryjbsd_sp_0012")}}}const s=f.O.Inst_get().openShopData.mallId
null!=this.effect_btn&&(this.effect_btn.SetActive(!1),s==this.data.Cfg_get().id&&(null!=this.buyBtn&&this.buyBtn.active||null!=this.vipbtn&&this.vipbtn.node.active)&&this.effect_btn.SetActive(!0))
}updatePos(){}AddListener(){super.AddListener(),this.m_handlerMgr.AddClickEvent(this.vipbtn,this.gotovip)}gotovip(){G.U.inst.controller.OpenPanel()}Clear(){super.Clear()}Destroy(){
super.Destroy()}}class B extends((0,n.Ri)()){constructor(...t){super(...t),this.selectData=null,this.degf_OnBuySuccess=null,this._degf_GetMallDataHandler=null,
this.scrollInterval=null}_initBinder(){super._initBinder(),this.degf_OnBuySuccess=t=>{this.OnSuccessBuy(t)},this._degf_GetMallDataHandler=t=>{this.OnGetMallData()}}InitView(){
super.InitView(),this.grid.SetInitInfo("ui_marekt_goods_item1_ry",this.CreateDelegate(this.OnCreateItem),E),this.grid.OnReposition_set(this.CreateDelegate(this.OnReposition))}
OnReposition(){this.contentScrollView.ResetPosition()}SetData(){this.selectData=y.N.GetInst().currentSelectShopData,null!=this.selectData&&(this.UpdateAnchors(),
this.UpdateData(!1),this.AddListener(),this.ScrollToTarget())}ScrollToTarget(){null!=this.scrollInterval&&(D.C.Inst_get().ClearInterval(this.scrollInterval),
this.scrollInterval=null)
const t=this.grid.data_get(),e=t.Count()
let i=-1
const s=f.O.Inst_get().openShopData.mallId
if(null!=s&&-1!=s)for(let n=0;n<=e-1;n++)if(t[n].Cfg_get().id==s){i=n
break}if(-1==i)for(let s=0;s<=e-1;s++)if(t[s].IsNew()){i=s
break}this.contentScrollViewBar.scrollTo(i)}ShowCurrencyBar_get(){
return 9==this.selectData.shopId?A._.ShowGold_Dia_Reputation:11==this.selectData.shopId?A._.ShowGold_Dia_Honour:12==this.selectData.shopId?A._.ShowGOLD_GLOD_MARKET:A._.ShowGold_Dia_BindDia
}OnSuccessBuy(t){this.UpdateData(!0)}SortShopItems(t,e){
const i=t.IsCanBuyWithOtherAsuramLimit()&&!(t.IsLimitBuy()&&0==t.RemainNum_get()),s=e.IsCanBuyWithOtherAsuramLimit()&&!(e.IsLimitBuy()&&0==e.RemainNum_get())
if(i&&s)return t.Cfg_get().order-e.Cfg_get().order
if(i&&!s)return-1
if(!i&&s)return 1
let n=!t.IsCanBuyWithOtherLimit(),l=!e.IsCanBuyWithOtherLimit()
return n&&l?t.Cfg_get().order-e.Cfg_get().order:n&&!l?-1:!n&&l?1:(n=!t.IsCanAllianceShopLimitBuy(),l=!e.IsCanAllianceShopLimitBuy(),
n&&l?t.Cfg_get().order-e.Cfg_get().order:n&&!l?-1:!n&&l?1:(n=t.IsLimitBuy()&&0==t.RemainNum_get(),l=e.IsLimitBuy()&&0==e.RemainNum_get(),
n==l?t.Cfg_get().order-e.Cfg_get().order:n&&!l?-1:!n&&l?1:-1))}OnGetMallData(){this.UpdateData(!0)
const t=f.O.Inst_get().openShopData.mallId
null!=t&&-1!=t&&this.ScrollToTarget()}UpdateData(t){if(null==this.selectData)return
t||this.grid.scrollTo(0),y.N.GetInst().SkillBookCanBuyReset()
const e=y.N.GetInst().GetShopItems(this.selectData.shopId,this.selectData.shopSubId)
if(9!=this.selectData.shopId||t||e.Sort(this.SortShopItems),t){const t=this.grid.data_get(),i={}
let s=0
for(const[e,n]of(0,r.V5)(t))i[n.Cfg_get().id]=s,s+=1
const n=(t,e)=>{const s=i[t.Cfg_get().id],n=i[e.Cfg_get().id]
return null!=s&&null!=n?s-n:null!=s?-1:null!=n?1:0}
e.Sort(n)}this.grid.data_set(e)}OnCreateItem(t){}AddListener(){y.N.GetInst().AddEventHandler(v.G.BUY_MALLINFO,this.degf_OnBuySuccess),
y.N.GetInst().AddEventHandler(v.G.GET_MALLS,this._degf_GetMallDataHandler),w.i.Inst.AddEventHandler(T.g.BAG_UPDATE,this.CreateDelegate(this.RefreshItem),50),
w.i.Inst.AddEventHandler(T.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors))}RemoveLister(){y.N.GetInst().RemoveEventHandler(v.G.BUY_MALLINFO,this.degf_OnBuySuccess),
y.N.GetInst().RemoveEventHandler(v.G.GET_MALLS,this._degf_GetMallDataHandler),w.i.Inst.RemoveEventHandler(T.g.BAG_UPDATE,this.CreateDelegate(this.RefreshItem)),
w.i.Inst.RemoveEventHandler(T.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors))}RefreshItem(){this.grid&&this.grid.updateAll()}UpdateAnchors(){}Clear(){this.RemoveLister(),
super.Clear(),null!=this.scrollInterval&&(D.C.Inst_get().ClearInterval(this.scrollInterval),this.scrollInterval=null)}Destroy(){super.Destroy()}}var k=i(3060)
class x extends((0,n.pA)(k.v)()){constructor(...t){super(...t),this.showNew=!1,this.showRedPoint=!1}InitView(){super.InitView(),this.newIcon.SetActive(!1)}SetData(t){
super.SetData(t),this.m_handlerMgr.AddEventMgr(T.g.MARKET_OLD_GOODS_UPDATE,this.CreateDelegate(this.UpdateNew)),this.UpdateNew()}UpdateNew(){
this.itemData&&(this.showNew=y.N.GetInst().HasNew(this.itemData.funId),this.newIcon.SetActive(this.showNew),this.UpdateRedPoint(this.showRedPoint))}UpdateRedPoint(t){
this.showRedPoint=t,this.redPoint.SetActive(t&&!this.showNew)}Clear(){super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}}
var V,N=i(7601),H=i(99294),U=i(9057),F=i(93877),j=i(63076),Y=i(75696),z=i(87923),q=i(68637)
class Z extends U.x{constructor(){super(),this.ui_baseitem=null,this.selectStatusContainer=null,this.expireStatusContainer=null,this.normalStatusContainer=null,
this.selectDayNameLabel=null,this.expireDayNameLabel=null,this.normalDayNameLabel=null,this.buyTip=null,this.redPoint=null,this.cfgData=null,this.clickHandler=null,
this.ServiceGiftDayItem()}ServiceGiftDayItem(){this.ui_baseitem=null,this.selectStatusContainer=null,this.expireStatusContainer=null,this.normalStatusContainer=null,
this.selectDayNameLabel=null,this.expireDayNameLabel=null,this.normalDayNameLabel=null,this.buyTip=null,this.redPoint=null,this.cfgData=null,this.clickHandler=null}InitView(){
super.InitView(),this.ui_baseitem=this.CreateComponentBinder(Y.j,2),this.selectStatusContainer=this.CreateComponent(H.z,3),this.expireStatusContainer=this.CreateComponent(H.z,4),
this.normalStatusContainer=this.CreateComponent(H.z,5),this.selectDayNameLabel=this.CreateComponent(F.Q,6),this.expireDayNameLabel=this.CreateComponent(F.Q,7),
this.normalDayNameLabel=this.CreateComponent(F.Q,8),this.buyTip=this.CreateComponent(F.Q,9),this.redPoint=this.CreateComponent(H.z,10)}SetData(t){this.UnRegGuide()
const e=t.data
this.cfgData=e.Cfg_get()
const i=new j.M(this.cfgData.itemId)
this.ui_baseitem.SetData(i),this.ui_baseitem.EnabledClickOpenTip(!1),this.ui_baseitem.ClickHandler_Set(this.CreateDelegate(this.OnClickItem)),
this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.OnClickItem))
let s=-1
null!=N.W.Inst.openTime&&(s=z.l.GetDayOffBySeconds(N.W.Inst.openTime/1e3)),this.cfgData.openDayLimit==s?this.ShowSelect():this.cfgData.openDayLimit<s?this.ShowExpire():this.ShowNormal(),
this.redPoint.SetActive(this.cfgData.openDayLimit<=s&&!t.hadBuy),this.buyTip.node.SetActive(t.hadBuy),this.RegGuide()}RegGuide(){
null!=this.cfgData&&q.c.Inst.RegGameObject(u.D.UI_MALL_SHOP_DAY_ITEM,this.node,this.cfgData.id)}UnRegGuide(){
null!=this.cfgData&&q.c.Inst.UnRegGameObject(u.D.UI_MALL_SHOP_DAY_ITEM,this.cfgData.id)}CheckGuide(){
null!=this.cfgData&&z.l.CheckBtnClickTrigger(u.D.UI_MALL_SHOP_DAY_ITEM,this.cfgData.id)}ShowExpire(){this.expireDayNameLabel.textSet(`第${this.cfgData.openDayLimit}天`),
this.selectStatusContainer.SetActive(!1),this.expireStatusContainer.SetActive(!0),this.normalStatusContainer.SetActive(!1)}ShowSelect(){
this.selectDayNameLabel.textSet(`第${this.cfgData.openDayLimit}天`),this.selectStatusContainer.SetActive(!0),this.expireStatusContainer.SetActive(!1),
this.normalStatusContainer.SetActive(!1)}ShowNormal(){this.normalDayNameLabel.textSet(`第${this.cfgData.openDayLimit}天`),this.selectStatusContainer.SetActive(!1),
this.expireStatusContainer.SetActive(!1),this.normalStatusContainer.SetActive(!0)}OnClickItem(){this.CheckGuide(),null!=this.clickHandler&&this.clickHandler(this.cfgData)}Clear(){
this.UnRegGuide(),super.Clear()}Destroy(){super.Destroy(),this.ui_baseitem=null,this.selectStatusContainer=null,this.expireStatusContainer=null,this.normalStatusContainer=null,
this.selectDayNameLabel=null,this.expireDayNameLabel=null,this.normalDayNameLabel=null,this.buyTip=null,this.redPoint=null}}class K extends((0,n.Ri)()){constructor(...t){
super(...t),this.itemList=null,this._timerId=-1,this.dayDict=null,this.selectData=null,this.openDayLimit=-1,this._degf_OnClickDayItem=null}_initBinder(){super._initBinder(),
this.ServiceGiftView(),this.itemList=new I.Z,this.dayDict=new g.X,this._degf_OnClickDayItem=t=>{this.OnClickDayItem(t)}}ServiceGiftView(){}InitView(){super.InitView(),
this.dayGrid.SetInitInfo("ui_market_servicetribitem_ry",this.CreateDelegate(this.onCreateServiceItem),Z),
this.grid.SetInitInfo("ui_marekt_goods_item1_ry",this.CreateDelegate(this.OnCreateMarketDataItem),E)}ShowCurrencyBar_get(){return A._.ShowAll}SetData(){
const t=y.N.GetInst().currentSelectShopData
this.itemList=y.N.GetInst().GetShopItems(t.shopId,t.shopSubId)
const e=new I.Z
let i=null
for(let t=0;t<=this.itemList.Count()-1;t++){i=this.itemList[t]
const s=i.Cfg_get()
if(1==s.goodsShow){const t={hadBuy:!1,data:i}
e.Add(t),this.dayDict.LuaDic_AddOrSetItem(s.openDayLimit,t)}}for(let t=0;t<=e.Count()-1;t++)this.UpdateDayBuyStatus(e[t])
e.Sort(K.SortDay),this.dayGrid.data_set(e)
let s=0
if(e.Count()>0){N.W.Inst.openTime
const t=e.Count()-1
s>t&&(s=t),e[s].hadBuy&&null!=e[s+1]&&(s+=1),this.OnClickDayItem(e[s].data.Cfg_get())}let n=40,l=150*e.Count()+n
this.slideNormal.widthSet(l),s+1<e.Count()&&(n=0),l=150*(s+1)+n,this.slideActive.widthSet(l),this.AddListener()}UpdateDayBuyStatus(t){if(t.hadBuy)return
const e=t.data.Cfg_get()
let i=null,s=!0
for(let t=0;t<=this.itemList.Count()-1;t++){i=this.itemList[t]
const n=i.Cfg_get()
if(e.openDayLimit==n.openDayLimit){if(!i.IsLimitBuy()){s=!1
break}if(i.RemainNum_get()>0){s=!1
break}}}t.hadBuy=s}OnSuccessBuy(t){const e=y.N.GetInst().GetInfo(t)
this.UpdateDayBuyStatus(this.dayDict.LuaDic_GetItem(e.Cfg_get().openDayLimit)),this.UpdateData()}UpdateData(){if(-1!=this.openDayLimit){const t=new I.Z
let e=null
for(let i=0;i<=this.itemList.Count()-1;i++){e=this.itemList[i]
e.Cfg_get().openDayLimit==this.openDayLimit&&t.Add(e)}this.grid.data_set(t)}}SetScroll(){}onCreateServiceItem(t){}OnCreateMarketDataItem(t){}OnClickDayItem(t){
this.tipLabel.textSet(`开服第${t.openDayLimit}天开放以下商品购买`),this.openDayLimit=t.openDayLimit,this.UpdateData()}static SortDay(t,e){
return t.data.Cfg_get().openDayLimit-e.data.Cfg_get().openDayLimit}AddListener(){y.N.GetInst().AddEventHandler(v.G.BUY_MALLINFO,this.CreateDelegate(this.OnSuccessBuy))}
RemoveListener(){y.N.GetInst().RemoveEventHandler(v.G.BUY_MALLINFO,this.CreateDelegate(this.OnSuccessBuy))}Clear(){this.RemoveListener(),super.Clear(),
D.C.Inst_get().ClearInterval(this._timerId)}Destroy(){}}
let $=(0,s.s_)(l.o.Market_Gold_Panel_ry,a.Z.ui_market_gold_mainview_ry).tabsPrefab([a.Z.ui_market_servicetrib_view_ry,a.Z.ui_market_gold_shop_list_ry,a.Z.ui_marekt_goods_item1_ry,a.Z.ui_ry_bottom_tab_market,a.Z.ui_ry_right_tab_new].concat(o.Z.BaseItem_ry_basePrefabs)).register()(V=class extends((0,
n.pA)(d.I)()){constructor(...t){super(...t),this.shopCfgIndexDict=null,this.rechargeIndex=0,this.tabCfgList=null,this.subTabCfgDict=null,this.subTabDataNameDict=null,
this.subShopIdDict=null,this.subTabDataRedPointIdDict=null}_initBinder(){super._initBinder(),this.shopCfgIndexDict=new g.X,this.tabCfgList=new I.Z,this.subTabCfgDict=new g.X,
this.subTabDataNameDict=new g.X,this.subShopIdDict=new g.X,this.subTabDataRedPointIdDict=new g.X,
this._subPanelDatas.Add(h.b.New(new I.Z(["ui_market_servicetrib_view_ry"]),this,K)),this._subPanelDatas.Add(h.b.New(new I.Z(["ui_market_gold_shop_list_ry"]),this,B))}InitView(){
super.InitView(),this.m_handlerMgr.AddClickEvent(this.tipBtn.node,this.CreateDelegate(this.OnClickTips))}OnAddToScene(){super.OnAddToScene(),
y.N.GetInst().currentSelectShopData=null,this.UpdateTab()
const t=f.O.Inst_get().openShopData
this.OpenShop(t.openShopId,t.openSubShopId),S.x.inst.ReqShowMall()}UpdateTab(){this.subTabDataRedPointIdDict.Clear(),this.subTabDataNameDict.Clear(),this.shopCfgIndexDict.Clear(),
this.tabCfgList.Clear(),this.subShopIdDict.Clear()
const t=y.N.GetInst().GetShopTab(2)
this.subTabCfgDict=y.N.GetInst().GetShopSubTab(2)
const e=new I.Z,i=new I.Z,s=new I.Z
for(const[t,e]of(0,r.V5)(this.subTabCfgDict)){const i=new I.Z,s=new I.Z,n=new I.Z
for(let t=0;t<=e.Count()-1;t++){const l=e[t]
i.Add(l.subLabelName),s.Add(y.N.GetInst().GetSubLabelRedPointId(l)),n.Add(`${l.functionId}_${l.labelId}_${l.subLabelId}`)}this.subShopIdDict.LuaDic_AddOrSetItem(t,n),
this.subTabDataRedPointIdDict.LuaDic_AddOrSetItem(t,s),this.subTabDataNameDict.LuaDic_AddOrSetItem(t,i)}let n=0
const l=new I.Z
for(let a=0;a<=t.Count()-1;a++){const o=t[a]
this.subTabDataNameDict.LuaDic_ContainsKey(o.labelId)&&(e.Add(o.labelName),this.tabCfgList.Add(o),l.Add(y.N.GetInst().GetLabelRedPoint(o)),s.Add(o.functionId),
this.shopCfgIndexDict.LuaDic_SetItem(o.labelId,n),i.Add(this.GetGuideIds(o.labelId)),n+=1)}this._SetTabData0(!0,e,l,null,null,null,s,null,null,i)}GetGuideIds(t){
return t==y.N.GoldLabel?u.D.UI_MALL_SHOP_GLOD_TAB:t==y.N.HonorLabel?u.D.UI_MALL_SHOP_HONOR_TAB:t==y.N.ALLIANCELabel?u.D.UI_MALL_SHOP_ALLIANCE_TAB:null}SwitchRegUIShow(t){let e=null
t==y.N.GoldLabel?e=u.D.GOLD_MALL:t==y.N.HonorLabel?e=u.D.HONOUR_SHOP:t==y.N.ALLIANCELabel&&(e=u.D.AsuramShop),this.registerUIId=m.I.Market_Gold_Panel_ry,
null!=this.registerUIScId&&e!=this.registerUIScId&&this.UnRegUIShow(!0),this.registerUIScId=e,this.RegUIShow()}OpenShop(t,e){if(-1==t)this.SelectTab0(this.rechargeIndex,!1)
else{const e=this.shopCfgIndexDict.LuaDic_GetItem(t)
null!=e?this.SelectTab0(e,!1):this.SelectTab0(null,!1)}if(null!=t&&null!=e){const i=this.shopCfgIndexDict.LuaDic_GetItem(t)
let s=!1,n=0
const l=this.tabCfgList[i]
if(null!=l){const t=this.subTabCfgDict.LuaDic_GetItem(l.labelId)
for(let i=0;i<=t.Count()-1;i++)if(t[i].subLabelId==e){s=!0,this.SelectTab1(i,!0)
break}}else for(let t=0;t<=this.tabCfgList.count-1;t++)if(null!=this.tabCfgList[t]){n=t
break}s||this.SelectTab1(n,!0)}else this.SelectTab1(null,!0)}ShowCurrencyBar_get(){let t=0
this.selectTabIdx0>0&&(t=1)
const e=this.GetSubView(t)
return e&&e.ShowCurrencyBar_get?e.ShowCurrencyBar_get():super.ShowCurrencyBar_get()}_OnSelectTab0BeforeUpdate(t){const e=this.tabCfgList[this.selectTabIdx0]
let i=null
if(null!=e){const t=this.subTabDataNameDict.LuaDic_GetItem(e.labelId)
e.labelId==y.N.GoldLabel?i=new I.Z([u.D.UI_MALL_SHOP_SEVER_TAB,u.D.UI_MALL_SHOP_GROW_TAB]):e.labelId==y.N.HonorLabel?i=new I.Z([u.D.UI_MALL_SHOP_HON_EX_TAB,u.D.UI_MALL_SHOP_HON_DALIY_TAB]):e.labelId==y.N.ALLIANCELabel&&(i=new I.Z([u.D.UI_MALL_SHOP_AL_DALIY_TAB])),
this.titleLabel.textSet(e.labelName),this._SetTabData1(!0,t,this.subTabDataRedPointIdDict.LuaDic_GetItem(e.labelId),null,this.subShopIdDict.LuaDic_GetItem(e.labelId),i,null),
this.SwitchRegUIShow(null)}else this._SetTabData1(!1,null,null,null,null,null,null)
t&&(f.O.Inst_get().openShopData.mallId=-1)}_OnSelectTab1BeforeUpdate(t){t&&(f.O.Inst_get().openShopData.mallId=-1)}UpdateView(){
const t=this.tabCfgList[this.selectTabIdx0],e=this.subTabCfgDict.LuaDic_GetItem(t.labelId)
let i=e[this.selectTabIdx1]
null==i&&(i=e[0],this.SelectTab1(0,!1)),this.titleLabel.textSet(t.labelName)
const s=y.N.GetInst().currentSelectShopData
null!=s&&y.N.GetInst().SaveUnShowNew(s.shopId,s.shopSubId)
const n={shopId:t.labelId,shopSubId:i.subLabelId}
y.N.GetInst().currentSelectShopData=n,t.labelId==y.N.GoldLabel&&1==i.subLabelId?this.ShowSubView(0):this.ShowSubView(1)}_SetTabData0(t,e,i,s,n,l,a,o,r,h){
this.bottomTabGrid.SetInitInfo("ui_ry_bottom_tab_market",null,x,this.CreateDelegate(this._OnClickBottomItem)),
this.bottomTabGrid.OnReposition_set(this.CreateDelegate(this.OnRepositionBottom)),super._SetTabData0(t,e,i,s,n,l,a,o,r,h)}_SetTabData1(t,e,i,s,n,l,a){
this.rightTabGrid.SetInitInfo("ui_ry_right_tab_new",null,c.b,this.CreateDelegate(this._OnClickRightItem)),
this.rightTabGrid.OnReposition_set(this.CreateDelegate(this.OnRepositionRight)),super._SetTabData1(t,e,i,s,n,l,a)}Clear(){super.Clear()}Destroy(){y.N.GetInst().SingNeedShow()
const t=y.N.GetInst().currentSelectShopData
null!=t&&y.N.GetInst().SaveUnShowNew(t.shopId,t.shopSubId),super.Destroy()}OnClickTips(){let t="GOLDSHOP_TIPS1"
9==this.tabCfgList[this.selectTabIdx0].labelId&&(t="ASURASHOP:TIPS")
const e=new p.w
e.position=new _.P(-470,300,0),e.width=340,e.infoId=t,e.singlelinemode=!0,C.Q.Inst_get().Open(e)}})||V},73904:(t,e,i)=>{
var s=i(6847),n=i(83908),l=i(49655),a=i(46282),o=i(38836),r=i(67885),h=i(74416),d=i(62370),c=i(5924),u=i(36334),m=i(44255),I=i(19755),g=i(85682),_=i(18202),p=i(5494),C=i(60130),S=i(98885),f=i(85602),y=i(38962),w=i(79534),D=i(20099),T=i(28287),A=i(87923),v=i(86209),L=i(48933),M=i(37648),b=i(55492),R=i(35037),P=i(77697),G=i(14792),O=i(62734),E=i(11162),B=i(33996)
class k{constructor(){this.name=null,this.functionId=0,this.redPointId=0,this.guideId=0,this.labelId=0,this.subLabelId=0,this.mallResLis=null,this.clickId=0,this.mallResLis=new f.Z
}}var x=i(8211),V=i(7155),N=i(28192),H=i(88653),U=i(92679),F=i(68637)
class j extends((0,n.yk)()){constructor(...t){super(...t),this.OnClickHandler=null,this.cfgData=null,this.showNew=null,this.guideId=null,this.index=0,this.delegate=null,
this._m_handlerMgr=null}InitView(){this.SetSelect(!1),this.cfgData=null,this.showNew=!1}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=N.h.Get()),
this._m_handlerMgr}SetData(t){this.cfgData=t.subShopData[this.index],this.delegate=t.delegate,this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.OnClick)),
this.m_handlerMgr.AddEventMgr(U.g.MARKET_OLD_GOODS_UPDATE,this.CreateDelegate(this.UpdateNew)),this.nameLabel.textSet(this.cfgData.name),
this.line.node.SetActive(this.index<j.ButtonCount-1),this.UpdateNew(),this.RegGuide()}RegGuide(){const t=this.GetGuideId()
null!=this.guideId&&this.guideId!=t&&this.UnRegGuide(),this.guideId=t,null!=this.guideId&&F.c.Inst.RegGameObject(this.guideId,this.node)}UnRegGuide(){
null!=this.guideId&&(F.c.Inst.UnRegGameObject(this.guideId),this.guideId=null)}CheckGuide(){null!=this.guideId&&A.l.CheckBtnClickTrigger(this.guideId)}GetGuideId(){
if(2==x.N.GetInst().curLabelId){if(0==this.index)return g.D.UI_MALL_LIMIT_TAB
if(1==this.index)return g.D.UI_MALL_GROW_TAB
if(2==this.index)return g.D.UI_MALL_RARE_TAB}return null}SetSelect(t){this.leftSelectBg.node.SetActive(!1),this.rightSelectBg.node.SetActive(!1),
this.normalSelectBg.node.SetActive(!1),t?(null!=j.CurrentSelectItem&&j.CurrentSelectItem.SetSelect(!1),j.CurrentSelectItem=this,
0==this.index?this.leftSelectBg.node.SetActive(!0):this.index==j.ButtonCount-1?this.rightSelectBg.node.SetActive(!0):this.normalSelectBg.node.SetActive(!0),
this.nameLabel.SetColor(new H.I(.3764706,.2784314,.2509804))):this.nameLabel.SetColor(new H.I(.654902,.5921569,.5294118))}UpdateNew(){
this.showNew=x.N.GetInst().HasNew(this.cfgData.functionId,this.cfgData.labelId,this.cfgData.subLabelId),this.newIcon.SetActive(this.showNew),this.updateRedPoint()}updateRedPoint(){
let t=!1
if(null!=this.cfgData){const e=x.N.GetInst().GetSubLabelRedPointId(this.cfgData)
t=O.f.Inst.GetData(e).show}this.redPoint.SetActive(t&&!this.showNew)}OnClick(){j.CurrentSelectItem!=this&&(this.CheckGuide(),this.SetSelect(!0),this.delegate(this.index),
null!=this.OnClickHandler&&this.OnClickHandler(this.index))}Clear(){this.UnRegGuide(),this.SetSelect(!1),j.CurrentSelectItem=null}Destroy(){this.OnClickHandler=null,super.destroy()
}}j.ButtonCount=0,j.CurrentSelectItem=null
var Y=i(50089)
class z extends((0,n.Ri)()){constructor(...t){super(...t),this.selfBottomTabHandler=null,this.selectData=null}InitView(){super.InitView()}SetData(){
this.selectData=x.N.GetInst().currentSelectShopData,null!=this.selectData&&(this.UpdateData(),this.UpdateCurrentBar(null),this.AddListener(),this.UpdateBottomAnchors())}
UpdateData(){if(null==this.selectData)return
const t=x.N.GetInst().GetShopItems(this.selectData.shopId,this.selectData.shopSubId),e=Math.ceil(t.Count()/4),i=new f.Z
let s=0
for(let n=0;n<=e-1;n++){const e={goodsList:new f.Z}
i.Add(e)
for(let i=0;i<=3;i++)null!=t[s]&&(e.goodsList.Add(t[s]),s+=1)}this.grid.data_set(i)}OnSuccessBuy(t){this.UpdateData()}UpdateCurrentBar(t){
9==this.selectData.shopId?v.w.Instance.ResetType(T._.ShowGold_Dia_Reputation):v.w.Instance.ResetType(T._.ShowGold_Dia_BindDia)}AddListener(){
x.N.GetInst().AddEventHandler(B.G.BUY_MALLINFO,this.CreateDelegate(this.OnSuccessBuy))}RemoveListener(){
x.N.GetInst().RemoveEventHandler(B.G.BUY_MALLINFO,this.CreateDelegate(this.OnSuccessBuy))}UpdateBottomAnchors(){const t=Y.t.GetUIWidth()
this.bottombg.widthSet(t),this.bottombg1.widthSet(t),C.O.SetAnchorPos(this.bottomLeft,!0,!1,-1),C.O.SetAnchorPos(this.bottomRight,!1,!0,-1)}Clear(){this.RemoveListener(),
super.Clear()}Destroy(){super.destroy()}}class q extends((0,n.Ri)()){constructor(...t){super(...t),this.selectData=null}InitView(){super.InitView()}SetData(){
this.limitTimePanel.Clear(),this.rechargePanel.Clear(),this.limitTimePanel.node.SetActive(!1),this.rechargePanel.node.SetActive(!1),
this.selectData=x.N.GetInst().currentSelectShopData,2==this.selectData.shopId&&-1==this.selectData.shopSubId?(this.rechargePanel.node.SetActive(!0),
this.rechargePanel.SetData()):(this.limitTimePanel.node.SetActive(!0),this.limitTimePanel.SetData())}GetViewPanelDepth(){this.selectData=x.N.GetInst().currentSelectShopData,
2==this.selectData.shopId&&this.selectData.shopSubId}Clear(){this.limitTimePanel.Clear(),this.rechargePanel.Clear(),super.Clear()}Destroy(){this.limitTimePanel.Destroy(),
this.rechargePanel.Destroy(),super.destroy()}}var Z,K,$=i(93640)
;(0,s.s_)(l.o.MarketPanel_ry,a.Z.ui_market_mainview_ry).tabsPrefab(r.S.modulePathList.concat([a.Z.ui_ry_right_tab3,a.Z.ui_market_limittime_view,a.Z.ui_market_servicetrib_view_ry,a.Z.ui_market_buyicon]),void 0,1).register()(((K=class extends((0,
n.pA)(m.I)()){constructor(...t){super(...t),this.shopIndexDict=null,this.firstTabList=null,this.secondTabDic=null,this.mallListView=null,this.selectBottomTabIndex=-1,
this.selectIndex1=-1,this.selectIndexBottom=-1,this.buyIcon=null,this.selectNewGift=!1,this.closetimerid=null,this.m_npcCharacter=null,this.buyParentItem=null}_initBinder(){
this.shopIndexDict=new y.X,this.firstTabList=new f.Z,this.secondTabDic=new y.X
const t=u.b.New(new f.Z(["ui_market_mall_shop_list_ry"]),this,z)
this._subPanelDatas.Add(t)
const e=u.b.New(new f.Z([a.Z.ui_market_limittime_view]),this,q)
this._subPanelDatas.Add(e),t.initViewHandler=this.CreateDelegate(this.UpdateMallListView),e.initViewHandler=this.CreateDelegate(this.UpdateLimitTimeView)}InitView(){
this.bottomTabGrid1.SetInitInfo("ui_market_mall_tab_item",null,j),this.bottomTabGrid1.OnReposition_set(this.CreateDelegate(this.OnBottomGridPos)),this.AddListener()}onAddToScene(){
this.SelectBottomTab(this.selectBottomTabIndex)}SortFirstTab(t,e){return e-t}GetFirstLabelData(){const t=x.N.GetInst().GetShopIds(1),e=new f.Z
for(let i=0;i<=t.Count()-1;i++){const s=R.L.GetInst().shopIdToTabs.LuaDic_GetItem(t[i]),n=new k
n.functionId=s.functionId,n.labelId=s.labelId,n.name=s.labelName,e.Add(n)}return e}GetSecondLabelData(){const t=x.N.GetInst().GetShopSubTab(1),e=new y.X
for(const[i,s]of(0,o.vy)(t))if(s.Count()>0){null==e[i]&&(e[i]=new f.Z)
for(let t=0;t<=s.Count()-1;t++){const n=new k
n.labelId=i,n.subLabelId=s[t].subLabelId,n.functionId=s[t].functionId,n.name=s[t].subLabelName,e[n.labelId].Add(n)}}if(this.IsRechargeOpen()){const t=2
null==e[t]&&(e[t]=new f.Z)
const i=new k
i.labelId=t,i.subLabelId=-1,i.redPointId=G.t.RECHARGE,i.guideId=g.D.UI_MALL_RECHARGE_TAB,i.functionId=b.x.RECHAGE,i.name="充 值",e[2].Add(i)}return e}IsRechargeOpen(){
return M.P.Inst_get().IsFunctionOpened(b.x.RECHAGE)&&V.o.Inst_get().isFristRecharge}SetViewConfig(){this._SetTabData0(!1),x.N.GetInst().currentSelectShopData=null,
L.I.calVec0.Set(-45,100,0),this.rightTabGrid.node.transform.SetLocalPosition(L.I.calVec0),this.rightBg3.node.SetActive(!1),this.secondTabDic=this.GetSecondLabelData()
const t=this.GetFirstLabelData()
this.firstTabList.Clear(),this.shopIndexDict.Clear()
const e=new f.Z
let i=0
const s=new f.Z,n=new f.Z
for(let l=0;l<=t.Count()-1;l++){const a=t[l],o=a.labelId
this.secondTabDic.LuaDic_ContainsKey(o)&&(e.Add(a.name),this.firstTabList.Add(a),this.shopIndexDict[o]=i,n.Add(x.N.GetInst().GetLabelRedPoint(a)),s.Add(a.functionId),i+=1)}
const l=new f.Z([g.D.UI_MALL_GOLD_TAB])
this._SetTabData1(!0,e,n,s,null,l)
const a=E.O.Inst_get().openShopData
this.OpenShop(a.openShopId,a.openSubShopId),M.P.Inst_get().IsFunctionOpened(b.x.DailyTotalRecharge)?(this.dailyRechargePanel.node.SetActive(!0),
this.dailyRechargePanel.SetData()):(this.SetModelView(),this.dailyRechargePanel.node.SetActive(!1))}ShowCurrencyBar_get(){return T._.ShowGold_Dia_BindDia}OpenShop(t,e){
const i=this.shopIndexDict.LuaDic_GetItem(t)
this.SelectTab1(i,!1)
let s=null
if(null!=t&&null!=e){const t=this.firstTabList[i]
if(null!=t){const i=this.secondTabDic.LuaDic_GetItem(t.labelId)
for(let t=0;t<=i.Count()-1;t++)if(i[t].subLabelId==e){s=t
break}}}if(null==s){const t=this.bottomTabGrid1.data_get()
if(t){const e=t.Count()
for(let i=0;i<=e-1;i++){const e=t[i],n=x.N.GetInst().GetSubLabelRedPointId(e)
if(O.f.Inst.GetData(n).show){s=i
break}}}}null==s&&(s=0),this.SelectBottomTab(s)}_SetTabData1(t,e,i,s,n,l){this.rightTabGrid.SetInitInfo("ui_ry_right_tab3",null,I.N,this.CreateDelegate(this._OnClickRightItem)),
this.rightTabGrid.OnReposition_set(this.CreateDelegate(this.OnRepositionRight)),super._SetTabData1(t,e,i,s,n,l)}_OnSelectTab1BeforeUpdate(t){
if(this.selectIndex1==this.selectTabIdx1)return
x.N.GetInst().curLabelId=-1
const e=this.firstTabList[this.selectTabIdx1]
if(null!=e){x.N.GetInst().curLabelId=e.labelId
const t=this.secondTabDic.LuaDic_GetItem(e.labelId)
let i=new f.Z
for(let e=0;e<t.Count();e++)i.Add({subShopData:t,delegate:this.CreateDelegate(this.SelectBottomTab)})
this.UpdateBottomTab(i)}else this.UpdateBottomTab(new f.Z)
t&&(E.O.Inst_get().openShopData.mallId=-1)}UpdateView(){if(this.isLoadIng)return
if(this.rightBg2.SetActive(!1),this.rightBg3.node.SetActive(!1),this.selectIndex1==this.selectTabIdx1&&this.selectIndexBottom==this.selectBottomTabIndex)return
this.selectIndex1=this.selectTabIdx1,this.selectIndexBottom=this.selectBottomTabIndex,this.bg2.node.SetActive(!1),this.bg3.node.SetActive(!1)
const t=this.firstTabList[this.selectTabIdx1],e=x.N.GetInst().currentSelectShopData
if(null!=e&&x.N.GetInst().SaveUnShowNew(e.shopId,e.shopSubId),null!=t){const e=this.secondTabDic.LuaDic_GetItem(t.labelId)
let i=e[this.selectBottomTabIndex]
null==i&&(i=e[0],this.SelectBottomTab(0)),2==t.labelId&&-1==i.subLabelId?(this.bg3.node.SetActive(!0),this.dailyRechargePanel.SetBg(!0)):(this.dailyRechargePanel.SetBg(!1),
this.bg2.node.SetActive(!0))
const s={shopId:t.labelId,shopSubId:i.subLabelId,functionId:t.functionId}
if(x.N.GetInst().currentSelectShopData=s,300==t.functionId||310==t.functionId||404==t.functionId){let e=0
3==s.shopId?e=310001:(2==s.shopId&&1==s.shopSubId||2==s.shopId&&2==s.shopSubId)&&(e=0),e>0&&0==D.V.ContainLastClicks(1,null,e)&&D.V.SendClickData(e),
this.selectNewGift=310==t.functionId,this.ShowSubView(1),this.UpdateLimitTimeView(),this.UpdateBuyIconPos()}else this.ShowSubView(0),this.UpdateMallListView()}}DelayClose(t){
this.closetimerid=null,E.O.Inst_get().CloseMainView()}SelectBottomTab(t){if(this.selectBottomTabIndex=t,this.bottomTabGrid1.itemList){const t=this.bottomTabGrid1.itemList.Count()
for(let e=0;e<=t-1;e++){const t=this.bottomTabGrid1.itemList[e]
e==this.selectBottomTabIndex?t.SetSelect(!0):t.SetSelect(!1)}}this.UpdateView()}OnSelectBottomTab(t){this.selectBottomTabIndex=t,this.UpdateView(),
E.O.Inst_get().openShopData.mallId=-1}OnBottomGridPos(){this.SelectBottomTab(this.selectBottomTabIndex)}UpdateMallListView(){this.GetSubView(0)}UpdateLimitTimeView(){
this.GetSubView(1)}OnCloseClick(){E.O.Inst_get().CloseMainView()}UpdateBottomTab(t){const e=t.Count()
if(e<2)this.btnBg.node.SetActive(!1)
else{if(this.btnBg.node.SetActive(!0),j.ButtonCount=t.Count(),this.bottomTabGrid1.data_set(t),e>4){const t=237*e+30
this.btnBg.widthSet(t)}else{const t=237*e+30
this.btnBg.widthSet(t)}2==e?this.bottomTabGrid1.node.x=-11:e>=3&&(this.bottomTabGrid1.node.x=-15),this.btnBg.heightSet(75)}}OnCreateBottomTabItem(t){}SetModelView(){
const t=P.f.Inst().getItemById(1000101)
null==this.m_npcCharacter?(this.m_npcCharacter=new h.B,this.m_npcCharacter.isForDialogue=!0,this.m_npcCharacter.dialogAngle=t.dialogAngle,this.m_npcCharacter.InitByCfg(t,!0),
this.npctexture.node.SetActive(!0)):this.m_npcCharacter.SetShow(!0)
const e=w.P.zero_get()
if(!A.l.IsEmptyStr(t.dialogMove)){const i=S.M.Split(t.dialogMove,d.o.s_Arr_UNDER_CHAR_DOT)
e.x+=S.M.String2Float(i[0]),e.y+=S.M.String2Float(i[1])}this.m_npcCharacter.setPosXYZ(e.x,e.y,e.z),this.m_npcCharacter.SetSize(2.5),w.P.Recyle(e)}DestroyNPC(){}AddListener(){
x.N.GetInst().AddEventHandler(B.G.BUY_MALLINFO,this.CreateDelegate(this.OnSuccessBuy))}RemoveListener(){
x.N.GetInst().RemoveEventHandler(B.G.BUY_MALLINFO,this.CreateDelegate(this.OnSuccessBuy))}OnSuccessBuy(t){
300==x.N.GetInst().GetInfo(t).Cfg_get().functionId&&this.bottomTabGrid1.updateItems()}OnRepositionRight(){if(null==this.buyParentItem){const t=this.rightTabGrid.itemList
for(let e=0;e<=t.Count()-1;e++){const i=t[e]
if(310==i.itemData.funId){this.buyParentItem=i,this.buyIcon=_.g.LoadScriptPrefab(a.Z.ui_market_buyicon,$.j,this.CreateDelegate(this.OnLoadBuyIcon),this.buyParentItem.node)
break}}}super.OnRepositionRight()}OnLoadBuyIcon(t){}UpdateBuyIconPos(){null!=this.buyIcon&&(this.selectNewGift?L.I.calVec3.Set(-103,31,0):L.I.calVec3.Set(-70,31,0),
this.buyIcon.node.transform.SetLocalPosition(L.I.calVec3))}UpdateAnchors(){super.UpdateAnchors()
const t=C.O.GetUIWidth()
this.bg3.widthSet(t),this.bg2.heightSet(C.O.GetUIHeight()),this.bg3.heightSet(C.O.GetUIHeight())}Clear(){this.DestroyNPC(),this.RemoveListener(),
null!=this.closetimerid&&(c.C.Inst_get().ClearInterval(this.closetimerid),this.closetimerid=null),v.w.Instance.RemoveDeepth(p.I.MarketPanel_ry),x.N.GetInst().curLabelId=-1,
this.dailyRechargePanel.Clear(),super.Clear()}Destroy(){null!=this.buyIcon&&this.buyIcon.Destroy(),this.dailyRechargePanel.Destroy(),
_.g.Unload(this.CreateDelegate(this.OnLoadBuyIcon)),x.N.GetInst().SingNeedShow()
const t=x.N.GetInst().currentSelectShopData
null!=t&&x.N.GetInst().SaveUnShowNew(t.shopId,t.shopSubId)}}).STAGE_ID=140,Z=K))},90715:(t,e,i)=>{
var s,n=i(18998),l=i(83908),a=i(38836),o=i(98800),r=i(97461),h=i(57834),d=i(51868),c=i(60130),u=i(98130),m=i(98885),I=i(85602),g=i(79534),_=i(29030),p=i(70850),C=i(92679),S=i(93078),f=i(87923),y=i(86209),w=i(33138),D=i(94026),T=i(33828),A=i(43308),v=i(34685),L=i(27158),M=i(65550),b=i(19519),R=i(63945),P=i(11162),G=i(33996),O=i(95895),E=i(8211),B=i(75507),k=i(32076),x=i(5924),V=i(18202),N=i(38962),H=i(48933),U=i(38045),F=i(9057),j=i(21554),Y=i(18152)
class z extends((0,l.pA)(F.x)()){constructor(...t){super(...t),this._itemData=null,this._baseItemData=null,this.state=null}InitView(){super.InitView()}SetData(t){this._itemData=t,
null!=this._itemData&&(this._baseItemData=this._itemData.GetBaseItemData(),this.baseItem.SetIconType(Y.s.BASE_SHAPE_BAG_TYPE),this.baseItem.icon_height=60,
this.baseItem.icon_width=60,this.baseItem.quality_width=60,this.baseItem.quality_height=60,this.baseItem.SetInitHandler(this.CreateDelegate(this.InitItemHandler)),
this.baseItem.ClickHandler_Set(this.CreateDelegate(this.ClickHandler)),this.baseItem.EnabledClickOpenTip(!1),this.baseItem.SetData(this._baseItemData),this.ItemSelectHandle(),
this.UpdateTagIcon(),r.i.Inst.AddEventHandler(C.g.MARKET_MALL_ITEM_SELECT,this.CreateDelegate(this.ItemSelectHandle)))}UpdateTagIcon(){if(2==this._itemData.Cfg_get().hot){
const t=this._itemData.GetDiscount()
t>0?(this.discount.SetActive(!0),this.discountNum.textSet((0,U.tw)(t))):this.discount.SetActive(!1)}else this.discount.SetActive(!1)}ItemSelectHandle(){
null!=E.N.GetInst().selectedMallItemData?this.selectBg.node.SetActive(E.N.GetInst().selectedMallItemData.mallid==this._itemData.mallid):this.selectBg.node.SetActive(!1)}
InitItemHandler(){const[t,e]=this.baseItem.GetRealWH()
this.selectBg.widthSet(t+16),this.selectBg.heightSet(e+16),this.ItemSelectHandle()}ClickHandler(){E.N.GetInst().selectedMallItemData=this._itemData,
r.i.Inst.RaiseEvent(C.g.MARKET_MALL_ITEM_SELECT),R.x.inst.CloseMarketBuyTip()
const t=this._itemData.Cfg_get()
let e=-1
this._itemData.IsCanLevelLimitBuy()?this._itemData.IsCanVipLimitBuy()&&this._itemData.IsCanTransferLimitBuy()||(e=t.vipLimitBuy>0&&0==t.transferLevelLimit?0:0==t.vipLimitBuy&&t.transferLevelLimit>0?3:0):e=(0==t.LevelMaxLimit||t.LevelMaxLimit,
3)
let i=!1
if(this._itemData.IsLimitBuy()?0!=this._itemData.RemainNum_get()&&(i=!0):i=!0,1==this.state)M.y.inst.ClientSysMessage(113007)
else if(3==this.state);else if(0==this.state)M.y.inst.ClientSysMessage(113006)
else{const t=this._itemData.IsCanBuyWithOtherLimit()
!i&&t&&M.y.inst.ClientSysMessage(113008)}-1==e&&(i&&r.i.Inst.AddEventHandler(C.g.TipsLoadCompelete,this.CreateDelegate(this.OpenMarketTip)),
j.J.Inst_get().ShowItemTip(this._baseItemData))}OpenMarketTip(t){R.x.inst.OpenMarketMallBuyTip(this._itemData,R.x.BuyTipPos),
r.i.Inst.RemoveEventHandler(C.g.TipsLoadCompelete,this.CreateDelegate(this.OpenMarketTip))}Clear(){this.baseItem&&this.baseItem.Clear(),
r.i.Inst.RemoveEventHandler(C.g.MARKET_MALL_ITEM_SELECT,this.CreateDelegate(this.ItemSelectHandle)),super.Clear()}Destroy(){this.baseItem&&this.baseItem.Destroy(),super.Destroy()}}
class q{constructor(){this.con_grid=null,this.grid_bg=null,this.bar=null,this.scroll_view=null,this.item_datas=null,this.show_item_dict=null,this.m_handlerMgr=null,this.row_cnt=0,
this.column_cnt=0,this.item_pool=null,this.interval=-1,this.show_item_dict=new N.X,this.item_pool=new I.Z}Init(t,e,i,s,n,l,a){this.m_handlerMgr=t,this.con_grid=e,this.grid_bg=i,
this.bar=s,this.scroll_view=n,this.SetColumnnAndRow(l,a),this.scroll_view.RegistonDragingMoving((0,k.v)(this.Update,this))}SetData(t,e){this.item_datas=t,
1==e?this.OnCallLaterUpdate():this.Update()}SetColumnnAndRow(t,e){this.row_cnt=null==t?q.ROW_CNT:t,this.column_cnt=null==e?q.COLUMN_CNT:e}OnCallLaterUpdate(){
let t=0,e=(this.row_cnt+q.ICON_MAX_CNT)*this.column_cnt,i=0
null!=this.bar&&null!=i||(i=0),i>0&&(t=Math.ceil((this.item_datas.Count()-this.column_cnt*this.row_cnt)*i),e=t+this.column_cnt*this.row_cnt+q.ICON_MAX_CNT*this.column_cnt,
t-=q.ICON_MAX_CNT*this.column_cnt,t<0&&(t=0),e>=this.item_datas.Count()&&(e=this.item_datas.Count()-1))
for(const[t,e]of(0,a.V5)(this.show_item_dict))t>=this.item_datas.Count()&&null!=e&&this.RemoveShowItem(e,t)
for(let i=t;i<=e;i++){const t=this.item_datas[i],e=this.show_item_dict.LuaDic_GetItem(i)
null==t||null==t.GetBaseItemData()||null==t.GetBaseItemData().cfgData_get()?this.RemoveShowItem(e,i):this.AddShowItem(e,i,t)}this.grid_bg.data_set(this.item_datas)}Update(){
this.interval=x.C.Inst_get().SetInterval((0,k.v)(this.OnCallLaterUpdate,this),100,1)}AddShowItem(t,e,i){null==t&&(t=this.GetShowItem()),
null!=t&&null!=t.node&&(this.con_grid.addChild(t.node),this.SetPos(t,e),this.show_item_dict.LuaDic_AddOrSetItem(e,t),null!=i&&t.SetData(i))}RemoveShowItem(t,e){
null!=t&&(t.node.SetActive(!1),this.show_item_dict.LuaDic_Remove(e),t.Clear(),this.item_pool.Add(t))}GetShowItem(){let t=null
if(this.item_pool.Count()>0)t=this.item_pool.Pop(),t.node.SetActive(!0)
else{const e=B.o.getPrefab("ui_market_novice_item")
t=(0,n.instantiate)(e).getCNode(z)}return t}SetPos(t,e){const i=e%this.column_cnt*(q.ITEM_SIZE+q.SPACE),s=-Math.floor(e/this.column_cnt)*(q.ITEM_SIZE+q.SPACE)
H.I.calVec0.Set(i,s,0),t.node.transform.SetLocalPosition(H.I.calVec0)}UpdateSize(){this.grid_bg.heightSet(Math.floor(this.item_datas.Count()/this.column_cnt)*q.ITEM_SIZE)}
Destroy(){-1!=this.interval&&(x.C.Inst_get().ClearInterval(this.interval),this.interval=-1)
for(const[t,e]of(0,a.V5)(this.show_item_dict))null!=e&&this.item_pool.Add(e)
this.show_item_dict.LuaDic_Clear()
for(let t=0;t<=this.item_pool.Count()-1;t++){const e=this.item_pool[t]
e.Clear(),e.Destroy(),V.g.DestroyView(e)}this.item_pool.Clear()}}q.COLUMN_CNT=8,q.ROW_CNT=7,q.SPACE=0,q.ITEM_SIZE=60,q.ICON_SIZE=58,q.ICON_MAX_CNT=4
n._decorator.ccclass("NoviceShopView")(s=class extends((0,l.pA)(d.$)()){constructor(...t){super(...t),this.rInfo=null,this.numPadPos=null,this._model=null,this.shapeGrid=null,
this.itemGrid=null,this._degf_CurrenceyUpdate=null,this.btn_buy=null,this.input=null,this.buyNum=null,this.singlePrice=null,this.label_cost=null,this.numList=null,
this.inputNumCtrl=null,this._degf_DiamondTipOkFun=null,this.label_itemName=null,this.goodsDesc=null,this.sp_diamondtype1=null,this.sp_diamondtype2=null,this.label_own=null,
this._degf_InitGridItem=null}_initBinder(){super._initBinder(),this.numPadPos=new g.P(243,-7,0)}InitView(){this._model=E.N.GetInst(),this.rInfo=o.Y.Inst.PrimaryRoleInfo_get(),
this.grid_bg.SetInitInfo("ui_bag_itembg",null,_.g),this.shapeGrid=new q,this.shapeGrid.Init(this.m_handlerMgr,this.con_grid,this.grid_bg,this.bar,this.scrollView,9,8)}Clear(){
this.RemoveLis(),super.Clear()}Destroy(){this.ClearData(),this.shapeGrid&&this.shapeGrid.Destroy()}SetData(){c.O.SetAnchorPos(this.leftUpWidget,!0,!0,2),
c.O.SetAnchorPos(this.rightUpWidget,!1,!0,2),o.Y.Inst.PrimaryRole_get().ClearMoveParam(),o.Y.Inst.PrimaryRole_get().ChangeToStand(),this._model.selectedMallItemData=null,
this.UpdateShopItem(),this.AddLis()}UpdateShopItem(){let t=new I.Z
const e=E.N.GetInst().GetListByType(O.g.NPCSHOP,this._model.m_npcId)
let i=0
for(;i<e.Count();)t.Add(e[i]),i+=1
this._model.selectedMallItemData=t[0],t=this.GetData(t),this.shapeGrid.SetData(t),this.scrollView.scrollTo(new n.Vec2(0,1))}GetData(t){let e=new I.Z
e=this.GetShowListByClient(t,this.shapeGrid.column_cnt)
let i=e.Count()
for(;i<t.Count();)e.Add(null),i+=1
const s=e.Count()%this.shapeGrid.column_cnt
let n=0
if(e.Count()>=this.shapeGrid.column_cnt*this.shapeGrid.row_cnt?s>0&&(n=this.shapeGrid.column_cnt-s):n=this.shapeGrid.column_cnt*this.shapeGrid.row_cnt-e.Count(),
n>0)for(let t=0;t<=n-1;t++)e.Add(null)
return e}GetShowListByClient(t,e){const i=new I.Z
let s=0
for(let n=0;n<=t.Count()-1;n++){const l=t[n]
if(null!=l){const t=l.GetBaseItemData().cfgData_get().shape
for(s=0;0==p.g.Inst_get().CanPutIn(t,s,i,e);)s+=1
p.g.Inst_get().PutIn(l,t,s,i,e)}}for(let t=0;t<=i.Count()-1;t++)1==i[t]&&(i[t]=null)
return i}ClearData(){E.N.GetInst().m_npcId=0}OnCloseClick(){P.O.Inst_get().CloseNoviceShopView()}AddLis(){
h.i.Get(this.closeBtn.node).RegistonClick(this.CreateDelegate(this.OnCloseClick))}RemoveLis(){h.i.Get(this.closeBtn.node).RemoveonClick(this.CreateDelegate(this.OnCloseClick))}
OnItemRefreshFun(){let t=null
const e=D.e.Inst_get().GetHandInTargetItem(this.itemGrid.itemList)
if(null!=e&&(t=e,t.handIn.SetActive(!0)),null==t&&null!=this.itemGrid.itemList&&0!=this.itemGrid.itemList.Count()){t=this.itemGrid.itemList[0]
const e=this._model.selectedMallItemData
if(null!=e)for(const[i,s]of(0,a.V5)(this.itemGrid.itemList)){const i=s._itemData
if(null!=i&&i.mallid==e.mallid){t=s
break}}}null!=t&&t.ItemClick(0,0),this.RegGuide()}RegGuide(){}UnRegGuide(){}addLis(){
r.i.Inst.AddEventHandler(C.g.MARKET_MALL_ITEM_SELECT,this.CreateDelegate(this.ItemSelectHandle)),this.rInfo.addCurrenceyLis(this._degf_CurrenceyUpdate),
h.i.Get(this.btn_buy.node).RegistonClick(this.CreateDelegate(this.OnBuyClick)),h.i.Get(this.input).RegistonClick(this.CreateDelegate(this.OnInputClick)),
h.i.Get(this.closeBtn).RegistonClick(this.CreateDelegate(this.OnCloseClick)),E.N.GetInst().AddEventHandler(G.G.GET_MALLS,this.CreateDelegate(this.GetMallDataHandler)),
E.N.GetInst().AddEventHandler(G.G.BUY_MALLINFO,this.CreateDelegate(this.UpdateMallInfoHandler))}removeLis(){
if(r.i.Inst.RemoveEventHandler(C.g.MARKET_MALL_ITEM_SELECT,this.CreateDelegate(this.ItemSelectHandle)),this.rInfo.removeCurrencyLis(this._degf_CurrenceyUpdate),
h.i.Get(this.btn_buy.node).RemoveonClick(this.CreateDelegate(this.OnBuyClick)),h.i.Get(this.input).RemoveonClick(this.CreateDelegate(this.OnInputClick)),
h.i.Get(this.closeBtn).RemoveonClick(this.CreateDelegate(this.OnCloseClick)),E.N.GetInst().RemoveEventHandler(G.G.GET_MALLS,this.CreateDelegate(this.GetMallDataHandler)),
E.N.GetInst().RemoveEventHandler(G.G.BUY_MALLINFO,this.CreateDelegate(this.UpdateMallInfoHandler)),null!=this.itemGrid.itemList){let t=0
for(;t<this.itemGrid.itemList.Count();){this.itemGrid.itemList[t].Clear(),t+=1}}}BuyNumChangeHandle(t){this.buyNum=t
const e=this.singlePrice*this.buyNum
e>this.getOwnNumVal()?this.label_cost.textSet(`[DA2222]${y.w.Instance.ConvertNumToString(e)}[-]`):this.label_cost.textSet(`[E2A66A]${y.w.Instance.ConvertNumToString(e)}[-]`)}
UpdateMallInfoHandler(t){const e=u.GF.INT(t),i=this.itemGrid.itemList
for(const[t,s]of(0,a.V5)(i)){const t=s
null!=t._itemData&&t._itemData.mallid==e&&t.UpdateLimitContainer()}}GetMallDataHandler(){this.ItemUpdate()}ItemUpdate(){
const t=E.N.GetInst().GetListByType(O.g.NPCSHOP,this._model.m_npcId),e=new I.Z
let i=0
for(;i<t.Count();)e.Add(t[i]),i+=1
this.itemGrid.data_set(e)}OnInputClick(t,e){this.numList.Clear(),S.F.Instance_get().OpenView(this.numPadPos,this.CreateDelegate(this.InputCallBack))}InputCallBack(t,e){
if(10==t)this.numList.Clear(),this.SetInput(this.numList)
else if(e)this.numList.Clear(),this.numList.Add(t),this.SetInput(this.numList)
else if(3==this.numList.Count()){const t=new I.Z
t.Add(9),t.Add(9),t.Add(9),this.SetInput(t)}else 0==t?this.numList.Count()>0&&(this.numList.Add(t),this.SetInput(this.numList)):(this.numList.Add(t),this.SetInput(this.numList))}
SetInput(t){let e=0,i=0
for(;i<t.Count();)e+=this.GetValue(t[i],t.Count()-i),i+=1
if(e>this.inputNumCtrl.max_get()){let t=this.inputNumCtrl.max_get()
0==t&&(t=1),this.inputNumCtrl.num_set(t)}else 0==e?this.inputNumCtrl.num_set(this.inputNumCtrl.min_get()):this.inputNumCtrl.num_set(e)}GetValue(t,e){let i=0,s=1,n=1
for(;n<e;)s*=10,n+=1
return i=s*t,i}OnBuyClick(t,e){if(null==this._model.selectedMallItemData)return
const i=this.singlePrice*this.buyNum
if(b.J.GOLD_DIAMOND_STR==this._model.selectedMallItemData.Cfg_get().consums.costs[0].subtype){
if(b.J.GetGold(o.Y.Inst.PrimaryRoleInfo_get(),b.J.GOLD_DIAMOND)<i)return void T.Y.Inst_get().OpenTip(this._degf_DiamondTipOkFun)}
if(b.J.GOLD_STR==this._model.selectedMallItemData.Cfg_get().consums.costs[0].subtype){if(o.Y.Inst.PrimaryRoleInfo_get().Gold_get()<i){const t=g.P.zero_get()
return void A._.Inst_get().OpenByCurrency(b.J.GOLD_STR,t)}}
p.g.Inst_get().getBagEmptyGridNum()<1?M.y.inst.ClientSysMessage(101001):R.x.inst.ReqBuyMallItem(this._model.selectedMallItemData.mallid,this.buyNum)}ItemSelectHandle(){
this.numList.Clear()
const t=this._model.selectedMallItemData,e=w.f.Inst().getItemById(t.Cfg_get().itemId),i=new v.B
i.itemCfg=e,i.mallCfg=t.Cfg_get()
const s=L.V.GetItemNameStr(t.Cfg_get())
this.label_itemName.textSet(s)
const n=L.V.GetItemQuality(t.Cfg_get())
this.label_itemName.SetColor(f.l.getColorByQuality(n)),this.goodsDesc.UpdateView(i),h.i.Get(this.input).RegistonClick(this.CreateDelegate(this.OnInputClick)),
this.inputNumCtrl.SetEnabled(!0,!0,!0,!0),this.inputNumCtrl.min_set(1),this.inputNumCtrl.num_set(1),this.updateDiamondType(),this.setOwnNum(),this.SetCost()}updateDiamondType(){
let t=null,e=null
null==this._model.selectedMallItemData?(t=b.J.GetCurrencyIconUrl(b.J.HonourStr),
e=b.J.GetCurrencyStr(b.J.HonourStr)):(t=b.J.GetCurrencyIconUrl(this._model.selectedMallItemData.Cfg_get().consums.costs[0].subtype),
e=b.J.GetCurrencyStr(this._model.selectedMallItemData.Cfg_get().consums.costs[0].subtype)),t!=this.sp_diamondtype1.spriteName()&&this.sp_diamondtype1.spriteNameSet(t),
t!=this.sp_diamondtype2.spriteName()&&this.sp_diamondtype2.spriteNameSet(t)}CurrenceyUpdate(t){this.setOwnNum(),this.SetCost()}setOwnNum(){
null!=this._model.selectedMallItemData?this.label_own.textSet(`${y.w.Instance.ConvertNumToString(this.getOwnNumVal())}`):this.label_own.textSet("0")}SetCost(){
if(1==this._model.shopType)this.SetHonorCost()
else if(null!=this._model.selectedMallItemData){const t=this._model.selectedMallItemData,e=m.M.Replace(t.Cfg_get().consums.costs[0].subvalue,m.M.s_SPAN_CHAR,"")
this.singlePrice=m.M.String2Int(e)
const i=this.getOwnNumVal()
let s=999
i/this.singlePrice==0?s=1:i/this.singlePrice<s&&(s=u.GF.INT(i/this.singlePrice)),this.inputNumCtrl.max_set(s)
const n=this.singlePrice*this.inputNumCtrl.num_get(),l=y.w.Instance.ConvertNumToString(n)
n>i?this.label_cost.textSet(`[DA2222]${l}[-]`):this.label_cost.textSet(`[E2A66A]${l}[-]`)}}getOwnNumVal(){if(null!=this._model.selectedMallItemData){
const t=this._model.selectedMallItemData.Cfg_get().consums.costs[0].subtype
return b.J.GetGold(o.Y.Inst.PrimaryRoleInfo_get(),t)}return 0}SetHonorCost(){}})},65656:(t,e,i)=>{
var s,n=i(18998),l=i(83908),a=i(17409),o=i(49655),r=i(97461),h=i(85682),d=i(31222),c=i(28192),u=i(85602),m=i(75696),I=i(92679),g=i(74657),_=i(6212),p=i(80460),C=i(63945)
n._decorator.ccclass("RyDailyRechargePanel")(s=class extends((0,l.Ri)()){constructor(...t){super(...t),this.info=null,this._m_handlerMgr=null}InitView(){
this.rewardGrid.SetInitInfo("ui_baseitem",this.CreateDelegate(this.OnItemRefreshFun),m.j)}OnItemRefreshFun(t){}SetData(){this.AddLis(),this.UpdateInfo()}Clear(){
this.node.SetActive(!1),this.RemoveLis(),this.rewardGrid.Clear(),super.Clear()}Destroy(){}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=c.h.Get()),
this._m_handlerMgr}AddLis(){r.i.Inst.AddEventHandler(I.g.UPDATE_DAILYACCULUMN_INFO,this.CreateDelegate(this.UpdateInfo)),
r.i.Inst.AddEventHandler(I.g.UPDATE_GET_SUCCESS,this.CreateDelegate(this.UpdateInfo)),this.m_handlerMgr.AddClickEvent(this.goGetBtn.node,this.CreateDelegate(this.GoGetBtnHandle))}
RemoveLis(){r.i.Inst.RemoveEventHandler(I.g.UPDATE_DAILYACCULUMN_INFO,this.CreateDelegate(this.UpdateInfo)),
r.i.Inst.RemoveEventHandler(I.g.UPDATE_GET_SUCCESS,this.CreateDelegate(this.UpdateInfo)),
this.m_handlerMgr.RemoveClickEvent(this.goGetBtn.node,this.CreateDelegate(this.GoGetBtnHandle))}UpdateInfo(){if(this.node.SetActive(!0),this.info=p.r.Inst.dailyRechargeInfo,
null==this.info)return
let t=null,e=!1
const i=p.r.Inst_Get().hasGetRechargeDic
let s=!1,n=new u.Z
if(null!=this.info.allConfigResources){this.info.allConfigResources.Sort(this.CreateDelegate(this.SortFunc))
for(let s=0;s<=this.info.allConfigResources.Count()-1;s++){const n=this.info.allConfigResources[s],l=_.K.Inst().dailyTotalRechargeMap[n]
if(null!=l){if(!(l.currency<=this.info.todayTotalRecharge.ToNum())){t=l
break}i[l.id]||(e=!0)}}}null==t&&(t=_.K.Inst().dailyTotalRechargeMap[this.info.allConfigResources[this.info.allConfigResources.Count()-1]],s=!0)
let l="查看更多"
s?(this.descTxt.textSet("每日累充已满，明天重置"),this.sliderTxt.textSet(`${t.currency}/${t.currency}`),
this.sliVal.widthSet(131.7)):(this.descTxt.textSet(`再充值[288c3c]${t.currency-this.info.todayTotalRecharge.ToNum()}元[-]后可领取`),
this.sliderTxt.textSet(`${this.info.todayTotalRecharge.ToLongStr()}/${t.currency}`),
this.info.todayTotalRecharge.ToNum()/t.currency<=1?this.sliVal.widthSet(this.info.todayTotalRecharge.ToNum()/t.currency*131.7):this.sliVal.widthSet(131.7)),e?l="前往领取":s&&(l="奖励领完")
const a=g.A.GetReward(t.rewardId)
null!=a&&(n=a.GetAllRewardList()),this.canGetEff.SetActive(e),this.goGetBtn.SetText(l),this.rewardGrid.data_set(n)}SetBg(t){this.bg1.SetActive(!t),this.bg2.SetActive(t),
t||this.leftWidget.node.transform.SetLocalPositionXYZ(-640,0,0)}SortFunc(t,e){const i=_.K.Inst().dailyTotalRechargeMap[t],s=_.K.Inst().dailyTotalRechargeMap[e]
return i.currency-s.currency}GoGetBtnHandle(){if((0,a.Di)(o.o.WelfareHallPanel)){let t=(0,a.Y)(o.o.MarketPanel_ry)
t&&(C.x.inst.mainPanel=t,C.x.inst.CloseMainPanel())}else d.N.inst.OpenUIByShortCutID(h.D.DAILY_TOTAL_RECHARGE)}})},99001:(t,e,i)=>{
var s,n=i(6847),l=i(83908),a=i(49655),o=i(46282),r=i(40053),h=i(38836),d=i(86133),c=i(98800),u=i(97461),m=i(70829),I=i(57834),g=i(52726),_=i(98130),p=i(98885),C=i(85602),S=i(88653),f=i(52212),y=i(14772),w=i(84229),D=i(21554),T=i(70850),A=i(3859),v=i(69015),L=i(92679),M=i(74045),b=i(49067),R=i(93078),P=i(87923),G=i(86209),O=i(26195),E=i(33138),B=i(32691),k=i(15821),x=i(78388),V=i(50748),N=i(28893),H=i(64501),U=i(65550),F=i(39043),j=i(19519),Y=i(63945),z=i(8211)
;(0,n.s_)(a.o.eMarketMallBuyTip,o.Z.ui_market_mall_buyTip).waitPrefab(r.Z.BaseItem_ry_basePrefabs).layerTip().inout(null).register()(s=class extends((0,l.Ri)()){constructor(...t){
super(...t),this.data=null,this.curBuyCount=1,this.nextPrice=0,this.currencyType=null,this.curPrice=0,this.curMoney=0,this.normalColor=null,this.disableColor=null,
this._degf_AddHandler=null,this._degf_OnAddButtonClick=null,this._degf_OnBuyButtonClick=null,this._degf_OnCloseHandler=null,this._degf_OnSubButtonClick=null,
this._degf_SelectUseNumHandler=null,this._degf_GotoBuy=null,this._degf_OnSetMaxBuyCountClick=null,this.maxBuyCount=0,this.tipIndex=null}_initBinder(){super._initBinder(),
this.normalColor=new S.I(.8,.796,.768),this.disableColor=new S.I(.8706,.1451,.1412),this._degf_AddHandler=(t,e)=>this.AddHandler(t,e),
this._degf_OnAddButtonClick=(t,e)=>this.OnAddButtonClick(t,e),this._degf_OnBuyButtonClick=(t,e)=>this.OnBuyButtonClick(t,e),this._degf_OnCloseHandler=t=>this.OnCloseHandler(t),
this._degf_OnSubButtonClick=(t,e)=>this.OnSubButtonClick(t,e),this._degf_SelectUseNumHandler=(t,e)=>this.SelectUseNumHandler(t,e),this._degf_GotoBuy=t=>this.GotoBuy(t),
this._degf_OnSetMaxBuyCountClick=()=>{this.OnSetMaxBuyCount()}}InitView(){}OnAddToScene(){this.data=Y.x.inst.m_curSelectedData,this.currencyType=this.data.GetCostType(),
this.curMoney=j.J.GetGold(c.Y.Inst.PrimaryRoleInfo_get(),this.currencyType),this.curCurrencyLabel.textSet(G.w.Instance.DiaCurrencyNumDes(this.currencyType))
const t=j.J.GetCurrencyIconUrl(this.currencyType)
this.currencyUp.spriteNameSet(t),this.currencyDown.spriteNameSet(t),this.data.IsFree()?this.buyBtnLabel.textSet("免 费"):this.buyBtnLabel.textSet("购 买"),this.SetMaxBuyCount(),
this.SetBuyCount(1),this.tipIndex=this.AddToLayout(),this.AddOrRemoveLis(!0)}AddToLayout(){const[t,e]=[325,267],[i,s]=[0,140]
v.g.Inst_get().AddTipByParam(this.node,null,v.g.HorizontalAlign.Right,v.g.VerticalAlign.Down,new f.F(i,s),new f.F(t,e))}SetBuyCount(t){this.countLabel.textSet(p.M.IntToString(t)),
this.curBuyCount=t
let e=0
if(!this.data.IsFree()){let i=this.data.Lastnum_get()
for(let s=0;s<=t-1;s++){i+=1
const t=this.data.GetCostByBuyCount(i)
e+=p.M.String2Double(t.cost.subvalue)}}
this.curPrice=e,this.curPrice<=this.curMoney?this.totalPriceLabel.SetColor(this.normalColor):this.totalPriceLabel.SetColor(this.disableColor),
this.currencyType==j.J.GOLD_STR?this.totalPriceLabel.textSet(G.w.Instance.ConvertNumToString(this.curPrice)):this.totalPriceLabel.textSet(this.curPrice.toString())}
GetSkillBookReCommendCntOfRole(t,e){const i=this.data.Cfg_get()
let s=0
if(e){const n=e.Skills_get()[t]
let l=0
n&&(l=n.originalLevel)
let a=null
if(l>0&&(a=x.r.Inst().GetItemBySkillIdAndLevel(t,1)),!a){const n=m.j.Inst().GetSkillByIdLevel(t,l,!1)
if(l>=n.maxLevel)s=0
else for(let a=l+1;a<=n.maxLevel;a++){const n=m.j.Inst().GetSkillByIdLevel(t,a,!1),l=V.m.Inst().CheckLearnState(n,e)[0]
if(0!=l){if(1!=l)break
{const e=V.m.Inst().GetlearnBeforeSkill(n)
if(m.j.Inst().GetSkillByStrId(e.toString()).skillid!=t)break}}const[o,r]=V.m.Inst().GetSkillItemConsume(n)
o==i.itemId&&(s+=r)}}}return s}GetSkillBookReCommendCnt(){const t=this.data.Cfg_get(),e=E.f.Inst().getItemById(t.itemId).GetRewardsSkillId()
let i=0
if(!(e>0))return
{const s=H.B.inst.GetPlayerInfoListFromSkillByItemId(t.itemId)
for(const[t,n]of(0,h.V5)(s))n&&(i+=this.GetSkillBookReCommendCntOfRole(e,n))}let s=i-T.g.Inst_get().GetItemNum(t.itemId)
return s<1&&(s=1),s}SetMaxBuyCount(){const t=this.data.GetDynamicAddCount()
let e=0
if(!this.data.IsFree()&&this.curMoney>0){const i=this.data.Lastnum_get()
let s=this.curMoney
const n=this.data.Cfg_get(),l=n.buyCountCost,a=n.GetBuyLimit()+t-i,o=this.GetSkillBookReCommendCnt()
let r=1
for(const[i,n]of(0,h.V5)(l)){if(s<=0)break
let i=n[1]
r==l.Count()&&(i+=t)
const a=Math.floor(i-n[0])
if(s<=a*p.M.String2Double(n[2].subvalue)){e=Math.floor(e+s/p.M.String2Double(n[2].subvalue)),s=-1
break}e+=a,s-=a*p.M.String2Double(n[2].subvalue),r+=1}-1!=n.buyLimit&&a<e&&(e=a),o&&e>o&&(e=o)}0==e&&(e=1),e>999&&(e=999),this.maxBuyCount=e}OnSetMaxBuyCount(){
this.SetBuyCount(this.maxBuyCount)}AddOrRemoveLis(t){null==t&&(t=!0),t?(I.i.Get(this.addButton.node).RegistonClick(this._degf_OnAddButtonClick),
I.i.Get(this.leftButton.node).RegistonClick(this._degf_OnSubButtonClick),I.i.Get(this.buyBtn.node).RegistonClick(this._degf_OnBuyButtonClick),
I.i.Get(this.countLabel.node).RegistonClick(this._degf_SelectUseNumHandler),u.i.Inst.AddEventHandler(L.g.BASE_TIP_CLOSE,this._degf_OnCloseHandler),
this.m_handlerMgr.AddClickEvent(this.maxBtn.node,this.CreateDelegate(this.OnSetMaxBuyCount)),
u.i.Inst.AddEventHandler(k.i.NEWBIE_MARKET_TIPS_BUY,this._degf_OnBuyButtonClick)):(I.i.Get(this.addButton.node).RemoveonClick(this._degf_OnAddButtonClick),
I.i.Get(this.leftButton.node).RemoveonClick(this._degf_OnSubButtonClick),I.i.Get(this.buyBtn.node).RemoveonClick(this._degf_OnBuyButtonClick),
I.i.Get(this.countLabel.node).RemoveonClick(this._degf_SelectUseNumHandler),u.i.Inst.RemoveEventHandler(L.g.BASE_TIP_CLOSE,this._degf_OnCloseHandler),
u.i.Inst.RemoveEventHandler(k.i.NEWBIE_MARKET_TIPS_BUY,this._degf_OnBuyButtonClick))}OnCloseHandler(t){Y.x.inst.CloseMarketBuyTip()}SelectUseNumHandler(t,e){
const i=E.f.Inst().getItemById(this.data.Cfg_get().itemId),s=this.addButton.node.getPosition()
s.y-=.3,s.x-=.1,i.sign,R.F.Instance_get().OpenView(null,this._degf_AddHandler,null,s)}AddHandler(t,e){10==t?this.curBuyCount=1:e?this.curBuyCount=t:(this.curBuyCount*=10,
this.curBuyCount+=t),this.curBuyCount<=0&&(this.curBuyCount=1),this.curBuyCount=Math.min(this.curBuyCount,this.maxBuyCount),this.SetBuyCount(this.curBuyCount)}
OnBuyButtonClick(t,e){this.CheckSkillLimitBuy()||this.RealBuy()}RealBuy(){this.CheckCanBuy()&&this.BuyHandle()}SendBuyHandler(t){const e=1==this.data.Cfg_get().labelId
Y.x.inst.ReqBuyMallItem(this.data.mallid,_.GF.INT(t),e)}OnSubButtonClick(t,e){1==this.curBuyCount||(this.curBuyCount-=1,this.SetBuyCount(this.curBuyCount))}OnAddButtonClick(t,e){
-1!=this.maxBuyCount&&this.maxBuyCount<=this.curBuyCount||(this.curBuyCount+=1,this.SetBuyCount(this.curBuyCount))}UnGotoSkillLimitBuy(){this.RealBuy()}GotoSkillLimitBuy(){
N.F.Inst_get().GotoBuy(this.data.Cfg_get().viewSkillLimit)}CheckSkillLimitBuy(){
if(this.data.Cfg_get().viewSkillLimit>-1&&N.F.Inst_get().CheckCanLimitBuy(this.data.Cfg_get().viewSkillLimit)){
const t=N.F.Inst_get().GetItem(this.data.Cfg_get().viewSkillLimit),e=E.f.Inst().getItemById(this.data.Cfg_get().itemId),i=new b.B
return i.infoId="MALL:SKILLBOOK_BUY_CONFIRM4",i.replaceParams.Add(`${t.discount}`),i.replaceParams.Add(P.l.GetItemNameWithQuCollor(null,e,null)),
i.cancelHandle=this.CreateDelegate(this.UnGotoSkillLimitBuy),i.confirmHandle=this.CreateDelegate(this.GotoSkillLimitBuy),i.tipstype=2,i.cancelText="坚持购买",i.confirmText="前往看看",
i.layer=g.F.Tip,i.layer=g.F.Tip,M.t.Inst().Open(i),!0}return!1}CheckCanBuy(){const t=E.f.Inst().getItemById(this.data.Cfg_get().itemId)
return"SKILLBOOK"==t.sign?this.CheckSkillBook(t):11102==this.data.Cfg_get().itemId?this.CheckExpandItem():11104!=this.data.Cfg_get().itemId||this.CheckAsuramRenameItem()}
PopTip(t,e){const i=new b.B
i.infoId=t,i.replaceParams=e,i.cancelText=(0,d.T)("坚持购买"),i.cancelHandle=this._degf_GotoBuy,i.confirmText=(0,d.T)("放弃购买"),this.RecordData(),D.J.Inst_get().CloseTipView(),
M.t.Inst().Open(i)}GotoBuy(t){this.ReadData(),this.BuyHandle()}RecordData(){Y.x.inst.m_curSelectedData=this.data,z.N.GetInst().curBuyCount=this.curBuyCount,
z.N.GetInst().curPrice=this.curPrice,z.N.GetInst().curMoney=this.curMoney}ReadData(){this.data=Y.x.inst.m_curSelectedData,this.curBuyCount=z.N.GetInst().curBuyCount,
this.curPrice=z.N.GetInst().curPrice,this.curMoney=z.N.GetInst().curMoney}BuyHandle(){
if(this.curPrice>this.curMoney)return Y.x.inst.OpenMarketMallAccessView(this.data,this.curPrice),B.C.Inst_get().CloseItemTipView(),Y.x.inst.CloseMarketBuyTip(),
void D.J.Inst_get().CloseTipView()
const t=E.f.Inst().getItemById(this.data.Cfg_get().itemId)
if(null!=t){if(t.itemType==A.q.EQUIPJEWEL||t.itemType==A.q.EQUIPJEWELSMELT||t.itemType==A.q.EQUIPJEWELMATERIAL){
if(O.j.Inst_get().emptySize_get()<1)return void U.y.inst.ClientSysMessage(102521)}else if(T.g.Inst_get().getBagEmptyGridNum()<1)return void U.y.inst.ClientSysMessage(101001)
this.SendBuyHandler(this.curBuyCount),Y.x.inst.CloseMarketBuyTip(),D.J.Inst_get().CloseTipView()}}CheckSkillBook(t){const e=this.data.Cfg_get().itemId
let i=null
const s=t.Rewards_get()
if(0!=s.typevalues.Count()){const t=s.typevalues[0].value,e=p.M.Split(t,":")
if(!P.l.IsEmptyStr(t)&&e.count>=1){const t=`${p.M.String2Int(e[0])}_1`
i=m.j.Inst().GetSkillByStrId(t)}}if(P.l.IsSkillMaxLevel(e)&&null!=i){const t=i.name,e="MALL:SKILLBOOK_BUY_CONFIRM3"
if(!F.V.Inst_get().GetData(F.V.Inst_get().GetRolePrefix()+e)){const i=new C.Z
return i.Add(t),this.PopTip(e,i),!1}}return!0}CheckExpandItem(){
if(T.g.Inst_get().bagSize_get()==T.g.Inst_get().maxBagSize_get()&&T.g.Inst_get().warehouseSize_get()==T.g.Inst_get().maxWarehouseSize_get()){
const t="BAG_AND_WAREHOUSE:UNLOCK_OVERFLOW"
if(!F.V.Inst_get().GetData(F.V.Inst_get().GetRolePrefix()+t)){const e=new C.Z
return this.PopTip(t,e),!1}}return!0}CheckAsuramRenameItem(){if(null==w.Q.Inst_get().AsuramData_get()){const t="RENAME:NOT_IN_ASURAM_NOTICE"
if(!F.V.Inst_get().GetData(F.V.Inst_get().GetRolePrefix()+t)){const e=new C.Z
return this.PopTip(t,e),!1}}const t=c.Y.Inst.PrimaryRoleInfo_get().AllianceJob_get()
if(t!=y.o.Leader&&t!=y.o.ViceLeader){const t="RENAME:ASURAM_JOB_NOTICE"
if(!F.V.Inst_get().GetData(F.V.Inst_get().GetRolePrefix()+t)){const e=new C.Z
return this.PopTip(t,e),!1}}return!0}Clear(){R.F.Instance_get().CloseView(),null!=this.tipIndex&&(v.g.Inst_get().RemoveByTip(),this.tipIndex=null),this.curBuyCount=1,
this.curMoney=0,this.AddOrRemoveLis(!1),this.data=null}Destroy(){}})},27120:(t,e,i)=>{
var s,n=i(18998),l=i(83908),a=i(46282),o=i(38836),r=i(50089),h=i(68662),d=i(5924),c=i(51868),u=i(60130),m=i(85602),I=i(87923),g=i(52053),_=i(60647),p=i(13487),C=i(11162),S=i(33996),f=i(8211),y=i(62370),w=i(18202),D=i(83540),T=i(98885),A=i(75696),v=i(93727),L=i(74657),M=i(3231)
class b extends((0,l.yk)()){_initBinder(){super._initBinder(),this.MarketMallLimitTimeGiftItemBaseEx()}MarketMallLimitTimeGiftItemBaseEx(){}InitView(){}Clear(){}Destroy(){
super.destroy()}SetData(t){t?this.rareObj.SetActive(!0):this.rareObj.SetActive(!1)}S_Test(){return!0}}class R extends((0,l.pA)(M.A)()){constructor(...t){super(...t),this.index=0}
InitView(){super.InitView(),this.rareGrid.SetInitInfo("ui_marekt_limittimetrib_baseitemex",null,b),this.goodGrid.SetInitInfo("ui_baseitem",null,A.j)}SetData(t){super.SetData(t),
null!=this.newIcon&&this.newIcon.SetActive(t.IsNew())
const e=t.Cfg_get()
this._baseItemData.showNum=e.num>1
this._baseItemData.serverData_get().num=e.num,w.g.SetItemIcon(this.itemIcon,this._baseItemData.cfgData_get().icon,D.b.eItem,!0)
const i=L.A.GetReward(e.goods).GetAllRewardList(),s=new m.Z
for(let t=0;t<=i.count-1;t++)s.Add(f.N.GetInst().IsRareItem(i[t].modelId_get()))
this.goodGrid.data_set(i),i.Count()>2?this.goodGrid.node.SetLocalPositionXYZ(0,-183.8,0):this.goodGrid.node.SetLocalPositionXYZ(38,-183.8,0),this.rareGrid.data_set(s)
const n=0==t.GetShowRemainTime()
this.buyOverContainer.SetActive(n),310==e.functionId?n?(this.bgCopyImg.skin="atlas/shangcheng/ryshangcheng_sp_0045",
this.bg1.spriteFrame=this.bg1.spfs[0]):(this.bgCopyImg.skin="atlas/shangcheng/ryshangcheng_sp_0044",
this.bg1.spriteFrame=this.bg1.spfs[1]):1==e.subLabelId?n?(this.bgCopyImg.skin="atlas/shangcheng/ryshangcheng_sp_0035",
this.bg1.spriteFrame=this.bg1.spfs[2]):(this.bgCopyImg.skin="atlas/shangcheng/ryshangcheng_sp_0032",
this.bg1.spriteFrame=this.bg1.spfs[3]):2==e.subLabelId?n?(this.bgCopyImg.skin="atlas/shangcheng/ryshangcheng_sp_0036",
this.bg1.spriteFrame=this.bg1.spfs[4]):(this.bgCopyImg.skin="atlas/shangcheng/ryshangcheng_sp_0033",
this.bg1.spriteFrame=this.bg1.spfs[5]):n?(this.bgCopyImg.skin="atlas/shangcheng/ryshangcheng_sp_0037",
this.bg1.spriteFrame=this.bg1.spfs[6]):(this.bgCopyImg.skin="atlas/shangcheng/ryshangcheng_sp_0034",this.bg1.spriteFrame=this.bg1.spfs[7]),
0!=this.data.Cfg_get().rechargeId?this.btnBg.skin="atlas/common/rycommon_bt_0070":this.btnBg.skin="atlas/common/rycommon_bt_0019",this.ShowDiscount()}OnCreateItem(t){}Clear(){
super.Clear()}Destroy(){super.Destroy()}ShowDiscount(){if(null==this.customDiscountContainer&&null==this.discountContainer)return
const t=this.data.Cfg_get()
if(null!=this.discountContainer&&this.discountContainer.node.SetActive(!1),null!=this.customDiscountContainer&&this.customDiscountContainer.SetActive(!1),
0!=t.hot)if(1==t.hot)this.discountContainer.node.SetActive(!0),this.discountContainer.skin="atlas/jbsd/ryjbsd_sp_0012",this.discountLabel.node.SetActive(!1)
else if(2==t.hot)this.discountContainer.node.SetActive(!0),this.discountContainer.skin="atlas/jbsd/ryjbsd_sp_0027",this.discountLabel.node.SetActive(!0),
this.discountLabel.textSet(`${this.data.GetDiscount()}%`)
else if(4==t.hot)this.discountContainer.node.SetActive(!0),this.discountContainer.skin="atlas/jbsd/ryjbsd_sp_0011",this.discountLabel.node.SetActive(!1)
else if(5==t.hot)this.customDiscountContainer.node.SetActive(!0),this.customDiscountLabel.textSet(t.discount[0]),
this.customDiscountContainer.widthSet(this.customDiscountLabel.textWidth+35)
else if(7==t.hot){this.customDiscountContainer.node.SetActive(!0)
let e=0
if(t.viewCondSpecailDic.LuaDic_ContainsKey("ActivityOpen"))e=.001*v.i.ins.GetLastEndMS(Number(t.viewCondSpecailDic.LuaDic_GetItem("ActivityOpen")))
else{const i=T.M.Split(t.timeControl,y.o.s_Arr_UNDER_LINE),s=h.D.serverTime_get()
e=this.StrChangeToMillisecond(i[1])-s+86400}this.customDiscountLabel.textSet(`剩${I.l.GetDayByTime(e)}`),this.customDiscountContainer.widthSet(this.customDiscountLabel.textWidth+35)
}}}class P extends((0,l.yk)()){constructor(...t){super(...t),this.index=0}InitView(){this.grid.SetInitInfo("ui_marekt_limittimetrib_item",null,R)}SetData(t){
this.grid.data_set(t.goodsList)
let e=330
0==this.index&&(e=364),this.bg&&(this.bg.getComponent(n.UITransform).height=e)}Clear(){}Destroy(){super.destroy()}Test1(){return!0}S_Test(){return!0}}
n._decorator.ccclass("MallLimitTimeGoodsView")(s=class extends((0,l.pA)(c.$)()){constructor(...t){super(...t),this.timeId=-1,this.remainTime=0,this.selectData=null,
this.scrollInterval=null}InitView(){super.InitView(),this.grid.SetInitInfo(a.Z.ui_marekt_limitgitf_bookself_ry,null,P),this.bottombg.widthSet(u.O.GetUIWidth())}IsShowSkillNotice(){
return!0}SetData(){_.p.inst.SendClientLogicSetting(p.R.MallNotToDayOpen,0),this.selectData=f.N.GetInst().currentSelectShopData,this.RemoveListener(),this.AddListener(),
this.UpdateData(),this.UpdateBottomAnchors(),this.dayNotice.SetActive(!1),this.weekNotice.SetActive(!1),this.monthNotice.SetActive(!1),this.newNotice.SetActive(!1),
this.skillNotice.SetActive(!1),404!=this.selectData.functionId?(this.bottomLeftSprite.SetActive(!0),310==this.selectData.functionId?(this.newNotice.SetActive(!0),
this.timeTip.textSet("结束时间")):(this.timeTip.textSet("刷新时间"),1==this.selectData.shopSubId?this.IsShowSkillNotice()?(this.skillNotice.SetActive(!0),
this.bottomLeftSprite.SetActive(!1)):this.dayNotice.SetActive(!0):2==this.selectData.shopSubId?this.weekNotice.SetActive(!0):this.monthNotice.SetActive(!0)),this.ClearTime(),
this.remainTime=.001*f.N.GetInst().GetLimitTimeGiftRefreshTime(this.selectData.shopId,this.selectData.shopSubId).ToNum()-h.D.serverTime_get(),this.SetShowTime(this.remainTime),
this.remainTime>0&&(this.timeId=d.C.Inst_get().SetInterval(this.CreateDelegate(this.OnLoopTime),1e3)),this.ScrollToTarget()):this.bottomLeftSprite.SetActive(!1)}ScrollToTarget(){
null!=this.scrollInterval&&(d.C.Inst_get().ClearInterval(this.scrollInterval),this.scrollInterval=null)
const t=this.grid.data_get(),e=t.Count()
let i=-1
const s=C.O.Inst_get().openShopData.mallId
if(null!=s&&-1!=s)for(let n=0;n<=e-1;n++){const e=t[n].goodsList
for(let t=0;t<=e.Count()-1;t++)if(e[t].Cfg_get().id==s){i=n
break}if(-1!=i)break}if(-1==i)for(let s=0;s<=e-1;s++){const e=t[s].goodsList
for(let t=0;t<=e.Count()-1;t++)if(e[t].IsNew()){i=s
break}}}UpdateData(t){const e=f.N.GetInst().GetShopItems(this.selectData.shopId,this.selectData.shopSubId),i=Math.ceil(e.Count()/3),s=new m.Z
if(t){const t=this.grid.data_get(),i={}
let s=0
if(t)for(const[e,n]of(0,o.V5)(t))for(const[t,e]of(0,o.V5)(n.goodsList))i[e.Cfg_get().id]=s,s+=1
const n=(t,e)=>{const s=i[t.Cfg_get().id],n=i[e.Cfg_get().id]
return null!=s&&null!=n?s-n:s?-1:n?1:0}
e.Sort(n)}let l=0
for(let t=0;t<=i-1;t++){const t={goodsList:new m.Z}
s.Add(t)
for(let i=0;i<=2;i++)null!=e[l]&&(t.goodsList.Add(e[l]),l+=1)}this.grid.data_set(s),s.length>0&&(this.content.height=341*s.length),this.content.SetLocalPosition(new n.Vec3(0,0,0))}
funcName(){}OnLoopTime(){this.remainTime-=1,this.remainTime<=0&&this.ClearTime(),this.SetShowTime(this.remainTime)}ClearTime(){d.C.Inst_get().ClearInterval(this.timeId),
this.timeId=-1}SetShowTime(t){this.timeLabel.textSet(I.l.GetDateFormatEX(t,!0,!0))}OnSuccessBuy(t){this.UpdateData(!0)}AddListener(){
f.N.GetInst().AddEventHandler(S.G.BUY_MALLINFO,this.CreateDelegate(this.OnSuccessBuy)),this.m_handlerMgr.AddClickEvent(this.skillNotice,this.CreateDelegate(this.SkillOpenHandler))}
RemoveListener(){f.N.GetInst().RemoveEventHandler(S.G.BUY_MALLINFO,this.CreateDelegate(this.OnSuccessBuy))}SkillOpenHandler(){g.d.Inst_get().ShowAoYiSkill()}UpdateBottomAnchors(){
const t=r.t.GetUIWidth()
this.bottombg.widthSet(t),this.bottombg1.widthSet(t),u.O.SetAnchorPos(this.bottomRight,!1,!1,-2)}Clear(){super.Clear(),this.ClearTime(),this.RemoveListener(),
null!=this.scrollInterval&&(d.C.Inst_get().ClearInterval(this.scrollInterval),this.scrollInterval=null)}Destroy(){super.destroy()}})},3231:(t,e,i)=>{i.d(e,{A:()=>z})
var s=i(32076),n=i(38836),l=i(86133),a=i(38045),o=i(97461),r=i(68662),h=i(62370),d=i(70829),c=i(9057),u=i(85682),m=i(31222),I=i(98885),g=i(85602),_=i(21554),p=i(70850),C=i(20099),S=i(92679),f=i(74045),y=i(49067),w=i(87923),D=i(86209),T=i(68637),A=i(93727),v=i(76887),L=i(7601),M=i(15821),b=i(41864),R=i(78388),P=i(52053),G=i(72268),O=i(50748),E=i(64501),B=i(65550),k=i(19519),x=i(84141),V=i(15771),N=i(63945),H=i(11162),U=i(8211),F=i(52513),j=i(31896),Y=i(66788)
class z extends c.x{constructor(...t){super(...t),this.data=null,this.canBuy=!1,this._baseItemData=null,this.state=-1,this.guideId=null,this.needUpLv=0,
this.shouldUpgradeSkillIdAndRoleIdx=null,this.lockTipBg=null,this.cfgRes=null}InitView(){super.InitView()}SetData(t){this.UnRegGuide(),this.data=t,this.RegGuide(),
this.AddListener()
const e=this.data.GetBaseItemData()
this._baseItemData=e,this.nameLabel.textSet(e.cfgData_get().name),this.ShowCost(),this.ShowBuyState(),this.ShowDiscount(),null!=this.newIcon&&this.newIcon.SetActive(t.IsNew())
const i=H.O.Inst_get().openShopData.mallId
null!=this.effect_btn&&(this.effect_btn.SetActive(!1),i==this.data.Cfg_get().id&&(null!=this.buyBtn&&this.buyBtn.active||null!=this.vipbtn&&this.vipbtn.node.active)&&this.effect_btn.SetActive(!0))
}RegGuide(){this.GetGuideId(),null!=this.data&&null!=this.guideId&&T.c.Inst.RegGameObject(this.guideId,this.bgBtn.node,this.data.Cfg_get().id)}GetGuideId(){this.guideId=null,
null!=this.data&&(this.data.Cfg_get().labelId==U.N.GoldLabel?(1==this.data.Cfg_get().sonTableIndex||2==this.data.Cfg_get().sonTableIndex)&&(this.guideId=u.D.UI_MALL_SHOP_D_BUY_BTN):this.data.Cfg_get().labelId==U.N.DIMANDLabel?this.guideId=u.D.UI_MALL_BUY_BTN:this.data.Cfg_get().labelId==U.N.HonorLabel?1==this.data.Cfg_get().sonTableIndex?this.guideId=u.D.UI_MALL_SHOP_HON_E_BUY_BTN:2==this.data.Cfg_get().sonTableIndex&&(this.guideId=u.D.UI_MALL_SHOP_HON_D_BUY_BTN):this.data.Cfg_get().labelId==U.N.ALLIANCELabel&&(this.guideId=u.D.UI_MALL_SHOP_AL_BUY_BTN))
}UnRegGuide(){null!=this.data&&null!=this.guideId&&T.c.Inst.UnRegGameObject(this.guideId,this.data.Cfg_get().id,!0)}CheckGuide(){
null!=this.data&&null!=this.guideId&&w.l.CheckBtnClickTrigger(this.guideId,this.data.Cfg_get().id)}AddListener(){
null!=this.itemIcon&&this.m_handlerMgr.AddClickEvent(this.itemIcon.node,this.CreateDelegate(this.OpenTipView)),this.AddOpenEvent()}RemoveOpenEvent(){
this.m_handlerMgr.RemoveClickEvent(this.bgBtn.node,this.CreateDelegate(this.OnBuyBtnClick)),o.i.Inst.RemoveEventHandler(M.i.NEWBIE_MARKET_BUY_BTN,(0,s.v)(this.onExecNewbie,this))}
AddOpenEvent(){this.m_handlerMgr.AddClickEvent(this.bgBtn.node,this.CreateDelegate(this.OnBuyBtnClick)),o.i.Inst.AddEventHandler(M.i.NEWBIE_MARKET_BUY_BTN,(0,
s.v)(this.onExecNewbie,this))}onExecNewbie(t){
this.data&&(t[0]&&t[0]==this.data.mallid.toString()||t[1]&&t[1]==this.data.mallid.toString()||t[2]&&t[2]==this.data.mallid.toString())&&this.OnBuyBtnClick()}ShowCost(){
if(4320==this.data.mallid&&Y.Y.Log(""),
this.RemoveOpenEvent(),!this.data.IsCanBuyWithOtherAsuramLimit()||this.data.IsLimitBuy()&&0==this.data.RemainNum_get())this.buyBtn.SetActive(!1)
else{if(this.AddOpenEvent(),this.buyBtn.SetActive(!0),null!=this.freeLabel&&this.freeLabel.SetActive(!1),this.costLabel.node.SetActive(!0),this.costIcon.node.SetActive(!0),
this.data.IsFree())null!=this.freeLabel?(this.freeLabel.SetActive(!0),this.costLabel.node.SetActive(!1),this.costIcon.node.SetActive(!1)):(this.costIcon.node.SetActive(!1),
this.costLabel.textSet("免 费"))
else if(0!=this.data.Cfg_get().rechargeId){const t=F.O.Inst().getConfig(this.data.Cfg_get().rechargeId),e=L.W.Inst.GetCurSystem(),i=t.platformCurrency[e]
this.costLabel.textSet(`${i}元`),this.costIcon.node.SetActive(!1)}else{let t,e=0
e=this.data.GetPrice(),t=this.data.GetCostType(),this.costLabel.textSet(D.w.Instance.ConvertNumToString(e)),this.costLabel.node.SetActive(!0),this.costIcon.node.SetActive(!0)
const i=k.J.GetCurrencyIconUrl(t)
this.costIcon.spriteNameSet(i)}this.costContainer.Reposition()}}ShowDiscount(){if(null==this.customDiscountContainer&&null==this.discountContainer)return
const t=this.data.Cfg_get()
if(null!=this.discountContainer&&this.discountContainer.node.SetActive(!1),null!=this.customDiscountContainer&&this.customDiscountContainer.SetActive(!1),
0!=t.hot)if(1==t.hot)this.discountContainer.node.SetActive(!0),this.discountContainer.spriteNameSet("atlas/jbsd/ryjbsd_sp_0012"),this.discountLabel.node.SetActive(!1)
else if(2==t.hot)this.discountContainer.node.SetActive(!0),this.discountContainer.spriteNameSet("atlas/jbsd/ryjbsd_sp_0027"),this.discountLabel.node.SetActive(!0),
this.discountLabel.textSet(`${this.data.GetDiscount()}%`)
else if(4==t.hot)this.discountContainer.node.SetActive(!0),this.discountContainer.spriteNameSet("atlas/jbsd/ryjbsd_sp_0011"),this.discountLabel.node.SetActive(!1)
else if(5==t.hot)this.customDiscountContainer.node.SetActive(!0),this.customDiscountLabel.textSet(t.discount[1]),
this.customDiscountContainer.widthSet(this.customDiscountLabel.width()+35)
else if(7==t.hot){this.customDiscountContainer.node.SetActive(!0)
let e=0
if(t.viewCondSpecailDic.LuaDic_ContainsKey("ActivityOpen"))e=.001*A.i.ins.GetLastEndMS((0,a.aI)(t.viewCondSpecailDic.LuaDic_GetItem("ActivityOpen")))
else{const i=I.M.Split(t.timeControl,h.o.s_Arr_UNDER_LINE),s=r.D.serverTime_get()
e=this.StrChangeToMillisecond(i[1])-s+86400}this.customDiscountLabel.textSet(`剩${w.l.GetDayByTime(e)}`),this.customDiscountContainer.widthSet(this.customDiscountLabel.width()+35)}}
StrChangeToMillisecond(t){let e=x.E.New()
return e.parse(t,!1),e.time_get()/1e3}ShowBuyState(){this.canBuy=!0,this.state=-1
const t=this.data.Cfg_get()
this.lockTipLabel.node.SetActive(!1),this.limitTipLabel.node.SetActive(!1),null!=this.vipbtn&&this.vipbtn.node.SetActive(!1),null!=this.lockTipBg&&this.lockTipBg.node.SetActive(!1)
let e=""
if(this.data.IsCanAllianceShopLimitBuy())if(this.data.IsCanLevelLimitBuy())if(this.data.IsCanVipLimitBuy()&&this.data.IsCanTransferLimitBuy())if(this.data.IsCanOpendayBuy()){
if(this.data.IsLimitBuy())if(this.data.RemainNum_get()<=0){if(300!=t.functionId){const t=this.data.Cfg_get().GetUpVip(V.U.inst.model.level_get())
t>0?(this.state=1,null!=this.vipbtn&&(this.vipbtn.node.SetActive(!0),this.vipbtn.SetText(`V${t+(0,l.T)("可购买更多")}`))):e="购买已达上限"}}else if(this.limitTipLabel.node.SetActive(!0),
null!=this.lockTipBg&&this.lockTipBg.node.SetActive(!0),310==t.functionId)this.limitTipLabel.textSet(`终身限购${this.data.GetShowRemainTime()}次`)
else if(300==t.functionId||404==t.functionId)this.limitTipLabel.textSet(`限购${this.data.GetShowRemainTime()}次`)
else{const e=`${t.buyLimitDesc}${this.data.GetShowRemainTime()}/${this.data.GetShowBuyLimit()}`
this.canBuy=0!=this.data.RemainNum_get(),this.limitTipLabel.textSet(e)}}else e=this.data.GetOpenTimeStr()
else t.vipLimitBuy>0&&0==t.transferLevelLimit?(this.state=0,e=`VIP${I.M.IntToString(this.cfgRes.vipLimitBuy)+(0,
l.T)("可购买")}`):0==t.vipLimitBuy&&t.transferLevelLimit>0?(this.state=3,e=I.M.IntToString(t.transferLimit)+((0,l.T)("转")+(I.M.IntToString(this.cfgRes.transferLevelLimit)+(0,
l.T)("级可购买")))):(this.state=0,e=I.M.IntToString(t.transferLimit)+((0,l.T)("转")+(I.M.IntToString(t.transferLevelLimit)+((0,l.T)("级或VIP")+(I.M.IntToString(t.vipLimitBuy)+(0,
l.T)("可购买"))))))
else 0==t.LevelMaxLimit||9999==t.LevelMaxLimit?(this.state=3,e=b.h.GetLevelStr(t.LevelMinLimit)+(0,l.T)("可购买")):(this.state=3,
e=`${I.M.IntToString(t.LevelMinLimit)}-${b.h.GetLevelStr(t.LevelMaxLimit)+(0,l.T)("可购买")}`)
else e=`${t.guildMallLevelLimit}级商店可购买`,this.state=3
this.needUpLv=0,this.shouldUpgradeSkillIdAndRoleIdx=null
const i=this._baseItemData.cfgData_get().GetRewardsSkillId()
if(this.buyBtn.active){if(i&&i>0&&!this.limitTipLabel.node.active){const t=E.B.inst.GetPlayerInfoListFromSkillByItemId(this._baseItemData.modelId_get()),e=new g.Z
let s=!1
for(const[l,a]of(0,n.V5)(t)){const t=a.Skills_get()[i]
let n=0
t&&(n=t.originalLevel)
const l=this.GetSkillInfoForOneRole(i,a,n)
null!=l[1]&&e.Add(l),0==n&&(s=!0)}if(e.Count()<=0);else{let t=!0
for(const[i,s]of(0,n.V5)(e))if(!s[5]){t=!1
break}if(t)this.limitTipLabel.textSet("[DE2524]该技能已满级[-]"),this.limitTipLabel.node.SetActive(!0)
else{const t=s?"学习":"升级"
let i=!0
for(const[t,s]of(0,n.V5)(e))if(!s[2]){i=!1
break}if(i){const i=e[0][2][0],s=e[0][2][1],n=b.h.GetLevelStr(i)
this.needUpLv=i-s,this.limitTipLabel.textSet(`[DE2524]${n}可${t}技能[-]`),this.limitTipLabel.node.SetActive(!0)}else{let[i,s]=[0,0]
for(const[t,l]of(0,n.V5)(e))l[3]&&(i=l[3][0],s+=l[3][1])
if(s&&s>0){if(i>=s){this.limitTipLabel.textSet(`技能${t}所需已满`)
let i,s=!0,l=!0
for(const[t,a]of(0,n.V5)(e))if(!a[5]&&!a[2]){if(!a[4]||!a[4][0]){s=!1,l=!1
break}const[t,e,n]=[a[4][0],a[4][1],a[4][2]]
t>0&&e?i=[e,n]:s=!1,t>=0&&(l=!1)}s&&i&&(this.shouldUpgradeSkillIdAndRoleIdx=i),l&&(this.needUpLv=-1)}else this.limitTipLabel.textSet(`购买[047104]${i}/${s}[-]本可${t}`)
this.limitTipLabel.node.SetActive(!0)}}}}}U.N.GetInst().SkillBookCanBuySet(i,!0)}""!=e&&(this.lockTipLabel.node.SetActive(!0),this.lockTipLabel.textSet(e))}GetSkillIsMaxLv(t,e,i){
if(e){const e=d.j.Inst().GetSkillByIdLevel(t,i,!1)
if(null!=e&&i>=e.maxLevel)return!0}return!1}GetSkillInfoForOneRole(t,e,i){let s=!1
i&&i>0&&(s=!0)
let n=null,l=!1
s&&(n=R.r.Inst().GetItemBySkillIdAndLevel(t,1))
const a=d.j.Inst().GetSkillByIdLevel(t,1,!1)
a&&(l=O.m.Inst().CheckSkillPointUseVaildity(a,e))
const o={}
if(!n&&l){o[1]=s
if(this.GetSkillIsMaxLv(t,e,i))o[5]=!0
else{const[s,n]=this.GetUpSkillIsLimitByLevel(t,e,i)
if(s)o[2]=[s,n]
else{const[s,n]=this.GetSkillConsumeItem(t,e,i)
if(s&&s>0){const t=p.g.Inst_get().GetItemNum(s)
o[3]=[t,n]}const[l,a,r]=this.GetNeedLvUpgradeSkill(t,e,i)
l&&(o[4]=[l,r,e.createIdx])}}}return o}GetSkillRoleAndMinLevel(t){const e=E.B.inst.GetPlayerInfoListFromSkillByItemId(this._baseItemData.modelId_get())
let i=null,s=99999
for(const[l,a]of(0,n.V5)(e)){const e=a.Skills_get()[t]
let n=0
e&&(n=e.originalLevel),n<s&&(s=n,i=a)}return[i,s]}GetSkillConsumeItem(t,e,i){if(e){const s=d.j.Inst().GetSkillByIdLevel(t,i+1,!1)
if(null!=s){if(!O.m.Inst().CheckSkillPointUseVaildity(s,e))return[0,0]
const[t,i]=O.m.Inst().GetSkillItemConsume(s)
return[t,i]}}return[0,0]}GetUpSkillIsLimitByLevel(t,e,i){if(e){const s=d.j.Inst().GetSkillByIdLevel(t,i+1,!1)
if(null!=s){if(!O.m.Inst().CheckSkillPointUseVaildity(s,e))return
const[t,i]=O.m.Inst().CheckLearnState(s,e)
if(3==t)return[i,e.Level_get()]}}return[0,0]}GetNeedLvUpgradeSkill(t,e,i){if(e){const[s,n,l]=O.m.Inst().GetBuySkillConsumeBestRoleLv(t,e,i)
let a
if(l&&(a=t),s>0)return[n,e.Level_get(),a]}return[0,0]}ProcessLinkFunction(){if(this.data.Cfg_get().viewCondSpecailDic.RIDING_BUY){if(v.$.Inst().GetRidingBuyOpenId()){
const t=new y.B
return t.infoId="MALL:RIDINGBUY_NOTICE1",t.confirmText=(0,l.T)("确定"),t.cancelText=(0,l.T)("坚持购买"),t.confirmHandle=this.CreateDelegate(this.GoToRidingBuyPanel),
t.cancelHandle=this.CreateDelegate(this.InternalOnBuyBtnClick),f.t.Inst().Open(t),!0}}if(this.shouldUpgradeSkillIdAndRoleIdx){const t=new y.B
return t.infoId="MALL:SKILLBOOK_BUY_CONFIRM6",t.cancelText=(0,l.T)("确定"),t.confirmText=(0,l.T)("升级技能"),t.confirmHandle=this.CreateDelegate(this.GotoSkillPanel),
t.confirmParam=this.shouldUpgradeSkillIdAndRoleIdx,t.cancelHandle=this.CreateDelegate(this.InternalOnBuyBtnClick),f.t.Inst().Open(t),!0}
let t=H.O.inst.GetNeedUpgradeLevel(this.data.Cfg_get().labelId,this.data.Cfg_get().itemId)
if(t<=0&&this.needUpLv>0&&(t=this.needUpLv),t>0){const e=new y.B
return e.infoId="MALL:LEVEL_NOTICE",e.cancelText=(0,l.T)("确定"),e.confirmText=(0,l.T)("前往升级"),e.replaceParams.Add((0,a.tw)(t)),
e.confirmHandle=this.CreateDelegate(this.GotoUpgradeLevel),e.cancelHandle=this.CreateDelegate(this.InternalOnBuyBtnClick),f.t.Inst().Open(e),!0}if(this.needUpLv<0){const t=new y.B
return t.infoId="MALL:SKILLBOOK_BUY_CONFIRM5",t.cancelText=(0,l.T)("确定"),t.confirmText=(0,l.T)("取消"),t.cancelHandle=this.CreateDelegate(this.InternalOnBuyBtnClick),
f.t.Inst().Open(t),!0}return!1}GotoSkillPanel(t){const[e,i]=[t[1],t[2]]
e&&P.d.Inst_get().OpenView(G.l.SKILL_VIEW,e,i),H.O.Inst_get().CloseMainView(),H.O.Inst_get().CloseGoldMainView()}GotoUpgradeLevel(){m.N.inst.OpenUIByShortCutID(u.D.IWantExp)}
GoToRidingBuyPanel(){N.x.inst.CloseMarketBuyTip(),m.N.inst.OpenUIByShortCutID(u.D.RIDINGBUY_PANEL)}OnBuyBtnClick(){this.ProcessLinkFunction()||this.InternalOnBuyBtnClick()}
InternalOnBuyBtnClick(t=null,e=null){this.CheckGuide()
const i=U.N.GetInst().currentSelectShopData
let s=0
if(null!=i&&(3==i.shopId?s=1:2==i.shopId&&1==i.shopSubId?s=2:2==i.shopId&&2==i.shopSubId&&(s=3)),this.data.IsFree()){const t=1==this.data.Cfg_get().labelId
return 1==s?C.V.SendClickData(310004):2==s?C.V.SendClickData(310100):3==s&&C.V.SendClickData(310200),void N.x.inst.ReqBuyMallItem(this.data.mallid,1,t)}
if(1==this.state)B.y.inst.ClientSysMessage(113007)
else if(3==this.state);else if(0==this.state)B.y.inst.ClientSysMessage(113006)
else{const t=this.data.IsCanBuyWithOtherLimit()
!this.canBuy&&t&&B.y.inst.ClientSysMessage(113008)}if(0!=this.data.Cfg_get().rechargeId){
const t=F.O.Inst().getConfig(this.data.Cfg_get().rechargeId),e=L.W.Inst.GetCurSystem(),i=t.platformCurrency[e]
1==s?6==i?C.V.SendClickData(310005):18==i?C.V.SendClickData(310006):30==i?C.V.SendClickData(310007):68==i?C.V.SendClickData(310008):98==i?C.V.SendClickData(310009):198==i?C.V.SendClickData(310010):328==i?C.V.SendClickData(310011):648==i&&C.V.SendClickData(310012):2==s?6==i?C.V.SendClickData(310101):18==i?C.V.SendClickData(310102):30==i?C.V.SendClickData(310103):68==i?C.V.SendClickData(310104):98==i?C.V.SendClickData(310105):168==i&&C.V.SendClickData(310106):3==s&&(6==i?C.V.SendClickData(310201):18==i?C.V.SendClickData(310202):30==i?C.V.SendClickData(310203):68==i?C.V.SendClickData(310204):98==i?C.V.SendClickData(310205):198==i?C.V.SendClickData(310206):328==i?C.V.SendClickData(310207):648==i&&C.V.SendClickData(310208)),
j.t.inst.Buy(F.O.Inst().getConfig(this.data.Cfg_get().rechargeId),null)}else U.N.GetInst().selectedMallItemData=this.data,N.x.inst.CloseMarketBuyTip(),
this.canBuy&&o.i.Inst.AddEventHandler(S.g.TipsLoadCompelete,this.CreateDelegate(this.OpenMarketTip)),this.OpenTipView()}OpenTipView(){_.J.Inst_get().ShowItemTip(this._baseItemData)
}OpenMarketTip(t){N.x.inst.OpenMarketMallBuyTip(this.data,N.x.BuyTipPos),o.i.Inst.RemoveEventHandler(S.g.TipsLoadCompelete,this.CreateDelegate(this.OpenMarketTip))}Clear(){
this.UnRegGuide(),super.Clear()}Destroy(){o.i.Inst.RemoveEventHandler(S.g.TipsLoadCompelete,this.CreateDelegate(this.OpenMarketTip)),super.Destroy()}}},93640:(t,e,i)=>{i.d(e,{
j:()=>h})
var s,n=i(18998),l=i(83908),a=i(17409),o=i(49655),r=i(48933)
let h=n._decorator.ccclass("MarketBuyIcon")(s=class extends((0,l.Ri)()){constructor(...t){super(...t),this.selectNewGift=void 0}InitView(){super.InitView()
let t=(0,a.Y)(o.o.MarketPanel_ry)
t&&(this.selectNewGift=t.selectNewGift)}Clear(){super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}UpdateBuyIconPos(){
this.selectNewGift?r.I.calVec3.Set(-103,31,0):r.I.calVec3.Set(-70,31,0),this.node.transform.SetLocalPosition(r.I.calVec3)}})||s},53223:(t,e,i)=>{
var s,n=i(18998),l=i(83908),a=i(97461),o=i(57834),r=i(51868),h=i(85682),d=i(5494),c=i(79534),u=i(21554),m=i(92679),I=i(87923),g=i(68637),_=i(7601),p=i(74657),C=i(50679),S=i(52513),f=i(31896),y=i(7155)
class w extends((0,l.yk)()){constructor(...t){super(...t),this.model=null,this.data=null}InitView(){super.InitView()}Clear(){this.RemoveLis()}Destroy(){super.destroy()}SetData(t){
if(this.model=y.o.Inst_get(),this.icon.skin="atlas/chongzhi/"+t.icon,this.desc.textSet(t.productName),this.isSelectImg.SetActive(!1),this.UnRegGuide(),this.data=t,this.RegGuide(),
this.RefreshItem(),this.SelectItemHandle(),this.redPoint.SetActive(!1),0!=this.data.hotPoint){const e=!f.t.inst.IsHasClick(t.id)
this.redPoint.SetActive(e)}this.icon.node.SetLocalScaleXYZ(t.scale,t.scale,0),this.AddLis()}AddLis(){o.i.Get(this.node).RegistonClick(this.CreateDelegate(this.ItemClickHandle)),
y.o.Inst_get().AddEventHandler(f.t.inst.ITEM_SELECT_EVENT,this.CreateDelegate(this.SelectItemHandle)),
y.o.Inst_get().AddEventHandler(f.t.inst.BUY_SUCCESS_EVENT,this.CreateDelegate(this.RefreshItem))}RemoveLis(){
o.i.Get(this.node).RemoveonClick(this.CreateDelegate(this.ItemClickHandle)),
y.o.Inst_get().RemoveEventHandler(f.t.inst.ITEM_SELECT_EVENT,this.CreateDelegate(this.SelectItemHandle)),
y.o.Inst_get().RemoveEventHandler(f.t.inst.BUY_SUCCESS_EVENT,this.CreateDelegate(this.RefreshItem)),this.UnRegGuide()}RegGuide(){
null!=this.data&&g.c.Inst.RegGameObject(h.D.UI_MALL_RECHARGE_ITEM,this.node,this.data.id)}UnRegGuide(){
null!=this.data&&g.c.Inst.UnRegGameObject(h.D.UI_MALL_RECHARGE_ITEM,this.data.id)}CheckGuide(){null!=this.data&&I.l.CheckBtnClickTrigger(h.D.UI_MALL_RECHARGE_ITEM,this.data.id)}
ItemClickHandle(){this.CheckGuide(),f.t.inst.SetClickItemInfo(this.data),y.o.Inst_get().RaiseEvent(f.t.inst.ITEM_SELECT_EVENT)}SelectItemHandle(){
const t=f.t.inst.GetClickItemInfo()
if(t.id==this.data.id){if(this.isSelectImg.SetActive(!0),0!=this.data.hotPoint){f.t.inst.IsHasClick(t.id)||f.t.inst.CM_RedPointClickHandle(this.data.id),this.redPoint.SetActive(!1)
}}else this.isSelectImg.SetActive(!1)}RefreshItem(){if(this.gift.SetActive(!1),0!=this.data.giveType)if(2==this.data.giveType)this.gift.SetActive(!0)
else if(1==this.data.giveType){0==this.model.GetTotalBuyTimes(this.data.id)&&this.gift.SetActive(!0)}}}n._decorator.ccclass("RyRechargePanel")(s=class extends((0,l.pA)(r.$)()){
constructor(...t){super(...t),this.effect=null,this.num=null,this.baseItemData=null}InitView(){super.InitView(),this.grid.SetInitInfo("ui_market_rechargeitem_ry",null,w),
this.registerUIScId=h.D.Recharge,this.registerUIId=d.I.MarketPanel_ry}OnAddToScene(){}SetData(){this.AddLis()
const t=S.O.Inst().diamonds
f.t.inst.SetClickItemInfo(t[0]),this.RefreshSelectItem(),this.grid.data_set(t),this.UpdateBottomAnchors(),this.RegGuide()}RegGuide(){
g.c.Inst.RegGameObject(h.D.UI_MALL_RECHARGE_BTN,this.buy.node)}UnRegGuide(){g.c.Inst.UnRegGameObject(h.D.UI_MALL_RECHARGE_BTN)}CheckGuide(){
I.l.CheckBtnClickTrigger(h.D.UI_MALL_RECHARGE_BTN)}Clear(){this.RemoveLis(),super.Clear()}Destroy(){null!=this.effect&&(this.effect.Clear(),this.effect.Destroy()),super.destroy()}
AddLis(){y.o.Inst_get().AddEventHandler(f.t.inst.ITEM_SELECT_EVENT,this.CreateDelegate(this.ItemClick)),
a.i.Inst.AddEventHandler(m.g.RECHARGE_INFO_CHANGE,this.CreateDelegate(this.RechargeInfo)),o.i.Get(this.buy.node).RegistonClick(this.CreateDelegate(this.BuyBtnHandle)),
o.i.Get(this.giftBtn.node).RegistonClick(this.CreateDelegate(this.OpenItemTip)),y.o.Inst_get().AddEventHandler(f.t.inst.BUY_SUCCESS_EVENT,this.CreateDelegate(this.RefreshItem))}
RemoveLis(){y.o.Inst_get().RemoveEventHandler(f.t.inst.ITEM_SELECT_EVENT,this.CreateDelegate(this.ItemClick)),
a.i.Inst.RemoveEventHandler(m.g.RECHARGE_INFO_CHANGE,this.CreateDelegate(this.RechargeInfo)),o.i.Get(this.buy.node).RemoveonClick(this.CreateDelegate(this.BuyBtnHandle)),
o.i.Get(this.giftBtn.node).RemoveonClick(this.CreateDelegate(this.OpenItemTip)),y.o.Inst_get().RemoveEventHandler(f.t.inst.BUY_SUCCESS_EVENT,this.CreateDelegate(this.RefreshItem)),
this.UnRegGuide()}ItemClick(){this.RefreshSelectItem()}BuyBtnHandle(){this.CheckGuide()
const t=f.t.inst.GetClickItemInfo()
f.t.inst.Buy(t,this.num)}OpenItemTip(){u.J.Inst_get().ShowItemTip(this.baseItemData)}RefreshSelectItem(){
const t=f.t.inst.GetClickItemInfo(),e=_.W.Inst.GetCurSystem(),i=t.platformCurrency[e]
this.btnTxt.textSet(`${i}元`),this.icon.skin="atlas/chongzhi/"+t.icon,this.num=i,this.RefreshItem()}PlayEffect(){const t=f.t.inst.GetClickItemInfo()
let e="",[i,s,n]=[0,0,1]
"rychongzhi_sp_0017"==t.icon?(e="pre_eff_rychongzhi_sp_0007",i=2.3,s=77.7,n=1.4):"rychongzhi_sp_0018"==t.icon?(e="pre_eff_rychongzhi_sp_0008",i=-4.1,s=78.3,
n=1.5):"rychongzhi_sp_0019"==t.icon?(e="pre_eff_rychongzhi_sp_0009",i=-8.9,s=100.3,n=1.5):"rychongzhi_sp_0020"==t.icon?(e="pre_eff_rychongzhi_sp_0010",i=-14.3,s=112.3,
n=1.8):"rychongzhi_sp_0021"==t.icon?(e="pre_eff_rychongzhi_sp_0011",i=-26.3,s=105,n=2):"rychongzhi_sp_0022"==t.icon?(e="pre_eff_rychongzhi_sp_0012",i=-6.8,s=129.4,
n=2.5):"rychongzhi_sp_0025"==t.icon&&(e="pre_eff_rychongzhi_sp_0013",i=-16,s=145,n=2.6),null!=this.effect&&(this.effect.Clear(),this.effect.Destroy()),this.effect=new C.V,
this.effect.CreateByName(e,this.effectPanel,null,null,this.effectPanel)
const l=new c.P
l.Set(i,s,0),this.effect.SetLocalPosition(l)
const a=new c.P
a.Set(n,n,1),this.effect.SetLocalScale(a)}RefreshItem(){this.double.SetActive(!1),this.giftBtn.node.SetActive(!1),this.itemNum.node.SetActive(!1)
const t=f.t.inst.GetClickItemInfo()
if(0!=t.giveType){const e=y.o.Inst_get().GetTotalBuyTimes(t.id)
3==t.giveType&&0==e&&this.double.SetActive(!0),2==t.giveType&&this.ShowGift(),1==t.giveType&&0==e&&this.ShowGift()}}ShowGift(){const t=f.t.inst.GetClickItemInfo()
this.giftBtn.node.SetActive(!0)
const e=t.rewardId,i=p.A.GetReward(e).GetAllRewardList()[0]
i.count<=1?this.itemNum.node.SetActive(!1):(this.itemNum.node.SetActive(!0),this.itemNum.textSet(`${i.count}钻石`)),this.baseItemData=i}RechargeInfo(){}UpdateBottomAnchors(){}})},
66988:(t,e,i)=>{i.d(e,{G:()=>ce})
var s=i(42292),n=i(38045),l=i(98800),a=i(61646),o=i(73206),r=i(97461),h=i(2689),d=i(13687),c=i(16812),u=i(38935),m=i(5924),I=i(56937),g=i(18202),_=i(31222),p=i(5494),C=i(52726),S=i(98789),f=i(79534),y=i(92679),w=i(57522),D=i(74045),T=i(49067),A=i(87923),v=i(28613),L=i(13476),M=i(73865),b=i(24524),R=i(53820),P=i(29134),G=i(1248),O=i(47870),E=i(49691),B=i(59816),k=i(64093),x=i(76737),V=i(61546),N=i(14792),H=i(62734),U=i(62405),F=i(46013),j=i(26619),Y=i(47041),z=i(75128),q=i(65180),Z=i(98958),K=i(99294),$=i(9986),W=i(30267),X=i(61756),Q=i(32759),J=i(93877),tt=i(3522),et=i(72005),it=i(13113),st=i(61911),nt=i(85682),lt=i(60130),at=i(47786),ot=i(68637),rt=i(94075),ht=i(92916)
class dt extends st.f{constructor(...t){super(...t),this.bossIcon=null,this.bossTypeLabel=null,this.bossValueLabel=null,this.taskLabel=null,this.energyValueLabel=null,
this.anchor=null,this.bossInfo=null,this.resetContainer=null,this.resetBtn=null,this.resetTipLabel=null,this.pre_eff_lzxg02=null,this.lightEffect=null,this.taskTitle=null,
this.pos=null,this.stateUnLock=null,this.stateLock=null,this.energyContainer=null,this.infobg=null,this.addEnergylab=null,this.addEnergylabTween=null,this.addEnegryIcon=null,
this.addEnergylabAlpha=null,this.timerId=-1,this.effectTimerId=-1,this.currentBossValue=0,this.timeEffectId=-1,this.updateEnergyTimeId=-1,this.currentEnergyValue=-1,
this.collectObject=null,this.isUpdateEnergy=!1,this.guideboss=null,this.needGuideBoss=null,this.guideParm=null,this.cfg=null}InitView(){super.InitView(),
this.bossIcon=this.CreateComponent(et.w,1),this.bossTypeLabel=this.CreateComponent(J.Q,2),this.bossValueLabel=this.CreateComponent(J.Q,3),
this.taskLabel=this.CreateComponent(J.Q,5),this.energyValueLabel=this.CreateComponent(J.Q,6),this.anchor=this.CreateComponent(it.T,7),this.bossInfo=this.CreateComponent(K.z,8),
this.resetContainer=this.CreateComponent(K.z,9),this.resetBtn=this.CreateComponent($.W,10),this.resetTipLabel=this.CreateComponent(J.Q,11),
this.pre_eff_lzxg02=this.CreateComponent(K.z,13),this.lightEffect=this.CreateComponent(tt.k,14),this.taskTitle=this.CreateComponent(J.Q,15),this.pos=this.CreateComponent(K.z,16),
this.stateUnLock=this.CreateComponent(K.z,17),this.stateLock=this.CreateComponent(K.z,18),this.energyContainer=this.CreateComponent(W.V,19),
this.infobg=this.CreateComponent(K.z,20),this.addEnergylab=this.CreateComponent(J.Q,21),this.addEnergylabTween=this.CreateComponent(Q.c,22),
this.addEnegryIcon=this.CreateComponent(K.z,23),this.addEnergylabAlpha=this.CreateComponent(X.R,24),this.guideboss=!1,this.needGuideBoss=!1,
this.m_handlerMgr.AddEventMgr(y.g.MAZE_SUB_ENERGY,this.CreateDelegate(this.ShowUpdateEnergy)),
this.m_handlerMgr.AddEventMgr(y.g.MAZE_ADD_ENERGY,this.CreateDelegate(this.UpdateEnergy)),
this.m_handlerMgr.AddEventMgr(y.g.MAZE_UPDATE_EVENTDATA,this.CreateDelegate(this.OnUpdateRoom)),
this.m_handlerMgr.AddEventMgr(y.g.MAZE_UPDATE_ROOM,this.CreateDelegate(this.OnUpdateRoom)),this.m_handlerMgr.AddClickEvent(this.resetBtn,this.CreateDelegate(this.OnClickReset)),
this.m_handlerMgr.AddClickEvent(this.bossIcon,this.CreateDelegate(this.OnOpenMap)),this.addEnergylabTween.AddEventHandler(this.CreateDelegate(this.OnEnergyTween)),
this.m_handlerMgr.AddClickEvent(this.infobg,this.CreateDelegate(this.OnClickBg))}OnClickBg(){
null!=this.guideParm&&ot.c.Inst.CheckTrigger(nt.D.MAZE_COPY_INFO_BG,q.e.Inst_get().currentRoomId)}OnAddToScene(){
const t=q.e.Inst_get().GetCurrentPlayRoomData().cfg_get(),[e,i]=q.e.Inst_get().CalculationEventData(t.rebirth,t.type,1)
this.cfg=t,this.currentBossValue=e,this.addEnergylab.node.SetActive(!1),this.Update(),this.RegGuide(),lt.O.SetAnchorPos(this.anchor,!0,!0,0)}RegGuide(){
if(1!=this.cfg.newHand)return
this.RegBossGuide()
const t=ht.q.Inst_get().GuideParam()
this.guideParm!=t&&this.UnRegGuide(),this.guideParm=t,ot.c.Inst.RegGameObject(nt.D.MAZE_COPY_INFO_BG,this.infobg,this.guideParm)}RegBossGuide(){if(1!=this.cfg.newHand)return
const t=ht.q.Inst_get().GuideParam()
this.guideParm==t&&this.needGuideBoss||this.UnRegBossGuide(),this.guideboss||(this.guideboss=!0,this.guideParm=t,
ot.c.Inst.RegGameObject(nt.D.MAZE_COPY_INFO_ICON,this.bossIcon.node,t),ot.c.Inst.RegGameObject(nt.D.MAZE_COPY_INFO_RESET_BTN,this.resetBtn.node,t))}UnRegBossGuide(){
null!=this.guideParm&&this.guideboss&&(this.guideboss=!1,ot.c.Inst.UnRegGameObject(nt.D.MAZE_COPY_INFO_ICON,this.guideParm),
ot.c.Inst.UnRegGameObject(nt.D.MAZE_COPY_INFO_RESET_BTN,this.guideParm))}UnRegGuide(){null!=this.guideParm&&(this.UnRegBossGuide(),
ot.c.Inst.UnRegGameObject(nt.D.MAZE_COPY_INFO_BG,this.guideParm),this.guideParm=null)}Update(){0!=q.e.Inst_get().currentRoomId&&(this.UpdateRoomData(),this.ShowUpdateEnergy())}
UpdateRoomData(){const t=q.e.Inst_get().GetCurrentPlayRoomData(),e=t.cfg_get(),[i,s]=q.e.Inst_get().CalculationEventData(e.rebirth,e.type,1)
this.needGuideBoss=!1
const n=t.eventData.cfg_get()
s>0&&i>=s?(this.bossInfo.SetActive(!1),this.resetContainer.SetActive(!0),this.resetTipLabel.textSet(at.x.Inst().getItemById(11042512).sys_messsage),
this.pre_eff_lzxg02.SetActive(!1),this.lightEffect.SetActive(!0),this.needGuideBoss=!0,ht.q.Inst_get().CheckGuideKillAllBoss()):(1==i?(this.needGuideBoss=!0,
ht.q.Inst_get().CheckKillBoss()):0!=e.newHand2&&(this.needGuideBoss=!0),this.bossInfo.SetActive(!0),this.resetContainer.SetActive(!1),
this.currentBossValue!=i&&0!=i?(this.lightEffect.SetActive(!0),this.ClearLightEffectTime(),
this.effectTimerId=m.C.Inst_get().SetInterval(this.CreateDelegate(this.HideLightEffect),2e3,1)):this.lightEffect.SetActive(!1),this.currentBossValue=i,
this.bossTypeLabel.textSet(`击败${s}只昆顿分身`),this.bossValueLabel.textSet(`${i}/${s}`),this.pre_eff_lzxg02.SetActive(!q.e.Inst_get().isClickedBossIcon)),
t.isUnLock||null==n.completeCond?(this.stateUnLock.SetActive(!0),this.stateLock.SetActive(!1),this.taskTitle.textSet("传送门开启："),
this.taskLabel.textSet(at.x.Inst().getItemById(11042511).sys_messsage)):(this.stateUnLock.SetActive(!1),this.stateLock.SetActive(!0),this.taskTitle.textSet("解锁条件："),
this.taskLabel.textSet(Z.V.Inst().replaceLangParamTwo(n.completeShow,t.eventData.progress,n.completeCond[1].value))),this.RegBossGuide()}UpdateEnergy(){this.isUpdateEnergy=!0,
this.PlayEnergyEffect()}energyDropObjGet(t){this.collectObject=t,this.PlayEnergyEffect()}PlayEnergyEffect(){if(null!=this.collectObject&&this.isUpdateEnergy){
const t=this.energyValueLabel.node.GetPosition()
let e=this.collectObject.GetPos()
lt.O.WorldToUILocalPosInHeadPanel(e.x,e.y+2,e.z,this.pos.transform),e=this.pos.transform.GetPosition(),w.h.Inst_get().PlayFlyItem(e,t,null,null,null,1,100),this.collectObject=null,
this.isUpdateEnergy=!1,this.ClearUpdateEnergyTime(),this.updateEnergyTimeId=m.C.Inst_get().SetInterval(this.CreateDelegate(this.PlayEnergyNumAim),1e3,1)
}else this.isUpdateEnergy&&this.OnEnergyTween()}ShowUpdateEnergy(){const t=`${q.e.Inst_get().currentEnergy}/${q.e.Inst_get().maxEnergy}`
this.energyValueLabel.textSet(`时空能量：${t}`),this.energyContainer.CallReposition()}PlayEnergyNumAim(){const t=q.e.Inst_get().GetEveryEnergyGetValue()
this.addEnergylab.node.SetActive(!0),this.addEnergylab.textSet(`+${t}`)
const e=this.addEnegryIcon.GetLocalPosition()
e.x=this.addEnergylab.width()+5,this.addEnegryIcon.SetLocalPosition(e),this.addEnergylabTween.ResetToBeginning(),this.addEnergylabTween.PlayForward(),
this.addEnergylabAlpha.ResetToBeginning(),this.addEnergylabAlpha.PlayForward()}OnEnergyTween(){this.addEnergylab.node.SetActive(!1),this.ShowUpdateEnergy()}OnUpdateRoom(t){
this.UpdateRoomData(),this.RegGuide()}HideLightEffect(){this.lightEffect.SetActive(!1)}OnClickReset(){ce.Inst_get().CM_SumReward()}OnOpenMap(){q.e.Inst_get().isClickedBossIcon=!0,
this.pre_eff_lzxg02.SetActive(!1),ce.Inst_get().OpenMapRoom()}ClearLightEffectTime(){m.C.Inst_get().ClearInterval(this.effectTimerId),this.effectTimerId=-1}ClearUpdateEnergyTime(){
m.C.Inst_get().ClearInterval(this.updateEnergyTimeId),this.updateEnergyTimeId=-1}Clear(){this.ClearUpdateEnergyTime(),this.ClearLightEffectTime(),this.UnRegGuide(),super.Clear()}
Destroy(){this.addEnergylabTween.RemoveEventHandler(this.CreateDelegate(this.OnEnergyTween)),this.UnRegGuide(),rt.u.Inst_get().DestroyTransport(),super.Destroy()}}
var ct=i(62370),ut=i(57834),mt=i(98885),It=i(52212),gt=i(21554),_t=i(70850),pt=i(63076),Ct=i(75696),St=i(76645),ft=i(93078),yt=i(85751),wt=i(63945),Dt=i(8211),Tt=i(65550),At=i(23296)
class vt extends st.f{constructor(...t){super(...t),this.closeBtn=null,this.useBtn=null,this.descTxt=null,this.numGo=null,this.minusBtn=null,this.addBtn=null,this.maxBtn=null,
this.item=null,this.num=null,this.cancelBtn=null,this.titleTxt=null,this.limitTipLabel=null,this.confirmlab=null,this.currencyWidget=null,this._itemData=null,this.result=0,
this.mallInfo=null,this.remainNum=null,this.maxNum=null,this.price=null}InitView(){super.InitView(),this.closeBtn=this.CreateComponent($.W,1),
this.useBtn=this.CreateComponent($.W,2),this.descTxt=this.CreateComponent(J.Q,3),this.numGo=this.CreateComponent(K.z,4),this.minusBtn=this.CreateComponent($.W,5),
this.addBtn=this.CreateComponent($.W,6),this.maxBtn=this.CreateComponent($.W,7),this.item=this.CreateComponentBinder(Ct.j,8),this.num=this.CreateComponent(J.Q,9),
this.cancelBtn=this.CreateComponent($.W,10),this.titleTxt=this.CreateComponent(J.Q,11),this.limitTipLabel=this.CreateComponent(J.Q,12),this.confirmlab=this.CreateComponent(J.Q,13),
this.currencyWidget=this.CreateComponent(et.w,14)}OnAddToScene(){this.UpdateView(),this.AddLis()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.CloseBtnHandle)),this.m_handlerMgr.AddClickEvent(this.cancelBtn,this.CreateDelegate(this.CancelBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.useBtn,this.CreateDelegate(this.UseBtnHandle)),this.m_handlerMgr.AddClickEvent(this.addBtn,this.CreateDelegate(this.AddBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.minusBtn,this.CreateDelegate(this.MinusBtnHandle)),this.m_handlerMgr.AddClickEvent(this.maxBtn,this.CreateDelegate(this.MaxBtnHandle)),
ut.i.Get(this.numGo).RegistonClick(this.CreateDelegate(this.SelectUseNumHandler))}RemoveLis(){ut.i.Get(this.numGo).RemoveonClick(this.CreateDelegate(this.SelectUseNumHandler))}
UpdateView(){const t=12056
this._itemData=new pt.M(t),this.item.SetData(this._itemData),this.mallInfo=null
const e=q.e.Inst_get().GetRoomDataById(q.e.Inst_get().currentShopRoomId)
if(null==e)return
const i=e.eventData.cfg_get(),s=Dt.N.GetInst().GetMazeVoes(i.id)
for(let e=0;e<=s.Count()-1;e++){const i=s[e]
if(i.Cfg_get().itemId==t){this.mallInfo=i
break}}null!=this.mallInfo&&(this.remainNum=_t.g.Inst_get().GetItemNum(t),this.remainNum>0?(this.confirmlab.textSet("使 用"),this.maxNum=this.remainNum,this.result=this.remainNum,
this.limitTipLabel.textSet("")):(this.confirmlab.textSet("购 买"),this.maxNum=this.mallInfo.GetShowRemainTime(),
this.price=mt.M.String2Int(this.mallInfo.Cfg_get().consums.costs[0].subvalue),this.result=1,
this.limitTipLabel.textSet(ct.o.Format("限购数量{0}/{1}",this.mallInfo.GetShowRemainTime(),this.mallInfo.GetShowBuyLimit()))),this.ChangeHandler())}ChangeHandler(){
const t=this._itemData
let e
if(this.num.textSet(`${this.result}/${this.maxNum}`),this.remainNum>0)e="是否使用{0}{1}，恢复{2}时空能量？",e=mt.M.Replace(e,"{0}",`${yt.u.GreenColorStr2}${this.result}个[-]`),
e=mt.M.Replace(e,"{1}",`${yt.u.GreenColorStr2}${t.GetNameStr()}[-]`),e=mt.M.Replace(e,"{2}",`${yt.u.GreenColorStr2}${30*this.result}点[-]`),this.descTxt.textSet(e),
this.currencyWidget.SetActive(!1)
else{e="是否消耗      {0} 购买并使用{1}{2}\n恢复{3}时空能量？",e=mt.M.Replace(e,"{0}",`${yt.u.GreenColorStr2}${this.price*this.result}[-]`),
e=mt.M.Replace(e,"{1}",`${yt.u.GreenColorStr2}${this.result}个[-]`),e=mt.M.Replace(e,"{2}",`${yt.u.GreenColorStr2}${t.GetNameStr()}[-]`),
e=mt.M.Replace(e,"{3}",`${yt.u.GreenColorStr2}${30*this.result}点[-]`),this.descTxt.textSet(e),this.currencyWidget.SetActive(!0)
const i=this.descTxt.width(),s=new It.F(-i/2+105,this.currencyWidget.GetLocalPosition().y)
this.currencyWidget.SetLocalPositionV2(s),It.F.Recycle(s)}}GetValue(){const t=this._itemData.cfgData_get().Rewards_get()
let e=0,i=null
if(t.typevalues.Count()>0&&(i=t.typevalues[0],i.type==At.E.GUAJI_EXP)){const t=mt.M.Split(i.value,ct.o.s_Arr_UNDER_COLON)
e=mt.M.String2Int(t[0])}return e}SelectUseNumHandler(){ft.F.Instance_get().OpenView(new f.P(0,-200,0),this.CreateDelegate(this.inputHandle))}inputHandle(t,e){
10==t?this.result=1:e?this.result=t:(this.result*=10,this.result+=t),this.result>this.maxNum&&(this.result=this.maxNum),this.result<=1&&(this.result=1),this.ChangeHandler()}
CloseBtnHandle(){ce.Inst_get().CloseGetEnergyView()}CancelBtnHandle(){ce.Inst_get().CloseGetEnergyView(),ce.Inst_get().ExitCopy()}AddBtnHandle(){
this.result<this.maxNum?(this.result+=1,this.result>this.maxNum&&(this.result=this.maxNum),this.ChangeHandler()):Tt.y.inst.ClientSysMessage(101539)}MinusBtnHandle(){
this.result>1?(this.result-=1,this.result<1&&(this.result=1),this.ChangeHandler()):Tt.y.inst.ClientSysMessage(101540)}MaxBtnHandle(){
this.result<this.maxNum?(this.result=this.maxNum,this.ChangeHandler()):(this.remainNum,Tt.y.inst.ClientSysMessage(101539))}UseBtnHandle(){const t=this._itemData
if(this.remainNum>0)if(null!=t&&null!=t.serverData_get()&&null!=t.serverData_get().id){
_t.g.Inst_get().GetItemNumById(t.serverData_get().id)>=this.result?St.t.Inst_get().UseItem(this.result,this._itemData.modelId_get(),t.serverData_get().id):gt.J.Inst_get().UseItemByModelId(this._itemData.modelId_get(),this.result)
}else gt.J.Inst_get().UseItemByModelId(this._itemData.modelId_get(),this.result)
else wt.x.inst.ReqBuyMallItem(this.mallInfo.mallid,this.result,!0)
this.CloseBtnHandle()}Clear(){this.RemoveLis(),this.item.Clear(),super.Clear()}Destroy(){this.item.Destroy(),this.closeBtn=null,this.useBtn=null,this.descTxt=null,this.numGo=null,
this.minusBtn=null,this.addBtn=null,this.maxBtn=null,this.item=null,this.num=null,this.cancelBtn=null,this.titleTxt=null,this.limitTipLabel=null,this.confirmlab=null,
this.currencyWidget=null,this._itemData=null,this.result=0,super.Destroy()}}
var Lt=i(68662),Mt=i(6665),bt=i(85602),Rt=i(53905),Pt=i(65772),Gt=i(66399),Ot=i(48481),Et=i(41864),Bt=i(51868)
class kt extends Bt.${constructor(...t){super(...t),this.ui_baseitem=null,this.sign=null}InitView(){super.InitView(),this.ui_baseitem=this.CreateComponentBinder(Ct.j,1),
this.sign=this.CreateComponent(K.z,2)}SetData(t){this.ui_baseitem.SetData(t.baseItemData),this.sign.SetActive(1==t.sign)}Clear(){super.Clear(),this.ui_baseitem.Clear()}Destroy(){
super.Destroy(),this.ui_baseitem.Destroy()}}class xt extends st.f{constructor(...t){super(...t),this.nameLabel=null,this.typeLabel=null,this.rewardGrid=null,this.enterBtn=null,
this.beTipLabel=null,this.upgradeBtn=null,this.bg=null,this.recommendTip=null,this.type=0,this.rebirthLevel=0}InitView(){super.InitView(),
this.nameLabel=this.CreateComponent(J.Q,1),this.typeLabel=this.CreateComponent(J.Q,2),this.rewardGrid=this.CreateComponent(Mt.A,3),this.enterBtn=this.CreateComponent($.W,4),
this.beTipLabel=this.CreateComponent(J.Q,6),this.upgradeBtn=this.CreateComponent($.W,7),this.bg=this.CreateComponent(et.w,8),this.recommendTip=this.CreateComponent(K.z,9),
this.rewardGrid.SetInitInfo("ui_maze_reward_item",null,kt)}SetData(t,e){this.type=t,this.rebirthLevel=e,
this.m_handlerMgr.AddClickEvent(this.enterBtn,this.CreateDelegate(this.OnEnter)),this.m_handlerMgr.AddClickEvent(this.upgradeBtn,this.CreateDelegate(this.OnUpgrade)),
1==t?(this.bg.spriteNameSet("rymwfy_sp_0005"),this.typeLabel.textSet("时之迷宫")):(this.bg.spriteNameSet("rymwfy_sp_0006"),this.typeLabel.textSet("空之迷宫"))
const i=F.M.Inst_get().stage,s=F.M.Inst_get().subStage
this.recommendTip.SetActive(!1)
const a=F.M.Inst_get().GetItemById(F.M.Inst_get().resourceId)
let o=0
const r=mt.M.Split(a.spaceMazeLevel,ct.o.s_Arr_UNDER_CHAR_DOT)
o=1==t?(0,n.aI)(r[0]):(0,n.aI)(r[1])
const h=l.Y.Inst.primaryRole.roleinfo.Level_get()
h>=o?this.beTipLabel.node.SetActive(!1):(this.beTipLabel.node.SetActive(!0),this.beTipLabel.textSet(`${Et.h.GetLevelStr(o)}开放`)),2!=i||3!=s&&4!=s?(this.enterBtn.node.SetActive(!1),
this.upgradeBtn.node.SetActive(!1)):(this.enterBtn.node.SetActive(!0),2==t&&this.recommendTip.SetActive(!0),h>=o?(this.enterBtn.node.SetActive(!0),
this.upgradeBtn.node.SetActive(!1)):(this.enterBtn.node.SetActive(!1),this.upgradeBtn.node.SetActive(!0)))
const d=Gt.A.GetInst().GetRewards(t,e),c=new bt.Z
for(let t=1;t<=d.length;t++){const e=d[t],i=mt.M.Split(e.value,":"),s=new pt.M((0,n.aI)(i[0]))
s.showNum=!0
const l=new Ot.t
l.num=(0,n.aI)(i[1]),s.serverData_set(l),c.Add({baseItemData:s,sign:(0,n.aI)(e.sign)})}this.rewardGrid.data_set(c)}OnEnter(){if(q.e.Inst_get().currentEnergy<=0){const t=new T.B
t.infoId="SPACE_MAZE:TIPS1",t.confirmText="仍要进入",t.confirmHandle=this.CreateDelegate(this.EnterCopy),D.t.Inst().Open(t)}else this.EnterCopy()}OnUpgrade(){
_.N.inst.OpenUIByShortCutID(nt.D.IWantExp)}EnterCopy(){if(1==this.type){
const t=F.M.Inst_get().GetItemById(F.M.Inst_get().resourceId),e=mt.M.Split(t.spaceMazeLevel,ct.o.s_Arr_UNDER_CHAR_DOT),i=(0,n.aI)(e[1])
if(l.Y.Inst.primaryRole.roleinfo.Level_get()>=i){const t=new T.B
return t.infoId="SPACE_MAZE:TIPS6",t.confirmText="取消",t.cancelText="坚持进入",t.cancelHandle=this.CreateDelegate(this.CM_EnterCopy),void D.t.Inst().Open(t)}}this.CM_EnterCopy()}
CM_EnterCopy(){ce.Inst_get().CM_EnterSpaceMaze(this.rebirthLevel,this.type)}Clear(){super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}}var Vt=i(9057)
class Nt extends Vt.x{constructor(...t){super(...t),this.nameLabel=null,this.select=null,this.data=null,this.clickHandler=null}InitView(){super.InitView(),
this.nameLabel=this.CreateComponent(J.Q,1),this.select=this.CreateComponent(K.z,2)}SetData(t){this.data=t,
this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.OnClick)),this.nameLabel.textSet(t.page),this.SetSelect(!1)}OnClick(){this.SetSelect(!0)}SetSelect(t){
t?(null!=Nt.__currentSelect&&Nt.__currentSelect.SetSelect(!1),this.select.SetActive(!0),Nt.__currentSelect=this,
null!=this.clickHandler&&this.clickHandler(this.data,this.index)):this.select.SetActive(!1)}Clear(){super.Clear()}Destroy(){Nt.__currentSelect=null,this.clickHandler=null,
super.Destroy()}Test1(){return!0}S_Test(){return!0}}Nt.__currentSelect=null
class Ht extends st.f{constructor(...t){super(...t),this.grid=null,this.timeLabel=null,this.timeInfoItem=null,this.spaceInfoItem=null,this.powerLabelLabel=null,
this.powerContainer=null,this.tipLabel=null,this.timeContainer=null,this.selectLabel=null,this.selectTabContainer=null,this.listContainer=null,this.tabBg=null,
this.energyTipBtn=null,this.defaultSelectIndex=0,this.timeText="",this.remainTime=0,this.timeId=0,this.data=null,this.showTab=!0,this.showType=-1}InitView(){super.InitView(),
this.grid=this.CreateComponent(Mt.A,1),this.timeLabel=this.CreateComponent(J.Q,2),this.timeInfoItem=this.CreateComponentBinder(xt,3),
this.spaceInfoItem=this.CreateComponentBinder(xt,4),this.powerLabelLabel=this.CreateComponent(J.Q,5),this.powerContainer=this.CreateComponent(W.V,6),
this.tipLabel=this.CreateComponent(J.Q,7),this.timeContainer=this.CreateComponent(K.z,8),this.selectLabel=this.CreateComponent(J.Q,9),
this.selectTabContainer=this.CreateComponent(K.z,10),this.listContainer=this.CreateComponent(K.z,11),this.tabBg=this.CreateComponent(et.w,12),
this.energyTipBtn=this.CreateComponent(K.z,13),this.listContainer.SetActive(!1),this.grid.SetInitInfo("ui_maze_timespace_item",this.CreateDelegate(this.OnCreateSpaceItem)),
this.grid.OnReposition_set(this.CreateDelegate(this.OnGridLoad))}OnAddToScene(){this.m_handlerMgr.AddClickEvent(this.selectTabContainer,this.CreateDelegate(this.OnTabClick)),
this.m_handlerMgr.AddEventMgr(y.g.MAZE_SUB_ENERGY,this.CreateDelegate(this.UpdateEnergy)),this.m_handlerMgr.AddEventMgr(y.g.MAZE_ADD_ENERGY,this.CreateDelegate(this.UpdateEnergy)),
this.m_handlerMgr.AddEventMgr(y.g.SPACE_ORIGIN_UPDATE,this.CreateDelegate(this.UpdateOrigin)),
this.m_handlerMgr.AddClickEvent(this.energyTipBtn,this.CreateDelegate(this.OnOpenTip)),this.showTab=!0
const t=Gt.A.GetInst().rebirthList,e=F.M.Inst_get().GetItemById(F.M.Inst_get().resourceId),i=new bt.Z
for(let s=0;s<=t.Count()-1;s++){const n=t[s]
n.rebirth<=e.type&&(i.Add(n),n.rebirth>=0&&(this.defaultSelectIndex=s))}
-1!=q.e.Inst_get().defaultSelectIndex&&null!=i[q.e.Inst_get().defaultSelectIndex]&&(this.defaultSelectIndex=q.e.Inst_get().defaultSelectIndex),
i.Count()<=1?this.selectTabContainer.SetActive(!1):this.tabBg.heightSet(56*i.Count()+10),this.grid.data_set(i),q.e.Inst_get().defaultSelectIndex=this.defaultSelectIndex,
this.UpdateData(i[this.defaultSelectIndex]),this.ShowState()}OnTabClick(){this.showTab=!this.showTab,this.showTab?this.listContainer.SetActive(!0):this.listContainer.SetActive(!1)}
OnCreateSpaceItem(t){const e=new Nt
return e.setId(t,null,0),e.clickHandler=this.CreateDelegate(this.OnSelectItem),e}OnOpenTip(){const t=new Rt.w
t.position=new f.P(-120,-130,0),t.width=300,t.infoId="SPACEMAZE:TIPS",Pt.Q.Inst_get().Open(t)}OnSelectItem(t,e){this.UpdateData(t),q.e.Inst_get().defaultSelectIndex=e,
this.OnTabClick()}UpdateData(t){this.data=t,this.selectLabel.textSet(t.page),this.timeInfoItem.SetData(1,t.rebirth),this.spaceInfoItem.SetData(2,t.rebirth)}UpdateOrigin(){
null!=this.data&&this.UpdateData(this.data),this.ShowState()}UpdateEnergy(){const t=q.e.Inst_get().currentEnergy,e=q.e.Inst_get().maxEnergy
let i=""
i=0==t?`[d43e3e]${t}[-]/${e}`:`${t}/${e}`,this.powerLabelLabel.textSet(`时空能量：${i}`),this.powerContainer.CallReposition()}ShowState(){
const t=F.M.Inst_get().stage,e=F.M.Inst_get().subStage
if(this.ClearTime(),0==t||1==t)this.powerContainer.node.SetActive(!1),this.timeContainer.SetActive(!1),this.tipLabel.node.SetActive(!0),
this.tipLabel.textSet(at.x.Inst().getItemById(11042507).sys_messsage)
else if(2!=t||1!=e&&2!=e){if(2==t&&(3==e||4==e)){const t=F.M.Inst_get().GetItemById(F.M.Inst_get().resourceId)
this.timeText=at.x.Inst().getItemById(11042509).sys_messsage,this.remainTime=.001*(F.M.Inst_get().serverInfo.openTime.ToNum()+1e3*t.keepTime-Lt.D.serverMSTime_get()),
this.timeId=m.C.Inst_get().SetInterval(this.CreateDelegate(this.LoopTime),1e3),this.showType=2,this.powerContainer.node.SetActive(!0),this.timeContainer.SetActive(!0),
this.tipLabel.node.SetActive(!1),this.ShowTimeText(this.remainTime),this.UpdateEnergy()}}else this.showType=1,this.timeText=at.x.Inst().getItemById(11042508).sys_messsage,
this.remainTime=.001*(F.M.Inst_get().serverInfo.openTime.ToNum()-Lt.D.serverMSTime_get()),this.timeId=m.C.Inst_get().SetInterval(this.CreateDelegate(this.LoopTime),1e3),
this.powerContainer.node.SetActive(!1),this.timeContainer.SetActive(!1),this.tipLabel.node.SetActive(!0),this.ShowTimeText(this.remainTime)}LoopTime(){this.remainTime-=1,
this.remainTime<=0&&(this.remainTime=0,this.ClearTime()),this.ShowTimeText(this.remainTime)}ShowTimeText(t){let e=A.l.DateDiffFormat(t)
e=Z.V.Inst().replaceLangParamOne(this.timeText,`[5FB470]${e}[-]`),1==this.showType?this.tipLabel.textSet(e):this.timeLabel.textSet(e)}OnGridLoad(){
this.grid.itemList[this.defaultSelectIndex].SetSelect(!0)}ClearTime(){m.C.Inst_get().ClearInterval(this.timeId),this.timeId=-1}Clear(){this.ClearTime(),super.Clear()}Destroy(){
super.Destroy()}Test1(){return!0}S_Test(){return!0}}var Ut=i(38836),Ft=i(38962),jt=i(33996),Yt=i(17783)
class zt extends Vt.x{constructor(...t){super(...t),this.normal=null,this.select=null,this.normalNameLabel=null,this.selectNameLabel=null,this.redPoint=null,this.clickHandler=null,
this.data=null}InitView(){super.InitView(),this.normal=this.CreateComponent(K.z,1),this.select=this.CreateComponent(K.z,2),this.normalNameLabel=this.CreateComponent(J.Q,3),
this.selectNameLabel=this.CreateComponent(J.Q,4),this.redPoint=this.CreateComponent(K.z,5)}SetData(t){this.data=t,
this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.OnClick)),this.normalNameLabel.textSet(t.name),this.selectNameLabel.textSet(t.name),this.SetSelect(!1),
this.redPoint.SetActive(q.e.Inst_get().HadRedPoint(this.data.roomCfg.type,this.data.roomCfg.rebirth,this.data.subLabelId))}OnClick(){zt._currentSelect!=this&&(this.SetSelect(!0),
null!=this.clickHandler&&this.clickHandler(this.data))}SetSelect(t){t?(this.normal.SetActive(!1),this.select.SetActive(!0),null!=zt._currentSelect&&zt._currentSelect.SetSelect(!1),
zt._currentSelect=this,
q.e.Inst_get().HadRedPoint(this.data.roomCfg.type,this.data.roomCfg.rebirth,this.data.subLabelId)&&(ce.Inst_get().CM_ClickRedPoint(this.data.roomCfg.type,this.data.roomCfg.rebirth,this.data.subLabelId),
this.redPoint.SetActive(!1))):(this.normal.SetActive(!0),this.select.SetActive(!1))}Clear(){super.Clear()}Destroy(){this.clickHandler=null,zt._currentSelect=null,super.Destroy()}}
zt._currentSelect=null
var qt=i(3231)
class Zt extends qt.A{constructor(...t){super(...t),this.limitTipLabel=null,this.nameLabel=null,this.costLabel=null,this.costContainer=null,this.ui_baseitem=null,
this.discountContainer=null,this.bgBtn=null,this.buyBtn=null,this.costIcon=null,this.lockTipLabel=null,this.bg=null,this.bg2=null}InitView(){super.InitView(),
this.limitTipLabel=this.CreateComponent(J.Q,1),this.nameLabel=this.CreateComponent(J.Q,2),this.costLabel=this.CreateComponent(J.Q,3),this.costContainer=this.CreateComponent(W.V,4),
this.ui_baseitem=this.CreateComponentBinder(Ct.j,5),this.discountContainer=this.CreateComponent(et.w,6),this.bgBtn=this.CreateComponent($.W,7),
this.buyBtn=this.CreateComponent($.W,8),this.costIcon=this.CreateComponent(et.w,9),this.lockTipLabel=this.CreateComponent(J.Q,10),this.bg=this.CreateComponent(et.w,11),
this.bg2=this.CreateComponent(et.w,12)}SetData(t){super.SetData(t),this.ui_baseitem.SetData(t.GetBaseItemData(!0))
const e=t.Cfg_get()
null!=e.rechargeId&&0!=e.rechargeId?(this.bg.SetActive(!0),this.bg2.SetActive(!1)):(this.bg.SetActive(!1),this.bg2.SetActive(!0))}ShowDiscount(){const t=this.data.Cfg_get()
0!=t.hot?1==t.hot?(this.discountContainer.node.SetActive(!0),this.discountContainer.spriteNameSet("ryjbsd_sp_0012"),
this.discountContainer.MakePixelPerfect()):2==t.hot?(this.discountContainer.node.SetActive(!0),this.discountContainer.spriteNameSet("ryjbsd_sp_0027"),
this.discountContainer.MakePixelPerfect()):4==t.hot&&(this.discountContainer.node.SetActive(!0),
this.discountContainer.spriteNameSet("ryjbsd_sp_0011")):this.discountContainer.SetActive(!1)}Clear(){super.Clear()}Destroy(){super.Destroy()}}class Kt extends st.f{constructor(){
super(),this.mallGrid=null,this.btnGrid=null,this.btnClose=null,this.tipLabel=null,this.typeDict=null,this.typeDict=new Ft.X}InitView(){super.InitView(),
this.mallGrid=this.CreateComponent(Mt.A,1),this.btnGrid=this.CreateComponent(Mt.A,2),this.btnClose=this.CreateComponent(K.z,3),this.tipLabel=this.CreateComponent(J.Q,4),
this.m_handlerMgr.AddClickEvent(this.btnClose,this.CreateDelegate(this.OnClose)),this.mallGrid.SetInitInfo("ui_maze_mall_item",null,Zt),
this.btnGrid.SetInitInfo("ui_maze_mall_btn",this.CreateDelegate(this.CreateMallBtn)),this.btnGrid.OnReposition_set(this.CreateDelegate(this.OnBtnLoaded)),
Dt.N.GetInst().AddEventHandler(jt.G.BUY_MALLINFO,this.CreateDelegate(this.OnSuccessBuy))}OnAddToScene(){this.tipLabel.textSet(at.x.Inst().getItemById(11042521).sys_messsage)
const t=q.e.Inst_get().GetRoomDataById(q.e.Inst_get().currentShopRoomId),e=t.eventData.cfg_get()
t.isUnLock||Yt.L.Inst_get().mgr.CM_TalkHandle((0,n.aI)(e.param.value),l.Y.Inst.m_primaryRoleInfo.Id_get())
const i=new bt.Z,s=Dt.N.GetInst().GetMazeVoes(e.id)
for(let e=0;e<=s.Count()-1;e++){const n=s[e]
if(null!=n){const e=n.Cfg_get()
let s=this.typeDict.LuaDic_GetItem(e.subLabelId)
null==s&&(s=new bt.Z,this.typeDict.LuaDic_AddOrSetItem(e.subLabelId,s)),s.Add(n)
let l=!1
for(let t=0;t<=i.Count()-1;t++)if(i[t].subLabelId==e.subLabelId){l=!0
break}l||i.Add({name:e.subLabelName,subLabelId:e.subLabelId,roomCfg:t.cfg_get()})}}if(i.Sort(this.CreateDelegate(this.SortMallTab)),this.SortMallDatas(),
this.UpdateData(i[0].subLabelId),i.Count()>1)this.btnGrid.data_set(i)
else{this.btnGrid.node.SetActive(!1)
const t=i[0]
q.e.Inst_get().HadRedPoint(t.roomCfg.type,t.roomCfg.rebirth,t.subLabelId)&&ce.Inst_get().CM_ClickRedPoint(t.roomCfg.type,t.roomCfg.rebirth,t.subLabelId)}}SortMallTab(t,e){
return t.subLabelId-e.subLabelId}EventHandler(){}SortMallDatas(){for(const[t,e]of(0,Ut.vy)(this.typeDict))e.Sort(this.CreateDelegate(this.SortMallData))}SortMallData(t,e){
return t.Cfg_get().order-e.Cfg_get().order}CreateMallBtn(t){const e=new zt
return e.setId(t,null,0),e.clickHandler=this.CreateDelegate(this.OnSelectMall),e}OnBtnLoaded(){this.btnGrid.itemList[0].SetSelect(!0)}OnSelectMall(t){this.UpdateData(t.subLabelId)}
UpdateData(t){const e=this.typeDict.LuaDic_GetItem(t)
this.mallGrid.data_set(e)}OnClose(){if(q.e.Inst_get().marketFirstClose){const t=ce.Inst_get().endPos.Clone()
t.y-=.25
const e=this.btnClose.GetPosition().Clone()
ce.Inst_get().PlayMarketCloseEffect(e,t)}ce.Inst_get().CloseTimeSpaceMarket()}OnSuccessBuy(){this.mallGrid.Refresh()}Clear(){super.Clear()}Destroy(){
Dt.N.GetInst().RemoveEventHandler(jt.G.BUY_MALLINFO,this.CreateDelegate(this.OnSuccessBuy)),super.Destroy()}Test1(){return!0}S_Test(){return!0}}
var $t=i(43133),Wt=i(9776),Xt=i(8889),Qt=i(48592)
class Jt extends st.f{constructor(...t){super(...t),this.closebtn=null,this.roomlab=null,this.goldlab=null,this.sliverlab=null,this.springlab=null,this.explab=null,
this.levellab=null,this.tiplab=null,this.resetbtn=null,this.cancelbtn=null,this.itempanel=null,this.itemscrollview=null,this.itemscrollbar=null,this.itemgrid=null,
this.uitable=null,this.goldcontainer=null,this.slivercontainer=null,this.springcontainer=null,this.model=null}InitView(){super.InitView(),
this.closebtn=this.CreateComponent($t.V,1),this.roomlab=this.CreateComponent(J.Q,2),this.goldlab=this.CreateComponent(J.Q,3),this.sliverlab=this.CreateComponent(J.Q,4),
this.springlab=this.CreateComponent(J.Q,5),this.explab=this.CreateComponent(J.Q,6),this.levellab=this.CreateComponent(J.Q,7),this.tiplab=this.CreateComponent(J.Q,8),
this.resetbtn=this.CreateComponent($t.V,9),this.cancelbtn=this.CreateComponent($t.V,10),this.itempanel=this.CreateComponent(Xt.$,11),
this.itemscrollview=this.CreateComponent(Wt.h,12),this.itemscrollbar=this.CreateComponent(Qt.G,13),this.itemgrid=this.CreateComponent(Mt.A,14),
this.uitable=this.CreateComponent(W.V,15),this.goldcontainer=this.CreateComponent(K.z,16),this.slivercontainer=this.CreateComponent(K.z,17),
this.springcontainer=this.CreateComponent(K.z,18),this.itemgrid.SetInitInfo("ui_baseitem",null,Ct.j),this.tiplab.textSet(at.x.Inst().getItemStrById(11042524))}OnAddToScene(){
this.model=q.e.Inst_get(),this.AddLis(),this.UpdateResCount(),this.UpdateItemes(),this.UpdateExp()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.closebtn,this.CreateDelegate(this.OnClosebtnClick)),this.m_handlerMgr.AddClickEvent(this.resetbtn,this.CreateDelegate(this.OnResetbtnClick)),
this.m_handlerMgr.AddClickEvent(this.cancelbtn,this.CreateDelegate(this.CloseHandler))}RemoveLis(){}OnClosebtnClick(){
lt.O.PlayNormalCloseTween(this.closebtn,this.CreateDelegate(this.CloseHandler))}UpdateExp(){
const t=this.model.CalcLevelAndExp(this.model.sumRoomReward.beginLevel,this.model.sumRoomReward.beginExp.ToNum(),this.model.sumRoomReward.exp.ToNum())
this.explab.textSet(A.l.GetPurseVOChineseString(this.model.sumRoomReward.exp.ToNum()))
let e=_T("（累计提升")
0!=t[0]&&(e+=`${t[0]}级`),t[1]>0&&(e+=`${t[1]}%`),e+="）",this.levellab.textSet(e)}UpdateResCount(){const t=this.model.GetGatherReses()
this.goldlab.textSet(`${t[1]}/${t[0]}`),0==t[0]?this.goldcontainer.SetActive(!1):this.goldcontainer.SetActive(!0),
0==t[2]?this.slivercontainer.SetActive(!1):this.slivercontainer.SetActive(!0),0==t[4]?this.springcontainer.SetActive(!1):this.springcontainer.SetActive(!0),
this.sliverlab.textSet(`${t[3]}/${t[2]}`),this.springlab.textSet(`${t[5]}/${t[4]}`),this.roomlab.textSet(`${t[7]}/${t[6]}`),this.uitable.Reposition()}UpdateItemes(){
const t=this.model.sumRoomReward.items,e=new bt.Z
for(let i=0;i<=t.Count()-1;i++){const s=new pt.M(t[i].modelId,t[i])
e.Add(s)}this.itemgrid.data_set(e)}OnResetbtnClick(){ce.Inst_get().ResetSpaceMaze(),this.CloseHandler()}CloseHandler(){_.N.inst.CloseById(p.I.MazeTimeSpaceResetPanel)}Clear(){
this.RemoveLis(),super.Clear()}Destroy(){super.Destroy(),this.closebtn=null,this.roomlab=null,this.goldlab=null,this.sliverlab=null,this.springlab=null,this.explab=null,
this.levellab=null,this.tiplab=null,this.resetbtn=null,this.cancelbtn=null,this.itempanel=null,this.itemscrollview=null,this.itemscrollbar=null,this.itemgrid=null,
this.uitable=null,this.goldcontainer=null,this.slivercontainer=null,this.springcontainer=null}Test1(){return!0}S_Test(){return!0}}
var te=i(44758),ee=i(70123),ie=i(75439),se=i(19519)
class ne extends st.f{constructor(...t){super(...t),this.bossView=null,this.monsterView=null,this.exitBtn=null,this.killMonsterNum=null,this.expLabCopy=null,this.rewardGrid=null,
this.exitLab=null,this.exitBtnBg=null,this.goodGridContainer=null,this.listScrollViewPanel=null,this.leftDec=null,this.rightDec=null,this.bg=null,this.rightContainer=null,
this.time=3,this.timerId=-1,this.roomData=null}InitView(){super.InitView(),this.bossView=this.CreateComponent(K.z,4),this.monsterView=this.CreateComponent(K.z,5),
this.exitBtn=this.CreateComponent($.W,11),this.killMonsterNum=this.CreateComponent(J.Q,12),this.expLabCopy=this.CreateComponent(J.Q,13),
this.rewardGrid=this.CreateComponent(Mt.A,14),this.exitLab=this.CreateComponent(J.Q,15),this.exitBtnBg=this.CreateComponent(et.w,16),
this.goodGridContainer=this.CreateComponent(K.z,17),this.listScrollViewPanel=this.CreateComponent(Xt.$,18),this.leftDec=this.CreateComponent(K.z,19),
this.rightDec=this.CreateComponent(K.z,20),this.bg=this.CreateComponent(et.w,21),this.rightContainer=this.CreateComponent(K.z,22),
this.rewardGrid.SetInitInfo("ui_baseitem",this.CreateDelegate(this.CreateItem))}OnAddToScene(){this.m_handlerMgr.AddClickEvent(this.exitBtn,this.CreateDelegate(this.OnClose)),
this.m_handlerMgr.AddEventMgr(y.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors)),this.UpdateAnchors()
const t=q.e.Inst_get().GetCurrentPlayRoomData()
this.roomData=t
const e=t.eventData.cfg_get()
e.type==q.e.ATTACK_BOSS||e.type==q.e.GOBLIN||e.type==q.e.NPC?this.ShowBossVew():2==e.type&&this.ShowMonsterView(),q.e.Inst_get().resultData=null}ShowBossVew(){
this.monsterView.SetActive(!1),this.bossView.SetActive(!0)
const t=q.e.Inst_get().GetCurrentPlayRoomData().cfg_get()
1!=t.type&&2!=t.start?(this.time=0,this.exitLab.textSet("关闭")):this.time=0
const e=q.e.Inst_get().resultData
this.goodGridContainer.SetLocalPositionXYZ(120,-31,0),this.ShowItems(e)}ShowMonsterView(){this.monsterView.SetActive(!0),this.bossView.SetActive(!1)
const t=q.e.Inst_get().resultData
this.killMonsterNum.textSet(`击退怪物：${t.killNum}`),this.expLabCopy.textSet(A.l.GetPurseVOChineseString(t.killMonsterExp.ToNum(),!0,2)),
this.goodGridContainer.SetLocalPositionXYZ(120,-50,0),this.ShowItems(t)}ShowItems(t){const e=new bt.Z
let i=t.items.Count()
if(i<=0){const t=this.monsterView.GetLocalPosition()
return t.y=-50,this.monsterView.SetLocalPosition(t),void this.goodGridContainer.SetActive(!1)}for(let s=0;s<=i-1;s++){const i=t.items[s],n=new pt.M(i.modelId)
n.serverData_set(i),e.Add(n)}this.rewardGrid.data_set(e),i>6&&(i=6.5)
const s=80*i
this.listScrollViewPanel.baseClipRegionSet(new te.L(s/2,-40,s,80)),this.listScrollViewPanel.node.SetLocalPositionXYZ(-s/2,35,0)
let n=this.rightDec.GetLocalPosition()
n.x=s/2+35,this.rightDec.SetLocalPosition(n),n=this.leftDec.GetLocalPosition(),n.x=-(s/2+35),this.leftDec.SetLocalPosition(n)}CreateItem(t){const e=new Ct.j
return e.setId(t,null,0),e}OnBuyClick(){const t=se.J.GetGold(l.Y.Inst.PrimaryRoleInfo_get(),se.J.GOLD_DIAMOND),e=ie.D.getInstance().GetIntValue("SPACEMAZE:DOUBLE_REWARD")
t>=e?(ce.Inst_get().CM_UseDoubleRewardItem(),ce.Inst_get().CloseTimeSpaceResultView()):ee.W.ins.OpenCurrencyAccess(se.J.GOLD_DIAMOND_STR,e-t)}UpdateAnchors(){
const t=lt.O.GetUIWidth()
this.bg.widthSet(t),lt.O.SetAnchorPos(this.rightContainer,!0,!1,0)
const e=this.rightContainer.GetLocalPosition()
e.x-=20,this.rightContainer.SetLocalPosition(e)}OnClose(){5==this.roomData.eventData.cfg_get().type&&ce.Inst_get().CM_LeaveGoblinRoom(),ce.Inst_get().CloseTimeSpaceResultView()}
ClearTime(){m.C.Inst_get().ClearInterval(this.timerId),this.timerId=-1}Clear(){this.ClearTime(),super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}}
class le extends Bt.${constructor(...t){super(...t),this.typeLabel=null,this.eventIcon=null,this.valueLabel=null,this.infoContainer=null,this.data=null}InitView(){super.InitView(),
this.typeLabel=this.CreateComponent(J.Q,1),this.eventIcon=this.CreateComponent(et.w,2),this.valueLabel=this.CreateComponent(J.Q,3),this.infoContainer=this.CreateComponent(W.V,4)}
SetData(t){this.data=t,1==t.type?this.ShowBossInfo():4==t.type&&this.ShowMarketInfo()}ShowBossInfo(){this.typeLabel.textSet("击败首领 "),this.eventIcon.spriteNameSet("rymwfy_bt_0002"),
this.eventIcon.MakePixelPerfect()
const[t,e]=q.e.Inst_get().CalculationEventData(this.data.rebirthLevel,this.data.roomType,this.data.type)
this.valueLabel.textSet(`${t}/${e}`),this.infoContainer.CallReposition()}ShowMarketInfo(){this.typeLabel.textSet("时空商人 "),this.eventIcon.spriteNameSet("rymwfy_bt_0014"),
this.eventIcon.MakePixelPerfect()
const t=this.infoContainer.node.GetLocalPosition()
t.x=12.7,this.infoContainer.node.SetLocalPosition(t)
let e=!1
const i=q.e.Inst_get().GetRoomDataList(this.data.roomType,this.data.rebirthLevel)
for(let t=0;t<=i.Count()-1;t++){const s=i[t]
if(null!=s.eventData){if(s.eventData.cfg_get().type==this.data.type){e=s.isUnLock
break}}}e?this.valueLabel.textSet("[067a06]已发现[-]"):this.valueLabel.textSet("未发现"),this.infoContainer.CallReposition()}Clear(){super.Clear()}Destroy(){super.Destroy()}}
var ae,oe,re=i(9182)
class he extends st.f{constructor(...t){super(...t),this.btnClose=null,this.ui_maze_room_map=null,this.eventItemGrid=null,this.mazeTypeLabel=null,this.bg=null,this.bg1=null,
this.bg2=null,this.leftContainer=null,this.rightContainer=null,this.cfg=null,this.guideParm=null}InitView(){super.InitView(),this.btnClose=this.CreateComponent($.W,1),
this.ui_maze_room_map=this.CreateComponentBinder(re.I,2),this.eventItemGrid=this.CreateComponent(Mt.A,3),this.mazeTypeLabel=this.CreateComponent(J.Q,4),
this.bg=this.CreateComponent(et.w,5),this.bg1=this.CreateComponent(et.w,6),this.bg2=this.CreateComponent(et.w,7),this.leftContainer=this.CreateComponent(K.z,8),
this.rightContainer=this.CreateComponent(K.z,9),this.m_handlerMgr.AddClickEvent(this.btnClose,this.CreateDelegate(this.OnClose)),
this.eventItemGrid.SetInitInfo("ui_maze_event_info",null,le)}OnAddToScene(){const t=q.e.Inst_get().GetCurrentPlayRoomData(!1)
this.ui_maze_room_map.OnAddToScene()
const e=new bt.Z,i=t.cfg_get()
1==i.type?this.mazeTypeLabel.textSet("时之迷宫"):this.mazeTypeLabel.textSet("空之迷宫"),e.Add({type:1,roomType:i.type,rebirthLevel:i.rebirth}),this.cfg=i,this.eventItemGrid.data_set(e),
this.RegGuide(),this.m_handlerMgr.AddEventMgr(y.g.MAZE_UPDATE_ROOM,this.CreateDelegate(this.RegGuide)),this.UpdateAnchors()}OnClose(){ce.Inst_get().CloseMapRoom()}RegGuide(){
if(1!=this.cfg.newHand)return
const t=ht.q.Inst_get().GuideParam()
t!=this.guideParm&&this.UnRegGuide(),this.guideParm=t,ot.c.Inst.RegGameObject(nt.D.MAZE_COPY_TIME_SPACE_ROOM_CLOSE_BTN,this.btnClose.node,this.guideParm)}UnRegGuide(){
null!=this.guideParm&&ot.c.Inst.UnRegGameObject(nt.D.MAZE_COPY_TIME_SPACE_ROOM_CLOSE_BTN,this.btnClose.node,this.guideParm)}UpdateAnchors(){const t=lt.O.GetUIWidth()
this.bg.widthSet(t)
const e=t-60
this.bg1.widthSet(e),this.bg2.widthSet(e),lt.O.SetAnchorPos(this.leftContainer,!0,!1,0),lt.O.SetAnchorPos(this.rightContainer,!1,!0,0)}Clear(){this.ui_maze_room_map.Clear(),
this.UnRegGuide(),super.Clear()}Destroy(){this.ui_maze_room_map.Destroy(),super.Destroy()}Test1(){return!0}S_Test(){return!0}}class de extends st.f{constructor(){super(),
this.ruleTitleLabel=null,this.ruleDescLabel=null,this.ruleImg=null,this.btnPrev=null,this.btNext=null,this.btnClose=null,this.dataList=null,this.index=-1,this.dataList=new bt.Z}
InitView(){super.InitView(),this.ruleTitleLabel=this.CreateComponent(J.Q,1),this.ruleDescLabel=this.CreateComponent(J.Q,2),this.ruleImg=this.CreateComponent(et.w,3),
this.btnPrev=this.CreateComponent(K.z,4),this.btNext=this.CreateComponent(K.z,5),this.btnClose=this.CreateComponent(K.z,6)}OnAddToScene(){
this.m_handlerMgr.AddClickEvent(this.btNext,this.CreateDelegate(this.OnClickNext)),this.m_handlerMgr.AddClickEvent(this.btnPrev,this.CreateDelegate(this.OnClickPrev)),
this.m_handlerMgr.AddClickEvent(this.btnClose,this.CreateDelegate(this.OnClose)),this.dataList.Add({spriteName:"rymwfy_sp_0041",descId:11042517}),this.dataList.Add({
spriteName:"rymwfy_sp_0042",descId:11042518}),this.dataList.Add({spriteName:"rymwfy_sp_0043",descId:11042519}),this.ShowIndex(1)}ShowIndex(t){const e=this.dataList.Count()
if(t<=0||t>e)return
this.btNext.SetActive(t<e),this.btnPrev.SetActive(t>1),this.index=t
const i=this.dataList[t-1]
this.ruleTitleLabel.textSet(`时空迷宫规则（${t}/${e}）`),this.ruleImg.spriteNameSet(i.spriteName),this.ruleDescLabel.textSet(at.x.Inst().getItemById(i.descId).sys_messsage)}OnClickPrev(){
this.index-=1,this.ShowIndex(this.index)}OnClickNext(){this.index+=1,this.ShowIndex(this.index)}OnClose(){if(q.e.Inst_get().ruleFirstClose){
const t=ce.Inst_get().endPos,e=this.btnClose.GetPosition()
t.x-=.2,ce.Inst_get().PlayRuleCloseEffect(e,t)}ce.Inst_get().CloseRuleView()}Clear(){super.Clear(),ht.q.Inst_get().CheckGuideCollect()}Destroy(){super.Destroy()}Test1(){return!0}
S_Test(){return!0}}let ce=(oe=class t extends c.k{constructor(){super(),this.copyInfoView=null,this.ShowInfoTipTimer=null,this.endPos=null,this.marketstop=!1,this.resetTimerid=-1,
this.RegisterMessage()}static Inst_get(){return null==t.inst&&(t.inst=new t),t.inst}RegisterMessage(){}Open(){const t=new I.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.viewClass=Ht,_.N.inst.OpenById(p.I.MazeTimeSpaceView,null,null,t)}OpenMapRoom(){const t=new I.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.viewClass=he,_.N.inst.OpenById(p.I.MazeTimeSpaceRoomView,null,null,t)}OpenTimeSpaceMarket(){const t=new I.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.viewClass=Kt,_.N.inst.OpenById(p.I.TimeSpaceMarketView,null,null,t)}OpenTimeSpaceResultView(){const t=new I.v
t.layerType=C.F.Tip,t.isShowMask=!0,t.isDefaultUITween=!0,t.viewClass=ne,_.N.inst.OpenById(p.I.MazeTimeSpaceResultView,null,null,t)}OpenMazeRuleView(){const t=new I.v
t.isShowMask=!0,t.maskAlpha=.8,t.viewClass=de,_.N.inst.OpenById(p.I.MazeRulePanel,null,null,t)}OpenGetEnergyView(){const t=new I.v
t.layerType=C.F.Alert,t.isShowMask=!0,t.viewClass=vt,_.N.inst.OpenById(p.I.MazeGetEnergyView,null,null,t)}CloseGetEnergyView(){_.N.inst.CloseById(p.I.MazeGetEnergyView)}
OpenGoToMazeTip(){const t=new T.B
t.infoId="SPACE_MAZE:TIPS7",t.confirmText="立即前往",t.confirmHandle=this.CreateDelegate(this.OpenMazeCopy),D.t.Inst().Open(t)}OpenMazeCopy(){
U.j.Inst_get().OpenRootView(j.W.MAZE_SPACE)}OpenCopyInfoPanel(){if(null==this.copyInfoView){const t=new I.v
t.layerType=C.F.DefaultUI,t.positionType=S.$.eCustom,_.N.inst.OpenById(p.I.MazeCopyRightPanel,this.CreateDelegate(this.OnLoadCopyInfoView),this.CreateDelegate(this.OnDestroyCopyInfoView),t),
this.EnterCopy()}}OnLoadCopyInfoView(t){return this.copyInfoView=new dt,this.copyInfoView.setId(t,null,0),
m.C.Inst_get().SetFrameLoop(this.CreateDelegate(this.UpdateTransportName),1,1),q.e.Inst_get().isClickedBossIcon=!1,this.copyInfoView}UpdateTransportName(){
rt.u.Inst_get().UpdateTransportName()}OnDestroyCopyInfoView(){g.g.DestroyView(this.copyInfoView),this.copyInfoView=null}CloseCopyInfoPanel(){
_.N.inst.CloseById(p.I.MazeCopyRightPanel)}Close(){_.N.inst.CloseById(p.I.MazeTimeSpaceView)}CloseMapRoom(){_.N.inst.CloseById(p.I.MazeTimeSpaceRoomView)}CloseTimeSpaceMarket(){
_.N.inst.CloseById(p.I.TimeSpaceMarketView)}CloseTimeSpaceResultView(){_.N.inst.CloseById(p.I.MazeTimeSpaceResultView)}CloseRuleView(){_.N.inst.CloseById(p.I.MazeRulePanel)}
ExitCopy(){const t=q.e.Inst_get().GetCurrentPlayRoomData()
if(null==t)return
if(null==t.eventData)return
const e=t.eventData.cfg_get()
if(null!=e)if(1==e.isExist){let i=!0
if(!t.isUnLock){const t=b.o.Inst().getItemById((0,n.aI)(e.copyId))
if(!A.l.IsEmptyStr(t.quitConfirm)){i=!1
const e=new T.B
e.infoId=t.quitConfirm,e.confirmHandle=this.CreateDelegate(this.LeaveCopy),D.t.Inst().Open(e)}}i&&this.LeaveCopy()}else{const t=new T.B
t.infoId="SPACE_MAZE:TIPS3",t.tipstype=1,D.t.Inst().Open(t)}}EnterCopy(){rt.u.Inst_get().EnterCopy(),z.g.Inst_get().EnterCopy()}LeaveCopy(){rt.u.Inst_get().LeaveCopy(),
z.g.Inst_get().LeaveCopy(),q.e.Inst_get().ClearCache(),t.Inst_get().endPos=null,this.CM_LeaveSpaceMaze()}SM_SpaceMazeEnergy(t){
t.energy>q.e.Inst_get().currentEnergy?(q.e.Inst_get().currentEnergy=t.energy,r.i.Inst.RaiseEvent(y.g.MAZE_ADD_ENERGY)):(q.e.Inst_get().currentEnergy=t.energy,
r.i.Inst.RaiseEvent(y.g.MAZE_SUB_ENERGY))
const e=F.M.Inst_get().IsCopyOpen()
H.f.Inst.SetState(N.t.MAZE_SPACE,t.energy>0&&e)}SM_SpaceMazeUpdate(t){const e=q.e.Inst_get().GetRoomDataById(t.spaceMazeId)
e.isFirstUnLock=t.isUnLock&&!e.isUnLock,e.eventData.id=t.eventid,e.eventData.progress=t.progress,e.isUnLock=t.isUnLock,e.isFirstUnLock&&(r.i.Inst.RaiseEvent(y.g.MAZE_ROOM_UNLOCK),
q.e.Inst_get().needToOpenGoblinTip&&this.OpenGoblin())
q.e.Inst_get().GetCurrentPlayRoomData().eventData.cfg_get().type==q.e.NPC&&(q.e.Inst_get().currentShopRoomId=t.spaceMazeId,M.y.Inst.UpdateBtns(null,!0),this.EnterCopy()),
r.i.Inst.RaiseEvent(y.g.MAZE_UPDATE_EVENTDATA,t.spaceMazeId)}ClearShowInfoTipTimer(){this.ShowInfoTipTimer&&(m.C.Inst_get().ClearInterval(this.ShowInfoTipTimer),
this.ShowInfoTipTimer=null)}HandleFirstPanelOpen(t){t?_.N.inst.IsViewShowing(p.I.TimeSpaceMarketView)&&(this.marketstop=!0,
_.N.inst.CloseById(p.I.TimeSpaceMarketView)):this.marketstop&&(this.marketstop=!1,this.OpenTimeSpaceMarket())}DelayShowInfoTip(){const t=new T.B
t.infoId="SPACE_MAZE:TIPS4",t.layer=C.F.Alert,t.confirmText="立即离开",t.confirmHandle=this.CreateDelegate(this.ExitCopy),D.t.Inst().Open(t),this.ShowInfoTipTimer=null}
SM_SpaceMazeInfo(t){const e=0==q.e.Inst_get().currentRoomId
q.e.Inst_get().HandlerRoomMsg(t),r.i.Inst.RaiseEvent(y.g.MAZE_UPDATE_ROOM),e&&(M.y.Inst.UpdateBtns(null,!0),q.e.Inst_get().needToOpenGoblinTip=!0,this.OpenGoblin())}
SM_SpaceMazeReward(t){q.e.Inst_get().resultData=t,this.OpenTimeSpaceResultView()}SM_SpaceMazeEndTip(){const t=new T.B
t.infoId="SPACE_MAZE:TIPS5",t.tipstype=1,t.confirmHandle=this.CreateDelegate(this.LeaveCopy),t.isDoCancleInClose=!0,t.cancelHandle=this.CreateDelegate(this.LeaveCopy),
D.t.Inst().Open(t)}ResetSpaceMaze(){const t=l.Y.Inst.primaryRole,e=f.P.zero_get()
o.X.Inst.PlayElement(a.k.TRANSPORT_MAP_START,t.GetHandle(),0,t.GetPos(),e,0,null),this.ClearResetTimer(),
this.resetTimerid=m.C.Inst_get().SetInterval(this.CreateDelegate(this.CM_ResetSpaceMaze),500)}ClearResetTimer(){
null!=this.resetTimerid&&this.resetTimerid>-1&&(m.C.Inst_get().ClearInterval(this.resetTimerid),this.resetTimerid=-1)}CM_ResetSpaceMaze(){this.ClearResetTimer()
const t=new B.i
u.C.Inst.F_SendMsg(t)}SM_ResetSpaceMaze(){q.e.Inst_get().ClearCache(),q.e.Inst_get().ClearRedPointData(),M.y.Inst.UpdateBtns(null,!0),rt.u.Inst_get().resetCopy=!0}
CM_ChangeSpaceMaze(t,e){const i=new R.F
i.spaceMazeId=t,i.isTransfer=e,u.C.Inst.F_SendMsg(i)}CM_EnterSpaceMaze(t,e){if(L.E.Instance.HasResourceDone()){const i=new G.I
i.type=e,i.rebirth=t,u.C.Inst.F_SendMsg(i)}}CM_LeaveSpaceMaze(){const t=new E.m
u.C.Inst.F_SendMsg(t)}CM_UseDoubleRewardItem(){const t=new x.J
u.C.Inst.F_SendMsg(t)}CM_LeaveGoblinRoom(){const t=new O.S
u.C.Inst.F_SendMsg(t)}OnFirstEnterCopy(t){t==v.e.MazeTimeSpace_START&&(q.e.Inst_get().ruleFirstClose=!0,this.OpenMazeRuleView(),V.X.Inst_get().RaiseEvent(y.g.MULTIPLEHANG_ON))}
PlayMarketCloseEffect(t,e){w.h.Inst_get().PlayFlyItem(t,e,null,null,null,1,1),m.C.Inst_get().SetInterval(this.CreateDelegate(this.OnEndPlayMarketCloseEffect),2e3,1)}
OnEndPlayMarketCloseEffect(){q.e.Inst_get().marketFirstClose=!1,V.X.Inst_get().RaiseEvent(y.g.MULTIPLEHANG_ON)}PlayRuleCloseEffect(t,e){
w.h.Inst_get().PlayFlyItem(t,e,null,null,null,1,1),m.C.Inst_get().SetInterval(this.CreateDelegate(this.OnEndPlayRuleCloseEffect),1e3,1)}OnEndPlayRuleCloseEffect(){
q.e.Inst_get().ruleFirstClose=!1,V.X.Inst_get().RaiseEvent(y.g.MULTIPLEHANG_ON)}IsInMazeCopy(){const t=d.b.Inst.GetCurMap()
return null!=t&&t.controllerType==h.N.SPACE_MAZE}SM_SpaceMazeRedPoint(t){for(let e=0;e<=t.labels.Count()-1;e++)q.e.Inst_get().AddRedPointData(t.type,t.rebirth,t.labels[e])
V.X.Inst_get().RaiseEvent(y.g.MULTIPLEHANG_ON)}CM_ClickRedPoint(t,e,i){const s=new P.T
s.type=t,s.rebirth=e,s.label=i,q.e.Inst_get().AddRedPointData(t,e,i),u.C.Inst.F_SendMsg(s),M.y.Inst.UpdateBtns(d.b.Inst.currentMapId_get(),!0)}OpenGoblin(){
const t=q.e.Inst_get().GetCurrentPlayRoomData()
null!=t&&t.isUnLock&&(q.e.Inst_get().needToOpenGoblinTip=!1,Y.N.Inst_get().ShowTipsAfterMaze_Special())}OpenResetPanel(){const t=new I.v
t.isShowMask=!0,t.viewClass=Jt,_.N.inst.OpenById(p.I.MazeTimeSpaceResetPanel,null,null,t)}CM_SumReward(){const t=new k.j
u.C.Inst.F_SendMsg(t)}SM_SumMazeRoomRewardHandler(t){q.e.Inst_get().sumRoomReward=t,this.OpenResetPanel()}},oe.inst=null,ue=ae=oe,me="Inst_get",Ie=[s.n],
ge=Object.getOwnPropertyDescriptor(ae,"Inst_get"),_e=ae,pe={},Object.keys(ge).forEach((function(t){pe[t]=ge[t]})),pe.enumerable=!!pe.enumerable,pe.configurable=!!pe.configurable,
("value"in pe||pe.initializer)&&(pe.writable=!0),pe=Ie.slice().reverse().reduce((function(t,e){return e(ue,me,t)||t}),pe),
_e&&void 0!==pe.initializer&&(pe.value=pe.initializer?pe.initializer.call(_e):void 0,pe.initializer=void 0),void 0===pe.initializer&&(Object.defineProperty(ue,me,pe),pe=null),ae)
var ue,me,Ie,ge,_e,pe},94075:(t,e,i)=>{i.d(e,{u:()=>R})
var s=i(32076),n=i(80812),l=i(98800),a=i(96098),o=i(73705),r=i(73206),h=i(97461),d=i(5924),c=i(18202),u=i(52726),m=i(60130),I=i(85602),g=i(79534),_=i(70850),p=i(92679),C=i(74045),S=i(49067),f=i(48933),y=i(8211),w=i(21334),D=i(65180),T=i(68404),A=i(99294),v=i(93877),L=i(13113)
class M extends T.B{constructor(...t){super(...t),this.energyCostLabel=null,this.container=null,this.nameLabel=null,this.prefixContainer=null}InitView(){super.InitView(),
this.energyCostLabel=this.CreateComponent(v.Q,1),this.container=this.CreateComponent(A.z,2),this.nameLabel=this.CreateComponent(A.z,3),
this.prefixContainer=this.CreateComponent(L.T,4),this.Reshow()}SetData(t){if(t.isUnLock)this.nameLabel.SetActive(!0),this.container.SetActive(!1)
else{this.nameLabel.SetActive(!1),this.container.SetActive(!0),this.energyCostLabel.textSet(`传送阵([5FB470]-${D.e.Inst_get().costEnergy}[-]`)
const t=(this.energyCostLabel.width()+30)/2,e=this.container.GetLocalPosition()
e.x=-t,this.container.SetLocalPosition(e)
const i=this.prefixContainer.GetLocalPosition()
i.x=this.energyCostLabel.width()+5,this.prefixContainer.SetLocalPosition(i)}}Clear(){super.Clear()}Destroy(){c.g.DestroyUIObj(),super.Destroy()}}var b=i(66988)
class R{constructor(){this.currentTransportRoomData=null,this.transport=!1,this.transportList=null,this._transportName=null,this._openEffectElementIds=null,
this.openEffectTimeId=-1,this._enabled=!0,this._playerPos=null,this.nameAssetLoaded=!1,this.loadFatherId=null,this.initLightPillar=!1,this.resetCopy=!0,this.transportList=new I.Z,
this._transportName=new I.Z,this._openEffectElementIds=new I.Z,this._playerPos=new g.P,h.i.Inst.AddEventHandler(p.g.PLAY_END_TRANSPORT,(0,s.v)(this.OnPlayEndTransport,this)),
h.i.Inst.AddEventHandler(p.g.MAZE_UPDATE_EVENTDATA,(0,s.v)(this.OnRoomDataUpdate,this)),h.i.Inst.AddEventHandler(p.g.MAZE_UPDATE_ROOM,(0,s.v)(this.OnRoomInfoUpdate,this))}
static Inst_get(){return null==R.inst&&(R.inst=new R),R.inst}Enabled_Set(t){this._enabled=t}EnterCopy(){}LeaveCopy(){this.DestroyTransport()
for(let t=0;t<=this._openEffectElementIds.Count()-1;t++)r.X.Inst.DeleteElement(this._openEffectElementIds[t])
this.nameAssetLoaded=!1,c.g.Unload((0,s.v)(this.OnLoadedTransportName,this)),this.initLightPillar=!1}OnPlayerMove(){if(0!=D.e.Inst_get().currentRoomId){if(!this._enabled)return
l.Y.Inst.primaryRole.MainRole_get().GetPosValue(this._playerPos)
const t=D.e.Inst_get().GetCurrentPlayRoomData()
for(let e=0;e<=this.transportList.Count()-1;e++){const i=this.transportList[e]
if(i.isShow_get()&&i.IsMapPointTransport(this._playerPos,1)){const s=t.GetNearRoomData(e+1)
if(!s.isUnLock&&D.e.Inst_get().currentEnergy<D.e.Inst_get().costEnergy){const t=D.e.Inst_get().GetRoomDataById(D.e.Inst_get().currentShopRoomId)
if(t){const e=12056
let i=null
const s=t.eventData.cfg_get(),n=y.N.GetInst().GetMazeVoes(s.id)
for(let t=0;t<=n.Count()-1;t++){const s=n[t]
if(s.Cfg_get().itemId==e){i=s
break}}if(null==i)return
_.g.Inst_get().GetItemNum(e)>0||i.GetShowRemainTime()>0?b.G.Inst_get().OpenGetEnergyView():this.ShowEnergyInfoTip()}else this.ShowEnergyInfoTip()
return}this.transport=!0,this.currentTransportRoomData=s,a.B.Inst.PlayTransportEffect(i.Cfg_get(),a.B.TYPE_FROM_NOMOVE)
break}}}}ShowEnergyInfoTip(){const t=new S.B
t.infoId="SPACE_MAZE:TIPS4",t.layer=u.F.Alert,t.confirmText="立即离开",t.confirmHandle=(0,s.v)(this.ExitCopy,this),C.t.Inst().Open(t)}ExitCopy(){b.G.Inst_get().ExitCopy()}
OnRoomDataUpdate(){const t=D.e.Inst_get().GetCurrentPlayRoomData()
t.isFirstUnLock?(t.isFirstUnLock=!1,this.PlayOpenTransportEffect()):this.UpdateTransport()}PlayOpenTransportEffect(){
1==D.e.Inst_get().GetCurrentPlayRoomData().type?(this.PlayOneOpenEffect(6001,1),this.PlayOneOpenEffect(6002,2),this.PlayOneOpenEffect(6003,3),
this.PlayOneOpenEffect(6004,4)):(this.PlayOneOpenEffect(6011,1),this.PlayOneOpenEffect(6012,2),this.PlayOneOpenEffect(6013,3),this.PlayOneOpenEffect(6014,4)),this.ClearOpenTime(),
this.openEffectTimeId=d.C.Inst_get().SetInterval((0,s.v)(this.OnOpenEffectEnd,this),450,1)}PlayOneOpenEffect(t,e){const i=D.e.Inst_get().GetCurrentPlayRoomData()
if(i.CheckHasLink(e,!1)){const s=l.Y.Inst.PrimaryRole_get(),n=w.p.Inst_get().transportDic_get()[t],a=g.P.zero_get()
f.I.calVec3.Set(n.belongPosX,3,n.belongPosY)
let o=200027301
1==i.GetNearRoomData(e).cfg_get().type&&(o=200027302)
const h=r.X.Inst.PlayElement(o,s.GetHandle(),0,f.I.calVec3,a,0)
this._openEffectElementIds.Add(h)}}OnOpenEffectEnd(){this.ClearTransportOpenEffect(),this.UpdateTransport()}OnRoomInfoUpdate(){this.UpdateTransport(),
(this.transport||this.resetCopy)&&(this.transport=!1,this.resetCopy=!1,l.Y.Inst.PrimaryRole_get().SetShow(!0),a.B.Inst.OnDlayPlayEnd(!0))}UpdateTransport(){
const t=D.e.Inst_get().GetCurrentPlayRoomData()
if(t.isUnLock){if(0==this.transportList.Count()){const e=w.p.Inst_get().transportDic_get(),i=new I.Z
1==t.type?(i.Add(e[6001]),i.Add(e[6002]),i.Add(e[6003]),i.Add(e[6004])):(i.Add(e[6011]),i.Add(e[6012]),i.Add(e[6013]),i.Add(e[6014]))
for(let t=0;t<=i.Count()-1;t++){const e=new o.B
e.InitByCfg(i[t]),this.transportList.Add(e)}}this.transportList[0].SetShow(t.CheckHasLink(1,!1)),this.transportList[1].SetShow(t.CheckHasLink(2,!1)),
this.transportList[2].SetShow(t.CheckHasLink(3,!1)),this.transportList[3].SetShow(t.CheckHasLink(4,!1)),0==this._transportName.Count()?c.g.LoadOne("ui_maze_transport_name",(0,
s.v)(this.OnLoadedTransportName,this)):this.UpdateTransportName()}else{for(let t=0;t<=this.transportList.Count()-1;t++)this.transportList[t].SetShow(!1)
this.UpdateTransportName()}}UpdateTransportName(){if(0==this._transportName.Count()){const t=b.G.Inst_get().copyInfoView
if(!this.nameAssetLoaded||null==t||0==this.transportList.Count())return
let e=new M
e.setId(this.loadFatherId,null,0),this._transportName.Add(e),this.loadFatherId=null
for(let t=1;t<=3;t++){const t=c.g.GetResFindId("ui_maze_transport_name")
e=new M,e.setId(t,null,0),this._transportName.Add(e)}this.UpdateNamePos()}const t=D.e.Inst_get().GetCurrentPlayRoomData()
for(let e=0;e<=this.transportList.Count()-1;e++){this.transportList[e].isShow_get()?(this._transportName[e].node.SetActive(!0),
this._transportName[e].SetData(t.GetNearRoomData(e+1))):this._transportName[e].node.SetActive(!1)}}ShowLightPillar(){this.initLightPillar||(this.initLightPillar=!0,
f.I.cal2Vec3.Set(13,27),f.I.cal2Vec2.Set(11.7-f.I.cal2Vec3.x,25.6-f.I.cal2Vec3.y),f.I.cal2Vec2.SetNormalize(),this.CreateLightPillar(f.I.cal2Vec2,f.I.cal2Vec3),
f.I.cal2Vec3.Set(23.5,24.1),f.I.cal2Vec2.Set(22.1-f.I.cal2Vec3.x,25.6-f.I.cal2Vec3.y),f.I.cal2Vec2.SetNormalize(),this.CreateLightPillar(f.I.cal2Vec2,f.I.cal2Vec3),
f.I.cal2Vec3.Set(20.8,14.5),f.I.cal2Vec2.Set(23-f.I.cal2Vec3.x,16.8-f.I.cal2Vec3.y),f.I.cal2Vec2.SetNormalize(),this.CreateLightPillar(f.I.cal2Vec2,f.I.cal2Vec3),
f.I.cal2Vec3.Set(9.8,17),f.I.cal2Vec2.Set(12.6-f.I.cal2Vec3.x,14.1-f.I.cal2Vec3.y),f.I.cal2Vec2.SetNormalize(),this.CreateLightPillar(f.I.cal2Vec2,f.I.cal2Vec3))}
CreateLightPillar(t,e){for(let i=0;i<=3;i++){const s=e.x+t.x*i*1.5,l=e.y+t.y*i*1.5
n.O.Inst_get().CreateFlagObjectByRId(2090010016,s,l,0)}}RemoveLightPillar(){this.initLightPillar=!1,n.O.Inst_get().RemoveAllList()}OnLoadedTransportName(t){this.nameAssetLoaded=!0,
this.loadFatherId=t[0],this.UpdateTransportName()}UpdateNamePos(){for(let t=0;t<=this.transportList.Count()-1;t++){const e=this._transportName[t]
if(null!=e){if(this.transportList[t].isShow_get()){const i=this.transportList[t].Cfg_get()
m.O.WorldToUILocalPosInHeadPanel(i.belongPosX,5,i.belongPosY,e.node.transform)}}}}OnPlayEndTransport(){
null!=this.currentTransportRoomData&&b.G.Inst_get().CM_ChangeSpaceMaze(this.currentTransportRoomData.id,!0)}ClearTransportOpenEffect(){
for(let t=0;t<=this._openEffectElementIds.Count()-1;t++)r.X.Inst.DeleteElement(this._openEffectElementIds[t])
this._openEffectElementIds.Clear()}ClearOpenTime(){d.C.Inst_get().ClearInterval(this.openEffectTimeId),this.openEffectTimeId=-1}DestroyTransport(){
for(let t=0;t<=this.transportList.Count()-1;t++)this.transportList[t].Destroy()
for(let t=0;t<=this._transportName.Count()-1;t++)this._transportName[t].Clear(),this._transportName[t].Destroy()
this.ClearTransportOpenEffect(),this._transportName.Clear(),this.transportList.Clear(),this.ClearOpenTime(),this.currentTransportRoomData=null}}R.inst=null},75128:(t,e,i)=>{i.d(e,{
g:()=>P})
var s=i(38836),n=i(38962),l=i(65180),a=i(98800),o=i(57121),r=i(97461),h=i(5924),d=i(79534),c=i(92679),u=i(94075)
class m{EnterCopy(){}LeaveCopy(){}Enter(){}Leave(){}}class I extends m{constructor(){super(),this._playerPos=null,this.timerId=-1,this._playerPos=new d.P}Enter(){
r.i.Inst.AddEventHandler(c.g.ADD_DROP,this.CreateDelegate(this.OnDrop)),o.M.Inst.hasCanPick_get()?this.OnDrop():u.u.Inst_get().Enabled_Set(!0)}Leave(){
r.i.Inst.RemoveEventHandler(c.g.ADD_DROP,this.CreateDelegate(this.OnDrop)),this.ClearTime(),u.u.Inst_get().Enabled_Set(!0)}OnDrop(){
-1==this.timerId&&(u.u.Inst_get().Enabled_Set(!1),this.timerId=h.C.Inst_get().SetFrameLoop(this.CreateDelegate(this.OnLoopCheckPickUp),1))}OnLoopCheckPickUp(){
if(!o.M.Inst.hasCanPick_get()){if(null==a.Y.Inst.primaryRole)return
this.ClearTime(),a.Y.Inst.primaryRole.MainRole_get().GetPosValue(this._playerPos)
const t=u.u.Inst_get().transportList
for(let e=0;e<=t.Count()-1;e++){const i=t[e]
if(i.isShow_get()&&i.IsMapPointTransport(this._playerPos,1)){
0==e?a.Y.Inst.primaryRole.SetPosXYZ(12.7,26.1):1==e?a.Y.Inst.primaryRole.SetPosXYZ(21.2,24.8):2==e?a.Y.Inst.primaryRole.SetPosXYZ(20.9,16.4):3==e&&a.Y.Inst.primaryRole.SetPosXYZ(13.3,15.5)
break}}u.u.Inst_get().Enabled_Set(!0)}}ClearTime(){h.C.Inst_get().ClearInterval(this.timerId),this.timerId=-1}}class g extends I{}
var _=i(38045),p=i(65227),C=i(73206),S=i(62370),f=i(98885),y=i(24524),w=i(75439)
class D extends I{constructor(...t){super(...t),this.unOpenElementID=-1}Enter(){super.Enter(),r.i.Inst.AddEventHandler(c.g.REMOVE_COLLECT,this.CreateDelegate(this.OnDropPickOver)),
r.i.Inst.AddEventHandler(c.g.ADD_COLLECT,this.CreateDelegate(this.UpdateCollectState)),this.UpdateCollectState()}Leave(){super.Leave(),
r.i.Inst.RemoveEventHandler(c.g.REMOVE_COLLECT,this.CreateDelegate(this.OnDropPickOver)),r.i.Inst.RemoveEventHandler(c.g.ADD_COLLECT,this.CreateDelegate(this.UpdateCollectState)),
this.ClearEffect()}UpdateCollectState(){let t=null
for(const[e,i]of(0,s.V5)(a.Y.CollectDic)){t=i
break}if(null==t)return
if(l.e.Inst_get().GetCurrentPlayRoomData().isUnLock||!t.m_state)this.ClearEffect(),t.MainRole_get().PassEvent(p.o.dead)
else{if(-1!=this.unOpenElementID)return
const e=t.Cfg_get()
let i=0
202136500==e.resourceId?i=10005e4:202136600==e.resourceId&&(i=100049900),this.unOpenElementID=C.X.Inst.PlayElement(i,t.GetHandle(),0,t.GetPos(),d.P.zero_get(),t.GetDirection()-90)}
}ClearEffect(){-1!=this.unOpenElementID&&(C.X.Inst.DeleteElement(this.unOpenElementID),this.unOpenElementID=-1)}OnDropPickOver(t){
const e=l.e.Inst_get().GetCurrentPlayRoomData().eventData.cfg_get(),i=t.Cfg_get(),s=y.o.Inst().getItemById((0,_.aI)(e.copyId))
if((0,_.aI)(s.mapId)!=i.mapId)return
const n=d.P.zero_get()
let a
const o=w.D.getInstance().GetStringArray("SPACEMAZE:GIFTBOX_EFFECT")
for(let t=0;t<=o.Count()-1;t++){let e=f.M.Replace(o[t],'"',"")
e=f.M.Split(e,S.o.s_Arr_UNDER_CHAR_DOT)
const s=(0,_.aI)(e[0])
if(i.resourceId==s){a=(0,_.aI)(e[1])
break}}t.m_state=!1,C.X.Inst.PlayElement(a,t.GetHandle(),0,t.GetPos(),n,t.GetDirection()-90),t.MainRole_get().PassEvent(p.o.open,this.CreateDelegate(this.UpdateCollectState))}}
var T=i(66988)
class A extends m{constructor(...t){super(...t),this.collectObject=null}Enter(){r.i.Inst.AddEventHandler(c.g.REMOVE_COLLECT,this.CreateDelegate(this.OnDropPickOver)),
r.i.Inst.AddEventHandler(c.g.ADD_COLLECT,this.CreateDelegate(this.UpdateCollectState)),this.UpdateCollectState()}Leave(){
r.i.Inst.RemoveEventHandler(c.g.REMOVE_COLLECT,this.CreateDelegate(this.OnDropPickOver)),r.i.Inst.RemoveEventHandler(c.g.ADD_COLLECT,this.CreateDelegate(this.UpdateCollectState)),
this.collectObject=null}UpdateCollectState(){for(const[t,e]of(0,s.V5)(a.Y.CollectDic)){this.collectObject=e,e.m_state?this.PlayUnLockState(e):this.PlayDeathState(e)
break}}OnDropPickOver(t){this.collectObject.m_state=!1,T.G.Inst_get().copyInfoView.energyDropObjGet(this.collectObject),this.PlayCollectOver()}PlayUnLockState(){
this.PlayEffect(200027305,p.o.skill1,this.CreateDelegate(this.PlayUnLockState2))}PlayDeathState(){this.PlayEffect(200027303,p.o.dead)}PlayCollectOver(){
this.PlayEffect(200027306,p.o.skill2,this.CreateDelegate(this.PlayDeathState))}PlayUnLockState2(){this.PlayEffect(200027304,p.o.stand)}PlayEffect(t,e,i){
this.collectObject.MainRole_get().PassEvent(e,i)
const s=this.collectObject.GetPos()
C.X.Inst.PlayElement(t,this.collectObject.GetHandle(),0,s,d.P.zero_get())}}class v extends m{Enter(){
r.i.Inst.AddEventHandler(c.g.UPDATE_MONSTER_COUNT,this.CreateDelegate(this.GoblinMonsterAdd)),this.GoblinMonsterAdd()}Leave(){
r.i.Inst.RemoveEventHandler(c.g.UPDATE_MONSTER_COUNT,this.CreateDelegate(this.GoblinMonsterAdd))}GoblinMonsterAdd(){let t=null
for(const[e,i]of(0,s.V5)(a.Y.MonsterDic))t=i
null!=t&&C.X.Inst.PlayElement(200027302,t.GetHandle(),0,t.GetPos(),d.P.zero_get())}}class L extends I{}var M=i(77697)
class b extends m{constructor(...t){super(...t),this.npcId=-1}Enter(){super.Enter()
const t=l.e.Inst_get().GetCurrentPlayRoomData().eventData.cfg_get()
this.npcId=(0,_.aI)(t.param.value)
const e=M.f.Inst().getItemById(this.npcId)
a.Y.Inst.CreateNPCByCfg(e)}Leave(){super.Leave(),a.Y.Inst.deleteNPC(this.npcId),this.npcId=-1}}class R extends m{}class P{constructor(){this.eventDict=null,this.currentEvent=null,
this.isEnterCopy=!1,this.eventDict=new n.X}static Inst_get(){return null==P.inst&&(P.inst=new P),P.inst}EnterCopy(){this.isEnterCopy=!0,this.eventDict.LuaDic_AddOrSetItem(1,new g),
this.eventDict.LuaDic_AddOrSetItem(2,new L),this.eventDict.LuaDic_AddOrSetItem(3,new A),this.eventDict.LuaDic_AddOrSetItem(4,new b),this.eventDict.LuaDic_AddOrSetItem(5,new v),
this.eventDict.LuaDic_AddOrSetItem(6,new R),this.eventDict.LuaDic_AddOrSetItem(7,new D)
for(const[t,e]of(0,s.V5)(this.eventDict))e.EnterCopy()
null!=l.e.Inst_get().GetCurrentPlayRoomData()&&this.SwitchRoom()}LeaveCopy(){for(const[t,e]of(0,s.V5)(this.eventDict))e.LeaveCopy()
this.eventDict.Clear(),this.isEnterCopy=!1,null!=this.currentEvent&&this.currentEvent.Leave(),this.currentEvent=null}SwitchRoom(){if(!this.isEnterCopy)return
null!=this.currentEvent&&this.currentEvent.Leave()
const t=l.e.Inst_get().GetCurrentPlayRoomData()
this.currentEvent=this.eventDict.LuaDic_GetItem(t.eventData.cfg_get().type),this.currentEvent.Enter()}}P.inst=null},92916:(t,e,i)=>{i.d(e,{q:()=>u})
var s=i(52880),n=i(97461),l=i(16812),a=i(92679),o=i(28613),r=i(11380),h=i(60647),d=i(13487),c=i(65180)
class u extends l.k{constructor(){super(),this.newHand2=0,this.lastRoomType=0,n.i.Inst.AddEventHandler(a.g.GUIDE_FINISH_GROUP,this.CreateDelegate(this.GuideHandler))}
static Inst_get(){return null==u._inst&&(u._inst=new u),u._inst}GuideHandler(t){}CreateRoute(t){s.o.Inst_get().CreateFlagRoute(t)}ClearRound(){s.o.Inst_get().clearRound(),
s.o.Inst_get().clearStage()}CheckGuide(){const t=c.e.Inst_get().GetCurrentPlayRoomData()
1==t.cfg_get().newHand&&null!=t&&(1==t.cfg_get().newHand2?this.lastRoomType==t.cfg_get().type&&2==this.newHand2?this.CheckGuideLeaveTwo():r.l.Instance.HadTriggerGuide(160001)||(this.IsReCord(d.R.MAZE_TIMESPACE_START)?n.i.Inst.RaiseEvent(a.g.GUIDE_EVENT,o.e.MazeTimeSpace_START_CLOSE_UI):(this.ReCord(d.R.MAZE_TIMESPACE_START),
n.i.Inst.RaiseEvent(a.g.GUIDE_EVENT,o.e.MazeTimeSpace_START))):2==t.cfg_get().newHand2?this.CheckGuideTwo():this.CheckGuideLeaveTwo(),this.lastRoomType=t.cfg_get().type,
this.newHand2=t.cfg_get().newHand2)}GuideParam(){const t=c.e.Inst_get().GetCurrentPlayRoomData().cfg_get()
return 0==t.newHand2?t.type:10*t.type+t.newHand2}CheckGuideTwo(){
null!=c.e.Inst_get().GetCurrentPlayRoomData()&&(this.IsReCord(d.R.MAZE_TIMESPACE_START_2)||(r.l.Instance.HadTriggerGuide(160011)||this.ReCord(d.R.MAZE_TIMESPACE_START_2),
n.i.Inst.RaiseEvent(a.g.GUIDE_EVENT,o.e.MazeTimeSpace_START_2)))}CheckGuideLeaveTwo(){
null!=c.e.Inst_get().GetCurrentPlayRoomData()&&(this.IsReCord(d.R.MAZE_TIMESPACE_COLLECT_LEVAE_2)||(this.ReCord(d.R.MAZE_TIMESPACE_COLLECT_LEVAE_2),
n.i.Inst.RaiseEvent(a.g.GUIDE_EVENT,o.e.MazeTimeSpace_LEVAE_2)))}CheckKillBoss(){const t=c.e.Inst_get().GetCurrentPlayRoomData()
null!=t&&1==t.cfg_get().newHand&&(this.IsReCord(d.R.MAZE_TIMESPACE_KILL_BOSS_FIRST)||(this.ReCord(d.R.MAZE_TIMESPACE_KILL_BOSS_FIRST),
n.i.Inst.RaiseEvent(a.g.GUIDE_EVENT,o.e.MazeTimeSpace_KILL_BOSS_FIRST)))}CheckGuideKillAllBoss(){const t=c.e.Inst_get().GetCurrentPlayRoomData()
null!=t&&1==t.cfg_get().newHand&&(this.IsReCord(d.R.MAZE_TIMESPACE_KILL_ALL_BOSS_FIRST)||(this.ReCord(d.R.MAZE_TIMESPACE_KILL_ALL_BOSS_FIRST),
n.i.Inst.RaiseEvent(a.g.GUIDE_EVENT,o.e.MazeTimeSpace_KILL_ALL_BOSS_FIRST)))}CheckGuideCloseMazeTimeRule(){const t=c.e.Inst_get().GetCurrentPlayRoomData()
null!=t&&1==t.cfg_get().newHand&&(r.l.Instance.HadTriggerGuide(160001)||n.i.Inst.RaiseEvent(a.g.GUIDE_EVENT,o.e.MazeTimeSpace_START_CLOSE_UI))}CheckGuideCollect(){
const t=c.e.Inst_get().GetCurrentPlayRoomData()
null!=t&&1==t.cfg_get().newHand&&n.i.Inst.RaiseEvent(a.g.GUIDE_EVENT,o.e.MazeTimeSpace_COLLECT_END)}IsReCord(t){const e=h.p.inst.GetClientLogicSetting(t)
return null!=e&&e>0}ReCord(t){h.p.inst.SendClientLogicSetting(t,10,!1)}}u._inst=null},65180:(t,e,i)=>{i.d(e,{e:()=>A})
var s=i(38836),n=i(38045),l=i(98800),a=i(97461),o=i(62370),r=i(98130),h=i(98885),d=i(85602),c=i(38962),u=i(92679),m=i(73865),I=i(75439),g=i(66399),_=i(10509),p=i(8211),C=i(74657),S=i(67642),f=i(94075),y=i(75128)
class w{constructor(t){this.id=null,this.isUnLock=!1,this.isFirstUnLock=!1,this.eventData=null,this.progress=0,this.type=0,this.id=t}cfg_get(){return g.A.GetInst().GetCfg(this.id)}
CanEnter(){return!!this.isUnLock||(!!this.CheckHasLink(1)||(!!this.CheckHasLink(2)||(!!this.CheckHasLink(3)||!!this.CheckHasLink(4))))}CheckHasLink(t,e){let i,s
null==e&&(e=!0),1==t?(i=1,s=3):2==t?(i=2,s=4):3==t?(i=3,s=1):4==t&&(i=4,s=2)
const n=this.GetNearRoomData(t)
if(null!=n){if(1==this.cfg_get().link[i]||1==n.cfg_get().link[s]){if(this.isUnLock)return!0
if(!e)return!0
if(n.isUnLock)return!0}}return!1}GetNearRoomData(t){const e=this.cfg_get()
if(null==e.location||e.location.length<=0)return null
const i=e.location[1],s=e.location[2]
let n,l
return 1==t?(n=i-1,l=s):2==t?(n=i,l=s-1):3==t?(n=i+1,l=s):4==t&&(n=i,l=s+1),A.Inst_get().GetRoomData(e.rebirth,e.type,n,l)}}class D{constructor(){this.id=null,this.progress=0}
cfg_get(){return g.A.GetInst().GetEventCfg(this.id)}}var T=i(92916)
class A{constructor(){this.maxEnergy=null,this.costEnergy=null,this.currentEnergy=0,this.resultData=null,this.isClickedBossIcon=!1,this.marketFirstClose=!1,
this.currentShopRoomId=-1,this.ruleFirstClose=!1,this.currentRoomId=0,this.prevRoomId=0,this.needToOpenGoblinTip=!1,this.needToOpenEnergy=!0,this.defaultSelectIndex=-1,
this.currentRoomType=0,this.roomDict=null,this.roomIdDict=null,this.typeCoordDict=null,this.marketRedPoint=null,this.sumRoomReward=null
let t=I.D.getInstance().GetStringValue("SPACEMAZE:ENERGY")
t=h.M.Split(t,o.o.s_Arr_UNDER_CHAR_DOT),this.maxEnergy=(0,n.aI)(t[1]),this.costEnergy=(0,n.aI)(t[0]),this.roomDict=new c.X,this.roomIdDict=new c.X,this.typeCoordDict=new c.X,
this.marketRedPoint=new c.X}static Inst_get(){return null==A.inst&&(A.inst=new A),A.inst}GetRoomDataList(t,e){const i=`${e}_${t}`
return this.roomDict.LuaDic_GetItem(i)}GetRoomData(t,e,i,s){const n=`${t}_${e}_${i}_${s}`
return this.typeCoordDict.LuaDic_GetItem(n)}GetRoomDataById(t){return this.roomIdDict.LuaDic_GetItem(t)}GetCurrentPlayRoomData(t){if(0==this.currentRoomId)return null
if(null==t&&(t=!0),t)return this.GetRoomDataById(this.currentRoomId)
const e=this.GetRoomDataById(this.currentRoomId)
return 2==e.cfg_get().start?this.GetRoomDataById(this.prevRoomId):e}NeedShowShopBtn(){return-1!=this.currentShopRoomId&&this.GetRoomDataById(this.currentShopRoomId).isUnLock}
CalculationEventData(t,e,i){const s=this.GetRoomDataList(e,t)
let l=0,a=0
for(let t=0;t<=s.Count()-1;t++){const e=s[t]
if(null!=e.eventData){const t=e.eventData,s=t.cfg_get()
this.IsTypeAdapt(i,s.type)&&null!=s.completeCond&&s.completeCond.length>0&&(l+=t.progress,a+=(0,n.aI)(s.completeCond[1].value))}}return[l,a]}IsTypeAdapt(t,e){
return t==A.ATTACK_BOSS?e==t||e==A.NPC:e==t}CalcLevelAndExp(t,e,i){
const s=new d.Z,n=l.Y.Inst.m_primaryRoleInfo.Level_get(),a=l.Y.Inst.m_primaryRoleInfo.CurMaxExp_get(),o=l.Y.Inst.m_primaryRoleInfo.Exp_get()
if(0==n-t)s[0]=0,s[1]=r.GF.INT(i/a*100)
else{let l=0
const h=t+l,d=e/_.L.Inst().getItemById(t).exp*100,c=o.ToNum()/a*100
s[1]=c-d
let u=i+e
for(;h<=n;){if(u-=_.L.Inst().getItemById(t).exp,u<0)break
l+=1}s[0]=l,s[1]=r.GF.INT(s[1])}return s}HandlerRoomMsg(t){const e=this.currentRoomId
this.ClearCache(),this.currentRoomId=t.nowSpaceMazeId,this.prevRoomId=t.lastSpaceMazeId
const i=g.A.GetInst().GetCfg(t.nowSpaceMazeId),s=i.type,n=i.rebirth
this.currentRoomType=s
const l=g.A.GetInst().GetRoomList(s,n),o=`${n}_${s}`
let r=this.roomDict.LuaDic_GetItem(o)
null==r&&(r=new d.Z,this.roomDict.LuaDic_AddOrSetItem(o,r))
let h=!1
for(let e=0;e<=l.Count()-1;e++){const s=l[e]
if(i.newHand==s.newHand){let e=null
for(let i=0;i<=t.spaceMazeList.Count()-1;i++)if(s.id==t.spaceMazeList[i].spaceMazeId){e=t.spaceMazeList[i]
break}let i=this.roomIdDict.LuaDic_GetItem(s.id)
null==i&&(i=new w(s.id),r.Add(i),2!=s.start&&this.typeCoordDict.LuaDic_AddOrSetItem(`${s.rebirth}_${s.type}_${s.location[1]}_${s.location[2]}`,i),
this.roomIdDict.LuaDic_AddOrSetItem(s.id,i)),null!=e&&(null==i.eventData&&(i.eventData=new D),i.eventData.id=e.eventId,i.eventData.progress=e.progress,i.isUnLock=e.isUnLock,
4==i.eventData.cfg_get().type&&(this.marketFirstClose=!i.isUnLock,this.currentShopRoomId=i.id,h=!0))}}h&&m.y.Inst.UpdateBtns(null,!0),T.q.Inst_get().CheckGuide(this.currentRoomId),
a.i.Inst.RaiseEvent(u.g.MAZE_TIME_SPACE_ROOM_UPDATE),this.currentRoomId!=e&&y.g.Inst_get().SwitchRoom()}AddRedPointData(t,e,i){const s=`${t}_${e}`
let n=this.marketRedPoint.LuaDic_GetItem(s)
null==n&&(n=new d.Z,this.marketRedPoint.LuaDic_AddOrSetItem(s,n)),n.Add(i)}HadRedPoint(t,e,i=null){const s=`${t}_${e}`,n=this.marketRedPoint.LuaDic_GetItem(s)
if(null!=n){if(null==i){const t=this.GetRoomDataById(this.currentShopRoomId)
if(null!=t){const e=t.eventData.cfg_get(),i=p.N.GetInst().GetMazeVoes(e.id)
for(let t=0;t<=i.Count()-1;t++)if(!n.Contains(i[t].Cfg_get().subLabelId))return!0}return!1}return!n.Contains(i)}return!0}GetEveryEnergyGetValue(){
return C.A.GetReward("SPACEMAZE_ENERGY").rewardValues_get().rewardValues[0].value}GetGatherReses(){const t=S.S.CreateTableArr(8,0)
let e=0
for(const[i,n]of(0,s.vy)(this.roomIdDict)){e=-1
const i=n.eventData.cfg_get()
if(null!=i&&null!=i.completeCond[1]){const t=i.completeCond[1].boxType
"gold"==t?e=0:"silver"==t?e=2:"spring"==t&&(e=4)}e>-1&&(t[e]=null==t[e]?1:t[e]+1),i.type!=A.GOBLIN&&(n.isUnLock&&(e>-1&&(t[e+1]=null==t[e+1]?1:t[e+1]+1),t[7]=null==t[7]?1:t[7]+1),
t[6]=null==t[6]?1:t[6]+1)}return t}ClearRedPointData(){this.marketRedPoint.Clear()}ClearCache(){this.roomIdDict.Clear(),this.roomDict.Clear(),this.typeCoordDict.Clear(),
this.resultData=null,this.currentRoomId=0,this.marketFirstClose=!1,this.currentShopRoomId=-1,this.needToOpenGoblinTip=!1,this.sumRoomReward=null}Clear(){this.ClearCache(),
this.ClearRedPointData(),this.isClickedBossIcon=!1,this.currentEnergy=0,this.defaultSelectIndex=-1,f.u.Inst_get().initLightPillar=!1,y.g.Inst_get().LeaveCopy()}}A.inst=null,
A.ATTACK_BOSS=1,A.NPC=4,A.GOBLIN=5},9182:(t,e,i)=>{i.d(e,{I:()=>b})
var s=i(38836),n=i(99294),l=i(8889),a=i(13113),o=i(61911),r=i(18202),h=i(85602),d=i(38962),c=i(92679),u=i(65550),m=i(66988),I=i(65180),g=i(51868)
class _ extends g.${InitView(){super.InitView()}Clear(){super.Clear()}Destroy(){super.Destroy(),r.g.DestroyUIObj()}Test1(){return!0}S_Test(){return!0}}
var p=i(5924),C=i(43133),S=i(72005),f=i(85682),y=i(79534),w=i(48933),D=i(75439),T=i(68637),A=i(50679)
class v extends o.f{constructor(...t){super(...t),this.stateBg=null,this.icon=null,this.lockStateBg=null,this.currentBg=null,this.clickHandler=null,this.data=null,this.effect=null,
this.timerId=-1,this.boxCollider=null,this.showGuide=null,this.isMinMap=null,this.bossGuideId=null,this.guideId=null}InitView(){super.InitView(),
this.stateBg=this.CreateComponent(S.w,1),this.icon=this.CreateComponent(S.w,2),this.lockStateBg=this.CreateComponent(S.w,3),this.currentBg=this.CreateComponent(n.z,4),
this.boxCollider=this.CreateComponent(C.V,5),this.showGuide=!1}SetData(t,e){this.data=t,this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.OnClickItem)),
this.isMinMap=e,this.boxCollider.SetColliderEnable(!e),this.ClearTime()
const i=t.eventData.cfg_get()
let s=""
this.bossGuideId=null,s=1==i.type||i.type==I.e.NPC?"rymwfy_bt_0013":"rymwfy_bt_0009",this.stateBg.spriteNameSet(s),
t.isUnLock?this.lockStateBg.node.SetActive(!1):(this.lockStateBg.node.SetActive(!0),1==i.type?(s="rymwfy_bt_0012",this.RegBossGuide(this.data.id)):s="rymwfy_bt_0008",
this.lockStateBg.spriteNameSet(s),e||this.ShowBossEffect()),this.icon.node.SetActive(!0)
const n=I.e.Inst_get().GetCurrentPlayRoomData(!1)
this.data.id==n.id?(this.showGuide=!0,this.icon.spriteNameSet("rymwfy_bt_0015"),this.currentBg.SetActive(!0),
this.icon.SetLocalPositionXYZ(39.2,-32,0)):(this.currentBg.SetActive(!1),this.icon.SetLocalPositionXYZ(42,-38,0),
t.isUnLock?1==i.type||4==i.type?(this.icon.spriteNameSet("rymwfy_bt_0002"),
this.RegBossGuide(this.data.id)):this.icon.node.SetActive(!1):1==i.type?(this.icon.spriteNameSet("rymwfy_bt_0016"),this.RegBossGuide(this.data.id)):this.icon.node.SetActive(!1)),
this.icon.MakePixelPerfect(),this.showGuide&&this.RegGuide()}RegBossGuide(t){
1==this.data.cfg_get().newHand&&(this.isMinMap||(null!=this.bossGuideId&&this.bossGuideId!=t&&this.UnBossGuide(),this.bossGuideId=t,
T.c.Inst.RegGameObject(f.D.MAZE_COPY_TIME_SPACE_ROOM_BOSS_ITEM,this.node,this.bossGuideId)))}UnBossGuide(){
this.isMinMap||null!=this.bossGuideId&&(T.c.Inst.UnRegGameObject(f.D.MAZE_COPY_TIME_SPACE_ROOM_BOSS_ITEM,this.bossGuideId),this.bossGuideId=null)}RegGuide(){
1==this.data.cfg_get().newHand&&(this.isMinMap||(this.guideId=this.data.id,T.c.Inst.RegGameObject(f.D.MAZE_COPY_TIME_SPACE_ROOM_ITEM,this.node,this.guideId)))}UnRegGuide(){
this.isMinMap||null!=this.guideId&&(T.c.Inst.UnRegGameObject(f.D.MAZE_COPY_TIME_SPACE_ROOM_ITEM,this.guideId),this.showGuide=!1)}ShowBossEffect(){
if(1==this.data.eventData.cfg_get().type){if(null==this.effect){const t=new A.V,e=new y.P
e.Set(40,-40,0),t.SetLocalPosition(e),t.CreateByName("pre_eff_pk_fjtx02",this.node,null,null,this.node),this.effect=t}const t=D.D.getInstance().GetIntValue("SPACEMAZE:BOSS_EFFECT")
this.timerId=p.C.Inst_get().SetInterval(this.CreateDelegate(this.HideEffect),1e3*t,1)}}HideEffect(){null!=this.effect&&(this.effect.Destroy(),this.effect=null)}OnClickItem(){
null!=this.clickHandler&&this.clickHandler(this.data)}GetCenterWorldPos(){w.I.calVec0.Set(0,0,0)
return this.icon.node.transform.TransformPoint(w.I.calVec0)}ClearTime(){this.HideEffect(),p.C.Inst_get().ClearInterval(this.timerId),this.timerId=-1}Clear(){
null!=this.effect&&this.effect.Clear(),this.clickHandler=null,this.UnRegGuide(),this.UnBossGuide(),this.HideEffect(),this.ClearTime(),super.Clear()}Destroy(){
null!=this.effect&&this.effect.Destroy(),this.clickHandler=null,this.effect=null,r.g.DestroyUIObj(),super.Destroy()}}let L=null,M=null
class b extends o.f{static __StaticInit(){L=Math.abs,M=[[-2,1],[2,1]]}constructor(){super(),this.container=null,this.listScrollViewPanel=null,this.bossLoc=null,this.itemDict=null,
this.hLineList=null,this.vLineList=null,this.lineDict=null,this.cacheItem=null,this.hCacheLine=null,this.vCacheLine=null,this.minMap=!1,this.currentRoomItem=null,
this.currentRoomData=null,this.currentRoomUnLock=null,this.circleCenter=null,this.arrowAnchor=null,this.itemDict=new d.X,this.hLineList=new h.Z,this.vLineList=new h.Z,
this.lineDict=new d.X,this.cacheItem=new h.Z,this.hCacheLine=new h.Z,this.vCacheLine=new h.Z}InitView(){super.InitView(),this.container=this.CreateComponent(a.T,1),
this.listScrollViewPanel=this.CreateComponent(l.$,2),this.bossLoc=this.CreateComponent(n.z,3),this.circleCenter=this.CreateComponent(n.z,4),
this.arrowAnchor=this.CreateComponent(n.z,5),null!=this.bossLoc&&this.bossLoc.SetActive(!1)}OnAddToScene(){
this.m_handlerMgr.AddEventMgr(c.g.MAZE_ROOM_UNLOCK,this.CreateDelegate(this.Update)),this.m_handlerMgr.AddEventMgr(c.g.MAZE_UPDATE_ROOM,this.CreateDelegate(this.UpdateRoomInfo)),
this.Update()}UpdateRoomInfo(){for(const[t,e]of(0,s.V5)(this.itemDict))e.node.SetActive(!1),this.cacheItem.Add(e)
for(let t=0;t<=this.hLineList.Count()-1;t++)this.hLineList[t].node.SetActive(!1),this.hCacheLine.Add(this.hLineList[t])
for(let t=0;t<=this.vLineList.Count()-1;t++)this.vLineList[t].node.SetActive(!1),this.vCacheLine.Add(this.vLineList[t])
this.itemDict.Clear(),this.hLineList.Clear(),this.vLineList.Clear(),this.lineDict.Clear(),this.Update()}Update(){const t=I.e.Inst_get().GetCurrentPlayRoomData(!1)
if(null==t)return
const e=t.cfg_get()
this.SetData(e.type,e.rebirth)}SetData(t,e){const i=I.e.Inst_get().GetRoomDataList(t,e),s=I.e.Inst_get().GetCurrentPlayRoomData(!1)
let n=0,l=0
for(let t=0;t<=i.Count()-1;t++){const e=i[t],a=e.CanEnter()
if(2!=e.cfg_get().start){const t=e.eventData.cfg_get()
let i=this.itemDict.LuaDic_GetItem(e.id)
if(a||1==t.type){const t=e.cfg_get(),o=80*(t.location[1]-1),r=80*(t.location[2]-1)
o>n&&(n=o),r>l&&(l=r),a&&(this.CreateLine(1,e,o,r),this.CreateLine(2,e,o,r),this.CreateLine(3,e,o,r),this.CreateLine(4,e,o,r)),null==i&&(i=this.GetItem(),
this.itemDict.LuaDic_AddOrSetItem(e.id,i)),i.node.SetActive(!0),i.SetData(e,this.minMap),i.SetLocalPositionXYZ(o,-r,0),s.id==e.id&&(this.currentRoomItem=i)
}else null!=i&&(i.node.SetActive(!1),this.HideLine(1,s),this.HideLine(2,s),this.HideLine(3,s),this.HideLine(4,s))}}if(!this.minMap){const t=n+82,e=l+82
this.container.widthSet(t),this.container.heightSet(e)
const i=(700-t)/2,s=-(500-e)/2
this.container.SetLocalPositionXYZ(i,s,0)}this.AimCurrentRoom()}SetMinMap(){this.minMap=!0,this.container.widthSet(290),this.container.heightSet(230),
this.container.SetLocalPositionXYZ(0,0,0),this.AimCurrentRoom()}AimCurrentRoom(){if(!this.minMap)return
const t=I.e.Inst_get().GetCurrentPlayRoomData(!1)
if(null==t||null==this.currentRoomItem)return
if(this.currentRoomData==t&&t.isUnLock==this.currentRoomUnLock)return
this.currentRoomData=t,this.currentRoomUnLock=t.isUnLock
const e=this.currentRoomItem.GetCenterWorldPos(),i=this.container.node.transform.InverseTransformPoint(e)
let[n,l]=[this.container.width()/2-i.x,-this.container.height()/2-i.y+10];[n,l]=[.6*n,.6*l],this.container.SetLocalPositionXYZ(n,l,0)
let a,o=!1,r=999
for(const[t,e]of(0,s.V5)(this.itemDict)){const t=e.data
if(1==t.eventData.cfg_get().type&&!t.isUnLock){const[t,i]=this.CheckInViewNew(this.currentRoomData.cfg_get().location,e)
if(t){o=!1
break}o=!0,i<r&&(r=i,a=e)}}if(o){this.bossLoc.SetActive(!0)
const t=a.GetCenterWorldPos(),e=this.circleCenter.transform.InverseTransformPoint(t)
let i=e.x,s=e.y
const n=65,l=n/Math.sqrt(i*i+s*s)
i*=l,s*=l
const o=0==i?90:Math.atan(s/i)*(180/Math.pi)
let r=o
o>0&&i>0&&(r+=180),o<0&&(r=i<0?360+o:180+o)
const h=52+12*(1-L(i/n))
i>h&&(i=h)
const d=5+12*(1-L(s/n))
s>d&&(s=d),this.bossLoc.transform.SetLocalPositionXYZ(i,s,0),this.arrowAnchor.transform.SetLocalRotateXYZ(0,0,r)}else this.bossLoc.SetActive(!1)}CheckInViewNew(t,e){
const i=e.data.cfg_get(),n=i.location[1]-t[1],l=i.location[2]-t[2]
if(L(n)<=1&&L(l)<=1)return!0
let a=!1
if(L(n)<=2&&L(l)<=1){a=!0
for(const[t,e]of(0,s.X)(M))if(e[1]==n&&e[2]==l){a=!1
break}}let o=L(n)+L(l)
return a&&(o*=.9),[!1,o]}CreateLine(t,e,i,s){let n,[l,a,o]=!1
const r=e.cfg_get()
if(1==t){if(1!=r.link[1]||!e.CheckHasLink(1))return
o=!0,l=r.location[1]-1,a=r.location[2],n=`h_${l+(r.location[1]+a)}`}else if(2==t){if(1!=r.link[2]||!e.CheckHasLink(2))return
l=r.location[1],a=r.location[2]-1,n=`v_${a+(r.location[2]+l)}`}else if(3==t){if(1!=r.link[3]||!e.CheckHasLink(3))return
o=!0,l=r.location[1]+1,a=r.location[2],n=`h_${r.location[1]+(l+a)}`}else if(4==t){if(1!=r.link[4]||!e.CheckHasLink(4))return
l=r.location[1],a=r.location[2]+1,n=`v_${r.location[2]+(a+l)}`}const h=this.lineDict.LuaDic_GetItem(n)
if(null!=h)return void h.node.SetActive(!0)
if(null!=I.e.Inst_get().GetRoomData(r.rebirth,r.type,l,a)){const e=this.GetLine(o)
let l,a
this.lineDict.LuaDic_AddOrSetItem(n,e),1==t?(l=i-10,a=s+32):2==t?(l=i+32,a=s-10):3==t?(l=i+70,a=s+32):4==t&&(l=i+32,a=s+70),e.SetLocalPositionXYZ(l,-a,0)}}HideLine(t,e){let i,s,n
const l=e.cfg_get()
1==t?(i=l.location[1]-1,s=l.location[2],n=`h_${i+(l.location[1]+s)}`):2==t?(i=l.location[1],s=l.location[2]-1,n=`v_${s+(l.location[2]+i)}`):3==t?(i=l.location[1]+1,s=l.location[2],
n=`h_${l.location[1]+(i+s)}`):4==t&&(i=l.location[1],s=l.location[2]+1,n=`v_${l.location[2]+(s+i)}`)
const a=this.lineDict.LuaDic_GetItem(n)
null!=a&&a.node.SetActive(!1)}GetItem(){let t=this.cacheItem.Pop()
if(null!=t)return t.node.SetActive(!0),t
const e=r.g.GetResFindId("ui_maze_room_item")
return t=new v,t.setPrefabRootId(e),t.clickHandler=this.CreateDelegate(this.OnClickRoomItem),t.node.transform.SetParent(this.container.FatherId,this.container.ComponentId),t}
GetLine(t){let e,i
return t?(i=this.hCacheLine.Pop(),null==i&&(e=r.g.GetResFindId("ui_maze_room_line_h"),i=new _,i.setPrefabRootId(e),
i.node.transform.SetParent(this.container.FatherId,this.container.ComponentId)),i.node.SetActive(!0),this.hLineList.Add(i)):(i=this.vCacheLine.Pop(),
null==i&&(e=r.g.GetResFindId("ui_maze_room_line_v"),i=new _,i.setPrefabRootId(e),i.node.transform.SetParent(this.container.FatherId,this.container.ComponentId)),
i.node.SetActive(!0),this.vLineList.Add(i)),i}OnClickRoomItem(t){if(this.minMap)m.G.Inst_get().OpenMapRoom()
else if(t.CanEnter()){if(I.e.Inst_get().GetCurrentPlayRoomData().id==t.id)return
m.G.Inst_get().CloseMapRoom(),m.G.Inst_get().CM_ChangeSpaceMaze(t.cfg_get().id,!1)}else u.y.inst.ClientSysMessage(11042510)}Clear(){for(const[t,e]of(0,
s.V5)(this.itemDict))e.Clear()
for(let t=0;t<=this.cacheItem.Count()-1;t++)this.cacheItem[t].Clear()
for(let t=0;t<=this.hLineList.Count()-1;t++)this.hLineList[t].Clear()
for(let t=0;t<=this.vLineList.Count()-1;t++)this.vLineList[t].Clear()
super.Clear()}Destroy(){for(const[t,e]of(0,s.V5)(this.itemDict))e.Destroy()
for(let t=0;t<=this.cacheItem.Count()-1;t++)this.cacheItem[t].Destroy()
for(let t=0;t<=this.hLineList.Count()-1;t++)this.hLineList[t].Clear()
for(let t=0;t<=this.vLineList.Count()-1;t++)this.vLineList[t].Destroy()
this.itemDict.Clear(),r.g.DestroyUIObj(),super.Destroy()}}},22625:(t,e,i)=>{i.d(e,{F:()=>u})
var s=i(83908),n=i(68404),l=i(85682),a=i(18202),o=i(98885),r=i(92679),h=i(68637),d=i(92916),c=i(65180)
class u extends((0,s.pA)(n.B)()){constructor(...t){super(...t),this.m_collect=null,this.guideId=null,this.guideParam=null}InitView(){super.InitView()}SetData(t){this.m_collect=t,
this.m_handlerMgr.AddEventMgr(r.g.MAZE_UPDATE_EVENTDATA,this.CreateDelegate(this.OnUpdateData)),this.OnUpdateData(),this.UpdateUIPos(),this._setHeadRenderByCharacter(t)}
OnUpdateData(){const t=this.m_collect.Cfg_get()
if(this.guideId=l.D.MAZE_COPY_TIME_SPACE_ROOM_COLLECT,this.guideParam=d.q.Inst_get().GuideParam(),h.c.Inst.RegGameObject(this.guideId,this.node,this.guideParam),
-1==t.canCollectTimes)this.nameLabel.textSet(t.name)
else{const e=c.e.Inst_get().GetCurrentPlayRoomData(),i=t.canCollectTimes-e.eventData.progress
i<=0?this.nameLabel.textSet(`${t.name}（[ca2626]${i}[-]/${t.canCollectTimes}）`):this.nameLabel.textSet(`${t.name}（${i}/${t.canCollectTimes}）`)}
if(-1!=o.M.IndexOf(t.randomRewards,"SPACEMAZE_ENERGY")){const t=c.e.Inst_get().GetEveryEnergyGetValue()
this.valueAddLabel.textSet(`采集 [5FB470]+${t}[-]`)
let[e,i,s]=this.energyIcon.GetLocalPositionXYZ()
e=this.valueAddLabel.width()+5,this.energyIcon.SetLocalPositionXYZ(e,i,s),[e,i,s]=this.contentContainer.GetLocalPositionXYZ(),e=-(this.valueAddLabel.width()+30)/2,
this.contentContainer.SetLocalPositionXYZ(e,i,s)}else this.contentContainer.visible=!1}UpdateUIPos(){this._SetPosByCharacter(this.m_collect)}Clear(){
null!=this.guideId&&(h.c.Inst.UnRegGameObject(this.guideId,this.guideParam),this.guideId=null),super.Clear()}Destroy(){a.g.DestroyUIObj(this),super.Destroy()}Test1(){return!0}
S_Test(){return!0}}},67595:(t,e,i)=>{i.d(e,{v:()=>v})
var s=i(93984),n=i(32076),l=i(38836),a=i(98800),o=i(97461),r=i(16812),h=i(98497),d=i(38935),c=i(70829),u=i(55360),m=i(98885),I=i(85602),g=i(92679),_=i(37648),p=i(55492),C=i(70400),S=i(88215),f=i(14792),y=i(62734),w=i(38045),D=i(70850),T=i(33833)
class A{constructor(){this.cfg=null,this.skillids=null,this.costId=null,this.costNum=null}CheckFix(){if(null==this.costId){const t=m.M.Split(this.cfg.m_costs.costs[0].value,":")
this.costId=m.M.String2Int(t[0]),this.costNum=m.M.String2Int(t[1])}return D.g.Inst_get().GetItemNum(this.costId)>=this.costNum}GetAttrDes(t){const e=this.cfg.m_atts.attrs
let i="",s=null
null!=t&&(s="047104")
for(let t=0;t<=e.Count()-1;t++)i+=`${T.X.Inst().GetLabelStrByStrKey(e[t].type,(0,w.aI)(e[t].value),null,s)}\n`
return i}S_Test(){return!0}}class v extends r.k{constructor(){super(),this.level=-1,this.defaultData=null,this.nextSkillData=null,this.map=null,this.firstSkillData=null,
this.list=null,this.skillIds=null
const t=u.Y.Inst.GetOrCreateCsv(s.h.eMedalresourceCsv)
this.map=t.m_mapCSV,this.list=new I.Z,this.skillIds=new I.Z
for(const[t,e]of(0,l.vy)(this.map)){const t=new A
if(t.cfg=e,this.list.Add(t),!m.M.IsNullOrEmpty(t.cfg.skillId)){const e=c.j.Inst().GetSkillByStrId(t.cfg.skillId)
this.skillIds.Contains(e.skillid)||this.skillIds.Add(e.skillid)}}this.list.Sort((0,n.v)(this.SonSortFunc,this))
const e=this.list.count
for(let t=0;t<=e;t++)if(!m.M.IsNullOrEmpty(this.list[t].cfg.skillId)){this.firstSkillData=this.list[t]
break}}IsMedalSkill(t){return this.skillIds.Contains(t)}GetCfgByLv(t){return this.map[t]}GetMedalIcon(t){return null==this.map[t]?[null,null]:[this.map[t].showId,this.map[t].name]}
GetShowData(){return this.IsActive()?this.list[this.level-1]:this.list[0]}SonSortFunc(t,e){return t.cfg.id-e.cfg.id}IsActive(){return this.level>0}GetNextData(t){
const e=this.list.IndexOf(t)
return e==this.list.count-1?null:this.list[e+1]}static Inst_get(){return null==v._inst&&(v._inst=new v),v._inst}RegMsg(){h.j.Inst.F_Register(-11582,S.U,(0,
n.v)(this.SM_MedalInfoHanler,this)),o.i.Inst.AddEventHandler(g.g.BAG_INITED,(0,n.v)(this.CheckRedPoint,this)),o.i.Inst.AddEventHandler(g.g.BAG_UPDATE,(0,
n.v)(this.CheckRedPoint,this)),o.i.Inst.AddEventHandler(g.g.FUNCTION_OPEN,(0,n.v)(this.FunOpenHandler,this))}FunOpenHandler(t){t==p.x.MEDAL&&this.CheckRedPoint()}CheckRedPoint(){
if(_.P.Inst_get().IsFunctionOpened(p.x.MEDAL)){if(this.level==this.list.count)return y.f.Inst.SetState(f.t.MEDAL,!1),o.i.Inst.RemoveEventHandler(g.g.BAG_INITED,(0,
n.v)(this.CheckRedPoint,this)),void o.i.Inst.RemoveEventHandler(g.g.BAG_UPDATE,(0,n.v)(this.CheckRedPoint,this))
if(this.IsActive()){let t=this.GetShowData()
t=this.GetNextData(t),null!=t?y.f.Inst.SetState(f.t.MEDAL,t.CheckFix()):y.f.Inst.SetState(f.t.MEDAL,!1)}else y.f.Inst.SetState(f.t.MEDAL,this.list[0].CheckFix())}}ResetData(t){
this.level=0,this.defaultData=null,this.nextSkillData=null}SM_MedalInfoHanler(t){const e=this.level
this.level=t.medalLevel
const i=a.Y.Inst.GetMultPlayerInfos()
for(let t=0;t<=i.Count()-1;t++)i[t].MedalLv_Set(this.level)
e<this.level&&(this.RaiseEvent(v.LevelUp),this.CheckRedPoint())}SendUpHanler(){const t=new C.F
d.C.Inst.F_SendMsg(t)}GetSkillList(){const t=new I.Z,e=new I.Z
this.level
this.nextSkillData=null
for(let i=0;i<=this.level-1;i++)if(!m.M.IsNullOrEmpty(this.list[i].cfg.skillId)){const s=c.j.Inst().GetSkillByStrId(this.list[i].cfg.skillId),n=e.IndexOf(s.skillid)
;-1==n?(e.Add(s.skillid),t.Add(s)):t[n]=s}let i=null
for(let t=this.level;t<=this.list.count-1;t++)if(!m.M.IsNullOrEmpty(this.list[t].cfg.skillId)){i=c.j.Inst().GetSkillByStrId(this.list[t].cfg.skillId)
if(-1==e.IndexOf(i.skillid)){this.nextSkillData=this.list[t]
break}i=null}return[t,i]}}v.QUEST_COMPLETE=2,v.QUEST_PROGRESS=1,v.QUEST_NONE=0,v.LevelUp="LevelUp",v.HONOR_MEDAL=0,v._inst=null},5892:(t,e,i)=>{i.d(e,{s:()=>G})
var s=i(98800),n=i(97960),l=i(97461),a=i(78816),o=i(56937),r=i(18202),h=i(31222),d=i(5494),c=i(995),u=i(98130),m=i(92679),I=i(57035),g=i(55492),_=i(48946),p=i(38836),C=i(99294),S=i(6665),f=i(72005),y=i(61911),w=i(60130),D=i(98885),T=i(85602),A=i(37648),v=i(5031),L=i(40621),M=i(17783),b=i(86662),R=i(67877)
class P extends y.f{constructor(){super(),this.background=null,this.grid=null,this._degf_OnClose=null,this._degf_OnGridItemLoaded=null,this._degf_UpdateRedPoint=null,
this.anchor=null,this._degf_OnClose=(t,e)=>this.OnClose(t,e),this._degf_OnGridItemLoaded=()=>this.OnGridItemLoaded(),this._degf_UpdateRedPoint=(t,e)=>this.UpdateRedPoint(t,e)}
InitView(){this.background=new f.w,this.background.setId(this.FatherId,this.FatherComponentID,2),this.grid=new S.A,this.grid.setId(this.FatherId,this.FatherComponentID,3),
this.anchor=this.CreateComponent(C.z,4),this.grid.SetInitInfo("ui_moreitem",null,R.U),this.grid.OnReposition_set(this._degf_OnGridItemLoaded)}SetAnchorPos(){
w.O.SetAnchorPos(this.anchor,null,!0,1,!1)
const t=v.T.inst_get().control.mainViewPanel.GetPosByFuncTypeInOpenView(g.x.MORE).Clone(),e=this.anchor.InverseTransformPoint(t).Clone()
e.y-=50,this.background.SetLocalPosition(e)}OnGridItemLoaded(){D.M.IsNullOrEmpty(M.L.Inst_get().model.flyUIChild)}OnAddToScene(){this.SetAnchorPos(),this.AddListeners(),
this.UpdateMoreItem()}Clear(){this.RemoveListeners(),this.grid.Clear(),this.UnRegGuide()}Destroy(){this.background=null,this.grid.Destroy()}AddListeners(){
this.AddFullScreenCollider(this.node,this._degf_OnClose)}RemoveListeners(){this.RemoveFullScreenCollider()}UnRegGuide(){}OnClose(t,e){G.Inst.CloseView()}UpdateMoreItem(){
const t=new T.Z,e=_.m.Inst_get().GetItemList()
let i=e.Count()-1
for(;i>=0;){const n=e[i]
if(G.Inst.functionId==g.x.MORE&&4==n.area_type||G.Inst.functionId==g.x.GROW&&5==n.area_type){const e=I.d.Inst_get().GetItemByNameId(n.id)
if(null!=e){s.Y.Inst.PrimaryRoleInfo_get().Level_get()
if(A.P.Inst_get().IsFunctionShow(e.id)||A.P.Inst_get().IsFunctionOpened(e.id)){const i=new b.T
i.id=e.id,i.areaId=n.area_id,i.icon=n.icon,i.btnId=n.id,i.efftype=n.type,t.Add(i)}}}i-=1}this.grid.data_set(t)
let n=0
const l=t.Count()
n=l%4==0?u.GF.INT(l/4):u.GF.INT(l/4)+1
const a=this.grid.node.transform.GetLocalPosition(),o=Math.abs(a.y)+n*this.grid.cellHeight()+3
this.background.heightSet(u.GF.INT(o)),l<=2?this.background.widthSet(190):3==l?this.background.widthSet(280):this.background.widthSet(370)}UpdateRedPoint(t,e){
if(null!=this.grid&&null!=this.grid.itemList&&0!=this.grid.itemList.Count())for(const[i,s]of(0,p.V5)(this.grid.itemList))if(null!=s.data){
if(L.c.Instance_get().GetIdByFunc(s.data.id)==t){s.tip.node.SetActive(e)
break}}}}class G{constructor(){this.view=null,this.functionId=0,this._degf_CallDestory=null,this._degf_Complete=null,this._degf_FunctionOpenHandler=null,
this._degf_LevelUpHandler=null,this._degf_CallDestory=()=>this.CallDestory(),this._degf_Complete=t=>this.Complete(t),this._degf_FunctionOpenHandler=t=>this.FunctionOpenHandler(t),
this._degf_LevelUpHandler=t=>this.LevelUpHandler(t),this.RegisteEvent()}static get Inst(){return null==G.inst&&(G.inst=new G),G.inst}RegisteEvent(){
l.i.Inst.AddEventHandler(m.g.FUNCTION_OPEN,this._degf_FunctionOpenHandler),l.i.Inst.AddEventHandler(m.g.FUNCTION_CLOSE,this._degf_FunctionOpenHandler),
s.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(n.A.LevelUpdate,this._degf_LevelUpHandler)}OpenView(t){if(null!=this.view&&this.view.isShow_get())this.view.UpdateMoreItem()
else{const t=new o.v
t.aniDir=c.K.Default,g.x.GROW,t.isShowMask=!0,h.N.inst.OpenById(d.I.MorePanel,this._degf_Complete,this._degf_CallDestory,t),a.a.inst_get().PlayOpenSound(d.I.MorePanel)}
this.functionId=t}Complete(t){return null==this.view&&(this.view=new P,this.view.setId(t,null,0)),this.view}CallDestory(){r.g.DestroyUIObj(this.view),this.view=null}CloseView(){
null!=this.view&&this.view.isShow_get()&&(h.N.inst.CloseById(d.I.MorePanel),a.a.inst_get().PlayCloseSound(d.I.MorePanel))}FunctionOpenHandler(t){
const e=u.GF.INT(t),i=I.d.Inst_get().getItemById(e)
if(null==i)return
const s=_.m.Inst_get().getItemById(i.nameId)
null!=s&&1==s.area_type&&3==s.area_type&&null!=this.view&&this.view.isShow_get()&&this.view.UpdateMoreItem()}LevelUpHandler(t){
null!=this.view&&this.view.isShow_get()&&this.view.UpdateMoreItem()}}G.inst=null},86662:(t,e,i)=>{i.d(e,{T:()=>s})
class s{constructor(){this.id=0,this.areaId=0,this.icon=null,this.btnId=null,this.efftype=1,this.stay=void 0,this.name=void 0}}},67877:(t,e,i)=>{i.d(e,{U:()=>B})
var s,n=i(18998),l=i(83908),a=i(98800),o=i(19176),r=i(68662),h=i(5924),d=i(85682),c=i(18202),u=i(83540),m=i(28192),I=i(98130),g=i(79534),_=i(21554),p=i(70850),C=i(63076),S=i(6710),f=i(3859),y=i(92679),w=i(87923),D=i(37639),T=i(55492),A=i(75439),v=i(48481),L=i(68637),M=i(52396),b=i(37322),R=i(43308),P=i(40621),G=i(62734),O=i(65550)
const{ccclass:E}=n._decorator
let B=E("MoreItem")(s=class extends((0,l.yk)()){constructor(...t){super(...t),this._m_handlerMgr=null,this.funcSpr=null,this.data=null,this.redPointId=0,this._timerId=-1,
this.cdEndTime=0,this.CDTimeCount=0,this.cding=!1,this.press=null,this._degf_OnFunc=null,this._degf_UpdateRedPoint=null,this._degf_OnHangStateUpdate=null,
this.defg_OnDressDrugs=null,this._degf_OnCdLoop=null,this._degf_OnShortcutGoodsUpdateCD=null,this._degf_OnLongPressDrugs=null,this.installBaseItemData=null}get m_handlerMgr(){
return this._m_handlerMgr||(this._m_handlerMgr=m.h.Get()),this._m_handlerMgr}_initBinder(){super._initBinder(),this._degf_OnFunc=(t,e)=>this.OnFunc(t,e),
this._degf_UpdateRedPoint=(t,e)=>this.UpdateRedPoint(t,e),this._degf_OnHangStateUpdate=t=>this.OnHangStateUpdate(t),this.defg_OnDressDrugs=t=>this.UpdateDressDrugs(),
this._degf_OnCdLoop=()=>this.OnCdLoop(),this._degf_OnShortcutGoodsUpdateCD=t=>this.OnShortcutGoodsUpdateCD(t),this._degf_OnLongPressDrugs=()=>this.OnLongPressDrugs()}InitView(){
this.drugsInfoContainer.SetActive(!1),this.btnImg.node.SetActive(!1),this.installBaseItemData=null}SetData(t){this.UnRegGuide(),this.ClearRedPoint(),this.AddListeners(),
this.data=t,null!=this.bg&&null!=this.bgTween&&this.bg.node.SetActive(!0),this.data.id==T.x.AUTO&&this.UpdateHangState(o.S.getInst().InHang_get()),
this.redPointId=P.c.Instance_get().GetIdByFunc(this.data.id)
const e=G.f.Inst.GetData(this.redPointId)
null!=e?(this.tip.node.SetActive(e.show),G.f.Inst.AddCallback(this.redPointId,this._degf_UpdateRedPoint)):this.tip.node.SetActive(!1),
this.noticeEffect.SetActive(M.h.Inst_get().GetEffState(this.data.id,this.data.efftype)),
this.data.id==T.x.BATTLE_USE_DRUGS?(this.press=new b.c(this.btnImg.node,null,this._degf_OnLongPressDrugs),
this.m_handlerMgr.AddEventMgr(y.g.SHORTCUT_GOODS_UPDATE,this.defg_OnDressDrugs),this.m_handlerMgr.AddEventMgr(y.g.SHORTCUT_GOODS_UPDATE_CD,this._degf_OnShortcutGoodsUpdateCD),
this.m_handlerMgr.AddEventMgr(y.g.BAG_UPDATE,this.CreateDelegate(this.UpdateBagItem)),
this.UpdateDressDrugs()):null!=this.installBaseItemData&&(this.m_handlerMgr.RemoveEventMgr(y.g.SHORTCUT_GOODS_UPDATE,this.defg_OnDressDrugs),
this.m_handlerMgr.RemoveEventMgr(y.g.SHORTCUT_GOODS_UPDATE_CD,this._degf_OnShortcutGoodsUpdateCD),null!=this.press&&this.press.Clear(),this.icon.node.SetActive(!0),
this.btnImg.node.SetActive(!1),this.drugsInfoContainer.SetActive(!1),this.installBaseItemData=null),this.UpdateTip(),this.RegGuide()}UpdateRedPoint(t,e){
this.tip.node.active!=e&&this.redPointId==t&&this.tip.node.SetActive(e)}UpdateHangState(t){t?(this.background.setSkin("atlas/mainui/rymainui_sp_empty"),
null!=this.bg&&null!=this.bgTween&&this.bg.node.SetActive(!1)):(this.background.setSkin("atlas/mainui/rymainui_functionicon_0060"),
null!=this.bg&&null!=this.bgTween&&this.bg.node.SetActive(!0))}UpdateDressDrugs(){const t=p.g.Inst_get().GetItemByModleID(p.g.Inst_get().shortcutGoodsItemID)
if(null!=t){this.installBaseItemData=new C.M(t.baseData_get().modelId_get())
const e=new v.t
e.modelId=t.baseData_get().modelId_get(),e.id=t.serverData_get().id,this.installBaseItemData.serverData_set(e)
const i=this.installBaseItemData.cfgData_get(),s=p.g.Inst_get().GetItemNum(i.id)
if(s>0)return this.icon.node.SetActive(!1),this.drugsInfoContainer.SetActive(!0),this.shade_sprite.node.SetActive(!1),this.btnImg.node.SetActive(!0),
this.numberLabel.node.SetActive(!0),this.numberLabel.textSet(`${s}`),c.g.SetItemIcon(this.btnImg,i.icon,u.b.eItem,!0),void(null!=this.press&&this.press.AddEvent())}
null!=this.press&&this.press.Clear(),this.installBaseItemData=null,this.icon.node.SetActive(!0),this.btnImg.node.SetActive(!1),this.drugsInfoContainer.SetActive(!1)}OnClickDrugs(){
if(a.Y.Inst.m_primaryRoleInfo&&a.Y.Inst.m_primaryRoleInfo.InTransform())O.y.inst.ClientSysMessage(131505)
else if(null==this.installBaseItemData){if(p.g.Inst_get().GetItemListByItemType(f.q.SCMEDICINE).Count()>0)this.OpenDrugs()
else{const t=A.D.getInstance().GetIntValue("ACCESS:POTION")
R._.Inst_get().OpenByItem(t,new g.P(0,0,0))}}else{if(this.cding)return void O.y.inst.ClientSysMessage(100035)
_.J.Inst_get().UseItem(this.installBaseItemData)}}OnLongPressDrugs(){this.OpenDrugs()}OpenDrugs(){const t=this.node.transform.GetLocalPosition()
t.x+=130,t.y-=130,S.E.Inst_get().Open(new g.P(t.x,t.y,t.z))}OnShortcutGoodsUpdateCD(t){this.cdEndTime=.001*I.GF.INT(t),this.UpdateDressDrugs(),
0!=this.cdEndTime&&(h.C.Inst_get().ClearLoop(this._timerId),this._timerId=-1,0!=p.g.Inst_get().shortcutGoodsItemID&&(this.cding=!0,this.shade_sprite.node.SetActive(!0),
this._timerId=h.C.Inst_get().SetFrameLoop(this._degf_OnCdLoop,1),this.CDTimeCount=this.cdEndTime-r.D.serverTime_get()))}OnCdLoop(){
const t=(this.cdEndTime-r.D.serverTime_get())/this.CDTimeCount
this.shade_sprite.fillAmountSet(t),this.shade_sprite.fillRange<=0&&this.clearDrugsCD()}clearDrugsCD(){this.shade_sprite.fillAmountSet(0),this.cding=!1,
this.shade_sprite.node.SetActive(!1),h.C.Inst_get().ClearLoop(this._timerId),this._timerId=-1}UpdateBagItem(){if(null==this.installBaseItemData){
const t=p.g.Inst_get().GetItemListByItemType(f.q.SCMEDICINE)
t.Count()>0&&_.J.Inst_get().ReqEquipMedicine(t[0].baseData_get().cfgData_get().id)
}else this.numberLabel.textSet(p.g.Inst_get().GetItemNum(this.installBaseItemData.cfgData_get().id).toString())}OnHangStateUpdate(t){
this.data.id==T.x.AUTO&&this.UpdateHangState(o.S.getInst().InHang_get())}ShowOrHideEffect(t){}OnShowTip(t){t==this.data.id&&this.UpdateTip()}OnCloseTip(t){
t==this.data.id&&this.tip_obj.SetActive(!1)}UpdateTip(){}GetCenterPos(){return this.icon.node.transform.GetLocalPosition()}ClearRedPoint(){if(0!=this.redPointId){
this.redPointId=P.c.Instance_get().GetIdByFunc(this.data.id)
null!=G.f.Inst.GetData(this.redPointId)&&G.f.Inst.RemoveCallback(this.redPointId,this._degf_UpdateRedPoint)}this.redPointId=0}Clear(){this.UnRegGuide(),this.RemoveListeners(),
this.ClearRedPoint(),this.clearDrugsCD(),this.data=null}Destroy(){}AddListeners(){this.m_handlerMgr.AddClickEvent(this.icon.node,this._degf_OnFunc),
this.m_handlerMgr.AddClickEvent(this.btnImg.node,this._degf_OnFunc),this.m_handlerMgr.AddEventMgr(y.g.MAIN_ICON_TIP_CHANGE,this.CreateDelegate(this.OnShowTip)),
this.m_handlerMgr.AddEventMgr(y.g.MAIN_ICON_TIP_CLOSE,this.CreateDelegate(this.OnCloseTip)),
this.m_handlerMgr.AddEventMgr(y.g.FUNCITEM_EFFECT_UPDATE,this.CreateDelegate(this.updateEff))}RemoveListeners(){
this.m_handlerMgr.RemoveClickEvent(this.icon.node,this._degf_OnFunc),this.m_handlerMgr.RemoveClickEvent(this.btnImg.node,this._degf_OnFunc),
this.m_handlerMgr.RemoveEventMgr(y.g.SHORTCUT_GOODS_UPDATE,this.defg_OnDressDrugs),
this.m_handlerMgr.RemoveEventMgr(y.g.SHORTCUT_GOODS_UPDATE_CD,this._degf_OnShortcutGoodsUpdateCD),
this.m_handlerMgr.RemoveEventMgr(y.g.MAIN_ICON_TIP_CHANGE,this.CreateDelegate(this.OnShowTip)),
this.m_handlerMgr.RemoveEventMgr(y.g.MAIN_ICON_TIP_CLOSE,this.CreateDelegate(this.OnCloseTip)),
this.m_handlerMgr.RemoveEventMgr(y.g.BAG_UPDATE,this.CreateDelegate(this.UpdateBagItem)),null!=this.press&&this.press.Clear()}updateEff(t){}OnFunc(t,e){
this.data.id!=T.x.BATTLE_USE_DRUGS?(D.K.OnClickHandelByFuncId(this.data.id),this.CheckGuide()):this.OnClickDrugs()}RegGuide(){
null!=this.data&&null!=this.data.id&&L.c.Inst.RegGameObject(d.D.UI_FUN_BTN_PANEL_BTN,this.icon.node,this.data.id)}UnRegGuide(){
null!=this.data&&null!=this.data.id&&L.c.Inst.UnRegGameObject(d.D.UI_FUN_BTN_PANEL_BTN,this.data.id)}CheckGuide(){
null!=this.data&&null!=this.data.id&&w.l.CheckBtnClickTrigger(d.D.UI_FUN_BTN_PANEL_BTN,this.data.id)}getCenterPos(){return this.icon.node.transform.GetLocalPosition()}
GetCenterLocalPos(){return this.icon.node.transform.GetLocalPosition()}})||s}}])
