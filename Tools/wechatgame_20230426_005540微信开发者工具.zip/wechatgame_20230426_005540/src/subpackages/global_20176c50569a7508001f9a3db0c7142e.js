"use strict";(globalThis.webpackChunkProject=globalThis.webpackChunkProject||[]).push([[172],{50107:(t,e,i)=>{i.d(e,{C:()=>s})
var s={SOCKET_CONNECTED:"socket_connected",SOCKET_CLOSED:"socket_closed",PANEL_READY:"PANEL_READY",PANEL_UPDATED:"PANEL_UPDATED",LOGIN_LOAD_START:"login_load_start",
LOGIN_FLAG_UPDATE:"login_flag_update",CREATE_SCENE:"create_tiledscene",MLAYER_NODE_ADDCHILD:"mlayer_node_addchild",__DEBUG_CAMERA_MOVE__:"__DEBUG_CAMERA_MOVE__"}},39470:(t,e,i)=>{
i.d(e,{x:()=>H})
var s,n=i(18998),a=i(83908),l=i(49655),r=i(38836),o=i(86133),h=i(11210),d=i(98800),c=i(97960),g=i(98958),u=i(66788),m=i(5494),_=i(84485),p=i(84229),f=i(92984),C=i(56131),E=i(13994),v=i(58158),N=i(77477),I=i(87923),T=i(37648),S=i(55492),A=i(33833),D=i(75439),w=i(10509),y=i(41864),V=i(65793),k=i(98130),U=i(98885),b=i(85602),O=i(62463)
class L{constructor(){this.attrName="",this.attrVal=""}AttrName_get(){return this.attrName}AttrName_set(t){this.attrName=t}AttrVal_get(){return this.attrVal}AttrVal_set(t){
this.attrVal=t}}const{ccclass:x}=n._decorator
let H=x("CharacterBaseInfoScript")(s=class extends((0,a.Ri)()){constructor(...t){super(...t),this._degf_WorldBuffBtnClickHandler=null,this._degf_UpdateOnreposition=null,
this._degf_WorldLevelTipMaskClickHandler=null,this._degf_OnGodBlessBtnClickHandler=null,this.rInfo=null,this.proAndReb=null,this.specialAttributeList=new b.Z,
this.attrNameAry=["伤害反射","五秒回血","闪避加成","暴击","暴击伤害","暴击减伤","命中加成"],this.attrValueAry=[1e3,50,20,50,2e3,410,68]}onLoad(){for(let t=0;t<7;t++){const e=new L
e.AttrName_set(this.attrNameAry[t]),e.AttrVal_set(this.attrValueAry[t].toString()),this.specialAttributeList.Add(e)}}InitView(){this.rInfo=null,this.PK_tip.active=!1,
this.grid.SetInitInfo("ui_characterui_detailinfoitem_new",null,O.x),this.grid.OnReposition_set(this.CreateDelegate(this.UpdateOnreposition))}OnItemRefreshFun(t,e){}
UpdateOnreposition(){this.detailScrollView.ResetPosition()}SetData(){this.InitData(),this.UpdateOnreposition()}InitData(){this.InitAllData(),this.addLis(),this._OnUpdateAnchor()}
_OnUpdateAnchor(){}addLis(){this.changeNameBtn.node.on(n.NodeEventType.TOUCH_END,this.ChangeNameBtnClickHandler,this),
this.asuramJoinBtn.node.on(n.NodeEventType.TOUCH_END,this.allianceClickBtnHandler,this),this.PK_btn.node.on(n.NodeEventType.TOUCH_END,this.PKTipBtnClickHandler,this),
this.PKTipMask.on(n.NodeEventType.TOUCH_END,this.PKTipClickHandler,this),this.changeleader.on(n.NodeEventType.TOUCH_END,this.ChangeLeaderClick,this),
this.surfaceBtn.node.on(n.NodeEventType.TOUCH_END,this.OnSurfaceClick,this)
const t=d.Y.Inst.primaryRoleInfoList
for(let e=0;e<=t.Count()-1;e++){const i=t[e]
i.AddEventHandler(c.A.LevelUpdate,this.CreateDelegate(this.LevelShowHandler)),i.AddEventHandler(c.A.AttributesUpdate,this.CreateDelegate(this.AttributeUpdateHandler)),
i.AddEventHandler(c.A.JobUpdate,this.CreateDelegate(this.JobUpdateHandler)),i.AddEventHandler(c.A.NameUpdate,this.CreateDelegate(this.NameUpdateHandler)),
i.AddEventHandler(c.A.ExpUpdate,this.CreateDelegate(this.ExpShowHandler)),i.AddEventHandler(c.A.AsuramIdUpdate,this.CreateDelegate(this.AsuramIdUpdateHandler))}}removeLis(){
this.changeNameBtn.node.off(n.NodeEventType.TOUCH_END,this.ChangeNameBtnClickHandler),this.asuramJoinBtn.node.off(n.NodeEventType.TOUCH_END,this.allianceClickBtnHandler),
this.PK_btn.node.off(n.NodeEventType.TOUCH_END,this.PKTipBtnClickHandler),this.changeleader.off(n.NodeEventType.TOUCH_END,this.ChangeLeaderClick),
this.surfaceBtn.node.off(n.NodeEventType.TOUCH_END,this.OnSurfaceClick),this.PKTipMask.off(n.NodeEventType.TOUCH_END,this.PKTipClickHandler)
const t=d.Y.Inst.primaryRoleInfoList
for(let e=0;e<=t.Count()-1;e++){const i=t[e]
i.RemoveEventHandler(c.A.LevelUpdate,this.CreateDelegate(this.LevelShowHandler)),i.RemoveEventHandler(c.A.AttributesUpdate,this.CreateDelegate(this.AttributeUpdateHandler)),
i.RemoveEventHandler(c.A.JobUpdate,this.CreateDelegate(this.JobUpdateHandler)),i.RemoveEventHandler(c.A.NameUpdate,this.CreateDelegate(this.NameUpdateHandler)),
i.RemoveEventHandler(c.A.ExpUpdate,this.CreateDelegate(this.ExpShowHandler)),i.RemoveEventHandler(c.A.AsuramIdUpdate,this.CreateDelegate(this.AsuramIdUpdateHandler))}}RegGuide(){}
UnRegGuide(){}CheckGuide(){}AsuramIdUpdateHandler(t){const e=t,i=h.i.Inst.GetCurSelect(l.o.CharacterPanel)
null!=i&&i.m_id.Equal(e.m_id)&&this.AsuramIdUpdate(e)}ExpShowHandler(t){const e=t,i=h.i.Inst.GetCurSelect(l.o.CharacterPanel)
null!=i&&i.m_id.Equal(e.m_id)&&this.ExpShow(e)}NameUpdateHandler(t){const e=t,i=h.i.Inst.GetCurSelect(l.o.CharacterPanel)
null!=i&&i.m_id.Equal(e.m_id)&&this.NameUpdate(e)}JobUpdateHandler(t){const e=t,i=h.i.Inst.GetCurSelect(l.o.CharacterPanel)
null!=i&&i.m_id.Equal(e.m_id)&&this.JobUpdate(e)}AttributeUpdateHandler(t){const e=t,i=h.i.Inst.GetCurSelect(l.o.CharacterPanel)
null!=i&&i.m_id.Equal(e.m_id)&&0==_.X.Inst_get().startOperation&&this.AttributeUpdate(e)}LevelShowHandler(t){const e=t,i=h.i.Inst.GetCurSelect(l.o.CharacterPanel)
null!=i&&i.m_id.Equal(e.m_id)&&this.LevelShow(e)}ChangeNameBtnClickHandler(t,e){E.I.inst.type=1,C.F.Inst_get().PreCheckChange()&&C.F.Inst_get().OpenChangeNameView()}
OnFunctionOpenHandler(t){}OnGodBlessBtnClickHandler(t,e){u.Y.LogWarning("神佑系统已删除")}InitAllData(){this.detailScrollView.bounceDuration=1
const t=h.i.Inst.GetCurSelect(m.I.CharacterUIPanel)
this.rInfo=t,this.SetExp(t,!1),this.AsuramIdUpdate(t),this.playerName.string=t.Name_get(),t.IsMaster()?(this.levelValue.string=`${t.GetMasterLevel()}`,
this.masterMark.node.active=!0):(this.levelValue.string=y.h.GetLevelStr(t.Level_get()),this.masterMark.node.active=!1),this.RoleAttributeUpdate(t),
this.professionName.string=I.l.getJobStr(t.Job_get()),this.UpdateWorldLevel(),this.InitDetailData(),this.PKDesc1.string=g.V.Inst().getStr2(11001,null,null,null,null),
this.UpdateLeader(),this.surfaceBtn.node.active=T.P.Inst_get().IsFunctionOpened(S.x.SURFACE)}UpdateLeader(){this.rInfo.isPrimary?(this.changeleader.active=!1,
this.curLeader.node.active=!0,this.UnRegGuide()):(this.changeleader.active=!0,this.curLeader.node.active=!1,this.RegGuide())}ChangeLeaderClick(t,e){
0!=d.Y.Inst.CM_ChangePlayerLeader(this.rInfo.m_id)&&(this.changeleader.active=!1,this.curLeader.node.active=!0)}OnSurfaceClick(t,e){V.W.Inst_get().OpenSurfaceSettingView()}
RoleAttributeUpdate(t){let e=0,i=""
e=t.Attributes_get()[k.GF.INT(N.Z.MaxHp)],i=U.M.DoubleToString(e),this.hpValue&&(this.hpValue.string=i)
const s=t.Attributes_get()[k.GF.INT(N.Z.PhyAttack_Min)],n=t.Attributes_get()[k.GF.INT(N.Z.PhyAttack_Max)]
i=0==s&&0==n?"0":`${I.l.GetAttackRuleDecimalVal(s)}-${I.l.GetAttackRuleDecimalVal(n)}`,this.physicalATKValue&&(this.physicalATKValue.string=i),
e=t.Attributes_get()[k.GF.INT(N.Z.Defense)],i=U.M.DoubleToString(e),this.defenceValue&&(this.defenceValue.string=i),e=t.Attributes_get()[k.GF.INT(N.Z.HitRate)],
i=U.M.DoubleToString(e),this.atkSuccessValue&&(this.atkSuccessValue.string=i),e=t.Attributes_get()[k.GF.INT(N.Z.DodgeRate)],i=U.M.DoubleToString(e),
this.defenceSuccessValue&&(this.defenceSuccessValue.string=i),e=t.Attributes_get()[k.GF.INT(N.Z.AttackSpeed)],null==e&&(e=0),i=U.M.DoubleToString(e),
this.attackSpeedValue&&(this.attackSpeedValue.string=i),e=t.Attributes_get()[k.GF.INT(N.Z.MoveSpeed)],null==e&&(e=0),i=U.M.DoubleToString(e),
this.MoveSpeedvalue&&(this.MoveSpeedvalue.string=i),this.PKlvalue&&(this.PKlvalue.string=t.PkPoint_get().toString())}ClearData(){this.removeLis()}Clear(){this.ClearData(),
this.UnRegGuide()}NameUpdate(t){null!=t&&(this.playerName.string=t.Name_get())}JobUpdate(t){null!=t&&(this.professionName.string=I.l.getJobStr(t.Job_get()))}AsuramIdUpdate(t){
null==t||null==p.Q.Inst_get().AsuramData_get()?this.asuramName.string="无":this.asuramName.string=p.Q.Inst_get().AsuramData_get().name}AttributeUpdate(t){
null!=t&&(this.RoleAttributeUpdate(t),this.InitDetailData())}LevelShow(t){null!=t&&this.levelValue&&(this.levelValue.string=`LV.${t.Level_get()}`,this.SetExp(t))}
WorldBuffBtnClickHandler(t,e){f.j.Inst_get().model.worldLevel
const i=d.Y.Inst.primaryRole.Roleinfo_get().Id_get()
d.Y.Inst.primaryRole.Roleinfo_get().Level_get(),f.j.Inst_get().model.getBuffByType("WorldLevelExp",i),
D.D.getInstance().getContent("WORLDLEVEL:WORLDLEVEL_PLAYER_COUNT").getContent().stringVal}PKTipBtnClickHandler(){this.PK_tip.active=!0}PKTipClickHandler(t,e){this.PK_tip.active=!1}
WorldLevelTipClickHandler(t,e){}WorldLevelUpdateHandler(){this.UpdateWorldLevel()}OnAddBuff(t){}UpdateWorldLevel(){}allianceClickBtnHandler(t,e){}ExpShow(t){this.SetExp(t)}
SetExp(t,e=!0){if(null==t||!this.expshow)return
t.Level_get()
const i=w.L.Inst().getItemById(t.Level_get()),s=t.Exp_get().ToNum()
let n=null
i.exp&&(n=i.exp.ToNum?i.exp.ToNum():i.exp)
const a=I.l.GetPurseVOChineseString(s,null,null,null,!0,!1)+"/"+I.l.GetPurseVOChineseString(n,null,null,null,!0,!1)
this.expshow.string=a,this.slider_fullExp.node.active=!1,this.slider.fillRange=s/n}InitDetailData(){const t=this.rInfo
if(!t)return
const e=t.Attributes_get(),i=new b.Z,s=A.X.Inst().getCanShowItemListByType(v.U.AttrIntruction_Special)
if(null!=s&&0!=s.Count()){let t=null,n=null
for(const[a,l]of(0,r.V5)(s)){if(n=null,t=new L,t.AttrName_set(l.name),1==l.valueType)if(l.id==N.Z.Treatment){null==e[l.id]&&u.Y.LogError(l.id+(0,o.T)("这个属性服务器没发值"))
const i=e[N.Z.PhyAttack_Max],s=e[N.Z.PhyAttack_Min]
t.AttrVal_set(I.l.GetRuleDecimalVal((i+s)/2))}else l.id==N.Z.MoveSpeed||null!=e[l.id]?t.AttrVal_set(`${e[l.id]}`):(t.AttrVal_set("快改啊"),u.Y.LogError(`${l.id} 这个属性找不到`))
else 2==l.valueType?t.AttrVal_set(I.l.GetPrecentDecimalVal(e[l.id],100,2)+"%"):t.AttrVal_set(e[l.id]+"%")
i.Add(t),null!=n&&i.Add(n)}}this.specialAttributeList=i,this.grid.data_set(i),this.specialattribute.parent.transform.height=360+this.specialattribute.transform.height}Destroy(){}
})||s},96175:(t,e,i)=>{var s,n=i(18998)
const{ccclass:a,property:l}=n._decorator
a("CharacterViewScript")(s=class{})},62463:(t,e,i)=>{i.d(e,{x:()=>r})
var s,n=i(18998),a=i(84501)
const{ccclass:l}=n._decorator
let r=l("DetailInfoItem")(s=class extends a.X{constructor(...t){super(...t),this.attrName=null,this.attrVal=null,this.infoData=null,this.bg=null,this.indexT=0,this.index=null}
Clear(){}InitView(){this.attrName=this.node.getChildByName("txtAttrName").getComponent(n.Label),this.attrVal=this.node.getChildByName("txtAttrVal").getComponent(n.Label),
this.bg=this.node.getChildByName("spBg").getComponent(n.Sprite)}SetData(t,e=0){null!=t&&(this.indexT=e,this.infoData=t,this.attrName.string=this.infoData.AttrName_get(),
this.attrVal.string=this.infoData.AttrVal_get(),this.index&&(this.bg.node.active=this.index%2==0))}Destroy(){}})||s},70167:(t,e,i)=>{
var s,n=i(18998),a=i(21370),l=i(34565),r=i(6847),o=i(17409),h=i(49655),d=i(46282),c=i(81224);(0,r.s_)(h.o.AlertV,d.Z.AlertV).layerSet(a.T.tip,!0).register()(s=class extends l.I{
constructor(...t){super(...t),this._data=null}onPanelAdded(t){this.doUpdatePanel(t)}onPanelRemoved(){this.doCallBack(c.Qk.Cancel,!0,!1)}onUserDataUpdate(t){this.doUpdatePanel(t)}
doUpdatePanel(t){if(this._data=t,t.width||t.height){const e=this.node.getComponent(n.UITransform)
e&&(t.width&&t.height?e.setContentSize(t.width,t.height):t.width?e.width=t.width:t.height&&(e.height=t.height))}const e=this.node.getCNode()
e.rtDesc.string=`<color=#181818>${t.msg}</color>`,t.addNode&&this.node.addChild(t.addNode)
const i=this.node.getChildByName("btnClose")
i&&(i.active=!t.noCloseBtn,i.on(n.NodeEventType.TOUCH_END,this.onClickClose,this))
const s=[e.btnCancel.node,e.btnConfirm.node]
let a=null,l=null
t.btn===c.Qk.Ok?(a=[c.Qk.Ok],l=[15]):t.btn===c.Qk.Cancel?(a=[c.Qk.Cancel],l=[16]):t.btn===c.Qk.CancelOk?(a=[c.Qk.Cancel,c.Qk.Ok],
l=[16,15]):t.btn===c.Qk.OkCancel&&(a=[c.Qk.Ok,c.Qk.Cancel],l=[15,16])
let r=null
if(t.label){const e=getText(t.label)
e&&(r=e.split(";"))}t.titleLabel&&(e.tTitle.string=getText(t.titleLabel)),t.title&&(e.tTitle.string=t.title)
const o=a?a.length:0
s[0].x=1===o?0:-128,s.forEach(((t,e)=>{if(t.off(n.NodeEventType.TOUCH_END,this.doCallBack,this,!1),a&&a.length>e){t.active=!0
const i=t.getComponentInChildren(n.Label)
r&&r.length>e?i.string=r[e]:l&&l.length>e?i.string=getText(l[e]):i.string="undefined",t.on(n.NodeEventType.TOUCH_END,this.doCallBack,this,!1,[a[e],!1,!0])}else t.active=!1}))}
onClickClose(){this.doCallBack(c.Qk.Cancel,!0,!0)}doCallBack(t,e,i,s){s instanceof Event&&s.stopPropagation()
const n=this._data?this._data.callback:void 0
this._data=null,i&&(0,o.sR)(this),n&&n(t,e)}})},18043:(t,e,i)=>{var s,n=i(18998),a=i(34565),l=i(6847),r=i(83908),o=i(49655),h=i(46282);(0,
l.s_)(o.o.AniTestView1,h.Z.AniTestView1).register()(s=class extends((0,r.pA)(a.I)()){onPanelAdded(){this.btnClose.on(n.NodeEventType.TOUCH_END,this.onCloseClick,this)
const t=this.aniG
t.clear(),t.line(-100,0,100,0),t.line(0,-100,0,100),t.stroke(),this.list.numItems=20}onCloseClick(){this.removeSelfPanel()}})},64302:(t,e,i)=>{var s=i(18998)
class n{static setItem(t,e){s.sys.localStorage.setItem(t,e)}static getItem(t){return s.sys.localStorage.getItem(t)}static setJSON(t,e){
s.sys.localStorage.setItem(t,JSON.stringify(e))}static getJSON(t){return JSON.parse(s.sys.localStorage.getItem(t))}static removeItem(t){s.sys.localStorage.removeItem(t)}
static clear(){s.sys.localStorage.clear()}}
var a=i(15317),l=i(11568),r=i(66008),o=i(6847),h=i(83908),d=i(17409),c=i(57258),g=i(49655),u=i(46282),m=i(98800),_=i(62265),p=i(93701),f=i(72359),C=i(23407),E=i(5924),v=i(22662),N=i(65550),I=i(85602),T=i(47465),S=i(28192)
class A extends((0,h.yk)()){constructor(...t){super(...t),this._m_handlerMgr=null,this.cfgdata=void 0}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=S.h.Get()),
this._m_handlerMgr}InitView(){}AddLis(){}RemoveLis(){}Clear(){}Destroy(){}SetData(t){this.AddLis(),this.cfgdata=t,this.txtname.textSet(t.name)}_DelayMarkAsChanged(){}}var D;(0,
o.s_)(g.o.EffectShowEditor,u.Z.ui_effectshoweditor_effectshowEditor).register()(D=class extends((0,h.Ri)()){constructor(...t){super(...t),this.s_pages=new I.Z([0,1,2,3,4]),
this.s_vals=new I.Z([{name:"角度",field:"angle"},{name:"缩放",field:"scale"},{name:"前移",field:"offset"},{name:"右移",field:"offsetRight"},{name:"垂直",field:"offsetY"},{name:"延迟",
field:"delay"}]),this.m_idx=0,this.m_curCfg=void 0,this.TimeId=null,this.vmcView=void 0}_initBinder(){super._initBinder()}InitView(){
this.itemtable.SetInitInfo("ui_effectshoweditor_effectshowItem",this.CreateDelegate(this.OnCreateRawItem),A),
this.itemtable.OnReposition_set(this.CreateDelegate(this.OnRepositionRawList)),this.closeBtn.node.on(s.NodeEventType.TOUCH_END,this.OnBtnCloseView,this,!1),
this.btnPlay.node.on(s.NodeEventType.TOUCH_END,this.onClickPlay,this,!1)
var t=this
t.btnReadCfg.node.on(s.NodeEventType.TOUCH_END,this.onRead,this,!1),this.btnClear.node.on(s.NodeEventType.TOUCH_END,(function(){n.setJSON("EffectShowEditor_fx_"+t.m_idx,""),
t.refresh()}),this,!1),this.actName.node.on("text-changed",(function(){n.setItem("EffectShowEditor_actName",t.actName.string)})),
this.effect.node.on("text-changed",this.onInputFinishstringValue,this,!1,["effect"]),this.num.node.on("text-changed",this.onInputFinishRangeValue,this,!1,["num"]),
this.time.node.on("text-changed",this.onInputFinishRangeValue,this,!1,["time"]),this.ballType.node.on("text-changed",this.onInputFinishIntValue,this,!1,["ballType"]),
this.angleType.node.on("text-changed",this.onInputFinishIntValue,this,!1,["angleType"]),this.skillspeed.node.on("text-changed",this.onInputFinishIntValue,this,!1,["skillspeed"]),
this.color.node.on("text-changed",this.onInputFinishIntValue,this,!1,["color"]),this.ballParams.node.on("text-changed",this.onInputFinishstringValue,this,!1,["ballParams"]),
this.offset.node.on("text-changed",this.onInputFinishstringValue,this,!1,["offsetXY"]),this.perspective.node.on(s.NodeEventType.TOUCH_END,this.checkBoxCallBack,this,!1),
this.isReleaseFrame.node.on(s.NodeEventType.TOUCH_END,this.checkisReleaseFrame,this,!1),this.isFollow.node.on(s.NodeEventType.TOUCH_END,this.checkisFollow,this,!1),
null==this.TimeId&&(this.TimeId=E.C.Inst_get().SetInterval((function(){t.curEffectCount.string="cur:"+p.a.ins.effectCount+"  curplayer: "+INS.settingMainControl.curPlayerEffNum
}),200)),this.btnTest.node.on(s.NodeEventType.TOUCH_END,(0,T.r)(this.TestPlay,this)),this.showBtn.node.on(s.NodeEventType.TOUCH_END,(0,T.r)(this.ShowTest,this)),
this.btnLogCurEffect.node.on(s.NodeEventType.TOUCH_END,(0,T.r)(this.LogEffect,this)),this.urlEdit.string="skill/x5/dj00_01_01.json",this.actNameEdit.string="90",this.ShowTest()}
OnCreateRawItem(t){console.log(t)}OnRepositionRawList(){const t=this.itemtable.itemList.Count()
for(let e=0;e<=t-1;e++){const t=this.itemtable.itemList[e]
let i=t.cfgdata
if(!this.m_curCfg||!i)return
t.txtname.text=i.name
let s=t.angle1
s.node.on("text-changed",this.onInputFinishRangeValue,this,!1,[i.field+"Start"]),s.string=this.m_curCfg[i.field+"Start"]+"",this.onInputFinishRangeValue(i.field+"Start",s)
let n=t.angle2
n.node.on("text-changed",this.onInputFinishRangeValue,this,!1,[i.field+"Space"]),n.string=this.m_curCfg[i.field+"Space"]+"",this.onInputFinishRangeValue(i.field+"Space",n)}}
checkisReleaseFrame(t){this.isReleaseFrame1.active=!this.isReleaseFrame1.active,n.setItem("EffectShowEditor_isReleaseFrame",this.isReleaseFrame1.active?"1":"0")}checkisFollow(t){
this.isFollow1.active=!this.isFollow1.active,n.setItem("EffectShowEditor_isFollow",this.isFollow1.active?"1":"0")}OnBtnCloseView(){
null!=this.TimeId&&(E.C.Inst_get().ClearInterval(this.TimeId),this.TimeId=null),(0,d.sR)(g.o.EffectShowEditor)}onRead(){let t=this.cfgId.string
if(!t)return
let e=C.r.ins.getEffectShowCfg(t,!1)
if(e)n.setJSON("EffectShowEditor_fx_"+this.m_idx,e),this.refresh()
else{let e="找不到特效,id:"+t
N.y.inst.ClientStrMsg(v.r.SystemTipMessage,e)}}checkBoxCallBack(t){this.perspective1.active=!this.perspective1.active
var e=this.perspective1.active?1:0
this.m_curCfg.perspective=e,n.setJSON("EffectShowEditor_fx_"+this.m_idx,this.m_curCfg)}onUpdateFun(){
self.curEffectCount.string="cur:"+p.a.ins.effectCount+"  curplayer: "+INS.settingMainControl.curPlayerEffNum}refresh(){
this.actName.string=n.getItem("EffectShowEditor_actName")||"act05",this.isReleaseFrame1.active="1"==n.getItem("EffectShowEditor_isReleaseFrame"),
this.isFollow1.active="1"==n.getItem("EffectShowEditor_isFollow"),this.m_curCfg=new f.i,this.m_curCfg.parseByJson(n.getJSON("EffectShowEditor_fx_"+this.m_idx)),
this.effect.string=this.m_curCfg.effect,this.urlEdit.string="skill/"+this.m_curCfg.effect+".json",this.num.string=this.m_curCfg.num+"",this.time.string=this.m_curCfg.time+"",
this.angleType.string=this.m_curCfg.angleType+"",this.ballType.string=this.m_curCfg.ballType+"",this.skillspeed.string=this.m_curCfg.skillspeed+"",
this.color.string=this.m_curCfg.color+"",this.ballParams.string=this.m_curCfg.ballParams,this.perspective1.active=1==this.m_curCfg.perspective,this.itemtable.Clear(),
this.itemtable.data_set(this.s_vals)}onInputFinishstringValue(t,e){let i=t
this.m_curCfg[i]=e.string,n.setJSON("EffectShowEditor_fx_"+this.m_idx,this.m_curCfg)}onInputFinishIntValue(t,e){let i=t
this.m_curCfg[i]=parseInt(e.string),n.setJSON("EffectShowEditor_fx_"+this.m_idx,this.m_curCfg)}onInputFinishRangeValue(t,e){let i=t
this.m_curCfg[i].parseByString(e.string),n.setJSON("EffectShowEditor_fx_"+this.m_idx,this.m_curCfg)}onClickPlay(t){let e=m.Y.Inst.primaryRole
if(!e)return
let i=n.getItem("EffectShowEditor_actName"),s="1"==n.getItem("EffectShowEditor_isReleaseFrame"),a="1"==n.getItem("EffectShowEditor_isFollow"),l=new Array
for(let t=0;t<this.s_pages.length;++t){let e=new f.i
e.parseByJson(n.getJSON("EffectShowEditor_fx_"+t)),e.onBody=a?1:0,e.effect&&e.num&&l.push(e)}if(0==l.length)return
let r=m.Y.Inst.getNearestCharacterDic(m.Y.MonsterDic,10,!1)
null==r&&(r=e)
let[o,h]=(0,_.cH)(e.GetPos().x,e.GetPos().z),d=new c.E(o,h)
p.a.ins.playActAndEffects(e,r,e,i,l,1,s,d,!0)}ShowTest(){this.node.getChildByName("eff_test").active=!this.node.getChildByName("eff_test").active}LogEffect(){
const t=p.a.ins._uidMap
console.log(t)}TestPlay(){if(!this.vmcView){this.vmcView=l.n.createVMC(l.n.VMCType.SELF),this.vmcView.setPosition(0,0)
let t=new s.Node("skill_eff_test")
t.parent=r.n.gameStage.scene.getSceneLayer(a.W.Top)
const e=m.Y.Inst.PrimaryRole_get()
let[i,n]=(0,_.cH)(e.GetPos().x,e.GetPos().z)
t.position=new s.math.Vec3(i,n,0),t.addChild(this.vmcView.node)}let t=this.urlEdit.string
this.vmcView.loadVMCData(t),this.vmcView.vmcData?this._onloadVmcView():this.vmcView.node.once(l.n.DATA_COMPLETE,this._onloadVmcView,this)}_onloadVmcView(){
let t=this.actNameEdit.string,e=Number(this.actNameEdit.string)
0==e||e||(e=Number(this.actNameEdit.string.split("_")[1])),this.vmcView.updatePose(this.vmcView.vmcData.url,e,0,null,null,t)}})}},t=>{
t.O(0,[277,16,5,253,831,14,136,128,979,748,489,23],(()=>{return e=45480,t(t.s=e)
var e}))
t.O()}])
