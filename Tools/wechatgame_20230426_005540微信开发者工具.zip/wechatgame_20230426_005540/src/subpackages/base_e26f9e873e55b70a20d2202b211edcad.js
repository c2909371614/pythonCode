(()=>{"use strict"
var e,t={69641:(e,t,i)=>{i.d(t,{o:()=>s})
class s{}s.LuaCallBackMgr=void 0,s.CharacterMgr=void 0,s.UIUtilBridge=void 0,s.LuaDisplayBridgeManager=void 0,s.JoystickControl=void 0,s.LostHpManager=void 0,s.getServiceVo=void 0,
s.getServiceVoId=void 0,s.LusuoLong=void 0},87234:(e,t,i)=>{i.d(t,{F:()=>n})
var s=i(18998)
class n extends s.Component{constructor(...e){super(...e),this._x=0,this._y=0}setVisible(e){const t=this.node
t.visible!=e&&(e?(t.x=this._x,t.y=this._y):(this._x=t.x,this._y=t.y,t.x=1e4,t.y=1e4),this.node.visible=e)}addView(e,t){
t._childIndex>=0?this.node.insertChild(e,t._childIndex):e.parent=this.node}removeView(e,t){this.node.removeChild(e)}}},85688:(e,t,i)=>{i.d(t,{n:()=>l})
var s=i(18998),n=i(87234),r=i(21370)
const o=[r.T.nav,r.T.sound,r.T.npcTalk,r.T.panel,r.T.Alert,r.T.tip,r.T.guide,r.T.msg,r.T.effect],a=[],h=new Map
class l extends s.Component{constructor(){super(),l.ins=this}addToLayer(e,t,i){const s=h.get(e)
return!!s&&(i._fullTest&&!i.isPanelActive()||this.invalid(),s.addView(t,i),!0)}removeFromLayer(e,t,i){const s=h.get(e)
s&&(this.invalid(),s.removeView(t,i))}invalid(){}getLayer(e){return h.get(e).node}setLayerVisible(e,t){const i=h.get(e)
i&&i.setVisible(t)}init(){if(a.length>0)throw new Error("repeat LayerCtrl.init()")
const e=s.sys.getSafeAreaRect(),t=this.node
for(let i=0;i<o.length;i++){const l=o[i],d=new s.Node
d.name=(0,r.L)(l)
const c=d.getOrAddComponent(s.UITransform)
c.setContentSize(e.width,e.height),c.setAnchorPoint(.5,.5),d.setPosition(.5*e.x,.5*e.y)
const u=d.addComponent(n.F)
a.push(u),h.set(l,u),t.addChild(d)}}}l.ins=void 0},21370:(e,t,i)=>{i.d(t,{L:()=>n,T:()=>s})
var s={None:-1e3,scene:-999,nav:-998,sound:-997,npcTalk:-996,panel:-995,Alert:-994,tip:-993,guide:-992,msg:-991,effect:-990}
function n(e){switch(e){case s.None:return""
case s.scene:return"LayerScene"
case s.nav:return"LayerNav"
case s.sound:return"LayerSound"
case s.npcTalk:return"LayerNpcTalk"
case s.panel:return"LayerPanel"
case s.tip:return"LayerTip"
case s.guide:return"LayerGuide"
case s.Alert:return"LayerAlert"
case s.msg:return"LayerMsg"
case s.effect:return"LayerEffect"
default:}return""}},34441:(e,t,i)=>{i.d(t,{X:()=>s})
const s=i(75507).o.LoaderCache},75507:(e,t,i)=>{i.d(t,{o:()=>n})
var s=i(18998)
const n=s.js.getClassByName("launch.LoaderDock")},42292:(e,t,i)=>{i.d(t,{n:()=>R,Vu:()=>M,Dr:()=>E,wT:()=>v,Y_:()=>S,Vx:()=>I,gK:()=>C,bD:()=>P,Iu:()=>b,j4:()=>x,O$:()=>L,ll:()=>T,
aH:()=>O})
var s=i(18998),n=0,r=1,o=2
const a="__$cus_clsArray__",h="__$cus_valArray__",l="__$cus_propertyNames__",d=new Map
function c(e,t){if(function(e){return!0===u[e]}(t))return
const i=e,s=i[l]||(i[l]=[])
if(-1!==s.indexOf(t))return
const c=Object.getOwnPropertyDescriptor(e,t),_=c?c.get?c.get.call(e):c.value:void 0,m=i[a]||(i[a]=[]),y=i[h]||(i[h]=[]),g=s.length
s.push(t)
const p=function(e,t,i){const s={enumerable:!0,configurable:!1}
return s.get=()=>{const s=t[i]
if(s)return s
const a=e[i]
if(a){const e=function(e,t){let i
switch(t){case n:i=new e
break
case r:i=e
break
case o:i=b(e)
break
default:console.error(`unsupport BeanType: ${t}`)}return null!=i&&t!=n&&t!=r&&i!=e&&"function"==typeof i&&(i=i()),null==i&&console.error("bean createDesc error"),i}(a,d.get(a))
return t[i]=e,e}},s.set=s=>{if(null!=s)if("function"==typeof s)e[i]=s,t[i]=void 0
else{const n=Object.getPrototypeOf(s).constructor
"function"==typeof n&&(e[i]=n,t[i]=s)}else t[i]=null},s}(m,y,g)
Object.defineProperty(e,t,p),void 0!==_&&null!=p.set&&p.set.call(e,_)}const u={constructor:!0,prototype:!0,arguments:!0,caller:!0,length:!0,name:!0}
const _=(()=>{const e=__$LaunchLogicBridge._launchClsMap
return e?Object.assign(Object.create(null),e):Object.create(null)})(),m=new Map,y=new WeakMap,g=new Map
let p,f=null,w=null
function v(e){return t=>{void 0!==_[e]&&(0,s.error)(`[common] repeat clsname '${e}'`),_[e]=t}}function S(e){return t=>{void 0!==_[e]&&(0,s.error)(`[common] repeat clsname '${e}'`),
_[e]=t}}function C(e){return t=>{void 0!==_[e]&&(0,s.error)(`[common] repeat clsname '${e}'`),_[e]=t}}function I(e,t,i){if("object"==typeof e){const i=e.constructor.name
throw new Error(`GETINS need a static method '${i}.${t}'`)}const s=i.get||i.value
g.set(e,s),(f||(f=new Set)).add(e)}function R(e,t,i){if("object"==typeof e){const i=e.constructor.name
throw new Error(`AUTOGETINS need a static method '${i}.${t}'`)}const s=i.get||i.value
g.set(e,s),(f||(f=new Set)).add(e),(w||(w=new Set)).add(e)}function b(e){const t=g.get(e)
if(null==t)throw new Error(`${e.name} should deco @GETINS or @AUTOGETINS`)
return t.call(e)}function T(e){return _[e]}function L(e){return s.js.getClassByName(e)}function M(e){return(t,i)=>{const s={}
y.set(s,t)
let r=m.get(e)
r||(r=[],m.set(e,r))
const o=n
r.push({targetKey:s,beanType:o,propertyKey:i})}}function E(e,t=o){return(i,s)=>{t!=n&&c(i,s)
const r={}
y.set(r,i)
let o=m.get(e)
o||(o=[],m.set(e,o)),o.push({targetKey:r,beanType:t,propertyKey:s})}}function x(e){p=e}let A=!1
function P(){A=!0,w&&(w.forEach((e=>{b(e)})),w=null)}function O(){m.forEach(((e,t,i)=>{const r=_[t]
if(r){i.delete(t)
for(let t=0;t<e.length;t++){const i=e[t],h=y.get(i.targetKey)
if(y.delete(i.targetKey),h)if(i.beanType==n)try{h[i.propertyKey]=new r}catch(e){(0,s.error)(e)}else o=r,a=i.beanType,d.set(o,a),h[i.propertyKey]=r}var o,a}else(0,
s.error)(`[common] _doBean: need CLASS '${t}'`)})),p&&p(f),f=null,A&&P()}},89123:(e,t,i)=>{i.d(t,{SK:()=>d})
i(18998),i(22267)
var s=i(69641)
class n{constructor(e=0,t=0){this.low=void 0,this.internalHigh=void 0,this.low=e,this.internalHigh=t}div(e){const t=this.internalHigh%e,i=(this.low%e+6*t)%e
this.internalHigh/=e
const s=(4294967296*t+this.low)/e
return this.internalHigh+=Math.floor(s/4294967296),this.low=s,i}mul(e){const t=Number(this.low)*e
this.internalHigh*=e,this.internalHigh+=Math.floor(t/4294967296),this.low*=e}add(e){const t=Number(this.low)+e
this.internalHigh+=Math.floor(t/4294967296),this.low=t}bitwiseNot(){this.low=~this.low,this.internalHigh=~this.internalHigh}}n.CHAR_CODE_0="0".charCodeAt(0),
n.CHAR_CODE_9="9".charCodeAt(0),n.CHAR_CODE_A="a".charCodeAt(0),n.CHAR_CODE_Z="z".charCodeAt(0)
class r extends n{get high(){return this.internalHigh}constructor(e=0,t=0){super(e,t),this.strArr=[]}equal(e){
return this===e||(!this||null!=e)&&(!!e&&(e.high==this.high&&e.low==this.low))}equalStr(e){return this===e||(!this||null!=e)&&this.toString()==e.toString()}isEmpty(){
return 0==this.high&&0==this.low}static create(e=0,t=0){
return e==r.ZERO.low&&t==r.ZERO.high?r.ZERO:e==r.ONE.low&&t==r.ONE.high?r.ONE:e==r.SIGN.low&&t==r.SIGN.high?r.SIGN:e==r.MARK.low&&t==r.MARK.high?r.MARK:new r(e,t)}
static fromNumber(e){return r.create(e%4294967296,Math.floor(e/4294967296))}toNumber(){return 4294967296*this.high+this.low}toString(e=10){
if(this.strArr&&this.strArr[e])return this.strArr[e]
if(e<2||e>36)throw new Error("指定要用于数字到字符串的转换的基数不在从 2 到 36 的范围内")
if(0==this.high)return this.strArr[e]=this.low.toString(e),this.strArr[e]
let t=`00000000000000000000000000000000${this.low.toString(2)}`
t=this.high.toString(2)+t.substr(t.length-32)
const i=[],s=[1]
for(let n=t.length-1;n>=0;n--)"1"==t.substr(n,1)&&this.addBit(i,s,e),this.addBit(s,s,e)
let n=""
for(let e=i.length-1;e>=0;e--)n+="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ".substr(i[e],1)
return this.strArr||(this.strArr=[]),this.strArr[e]=n,this.strArr[e]}static fromString(e){if(!e)return r.ZERO
const t=(e=e.split(".")[0]).match(/\d/g)
let i,s=0
const n=t.length
for(i=0;i<n;i++)t[i]=parseInt(t[i])
let o=""
for(;0==t[0]&&t.shift(),0!=t.length;){for(i=0;i<t.length;i++)s&&(t[i]+=10*s,s=0),s=t[i]%16,t[i]>>=4
o="0123456789ABCDEF".substr(s,1)+o,s=0}let a,h
return o||(o="0"),o.length>8?(a=parseInt(`0x${o.substr(0,o.length-8)}`),h=parseInt(`0x${o.substr(o.length-8,8)}`)):(a=0,h=parseInt(`0x${o}`)),r.create(h,a)}static indexOf(e,t){
if(!t)return-1
for(let i=0,s=e?e.length:0;i<s;i++)if(t==e[i]||t.equal(e[i]))return i
return-1}addBit(e,t,i){let s,n=!1
const r=Math.max(e.length,t.length)
for(s=0;s<r;s++)s>=e.length&&(e[s]=0),s>=t.length&&(t[s]=0),e[s]+=t[s],n&&e[s]++,n=!1,e[s]>=i&&(e[s]-=i,n=!0)
return n&&e.push(1),e}static compare(e,t){return e&&t?e.high>t.high?1:e.high<t.high?-1:e.low>t.low?1:e.low<t.low?-1:0:-1}static parselong(e,t=0){let i=0
0==t&&(0==e.indexOf("0x")?(t=16,i=2):t=10),e=e.toLowerCase()
const s=new r
for(;i<e.length;i++){let r=e.charCodeAt(i)
r>=n.CHAR_CODE_0&&r<=n.CHAR_CODE_9?r-=n.CHAR_CODE_0:r>=n.CHAR_CODE_A&&r<=n.CHAR_CODE_Z&&(r-=n.CHAR_CODE_A,r+=10),s.mul(t),s.add(r)}return r.create(s.low,s.high)}and(e){
const t=this.internalHigh&e.internalHigh,i=this.low&e.low
return r.create(i,t)}or(e){let t=this.internalHigh|e.internalHigh
t=this.uintBitFix(t)
let i=this.low|e.low
return i=this.uintBitFix(i),r.create(i,t)}xor(e){let t=this.internalHigh^e.internalHigh
t=this.uintBitFix(t)
let i=this.low^e.low
return i=this.uintBitFix(i),r.create(i,t)}byteValue(){return 255&this.low}shiftRight(e){if(0==e)return this
if(e>63)return this
let t=this.internalHigh,i=this.low
let s,n
Math.floor(e/32)>0&&(i=t,t=t>=0?0:-1),e%=32
let o=0
for(n=0;n<e;n++)o|=1<<n,o=this.uintBitFix(o)
return s=i&o,i>>>=e,s=t&o,i|=s<<32-e,i=this.uintBitFix(i),t>>=e,r.create(i,t)}shiftRightNo(e){if(0==e)return this
if(e>63)return this
let t=this.internalHigh,i=this.low
let s,n
Math.floor(e/32)>0&&(i=t,t=0),e%=32
let o=0
for(n=0;n<e;n++)o|=1<<n,o=this.uintBitFix(o)
return s=i&o,i>>>=e,s=t&o,i|=s<<32-e,i=this.uintBitFix(i),t>>>=e,r.create(i,t)}shiftLeft(e){if(0==e)return this
if(e>63)return r.create(0,0)
if(32==e)return r.create(0,this.low)
let t=this.internalHigh,i=this.low
let s,n
Math.floor(e/32)>0&&(t=i,i=0),e%=32
let o=0
for(n=1;n<=e;n++)o|=1<<32-n,o=this.uintBitFix(o)
return s=t&o,t<<=e,s=i&o,t|=s>>>32-e,t=this.uintBitFix(t),i<<=e,r.create(i,t)}uintBitFix(e){return e<0&&(e=4294967296+e),e}}r.ZERO=new r,r.ONE=new r(1,0),
r.SIGN=new r(4294967295,4294967295),r.MARK=new r(4294967168,4294967295)
class o{static readInt(e){return o.decodeZigZag32(o.readRawVarint32(e))}static writeInt(e,t){o.writeRawVarint32(t,o.encodeZigZag32(e))}static readLong(e){
return o.decodeZigZag64(o.readRawVarint64(e))}static writeLong(e,t){o.writeRawVarint64(t,o.encodeZigZag64(e))}static readLusuoLong(e){
return o.decodeZigZag64LusuoLong(o.readRawVarint64LusuoLong(e))}static writeLusuoLong(e,t){o.writeRawVarint64LusuoLong(t,o.encodeZigZag64LusuoLong(e))}static readRawVarint32(e){
return o.readRawVarint64SlowPath(e)}static writeRawVarint32(e,t){for(;;){if(0==(-128&t))return void o.writeRawByte(e,t)
o.writeRawByte(e,127&t|128),t>>>=7}}static readRawVarint64SlowPath(e){let t=0
for(let i=0;i<64;i+=7){const s=o.readRawByte(e)
if(t|=(127&s)<<i,0==(128&s))return t}throw new Error("readRawVarint64SlowPath")}static readRawByte(e){return e.readByte()}static writeRawByte(e,t){e.writeByte(t)}
static encodeZigZag32(e){return e<<1^e>>31}static decodeZigZag32(e){return e>>>1^-(1&e)}static decodeZigZag64(e){const t=e.shiftRightNo(1),i=0==(1&e.low)?r.ZERO:r.SIGN
return t.xor(i)}static decodeZigZag64LusuoLong(e){const t=e.shiftRightNo(1),i=0==(1&e.low)?s.o.LusuoLong.ZERO:s.o.LusuoLong.SIGN
return t.Xor(i)}static encodeZigZag64(e){const t=e.shiftLeft(1),i=e.shiftRight(63)
return t.xor(i)}static encodeZigZag64LusuoLong(e){const t=e.shiftLeft(1),i=e.shiftRight(63)
return t.Xor(i)}static readRawVarint64(e){let t=0,i=r.create()
for(;t<64;){const s=e.readByte()
let n=r.create(127&s,0)
if(n=n.shiftLeft(t),i=i.or(n),0==(128&s))return i
t+=7}return i}static readRawVarint64LusuoLong(e){let t=0,i=s.o.LusuoLong.create()
for(;t<64;){const n=e.readByte()
let r=s.o.LusuoLong.create(127&n,0)
if(r=r.shiftLeft(t),i=i.Or(r),0==(128&n))return i
t+=7}return i}static writeRawVarint64(e,t){for(;;){const i=t.byteValue()
if(t.and(r.MARK).equal(r.ZERO))return void this.writeRawByte(e,i)
this.writeRawByte(e,127&i|128),t=t.shiftRightNo(7)}}static writeRawVarint64LusuoLong(e,t){for(;;){const i=t.ByteValue()
if(t.And(s.o.LusuoLong.MARK).Equal(s.o.LusuoLong.ZERO))return void this.writeRawByte(e,i)
this.writeRawByte(e,127&i|128),t=t.shiftRightNo(7)}}}const a="littleEndian"
var h=7
const l={1:-11,2:-14,3:-13,4:-14,5:-14,6:-15,7:-14,8:-10,9:-14,10:-18,15:-24,16:-33,17:-14,25:-14}
class d{constructor(e=null){this._len=0,this._position_=0,this._data_=null,this._littleEndian_=!1,this._byteView_=null,this.powTwo=!1,
"number"==typeof e?this.___resizeBuffer(e):e?this.setUint8Array(new Uint8Array(e)):this.___resizeBuffer(8)}ensureWrite(e){this._len<e&&(this.length=e)}readBoolean(){
return 0!==this.readByte()}readByte(){return this._data_.getInt8(this._position_++)}getByte(e){return this._data_.getInt8(e)}readBytes(e,t=0,i=0){
if(t<0||i<0)throw new Error("Read error - Out of bounds")
const s=0===i?this._len-this._position_:i
e.ensureWrite(t+s),e._byteView_.set(this._byteView_.subarray(this._position_,this._position_+s),t),e.position=t,this._position_+=s,e.position+s>e.length&&(e.length=e.position+s)}
readUint8Array(e=0){if(e<0)throw new Error("Read error - Out of bounds")
const t=0===e?this._len-this._position_:e,i=this._position_
return this._position_+=t,this._byteView_.subarray(i,i+t)}readDouble(){const e=this._data_.getFloat64(this._position_,this._littleEndian_)
return this._position_+=8,e}readLong(){return 1*this.readUnsignedInt()*4294967296+this.readUnsignedInt()}readFloat(){
const e=this._data_.getFloat32(this._position_,this._littleEndian_)
return this._position_+=4,e}readInt(){const e=this._data_.getInt32(this._position_,this._littleEndian_)
return this._position_+=4,e}readShort(){const e=this._data_.getInt16(this._position_,this._littleEndian_)
return this._position_+=2,e}readUnsignedByte(){return this._data_.getUint8(this._position_++)}readUnsignedInt(){const e=this._data_.getUint32(this._position_,this._littleEndian_)
return this._position_+=4,Math.floor(e)}readUnsignedShort(){const e=this._data_.getUint16(this._position_,this._littleEndian_)
return this._position_+=2,e}readUTF(){const e=this.readUnsignedShort()
return e>0?this.readUTFBytes(e):""}readVarString(){const e=this.readVarInt()
return e>0?this.readUTFBytes(e):""}readString(){const e=this.readUnsignedShort()
return e>0?this.readUTFBytes(e):""}readUnicode(e){let t=""
const i=this._position_+e
let s,n
for(;this._position_<i;)n=this._byteView_[this._position_++],s=this._byteView_[this._position_++],t+=String.fromCharCode(s<<8|n)
return t}readMultiByte(e,t){return"UNICODE"===t||"unicode"===t?this.readUnicode(e):this.readUTFBytes(e)}readUTFBytes(e=-1){let t=""
const i=this._position_+e
let s,n,r
const o=String.fromCharCode
for(;this._position_<i;)s=this._data_.getUint8(this._position_++),s<128?0!==s&&(t+=o(s)):s<224?t+=o((63&s)<<6|127&this._data_.getUint8(this._position_++)):s<240?(n=this._data_.getUint8(this._position_++),
t+=o((31&s)<<12|(127&n)<<6|127&this._data_.getUint8(this._position_++))):(n=this._data_.getUint8(this._position_++),r=this._data_.getUint8(this._position_++),
t+=o((15&s)<<18|(127&n)<<12|r<<6&127|127&this._data_.getUint8(this._position_++)))
return t.charCodeAt(0),t}writeBoolean(e){this.writeByte(e?1:0)}writeByte(e){this.ensureWrite(this._position_+1),this._data_.setInt8(this._position_,e),this._position_+=1}
writeUnsignedByte(e){this.ensureWrite(this._position_+1),this._data_.setUint8(this._position_,e),this._position_+=1}writeBytes(e,t=0,i=0){
if(t<0||i<0)throw new Error("writeBytes error - Out of bounds")
const s=0===i?e.length-t:i
this.ensureWrite(this._position_+s),this._byteView_.set(e._byteView_.subarray(t,t+s),this._position_),this._position_+=s}writeArrayBuffer(e,t=0,i=0){
if(t<0||i<0)throw new Error("writeArrayBuffer error - Out of bounds")
const s=0===i?e.byteLength-t:i
this.ensureWrite(this._position_+s)
const n=new Uint8Array(e)
this._byteView_.set(n.subarray(t,t+s),this._position_),this._position_+=s}writeUint8Array(e,t=0,i=0){if(t<0||i<0)throw new Error("writeArrayBuffer error - Out of bounds")
const s=0===i?e.byteLength-t:i
this.ensureWrite(this._position_+s),this._byteView_.set(e.subarray(t,t+s),this._position_),this._position_+=s}writeDouble(e){this.ensureWrite(this._position_+8),
this._data_.setFloat64(this._position_,e,this._littleEndian_),this._position_+=8}writeLong(e){let t,i
0!==e&&(e>Number.MAX_VALUE||e<Number.MIN_VALUE)&&console.error("writeLong error - Out of bounds"),e>0?(t=e%4294967296,i=(e-1*t)/4294967296):(t=e%-4294967296,i=4294967295,
e<-4294967296&&(t||i++,i+=(e-1*t)/4294967296),t+=4294967296),this.writeUnsignedInt(i),this.writeUnsignedInt(t)}writeFloat(e){this.ensureWrite(this._position_+4),
this._data_.setFloat32(this._position_,e,this._littleEndian_),this._position_+=4}writeInt(e){this.ensureWrite(this._position_+4),
this._data_.setInt32(this._position_,e,this._littleEndian_),this._position_+=4}writeShort(e){this.ensureWrite(this._position_+2),
this._data_.setInt16(this._position_,e,this._littleEndian_),this._position_+=2}writeUnsignedInt(e){this.ensureWrite(this._position_+4),
this._data_.setUint32(this._position_,e,this._littleEndian_),this._position_+=4}writeUnsignedShort(e){this.ensureWrite(this._position_+2),
this._data_.setUint16(this._position_,e,this._littleEndian_),this._position_+=2}writeString(e){this.writeUnsignedShort(d._getUTFBytesCount(e)),this.writeUTFBytes(e)}writeUTF(e){
this.writeUnsignedShort(d._getUTFBytesCount(e)),this.writeUTFBytes(e)}writeVarString(e){this.writeVarInt(d._getUTFBytesCount(e)),this.writeUTFBytes(e)}writeUnicode(e){let t
this.ensureWrite(this._position_+2*e.length)
for(let i=0,s=e.length;i<s;i++)t=e.charCodeAt(i),this._byteView_[this._position_++]=255&t,this._byteView_[this._position_++]=t>>8}writeMultiByte(e,t){
"UNICODE"===t||"unicode"===t?this.writeUnicode(e):this.writeUTFBytes(e)}writeUTFBytes(e){this.ensureWrite(this._position_+4*e.length)
for(let t=0,i=e.length;t<i;t++){const i=e.charCodeAt(t)
i<=127?this.writeByte(i):i<=2047?(this.writeByte(192|i>>6),this.writeByte(128|63&i)):i<=65535?(this.writeByte(224|i>>12),this.writeByte(128|i>>6&63),
this.writeByte(128|63&i)):(this.writeByte(240|i>>18),this.writeByte(128|i>>12&63),this.writeByte(128|i>>6&63),this.writeByte(128|63&i))}this.length=this._position_}_get(e){
return this._data_.getUint8(e)}_set(e,t){this._data_.setUint8(e,t)}_byteAt_(e){return this._byteView_[e]}_byteSet_(e,t){this.ensureWrite(e+1),this._byteView_[e]=t}
static _getUTFBytesCount(e){let t=0
for(let i=0,s=e.length;i<s;i++){const s=e.charCodeAt(i)
t+=s<=127?1:s<=2047?2:s<=65535?3:4}return t}gunzip(e){{const e=new Zlib.Gunzip(this._byteView_)
this._byteView_=e.decompress()}this._data_=new DataView(this._byteView_.buffer),this._len=this._byteView_.byteLength,this._allocated_=this._len,this._position_=0}uncompress(){{
const e=new Zlib.Inflate(this._byteView_)
this._byteView_=e.decompress()}this._data_=new DataView(this._byteView_.buffer),this._len=this._byteView_.byteLength,this._allocated_=this._len,this._position_=0}
___resizeBuffer(e){try{const t=new Uint8Array(e)
null!=this._byteView_&&(this._byteView_.length<=e?t.set(this._byteView_):t.set(this._byteView_.subarray(0,e))),this._byteView_=t,this._data_=new DataView(t.buffer)}catch(e){}}
__getBuffer(){return this._data_.buffer}static _ofBuffer(e){const t=new d
return t.length=e.byteLength,t._data_=new DataView(e),t._byteView_=new Uint8Array(e),t}setUint8Array(e){this._byteView_=e,this._data_=new DataView(e.buffer),this._len=e.byteLength,
this._position_=0}get bytesAvailable(){return this.length-this._position_}get endian(){return this._littleEndian_?a:"bigEndian"}set endian(e){this._littleEndian_=e===a}
get length(){return this._len}set length(e){const t=this._byteView_?this._byteView_.length:0
let i=e
if(this.powTwo)for(i=t;i<e;)i*=2
t!==i&&this.___resizeBuffer(i),this._len=e}clipLength(){(this._byteView_?this._byteView_.length:0)!=this._len&&this.___resizeBuffer(this._len)}get position(){return this._position_
}set position(e){e<this._len?this._position_=e<0?0:e:(this._position_=e,this.length=e)}clear(){this._position_=0,this.length=0}toString(){const e=this._position_
this._position_=0
const t=this.readUTFBytes(this.length)
return this._position_=e,t}readList(e,t){const i=[]
if(-1==this.readVarInt())return i
const s=c[e].call(this)
if(0===s)return i
let n
if(1==this.readByte()&&(n=this.readVarInt()),t<15){const e=c[t]
for(let t=0;t<s;t++)i[t]=e.call(this)}else if(25===t)for(let e=0;e<s;e++)i[e]=this.readVo(n)
else if(t>0){const e=c[t],n=[]
for(let e=3;e<arguments.length;e++)n[e-3]=arguments[e]
for(let t=0;t<s;t++)i[t]=e.apply(this,n)}else{const e=null==t.create?t:null
for(let n=0;n<s;n++)i[n]=e?new e(this):t.create(this)}return i}writeList(e,t,i){const s=e?e.length:0
if(this.writeVarInt(-24),u[t].call(this,s),0!==s)if(this.writeByte(1),i<15){const t=u[i]
for(let n=0;n<s;n++)0==n&&this.writeVarInt(l[i]),t.call(this,e[n])}else if(25===i)for(let t=0;t<s;t++)this.writeVo(e[t],0==t)
else if(i>0){const t=u[i],n=[]
for(let e=4;e<arguments.length;e++)n[e-3]=arguments[e]
for(let i=0;i<s;i++)n[0]=e[i],t.apply(this,n)}else for(let t=0;t<s;t++)e[t].encode(this)}readArray(e,t){const i=[],s=c[e].call(this)
if(0===s)return i
let n
if(t<15){const e=c[t]
for(let t=0;t<s;t++)i[t]=e.call(this)}else if(25===t)for(let e=0;e<s;e++)n=this.readVarInt(),i[e]=-1==n?null:this.readVo(n)
else if(t>0){const e=c[t],n=[]
for(let e=3;e<arguments.length;e++)n[e-3]=arguments[e]
for(let t=0;t<s;t++)i[t]=e.apply(this,n)}else{const e=null==t.create?t:null
for(let n=0;n<s;n++)i[n]=e?new e(this):t.create(this)}return i}writeArray(e,t,i){const s=e?e.length:0
if(u[t].call(this,s),0!==s)if(this.writeByte(1),i<15){const t=u[i]
for(let n=0;n<s;n++)0==n&&this.writeVarInt(l[i]),t.call(this,e[n])}else if(25===i)for(let t=0;t<s;t++)this.writeVo(e[t],0==t)
else if(i>0){const t=u[i],n=[]
for(let e=4;e<arguments.length;e++)n[e-3]=arguments[e]
for(let i=0;i<s;i++)n[0]=e[i],t.apply(this,n)}else for(let t=0;t<s;t++)e[t].encode(this)}readMap(e,t,i){const s=new Map
if(-1==this.readVarInt())return s
const n=c[e].call(this)
if(0===n)return s
const r=255&this.readByte(),o=0==(2&r)
let a=0
0==(1&r)||this.readVarInt(),o||(a=this.readVarInt())
const h=c[i]
if(t<15){const e=c[t]
for(let t=0;t<n;t++)s.set(h.call(this),e.call(this))}else if(25===t)for(let e=0;e<n;e++){const e=h.call(this),t=this.readVo(a)
s.set(e,t)}else if(t>0){const e=c[t],i=[]
for(let e=3;e<arguments.length;e++)i[e-3]=arguments[e]
for(let t=0;t<n;t++)s.set(h.call(this),e.apply(this,i))}else{const e=null==t.create?t:null
for(let i=0;i<n;i++){const i=h.call(this),n=e?new e(this):t.create(this)
s.set(i,n)}}return s}readRecord(e,t,i){const s=Object.create(null),n=c[e].call(this)
if(0===n)return s
const r=c[i]
if(t<15){const e=c[t]
for(let t=0;t<n;t++){const t=r.call(this),i=e.call(this)
s[t]=i}}else if(t>0){const e=c[t],i=[]
for(let e=3;e<arguments.length;e++)i[e-3]=arguments[e]
for(let t=0;t<n;t++){const t=r.call(this),n=e.apply(this,i)
s[t]=n}}else{const e=null==t.create?t:null
for(let i=0;i<n;i++){const i=r.call(this),n=e?new e(this):t.create(this)
s[i]=n}}return s}writeMap(e,t,i,s){const n=e?e.size:0
if(this.writeVarInt(-33),u[t].call(this,n),0===n)return
this.writeByte(3),this.writeVarInt(l[s]),this.writeVarInt(l[i])
const r=u[s]
if(i<15){const t=u[i]
e.forEach(((e,i)=>{r.call(this,i),t.call(this,e)}))}else if(25===i)e.forEach(((e,t)=>{r.call(this,t),this.writeVo(e)}))
else if(i>0){const t=u[i],s=[]
for(let e=4;e<arguments.length;e++)s[e-3]=arguments[e]
e.forEach(((e,i)=>{r.call(this,i),s[0]=e,t.apply(this,s)}))}else e.forEach(((e,t)=>{r.call(this,t),e.encode(this)}))}writeRecord(e,t,i,s){
const n=Object.getOwnPropertyNames(e),r=n.length
if(u[t].call(this,r),0===r)return
const o=u[s],a=s<=h
if(i<15){const t=u[i]
for(let i=0;i<r;i++){const s=n[i]
o.call(this,a?Number(s):s),t.call(this,e[s])}}else if(i>0){const t=u[i],s=[]
for(let e=4;e<arguments.length;e++)s[e-3]=arguments[e]
for(let i=0;i<r;i++){const r=n[i]
o.call(this,a?Number(r):r),s[0]=e[r],t.apply(this,s)}}else for(let t=0;t<r;t++){const i=n[t]
o.call(this,a?Number(i):i),e[i].encode(this)}}readBufferArray(){const e=this.readVarInt()
if(0===e)return[]
const t=[]
for(let i=0;i<e;i++)t.push(this.readByte())
return t}readVarInt(){return o.readInt(this)}readVarLong(){return o.readLong(this)}readLusuoLong(){return o.readLusuoLong(this)}readVo(e){if(e||(e=this.readVarInt()),
-1==e)return null
return new(s.o.getServiceVo(e))(this)}writeVo(e,t=!0){if(t){const t=s.o.getServiceVoId(e)
this.writeVarInt(t)}e.encode(this)}writeVarInt(e){o.writeInt(e,this)}writeVarLong(e){o.writeLong(e,this)}writeLusuoLong(e){o.writeLusuoLong(e,this)}get isGZip(){
const e=this._byteView_
return 35615==(255&e[0]|e[1]<<8&65280)}}const c={1:d.prototype.readByte,2:d.prototype.readUnsignedByte,3:d.prototype.readShort,4:d.prototype.readVarInt,5:d.prototype.readInt,
6:d.prototype.readVarLong,7:d.prototype.readLong,8:d.prototype.readBoolean,9:d.prototype.readUTF,10:d.prototype.readVarString,15:d.prototype.readList,16:d.prototype.readMap,
17:d.prototype.readRecord},u={1:d.prototype.writeByte,2:d.prototype.writeUnsignedByte,3:d.prototype.writeShort,4:d.prototype.writeVarInt,5:d.prototype.writeInt,
6:d.prototype.writeVarLong,7:d.prototype.writeLong,8:d.prototype.writeBoolean,9:d.prototype.writeUTF,10:d.prototype.writeVarString,15:d.prototype.writeList,16:d.prototype.writeMap,
17:d.prototype.writeRecord}},54986:(e,t,i)=>{i.d(t,{o:()=>s})
class s{constructor(){this._gmLocalStorage=void 0}static get ins(){return this._ins||(this._ins=new s),this._ins}get isPrintProto(){return this.getGmLocalStorage().printProto||!1}
set isPrintProto(e){const t=this.getGmLocalStorage()
t.printProto!=e&&(t.printProto=e,this._saveGmLocalStorage())}get isPrintMoveProto(){return this.getGmLocalStorage().printMoveProto||!1}set isPrintMoveProto(e){
const t=this.getGmLocalStorage()
t.printMoveProto!=e&&(t.printMoveProto=e,this._saveGmLocalStorage())}get isCameraFar(){return this.getGmLocalStorage().cameraFar||!1}set isCameraFar(e){
const t=this.getGmLocalStorage()
t.cameraFar!=e&&(t.cameraFar=e,this._saveGmLocalStorage())}getGmLocalStorage(){if(!this._gmLocalStorage){const e=localStorage.getItem("_gmLocalStorage_")
this._gmLocalStorage=e?JSON.parse(e):{printProto:!1,printMoveProto:!1,cameraFar:!1}}return this._gmLocalStorage}_saveGmLocalStorage(){
localStorage.setItem("_gmLocalStorage_",`${JSON.stringify(this.getGmLocalStorage())}`)}}s._ins=void 0},71409:(e,t,i)=>{i.d(t,{BE:()=>m,GH:()=>c,Oo:()=>v,XC:()=>y,bG:()=>u})
i(22267)
var s=i(42292)
const n=new Map,r=Object.create(null),o=new Set,a=new Map,h=new Set,l=[],d=new Map
function c(e,t=0){return(i,s,r)=>{let o,a
"function"==typeof i?(o=i,a=!0):(o=i.constructor,a=!1)
const h=r.value
let c,u,_
Array.isArray(e)?(c=e,u=!0):(c=l,c[0]=e,u=!1)
for(let e=0;e<c.length;e++){const i=c[e]
if(null==i){console.error(`null msgId(${i}) in ${o.name}`)
continue}if(a){const e={methodVo:{msgId:i,method:h,priority:t,isArray:u},target:o}
let s=d.get(i)
if(s)for(let i=s.length-1;i>=0;i--){if(0==i){s.unshift(e)
break}if(s[i].methodVo.priority<=t){s.splice(i+1,0,e)
break}}else s=[e],d.set(i,s)}else _||(_=n.get(o),_||(_={ctor:o,lastMsgIndex:0,handlers:[]},n.set(o,_))),_.handlers.push({msgId:i,method:h,priority:t,isArray:u})}}}function u(e,t){
const i=a.get(e)
if(i){for(let e=0;e<i.length;e++){const t=i[e],n=(0,s.Iu)(t)
n&&m(n)}a.delete(e)}const n=d.get(e)
if(n)for(let i=0,s=n.length;i<s;i++){const s=n[i]
s&&_(e,s,t)}const o=r[e]
if(o){const i=o.neg,s=o.zero,n=o.pos
if(0!==o.sortType){const e=o.sortType
o.sortType=0,i&&i.length>1&&0!=(1&e)&&i.sort(S),n&&n.length>1&&0!=(2&e)&&n.sort(S)}const r=s?s.length:0,a=n?n.length:0
if(i)for(let s=0,n=i.length;s<n;s++){const n=i[s]
n&&_(e,n,t)}if(s)for(let i=0;i<r;i++){const n=s[i]
n&&_(e,n,t)}if(n)for(let i=0;i<a;i++){const s=n[i]
s&&_(e,s,t)}}}function _(e,t,i){const s=t.methodVo,n=t.target,r=s.method
try{s.isArray?void 0!==i?r.call(n,e,i):r.call(n,e):void 0!==i?r.call(n,i):r.call(n)}catch(t){const i=Object.getPrototypeOf(n),s=i&&i.constructor?i.constructor.name:""
let o=r.name
!o&&i&&(o=function(e,t){const i=Object.getOwnPropertyNames(e)
for(let s=0;s<i.length;s++)if(e[i[s]]===t)return i[s]
return""}(i,r)),console.error(`[msg] msgId: "${e}" method: "${s}.${o}"\n${t.message}`),console.error(t)}}function m(e){if(!e)return
let t=e.constructor
if(!t)return
"CharacterMgr"==t.name&&console.log(t.name)
if(!n.get(t))return
if(o.has(e))return
o.add(e)
const i=f(t)
i||console.log(i)
for(let t=0,s=i.length;t<s;t++){const s=i[t],n=s.msgId,o=s.priority,a=r[n]||(r[n]={sortType:0,neg:null,zero:null,pos:null
}),h=0===o?a.zero||(a.zero=[]):o<0?a.neg||(a.neg=[]):a.pos||(a.pos=[])
h.push({methodVo:s,target:e}),h.length>1&&(o<0?a.sortType|=1:o>0&&(a.sortType|=2))}}function y(e){if(!e)return
if(!o.has(e))return
o.delete(e)
let t=e.constructor
if(!t)return
const i=f(t)
for(let t=0,s=i.length;t<s;t++){const s=i[t],n=s.msgId,o=r[n]
if(o){const t=s.priority,i=0==t?o.zero:t<0?o.neg:o.pos
if(i)for(let t=0,s=i.length;t<s;t++){const s=i[t]
s&&s.target==e&&(i[t]=null,s.methodVo=null,s.target=null,h.add(n))}}}}const g=new Set,p=new Map
function f(e){"CharacterMgr"==e.name&&console.log(e.name)
let t=p.get(e)
if(void 0!==t)return t
g.clear()
const i=n.get(e)
if(i)for(let e=0;e<i.handlers.length;e++){const s=i.handlers[e];(t||(t=[])).push(s),g.add(s.msgId)}const s=Object.getPrototypeOf(e.prototype)
if(s&&s.constructor){const e=f(s.constructor)
if(e&&e.length)for(let i=0;i<e.length;i++){const s=e[i]
g.has(s.msgId)||((t||(t=[])).push(s),g.add(s.msgId))}}return g.clear(),p.set(e,t||null),t}let w=null
function v(e){(w||(w=new Set)).add(e)}function S(e,t){return e?t?e.methodVo.priority-t.methodVo.priority:e?-1:0:t?1:0}function C(){
window._isGameRestarting||(h.size>0&&(h.forEach((e=>{const t=r[e]
t.neg&&I(t.neg),t.zero&&I(t.zero),t.pos&&I(t.pos)})),h.clear()),cus.scheduleOnce(5,C))}function I(e){if(e.length>0)for(let t=e.length-1;t>=0;t--)e[t]||e.splice(t,1)}(0,
s.j4)((function(e){w&&(w.forEach((e=>{m(new e)})),w=null),e&&e.forEach((e=>{const t=f(e)
if(t)for(let i=0,s=t.length;i<s;i++){const s=t[i].msgId
let n=a.get(s)
n||(n=[],a.set(s,n)),n.push(e)}}))})),cus.addStaticCall((()=>{cus.scheduleOnce(5,C)})),globalThis.addObserver=m,globalThis.sendMessage=u},43585:(e,t,i)=>{i.d(t,{L:()=>s})
class s{constructor(e,t,i,s,n){if(this._capacity=0,this._cls=null,this._factory=null,this._recycle=void 0,this._pool=void 0,this._ignoreObjRecycle=!1,
e<0)throw new Error("illegal capacity")
if(!t&&!i)throw new Error("must has cls or factory")
t?this._cls=t:this._factory=i,this._capacity=e,this._recycle=s,this._ignoreObjRecycle=!!n,this._pool=[]}obtain(){
return this._pool.length>0?this._pool.pop():this._cls?new this._cls:this._factory.call(void 0)}release(e){null!=this._recycle&&this._recycle.call(void 0,e),
this._ignoreObjRecycle||"function"!=typeof e.recycle||e.recycle(),
this._pool.length<this._capacity?this._pool.push(e):"function"==typeof e.dispose?e.dispose():"function"==typeof e.destroy&&e.destroy()}has(e=1){return this._pool.length>=e}clear(){
const e=this._pool
for(;e.length>0;){const t=e.pop()
"function"==typeof t.dispose?t.dispose():"function"==typeof t.destroy&&t.destroy()}}}},78175:(e,t,i)=>{i.d(t,{FJ:()=>o,_e:()=>r})
var s=i(18998),n=i(42292)
function r(e,t){const i=(0,n.ll)(t)
return null!=i?e.getComponent(i):null}s.CCObject.Flags.PrevIsOnEnableCalled
__$LaunchLogicBridge._travelNode
const o=__$LaunchLogicBridge._MakeNodeGray},39407:(e,t,i)=>{i.d(t,{Fr:()=>u,IP:()=>h,KT:()=>_,QI:()=>r,RI:()=>y,RT:()=>m,Wg:()=>o,iP:()=>d,kJ:()=>l,n6:()=>c,pE:()=>a,t4:()=>p,
zM:()=>n})
const s=Object.prototype.hasOwnProperty
function n(e,t){return"object"==typeof e&&s.call(e,t)}function r(e){return"number"==typeof e}function o(e){const t=typeof e
return"string"===t||"number"===t}function a(e){return"boolean"==typeof e}function h(e){return!!e&&"object"==typeof e}function l(e){return Array.isArray(e)}function d(e){
for(const t in e)return!1
return!0}function c(e){return e>0&&0==(e&e-1)}function u(e){const t=e.search(/\d/)
return-1===t?e:e.slice(0,t)}function _(e){return Math.round((e%360+360)%360/45)%8}function m(e,t){return t&&"object"==typeof t&&t.ToLongStr?`L(${t.ToLongStr()})`:t}function y(e){
let t="",i=e.indexOf("]")+1,s=e.lastIndexOf("[")
return i<0||s<0||(t=e.substring(i,s)),t}function g(e){return e<10?`0${e}`:`${e}`}function p(e,...t){console.log(`[${function(e){const t=new Date(null!=e?e:Date.now())
return`${t.getFullYear()}/${g(t.getMonth()+1)}/${g(t.getDate())} ${g(t.getHours())}:${g(t.getMinutes())}:${g(t.getSeconds())}`}()}]`,e,...t)}},49609:(e,t,i)=>{i.d(t,{t:()=>C})
var s=i(85688),n=i(75507),r=i(21370),o=i(66008),a=i(18998)
const h=(0,i(42292).O$)("app/BinderComponent")
function l(e){return()=>e}var d="MiniCreateroleview_Ry",c="MiniTaskMainPanel",u="MiniDialoguePanel",_="MiniTopSmallMapView",m="MiniTopMapView",y=i(32499)
class g{}g.BASE_SWORDMAN=1e3,g.BASE_MAGICIAN=2e3,g.BASE_ARCHER=3e3,g.None=0,g.Male=1,g.Female=2
class p extends(l(h)()){constructor(...e){super(...e),this.haverole=!1,this.isDiyName=!1,this.isFirst=!0,this.lastKey=-1,this.endtime=0,this.soundkey=0}onLoad(){
MiniPlatController.sendClick(24),this.OnAddToScene(),C.ins.isAuto&&this.schedule(this.OnCreateRoleClick,.4)}OnAddToScene(){this.isFirst=!0,this.AddorRemoveLis(!0),
this.UpdateAnchor()
const e=[1e3,2e3,3e3][Math.floor(3*(a.math.random()-.001))]
this.SelectJob(e),y.P.ins.setup(),cus.scheduleOnce(.3,(()=>{C.ins.startPreload(!0)}))}AddorRemoveLis(e=!1){
e&&(this.saber.node.on(a.NodeEventType.TOUCH_END,this.CreateDelegate(this.OnChangeSelectJob)),
this.caster.node.on(a.NodeEventType.TOUCH_END,this.CreateDelegate(this.OnChangeSelectJob)),
this.archer.node.on(a.NodeEventType.TOUCH_END,this.CreateDelegate(this.OnChangeSelectJob)),
this.btn_create.node.on(a.NodeEventType.TOUCH_END,this.CreateDelegate(this.OnCreateRoleClick)))}UpdateAnchor(){const e=a.sys.getSafeAreaRect()
let t=a.view.getVisibleSize().x-e.x,i=(a.view.getVisibleSize().y,e.y,-t/2),s=t/2
this.left.getComponent("app/TweenPosition").SetFrom(new a.Vec3(i-400,0,0)),this.left.getComponent("app/TweenPosition").SetTo(new a.Vec3(i,0,0)),
this.right.getComponent("app/TweenPosition").SetFrom(new a.Vec3(s+400,0,0)),this.right.getComponent("app/TweenPosition").SetTo(new a.Vec3(s,0,0))}OnCreateRoleClick(){
MiniPlatController.sendClick(26),y.P.ins.onRoleCreated(),C.ins.OpenTaskPanel(),C.ins.OpenTopSmallMapPanel(),__$LaunchLogicBridge._getLaunchPanelCtrl().closePanel(d)}
OnChangeSelectJob(e){
this.saber.node.name==e.target.name?this.SelectJob(g.BASE_SWORDMAN):this.caster.node.name==e.target.name?this.SelectJob(g.BASE_MAGICIAN):this.archer.node.name==e.target.name&&this.SelectJob(g.BASE_ARCHER)
}SelectJob(e){this.min.visible=this.right.visible=!1
let t=g.Male
e==g.BASE_SWORDMAN?this.saber.node.getComponent(a.Toggle).isChecked=!0:e==g.BASE_MAGICIAN?this.caster.node.getComponent(a.Toggle).isChecked=!0:e==g.BASE_ARCHER&&(this.archer.node.getComponent(a.Toggle).isChecked=!0,
t=g.Female),C.ins.sexType=t,C.ins.jobID=e,this.SelectRole(e)}SelectRole(e){this.setright(e),this.lastKey!=e&&0!=e&&(this.lastKey=e),this.PlayTween()}setright(e){let t=null
if(e==g.BASE_SWORDMAN){t="rychuangjue_sp_0008,rychuangjue_sp_0015,剑士有着强健的体魄和高超的剑术，属于近距离攻击职业，擅长单体攻击与保护队友。".split(",")}else if(e==g.BASE_MAGICIAN){
t="rychuangjue_sp_0009,rychuangjue_sp_0016,魔法师掌握着强大的法术，但防御薄弱，属于远距离攻击职业，擅长群体攻击与控制。".split(",")}else if(e==g.BASE_ARCHER){
t="rychuangjue_sp_0007,rychuangjue_sp_0017,弓箭手精通精灵族箭术与法术，属于远距离混合职业，擅长远距离攻击与治疗增益。".split(",")}if(null!=t&&t.length>=3){const i=[[6,.5],[-5,8],[0,-17]][e/1e3-1]
this.jobMainSp.spriteNameSet("preload:/atlas/chuangjue/"+t[0]),this.jobradar.spriteNameSet("preload:/atlas/chuangjue/"+t[1]),
this.jobradar.node.position=new a.math.Vec3(i[0],i[1],0),this.jobMainLab.textSet(t[2])
let s=["18","19","20"][e/1e3-1]
this.role.skin="preload:/images/chuangjue/rychuangjue_sp_00"+s}}Clear(){this.AddorRemoveLis()}Destroy(){this.unschedule(this.OnCreateRoleClick),super.destroy()}PlayTween(){
this.min.visible=this.right.visible=!0,this.min.getComponent("app/TweenPosition").PlayForward(),this.right.getComponent("app/TweenPosition").PlayForward(),
this.left.getComponent("app/TweenPosition").PlayForward(),this.min.getComponent("app/TweenAlpha").PlayForward(),this.right.getComponent("app/TweenAlpha").PlayForward()}}
class f extends(l(h)()){onLoad(){this.click.node.on(a.NodeEventType.TOUCH_END,this.CreateDelegate(this.OnClickMap)),this.click.node.active=!1
const e=a.sys.getSafeAreaRect()
let t=a.view.getVisibleSize().x-e.x,i=a.view.getVisibleSize().y-e.y
this.anchor.node.position=new a.math.Vec3(t/2,i/2)}StartGuide(){this.click.node.active=!0,C.ins.isAuto&&this.scheduleOnce(this.OnClickMap,.4)}OnClickMap(){
MiniPlatController.sendClick(35),this.unschedule(this.OnClickMap),C.ins.OpenTopMapPanel()}Destroy(){this.unschedule(this.OnClickMap)}}class w extends(l(h)()){constructor(...e){
super(...e),this.contentList=void 0,this.index=void 0,this.isAlreadyClick=void 0,this.isEnd=void 0}onLoad(){MiniPlatController.sendClick(32),this.AddLis(),this.InitModelView(),
this.contentList=[],this.contentList.push("大天使使者#你终于回来了"),this.contentList.push("我#嗯？？这是哪里？！！"),this.contentList.push("大天使使者#这里是勇者大陆，但马上就要被攻陷了。这里急需勇士们的拯救，看到你，我看到了希望了。"),
this.contentList.push("我#怎么回事？刚进来，我也看到了城外全是魔族的毒雾，马上就蔓延到城内了"),
this.contentList.push("大天使使者#这就得从上一次人魔大战说起了，上一次的大战中，无数勇士以生命的代价重创了魔王昆顿，但是依旧没能消灭昆顿，狡猾的昆顿在重伤的状态下，一边疗伤，一边召唤了大量的魔族小兵和精英怪，这群恶魔入侵到世界的每一个角落，所到之处哀鸿遍野，不仅如此，魔王昆顿还释放毒雾污染人类世界，限制人类的行动，蚕食人类的领土"),
this.contentList.push("我#历史如此沉重！不过，既然我回来了，我就不会袖手旁观！都交给我吧"),this.contentList.push("大天使使者#去找老板娘吧，她最喜欢英勇的勇士了。"),this.UpdateAnchor(),this.isEnd=!1,this.index=0,this.OnNext(),
C.ins.isAuto&&this.schedule(this.OnNext,.3,999,.3)}InitModelView(){let e
switch(this.npcUIAvatar.mid="pre_nm016",C.ins.jobID){case 1e3:e="pre_sm000_00_00"
break
case 2e3:e="pre_mg000_00_00"
break
case 3e3:e="pre_ac000_00_00"}this.playerUIAvatar.mid=e}AddLis(){this.collider.node.on(a.NodeEventType.TOUCH_END,this.OnClick,this)}RemoveLis(){}UpdateAnchor(){
const e=a.sys.getSafeAreaRect()
let t=a.view.getVisibleSize().x-e.x,i=a.view.getVisibleSize().y-e.y
this.CloseBtn.node.position=new a.math.Vec3(-t/2+125,i/2-57.5),this.leftAnchor.node.position=new a.math.Vec3(-t/2-1,-i/2-1),
this.rightAnchor.node.position=new a.math.Vec3(t/2+1,-i/2-1)}OnClick(){this.isAlreadyClick||(MiniPlatController.sendClick(33),this.isAlreadyClick=!0),this.OnNext()}OnNext(){
if(this.index>=this.contentList.length)return void this.Close()
let e=this.contentList[this.index].split("#")
this.index++
let t=e[0],i=e[1],s="我"!=t
this.leftAnchor.node.active=s,this.rightAnchor.node.active=!s,this.nameLeft.string=t,this.nameRight.string=t,this.dialoglabel.string=i}Close(){this.isEnd||(this.isEnd=!0,
this.unschedule(this.OnNext),MiniPlatController.sendClick(34),__$LaunchLogicBridge._getLaunchPanelCtrl().getOpenPanelNode(_).getComponent(f).StartGuide(),
__$LaunchLogicBridge._getLaunchPanelCtrl().closePanel(u))}Destroy(){this.RemoveLis(),this.unschedule(this.OnNext)}}class v extends(l(h)()){onLoad(){
MiniPlatController.sendClick(29),this.AddLis(),this.UpdateAnchor(),C.ins.isAuto&&this.schedule(this.TaskItemOnClick,.3)}AddLis(){
this.ui_task_mainui_item.node.on(a.NodeEventType.TOUCH_END,this.TaskItemOnClick,this)}RemoveLis(){}TaskItemOnClick(){MiniPlatController.sendClick(30),this.FindPathEnd()}
FindPathEnd(){MiniPlatController.sendClick(31),C.ins.OpenDialoguePanel(),__$LaunchLogicBridge._getLaunchPanelCtrl().closePanel(c)}UpdateAnchor(){const e=a.sys.getSafeAreaRect()
let t=a.view.getVisibleSize().x-e.x
a.view.getVisibleSize().y,e.y
this.anchor.node.position=new a.math.Vec3(-t/2,1)}Destroy(){this.RemoveLis(),this.unschedule(this.TaskItemOnClick)}}class S extends(l(h)()){onLoad(){
this.click.node.on(a.NodeEventType.TOUCH_END,this.OnClick)
const e=a.sys.getSafeAreaRect()
let t=a.view.getVisibleSize().x-e.x,i=a.view.getVisibleSize().y-e.y
this.bg.transform.setContentSize(t,i),this.rightAnchor.node.x=t/2,this.leftAnchor.node.x=-t/2,C.ins.isAuto&&this.scheduleOnce(this.OnClick,.4)}OnClick(){
MiniPlatController.sendClick(36),C.ins.enterRealScene()}Destroy(){this.unschedule(this.OnClick)}}class C{constructor(){this.isMiniStage=!1,this.isPreloadSuc=!1,this.isAuto=!1,
this.isAutoGm=!1,this.sexType=g.Male,this.jobID=-1,this._isPreloading=!1,this._isPreloadComplete=!1,this._isEnterReal=!1}static get ins(){return C._ins||(this._ins=new C),this._ins
}OpenCreateRolePanel(){__$LaunchLogicBridge._getLaunchPanelCtrl().openPanel(d,{prefab:["ui/ui_create_role_view_ry_mini","preload"],scriptCls:p,removeOther:!0
},s.n.ins.getLayer(r.T.panel))}OpenTaskPanel(){__$LaunchLogicBridge._getLaunchPanelCtrl().openPanel(c,{prefab:["ui/ui_task_mainui_panel_mini","preload"],scriptCls:v,removeOther:!1
},s.n.ins.getLayer(r.T.nav))}OpenDialoguePanel(){__$LaunchLogicBridge._getLaunchPanelCtrl().openPanel(u,{prefab:["ui/ui_dialogue_mianpanel_mini","preload"],scriptCls:w,
removeOther:!1},s.n.ins.getLayer(r.T.npcTalk))}OpenTopSmallMapPanel(){__$LaunchLogicBridge._getLaunchPanelCtrl().openPanel(_,{
prefab:["ui/ui_topsmallmap_topmappanel_mini","preload"],scriptCls:f,removeOther:!1},s.n.ins.getLayer(r.T.nav))}OpenTopMapPanel(){
__$LaunchLogicBridge._getLaunchPanelCtrl().openPanel(m,{prefab:["ui/ui_topsmallmap_mainmap_mini","preload"],scriptCls:S,removeOther:!1},s.n.ins.getLayer(r.T.panel))}
startPreload(e){this._isPreloading||(this._isPreloading=!0,MiniPlatController.sendClick(25),e||__$LaunchLogicBridge._getLaunchPanelCtrl().switchLoadingView(!0),
this._loadPackages())}_loadPackages(){n.o.loadPackages(launcher.config.subpackages.logic,(()=>{this._isPreloadComplete=!0,
launcher._gameLogicInterfaces&&(launcher._gameLogicInterfaces.init(),launcher._gameLogicInterfaces.preload()),this._checkEnter()}))}enterRealScene(){
if(MiniPlatController.sendClick(37),console.log("进入真正场景"),this.isMiniStage=!1,o.n.sceneMgr.doClear(),this._checkEnter(),!this._isPreloadComplete){let e=()=>{
this._isPreloadComplete?cus.unschedule(e):this._loadPackages()}
e(),cus.schedule(e,2)}}_checkEnter(){this.isMiniStage||!this._isPreloadComplete||this._isEnterReal||(this._isEnterReal=!0,
__$LaunchLogicBridge._getLaunchPanelCtrl().switchLoadingView(!0),launcher._gameLogicInterfaces&&launcher._gameLogicInterfaces.setup())}}C._ins=void 0},32499:(e,t,i)=>{i.d(t,{
P:()=>y})
var s,n,r,o=i(42292),a=i(71409),h=i(65603),l=i(37202),d=i(13549),c=i(84187),u=i(66008),_=i(49609)
function m(e,t,i,s,n){var r={}
return Object.keys(s).forEach((function(e){r[e]=s[e]})),r.enumerable=!!r.enumerable,r.configurable=!!r.configurable,("value"in r||r.initializer)&&(r.writable=!0),
r=i.slice().reverse().reduce((function(i,s){return s(e,t,i)||i}),r),n&&void 0!==r.initializer&&(r.value=r.initializer?r.initializer.call(n):void 0,r.initializer=void 0),
void 0===r.initializer&&(Object.defineProperty(e,t,r),r=null),r}let y=(s=(0,a.GH)(c.V.SCENE_READY),r=class e{constructor(){this._birthMapId="10002",this._birthVec={x:14150,y:4e3}}
static get ins(){return this._ins||(this._ins=new e),this._ins}setup(){this.isMiniStage&&(MiniPlatController.sendClick(27),u.n.gameStage._setup(),
u.n.gameStage.changeScene(this._birthMapId))}onSceneReady(){if(!this.isMiniStage)return
const e=u.n.sceneMgr.createNpc("501")
e.render.loadPart(l.y.mid,"pre_nm016"),e.render.setDir(h.zn.DOWN),e.head.renderShadow=!1,e.node.setPosition(14200,4200),u.n.sceneMgr.scene.addItem(e.sceneItem),
MiniPlatController.sendClick(28)}onRoleCreated(){let e
switch(_.t.ins.jobID){case 1e3:e="pre_sm000_00_00"
break
case 2e3:e="pre_mg000_00_00"
break
case 3e3:e="pre_ac000_00_00"}const t=u.n.sceneMgr.createChar("101",d.f.Char)
t.sceneItem.sceneFocus=!0,t.render.loadPart(l.y.mid,e||"pre_sm000_00_00"),t.render.setDir(h.zn.RIGHT_UP),t.head.renderShadow=!1,
t.node.setPosition(this._birthVec.x,this._birthVec.y),u.n.sceneMgr.scene.addItem(t.sceneItem)}get isMiniStage(){return _.t.ins.isMiniStage}close(){(0,a.XC)(this)}},r._ins=void 0,
m(n=r,"ins",[o.Vx],Object.getOwnPropertyDescriptor(n,"ins"),n),m(n.prototype,"onSceneReady",[s],Object.getOwnPropertyDescriptor(n.prototype,"onSceneReady"),n.prototype),n)},
66008:(e,t,i)=>{i.d(t,{n:()=>_})
var s,n,r,o,a,h,l,d,c=i(42292)
function u(e,t,i,s,n){var r={}
return Object.keys(s).forEach((function(e){r[e]=s[e]})),r.enumerable=!!r.enumerable,r.configurable=!!r.configurable,("value"in r||r.initializer)&&(r.writable=!0),
r=i.slice().reverse().reduce((function(i,s){return s(e,t,i)||i}),r),n&&void 0!==r.initializer&&(r.value=r.initializer?r.initializer.call(n):void 0,r.initializer=void 0),
void 0===r.initializer&&(Object.defineProperty(e,t,r),r=null),r}let _=(s=(0,c.Vu)("engine.GameStage"),n=(0,c.Vu)("engine.MapTiles"),r=(0,c.Vu)("engine.APath"),(d=class{
static cameraFocus(e,t,i){this.gameStage.sceneCamera.focus(e,t,i)}}).gameStage=void 0,d.mapTiles=void 0,d.aPath=void 0,d.sceneMgr=void 0,
u(o=d,"gameStage",[s],(a=(a=Object.getOwnPropertyDescriptor(o,"gameStage"))?a.value:void 0,{enumerable:!0,configurable:!0,writable:!0,initializer:function(){return a}}),o),
u(o,"mapTiles",[n],(h=(h=Object.getOwnPropertyDescriptor(o,"mapTiles"))?h.value:void 0,{enumerable:!0,configurable:!0,writable:!0,initializer:function(){return h}}),o),
u(o,"aPath",[r],(l=(l=Object.getOwnPropertyDescriptor(o,"aPath"))?l.value:void 0,{enumerable:!0,configurable:!0,writable:!0,initializer:function(){return l}}),o),o)},
71014:(e,t,i)=>{i.d(t,{bq:()=>a,iV:()=>o})
i(18998)
var s=i(39407)
i(66008)
const n=Object.create(null),r=Object.create(null)
function o(e,...t){return i=>{const o=(0,s.kJ)(e)?e:[e]
for(let e=0;e<o.length;e++){const t=o[e],s=n[t]||(n[t]=[]);-1===s.indexOf(i)&&s.push(i)}for(let e=0;e<t.length;e++){const s=t[e],n=r[s]||(r[s]=[]);-1===n.indexOf(i)&&n.push(i)}}}
function a(e){const t=[]
for(let i=0;i<e.length;i++){const s=e[i],r=n[s]
if(r)for(let e=0;e<r.length;e++){const i=r[e];-1===t.indexOf(i)&&t.push(i)}}return t}},47097:(e,t,i)=>{i.d(t,{c:()=>s})
const s={Sync:"sync",Hook:"hook"}},55226:(e,t,i)=>{i.d(t,{P:()=>n})
const s={act01:[1333,1333,1333,1333],act02:[667,667,667,667],act03:[667,667,667,667],act04:[667,667,667,667],act05:[1e3,1e3,1e3,1e3],act07:[667,667,667,667],
act11:[833,833,833,833],actDeath:[1500,3333,2867,2333],act14:[1e3,1e3,1e3,1e3],act16:[667,667,667,667],act17:[1333,1333,1333,1333],act18:[667,667,667,667],
act19:[1333,1333,1333,1333],act20:[1067,1067,1067,1067],act1001:[1067,1067,1067,1067],act1005:[1e3,1e3,1e3,1e3],act1007:[300,300,300,300],act1009:[1667,1667,1667,1667],
act1011:[1333,1333,1333,1333],act2003:[933,933,933,933],act3008:[1200,1200,1200,1200],act3009:[1633,1633,1633,1633]}
function n(e,t){let i=s[e]
return i||(console.error(`cannot find AvatarActTime '${e}'`),i=s[e]),i[t]}},72574:(e,t,i)=>{i.d(t,{Bv:()=>s})
var s={None:"none",Stand:"act01",FightIdle:"act02",Walk:"act03",Run:"act03",FightWalk:"act04",Attack:"act05",Death:"act11",WingStand:"act14",WingRun:"act16",sitRide_Idle:"act17",
sitRide_Run:"act18",standRide_Idle:"act19",standRide_Run:"act20",Hit:"act07",Skill:"act05"}
new Set([s.Stand,s.Run,s.Walk])},65603:(e,t,i)=>{i.d(t,{wv:()=>a,xj:()=>r,zi:()=>o,zn:()=>n})
var s=i(18998),n={UP:0,RIGHT_UP:1,RIGHT:2,RIGHT_DOWN:3,DOWN:4,LEFT_DOWN:5,LEFT:6,LEFT_UP:7}
function r(e){switch(e){case n.UP:case n.RIGHT_UP:return n.RIGHT_UP
case n.RIGHT:case n.RIGHT_DOWN:return n.RIGHT_DOWN
case n.DOWN:case n.LEFT_DOWN:return n.LEFT_DOWN
case n.LEFT:case n.LEFT_UP:return n.LEFT_UP
default:return n.RIGHT_UP}}function o(e){switch(e){case n.UP:return 0
case n.RIGHT_UP:return 45
case n.RIGHT:return 90
case n.RIGHT_DOWN:return 135
case n.DOWN:return 180
case n.LEFT_DOWN:return-135
case n.LEFT:return-90
case n.LEFT_UP:return-45
default:return 0}}function a(e){switch(e){case n.UP:return new s.Vec2(0,1)
case n.RIGHT_UP:return new s.Vec2(1,1)
case n.RIGHT:return new s.Vec2(1,0)
case n.RIGHT_DOWN:return new s.Vec2(1,-1)
case n.DOWN:return new s.Vec2(0,-1)
case n.LEFT_DOWN:return new s.Vec2(-1,-1)
case n.LEFT:return new s.Vec2(-1,0)
case n.LEFT_UP:return new s.Vec2(-1,1)
default:return new s.Vec2(0,0)}}},37202:(e,t,i)=>{i.d(t,{y:()=>s})
var s={none:"none",mid:"mid",wid:"wid",widL:"widL",widR:"widR",mount:"mount",wgid:"wgid"}},13549:(e,t,i)=>{i.d(t,{f:()=>s})
var s={None:0,Char:1,Hero:2,Monster:4,Npc:8,Portal:16,Effect:32,Robot:64,Drop:128,Follower:256,EffectObject:512,Collect:2048,Guard:4096,Tomb:8192}},84187:(e,t,i)=>{i.d(t,{V:()=>s})
const s={SCENE_SETUP:"SCENE_SETUP",SCENE_BEFORE_CHANGED:"SCENE_BEFORE_CHANGED",SCENE_CHANGED:"SCENE_CHANGED",SCENE_READY:"SCENE_READY",EFFECT_AUTO_REMOVED:"EFFECT_AUTO_REMOVED",
DISPLAY_ACT_CHANGED:"DISPLAY_ACT_CHANGED",MOVE_END:"MOVE_END",MOVE_PATHS_SEND:"MOVE_PATHS_SEND",STATE_CHANGED:"STATE_CHANGED",SEND_CAMERA_TEX:"SEND_CAMERA_TEX"}},15317:(e,t,i)=>{
i.d(t,{U:()=>n,W:()=>s})
var s={START:0,Map:0,Wireframe:1,BottomTex:2,BottomEff:3,Bottom:4,Middle:5,Top:6,TopEff:7,Hurt:8,Texture:9,Component:10,ScatterTex:11,Text:12,END:13,HotArea:9}
function n(e){switch(e){case s.Wireframe:return"Wireframe"
case s.Map:return"SceneMap"
case s.BottomTex:return"BottomTex"
case s.Bottom:return"SceneBottom"
case s.Middle:return"SceneMiddle"
case s.Top:return"SceneTop"
case s.Texture:return"SceneTexture"
case s.Hurt:return"SceneHurt"
default:return`Scene_${e}`}}},15912:(e,t,i)=>{i.d(t,{Ls:()=>o,Sp:()=>n,UH:()=>s,V_:()=>r,bj:()=>a,vn:()=>h})
const s=50,n=50,r=50,o=r/2
const a=1e4
function h(e,t){return e*a+t}},4053:(e,t,i)=>{i.d(t,{T:()=>_})
var s,n=i(18998),r=i(42292),o="green",a=i(15317),h=i(48846),l=i(61696)
const d="fightword",c=n.Color.WHITE,u=new n.Color("#02b0e9")
let _=(0,r.wT)("engine.AvatarHead")(s=n._decorator.ccclass("engine.AvatarHead")(s=class extends n.Component{constructor(...e){super(...e),this._headName=null,this._nameSkin=null,
this._nameVisible=!1,this._nameColor=c,this._guildName=null,this._guildNameVisible=!1,this._guildNameColor=u,this._currHp=0,this._maxHp=0,this._hpVisible=!1,this._hpSheet=o,
this._titles=null,this._titleVisible=!1,this._titlePasses=null,this._bodyHeight=200,this._renderShadow=!1,this._sceneItem=null,this.TEXTSIZE=20,this.texArray=[],this.texIndex=0,
this.labelArray=[],this.labelIndex=0,this.renderArray=[],this.renderFlag=(0,l.Rb)(),this._nodeX=0,this._nodeY=0,this._nodeZIndex=0,this._nodeOpacity=0}get __IS_AVATAR_HEAD__(){
return!0}drawCanvas(e){this._renderShadow&&(0,l.tn)(this,0,0,0,0,.5,.5,d,"shoawd",e,a.W.BottomTex)
let t=this._bodyHeight
if(this._hpVisible){let i=this._maxHp>0?this._currHp/this._maxHp:0
i<0?i=0:i>1&&(i=1)
const s=76,n=6
if((0,l.tn)(this,0,t,s,n,.5,0,d,"top_img_black",e,a.W.Texture),i>0){const r=s-2,h=n-2,c=this._hpSheet===o?"top_img_green":"top_img_red";(0,
l.tn)(this,-r/2,t+1,r*i,h,0,0,d,c,e,a.W.Texture)}t+=n+5}if(this._nameVisible&&(this._headName||this._nameSkin)){if(this._nameSkin){const i=(0,h.uv)(this._nameSkin);(0,
l.tn)(this,0,t,0,0,.5,0,i,void 0,e,a.W.ScatterTex),t+=30}else this._headName&&(t+=20,(0,l.y0)(this,0,t,.5,this._headName,this._nameColor,0,e,a.W.Text))
t+=5}this._guildNameVisible&&this._guildName&&(t+=20,(0,l.y0)(this,0,t,.5,this._guildName,this._guildNameColor,0,e,a.W.Text),t+=5)
let i=this._titlePasses
const s=i?i.join(","):null,n=this._titles||null
if(s!==n||!!s!==this._titleVisible){const e=i
if(n&&this._titleVisible){if(i=n.split(","),e)for(let t=e.length-1;t>=0;t--)-1!==i.indexOf(e[t])&&e.splice(t,1)}else i=null
this._titlePasses=i}if(i){t+=30
for(let e=0;e<i.length;e++){i[e]
t+=100}}}isRenderEnabled(){return!this._sceneItem||this._sceneItem._sceneRenderEnabled}updateRenderEnabled(e){this.unschedule(this.loop),e?(this.schedule(this.loop,0),
this.loop()):this.clearRender()}loop(){(0,l.Jz)(this)}clearRender(){this.unschedule(this.loop),(0,l.yW)(this,!0)}get charName(){return this._headName}set charName(e){
e!==this._headName&&(this._headName=e,this.invalid())}get nameSkin(){return this._nameSkin}set nameSkin(e){this._nameSkin!==e&&(this._nameSkin=e,this.invalid())}get nameVisible(){
return this._nameVisible}set nameVisible(e){this._nameVisible!==e&&(this._nameVisible=e,this.invalid())}get nameColor(){return this._nameColor}set nameColor(e){
this._nameColor.equals(e)||(this._nameColor=e,this.invalid())}get guildName(){return this._guildName}set guildName(e){this._guildName!==e&&(this._guildName=e,this.invalid())}
get guildNameVisible(){return this._guildNameVisible}set guildNameVisible(e){this._guildNameVisible!==e&&(this._guildNameVisible=e,this.invalid())}get guildNameColor(){
return this._guildNameColor}set guildNameColor(e){this._guildNameColor.equals(e)||(this._guildNameColor=e,this.invalid())}get hp(){return this._currHp}set hp(e){
this._currHp!==e&&(this._currHp=e,this.invalid())}get maxHp(){return this._maxHp}set maxHp(e){this._maxHp!==e&&(this._maxHp=e,this.invalid())}get hpVisible(){return this._hpVisible
}set hpVisible(e){this._hpVisible!==e&&(this._hpVisible=e,this.invalid())}get hpSheet(){return this._hpSheet}set hpSheet(e){this._hpSheet!==e&&(this._hpSheet=e,this.invalid())}
get titles(){return this._titles}set titles(e){this._titles!==e&&(this._titles=e,this.invalid())}get titleVisible(){return this._titleVisible}set titleVisible(e){
this._titleVisible!==e&&(this._titleVisible=e,this.invalid())}get bodyHeight(){return this._bodyHeight}set bodyHeight(e){this._bodyHeight!==e&&(this._bodyHeight=e,this.invalid())}
get renderShadow(){return this._renderShadow}set renderShadow(e){this._renderShadow!==e&&(this._renderShadow=e,this.invalid())}setDeath(){this.hpVisible=!1,this.nameVisible=!1}
relive(){}invalid(){(0,l.R0)(this)}recycle(){this._headName=null,this._nameSkin=null,this._nameVisible=!1,this._nameColor=c,this._guildName=null,this._guildNameVisible=!1,
this._guildNameColor=u,this._currHp=0,this._maxHp=0,this._hpVisible=!1,this._hpSheet=o,this._titles=null,this._titleVisible=!1,this._titlePasses=null,this._bodyHeight=200,
this._renderShadow=!1,this.texIndex=0,this.labelIndex=0,this._nodeX=0,this._nodeY=0,this._nodeZIndex=0,this._nodeOpacity=0,this.renderFlag=(0,l.Rb)()}})||s)||s},42334:(e,t,i)=>{
i.d(t,{o:()=>h})
var s,n=i(18998),r=i(34441),o=i(75507),a=i(48846)
let h=(0,n._decorator.ccclass)(s=class extends n.Component{constructor(...e){super(...e),this._offsetX=0,this._offsetY=0,this._atlasNameOrImgPath="",this._subName="",this._resId=0,
this._sprite=null}_onRender(e,t,i,s,r,o,a,h,l,d,c,u){this._offsetX=s,this._offsetY=r,this._atlasNameOrImgPath=c,this._subName=u||""
const _=this.node
_.transform.setAnchorPoint(l,d),_.transform.setContentSize(o,a),_.parent!==h&&_.setParent(h),this._removeSpriteFrame(),
this._sprite.sizeMode=o>0?n.Sprite.SizeMode.CUSTOM:n.Sprite.SizeMode.TRIMMED,this._onRefresh(e,t,i)}_onRefresh(e,t,i){0===this._resId&&this._setSpriteFrame()
const s=this.node
s.visible=!0,i!==s.opacity&&(s.opacity=i),s.setPosition(e+this._offsetX,t+this._offsetY)}_getOffsetX(){return this._offsetX}_setOffsetX(e){this._offsetX=e}_subOffsetX(e){
this._offsetX-=e}_setSpriteFrame(){if(this._subName){const e=(0,a.th)(this._atlasNameOrImgPath)
this._resId=o.o.getResId(e)||o.o.loadRes(e,n.SpriteAtlas,r.X.Medium)}else this._resId=o.o.getResId(this._atlasNameOrImgPath)||o.o.loadRemote(this._atlasNameOrImgPath,r.X.RefCycle)
o.o.listenRes(this._resId,this._listenCallback,this)}_listenCallback(e,t){if(this._resId===t)if(this._subName){const i=e?e.getSpriteFrame(this._subName):null
i&&o.o._$retainRes(t),this._sprite.spriteFrame=i}else e&&o.o._$retainRes(t),this._sprite.spriteFrame=e}_clear(e){e&&this.node.transform.setContentSize(0,0),
this._removeSpriteFrame(),this.node.visible=!1}onDisable(){this._removeSpriteFrame()}_removeSpriteFrame(){const e=this._resId
e>0&&(this._resId=0,o.o.removeListenRes(e,this._listenCallback,this),this._sprite.spriteFrame&&(this._sprite.spriteFrame=null,o.o._$releaseRes(e)))}recycle(){this._clear(!0)}})||s
},11568:(e,t,i)=>{i.d(t,{n:()=>n})
var s=i(18998)
const n=s.js.getClassByName("VMCView")},61696:(e,t,i)=>{i.d(t,{YJ:()=>C,zi:()=>S,yW:()=>p,y0:()=>w,Jz:()=>y,tn:()=>f,Rb:()=>m,R0:()=>_,nR:()=>v})
var s=i(18998),n=i(43585),r=i(48846)
i(4053)
class o extends s.Component{constructor(...e){super(...e),this._offsetX=0,this._offsetY=0,this._label=null}_onRender(e,t,i,n,r,o,a,h,l,d,c,u){this._offsetX=n,this._offsetY=r
const _=this.node,m=_.getOrAddComponent(s.UITransform)
m.setAnchorPoint(a,h),_.parent!==o&&_.setParent(o)
let y=0
const g=this._label
return g.fontSize=c,g.lineHeight=c,g.string=l,g.color=d,u&&(g.updateRenderData(!0),y=m.width),this._onRefresh(e,t,i),y}_onRefresh(e,t,i){const s=this.node
s.visible=!0,s.opacity=i,s.setPosition(e+this._offsetX,t+this._offsetY)}_getOffsetX(){return this._offsetX}_setOffsetX(e){this._offsetX=e}_subOffsetX(e){this._offsetX-=e}_clear(e){
this.node.visible=!1}recycle(){this._clear(!0)}}var a=i(42334)
const h=new n.L(1e3,null,(()=>{const e=s.Node.createUINode(),t=e.addComponent(s.Sprite),i=e.addComponent(a.o)
return i._sprite=t,(0,r.n2)(e,!0),i})),l=new n.L(1e3,null,(()=>{const e=s.Node.createUINode(),t=e.addComponent(s.Label)
t.fontFamily="SimHei"
const i=e.addComponent(s.LabelOutline)
i.width=1,i.color=s.Color.BLACK
const n=e.addComponent(o)
return n._label=t,(0,r.n2)(e,!0),n})),d=1,c=2,u=4
function _(e){e.renderFlag|=d}function m(){return d|u}function y(e){const t=e._sceneItem,i=e.renderFlag
if(t._sceneRenderEnabled){if(0!=(i&d)){e.renderFlag&=~d
const i=function(e){const t=e?e._getScene():null
return t?t.sceneContext:null}(t)
S(e),null!=e.drawCanvas&&e.drawCanvas(i),C(e),g(e),function(e){let t=!0
;(e.renderArray&&e.renderArray.length||e.texArray&&e.texArray.length||e.labelArray&&e.labelArray.length)&&(t=!1)
t?e.renderFlag|=u:e.renderFlag&=~u}(e)}else 0==(i&u)&&function(e,t){const i=e.node,s=i.x,n=i.y,r=i.opacity
if(0!=(e.renderFlag&c)||e._nodeX!==s||e._nodeY!==n||e._nodeOpacity!==r){const t=e.renderArray
if(t)for(let e=0;e<t.length;e++){t[e]._onRefresh(s,n,r)}else{const t=e.texArray
if(t)for(let e=0;e<t.length;e++){t[e]._onRefresh(s,n,r)}const i=e.labelArray
if(i)for(let e=0;e<i.length;e++){i[e]._onRefresh(s,n,r)}}g(e),e.renderFlag&=~c}}(e)
e.renderFlag&=~c}else 0==(i&c)&&p(e)}function g(e){const t=e.node
e._nodeX=t.x,e._nodeY=t.y,e._nodeOpacity=t.opacity}function p(e,t){const i=e.renderArray
if(i&&!t)for(let e=0;e<i.length;e++)i[e]._clear()
else{const i=e.texArray
if(i){for(let e=0;e<i.length;e++)t?h.release(i[e]):i[e]._clear()
t&&(i.length=0)}const s=e.labelArray
if(s){for(let e=0;e<s.length;e++)t?l.release(s[e]):s[e]._clear()
t&&(s.length=0)}}t&&(i&&(i.length=0),e.renderFlag|=u,e.renderFlag|=d),e.renderFlag|=c}function f(e,t,i,n,r,o,a,l,d,c,u){if(n<=0&&r>0||n>0&&r<=0)return(0,
s.error)("draw-util.drawCanvasTex width & height 要么都为 =0，要么都 >0"),null
let _
const m=e.texArray
if(m){const t=e.texIndex
e.texIndex+=1,_=m[t]||(m[t]=h.obtain())}else _=h.obtain()
let y
if(c){if(!u)return(0,s.error)("layer error!!!"),null
y=c.getSceneLayer(u).node}else y=e.node
const g=e.node
return _._onRender(c?g.x:0,c?g.y:0,c?g.opacity:255,t,i,n,r,y,o,a,l,d),e.renderArray&&e.renderArray.push(_),_}function w(e,t,i,n,r,o,a,h,d){let c
if(h){if(!d)return(0,s.error)("layer error!!!"),null
c=h.getSceneLayer(d).node}else c=e.node
const u=e.labelArray
let _
if(u){const t=e.labelIndex
e.labelIndex+=1,_=u[t]||(u[t]=l.obtain())}else _=l.obtain()
const m=e.node
return _._onRender(h?m.x:0,h?m.y:0,h?m.opacity:255,t,i,c,n,1,r,o||s.Color.WHITE,a||e.TEXTSIZE||20),e.renderArray&&e.renderArray.push(_),_}function v(e,t,i,n,r,a,h){let l=a>0?0:r
for(let r=t;r<i;r++){const t=e[r],i=t.node,a=h?h[r]:null
a&&a.spaceW&&(l+=a.spaceW),t instanceof o&&t._label.updateRenderData(!0)
const c=i.getComponent(s.UITransform),u=(null==c?void 0:c.width)||0
if(u<=0&&(0,s.error)("canvas node in layout should has a valid width"),a&&void 0!==a.alignIndex&&a.alignIndex<r){var d
const r=e[a.alignIndex],o=r._getOffsetX(),h=o+(a.alignOffsetX||0)
t._setOffsetX(h),i.x=n+h
const c=(null===(d=r.node.getComponent(s.UITransform))||void 0===d?void 0:d.width)||0
l=Math.max(l+u,o+c)}else t._setOffsetX(l),i.x=n+l,l+=u}if(a>0){const s=a*l-r
for(let r=t;r<i;r++){const t=e[r]
t._subOffsetX(s),t.node.x=n+t._getOffsetX()}}}function S(e){e.texIndex=0,e.labelIndex=0,e.renderArray&&(e.renderArray.length=0)}function C(e){const t=e.texArray
if(t&&t.length!==e.texIndex){const i=e.texIndex
for(let e=i;e<t.length;e++)h.release(t[e])
t.length=i}const i=e.labelArray
if(i&&i.length!==e.labelIndex){const t=e.labelIndex
for(let e=t;e<i.length;e++)l.release(i[e])
i.length=t}}},68586:(e,t,i)=>{i.d(t,{D:()=>l})
var s=i(18998),n=i(43585),r=i(61696),o=i(66008)
let a=0
class h extends s.Component{constructor(...e){super(...e),this.GID=a+=1,this.type="",this.effType=0,this.scaleEnd=0,this.offsetX=0,this.offsetY=0,this.startY=0,this.dir=0,
this.va=1,this.dx=0,this.dy=0,this.startTime=0,this.startSpeedY=0,this.flowList=void 0,this.value=0,this.texArray=[],this.texIndex=0,this.labelArray=void 0,this.labelIndex=0,
this.renderArray=[],this.renderFlag=(0,r.Rb)(),this._handler=null}setupHandler(e){this._handler=e,e.resetImg(this),(0,r.zi)(this),e.drawCanvas(this),(0,r.YJ)(this),
this.node.visible=!0,o.n.sceneMgr.addHurtImage(this)}lateUpdate(){this._handler&&this._handler.lateUpdate(this)}recycle(){(0,r.yW)(this,!0),this.node.visible=!1,this._handler=null,
this.type="",this.effType=0,this.scaleEnd=0,this.offsetX=0,this.offsetY=0,this.startY=0,this.dir=0,this.va=1,this.dx=0,this.dy=0,this.startTime=0,this.startSpeedY=0,
this.flowList=null,this.value=0}}const l=new n.L(80,null,(()=>s.Node.createUINode("RENDER_CHILD").addComponent(h)))},4925:(e,t,i)=>{i.d(t,{S:()=>a})
var s=i(69641),n=i(66008),r=i(69734),o=i(68586)
class a{constructor(){this.playingNum=0}playHurt(e,t,i,a,h=null,l=null,d=null,c=null){let u=s.o.LuaDisplayBridgeManager.inst.GetDisplayObject(i)
if(u||(u=n.n.sceneMgr.getItem(n.n.sceneMgr.mainPlayerId)),!u.node)return
const _=(0,r.J)(0),m=o.D.obtain()
this.playingNum++
let y=100*c.MainRole_get().GetHeadNameHeight()
m.type=t,m.flowList=e,m.offsetX=u.node.x,m.offsetY=u.node.y+y,m.setupHandler(_)}}a.ins=new a},69734:(e,t,i)=>{i.d(t,{J:()=>a,M:()=>o})
var s=i(18998)
const n=Object.create(null),r=Object.create(null)
function o(...e){return t=>{for(let i=0;i<e.length;i++){const r=e[i]
null!=n[r]&&(0,s.error)(`repeat HurtHandler class type(${r}) ${n[r].name} - ${t.name}`),n[r]=t}}}function a(e){const t=r[e]
if(null!=t)return t
const i=n[e]||n[0]
return i._instance||(i._instance=new i),r[e]=i._instance,i._instance}},16286:(e,t,i)=>{i.d(t,{C8:()=>d,Ci:()=>m,TJ:()=>a,UT:()=>o,XP:()=>y,dJ:()=>l,id:()=>c,kh:()=>_,pC:()=>u,
v9:()=>h})
var s=i(18998),n=i(65603),r=i(15912)
new s.Vec2
function o(e,t){return[Math.floor(100*e/r.V_),Math.floor(100*t/r.V_)]}function a(e){return.01*e}function h(e,t){return[.01*e,.01*t]}function l(e,t,i,s){
const n=e>i?e-i:i-e,r=t>s?t-s:s-t
return n>r?n:r}function d(e,t,i=new s.Vec2){return i.x=Math.floor(e/r.V_),i.y=Math.floor(t/r.V_),i}function c(e){return Math.floor(e/r.V_)}function u(e){return Math.floor(e/r.V_)}
function _(e,t,i=new s.Vec2){return i.x=Math.floor(e/r.V_)*r.V_+r.Ls,i.y=Math.floor(t/r.V_)*r.V_+r.Ls,i}function m(e,t,i=new s.Vec2){return i.x=Math.floor(e*r.V_+r.Ls),
i.y=Math.floor(t*r.V_+r.Ls),i}function y(e,t,i,s){const r=e-i,o=t-s,a=180*Math.atan2(o,r)/Math.PI
return a>=-22&&a<22?n.zn.LEFT:a>=22&&a<67?n.zn.LEFT_DOWN:a>=67&&a<112?n.zn.DOWN:a>=112&&a<157?n.zn.RIGHT_DOWN:a>=157||a<-157?n.zn.RIGHT:a>=-157&&a<-112?n.zn.RIGHT_UP:a>=-112&&a<-67?n.zn.UP:a>=-67&&a<-22?n.zn.LEFT_UP:n.zn.DOWN
}},48846:(e,t,i)=>{i.d(t,{FG:()=>c,XV:()=>u,aG:()=>g,cr:()=>d,ld:()=>l,n2:()=>h,th:()=>m,uv:()=>_,xD:()=>y})
var s=i(18998),n=(i(22267),i(39407)),r=i(37202),o=i(71014),a=i(47097)
function h(e,t){t?(e.layer|=s.Layers.Enum.UI_2D,e.layer&=~s.Layers.Enum.DEFAULT):(e.layer&=~s.Layers.Enum.UI_2D,e.layer|=s.Layers.Enum.DEFAULT)}function l(e,t){
return`maps/mapres/ground/${e}/bgfm${t}.jpg`}function d(e){return`maps/${e}.bin`}function c(e){return`maps/mapres/ground/${e}/small.jpg`}function u(e,t,i,s,o){let a="",h=(0,
n.Fr)(t)
if(o)a="avatars_show"
else if(e==r.y.mount)a="horse"
else if("pre_ms"==h)a="monster"
else if("pre_nm"==h)a="npc"
else if("pre_sh"==h)a="guard"
else{a=`avatars/${e==r.y.widL||e==r.y.widR?"wid":e}`}return`${a}/${t}/${i}/${s}.json`}function _(e){return`ui/images1/titles/${e}.png`}function m(e){return`atlas/${e}`}
function y(e){return`${e}`}function g(e){const t=[a.c.Sync]
return t&&t.length>0?(0,o.bq)(t):[]}},18998:e=>{e.exports=__$LaunchLogicBridge._ccImport},22267:e=>{e.exports=__$LaunchLogicBridge._ccenvImport}},i={}
function s(e){var n=i[e]
if(void 0!==n)return n.exports
var r=i[e]={exports:{}}
return t[e](r,r.exports,s),r.exports}s.m=t,e=[],s.O=(t,i,n,r)=>{if(!i){var o=1/0
for(d=0;d<e.length;d++){for(var[i,n,r]=e[d],a=!0,h=0;h<i.length;h++)(!1&r||o>=r)&&Object.keys(s.O).every((e=>s.O[e](i[h])))?i.splice(h--,1):(a=!1,r<o&&(o=r))
if(a){e.splice(d--,1)
var l=n()
void 0!==l&&(t=l)}}return t}r=r||0
for(var d=e.length;d>0&&e[d-1][2]>r;d--)e[d]=e[d-1]
e[d]=[i,n,r]},s.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e
return s.d(t,{a:t}),t},s.d=(e,t)=>{for(var i in t)s.o(t,i)&&!s.o(e,i)&&Object.defineProperty(e,i,{enumerable:!0,get:t[i]})},s.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),
(()=>{var e={348:0}
s.O.j=t=>0===e[t]
var t=(t,i)=>{var n,r,[o,a,h]=i,l=0
if(o.some((t=>0!==e[t]))){for(n in a)s.o(a,n)&&(s.m[n]=a[n])
if(h)var d=h(s)}for(t&&t(i);l<o.length;l++)r=o[l],s.o(e,r)&&e[r]&&e[r][0](),e[r]=0
return s.O(d)},i=globalThis.webpackChunkProject=globalThis.webpackChunkProject||[]
i.forEach(t.bind(null,0)),i.push=t.bind(null,i.push.bind(i))})()
var n={};(()=>{var e=s(18998),t=s(85688),i=s(42292),n=s(49609)
launcher._gameBaseInterfaces={init(){(0,i.aH)()},preload(){},setup(){const i=e.director.getScene().getChildByName("UICanvas");(i.getComponent(t.n)||i.addComponent(t.n)).init(),
launcher._testFlag(1)&&(launcher.config.isNewAccount=!0,n.t.ins.isAuto=!0),n.t.ins.isMiniStage=launcher.config.isNewAccount,
n.t.ins.isMiniStage?(__$LaunchLogicBridge._getLaunchPanelCtrl().isMiniStageForLoginPanel=!0,MiniPlatController.sendClick(23),n.t.ins.OpenCreateRolePanel()):n.t.ins.startPreload(!1)
}}
s(32499)
var r=s(71409),o=s(84187),a=s(66008),h=s(43585),l=s(39407),d=s(65603),c=0,u=1,_=4,m=8,y=32,g=128,p=256,f=512,w=2048,v=4096,S=8192,C=s(13549),I=s(15317),R=s(4053),b=s(72574),T=s(55226),L=s(37202)
const M=[[L.y.mount,L.y.mid,L.y.widR,L.y.widL,L.y.wgid],[L.y.mount,L.y.mid,L.y.widL,L.y.widR,L.y.wgid],[L.y.mount,L.y.widL,L.y.widR,L.y.mid,L.y.wgid],[L.y.mount,L.y.widL,L.y.widR,L.y.wgid,L.y.mid],[L.y.mount,L.y.wgid,L.y.widL,L.y.widR,L.y.mid],[L.y.mount,L.y.wgid,L.y.widR,L.y.widL,L.y.mid],[L.y.mount,L.y.widL,L.y.widR,L.y.mid,L.y.wgid],[L.y.mount,L.y.mid,L.y.widR,L.y.widL,L.y.wgid]],E=[[L.y.mount,L.y.mid,L.y.widR,L.y.widL,L.y.wgid],[L.y.mount,L.y.mid,L.y.widL,L.y.widR,L.y.wgid],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.widR,L.y.wgid,L.y.mid,L.y.widL],[L.y.mount,L.y.wgid,L.y.mid,L.y.widL,L.y.widR],[L.y.mount,L.y.wgid,L.y.widR,L.y.mid,L.y.widL],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.mid,L.y.widR,L.y.widL,L.y.wgid]],x=[[L.y.mount,L.y.widL,L.y.widR,L.y.mid,L.y.wgid],[L.y.mount,L.y.widL,L.y.mid,L.y.widR,L.y.wgid],[L.y.mount,L.y.widR,L.y.mid,L.y.wgid,L.y.widL],[L.y.mount,L.y.widR,L.y.wgid,L.y.mid,L.y.widL],[L.y.mount,L.y.wgid,L.y.mid,L.y.widL,L.y.widR],[L.y.mount,L.y.wgid,L.y.widR,L.y.mid,L.y.widL],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.widR,L.y.widL,L.y.mid,L.y.wgid]],A=[[L.y.mount,L.y.mid,L.y.widL,L.y.widR,L.y.wgid],[L.y.mount,L.y.mid,L.y.widR,L.y.widL,L.y.wgid],[L.y.mount,L.y.mid,L.y.widL,L.y.widR,L.y.wgid],[L.y.mount,L.y.wgid,L.y.mid,L.y.widL,L.y.widR],[L.y.mount,L.y.wgid,L.y.mid,L.y.widL,L.y.widR],[L.y.mount,L.y.wgid,L.y.mid,L.y.widR,L.y.widL],[L.y.mount,L.y.mid,L.y.widL,L.y.widR,L.y.wgid],[L.y.mount,L.y.mid,L.y.widR,L.y.widL,L.y.wgid]],P=[[L.y.mount,L.y.widL,L.y.widR,L.y.mid,L.y.wgid],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.mid,L.y.widL,L.y.widR,L.y.wgid],[L.y.mount,L.y.wgid,L.y.mid,L.y.widL,L.y.widR],[L.y.mount,L.y.wgid,L.y.mid,L.y.widL,L.y.widR],[L.y.mount,L.y.wgid,L.y.mid,L.y.widR,L.y.widL],[L.y.mount,L.y.mid,L.y.widL,L.y.widR,L.y.wgid],[L.y.mount,L.y.widL,L.y.mid,L.y.widR,L.y.wgid]],O=[[L.y.mount,L.y.widL,L.y.widR,L.y.mid,L.y.wgid],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.mid,L.y.widL,L.y.widR,L.y.wgid],[L.y.mount,L.y.wgid,L.y.mid,L.y.widL,L.y.widR],[L.y.mount,L.y.wgid,L.y.mid,L.y.widL,L.y.widR],[L.y.mount,L.y.wgid,L.y.mid,L.y.widR,L.y.widL],[L.y.mount,L.y.mid,L.y.widL,L.y.widR,L.y.wgid],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid]],N=[[L.y.mount,L.y.widL,L.y.widR,L.y.mid,L.y.wgid],[L.y.mount,L.y.widL,L.y.mid,L.y.widR,L.y.wgid],[L.y.mount,L.y.widL,L.y.mid,L.y.wgid,L.y.widR],[L.y.mount,L.y.widR,L.y.wgid,L.y.mid,L.y.widL],[L.y.mount,L.y.wgid,L.y.widL,L.y.widR,L.y.mid],[L.y.mount,L.y.wgid,L.y.widR,L.y.widL,L.y.mid],[L.y.mount,L.y.widL,L.y.mid,L.y.widR,L.y.wgid],[L.y.mount,L.y.widR,L.y.widL,L.y.mid,L.y.wgid]],D=[[L.y.mount,L.y.widL,L.y.widR,L.y.mid,L.y.wgid],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.wgid,L.y.mid,L.y.widL,L.y.widR],[L.y.mount,L.y.wgid,L.y.mid,L.y.widL,L.y.widR],[L.y.mount,L.y.wgid,L.y.mid,L.y.widR,L.y.widL],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid]],B=[[L.y.mount,L.y.mid,L.y.widL,L.y.widR,L.y.wgid],[L.y.mount,L.y.mid,L.y.widL,L.y.widR,L.y.wgid],[L.y.mount,L.y.mid,L.y.widL,L.y.widR,L.y.wgid],[L.y.mount,L.y.wgid,L.y.widR,L.y.widL,L.y.mid],[L.y.mount,L.y.wgid,L.y.widR,L.y.widL,L.y.mid],[L.y.mount,L.y.wgid,L.y.widR,L.y.widL,L.y.mid],[L.y.mount,L.y.mid,L.y.widL,L.y.widR,L.y.wgid],[L.y.mount,L.y.mid,L.y.widL,L.y.widR,L.y.wgid]],V=[[L.y.mount,L.y.mid,L.y.widL,L.y.widR,L.y.wgid],[L.y.mount,L.y.mid,L.y.widL,L.y.widR,L.y.wgid],[L.y.mount,L.y.mid,L.y.widL,L.y.widR,L.y.wgid],[L.y.mount,L.y.wgid,L.y.mid,L.y.widR,L.y.widL],[L.y.mount,L.y.wgid,L.y.widR,L.y.widL,L.y.mid],[L.y.mount,L.y.wgid,L.y.mid,L.y.widR,L.y.widL],[L.y.mount,L.y.mid,L.y.widL,L.y.widR,L.y.wgid],[L.y.mount,L.y.mid,L.y.widL,L.y.widR,L.y.wgid]],k=[[L.y.mount,L.y.mid,L.y.widL,L.y.widR,L.y.wgid],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.mid,L.y.widR,L.y.wgid,L.y.widL],[L.y.mount,L.y.wgid,L.y.mid,L.y.widR,L.y.widL],[L.y.mount,L.y.wgid,L.y.widR,L.y.mid,L.y.widL],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid]],F=[[L.y.mount,L.y.mid,L.y.widL,L.y.widR,L.y.wgid],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.mid,L.y.widR,L.y.wgid,L.y.widL],[L.y.mount,L.y.wgid,L.y.mid,L.y.widR,L.y.widL],[L.y.mount,L.y.wgid,L.y.widR,L.y.mid,L.y.widL],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid]],U=[[L.y.mount,L.y.mid,L.y.widR,L.y.widL,L.y.wgid],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.wgid,L.y.mid,L.y.widR,L.y.widL],[L.y.mount,L.y.wgid,L.y.mid,L.y.widR,L.y.widL],[L.y.mount,L.y.wgid,L.y.widR,L.y.mid,L.y.widL],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid]],H=[[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.wgid,L.y.mid,L.y.widR,L.y.widL],[L.y.mount,L.y.wgid,L.y.mid,L.y.widR,L.y.widL],[L.y.mount,L.y.wgid,L.y.widR,L.y.mid,L.y.widL],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid]],W=[[L.y.mount,L.y.widL,L.y.mid,L.y.widR,L.y.wgid],[L.y.mount,L.y.mid,L.y.widR,L.y.widL,L.y.wgid],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.wgid,L.y.mid,L.y.widR,L.y.widL],[L.y.mount,L.y.wgid,L.y.mid,L.y.widR,L.y.widL],[L.y.mount,L.y.wgid,L.y.widR,L.y.mid,L.y.widL],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid]],j=[[L.y.mount,L.y.widL,L.y.mid,L.y.widR,L.y.wgid],[L.y.mount,L.y.mid,L.y.widL,L.y.widR,L.y.wgid],[L.y.mount,L.y.mid,L.y.widR,L.y.widL,L.y.wgid],[L.y.mount,L.y.wgid,L.y.mid,L.y.widR,L.y.widL],[L.y.mount,L.y.wgid,L.y.mid,L.y.widL,L.y.widR],[L.y.mount,L.y.wgid,L.y.mid,L.y.widR,L.y.widL],[L.y.mount,L.y.mid,L.y.widR,L.y.widL,L.y.wgid],[L.y.mount,L.y.widL,L.y.mid,L.y.widR,L.y.wgid]],z=[[L.y.mount,L.y.mid,L.y.widR,L.y.widL,L.y.wgid],[L.y.mount,L.y.mid,L.y.widR,L.y.widL,L.y.wgid],[L.y.mount,L.y.widL,L.y.widR,L.y.mid,L.y.wgid],[L.y.mount,L.y.wgid,L.y.widL,L.y.widR,L.y.mid],[L.y.mount,L.y.wgid,L.y.widL,L.y.widR,L.y.mid],[L.y.mount,L.y.wgid,L.y.widL,L.y.widR,L.y.mid],[L.y.mount,L.y.widL,L.y.widR,L.y.mid,L.y.wgid],[L.y.mount,L.y.mid,L.y.widR,L.y.widL,L.y.wgid]],G=[[L.y.mount,L.y.mid,L.y.widR,L.y.widL,L.y.wgid],[L.y.mount,L.y.mid,L.y.widR,L.y.widL,L.y.wgid],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.wgid,L.y.widR,L.y.mid,L.y.widL],[L.y.mount,L.y.wgid,L.y.widR,L.y.mid,L.y.widL],[L.y.mount,L.y.wgid,L.y.widR,L.y.mid,L.y.widL],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.mid,L.y.widR,L.y.widL,L.y.wgid]],$=[[L.y.mount,L.y.widL,L.y.mid,L.y.widR,L.y.wgid],[L.y.mount,L.y.widL,L.y.mid,L.y.widR,L.y.wgid],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.widR,L.y.wgid,L.y.mid,L.y.widL],[L.y.mount,L.y.wgid,L.y.widR,L.y.mid,L.y.widL],[L.y.mount,L.y.wgid,L.y.widR,L.y.mid,L.y.widL],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.widL,L.y.mid,L.y.widR,L.y.wgid]],X=[[L.y.mount,L.y.widL,L.y.mid,L.y.widR,L.y.wgid],[L.y.mount,L.y.widL,L.y.mid,L.y.widR,L.y.wgid],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.widR,L.y.wgid,L.y.mid,L.y.widL],[L.y.mount,L.y.wgid,L.y.widR,L.y.mid,L.y.widL],[L.y.mount,L.y.wgid,L.y.widR,L.y.mid,L.y.widL],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.widL,L.y.mid,L.y.widR,L.y.wgid]],Y=[[L.y.mount,L.y.widL,L.y.mid,L.y.widR,L.y.wgid],[L.y.mount,L.y.mid,L.y.widR,L.y.widL,L.y.wgid],[L.y.mount,L.y.widR,L.y.wgid,L.y.mid,L.y.widL],[L.y.mount,L.y.wgid,L.y.widR,L.y.mid,L.y.widL],[L.y.mount,L.y.wgid,L.y.widR,L.y.mid,L.y.widL],[L.y.mount,L.y.wgid,L.y.widR,L.y.mid,L.y.widL],[L.y.mount,L.y.widR,L.y.wgid,L.y.mid,L.y.widL],[L.y.mount,L.y.widL,L.y.mid,L.y.widR,L.y.wgid]],Z=[[L.y.mount,L.y.widL,L.y.mid,L.y.widR,L.y.wgid],[L.y.mount,L.y.widL,L.y.mid,L.y.widR,L.y.wgid],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.widR,L.y.wgid,L.y.mid,L.y.widL],[L.y.mount,L.y.wgid,L.y.widR,L.y.mid,L.y.widL],[L.y.mount,L.y.wgid,L.y.widR,L.y.mid,L.y.widL],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.widL,L.y.mid,L.y.widR,L.y.wgid]],K=[[L.y.mount,L.y.mid,L.y.widR,L.y.widL,L.y.wgid],[L.y.mount,L.y.mid,L.y.widR,L.y.widL,L.y.wgid],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.wgid,L.y.widR,L.y.mid,L.y.widL],[L.y.mount,L.y.wgid,L.y.widR,L.y.mid,L.y.widL],[L.y.mount,L.y.wgid,L.y.widR,L.y.mid,L.y.widL],[L.y.mount,L.y.widR,L.y.mid,L.y.widL,L.y.wgid],[L.y.mount,L.y.mid,L.y.widR,L.y.widL,L.y.wgid]],J=[[L.y.mount,L.y.widL,L.y.mid,L.y.widR,L.y.wgid],[L.y.mount,L.y.mid,L.y.widL,L.y.widR,L.y.wgid],[L.y.mount,L.y.mid,L.y.widR,L.y.widL,L.y.wgid],[L.y.mount,L.y.wgid,L.y.mid,L.y.widR,L.y.widL],[L.y.mount,L.y.wgid,L.y.mid,L.y.widL,L.y.widR],[L.y.mount,L.y.wgid,L.y.mid,L.y.widR,L.y.widL],[L.y.mount,L.y.mid,L.y.widR,L.y.widL,L.y.wgid],[L.y.mount,L.y.mid,L.y.widR,L.y.widL,L.y.wgid]]
const q=[0,45,90,135,180,135,90,45]
function Q(e){return q[e]}const ee={pre_wq1001_1_00_00:"pre_wq100101_1_00_00",pre_wq1002_1_00_00:"pre_wq100201_1_00_00",pre_wq1003_1_00_00:"pre_wq100301_1_00_00",
pre_wq1004_1_00_00:"pre_wq100401_1_00_00",pre_wq1005_1_00_00:"pre_wq100501_1_00_00",pre_wq1006_1_00_00:"pre_wq100601_1_00_00",pre_wq1007_1_00_00:"pre_wq100701_1_00_00",
pre_wq1008_1_00_00:"pre_wq100801_1_00_00",pre_wq1009_1_00_00:"pre_wq100901_1_00_00",pre_wq1010_1_00_00:"pre_wq101001_1_00_00",pre_wq1011_1_00_00:"pre_wq101101_1_00_00",
pre_wq1012_1_00_00:"pre_wq101201_1_00_00",pre_wq1013_1_00_00:"pre_wq101301_1_00_00",pre_wq1014_1_00_00:"pre_wq101401_1_00_00",pre_wq1015_1_00_00:"pre_wq101501_1_00_00"}
var te,ie=s(48846),se=s(16286),ne=s(11568)
const re=new h.L(500,void 0,(()=>e.Node.createUINode()),(e=>{e.removeAllChildren()}))
let oe=(0,i.wT)("engine.AvatarRender")(te=e._decorator.ccclass("engine.AvatarRender")(te=class t extends e.Component{constructor(...t){super(...t),this._currAct=b.Bv.Stand,
this.actCallBack=null,this._currDir=d.zn.UP,this._actRenderers=new Map,this._timeScale=1,this._hasWing=!1,this._mountAct=0,this._mountResName=null,this._isSafe=0,
this._backBody=null,this._frontBody=null,this._isPlayComplete=!1,this._jobId=0,this._completeDelay=0,this.forceRepeat=!1,this.mainPartId=L.y.mid,this.uiMode=!1,this.resShow=!1,
this.hotArea=new e.Rect(-30,-10,60,130),this._autoHotArea=!0,this._sceneItem=null}get __IS_AVATARRENDER__(){return!0}get backBody(){
return this._backBody||(this._backBody=re.obtain(),this._backBody.name="back",this.node.insertChild(this._backBody,0)),this._backBody}get frontBody(){
return this._frontBody||(this._frontBody=re.obtain(),this._frontBody.name="front",this.node.addChild(this._frontBody)),this._frontBody}getAct(){return this._currAct}
setAct(e,t=null){const i=this.uiMode?e:this._getShowAction(e);(this.uiMode?this._currAct:this._getShowAction(this._currAct))!=i&&(this._currAct=i,this.actCallBack=t,
this._isPlayComplete=!1,this.unschedule(this._complateCallback),this.unschedule(this._updateAllRenderers),this.scheduleOnce(this._updateAllRenderers,0))}setSafe(e){this._isSafe=e}
SetPlayInterMultiple(e){this._actRenderers.forEach((t=>{t.playInterMultiple=e}))}get currDir(){return this._currDir}set currDir(e){this._currDir!=e&&(this._currDir=e,
this._isPlayComplete=!1,this.unschedule(this._updateAllRenderers),this.scheduleOnce(this._updateAllRenderers,0))}getDir(){return this._currDir}setDir(e){
this._currDir!=e&&(this._currDir=e,this._isPlayComplete=!1,this.unschedule(this._updateAllRenderers),this.scheduleOnce(this._updateAllRenderers,0))}play(e,t=0){this.setAct(e)}
rePlay(){this._actRenderers.forEach((e=>{e.replay()}))}SetColor(e){this._actRenderers.forEach((t=>{t.sprite.color=e}))}SetHeightOffset(e){this._actRenderers.forEach(((t,i)=>{
"mount"==i&&(t.y=e)}))}ResetColor(){this._actRenderers.forEach((t=>{t.sprite.color=e.Color.WHITE}))}getTimeScale(){return this._timeScale}setTimeScale(e){this._timeScale=e}
onDestroy(){}loadPart(e,t,i,s,n){let r=this._actRenderers.get(e)
var o
if(e==L.y.widR&&(t=ee[o=t]||o),t!==(r?r.partId:null)){if(e==L.y.wgid&&(this._hasWing=!!t),e==L.y.mount){this._mountAct=t?1:0,this._mountResName=t&&0!=this._jobId?t:null
for(let[e,t]of this._actRenderers)e!=L.y.mid&&e!=L.y.wgid&&(t.node.active=!this._mountResName)}t?(r||(r=function(e){const t=e==L.y.mid||e==L.y.wgid
return ne.n.createVMC(t?ne.n.VMCType.SELF_FLOW:ne.n.VMCType.SELF)}(e),r.part=e,this._actRenderers.set(e,r),this._updateAppends()),r.node.name=`VMC_${e}_${t}`,r.partId=t,
r.setCameraLayer(!this.uiMode),this.node.addChild(r.node),e==L.y.mid&&(r.node.on("COMPLETE",this._onRendererPlayComplete,this),
t.indexOf("pre_sm")>=0?this._jobId=1:t.indexOf("pre_mg")>=0?this._jobId=2:t.indexOf("pre_ac")>=0?this._jobId=3:this._jobId=0),this.unschedule(this._updateAllRenderers),
this.scheduleOnce(this._updateAllRenderers,0)):r&&(r.node.active=!0,this._actRenderers.delete(e),r.node.off("COMPLETE",this._onRendererPlayComplete,this),r.recover(),
this._updateAppends(),e==L.y.mid&&(this._jobId=0))}
this.updateFlow(e,i,s,n),this._mountResName?e!=L.y.mid&&e!=L.y.wgid&&r&&(r.node.active=!1):e!=L.y.mount||t||(this.unschedule(this._updateAllRenderers),
this.scheduleOnce(this._updateAllRenderers,0))}updateFlow(e,t,i,s){const n=this._actRenderers.get(e)
n&&n.updateFlow(t,i,s)}faceTo(t){let i=0,s=0
t instanceof e.Component?(i=t.node.x,s=t.node.y):(i=t.x,s=t.y),this.setDir((0,se.XP)(this.node.x,this.node.y,i,s))}facePoint(e,t){this.setDir((0,
se.XP)(this.node.x,this.node.y,e,t))}_updateAllRenderers(){const e=this.uiMode?this._currAct:this._getShowAction(this._currAct),t=(i=e,s=this._currDir,
2==(n=this._jobId)?i==b.Bv.Stand?B[s]:i==b.Bv.FightIdle?V[s]:i==b.Bv.FightWalk?k[s]:i==b.Bv.Run?F[s]:i==b.Bv.WingStand?U[s]:i==b.Bv.WingRun?H[s]:i==b.Bv.Death?j[s]:i==b.Bv.Attack?W[s]:B[s]:3==n?i==b.Bv.Stand?z[s]:i==b.Bv.FightIdle?G[s]:i==b.Bv.FightWalk?$[s]:i==b.Bv.Run?X[s]:i==b.Bv.WingStand?Y[s]:i==b.Bv.WingRun?Z[s]:i==b.Bv.Death?J[s]:i==b.Bv.Attack?K[s]:z[s]:i==b.Bv.Stand?M[s]:i==b.Bv.FightIdle?E[s]:i==b.Bv.Run?A[s]:i==b.Bv.FightWalk?x[s]:i==b.Bv.WingStand?P[s]:i==b.Bv.WingRun?O[s]:i==b.Bv.Death?D[s]:i==b.Bv.Attack?N[s]:M[s])
var i,s,n
const r=this._isPlayComplete,o=!r,a=r&&e==b.Bv.Death,h=(0,T.P)(e,this._jobId)
if(e==b.Bv.Death){const e=(0,T.P)("actDeath",this._jobId)
this._completeDelay=Math.max(0,e-h)}else this._completeDelay=0
let l,d=0
this._backBody&&d++
const c=this.isRenderEnabled()
for(let e=0;e<t.length;e++){const i=t[e],s=this._actRenderers.get(i)
s&&(s._renderEnabled=c,s.customTotalTime=h,a&&s.part==L.y.wgid?l=s:(s.node.setSiblingIndex(d++),o&&this._updateRenderer(s)))}l&&l.node.setSiblingIndex(d++),
this._frontBody&&this._frontBody.setSiblingIndex(d++)}_updateAppends(){const e=this.mainPartId,t=this._actRenderers,i=t.get(e)
if(!i)return
i.isSon=!1
const s=i._appendList||(i._appendList=[])
s.length&&(s.length=0),t.forEach((e=>{e!=i&&(e.isSon=!0,e._appendList&&(e._appendList.length=0),e.checkAppendChange(),s[s.length]=e)}))}_updateRenderer(e){
let t=this.uiMode?this._currAct:this._getShowAction(this._currAct,e.part),i=this._currDir
this._mountAct>0&&(i=(0,d.xj)(i))
const s=(0,d.zi)(i),n=this.forceRepeat||t==b.Bv.Stand||t==b.Bv.Run||t==b.Bv.WingStand||t==b.Bv.WingRun||t==b.Bv.sitRide_Idle||t==b.Bv.sitRide_Run||t==b.Bv.standRide_Idle||t==b.Bv.standRide_Run||t==b.Bv.FightIdle||t==b.Bv.FightWalk?0:1
let r
if(this._mountResName){let s
s=1==this._jobId?"sm":3==this._jobId?"ac":"mg",e.part==L.y.mid?r=`horse/${s}/${this._mountResName}/${t}/${Q(i)}.json`:e.part==L.y.wgid&&(r=`avatars/wgid/${s}/${e.partId}/${this._mountResName}/${t}/${Q(i)}.json`)
}else r=(0,ie.XV)(e.part,e.partId,t,`${Q(i)}`,this.resShow)
e.updatePose(r,s,n)}_getShowAction(e,t){
return e==b.Bv.Stand||e==b.Bv.WingStand||e==b.Bv.sitRide_Idle||e==b.Bv.standRide_Idle||e==b.Bv.FightIdle?t==L.y.mount?b.Bv.Stand:1==this._mountAct?b.Bv.standRide_Idle:2==this._mountAct?b.Bv.sitRide_Idle:this._hasWing?b.Bv.WingStand:1==this._isSafe?b.Bv.FightIdle:b.Bv.Stand:e==b.Bv.Run||e==b.Bv.WingRun||e==b.Bv.sitRide_Run||e==b.Bv.standRide_Run||e==b.Bv.FightWalk?t==L.y.mount?b.Bv.Run:1==this._mountAct?b.Bv.standRide_Run:2==this._mountAct?b.Bv.sitRide_Run:this._hasWing?b.Bv.WingRun:this._isSafe?b.Bv.FightWalk:b.Bv.Run:e
}_onRendererPlayComplete(e){this._currAct==b.Bv.Death?this._isPlayComplete=!0:(1==this._isSafe?this._currAct=b.Bv.FightIdle:this._currAct=b.Bv.Stand,this._isPlayComplete=!1),
this.SetPlayInterMultiple(1),this.unschedule(this._updateAllRenderers),this.scheduleOnce(this._updateAllRenderers,0),
this.actCallBack&&(this._completeDelay>0?this.scheduleOnce(this._complateCallback,this._completeDelay/1e3):this._complateCallback())}_complateCallback(){const e=this.actCallBack
e&&(this.actCallBack=null,e(this))}testPoint(e,t){
const i=this.node,s=this.hotArea,n=!this._autoHotArea,r=n?1:i.scale2d,o=n?1:i.scale2d,a=s.x*r+i.x,h=s.y*o+i.y,l=s.width*r,d=s.height*o
return e>=a&&e<=a+l&&t>=h&&t<=h+d}isRenderEnabled(){return!this._sceneItem||this._sceneItem._sceneRenderEnabled}updateRenderEnabled(e){this._actRenderers.forEach((t=>{
t.updateRenderEnabled(e)}))}clearRender(){this._backBody&&(t.clearBodyNode(this._backBody),this._backBody=null),this._frontBody&&(t.clearBodyNode(this._frontBody),
this._frontBody=null),this._actRenderers.size&&(this._actRenderers.forEach((e=>{e.recover()})),this._actRenderers.clear()),this.resShow=!1,this.forceRepeat=!1,this._jobId=0,
this._completeDelay=0,this._isSafe=0,this._currAct=b.Bv.Stand,this._currDir=d.zn.UP,this._timeScale=1,this._hasWing=!1,this._mountAct=0,this.mainPartId=L.y.mid,this.uiMode=!1,
this.unschedule(this._complateCallback),this.unschedule(this._updateAllRenderers),this.actCallBack&&(this.actCallBack=null)}static clearBodyNode(e){e.removeAllChildren(),
e.removeFromParent(),re.release(e)}})||te)||te
var ae,he=s(69641),le=s(78175)
function de(e,t,i,s){return Math.sqrt((e-i)*(e-i)+(t-s)*(t-s))}function ce(e,t,i){return e<t?t:e>i?i:e}let ue=0
const _e=new e.Vec2
let me=(0,i.wT)("engine.Move")(ae=(0,e._decorator.ccclass)(ae=class extends e.Component{constructor(...e){super(...e),this._moveTargetX=0,this._moveTargetY=0,this._movePaths=null,
this._moveTotalTime=0,this._moveLastLoopTime=0,this._moveIndex=0,this._moveNextX=-1,this._moveNextY=-1,this._moveNextAstarStep=0,this._moveNextNeedAstar=!1,
this._moveWaitSendPathsLength=0,this._moveSpeed=0,this._moving=!1,this.moveEndCallBackId=-1,this.runSpeed=3,this.isPlayMoveWarm=!1,this.moveModeForChar=!1,
this.moveSendServicePaths=!1,this.moveWarmDelay=160,this._avatarRender=null,this._sceneItem=null,this._isLoop=!1}get __IS_MOVE__(){return!0}moveTo(e,t,i){let s=2e3,n=!0;(0,
l.QI)(i)?i>0&&(s=i):(0,l.pE)(i)&&(n=i)
return this._moving?(this._moveNextX=e,this._moveNextY=t,this._moveNextAstarStep=s,this._moveNextNeedAstar=n):this._tryMoveTo(e,t,n,s),ue+=1,this._moveIndex=ue,this._moveIndex}
movePaths(e){return e.length>0&&this._doMovePaths(e),ue+=1,this._moveIndex=ue,this._moveIndex}isMoving(){if(this._moving)return!0
const e=this._avatarRender
return!!e&&(e.getAct()===b.Bv.Run||e.getAct()===b.Bv.Walk)}stopMove(e=!0){this._moving&&this._clean(e)}onLoad(){this._sceneItem=(0,le._e)(this,"engine.SceneItem"),
this._avatarRender=(0,le._e)(this,"engine.AvatarRender")}_getMoveTargetPoint(t){if(this._movePaths&&this._movePaths.length>0){const i=this._movePaths[this._movePaths.length-1]
return(t||new e.Vec2).set(i.x,i.y)}return null}_tryMoveNext(){
return(-1!==this._moveNextX||-1!==this._moveNextY)&&this._tryMoveTo(this._moveNextX,this._moveNextY,this._moveNextNeedAstar,this._moveNextAstarStep)}getTimeScale(){
return this._avatarRender?this._avatarRender.getTimeScale():this._sceneItem?this._sceneItem.getSceneTimeScale():1}_setLoop(e){this._isLoop!=e&&(this._isLoop=e,
e?this.schedule(this.loop,0):this.unschedule(this.loop))}loop(){if(!this._moving)return this._moveIndex>0&&this._sendMoveEnd(),void this._setLoop(!1)
const t=this.getTimeScale(),i=cus.currTime
if(this._moveTotalTime+=(i-this._moveLastLoopTime)*t,this._moveLastLoopTime=i,this._moveTotalTime<=0)return
const s=this.node,n=(0,se.id)(s.x),r=(0,se.pC)(s.y),o=s.x,a=s.y,h=this._moveTargetX,l=this._moveTargetY,d=de(o,a,h,l),c=d/(100*this._moveSpeed)*1e3*t
let u=c
this._moveTotalTime>=u?this._moveTotalTime-=u:(u=this._moveTotalTime,this._moveTotalTime=0)
let _=o,m=a
if(d<=.5)_=h,m=l
else{if(!(u>0))return void(0,e.error)("time <= 0 !")
{const e=u/c
_=h*e+o*(1-e),m=l*e+a*(1-e)}}s.setPosition(_,m)
let y=!1
if(_===this._moveTargetX&&m===this._moveTargetY)if(this._movePaths.length>0){this._moveTotalTime=0
const e=this._movePaths.shift()
this._moveTargetX=e.x,this._moveTargetY=e.y,this._checkAndSetDir(!0),this._updateWalkMode(),this._changeCharMoveAct()}else y=!0
if(-1!==this._moveNextX&&-1!==this._moveNextY&&(y||n!==(0,se.id)(s.x)||r!==(0,se.pC)(s.y)))return this._tryMoveTo(this._moveNextX,this._moveNextY,this._moveNextNeedAstar,this._moveNextAstarStep),
he.o.LuaCallBackMgr&&he.o.LuaCallBackMgr.CallOnMoveEndDicWithOutDelay(this.moveEndCallBackId,.01*_,0,.01*m),void this._clean()
y&&(he.o.LuaCallBackMgr&&he.o.LuaCallBackMgr.CallOnMoveEndDicWithOutDelay(this.moveEndCallBackId,.01*_,0,.01*m),this._clean())}_sendMoveEnd(){const e=this._moveIndex
this._moveIndex=0,this.node.hasEventListener(o.V.MOVE_END)&&this.node.emit(o.V.MOVE_END,e)}_tryMoveTo(e,t,i,s){const n=(0,se.C8)(e,t,_e),r=n.x,o=n.y,h=(0,se.id)(this.node.x),l=(0,
se.pC)(this.node.y)
if(r===h&&o===l)return this._clean(),!1
const d=a.n.aPath.findPath(h,l,r,o)
if(!d||0==d.length)return this._clean(),!1
const c=[]
for(let e=0;e<d.length;e++){const t=d[e]
c.push((0,se.Ci)(t[0],t[1]))}return this._doMovePaths(c),this._setLoop(!0),!0}_doMovePaths(e){const t=e[e.length-1];(0,se.C8)(t.x,t.y,_e)
e.shift()
const i=e.shift()
this._moveTargetX=i.x,this._moveTargetY=i.y,this._movePaths=e,this._moveTotalTime=0,this._moveLastLoopTime=cus.currTime,this._moving=!0,this._checkAndSetDir(!0),
this._updateWalkMode()}_checkAndSetDir(e=!1){const t=this.node
if(t.x===this._moveTargetX&&t.y===this._moveTargetY)return
let i=e
if(!i){const e=(0,se.C8)(this._moveTargetX,this._moveTargetY,_e),s=e.x,n=e.y
i=(0,se.id)(t.x)!==s||(0,se.pC)(t.y)!==n}i&&this._avatarRender&&this._avatarRender.setDir((0,se.XP)(t.x,t.y,this._moveTargetX,this._moveTargetY))}_updateWalkMode(){const e=(0,
se.kh)(this._moveTargetX,this._moveTargetY,_e)
0!==de(this.node.x,this.node.y,e.x,e.y)&&this._changeCharMoveAct()}_changeCharMoveAct(){const e=this._avatarRender
let t=null
this.moveModeForChar?t=b.Bv.Run:e&&e.getAct()!==b.Bv.Walk&&(t=b.Bv.Walk),this._updateSpeed()}_updateSpeed(){
he.o.LuaDisplayBridgeManager&&(this._moveSpeed=he.o.LuaDisplayBridgeManager.inst.speedDic[this._sceneItem.handleId]),this._moveSpeed||(this._moveSpeed=this.runSpeed)}
setMoveSpeed(e){this.runSpeed=e}_clean(e=!0){if(this._setLoop(!1),-1!==this._moveNextX&&(this._moveNextX=-1,this._moveNextY=-1,this._moveNextAstarStep=0,
this._moveNextNeedAstar=!1),this._moving){const t=this._avatarRender
t&&(he.o.JoystickControl?!he.o.JoystickControl.Inst.IsDraging()&&e&&t.play(b.Bv.Stand):t.play(b.Bv.Stand)),this._moving=!1,this._moveSpeed=0,this._moveTargetX=0,
this._moveTargetY=0,this._moveTotalTime=0,this._moveLastLoopTime=0,this._movePaths=null,this._moveWaitSendPathsLength=0}}recycle(){this._setLoop(!1),this._moveTargetX=0,
this._moveTargetY=0,this._moveTotalTime=0,this._moveLastLoopTime=0,this._moveIndex=0,this._moveNextX=-1,this._moveNextY=-1,this._moveNextAstarStep=0,this._moveNextNeedAstar=!1,
this._moveWaitSendPathsLength=0,this._moveSpeed=0,this._moving=!1,this.runSpeed=3,this.isPlayMoveWarm=!1,this.moveModeForChar=!1,this.moveSendServicePaths=!1,
this.moveWarmDelay=160,this._movePaths=null}})||ae)||ae
const ye=Object.getOwnPropertyDescriptor(e.Node.prototype,"x").get,ge=Object.getOwnPropertyDescriptor(e.Node.prototype,"x").set,pe=Object.getOwnPropertyDescriptor(e.Node.prototype,"y").get,fe=Object.getOwnPropertyDescriptor(e.Node.prototype,"y").set,we=Object.getOwnPropertyDescriptor(e.Node.prototype,"position").get,ve=Object.getOwnPropertyDescriptor(e.Node.prototype,"position").set,Se=Object.getOwnPropertyDescriptor(e.BaseNode.prototype,"active").set
class Ce extends e.Node{constructor(...e){super(...e),this.tileX=0,this.tileY=0,this._nodeActive=!0,this._sceneActive=!0,this._sceneItem=null}get __IS_SCENEITEM_NODE__(){return!0}
get x(){return ye.call(this)}set x(e){e!==ye.call(this)&&(ge.call(this,e),this.tileX=(0,se.id)(e),this._sceneItem._updateItemPos())}get y(){return pe.call(this)}set y(e){
e!==pe.call(this)&&(fe.call(this,e),this.tileY=(0,se.pC)(e),this._sceneItem._updateItemPos())}get position(){return we.call(this)}set position(e){const t=e.x,i=e.y
t===ye.call(this)&&i===pe.call(this)||(ve.call(this,e),this.tileX=(0,se.id)(t),this.tileY=(0,se.pC)(i),this._sceneItem._updateItemPos())}setXY(e,t){
e===ye.call(this)&&t===pe.call(this)||(super.setXY(e,t),this.tileX=(0,se.id)(e),this.tileY=(0,se.pC)(t),this._sceneItem._updateItemPos())}setPosition(e,t,i){
const s="number"==typeof e,n=s?e:e.x,r=s?t:e.y
n===ye.call(this)&&r===pe.call(this)||(super.setPosition(e,t||0,i),this.tileX=(0,se.id)(n),this.tileY=(0,se.pC)(r),this._sceneItem._updateItemPos())}get active(){
return this._nodeActive}set active(e){e!==this._nodeActive&&(this._nodeActive=e,this._updateNodeActive())}_getSceneActive(){return this._sceneActive}_setSceneActive(e){
e!==this._sceneActive&&(this._sceneActive=e,this._updateNodeActive())}_updateNodeActive(){Se.call(this,this._nodeActive&&this._sceneActive)}setParent(e){
this._sceneItem._parentChanged(e),super.setParent(e)}recycle(){this.tileX=0,this.tileY=0,this._nodeActive=!0,this._sceneActive=!0,this._updateNodeActive()
const t=this._components
if(t)for(let i=0;i<t.length;i++){const s=t[i];(0,e.isValid)(s,!0)&&"function"==typeof s.recycle&&s.recycle()}}}var Ie
let Re=(0,i.wT)("engine.SceneItem")(Ie=(0,e._decorator.ccclass)(Ie=class extends e.Component{constructor(...e){super(...e),this._scenePosEnabled=!1,this._scene=null,this.itemId=0,
this.itemType=0,this.itemIndexKey=0,this._poolType="",this.sceneObject=null,this.render=null,this.head=null,this.selectEnabled=!1,this.sceneFocus=!1,this.handleId=0,
this.createData=null,this.displayId=0,this.character=null,this._sceneVisible=!1,this._sceneRenderEnabled=!1,this._shieldVisible=!0}get tileX(){return this.node.tileX}get tileY(){
return this.node.tileY}_initItem(t,i,s){const n=s>=0?s:i
return(0,l.n6)(n)||(0,e.error)("sceneItem.itemIndexKey must be two_n"),this.itemId=t,this.itemType=i,this.itemIndexKey=n,n}_isInScene(){return null!=this._scene}_getScene(){
return this._scene}_setScene(e){e!==this._scene&&(this._scene=e,this._updateItemPos())}removeFromScene(){this._scene&&this._scene.removeItem(this)}getSceneTimeScale(){
return this._scene?this._scene.getTimeScale():1}_getSceneActive(){return this.node._getSceneActive()}_setSceneActive(e){this.node._setSceneActive(e)}getScenePosEnabled(){
return this._scenePosEnabled}setScenePosEnabled(e){e!==this._scenePosEnabled&&(this._scenePosEnabled=e,this._updateItemPos())}_parentChanged(e){
this._scene&&this._scene._checkItemParentChanged(this,e)}_updateItemPos(){if(this._scene&&this._scenePosEnabled){const e=this.node
e.opacity=a.n.mapTiles.isAlpha(e.tileX,e.tileY)?153:255,this.sceneFocus&&a.n.cameraFocus(e.x,e.y,!0)}}setSceneFocus(e){this.sceneFocus=e,
e&&a.n.cameraFocus(this.node.x,this.node.y,e)}recycle(){this.removeFromScene()
const e=this.node
e.removeFromParent(),e.active=!0,e.setPosition(0,0,0),e.transform.setAnchorPoint(0,0),e.setScale(1,1,1),e.name="",this.handleId=0,this.displayId=0,this.createData=null,
this._scenePosEnabled=!1,this._scene=null,this.character=null,this.selectEnabled=!1,this.sceneFocus=!1,this._sceneVisible=!1,this._shieldVisible=!0,this.itemId=0,this.itemType=0,
this.itemIndexKey=0,this._poolType=""}get appVisible(){return null==this.character||this.character.isShow_get()}HandleProcessShield(){
return null!=this.character&&this.character.HandleProcessShield()}})||Ie)||Ie
function be(){const t=function(t){const i=new Ce(t)
return i._transform=i.addComponent(e.UITransform),i}()
t.transform.setAnchorPoint(0,0)
const i=t.addComponent(Re)
return t._sceneItem=i,i}var Te
let Le=(0,e._decorator.ccclass)(Te=class extends e.Component{constructor(...e){super(...e),this.sceneItem=null,this.move=null,this.head=null,this.render=null}get __IS_CHAR__(){
return!0}_configComponent(){this.move.isPlayMoveWarm=!1,this.move.moveModeForChar=!0,this.head.renderShadow=!0,this.sceneItem.setScenePosEnabled(!0)}recycle(){
this._configComponent()}SetCharacter(e){this.sceneItem&&(this.sceneItem.character=e)}})||Te
const Me=(0,i.O$)("app/Image")
var Ee
let xe=(0,e._decorator.ccclass)(Ee=class extends e.Component{constructor(...e){super(...e),this.sceneItem=null,this.img=null,this._skin=""}testPoint(e,t){
const i=this.node,s=i.scale2d,n=i.scale2d,r=this.img.node.transform,o=i.x,a=i.y,h=r.width*s,l=r.height*n
return e>=o&&e<=o+h&&t>=a&&t<=a+l}_configComponent(){this.sceneItem.setScenePosEnabled(!0)}get skin(){return this._skin}set skin(e){e!=this._skin&&(this._skin=e,
this.isRenderEnabled()&&(this.img.skin=e))}isRenderEnabled(){return!!this.sceneItem&&this.sceneItem._sceneRenderEnabled}updateRenderEnabled(e){
e&&this._skin?this.img.skin=this._skin:this.img.skin=""}clearRender(){this.img.skin=""}recycle(){this._configComponent()}})||Ee
var Ae
let Pe=(0,e._decorator.ccclass)(Ae=class extends e.Component{constructor(...e){super(...e),this.sceneItem=null,this.img=null,this._skin=""}get __IS_Drop__(){return!0}
testPoint(e,t){const i=this.node,s=i.scale2d,n=i.scale2d,r=this.img.node.transform,o=i.x,a=i.y,h=r.width*s,l=r.height*n
return e>=o&&e<=o+h&&t>=a&&t<=a+l}_configComponent(){this.sceneItem.setScenePosEnabled(!0)}get skin(){return this._skin}set skin(e){e!=this._skin&&(this._skin=e,
this.isRenderEnabled()&&(this.img.skin=e))}isRenderEnabled(){return!!this.sceneItem&&this.sceneItem._sceneRenderEnabled}updateRenderEnabled(e){
e&&this._skin?this.img.skin=this._skin:this.img.skin=""}clearRender(){this.img.skin=""}recycle(){this._configComponent()}})||Ae
var Oe
let Ne=(0,e._decorator.ccclass)(Oe=class extends e.Component{constructor(...e){super(...e),this.sceneItem=null,this.render=null,this.autoRemoved=!0}get __IS_EFFECT__(){return!0}
_configComponent(){this.sceneItem.selectEnabled=!1}recycle(){this.autoRemoved=!0,this._configComponent()}})||Oe
var De
let Be=(0,e._decorator.ccclass)(De=class extends Ne{constructor(...e){super(...e),this.move=null}get __IS_EFFECT_OBJECT__(){return!0}})||De
var Ve
let ke=(0,e._decorator.ccclass)(Ve=class extends e.Component{constructor(...e){super(...e),this.sceneItem=null,this.move=null,this.render=null}get __IS_FOLLOWER__(){return!0}
_configComponent(){this.move.isPlayMoveWarm=!1,this.move.moveModeForChar=!0,this.sceneItem.setScenePosEnabled(!0)}recycle(){this._configComponent()}})||Ve
var Fe
let Ue=(0,e._decorator.ccclass)(Fe=class extends e.Component{constructor(...e){super(...e),this.sceneItem=null,this.move=null,this.head=null,this.render=null,this.modelId=0}
get __IS_GUARD__(){return!0}_configComponent(){this.sceneItem.setScenePosEnabled(!0),this.head.renderShadow=!0}recycle(){this._configComponent()}HandleProcessShield(){return!0}
SetCharacter(e){this.sceneItem&&(this.sceneItem.character=e)}})||Fe
var He
let We=(0,e._decorator.ccclass)(He=class extends e.Component{constructor(...e){super(...e),this.sceneItem=null,this.move=null,this.head=null,this.render=null,this.modelId=0}
get __IS_MONSTER__(){return!0}_configComponent(){this.sceneItem.setScenePosEnabled(!0),this.head.renderShadow=!0}recycle(){this._configComponent()}SetCharacter(e){
this.sceneItem&&(this.sceneItem.character=e)}})||He
var je
let ze=(0,e._decorator.ccclass)(je=class extends e.Component{constructor(...e){super(...e),this.sceneItem=null,this.head=null,this.render=null,this.modelId=0}get __IS_NPC__(){
return!0}_configComponent(){this.head.renderShadow=!0,this.sceneItem.setScenePosEnabled(!0)}recycle(){this._configComponent()}})||je
var Ge
let $e=(0,e._decorator.ccclass)(Ge=class extends e.Component{constructor(...e){super(...e),this.sceneItem=null,this.img=null,this.head=null,this._skin=""}testPoint(e,t){
const i=this.node,s=i.scale2d,n=i.scale2d,r=this.img.node.transform,o=i.x,a=i.y,h=r.width*s,l=r.height*n
return e>=o&&e<=o+h&&t>=a&&t<=a+l}_configComponent(){this.sceneItem.setScenePosEnabled(!0)}get skin(){return this._skin}set skin(e){e!=this._skin&&(this._skin=e,
this.isRenderEnabled()&&(this.img.skin=e))}isRenderEnabled(){return!!this.sceneItem&&this.sceneItem._sceneRenderEnabled}updateRenderEnabled(e){
e&&this._skin?this.img.skin=this._skin:this.img.skin=""}clearRender(){this.img.skin=""}recycle(){this._configComponent()}})||Ge
const Xe="Char",Ye="Effect",Ze="Monster",Ke="Npc",Je="EffObject",qe="Follower",Qe="Drop",et="Collect",tt="Guard",it="Tomb"
function st(e){e.node.recycle()}const nt=new Map
function rt(e){return nt.get(e)}nt.set("Char",new h.L(100,null,(function(){const e=be(),t=e.addComponent(me),i=e.addComponent(R.T),s=e.addComponent(oe),n=e.addComponent(Le)
return e.sceneObject=n,n.sceneItem=e,n.move=t,n.head=i,n.render=s,e.render=s,e.head=i,i._sceneItem=e,s._sceneItem=e,n._configComponent(),n}),st,!0)),
nt.set("Effect",new h.L(100,null,(function(){const e=be(),t=ne.n.createVMC(ne.n.VMCType.SELF)
e.node.addChild(t.node)
const i=e.addComponent(Ne)
return i.sceneItem=e,i.render=t,e.render=t,e.sceneObject=i,i._configComponent(),i}),st,!0)),nt.set("Monster",new h.L(100,null,(function(){
const e=be(),t=e.addComponent(me),i=e.addComponent(R.T),s=e.addComponent(oe),n=e.addComponent(We)
return e.sceneObject=n,n.sceneItem=e,n.move=t,n.head=i,n.render=s,e.render=s,e.head=i,s._sceneItem=e,i._sceneItem=e,n._configComponent(),n}),st,!0)),
nt.set("Npc",new h.L(100,null,(function(){const e=be(),t=e.addComponent(R.T),i=e.addComponent(oe),s=e.addComponent(ze)
return e.sceneObject=s,s.sceneItem=e,s.head=t,s.render=i,e.render=i,e.head=t,i._sceneItem=e,t._sceneItem=e,s._configComponent(),s}),st,!0)),
nt.set("EffObject",new h.L(100,null,(function(){const e=be(),t=e.addComponent(me),i=ne.n.createVMC(ne.n.VMCType.SELF)
e.node.addChild(i.node)
const s=e.addComponent(Be)
return e.sceneObject=s,s.sceneItem=e,s.move=t,s.render=i,e.render=i,s._configComponent(),s}),st,!0)),nt.set("Follower",new h.L(100,null,(function(){
const e=be(),t=e.addComponent(me),i=e.addComponent(oe),s=e.addComponent(ke)
return e.sceneObject=s,s.sceneItem=e,s.move=t,s.render=i,e.render=i,i._sceneItem=e,s._configComponent(),s}),st,!0)),nt.set("Drop",new h.L(100,null,(function(){const e=be()
e.node.transform.setAnchorPoint(.5,.5),(0,ie.n2)(e.node,!0)
const t=e.addComponent(Pe),i=e.addComponent(Me)
return t.sceneItem=e,t.img=i,t._configComponent(),e.render=t,t}),st,!0)),nt.set("Collect",new h.L(100,null,(function(){const e=be()
e.node.transform.setAnchorPoint(.5,.5),(0,ie.n2)(e.node,!0)
const t=e.addComponent(xe),i=e.addComponent(Me)
return t.sceneItem=e,t.img=i,t._configComponent(),e.render=t,t}),st,!0)),nt.set("Guard",new h.L(100,null,(function(){
const e=be(),t=e.addComponent(me),i=e.addComponent(R.T),s=e.addComponent(oe),n=e.addComponent(Ue)
return e.sceneObject=n,n.sceneItem=e,n.move=t,n.head=i,n.render=s,e.render=s,e.head=i,s._sceneItem=e,i._sceneItem=e,n._configComponent(),n}),st,!0)),
nt.set("Tomb",new h.L(100,null,(function(){const e=be()
e.node.transform.setAnchorPoint(.5,.5),(0,ie.n2)(e.node,!0)
const t=e.addComponent($e),i=e.addComponent(Me)
return t.sceneItem=e,t.img=i,t._configComponent(),e.render=t,t}),st,!0))
let ot=0
function at(e){ot+=1
const t=`${e}@${ot}`
return t.charCodeAt(0),t}class ht extends e.Component{constructor(...e){super(...e),this.scene=null,this.mainPlayerId=0,this._scripts=new Map,this._items=new Map,
this._itemSets=new Map,this.isAddToScene=!1}setMainPlayerId(e){this.mainPlayerId=e}hasItem(e){return this._items.has(e)}getItem(e){return this._items.get(e)}
addItem(e,t=I.W.Middle){this.scene.addItem(e.sceneItem,t),this.isEffect(e)&&e.autoRemoved&&e.node.once(o.V.EFFECT_AUTO_REMOVED,this.removeItem,this)}
addItemWithIndex(t,i=I.W.Middle){const s=t.sceneItem,n=s.itemId
if(""!=n){if(this._items.has(n)&&((0,e.error)("[engine] cannot addItem with already itemId !"),this.removeItem(n)),this._items.set(n,t),s.itemIndexKey!==c){
let e=this._itemSets.get(s.itemIndexKey)
null==e&&(e=new Set,this._itemSets.set(s.itemIndexKey,e)),e.add(t)}this.scene?(this.isAddToScene=!0,this.scene.addItem(s,i)):this.isAddToScene=!1,
this.isEffect(t)&&t.autoRemoved&&t.node.once(o.V.EFFECT_AUTO_REMOVED,this.removeItem,this)}}addSceneItemAfterScene(){this.isAddToScene||this._items.forEach((e=>{
this.scene.addItem(e.sceneItem,I.W.Middle),e.sceneItem.sceneFocus&&a.n.cameraFocus(e.node.x,e.node.y,!0)}))}removeItem(t){let i,s,n=0
if((0,l.Wg)(t)?(n=t,s=this._items.get(n),s&&(i=s.sceneItem)):t instanceof e.Node?(i=t._sceneItem,n=i.itemId,s=this._items.get(n)):(i=t.sceneItem,i&&(n=i.itemId),s=t),
n&&this._items.delete(n),i&&(this.scene&&this.scene.removeItem(i),s||(s=i.sceneObject,s||(0,e.error)("error sceneItem without sceneObject")),s)){
const e=this._itemSets.get(i.itemIndexKey)
switch(e&&e.delete(s),i._poolType){case Xe:case qe:"undefined"!=typeof INS&&INS.settingMainControl&&INS.settingMainControl.curRoleNum--
break
case Ze:"undefined"!=typeof INS&&INS.settingMainControl&&INS.settingMainControl.curMonsterNum--
break
case tt:"undefined"!=typeof INS&&INS.settingMainControl&&INS.settingMainControl.curGuardNum--}const t=rt(i._poolType)
t?t.release(s):(st(s),s.node.destroy())}}traverseItems(e,t,i){e===c?this._items.forEach(t,i):this._itemSets.forEach(((s,n)=>{0!=(e&n)&&s.forEach(t,i)}))}getItemsCount(e=c){
if(e===c)return this._items.size
let t=0
return this._itemSets.forEach(((i,s)=>{0!=(e&s)&&(t+=i.size)})),t}addHurtImage(e){this.scene.addHurtImage(e)}removeHurtImage(e){this.scene.removeHurtImage(e)}isDeath(e){return!1}
setItemDeath(e){}getItemDir(e){return this.isAvatarRender(e)?e.render.getDir():d.zn.UP}createChar(e,t=C.f.Char,i=u){
"undefined"!=typeof INS&&INS.settingMainControl&&INS.settingMainControl.curRoleNum++
const s=rt("Char").obtain()
return s.sceneItem&&(s.sceneItem._initItem(e,t,i),s.sceneItem.selectEnabled=!0,s.sceneItem.node.name=e.toString()+"_"+Xe,s.sceneItem._poolType=Xe),s}createGuard(e){
"undefined"!=typeof INS&&INS.settingMainControl&&INS.settingMainControl.curGuardNum++
const t=rt("Guard").obtain(),i=e+"_"+tt
return t.sceneItem._initItem(i,C.f.Guard,v),t.sceneItem.selectEnabled=!0,t.sceneItem._poolType=tt,t.sceneItem.node.name=e+"_"+tt,t}createCharPrefix(e,t,i){
"undefined"!=typeof INS&&INS.settingMainControl&&INS.settingMainControl.curRoleNum++
const s=rt("Char").obtain()
return s.sceneItem._initItem(at(e),t,i),s.sceneItem._poolType=Xe,s}createFollower(e,t=C.f.Follower,i=p){
"undefined"!=typeof INS&&INS.settingMainControl&&INS.settingMainControl.curRoleNum++
const s=rt("Follower").obtain()
return s.sceneItem._initItem(e,t,i),s.sceneItem.selectEnabled=!0,s.sceneItem._poolType=qe,s}createMonster(e){
"undefined"!=typeof INS&&INS.settingMainControl&&INS.settingMainControl.curMonsterNum++
const t=rt("Monster").obtain()
return t.sceneItem&&(t.sceneItem._initItem(e,C.f.Monster,_),t.sceneItem.selectEnabled=!0,t.sceneItem._poolType=Ze,t.sceneItem.node.name=e.toString()+"_"+Ze),t}createNpc(e){
const t=rt("Npc").obtain()
return t.sceneItem._initItem(at("npc"),C.f.Npc,m),t.sceneItem.selectEnabled=!0,t.sceneItem._poolType=Ke,t.sceneItem.node.name=e+"_"+Ke,t}createCollect(e){
const t=rt("Collect").obtain()
return t.sceneItem._initItem(at("collect"),C.f.Collect,w),t.sceneItem.selectEnabled=!0,t.sceneItem._poolType=et,t.sceneItem.node.name=e.toString()+"_"+et,t}createDrop(e){
const t=rt("Drop").obtain()
return t.sceneItem._initItem(at("drop"),C.f.Drop,g),t.sceneItem.selectEnabled=!0,t.sceneItem._poolType=Qe,t.sceneItem.node.name=e.toString()+"_"+Qe,t}createBossTomb(e){
const t=rt("Tomb").obtain()
return t.sceneItem._initItem(at("Tomb"),C.f.Tomb,S),t.sceneItem.selectEnabled=!0,t.sceneItem._poolType=it,t.sceneItem.node.name=e.toString()+"_"+it,t}createNpcPrefix(e,t,i){
const s=rt("Npc").obtain()
return s.sceneItem._initItem(at(e),t,i),s.sceneItem.selectEnabled=!0,s.sceneItem._poolType=Ke,s}createEffect(e,t=C.f.Effect,i=y){const s=rt("Effect").obtain()
return s.sceneItem._initItem(e||at("effect"),t,i),s.sceneItem._poolType=Ye,s}createEffectObject(e,t=C.f.EffectObject,i=f){const s=rt("EffObject").obtain()
return s.sceneItem._initItem(e||at("effObj"),t,i),s.sceneItem._poolType=Je,s}isChar(e){return!0===e.__IS_CHAR__}isMonster(e){return!0===e.__IS_MONSTER__}isNpc(e){
return!0===e.__IS_NPC__}isEffect(e){return!0===e.__IS_EFFECT__}isEffectObject(e){return!0===e.__IS_EFFECT_OBJECT__}isSceneItemNode(e){return!0===e.__IS_SCENEITEM_NODE__}
isMoveObject(e){const t=e.move
return null!=t&&!0===t.__IS_MOVE__}isAvatarRender(e){const t=e.render
return null!=t&&!0===t.__IS_AVATARRENDER__}isDrop(e){return null!=e&&!0===e.__IS_Drop__}isAvatarHead(e){const t=e.head
return null!=t&&!0===t.__IS_AVATAR_HEAD__}isFightData(e){return(0,l.IP)(e)&&!0===e.__IS_FIGHT_DATA__}getTimeScale(e){
return this.isAvatarRender(e)?e.render.getTimeScale():e.sceneItem.getSceneTimeScale()}getItemId(e){return e?e.sceneItem?e.sceneItem.itemId:e._sceneItem?e._sceneItem.itemId:0:0}
getUnderPoint(e,t,i=c){const s=this.getItem(this.mainPlayerId)
let n=-1,r=null,o=!1
return this.traverseItems(i,(i=>{const a=i.sceneItem
if(a&&a.selectEnabled&&a._sceneVisible&&this.testPoint(i,e,t)){if(i===s)return void(o=!0)
let e=a.node.y
a.itemType!==C.f.Npc&&a.itemType!==C.f.Portal||(e+=1e4),e>n&&(n=e,r=i)}})),r||(o?s:null)}testPoint(e,t,i){
return this.isAvatarRender(e)?e.render.testPoint(t,i):!!this.isDrop(e)&&e.testPoint(t,i)}clear(){}doClear(){this._items.size>0&&(this._items.forEach((e=>{this.removeItem(e)})),
this._items.clear()),this._itemSets.clear()
const e=this.scene
e._forEachSceneItem((t=>{if(t){const i=t.sceneObject
if(e.removeItem(t),i){const e=rt(t._poolType)
e?e.release(i):(st(i),i.node.destroy())}}}))}}var lt,dt=1,ct=2,ut=3,_t=4,mt=1
class yt{constructor(e,t){this.isBodyRenderHide=!1,this.isRenderHotArea=!1,this.renderVisible=!1,this._allLayer=void 0,this._graphicsComps=void 0,this._layers=void 0
const i=new Set
this._allLayer=i
for(let t=0;t<e.length;t++){const s=e[t]
s&&i.add(s)}this._layers=e,this._graphicsComps=t}drawHotArea(t,i,s,n,r,o){const a=this._graphicsComps[I.W.HotArea]
a.lineWidth=1,a.strokeColor=e.Color.RED,a.line(s,i,s+r,i),a.line(t,n,t,n+o),a.rect(s,n,r,o),a.stroke()}getSceneLayer(e){return this._layers[e]}getSceneLayerByEffectLayer(e){
switch(e){case ct:return this._layers[I.W.BottomEff]
case _t:return this._layers[I.W.Bottom]
case ut:return this._layers[I.W.Top]
case dt:case mt:return this._layers[I.W.TopEff]
default:}return this._layers[I.W.TopEff]}_clear(){this._allLayer.forEach((e=>{e.clear()}))
for(const e in this._graphicsComps){const t=this._graphicsComps[e]
t&&t.clear()}}_render(){}}const{ccclass:gt}=e._decorator
let pt=gt(lt=class extends e.Component{constructor(...e){super(...e),this._x=0,this._y=0}clear(){}setVisible(e){const t=this.node
t.visible!=e&&(e?(t.x=this._x,t.y=this._y):(this._x=t.x,this._y=t.y,t.x=1e4,t.y=1e4),this.node.visible=e)}})||lt
var ft,wt=s(34441),vt=s(75507),St=s(15912),Ct=s(89123)
class It extends Ct.SK{constructor(...e){super(...e),this._strTable=null,this._objTable=null,this._traitsTable=null}readObject(){return this._strTable=[],this._objTable=[],
this._traitsTable=[],this.readObject2()}readObject2(){const e=this.readByte()
return this.readObjectValue(e)}readObjectValue(e){let t
switch(e){case 1:break
case 6:t=this.__readstring()
break
case 4:t=this.readInterger()
break
case 2:t=!1
break
case 3:t=!0
break
case 10:t=this.readScriptObject()
break
case 9:t=this.__readArray()
break
case 5:t=this.readDouble()
break
case 12:t=this.readByteArray()
break
default:console.trace(`Unknown object type tag!!!${e}`)}return t}readUInt29(){let e=0,t=255&this.readByte()
return t<128?t:(e=(127&t)<<7,t=255&this.readByte(),t<128?e|t:(e=(e|127&t)<<7,t=255&this.readByte(),t<128||(e=(e|127&t)<<8,t=255&this.readByte()),e|t))}readByteArray(){
const e=this.readUInt29()
if(0==(1&e))return this.getObjRef(e>>1)
const t=e>>1,i=new It
return this._objTable.push(i),this.readBytes(i,0,t),i}__readstring(){const e=this.readUInt29()
if(0==(1&e))return this.getStrRef(e>>1)
const t=e>>1
if(0==t)return It.EMPTY_STRING
const i=this.readUTFBytes(t)
return this._strTable.push(i),i}readInterger(){let e=this.readUInt29()
return e=e<<3>>3,parseInt(`${e}`,10)}readTraits(e){let t
if(1==(3&e))return t=this.getTraitReference(e>>2),t.propoties?t:{obj:{}}
const i=4==(4&e),s=8==(8&e),n=e>>4,r=this.__readstring()
if(t={},t.className=r,t.propoties=[],t.dynamic=s,t.externalizable=i,n>0)for(let e=0;e<n;e++){const e=this.__readstring()
t.propoties.push(e)}return this._traitsTable.push(t),t}readScriptObject(){const e=this.readUInt29()
if(0==(1&e))return this.getObjRef(e>>1)
const t=this.readTraits(e),i=t.className
t.externalizable
let s,n
const r=t.propoties
if(i&&""!=i){const e=It.getRegClass(i)
s=e?new e:{}}else s={}
if(this._objTable.push(s),r)for(let e=0;e<r.length;e++)s[r[e]]=this.readObject2()
if(t.dynamic)for(;n=this.__readstring(),null!=n&&0!=n.length;)s[n]=this.readObject2()
return s}__readArray(){const e=this.readUInt29()
if(0==(1&e))return this.getObjRef(e>>1)
let t=null
const i=e>>1
let s
for(;s=this.__readstring(),null!=s&&0!=s.length;)null==t&&(t={},this._objTable.push(t)),t[s]=this.readObject2()
if(null==t){t=[],this._objTable.push(t)
for(let e=0;e<i;e++)t.push(this.readObject2())}else for(let e=0;e<i;e++)t[e]=this.readObject2()
return t}getStrRef(e){return this._strTable[e]}getObjRef(e){return this._objTable[e]}getTraitReference(e){return this._traitsTable[e]}static getRegClass(e){
console.error(`LightByteArray getRegClass ${e}`)}}It.EMPTY_STRING=""
class Rt{constructor(){this.width=0,this.height=0,this.fragmentWidth=512,this.fragmentHeight=512,this.fragmentW=0,this.fragmentH=0,this.gridW=0,this.gridH=0,this.gridWMax=0,
this.gridHMax=0,this.extrudeX=1,this.extrudeY=1,this.tiles=null,this.areaTiles=null,this.extendTiles=null,this.dynamicDatas=null}parseFormat(e){const t=new It(e)
t.position=0,t.uncompress()
const i=t.readUnsignedInt()
if(i>=2)return void this.parse2(i,t)
this.width=t.readUnsignedInt(),this.height=t.readUnsignedInt()
t.readUnsignedInt(),t.readUnsignedInt()
this.fragmentWidth=t.readUnsignedInt(),this.fragmentHeight=t.readUnsignedInt(),this.fragmentW=t.readUnsignedInt(),this.fragmentH=t.readUnsignedInt(),this.extrudeX=t.readByte(),
this.extrudeY=t.readByte(),this.gridWMax=Math.floor(this.fragmentWidth*this.fragmentW/St.V_),this.gridHMax=Math.floor(this.fragmentHeight*this.fragmentH/St.V_)
t.readUTF()
const s=t.readObject().Tiles
s.position=0,this.gridW=s.readUnsignedInt(),this.gridH=s.readUnsignedInt(),s.position=0,this.tiles=s,this.areaTiles=new Ct.SK,this.extendTiles=new Ct.SK,this.dynamicDatas={},
a.n.mapTiles.offset=8,a.n.mapTiles.setup(this),a.n.aPath.mapTiles=a.n.mapTiles}parse2(e,t){this.width=t.readUnsignedInt(),this.height=t.readUnsignedInt()
t.readUnsignedInt(),t.readUnsignedInt()
this.fragmentWidth=t.readUnsignedInt(),this.fragmentHeight=t.readUnsignedInt(),this.fragmentW=t.readUnsignedInt(),this.fragmentH=t.readUnsignedInt(),this.extrudeX=t.readByte(),
this.extrudeY=t.readByte(),this.gridWMax=Math.floor(this.fragmentWidth*this.fragmentW/St.V_),this.gridHMax=Math.floor(this.fragmentHeight*this.fragmentH/St.V_)
t.readUTF()
this.gridW=t.readUnsignedInt(),this.gridH=t.readUnsignedInt()
const i=new Ct.SK,s=t.readUnsignedInt()
t.readBytes(i,0,s),this.tiles=i
const n=new Ct.SK
this.areaTiles=n
const r=t.readUnsignedInt()
r>0&&t.readBytes(n,0,r)
const o=new Ct.SK
if(this.extendTiles=o,e>=3){const e=t.readUnsignedInt()
e>0&&t.readBytes(o,0,e)}if(this.dynamicDatas={},e>=4){const e=t.readByte()
for(let i=0;i<e;i++){const e=t.readByte(),i=t.readUnsignedInt(),s={}
for(let e=0;e<i;e+=2){s[`${t.readShort()}_${t.readShort()}`]=!0}this.dynamicDatas[e]=s}}a.n.mapTiles.offset=0,a.n.mapTiles.setup(this),a.n.aPath.mapTiles=a.n.mapTiles}
clearFormat(){}}const{ccclass:bt}=e._decorator,Tt=new e.Rect,Lt=[],Mt=[],Et=[],xt=512,At={rect:new e.Rect,isRotate:!1,texture:null},Pt=512,Ot=[]
let Nt=bt(ft=class extends e.Component{constructor(...t){super(...t),this.mapId="",this.prevMapId="",this.isMapDataReady=!1,this._mapData=null,this._smallMapTex=null,
this._mapDataResId=0,this._smallMapResId=0,this._lastUpdateTime=0,this._invalid=!1,this._camera=null,this.extrudeX=1,this.extrudeY=1,this.blockWidth=xt-2*this.extrudeX,
this.blockHeight=Pt-2*this.extrudeY,this._ltPoint=new e.Vec2(-1,-1),this._rbPoint=new e.Vec2(-1,-1),this._key2RedId={},this._resId2Key=new Map,this._retainResIds=new Set,
this._childNodeMap={},this._xCount=0,this._yCount=0,this._smallRate=0}onLoad(){this._camera=a.n.gameStage.sceneCamera}lateUpdate(){if(!this.isMapDataReady)return
const t=cus.currTime
if(!this._invalid&&t-this._lastUpdateTime<80)return
this._lastUpdateTime=t,this._invalid=!1
const i=this._mapData.height,s=this._camera.getVisibleRectWH(Tt),n=s.x,r=i-(s.y+s.height),o=n+s.width,a=i-s.y,h=this.blockWidth,l=this.blockHeight,d=this._xCount,c=this._yCount,u=Math.max(0,Math.floor(n/h)),_=Math.max(0,Math.floor(r/l)),m=Math.min(d-1,Math.ceil(o/h)),y=Math.min(c-1,Math.ceil(a/l)),g=this._ltPoint,p=this._rbPoint
if(g.x==u&&g.y==_&&p.x==m&&p.y==y)return
const f=this.extrudeX,w=this.extrudeY,v=this._childNodeMap,S=this._key2RedId,C=this._resId2Key,I=this._retainResIds
Lt.length&&(Lt.length=0),Mt.length&&(Mt.length=0)
for(let e in v){const t=Number(e),i=t/St.bj>>0,s=t%St.bj
if(i<u||i>m||s<_||s>y){const e=v[t]
e&&(delete v[t],Lt.push(e))}}for(let e in S){const t=Number(e),i=t/St.bj>>0,s=t%St.bj
if(i<u||i>m||s<_||s>y){const e=S[t]
e>0&&(delete S[t],C.delete(e),I.has(e)&&(I.delete(e),vt.o._$releaseRes(e)))}}for(let t=u;t<=m;t++)for(let s=_;s<=y;s++){const n=(0,St.vn)(t,s)
let r=v[n]
if(r)continue
if(Lt.length)r=Lt.pop()
else if(Et.length)r=Et.pop()
else{r=e.Node.createUINode("RENDERER_MAP"),(0,ie.n2)(r,!0)
const t=r.transform
t.setAnchorPoint(0,1),t.setContentSize(xt,Pt)
r.addComponent(e.Sprite).sizeMode=e.Sprite.SizeMode.CUSTOM,this.node.addChild(r)}v[n]=r,r.setPosition(t*h-f,i-s*l+w)
const o=r.getComponent(e.Sprite),a=S[n]
if(a){const e=vt.o.getRes(a)
if(e){this.updateSpriteFrame(o,e)
continue}}this.updateSpriteFrame(o,this.createSmallSpf(t*h-f,s*l-w,xt,Pt)),Mt.push(n)}g.set(u,_),p.set(m,y)
for(let t=0;t<Lt.length;t++){const i=Lt[t],s=i.getComponent(e.Sprite)
s.spriteFrame&&(this.releaseSmallSpf(s.spriteFrame),s.spriteFrame=null),i.visible=!1,-1==Et.indexOf(i)&&Et.push(i)}if(Lt.length=0,Mt.length>0){const e=n+(o-n)/2,t=r+(a-r)/2
Mt.sort(((s,n)=>{const r=s/St.bj>>0,o=s%St.bj,a=de(r*h-f+256,i-o*l+w-256,e,t),d=n/St.bj>>0,c=n%St.bj
return de(d*h-f+256,i-c*l+w-256,e,t)-a}))
for(let e=0;e<Mt.length;e++){const t=Mt[e],i=t/St.bj>>0,s=t%St.bj*this._xCount+i,n=(0,ie.ld)(this.mapId,s),r=vt.o.loadRemote(n,wt.X.RefTex)
S[t]=r,C.set(r,t),vt.o.listenRes(r,this._listenImageCallback,this)}Mt.length=0}}_listenImageCallback(t,i){if(!t)return
t.packable=!1,t.texture.setFilters(e.Texture2D.Filter.NEAREST,e.Texture2D.Filter.NEAREST),
t.texture.setWrapMode(e.Texture2D.WrapMode.CLAMP_TO_EDGE,e.Texture2D.WrapMode.CLAMP_TO_EDGE)
const s=this._resId2Key.get(i)
if(null==s||this._key2RedId[s]!=i)return void(this._retainResIds.has(i)&&(this._retainResIds.delete(i),vt.o._$releaseRes(i)))
this._retainResIds.has(i)||(this._retainResIds.add(i),vt.o._$retainRes(i))
const n=this._childNodeMap[s]
n&&this.updateSpriteFrame(n.getComponent(e.Sprite),t)}updateSpriteFrame(e,t){e.node.visible=!0,e.spriteFrame!=t&&(e.spriteFrame&&this.releaseSmallSpf(e.spriteFrame),
e.spriteFrame=t,t&&e._applySpriteSize())}createSmallSpf(t,i,s,n){let r
Ot.length>0?r=Ot.pop():(r=new e.SpriteFrame,r.packable=!1,r.name="__ry__")
const o=this._smallRate||32
return At.rect.set(t/o,i/o,s/o,n/o),At.isRotate=!1,At.texture=this._smallMapTex.texture,r.reset(At,!0),At.texture=null,r}releaseSmallSpf(e){e&&"__ry__"==e.name&&(e._texture=null,
Ot.push(e))}ready(){if(this.mapId&&0===this._mapDataResId&&Number(this.mapId)>0){const e=(0,ie.cr)(this.mapId)
this._mapDataResId=vt.o.loadRemote(e,wt.X.RefConfigData,{_ResFormat_:Rt}),vt.o.listenRes(this._mapDataResId,this._listenCallback,this)
const t=(0,ie.FG)(this.mapId)
vt.o.listenRes(vt.o.loadRemote(t,wt.X.RefTick),this._listenSmallMapCallback,this)}
return!this.isMapDataReady&&this._mapDataResId>0&&this._mapData&&this._smallMapTex&&(this._invalid=!0,this._smallRate=this._mapData.width/this._smallMapTex.width,
this.isMapDataReady=!0),this.isMapDataReady}_listenCallback(e,t){if(this._mapDataResId!==t)return
vt.o._$retainRes(this._mapDataResId),this._mapData=e
const i=this._mapData.width,s=this._mapData.height
this.extrudeX=this._mapData.extrudeX,this.extrudeY=this._mapData.extrudeY,this.blockWidth=xt-2*this.extrudeX,this.blockHeight=Pt-2*this.extrudeY,
this._xCount=Math.ceil(i/this.blockWidth),this._yCount=Math.ceil(s/this.blockHeight)}_listenSmallMapCallback(t,i){
this._smallMapResId!=i&&(this._smallMapResId>0&&vt.o._$releaseRes(this._smallMapResId),this._smallMapResId=i,i>0&&vt.o._$retainRes(i)),this._smallMapTex=t,
t.texture.setFilters(e.Texture2D.Filter.NEAREST,e.Texture2D.Filter.NEAREST),t.texture.setWrapMode(e.Texture2D.WrapMode.CLAMP_TO_EDGE,e.Texture2D.WrapMode.CLAMP_TO_EDGE)}change(e){
this.mapId!==e&&(this.clear(),this._mapDataResId>0&&(vt.o._$releaseRes(this._mapDataResId),vt.o.clearRes(this._mapDataResId),this._mapDataResId=0),this._mapData=null,
this._smallMapResId>0&&vt.o.removeListenRes(this._smallMapResId,this._listenSmallMapCallback,this),this._smallMapTex=null,this.prevMapId=this.mapId,this.mapId=e,
this.isMapDataReady=!1)}mapWidth(){return this._mapData?this._mapData.width:0}mapHeight(){return this._mapData?this._mapData.height:0}transY(e){
return this._mapData?this._mapData.height-e:e}clear(){const t=this.node.children
for(let i=0;i<t.length;i++){const s=t[i],n=s.getComponent(e.Sprite)
n.spriteFrame&&(this.releaseSmallSpf(n.spriteFrame),n.spriteFrame=null),s.visible=!1,-1==Et.indexOf(s)&&Et.push(s)}this._retainResIds.forEach((e=>{vt.o._$releaseRes(e)})),
this._retainResIds.clear(),this._key2RedId={},this._resId2Key.clear(),this._childNodeMap={},this._ltPoint.set(-1,-1),this._rbPoint.set(-1,-1),this._invalid=!0}})||ft
class Dt extends e.Component{constructor(...e){super(...e),this.isClear=!0,this.isCameraMove=!0,this.g=null,this.status=0}onLoad(){this.node.layer=e.Layers.Enum.UI_2D,
this.g=this.node.addComponent(e.Graphics),this.g.lineWidth=1.6}onCameraChange(){this.isCameraMove=!0}openOrClose(e){this.status==e?(this.status=0,this.stopDraw()):(this.status=e,
this.openDraw())}openDraw(){this.unschedule(this.loop),this.schedule(this.loop,0),he.o.UIUtilBridge&&he.o.UIUtilBridge.openTip(),this.isClear=!0}stopDraw(){
this.unschedule(this.loop),he.o.UIUtilBridge&&he.o.UIUtilBridge.closeTip(),this.isClear||(this.isClear=!0,this.g.clear())}loop(){if(this.isCameraMove||this.isClear){
const t=a.n.mapTiles
if(!t||!t.isValid)return
this.isCameraMove=!1,this.isClear=!1
const i=a.n.gameStage.sceneCamera.getVisibleRectWH(new e.Rect),s=100,n=50*Math.floor(i.x/50)+s,r=50*Math.ceil((i.x+i.width)/50)-s,o=50*Math.floor(i.y/50)+s,h=50*Math.ceil((i.y+i.height)/50)-s,l=this.g
l.clear()
const d=1==this.status
for(let i=n;i<=r;i+=50)for(let s=o;s<=h;s+=50){const n=i,r=s,o=(0,se.id)(n),a=(0,se.id)(r)
let h
if(d)if(t.isAlpha(o,a,!1))h=new e.Color(54,204,0,102)
else if(t.canPass(o,a,!1)){if(!t.isSafe(o,a,!1))continue
h=new e.Color(246,237,23,102)}else h=new e.Color(255,0,0,102)
else{const i=t.getAreaId(o,a)
if(!(i>0))continue
{const t=i%3
h=0==t?new e.Color(78,247,82,102):1==t?new e.Color(4,160,8,102):new e.Color(13,86,15,102)}}l.fillColor=h,l.fillRect(n,r,50,50)}l.strokeColor=e.Color.RED
for(let e=n;e<=r;e+=50)l.line(e,o,e,h)
for(let e=o;e<=h;e+=50)l.line(n,e,r,e)
l.stroke()}}}var Bt
const{ccclass:Vt}=e._decorator
function kt(e,t){return t.node&&e.node?t.node.y-e.node.y:0}const Ft=new e.Rect,Ut=new e.Vec2
let Ht=Vt(Bt=class extends e.Component{constructor(...t){super(...t),this._map=null,this._camera=null,this._layers=[],this._layersSet=new Set,this._sceneItems=[],
this._tmpSceneItems=[],this._roleItems=[],this._monsterItems=[],this._guardItems=[],this._lastDepthTime=0,this._invalidDepth=!0,this._needSendReadyEvent=!1,this._timeScale=1,
this._isStop=!1,this._lastMouseEvent=null,this._lastMouseX=0,this._lastMouseY=0,this.isReady=!1,this.prevSceneId="",this.sceneId="",this.sceneContext=null,this.sceneMgr=null,
this.sceneScripts=null,this._wireframeLayer=null,this.startPos=new e.Vec2}onLoad(){const t=this.node
this._camera=a.n.gameStage.sceneCamera
const i=this._layers,s=this._layersSet,n=[],r={}
for(let o=I.W.Map;o<I.W.END;o++){const a=o,h=e.Node.createUINode((0,I.U)(a))
h.transform.setAnchorPoint(0,0),t.addChild(h),i[a]=h,s.add(h),a===I.W.Map?this._map=h.addComponent(Nt):a==I.W.Wireframe?this._wireframeLayer=h.addComponent(Dt):n[a]=h.addComponent(pt),
a===I.W.HotArea&&(r[a]=h.addComponent(e.Graphics))}this.sceneContext=new yt(n,r)}onEnable(){this.node.on(e.NodeEventType.TOUCH_START,this.onTouchStart,this),
this.node.on(e.NodeEventType.TOUCH_END,this.onSceneTouchEnd,this)}onDisable(){this.node.off(e.NodeEventType.TOUCH_START,this.onTouchStart,this),
this.node.off(e.NodeEventType.TOUCH_END,this.onSceneTouchEnd,this),he.o.UIUtilBridge&&he.o.UIUtilBridge.removeTouchMove(this.onTopTouchMoved,this)}getSceneLayer(e){
return this._layers[e]}getWireframeLayer(){return this._wireframeLayer}setLayerVisible(e,t){this.sceneContext.getSceneLayer(e).setVisible(t)}onTouchStart(e){
const t=e.touch.getLocation()
this.startPos.set(t.x,t.y),he.o.UIUtilBridge&&he.o.UIUtilBridge.addTouchMove(this.onTopTouchMoved,this,this.onTopTouchEnded)}onTopTouchMoved(t){
const i=t.touch.getLocation(),s=i.x-this.startPos.x,n=i.y-this.startPos.y
he.o.JoystickControl&&!he.o.JoystickControl.Inst.IsDraging()&&(s>30||n>30||s<-30||n<-30)&&(he.o.JoystickControl.Inst.draging_set(!0),
he.o.JoystickControl.Inst.startPos=this.startPos,he.o.JoystickControl.Inst.OpenJoystickPanel(),t.preventSwallow=!0),
he.o.JoystickControl&&he.o.JoystickControl.Inst.IsDraging()&&(t.preventSwallow=!0,he.o.JoystickControl.Inst.ClickBegin(i.x,i.y,0),
this._camera.convertScreenPosTo2DWorldPos(t.getLocation(Ut),Ut),this._lastMouseX=Ut.x,this._lastMouseY=Ut.y,this._lastMouseEvent=e.NodeEventType.TOUCH_MOVE)}onTopTouchEnded(t){
he.o.JoystickControl&&he.o.JoystickControl.Inst.IsDraging()&&(t&&(t.preventSwallow=!1),this._lastMouseEvent=e.NodeEventType.TOUCH_END)}onSceneTouchEnd(e){
if(he.o.JoystickControl&&he.o.JoystickControl.Inst.IsDraging())return
this._camera.convertScreenPosTo2DWorldPos(e.getLocation(Ut),Ut),this._lastMouseX=Ut.x,this._lastMouseY=Ut.y
const t=e.touch.getLocation()
this.startPos.set(t.x,t.y),this._lastMouseEvent="click-end"}_initScripts(e,t){this.sceneMgr=e,this.sceneScripts=t}update(){let t=null
if(this._lastMouseEvent&&(t=this._lastMouseEvent,this._lastMouseEvent!=e.NodeEventType.TOUCH_MOVE&&(this._lastMouseEvent=null)),this._isStop)return
if(!this._map.isMapDataReady)return
const i=this.ready()
if(this._needSendReadyEvent){this._needSendReadyEvent=!1
try{(0,r.bG)(o.V.SCENE_READY,{prev:this.prevSceneId,curr:this.sceneId})}catch(t){(0,e.error)(t)}}if(i&&t)try{this._scriptsOnMouse(t,this._lastMouseX,this._lastMouseY)}catch(t){(0,
e.error)(t)}}lateUpdate(){const t=this._map.isMapDataReady
if(!this._map.ready())return
if(!t){const e=this._map.mapWidth(),t=this._map.mapHeight()
this.node.transform.setContentSize(e,t),this._map.node.transform.setContentSize(e,t),this._camera.mapRect.width=e,this._camera.mapRect.height=t,
this._camera.updateCameraAfterEnterScene()}const i=cus.currTime
i-this._lastDepthTime>=(this._invalidDepth?200:600)&&(this._lastDepthTime=i,this._invalidDepth=!1,this.doDepth())
const s=this.isReady,n=this.node.active&&s,r=this.sceneContext
r.renderVisible=n,r._clear()
const o=this._camera.getVisibleRectWH(Ft),a=this._sceneItems
this._roleItems.length=0,this._monsterItems.length=0,this._guardItems.length=0
for(let t=0,i=a.length;t<i;t++){const i=a[t]
if(i&&i.node){const s=i.node,r=o.contains(e.Vec2.TEMP.set(s.x,s.y))
r!==i._sceneVisible&&(i._sceneVisible=r),i.node.setSiblingIndex(t)
const a=i.appVisible,h=r&&n&&a
h!=i._sceneRenderEnabled&&(i._sceneRenderEnabled=h,h&&this.HandleProcessShield(i,h)||this.UpdateRender(i,h))}}this.HandleShield()}UpdateRender(e,t){
e.render&&e.render.updateRenderEnabled(t),e.head&&e.head.updateRenderEnabled(t)}doDepth(){const e=this._tmpSceneItems
0!==e.length&&(e.length=0)
for(let t=0,i=this._sceneItems.length;t<i;t++){const i=this._sceneItems[t]
i&&e.push(i)}if(this._sceneItems.length=0,0===e.length)return
const t=e
this._tmpSceneItems=this._sceneItems,this._sceneItems=t,t.length<=1||t.sort(kt)}addItem(e,t=I.W.Middle){if(!e)return
const i=this._sceneItems;-1===i.indexOf(e)&&i.push(e),e._sceneVisible=!1,e._sceneRenderEnabled=!1,e._setScene(this),e._setSceneActive(this.isReady),this._invalidDepth=!0,
e.node.setParent(this._layers[t])}removeItem(e){e&&this.clearItem(e,!0)}addHurtImage(e){e.node.setParent(this._layers[I.W.Hurt])}removeHurtImage(e){e.node.removeFromParent()}
clearItem(e,t){const i=e.node._components
for(let e=0;e<i.length;e++){const t=i[e]
null!=t.clearRender&&t.clearRender()}const s=this._sceneItems.indexOf(e);-1!==s&&(this._sceneItems[s]=null),e._sceneVisible=!1,e._sceneRenderEnabled=!1,e._setScene(null),
e._setSceneActive(!0),t&&e.node.removeFromParent()}_checkItemParentChanged(e,t){t&&this._layersSet.has(t)||this.clearItem(e,!1)}change(e,t){if(a.n.mapTiles.isValid=!1,
this.sceneId!==e){const t=this.sceneId
this._scriptsOnActive(!1),this.prevSceneId=t,this.sceneId=e,this._map.change((0,ie.xD)(e)),this._map.isMapDataReady||this.node.transform.setContentSize(0,0),
this._scriptsOnSceneChanged()}else t?(a.n.mapTiles.isValid=!0,this._scriptsOnActive(!1)):this.isReady&&(a.n.mapTiles.isValid=!0,this._needSendReadyEvent=!0)}ready(){
return this.isReady||this._map.isMapDataReady&&this._scriptsOnScenePrepare()&&(this.isReady=!0,this._needSendReadyEvent=!0,a.n.mapTiles.isValid=!0,this._scriptsOnActive(!0),
this._scriptsOnSceneReady(),this.activeSceneItems(!0)),this.isReady}activeSceneItems(e){const t=this._sceneItems
for(let i=0;i<t.length;i++){const s=t[i]
s&&s._setSceneActive(e)}}getTimeScale(){return this._timeScale}setTimeScale(e){this._timeScale=e}isMapReady(){return this._map.isMapDataReady}mapWidth(){return this._map.mapWidth()
}mapHeight(){return this._map.mapHeight()}_forEachSceneItem(e){this._sceneItems.forEach(e)}clear(){this._needSendReadyEvent=!1,this._invalidDepth=!0,this._lastDepthTime=0,
this._lastMouseEvent=null,this._tmpSceneItems.length=0,this.isReady=!1,this._roleItems.length=0,this._guardItems.length=0,this._monsterItems.length=0,this._map.clear()
for(let e=0;e<this._layers.length;e++)e!==I.W.Map&&e!==I.W.Middle&&this._layers[e].removeAllChildren()}_scriptsOnActive(e){this.sceneMgr&&(this.sceneMgr.enabled=e)
const t=this.sceneScripts
for(let i=0;i<t.length;i++)t[i].enabled=e}_scriptsOnSceneChanged(){const t=this.sceneScripts
for(let i=0;i<t.length;i++){const s=t[i]
if(null!=s.onSceneChanged)try{s.onSceneChanged(this.prevSceneId,this.sceneId)}catch(t){(0,e.error)(t)}}}_scriptsOnSceneReady(){const t=this.sceneScripts
for(let i=0;i<t.length;i++){const s=t[i]
if(null!=s.onSceneReadyed)try{s.onSceneReadyed()}catch(t){(0,e.error)(t)}}}_scriptsOnScenePrepare(){const t=this.sceneScripts
for(let i=0;i<t.length;i++){const s=t[i]
if(null!=s.onScenePrepare)try{if(!s.onScenePrepare())return!1}catch(t){(0,e.error)(t)}}return!0}_scriptsOnMouse(t,i,s){const n=this.sceneScripts
for(let r=0;r<n.length;r++){const o=n[r]
if(null!=o.onSceneMouseEvent)try{o.onSceneMouseEvent(t,i,s)}catch(t){(0,e.error)(t)}}}HandleProcessShield(e,t){let i=e.HandleProcessShield()
if(i){const t=this.GetShieldItems(e._poolType)
t&&t.push(e)}return i}GetShieldItems(e){return e==Xe?this._roleItems:e==Ze?this._monsterItems:e==tt?this._guardItems:null}HandleShield(){if(this._roleItems.length>0){
let e=INS.settingMainControl.maxRoleNum
this.ExecShield(this._roleItems,e)}if(this._monsterItems.length>0){let e=INS.settingMainControl.maxMonsterNum
this.ExecShield(this._monsterItems,e)}if(this._guardItems.length>0){let e=INS.settingMainControl.maxGuardNum
this.ExecShield(this._guardItems,e)}}ExecShield(e,t){let i=0
for(let t=0;t<e.length;t++)e[t]._shieldVisible&&i++
let s=t-i
const n=s>=0
s=Math.abs(s)
let r=0
for(let t=0;t<e.length;t++)e[t]._shieldVisible!=n&&r<s&&(e[t]._shieldVisible=n,r++),this.UpdateRender(e[t],e[t]._shieldVisible)}_removeScripts(){}})||Bt
var Wt=s(54986)
new e.Vec2(0,0)
const jt=new e.Vec2,zt=new e.Vec3,Gt=new e.Vec3,$t=new e.Vec3,Xt=new e.Vec3,Yt=new e.Vec3,Zt=new e.Vec3
let Kt=0,Jt=0,qt=0,Qt=0
class ei extends e.Component{constructor(...t){super(...t),this.pivotPoint=new e.Vec3,this.sceneNode=null,this.mapRect=new e.Rect,this.OrthoSizeMin=360,this.OrthoSizeMax=1200,
this.curOrthoSizeMax=0,this.curOrthoSizeMin=0,this._minResilienceOrthoSize=0,this._maxResilienceOrthoSize=1e8,this._moveAction=null,this._resilicenceAction=null,
this._leftSpacing=0,this._topSpacing=0,this._rightSpacing=0,this._bottomSpacing=0,this._camera=null,this._forceUpdate=!1,this._focusPos=new e.Vec2,this._windowOffsetX=0,
this._windowOffsetY=0,this._limitRange=null}setup(){window.worldCamera=this,this._camera=this.getComponent(e.Camera),this.curOrthoSizeMin=this.OrthoSizeMin,
this.curOrthoSizeMax=this.OrthoSizeMax,window.sceneCamera=this,e.view.on("canvas-resize",this._onSizeChange,this),this._onSizeChange()}_onSizeChange(){
const t=e.view.getVisibleSize()
Kt=t.width,Jt=t.height,qt=Kt/2,Qt=Jt/2,this._windowOffsetX=(Kt-1280)/2,this._windowOffsetY=(Jt-720)/2,this._updateOrthoSize(this._camera.orthoHeight,!0)}_updateOrthoSize(e,t){
const i=this._camera;(i.orthoHeight!=e||this._forceUpdate||t)&&(i.orthoHeight=e,(e<=this.curOrthoSizeMax||this._forceUpdate||t)&&this.calculateSpacing())}focus(e,t,i){
this.moveCameraTo(Gt.set(e,t))}view(e,t){}invalid(){let e=!1
e=Wt.o.ins.isCameraFar,this._updateOrthoSize(e?700:this.uiOrthoHeight,!0)}_alignWithScreen(){this._updateOrthoSize(this.uiOrthoHeight)}get uiOrthoHeight(){
return e.director.getScene().getChildByName("UICanvas").getChildByName("Camera").getComponent(e.Camera).orthoHeight}convertScreenPosTo2DWorldPos(t,i){
const s=Xt.set(t.x,t.y,-1),n=Yt.set(t.x,t.y,1)
this._camera.screenToWorld(s,s),this._camera.screenToWorld(n,n)
const r=e.Vec3.subtract(Zt,n,s),o=-s.z/r.z
return i.x=s.x+r.x*o+this._windowOffsetX,i.y=s.y+r.y*o+this._windowOffsetY,i}convertMapPosToScreenPos(e,t){const i=e.add(this.sceneNode.getPosition())
return this._camera.worldToScreen(i,t)}calculateSpacing(){this._leftSpacing=qt,this._rightSpacing=this._leftSpacing,this._bottomSpacing=Qt,this._topSpacing=this._bottomSpacing}
getCameraViewRect(e){
return e.set(this.pivotPoint.x-this._leftSpacing,this.pivotPoint.y-this._bottomSpacing,this._leftSpacing+this._rightSpacing,this._topSpacing+this._bottomSpacing)}
getVisibleRectWH(e){return e.x=this.pivotPoint.x-this._leftSpacing,e.y=this.pivotPoint.y-this._bottomSpacing,e.width=this._leftSpacing+this._rightSpacing,
e.height=this._bottomSpacing+this._topSpacing,e}cancelCameraLimitRange(){this._limitRange&&(this._limitRange=null)}updateCameraAfterEnterScene(){this.moveCameraTo(this._focusPos),
this.invalid()}moveCameraTo(e){this._focusPos.set(e.x,e.y)
const t=this.mapRect
let i=t.x,s=i+t.width,n=t.y,r=n+t.height
const o=ce(e.x,i+this._leftSpacing,s-this._rightSpacing),h=ce(e.y,n+this._bottomSpacing,r-this._topSpacing)
;(this._forceUpdate||o!==this.pivotPoint.x||h!==this.pivotPoint.y)&&(this.node.setXY(o-qt,h-Qt),this.pivotPoint.set(o,h))
{const e=a.n.gameStage.scene.getWireframeLayer()
e&&e.onCameraChange()}}moveCameraBy(e){this.moveCameraTo(zt.set(this.pivotPoint).add($t.set(e.x,e.y)))}zoomOrthoCameraBy(e,t,i=!1){
this.zoomOrthoCameraTo(this._camera.orthoHeight+e,t,i)}zoomOrthoCameraTo(t,i,s=!1,n=!0){i||(i=new e.Vec2(qt,Qt)),this.convertScreenPosTo2DWorldPos(i,jt)
const r=jt.x,o=jt.y
n&&(t=ce(t,this.curOrthoSizeMin,this.curOrthoSizeMax)),this._updateOrthoSize(t),this.convertScreenPosTo2DWorldPos(i,jt),$t.x=r-jt.x,$t.y=o-jt.y,this.moveCameraBy($t),
s&&(t<this._minResilienceOrthoSize?this.startResilienceOrthoCamera(this._minResilienceOrthoSize,.3,i):t>this._maxResilienceOrthoSize&&this.startResilienceOrthoCamera(this._maxResilienceOrthoSize,.3,i))
}startMoveCameraAction(e,t=3,i=!1,s=null){if(0===e.x&&0===e.y)return void(s&&s())
!i&&e.lengthSqr()>9025&&e.normalize().multiplyScalar(95),-1===t&&(t=e.length()/30),this.stopMoveCameraAction()
const n=e.normalize().multiplyScalar(t)
this._moveAction=()=>{if(0===e.x&&0===e.y)return this.stopMoveCameraAction(),void(s&&s())
if(Math.abs(n.x)>Math.abs(e.x)||Math.abs(n.y)>Math.abs(e.y))return this.moveCameraBy(e.divide2f(2,2)),this.stopMoveCameraAction(),void(s&&s())
const t=e.subtract(n)
this.moveCameraBy(e.add(t).divide2f(2,2)),e=t},this.schedule(this._moveAction)}startUniformMoveCameraAction(t,i,s){
if(0==i||this.pivotPoint.x==t.x&&this.pivotPoint.y==t.y)return void(s&&s(t))
this.stopMoveCameraAction()
const n=t.subtract(new e.Vec2(this.pivotPoint.x,this.pivotPoint.y)).normalize()
this._moveAction=e=>{const r=i*e,o=n.x*r
if(Math.abs(o)>Math.abs(t.x-this.pivotPoint.x))return this.moveCameraTo(t),this.stopMoveCameraAction(),void(s&&s(t))
this.moveCameraBy(n.multiplyScalar(r))},this.schedule(this._moveAction)}stopMoveCameraAction(){this._moveAction&&(this.unschedule(this._moveAction),this._moveAction=null)}
startResilienceOrthoCamera(e,t,i){if(this._camera.orthoHeight===e)return
this.stopResilienceCamera()
const s=this._camera.orthoHeight<=e,n=(e-this._camera.orthoHeight)/t/60
this._resilicenceAction=()=>{if(s){if(this._camera.orthoHeight>=e)return void this.stopResilienceCamera()
}else if(this._camera.orthoHeight<=e)return void this.stopResilienceCamera()
this.zoomOrthoCameraBy(n,i)},this.schedule(this._resilicenceAction)}stopResilienceCamera(){this._resilicenceAction&&(this.unschedule(this._resilicenceAction),
this._resilicenceAction=null)}tweenZoomOrthoCameraTo(e,t=12,i=null,s=null){if(this._camera.orthoHeight==e)return void(s&&s())
const n=(e-this._camera.orthoHeight)/t
let r=0
this.stopResilienceCamera(),this._resilicenceAction=()=>{this.zoomOrthoCameraTo(n+this._camera.orthoHeight,i),r+=1,r>=t&&(this.stopResilienceCamera(),s&&s())},
this.schedule(this._resilicenceAction)}}const ti=new e.Vec2
class ii extends e.Component{constructor(...t){super(...t),this.worldCamera=null,this.bottomTouchNode=null,this.topTouchNode=null,this._lastTouchDelta=e.Vec2.ZERO,
this._lastTouchMoveTime=0,this._isMouseRightButtonDown=!1,this._fingerDis=0,this._fingerScale=0,this._touchIdSet=new Set,this._touchIdStatus=new Map,this._touchIdStartPts=new Map,
this._zoomFocuse=null,this._sizeChangeFlag=!1,this._isRotateCamera=!1,this._oneTouchEndStatus=0,this.isObjectTouchVaild=!0,this.isMoving=!1}onLoad(){
const t=this.topTouchNode.getComponent(e.Widget)
t?t.updateAlignment():console.log("--WorldTouch topNodeWidget is null"),this.node.parent.on(e.NodeEventType.SIZE_CHANGED,this.onCanvasSizeChange,this)}onEnable(){this.initTouch()}
onDisable(){this.removeTouch()}initTouch(){}removeTouch(){this.topTouchNode.off(e.NodeEventType.TOUCH_START,this.onTopTouchStarted,this),
this.topTouchNode.off(e.NodeEventType.TOUCH_END,this.onTopTouchEnded,this),this.topTouchNode.off(e.NodeEventType.TOUCH_CANCEL,this.onTopTouchCancel,this),
this.topTouchNode.off(e.NodeEventType.TOUCH_MOVE,this.onTouchMoved,this),this.node.off(e.NodeEventType.TOUCH_END,this.onTouchEnded,this,!0),
this.node.off(e.NodeEventType.TOUCH_END,this.onTouchEndedBubbles,this,!1),this.node.off(e.NodeEventType.TOUCH_CANCEL,this.onTouchCanceld,this,!0),
this.node.off(e.NodeEventType.MOUSE_WHEEL,this.onMouseWheel,this,!0),this.node.off(e.NodeEventType.MOUSE_DOWN,this.onMouseDown,this,!0),
this.node.off(e.NodeEventType.MOUSE_UP,this.onMouseUp,this,!0)}onTopTouchStarted(t){t.preventSwallow=!0
const i=this._touchIdStatus,s=this._touchIdSet,n=t.getTouches()
for(let e=0;e<n.length;e++){const t=n[e].getID()
s.add(t),i.set(t,0)}const r=t.touch.getLocation(),o=this._touchIdStartPts.get(t.touch.getID())
o?(o.x=r.x,o.y=r.y):this._touchIdStartPts.set(t.touch.getID(),(0,e.v2)(r.x,r.y))
const a=1==this._touchIdSet.size
a&&(this.isMoving=!1),this.isObjectTouchVaild=a,this._fingerScale=0,this._lastTouchMoveTime=cus.currTime,this._lastTouchDelta=e.Vec2.ZERO,this.worldCamera.stopMoveCameraAction()}
onTopTouchEnded(e){e.preventSwallow=!0
const t=this._touchIdStatus,i=this._touchIdSet,s=i.size
this._oneTouchEndStatus=-1,this._fingerDis=0
const n=e.getTouches()
for(let e=0;e<n.length;e++){const r=n[e].getID()
i.delete(r),1==s&&(this._oneTouchEndStatus=t.get(r)||0),t.delete(r)}}onTopTouchCancel(e){e.preventSwallow=!0
const t=this._touchIdStatus,i=this._touchIdSet
this._fingerDis=0
const s=e.getTouches()
for(let e=0;e<s.length;e++){const n=s[e].getID()
i.delete(n),t.delete(n)}}onTouchMoved(e){e.preventSwallow=!0
const t=e.getTouches(),i=this._touchIdSet.size
if(2===i&&2===t.length){if(0==this._fingerDis){const e=t[0].getLocation(),i=t[1].getLocation()
return this._fingerDis=e.subtract(i).length(),void(this._zoomFocuse=e.add(i).divide2f(2,2))}this._touchIdStatus.forEach(si),this.isMoving=!0
const e=t[0].getDelta().y,i=t[1].getDelta().y
let s=0
e<0&&i<0?s=-Math.min(Math.abs(e),Math.abs(i)):e>0&&i>0&&(s=Math.min(Math.abs(e),Math.abs(i))),Math.abs(s)>0&&(this._isRotateCamera=!0)
const n=t[0].getLocation().subtract(t[1].getLocation()).length(),r=n-this._fingerDis
this._doZoomOrthoCameraBy(-Math.floor(7*r),this._zoomFocuse,!0),this._fingerDis=n}else if(1===i){if(0==e.getDeltaX()&&0==e.getDeltaY())return
this.isMoving=!0,this.worldCamera.convertScreenPosTo2DWorldPos(e.getPreviousLocation(),ti)
let t=ti.x,i=ti.y
this.worldCamera.convertScreenPosTo2DWorldPos(e.getLocation(),ti),t-=ti.x,i-=ti.y,t=Math.floor(2.2*ce(t,-St.UH,St.UH)),i=Math.floor(2.2*ce(i,-St.Sp,St.Sp)),
this.worldCamera.moveCameraBy(ti.set(t,i)),this._lastTouchMoveTime=cus.currTime,this._lastTouchDelta=e.getDelta()}}onTouchEnded(){
this.isObjectTouchVaild&&0!=this._oneTouchEndStatus&&(this.isObjectTouchVaild=!1)}onTouchEndedBubbles(e){e.getLocation()
1!=this._oneTouchEndStatus||this._isMouseRightButtonDown||this._isRotateCamera?this._isRotateCamera=!1:cus.currTime-this._lastTouchMoveTime<150&&(Math.abs(this._lastTouchDelta.x)+Math.abs(this._lastTouchDelta.y)<=3?this.worldCamera.startMoveCameraAction(this._lastTouchDelta.negative().multiplyScalar(3)):this.worldCamera.startMoveCameraAction(this._lastTouchDelta.negative().multiplyScalar(3),-1)),
this._oneTouchEndStatus}onTouchCanceld(e){}canSwitchSystemEvents(){return 0==this._touchIdSet.size}_doZoomOrthoCameraBy(e,t,i=!1){this.worldCamera.zoomOrthoCameraBy(e,t,i)}
onMouseDown(t){t.getButton()===e.EventMouse.BUTTON_RIGHT&&(this._isMouseRightButtonDown=!0)}onMouseUp(t){
t.getButton()===e.EventMouse.BUTTON_RIGHT&&(this._isMouseRightButtonDown=!1)}onMouseWheel(e){const t=e.getScrollY()
this._doZoomOrthoCameraBy(-Math.floor(.3*t),e.getLocation(),!0)}onCanvasSizeChange(){const t=e.view.getVisibleSize()
this.node.setPosition(-t.width/2,-t.height/2),this._sizeChangeFlag=!0}onStopTouch(){this._touchIdSet.clear(),this._fingerDis=0}lateUpdate(){
this._sizeChangeFlag&&(this._sizeChangeFlag=!1,this.worldCamera.calculateSpacing())}}function si(e,t,i){i.set(t,2)}var ni;(0,i.wT)("engine.GameStage")(ni=class{constructor(){
this.scene=null,this.sceneMgr=null,this.sceneCamera=null,this.sceneNode=null,this._privateScene=null,this._isSetup=!1}_setup(){if(this._isSetup)return
this._isSetup=!0
const t=e.director.getScene().getChildByName("UICanvas"),i=e.view.getVisibleSize(),s=t.getChildByName("Main Camera").addComponent(ei),n=e.Node.createUINode("SceneNode"),r=n.addComponent(Ht),o=e.Node.createUINode("SceneTopTouchNode")
o.transform.setContentSize(i.width,i.height)
const h=n.addComponent(ii)
h.enabled=!1,s.sceneNode=n,this.sceneCamera=s,this.scene=r,this.sceneNode=n,this._privateScene=r,h.worldCamera=s,h.bottomTouchNode=n,h.topTouchNode=o,h.enabled=!0,
n.transform.setAnchorPoint(0,0),n.setXY(-i.width/2,-i.height/2),t.insertChild(o,0),t.insertChild(n,0),s.setup()
const l=n.getComponent(ht)||n.addComponent(ht)
l.enabled=!1,this.sceneMgr=l,a.n.sceneMgr=l}changeScene(t,i=!0){const s=this._privateScene,n=s.sceneId,h=n!==t
if((0,e.warn)(`[engine] changeScene ${n} -> ${t}`),(0,r.bG)(o.V.SCENE_BEFORE_CHANGED,{prev:n,curr:t}),h){s._removeScripts()
const e=s.node,i=e.active
i&&(e.active=!1)
const n=e.getComponent(ht)||e.addComponent(ht)
n.enabled=!1,this.sceneMgr=n,a.n.sceneMgr=n,n.scene=s,n.addSceneItemAfterScene()
const r=[],o=(0,ie.aG)(t)
for(let t=0;t<o.length;t++){const i=o[t],a=e.getComponent(i)||e.addComponent(i)
a.enabled=!1,a.scene=s,a.sceneMgr=n,r.push(a)}s._initScripts(n,r),e.active=i}(i||h)&&(s.clear(),this.clear()),s.change(t,i||h),(0,r.bG)(o.V.SCENE_CHANGED,{prev:n,curr:t})}
showScene(){this._privateScene.node.opacity=255}hideScene(){this._privateScene.node.opacity=0}clear(){a.n.mapTiles.clear()}})
s(42334)
var ri,oi=16,ai=2,hi=1,li=2048
const di=[[-1,0],[-1,1],[0,1],[1,1],[1,0],[1,-1],[0,-1],[-1,-1]],ci=new e.Vec2;(0,i.wT)("engine.MapTiles")(ri=class{constructor(){this.tiles=null,this.areaTiles=null,
this.extendTiles=null,this.dynamicDatas=null,this.dynamicBlockId=0,this.isValid=!1,this.gridW=0,this.gridH=0,this.gridWMax=0,this.gridHMax=0,this.offset=8}setup(e){
this.tiles=e.tiles,this.areaTiles=e.areaTiles,this.extendTiles=e.extendTiles,this.dynamicDatas=e.dynamicDatas,this.dynamicBlockId=0,this.gridW=e.gridW,this.gridH=e.gridH,
this.gridWMax=e.gridWMax,this.gridHMax=e.gridHMax}hasGrid(e,t){return e>=0&&t>=0&&e<this.gridW&&t<this.gridH&&e<this.gridWMax&&t<this.gridHMax}getPosition(e,t){
return e>=0&&t>=0&&e<this.gridW&&t<this.gridH&&e<this.gridWMax&&t<this.gridHMax?this.gridW*t+e+this.offset:-1}getStat(e,t,i=!0){if(!this.isValid)return hi
if(i&&!this.hasGrid(e,t))return console.error(`访问了不存在的点 ${e}, ${t}`),hi
const s=this.gridW*t+e+this.offset
return this.tiles.getByte(s)}getStat1(e,t){const i=this.gridW*t+e+this.offset
return i>=0?this.tiles.getByte(i):li}getByte(e){return this.tiles.getByte(e)}quote(e,t,i){St.bj,St.bj}canPass(e,t,i=!0){
return 0==(this.getStat(e,t,i)&hi)&&this.canPassDynamicTiles(e,t)}isAlpha(e,t,i=!0){return 0!=(this.getStat(e,t,i)&ai)}isSafe(e,t,i=!0){return 0!=(this.getStat(e,t,i)&oi)}
getAreaId(e,t){const i=this.gridW*t+e
return i>=0&&i<this.areaTiles.length?this.areaTiles.getByte(i):0}isExtend(e,t,i){if(this.extendTiles){const s=this.gridW*t+e
if(s>=0&&s<this.extendTiles.length){return 0!=(this.extendTiles.getByte(s)+128&1<<i)}}return!1}canPassDynamicTiles(e,t){
return!this.dynamicDatas||!this.dynamicDatas[this.dynamicBlockId]||!this.dynamicDatas[this.dynamicBlockId][`${e}_${t}`]}getDynamicTiles(e=1){
return this.dynamicDatas&&this.dynamicDatas[e]||{}}setDynamicTiles(e=1){this.dynamicBlockId=e}clear(){this.tiles=null}traverseTiles(e,t,i,s,n,r=null,o=!0){const a=s<i?-1:1
for(let h=i;1===a?h<=s:h>=s;h+=a){let i=!1
for(let s=0;s<di.length;s+=1){const a=di[s],l=e+a[0]*h,d=t+a[1]*h
this.getPosition(l,d)>=0&&(!o||this.canPass(l,d))&&(i=!0,n.call(r,l,d))}if(i)break}}traverseTilesOne(e,t,i,s,n=null,r=!0){for(let o=0;o<di.length;o+=1){
const a=di[o],h=e+a[0]*i,l=t+a[1]*i
this.getPosition(h,l)>=0&&(!r||this.canPass(h,l))&&s.call(n,h,l)}}findPoint(t,i,s,n,r,o,a){const h=(0,se.C8)(s,n,ci)
let l=2147483647,d=-1,c=-1
return this.traverseTiles(h.x,h.y,r,o,((e,s)=>{const n=(0,se.Ci)(e,s,ci),r=n.x,o=n.y,a=de(t,i,r,o)
a<l&&(l=a,d=r,c=o)})),-1!==d?(a||new e.Vec2).set(d,c):null}findPointOne(t,i,s,n,r=1,o=null){const a=(0,se.C8)(s,n,ci)
let h=2147483647,l=-1,d=-1
return this.traverseTilesOne(a.x,a.y,r,((e,s)=>{const n=(0,se.Ci)(e,s,ci),r=n.x,o=n.y,a=de(t,i,r,o)
a<h&&(h=a,l=r,d=o)})),-1!==l?(o||new e.Vec2).set(l,d):null}findPointByTestTile(t,i,s,n,r,o,a,h){const l=(0,se.C8)(t,i,ci),d=l.x,c=l.y,u=(0,
se.C8)(s,n,ci),_=u.x,m=u.y,y=a?Math.floor(8*Math.random())+1:1
let g=y,p=2147483647,f=-1,w=-1
if(this.traverseTiles(_,m,r,o,((e,t)=>{const i=(0,se.dJ)(d,c,e,t)
if(i<=p){if(i===p){if(g<=0)return}else g=y
g-=1,p=i,f=e,w=t}})),-1!==f){const t=(0,se.Ci)(f,w,ci)
return(h||new e.Vec2).set(t.x,t.y)}return null}getNearestWalkTile(t,i,s,n){let r=1,o=1,a=(0,se.TJ)(St.V_),h=[-a,0,a],l=s,d=n
for(;o<=10;){var c=Math.floor(3*Math.random()),u=Math.floor(3*Math.random())
l=s+h[c],d=n+h[u]
const t=(0,se.UT)(l,d)
if(this.canPass(t[0],t[1]))return new e.Vec2(l,d)
r++,r>30&&(o++,r=1,h=[-a*o,0,a*o])}return new e.Vec2(t,i)}})
var ui,_i,mi=s(61696)
let yi=(_i=class e{static get inst(){return null==e._inst&&(e._inst=new e),e._inst}constructor(){this._imgRecord={},this.loadAltas()}loadAltas(){
const e=vt.o.getRes(vt.o.getResId("atlas/fightword"))
if(e){const t=e.spriteFrames,i=he.o.LostHpManager.Ins_get()
for(const e of Object.keys(t)){let t=e.split("_"),s=0,n=0
3==t.length?s=100*i.getFightResultKeyByType(t[2]):4==t.length&&("+"==t[3]?s=100*i.getFightResultKeyByType(t[2])+10:"-"==t[3]?s=100*i.getFightResultKeyByType(t[2])+11:"0"==t[3]?s=100*i.getFightResultKeyByType(t[2])+12:(n=Number(t[3]),
s=100*i.getFightResultKeyByType(t[2])+n)),0!=s&&(this._imgRecord[s]=e)}}for(const e in this._imgRecord)e+":"+this._imgRecord[e]+"\n"}numImg(e){return this._imgRecord[e]}},
_i._inst=null,gi=ui=_i,pi="inst",fi=[i.Vx],wi=Object.getOwnPropertyDescriptor(ui,"inst"),vi=ui,Si={},Object.keys(wi).forEach((function(e){Si[e]=wi[e]})),
Si.enumerable=!!Si.enumerable,Si.configurable=!!Si.configurable,("value"in Si||Si.initializer)&&(Si.writable=!0),Si=fi.slice().reverse().reduce((function(e,t){return t(gi,pi,e)||e
}),Si),vi&&void 0!==Si.initializer&&(Si.value=Si.initializer?Si.initializer.call(vi):void 0,Si.initializer=void 0),void 0===Si.initializer&&(Object.defineProperty(gi,pi,Si),
Si=null),ui)
var gi,pi,fi,wi,vi,Si,Ci=s(68586),Ii=s(4925)
const Ri="fightword"
class bi{drawCanvas(e){}lateUpdate(e){}resetImg(e){const[t,i,s,n]=he.o.LostHpManager.Ins_get().GetAniEffPosY(e.type)
e.startTime=cus.currTime,e.dx=0,e.dy=0,e.effType=t,e.scaleEnd=n
const r=e.node
r.opacity=255,r.scale2d=s,r.setPosition(e.offsetX,e.offsetY+i)}clear(e){Ii.S.ins.playingNum--,Ci.D.release(e)}getAtlas(){return Ri}drawImage(e,t,i,s,n=.5){if(t){
const r=this.getFrameRect(Ri,t)
r&&(0,mi.tn)(e,i,s,r.width,r.height,0,n,Ri,t)}}drawImages(e,t,i,s,n=.5){if(t&&0!=t.length)for(let r=0;r<t.length;r++){const o=this.getImgName(t[r]),a=this.getFrameRect(Ri,o)
a&&(0,mi.tn)(e,i,s,a.width,a.height,0,n,Ri,o)}}getFrameRect(e,t){const i=vt.o.getRes(vt.o.getResId(`atlas/${e}`))
if(i){const e=i.getSpriteFrame(t)
if(e)return e.getRect()}return null}getImgName(e){return yi.inst.numImg(e)}}var Ti,Li=s(69734);(0,Li.M)(0)(Ti=class extends bi{constructor(...e){super(...e),this._symbol=null}
drawCanvas(e){const t=e.renderArray.length
this.drawImages(e,e.flowList,0,0),(0,mi.nR)(e.renderArray,t,e.renderArray.length,0,0,.5)}lateUpdate(t){const i=t.node,s=cus.currTime-t.startTime
2==t.effType?(t.dx=1*e.math.random()-5,t.dy=2):1==t.effType?(t.dx=1*e.math.random()-5,t.dy=-1):3==t.effType?(t.dx=5+1*e.math.random(),t.dy=2):4==t.effType||5==t.effType?(t.dx=0,
t.dy=2):6==t.effType?(t.dx=0,t.dy=-2):(t.dx=0,t.dy=2),i.x+=t.dx,i.y+=t.dy,i.scale2d<t.scaleEnd?(i.scale2d*=1.1,
i.scale2d>t.scaleEnd&&(i.scale2d=t.scaleEnd)):i.scale2d>t.scaleEnd&&(i.scale2d*=.9,i.scale2d<t.scaleEnd&&(i.scale2d=t.scaleEnd)),s>600&&(i.opacity=0),i.opacity<=0&&this.clear(t)}})
var Mi;(0,Li.M)(1)(Mi=class extends bi{drawCanvas(e){const t=e.renderArray.length
this.drawImages(e,e.flowList,0,0),(0,mi.nR)(e.renderArray,t,e.renderArray.length,0,0,.5)}lateUpdate(e){const t=e.node,i=cus.currTime-e.startTime
e.startSpeedY<0&&(e.startSpeedY=0),e.dx-=1.25,e.dy+=1.1*e.dx,e.startSpeedY>0&&(e.startSpeedY-=.15),t.y+=e.dy,t.scale2d<1.2&&(t.scale2d*=1.01),i>120?(e.dy=1.5+e.startSpeedY,
t.opacity-=Math.round(1*e.va*255),i>1500&&(t.active=!1,t.opacity=0)):e.dy=2+e.startSpeedY,t.opacity<=0&&this.clear(e)}})
class Ei{constructor(e,t){this.x=0,this.y=0,this.f=0,this.g=0,this.h=0,this.fatherNode=null,this.isOpen=!1,this.isClose=!1,this.x=e,this.y=t}}class xi{constructor(){
this.defaultCmp=(e,t)=>e<t?-1:e>t?1:0}insort(e,t,i=null,s=null,n=null){let r
if(null==i&&(i=0),null==n&&(n=this.defaultCmp),i<0)throw new Error("lo must be non-negative")
for(null==s&&(s=e.length);i<s;)r=Math.floor((i+s)/2),n(t,e[r])<0?s=r:i=r+1
return[].splice.apply(e,[i,i-i].concat(t)),t}heappush(e,t,i){return null==i&&(i=this.defaultCmp),e.push(t),this._siftdown(e,0,e.length-1,i)}heappop(e,t){let i,s
return null==t&&(t=this.defaultCmp),i=e.pop(),e.length?(s=e[0],e[0]=i,this._siftup(e,0,t)):s=i,s}heapreplace(e,t,i){let s
return null==i&&(i=this.defaultCmp),s=e[0],e[0]=t,this._siftup(e,0,i),s}heappushpop(e,t,i){let s
return null==i&&(i=this.defaultCmp),e.length&&i(e[0],t)<0&&(s=[e[0],t],t=s[0],e[0]=s[1],this._siftup(e,0,i)),t}heapify(e,t){let i,s
null==t&&(t=this.defaultCmp)
const n=(()=>{const t=[]
for(i=0,s=Math.floor(e.length/2);s>=0?i<s:i>s;s>=0?i++:i--)t.push(i)
return t}).apply(this).reverse(),r=[]
for(let i=0,s=n.length;i<s;i++){const s=n[i]
r.push(this._siftup(e,s,t))}return r}updateItem(e,t,i){let s
return null==i&&(i=this.defaultCmp),s=e.indexOf(t),-1===s?null:(this._siftdown(e,0,s,i),this._siftup(e,s,i))}nlargest(e,t,i){let s,n,r,o,a
if(null==i&&(i=this.defaultCmp),n=e.slice(0,t),!n.length)return n
for(this.heapify(n,i),a=e.slice(t),r=0,o=a.length;r<o;r++)s=a[r],this.heappushpop(n,s,i)
return n.sort(i).reverse()}nsmallest(e,t,i){let s,n,r,o,a,h,l,d,c,u
if(null==i&&(i=this.defaultCmp),10*t<=e.length){if(o=e.slice(0,t).sort(i),!o.length)return o
for(r=o[o.length-1],d=e.slice(t),a=0,l=d.length;a<l;a++)s=d[a],i(s,r)<0&&(this.insort(o,s,0,null,i),o.pop(),r=o[o.length-1])
return o}for(this.heapify(e,i),u=[],n=0,h=0,c=Math.min(t,e.length);c>=0?h<c:h>c;n=c>=0?++h:--h)u.push(this.heappop(e,i))
return u}_siftdown(e,t,i,s){let n,r,o
for(null==s&&(s=this.defaultCmp),n=e[i];i>t&&(o=i-1>>1,r=e[o],s(n,r)<0);)e[i]=r,i=o
return e[i]=n,n}_siftup(e,t,i){null==i&&(i=this.defaultCmp)
let s=e.length,n=t,r=e[t],o=2*t+1
for(;o<s;){let n=o+1
n<s&&!(i(e[o],e[n])<0)&&(o=n),e[t]=e[o],o=2*(t=o)+1}return e[t]=r,this._siftdown(e,n,t,i)}}class Ai{constructor(e=null){this.heapFunction=new xi,this.cmp=void 0,this.nodes=void 0,
this.cmp=null!=e?e:this.heapFunction.defaultCmp,this.nodes=[]}push(e){return this.heapFunction.heappush(this.nodes,e,this.cmp)}pop(){
return this.heapFunction.heappop(this.nodes,this.cmp)}peek(){return this.nodes[0]}contains(e){return-1!==this.nodes.indexOf(e)}replace(e){
return this.heapFunction.heapreplace(this.nodes,e,this.cmp)}pushpop(e){return this.heapFunction.heappushpop(this.nodes,e,this.cmp)}heapify(){
return this.heapFunction.heapify(this.nodes,this.cmp)}updateItem(e){return this.heapFunction.updateItem(this.nodes,e,this.cmp)}clear(){return this.nodes=[]}empty(){
return 0===this.nodes.length}size(){return this.nodes.length}clone(){const e=new Ai
return e.nodes=this.nodes.slice(0),e}toArray(){return this.nodes.slice(0)}}class Pi{constructor(){this.m_maxTry=4e4,this.nodeMap=null,this.mapTiles=null}find(e,t,i,s,n=0){
if(!this.canPass(i,s))return null
const r=new Ai(((e,t)=>e.f-t.f))
0==n&&(n=this.m_maxTry),this.nodeMap=[]
const o=this.getOrCreateNode(e,t),a=this.getOrCreateNode(i,s)
let h
const l=Pi.manhattan,d=Math.abs
let c,u,_,m,y=0
for(o.g=0,o.f=0,r.push(o),o.isOpen=!0;!r.empty();){if(++y>n)return null
if(h=r.pop(),h.isClose=!0,Pi.isEnd(h,a))return Pi.backtrace(h)
const e=this.getArounds(h)
for(c=0,u=e.length;c<u;c++){if(m=e[c],Pi.isEnd(m,a))return m.fatherNode=h,Pi.backtrace(m)
_=h.g+(m.x-h.x==0||m.y-h.y==0?1:Math.SQRT2),(!m.isOpen||_<m.g)&&(m.g=_,m.h=l(d(m.x-a.x),d(m.y-a.y)),m.f=m.g+m.h,m.fatherNode=h,m.isOpen?r.updateItem(m):(r.push(m),m.isOpen=!0))}}
return null}static manhattan(e,t){return e+t}static isEnd(e,t){return e.x==t.x&&e.y==t.y}getOrCreateNode(e,t){if(this.nodeMap[e]&&null!=this.nodeMap[e][t])return this.nodeMap[e][t]
const i=new Ei(e,t)
return this.nodeMap[e]||(this.nodeMap[e]=[]),this.nodeMap[e][t]=i,i}getArounds(e){let t,i
const s=[]
let n,r,o,a
for(let h=0;h<Pi.aroundArr.length;h++){const l=Pi.aroundArr[h]
if(t=e.x+l[0],i=e.y+l[1],this.canPass(t,i)){if(4==h){if(n=e.x+Pi.aroundArr[0][0],r=e.y+Pi.aroundArr[0][1],o=e.x+Pi.aroundArr[1][0],a=e.y+Pi.aroundArr[1][1],
!this.canPass(n,r)&&!this.canPass(o,a))continue}else if(5==h){if(n=e.x+Pi.aroundArr[2][0],r=e.y+Pi.aroundArr[2][1],o=e.x+Pi.aroundArr[1][0],a=e.y+Pi.aroundArr[1][1],
!this.canPass(n,r)&&!this.canPass(o,a))continue}else if(6==h){if(n=e.x+Pi.aroundArr[2][0],r=e.y+Pi.aroundArr[2][1],o=e.x+Pi.aroundArr[3][0],a=e.y+Pi.aroundArr[3][1],
!this.canPass(n,r)&&!this.canPass(o,a))continue}else if(7==h&&(n=e.x+Pi.aroundArr[0][0],r=e.y+Pi.aroundArr[0][1],o=e.x+Pi.aroundArr[3][0],a=e.y+Pi.aroundArr[3][1],
!this.canPass(n,r)&&!this.canPass(o,a)))continue
const l=this.getOrCreateNode(t,i)
l.isClose||s.push(l)}}return s}canPass(e,t){return!!this.mapTiles&&this.mapTiles.canPass(e,t,!1)}checkCopyBloodSafeCanpass(e,t){return!0}checkDynamicCanPass(){return!1}
static backtrace(e){const t=[]
for(t.push([e.x,e.y]);e.fatherNode;)e=e.fatherNode,t.push([e.x,e.y])
return t.reverse()}}var Oi,Ni
Pi.aroundArr=[[1,0],[0,1],[-1,0],[0,-1],[1,1],[-1,1],[-1,-1],[1,-1]];(0,i.wT)("engine.APath")((Ni=class e extends Pi{canPath(e,t){const i=e,s=t
return!!this.canPass(i,s)}findPath(t,i,s,n,r=0,o=0){if(isNaN(s)||isNaN(n))return console.error("上层逻辑错误，传进来的目标点为nan"),null
if(t==s&&i==n)return null
const a=Math.abs(s-t),h=Math.abs(n-i),l=a?(s-t)/a:0,d=h?(n-i)/h:0
let c=t,u=i
const _=(n-i)/(s-t)
let m=!0
for(;;){if(!this.canPass(c,u)){m=!1
break}if(c==s&&u==n)break
const e=(c-t+.5*l)*_
if(Math.abs(e)<Math.abs(u-i+.5*d))c+=l
else if(Math.abs(e)>Math.abs(u-i+.5*d))u+=d
else{if(!this.canPass(c+l,u)&&!this.canPass(c,u+d)){m=!1
break}c+=l,u+=d}}if(m){const e=Math.atan2(n-i,s-t)
return[[t,i],[s-Math.round(r*Math.cos(e)),n-Math.round(r*Math.sin(e))]]}const y=this.find(t,i,s,n,o)
if(y){const t=Math.max(1,y.length-r)
let i=y.slice(0,t)
return i&&(i=e.combineAndSplitStraight(i)),i}return console.log("寻路返回null 怪物是不是配到障碍点了?"),null}canPassLiner(e,t,i,s,n=0,r=0){
if(isNaN(i)||isNaN(s))return console.error("上层逻辑错误，传进来的目标点为nan"),!1
if(e==i&&t==s)return!0
const o=Math.abs(i-e),a=Math.abs(s-t),h=o?(i-e)/o:0,l=a?(s-t)/a:0
let d=e,c=t
const u=(s-t)/(i-e)
let _=!0
for(;;){if(!this.canPass(d,c)){_=!1
break}if(d==i&&c==s)break
const n=(d-e+.5*h)*u
if(Math.abs(n)<Math.abs(c-t+.5*l))d+=h
else if(Math.abs(n)>Math.abs(c-t+.5*l))c+=l
else{if(!this.canPass(d+h,c)&&!this.canPass(d,c+l)){_=!1
break}d+=h,c+=l}}return _}static combineAndSplitStraight(t){const i=[]
let s,n=-1
const r=t.length-1
let o=0,a=0
for(;a<r;a++)s=e.countTileDirection(t[a],t[a+1]),s!=n?i.push(t[a]):o>=e.SPLIT_GRID_LENGTH&&(i.push(t[a]),o=0),o++,n=s
return i.push(t[a]),i}static countTileDirection(e,t){return e[1]==t[1]&&e[0]==t[0]?4:e[1]==t[1]?e[0]<t[0]?2:6:e[0]==t[0]?e[1]<t[1]?4:0:e[0]<t[0]?e[1]<t[1]?3:1:e[1]<t[1]?5:7}
isNaNorBlock(e,t){return!(!isNaN(e)&&!isNaN(t))||!this.canPass(e,t)}},Ni.SPLIT_GRID_LENGTH=6,Oi=Ni))
var Di=s(71014),Bi=s(47097)
const Vi=e.Component
var ki;(0,Di.iV)(Bi.c.Sync,"MainPlayer")(ki=(0,e._decorator.ccclass)(ki=class extends Vi{onSceneReadyed(){
he.o.LuaDisplayBridgeManager&&he.o.LuaDisplayBridgeManager.Instance_get().CreateAfterSceneReadyed()}})||ki)
var Fi
new e.Vec2;(0,Di.iV)(Bi.c.Sync)(Fi=(0,e._decorator.ccclass)(Fi=class extends Vi{onSceneMouseEvent(e,t,i){if(he.o.CharacterMgr){const[s,n]=(0,se.v9)(t,i)
he.o.CharacterMgr.Inst.OnTapOrHold(e,s,n)}}})||Fi)})(),n=s.O(n)})()
