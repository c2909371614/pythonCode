"use strict";(globalThis.webpackChunkProject=globalThis.webpackChunkProject||[]).push([[16],{26421:(e,t,i)=>{i.d(t,{k:()=>g})
var n=i(18998),s=i(87115),l=i(95721),a=i(85602),r=i(86133),o=i(66788)
class d{}d.BOOL=-2,d.BYTE=-3,d.CHAR=-4,d.SHORT=-5,d.INT=-6,d.LONG=-7,d.FLOAT=-8,d.DOUBLE=-9,d.BOOL_JAVA=-10,d.BYTE_JAVA=-11,d.CHAR_JAVA=-12,d.SHORT_JAVA=-13,d.INT_JAVA=-14,
d.LONG_JAVA=-15,d.FLOAT_JAVA=-16,d.DOUBLE_JAVA=-17,d.STRING_JAVA=-18,d.AbstractCollection_JAVA=-21,d.AbstractList_JAVA=-22,d.ArrayList_JAVA=-24,d.LinkedList_JAVA=-27,
d.Vector_JAVA=-29,d.List_JAVA=-30,d.AbstractMap_JAVA=-31,d.Attributes_JAVA=-32,d.HashMap_JAVA=-33,d.Map_JAVA=-39,d.BEAN=-1e3,d.BEAN_NULL=-1611
var h=i(82198)
let u={[-1134]:!0,[-1104]:!0,[-1105]:!0,[-1101]:!0,[-1231]:!0,[-1241]:!0,[-1301]:!0,[-1342]:!0,[-1341]:!0,[-1261]:!0,[-1111]:!0,[-11522]:!0,[-1238]:!0
},c=[11,187,37,61,91],I=0,_=1,p=[3,17,31,67],S=0
class g{static GetNextProtoKey(){let e=S
e*=31,e>2147483647&&(e%=2147483647)
for(let t=0;t<5;t++)e=31*e+c[t],e>2147483647&&(e%=2147483647)
for(let t=0;t<_;t++)e=31*e+I,e>2147483647&&(e%=2147483647)
return S+=p[S%4+1],S>2147483647&&(S%=2147483647),e}static SetProtoIndex(e,t){S=e,I=t,_=I%4+4}GetProtoIndex(){return[S,I]}getId(){return 0}static ClearReadBuffer(){
h.b.readBuffer.clear()}static ClearWriteBuffer(){h.b.writeBuffer.clear()}writeInt(e){h.b.writeBuffer.writeVarInt(e)}writeString(e){h.b.writeBuffer.writeVarString(e)}writeLong1(e){
h.b.writeBuffer.writeLusuoLong(e)}writeLong(e){
"string"==typeof e?h.b.writeBuffer.writeLusuoLong(l.o.FromString(e)):"number"==typeof e?h.b.writeBuffer.writeLusuoLong(l.o.FromNumber(e)):h.b.writeBuffer.writeLusuoLong(e)}
writeIntArray(e){const t=e?e.length:0
h.b.writeBuffer.writeVarInt(t)
for(let i=0;i<t;i++)h.b.writeBuffer.writeVarInt(e[i])}writeStringList2Array(e){throw new Error("cannnot write")}writeIntList2Array(e){const t=e?e.length:0
h.b.writeBuffer.writeVarInt(t)
for(let i=0;i<t;i++)h.b.writeBuffer.writeVarInt(e[i])}WriteOneByteByUInt(e){h.b.writeBuffer.writeByte(e)}writeIntList(e){
if(null==e||0==e.length)return void h.b.writeBuffer.writeVarInt(-1)
h.b.writeBuffer.writeVarInt(-24)
const t=e.length
this.writeInt(t),this.WriteOneByteByUInt(1),this.writeInt(d.INT_JAVA)
for(let i=0;i<=t-1;i++)this.writeInt(e[i])}writeIntMessageDic(e){throw new Error("cannot writeIntMessageDic")}readLong(){return h.b.readBuffer.readLusuoLong()}readLongToNumber(){
return h.b.readBuffer.readLusuoLong().ToNum()}writeBean(e=null){null==e?this._writeFixShort(-1):(this._writeFixShort(e.getId()),e.write())}writeShort(e){
h.b.writeBuffer.writeUnsignedShort(e)}writeFloat(e){h.b.writeBuffer.writeFloat(e)}writeByte(e){h.b.writeBuffer.writeByte(e)}readBool(){return h.b.readBuffer.readBoolean()}
writeBool(e){h.b.writeBuffer.writeBoolean(e)}writeArray(e){const t=e.length
this.writeInt(t)
for(let i=0;i<t;i++)this.writeBean(e[i])}writeLongList(e){if(null==e||0==e.length)return void h.b.writeBuffer.writeVarInt(-1)
h.b.writeBuffer.writeVarInt(-24)
const t=e.length
h.b.writeBuffer.writeVarInt(t),this.WriteOneByteByUInt(1),this.writeInt(d.LONG_JAVA)
for(let i=0;i<=t-1;i++)this.writeLong(e[i])}writeLongArray(e){const t=e.length
this.writeInt(t)
for(let i=0;i<t;i++)this.writeLong(e[i])}writeList(e){if(null==e||0==e.length)return void h.b.writeBuffer.writeVarInt(-1)
this.writeShort(-24)
const t=e.length
this.writeInt(t),this.WriteOneByteByUInt(1)
const i=e[0].getId()
this.writeShort(i)
for(let i=0;i<=t-1;i++)this.writeBeanWithoutId(e[i])}writeBeanWithoutId(e){null==e?h.b.writeBuffer.writeVarInt(-1):e.write()}readInt(){return h.b.readBuffer.readVarInt()}
readString(){return h.b.readBuffer.readVarString()}readBean(e){const t=this.readInt()
if(-1==t)return null
const i=g.F_GetMessage(t)
return null==i?(o.Y.LogError(`Message${t+(0,r.T)("没有注册，导致无法读取")}`),null):(i.reading(),i)}readShort(){return h.b.readBuffer.readShort()}_readFixShort(){
return h.b.readBuffer.readVarInt()}_writeFixShort(e){h.b.writeBuffer.writeVarInt(e)}readByte(){return h.b.readBuffer.readByte()}readFloat(){return h.b.readBuffer.readFloat()}
readMessageArray(){const e=new a.Z,t=this.readInt()
if(t>0){let i=null
for(let n=0;n<t;n++)if(i=this._readFixShort(),-1==i)e.Add(null)
else{const t=g.F_GetMessage(i)
t.reading(),e.Add(t)}}return e}readMsgTemplateList(e){const t=this.readInt()
if(t<=0)return
let i=null
for(let n=0;n<=t-1;n++)if(i=this._readFixShort(),-1==i)e.Add(null)
else{const t=g.F_GetMessage(i)
null==t?o.Y.LogError(`Message${i+(0,r.T)("没有注册，导致无法读取")}`):(t.reading(),e.Add(t))}}readMessageList2List(e){if(-1==this._readFixShort())return
const t=this.readInt()
if(t<=0)return
let i=null
let n=null
if(1==this.readByte()){i=this._readFixShort()
for(let s=0;s<=t-1;s++)n=g.F_GetMessage(i),n.reading(),e.Add(n)}else for(let s=0;s<=t-1;s++)i=this._readFixShort(),n=g.F_GetMessage(i),n.reading(),e.Add(n)}readMessageList(){
if(-1==this._readFixShort())return null
const e=this.readInt(),t=new a.Z
if(0!=e)if(1==this.readByte()){const i=this._readFixShort()
for(let n=0;n<e;n++){const e=g.F_GetMessage(i)
e.reading(),t.push(e)}}else for(let i=0;i<e;i++){const e=this._readFixShort(),i=g.F_GetMessage(e)
i.reading(),t.push(i)}return t}readIntArray(){const e=new a.Z,t=this.readInt()
if(0!=t)for(let i=0;i<t;i++)e[i]=this.readInt()
return e}readIntListFromArray(){const e=new a.Z,t=this.readInt()
if(0!=t)for(let i=0;i<t;i++)e[i]=this.readInt()
return e}readIntListFromList(){const e=new a.Z
if(-1!=this._readFixShort()){const t=this.readInt()
if(0!=t){this.readByte()
this._readFixShort()
for(let i=0;i<t;i++)e[i]=this.readInt()}}return e}readIntList(){if(-1==this._readFixShort())return null
const e=new a.Z,t=this.readInt()
if(0!=t){this.readByte()
this._readFixShort()
for(let i=0;i<t;i++)e[i]=this.readInt()}return e}readShortArray(){const e=new a.Z,t=this.readInt()
if(0!=t)for(let i=0;i<t;i++)e[i]=this.readShort()
return e}readShortList(){if(-1==this._readFixShort())return null
const e=new a.Z,t=this.readInt()
if(0!=t){this.readByte()
this._readFixShort()
for(let i=0;i<t;i++)e[i]=this.readShort()}return e}readStringArray(){const e=new a.Z,t=this.readInt()
if(0!=t)for(let i=0;i<t;i++)e[i]=this.readString()
return e}readStringList(){if(-1==this._readFixShort())return null
const e=new a.Z,t=this.readInt()
if(0!=t){this.readByte()
this._readFixShort()
for(let i=0;i<t;i++)e[i]=this.readString()}return e}readByteArray(){const e=new a.Z,t=this.readInt()
if(0!=t)for(let i=0;i<t;i++)e[i]=this.readByte()
return e}readByteList(){if(-1==this._readFixShort())return null
const e=new a.Z,t=this.readInt()
if(0!=t){this.readByte()
this._readFixShort()
for(let i=0;i<t;i++)e[i]=this.readByte()}return e}readLongList(){if(-1==this._readFixShort())return null
const e=new a.Z,t=this.readInt()
if(0!=t){this.readByte()
this._readFixShort()
for(let i=0;i<t;i++)e[i]=this.readLong()}return e}readLongNumberList(){if(-1==this._readFixShort())return null
const e=new a.Z,t=this.readInt()
if(0!=t){this.readByte()
this._readFixShort()
for(let i=0;i<t;i++)e[i]=this.readLongToNumber()}return e}readLongArray(){const e=new a.Z,t=this.readInt()
if(0!=t)for(let i=0;i<t;i++)e[i]=this.readLong()
return e}readLongNumberArray(){const e=new a.Z,t=this.readInt()
if(0!=t)for(let i=0;i<t;i++)e[i]=this.readLongToNumber()
return e}getDicContentTypeMultiReturn(){let e=0,t=0,i=!1,n=!1
const s=this.readByte()
return n=0==(1&s),i=0==(2&s),n||(e=this._readFixShort()),i||(t=this._readFixShort()),[e,t,n,i]}checkDicContentEmpty(){return-1==this._readFixShort()?0:this.readInt()}
writeLongIntDic(e){if(null==e)h.b.writeBuffer.writeVarInt(-1)
else{const t=d.LONG_JAVA,i=d.INT
this.writeShort(d.HashMap_JAVA)
const n=e.LuaDic_Keys(),s=n.Count()
if(this.writeInt(s),s>0){const l=!0,a=!0
l&&a?this.writeByte(3):l?this.writeByte(1):a?this.writeByte(2):this.writeByte(0),l&&this.writeShort(t),a&&this.writeShort(i)
let r=null,o=null
for(let t=0;t<=s-1;t++)r=n[t],o=e.LuaDic_GetItem(r),this.writeLong(r),this.writeInt(o)}}}writeIntBoolDic(e){if(null==e)h.b.writeBuffer.writeVarInt(-1)
else{const t=d.INT,i=d.BOOL
this.writeShort(d.HashMap_JAVA)
const n=e.LuaDic_Keys(),s=n.Count()
if(this.writeInt(s),s>0){const l=!0,a=!0
l&&a?this.writeByte(3):l?this.writeByte(1):a?this.writeByte(2):this.writeByte(0),l&&this.writeShort(t),a&&this.writeShort(i)
for(let t=0;t<=s-1;t++){const i=n[t],s=e.LuaDic_GetItem(i)
this.writeInt(Number(i)),this.writeBool(s)}}}}readIntToIntDic(e){const t=this.checkDicContentEmpty()
if(0==t)return
let[i,s,l,a]=this.getDicContentTypeMultiReturn()
if(t>1e5)(0,n.error)((0,r.T)("长度超过限制，两端协议有可能不匹配，消息")+(s+(0,r.T)("被忽略")))
else for(let n=0;n<=t-1;n++){l&&(i=this._readFixShort())
const t=this.readInt()
a&&(s=this._readFixShort()),e.LuaDic_SetItem(t,this.readInt())}}writeIntIntDic(e){if(null==e)h.b.writeBuffer.writeVarInt(-1)
else{const t=d.INT,i=d.INT
h.b.writeBuffer.writeVarInt(d.HashMap_JAVA)
const n=e.LuaDic_Keys(),s=n.Count()
if(h.b.writeBuffer.writeVarInt(s),s>0){const l=!0,a=!0
l&&a?this.writeByte(3):l?this.writeByte(1):a?this.writeByte(2):this.writeByte(0),l&&h.b.writeBuffer.writeVarInt(t),a&&h.b.writeBuffer.writeVarInt(i)
for(let t=0;t<=s-1;t++){const i=n[t],s=e.LuaDic_GetItem(i)
this.writeInt(Number(i)),this.writeInt(s)}}}}writeIntStringDic(e){if(null==e)h.b.writeBuffer.writeVarInt(-1)
else{const t=d.INT,i=d.STRING_JAVA
this.writeInt(d.HashMap_JAVA)
const n=e.LuaDic_Keys(),s=n.Count()
if(this.writeInt(s),s>0){const l=!0,a=!0
l&&a?this.writeByte(3):l?this.writeByte(1):a?this.writeByte(2):this.writeByte(0),l&&this.writeInt(t),a&&this.writeInt(i)
let r=null,o=null
for(let t=0;t<=s-1;t++)r=n[t],o=e.LuaDic_GetItem(r),this.writeInt(Number(r)),this.writeString(o)}}}writeByteIntDic(e){}writeIntByteDic(e){if(null==e)h.b.writeBuffer.writeVarInt(-1)
else{const t=d.INT,i=d.BYTE
this.writeShort(d.HashMap_JAVA)
const n=e.LuaDic_Keys(),s=n.Count()
if(this.writeInt(s),s>0){const l=!0,a=!0
l&&a?this.writeByte(3):l?this.writeByte(1):a?this.writeByte(2):this.writeByte(0),l&&this.writeShort(t),a&&this.writeShort(i)
let r=null,o=null
for(let t=0;t<=s-1;t++)r=n[t],o=e.LuaDic_GetItem(r),this.writeInt(Number(r)),this.writeByte(o)}}}writeStringByteDic(e){if(null==e)h.b.writeBuffer.writeVarInt(-1)
else{const t=d.STRING_JAVA,i=d.BYTE
this.writeShort(d.HashMap_JAVA)
const n=e.LuaDic_Keys(),s=n.Count()
if(this.writeInt(s),s>0){const l=!0,a=!0
l&&a?this.writeByte(3):l?this.writeByte(1):a?this.writeByte(2):this.writeByte(0),l&&this.writeShort(t),a&&this.writeShort(i)
let r=null,o=null
for(let t=0;t<=s-1;t++)r=n[t],o=e.LuaDic_GetItem(r),this.writeString(r),this.writeByte(o)}}}writeStringStringDic(e){if(null==e)h.b.writeBuffer.writeVarInt(-1)
else{const t=d.STRING_JAVA,i=d.STRING_JAVA
h.b.writeBuffer.writeVarInt(d.HashMap_JAVA)
const n=e.LuaDic_Keys(),s=n.Count()
if(this.writeInt(s),s>0){const l=!0,a=!0
l&&a?this.writeByte(3):l?this.writeByte(1):a?this.writeByte(2):this.writeByte(0),l&&h.b.writeBuffer.writeVarInt(t),a&&h.b.writeBuffer.writeVarInt(i)
let r=null,o=null
for(let t=0;t<=s-1;t++)r=n[t],o=e.LuaDic_GetItem(r),this.writeString(r),this.writeString(o)}}}readLongToFloatDic(e){const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readLong(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a.ToLongStr(),this.readFloat())}readIntToShortDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readInt(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a,this.readShort())}readIntToBoolDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readInt(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a,this.readBool())}readIntToStringDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readInt(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a,this.readString())}readIntToLongDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readInt(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a,this.readLong())}readIntToLongNumberDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readInt(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a,this.readLongToNumber())}readIntToNumberByLongDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readInt(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a,this.readLongToNumber())}readIntToByteDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readInt(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a,this.readByte())}readIntToMessageDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,s,l,a]=this.getDicContentTypeMultiReturn(),o=null
for(let h=0;h<=t-1;h++)if(l&&(i=this._readFixShort()),o=this.readInt(),a&&(s=this._readFixShort()),-1==s||s==d.BEAN_NULL)e.LuaDic_SetItem(o,null)
else{const t=g.F_GetMessage(s)
null==t?(0,n.error)((0,r.T)("消息")+(s+(0,r.T)("没注册"))):(t.reading(),e.LuaDic_SetItem(o,t))}}readShortToIntDic(e){const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readShort(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a,this.readInt())}readShortToShortDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readShort(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a,this.readShort())}readShortToStringDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readShort(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a,this.readString())}readShortToLongDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readShort(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a,this.readLong())}readShortToByteDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readShort(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a,this.readByte())}readShortToMessageDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)if(s&&(i=this._readFixShort()),a=this.readShort(),l&&(n=this._readFixShort()),-1==n||n==d.BEAN_NULL)e.LuaDic_SetItem(a,null)
else{const t=g.F_GetMessage(n)
t.reading(),e.LuaDic_SetItem(a,t)}}readStringToIntDic(e){const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readString(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a,this.readInt())}readStringToShortDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readString(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a,this.readShort())}readStringToStringDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readString(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a,this.readString())}readStringToLongDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readString(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a,this.readLong())}readStringToByteDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readString(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a,this.readByte())}readStringToMessageDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)if(s&&(i=this._readFixShort()),a=this.readString(),l&&(n=this._readFixShort()),-1==n||n==d.BEAN_NULL)e.LuaDic_SetItem(a,null)
else{const t=g.F_GetMessage(n)
t.reading(),e.LuaDic_SetItem(a,t)}}readByteToIntDic(e){const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readByte(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a,this.readInt())}readByteToShortDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readByte(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a,this.readShort())}readByteToStringDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readByte(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a,this.readString())}readByteToLongDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readByte(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a,this.readLong())}readByteToByteDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readByte(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a,this.readByte())}readByteToMessageDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)if(s&&(i=this._readFixShort()),a=this.readByte(),l&&(n=this._readFixShort()),-1==n||n==d.BEAN_NULL)e.LuaDic_SetItem(a,null)
else{const t=g.F_GetMessage(n)
t.reading(),e.LuaDic_SetItem(a,t)}}readLongToIntDic(e){const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readLong(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a,this.readInt())}readLongToShortDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readLong(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a,this.readShort())}readLongToStringDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readLong(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a,this.readString())}readLongToLongDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readLong(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a,this.readLong())}readLongToByteDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)s&&(i=this._readFixShort()),a=this.readLong(),l&&(n=this._readFixShort()),e.LuaDic_SetItem(a,this.readByte())}readLongToMessageDic(e){
const t=this.checkDicContentEmpty()
if(0==t)return
let[i,n,s,l]=this.getDicContentTypeMultiReturn(),a=null
for(let r=0;r<=t-1;r++)if(s&&(i=this._readFixShort()),a=this.readLong(),l&&(n=this._readFixShort()),-1==n||n==d.BEAN_NULL)e.LuaDic_SetItem(a,null)
else{const t=g.F_GetMessage(n)
t.reading(),e.LuaDic_SetItem(a,t)}}writing(){return!0}reading(){return!0}read(){this.reading()}write(){this.writing()}writeProtoKey(){if(0==I)return
const e=this.getId()
if(u[e])return
const t=g.GetNextProtoKey()
this.writeInt(t)}static F_GetMessage(e){const t=s.vr[e]
return null!=t?new t:null}clearData(){}clear(){}}},98497:(e,t,i)=>{i.d(t,{j:()=>a})
var n=i(38962),s=i(86133),l=i(66788)
class a{constructor(){this.messages=null,this.handlers=null,this.messages=new n.X,this.handlers=new n.X}static get Inst(){return null==a.inst&&(a.inst=new a),a.inst}
F_Register(e,t,i){this.messages.LuaDic_ContainsKey(e)||this.messages.LuaDic_Add(e,t),this.handlers.LuaDic_ContainsKey(e)||this.handlers.LuaDic_Add(e,i)}F_Unregister(e){
this.messages.LuaDic_ContainsKey(e)&&this.messages.LuaDic_Remove(e),this.handlers.LuaDic_ContainsKey(e)&&this.handlers.LuaDic_Remove(e)}F_RegisterBean(e,t){
this.messages.LuaDic_ContainsKey(e)||this.messages.LuaDic_Add(e,t)}F_GetMessage(e){if(this.messages.LuaDic_ContainsKey(e)){return new(this.messages.LuaDic_GetItem(e))}
return l.Y.LogError((0,s.T)("没有找到指定消息类型，消息id为:")+e),null}F_GetMessageCls(e){if(this.messages.LuaDic_ContainsKey(e)){return this.messages.LuaDic_GetItem(e)}return l.Y.LogError((0,
s.T)("没有找到指定消息类型，消息id为:")+e),null}F_SendHandler(e,t){if(this.handlers.LuaDic_ContainsKey(e)){const i=this.handlers.LuaDic_GetItem(e)
if(null==i)try{i(t)}catch(e){console.error(e)}}}}a.inst=void 0},82198:(e,t,i)=>{i.d(t,{b:()=>s})
var n=i(89123)
class s{static __StaticInit(){this.readBuffer=new n.SK,this.writeBuffer=new n.SK}}s.readBuffer=void 0,s.writeBuffer=void 0,s.__StaticInit()},38935:(e,t,i)=>{i.d(t,{C:()=>X})
var n=i(54986),s=i(39407),l=i(34272),a=i(20099),r=i(35280),o=i(98130),d=i(98885),h=i(85602),u=i(38962),c=i(16854),I=i(77546),_=i(86133),p=i(22692),S=i(97461),g=i(65815),m=i(67493),f=i(16812),C=i(66788),T=i(98497),y=i(82198),A=i(67642)
let P=null,w=null,R=null,D=null,L=null,E=0,B=0,M=0,G=0,O=0,U=0,b=0,F=0,k=!1,v=0,N=0,V=0,x=0,H=0,Z=0
class Y{static __StaticInit(){P=A.S.CreateTableArr2048(0),w=A.S.CreateTableArr2048(""),R=A.S.CreateTableArr2048(0),D=A.S.CreateTableArr2048(0),L=A.S.CreateTableArr2048(0)}
static Init(e,t,i,n,s){Y.Reset(),E=e,B=t,M=i,G=s,v=n}static Reset(){E=0,B=0,M=0,G=0,O=1,U=1,b=1,F=1,N=1}static IsNullByIntList(){return O<=E}static GetCurUIntVal(){let e=0
return 0==Z?(k=!0,C.Y.LogError("协议读取错误")):G>=F&&(e=D[F],F+=1,Z-=1),e}static GetCurIntVal(){let e=0
return 0==V?(k=!0,C.Y.LogError("协议读取错误")):E>=O&&(e=P[O],O+=1,V-=1),e}static GetCurStringVal(){let e=""
return 0==H?(k=!0,C.Y.LogError("协议读取错误")):B>=U&&(e=w[U],U+=1,H-=1),e}static GetCurFloatVal(){let e=0
return 0==x?(k=!0,C.Y.LogError("协议读取错误")):M>=b&&(e=R[b],b+=1,x-=1),e}static SetCurPoolDataLength(){null==L||N>=v?C.Y.LogError((0,_.T)("协议内容不能为空")):(V=L[N+0],x=L[N+1],H=L[N+2],
Z=L[N+3],N+=4)}static ClearCurPoolDataLength(){0!=V&&(O+=V),0!=x&&(b+=x),0!=H&&(U+=H),0!=Z&&(F+=Z),V=0,x=0,H=0,Z=0,k=!1}static PoolIsEqual(){let e=!0
return(k||0!=V||0!=x||0!=H||0!=Z)&&(e=!1),e}}Y.__StaticInit()
let W=null,K=0,z=0,j=null
class X extends f.k{static get Inst(){return this._Inst||(this._Inst=new X),this._Inst}static __StaticInit(){X.AUTO_RECYLE.LuaDic_Add(-1405,1),X.AUTO_RECYLE.LuaDic_Add(-1112,1),
X.AUTO_RECYLE.LuaDic_Add(-1222,1),X.AUTO_RECYLE.LuaDic_Add(-1308,1),X.AUTO_RECYLE.LuaDic_Add(-1410,1),X.AUTO_RECYLE.LuaDic_Add(-1208,1),X.AUTO_RECYLE.LuaDic_Add(-1234,1),
X.AUTO_RECYLE.LuaDic_Add(-1305,1),X.AUTO_RECYLE.LuaDic_Add(-1304,1),X.AUTO_RECYLE.LuaDic_Add(-1232,1),X.AUTO_RECYLE.LuaDic_Add(-1221,1),X.AUTO_RECYLE.LuaDic_Add(-1235,1),
X.AUTO_RECYLE.LuaDic_Add(-1303,1),X.AUTO_RECYLE.LuaDic_Add(-1202,1),X.AUTO_RECYLE.LuaDic_Add(-1402,1),X.AUTO_RECYLE.LuaDic_Add(-1209,1),X.AUTO_RECYLE.LuaDic_Add(-1517,1),
X.AUTO_RECYLE.LuaDic_Add(-1906,1),X.AUTO_RECYLE.LuaDic_Add(-3103,1),X.AUTO_RECYLE.LuaDic_Add(-1697,1),X.AUTO_RECYLE.LuaDic_Add(-1271,1),X.AUTO_RECYLE.LuaDic_Add(-1268,1),
X.AUTO_RECYLE.LuaDic_Add(-1985,1),X.AUTO_RECYLE.LuaDic_Add(-2044,1),X.AUTO_RECYLE.LuaDic_Add(-2002,1),X.AUTO_RECYLE.LuaDic_Add(-1996,1),X.AUTO_RECYLE.LuaDic_Add(-1984,1),
X.AUTO_RECYLE.LuaDic_Add(-2506,1),X.AUTO_RECYLE.LuaDic_Add(-1201,1),X.AUTO_RECYLE.LuaDic_Add(-1203,1),X.AUTO_RECYLE.LuaDic_Add(-1215,1),X.AUTO_RECYLE.LuaDic_Add(-1904,1),
X.AUTO_RECYLE.LuaDic_Add(-1302,1),X.AUTO_RECYLE.LuaDic_Add(-1301,1),X.AUTO_RECYLE.LuaDic_Add(-1511,1),X.AUTO_RECYLE.LuaDic_Add(-1512,1),X.AUTO_RECYLE.LuaDic_Add(-1698,1),
X.AUTO_RECYLE.LuaDic_Add(-11662,1),X.AUTO_RECYLE.LuaDic_Add(-11664,1),X.AUTO_RECYLE.LuaDic_Add(-11663,1),X.AUTO_RECYLE.LuaDic_Add(-1695,1),X.AUTO_RECYLE.LuaDic_Add(-11674,1),
X.AUTO_RECYLE.LuaDic_Add(-1333,1),
X.AUTO_RECYLE.LuaDic_Add(-1332,1),W=(e,t,i)=>"__isInstance"==t||"_class_type_"==t||"_class_type_meta_cache_"==t||"m_buf"==t||"object"==typeof i?[2,null]:[0,null],j=new h.Z}
constructor(e){super(e,c.J.eSocketManager),this.v_StartTime=0,this.v_SendMsgByte=0,this.v_ReveiveMsgByte=0,this.lua_Socket=null,this.crossServerSocket=null,this.messagePools=null,
this._lascheckPoolTime=0,this.DTime=0,this._degf__RecycleMessagePoolsOnGC=null,this.lua_Socket=new g.p(!0),this.crossServerSocket=new g.p(!1),this.messagePools=new u.X,
this._degf__RecycleMessagePoolsOnGC=e=>{this._RecycleMessagePoolsOnGC(e)}}Recycle_MessagePools(e){const t=e.getId()
e.clearData()
this._GetMessagePool(t,e.constructor).RecycleObj(e)}Getv_MessagePools(e,t){return this._GetMessagePool(e,t).GetObj()}_GetMessagePool(e,t){let i=this.messagePools.LuaDic_GetItem(e)
return null!=i||(i=new r.h,i.key=e,i.maxPoolCount=X.AUTO_RECYLE.LuaDic_ContainsKey(e)?64:8,i.objCls=t,null==i.objCls&&(i.objCls=T.j.Inst.F_GetMessageCls(e)),
this.messagePools.LuaDic_AddOrSetItem(e,i)),i}GetMessagePoolsToWeakObj(e,t){return this._GetMessagePool(e,t).GetObj()}_RecycleMessagePoolsOnGC(e){if(null==e)return
const t=e.getId()
e.clearData()
this._GetMessagePool(t).RecycleObj(e)}Setv_ReveiveMsgByte(e){null!=X._Inst&&(X._Inst.v_ReveiveMsgByte=e)}F_InitSocketInfo(){}InitSingleton(){}SingletonUpdate(e,t){this.DTime=t}
F_InitSocketCon(e,t,i,n,s){null==s&&(s=!0),null==n&&(n=!1),null==i&&(i=!1),I.s.Info(`F_InitSocketCon ${e}:${t}`)
const l=this.GetSocket(s)
l.F_Close(!1),l.F_Connect(e,t,i,n)}IsConnected(e){return(0,l.h0)().socket.getConnected()}IsCreateThread(e){null==e&&(e=!0)
return this.GetSocket(e).IsCreateThread()}static dumpProto(e,t,i){X.ClientDebugProto&&(i||X.ClientDebugProtoClog?(I.s.Info(`${e}${t.getId()}--${t.constructor.name}`),
console.log(t)):(C.Y.Log(`${e}${t.getId()}--${t.constructor.name}`,!0),console.log(t)))}ProtoToString(e){return""}F_SendMsg(e,t,i){const a=e.getId(),r=o.GF.MTimer_get()
r-K>1e3&&(z=0,K=r),z+=1,z>80&&(z=0,K=r,C.Y.LogError(`send proto too hight !${a}`)),y.b.writeBuffer.clear(),e.write(),(0,l.UK)(a,y.b.writeBuffer)
{const t=n.o.ins
if(t.isPrintProto){const i=e.getId();(-1111!=i&&-11616!=i||t.isPrintMoveProto)&&console.log(`%c >>> [${e.constructor.name} ${i}] ${JSON.stringify(e,s.RT)}`,"color:#da70d6;")}}}
DoSendMsg(e,t,i){if(null!=e){e.ResetWriteProtoStreamBuffer(),t.write(),t.writeProtoKey()
e.F_Send(i)}}ReceiveSocketMessage(e,t,i,n,s){j.Clear(),Y.Init(e,t,i,n,s)
let l=0,a=null
for(;Y.IsNullByIntList();){if(Y.SetCurPoolDataLength(),l=Y.GetCurIntVal(),a=T.j.Inst.F_GetMessage(l),null==a)return C.Y.LogError(`${(0,
_.T)("收到消息但是无法处理，id:")}${l} LastProId=${X.LastProId}`),S.i.Inst.RaiseEvent(p.N.SocketDecodeError),Y.ClearCurPoolDataLength(),void Y.Reset()
a.read(),Y.PoolIsEqual()||(C.Y.LogError(l+((0,_.T)(":此协议前后端不一致， LastProId = ")+X.LastProId)),S.i.Inst.RaiseEvent(p.N.SocketDecodeError),Y.ClearCurPoolDataLength()),j.Add(a),
X.LastProId=l}let r=0
for(;r<j.Count();){const e=j[r]
X.SendMsgHandle(e),r+=1}Y.Reset()}ReceiveByteMessage(e,t,i,n,s,l){const a=m.os.clock(),r=new h.Z
Y.Init(e,t,i,n,s)
let o=0,d=null
for(;Y.IsNullByIntList();){if(Y.SetCurPoolDataLength(),o=Y.GetCurIntVal(),d=T.j.Inst.F_GetMessage(o),null==d)return C.Y.LogError(`${(0,
_.T)("收到消息但是无法处理，id:")}${o} LastProId=${X.LastProId}`),S.i.Inst.RaiseEvent(p.N.SocketDecodeError),Y.ClearCurPoolDataLength(),void Y.Reset()
d.read(),Y.PoolIsEqual()||(C.Y.LogError(o+((0,_.T)(":此协议前后端不一致， LastProId = ")+X.LastProId)),S.i.Inst.RaiseEvent(p.N.SocketDecodeError),Y.ClearCurPoolDataLength()),r.Add(d),
X.LastProId=o}let u=0
for(;u<r.Count();){const e=r[u]
X.SendMsgHandle(e),u+=1}I.s.Info(`录像协议解析耗时：${m.os.clock()-a}秒`),Y.Reset(),h.Z.Recyle(r)}static SendMsgHandle(e){T.j.Inst.F_SendHandler(e.getId(),e)}InstF_CloseSocketCon(e){
null==e&&(e=!1),null!=X._Inst&&X._Inst.F_CloseSocketCon(e)}F_CloseSocketCon(e,t){null==t&&(t=!0),null==e&&(e=!1),C.Y.Log("F_CloseSocketCon ")
this.GetSocket(t).F_Close(e)}F_IsSocketConnect(e){return(0,l.h0)().socket.getConnected()}setReadMsg(e){this.lua_Socket.setReadMsg(e)}UnInitSingleton(){}GetSocket(e){
return e?this.lua_Socket:this.crossServerSocket}HandleMxpMsg(e){const t=d.M.Split(e,"|"),i=d.M.Split(t[0],d.M.s_EQUAL_CHAR)
if("id"==i[0]){const t=d.M.String2Int(i[1])
9!=t&&10!=t&&a.V.SendRecvData(e)}}}X.AUTO_RECYLE=new u.X,X._Inst=null,X.ClientDebugProto=!0,X.ClientDebugProtoClog=!1,X.LastProId=0,X.__StaticInit()},21318:(e,t,i)=>{i.d(t,{P:()=>A
})
var n=i(92679),s=i(48933),l=i(75439),a=i(7601),r=i(81629),o=i(65550),d=i(85942),h=i(68366),u=i(93984),c=i(77546),I=i(86133),_=i(38045),p=i(98800),S=i(59553),g=i(97461),m=i(98958),f=i(68662),C=i(38935),T=i(5924),y=i(66788)
class A{SetPreFocusTimeVal(){let e=h.N.Inst_get()
A.preFocusTime=e.time_get(),e=null}JudgeTimePaddingVal(){let e=h.N.Inst_get()
A.curFocusTime=e.time_get(),e=null
let t=!1
0!=A.preFocusTime&&A.curFocusTime-A.preFocusTime>=A.focusPaddingTime&&(t=!0),A.JudgeSocketState(t)}SetFocus(e){c.s.Info(`Lua SetFocus ${(0,_.tw)(e)}`),A.isFocus=e,
null!=p.Y.Inst&&p.Y.Inst.UpdateLastOperationTime(),g.i.Inst.RaiseEvent(n.g.ApplicationFocus,e)}static JudgeSocketState(e){if(c.s.Info((0,
I.T)("LuaOffLineReconnect JudgeSocketState")),e)f.D.IsEditor
else if(A.isGotoJudge&&(a.W.Inst.CM_HeartBeatHandler(),!C.C.Inst.IsConnected())){if(null==s.I.IP||null==s.I.Port)return void a.W.Inst.ReLogin()
;-1==A.reTimeTwo&&(a.W.Inst.SetConnectingStatus(1),C.C.Inst.F_InitSocketCon(s.I.IP,s.I.Port),A.reTimeTwo=T.C.Inst_get().SetInterval(A.ShowLoadView,200,1)),
A.reConnectMax=l.D.getInstance().GetIntValue("RECONNECT:COUNT"),S._.Inst.isShowConnectLose=!1,A.isGotoJudge=!1}}TimeStart(e){
A.reTimeTwo=T.C.Inst_get().SetInterval(A.OpenViewHandler,5e3),A.OpenViewHandler()}static ShowLoadView(){A.ClearHomeOffLineTime(),C.C.Inst.IsConnected()||A.TimeStart(null)}
static OpenViewHandler(){if(a.W.Inst.SetConnectingStatus(1),C.C.Inst.F_InitSocketCon(s.I.IP,s.I.Port),r.K.inst.PlayLoadEffect(),A.oneConnectCount+=1,
y.Y.Log(`LuaOfflineReconnect OpenViewHandler ${A.oneConnectCount}`),3==A.oneConnectCount)if(r.K.inst.StopLoadEffect(),A.ClearHomeOffLineTime(),A.reConnectCount+=1,
A.reConnectCount<A.reConnectMax){const e=new d.N
e.showText=m.V.Inst().getStr(10401,u.h.eLangResource),e.okText=m.V.Inst().getStr(10400,u.h.eLangResource),e.tipstype=1,e.btnColorType=2,e.okhandler=A.TimeStart,e.isShowCloseBtn=!1,
o.y.inst.OpenTopLayerMessageTips(e)}else{const e=m.V.Inst().getStr(10458,u.h.eLangResource)
S._.Inst.ReLoginTip(e)}}static ClearHomeOffLineTime(){A.oneConnectCount=0,T.C.Inst_get().ClearInterval(A.reTimeTwo),A.reTimeTwo=-1}ResetData(e){null==e&&(e=!1),
A.ClearHomeOffLineTime(),A.isGotoJudge=e,A.reConnectCount=0}}A.reTimeTwo=-1,A.oneConnectCount=0,A.isGotoJudge=!1,A.reConnectMax=0,A.reConnectCount=0,A.isFocus=!0,A.preFocusTime=0,
A.curFocusTime=0,A.focusPaddingTime=18e4},62370:(e,t,i)=>{i.d(t,{o:()=>r})
var n=i(18998),s=i(98885),l=i(85602),a=i(38045)
class r{static GetChar(e,t){return s.M.GetAt(e,t)}static NumToString(e=null,t=null,i=null){if(i&&t>0){const n=10^t,s=e*n
1==i?e=Math.floor(s):2==i&&(e=Math.ceil(s)),e/=n}const n=(0,a.tw)(e),r=s.M.Split(n,s.M.s_DOT_CHAR_DOT)
let o=null
if(1==r.count)o=r[0]
else{let e=r[1]
let t=-1
for(let i=s.M.Length(e)-1;i<=0;i+=-1){if("0"!=s.M.GetAt(e,i)){t=i
break}}-1==t?o=r[0]:(e=s.M.SubStringWithEnd(e,0,t+1),o=r[0]+(s.M.s_DOT_CHAR_DOT+e))}return l.Z.Recyle(r),o}static NumDigit(e,t){null==t&&(t=0),e*=10**t
let i=(0,a.tw)(e)
const n=i.indexOf(s.M.s_DOT_CHAR)
return 0!=n&&(i=s.M.SubStringWithEnd(i,0,n),i=s.M.ReplaceSlow(i,s.M.s_DOT_CHAR,r.s_BLANK_CHAR),e=s.M.String2Double(i)),e/=10**t}static GetStringArr(e,t){
(s.M.IndexOf(e,"[")>-1||s.M.IndexOf(e,"{")>-1)&&(e=(e=e.slice(1,1+s.M.Length(e)-1)).slice(0,s.M.Length(e)-1)),null==t&&(t=r.s_Arr_UNDER_CHAR_DOU)
const i=""==e?new l.Z:s.M.Split(e,t)
let n=0
for(;n<i.count;)i[n]=s.M.Replace(i[n],s.M.s_StringChar,""),n+=1
return i}static GetIntArr(e,t){if(""==e)return new l.Z
s.M.IndexOf(e,"[")>-1&&(e=s.M.SubStringWithLen(e,1,s.M.Length(e)-1),e=s.M.SubStringWithLen(e,0,s.M.Length(e)-1)),null==t&&(t=r.s_Arr_UNDER_CHAR_DOU)
const i=s.M.Split(e,t)
let n=0
for(;n<i.count;)i[n]=s.M.String2Double(s.M.Replace(i[n],s.M.s_StringChar,"")),n+=1
return i}CharToString(e){return e}static Format(e,t,i=null,n=null,l=null,a=null){let r=s.M.Replace(e,"{0}",t)
return null!=i&&(r=s.M.Replace(r,"{1}",i)),null!=n&&(r=s.M.Replace(r,"{2}",n)),null!=l&&(r=s.M.Replace(r,"{3}",l)),null!=a&&(r=s.M.Replace(r,"{4}",a)),r}
static GetUrlAtPositionVec3(e,t){return this.GetUrlAtCharacterIndex(this.GetCharacterIndexAtPositionVec3(t,e,!0),t)}static GetCharacterIndexAtPositionVec3(e,t,i){
let s=e.node,l=null,a=-1
n.sys.getSafeAreaRect()
let r=new n.Vec3(0,0,0)
r.x=t.x/n.view.getVisibleSizeInPixel().width*n.view.getVisibleSize().width,r.y=t.y/n.view.getVisibleSizeInPixel().height*n.view.getVisibleSize().height
for(let e=0;e<s.children.length;e++){l=s.children[e].getComponent(n.UITransform)
if(l.getBoundingBoxToWorld().contains(new n.Vec2(r.x,r.y))){a=e
break}}return a}static GetUrlAtCharacterIndex(e,t){let i,s=t.string,l=t.node.children[e]
if(!l)return
i=l.getComponent(n.Label).string
let a=s.indexOf(i),r=-1,o=0
for(;a>0;a--){if(">"==s[a]&&s[a-1]&&s[a-2]&&"/"==s[a-1]&&"<"==s[a-2])return""
if('"'==s[a]){if(0!=o){a+=1
break}r=a,o=1}}return s.substring(a,r)}}r.s_Arr_UNDER_CHAR_DOT="_",r.s_Arr_UNDER_CHAR_DOLL="$",r.s_Arr_UNDER_CHAR_DOU=",",r.s_Arr_UNDER_COLON=":",r.s_Arr_UNDER_LINE="|",
r.s_UNDER_CHAR="_",r.s_F_SLASH_ONE="/",r.s_ADD_STR="+",r.s_UNDER_LINE="|",r.s_NEXT_LINE="\\n",r.s_NEXT_ONELINE="\n",r.s_MID_CHAR="-",r.s_BLANK_CHAR="",r.s_STAR_CHAR="*",
r.s_UNDER_COLON=":",r.s_BIG_COLON="：",r.s_UNDER_PERCENT="%",r.s_UNDER_CHAR_DOLL="$",r.s_AND_CHAR="&",r.s_W_CHAR="W",r.s_E_CHAR="E",r.s_RIGHTARCHER_CHAR=">>>",r.s_SPAN_CHAR="，",
r.s_EXCLAMATORY_CHAR="!",r.s_SHARP_CHAR="#",r.s_LEFT_NAME_CHAR="「",r.s_RIGHT_NAME_CHAR="」",r.s_RIGHT_ARROW="→",r.s_RIGHT_DOT_CHAR="、",r.s_BIG_SPACE_CHAR="　",r.s_LEFT_S_K_CCHAR="（",
r.s_RIGHT_S_K_CCHAR="）",r.tempToString="&",r.undefined="!@#$%^(*^*"},95417:(e,t,i)=>{i.d(t,{U:()=>de})
var n=i(42292),s=i(87717),l=i(94148),a=i(54415),r=i(31922),o=i(57940),d=i(94826),h=i(48933),u=i(37648),c=i(55492),I=i(75439),_=i(5031),p=i(76218),S=i(21307),g=i(21334),m=i(73082),f=i(82474),C=i(13195),T=i(35128),y=i(98130),A=i(98885),P=i(38962),w=i(52880),R=i(16854),D=i(38836),L=i(80812),E=i(98800),B=i(65393),M=i(57121),G=i(78752),O=i(91238),U=i(19176),b=i(6700),F=i(2689),k=i(31222),v=i(5494)
class N{SetChangeInfo(e){}GetIsWedding(){return!1}}
var V,x,H=i(80160),Z=i(84229),Y=i(92984),W=i(26753),K=i(73865),z=i(28462),j=i(93061),X=i(88010),q=i(57651),J=i(47041),$=i(62783),Q=i(33065),ee=i(86133),te=i(36241),ie=i(13687),ne=i(5924),se=i(66788)
class le{constructor(){this._taskResult=null,this._activeResult=null,this._apktipsResult=null,this._killtipsResult=null,this._mapResult=null,this._chatResult=null,
this._icontipResult=null,this._operationResult=null,this._functionupResult=null,this._functiondownResult=null,this._headResult=null,this._skillResult=null,
this._preNoticeResult=null,this._crackerResult=null,this._newServerAdvantage=null,this._otherActiveResult=null,this._beingStrongResult=null,this._activityNotifyResult=null,
this._transformTaskResult=null,this._hangEfficientResult=null,this._hideBranchResult=null,this._banTeamResult=null,this._banBeatBackResult=null,this.m_frontMap=0,this.m_timerId=0,
this.m_intervalId=0,this._degf_DelayHideOrShow=null,this._rightUpBtnList=null,this._degf_DelayHideOrShow=(e,t)=>this.DelayHideOrShow(e,t)}static Inst_get(){
return null==le._inst&&(le._inst=new le),le._inst}banTeamResult_get(){return null==this._banTeamResult&&(this._banTeamResult=g.p.Inst_get().GetBanTeamResult()),this._banTeamResult}
banBeatBackResult_get(){return null==this._banBeatBackResult&&(this._banBeatBackResult=g.p.Inst_get().GetBanBeatBackResult()),this._banBeatBackResult}ExitMap(e){}EnterMap(e){
ne.C.Inst_get().ClearInterval(this.m_intervalId),this.m_intervalId=ne.C.Inst_get().SetFrameLoopForParm(this._degf_DelayHideOrShow,1,1,e)}DelayHideOrShow(e,t){const i=y.GF.INT(t)
null!=g.p.Inst_get().GetMapById(i)?(this.HideOrShow(this.GetUseMapId(i)),X.F.Inst_get().ClosePkUI(),this.m_frontMap=i):se.Y.LogError((0,
ee.T)("mapRes或者mapId为nil ")+debug.traceback())}GetUseMapId(e){const t=g.p.Inst_get().GetMapById(e)
return null==t||"ASURAM_SCENE"!=t.controllerType||Z.Q.Inst_get().IsInCopy()?e:ie.b.Inst.lastMapId>0?ie.b.Inst.lastMapId:10001}OnlyCheckTaskPanel(){
const e=this.GetUseMapId(this.m_frontMap),t=A.M.IntToString(e)
g.p.Inst_get().GetMapById(this.m_frontMap)
return!this.IndexOfStr(this.taskResult_get(),t)}ShowOrHideNewServerAdvantageTip(){}ShowOrHideNewServerAdvantage(e){}HideOrShow(e){
const t=A.M.IntToString(e),i=g.p.Inst_get().GetMapById(e)
i.hideElementsList.Contains(le.TIPFATHER)?J.N.Inst_get().HideOrShowTip(!1):J.N.Inst_get().HideOrShowTip(!0),this.IndexOfStr(this.taskResult_get(),t)?(q.i.ins.CloseMainUI(),
q.i.ins.CloseTaskTempView()):(q.i.ins.OpenMainUI(),q.i.ins.OpenTaskTempView()),this.IsShowRightUpBtnList(t)?K.y.Inst.ForceCloseFuncBtn():K.y.Inst.ForceOpenFuncBtn(),
this.IndexOfStr(this.mapResult_get(),t)?$.X.inst.ForceCloseForMapJudge():$.X.inst.ForceOpenForMapJudge(),
this.IndexOfStr(this.chatResult_get(),t)?W.d.Inst_get().controller.ForceCloseForMapJudge(!0):W.d.Inst_get().controller.ForceOpenForMapJudge(),
this.IndexOfStr(this.icontipResult_get(),t)?j.Z.Inst_get().ForceCloseIconTipsForMapJudge():j.Z.Inst_get().ForceOpenIconTipsForMapJudge(),
this.IndexOfStr(this.operationResult_get(),t)?_.T.inst_get().control.ForceCloseOperationPanel():Q.x.Inst_get().CheckAssistDamageOpen()||_.T.inst_get().control.ForceOpenOperationPanel(),
this.IndexOfStr(this.activeResult_get(),t)?_.T.inst_get().control.ForceOpenFuncSetView():(_.T.inst_get().control.ForceOpenFuncSetView(),K.y.Inst.ForceOpenFuncBtn()),
this.IndexOfStr(this.funcPrenoticeResult_get(),t)?z.J.inst.ForceCloseForMapJudge():z.J.inst.ForceOpenForMapJudge(),
this.IndexOfStr(this.headResult_get(),t)?_.T.inst_get().control.ForceCloseHeadForMapJudge():_.T.inst_get().control.ForceOpenHeadForMapJudge(),
this.IndexOfStr(this.skillResult_get(),t)?_.T.inst_get().control.ForceCloseSkillForMapJudge():_.T.inst_get().control.ForceOpenSkillForMapJudge(),
this.IndexOfStr(this.hangEfficientResult_get(),t)?te._.getInst().ForceCloseStartIcon():te._.getInst().ForceOpenStartIcon(),
"ARENA"==i.controllerType||("REDHOODREADY"==i.controllerType||"REDHOOD"==i.controllerType?(j.Z.Inst_get().ForceCloseIconTipsForMapJudge(),
_.T.inst_get().control.ForceCloseOperationPanel()):i.controllerType),_.T.inst_get().control.ForceOpenExpForMapJudge()
const n=g.p.Inst_get().GetBuffsById(A.M.String2Int(t))
null==n||0==n.Count()?Y.j.Inst_get().model.ForceResumeBuffColor():Y.j.Inst_get().model.ForceCancelBuffColor(n),H.x.inst.CheckTransferBtn(),
_.T.inst_get().control.JudgeShowExtraPackageBtn()}IsOtherShowPanel(e){return this.IndexOfStr(this.otherActiveResult_get(),e)}IsShowRightUpBtnList(e){
return null==this._rightUpBtnList&&(this._rightUpBtnList=g.p.Inst_get().GetMapIdsByUIType(le.FUC_RIGHT_UP_BTN_LIST)),this.IndexOfStr(this._rightUpBtnList,e)}headAllUI(){
q.i.ins.CloseMainUI(),q.i.ins.CloseTaskTempView(),K.y.Inst.ForceCloseFuncBtn(),$.X.inst.ForceCloseForMapJudge(),W.d.Inst_get().controller.ForceCloseForMapJudge(),
j.Z.Inst_get().ForceCloseIconTipsForMapJudge(),_.T.inst_get().control.ForceCloseOperationPanel(),_.T.inst_get().control.ForceCloseUpFuncForMapJudge(),
_.T.inst_get().control.ForceCloseDownFuncForMapJudge(),z.J.inst.ForceCloseForMapJudge(),_.T.inst_get().control.ForceCloseHeadForMapJudge(),
_.T.inst_get().control.ForceCloseSkillForMapJudge(),_.T.inst_get().control.ForceCloseExpForMapJudge(),_.T.inst_get().control.ForceCloseFuncSetView(),
_.T.inst_get().control.ForceClosePkFuncView(),FireCrackerEnterCtrl.Inst_get().HideView(),_.T.inst_get().control.ForceHideExtraPackageBtn()}IsOperationCouldShow(){
const e=`${ie.b.Inst.currentMapId_get()}`
return!this.IndexOfStr(this.operationResult_get(),e)}IsTaskPanelCouldShow(){const e=`${ie.b.Inst.currentMapId_get()}`
return!this.IndexOfStr(this.taskResult_get(),e)}IsFunOpenPanelShow(){const e=`${ie.b.Inst.currentMapId_get()}`
return!this.IndexOfStr(this.activeResult_get(),e)}IndexOfStr(e,t){for(const[i,n]of(0,D.V5)(e))if(n==t)return!0
return!1}hangEfficientResult_get(){return null==this._hangEfficientResult&&(this._hangEfficientResult=g.p.Inst_get().GetMapIdsByUIType(le.HANG_EFFICIENT)),this._hangEfficientResult
}taskResult_get(){return null==this._taskResult&&(this._taskResult=g.p.Inst_get().GetMapIdsByUIType(le.TASK_PANEL)),this._taskResult}activeResult_get(){
return null==this._activeResult&&(this._activeResult=g.p.Inst_get().GetMapIdsByUIType(le.ACTIVITY_ICON)),this._activeResult}pkTipsResult_get(){
return null==this._apktipsResult&&(this._apktipsResult=g.p.Inst_get().GetMapIdsByUIType(le.PKTIPS)),this._apktipsResult}killTipsResult_get(){
return null==this._killtipsResult&&(this._killtipsResult=g.p.Inst_get().GetMapIdsByUIType(le.KILLTIPS)),this._killtipsResult}otherActiveResult_get(){
return null==this._otherActiveResult&&(this._otherActiveResult=g.p.Inst_get().GetMapIdsByUIType(le.SHOW_ACTIVITY_ICON)),this._otherActiveResult}mapResult_get(){
return null==this._mapResult&&(this._mapResult=g.p.Inst_get().GetMapIdsByUIType(le.MAP)),this._mapResult}chatResult_get(){
return null==this._chatResult&&(this._chatResult=g.p.Inst_get().GetMapIdsByUIType(le.CHAT)),this._chatResult}icontipResult_get(){
return null==this._icontipResult&&(this._icontipResult=g.p.Inst_get().GetMapIdsByUIType(le.ICON_TIP)),this._icontipResult}operationResult_get(){
return null==this._operationResult&&(this._operationResult=g.p.Inst_get().GetMapIdsByUIType(le.OPERATION_ACTIVITY)),this._operationResult}headResult_get(){
return null==this._headResult&&(this._headResult=g.p.Inst_get().GetMapIdsByUIType(le.HEAD)),this._headResult}skillResult_get(){
return null==this._skillResult&&(this._skillResult=g.p.Inst_get().GetMapIdsByUIType(le.SKILL)),this._skillResult}funcPrenoticeResult_get(){
return null==this._preNoticeResult&&(this._preNoticeResult=g.p.Inst_get().GetMapIdsByUIType(le.FUNC_PRENOTICE)),this._preNoticeResult}}le._inst=null,le.TASK_PANEL=5,le.CHAT=6,
le.HEAD=7,le.SKILL=8,le.MAP=9,le.OPERATION_View=10,le.FuncSet_View=11,le.FUNC_PRENOTICE=12,le.ICON_TIP=13,le.HANG_EFFICIENT=14,le.SHOW_ACTIVITY_ICON=17,le.TIPFATHER=21,
le.PKTIPS=22,le.KILLTIPS=23,le.FUC_RIGHT_UP_BTN_LIST=25,le.TRANS_JOB_ICON=26,le.REBIRTH_ICON=27,le.TASK_MAINUI_PANEL=28,le.MAP_PASS_BTN=29,le.Setting_ICON=30,le.ACTIVITY_ICON=null,
le.OPERATION_ACTIVITY=null
class ae extends le{static Inst_get(){return null==ae._inst&&(ae._inst=new ae),ae._inst}HideOrShow(e){super.HideOrShow(e)}}ae._inst=null
class re extends le{static Inst_get(){return null==re._inst&&(re._inst=new re),re._inst}HideOrShow(e){super.HideOrShow(e)}}re._inst=null
let oe=null,de=(x=class e extends C.W{static get Inst(){return null==e._inst&&(e._inst=new e),e._inst}constructor(){super(!0,R.J.eSceneMgr,R.J.eSceneMgr),this.lastUpdateTime=0,
this.lastMapId=0,this.lastX=0,this.lastY=0,this.enabled=!0,this.model=null,this.squareDisDic=null,this.DropPickRang=null,this.DropPickCD=5,this.LastDropPick=0,
this.LastCheckSubmitFireItemBtn=0,this.isInitSquareDisDic=!1,this.currTouchType=-1,this.currTouchObj=null,this.disVal=9,this.mSceneTouchView=null,
this._degf_SM_SceneChangeHandler=null,this._degf_DelayShowPlayer=null,this.model=new N,this.squareDisDic=new P.X,this.DropPickRang=9,this._degf_SM_SceneChangeHandler=e=>{},
oe=new P.X,oe.LuaDic_AddOrSetItem(F.N.MULTIPLE_HANG,re),oe.LuaDic_AddOrSetItem(F.N.SCENE,re),oe.LuaDic_AddOrSetItem(F.N.DEMONPLAZA,re),oe.LuaDic_AddOrSetItem(F.N.BLOODTOWN,ae),
oe.LuaDic_AddOrSetItem(F.N.ASURAM_SCENE,re),oe.LuaDic_AddOrSetItem(F.N.ARENA,re),oe.LuaDic_AddOrSetItem(F.N.MAPCOPY,ae),oe.LuaDic_AddOrSetItem(F.N.WORLD_BOSS_NEWHAND,ae),
oe.LuaDic_AddOrSetItem(F.N.WORLD_BOSS,ae),oe.LuaDic_AddOrSetItem(F.N.BATTLEFIELD,re),oe.LuaDic_AddOrSetItem(F.N.GOLD_SPAWN_SINGLE,ae)}InitSingleton(){this.addLis()}EnterMap(e){
const t=g.p.Inst_get().GetMapById(e)
null!=t&&null!=oe[t.controllerType]?oe[t.controllerType].Inst_get().EnterMap(e):le.Inst_get().EnterMap(e)}InitSquareDisDic(){if(this.isInitSquareDisDic)return
const e=I.D.getInstance().getContent("INTERACTION:RADIUS"),t=A.M.Split(e.getContent().stringVal,A.M.s_SPAN_CHAR)
let i=A.M.String2Float(t[0])
this.squareDisDic.LuaDic_AddOrSetItem(r.z.SceneTouchBtnType_NPC,i*i),i=A.M.String2Float(t[1]),this.squareDisDic.LuaDic_AddOrSetItem(r.z.SceneTouchBtnType_Collect,i*i),
i=A.M.String2Float(t[2]),this.squareDisDic.LuaDic_AddOrSetItem(r.z.SceneTouchBtnType_Drop,i*i),i=A.M.String2Float(t[3]),
this.squareDisDic.LuaDic_AddOrSetItem(r.z.SceneTouchBtnType_Wall,i*i),i=A.M.String2Float(t[4]),this.DropPickRang=i*i,i=A.M.String2Float(t[5]),this.DropPickCD=i,
this.isInitSquareDisDic=!0}UnInitSingleton(){}SingletonUpdate(e,t){if(!this.enabled)return void(null!=this.currTouchObj&&this.ResetStateAndCloseSceneTouchView())
const i=y.GF.Timer_get()
if(i-this.lastUpdateTime<.2)return
this.lastUpdateTime=i
const n=E.Y.Inst.PrimaryRole_get()
if(null==n)return
const l=E.Y.Inst.PrimaryRoleInfo_get()
if(null==l)return
const a=l.MapId_get(),r=h.I.calVec0
n.GetCurPos(r),this.lastMapId=a,this.lastX=r.x,this.lastY=r.y,w.o.Inst_get().CheckScene(r,a),E.Y.Inst.CheckSceneNpc(r,a),E.Y.Inst.CheckSoundTrigger(r,a),
L.O.Inst_get().CheckScene(r,a),B.e.Inst_get().Update(),s.L.Inst_get().CheckRunes(),this.CheckTouchButton(),this._CheckPandoraTouchBotton(),this._CheckSubmitFireItemTouchBotton()}
InitPoisonArea(){}CheckTouchButton(){this.InitSquareDisDic()
let e=null,t=null,i=null
const n=h.I.calVec0,s=h.I.calVec1
if(E.Y.Inst.PrimaryRole_get().GetCurPos(n),-1!=this.currTouchType){let l=this.squareDisDic[this.currTouchType]
if(this.currTouchType==r.z.SceneTouchBtnType_NPC?(e=this.currTouchObj,e.GetCurPos(s),
null!=e.Cfg_get()&&(l=e.Cfg_get().interactionDistance)):this.currTouchType==r.z.SceneTouchBtnType_Drop?(t=this.currTouchObj,
t.GetCurPos(s)):this.currTouchType==r.z.SceneTouchBtnType_Wall&&(i=this.currTouchObj,s.x=i.playerPosX,s.y=n.y,s.z=i.playerPosY),
!(T.p.FastDistance(n.x,n.z,s.x,s.z)>l))return void(E.Y.Inst.PrimaryRoleInfo_get().SceneTouchState==r.z.SceneTouchHide&&this._CheckTouchBotton())
this.ResetStateAndCloseSceneTouchView()}
E.Y.Inst.PrimaryRole_get().FindPathType_get()!=O.m.Point||U.S.getInst().InHang_get()&&!l.b.Inst_get().InAsuramMap()||a.k.Inst_get().IsShowCollect()||this._CheckTouchBotton()}
CheckCurrTouchDestory(e){this.currTouchObj==e&&this.ResetStateAndCloseSceneTouchView()}ResetStateAndCloseSceneTouchView(){
E.Y.Inst.PrimaryRoleInfo_get().SceneTouchState=r.z.SceneTouchStateNormal,this.currTouchType=-1,this.currTouchObj=null,this.CloseSceneTouchView()}_CheckTouchBotton(){
const e=E.Y.Inst.PrimaryRoleInfo_get().SceneTouchState
if(e==r.z.SceneTouchStateShow)return
const t=h.I.calVec0,[i,n,s]=E.Y.Inst.PrimaryRole_get().GetPosXYZ()
let[l,a,o]=[0,0,0]
if(e==r.z.SceneTouchStateNormal||e==r.z.SceneTouchHide&&this.currTouchType!=r.z.SceneTouchBtnType_NPC){const e=E.Y.NpcDic
for(const[t,n]of(0,D.V5)(e))if([l,a,o]=n.GetPosXYZ(),T.p.FastDistance(i,s,l,o)<n.Cfg_get().interactionDistance)return this.currTouchType=r.z.SceneTouchBtnType_NPC,
this.currTouchObj=n,void this.OpenSceneTouchView()}
if(y.GF.Timer_get()-this.LastDropPick>this.DropPickCD&&(e==r.z.SceneTouchStateNormal||e==r.z.SceneTouchHide&&this.currTouchType!=r.z.SceneTouchBtnType_Drop)){
const e=M.M.Inst.needPickDic
for(const[i,n]of(0,D.V5)(e)){[l,a,o]=n.GetPosXYZ()
const e=this.squareDisDic[r.z.SceneTouchBtnType_Drop]
if(T.p.FastDistance(t.x,t.z,l,o)<=e)return this.currTouchType=r.z.SceneTouchBtnType_Drop,this.currTouchObj=n,void this.OpenSceneTouchView()}}
if(e==r.z.SceneTouchStateNormal||e==r.z.SceneTouchHide&&this.currTouchType!=r.z.SceneTouchBtnType_Wall){let e=null
if(e=m.N.Inst().wallListGroup.LuaDic_GetItem(E.Y.Inst.PrimaryRoleInfo_get().MapId_get()),null!=e){let i=0
for(;i<e.Count();){const n=e[i]
if(f.$.inst.pickDic.LuaDic_ContainsKey(n.id)&&null==f.$.inst.pickDic[n.id]&&!E.Y.Inst.PrimaryRole_get().IsSitOrWall()){
if(T.p.FastDistance(t.x,t.z,n.playerPosX,n.playerPosY)<=this.squareDisDic[r.z.SceneTouchBtnType_Wall])return this.currTouchType=r.z.SceneTouchBtnType_Wall,this.currTouchObj=n,
void this.OpenSceneTouchView()}i+=1}}}}_CheckPandoraTouchBotton(){const e=h.I.calVec0,t=h.I.calVec1
if(E.Y.Inst.PrimaryRole_get().GetCurPos(e),y.GF.Timer_get()-this.LastDropPick>this.DropPickCD){const i=M.M.Inst.pandoraPickDic
for(const[n,s]of(0,D.V5)(i)){s.GetCurPos(t)
let i=this.squareDisDic[r.z.SceneTouchBtnType_Drop]
if(S.B.Inst_get().IsShowPhotographView_get()&&(i*=i),T.p.FastDistance(e.x,e.z,t.x,t.z)<=i)return void p.U.inst.showPandoraBoxDropBtn(!0)}p.U.inst.showPandoraBoxDropBtn(!1)}}
_CheckSubmitFireItemTouchBotton(){const e=k.N.inst.GetViewById(v.I.RyAllianceCopyBornFireView)
if(!e)return
if(!E.Y.Inst.PrimaryRole_get())return
if(!u.P.Inst_get().IsFunctionOpened(c.x.ASURAM_BORNFIRE))return
const t=h.I.calVec0
if(E.Y.Inst.PrimaryRole_get().GetCurPos(t),y.GF.Timer_get()-this.LastCheckSubmitFireItemBtn>.3){this.LastCheckSubmitFireItemBtn=y.GF.Timer_get()
const i=B.e.Inst_get().ObjectDic
for(const[n,s]of(0,D.V5)(i)){const i=s.GetInfo()
if(i.Type_get()==G.M.BoneFire){const n=i.InteractionDis_get()
if(T.p.FastDistance(t.x,t.z,i.x,i.y)<=n*n)return void e.ShowHideSubmitFireBtn(!0)}}e.ShowHideSubmitFireBtn(!1)}}OpenSceneTouchView(){
null==this.mSceneTouchView&&null!=_.T.inst_get().control.ui_scene_touch_view&&(this.mSceneTouchView=_.T.inst_get().control.ui_scene_touch_view),
null!=this.mSceneTouchView?(this.mSceneTouchView.OnAddToScene(),
d.C.Inst_get().SetActiveById(o.k.sceneTouchView,!0)):(E.Y.Inst.PrimaryRoleInfo_get().SceneTouchState=r.z.SceneTouchStateNormal,this.currTouchType=-1,this.currTouchObj=null)}
CloseSceneTouchView(){null!=this.mSceneTouchView&&(d.C.Inst_get().SetActiveById(o.k.sceneTouchView,!1),this.mSceneTouchView.Clear())}SwitchTouchViewToPk(){
null!=this.mSceneTouchView&&this.mSceneTouchView.SwitchToPk()}ClearData(){b.L.ClearAllElementCombine(!0)}SwitchTouchViewToNormal(){
null!=this.mSceneTouchView&&this.mSceneTouchView.SwitchToNormal()}SetSceneViewEnable(e){this.enabled=e}ChangeTouchDistance(e,t){null!=this.squareDisDic&&(this.InitSquareDisDic(),
this.squareDisDic.LuaDic_ContainsKey(e)&&(this.squareDisDic[e]=t))}addLis(){}},x._inst=null,he=V=x,ue="Inst",ce=[n.Vx],Ie=Object.getOwnPropertyDescriptor(V,"Inst"),_e=V,pe={},
Object.keys(Ie).forEach((function(e){pe[e]=Ie[e]})),pe.enumerable=!!pe.enumerable,pe.configurable=!!pe.configurable,("value"in pe||pe.initializer)&&(pe.writable=!0),
pe=ce.slice().reverse().reduce((function(e,t){return t(he,ue,e)||e}),pe),_e&&void 0!==pe.initializer&&(pe.value=pe.initializer?pe.initializer.call(_e):void 0,
pe.initializer=void 0),void 0===pe.initializer&&(Object.defineProperty(he,ue,pe),pe=null),V)
var he,ue,ce,Ie,_e,pe},58207:(e,t,i)=>{
var n,s=i(18998),l=i(83908),a=i(87717),r=i(85430),o=i(80160),d=i(43076),h=i(54415),u=i(31922),c=i(57940),I=i(94826),_=i(48933),p=i(88010),S=i(79878),g=i(75517),m=i(82474),f=i(35128),C=i(98130),T=i(85602),y=i(79534),A=i(38836),P=i(86133),w=i(98800),R=i(57121),D=i(36241),L=i(57834),E=i(60130),B=i(95417)
const{ccclass:M}=s._decorator
M("SceneTouchView")(n=class extends((0,l.zB)()){constructor(...e){super(...e),this._degf_OnTouchHnadler=null}_initBinder(){super._initBinder(),
this._degf_OnTouchHnadler=(e,t)=>this.OnTouchHnadler(e,t)}InitView(){this.SetAnchorPos(),h.k.Inst_get().m_collectBtn=this.collectBtnView,this.collectBtnView.OnAddToScene(),
o.x.inst.transferBtn=this.chuangongBtn,this.chuangongBtn.OnAddToScene(),I.C.Inst_get().RegisterObj(c.k.sceneTouchView,this.offset,!0),
I.C.Inst_get().SetActiveById(c.k.sceneTouchView,!1)}OnAddToScene(){if(this.AddEventListeners(),w.Y.Inst.PrimaryRoleInfo_get().SceneTouchState=u.z.SceneTouchStateShow,
B.U.Inst.currTouchType==u.z.SceneTouchBtnType_NPC)r.a.isInAllianceBossMap_get()&&d.w.Inst_get().checkInActivity()?(this.des.textSet((0,P.T)("吃块烤肉")),
this.icon.spriteNameSet("mainui_icon_0041"),this.icon.node.SetLocalPositionXYZ(8.2,5.5,0)):(this.des.textSet((0,P.T)("交谈")),this.icon.spriteNameSet("mainui_icon_0007"),
this.icon.node.SetLocalPositionXYZ(-4.5,5.5,0))
else if(B.U.Inst.currTouchType==u.z.SceneTouchBtnType_Drop)this.des.textSet((0,P.T)("拾取")),this.icon.spriteNameSet("mainui_icon_0001"),this.icon.node.SetLocalPositionXYZ(8,5,0)
else if(B.U.Inst.currTouchType==u.z.SceneTouchBtnType_Wall){let e=B.U.Inst.currTouchObj
53==e.animationID?(this.des.textSet((0,P.T)("坐下")),this.icon.spriteNameSet("mainui_icon_0013"),
this.icon.node.SetLocalPositionXYZ(-7.5,5.5,0)):50==e.animationID&&(this.des.textSet((0,P.T)("倚靠")),this.icon.spriteNameSet("mainui_icon_0014"),
this.icon.node.SetLocalPositionXYZ(-8,10.6,0))}this.ani.ResetToBeginning(),this.ani.Play(),p.F.Inst_get().isInPkUI?this.SwitchToPk():this.SwitchToNormal()}SetAnchorPos(){
E.O.SetAnchorPos(this.anchor,!1,!1,0,!1)}SwitchToPk(){let e=new y.P(0,24,0)
this.posObj.transform.SetLocalPosition(e),y.P.Recyle(e)}SwitchToNormal(){let e=new y.P(0,0,0)
this.posObj.transform.SetLocalPosition(e),y.P.Recyle(e)}Clear(){this.RemoveEventListeners()}Destroy(){this.RemoveEventListeners(),this.collectBtnView.Destroy()}AddEventListeners(){
L.i.Get(this.touch.node).RegistonClick(this._degf_OnTouchHnadler)}RemoveEventListeners(){L.i.Get(this.touch.node).RemoveonClick(this._degf_OnTouchHnadler)}OnTouchHnadler(e,t){
if(g.W.inst_get().CloseView(),S.Y.isInTaskFindWay=!1,D._.getInst().openOrCloseStartIcon(),
B.U.Inst.currTouchType==u.z.SceneTouchBtnType_NPC)w.Y.Inst.SelectAndOpenNpcDialog(B.U.Inst.currTouchObj)
else if(B.U.Inst.currTouchType==u.z.SceneTouchBtnType_Wall){let e=B.U.Inst.currTouchObj
if(!a.L.Inst_get().HandleWallObjectId(e.id)){let t=e.id%100
m.$.inst.CM_WallSitDownHandler(t)}}else if(B.U.Inst.currTouchType==u.z.SceneTouchBtnType_Drop){let e=B.U.Inst.currTouchObj
if(w.Y.Inst.CurTarget_set(e),R.M.Inst.selectedDrop_set(e),0==e.dropInfo_get()._dInfo.collect){let e=this.GetRangeDrops()
R.M.Inst.RequestCM_PickUpMany(e),B.U.Inst.LastDropPick=C.GF.Timer_get()}else h.k.Inst_get().CM_GatherStartReq(e.dropInfo_get().Id_get(),e.Cfg_get().id)}
w.Y.Inst.PrimaryRoleInfo_get().SceneTouchState=u.z.SceneTouchHide,B.U.Inst.CloseSceneTouchView()}GetRangeDrops(){let e=new T.Z,t=_.I.calVec0,i=_.I.calVec1
w.Y.Inst.PrimaryRole_get().GetCurPos(t)
let n=R.M.Inst.DropDic
for(const[s,l]of(0,A.V5)(n))l.GetCurPos(i),f.p.FastDistance(t.x,t.z,i.x,i.z)<=B.U.Inst.DropPickRang&&e.Add(l.dropInfo_get())
return e}})},82737:(e,t,i)=>{i.d(t,{g:()=>n})
class n{}n.DT_NONE=0,n.DT_PRIMARY_ROLE=1,n.DT_PRIMARY_ROLE_SUMMON=2,n.DT_BOSS_ELITE_MONSTER=3,n.DT_NPC_COLLECT_TRANSPORT=4,n.DT_OTHER_ROLE=5,n.DT_NORMAL_MONSTER=6,n.DT_OTHER=7},
14236:(e,t,i)=>{i.d(t,{v:()=>M})
var n,s,l,a=i(75439),r=i(14990),o=i(78806),d=i(20353),h=i(84312),u=i(69324),c=i(78300),I=i(35128),_=i(98885),p=i(85602),S=i(72785),g=i(38962),m=i(52212),f=i(38836),C=i(86133),T=i(38045),y=i(23833),A=i(98800),P=i(57121),w=i(48748),R=i(63611),D=i(92415),L=i(62370),E=i(42292)
function B(e,t,i,n,s){var l={}
return Object.keys(n).forEach((function(e){l[e]=n[e]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,n){return n(e,t,i)||i}),l),s&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(s):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(e,t,l),l=null),l}let M=(n=(0,i(71409).GH)(D.k.SM_VisibleObjects),l=class e{static Inst_get(){return e.Inst||(e.Inst=new e),e.Inst}
constructor(){this.shiledDataDict=null,this._degf_SM_VisibleObjectsHandler=null,this._degf_SortDisplayList=null,this.shiledDataDict=new g.X,
this._degf_SM_VisibleObjectsHandler=e=>this.SM_VisibleObjectsHandler(e),this._degf_SortDisplayList=(e,t)=>this.SortDisplayList(e,t)}GetShiledData(e){let t=null
return t=this.shiledDataDict[e],null!=t?t:null}AddShiledData(e,t,i){let n=this.GetShiledData(e)
null==n&&(n=new ShiledData,n.handleId=e,n.shiledType=t,n.isShow=i,this.shiledDataDict.LuaDic_AddOrSetItem(e,n))}RemoveShiledData(e){
null!=this.GetShiledData(e)&&this.shiledDataDict.LuaDic_Remove(e)}SetDisplayShow(e,t){const i=this.GetShiledData(e.handle)
if(null==i||i.shiledType==ShiledConst.DT_NONE||i.isShow==t)return
let n=!1
t?(LuaEngineBridgeManager.ForceShowDisplay(i.handleId),n=LuaEngineBridgeManager.IsDisplayReallyShow(i.handleId),n?i.isShow=!0:S.c.DebugError((0,
C.T)("形象id：")+(i.handleId.toString()+((0,C.T)(",屏蔽类型：")+(_.M.IntToString(i.shiledType)+(0,C.T)("设置显示失败")))))):(e.SetShow(!1),
n=LuaEngineBridgeManager.IsDisplayReallyShow(i.handleId),n?S.c.DebugError((0,C.T)("形象id：")+(i.handleId.toString()+((0,C.T)(",屏蔽类型：")+(_.M.IntToString(i.shiledType)+(0,
C.T)("设置隐藏失败"))))):i.isShow=!1)}GetTypeTotal(e,t){let i=0
for(const[n,s]of(0,f.V5)(this.shiledDataDict))(e&&s.shiledType!=ShiledConst.DT_NONE&&s.isShow==t||!e&&s.isShow==t)&&(i+=1)
return i}GetTypeNum(e,t){let i=0
for(const[n,s]of(0,f.V5)(this.shiledDataDict))s.shiledType==e&&s.isShow==t&&(i+=1)
return i}GetOtherRoleNum(e,t){let i=0
for(const[n,s]of(0,f.V5)(this.shiledDataDict))if(s.shiledType==ShiledConst.DT_OTHER_ROLE&&s.isShow==t){A.Y.Inst.IsHostileRole(s.handleId,s.shiledType)==e&&(i+=1)}return i}
GetTypeLimit(e){let t=-1
return e==ShiledConst.DT_PRIMARY_ROLE||e==ShiledConst.DT_PRIMARY_ROLE_SUMMON?t=3:e==ShiledConst.DT_BOSS_ELITE_MONSTER||e==ShiledConst.DT_NPC_COLLECT_TRANSPORT?t=10:e==ShiledConst.DT_OTHER_ROLE?t=24:e==ShiledConst.DT_NORMAL_MONSTER&&(t=30),
t}IsTypeImportant(e){let t=!1
return e!=ShiledConst.DT_PRIMARY_ROLE&&e!=ShiledConst.DT_PRIMARY_ROLE_SUMMON&&e!=ShiledConst.DT_BOSS_ELITE_MONSTER&&e!=ShiledConst.DT_NPC_COLLECT_TRANSPORT||(t=!0),t}
CanShowDisplay(e){if(!this.IsTypeImportant(e)){const t=this.GetTypeLimit(e)
if(-1!=t){if(this.GetTypeNum(e,!0)>=t)return!1}const i=LuaEngineBridgeManager.MaxShowComplexObjectNums()
if(this.GetTypeTotal(!0,!0)>=i)return!1}return!0}SM_VisibleObjectsHandler(e){const t=new p.Z
for(const[i,n]of(0,f.V5)(e.playerList))t.Add(n)
for(const[i,n]of(0,f.V5)(e.monsterList))t.Add(n)
for(const[i,n]of(0,f.V5)(e.summonList))t.Add(n)
for(const[i,n]of(0,f.V5)(e.dropList))t.Add(n)
for(const[i,n]of(0,f.V5)(e.spiritList))t.Add(n)
t.Sort(this._degf_SortDisplayList)
let i=0
for(;i<t.Count();){const e=t[i];(0,T.t2)(e,h.R)?w.d.Inst.SM_PlayerInfoHandler(e):(0,T.t2)(e,o.E)?A.Y.Inst.SM_MonsterInfoHandler(e):(0,
T.t2)(e,d.f)?A.Y.Inst.SM_SummonMonsterInfoHandler(e):(0,T.t2)(e,r.Z)?P.M.Inst.SM_SimpleDropObjectInfoHandler(e):(0,T.t2)(e,u.E)&&SkillCastControl.GetInst().SM_SpiritInfoHandler(e),
i+=1}for(const[t,i]of(0,f.V5)(e.moveList))A.Y.Inst.SM_MoveHandler(i)}SortDisplayList(e,t){let i=this.SortByRole(e,t,!1)
if(0!=i)return i
if(i=this.SortBySummon(e,t,!1),0!=i)return i
if(i=this.SortByMonster(e,t,R.b.MONSTER_BOSS),0!=i)return i
const n=R.b.MONSTER_ELITE+(L.o.s_UNDER_CHAR_DOLL+R.b.ACTIVITY_ELITE)
return i=this.SortByMonster(e,t,n),0!=i?i:(i=this.SortByRole(e,t,!0),0!=i?i:(i=this.SortByMonster(e,t,R.b.MONSTER_NORMAL),0!=i||(i=this.SortByDistance(e,t)),i))}SortByRole(e,t,i){
const n=this.IsRole(e,i),s=this.IsRole(t,i)
return n&&!s?-1:s&&!n?1:0}SortBySummon(e,t,i){const n=this.IsSummon(e,i),s=this.IsSummon(t,i)
return n&&!s?-1:s&&!n?1:0}SortByMonster(e,t,i){const n=this.IsMonster(e,i),s=this.IsMonster(t,i)
return n&&!s?-1:s&&!n?1:0}SortByDistance(e,t){const i=this.IsInDistance(e),n=this.IsInDistance(t)
return i&&!n?-1:n&&!i?1:0}IsRole(e,t){let i=null
if((0,T.t2)(e,h.R)){i=e.objId}if(null!=i){const e=A.Y.Inst.PrimaryRoleInfo_get().Id_get().Equal(i)
if(t&&!e||!t&&e)return!0}return!1}IsSummon(e,t){if((0,T.t2)(e,d.f)){const i=e,n=A.Y.Inst.PrimaryRoleInfo_get().Id_get().Equal(i.ownerId)
if(t&&!n||!t&&n)return!0}return!1}IsMonster(e,t){if((0,T.t2)(e,o.E)){const i=e,n=y.a.getInst().getObjById(i.templateId)
if(null!=n){const e=_.M.Split(t,L.o.s_UNDER_CHAR_DOLL)
if(null!=e&&0!=e.count)for(const[t,i]of(0,f.V5)(e))if(n.objectType==i)return!0}}return!1}IsInDistance(e){let t=c.V.TEMP_VECTOR2D_get()
if((0,T.t2)(e,h.R)){const i=e
t=new m.F(i.x,i.y).Clone()}else if((0,T.t2)(e,o.E)){const i=e
t=new m.F(i.x,i.y).Clone()}else if((0,T.t2)(e,d.f)){const i=e
t=new m.F(i.x,i.y).Clone()}else if((0,T.t2)(e,r.Z)){const i=e
t=new m.F(i.x,i.y).Clone()}else if((0,T.t2)(e,u.E)){const i=e
t=new m.F(i.x,i.y).Clone()}
const i=I.p.FastDistance(A.Y.Inst.PrimaryRoleInfo_get().X_get(),A.Y.Inst.PrimaryRoleInfo_get().Y_get(),t.x,t.y),n=a.D.getInstance().GetIntValue("AUTO_SHILED:DISTANCE")
return i<=n*n}ShowShiledInfo(){const e=LuaEngineBridgeManager.MaxShowComplexObjectNums()
S.c.DebugLog((0,C.T)("形象总上限：")+_.M.IntToString(e))
let t=this.GetTypeNum(ShiledConst.DT_PRIMARY_ROLE,!0),i=this.GetTypeNum(ShiledConst.DT_PRIMARY_ROLE,!1),n=this.GetTypeLimit(ShiledConst.DT_PRIMARY_ROLE)
S.c.DebugLog((0,C.T)("主玩家类型当前显示数为：")+(_.M.IntToString(t)+((0,C.T)("，隐藏数为：")+(_.M.IntToString(i)+((0,C.T)("，显示上限为：")+_.M.IntToString(n)))))),
t=this.GetTypeNum(ShiledConst.DT_PRIMARY_ROLE_SUMMON,!0),i=this.GetTypeNum(ShiledConst.DT_PRIMARY_ROLE_SUMMON,!1),n=this.GetTypeLimit(ShiledConst.DT_PRIMARY_ROLE_SUMMON),
S.c.DebugLog((0,C.T)("主玩家召唤物类型当前显示数为：")+(_.M.IntToString(t)+((0,C.T)("，隐藏数为：")+(_.M.IntToString(i)+((0,C.T)("，显示上限为：")+_.M.IntToString(n)))))),
t=this.GetTypeNum(ShiledConst.DT_BOSS_ELITE_MONSTER,!0),i=this.GetTypeNum(ShiledConst.DT_BOSS_ELITE_MONSTER,!1),n=this.GetTypeLimit(ShiledConst.DT_BOSS_ELITE_MONSTER),
S.c.DebugLog((0,C.T)("BOSS和精英怪类型当前显示数为：")+(_.M.IntToString(t)+((0,C.T)("，隐藏数为：")+(_.M.IntToString(i)+((0,C.T)("，显示上限为：")+_.M.IntToString(n)))))),
t=this.GetTypeNum(ShiledConst.DT_NPC_COLLECT_TRANSPORT,!0),i=this.GetTypeNum(ShiledConst.DT_NPC_COLLECT_TRANSPORT,!1),n=this.GetTypeLimit(ShiledConst.DT_NPC_COLLECT_TRANSPORT),
S.c.DebugLog((0,C.T)("对话NPC、采集物、传送阵类型当前显示数为：")+(_.M.IntToString(t)+((0,C.T)("，隐藏数为：")+(_.M.IntToString(i)+((0,C.T)("，显示上限为：")+_.M.IntToString(n)))))),
t=this.GetTypeNum(ShiledConst.DT_OTHER_ROLE,!0),i=this.GetTypeNum(ShiledConst.DT_OTHER_ROLE,!1),n=this.GetTypeLimit(ShiledConst.DT_OTHER_ROLE)
const s=this.GetOtherRoleNum(!0,!0),l=this.GetOtherRoleNum(!0,!1),a=this.GetOtherRoleNum(!1,!0),r=this.GetOtherRoleNum(!1,!1)
S.c.DebugLog((0,C.T)("其他玩家类型当前显示数为：")+(_.M.IntToString(t)+((0,C.T)("，隐藏数为：")+(_.M.IntToString(i)+((0,C.T)("，显示上限为：")+(_.M.IntToString(n)+((0,
C.T)("，其中敌对玩家显示数为：")+(_.M.IntToString(s)+((0,C.T)("，敌对玩家隐藏数为：")+(_.M.IntToString(l)+((0,C.T)("，非敌对玩家显示数为")+(_.M.IntToString(a)+((0,
C.T)("，非敌对玩家隐藏数为")+_.M.IntToString(r)))))))))))))),t=this.GetTypeNum(ShiledConst.DT_NORMAL_MONSTER,!0),i=this.GetTypeNum(ShiledConst.DT_NORMAL_MONSTER,!1),
n=this.GetTypeLimit(ShiledConst.DT_NORMAL_MONSTER),S.c.DebugLog((0,C.T)("普通怪类型当前显示数为：")+(_.M.IntToString(t)+((0,C.T)("，隐藏数为：")+(_.M.IntToString(i)+((0,
C.T)("，显示上限为：")+_.M.IntToString(n)))))),t=this.GetTypeNum(ShiledConst.DT_OTHER,!0),i=this.GetTypeNum(ShiledConst.DT_OTHER,!1),n=this.GetTypeLimit(ShiledConst.DT_OTHER),
S.c.DebugLog((0,C.T)("其他类型当前显示数为：")+(_.M.IntToString(t)+((0,C.T)("，隐藏数为：")+(_.M.IntToString(i)+((0,C.T)("，显示上限为：")+_.M.IntToString(n)))))),
t=this.GetTypeNum(ShiledConst.DT_NONE,!0),i=this.GetTypeNum(ShiledConst.DT_NONE,!1),S.c.DebugLog((0,C.T)("不计数类型当前显示数为：")+(_.M.IntToString(t)+((0,
C.T)("，隐藏数为：")+_.M.IntToString(i)))),t=this.GetTypeTotal(!1,!0),i=this.GetTypeTotal(!1,!1),S.c.DebugLog((0,C.T)("当前显示总数为：")+(_.M.IntToString(t)+((0,
C.T)("，隐藏总数为：")+_.M.IntToString(i))))}},l.Inst=null,B(s=l,"Inst_get",[E.n],Object.getOwnPropertyDescriptor(s,"Inst_get"),s),
B(s.prototype,"SM_VisibleObjectsHandler",[n],Object.getOwnPropertyDescriptor(s.prototype,"SM_VisibleObjectsHandler"),s.prototype),s)},63182:(e,t,i)=>{i.d(t,{_:()=>r})
var n=i(70850),s=i(20641),l=i(21790),a=i(38935)
class r{static getInst(){return null==r._inst&&(r._inst=new r),r._inst}buyItem(e,t){const i=new l.n
i.CountNum=t,i.ShopItemId=e,a.C.Inst.F_SendMsg(i)}dealBagItem(e,t){if(-1==n.g.Inst_get().GetItemIndex(e)){const i=s.f.getInst().getShopIdByItemId(e)
return null!=i&&this.buyItem(i.id,t),!0}return!1}}r._inst=null},11926:(e,t,i)=>{i.d(t,{y:()=>B})
var n=i(31922),s=i(75439),l=i(66959),a=i(61149),r=i(95721),o=i(98130),d=i(98885),h=i(85602),u=i(79534),c=i(86133),I=i(98800),_=i(73206),p=i(36241),S=i(19176),g=i(68662),m=i(38935),f=i(62370),C=i(41664),T=i(66788),y=i(18202),A=i(31222),P=i(5494),w=i(45549),R=i(5924),D=i(72005),L=i(61911)
class E extends L.f{constructor(){super(),this.progress=null,this.maxStepTime=0,this._timerId=-1,this.mStartTime=0,this._degf_OnFrame=null,this._degf_OnFrame=()=>this.OnFrame()}
InitView(){this.progress=new D.w,this.progress.setId(this.FatherId,this.FatherComponentID,1)}OnAddToScene(){this.AddEventListeners()}Clear(){this.RemoveEventListeners()}
AddEventListeners(){R.C.Inst_get().ClearLoop(this._timerId),this._timerId=R.C.Inst_get().SetFrameLoop(this._degf_OnFrame,1),this.progress.fillAmountSet(0),
this.mStartTime=o.GF.Timer_get()}RemoveEventListeners(){R.C.Inst_get().ClearLoop(this._timerId),this._timerId=-1}OnFrame(){let e=(o.GF.Timer_get()-this.mStartTime)/this.maxStepTime
e>1&&(e=1),this.progress.fillAmountSet(e)}Destroy(){}}class B{constructor(){this.stepTime=null,this.stepElementIDs=null,this.startActElementID=0,this.startEffElementID=0,
this.maxStepTime=0,this.EndAccumulateStep=0,this.EffDelayDeleteTime=0,this.isInit=!1,this.mIsShow=!1,this.isInmidate=!1,this.mAccumulateProgressView=null,this.soundKey=null,
this._degf_CallDestoryAccumulateProgressView=null,this._degf_ShowAccumulateProgressViewHandler=null,this.stepTime=new h.Z,this.stepElementIDs=new h.Z,
this._degf_CallDestoryAccumulateProgressView=()=>this.CallDestoryAccumulateProgressView(),this._degf_ShowAccumulateProgressViewHandler=e=>this.ShowAccumulateProgressViewHandler(e)}
Init(){if(this.isInit)return
this.isInit=!0
const e=s.D.getInstance().getContent("STAR:EFF_DELAY")
null!=e&&(this.EffDelayDeleteTime=d.M.String2Int(e.getContent().stringVal))
const t=s.D.getInstance().getContent("STAR:STAGE_TIME"),i=d.M.Split(t.getContent().stringVal,d.M.s_SPAN_CHAR),n=d.M.Split(i[1],f.o.s_UNDER_CHAR)
let l=0
for(;l<n.count;)this.stepTime.Add(d.M.String2Int(n[l])),l+=1
this.maxStepTime=this.stepTime[this.stepTime.Count()-1]/1e3
const a=d.M.Split(i[0],f.o.s_UNDER_CHAR)
if(a.count!=n.count+2)return void T.Y.LogError((0,c.T)("蓄力技能配置有误！请对应策划检查CONFIGVALUE表"))
this.startActElementID=d.M.String2Int(a[0]),this.startEffElementID=d.M.String2Int(a[1])
let r=2
for(;r<a.count;)this.stepElementIDs.Add(d.M.String2Int(a[r])),r+=1}GetSkillElementID(e){return this.Init(),this.stepElementIDs.Count()>e?this.stepElementIDs[e]:0}
StartAccumulate(e){this.Init(),a.k.inst.clearAuotoPk()
const t=new l.U
t.skillId=e.skillid,t.clientStartTime=r.o.FromNumber(g.D.serverMSTime_get()),t.playerId=I.Y.Inst.PrimaryRoleInfo_get().Id_get(),m.C.Inst.F_SendMsg(t),
this.PlaySkillEffect(I.Y.Inst.PrimaryRole_get()),this.OpenAccumulateProgressView(),this.StartSkillAccumylateSound(e.name)}StartSkillAccumylateSound(e){e==(0,
c.T)("星辰一怒")&&(this.soundKey=C.j.Inst.PlayBySoundId(42036))}EndSkillAccumylateSound(e){e==(0,c.T)("星辰一怒")&&null!=this.soundKey&&(C.j.Inst.StopByKey(this.soundKey),
C.j.Inst.PlayBySoundId(42037))}PlaySkillEffect(e){if(this.Init(),null==e||null==e.Roleinfo_get())return
const t=u.P.zero_get()
e.MainRole_get().GetPosValue(t),_.X.Inst.DeleteElement(e.Roleinfo_get().accumulateActElementHandler),_.X.Inst.DeleteElement(e.Roleinfo_get().accumulateEffElementHandler),
e.Roleinfo_get().accumulateActElementHandler=w.x.GetInst().PlaySkillEffect(e,this.startActElementID,e.MainRole_get().handle,0,t,t,0,0,null,!0),
e.Roleinfo_get().accumulateEffElementHandler=w.x.GetInst().PlaySkillEffect(e,this.startEffElementID,e.MainRole_get().handle,0,t,t,0,0,null,!0),u.P.Recyle(t)}EndAccumulate(e){
if(null!=this.mAccumulateProgressView){this.EndAccumulateStep=0
const t=1e3*(o.GF.Timer_get()-this.mAccumulateProgressView.mStartTime),i=this.stepTime.Count()-1
let n=i
for(;n>-1;)t>=this.stepTime[n]&&(this.EndAccumulateStep=o.GF.INT(n+1),this.EndAccumulateStep>i&&(this.EndAccumulateStep=o.GF.INT(i))),n-=1
if(this.CloseAccumulateProgressView(),S.S.getInst().InHang_get())return p._.getInst().endHang(!1),w.x.GetInst().hotCastSKill(e.skillid,!0),p._.getInst().StartStopAIHandler(),
void this.EndSkillAccumylateSound(e.name)
w.x.GetInst().hotCastSKill(e.skillid,!0)}this.EndSkillAccumylateSound(e.name)}BreakAccumulate(e){null!=e&&null!=e.Roleinfo_get()&&(e.DeleteAccumulateEffElement(),
e==I.Y.Inst.PrimaryRole_get()&&this.CloseAccumulateProgressView())}OpenAccumulateProgressView(){this.mIsShow=!0,
null==this.mAccumulateProgressView?A.N.inst.OpenById(P.I.AccumulatePanel,this._degf_ShowAccumulateProgressViewHandler,this._degf_CallDestoryAccumulateProgressView):(this.mAccumulateProgressView.node.SetActive(!0),
this.mAccumulateProgressView.OnAddToScene())}ShowAccumulateProgressViewHandler(e){if(null==this.mAccumulateProgressView){this.mAccumulateProgressView=new E,
this.mAccumulateProgressView.setId(e,null,0),this.mAccumulateProgressView.maxStepTime=this.maxStepTime
const t=I.Y.Inst.PrimaryRoleInfo_get().Skills_get()
t.LuaDic_ContainsKey(n.z.SKILL_ID_XCYN)&&t[n.z.SKILL_ID_XCYN].level>=4&&(this.mAccumulateProgressView.maxStepTime=this.maxStepTime-1)}return this.mAccumulateProgressView}
CallDestoryAccumulateProgressView(){y.g.DestroyUIObj(this.mAccumulateProgressView),this.mAccumulateProgressView=null}IsShowAccumulateProgressView(){return this.mIsShow}
CloseAccumulateProgressView(){this.mIsShow=!1,null!=this.mAccumulateProgressView&&(this.mAccumulateProgressView.Clear(),this.mAccumulateProgressView.node.SetActive(!1)),
p._.getInst().ishang_get()&&p._.getInst().StartStopAIInmidateHandler()}}B.Inst=new B},70829:(e,t,i)=>{i.d(t,{j:()=>D})
var n=i(94148),s=i(31922),l=i(33314),a=i(96913),r=i(46749),o=i(75439),d=i(42534),h=i(33138),u=i(72835),c=i(845),I=i(35259),_=i(55360),p=i(98885),S=i(85602),g=i(72785),m=i(38962),f=i(8873),C=i(93984),T=i(38836),y=i(86133),A=i(38045),P=i(98800),w=i(62370),R=i(66788)
class D{constructor(){this.map=null,this.groupSkillDic=null,this.groupSkillSortDic=null,this.jobSkillSortDic=null,this.consumeItemIds=null,this.perfomanceDic=null,
this.AoYiSkillDic=null,this.angelSkills=null,this._degf_SkillGroupSort=null,this._degf_compare=null,this._degf_compareSkillBook=null,this.skillDic=null,this.aoYiSkillList=null,
this.aoYiSkillShowLv=null,this.aoYiSkillBuffList=null,this.groupSkillDic=new m.X,this.groupSkillSortDic=new m.X,this.jobSkillSortDic=new m.X,this.consumeItemIds=new m.X,
this.perfomanceDic=new m.X,this.AoYiSkillDic=new m.X,this.angelSkills=new S.Z,this._degf_SkillGroupSort=(e,t)=>this.SkillGroupSort(e,t),this._degf_compare=(e,t)=>this.compare(e,t),
this._degf_compareSkillBook=(e,t)=>this.compareSkillBook(e,t),this.skillDic=new m.X
const e=_.Y.Inst.GetOrCreateCsv(C.h.eSkill)
this.aoYiSkillList=o.D.getInstance().GetIntArray("SKILL:ESOTERIC_SKILL"),this.aoYiSkillShowLv=o.D.getInstance().GetIntValue("SKILL:ESOTERIC_SKILL_SEE"),
this.aoYiSkillBuffList=new S.Z([101081,101082,101083,101084,101085,101086,101087,101088,101089,101090,201081,201082,201083,201084,201085,201086,201087,201088,201089,201090,301081,301082,301083,301084,301085,301086,301087,301088,301089,301090]),
this.map=e.GetCsvMap(),this.InitSkillGroupDic(),this.InitJobSkillDic(),this.InitAngelSkillList()
const t=_.Y.Inst.GetOrCreateCsv(C.h.eSkillPerfomance).GetCsvMap()
for(const[e,i]of(0,T.vy)(t)){const i=t[e],n=new m.X
n.LuaDic_AddOrSetItem(s.z.DeviceQualityHigh,i.highEndId),n.LuaDic_AddOrSetItem(s.z.DeviceQualityMiddle,i.midEndId),n.LuaDic_AddOrSetItem(s.z.DeviceQualityLow,i.LowEndId),
this.perfomanceDic.LuaDic_AddOrSetItem(e,n)}}InitAngelSkillList(){const e=d.f.Inst().map
for(const[t,i]of(0,T.vy)(e))if(i.IsAngelEquip()&&!p.M.IsNullOrEmpty(i.addskill)){let e=p.M.Split(i.addskill,w.o.s_UNDER_CHAR)[0],t=p.M.String2Int(e)
;-1==this.angelSkills.IndexOf(t)&&this.angelSkills.Add(t)}}IsAoYiSkillBuff(e){return this.aoYiSkillBuffList.Contains(e)}IsAoYiSkill(e){return this.aoYiSkillList.Contains(e)}
GetQualyAdapatElementID(e){let t=null
if(t=this.perfomanceDic.LuaDic_GetItem(e),null!=t){let e=0
const i=c.g.Inst_get().systemModel.GetPerformanceType()
if(e=t.LuaDic_GetItem(i),null==e&&(e=0),0!=e)return e}return e}static Inst(){return null==D._inst&&(D._inst=new D),D._inst}IsHasSkill(e){let t=null
P.Y.Inst.PrimaryRoleInfo_get()
let i=!1
t=e.baseData_get()
const n=t.cfgData_get().Rewards_get().typevalues
let s=0,l=null
for(const[e,t]of(0,T.V5)(n))if("Skill"==t.type||"ExtraSkill"==t.type){l=p.M.Split(t.value,w.o.s_Arr_UNDER_COLON),s=p.M.String2Int(l[0])
i=0==this.isSkillLearn(s)}return i}isSkillLearn(e){return I.C.INSTANCE.isSkillLearn(e)}InitJobSkillDic(){let e=null,t=null
for(const[i,n]of(0,T.V5)(this.map)){const i=u.V.Inst_get().JobRelationDict
if(i.LuaDic_ContainsKey(n.job)){if(t=i[n.job],1==n.skillLevel&&0!=n.job&&null!=t&&t.Contains(n.job)){
this.jobSkillSortDic.LuaDic_ContainsKey(n.job)?this.jobSkillSortDic[n.job].Add(n):(e=new S.Z,e.Add(n),this.jobSkillSortDic.LuaDic_AddOrSetItem(n.job,e))}}else g.c.DebugError((0,
y.T)("找不到职业：")+n.job)}for(const[e,t]of(0,T.V5)(this.jobSkillSortDic))0!=t.Count()&&t.Sort(this._degf_compare)}GetSkillGroup(e){
if(!this.groupSkillDic.LuaDic_ContainsKey(e))return null
let t=null
return this.groupSkillSortDic.LuaDic_ContainsKey(e)?t=this.groupSkillSortDic[e]:(t=this.groupSkillDic[e],t.Sort(this._degf_SkillGroupSort),
this.groupSkillSortDic.LuaDic_AddOrSetItem(e,t)),t}SkillGroupSort(e,t){return e.order-t.order}GetIsTrueSkill(e){return 4==this.GetSkillById(e,!1).order}AddSkillToDic(e){let t=null
this.skillDic.LuaDic_ContainsKey(e.skillid)?t=this.skillDic.LuaDic_GetItem(e.skillid):(t=new S.Z(e.maxRealLevel),this.skillDic.LuaDic_AddOrSetItem(e.skillid,t)),
0==e.level?t[e.level]=e:t[e.level-1]=e}GetSkillInDic(e,t,i){let n=null
return this.skillDic.LuaDic_ContainsKey(e)?(n=this.skillDic.LuaDic_GetItem(e),t<=n.count?0==t?n[0]:n[t-1]:n[n.count-1]):(i&&R.Y.LogError(`${(0,
y.T)("GetSkillById 技能表找不到技能ID:")}${e}_${t}`),null)}InitSkillGroupDic(){let e=null,t=null
for(const[i,n]of(0,T.vy)(this.map)){if(t=this.map[i],this.aoYiSkillList.Contains(t.skillid)){const e=l.Z.GetJobKind(t.job)
this.AoYiSkillDic.LuaDic_ContainsKey(e)||this.AoYiSkillDic.LuaDic_AddOrSetItem(e,t.skillid),t.isAoYi=!0}this.AddSkillToDic(t),
1==t.skillLevel&&(this.groupSkillDic.LuaDic_ContainsKey(t.SkillGroup)?(e=this.groupSkillDic[t.SkillGroup],e.Add(t)):(e=new S.Z,e.Add(t),
this.groupSkillDic.LuaDic_AddOrSetItem(t.SkillGroup,e)))
const n=r.z.CreateFromJson(t.learnConsumes)
if(n.Parse(),null!=n.GetItem()){let e=0
for(;e<n.typevalues.Count();){const t=n.typevalues[e]
if(t.type==a._.t_Item){const e=p.M.String2Int(t.valueType)
this.consumeItemIds.LuaDic_AddOrSetItem(e,!0)}e+=1}}}}GetAoYiSkillByJobKind(e){return this.AoYiSkillDic.LuaDic_GetItem(e)}GetSkillByIdLevel(e,t,i){return null==i&&(i=!0),
this.GetSkillInDic(e,t,i)}GetPlayerSkillById(e,t,i){if(null==i&&(i=!0),!t.InTransform()){const n=I.C.INSTANCE.GetSkillByStudyDic(e,t)
let s=1
return null!=n&&(s=n.level),this.GetSkillInDic(e,s,i)}const s=n.b.Inst_get().GetSkillLevel()
return this.GetSkillByIdLevel(e,s,i)}GetSkillById(e,t){return null==t&&(t=!0),this.GetSkillInDic(e,1,t)}GetSkillIdByStrId(e){const t=p.M.Split(e,w.o.s_Arr_UNDER_CHAR_DOT)
return p.M.String2Int(t[0])}GetSkillByStrId(e,t){return null==t&&(t=!0),this.map.LuaDic_ContainsKey(e)?this.map[e]:(t&&R.Y.LogError((0,y.T)("GetSkillById 技能表找不到技能ID:")+e),null)}
GetDefaultSkillId(e){const t=l.Z.GetJobKind(e)
return f.v.DefauleSkillIds[t]}GetMaxLevelSkill(e){const t=this.GetSkillByIdLevel(e,1)
return null==t?null:this.GetSkillByIdLevel(e,t.maxRealLevel,!1)}GetAllSkillByJobkingAndTansfer(e,t){let i=null
const n=u.V.Inst_get().GetjobsByJobKingAndTransfer(e,t)
let s=0
for(;s<n.Count();){const e=n[s]
let t=null
t=this.jobSkillSortDic.LuaDic_GetItem(e),null!=t&&0!=t.Count()&&(null==i&&(i=new S.Z),i.AddRange(t)),s+=1}return null==i&&(i=new S.Z),i}GetProAllSkill(e){let t=null
const i=u.V.Inst_get().JobRelationDict[e]
let n=0
for(;n<i.Count();){const e=i[n]
let s=null
s=this.jobSkillSortDic.LuaDic_GetItem(e),null!=s&&0!=s.Count()&&(null==t&&(t=new S.Z),t.AddRange(s)),n+=1}return t}compare(e,t){
return e.circle<t.circle?-1:e.circle>t.circle?1:e.circleLevel<t.circleLevel?-1:e.circleLevel>t.circleLevel?1:e.skillid<t.skillid?-1:e.skillid>t.skillid?1:0}compareSkillBook(e,t){
const i=u.V.Inst_get().GetJobItemById(e.job),n=u.V.Inst_get().GetJobItemById(t.job)
return i.time<n.time?-1:i.time>n.time?1:e.job-t.job}GetSkillCfgByItemId(e){const t=h.f.Inst().getItemById(e).Rewards_get(),i=(0,A.aI)(p.M.Split(t.typevalues[0].value,":")[0])
return this.GetSkillByIdLevel(i,1)}}D._inst=null},80129:(e,t,i)=>{i.d(t,{D:()=>C})
var n=i(56937),s=i(18202),l=i(31222),a=i(5494),r=i(52726),o=i(995),d=i(98130),h=i(85602),u=i(72785),c=i(86133),I=i(5924),_=i(8889),p=i(3522),S=i(72005),g=i(61911),m=i(60130)
class f extends g.f{constructor(){super(),this.icon1=null,this.icon2=null,this.icon3=null,this.icon4=null,this.icon5=null,this.icon6=null,this.effxh1=null,this.effxh2=null,
this.effxh3=null,this.effxh4=null,this.effxh5=null,this.effxh6=null,this.effsg1=null,this.effsg2=null,this.effsg3=null,this.effsg4=null,this.effsg5=null,this.effsg6=null,
this.effsglight=null,this.effpanel=null,this.icons=null,this.effxhs=null,this.effsgs=null,this.timesmsg=null,this.timerid=-1,this._degf_playeff=null,
this._degf_playeff=(e,t)=>this.playeff(e,t)}InitView(){super.InitView(),this.icon1=new S.w,this.icon1.setId(this.FatherId,this.FatherComponentID,1),this.icon2=new S.w,
this.icon2.setId(this.FatherId,this.FatherComponentID,2),this.icon3=new S.w,this.icon3.setId(this.FatherId,this.FatherComponentID,3),this.icon4=new S.w,
this.icon4.setId(this.FatherId,this.FatherComponentID,4),this.icon5=new S.w,this.icon5.setId(this.FatherId,this.FatherComponentID,5),this.icon6=new S.w,
this.icon6.setId(this.FatherId,this.FatherComponentID,6),this.effxh1=new p.k,this.effxh1.setId(this.FatherId,this.FatherComponentID,7),this.effxh2=new p.k,
this.effxh2.setId(this.FatherId,this.FatherComponentID,8),this.effxh3=new p.k,this.effxh3.setId(this.FatherId,this.FatherComponentID,9),this.effxh4=new p.k,
this.effxh4.setId(this.FatherId,this.FatherComponentID,10),this.effxh5=new p.k,this.effxh5.setId(this.FatherId,this.FatherComponentID,11),this.effxh6=new p.k,
this.effxh6.setId(this.FatherId,this.FatherComponentID,12),this.effsg1=new p.k,this.effsg1.setId(this.FatherId,this.FatherComponentID,13),this.effsg2=new p.k,
this.effsg2.setId(this.FatherId,this.FatherComponentID,14),this.effsg3=new p.k,this.effsg3.setId(this.FatherId,this.FatherComponentID,15),this.effsg4=new p.k,
this.effsg4.setId(this.FatherId,this.FatherComponentID,16),this.effsg5=new p.k,this.effsg5.setId(this.FatherId,this.FatherComponentID,17),this.effsg6=new p.k,
this.effsg6.setId(this.FatherId,this.FatherComponentID,18),this.effsglight=new p.k,this.effsglight.setId(this.FatherId,this.FatherComponentID,19),this.effpanel=new _.$,
this.effpanel.setId(this.FatherId,this.FatherComponentID,20),this.effxhs=new h.Z,this.effxhs.Add(this.effxh1),this.effxhs.Add(this.effxh2),this.effxhs.Add(this.effxh3),
this.effxhs.Add(this.effxh4),this.effxhs.Add(this.effxh5),this.effxhs.Add(this.effxh6),this.effsgs=new h.Z,this.effsgs.Add(this.effsg1),this.effsgs.Add(this.effsg2),
this.effsgs.Add(this.effsg3),this.effsgs.Add(this.effsg4),this.effsgs.Add(this.effsg5),this.effsgs.Add(this.effsg6),this.icons=new h.Z,this.icons.Add(this.icon1),
this.icons.Add(this.icon2),this.icons.Add(this.icon3),this.icons.Add(this.icon4),this.icons.Add(this.icon5),this.icons.Add(this.icon6)}OnAddToScene(){
m.O.AddUIEffectSortOrderBind(this.effpanel.node)
let e=0
for(;e<this.effxhs.Count();)this.effxhs[e].node.SetActive(!1),this.effsgs[e].node.SetActive(!1),e+=1
this.effsglight.node.SetActive(!1),this.UpdateView(this.timesmsg)}setData(e){this.timesmsg=e,this.UpdateView()}UpdateView(e){if(null==this.timesmsg)return
const t=this.timesmsg.hitTimes
if(t>6)return void u.c.DebugError((0,c.T)("连击数大于6异常了"))
if(this.timesmsg.times>6)return void u.c.DebugError((0,c.T)("连击上限数大于6异常了"))
let i=0
for(i=0;i<t;)this.icons[i].spriteNameSet("mainui_sp_255"),i+=1
for(i=t;i<this.timesmsg.times;)this.icons[i].spriteNameSet("mainui_sp_256"),i+=1
for(i=this.timesmsg.times;i<this.icons.Count();)this.icons[i].spriteNameSet("mainui_sp_257"),i+=1
this.timerid=I.C.Inst_get().SetFrameLoopForParm(this._degf_playeff,3,1,t-1),this.effsgs[t-1].node.SetActive(!0),this.effsgs[t-1].SetResetOnPlay(!0),this.effsgs[t-1].Play(!0,!1),
this.timesmsg.hitTimes==this.timesmsg.times&&(this.effsglight.node.SetActive(!0),this.effsglight.SetResetOnPlay(!0),this.effsglight.Play(!0,!1))}playeff(e,t){
if(null==C.Inst_get()._iconTipsPanel)return
if(-1==this.timerid)return
const i=d.GF.INT(t)
this.effxhs[i].node.SetActive(!0),this.effxhs[i].SetResetOnPlay(!0),this.effxhs[i].Play(!0,!1)}Clear(){I.C.Inst_get().ClearInterval(this.timerid),this.timerid=-1}Destroy(){}}
class C{constructor(){this._iconTipsPanel=null,this.timesmsg=null,this._degf_CallDestory=null,this._degf_ShowHandler=null,this._degf_CallDestory=()=>this.CallDestory(),
this._degf_ShowHandler=e=>this.ShowHandler(e),this.registeEvent()}static Inst_get(){return null==C._Inst&&(C._Inst=new C),C._Inst}registeEvent(){}OpenIconTipsPanel(e){
if(this.timesmsg=e,null!=this._iconTipsPanel&&this._iconTipsPanel.isShow_get())this._iconTipsPanel.setData(this.timesmsg)
else{const e=new n.v
e.layerType=r.F.DefaultUI,e.aniDir=o.K.Down,l.N.inst.OpenById(a.I.eLianjiTipsPanel,this._degf_ShowHandler,this._degf_CallDestory,e)}}CallDestory(){
s.g.DestroyUIObj(this._iconTipsPanel),this._iconTipsPanel=null}ShowHandler(e){return null==this._iconTipsPanel&&(this._iconTipsPanel=new f,
this._iconTipsPanel.timesmsg=this.timesmsg,this._iconTipsPanel.setId(e,null,0)),this._iconTipsPanel}CloseView(){l.N.inst.ClosePanel(this._iconTipsPanel)}}C._Inst=null},
19003:(e,t,i)=>{i.d(t,{l:()=>f})
var n=i(18998),s=i(55226),l=i(92984),a=i(33314),r=i(95721),o=i(38962),d=i(79534),h=i(8125),u=i(38836),c=i(86133),I=i(98800),_=i(93701),p=i(66788),S=i(70829)
class g{constructor(){this.skillId=0,this.configId=null,this.casterEffectHandle=0,this.trajectoryEffectHandle=0,this.hitEffectHandle=0,this.tailEffectHandle=0,this.endX=0,
this.endY=0,this.buffType=null,this.msg=null,this.level=1,this.effectorOid=null,this.targetOid=null}}g.MOTION_CHARGE=0,g.MOTION_TELEPORT=1
var m=i(45549)
class f{constructor(){this.moveSkillHandleDic=null,this.playerMoveHandler=null,this.moveSkillHandleDic=new o.X}DealMoveSkill(e,t){const i=e.m_buffIdList
if(null!=i)for(const[n,s]of(0,u.V5)(i)){const i=l.j.Inst_get().model.GetBuffResById(s)
if(null!=i&&(i.type==f.BUFF_TYPE_CHARGEDIR||i.type==f.BUFF_TYPE_TELEPORT||i.type==f.BUFF_TYPE_BACKWARDS)){const n=this.GetHandleInst(e.id,e.skillid,t)
return n.buffType=i.type,n}}return null}IsMoveSkill(e){const t=e.GetBuffIds()
for(const[e,i]of(0,u.V5)(t)){const e=l.j.Inst_get().model.GetBuffResById(i)
if(null!=e&&(e.type==f.BUFF_TYPE_CHARGEDIR||e.type==f.BUFF_TYPE_TELEPORT||e.type==f.BUFF_TYPE_BACKWARDS||e.type==f.BUFF_TYPE_CHARGEPOSITION))return!0}return!1}IsTeleportSkill(e){
const t=e.GetBuffIds()
for(const[e,i]of(0,u.V5)(t)){const e=l.j.Inst_get().model.GetBuffResById(i)
if(null!=e&&(e.type==f.BUFF_TYPE_TELEPORT||e.type==f.BUFF_TYPE_BACKWARDS))return!0}return!1}OnMoveStarttMotionBefore(e,t){
const i=`${e.motion.skillId}_${e.motion.skillLevel}`,n=this.GetHandleInst(i,e.motion.skillId,e.owner)
n.endX=e.motion.endX,n.endY=e.motion.endY
const s=S.j.Inst().GetSkillByIdLevel(n.skillId,n.level),l=I.Y.Inst.getCharacterById(n.effectorOid),a=I.Y.Inst.getCharacterById(n.targetOid)
;[f.rushElementId]=m.x.GetInst().showSkillEffect(s,l,a,n.endX,n.endY,!0,!1,null,null,null,null,t)}OnMoveStarttMotion(e,t){
const i=`${e.motion.skillId}_${e.motion.skillLevel}`,l=this.GetHandleInst(i,e.motion.skillId,e.owner)
l.endX=e.motion.endX,l.endY=e.motion.endY
const r=S.j.Inst().GetSkillByIdLevel(l.skillId,l.level),o=I.Y.Inst.getCharacterById(l.effectorOid)
I.Y.Inst.getCharacterById(l.targetOid)
switch(e.motion.type){case f.CHARGE_TYPE:let t
t=new d.P(e.motion.endX,0,e.motion.endY)
let i=o.Roleinfo_get().Job_get(),l=a.Z.GetJobType(i),h=(0,s.P)(r.SingleAttackId,l)
h?h/=1e3:h=.3,(0,n.tween)(o).to(h,{tweenPos:t}).start()
break
case f.BLINK_TYPE:o.setPos(e.motion.endX,e.motion.endY)
break
case f.ADSORB_TYPE:console.error("MoveSkillLogic.ADSORB_TYPE 还没实现")}}GetHandleInst(e,t,i){if(e=this.GetMoveKey(e,i),
this.moveSkillHandleDic.LuaDic_ContainsKey(e))return this.moveSkillHandleDic[e]
const n=new g
return n.effectorOid=i,n.skillId=t,n.configId=e,this.moveSkillHandleDic.LuaDic_AddOrSetItem(e,n),I.Y.Inst.PlayerId_get().Equal(i)&&(this.playerMoveHandler=n),n}GetExistHandle(e,t){
if(null==t)return null
const i=`${e}_${t.ToStringByRadix(10)}`
return this.moveSkillHandleDic.LuaDic_ContainsKey(i)?this.moveSkillHandleDic[i]:null}ClearMoveHandle(e,t,i){const n=`${t}_${i}`,s=this.GetHandleInst(n,t,e),l=this.GetMoveKey(n,e)
if(null!=s){const t=I.Y.Inst.getRoleById(e)
null!=t&&s.buffType!=f.BUFF_TYPE_TELEPORT&&s.buffType!=f.BUFF_TYPE_BACKWARDS&&t.setPos(s.endX,s.endY),this.moveSkillHandleDic.LuaDic_Remove(l)}}ClearPlayerMoveHandle(){
null!=this.playerMoveHandler&&(_.a.ins.DeleteEffShowById(this.playerMoveHandler.casterEffectHandle),_.a.ins.DeleteEffShowById(this.playerMoveHandler.trajectoryEffectHandle),
_.a.ins.DeleteEffShowById(this.playerMoveHandler.tailEffectHandle),this.playerMoveHandler=null)}IsDealTeleportSkill(e,t){if(null==e)return!1
if(e.buffType==f.BUFF_TYPE_TELEPORT||e.buffType==f.BUFF_TYPE_BACKWARDS){
const i=I.Y.Inst.PrimaryRole_get(),n=i.GetPos(),s=d.P.zero_get(),l=S.j.Inst().GetSkillByStrId(e.configId),a=l.pointDis
if(t){const e=i.GetDirection(),t=.9*a*Math.cos(e),l=.9*a*Math.sin(e)
s.x=n.x+t,s.z=n.z+l,s.y=n.y}else{const e=h.T.GetMousePosition()
LuaSceneBridgeManager.Instance_get().RayMap(e.x,e.y,s),d.P.Recyle(e),s.y=n.y
let t=d.P.Distance(s,n)
if(t>a){let e=a/t
e*=.95,s.x=n.x+(s.x-n.x)*e,s.z=n.z+(s.z-n.z)*e,t=d.P.Distance(s,n)}}const r=this.GetUsePoint(n,s)
return d.P.Recyle(s),0!=r.y&&m.x.GetInst().SendCastSkillMsg(l,I.Y.Inst.PlayerId_get(),r.x,r.z,I.Y.Inst.PlayerId_get(),I.Y.Inst.PrimaryRole_get()),d.P.Recyle(r),!0}return!1}
GetUsePoint(e,t){const i=d.P.zero_get()
if(LuaSceneBridgeManager.Instance_get().CanArriveByPos(t))return i.Set(t.x,t.y,t.z),i
const n=t.x-e.x,s=t.z-e.z
let l=19
for(;l>=1;){if(t.x=e.x+n*l*.05,t.z=e.z+s*l*.05,LuaSceneBridgeManager.Instance_get().CanArriveByPos(t)){i.Set(t.x,t.y,t.z)
break}l-=1}return i}DealSkillEffect(e,t){const i=this.GetHandleInst(e.id,e.skillid,t.effectorOid)
i.skillId=t.skillId,i.level=t.level,0==t.level&&p.Y.LogError((0,c.T)("SM_StartUseSkill消息异常:等级为0")),i.effectorOid=r.o.New(t.effectorOid.low_get(),t.effectorOid.high_get()),
i.targetOid=r.o.New(t.targetOid.low_get(),t.targetOid.high_get())}GetMoveKey(e,t){return`${e}_${t.ToStringByRadix(10)}`}}f.BUFF_TYPE_CHARGEDIR="ChargeDir",
f.BUFF_TYPE_CHARGEPOSITION="ExchangePosition",f.BUFF_TYPE_TELEPORT="Teleport",f.BUFF_TYPE_BACKWARDS="Backwards",f.BUFF_TYPE_RECOVER="Recover",f.BUFF_TYPE_SNEER="Sneer",
f.rushElementId=0,f.CHARGE_TYPE=0,f.BLINK_TYPE=1,f.ADSORB_TYPE=2},45549:(e,t,i)=>{i.d(t,{x:()=>St})
var n=i(92415),s=i(80459),l=i(75439),a=i(54383),r=i(95721),o=i(71409),d=i(35128),h=i(98130),u=i(98885),c=i(85602),I=i(38962),_=i(52212),p=i(79534),S=i(38836),g=i(38045),m=i(98800),f=i(62846),C=i(96557),T=i(97461),y=i(65530),A=i(54671),P=i(47258),w=i(2577)
class R{constructor(){this.label=0,this.strs={},this.primaryRole=null,this.t_character=null,this.isuser=!1,this.mutilHurtOffset=0,this.targetId=null}}
var D=i(84581),L=i(21697),E=i(74416),B=i(28475),M=i(66788),G=i(70829),O=i(17409),U=i(11037),b=i(32691),F=i(92202),k=i(13195),v=i(16854),N=i(68662),V=i(38935),x=i(5924)
class H extends k.W{constructor(){super(!0,v.J.eSkillShow,v.J.eSkillShow),this._degf_Show_EndUseSkill=null,this._degf_Show_EndUseSkill=(e,t)=>this.Show_EndUseSkill(e,t)}
static GetInst(){return null==H._inst&&(H._inst=new H),H._inst}InitSingleton(){}UnInitSingleton(){}add(e){const t=e,i=h.GF.INT(t.delayTime.ToNum())
if(i<=0)this.Show_EndUseSkill(0,t)
else{const n=t.useTime.ToNum()
let s=N.D.serverMSTime_get()-n
s<0&&(s=0)
const l=i-h.GF.INT(s)
l>0?(t.ResetUHandle(),x.C.Inst_get().SetIntervalForParm(this._degf_Show_EndUseSkill,l,1,e)):this.Show_EndUseSkill(0,t)}}Show_EndUseSkill(e,t){St.GetInst().Show_EndUseSkill(t)
let i=0
const n=`${t.skillId}_${t.level}`
let s=0,l=!1,a=0,r=!1
if(G.j.Inst().angelSkills.IndexOf(t.skillId)>-1){s=1,l=!0
for(let e=0;e<=t.effectList.Count()-1;e++){i+=t.effectList[e].damage}}else{let e=!1
const o=m.Y.Inst.primaryRoleInfoList
for(let i=0;i<=o.Count()-1;i++)if(o[i].Id_get().Equal(t.effectorOid)){e=!0
break}if(!e)return
if(null!=U.D.GetInst().GetHorseLevelSkill(n)?l=!0:G.j.Inst().IsAoYiSkillBuff(t.buffId)&&(s=2,a=t.buffId,l=!0,r=!0),l)for(let e=0;e<=t.effectList.Count()-1;e++){
i+=t.effectList[e].damage}}if(l){const e=F.O.Inst_get().GetSkillShow(n,a)
if(r||null==e){const e={skillId:n,hurtValue:i,isShow:!1,type:s,buffId:a}
F.O.Inst_get().AddHorseSkillShow(e),b.C.Inst_get().ShowHorseSkillMainView()}else{e.hurtValue+=i
let t=(0,O.Y)(_PanelId0.HorseSkillMainView)
null!=t&&t.UpdateItemHurtValue(n)}}V.C.Inst.Recycle_MessagePools(t)}}H._inst=null
var Z=i(42292),Y=i(30627),W=i(59625),K=i(92679),z=i(31922),j=i(33314),X=i(87923),q=i(27122),J=i(48933),$=i(74369),Q=i(72041),ee=i(44637),te=i(65561),ie=i(22662),ne=i(47552),se=i(61149),le=i(88883),ae=i(25406),re=i(65550),oe=i(20193),de=i(78300),he=i(61991),ue=i(48712),ce=i(82815),Ie=i(7733),_e=i(22797),pe=i(34899),Se=i(77546),ge=i(86133),me=i(75331),fe=i(53920),Ce=i(63611),Te=i(89549),ye=i(55039),Ae=i(87722),Pe=i(67703),we=i(94954),Re=i(70650),De=i(61646),Le=i(73206),Ee=i(93701),Be=i(4926),Me=i(19176),Ge=i(6700),Oe=i(73136),Ue=i(93052),be=i(71530),Fe=i(41664),ke=i(11926),ve=i(53343),Ne="SINGLE",Ve="TARGET_RANGE",xe="POSITION_RANGE",He=i(38770)
class Ze{constructor(){this.msg=null,this.cfg=null,this.caster=null,this.index=0}static GetPoolData(e,t,i,n){if(!Ze.isInit){for(let e=1;e<=20;e++)Ze.cachePool.Add(new Ze)
Ze.isInit=!0}let s=null
return Ze.cachePool.count>0?(s=Ze.cachePool[0],Ze.cachePool.RemoveAt(0)):s=new Ze,s.msg=e,s.cfg=t,s.caster=i,s.index=n,s}Clone(){
return Ze.GetPoolData(this.msg,this.cfg,this.caster,this.index)}static Recycle(e){e.msg=null,e.cfg=null,e.caster=null,e.index=0,Ze.cachePool.Add(e)}}Ze.cachePool=new c.Z,
Ze.isInit=!1
class Ye{}Ye.PASSIVE="passive",Ye.SINGLEATTACK="singleAttack",Ye.GROUPATTACK="groupAttack",Ye.BUFF="buff",Ye.SUMMON="summon",Ye.RUSH="rush",Ye.TELEPORT="teleport",
Ye.LIGHTNINGARROW="lightningArrow"
class We{constructor(){this.msg=null,this.value=0,this.primaryRole=null,this.t_character=null,this.ismysum=!1,this.isMyPet=!1,this.i=0,this.targetId=null}static new(){
const e=q.Q.Inst().GetObjectByName("DoubleAttackHurtVo",We)
return e.isRecycle=!1,e}ClearData(){this.msg=null,this.value=0,this.primaryRole=null,this.t_character=null,this.ismysum=!1,this.isMyPet=!1,this.targetId=null,this.i=0}Clone(){
const e=new We
return e.msg=this.msg.Clone(),e.value=this.value,e.primaryRole=this.primaryRole,e.t_character=this.t_character,e.ismysum=this.ismysum,e.isMyPet=this.isMyPet,
e.targetId=this.targetId,e}}var Ke,ze,je,Xe,qe,Je,$e,Qe,et,tt,it,nt,st,lt,at,rt,ot,dt,ht,ut,ct,It,_t=i(19003)
function pt(e,t,i,n,s){var l={}
return Object.keys(n).forEach((function(e){l[e]=n[e]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,n){return n(e,t,i)||i}),l),s&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(s):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(e,t,l),l=null),l}let St=(Ke=(0,o.GH)(n.k.SM_ComboTimes),ze=(0,o.GH)(n.k.SM_SkillsInfo),je=(0,o.GH)(n.k.SM_StartMotion),Xe=(0,
o.GH)(n.k.SM_EndMotion),qe=(0,o.GH)(n.k.SM_InterruptMotion),Je=(0,o.GH)(n.k.SM_LightArrowNotice),$e=(0,o.GH)(n.k.SM_AlmightyBall),Qe=(0,o.GH)(n.k.SM_UpdateSkillCd),et=(0,
o.GH)(n.k.SM_UpdateSkillPublicCd),tt=(0,o.GH)(n.k.SM_SkillAlertTime),it=(0,o.GH)(n.k.SM_AbortAccumulateSkill),nt=(0,o.GH)(n.k.SM_SpiritInfo),st=(0,o.GH)(n.k.SM_UpdateSkillEntry),
lt=(0,o.GH)(n.k.SM_Cultivation),at=(0,o.GH)(n.k.SM_State),rt=(0,o.GH)(n.k.SM_UseSkill),ot=(0,o.GH)(n.k.SM_StartUseSkill),dt=(0,o.GH)(n.k.SM_EndUseSkill),ht=(0,
o.GH)(n.k.SM_ClearSkillCd),ut=(0,o.GH)(n.k.SM_ShortcutKey),It=class e{static get Inst(){return null==e._Inst&&e.GetInst(),e._Inst}constructor(){this.hitCharacterDic=I.X.new(),
this.m_skillEndDic=I.X.new(),this.moveSkillLogic=new _t.l,this.delaySkillDic=null,this.rushHandleId=0,this.nextUseWeakShootingIdx=A.X.NONE,this._skillModel=null,
this._MinBooldFlyGap=-1,this.savemsg=null,this.lastsendtime=0,this.sendtime=0,this._attackintervalId=-1,this.curAEhandle=0,this.PrendPos=null,this.skillmsgbuff=null,
this.curAttackMeTargetId=null,this.OldPkMeTargetId=null,this.isShowEffect=!0,this.lastTargetId=null,this.forbidenTimeId=-1,this._degf_CDHandler1=null,this._degf_CDHandler2=null,
this._degf_PhotoShotSkillDone=null,this._degf_SM_AbortAccumulateSkillHandler=null,this._degf_SM_ClearSkillCdHandler=null,this._degf_SM_ComboTimesHandler=null,
this._degf_SM_CultivationHandler=null,this._degf_SM_EndMotionHandler=null,this._degf_SM_EndUseSkillHandler=null,this._degf_SM_InterruptMotionHandler=null,
this._degf_SM_InterruptSkillHandler=null,this._degf_SM_LightArrowNoticeHandler=null,this._degf_SM_AlmightyBallHandler=null,this._degf_SM_ShortcutKeyHandler=null,
this._degf_SM_SkillAlertTimeHandler=null,this._degf_SM_SkillsInfoHandler=null,this._degf_SM_SpiritInfoHandler=null,this._degf_SM_StartMotionHandler=null,
this._degf_SM_StartUseSkillHandler=null,this._degf_SM_StateHandler=null,this._degf_SM_UpdateSkillCdHandler=null,this._degf_SM_UpdateSkillPublicCdHandler=null,
this._degf_SM_UpdateSkillEntryHandler=null,this._degf_SM_UseSkillHandler=null,this._degf_ShowMutilBlood=null,this._degf_ShowDoubleAttackBlood=null,this._degf_TimeChange=null,
this._degf_DoShowEffect=null,this._degf_ShowChainLightningEffect=null,this.forbidenUseSkill=null,this.time=null,this.hitCharacterDic=new I.X,this.m_skillEndDic=new I.X,
this.delaySkillDic=new I.X,this.PrendPos=new p.P,this._degf_CDHandler1=(e,t)=>this.CDHandler1(e,t),this._degf_CDHandler2=(e,t)=>this.CDHandler2(e,t),
this._degf_PhotoShotSkillDone=e=>this.PhotoShotSkillDone(e),this._degf_SM_AbortAccumulateSkillHandler=e=>this.SM_AbortAccumulateSkillHandler(e),
this._degf_SM_ClearSkillCdHandler=e=>this.SM_ClearSkillCdHandler(e),this._degf_SM_ComboTimesHandler=e=>this.SM_ComboTimesHandler(e),
this._degf_SM_CultivationHandler=e=>this.SM_CultivationHandler(e),this._degf_SM_EndMotionHandler=e=>this.SM_EndMotionHandler(e),
this._degf_SM_EndUseSkillHandler=e=>this.SM_EndUseSkillHandler(e),this._degf_SM_InterruptMotionHandler=e=>this.SM_InterruptMotionHandler(e),
this._degf_SM_InterruptSkillHandler=e=>this.SM_InterruptSkillHandler(e),this._degf_SM_LightArrowNoticeHandler=e=>this.SM_LightArrowNoticeHandler(e),
this._degf_SM_AlmightyBallHandler=e=>this.SM_AlmightyBallHandler(e),this._degf_SM_ShortcutKeyHandler=e=>this.SM_ShortcutKeyHandler(e),
this._degf_SM_SkillAlertTimeHandler=e=>this.SM_SkillAlertTimeHandler(e),this._degf_SM_SkillsInfoHandler=e=>this.SM_SkillsInfoHandler(e),
this._degf_SM_SpiritInfoHandler=e=>this.SM_SpiritInfoHandler(e),this._degf_SM_StartMotionHandler=e=>this.SM_StartMotionHandler(e),
this._degf_SM_StartUseSkillHandler=e=>this.SM_StartUseSkillHandler(e),this._degf_SM_StateHandler=e=>this.SM_StateHandler(e),
this._degf_SM_UpdateSkillCdHandler=e=>this.SM_UpdateSkillCdHandler(e),this._degf_SM_UpdateSkillPublicCdHandler=e=>this.SM_UpdateSkillPublicCdHandler(e),
this._degf_SM_UpdateSkillEntryHandler=e=>this.SM_UpdateSkillEntryHandler(e),this._degf_SM_UseSkillHandler=e=>this.SM_UseSkillHandler(e),
this._degf_ShowMutilBlood=(e,t)=>this.ShowMutilBlood(e,t),this._degf_ShowDoubleAttackBlood=(e,t)=>this.ShowDoubleAttackBlood(e,t),this._degf_TimeChange=()=>this.TimeChange(),
this._degf_DoShowEffect=(e,t)=>this.DoShowEffect(e,t),this._degf_ShowChainLightningEffect=(e,t)=>this.ShowChainLightningEffect(e,t),this._skillModel=INS.skillModel,
this.skillmsgbuff=H.GetInst()}static GetInst(){return null==e._Inst&&(e._Inst=new e),e._Inst}CheckLastTargetIsPKList(e){
return null!=e&&null!=this.lastTargetId&&!(!e.Equal(this.lastTargetId)||!a.k.Inst_get().IsExistPkList(this.lastTargetId))}ParseConfig(){
const e=l.D.getInstance().GetStringValue("SHANDIANLIAN:PIAOXUE")
if(!u.M.IsNullOrEmpty(e)){const t=u.M.Split(e,u.M.s_CCD_CHAR_DOT)
for(let e=1;e<=t.count;e++){const i=u.M.Split(t[e-1],GameStringProxy.s_UNDER_CHAR)
this.delaySkillDic.LuaDic_AddOrSetItem(u.M.String2Int(i[0]),u.M.String2Int(i[1]))}}}RegistProtocol(){}GetSkillDisLimit(e){return e.m_skillMaxDis}GetDisLimit(e){
const t=l.D.getInstance().getContent("SETTING:MAX_FIND_OBJECT_DISTANCE").getContent(),i=u.M.Split(t.stringVal,u.M.s_CCD_CHAR_DOT)
for(const[t,n]of(0,S.V5)(i)){const t=u.M.Split(n,GameStringProxy.s_UNDER_CHAR)
if(e==u.M.String2Int(t[0]))return u.M.String2Int(t[1])}return 10}MinBooldFlyGap_get(){
return-1==this._MinBooldFlyGap&&(this._MinBooldFlyGap=l.D.getInstance().GetIntValue("MUTILHURT:MIN_INTERVAL")),this._MinBooldFlyGap}SM_ComboTimesHandler(e){const t=e
t.hitTimes>0?LianjiTipsController.Inst_get().OpenIconTipsPanel(t):LianjiTipsController.Inst_get().CloseView()}SM_SkillsInfoHandler(e){
const t=e,i=m.Y.Inst.GetMultiPlayerInfo(t.playerId)
i.Skills_set(t.skills),i.isNoRoleModel||T.i.Inst.RaiseEvent(K.g.ACTIVE_UPDATE)}SM_StartMotionHandler(e){const t=e
m.Y.Inst.getCharacterById(t.owner)
this.moveSkillLogic.OnMoveStarttMotion(t,!0)}TestUseMotion(){}SM_EndMotionHandler(e){const t=e
this.moveSkillLogic.ClearMoveHandle(t.owner,t.skillId,t.skillLevel)}SM_InterruptMotionHandler(e){const t=e
this.moveSkillLogic.ClearMoveHandle(t.owner,t.skillId,t.skillLevel)}SM_LightArrowNoticeHandler(e){const t=e
DelaySkillShowControl.GetInst().HandleLightArrowNotice(t)}SM_AlmightyBallHandler(e){const t=e
DelaySkillShowControl.GetInst().HandleAlmightyBallNotice(t)}SM_UpdateSkillCdHandler(e){const t=e,i=N.D.serverMSTime_get()
let n=t.skillCdEndTime.ToNum()-i
n<0&&(n=0)
let s=t.publicGroupNextTime.ToNum()-i
s<0&&(s=0),me.N.Inst.UpdateCD(t.playerId,t.skillId,n,t.publicGroup,s,t.login)}SM_UpdateSkillPublicCdHandler(e){const t=e
me.N.Inst.UpdatePublicCd2(t.skillPublicCd)}SM_SkillAlertTimeHandler(e){const t=e,i=G.j.Inst().GetSkillByStrId(t.skillId),n=m.Y.Inst.getCharacterById(t.objectId)
if(null!=n){const e=ye.W.transHeading2UnityDir(t.heading)
n.SetDirection(e)
const s=p.P.zero_get()
n.GetCurPos(s),i.areaSelector!=Ve&&i.areaSelector!=xe||(s.x=t.centerX,s.z=t.centerY)
let l=1
const a=n.GetHandle()
let r=t.alertTime+200
if(0!=i.warningEventID){const e=n
null!=e&&(null!=e.Statemachine_get()&&e.Statemachine_get().PlayStateAni(i.warningEventID,0,0,1),r<=1&&(r=1),l=i.warningAnimTime/r,e.SetAnimationRate(l))}if(0!=i.warningEffect){
l=5e3/r
let e=1,t=1,o=1
null!=i.elementScale&&i.elementScale.length>0&&(1==i.elementScale.length?e=i.elementScale[1]:(t=i.elementScale[1],o=i.elementScale[2]))
const d=Le.X.Inst.PlayElement(i.warningEffect,a,a,s,s,n.GetDirectionAndAdjust(),null,!1,l,!0,e,t,o)
null!=d&&0!=d&&n.SetAlertEleHandle(d)}p.P.Recyle(s)
const o={}
i.warningEffect>0?o[1]="isAlert$1":0==i.warningEffect&&(o[1]="isAlert$-1"),Fe.j.Inst.PlayByCfgSoundId(i.alertSound,null,o),this.PlayDelayEffect(t.skillId,t.objectId)}
T.i.Inst.RaiseEvent(K.g.SKILL_ALERT,t)}handleEndSkillPlay(e){
Me.S.getInst().InHang_get()||null!=m.Y.Inst.PrimaryRole_get()&&null!=m.Y.Inst.PrimaryRole_get().AISingleton_get()&&(m.Y.Inst.PrimaryRole_get().AISingleton_get().getSingletonType(),
ce.R.precastskill)}SM_AbortAccumulateSkillHandler(e){ke.y.Inst.BreakAccumulate(m.Y.Inst.PrimaryRole_get())}SM_SpiritInfoHandler(e){const t=e
if(null!=t){null!=G.j.Inst().GetSkillByStrId(t.skillid)&&m.Y.Inst.CreateSpirit(t)}}SM_UpdateSkillEntryHandler(e){const t=e
this.SM_UpdateSkillEntryHandlerTrue(t)}SM_UpdateSkillEntryHandlerTrue(e){if(null!=e){const t=m.Y.Inst.GetMultiPlayerInfo(e.playerId)
null!=t&&t.updateSkillEntry(e.entry,e.needNotify)}}SM_CultivationHandler(e){}CastSkill(t,i,n){if(null==i)return!1
const s=i.Roleinfo_get(),l=a.k.Inst_get().pkModel
if(l==le.j.GUILD_MODEL&&null!=n)if(n.Roletype_get()==D.s.role){
const e=n.Roleinfo_get(),i=e.teamId_get().Equal(s.teamId_get())&&!s.teamId_get().Equal(r.o.ZERO)&&!e.Id_get().Equal(s.Id_get()),l=e.AsuramId_get().Equal(s.AsuramId_get())&&!s.AsuramId_get().Equal(J.I.zeroLong)&&!e.Id_get().Equal(s.Id_get()),o=G.j.Inst().GetSkillById(t,!1)
let d=!1
if(a.k.Inst_get().IsExistPkList(n.GetGameId())&&(d=!0),(i||l)&&!d&&"ALL"!=o.targetFilter)return re.y.inst.ClientSysMessage(110015),!1
if(e&&e.IsNewPlayer())return re.y.inst.ClientSysMessage(429048),!1}else n.Roletype_get(),D.s.monster
else if(l==le.j.SLAUGHTER_MODEL&&null!=n&&n.Roletype_get()==D.s.role){const e=n.Roleinfo_get()
if(e&&e.IsNewPlayer())return re.y.inst.ClientSysMessage(429048),!1}const o=G.j.Inst().GetPlayerSkillById(t,s)
if(null==o)return!1
1==o.looptype?this._skillModel.CurLoopSkill_set(t,s):this._skillModel.CurLoopSkill_set(0,s)
if(!i.CanChangeSkillState())return this._skillModel.NextSkill_set(t,s),!1
if(i.Isdead_get())return!1
if(this._skillModel.CurSkill_set(t,s),o.IsSelfFriendType()){const t=e.GetInst().CastSkillDecision(INS.skillModel.CurSkill_get(s),i,n)
t>1&&re.y.inst.ClientSysMessage(t)}else{if((n=m.Y.Inst.chooseTarget(o))&&o.GetHangVo().type==Ie.l.RUSH&&X.l.IsLineBlock(i,n)&&(n=null),
null==n)return re.y.inst.ClientSysMessage(105022),!1
i.addCastSkillAction()}return!0}PkCastSkill(e,t,i){if(null==t)return!1
const n=a.k.Inst_get().pkModel,s=t.Roleinfo_get(),l=m.Y.Inst.PrimaryRoleInfo_get().GoblinSign_get()
if(n==le.j.GUILD_MODEL&&null!=i){if(i.Roletype_get()==D.s.role){
const t=i.Roleinfo_get(),n=t.teamId_get().Equal(s.teamId_get())&&!s.teamId_get().Equal(J.I.zeroLong)&&!t.Id_get().Equal(s.Id_get()),r=t.AsuramId_get().Equal(s.AsuramId_get())&&!s.AsuramId_get().Equal(J.I.zeroLong)&&!t.Id_get().Equal(s.Id_get()),o=G.j.Inst().GetSkillById(e,!1)
let d=!1
if(a.k.Inst_get().IsExistPkList(i.GetGameId())&&(d=!0),(n||r)&&!d&&0==l&&"ALL"!=o.targetFilter)return re.y.inst.ClientSysMessage(110015),!1}else if(i.Roletype_get()==D.s.monster){}
}else if(n==le.j.SLAUGHTER_MODEL&&null!=i&&i.Roletype_get()==D.s.role){const e=i.Roleinfo_get()
if(e&&e.IsNewPlayer())return re.y.inst.ClientSysMessage(429048),!1}if(null!=i&&i.Roletype_get()==D.s.monster&&i.isGoblin()&&!i.isAttackedable())return re.y.inst.ClientSysStrMsg((0,
ge.T)("不能攻击该目标")),!1
if(l>0&&null!=i&&!i.isAttackedable())return re.y.inst.ClientSysStrMsg((0,ge.T)("不能攻击该目标")),!1
const r=G.j.Inst().GetPlayerSkillById(e,s)
if(null==r)return!1
1==r.looptype?this._skillModel.CurLoopSkill_set(e,s):this._skillModel.CurLoopSkill_set(0,s)
if(!t.CanChangeSkillState())return this._skillModel.NextSkill_set(e,s),!1
if(t.Isdead_get())return!1
if(this._skillModel.CurSkill_set(e,s),!r.IsSelfFriendType())return t.addPkNomalCastSkillAction(),!1
{const e=this.CastSkillDecision(INS.skillModel.CurSkill_get(s),t,i)
if(e>1)return re.y.inst.ClientSysMessage(e),!1}return!0}JudgeNightBuff(e,t,i){
if(null!=t&&t.Roletype_get()==D.s.role&&null!=INS.buffViewManager.model.getBuffByType("Night",t.objId)){
if(G.j.Inst().GetPlayerSkillById(e,i).targetFilter==He.b.ENEMY)return re.y.inst.ClientStrMsg(ie.r.SystemTipMessage,(0,ge.T)("不能攻击带夜间保护BUFF的玩家")),!0}return!1}
SendCastSkillMsg(e,t,i,n,s,l){const o=e.skillid
if(Me.S.getInst().InHang_get()&&2109==o)return M.Y.LogError((0,ge.T)("非正常释放瞬移技能")),!1
const h=m.Y.Inst.getCharacterById(t),u=l
if(u.isdead)return!1
const c=u.Roleinfo_get()
if(this.JudgeNightBuff(o,h,c))return!1
const I=Ge.L.Instance_get().GetTime()
if(this.sendtime=I,this.sendtime,this.lastsendtime,this.lastsendtime=I,null!=l){
l.isPrimary&&l.CurrentMachineState_get()==Te.k.Run?u.StopPathing():null!=u&&u.StopPathWithOutNoticeServer()
l.ShowRide_set(!1)}else l.StopPathing(),u.ShowRide_set(!1)
l.isPrimary&&(this.lastTargetId=t),null!=h&&h.isAttackedable()&&l.isPlayer&&Me.S.getInst().SetLastAttackTarget(l.Roleinfo_get().createIdx,h)
let _=null
_=new $.C,_.playerId=s,_.time=r.o.FromNumber(N.D.serverMSTime_get()),_.skillId=o,_.targetId=t,_.targetX=i,_.targetY=n,_.heading=l.GetDirection(),
null!=l&&l.isPrimary&&(a.k.Inst_get().attack_set(!0),x.C.Inst_get().ClearInterval(this._attackintervalId),
this._attackintervalId=x.C.Inst_get().SetInterval(this._degf_TimeChange,1e4,1),null!=h&&h.Roletype_get()==D.s.role&&(l.GetGameId().Equal(t)||(a.k.Inst_get().curAttackRoleId=t,
a.k.Inst_get().isRolePkTime_set(!0))))
const S=new te.T
S.skillId=o,S.level=e.skillLevel,S.effectorOid=l.GetGameId(),S.targetOid=t,S.targetX=i,S.targetY=n,S.playerId=s,S.isclient=!0,S.accumulateStage=ke.y.Inst.EndAccumulateStep
let g=!0
if((o==z.z.SKILL_ID_XCYN||e.delayTime>0)&&(g=!1),g&&this.SM_StartUseSkillHandler(S),e.IsDelaySkill()){const e=`${S.skillId}_${S.level}`
this.PlayDelayEffect(e,_.playerId)}if(e.isrushtype){const t=p.P.zero_get()
l.GetCurPos(t)
const i=new ee.Z
i.owner=l.GetGameId()
const n=new Q.q
n.skillId=o,n.skillLevel=e.skillLevel
let s=l.GetDirection(),a=e.pointDis,r=0
if(2109==e.skillid&&(s+=180,s>180&&(s-=360)),null!=h&&!h.isPrimary){if(h.Isdead_get())return!1
const e=h.GetPos()
l.rotateTo(e),s=d.p.CalYRotateDirectionByVector3DXZ(e,t)*he.U.RADIANS_TO_DEGREES,s+=90,s>180&&(s-=360),r=h.GetObjWidth(),r<2&&(r=2),a=p.P.Distance(t,e),a-=r}
const u=this.calPos(t.x,t.z,s,a,r)
if(0==u.x&&0==u.y)return M.Y.LogError((0,ge.T)("冲锋到00点了")),!1
Ge.L.Instance_get().ConnectedWithBlockLevel(t.x,t.z,u.x,u.y,Ge.L.s_bt_dynamic)||(u.x=.5*Ge.L.Instance_get().GetLastArrivalX()+.25,u.y=.5*Ge.L.Instance_get().GetLastArrivalY()+.25),
p.P.Recyle(t),n.endX=u.x,n.endY=u.y,i.motion=n,this.moveSkillLogic.OnMoveStarttMotionBefore(i),_.endX=u.x,_.endY=u.y}if(e.IsDelaySkill()){if(null!=h){const e=h.GetPos()
l.rotateTo(e)}this.HandleForbidSkillTime(e.alertTime,e.name)}return e.isAoYi&&M.Y.LogWarning(`释放奥义技能${e.skillid}`),V.C.Inst.F_SendMsg(_),!0}PlayDelayEffect(e,t){
const i=G.j.Inst().GetSkillByStrId(e),n=(0,g.Z)(m.Y.GetCharacterWithAutoRelive(t),L.s)
if(null!=n){if(0!=i.getReadyAttackId){this.PlaySkillEffect(null,i.getReadyAttackId,n.GetHandle(),0,J.I.zero3,J.I.zero3,0,0,null,!0)}if(0!=i.getReadyEffect){
this.PlaySkillEffect(null,i.getReadyEffect,n.GetHandle(),0,J.I.zero3,J.I.zero3,0,0,null,!0)}}}HandleForbidSkillTime(e,t){this.forbidenUseSkill=!0
let i=_T("（{0} 释放中...）")
i=u.M.Replace(i,"{0}",t),AsuramWarControl.Inst_get().OpenChariotProcess(e,i),this.ClearForbidenTime(),
this.forbidenTimeId=x.C.Inst_get().SetInterval(this.CreateDelegate(this.ResetForbidenSkill),e),T.i.Inst.RaiseEvent(K.g.FORBIDEN_SKILL_USE,this.forbidenUseSkill)}
ResetForbidenSkill(){this.ClearForbidenTime(),this.forbidenUseSkill=!1,T.i.Inst.RaiseEvent(K.g.FORBIDEN_SKILL_USE,this.forbidenUseSkill)}ClearForbidenTime(){
this.forbidenTimeId>-1&&x.C.Inst_get().ClearInterval(this.forbidenTimeId)}TimeChange(){a.k.Inst_get().attack_set(!1)}calPos(e,t,i,n,s){(i=180-i)<0&&(i+=360)
const l=de.V.TEMP_VECTOR2D_get(),a=i*he.U.DEGREES_TO_RADIANS,r=Math.cos(a),o=Math.sin(a)
let d=e,h=t
const u=.25
let c=0,I=-1,_=-1
for(;c<n;){d+=r*u,h+=o*u,c+=u
Oe.c.Instance_get().CanArrive(d,h)?I>0&&_>0&&(I=-1,_=-1):I<0&&_<0&&(_=h,I=d,n+=s),c>=n&&I>0&&_>0&&(d=I-r*u,h=_-o*u)}return l.Set(d,h),l}PhotoShotSkillDone(e){
T.i.Inst.RaiseEvent(K.g.SKILL_SHOW_SKILL_DISPLAYDONE)}hotCastSKill(e,t){null==t&&(t=!1)
const i=m.Y.Inst.PrimaryRole_get(),n=m.Y.Inst.PrimaryRoleInfo_get(),l=n.Skills_get()
if(!this.CanUseSkill(i,!0))return-1
if(l.LuaDic_ContainsKey(e)){if(INS.buffViewManager.model.HasCanNotAttackBuff(i.GetGameId(),!0))return-1
const a=l[e],r=G.j.Inst().GetPlayerSkillById(e,n),o=this.moveSkillLogic.DealMoveSkill(r,n.Id_get())
if(r.needTarget){let e=null
return e=(0,g.Z)(m.Y.Inst.CurTarget_get(),L.s),null==e||(0,g.t2)(m.Y.Inst.CurTarget_get(),E.B)||(0,
g.t2)(m.Y.Inst.CurTarget_get(),s.o)?e=this.ReselectTarget(r):this.CheckTargetDistance(r,i,e)||(e=this.ReselectTarget(r)),
this.JudgeNightBuff(r.skillid,e,n)?-1:INS.skillModel.CheckSkillTarget(r,i,e,!0)&&this.CastSkill(a.id,i,e)?1:-1}if(!this.moveSkillLogic.IsDealTeleportSkill(o,t)){let[e,t]=[0,0]
i.GetPosXZ(),null!=m.Y.Inst.CurTarget_get()?[e,t]=m.Y.Inst.CurTarget_get().GetPosXZ():[e,t]=i.GetPosXZ(),[e,t]=this.GetSkillDirection(r,i,e,t)
const s=h.GF.INT(1e3*i.getPublicCD())
return this.SendCastSkillMsg(r,m.Y.Inst.PlayerId_get(),e,t,m.Y.Inst.PlayerId_get(),i)?(me.N.Inst.AddCD(r.skillid,r.publicCDGroup,r.cd,s,fe.n.SKILL,n.Id_get()),1):-1}}return-1}
hotCastTransformSkill(e){const t=m.Y.Inst.PrimaryRole_get(),i=m.Y.Inst.PrimaryRoleInfo_get(),n=h.GF.INT(1e3*t.getPublicCD())
if(this.forbidenUseSkill)return-1
if(!t.CanChangeSkillState())return-1
if(e.needTarget){let s=null
s=(0,g.Z)(m.Y.Inst.CurTarget_get(),L.s)
if(m.Y.Inst.CheckTargetType(e,s)||(s=null),e.IsSelfFriendType()?(null==s||s.isAttackedable()||this.FriendTypeSkillAdapt(s.Roletype_get()))&&(s=t):null==s&&(s=this.ReselectTarget(e)),
null==s)return null!=e&&6100301==e.skillid&&re.y.inst.ClientSysMessage(131172),-1
if(!this.CheckTargetDistance(e,t,s))return this._skillModel.CurSkill_set(e.skillid,i),t.addCastSkillAction(),-1
if(!e.IsSelfFriendType()&&e.needTarget){if(null==s)return-1
if(s.IsInSafeArea())return-1
if(!s.isAttackedable())return-1}if(null==s)return null!=e&&6100301==e.skillid&&re.y.inst.ClientSysMessage(131172),-1
const l=new p.P
return e.areaSelector==xe&&s.GetCurPos(l),this.SendCastSkillMsg(e,s.GetGameId(),l.x,l.z,m.Y.Inst.PlayerId_get(),t)?(this.AddCD(e,n,fe.n.SKILL,i.Id_get()),1):-1}
return this.SendCastSkillMsg(e,m.Y.Inst.PlayerId_get(),0,0,m.Y.Inst.PlayerId_get(),t)?(this.AddCD(e,n,fe.n.SKILL,i.Id_get()),1):-1}AddCD(e,t,i,n){let s=0
s=e.IsDelaySkill()?e.cd+e.alertTime:e.cd,me.N.Inst.AddCD(e.skillid,e.publicCDGroup,s,t,i,n)}hotPkCastSKill(e,t){null==t&&(t=!1)
const i=m.Y.Inst.PrimaryRoleInfo_get(),n=m.Y.Inst.PrimaryRole_get()
if(!this.CanUseSkill(n,!0))return-1
const l=i.Skills_get()
if(l.LuaDic_ContainsKey(e)){const a=l[e],r=G.j.Inst().GetPlayerSkillById(e,i),o=this.moveSkillLogic.DealMoveSkill(r,i.Id_get()),d=this.GetDisLimit(i.Job_get())
if(r.needTarget){let e=null
return e=(0,g.Z)(m.Y.Inst.CurTarget_get(),L.s),null==e||(0,g.t2)(m.Y.Inst.CurTarget_get(),E.B)||(0,
g.t2)(m.Y.Inst.CurTarget_get(),s.o)?e=m.Y.Inst.hangAutoSelect(d,!0,!1,null,!0,!1):this.CheckPkTargetDistance(r,m.Y.Inst.PrimaryRole_get(),e,d)||(e=m.Y.Inst.hangAutoSelect(d,!0,!1,null,!0,!1)),
r.IsSelfFriendType()||null!=e&&m.Y.Inst.setCurTarget(e),this.JudgeNightBuff(r.skillid,e,i)?-1:this.PkCastSkill(a.id,n,e)?1:-1}if(!this.moveSkillLogic.IsDealTeleportSkill(o,t)){
const e=h.GF.INT(1e3*n.getPublicCD())
return this.SendCastSkillMsg(r,m.Y.Inst.PlayerId_get(),0,0,m.Y.Inst.PlayerId_get(),n)?(me.N.Inst.AddCD(r.skillid,r.publicCDGroup,r.cd,e,fe.n.SKILL,i.Id_get()),1):-1}}return-1}
ReselectTarget(e){const t=m.Y.Inst.chooseTarget(e)
return m.Y.Inst.CheckTargetType(e,t)?t:null}isTargetType(e){return e==D.s.monster||e==D.s.role}castDefaultSkill(){return M.Y.Log("TEST"),this.hotCastSKill(1e4),!0}checkCost(e,t){
const i=e.castCosts
if(null!=i)for(const[e,n]of(0,S.V5)(i.costs))if("Mp"==n.type&&t.CurrentMp_get()<n.value)return re.y.inst.ClientSysMessage(100506),!1
return!0}CheckCD(e,t){const i=t.Roleinfo_get()
return this.CheckRoleCD(e,i)}CheckRoleCD(e,t){if(null==t)return!1
return!me.N.Inst.isInCDing(e.skillid,e.publicCDGroup,t.Id_get())}CheckNeedChangeDis(e){return null!=e&&!_e.p.IsAreaSelector(e.areaSelector)}CheckTargetDistance(e,t,i,n){
if(null==n&&(n=!1),null==i)return!1
if(i.Isdead_get())return!1
const[s,l]=t.GetPosXZ(),[a,r]=i.GetPosXZ()
let o=be.A.DistanceXZ(s,0,l,a,0,r)
if(e.areaSelector!=Ve&&e.areaSelector!=xe){o=o-t.GetObjWidth()-i.GetObjWidth()}(0,g.t2)(i,B.u),o<0&&(o=0)
let d=e.pointDis+0
return n&&(d=e.PKdistance+0),!(o>d)}CheckPkTargetDistance(e,t,i,n){if(null==n&&(n=6),null==i)return!1
if(i.Isdead_get())return!1
let s=p.P.zero_get()
t.GetCurPos(s)
const l=de.V.TEMP_VECTOR2D_get()
l.x=s.x,l.y=s.z,p.P.Recyle(s),s=p.P.zero_get(),i.GetCurPos(s)
const a=de.V.TEMP_VECTOR2D_get()
a.x=s.x,a.y=s.z,p.P.Recyle(s)
let r=_.F.Distance(l,a)
return r=r-t.GetObjWidth()-i.GetObjWidth(),!(r>n)}showSpriteEffect(e,t,i,n,s){let l=0
if(l=null!=s?s.isDisplay?n.showcasterEffect:s.isPrimary?n.casterEffect:n.casterEffectOther:n.casterEffect,0!=l){const n=p.P.zero_get()
n.x=e,n.z=t,n.y=Oe.c.Instance_get().GetHeight(h.GF.INT(ue.a.eTrueWorld),e,t)
this.PlaySkillEffect(null,l,0,0,J.I.zero3,n,i,0,null,!0)
p.P.Recyle(n)}}getMouseDir(e){const t=p.P.zero_get(),i=UIUtilBridge.GetMousePosition()
Oe.c.Instance_get().RayMap(i.x,i.y,t),p.P.Recyle(i)
let n=d.p.CalYRotateDirectionByVector3DXZ(e,t)*he.U.RADIANS_TO_DEGREES
return p.P.Recyle(t),n-=90,n<0&&(n=360+n),n}getBuffDir(e,t){return this.getBuffDirXYZ(e.x,e.y,e.z,t.x,t.y,t.z)}getBuffDirXYZ(e,t,i,n,s,l){
let a=d.p.CalYRotateDirectionByVector3DXZ_XYZ(e,t,i,n,s,l)*he.U.RADIANS_TO_DEGREES
return a-=90,a<0&&(a=360+a),a}isPlayerInShot(e){const t=(0,g.Z)(e,B.u)
if(null==t)return!1
const i=t.Worldtype_get()
if(null==i){if(null!=t.Roleinfo_get())M.Y.LogError(`相机类型为空${t.Roleinfo_get().name}`)
else{let e=""
t.m_destroyed&&(e="m_destroyed:true"),M.Y.LogError(`相机类型为空${e}`)}return!1}return i>=ue.a.eSmallPhotoWorld&&i<=ue.a.eCustomWorld3}setPhotoShot(e,t,i){t&&(e._bOffsetStage=!0,
e._eOffsetWorldType=null!=i?LuaPhotoBridgeManager.Instance_get().GetStageWorldType(i):4,e._ElementCombineEnd=this._degf_PhotoShotSkillDone)}isSkillHide(e){
if(!this.isShowEffect)return!0
const t=(0,g.Z)(e,B.u)
return null==t||t.IsSelect_get()||t.isPlayer,!1}isSkillHideByPrimary(e){return!!this.isShowEffect||!!e.GetGameId().Equal(m.Y.Inst.PrimaryRoleInfo_get().Id_get())}
showSkillEffect(e,t,i,n,s,l,a,r,o,u,c,I,_,p){if(null==u&&(u=A.X.NONE),null==o&&(o=0),null==r&&(r=0),null==a&&(a=!0),null==l&&(l=!1),null==t)return[0,0,0]
this.moveSkillLogic.GetExistHandle(e.id,t.GetGameId())
let S=0,g=1,f=1,C=!1
if(!t.isShow_get())return[0,0,0]
t.isPrimary||t.isDisplay||(C=!0),S=t.GetHandle()
const[T,y,P]=t.GetPosXYZ()
let[w,R,D]=[0,0,0]
const L=m.Y.Inst.IsMultiPlayer(t.GetGameId())
let E=0,B=0
const M=e.needTarget,G=this.isPlayerInShot(t)||t.isDisplay
let O=t.GetDirection()
if(G&&(O=t.GetDirection()),B=O-90,B<0&&(B=360+B),M){if(null==i){let[i,l]=[0,0]
0!=e.trajectoryEffect?[i,l]=G?this.GetTargetPosion(t,0,0,3,O):this.GetTargetPosion(t,0,0,15,O):[i,l]=G?this.GetTargetPosion(t,0,0,1.5,O):this.GetTargetPosion(t,0,0,3,O),w=i,
R=Oe.c.Instance_get().GetHeight(h.GF.INT(ue.a.eTrueWorld),n,s),G&&(R=y),D=l,a&&t.rotateToXYZ(w,R,D,1e-5)}else if(E=i.GetHandle(),0!=E?([w,R,D]=i.GetPosXYZ(),
f=i.getAttackAnimationRate(e.skillFrame,e.skillFrameType),a&&t.rotateToXYZ(w,R,D,1e-5),
0==e.warningEffect&&(B=d.p.CalYRotateDirectionByVector3DXZ_XYZ(w,R,D,T,y,P)*he.U.RADIANS_TO_DEGREES)):i=null,null==i){[w,R,D]=[0,0,0]
let[i,l]=[0,0]
0!=e.trajectoryEffect?[i,l]=G?this.GetTargetPosion(t,0,0,3,O):this.GetTargetPosion(t,0,0,15,O):[i,l]=G?this.GetTargetPosion(t,0,0,1.5,O):this.GetTargetPosion(t,0,0,3,O),w=i,
R=Oe.c.Instance_get().GetHeight(h.GF.INT(ue.a.eTrueWorld),n,s),G&&(R=y),D=l,B=O-90,B<0&&(B=360+B),a&&t.rotateToXYZ(w,R,D,1e-5)}}else w=n,
R=p||Oe.c.Instance_get().GetHeight(h.GF.INT(ue.a.eTrueWorld),n,s),D=s,B=t.GetDirection()
if(e.areaSelector!=Ne&&e.areaSelector!=xe&&e.areaSelector!=Ve||0==w&&0==D||t.rotateToXYZ(w,R,D,1e-5),
null!=t.GetGameId()&&t.isPlayer&&(e.creatorType!=pe.z.PASSIVE?t.StopPathing():e.isrushtype&&I&&t.PauseMove()),!G&&this.isSkillHide(t))return this.PlayAttackAnim(e,t,i,B,L),[0,0,0]
0==r&&this.PlayAttackAnim(e,t,i,B,L,t.Worldtype_get())
let U=null,b=!1,F=0,k=0,v=0,N=1
l&&(w=n,D=s)
let V=0,x=0,H=new Be.E
H.source=t,H.effRole=t,H.target=i,V=null!=t?t.isDisplay?e.displayCasterEffectList.Count()>r?e.displayCasterEffectList[r]:e.showcasterEffect:t.isPrimary?e.casterEffect:e.casterEffectOther:e.casterEffect
let Z=e.showcasterEffect
if(0!=V)if(U=null,L&&(U=t._degf_onAEvent),b=e.IsCastAdd(),t.isDisplay&&(b=!1),b&&(g=t.getAttackAnimationRate(e.skillFrame,e.skillFrameType),N=g),x=t.isDisplay?Z:V,H.speedRate=N,
H.SetPoint(T,P),H.isReleaseFrame=!0,H.SetCfg(x),e.showEffectType==Ye.BUFF&&t.isDisplay)F=Ee.a.ins.showEffectByData(H)
else if(j.Z.IsSwordByAnim(t)){const i=t
F=this.PlaySwordSkill(e,i,H,null)}else F=Ee.a.ins.showEffectByData(H)
let Y=0
if(Y=null!=t?t.isDisplay?e.showtrajectoryEffect:t.isPrimary?e.trajectoryEffect:e.trajectoryEffectOther:e.trajectoryEffect,0!=Y){U=null,U=t._degf_onAEvent
let n=new Be.E
if(n.source=t,n.effRole=t,n.target=i,n.SetPoint(T,P),n.isReleaseFrame=!0,j.Z.IsArcherByAnim(t)){const s=t
2==e.quicken&&(n.speedRate=g),n.SetCfg(Y),k=this.PlayArcherSkill(e,s,n,null,i)}else b=e.IsTrajectoryAdd(),t.isDisplay&&(b=!1),N=1,
b&&(g=t.getAttackAnimationRate(e.skillFrame,e.skillFrameType),N=g),null!=i||C?n.SetCfg(Y):n.SetCfg(e.showtrajectoryEffect),n.speedRate=N,k=Ee.a.ins.showEffectByData(n)}let W=0
W=null!=t?t.isDisplay?e.showhitEffect:t.isPrimary?e.hitEffect:e.hitEffectOther:e.hitEffect
let K=new Be.E
return K.source=t,K.effRole=i,K.target=i,K.SetPoint(w,D),K.isReleaseFrame=!0,0==W||e.isMagic||(U=null,L&&(U=t._degf_onAEvent),null!=i||C?K.SetCfg(W):K.SetCfg(e.showhitEffect),
b=e.IsHitAdd(),t.isDisplay&&(b=!1),N=1,b&&(g=t.getAttackAnimationRate(e.skillFrame,e.skillFrameType),N=g),K.speedRate=g,v=Ee.a.ins.showEffectByData(K)),[F,k,v]}CDHandler1(e,t){
const i=(0,g.Z)(t,B.u)
null!=i&&i.SetHeadUIVisible(!1)}CDHandler2(e,t){const i=(0,g.Z)(t,B.u)
null!=i&&i.SetHeadUIVisible(!0)}ElementCombineEnd(e){}PlayAttackAnim(e,t,i,n,s,l){let a=null,r=null,o=null,d=0
const[h,u,c]=t.GetPosXYZ(),I=t.getAttackAnimationRate(e.skillFrame,e.skillFrameType)
let _=1
if(null!=i&&(d=i.GetHandle()),t.GetHandle()==d&&(_=I),(0,g.t2)(t,B.u)){const i=t
a=this.GetCastAnimationId(i,e),X.l.IsEmptyStr(a)||(r=null,o=null,i.elementID=a,i.skillFrame=e.skillFrame,i.skillFrameType=e.skillFrameType,i.SetDirection(n),t.changeToCastSkill(a))
}else((0,g.t2)(t,Ae._)||t.Roletype_get()==D.s.pet)&&(t.Cfg_get().isHuman?(a=e.SingleAttackId,t.elementID=a,t.skillFrame=e.skillFrame,t.skillFrameType=e.skillFrameType,
t.SetDirection(n),t.changeToCastSkill(a)):(a=e.SingleAttackId,t.SetDirection(n),console.log("PlayAttackAnim angle "+n+" attackId "+a),t.changeToCastSkill(a)))
return 0}resetAe(){}showMoveSkillEffect(e,t,i,n,s,l){const a=this.moveSkillLogic.GetExistHandle(e.id,t.GetGameId())
let r=0
const o=p.P.zero_get()
if(null==t)return
r=t.GetHandle(),t.GetCurPos(o)
const u=m.Y.Inst.IsMultiPlayer(t.GetGameId())
let c=0
const I=p.P.zero_get()
let _=0,S=0
I.x=n,I.y=Oe.c.Instance_get().GetHeight(h.GF.INT(ue.a.eTrueWorld),n,s),I.z=s
e.needTarget?null==i?(S=t.GetDirection()-90,S<0&&(S=360+S)):(c=i.GetHandle(),_=i.GetDirection()-90,t.rotateTo(I,1e-5),
S=d.p.CalYRotateDirectionByVector3DXZ(I,o)*he.U.RADIANS_TO_DEGREES):(S=t.GetDirection()-90,S<0&&(S=360+S)),
"SINGLE"!=e.areaSelector&&"POSITION_RANGE"!=e.areaSelector&&"TARGET_RANGE"!=e.areaSelector||t.rotateTo(I,1e-5),
t.GetGameId().Equal(m.Y.Inst.PrimaryRole_get().GetGameId())&&t.StopPathing()
let f=null,C=0
C=this.PlaySkillEffect(t,l,r,c,o,I,S,_,null,!0,f,null),0!=C&&null!=a&&(a.casterEffectHandle=C)
let T=0
if((0,g.t2)(t,B.u)){T=this.GetCastAnimationId(t,e),f=null
let i=!1
u&&(f=t._degf_onAEvent,i=!0),C=Le.X.Inst.PlaySkillElement(T,r,c,o,I,S,_,null,i,f,null),t.changeToCastSkill(0)}else(0,g.t2)(t,Ae._)&&(T=e.SingleAttackId,t.changeToCastSkill(T))
p.P.Recyle(o),p.P.Recyle(I)}GetTrajectoryEffect(){return""}releaseNextSkill(e){this._skillModel.NextSkill_set(0,e.Roleinfo_get())}SM_StateHandler(e){const t=e
null!=t&&m.Y.Inst.SM_StateHandler(t)}SM_UseSkillHandler(e){const t=e
if(0!=t.code)if(Se.s.Info(`SM_UseSkill code ${t.code}`),t.code==Ue.k.SKILL_TARGET_NOT_EXIST){
null!=m.Y.Inst.getMonsterById(t.pointTargetId)&&m.Y.Inst.SM_RemoveHandle(t.pointTargetId)}else re.y.inst.ClientSysMessage(t.code)}SM_StartUseSkillHandler(e){
const t=e,i=t.playerId,n=G.j.Inst().GetSkillByIdLevel(t.skillId,t.level),s=m.Y.Inst
if(1212!=n.skillid&&null!=n){const e=(0,g.Z)(s.GetCharacterWithAutoRelive(t.effectorOid),L.s),l=(0,g.Z)(s.GetCharacterWithAutoRelive(t.targetOid),L.s)
if(null!=e&&e.isPrimary&&!t.isclient&&n.creatorType!=pe.z.PASSIVE)if(n.skillid==z.z.SKILL_ID_XCYN){const t=h.GF.INT(1e3*e.getPublicCD())
me.N.Inst.AddCD(n.skillid,n.publicCDGroup,n.cd,t,fe.n.SKILL,e.GetGameId())}else{if(!n.IsDelaySkill())return
this.ResetForbidenSkill()}if(null!=e&&n.creatorType!=pe.z.PASSIVE&&t.effectorOid.Equal(i)&&e.StopPathing(),(0,g.t2)(e,Ae._)&&e.Isstop_get(),
null!=e&&this.moveSkillLogic.IsTeleportSkill(n)&&m.Y.Inst.CurTarget_get()==e&&m.Y.Inst.setCurTarget(null),null!=e&&this.moveSkillLogic.IsMoveSkill(n)){
if(e.GetGameId().Equal(m.Y.Inst.PlayerId_get())){h.GF.INT(1e3*e.getPublicCD())}this.moveSkillLogic.DealSkillEffect(n,t)}else if(n.creatorType!=pe.z.AreaMagic||(0,
g.t2)(e,SpiritCharacter)){if(null!=e){let i=!1
i=n.areaSelector==Ve||n.areaSelector==xe,e.isPrimary&&(i=!1),this.showSkillEffect(n,e,l,t.targetX,t.targetY,i,!0,0,t.accumulateStage,t.nextUseWeakShootingIdx,t.param)}
}else this.ShowAreaMagicEffect(n,t.targetX,t.targetY,e)}}ShowAreaMagicEffect(e,t,i,n){const s=p.P.zero_get()
s.x=t,s.y=Oe.c.Instance_get().GetHeight(h.GF.INT(ue.a.eTrueWorld),t,i),s.z=i
let l=0
if(l=null!=n?n.isDisplay?e.showcasterEffect:n.isPrimary?e.casterEffect:e.casterEffectOther:e.casterEffect,0==l)return
this.PlaySkillEffect(null,l,0,0,J.I.zero3,s,0,0,null,!0)
p.P.Recyle(s)}queryHpHandler(e){const t=e
ElementBridgeManager.DeleteElementCombine(t,!0)}PlayBloodEffect(e,t,i,n){let s=!1
const l=m.Y.Inst.GetPetById(e.effectorOid)
null!=l&&m.Y.Inst.IsMultiPrimaryId(l.ownerId)&&(s=!0)
let a=!1
const r=m.Y.Inst.getCharacterById(e.effectorOid)
if(null!=r&&r.Roletype_get()==D.s.role&&null!=r.Roleinfo_get()&&null!=r.Roleinfo_get().masterObjId&&m.Y.Inst.IsMultiPrimaryId(r.Roleinfo_get().masterObjId)&&(a=!0),
!(m.Y.Inst.IsMultiPrimaryId(e.effectorOid)||m.Y.Inst.IsMultiPrimaryId(e.effectList[t].targetOid)&&m.Y.Inst.IsMultiPrimaryId(n.objId)||e.effectList[t].label==ve.$.FanShe||e.effectList[t].label==ve.$.Parry||s||a))return
const o=e.effectList[t].damage
if(0==o&&e.effectList[t].label!=ve.$.Miss&&e.effectList[t].label!=ve.$.Invincibility)return
let d=!1
if((0,g.t2)(n,Pe.w)){const e=n
d=m.Y.Inst.IsMultiPrimaryId(e.info.ownerId)}if(0!=e.skillId){const l=G.j.Inst().GetSkillByIdLevel(e.skillId,e.level)
let a=180
const r=new c.Z,h=We.new()
if(h.msg=e.Clone(),h.primaryRole=i,h.t_character=n,null!=n&&(h.targetId=n.GetGameId()),h.ismysum=d,h.isMyPet=s,h.i=t,e.isSplitValue){h.value=Math.floor(o/2),r.Add(h),
r.Add(h.Clone())
const e=l.delaytimeList
if(""!=l.mutilHurt&&null!=e&&e.Count()>1){const t=e.Count()
a=2*e[t-1]-e[t-2]}}else h.value=o,r.Add(h)
this.ShowDoubleAttackBlood(0,r[0]),r.Count()>1&&x.C.Inst_get().SetIntervalForParm(this._degf_ShowDoubleAttackBlood,a,1,r[1])}else{
const l=f.b.Ins_get().GetNumInfo(o,e.effectList[t].label,n.isMultiPrimary||d,s,e.curUseWeakShootingIdx)
this.PlayEffect(e.effectList[t].label,l,i,n,n.isMultiPrimary||d)}}ShowDoubleAttackBlood(e,t){let i=t
const n=i.msg
if(null==n)return
const s=i.value,l=i.primaryRole,a=i.t_character,r=i.ismysum,o=i.isMyPet,d=i.i
let u={}
const c=G.j.Inst().GetSkillByIdLevel(n.skillId,n.level)
if(""!=c.mutilHurt&&s>0){const e=c.delaytimeList,t=c.damageList
let i=0,I=0,_=0
for(;_<e.Count();){let p=e[_]
_>0&&(i=p-e[_-1])
const S=s*t[_]/1e4
if(0!=h.GF.INT(S)){const e=new R
e.isuser=a.isMultiPrimary||r,u=f.b.Ins_get().GetNumInfo(h.GF.INT(S),n.effectList[d].label,e.isuser,o,n.curUseWeakShootingIdx),e.label=this.GetLabel(n.effectList[d].label,e.isuser),
e.strs=u,e.primaryRole=l,e.t_character=a,e.targetId=null!=a?a.GetGameId():null,e.mutilHurtOffset=.1*-_
const t=1/l.getAttackAnimationRate(c.skillFrame,c.skillFrameType)
i=h.GF.INT(i*t),0!=i&&i<this.MinBooldFlyGap_get()&&(i=this.MinBooldFlyGap_get()),p=I+i,
p<=0?this.ShowMutilBlood(0,e):x.C.Inst_get().SetIntervalForParm(this._degf_ShowMutilBlood,p,1,e)}I=p,_+=1}
}else u=f.b.Ins_get().GetNumInfo(s,n.effectList[d].label,a.isMultiPrimary||r,o,n.curUseWeakShootingIdx),this.PlayEffect(n.effectList[d].label,u,l,a,a.isMultiPrimary||r)
q.Q.Inst().Recycle("DoubleAttackHurtVo",i),i=null}ShowMutilBlood(e,t){const i=t
if(null!=i.targetId){if(null==m.Y.Inst.getCharacterById(i.targetId,!0))return}this.PlayEffect(i.label,i.strs,i.primaryRole,i.t_character,i.isuser,i.mutilHurtOffset)}
PlayHeadFlutter(e,t,i,n){const s=f.b.Ins_get().GetNumInfo(e,t,n.isplayer)
this.PlayEffect(t,s,i,n,n.isplayer)}GetLabel(e,t){return t&&0!=e&&e!=ve.$.Heal&&102!=e&&103!=e&&e!=ve.$.SiegeScoreUp&&e!=ve.$.Parry&&e!=ve.$.BreakShield&&(e=100),e}
PlayEffect(e,t,i,n,s,l){if(null==l&&(l=0),ne.x.Instance.isChangeing||null==i)return
let a=1,[r,o,d]=i.GetPosXYZ(),[h,u,c]=n.GetPosXYZ();[r,o,d]=y.x.Instance_get().WorldToScreenPoint2XYZ(r,o,d),[h,u,c]=y.x.Instance_get().WorldToScreenPoint2XYZ(h,u,c)
const I=h-r
s?(a=1,e=this.GetLabel(e,s)):a=I>0?2:1,null!=n.MainRole_get()&&(s||(l=0),f.b.Ins_get().SetFlowEffect(e,t,n.MainRole_get(),l,a,n))}GetRandomPos(e,t,i){let n=0,s=0
return n=e,s=i,[n,t,s]}SM_EndUseSkillHandler(e){const t=e
this.nextUseWeakShootingIdx=t.nextUseWeakShootingIdx,this.skillmsgbuff.add(t)}Show_EndUseSkill(e){const t=m.Y.Inst.getCharacterById(e.effectorOid),i=e.effectList.Count()
let n=null
if(0!=e.skillId&&(n=G.j.Inst().GetSkillByIdLevel(e.skillId,e.level)),null!=n&&null!=t&&(t.isMultiPrimary&&t.Roletype_get()==D.s.player||t.Roletype_get()==D.s.monster)){
e.targetOid.ToNum()}this.curAttackMeTargetId=null
const s=e.Clone()
this.time=N.D.serverTime_get()
let l=0
for(;l<i;){const e=Ze.GetPoolData(s,n,t,l)
this.delaySkillDic.LuaDic_ContainsKey(s.skillId)?(1212==n.skillid&&x.C.Inst_get().SetIntervalForParm(this._degf_ShowChainLightningEffect,this.delaySkillDic[s.skillId]*l,1,e.Clone()),
x.C.Inst_get().SetIntervalForParm(this._degf_DoShowEffect,this.delaySkillDic[s.skillId]*l,1,e)):this.DoShowEffect(null,e),l+=1}}DoShowEffect(t,i){
const n=i.msg,s=i.index,l=i.cfg,a=i.caster
Ze.Recycle(i)
const r=m.Y.Inst.PrimaryRole_get()
if(null==r)return
if(!e.Inst.isShowEffect)return
const o=n.effectList[s]
let h=0
null!=n.uHandleList&&(h=n.uHandleList[s])
const u=m.Y.Inst.getCharacterById(o.targetOid,!0)
if(null!=u&&(0==h||h==u.GetFakerId())){if(o.targetOid.Equal(m.Y.Inst.PlayerId_get())&&m.Y.Inst.handleHatred(n.effectorOid,o.damage),0!=n.skillId){
if(null!=l&&0!=l.attackedEffect&&o.label!=ve.$.Heal){let e=0
null!=a&&(e=Re.e.GetACRotation(a)),this.PlayHitEffect(l.attackedEffect,o.targetOid,e)}
u.Roletype_get()==D.s.monster&&(u.isBoss()?null!=a&&a.isPrimary&&a.Roletype_get()==D.s.player&&(l.bloodBlockArr.Count(),
oe.D.Inst_get().fightTime=N.D.serverTime_get()):this.PlaySkillEffect(u,102000400,0,u.GetHandle(),J.I.zero3,J.I.zero3,0,0))}let[e,t,i]=u.GetPosXYZ()
if(this.PlayBloodEffect(n,s,r,u),u.Roletype_get()==D.s.monster){const e=(0,g.Z)(u,Ae._),t=e.Info_get()
if(null!=t&&null!=e&&e.Cfg_get()&&e.isUpdateBlood_get()&&!e.Cfg_get().isSettledTime&&!e.IsGoldWarBoss()){let i=t.CurrentHp_get()
i-=o.damage,i=d.p.Max(i,0),o.fakeHp||t.CurrentHp_set(i),e.Cfg_get().objectType!=Ce.b.MONSTER_BOSS&&e.Cfg_get().objectType!=Ce.b.MAZE_CALL_BOSS||0!=t.CurrentHp_get()&&null==W.o.Inst_get().boss||Y.t.Inst().UpdateHpBar(t)
}}if(u.Roletype_get()==D.s.role){const e=u.Roleinfo_get()
if(null!=e){let t=e.CurrentHp_get(),i=e.CurrentShield_get()
o.label==ve.$.Heal?t==o.curHp&&(t+=o.damage,t=d.p.Min(t,e.MaxHp_get()),e.CurrentHp_set(t)):o.label==ve.$.BreakShield?(i-=o.damage,i=d.p.Max(i,0),
e.CurrentShield_set(i)):o.label!=ve.$.Parry&&(t-=o.damage,t=d.p.Max(t,0),o.fakeHp||e.CurrentHp_set(t))}}
if(u.Roletype_get()!=D.s.player&&null!=a&&a.isPlayer)o.label!=ve.$.Heal&&0!=o.damage&&se.k.inst.Attack(u)
else if(null!=a&&!a.isPlayer&&(m.Y.Inst.IsMultiPlayer(u.GetGameId())||u.IsFakePkFriend())&&(a.Roletype_get()!=D.s.role&&a.Roletype_get()!=D.s.pet||(ae.U.Inst_get().AddPKTarget(n.effectorOid),
we.e.inst_get().ChangePKWeight(n.effectorOid,this.OldPkMeTargetId),this.OldPkMeTargetId=n.effectorOid),
a.Roletype_get()==D.s.monster&&a.isBoss()&&(oe.D.Inst_get().fightTime=N.D.serverTime_get()),this.curAttackMeTargetId=n.effectorOid,0!=n.skillId)){
const e=G.j.Inst().GetSkillByIdLevel(n.skillId,n.level)
null==e||e.targetFilter==He.b.FRIEND_AND_SELF||e.targetFilter==He.b.WE||e.targetFilter==He.b.SELF||e.targetFilter==He.b.FRIEND||n.effectorOid.Equal(m.Y.Inst.PlayerId_get())||o.label!=ve.$.Heal&&0!=o.damage&&(se.k.inst.attackEd(a),
se.k.inst.attackSave(a))}if(INS.buffViewManager.hasBuffByEffectId(m.Y.Inst.PrimaryRoleInfo_get().Id_get(),m.Y.Inst.PrimaryRoleInfo_get().Id_get(),100200502)&&u.isPrimary&&null!=a){
const[n,s,l]=a.GetPosXYZ(),r=this.getBuffDirXYZ(n,s,l,e,t,i)
this.PlaySkillEffect(a,100200503,u.GetHandle(),a.GetHandle(),J.I.zero3,J.I.zero3,r,0,null,!0,null,null)}let h=0
if(2004==n.skillId||2005==n.skillId){if(u.Roletype_get()==D.s.monster){const e=u
if(e.isNormal()&&0==e.StandFixAi()&&(h=u.getHP(),h>0)){null!=a&&(u.saveheilongbodirect=u.GetDirection(),
this.PlaySkillEffect(a,102000200,a.GetHandle(),u.GetHandle(),J.I.zero3,J.I.zero3,0,0,null,!0,null,e._degf_onHeilongbo))}}}else if(null!=o.beatBack){if(h=u.getHP()-o.damage,h>0){
u.setPos(o.beatBack.x,o.beatBack.y),[e,t,i]=u.GetPosXYZ()
const[s,l,r]=[o.beatBack.dx,t,o.beatBack.dy]
u.MainRole_get().ReSetEvent()
let h=De.k.BEAT_BACK2
if(null!=a){u.Roletype_get()!=D.s.player&&u.Roletype_get()!=D.s.role||(h=De.k.ROLE_BE_HIT_BACK,u.Isdead_get()&&(h=De.k.ROLE_BE_HIT_FLY_DIE),u.forceStopPathing(!0),
u.rotateTo(a.GetPos()))
let o=0
if(1103==n.skillId?o=110301:1010==n.skillId?o=101001:2009==n.skillId&&(o=200901),0==o)a.Isdead_get()||this.PlaySkillEffectXYZ(a,h,a.GetHandle(),u.GetHandle(),s,l,r,e,t,i)
else{const n=ElementCfgManager.GetInst().GetElementBlendCount(o)
if(0!=n){let h=d.p.FastDistanceXYZ(s,l,r,e,t,i)
h=Math.sqrt(h)
const I=h/n,_=new c.Z
let p=1
for(;p<=n;){const e=new LuaElementCombineLocation
e._uElementCombineID=0,e._uHandleSrc=a.GetHandle(),e._uHandleDest=u.GetHandle()
const i=I*p,[n,o]=this.GetTargetPosion(u,0,0,i,a.GetDirection())
if(1==p)e._vSrcPosx=s,e._vSrcPosy=l,e._vSrcPosz=r
else{const i=I*(p-1),[n,s]=this.GetTargetPosion(u,0,0,i,a.GetDirection())
e._vSrcPosx=n,e._vSrcPosy=t,e._vSrcPosz=s}e._vDestPosx=n,e._vDestPosy=t,e._vDestPos=curposy,_.Add(e),p+=1}ElementBlendMgr.GetInst().PlayBlendElement(o,_)}}}}
}else 0!=n.skillId&&null!=u&&(u.Roletype_get()==D.s.monster&&u.isNormal()&&(u.inMove()||null!=u.Cfg_get()&&u.Cfg_get().isHuman||u.changeToHit()),
u.Roletype_get()==D.s.monster&&u.isBoss()&&(u.inMove()||null!=u.Cfg_get()&&u.Cfg_get().isBossHit&&u.changeToHit()))}}ShowChainLightningEffect(e,t){let i=null,n=null
if(0==t.index)i=m.Y.Inst.getCharacterById(t.msg.targetOid,!0)
else{const e=t.msg.effectList[t.index-1]
if(null==e)return
i=m.Y.Inst.getCharacterById(e.targetOid,!0)}const s=t.msg.effectList[t.index]
n=m.Y.Inst.getCharacterById(s.targetOid,!0),J.I.cal2Vec0=n.GetPosV2(),this.showSkillEffect(t.cfg,i,n,J.I.cal2Vec0.x,J.I.cal2Vec0.y,!0),Ze.Recycle(t)}GetCastAnimationId(e,t){
return null==e||null==e.Roleinfo_get()||j.Z.IsArcher(e.Roleinfo_get().Job_get()),t.SingleAttackId}getSkillEndStruct(e,t){for(const[i,n]of(0,
S.V5)(this.m_skillEndDic))if(n.casterId.Equal(e)&&n.skillid==t)return n
return null}SM_InterruptSkillHandler(e){const t=e,i=G.j.Inst().GetSkillById(t.skillId)
t.effectorOid.Equal(m.Y.Inst.PlayerId_get())&&m.Y.Inst.PrimaryRole_get().ChangeToStand(),null!=i&&me.N.Inst.ClearCD(t.skillId,i.publicCDGroup,t.effectorOid),
V.C.Inst.Recycle_MessagePools(t)}SM_ClearSkillCdHandler(e){const t=e,i=G.j.Inst().GetSkillByIdLevel(t.skillId,t.skillLevel)
null!=i&&me.N.Inst.ClearCD(t.skillId,i.publicCDGroup,t.playerId)}useDefaultSkill(){const e=m.Y.Inst.PrimaryRoleInfo_get()
if(0==e.GetChariotId())0==this._skillModel.CurLoopSkill_get(e)&&this._skillModel.CurLoopSkill_set(this.getDefaultSkill(),e),
0!=this._skillModel.CurLoopSkill_get(e)&&this.CastSkill(this._skillModel.CurLoopSkill_get(e),m.Y.Inst.PrimaryRole_get())
else{const e=AsuramWarControl.Inst_get().GetDefaultChariotSkill()
null!=e&&this.hotCastTransformSkill(e)}}setDefaultSkill(){this._skillModel.CurLoopSkill_set(this.getDefaultSkill(),m.Y.Inst.PrimaryRoleInfo_get())}getDefaultSkill(){
const e=m.Y.Inst.PrimaryRoleInfo_get().Skills_get()
let t=h.GF.INT32_MAX_VALUE_get()
for(const[i,n]of(0,S.V5)(e)){const e=G.j.Inst().GetSkillById(n.id)
1==e.looptype&&e.skillid<t&&(t=e.skillid)}return t!=h.GF.INT32_MAX_VALUE_get()?t:0}getAngle(e,t){const i=e-t
let n=180*Math.atan2(i.z,i.x)/Math.pi_get()
return n=90-n,n<0&&(n=360+n),n}CM_AddShortcutKeyHandler(e,t){const i=new CM_AddShortcutKey
return i.key=e,i.value=t,V.C.Inst.F_SendMsg(i),!0}CM_DelShortcutKeyHandler(e){const t=new CM_DelShortcutKey
return t.key=e,V.C.Inst.F_SendMsg(t),!0}CM_ExchangeShortcutKeyHandler(e,t){const i=new CM_ExchangeShortcutKey
return i.from=e,i.to=t,V.C.Inst.F_SendMsg(i),!0}CanUseSkill(e,t){if((0,g.t2)(e,INS.Player)){const i=e.GetStates()
if(C.Q.CanUseSkill(i,null,t))return!0}return!1}SM_ShortcutKeyHandler(e){P.T.GetInst().keysMap=e.keysMap,T.i.Inst.RaiseEvent(w.g.SHORTCUT_CHANGE,!0)}CastEmenyTypeSkill(t,i,n,s,l,a){
null==a&&(a=!0)
const o=n,d=o.Roleinfo_get()
if(i.needTarget&&null==t){const[e,t,s]=this.GetSkillDirectionNotarget(i,n)
M.Y.Log((0,ge.T)("施法者状态:")+n.CurrentMachineState_get(),!0)
const l=h.GF.INT(1e3*o.getPublicCD())
return this.SendCastSkillMsg(i,r.o.ZERO,e,s,d.Id_get(),n)?(this.AddCD(i,l,fe.n.SKILL,d.Id_get()),1):-1}if(null==t)return 105013
if((null==t||t.Isdead_get()||!t.isAttackedable())&&"ALL"!=i.targetFilter)return-1
let u=r.o.ZERO
if(null!=t&&(u=t.GetGameId()),!e.GetInst().CheckTargetDistance(i,n,t)&&a){const e=p.P.zero_get()
n.GetCurPos(e)
const s=p.P.zero_get()
t.GetCurPos(s)
const l=0
let a=i.pointDis+l
return a-=.1,t.Isdead_get()||(o.reachPoint(s,e,a,null,null,2),t.isAttackedable()&&Me.S.getInst().SetLastAttackTarget(o.Roleinfo_get().createIdx,t)),p.P.Recyle(e),p.P.Recyle(s),0}
let[c,I]=this.GetSkillDirection(i,n,s,l)
if(i.IsDelaySkill()&&null!=t){const e=new p.P
t.GetCurPos(e),c=e.x,I=e.z}const _=h.GF.INT(1e3*o.getPublicCD())
return this.SendCastSkillMsg(i,u,c,I,o.Roleinfo_get().Id_get(),n)?(this.AddCD(i,_,fe.n.SKILL,d.Id_get()),1):-1}GetSkillDirection(e,t,i,n){if(_e.p.IsAreaSelector(e.areaSelector)){
const[e,s]=d.p.CalVector3DXYZByYRotateXZ(t.GetDirection()),[l,a]=t.GetPosXZ()
i=l-e,n=a-s}return[i,n]}GetSkillDirectionNotarget(e,t){let i=0,n=0,s=0,[l,a]=[0,0]
const r=this.isPlayerInShot(t)||t.isDisplay,[o,d,u]=t.GetPosXYZ()
let c=t.GetDirection()
return r&&(c=t.GetDirection()),0!=e.trajectoryEffect?[l,a]=r?this.GetTargetPosion(t,0,0,3,c):this.GetTargetPosion(t,0,0,15,c):[l,a]=r?this.GetTargetPosion(t,0,0,1.5,c):this.GetTargetPosion(t,0,0,3,c),
i=l,n=Oe.c.Instance_get().GetHeight(h.GF.INT(ue.a.eTrueWorld),o,u),r&&(n=d),s=a,[i,n,s]}GetTargetPosion(e,t,i,n,s){
const[l,a]=d.p.CalVector3DXYZByYRotateXZ(s),[r,o]=[l*n,a*n],[h,u]=e.GetPosXZ()
t=h-r,i=u-o
de.V.TEMP_VECTOR2D_get()
return[t,i]}GetCanMoveTargetPosionByDirXYZ(e,t,i,n,s){let[l,a]=d.p.CalVector3DXYZByYRotateXZ(s)
l*=n,a*=n
let[r,o]=[0,0],[h,u,c]=[0,0,0],I=1,_=!1
for(;I>=0;){if(r=l*I,o=a*I,h=e-r,c=i-o,u=t,_=Oe.c.Instance_get().CanArriveByPosXYZ(h,u,c),_)return[h,u,c]
I-=.1}return[e,t,i]}GetTargetPositionDir(e,t,i){const n=d.p.CalVector3DXYZByYRotate(i),s=Vector3DProxy.Mul(n,t),l=e.x-s.x,a=e.y-s.z,r=de.V.TEMP_VECTOR2D_get()
return r.x=l,r.y=a,p.P.Recyle(n),p.P.Recyle(s),r}CastSelfFriendTypeSkill(e,t,i,n,s){(null==e||e.isAttackedable()||this.FriendTypeSkillAdapt(e.Roletype_get()))&&(e=i)
let l=r.o.ZERO
null!=e&&(l=e.GetGameId())
const[a,o]=this.GetSkillDirection(t,i,n,s),d=i.Roleinfo_get()
i.StopPathing()
const u=h.GF.INT(1e3*i.getPublicCD())
return this.SendCastSkillMsg(t,l,a,o,d.Id_get(),i)?(me.N.Inst.AddCD(t.skillid,t.publicCDGroup,t.cd,u,fe.n.SKILL,d.Id_get()),1):-1}FriendTypeSkillAdapt(e){return e==D.s.npc}
CastSkillDecision(t,i,n,s){if(null==s&&(s=!0),null==i)return-1
if(i.Isdead_get())return 100508
const l=i.Roleinfo_get(),a=G.j.Inst().GetPlayerSkillById(t,l)
if(null!=a){if(!e.GetInst().checkCost(a,l))return-1
if(!e.GetInst().CheckCD(a,i))return 105032
r.o.ZERO
const t=0,o=0
let d=0
return a.needTarget&&(d=a.IsSelfFriendType()?this.CastSelfFriendTypeSkill(n,a,i,t,o):this.CastEmenyTypeSkill(n,a,i,t,o,s)),d}return-1}
PlaySkillEffectXYZ(e,t,i,n,s,l,a,r,o,d,h,u,c,I,_,p,S,g,m,f,C){return null==f&&(f=!0),null==m&&(m=1),null==g&&(g=1),null==S&&(S=1),null==I&&(I=!1),null==u&&(u=0),null==h&&(h=0),
null==e||e.isShow_get()?Le.X.Inst.PlaySkillElementXYZ(t,i,n,s,l,a,r,o,d,h,u,c,I,_,p,S,g,m,null,f,C):0}PlaySkillEffect(e,t,i,n,s,l,a,r,o,d,h,u,c,I,_,p,S){
return this.PlaySkillEffectXYZ(e,t,i,n,s.x,s.y,s.z,l.x,l.y,l.z,a,r,o,d,h,u,c,I,_,p,S)}PlayHitEffect(e,t,i){const n=m.Y.Inst.getCharacterById(t)
if(null==n)return
const s=(0,g.Z)(n,L.s)
if(null!=s){s.GetHandle()
const[t,i,n]=s.GetPosXYZ()
let l=new Be.E
l.source=s,l.target=s,l.effRole=s,l.SetCfg(e),Ee.a.ins.showEffectByData(l)}}DisplayHitEffect(e,t){if(0!=e){let i=null
const n=(0,g.Z)(t,L.s)
if(null!=n){const t=n.GetHandle(),s=p.P.zero_get()
return n.GetCurPos(s),i=Le.X.Inst.ConstuctSkillLocation(e,0,t,J.I.zero3,s),p.P.Recyle(s),Le.X.Inst.PlaySkillLocation(i,null)}}return 0}ClearPlayerMoveHandle(){
null!=this.moveSkillLogic&&this.moveSkillLogic.ClearPlayerMoveHandle()}clearRushElement(){
0!=this.rushHandleId&&LuaElementBridgeManager.Instance_get().DeleteElementCombine(this.rushHandleId,!1)}PlaySwordSkill(e,t,i,n){if(10003==e.skillid||e.skillid,10001==e.skillid){
const e=this.getSwordElectmentID(t)
0!=e&&i.SetCfg(e)}return Ee.a.ins.showEffectByData(i)}getSwordElectmentID(e){return 0}PlayArcherSkill(e,t,i,n,s){return Ee.a.ins.showEffectByData(i)}},It._Inst=null,
pt(ct=It,"Inst",[Z.Vx],Object.getOwnPropertyDescriptor(ct,"Inst"),ct),
pt(ct.prototype,"SM_ComboTimesHandler",[Ke],Object.getOwnPropertyDescriptor(ct.prototype,"SM_ComboTimesHandler"),ct.prototype),
pt(ct.prototype,"SM_SkillsInfoHandler",[ze],Object.getOwnPropertyDescriptor(ct.prototype,"SM_SkillsInfoHandler"),ct.prototype),
pt(ct.prototype,"SM_StartMotionHandler",[je],Object.getOwnPropertyDescriptor(ct.prototype,"SM_StartMotionHandler"),ct.prototype),
pt(ct.prototype,"SM_EndMotionHandler",[Xe],Object.getOwnPropertyDescriptor(ct.prototype,"SM_EndMotionHandler"),ct.prototype),
pt(ct.prototype,"SM_InterruptMotionHandler",[qe],Object.getOwnPropertyDescriptor(ct.prototype,"SM_InterruptMotionHandler"),ct.prototype),
pt(ct.prototype,"SM_LightArrowNoticeHandler",[Je],Object.getOwnPropertyDescriptor(ct.prototype,"SM_LightArrowNoticeHandler"),ct.prototype),
pt(ct.prototype,"SM_AlmightyBallHandler",[$e],Object.getOwnPropertyDescriptor(ct.prototype,"SM_AlmightyBallHandler"),ct.prototype),
pt(ct.prototype,"SM_UpdateSkillCdHandler",[Qe],Object.getOwnPropertyDescriptor(ct.prototype,"SM_UpdateSkillCdHandler"),ct.prototype),
pt(ct.prototype,"SM_UpdateSkillPublicCdHandler",[et],Object.getOwnPropertyDescriptor(ct.prototype,"SM_UpdateSkillPublicCdHandler"),ct.prototype),
pt(ct.prototype,"SM_SkillAlertTimeHandler",[tt],Object.getOwnPropertyDescriptor(ct.prototype,"SM_SkillAlertTimeHandler"),ct.prototype),
pt(ct.prototype,"SM_AbortAccumulateSkillHandler",[it],Object.getOwnPropertyDescriptor(ct.prototype,"SM_AbortAccumulateSkillHandler"),ct.prototype),
pt(ct.prototype,"SM_SpiritInfoHandler",[nt],Object.getOwnPropertyDescriptor(ct.prototype,"SM_SpiritInfoHandler"),ct.prototype),
pt(ct.prototype,"SM_UpdateSkillEntryHandler",[st],Object.getOwnPropertyDescriptor(ct.prototype,"SM_UpdateSkillEntryHandler"),ct.prototype),
pt(ct.prototype,"SM_CultivationHandler",[lt],Object.getOwnPropertyDescriptor(ct.prototype,"SM_CultivationHandler"),ct.prototype),
pt(ct.prototype,"SM_StateHandler",[at],Object.getOwnPropertyDescriptor(ct.prototype,"SM_StateHandler"),ct.prototype),
pt(ct.prototype,"SM_UseSkillHandler",[rt],Object.getOwnPropertyDescriptor(ct.prototype,"SM_UseSkillHandler"),ct.prototype),
pt(ct.prototype,"SM_StartUseSkillHandler",[ot],Object.getOwnPropertyDescriptor(ct.prototype,"SM_StartUseSkillHandler"),ct.prototype),
pt(ct.prototype,"SM_EndUseSkillHandler",[dt],Object.getOwnPropertyDescriptor(ct.prototype,"SM_EndUseSkillHandler"),ct.prototype),
pt(ct.prototype,"SM_ClearSkillCdHandler",[ht],Object.getOwnPropertyDescriptor(ct.prototype,"SM_ClearSkillCdHandler"),ct.prototype),
pt(ct.prototype,"SM_ShortcutKeyHandler",[ut],Object.getOwnPropertyDescriptor(ct.prototype,"SM_ShortcutKeyHandler"),ct.prototype),ct)},53343:(e,t,i)=>{i.d(t,{$:()=>n})
var n={Miss:0,NormalAttack:1,CriticalHit:2,ExcellentBlow:3,IgnoringBlow:4,Heal:5,FanShe:6,Baoji:7,Zhimin:8,Lianji:9,Double:10,Parry:11,BreakShield:12,LiuXue:21,FanJi:22,ZhuoSao:23,
ZhaoHuanShou:24,ZhongDu:25,ShenFa:26,HuixinPet:61,ZhuoyuePet:62,ZhimingPet:63,PutongPet:64,RuodianHuixinOne:65,RuodianHuixinTwo:66,RuodianHuixinThree:67,RuodianZhuoyueOne:68,
RuodianZhuoyueTwo:69,RuodianZhuoyueThree:70,RuodianZhimingOne:71,RuodianZhimingTwo:72,RuodianZhimingThree:73,RuodianPutongOne:74,RuodianPutongTwo:75,RuodianPutongThree:76,
RuodianHuixinOneEx:77,RuodianHuixinTwoEx:78,RuodianHuixinThreeEx:79,RuodianZhuoyueOneEx:80,RuodianZhuoyueTwoEx:81,RuodianZhuoyueThreeEx:82,RuodianZhimingOneEx:83,
RuodianZhimingTwoEx:84,RuodianZhimingThreeEx:85,RuodianPutongOneEx:86,RuodianPutongTwoEx:87,RuodianPutongThreeEx:88,Invincibility:101,RedfortressSocreUp:102,KillMonsterExp:103,
SiegeScoreUp:104}},54671:(e,t,i)=>{i.d(t,{X:()=>n})
var n={NONE:-1,TYPE1:0,TYPE2:1,TYPE3:2}},21169:(e,t,i)=>{i.d(t,{O:()=>n})
var n={loopskillchange:"loopskillchange",curskillchange:"curskillchange"}},38770:(e,t,i)=>{i.d(t,{b:()=>n})
var n={ALL:"ALL",SELF:"SELF",WE:"WE",FRIEND:"FRIEND",FRIEND_AND_SELF:"FRIEND_AND_SELF",ENEMY:"ENEMY",ENEMY_PLAYER:"ENEMY_PLAYER",ENEMY_MONSTER:"ENEMY_MONSTER"}},47258:(e,t,i)=>{
i.d(t,{T:()=>l})
var n=i(16812),s=i(2577)
class l extends n.k{constructor(...e){super(...e),this.keysMap=null}static GetInst(){return null==l.Inst&&(l.Inst=new l),l.Inst}SendSkillCdChangeEvent(){
this.RaiseEvent(s.g.CD_CHANGE,this)}}l.Inst=null},2577:(e,t,i)=>{i.d(t,{g:()=>n})
class n{}n.CD_CHANGE="CD_CHANGE",n.SHORTCUT_CHANGE="SHORTCUT_CHANGE",n.NEWSKILL_CHANGE="NEWSKILL_CHANGE",n.NEWSKILL_ADD="NEWSKILL_ADD",
n.NEWSKILL_HEAD_CHANGE="NEWSKILL_HEAD_CHANGE",n.NEWSKILL_SHINN_ADD="NEWSKILL_SHINN_ADD",n.SKILL_VALIDITY_CHANGE="SKILL_VALIDITY_CHANGE",
n.SKILL_EXCHANGE_CLOSE="SKILL_EXCHANGE_CLOSE"},83995:(e,t,i)=>{
var n=i(92984),s=i(34294),l=i(35259),a=i(65550),r=i(98885),o=i(85602),d=i(82815),h=i(7733),u=i(18045),c=i(98800),I=i(84581),_=i(71530),p=i(16812),S=i(70829),g=i(21169)
class m extends p.k{constructor(...e){super(...e),this.needdebug=!1,this.m_curSkill=0,this.m_curLoopSkill=0,this.m_nextSkill=0,this.currentPressSkill=null,
this.roundEffectHandleId=0,this.xcylSkill=null}CurSkill_get(){return this.m_curSkill}CurMutlSkill_set(e,t){t.isPrimary&&(this.m_curSkill=e)}CurSkill_set(e){this.m_curSkill=e}
NextSkill_get(){return this.m_nextSkill}NextSkill_set(e){this.m_nextSkill=e}CurLoopSkill_get(){return this.m_curLoopSkill}CurLoopSkill_set(e){this.m_curLoopSkill=e}}m._inst=null
var f,C,T,y=i(98130),A=i(42292),P=i(87923),w=i(21729),R=i(38836),D=i(73136);(0,A.gK)("GameSys.SkillModel")((T=class e extends p.k{static __StaticInit(){}constructor(){super(!1,0),
this.list=null,this.sortList=null,this.skillCells=null,this.needdebug=!1,this.m_curSkill=0,this.m_curLoopSkill=0,this.m_nextSkill=0,this.currentPressSkill=null,
this.roundEffectHandleId=0,this.xcylSkill=null,this.aoYiSkillsSort=null,this.aoYiSkills=null,this.pressSkills=null,this.buffGroup=null,this.sortOr=null,this.skillCells=new o.Z
for(let e=0;e<=c.Y.PLAYER_MAX_NUM-1;e++)this.skillCells.Add(new m)
this.aoYiSkillsSort=new o.Z(c.Y.PLAYER_MAX_NUM),this.aoYiSkills=new o.Z,this.pressSkills=new o.Z(c.Y.PLAYER_MAX_NUM),this.list=new o.Z,
this.sortList=new o.Z([h.l.HEALTH,h.l.BUFF,h.l.SUMMONMONSTER,h.l.RUSH,h.l.NORMAL])}CurSkill_get(e){return this.skillCells[e.createIdx].m_curSkill}CurSkill_set(e,t){
this.skillCells[t.createIdx].CurSkill_set(e),this.RaiseEvent(g.O.curskillchange,this)}NextSkill_get(e){return this.skillCells[e.createIdx].m_nextSkill}NextSkill_set(e,t){
this.skillCells[t.createIdx].NextSkill_set(e)}CurLoopSkill_get(e){return this.skillCells[e.createIdx].m_curLoopSkill}CurLoopSkill_set(e,t){
this.skillCells[t.createIdx].CurLoopSkill_set(e),this.RaiseEvent(g.O.loopskillchange,this)}static getInst(){return null==e._inst&&(e._inst=new e),e._inst}SetPreSkill(e,t,i){
const n=c.Y.Inst.PrimaryRoleInfo_get().createIdx
if(null==e&&(e=n),this.pressSkills[e]=t,null!=i&&i!=d.R.precastskill){const t=c.Y.Inst.GetMultiPlayeByCreateIdx(e)
u.R.getInst().addAI(t,i)}}ResetData(){for(let e=0;e<=this.aoYiSkills.count-1;e++)this.aoYiSkills[e]=null
for(let e=0;e<=this.aoYiSkillsSort.count-1;e++)this.aoYiSkillsSort[e]=null
for(let e=0;e<=this.pressSkills.count-1;e++)this.pressSkills[e]=null}GetPreSkill(e){return this.pressSkills[e]}ClearPreSkill(){
for(let e=0;e<=this.pressSkills.count-1;e++)this.pressSkills[e]=null}CheckSkillTarget(e,t,i,n){if(null==e||null==i)return!0
if(!c.Y.Inst.CheckTargetType(e,i))return!0
if(null!=e.GetHangVo()){if(e.GetHangVo().type==h.l.RUSH){const[s,l]=t.GetPosXZ(),[r,o]=i.GetPosXZ()
return!(D.c.Instance_get().IsLineBlock(s,l,r,o)&&_.A.DistanceFastXZ(s,0,l,r,0,l)<=e.pointDis*e.pointDis+.2)||(null!=n&&n&&a.y.inst.ClientSysStrMsg("无法对当前目标发起冲锋"),!1)}
if(e.GetHangVo().type==h.l.HEALTH)return!0
if(e.GetHangVo().type==h.l.BUFF)return!0}return!0}NeedCheckLineBlock(e){return null==e||null!=e.GetHangVo()&&e.GetHangVo().type==h.l.RUSH}GetSkillTarget(e,t,i,n,s,l,a){
if(null==e)return null
if(null!=e.GetHangVo()){if(e.GetHangVo().type==h.l.RUSH)return this.GetRushTarget(e,t,n,s,null,l,a)
if(e.GetHangVo().type==h.l.HEALTH)return this.GetHealthTarget(e,i)
if(e.GetHangVo().type==h.l.BUFF)return this.GetBuffTarget(e,t,s,null,n,l,a)}return null}GetHealthTarget(e,t){const i=r.M.String2Float(e.GetHangVo().extend)
let n=null,s=null,l=w.N.huge
const a=c.Y.Inst.primaryRoleList
if(null!=e.skillTargetType){this.list.Clear()
for(let e=0;e<=a.Count()-1;e++){const s=a[e].Roleinfo_get()
n=s.CurrentHp_get()/s.MaxHp_get()*1e4,(!t||n<=i)&&n<l&&this.list.Add(a[e])}this.list.count>0&&(e.skillTargetType.SortRoleList(this.list),s=this.list[0],this.list.Clear())
}else for(let e=0;e<=a.Count()-1;e++){const r=a[e],o=r.Roleinfo_get()
n=o.CurrentHp_get()/o.MaxHp_get()*1e4,(!t||n<i)&&n<l&&(l=n,s=r)}return s}GetBuffTarget(e,t,i,s,l,a,r){let o=!1
l>0&&(o=!0)
const[d,h]=t.GetPosXZ()
if(null==a&&([a,r]=[d,h]),null!=s)if(o){const e=s.GetObjWidth()
if((l+e)*(l+e)>=P.l.CalFastCharToXZDisFast(s,d,h))return s}else if(s.roletype!=I.s.role&&!e.IsSelfFriendType())return s
if(!o&&e.targetFilter==eTargetFilter.SELF)return t
this.buffGroup=n.j.Inst_get().model.buffGroup
const u=t.Roleinfo_get(),_=e.GetHangVo()
let p=c.Y.Inst.SelectMaxDis_get()
if(o&&(p=l),null!=_.buffIds){const e=n.j.Inst_get().model
let s=0
const l=c.Y.Inst.GetNearAttackMonsterList(p,a,r,i),I=c.Y.Inst.GetNearAttackRoleList(p,a,r)
if(o&&0==l.count&&0==I.count)return null
for(;s<_.buffIds.count;){const o=_.buffIds[s]
let c=null
const S=n.j.Inst_get().model.GetBuffResById(o)
let g=y.GF.INT32_MAX_VALUE_get()
if(null!=this.buffGroup&&(g=this.buffGroup.LuaDic_GetItem(`${_.buffIds[s]}`)),null==g&&(g=y.GF.INT32_MAX_VALUE_get()),null!=S.buffTargetType){
if(_.cfg.IsSelfFriendType()?c=this.GetFriendBuffTarget(S,g,d,h,p,t,a,r):_.cfg.targetFilter==eTargetFilter.ENEMY_MONSTER?c=this.GetDeBuffMonsterTarget(S,g,d,h,p,t,i,l,a,r):_.cfg.targetFilter==eTargetFilter.ENEMY_PLAYER?c=this.GetDeBuffRoleTarget(S,g,d,h,p,t,i,I,a,r):_.cfg.targetFilter==eTargetFilter.ENEMY&&(c=this.GetDeBuffTarget(S,g,d,h,p,t.monsterIds,l,I,a,r)),
null!=c)return c}else{const i=e.GetGroupBuffValue(u.Id_get(),`${_.buffIds[s]}`)
if(g>i||0==i)return t}s+=1}}return null}GetFriendBuffTarget(e,t,i,s,l,a,r,d){const h=c.Y.Inst.primaryRoleList.count,u=n.j.Inst_get().model
let I=null,_=null
for(let i=0;i<=h-1;i++){const n=c.Y.Inst.primaryRoleList[i]
if(u.GetGroupBuffValue(n.GetGameId(),`${e.id}`)<t)if(e.buffTargetType.CheckPlayerFix(n.Roleinfo_get())){if(!e.buffTargetType.needSort)return n
null==_&&(_=new o.Z),_.Add(n)}else a==n&&(I=n)}return null!=_&&_.count>0?(_.count>1&&e.buffTargetType.SortRoleList(_),_[0]):I}GetDeBuffMonsterTarget(e,t,i,s,l,a,r,o,d,h){
null==d&&([d,h]=[i,s]),null==o&&(o=c.Y.Inst.GetNearAttackMonsterList(l,d,h,r))
const u=n.j.Inst_get().model,I=null
for(let i=0;i<=o.count-1;i++){const n=o[i]
u.GetGroupBuffValue(n.Info_get().id,`${e.id}`)<t&&I.Add(n)}return I.count>0?(I.count>1&&e.buffTargetType.SortMonsterList(I),I[0]):null}GetDeBuffRoleTarget(e,t,i,s,l,a,r,d,h,u){
const I=n.j.Inst_get().model
null==h&&([h,u]=[i,s]),null==d&&(d=c.Y.Inst.GetNearAttackRoleList(l,h,u))
const _=d.count
let p=null,S=null
for(let i=0;i<=_-1;i++){const n=d[i]
if(I.GetGroupBuffValue(n.Id_get(),`${e.id}`)<t)if(e.buffTargetType.CheckPlayerFix(n.Roleinfo_get())){if(!e.buffTargetType.needSort)return n
null==p&&(p=new o.Z),p.Add(n)}else null==S&&(S=new o.Z),S.Add(n)}return p.count>0?(p.count>1&&e.buffTargetType.SortRoleList(p),p[0]):S.count>0?(e.buffTargetType.SortRoleList(S),
S[0]):null}GetDeBuffTarget(e,t,i,n,s,l,a,r,o,d,h){let u=null
return null!=a&&0!=a.count||(u=this.GetDeBuffRoleTarget(e,t,i,n,s,l,a,o,d,h)),null==u&&(u=this.GetDeBuffMonsterTarget(e,t,i,n,s,l,a,r,d,h)),u}GetRushTarget(e,t,i,n,s,l,a){
if(null!=s&&s.roletype==I.s.role&&!e.IsSelfFriendType()&&!P.l.IsLineBlock(s,t))return s
if(null==i&&(i=e.pointDis),null==e.skillTargetType)return null
{const[s,r]=t.GetPosXZ()
null==l&&([l,a]=[s,r])
let o=null
if((null==n||0==n.count)&&(o=c.Y.Inst.GetNearAttackRoleList(i,l,a,null,null),o.count>0)){e.skillTargetType.SortRoleList(o)
for(let e=0;e<=o.count-1;e++)if(!P.l.IsLineBlock(o[e],t))return o[e]}if(o=c.Y.Inst.GetNearAttackMonsterList(i,l,a,n),!(o.count>0))return null
e.skillTargetType.SortMonsterList(o)
for(let e=0;e<=o.count-1;e++)if(!P.l.IsLineBlock(o[e],t))return o[e]}}UpdateHangSkillVOs(e,t,i){const n=[s.L.Skill_List_Type_PVE,s.L.Skill_List_Type_PVP]
let a=0
for(const[r,d]of(0,R.X)(n)){const n=d==s.L.Skill_List_Type_PVE?t:i
if(null!=n){n.Clear()
const t=new o.Z,i=s.L.Inst_get().GetRoleUseSkillSlot(e.createIdx,d)
if(null!=i){const s=i.skillUpM
for(const[i,r]of(0,R.V5)(s)){const i=l.C.Inst.GetSkillByStudyDic(r,e)
if(null!=i){const e=S.j.Inst().GetSkillByIdLevel(r,i.level)
null!=e&&null!=e.GetHangVo()&&(n.Add(e.GetHangVo()),t.Add(e.GetHangVo()),e.GetHangVo().type==h.l.NORMAL&&e.pointDis>a&&(a=e.pointDis))}}this.SortHangSkillVOs(n,t)}}}return a}
SortHangSkillVOs(e,t){this.sortOr=t,e.Sort(this.CreateDelegate(this.OnSortHangSkillVOs)),this.sortOr=null}OnSortHangSkillVOs(e,t){
let i=this.sortList.IndexOf(e.type),n=this.sortList.IndexOf(t.type)
if(n==i&&2==i){const s=r.M.String2Int(e.extend),l=r.M.String2Int(e.extend)
return s<l?1:s>l?-1:null!=this.sortOr?(i=this.sortOr.IndexOf(e),n=this.sortOr.IndexOf(t),i-n):0}return i==n&&null!=this.sortOr&&(i=this.sortOr.IndexOf(e),n=this.sortOr.IndexOf(t)),
i-n}GetAllAoYiSkill(){this.aoYiSkills.Clear()
const e=S.j.Inst().aoYiSkillShowLv,t=c.Y.Inst.primaryRoleInfoList
for(let i=0;i<=t.count-1;i++){const n=t[i].m_skills
for(const[s,l]of(0,R.V5)(n))if(S.j.Inst().IsAoYiSkill(l.id)&&l.level>=e){if(null==this.aoYiSkillsSort[i]){const e=S.j.Inst().GetSkillByIdLevel(l.id,l.level)
this.aoYiSkillsSort[i]={res:e,createIdx:t[i].createIdx}}else if(this.aoYiSkillsSort[i].res.skillid!=l.id||this.aoYiSkillsSort[i].res.level!=l.level){
const e=S.j.Inst().GetSkillByIdLevel(l.id,l.level)
this.aoYiSkillsSort[i].res=e}break}null!=this.aoYiSkillsSort[i]&&this.aoYiSkills.Add(this.aoYiSkillsSort[i])}return this.aoYiSkills}},T._inst=null,L=C=T,E="getInst",B=[A.Vx],
M=Object.getOwnPropertyDescriptor(C,"getInst"),G=C,O={},Object.keys(M).forEach((function(e){O[e]=M[e]})),O.enumerable=!!O.enumerable,O.configurable=!!O.configurable,
("value"in O||O.initializer)&&(O.writable=!0),O=B.slice().reverse().reduce((function(e,t){return t(L,E,e)||e}),O),
G&&void 0!==O.initializer&&(O.value=O.initializer?O.initializer.call(G):void 0,O.initializer=void 0),void 0===O.initializer&&(Object.defineProperty(L,E,O),O=null),f=C))
var L,E,B,M,G,O},51696:(e,t,i)=>{i.d(t,{G:()=>n})
var n={BACKGROUND_CHANNEL_GROUP:1,ENVIRONMENT_CHANNEL_GROUP:2,UI_CHANNEL_GROUP:3,NPC_CHANNEL_GROUP:4,EVENT_CHANNEL_GROUP:5,ROLE_CHANNEL_GROUP:6,BOSS_CHANNEL_GROUP:7,
MONSTER_CHANNEL_GROUP:8,DROP_CHANNEL_GROUP:9,BACKGROUND_SOUND_GROUP:1,FMOD_BACKGROUND_SOUND_GROUP:"Music",EFFECT2D_SOUND_GROUP:2,FMOD_EFFECT2D_SOUND_GROUP:"Effect",
DEFAULT_SOUND_GROUP:3,DEFAULT_PANEL:-1,TRANS_JOB_PANEL:1,BOSS_PANEL:2,TASK_PANEL:3,MAP_PANEL:4,DIALOGUE_PANEL:5,DISPLAY_PANEL:6,MAP_TRANSPORT_MASK_PANEL:7,
MUSIC_MUTE_SET:"MUSIC_MUTE_SET",MUSIC_VOL_SET:"MUSIC_VOL_SET",EFFECT_MUTE_SET:"EFFECT_MUTE_SET",EFFECT_VOL_SET:"EFFECT_VOL_SET",eFunctionListOpen:"FunctionListOpen",
eFunctionListClose:"FunctionListClose",eMapFunctionListChange:"MapFunctionListChange",ePersonalBossCountDown:"PersonalBossCountDown",eSuitUpdate:"SuitUpdate",
eStarMasterUpgrade:"StarMasterUpgrade",eMiracleSelectMonster:"MiracleSelectMonster",eGetDiamondAni:"GetDiamondAni",eItemOnSale:"ItemOnSale",
eEquipEvolutionSuccess:"EquipEvolutionSuccess",eEquipEvolutionFail:"EquipEvolutionFail",eEquipShift:"EquipShift",eCopyBraveTestStarAni:"CopyBraveTestStarAni",
eCopyBraveTestChest:"CopyBraveTestChest"}},3838:(e,t,i)=>{i.d(t,{O:()=>T})
var n=i(42292),s=i(33314),l=i(91652),a=i(98130),r=i(98885),o=i(85602),d=i(38962),h=i(38836),u=i(86133),c=i(98800),I=i(5924),_=i(66788)
class p{constructor(){this.cfg=null,this.aniSpeed=0,this.startTimerList=null,this.loopTimerList=null,this.startTimerList=new o.Z,this.loopTimerList=new o.Z}}class S{constructor(){
this.aniId=0,this.soundId=0}}var g,m,f,C=i(41664)
let T=(0,n.gK)("GameSys.AniSoundMgr")((f=class e{constructor(){this.aniSoundDict=null,this._degf_PlayFirst=null,this._degf_PlayLoop=null,this.aniSoundDict=new d.X,
this._degf_PlayFirst=(e,t)=>this.PlayFirst(e,t),this._degf_PlayLoop=(e,t)=>this.PlayLoop(e,t)}static Inst_get(){return null==e._inst&&(e._inst=new e),e._inst}PlayByAniId(e){
let t=null
if(t=this.aniSoundDict[e],null!=t)return
const i=c.Y.Inst.PrimaryRoleInfo_get(),n=s.Z.GetJobType(i.Job_get()),o=i.Sex_get(),d=l.r.Inst_get().GetAniCfg(n,o,e)
if(null==d)return
if(0==d.soundIdList_get().Count())return
t=new p,t.cfg=d,t.aniSpeed=c.Y.Inst.PrimaryRole_get().GetAnimationRate(),this.aniSoundDict.LuaDic_AddOrSetItem(e,t)
let h=0
for(;h<d.startTimeList.Count();){if(h>=d.soundIdList_get().Count()){_.Y.LogError((0,u.T)("起始时间跟音效个数不对应，请策划大佬检查soundanimationconfig表中指定项:")+r.M.IntToString(e))
break}const i=d.startTimeList[h],n=a.GF.INT(i/t.aniSpeed),s=new S
s.aniId=e,s.soundId=d.soundIdList_get()[h].soundId
const l=I.C.Inst_get().SetIntervalForParm(this._degf_PlayFirst,n,1,s)
t.startTimerList.Add(l),h+=1}}StopByAniId(e){let t=null
if(t=this.aniSoundDict[e],null!=t){for(const[e,i]of(0,h.V5)(t.startTimerList))I.C.Inst_get().ClearLoop(i)
t.startTimerList.Clear()
for(const[e,i]of(0,h.V5)(t.loopTimerList))I.C.Inst_get().ClearLoop(i)
t.loopTimerList.Clear(),this.aniSoundDict.LuaDic_Remove(e)}}PlayFirst(e,t){const i=t,n=this.aniSoundDict[i.aniId]
if(n.startTimerList.Remove(e),C.j.Inst.PlayBySoundId(i.soundId),0!=n.cfg.intervalTime){
const e=a.GF.INT(n.cfg.intervalTime/n.aniSpeed),t=I.C.Inst_get().SetIntervalForParm(this._degf_PlayLoop,e,-1,i)
n.loopTimerList.Add(t)}}PlayLoop(e,t){const i=t
C.j.Inst.PlayBySoundId(i.soundId)}IsExist(e){return this.aniSoundDict.LuaDic_ContainsKey(e)}UpdateAniSpeed(e){for(const[t,i]of(0,h.V5)(this.aniSoundDict))if(i.aniSpeed!=e){
const t=i.aniSpeed
i.aniSpeed=e
const n=new o.Z,s=new o.Z
for(const[e,t]of(0,h.V5)(i.startTimerList)){const e=I.C.Inst_get().TriggerLeftTime(t),i=I.C.Inst_get().GetTriggerParam(t)
e>0&&(n.Add(e),s.Add(i)),I.C.Inst_get().ClearLoop(t)}i.startTimerList.Clear()
for(const[e,t]of(0,h.V5)(i.loopTimerList)){const e=I.C.Inst_get().TriggerLeftTime(t),i=I.C.Inst_get().GetTriggerParam(t)
e>0&&(n.Add(e),s.Add(i)),I.C.Inst_get().ClearLoop(t)}i.loopTimerList.Clear()
let l=0
for(;l<n.Count();){const r=n[l],o=a.GF.INT(r/(e/t)),d=s[l],h=I.C.Inst_get().SetIntervalForParm(this._degf_PlayFirst,o,1,d)
i.startTimerList.Add(h),l+=1}}}},f._inst=null,y=m=f,A="Inst_get",P=[n.Vx],w=Object.getOwnPropertyDescriptor(m,"Inst_get"),R=m,D={},Object.keys(w).forEach((function(e){D[e]=w[e]})),
D.enumerable=!!D.enumerable,D.configurable=!!D.configurable,("value"in D||D.initializer)&&(D.writable=!0),D=P.slice().reverse().reduce((function(e,t){return t(y,A,e)||e}),D),
R&&void 0!==D.initializer&&(D.value=D.initializer?D.initializer.call(R):void 0,D.initializer=void 0),void 0===D.initializer&&(Object.defineProperty(y,A,D),D=null),g=m))||g
var y,A,P,w,R,D},80037:(e,t,i)=>{i.d(t,{j:()=>d})
var n=i(35128),s=i(98130),l=i(85602),a=i(23833),r=i(5924),o=i(41664)
class d{constructor(){this.timeId=0,this.bossDelayList=null,this.soundKeyList=null,this._degf_DelayPlaySound=null,this._degf_DelayPlaySound=(e,t)=>this.DelayPlaySound(e,t)}
static Inst_get(){return null==d._inst&&(d._inst=new d),d._inst}PlayStandSound(e){const t=a.a.getInst().getObjById(e)
if(null==t)return
this.StopStandSound()
const i=this.GetBossDelayTime()
this.StartTimer(i,t.standSoundId)}StopStandSound(){this.StopTimer(),o.j.Inst.StopByKeyList(this.soundKeyList)}DelayPlaySound(e,t){const i=t
this.soundKeyList=o.j.Inst.PlayByCfgSoundId(i,null,null,!1,!0)}StartTimer(e,t){0==this.timeId&&(this.timeId=r.C.Inst_get().SetIntervalForParm(this._degf_DelayPlaySound,e,1,t))}
StopTimer(){0!=this.timeId&&(r.C.Inst_get().ClearInterval(this.timeId),this.timeId=0)}GetBossDelayTime(){let e=0
if(null==this.bossDelayList&&(this.bossDelayList=new l.Z),0!=this.bossDelayList.Count()){const t=this.bossDelayList[0],i=this.bossDelayList[this.bossDelayList.Count()-1]
e=t==i?t:s.GF.INT(n.p.RandomMinMax(t,i))}return e}}d._inst=null},47640:(e,t,i)=>{i.d(t,{y:()=>g})
var n=i(18998),s=i(845),l=i(38836),a=10,r=i(51696),o=i(85688),d=i(75507),h=i(21370),u=i(87923),c=i(66788)
class I{constructor(){this.soundName=null,this.uResName=null,this.uResId=null,this.VolumeOrigin=null,this.VolumeScale=null,this.Mute=null,this.handleId=null,this.realVolume=null,
this.fadeOut=null,this.fadeIn=null,this.autoPlay=null,this.loop=null,this.onPlayEnd=null,this.group=null,this.iLoopCount=null,this.FMODParams=null,this._soundNode=null,
this._audioSource=null,this._resId=null,this.isLoaded=!1,this.loadStartTime=0,this.isStarted=!1,this.autoDestroy=!0,this.destroyOnStop=!1,this.isPause=!1,this.isDestroy=!1,
this.testSoundStr="Ambience/soundc_rain_01"}PlaySound(){this.Clear()
let e=this._audioSource
if(null==e){this._soundNode=n.Node.createUINode(),e=this._soundNode.getOrAddComponent(n.AudioSource),this._audioSource=e
const t=o.n.ins.getLayer(h.T.sound)
e.node.setParent(t)}this._soundNode.name=u.l.ReplaceAllAByB(this.uResName,"/","."),this.loadStartTime=cus.currTime
const t=this._resId,i=d.o.loadBundleRes(`sound/${this.uResName}`,"wealth",n.AudioClip,d.o.LoaderCache.RefCycle)
t!=i?(t>0&&(d.o._$releaseRes(t),e.clip=null),d.o._$retainRes(i),this._resId=i,d.o.listenRes(i,this._onAssetLoaded,this)):e.clip&&this.Start()}_onAssetLoaded(e){
e&&(this._audioSource.clip=e,this.Start())}Start(){this.uResName==this.testSoundStr&&c.Y.Log("-------Start"),this.isLoaded=!0,this.isStarted=!0,this._audioSource.loop=this.loop,
this._audioSource.volume=this.Mute?0:this.VolumeScale,this._audioSource.play()}Resume(){this.uResName==this.testSoundStr&&c.Y.Log("-------Resume"),this.isPause=!1,
this._audioSource.play()}Pause(){this.uResName==this.testSoundStr&&c.Y.Log("-------Pause"),this.isPause=!0,this._audioSource.pause()}SetVolume(e){this._audioSource.volume=e}
Stop(e,t){this.uResName==this.testSoundStr&&c.Y.Log("-------Stop"),this.isStarted=!1,0==e&&(this._audioSource.stop(),this.destroyOnStop=t,
this.destroyOnStop&&g.Inst_get().DestorySound(this.handleId))}Update(){if(!this.isLoaded&&cus.currTime-this.loadStartTime>1e4)return!1
if(!this.isStarted)return!0
if(this.uResName==this.testSoundStr&&c.Y.Log("-------Update--\x3euResName:"+this.uResName+" ,loop:"+this.loop.toString()+" ,isPlaying:"+this._audioSource.playing+" ,currentTime:"+this._audioSource.currentTime),
null!=this._audioSource&&!this._audioSource.playing&&0==this._audioSource.currentTime){if(this.loop)return this._audioSource.play(),!0
if(this.autoDestroy)return!1}return this.FadeInAndOut(),!0}FadeInAndOut(){}Clear(){this._audioSource&&this._audioSource.stop(),this.isLoaded=!1,this.loadStartTime=0,
this.isStarted=!1,this.autoDestroy=!0,this.destroyOnStop=!1,this.isPause=!1,this.isDestroy=!1}Recyle(e){this.uResName==this.testSoundStr&&c.Y.Log("-------Recyle"),
null!=this.onPlayEnd&&(this.onPlayEnd(this.handleId),this.onPlayEnd=null),this.Clear(),this._resId>0&&(d.o._$releaseRes(this._resId),this._audioSource.clip=null,this._resId=0),
e&&g.Inst_get().Recyle(this)}Destroy(){this._soundNode.parent&&this._soundNode.parent.removeChild(this._soundNode)}}var _=i(85602),p=i(38962),S=i(41664)
class g{static Inst_get(){return null==g._inst&&(g._inst=new g),g._inst}constructor(){this._lastTime=0,this.SoundPool=new _.Z,this._vSoundGroupVolume=[],this._vSoundGroup=new _.Z,
this._dSoundList=new _.Z,this._vSoundGroupMute=[],this._uMaxHandle=1
const e=s.g.Inst_get().systemModel.systemSetting_get()
let t=a
for(let i=0;i<t;++i){let t=new p.X
this._vSoundGroup.Add(t),1==i?(this._vSoundGroupVolume[i]=1*e.musicOption/100,this._vSoundGroupMute[i]=!e.autoMusic):2==i||3==i?(this._vSoundGroupVolume[i]=1*e.soundOption/100,
this._vSoundGroupMute[i]=!e.autoSound):(this._vSoundGroupVolume[i]=1,this._vSoundGroupMute[i]=!1)}cus.requestFrame(this.SingletonUpdate,this)}SoundPlay2D(e,t,i,n,s,l,a,r){
if(null==l&&(l=!0),null==s&&(s=!1),null==n&&(n=0),null==i&&(i=1),"footstep_common"==e)return 0
let o=this._uMaxHandle++,d=this.CreateSound()
return d.uResName=e,d.onPlayEnd=a,d.group=t,d.fadeIn=n,d.loop=s,d.autoPlay=l,d.VolumeOrigin=i,d.handleId=o,d.Mute=this._vSoundGroupMute[t],d.VolumeScale=this._vSoundGroupVolume[t],
d.PlaySound(),this._vSoundGroup[t].LuaDic_AddOrSetItem(o,d),this._dSoundList.Add(d),o}SoundStop(e,t,i){null==i&&(i=!0),null==t&&(t=0)
let n=this._TryGetSound(e)
null!=n&&n.Stop(0,i)}SoundSetGroupVolume(e,t){if(this._vSoundGroupVolume[e]=t,this._vSoundGroupMute[e])return
let i=this._vSoundGroup[e]
if(null!=i)for(const[e,n]of(0,l.V5)(i))n.SetVolume(t)}SoundGetGroupVolume(e){return this._vSoundGroupVolume[e]}SoundSetGroupMute(e,t){this._vSoundGroupMute[e]=t
let i=this._vSoundGroupVolume[e],n=this._vSoundGroup[e]
if(null!=n)for(const[e,s]of(0,l.V5)(n))s.SetVolume(t?0:i)}SetSoundGroupVCAPath(e,t){}ActiveSnapshot(e){}DeactiveSnapshot(e){}PreloadSounds(e){}UnloadSounds(e){}OnButtonPress(){}
OnButtonClickSound(e=null){S.j.Inst.PlayButtonSound(e)}_TryGetSound(e){let t=null
for(let i=this._dSoundList.Count()-1;i>=0;--i)if(this._dSoundList[i].handleId==e){t=this._dSoundList[i]
break}return t}SingletonUpdate(){const e=cus.currTime
if(n.game.isPaused()||!(e-this._lastTime<1500)){this._lastTime=e
for(let e=0;e<this._dSoundList.Count();++e)this._dSoundList[e].Update()||this.DestorySound(this._dSoundList[e].handleId)}}DestorySound(e,t=!0){let i=this._TryGetSound(e)
if(null==i)return
for(let t=this._dSoundList.Count()-1;t>=0;--t)if(this._dSoundList[t].handleId==e){this._dSoundList.Remove(this._dSoundList[t])
break}const n=i.group
this._vSoundGroup[n].LuaDic_Remove(e),i.Recyle(t)}CreateSound(){
if(this._dSoundList.Count()>=10)for(let e=0;e<this._dSoundList.Count();++e)if(this._dSoundList[e].group!=r.G.BACKGROUND_SOUND_GROUP){const t=this._dSoundList[e]
return this.DestorySound(t.handleId,!1),t}if(this.SoundPool.length>0){return this.SoundPool.pop()}return new I}Recyle(e){this.SoundPool.length<10&&this.SoundPool.push(e)}}
g._inst=null},3433:(e,t,i)=>{i.d(t,{c:()=>h})
var n=i(21334),s=i(85602),l=i(38836),a=i(13687),r=i(51696)
class o{constructor(){this.playCallback=null,this.paramsList=null}}var d=i(41664)
class h{constructor(){this.doneSoundList=null,this._isSafeArea=!1,this._isMapLoaded=!1,this.doneSoundList=new s.Z}static Inst_get(){return null==h._inst&&(h._inst=new h),h._inst}
IsSafeArea_get(){return this._isSafeArea}IsSafeArea_set(e){this._isSafeArea=e,this.PlayMapSound()}IsMapLoaded_get(){return this._isMapLoaded}IsMapLoaded_set(e){this._isMapLoaded=e,
this._isMapLoaded&&(this.PlayMapSound(),this.PlayDoneSound())}PlayMapSound(){if(!this._isMapLoaded)return
const e=a.b.Inst.currentMapId_get(),t=n.p.Inst_get().GetMapById(e)
if(null==t)return
let i=null,s=null
this._isSafeArea?(i=t.safeBackground,s=t.safeEnvironment):(i=t.backGround,s=t.environment),d.j.Inst.StopByGroup(r.G.BACKGROUND_CHANNEL_GROUP),d.j.Inst.PlayByCfgSoundId(i),
d.j.Inst.StopByGroup(r.G.ENVIRONMENT_CHANNEL_GROUP),d.j.Inst.PlayByCfgSoundId(s)}TryPlayDoneSound(e,t){if(this._isMapLoaded)null!=e&&e(t)
else{const i=new o
i.playCallback=e,i.paramsList=t,this.doneSoundList.Add(i)}}PlayDoneSound(){for(const[e,t]of(0,l.V5)(this.doneSoundList))null!=t.playCallback&&t.playCallback(t.paramsList)
this.doneSoundList.Clear()}}h._inst=null},78816:(e,t,i)=>{i.d(t,{a:()=>a})
var n=i(91652),s=i(38962),l=i(41664)
class a{constructor(){this.loopSoundDict=null,this.loopSoundDict=new s.X}static inst_get(){return null==a._inst&&(a._inst=new a),a._inst}PlayOpenSound(e){
const t=n.r.Inst_get().GetPanelCfg(e)
if(null==t)return
l.j.Inst.PlayByCfgSoundId(t.openSoundId)
const i=l.j.Inst.PlayByCfgSoundId(t.loopSoundId,null,null,null,!0)
null!=i&&0!=i.Count()&&this.loopSoundDict.LuaDic_AddOrSetItem(e,i)}PlayCloseSound(e){const t=n.r.Inst_get().GetPanelCfg(e)
if(null==t)return
l.j.Inst.PlayByCfgSoundId(t.closeSoundId)
let i=null
i=this.loopSoundDict[e],null!=i&&(l.j.Inst.StopByKeyList(i),i.Clear())}}a._inst=null},41664:(e,t,i)=>{i.d(t,{j:()=>A})
var n=i(42292),s=i(38908),l=i(91652),a=i(845),r=i(5468),o=i(98885),d=i(85602),h=i(38962),u=i(38836),c=i(86133),I=i(20738),_=i(85179),p=i(6700),S=i(66788),g=i(51696)
const m=new(i(26133).G)
class f{constructor(){this.key=0,this.soundId=0,this.soundHandle=0,this.elementHandle=0,this.playEndCallback=null}static Fetch(){return m.count>0?m.Pop():new f}Recyle(){
if(m.count<30)return this.Clear(),m.Add(this)}Clear(){this.key=0,this.soundId=0,this.soundHandle=0,this.elementHandle=0,this.playEndCallback=null}}var C,T,y=i(47640)
let A=(T=class e{static get Inst(){return null==e._inst&&(e._inst=new e),e._inst}constructor(){this.enableLog=!1,this.soundDataDict=null,this._degf_OnPlayElementEnd=null,
this._degf_OnPlaySoundEnd=null,this.soundDataDict=new h.X,this._degf_OnPlayElementEnd=e=>this.OnPlayElementEnd(e),this._degf_OnPlaySoundEnd=e=>this.OnPlaySoundEnd(e),
y.y.Inst_get().OnButtonPress()}PlayByResName(e,t,i){let n=l.r.Inst_get().GetSoundIdByResName(e)
return null!=n&&0!=n.Count()||(n=l.r.Inst_get().GetSoundIdByResName("empty")),this.PlayByUnitList(n,t,null,i)}PlayByDivision(e,t="",i=null,n=!1){null==t&&(t="")
const s=l.r.Inst_get().GetSoundIdByDivision(e,t)
return this.PlayByUnitList(s,i,null,n)}PlayByCfgSoundId(e,t=null,i=null,n=null,s=null){null==n&&(n=!0)
const a=l.r.Inst_get().ParseSoundId(e,n)
if(!s&&null==a)return null
const r=this.PlayByUnitList(a,t,i,s)
return s?r:null}PlayByUnitList(e,t,i,n){let s=null
if(n&&(s=new d.Z),null!=e&&0!=e.Count()){let l=0
for(;l<e.Count();){const a=e[l],r=this.PlayBySoundId(a.soundId,t,i)
n&&0!=r&&s.Add(r),l+=1}}return s}PlayBySoundId(t,i,n){if(!l.r.Inst_get().IsExistSound(t)){if(this.enableLog){const e=o.M.Replace((0,
c.T)("音效{0}在soundresource表中不存在:"),"{0}",o.M.IntToString(t))
S.Y.Log(e)}return 0}if(!this.FilterByGroup(t))return 0
if(!this.FilterByMutex(t))return 0
const a=l.r.Inst_get().GetResCfgById(t)
if(!s.C.Instance.isDone_get()&&!p.L.CheckSound(a.path))return 0
let r=this.soundDataDict[a.groupId]
null==r&&(r=new d.Z,this.soundDataDict.LuaDic_AddOrSetItem(a.groupId,r))
const h=f.Fetch()
e.increaseKey+=1,h.key=e.increaseKey,h.soundId=t,h.playEndCallback=i,r.Add(h)
const u=l.r.Inst_get().GetSoundGroup(t)
if(l.r.Inst_get().IsElementSound(t)){const e=new _.w
e._uElementCombineID=a.ElementId,e._ElementCombineEnd=this._degf_OnPlayElementEnd,h.elementHandle=I.h.Instance_get().CreateElementCombine(e)
}else h.soundHandle=y.y.Inst_get().SoundPlay2D(a.path,u,a.volume/100,a.fadein,a.loop,!0,this._degf_OnPlaySoundEnd,n)
if(u==g.G.DEFAULT_SOUND_GROUP){const e=y.y.Inst_get().SoundGetGroupVolume(g.G.BACKGROUND_SOUND_GROUP),i=e*(1-a.lower/100)
y.y.Inst_get().SoundSetGroupVolume(g.G.BACKGROUND_SOUND_GROUP,i)
const n=y.y.Inst_get().SoundGetGroupVolume(g.G.EFFECT2D_SOUND_GROUP),s=n*(1-a.lower/100)
y.y.Inst_get().SoundSetGroupVolume(g.G.EFFECT2D_SOUND_GROUP,s)
{let l=o.M.Replace((0,c.T)("音效{0}造成背景音效和2d音效组的音量降低，其中背景音效组音量由"),"{0}",o.M.IntToString(t))
l+=o.M.Replace((0,c.T)("{0}降到"),"{0}",o.M.FloatToString(e)),l+=o.M.Replace((0,c.T)("{0},2d音效组音量由"),"{0}",o.M.FloatToString(i)),l+=o.M.Replace((0,
c.T)("{0}降到"),"{0}",o.M.FloatToString(n)),l+=o.M.Replace("{0}","{0}",o.M.FloatToString(s)),S.Y.Log(l)}}return h.key}OnPlayElementEnd(e){for(const[t,i]of(0,
u.V5)(this.soundDataDict))for(const[t,n]of(0,u.V5)(i))if(n.elementHandle==e._uHandleID)return void(null!=n.playEndCallback?n.playEndCallback(n.key):this.StopByKey(n.key))}
OnPlaySoundEnd(e){for(const[t,i]of(0,u.V5)(this.soundDataDict))for(const[t,n]of(0,
u.V5)(i))if(n.soundHandle==e)return void(null!=n.playEndCallback?n.playEndCallback(n.key):this.StopByKey(n.key))}StopAll(e){null==e&&(e=!0)
for(const[t,i]of(0,u.vy)(this.soundDataDict))this.StopByGroup(t,e)}StopByGroup(e,t){null==t&&(t=!0)
const i=this.soundDataDict[e]
if(null!=i){let e=0
for(;e<i.Count();){const n=i[e]
if(0!=n.elementHandle)I.h.Instance_get().DeleteElementCombine(n.elementHandle)
else if(0!=n.soundHandle){const e=l.r.Inst_get().GetResCfgById(n.soundId)
y.y.Inst_get().SoundStop(n.soundHandle,e.fadeout,t)}this.ResetSettingVolume(n.soundId),n.Recyle(),e+=1}i.Clear()}}StopByKeyList(e,t=null){if(null==t&&(t=!0),
null!=e)for(const[i,n]of(0,u.V5)(e))this.StopByKey(n,t)}StopByKey(e,t){null==t&&(t=!0)
for(const[i,n]of(0,u.V5)(this.soundDataDict))for(const[i,s]of(0,u.V5)(n))if(s.key==e){if(0!=s.elementHandle)I.h.Instance_get().DeleteElementCombine(s.elementHandle)
else if(0!=s.soundHandle){const e=l.r.Inst_get().GetResCfgById(s.soundId)
y.y.Inst_get().SoundStop(s.soundHandle,e.fadeout,t)}return this.ResetSettingVolume(s.soundId),s.Recyle(),n.Remove(s),void this.PrintSound(s.soundId)}}ExistByKey(e){
for(const[t,i]of(0,u.V5)(this.soundDataDict))for(const[t,n]of(0,u.V5)(i))if(n.key==e)return!0
return!1}ExistByKeyList(e){if(null!=e){let t=0
for(;t<e.Count();){if(this.ExistByKey(e[t]))return!0
t+=1}}return!1}FilterByGroup(e){const t=l.r.Inst_get().GetResCfgById(e),i=l.r.Inst_get().GetGroupLimit(t.groupId),n=this.soundDataDict.LuaDic_GetItem(t.groupId)
if(null!=n&&n.Count()>=i){if(this.enableLog){const s=o.M.Replace((0,c.T)("音效{0}不能播放,"),"{0}",o.M.IntToString(e)),l=o.M.Replace((0,
c.T)("因为它所属的音效组{0}的上限是"),"{0}",o.M.IntToString(t.groupId)),a=o.M.Replace((0,c.T)("{0},当前该组中播放的音效有"),"{0}",o.M.IntToString(i)),r=o.M.Replace((0,
c.T)("{0}个,分别是:"),"{0}",n.Count().toString())
let d=""
for(const[e,t]of(0,u.V5)(n))""==d?d=o.M.IntToString(t.soundId):d+=`,${o.M.IntToString(t.soundId)}`
const h=s+(l+(a+(r+d)))
S.Y.Log(h)}return!1}return!0}FilterByMutex(e){const t=l.r.Inst_get().GetResCfgById(e)
if(0==t.type)return!0
let i="",n=0
for(const[s,a]of(0,u.V5)(this.soundDataDict))for(const[s,r]of(0,u.V5)(a)){
if(l.r.Inst_get().GetResCfgById(r.soundId).type==t.type&&(this.enableLog&&(""==i?i=o.M.IntToString(r.soundId):i+=`,${o.M.IntToString(r.soundId)}`),n+=1,n>=t.coexistence)){
if(this.enableLog){const s=o.M.Replace((0,c.T)("音效{0}不能播放,"),"{0}",o.M.IntToString(e))+(o.M.Replace((0,c.T)("因为它的互斥类型{0}的上限是"),"{0}",o.M.IntToString(t.type))+(o.M.Replace((0,
c.T)("{0},当前该互斥类型中播放的音效已经有"),"{0}",o.M.IntToString(t.coexistence))+(o.M.Replace((0,c.T)("{0}个,分别是:"),"{0}",o.M.IntToString(n))+i)))
S.Y.Log(s)}return!1}}return!0}ResetSettingVolume(e){if(l.r.Inst_get().GetSoundGroup(e)==g.G.DEFAULT_SOUND_GROUP){const e=a.g.Inst_get().systemModel
if(null!=e&&null!=e._systemSetting){const t=1*e._systemSetting.musicOption/100
y.y.Inst_get().SoundSetGroupVolume(g.G.BACKGROUND_SOUND_GROUP,t)
const i=1*e._systemSetting.soundOption/100
y.y.Inst_get().SoundSetGroupVolume(g.G.EFFECT2D_SOUND_GROUP,i)}}}PlayButtonSound(t=null){o.M.IsNullOrEmpty(t)&&(t=r.E.s_Empty),e.Inst.PlayByResName(t)}PrintSound(e){
if(this.enableLog){let t=""
for(const[e,i]of(0,u.V5)(this.soundDataDict))for(const[e,n]of(0,u.V5)(i))""==t?t=o.M.IntToString(n.soundId):t+=`,${o.M.IntToString(n.soundId)}`
const i=o.M.Replace((0,c.T)("回收了音效{0},剩下在播放的音效列表为:"),"{0}",o.M.IntToString(e))
let n=(0,c.T)("空")
""!=t&&(n=o.M.Replace("{0}","{0}",t))
const s=i+n
S.Y.Log(s)}}},T._inst=null,T.increaseKey=0,P=C=T,w="Inst",R=[n.Vx],D=Object.getOwnPropertyDescriptor(C,"Inst"),L=C,E={},Object.keys(D).forEach((function(e){E[e]=D[e]})),
E.enumerable=!!E.enumerable,E.configurable=!!E.configurable,("value"in E||E.initializer)&&(E.writable=!0),E=R.slice().reverse().reduce((function(e,t){return t(P,w,e)||e}),E),
L&&void 0!==E.initializer&&(E.value=E.initializer?E.initializer.call(L):void 0,E.initializer=void 0),void 0===E.initializer&&(Object.defineProperty(P,w,E),E=null),C)
var P,w,R,D,L,E},34297:(e,t,i)=>{i.d(t,{L:()=>d})
var n=i(35128),s=i(98885),l=i(85602),a=i(62370)
class r{constructor(){this.soundId=0,this.genRate=0,this.delayTime=0}Parse(e){const t=s.M.Split(e,a.o.s_UNDER_CHAR)
null!=t&&(t.count>=1&&(this.soundId=s.M.String2Int(t[0])),t.count>=2?this.genRate=s.M.String2Int(t[1]):this.genRate=1e4,t.count>=3&&(this.delayTime=s.M.String2Int(t[2])))}}class o{
constructor(){this.unitList=null}Parse(e){this.unitList=new l.Z
const t=s.M.Split(e,s.M.s_CCD_CHAR_DOT)
if(null!=t&&0!=t.count){let e=0
for(;e<t.count;){const i=new r
i.Parse(t[e]),this.unitList.Add(i),e+=1}}}}class d{constructor(){this.groupList=null,this.commList=null,this.commListListRate=null}Parse(e){this.groupList=new l.Z,
this.commList=null,this.commListListRate=new l.Z(3)
const t=s.M.Split(e,a.o.s_UNDER_LINE)
if(null!=t&&0!=t.count){let e=0
for(;e<t.count;){const i=new o
i.Parse(t[e]),this.groupList.Add(i),e+=1}}}GetSoundListByRate(){const e=Math.floor(n.p.RandomMinMax(0,3))
let t=this.commListListRate[e]
if(null!=t)return t
t=new l.Z,this.commListListRate[e]=t
const i=n.p.RandomMinMax(0,1e4)
let s=0
for(;s<this.groupList.Count();){let e=0
const n=this.groupList[s]
let l=0
for(;l<n.unitList.Count();){const s=n.unitList[l]
if(e+=s.genRate,e>=i){t.Add(s)
break}l+=1}s+=1}return t}GetSoundList(){if(null!=this.commList)return this.commList
this.commList=new l.Z
let e=0
for(;e<this.groupList.Count();){const t=this.groupList[e]
let i=0
for(;i<t.unitList.Count();){const e=t.unitList[i]
this.commList.Add(e),i+=1}e+=1}return this.commList}}},7866:(e,t,i)=>{i.d(t,{_:()=>I})
var n=i(12338),s=i(98885),l=i(85602),a=i(38836),r=i(38045),o=i(68662),d=i(66788),h=i(99294),u=i(30849),c=i(60069)
class I extends u.C{constructor(){super(),this._zhubaos=null,this._fenbaos=null,this._customInitView=null,this._fenbaoSpecial=null,this._zhubaos=new l.Z,this._fenbaos=new l.Z}
InitView(){if(null!=this._customInitView)this._customInitView()
else{let e=1,t=1
for(let i=1;i<=100;i++){const n=this.CreateComponentBinder(c.r,i)
if(null==n)break
{const i=h.z.name(n)
let s=i
if(null!=this[i])if("zb"==i||"fb"==i){let l="zb"==i&&e||t
for(s=i+l;null!=this[s];)l+=1,s=i+l
this[s]=n,this._InitPackageComponentList(s,n),"zb"==i?e=l+1:t=l+1}else d.Y.LogError(`SplitePackageToolView can not has same name property ${i}`)
else this[s]=n,this._InitPackageComponentList(s,n)}}}this.SetData()}_InitPackageComponentList(e,t){if("gameObject"!=e&&"table"==typeof t&&(0,
r.t2)(t,c.r))if(s.M.StartsWith(e,"zb"))this._zhubaos.Add(t)
else if(s.M.StartsWith(e,"fb")){const i=2
if(e.length>2&&"_"==e[i+1]){const n=s.M.IndexOf(e,"_",i+1),a=s.M.SubStringWithLen(e,i+1,n-i-1)
null==this._fenbaoSpecial&&(this._fenbaoSpecial={})
let r=this._fenbaoSpecial[a]
null==r&&(r=new l.Z,this._fenbaoSpecial[a]=r),r.Add(t)}else this._fenbaos.Add(t)}}SetData(){const e=o.D.IsFenBao(!0)
if(n.K.SetActiveObjs(!e,this._zhubaos),n.K.SetActiveObjs(e,this._fenbaos),null!=this._fenbaoSpecial){const e=o.D.curOtherPackageName
for(const[t,i]of(0,a.X)(this._fenbaoSpecial))n.K.SetActiveObjs(t==e,i)}}Clear(){super.Clear()}Destroy(){super.Destroy()}}},5924:(e,t,i)=>{i.d(t,{C:()=>h})
var n=i(13195),s=i(98130),l=i(85602),a=i(38962),r=i(38836),o=i(66788)
class d{constructor(){this._callTimer=null,this._calcTime=0,this._delayTime=0,this._repeatTime=1,this._action=null,this._param=null,this._deleg=null,this._exeTime=0,
this._isFrameLoop=!1,this._isCleared=!1,this.key=-1}Init(e,t,i=null,n=null,s=null,l=null,a=null){null==t&&o.Y.LogError(`${t}nil`),this._callTimer=e,this._delayTime=t,
this._repeatTime=n,this._action=i,this._deleg=s,this._param=l,this._isCleared=!1,this._isFrameLoop=a}Execute(){this._isCleared||(this._exeTime+=1,
null!=this._param||null!=this._deleg?null!=this._deleg&&this._deleg(this.key,this._param):null!=this._action&&this._action())}CheckAllDelegate(){}IsTimerOut_get(){
return!!this._isCleared||(this._isFrameLoop?(this._calcTime+=1,this._calcTime>=this._delayTime&&(this._calcTime=0,!0)):(this._calcTime+=this._callTimer.distanceTime,
this._calcTime>=this._delayTime&&(this._calcTime-=this._delayTime,!0)))}Refresh(){this._calcTime=0}IsRepeatOver_get(){
return!!this._isCleared||-1!=this._repeatTime&&this._exeTime>=this._repeatTime}IsRepeatOverReady(e){return!!this._isCleared||-1!=this._repeatTime&&(null==e&&(e=1),
this._exeTime+e>=this._repeatTime)}IsSameAction(e){return e==this._action}IsSameDelegate(e){return e==this._deleg}Clear(){this._calcTime=0,this._exeTime=0,this._isFrameLoop=!1,
this._action=null,this._param=null,this._deleg=null,this._isCleared=!0,this._action=null,this._param=null,this._deleg=null}TriggerLeftTime(){if(this._isCleared)return-1
let e=this._delayTime-this._calcTime
return e<0&&(e=0),e}}class h extends n.W{constructor(){super(),this._actionlist=null,this.distanceTime=0,this._delayList=null,this._waitdelayList=null,this._pool=null,
this._delayDic=null,this._recordTime=0,this._actionlist=new l.Z,this._delayList=new l.Z,this._waitdelayList=new l.Z,this._pool=new l.Z,this._delayDic=new a.X}InitSingleton(){}
UnInitSingleton(){}SingletonUpdate(){this._SingletonUpdate(),this.PushDataToList()}static Inst_get(){return null==h._Inst&&(h._Inst=new h),h._Inst}_SingletonUpdate(){
this.distanceTime=0!=this._recordTime?cus.currTime-this._recordTime:0,this._recordTime=cus.currTime,this.ExecuteAction(),this.UIUpdate()}PushDataToList(){
const e=this._waitdelayList.Count()
if(e>0){let t=0
for(;t<e;)this._delayList.Add(this._waitdelayList[t]),t+=1
this._waitdelayList.Clear()}}CallLater(e){null!=e&&this._actionlist.IndexOf(e,0)<0&&this._actionlist.Add(e)}Remove(e){if(null!=e){let t=this._actionlist.Count()-1
for(;t>=0;){if(this._actionlist[t]==e){this._actionlist.RemoveAt(t)
break}t-=1}}}CheckAllDelegate(){for(const[e,t]of(0,r.vy)(this._delayList))t.CheckAllDelegate()}ExecuteAction(){let e=this._delayList.Count()
if(e>0){let t=null,i=0
for(;i<e;)t=this._delayList[i],t.IsTimerOut_get()&&(t.IsRepeatOverReady(1)&&(this._delayList.Remove(t),this._delayDic.LuaDic_Remove(t.key),this._pool.Add(t),i-=1,e-=1),t.Execute(),
t.IsRepeatOver_get()&&t.Clear()),i+=1}}UIUpdate(){const e=this._actionlist.Count()
if(e>0){let t=null,i=0
for(;i<e;){if(t=this._actionlist[i],t(),this.IsBreakExcute())return void this._actionlist.RemoveRange(0,i)
i+=1}this._actionlist.Clear()}}IsBreakExcute(){return!1}SetInterval(e=null,t=null,i=null){null==i&&(i=-1)
const n=this.GetHandler()
if(null!=e)return n.Init(this,t,e,i,null,null,!1),n.key
o.Y.LogError("回调函数为空")}ReSetIntervalTime(e,t){const i=this.GetHandlerByKey(e)
null!=i&&(i._delayTime=t)}RefrshIntervalTimer(e){const t=this.GetHandlerByKey(e)
null!=t&&t.Refresh()}UpdateSpeed(e,t,i){const n=this.GetHandlerByKey(e)
null!=n&&(n._delayTime=s.GF.INT(n._delayTime/(i/t)),n._calcTime=s.GF.INT(n._calcTime/(i/t)))}SetIntervalForParm(e,t,i,n){if(null==i&&(i=-1),null==e)return o.Y.LogError("回调函数为空"),-1
const s=this.GetHandler()
return s.Init(this,t,null,i,e,n,!1),s.key}SetFrameLoop(e,t,i){if(null==i&&(i=-1),null==e)return o.Y.LogError("回调函数为空"),-1
const n=this.GetHandler()
return n.Init(this,t,e,i,null,null,!0),n.key}SetFrameLoopForParm(e,t,i,n){if(null==i&&(i=-1),null==e)return o.Y.LogError("回调函数为空"),-1
const s=this.GetHandler()
return s.Init(this,t,null,i,e,n,!0),s.key}GetHandler(){let e=null
return 0==this._pool.Count()?e=new d:(e=this._pool[0],this._pool.RemoveAt(0)),e.key=this.getHandlerKey(),this._waitdelayList.Add(e),this._delayDic.LuaDic_AddOrSetItem(e.key,e),e}
getHandlerKey(){for(h.increaseKey+=1,h.increaseKey==s.GF.INT32_MAX_VALUE_get()&&(h.increaseKey=1);this._delayDic.LuaDic_ContainsKey(h.increaseKey);)h.increaseKey+=1
return h.increaseKey}GetHandlerByKey(e){if(e<=0)return null
let t=null
return t=this._delayDic[e],null!=t?t:null}ClearInterval(e){if(null==e||e<=0)return 0
const t=this.GetHandlerByKey(e)
return null!=t&&t.Clear(),0}ClearLoop(e){return this.ClearInterval(e)}TriggerLeftTime(e){const t=this.GetHandlerByKey(e)
return null==t?-1:t.TriggerLeftTime()}GetTriggerParam(e){const t=this.GetHandlerByKey(e)
return null==t?null:t._param}GetRepeatTime(e){const t=this.GetHandlerByKey(e)
return null==t?0:t._repeatTime}}h.MAX_EXECUTE_TIME=20,h._Inst=null,h.increaseKey=1},76544:(e,t,i)=>{i.d(t,{p:()=>l})
var n=i(5924)
class s{constructor(){this.playFunId=-1}Invoke(e,t){this.Stop(),this.playFunId=n.C.Inst_get().SetInterval(e,t,1)}Stop(){
-1!=this.playFunId&&(n.C.Inst_get().ClearInterval(this.playFunId),this.playFunId=-1)}}class l{constructor(){this.funMap=new Map}InvokeFrame(e,t){this.Invoke(e,t*l.SPAN_FRAME)}
Invoke(e,t){if(this.funMap.has(e))this.funMap.get(e).Invoke(e,t)
else{const i=new s
this.funMap.set(e,i),i.Invoke(e,t)}}Stop(e){const t=this.funMap.get(e)
t&&(this.funMap.delete(e),t.Stop())}Clear(){this.funMap.forEach((e=>{e.Stop()})),this.funMap.clear()}}l.SPAN_FRAME=33},66788:(e,t,i)=>{i.d(t,{Y:()=>r})
var n=i(98130),s=i(77546),l=i(86133)
class a{}a.Error=1,a.Warning=2,a.Normal=3
class r{static SetDebugEnable(e,t){}static SetEnableLog(e){}static Log(e,t,i){null==t&&(t=!0),t&&console.log(`[${n.GF.MTimer_get()}] ${e}`)}static LogWarning(e){
r.Log(`<color=red>WARNING:${e}</color>`,!0,a.Warning)}static LogGreen(e){r.Log(`${(0,l.T)("<color=green>程序打印:")}${e}</color>`,!0,a.Normal)}static LogGMInEditor(e){}
static LogError(e){console.error(`[${n.GF.MTimer_get()}] ${e}`)}static LogBool(e){e?r.Log("true",!0):r.Log("false",!0)}static Info(e){s.s.Info(e)}static SInfo(e){s.s.Info(e)}}
r.LOG_MESSAGE=!0},65733:(e,t,i)=>{i.d(t,{C:()=>n})
class n{}n.LOG_ELEMENT=!1,n.LOG_CXH=!1,n.LOG_GX=!1,n.LOG_SOCKET=!1,n.LOG_SMMOVE=!1},52726:(e,t,i)=>{i.d(t,{F:()=>n})
class n{}n.UpAlert=-1,n.Effect=0,n.Msg=1,n.Tip=2,n.Alert=3,n.Story=4,n.MainUI=5,n.Photograph=6,n.NpcTalkUI=7,n.DefaultUI=8,n.Head=9,n.MiracleUIEffect=10,n.PhotoHide=11,n.Sound=12},
995:(e,t,i)=>{i.d(t,{K:()=>n})
class n{}n.Default="Default",n.Left="Left",n.Right="Right",n.Right2="Right2",n.Right3="Right3",n.Up="Up",n.Down="Down",n.Down2="Down2",n.Down3="Down3",n.Expbar="Expbar",
n.DefaultLeft=1,n.DefaultRight=2,n.DefaultRight2=3,n.DefaultRight3=4,n.DefaultUp=5,n.DefaultDown=6,n.DefaultDown2=7,n.DefaultDown3=8,n.MainLeft=9,n.MainRight=10,n.MainUp=11,
n.MainDown=12,n.MainDown2=13,n.NpcRight=14,n.ExpbarDown=15},98789:(e,t,i)=>{i.d(t,{$:()=>n})
class n{}n.eCustom=0,n.eCenter=1,n.eLeft=2,n.eTop=3,n.eRight=4,n.eBottom=5,n.eLeftTop=6,n.eRightTop=7,n.eLeftBottm=8,n.eRightBottom=9},61911:(e,t,i)=>{i.d(t,{f:()=>u})
var n=i(34565),s=i(17409),l=i(28287),a=i(98130),r=i(85602),o=i(38962),d=i(57834),h=i(5494)
class u extends n.I{constructor(...e){super(...e),this.showComp=null,this.isExclusionPanel=!1,this.DestoryPanelLevel=u.DestoryLevelForce,this.isKillAllExcluded=!1,
this.isCanNotBeExcluded=!1,this.exclusionIds=null,this.isPanelInited=!1,this.hasClose=!1,this.hasOpen=!1,this.m_eventDic=null,this.subLoadedChild=null,this.ignoreCheckClearGC=!1,
this.fullScreenColliderId=0,this._degf_OnFullScreenColliderInit=null,this.m_ReadyDestory=!1,this.m_AutoForceDestory=!1,this.registerUIScId=null,this.registerUIId=null,
this.isFirstPanel=!1,this.m_Destroyed=!1,this.onSetData=null}_initBinder(){super._initBinder(),this.m_eventDic=new o.X,this.subLoadedChild=new r.Z,
this._degf_OnFullScreenColliderInit=()=>this.OnFullScreenColliderInit(),this.InitHandlerMgr()}InitHandlerMgr(e){return this.m_handlerMgr.selfTarget_set(e?this:null),
this.m_handlerMgr}ShowCurrencyBar_get(){return l._.None}isShow_get(){return super.isShow_get()}isOpen_get(){return super.isOpen_get()}isOpenInHide_get(){
return null!=this.showComp&&(!!this.isPanelInited&&(!this.showComp.IsClose()&&!this.showComp.isShow))}uiId_get(){return super.uiId_get()}IsFirstPanel_Get(){return this.isFirstPanel
}IsForceCloseByGoAccess(){return!1}AddExclusion(e){this.exclusionIds=e}setId(e,t,i){super.setId(e,t,i)}InitById(e,t,i){this.isPanelInited=!0,super.setId(e,t,i)}
__InternalSetData(e){this.SetData(e),null!=this.onSetData&&this.onSetData()}OnAddToSceneBefore(){this.hasOpen||(this.hasOpen=!0,this.hasClose=!1,
null!=this.showComp&&null!=this.showComp.param_get()&&this.showComp.param_get().isDefaultUITween&&(PanelSoundMgr.inst_get().PlayOpenSound(this.showComp.uId),
this.showComp.uId!=h.I.SettingMainPanel&&(u.snapshotCount+=1,1==u.snapshotCount&&LuaSoundBridgeMgr.Inst_get().ActiveSnapshot("UIOpening")))),this.OnAddToScene(),
this.hasOpen&&this.RegUIShow()}OnAddToScene(){}RegUIShow(){null!=this.registerUIScId&&INS.uIShowShortCut.RegUIShowDic(this.registerUIScId,this.registerUIId)}UnRegUIShow(e){
null!=this.registerUIScId&&(INS.uIShowShortCut.UnRegUIShowDic(this.registerUIScId),null!=e&&e&&(this.registerUIScId=null))}ClearBefore(){this.hasClose||(this.hasClose=!0,
this.hasOpen=!1,null!=this.showComp&&null!=this.showComp.param_get()&&this.showComp.param_get().isDefaultUITween),this.RemoveFullScreenCollider(),
null!=this.m_handlerMgr&&this.m_handlerMgr.Clear()}Clear(){this.ClearBefore(),this.RemoveFullScreenCollider(),null!=this.m_handlerMgr&&this.m_handlerMgr.Clear(),super.Clear()}
IsDestroyed(){return this.m_Destroyed}Destroy(){this.IsDestroyed()||(this.showComp=null,this.m_eventDic.LuaDic_Clear(),this.m_eventDic=null,super.Destroy())}SetChildDepth(e){
UIShowMgr.inst.SetChildDepth(this.FatherId,e)}GetListener(e){let t=null
return this.m_eventDic.LuaDic_ContainsKey(e)?t=this.m_eventDic[e]:(t=new d.i,this.m_eventDic.LuaDic_AddOrSetItem(e,t)),t}GetRemoveListener(e){
return this.m_eventDic.LuaDic_ContainsKey(e)?this.m_eventDic[e]:null}AddSubmitEvent(e,t){this.GetListener(e).RegistonSubmit(t)}RemoveSubmitEvent(e,t){
const i=this.GetRemoveListener(e)
null!=i&&i.RemoveonSubmit(t)}AddClickEvent(e,t){this.GetListener(e).RegistonClick(t)}RemoveClickEvent(e,t){const i=this.GetRemoveListener(e)
null!=i&&i.RemoveonClick(t)}AddDoubleClickEvent(e,t){this.GetListener(e).RegistonDoubleClick(t)}RemoveDoubleClickEvent(e,t){const i=this.GetRemoveListener(e)
null!=i&&i.RemoveonDoubleClick(t)}AddHoverEvent(e,t){this.GetListener(e).RegistonHover(t)}RemoveHoverEvent(e,t){const i=this.GetRemoveListener(e)
null!=i&&i.RemoveonHover(t)}AddPressEvent(e,t){this.GetListener(e).RegistOnPress(t)}RemovePressEvent(e,t){const i=this.GetRemoveListener(e)
null!=i&&i.RemoveOnPress(t)}AddSelectEvent(e,t){this.GetListener(e).RegistonSelect(t)}RemoveSelectEvent(e,t){const i=this.GetRemoveListener(e)
null!=i&&i.RemoveonSelect(t)}AddScrollEvent(e,t){this.GetListener(e).RegistonScroll(t)}RemoveScrollEvent(e,t){const i=this.GetRemoveListener(e)
null!=i&&i.RemoveonScroll(t)}AddDragStartEvent(e,t){this.GetListener(e).RegistonDragStart(t)}RemoveDragStartEvent(e,t){const i=this.GetRemoveListener(e)
null!=i&&i.RemoveonDragStart(t)}AddDragOverEvent(e,t){this.GetListener(e).RegistonDragOver(t)}RemoveDragOverEvent(e,t){const i=this.GetRemoveListener(e)
null!=i&&i.RemoveonDragOver(t)}AddDragOutEvent(e,t){this.GetListener(e).RegistonDragOut(t)}RemoveDragOutEvent(e,t){const i=this.GetRemoveListener(e)
null!=i&&i.RemoveonDragOut(t)}AddDragEndEvent(e,t){this.GetListener(e).RegistonDragEnd(t)}RemoveDragEndEvent(e,t){const i=this.GetRemoveListener(e)
null!=i&&i.RemoveonDragEnd(t)}AddKeyEvent(e,t){this.GetListener(e).RegistonKey(t)}RemoveKeyEvent(e,t){const i=this.GetRemoveListener(e)
null!=i&&i.RemoveonKey(t)}AddTooltipEvent(e,t){this.GetListener(e).RegistonTooltip(t)}RemoveTooltipEvent(e,t){const i=this.GetRemoveListener(e)
null!=i&&i.RemoveonTooltip(t)}GetFullScreenColliderId(){return this.fullScreenColliderId}AddFullScreenCollider(e,t,i,n,l){null==l&&(l=!0),null==n&&(n=!0),(0,s.D1)(e,t)}
OnFullScreenColliderInit(){}RemoveFullScreenCollider(e){(0,s.Rt)(this)}DoReShow(){}DoHide(){}DoExclusive(){}}u.DestoryLevelForce=a.GF.INT32_MAX_VALUE_get(),
u.DestoryLevel0=a.GF.INT32_MIN_VALUE_get(),u.DestoryLevel3=3072,u.DestoryLevel4=4096,u.snapshotCount=0},30849:(e,t,i)=>{i.d(t,{C:()=>l})
var n=i(84501),s=i(28192)
class l extends n.X{constructor(...e){super(...e),this.m_Destroyed=!1,this._m_handlerMgr=null,this._all_delegate_cache_=null}get m_handlerMgr(){
return this._m_handlerMgr||(this._m_handlerMgr=s.h.Get()),this._m_handlerMgr}CheckNotGCBehaviour(){}InitHandlerMgr(e){}SetHandlerMgr(e){}__InitNeedClearCls(){}
CreateComponent(e,t){}CreateComponentBinder(e,t){}setId(e,t,i){}setPrefabRootId(e){}setBinderId(e,t,i){}IsDestroyed(){return this.m_Destroyed}Clear(){this.m_Destroyed}Destroy(){}
RemoveAllBehaviourValue(){}__DoOnDestroy(e){}}},60069:(e,t,i)=>{i.d(t,{r:()=>s})
var n=i(84501)
class s extends n.X{constructor(...e){super(...e),this.ComponentId=0,this.FatherComponentID=null,this.FatherId=0,this._createStack=null,this._gameObjectPath=null,this._type_=null,
this.isQuickActive=null,this.hideV3=null}ToInstanceKey(){return 1e10*this.FatherId+this.ComponentId}IsRootPrefab(){return 0==this.ComponentId&&0!=this.FatherId}GetCreateStack(){
return""}GetTypeName(){return""}GetInternalCallBacks(){return null}IsBinder(){}IsBinderSubComponent(e){}CloneIdTo(e){e.FatherId=this.FatherId,
e.FatherComponentID=this.FatherComponentID,e.ComponentId=this.ComponentId}setId(e,t,i){this.FatherId=e,this.ComponentId=s._CalComponentId(e,t,i),this.InitView()}
static _CalComponentId(e,t,i){if(null==t)return i
return 100*t+i}CreateComponent(e,t){}setBinderId(e,t,i){}_UpdateObjPath(){}CreateComponentBinder(e,t){}InitView(){}GetEnabled(){return!1}SetEnabled(e,t){}isActiveAndEnabled(){
return!1}SetColliderEnable(e){}IsObjectExist(){return!1}IsComponentExist(){return!1}IsNull(){return!1}IsNullWithErr(){return!1}IsPrefabBinderExist(){return!1}GetPanelDeepth(){
return 0}setIdSrc(e,t,i){this.FatherId=e,this.ComponentId=i,this.FatherComponentID=t,this.InitView()}AddComponent(e,t){return null}CreateSubComponent(e,t){return null}
InstantiateComponent(e,t){return null}FindComponent(e,t,i,n){return null}ResetTransform(){}SetParent(e,t,i){return!1}SetParentToLayer(e){}SetParentActive(e){}RemoveParent(){}
GetPosition(){return null}SetPosition(e){}SetRotate(e){}SetLocalRotate(e){}SetLocalRotateXYZ(e,t,i){}GetRotate(){return null}GetLocalRotate(){return null}GetLocalPosition(){
return null}GetLocalPositionXYZ(){}SetLocalPosition(e){}SetLocalPositionV2(e){}SetLocalPositionXYZ(e,t,i){}GetScale(){return null}GetLocalScale(){return null}SetLocalScale(e){}
SetLocalScaleXYZ(e,t,i){}SetEulerAngles(e){}SetEulerAnglesXYZ(e,t,i){}GetEulerAngles(){return null}GetLocalEulerAngles(){return null}SetLocalEulerAngles(e){}
SetLocalEulerAnglesXYZ(e,t,i){}WorldToLocalMatrixMultiplyPoint3x4(e){return null}WorldToLocalMatrixMultiplyPoint3x4XYZ(e,t,i){}InverseTransformPoint(e){return null}
TransformPoint(e){return null}name(){return""}SetName(e){}get activeInHierarchy(){return!1}activeSelf(){return!1}SetActive(e,t,i){}SetRuleDepth(e){}GetBoundsSize(){return null}
LayerIsShowInCamera(e){}}s.increaseKey=1},51868:(e,t,i)=>{i.d(t,{$:()=>l})
var n=i(28192),s=i(84501)
class l extends s.X{constructor(...e){super(...e),this.onSetData=null,this.panelParent=null,this.registerUIScId=null,this.registerUIId=null,this._def__ItemClickHandler=null,
this.m_handlerMgr=null}_initBinder(){super._initBinder(),this.m_handlerMgr=n.h.Get()}RegUIShow(){this.registerUIScId}UnRegUIShow(){this.registerUIScId}__InternalSetData(e){
this.SetData(e),null!=this.onSetData&&this.onSetData()}SetData(e){}Clear(){null!=this.m_handlerMgr&&this.m_handlerMgr.Clear(),this.onClick=null,this.onSetData=null}}},
36334:(e,t,i)=>{i.d(t,{b:()=>h})
var n=i(18998),s=i(75507),l=i(28287),a=i(86209),r=i(86871),o=i(38045),d=i(61911)
class h{constructor(e,t,i,n,s,l,a,r,o,d){this.loadPaths=null,this.parent=null,this.viewCls=null,this.initViewHandler=null,this.loadedHandler=null,this.openHandler=null,
this.setDataParam=null,this.destroyHandler=null,this.rootUIFatherId=null,this.showCharacterTab=null,this.view=null,this.isShowing=!1,this.isLoading=!1,this.isShow=!1,
this._degf__LoadedHandler=null,this.loadPaths=e,this.parent=t,this.viewCls=i,this.initViewHandler=n,this.loadedHandler=a,this.openHandler=r,this.setDataParam=l,
this.destroyHandler=o,this.rootUIFatherId=s,this.showCharacterTab=d}static New(e,t,i,n,s,l,a,r,o,d){return new h(e,t,i,n,s,l,a,r,o,d)}ShowView(){this.isShow=!0,
null==this.view?0==this.isLoading&&(this.isLoading=!0,this._LoadedHandler()):this._ShowViewAfterInit()}HideView(){this.isShow=!1,
null!=this.view&&1==this.isShowing&&(this.view.node&&this.view.node.SetActive(!1),__$LaunchLogicBridge._clearBinderObject(this.view)),this.isShowing=!1}Clear(){this.HideView()}
Destroy(){null!=this.view&&__$LaunchLogicBridge._destroyBinderObject(this.view),this.isLoading=!1,this.isShow=!1,this.isShowing=!1,this.view=null,this.loadPaths=null,
this.parent=null,this.viewCls=null,this.initViewHandler=null,this.loadedHandler=null,this.openHandler=null,this.setDataParam=null,this.destroyHandler=null,this.rootUIFatherId=null,
this.showCharacterTab=null}_LoadedHandler(){let e=this.loadPaths[0].substring(this.loadPaths[0].lastIndexOf("/")+1,this.loadPaths[0].length)
const t=s.o.getPrefab(e)
let i=(0,n.instantiate)(t)
this.parent instanceof n.Node?this.parent.addChild(i):this.parent.node.addChild(i),this.isLoading=!1,this.view=i.getCNode(this.viewCls),
null!=this.initViewHandler?this.initViewHandler(this.view):(0,r.I)(this.view),this._ShowViewAfterInit()}_ShowViewAfterInit(){if(0!=this.isShow){if(this.view.node.SetActive(!0),
this.isShowing=!0,null!=this.openHandler)this.openHandler(this.view)
else if((0,o.t2)(this.view,d.f))this.view.OnAddToScene()
else if(this.view.SetData(this.setDataParam),this.view.ShowCurrencyBar_get){let e=this.view.ShowCurrencyBar_get()
if(this.parent&&e==l._.None)return
a.w.Instance.ResetType(e)}}else this.view.node.SetActive(!1)}Test1(){return!0}S_Test(){return!0}}},15518:(e,t,i)=>{i.d(t,{k:()=>l})
var n=i(85602),s=i(61911)
class l extends s.f{constructor(...e){super(...e),this._subPanelDatas=new n.Z,this._curShowIdx=-1}InitView(){}ShowSubView(e){this._curShowIdx=e
for(let t=0;t<=this._subPanelDatas.Count()-1;t++){const i=this._subPanelDatas[t]
null!=i&&(t==e||i.HideView())}null!=this._subPanelDatas[e]&&this._subPanelDatas[e].ShowView()}GetSubView(e){const t=this._subPanelDatas[e]
return null!=t?t.view:null}Clear(){for(let e=0;e<=this._subPanelDatas.Count()-1;e++){const t=this._subPanelDatas[e]
null!=t&&(t.Clear(),t.view&&t.view.Clear&&t.view.Clear())}super.Clear()}DestroySubPanelDatas(){if(null!=this._subPanelDatas){for(let e=0;e<=this._subPanelDatas.Count()-1;e++){
const t=this._subPanelDatas[e]
null!=t&&t.Destroy()}this._subPanelDatas.Clear()}}Destroy(){this.DestroySubPanelDatas(),super.Destroy()}}},16968:(e,t,i)=>{i.d(t,{E:()=>I})
var n=i(92679),s=i(87923),l=i(2457),a=i(37648),r=i(68637),o=i(62734),d=i(97461),h=i(18202),u=i(30849),c=i(25035)
class I extends u.C{constructor(...e){super(...e),this._curRedPointId=0,this.itemData=null,this.isSelect=!1,this.cachRedpointShow=!1,this.useNewRedpointRule=!0,
this.isAddSelfClickEvent=!0,this.addSign=null,this.funId=null,this.addFunEv=null}SetData(e){"string"==typeof e&&(e=c.k.New(e,this._curRedPointId,this.funId,0)),this.itemData=e,
this.SetRedPointId(e.redPointId),this.SetFunId(e.funId),this.RegGuide(),this.ExceuteSign(),this.label.textSet(e.btnName),
this.isAddSelfClickEvent&&this.SetItemClickGo(this.btn.node)}SetGuideId(e,t){
null==this.itemData||e==this.itemData.guideId&&this.itemData.guideParam==t||(null!=this.itemData.guideId&&this.UnRegGuide(),this.itemData.guideId=e,this.itemData.guideParam=t,
this.RegGuide())}RegGuide(){if(null!=this.itemData.guideId){let e=this.btn.node
null!=e&&(this.m_handlerMgr.AddClickEvent(e,this.CreateDelegate(this.CheckGuide)),r.c.Inst.RegGameObject(this.itemData.guideId,e,this.itemData.guideParam))}}UnRegGuide(){
null!=this.itemData&&null!=this.itemData.guideId&&r.c.Inst.UnRegGameObject(this.itemData.guideId,this.itemData.guideParam)}CheckGuide(){
null!=this.itemData&&null!=this.itemData.guideId&&s.l.CheckTrigger(l.u.COND_CLICK_BTN_VAL,this.itemData.guideId,this.itemData.guideParam)}SetSelect(e){e?(this.btn.SetIsEnabled(!1),
this.bg1.SetActive(!0)):(this.btn.SetIsEnabled(!0),this.bg1.SetActive(!1)),e&&e!=this.isSelect&&this.PlayAni(),this.isSelect=e,null!=this.addSign&&this.addSign.SetSelected(e)}
PlayAni(){}UpdateRedPoint(e){this.redPoint&&this.redPoint.SetActive(e)}SetRedPointId(e){if(null==e&&(e=0),e<=0)return this._ClearRedPointId(),void this._OnRedPointUpdate(0)
e!=this._curRedPointId&&(this._ClearRedPointId(),this._curRedPointId=e,o.f.Inst.AddCallback(this._curRedPointId,this.CreateDelegate(this._OnRedPointUpdate)),
this._OnRedPointUpdate(e))}_ClearRedPointId(){this._curRedPointId>0&&(o.f.Inst.RemoveCallback(this._curRedPointId,this.CreateDelegate(this._OnRedPointUpdate)),
this._curRedPointId=0)}_OnRedPointUpdate(e,t,i,n){if(this.cachRedpointShow=!1,this._curRedPointId<=0)return void this.UpdateRedPoint(!1)
const s=o.f.Inst.GetData(this._curRedPointId)
null!=s&&(this.cachRedpointShow=s.show,this.UpdateRedPoint(s.show))}_CanUseNewRedpointRule(){
if(this._curRedPointId&&this._curRedPointId>0)return o.f.Inst.HasLeafRedPoint(this._curRedPointId)}SetFunId(e){this.funId=e,this.SetShowByFunId()}SetShowByFunId(){
if(null!=this.funId&&this.funId>0){const e=a.P.Inst_get().IsFunctionOpened(this.funId)
this.node.SetActive(e)}}_OnFunOpenHandler(){this.SetShowByFunId()}_ClearFunEvt(){this.addFunEv&&(this.addFunEv=!1,
d.i.Inst.RemoveEventHandler(n.g.FUNCTION_OPEN,this.CreateDelegate(this._OnFunOpenHandler)))}RefreshOpenState(){this.SetShowByFunId()}AddPlugin(e){this.addSign=e,
this.addSign.SetData(this.itemData),this.addSign.SetSelected(this.isSelect)}ExceuteSign(){null!=this.addSign&&null!=this.itemData&&this.addSign.Execute(this.itemData)}ClearSign(){
null!=this.addSign&&this.addSign.Clear()}DestroySign(){null!=this.addSign&&(this.addSign.Destroy(),h.g.DestroyUIObj(this.addSign))}Clear(){this.UnRegGuide(),this.funId=null,
this._ClearRedPointId(),this.ClearSign(),super.Clear()}Destroy(){this.DestroySign(),super.Destroy()}Test1(){return!0}S_Test(){return!0}}},3060:(e,t,i)=>{i.d(t,{v:()=>l})
var n=i(83908),s=i(16968)
class l extends((0,n.pA)(s.E)()){constructor(...e){super(...e),this.oldTitle=""}InitView(){this._curRedPointId=0,this.redPoint.SetActive(!1)}SetData(e){super.SetData(e),
this.lightLabel.node.SetActive(!1),this.label.node.SetActive(!0),this.label.textSet(this.itemData.btnName),this.lightLabel.textSet(this.itemData.btnName),
this.icon.node.SetActive(!1),this.bg1.SetActive(!1),this.bg2.SetActive(!0)}SetSelect(e){if(super.SetSelect(e),e){if(this.lightLabel.node.SetActive(!0),
this.label.node.SetActive(!1),this.icon.node.SetActive(!0),this.itemData){const e=INS.CommonUtil.GetCommonTabSpriteName(this.itemData.btnName,this.itemData.funId)
e&&this.icon.spriteNameSet("atlas/yeqian/"+e)}this.oldTitle!=this.itemData.btnName&&(this.oldTitle=this.itemData.btnName),this.bg2.SetActive(!1)
}else this.lightLabel.node.SetActive(!1),this.label.node.SetActive(!0),this.icon.node.SetActive(!1),this.bg2.SetActive(!0)}PlayAni(){super.PlayAni(),
this.tweenAlpha&&this.tweenScale&&(this.tweenAlpha.Play(),this.tweenScale.Play())}AddPlugin(e){}Test1(){return!0}S_Test(){return!0}}},26148:(e,t,i)=>{i.d(t,{P:()=>r})
var n=i(55492),s=i(35091),l=i(72005),a=i(30849)
class r extends a.C{constructor(...e){super(...e),this.itemdata=null,this.newsign=null,this.visible=null}InitView(){super.InitView(),this.newsign=this.CreateComponent(l.w,1)}
Execute(e){e.funId!=n.x.TRADING_MARKET&&e.funId!=n.x.ROLAND_TRADINGMARKET||(s._.Inst_get().newForFunDic[e.funId]?this.newsign.SetActive(!0):this.newsign.SetActive(!1))}SetData(e){
this.itemdata=e,this.m_handlerMgr.AddNotifyEvent(s._.Inst_get(),s._.UPDATE_NEW_SIGN,this.CreateDelegate(this.OnEvent))}OnEvent(){this.Execute(this.itemdata)}SetSelected(e){
this.visible=!e,this.SetActive(this.visible)}AddLis(){}RemoveLis(){}Clear(){this.RemoveLis(),this.m_handlerMgr.Clear(),super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}
S_Test(){return!0}}},25035:(e,t,i)=>{i.d(t,{k:()=>l})
var n=i(85602),s=i(16812)
class l extends s.k{constructor(e,t,i,n,s,l){super(),this.btnName=null,this.redPointId=null,this.funId=null,this.tabId=null,this.huodongId=null,this.guideId=null,
this.guideParam=null,this.btnName=e,this.redPointId=t,this.funId=i,this.tabId=n,this.huodongId=s,this.guideId=l}static New(e,t,i,n,s,a){return new l(e,t,i,n,s,a)}
static NewToList(e,t,i,s,a,r){const o=new n.Z
for(let d=0;d<=e.Count()-1;d++)o.Add(new l(n.Z.GetAtDefault(e,d,""),n.Z.GetAtDefault(t,d,0),n.Z.GetAtDefault(i,d,0),n.Z.GetAtDefault(s,d,0),n.Z.GetAtDefault(a,d,0),n.Z.GetAtDefault(r,d,null)))
return o}}},44255:(e,t,i)=>{i.d(t,{I:()=>w})
var n=i(18998),s=i(58542),l=i(83908),a=i(17409),r=i(92679),o=i(28287),d=i(51322),h=i(85602),u=i(38962),c=i(44434),I=i(32076),_=i(38836),p=i(67493),S=i(13602),g=i(5494),m=i(60130),f=i(15518)
class C{constructor(){this.bottombg=null}InitView(){}Clear(){}Destroy(){}}var T,y=i(3060),A=i(25035),P=i(72693)
let w=n._decorator.ccclass("TabCommonPanel")(T=class e extends((0,l.pA)(f.k)()){constructor(t){super(t),this.needCharacterTab=!0,this.tabIds=null,this.tabsObj=null,
this.bottomItems=null,this._curRedPointId=null,this._subPanelDatasDic=new u.X,this.__ui_ry_tabcommonpanel=null,this.selectCid=null,this.selectTabIdx0=null,this.selectTabIdx1=null,
this.names=null,this.bottomChangeBtnName=null,this.tab0RedPointList=null,this.tab1RedPointList=null,this.playAni=null,this.tab0FunIds=null,this.tab1FunIds=null,
this.curLoadStates={},this.isLoadIng=!1,this.curIndex=void 0,this.rightTabs=void 0,this.bottomTabs=void 0,this.startTime=void 0
const i=t.getComponent(c.m)
if(i)for(let t=0;t<i.items.length;t++){const n=i.items[t]
if(n.propType==c.m.PropType.clsname&&"TabCommonPanel"==n._clsName){const t=n._comp.node
if(t!=this.node){const i=t.getCNode(e),n=t.getComponent(c.m)
for(let e=0;e<n.items.length;e++){const t=n.items[e].propName
null==this[t]?this[t]=i[t]:console.error(`repeat propName '${t}'`)}}break}}}DoHide(){super.DoHide()}InitView(){super.InitView(),this.selectCid=-1,this.selectTabIdx0=-1,
this.selectTabIdx1=-1,this.names=null,this.bottomChangeBtnName=!1,this.tab0RedPointList=null,this.tab1RedPointList=null,this.InitViewEx(),
this.bottomTabGrid2&&this.bottomTabGrid2.SetInitInfo("ui_ry_bottombg",null,C)}InitViewEx(){}OnAddToScene(){this.ResetToScene(),0!=this.playAni&&this.PlayAni()}ResetToScene(){
this.AddLis(),this.UpdateAnchors(),this.SetViewConfig()}PlayAni(){}UpdateView(){}SetViewConfig(){}ShowCurrencyBar_get(){return o._.ShowAll}_OnSelectCharacterBeforeUpdate(){}
_OnSelectTab0BeforeUpdate(e,t){null!=this._subPanelDatas&&this.selectTabIdx0>=0&&this.selectTabIdx0<this._subPanelDatas.Count()&&this.ShowSubView(this.selectTabIdx0),
this.bottomChangeBtnName&&this.titleLabel.textSet(this.names[this.selectTabIdx0])}_OnSelectTab1BeforeUpdate(e){}OnCloseClick(){this.removeSelfPanel()}removeSelfPanel(){
const e=this.node.parent
if(e)for(let t=0;t<e.components.length;t++){const i=e.components[t]
if(i._panelID)return void(0,a.sR)(i._panelID)}super.removeSelfPanel(),(0,a.qJ)(g.I.AlliancePanel)&&(0,a.Yp)(g.I.CurrencyBar)}PalyCloseAni(e,t,i){null==i&&(i=(0,
I.v)(this.OnCloseClick,this)),null!=i&&this.m_handlerMgr.SetInterval(i,100,1),this.OnCloseClick()}SelectView(e,t,i){t=INS.LuaUIUtil.GetSelectedIndex(t,this.tab0RedPointList),
this.selectCid=e,this.selectTabIdx0=t,this.selectTabIdx1=i,this.needCharacterTab&&(this.bottomTabGrid.node.active&&(this._UpdateTableSelect0(),this._OnSelectTab0BeforeUpdate()),
this.rightTabGrid.node.active&&(this._UpdateTableSelect1(),this._OnSelectTab1BeforeUpdate()),
this.ui_charactertab.node.active&&(this.ui_charactertab.SetCurSelectIdx(this.selectCid,!0,!1),this._OnSelectCharacterBeforeUpdate())),this.isLoadIng||this.UpdateView()}
SelectCharacter(e,t,i){null==i&&(i=!0),this.selectCid=this.GetRoleRedpointId(e),
this.needCharacterTab&&(this.ui_charactertab.node.active&&this.ui_charactertab.SetCurSelectIdx(this.selectCid,!0,!1),i&&this._OnSelectCharacterBeforeUpdate()),
t&&this.curLoadStates[e]&&this.UpdateView()}SelectTab0(e,t,i){i||(e=INS.LuaUIUtil.GetSelectedIndex(e,this.tab0RedPointList))
const n=this.selectTabIdx0
this.selectTabIdx0=e,this._UpdateTableSelect0(i),n==this.selectTabIdx0&&this.isLoadIng||(!this.curLoadStates[e]&&this.LoadView(e),
this.curLoadStates[e]&&this._OnSelectTab0BeforeUpdate(i,n),t&&this.curLoadStates[e]&&this.UpdateView())}SelectTab1(e,t,i){
i||(e=INS.LuaUIUtil.GetSelectedIndex(e,this.tab1RedPointList)),this.selectTabIdx1=e,this._UpdateTableSelect1(i)
let n=(0,a.Ue)(this._panelID)
n&&!n[1]&&(e=this.selectTabIdx0),!this.curLoadStates[e]&&this.LoadView(e),this.curLoadStates[e]&&this._OnSelectTab1BeforeUpdate(i),t&&this.curLoadStates[e]&&this.UpdateView()}
Clear(){this.unschedule(this._delayUpSelect0),this.RemoveLis(),this._ClearTabsObj(),this.playAni=!0,super.Clear()}Destroy(){this._ClearTabsObj(),this.DestorySubPanelDatasDic(),
super.Destroy(),this.curLoadStates=null}AddLis(){this.m_handlerMgr.AddEventMgr(r.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors)),
this.m_handlerMgr.AddEventMgr(r.g.FUNCTION_OPEN,this.CreateDelegate(this.OnFunOpenHandler)),this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.PalyCloseAni))}
OnFunOpenHandler(){if(null!=this.bottomTabGrid.itemList&&this.bottomTabGrid.itemList[0]&&this.bottomTabGrid.itemList[0].RefreshOpenState){const e=this.bottomTabGrid.itemList.length
for(let t=0;t<=e-1;t++)this.bottomTabGrid.itemList[t].RefreshOpenState()
this.bottomTabGrid.Reposition()}}RemoveLis(){}_SetTabData0(e,t,i,n,s,l,a,r,o,d){if(this.bottomTabs=r,e){this._ClearTabsObj(),this.bottomTabGrid.node.SetActive(!0),
null==this.bottomTabGrid.m_onReposition&&(this.bottomTabGrid.SetInitInfo("ui_ry_bottom_tab",null,y.v,this.CreateDelegate(this._OnClickBottomItem)),
this.bottomTabGrid.OnReposition_set(this.CreateDelegate(this.OnRepositionBottom))),this.tab0RedPointList=i,this.tab0FunIds=a
const e=new h.Z
this.bottomChangeBtnName&&(this.names=t)
let n=0
null!=d&&(n=d.count)
for(let s=0;s<=t.Count()-1;s++){const l=A.k.New(t[s],h.Z.GetAtDefault(i,s,0),h.Z.GetAtDefault(a,s,0),h.Z.GetAtDefault(r,s,0),h.Z.GetAtDefault(o,s,0))
s<n&&(l.guideId=d[s]),e.Add(l)}this.bottomTabGrid.data_set(e),this.bottomTabGrid.node.parent.transform.width=e.length*this.bottomTabGrid.cellWidth
}else this.bottomTabGrid.node.SetActive(!1)}_SetTabData0ToTabsObj(e,t,i,n,s,l){if(e){this._ClearTabsObj(),this.bottomTabGrid.node.SetActive(!0),this.bottomItems=t,
this.tab0RedPointList=i
let e=0
null!=l&&(e=l.count)
const a=new h.Z
for(let n=0;n<=t.Count()-1;n++){const s=t[n],r=h.Z.GetAtDefault(i,n,0)
n<e&&s.SetGuideId(l[n]),s.SetRedPointId(r),a.Add(s.btn),this.m_handlerMgr.AddClickEvent(s.btn,this.CreateDelegate(this._OnClickBottomItemHandler))}
this.tabsObj=new d.G(a,n,this.bottomTabGrid,this.node),this.tabsObj.isAddTabEvent=s,this.tabsObj.RefreshTab()}else this.bottomTabGrid.node.SetActive(!1)}_ClearTabsObj(){
null!=this.tabsObj&&(this.tabsObj.Destroy(),this.tabsObj=null)}_SetTabData1(e,t,i,n,s,l,a){if(this.rightTabs=s,this.tab1RedPointList=i,this.tab1FunIds=n,e){
this.rightTabGrid.node.SetActive(!0),null==this.rightTabGrid.m_onReposition&&(this.rightTabGrid.SetInitInfo("ui_ry_right_tab",null,P.j,this.CreateDelegate(this._OnClickRightItem)),
this.rightTabGrid.OnReposition_set(this.CreateDelegate(this.OnRepositionRight)))
let e=0
null!=l&&(e=l.count)
const r=new h.Z
for(let o=0;o<=t.Count()-1;o++){const d=A.k.New(t[o],h.Z.GetAtDefault(i,o,0),h.Z.GetAtDefault(n,o,0),h.Z.GetAtDefault(s,o,0),h.Z.GetAtDefault(a,o,0))
o<e&&(d.guideId=l[o]),r.Add(d)}this.rightTabGrid.data_set(r),null!=this.rightBg3&&(t.Count()>0?(this.rightBg1.SetActive(!1),this.rightBg2.SetActive(!0),
this.rightBg3.node.SetActive(!0)):(this.rightBg1.SetActive(!0),this.rightBg2.SetActive(!1),this.rightBg3.node.SetActive(!1)))}else this.rightTabGrid.node.SetActive(!1),
null!=this.rightBg3&&(this.rightBg1.SetActive(!0),this.rightBg2.SetActive(!1),this.rightBg3.node.SetActive(!1))}_SetCharacterTabData(e,t,i,n){
this.needCharacterTab&&null!=this.ui_charactertab&&(e?(this.ui_charactertab.node.SetActive(!0),this.ui_charactertab.SetData(t),this.ui_charactertab.SetRedPointId(i),
1==n&&(this.ui_charactertab.onChanged=this.CreateDelegate(this._OnCharacterTabChange))):this.ui_charactertab.node.SetActive(!1))}OnRepositionBottom(){
null==this.tabsObj&&this.InitTabsObject(),this._UpdateTableSelect0(),this.bottomTabGrid.Reposition()}InitTabsObject(){if(null!=this.tabIds){const e=new h.Z
let t=0
for(;t<this.bottomTabGrid.itemList.Count();)e.Add(this.bottomTabGrid.itemList[t].btn),t+=1
this.tabsObj=new d.G(e,this.tabIds,this.bottomTabGrid,this.node),this.tabsObj.RefreshTab()}}OnRepositionRight(){this.rightTabGrid.Reposition(),this._UpdateTableSelect1()}
_OnCharacterTabChange(){this.SelectCharacter(this.ui_charactertab.GetCurPlayerInfo().createIdx,!0)}SetCharacterTabVisible(e){
null!=this.ui_charactertab&&this.ui_charactertab.node.SetActive(e)}ShowSubView(e){
null!=this._subPanelDatas[e]&&(null!=this._subPanelDatas[e].showCharacterTab&&this.SetCharacterTabVisible(this._subPanelDatas[e].showCharacterTab),
this._subPanelDatas[e].parent==this&&null!=this.subwidget&&(this._subPanelDatas[e].parent=this.subwidget)),this.isLoadIng||super.ShowSubView(e)}_OnClickBottomItem(e,t,i){let n=0
n=this.bottomTabGrid.itemList.IndexOf(e),this.SelectTab0(n,!0,!0),e.CheckGuide()}_OnClickBottomItemHandler(e,t){let i=-1
null!=this.tabsObj&&(i=this.tabsObj.GetBtnIdx(e)),this.SelectTab0(i,!0,!0)}_UpdateTableSelect0(e){if(this.bottomTabGrid.itemList)if(null!=this.bottomItems){
const e=this.bottomItems.Count(),t=this.selectTabIdx0
for(let i=0;i<=e-1;i++){const e=this.bottomItems[i]
i!=t?e.SetSelect(!1):e.SetSelect(!0)}}else{const e=this.bottomTabGrid.itemList.Count()
for(let t=0;t<=e-1;t++){const e=this.bottomTabGrid.itemList[t]
t!=this.selectTabIdx0?e.SetSelect(!1):(e.SetSelect(!0),this.CheckBottomClip())}}}CheckBottomClip(){}_OnClickRightItem(e,t,i){const n=this.rightTabGrid.itemList.IndexOf(e)
this.SelectTab1(n,!0,!0),e.CheckGuide()}_UpdateTableSelect1(e){if(null==this.rightTabGrid.itemList)return
const t=this.rightTabGrid.itemList.Count()
for(let e=0;e<=t-1;e++){const t=this.rightTabGrid.itemList[e]
t.useNewRedpointRule=!0,e!=this.selectTabIdx1?t.SetSelect(!1):t.SetSelect(!0)}}UpdateAnchors(){const e=m.O.GetUIWidth()
null!=this.bg1&&this.bg1.widthSet(e),null!=this.bg2&&this.bg2.widthSet(e),m.O.SetAnchorPos(this.leftTrans,!0,!1,0),m.O.SetAnchorPos(this.rightTrans,!1,!0,0)
const t=m.O.UIScreenNotchWidth
null!=this.ui_charactertab&&this.ui_charactertab.node.transform.SetLocalPositionXYZ(71+t,0,0)}OnAniPlayEnd(){INS.luaEventMgr.RaiseEvent(r.g.TabCommonOpenAniEnd,this.uiId_get())}
GetRoleRedpointId(e){return null!=e&&-1!=e?e:this.ui_charactertab.GetRedPointIndex()}GetSubPanelDatasInDic(e){return this._subPanelDatasDic.LuaDic_GetItem(e)}
RecyleSubPanelDatas(e){this.AddSubPanelDatas(e,this._subPanelDatas)}AddSubPanelDatas(e,t){let i=null
this._subPanelDatasDic.LuaDic_ContainsKey(e)&&(i=this._subPanelDatasDic.LuaDic_GetItem(e)),this._subPanelDatas!=i&&(this.DestoryOneSubPanelDatas(i),this._subPanelDatasDic[e]=t)}
SwitchSubPanelDatasInDic(e){return this.HideAllSubView(),this.GetSubPanelDatasInDic(e)}HideAllSubView(){
if(null!=this._subPanelDatas)for(let e=0;e<=this._subPanelDatas.Count()-1;e++){const t=this._subPanelDatas[e]
null!=t&&t.HideView()}}DestorySubPanelDatasDic(){if(this._subPanelDatasDic.LuaDic_Count()>0)for(const[e,t]of(0,_.V5)(this._subPanelDatasDic))this.DestoryOneSubPanelDatas(t)}
DestoryOneSubPanelDatas(e){if(null!=e){for(let t=0;t<=e.Count()-1;t++){const i=e[t]
null!=i&&i.Destroy()}e.Clear()}}GetRedTabIndex(e,t,i){return null==t&&(t=this.tab0RedPointList),null==i&&(i=this.tab0FunIds),INS.LuaUIUtil.GetSelectedIndex(e,t,i)}
getPrefabLoader(){return this.node.getOrAddComponent(S.A)}LoadView(e,t,i){if(console.log("进入load,index：",e),this.startTime=p.os.clock(),
!this._panelID)return void console.log("err: 动态加载，没找到_panelID")
let n,s=(0,a.U6)(this._panelID),l=(0,a.Ue)(this._panelID),r=this.bottomTabs?this.bottomTabs[e]:e,o=this.rightTabs?this.rightTabs[e]:e,d=l&&l[1]?o:r
if(s&&null==s[e]&&null!=s[999]&&(d=999),this.curIndex=e,s&&null!=s[d]){n=s[d],this.curLoadStates[d]=!1,this.isLoadIng=!0,n instanceof Array?this.getPrefabLoader().loadPrefabs(n,(0,
I.v)(this.LoadPrefbComplete,this),null,{index:e,panelId:this._panelID,tabsparams:l}):this.getPrefabLoader().loadPrefab(n,(0,I.v)(this.LoadPrefbComplete,this),null,{index:e,
panelId:this._panelID,tabsparams:l})}else this.LoadPrefbComplete(null,{index:e,panelId:this._panelID,tabsparams:l})}LoadPrefbComplete(e,t){
if(console.log("timeLoadEnd：",p.os.clock()-this.startTime),this.curLoadStates[t.index]=!0,this.curIndex!=t.index)return
let i=(0,a.Di)(t.panelId)
i!=s.C.closed&&i!=s.C.closing&&(this.isLoadIng=!1,t.tabsparams&&t.tabsparams[1]?this._OnSelectTab1BeforeUpdate():this._OnSelectTab0BeforeUpdate(),this.UpdateView())}
IsFirstPanel_Get(){return!0}})||T},72693:(e,t,i)=>{i.d(t,{j:()=>a})
var n=i(18998),s=i(83908),l=i(16968)
class a extends((0,s.pA)(l.E)()){constructor(...e){super(...e),this.line=null,this.redPoint=null,this.color1=null,this.color2=null}InitView(){this.redPoint=this.comm_sp_0015,
this._curRedPointId=0,this.redPoint.SetActive(!1)}SetData(e){super.SetData(e),null!=this.uispAni&&this.uispAni.node.SetActive(!1)}PlayAni(){super.PlayAni(),
null!=this.uispAni&&this.uispAni.node.SetActive(!0)}SetSelect(e){super.SetSelect(e),e?(this.label.color=new n.Color(110,87,78,255),
this.label.color=this.color1?this.color1:new n.Color(110,87,78,255)):(this.label.color=new n.Color(166,152,134,255),
this.label.color=this.color2?this.color2:new n.Color(166,152,134,255)),null!=this.uispAni&&(e||this.uispAni.node.SetActive(!1))}setColor(e,t){this.color1=e,this.color2=t}Test1(){
return!0}S_Test(){return!0}}},62085:(e,t,i)=>{i.d(t,{M:()=>h})
var n,s=i(18998),l=i(83908),a=i(48933),r=i(72693)
const{ccclass:o,property:d}=s._decorator
let h=o("TabCommonRightItem3")(n=class extends((0,l.pA)(r.j)()){constructor(...e){super(...e),this.retSize=null,this.redPoint=null}InitView(){this._curRedPointId=0,this.retSize=!0,
this.redPoint=this.redPoint1,this.newIcon&&this.newIcon.SetActive(!1)}SetSelect(e){e?(this.btn.SetIsEnabled(!1),this.btn1.node.SetActive(!0),this.btn2.SetActive(!1),
this.retSize&&(this.bg1.widthSet(178),this.bg1.heightSet(58),a.I.calVec0.Set(0,0,0),this.bg1.node.transform.SetLocalPosition(a.I.calVec0))):(this.btn.SetIsEnabled(!0),
this.btn1.node.SetActive(!1),this.btn2.SetActive(!0),null!=this.itemData&&this.label2.textSet(this.itemData.btnName),this.retSize&&(this.bg2.widthSet(132),this.bg2.heightSet(56),
a.I.calVec0.Set(22.4,0,0),this.bg2.node.transform.SetLocalPosition(a.I.calVec0))),this.isSelect=e}Test1(){return!0}S_Test(){return!0}})||n},19755:(e,t,i)=>{i.d(t,{N:()=>a})
var n=i(92679),s=i(8211),l=i(62085)
class a extends l.M{constructor(...e){super(...e),this.showNew=!1,this.showRedPoint=!1,this.index=0}InitView(){super.InitView()}SetData(e){super.SetData(e),
this.m_handlerMgr.AddEventMgr(n.g.MARKET_OLD_GOODS_UPDATE,this.CreateDelegate(this.UpdateNew)),this.UpdateNew()}UpdateNew(){this.showNew=s.N.GetInst().HasNew(this.itemData.funId),
this.newIcon.SetActive(this.showNew),this.UpdateRedPoint(this.showRedPoint)}UpdateRedPoint(e){this.showRedPoint=e,this.redPoint.SetActive(e&&!this.showNew)}}},73316:(e,t,i)=>{
i.d(t,{b:()=>h})
var n=i(83908),s=i(92679),l=i(8211),a=i(98885),r=i(38045),o=i(62370),d=i(72693)
class h extends((0,n.pA)(d.j)()){constructor(...e){super(...e),this.showNew=null,this.showRedPoint=null}InitView(){super.InitView(),this.newIcon.SetActive(!1)}SetData(e){
super.SetData(e),this.m_handlerMgr.AddEventMgr(s.g.MARKET_OLD_GOODS_UPDATE,this.CreateDelegate(this.UpdateNew)),this.UpdateNew()}UpdateNew(){if(!this.itemData)return
const e=a.M.Split(this.itemData.tabId,o.o.s_Arr_UNDER_CHAR_DOT),t=(0,r.aI)(e[0]),i=(0,r.aI)(e[1]),n=(0,r.aI)(e[2])
this.showNew=l.N.GetInst().HasNew(t,i,n),this.newIcon.SetActive(this.showNew),this.UpdateRedPoint(this.showRedPoint)}UpdateRedPoint(e){this.showRedPoint=e,
this.redPoint.SetActive(e&&!this.showNew)}Clear(){this.m_handlerMgr.RemoveEventMgr(s.g.MARKET_OLD_GOODS_UPDATE,this.CreateDelegate(this.UpdateNew)),super.Clear()}Destroy(){
super.Destroy()}}},68646:(e,t,i)=>{i.d(t,{l:()=>d})
var n=i(48933),s=i(99294),l=i(9986),a=i(93877),r=i(72005),o=i(16968)
class d extends o.E{constructor(...e){super(...e),this.line=null}InitView(){super.InitView(),this.bg1=this.CreateComponent(r.w,1),this.label=this.CreateComponent(a.Q,2),
this.redPoint=this.CreateComponent(s.z,3),this.line=this.CreateComponent(s.z,4),this.btn=this.CreateComponent(l.W,5),this._curRedPointId=0,this.redPoint.SetActive(!1)}SetSelect(e){
e?(this.btn.SetIsEnabled(!1),this.bg1.widthSet(130),this.bg1.heightSet(65),n.I.calVec0.Set(0,0,0),this.bg1.node.transform.SetLocalPosition(n.I.calVec0)):(this.btn.SetIsEnabled(!0),
this.bg1.widthSet(126),this.bg1.heightSet(64),n.I.calVec0.Set(-10,0,0),this.bg1.node.transform.SetLocalPosition(n.I.calVec0))}Test1(){return!0}S_Test(){return!0}}},56937:(e,t,i)=>{
i.d(t,{v:()=>r})
var n=i(78300),s=i(52726),l=i(995),a=i(98789)
class r{constructor(){this.layerType=s.F.MainUI,this.positionType=a.$.eCenter,this.pos=null,this.isLocalPos=!0,this.layerClickHandler=null,this.aniDir=l.K.Default,
this.isShowMask=!1,this.maskAlpha=.5,this.isSelfTween=!0,this.isCloseCamera=!0,this.isInitActive=!0,this.ReLoginOrChangeRoleIsDestroy=!0,this.isSetActiveClose=!0,
this.isDefaultUITween=!1,this.noTweenDirIndex=-1,this.viewClass=null,this.isExclusionPanel=!1,this.isCanNotBeExcluded=!1,this.pos=n.V.TEMP_VECTOR2D_get()}IsExeTween(){
return!(!this.isDefaultUITween||!this.isSelfTween)}}},13602:(e,t,i)=>{i.d(t,{A:()=>l})
var n=i(18998),s=i(75507)
class l extends n.Component{constructor(...e){super(...e),this._resIds=[]}loadPrefab(e,t,i,l){s.o.listenRes(s.o.loadRes(e,n.Prefab,null!=i?i:s.o.LoaderCache.RefTick),((e,i)=>{(0,
n.isValid)(this)&&null!=this._resIds&&0!=i&&(e&&this._resIds&&-1==this._resIds.indexOf(i)&&(this._resIds.push(i),s.o._$retainRes(i)),null!=t&&t(e||null,l))}))}loadPrefabs(e,t,i,l){
const a=this._resIds
if(!(0,n.isValid)(this)||null==a)return
let r=e.length
for(let o=0;o<e.length;o++)s.o.listenRes(s.o.loadRes(e[o],n.Prefab,null!=i?i:s.o.LoaderCache.RefTick),((e,i)=>{e&&i>0&&-1==a.indexOf(i)&&(a.push(i),s.o._$retainRes(i)),
null!=t&&(r--,0==r&&t(null,l))}))}releasePrefab(e){const t=this._resIds
if(!t)return
const i=s.o.getResId(e)
if(i>0){const e=t.indexOf(i)
e>=0&&(t.splice(e,1),s.o._$releaseRes(i))}}releaseAll(){const e=this._resIds
if(e&&e.length>0){for(let t=0;t<e.length;t++)s.o._$releaseRes(e[t])
e.length=0}}onDestroy(){this.releaseAll()}}},18202:(e,t,i)=>{i.d(t,{g:()=>f})
var n=i(18998),s=i(75507),l=i(85602),a=i(38962),r=i(3110),o=i(30438),d=i(38045),h=i(66788),u=i(61911),c=i(67885),I=i(38836),_=i(83540),p=i(5494)
class S{constructor(){this.pathsDic=null,this.pathsDic=new a.X}InitModuleID(){
let e=INS.ryTipCompFactory.GetAllTipCompPath(),t=new l.Z(["UIRoot","ui_comm_texture_head","ui_comm_sprite_head","ui_comm_fullscreencollider","ui_map_loading"])
this.AddInfo(p.I.eUIRoot,t),t=new l.Z(["ui_ry_tabcommonpanel","ui_ry_tabcommonpanel_custom","ui_ry_tabcommonpanel_nocharacter","ui_ry_tabcommonpanel_scrollright","ui_ry_tabcommonpanel_sign"]),
this.AddInfo(p.I.eTabCommon,t),t=new l.Z(["ui_innerlogin_loginpanel","ui_innerlogin_button"]),this.AddInfo(p.I.SelectServerList,t),
t=new l.Z(["ui_login_view","ui_loading_panel","ui_map_loading"]),this.AddInfo(p.I.Login,t),t=new l.Z(["ui_notice_view"]),this.AddInfo(p.I.NoticeUI,t),
t=new l.Z(["ui_gaininfonotice_view"]),this.AddInfo(p.I.GainInfoNoticeUI,t),t=new l.Z(["ui_create_role_view_ry"]),this.AddInfo(p.I.Createroleview_Ry,t),
t=new l.Z(["ui_select_role_view_ry"]),this.AddInfo(p.I.SelectRole_Ry,t),t=new l.Z(["ui_baseitem","ui_bag_itembg"])
for(const[e,i]of(0,I.V5)(c.S.COMP_DICT))null!=i.viewPath&&t.Add(i.viewPath)
this.AddInfo(p.I.BaseItem,t),t=new l.Z(["ui_characterui_characteruipanel","ui_characterui_characterview"]),this.AddInfo(p.I.CharacterUIPanel,t),
t=new l.Z(["ui_ry_bag_itemtippanel","ui_equiptip_suitattritem"]),t.AddRange(e),this.AddInfo(p.I.ItemTip,t),t=new l.Z(["ui_ry_tabcommonpanel","ui_bag_itembg"]),
this.AddInfo(p.I.eBagPanel,t),t=new l.Z(["ui_bag_sell","ui_bag_sellitem"]),this.AddInfo(p.I.eBagSellPanel,t),t=new l.Z(["ui_bag_sell_simple"]),
this.AddInfo(p.I.eBagSellSimplePanel,t),t=new l.Z(["ui_bag_bagexpandalert"]),this.AddInfo(p.I.eBagExpandAlert,t),t=new l.Z(["ui_bag_batchusealert"]),
this.AddInfo(p.I.BatchUserAlert,t),
t=new l.Z(["ui_ry_equiptip_panel","ui_equiptip_role_icon","ui_equiptip_role_icon_list","ui_equiptip_specialattr","ui_equiptip_suitattr","ui_equiptip_commonattr","ui_equiptip_demanditem","ui_equiptip_excellenceattr","ui_equiptip_extendbtn","ui_equiptip_elementattr"]),
t.AddRange(e),
this.AddInfo(p.I.EquipTip,t),t=new l.Z(["ui_ry_elementtip_panel","ui_equiptip_role_icon","ui_equiptip_role_icon_list","ui_equiptip_commonattr","ui_equiptip_extendbtn","ui_equiptip_elementattr"]),
t.AddRange(e),
this.AddInfo(p.I.ElementTip,t),t=new l.Z(["ui_ry_elecarvetip_panel","ui_equiptip_role_icon","ui_equiptip_role_icon_list","ui_equiptip_commonattr","ui_equiptip_extendbtn","ui_equiptip_elementattr"]),
t.AddRange(e),this.AddInfo(p.I.EleCarveTip,t),t=new l.Z(["ui_systemtips_tipmessagepanel","ui_systemtips_tipmessageitem"]),this.AddInfo(p.I.SystemCommonMessage,t),
t=new l.Z(["ui_systemtips_riversandlakessaid"]),this.AddInfo(p.I.RiversAndLakesSaid,t),t=new l.Z(["ui_systemtips_systemchannelpanel"]),this.AddInfo(p.I.SystemMessagePanel,t),
t=new l.Z(["ui_boss_bosspanel_ry"]),this.AddInfo(p.I.BossStatus,t),t=new l.Z(["ui_systemtips_selectcircle"]),this.AddInfo(p.I.SelectCircle,t),
t=new l.Z(["ui_topsmallmap_topmappanel","ui_topsmallmap_point","ui_topsmallmap_obj_item","ui_topsmallmap_monsterinfo","ui_topsmallmap_radartaskitem","ui_topsmallmap_radartransferitem","ui_topsmallmap_radarbossitem","ui_topsmallmap_radargoldmonsteritem","ui_topsmallmap_endpoint","ui_topsmallmap_teamitem","ui_topsmallmap_radarendpoint","ui_topsmallmap_relivepointitem","ui_topsmallmap_siegebuilditem","ui_topsmallmap_textitem","ui_topsmallmap_mapicon","ui_topsmallmap_gate_info_ry","ui_topsmallmap_gate_conetpoint","ui_asuramwar_bufficon","ui_topsmallmap_crossbossitem_ry","ui_maze_room_item","ui_maze_room_line_h","ui_maze_room_line_v"]),
this.AddInfo(p.I.TopSmallMap,t),t=new l.Z(["ui_bottomfunction_shortcutitem"]),this.AddInfo(p.I.ShortCutSelectPanel,t),t=new l.Z(["ui_bottomfunction_skilltips"]),
this.AddInfo(p.I.SkillTip,t),t=new l.Z(["ui_targetplayer_operationpanel"]),this.AddInfo(p.I.TargetPlayerPanelId,t),t=new l.Z(["ui_maptitle_title"]),this.AddInfo(p.I.MapTitle,t),
t=new l.Z(["ui_relive_relivepanel"]),this.AddInfo(p.I.Relive,t),t=new l.Z(["ui_relive_role_panel"]),this.AddInfo(p.I.ReliveRole,t),t=new l.Z(["ui_hang_mainpanel"]),
this.AddInfo(p.I.eHangMainPanel,t),t=new l.Z(["ui_hang_sreenicon"]),this.AddInfo(p.I.eHangStartIcon,t),t=new l.Z(["ui_hang_stopicon"]),this.AddInfo(p.I.eHangPauseIcon,t),
t=new l.Z(["ui_hang_selectskillpanel"]),this.AddInfo(p.I.eHangSelectSkillPanel,t),t=new l.Z(["ui_bag_bagitem"]),this.AddInfo(p.I.Task,t),
t=new l.Z(["ui_hang_selectskillcomponent"]),this.AddInfo(p.I.eHangSelectSkillComponent,t),t=new l.Z(["ui_icontips_panel"]),this.AddInfo(p.I.eIconTipsPanel,t),
t=new l.Z(["ui_lianjitips_panel"]),this.AddInfo(p.I.eLianjiTipsPanel,t),t=new l.Z(["ui_copybaseui_belialpanel"]),this.AddInfo(p.I.CopyBelialUIPanel,t),
t=new l.Z(["ui_copybaseui_belialsquareresult_ry"]),this.AddInfo(p.I.BelialResultPanel,t),t=new l.Z(["ui_copypanel_bloodtown"]),this.AddInfo(p.I.BloodTownPanel,t),
t=new l.Z(["ui_copypanel_bloodtown_rankview_ry"]),this.AddInfo(p.I.BloodTownRankPanel,t),t=new l.Z(["ui_belialsquare_view","ui_belialsquare_item","ui_baseitem"]),
this.AddInfo(p.I.BelialPanel,t),t=new l.Z(["ui_copybaseui_defeatpanel"]),this.AddInfo(p.I.CopyDefeatPanel,t),t=new l.Z(["ui_copybaseui_successpanel"]),
this.AddInfo(p.I.CopySuccessPanel,t),t=new l.Z(["ui_pk_tips"]),this.AddInfo(p.I.PkTipsPanel,t),t=new l.Z(["ui_bagextend_panel"]),this.AddInfo(p.I.eBagExtendPanel,t),
t=new l.Z(["ui_chat_showpanel","ui_chat_cell","ui_chat_face","ui_chat_showchannelitem","ui_mail_main","ui_mail_detail","ui_mail_infoitem","ui_chat_channelflag","ui_chat_totalcell","ui_comm_sprite_head","ui_comm_texture_head"]),
this.AddInfo(p.I.eChatShowPanel,t),t=new l.Z(["ui_rychat_mainpanel","ui_chat_copytip"]),this.AddInfo(p.I.eChatMainPanel,t),t=new l.Z(["ui_chat_copytip"]),
this.AddInfo(p.I.ChatCopyTipId,t),t=new l.Z(["ui_chat_hornpanel"]),this.AddInfo(p.I.eChatHornPanel,t),t=new l.Z(["ui_chat_taskdetail"]),this.AddInfo(p.I.eChatTaskDetailPanel,t),
t=new l.Z(["ui_chat_voice"]),this.AddInfo(p.I.eChatVoicePanel,t),t=new l.Z(["ui_chat_simplenotice"]),this.AddInfo(p.I.ChatSimplePanelId,t),t=new l.Z(["ui_collect_slider_head"]),
this.AddInfo(p.I.eCollectSliderUI,t),t=new l.Z(["ui_ry_tabcommonpanel"]),this.AddInfo(p.I.TreasurePanel,t),t=new l.Z(["ui_treasure_bosstip"]),this.AddInfo(p.I.eBossDropTipPanel,t),
t=new l.Z(["ui_copybaseui_copyentertimer"]),this.AddInfo(p.I.EnterCopyTime,t),t=new l.Z(["ui_copybaseui_inspirepanel"]),this.AddInfo(p.I.CopyInspire,t),
t=new l.Z(["ui_copybaseui_belielexp_panel","ui_copybaseui_belielexp_item"]),this.AddInfo(p.I.CopyExpBuff,t),
t=new l.Z(["ui_topsmallmap_mainmap","ui_topsmallmap_worldunlockeffect","ui_topsmallmap_transferitem","ui_topsmallmap_bossitem","ui_topsmallmap_obj_item","ui_topsmallmap_miracle_obj_item","ui_topsmallmap_goldmonsteritem","ui_topsmallmap_currentmapinfoitem_t","ui_topsmallmap_currentmapinfoitem","ui_topsmallmap_teamitem","ui_topsmallmap_monsterinfopanel","ui_smallmapbosstip","ui_smallmapmonstertip","ui_topsmallmap_monsterinfo_tip","ui_topsmallmap_monsterinfo","ui_bag_baseitem"]),
this.AddInfo(p.I.eMap,t),t=new l.Z(["ui_topsmallmap_gate_info_tip","ui_baseitem"]),this.AddInfo(p.I.eMapGateTip,t),t=new l.Z(["ui_map_pass_btn","ui_map_pass_flyeff"]),
this.AddInfo(p.I.eMapPassMainBtn,t),t=new l.Z(["ui_topsmallmap_updef_panel","ui_topsmallmap_updef_item","ui_comm_btn_close"]),this.AddInfo(p.I.eSmallUpDefPanel,t),
t=new l.Z(["ui_mail_main"]),this.AddInfo(p.I.MailMainPanel,t),t=new l.Z(["ui_mail_detail"]),this.AddInfo(p.I.MailDetailPanel,t),t=new l.Z(["ui_ry_tabcommonpanel_alliance"]),
this.AddInfo(p.I.AlliancePanel,t),t=new l.Z(["ui_alliance_apply","ui_alliance_applyinfo_new","ui_comm_texture_head","ui_comm_sprite_head"]),this.AddInfo(p.I.AllianceApplyPanel,t),
t=new l.Z(["ui_alliance_createalliance"]),this.AddInfo(p.I.CreateAlliancePanel,t),t=new l.Z(["ui_alliance_notice"]),this.AddInfo(p.I.AllianceNoticePanel,t),
t=new l.Z(["ui_alliance_appoint"]),this.AddInfo(p.I.AllianceAppointPanel,t),t=new l.Z(["ui_alliance_expel"]),this.AddInfo(p.I.AllianceExpelPanel,t),
t=new l.Z(["ui_alliance_quittip"]),this.AddInfo(p.I.AllianceQuitPanel,t),t=new l.Z(["ui_appliance_assigntip"]),this.AddInfo(p.I.AllianceAssignPanel,t),
t=new l.Z(["ui_systemtips_consumeusetip"]),this.AddInfo(p.I.ConsumeUseTip,t),t=new l.Z(["ui_maparea_mapareatips"]),this.AddInfo(p.I.MapAreaTips,t),
t=new l.Z(["ui_alliance_invite"]),this.AddInfo(p.I.AllianceInvitePanel,t),t=new l.Z(["ui_copybase_bloodtownevaluate"]),this.AddInfo(p.I.BloodTownEvaluatePanel,t),
t=new l.Z(["ui_copybase_bloodtownsuccess"]),this.AddInfo(p.I.BloodTownSuccessPanel,t),t=new l.Z(["ui_copybase_bloodtownresult_ry"]),this.AddInfo(p.I.BloodTownResultPanel,t),
t=new l.Z(["ui_copybase_bloodtownetrace"]),this.AddInfo(p.I.BloodTownTracePanel,t),t=new l.Z(["ui_copybase_bloodtownstagetip"]),this.AddInfo(p.I.eBloodTownStageTipView,t),
t=new l.Z(["ui_gm_gmpanel","ui_gm_searchitem","ui_gm_gmbtn","ui_gm_sontabbtn"]),this.AddInfo(p.I.GmPanel,t),t=new l.Z(["ui_gm_minigmpanel"]),this.AddInfo(p.I.GmMiniPanel,t),
t=new l.Z(["ui_copybaseui_bloodtownloading"]),this.AddInfo(p.I.eBloodTownLoading,t),t=new l.Z(["ui_character_newtitletipview"]),this.AddInfo(p.I.TitleTip,t),
t=new l.Z(["ui_character_newtotaltip","ui_character_newtitleattritem"]),this.AddInfo(p.I.TitleTotalTip,t),
t=new l.Z(["ui_market_mainpanel","ui_comm_onetreetitleitem","ui_comm_onetreeitem","ui_market_malltabitem"]),this.AddInfo(p.I.MarketPanel,t),t=new l.Z(["ui_market_mainview_ry"]),
this.AddInfo(p.I.MarketPanel_ry,t),t=new l.Z(["ui_market_gold_mainview_ry"]),this.AddInfo(p.I.Market_Gold_Panel_ry,t),t=new l.Z(["ui_market_itemchangebuytip"]),
this.AddInfo(p.I.MarketItemBuyTip,t),t=new l.Z(["ui_market_itemchangeauctiontip"]),this.AddInfo(p.I.MarketItemAuctionTip,t),
t=new l.Z(["ui_forge_equipmasterview","ui_forge_equipmaster_propertyblock","ui_forge_equipmaster_propertyitem"]),this.AddInfo(p.I.eAdditionMasterPanel,t),
t=new l.Z(["ui_market_getauctionpanel"]),this.AddInfo(p.I.GetAuctionPanel,t),t=new l.Z(["ui_welfare_tabpanel"]),this.AddInfo(p.I.WelfarePanelId,t),
t=new l.Z(["ui_ry_tabcommonpanel"]),this.AddInfo(p.I.LostAbyss,t),t=new l.Z(["ui_hang_recommend"]),this.AddInfo(p.I.RecommendHangPanel,t),t=new l.Z(["ui_inputnumberpanel"]),
this.AddInfo(p.I.InputNumberPanel,t),t=new l.Z(["ui_mainview_skilllist","ui_skill_effect"]),this.AddInfo(p.I.MainViewSkill,t),
t=new l.Z(["ui_mainview_panel","ui_ry_tabcommonpanel","ui_functionopen_spreaditem","ui_functionopen_spreaditem2","ui_functionopen_leftspreaditem","ui_shortcutgoods","ui_comm_fullscreenmask","ui_functionopen_pkfuncitem"]),
this.AddInfo(p.I.eMainViewPanel,t),t=new l.Z(["ui_mainview_expbar"]),this.AddInfo(p.I.eMainViewExp,t),
t=new l.Z(["ui_sw1tchtarget_panel","ui_sw1tchtarget_item","ui_comm_sprite_head","ui_comm_texture_head"]),this.AddInfo(p.I.SwitchTarget,t),t=new l.Z(["ui_settingmainpanel"]),
this.AddInfo(p.I.SettingMainPanel,t),t=new l.Z(["ui_setting_offlinerewardpanel"]),this.AddInfo(p.I.OffLineRewardPanel,t),
t=new l.Z(["ui_strengthen_strengthenmainpanel","ui_comm_onetreetitleitem","ui_comm_onetreeitem"]),this.AddInfo(p.I.eStrengthenPanel,t),t=new l.Z(["ui_pksw1tchpanel"]),
this.AddInfo(p.I.PkSwitchPanel,t),t=new l.Z(["ui_morepanel"]),this.AddInfo(p.I.MorePanel,t),t=new l.Z(["ui_task_mainui_panel","ui_task_mainui_item"]),
this.AddInfo(p.I.eTaskMainUI,t),t=new l.Z(["ui_transferjobpanel"]),this.AddInfo(p.I.TransferJobPanel,t),t=new l.Z(["ui_targetplayer_headpanel"]),
this.AddInfo(p.I.eTargetPlayerHeadPanel,t),t=new l.Z(["ui_targetplayer_head"]),this.AddInfo(p.I.eTargetPlayerHead,t),t=new l.Z(["ui_market_recharge_buytip"]),
this.AddInfo(p.I.RechargeBuyTip,t),t=new l.Z(["ui_treasure_killtip"]),this.AddInfo(p.I.eBossKillInfoTip,t),t=new l.Z(["ui_ry_compound_put_itemtip"]),
this.AddInfo(p.I.RyCompoundPutItemTip,t),t=new l.Z(["ui_ry_compound_peek_panel","ui_baseitem"]),this.AddInfo(p.I.RyCompoundPeekItemView,t),
t=new l.Z(["ui_ry_equipadvance_peek_panel","ui_baseitem"]),this.AddInfo(p.I.RyEquipAdvance,t),t=new l.Z(["ui_ry_equipadvance_success","ui_equipadvance_excellenceattr"]),
this.AddInfo(p.I.RyEquipAdvanceSuccess,t),t=new l.Z(["ui_ry_equipadvance_success2","ui_equipadvance_excellenceattr","ui_ry_equipadvance_show"]),
this.AddInfo(p.I.RyAngelEquipAdvanceSuccess,t),t=new l.Z(["ui_copybaseui_alliance_task_successpanel"]),this.AddInfo(p.I.AllianceTaskSuccessPanel,t),
t=new l.Z(["ui_divine_activeview"]),this.AddInfo(p.I.eDivineActive,t),t=new l.Z(["ui_ry_forge_panel"]),this.AddInfo(p.I.ForgePanel,t),t=new l.Z(["ui_alliance_leveluppanel"]),
this.AddInfo(p.I.AllianceLevelUpPanel,t),t=new l.Z(["ui_vitality_tips_panel"]),this.AddInfo(p.I.VitalityTipsPanel,t),t=new l.Z(["ui_alliance_operationpanel"]),
this.AddInfo(p.I.eAllianceOperationPanel,t),t=new l.Z(["ui_vitality_calendar_panel"]),this.AddInfo(p.I.VitalityCalendarPanel,t),t=new l.Z(["ui_activity_calendar_mainview"]),
this.AddInfo(p.I.VitalityCalendarTablePanel,t),t=new l.Z(["ui_dialogue_mianpanel","ui_dialogue_funbtn","ui_market_novice_item","ui_belialsquare_view","ui_copypanel_bloodtown"]),
this.AddInfo(p.I.eDialoguePanel,t),t=new l.Z(["ui_dialogue_handinpanel"]),this.AddInfo(p.I.HandInPanel,t),t=new l.Z(["ui_taozhuangronghe_view"]),this.AddInfo(p.I.eSuitFuseView,t),
t=new l.Z(["ui_taozhuangronghe_success_view","ui_taozhuangronghe_suitfuseattr"]),this.AddInfo(p.I.eSuitFuseSuccessView,t),
t=new l.Z(["ui_ry_tabcommonpanel_ranking","ui_ry_ranking_item"]),this.AddInfo(p.I.RankingPanel,t),t=new l.Z(["ui_elecarve_echoview"]),this.AddInfo(p.I.EleCarveEchoView,t),
t=new l.Z(["ui_elecarve_addview"]),this.AddInfo(p.I.EleCarveItemSelectView,t),t=new l.Z(["ui_elecarve_bagview"]),this.AddInfo(p.I.EleCarveBagView,t),
t=new l.Z(["ui_elecarve_successview"]),this.AddInfo(p.I.EleCarveSuccessView,t),t=new l.Z(["ui_elecaeve_resetview"]),this.AddInfo(p.I.EleCarveReSetView,t),
t=new l.Z(["ui_elecarve_echoactive_view"]),this.AddInfo(p.I.EleCarveEchoUpView,t),
t=new l.Z(["ui_friend_friendview","ui_bag_bagitem","ui_friend_frienditem","ui_comm_sprite_head","ui_comm_texture_head"]),this.AddInfo(p.I.eFriendView,t),
t=new l.Z(["ui_friend_reqlist","ui_ryfriend_additem","ui_comm_sprite_head","ui_comm_texture_head"]),this.AddInfo(p.I.eFriendReqListView,t),
t=new l.Z(["ui_friend_addfriend","ui_ryfriend_additem","ui_comm_sprite_head","ui_comm_texture_head"]),this.AddInfo(p.I.eFriendAddView,t),t=new l.Z(["ui_ranking_operationpanel"]),
this.AddInfo(p.I.RankCheckPlayerView,t),t=new l.Z(["ui_armyequip_armyequippanel"]),this.AddInfo(p.I.eArmyEquipView,t),t=new l.Z(["ui_recover_copycounttips_panel"]),
this.AddInfo(p.I.RecoverCopyCountTipsPanel,t),t=new l.Z(["ui_recover_taskrewardtips_panel"]),this.AddInfo(p.I.RecoverTaskRewardTipsPanel,t),
t=new l.Z(["ui_shortcut_select_panel","ui_bag_bagitem"]),this.AddInfo(p.I.eShortcutGoodsSelectPanel,t),
t=new l.Z(["ui_attrchangetip_tippanel","ui_attrchangetip_changeattritem","ui_attrchangetip_excellent"]),this.AddInfo(p.I.ChangeAttrPanel,t),t=new l.Z(["ui_map_change_progress"]),
this.AddInfo(p.I.MapChangeProgress,t),t=new l.Z(["ui_comm_currency_bar","ui_comm_currency_item"]),this.AddInfo(p.I.CurrencyBar,t),t=new l.Z(["ui_pandora_tipspanel"]),
this.AddInfo(p.I.PandoraTipsPanel,t),t=new l.Z(["ui_ry_pandoratip_panel"]),t.AddRange(e),this.AddInfo(p.I.RyPandoraTipsPanel,t),t=new l.Z(["ui_pandora_v1ptipspanel"]),
this.AddInfo(p.I.PandoraVipTipsPanel,t),t=new l.Z(["ui_pandora_selectitem_tipspanel"]),this.AddInfo(p.I.PandoraSelectPanel,t),t=new l.Z(["ui_pandora_rewardshowpanel"]),
this.AddInfo(p.I.PandoraRewardShowPanel,t),t=new l.Z(["ui_pandora_v1prewardshowpanel"]),this.AddInfo(p.I.PandoraVipRewardShowPanel,t),t=new l.Z(["ui_pandora_tipsinfopanel"]),
this.AddInfo(p.I.PandoraTipsInfoPanel,t),t=new l.Z(["ui_pandora_v1ptipsinfopanel"]),this.AddInfo(p.I.PandoraVipTipsInfoPanel,t),t=new l.Z(["ui_pandora_recharge_panel"]),
this.AddInfo(p.I.PandoraRechargePanel,t),t=new l.Z(["ui_map_loading"]),this.AddInfo(p.I.MapLoading,t),t=new l.Z(["ui_map_titledrifting"]),this.AddInfo(p.I.MapTitleDirfting,t),
t=new l.Z(["ui_common_timeinput"]),this.AddInfo(p.I.TimeInput,t),t=new l.Z(["ui_setting_lockscreenpanel"]),this.AddInfo(p.I.eLockScreenTip,t),
t=new l.Z(["ui_copybaseui_belielexpbuy_panel"]),this.AddInfo(p.I.eCopyBelielExpBuyPanel,t),t=new l.Z(["ui_copybaseui_copyinspirepanel"]),this.AddInfo(p.I.CopyInspireBtnPanel,t),
t=new l.Z(["ui_copybaseui_copyexppanel"]),this.AddInfo(p.I.CopyExpBtnPanel,t),t=new l.Z(["ui_copybaseui_sweeppanel_ry"]),this.AddInfo(p.I.CopySweepView,t),
t=new l.Z(["ui_copybase_lefttime"]),this.AddInfo(p.I.CopyLeftTimePanel,t),t=new l.Z(["ui_copybase_bloodtown_lefttime"]),this.AddInfo(p.I.CopyBloodTownLeftTimePanel,t),
t=new l.Z(["ui_copybaseui_bloodtown_gainaward"]),this.AddInfo(p.I.CopyBloodTownGainAwardPanel,t),t=new l.Z(["ui_openservice_mainpanel"]),this.AddInfo(p.I.OpenServicePanel,t),
t=new l.Z(["ui_treasure_rewardtip"]),this.AddInfo(p.I.WorldBossRewardTip,t),t=new l.Z(["ui_treasure_teamdamagerank","ui_treasure_teamdamagerankitem"]),
this.AddInfo(p.I.BossTeamDamageRankPanel,t),t=new l.Z(["ui_copybaseui_commonrightview","ui_bossassistpanel","ui_bossassist_item"]),this.AddInfo(p.I.BossMemberDamagePanel,t),
t=new l.Z(["ui_bossassisttip"]),this.AddInfo(p.I.BossMemberDamageTip,t),t=new l.Z(["ui_npchead_mainpanel"]),this.AddInfo(p.I.NpcHeadPanel,t),t=new l.Z(["ui_comm_buyalertpanel"]),
this.AddInfo(p.I.BuyAlertPanel,t),t=new l.Z(["ui_comm_buy_tip"]),this.AddInfo(p.I.BuyTipPanel,t),t=new l.Z(["ui_skill_tips_toppanel","ui_skill_tips_descitem"]),
this.AddInfo(p.I.eSkillTips,t),t=new l.Z(["ui_skill_mainview_tips","ui_skill_tips_descitem","ui_skill_tips_level_desc"]),this.AddInfo(p.I.eSkillMainViewTips,t),
t=new l.Z(["ui_skill_new_to_skill_ry"]),this.AddInfo(p.I.eSkillNewView,t),t=new l.Z(["ui_skill_new_to_other_ry"]),this.AddInfo(p.I.eSkillNewViewByOther,t),
t=new l.Z(["ui_skill_transferskill"]),this.AddInfo(p.I.eSkillNewTransferView,t),t=new l.Z(["ui_boss_buffpanel_ry","ui_boss_buffitem_ry"]),this.AddInfo(p.I.BossBuffPanel,t),
t=new l.Z(["ui_collect_btn"]),this.AddInfo(p.I.CollectBtnPanel,t),t=new l.Z(["ui_mail_delete"]),this.AddInfo(p.I.MailDeletePanel,t),
t=new l.Z(["ui_task_mainpanel","ui_task_treetitleitem","ui_task_treeitem"]),this.AddInfo(p.I.TaskMainPanel,t),t=new l.Z(["ui_firstcharge_mainpanel"]),
this.AddInfo(p.I.FirstChargePanel,t),t=new l.Z(["ui_spaceorigin_root_ry"]),this.AddInfo(p.I.SpaceOriginRootView,t),t=new l.Z(["ui_spaceorigin_ry"]),
this.AddInfo(p.I.SpaceOriginView,t),t=new l.Z(["ui_spaceorigin_notice_ry"]),this.AddInfo(p.I.SpaceOriginNoticeView,t),
t=new l.Z(["ui_ry_tabcommonpanel_crossbattle","ui_topsmallmap_crossbossitem_ry"]),this.AddInfo(p.I.CrossBattleRootView,t),t=new l.Z(["ui_crossboss_statusview_ry"]),
this.AddInfo(p.I.CrossBossStatusView,t),t=new l.Z(["ui_crossboss_usebadgeview"]),this.AddInfo(p.I.CrossBossUseBadgeView,t),
t=new l.Z(["ui_character_attrintructionpanel","ui_characterui_attrintructionitem"]),this.AddInfo(p.I.AttrIntructionPanel,t),t=new l.Z(["ui_forge_luckytip"]),
this.AddInfo(p.I.LuckyAddTipPanel,t),t=new l.Z(["ui_treasure_karima_relivepanel"]),this.AddInfo(p.I.eKarimaRelivePanel,t),t=new l.Z(["ui_sceneani_panel"]),
this.AddInfo(p.I.SceneAniPanel,t),t=new l.Z(["ui_comm_texttippanel"]),this.AddInfo(p.I.TextTipPanel,t),t=new l.Z(["ui_asuram_mainpanel"]),this.AddInfo(p.I.AsuramMainPanel,t),
t=new l.Z(["ui_systemtips_bufftippanel","ui_systemtips_tipmessageitem"]),this.AddInfo(p.I.BuffTipPanel,t),t=new l.Z(["ui_infotip_tipview","ui_infotip_currency"]),
this.AddInfo(p.I.InfoTipPanel,t),t=new l.Z(["ui_commonhint_hintpanel"]),this.AddInfo(p.I.eCommonHintPanel,t),t=new l.Z(["ui_commonhint_hintpanel"]),
this.AddInfo(p.I.eCommonHintTopLayerPanel,t),t=new l.Z(["ui_gold_monster_panel","ui_gold_monster_team","ui_comm_sprite_head","ui_comm_texture_head"]),
this.AddInfo(p.I.GoldNpcPanel,t),t=new l.Z(["ui_asuram_copyresultpanelnew"]),this.AddInfo(p.I.AsuramCopySuccessPanel,t),t=new l.Z(["ui_mainview_fpspanel"]),
this.AddInfo(p.I.FPSPanel,t),t=new l.Z(["ui_buttoneffect_panel"]),this.AddInfo(p.I.eButtonEffectPanel,t),t=new l.Z(["ui_setting_offlinedielogtip","ui_setting_offlinedielogitem"]),
this.AddInfo(p.I.OffLineDieLogTip,t),t=new l.Z(["ui_setting_offlinerecoverpanel"]),this.AddInfo(p.I.OffLineRecoverPanel,t),t=new l.Z(["ui_loading_panel"]),
this.AddInfo(p.I.eLoadEffectPanel,t),t=new l.Z(["ui_screen_notch_view"]),this.AddInfo(p.I.eNotchView,t),t=new l.Z(["ui_treasure_dropview","ui_treasure_dropinfo"]),
this.AddInfo(p.I.BossDropPanel,t),t=new l.Z(["ui_photograph_capturepanel"]),this.AddInfo(p.I.PhotographCapturePanel,t),
t=new l.Z(["ui_alliance_alliancehallpanel","ui_alliance_alliancehallitem"]),this.AddInfo(p.I.AllianceBuildHallPanel,t),
t=new l.Z(["ui_alliance_alliancevaultpanel","ui_alliance_alliancevaultitem"]),this.AddInfo(p.I.AllianceBuildVaultPanel,t),
t=new l.Z(["ui_alliance_alliancetecpanel","ui_alliance_alliancetecitem"]),this.AddInfo(p.I.AllianceBuildTecPanel,t),
t=new l.Z(["ui_alliance_alliancewarehousepanel","ui_alliance_alliancewarehouseitem","ui_alliance_alliancewarehousenotify"]),this.AddInfo(p.I.AllianceWarehousePanel,t),
t=new l.Z(["ui_alliance_alliancebuildsetpanel"]),this.AddInfo(p.I.AllianceSetPanel,t),t=new l.Z(["ui_alliance_alliancebuilddonatepanel","ui_bag_bagitem"]),
this.AddInfo(p.I.AllianceDonatePanel,t),t=new l.Z(["ui_treasure_bosshometip"]),this.AddInfo(p.I.BossHomeTipPanel,t),t=new l.Z(["ui_treasure_worldbossruletip"]),
this.AddInfo(p.I.WorldBossRulePanel,t),t=new l.Z(["ui_treasure_neutrolbossruletip"]),this.AddInfo(p.I.NeutrolBossRulePanel,t),t=new l.Z(["ui_treasure_v1pbossruletip"]),
this.AddInfo(p.I.VipBossRulePanel,t),t=new l.Z(["ui_treasure_karimabossruletip"]),this.AddInfo(p.I.KarimaBossRulePanel,t),t=new l.Z(["ui_comm_copymonsterrefreshpanel"]),
this.AddInfo(p.I.CopyMonsterTip,t),t=new l.Z(["ui_comm_copynpcrefreshpanel"]),this.AddInfo(p.I.CopyNPCTip,t),t=new l.Z(["ui_gate_reward_tips_ry","ui_baseitem"]),
this.AddInfo(p.I.MapPassRewardTips,t),t=new l.Z(["ui_map_pass_info_tip","ui_baseitem"]),this.AddInfo(p.I.MapPassNextTips,t),t=new l.Z(["ui_map_pass_fb_info","ui_baseitem"]),
this.AddInfo(p.I.MapPassFbInfo,t),t=new l.Z(["ui_map_pass_fb_successpanel_ry","ui_baseitem"]),this.AddInfo(p.I.MapPassFbSuccessView,t),t=new l.Z(["ui_map_pass_fb_failpanel_ry"]),
this.AddInfo(p.I.MapPassFbFailView,t),t=new l.Z(["ui_unlockboss_fb_info"]),this.AddInfo(p.I.UnlockMapBossFbView,t),t=new l.Z(["ui_alliance_blogview"]),
this.AddInfo(p.I.AllianceBlogPanel,t),t=new l.Z(["ui_mainview_hangexptip"]),this.AddInfo(p.I.MainViewEffectiveTip,t),t=new l.Z(["ui_setting_recommendpanel"]),
this.AddInfo(p.I.SettingRecommendTip,t),t=new l.Z(["ui_getexptips_panel","ui_getexptips_item"]),this.AddInfo(p.I.GetExpTipsPanel,t),t=new l.Z(["ui_npc_speakpanel"]),
this.AddInfo(p.I.eNpcSpeakPanel,t),t=new l.Z(["ui_accumulate_progress_view"]),this.AddInfo(p.I.AccumulatePanel,t),
t=new l.Z(["ui_targetplayer_suittipview","ui_equiptip_suitattr","ui_equiptip_commonattr"]),this.AddInfo(p.I.TargetPlayerSuitTip,t),
t=new l.Z(["ui_strengthen_strengthenlistpanel","ui_strengthen_strengthenlistitem"]),this.AddInfo(p.I.eStrengthenListPanel,t),
t=new l.Z(["ui_server_panel_ry","ui_comm_sprite_head","ui_comm_texture_head"]),this.AddInfo(p.I.ServerPanel,t),t=new l.Z(["ui_functionopen_animepanel"]),
this.AddInfo(p.I.FuncAnimePanel,t),t=new l.Z(["ui_suit_tipview"]),this.AddInfo(p.I.SuitTip,t),t=new l.Z(["ui_function_prenoticeinfopanel"]),this.AddInfo(p.I.FuncPrenoticeTip,t),
t=new l.Z(["ui_v1p_panel_ry","ui_v1p_levelcell_ry"]),this.AddInfo(p.I.VIPPanel,t),t=new l.Z(["ui_dun_exp_view"]),this.AddInfo(p.I.VIPExpView,t),
t=new l.Z(["ui_v1p_upgradepanel_ry"]),this.AddInfo(p.I.VIPUpgradeView,t),t=new l.Z(["ui_v1p_buytippanel"]),this.AddInfo(p.I.VIPBuyPanel,t),
t=new l.Z(["ui_recover_panel","ui_recover_copycount_item","ui_recover_taskreward_item","ui_recover_offlinereward_item"]),this.AddInfo(p.I.RecoverPanel,t),
t=new l.Z(["ui_recover_countpanel_ry"]),this.AddInfo(p.I.RecoverCountView,t),t=new l.Z(["ui_element_printpanel"]),this.AddInfo(p.I.eElementPrintPanel,t),
t=new l.Z(["ui_photograph_mainpanel"]),this.AddInfo(p.I.PhotographMainPanel,t),t=new l.Z(["ui_pandora_box_mainpanel"]),this.AddInfo(p.I.PandoraBoxMainPanel,t),
t=new l.Z(["ui_blank_blankview"]),this.AddInfo(p.I.BlankPanel,t),t=new l.Z(["ui_comm_fullscreen_toppanel"]),this.AddInfo(p.I.FullSceneTopPanel,t),
t=new l.Z(["ui_alliance_boss_monsterouttip"]),this.AddInfo(p.I.eAllianceBossCopyMonsterOutTip,t),t=new l.Z(["ui_alliance_boss_rankpanel"]),
this.AddInfo(p.I.eAllianceBossCopyRankPanel,t),t=new l.Z(["ui_alliance_bossup"]),this.AddInfo(p.I.AllianceBossUpgradeView,t),t=new l.Z(["ui_alliance_bossalert"]),
this.AddInfo(p.I.AllianceBossAlertView,t),t=new l.Z(["ui_alliance_boss_boxpanel"]),this.AddInfo(p.I.AllianceBossBoxView,t),t=new l.Z(["ui_alliance_bossblood"]),
this.AddInfo(p.I.AllianceBossDoubleBlood,t),t=new l.Z(["ui_alliance_boss_countdown_ry"]),this.AddInfo(p.I.AllianceBossCountDown,t),t=new l.Z(["ui_tipsqueue_fathertip"]),
this.AddInfo(p.I.TipListPanel,t),t=new l.Z(["ui_comm_story_loading"]),this.AddInfo(p.I.StoryLoadingViewID,t),t=new l.Z(["ui_copybaseui_controllbtnpanel"]),
this.AddInfo(p.I.CopyControlBtnPanel,t),t=new l.Z(["ui_market_marketequipattention","ui_market_attentionmenuitem"]),this.AddInfo(p.I.MarketAttentionEquipPanel,t),
t=new l.Z(["ui_skill_jobskillview","ui_skill_job_raw","ui_bag_bagitem","ui_skill_addtive_tip_item","ui_equiptip_excellenceattr","ui_bag_materialitem"]),
this.AddInfo(p.I.JobSkillPanel,t),t=new l.Z(["ui_market_mytradepanel","ui_market_markettradetaxpanel","ui_market_markettradealliancetaxpanel"]),
this.AddInfo(p.I.MarketMyTradePanel,t),t=new l.Z(["ui_alliance_membersview","ui_comm_texture_head","ui_comm_sprite_head"]),this.AddInfo(p.I.AllianceMemberView,t),
t=new l.Z(["ui_characterui_skillexercise","ui_skill_job_rawex"]),this.AddInfo(p.I.CharacterSkillExercise,t),t=new l.Z(["ui_bag_equipview","ui_equipmaster_tippanel"]),
this.AddInfo(p.I.BagEquipView,t),t=new l.Z(["ui_boss_hptest"]),this.AddInfo(p.I.HpTestPanel,t),t=new l.Z(["ui_character_soulpanel"]),this.AddInfo(p.I.eSoulPanel,t),
t=new l.Z(["ui_topsmallmap_linepanel"]),this.AddInfo(p.I.eChangeLinePanel,t),t=new l.Z(["ui_transjob_mainui_icon"]),this.AddInfo(p.I.TransferJobEnterPanel,t),
t=new l.Z(["ui_ry_copyentrance_panel"]),this.AddInfo(p.I.eCopyEntrancePanel,t),t=new l.Z(["ui_task_chapterpanel"]),this.AddInfo(p.I.eTaskChapterPanel,t),
t=new l.Z(["ui_extra_loading_panel"]),this.AddInfo(p.I.ExtraLoadingPanel,t),t=new l.Z(["ui_mapcopy_cond_panel"]),this.AddInfo(p.I.MapCopyCondPanel,t),
t=new l.Z(["ui_ry_fly_eff_panel"]),this.AddInfo(p.I.FLYEFFVIEW,t),t=new l.Z(["ui_upgrade_panel"]),this.AddInfo(p.I.LevelUpTip,t),t=new l.Z(["ui_skill_skillexchangepanel"]),
this.AddInfo(p.I.SkillExchangePanel,t),t=new l.Z(["ui_battlescoreanime_animepanel"]),this.AddInfo(p.I.BattleScoreAnimePanel,t),t=new l.Z(["ui_addpointtip_tipview"]),
this.AddInfo(p.I.AddPointTip,t),this.AddInfo(p.I.AddPointTip,t),t=new l.Z(["ui_newserver_advantage_tip"]),this.AddInfo(p.I.NewServerAdvantagePanel,t),
t=new l.Z(["ui_market_recharge_shenbing"]),this.AddInfo(p.I.RechargeShenbing,t),t=new l.Z(["ui_task_finish_effect_panel"]),this.AddInfo(p.I.TaskFinshEffect,t),
t=new l.Z(["ui_task_temp_view"]),this.AddInfo(p.I.eTaskTempView,t),t=new l.Z(["ui_market_groundingitemtippanel"]),this.AddInfo(p.I.GroundingItemTipPanel,t),
t=new l.Z(["ui_market_groundingequippanel"]),this.AddInfo(p.I.GroundingEquipTipPanel,t),t=new l.Z(["ui_task_exeequippanel"]),this.AddInfo(p.I.TaskExeEquipPanel,t),
t=new l.Z(["ui_task_noexeequippanel"]),this.AddInfo(p.I.TaskNoExeEquipPanel,t),t=new l.Z(["ui_task_skillpanel"]),this.AddInfo(p.I.TaskSkillPanel,t),
t=new l.Z(["ui_map_transport_mask"]),this.AddInfo(p.I.MapTransportMask,t),t=new l.Z(["ui_map_pass_reward_view","ui_map_pass_reward_baseitem","ui_map_pass_reward_item"]),
this.AddInfo(p.I.MapPassRewardView,t),t=new l.Z(["ui_copybaseui_commonrightview","ui_copybaseui_mapbattle_panel"]),this.AddInfo(p.I.MapCopyBattlePanel,t),
t=new l.Z(["ui_copybaseui_mapsuc_panel"]),this.AddInfo(p.I.MapCopySucPanel,t),t=new l.Z(["ui_copybaseui_mapfail_panel"]),this.AddInfo(p.I.MapCopyFailPanel,t),
t=new l.Z(["ui_fruit_panel","ui_fruit_item","ui_baseitem"]),this.AddInfo(p.I.FruitPanel,t),t=new l.Z(["ui_horse_mainview"]),this.AddInfo(p.I.Horse,t),
t=new l.Z(["ui_horse_dresspanel"]),this.AddInfo(p.I.HorseDress,t),t=new l.Z(["ui_horse_skilltipview"]),this.AddInfo(p.I.HorseSkillTipView,t),t=new l.Z(["ui_horse_selectpanel"]),
this.AddInfo(p.I.HorseSelectView,t),t=new l.Z(["ui_mainview_bufflist"]),this.AddInfo(p.I.MainBuffListPanel,t),t=new l.Z(["ui_mainview_allbufflist"]),
this.AddInfo(p.I.MainAllBuffListPanel,t),t=new l.Z(["ui_copybaseui_copysoonendtime"]),this.AddInfo(p.I.CopySoonEndTimePanel,t),t=new l.Z(["ui_setting_cdkeypanel"]),
this.AddInfo(p.I.CDKeyPanel,t),t=new l.Z(["ui_copybaseui_mapnorecoverpanel"]),this.AddInfo(p.I.CopyMapNoRecoverPanel,t),t=new l.Z(["ui_obtain_panel"]),
this.AddInfo(p.I.eObtainPanel,t),t=new l.Z(["ui_fasterfight_ry"]),this.AddInfo(p.I.FasterFight,t),t=new l.Z(["ui_flypanel","ui_flybagitem"]),this.AddInfo(p.I.eFlyItemPanel,t),
t=new l.Z(["ui_rydunboss_successpanel"]),this.AddInfo(p.I.eVipBossSuccessPanel,t),t=new l.Z(["ui_rydunboss_defeatpanel"]),this.AddInfo(p.I.VipBossDefeatPanel,t),
t=new l.Z(["ui_lostabyss_successview_ry"]),this.AddInfo(p.I.LostAbyssSuccessPanel,t),t=new l.Z(["ui_lostabyss_battleview_ry"]),this.AddInfo(p.I.LostAbyssBattleView,t),
t=new l.Z(["ui_alliance_questionview_ry","ui_alliance_question_rankitem_ry"]),this.AddInfo(p.I.AlliQuestionView,t),
t=new l.Z(["ui_alliance_question_invate","ui_alliance_question_invate_item"]),this.AddInfo(p.I.AlliQuestionInvatePanel,t),t=new l.Z(["ui_alliance_question_transfer"]),
this.AddInfo(p.I.AlliQuestionTransferPanel,t),t=new l.Z(["ui_morepanel"]),this.AddInfo(p.I.eWelfareXPanel,t),t=new l.Z(["ui_suitcomposetip","ui_suitlabelitem"]),
this.AddInfo(p.I.eSuitComposeTip,t),t=new l.Z(["ui_mainview_buffdetailpanel"]),this.AddInfo(p.I.eHeadBuffDetailPanel,t),t=new l.Z(["ui_alliancebuild_alliancemasterpanel"]),
this.AddInfo(p.I.eAllianceMasterPanel,t),t=new l.Z(["ui_vitality_rewardpanel","ui_vitality_reward_item"]),this.AddInfo(p.I.VitalityActivityRewardPanel,t),
t=new l.Z(["ui_alliance_alliancenoticepanel"]),this.AddInfo(p.I.eAllianceNoticePanel,t),t=new l.Z(["ui_alliance_shoppanel"]),this.AddInfo(p.I.eAllianceShopPanel,t),
t=new l.Z(["ui_characterui_passivetalent"]),this.AddInfo(p.I.PassiveTalentPanel,t),t=new l.Z(["ui_alliance_entrustpanel","ui_alliance_entrustitem"]),
this.AddInfo(p.I.eAllianceEntrustPanel,t),t=new l.Z(["ui_alliance_entrusthelppanel","ui_comm_sprite_head","ui_comm_texture_head"]),this.AddInfo(p.I.eAllianceHelpPanel,t),
t=new l.Z(["ui_copybaseui_bloodtown_stonepanel","ui_bag_bagitem","ui_copybaseui_bloodtown_stone_item"]),this.AddInfo(p.I.eBloodTownItemStonePanel,t),
t=new l.Z(["ui_copybaseui_bloodtown_flyeffect"]),this.AddInfo(p.I.eBloodTownItemStoneFlyPanel,t),t=new l.Z(["ui_buybattleboss_tip"]),this.AddInfo(p.I.eBuyBattleBossHintPanel,t),
t=new l.Z(["ui_getwing_panel"]),this.AddInfo(p.I.eGetWingPanel,t),t=new l.Z(["ui_ry_tabcommonpanel"]),this.AddInfo(p.I.eTransJobMainView,t),
t=new l.Z(["ui_transjob_getskill_panel"]),this.AddInfo(p.I.eTransJobGetSkill,t),t=new l.Z(["ui_rydtsnb_view","ui_rydtsnb_view_btn"]),this.AddInfo(p.I.eRydtsNB,t),
t=new l.Z(["ui_ry_tabcommonpanel"]),this.AddInfo(p.I.eRydtsNBExample10,t),t=new l.Z(["ui_system_force_msg"]),this.AddInfo(p.I.eSystemForceMsgPanel,t),
t=new l.Z(["ui_suitattr_suitattrtip"]),this.AddInfo(p.I.eSuitAttrTipPanel,t),t=new l.Z(["ui_task_suitequippanel"]),this.AddInfo(p.I.eTaskSuitEquipView,t),
t=new l.Z(["ui_ry_skill_panel"]),this.AddInfo(p.I.eSkillPanel,t),t=new l.Z(["ui_skill_jobskill_info_tip","ui_bag_materialitem","ui_skill_tips_level_desc"]),
this.AddInfo(p.I.SkillInfoTip,t),t=new l.Z(["ui_ry_skill_tips"]),this.AddInfo(p.I.eSkillTipsPanel,t),t=new l.Z(["ui_bag_horsetippanel","ui_bag_tipbtn"]),t.AddRange(e),
this.AddInfo(p.I.HorseItemTip,t),t=new l.Z(["ui_market_mall_buytip"]),this.AddInfo(p.I.eMarketMallBuyTip,t),t=new l.Z(["ui_market_mall_accessview"]),
this.AddInfo(p.I.MarketAccessView,t),t=new l.Z(["ui_facade_setting","ui_drop_down_list","ui_drop_down_list_item"]),this.AddInfo(p.I.eFacadeSettingPanel,t),
t=new l.Z(["ui_copy_beliel_rank","ui_copy_beliel_rankitem","ui_bag_baseitem76_76"]),this.AddInfo(p.I.AllienceBelielRankPanel,t),t=new l.Z(["ui_copy_beliel_score"]),
this.AddInfo(p.I.AllienceBelielScorePanel,t),t=new l.Z(["ui_bossassist_assisting","ui_bossassist_item"]),this.AddInfo(p.I.AssistDamageRankPanel,t),
t=new l.Z(["ui_treasure_worldboss_normalsuccessview"]),this.AddInfo(p.I.WorldBossNormalSuccessPanel,t),t=new l.Z(["ui_treasure_worldboss_extrasuccessview"]),
this.AddInfo(p.I.WorldBossExtraSuccessPanel,t),t=new l.Z(["ui_bossassist_successpanel"]),this.AddInfo(p.I.WorldBossAssistSuccessPanel,t),t=new l.Z(["ui_bossassist_successeffect"]),
this.AddInfo(p.I.AssistFinshEffect,t),t=new l.Z(["ui_scorefly_panel"]),this.AddInfo(p.I.ScoreFlyPanel,t),
t=new l.Z(["ui_treasure_worldboss_flyeffect_ry","ui_treasure_worldboss_flyitem_ry"]),this.AddInfo(p.I.WorldBossFlyEffectPanel,t),
t=new l.Z(["ui_treasure_worldboss_extrarewardinfo_ry"]),this.AddInfo(p.I.WorldBossExtraRewardPanel,t),t=new l.Z(["ui_asuram_taskpanelnew"]),this.AddInfo(p.I.eAsuramTaskPanel,t),
t=new l.Z(["ui_login_gmloginpanel"]),this.AddInfo(p.I.eGmLoginPanel,t),t=new l.Z(["ui_scoreflytobar_panel"]),this.AddInfo(p.I.eScoreFlyToBarPanel,t),
t=new l.Z(["ui_transportready_panel"]),this.AddInfo(p.I.eTransportReadyPanel,t),t=new l.Z(["ui_test_panel"]),this.AddInfo(p.I.eTestPanel,t),
t=new l.Z(["ui_addpointway_tipview","ui_addpointway_item"]),this.AddInfo(p.I.eAddPointWayTipPanel,t),t=new l.Z(["ui_diamondfly_panel","ui_diamondfly_item"]),
this.AddInfo(p.I.eDiamondGetEffectPanel,t),t=new l.Z(["ui_diamond_limit_rewardview_ry"]),this.AddInfo(p.I.eDiamondLimitGetRewardPanel,t),
t=new l.Z(["ui_diamond_limit_noticeicon_ry"]),this.AddInfo(p.I.eDiamondLimitNoticeIcon,t),t=new l.Z(["ui_diamond_limit_noticeview_ry"]),this.AddInfo(p.I.eDiamondLimitNoticeView,t),
t=new l.Z(["ui_map_overpowertip"]),this.AddInfo(p.I.eEliteTipPanel,t),t=new l.Z(["ui_copybaseui_commonrightview","ui_copybaseui_skylandpanel"]),
this.AddInfo(p.I.SkylandCopyPanel,t),t=new l.Z(["ui_copybaseui_slowdowntippanel"]),this.AddInfo(p.I.SlowDownTipPanel,t),t=new l.Z(["ui_copypanel_skylandcountdown"]),
this.AddInfo(p.I.SkylandCountDownPanel,t),t=new l.Z(["ui_alliance_assist_thankview","ui_alliance_assist_msgitem","ui_alliance_assist_assistantitem"]),
this.AddInfo(p.I.eAllianceAssistThankPanel,t),t=new l.Z(["ui_alliance_assist_recievethankview"]),this.AddInfo(p.I.eAllianceAssistRecieveThankPanel,t),
t=new l.Z(["ui_comm_commkilltippanel"]),this.AddInfo(p.I.eCommonKillTipPanel,t),t=new l.Z(["ui_comm_flyitemview","ui_comm_flyitem"]),this.AddInfo(p.I.eCommonFlyItemPanel,t),
t=new l.Z(["ui_alliance_applyagentview"]),this.AddInfo(p.I.eApplyAgentPanel,t),t=new l.Z(["ui_treasure_karima_starview"]),this.AddInfo(p.I.eKarimaStarView,t),
t=new l.Z(["ui_prenotice_listpanel"]),this.AddInfo(p.I.ePrenoticeListPanel,t),t=new l.Z(["ui_bag_titletippanel","ui_bag_tipbtn"]),t.AddRange(e),this.AddInfo(p.I.eTitleItemTip,t),
t=new l.Z(["ui_efficiency_efficiencypanel_ry","ui_efficiency_efficiencyitem_ry"]),this.AddInfo(p.I.eEfficiencyPanel,t),t=new l.Z(["ui_chat_debugpanel"]),
this.AddInfo(p.I.eChatDebug,t),t=new l.Z(["ui_copybaseui_commonrightview","ui_copybaseui_asuramtasktrace_panel"]),this.AddInfo(p.I.eAsuramTaskCopyTracePanel,t),
t=new l.Z(["ui_alliancecopy_task_ry"]),this.AddInfo(p.I.eRyAllianceCopyTaskView,t),t=new l.Z(["ui_rolanddefense_copyview1"]),this.AddInfo(p.I.RolandRepairCrackCopyView,t),
t=new l.Z(["ui_rolanddefense_copyview2"]),this.AddInfo(p.I.RolandDefenseCopy2View,t),t=new l.Z(["ui_asuram_prenotice"]),this.AddInfo(p.I.eAsuramPrenoticePanel,t),
t=new l.Z(["ui_mainview_battleskillpanel"]),this.AddInfo(p.I.eBattleSkillPanel,t),t=new l.Z(["ui_changename_view"]),this.AddInfo(p.I.eChangeNamePanel,t),
t=new l.Z(["ui_forge_suitbuildpanel","ui_compound_treetitleitem","ui_compound_treeitem"]),this.AddInfo(p.I.eSuitBild,t),t=new l.Z(["ui_quenton_mainpanel"]),
this.AddInfo(p.I.eQuentonMainPanel,t),t=new l.Z(["ui_quenton_noticepanel"]),this.AddInfo(p.I.eQuentonNoticePanel,t),
t=new l.Z(["ui_skill_setskillview","ui_skill_setskill_row","ui_skill_setskill_listitem"]),this.AddInfo(p.I.eSetSkillPanel,t),t=new l.Z(["ui_market_subpackrechargeview"]),
this.AddInfo(p.I.eSubPackRechargeView,t),t=new l.Z(["ui_copybaseui_commonrightview","ui_quenton_copyview"]),this.AddInfo(p.I.eQuentonCopyView,t),t=new l.Z(["ui_joystick_panel"]),
this.AddInfo(p.I.eJoystickPanel,t),t=new l.Z(["ui_activitybaokubuy"]),this.AddInfo(p.I.ActivityBaoKuBuyPanel,t),t=new l.Z(["ui_activitybaoku_reward"]),
this.AddInfo(p.I.ActivityBaoKuRewardPanel,t),t=new l.Z(["ui_alliance_alliancewelfarepanel"]),this.AddInfo(p.I.AllianceWelfarePanel,t),
t=new l.Z(["ui_alliance_alliancedistributepanel","ui_comm_texture_head","ui_comm_sprite_head"]),this.AddInfo(p.I.AllianceDistributePanel,t),
t=new l.Z(["ui_alliance_alliancedrawrewardpanel","ui_comm_texture_head","ui_comm_sprite_head"]),this.AddInfo(p.I.AllianceDrawRewardPanel,t),
t=new l.Z(["ui_alliance_assist_basepanel","ui_alliance_assist_goblinview","ui_alliance_assist_goblinviewitem"]),this.AddInfo(p.I.AllianceAssistBasePanel,t),
t=new l.Z(["ui_alliance_assist_goblinresponseview"]),this.AddInfo(p.I.AllianceAssistGoblinResponsePanel,t),t=new l.Z(["ui_tip_commtipsview"]),this.AddInfo(p.I.eCommTextTipPanel,t),
t=new l.Z(["ui_uploadlogview"]),this.AddInfo(p.I.eUpLoadLogView,t),t=new l.Z(["ui_chat_crosspanel"]),this.AddInfo(p.I.eCrossChat,t),t=new l.Z(["ui_officialaccount_panel_ry"])
this.AddInfo(p.I.eOfficialAccountPanel,t),t=new l.Z(["ui_seasonring_panel"]),this.AddInfo(p.I.eSeasonRingPanel,t),t=new l.Z(["ui_seasonring_subupgradepanel"]),
this.AddInfo(p.I.eSeasonRingUpgradePanel,t),t=new l.Z(["ui_seasonring_realupgothroughpanel"]),this.AddInfo(p.I.eSeasonRingGothroughRealPanel,t),
t=new l.Z(["ui_seasonring_subupgothroughpanel"]),this.AddInfo(p.I.eSeasonRingGothroughSuccessPanel,t),t=new l.Z(["ui_seasonring_enhancetip"]),
this.AddInfo(p.I.eSeasonRingEnhanceTip,t),t=new l.Z(["ui_seasonring_activetippanel"]),this.AddInfo(p.I.eSeasonRingActiveTipPanel,t),t=new l.Z(["ui_seasonring_activesucpanel"]),
this.AddInfo(p.I.eSeasonRingActiveSucPanel,t),t=new l.Z(["ui_seasonring_replacepanel"]),this.AddInfo(p.I.eSeasonRingReplacePanel,t),t=new l.Z(["ui_seasonringtips_panel"]),
this.AddInfo(p.I.eSeasonRingTipPanel,t),t=new l.Z(["ui_systemtips_scannermsgview"]),this.AddInfo(p.I.eScannerMsgPanel,t),t=new l.Z(["ui_transferserver_rank"]),
this.AddInfo(p.I.eTransferServerRank,t),t=new l.Z(["ui_transferserver_alert"]),this.AddInfo(p.I.eTransferServerAlert,t),t=new l.Z(["ui_transferserver_readyview"]),
this.AddInfo(p.I.eTransferServerReadyPanel,t),t=new l.Z(["ui_worldauction_bidpanel"]),this.AddInfo(p.I.eCrossAuctionBidPanel,t),t=new l.Z(["ui_worldauction_shareview"]),
this.AddInfo(p.I.eWorldFirmShareView,t),t=new l.Z(["ui_dropexp_panel","ui_dropexp_ball"]),this.AddInfo(p.I.DropExpPanel,t),t=new l.Z(["ui_ry_forge_enhancesuccess"]),
this.AddInfo(p.I.EnhanceSuccessView,t),t=new l.Z(["ui_ry_forge_quicksuccess"]),this.AddInfo(p.I.EnhanceAutoSuccessView,t),t=new l.Z(["ui_ry_forge_suitsuccess"]),
this.AddInfo(p.I.SuitSuccessView,t),t=new l.Z(["ui_ry_forge_suit_tip"]),this.AddInfo(p.I.SuitTipView,t),
t=new l.Z(["ui_excscroll_panel","ui_excscroll_item","ui_excscroll_bigitem"]),this.AddInfo(p.I.eExcScroll,t),t=new l.Z(["ui_excscroll_getpanel"]),this.AddInfo(p.I.eExcScrollGet,t),
t=new l.Z(["ui_manual_manualview"]),this.AddInfo(p.I.ManualPanel,t),t=new l.Z(["ui_manual_gainrewpanel"]),this.AddInfo(p.I.ManualGainRewPanel,t),
t=new l.Z(["ui_assist_gainrewpanel"]),this.AddInfo(p.I.AssistGainRewPanel,t),t=new l.Z(["ui_ry_forge_metagems_tips"]),this.AddInfo(p.I.MetagensTips,t),
t=new l.Z(["ui_ry_forge_metagems_blessactive_view"]),this.AddInfo(p.I.MetagensBlessActive,t),t=new l.Z(["ui_manual_somethingopen"]),this.AddInfo(p.I.ManualFuncOpen,t),
t=new l.Z(["ui_becomestronger_mainview"]),this.AddInfo(p.I.BecomeStrongerMainView,t),t=new l.Z(["ui_daily_task_info"]),this.AddInfo(p.I.DailyTaskInfo,t),
t=new l.Z(["ui_ry_forge_metagems_box_view","ui_ry_forge_metage_eff1"]),this.AddInfo(p.I.MetagemsBoxView,t),t=new l.Z(["ui_ry_offlinehangup_panel"])
for(const[e,i]of(0,I.V5)(c.S.COMP_DICT))null!=i.viewPath&&t.Add(i.viewPath)
this.AddInfo(p.I.OfflineHangupPanel,t),t=new l.Z(["ui_goldspawn_result"]),this.AddInfo(p.I.GoldSpawnResultPanel,t),t=new l.Z(["ui_goldspawn_out_result"]),
this.AddInfo(p.I.GoldSpawnOutResultPanel,t),t=new l.Z(["ui_goldspawn_panel","ui_goldspawn_map_item_t","ui_goldspawn_map_item","ui_goldspawn_map_icon"]),
this.AddInfo(p.I.GoldSpawnMainPanel,t),t=new l.Z(["ui_goldspawn_monster_tip"]),this.AddInfo(p.I.GoldSpawnMonsterTip,t),t=new l.Z(["ui_goldspwan_mainr","ui_goldspwan_mainr_item"]),
this.AddInfo(p.I.GoldSpawnMainRightPanel,t),t=new l.Z(["ui_goldspawn_remaind_time"]),this.AddInfo(p.I.GoldSpawnRemainTimeTip,t),t=new l.Z(["ui_goldspawn_addtime"]),
this.AddInfo(p.I.GoldSpawnAddTimeTip,t),t=new l.Z(["ui_goldspawn_defense"]),this.AddInfo(p.I.GoldSpawnDefenseTip,t),t=new l.Z(["ui_equiptransfer_tipview"]),
this.AddInfo(p.I.EquipLuckyChangeTip,t),t=new l.Z(["ui_multipleexphang_addtime"]),this.AddInfo(p.I.MultipleHangAddTimeTip,t),
t=new l.Z(["ui_multipleexphang_mainr","ui_multipleexphang_mainr_item"]),this.AddInfo(p.I.MultipleHangRightPanel,t),t=new l.Z(["ui_multipleexphang_remaind_time"]),
this.AddInfo(p.I.MultipleHangRemainPanel,t),t=new l.Z(["ui_multipleexphang_result"]),this.AddInfo(p.I.MultipleHangResultPanel,t),t=new l.Z(["ui_multipleexphang_panel"]),
this.AddInfo(p.I.MultipleHangPanel,t),t=new l.Z(["ui_multipleexphang_buff_tips"]),this.AddInfo(p.I.MultipleHangBuffTip,t),t=new l.Z(["ui_topsmallmap_bosschallenge_view"]),
this.AddInfo(p.I.MapUnlockBossChangeView,t),t=new l.Z(["ui_topsmallmap_flyItem"]),this.AddInfo(p.I.MapUnlockFlyItem,t),t=new l.Z(["ui_topsmallmap_unlock_view_ry"]),
this.AddInfo(p.I.MapUnlockView,t),t=new l.Z(["ui_topsmallmap_crossbosschallenge_view"]),this.AddInfo(p.I.MapCrossBossChallengeView,t),
t=new l.Z(["ui_use_drugs_view","ui_use_drugs_item"]),this.AddInfo(p.I.BattleUseDrugs,t),t=new l.Z(["ui_rebirth_mainui_icon"]),this.AddInfo(p.I.eRebirthMainIcon,t),
t=new l.Z(["ui_ry_tabcommonpanel"]),this.AddInfo(p.I.eRebirthMainPanel,t),t=new l.Z(["ui_rebirth_submit_panel"]),this.AddInfo(p.I.eRebirthSubmitPanel,t),
t=new l.Z(["ui_rebirth_skill_info_panel"]),this.AddInfo(p.I.eRebirthSkillInfoPanel,t),t=new l.Z(["ui_rebirth_talent_tip"]),this.AddInfo(p.I.eRebirthTalentTip,t),
t=new l.Z(["ui_rebirth_suc_panel"]),this.AddInfo(p.I.eRebirthSucPanel,t),t=new l.Z(["ui_rebirth_boss_icon_panel"]),this.AddInfo(p.I.eRebirthBossIconPanel,t),
t=new l.Z(["ui_rebirth_boss_wildtime_panel"]),this.AddInfo(p.I.eRebirthBossWildTimePanel,t),t=new l.Z(["ui_rebirth_monster_panel","ui_rebirth_monster_item"]),
this.AddInfo(p.I.eRebirthMonsterPanel,t),t=new l.Z(["ui_rebirth_help_come_panel"]),this.AddInfo(p.I.eRebirthHelpComePanel,t),t=new l.Z(["ui_rebirth_boss_suc_panel"]),
this.AddInfo(p.I.eRebirthBossSucPanel,t),t=new l.Z(["ui_rebirth_boss_fail_panel","ui_rebirth_boss_fail_item"]),this.AddInfo(p.I.eRebirthBossFailPanel,t),
t=new l.Z(["ui_stall_stallview_ry","ui_stall_market_item_ry","ui_stall_market_menuitem_ry","ui_tradingmarketview_treetitleitem","ui_stall_marketview_onetreeitem","ui_stall_marketview_treetitleitem_ry"]),
this.AddInfo(p.I.StallView,t),t=new l.Z(["ui_stall_logview_ry","ui_infotip_currency"]),this.AddInfo(p.I.StallLogView,t),t=new l.Z(["ui_stall_expensivelogview_ry"]),
this.AddInfo(p.I.RyStallHighPriceLogView,t),t=new l.Z(["ui_stall_putoffview_ry"]),this.AddInfo(p.I.StallPutOffView,t),t=new l.Z(["ui_stall_putonview_ry"]),
this.AddInfo(p.I.StallPutOnView,t),t=new l.Z(["ui_stall_buyview_ry"]),this.AddInfo(p.I.StallBuyView,t),t=new l.Z(["ui_stall_otherplayerview_ry"]),t.AddRange(e),
this.AddInfo(p.I.OhterPlayerStallView,t),t=new l.Z(["ui_stall_rerentview_ry"]),this.AddInfo(p.I.RyStallReRentView,t),
t=new l.Z(["ui_ry_friendpanel","ui_comm_texture_head","ui_comm_sprite_head"]),this.AddInfo(p.I.RYFriendPanel,t),
t=new l.Z(["ui_daily_panel","ui_daily_taskview","ui_daily_taskitem"]),this.AddInfo(p.I.RYDailyPanel,t),t=new l.Z(["ui_daily_getrewardview","ui_daily_getrewarditem"]),
this.AddInfo(p.I.RYDailyGetAwardView,t),t=new l.Z(["ui_excalibur_view_ry"]),this.AddInfo(p.I.RyExcaliburView,t),t=new l.Z(["ui_handinitem_view"]),
this.AddInfo(p.I.HandInItemView,t),t=new l.Z(["ui_ry_wondful_event"]),this.AddInfo(p.I.eWonderfulEventPanel,t),
t=new l.Z(["ui_rychat_searchplayerpanel","ui_rychat_searchplayeritem"]),this.AddInfo(p.I.RySearchPlayerPanel,t),t=new l.Z(["ui_rymedal_mainpanel","ui_rymedal_medalview"]),
this.AddInfo(p.I.RyMedalPanel,t),t=new l.Z(["ui_rymedal_medaluppanel"]),this.AddInfo(p.I.RyMedalUpPanel,t),
t=new l.Z(["ui_ry_skill_praticeskillview","ui_ry_skill_praticeskilldesc"]),this.AddInfo(p.I.RySkillPraticeSkillView,t),t=new l.Z(["ui_ry_skilltipview"]),
this.AddInfo(p.I.RyNormalSkillTipView,t),t=new l.Z(["ui_ry_divine_skilltipview"]),this.AddInfo(p.I.RyDivineSkillTipView,t),t=new l.Z(["ui_ry_divine_skilltipview"]),
this.AddInfo(p.I.RyDivineCodeSkillTipView,t),t=new l.Z(["ui_rykarima_statusview"]),this.AddInfo(p.I.KarimaStatusView,t),
t=new l.Z(["ui_selectroletip_view","ui_selectroletip_item"]),this.AddInfo(p.I.SelectRoleTip,t),t=new l.Z(["ui_market_rechargetrib_view","ui_baseitem"]),
this.AddInfo(p.I.RechargeGiftPanel,t),t=new l.Z(["ui_copybaseui_commonrightview","ui_rykarima_rightview"]),this.AddInfo(p.I.KarimaRightView,t),
t=new l.Z(["ui_buff_mainview","ui_buffer_item"]),this.AddInfo(p.I.BufferMainView,t),t=new l.Z(["ui_getbuff_tippanel"]),this.AddInfo(p.I.GetBuffView,t),
t=new l.Z(["ui_surface_show_selectview_ry"]),this.AddInfo(p.I.RySurfaceSelectView,t),t=new l.Z(["ui_surface_settingview_ry"]),this.AddInfo(p.I.RySurfaceSettingView,t),
t=new l.Z(["ui_surface_fashionattrview_ry"]),this.AddInfo(p.I.RyFashionAttrView,t),t=new l.Z(["ui_surface_fashioncabinetview_ry"]),this.AddInfo(p.I.RyFashionCabinetView,t),
t=new l.Z(["ui_ryfirstcharge_rewardpanel"]),this.AddInfo(p.I.FirstChargeRewardShow,t),t=new l.Z(["ui_ryfirstcharge_successpanel"]),this.AddInfo(p.I.FirstChargeSuccessPanel,t),
t=new l.Z(["ui_skilllimitbuy_view_ry"]),this.AddInfo(p.I.RySkillLimitBuyView,t),t=new l.Z(["ui_skilllimitbuy_second_view_ry"]),this.AddInfo(p.I.RySkillLimitBuySecondView,t),
t=new l.Z(["ui_skilllimitbuy_reward_view_ry"]),this.AddInfo(p.I.RySkillLimitBuyRewardView,t),t=new l.Z(["ui_discountgoods_mainview"]),this.AddInfo(p.I.DISCOUNT_GOODS_MAINVIEW,t),
t=new l.Z(["ui_buy_discountgoods_panel"]),this.AddInfo(p.I.DISCOUNT_GOODS_BUY_RESULT,t),t=new l.Z(["ui_handexpup_tip_view"]),this.AddInfo(p.I.HAND_EXP_UP_TIP,t),
t=new l.Z(["ui_alliancecopy_bornfire_ry"]),this.AddInfo(p.I.RyAllianceCopyBornFireView,t),t=new l.Z(["ui_alliancecopy_chuangong_ry"]),
this.AddInfo(p.I.RyAllianceCopyChuanGongView,t),t=new l.Z(["ui_alliancecopy_submitfire_ry","ui_copybaseui_fireitem","ui_baseitem"]),
this.AddInfo(p.I.RyAllianceCopySubmitFireView,t),t=new l.Z(["ui_alliancecopy_submitfire_confirm"]),this.AddInfo(p.I.RyAllianceCopySubmitFireConfirmView,t),
t=new l.Z(["ui_alliancecopy_beginfire_ry","ui_alliancecopy_headitem"]),this.AddInfo(p.I.RyAllianceCopyBeginFireView,t),t=new l.Z(["ui_alliance_chuangong_ry"]),
this.AddInfo(p.I.RyAllianceChuanGongView,t),t=new l.Z(["ui_alliance_minxiang_ry"]),this.AddInfo(p.I.RyAllianceMinXiangView,t),t=new l.Z(["ui_copybase_gainview"]),
this.AddInfo(p.I.CopyGain,t),t=new l.Z(["ui_common_getreward_tippanel"]),this.AddInfo(p.I.GetRewardTipPanel,t),t=new l.Z(["ui_topsmallmap_world_expview"]),
this.AddInfo(p.I.RyWorldMapExpTipsView,t),t=new l.Z(["ui_task_mainui_hide_panel","ui_task_hide_view"]),this.AddInfo(p.I.eTaskHideMainUI,t),t=new l.Z(["ui_ry_sevenday_mainview"]),
this.AddInfo(p.I.eSevenDayPanel,t),t=new l.Z(["ui_sevenday_rank_daily_reward_panel"]),this.AddInfo(p.I.eSevenDayRankRewardPanel,t),t=new l.Z(["ui_ry_openservergrab_mainview"]),
this.AddInfo(p.I.OpenServerGrabPanel,t),t=new l.Z(["ui_openservergrab_accesspanel","ui_access_icon"]),this.AddInfo(p.I.OpenServerGrabAccessPanel,t),
t=new l.Z(["ui_openservergrab_rewardranklis_view","ui_openservergrab_ranklis_item"]),this.AddInfo(p.I.OpenServerGrabRankLisView,t),t=new l.Z(["ui_alliance_asuramwarrewardpanel"]),
this.AddInfo(p.I.AsuramWarRewardPanel,t),t=new l.Z(["ui_alliance_asuramwarstatuspanel"]),this.AddInfo(p.I.AsuramWarStatusPanel,t),t=new l.Z(["ui_targetplayer_rymainpanel"]),
this.AddInfo(p.I.RyTargetPlayerMainPanel,t),t=new l.Z(["ui_alliance_alliancetreasurepanel","ui_alliance_alliancetreasureitem"]),this.AddInfo(p.I.RyAllianceBuildTreasureView,t),
t=new l.Z(["ui_copybaseui_duntimer"]),this.AddInfo(p.I.RyDunBossTimer,t),t=new l.Z(["ui_bag_itemmodeltippanel"]),this.AddInfo(p.I.ItemModelTipView,t),
t=new l.Z(["ui_taskobtain_panel"]),this.AddInfo(p.I.TaskObtainPanel,t),t=new l.Z(["ui_task_equipcollectguidepanel"]),this.AddInfo(p.I.TaskEquipCollectGuidePanel,t),
t=new l.Z(["ui_rainbow_panel"]),this.AddInfo(p.I.eRainbow,t),t=new l.Z(["ui_ry_ridingbuy_mainpanel"]),this.AddInfo(p.I.RidingBuyPanel,t),
t=new l.Z(["ui_ry_ridingbuy_showhorsepanel"]),this.AddInfo(p.I.RidingBuyShowHorsePanel,t),t=new l.Z(["ui_ry_ridingbuy_tip"]),this.AddInfo(p.I.RidingBuyTipPanel,t),
t=new l.Z(["ui_efficiency_expdrugpanel_ry"]),this.AddInfo(p.I.eEfficiencyExpDrug,t),t=new l.Z(["ui_efficiency_tippanel_ry"]),this.AddInfo(p.I.eEfficiencyExpDrugTip,t),
t=new l.Z(["ui_dialogue_robotpanel"]),this.AddInfo(p.I.DialogueRobotPanel,t),t=new l.Z(["ui_arena_view_ry"]),this.AddInfo(p.I.eRyArenaView,t),t=new l.Z(["ui_arena_logview_ry"]),
this.AddInfo(p.I.eRyArenaLogView,t),t=new l.Z(["ui_arena_rewardview_ry"]),this.AddInfo(p.I.eRyArenaRewardView,t),t=new l.Z(["ui_arena_head_r_ry"]),
this.AddInfo(p.I.eRyArenaHeadRightView,t),t=new l.Z(["ui_arena_head_l_ry"]),this.AddInfo(p.I.eRyArenaHeadLeftView,t),t=new l.Z(["ui_arena_timer_ry"]),
this.AddInfo(p.I.eRyArenaCopyTimerView,t),t=new l.Z(["ui_arena_result_view_ry"]),this.AddInfo(p.I.eRyArenaCopyResultView,t),t=new l.Z(["ui_arena_damage_view_ry"]),
this.AddInfo(p.I.eRyArenaCopyDamageView,t),t=new l.Z(["ui_arena_cleanup_view_ry"]),this.AddInfo(p.I.eRyArenaCleanUpView,t),t=new l.Z(["ui_arena_exitbtn_view"]),
this.AddInfo(p.I.eRyArenaCopyExitView,t),t=new l.Z(["ui_ry_tabcommonpanel"]),this.AddInfo(p.I.eGameGM,t),
t=new l.Z(["ui_game_gm_createrole_select_panel","ui_ry_skill_common_item"]),this.AddInfo(p.I.eGameGMCreateRoleSelect,t),t=new l.Z(["ui_game_exit"]),this.AddInfo(p.I.eGameExit,t),
t=new l.Z(["ui_ry_equipadvance_selectpanel"]),this.AddInfo(p.I.RyEquipAdvanceSelectEquipPanel,t),t=new l.Z(["ui_ry_equipadvance_peekattrpanel"]),
this.AddInfo(p.I.RyEquipAdvancePeekAttrPanel,t),t=new l.Z(["ui_activity_lottery_view"]),this.AddInfo(p.I.ActivityLottery,t),t=new l.Z(["ui_gain_item_view","ui_gain_item"]),
this.AddInfo(p.I.GainItemView,t),t=new l.Z(["ui_ry_alliance_donationpanel"]),this.AddInfo(p.I.RyAllianceBuildDonation,t),t=new l.Z(["ui_ry_alliancefactory_mainpanel"]),
this.AddInfo(p.I.RyAllianceFactory,t),t=new l.Z(["ui_alliance_pullcar","ui_alliance_caritem","ui_alliance_car_oneattr"]),this.AddInfo(p.I.RyAlliancePullCar,t),
t=new l.Z(["ui_alliance_rytechview"]),this.AddInfo(p.I.RyAllianceBuildTecPanel,t),t=new l.Z(["ui_fortunetreasure_panel","ui_fortune_fatebox_item","ui_fortune_fateturn_item"]),
this.AddInfo(p.I.FortuneTreasure,t),t=new l.Z(["ui_fortune_fateresure_resultpanel"]),this.AddInfo(p.I.FortuneFateResultPanel,t),
t=new l.Z(["ui_fortune_raremerchant_panel","ui_fortune_raremerchant_item"]),this.AddInfo(p.I.FortuneMerchant,t),t=new l.Z(["ui_fortune_round_tips"]),
this.AddInfo(p.I.FortuneTipView,t),t=new l.Z(["ui_loading_circleview_ry"]),this.AddInfo(p.I.eRyLoadingCircleView,t),t=new l.Z(["ui_welfara_advancefighttokentip"]),
this.AddInfo(p.I.AdvanceFightTokenTip,t),t=new l.Z(["ui_gem_master_view"]),this.AddInfo(p.I.GEM_MASTER,t),t=new l.Z(["ui_gem_select_view"]),this.AddInfo(p.I.GEM_SELECT,t),
t=new l.Z(["ui_ry_forge_wingRefine_success"]),this.AddInfo(p.I.WingRefineSuccessView,t),t=new l.Z(["ui_ry_forge_wingRefine_selectpanel"]),
this.AddInfo(p.I.WingRefineSelectItemView,t),t=new l.Z(["ui_mayatreasure_panel","ui_maya_hunttreasure_view","ui_maya_hunttreasure_item","ui_maya_treasure_item"]),
this.AddInfo(p.I.MayaTreasureView,t),t=new l.Z(["ui_mayatreasure_result_panel"]),this.AddInfo(p.I.MayaTreasureResultView,t),t=new l.Z(["ui_mayaexchange_tip"]),
this.AddInfo(p.I.MayaExchangeTipView,t),t=new l.Z(["ui_alliance_charioticon"]),this.AddInfo(p.I.CancelTransformIcon,t),t=new l.Z(["ui_alliance_chariotinprocess"]),
this.AddInfo(p.I.ChariotInProcess,t),t=new l.Z(["ui_honortrib_view","ui_honortrib_item"]),this.AddInfo(p.I.HonorGiftView,t),t=new l.Z(["ui_honortrib_result_view"]),
this.AddInfo(p.I.HonorGiftResultView,t),t=new l.Z(["ui_smallmap_levep_tips_ry"]),this.AddInfo(p.I.MapLevelTips,t),t=new l.Z(["ui_onlinehang_icon_ry"]),
this.AddInfo(p.I.eRyOnlineHangIcon,t),t=new l.Z(["ui_onlinehang_view_ry"]),this.AddInfo(p.I.eRyOnlineHangView,t),t=new l.Z(["ui_task_mainui_contract_panel"]),
this.AddInfo(p.I.eTaskContractMainUI,t),t=new l.Z(["ui_task_contract_info_panel"]),this.AddInfo(p.I.eTaskContractInfoPanel,t),
t=new l.Z(["ui_task_contract_select_panel","ui_task_contract_select_item"]),this.AddInfo(p.I.eTaskContractSelectPanel,t),t=new l.Z(["ui_task_contract_select_end_panel"]),
this.AddInfo(p.I.eTaskContractSelectEndPanel,t),t=new l.Z(["ui_task_contract_panel","ui_task_contract_item"]),this.AddInfo(p.I.eTaskContractPanel,t),
t=new l.Z(["ui_task_contract_finish_eff_panel"]),this.AddInfo(p.I.eTaskContractFinishEffectPanel,t),t=new l.Z(["ui_task_contract_recover_panel"]),
this.AddInfo(p.I.eTaskContractRecoverPanel,t),t=new l.Z(["ui_tradingmarket_attentionpanel","ui_tradingmarketview_treetitleitem","ui_stall_marketview_onetreeitem"]),
this.AddInfo(p.I.TradingMarketAttention,t),t=new l.Z(["ui_tradingmarket_operation"]),this.AddInfo(p.I.TradingMarketOperation,t),t=new l.Z(["ui_tradingmarket_tipview"]),
this.AddInfo(p.I.TradingMarketGetItemTipView,t),t=new l.Z(["ui_tradingmarket_logpanel"]),this.AddInfo(p.I.TradingMarketLogPanel,t),t=new l.Z(["ui_changejob_mainpanel"]),
this.AddInfo(p.I.ChangeJobMainPanel,t),t=new l.Z(["ui_changejob_detailpanel"]),this.AddInfo(p.I.ChangeJobDetailPanel,t),t=new l.Z(["ui_changejob_effectpanel"]),
this.AddInfo(p.I.ChangeJobEffectPanel,t),t=new l.Z(["ui_changejob_respanel"]),this.AddInfo(p.I.ChangeJobResPanel,t),t=new l.Z(["ui_angel_eq_get_view"]),
this.AddInfo(p.I.AngelEquipGetView,t),t=new l.Z(["ui_access_panel","ui_access_normal_item","ui_access_mall_item"]),this.AddInfo(p.I.eAccessPanel,t),
t=new l.Z(["ui_access_currency_panel","ui_access_icon"]),this.AddInfo(p.I.eAccessCurrencyPanel,t),t=new l.Z(["ui_access_currency_panel2","ui_access_icon"]),
this.AddInfo(p.I.eAccessCurrencyPanel2,t),t=new l.Z(["ui_access_commonlist_panel","ui_access_icon"]),this.AddInfo(p.I.eAccessListCommonPanel,t),
t=new l.Z(["ui_alliance_asuramwarscoreshowpanel"]),this.AddInfo(p.I.AsuramWarScoreShowPanel,t),t=new l.Z(["ui_alliance_asuramwarfailpanel"]),
this.AddInfo(p.I.AsuramWarFailedPanel,t),t=new l.Z(["ui_alliance_asuramwarsucpanel"]),this.AddInfo(p.I.AsuramWarSucPanel,t),t=new l.Z(["ui_alliance_asuramwarhistorypanel"]),
this.AddInfo(p.I.AsuramWarHistoryPanel,t),t=new l.Z(["ui_alliance_asuramwardamagepanel"]),this.AddInfo(p.I.AsuramWarDamagePanel,t),t=new l.Z(["ui_arena_buynumview_ry"]),
this.AddInfo(p.I.eRyArenaBuyNumView,t),t=new l.Z(["ui_alliance_statisticspanel"]),this.AddInfo(p.I.AsuramWarStatisticsPanel,t),t=new l.Z(["ui_alliance_asuramwardowntimepanel"]),
this.AddInfo(p.I.AsuramWarDowntimePanel,t),t=new l.Z(["ui_copybase_gainview"]),this.AddInfo(p.I.KarimaGainView,t),t=new l.Z(["ui_redpacket_panel"]),this.AddInfo(p.I.REDPACKET,t),
t=new l.Z(["ui_asuramwar_doorpanel"]),this.AddInfo(p.I.AsuramWarDoorPanel,t),t=new l.Z(["ui_asuramwar_camppanel"]),this.AddInfo(p.I.AsuramWarCampPanel,t),
t=new l.Z(["ui_asuramwar_rulepanel"]),this.AddInfo(p.I.AsuramWarRulePanel,t),t=new l.Z(["ui_map_pass_alert_ry"]),this.AddInfo(p.I.MapPassAlertPanel,t),
t=new l.Z(["ui_exorcism_copy_traceview_ry"]),this.AddInfo(p.I.RyExorcismCopyTraceView,t),t=new l.Z(["ui_exorcism_copy_resultview_ry"]),this.AddInfo(p.I.RyExorcismCopyResultView,t),
t=new l.Z(["ui_exorcism_copy_buffselectview_ry"]),this.AddInfo(p.I.RyExorcismCopyBuffSelectView,t),t=new l.Z(["ui_horseskill_new_ry"]),this.AddInfo(p.I.HorseSkillAddPanel,t),
t=new l.Z(["ui_horse_skill_mainview","ui_horse_skill_mainview_item"]),this.AddInfo(p.I.HorseSkillShowMainView,t),
t=new l.Z(["ui_exorcism_rankreward_panel","ui_exorcism_rankreward_item","ui_exorcism_rankreward_roleitem"]),this.AddInfo(p.I.ExorcismRankRewardView,t),
t=new l.Z(["ui_exorcism_badgeeffect_panel","ui_exorcism_badgeeffect_item"]),this.AddInfo(p.I.ExorcismBadgeEffView,t),t=new l.Z(["ui_exorcism_main_panel"]),
this.AddInfo(p.I.ExorcismView,t),t=new l.Z(["ui_welfara_cdkeyview"]),this.AddInfo(p.I.CDKeyView,t),t=new l.Z(["ui_godsuitroad_mainpanel"]),this.AddInfo(p.I.GodSuitRoadPanel,t),
t=new l.Z(["ui_access_kindspanel"]),this.AddInfo(p.I.AccessKindsPanel,t),t=new l.Z(["ui_exorcism_rewardshowview_ry"]),this.AddInfo(p.I.ExorcismRewardShowView,t),
t=new l.Z(["ui_exorcism_totalrewardview_ry"]),this.AddInfo(p.I.ExorcismTotalRewardView,t),t=new l.Z(["ui_pandora_select_panel","ui_pandora_select_num_item"]),
this.AddInfo(p.I.PandoraSelectPanel,t),t=new l.Z(["ui_maze_timespace_mainview"]),this.AddInfo(p.I.MazeTimeSpaceView,t),
t=new l.Z(["ui_maze_room_view","ui_maze_room_item","ui_maze_room_line_h","ui_maze_room_line_v"]),this.AddInfo(p.I.MazeTimeSpaceRoomView,t),t=new l.Z(["ui_maze_result_view"]),
this.AddInfo(p.I.MazeTimeSpaceResultView,t),t=new l.Z(["ui_maze_market_view"]),this.AddInfo(p.I.TimeSpaceMarketView,t),t=new l.Z(["ui_maze_copy_info_panel"]),
this.AddInfo(p.I.MazeCopyRightPanel,t),t=new l.Z(["ui_asuramwar_rank_panel"]),this.AddInfo(p.I.AsuramWarRankPanel,t),t=new l.Z(["ui_usehangupitem_view"]),
this.AddInfo(p.I.UseHangItemView,t),t=new l.Z(["ui_maze_rule_view"]),this.AddInfo(p.I.MazeRulePanel,t),t=new l.Z(["ui_maze_getenergyview"]),this.AddInfo(p.I.MazeGetEnergyView,t),
t=new l.Z(["ui_ry_starsky_tabview"]),this.AddInfo(p.I.StarSkyTabView,t),t=new l.Z(["ui_comm_reward_view"]),this.AddInfo(p.I.CommRewardView,t),
t=new l.Z(["ui_sky_reward_pool_view"]),this.AddInfo(p.I.SkyRewardPoolView,t),t=new l.Z(["ui_asuramwar_altartracepanel"]),this.AddInfo(p.I.AWAltarTracePanel,t),
t=new l.Z(["ui_asuramwar_runenoticpanel"]),this.AddInfo(p.I.AWRuneNoticePanel,t),
t=new l.Z(["ui_element_enhancebag_view","ui_element_enhancebag_item","ui_element_enhancebag_popitem"]),this.AddInfo(p.I.ElementEnhanceBagView,t),
t=new l.Z(["ui_elecompound_bagview","ui_ele_elecompound_matitem"]),this.AddInfo(p.I.EleCompoundBagView,t),t=new l.Z(["ui_elecompoundsuccess","ui_elecompoundsuccess_attr"]),
this.AddInfo(p.I.EleCompoundSuccessView,t),t=new l.Z(["ui_ry_element_main_view"]),this.AddInfo(p.I.ElementItemMainVIew,t),
t=new l.Z(["ui_rolandappear_mainpanel","ui_ry_element_star_fly_item","ui_rolandappear_rewarditem","ui_rolandprogress_item","ui_rolandappear_rank_item","ui_rolandbuff_item"]),
this.AddInfo(p.I.RolandAppearMainView,t),t=new l.Z(["ui_rolandbuff_rewardview"]),this.AddInfo(p.I.RolandAppearBuffRewardView,t),
t=new l.Z(["ui_rolandvalley_copypanel","ui_bossassist_item","ui_roland_monster_item"]),this.AddInfo(p.I.RolandValleyCopyView,t),t=new l.Z(["ui_rolandvalley_copy_success"]),
this.AddInfo(p.I.RolandValleyCopySuccessView,t),t=new l.Z(["ui_roland_end_tipview"]),this.AddInfo(p.I.RolandEndTipView,t),t=new l.Z(["ui_ry_element_circle_showup_view"]),
this.AddInfo(p.I.ElementItemShowStageUpView,t),t=new l.Z(["ui_rechargebytester_view"]),this.AddInfo(p.I.RechargeByTester,t),t=new l.Z(["ui_ry_forge_wingpreview"]),
this.AddInfo(p.I.RyWingPreView,t),t=new l.Z(["ui_rolanddefense_main_view"]),this.AddInfo(p.I.RolandDefenseMainView,t),t=new l.Z(["ui_rolanddefense_copysuccess1"]),
this.AddInfo(p.I.RolandCopySuccess1,t),t=new l.Z(["ui_rolanddefense_senceview"]),this.AddInfo(p.I.RolandSenceView,t),
t=new l.Z(["ui_rolandsave_panel","ui_rolandsave_nest_view","ui_rolandsave_nest_item","ui_rolandsave_rank_item","ui_rolandsave_boss_view"]),this.AddInfo(p.I.RolandSavePanel,t),
t=new l.Z(["ui_rolandsave_add_power_panel"]),this.AddInfo(p.I.RolandSaveAddPowerPanel,t),
t=new l.Z(["ui_rolandsave_reward_rank_panel","ui_rolandsave_reward_rank_item0","ui_rolandsave_reward_rank_item1"]),this.AddInfo(p.I.RolandSaveRewardRankPanel,t),
t=new l.Z(["ui_rolandsave_first_enter_black_panel"]),this.AddInfo(p.I.RolandSaveFirstEnterBlackPanel,t),t=new l.Z(["ui_rolandsave_boss_cd_panel"]),
this.AddInfo(p.I.RolandSaveBossCD,t),t=new l.Z(["ui_rolandsave_fight_rank_panel"]),this.AddInfo(p.I.RolandSaveFightRankPanel,t),
t=new l.Z(["ui_rolandsave_wish_buff_tip","ui_rolandsave_wish_buff_item"]),this.AddInfo(p.I.RolandSaveWishBuffTip,t),t=new l.Z(["ui_rolandsave_boss_come_time_panel"]),
this.AddInfo(p.I.RolandSaveBossComeTimePanel,t),t=new l.Z(["ui_rolandsave_boss_reward_rank_tip","ui_rolandsave_boss_reward_rank_tip_item"]),
this.AddInfo(p.I.RolandSaveBossRewardRankTip,t),t=new l.Z(["ui_rolandsave_efficiency_mainui"]),this.AddInfo(p.I.RolandSaveEfficiencyMainUI,t),
t=new l.Z(["ui_themecarnival_panel","ui_themecarnival_right_btn","ui_themecarnival_top_btn","ui_themecarnival_reward_item"]),this.AddInfo(p.I.ThemeCarnival,t),
t=new l.Z(["ui_glorycallrootview"]),this.AddInfo(p.I.GloryCallRootView,t),t=new l.Z(["ui_dragontreasure_treasureshop_view","ui_dragontreasure_treasureshopitem"]),
this.AddInfo(p.I.GloryCallShopView,t),t=new l.Z(["ui_glorycallresultview"]),this.AddInfo(p.I.GloryCallResultView,t),
t=new l.Z(["ui_dragontreasure_panel","ui_dragontreasure_currencyitem"]),this.AddInfo(p.I.DragonTreasureView,t),
t=new l.Z(["ui_dragon_shopview","ui_dragon_buyitem","ui_drogonbuytip_iconitem"]),this.AddInfo(p.I.DragonTreasureBuyTipView,t),
t=new l.Z(["ui_dragontreasure_rareshop_panel","ui_dragontreasure_shopitem"]),this.AddInfo(p.I.DragonTreasureShopView,t),
t=new l.Z(["ui_dragontreasure_rewardpool_panel","ui_dragontreasure_rewardpool_item","ui_dragontreasure_rewarditem"]),this.AddInfo(p.I.DragonRewardPoolView,t),
t=new l.Z(["ui_dragontreasure_result_panel","ui_dragontreasure_openitem"]),this.AddInfo(p.I.DragonResultView,t),
t=new l.Z(["ui_dragontreasure_treasureshop_view","ui_dragontreasure_treasureshopitem"]),this.AddInfo(p.I.DragonTreasureTreasureShopView,t),t=new l.Z(["ui_expire_tip_view"]),
this.AddInfo(p.I.ExpireTip,t),t=new l.Z(["ui_expire_btn_view"]),this.AddInfo(p.I.ExpireTipBtn,t),t=new l.Z(["ui_huodongmall_buy_panel"]),this.AddInfo(p.I.HuoDongMallBuyPanel,t),
t=new l.Z(["ui_huodongmall_success_panel"]),this.AddInfo(p.I.HuoDongMallSuccessPanel,t),t=new l.Z(["ui_honorkings_mainpanel"]),this.AddInfo(p.I.HonorKingMainPanel,t),
t=new l.Z(["ui_rolandvalley_guide_showview","ui_rolandvalley_guide_flybtn"]),this.AddInfo(p.I.RolandGuideShowView,t),t=new l.Z(["ui_roland_notice_view"]),
this.AddInfo(p.I.RolandNoticeView,t),t=new l.Z(["ui_rolandsave_crusade_resultview_ry"]),this.AddInfo(p.I.RolandSaveCrusadeResultView,t),
t=new l.Z(["ui_rolandsave_crusade_traceview_ry","ui_map_pass_flyeff"]),this.AddInfo(p.I.RolandSaveCrusadeTraceView,t),t=new l.Z(["ui_rolandsave_copy_resultview_ry"]),
this.AddInfo(p.I.RolandSaveResultView,t),t=new l.Z(["ui_copybaseui_commonrightview","ui_rolandsave_copy_bossassistpanel","ui_bossassist_item"]),
this.AddInfo(p.I.RolandSaveMemberDamagePanel,t),t=new l.Z(["ui_maze_resetview"]),this.AddInfo(p.I.MazeTimeSpaceResetPanel,t),t=new l.Z(["ui_asuramwar_matchingpanel"]),
this.AddInfo(p.I.AWMatchingPanel,t),t=new l.Z(["ui_asuramwar_awscoreshowpanel"]),this.AddInfo(p.I.AWScoreShowPanel,t),
t=new l.Z(["ui_ry_forge_equiprefine_attrview","ui_ry_forge_equiprefine_commitem"]),this.AddInfo(p.I.RyEquipRefineAllAttrView,t),
t=new l.Z(["ui_ry_forge_equiprefine_refineview","ui_ry_forge_equiprefine_refineitem"]),this.AddInfo(p.I.RyEquipRefineRefineView,t),
t=new l.Z(["ui_ry_forge_equiprefine_replaceview"]),this.AddInfo(p.I.RyEquipRefineReplaceView,t),t=new l.Z(["ui_ry_forge_equiprefine_upgradesucview"]),
this.AddInfo(p.I.RyEquipRefineUpgradeSucView,t),t=new l.Z(["ui_fighttoken_getreward_tippanel"]),this.AddInfo(p.I.FightTokenGetTipPanel,t),t=new l.Z(["ui_publicbeta_mainview_ry"]),
this.AddInfo(p.I.RyPublicBetaMianView,t),t=new l.Z(["ui_publicbeta_jigsaw_lightchip_view"]),this.AddInfo(p.I.RyPublicBetaJigsawLightChipView,t),
t=new l.Z(["ui_publicbeta_totalrecharge_rewardview_ry"]),this.AddInfo(p.I.RyPublicBetaRewardView,t),t=new l.Z(["ui_springfestival_mainview_ry"]),
this.AddInfo(p.I.RySpringFestivalMainView,t),t=new l.Z(["ui_springfestival_resultview_ry"]),this.AddInfo(p.I.RySpringFestivalCelebrateResultView,t),
t=new l.Z(["ui_sf_goldcattle_getreward_view"]),this.AddInfo(p.I.RyGoldCattleRewardView,t),t=new l.Z(["ui_sf_fiveblesscome_shareview"]),this.AddInfo(p.I.FiveBlessComeShareView,t),
t=new l.Z(["ui_sf_fiveblesscome_exchangeview"]),this.AddInfo(p.I.FiveBlessComeExchangeView,t),t=new l.Z(["ui_sf_fiveblesscome_getreward_view"]),
this.AddInfo(p.I.FiveBlessComeRewardView,t),t=new l.Z(["ui_sf_springcattle_copypanel"]),this.AddInfo(p.I.SpringCattleCopyView,t),t=new l.Z(["ui_obelisk_panel"]),
this.AddInfo(p.I.ObeliskPanel,t),t=new l.Z(["ui_crime_buff_select_panel","ui_crime_buff_select_item"]),this.AddInfo(p.I.CrimeBuffSelectPanel,t),
t=new l.Z(["ui_crime_reward_rank_panel","ui_crime_reward_rank_item1","ui_crime_reward_rank_item0"]),this.AddInfo(p.I.CrimeRewardRankPanel,t),
t=new l.Z(["ui_crime_copy_end_time_panel"]),this.AddInfo(p.I.CrimeCopyEndTimePanel,t),t=new l.Z(["ui_crime_fight_buff_panel","ui_crime_fight_buff_item"]),
this.AddInfo(p.I.CrimeFightBuffPanel,t),t=new l.Z(["ui_crime_value_reward_panel"]),this.AddInfo(p.I.CrimeValueRewardPanel,t),t=new l.Z(["ui_crime_rank_reward_panel"]),
this.AddInfo(p.I.CrimeRankRewardPanel,t),t=new l.Z(["ui_crime_copy_suc_panel"]),this.AddInfo(p.I.CrimeCopySucPanel,t),t=new l.Z(["ui_crime_copy_fail_panel"]),
this.AddInfo(p.I.CrimeCopyFailPanel,t),t=new l.Z(["ui_publicbeta_daliy_tip_view"]),this.AddInfo(p.I.RyPublicBetaDaliyTipView,t),
t=new l.Z(["ui_publicbeta_daliy_reward_view","ui_publicbeta_daliy_reward_part","ui_publicbeta_daliy_reward_item"]),this.AddInfo(p.I.RyPublicBetaDaliyRewardView,t),
t=new l.Z(["ui_publicbeta_collect_reward_icon"]),this.AddInfo(p.I.RyPublicBetaCollctRewardIcon,t),t=new l.Z(["ui_publicbeta_collect_rewardview_ry"]),
this.AddInfo(p.I.RyPublicBetaCollctRewardView,t),t=new l.Z(["ui_superVip"]),this.AddInfo(p.I.SuperVipView,t),t=new l.Z(["ui_publicbeta_collect_sreenicon"]),
this.AddInfo(p.I.RyPublicBetaAutoCollctScreenIcon,t),t=new l.Z(["ui_ry_equipstaradvance_panel_new"]),this.AddInfo(p.I.RyEquipStarAdvanceView,t),
t=new l.Z(["ui_ry_equipstaradvance_selectpanel"]),this.AddInfo(p.I.RyEquipStarAdvanceSelectEquipView,t),
t=new l.Z(["ui_ry_equipstaradvance_success","ui_equipadvance_excellenceattr","ui_ry_equipadvance_show"]),this.AddInfo(p.I.RyEquipStarAdvanceSuccessEquipView,t),
t=new l.Z(["ui_limitedencore_mainview"]),this.AddInfo(p.I.LimitedEncorePanel,t),t=new l.Z(["ui_targetplayer_reportotherpanel"]),this.AddInfo(p.I.ReportPlayerPanel,t),
t=new l.Z(["ui_effectshoweditor_effectshowEditor","ui_effectshoweditor_effectshowItem"]),this.AddInfo(p.I.EffectShowEditor,t)
const i=new l.Z([p.I.eTabCommon,p.I.eMainViewPanel,p.I.TopSmallMap,p.I.eTaskMainUI,p.I.ShortCutSelectPanel,p.I.eMainViewExp,p.I.eChatShowPanel,p.I.MapLoading,p.I.BaseItem])
let n=0,s=0
for(;s<i.count;)n+=this.GetLoadPaths(i[s]).count,s+=1
t=new l.Z
let a=null,r=0,o=0
for(;o<i.count;){a=this.GetLoadPaths(i[o])
let e=0
for(;e<a.count;)null!=a[e]?(t[r]=a[e],r+=1):h.Y.LogError("不能传空"),e+=1
o+=1}let d=0
const u=f.allIconTypeToAtlas[_.b.eItem]
if(null!=u)for(;;){const e=u+d
if(!UIResFacade.HasResByPath(e,!1))break
t.Add(e),d+=1}t.Add("ui_guide_view"),t.Add("ui_guide_effect"),t.Add("ui_guide_roundeffect"),this.AddInfo(p.I.PreLoadMainView,t)}AddInfo(e,t){this.pathsDic.LuaDic_AddOrSetItem(e,t)}
GetLoadPaths(e){return this.pathsDic[e]}static Inst_get(){return null==S._instance&&(S._instance=new S,S._instance.InitModuleID()),S._instance}}S._instance=null
class g extends n.Component{constructor(...e){super(...e),this.resId=0}retainId(e){this._releaseRes(),e>0&&(this.resId=e,s.o._$retainRes(e))}_releaseRes(){const e=this.resId
e>0&&(this.resId=0,s.o._$releaseRes(e))}onDestroy(){this._releaseRes()}Destroy(){this._releaseRes()}}var m=i(31222)
class f{constructor(){this.m_callList=null,this.m_allCallList=null,this.m_OpenValues=null,this.m_countList=null,this.m_pathList=null,this.m_isTexture=null,this.uIdList=null,
this.m_bridgeItemDic=null,this.m_callList=new l.Z,this.m_allCallList=new l.Z,this.m_OpenValues=new l.Z,this.m_countList=new l.Z,this.m_pathList=new l.Z,this.m_isTexture=new l.Z,
this.uIdList=new l.Z,this.m_bridgeItemDic=new a.X}static LoadOne(e,t,i){const l=s.o.loadRes(e,n.Prefab,s.o.LoaderCache.RefTick)
s.o.listenRes(l,(s=>{if(!(s&&s instanceof n.Prefab))return void console.error(`error prefab url '${e}'`)
const a=(0,n.instantiate)(s)
if(a.addComponent(g).retainId(l),i){const e=a.getComponent(i)||a.addComponent(i)
__$LaunchLogicBridge._initBinderObject(e)}t(a)}))}static LoadScriptPrefab(e,t,i,l,a){let o
if(t&&(o=new t),!e)return
let d=e instanceof Array,h=d?e.length:1,u=h
if(e=d?e:e.split("*"),h>0)for(let d=0;d<u;d++){const u=s.o.loadRes(e[d],n.Prefab,s.o.LoaderCache.RefTick)
s.o.listenRes(u,(e=>{if(!(e&&e instanceof n.Prefab))return void console.error(`error prefab url '${u}'`)
const s=(0,n.instantiate)(e)
s.addComponent(g).retainId(u),t&&(s._addComponentInstance(o),(0,r.v)(o,s),__$LaunchLogicBridge._initBinderObject(o),null!=o.OnAddToScene&&o.OnAddToScene()),
l&&(a&&a.insert?l.insertChild(s,a.insert):l.addChild(s)),h--,h<=0&&i(o,a)}))}return o}static LoadByUid(e,t,i){const n=S.Inst_get().GetLoadPaths(e)
let s=!1
null!=i&&(s=!0),f.inst.ExeLoad(n,i,s,!1,t,e)}static Unload(e){}static InitIconUrl(){f.IconUrlDic=a.X.new(),f.IconUrlDic.LuaDic_AddOrSetItem(_.b.eItem,"WEB:/icon/bag/"),
f.IconUrlDic.LuaDic_AddOrSetItem(_.b.eEquip,"WEB:/icon/equip/"),f.IconUrlDic.LuaDic_AddOrSetItem(_.b.eSkill,"WEB:/icon/skill/"),
f.IconUrlDic.LuaDic_AddOrSetItem(_.b.eHorse,"WEB:/icon/horse/"),f.IconUrlDic.LuaDic_AddOrSetItem(_.b.eBuff,"WEB:/icon/buff/"),
f.IconUrlDic.LuaDic_AddOrSetItem(_.b.eTitle,"WEB:/chenghao/chenghao1/"),f.IconUrlDic.LuaDic_AddOrSetItem(_.b.eEquipRefineAttr,"WEB:/icon/refining/"),
f.IconUrlDic.LuaDic_AddOrSetItem(_.b.eTechnology,"WEB:/icon/technology/"),f.IconUrlDic.LuaDic_AddOrSetItem(_.b.eBuff,"WEB:/icon/buff/"),
f.IconUrlDic.LuaDic_AddOrSetItem(_.b.eDrop,"WEB:/icon/drop/")}static SetItemIcon(e,t,i,s=!0,l){e.sizeMode=s?n.Sprite.SizeMode.TRIMMED:n.Sprite.SizeMode.CUSTOM,
null==f.IconUrlDic&&f.InitIconUrl()
const a=f.IconUrlDic.LuaDic_GetItem(i)
if(e.skin=`${a+t}.png`,e instanceof o.i){const t=e.flowLightColor3
e.flowLightColor1=new n.Color(t.r,t.g,t.b,0),e.flowLightColor2=new n.Color(t.r,t.g,t.b,0),e.flowLightColor3=new n.Color(t.r,t.g,t.b,0),l&&(e.flowLightColor1=l.color1,
e.flowLightColor2=l.color2,e.flowLightColor3=l.color3)}}static UpdateIconFlow(e,t){t&&e instanceof o.i&&(e.flowLightColor1=t.color1,e.flowLightColor2=t.color2,
e.flowLightColor3=t.color3)}static SetImageRender(e,t,i,s=!0){e.img.sizeMode=s?n.Sprite.SizeMode.TRIMMED:n.Sprite.SizeMode.CUSTOM,null==f.IconUrlDic&&f.InitIconUrl()
const l=f.IconUrlDic.LuaDic_GetItem(i)
e.skin=`${l+t}.png`}static GetResFindId(e){return 0}static DestroyUIObj(e){null==f._allDestroyedIds[e.FatherId]&&(f._allDestroyedIds[e.FatherId]=!0,
e.IsRootPrefab&&!e.IsRootPrefab()&&h.Y.LogError("不是通过加载的别调用这里"),(0,d.t2)(e,u.f)&&(e.m_ReadyDestory=!0,m.N.inst.DestoryPanel(e.FatherId)),f.DestroyUIById(e.FatherId))}
static DestroyUIById(e){}static DestroyView(e){}}f._allDestroyedIds={},f.allAtlasToIconType={},f.allIconTypeToAtlas={},f.curCustomIconTypeMax=1e3,f.inst=new f,f.IconUrlDic=null},
31222:(e,t,i)=>{i.d(t,{N:()=>f})
i(22267)
var n=i(17409),s=i(92679),l=i(87923),a=i(68637),r=i(81629),o=i(44644),d=i(51576),h=i(98885),u=i(85602),c=i(38962),I=i(52212),_=i(38836),p=i(38045),S=i(97461),g=i(61911),m=i(5494)
class f{constructor(){this.isUnLoad=!1,this.m_findDic=null,this.m_hideDic=null,this.m_loadingDic=null,this.eventLayerCallId=0,this.m_layerCallHandlers=null,
this.m_curExclusionId=-1,this.m_curExclusionIdList=null,this.colliderLoadDict=null,this.colliderLoadResult=null,this.colliderLoadResultList=null,this.firstPanelList=null,
this.isLoadingCollider=!1,this._degf_ColliderLoadComplete=null,this._degf_OnLayerClickCallBack=null,this._degf_OnUIRootLoaded=null,this.m_compDic=null,this.m_findDic=new c.X,
this.m_hideDic=new c.X,this.m_loadingDic=new c.X,this.m_layerCallHandlers=new u.Z,this.m_curExclusionIdList=new u.Z,this.colliderLoadDict=new u.Z,this.colliderLoadResult=new c.X,
this.colliderLoadResultList=new u.Z,this.firstPanelList=new u.Z,this._degf_ColliderLoadComplete=e=>this.ColliderLoadComplete(e),
this._degf_OnLayerClickCallBack=()=>this.OnLayerClickCallBack(),this._degf_OnUIRootLoaded=e=>this.OnUIRootLoaded(e)}OpenLogin(){
const e=LuaCallBackMgr.AddCallBackLoadComplete(this._degf_OnUIRootLoaded)
UIShowFacade.InitRoot(e)
const t=ConfigManager.getInstance().GetStringValue("VEDIO:ID"),i=h.M.Split(t,";")
for(let e=0;e<=i.Count()-1;e++)LuaMovieBridgeManager.Inst_get().InitVideo(i[e])}InstOpenLogin(){f.inst.OpenLogin()}GetUIRootSize(){const e=new I.F(0,0)
return e.x=UIShowFacade.rootManualWidth(),e.y=UIShowFacade.rootManualHeight(),e}GetUIRootPosition(){return UIShowFacade.GetUIRootPosition()}SetUICameraLocalPosition(e,t,i){
UIShowFacade.SetUICameraLocalPosition(e,t,i)}GetScreenRatio(){return UIUtilBridge.GetScreenWidth()/UIUtilBridge.GetScreenHeight()}SetDirVisible(e,t){UIShowFacade.SetDirVisible(e,t)
}PlaySingleDirectionAnim(e,t){UIShowFacade.PlaySingleDirectionAnim(e,t)}IsStoryOut_Get(){return f.isStoryOut}PlaySingleDirectionAllAnim(e){f.isStoryOut=!0,
this.PlaySingleDirectionAnim(LuaDirectionType.DefaultLeft,e),this.PlaySingleDirectionAnim(LuaDirectionType.DefaultRight,e),
this.PlaySingleDirectionAnim(LuaDirectionType.DefaultRight2,e),this.PlaySingleDirectionAnim(LuaDirectionType.DefaultRight3,e),
this.PlaySingleDirectionAnim(LuaDirectionType.DefaultUp,e),this.PlaySingleDirectionAnim(LuaDirectionType.DefaultDown,e),
this.PlaySingleDirectionAnim(LuaDirectionType.DefaultDown2,e),this.PlaySingleDirectionAnim(LuaDirectionType.DefaultDown3,e),
this.PlaySingleDirectionAnim(LuaDirectionType.MainLeft,e),this.PlaySingleDirectionAnim(LuaDirectionType.MainRight,e),this.PlaySingleDirectionAnim(LuaDirectionType.MainUp,e),
this.PlaySingleDirectionAnim(LuaDirectionType.MainDown,e),this.PlaySingleDirectionAnim(LuaDirectionType.MainDown2,e),this.PlaySingleDirectionAnim(LuaDirectionType.NpcRight,e),
this.PlaySingleDirectionAnim(LuaDirectionType.ExpbarDown,e)}RemoveSingleDirectionAnim(e){UIShowFacade.RemoveSingleDirectionAnim(e)}RemoveAllSingleDirectionAnimOnce(){
f.isStoryOut=!1,this.RemoveSingleDirectionAnim(LuaDirectionType.DefaultLeft),this.RemoveSingleDirectionAnim(LuaDirectionType.DefaultRight),
this.RemoveSingleDirectionAnim(LuaDirectionType.DefaultRight2),this.RemoveSingleDirectionAnim(LuaDirectionType.DefaultRight3),
this.RemoveSingleDirectionAnim(LuaDirectionType.DefaultUp),this.RemoveSingleDirectionAnim(LuaDirectionType.DefaultDown),
this.RemoveSingleDirectionAnim(LuaDirectionType.DefaultDown2),this.RemoveSingleDirectionAnim(LuaDirectionType.DefaultDown3),
this.RemoveSingleDirectionAnim(LuaDirectionType.MainLeft),this.RemoveSingleDirectionAnim(LuaDirectionType.MainRight),this.RemoveSingleDirectionAnim(LuaDirectionType.MainUp),
this.RemoveSingleDirectionAnim(LuaDirectionType.MainDown),this.RemoveSingleDirectionAnim(LuaDirectionType.MainDown2),this.RemoveSingleDirectionAnim(LuaDirectionType.NpcRight),
this.RemoveSingleDirectionAnim(LuaDirectionType.ExpbarDown)}RemoveAllSingleDirectionAnim(){f.isStoryOut=!1,UIShowFacade.RemoveAllSingleDirectionAnim()}ShowMainView(){
this.RemoveAllSingleDirectionAnim()}HideMainView(){this.PlaySingleDirectionAllAnim(!0)}ScreenFadeIn(e){UIShowFacade.ScreenFadeIn(e)}ScreenFadeOut(e){UIShowFacade.ScreenFadeOut(e)}
ShowGlobalCollider(){UIShowFacade.ShowGlobalCollider()}HideGlobalCollider(){UIShowFacade.HideGlobalCollider()}OnUIRootLoaded(e){
GameLoginModel.Instance.RaiseEvent(GameLoginModel.eStateChange,GameLoginModel.eLoginState),r.K.inst.OpenLoadEffectPanel(),r.K.inst.OpenButtonEffectPanel(),r.K.inst.OpenNotchView()}
SetRockerVisible(e){UIShowFacade.SetRockerVisible(e)}OpenById(e,t,i,s,l){(0,n.Yp)(e,s,l)}OpenByIdTwo(e,t,i,n){t()}CheckWaitMsgShow(e){
return!!f.m_compDic.LuaDic_ContainsKey(e)&&(f.m_compDic[e].waitShow?(f.m_compDic[e].RealShow(),!0):!f.m_compDic[e].isClose)}GetViewById(e){return(0,n.Y)(e)}GetViewByFatherId(e){
let t=null
return this.m_findDic.LuaDic_ContainsKey(e)?(t=this.m_findDic[e],t.m_panel):null}IsViewShowing(e,t){return(0,n.qJ)(e,t)}DealDefaultLayerVisible(e,t){}AddAlertLayerClick(e){
const t=e.param_get()
null!=t&&null!=t.layerClickHandler&&(this.m_layerCallHandlers.Add(t.layerClickHandler),
0==this.eventLayerCallId&&(this.eventLayerCallId=LuaCallBackMgr.AddCallBackEventCallback(this._degf_OnLayerClickCallBack)),e.eventLayerCallId=this.eventLayerCallId)}
OnLayerClickCallBack(){this.eventLayerCallId=0
let e=0
for(;e<this.m_layerCallHandlers.Count();)this.m_layerCallHandlers[e](),e+=1
this.m_layerCallHandlers.Clear()}RemoveLyaerClickHandler(e){const t=this.m_layerCallHandlers.IndexOf(e,0)
t>-1&&this.m_layerCallHandlers.RemoveAt(t),0==this.m_layerCallHandlers.Count()&&(LuaCallBackMgr.RemoveCallBackEventCallback(this.eventLayerCallId),this.eventLayerCallId=0,
UIShowFacade.CancelAlertClick())}ShowComplete(e){f.m_compDic.LuaDic_ContainsKey(e.uId)||(this.m_loadingDic.LuaDic_Remove(e.uId),this.AddCompToDic(e),this.AddOrDelHideComp(e,!0))}
InitEnd(e){this.OpenFirstPanel(e)}AddCompToDic(e){f.m_compDic.LuaDic_AddOrSetItem(e.uId,e),this.m_findDic.LuaDic_AddOrSetItem(e.findId,e),this.AddOrDelHideComp(e,!0)}ReShowById(e){
if(f.m_compDic.LuaDic_ContainsKey(e)){const t=f.m_compDic[e]
if(!t.isClose)return t.ReShow(),this.AddOrDelHideComp(t,!0),!0}return!1}HideById(e){if(f.m_compDic.LuaDic_ContainsKey(e)){const t=f.m_compDic[e]
t.Hide(),this.AddOrDelHideComp(t,!1)}}CloseById(e,t=null,i=null){if((0,n.sR)(e),null==i&&(i=!1),null==t&&(t=!1),
this.m_loadingDic.LuaDic_ContainsKey(e))return this.CloseFirstPanel(this.m_loadingDic.LuaDic_GetItem(e)),this.UnLoading(e),this.UnLoadDataClear(this.m_loadingDic[e]),
r.K.inst.StopLoadEffect(),void(e==m.I.eChatMainPanel&&o.T.inst.PhotoHideLayerState_set(d.N.ChatPanleType,!0,null))
if(f.m_compDic.LuaDic_ContainsKey(e)){const n=f.m_compDic[e]
if(this.CloseFirstPanel(n),n.Close(t,i,null),n.isClose=!0,this.AddOrDelHideComp(n,!1),
e==this.m_curExclusionId)if(this.m_curExclusionIdList.Count()>0)for(;this.m_curExclusionIdList.Count()>0;){const t=this.m_curExclusionIdList.Count()-1
if(this.m_curExclusionId=this.m_curExclusionIdList[t],this.m_curExclusionIdList.RemoveAt(t),e!=this.m_curExclusionId&&this.ReShowById(this.m_curExclusionId))break
}else this.m_curExclusionId=0}}OpenFirstPanel(e){if(!this.IsFirstPanelByComp(e))return
this.ClearFirstPanel(),S.i.Inst.RaiseEvent(s.g.FIRST_PANEL_OPEN,!0)
const t=this.firstPanelList.IndexOf(e)
if(-1!=t){if(t!=this.firstPanelList.Count()-1){let e=this.firstPanelList.Count()-1
for(;e>t;)this.CloseById(this.firstPanelList[e].uId),e-=1}}else this.firstPanelList.Count()==f.MAX_FIRST_PANEL_CNT&&this.CloseById(this.firstPanelList[0].uId),
this.firstPanelList.Count()==f.MAX_FIRST_PANEL_CNT-1&&this.firstPanelList[this.firstPanelList.Count()-1].m_panel.SetLocalPositionXYZ(-1e4,0,0),this.firstPanelList.Add(e)
e.m_panel.playAni=!1}CloseFirstPanel(e){if(this.IsFirstPanelByComp(e))if(this.ClearFirstPanel(),-1!=this.firstPanelList.IndexOf(e)&&this.firstPanelList.Remove(e),
this.firstPanelList.Count()>0){const e=this.firstPanelList[this.firstPanelList.Count()-1]
e.m_panel.SetLocalPositionXYZ(0,0,0),this.IsFirstPanelByComp(e)&&null!=e.m_panel.PlayAni&&(e.m_panel.PlayAni(),e.m_panel.playAni=!1)
}else S.i.Inst.RaiseEvent(s.g.FIRST_PANEL_OPEN,!1)}ClearFirstPanel(){let e=this.firstPanelList.Count()-1
for(;e>=0;)this.IsFirstPanelByComp(this.firstPanelList[e])?this.firstPanelList[e].playAni=!0:this.firstPanelList.RemoveAt(e),e-=1}ClosePanel(e){(0,n.sR)(e)}AddOrDelHideComp(e,t){
t?this.m_hideDic.LuaDic_ContainsKey(e.uId)&&this.m_hideDic.LuaDic_Remove(e.uId):this.m_hideDic.LuaDic_AddOrSetItem(e.uId,e)}DealExclusionPanel(e){if(e.isExclusionPanel){
if(this.m_curExclusionId==e.showComp.uId)return
if(this.m_curExclusionId>0&&!e.isKillAllExcluded){const t=this.m_curExclusionIdList.IndexOf(e.showComp.uId,0);-1!=t&&this.m_curExclusionIdList.RemoveAt(t)
let i=!0
if(null!=e.exclusionIds){let t=0
for(;t<e.exclusionIds.count;){if(e.exclusionIds[t]==this.m_curExclusionId){i=!1
break}t+=1}}i?(this.m_curExclusionIdList.Add(this.m_curExclusionId),this.HideById(this.m_curExclusionId)):this.CloseById(this.m_curExclusionId,!1,!0),
BagManager.Inst_get().CloseAllTip()}if(e.isKillAllExcluded){this.m_curExclusionId>0&&this.m_curExclusionIdList.Add(this.m_curExclusionId),this.m_curExclusionId=0
let t=this.m_curExclusionIdList.Count()-1
for(;t>=0;){if(e.showComp.uId!=this.m_curExclusionIdList[t]){const e=this.m_curExclusionIdList[t]
this.m_compDic.LuaDic_ContainsKey(e)&&(this.m_compDic[e].DoExclusive(),this.CloseById(e,!1,!0))}t-=1}this.m_curExclusionId=0,
e.isCanNotBeExcluded||(this.m_curExclusionId=e.showComp.uId),this.m_curExclusionIdList.Clear(),this.CloseFirstClassPanel(),BagManager.Inst_get().CloseAllTip(),
CommonHintController.Inst.OutClosePanel(),CommonHintController.Inst.CloseTopLayerPanel(!0),CommTextTipsControl.Inst_get().Close(),a.c.Inst.RemoveForceGuide()
}else this.m_curExclusionId=e.showComp.uId}}SetChildDepth(e,t){0}GetRootBasePanelByFatherId(e){for(const[t,i]of(0,_.V5)(this.m_findDic)){const n=i.m_panel
if(t==e)return n
if(null!=n&&n.subLoadedChild.Contains(e))return n}return null}GetUIParentId(e,t,i){return UIShowFacade.GetUIParentId(e,t,i)}SetPanelToTopDepth(e){UIShowFacade.SetPanelToTopDepth(e)
}ChangeDepthValue(e,t,i){UIShowFacade.ChangeDepthValue(e,t,i)}SetHeadPanelParent(e,t,i){null==i&&(i=!1),null==t&&(t=!1),UIShowFacade.SetHeadPanelParent(e,t,i)}
SetHideLayerEnable(e){UIShowFacade.SetHideLayerEnable(e)}DestoryPanel(e){if(this.m_findDic.LuaDic_ContainsKey(e)){const t=this.m_findDic[e]
f.m_compDic.LuaDic_Remove(t.uId),this.m_findDic.LuaDic_Remove(t.findId),this.m_hideDic.LuaDic_Remove(t.uId),t.Destory()}}GetObjRootPanelDepth(e){
return UIShowFacade.GetObjRootPanelDepth(e)}SetParentTran(e,t,i,n,s,l,a){null==a&&(a=0),null==l&&(l=!1),null==s&&(s=!1),UIShowFacade.SetParentTran(e,t,i,n,s,l,a)}
CallControlDestroyById(e){let t=null
f.m_compDic.LuaDic_ContainsKey(e)&&(t=f.m_compDic[e],t.CallControlDestory())}OpenUIByShortCutID(e,t,i){return INS.uIShowShortCut.OpenUIByShortCutID(e,t,null,null,i)}
OpenUIByShortCutIDWithPlayerId(e,t,i,n){return INS.uIShowShortCut.OpenUIByShortCutID(e,t,null,n,i)}OpenUIByStrIdWithParam(e,t,i){const n=h.M.Split(e,h.M.s_CCD_CHAR)
return INS.uIShowShortCut.OpenUIByShortCutID(h.M.String2Int(n[0]),t,e,i)}OpenUIByShortCutIDStr(e,t,i,n){"string"!=typeof e&&(e=(0,p.tw)(e))
const s=h.M.Split(e,h.M.s_CCD_CHAR)
return INS.uIShowShortCut.OpenUIByShortCutID(h.M.String2Int(s[0]),t,e,i,null,n)}OpenUIByShortCutIDOpenUI(e){"string"!=typeof e&&(e=(0,p.tw)(e))
const t=h.M.Split(e,h.M.s_CCD_CHAR)
return INS.uIShowShortCut.OpenUIByShortCutID(h.M.String2Int(t[0]),null,e)}OpenUIByFuncFather(e){
if(null!=TaskViewManager.Inst_get().model.goUIParam&&!l.l.IsEmptyStr(TaskViewManager.Inst_get().model.goUIParam.OpenUI_get())){
const t=UIIDCfgManager.Inst().GetFathersById(TaskViewManager.Inst_get().model.goUIParam.uiID)
if(!h.M.IsNullOrEmpty(t)&&t==e)return this.OpenUIByShortCutIDStr(TaskViewManager.Inst_get().model.goUIParam.OpenUI_get())}return TaskViewManager.Inst_get().model.goUIParam=null,!1}
AddFullScreenCollider(e,t,i,n,s,l){if(null==s&&(s=!0),null==n&&(n=!0),null==t&&null==i)return
let a=null
a=this.colliderLoadResult.LuaDic_GetItem(e.FatherId),null==a&&(a=new LoadColliderItem,null!=t&&(a.clickCallback=t),null!=i?a.dragStartCallback=i:s&&(a.dragStartCallback=t),
a.onInitCallback=l,a.root=e,a.isThrough=n,this.colliderLoadDict.Add(a),this.isLoadingCollider||(this.isLoadingCollider=!0,
UIResMgr.LoadOne("ui_comm_fullscreencollider",this._degf_ColliderLoadComplete)))}ColliderLoadComplete(e){const t=e[0],i=new LuaBehaviour
i.setId(t,null,0)
const n=this.colliderLoadDict.Count()
let s=0
for(;s<n;){const e=UIResMgr.GetResFindId("ui_comm_fullscreencollider")
this.SetCollider(e),s+=1}UIResMgr.DestroyUIObj(i),this.isLoadingCollider=!1}SetCollider(e){const t=new LuaBehaviour
if(t.setId(e,null,0),t.node.transform.ComponentId=-1,this.colliderLoadDict.Count()>0){const e=ContainerProxy.PopFront(this.colliderLoadDict)
if(e.collider=t,null!=e.root){if(t.node.transform.SetParent(e.root.FatherId,e.root.ComponentId)){this.SetBoxColliderThrough(t.FatherId,t.ComponentId,e.isThrough)
const i=LuaUIEventListener.Get(t.node)
null!=e.clickCallback&&i.RegistonClick(e.clickCallback),null!=e.dragStartCallback&&i.RegistonDragStart(e.dragStartCallback),
this.colliderLoadResult.LuaDic_AddOrSetItem(e.root.FatherId,e),null!=e.onInitCallback&&e.onInitCallback()}else this.colliderLoadResult.LuaDic_AddOrSetItem(e.root.FatherId,e),
this.RemoveFullScreenCollider(e.root.FatherId)}else UIResMgr.DestroyUIObj(e.collider)}}GetFullScreenCollider(e){let t=null
return t=this.colliderLoadResult.LuaDic_GetItem(e),null!=t?t.collider:null}SetFullScreenColliderMask(e,t){let i=null
i=this.colliderLoadResult.LuaDic_GetItem(e),null!=i&&this.SetFullScreenColliderBackgroundMask(i.collider.FatherId,i.collider.ComponentId,t)}SetFullScreenColliderThrough(e,t){
let i=null
i=this.colliderLoadResult.LuaDic_GetItem(e),null!=i&&this.SetBoxColliderThrough(i.collider.FatherId,i.collider.ComponentId,t)}RemoveFullScreenCollider(e){let t=null
if(t=this.colliderLoadResult.LuaDic_GetItem(e),null!=t&&null!=t.collider){if(null!=t.clickCallback){LuaUIEventListener.Get(t.collider.node).RemoveonClick(t.clickCallback)}
if(null!=t.dragStartCallback){LuaUIEventListener.Get(t.collider.node).RemoveonDragStart(t.dragStartCallback)}this.colliderLoadResult.LuaDic_Remove(e),
UIResMgr.DestroyUIObj(t.collider)}this.colliderLoadResult.LuaDic_Remove(e)
let i=0
for(;i<this.colliderLoadDict.Count();){if(null!=this.colliderLoadDict[i].root&&this.colliderLoadDict[i].root.FatherId==e){this.colliderLoadDict[i].root=null,
this.colliderLoadDict.RemoveAt(i)
break}i+=1}}ClearFullScreenCollider(){const e=new u.Z
for(const[t,i]of(0,_.vy)(this.colliderLoadResult))e.Add(t)
let t=0
for(;t<e.Count();)this.RemoveFullScreenCollider(e[t]),t+=1
this.colliderLoadResult.LuaDic_Clear(),this.isLoadingCollider=!1}ClearAllPanel(e,t,i,s){null==s&&(s=!1),null==i&&(i=-1),null==t&&(t=!1),null==e&&(e=!1),e&&(0,n.dU)(i,t,s),
this.m_curExclusionIdList.Clear(),this.m_curExclusionId=-1,a.c.Inst.RemoveForceGuide()}CloseAllExclusivePanel(e=-1){(0,n.eW)(e)}CloseFirstClassPanel(){for(const[e,t]of(0,
_.vy)(f.m_compDic)){const t=f.m_compDic[e];(this.IsFirstPanelByComp(t)||this.IsForceCloseByGoAccess(t))&&this.CloseById(t.uId)}}ForceCloseByGoAccess(){for(const[e,t]of(0,
_.vy)(f.m_compDic)){const t=f.m_compDic[e]
this.IsForceCloseByGoAccess(t)&&this.CloseById(t.uId)}}IsFirstPanelByComp(e){return!(null==e.m_panel||!(0,p.t2)(e.m_panel,g.f)||!e.m_panel.IsFirstPanel_Get())}
IsForceCloseByGoAccess(e){return!(null==e.m_panel||!(0,p.t2)(e.m_panel,g.f)||!e.m_panel.IsForceCloseByGoAccess())}UnLoadDataClear(e){this.m_loadingDic.LuaDic_Remove(e.uId),
null!=e.param_get().layerClickHandler&&this.RemoveLyaerClickHandler(e.param_get().layerClickHandler),e.Destory()}UnLoading(e){let t=null
t=this.m_loadingDic.LuaDic_GetItem(e),null!=t&&(t.isUnLoad=!0)}SetBoxColliderThrough(e,t,i){UIShowFacade.SetBoxColliderThrough(e,t,i)}SetFullScreenColliderBackgroundMask(e,t,i){
UIShowFacade.SetFullScreenColliderMask(e,t,i)}IsPlayingTween(){return UIShowFacade.IsPlayingTween()}PlayMainAnim(e){UIShowFacade.PlayMainUIAnim(e)}IsMainPlayOut(){
return UIShowFacade.IsMainUIPlayOut()}IsAllDefaultUIHide(){return UIShowFacade.IsAllDefaultUIHide()}IsAnyDefaultUIHide(){return UIShowFacade.IsAnyDefaultUIHide()}
IsSingleDirectionHide(e){return UIShowFacade.IsSingleDirectionHide(e)}GetAllHideUIDirection(){return UIShowFacade.GetAllHideUIDirection()}GetShieldUIDs(){return f.shiledUID}}
f.m_compDic=new c.X,f.MAX_FIRST_PANEL_CNT=2,f.inst=new f,f.isStoryOut=!1,f.shiledUID=[m.I.eDialoguePanel]},17705:(e,t,i)=>{
var n,s,l,a=i(42292),r=i(93343),o=i(53810),d=i(87717),h=i(31192),u=i(22107),c=i(85430),I=i(80486),_=i(28734),p=i(41163),S=i(84229),g=i(87851),m=i(21554),f=i(70850),C=i(86770),T=i(63076),y=i(86399),A=i(56131),P=i(13994),w=i(78592),R=i(58158),D=i(26753),L=i(54130),E=i(51965),B=i(31922),M=i(13526),G=i(87923),O=i(78417),U=i(92473),b=i(33275),F=i(82550),k=i(90034),v=i(80740),N=i(10429),V=i(72652),x=i(2457),H=i(48933),Z=i(87530),Y=i(64649),W=i(91897),K=i(21987),z=i(6667),j=i(57035),X=i(37648),q=i(55492),J=i(11037),$=i(22662),Q=i(60128),ee=i(33543),te=i(32691),ie=i(12842),ne=i(93727),se=i(59616),le=i(33072),ae=i(61249),re=i(35073),oe=i(956),de=i(94935),he=i(94582),ue=i(25606),ce=i(98936),Ie=i(43709),_e=i(82949),pe=i(76887),Se=i(10231),ge=i(49831),me=i(11740),fe=i(69664),Ce=i(60028),Te=i(14187),ye=i(5031),Ae=i(89427),Pe=i(83900),we=i(21267),Re=i(11162),De=i(31896),Le=i(66988),Ee=i(51704),Be=i(77697),Me=i(43308),Ge=i(14306),Oe=i(2574),Ue=i(76218),be=i(59136),Fe=i(31336),ke=i(73581),ve=i(27193),Ne=i(18414),Ve=i(6769),xe=i(97438),He=i(83378),Ze=i(53012),Ye=i(52053),We=i(72268),Ke=i(50748),ze=i(57553),je=i(64501),Xe=i(35259),qe=i(62405),Je=i(26619),$e=i(96297),Qe=i(65550),et=i(57651),tt=i(41825),it=i(62783),nt=i(12970),st=i(78922),lt=i(37151),at=i(19276),rt=i(88934),ot=i(22046),dt=i(12417),ht=i(15771),ut=i(71893),ct=i(95155),It=i(13224),_t=i(95721),pt=i(98885),St=i(85602),gt=i(38962),mt=i(38836),ft=i(86133),Ct=i(38045),Tt=i(11210),yt=i(98800),At=i(62370),Pt=i(66788),wt=i(72637),Rt=i(37142),Dt=i(85682)
let Lt=new gt.X;(0,a.gK)("GameSys.UIShowShortCut")((l=class e{static __StaticInit(){}static Inst_get(){return null==e._Inst&&(e._Inst=new e),e._Inst}
OpenUIByShortCutID(e,t,i,n,s,l){let a=this.CheckFuncOpen(e)
if(!a)return
ye.T.inst_get().control.CloseBuffDetailPanel()
let x=null
if(pt.M.IsNullOrEmpty(i)||(x=pt.M.Split(i,pt.M.s_CCD_CHAR)),e==Dt.D.Title)R.U.Inst_get().topViewType=L.Q.Normal,R.U.Inst_get().characterViewType=E.f.TITLE,w.l.Inst().Open(null,n)
else if(e==Dt.D.ProSkill){Xe.C.INSTANCE.curShowChildView=M.c.ProSkill,Xe.C.INSTANCE.isQuickOpenBag&&m.J.Inst_get().closeBag()
let e=null
const i=t
let s=n;(0,Ct.t2)(i,T.M)&&([s,e]=je.B.inst.GetPlayerIndexFromSkillByBagItem(i),Xe.C.INSTANCE.characterTabIdx=s),Ye.d.Inst_get().OpenView(We.l.SKILL_VIEW,e,s)
}else if(e==Dt.D.Fruit){let e=0
if(null!=t){const i=t
e=i.modelId_get(),null==n&&(n=i.playerIdx)}z.h.Inst().OpenView(e,n)}else if(e==Dt.D.EquipEnhance)Ne.v.Inst().OpenForgePanel(Ve.o.ENHANCE_VIEW,n)
else if(e==Dt.D.Equip_Refine)Ne.v.Inst().OpenForgePanel(Ve.o.EQUIPREFINE_VIEW,n)
else if(e==Dt.D.EquipAdd)Ne.v.Inst().OpenForgePanel(Ve.o.ADDTION_VIEW,n)
else if(e==Dt.D.EquipLucky)Ne.v.Inst().OpenForgePanel(Ve.o.LUCKYADD_VIEW,n)
else if(e==Dt.D.forge_suit)m.J.Inst_get().openOrClose(C.D.rySuit)
else if(e==Dt.D.DIVINE)R.U.Inst_get().topViewType=L.Q.DIVINE,w.l.Inst().Open(L.Q.DIVINE,n)
else if(e==Dt.D.EquipAdvance)Ne.v.Inst().OpenForgePanel(Ve.o.EQUIPADVANCE_VIEW,n)
else if(e==Dt.D.WingRefine)Ne.v.Inst().OpenForgePanel(Ve.o.WINGREFINE_VIEW,n)
else if(e==Dt.D.RyCompound){let e,t
null!=x&&(x[1]&&(e=pt.M.String2Int(x[1])),x[2]&&(t=pt.M.String2Int(x[2]))),Rt.V.Inst_get().JumpToRyCompoundPanel(e,t)
}else if(e==Dt.D.RIDIN_MAT_COMPOSE)Rt.V.Inst_get().JumpToRyCompoundPanel(Fe.K.HORSE,null)
else if(e==Dt.D.ObtainPanel){if(null!=x&&x.Count()>2&&1==pt.M.String2Int(x[1])){H.I.calVec0.Set(0,0,0)
const e=new St.Z
e.AddRange(pt.M.Split(x[2],At.o.s_Arr_UNDER_CHAR_DOU))
for(let t=0;t<=e.Count()-1;t++)e[t]=pt.M.String2Int(e[t])
Me._.Inst_get().OpenByWay(e)}}else if(e==Dt.D.TaskObtainPanel){if(null!=x&&x.Count()>2&&1==pt.M.String2Int(x[1])){H.I.calVec0.Set(0,0,0)
const e=new St.Z
e.AddRange(pt.M.Split(x[2],At.o.s_Arr_UNDER_CHAR_DOU))
for(let t=0;t<=e.Count()-1;t++)e[t]=pt.M.String2Int(e[t])
Me._.Inst_get().OpenTaskObtainByWay(e,H.I.calVec0,0,et.i.ins.GetTaskMainUIPanelAnchPosRefSpr(),!1)}}else if(e==Dt.D.Arena)k.s.Inst_get().Open(v.F.ArenaCopy)
else if(e==Dt.D.Recover)ut.u.Inst_get().viewType=ct.S.RECOVER,It.w.Inst_Get().OpenPanel()
else if(e==Dt.D.Boss)null!=x&&2==x.count?rt.$.Inst().OpenByType(ot.l.WORLDBOSS,pt.M.String2Int(x[1])):rt.$.Inst().OpenByType(ot.l.WORLDBOSS)
else if(e==Dt.D.MAP_PASS_TIP){const e=we.u.Inst().GetNextPassVo(we.u.Inst().nowFightVo)
null!=e&&Pe.N.Inst().OpenMapPassTips(e.id)
}else if(e==Dt.D.GOLD_DIAMOND_MALL||e==Dt.D.HONOUR_SHOP||e==Dt.D.GOLD_MALL||e==Dt.D.MALL_LIMIT_TIME_GIFT||e==Dt.D.HONOUR_MALL)this.GotoMall(e,x)
else if(e==Dt.D.Pray)ut.u.Inst_get().viewType=ct.S.PRAY,It.w.Inst_Get().OpenPanel()
else if(e==Dt.D.WELF_PASS_REWARD)ut.u.Inst_get().viewType=ct.S.PASSREWARD,It.w.Inst_Get().OpenPanel()
else if(e==Dt.D.Angel_Fight_Token)ut.u.Inst_get().viewType=ct.S.ANGEL_FIGHT_TOKEN,It.w.Inst_Get().OpenPanel()
else if(e==Dt.D.USE_ROLANDBADGE)U.R.Inst_get().OpenUseBadgeView()
else if(e==Dt.D.MONTH_CARD)ut.u.Inst_get().viewType=ct.S.MONTH_CARD,It.w.Inst_Get().OpenPanel()
else if(e==Dt.D.DAILY_RECHARGE)ut.u.Inst_get().viewType=ct.S.DAILY_RECHARGE,It.w.Inst_Get().OpenPanel()
else if(e==Dt.D.DAILY_TOTAL_RECHARGE)ut.u.Inst_get().viewType=ct.S.DAILY_TOTAL_RECHARGE,It.w.Inst_Get().OpenPanel()
else if(e==Dt.D.Asuram)S.Q.Inst_get().defaultMainTabIndex=g.t.ASURAM,I.K.Inst().Open()
else if(e==Dt.D.AsuramActivity)S.Q.Inst_get().defaultMainTabIndex=g.t.ACTIVITY,I.K.Inst().Open()
else if(e==Dt.D.AsuramTask)yt.Y.Inst.PrimaryRoleInfo_get().AsuramId_get().Equal(H.I.zeroLong)||null==S.Q.Inst_get().AsuramData_get()?(S.Q.Inst_get().defaultMainTabIndex=g.t.ASURAM,
I.K.Inst().Open()):(S.Q.Inst_get().defaultMainTabIndex=g.t.ACTIVITY,S.Q.Inst_get().activeViewType=_.k.TASK,I.K.Inst().Open())
else if(e==Dt.D.STALL_MYSTALL);else if(e==Dt.D.AsuramBoss){yt.Y.Inst.PrimaryRoleInfo_get().isHaveAlliance_get()?(S.Q.inst.defaultMainTabIndex=g.t.ACTIVITY,
S.Q.inst.activeViewType=_.k.BOSS,I.K.Inst().Open(!1)):Qe.y.inst.ClientStrMsg(null,(0,ft.T)("尚未加入战盟"))}else if(e==Dt.D.ASURAM_FIRE){
yt.Y.Inst.PrimaryRoleInfo_get().isHaveAlliance_get()?(S.Q.inst.defaultMainTabIndex=g.t.ACTIVITY,S.Q.inst.activeViewType=_.k.FIRE,
I.K.Inst().Open(!1)):Qe.y.inst.ClientStrMsg(null,(0,ft.T)("尚未加入战盟"))}else if(e==Dt.D.AsuramBossCopy){
yt.Y.Inst.PrimaryRoleInfo_get().isHaveAlliance_get()?S.Q.Inst_get().bossModel.isBossOpen_get()?c.a.isInAllianceMap_get()?Qe.y.inst.ClientStrMsg($.r.SystemTipMessage,(0,
ft.T)("已在战盟领地内了")):(I.K.Inst().Close(),u.N.inst_get().EnterCopy()):Qe.y.inst.ClientStrMsg($.r.SystemTipMessage,(0,ft.T)("不在活动期间")):Qe.y.inst.ClientStrMsg(null,(0,ft.T)("尚未加入战盟"))
}else if(e==Dt.D.AsuramQuestionCopy){
yt.Y.Inst.PrimaryRoleInfo_get().isHaveAlliance_get()?O.L.GetInst().IsBornFireActivityOpen()?c.a.isInAllianceMap_get()?Qe.y.inst.ClientStrMsg($.r.SystemTipMessage,(0,
ft.T)("已在战盟领地内了")):(I.K.Inst().Close(),O.L.GetInst().EnterRyAllianceScene()):Qe.y.inst.ClientStrMsg($.r.SystemTipMessage,(0,ft.T)("不在活动期间")):Qe.y.inst.ClientStrMsg(null,(0,
ft.T)("尚未加入战盟"))}else if(e==Dt.D.AsuramMemberList){yt.Y.Inst.PrimaryRoleInfo_get().isHaveAlliance_get()?(S.Q.inst.defaultMainTabIndex=g.t.ASURAM,S.Q.inst.infoViewType=p.Z.MEMBER,
I.K.Inst().Open(!1)):Qe.y.inst.ClientStrMsg(null,(0,ft.T)("尚未加入战盟"))}else if(e==Dt.D.Friend)K.N.Inst_get().OpenFriendPanel()
else if(e==Dt.D.Horse){R.U.Inst_get().topViewType=L.Q.HORSE
const e=t
if(null!=e){let t=J.D.GetInst().GetCfgByActiveItem(e.cfgData_get().id)
null==t&&(t=J.D.GetInst().GetCfgByLevelItem(e.cfgData_get().id)),null==t?R.U.Inst_get().subTopViewType=null:(2==t.horseType?R.U.Inst_get().subTopViewType=L.Q.HORSE_UNREAL:R.U.Inst_get().subTopViewType=null,
te.C.Inst_get().defaultSelectHorseId=t.id)}w.l.Inst().Open(null,n)}else if(e==Dt.D.GEN)R.U.Inst_get().topViewType=L.Q.GEM,w.l.Inst().Open(null,n)
else if(e==Dt.D.Transfer){let e=null
null!=t&&(e="table"==typeof t?t:_t.o.FromString(t)),lt.Q.ins.OpenPanel(e)}else if(e==Dt.D.REBIRTH)be.c.ins.OpenPanel()
else if(e==Dt.D.Vip)null!=x&&2==x.count&&(ht.U.inst.model.defaultVipGiftIndex=pt.M.String2Int(x[1])),ht.U.inst.controller.OpenPanel()
else if(e==Dt.D.VipBoss){const e=t
let i=0
if(null!=e){const t=pt.M.Split(e,At.o.s_Arr_UNDER_LINE)
if(t.count>1){dt._.Inst().isPassCopy=!0
const e=pt.M.String2Int(t[1])
i=at.C.Inst().GetBossIdByCopy(e),dt._.Inst().bossId4PassCopy=i}}rt.$.Inst().OpenByType(ot.l.VIPBOSS,i)}else if(e==Dt.D.KarimaBoss)rt.$.Inst().OpenByType(ot.l.KARIMABOSS)
else if(e==Dt.D.AncientBoss)null!=x&&2==x.count?rt.$.Inst().OpenByType(ot.l.ANCIENTBOSS,pt.M.String2Int(x[1])):rt.$.Inst().OpenByType(ot.l.ANCIENTBOSS)
else if(e==Dt.D.Bag){let e=0
null!=t&&(e=pt.M.String2Int(t)),m.J.Inst_get().openOrClose(C.D.bagTab,e)}else if(e==Dt.D.WareHouse)m.J.Inst_get().openOrClose(C.D.warehouseTab)
else if(e==Dt.D.NowMap)null!=x&&x.Count()>1?it.X.inst.OpenCurrentMapByMansterSpawnId(x[1]):it.X.inst.OpenMapPanel(it.X.SCENE_MAP)
else if(e==Dt.D.BagTip){if(m.J.Inst_get().openOrClose(C.D.bagTab),null!=x&&x.Count()>=2){const e=new T.M(pt.M.String2Int(x[1]))
INS.itemTipManager.OpenTipView(e)}}else if(e==Dt.D.WordMap)null!=l&&null!=l.param&&(nt.F.getInst().OpenEffMapId=l.param.mapId),it.X.inst.OpenMapPanel(it.X.WORD_MAP)
else if(e==Dt.D.AddAttrPoint)R.U.Inst_get().topViewType=L.Q.Normal,R.U.Inst_get().characterViewType=E.f.AddAttrs,w.l.Inst().Open(null,n)
else if(e==Dt.D.FASHION)X.P.Inst_get().IsFunctionOpened(q.x.FASHION)?(R.U.Inst_get().topViewType=L.Q.Normal,R.U.Inst_get().characterViewType=E.f.SURFACE_FASHION,
w.l.Inst().Open(null,n)):G.l.SetFunctionTip(q.x.FASHION)
else if(e==Dt.D.Seting)ze._.Inst.OpenMainPanel(!0)
else if(e==Dt.D.PandoraBox)if(yt.Y.Inst.PrimaryRole_get().Terraintype_get()!=B.z.TerrainTypeSafe)Qe.y.inst.ClientSysMessage(11042301)
else if(t){const e=t,i=f.g.Inst_get().GetItemById(e.serverData_get().Id_get())
Ue.U.inst.OpenMainPanel(i)}else Ue.U.inst.OpenMainPanel()
else if(e==Dt.D.Recharge)De.t.inst.OpenPanel()
else if(e==Dt.D.FirstRecharge)W.v.Inst_get().OpenView()
else if(e==Dt.D.LevelAward)It.w.Inst_Get().IsShowLevelRewardTab()?(ut.u.Inst_get().viewType=ct.S.LEVEL,It.w.Inst_Get().OpenPanel()):Qe.y.inst.ClientSysMessage(120100)
else if(e==Dt.D.ChatChannelTotal||e==Dt.D.ChatChannelSystem||e==Dt.D.ChatChannelWorld||e==Dt.D.ChatChannelNearby||e==Dt.D.ChatChannelTeam||e==Dt.D.ChatChannelAlliance)D.d.Inst_get().controller.OpenByUIID(e)
else if(e==Dt.D.ALLIANCE_FACTORY)Rt.V.Inst_get().JumpToAlliancePanel(g.t.BUILDING,null,r.L.FactoryType)
else if(e==Dt.D.ALLIANCE_TECH)Rt.V.Inst_get().JumpToAlliancePanel(g.t.BUILDING,null,r.L.TechnologyType)
else if(e==Dt.D.ALLIANCE_TREASURE)Rt.V.Inst_get().JumpToAlliancePanel(g.t.BUILDING,null,r.L.TreasureType)
else if(e==Dt.D.ALLIANCE_DONATE)Rt.V.Inst_get().JumpToAlliancePanel(g.t.BUILDING,null,r.L.Donation)
else if(e==Dt.D.IwantMoney)F.P.Inst_get().Open(V.X.MONEY)
else if(e==Dt.D.IWantExp)F.P.Inst_get().Open(V.X.EXP)
else if(e==Dt.D.IWantEquip)F.P.Inst_get().Open(V.X.EQUIP)
else if(e==Dt.D.RoleChangeNameView)P.I.inst.type=1,A.F.Inst_get().PreCheckChange()&&A.F.Inst_get().OpenChangeNameView()
else if(e==Dt.D.AsuramChangeNameView)P.I.inst.type=2,A.F.Inst_get().PreCheckChange()&&A.F.Inst_get().OpenChangeNameView()
else if(e==Dt.D.SEVEN_DAY)Se.P.ins.OpenPanel()
else if(e==Dt.D.RolandSaveMgr)ve.w.ins.OpenPanel()
else if(e==Dt.D.GAME_GM){let e=null,t=null,i=null
x.Count()>1&&(null!=x[1]&&(e=pt.M.String2Int(x[1])),null!=x[2]&&(t=pt.M.String2Int(x[2])),null!=x[3]&&(i=pt.M.String2Int(x[3]))),Q.t.ins.OpenPanel(e,t,i)
}else if(e==Dt.D.AsuramShop)yt.Y.Inst.PrimaryRoleInfo_get().AsuramId_get().Equal(H.I.zeroLong)||null==S.Q.Inst_get().AsuramData_get()?Qe.y.inst.ClientSysMessage(10530029):this.GotoMall(e,x)
else if(e==Dt.D.OFFICIAL_ACCOUNT)Ge.H.Inst().OpenMainView()
else if(e==Dt.D.MAIL)D.d.Inst_get().controller.OpenMainPanel(!0)
else if(e==Dt.D.BAG_SELL)m.J.Inst_get().OpenBagSellPanel()
else if(e==Dt.D.STALL_MARKET)null!=t&&null!=t.count&&t.count>0?$e.v.Inst_get().OpenStallMarketView(t[0],t[1],s):$e.v.Inst_get().OpenStallMarketView()
else if(e==Dt.D.MANUAL_SPECIAL_GOUI)if(null!=x&&x.count>=3){if(x[1]=pt.M.String2Int(x[1]),!this.CheckFuncOpen(x[1]))return!1
Ae.X.DoOpenShortCut(x)}else Pt.Y.LogError("检查goUI配置,没配特殊参数")
else if(e==Dt.D.GUIDE_MAP_BY_TASK)if(null!=x&&x.count>=2){const e=pt.M.String2Int(x[1])
it.X.inst.OpenMapPanel(it.X.WORD_MAP,null,null,e,!1,!0)}else Pt.Y.LogError("检查goUI配置,没配特殊参数")
else if(e==Dt.D.BelialPanel||e==Dt.D.BLOOD_TOWN)this.GotoNpc(e)
else if(e==Dt.D.LOST_ABYSS)k.s.Inst_get().Open(v.F.DailyCopy,N.W.LostAbyss)
else if(e==Dt.D.LOST_ABYSS_HARD)X.P.Inst_get().IsFunctionOpened(q.x.LOST_ABYSS_HARD)&&Te.u.Inst_Get().IsStageUnlock(1,1,2)?(Te.u.Inst_Get().copyMode=2,
k.s.Inst_get().Open(v.F.DailyCopy,N.W.LostAbyss)):Qe.y.inst.ClientSysMessage(11030710)
else if(e==Dt.D.EXCALIBUR);else if(e==Dt.D.REBIRTH_TALENT)Ye.d.Inst_get().OpenView(We.l.REBIRTHTALENT_VIEW,null,n)
else if(e==Dt.D.skill_practiceSkill){const e=t
if((0,Ct.t2)(e,T.M)){const[t,i]=Ke.m.Inst().GetUsePraSkillMinLvPlayer(e.serverData_get().modelId)
null!=i&&Ye.d.Inst_get().OpenView(We.l.SKILL_VIEW,i,t.createIdx,!0)}else{let e=yt.Y.Inst.PrimaryRoleInfo_get()
null!=n&&(e=yt.Y.Inst.GetMultiPlayerInfoByCreateIdx(n)),Ye.d.Inst_get().OpenPraticeSkillView(null,e)}}else if(e==Dt.D.DAILY_PANEL){let e=-1
null!=x[1]&&(e=pt.M.String2Int(x[1])),k.s.Inst_get().Open(v.F.DailyTask,N.W.Daily,e)}else if(e==Dt.D.DAILY_PANEL_TIMETASK){let e=-1
null!=x&&null!=x[1]&&(e=pt.M.String2Int(x[1])),k.s.Inst_get().Open(v.F.DailyTask,N.W.TimeTask,e)}else if(e==Dt.D.MAYA_TREASURE)ue.X.Inst_get().OpenView()
else if(e==Dt.D.MEDAL)w.l.Inst().OpenByParam(!0,L.Q.MEDEL,0,n)
else if(e==Dt.D.TASKEQUIPCOLLECTGUIDE)et.i.ins.OpenEquipCollectGuidePanel(i,t)
else if(e==Dt.D.LUCK_LOTTERY)ut.u.Inst_get().viewType=ct.S.LOTTETY,It.w.Inst_Get().OpenPanel()
else if(e==Dt.D.FORTUNE)ae.p.Inst_get().OpenView(re.F.FATE_TREASURE_VIEW)
else if(e==Dt.D.FORTUNE_INTEGRAL)ae.p.Inst_get().OpenView(re.F.INTEGRAL_EXCHANGE_VIEW)
else if(e==Dt.D.FORTUNE_LIMITBUY)ae.p.Inst_get().OpenView(re.F.FORTUNE_LIMIT_VIEW)
else if(e==Dt.D.MAP_PASS_GUIDE)Pe.N.Inst().RaiseMapPassGuide()
else if(e==Dt.D.GET_CAR)o.m.Inst_get().OpenAlliancePullCarView()
else if(e==Dt.D.Fast_Fight)Ze.s.Inst_get().OpenView()
else if(e==Dt.D.ALLIANCE_ASSIST)h.d.Inst_get().OpenAssistBasePanel()
else if(e==Dt.D.TASK_CONTRACT_SELECT)tt.e.ins.OpenTaskContractSelectPanel()
else if(e==Dt.D.TASK_CONTRACT)tt.e.ins.OpenPanel()
else if(e==Dt.D.CHANGEJOB)y.Y.Inst_get().OpenPanel()
else if(e==Dt.D.MAPPASSREWARD)Pe.N.Inst().OpenMappassRewardView()
else if(e==Dt.D.TRADINGMARKET_BUY){let e=null
null!=x&&(e=x[1]),st.f.Inst_Get().OpenBuyView(e)}else if(e==Dt.D.TRADINGMARKET_SELL)st.f.Inst_Get().OpenSellView()
else if(e==Dt.D.Roland_TradingMarket){let e=null
null!=x&&(e=x[1]),st.f.Inst_Get().OpenBuyView(e,q.x.ROLAND_TRADINGMARKET)}else if(e==Dt.D.Divine_Code)w.l.Inst().OpenByParam(!0,L.Q.DIVINE,1)
else if(e==Dt.D.ASURAM_WAR)d.L.Inst_get().ClickTopIcon()
else if(e==Dt.D.ONLINE_HANHG)Oe.k.Inst_get().OpenOnlineHangView()
else if(e==Dt.D.VIP_EXP_ADD)ht.U.inst.controller.OpenPanel(!0)
else if(e==Dt.D.RIDINGBUY_PANEL){const e=pe.$.Inst().GetRidingBuyOpenId()
e?pe.$.Inst().OpenRidingBuyPanel(e):Qe.y.inst.ClientSysStrMsg("活动未开启！")}else if(e==Dt.D.ALLIANCE_CHUANGONG)O.L.GetInst().OpenChuanGongView()
else if(e==Dt.D.God_Suit_Road)ee.r.Inst_get().OpenPanel()
else if(e==Dt.D.EXORCISM_MAIN)k.s.Inst_get().Open(v.F.Exorcism)
else if(e==Dt.D.MULTIPLE_EXP_VIEW)Ee.j.inst.OpenMultipleHangPanel()
else if(e==Dt.D.OPEN_SERVER_GRAB_QUEST)ce.V.Inst_get().OpenPanel(Ie.Q.Quest)
else if(e==Dt.D.OPEN_SERVER_GRAB_SEVENDAY)ce.V.Inst_get().OpenPanel(Ie.Q.SevenDay)
else if(e==Dt.D.OPEN_SERVER_GRAB_MALL_1)ce.V.Inst_get().OpenPanel(Ie.Q.SevenDay,Ie.Q.Rank_1,Ie.Q.Three_3)
else if(e==Dt.D.OPEN_SERVER_GRAB_MALL_2)ce.V.Inst_get().OpenPanel(Ie.Q.SevenDay,Ie.Q.Rank_2,Ie.Q.Three_3)
else if(e==Dt.D.OPEN_SERVER_GRAB_MALL_3)ce.V.Inst_get().OpenPanel(Ie.Q.SevenDay,Ie.Q.Rank_3,Ie.Q.Three_3)
else if(e==Dt.D.OPEN_SERVER_GRAB_MALL_4)ce.V.Inst_get().OpenPanel(Ie.Q.SevenDay,Ie.Q.Rank_4,Ie.Q.Three_3)
else if(e==Dt.D.OPEN_SERVER_GRAB_MALL_5)ce.V.Inst_get().OpenPanel(Ie.Q.SevenDay,Ie.Q.Rank_5,Ie.Q.Three_3)
else if(e==Dt.D.OPEN_SERVER_GRAB_MALL_6)ce.V.Inst_get().OpenPanel(Ie.Q.SevenDay,Ie.Q.Rank_6,Ie.Q.Three_3)
else if(e==Dt.D.OPEN_SERVER_GRAB_MALL_7)ce.V.Inst_get().OpenPanel(Ie.Q.SevenDay,Ie.Q.Rank_7,Ie.Q.Three_3)
else if(e==Dt.D.THEME_CARNIVAL){let e=null,t=null
x.Count()>1&&(null!=x[1]&&(e=pt.M.String2Int(x[1])),null!=x[2]&&(t=pt.M.String2Int(x[2]))),Ce.p.ins.OpenPanel(e,t)
}else if(e==Dt.D.METAGEMS_VIEW)Ne.v.Inst().OpenForgePanel(Ve.o.METAGAMES_VIEW,n)
else if(e==Dt.D.METAGEMS_BOX_VIEW)X.P.Inst_get().IsFunctionOpened(q.x.FORGE)?X.P.Inst_get().IsFunctionOpened(q.x.EQUIP_METAGEMS)?X.P.Inst_get().IsFunctionOpened(q.x.EQUIP_METAGEMS_BOX)?(xe.v.Inst().isDefaultOpenBox=!0,
Ne.v.Inst().OpenForgePanel(Ve.o.METAGAMES_VIEW,n)):G.l.SetFunctionTip(q.x.EQUIP_METAGEMS_BOX):G.l.SetFunctionTip(q.x.EQUIP_METAGEMS):G.l.SetFunctionTip(q.x.FORGE)
else if(e==Dt.D.MAZE)qe.j.Inst_get().OpenRootView(Je.W.MAZE_SPACE)
else if(e==Dt.D.MAZE_MALL)Le.G.Inst_get().OpenTimeSpaceMarket()
else if(e==Dt.D.DragonTreasureMain)se.N.Inst_get().OpenView(le.L.DragonTreasureMain)
else if(e==Dt.D.DragonTreasureShop)se.N.Inst_get().OpenShopView()
else if(e==Dt.D.DragonTreasureView)se.N.Inst_get().OpenView(le.L.DragonTreasureMain),se.N.Inst_get().OpenTreasureShopView()
else if(e==Dt.D.HonorKings_Quest)de.H.Inst_get().OpenMainPanel(he.x.ATTACH_REREWARD)
else if(e==Dt.D.HonorKings_Rank)de.H.Inst_get().OpenMainPanel(he.x.RANK_REWARDD)
else if(e==Dt.D.StarSky)fe.E.Inst_get().OpenStarSkyView()
else if(e==Dt.D.StarSkyLimit)fe.E.Inst_get().OpenStarSkyView(1)
else if(e==Dt.D.CROSS_BOSS)U.R.Inst_get().OpenRootView(b.E.CROSS_BOSS)
else if(e==Dt.D.RolandAppear)ke.o.Inst_get().OpenRolandAppearPanel(0)
else if(e==Dt.D.RolandValley)ke.o.Inst_get().OpenRolandAppearPanel(1)
else if(e==Dt.D.ELement_BASE)Z.L.Inst().OpenEleMianView(Y.$.UI_ELEMENT_ITEM,Y.$.UI_ELEMENT_ITEM_SUB_CIRCEL)
else if(e==Dt.D.ELement_Enhance)Z.L.Inst().OpenEleMianView(Y.$.UI_ELEMENT_ITEM,Y.$.UI_ELEMENT_ITEM_SUB_ENCHACE)
else if(e==Dt.D.ELement_Compound)Z.L.Inst().OpenEleMianView(Y.$.UI_ELEMENT_ITEM,Y.$.UI_ELEMENT_ITEM_SUB_Compound)
else if(e==Dt.D.USE_RIDINGEXPBOOK)R.U.Inst_get().topViewType=L.Q.HORSE,R.U.Inst_get().subTopViewType=L.Q.HORSE_RIDING,w.l.Inst().Open(null,n)
else if(e==Dt.D.GLORYCALL_SHOP)oe.$.Inst_get().OpenTreasureShopView()
else if(e==Dt.D.GLORYCALL)oe.$.Inst_get().OpenView()
else if(e==Dt.D.JIGSAW){if(!ne.i.ins.IsActiveState(ie.t.PUBLICBETA_JIGSAW))return void Qe.y.inst.ClientSysStrMsg("不在活动时间内")
_e.R.Inst_get().OpenPublicBetaView(2)
}else e==Dt.D.Equip_StarAdvance?He.a.Inst_get().OpenRyEquipStarAdvanceView():e==Dt.D.GOLD_CATTLE?ge.Q.Inst_get().OpenSpringFestivalView(me.K.GOLDCATTLE):e==Dt.D.SPRING_CATTLE?ge.Q.Inst_get().OpenSpringFestivalView(me.K.SPRINGCATTLE):e==Dt.D.FIVE_BLESS_COME?ge.Q.Inst_get().OpenSpringFestivalView(me.K.FIVEBLESSCOME):e==Dt.D.FUCARD_EXCHANGE?(ge.Q.Inst_get().OpenSpringFestivalView(me.K.FIVEBLESSCOME),
ge.Q.Inst_get().OpenFiveBlessComeExchangeView()):e==Dt.D.SPRINGFESTIVAL_CELEBRATE?ge.Q.Inst_get().OpenSpringFestivalView(me.K.CELEBRATE):e==Dt.D.SPRINGFESTIVAL_SHOP?ge.Q.Inst_get().OpenSpringFestivalView(me.K.SHOP):a=!1
return a}GotoMall(e,t){let i=-1,n=-1,s=-1
null!=t&&(null!=t[1]&&(s=pt.M.String2Int(t[1])),null!=t[2]&&(i=pt.M.String2Int(t[2])),null!=t[3]&&(n=pt.M.String2Int(t[3]))),
-1==s&&(e==Dt.D.AsuramShop?s=9:e==Dt.D.GOLD_MALL?s=4:e==Dt.D.GOLD_DIAMOND_MALL?s=2:e==Dt.D.HONOUR_SHOP?s=5:e==Dt.D.HONOUR_MALL&&(s=11)),Re.O.Inst_get().Open(null,s,i,n)}GotoNpc(e){
const t=wt.I.Inst().GetUICfg(e).functionID
if(!X.P.Inst_get().IsFunctionOpened(t))return void G.l.SetFunctionTip(t)
m.J.Inst_get().closeBag()
const i=j.d.Inst_get().getItemById(t)
if(null!=i){const e=Be.f.Inst().getItemById(i.npcId)
null!=e&&e.GOToNpc()}}CheckVersionFunctionIsOpen(e){return!0}RegUIShowDic(e,t){null==t&&(t=-1),Lt&&!Lt.LuaDic_ContainsKey(e)&&(Lt.LuaDic_AddOrSetItem(e,t),
G.l.CheckTrigger(x.u.COND_OPEN_UI_VAL,e))}ChangeCharacterTab(e){for(const[t,i]of(0,mt.V5)(Lt))if(i==e){G.l.CheckTrigger(x.u.COND_OPEN_UI_VAL,t)
break}}UnRegUIShowDic(e){Lt&&Lt.LuaDic_ContainsKey(e)&&(Lt.LuaDic_Remove(e),G.l.CheckTrigger(x.u.COND_CLOSE_UI_VAL,e))}CheckUIOpenByUIShortCutType(e,t){
if(Lt.LuaDic_ContainsKey(e)){if(null!=t){const i=Lt.LuaDic_GetItem(e)
return Tt.i.Inst.GetCurSelect(i).createIdx==t}return!0}return!1}CheckGoUIByUIShortCutType(e){
return!!Lt.LuaDic_ContainsKey(e)&&(e==Dt.D.OPEN_SERVER_GRAB_MALL_1?ce.V.Inst_get().IsCanOpen(Ie.Q.SevenDay,Ie.Q.Rank_1,Ie.Q.Three_3):e==Dt.D.OPEN_SERVER_GRAB_MALL_2?ce.V.Inst_get().IsCanOpen(Ie.Q.SevenDay,Ie.Q.Rank_2,Ie.Q.Three_3):e==Dt.D.OPEN_SERVER_GRAB_MALL_3?ce.V.Inst_get().IsCanOpen(Ie.Q.SevenDay,Ie.Q.Rank_3,Ie.Q.Three_3):e==Dt.D.OPEN_SERVER_GRAB_MALL_4?ce.V.Inst_get().IsCanOpen(Ie.Q.SevenDay,Ie.Q.Rank_4,Ie.Q.Three_3):e==Dt.D.OPEN_SERVER_GRAB_MALL_5?ce.V.Inst_get().IsCanOpen(Ie.Q.SevenDay,Ie.Q.Rank_5,Ie.Q.Three_3):e==Dt.D.OPEN_SERVER_GRAB_MALL_6?ce.V.Inst_get().IsCanOpen(Ie.Q.SevenDay,Ie.Q.Rank_6,Ie.Q.Three_3):e!=Dt.D.OPEN_SERVER_GRAB_MALL_7||ce.V.Inst_get().IsCanOpen(Ie.Q.SevenDay,Ie.Q.Rank_7,Ie.Q.Three_3))
}CheckFuncOpen(e){if(null==wt.I.Inst().GetUICfg(e))return e>0&&Pt.Y.LogError((0,ft.T)("界面打开ID为")+(e+(0,ft.T)("，请检查配置或者逻辑"))),!1
if(!this.CheckVersionFunctionIsOpen(e))return!1
const t=wt.I.Inst().GetFunctionOpenId(e),i=j.d.Inst_get().getItemById(t)
if(null==i&&0!=t)return Pt.Y.LogError((0,ft.T)("UIIDRESOURCE表 ")+(e+((0,ft.T)(" 配的functionID ")+(t+(0,ft.T)(" 在FUNCTIONRESOURCE表里找不到"))))),!1
if(null!=i&&!X.P.Inst_get().CheckExtraPackageFunction(i.id,!0))return!1
yt.Y.Inst.PrimaryRoleInfo_get().Level_get()
let n=wt.I.Inst().IsFunctionOpen(e)
return n||X.P.Inst_get().IsFunctionClosed(t)||G.l.SetFunctionTip(t),n}},l._Inst=null,Et=s=l,Bt="Inst_get",Mt=[a.Vx],Gt=Object.getOwnPropertyDescriptor(s,"Inst_get"),Ot=s,Ut={},
Object.keys(Gt).forEach((function(e){Ut[e]=Gt[e]})),Ut.enumerable=!!Ut.enumerable,Ut.configurable=!!Ut.configurable,("value"in Ut||Ut.initializer)&&(Ut.writable=!0),
Ut=Mt.slice().reverse().reduce((function(e,t){return t(Et,Bt,e)||e}),Ut),Ot&&void 0!==Ut.initializer&&(Ut.value=Ut.initializer?Ut.initializer.call(Ot):void 0,
Ut.initializer=void 0),void 0===Ut.initializer&&(Object.defineProperty(Et,Bt,Ut),Ut=null),n=s))
var Et,Bt,Mt,Gt,Ot,Ut},85682:(e,t,i)=>{i.d(t,{D:()=>n})
var n={Title:2,ProSkill:3,Fruit:8,EquipEnhance:9,EquipAdd:10,EquipLucky:11,EquipAdvance:12,WingRefine:13,RyCompound:16,Recover:26,Boss:27,Pray:33,Asuram:37,AsuramTask:38,
AsuramBoss:39,AsuramMemberList:40,Friend:41,Transfer:48,Vip:52,VipBoss:60,KarimaBoss:61,Bag:62,WareHouse:63,NowMap:64,WordMap:65,AddAttrPoint:71,Seting:84,AncientBoss:88,
PandoraBox:97,Recharge:129,FirstRecharge:130,LevelAward:131,ChatChannelTotal:136,ChatChannelSystem:137,ChatChannelWorld:138,ChatChannelNearby:139,ChatChannelTeam:140,
ChatChannelAlliance:141,IwantMoney:179,IWantExp:180,IWantEquip:181,ReActivity:193,RoleChangeNameView:196,AsuramChangeNameView:197,OFFICIAL_ACCOUNT:246,MAIL:257,BAG_SELL:274,
GOLD_DIAMOND_MALL:284,MANUAL_SPECIAL_GOUI:285,BelialPanel:287,REBIRTH:289,Horse:290,STALL_MARKET:293,BLOOD_TOWN:294,LOST_ABYSS:296,EXCALIBUR:300,REBIRTH_TALENT:302,
STALL_MYSTALL:303,GOLD_MALL:305,HONOUR_SHOP:306,skill_practiceSkill:307,DAILY_PANEL:309,MEDAL:310,AsuramShop:311,forge_suit:312,DIVINE:313,SEVEN_DAY:314,ObtainPanel:315,
TASKEQUIPCOLLECTGUIDE:316,BagTip:317,TaskObtainPanel:318,Arena:319,GAME_GM:320,LOST_ABYSS_HARD:326,WELF_PASS_REWARD:331,FORTUNE:332,LUCK_LOTTERY:333,ALLIANCE_FACTORY:334,
ALLIANCE_TECH:335,MAP_PASS_TIP:336,MALL_LIMIT_TIME_GIFT:337,GET_CAR:338,Fast_Fight:339,ALLIANCE_ASSIST:340,MAYA_TREASURE:341,MAP_PASS_GUIDE:343,DAILY_PANEL_TIMETASK:344,GEN:345,
FASHION:346,TASK_CONTRACT_SELECT:347,TASK_CONTRACT:348,CHANGEJOB:349,MAPPASSREWARD:350,TRADINGMARKET_BUY:351,TRADINGMARKET_SELL:352,HONOUR_MALL:353,ASURAM_WAR:354,MONTH_CARD:355,
ALLIANCE_DONATE:356,ALLIANCE_TREASURE:357,VIP_EXP_ADD:358,ONLINE_HANHG:359,RIDINGBUY_PANEL:360,DAILY_RECHARGE:361,RIDIN_MAT_COMPOSE:106,AsuramBossCopy:362,GUIDE_MAP_BY_TASK:363,
ALLIANCE_CHUANGONG:365,God_Suit_Road:366,EXORCISM_MAIN:367,MULTIPLE_EXP_VIEW:368,DAILY_TOTAL_RECHARGE:369,AsuramActivity:370,OPEN_SERVER_GRAB_QUEST:371,
OPEN_SERVER_GRAB_SEVENDAY:372,METAGEMS_VIEW:373,METAGEMS_BOX_VIEW:374,MAZE:375,MAZE_MALL:383,ASURAM_FIRE:384,OPEN_SERVER_GRAB_MALL_1:376,OPEN_SERVER_GRAB_MALL_2:377,
OPEN_SERVER_GRAB_MALL_3:378,OPEN_SERVER_GRAB_MALL_4:379,OPEN_SERVER_GRAB_MALL_5:380,OPEN_SERVER_GRAB_MALL_6:381,OPEN_SERVER_GRAB_MALL_7:382,ELEMENT_ITEM:384,THEME_CARNIVAL:385,
DragonTreasureMain:387,DragonTreasureShop:388,HonorKings_Quest:389,HonorKings_Rank:390,FORTUNE_INTEGRAL:392,FORTUNE_LIMITBUY:393,CROSS_BOSS:394,StarSky:391,StarSkyLimit:395,
AsuramQuestionCopy:396,RolandAppear:397,RolandValley:398,ELement_Enhance:399,ELement_Compound:400,Angel_Fight_Token:401,Roland_TradingMarket:402,Divine_Code:403,
USE_ROLANDBADGE:404,USE_RIDINGEXPBOOK:405,ELement_BASE:406,GLORYCALL_SHOP:407,JIGSAW:408,Equip_Refine:409,Equip_StarAdvance:410,GOLD_CATTLE:411,SPRING_CATTLE:412,
FIVE_BLESS_COME:413,FUCARD_EXCHANGE:414,SPRINGFESTIVAL_CELEBRATE:415,SPRINGFESTIVAL_SHOP:416,DragonTreasureView:417,GLORYCALL:420,TaskMainUI:1e3,FUN_BTN_PANEL:1010,
UI_TaskMainUI_ITEM:100000010,UI_FUN_BTN_PANEL_BTN:101000010,UI_MAIN_ROLE_ICON:1e6,UI_MAIN_ROLE_BTN:1000001,UI_ROLE_ATTR_TAB:1000002,UI_ROLE_MEDAL_TAB:1000003,
UI_ROLE_HORSE_TAB:1000004,UI_ROLE_DIVINE_TAB:1000005,UI_ROLE_ATTR_BASE_TAB:1000006,UI_ROLE_ATTR_ADD_TAB:1000007,UI_ROLE_ATTR_TITLE_TAB:1000008,UI_ROLE_ATTR_SURFACE_TAB:1000009,
UI_ASURAMWAR_GUIDEAREA:2500001,UI_ASURAMWAR_MAPGUIDE:2500002,UI_ASURAMWAR_MAPGUIDE_2:2500003,UI_ASURAMWAR_RULE:2500004,UI_CHARACTER_TAB0:1000010,UI_CHARACTER_TAB1:1000011,
UI_CHARACTER_TAB2:1000012,UI_ROLE_LEARDER_BTN:1000013,UI_ROLE_ATTR_ADD_RESET_BTN:1000014,UI_ROLE_ATTR_ADD_REM_BTN:1000015,UI_ROLE_ATTR_ADD_BTN:1000016,
UI_ROLE_ATTR_ADD_STR_BTN:1000017,UI_ROLE_ATTR_SUB_STR_BTN:1000018,UI_ROLE_ATTR_ADD_AG_BTN:1000019,UI_ROLE_ATTR_SUB_AG_BTN:1000020,UI_ROLE_ATTR_ADD_VI_BTN:1000021,
UI_ROLE_ATTR_SUB_VI_BTN:1000022,UI_ROLE_ATTR_ADD_IN_BTN:1000023,UI_ROLE_ATTR_SUB_IN_BTN:1000024,UI_ROLE_ATTR_ADD_FRUIT_BTN:1000025,UI_FRUIT_USE_BTN:1000026,
UI_ROLE_ATTR_TITLE_SHOW_BTN:1000027,UI_ROLE_ATTR_TITLE_USE_BTN:1000028,UI_ROLE_ATTR_TITLE_LOOK_BTN:1000029,UI_ROLE_ATTR_TITLE_SELECT:1000030,UI_ROLE_ATTR_SURFACE_SAVE_BTN:1000031,
UI_ROLE_ATTR_SURFACE_SELECT_ITEM:1000032,UI_ROLE_ATTR_SURFACE_MENU_BTN:1000033,UI_ROLE_MEDAL_BTN:1000034,UI_ROLE_MEDAL_SKILL_ITEM:1000035,UI_ROLE_MEDAL_COST_ITEM:1000036,
UI_ROLE_HORSE_ITEM:1000037,UI_ROLE_HORSE_BTN:1000038,UI_ROLE_HORSE_AUTO_BTN:1000039,UI_ROLE_HORSE_SKILL:1000040,UI_ROLE_HORSE_RIDE:1000041,UI_ROLE_HORSE_REPLACE:1000042,
UI_ROLE_DIVINE_UP_BTN:1000043,UI_ROLE_DIVINE_ITEM:1000044,UI_ROLE_DIVINE_LOCATION:1000045,UI_ROLE_DIVINE_SKILL:1000046,UI_FORCE_STRENG_TAB:1100002,UI_FORCE_ADD_TAB:1100003,
UI_FORCE_LUCKY_TAB:1100004,UI_FORCE_SUIT_TAB:1100005,UI_FORCE_STRENG_4__TAB:1100006,UI_FORCE_STRENG_5__TAB:1100007,UI_FORCE_STRENG_BTN:1100008,UI_FORCE_EQUIP_ITEM:1100009,
UI_FORCE_COST_ITEM:1100010,UI_FORCE_GET_WAY_BTN:1100011,UI_FORCE_ADD_BTN:1100012,UI_FORCE_ADD_4_TAB:1100013,UI_FORCE_ADD_5_TAB:1100014,UI_FORCE_LUCKY_4_TAB:1100016,
UI_FORCE_LUCKY_5_TAB:1100017,UI_FORCE_SUIT_BTN:1100018,UI_FORCE_SUIT_SHOW_BTN:1100019,UI_FORCE_SUIT_COST:1100020,UI_BAG_TAB:1200002,UI_BAG_COMPOSE_TAB:1200003,
UI_FORCE_SUIT_4_TAB:1200004,UI_FORCE_SUIT_5_TAB:1200005,UI_BAG_SELL_BTN:1200006,UI_BAG_ALL_BTN:1200007,UI_BAG_EQUIP_BTN:1200008,UI_BAG_ITEM_BTN:1200009,UI_BAG_WING_TAB:1200010,
UI_BAG_HORSE_TAB:1200011,UI_BAG_JW_TAB:1200012,UI_BAG_GUARD_TAB:1200013,UI_BAG_ORHER_TAB:1200014,UI_BAG_EX_UP_TAB:1200015,UI_BAG_ANGEL_UP_TAB:1200016,
UI_BAG_ANGEL_EQUIP_TAB:1200050,UI_BAG_GEM_TAB:1200051,UI_BAG_COMPOSE_WING_BTN:1200017,UI_BAG_COMPOSE_PRE_BTN:1200018,UI_BAG_COMPOSE_PRE_CLOSE_BTN:1200019,
UI_BAG_COMPOSE_PRE_WING_ITEM:1200020,UI_BAG_COMPOSE_HORSE_BTN:1200021,UI_BAG_COMPOSE_HORSE_MAX_BTN:1200022,UI_BAG_COMPOSE_ONE_CLAUSE_BTN:1200023,
UI_BAG_COMPOSE_HORSE_HIGH_BTN:1200024,UI_BAG_COMPOSE_JW_BTN:1200025,UI_BAG_COMPOSE_JW_MAX_BTN:1200026,UI_BAG_COMPOSE_GUARD_BTN:1200031,UI_BAG_COMPOSE_GUARD_PRE_BTN:1200032,
UI_BAG_COMPOSE_OTHER_BTN:1200039,UI_BAG_COMPOSE_OTHER_PRE_BTN:1200040,UI_BAG_COMPOSE_EX_UP_BTN:1200044,UI_BAG_COMPOSE_EX_UP_PRE_BTN:1200045,UI_BAG_COMPOSE_EX_UP_TIPS_BTN:1200046,
UI_BAG_COMPOSE_ANGEL_UP_BTN:1200047,UI_BAG_COMPOSE_ANGEL_UP_PRE_BTN:1200048,UI_BAG_COMPOSE_ANGEL_UP_TIP_BTN:1200049,UI_SKILL_TAB:1300002,UI_SKILL_TALENT_TAB:1300003,
UI_SKILL_LEARN_TAB:1300004,UI_SKILL_FIT_TAB:1300005,UI_SKILL_LEARN_BTN:1300006,UI_SKILL_COST_ITEM_BTN:1300007,UI_SKILL_ICON:1300008,UI_SKILL_TALENT_ICON:1300009,
UI_SKILL_TALENT_LEARN_BTN:1300010,UI_BOSS_WORLD_TAB:1400002,UI_BOSS_GLOD_TAB:1400003,UI_BOSS_KLM_TAB:1400004,UI_BOSS_VIPBOSS_TAB:1400005,UI_BOSS_CHANGEL_BTN:1400006,
UI_BOSS_FOLLOWL_BTN:1400007,UI_BOSS_ADD_V_BTN:1400008,UI_BOSS_ITEM_ICON:1400009,UI_COMMONINSPRIRE_BTN:1400010,UI_BOSS_GLOD_L_BTN:1400011,UI_BOSS_GLOD_R_BTN:1400012,
UI_BOSS_GLOD_CHANEAL_BTN:1400013,UI_BOSS_GLOD_FOLLOW_BTN:1400014,UI_BOSS_GLOD_ADD_BTN:1400015,UI_BOSS_KLM_CHANEAL_BTN:1400016,UI_BOSS_KLM_FOLLOW_BTN:1400017,
UI_BOSS_KLM_ADD_BTN:1400018,UI_BOSS_KLM_COST_ITEM:1400019,UI_BOSS_KLM_BOSS_ICON:1400020,UI_BOSS_VIP_CHANEAL_BTN:1400021,UI_BOSS_VIP_ADD_BTN:1400022,UI_MARKET_TAB:1500002,
UI_MARKET_STALL_TAB:1500003,UI_MARKET_MYLOG_BTN:1500004,UI_MARKET_HPLOG_BTN:1500005,UI_MARKET_S_INPUT:1500006,UI_MARKET_S_BTN:1500007,UI_MARKET_ITEM:1500008,
UI_MARKET_GO_BTN:1500009,UI_MARKET_STALL_OPEN_BTN:1500010,UI_MARKET_STALL_REENT_BTN:1500011,UI_MARKET_STALL_RENAME_BTN:1500012,UI_MARKET_STALL_MERGE_BTN:1500013,
UI_MARKET_STALL_SELL_LOG_BTN:1500014,UI_MARKET_STALL_MENU_ALL_BTN:1500015,UI_MARKET_STALL_MENU_EQUIP_BTN:1500016,UI_MARKET_STALL_MENU_SKILL_BTN:1500017,
UI_MARKET_STALL_MENU_WING_BTN:1500018,UI_MARKET_WANTBUY_BTN:1500019,UI_MARKET_WANTSEll_BTN:1500020,UI_DAILY_TAB:1600002,UI_DAILY_COPY_TAB:1600003,UI_DAILY_BASE_TAB:1600004,
UI_DAILY_LIMIT_TAB:1600005,UI_DAILY_GOTO_BTN:1600006,UI_DAILY_CHANGE_BTN:1600007,UI_DAILY_REWARD_FIX_BTN:1600008,UI_DAILY_WEEK_BTN:1600009,UI_DAILY_STRENG_BTN:1600010,
UI_DAILY_REWARD_BTN:1600011,UI_DAILY_GO_STR_BTN:1600012,UI_STRENG_EQ_BTN:1600013,UI_STRENG_EXP_BTN:1600014,UI_STRENG_GOLD_BTN:1600015,UI_DAILY_LOSTABYSS_TAB:1600016,
UI_DAILY_LOSTABYSS_CHANEL_BTN:1600017,UI_DAILY_LOSTABYSS_NORMAL_BTN:1600018,UI_DAILY_LOSTABYSS_HARD_BTN:1600019,UI_DAILY_LOSTABYSS_REWARD_BTN:1600020,UI_MUTILEXP_ADD_BTN:1700002,
UI_MUTILEXP_PAUSE_BTN:1700003,UI_MUTILEXP_COST_ITEM:1700004,UI_MUTILEXP_COST_BTN:1700005,UI_MUTILEXP_PREY_BTN:1700006,UI_ALLIANCE_INFO_TAB:1800002,UI_ALLIANCE_BUILD_TAB:1800003,
UI_ALLIANCE_ACT_TAB:1800004,UI_ALLIANCE_TOTAL_TAB:1800005,UI_ALLIANCE_MENBER_TAB:1800006,UI_ALLIANCE_LIST_TAB:1800007,UI_ALLIANCE_EVENT_BTN:1800008,UI_ALLIANCE_GOTO_BTN:1800009,
UI_ALLIANCE_RENAME_BTN:1800010,UI_ALLIANCE_NOTICE_BTN:1800011,UI_ALLIANCE_RECRUIT_BTN:1800012,UI_ALLIANCE_APPLY_BTN:1800013,UI_ALLIANCE_QUIT_BTN:1800014,
UI_ALLIANCE_HALL_ICON:1800015,UI_ALLIANCE_SHOP_ICON:1800016,UI_ALLIANCE_TREASURE_ICON:1800017,UI_ALLIANCE_SCIENCE_ICON:1800018,UI_ALLIA_ACT_TASK_GO_BTN:1800023,
UI_ALLIA_ACT_TASK_SUMIT_BTN:1800024,UI_ALLIA_ACT_TASK_HELP_BTN:1800025,UI_ALLIA_ACT_TASK_REWARD_BTN:1800026,UI_ALLIA_ACT_BOSS_ENTER_BTN:1800027,UI_ALLIANCE_TREASURE_REWARD:1800030,
UI_ALLIANCE_TREASURE_ITEM_REWARD:1800031,UI_MALL_GOLD_TAB:1900002,UI_MALL_RECHARGE_TAB:1900003,UI_MALL_LIMIT_TAB:1900004,UI_MALL_GROW_TAB:1900005,UI_MALL_RARE_TAB:1900006,
UI_MALL_BUY_BTN:1900007,UI_MALL_RECHARGE_ITEM:1900008,UI_MALL_RECHARGE_BTN:1900009,UI_MALL_SHOP_GLOD_TAB:2000002,UI_MALL_SHOP_HONOR_TAB:2000003,UI_MALL_SHOP_ALLIANCE_TAB:2000004,
UI_MALL_SHOP_SEVER_TAB:2000005,UI_MALL_SHOP_GROW_TAB:2000006,UI_MALL_SHOP_DAY_ITEM:2000007,UI_MALL_SHOP_S_BUY_BTN:2000008,UI_MALL_SHOP_D_BUY_BTN:2000009,
UI_MALL_SHOP_HON_EX_TAB:2000010,UI_MALL_SHOP_HON_DALIY_TAB:2000011,UI_MALL_SHOP_HON_E_BUY_BTN:2000012,UI_MALL_SHOP_HON_D_BUY_BTN:2000013,UI_MALL_SHOP_AL_DALIY_TAB:2000014,
UI_MALL_SHOP_AL_BUY_BTN:2000015,UI_WELF_LEVEL_TAB:2100002,UI_WELF_PREY_TAB:2100003,UI_WELF_DV_TAB:2100004,UI_WELF_LEVEL_REWARD_BTN:2100005,UI_WELF_LEVEL_VIP_BTN:2100006,
UI_WELF_PREY_L_BTN:2100007,UI_WELF_PREY_R_BTN:2100008,UI_WELF_DV_REWARD_BTN:2100009,UI_WELF_PASS_REWARD:2100010,UI_WELF_RECOVER:2100011,UI_WELF_CDK:2100012,
UI_MAIN_SMALL_MAP:2200001,UI_MAP_CURENT_BTN:2200002,UI_MAP_BOSS_BTN:2200003,UI_MAP_GOLD_BTN:2200004,UI_MAP_TRANFER_BTN:2200005,UI_MAP_GLOD_ITEM:2200006,UI_MAP_SCENE_BTN:2200007,
UI_MAP_ITEM_BTN:2200008,UI_MAIN_SMALL_MAP_REWARD_BTN:2200009,UI_MAIN_COLLECT_BTN:2300002,UI_MAIN_PK_BTN:2300003,UI_MAIN_SKILL_VIEW:2300004,UI_MAIN_MEDI_VIEW:2300005,
UI_MAIN_BAG_EX:2300006,UI_MAIN_BUFF_BTN:2300007,UI_MAIN_USE_NOTICE:2300009,UI_MAIN_MAIL_VIEW:2300011,UI_MAIN_MAP_SPREAD_BTN:2300012,UI_MAIN_HELP_BTN:2400001,UI_HELP_TAB:2400002,
UI_HELP_TRANSFER_TAB:2400003,UI_HELP_GO_BTN:2400004,UI_MAP_PASS_BTN:2400005,UI_FORGE_EQUIP_ADVANCE_GUIDE_KUANG1:2400006,UI_FORGE_EQUIP_ADVANCE_GUIDE_KUANG2:2400007,
UI_FORGE_EQUIP_ADVANCE_GUIDE_KUANG3:2400008,UI_FORGE_EQUIP_ADVANCE_BTN:2400009,UI_MAP_ITEM_SUB_BTN:2400010,UI_MAP_ITEM_ROLAND_BTN:2400020,UI_CHANGEJOBCARD_CHARACTERAREA:2600001,
UI_CHANGEJOBCARD_JOBAREA:2600002,UI_QUEUE_TIP_ITEM_BTN:3000001,MAZE_COPY_INFO_ICON:3100010,MAZE_COPY_INFO_BG:3100011,MAZE_COPY_INFO_RESET_BTN:3100012,
MAZE_COPY_TIME_SPACE_ROOM_ITEM:3100020,MAZE_COPY_TIME_SPACE_ROOM_BOSS_ITEM:3100021,MAZE_COPY_TIME_SPACE_ROOM_CLOSE_BTN:3100030,MAZE_COPY_TIME_SPACE_ROOM_COLLECT:3100100,
MAZE_C_T_S_ROOM_COL_BTN:3100102,MAZE_COPY_TIME_SPACE_ROUTE:3100101}},49484:(e,t,i)=>{i.d(t,{p:()=>E})
var n=i(83900),s=i(33065),l=i(36241),a=i(84229),r=i(26753),o=i(73865),d=i(28462),h=i(93061),u=i(80392),c=i(96964),I=i(60447),_=i(5031),p=i(88010),S=i(48750),g=i(57651),m=i(41825),f=i(47041),C=i(62783),T=i(21334),y=i(98130),A=i(98885),P=i(38836),w=i(86133),R=i(13687),D=i(5924),L=i(66788)
class E{constructor(){this._taskResult=null,this._tasktempResult=null,this._activeResult=null,this._apktipsResult=null,this._killtipsResult=null,this._mapResult=null,
this._chatResult=null,this._icontipResult=null,this._operationResult=null,this._headResult=null,this._skillResult=null,this._preNoticeResult=null,this._otherActiveResult=null,
this._hangEfficientResult=null,this._hideBranchResult=null,this._banTeamResult=null,this._banBeatBackResult=null,this.m_frontMap=0,this.m_timerId=0,this.m_intervalId=0,
this._degf_DelayHideOrShow=null,this._rightUpBtnList=null,this._degf_DelayHideOrShow=(e,t)=>this.DelayHideOrShow(e,t)}static Inst_get(){return null==E._inst&&(E._inst=new E),
E._inst}banTeamResult_get(){return null==this._banTeamResult&&(this._banTeamResult=T.p.Inst_get().GetBanTeamResult()),this._banTeamResult}banBeatBackResult_get(){
return null==this._banBeatBackResult&&(this._banBeatBackResult=T.p.Inst_get().GetBanBeatBackResult()),this._banBeatBackResult}EnterMap(e){
D.C.Inst_get().ClearInterval(this.m_intervalId),this.m_intervalId=D.C.Inst_get().SetFrameLoopForParm(this._degf_DelayHideOrShow,1,1,e)}DelayHideOrShow(e,t){
const i=y.GF.INT(t),n=T.p.Inst_get().GetMapById(i)
null!=n?(c.o.getInstance().InKarima()?(p.F.Inst_get().SwitchToNormal(),1==S.N.Inst_get().isPlayBackMode||I.b.Inst_get().isLive?(p.F.Inst_get().ClosePkUI(),
_.T.inst_get().control.ForceCloseSkillForMapJudge(),u.H.Inst.SetBattleJoystickState(!1),
r.d.Inst_get().controller.ForceCloseForMapJudge(!0)):"SNOWBALL"==n.controllerType&&(g.i.ins.CloseMainUI(),g.i.ins.CloseTaskTempView())):(this.HideOrShow(this.GetUseMapId(i)),
p.F.Inst_get().ClosePkUI()),this.m_frontMap=i):L.Y.LogError((0,w.T)("mapRes或者mapId为nil "))}GetUseMapId(e){const t=T.p.Inst_get().GetMapById(e)
return null==t||"ASURAM_SCENE"!=t.controllerType||a.Q.Inst_get().IsInCopy()?e:R.b.Inst.lastMapId>0?R.b.Inst.lastMapId:10001}OnlyCheckTaskPanel(){
const e=this.GetUseMapId(this.m_frontMap),t=A.M.IntToString(e)
T.p.Inst_get().GetMapById(this.m_frontMap)
return!this.IndexOfStr(this.taskResult_get(),t)}ShowOrHideNewServerAdvantageTip(){}ShowOrHideNewServerAdvantage(e){}HideOrShow(e){
const t=A.M.IntToString(e),i=T.p.Inst_get().GetMapById(e)
i.hideElementsList.Contains(E.TIPFATHER)?f.N.Inst_get().HideOrShowTip(!1):f.N.Inst_get().HideOrShowTip(!0),
i.hideElementsList.Contains(E.TASK_MAINUI_PANEL)?g.i.ins.HideTaskMainUIPanel(!0):g.i.ins.HideTaskMainUIPanel(!1),
i.hideElementsList.Contains(E.TASKCONTRACT_MAINUI)?m.e.ins.CloseTaskContractUI():g.i.ins.ChangeShowMainUITask(),
i.hideElementsList.Contains(E.MAP_PASS_BTN)?n.N.Inst().CloseMapPassMainBtn():n.N.Inst().OpenMapPassMainBtn(),
this.IndexOfStr(this.taskResult_get(),t)?g.i.ins.CloseMainUI():g.i.ins.OpenMainUI(),
this.IndexOfStr(this.taskTempResult_get(),t)?g.i.ins.CloseTaskTempView():g.i.ins.OpenTaskTempView(),
this.IsShowRightUpBtnList(t)?o.y.Inst.ForceCloseFuncBtn():o.y.Inst.ForceOpenFuncBtn(),
this.IndexOfStr(this.mapResult_get(),t)?C.X.inst.ForceCloseForMapJudge():C.X.inst.ForceOpenForMapJudge(),
this.IndexOfStr(this.chatResult_get(),t)?r.d.Inst_get().controller.ForceCloseForMapJudge(!0):r.d.Inst_get().controller.ForceOpenForMapJudge(),
this.IndexOfStr(this.icontipResult_get(),t)?h.Z.Inst_get().ForceCloseIconTipsForMapJudge():h.Z.Inst_get().ForceOpenIconTipsForMapJudge(),
this.IndexOfStr(this.operationResult_get(),t)?_.T.inst_get().control.ForceCloseOperationPanel():s.x.Inst_get().CheckAssistDamageOpen()||_.T.inst_get().control.ForceOpenOperationPanel(),
this.IndexOfStr(this.activeResult_get(),t)?_.T.inst_get().control.ForceCloseFuncSetView():_.T.inst_get().control.ForceOpenFuncSetView(),
this.IndexOfStr(this.funcPrenoticeResult_get(),t)?d.J.inst.ForceCloseForMapJudge():d.J.inst.ForceOpenForMapJudge(),
this.IndexOfStr(this.headResult_get(),t)?_.T.inst_get().control.ForceCloseHeadForMapJudge():_.T.inst_get().control.ForceOpenHeadForMapJudge(),
this.IndexOfStr(this.skillResult_get(),t)?_.T.inst_get().control.ForceCloseSkillForMapJudge():_.T.inst_get().control.ForceOpenSkillForMapJudge(),
l._.getInst().openOrCloseStartIcon(),this.IndexOfStr(this.hangEfficientResult_get(),t)?l._.getInst().ForceCloseStartIcon():l._.getInst().ForceOpenStartIcon(),
_.T.inst_get().DoSpreadBtns(!1),this.CheckOtherShow()}CheckOtherShow(e){}IsOtherShowPanel(e){return this.IndexOfStr(this.otherActiveResult_get(),e)}IsShowRightUpBtnList(e){
return null==this._rightUpBtnList&&(this._rightUpBtnList=T.p.Inst_get().GetMapIdsByUIType(E.FUC_RIGHT_UP_BTN_LIST)),this.IndexOfStr(this._rightUpBtnList,e)}headAllUI(){
g.i.ins.CloseMainUI(),g.i.ins.CloseTaskTempView(),o.y.Inst.ForceCloseFuncBtn(),C.X.inst.ForceCloseForMapJudge(),h.Z.Inst_get().ForceCloseIconTipsForMapJudge(),
_.T.inst_get().control.ForceCloseOperationPanel(),_.T.inst_get().control.ForceCloseUpFuncForMapJudge(),_.T.inst_get().control.ForceCloseDownFuncForMapJudge(),
_.T.inst_get().control.ForceCloseHeadForMapJudge(),_.T.inst_get().control.ForceCloseSkillForMapJudge(),_.T.inst_get().control.ForceCloseExpForMapJudge(),
_.T.inst_get().control.ForceCloseFuncSetView(),_.T.inst_get().control.ForceClosePkFuncView(),_.T.inst_get().control.ForceHideExtraPackageBtn()}IsOperationCouldShow(){
const e=`${R.b.Inst.currentMapId_get()}`
return!this.IndexOfStr(this.operationResult_get(),e)}IsTaskPanelCouldShow(){const e=`${R.b.Inst.currentMapId_get()}`
return!this.IndexOfStr(this.taskResult_get(),e)}IsFunOpenPanelShow(){const e=`${R.b.Inst.currentMapId_get()}`
return!this.IndexOfStr(this.activeResult_get(),e)}IndexOfStr(e,t){for(const[i,n]of(0,P.V5)(e))if(n==t)return!0
return!1}hangEfficientResult_get(){return null==this._hangEfficientResult&&(this._hangEfficientResult=T.p.Inst_get().GetMapIdsByUIType(E.HANG_EFFICIENT)),this._hangEfficientResult}
taskResult_get(){return null==this._taskResult&&(this._taskResult=T.p.Inst_get().GetMapIdsByUIType(E.TASK_PANEL)),this._taskResult}taskTempResult_get(){
return null==this._tasktempResult&&(this._tasktempResult=T.p.Inst_get().GetMapIdsByUIType(E.Task_Temp_View)),this._tasktempResult}activeResult_get(){
return null==this._activeResult&&(this._activeResult=T.p.Inst_get().GetMapIdsByUIType(E.FuncSet_View)),this._activeResult}pkTipsResult_get(){
return null==this._apktipsResult&&(this._apktipsResult=T.p.Inst_get().GetMapIdsByUIType(E.PKTIPS)),this._apktipsResult}killTipsResult_get(){
return null==this._killtipsResult&&(this._killtipsResult=T.p.Inst_get().GetMapIdsByUIType(E.KILLTIPS)),this._killtipsResult}otherActiveResult_get(){
return null==this._otherActiveResult&&(this._otherActiveResult=T.p.Inst_get().GetMapIdsByUIType(E.SHOW_ACTIVITY_ICON)),this._otherActiveResult}mapResult_get(){
return null==this._mapResult&&(this._mapResult=T.p.Inst_get().GetMapIdsByUIType(E.MAP)),this._mapResult}chatResult_get(){
return null==this._chatResult&&(this._chatResult=T.p.Inst_get().GetMapIdsByUIType(E.CHAT)),this._chatResult}icontipResult_get(){
return null==this._icontipResult&&(this._icontipResult=T.p.Inst_get().GetMapIdsByUIType(E.ICON_TIP)),this._icontipResult}operationResult_get(){
return null==this._operationResult&&(this._operationResult=T.p.Inst_get().GetMapIdsByUIType(E.OPERATION_View)),this._operationResult}headResult_get(){
return null==this._headResult&&(this._headResult=T.p.Inst_get().GetMapIdsByUIType(E.HEAD)),this._headResult}skillResult_get(){
return null==this._skillResult&&(this._skillResult=T.p.Inst_get().GetMapIdsByUIType(E.SKILL)),this._skillResult}funcPrenoticeResult_get(){
return null==this._preNoticeResult&&(this._preNoticeResult=T.p.Inst_get().GetMapIdsByUIType(E.FUNC_PRENOTICE)),this._preNoticeResult}}E._inst=null,E.TASK_PANEL=5,E.CHAT=6,E.HEAD=7,
E.SKILL=8,E.MAP=9,E.OPERATION_View=10,E.FuncSet_View=11,E.FUNC_PRENOTICE=12,E.ICON_TIP=13,E.HANG_EFFICIENT=14,E.SHOW_ACTIVITY_ICON=17,E.TIPFATHER=21,E.PKTIPS=22,E.KILLTIPS=23,
E.FUC_RIGHT_UP_BTN_LIST=25,E.TRANS_JOB_ICON=26,E.REBIRTH_ICON=27,E.TASK_MAINUI_PANEL=28,E.MAP_PASS_BTN=29,E.Setting_ICON=30,E.TASKCONTRACT_MAINUI=31,E.Task_Temp_View=32,
E.FUC_Left_BTN_LIST=33,E.GAME_GM_STATE=34,E.BOSSTIPFATHER=35},72637:(e,t,i)=>{i.d(t,{I:()=>o})
var n=i(37648),s=i(55360),l=i(93984),a=i(38836),r=i(66788)
class o{constructor(){this.map=null
const e=s.Y.Inst.GetOrCreateCsv(l.h.eUIIdResource)
this.map=e.GetCsvMap()}static Inst(){return null==o._inst&&(o._inst=new o),o._inst}IsFunctionOpen(e){let t=null
return t=this.map.LuaDic_GetItem(e),null!=t&&(0==t.functionID||n.P.Inst_get().IsFunctionOpened(t.functionID))}GetUICfg(e){let t=null
return t=this.map.LuaDic_GetItem(e),null==t&&r.Y.LogError(`UIIDRESOURCE 找不到 id：${e}`),t}GetFunctionOpenId(e){let t=null
return t=this.map.LuaDic_GetItem(e),null!=t?t.functionID:0}GetFathersById(e){for(const[t,i]of(0,a.V5)(this.map))if(i.UIID==e)return i.fatherId
return null}GetIdByFunctionId(e){for(const[t,i]of(0,a.V5)(this.map))if(i.functionID==e)return i.UIID
return null}}o._inst=null},37142:(e,t,i)=>{i.d(t,{V:()=>p})
var n=i(52749),s=i(25777),l=i(80486),a=i(84229),r=i(87851),o=i(21554),d=i(37648),h=i(55492),u=i(31336),c=i(65550),I=i(86133),_=i(98800)
class p{static Inst_get(){return null==p._inst&&(p._inst=new p),p._inst}JumpToRyCompoundPanel(e,t){
d.P.Inst_get().IsFunctionOpened(h.x.COMPOUND)?(u.K.Inst_get().CompoundChildeViewType=e||0,u.K.Inst_get().jumpComposeId=t||0,
o.J.Inst_get().openOrClose(1)):c.y.inst.ClientSysStrMsg("功能未开启！")}JumpToAlliancePanel(e,t,i,o){
_.Y.Inst.PrimaryRoleInfo_get().isHaveAlliance_get()?(a.Q.Inst_get().defaultMainTabIndex=e,a.Q.Inst_get().infoViewType=t,s.z.Inst_get().quickOpenBuildingType=i,
n.m.Inst_Get().openTechId=o||0):(c.y.inst.ClientStrMsg(null,(0,I.T)("尚未加入战盟")),a.Q.Inst_get().defaultMainTabIndex=r.t.ASURAM),l.K.Inst().Open()}}p._inst=null},5494:(e,t,i)=>{let n
i.d(t,{I:()=>n}),function(e){e[e.Default=0]="Default",e[e.eUIRoot=1]="eUIRoot",e[e.PreLoadMainView=2]="PreLoadMainView",e[e.eTabCommon=3]="eTabCommon",e[e.BaseItem=4]="BaseItem",
e[e.Login=5]="Login",e[e.SelectServerList=6]="SelectServerList",e[e.eRole=7]="eRole",e[e.ItemTip=8]="ItemTip",e[e.eBagPanel=9]="eBagPanel",e[e.eBagSellPanel=10]="eBagSellPanel",
e[e.eBagSellSimplePanel=11]="eBagSellSimplePanel",e[e.eBagItem=12]="eBagItem",e[e.CharacterUIPanel=13]="CharacterUIPanel",e[e.eBagExpandAlert=14]="eBagExpandAlert",
e[e.BatchUserAlert=15]="BatchUserAlert",e[e.EquipTip=16]="EquipTip",e[e.ElementTip=17]="ElementTip",e[e.EleCarveTip=18]="EleCarveTip",e[e.EquipItemMenu=19]="EquipItemMenu",
e[e.SystemCommonMessage=20]="SystemCommonMessage",e[e.ClientTipMessage=21]="ClientTipMessage",e[e.RiversAndLakesSaid=22]="RiversAndLakesSaid",
e[e.SystemMessagePanel=23]="SystemMessagePanel",e[e.PolicyPanel=24]="PolicyPanel",e[e.BossStatus=25]="BossStatus",e[e.SelectCircle=26]="SelectCircle",
e[e.BattleReminderMsg=27]="BattleReminderMsg",e[e.TopSmallMap=28]="TopSmallMap",e[e.NpcPanel=29]="NpcPanel",e[e.ShortCutSelectPanel=30]="ShortCutSelectPanel",
e[e.SkillTip=31]="SkillTip",e[e.TargetPlayerPanelId=32]="TargetPlayerPanelId",e[e.MapTitle=33]="MapTitle",e[e.eTargetPlayerTopPanel=34]="eTargetPlayerTopPanel",e[e.Task=35]="Task",
e[e.Relive=36]="Relive",e[e.ReliveRole=37]="ReliveRole",e[e.eHangMainPanel=38]="eHangMainPanel",e[e.eHangStartIcon=39]="eHangStartIcon",e[e.eHangPauseIcon=40]="eHangPauseIcon",
e[e.RegisterPanel=41]="RegisterPanel",e[e.eHangSelectSkillPanel=42]="eHangSelectSkillPanel",e[e.eHangSelectSkillComponent=43]="eHangSelectSkillComponent",
e[e.eIconTipsPanel=44]="eIconTipsPanel",e[e.eLianjiTipsPanel=45]="eLianjiTipsPanel",e[e.TeamHeadPanel=46]="TeamHeadPanel",e[e.BloodTownPanel=47]="BloodTownPanel",
e[e.BloodTownRankPanel=48]="BloodTownRankPanel",e[e.CopyDefeatPanel=49]="CopyDefeatPanel",e[e.CopySuccessPanel=50]="CopySuccessPanel",e[e.PkTipsPanel=51]="PkTipsPanel",
e[e.eChatShowPanel=52]="eChatShowPanel",e[e.eChatMainPanel=53]="eChatMainPanel",e[e.ChatCopyTipId=54]="ChatCopyTipId",e[e.eChatHornPanel=55]="eChatHornPanel",
e[e.eChatTaskDetailPanel=56]="eChatTaskDetailPanel",e[e.eChatVoicePanel=57]="eChatVoicePanel",e[e.ChatSimplePanelId=58]="ChatSimplePanelId",
e[e.eBagExtendPanel=59]="eBagExtendPanel",e[e.eCollectSliderUI=60]="eCollectSliderUI",e[e.TreasurePanel=61]="TreasurePanel",e[e.eBossDropTipPanel=62]="eBossDropTipPanel",
e[e.EnterCopyTime=63]="EnterCopyTime",e[e.CopyInspire=64]="CopyInspire",e[e.CopyExpBuff=65]="CopyExpBuff",e[e.CopyGain=66]="CopyGain",e[e.ExitCopyTime=67]="ExitCopyTime",
e[e.eMap=68]="eMap",e[e.eMapMonsterTip=69]="eMapMonsterTip",e[e.eMapGateTip=70]="eMapGateTip",e[e.eMapPassMainBtn=71]="eMapPassMainBtn",e[e.eSmallUpDefPanel=72]="eSmallUpDefPanel",
e[e.WithOneShop=73]="WithOneShop",e[e.GetEquipPanel=74]="GetEquipPanel",e[e.GetItemPanel=75]="GetItemPanel",e[e.eEnhancePanel=76]="eEnhancePanel",e[e.BelialPanel=77]="BelialPanel",
e[e.CopyBelialUIPanel=78]="CopyBelialUIPanel",e[e.BelialResultPanel=79]="BelialResultPanel",e[e.ReliveCopy=80]="ReliveCopy",e[e.MailMainPanel=81]="MailMainPanel",
e[e.MailDetailPanel=82]="MailDetailPanel",e[e.AutoEnhancePanel=83]="AutoEnhancePanel",e[e.AutoAddPanel=84]="AutoAddPanel",e[e.EnhanceSuccessView=85]="EnhanceSuccessView",
e[e.EnhanceAutoSuccessView=86]="EnhanceAutoSuccessView",e[e.SuitSuccessView=87]="SuitSuccessView",e[e.SuitTipView=88]="SuitTipView",e[e.CompoundPanel=89]="CompoundPanel",
e[e.AlliancePanel=90]="AlliancePanel",e[e.AllianceApplyPanel=91]="AllianceApplyPanel",e[e.CreateAlliancePanel=92]="CreateAlliancePanel",
e[e.AllianceNoticePanel=93]="AllianceNoticePanel",e[e.AllianceAppointPanel=94]="AllianceAppointPanel",e[e.AllianceExpelPanel=95]="AllianceExpelPanel",
e[e.AllianceQuitPanel=96]="AllianceQuitPanel",e[e.AllianceAssignPanel=97]="AllianceAssignPanel",e[e.SkillShowPanel=98]="SkillShowPanel",e[e.eCommonTipsView=99]="eCommonTipsView",
e[e.ConsumeUseTip=100]="ConsumeUseTip",e[e.MapAreaTips=101]="MapAreaTips",e[e.AllianceInvitePanel=102]="AllianceInvitePanel",
e[e.BloodTownEvaluatePanel=103]="BloodTownEvaluatePanel",e[e.BloodTownSuccessPanel=104]="BloodTownSuccessPanel",e[e.BloodTownResultPanel=105]="BloodTownResultPanel",
e[e.BloodTownTracePanel=106]="BloodTownTracePanel",e[e.ActivityShowPanel=107]="ActivityShowPanel",e[e.eBloodTownStageTipView=108]="eBloodTownStageTipView",
e[e.eAchievePanel=109]="eAchievePanel",e[e.GmPanel=110]="GmPanel",e[e.GmMiniPanel=111]="GmMiniPanel",e[e.WorldDisPanel=112]="WorldDisPanel",
e[e.RetrieveBountryTip=113]="RetrieveBountryTip",e[e.eBloodTownLoading=114]="eBloodTownLoading",e[e.TitleTip=115]="TitleTip",e[e.TitleTotalTip=116]="TitleTotalTip",
e[e.MarketPanel=117]="MarketPanel",e[e.MarketPanel_ry=118]="MarketPanel_ry",e[e.Market_Gold_Panel_ry=119]="Market_Gold_Panel_ry",e[e.MarketItemBuyTip=120]="MarketItemBuyTip",
e[e.MarketItemAuctionTip=121]="MarketItemAuctionTip",e[e.MarketItemGoundingTip=122]="MarketItemGoundingTip",e[e.MarketCurrencyGoundingTip=123]="MarketCurrencyGoundingTip",
e[e.AccessPanel=124]="AccessPanel",e[e.eAdditionMasterPanel=125]="eAdditionMasterPanel",e[e.GetAuctionPanel=126]="GetAuctionPanel",e[e.WelfarePanelId=127]="WelfarePanelId",
e[e.LostAbyss=128]="LostAbyss",e[e.LostAbyssSuccessPanel=129]="LostAbyssSuccessPanel",e[e.LostAbyssBattleView=130]="LostAbyssBattleView",
e[e.RecommendHangPanel=131]="RecommendHangPanel",e[e.InputNumberPanel=132]="InputNumberPanel",e[e.eMainViewPanel=133]="eMainViewPanel",e[e.MainViewSkill=134]="MainViewSkill",
e[e.eMainViewExp=135]="eMainViewExp",e[e.SwitchTarget=136]="SwitchTarget",e[e.SettingMainPanel=137]="SettingMainPanel",e[e.OffLineRewardPanel=138]="OffLineRewardPanel",
e[e.eStrengthenPanel=139]="eStrengthenPanel",e[e.PkSwitchPanel=140]="PkSwitchPanel",e[e.MorePanel=141]="MorePanel",e[e.eTaskMainUI=142]="eTaskMainUI",
e[e.eTaskHideMainUI=143]="eTaskHideMainUI",e[e.RechargeBuyTip=144]="RechargeBuyTip",e[e.TransferJobPanel=145]="TransferJobPanel",
e[e.eTargetPlayerHeadPanel=146]="eTargetPlayerHeadPanel",e[e.eTargetPlayerHead=147]="eTargetPlayerHead",e[e.eBossKillInfoTip=148]="eBossKillInfoTip",
e[e.ForgePanel=149]="ForgePanel",e[e.AllianceTaskSuccessPanel=150]="AllianceTaskSuccessPanel",e[e.DailyMainPanel=151]="DailyMainPanel",
e[e.AllianceLevelUpPanel=152]="AllianceLevelUpPanel",e[e.VitalityTipsPanel=153]="VitalityTipsPanel",e[e.eAllianceOperationPanel=154]="eAllianceOperationPanel",
e[e.VitalityCalendarPanel=155]="VitalityCalendarPanel",e[e.VitalityCalendarTablePanel=156]="VitalityCalendarTablePanel",e[e.StarEquipTakeOffTip=157]="StarEquipTakeOffTip",
e[e.eDialoguePanel=158]="eDialoguePanel",e[e.eSuitFuseView=159]="eSuitFuseView",e[e.eSuitFuseSuccessView=160]="eSuitFuseSuccessView",e[e.HandInPanel=161]="HandInPanel",
e[e.RankingPanel=162]="RankingPanel",e[e.EleCarveEchoView=163]="EleCarveEchoView",e[e.EleCarveItemSelectView=164]="EleCarveItemSelectView",
e[e.EleCarveBagView=165]="EleCarveBagView",e[e.EleCarveSuccessView=166]="EleCarveSuccessView",e[e.EleCarveReSetView=167]="EleCarveReSetView",
e[e.EleCarveEchoUpView=168]="EleCarveEchoUpView",e[e.eArmyEquipView=169]="eArmyEquipView",e[e.eFriendView=170]="eFriendView",e[e.eFriendReqListView=171]="eFriendReqListView",
e[e.eFriendAddView=172]="eFriendAddView",e[e.RankCheckPlayerView=173]="RankCheckPlayerView",e[e.RecoverCopyCountTipsPanel=174]="RecoverCopyCountTipsPanel",
e[e.RecoverTaskRewardTipsPanel=175]="RecoverTaskRewardTipsPanel",e[e.eShortcutGoodsSelectPanel=176]="eShortcutGoodsSelectPanel",e[e.GMOpenPanel=177]="GMOpenPanel",
e[e.HangOpenPanel=178]="HangOpenPanel",e[e.ChangeAttrPanel=179]="ChangeAttrPanel",e[e.MapChangeProgress=180]="MapChangeProgress",e[e.CurrencyBar=181]="CurrencyBar",
e[e.PandoraTipsPanel=182]="PandoraTipsPanel",e[e.RyPandoraTipsPanel=183]="RyPandoraTipsPanel",e[e.PandoraVipTipsPanel=184]="PandoraVipTipsPanel",
e[e.PandoraSelectPanel=185]="PandoraSelectPanel",e[e.PandoraRewardShowPanel=186]="PandoraRewardShowPanel",e[e.PandoraVipRewardShowPanel=187]="PandoraVipRewardShowPanel",
e[e.PandoraTipsInfoPanel=188]="PandoraTipsInfoPanel",e[e.PandoraVipTipsInfoPanel=189]="PandoraVipTipsInfoPanel",e[e.PandoraRechargePanel=190]="PandoraRechargePanel",
e[e.MapLoading=191]="MapLoading",e[e.MapTitleDirfting=192]="MapTitleDirfting",e[e.TimeInput=193]="TimeInput",e[e.eLockScreenTip=194]="eLockScreenTip",
e[e.OpenServicePanel=195]="OpenServicePanel",e[e.eCopyBelielExpBuyPanel=196]="eCopyBelielExpBuyPanel",e[e.CopyInspireBtnPanel=197]="CopyInspireBtnPanel",
e[e.CopyExpBtnPanel=198]="CopyExpBtnPanel",e[e.CopySweepView=199]="CopySweepView",e[e.CopyLeftTimePanel=200]="CopyLeftTimePanel",
e[e.CopyBloodTownLeftTimePanel=201]="CopyBloodTownLeftTimePanel",e[e.CopyBloodTownGainAwardPanel=202]="CopyBloodTownGainAwardPanel",
e[e.eRedFortressRulePanel=203]="eRedFortressRulePanel",e[e.eRedFortressRewardShowPanel=204]="eRedFortressRewardShowPanel",e[e.WorldBossRewardTip=205]="WorldBossRewardTip",
e[e.eRedFortressPreparePanel=206]="eRedFortressPreparePanel",e[e.eRedFortressPrepareTimer=207]="eRedFortressPrepareTimer",
e[e.eRedFortressCollapseTimer=208]="eRedFortressCollapseTimer",e[e.eRedFortressFinishTimer=209]="eRedFortressFinishTimer",e[e.eRedFortressKillPanel=210]="eRedFortressKillPanel",
e[e.BossTeamDamageRankPanel=211]="BossTeamDamageRankPanel",e[e.BossMemberDamagePanel=212]="BossMemberDamagePanel",e[e.BossMemberDamageTip=213]="BossMemberDamageTip",
e[e.eRedFortressCollapsePanel=214]="eRedFortressCollapsePanel",e[e.NpcHeadPanel=215]="NpcHeadPanel",e[e.EquipPromoteSelectPanel=216]="EquipPromoteSelectPanel",
e[e.BuyAlertPanel=217]="BuyAlertPanel",e[e.BuyTipPanel=218]="BuyTipPanel",e[e.EquipPromoteTipPanel=219]="EquipPromoteTipPanel",e[e.eSkillTips=220]="eSkillTips",
e[e.eSkillNewViewByOther=221]="eSkillNewViewByOther",e[e.eSkillNewView=222]="eSkillNewView",e[e.eSkillNewTransferView=223]="eSkillNewTransferView",
e[e.BossBuffPanel=224]="BossBuffPanel",e[e.WingRefineTipPanel=225]="WingRefineTipPanel",e[e.WingSelectPanel=226]="WingSelectPanel",e[e.CollectBtnPanel=227]="CollectBtnPanel",
e[e.MailDeletePanel=228]="MailDeletePanel",e[e.MainUIKarimaPanel=229]="MainUIKarimaPanel",e[e.BountyTaskTipPanel=230]="BountyTaskTipPanel",e[e.TaskMainPanel=231]="TaskMainPanel",
e[e.FirstChargePanel=232]="FirstChargePanel",e[e.SpaceOriginRootView=233]="SpaceOriginRootView",e[e.SpaceOriginView=234]="SpaceOriginView",
e[e.SpaceOriginNoticeView=235]="SpaceOriginNoticeView",e[e.CrossBattleRootView=236]="CrossBattleRootView",e[e.CrossBossStatusView=237]="CrossBossStatusView",
e[e.CrossBossUseBadgeView=238]="CrossBossUseBadgeView",e[e.AttrIntructionPanel=239]="AttrIntructionPanel",e[e.eRemainsMainPanel=240]="eRemainsMainPanel",
e[e.BuyMedicineTip=241]="BuyMedicineTip",e[e.LuckyAddTipPanel=242]="LuckyAddTipPanel",e[e.eRemainsCopyPanel=243]="eRemainsCopyPanel",e[e.eRemainsFindPanel=244]="eRemainsFindPanel",
e[e.eKarimaCurseTip=245]="eKarimaCurseTip",e[e.eKarimaRelivePanel=246]="eKarimaRelivePanel",e[e.SceneAniPanel=247]="SceneAniPanel",e[e.SuitResolvePanel=248]="SuitResolvePanel",
e[e.TextTipPanel=249]="TextTipPanel",e[e.AsuramMainPanel=250]="AsuramMainPanel",e[e.eGuardLosePanel=251]="eGuardLosePanel",e[e.BuffTipPanel=252]="BuffTipPanel",
e[e.AsuramTaskTipPanel=253]="AsuramTaskTipPanel",e[e.InfoTipPanel=254]="InfoTipPanel",e[e.eCommonHintPanel=255]="eCommonHintPanel",
e[e.eCommonHintTopLayerPanel=256]="eCommonHintTopLayerPanel",e[e.GoldNpcPanel=257]="GoldNpcPanel",e[e.AsuramCopySuccessPanel=258]="AsuramCopySuccessPanel",
e[e.FPSPanel=259]="FPSPanel",e[e.eRedFortressHeadScorePanel=260]="eRedFortressHeadScorePanel",e[e.eButtonEffectPanel=261]="eButtonEffectPanel",
e[e.eLoadEffectPanel=262]="eLoadEffectPanel",e[e.eNotchView=263]="eNotchView",e[e.OffLineDieLogTip=264]="OffLineDieLogTip",e[e.OffLineRecoverPanel=265]="OffLineRecoverPanel",
e[e.BossDropPanel=266]="BossDropPanel",e[e.PhotographCapturePanel=267]="PhotographCapturePanel",e[e.AllianceBuildHallPanel=268]="AllianceBuildHallPanel",
e[e.AllianceBuildVaultPanel=269]="AllianceBuildVaultPanel",e[e.AllianceBuildTecPanel=270]="AllianceBuildTecPanel",e[e.AllianceWarehousePanel=271]="AllianceWarehousePanel",
e[e.AllianceSetPanel=272]="AllianceSetPanel",e[e.AllianceDonatePanel=273]="AllianceDonatePanel",e[e.BossHomeTipPanel=274]="BossHomeTipPanel",
e[e.WorldBossRulePanel=275]="WorldBossRulePanel",e[e.NeutrolBossRulePanel=276]="NeutrolBossRulePanel",e[e.VipBossRulePanel=277]="VipBossRulePanel",
e[e.KarimaBossRulePanel=278]="KarimaBossRulePanel",e[e.eRemainsUnlockPanel=279]="eRemainsUnlockPanel",e[e.CopyMonsterTip=280]="CopyMonsterTip",e[e.CopyNPCTip=281]="CopyNPCTip",
e[e.BoxGatherExitBtnPanel=282]="BoxGatherExitBtnPanel",e[e.BoxRefreshPanel=283]="BoxRefreshPanel",e[e.BoxExitPanel=284]="BoxExitPanel",
e[e.MapPassRewardTips=285]="MapPassRewardTips",e[e.MapPassNextTips=286]="MapPassNextTips",e[e.MapPassFbInfo=287]="MapPassFbInfo",
e[e.MapPassFbSuccessView=288]="MapPassFbSuccessView",e[e.MapPassFbFailView=289]="MapPassFbFailView",e[e.UnlockMapBossFbView=290]="UnlockMapBossFbView",
e[e.MapPassRewardView=291]="MapPassRewardView",e[e.eHeroMemoryPanel=292]="eHeroMemoryPanel",e[e.AllianceBlogPanel=293]="AllianceBlogPanel",
e[e.LoseSectrtsDetailPanel=294]="LoseSectrtsDetailPanel",e[e.MainViewEffectiveTip=295]="MainViewEffectiveTip",e[e.SettingRecommendTip=296]="SettingRecommendTip",
e[e.GetExpTipsPanel=297]="GetExpTipsPanel",e[e.eNpcSpeakPanel=298]="eNpcSpeakPanel",e[e.AccumulatePanel=299]="AccumulatePanel",e[e.TransferGetItemTip=300]="TransferGetItemTip",
e[e.TargetPlayerSuitTip=301]="TargetPlayerSuitTip",e[e.PromoteSuccessPanel=302]="PromoteSuccessPanel",e[e.eStrengthenListPanel=303]="eStrengthenListPanel",
e[e.ServerPanel=304]="ServerPanel",e[e.ServerPanel1=305]="ServerPanel1",e[e.FuncAnimePanel=306]="FuncAnimePanel",e[e.SuitTip=307]="SuitTip",
e[e.FuncPrenoticeTip=308]="FuncPrenoticeTip",e[e.VIPPanel=309]="VIPPanel",e[e.VIPExpView=310]="VIPExpView",e[e.VIPUpgradeView=311]="VIPUpgradeView",
e[e.VIPBuyPanel=312]="VIPBuyPanel",e[e.RecoverPanel=313]="RecoverPanel",e[e.RecoverCountView=314]="RecoverCountView",e[e.eElementPrintPanel=315]="eElementPrintPanel",
e[e.PhotographMainPanel=316]="PhotographMainPanel",e[e.PandoraBoxMainPanel=317]="PandoraBoxMainPanel",e[e.eMasterRoadOpenPanel=318]="eMasterRoadOpenPanel",
e[e.eMasterRoadSelectPanel=319]="eMasterRoadSelectPanel",e[e.eMasterRoadActivatePanel=320]="eMasterRoadActivatePanel",e[e.eMasterRoadEventPanel=321]="eMasterRoadEventPanel",
e[e.MasterRoadAccessTipPanel=322]="MasterRoadAccessTipPanel",e[e.BlankPanel=323]="BlankPanel",e[e.FullSceneTopPanel=324]="FullSceneTopPanel",
e[e.eAllianceBossCopyMonsterCountTip=325]="eAllianceBossCopyMonsterCountTip",e[e.eAllianceBossCopyMonsterOutTip=326]="eAllianceBossCopyMonsterOutTip",
e[e.eAllianceBossCopyRankPanel=327]="eAllianceBossCopyRankPanel",e[e.eAllianceBossInspirePanel=328]="eAllianceBossInspirePanel",
e[e.AllianceBossCopyResultPanel=329]="AllianceBossCopyResultPanel",e[e.AllianceBossUpgradeView=330]="AllianceBossUpgradeView",
e[e.AllianceBossAlertView=331]="AllianceBossAlertView",e[e.AllianceBossBoxView=332]="AllianceBossBoxView",e[e.AllianceBossDoubleBlood=333]="AllianceBossDoubleBlood",
e[e.AllianceBossCopyMapExitPanel=334]="AllianceBossCopyMapExitPanel",e[e.AllianceBossCountDown=335]="AllianceBossCountDown",e[e.TipListPanel=336]="TipListPanel",
e[e.StoryLoadingViewID=337]="StoryLoadingViewID",e[e.CopyControlBtnPanel=338]="CopyControlBtnPanel",e[e.HeroMemoryWakeTip=339]="HeroMemoryWakeTip",
e[e.MarketAttentionEquipPanel=340]="MarketAttentionEquipPanel",e[e.JobSkillPanel=341]="JobSkillPanel",e[e.RuneArmyEquipPanel=342]="RuneArmyEquipPanel",
e[e.MarketMyTradePanel=343]="MarketMyTradePanel",e[e.AllianceMemberView=344]="AllianceMemberView",e[e.ForgeSuittopPanel=345]="ForgeSuittopPanel",
e[e.CharacterSkillExercise=346]="CharacterSkillExercise",e[e.eBagView=347]="eBagView",e[e.BagEquipView=348]="BagEquipView",e[e.CompoundWingPanel=349]="CompoundWingPanel",
e[e.CompoundAngelPanel=350]="CompoundAngelPanel",e[e.HpTestPanel=351]="HpTestPanel",e[e.eSoulPanel=352]="eSoulPanel",e[e.eChangeLinePanel=353]="eChangeLinePanel",
e[e.EnhanceChangeEquipTipPanel=354]="EnhanceChangeEquipTipPanel",e[e.TransferJobEnterPanel=355]="TransferJobEnterPanel",e[e.QuestionDialogPanel=356]="QuestionDialogPanel",
e[e.eCopyEntrancePanel=357]="eCopyEntrancePanel",e[e.CopyLeavePanel=358]="CopyLeavePanel",e[e.EquipEnhanceMasterTipPanel=359]="EquipEnhanceMasterTipPanel",
e[e.EquipAdditionMasterTipPanel=360]="EquipAdditionMasterTipPanel",e[e.EquipExcellenceMasterTipPanel=361]="EquipExcellenceMasterTipPanel",
e[e.TaskRightEffectPanel=362]="TaskRightEffectPanel",e[e.eTaskChapterPanel=363]="eTaskChapterPanel",e[e.ExtraLoadingPanel=364]="ExtraLoadingPanel",
e[e.MapTaskReadyPanel=365]="MapTaskReadyPanel",e[e.MapTaskCanAcceptPanel=366]="MapTaskCanAcceptPanel",e[e.MapTaskAcceptedPanel=367]="MapTaskAcceptedPanel",
e[e.MapCopyCondPanel=368]="MapCopyCondPanel",e[e.GuardDevelopMainPanel=369]="GuardDevelopMainPanel",e[e.GuardBattlePrayTipPanel=370]="GuardBattlePrayTipPanel",
e[e.GuardBattleAttrAddTipPanel=371]="GuardBattleAttrAddTipPanel",e[e.GuardWarehousePanel=372]="GuardWarehousePanel",e[e.GuardExpPanel=373]="GuardExpPanel",
e[e.GuardTipPanel=374]="GuardTipPanel",e[e.GuardBagTipPanel=375]="GuardBagTipPanel",e[e.GuardGetPanel=376]="GuardGetPanel",e[e.GuardCollectAddPanel=377]="GuardCollectAddPanel",
e[e.GuardRecycleSettingPanel=378]="GuardRecycleSettingPanel",e[e.ConsignBuySurePanel=379]="ConsignBuySurePanel",e[e.FLYEFFVIEW=380]="FLYEFFVIEW",
e[e.RyCurveFlyItemView=381]="RyCurveFlyItemView",e[e.GuardSkillTipsPanel=382]="GuardSkillTipsPanel",e[e.LevelUpTip=383]="LevelUpTip",
e[e.SkillExchangePanel=384]="SkillExchangePanel",e[e.AngleSkillExchangePanel=385]="AngleSkillExchangePanel",e[e.BattleScoreAnimePanel=386]="BattleScoreAnimePanel",
e[e.AddPointTip=387]="AddPointTip",e[e.NewServerAdvantagePanel=388]="NewServerAdvantagePanel",e[e.RechargeShenbing=389]="RechargeShenbing",
e[e.TaskFinshEffect=390]="TaskFinshEffect",e[e.eTaskTempView=391]="eTaskTempView",e[e.GroundingItemTipPanel=392]="GroundingItemTipPanel",
e[e.GroundingEquipTipPanel=393]="GroundingEquipTipPanel",e[e.TaskExeEquipPanel=394]="TaskExeEquipPanel",e[e.TaskNoExeEquipPanel=395]="TaskNoExeEquipPanel",
e[e.TaskSkillPanel=396]="TaskSkillPanel",e[e.BountyTaskMainPanel=397]="BountyTaskMainPanel",e[e.MapTransportMask=398]="MapTransportMask",e[e.FullScreenMask=399]="FullScreenMask",
e[e.MapTaskBattlePanel=400]="MapTaskBattlePanel",e[e.MapCopyBattlePanel=401]="MapCopyBattlePanel",e[e.MapCopySucPanel=402]="MapCopySucPanel",
e[e.MapCopyFailPanel=403]="MapCopyFailPanel",e[e.FruitPanel=404]="FruitPanel",e[e.MainBuffListPanel=405]="MainBuffListPanel",e[e.MainAllBuffListPanel=406]="MainAllBuffListPanel",
e[e.CopySoonEndTimePanel=407]="CopySoonEndTimePanel",e[e.CDKeyPanel=408]="CDKeyPanel",e[e.CopyMapNoRecoverPanel=409]="CopyMapNoRecoverPanel",e[e.FasterFight=410]="FasterFight",
e[e.NoticeUI=411]="NoticeUI",e[e.GainInfoNoticeUI=412]="GainInfoNoticeUI",e[e.eObtainPanel=413]="eObtainPanel",e[e.eFlyItemPanel=414]="eFlyItemPanel",
e[e.GuardSkillReplacePanel=415]="GuardSkillReplacePanel",e[e.GuardSelectSkillPanel=416]="GuardSelectSkillPanel",e[e.GuardPieceCompoundPanel=417]="GuardPieceCompoundPanel",
e[e.GuardPieceSettingPanel=418]="GuardPieceSettingPanel",e[e.eVipBossSuccessPanel=419]="eVipBossSuccessPanel",e[e.EhanceEquipShineTipPanel=420]="EhanceEquipShineTipPanel",
e[e.AlliQuestionView=421]="AlliQuestionView",e[e.AlliQuestionInvatePanel=422]="AlliQuestionInvatePanel",e[e.AlliQuestionTransferPanel=423]="AlliQuestionTransferPanel",
e[e.eWelfareXPanel=424]="eWelfareXPanel",e[e.eSuitComposeTip=425]="eSuitComposeTip",e[e.eHeroMemoryGuideTip=426]="eHeroMemoryGuideTip",
e[e.eHeadBuffDetailPanel=427]="eHeadBuffDetailPanel",e[e.HeromemoryGetTip=428]="HeromemoryGetTip",e[e.eAllianceMasterPanel=429]="eAllianceMasterPanel",
e[e.eAllianceNoticePanel=430]="eAllianceNoticePanel",e[e.PassiveTalentPanel=431]="PassiveTalentPanel",e[e.MusTowerPanel=432]="MusTowerPanel",
e[e.VitalityActivityRewardPanel=433]="VitalityActivityRewardPanel",e[e.eAllianceShopPanel=434]="eAllianceShopPanel",e[e.eAllianceEntrustPanel=435]="eAllianceEntrustPanel",
e[e.eAllianceHelpPanel=436]="eAllianceHelpPanel",e[e.eMusTowerHardTimePanel=437]="eMusTowerHardTimePanel",e[e.eMusTowerNoramlTimePanel=438]="eMusTowerNoramlTimePanel",
e[e.eMusTowerHardSuccessPanel=439]="eMusTowerHardSuccessPanel",e[e.eMusTowerNormalSuccessPanel=440]="eMusTowerNormalSuccessPanel",
e[e.eMusTowerHardTracePanel=441]="eMusTowerHardTracePanel",e[e.eMustTowerNormalTracePanel=442]="eMustTowerNormalTracePanel",e[e.eForgeMasterTipPanel=443]="eForgeMasterTipPanel",
e[e.ForgeEnhanceSoulInfo=444]="ForgeEnhanceSoulInfo",e[e.ForgeEnhanceSoulInfoTip=445]="ForgeEnhanceSoulInfoTip",e[e.eMusTowerHardReSuccessPanel=446]="eMusTowerHardReSuccessPanel",
e[e.eMusTowerNormalReSuccessPanel=447]="eMusTowerNormalReSuccessPanel",e[e.eGuardQualityUpPanel=448]="eGuardQualityUpPanel",
e[e.eBloodTownItemStonePanel=449]="eBloodTownItemStonePanel",e[e.eBloodTownItemStoneFlyPanel=450]="eBloodTownItemStoneFlyPanel",
e[e.eBuyBattleBossHintPanel=451]="eBuyBattleBossHintPanel",e[e.eGetWingPanel=452]="eGetWingPanel",e[e.eGuardEquipmentTipPanel=453]="eGuardEquipmentTipPanel",
e[e.eMusTowerChapterPanel=454]="eMusTowerChapterPanel",e[e.eMusTowerCopyPanel=455]="eMusTowerCopyPanel",e[e.eTransJobMainView=456]="eTransJobMainView",
e[e.eRebirthMainIcon=457]="eRebirthMainIcon",e[e.eRebirthMainPanel=458]="eRebirthMainPanel",e[e.eRebirthSubmitPanel=459]="eRebirthSubmitPanel",
e[e.eRebirthSkillInfoPanel=460]="eRebirthSkillInfoPanel",e[e.eRebirthTalentTip=461]="eRebirthTalentTip",e[e.eRebirthSucPanel=462]="eRebirthSucPanel",
e[e.eRebirthBossIconPanel=463]="eRebirthBossIconPanel",e[e.eRebirthBossWildTimePanel=464]="eRebirthBossWildTimePanel",e[e.eRebirthMonsterPanel=465]="eRebirthMonsterPanel",
e[e.eRebirthHelpComePanel=466]="eRebirthHelpComePanel",e[e.eRebirthBossSucPanel=467]="eRebirthBossSucPanel",e[e.eRebirthBossFailPanel=468]="eRebirthBossFailPanel",
e[e.eTransferJobAccessView=469]="eTransferJobAccessView",e[e.eSystemForceMsgPanel=470]="eSystemForceMsgPanel",e[e.eSuitAttrTipPanel=471]="eSuitAttrTipPanel",
e[e.eTaskSuitEquipView=472]="eTaskSuitEquipView",e[e.eEnhanceEquipMaterialPanel=473]="eEnhanceEquipMaterialPanel",e[e.eSkillPanel=474]="eSkillPanel",
e[e.eSkillTipsPanel=475]="eSkillTipsPanel",e[e.SkillInfoTip=476]="SkillInfoTip",e[e.AngleSkillInfoTip=477]="AngleSkillInfoTip",e[e.TransferSkillTip=478]="TransferSkillTip",
e[e.eCommonRulesView=479]="eCommonRulesView",e[e.HorseItemTip=480]="HorseItemTip",e[e.eMarketMallBuyTip=481]="eMarketMallBuyTip",e[e.MarketAccessView=482]="MarketAccessView",
e[e.eLotteryTipView=483]="eLotteryTipView",e[e.eLotteryBuyItemView=484]="eLotteryBuyItemView",e[e.eFacadeSettingPanel=485]="eFacadeSettingPanel",
e[e.eFuncSetView=486]="eFuncSetView",e[e.eSkillMainViewTips=487]="eSkillMainViewTips",e[e.eBaptizeTalentSkillTip=488]="eBaptizeTalentSkillTip",
e[e.BaptizeAttrPreviewTip=489]="BaptizeAttrPreviewTip",e[e.ExcellentAdditionSuccessPanel=490]="ExcellentAdditionSuccessPanel",
e[e.AllienceBelielRankPanel=491]="AllienceBelielRankPanel",e[e.AllienceBelielScorePanel=492]="AllienceBelielScorePanel",e[e.AssistDamageRankPanel=493]="AssistDamageRankPanel",
e[e.WorldBossNormalSuccessPanel=494]="WorldBossNormalSuccessPanel",e[e.WorldBossExtraSuccessPanel=495]="WorldBossExtraSuccessPanel",
e[e.WorldBossAssistSuccessPanel=496]="WorldBossAssistSuccessPanel",e[e.AssistFinshEffect=497]="AssistFinshEffect",e[e.ScoreFlyPanel=498]="ScoreFlyPanel",
e[e.WorldBossFlyEffectPanel=499]="WorldBossFlyEffectPanel",e[e.WorldBossExtraRewardPanel=500]="WorldBossExtraRewardPanel",e[e.eAsuramTaskPanel=501]="eAsuramTaskPanel",
e[e.eGmLoginPanel=502]="eGmLoginPanel",e[e.eScoreFlyToBarPanel=503]="eScoreFlyToBarPanel",e[e.ExcellentAdditionPreviewTipPanel=504]="ExcellentAdditionPreviewTipPanel",
e[e.eTransportReadyPanel=505]="eTransportReadyPanel",e[e.eTestPanel=506]="eTestPanel",e[e.eAddPointWayTipPanel=507]="eAddPointWayTipPanel",
e[e.eDiamondGetEffectPanel=508]="eDiamondGetEffectPanel",e[e.eDiamondLimitGetRewardPanel=509]="eDiamondLimitGetRewardPanel",
e[e.eDiamondLimitNoticeIcon=510]="eDiamondLimitNoticeIcon",e[e.eDiamondLimitNoticeView=511]="eDiamondLimitNoticeView",e[e.eEliteTipPanel=512]="eEliteTipPanel",
e[e.eMinePanel=513]="eMinePanel",e[e.TransferJobSecondPanel=514]="TransferJobSecondPanel",e[e.SkylandCopyPanel=515]="SkylandCopyPanel",e[e.SlowDownTipPanel=516]="SlowDownTipPanel",
e[e.eJewelUpPanel=517]="eJewelUpPanel",e[e.eJewelSmeltPanel=518]="eJewelSmeltPanel",e[e.SkylandCountDownPanel=519]="SkylandCountDownPanel",
e[e.eAllianceBossInspireTipPanel=520]="eAllianceBossInspireTipPanel",e[e.eAllianceAssistThankPanel=521]="eAllianceAssistThankPanel",
e[e.eAllianceAssistRecieveThankPanel=522]="eAllianceAssistRecieveThankPanel",e[e.eCommonKillTipPanel=523]="eCommonKillTipPanel",e[e.eKarimaStarView=524]="eKarimaStarView",
e[e.eKarimaRunePanel=525]="eKarimaRunePanel",e[e.eKarimaDamagePanel=526]="eKarimaDamagePanel",e[e.eCommonFlyItemPanel=527]="eCommonFlyItemPanel",
e[e.eJewelSelectPanel=528]="eJewelSelectPanel",e[e.eActiveTip=529]="eActiveTip",e[e.eDivineActive=530]="eDivineActive",e[e.eJewelBookPanel=531]="eJewelBookPanel",
e[e.eTransferJobUnlockTip=532]="eTransferJobUnlockTip",e[e.ePrenoticeListPanel=533]="ePrenoticeListPanel",e[e.eApplyAgentPanel=534]="eApplyAgentPanel",
e[e.eTitleItemTip=535]="eTitleItemTip",e[e.eEfficiencyPanel=536]="eEfficiencyPanel",e[e.eEfficiencyExpDrug=537]="eEfficiencyExpDrug",
e[e.eEfficiencyExpDrugTip=538]="eEfficiencyExpDrugTip",e[e.eChatDebug=539]="eChatDebug",e[e.eAsuramTaskCopyTracePanel=540]="eAsuramTaskCopyTracePanel",
e[e.eRyAllianceCopyTaskView=541]="eRyAllianceCopyTaskView",e[e.RolandRepairCrackCopyView=542]="RolandRepairCrackCopyView",e[e.RolandDefenseCopy2View=543]="RolandDefenseCopy2View",
e[e.eAsuramPrenoticePanel=544]="eAsuramPrenoticePanel",e[e.eRechargeRebatePanel=545]="eRechargeRebatePanel",e[e.eRechargeExaminePanel=546]="eRechargeExaminePanel",
e[e.eBattleSkillPanel=547]="eBattleSkillPanel",e[e.eChangeNamePanel=548]="eChangeNamePanel",e[e.eSuitBild=549]="eSuitBild",e[e.eSuitBagPanel=550]="eSuitBagPanel",
e[e.eSuitRecyclePanel=551]="eSuitRecyclePanel",e[e.eSuitSplitPanel=552]="eSuitSplitPanel",e[e.eSuitTotalPanel=553]="eSuitTotalPanel",e[e.eQuentonMainPanel=554]="eQuentonMainPanel",
e[e.eQuentonNoticePanel=555]="eQuentonNoticePanel",e[e.eSetSkillPanel=556]="eSetSkillPanel",e[e.eTransferForthPanel=557]="eTransferForthPanel",
e[e.eSubPackRechargeView=558]="eSubPackRechargeView",e[e.eQuentonCopySuccessView=559]="eQuentonCopySuccessView",e[e.eGoldCallView=560]="eGoldCallView",
e[e.eQuentonCopyView=561]="eQuentonCopyView",e[e.eJoystickPanel=562]="eJoystickPanel",e[e.eLotteryExchangeSelectView=563]="eLotteryExchangeSelectView",
e[e.eAsuramBossBlood=564]="eAsuramBossBlood",e[e.eCastIronPanel=565]="eCastIronPanel",e[e.eGoldenTreasure=566]="eGoldenTreasure",
e[e.ActivityBaoKuBuyPanel=567]="ActivityBaoKuBuyPanel",e[e.ActivityBaoKuRewardPanel=568]="ActivityBaoKuRewardPanel",e[e.RedFortressNoticePanel=569]="RedFortressNoticePanel",
e[e.AllianceWelfarePanel=570]="AllianceWelfarePanel",e[e.AllianceDistributePanel=571]="AllianceDistributePanel",e[e.AllianceDrawRewardPanel=572]="AllianceDrawRewardPanel",
e[e.AllianceAssistBasePanel=573]="AllianceAssistBasePanel",e[e.AllianceAssistGoblinResponsePanel=574]="AllianceAssistGoblinResponsePanel",
e[e.AllianceAssistGoblinRewardPanel=575]="AllianceAssistGoblinRewardPanel",e[e.eTransferJobTipView=576]="eTransferJobTipView",e[e.eTransferOceneView=577]="eTransferOceneView",
e[e.eGodBlessMainView=578]="eGodBlessMainView",e[e.eJewelBagPanel=579]="eJewelBagPanel",e[e.eCommTextTipPanel=580]="eCommTextTipPanel",e[e.eUpLoadLogView=581]="eUpLoadLogView",
e[e.eMiracleDepositsView=582]="eMiracleDepositsView",e[e.eMiracleDepositsGainedView=583]="eMiracleDepositsGainedView",
e[e.eMiracleDepositsBuyItemView=584]="eMiracleDepositsBuyItemView",e[e.eAllianceWelfareDescView=585]="eAllianceWelfareDescView",
e[e.eSixTransferTaskPanel=586]="eSixTransferTaskPanel",e[e.eSixTransferCopyEndPanel=587]="eSixTransferCopyEndPanel",e[e.eAdvanceNoticePanel=588]="eAdvanceNoticePanel",
e[e.eSixTransferCopyEnterTaskPanel=589]="eSixTransferCopyEnterTaskPanel",e[e.eSixTransferCopyEnterMainPanel=590]="eSixTransferCopyEnterMainPanel",
e[e.eSixTransferTipPanel=591]="eSixTransferTipPanel",e[e.eMasterCompoundSuccessPanel=592]="eMasterCompoundSuccessPanel",
e[e.eElementEnhanceMasterPanel=593]="eElementEnhanceMasterPanel",e[e.eCrossChat=594]="eCrossChat",e[e.eVersionActivityPanel=595]="eVersionActivityPanel",
e[e.eMasterSuitSplitPanel=596]="eMasterSuitSplitPanel",e[e.eSeasonRingPanel=597]="eSeasonRingPanel",e[e.eSeasonRingUpgradePanel=598]="eSeasonRingUpgradePanel",
e[e.eSeasonRingEnhanceTip=599]="eSeasonRingEnhanceTip",e[e.eSeasonRingGothroughRealPanel=600]="eSeasonRingGothroughRealPanel",
e[e.eSeasonRingGothroughSuccessPanel=601]="eSeasonRingGothroughSuccessPanel",e[e.eSeasonRingActiveTipPanel=602]="eSeasonRingActiveTipPanel",
e[e.eSeasonRingActiveSucPanel=603]="eSeasonRingActiveSucPanel",e[e.eSeasonRingReplacePanel=604]="eSeasonRingReplacePanel",e[e.eSeasonRingTipPanel=605]="eSeasonRingTipPanel",
e[e.eScannerMsgPanel=606]="eScannerMsgPanel",e[e.eTransferServerMainPanel=607]="eTransferServerMainPanel",e[e.eTransferServerReadyPanel=608]="eTransferServerReadyPanel",
e[e.eSacredEquipPanel=609]="eSacredEquipPanel",e[e.eSacredEquipLvlUpPanel=610]="eSacredEquipLvlUpPanel",e[e.eSacredEquipActivedPanel=611]="eSacredEquipActivedPanel",
e[e.eSacredEquipForgePanel=612]="eSacredEquipForgePanel",e[e.eCrossAuctionBidPanel=613]="eCrossAuctionBidPanel",e[e.eTransferServerRank=614]="eTransferServerRank",
e[e.eTransferServerAlert=615]="eTransferServerAlert",e[e.eWorldFirmShareView=616]="eWorldFirmShareView",e[e.WingRefine=617]="WingRefine",e[e.DropExpPanel=618]="DropExpPanel",
e[e.ComposeResultView=619]="ComposeResultView",e[e.ManualPanel=620]="ManualPanel",e[e.eExcScroll=621]="eExcScroll",e[e.eExcScrollGet=622]="eExcScrollGet",
e[e.ManualBuyTip=623]="ManualBuyTip",e[e.ManualGainRewPanel=624]="ManualGainRewPanel",e[e.ManualFuncOpen=625]="ManualFuncOpen",e[e.RyEquipAdvance=626]="RyEquipAdvance",
e[e.RyEquipAdvanceSuccess=627]="RyEquipAdvanceSuccess",e[e.RyAngelEquipAdvanceSuccess=628]="RyAngelEquipAdvanceSuccess",e[e.CompoundAddMatPanel=629]="CompoundAddMatPanel",
e[e.AssistGainRewPanel=630]="AssistGainRewPanel",e[e.MetagemsBoxView=631]="MetagemsBoxView",e[e.MetagensTips=632]="MetagensTips",e[e.MetagensBlessActive=633]="MetagensBlessActive",
e[e.ActivityCalendarMainView=634]="ActivityCalendarMainView",e[e.BecomeStrongerMainView=635]="BecomeStrongerMainView",e[e.eTransJobGetSkill=636]="eTransJobGetSkill",
e[e.eRydtsNB=637]="eRydtsNB",e[e.eRydtsNBExample10=638]="eRydtsNBExample10",e[e.Createroleview_Ry=639]="Createroleview_Ry",e[e.SelectRole_Ry=640]="SelectRole_Ry",
e[e.DailyTaskInfo=641]="DailyTaskInfo",e[e.OfflineHangupPanel=642]="OfflineHangupPanel",e[e.GoldSpawnResultPanel=643]="GoldSpawnResultPanel",
e[e.GoldSpawnOutResultPanel=644]="GoldSpawnOutResultPanel",e[e.GoldSpawnMainPanel=645]="GoldSpawnMainPanel",e[e.GoldSpawnMonsterTip=646]="GoldSpawnMonsterTip",
e[e.GoldSpawnMainRightPanel=647]="GoldSpawnMainRightPanel",e[e.GoldSpawnRemainTimeTip=648]="GoldSpawnRemainTimeTip",e[e.GoldSpawnAddTimeTip=649]="GoldSpawnAddTimeTip",
e[e.GoldSpawnDefenseTip=650]="GoldSpawnDefenseTip",e[e.MultipleHangAddTimeTip=651]="MultipleHangAddTimeTip",e[e.MultipleHangRightPanel=652]="MultipleHangRightPanel",
e[e.MultipleHangRemainPanel=653]="MultipleHangRemainPanel",e[e.MultipleHangResultPanel=654]="MultipleHangResultPanel",e[e.MultipleHangPanel=655]="MultipleHangPanel",
e[e.MultipleHangBuffTip=656]="MultipleHangBuffTip",e[e.MapUnlockBossChangeView=657]="MapUnlockBossChangeView",e[e.MapUnlockFlyItem=658]="MapUnlockFlyItem",
e[e.MapUnlockView=659]="MapUnlockView",e[e.MapCrossBossChallengeView=660]="MapCrossBossChallengeView",e[e.EquipLuckyChangeTip=661]="EquipLuckyChangeTip",
e[e.MyStallView=662]="MyStallView",e[e.StallView=663]="StallView",e[e.StallLogView=664]="StallLogView",e[e.StallPutOffView=665]="StallPutOffView",
e[e.StallBuyView=666]="StallBuyView",e[e.StallPutOnView=667]="StallPutOnView",e[e.StallMarketView=668]="StallMarketView",e[e.OhterPlayerStallView=669]="OhterPlayerStallView",
e[e.RyStallHighPriceLogView=670]="RyStallHighPriceLogView",e[e.RyStallMyBuyLogView=671]="RyStallMyBuyLogView",e[e.RyStallReRentView=672]="RyStallReRentView",
e[e.BattleUseDrugs=673]="BattleUseDrugs",e[e.NewCompoundPanel=674]="NewCompoundPanel",e[e.RyCommonCompoundPanel=675]="RyCommonCompoundPanel",e[e.RYFriendPanel=676]="RYFriendPanel",
e[e.RyCompoundPutItemTip=677]="RyCompoundPutItemTip",e[e.RyCompoundPeekItemView=678]="RyCompoundPeekItemView",e[e.RYDailyPanel=679]="RYDailyPanel",
e[e.RYDailyGetAwardView=680]="RYDailyGetAwardView",e[e.RyExcaliburView=681]="RyExcaliburView",e[e.HandInItemView=682]="HandInItemView",
e[e.eWonderfulEventPanel=683]="eWonderfulEventPanel",e[e.RySearchPlayerPanel=684]="RySearchPlayerPanel",e[e.RyMedalPanel=685]="RyMedalPanel",
e[e.RyMedalUpPanel=686]="RyMedalUpPanel",e[e.RyNormalSkillTipView=687]="RyNormalSkillTipView",e[e.RyDivineSkillTipView=688]="RyDivineSkillTipView",
e[e.RyDivineCodeSkillTipView=689]="RyDivineCodeSkillTipView",e[e.RySkillPraticeSkillView=690]="RySkillPraticeSkillView",e[e.SelectRoleTip=691]="SelectRoleTip",
e[e.KarimaStatusView=692]="KarimaStatusView",e[e.KarimaRightView=693]="KarimaRightView",e[e.BufferMainView=694]="BufferMainView",e[e.GetBuffView=695]="GetBuffView",
e[e.RechargeGiftPanel=696]="RechargeGiftPanel",e[e.VipBossDefeatPanel=697]="VipBossDefeatPanel",e[e.FirstChargeRewardShow=698]="FirstChargeRewardShow",
e[e.eOfficialAccountPanel=699]="eOfficialAccountPanel",e[e.RySurfaceSelectView=700]="RySurfaceSelectView",e[e.RySurfaceSettingView=701]="RySurfaceSettingView",
e[e.RyFashionAttrView=702]="RyFashionAttrView",e[e.RyFashionCabinetView=703]="RyFashionCabinetView",e[e.FirstChargeSuccessPanel=704]="FirstChargeSuccessPanel",
e[e.RySkillLimitBuyView=705]="RySkillLimitBuyView",e[e.RySkillLimitBuySecondView=706]="RySkillLimitBuySecondView",e[e.RySkillLimitBuyRewardView=707]="RySkillLimitBuyRewardView",
e[e.eSevenDayPanel=708]="eSevenDayPanel",e[e.eSevenDayRankRewardPanel=709]="eSevenDayRankRewardPanel",e[e.OpenServerGrabPanel=710]="OpenServerGrabPanel",
e[e.OpenServerGrabAccessPanel=711]="OpenServerGrabAccessPanel",e[e.OpenServerGrabRankLisView=712]="OpenServerGrabRankLisView",e[e.eRainbow=713]="eRainbow",
e[e.DISCOUNT_GOODS_MAINVIEW=714]="DISCOUNT_GOODS_MAINVIEW",e[e.DISCOUNT_GOODS_BUY_RESULT=715]="DISCOUNT_GOODS_BUY_RESULT",e[e.HAND_EXP_UP_TIP=716]="HAND_EXP_UP_TIP",
e[e.RyAllianceCopyBornFireView=717]="RyAllianceCopyBornFireView",e[e.RyAllianceCopyChuanGongView=718]="RyAllianceCopyChuanGongView",
e[e.RyAllianceCopySubmitFireView=719]="RyAllianceCopySubmitFireView",e[e.RyAllianceCopyBeginFireView=720]="RyAllianceCopyBeginFireView",
e[e.RyAllianceCopySubmitFireConfirmView=721]="RyAllianceCopySubmitFireConfirmView",e[e.RyAllianceChuanGongView=722]="RyAllianceChuanGongView",
e[e.RyAllianceMinXiangView=723]="RyAllianceMinXiangView",e[e.GetRewardTipPanel=724]="GetRewardTipPanel",e[e.RyWorldMapExpTipsView=725]="RyWorldMapExpTipsView",
e[e.AsuramWarRewardPanel=726]="AsuramWarRewardPanel",e[e.AsuramWarStatusPanel=727]="AsuramWarStatusPanel",e[e.RyTargetPlayerMainPanel=728]="RyTargetPlayerMainPanel",
e[e.RyAllianceBuildTreasureView=729]="RyAllianceBuildTreasureView",e[e.RyDunBossTimer=730]="RyDunBossTimer",e[e.ItemModelTipView=731]="ItemModelTipView",
e[e.TaskObtainPanel=732]="TaskObtainPanel",e[e.TaskEquipCollectGuidePanel=733]="TaskEquipCollectGuidePanel",e[e.RidingBuyPanel=734]="RidingBuyPanel",
e[e.RidingBuyShowHorsePanel=735]="RidingBuyShowHorsePanel",e[e.RidingBuyTipPanel=736]="RidingBuyTipPanel",e[e.DialogueRobotPanel=738]="DialogueRobotPanel",
e[e.eGameGM=739]="eGameGM",e[e.eGameGMCreateRoleSelect=740]="eGameGMCreateRoleSelect",e[e.eGameExit=741]="eGameExit",e[e.eRyArenaView=742]="eRyArenaView",
e[e.eRyArenaRewardView=743]="eRyArenaRewardView",e[e.eRyArenaLogView=744]="eRyArenaLogView",e[e.eRyArenaHeadRightView=745]="eRyArenaHeadRightView",
e[e.eRyArenaHeadLeftView=746]="eRyArenaHeadLeftView",e[e.eRyArenaCopyTimerView=747]="eRyArenaCopyTimerView",e[e.eRyArenaCopyResultView=748]="eRyArenaCopyResultView",
e[e.eRyArenaCopyDamageView=749]="eRyArenaCopyDamageView",e[e.eRyArenaCleanUpView=750]="eRyArenaCleanUpView",e[e.eRyArenaCopyExitView=751]="eRyArenaCopyExitView",
e[e.RyEquipAdvancePanel=752]="RyEquipAdvancePanel",e[e.RyEquipAdvanceSelectEquipPanel=753]="RyEquipAdvanceSelectEquipPanel",
e[e.RyEquipAdvancePeekAttrPanel=754]="RyEquipAdvancePeekAttrPanel",e[e.ActivityLottery=755]="ActivityLottery",e[e.RyAllianceBuildTecPanel=756]="RyAllianceBuildTecPanel",
e[e.RyAllianceBuildDonation=757]="RyAllianceBuildDonation",e[e.GainItemView=758]="GainItemView",e[e.RyAllianceFactory=759]="RyAllianceFactory",
e[e.RyAlliancePullCar=760]="RyAlliancePullCar",e[e.FortuneTreasure=761]="FortuneTreasure",e[e.FortuneFateResultPanel=762]="FortuneFateResultPanel",
e[e.FortuneMerchant=763]="FortuneMerchant",e[e.FortuneTipView=764]="FortuneTipView",e[e.eRyLoadingCircleView=765]="eRyLoadingCircleView",
e[e.AdvanceFightTokenTip=766]="AdvanceFightTokenTip",e[e.GEM_MASTER=767]="GEM_MASTER",e[e.GEM_SELECT=768]="GEM_SELECT",e[e.WingRefineSelectItemView=769]="WingRefineSelectItemView",
e[e.WingRefineSuccessView=770]="WingRefineSuccessView",e[e.MayaTreasureView=771]="MayaTreasureView",e[e.MayaTreasureResultView=772]="MayaTreasureResultView",
e[e.MayaExchangeTipView=773]="MayaExchangeTipView",e[e.CancelTransformIcon=774]="CancelTransformIcon",e[e.ChariotInProcess=775]="ChariotInProcess",
e[e.HonorGiftView=776]="HonorGiftView",e[e.HonorGiftResultView=777]="HonorGiftResultView",e[e.MapLevelTips=778]="MapLevelTips",e[e.eRyOnlineHangIcon=779]="eRyOnlineHangIcon",
e[e.eRyOnlineHangView=780]="eRyOnlineHangView",e[e.eTaskContractMainUI=781]="eTaskContractMainUI",e[e.eTaskContractInfoPanel=782]="eTaskContractInfoPanel",
e[e.eTaskContractSelectPanel=783]="eTaskContractSelectPanel",e[e.eTaskContractSelectEndPanel=784]="eTaskContractSelectEndPanel",e[e.eTaskContractPanel=785]="eTaskContractPanel",
e[e.eTaskContractFinishEffectPanel=786]="eTaskContractFinishEffectPanel",e[e.eTaskContractRecoverPanel=787]="eTaskContractRecoverPanel",e[e.eAccessPanel=788]="eAccessPanel",
e[e.eAccessCurrencyPanel=789]="eAccessCurrencyPanel",e[e.eAccessCurrencyPanel2=790]="eAccessCurrencyPanel2",e[e.eAccessListCommonPanel=791]="eAccessListCommonPanel",
e[e.TradingMarketOperation=792]="TradingMarketOperation",e[e.TradingMarketGetItemTipView=793]="TradingMarketGetItemTipView",
e[e.TradingMarketAttention=794]="TradingMarketAttention",e[e.TradingMarketLogPanel=795]="TradingMarketLogPanel",e[e.ChangeJobMainPanel=796]="ChangeJobMainPanel",
e[e.ChangeJobDetailPanel=797]="ChangeJobDetailPanel",e[e.ChangeJobEffectPanel=798]="ChangeJobEffectPanel",e[e.ChangeJobResPanel=799]="ChangeJobResPanel",
e[e.AngelEquipGetView=800]="AngelEquipGetView"
e[e.AsuramWarScoreShowPanel=801]="AsuramWarScoreShowPanel",e[e.AsuramWarFailedPanel=802]="AsuramWarFailedPanel",e[e.AsuramWarSucPanel=803]="AsuramWarSucPanel",
e[e.AsuramWarHistoryPanel=804]="AsuramWarHistoryPanel",e[e.AsuramWarDamagePanel=805]="AsuramWarDamagePanel",e[e.eRyArenaBuyNumView=806]="eRyArenaBuyNumView",
e[e.AsuramWarStatisticsPanel=807]="AsuramWarStatisticsPanel",e[e.AsuramWarDowntimePanel=808]="AsuramWarDowntimePanel",e[e.KarimaGainView=809]="KarimaGainView",
e[e.REDPACKET=810]="REDPACKET",e[e.AsuramWarDoorPanel=811]="AsuramWarDoorPanel",e[e.AsuramWarCampPanel=812]="AsuramWarCampPanel",e[e.AsuramWarRulePanel=813]="AsuramWarRulePanel",
e[e.MapPassAlertPanel=814]="MapPassAlertPanel",e[e.RyExorcismCopyTraceView=815]="RyExorcismCopyTraceView",e[e.RyExorcismCopyResultView=816]="RyExorcismCopyResultView",
e[e.RyExorcismCopyBuffSelectView=817]="RyExorcismCopyBuffSelectView",e[e.CDKeyView=818]="CDKeyView",e[e.ExorcismRankRewardView=819]="ExorcismRankRewardView",
e[e.ExorcismRewardShowView=820]="ExorcismRewardShowView",e[e.ExorcismTotalRewardView=821]="ExorcismTotalRewardView",e[e.ExorcismBadgeEffView=822]="ExorcismBadgeEffView",
e[e.ExorcismView=823]="ExorcismView",e[e.GodSuitRoadPanel=824]="GodSuitRoadPanel",e[e.AccessKindsPanel=825]="AccessKindsPanel",e[e.PandoraSelectPanel_1=826]="PandoraSelectPanel_1",
e[e.MazeTimeSpaceView=827]="MazeTimeSpaceView",e[e.MazeTimeSpaceRoomView=828]="MazeTimeSpaceRoomView",e[e.TimeSpaceMarketView=829]="TimeSpaceMarketView",
e[e.MazeTimeSpaceResultView=830]="MazeTimeSpaceResultView",e[e.MazeCopyRightPanel=831]="MazeCopyRightPanel",e[e.MazeRulePanel=832]="MazeRulePanel",
e[e.MazeGetEnergyView=833]="MazeGetEnergyView",e[e.AsuramWarRankPanel=834]="AsuramWarRankPanel",e[e.UseHangItemView=835]="UseHangItemView",
e[e.AWAltarTracePanel=836]="AWAltarTracePanel",e[e.AWRuneNoticePanel=837]="AWRuneNoticePanel",e[e.ElementItemMainVIew=838]="ElementItemMainVIew",
e[e.ElementEnhanceBagView=839]="ElementEnhanceBagView",e[e.EleCompoundBagView=840]="EleCompoundBagView",e[e.EleCompoundSuccessView=841]="EleCompoundSuccessView",
e[e.RechargeByTester=842]="RechargeByTester",e[e.RyWingPreView=843]="RyWingPreView",e[e.RolandDefenseMainView=844]="RolandDefenseMainView",
e[e.RolandCopySuccess1=845]="RolandCopySuccess1",e[e.RolandSenceView=846]="RolandSenceView",e[e.RolandAppearMainView=847]="RolandAppearMainView",
e[e.RolandAppearBuffRewardView=848]="RolandAppearBuffRewardView",e[e.RolandActivityTipView=849]="RolandActivityTipView",e[e.RolandValleyCopyView=850]="RolandValleyCopyView",
e[e.RolandValleyCopySuccessView=851]="RolandValleyCopySuccessView",e[e.RolandEndTipView=852]="RolandEndTipView",e[e.ThemeCarnival=853]="ThemeCarnival",
e[e.ElementItemShowStageUpView=854]="ElementItemShowStageUpView",e[e.StarSkyTabView=855]="StarSkyTabView",e[e.CommRewardView=856]="CommRewardView",
e[e.SkyRewardPoolView=857]="SkyRewardPoolView",e[e.DragonTreasureView=858]="DragonTreasureView",e[e.DragonTreasureBuyTipView=859]="DragonTreasureBuyTipView",
e[e.DragonTreasureShopView=860]="DragonTreasureShopView",e[e.DragonRewardPoolView=861]="DragonRewardPoolView",e[e.DragonResultView=862]="DragonResultView",
e[e.DragonTreasureTreasureShopView=863]="DragonTreasureTreasureShopView",e[e.GloryCallRootView=864]="GloryCallRootView",e[e.GloryCallShopView=865]="GloryCallShopView",
e[e.GloryCallResultView=866]="GloryCallResultView",e[e.ExpireTip=867]="ExpireTip",e[e.ExpireTipBtn=868]="ExpireTipBtn",e[e.HuoDongMallBuyPanel=869]="HuoDongMallBuyPanel",
e[e.HuoDongMallSuccessPanel=870]="HuoDongMallSuccessPanel",e[e.HonorKingMainPanel=871]="HonorKingMainPanel",e[e.RolandGuideShowView=872]="RolandGuideShowView",
e[e.RolandNoticeView=873]="RolandNoticeView",e[e.RolandSaveCrusadeTraceView=874]="RolandSaveCrusadeTraceView",e[e.RolandSaveCrusadeResultView=875]="RolandSaveCrusadeResultView",
e[e.RolandSaveResultView=876]="RolandSaveResultView",e[e.RolandSavePanel=877]="RolandSavePanel",e[e.RolandSaveAddPowerPanel=878]="RolandSaveAddPowerPanel",
e[e.RolandSaveRewardRankPanel=879]="RolandSaveRewardRankPanel",e[e.RolandSaveFirstEnterBlackPanel=880]="RolandSaveFirstEnterBlackPanel",
e[e.RolandSaveFightRankPanel=881]="RolandSaveFightRankPanel",e[e.RolandSaveBossCD=882]="RolandSaveBossCD",e[e.RolandSaveWishBuffTip=883]="RolandSaveWishBuffTip",
e[e.RolandSaveBossComeTimePanel=884]="RolandSaveBossComeTimePanel",e[e.RolandSaveBossRewardRankTip=885]="RolandSaveBossRewardRankTip",
e[e.RolandSaveEfficiencyMainUI=886]="RolandSaveEfficiencyMainUI",e[e.RolandSaveMemberDamagePanel=887]="RolandSaveMemberDamagePanel",
e[e.MazeTimeSpaceResetPanel=888]="MazeTimeSpaceResetPanel",e[e.AWMatchingPanel=889]="AWMatchingPanel",e[e.FightTokenGetTipPanel=890]="FightTokenGetTipPanel",
e[e.AWScoreShowPanel=891]="AWScoreShowPanel",e[e.RyEquipRefineAllAttrView=892]="RyEquipRefineAllAttrView",e[e.RyEquipRefineRefineView=893]="RyEquipRefineRefineView",
e[e.RyEquipRefineReplaceView=894]="RyEquipRefineReplaceView",e[e.RyEquipRefineUpgradeSucView=895]="RyEquipRefineUpgradeSucView",
e[e.RyPublicBetaMianView=896]="RyPublicBetaMianView",e[e.RyPublicBetaJigsawLightChipView=897]="RyPublicBetaJigsawLightChipView",
e[e.RyPublicBetaRewardView=898]="RyPublicBetaRewardView",e[e.RyPublicBetaDaliyTipView=899]="RyPublicBetaDaliyTipView",
e[e.RyPublicBetaDaliyRewardView=900]="RyPublicBetaDaliyRewardView",e[e.RyPublicBetaCollctRewardIcon=901]="RyPublicBetaCollctRewardIcon",
e[e.RyPublicBetaCollctRewardView=902]="RyPublicBetaCollctRewardView",e[e.RySpringFestivalMainView=903]="RySpringFestivalMainView",
e[e.RyGoldCattleRewardView=904]="RyGoldCattleRewardView",e[e.FiveBlessComeShareView=905]="FiveBlessComeShareView",e[e.FiveBlessComeExchangeView=906]="FiveBlessComeExchangeView",
e[e.FiveBlessComeRewardView=907]="FiveBlessComeRewardView",e[e.SpringCattleCopyView=908]="SpringCattleCopyView",
e[e.RySpringFestivalCelebrateResultView=909]="RySpringFestivalCelebrateResultView",e[e.ObeliskPanel=910]="ObeliskPanel",e[e.ObeliskSankPanel=911]="ObeliskSankPanel",
e[e.CrimeBuffSelectPanel=912]="CrimeBuffSelectPanel",e[e.CrimeRewardRankPanel=913]="CrimeRewardRankPanel",e[e.CrimeCopyEndTimePanel=914]="CrimeCopyEndTimePanel",
e[e.CrimeFightBuffPanel=915]="CrimeFightBuffPanel",e[e.CrimeValueRewardPanel=916]="CrimeValueRewardPanel",e[e.CrimeRankRewardPanel=917]="CrimeRankRewardPanel",
e[e.CrimeCopySucPanel=918]="CrimeCopySucPanel",e[e.CrimeCopyFailPanel=919]="CrimeCopyFailPanel",e[e.SuperVipView=920]="SuperVipView",
e[e.RyPublicBetaAutoCollctScreenIcon=921]="RyPublicBetaAutoCollctScreenIcon",e[e.LimitedEncorePanel=922]="LimitedEncorePanel",
e[e.RyEquipStarAdvanceView=923]="RyEquipStarAdvanceView",e[e.RyEquipStarAdvanceSelectEquipView=924]="RyEquipStarAdvanceSelectEquipView",
e[e.RyEquipStarAdvanceSuccessEquipView=925]="RyEquipStarAdvanceSuccessEquipView",e[e.ReportPlayerPanel=926]="ReportPlayerPanel",e[e.eATestView=1e4]="eATestView",
e[e.dailyTotalRechargePanel=10001]="dailyTotalRechargePanel",e[e.EffectShowEditor=10002]="EffectShowEditor",e[e.RuneTip=10003]="RuneTip",e[e.HPWarningPanel=10004]="HPWarningPanel"
}(n||(n={}))},8334:(e,t,i)=>{i.d(t,{Z:()=>n})
var n={eCustom:0,eCenter:1,eLeft:2,eTop:3,eRight:4,eBottom:5,eLeftTop:6,eRightTop:7,eLeftBottm:8,eRightBottom:9}},61613:(e,t,i)=>{i.d(t,{v:()=>u})
var n=i(98130),s=i(52212),l=i(79534),a=i(44758),r=i(60130)
const o=1280
let d=0,h=0
class u{static __StaticInit(){d=280,h=d/2}static GetAdaptionWidth(e,t){const i=r.O.GetUIWidth()
if(i>o){const s=i-o
return n.GF.INT(e+(t-e)/d*s)}return e}GetAdaptionHight(){return 720}static SetAdaptionPos(e,t,i,n=null){if(null==n){let[t,i]=[0,0];[t,n,i]=e.GetLocalPositionXYZ()}
const s=r.O.GetUIWidth()
let l=t
if(s>o&&i!=t){l+=(i-t)/d*(s-o)}e.SetLocalPositionXYZ(l,n,0)}SetUIPanelSize(e,t,i,n,s,l,d,h){if(null==t&&(t=0),!(i&&n&&s&&l))return
const u=r.O.GetUIWidth()
0==t?e.baseClipRegionSet(new a.L(i,n,u-o+s,l)):1==t?e.baseClipRegionSet(new a.L(i-(u-o)/2,n,u-o+s,l)):e.baseClipRegionSet(new a.L(i+(u-o)/2,n,u-o+s,l))}SetUIGridCell(e,t,i){
if(!t)return
if(t<1)return
if(!i)return
i+=(r.O.GetUIWidth()-o)/(t-1),e.cellWidthSet(i)}AdaptUIToSubWidget1(e,t,i){r.O.GetUIWidth()<u.LONG_WIDTH_SIGN||u.LayoutUIToRect(e,t,null,!0,i)}AdaptUIToSubWidget2(e,t,i){
r.O.GetUIWidth()<u.LONG_WIDTH_SIGN||u.LayoutUIToRect(e,t,u.GetTabSubRect(2),!1,i)}AdaptUIToRect(e,t,i,n,s,l,a){r.O.GetUIWidth()<u.LONG_WIDTH_SIGN||u.LayoutUIToRect(e,t,i,n,s,l,a)}
static LayoutUIToX(e,t,i,n,s,o,d){if(r.O.GetUIWidth()<u.LONG_WIDTH_SIGN&&!d)return
if(null==e)return
if(0==t)return
if(null==e)return
null==s&&(s=!0),null==i&&(i=0),null==o&&(o=r.O.GetUIWidth()/2)
let h=null
null==n?h=u.GetTabSubRect():(h=new a.L(n.x,n.y,n.z,n.w),s&&(h.x=n.x+u.TAB_LEFT_WIDTH,h.y=n.y+u.TAB_SUBWIDGET_BOTTOM_HEIGHT))
let c=0
null==t&&(t=u.LAYOUT_CENTER),t==u.LAYOUT_LEFT?c=h.x:t==u.LAYOUT_CENTER?c=h.x+h.z/2:t==u.LAYOUT_RIGHT&&(c=h.x+h.z),c+=i,c-=o
const I=e.position
e.SetLocalPositionXYZ(c,I.y,I.z),l.P.Recyle(new l.P(I.x,I.y,I.z))}static LayoutUIToRect(e,t,i,n,o,d,h){if(null==e)return
if(0==t)return
if(null==e)return
null==n&&(n=!0)
let c=null
null==i?c=u.GetTabSubRect():(c=new a.L(i.x,i.y,i.z,i.w),n&&(c.x=i.x+u.TAB_LEFT_WIDTH,c.y=i.y+u.TAB_SUBWIDGET_BOTTOM_HEIGHT)),null==d&&(d=r.O.GetUIWidth()/2),
null==h&&(h=r.O.GetUIHeight()/2),null==t&&(t=u.LAYOUT_CENTER),null==o&&(o=s.F.zero_get())
const I=new l.P
t==u.LAYOUT_LEFT_TOP?(I.x=c.x,I.y=c.y+c.w):t==u.LAYOUT_CENTER_TOP?(I.x=c.x+c.z/2,I.y=c.y+c.w):t==u.LAYOUT_RIGHT_TOP?(I.x=c.x+c.z,I.y=c.y+c.w):t==u.LAYOUT_LEFT?(I.x=c.x,
I.y=c.y+c.w/2):t==u.LAYOUT_CENTER?(I.x=c.x+c.z/2,I.y=c.y+c.w/2):t==u.LAYOUT_RIGHT?(I.x=c.x+c.z,I.y=c.y+c.w/2):t==u.LAYOUT_LEFT_BOTTOM?(I.x=c.x,
I.y=c.y):t==u.LAYOUT_CENTER_BOTTOM?(I.x=c.x+c.z/2,I.y=c.y):t==u.LAYOUT_RIGHT_BOTTOM&&(I.x=c.x+c.z,I.y=c.y),I.x+=o.x,I.y+=o.y,I.x-=d,I.y-=h,e.SetLocalPositionXYZ(I.x,I.y,I.z),
l.P.Recyle(I),a.L.Recyle(c)}GetPanelLocalPosition(e,t){if(null==e||null==t)return l.P.zero_get()
const i=l.P.zero_get(),n=t.InverseTransformPoint(e.TransformPoint(i))
return l.P.Recyle(i),n}static GetTabSubRect(e){
return null==e&&(e=1),1==e?(null==u.TAB_SUBWIDGET_RECT_1&&(u.TAB_SUBWIDGET_RECT_1=new a.L(u.TAB_LEFT_WIDTH,u.TAB_SUBWIDGET_BOTTOM_HEIGHT,r.O.GetUIWidth()-u.TAB_LEFT_WIDTH-u.TAB_RIGHT_WIDTH_1,u.TAB_SUBWIDGET_HEIGHT)),
u.TAB_SUBWIDGET_RECT_1.Clone()):2==e?(null==u.TAB_SUBWIDGET_RECT_2&&(u.TAB_SUBWIDGET_RECT_2=new a.L(u.TAB_LEFT_WIDTH,u.TAB_SUBWIDGET_BOTTOM_HEIGHT,r.O.GetUIWidth()-u.TAB_LEFT_WIDTH-u.TAB_RIGHT_WIDTH_2,u.TAB_SUBWIDGET_HEIGHT)),
u.TAB_SUBWIDGET_RECT_2.Clone()):u.TAB_SUBWIDGET_RECT_1.Clone()}NeedAdaption(){return!(r.O.GetUIWidth()<u.LONG_WIDTH_SIGN)}static GetHalfWOffset(e,t){null==t&&(t=!0)
const i=u.GetAdaptionWidth(0,h)
return t?i+e:e-i}}u.TAB_LEFT_WIDTH=150,u.TAB_RIGHT_WIDTH_1=104,u.TAB_RIGHT_WIDTH_2=140,u.TAB_SUBWIDGET_HEIGHT=550,u.TAB_SUBWIDGET_BOTTOM_HEIGHT=84,u.NORMAL_WIDTH_SIGN=1280,
u.LONG_WIDTH_SIGN=1440,u.TAB_SUBWIDGET_RECT_1=null,u.TAB_SUBWIDGET_RECT_2=null,u.LAYOUT_LEFT_TOP=1,u.LAYOUT_CENTER_TOP=2,u.LAYOUT_RIGHT_TOP=3,u.LAYOUT_LEFT=4,u.LAYOUT_CENTER=5,
u.LAYOUT_RIGHT=6,u.LAYOUT_LEFT_BOTTOM=7,u.LAYOUT_CENTER_BOTTOM=8,u.LAYOUT_RIGHT_BOTTOM=9,u.__StaticInit()},28192:(e,t,i)=>{i.d(t,{h:()=>p})
var n=i(38962),s=i(18998),l=i(62734),a=i(81266),r=i(85602),o=i(58087),d=i(38836),h=i(38045),u=i(97461),c=i(5924),I=i(66788)
let _=null
class p{static __StaticInit(){}constructor(){this.m_destroyComps=null,this.m_destroyUIObjComps=null,this.m_clearCompsCache=null,this.m_selfTarget=null,this.m_compHandlers=null,
this.m_timerIds=null,this.m_timerKeyWraps=null,this.m_clearObjs=null,this.m_clearComps=null,this.m_notifyHandlers=null,this.m_clearFuns=null,this.m_redPointFuncs=null,
this.m_clearRedPoint=null,this.uIShortCutType=null,this.m_guideObjs=null,this.ResetClearData()}static Get(){let e=null
const t=p.s_instancePool.Count()
return t>0&&(e=p.s_instancePool[t-1],p.s_instancePool.RemoveAt(t-1)),e=new p,e}static Recycle(e,t){null==t&&(t=!0),t&&(e.Clear(),e.Destroy()),p.s_instancePool.Add(e)}
ResetClearData(){this.m_compHandlers=null,this.m_timerIds=null,this.m_timerKeyWraps=null,this.m_clearObjs=null,this.m_clearComps=null,this.m_notifyHandlers=null,
this.m_clearFuns=null,this.m_redPointFuncs=null,this.m_clearRedPoint=null,this.uIShortCutType=null,this.m_guideObjs=null}Clear(){if(null!=this.m_clearObjs)for(const[e,t]of(0,
d.X)(this.m_clearObjs))null!=e&&e.Clear()
if(null!=this.m_clearCompsCache)for(const[e,t]of(0,d.X)(this.m_clearCompsCache))0==e.IsDestroyed()&&e.Clear()
if(null!=this.m_compHandlers)for(const[e,t]of(0,d.X)(this.m_compHandlers))for(const[i,n]of(0,
d.X)(t))e==p.HandlerType_Click?i.RemoveonClick(n):e==p.HandlerType_OnPress?i.RemoveOnPress(n):e==p.HandlerType_Select&&i.RemoveonSelect(n)
if(null!=this.m_notifyHandlers)for(const[e,t]of(0,d.X)(this.m_notifyHandlers))for(const[i,n]of(0,d.X)(t))for(const[t,s]of(0,d.X)(n))e.RemoveEventHandler(i,s)
if(null!=this.m_timerIds)for(const[e,t]of(0,d.X)(this.m_timerIds))c.C.Inst_get().ClearInterval(e)
if(null!=this.m_timerKeyWraps)for(const[e,t]of(0,d.X)(this.m_timerKeyWraps));if(null!=this.m_clearComps)for(const[e,t]of(0,
d.X)(this.m_clearComps))"string"!=typeof e&&0==e.IsDestroyed()&&e.Clear()
if(null!=this.m_clearRedPoint)for(const[e,t]of(0,d.X)(this.m_clearRedPoint)){const i=l.f.Inst.GetData(t[1])
null!=i&&i.RemovetipObj(e)}if(null!=this.m_redPointFuncs)for(const[e,t]of(0,d.X)(this.m_redPointFuncs))for(const[i,n]of(0,d.X)(t))l.f.Inst.RemoveCallback(e,i)
if(null!=this.m_clearFuns)for(const[e,t]of(0,d.X)(this.m_clearFuns))e()
this.ResetClearData()}Destroy(){if(null!=this.m_destroyComps)for(const[e,t]of(0,d.X)(this.m_destroyComps)){const t=e
0==t.IsDestroyed()&&(t.Destroy(),t.m_Destroyed=!0)}if(this.m_destroyComps=null,this.m_clearCompsCache=null,null!=this.m_destroyUIObjComps)for(const[e,t]of(0,
d.X)(this.m_destroyUIObjComps)){const t=e
0==t.IsDestroyed()&&(t.Destroy(),UIResMgr.DestroyUIObj(t),t.m_Destroyed=!0)}this.m_destroyUIObjComps=null,this.m_selfTarget=null}selfTarget_set(e){this.m_selfTarget=e}
SetInterval(e,t,i){null==i&&(i=-1)
const n=c.C.Inst_get().SetInterval(e,t,i)
return this.AddTimerId(n),n}SetIntervalByCurId(e,t,i,n){if(e>0)return e
return this.SetInterval(t,i,n)}SetIntervalForParm(e,t,i,n){null==i&&(i=-1)
const s=c.C.Inst_get().SetIntervalForParm(e,t,i,n)
return this.AddTimerId(s),s}SetFrameLoop(e,t,i){const n=c.C.Inst_get().SetFrameLoop(e,t,i)
return this.AddTimerId(n),n}SetFrameLoopForParm(e,t,i,n){const s=c.C.Inst_get().SetIntervalForParm(e,t,i,n)
return this.AddTimerId(s),s}ClearInterval(e){return this.ClearTimerId(e)}AddTimerId(e){null==this.m_timerIds&&(this.m_timerIds={}),this.m_timerIds[e]=!0}ClearTimerId(e){
return null==e?0:e<=0?e:(null!=this.m_timerIds&&(this.m_timerIds[e]=null),c.C.Inst_get().ClearInterval(e),0)}AddTimerKeyWrap(e){
null==this.m_timerKeyWraps&&(this.m_timerKeyWraps={}),this.m_timerKeyWraps[e]=!0}AddRedPointTipObj(e,t,i){null==this.m_clearRedPoint&&(this.m_clearRedPoint={}),null==i&&(i=0),
l.f.Inst.GetData(e).AddtipObj(t,i,!0),this.m_clearRedPoint[t]=[e,i]}AddClearComponent(e,t,i){null==t&&(t=!0),null==i&&(i=!1),null==this.m_clearComps&&(this.m_clearComps={}),
this.m_clearComps[e]=!0,t&&(i?(null==this.m_destroyUIObjComps&&(this.m_destroyUIObjComps=setmetatable({},_)),
this.m_destroyUIObjComps[e]=!0):(null==this.m_destroyComps&&(this.m_destroyComps=setmetatable({},_)),this.m_destroyComps[e]=!0))}AddClearObj(...e){
null==this.m_clearObjs&&(this.m_clearObjs={})
for(let t=1;t<=select("#",...e);t++){const i=select(t,...e)
this.m_clearObjs[i]=!0}}AddClearComponentParams(e,t,...i){null==e&&(e=!0),null==t&&(t=!1),null==this.m_clearComps&&(this.m_clearComps={})
for(let n=1;n<=select("#",...i);n++){const s=select(n,...i)
this.m_clearComps[s]=!0,e&&(t?(null==this.m_destroyUIObjComps&&(this.m_destroyUIObjComps=setmetatable({},_)),
this.m_destroyUIObjComps[s]=!0):(null==this.m_destroyComps&&(this.m_destroyComps=setmetatable({},_)),this.m_destroyComps[s]=!0))}}AddClearComponentAlwaysCache(e,t,i){
null==t&&(t=!0),null==i&&(i=!1),null==this.m_clearCompsCache&&(this.m_clearCompsCache=setmetatable({},_)),this.m_clearCompsCache[e]=!0,
t&&(i?(null==this.m_destroyUIObjComps&&(this.m_destroyUIObjComps=setmetatable({},_)),
this.m_destroyUIObjComps[e]=!0):(null==this.m_destroyComps&&(this.m_destroyComps=setmetatable({},_)),this.m_destroyComps[e]=!0))}AddClearFunc(e){
null==this.m_clearFuns&&(this.m_clearFuns={}),this.m_clearFuns[e]=!0}RemoveTimerId(e){null!=this.m_timerIds&&(this.m_timerIds[e]=null)}RemoveTimerKeyWrap(e){
null!=this.m_timerKeyWraps&&(this.m_timerKeyWraps[e]=null)}RemoveClearComponent(e,t){null==t&&(t=!0),null!=this.m_clearComps&&(this.m_clearComps[e]=null),
t&&null!=this.m_destroyComps&&(this.m_destroyComps[e]=null)}RemoveClearFunc(e){null!=this.m_clearFuns&&(this.m_clearFuns[e]=null)}RedPointAddCallback(e,t){
null==this.m_redPointFuncs&&(this.m_redPointFuncs={})
let i=this.m_redPointFuncs[e]
null==i&&(i=a.E.CreateWeakTable(!0,!1),this.m_redPointFuncs[e]=i),null==i[t]&&(l.f.Inst.AddCallback(e,t),i[t]=!0)}RedPointRemoveCallback(e,t){if(null==this.m_redPointFuncs)return
const i=this.m_redPointFuncs[e]
null!=i&&null!=i[t]&&(l.f.Inst.RemoveCallback(e,t),i[t]=null)}AddNotifyEvent(e,t,i,s,l,a,r){if(null==i)return void I.Y.LogError("传入回调空")
null==this.m_notifyHandlers&&(this.m_notifyHandlers=new o.y)
let h=null
this.m_notifyHandlers.LuaDic_ContainsKey(e)&&(h=this.m_notifyHandlers.LuaDic_GetItem(e).LuaDic_GetItem(t)),h||(h=n.X.new(),
this.m_notifyHandlers.LuaDic_ContainsKey(e)||this.m_notifyHandlers.LuaDic_AddOrSetItem(e,n.X.new()),this.m_notifyHandlers.LuaDic_GetItem(e).LuaDic_AddOrSetItem(t,h))
;(function(e,t){for(const[i,n]of(0,d.X)(e))if(n==t)return!1
return e.LuaDic_AddOrSetItem(e.Count(),t),!0})(h,i)&&e.AddEventHandler(t,i,s,l,a,r)}RemoveNotifyEvent(e,t,i){if(null==i||null==this.m_notifyHandlers)return
let n=null
if(this.m_notifyHandlers.LuaDic_GetItem(e)&&(n=this.m_notifyHandlers.LuaDic_GetItem(e).LuaDic_GetItem(t)),n){const s=function(e,t){if(!e)return-1
for(const[i,n]of(0,d.X)(e))if(n==t)return i
return-1}(n,i)
null!=n.LuaDic_GetItem(s)&&(n.LuaDic_Remove(s),e.RemoveEventHandler(t,i))}}AddEventMgr(e,t,i,n,s,l){this.AddNotifyEvent(u.i.Inst,e,t,i,n,s,l)}RemoveEventMgr(e,t){
this.RemoveNotifyEvent(u.i.Inst,e,t)}GetListener(e){return e._type_==LuaGameObject?LuaUIEventListener.Get(e):LuaUIEventListener.Get(e.node)}GetListenerStraight(e){
return e._type_==LuaGameObject?e.__listener:e.node.__listener}AddClickEvent(e,t){if(null==t)return;((0,h.t2)(e,s.Node)?e:e.node).on(s.NodeEventType.TOUCH_END,t)}
RemoveClickEvent(e,t){if(null==t)return;((0,h.t2)(e,s.Node)?e:e.node).off(s.NodeEventType.TOUCH_END,t)}AddPressEvent(e,t){if(null==t)return;((0,
h.t2)(e,s.Node)?e:e.node).on(s.NodeEventType.TOUCH_START,t)}RemovePressEvent(e,t){if(null==t||null==this.m_compHandlers)return;((0,
h.t2)(e,s.Node)?e:e.node).off(s.NodeEventType.TOUCH_START,t)}AddSelectEvent(e,t){if(null==t)return
null==this.m_compHandlers&&(this.m_compHandlers={})
const i=p.GetListener(e)
null==a.E.GetValue2(this.m_compHandlers,p.HandlerType_Select,i)&&(i.RegistonSelect(t),a.E.SetValue(this.m_compHandlers,t,!0,p.HandlerType_Select,i))}RemoveSelectEvent(e,t){
if(null==t||null==this.m_compHandlers)return
const i=p.GetListenerStraight(e)
if(null==i)return
null!=a.E.GetValue2(this.m_compHandlers,p.HandlerType_Select,i)&&(i.RemoveonSelect(t),a.E.SetValue(this.m_compHandlers,null,!1,p.HandlerType_Select,i))}RegUIShowDic(e,t){
this.uIShortCutType=e,INS.uIShowShortCut.RegUIShowDic(e,t)}RegGuide(e,t){null==this.m_guideObjs&&(this.m_guideObjs={}),null==this.m_guideObjs[e]?(this.m_guideObjs[e]=t,
GuideManager.Inst.RegGameObject(e,t)):I.Y.LogError(`can add same guide ${e}`)}UnRegGuide(e){null!=this.m_guideObjs&&null!=this.m_guideObjs[e]&&(this.m_guideObjs[e]=null,
GuideManager.Inst.UnRegGameObject(e))}Test1(){return!0}S_Test(){return!0}}p.HandlerType_Click=1,p.HandlerType_BeforeClick=2,p.HandlerType_AfterClick=3,p.HandlerType_DoubleClick=4,
p.HandlerType_Select=5,p.HandlerType_OnPress=6,p.s_instancePool=new r.Z},60130:(e,t,i)=>{i.d(t,{O:()=>N})
var n,s,l=i(18998),a=i(87234),r=i(85688),o=i(21370),d=i(42292),h=i(78175),u=i(1240),c=i(75696),I=i(92679),_=i(48933),p=i(21987),S=i(37648),g=i(48481),m=i(63945),f=i(40621),C=i(62734),T=i(70857),y=i(98130),A=i(85602),P=i(52212),w=i(79534),R=i(99942),D=i(8125),L=i(77546),E=i(38836),B=i(38045),M=i(97461),G=i(96617),O=i(5924),U=i(66788),b=i(4338),F=i(18202),k=i(31222),v=i(5494)
let N=(0,d.Y_)("GameSys.LuaUIUtil")((s=class e{static _SwitchNotchTest(){
e._EditorTestAnchor?0==e._EditorTestAnchorLeft?e._EditorTestAnchor=!1:e._EditorTestAnchorLeft=!1:(e._EditorTestAnchor=!0,e._EditorTestAnchorLeft=!0),e.InitCsData()}
static InitCsData(){e._EditorTestAnchor=!1,D.T.SetUseNotchView(e.UseNotchView,e._EditorTestAnchor)}static _InitUIDatas(){const t=l.sys.getSafeAreaRect()
e.ScreenWidth=l.view.getVisibleSize().x-t.x,e.ScreenHeight=l.view.getVisibleSize().y-t.y,e.UIScreenLeft=-e.ScreenWidth/2,e.UIScreenRight=e.ScreenWidth/2,
e.UIScreenTop=e.ScreenHeight/2,e.UIScreenBottom=-e.ScreenHeight/2,e.UIScreenLeftWithNotch=e.UIScreenLeft,e.UIScreenRightWithNotch=e.UIScreenRight,
e.UIScreenNotchWidth=e.ScreenWidth,e.SafeAreaBottom=e.GetSafeAreaBottom()
const i=e.UIScreenLeftWithNotch!=e.UIScreenLeft||e.UIScreenRightWithNotch!=e.UIScreenRight
if(i&&e.SafeAreaBottom<=30&&(e.SafeAreaBottom=e.UIScreenNotchWidth/e.Pixel2NGUI-30),e.SafeAreaBottom<=0&&(e.SafeAreaBottom=30),
e.UIScreenSafeAreaBottomOffset=y.GF.INT(e.SafeAreaBottom*e.Pixel2NGUI),e.HasNotch=i,e.IsNotchAtLeft=e.UIScreenLeftWithNotch!=e.UIScreenLeft,
e.UIScreenNotchWidthLeft=e.UIScreenLeftWithNotch-e.UIScreenLeft,e.UIScreenNotchWidthRight=-e.UIScreenRightWithNotch+e.UIScreenRight,
e.UIScreenNotchWidth=e.UIScreenNotchWidthLeft>e.UIScreenNotchWidthRight&&e.UIScreenNotchWidthLeft||e.UIScreenNotchWidthRight,e.UIScreenNotchWidthSrc=e.UIScreenNotchWidth,
e.UIScreenWidth=e.UIScreenRight-e.UIScreenLeft,e.UIScreenHeight=e.UIScreenTop-e.UIScreenBottom,e.UIScreenWidthSrc=e.UIScreenWidth,e.UIScreenHeightSrc=e.UIScreenHeight,
e.UseNotchView){let t=e.UIScreenNotchWidthSrc/2
t=e.IsNotchAtLeft&&-t||t,e.UIScreenLeftWithNotch+=t,e.UIScreenRightWithNotch+=t,e.UIScreenWidth-=e.UIScreenNotchWidthSrc,e.UIScreenLeft=e.UIScreenLeftWithNotch,
e.UIScreenRight=e.UIScreenRightWithNotch,e.UIScreenNotchWidth=0,e.UIScreenNotchWidthLeft=0,e.UIScreenNotchWidthRight=0}if(e.UIScreenWidthSrc=y.GF.INT(e.UIScreenWidthSrc),
e.UIScreenHeightSrc=y.GF.INT(e.UIScreenHeightSrc),e.UIScreenWidth=y.GF.INT(e.UIScreenWidth),e.UIScreenHeight=y.GF.INT(e.UIScreenHeight),
e.UIScreenNotchWidth=y.GF.INT(e.UIScreenNotchWidth),e.UIScreenNotchWidthSrc=y.GF.INT(e.UIScreenNotchWidthSrc),e._LogCount<=1){e._LogCount+=1
const t=`LuaUIUtil._InitUIDatas \n_M.UseNotchView = \t\t\t\t\t${(0,B.tw)(e.UseNotchView)}\n_M.ScreenWidth = \t\t\t\t\t${e.ScreenWidth}\n_M.ScreenHeight = \t\t\t\t\t${e.ScreenHeight}\n_M.UIScreenWidth = \t\t\t\t${e.UIScreenWidth}\n_M.UIScreenHeight = \t\t\t\t${e.UIScreenHeight}\n_M.UIScreenLeft = \t\t\t\t\t${e.UIScreenLeft}\n_M.UIScreenRight = \t\t\t\t${e.UIScreenRight}\n_M.UIScreenTop = \t\t\t\t\t${e.UIScreenTop}\n_M.UIScreenBottom = \t\t\t\t${e.UIScreenBottom}\n_M.UIScreenLeftWithNotch = \t\t${e.UIScreenLeftWithNotch}\n_M.UIScreenRightWithNotch = \t\t${e.UIScreenRightWithNotch}\n_M.UIScreenNotchWidth = \t\t\t${e.UIScreenNotchWidth}\n_M.Pixel2NGUI = \t\t\t\t\t${e.Pixel2NGUI}\n_M.SafeAreaBottom = \t\t\t\t${e.SafeAreaBottom}\n_M.UIScreenSafeAreaBottomOffset = \t${e.UIScreenSafeAreaBottomOffset}\n_M.UIScreenNotchWidthLeft = \t${e.UIScreenNotchWidthLeft}\n_M.UIScreenNotchWidthRight = \t${e.UIScreenNotchWidthRight}\n_M.SafeAreaBottomSrc = \t${e.GetSafeAreaBottom()}\n_M.UIScreenNotchWidthSrc = \t${e.UIScreenNotchWidthSrc}`
L.s.Info(t)}M.i.Inst.AddEventHandler(I.g.UPDATE_ANCHORS,e._OnUpdateAnchors)}static ResetAnchorPos(t,i){e.SetAnchorPos(t,i,!0,0,!1)}static _OnUpdateAnchors(){for(const[t,i]of(0,
E.X)(e.s_allListenerAnchors))t.IsObjectExist()&&e.SetAnchorPos(t,i.isLeft,i.withNotch,i.topOrCenterOrBottom,i.withSafeArea,!1)}static SetAnchorPos(t,i,n,s,l,a,r,o){
if(null==n&&(n=!0),null==s&&(s=0),null==l&&(l=!1),null==a&&(a=!1),a){let a=e.s_allListenerAnchors[t]
null==a&&(a={},e.s_allListenerAnchors[t]=a),a.isLeft=i,a.withNotch=n,a.topOrCenterOrBottom=s,a.withSafeArea=l}let d=0,h=0
const u=null==i
if(u||(d=n?i?e.UIScreenLeftWithNotch:e.UIScreenRightWithNotch:i?e.UIScreenLeft:e.UIScreenRight),1==s?h=360:-1==s?h=-360:2==s?h=e.UIScreenTop:-2==s&&(h=e.UIScreenBottom),l&&!u){
const t=e.HasNotch,l=e.IsNotchAtLeft
let a=!1
if(0!=s&&(t&&n&&(i&&l||!i&&!l)||(e.UIScreenTop>360&&2!=s&&-2!=s||(a=!0),a&&e.UseNotchView&&e.HasNotch&&i==e.IsNotchAtLeft&&(a=!1))),a){let t=e.UIScreenSafeAreaBottomOffset
t/=2,d+=i&&t||-t,h+=s>0&&-t||t}}d=y.GF.INT(d),h=y.GF.INT(h),null!=r&&(d+=r),null!=o&&(h+=o),t.SetLocalPositionXYZ(d,h,0)}static GetUIWidth(){return e.UIScreenWidth}
static GetUIHeight(){return e.UIScreenHeight}static GetUICanvasSize(){const e=l.director.getScene().getChildByName("UICanvas")
return e?e.transform.contentSize:l.screen.windowSize}static GetSafeAreaBottom(){return 0}static WorldToUILocalPos(e,t,i){const n=G.A.Vector3ToFloatArray(e)
D.T.WorldToUILocalPosByGo(A.Z.GetTableOrNilFromLua(n),t.FatherId,t.ComponentId,i.FatherId,i.ComponentId)}static WorldToUILocalPosRelative(e,t){
return D.T.WorldToUILocalPosRelative(e.x,e.y,e.z,t.FatherId,t.ComponentId)}static WorldToUILocalPosInHeadPanel(e,t,i,n,s){null!=s&&(t+=s),n.SetLocalPositionXYZ(e,t,i)}
static FlyToPosTween(e,t){D.T.FlyToPosTweenClone(e.FatherId,e.ComponentId,t.FatherId,t.ComponentId)}static GetRelateMousePiont(e){
return D.T.GetRelateMousePiont(e.FatherId,e.ComponentId)}static FlyItemToPos(t,i,n,s){const l=new g.t
l.modelId=t,l.num=i
const a=new u.Y
a.serverData_set(l),e.FlyItemToPos_bagItemData=a,e.FlyItemToPos_toX=n,e.FlyItemToPos_toY=s,F.g.LoadOne("ui_baseitem",e.FlyItemToPosLoadComplete)}static FlyItemToPosLoadComplete(t){
const i=new c.j
i.setId(t[0],null,0),i.SetData(e.FlyItemToPos_bagItemData.baseData_get()),D.T.FlyToPosTween(i.FatherId,i.ComponentId,e.FlyItemToPos_toX,e.FlyItemToPos_toY)}FlyToPosTweenArr(e,t){
const i=e.count,n=new A.Z(i),s=new A.Z(i)
let l=0
for(;l<i;)n[l]=e[l].FatherId,s[l]=e[l].ComponentId,l+=1
D.T.FlyToPosTweenArrClone(A.Z.GetTableOrNilFromLua(n),A.Z.GetTableOrNilFromLua(s),t.FatherId,t.ComponentId)}static makeGoGray(e,t){(0,h.FJ)(e,t)}ShakeGo(e,t){
D.T.ShakeGo(e.FatherId,e.ComponentId,t)}static WorldPosToLayoutLocalPos(e,t,i,n){let s=new w.P
return s=D.T.WorldToLocalMatrixMultiplyPoint3x4(i,s),s}static WorldPosToLayoutLocalPosQuick(e,t){return D.T.WorldPosToLayoutLocalPosQuick(e.x,e.y,t)}SetLogPlayerID(e){
D.T.SetLogPlayerID(e.low_get(),e.high_get())}static SetLayerVisible(e,t,i,n){r.n.ins.setLayerVisible(e,t)}LayerIsShowInCamera(e,t,i){
D.T.LayerIsShowInCamera(e,t,A.Z.GetTableOrNilFromLua(i))}GameObjectIsShowInCamera(e,t){D.T.nodeIsShowInCamera(e,t)}BindActiveAndChangeParent(e,t,i){null==i&&(i=!0),
D.T.BindActiveAndChangeParent(e.FatherId,e.ComponentId,t.FatherId,t.ComponentId,i)}BindActiveSetValue(e,t){D.T.BindActiveSetValue(e.FatherId,e.ComponentId,t)}
SetPanelOffsetByItem(e,t,i){D.T.SetPanelOffsetByItem(e.FatherId,e.ComponentId,t.FatherId,t.ComponentId,i)}static AddUIEffectSortOrderBind(e,t){null==t&&(t=!1),
D.T.AddUIEffectSortOrderBind(e.FatherId,e.ComponentId,t)}UIEffectSortOrderAddChild(e,t){D.T.UIEffectSortOrderAddChild(e.FatherId,e.ComponentId,t.FatherId,t.ComponentId)}
UIEffectSortOrderUpdateRenderList(e){D.T.UIEffectSortOrderUpdateRenderList(e.FatherId,e.ComponentId)}static SetGuidePanelParent(e,t,i=null){if(null==i&&(i=!1),
D.T.SetGuideAutoPositionState(e,t,!0),i=!0){let i=t,n=i.parent
for(;n&&"guide_parent"!=i.name;){let e=i.getChildByName("guide_parent")
if(e){i=e
break}if(n.getComponent(a.F))break
i=n,n=n.parent}e.parent=i}else e.parent=r.n.ins.node.getChildByName((0,o.L)(o.T.guide))
e.scale=new l.Vec3(1,1,1)}static SetFunctionGuidePanelParent(e,t,i){null==t&&(t=!0)
e.worldPosition
e.parent=r.n.ins.node.getChildByName((0,o.L)(o.T.guide)),e.scale=new l.Vec3(1,1,1),e.SetActive(!0),D.T.SetGuideAutoPositionState(e,i,!0)}static SetGuideAutoPositionState(e,t,i){
null==i&&(i=!1),D.T.SetGuideAutoPositionState(e,t,i)}static SetGuideFixedPositionState(e,t){null==t&&(t=!1)
let i=e.getComponent(R.a)
null!=i&&(i.IsFixedPos=t)}static GetBoxCollider2DSize(e){let t=new A.Z
return t.push(e.transform.width),t.push(e.transform.height),t}ResetParticleSystem(e){D.T.ResetParticleSystem(e.FatherId,e.ComponentId)}SetChildsSpriteDepth(e,t){
D.T.SetChildsSpriteDepth(e.FatherId,e.ComponentId,t)}SetServerState(e,t,i){
null!=e&&(t==T.Y.ServerStateNormal?i?e.spriteNameSet("rydenglu_sp_0022"):e.spriteNameSet("rydenglu_sp_0011"):t==T.Y.ServerStateBusy?i?e.spriteNameSet("rydenglu_sp_0014"):e.spriteNameSet("rydenglu_sp_0010"):t==T.Y.ServerStateCrowd?i?e.spriteNameSet("rydenglu_sp_0021"):e.spriteNameSet("rydenglu_sp_0009"):(t==T.Y.ServerStateClose||t==T.Y.ServerStateNotCreate)&&(i?e.spriteNameSet("rydenglu_sp_0023"):e.spriteNameSet("rydenglu_sp_0012")))
}static CloseSecondayView(){m.x.inst.CloseGetAuctionPanel(),p.N.Inst_get().CloseFriendAddView(),p.N.Inst_get().CloseFriendReqListView(),k.N.inst.CloseById(v.I.PassiveTalentPanel)}
SetTabGridUseNeedRedpointRule(e){e&&e.itemList||U.Y.LogError("grid must be LuaMyUIGrid")
const t=e.itemList.Count()
for(let i=0;i<=t-1;i++){e.itemList[i].useNewRedpointRule=!0}}SetTabItemListNeedRedpointRule(e){e||U.Y.LogError("itemList must be not nil")
const t=e.Count()
for(let i=0;i<=t-1;i++){e[i].useNewRedpointRule=!0}}static GetConstrainOffset(e,t,i){_.I.calVec0.Set(0,0,0)
const n=t.transform.TransformPoint(_.I.calVec0),s=e.node.transform.convertToNodeSpaceAR(n),l=t.transform.contentSize,a=new P.F,r=new P.F
a.Set(s.x,s.y-l.y),r.Set(s.x,s.y)
return new w.P(a.x,a.y,0)}static PlayPositionTween(e,t,i,n,s=0,a=null,r=null){if(null!=e&&(s=s||0,n=new l.Vec3(n.x,n.y,n.z),e.setPosition(i),(0,l.tween)(e).delay(s).to(t,{x:n.x,
y:n.y}).start(),null!=a)){const e=5+1e3*t+1e3*s
null!=r?O.C.Inst_get().SetIntervalForParm(a,e,1,r):O.C.Inst_get().SetInterval(a,e,1)}}PlayRotationTween(e,t,i,n,s,l,a){if(null!=e&&(s=s||0,
b.z.Begin(e.FatherId,e.ComponentId,t,i,n,s),null!=l)){const e=5+1e3*t+1e3*s
null!=a?O.C.Inst_get().SetIntervalForParm(l,e,1,a):O.C.Inst_get().SetInterval(l,e,1)}}static PlayNormalCloseTween(t,i,n=null){if(null!=t&&null!=i){const t=5+1e3*e.NormalDuration+0
null!=n?O.C.Inst_get().SetIntervalForParm(i,t,1,n):O.C.Inst_get().SetInterval(i,t,1)}}static RestrictGameObjToScrollPanel(t,i,n){if(n){const e=t.GetViewSize()
let n=t.node.GetBoundsSize().y-e.y+2*t.clipSoftness().y,s=t.node.transform.GetLocalPosition()
n<0&&(n=0)
const l=-s.y+e.y/2
_.I.calVec0.Set(0,0,0)
const a=i.transform.TransformPoint(_.I.calVec0),r=t.node.transform.InverseTransformPoint(a)
let o=s.y+(l-r.y)
o>n&&(o=n),s=t.node.transform.GetLocalPosition()
const d=t.clipOffset(),h=o-s.y
s.y=o,d.y-=h,t.node.transform.SetLocalPosition(s),t.clipOffsetSet(d)}else{const s=e.GetConstrainOffset(t,i,n)
if(s.SqrMagnitude()>.1){const e=t.node.transform.GetLocalPosition(),i=t.clipOffset()
e.x+=s.x,e.y+=s.y,i.x-=s.x,i.y-=s.y,t.node.transform.SetLocalPosition(e),t.clipOffsetSet(i)}}}static ScrollToIndex(e,t,i,n,s,l,a){return a=a||100,O.C.Inst_get().SetInterval((()=>{
if(null==t||null==e)return
0==t.data_get().Count()&&e.SetValue(0)
let l=1
t.MaxPerLine_get()>0&&(l=t.MaxPerLine_get())
let a=t.data_get().Count()
a%l!=0&&(a=a-a%l+l)
let r=i+1
if(null==n&&(n=l),r%l!=0&&(r=r-r%l+l),a<=n)return void e.SetValue(0)
let o=(r-n)/(a-n)
null==s&&(s=!0),s&&(o+=(n-l)/(a-n)),e.SetValue(o)}),a,1)}ScrollToItemByScrollBar(e,t,i,n,s){const l=e.GetViewSize().y,a=i-l
if(a>0){const e=t.GetValue()
if(s>l+e*a||n<0+e*a){let e=s-l
e<0&&(e=0)
let i=e/a
i>1?i=1:i<0&&(i=0),t.SetValueForce(i)}}}static GetSelectedIndex(e,t,i){const n=S.P.Inst_get()
if(null!=e&&-1!=e)return e
let s=0
if(null==t||0==t.Count())return s
let l=-1
if(null!=i)for(let e=0;e<=i.Count()-1;e++){if(null!=i[e]){n.IsFunctionOpened(i[e])&&-1==l&&(l=s)}else-1==l&&(l=s)
s+=1}s=0
for(const[e,i]of(0,E.V5)(t)){if(i>0){const e=C.f.Inst.GetData(i)
let t=!0
const a=f.c.inst.GetFunIdByRedPointId(i)
if(-1!=a&&(t=n.IsFunctionOpened(a)),t&&-1==l&&(l=s),t&&e&&e.show)return s}else-1==l&&(l=s)
s+=1}return-1==l&&(l=0),l}},s._EditorTestAnchor=!1,s._EditorTestAnchorLeft=!0,s.UseNotchView=!0,s.ScreenWidth=0,s.ScreenHeight=0,s.UIScreenWidth=0,s.UIScreenHeight=0,
s.UIScreenWidthSrc=0,s.UIScreenHeightSrc=0,s.UIScreenLeft=0,s.UIScreenRight=0,s.UIScreenTop=360,s.UIScreenBottom=-360,s.UIScreenLeftWithNotch=0,s.UIScreenRightWithNotch=0,
s.UIScreenNotchWidthLeft=0,s.UIScreenNotchWidthRight=0,s.NotchWidth=0,s.UIScreenNotchWidth=0,s.UIScreenNotchWidthSrc=0,s.Pixel2NGUI=1,s.SafeAreaBottom=0,
s.UIScreenSafeAreaBottomOffset=0,s.HasNotch=!1,s.IsNotchAtLeft=!0,s._LogCount=0,s.s_allListenerAnchors={},s.worldToUILocalPosFloatArr=null,s.FlyItemToPos_bagItemData=null,
s.FlyItemToPos_toX=0,s.FlyItemToPos_toY=0,s.NormalDuration=.2,s.NormalFormvec=new w.P(0,0,0),s.NormalTovec=new w.P(0,0,-90),n=s))||n
N._InitUIDatas()},83540:(e,t,i)=>{i.d(t,{b:()=>n})
var n={eItem:0,eSkill:1,eEquip:2,eBuff:3,eNotify:4,eFace:5,eSaoguang:6,eRebirthTalent:7,eEquipRefineAttr:8,eTitle:9,eTechnology:10,eDrop:11,eRyCommon:100,eHorse:101}},
43133:(e,t,i)=>{i.d(t,{V:()=>o})
var n,s=i(18998),l=i(52212),a=i(30849)
const{ccclass:r}=s._decorator
let o=r("LuaBoxCollider2DQuick")(n=class extends a.C{offset(){return new l.F}offsetSet(e){}size(){return new l.F}sizeSet(e){}OverlapPoint(e){return!0}SetThrough(e){}})||n},
84193:(e,t,i)=>{i.d(t,{n:()=>s})
var n=i(30849)
class s extends n.C{SetTxt(e){ChatFaceLabelBridge.SetTxt(this.FatherId,this.ComponentId,e)}SetCommonTxt(e){ChatFaceLabelBridge.SetCommonTxt(this.FatherId,this.ComponentId,e)}
SetIsFaceXReturn(e){ChatFaceLabelBridge.SetIsFaceXReturn(this.FatherId,this.ComponentId,e)}LineNum(){return ChatFaceLabelBridge.GetLineNum(this.FatherId,this.ComponentId)}Clear(){
ChatFaceLabelBridge.Clear(this.FatherId,this.ComponentId)}Destory(){ChatFaceLabelBridge.Destory(this.FatherId,this.ComponentId)}CalculateTxtSize(e,t,i){
return ChatFaceLabelBridge.CalculateTxtSize(this.FatherId,this.ComponentId,e,t,i)}GetSize(){return ChatFaceLabelBridge.GetSize(this.FatherId,this.ComponentId)}
CalculateSingleLineX(e,t){return ChatFaceLabelBridge.CalculateSingleLineX(this.FatherId,this.ComponentId,e,t)}StripSymbols(e){
return ChatFaceLabelBridge.StripSymbols(this.FatherId,this.ComponentId,e)}}},62063:(e,t,i)=>{i.d(t,{U:()=>o})
var n=i(91037),s=i(81266),l=i(38836),a=i(75309),r=i(30849)
class o extends r.C{AddHandle(e,t,i,n,l,r){const d=s.E.GetValue3(o.callbackIdDic,e,t,i)
if(null!=d){if(d[1]==n)return d[2]
a.n.RemoveCallBackEventCallback(d[2]),l(t,i)}const h=a.n.AddCallBackEventCallback(n)
return s.E.SetValue(o.callbackIdDic,[n,h],!0,e,t,i),r(t,i,h),null}RemoveHandler(e,t,i,n,l){const r=s.E.GetValue3(o.callbackIdDic,e,t,i)
if(null!=r&&r[1]==n){a.n.RemoveCallBackEventCallback(r[2]),l(t,i),s.E.SetValue(o.callbackIdDic,null,!1,e,t,i)
const n=s.E.GetValue2(o.callbackIdDic,e,t)
null!=n&&0==s.E.HasValue(n)&&s.E.SetValue(o.callbackIdDic,null,!1,e,t)}return null}CheckAllDelegate(){for(const[e,t]of(0,l.X)(o.callbackIdDic))for(const[e,i]of(0,
l.X)(t))for(const[e,t]of(0,l.X)(i))n.Z.CheckDelegateTarget(t[1])}AddEventToFinishedHandler(e,t,i){
o.AddHandle(o._sHandlerTypeFinish,e,t,i,EventDelegateBridge.RemoveEventFromFinishedHandler,EventDelegateBridge.AddEventToFinishedHandler)}RemoveEventFromFinishedHandler(e,t,i){
o.RemoveHandler(o._sHandlerTypeFinish,e,t,i,EventDelegateBridge.RemoveEventFromFinishedHandler,EventDelegateBridge.AddEventToFinishedHandler)}AddEventToChangeHandler(e,t,i){
o.AddHandle(o._sHandlerTypeChange,e,t,i,EventDelegateBridge.RemoveEventFromChangeHandler,EventDelegateBridge.AddEventToChangeHandler)}RemoveEventFromChangeHandler(e,t,i){
o.RemoveHandler(o._sHandlerTypeChange,e,t,i,EventDelegateBridge.RemoveEventFromChangeHandler,EventDelegateBridge.AddEventToChangeHandler)}AddEventInputChangeHandler(e,t,i){
o.AddHandle(o._sHandlerTypeInputChange,e,t,i,EventDelegateBridge.RemoveEventInputChangeHandler,EventDelegateBridge.AddEventInputChangeHandler)}RemoveEventInputChangeHandler(e,t,i){
o.RemoveHandler(o._sHandlerTypeInputChange,e,t,i,EventDelegateBridge.RemoveEventInputChangeHandler,EventDelegateBridge.AddEventInputChangeHandler)}}o.callbackIdDic={},
o._sHandlerTypeFinish=1,o._sHandlerTypeChange=2,o._sHandlerTypeInputChange=3},99294:(e,t,i)=>{i.d(t,{z:()=>a})
var n=i(79534),s=i(60069)
let l=null
class a extends s.r{constructor(...e){super(...e),this.transform=null}static __StaticInit(){l=new n.P(0,0,0)}_initBinder(){super._initBinder(),this.transform=this}}},
64732:(e,t,i)=>{i.d(t,{f:()=>S})
var n,s,l,a=i(92679),r=i(85602),o=i(38836),d=i(97461),h=i(30849),u=i(18202),c=i(96617)
class I{SetData(e,t,i){if(null!=i){I.offset.Clear(),I.id.Clear(),I.parentID.Clear(),I.name.Clear(),I.expand.Clear()
let e=0
for(;e<i.Count();)I.offset.Add(i[e].offset),I.id.Add(i[e].id),I.parentID.Add(i[e].parentID),I.name.Add(i[e].name),I.expand.Add(i[e].expand),e+=1}
const n=MyTreeBridge.SetData(e,t,r.Z.GetTableOrNilFromLua(I.offset.GetLuaToArray()),r.Z.GetTableOrNilFromLua(I.id.GetLuaToArray()),r.Z.GetTableOrNilFromLua(I.parentID.GetLuaToArray()),r.Z.GetTableOrNilFromLua(I.name.GetLuaToArray()),r.Z.GetTableOrNilFromLua(I.expand.GetLuaToArray()))
return c.A.ArrayToCList(n,!0)}ResetScrollViewPos(e,t){MyTreeBridge.ResetScrollViewPos(e,t)}}I.offset=new r.Z,I.id=new r.Z,I.parentID=new r.Z,n=I,s="name",l=new r.Z,(s=function(e){
var t=function(e,t){if("object"!=typeof e||null===e)return e
var i=e[Symbol.toPrimitive]
if(void 0!==i){var n=i.call(e,t||"default")
if("object"!=typeof n)return n
throw new TypeError("@@toPrimitive must return a primitive value.")}return("string"===t?String:Number)(e)}(e,"string")
return"symbol"==typeof t?t:String(t)}(s))in n?Object.defineProperty(n,s,{value:l,enumerable:!0,configurable:!0,writable:!0}):n[s]=l,I.expand=new r.Z
var _=i(70707),p=i(57834)
class S extends h.C{constructor(){super(),this.itemTitleList=null,this.itemList=null,this.dataList=null,this.itemIndex=0,this.itemTitleIndex=0,this.itemChildIndex=0,
this.treeTitleItemName=null,this.treeItemName=null,this.curTreeData=null,this.titleItemIdList=null,this.itemIdList=null,this.createLuaTitleItem=null,this.createLuaItem=null,
this.OnSelect=null,this.notifier=null,this._degf_TreeItemClickHandler=null,this.notifier=new _.k,this._degf_TreeItemClickHandler=(e,t)=>this.TreeItemClickHandler(e,t)}
SetTreeItemDelegate(e,t){this.createLuaTitleItem=e,this.createLuaItem=t}SetTitleAndItemName(e,t){this.treeTitleItemName=e,this.treeItemName=t,
MyTreeBridge.SetTitleAndItemName(this.FatherId,this.ComponentId,e,t)}SetData(e){const t=I.SetData(this.FatherId,this.ComponentId,e)
if(null!=t){this.titleItemIdList=new r.Z,this.itemIdList=new r.Z
let e=!0,i=0
for(;i<t.Count();)-1==t[i]&&(e=!1),e?this.titleItemIdList.Add(t[i]):-1!=t[i]&&this.itemIdList.Add(t[i]),i+=1}this.InitItemList(),this.dataList=e,
this.whileItem("0",this.GetChildrenDataList("0")),this.ChangeTreeSelect(this.curTreeData,!1),I.ResetScrollViewPos(this.FatherId,this.ComponentId),
d.i.InstRaiseEvent(a.g.TREE_SHOWNUM_CHENGE)}InitItemList(){if(this.itemIndex=0,this.itemTitleIndex=0,this.itemChildIndex=0,null==this.itemList&&(this.itemList=new r.Z),
this.itemList.Count()>0)for(const[e,t]of(0,o.V5)(this.itemList))t.node.SetActive(!1)
if(null==this.itemTitleList&&(this.itemTitleList=new r.Z),this.itemTitleList.Count()>0)for(const[e,t]of(0,o.V5)(this.itemTitleList))t.node.SetActive(!1)}whileItem(e,t){
const i=this.GetItemData(e)
let n=0
null!=i&&(n=i.level+1)
for(const[e,i]of(0,o.V5)(t)){if(this.itemIndex+=1,i.level=n,0==n){this.itemTitleIndex+=1
const e=this.CreateTreeTitleItem(this.itemTitleIndex)
e.node.SetActive(!0)
const t=this.GetChildrenDataList(i.id)
e.SetData(i,this.curTreeData,t.Count()>0),p.i.Get(e.node).RegistonClick(this._degf_TreeItemClickHandler)}else{this.itemChildIndex+=1
const e=this.CreateTreeItem(this.itemChildIndex)
e.node.SetActive(!0),e.SetMyTreeData(i),p.i.Get(e.node).RegistonClick(this._degf_TreeItemClickHandler)}if(i.expand){const e=this.GetChildrenDataList(i.id)
null!=e&&e.Count()>0&&this.whileItem(i.id,e)}}}TreeItemClickHandler(e,t){let i=0
if(null!=this.itemTitleList)for(i=0;i<this.itemTitleList.Count();){if(this.itemTitleList[i].FatherId==t)return this.itemTitleList[i].CheckGuide(),
void this.OnItemClickHandler(this.itemTitleList[i].GetMyTreeData())
i+=1}if(null!=this.itemList)for(i=0;i<this.itemList.Count();){if(this.itemList[i].FatherId==t)return this.itemList[i].CheckGuide(),
void this.OnItemClickHandler(this.itemList[i].GetMyTreeData())
i+=1}}ChangeTreeSelect(e,t){if(null==t&&(t=!0),null!=e){this.curTreeData=e
for(const[t,i]of(0,o.V5)(this.itemList))i.GetMyTreeData().id==e.id?i.SetSelected(!0):i.SetSelected(!1)
t&&this.RaiseEvent(a.g.TREE_ITEM_CHENGE,e),null!=this.OnSelect&&this.OnSelect()}}CreateTreeTitleItem(e){let t=null
return e>=0&&null!=this.itemTitleList&&e<=this.itemTitleList.Count()?(t=this.itemTitleList[e-1],
t):null==this.treeTitleItemName?null:(t=this.createLuaTitleItem(this.titleItemIdList[e-1]),this.itemTitleList.Add(t),t)}RecheckRedPoint(){let e=0
for(;e<this.itemTitleList.count;){const t=this.itemTitleList[e],i=this.GetChildrenDataList(t.GetMyTreeData().id)
let n=0,s=!1
for(;n<i.count;){i[n].RecheckRedPoint()&&(s=!0),n+=1}t.ResetRedPoint(s),e+=1}}CreateTreeItem(e){let t=null
return e>=0&&null!=this.itemList&&e<=this.itemList.Count()?(t=this.itemList[e-1],t):null==this.treeItemName?null:(t=this.createLuaItem(this.itemIdList[e-1]),this.itemList.Add(t),t)
}OnItemClickHandler(e){const t=this.GetChildrenDataList(e.id),i=this.GetItemData(e.id)
if(this.RaiseEvent(a.g.TREE_ITEM_CLICK,i),this.GetNeedAutoClose())for(const[t,i]of(0,o.V5)(this.dataList))i.id!=e.id&&(i.expand,i.expand=!1)
if(1==e.level){const t=this.GetItemData(e.parentID)
null!=t&&(t.expand=!0)}if(null!=e&&null!=t&&(t.Count()>0||this.GetNeedAutoClose()&&0==e.level)){if(1==e.expand?i.expand=!1:i.expand=!0,
this.GetNeedAutoClose()&&this.GetNeedAutoCloseSelectOne()&&t.Count()>0)return this.ChangeTreeSelect(t[0]),void this.SetData(this.dataList)
this.curTreeData=e,this.SetData(this.dataList),this.ChangeTreeSelect(e),null!=i&&0==i.level&&this.GetNeedParentEvet()&&this.RaiseEvent(a.g.TREE_ITEM_CHENGE,i)
}else this.ChangeTreeSelect(e)}extendByIndex(e){if(null==e&&(e=0),null!=this.itemTitleList&&e<this.itemTitleList.Count()){const t=this.itemTitleList[e].GetMyTreeData()
t.expand=!1,this.OnItemClickHandler(t)}}extendByName(e){if(null!=this.itemTitleList){let t=0
for(;t<this.itemTitleList.Count();){const i=this.itemTitleList[t].GetMyTreeData()
i.name==e&&(i.expand=!1,this.OnItemClickHandler(i)),t+=1}}}selectByIndex(e){if(null==e&&(e=0),null!=this.itemList&&e<this.itemList.Count()){const t=this.itemList[e].GetMyTreeData()
this.OnItemClickHandler(t)}}selectByIndexNoEvent(e){if(null==e&&(e=0),null!=this.itemList&&e<this.itemList.Count()){const t=this.itemList[e].GetMyTreeData()
this.ChangeTreeSelect(t,!1)}}selectByName(e){if(null!=this.dataList){let t=0
for(;t<this.dataList.Count();){const i=this.dataList[t]
if(i.name==e){const e=this.GetItemData(i.parentID)
null!=e&&(e.expand=!0),i.expand=!0,this.ChangeTreeSelect(i),this.SetData(this.dataList)}t+=1}}}selectById(e){if(null!=this.dataList){let t=0
for(;t<this.dataList.Count();){const i=this.dataList[t]
if(i.id==e){if(this.GetNeedAutoClose())for(const[e,t]of(0,o.V5)(this.dataList))t.id!=i.id&&(t.expand=!1)
const e=this.GetItemData(i.parentID)
null!=e&&(e.expand=!0),i.expand=!0,this.ChangeTreeSelect(i),this.SetData(this.dataList)}t+=1}}}selectByIdAndTitle(e,t){if(null!=this.dataList){let i=0
for(;i<this.dataList.Count();){const n=this.dataList[i]
if(n.id==e&&n.parentID==t){if(this.GetNeedAutoClose())for(const[e,t]of(0,o.V5)(this.dataList))t.id!=n.id&&(t.expand=!1)
const e=this.GetItemData(n.parentID)
null!=e&&(e.expand=!0),n.expand=!0,this.ChangeTreeSelect(n),this.SetData(this.dataList)}i+=1}}}selectById2(e){}hasSelectOne(){if(null!=this.itemList){let e=!1,t=0
for(;t<this.itemList.Count();){if(e=this.itemList[t].GetSelected(),e)return!0
t+=1}}return!1}reset(){if(null!=this.itemList)for(const[e,t]of(0,o.V5)(this.itemList))t.SetSelected(!1)
if(this.curTreeData=null,null!=this.dataList&&this.dataList.Count()>0){let e=0
for(;e<this.dataList.Count();){const t=this.dataList[e]
t.expand=0==e,e+=1}this.SetData(this.dataList)}}reset2(){if(null!=this.itemList)for(const[e,t]of(0,o.V5)(this.itemList))t.SetSelected(!1)
if(this.curTreeData=null,null!=this.dataList&&this.dataList.Count()>0){let e=0
for(;e<this.dataList.Count();){this.dataList[e].expand=!1,e+=1}this.SetData(this.dataList)}}GetChildrenDataList(e){const t=new r.Z
for(const[i,n]of(0,o.V5)(this.dataList))n.parentID==e&&t.Add(n)
return t}GetItemData(e){for(const[t,i]of(0,o.V5)(this.dataList))if(i.id==e)return i
return null}GetTitleItem(e){for(const[t,i]of(0,o.V5)(this.itemTitleList))if(i.GetMyTreeData().id==e)return i
return null}GetItem(e){for(const[t,i]of(0,o.V5)(this.itemList))if(i.GetMyTreeData().id==e)return i
return null}GetAllTitleItem(){return null!=this.itemTitleList?this.itemTitleList:null}GetAllItem(e){const t=new r.Z
for(const[i,n]of(0,o.V5)(this.itemList))n.GetMyTreeData().parentID==e&&t.Add(n)
return t}AddEventHandler(e,t){this.notifier.AddEventHandler(e,t)}RemoveEventHandler(e,t){this.notifier.RemoveEventHandler(e,t)}RaiseEvent(e,t){this.notifier.RaiseEvent(e,t)}
RemoveAllEventHandler(e){this.notifier.RemoveAllEventHandler(e)}Clear(){}Destory(){this.Destroy()}Destroy(){let e=0
if(null!=this.itemList){for(e=this.itemList.Count()-1;e>-1;){const t=this.itemList[e]
p.i.Get(t.node).RemoveonClick(this._degf_TreeItemClickHandler),t.Destroy(),u.g.DestroyUIObj(t),e-=1}this.itemList.Clear(),this.itemList=null}if(null!=this.itemTitleList){
for(e=this.itemTitleList.Count()-1;e>-1;){const t=this.itemTitleList[e]
p.i.Get(t.node).RemoveonClick(this._degf_TreeItemClickHandler),t.Destroy(),u.g.DestroyUIObj(t),e-=1}this.itemTitleList.Clear(),this.itemTitleList=null}}GetNeedAutoClose(){
return MyTreeBridge.GetNeedAutoClose(this.FatherId,this.ComponentId)}SetNeedAutoClose(e){MyTreeBridge.SetNeedAutoClose(this.FatherId,this.ComponentId,e)}
GetNeedAutoCloseSelectOne(){return MyTreeBridge.GetNeedAutoCloseSelectOne(this.FatherId,this.ComponentId)}SetNeedAutoCloseSelectOne(e){
MyTreeBridge.SetNeedAutoCloseSelectOne(this.FatherId,this.ComponentId,e)}GetNeedParentEvet(){return MyTreeBridge.GetNeedParentEvet(this.FatherId,this.ComponentId)}
SetNeedParentEvet(e){MyTreeBridge.SetNeedParentEvet(this.FatherId,this.ComponentId,e)}GetCurShowNum(){let e=0
const t=this.dataList.Count()
let i=0
for(;i<t;){if("0"==this.dataList[i].parentID&&this.dataList[i].expand){e+=this.GetChildrenDataList(this.dataList[i].id).Count(),e+=1}else"0"==this.dataList[i].parentID&&(e+=1)
i+=1}return e}}},92178:(e,t,i)=>{i.d(t,{E:()=>a})
var n=i(87923),s=i(68637),l=i(30849)
class a extends l.C{constructor(...e){super(...e),this.treeData=null}GetMyTreeData(){return this.treeData}SetMyTreeData(e){this.treeData=e}RegGuide(){
null!=this.treeData&&null!=this.treeData.guideId&&s.c.Inst.RegGameObject(this.treeData.guideId,this.treeData.guideParam,this.node)}UnRegGuide(){
null!=this.treeData&&null!=this.treeData.guideId&&s.c.Inst.UnRegGameObject(this.treeData.guideId,this.treeData.guideParam)}CheckGuide(){
null!=this.treeData&&null!=this.treeData.guideId&&n.l.CheckBtnClickTrigger(this.treeData.guideId,this.treeData.guideParam)}Destroy(){this.UnRegGuide(),super.Destroy()}}},
6508:(e,t,i)=>{i.d(t,{U:()=>a})
var n=i(62734),s=i(92178),l=i(72005)
class a extends s.E{constructor(){super(),this.RedPoint=null,this.isAddLis=!1,this.redPointId=-1,this.luaMyTreeRedPointData=null,this._degf_UpdateRedPointHandler=null,
this._degf_UpdateRedPointHandler=(e,t)=>this.UpdateRedPointHandler(e,t)}InitView(){this.RedPoint=new l.w,this.RedPoint.setId(this.FatherId,this.FatherComponentID,1),
super.InitView()}SetPointState(e){this.RedPoint.node.SetActive(e)}AddOrRemoveLis(e){null==e&&(e=!0),e?(n.f.Inst.AddCallback(this.redPointId,this._degf_UpdateRedPointHandler),
this.isAddLis=!0):(n.f.Inst.RemoveCallback(this.redPointId,this._degf_UpdateRedPointHandler),this.isAddLis=!1)}UpdateRedPointHandler(e,t){e==this.redPointId&&this.SetPointState(t)}
SetMyTreeData(e){super.SetMyTreeData(e),this.isAddLis&&this.AddOrRemoveLis(!1),this.SetPointState(!1)
const t=e
if(null!=t){const e=n.f.Inst.GetData(t.redPointId)
null!=e?this.SetPointState(e.show):t.tempShowRedPoint&&this.SetPointState(!0),this.redPointId=t.redPointId,this.AddOrRemoveLis()}this.luaMyTreeRedPointData=t}RecheckRedPoint(){
let e=!1
return null!=this.luaMyTreeRedPointData&&null!=this.luaMyTreeRedPointData.redPointCheckFun&&(e=this.luaMyTreeRedPointData.redPointCheckFun(this.luaMyTreeRedPointData.data)),
this.SetPointState(e),e}Destroy(){super.Destroy(),this.AddOrRemoveLis(!1),this.luaMyTreeRedPointData=null}}},70707:(e,t,i)=>{i.d(t,{k:()=>a})
var n=i(85602),s=i(38962),l=i(38836)
class a{constructor(){this.m_eventMap=null,this.delegateList=null,this.m_eventMap=new s.X,this.delegateList=new n.Z}AddEventHandler(e,t){let i=null
this.m_eventMap.LuaDic_ContainsKey(e)?i=this.m_eventMap.LuaDic_GetItem(e):(i=new n.Z,this.m_eventMap.LuaDic_AddOrSetItem(e,i))
const s=i.IndexOf(t,0);-1==s?i.Add(t):i[s]=t}RemoveEventHandler(e,t){if(this.m_eventMap.LuaDic_ContainsKey(e)&&null!=this.m_eventMap[e]){let i=null
i=this.m_eventMap.LuaDic_GetItem(e),-1!=i.IndexOf(t,0)&&i.Remove(t)}}RaiseEvent(e,t){let i=null,n=null
if(i=this.m_eventMap[e],null!=i&&null!=i){let e=0
const s=i.Count()
for(e=0;e<s;)e<this.delegateList.Count()?this.delegateList[e]=i[e]:this.delegateList.Add(i[e]),e+=1
for(e=0;e<s;)n=this.delegateList[e],n(t),e+=1
for(e=0;e<s;)this.delegateList[e]=null,e+=1}}HasEvent(e){return this.m_eventMap.LuaDic_ContainsKey(e)}RemoveAllEventHandler(e){
if(this.m_eventMap.LuaDic_ContainsKey(e)&&null!=this.m_eventMap[e]){const t=this.m_eventMap[e]
let i=0
for(;i<t.Count();){const n=t[i]
this.RemoveEventHandler(e,n),i+=1}}}Destroy(){for(const[e,t]of(0,l.V5)(this.m_eventMap))this.m_eventMap.LuaDic_IsNullValue(t)||this.RemoveAllEventHandler(e)}}},80518:(e,t,i)=>{
i.d(t,{A:()=>a})
var n=i(87923),s=i(68637),l=i(30849)
class a extends l.C{constructor(...e){super(...e),this.m_treeData=null}GetMyTreeData(){
return this.m_treeData.expand=MyTreeTitleItemBridge.GetMyTreeExpand(this.FatherId,this.ComponentId),this.m_treeData}GetHasChild(){
return MyTreeTitleItemBridge.GetHasChild(this.FatherId,this.ComponentId)}SetHasChild(e){MyTreeTitleItemBridge.SetHasChild(this.FatherId,this.ComponentId,e)}SetData(e,t,i){
null==i&&(i=!0),this.UnRegGuide(),this.m_treeData=e
let n="-1",s="-1"
null!=t&&(n=t.id,s=t.parentID),MyTreeTitleItemBridge.SetData(this.FatherId,this.ComponentId,this.m_treeData.offset,this.m_treeData.id,this.m_treeData.parentID,this.m_treeData.name,this.m_treeData.expand,n,s,i,this.m_treeData.ignoreSelectForBg),
this.RegGuide()}RegGuide(){null!=this.m_treeData&&null!=this.m_treeData.guideId&&s.c.Inst.RegGameObject(this.m_treeData.guideId,this.m_treeData.guideParam,this.node)}UnRegGuide(){
null!=this.m_treeData&&null!=this.m_treeData.guideId&&s.c.Inst.UnRegGameObject(this.m_treeData.guideId,this.m_treeData.guideParam)}CheckGuide(){
null!=this.m_treeData&&null!=this.m_treeData.guideId&&n.l.CheckBtnClickTrigger(this.m_treeData.guideId,this.m_treeData.guideParam)}SetTextColor(){
MyTreeTitleItemBridge.SetTextColor(this.FatherId,this.ComponentId)}Clear(){this.UnRegGuide(),super.Clear()}Destroy(){super.Destroy()}}},48330:(e,t,i)=>{i.d(t,{l:()=>o})
var n=i(62734),s=i(88653),l=i(80518),a=i(93877),r=i(72005)
class o extends l.A{constructor(){super(),this.RedPoint=null,this.labelText=null,this.isAddLis=!1,this.redPointId=-1,this._degf_UpdateRedPointHandler=null,
this.luaMyTreeRedPointData=null,this._degf_UpdateRedPointHandler=(e,t)=>this.UpdateRedPointHandler(e,t)}InitView(){this.RedPoint=new r.w,
this.RedPoint.setId(this.FatherId,this.FatherComponentID,1),this.labelText=new a.Q,this.labelText.setId(this.FatherId,this.FatherComponentID,2),super.InitView()}SetPointState(e){
this.RedPoint.node.SetActive(e)}AddOrRemoveLis(e){
null==e&&(e=!0),e?this.isAddLis||n.f.Inst.AddCallback(this.redPointId,this._degf_UpdateRedPointHandler):this.isAddLis&&n.f.Inst.RemoveCallback(this.redPointId,this._degf_UpdateRedPointHandler),
this.isAddLis=e}UpdateRedPointHandler(e,t){e==this.redPointId&&this.SetPointState(t)}SetData(e,t,i){null==i&&(i=!0),super.SetData(e,t,i)
const l=e
if(null!=l){this.SetPointState(!1)
const e=n.f.Inst.GetData(l.redPointId)
null!=e?this.SetPointState(e.show):l.tempShowRedPoint&&this.SetPointState(!0),this.redPointId!=l.redPointId&&this.AddOrRemoveLis(!1),this.redPointId=l.redPointId,
this.AddOrRemoveLis()}const a=null!=t&&(e.id==t.id||e.id==t.parentID)
e.expand||a?this.labelText.SetColor(new s.I(224/255,226/255,179/255)):this.labelText.SetColor(new s.I(150/255,128/255,107/255)),super.SetTextColor()}RecheckRedPoint(){let e=!1
return null!=this.luaMyTreeRedPointData&&null!=this.luaMyTreeRedPointData.redPointCheckFun&&(e=this.luaMyTreeRedPointData.redPointCheckFun(this.luaMyTreeRedPointData.data)),
this.SetPointState(e),e}ResetRedPoint(e){this.SetPointState(e)}Destory(){super.Destory(),this.RedPoint=null,this.labelText=null,this.AddOrRemoveLis(!1)}}},9986:(e,t,i)=>{i.d(t,{
W:()=>a})
var n=i(85602),s=i(96617),l=i(83207)
class a extends l.s{SetExtraSprite(e){MyUIButtonBridge.SetExtraSprite(this.FatherId,this.ComponentId,e)}SetHoverChange(e){
MyUIButtonBridge.SetHoverChange(this.FatherId,this.ComponentId,e)}GetHoverChange(){return MyUIButtonBridge.GetHoverChange(this.FatherId,this.ComponentId)}SetPressChange(e){
MyUIButtonBridge.SetPressChange(this.FatherId,this.ComponentId,e)}GetPressChange(){return MyUIButtonBridge.GetPressChange(this.FatherId,this.ComponentId)}SetDisabledChange(e){
MyUIButtonBridge.SetDisabledChange(this.FatherId,this.ComponentId,e)}GetDisabledChange(){return MyUIButtonBridge.GetDisabledChange(this.FatherId,this.ComponentId)}
SetHoverBgChange(e){MyUIButtonBridge.SetHoverBgChange(this.FatherId,this.ComponentId,e)}GetHoverBgChange(){return MyUIButtonBridge.GetHoverBgChange(this.FatherId,this.ComponentId)}
SetPressBgChange(e){MyUIButtonBridge.SetPressBgChange(this.FatherId,this.ComponentId,e)}GetPressBgChange(){return MyUIButtonBridge.GetPressBgChange(this.FatherId,this.ComponentId)}
SetDisabledBgChange(e){MyUIButtonBridge.SetDisabledBgChange(this.FatherId,this.ComponentId,e)}GetDisabledBgChange(){
return MyUIButtonBridge.GetDisabledBgChange(this.FatherId,this.ComponentId)}SetTextColor(e){const t=s.A.ColorToFloatArray(e)
MyUIButtonBridge.SetTextColor(this.FatherId,this.ComponentId,n.Z.GetTableOrNilFromLua(t))}UpdateDefaultTextColor(e){const t=s.A.ColorToFloatArray(e)
MyUIButtonBridge.UpdateDefaultTextColor(this.FatherId,this.ComponentId,n.Z.GetTableOrNilFromLua(t))}SetTextHover(e){const t=s.A.ColorToFloatArray(e)
MyUIButtonBridge.SetTextHover(this.FatherId,this.ComponentId,n.Z.GetTableOrNilFromLua(t))}GetTextHover(){return MyUIButtonBridge.GetTextHover(this.FatherId,this.ComponentId)}
SetTextPress(e){const t=s.A.ColorToFloatArray(e)
MyUIButtonBridge.SetTextPress(this.FatherId,this.ComponentId,n.Z.GetTableOrNilFromLua(t))}GetTextPress(){return MyUIButtonBridge.GetTextPress(this.FatherId,this.ComponentId)}
SetTextDisabled(e){const t=s.A.ColorToFloatArray(e)
MyUIButtonBridge.SetTextDisabled(this.FatherId,this.ComponentId,n.Z.GetTableOrNilFromLua(t))}GetTextDisabled(){
return MyUIButtonBridge.GetTextDisabled(this.FatherId,this.ComponentId)}SetTextEffectColorHover(e){const t=s.A.ColorToFloatArray(e)
MyUIButtonBridge.SetTextEffectColorHover(this.FatherId,this.ComponentId,n.Z.GetTableOrNilFromLua(t))}GetTextEffectColorHover(){
return MyUIButtonBridge.GetTextEffectColorHover(this.FatherId,this.ComponentId)}SetTextEffectColorPress(e){const t=s.A.ColorToFloatArray(e)
MyUIButtonBridge.SetTextEffectColorPress(this.FatherId,this.ComponentId,n.Z.GetTableOrNilFromLua(t))}GetTextEffectColorPress(){
return MyUIButtonBridge.GetTextEffectColorPress(this.FatherId,this.ComponentId)}SetTextEffectColorDisabled(e){const t=s.A.ColorToFloatArray(e)
MyUIButtonBridge.SetTextEffectColorDisabled(this.FatherId,this.ComponentId,n.Z.GetTableOrNilFromLua(t))}GetTextEffectColorDisabled(){
return MyUIButtonBridge.GetTextEffectColorDisabled(this.FatherId,this.ComponentId)}SetTextHoverOffsetX(e){MyUIButtonBridge.SetTextHoverOffsetX(this.FatherId,this.ComponentId,e)}
GetTextHoverOffsetX(){return MyUIButtonBridge.GetTextHoverOffsetX(this.FatherId,this.ComponentId)}SetTextPressOffsetX(e){
MyUIButtonBridge.SetTextPressOffsetX(this.FatherId,this.ComponentId,e)}GetTextPressOffsetX(){return MyUIButtonBridge.GetTextPressOffsetX(this.FatherId,this.ComponentId)}
SetTextDisabledOffsetX(e){MyUIButtonBridge.SetTextDisabledOffsetX(this.FatherId,this.ComponentId,e)}GetTextDisabledOffsetX(){
return MyUIButtonBridge.GetTextDisabledOffsetX(this.FatherId,this.ComponentId)}SetTextHoverOffsetY(e){MyUIButtonBridge.SetTextHoverOffsetY(this.FatherId,this.ComponentId,e)}
GetTextHoverOffsetY(){return MyUIButtonBridge.GetTextHoverOffsetY(this.FatherId,this.ComponentId)}SetTextPressOffsetY(e){
MyUIButtonBridge.SetTextPressOffsetY(this.FatherId,this.ComponentId,e)}GetTextPressOffsetY(){return MyUIButtonBridge.GetTextPressOffsetY(this.FatherId,this.ComponentId)}
SetTextDisabledOffsetY(e){MyUIButtonBridge.SetTextDisabledOffsetY(this.FatherId,this.ComponentId,e)}GetTextDisabledOffsetY(){
return MyUIButtonBridge.GetTextDisabledOffsetY(this.FatherId,this.ComponentId)}SetTextEffectXHover(e){MyUIButtonBridge.SetTextEffectXHover(this.FatherId,this.ComponentId,e)}
GetTextEffectXHover(){return MyUIButtonBridge.GetTextEffectXHover(this.FatherId,this.ComponentId)}SetTextEffectXPress(e){
MyUIButtonBridge.SetTextEffectXPress(this.FatherId,this.ComponentId,e)}GetTextEffectXPress(){return MyUIButtonBridge.GetTextEffectXPress(this.FatherId,this.ComponentId)}
SetTextEffectXDisabled(e){MyUIButtonBridge.SetTextEffectXDisabled(this.FatherId,this.ComponentId,e)}GetTextEffectXDisabled(){
return MyUIButtonBridge.GetTextEffectXDisabled(this.FatherId,this.ComponentId)}SetTextEffectYHover(e){MyUIButtonBridge.SetTextEffectYHover(this.FatherId,this.ComponentId,e)}
GetTextEffectYHover(){return MyUIButtonBridge.GetTextEffectYHover(this.FatherId,this.ComponentId)}SetTextEffectYPress(e){
MyUIButtonBridge.SetTextEffectYPress(this.FatherId,this.ComponentId,e)}GetTextEffectYPress(){return MyUIButtonBridge.GetTextEffectYHover(this.FatherId,this.ComponentId)}
SetTextEffectYDisabled(e){MyUIButtonBridge.SetTextEffectYDisabled(this.FatherId,this.ComponentId,e)}GetTextEffectYDisabled(){
return MyUIButtonBridge.GetTextEffectYDisabled(this.FatherId,this.ComponentId)}SetText(e){MyUIButtonBridge.SetText(this.FatherId,this.ComponentId,e)}SetState(e,t){
MyUIButtonBridge.SetState(this.FatherId,this.ComponentId,e,t)}}},6665:(e,t,i)=>{i.d(t,{A:()=>c})
var n=i(98130),s=i(85602),l=i(38962),a=i(38836),r=i(68662),o=i(5924),d=i(66788),h=i(30849)
class u extends h.C{constructor(){super(),this._degf_cellHeight=null,this._degf_cellWidth=null,this._degf_cellHeight=()=>this.cellHeight(),this._degf_cellWidth=()=>this.cellWidth()
}cellWidth(){return UIGridBridge.cellWidth(this.FatherId,this.ComponentId)}cellWidthSet(e){UIGridBridge.cellWidthSet(this.FatherId,this.ComponentId,e)}cellHeight(){
return UIGridBridge.cellHeight(this.FatherId,this.ComponentId)}cellHeightSet(e){UIGridBridge.cellHeightSet(this.FatherId,this.ComponentId,e)}pivotSet(e){
UIGridBridge.pivotSet(this.FatherId,this.ComponentId,e)}Reposition(){UIGridBridge.Reposition(this.FatherId,this.ComponentId)}}u.eTopLeft=0,u.eTop=1,u.eTopRight=2,u.eLeft=3,
u.eCenter=4,u.eRight=5,u.eBottomLeft=6,u.eBottom=7,u.eBottomRight=8
class c extends u{constructor(){super(),this._refreshData=null,this.m_refreshFun=null,this.m_itemCls=null,this.m_onReposition=null,this.m_dic=null,this.itemList=null,
this._mPrePageCount=null,this._mMaxPage=1,this.resetPos=!0,this._mCurrentPage=1,this._sIndex=0,this._eIndex=0,this._isPageInit=!1,this.m_isFirstRefresh=!0,this.m_thisActive=!1,
this.firstReposition=!0,this.callbackId=0,this.curRefreshStep=0,this.m_onTweenFinish=null,this.tweenInterval=-1,this.delayMoveInterval=-1,this.callId=-1,this.hideTweenItem=null,
this._degf_LoadComplete=null,this._degf_StartMoveItem=null,this._degf_bridgeHandler=null,this.m_itemClick=null,this.m_uidata=null,this.itemCls=null,this.itemClick=null,
this._refreshData=new s.Z,this.m_dic=new l.X,this.itemList=new s.Z,this._mPrePageCount=n.GF.INT32_MAX_VALUE_get(),this._degf_LoadComplete=(e,t)=>this.LoadComplete(e,t),
this._degf_StartMoveItem=(e,t)=>this.StartMoveItem(e,t),this._degf_bridgeHandler=()=>this.bridgeHandler()}prePageCount_get(){return this._mPrePageCount}prePageCount_set(e){
this._mPrePageCount=e,null!=this._refreshData&&this.SetPageInit()}SetPageInit(){if(null!=this._refreshData){this._isPageInit=!0
const e=this._refreshData.Count()-1
this._mMaxPage=n.GF.INT(e/this._mPrePageCount)+1,this.SetCurrentPage(this._mCurrentPage),this.Refresh()}}maxPage_get(){return this._mMaxPage}currentPage_get(){
return this._mCurrentPage}currentPage_set(e){this.SetCurrentPage(e),this.Refresh()}SetCurrentPage(e){(e<1||e>this._mMaxPage)&&(e=1),this._mCurrentPage=e}GotoNext(){
return this._mCurrentPage+=1,this._mCurrentPage>this._mMaxPage&&(this._mCurrentPage=1),this.Refresh(),this._mCurrentPage}GotoFront(){return this._mCurrentPage-=1,
this._mCurrentPage<1&&(this._mCurrentPage=this._mMaxPage),this.Refresh(),this._mCurrentPage}SetDataIndex(){
if(null==this._refreshData||0==this._refreshData.Count())return this._sIndex=0,void(this._eIndex=0)
this._sIndex=this._mPrePageCount*(this._mCurrentPage-1)
let e=0
e=this._mCurrentPage==this.maxPage_get()?this._refreshData.Count()-this._sIndex:this._mPrePageCount,this._eIndex=this._sIndex+e}SetInitInfo(e,t,i,n,s){this.SetItemLoadPath(e),
this.m_refreshFun=t,this.m_itemCls=i,this.m_itemClick=n,this.m_uidata=s}data_get(){return this._refreshData}data_set(e){this._refreshData=e,
this._isPageInit?this.Refresh():this.SetPageInit()}SetDataByIndex(e,t){null!=this._refreshData&&null!=this.itemList&&t<this._refreshData.Count()&&t>-1&&(this._refreshData[t]=e,
t<this.itemList.Count()&&this.itemList[t].SetData(e))}Refresh(){this.callbackId>0&&LuaCallBackMgr.RemoveListCallBackLoadComplete(this.callbackId),
this.m_isFirstRefresh&&(this.m_isFirstRefresh=!1,this.node.SetActive(this.m_thisActive)),this.SetDataIndex(),o.C.Inst_get().ClearInterval(this.delayMoveInterval),
this.delayMoveInterval=-1,o.C.Inst_get().ClearInterval(this.tweenInterval),this.tweenInterval=-1
for(const[e,t]of(0,a.V5)(this.itemList))t.Clear()
this.ResetTweenItem(),this.itemList.Clear(),this.curRefreshStep=0,this.callbackId=LuaCallBackMgr.AddListCallBackLoadComplete(this._degf_LoadComplete)
let e=0
null!=this._refreshData&&(e=this._eIndex-this._sIndex),MyUIGridBridge.SetData(this.FatherId,this.ComponentId,this.callbackId,e)}ResetTweenItem(){
null!=this.hideTweenItem&&(MyUIGridBridge.ResetItemTween(this.hideTweenItem.FatherId,this.hideTweenItem.ComponentId),this.hideTweenItem=null)}LoadComplete(e,t){
if(this.IsDestroyed())d.Y.LogError("LuaMyUIGrid is destroyed when loadcomplete")
else{if(this.m_thisActive||(this.m_thisActive=!0,this.node.SetActive(this.m_thisActive)),null!=this._refreshData&&this._refreshData.Count()>0){
t<this.curRefreshStep&&(this.curRefreshStep=0)
let i=0
for(i=this.curRefreshStep;i<=t;){const t=this.GetItem(e[i])
t.index=i,t.onClick=this.m_itemClick,t.node.SetActive(!0),t.__InternalSetData(this.GetDataByIndex(i)),this.itemList.Add(t),i+=1}this.curRefreshStep=i,
this.resetPos?this.Reposition(!0):this.CallReposition()}else this.CallReposition()
this.curRefreshStep>=e.count&&(LuaCallBackMgr.RemoveListCallBackLoadComplete(this.callbackId),this.callbackId=0)}}GetDataByIndex(e){return this._refreshData[this._sIndex+e]}
GetItem(e){let t=null
return this.m_dic.LuaDic_ContainsKey(e)?(t=this.m_dic[e],t):(null!=this.m_itemCls?(t=new this.m_itemCls,null!=this.m_uidata&&t.SetUIData(this.m_uidata),
t.setPrefabRootId(e)):t=this.m_refreshFun(e),this.m_dic.LuaDic_AddOrSetItem(e,t),t)}CallReposition(){null!=this.m_onReposition&&(this.m_onReposition(),
this.firstReposition&&(this.firstReposition=!1))}OnReposition_set(e){this.m_onReposition=e}OnTweenFinish_set(e){this.m_onTweenFinish=e}StartHideItem(e,t){
this.itemList.Count()<=e.index||(this.hideTweenItem=this.itemList[e.index],this.OnTweenFinish_set(t),
MyUIGridBridge.StartHideItem(this.hideTweenItem.FatherId,this.hideTweenItem.ComponentId,e.alphaDuration),o.C.Inst_get().ClearInterval(this.delayMoveInterval),
this.delayMoveInterval=o.C.Inst_get().SetIntervalForParm(this._degf_StartMoveItem,n.GF.INT(1e3*e.moveDelay),1,e),o.C.Inst_get().ClearInterval(this.tweenInterval))}
StartMoveItem(e,t){const i=t,n=MyUIGridBridge.arrangement(this.FatherId,this.ComponentId),s=(MyUIGridBridge.cellWidth(this.FatherId,this.ComponentId),
MyUIGridBridge.cellHeight(this.FatherId,this.ComponentId)),l=this.itemList.Count()
let a=i.index+1
for(;a<l;){const e=this.itemList[a],t=e.node.transform.GetLocalPosition()
let r=t.x,o=t.y
0==n?r=t.x-s:1==n&&(o=t.y+s),a==l-1&&(this.callId=LuaCallBackMgr.AddCallBackOnFinished(this._degf_bridgeHandler)),
MyUIGridBridge.StartMoveItem(e.FatherId,e.ComponentId,i.moveDuration,r,o,this.callId),a+=1}}bridgeHandler(){null!=this.m_onTweenFinish&&this.m_onTweenFinish()}CallTweenFinish(e){
null!=this.m_onTweenFinish&&this.m_onTweenFinish()}IsMoveTween_get(){return MyUIGridBridge.GetIsMoveTween(this.FatherId,this.ComponentId)}IsMoveTween_set(e){
MyUIGridBridge.SetIsMoveTween(this.FatherId,this.ComponentId,e)}IsJustOneMoveTween_get(){return MyUIGridBridge.GetJustOneMoveTween(this.FatherId,this.ComponentId)}
IsJustOneMoveTween_set(e){MyUIGridBridge.SetJustOneMoveTween(this.FatherId,this.ComponentId,e)}MaxPerLine_get(){return MyUIGridBridge.GetMaxPerLine(this.FatherId,this.ComponentId)}
MaxPerLine_set(e){MyUIGridBridge.SetMaxPerLine(this.FatherId,this.ComponentId,e)}customSetPos(){return MyUIGridBridge.customSetPos(this.FatherId,this.ComponentId)}
customSetPos_set(e){return MyUIGridBridge.customSetPos_set(this.FatherId,this.ComponentId,e)}Destroy(){if(!this.m_Destroyed){this.m_onReposition=null,
o.C.Inst_get().ClearInterval(this.delayMoveInterval),this.delayMoveInterval=-1,o.C.Inst_get().ClearInterval(this.tweenInterval),this.tweenInterval=-1,
this.callbackId>0&&(LuaCallBackMgr.RemoveListCallBackLoadComplete(this.callbackId),this.callbackId=0),this.callId>0&&LuaCallBackMgr.RemoveCallBackOnFinished(this.callId),
this.m_itemClick=null,this.callId=-1
for(const[e,t]of(0,a.V5)(this.m_dic))t.Clear(),t.Destroy()
this.itemList.Clear(),this.itemList=null,this.DoOnDestroy(),this.m_dic.LuaDic_Clear(),this.m_dic=null,this.m_refreshFun=null,this.m_onReposition=null,this.m_onTweenFinish=null,
this._refreshData=null,this.itemCls=null,this.itemClick=null,super.Destroy()}}SetItemLoadPath(e){const t=r.D.IsNeedReplacePrefabName(e)
""!=t&&(e=t),MyUIGridBridge.SetItemLoadPath(this.FatherId,this.ComponentId,e)}DoPosInteger(){MyUIGridBridge.DoPosInteger(this.FatherId,this.ComponentId)}Clear(){
if(this.callbackId>0&&LuaCallBackMgr.RemoveListCallBackLoadComplete(this.callbackId),null!=this.itemList)for(const[e,t]of(0,a.V5)(this.itemList))t.Clear()
super.Clear()}DoOnDestroy(){MyUIGridBridge.DoOnDestroy(this.FatherId,this.ComponentId)}Reposition(e){super.Reposition(),null==e&&(e=!0),e&&this.CallReposition()}DoRefresh(){
MyUIGridBridge.DoRefresh(this.FatherId,this.ComponentId)}}},89501:(e,t,i)=>{i.d(t,{N:()=>s})
var n=i(6665)
class s extends n.A{constructor(...e){super(...e),this.onceInitCount=0}SetOnceInitCount(e){MyUIGridExBridge.SetOnceInitCount(this.FatherId,this.ComponentId,e),this.onceInitCount=e}
DoOnDestroy(){MyUIGridExBridge.DoOnDestroyEx(this.FatherId,this.ComponentId)}LoadComplete(e,t){if(this.m_thisActive||(this.m_thisActive=!0,this.node.SetActive(this.m_thisActive)),
null!=this._refreshData&&this._refreshData.Count()>0){t<this.curRefreshStep&&(this.curRefreshStep=0)
let i=0
const n=this.curRefreshStep
for(i=this.curRefreshStep;i<=t;){const t=this.GetItem(e[i])
t.index=i,t.__InternalSetData(this.GetDataByIndex(i)),this.itemList.Add(t),i+=1}this.curRefreshStep=i,0==n&&this.CallReposition()}}}},9057:(e,t,i)=>{i.d(t,{x:()=>s})
var n=i(30849)
class s extends n.C{constructor(...e){super(...e),this.index=0,this.tag=null,this.onSetData=null,this._def_ItemClickHandler=null}_initBinder(){super._initBinder()}InitView(){}
__InternalSetData(e){this.SetData(e),null!=this.onSetData&&this.onSetData()}SetData(e){}SetUIData(e){}Clear(){null!=this.m_handlerMgr&&this.m_handlerMgr.Clear(),this.onClick=null,
this.onSetData=null}SetItemClickGo(e){null==this._def_ItemClickHandler&&(this._def_ItemClickHandler=(e,t)=>{this._ItemClickHandler(e,t)}),
this.m_handlerMgr.AddClickEvent(e,this._def_ItemClickHandler)}_ItemClickHandler(e,t){null!=this.onClick&&this.onClick(e,t)}Destroy(){super.Destroy()}}},78287:(e,t,i)=>{i.d(t,{
_:()=>s})
var n=i(30849)
class s extends n.C{SetBtnStep(e){MyUIScrollBarBridge.SetBtnStep(this.FatherId,this.ComponentId,e)}GetBtnStep(){
return MyUIScrollBarBridge.GetBtnStep(this.FatherId,this.ComponentId)}DoForceUpdate(){MyUIScrollBarBridge.DoForceUpdate(this.FatherId,this.ComponentId)}GetValue(){
return MyUIScrollBarBridge.GetValue(this.FatherId,this.ComponentId)}SetValue(e){MyUIScrollBarBridge.SetValue(this.FatherId,this.ComponentId,e)}SetValueForce(e){
MyUIScrollBarBridge.SetValueForce(this.FatherId,this.ComponentId,e)}GetBarSize(){return MyUIScrollBarBridge.GetBarSize(this.FatherId,this.ComponentId)}SetBarSize(e){
MyUIScrollBarBridge.SetBarSize(this.FatherId,this.ComponentId,e)}}},9776:(e,t,i)=>{i.d(t,{h:()=>s})
var n=i(71728)
class s extends n.L{SetPixelFix(e){MyUIScrollViewBridge.SetPixelFix(this.FatherId,this.ComponentId,e)}GetPixelFix(){
return MyUIScrollViewBridge.GetPixelFix(this.FatherId,this.ComponentId)}DoScroll(e){MyUIScrollViewBridge.DoScroll(this.FatherId,this.ComponentId,e)}SetDragAmountAndUpdate(e,t){
MyUIScrollViewBridge.SetDragAmountAndUpdate(this.FatherId,this.ComponentId,e,t)}DoScrollNoActivite(e){MyUIScrollViewBridge.DoScrollNoActivite(this.FatherId,this.ComponentId,e)}
DoUpdateScrollbars(e){null==e&&(e=!0),MyUIScrollViewBridge.DoUpdateScrollbars(this.FatherId,this.ComponentId,e)}RegiestGetSection(e,t){
if(this.callDragStartIdDic.LuaDic_ContainsKey(t))return
const i=LuaCallBackMgr.AddCallBackOnDragStartNotification(t)
this.callDragStartIdDic.LuaDic_AddOrSetItem(t,i),MyUIScrollViewBridge.RegiestGetSection(this.FatherId,this.ComponentId,e.FatherId,e.ComponentId,i)}RemoveGetSection(e){
if(this.callDragStartIdDic.LuaDic_ContainsKey(e)){const t=this.callDragStartIdDic[e]
this.callDragStartIdDic.LuaDic_Remove(e),LuaCallBackMgr.RemoveCallBackOnDragNotification(t),MyUIScrollViewBridge.RemoveGetSection(this.FatherId,this.ComponentId)}}
GetVerticalBoundPanelRatio(){return MyUIScrollViewBridge.GetVerticalBoundPanelRatio(this.FatherId,this.ComponentId)}StopSpringPanel(){
MyUIScrollViewBridge.StopSpringPanel(this.FatherId,this.ComponentId)}RemoveSpringPanel(){MyUIScrollViewBridge.RemoveSpringPanel(this.FatherId,this.ComponentId)}
StartSpringPanel(e,t){MyUIScrollViewBridge.StartSpringPanel(this.FatherId,this.ComponentId,e,t)}}},63062:(e,t,i)=>{i.d(t,{p:()=>s})
var n=i(30849)
class s extends n.C{SetDir(e){MyUISliderBridge.SetDir(this.FatherId,this.ComponentId,e)}GetDir(){return MyUISliderBridge.GetDir(this.FatherId,this.ComponentId)}GetGrowTime(){
return MyUISliderBridge.GetGrowTime(this.FatherId,this.ComponentId)}SetGrowTime(e){MyUISliderBridge.SetGrowTime(this.FatherId,this.ComponentId,e)}SetIsAutoClear(e){
MyUISliderBridge.SetIsAutoClear(this.FatherId,this.ComponentId,e)}GetIsAutoClear(){return MyUISliderBridge.GetIsAutoClear(this.FatherId,this.ComponentId)}SetW1(e){
MyUISliderBridge.SetW1(this.FatherId,this.ComponentId,e)}GetW1(){return MyUISliderBridge.GetW1(this.FatherId,this.ComponentId)}DoF_SetValueEx(e,t){
MyUISliderBridge.DoF_SetValueEx(this.FatherId,this.ComponentId,e,t)}DoF_SetValue(e,t){MyUISliderBridge.DoF_SetValue(this.FatherId,this.ComponentId,e,t)}GetImgBaseWidth(){
return MyUISliderBridge.GetImgBaseWidth(this.FatherId,this.ComponentId)}GetFillVal(){return MyUISliderBridge.GetFillVal(this.FatherId,this.ComponentId)}SetProgressType(e){
MyUISliderBridge.SetProgressType(this.FatherId,this.ComponentId,e)}GetProgressType(){return MyUISliderBridge.GetProgressType(this.FatherId,this.ComponentId)}SetDecimalDigits(e){
MyUISliderBridge.SetDecimalDigits(this.FatherId,this.ComponentId,e)}GetDecimalDigits(){return MyUISliderBridge.GetProgressType(this.FatherId,this.ComponentId)}SetMaxVal(e){
MyUISliderBridge.SetMaxVal(this.FatherId,this.ComponentId,e)}GetMaxVal(){return MyUISliderBridge.GetMaxVal(this.FatherId,this.ComponentId)}DoF_SetFullVal(){
MyUISliderBridge.DoF_SetFullVal(this.FatherId,this.ComponentId)}DoF_ClearInfo(){MyUISliderBridge.DoF_ClearInfo(this.FatherId,this.ComponentId)}SetFgSize(e){
MyUISliderBridge.SetFgSize(this.FatherId,this.ComponentId,e.x,e.y)}GetFgSize(){return MyUISliderBridge.GetFgSize(this.FatherId,this.ComponentId)}SetFgSizeWH(e,t){
MyUISliderBridge.SetFgSize(this.FatherId,this.ComponentId,e,t)}SetBgSize(e){MyUISliderBridge.SetBgSize(this.FatherId,this.ComponentId,e.x,e.y)}SetBgSizeWH(e,t){
MyUISliderBridge.SetBgSize(this.FatherId,this.ComponentId,e,t)}GetBgSize(){return MyUISliderBridge.GetBgSize(this.FatherId,this.ComponentId)}ClearData(){
MyUISliderBridge.ClearData(this.FatherId,this.ComponentId)}}},36437:(e,t,i)=>{i.d(t,{K:()=>r})
var n=i(38962),s=i(38836),l=i(75309),a=i(30849)
class r extends a.C{constructor(){super(),this.callbackIdDic=null,this.callbackIdDic=new n.X}GetSelectHandler(){
return MyUITabBridge.GetSelectHandler(this.FatherId,this.ComponentId)}SetSelectHandler(e){let t=0
this.callbackIdDic.LuaDic_ContainsKey(e)?t=this.callbackIdDic[e]:(t=l.n.AddCallBackTabSelectHandler(e),this.callbackIdDic.LuaDic_AddOrSetItem(e,t)),
MyUITabBridge.SetSelectHandler(this.FatherId,this.ComponentId,t)}RemoveSelectHandler(e){if(this.callbackIdDic.LuaDic_ContainsKey(e)){const t=this.callbackIdDic[e]
this.callbackIdDic.LuaDic_Remove(e),l.n.RemoveCallBackTabSelectHandler(t),MyUITabBridge.SetSelectHandler(this.FatherId,this.ComponentId,0)}}GetSelectIndex(){
return MyUITabBridge.GetSelectIndex(this.FatherId,this.ComponentId)}SetSelectIndex(e,t){null==t&&(t=!1),MyUITabBridge.SetSelectIndex(this.FatherId,this.ComponentId,e,t)}
ResetNoClick(){MyUITabBridge.ResetNoClick(this.FatherId,this.ComponentId)}ResetClickOne(){MyUITabBridge.ResetClickOne(this.FatherId,this.ComponentId)}ClearIndex(){
MyUITabBridge.ClearIndex(this.FatherId,this.ComponentId)}InActiveTab(e){MyUITabBridge.InActiveTab(this.FatherId,this.ComponentId,e)}SetCurIndexBtnEnabel(e){
MyUITabBridge.SetCurIndexBtnEnable(this.FatherId,this.ComponentId,e)}ActiveTab(e){MyUITabBridge.ActiveTab(this.FatherId,this.ComponentId,e)}Layout(){
MyUITabBridge.Layout(this.FatherId,this.ComponentId)}SetTab(e,t){MyUITabBridge.SetTab(this.FatherId,this.ComponentId,e.FatherId,e.ComponentId,t)}SetTabContext(e,t){
MyUITabBridge.SetTabContent(this.FatherId,this.ComponentId,e.FatherId,e.ComponentId,t)}SetEnableSelect(e){MyUITabBridge.SetEnableSelect(this.FatherId,this.ComponentId,e)}
GetTabIndex(e){return MyUITabBridge.GetTabIndex(this.FatherId,this.ComponentId,e.FatherId,e.ComponentId)}ClearTab(){MyUITabBridge.ClearTab(this.FatherId,this.ComponentId)}Clear(){
for(const[e,t]of(0,s.vy)(this.callbackIdDic)){const e=t
l.n.RemoveCallBackTabSelectHandler(e)}this.callbackIdDic.LuaDic_Clear(),MyUITabBridge.SetSelectHandler(this.FatherId,this.ComponentId,0)}Destory(){
MyUITabBridge.Destory(this.FatherId,this.ComponentId)}Destroy(){r.Destory(),super.Destroy()}}},30267:(e,t,i)=>{i.d(t,{V:()=>s})
var n=i(30849)
class s extends n.C{constructor(){super(),this._refreshData=null,this.m_dic=null,this.itemList=null,this.m_CreateFun=null,this.m_onReposition=null,this._mPrePageCount=null,
this._mMaxPage=1,this._mCurrentPage=1,this._sIndex=0,this._eIndex=0,this.m_isFirstRefresh=!0,this.m_thisActive=!1,this.callbackId=0,this._degf_LoadComplete=null,
this.m_dic=new Dictionary,this.itemList=new CList,this._mPrePageCount=GF.INT32_MAX_VALUE_get(),this._degf_LoadComplete=e=>this.LoadComplete(e)}data_get(){return this._refreshData}
data_set(e){if(this._refreshData=e,null!=this._refreshData){const e=this._refreshData.Count()-1
this._mMaxPage=GF.INT(e/this._mPrePageCount)+1}this.SetCurrentPage(this._mCurrentPage),this.Refresh()}prePageCount_get(){return this._mPrePageCount}prePageCount_set(e){
if(this._mPrePageCount=e,null!=this._refreshData){const e=this._refreshData.Count()-1
this._mMaxPage=GF.INT(e/this._mPrePageCount)+1,this.SetCurrentPage(this._mCurrentPage),this.Refresh()}}maxPage_get(){return this._mMaxPage}currentPage_get(){
return this._mCurrentPage}currentPage_set(e){this.SetCurrentPage(e),this.Refresh()}SetCurrentPage(e){(e<1||e>this._mMaxPage)&&(e=1),this._mCurrentPage=e}GotoNext(){
return this._mCurrentPage+=1,this._mCurrentPage>this._mMaxPage&&(this._mCurrentPage=1),this.Refresh(),this._mCurrentPage}GotoFront(){return this._mCurrentPage-=1,
this._mCurrentPage<1&&(this._mCurrentPage=this._mMaxPage),this.Refresh(),this._mCurrentPage}SetDataIndex(){
if(null==this._refreshData||0==this._refreshData.Count())return this._sIndex=0,void(this._eIndex=0)
this._sIndex=this._mPrePageCount*(this._mCurrentPage-1)
let e=0
e=this._mCurrentPage==this.maxPage_get()?this._refreshData.Count()-this._sIndex:this._mPrePageCount,this._eIndex=this._sIndex+e}SetInitInfo(e,t){this.SetItemLoadPath(e),
this.m_CreateFun=t}Refresh(){this.callbackId>0&&LuaCallBackMgr.RemoveCallBackLoadComplete(this.callbackId),this.m_isFirstRefresh&&(this.m_isFirstRefresh=!1,
this.node.SetActive(this.m_thisActive)),this.SetDataIndex(),this.callbackId=LuaCallBackMgr.AddCallBackLoadComplete(this._degf_LoadComplete)
let e=0
null!=this._refreshData&&(e=this._eIndex-this._sIndex),MyUITableBridge.SetData(this.FatherId,this.ComponentId,this.callbackId,e)}LoadComplete(e){
this.m_thisActive||(this.m_thisActive=!0,this.node.SetActive(this.m_thisActive)),this.callbackId=0
for(const[e,t]of Vpairs(this.itemList))t.Clear()
if(this.itemList.Clear(),null!=this._refreshData&&this._refreshData.Count()>0){const t=e.count
let i=null
const n=this._refreshData.Count()
let s=0
for(;s<t;)s+this._sIndex<n&&(i=this.GetItem(e[s]),i.index=s,i.SetData(this.GetDataByIndex(s)),this.itemList.Add(i)),s+=1}this.CallReposition(),
LuaCallBackMgr.RemoveCallBackLoadComplete(this.callbackId)}GetDataByIndex(e){return this._refreshData[this._sIndex+e]}GetItem(e){let t=null
return this.m_dic.LuaDic_ContainsKey(e)?(t=this.m_dic[e],t):(t=this.m_CreateFun(e),this.m_dic.LuaDic_AddOrSetItem(e,t),t)}OnReposition_set(e){this.m_onReposition=e}
CallReposition(){MyUITableBridge.Reposition(this.FatherId,this.ComponentId),null!=this.m_onReposition&&this.m_onReposition()}IsMoveTween_get(){
return MyUITableBridge.GetIsMoveTween(this.FatherId,this.ComponentId)}IsMoveTween_set(e){MyUITableBridge.SetIsMoveTween(this.FatherId,this.ComponentId,e)}Destroy(){
if(!this.m_Destroyed){this.callbackId>0&&LuaCallBackMgr.RemoveCallBackLoadComplete(this.callbackId)
for(const[e,t]of Vpairs(this.m_dic))t.Clear(),t.Destroy(),UIResMgr.DestroyUIObj(t)
this.itemList.Clear(),this.DoOnDestroy(),this.itemList=null,this.m_dic.LuaDic_Clear(),this.m_dic=null,this.m_CreateFun=null,this.m_onReposition=null,this._refreshData=null,
super.Destroy()}}SetItemLoadPath(e){const t=LuaGlobal.IsNeedReplacePrefabName(e)
""!=t&&(e=t),MyUITableBridge.SetItemLoadPath(this.FatherId,this.ComponentId,e)}DoRefresh(){MyUITableBridge.DoRefresh(this.FatherId,this.ComponentId)}DoPosInteger(){
MyUITableBridge.DoPosInteger(this.FatherId,this.ComponentId)}Clear(){for(const[e,t]of Vpairs(this.itemList))t.Clear()
super.Clear()}DoOnDestroy(){MyUITableBridge.DoOnDestroy(this.FatherId,this.ComponentId)}Reposition(){MyUITableBridge.Reposition(this.FatherId,this.ComponentId),
this.CallReposition()}GetTableSize(){return MyUITableBridge.GetTableSize(this.FatherId,this.ComponentId)}GetXOffset(){
return MyUITableBridge.GetXOffset(this.FatherId,this.ComponentId)}GetYOffset(){return MyUITableBridge.GetYOffset(this.FatherId,this.ComponentId)}SetHideInactive(e){
MyUITableBridge.SetHideInactive(this.FatherId,this.ComponentId,e)}CallFunForItems(e,...t){for(const[t,i]of Vpairs(this.m_dic))if(i){i[e]}}}},19833:(e,t,i)=>{i.d(t,{X:()=>s})
var n=i(79534)
class s{constructor(){this.type=0,this.handleId=0,this.pos=new n.P,this.animationId=0,this.index=0,this.pos=new n.P}Clear(){this.type=0,this.handleId=0,this.animationId=0,
this.index=0}static IsMonster(e){return e==s.MONSTERCHARACTER||e==s.SUMMONMONSTERCHARACTER||e==s.GOLDMONSTERCHARACTER||e==s.BOSSTOMB}static IsNpc(e){return e==s.NPCCHARACTER}
static IsGuard(e){return e==s.GUARDCHARACTER}static IsRiding(e){return e==s.HORSECHARACTER}static IsDrop(e){return e==s.DROPCHARACTER}static IsCollect(e){
return e==s.COLLECTCHARACTER}}s.NOTYPE=-1,s.INTERACTIVEITEM=0,s.DROPCHARACTER=1,s.TRANSPORTCHARACTER=2,s.GUARDCHARACTER=3,s.HORSECHARACTER=4,s.MONSTERCHARACTER=5,s.NPCCHARACTER=6,
s.ROLE=7,s.SUMMONMONSTERCHARACTER=8,s.COLLECTCHARACTER=9,s.GOLDMONSTERCHARACTER=10,s.BOSSTOMB=12,s.WALLCHARACTER=13,s.DP_ITEM=14,s.PANDORABOX_ITEM=15,s.KARIMA_GATE=16,
s.MAGIC_TOWER=17},80363:(e,t,i)=>{i.d(t,{L:()=>l})
var n=i(85602),s=i(75309)
class l{ExecuteCapture(e,t,i,l,a,r,o,d,h,u){const c=s.n.AddCallBackOnFinished(i)
return ScreenCaptureBridge.ExecuteCapture(n.Z.GetTableOrNilFromLua(e),n.Z.GetTableOrNilFromLua(t),c,n.Z.GetTableOrNilFromLua(l),n.Z.GetTableOrNilFromLua(a),n.Z.GetTableOrNilFromLua(r),n.Z.GetTableOrNilFromLua(o),n.Z.GetTableOrNilFromLua(d),n.Z.GetTableOrNilFromLua(h),n.Z.GetTableOrNilFromLua(u)),
c}DestroyCaptureView(){ScreenCaptureBridge.DestroyCaptureView()}SaveFile(){ScreenCaptureBridge.SaveFile()}ExecuteScreenCache(e,t,i,l,a,r,o,d,h){
const u=s.n.AddCallBackIntArrDelegate(t)
ScreenCaptureBridge.ExecuteScreenCache(u,n.Z.GetTableOrNilFromLua(i),n.Z.GetTableOrNilFromLua(l),n.Z.GetTableOrNilFromLua(a),n.Z.GetTableOrNilFromLua(r),n.Z.GetTableOrNilFromLua(o),n.Z.GetTableOrNilFromLua(d),n.Z.GetTableOrNilFromLua(h),e)
}ExecuteSetScreenCacheTex(e,t,i){ScreenCaptureBridge.ExecuteSetScreenCacheTex(n.Z.GetTableOrNilFromLua(t),n.Z.GetTableOrNilFromLua(i),e)}DestoryScreenCache(){
ScreenCaptureBridge.DestoryScreenCache()}}},86290:(e,t,i)=>{i.d(t,{G:()=>s})
var n=i(60069)
class s extends n.r{}},61756:(e,t,i)=>{i.d(t,{R:()=>s})
var n=i(84006)
class s extends n.k{GetFrom(){return TweenAlphaBridge.GetFrom(this.FatherId,this.ComponentId)}SetFrom(e){TweenAlphaBridge.SetFrom(this.FatherId,this.ComponentId,e)}GetTo(){
return TweenAlphaBridge.GetTo(this.FatherId,this.ComponentId)}SetTo(e){TweenAlphaBridge.SetTo(this.FatherId,this.ComponentId,e)}GetAlpha(){
return TweenAlphaBridge.GetAlpha(this.FatherId,this.ComponentId)}SetAlpha(e){TweenAlphaBridge.SetAlpha(this.FatherId,this.ComponentId,e)}GetValue(){
return TweenAlphaBridge.GetAlpha(this.FatherId,this.ComponentId)}SetValue(e){TweenAlphaBridge.SetAlpha(this.FatherId,this.ComponentId,e)}Begin(e,t,i,n,s,l){
TweenAlphaBridge.Begin(e,t,i,n,s,l)}}},32759:(e,t,i)=>{i.d(t,{c:()=>s})
var n=i(84006)
class s extends n.k{GetFrom(){return TweenPositionBridge.GetFrom(this.FatherId,this.ComponentId)}SetFrom(e){TweenPositionBridge.SetFrom(this.FatherId,this.ComponentId,e.x,e.y,e.z)}
GetTo(){return TweenPositionBridge.GetTo(this.FatherId,this.ComponentId)}SetTo(e){TweenPositionBridge.SetTo(this.FatherId,this.ComponentId,e.x,e.y,e.z)}SetFromXYZ(e,t,i){
TweenPositionBridge.SetFrom(this.FatherId,this.ComponentId,e,t,i)}SetToXYZ(e,t,i){TweenPositionBridge.SetTo(this.FatherId,this.ComponentId,e,t,i)}GetWorldSpace(){
return TweenPositionBridge.GetWorldSpace(this.FatherId,this.ComponentId)}SetWorldSpace(e){TweenPositionBridge.SetWorldSpace(this.FatherId,this.ComponentId,e)}GetPosition(){
return TweenPositionBridge.GetPosition(this.FatherId,this.ComponentId)}SetPosition(e){TweenPositionBridge.SetPosition(this.FatherId,this.ComponentId,e.x,e.y,e.z)}GetValue(){
return TweenPositionBridge.GetValue(this.FatherId,this.ComponentId)}SetValue(e){TweenPositionBridge.SetValue(this.FatherId,this.ComponentId,e.x,e.y,e.z)}Begin(e,t,i,n,s,l){
TweenPositionBridge.Begin(e,t,i,n.x,n.y,n.z,s.x,s.y,s.z,l)}}},4338:(e,t,i)=>{i.d(t,{z:()=>s})
var n=i(84006)
class s extends n.k{GetFrom(){return TweenRotationBridge.GetFrom(this.FatherId,this.ComponentId)}SetFrom(e){TweenRotationBridge.SetFrom(this.FatherId,this.ComponentId,e.x,e.y,e.z)}
GetTo(){return TweenRotationBridge.GetTo(this.FatherId,this.ComponentId)}SetTo(e){TweenRotationBridge.SetTo(this.FatherId,this.ComponentId,e.x,e.y,e.z)}SetFromXYZ(e,t,i){
TweenRotationBridge.SetFrom(this.FatherId,this.ComponentId,e,t,i)}SetToXYZ(e,t,i){TweenRotationBridge.SetTo(this.FatherId,this.ComponentId,e,t,i)}Begin(e,t,i,n,s,l){
TweenRotationBridge.Begin(e,t,i,n.x,n.y,n.z,s.x,s.y,s.z,l)}}},35880:(e,t,i)=>{i.d(t,{d:()=>s})
var n=i(84006)
class s extends n.k{GetFrom(){return TweenScaleBridge.GetFrom(this.FatherId,this.ComponentId)}SetFrom(e){TweenScaleBridge.SetFrom(this.FatherId,this.ComponentId,e.x,e.y,e.z)}
GetTo(){return TweenScaleBridge.GetTo(this.FatherId,this.ComponentId)}SetTo(e){TweenScaleBridge.SetTo(this.FatherId,this.ComponentId,e.x,e.y,e.z)}SetToXYZ(e,t,i){
TweenScaleBridge.SetTo(this.FatherId,this.ComponentId,e,t,i)}SetFromXYZ(e,t,i){TweenScaleBridge.SetFrom(this.FatherId,this.ComponentId,e,t,i)}GetUpdateTableState(){
return TweenScaleBridge.GetUpdateTableState(this.FatherId,this.ComponentId)}SetUpdateTableState(e){TweenScaleBridge.SetUpdateTableState(this.FatherId,this.ComponentId,e)}
GetValue(){return TweenScaleBridge.GetValue(this.FatherId,this.ComponentId)}SetValue(e){TweenScaleBridge.SetValue(this.FatherId,this.ComponentId,e.x,e.y,e.z)}GetScale(){
return TweenScaleBridge.GetScale(this.FatherId,this.ComponentId)}SetScale(e){TweenScaleBridge.SetScale(this.FatherId,this.ComponentId,e.x,e.y,e.z)}SetTweenFactor(e){
TweenScaleBridge.SetTweenFactor(this.FatherId,this.ComponentId,e)}Begin(e,t,i,n,s,l){TweenScaleBridge.Begin(e,t,i,n.x,n.y,n.z,s.x,s.y,s.z,l)}}},87556:(e,t,i)=>{i.d(t,{j:()=>s})
var n=i(13113)
class s extends n.T{fillAmount(){return UIBasicSpriteBridge.fillAmount(this.FatherId,this.ComponentId)}fillAmountSet(e){
UIBasicSpriteBridge.fillAmountSet(this.FatherId,this.ComponentId,e)}InitTempData(){UIBasicSpriteBridge.InitTempData()}GetMinWidth(){
return UIBasicSpriteBridge.GetMinWidth(this.FatherId,this.ComponentId)}GetMinHeight(){return UIBasicSpriteBridge.GetMinHeight(this.FatherId,this.ComponentId)}invert(){
return UIBasicSpriteBridge.invert(this.FatherId,this.ComponentId)}invertSet(e){UIBasicSpriteBridge.invertSet(this.FatherId,this.ComponentId,e)}hasBorder(){
return UIBasicSpriteBridge.hasBorder(this.FatherId,this.ComponentId)}GetPremultipliedAlpha(){return UIBasicSpriteBridge.GetPremultipliedAlpha(this.FatherId,this.ComponentId)}
GetPixelSize(){return UIBasicSpriteBridge.GetPixelSize(this.FatherId,this.ComponentId)}}},83207:(e,t,i)=>{i.d(t,{s:()=>l})
var n=i(30849)
class s extends n.C{SetIsEnabled(e){}GetIsEnabled(){return!1}ResetDefaultColor(){}CacheDefaultColor(){}SetState(e,t){}UpdateColor(e){}SetSize(e,t){}}class l extends s{
dragHighlight(){return UIButtonBridge.dragHighlight(this.FatherId,this.ComponentId)}dragHighlightSet(e){UIButtonBridge.dragHighlightSet(this.FatherId,this.ComponentId,e)}
hoverSprite(){return UIButtonBridge.hoverSprite(this.FatherId,this.ComponentId)}hoverSpriteSet(e){UIButtonBridge.hoverSpriteSet(this.FatherId,this.ComponentId,e)}pressedSprite(){
return UIButtonBridge.pressedSprite(this.FatherId,this.ComponentId)}pressedSpriteSet(e){UIButtonBridge.pressedSpriteSet(this.FatherId,this.ComponentId,e)}disabledSprite(){
return UIButtonBridge.disabledSprite(this.FatherId,this.ComponentId)}disabledSpriteSet(e){UIButtonBridge.disabledSpriteSet(this.FatherId,this.ComponentId,e)}pixelSnap(){
return UIButtonBridge.pixelSnap(this.FatherId,this.ComponentId)}pixelSnapSet(e){UIButtonBridge.pixelSnapSet(this.FatherId,this.ComponentId,e)}GetIsEnabled(){
return UIButtonBridge.GetIsEnabled(this.FatherId,this.ComponentId)}SetIsEnabled(e){UIButtonBridge.SetIsEnabled(this.FatherId,this.ComponentId,e)}normalSprite(){
return UIButtonBridge.normalSprite(this.FatherId,this.ComponentId)}normalSpriteSet(e){UIButtonBridge.normalSpriteSet(this.FatherId,this.ComponentId,e)}OnDragOver(){
UIButtonBridge.OnDragOver(this.FatherId,this.ComponentId)}OnDragOut(){UIButtonBridge.OnDragOut(this.FatherId,this.ComponentId)}OnClick(){
UIButtonBridge.OnClick(this.FatherId,this.ComponentId)}SetState(e,t){UIButtonBridge.SetState(this.FatherId,this.ComponentId,e,t)}}},37009:(e,t,i)=>{i.d(t,{l:()=>s})
var n=i(30849)
class s extends n.C{OnSelect(){UICenterOnSelectBridger.OnSelect(this.FatherId,this.ComponentId)}StopSpring(e,t){UICenterOnSelectBridger.StopSpring(e,t)}}},62353:(e,t,i)=>{i.d(t,{
U:()=>a})
var n=i(38962),s=i(75309),l=i(70181)
class a{constructor(){this.node=null,this.callbackID=-1,this.failureCallbackID=-1,this.LuaObjectID=0,this.OnDragEndCallBack=null,this.OnFailureCallback=null,this.data=null,
this.DragSource=null,this._degf_DragEndCallback=null,this._degf_FailureCallback=null,this.DragSource=new n.X,this._degf_DragEndCallback=(e,t)=>this.DragEndCallback(e,t),
this._degf_FailureCallback=(e,t)=>this.FailureCallback(e,t)}static Create(e,t,i,n,r=!1){const o=new a
return o.LuaObjectID=(()=>{const e=a.UI_DRAG_DROP_AUTO_ID
return a.UI_DRAG_DROP_AUTO_ID+=1,e})(),o.node=e,o.OnDragEndCallBack=i,o.OnFailureCallback=n,o.callbackID=s.n.AddCallBackVoidDelegate(o._degf_DragEndCallback),
null!=n&&(o.failureCallbackID=s.n.AddCallBackVoidDelegate(o._degf_FailureCallback)),a.UIDragDropItemDic.LuaDic_AddOrSetItem(o.LuaObjectID,o),
l._.AddComponent(e,t,o.LuaObjectID,o.callbackID,o.failureCallbackID,r),o}DragEndCallback(e,t){let i=null
i=a.UIDragDropItemDic[e],null!=i&&null!=this.OnDragEndCallBack&&this.OnDragEndCallBack(i,this)}FailureCallback(e,t){let i=null
i=a.UIDragDropItemDic[e],null!=i&&null!=this.OnFailureCallback&&this.OnFailureCallback(i)}SetInteractable(e){l._.SetInteractable(this.node,e)}SetRestrictPressAndHold(){
this.SetRestrict(4)}SetRestrict(e){}SetManualTrigger(e){}SetPressAndHoldDelay(e){}SetPressDragDis(e){}GetDraggedItemsCount(){}Dispose(){
a.UIDragDropItemDic.LuaDic_Remove(this.LuaObjectID),s.n.RemoveCallBackVoidDelegate(this.callbackID),s.n.RemoveCallBackVoidDelegate(this.failureCallbackID),this.data=null,
this.node=null,this.LuaObjectID=-1,this.OnDragEndCallBack=null,this.DragSource.LuaDic_Clear()}}a.UI_DRAG_DROP_AUTO_ID=0,a.UIDragDropItemDic=new n.X},67330:(e,t,i)=>{i.d(t,{b:()=>s
})
var n=i(60130)
class s{constructor(e){this.mPanel=null,this.mPanel=e,n.O.AddUIEffectSortOrderBind(this.mPanel)}AddChild(e){n.O.UIEffectSortOrderAddChild(this.mPanel,e)}UpdateRenders(){
n.O.UIEffectSortOrderUpdateRenderList(this.mPanel)}}},57834:(e,t,i)=>{i.d(t,{i:()=>l})
var n=i(18998),s=i(66788)
class l{constructor(){this.clickHandler=null,this._go=null,this._lastClickTime=0}static Get(e){if(null==e.__lualistener){const t=new l
t._go=e instanceof n.Node?e:e.node,e.__lualistener=t}return e.__lualistener}Clear(){this.clickHandler=null,this._lastClickTime=null,this._go&&this._go.offAll()}parameter(){return""
}parameterSet(e){}RegistonSubmit(e){}RemoveonSubmit(e){}CallonSubmit(e){}RegistonClick(e){
this._go&&(null!=this.clickHandler&&this.clickHandler!=e&&this.RemoveonClick(this.clickHandler),this.clickHandler=e,this._go.on(n.NodeEventType.TOUCH_END,e,this._go))}
ClearClickHandler(e){this._go&&this._go.off(n.NodeEventType.TOUCH_END,e,this._go),this.clickHandler==e&&(this.clickHandler=null)}RemoveonClick(e){
null!=this.clickHandler&&(this.clickHandler==e?(this.clickHandler=null,this._go&&this._go.off(n.NodeEventType.TOUCH_END,e,this._go)):s.Y.LogError("一个gameobject移除的回调和添加的不一样"))}
RegistonBeforeClick(e){this.RegistonClick(e)}RemoveonBeforeClick(e){this.RemoveonClick(e)}RegistonAfterClick(e){this.RegistonClick(e)}RemoveonAfterClick(e){this.RemoveonClick(e)}
CallonClick(e){}RegistonDoubleClick(e){this._go&&(this._lastClickTime=0,this.clickHandler&&this._go.off(n.NodeEventType.TOUCH_END,this.clickHandler,this._go),this.clickHandler=e,
this._go.on(n.NodeEventType.TOUCH_END,this._onDoubleClick,this))}RemoveonDoubleClick(e){this.clickHandler==e&&(this.clickHandler=null,
this._go&&this._go.off(n.NodeEventType.TOUCH_END,this._onDoubleClick,this))}_onDoubleClick(){this._lastClickTime>0&&cus.currTime-this._lastClickTime>400?(this._lastClickTime=0,
this.clickHandler&&this.clickHandler()):this._lastClickTime=cus.currTime}CallonDoubleClick(e){}RegistonHover(e){this._go&&this._go.on(n.NodeEventType.TOUCH_START,e,this._go)}
RemoveonHover(e){this._go&&this._go.off(n.NodeEventType.TOUCH_START,e,this._go)}CallonHover(e,t){}RegistonSelect(e){}RemoveonSelect(e){}CallonSelect(e,t){}RegistonScroll(e){}
RemoveonScroll(e){}CallonScroll(e,t){}RegistonDragStart(e){}RemoveonDragStart(e){}CallonDragStart(e){}RegistonDragOver(e){}RemoveonDragOver(e){}CallonDragOver(e){}
RegistonDragOut(e){}RemoveonDragOut(e){}CallonDragOut(e){}RegistonDragEnd(e){}RemoveonDragEnd(e){}CallonDragEnd(e){}RegistonKey(e){
this._go&&this._go.on(n.Input.EventType.KEY_UP,e,this)}RemoveonKey(e){this._go&&this._go.off(n.Input.EventType.KEY_UP,e,this)}CallonKey(e,t){}RegistonTooltip(e){}
RemoveonTooltip(e){}CallonTooltip(e,t){}RegistOnPress(e){}RemoveOnPress(e){}CallOnPress(e,t){}OnSubmit(){}OnClick(){}OnDoubleClick(){}OnHover(e){}OnPress(e){}OnSelect(e){}
OnScroll(e){}OnDragStart(){}OnDrag(e){}OnDragOver(){}OnDragOut(){}OnDragEnd(){}OnDrop(e){}OnKey(e){}OnTooltip(e){}}},69029:(e,t,i)=>{i.d(t,{z:()=>d})
var n=i(98130),s=i(85602),l=i(38962),a=i(96617),r=i(75309),o=i(30849)
class d extends o.C{constructor(){super(),this.submitCallbackIdDic=null,this.changeCallbackIdDic=null,this.submitCallbackIdDic=new l.X,this.changeCallbackIdDic=new l.X}
GetInputType(){return UIInputBridge.GetInputType(this.FatherId,this.ComponentId)}SetInputType(e){const t=n.GF.INT(e)
UIInputBridge.SetInputType(this.FatherId,this.ComponentId,t)}GetOnReturnKey(){return UIInputBridge.GetOnReturnKey(this.FatherId,this.ComponentId)}SetOnReturnKey(e){
const t=n.GF.INT(e)
UIInputBridge.SetOnReturnKey(this.FatherId,this.ComponentId,t)}GetKeyboardType(){return UIInputBridge.GetKeyboardType(this.FatherId,this.ComponentId)}SetKeyboardType(e){
const t=n.GF.INT(e)
UIInputBridge.SetKeyboardType(this.FatherId,this.ComponentId,t)}GetIsHideInput(){return UIInputBridge.GetIsHideInput(this.FatherId,this.ComponentId)}SetIsHideInput(e){
UIInputBridge.SetIsHideInput(this.FatherId,this.ComponentId,e)}GetIsSelectAllTextOnFocus(){return UIInputBridge.GetIsSelectAllTextOnFocus(this.FatherId,this.ComponentId)}
SetIsSelectAllTextOnFocus(e){UIInputBridge.SetIsSelectAllTextOnFocus(this.FatherId,this.ComponentId,e)}GetValidation(){
return UIInputBridge.GetValidation(this.FatherId,this.ComponentId)}SetValidation(e){const t=n.GF.INT(e)
UIInputBridge.SetValidation(this.FatherId,this.ComponentId,t)}GetCharacterLimit(){return UIInputBridge.GetCharacterLimit(this.FatherId,this.ComponentId)}SetCharacterLimit(e){
UIInputBridge.SetCharacterLimit(this.FatherId,this.ComponentId,e)}GetSavedAs(){return UIInputBridge.GetSavedAs(this.FatherId,this.ComponentId)}SetSavedAs(e){
UIInputBridge.SetSavedAs(this.FatherId,this.ComponentId,e)}AddSubmitEventHandler(e){const t=r.n.AddCallBackEventCallback(e)
this.submitCallbackIdDic.LuaDic_AddOrSetItem(e,t),UIInputBridge.AddSubmitEventHandler(this.FatherId,this.ComponentId,t)}RemoveSubmitEventHandler(e){
if(this.submitCallbackIdDic.LuaDic_ContainsKey(e)){const t=this.submitCallbackIdDic[e]
this.submitCallbackIdDic.LuaDic_Remove(e),r.n.RemoveCallBackEventCallback(t),UIInputBridge.RemoveSubmitEventHandler(this.FatherId,this.ComponentId,t)}}AddChangeEventHandler(e){
if(this.changeCallbackIdDic.LuaDic_ContainsKey(e))return
const t=r.n.AddCallBackEventCallback(e)
this.changeCallbackIdDic.LuaDic_AddOrSetItem(e,t),UIInputBridge.AddChangeEventHandler(this.FatherId,this.ComponentId,t)}RemoveChangeEventHandler(e){
if(this.changeCallbackIdDic.LuaDic_ContainsKey(e)){const t=this.changeCallbackIdDic[e]
this.changeCallbackIdDic.LuaDic_Remove(e),r.n.RemoveCallBackEventCallback(t),UIInputBridge.RemoveChangeEventHandler(this.FatherId,this.ComponentId,t)}}GetActiveTextColor(){
return UIInputBridge.GetActiveTextColor(this.FatherId,this.ComponentId)}SetActiveTextColor(e){const t=a.A.ColorToFloatArray(e)
UIInputBridge.SetActiveTextColor(this.FatherId,this.ComponentId,s.Z.GetTableOrNilFromLua(t))}GetCaretColor(){return UIInputBridge.GetCaretColor(this.FatherId,this.ComponentId)}
SetCaretColor(e){const t=a.A.ColorToFloatArray(e)
UIInputBridge.SetCaretColor(this.FatherId,this.ComponentId,s.Z.GetTableOrNilFromLua(t))}GetSelectionColor(){return UIInputBridge.GetSelectionColor(this.FatherId,this.ComponentId)}
SetSelectionColor(e){const t=a.A.ColorToFloatArray(e)
UIInputBridge.SetSelectionColor(this.FatherId,this.ComponentId,s.Z.GetTableOrNilFromLua(t))}GetNeedSelRestEncodeState(){
return UIInputBridge.GetNeedSelRestEncodeState(this.FatherId,this.ComponentId)}SetNeedSelRestEncodeState(e){
UIInputBridge.SetNeedSelRestEncodeState(this.FatherId,this.ComponentId,e)}GetDefaultText(){return UIInputBridge.GetDefaultText(this.FatherId,this.ComponentId)}SetDefaultText(e){
UIInputBridge.SetDefaultText(this.FatherId,this.ComponentId,e)}GetDefaultColor(){return UIInputBridge.GetDefaultColor(this.FatherId,this.ComponentId)}SetDefaultColor(e){
const t=a.A.ColorToFloatArray(e)
UIInputBridge.SetDefaultColor(this.FatherId,this.ComponentId,s.Z.GetTableOrNilFromLua(t))}GetIsInputShouldBeHidden(){
return UIInputBridge.GetIsInputShouldBeHidden(this.FatherId,this.ComponentId)}GetText(){return UIInputBridge.GetText(this.FatherId,this.ComponentId)}GetTextByteLength(){
return UIInputBridge.GetTextByteLength(this.FatherId,this.ComponentId)}SetText(e){UIInputBridge.SetText(this.FatherId,this.ComponentId,e)}GetValue(){
return UIInputBridge.GetValue(this.FatherId,this.ComponentId)}SetValue(e){UIInputBridge.SetValue(this.FatherId,this.ComponentId,e)}SetSymbolStr(e){
UIInputBridge.SetSymbolStr(this.FatherId,this.ComponentId,e)}Set(e,t){null==t&&(t=!0),UIInputBridge.Set(this.FatherId,this.ComponentId,e,t)}GetSelected(){
return UIInputBridge.GetSelected(this.FatherId,this.ComponentId)}SetSelected(e){UIInputBridge.SetSelected(this.FatherId,this.ComponentId,e)}GetIsSelected(){
return UIInputBridge.GetIsSelected(this.FatherId,this.ComponentId)}SetIsSelected(e){UIInputBridge.SetIsSelected(this.FatherId,this.ComponentId,e)}GetCursorPosition(){
return UIInputBridge.GetCursorPosition(this.FatherId,this.ComponentId)}SetCursorPosition(e){UIInputBridge.SetCursorPosition(this.FatherId,this.ComponentId,e)}GetSelectionStart(){
return UIInputBridge.GetSelectionStart(this.FatherId,this.ComponentId)}SetSelectionStart(e){UIInputBridge.SetSelectionStart(this.FatherId,this.ComponentId,e)}GetSelectedEnd(){
return UIInputBridge.GetSelectedEnd(this.FatherId,this.ComponentId)}SetSelectedEnd(e){UIInputBridge.SetSelectedEnd(this.FatherId,this.ComponentId,e)}Validate(e){
return UIInputBridge.Validate(this.FatherId,this.ComponentId,e)}Start(){UIInputBridge.Start(this.FatherId,this.ComponentId)}OnSelect(e){
UIInputBridge.OnSelect(this.FatherId,this.ComponentId,e)}Update(){UIInputBridge.Update(this.FatherId,this.ComponentId)}OnPress(e){
UIInputBridge.OnPress(this.FatherId,this.ComponentId,e)}OnDrag(e){UIInputBridge.OnDrag(this.FatherId,this.ComponentId,e.x,e.y)}Submit(){
UIInputBridge.Submit(this.FatherId,this.ComponentId)}UpdateLabel(){UIInputBridge.UpdateLabel(this.FatherId,this.ComponentId)}RemoveFocus(){
UIInputBridge.RemoveFocus(this.FatherId,this.ComponentId)}SaveValue(){UIInputBridge.SaveValue(this.FatherId,this.ComponentId)}LoadValue(){
UIInputBridge.LoadValue(this.FatherId,this.ComponentId)}}},93877:(e,t,i)=>{i.d(t,{Q:()=>r})
var n=i(85602),s=i(38045),l=i(96617),a=i(13113)
class r extends a.T{finalFontSize(){return UILabelBridge.finalFontSize(this.FatherId,this.ComponentId)}GetIsAnchoredHorizontally(){
return UILabelBridge.GetIsAnchoredHorizontally(this.FatherId,this.ComponentId)}GetIsAnchoredVertically(){
return UILabelBridge.GetIsAnchoredVertically(this.FatherId,this.ComponentId)}text(){return UILabelBridge.text(this.FatherId,this.ComponentId)}textSet(e){"number"==typeof e&&(e=(0,
s.tw)(e)),UILabelBridge.textSet(this.FatherId,this.ComponentId,e)}defaultFontSize(){return UILabelBridge.defaultFontSize(this.FatherId,this.ComponentId)}fontSize(){
return UILabelBridge.fontSize(this.FatherId,this.ComponentId)}fontSizeSet(e){UILabelBridge.fontSizeSet(this.FatherId,this.ComponentId,e)}applyGradient(){
return UILabelBridge.applyGradient(this.FatherId,this.ComponentId)}applyGradientSet(e){UILabelBridge.applyGradientSet(this.FatherId,this.ComponentId,e)}gradientTop(){
return UILabelBridge.gradientTop(this.FatherId,this.ComponentId)}gradientTopSet(e){const t=l.A.ColorToFloatArray(e)
UILabelBridge.gradientTopSet(this.FatherId,this.ComponentId,n.Z.GetTableOrNilFromLua(t))}gradientBottom(){return UILabelBridge.gradientBottom(this.FatherId,this.ComponentId)}
gradientBottomSet(e){const t=l.A.ColorToFloatArray(e)
UILabelBridge.gradientBottomSet(this.FatherId,this.ComponentId,n.Z.GetTableOrNilFromLua(t))}spacingX(){return UILabelBridge.spacingX(this.FatherId,this.ComponentId)}spacingXSet(e){
UILabelBridge.spacingXSet(this.FatherId,this.ComponentId,e)}spacingY(){return UILabelBridge.spacingY(this.FatherId,this.ComponentId)}spacingYSet(e){
UILabelBridge.spacingYSet(this.FatherId,this.ComponentId,e)}useFloatSpacing(){return UILabelBridge.useFloatSpacing(this.FatherId,this.ComponentId)}useFloatSpacingSet(e){
UILabelBridge.useFloatSpacingSet(this.FatherId,this.ComponentId,e)}floatSpacingX(){return UILabelBridge.floatSpacingX(this.FatherId,this.ComponentId)}floatSpacingXSet(e){
UILabelBridge.floatSpacingXSet(this.FatherId,this.ComponentId,e)}floatSpacingY(){return UILabelBridge.floatSpacingY(this.FatherId,this.ComponentId)}floatSpacingYSet(e){
UILabelBridge.floatSpacingYSet(this.FatherId,this.ComponentId,e)}effectiveSpacingY(){return UILabelBridge.effectiveSpacingY(this.FatherId,this.ComponentId)}effectiveSpacingX(){
return UILabelBridge.effectiveSpacingX(this.FatherId,this.ComponentId)}overflowEllipsis(){return UILabelBridge.overflowEllipsis(this.FatherId,this.ComponentId)}
overflowEllipsisSet(e){UILabelBridge.overflowEllipsisSet(this.FatherId,this.ComponentId,e)}overflowWidth(){return UILabelBridge.overflowWidth(this.FatherId,this.ComponentId)}
overflowWidthSet(e){UILabelBridge.overflowWidthSet(this.FatherId,this.ComponentId,e)}supportEncoding(){return UILabelBridge.supportEncoding(this.FatherId,this.ComponentId)}
supportEncodingSet(e){UILabelBridge.supportEncodingSet(this.FatherId,this.ComponentId,e)}multiLine(){return UILabelBridge.multiLine(this.FatherId,this.ComponentId)}multiLineSet(e){
UILabelBridge.multiLineSet(this.FatherId,this.ComponentId,e)}GetLocalCorners(){const e=UILabelBridge.GetLocalCorners(this.FatherId,this.ComponentId)
return l.A.ArrayToCList(e)}GetWorldCorners(){const e=UILabelBridge.GetWorldCorners(this.FatherId,this.ComponentId)
return l.A.ArrayToCList(e)}GetDrawingDimensions(){return UILabelBridge.GetDrawingDimensions(this.FatherId,this.ComponentId)}maxLineCount(){
return UILabelBridge.maxLineCount(this.FatherId,this.ComponentId)}maxLineCountSet(e){UILabelBridge.maxLineCountSet(this.FatherId,this.ComponentId,e)}effectColor(){
return UILabelBridge.effectColor(this.FatherId,this.ComponentId)}effectColorSet(e){const t=l.A.ColorToFloatArray(e)
UILabelBridge.effectColorSet(this.FatherId,this.ComponentId,n.Z.GetTableOrNilFromLua(t))}effectDistance(){return UILabelBridge.effectDistance(this.FatherId,this.ComponentId)}
effectDistanceSet(e){UILabelBridge.effectDistanceSet(this.FatherId,this.ComponentId,e.x,e.y)}quadsPerCharacter(){
return UILabelBridge.quadsPerCharacter(this.FatherId,this.ComponentId)}processedText(){return UILabelBridge.processedText(this.FatherId,this.ComponentId)}printedSize(){
return UILabelBridge.printedSize(this.FatherId,this.ComponentId)}GetLocalSize(){return UILabelBridge.GetLocalSize(this.FatherId,this.ComponentId)}printedText(){
return UILabelBridge.printedText(this.FatherId,this.ComponentId)}MarkAsChanged(){UILabelBridge.MarkAsChanged(this.FatherId,this.ComponentId)}MakePixelPerfect(){
UILabelBridge.MakePixelPerfect(this.FatherId,this.ComponentId)}AssumeNaturalSize(){UILabelBridge.AssumeNaturalSize(this.FatherId,this.ComponentId)}
GetCharacterIndexAtPositionVec3(e,t){return UILabelBridge.GetCharacterIndexAtPositionVec3(this.FatherId,this.ComponentId,e.x,e.y,e.z,t)}GetCharacterIndexAtPositionVec2(e,t){
return UILabelBridge.GetCharacterIndexAtPositionVec2(this.FatherId,this.ComponentId,e.x,e.y,t)}OnHover(e){UILabelBridge.OnHover(this.FatherId,this.ComponentId,e)}
GetUrlAtPositionVec3(e){return UILabelBridge.GetUrlAtPositionVec3(this.FatherId,this.ComponentId,e.x,e.y,e.z)}GetUrlAtPositionVec2(e){
return UILabelBridge.GetUrlAtPositionVec2(this.FatherId,this.ComponentId,e.x,e.y)}GetUrlAtCharacterIndex(e){
return UILabelBridge.GetUrlAtCharacterIndex(this.FatherId,this.ComponentId,e)}CalculateOffsetToFit(e){return UILabelBridge.CalculateOffsetToFit(this.FatherId,this.ComponentId,e)}
SubstringCalculateOffset(e,t,i){return UILabelBridge.SubstringCalculateOffset(this.FatherId,this.ComponentId,e,t,i)}SetCurrentProgress(){
UILabelBridge.SetCurrentProgress(this.FatherId,this.ComponentId)}SetCurrentPercent(){UILabelBridge.SetCurrentPercent(this.FatherId,this.ComponentId)}SetCurrentSelection(e){
UILabelBridge.SetCurrentSelection(this.FatherId,this.ComponentId,e)}Wrap(e,t,i){return null==i&&(i=1e6),UILabelBridge.Wrap(this.FatherId,this.ComponentId,e,t,this._degf_height)}
UpdateNGUIText(){UILabelBridge.UpdateNGUIText(this.FatherId,this.ComponentId)}SetAlignment(e){UILabelBridge.SetAlignment(this.FatherId,this.ComponentId,e)}SetGray(e){
UILabelBridge.SetGray(this.FatherId,this.ComponentId,e)}overflowMethod(){return UILabelBridge.overflowMethod(this.FatherId,this.ComponentId)}overflowMethodSet(e){
UILabelBridge.overflowMethodSet(this.FatherId,this.ComponentId,e)}effectStyle(){return UILabelBridge.effectStyle(this.FatherId,this.ComponentId)}effectStyleSet(e){
UILabelBridge.effectStyleSet(this.FatherId,this.ComponentId,e)}}},67292:(e,t,i)=>{i.d(t,{b:()=>I})
var n,s=i(18998),l=i(87923),a=i(86209),r=i(95721),o=i(35128),d=i(98885),h=i(85602),u=i(5924)
const{ccclass:c}=s._decorator
let I=c("LuaUILabelInteger")(n=class extends s.Label{constructor(){super(),this._numNow=0,this._numEnd=r.o.ZERO,this._step=0,this.timerId=0,this.m_isRandomValue=!1,
this.m_isParseChineseStr=!1,this.m_stepArr=null,this.m_delayTag=0,this.idx=0,this.count=-1,this.callback=null,this.m_isUseChineseCurrency=!1,this.m_canlesszero=!1,
this._degf_ChangeNumber=null,this.m_extraStr=null,this._numNowCopy=0,this._degf_ChangeNumber=()=>this.ChangeNumber()}NumNow_get(){return this._numNow}NumEnd_get(){
return this._numEnd}Step_get(){return this._step}ChangeFromTo(e,t,i,n,s,l,a,r,o){this.ChangeNumberFromTo(e.ToNum(),t.ToNum(),i,n,s,l,a,r,o)}ChangeNumberFromTo(e,t,i,n,s,o,h,c,I){
if(null==c&&(c=""),null==h&&(h=!1),null==o&&(o=!1),null==s&&(s=!1),null==I&&(I=!1),null==n&&(n=50),null==i&&(i=10),this.ChangeEnd(),this.m_isRandomValue=s,
this.m_isParseChineseStr=o,this.m_isUseChineseCurrency=h,this.m_canlesszero=I,this.m_extraStr=c,e==t)this.SetNumber(t)
else{this._numNow=this._numNowCopy=e,this._numEnd=r.o.FromNumber(t),s?this.SetRandomChangeValue(r.o.FromNumber(e),r.o.FromNumber(t),i):this._step=(t-e)/i
let o=""
o=this.m_isUseChineseCurrency?a.w.Instance.ConvertNumToString(this._numNow)+this.m_extraStr:this.m_isParseChineseStr?l.l.GetCopyExpChineseStringEX(this._numNow,this._numEnd.ToNum()>1e8):d.M.DoubleToString(this._numNow),
this.textSet(o),this.m_delayTag=0,this.idx=0,this.count=i,this.timerId=u.C.Inst_get().SetInterval(this._degf_ChangeNumber,n,i)}}SetRandomChangeValue(e,t,i){null==i&&(i=10)
let n=t.ToNum()-e.ToNum()
const s=n/i
if(this.m_stepArr=new h.Z,1==i)return void(this.m_stepArr[0]=s)
let l=0
for(;l<i-1;){const e=o.p.RandomMinMax(.9*s,1.1*s)
this.m_stepArr[l]=e,n-=e,l+=1}this.m_stepArr[i-1]=n}ChangeNumber(){if(this.timerId<=0)return
this.m_isRandomValue?(this._numNow+=this.m_stepArr[this.m_delayTag],this.m_delayTag+=1):this._numNow+=this._step,
this._numNow<0&&!this.m_canlesszero&&(this._numNow=this._numNowCopy=0)
const e=Math.round(this._numNow)
let t=""
t=this.m_isUseChineseCurrency?a.w.Instance.ConvertNumToString(e)+this.m_extraStr:this.m_isParseChineseStr?l.l.GetCopyExpChineseStringEX(e,this._numEnd.ToNum()>1e8):d.M.DoubleToString(e),
this.textSet(t),this.idx+=1,this.idx==this.count&&null!=this.callback&&this.callback()}SetNumber(e){const t=e
if(this._numNow==t)return
this._numNow=t
let i=""
i=this.m_isUseChineseCurrency?a.w.Instance.ConvertNumToString(this._numNow)+this.m_extraStr:this.m_isParseChineseStr?l.l.GetCopyExpChineseStringEX(this._numNow,this._numEnd.ToNum()>1e8):d.M.DoubleToString(this._numNow),
this.textSet(i)}Destroy(){this.ChangeEnd(),this.callback=null,super.destroy()}ChangeEnd(){0!=this.timerId&&(u.C.Inst_get().ClearInterval(this.timerId),this.timerId=0)}})||n},
8889:(e,t,i)=>{i.d(t,{$:()=>r})
var n=i(85602),s=i(34143),l=i(96617),a=i(21096)
class r extends a.w{showInPanelTool(){return UIPanelBridge.showInPanelTool(this.FatherId,this.ComponentId)}showInPanelToolSet(e){
UIPanelBridge.showInPanelToolSet(this.FatherId,this.ComponentId,e)}generateNormals(){return UIPanelBridge.generateNormals(this.FatherId,this.ComponentId)}generateNormalsSet(e){
UIPanelBridge.generateNormalsSet(this.FatherId,this.ComponentId,e)}generateUV2(){return UIPanelBridge.generateUV2(this.FatherId,this.ComponentId)}generateUV2Set(e){
UIPanelBridge.generateUV2Set(this.FatherId,this.ComponentId,e)}widgetsAreStatic(){return UIPanelBridge.widgetsAreStatic(this.FatherId,this.ComponentId)}widgetsAreStaticSet(e){
UIPanelBridge.widgetsAreStaticSet(this.FatherId,this.ComponentId,e)}cullWhileDragging(){return UIPanelBridge.cullWhileDragging(this.FatherId,this.ComponentId)}
cullWhileDraggingSet(e){UIPanelBridge.cullWhileDraggingSet(this.FatherId,this.ComponentId,e)}alwaysOnScreen(){return UIPanelBridge.alwaysOnScreen(this.FatherId,this.ComponentId)}
alwaysOnScreenSet(e){UIPanelBridge.alwaysOnScreenSet(this.FatherId,this.ComponentId,e)}anchorOffset(){return UIPanelBridge.anchorOffset(this.FatherId,this.ComponentId)}
anchorOffsetSet(e){UIPanelBridge.anchorOffsetSet(this.FatherId,this.ComponentId,e)}softBorderPadding(){return UIPanelBridge.softBorderPadding(this.FatherId,this.ComponentId)}
softBorderPaddingSet(e){UIPanelBridge.softBorderPaddingSet(this.FatherId,this.ComponentId,e)}startingRenderQueue(){
return UIPanelBridge.startingRenderQueue(this.FatherId,this.ComponentId)}startingRenderQueueSet(e){UIPanelBridge.startingRenderQueueSet(this.FatherId,this.ComponentId,e)}
drawCallClipRange(){return UIPanelBridge.drawCallClipRange(this.FatherId,this.ComponentId)}drawCallClipRangeSet(e){
UIPanelBridge.drawCallClipRangeSet(this.FatherId,this.ComponentId,e.x,e.y,e.z,e.w)}nextUnusedDepth(){return UIPanelBridge.nextUnusedDepth()}GetCanBeAnchored(){
return UIPanelBridge.GetCanBeAnchored(this.FatherId,this.ComponentId)}GetAlpha(){return UIPanelBridge.GetAlpha(this.FatherId,this.ComponentId)}SetAlpha(e){
UIPanelBridge.SetAlpha(this.FatherId,this.ComponentId,e)}depth(){return UIPanelBridge.depth(this.FatherId,this.ComponentId)}depthSet(e){
UIPanelBridge.depthSet(this.FatherId,this.ComponentId,e)}sortingOrder(){return UIPanelBridge.sortingOrder(this.FatherId,this.ComponentId)}sortingOrderSet(e){
UIPanelBridge.sortingOrderSet(this.FatherId,this.ComponentId,e)}width(){return UIPanelBridge.width(this.FatherId,this.ComponentId)}height(){
return UIPanelBridge.height(this.FatherId,this.ComponentId)}halfPixelOffset(){return UIPanelBridge.halfPixelOffset(this.FatherId,this.ComponentId)}usedForUI(){
return UIPanelBridge.usedForUI(this.FatherId,this.ComponentId)}clipCount(){return UIPanelBridge.clipCount(this.FatherId,this.ComponentId)}hasClipping(){
return UIPanelBridge.hasClipping(this.FatherId,this.ComponentId)}hasCumulativeClipping(){return UIPanelBridge.hasCumulativeClipping(this.FatherId,this.ComponentId)}clipOffset(){
return UIPanelBridge.clipOffset(this.FatherId,this.ComponentId)}clipOffsetSet(e){UIPanelBridge.clipOffsetSet(this.FatherId,this.ComponentId,e.x,e.y)}clipOffsetSetXY(e,t){
UIPanelBridge.clipOffsetSet(this.FatherId,this.ComponentId,e,t)}baseClipRegion(){return UIPanelBridge.baseClipRegion(this.FatherId,this.ComponentId)}baseClipRegionSet(e){
UIPanelBridge.baseClipRegionSet(this.FatherId,this.ComponentId,e.x,e.y,e.z,e.w)}baseClipRegionSetXYZW(e,t,i,n){
UIPanelBridge.baseClipRegionSet(this.FatherId,this.ComponentId,e,t,i,n)}finalClipRegion(){return UIPanelBridge.finalClipRegion(this.FatherId,this.ComponentId)}clipSoftness(){
return UIPanelBridge.clipSoftness(this.FatherId,this.ComponentId)}clipSoftnessSet(e){UIPanelBridge.clipSoftnessSet(this.FatherId,this.ComponentId,e.x,e.y)}GetLocalCorners(){
const e=UIPanelBridge.GetLocalCorners(this.FatherId,this.ComponentId)
return l.A.ArrayToCList(e)}GetWorldCorners(){const e=UIPanelBridge.GetWorldCorners(this.FatherId,this.ComponentId)
return l.A.ArrayToCList(e)}Invalidate(e){UIPanelBridge.Invalidate(this.FatherId,this.ComponentId,e)}CalculateFinalAlpha(e){
return UIPanelBridge.CalculateFinalAlpha(this.FatherId,this.ComponentId,e)}SetRect(e,t,i,n){UIPanelBridge.SetRect(this.FatherId,this.ComponentId,e,t,i,n)}IsVisible(e,t,i,s){
const a=l.A.Vector3ToFloatArray(e),r=l.A.Vector3ToFloatArray(t),o=l.A.Vector3ToFloatArray(i),d=l.A.Vector3ToFloatArray(s)
return UIPanelBridge.IsVisible(this.FatherId,this.ComponentId,n.Z.GetTableOrNilFromLua(a),n.Z.GetTableOrNilFromLua(r),n.Z.GetTableOrNilFromLua(o),n.Z.GetTableOrNilFromLua(d))}
IsVisibleWorldPos(e){return UIPanelBridge.IsVisibleWorldPos(this.FatherId,this.ComponentId,e.x,e.y,e.z)}RebuildAllDrawCalls(){
UIPanelBridge.RebuildAllDrawCalls(this.FatherId,this.ComponentId)}SetDirty(){UIPanelBridge.SetDirty(this.FatherId,this.ComponentId)}ParentHasChanged(){
UIPanelBridge.ParentHasChanged(this.FatherId,this.ComponentId)}SortWidgets(){UIPanelBridge.SortWidgets(this.FatherId,this.ComponentId)}Refresh(){
UIPanelBridge.Refresh(this.FatherId,this.ComponentId)}CalculateConstrainOffset(e,t){const i=l.A.Vector2ToFloatArray(e),s=l.A.Vector2ToFloatArray(t)
return UIPanelBridge.CalculateConstrainOffset(this.FatherId,this.ComponentId,n.Z.GetTableOrNilFromLua(i),n.Z.GetTableOrNilFromLua(s))}GetViewSize(){
return UIPanelBridge.GetViewSize(this.FatherId,this.ComponentId)}GetRect(){const e=this.node.transform.GetLocalPosition(),t=this.baseClipRegion(),i=e.x-t.z/2,n=e.y-t.w/2
return new s.U(i,n,t.z,t.w)}}},29562:(e,t,i)=>{i.d(t,{V:()=>s})
var n=i(16261)
class s extends n.X{}},3522:(e,t,i)=>{i.d(t,{k:()=>o})
var n,s=i(18998),l=i(38962),a=i(30849)
const{ccclass:r}=s._decorator
let o=r("LuaUIPlayAnimation")(n=class extends a.C{constructor(...e){super(...e),this.callbackIdDic=null}_initBinder(){super._initBinder(),this.callbackIdDic=new l.X}
SetClipName(e){}GetClipName(){return""}SetResetOnPlay(e){}GetResetOnPlay(){return!1}SetClearSelection(e){}GetClearSelection(){return!1}AddEventHandler(e){}RemoveEventHandler(e){}
Play(e,t){}Sample(e){}PlayForward(){}PlayReverse(){}ResumeAnim(e){}StopAnim(){}SetAnimProgress(e,t,i){}SetLoopEnable(e){}})||n},21096:(e,t,i)=>{i.d(t,{w:()=>l})
var n=i(96617),s=i(30849)
class l extends s.C{finalAlpha(){return UIRectBridge.finalAlpha(this.FatherId,this.ComponentId)}finalAlphaSet(e){UIRectBridge.finalAlphaSet(this.FatherId,this.ComponentId,e)}
isFullyAnchored(){return UIRectBridge.isFullyAnchored(this.FatherId,this.ComponentId)}GetIsAnchoredHorizontally(){
return UIRectBridge.GetIsAnchoredHorizontally(this.FatherId,this.ComponentId)}GetIsAnchoredVertically(){return UIRectBridge.GetIsAnchoredVertically(this.FatherId,this.ComponentId)}
GetCanBeAnchored(){return UIRectBridge.GetCanBeAnchored(this.FatherId,this.ComponentId)}isAnchored(){return UIRectBridge.isAnchored(this.FatherId,this.ComponentId)}GetAlpha(){
return UIRectBridge.GetAlpha(this.FatherId,this.ComponentId)}SetAlpha(e){UIRectBridge.SetAlpha(this.FatherId,this.ComponentId,e)}CalculateFinalAlpha(e){
return UIRectBridge.CalculateFinalAlpha(this.FatherId,this.ComponentId,e)}GetLocalCorners(){const e=UIRectBridge.GetLocalCorners(this.FatherId,this.ComponentId)
return n.A.ArrayToCList(e)}GetWorldCorners(){const e=UIRectBridge.GetWorldCorners(this.FatherId,this.ComponentId)
return n.A.ArrayToCList(e)}Invalidate(e){UIRectBridge.Invalidate(this.FatherId,this.ComponentId,e)}UpdateAnchors(){UIRectBridge.UpdateAnchors(this.FatherId,this.ComponentId)}
SetScreenRect(e,t,i,n){UIRectBridge.SetScreenRect(this.FatherId,this.ComponentId,e,t,i,n)}ResetAnchors(){UIRectBridge.ResetAnchors(this.FatherId,this.ComponentId)}
ResetAndUpdateAnchors(){UIRectBridge.ResetAndUpdateAnchors(this.FatherId,this.ComponentId)}SetRect(e,t,i,n){UIRectBridge.SetRect(this.FatherId,this.ComponentId,e,t,i,n)}
ParentHasChanged(){UIRectBridge.ParentHasChanged(this.FatherId,this.ComponentId)}SetAnchorTransform(e){UIRectBridge.SetAnchorTransform(this.FatherId,this.ComponentId,e)}}},
48592:(e,t,i)=>{i.d(t,{G:()=>s})
var n=i(30849)
class s extends n.C{GetScrollValue(){return UIScrollBarBridge.GetScrollValue(this.FatherId,this.ComponentId)}SetScrollValue(e){
UIScrollBarBridge.SetScrollValue(this.FatherId,this.ComponentId,e)}GetBarSize(){return UIScrollBarBridge.GetBarSize(this.FatherId,this.ComponentId)}SetBarSize(e){
UIScrollBarBridge.SetBarSize(this.FatherId,this.ComponentId,e)}ForceUpdate(){UIScrollBarBridge.ForceUpdate(this.FatherId,this.ComponentId)}}},71728:(e,t,i)=>{i.d(t,{L:()=>s})
var n=i(30849)
class s extends n.C{constructor(){super(),this.callDragStartIdDic=null,this.callDragFinishedIdDic=null,this.callDragingIdDic=null,this.callDragStartIdDic=new Dictionary,
this.callDragFinishedIdDic=new Dictionary,this.callDragingIdDic=new Dictionary}GetMovement(){return UIScrollViewBridge.GetMovement(this.FatherId,this.ComponentId)}SetMovement(e){
const t=e
UIScrollViewBridge.SetMovement(this.FatherId,this.ComponentId,t)}GetDragEffect(){return UIScrollViewBridge.GetDragEffect(this.FatherId,this.ComponentId)}SetDragEffect(e){const t=e
UIScrollViewBridge.SetDragEffect(this.FatherId,this.ComponentId,t)}GetRestrictWithinPanel(){return UIScrollViewBridge.GetRestrictWithinPanel(this.FatherId,this.ComponentId)}
SetRestrictWithinPanel(e){UIScrollViewBridge.SetRestrictWithinPanel(this.FatherId,this.ComponentId,e)}GetConstrainOnDrag(){
return UIScrollViewBridge.GetConstrainOnDrag(this.FatherId,this.ComponentId)}SetConstrainOnDrag(e){UIScrollViewBridge.SetConstrainOnDrag(this.FatherId,this.ComponentId,e)}
GetDisableDragIfFits(){return UIScrollViewBridge.GetDisableDragIfFits(this.FatherId,this.ComponentId)}SetDisableDragIfFits(e){
UIScrollViewBridge.SetDisableDragIfFits(this.FatherId,this.ComponentId,e)}GetSmoothDragStart(){return UIScrollViewBridge.GetSmoothDragStart(this.FatherId,this.ComponentId)}
SetSmoothDragStart(e){UIScrollViewBridge.SetSmoothDragStart(this.FatherId,this.ComponentId,e)}GetiOSDragEmulation(){
return UIScrollViewBridge.GetiOSDragEmulation(this.FatherId,this.ComponentId)}SetiOSDragEmulation(e){UIScrollViewBridge.SetiOSDragEmulation(this.FatherId,this.ComponentId,e)}
GetScrollWheelFactor(){return UIScrollViewBridge.GetScrollWheelFactor(this.FatherId,this.ComponentId)}SetScrollWheelFactor(e){
UIScrollViewBridge.SetScrollWheelFactor(this.FatherId,this.ComponentId,e)}GetMomentumAmount(){return UIScrollViewBridge.GetMomentumAmount(this.FatherId,this.ComponentId)}
SetMomentumAmount(e){UIScrollViewBridge.SetMomentumAmount(this.FatherId,this.ComponentId,e)}GetDampenStrength(){
return UIScrollViewBridge.GetDampenStrength(this.FatherId,this.ComponentId)}SetDampenStrength(e){UIScrollViewBridge.SetDampenStrength(this.FatherId,this.ComponentId,e)}
GetShowScrollBars(){return UIScrollViewBridge.GetShowScrollBars(this.FatherId,this.ComponentId)}SetShowScrollBars(e){const t=e
UIScrollViewBridge.SetShowScrollBars(this.FatherId,this.ComponentId,t)}GetCustomMovement(){return UIScrollViewBridge.GetCustomMovement(this.FatherId,this.ComponentId)}
SetCustomMovement(e){UIScrollViewBridge.SetCustomMovement(this.FatherId,this.ComponentId,e.x,e.y)}GetContentPivot(){
return UIScrollViewBridge.GetContentPivot(this.FatherId,this.ComponentId)}SetContentPivot(e){const t=e
UIScrollViewBridge.SetContentPivot(this.FatherId,this.ComponentId,t)}RegistonDragStarted(e){if(this.callDragStartIdDic.LuaDic_ContainsKey(e))return
const t=LuaCallBackMgr.AddCallBackOnDragStartNotification(e)
this.callDragStartIdDic.LuaDic_AddOrSetItem(e,t),UIScrollViewBridge.RegistonDragStarted(this.FatherId,this.ComponentId,t)}RemoveonDragStarted(e){
if(this.callDragStartIdDic.LuaDic_ContainsKey(e)){const t=this.callDragStartIdDic[e]
this.callDragStartIdDic.LuaDic_Remove(e),LuaCallBackMgr.RemoveCallBackOnDragNotification(t),UIScrollViewBridge.RemoveonDragStarted(this.FatherId,this.ComponentId,t)}}
CallonDragStarted(e){if(this.callDragStartIdDic.LuaDic_ContainsKey(e)){const t=this.callDragStartIdDic[e]
UIScrollViewBridge.CallonDragStarted(this.FatherId,this.ComponentId,t)}}RegiestGetSection(){}RegistonDragFinished(e){if(this.callDragFinishedIdDic.LuaDic_ContainsKey(e))return
const t=LuaCallBackMgr.AddCallBackOnDragFinishedNotification(e)
this.callDragFinishedIdDic.LuaDic_AddOrSetItem(e,t),UIScrollViewBridge.RegistonDragFinished(this.FatherId,this.ComponentId,t)}RemoveonDragFinished(e){
if(this.callDragFinishedIdDic.LuaDic_ContainsKey(e)){const t=this.callDragFinishedIdDic[e]
this.callDragFinishedIdDic.LuaDic_Remove(e),LuaCallBackMgr.RemoveCallBackOnDragFinishedNotification(t),UIScrollViewBridge.RemoveonDragFinished(this.FatherId,this.ComponentId,t)}}
CallonDragFinished(e){if(this.callDragFinishedIdDic.LuaDic_ContainsKey(e)){const t=this.callDragFinishedIdDic[e]
UIScrollViewBridge.CallonDragFinished(this.FatherId,this.ComponentId,t)}}RegistonDragingMoving(e){if(!this.callDragingIdDic.LuaDic_ContainsKey(e)){
const t=LuaCallBackMgr.AddCallBackOnDragingNotification(e)
this.callDragingIdDic.LuaDic_AddOrSetItem(e,t),UIScrollViewBridge.RegistonDragingMoving(this.FatherId,this.ComponentId,t)}}RemoveonDragingMoving(e){
if(this.callDragingIdDic.LuaDic_ContainsKey(e)){const t=this.callDragingIdDic[e]
this.callDragingIdDic.LuaDic_Remove(e),LuaCallBackMgr.RemoveCallBackOnDragingNotification(t),UIScrollViewBridge.RemoveonDragingMoving(this.FatherId,this.ComponentId,t)}}
RegistonStoppedMoving(e){if(this.callDragStartIdDic.LuaDic_ContainsKey(e))return
const t=LuaCallBackMgr.AddCallBackOnDragStartNotification(e)
this.callDragStartIdDic.LuaDic_AddOrSetItem(e,t),UIScrollViewBridge.RegistonStoppedMoving(this.FatherId,this.ComponentId,t)}RemoveonStoppedMoving(e){
if(this.callDragStartIdDic.LuaDic_ContainsKey(e)){const t=this.callDragStartIdDic[e]
this.callDragStartIdDic.LuaDic_Remove(e),LuaCallBackMgr.RemoveCallBackOnDragNotification(t),UIScrollViewBridge.RemoveonStoppedMoving(this.FatherId,this.ComponentId,t)}}
GetIsDragging(){return UIScrollViewBridge.GetIsDragging(this.FatherId,this.ComponentId)}canMoveHorizontally(){
return UIScrollViewBridge.canMoveHorizontally(this.FatherId,this.ComponentId)}canMoveVertically(){return UIScrollViewBridge.canMoveVertically(this.FatherId,this.ComponentId)}
shouldMoveHorizontally(){return UIScrollViewBridge.shouldMoveHorizontally(this.FatherId,this.ComponentId)}shouldMoveVertically(){
return UIScrollViewBridge.shouldMoveVertically(this.FatherId,this.ComponentId)}CheckScrollbars(){UIScrollViewBridge.CheckScrollbars(this.FatherId,this.ComponentId)}
RestrictWithinBounds(e,t,i){return null==i&&(i=!0),null==t&&(t=!0),UIScrollViewBridge.RestrictWithinBounds(this.FatherId,this.ComponentId,e,t,i)}DisableSpring(){
UIScrollViewBridge.DisableSpring(this.FatherId,this.ComponentId)}UpdateScrollbars(e){null==e&&(e=!0),UIScrollViewBridge.UpdateScrollbars(this.FatherId,this.ComponentId,e)}
SetDragAmount(e,t,i){UIScrollViewBridge.SetDragAmount(this.FatherId,this.ComponentId,e,t,i)}InvalidateBounds(){UIScrollViewBridge.InvalidateBounds(this.FatherId,this.ComponentId)}
ResetPosition(){UIScrollViewBridge.ResetPosition(this.FatherId,this.ComponentId)}UpdatePosition(){UIScrollViewBridge.UpdatePosition(this.FatherId,this.ComponentId)}OnScrollBar(e){
UIScrollViewBridge.OnScrollBar(this.FatherId,this.ComponentId,e)}MoveRelative(e){UIScrollViewBridge.MoveRelative(this.FatherId,this.ComponentId,e.x,e.y,e.z)}Press(e){
UIScrollViewBridge.Press(this.FatherId,this.ComponentId,e)}Drag(){UIScrollViewBridge.Drag(this.FatherId,this.ComponentId)}Scroll(e){
UIScrollViewBridge.Scroll(this.FatherId,this.ComponentId,e)}LateUpdate(){UIScrollViewBridge.LateUpdate(this.FatherId,this.ComponentId)}}},22370:(e,t,i)=>{i.d(t,{f:()=>o})
var n=i(98130),s=i(38962),l=i(75309),a=i(30849)
class r extends a.C{constructor(){super(),this.callbackIdDic=null,this.callFinishedbackIdDic=null,this.callbackIdDic=new s.X,this.callFinishedbackIdDic=new s.X}GetNumberOfSteps(){
return UIProgressBarBridge.GetNumberOfSteps(this.FatherId,this.ComponentId)}SetNumberOfSteps(e){UIProgressBarBridge.SetNumberOfSteps(this.FatherId,this.ComponentId,e)}
RegistonDragFinished(e){if(this.callFinishedbackIdDic.LuaDic_ContainsKey(e))return
const t=l.n.AddCallBackOnDragFinishedNotification(e)
this.callFinishedbackIdDic.LuaDic_AddOrSetItem(e,t),UIProgressBarBridge.RegistonDragFinished(this.FatherId,this.ComponentId,t)}RemoveonDragFinished(e){
if(this.callFinishedbackIdDic.LuaDic_ContainsKey(e)){const t=this.callFinishedbackIdDic[e]
this.callFinishedbackIdDic.LuaDic_Remove(e),l.n.RemoveCallBackOnDragFinishedNotification(t),UIProgressBarBridge.RemoveonDragFinished(this.FatherId,this.ComponentId,t)}}
CallonDragFinished(e){if(this.callFinishedbackIdDic.LuaDic_ContainsKey(e)){const t=this.callFinishedbackIdDic[e]
UIProgressBarBridge.CallonDragFinished(this.FatherId,this.ComponentId,t)}}AddEventHandler(e){if(this.callbackIdDic.LuaDic_ContainsKey(e))return
const t=l.n.AddCallBackEventCallback(e)
this.callbackIdDic.LuaDic_AddOrSetItem(e,t),UIProgressBarBridge.AddEventHandler(this.FatherId,this.ComponentId,t)}RemoveEventHandler(e){
if(this.callbackIdDic.LuaDic_ContainsKey(e)){const t=this.callbackIdDic[e]
this.callbackIdDic.LuaDic_Remove(e),l.n.RemoveCallBackEventCallback(t),UIProgressBarBridge.RemoveEventHandler(this.FatherId,this.ComponentId,t)}}GetFillDirection(){
return UIProgressBarBridge.GetFillDirection(this.FatherId,this.ComponentId)}SetFillDirection(e){const t=n.GF.INT(e)
UIProgressBarBridge.SetFillDirection(this.FatherId,this.ComponentId,t)}GetValue(){return UIProgressBarBridge.GetValue(this.FatherId,this.ComponentId)}SetValue(e){
UIProgressBarBridge.SetValue(this.FatherId,this.ComponentId,e)}GetAlpha(){return UIProgressBarBridge.GetAlpha(this.FatherId,this.ComponentId)}SetAlpha(e){
UIProgressBarBridge.SetAlpha(this.FatherId,this.ComponentId,e)}Set(e,t){null==t&&(t=!0),UIProgressBarBridge.Set(this.FatherId,this.ComponentId,e,t)}Start(){
UIProgressBarBridge.Start(this.FatherId,this.ComponentId)}Update(){UIProgressBarBridge.Update(this.FatherId,this.ComponentId)}ForceUpdate(){
UIProgressBarBridge.ForceUpdate(this.FatherId,this.ComponentId)}OnPan(e){UIProgressBarBridge.OnPan(this.FatherId,this.ComponentId,e.x,e.y)}}class o extends r{
isColliderEnabled(e,t){return UISliderBridge.isColliderEnabled(e,t)}GetSliderValue(e,t){return UISliderBridge.GetSliderValue(e,t)}SetSliderValue(e,t,i){
UISliderBridge.SetSliderValue(e,t,i)}GetInverted(e,t){return UISliderBridge.GetInverted(e,t)}SetInverted(e,t,i){UISliderBridge.SetInverted(e,t,i)}}},72005:(e,t,i)=>{i.d(t,{w:()=>l
})
var n=i(18202),s=i(87556)
class l extends s.j{spriteName(){return UISpriteBridge.spriteName(this.FatherId,this.ComponentId)}spriteNameSet(e){null==e&&(e=""),
UISpriteBridge.spriteNameSet(this.FatherId,this.ComponentId,e)}name(){return UISpriteBridge.name(this.FatherId,this.ComponentId)}nameSet(e){
UISpriteBridge.nameSet(this.FatherId,this.ComponentId,e)}isValid(){return UISpriteBridge.isValid(this.FatherId,this.ComponentId)}applyGradient(){
return UISpriteBridge.applyGradient(this.FatherId,this.ComponentId)}applyGradientSet(e){UISpriteBridge.applyGradientSet(this.FatherId,this.ComponentId,e)}GetBorder(){
return UISpriteBridge.GetBorder(this.FatherId,this.ComponentId)}GetPixelSize(){return UISpriteBridge.GetPixelSize(this.FatherId,this.ComponentId)}GetMinWidth(){
return UISpriteBridge.GetMinWidth(this.FatherId,this.ComponentId)}GetMinHeight(){return UISpriteBridge.GetMinHeight(this.FatherId,this.ComponentId)}GetDrawingDimensions(){
return UISpriteBridge.GetDrawingDimensions(this.FatherId,this.ComponentId)}GetPremultipliedAlpha(){return UISpriteBridge.GetPremultipliedAlpha(this.FatherId,this.ComponentId)}
MakePixelPerfect(){UISpriteBridge.MakePixelPerfect(this.FatherId,this.ComponentId)}SetSpriteType(e){UISpriteBridge.setSpriteType(this.FatherId,this.ComponentId,e)}GetSpriteType(){
return UISpriteBridge.getSpriteType(this.FatherId,this.ComponentId)}SetItemIcon(e,t,i,s,l){n.g.SetItemIcon(this.FatherId,this.ComponentId,e,t,i,s,l)}SetItemIconByAtlas(e,t,i,s,l){
n.g.SetItemIconByAtlas(this.FatherId,this.ComponentId,e,t,i,s,l)}EnableIconLightFlow(e){UISpriteBridge.EnableIconLightFlow(this.FatherId,this.ComponentId,e)}SetIconEquipName(e){
UISpriteBridge.SetIconEquipName(this.FatherId,this.ComponentId,e)}}},11355:(e,t,i)=>{i.d(t,{I:()=>r})
var n,s=i(18998),l=i(30849)
const{ccclass:a}=s._decorator
let r=a("LuaUISpriteAnimation")(n=class extends l.C{frameIndex(){return 0}frameIndexSet(e){}frames(){return 0}framesPerSecond(){return 0}framesPerSecondSet(e){}namePrefix(){
return""}namePrefixSet(e){}loop(){return!1}loopSet(e){}pixelSnapSet(e){}isPlaying(){return!1}RebuildSpriteList(){}StrCompAB(e,t){return 0}Play(){}Pause(){}ResetToBeginning(){}
useClientDataSet(e){}clientSpritePrefixSet(e){}clientLoopStartIndexSet(e){}clientLoopEndIndexSet(e){}clientLoopIndexDigitSet(e){}})||n},16261:(e,t,i)=>{i.d(t,{X:()=>l})
var n=i(18202),s=i(87556)
class l extends s.j{constructor(...e){super(...e),this.textureIdRGB=0,this.textureIdAlpha=0}GetPremultipliedAlpha(){
return UITextureBridge.GetPremultipliedAlpha(this.FatherId,this.ComponentId)}GetBorder(){return UITextureBridge.GetBorder(this.FatherId,this.ComponentId)}SetBorder(e){
UITextureBridge.SetBorder(this.FatherId,this.ComponentId,e.x,e.y,e.z,e.w)}GetDrawingDimensions(){return UITextureBridge.GetDrawingDimensions(this.FatherId,this.ComponentId)}
fixedAspect(){return UITextureBridge.fixedAspect(this.FatherId,this.ComponentId)}setSize(e,t){UITextureBridge.setSize(this.FatherId,this.ComponentId,e,t)}GetSize(){
return UITextureBridge.GetSize(this.FatherId,this.ComponentId)}fixedAspectSet(e){UITextureBridge.fixedAspectSet(this.FatherId,this.ComponentId,e)}MakePixelPerfect(){
UITextureBridge.MakePixelPerfect(this.FatherId,this.ComponentId)}SetMainTextureByPhoto(e){UITextureBridge.SetMainTextureByPhoto(this.FatherId,this.ComponentId,e)}
SetUVRect(e,t,i,n){UITextureBridge.SetUVRect(this.FatherId,this.ComponentId,e,t,i,n)}SetMainTexture(e,t,i){null==i&&(i=!1),null==t&&(t=0),this.DestroyTex(),this.textureIdRGB=e,
this.textureIdAlpha=t,UITextureBridge.SetMainTexture(this.FatherId,this.ComponentId,e,t,i)}DestroyTex(){0!=this.textureIdRGB&&(n.g.DestroyUIById(this.textureIdRGB),
this.textureIdRGB=0),0!=this.textureIdAlpha&&(n.g.DestroyUIById(this.textureIdAlpha),this.textureIdAlpha=0)}Destroy(){this.DestroyTex()}}},32208:(e,t,i)=>{i.d(t,{r:()=>a})
var n=i(38962),s=i(75309),l=i(30849)
class a extends l.C{constructor(){super(),this.callbackIdDic=null,this.callbackIdDic=new n.X}SetGroup(e){UIToggleBridge.SetGroup(this.FatherId,this.ComponentId,e)}GetGroup(){
return UIToggleBridge.GetGroup(this.FatherId,this.ComponentId)}SetInvertSpriteState(e){UIToggleBridge.SetInvertSpriteState(this.FatherId,this.ComponentId,e)}GetInvertSpriteState(){
return UIToggleBridge.GetInvertSpriteState(this.FatherId,this.ComponentId)}SetStartsActive(e){UIToggleBridge.SetStartsActive(this.FatherId,this.ComponentId,e)}GetStartsActive(){
return UIToggleBridge.GetStartsActive(this.FatherId,this.ComponentId)}SetInstantTween(e){UIToggleBridge.SetInstantTween(this.FatherId,this.ComponentId,e)}GetInstantTween(){
return UIToggleBridge.GetInstantTween(this.FatherId,this.ComponentId)}SetOptionCanBeNone(e){UIToggleBridge.SetOptionCanBeNone(this.FatherId,this.ComponentId,e)}
GetOptionCanBeNone(){return UIToggleBridge.GetOptionCanBeNone(this.FatherId,this.ComponentId)}AddEventHandler(e){if(this.callbackIdDic.LuaDic_ContainsKey(e))return
const t=s.n.AddCallBackEventCallback(e)
this.callbackIdDic.LuaDic_AddOrSetItem(e,t),UIToggleBridge.AddEventHandler(this.FatherId,this.ComponentId,t)}RemoveEventHandler(e){if(this.callbackIdDic.LuaDic_ContainsKey(e)){
const t=this.callbackIdDic[e]
this.callbackIdDic.LuaDic_Remove(e),s.n.RemoveCallBackEventCallback(t),UIToggleBridge.RemoveEventHandler(this.FatherId,this.ComponentId)}}GetValue(){
return UIToggleBridge.GetValue(this.FatherId,this.ComponentId)}SetValue(e){UIToggleBridge.SetValue(this.FatherId,this.ComponentId,e)}GetIsColliderEnabled(){
return UIToggleBridge.GetIsColliderEnabled(this.FatherId,this.ComponentId)}GetIsChecked(){return UIToggleBridge.GetIsChecked(this.FatherId,this.ComponentId)}SetIsChecked(e){
UIToggleBridge.SetIsChecked(this.FatherId,this.ComponentId,e)}Set(e,t){null==t&&(t=!0),UIToggleBridge.Set(this.FatherId,this.ComponentId,e,t)}}},84006:(e,t,i)=>{i.d(t,{k:()=>r})
var n=i(38962),s=i(38836),l=i(75309),a=i(30849)
class r extends a.C{constructor(){super(),this.callbackIdDic=null,this.callbackIdDic=new n.X}delay(){return UITweenerBridge.delay(this.FatherId,this.ComponentId)}delaySet(e){
UITweenerBridge.delaySet(this.FatherId,this.ComponentId,e)}duration(){return UITweenerBridge.duration(this.FatherId,this.ComponentId)}durationSet(e){
UITweenerBridge.durationSet(this.FatherId,this.ComponentId,e)}tweenGroup(){return UITweenerBridge.tweenGroup(this.FatherId,this.ComponentId)}tweenGroupSet(e){
UITweenerBridge.tweenGroupSet(this.FatherId,this.ComponentId,e)}tweenStyleSet(e){UITweenerBridge.tweenStyleSet(this.FatherId,this.ComponentId,e)}ResetToBeginning(){
UITweenerBridge.ResetToBeginning(this.FatherId,this.ComponentId)}Play(e){null==e&&(e=!0),UITweenerBridge.Play(this.FatherId,this.ComponentId,e)}PlayForward(){
UITweenerBridge.PlayForward(this.FatherId,this.ComponentId)}PlayReverse(){UITweenerBridge.PlayReverse(this.FatherId,this.ComponentId)}AddEventHandler(e){
if(this.callbackIdDic.LuaDic_ContainsKey(e))return
const t=l.n.AddCallBackEventCallback(e)
this.callbackIdDic.LuaDic_AddOrSetItem(e,t),UITweenerBridge.AddEventHandler(this.FatherId,this.ComponentId,t)}RemoveEventHandler(e){if(this.callbackIdDic.LuaDic_ContainsKey(e)){
const t=this.callbackIdDic[e]
this.callbackIdDic.LuaDic_Remove(e),l.n.RemoveCallBackEventCallback(t),UITweenerBridge.RemoveEventHandler(this.FatherId,this.ComponentId)}}SetStartToCurrentValue(){
UITweenerBridge.SetStartToCurrentValue(this.FatherId,this.ComponentId)}SetEndToCurrentValue(){UITweenerBridge.SetEndToCurrentValue(this.FatherId,this.ComponentId)}GetMethod(){
return UITweenerBridge.GetMethod(this.FatherId,this.ComponentId)}SetMethod(e){UITweenerBridge.SetMethod(this.FatherId,this.ComponentId,e)}Clear(){
if(null!=this.callbackIdDic)for(const[e,t]of(0,s.V5)(this.callbackIdDic)){const i=this.callbackIdDic[t]
this.callbackIdDic.LuaDic_Remove(e),l.n.RemoveCallBackEventCallback(i),UITweenerBridge.RemoveEventHandler(this.FatherId,this.ComponentId)}super.Clear()}}},13113:(e,t,i)=>{i.d(t,{
T:()=>a})
var n=i(85602),s=i(96617),l=i(21096)
class a extends l.w{constructor(){super(),this._degf_color=null,this._degf_height=null,this._degf_color=()=>this.color(),this._degf_height=()=>this.height()}
autoResizeBoxCollider(){return UIWidgetBridge.autoResizeBoxCollider(this.FatherId,this.ComponentId)}autoResizeBoxColliderSet(e){
UIWidgetBridge.autoResizeBoxColliderSet(this.FatherId,this.ComponentId,e)}hideIfOffScreen(){return UIWidgetBridge.hideIfOffScreen(this.FatherId,this.ComponentId)}
hideIfOffScreenSet(e){UIWidgetBridge.hideIfOffScreenSet(this.FatherId,this.ComponentId,e)}aspectRatio(){return UIWidgetBridge.aspectRatio(this.FatherId,this.ComponentId)}
aspectRatioSet(e){UIWidgetBridge.aspectRatioSet(this.FatherId,this.ComponentId,e)}fillGeometry(){return UIWidgetBridge.fillGeometry(this.FatherId,this.ComponentId)}
fillGeometrySet(e){UIWidgetBridge.fillGeometrySet(this.FatherId,this.ComponentId,e)}isForceRayHit(){return UIWidgetBridge.isForceRayHit(this.FatherId,this.ComponentId)}
isForceRayHitSet(e){UIWidgetBridge.isForceRayHitSet(this.FatherId,this.ComponentId,e)}pivotSet(e){UIWidgetBridge.pivotSet(this.FatherId,this.ComponentId,e)}GetPivot(){
return UIWidgetBridge.GetPivot(this.FatherId,this.ComponentId)}width(){return UIWidgetBridge.width(this.FatherId,this.ComponentId)}widthSet(e){
UIWidgetBridge.widthSet(this.FatherId,this.ComponentId,e)}height(){return UIWidgetBridge.height(this.FatherId,this.ComponentId)}heightSet(e){
UIWidgetBridge.heightSet(this.FatherId,this.ComponentId,e)}color(){return UIWidgetBridge.color(this.FatherId,this.ComponentId)}SetColor(e){
UIWidgetBridge.SetColor(this.FatherId,this.ComponentId,e._r,e._g,e._b,e._a)}SetColorRGBA(e,t,i,n){UIWidgetBridge.SetColor(this.FatherId,this.ComponentId,e,t,i,n)}GetAlpha(){
return UIWidgetBridge.GetAlpha(this.FatherId,this.ComponentId)}SetAlpha(e){UIWidgetBridge.SetAlpha(this.FatherId,this.ComponentId,e)}isVisible(){
return UIWidgetBridge.isVisible(this.FatherId,this.ComponentId)}hasVertices(){return UIWidgetBridge.hasVertices(this.FatherId,this.ComponentId)}depth(){
return UIWidgetBridge.depth(this.FatherId,this.ComponentId)}depthSet(e){UIWidgetBridge.depthSet(this.FatherId,this.ComponentId,e)}raycastDepth(){
return UIWidgetBridge.raycastDepth(this.FatherId,this.ComponentId)}GetLocalCorners(){const e=UIWidgetBridge.GetLocalCorners(this.FatherId,this.ComponentId)
return s.A.ArrayToCList(e)}GetLocalSize(){return UIWidgetBridge.GetLocalSize(this.FatherId,this.ComponentId)}localCenter(){
return UIWidgetBridge.localCenter(this.FatherId,this.ComponentId)}GetWorldCorners(){const e=UIWidgetBridge.GetWorldCorners(this.FatherId,this.ComponentId)
return s.A.ArrayToCList(e)}worldCenter(){return UIWidgetBridge.worldCenter(this.FatherId,this.ComponentId)}GetDrawingDimensions(){
return UIWidgetBridge.GetDrawingDimensions(this.FatherId,this.ComponentId)}hasBoxCollider(){return UIWidgetBridge.hasBoxCollider(this.FatherId,this.ComponentId)}SetDimensions(e,t){
UIWidgetBridge.SetDimensions(this.FatherId,this.ComponentId,e,t)}CalculateFinalAlpha(e){return UIWidgetBridge.CalculateFinalAlpha(this.FatherId,this.ComponentId,e)}Invalidate(e){
UIWidgetBridge.Invalidate(this.FatherId,this.ComponentId,e)}CalculateCumulativeAlpha(e){return UIWidgetBridge.CalculateCumulativeAlpha(this.FatherId,this.ComponentId,e)}
SetRect(e,t,i,n){UIWidgetBridge.SetRect(this.FatherId,this.ComponentId,e,t,i,n)}ResizeCollider(){UIWidgetBridge.ResizeCollider(this.FatherId,this.ComponentId)}SetDirty(){
UIWidgetBridge.SetDirty(this.FatherId,this.ComponentId)}RemoveFromPanel(){UIWidgetBridge.RemoveFromPanel(this.FatherId,this.ComponentId)}MarkAsChanged(){
UIWidgetBridge.MarkAsChanged(this.FatherId,this.ComponentId)}CheckLayer(){UIWidgetBridge.CheckLayer(this.FatherId,this.ComponentId)}ParentHasChanged(){
UIWidgetBridge.ParentHasChanged(this.FatherId,this.ComponentId)}UpdateVisibility(e,t){return UIWidgetBridge.UpdateVisibility(this.FatherId,this.ComponentId,e,t)}UpdateTransform(e){
return UIWidgetBridge.UpdateTransform(this.FatherId,this.ComponentId,e)}UpdateGeometry(e){return UIWidgetBridge.UpdateGeometry(this.FatherId,this.ComponentId,e)}MakePixelPerfect(){
UIWidgetBridge.MakePixelPerfect(this.FatherId,this.ComponentId)}GetMinWidth(){return UIWidgetBridge.GetMinWidth(this.FatherId,this.ComponentId)}GetMinHeight(){
return UIWidgetBridge.GetMinHeight(this.FatherId,this.ComponentId)}GetBorder(){return UIWidgetBridge.GetBorder(this.FatherId,this.ComponentId)}SetBorder(e){
const t=s.A.Vector4ToFloatArray(e)
UIWidgetBridge.SetBorder(this.FatherId,this.ComponentId,n.Z.GetTableOrNilFromLua(t))}SetChildrenDepth(e,t,i){UIWidgetBridge.SetChildrenDepth(e,t,i)}AddChildrenDepth(e,t,i){
UIWidgetBridge.AddChildrenDepth(e,t,i)}GetGrayState(){return UIWidgetBridge.GetGrayState(this.FatherId,this.ComponentId)}}},74147:(e,t,i)=>{i.d(t,{R:()=>a})
var n=i(85602),s=i(38962),l=i(38836)
class a{LoadTextureByUrl(e,t,i,s,l){null==i&&(i=0),null==s&&(s=0),null==l&&(l=0)
let r=!0
if(null!=t)if(a.loadCompleteHandlerDic.LuaDic_ContainsKey(e))-1==a.loadCompleteHandlerDic[e].IndexOf(t,0)?a.loadCompleteHandlerDic[e].Add(t):r=!1
else{const i=new n.Z
i.Add(t),a.loadCompleteHandlerDic.LuaDic_AddOrSetItem(e,i)}r&&UrlLoadTextureBridge.LoadTextureByUrl(e,i,s,l)}StopLoadAndDestoryByUrl(e,t,i){let n=!1
if(null!=t)if(null==e)for(const[e,i]of(0,l.V5)(a.loadCompleteHandlerDic))i.IndexOf(t,0)>-1&&(i.Remove(t),UrlLoadTextureBridge.StopLoadAndDestoryByUrl(e),n=!0)
else a.loadCompleteHandlerDic.LuaDic_ContainsKey(e)&&a.loadCompleteHandlerDic[e].IndexOf(t,0)>-1&&(a.loadCompleteHandlerDic[e].Remove(t),
UrlLoadTextureBridge.StopLoadAndDestoryByUrl(e),n=!0)
else null!=e&&a.loadCompleteHandlerDic.LuaDic_ContainsKey(e)&&a.loadCompleteHandlerDic[e].IndexOf(t,0)>-1&&(a.loadCompleteHandlerDic[e].Remove(t),
UrlLoadTextureBridge.StopLoadAndDestoryByUrl(e),n=!0)
i&&!n&&null!=e&&UrlLoadTextureBridge.StopLoadAndDestoryByUrl(e)}StopLoadCompleteByUrl(e,t){
if(null!=e)a.loadCompleteHandlerDic.LuaDic_ContainsKey(e)&&a.loadCompleteHandlerDic[e].IndexOf(t,0)>-1&&(a.loadCompleteHandlerDic[e].Remove(t),
UrlLoadTextureBridge.StopLoadCompleteByUrl(e))
else for(const[e,i]of(0,l.V5)(a.loadCompleteHandlerDic))i.IndexOf(t,0)>-1&&(i.Remove(t),UrlLoadTextureBridge.StopLoadCompleteByUrl(e))}DoLoadTextureCompleteFunc(e){
if(a.loadCompleteHandlerDic.LuaDic_ContainsKey(e))for(const[t,i]of(0,l.V5)(a.loadCompleteHandlerDic[e]))null!=i&&i()}SetTextureByUITexturenId(e,t,i){
UrlLoadTextureBridge.SetTextureByUITexturenId(e,t,i)}GetTextureWidthByUrl(e){return UrlLoadTextureBridge.GetTextureWidthByUrl(e)}GetTextureHeightByUrl(e){
return UrlLoadTextureBridge.GetTextureHeightByUrl(e)}}a.loadCompleteHandlerDic=new s.X},70181:(e,t,i)=>{i.d(t,{_:()=>I})
var n=i(18998),s=i(17409),l=i(81257),a=i(58087),r=i(38844),o=i(11294),d=i(38836),h=i(38045),u=i(75309),c=i(8125)
class I{static AddComponent(e,t,i,n,s,l=!1){this.dragNodeDic.LuaDic_AddOrSetItem(e,{cloneGo:t,luaObjectID:i,callbackID:n,failureCallbackID:s}),this.SetUpDrag(t,e),
l&&(this.searchNode=e.parent)}static SetInteractable(e,t){this.interactableDic.LuaDic_ContainsKey(e)&&this.interactableDic.LuaDic_Remove(e),
this.interactableDic.LuaDic_AddOrSetItem(e,t),this.UpdateInteractable()}static SetUpDrag(e,t,i){let s=e.getComponent(n.UITransform)
s||(s=e.addComponent(n.UITransform),s.setContentSize(5e3,5e3)),this.SetDragActiveOn(t,e)}static OnMove(e,t){const i=t.getDelta()
if(!this.isMoving&&Math.abs(i.x)<3&&Math.abs(i.y)<3)return
this.nowNode=e
let s=t.getLocation(),l=this.GetDragNodeParent()
l&&(this.moveAimPos=I.ConvertToNodeSpace(l,new n.Vec3(s.x,s.y,0)),console.log("UIDragDropItemBridge:","localNode worldPos:",l.getWorldPosition(),"touchPos:",s,"this.moveAimPos:",this.moveAimPos)),
this.ShowDragEff(t.target),this.isMoving=!0,t.preventSwallow=!1}static onGoMouseMove(e){if(this.isDragUp){this.isDragUp=!1
const t=this.dragNodeDic.LuaDic_GetItem(e.target),i=this.dragNodeDic.LuaDic_GetItem(this.nowNode)
t&&i&&t.luaObjectID!=i.luaObjectID?(this.isSuccess=!0,u.n.CallVoidDelegate(t.callbackID,i.luaObjectID)):t&&i&&t.luaObjectID!=i.luaObjectID?this.isSuccess=!1:this.isSuccess=!0}}
static ShowDragEff(e){this.dragNode&&this.isSameNode(this.dragNode,e)||this.InitDragNode(e),this.dragNode.transform.SetLocalPosition(this.moveAimPos),
console.log("[dragDropItem] this.moveAimPos:",this.moveAimPos)}static isSameNode(e,t){let i=e.getComponent(r.E),n=t.getComponent(r.E)
return!(!i||!n||i.skin!=n.skin)}static CloneNodeAtoB(e,t){return(t=(0,n.instantiate)(e)).parent=e.parent,t}static InitDragNode(e){
this.dragNode&&(this.dragNode.parent&&(this.dragNode.parent=null),this.dragNode&&this.dragNode.destroy(),this.dragNode=null),this.dragNode=this.CloneNodeAtoB(e,this.dragNode),
this.dragNode.parent=this.GetDragNodeParent()
const t=this.dragNode.getComponent(r.E),i=t.color
t.SetColor(new n.math.Color(i.r,i.b,i.g,127.5)),this.dragNode.on(n.NodeEventType.TOUCH_END,this.onDragMouseUp,this),
this.dragNode.on(n.NodeEventType.TOUCH_CANCEL,this.onDragMouseUp,this)}static onDragMouseUp(){if(this.isMoving){const e=this.dragNodeDic.LuaDic_GetItem(this.nowNode)
this.isSuccess=!1,setTimeout((()=>{this.isSuccess||u.n.CallVoidDelegate(e.failureCallbackID,e.luaObjectID)}),100),this.isDragUp=!0}this.dragNode&&(this.dragNode.parent=null,
this.dragNode&&this.dragNode.destroy(),this.dragNode=null),this.isMoving=!1}static OnTouchStart(e,t){this.SetScrollViewState(e,!1)}static GetDragNodeParent(){const e=(0,s.Z_)()
return e?e.parent:null}static UpdateInteractable(){for(const[e,t]of(0,d.V5)(this.interactableDic)){const i=this.dragNodeDic.LuaDic_GetItem(e)
e&&i&&i.cloneGo&&(0,h.t2)(e,n.Node)&&(0,h.t2)(i.cloneGo,n.Node)&&(t?this.SetDragActiveOn(e,i.cloneGo):this.SetDragActiveOff(e,i.cloneGo))}}static SetDragActiveOn(e,t){
t&&e&&t.on&&e.on&&(t.on(n.NodeEventType.TOUCH_START,this.OnTouchStart,this,!1,[e]),t.on(n.NodeEventType.TOUCH_MOVE,this.OnMove,this,!1,[e]),
t.on(n.NodeEventType.TOUCH_END,this.onTouchCancel,this),t.on(n.NodeEventType.TOUCH_CANCEL,this.onTouchCancel,this),e.on(n.NodeEventType.TOUCH_END,this.onTouchEnd,this),
c.T.addTouchMove((()=>{}),this,(()=>{this.onDragMouseUp(),this.onTouchEnd()})))}static SetDragActiveOff(e,t){
t&&e&&t.on&&e.on&&(t.off(n.NodeEventType.TOUCH_START,this.OnTouchStart,this),t.off(n.NodeEventType.TOUCH_MOVE,this.OnMove,this),
t.off(n.NodeEventType.TOUCH_END,this.onTouchCancel,this),t.off(n.NodeEventType.TOUCH_CANCEL,this.onTouchCancel,this),e.off(n.NodeEventType.MOUSE_MOVE,this.onGoMouseMove,this),
e.off(n.NodeEventType.TOUCH_END,this.onTouchEnd,this),c.T.removeTouchMove((()=>{}),this),this.dragNode&&(this.dragNode.off(n.NodeEventType.TOUCH_END,this.onDragMouseUp,this),
this.dragNode.off(n.NodeEventType.TOUCH_CANCEL,this.onDragMouseUp,this)))}static onTouchEnd(e){let t=new n.Vec2
if(t=e?e.getLocation():c.T.touchLocation,this.isDragUp){this.isDragUp=!1
const e=this.findTouchNode(t.x,t.y)
if(e){const t=this.dragNodeDic.LuaDic_GetItem(e),i=this.dragNodeDic.LuaDic_GetItem(this.nowNode)
t&&i&&t.luaObjectID!=i.luaObjectID?(this.isSuccess=!0,u.n.CallVoidDelegate(t.callbackID,i.luaObjectID)):t&&i&&t.luaObjectID!=i.luaObjectID?this.isSuccess=!1:this.isSuccess=!0}}}
static onTouchCancel(){this.onDragMouseUp(),this.onTouchEnd(),this.nowNode&&this.SetScrollViewState(this.nowNode,!0)}static findParentNode(e,t=o.E){let i=e
if(!i)return console.error("node is empty"),null
for(let e=0;e<20;e++){const e=i.parent
if(!e)return null
for(let i=e.components.length-1;i>=0;i--){const n=e.components[i]
if(n instanceof t)return n}i=e}return null}static findTouchNode(e,t){if(!this.searchNode)return null
return this._travelNode(e,t,this.searchNode)||null}static _travelNode(e,t,i){n.sys.getSafeAreaRect()
e=e/n.view.getVisibleSizeInPixel().width*n.view.getVisibleSize().width,t=t/n.view.getVisibleSizeInPixel().height*n.view.getVisibleSize().height
for(let s=i.children.length-1;s>=0;s--){const a=i.children[s]
if(a.active&&a.visible&&"INSPECTOR_NODE"!=a.name&&"RICHTEXT_CHILD"!=a.name&&"RICHTEXT_Image_CHILD"!=a.name&&a.opacity>0){const i=a.transform
if(i.width&&i.height){let s=!1
for(let e=a.components.length-1;e>=0;e--){const t=a.components[e]
if(t.enabled&&t instanceof l.n){s=!0
break}}if(s){if(i.getBoundingBoxToWorld(!0).contains(n.Vec2.TEMP.set(e,t)))return a}}}}return null}static SetScrollViewState(e,t){this.sview||(this.sview=this.findParentNode(e)),
this.sview&&(this.sview.enabled=t)}static ConvertToNodeSpace(e,t){const i=n.sys.getSafeAreaRect()
let s=new n.Vec3(0,0,0)
return s.x=(t.x-n.view.getVisibleSizeInPixel().width/2)/n.view.getVisibleSizeInPixel().width*n.view.getVisibleSize().width-i.x/2,
s.y=(t.y-n.view.getVisibleSizeInPixel().height/2)/n.view.getVisibleSizeInPixel().height*n.view.getVisibleSize().height,s}static ConvertToNodeSpace2(e,t){n.sys.getSafeAreaRect()
let i=new n.Vec3(0,0,0)
return i.x=e.x/n.view.getVisibleSizeInPixel().width*n.view.getVisibleSize().width,i.y=e.y/n.view.getVisibleSizeInPixel().height*n.view.getVisibleSize().height,
t&&(i.x=i.x-t.worldPosition.x,i.y=i.x-t.worldPosition.y),i}static Clear(){this.dragNode=null,this.dragNodeDic.Clear(),this.interactableDic.Clear(),this.lastTouchPos=null,
this.moveAimPos=null,this.isMoving=!1,this.nowNode=null,this.isDragUp=!1,this.isSuccess=!1,this.sview=null}}I.dragNode=null,I.dragNodeDic=new a.y,I.interactableDic=new a.y,
I.lastTouchPos=null,I.moveAimPos=null,I.isMoving=!1,I.nowNode=null,I.isDragUp=!1,I.isSuccess=!1,I.searchNode=null,I.sview=null},84473:(e,t,i)=>{i.d(t,{D:()=>n})
var n={eNormal:0,eHover:1,ePressed:2,eDisabled:3}},93701:(e,t,i)=>{i.d(t,{a:()=>h})
var n=i(39407),s=i(10781),l=i(98130),a=i(29567),r=i(5924),o=i(23407),d=i(4926)
class h{static get ins(){return null==h.inst&&(h.inst=new h),h.inst}constructor(){this._uidMap={},this._personIdUidMap={},this._attackSkillNum=0,this._waitKeyArr=[],
this._allCacheArr=new Array,this._layoutGroupCfg=null,this.effectMap={},this.increaseKey=0,h.MAX_SKILL_NUM=14,h.MAX_BUFF_NUM=8,h.MAX_ATTACK_SKILL_NUM=2}get effectCount(){
return INS.settingMainControl.curBuffNum+INS.settingMainControl.curEffNum}playActAndEffectsByData(e){
return this.playActAndEffects(e.source,e.target,e.effRole,e.act,e.cfgs,e.speedRate,e.isReleaseFrame,e.point,e.isGlobalPoint)}playActAndEffects(e,t,i,n,s,l=1,a,o=null,d=!1){
n&&e.SetAct(n)
const h=this.GetKey()
if(a){let n=this
r.C.Inst_get().SetInterval((function(){n.onDelayPlayActAndEffects(h,e,t,i,s,l,o,d)}),e.currentActReleaseTime,1)}else this.onDelayPlayActAndEffects(h,e,t,i,s,l,o,d)
return h}onDelayPlayActAndEffects(e,t,i,n,s,l=1,a=null,r=!1){for(let o=0;o<s.length;o++){const d=s[o]
this.showEffect(e,d,null,t,i,n,l,a,null,!1,-1,"",-1,1,!1,r)}}showEffectByIdx(e,t,i,n,s=1,l=null,a=null,r=!1,d=1,h=!1,u=!1,c=""){if(!e)return
var I
I=e.indexOf("_")>-1?[(I=e.split("_"))[Math.floor(Math.random()*I.length)]]:e.split(",")
const _=this.GetKey()
for(var p=0;p<I.length;++p){var S=I[p]
if(S){var g=o.r.ins.getEffectShowCfg(S,!1)
g&&this.showEffect(_,g,null,t,i,n,s,l,a,r,-1,c,-1,d,h,u)}}return _}showEffectByData(e){if(e&&e.cfgs&&e.cfgs.length>0){const t=this.GetKey()
for(let i=0;i<e.cfgs.length;i++){const n=e.cfgs[i]
this.showEffect(t,n,e,e.source,e.target,e.effRole,e.speedRate,e.point,e.effParent,e.ignorePause,e.isBuffEffect,e.uid,e.time,e.scale,e.calcNum,e.isGlobalPoint,e.floor)}return t}
return-1}showEffect(e,t,i,n,l,o,h=1,u=null,c=null,I=!1,_=-1,p="",S=-1,g=1,m=!1,f=!1,C=0){if(!t.effect)return void console.error("特效名不能为空,EffectShowResource--特效表,id:"+t.id)
const T=n?n.GetDirection():0,y=Math.floor(t.num.val)
p=""==p?`${t.id}_${cus.currTime}`:p
let A=0
for(let d=0;d<y;++d){
if(i&&i.source&&i.source.isPrimary&&i.source.isPlayer);else if(INS.settingMainControl.checkEffNum())return void console.error("showEffect--numLimited 特效资源id =="+t.id)
this._waitKeyArr.push(p),this._waitKeyArr.length>50&&console.error(`警告特效等待列表len：${this._waitKeyArr.length}`)
let y=(t.delayStart.val+t.delaySpace.val*d)*h
if(t.mulEffDelayArr&&t.mulEffDelayArr.length>0&&d>0){const e=t.mulEffDelayArr[d-1]
y=(t.delayStart.val+parseFloat(`${A}`)+parseFloat(`${e}`))*h,A=parseFloat(`${A}`)+parseFloat(`${e}`)}y>0&&(y=y*t.skillspeed/100)
const P=t.angleStart.val+t.angleSpace.val*d,w=t.offsetStart.val+t.offsetSpace.val*d,R=t.offsetRightStart.val+t.offsetRightSpace.val*d,D=t.offsetYStart.val+t.offsetYSpace.val*d
let L
L=t.scaleStart.val+t.scaleSpace.val*d,0==L&&(L=1)
let E=this
const B=a.x.createEffectShow()
if(B.m_onPlay=s.R.create(this,this.onEffectPlay,[_>=0,m]),B.m_onDestroy=s.R.create(this,this.onEffectDestroy,[_>=0,m]),B.m_onAddRoot=s.R.create(this,this.onEffectStart),B.m_key=e,
i&&(i.k=e),this.AddEffShowById(e,B),y>0){let s=r.C.Inst_get().SetInterval((function(){E.onDelayShowOneEffect(e,B,t,i,n,l,o,T,P,w,R,D,L,h,u,c,I,_,p,S,g,m,f,C,d+1)}),y,1)
B._delayId=s}else this.onDelayShowOneEffect(e,B,t,i,n,l,o,T,P,w,R,D,L,h,u,c,I,_,p,S,g,m,f,C,d+1)}function P(){let e=new d.E
return e.source=n,e.target=l,e.effRole=o,e.speedRate=h,e.point=u,e.effParent=c,e.ignorePause=I,e.isBuffEffect=_,e.uid=p,e.time=S,e.scale=g,e.calcNum=m,e.isGlobalPoint=f,e.floor=C,e
}if(t.effShowN)for(let e=0;e<t.effShowN.length;e++){let i=t.effShowN[e]
if(i==t.id){console.error("多段特效 循环播放了  id:"+i)
continue}let n=P()
n.SetCfg(i),this.showEffectByData(n)}if(t.effShowMirror>0&&(!i||0==i.mirrorType)){let e=P()
e.SetCfg(t.id),e.mirrorType=t.effShowMirror,this.showEffectByData(e)}}onDelayShowOneEffect(e,t,i,n,s,l,a,r,o,d,h,u,c,I,_=null,p=null,S=!1,g=-1,m="",f=-1,C=1,T=!1,y=!1,A=0,P=0){
const w=this._waitKeyArr.indexOf(m)
this._waitKeyArr.splice(w,1)
let R=""
if(g>=0){R=m.split("_")[2]}this._allCacheArr.indexOf(i.id)<0&&this._allCacheArr.push(i.id),null!=R&&""!=R&&(t.m_personIds=R),t.Play(i,n,s,l,a,r,o,d,h,u,c,I,_,p,S,g,f,C,y,A,P)}
onEffectPlay(e,t,i){const n=i.m_key,s=i.m_personIds
let l=this._uidMap[n]
l||(l=[]),l.push(i),this._uidMap[n]=l,e?INS.settingMainControl.curBuffNum++:i&&i._source&&i._source.isPrimary&&i._source.isPlayer?INS.settingMainControl.curPlayerEffNum++:INS.settingMainControl.curEffNum++,
t&&this._attackSkillNum++,n&&n>0&&s&&""!=s&&(l=this._personIdUidMap[s],l||(l=[]),l.push(n),this._personIdUidMap[s]=l)}onEffectDestroy(e,t,i){if(!i)return
const s=i.m_key,l=i.m_personIds
if((0,n.zM)(this._uidMap,s)){const n=this._uidMap[s],l=n.indexOf(i)
l>=0&&n.splice(l,1),n.length<=0&&delete this._uidMap[s],e?INS.settingMainControl.curBuffNum--:i&&i._source&&i._source.isPrimary&&i._source.isPlayer?INS.settingMainControl.curPlayerEffNum--:INS.settingMainControl.curEffNum--,
t&&this._attackSkillNum--}if(s&&s>0&&l&&""!=l&&(0,n.zM)(this._personIdUidMap,l)){const e=this._personIdUidMap[l],t=e.indexOf(s)
t>=0&&e.splice(t,1),e.length<=0&&delete this._personIdUidMap[l],this.layoutGroupEffect(l,i.cfg.layoutGroup)}
INS.settingMainControl.curBuffNum<0||INS.settingMainControl.curEffNum<0||this._attackSkillNum,i.m_key&&i.m_key>0&&delete this.effectMap[i.m_key]}onEffectStart(e){
if(e&&e.cfg&&e.cfg.layoutGroup>0){const t=e.m_personIds
this.layoutGroupEffect(t,e.cfg.layoutGroup)}}removeEffectByTag(e){for(let t=this._waitKeyArr.length-1;t>=0;t--)this._waitKeyArr[t].indexOf(e)>=0&&this._waitKeyArr.splice(t,1)
for(const t in this._uidMap)if(t.indexOf(e)>=0){let e=this._uidMap[t]
for(;e.length>0;){e.pop().smoothEnd()}}}removeEffectByUId(e){const t=this._waitKeyArr.indexOf(e)
if(t>=0&&this._waitKeyArr.splice(t,1),(0,n.zM)(this._uidMap,e)){const t=this._uidMap[e]
for(;t.length>0;){t.pop().smoothEnd()}}}removeBuffEffByRoleId(e){for(let t=this._waitKeyArr.length-1;t>=0;t--){this._waitKeyArr[t].indexOf(e)>=0&&this._waitKeyArr.splice(t,1)}
const t=this._personIdUidMap[e]
for(;t&&t.length>0;){const e=t.pop()
this.removeEffectByUId(e)}}clearTimer(e){r.C.Inst_get().ClearInterval(e)}clearAll(){this._waitKeyArr.length=0,this._personIdUidMap={},this._attackSkillNum=0
const e=this._uidMap
this._uidMap={}
for(const t in e){let i=e[t]
if(i)for(let e=0;e<i.length;++e)i[e].Destroy()}}layoutGroupEffect(e,t){let i,n,s,l=this._personIdUidMap[e],a=[]
if(l)for(let e=0;e<l.length;e++)if(s=l[e],n=this._uidMap[s],n)for(let e=0;e<n.length;e++)i=n[e],i&&i.cfg.layoutGroup==t&&a.push(i)
if(a.length>0){let e
a.sort((function(e,t){return e.cfg.layoutSort-t.cfg.layoutSort})),this._layoutGroupCfg||(this._layoutGroupCfg=[[0,0],[0,-25],[0,-50]])
for(let t=0;t<this._layoutGroupCfg.length;t++)i=a[t],e=this._layoutGroupCfg[t],i&&i._root&&(e?i.resetRootPos(e[0],e[1]):console.error("没找到对应坐标配置 i="+t))}}AddEffShowById(e,t){
let i=this.effectMap[e]
i||(i=[]),i.push(t),this.effectMap[e]=i}DeleteEffShowById(e){if(this.effectMap[e]){let t=this.effectMap[e]
for(let e=0;e<t.length;++e){t[e].Destroy()}delete this.effectMap[e]}return 0}GetKey(){return this.increaseKey>=l.GF.INT32_MAX_VALUE_get()&&(this.increaseKey=0),this.increaseKey+=1,
null!=this.effectMap[this.increaseKey]&&(this.increaseKey+=1),this.increaseKey}}h.inst=null,h.MAX_SKILL_NUM=20,h.MAX_BUFF_NUM=18,h.MAX_ATTACK_SKILL_NUM=10},4926:(e,t,i)=>{i.d(t,{
E:()=>a})
var n=i(57258),s=i(62265),l=i(23407)
class a{constructor(){this.k=-1,this.source=null,this.target=null,this.effRole=null,this.act=null,this.cfgs=null,this.speedRate=1,this.isReleaseFrame=!1,this.point=null,
this.isGlobalPoint=!1,this.effParent=null,this.ignorePause=!1,this.isBuffEffect=-1,this.uid="",this.time=-1,this.scale=1,this.calcNum=!1,this.floor=0,this.m_onPlay=null,
this.m_onDestroy=null,this.m_onAddRoot=null,this.mirrorType=0}SetCfg(e,t=!1){if(null==this.cfgs){this.cfgs=new Array
let t=l.r.ins.getEffectShowCfg(e,!1)
t&&this.cfgs.push(t)}else if(t){let t=l.r.ins.getEffectShowCfg(e,!1)
t&&this.cfgs.push(t)}else{this.cfgs=new Array
let t=l.r.ins.getEffectShowCfg(e,!1)
t&&this.cfgs.push(t)}}SetPoint(e,t){let[i,l]=(0,s.cH)(e,t)
null==this.point?this.point=new n.E(i,l):(this.point.x=i,this.point.y=l)}}},89632:(e,t,i)=>{i.d(t,{N:()=>n})
class n{static get ins(){return null==n.inst&&(n.inst=new n),n.inst}constructor(){this._topLayer=null,this._bottomLayer=null,this._topLayer=null,this._bottomLayer=null}}n.inst=null
},72359:(e,t,i)=>{i.d(t,{i:()=>a})
var n=i(38962),s=i(35128)
class l{constructor(){this.min=0,this.max=0,this.min=0,this.max=0}parseByString(e){if(!e)return this.max=0,void(this.min=0)
const t=e.split(",")
2==t.length?(this.min=Number(t[0]),this.max=Number(t[1])):(this.min=Number(t[0]),this.max=Number(t[0]))}parseByObject(e){e&&(this.min=e.min||0,this.max=e.max||0)}toString(){
return this.min>=this.max?this.min.toString():`${this.min.toString()},${this.max.toString()}`}get val(){
return this.min>=this.max?this.min:Math.floor(s.p.RandomMinMax(this.min,this.max))}}class a{constructor(){this.id=0,this.effect="",this.desc="",this.layer=0,this.num=new l,
this.time=new l,this.endStop=0,this.angleType=0,this.angleStart=new l,this.angleSpace=new l,this.offsetStart=new l,this.offsetSpace=new l,this.offsetRightStart=new l,
this.offsetRightSpace=new l,this.offsetXY="",this.offsetYStart=new l,this.offsetYSpace=new l,this.scaleStart=new l,this.scaleStart2=new l,this.scaleSpace=new l,
this.delayStart=new l,this.delaySpace=new l,this.ballType=0,this.ballParams="",this.perspective=0,this.skillspeed=65,this.fadeIn=null,this.fadeOut=null,this.ghost=null,
this.direction=0,this.onBody=0,this.color=0,this.transparency=0,this.layoutGroup=0,this.layoutSort=0,this.layoutEffect="",this.mulEffDelayArr=null,this.disable=0,this.actionTime=0,
this.weaponEffect=null,this.effShowMirror=0,this.effShowN=null,this.id=0}parseByCfg(e){if(this.id=e.id,this.effect=e.effect,this.layer=e.layer,this.num.parseByString(e.num),
this.time.parseByString(e.time),this.angleType=e.angleType||0,this.angleStart.parseByString(e.angleStart),this.angleSpace.parseByString(e.angleSpace),
this.offsetStart.parseByString(e.offsetStart),this.offsetSpace.parseByString(e.offsetSpace),this.offsetRightStart.parseByString(e.offsetRightStart),
this.offsetRightSpace.parseByString(e.offsetRightSpace),this.offsetXY=e.offsetXY,this.offsetYStart.parseByString(e.offsetYStart),this.offsetYSpace.parseByString(e.offsetYSpace),
this.scaleStart.parseByString(e.scaleStart),this.scaleStart2.parseByString(e.scaleStart2),this.scaleSpace.parseByString(e.scaleSpace),this.delayStart.parseByString(e.delayStart),
this.delaySpace.parseByString(e.delaySpace),this.ballType=e.ballType||0,this.skillspeed=e.skillspeed,this.ballParams=e.ballParams,this.perspective=e.perspective||0,
this.fadeIn=e.fadeIn,this.fadeOut=e.fadeOut,this.ghost=e.ghost,this.direction=e.direction,this.onBody=e.onBody,this.color=e.color,this.transparency=e.transparency/10,
this.layoutGroup=e.layoutGroup,this.layoutSort=e.layoutSort,this.layoutEffect=e.layoutEffect,
this.mulEffDelayArr=e.effectShowTimeGroup&&""!=e.effectShowTimeGroup?e.effectShowTimeGroup.split(","):[],this.disable=e.disable,this.actionTime=e.actionTime,e.weaponEffect){
this.weaponEffect=new n.X
let t=e.weaponEffect.split("|")
for(let e=0;e<t.length;e++){let i=t[e].split("_")
this.weaponEffect.LuaDic_Add(Number(i[0]),Number(i[1]))}}if(this.endStop=e.endStop,e.effShowN){this.effShowN=new Array
let t=e.effShowN.split("_")
for(let e=0;e<t.length;e++)this.effShowN.push(Number(t[e]))}return this.effShowMirror=e.effShowMirror,!0}parseByJson(e){if(!e)return
const t=e
this.id=t.id||0,this.effect=t.effect||"",this.desc=t.id||"",this.num.parseByObject(t.num),this.time.parseByObject(t.time),this.angleStart.parseByObject(t.angleStart),
this.angleSpace.parseByObject(t.angleSpace),this.offsetStart.parseByObject(t.offsetStart),this.offsetSpace.parseByObject(t.offsetSpace),
this.offsetRightStart.parseByObject(t.offsetRightStart),this.offsetRightSpace.parseByObject(t.offsetRightSpace),this.offsetXY=t.offsetXY||"",
this.offsetYStart.parseByObject(t.offsetYStart),this.offsetYSpace.parseByObject(t.offsetYSpace),this.scaleStart.parseByObject(t.scaleStart),
this.scaleSpace.parseByObject(t.scaleSpace),this.delayStart.parseByObject(t.delayStart),this.delaySpace.parseByObject(t.delaySpace),this.angleType=t.angleType||0,
this.ballType=t.ballType||0,this.skillspeed=t.skillspeed||0,this.ballParams=t.ballParams||"",this.perspective=t.perspective||0,this.fadeIn=t.fadeIn||[],this.fadeOut=t.fadeOut||[],
this.ghost=t.ghost,this.direction=t.direction,this.onBody=t.onBody,this.color=t.color,this.mulEffDelayArr=t.mulEffDelayArr,this.disable=t.disable,this.actionTime=t.actionTime,
this.weaponEffect=t.weaponEffect,this.endStop=t.endStop,this.effShowN=t.effShowN,this.effShowMirror=t.effShowMirror}toJson(){return JSON.stringify(this)}}},23407:(e,t,i)=>{i.d(t,{
r:()=>a})
var n=i(55360),s=i(93984),l=i(72359)
class a{static get ins(){return a.inst||(a.inst=new a),a.inst}constructor(){this.m_mapCSV=null,this._effectShowCfgs=void 0
const e=n.Y.Inst.GetOrCreateCsv(s.h.eEffectShowResource)
this.m_mapCSV=e.GetCsvMap()}getEffectShowCfg(e,t=!0){if(!e)return null
var i=this.effectShowCfgs[e]
return i||console.error("EFFECTSHOWRESOURCE表中不存在对应id=="+e+"的配置"),i}get effectShowCfgs(){if(!this._effectShowCfgs){this._effectShowCfgs={}
for(const t in this.m_mapCSV)if(Object.prototype.hasOwnProperty.call(this.m_mapCSV,t)){const i=this.m_mapCSV[t]
var e=new l.i
if(!e.parseByCfg(i))continue
this._effectShowCfgs[e.id.toString()]=e}}return this._effectShowCfgs}}a.inst=void 0}}])
