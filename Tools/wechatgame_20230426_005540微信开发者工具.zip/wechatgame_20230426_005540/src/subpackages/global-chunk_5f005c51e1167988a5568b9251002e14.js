"use strict";(globalThis.webpackChunkProject=globalThis.webpackChunkProject||[]).push([[136],{20052:(t,e,i)=>{i.d(e,{s:()=>M})
var s=i(56937),n=i(18202),a=i(31222),o=i(5494),l=i(52726),r=i(98789),h=i(52212),d=i(73341),u=i(38836),c=i(86133),_=i(38045),I=i(97461),g=i(5924),m=i(76544),C=i(9986),S=i(6665),p=i(61911),A=i(98885),f=i(85602),y=i(79534),T=i(21554),R=i(59686),v=i(75696),w=i(11562),D=i(23628),E=i(92679),L=i(22662),G=i(43308),O=i(65550),b=i(85942),B=i(79878),N=i(94026)
class P extends p.f{constructor(){super(),this.closeBtn=null,this.scrollGrid=null,this.handInBtn=null,this.buyOtherBtn=null,this.m_model=null,this.m_upModelId=0,
this.m_autoHandInTimer=0,this.m_consumeIds=null,this.m_needTipUpEquip=!1,this.delayExecutor=null,this.m_listData=null,this.m_itemPosList=null,this.m_gridBagItems=null,
this._degf_CloseDiaPanel=null,this._degf_DelayOpenAccessView=null,this._degf_ItemClickHandler=null,this._degf_OnBtnClick=null,this._degf_OnCreateItem=null,
this._degf_OnItemReposition=null,this._degf_OnTipShowComplete=null,this._degf_SendToServer=null,this._degf_UpdateByBagChanged=null,this.m_itemPosList=new f.Z,
this._degf_CloseDiaPanel=()=>this.CloseDiaPanel(),this._degf_DelayOpenAccessView=()=>this.DelayOpenAccessView(),this._degf_ItemClickHandler=t=>this.ItemClickHandler(t),
this._degf_OnBtnClick=(t,e)=>this.OnBtnClick(t,e),this._degf_OnCreateItem=t=>this.OnCreateItem(t),this._degf_OnItemReposition=()=>this.OnItemReposition(),
this._degf_OnTipShowComplete=t=>this.OnTipShowComplete(t),this._degf_SendToServer=t=>this.SendToServer(t),this._degf_UpdateByBagChanged=t=>this.UpdateByBagChanged(t)}InitView(){
this.closeBtn=new C.W,this.closeBtn.setId(this.FatherId,this.FatherComponentID,1),this.scrollGrid=new S.A,this.scrollGrid.setId(this.FatherId,this.FatherComponentID,2),
this.scrollGrid.SetInitInfo("ui_baseitem",this._degf_OnCreateItem),this.scrollGrid.OnReposition_set(this._degf_OnItemReposition),this.handInBtn=new C.W,
this.handInBtn.setId(this.FatherId,this.FatherComponentID,3),this.buyOtherBtn=new C.W,this.buyOtherBtn.setId(this.FatherId,this.FatherComponentID,4),this.isExclusionPanel=!0,
this.delayExecutor=new m.p}Destroy(){this.closeBtn=null,this.scrollGrid.Destroy(),this.scrollGrid=null,this.handInBtn=null,this.buyOtherBtn=null,this.delayExecutor=null}
OnAddToScene(){this.AddOrDelEvent(!0),this.DoUpate()}Clear(){this.RevertPos(),T.J.Inst_get().isJudgeItemTipOperate=!0,T.J.Inst_get().isJudgeItemTipCompare=!0,
T.J.Inst_get().CloseTipView(),this.AddOrDelEvent(!1),this.delayExecutor.Clear(),G._.Inst_get().CloseView(),g.C.Inst_get().ClearInterval(this.m_autoHandInTimer),
this.m_consumeIds=null,this.SetForBag(!0),this.m_listData=null}SetForBag(t){if(null!=this.m_listData)for(const[e,i]of(0,u.V5)(this.m_listData))i.baseData_get().isForBag=t}
AddOrDelEvent(t){t?(B.Y.RegLuaClick(this.handInBtn.node,this._degf_OnBtnClick),B.Y.RegLuaClick(this.buyOtherBtn.node,this._degf_OnBtnClick),
B.Y.RegLuaClick(this.closeBtn.node,this._degf_OnBtnClick),I.i.Inst.AddEventHandler(E.g.TIP_VIEW_UPDATE_DATA,this._degf_OnTipShowComplete),
I.i.Inst.AddEventHandler(E.g.BAG_UPDATE,this._degf_UpdateByBagChanged)):(B.Y.DelLuaClick(this.handInBtn.node,this._degf_OnBtnClick),
B.Y.DelLuaClick(this.buyOtherBtn.node,this._degf_OnBtnClick),B.Y.DelLuaClick(this.closeBtn.node,this._degf_OnBtnClick),
I.i.Inst.RemoveEventHandler(E.g.TIP_VIEW_UPDATE_DATA,this._degf_OnTipShowComplete),I.i.Inst.RemoveEventHandler(E.g.BAG_UPDATE,this._degf_UpdateByBagChanged))}OnBtnClick(t,e){
if(this.handInBtn.ComponentId==t)if(this.m_consumeIds=this.GetSelectedIds(),this.m_needTipUpEquip){const t=new b.N
t.showText=(0,c.T)("该装备比您身上的装备好，是否确认上交？"),t.okhandler=this._degf_SendToServer,t.tipstype=2,O.y.inst.OpenCommonMessageTips(t)}else this.SendToServer(null)
else this.buyOtherBtn.ComponentId==t?G._.Inst_get().IsOpen()?G._.Inst_get().CloseView():this.OpenAccessView():this.closeBtn.ComponentId==t&&M.Inst_get().Close()}
OnTipShowComplete(t){if((0,_.t2)(t,w.d)){const e=t
e.SetBtnShowState(e.useBtn,!1),e.SetBtnShowState(e.sellBtn,!1),e.SetButtonState()}}UpdateByBagChanged(t){this.DoUpate()}DoUpate(){if(T.J.Inst_get().isJudgeItemTipOperate=!1,
T.J.Inst_get().isJudgeItemTipCompare=!1,this.m_model=d.F.Inst_get().model.selectFunModel,
null!=this.m_model&&(this.m_listData=N.e.Inst_get().GetHandInDataList(this.m_model.taskConfig),this.SetPosList(this.m_listData),this.SetForBag(!1),
this.scrollGrid.data_set(this.m_listData),0==this.scrollGrid.data_get().Count())){const t=this.m_model.taskConfig.tCTargetDefs_get().tCTargetDefs[0]
this.m_upModelId=A.M.String2Int(t.param.itemModelId),this.OpenAccessView()}}SetPosList(t){this.m_gridBagItems=t,this.m_itemPosList.Clear()
const e=new y.P(-230,-21)
let i=0
for(;i<t.Count();){const s=t[i]
this.m_itemPosList.Add(s.baseData_get().tipsPos),s.baseData_get().tipsPos=e,s.baseData_get().tipPosType=R.l.Default,i+=1}}RevertPos(){
if(null!=this.m_gridBagItems&&this.m_gridBagItems.Count()>0){let t=0
for(;t<this.m_gridBagItems.Count();){this.m_gridBagItems[t].baseData_get().tipsPos=this.m_itemPosList[t],t+=1}this.m_gridBagItems.Clear(),this.m_itemPosList.Clear(),
this.m_gridBagItems=null,this.m_itemPosList=null}}OnCreateItem(t){const e=new v.j
return e.setId(t,null,0),e.ClickHandler_Set(this._degf_ItemClickHandler),e}ItemClickHandler(t){t.setSelected(!t.selected),G._.Inst_get().CloseView()}OnItemReposition(){}
OpenAccessView(){G._.Inst_get().IsOpen()||(T.J.Inst_get().isItemTipShow_get()?this.delayExecutor.Invoke(this._degf_DelayOpenAccessView,50):this.DelayOpenAccessView())}
DelayOpenAccessView(){const t=this.m_model.taskConfig.GetAccessData(),e=new y.P(-203,34,0)
G._.Inst_get().OpenByWay(t,e,this.m_upModelId)}GetSelectedIds(){this.m_needTipUpEquip=!1
let t=null
const e=this.scrollGrid.itemList
let i=e.Count()
if(i>0){t=new f.Z
let s=0
for(;s<i;){const i=e[s]
i.selected&&(t.Add(i.bagItemData_get().serverData_get().id),this.SetUpScoreEquip(i)),s+=1}}let s=null
if(null!=t){i=t.Count(),s=new f.Z
let e=0
for(;e<i;)s[e]=t[e],e+=1}return s}SetUpScoreEquip(t){
"EQUIPMENT"==t.BaseData_get().cfgData_get().itemType&&(this.m_needTipUpEquip=D.b.IsRecommendForAllRole(t.bagItemData_get().baseData_get()))}SendToServer(t){
if(null==this.m_consumeIds||0==this.m_consumeIds.count)return void O.y.inst.ClientStrMsg(L.r.SystemTipMessage,(0,c.T)("请选择上交的物品"))
this.m_model.taskConfig.GetIntersectionType()
M.Inst_get().Close(),g.C.Inst_get().SetInterval(this._degf_CloseDiaPanel,100,1)}CloseDiaPanel(){d.F.Inst_get().control.ForceClose()}}class M{constructor(){this.view=null,
this._degf_CallComplete=null,this._degf_CallDestory=null,this._degf_CallComplete=t=>this.CallComplete(t),this._degf_CallDestory=()=>this.CallDestory()}static Inst_get(){
return null==M._inst&&(M._inst=new M),M._inst}Open(){if(null==d.F.Inst_get().model.selectFunModel)return
const t=new s.v
t.isShowMask=!0,t.layerType=l.F.Alert,t.positionType=r.$.eRightBottom,t.pos=new h.F(-6,67).Clone(),
a.N.inst.OpenById(o.I.HandInPanel,this._degf_CallComplete,this._degf_CallDestory,t)}Close(){a.N.inst.CloseById(o.I.HandInPanel)}CallComplete(t){
return null==this.view&&(this.view=new P,this.view.setId(t,null,0)),this.view}CallDestory(){n.g.DestroyUIObj(this.view),this.view=null}}M._inst=null},37189:(t,e,i)=>{i.d(e,{o:()=>c
})
var s=i(32076),n=i(56937),a=i(18202),o=i(31222),l=i(5494),r=i(52726),h=i(98789),d=i(35918),u=i(44798)
class c{constructor(){this.HandItemView=null}static Inst_get(){return null==c._inst&&(c._inst=new c),c._inst}OpenHandInItemView(t){if(d.j.Inst_get().CurHandInItemData=t,
null!=this.HandItemView&&this.HandItemView.isShow_get())this.HandItemView.OnAddToScene()
else{const t=new n.v
t.isShowMask=!0,t.layerType=r.F.Alert,t.positionType=h.$.eCenter,o.N.inst.OpenById(l.I.HandInItemView,(0,s.v)(this.HandInItemViewComplete,this),(0,
s.v)(this.HandInItemDestory,this),t)}}CloseHandInItemView(){o.N.inst.CloseById(l.I.HandInItemView)}HandInItemViewComplete(t){
return null==this.HandItemView&&(this.HandItemView=new u.K,this.HandItemView.setId(t,null,0)),this.HandItemView}HandInItemDestory(){a.g.DestroyUIObj(this.HandItemView),
this.HandItemView=null}}c._inst=null},90156:(t,e,i)=>{i.d(e,{L:()=>h})
var s=i(66788),n=i(63076),a=i(70093),o=i(59686),l=i(87923),r=i(48481)
class h{constructor(){this.ItemId=0,this.BaseItemData=null,this.CurNum=0,this.NeedNum=0,this.TaskId=0,this.isHelpOther=!1,this.OhterPlayerId=null,this.OhterName="",this.assId=0}
InitData(t,e,i,l,h,d,u,c){if(0==t)return
e<0&&(e=0),i<0&&(i=0),null==l&&(l=0),e>i&&(e=i,s.Y.LogError(`curnum > neednum ${e} ${i}`))
const _=new r.t
_.modelId=t,this.ItemId=t,this.BaseItemData=new n.M(t,_),this.BaseItemData.limitNum=i-e,this.BaseItemData.btnType=a.p.GetWay,this.BaseItemData.tipPosType=o.l.GetWay,this.CurNum=e,
this.NeedNum=i,this.TaskId=l,this.isHelpOther=h,this.OhterPlayerId=d,this.OhterName=u,this.assId=c}GetShowDecs(){
let t=!1,e=`上交1个${l.l.SetStringColorByQuality(this.BaseItemData.Quality_get(),this.BaseItemData.cfgData_get().name)}`
return this.isHelpOther&&!l.l.IsEmptyStr(this.OhterName)&&(e=`[协助] ${this.OhterName}\n${e}`,t=!0),[e,t]}}},94026:(t,e,i)=>{i.d(e,{e:()=>y})
var s=i(38836),n=i(38045),a=i(98800),o=i(62370),l=i(98885),r=i(85602),h=i(1240),d=i(70850),u=i(59918),c=i(71143),_=i(33314),I=i(87923),g=i(44498),m=i(5268),C=i(42534),S=i(33138),p=i(89803),A=i(68965)
class f{}f.HandInItemId="HandItem",f.HandInItemType="HandItemType",f.HandInGroup="HandGroup",f.HandInEquipmentTypeAndStepLv="HandEquipmentTypeAndStepLv"
class y{constructor(){this.handInTarget=null,this.selectIdxList=null,this.m_needParam=0,this.bData=null,this.m_equipIndexList=null,this._degf_SortByQualityAndLevel=null,
this.selectIdxList=new r.Z,this.m_equipIndexList=new r.Z,this._degf_SortByQualityAndLevel=(t,e)=>this.SortByQualityAndLevel(t,e)}static Inst_get(){
return null==y._inst&&(y._inst=new y),y._inst}GetItemTypeList(t){const e=new r.Z,i=d.g.Inst_get().GetAllItem()
for(const[n,a]of(0,s.V5)(i))a.baseData_get().cfgData_get().itemType==t&&e.Add(a)
return e}GetEquipTypeAndStepList(t,e){const i=new r.Z,n=d.g.Inst_get().GetAllItem()
for(const[a,o]of(0,s.V5)(n))if(o.baseData_get().isEquip_get()){this.IsEnoughEquipTypeAndStep(o.baseData_get().modelId_get(),t,e)&&i.Add(o)}return i}GetGroupList(t){
const e=new r.Z,i=d.g.Inst_get().GetAllItem()
for(const[n,a]of(0,s.V5)(i))a.baseData_get().cfgData_get().itemGroupId==t&&e.Add(a)
return e}GetHandInDataList(t){let e=new r.Z,i=0
const n=t.completeConsumsInfo_get()
if(0!=n.rewardValues.Count()){const t=n.rewardValues[0],s=l.M.Split(t.value,o.o.s_Arr_UNDER_COLON)
if(t.type==f.HandInItemId){const t=l.M.String2Int(s[0])
i=l.M.String2Int(s[1]),e=d.g.Inst_get().GetAllItem(t),e.Sort(this._degf_SortByQualityAndLevel)}else if(t.type==f.HandInItemType){const t=s[0]
i=l.M.String2Int(s[1]),e=this.GetItemTypeList(t),e.Sort(this._degf_SortByQualityAndLevel)}else if(t.type==f.HandInEquipmentTypeAndStepLv){const t=s[0],n=l.M.String2Int(s[1])
i=l.M.String2Int(s[2]),e=this.GetEquipTypeAndStepList(t,n),this.SortBySocre(e)}else if(t.type==f.HandInGroup){const t=l.M.String2Int(s[0])
i=l.M.String2Int(s[1]),e=this.GetGroupList(t),e.Sort(this._degf_SortByQualityAndLevel)}}this.selectIdxList.Clear()
let a=0
for(;a<e.Count();){const t=e[a]
i>0&&(i-=t.serverData_get().num,this.selectIdxList.Add(a)),a+=1}const h=new r.Z
let u=null
for(const[t,i]of(0,s.V5)(e))u=i,null!=u&&null!=u.baseData_get()&&u.baseData_get().IsNoAuctionAndAppraisal()&&h.Add(i)
return h}SortByQualityAndLevel(t,e){const i=t,s=e,n=i.baseData_get().cfgData_get(),a=s.baseData_get().cfgData_get()
return I.l.GetQuality(i.baseData_get())!=I.l.GetQuality(s.baseData_get())?I.l.GetQuality(i.baseData_get())>I.l.GetQuality(s.baseData_get())?1:-1:n.level!=a.level?n.level>a.level?1:-1:0
}SortBySocre(t){const e=t.Count()
let i=0
const s=a.Y.Inst.PrimaryRoleInfo_get().Job_get()
for(;i<e;){let n=0,a=0,o=0
for(;o<e-i;){const e=t[o].baseData_get().socre_get(s)
e>n&&(n=e,a=o),o+=1}const l=t[a]
t[a]=t[e-i-1],t[e-i-1]=l,i+=1}}GetHandInTargetItem(t){if(null!=this.handInTarget&&null!=t&&0!=t.Count())if(this.handInTarget.type==p.d.HAND_IN_ITEM){
const e=l.M.String2Int(this.handInTarget.param.itemModelId)
let i=0
for(;i<t.Count();){const s=t[i]
if(this.GetHandInTargetItemId(s)==e)return s
i+=1}}else if(this.handInTarget.type==p.d.HAND_IN_ITEM_GROUP){let e=0
for(;e<t.Count();){const i=t[e],s=this.GetHandInTargetItemId(i)
if(S.f.Inst().IsGroupContains(this.handInTarget.param.itemGroupId,s))return i
e+=1}}else if(this.handInTarget.type==p.d.HAND_IN_EQUIPMENT){let e=0
for(;e<t.Count();){const i=t[e],s=this.GetHandInTargetItemId(i)
if(this.IsEnoughEquipTypeAndStep(s,this.handInTarget.param.equipmentType,this.handInTarget.param.stepLv))return i
e+=1}}return null}GetHandInTargetItemId(t){let e=0
if((0,n.t2)(t,A.v)){e=t.modelId}return e}IsEnoughEquipTypeAndStep(t,e,i){const s=C.f.Inst().getItemById(t)
if(null!=s){if(u.R.IsInclude(s.equipType,e)){if(S.f.Inst().getItemById(t).equipStepLv>=i)return!0}}return!1}IsHaveEnoughEquip(t,e){this.bData=null
const i=d.g.Inst_get().GetEquipList()
if(0==i.Count())return!1
this.m_equipIndexList.Clear()
const n=a.Y.Inst.PrimaryRoleInfo_get().AllStageEquipments_get()
if(null!=n){const a=new r.Z
let o=null
for(const[t,e]of(0,s.vy)(n)){const e=n[t]
let i=0
for(;i<e.equipmentsGet().Count();){const t=e.equipmentsGet()[i]
null!=t&&(this.m_equipIndexList.Add(t.equipIndex),o=new h.Y,o.isDressedEquip=!0,o.serverData_set(t),a.Add(o)),i+=1}}this.m_needParam=e,this.DoJudgeEnough(t,e,a,!1)
for(const[t,e]of(0,s.V5)(a))h.Y.Recycle(e)
if(this.m_needParam>0&&(e=1,this.DoJudgeEnough(t,e,i,!0)))return!0}return!1}DoJudgeEnough(t,e,i,n){const o=a.Y.Inst.PrimaryRoleInfo_get(),r=o.Job_get()
let h=!1,d=0,c=0,g=!0
I.l.IsEmptyStr(t.itemModelId)||(c=l.M.String2Int(t.itemModelId))
for(const[a,m]of(0,s.V5)(i))if(_.Z.IsSameJobType(r,m.baseData_get().cfgData_get().job)&&o.Level_get()>=m.baseData_get().cfgData_get().level&&(g=!0,
0!=c&&m.baseData_get().cfgData_get().id!=c&&(g=!1),g)){if(u.R.IsInclude(m.baseData_get().cfgEquipData_get().equipType,t.equipmentType)){let i=!0
if(!i||I.l.IsEmptyStr(t.itemModelId)||this.IsAttEnough(m,y.ITEM_MODEL_ID,t.itemModelId)||(i=!1),i&&t.quality>0&&!this.IsAttEnough(m,y.QUALITY,l.M.IntToString(t.quality))&&(i=!1),
i&&t.equipStepLv>0&&!this.IsAttEnough(m,y.EQUIP_STEP_LV,l.M.IntToString(t.equipStepLv))&&(i=!1),
i&&t.equipexcellencenum>0&&!this.IsAttEnough(m,y.EQUIPE_XCELLENCE_NUM,l.M.IntToString(t.equipexcellencenum))&&(i=!1),
!i||I.l.IsEmptyStr(t.equipexcellencetype)||this.IsAttEnough(m,y.EQUIP_EXCELLENCE_TYPE,t.equipexcellencetype)||(i=!1),
i&&t.equipenhancelevel>0&&!this.IsAttEnough(m,y.EQUIP_ENHANCE_LEVEL,l.M.IntToString(t.equipenhancelevel))&&(i=!1),
i&&t.equipaddlevel>0&&!this.IsAttEnough(m,y.EQUIP_ADD_LEVEL,l.M.IntToString(t.equipaddlevel))&&(i=!1),i&&t.star>0&&!this.IsAttEnough(m,y.STAR,l.M.IntToString(t.star))&&(i=!1),
i&&t.excellentOrSuit>0&&!this.IsAttEnough(m,y.EXCELLENT_OR_SUIT,l.M.IntToString(t.excellentOrSuit))&&(i=!1),
i&&t.equipColumn>0&&!this.IsAttEnough(m,y.EQUIP_COLUMN,l.M.IntToString(t.equipColumn))&&(i=!1),i&&!this.IsSuitEnough(m,t.suitType,t.suitlevel)&&(i=!1),i){let i=!0
if(n&&(this.IsEquipSpaceEnough(t,m.baseData_get(),1)||(i=!1)),i&&(d+=1,d>=e)){h=!0,null==this.bData&&(this.bData=m.baseData_get(),
this.bData.referenceCount=this.bData.referenceCount+1)
break}}}}return this.m_needParam=e-d,h}IsEquipSpaceEnough(t,e,i){const n=a.Y.Inst.PrimaryRoleInfo_get(),o=c.i.GetAllCanTakeOnPosList(n,e),l=new r.Z
for(const[e,i]of(0,s.V5)(o)){if(null==i._equipmentEx)return!0
if(-1==this.m_equipIndexList.IndexOf(i._index,0)){l.Clear()
const e=new h.Y
if(e.isDressedEquip=!0,e.serverData_set(i._equipmentEx),l.Add(e),!this.DoJudgeEnough(t,1,l,!1))return!0}}return!1}IsSuitEnough(t,e,i){if(0==e)return!0
const s=t.serverData_get()
if(s.suitId>0){const t=m.H.Inst().getSuitById(s.suitId)
if(t.suitType==e&&t.suitLevel>=i)return!0}return!1}IsAttEnough(t,e,i){const s=l.M.String2Int(i)
if(e==y.ITEM_MODEL_ID){if(t.baseData_get().modelId_get()==s)return!0}else if(e==y.QUALITY){if(t.baseData_get().Quality_get()>=s)return!0}else if(e==y.EQUIP_STEP_LV){
if(t.baseData_get().cfgData_get().equipStepLv>=s)return!0}else if(e==y.EQUIPE_XCELLENCE_NUM){if(g.I.GetExeAttrsNum(t.serverData_get())>=s)return!0
}else if(e==y.EQUIP_EXCELLENCE_TYPE){if(g.I.IsExeEquipHasType(t.serverData_get(),i))return!0}else if(e==y.EQUIP_ENHANCE_LEVEL){if(t.serverData_get().Enhancelevel_get()>=s)return!0
}else if(e==y.EQUIP_ADD_LEVEL){if(t.serverData_get().EquipmentAdd_get()>=s)return!0}else if(e==y.STAR){if(t.serverData_get().Star_get()>=s)return!0}else if(e==y.EXCELLENT_OR_SUIT){
const e=t.serverData_get()
if(e.ExcellenceCount_get()+e.suitId>=s)return!0}else if(e==y.EQUIP_COLUMN){const e=t.baseData_get().cfgEquipData_get().equipColumn
if(null!=e&&l.M.IndexOf(e,i,0)>-1)return!0}return!1}}y._inst=null,y.ITEM_MODEL_ID="itemModelId",y.QUALITY="quality",y.EQUIP_STEP_LV="equipStepLv",
y.EQUIPE_XCELLENCE_NUM="equipexcellencenum",y.EQUIP_EXCELLENCE_TYPE="equipexcellencetype",y.EQUIP_ENHANCE_LEVEL="equipenhancelevel",y.EQUIP_ADD_LEVEL="equipaddlevel",y.STAR="star",
y.EXCELLENT_OR_SUIT="excellentOrSuit",y.EQUIP_COLUMN="equipColumn"},35918:(t,e,i)=>{i.d(e,{j:()=>n})
var s=i(16812)
class n extends s.k{constructor(...t){super(...t),this.CurHandInItemData=null}static Inst_get(){return null==n._inst&&(n._inst=new n),n._inst}}n._inst=null},44798:(t,e,i)=>{i.d(e,{
K:()=>m})
var s,n=i(6847),a=i(83908),o=i(49655),l=i(46282),r=i(21554),h=i(70850),d=i(92679),u=i(65550),c=i(17783),_=i(20193),I=i(37189),g=i(35918)
let m=(0,n.s_)(o.o.HandInItemView,l.Z.ui_handinitem_view).register()(s=class extends((0,a.Ri)()){constructor(...t){super(...t),this.HandInNum=1,this.CurHandInItemData=null}
InitView(){super.InitView()}Clear(){this.RemoveLis(),this.CurHandInItemData=null,g.j.Inst_get().CurHandInItemData=null,this.ui_baseitem.Clear(),this.HandInNum=1,super.Clear()}
Destroy(){}OnAddToScene(){this.RemoveLis(),this.AddLis(),this.CurHandInItemData=g.j.Inst_get().CurHandInItemData,null!=this.CurHandInItemData&&(this.HandInNum=1,this.UpdateView())}
AddLis(){this.m_handlerMgr.AddClickEvent(this.Handin,this.CreateDelegate(this.OnHandInClick)),this.m_handlerMgr.AddClickEvent(this.CloseBtn,this.CreateDelegate(this.OnCloseClick)),
this.m_handlerMgr.AddEventMgr(d.g.BAG_UPDATE,this.CreateDelegate(this.UpdataBagNum))}RemoveLis(){this.m_handlerMgr.Clear()}OnHandInClick(){
if(null==this.CurHandInItemData||this.HandInNum<=h.g.Inst_get().GetItemNum(this.CurHandInItemData.ItemId))return this.DoHandIn(),I.o.Inst_get().CloseHandInItemView(),
void r.J.Inst_get().CloseTipView()
u.y.inst.ClientSysStrMsg("道具不足"),INS.itemTipManager.OpenTipViewById(this.CurHandInItemData.ItemId)}OnCloseClick(){I.o.Inst_get().CloseHandInItemView()}UpdataBagNum(){
this.CurHandInItemData.BaseItemData.serverData_get().num=h.g.Inst_get().GetItemNum(this.CurHandInItemData.ItemId),this.ui_baseitem.SetData(this.CurHandInItemData.BaseItemData)}
UpdateView(){this.CurHandInItemData.BaseItemData.serverData_get().num=h.g.Inst_get().GetItemNum(this.CurHandInItemData.ItemId),
this.ui_baseitem.SetData(this.CurHandInItemData.BaseItemData)
const[t,e]=this.CurHandInItemData.GetShowDecs()
e?(this.Dec.textSet(t),this.Dec2.textSet("")):(this.Dec.textSet(""),this.Dec2.textSet(t))}CheckCanHandIn(){
return null!=this.CurHandInItemData&&(this.HandInNum<=h.g.Inst_get().GetItemNum(this.CurHandInItemData.ItemId)||(u.y.inst.ClientSysStrMsg("道具不足"),!1))}DoHandIn(){
this.HandInNum>0&&(this.CurHandInItemData.isHelpOther?_.D.Inst_get().AssistOther(this.CurHandInItemData.assId):c.L.Inst_get().mgr.CM_QuestHandInHandle(this.CurHandInItemData.TaskId,this.CurHandInItemData.ItemId,this.HandInNum))
}})||s},32691:(t,e,i)=>{i.d(e,{C:()=>j})
var s,n,a,o,l,r,h,d,u,c=i(42292),_=i(71409),I=i(17409),g=i(49655),m=i(82662),C=i(38836),S=i(38045),p=i(98800),A=i(97461),f=i(38935),y=i(66788),T=i(56937),R=i(52726),v=i(98789),w=i(98885),D=i(79534),E=i(92679),L=i(37648),G=i(55492),O=i(11037),b=i(40451),B=i(90522),N=i(32441),P=i(94266),M=i(45275),V=i(48412),k=i(26449),x=i(44683),H=i(92415),U=i(14792),F=i(62734),Y=i(64501),K=i(45537),z=i(92202),Q=i(54002),Z=i(92905)
function X(t,e,i,s,n){var a={}
return Object.keys(s).forEach((function(t){a[t]=s[t]})),a.enumerable=!!a.enumerable,a.configurable=!!a.configurable,("value"in a||a.initializer)&&(a.writable=!0),
a=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),a),n&&void 0!==a.initializer&&(a.value=a.initializer?a.initializer.call(n):void 0,a.initializer=void 0),
void 0===a.initializer&&(Object.defineProperty(t,e,a),a=null),a}let j=(s=(0,_.GH)(H.k.SM_LoginAfterRidingInfo),n=(0,_.GH)(H.k.SM_RidingCompose),a=(0,_.GH)(H.k.SM_RidingActSkill),
o=(0,_.GH)(H.k.SM_RidingObtain),l=(0,_.GH)(H.k.SM_RidingUpdate),r=(0,_.GH)(H.k.SM_RidingRequestResult),h=(0,_.GH)(H.k.SM_RidingSkillAct),u=class t{constructor(){
this.horseSkillMainViewLoading=!1,this.defaultSelectHorseId=-1,this.tipData=null,this.horseLevelData=null,this._degf_SM_GetLoginRidingData=null,this._degf_SM_RidingObtain=null,
this._degf_SM_RidingUpdate=null,this._degf_SM_RidingRequestResult=null,this._degf_OnBagUpdate=null,this.roleData=null,this.newHorseSkill=null,this._degf_SM_GetLoginRidingData=t=>{
this.SM_GetLoginRidingData(t)},this._degf_SM_RidingObtain=t=>{this.SM_RidingObtain(t)},this._degf_SM_RidingUpdate=t=>{this.SM_RidingUpdate(t)},
this._degf_SM_RidingRequestResult=t=>{this.SM_RidingRequestResult(t)},this._degf_OnBagUpdate=t=>{this.UpdateHorseRedPoint()},
A.i.Inst.AddEventHandler(E.g.BAG_UPDATE,this._degf_OnBagUpdate)}static Inst_get(){return null==t.inst&&(t.inst=new t),t.inst}open(){const t=new T.v
t.isShowMask=!0,t.isDefaultUITween=!0,(0,I.Yp)(m.b.HorseMainView,t)}OpenHorseDressPanel(){const t=new T.v
t.isShowMask=!0,t.isDefaultUITween=!0,(0,I.Yp)(m.b.HorseDress,t)}OpenHorseItemTipView(t){this.tipData=t
let e=(0,I.Y)(m.b.HorseItemTipPanel)
if(null==e){const e=new T.v
e.layerType=R.F.Tip,e.positionType=v.$.eCustom,e.isShowMask=!0,e.maskAlpha=t.maskAlpha,(0,I.Yp)(m.b.HorseItemTipPanel,e)}else e.SetData(this.tipData),this.tipData=null}
OpenHorseSKillTipView(t){this.horseLevelData=t
let e=(0,I.Y)(m.b.HorseSkillTipView)
if(null==e){const t=new T.v
t.isShowMask=!0,t.isDefaultUITween=!0,(0,I.Yp)(m.b.HorseSkillTipView,t)}else e.SetData(this.horseLevelData),this.horseLevelData=null}OpenSelectHorseView(t){this.roleData=t
let e=(0,I.Y)(m.b.HorseSelectView)
if(null==e){const t=new T.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.positionType=v.$.eCustom,t.pos=new D.P(200,0,0),(0,I.Yp)(m.b.HorseSelectView,t)}else e.SetData(t),this.roleData=null}CloseItemTipView(){(0,
I.sR)(g.o.HorseItemTipPanel)}UpdateHorseRidingSkillRedPoint(){let t=!1
const e=z.O.Inst_get().GetHorseSkillList()
for(let i=0;i<=e.Count()-1;i++)if(e[i].CanUpgrade()){t=!0
break}F.f.Inst.SetState(U.t.HORSE_RIDING,t)}UpdateHorseRedPoint(){let t=!1,e=!1
if(L.P.Inst_get().IsFunctionOpened(G.x.Horse)){const i=z.O.Inst_get().GetHorseDataList()
for(const[s,n]of(0,C.V5)(i))if(n.IsCanActive()&&(2==n.cfgData.horseType?e=!0:t=!0),2==n.cfgData.horseType&&n.IsSkillRed()&&(e=!0),
2!=n.cfgData.horseType&&(n.IsCanUpgradeNext()||n.IsSkillRed())&&(t=!0),e&&t)break}F.f.Inst.SetState(U.t.HORSE_BASE,t),F.f.Inst.SetState(U.t.HORSE_UNREAL,e),
this.UpdateHorseRidingSkillRedPoint()}ShowSkillAdd(t){Y.B.inst.OpenSkillNewView(t)}SM_GetLoginRidingData(t){z.O.Inst_get().SetHorseServerData(t),this.UpdateHorseRedPoint(),
A.i.Inst.RaiseEvent(K.z.HORSE_INFO_CHANGE)}SM_RidingComposeHandler(t){z.O.Inst_get().ridingCompose=t.isAutoCompose,this.UpdateHorseRedPoint(),
A.i.Inst.RaiseEvent(K.z.HORSE_AUTO_COMPOSE)}SM_RidingActSkillHandler(t){const e=t.ridingVo.horseId,i=z.O.Inst_get().GetHorseData(e).SkillList_Get(),s=t.ridingVo.skillList
let n=null
for(let t=0;t<=s.Count()-1;t++)if(-1==i.IndexOf(s[t])){n=s[t]
break}if(n){const i=w.M.Split(n,"_")
if(w.M.String2Int(i[0])>0);else{const t=O.D.GetInst().GetHorseSkill(e)
let i=null
for(let e=0;e<=t.Count()-1;e++){if(t[e].skill==n){i={cfg:t[e],name:t[e].name,skillIcon:t[e].skillIcon,skillDesc:t[e].skillDesc,skill:t[e].skill}
break}if(t[e].skill2==n){i={cfg:t[e],name:t[e].name2,skillIcon:t[e].skillIcon2,skillDesc:t[e].skillDesc2,skill:t[e].skill2}
break}}null!=i&&this.ShowHorseSkillAdd(i)}z.O.Inst_get().UpdateHorseSkill(t.ridingVo),A.i.Inst.RaiseEvent(z.O.SKILL_UPDATE,n),this.UpdateHorseRedPoint()}}SM_RidingObtain(t){
const e=t.ridingVo,i=z.O.Inst_get().GetHorseDataById(e.horseId)
i.State_set(Q.K.ACTIVE),i.Level_set(e.level),i.Stage_set(e.rank),i.PowerValue_set(e.battleScore.ToNum()),i.SkillList_Set(e.skillList),i.experience=e.process,
A.i.Inst.RaiseEvent(E.g.HORSE_ACTIVE,i)}SM_RidingUpdate(t){const e=t.ridingVo,i=z.O.Inst_get().GetHorseDataById(e.horseId),s=e.level!=i.Level_get(),n=e.rank!=i.Stage_get()
i.Level_set(e.level),i.Stage_set(e.rank),i.PowerValue_set(e.battleScore.ToNum()),i.SkillList_Set(e.skillList),i.experience=e.process,A.i.Inst.RaiseEvent(E.g.HORSE_UPGRADE,{
horseData:i,isUp:s,isRank:n})}SM_RidingRequestResult(t){let e=null
for(let i=0;i<=t.ridingStatus.Count()-1;i++){e=t.ridingStatus[i]
const s=p.Y.Inst.getCharacterById(e.playerId)
if(null==s)return void y.Y.Log(`SM_RidingRequestResult--坐骑找不到玩家：${e.playerId.ToLongStr()}`)
const n=s
n.Roleinfo_get().horseId_set(e.horseId),e.isGetOn?n.ShowHorse():n.HideHorse()}}SM_RidingSkillAct(t){z.O.Inst_get().HandlerRidingSkillAct(t),this.UpdateHorseRidingSkillRedPoint(),
A.i.Inst.RaiseEvent(E.g.HORSE_RIDING_UPDATE)}SendHorseDressOrOff(t,e){if(!(0,S.t2)(t,INS.Player))return
const i=t.Roleinfo_get()
e?t.ShowRide_get()||this.CM_RidingRequest(i.horseId_get(),i.Id_get(),!0):t.ShowRide_get()&&this.CM_RidingRequest(i.horseId_get(),i.Id_get(),!1)}SendAllRoleHorseDressOrOff(t){
if(null!=p.Y.Inst.primaryRole){const t=p.Y.Inst.primaryRole.roleinfo
if(null!=t&&t.InTransform())return}const e=p.Y.Inst.primaryRoleList
for(let i=0;i<=e.Count()-1;i++)null!=e[i]&&null!=e[i].roleinfo&&e[i].roleinfo.hasHorse()&&e[i].ShowRide_set(t)}HasHorse(){const t=p.Y.Inst.primaryRoleList
if(null!=t)for(let e=0;e<=t.Count()-1;e++)if(t[e].roleinfo.hasHorse())return!0
return!1}IntereptSkillAdd(t,e){const i=z.O.Inst_get()
if(0==i.curUIHorseId)return!1
return!i.GetSkillEffect(i.curUIHorseId,t,e)}ShowHorseSkillAdd(t){this.newHorseSkill=t
const e=new T.v
e.viewClass=Z.c,(0,I.Yp)(m.b.HorseSkillAddView,e)}CM_RidingActivate(t){const e=new b.C
e.horseId=t,f.C.Inst.F_SendMsg(e)}CM_RidingUpgrade(t,e){const i=new x.V
i.ridingId=t,i.isAuto=e,f.C.Inst.F_SendMsg(i)}CM_RidingRequest(t,e,i){const s=new V.D
s.horseId=t,s.playerId=e,s.needShow=i,f.C.Inst.F_SendMsg(s)}CM_RidingChange(t,e){const i=new N.m
i.playerId=e,i.horseId=t,f.C.Inst.F_SendMsg(i)}CM_RidingEquip(t){const e=new M.w
e.isEquipped=t,f.C.Inst.F_SendMsg(e)}CM_RidingCompose(t){const e=new P.R
e.isAutoCompose=t,f.C.Inst.F_SendMsg(e)}CM_RidingActSkill(t,e){const i=new B.a
i.horseId=t,i.skillId=e,f.C.Inst.F_SendMsg(i)}CM_RidingSkillAct(t){const e=new k.A
e.skillId=t,f.C.Inst.F_SendMsg(e)}ShowHorseSkillMainView(){let t=(0,I.Y)(m.b.HorseSkillMainView)
if(this.horseSkillMainViewLoading)t.OnAddToScene()
else{this.horseSkillMainViewLoading=!0
const t=new T.v
t.layerType=R.F.DefaultUI,(0,I.Yp)(m.b.HorseSkillMainView,t)}}},u.inst=null,X(d=u,"Inst_get",[c.n],Object.getOwnPropertyDescriptor(d,"Inst_get"),d),
X(d.prototype,"SM_GetLoginRidingData",[s],Object.getOwnPropertyDescriptor(d.prototype,"SM_GetLoginRidingData"),d.prototype),
X(d.prototype,"SM_RidingComposeHandler",[n],Object.getOwnPropertyDescriptor(d.prototype,"SM_RidingComposeHandler"),d.prototype),
X(d.prototype,"SM_RidingActSkillHandler",[a],Object.getOwnPropertyDescriptor(d.prototype,"SM_RidingActSkillHandler"),d.prototype),
X(d.prototype,"SM_RidingObtain",[o],Object.getOwnPropertyDescriptor(d.prototype,"SM_RidingObtain"),d.prototype),
X(d.prototype,"SM_RidingUpdate",[l],Object.getOwnPropertyDescriptor(d.prototype,"SM_RidingUpdate"),d.prototype),
X(d.prototype,"SM_RidingRequestResult",[r],Object.getOwnPropertyDescriptor(d.prototype,"SM_RidingRequestResult"),d.prototype),
X(d.prototype,"SM_RidingSkillAct",[h],Object.getOwnPropertyDescriptor(d.prototype,"SM_RidingSkillAct"),d.prototype),d)},45537:(t,e,i)=>{i.d(e,{z:()=>s})
class s{}s.HORSE_INFO_CHANGE="HORSE_INFO_CHANGE",s.SELECT_ONE_HORSE="SELECT_ONE_HORSE",s.HORSE_STATE_CHANGE="HORSE_STATE_CHANGE",
s.HORSE_HUANHUA_STATE_CHANGE="HORSE_HUANHUA_STATE_CHANGE",s.HORSE_ACTIVITE_CHANGE="HORSE_ACTIVITE_CHANGE",s.CLICK_HORSE_LIST_ITEM="CLICK_HORSE_LIST_ITEM",
s.UPDATE_HORSE_TOTAL_ATT="UPDATE_HORSE_TOTAL_ATT",s.CLICK_HORSE_SECOND_LIST_ITEM="CLICK_HORSE_SECOND_LIST_ITEM",s.HORSE_AUTO_COMPOSE="HORSE_AUTO_COMPOSE"},92202:(t,e,i)=>{i.d(e,{
O:()=>R})
var s=i(38836),n=i(38045),a=i(98800),o=i(97960),l=i(98885),r=i(85602),h=i(38962),d=i(70850),u=i(30421),c=i(75439),_=i(11037),I=i(87923),g=i(44498),m=i(33833)
class C{constructor(t,e,i){this.attKey=null,this.attValue=null,this.attValueAdd=null,this.attKey=t,this.attValue=e,this.attValueAdd=i}SetCell(t){
const e=m.X.Inst().getItemByName(this.attKey)
if(t.isForMainPanel){t.nameLabel.textSet(e.name4word)
let i=g.I.GetOkFormatAttrVal(this.attKey,l.M.String2Double(this.attValue))
i=null!=this.attValueAdd&&"0"!=this.attValueAdd?`${g.I.GetOkFormatAttrVal(this.attKey,l.M.String2Double(this.attValue))}[57ea57](+${this.attValueAdd})[-]`:g.I.GetOkFormatAttrVal(this.attKey,l.M.String2Double(this.attValue)),
t.valueLabel.textSet(I.l.SetStringColor("F4E2B3",i))}else{let i=e.name
const s=` +${g.I.GetOkFormatAttrVal(this.attKey,l.M.String2Double(this.attValue))}`
null!=this.attValueAdd&&"0"!=this.attValueAdd?i+=`${I.l.SetStringColor("FFEFE1",s)}[57ea57](+${this.attValueAdd})[-]`:i+=I.l.SetStringColor("FFEFE1",s),t.nameLabel.textSet(i),
t.valueLabel.textSet("")}}}var S=i(88653),p=i(54002)
class A{constructor(t){this.cfgData=null,this.horseId=null,this._state=p.K.DIS_ACTIVE,this._stage=1,this._level=1,this._battleScore=0,this.isDress=!1,this.experience=null,
this.skillList=null,this.cfgData=_.D.GetInst().GetCfg(t),this.horseId=t,this.skillList=new r.Z}Stage_set(t){this._stage=t}Stage_get(){return this._stage}State_set(t){this._state=t}
State_get(){return this._state}Level_set(t){this._level=t}Level_get(){return this._level}LevelCfg_get(){
return _.D.GetInst().GetLevelCfg(this.horseId,this.Stage_get(),this.Level_get())}PowerValue_set(t){this._battleScore=t}PowerValue_get(){
return this.IsActive()?this._battleScore:this.cfgData.score}IsActive(){return this._state==p.K.ACTIVE}SkillList_Set(t){this.skillList=t}SkillList_Get(){return this.skillList}
HasSkill(t){return this.skillList.IndexOf(t)>-1}IsCanActive(){if(this.IsActive())return!1
let t=null
const e=this.cfgData.activationex.typevalues
for(let i=0;i<=e.Count()-1;i++)if(t=e[i],d.g.Inst_get().GetItemNum((0,n.aI)(t.valueType))>=t.valueNum)return!0
return!1}IsCanUpgradeNext(){if(!this.IsActive())return!1
if(2==this.cfgData.horseType)return!1
let t=_.D.GetInst().GetLevelCfg(this.horseId,this.Stage_get(),this.Level_get()+1)
if(null==t&&(t=_.D.GetInst().GetLevelCfg(this.horseId,this.Stage_get()+1,1)),null==t)return!1
const e=this.LevelCfg_get().consume
return!!(d.g.Inst_get().GetItemNum((0,n.aI)(e))>=1||R.Inst_get().CanAutoCompose(e))}IsSkillRed(){const t=_.D.GetInst().GetHorseSkill(this.horseId)
let e=!1
for(let i=0;i<=t.Count()-1;i++){if(this.IsActive()&&this.Stage_get()>=t[i].horseRank&&this.Level_get()>=t[i].horseLevel){let s=0,n=0
if(l.M.IsNullOrEmpty(t[i].skill)||(s=this.skillList.IndexOf(t[i].skill)),l.M.IsNullOrEmpty(t[i].skill2)||(n=this.skillList.IndexOf(t[i].skill2)),-1==s||-1==n){e=!0
break}}}return e}getQualityColor(t){return A.colorList[t]}}
A.colorList=new r.Z([new S.I(.96,.8862745,.8313726,1),new S.I(.05882353,.4,.7843137,1),new S.I(.02352941,.4784314,.02352941,1),new S.I(.5372549,.2078431,.7058824,1),new S.I(.5921569,.3568628,.05098039,1),new S.I(.5882353,.2352941,.1411765,1),new S.I(.6980392,.25,.5882,1)])
var f=i(62370),y=i(63076)
class T{constructor(t){this.skillId=null,this.level=0,this.costItemList=null,this.skillId=t,this.costItemList=new r.Z}GetLevelCfg(t){null==t&&(t=this.level),0==t&&(t=1)
const e=_.D.GetInst().GetHorseRealSKill(this.skillId)
for(let i=0;i<=e.Count()-1;i++)if(e[i].level==t)return e[i]}GetCostItemList(){this.costItemList.Clear()
const t=this.GetLevelCfg()
for(let e=0;e<t.cost.length;e++){const i=t.cost[e],s=l.M.Split(i.value,f.o.s_Arr_UNDER_COLON),a=new y.M((0,n.aI)(s[0]))
a.showNum=!1,a.greenRateNum=(0,n.aI)(s[1]),this.costItemList.Add(a)}return this.costItemList}IsMaxLevel(){if(this.IsLock())return!1
const t=this.GetLevelCfg()
return t.level>=t.maxLevel}IsLock(){return 0==this.level}UpgradeItemEnough(){const t=this.GetCostItemList()
for(let e=0;e<=t.Count()-1;e++){const i=t[e]
if(d.g.Inst_get().GetItemNum(i.modelId_get())<i.greenRateNum)return!1}return!0}CanUpgrade(){return!this.IsMaxLevel()&&(!!this.UpgradeItemEnough()&&!!this.UpgradeCondition())}
UpgradeCondition(){const t=this.GetLevelCfg()
if(t.skillCondition>0){if(R.Inst_get().GetHorseRidingSkillDataBySkillId(this.skillId-1).level<t.skillCondition)return!1}if(t.horseCondition>0){
if(R.Inst_get().GetTotalStage()<t.horseCondition)return!1}return!0}}class R{constructor(){this._horseDictData=null,this._roleHorseData=null,this.showSKillList=null,
this.showSKillListDict=null,this.showBuffListDict=null,this.horseRidingSKillDict=null,this.allRoleHorseShow=!1,this.enabledRidingHorse=!0,this.currentSelectType=1,
this.horseActiveEffectDic=null,this.ridingCompose=!1,this.curUIHorseId=0,this.composeCfgsDic=null,this.baseCompose=null,this.composeCfgsStr=null,this._horseDictData=new h.X,
this._roleHorseData=new h.X,this.showSKillList=new r.Z,this.showSKillListDict=new h.X,this.showBuffListDict=new h.X,this.horseRidingSKillDict=new h.X,
this.horseActiveEffectDic=new h.X,this.composeCfgsDic=new h.X,this.InitCfg()}static Inst_get(){return null==R.inst&&(R.inst=new R),R.inst}InitCfg(){
this.baseCompose=c.D.getInstance().GetIntValue("RIDING:RIDING_DAN_UNCOMPOSE"),this.composeCfgsStr=c.D.getInstance().GetStringValue("RIDING:RIDING_DAN_COMPOSE")
const t=l.M.Split(this.composeCfgsStr,",")
for(let e=0;e<=t.Count()-1;e++){const i=l.M.Split(t[e],"_"),s=u.c.Inst().getItemById(l.M.String2Int(i[1]))
this.composeCfgsDic.LuaDic_AddOrSetItem(l.M.String2Int(i[0]),s)}}GetHorseDataList(){return this._horseDictData.LuaDic_Values()}GetHorseDataListByType(t){const e=new r.Z
for(const[i,n]of(0,s.V5)(this._horseDictData))n.cfgData.horseType==t&&e.Add(n)
return e}GetHorseDataById(t){let e=this._horseDictData.LuaDic_GetItem(t)
return null==e&&(e=new A(t),0==e.cfgData.show&&this._horseDictData.LuaDic_AddOrSetItem(t,e)),e}GetPlayerHorse(t){return this._roleHorseData.LuaDic_GetItem(t)}GetTotalStage(){
let t=0
const e=this.GetHorseDataList()
for(let i=0;i<=e.Count()-1;i++){const s=e[i]
s.IsActive()&&(2==s.cfgData.horseType?t+=s.cfgData.ghostGrade:t+=s.Stage_get())}return t}SetRoleHorseServerData(t){let e=null,i=null
for(let s=0;s<=t.Count()-1;s++)e=t[s],i=this._roleHorseData.LuaDic_GetItem(e.playerId),null!=i&&(i.isDress=!1)
for(let s=0;s<=t.Count()-1;s++){e=t[s]
const n=a.Y.Inst.GetMultiPlayerInfo(e.playerId)
if(0==e.horseId)this._roleHorseData.LuaDic_Remove(e.playerId),n.horseId_set(0)
else{i=this.GetHorseDataById(e.horseId),i.isDress=!0,this._roleHorseData.LuaDic_AddOrSetItem(e.playerId,i)
const t=n.horseId_get()
n.horseId_set(e.horseId),e.isGetOn&&t==e.horseId&&n.RaiseEvent(o.A.HorseChange)}}}SetHorseServerData(t){const e=t,i=_.D.GetInst().horseList
let n=null
for(const[t,a]of(0,s.V5)(i)){let t=this._horseDictData.LuaDic_GetItem(a.id)
null==t&&(t=new A(a.id),this._horseDictData.LuaDic_AddOrSetItem(a.id,t)),t.cfgData=a,n=null
for(let t=0;t<=e.ridingVos.Count()-1;t++)e.ridingVos[t].horseId==a.id&&(n=e.ridingVos[t])
null!=n?(t.State_set(p.K.ACTIVE),t.Level_set(n.level),t.Stage_set(n.rank),t.SkillList_Set(n.skillList),t.experience=n.process,
t.PowerValue_set(n.battleScore.ToNum())):t.State_set(p.K.DIS_ACTIVE)}this.enabledRidingHorse=t.ieEquipped,this.SetRoleHorseServerData(e.ridingStatus)}GetItemAttList(t){
const e=t.GetHorseTV().typevalues,i=new r.Z
let s=0
for(;s<e.Count();){const t=e[s],n=new C(t.type,t.value)
i.Add(n),s+=1}if(t.speed>0){const e=new C("MoveSpeed",l.M.IntToString(t.speed))
i.Add(e)}const n=t.GetSpecialTV()
if(null!=n&&null!=n.typevalues){const t=n.typevalues
let e=0
for(;e<t.Count();){const s=t[e],n=new C(s.type,s.value)
i.Add(n),e+=1}}return i}Clear(){this._horseDictData.Clear(),this._roleHorseData.Clear()}GetSkillEffect(t,e,i){return!0}SetSkillEffect(t,e,i,s){const n=this.GetSkillEffectKey(t,e,i)
this.horseActiveEffectDic.LuaDic_AddOrSetItem(n,s)}GetSkillEffectKey(t,e,i){return 0==i&&(i=1),`${t}_${e}_${i}`}CanAutoCompose(t){if(!this.ridingCompose)return!1
return this.GetEnoughCompose(t)}GetEnoughCompose(t){t=(0,n.aI)(t)
if(d.g.Inst_get().GetItemNum(t)>=1)return!0
if(t==this.baseCompose)return!1
const e=this.composeCfgsDic[t]
if(!e)return!1
const i=this.GetComposeCfgCount(e),s=d.g.Inst_get().GetItemNum(this.baseCompose)
return this.GetHaveCfgCount(e)+s>=i}GetHaveCfgCount(t){const e=t.itemConsumesList[0],i=d.g.Inst_get().GetItemNum(e.modelId),s=this.composeCfgsDic[e.modelId]
return null!=s?s.itemConsumesList[0].modelId!=this.baseCompose?i*e.num*this.GetComposeCfgCount(s):i*e.num:0}GetComposeCfgCount(t){const e=t.itemConsumesList[0]
d.g.Inst_get().GetItemNum(e.modelId)
if(e.modelId==this.baseCompose)return e.num
const i=this.composeCfgsDic[e.modelId]
return null!=i?e.num*this.GetComposeCfgCount(i):e.num}UpdateHorseSkill(t){let e=this._horseDictData.LuaDic_GetItem(t.horseId)
null==e&&(e=new A(t.horseId),this._horseDictData.LuaDic_AddOrSetItem(t.horseId,e)),e.State_set(p.K.ACTIVE),e.Level_set(t.level),e.Stage_set(t.rank),e.SkillList_Set(t.skillList),
e.experience=t.process,e.PowerValue_set(t.battleScore.ToNum())}GetHorseData(t){const e=this.GetHorseDataList()
for(let i=0;i<=e.Count()-1;i++)if(e[i].horseId==t)return e[i]
return null}AddHorseSkillShow(t){t.buffId>0?this.showBuffListDict.LuaDic_AddOrSetItem(t.buffId,t):this.showSKillListDict.LuaDic_AddOrSetItem(t.skillId,t),this.showSKillList.Add(t)}
RemoveHorseSkillShow(t){0!=t.buffId?this.showBuffListDict.LuaDic_Remove(t.buffId):this.showSKillListDict.LuaDic_Remove(t.skillId),this.showSKillList.Remove(t)}GetSkillShow(t,e){
return e>0?this.showBuffListDict.LuaDic_GetItem(e):this.showSKillListDict.LuaDic_GetItem(t)}GetNextSHowSKill(){
for(let t=0;t<=this.showSKillList.Count()-1;t++)if(!this.showSKillList[t].isShow)return this.showSKillList[t]
return null}HandlerRidingSkillAct(t){const e=_.D.GetInst().ridingList
for(let i=0;i<=e.Count()-1;i++){const s=e[i]
let n=t.skillMap.LuaDic_GetItem(s.skillId),a=this.GetHorseRidingSkillDataBySkillId(s.skillId)
null==a&&(a=new T(s.skillId),this.horseRidingSKillDict.LuaDic_AddOrSetItem(s.skillId,a)),null==n&&(n=0),a.level=n}}GetHorseSkillList(){
return this.horseRidingSKillDict.LuaDic_Values()}GetHorseRidingSkillDataBySkillId(t){return this.horseRidingSKillDict.LuaDic_GetItem(t)}ClearData(){this.showSKillList.Clear(),
this.showSKillListDict.Clear(),this.showBuffListDict.Clear(),this.horseRidingSKillDict.Clear()}}R.SKILL_UPDATE="HORSE_SKILL_UPDATE",R.inst=null},54002:(t,e,i)=>{i.d(e,{K:()=>s})
class s{}s.DIS_ACTIVE=1,s.ACTIVE=2},58322:(t,e,i)=>{i.d(e,{F:()=>r})
var s,n=i(18998),a=i(83908)
const{ccclass:o,property:l}=n._decorator
let r=o("HorseAttItem")(s=class extends((0,a.yk)()){constructor(...t){super(...t),this.isPop=!1,this.isForMainPanel=!1}InitView(){}SetData(t){t.SetCell(this)}})||s},
90045:(t,e,i)=>{
var s,n,a=i(18998),o=i(10781),l=i(83908),r=i(65227),h=i(32697),d=i(20583),u=i(50838),c=i(70650),_=i(73206),I=i(28192),g=i(85602),m=i(79534),C=i(82589),S=i(92679),p=i(87923),A=i(11037),f=i(32691),y=i(45537),T=i(92202),R=i(54002),v=i(56568)
a._decorator.ccclass("HorseBasePanel")((n=class t extends((0,l.Ri)()){constructor(...t){super(...t),this._m_handlerMgr=null,this.currentSelectHorseData=null,this.m_horse=null,
this.roleRotateIndex=0,this.m_horseEleId=0,this.onSelectHorseCall=null,this.dataList=null,this.horseSkillItemList=null,this.rankEffect=null,this.upEffect=null,this.commEffect=null,
this.starUpEffect=null,this.activeEffect=null,this._degf_OnSelectItem=null,this._degf_HorseInitHandler=null,this.m_isChangeState=null,this.displayUIAvatarModel=void 0}
get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=I.h.Get()),this._m_handlerMgr}_initBinder(){super._initBinder(),this.horseSkillItemList=new g.Z,
this._degf_OnSelectItem=t=>this.OnSelectItem(t),this._degf_HorseInitHandler=t=>this.HorseInitHandler(t)}InitView(){this.horseSkillItemList.Add(this.ui_horse_skill_item1),
this.horseSkillItemList.Add(this.ui_horse_skill_item2),this.horseSkillItemList.Add(this.ui_horse_skill_item3),this.horseSkillItemList.Add(this.ui_horse_skill_item4),
this.horseSkillItemList.Add(this.ui_horse_skill_item5),this.grid.SetInitInfo("ui_horse_item",this.CreateDelegate(this.OnCreateHorseItem),v.$),
this.grid.OnReposition_set(this.CreateDelegate(this.OnCreateHorseItem)),this.AddLis(),this.displayUIAvatarModel=new u.o,this.displayUIAvatarModel.SetTarget(this.texture,!0)}
AddLis(){this.m_handlerMgr.AddClickEvent(this.dressBtn.node,this.CreateDelegate(this.onDress)),
this.m_handlerMgr.AddEventMgr(S.g.HORSE_ACTIVE,this.CreateDelegate(this.OnActiveHorse)),
this.m_handlerMgr.AddEventMgr(y.z.HORSE_INFO_CHANGE,this.CreateDelegate(this.OnHorseDressChange)),
this.m_handlerMgr.AddEventMgr(S.g.HORSE_UPGRADE,this.CreateDelegate(this.OnUpgradeHorse))}removeLis(){
this.m_handlerMgr.RemoveClickEvent(this.dressBtn.node,this.CreateDelegate(this.onDress)),this.m_handlerMgr.RemoveEventMgr(S.g.HORSE_ACTIVE,this.CreateDelegate(this.OnActiveHorse)),
this.m_handlerMgr.RemoveEventMgr(y.z.HORSE_INFO_CHANGE,this.CreateDelegate(this.OnHorseDressChange)),
this.m_handlerMgr.RemoveEventMgr(S.g.HORSE_UPGRADE,this.CreateDelegate(this.OnUpgradeHorse))}OnAddToScene(){
this.dataList=T.O.Inst_get().GetHorseDataListByType(T.O.Inst_get().currentSelectType),this.dataList.Sort(this.SortHorse),
this.horseListScrollView.content.transform.height=102*this.dataList.length,this.setDefaultSelect(),this.grid.data_set(this.dataList)}setDefaultSelect(){
let t=0,e=0,i=null,s=f.C.Inst_get().defaultSelectHorseId
for(let n=0;n<=this.dataList.Count()-1;n++)if(i=this.dataList[n],-1!=s){if(i.horseId==s){t=i.horseId,e=n
break}}else{if(i.IsCanActive()){t=i.horseId,e=n
break}if(i.IsCanUpgradeNext()){t=i.horseId,e=n
break}}if(f.C.Inst_get().defaultSelectHorseId=-1,0==t)for(let s=0;s<=this.dataList.Count()-1;s++)if(i=this.dataList[s],i.isDress){t=i.horseId,e=s
break}0==t&&(t=this.dataList[0].horseId),this.SelectShowData(this.dataList[e]),this.horseListScrollView.content.transform.SetLocalPositionXYZ(0,102*e,0),v.$.selectHorseId=t}
OnSelectItem(t){const e=t.data
this.currentSelectHorseData!=e&&this.SelectShowData(e)}SelectShowData(t){this.ShowHorseInfo(t),null!=this.onSelectHorseCall&&this.onSelectHorseCall(t)}ShowHorseSkill(e){
const i=A.D.GetInst().GetHorseSkill(e.horseId)
if(null==i){for(let t=0;t<=this.horseSkillItemList.Count()-1;t++)this.horseSkillItemList[t].node.SetActive(!1)
return}const s=new g.Z
for(let t=0;t<=i.Count()-1;t++){const e=i[t]
if(!p.l.IsEmptyStr(e.name)){const t={cfg:e,name:e.name,skillIcon:e.skillIcon,skillDesc:e.skillDesc,skill:e.skill}
s.Add(t)}if(!p.l.IsEmptyStr(e.name2)){const t={cfg:e,name:e.name2,skillIcon:e.skillIcon2,skillDesc:e.skillDesc2,skill:e.skill2}
s.Add(t)}}s.Sort(t.SortSkill)
for(let t=0;t<=this.horseSkillItemList.Count()-1;t++){const e=s[t]
null!=e?(this.horseSkillItemList[t].node.SetActive(!0),this.horseSkillItemList[t].SetData(e)):this.horseSkillItemList[t].node.SetActive(!1)}
const n=[[[-78.6,-32.3]],[[-156,-27.7],[-12.9,-27.7]],[[-215,-21],[-78.6,-32.3],[55,-21]],[[-267,-6],[-141.5,-30.9],[-10.3,-29.3],[118,-5.9]],[[-304.7,9.3],[-212.8,-22],[-78.6,-32.3],[52,-22],[154.8,9.3]]][s.Count()-1]
for(let t=0;t<n.length;t++){const e=n[t]
this.horseSkillItemList[t].node.x=e[0],this.horseSkillItemList[t].node.y=e[1],this.horseSkillItemList[t].node.SetActive(!0)}}static SortSkill(t,e){
return t.cfg.horseRank-e.cfg.horseRank}OnCreateHorseItem(t){const e=t.getCNode(v.$)
return e.OnClickHandler=this._degf_OnSelectItem,e}OnActiveHorse(t){this.currentSelectHorseData.horseId==t.horseId&&(this.ShowHorseInfo(this.currentSelectHorseData),
this.playEffect(4))}OnUpgradeHorse(t){this.UpdateHorseList(),this.currentSelectHorseData.horseId==t.horseData.horseId&&(this.ShowHorseInfo(this.currentSelectHorseData),
t.isRank?this.playEffect(1):t.isUp?this.playEffect(2):this.playEffect(3))}OnHorseDressChange(){
this.grid&&(this.dataList=T.O.Inst_get().GetHorseDataListByType(T.O.Inst_get().currentSelectType),this.dataList.Sort(this.SortHorse),this.grid.data_set(this.dataList))}
UpdateHorseList(){this.grid&&(this.dataList=T.O.Inst_get().GetHorseDataListByType(T.O.Inst_get().currentSelectType),this.dataList.Sort(this.SortHorse),
this.grid.data_set(this.dataList))}ShowHorseInfo(t){this.UnRegGuide()
const e=this.currentSelectHorseData
this.currentSelectHorseData=t,T.O.Inst_get().curUIHorseId=this.currentSelectHorseData.horseId
const i=t.cfgData.horseName
this.horsename.textSet(i),this.sorceValue.textSet(t.PowerValue_get())
let s="atlas/zuoqi/"
const n=new g.Z(["ryzuoqi_sp_0003","ryzuoqi_sp_0007","ryzuoqi_sp_0008","ryzuoqi_sp_0002","ryzuoqi_sp_0006","ryzuoqi_sp_0005","ryzuoqi_sp_0004"])
this.qualityNameBg.spriteNameSet(s+n[t.cfgData.horseGrade]),null!=e&&e.horseId==t.horseId||this.ShowHorseModel(t),t.cfgData.horseType,
this.bg.spriteNameSet(s+"ryzuoqihuanxing_sp_0001"),this.ShowHorseSkill(t),this.RegGuide()}RegGuide(){this.currentSelectHorseData.IsActive()}UnRegGuide(){this.currentSelectHorseData
}ShowHorseModel(t){const e=t.cfgData.modelId
this.displayUIAvatarModel.SetScale(1,1),d.x.inst.SetUIAvatarData(e,h.v.horse,this.displayUIAvatarModel),this.displayUIAvatarModel.SetDir(4)}onDress(){
f.C.Inst_get().OpenHorseDressPanel()}playEffect(t){this.effectPanel
null==this.commEffect&&(this.commEffect=this.createEffectNode("pre_eff_sh_uitx_07",16)),this.commEffect.node.visible=!0,this.commEffect.replay(1),
1==t?(null==this.rankEffect&&(this.rankEffect=this.createEffectNode("pre_eff_upgrade_suc_1",4)),this.rankEffect.node.visible=!0,
this.rankEffect.replay(1)):2==t?(null==this.starUpEffect&&(this.starUpEffect=this.createEffectNode("pre_eff_upstar_suc_1",4)),this.starUpEffect.node.visible=!0,
this.starUpEffect.replay(1)):3==t?(null==this.upEffect&&(this.upEffect=this.createEffectNode("pre_eff_promote_suc_1",4)),this.upEffect.node.visible=!0,
this.upEffect.replay(1)):4==t&&(null==this.activeEffect&&(this.activeEffect=this.createEffectNode("pre_eff_activation_suc_1",4)),this.activeEffect.node.visible=!0,
this.activeEffect.replay(1))}createEffectNode(t,e=8){let i=new a.Node("effNode"),s=i.addComponent(C.J)
return s.path=t,s.prefix=4,s.repeat=1,s.playOverRecover=!1,s.playOverRemove=!1,s.frameRate=e,s.playOverHandler=new o.R(this,(()=>{s.node.visible=!1})),this.effectPanel.addChild(i),
s}SortHorse(t,e){const i=t.State_get(),s=e.State_get()
return i==R.K.ACTIVE&&s!=R.K.ACTIVE?-1:i!=R.K.ACTIVE&&s==R.K.ACTIVE?1:i==R.K.ACTIVE&&s==R.K.ACTIVE?e.cfgData.rank-t.cfgData.rank:e.cfgData.rank2-t.cfgData.rank2}
HorseInitHandler(t){const e=this.currentSelectHorseData.cfgData
if(null!=this.m_horse&&this.m_horse.IsInited()&&(null!=this.m_horse&&(0!=this.roleRotateIndex&&c.e.GetInst().UnregDrag(this.roleRotateIndex),
this.roleRotateIndex=c.e.GetInst().RegDrag(this.rolerotategrid.node,this.m_horse.MainRole_get())),0!=e.elementId&&!this.m_isChangeState)){
this.m_horse.MainRole_get().PassEvent(r.o.horseshow)
const t=m.P.zero_get()
let i
this.m_horseEleId=_.X.Inst.PlayElement(e.elementId,this.m_horse.GetHandle(),0,this.m_horse.GetPos(),t,this.m_horse.GetDirectionAndAdjust(),null,!0,null,null,.5,null,null,null,i)}}
RemoveHorse(){null!=this.m_horse&&(this.m_horse.Destroy(),this.m_horse=null)}Clear(){this.UnRegGuide(),this.removeLis(),this.currentSelectHorseData=null,this.RemoveHorse(),
_.X.Inst.DeleteElement(this.m_horseEleId),T.O.Inst_get().curUIHorseId=0,super.Clear()}Destroy(){this.currentSelectHorseData=null,this.RemoveHorse(),this.grid.destroy(),
_.X.Inst.DeleteElement(this.m_horseEleId),super.destroy()}},n.STAGE_ID=56,s=n))},98909:(t,e,i)=>{i.d(e,{c:()=>S})
var s,n=i(18998),a=i(83908),o=i(38045),l=i(18202),r=i(83540),h=i(28192),d=i(63076),u=i(33314),c=i(87923),_=i(32691),I=i(45537),g=i(92202)
const{ccclass:m,property:C}=n._decorator
let S=m("HorseDressItem")(s=class extends((0,a.yk)()){constructor(...t){super(...t),this._m_handlerMgr=null,this.playerRoleInfo=null}get m_handlerMgr(){
return this._m_handlerMgr||(this._m_handlerMgr=h.h.Get()),this._m_handlerMgr}InitView(){}SetData(t){this.UnRegGuide(),this.playerRoleInfo=t,this.ui_charactertab_role.SetData(t),
this.ui_charactertab_role.SetRedPoint(!1),this.ui_charactertab_role.text_level.textSet(u.Z.GetJobName(t.Job_get()))
const e=Math.max(this.ui_charactertab_role.img_level_bg.width(),this.ui_charactertab_role.text_level.width()+30)
this.ui_charactertab_role.img_level_bg.widthSet(e)
const i=g.O.Inst_get().GetPlayerHorse(t.Id_get())
null!=i?(this.horsehead.node.SetActive(!0),this.emptyTip.SetActive(!1),this.SetHorseData(i)):(this.horsehead.node.SetActive(!1),this.emptyTip.SetActive(!0)),
this.m_handlerMgr.AddClickEvent(this.dressBtn.node,this.CreateDelegate(this.onDress)),
this.m_handlerMgr.AddEventMgr(I.z.HORSE_INFO_CHANGE,this.CreateDelegate(this.OnHorseDressChange)),
this.m_handlerMgr.AddClickEvent(this.horsehead,this.CreateDelegate(this.OnClickHorse))}RegGuide(){}UnRegGuide(){this.playerRoleInfo}SetHorseData(t){const e=t.cfgData
l.g.SetItemIcon(this.img,e.headId,r.b.eHorse),this.quality.spriteNameSet(c.l.getQualityImgByQuality(e.horseGrade)),this.RegGuide()}onDress(){
_.C.Inst_get().OpenSelectHorseView(this.playerRoleInfo)}OnHorseDressChange(t){const e=g.O.Inst_get().GetPlayerHorse(this.playerRoleInfo.Id_get())
null!=e&&this.SetHorseData(e)}OnClickHorse(){const t=g.O.Inst_get().GetPlayerHorse(this.playerRoleInfo.Id_get())
if(null!=t){const e=t.cfgData.activationex.typevalues[0],i=new d.M((0,o.aI)(e.valueType))
INS.itemTipManager.OpenTipView(i)}}Clear(){this.UnRegGuide()}Test1(){return!0}S_Test(){return!0}})||s},24924:(t,e,i)=>{
var s,n=i(6847),a=i(83908),o=i(17409),l=i(49655),r=i(46282),h=i(98800),d=i(28192),u=i(47786),c=i(32691),_=i(45537),I=i(92202),g=i(98909);(0,
n.s_)(l.o.HorseDress,r.Z.ui_horse_dresspanel).register()(s=class extends((0,a.Ri)()){constructor(...t){super(...t),this._m_handlerMgr=null}get m_handlerMgr(){
return this._m_handlerMgr||(this._m_handlerMgr=d.h.Get()),this._m_handlerMgr}InitView(){super.InitView(),this.grid.SetInitInfo("ui_horse_dress_item",null,g.c),
this.m_handlerMgr.AddClickEvent(this.btnClose,this.CreateDelegate(this.Close)),this.m_handlerMgr.AddClickEvent(this.upBtn,this.CreateDelegate(this.OnUpBtn)),
this.m_handlerMgr.AddEventMgr(_.z.HORSE_INFO_CHANGE,this.CreateDelegate(this.UpdateData))}OnAddToScene(){const t=u.x.Inst().getItemById(180040)
this.tipLabel.textSet(t.sys_messsage),this.UpdateData()}UpdateData(){this.UpdateEquipData(),this.grid.data_set(h.Y.Inst.primaryRoleInfoList)}UpdateEquipData(){let t=!1
const e=h.Y.Inst.primaryRoleInfoList
for(let i=0;i<=e.Count()-1;i++){null!=I.O.Inst_get().GetPlayerHorse(e[i].Id_get())&&(t=!0)}t?(this.upBtn.node.SetActive(!0),
I.O.Inst_get().enabledRidingHorse?this.upBtnLabel.textSet("卸下坐骑"):this.upBtnLabel.textSet("骑乘坐骑")):this.upBtn.node.SetActive(!1)}OnUpBtn(){
c.C.Inst_get().CM_RidingEquip(!I.O.Inst_get().enabledRidingHorse)}Close(){(0,o.sR)(l.o.HorseDress)}})},56568:(t,e,i)=>{i.d(e,{$:()=>C})
var s,n,a=i(18998),o=i(83908),l=i(85682),r=i(83540),h=i(28192),d=i(87923),u=i(6251),c=i(45537),_=i(92202),I=i(18202)
const{ccclass:g,property:m}=a._decorator
let C=g("HorseGridItem")((n=class t extends((0,o.yk)()){constructor(...t){super(...t),this._m_handlerMgr=null,this.OnClickHandler=null,this.data=null,this.cfg=null}
get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=h.h.Get()),this._m_handlerMgr}InitView(){
this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.onClickItem)),this.m_handlerMgr.AddEventMgr(_.O.SKILL_UPDATE,this.CreateDelegate(this.SkillUpdate)),
this.m_handlerMgr.AddEventMgr(c.z.HORSE_AUTO_COMPOSE,this.CreateDelegate(this.SkillUpdate))}SetData(e){this.data=e
const i=e.cfgData
this.textname.textSet(i.horseName),this.textname.SetColor(e.getQualityColor(i.horseGrade)),I.g.SetItemIcon(this.img,i.headId,r.b.eHorse,!1),
this.quality.spriteNameSet(d.l.getQualityImgByQuality(i.horseGrade)),this.sign.SetActive(e.isDress),e.IsActive()?(this.lockContainer.SetActive(!1),
u.d.LuaMakeGoGray(this.img.node,!1)):(this.lockContainer.SetActive(!0),u.d.LuaMakeGoGray(this.img.node,!0)),
this.RedPoint.node.SetActive(this.data.IsCanActive()||this.data.IsCanUpgradeNext()||this.data.IsSkillRed()),this.SetSelect(!1),i.id==t.selectHorseId&&this.SetSelect(!0),
this.RegGuide()}SkillUpdate(){this.RedPoint.node.SetActive(this.data.IsCanActive()||this.data.IsCanUpgradeNext()||this.data.IsSkillRed())}RegGuide(){}UnRegGuide(){}SetSelect(e){
e?(this.select.node.SetActive(!0),t.selectHorseId=this.data.horseId,t.currentSelectItem=this,null!=this.OnClickHandler&&this.OnClickHandler(this)):this.select.node.SetActive(!1)}
onClickItem(){d.l.CheckBtnClickTrigger(l.D.UI_ROLE_HORSE_ITEM),t.currentSelectItem!=this&&(null!=t.currentSelectItem&&t.currentSelectItem.SetSelect(!1),this.SetSelect(!0))}
UpdateRedPoint(){}removeLis(){this.m_handlerMgr.RemoveClickEvent(this.node,this.CreateDelegate(this.onClickItem)),
this.m_handlerMgr.RemoveEventMgr(_.O.SKILL_UPDATE,this.CreateDelegate(this.SkillUpdate)),
this.m_handlerMgr.RemoveEventMgr(c.z.HORSE_AUTO_COMPOSE,this.CreateDelegate(this.SkillUpdate))}Clear(){this.UnRegGuide(),this.SetSelect(!1),t.currentSelectItem=null}Destroy(){
super.destroy(),this.removeLis(),t.currentSelectItem=null}},n.currentSelectItem=null,n.selectHorseId=null,s=n))||s},51100:(t,e,i)=>{
var s,n=i(18998),a=i(6847),o=i(83908),l=i(17409),r=i(49655),h=i(46282),d=i(97461),u=i(28192),c=i(52212),_=i(70123),I=i(21554),g=i(84635),m=i(69015),C=i(67471),S=i(92679),p=i(11037),A=i(92202),f=i(32691)
const{ccclass:y,property:T}=n._decorator
y("HorseItemTipPanel")(s=(0,a.s_)(r.o.HorseItemTipPanel,h.Z.ui_bag_horsetippanel).waitPrefab([h.Z.ui_top_container,h.Z.ui_scroller_container,h.Z.ui_btns_container,h.Z.ui_horse_baseprop_module,h.Z.ui_horse_skill_module,h.Z.ui_descObj,h.Z.ui_descChannelObj,h.Z.ui_bag_horse_skill_item]).register()(s=class extends((0,
o.Ri)()){constructor(...t){super(...t),this._m_handlerMgr=null,this.tipIndex=null}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=u.h.Get()),this._m_handlerMgr}
InitView(){this.ui_tiproot.InitListByCompType(g.o.ITEM_HORSE_VIEW),(0,l.D1)(this,this.CloseTip),
this.m_handlerMgr.AddEventMgr(S.g.TIPROOTVIEW_REFRESHPOS,this.CreateDelegate(this.OnPos)),this.SetData(f.C.Inst_get().tipData),d.i.Inst.RaiseEvent(S.g.TipsLoadCompelete)}
SetData(t){m.g.Inst_get().ClearTip(),this.tipIndex=null
const e=new C.c(t)
t.isForBag?e.scorllerMaxH=365:e.scorllerMaxH=385
const i=p.D.GetInst().getActiviteCfg(t.cfgData_get().id)
A.O.Inst_get().GetHorseDataById(i.id).IsActive()&&(t.isShowAccess=!1),this.ui_tiproot.SetData(e),this.leftpart.SetData(i),this.ResetLayout(),this.OnPos()}OnPos(){
const t=this.leftpart.node.transform.GetLocalPosition(),e=this.ui_tiproot.nBg.transform.GetLocalPosition()
t.y=e.y-8,this.leftpart.node.transform.SetLocalPosition(t),this.ResetLayout()}ResetLayout(){const[t,e]=this.GetLeftPos(),[i,s]=this.GetSize()
null!=this.tipIndex?m.g.Inst_get().RefreshTipPos(this.tipIndex,new c.F(t,e),new c.F(i,s)):this.tipIndex=m.g.Inst_get().AddTipByParam(this,null,null,new c.F(t,e),new c.F(i,s))}
GetLeftPos(){const t=this.ui_tiproot.nBg.transform.GetLocalPosition()
return[t.x+20,t.y-8]}GetSize(){return[this.ui_tiproot.nBg.transform.width,this.ui_tiproot.nBg.transform.height]}CloseTip(){I.J.Inst_get().ForceCloseTipView(),(0,
l.sR)(r.o.HorseItemTipPanel)}Clear(){m.g.Inst_get().ClearTip(),_.W.ins.ClosePanel(),this.ui_tiproot.OnReposition_set(null),this.leftpart.Clear(),super.Clear()}Destroy(){
this.leftpart.Destroy(),super.destroy()}Test1(){return!0}S_Test(){return!0}})||s)},12488:(t,e,i)=>{i.d(e,{I:()=>h})
var s,n=i(6847),a=i(83908),o=i(17409),l=i(49655),r=i(46282)
let h=(0,n.s_)(l.o.HorseMainView,r.Z.ui_horse_mainview).waitPrefab(r.Z.ui_horse_item).register()(s=class extends((0,a.Ri)()){constructor(...t){super(...t),
this._degf_onSelectHorseCall=null}_initBinder(){this._degf_onSelectHorseCall=t=>{this.onSelectHorseCall(t)}}InitView(){
this.ui_horse_basepanel.onSelectHorseCall=this._degf_onSelectHorseCall}SetData(){this.ui_horse_basepanel.OnAddToScene()}onSelectHorseCall(t){this.ui_horse_up_panel.SetData(t)}
OnCloseClick(){(0,o.sR)(l.o.HorseMainView)}Test1(){return!0}S_Test(){return!0}})||s},52435:(t,e,i)=>{i.d(e,{A:()=>d})
var s,n=i(18998),a=i(83908),o=i(87923),l=i(33833)
const{ccclass:r,property:h}=n._decorator
let d=r("HorseRidingAttrItem")(s=class extends((0,a.yk)()){InitView(){}SetData(t){if(t.isMaxLevel){const e=l.X.Inst().getItemByName(t.type)
let i=e&&o.l.getAttrValueStr(e.id,t.value)
"RIDING_ATTACK"==t.type?(this.nameLabel.textSet("全部坐骑攻击提升"),i=`${t.value}%`):"RIDING_DEFENSE"==t.type?(this.nameLabel.textSet("全部坐骑防御提升"),
i=`${t.value}%`):"RIDING_HP"==t.type?(this.nameLabel.textSet("全部坐骑生命提升"),i=`${t.value}%`):this.nameLabel.textSet(e.name),this.valueLabel.textSet(`+${i}`),
this.nextValueLabel.textSet(""),this.arrowImg.SetActive(!1)}else{const e=l.X.Inst().getItemByName(t[1].type)
let i=e&&o.l.getAttrValueStr(e.id,t[1].value)
const s=l.X.Inst().getItemByName(t[2].type)
let n=null
if(null==s||!t.isZeroLevel&&t[2].value==t[1].value||(n=o.l.getAttrValueStr(s.id,t[2].value)),"RIDING_ATTACK"==t[1].type){this.nameLabel.textSet("全部坐骑攻击提升"),i=`${t[1].value}%`,
n=`${t[2].value}%`
t[2].value,t[1].value
n=this.GetNextDes(t)}else"RIDING_DEFENSE"==t[1].type?(this.nameLabel.textSet("全部坐骑防御提升"),i=`${t[1].value}%`,
n=this.GetNextDes(t)):"RIDING_HP"==t[1].type?(this.nameLabel.textSet("全部坐骑生命提升"),i=`${t[1].value}%`,n=this.GetNextDes(t)):this.nameLabel.textSet(e.name)
t.isZeroLevel?this.valueLabel.textSet("+0"):this.valueLabel.textSet(`+${i}`),null!=n?(this.nextValueLabel.textSet(n),this.arrowImg.SetActive(!0)):(this.nextValueLabel.textSet(""),
this.arrowImg.SetActive(!1))}}GetNextDes(t){return t[2].value-t[1].value>0||t.isZeroLevel?`${t[2].value}%`:null}})||s},21660:(t,e,i)=>{i.d(e,{o:()=>h})
var s,n=i(18998),a=i(83908),o=i(70850)
const{ccclass:l,property:r}=n._decorator
let h=l("HorseRidingCostItem")(s=class extends((0,a.yk)()){InitView(){}SetData(t){this.ui_baseitem.SetData(t)
let e=""
const i=o.g.Inst_get().GetItemNum(t.modelId_get()),s=t.greenRateNum
e=i>=s?`[5fb470]${i}[-]/${s}`:`[de2524]${i}[-]/${s}`,this.valueLabel.textSet(e)}Test1(){return!0}S_Test(){return!0}})||s},23937:(t,e,i)=>{
var s,n,a=i(18998),o=i(83908),l=i(18202),r=i(83540),h=i(28192),d=i(82589)
const{ccclass:u,property:c}=a._decorator
u("HorseRidingItem")((n=class t extends((0,o.yk)()){constructor(...t){super(...t),this._m_handlerMgr=null,this.clickHandler=null,this.data=null,this.centerOnSelect=null}
get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=h.h.Get()),this._m_handlerMgr}InitView(){this.select.node.SetActive(!1),this.RedPoint.SetActive(!1),
this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.OnClickItem))}SetData(t){this.data=t
const e=t.GetLevelCfg()
l.g.SetItemIcon(this.img,e.icon,r.b.eSkill),this.RedPoint.SetActive(t.CanUpgrade()),t.IsLock()?(this.lockContainer.SetActive(!0),this.stateTip.textSet("0"),
1==e.specSkill?this.bg.spriteNameSet("atlas/zuoqi/ryzuoqiqishu_sp_0009"):(this.bg.spriteNameSet("atlas/zuoqi/ryzuoqiqishu_sp_0008"),this.bg.widthSet(90),
this.bg.heightSet(90))):(this.lockContainer.SetActive(!1),
1==e.specSkill?this.bg.spriteNameSet("atlas/zuoqi/ryzuoqiqishu_sp_0009"):this.bg.spriteNameSet("atlas/zuoqi/ryzuoqiqishu_sp_0006"),
t.IsMaxLevel()?this.stateTip.textSet("[58e545]满[-]"):this.stateTip.textSet(e.level.toString()))}AdjustScrollViewPos(){this.centerOnSelect&&this.centerOnSelect.OnSelect()}
OnClickItem(){this.SetSelect(!0),null!=this.clickHandler&&this.clickHandler(this.data)}SetSelect(e){e?(null!=t._CreateSelectItem&&t._CreateSelectItem.SetSelect(!1),
t._CreateSelectItem=this,this.select.node.SetActive(!0)):this.select.node.SetActive(!1)}playEffect(){const t=this.effect
if(null==t.getComponent(d.J)){t.addComponent(d.J)
let e=t.getComponent(d.J)
e.prefix=4,e.repeat=1,e.playOverRecover=!1,e.playOverRemove=!1,e.path="pre_eff_unlock02_01"}else{t.getComponent(d.J).replay(1)}}Clear(){this.clickHandler=null,
t._CreateSelectItem=null}},n._CreateSelectItem=null,s=n))},27129:(t,e,i)=>{i.d(e,{z:()=>y})
var s,n=i(18998),a=i(75507),o=i(6847),l=i(83908),r=i(49655),h=i(46282),d=i(28192),u=i(85602),c=i(79534),_=i(53905),I=i(92679),g=i(65772),m=i(65550),C=i(32691),S=i(92202),p=i(52435),A=i(21660)
class f extends((0,l.Ri)()){InitView(){}GetHorseSkillItemByIdx(t){return this[`horseItem${t}`]}HideLastLine(){this.line10.SetActive(!1)}ActiveLine(t){const e=this[`line${t}`]
e&&e.spriteNameSet("atlas/zuoqi/ryzuoqiqishu_sp_0004")}}
let y=(0,o.s_)(r.o.HorseRidingView,h.Z.ui_horse_ridingview).waitPrefab(h.Z.ui_horse_riding_item).waitPrefab(h.Z.ui_horse_riding_itemGroup).register()(s=class extends((0,l.Ri)()){
constructor(...t){super(...t),this._m_handlerMgr=null,this.currentData=null,this.currentLevel=0,this.horseSkillItem=null,this.horseSkillItemGroup=null,this.commEffect=null,
this.upEffect=null}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=d.h.Get()),this._m_handlerMgr}_initBinder(){super._initBinder(),this.horseSkillItem=new u.Z,
this.horseSkillItemGroup=new u.Z}InitView(){this.nextAttrList.SetInitInfo("ui_horse_riding_attritem",null,p.A),this.itemGrid.SetInitInfo("ui_horse_riding_cost_item",null,A.o),
this.upRedPoint.SetActive(!1)}SetData(){this.m_handlerMgr.AddClickEvent(this.upBtn,this.CreateDelegate(this.OnUpgrade)),
this.m_handlerMgr.AddClickEvent(this.tipBtn,this.CreateDelegate(this.OpenTip)),this.m_handlerMgr.AddEventMgr(I.g.HORSE_RIDING_UPDATE,this.CreateDelegate(this.UpdateData)),
this.updateHorseRidingGraphic()}UpdateData(){if(this.currentData){let t=this.GetRidingItem(this.currentData.skillId),e=t[0],i=t[1]
e.SetData(e.data),e.playEffect(),this.ShowItem(this.currentData),null!=i&&i.SetData(i.data)}}updateHorseRidingGraphic(){const t=S.O.Inst_get().GetHorseSkillList()
let e=0
const i=this.horseSkillItem.Count()
for(let s=0;s<=t.Count()-1;s++){this.GetRidingItem(t[s].skillId)[0].SetData(t[s])
const n=Math.floor(i/10),a=i%10+1,o=this.horseSkillItemGroup[n]
!t[s].IsLock()&&o&&o.ActiveLine(a),(0==e&&t[s].CanUpgrade()||0==e&&(s!=t.Count()-1&&!t[s].IsLock()&&t[s+1].IsLock()&&!t[s].IsMaxLevel()||s==t.Count()&&!t[s].IsLock())||0==e&&0!=s&&t[s-1].IsMaxLevel()&&t[s].IsLock())&&(e=s)
}this.horseSkillItemGroup.Count()>0&&this.horseSkillItemGroup[this.horseSkillItemGroup.Count()-1].HideLastLine()
let s=this.horseSkillItem[e]
s&&(s.SetSelect(!0),s.AdjustScrollViewPos(),this.OnSelectItem(s.data))}GetRidingItem(t){const e=this.horseSkillItem.Count()
for(let i=0;i<=e-1;i++)if(this.horseSkillItem[i].data.skillId==t)return i<e-1?[this.horseSkillItem[i],this.horseSkillItem[i+1]]:[this.horseSkillItem[i]]
const i=Math.floor(e/10),s=e%10+1
let o=this.horseSkillItemGroup[i]
if(!o){const t=a.o.getPrefab("ui_horse_riding_itemGroup")
o=(0,n.instantiate)(t).getCNode(f),o.node.setParent(this.ridingItemContainer.node),this.horseSkillItemGroup.Add(o)
const e=1169*i
o.node.transform.SetLocalPositionXYZ(e,0,0)}let l=null
return l=o.GetHorseSkillItemByIdx(s),l.clickHandler=this.CreateDelegate(this.OnSelectItem),this.horseSkillItem.Add(l),[l]}OnSelectItem(t){this.currentData=t,this.ShowItem(t)}
ShowItem(t){const e=t.GetLevelCfg()
this.nameLabel.textSet(e.name),this.upRedPoint.SetActive(t.CanUpgrade()),this.currentLevel=t.level
let i=0
this.descLabel.textSet(e.desc)
let s=this.descLabel.node.transform.GetLocalPosition()
i=Math.abs(s.y)+this.descLabel.height()+30
const n=t.IsMaxLevel()
if(this.nextAttrContainer.SetActive(!n),this.conditionContainer.SetActive(!n),n){this.disableBtn.SetActive(!0),this.disableBtnLabel.textSet("已满级"),this.upBtn.node.SetActive(!1),
this.nextAttrContainer.SetActive(!0)
const e=t.GetLevelCfg(),s=new u.Z
for(let t=0;t<e.attrs.length;t++){const i=e.attrs[t]
i.isMaxLevel=!0,s.Add(i)}this.nextAttrList.data_set(s),this.nextAttrContainer.SetLocalPositionXYZ(0,-i,0)}else{this.nextAttrContainer.SetActive(!0)
const e=t.GetLevelCfg(t.level+1),n=t.GetLevelCfg(),a=new u.Z
for(let t=0;t<e.attrs.length;t++){const i={}
0==this.currentLevel&&(i.isZeroLevel=!0),i[1]=n.attrs[t],i[2]=e.attrs[t],a.Add(i)}this.nextAttrList.data_set(a),this.nextAttrContainer.SetLocalPositionXYZ(0,-i,0),
i=i+34*e.attrs.length+40,s=this.conditionContainer.transform.GetLocalPosition(),s.y=-i,this.conditionContainer.transform.SetLocalPosition(s),
this.itemGrid.data_set(t.GetCostItemList())
let o="坐骑总阶数达到"
if(S.O.Inst_get().GetTotalStage()<n.horseCondition?o+=`[de2524]${n.horseCondition}[-]`:o+=n.horseCondition,o+="阶",this.horseStageConditionLabel.textSet(o),n.skillCondition>0){
this.horseLevelConditionLabel.node.SetActive(!0)
const e=S.O.Inst_get().GetHorseRidingSkillDataBySkillId(t.skillId-1),i=e.GetLevelCfg()
let s=""
s=e.level>=n.skillCondition?`${i.name}等级达到${n.skillCondition}级`:`${i.name}等级达到[de2524]${n.skillCondition}[-]级`,this.horseLevelConditionLabel.textSet(s)
}else this.horseLevelConditionLabel.node.SetActive(!1)
t.UpgradeCondition()?(this.disableBtn.SetActive(!1),this.upBtn.node.SetActive(!0)):(this.upBtn.node.SetActive(!1),this.disableBtn.SetActive(!0),this.disableBtnLabel.textSet("升级"))}
let a=""
t.IsLock()?a="未解锁":(a=`${e.level}级`,n&&(a+="(满级)")),this.levelLabel.textSet(a)}OnUpgrade(){if(!this.currentData.UpgradeItemEnough()){const t=this.currentData.GetCostItemList()[0]
return INS.itemTipManager.OpenTipView(t),void m.y.inst.ClientSysMessage(180044)}C.C.Inst_get().CM_RidingSkillAct(this.currentData.skillId)}OpenTip(){const t=new _.w
t.infoId="RIDING:SKILLTIPS1",t.position=new c.P(140,0,0),t.width=400,t.height=80,g.Q.Inst_get().Open(t)}playEffect(){}Clear(){super.Clear(),
null!=this.upEffect&&(this.upEffect.Clear(),this.upEffect=null),null!=this.commEffect&&(this.commEffect.Clear(),this.commEffect=null)
for(let t=0;t<=this.horseSkillItemGroup.Count()-1;t++)this.horseSkillItemGroup[t].Clear()}Destroy(){}})||s},10328:(t,e,i)=>{i.d(e,{K:()=>c})
var s,n=i(18998),a=i(83908),o=i(18202),l=i(83540),r=i(28192),h=i(87923)
const{ccclass:d,property:u}=n._decorator
let c=d("HorseSelectItem")(s=class extends((0,a.yk)()){constructor(...t){super(...t),this._m_handlerMgr=null,this.data=null,this.clickHandler=null}get m_handlerMgr(){
return this._m_handlerMgr||(this._m_handlerMgr=r.h.Get()),this._m_handlerMgr}InitView(){}SetData(t){this.data=t.horseData
const e=this.data.cfgData
o.g.SetItemIcon(this.img,e.headId,l.b.eHorse),this.quality.spriteNameSet(h.l.getQualityImgByQuality(e.horseGrade)),this.sign.SetActive(this.data.isDress),
this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.OnClick))}OnClick(){null!=this.clickHandler&&this.clickHandler(this.data)}})||s},12712:(t,e,i)=>{
var s,n=i(6847),a=i(83908),o=i(17409),l=i(49655),r=i(46282),h=i(85602),d=i(32691),u=i(92202),c=i(10328);(0,
n.s_)(l.o.HorseSelectView,r.Z.ui_horse_selectpanel).register()(s=class t extends((0,a.Ri)()){constructor(...t){super(...t),this.role=null}InitView(){super.InitView(),
this.grid.SetInitInfo("ui_horse_select_item",this.CreateDelegate(this.OnCreateItem)),this.AddClickEvent(this.node,this.CreateDelegate(this.Close)),
this.SetData(d.C.Inst_get().roleData),d.C.Inst_get().roleData=null}SetData(e){this.role=e
const i=new h.Z,s=u.O.Inst_get().GetHorseDataList()
for(let t=0;t<=s.Count()-1;t++)s[t].IsActive()&&e.horseId_get()!=s[t].horseId&&i.Add({horseData:s[t],role:e})
i.Sort(t.Sort),this.grid.data_set(i),this.grid.Reposition(),this.horseListScrollView.ResetPosition()}OnCreateItem(t){const e=t[0].getCNode(c.K)
return e.clickHandler=this.CreateDelegate(this.OnClickItem),e}static Sort(t,e){const i=t.horseData,s=e.horseData
return i.isDress?1:s.isDress?-1:s.cfgData.horseGrade-i.cfgData.horseGrade}OnClickItem(t){d.C.Inst_get().CM_RidingChange(t.horseId,this.role.Id_get()),this.Close()}DressHorse(){}
Close(){(0,o.sR)(l.o.HorseSelectView)}})},92905:(t,e,i)=>{i.d(e,{c:()=>I})
var s,n=i(6847),a=i(83908),o=i(17409),l=i(49655),r=i(46282),h=i(5924),d=i(18202),u=i(83540),c=i(28192),_=i(32691)
let I=(0,n.s_)(l.o.HorseSkillAddView,r.Z.ui_horseskill_new_ry).register()(s=class extends((0,a.Ri)()){constructor(...t){super(...t),this._m_handlerMgr=null,this._data=null,
this.intervalId=null,this.closeTime=null}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=c.h.Get()),this._m_handlerMgr}InitView(){this.OnAddToScene()}
OnAddToScene(){this.AddLis(),this.ShowNextSkill()}ShowNextSkill(){const t=_.C.Inst_get().newHorseSkill
this.SetSkill(t),this.PlayShowEffect()}SetSkill(t){this._data=t,this.skillname.textSet(this._data.name),d.g.SetItemIcon(this.skillicon,this._data.skillIcon,u.b.eSkill)
const e=this._data.skillDesc
this.skilldesc.textSet(e)}PlayShowEffect(){this.effectPanel.SetActive(!1),this.effectPanel.SetActive(!0),this.closeEffect.SetActive(!1),
null!=this.intervalId&&(h.C.Inst_get().ClearInterval(this.intervalId),this.intervalId=null),this.closeTime=5,
this.intervalId=h.C.Inst_get().SetInterval(this.CreateDelegate(this.OnAutoCloseLoop),1e3),this.OnAutoCloseLoop()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.mask,this.CreateDelegate(this.CheckClose))}OnAutoCloseLoop(){this.closeTime<=0?this.CheckClose():(this.closeTime-=1,
this.closetime.textSet(`点击空白处关闭（${this.closeTime}）`))}CheckClose(){this.close()}close(){this.closeEffect.SetActive(!0),
null!=this.intervalId&&(h.C.Inst_get().ClearInterval(this.intervalId),this.intervalId=null),(0,o.sR)(l.o.HorseSkillAddView)}RemoveLis(){
null!=this.intervalId&&(h.C.Inst_get().ClearInterval(this.intervalId),this.intervalId=null)}Clear(){this.RemoveLis(),super.Clear()}Test1(){return!0}S_Test(){return!0}})||s},
55227:(t,e,i)=>{var s,n=i(18998),a=i(83908),o=i(85682),l=i(18202),r=i(83540),h=i(28192),d=i(60130),u=i(58158),c=i(85751),_=i(87923),I=i(32691),g=i(92202)
const{ccclass:m,property:C}=n._decorator
m("HorseSkillItem")(s=class extends((0,a.yk)()){constructor(...t){super(...t),this._m_handlerMgr=null,this.horseLevelData=null,this.data=null,this.showEffect=!1,this.inited=!1,
this.clickeffect=null,this.hasskill=null}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=h.h.Get()),this._m_handlerMgr}InitView(){super.InitView(),
this.clickeffect=!1}SetData(t){this.UnRegGuide(),this.data=t,this.horseLevelData=t.cfg
const e=g.O.Inst_get().GetHorseDataById(this.horseLevelData.horseId)
let i=!1
i=2==e.cfgData.horseType?e.IsActive():e.IsActive()&&e.Stage_get()>=this.horseLevelData.horseRank&&e.Level_get()>=this.horseLevelData.horseLevel
let s=!1
i?(this.hasskill=e.HasSkill(this.data.skill),this.hasskill?(this.showEffect=!1,this.tipLabel.textSet(t.name),
d.O.makeGoGray(this.skillIcon.node,!1)):(this.tipLabel.textSet(c.u.BrightGoldColorStr2+"点击解锁"+c.u.EndSymbol),this.showEffect=!0,d.O.makeGoGray(this.skillIcon.node,!0),
s=!0)):(this.showEffect=!1,2==e.cfgData.horseType||1==this.horseLevelData.horseRank?this.tipLabel.textSet("激活解锁"):this.tipLabel.textSet(`${this.horseLevelData.horseRank}阶解锁`),
d.O.makeGoGray(this.skillIcon.node,!0)),this.Sprite.SetActive(s),l.g.SetItemIcon(this.skillIcon,t.skillIcon,r.b.eSkill,!1),
this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.OnClickItem)),this.m_handlerMgr.AddEventMgr(g.O.SKILL_UPDATE,this.CreateDelegate(this.SkillUpdate)),
this.m_handlerMgr.AddEventMgr(u.U.MAINUI_ANIMATION_COMPLETE,this.CreateDelegate(this.OnAniEnd)),this.RegGuide(),u.U.Inst_get().AniPlayEnd&&(this.inited=!0),this.ShowEffect()}
RegGuide(){}UnRegGuide(){}OnClickItem(){_.l.CheckBtnClickTrigger(o.D.UI_ROLE_HORSE_SKILL)
let t=!1
const e=g.O.Inst_get().GetHorseDataById(this.horseLevelData.horseId)
t=2==e.cfgData.horseType?e.IsActive():e.IsActive()&&e.Stage_get()>=this.horseLevelData.horseRank&&e.Level_get()>=this.horseLevelData.horseLevel,
this.hasskill=e.HasSkill(this.data.skill),
t&&!this.hasskill?I.C.Inst_get().CM_RidingActSkill(this.horseLevelData.horseId,this.data.skill):I.C.Inst_get().OpenHorseSKillTipView(this.data)}ShowEffect(){}SkillUpdate(t){
this.data.skill==t&&(this.tipLabel.textSet(this.data.name),d.O.makeGoGray(this.skillIcon.node,!1),this.Sprite.SetActive(!1))}OnAniEnd(){this.inited=!0,this.ShowEffect()}Clear(){
this.UnRegGuide()}})},59810:(t,e,i)=>{
var s,n=i(18998),a=i(75507),o=i(6847),l=i(83908),r=i(49655),h=i(46282),d=i(13687),u=i(5924),c=i(28192),_=i(60130),I=i(85602),g=i(55661),m=i(21334),C=i(92202),S=i(32691),p=i(7790)
;(0,o.s_)(r.o.HorseSkillMainView,h.Z.ui_horse_skill_mainview).waitPrefab(h.Z.ui_horse_skill_mainview_item).register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),
this._m_handlerMgr=null,this.itemList=null,this.cacheList=null,this.startY=0,this.aimY=0,this.moveTotalDistance=0,this.loopMoveTimerId=-1,this.moving=!1,this.breakLoop=!1}
get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=c.h.Get()),this._m_handlerMgr}_initBinder(){super._initBinder(),this.itemList=new I.Z,this.cacheList=new I.Z}
InitView(){this.UpdateAnchors()}OnAddToScene(){m.p.Inst_get().GetMapById(d.b.Inst.currentMapId_get()).senceType,g.S.CopyMap,this.container.SetLocalPositionXYZ(450,50,0),
this.ShowNext()}UpdateAnchors(t){_.O.SetAnchorPos(this.anchor,!0,!0,0,!0)}ShowNext(){if(!this.moving&&this.itemList.Count()<3){const t=C.O.Inst_get().GetNextSHowSKill()
null!=t&&(t.isShow=!0,this.AddItem(t))}}AddItem(t){let e=this.cacheList[0]
null==e?e=this.GetItem():this.cacheList.RemoveAt(0)
const i=e.node.transform.GetLocalPosition()
i.y=0,e.isCycle=!1,e.node.transform.SetLocalPosition(i),e.node.SetActive(!1),this.itemList.Add(e),e.SetData(t),this.MoveStart()}UpdateItemHurtValue(t){
for(let e=0;e<=this.itemList.Count()-1;e++){if(this.itemList[e].data.skillId==t){this.itemList[e].UpdateHurtValue()
break}}}MoveStart(){
this.moving=!0,this.moveTotalDistance=0,this.breakLoop=!1,null!=this.loopMoveTimerId&&-1!=this.loopMoveTimerId||(this.loopMoveTimerId=u.C.Inst_get().SetFrameLoop(this.CreateDelegate(this.LoopMove),1))
}LoopMove(){if(this.breakLoop)return void this.MoveEnd()
let t=200*u.C.Inst_get().distanceTime*.001
this.moveTotalDistance+=t,this.moveTotalDistance>=53&&(t=this.moveTotalDistance-53,this.breakLoop=!0)
let e=-1e5
for(let i=this.itemList.Count()-1;i>=0;i+=-1){const s=this.itemList[i]
let n=s.node.transform.GetLocalPosition()
n.y+=t,e+51>n.y&&(n.y=e+51),e=n.y,s.node.transform.SetLocalPosition(n)}}MoveEnd(){this.moving=!1,this.ClearTime()
const t=this.itemList[this.itemList.Count()-1]
null!=t&&t.node.SetActive(!0),this.ShowNext()}GetItem(){const t=a.o.getPrefab("ui_horse_skill_mainview_item"),e=(0,n.instantiate)(t).getCNode(p.A)
return e.node.setParent(this.container),e.expireHandler=this.CreateDelegate(this.OnExpireItem),this.m_handlerMgr.AddClearComponent(e,!1,!1),e}ClearTime(){
u.C.Inst_get().ClearLoop(this.loopMoveTimerId),this.loopMoveTimerId=-1}OnExpireItem(t){t.isCycle||(t.node.SetActive(!1),this.itemList.Remove(t),this.cacheList.Add(t),
C.O.Inst_get().RemoveHorseSkillShow(t.data),t.data=null,t.isCycle=!0)}Clear(){for(let t=0;t<=this.itemList.Count()-1;t++)this.itemList[t].Clear()
for(let t=0;t<=this.cacheList.Count()-1;t++)this.cacheList[t].Clear()
super.Clear()}Destroy(){for(let t=0;t<=this.itemList.Count()-1;t++)this.itemList[t].Destroy()
for(let t=0;t<=this.cacheList.Count()-1;t++)this.cacheList[t].Destroy()
this.ClearTime(),S.C.Inst_get().horseSkillMainViewLoading=!1}Test1(){return!0}S_Test(){return!0}})},7790:(t,e,i)=>{i.d(e,{A:()=>g})
var s,n=i(18998),a=i(83908),o=i(70829),l=i(5924),r=i(18202),h=i(83540),d=i(92984),u=i(87923),c=i(11037)
const{ccclass:_,property:I}=n._decorator
let g=_("HorseSkillMainViewItem")(s=class extends((0,a.Ri)()){constructor(...t){super(...t),this.timeId=-1,this.expireHandler=null,this.data=null,this.isCycle=!1}InitView(){}
SetData(t){this.data=t,this.UpdateContent()
const e=this.skillName.node.transform.GetLocalPosition(),i=this.hurtValueLabel.node.transform.GetLocalPosition()
this.skillName.updateRenderer(),i.x=e.x+this.skillName.width()+10,this.hurtValueLabel.node.transform.SetLocalPosition(i),this.UpdateHurtValue(),this.ClearTime(),
this.timeId=l.C.Inst_get().SetInterval(this.CreateDelegate(this.ExpireTime),3e3,1),this.pre_eff_ridingnotice_1.replay(1)}UpdateContent(){const t=this.data.buffId>0
this.skillicon.SetActive(!t&&1==this.data.type),this.horseIcon.SetActive(!t&&0==this.data.type),this.bufflicon.SetActive(t),
this.data.buffId>0?this.UpdateBuffContent(this.data):0==this.data.type?this.UpdateHorseContent(this.data):1==this.data.type&&this.UpdateWeaponContent()}UpdateBuffContent(t){
const e=d.j.Inst_get().model.GetBuffResById(t.buffId)
this.skillName.textSet(e.name),r.g.SetItemIcon(this.bufflicon,e.icon,h.b.eBuff,!1)}UpdateHorseContent(t){const e=c.D.GetInst().GetHorseLevelSkill(t.skillId)
let i=!1
u.l.IsEmptyStr(e.skill)||e.skill==t.skillId&&(i=!0,this.skillName.textSet(`${e.name}伤害`)),i||u.l.IsEmptyStr(e.skill2)||e.skill2==t.skillId&&this.skillName.textSet(`${e.name2}伤害`)
const s=c.D.GetInst().GetCfg(e.horseId)
r.g.SetItemIcon(this.horseIcon,s.headId,h.b.eHorse,!1)}UpdateWeaponContent(){const t=o.j.Inst().GetSkillByStrId(this.data.skillId)
this.skillName.textSet(`${t.name}伤害`),r.g.SetItemIcon(this.skillicon,t.skillicon,h.b.eSkill,!1)}UpdateHurtValue(){if(this.data.buffId>0){
const t=d.j.Inst_get().model.GetBuffResById(this.data.buffId)
this.hurtValueLabel.textSet(t.desc)}else this.hurtValueLabel.textSet(this.data.hurtValue)}ExpireTime(){null!=this.expireHandler&&this.expireHandler(this)}ClearTime(){
l.C.Inst_get().ClearInterval(this.timeId),this.timeId=-1}Clear(){super.Clear()}Destroy(){this.expireHandler=null,this.ClearTime()}Test1(){return!0}S_Test(){return!0}})||s},
12966:(t,e,i)=>{var s,n=i(6847),a=i(83908),o=i(17409),l=i(49655),r=i(46282),h=i(18202),d=i(83540),u=i(32691),c=i(92202);(0,
n.s_)(l.o.HorseSkillTipView,r.Z.ui_horse_skilltipview).register()(s=class extends((0,a.Ri)()){InitView(){this.AddClickEvent(this.node,this.CreateDelegate(this.Close)),
this.SetData(u.C.Inst_get().horseLevelData)}SetData(t){const e=t.cfg,i=c.O.Inst_get().GetHorseDataById(e.horseId)
let s=!1
s=2==i.cfgData.horseType?i.IsActive():i.IsActive()&&i.Stage_get()>=e.horseRank&&i.Level_get()>=e.horseLevel,s?this.lockTip.textSet("已解锁"):this.lockTip.textSet("未解锁"),
h.g.SetItemIcon(this.skillIcon,t.skillIcon,d.b.eSkill),this.descLabel.textSet(t.skillDesc),this.nameLabel.textSet(t.name)}Close(){(0,o.sR)(l.o.HorseSkillTipView)}Clear(){
super.Clear()}})},87558:(t,e,i)=>{var s,n,a=i(18998),o=i(83908),l=i(32697),r=i(20583),h=i(50838),d=i(31546),u=i(41664),c=i(92202)
const{ccclass:_,property:I}=a._decorator
_("HorseTipLeftPart")(((n=class extends((0,o.Ri)()){constructor(...t){super(...t),this.m_horse=null,this.curCfg=null,this.roleRotateIndex=0,this._degf_HorseInitHandler=null,
this.soundKey=null,this.displayUIAvatarModel=null}_initBinder(){super._initBinder(),this._degf_HorseInitHandler=t=>this.HorseInitHandler(t)}InitView(){
this.displayUIAvatarModel=new h.o,this.displayUIAvatarModel.SetTarget(this.rolerotategrid,!0),this.displayUIAvatarModel.SetDir(5)}SetData(t){this.curCfg=t,
this.nameTxt.textSet(this.curCfg.horseName)
const e=c.O.Inst_get().GetHorseDataById(this.curCfg.id)
this.battlescorevalue.textSet(`提升战力:${e.PowerValue_get()}`),this.soundKey=u.j.Inst.PlayBySoundId(this.curCfg.soundId),this.SetModel()}SetModel(){const t=new d.O
t._displayID=this.curCfg.modelId,this.displayUIAvatarModel.SetScale(1,1),r.x.inst.SetUIAvatarData(t._displayID,l.v.horse,this.displayUIAvatarModel)}HorseInitHandler(t){}Destroy(){
null!=this.m_horse&&(this.m_horse.Destroy(),this.m_horse=null)}}).STAGE_ID=62,s=n))},91021:(t,e,i)=>{i.d(e,{T:()=>d})
var s,n=i(18998),a=i(83908),o=i(83540),l=i(18202)
const{ccclass:r,property:h}=n._decorator
let d=r("HorseTipSkillItem")(s=class extends((0,a.yk)()){InitView(){}SetData(t){const e=t.cfg
let i=`[93c8fe]${t.name}[-]`
2==e.horseType||1==e.horseRank?i+="[686763]（激活解锁）[-]":i+=`[686763]（${e.horseRank}阶解锁）[-]`,i+="\n",i+=t.skillDesc,i+="\n",l.g.SetItemIcon(this.skillIcon,t.skillIcon,o.b.eSkill),
this.tipLabel.textSet(i),this.tipIcon.SetActive(1==e.tipsOrder)}})||s},19636:(t,e,i)=>{
var s,n=i(18998),a=i(83908),o=i(38045),l=i(97461),r=i(5924),h=i(28192),d=i(85602),u=i(79534),c=i(63076),_=i(75696),I=i(53905),g=i(65249),m=i(92679),C=i(87923),S=i(65772),p=i(33833),A=i(11037),f=i(65550),y=i(32691),T=i(45537),R=i(92202),v=i(54002)
n._decorator.ccclass("HorseUpgradePanel")(s=class extends((0,a.Ri)()){constructor(...t){super(...t),this._m_handlerMgr=null,this.horseData=null,this.outTimer=-1,this.autoUp=!1,
this.levelStarts=null,this._degf_OnLoopUp=null,this.oldStage=null}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=h.h.Get()),this._m_handlerMgr}_initBinder(){
super._initBinder(),this.levelStarts=new d.Z,this._degf_OnLoopUp=()=>{this.OnLoopUp()}}InitView(){this.levelStarts.Add(this.star1),this.levelStarts.Add(this.star2),
this.levelStarts.Add(this.star3),this.levelStarts.Add(this.star4),this.levelStarts.Add(this.star5),this.itemGrid.SetInitInfo("ui_baseitem",this.CreateDelegate(this.OnCreateItem))}
AddLis(){this.m_handlerMgr.AddClickEvent(this.upBtn.node,this.CreateDelegate(this.OnClickUpBtn)),
this.m_handlerMgr.AddClickEvent(this.autoUpBtn.node,this.CreateDelegate(this.OnClickAutoUpBtn)),
this.m_handlerMgr.AddClickEvent(this.activeBtn.node,this.CreateDelegate(this.onClickActiveBtn)),this.m_handlerMgr.AddClickEvent(this.tipBtn,this.CreateDelegate(this.OnOpenTip)),
this.m_handlerMgr.AddClickEvent(this.autocompose,this.CreateDelegate(this.OnChangeAutoCompose)),
l.i.Inst.AddEventHandler(m.g.BAG_UPDATE,this.CreateDelegate(this.UpdateUseItemList)),l.i.Inst.AddEventHandler(m.g.HORSE_UPGRADE,this.CreateDelegate(this.OnUpgradeHorse)),
l.i.Inst.AddEventHandler(m.g.HORSE_ACTIVE,this.CreateDelegate(this.OnActiveHorse)),l.i.Inst.AddEventHandler(T.z.HORSE_AUTO_COMPOSE,this.CreateDelegate(this.ShowAutoCompose))}
removeLis(){this.m_handlerMgr.RemoveClickEvent(this.upBtn.node,this.CreateDelegate(this.OnClickUpBtn)),
this.m_handlerMgr.RemoveClickEvent(this.autoUpBtn.node,this.CreateDelegate(this.OnClickAutoUpBtn)),
this.m_handlerMgr.RemoveClickEvent(this.activeBtn.node,this.CreateDelegate(this.onClickActiveBtn)),
this.m_handlerMgr.RemoveClickEvent(this.tipBtn,this.CreateDelegate(this.OnOpenTip)),
this.m_handlerMgr.RemoveClickEvent(this.autocompose,this.CreateDelegate(this.OnChangeAutoCompose)),
l.i.Inst.RemoveEventHandler(m.g.BAG_UPDATE,this.CreateDelegate(this.UpdateUseItemList)),l.i.Inst.RemoveEventHandler(m.g.HORSE_UPGRADE,this.CreateDelegate(this.OnUpgradeHorse)),
l.i.Inst.RemoveEventHandler(m.g.HORSE_ACTIVE,this.CreateDelegate(this.OnActiveHorse)),l.i.Inst.RemoveEventHandler(T.z.HORSE_AUTO_COMPOSE,this.CreateDelegate(this.ShowAutoCompose))}
OnChangeAutoCompose(){this.autocompose.GetValue()?y.C.Inst_get().CM_RidingCompose(!1):y.C.Inst_get().CM_RidingCompose(!0)}SetData(t){if(this.AddLis(),
null!=this.horseData&&this.horseData.cfgData.id!=t.cfgData.id&&(this.oldStage=t._stage,this._ClearAutoUp()),
null!=this.horseData&&null!=this.oldStage&&t._stage>this.oldStage&&R.O.Inst_get().ridingCompose){
this.horseData.LevelCfg_get().consume!=R.O.Inst_get().baseCompose&&this._ClearAutoUp()}this.autoUp||this.autoBtnLabel.textSet("自动提升"),this.oldStage=t._stage,this.UnRegGuide(),
this.horseData=t,t.State_get()==v.K.DIS_ACTIVE?this.ShowActiveView(t):2==this.horseData.cfgData.horseType?this.ShowUnrealHorseView(t):this.ShowLevelView(t),this.RegGuide()}
OnUpgradeHorse(t){const e=t.horseData
this.horseData.horseId==e.horseId&&this.SetData(this.horseData)}OnActiveHorse(t){this.horseData.horseId==t.horseId&&this.SetData(this.horseData)}ShowActiveView(t){
this.stageLabel.node.SetActive(!1),this.levelInfoContainer.SetActive(!1),this.autocompose.SetActive(!1),2==this.horseData.cfgData.horseType?(this.activeTipIcon2.SetActive(!0),
this.activeTipIcon.node.SetActive(!1)):(this.activeTipIcon2.SetActive(!1),this.activeTipIcon.node.SetActive(!0)),this.deContainer.SetActive(!0),this.itemlayer.SetActive(!0),
this.maxTip.node.SetActive(!1),this.maxActiveTipIcon.node.SetActive(!1),this.upBtn.node.SetActive(!1),this.autoUpBtn.node.SetActive(!1),this.activeBtn.node.SetActive(!0),
this._SetAttr(t.cfgData,null,null),this._SetUseItem(t.cfgData.activationex.typevalues),this.properyPanelTitle.textSet("激活属性"),this.itemPanelTitle.textSet("激活消耗"),
this.activeRedPoint.SetActive(t.IsCanActive())}ShowLevelView(t){let e=A.D.GetInst().GetLevelCfg(t.horseId,t.Stage_get(),t.Level_get()+1)
null==e&&(e=A.D.GetInst().GetLevelCfg(t.horseId,t.Stage_get()+1,1))
if(this.horseData.LevelCfg_get().consume==R.O.Inst_get().baseCompose||null==e?this.autocompose.SetActive(!1):this.autocompose.SetActive(!0),
null==e)return void this.ShowMaxStageLevelView(t)
this.maxActiveTipIcon.node.SetActive(!1),this.stageLabel.node.SetActive(!0),this.levelInfoContainer.SetActive(!0),this.activeTipIcon.node.SetActive(!1),
this.activeTipIcon2.SetActive(!1),this.itemlayer.SetActive(!0),this.maxTip.node.SetActive(!1),this.deContainer.SetActive(!0),this.upBtn.node.SetActive(!0),
this.autoUpBtn.node.SetActive(!0),this.activeBtn.node.SetActive(!1),this.progress.SetActive(!0)
const i=t.LevelCfg_get()
this.progressLabel.textSet(`${t.experience.ToNum()}/${i.levelExp}`),this.progressBar.node.transform.width=t.experience.ToNum()/i.levelExp*284,
this.stageLabel.textSet(`${t.Stage_get()}阶`),this._ShowLevel(t.Level_get()),this._SetAttr(t.cfgData,i,e),this._SetUseItem(null,i.consume),this.properyPanelTitle.textSet("升级属性"),
this.itemPanelTitle.textSet("升级消耗"),this.upRedPoint.SetActive(t.IsCanUpgradeNext()),this.ShowAutoCompose()}ShowAutoCompose(){
this.autocompose.SetValue(R.O.Inst_get().ridingCompose),y.C.Inst_get().UpdateHorseRedPoint(),this.upRedPoint.SetActive(this.horseData.IsCanUpgradeNext())}RegGuide(){}UnRegGuide(){}
ShowMaxStageLevelView(t){this.properyPanelTitle.textSet("当前属性"),this.stageLabel.textSet(`${t.Stage_get()}阶`),this._ShowLevel(t.Level_get()),this.progress.SetActive(!1),
this.deContainer.SetActive(!0),this.stageLabel.node.SetActive(!0),this.levelInfoContainer.SetActive(!0),this.activeTipIcon.node.SetActive(!1),this.activeTipIcon2.SetActive(!1),
this.itemlayer.SetActive(!1),this.maxTip.node.SetActive(!0),this.maxActiveTipIcon.node.SetActive(!1),this.upBtn.node.SetActive(!1),this.autoUpBtn.node.SetActive(!1),
this.activeBtn.node.SetActive(!1),this._SetAttr(t.cfgData,t.LevelCfg_get())}ShowUnrealHorseView(t){this.autocompose.SetActive(!1),this.properyPanelTitle.textSet("当前属性"),
this.stageLabel.node.SetActive(!1),this.levelInfoContainer.SetActive(!1),this.deContainer.SetActive(!1),this.maxActiveTipIcon.node.SetActive(!0),
this.activeTipIcon.node.SetActive(!1),this.activeTipIcon2.SetActive(!1),this.itemlayer.SetActive(!1),this.maxTip.node.SetActive(!1),this.upBtn.node.SetActive(!1),
this.autoUpBtn.node.SetActive(!1),this.activeBtn.node.SetActive(!1),this._SetAttr(t.cfgData,t.LevelCfg_get())}_ShowLevel(t){t-=1
for(let e=0;e<=this.levelStarts.Count()-1;e++)e<=t?this.levelStarts[e].spriteNameSet("atlas/zuoqi/ryzuoqi_sp_0012"):this.levelStarts[e].spriteNameSet("atlas/zuoqi/ryzuoqi_sp_0013")
}_SetAttr(t,e,i){const s=t.horseAttrsex.typevalues
let n=null,a=null,o=0,l=""
for(let t=0;t<=s.Count()-1;t++)n=s[t],o=parseInt(n.value),a=p.X.Inst().getItemByName(n.type),null!=e&&null!=e[n.type]&&(o+=e[n.type]),l=C.l.getAttrValueStr(a.id,o),
null!=e&&null!=i&&null!=i[n.type]&&null!=e[n.type]&&(l+=` [047104]+${i[n.type]-e[n.type]}[-]`),
"MaxHp"==n.type?this.lifeValue.textSet(l):"Attack"==n.type?this.attackValue.textSet(l):"Defense"==n.type&&this.defLabel.textSet(l)
this.speedValue.textSet(t.speed.toString())}_SetUseItem(t,e){let i=null
const s=new d.Z
if(t)for(let e=0;e<=t.Count()-1;e++){i=t[e]
const n=new c.M((0,o.aI)(i.valueType))
n.showNum=!1,n.needNum=i.valueNum,n.isCanOperate=!1,s.Add(n)}else{const t=new c.M((0,o.aI)(e))
t.showNum=!1,t.needNum=1,t.isCanOperate=!1,s.Add(t)}this.itemGrid.data_set(s)}UpdateUseItemList(){this.itemGrid&&this.itemGrid.updateItems()}OnOpenTip(){
const t=new I.w,e=new d.Z,i=new g.o
i.isPoint=!1,i.content="坐骑属性对多角色同时生效",e.Add(i),t.position=new u.P(130,250,0),t.width=300,t.contents=e,S.Q.Inst_get().Open(t)}onClickActiveBtn(){
if(this.horseData.IsCanActive())y.C.Inst_get().CM_RidingActivate(this.horseData.horseId)
else{const t=this.horseData.cfgData.activationex.typevalues[0],e=new c.M((0,o.aI)(t.valueType))
INS.itemTipManager.OpenTipView(e),f.y.inst.ClientSysMessage(11030603)}}OnClickUpBtn(){
this.horseData.IsCanUpgradeNext()?y.C.Inst_get().CM_RidingUpgrade(this.horseData.horseId,!1):this.ShowUpgradeNeedTip()}ShowUpgradeNeedTip(){
const t=this.horseData.LevelCfg_get().consume,e=new c.M((0,o.aI)(t))
INS.itemTipManager.OpenTipView(e),f.y.inst.ClientSysMessage(11030604)}OnClickAutoUpBtn(){
this.autoUp?this._ClearAutoUp():this.horseData.IsCanUpgradeNext()?(this.upBtn.SetIsEnabled(!1),this.autoUp=!0,this.autoBtnLabel.textSet("暂停提升"),
this.outTimer=r.C.Inst_get().SetInterval(this._degf_OnLoopUp,100)):this.ShowUpgradeNeedTip()}OnLoopUp(){
this.horseData.IsCanUpgradeNext()?y.C.Inst_get().CM_RidingUpgrade(this.horseData.horseId,!0):this._ClearAutoUp()}_ClearAutoUp(){this.autoUp&&(this.upBtn.SetIsEnabled(!0),
this.autoUp=!1,this.autoBtnLabel.textSet("自动提升"),r.C.Inst_get().ClearInterval(this.outTimer))}OnCreateItem(t){const e=t[0].getCNode(_.j)
return e.SetIconSize(50,50),e.SetBgSize(60,60),e}Clear(){this.UnRegGuide(),this.autoUp=!1,this.removeLis(),super.Clear(),r.C.Inst_get().ClearInterval(this.outTimer)}})},
85605:(t,e,i)=>{i.d(e,{$:()=>P})
var s,n,a,o,l,r=i(42292),h=i(71409),d=i(38836),u=i(86133),c=i(97461),_=i(38935),I=i(56937),g=i(31222),m=i(5494),C=i(52726),S=i(28192),p=i(38962),A=i(70123),f=i(70850),y=i(92679),T=i(38119),R=i(12842),v=i(11740),w=i(65550),D=i(19519),E=i(82025),L=i(75582),G=i(60567),O=i(62605),b=i(92962),B=i(92415)
function N(t,e,i,s,n){var a={}
return Object.keys(s).forEach((function(t){a[t]=s[t]})),a.enumerable=!!a.enumerable,a.configurable=!!a.configurable,("value"in a||a.initializer)&&(a.writable=!0),
a=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),a),n&&void 0!==a.initializer&&(a.value=a.initializer?a.initializer.call(n):void 0,a.initializer=void 0),
void 0===a.initializer&&(Object.defineProperty(t,e,a),a=null),a}let P=(s=(0,h.GH)(B.k.SM_ActivityMallInfo),n=(0,h.GH)(B.k.SM_ActivityMallConfig),a=(0,h.GH)(B.k.SM_ActivityMallBuy),
l=class t{static get ins(){return null==t._ins&&(t._ins=new t),t._ins}constructor(){this.m_handlerMgr=null,this.InitHandlerMgr(),this.RegisterMsg()}InitHandlerMgr(){
return null==this.m_handlerMgr&&(this.m_handlerMgr=S.h.Get()),this.m_handlerMgr}AddLis(){}RegisterMsg(){}SM_ActivityMallInfoHandler(t){for(const[e,i]of(0,
d.V5)(t.hasBuyInfo))G.P.ins.huodong_shopBuyInfo_dict.LuaDic_AddOrSetItem(e,i),c.i.Inst.RaiseEvent(y.g.HUODONG_MALL_BUY_CNT_CHANGE,e)
c.i.Inst.RaiseEvent(y.g.HUODONG_MALL_BUY_CNT_LIST_CHANGE,t.activityId)}SM_ActivityMallConfigHandler(t){
0!=t.activityId&&(null==G.P.ins.huodong_shop_dict[t.activityId]&&(G.P.ins.huodong_shop_dict[t.activityId]=new p.X),G.P.ins.huodong_shop_dict[t.activityId]=t.configVos,
c.i.Inst.RaiseEvent(y.g.HUODONG_MALL_CHANGE,t))}SM_ActivityMallBuyHandler(t){1==L.Z.ins.GetVoByMallId(t.mallId).show_suc&&this.OpenSuccessPanel(t.reward),
c.i.Inst.RaiseEvent(y.g.HUODONG_MALL_BUY_SUCCESS,t)}CM_ActivityMallBuy(t,e){null==e&&(e=1)
const i=new T.q
i.mallId=t,i.num=e,_.C.Inst.F_SendMsg(i)}OpenSuccessPanel(t){G.P.ins.reward=t
const e=new I.v
e.isShowMask=!0,e.layerType=C.F.Tip,e.viewClass=b.k,g.N.inst.OpenById(m.I.HuoDongMallSuccessPanel,null,null,e)}CheckItemEnough(t,e,i,s,n){const a=f.g.Inst_get().GetItemNum(e)
if(a>=i)return!0
null==s&&(s=E.f.TICKET_TYPE)
const o=i-a,l=G.P.ins.GetVoByHuodongIdAndType(t,s)
if(t==R.t.SPRINGFESTIVAL_SHOP&&0==l.Remain_Num())return void w.y.inst.ClientSysStrMsg((0,u.T)("点燃次数不足"))
let r=`${l.mallId}_simple`
if(o>1&&(r=`${l.mallId}_multi`),G.P.ins.ignore_dict.LuaDic_GetItem(r)){if(this.CheckConsumeEnough(l.Consume_Get(),o)){if(t==R.t.SPRINGFESTIVAL_SHOP){
const[t,e]=v.K.Inst_get().GetCelebrateDiscount()
e!=t&&G.P.ins.ignore_dict.LuaDic_AddOrSetItem(r,!1)}this.CM_ActivityMallBuy(l.mallId,o),c.i.Inst.RaiseEvent(y.g.HUODONG_MALL_BUY_PANEL_SURE,t)}return}G.P.ins.show_buy_huodongId=t,
G.P.ins.show_buy_cnt=o,G.P.ins.show_buy_type=s,G.P.ins.show_content_params=n
const h=new I.v
return h.isShowMask=!0,h.layerType=C.F.Tip,h.viewClass=O.Z,g.N.inst.OpenById(m.I.HuoDongMallBuyPanel,null,null,h),!1}CheckConsumeEnough(t,e,i){null==e&&(e=1),null==i&&(i=!0)
const s=t.GetItemDataByType().count*e
if(null!=t.currencyItem_get()){if(D.J.IsMoneyEnough(t.currencyItem_get().virtualItemData_get().virtualTypeStr,s))return!0
i&&A.W.ins.OpenCurrencyAccess(t.currencyItem_get().virtualItemData_get().virtualTypeStr,s)}else if(null!=t.baseItem_get()){
if(f.g.Inst_get().GetItemNum(t.baseItem_get().modelId_get())>=s)return!0
i&&A.W.ins.OpenAccessByItemId(t.baseItem_get().modelId_get(),null,null)}return!1}},l._ins=null,N(o=l,"ins",[r.n],Object.getOwnPropertyDescriptor(o,"ins"),o),
N(o.prototype,"SM_ActivityMallInfoHandler",[s],Object.getOwnPropertyDescriptor(o.prototype,"SM_ActivityMallInfoHandler"),o.prototype),
N(o.prototype,"SM_ActivityMallConfigHandler",[n],Object.getOwnPropertyDescriptor(o.prototype,"SM_ActivityMallConfigHandler"),o.prototype),
N(o.prototype,"SM_ActivityMallBuyHandler",[a],Object.getOwnPropertyDescriptor(o.prototype,"SM_ActivityMallBuyHandler"),o.prototype),o)},75582:(t,e,i)=>{i.d(e,{Z:()=>a})
var s=i(93984),n=i(55360)
class a{constructor(){this.map_shop=null
const t=n.Y.Inst.GetOrCreateCsv(s.h.eActivityShopResource)
this.map_shop=t.GetCsvMap()}static get ins(){return null==a._ins&&(a._ins=new a),a._ins}GetVoByMallId(t){return this.map_shop[t]}}a._ins=null},95523:(t,e,i)=>{i.d(e,{y:()=>I})
var s,n=i(18998),a=i(90419),o=i(50089),l=i(98885),r=i(85602),h=i(46749),d=i(2457),u=i(39491),c=i(28359),_=i(60567)
let I=n._decorator.ccclass("HuoDongMallItemVo")(s=class extends u.h{constructor(){super(),this.consumes=null,this.viewConditionList=null,this.buyConditionList=null,
this.vipLevel=null}Wrap(t){this.mallId=t.mallId,this.reward=t.reward,this.consumeDefs=t.consumeDefs,this.limit=t.limit,this.activityId=t.activityId,this.type=t.type,
this.giveReward=t.giveReward,this.buyCond=t.buyCond,this.viewCond=t.viewCond,this.rechargeId=t.rechargeId,this.nextFreshTime=t.nextFreshTime,this.timeControl=t.timeControl}
Consume_Get(){this.consumes
{const t=a.d.parseJsonObjectWithFix(this.consumeDefs,"rewardValues")
this.consumes=o.t.decode(t,c.h),this.consumes.Parse()}if(null!=this.consumes.rewardValues[0].num){const t=_.P.ins.GetBuyTimesByMallId(this.mallId)
let e=this.consumes.rewardValues[0]
for(let i=0;i<=this.consumes.rewardValues.Count()-1;i++){const s=this.consumes.rewardValues[i]
t>=s.num&&(e=s)}return e}return this.consumes.rewardValues[0]}ViewConditions_Get(){if(l.M.IsNullOrEmpty(this.viewCond)||"null"==this.viewCond)return this.viewConditionList=new r.Z,
this.viewConditionList
if(null==this.viewConditionList){const t={},e=new h.z
if(t.typevalues=o.t.decode(this.viewCond),e.FillData(t),e.ParseGameCondition(),this.viewConditionList=new r.Z,
null!=e&&null!=e.typevalues&&0!=e.typevalues.Count())for(let t=0;t<=e.typevalues.Count()-1;t++)this.viewConditionList.Add(e.typevalues[t].condition)}return this.viewConditionList}
Remain_Num(){if(-1!=this.limit){let t=this.limit-_.P.ins.GetBuyTimesByMallId(this.mallId)
return t<0&&(t=0),t}return-1}BuyConditions_Get(){if(l.M.IsNullOrEmpty(this.buyCond)||"null"==this.buyCond)return this.buyConditionList=new r.Z,this.buyConditionList
if(null==this.buyConditionList){const t={},e=new h.z
if(t.typevalues=o.t.decode(this.buyCond),e.FillData(t),e.ParseGameCondition(),this.buyConditionList=new r.Z,
null!=e&&null!=e.typevalues&&0!=e.typevalues.Count())for(let t=0;t<=e.typevalues.Count()-1;t++)e.typevalues[t].condition.intType==d.u.VIPLevelGT_Val&&(this.vipLevel=e.typevalues[t].condition.vipLv),
this.buyConditionList.Add(e.typevalues[t].condition)}return this.buyConditionList}GetVipLimit(){return null==this.buyConditionList&&this.BuyConditions_Get(),
this.vipLevel?this.vipLevel:0}CheckView(){for(let t=0;t<=this.ViewConditions_Get().Count()-1;t++)if(!this.ViewConditions_Get()[t].CheckCondition())return!1
return!0}CheckBuy(){for(let t=0;t<=this.BuyConditions_Get().Count()-1;t++)if(!this.BuyConditions_Get()[t].CheckCondition())return!1
return!0}})||s},60567:(t,e,i)=>{i.d(e,{P:()=>h})
var s=i(38836),n=i(16812),a=i(85602),o=i(38962),l=i(75582),r=i(95523)
class h extends n.k{constructor(){super(),this.huodong_shop_dict=null,this.huodong_shopBuyInfo_dict=null,this.show_buy_huodongId=0,this.show_buy_cnt=0,this.show_buy_type=0,
this.show_content_params=null,this.ignore_dict=null,this.reward=null,this.emptySortList=null,this.huodong_shop_dict=new o.X,this.huodong_shopBuyInfo_dict=new o.X,
this.ignore_dict=new o.X,this.emptySortList=new a.Z}static get ins(){return null==h._ins&&(h._ins=new h),h._ins}ResetModel(){this.huodong_shop_dict.Clear(),
this.huodong_shopBuyInfo_dict.Clear(),this.ignore_dict.Clear()}GetBuyTimesByMallId(t){
return null==this.huodong_shopBuyInfo_dict.LuaDic_GetItem(t)?0:this.huodong_shopBuyInfo_dict.LuaDic_GetItem(t)}GetMallDictByHuoDongId(t){return this.huodong_shop_dict[t]}
GetMallListByHuoDongId(t){const e=new a.Z,i=this.huodong_shop_dict[t]
if(null!=i){for(const[t,n]of(0,s.V5)(i))e.Add(n)
e.Sort(this.CreateDelegate(this.SortVo))}return e}SortVo(t,e){return l.Z.ins.GetVoByMallId(t.mallId).order-l.Z.ins.GetVoByMallId(e.mallId).order}GetMallListByHuoDongIdSort2(t,e){
this.emptySortList=e
const i=new a.Z,n=this.huodong_shop_dict[t]
if(null!=n){for(const[t,e]of(0,s.V5)(n))i.Add(e)
i.Sort(this.CreateDelegate(this.SortVo2))}if(null==e){e=new a.Z
for(let t=0;t<=i.count-1;t++)0==i[t].Remain_Num()&&e.Add(i[t].mallId)}return[i,e]}SortVo2(t,e){if(null!=this.emptySortList){
const i=this.emptySortList.IndexOf(t.mallId),s=this.emptySortList.IndexOf(e.mallId)
return i>=0&&s<0?1:i>=-1&&s<1?-1:i-s}const i=t.Remain_Num(),s=e.Remain_Num()
return 0!=i&&0==s?-1:0==i&&0!=s?1:l.Z.ins.GetVoByMallId(t.mallId).order-l.Z.ins.GetVoByMallId(e.mallId).order}GetVoByHuodongIdAndType(t,e){const i=this.huodong_shop_dict[t]
if(!i)return null
for(const[t,n]of(0,s.V5)(i))if(n.type==e){const t=new r.y
return t.Wrap(n),t}return null}}h._ins=null},82025:(t,e,i)=>{i.d(e,{f:()=>s})
class s{}s.NORMAL_TYPE=1,s.HIGH_TYPE=2,s.RECHARGE_TYPE=3,s.TICKET_TYPE=4},62605:(t,e,i)=>{i.d(e,{Z:()=>A})
var s,n=i(6847),a=i(83908),o=i(46282),l=i(97461),r=i(62370),h=i(61911),d=i(31222),u=i(5494),c=i(63076),_=i(67885),I=i(92679),g=i(12842),m=i(11740),C=i(85605),S=i(75582),p=i(60567)
let A=(0,n.s_)(u.I.HuoDongMallBuyPanel,o.Z.ui_huodongmall_buy_panel).waitPrefab(_.S.modulePathList).register()(s=class extends((0,a.pA)(h.f)()){constructor(...t){super(...t),
this.huodongMallVo=null}InitView(){super.InitView()}OnAddToScene(){this.huodongMallVo=p.P.ins.GetVoByHuodongIdAndType(p.P.ins.show_buy_huodongId,p.P.ins.show_buy_type),
this.AddLis(),this.UpdatePanel()}AddLis(){this.m_handlerMgr.AddClickEvent(this.btn_buy.node,this.CreateDelegate(this.OnClickBtnBuy)),
this.m_handlerMgr.AddClickEvent(this.btn_close.node,this.CreateDelegate(this.OnClickBtnClose)),
this.m_handlerMgr.AddEventMgr(I.g.ACCESS_ICON_CLICK,this.CreateDelegate(this.OnClickBtnClose)),this.m_handlerMgr.AddClickEvent(this.tog.node,this.CreateDelegate(this.OnClickTog))}
RemoveLis(){}Clear(){super.Clear(),this.RemoveLis(),this.huodongMallVo=null,p.P.ins.show_buy_cnt=0,p.P.ins.show_buy_huodongId=0,p.P.ins.show_buy_type=0,
p.P.ins.show_content_params=null}Destroy(){super.Destroy()}UpdatePanel(){const t=c.M.wrapReward(this.huodongMallVo.reward.rewards[0])
t.iconExtraData.leftup_sign="rycommon_sp_0229",t.count=p.P.ins.show_buy_cnt*t.count,this.ui_baseitem_buy.RegisterCustomComponentConfig(_.S.LEFTUP_SIGN_COMP),
this.ui_baseitem_buy.SetData(t)
const e=c.M.wrapReward(this.huodongMallVo.giveReward.rewards[0])
e.iconExtraData.leftup_sign="rycommon_sp_0228",e.count=p.P.ins.show_buy_cnt*e.count,this.ui_baseitem_give.RegisterCustomComponentConfig(_.S.LEFTUP_SIGN_COMP),
this.ui_baseitem_give.SetData(e)
const i=this.huodongMallVo.Consume_Get().GetItemDataByType().count*p.P.ins.show_buy_cnt,s=p.P.ins.show_content_params
null==s?this.text_desc.textSet(r.o.Format(S.Z.ins.GetVoByMallId(this.huodongMallVo.mallId).tips,i,p.P.ins.show_buy_cnt)):this.text_desc.textSet(r.o.Format(S.Z.ins.GetVoByMallId(this.huodongMallVo.mallId).tips,s[0],s[1],s[2],s[3],s[4])),
this.UpdateTog()}OnClickTog(){this.tog.SetValue(!this.tog.GetValue())
let t=`${this.huodongMallVo.mallId}_simple`
p.P.ins.show_buy_cnt>1&&(t=`${this.huodongMallVo.mallId}_multi`),p.P.ins.ignore_dict.LuaDic_AddOrSetItem(t,this.tog.GetValue())}UpdateTog(){
if(this.huodongMallVo.activityId==g.t.SPRINGFESTIVAL_SHOP){const[t,e]=m.K.Inst_get().GetCelebrateDiscount()
if(e!=t)return void this.tog.SetActive(!1)
this.tog.SetActive(!0),10==t?this.tog_text.textSet("本次在线不再提示"):this.tog_text.textSet("折扣变化前不弹窗")}let t=`${this.huodongMallVo.mallId}_simple`
p.P.ins.show_buy_cnt>1&&(t=`${this.huodongMallVo.mallId}_multi`),this.tog.SetValue(p.P.ins.ignore_dict.LuaDic_GetItem(t))}OnClickBtnBuy(){
C.$.ins.CheckConsumeEnough(this.huodongMallVo.Consume_Get(),p.P.ins.show_buy_cnt)&&(C.$.ins.CM_ActivityMallBuy(this.huodongMallVo.mallId,p.P.ins.show_buy_cnt),
l.i.Inst.RaiseEvent(I.g.HUODONG_MALL_BUY_PANEL_SURE,p.P.ins.show_buy_huodongId))
let t=`${this.huodongMallVo.mallId}_simple`
if(p.P.ins.show_buy_cnt>1&&(t=`${this.huodongMallVo.mallId}_multi`),p.P.ins.ignore_dict.LuaDic_AddOrSetItem(t,this.tog.GetValue()),
this.huodongMallVo.activityId==g.t.SPRINGFESTIVAL_SHOP){const[e,i]=m.K.Inst_get().GetCelebrateDiscount()
i!=e&&p.P.ins.ignore_dict.LuaDic_AddOrSetItem(t,!1)}d.N.inst.CloseById(u.I.HuoDongMallBuyPanel)}OnClickBtnClose(){
l.i.Inst.RaiseEvent(I.g.HUODONG_MALL_BUY_PANEL_CLOSE,p.P.ins.show_buy_huodongId),d.N.inst.CloseById(u.I.HuoDongMallBuyPanel)}})||s},92962:(t,e,i)=>{i.d(e,{k:()=>S})
var s,n=i(6847),a=i(83908),o=i(46282),l=i(97461),r=i(41664),h=i(61911),d=i(31222),u=i(5494),c=i(85602),_=i(63076),I=i(75696),g=i(67885),m=i(92679),C=i(60567)
let S=(0,n.s_)(u.I.HuoDongMallSuccessPanel,o.Z.ui_huodongmall_success_panel).waitPrefab(g.S.modulePathList).register()(s=class extends((0,a.pA)(h.f)()){InitView(){super.InitView(),
this.grid_item.SetInitInfo("ui_baseitem",null,I.j)}OnAddToScene(){null!=C.P.ins.reward&&(this.effect_panel.SetActive(!1),this.effect_panel.SetActive(!0),this.AddLis(),
this.UpdatePanel(),r.j.Inst.PlayByDivision("Pandora"))}AddLis(){this.m_handlerMgr.AddClickEvent(this.btn_call,this.CreateDelegate(this.OnClickBtnCall))}RemoveLis(){}Clear(){
super.Clear(),this.RemoveLis(),C.P.ins.reward=null}Destroy(){super.Destroy()}UpdatePanel(){const t=new c.Z
for(let e=0;e<=C.P.ins.reward.rewards.Count()-1;e++)t.Add(_.M.wrapReward(C.P.ins.reward.rewards[e]))
this.grid_item.data_set(t)}OnClickBtnCall(){d.N.inst.CloseById(u.I.HuoDongMallSuccessPanel),l.i.Inst.RaiseEvent(m.g.HUODONG_MALL_SUCCESS_PANEL_CLOSE)}})||s},99421:(t,e,i)=>{i.d(e,{
l:()=>P})
var s,n,a,o,l,r,h,d,u=i(71409),c=i(38836),_=i(97461),I=i(38935),g=i(28192),m=i(85602),C=i(38962),S=i(92679),p=i(55025),A=i(18797),f=i(8010),y=i(17259),T=i(26770),R=i(35517),v=i(23539),w=i(35868),D=i(92415),E=i(66788),L=i(42292),G=i(94009),O=i(12842),b=i(69622),B=i(93727)
function N(t,e,i,s,n){var a={}
return Object.keys(s).forEach((function(t){a[t]=s[t]})),a.enumerable=!!a.enumerable,a.configurable=!!a.configurable,("value"in a||a.initializer)&&(a.writable=!0),
a=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),a),n&&void 0!==a.initializer&&(a.value=a.initializer?a.initializer.call(n):void 0,a.initializer=void 0),
void 0===a.initializer&&(Object.defineProperty(t,e,a),a=null),a}let P=(s=(0,u.GH)(D.k.SM_GetActivityRank),n=(0,u.GH)(D.k.SM_UpdateActivityTask),a=(0,u.GH)(D.k.SM_ActivityDate),
o=(0,u.GH)(D.k.SM_CommonActivityLottery),l=(0,u.GH)(D.k.SM_CommonActivityLotteryConfig),r=(0,u.GH)(D.k.SM_CommonActivityLotteryInfo),d=class t{static get ins(){
return this._ins||(this._ins=new t),this._ins}constructor(){this.m_handlerMgr=null,this.updateType=null,this.InitHandlerMgr(),this.AddLis(),this.RegisterMsg()}InitHandlerMgr(){
return null==this.m_handlerMgr&&(this.m_handlerMgr=g.h.Get()),this.m_handlerMgr}AddLis(){}RegisterMsg(){this.updateType=new m.Z}SM_GetActivityRankHandler(t){
0!=t.activityId&&(null==B.i.ins.rankInfoDic[t.activityId]&&(B.i.ins.rankInfoDic[t.activityId]=new C.X),B.i.ins.rankInfoDic[t.activityId][t.rankType]=t,
_.i.Inst.RaiseEvent(S.g.HUODONG_RANKINFO_UPDATE,t))}SM_UpdateActivityTaskHandler(t){this.updateType.Clear()
const e=B.i.ins.huodong_quest_dict
for(const[i,s]of(0,c.V5)(t.activityTaskVoMap)){let t=null
e.LuaDic_ContainsKey(i)&&(t=e[i].activityRewardVo.isReward),e.LuaDic_AddOrSetItem(i,s)
const n=b.J.ins.GetQuestVoById(s.taskId)
n?(t!=s.activityRewardVo.isReward&&null!=t&&!t&&s.activityRewardVo.isReward&&_.i.Inst.RaiseEvent(S.g.HUODONG_GET_REWARD,s),
this.updateType.Contains(n.targetType)||this.updateType.Add(n.targetType)):E.Y.LogError("ACTIVITYQUESTRESOURCE 找不到配置 taskId="+s.taskId)}
_.i.Inst.RaiseEvent(S.g.HUODONG_QUEST_CHANGE,t),this.updateType.count>0&&_.i.Inst.RaiseEvent(S.g.HUODONG_TYPE_CHANGE,this.updateType)}SM_ActivityDateHandler(t){for(const[e,i]of(0,
c.V5)(t.activityDateMap))this.UpdateActivityId(e),B.i.ins.huodong_dict.LuaDic_AddOrSetItem(e,i),_.i.Inst.RaiseEvent(S.g.HUODONG_INFO_CHANGE,i.activityId)}UpdateActivityId(t){
const e=b.J.ins.GetHuoDongVo(t)
null!=e&&(e.group==G.$.SPRINGFESTIVAL_CELEBRATE?O.t.SPRINGFESTIVAL_CELEBRATE=t:e.group==G.$.SPRINGFESTIVAL_SHOP&&(O.t.SPRINGFESTIVAL_SHOP=t))}SM_CommonActivityLotteryHandle(t){
B.i.ins.SetLotteryEndInfo(t),_.i.Inst.RaiseEvent(S.g.OPEN_LOTTERY_SUCCESS,t)}SM_CommonActivityLotteryConfigHandle(t){this.UpdateActivityId(t.activityId),
B.i.ins.SetLotteryConfig(t),_.i.Inst.RaiseEvent(S.g.UPDATE_LOTTERY_CONFIG,t)}SM_CommonActivityLotteryInfoHandle(t){this.UpdateActivityId(t.activityId),B.i.ins.SetLotteryInfo(t),
_.i.Inst.RaiseEvent(S.g.UPDATE_LOTTERY_INFO,t)}CM_GainActivitytaskReward(t,e){const i=new T.M
i.activityId=t,i.taskId=e,I.C.Inst.F_SendMsg(i)}CM_GainRankDayReward(t){const e=new R.p
e.activityId=t,I.C.Inst.F_SendMsg(e)}CM_OpenActivityPanel(t){const e=new w.V
e.activityId=t,I.C.Inst.F_SendMsg(e,null,t)}CM_AcceptRidingBuyReward(t){const e=new p.d
e.id=t,I.C.Inst.F_SendMsg(e)}CM_GetActivityRank(t,e,i){const s=new v.Q
s.activityId=t,s.startIndex=e,s.endIndex=i,I.C.Inst.F_SendMsg(s)}CM_GainAcitivityRankReward(t,e){const i=new y.l
i.activityId=t,i.rankType=e,I.C.Inst.F_SendMsg(i)}CM_ActivityGetTime(t){const e=new A.p
e.activityList=t,I.C.Inst.F_SendMsg(e)}CM_CommonActivityLottery(t,e){const i=new f.X
i.activityId=t,i.multiple=e,I.C.Inst.F_SendMsg(i)}},d._ins=null,N(h=d,"ins",[L.n],Object.getOwnPropertyDescriptor(h,"ins"),h),
N(h.prototype,"SM_GetActivityRankHandler",[s],Object.getOwnPropertyDescriptor(h.prototype,"SM_GetActivityRankHandler"),h.prototype),
N(h.prototype,"SM_UpdateActivityTaskHandler",[n],Object.getOwnPropertyDescriptor(h.prototype,"SM_UpdateActivityTaskHandler"),h.prototype),
N(h.prototype,"SM_ActivityDateHandler",[a],Object.getOwnPropertyDescriptor(h.prototype,"SM_ActivityDateHandler"),h.prototype),
N(h.prototype,"SM_CommonActivityLotteryHandle",[o],Object.getOwnPropertyDescriptor(h.prototype,"SM_CommonActivityLotteryHandle"),h.prototype),
N(h.prototype,"SM_CommonActivityLotteryConfigHandle",[l],Object.getOwnPropertyDescriptor(h.prototype,"SM_CommonActivityLotteryConfigHandle"),h.prototype),
N(h.prototype,"SM_CommonActivityLotteryInfoHandle",[r],Object.getOwnPropertyDescriptor(h.prototype,"SM_CommonActivityLotteryInfoHandle"),h.prototype),h)},69622:(t,e,i)=>{i.d(e,{
J:()=>_})
var s,n,a=i(42292),o=i(93984),l=i(32076),r=i(38836),h=i(55360),d=i(85602),u=i(38962),c=i(46899)
let _=(n=class t{static get ins(){return this._ins||(this._ins=new t),this._ins}constructor(){this.map_huodong=null,this.map_quest=null,this.map_rank=null,this.lotteryMap=null,
this.target_type_dict=null,this.all_target_types=null
const t=h.Y.Inst.GetOrCreateCsv(o.h.eActivityResource)
this.map_huodong=t.GetCsvMap()
const e=h.Y.Inst.GetOrCreateCsv(o.h.eActivityQuestResource)
this.map_quest=e.GetCsvMap()
const i=h.Y.Inst.GetOrCreateCsv(o.h.eActivityRankResource)
this.map_rank=i.GetCsvMap()
const s=h.Y.Inst.GetOrCreateCsv(o.h.eCommonactivitylotteryResource)
this.lotteryMap=s.GetCsvMap(),this.target_type_dict=new u.X,this.all_target_types=new d.Z,this.InitTargetTypes()}GetHuoDongVo(t){return this.map_huodong[t]}
GetHuoDongVosByFuncType(t){const e=new d.Z
for(const[i,s]of(0,r.V5)(this.map_huodong))s.functionId==t&&e.Add(s)
return e.Sort(((t,e)=>t.id-e.id)),e}GetAccessDataLisById(t){const e=this.GetHuoDongVo(t),i=new d.Z(e.access)
return c.m.FillDataList(i)}GetQuestListVoByIdAndTargetType(t,e){const i=new d.Z
for(const[s,n]of(0,r.V5)(this.map_quest))n.activityId==t&&n.targetType==e&&i.Add(n)
return i.Sort((0,l.v)(this.SortBySortId,this)),i}SortBySortId(t,e){return t.sort-e.sort}GetQuestVoById(t){return this.map_quest[t]}GetQuestVoListById(t){const e=new d.Z
for(const[i,s]of(0,r.V5)(this.map_quest))s.activityId==t&&e.Add(s)
return e.Sort((0,l.v)(this.SortBySortId,this)),e}GetTargetTypesByHuoDongId(t,e){const i=this.target_type_dict.LuaDic_GetItem(t)
if(null==i)return
if(null==e)return i
const s=new d.Z
for(let t=0;t<=i.Count()-1;t++)i[t]!=e&&s.Add(i[t])
return s}InitTargetTypes(){const t=new d.Z
for(const[e,i]of(0,r.V5)(this.map_quest))t.Add(i)
t.Sort(((t,e)=>t.sort-e.sort))
for(let e=0;e<=t.Count()-1;e++){const i=t[e]
let s=this.target_type_dict.LuaDic_GetItem(i.activityId)
null==s&&(s=new d.Z),-1==s.IndexOf(i.targetType)&&s.Add(i.targetType),-1==this.all_target_types.IndexOf(i.targetType)&&this.all_target_types.Add(i.targetType),
this.target_type_dict.LuaDic_AddOrSetItem(i.activityId,s)}
for(const[t,e]of(0,r.V5)(this.target_type_dict))e.Sort(((e,i)=>this.GetQuestListVoByIdAndTargetType(t,e)[0].sort-this.GetQuestListVoByIdAndTargetType(t,i)[0].sort))}
GetLotteryResById(t){return this.lotteryMap[t]}},n._ins=null,I=s=n,g="ins",m=[a.n],C=Object.getOwnPropertyDescriptor(s,"ins"),S=s,p={},Object.keys(C).forEach((function(t){p[t]=C[t]
})),p.enumerable=!!p.enumerable,p.configurable=!!p.configurable,("value"in p||p.initializer)&&(p.writable=!0),p=m.slice().reverse().reduce((function(t,e){return e(I,g,t)||t}),p),
S&&void 0!==p.initializer&&(p.value=p.initializer?p.initializer.call(S):void 0,p.initializer=void 0),void 0===p.initializer&&(Object.defineProperty(I,g,p),p=null),s)
var I,g,m,C,S,p},93727:(t,e,i)=>{i.d(e,{i:()=>C})
var s=i(32076),n=i(38836),a=i(90419),o=i(50089),l=i(68662),r=i(98885),h=i(85602),d=i(38962),u=i(57035),c=i(8211),_=i(28359),I=i(56834),g=i(23649),m=i(69622)
class C{static get ins(){return this._ins||(this._ins=new C),this._ins}constructor(){this.huodong_quest_dict=null,this.huodong_dict=null,this.rankInfoDic=null,
this.ridingbuy_dict=null,this.lotteryInfoDic=null,this.lotteryEndInfoDic=null,this.lotteryLisDic=null,this.lotteryDic=null,this.lotteryTimeControlDic=null,
this.huodong_quest_dict=new d.X,this.huodong_dict=new d.X,this.rankInfoDic=new d.X,this.ridingbuy_dict=new d.X,this.lotteryInfoDic=new d.X,this.lotteryEndInfoDic=new d.X,
this.lotteryLisDic=new d.X,this.lotteryDic=new d.X,this.lotteryTimeControlDic=new d.X}ResetModel(){this.huodong_quest_dict.Clear(),this.huodong_dict.Clear(),
this.ridingbuy_dict.Clear(),this.rankInfoDic.Clear()}GetConsume(t){if(!r.M.IsNullOrEmpty(t)){const e=a.d.parseJsonObjectWithFix(t,"rewardValues"),i=o.t.decode(e,_.h)
return i.Parse(),i.GetItemList()}}GetQuestListVoByIdAndTargetType(t,e){const i=new h.Z
for(const[s,a]of(0,n.V5)(this.huodong_quest_dict)){const s=m.J.ins.GetQuestVoById(a.taskId)
if(g.h.MALL_BUY==e){const n=r.M.String2Int(s.TargetDefs_Get().tCTargetDefs[0].param.mallId)
null!=c.N.GetInst().GetInfo(n)&&s.activityId==t&&s.targetType==e&&i.Add(a)}else s.activityId==t&&s.targetType==e&&i.Add(a)}return i.Sort((0,s.v)(this.SortBySortId,this)),i}
GetQuestListVoByTargetType(t){const e=new h.Z
for(const[i,s]of(0,n.V5)(this.huodong_quest_dict)){const i=m.J.ins.GetQuestVoById(s.taskId)
this.IsActiveState(i.activityId)&&i.targetType==t&&e.Add(s)}return e.Sort((0,s.v)(this.SortBySortId,this)),e}GetQuestListVoByTargetTypeAndGroup(t,e){const i=new h.Z
for(const[s,a]of(0,n.V5)(this.huodong_quest_dict)){const s=m.J.ins.GetQuestVoById(a.taskId)
if(this.IsActiveState(s.activityId)&&s.targetType==t){const t=m.J.ins.GetHuoDongVo(s.activityId)
null!=t&&t.group==e&&i.Add(a)}}return i.Sort((0,s.v)(this.SortBySortId,this)),i}SortBySortId(t,e){return m.J.ins.GetQuestVoById(t.taskId).sort-m.J.ins.GetQuestVoById(e.taskId).sort
}GetState(t){const e=this.huodong_dict.LuaDic_GetItem(t)
return null==e||l.D.serverMSTime_get()<e.startTime.ToNum()?I.V.NONE:l.D.serverMSTime_get()<e.endTime.ToNum()?I.V.OPEN:l.D.serverMSTime_get()<e.delayTime.ToNum()?I.V.END:I.V.CLOSE}
IsActiveState(t){return this.GetState(t)==I.V.OPEN||this.GetState(t)==I.V.END}GetActiveShowHuoDongIdByFunc(t){const e=new h.Z,i=m.J.ins.GetHuoDongVosByFuncType(t)
for(let t=0;t<=i.Count()-1;t++)1==i[t].client_show&&this.IsActiveState(i[t].group)&&e.Add(i[t].id)
return e}GetOpenHuoDongIdByGroupId(t){
for(const[e,i]of(0,n.V5)(this.huodong_dict))if(this.IsActiveState(i.activityId)&&m.J.ins.GetHuoDongVo(i.activityId).group==t)return i.activityId
return 0}GetHuoDongInfoByGroupId(t){for(const[e,i]of(0,n.V5)(this.huodong_dict))if(this.IsActiveState(i.activityId)&&m.J.ins.GetHuoDongVo(i.activityId).group==t)return i
return null}GetStateByGroupId(t){const e=this.GetOpenHuoDongIdByGroupId(t)
return this.GetState(e)}GetStartMS(t){let e=0
const i=this.huodong_dict.LuaDic_GetItem(t)
return null!=i&&null!=i.endTime&&i.endTime.ToNum()>0&&(e=i.startTime.ToNum()-l.D.serverMSTime_get()),e}GetLastEndMS(t){let e=0
const i=this.huodong_dict.LuaDic_GetItem(t)
return null!=i&&null!=i.endTime&&i.endTime.ToNum()>0&&(e=i.endTime.ToNum()-l.D.serverMSTime_get()),e}GetEndMS(t){let e=0
const i=this.huodong_dict.LuaDic_GetItem(t)
return null!=i&&null!=i.endTime&&i.endTime.ToNum()>0&&(e=i.endTime.ToNum()),e}GetQuestVo(t){return this.huodong_quest_dict.LuaDic_GetItem(t)}GetTargetVo(t){
return null==this.GetQuestVo(t)?null:this.GetQuestVo(t).targetVos[0]}GetRewardtVo(t){return null==this.GetQuestVo(t)?null:this.GetQuestVo(t).activityRewardVo}SortTask(t,e){
let i=m.J.ins.GetQuestVoById(t.taskId).sort,s=m.J.ins.GetQuestVoById(e.taskId).sort
return t.activityRewardVo.isReward&&(i+=1e11),e.activityRewardVo.isReward&&(s+=1e11),i-s}GetFunctionOpenActId(t){
const e=u.d.Inst_get().getItemById(t),i=r.M.SubStringWithLen(e.activityIds,1,r.M.Length(e.activityIds)-2),s=r.M.Split(i,r.M.s_SPAN_CHAR)
for(let t=0;t<=s.Count()-1;t++){const e=r.M.String2Int(s[t])
if(this.GetState(e)==I.V.END||this.GetState(e)==I.V.OPEN)return e}return 0}SetLotteryConfig(t){this.lotteryLisDic[t.activityId]=t.configs,
this.lotteryTimeControlDic[t.activityId]=t.lotteryTimeControl,null==this.lotteryDic[t.activityId]&&(this.lotteryDic[t.activityId]=new d.X),this.lotteryDic[t.activityId].Clear()
for(let e=0;e<=t.configs.Count()-1;e++){const i=t.configs[e]
this.lotteryDic[t.activityId][i.id]=i}}GetConfigVoByType(t,e){const i=new h.Z
if(this.lotteryLisDic[t]){for(let s=0;s<=this.lotteryLisDic[t].Count()-1;s++){const n=this.lotteryLisDic[t][s]
n.type==e&&i.Add(n)}i.Sort((0,s.v)(this.SortLottery,this))}return i}SortLottery(t,e){return t.id-e.id}SetLotteryInfo(t){this.lotteryInfoDic[t.activityId]=t}SetLotteryEndInfo(t){
this.lotteryEndInfoDic[t.activityId]=t}HasFreeOpenTime(t){const e=this.lotteryInfoDic[t]
return null!=e&&e.restFreeCount>0}}C._ins=null},94009:(t,e,i)=>{i.d(e,{$:()=>s})
class s{}s.STAR_LIMIT=1501,s.CRIME=1908,s.SPRINGFESTIVAL_CELEBRATE=2304,s.SPRINGFESTIVAL_SHOP=2305,s.PUBLICBETA_DAILY=2101},12842:(t,e,i)=>{i.d(e,{t:()=>s})
class s{}s.SEVEN_DAY_RANK=1050,s.SEVEN_DAY_1=1051,s.SEVEN_DAY_2=1052,s.SEVEN_DAY_3=1053,s.SEVEN_DAY_4=1054,s.SEVEN_DAY_5=1055,s.SEVEN_DAY_6=1056,s.SEVEN_DAY_7=1057,
s.SEVEN_DAY_8=1058,s.OPEN_SERVER_GRAB_QUEST=2e3,s.OPEN_SERVER_GRAB_QUEST_ALL=2008,s.OPEN_SERVER_GRAB_RANK_1=2001,s.OPEN_SERVER_GRAB_RANK_2=2002,s.OPEN_SERVER_GRAB_RANK_3=2003,
s.OPEN_SERVER_GRAB_RANK_4=2004,s.OPEN_SERVER_GRAB_RANK_5=2005,s.OPEN_SERVER_GRAB_RANK_6=2006,s.OPEN_SERVER_GRAB_RANK_7=2007,s.TESTREBATE_RECHARGE=2100,s.HONORGIFT=1100,
s.LOTTERY=1200,s.FORTUNE=1300,s.MAYA_TREASURE=1600,s.STAR_LIMIT=1501,s.LEVEL_REWARD=1700,s.THEMECARNIVAL=1800,s.BOSS_KILLER=1801,s.COPY_SWAPER=1802,s.RY_GROUP_ROAD=1803,
s.THEME_DAY_1=1804,s.THEME_DAY_2=1805,s.THEME_DAY_3=1806,s.THEME_DAY_4=1807,s.THEME_DAY_5=1808,s.THEME_DAY_6=1809,s.THEME_DAY_7=1810,s.DRAGON_TREASURE=1900,
s.DRAGON_TREASURE_SHOP=1901,s.ROLANDSAVE_NEST=1905,s.CRIME=1908,s.ROLAND_APPEAR=1902,s.Roland_Defense=1910,s.PUBLICBETA_JIGSAW=2102,s.PUBLICBETA_CHARGE=2103,s.PUBLICBETA_SHOP=2104,
s.PUBLICBETA_DAILY=2101,s.SPRINGFESTIVAL_CELEBRATE=2304,s.SPRINGFESTIVAL_SHOP=2305},56834:(t,e,i)=>{i.d(e,{V:()=>s})
class s{}s.NONE=0,s.OPEN=1,s.END=2,s.CLOSE=3},23649:(t,e,i)=>{i.d(e,{h:()=>s})
class s{}s.KAIFU_LEVEL=1,s.EQUIP_EXCELLENT=2,s.EQUIP_ENHANCE=3,s.CONSUME_CURRENCY=4,s.MALL_BUY=5,s.ACTIVITY_SCORE=6,s.KILL_MONSTER=7,s.ALL_ROLE_LEARN_SKILL_NUM=8,s.XIAOHAO_TILI=9,
s.ALL_ROLE_LEARN_SKILL_NUM=10,s.MULTI_HANG_TIME=11,s.SKILL_LEVEL_UP_TIME=12,s.POWER=13,s.EQUIPMENT_ADD_TIME=14,s.EQUIPMENT_Three_excellenceCnt=15,s.QUICKBATTLE_TIMES=16,
s.World_BOSS=17,s.GOLD_WORLD_BOSS=18,s.BelialPanel=19,s.BLOOD_TOWN=20,s.Arena_TIME=21,s.Arena_RANK=22,s.ALLIANCE_TASK=23,s.ALLIANCE_ASSIST=24,s.SEEK_TREASURE=25,s.PASS_MAP=26,
s.EQUIPMENT_ALLNUM_EXC=27,s.THEME_GOLD_BOSS=29,s.THEME_WORLD_BOSS=30,s.THEME_COPY=31,s.THEME_CS_BOSS=32,s.THEME_CS_COPY=33,s.THEME_SCORE_REWARD=35,s.DRAGON_TREASURE=42,
s.SPRING_WELFARE_VALUE=43,s.PUBLICBETA_DALIY=34},50426:(t,e,i)=>{i.d(e,{Y:()=>o})
var s=i(93984),n=i(55360),a=i(75439)
class o{constructor(){this.map=null,this.keyItemId=null,this.titleId=null,this.silverId=null,this.goldId=null,this.tenTime=null,this.freeTimes=null,this.directBuyId=null
const t=n.Y.Inst.GetOrCreateCsv(s.h.eDragonTreasureResource)
this.map=t.GetCsvMap(),this._InitConfig()}static Inst_get(){return null==o.inst&&(o.inst=new o),o.inst}_InitConfig(){
this.keyItemId=a.D.getInstance().GetIntValue("DRAGONTREASURE:ITEMID"),this.titleId=a.D.getInstance().GetIntValue("DRAGONTREASURE:TITLEID"),
this.silverId=a.D.getInstance().GetIntValue("DRAGONTREASURE:SILVERCOIN"),this.goldId=a.D.getInstance().GetIntValue("DRAGONTREASURE:GOLDCOIN"),
this.tenTime=a.D.getInstance().GetIntValue("DRAGONTREASURE:TENTIMES"),this.freeTimes=a.D.getInstance().GetIntValue("DRAGONTREASURE:FREETIMES"),
this.directBuyId=a.D.getInstance().GetIntValue("DRAGONTREASURE:GIFTBAG")}GetResById(t){return this.map[t]}}o.inst=null},59616:(t,e,i)=>{i.d(e,{N:()=>ue})
var s=i(97461),n=i(90419),a=i(50089),o=i(98497),l=i(38935),r=i(56937),h=i(18202),d=i(31222),u=i(5494),c=i(52726),_=i(98885),I=i(85602),g=i(21554),m=i(70850),C=i(92679),S=i(87923),p=i(37648),A=i(55492),f=i(50236),y=i(21444),T=i(20460),R=i(68173),v=i(85605),w=i(82025),D=i(60567),E=i(60647),L=i(13487),G=i(65550),O=i(28359)
class b{}b.OpenSuccess="OpenSuccess",b.UpdateInfo="UpdateInfo",b.UpdateConfig="UpdateConfig",b.UpdateShopInfo="UpdateShopInfo",b.OpenItemAnimEnd="OpenItemAnimEnd",
b.RefreshTreasureShopRedPoint="RefreshTreasureShopRedPoint"
var B=i(33072),N=i(38836),P=i(16812),M=i(38962),V=i(63076),k=i(57035),x=i(75582),H=i(56834),U=i(93727),F=i(50426)
class Y extends P.k{constructor(){super(),this.defaultView=0,this.treasureLis=null,this.treasureDic=null,this.treasureInfo=null,this.actId=0,this.shopActId=0,
this.isShowTreasureShopRedPoint=!0,this.treasureEndInfo=null,this.treasureLis=new I.Z,this.treasureDic=new M.X}static Inst_get(){return null==Y.inst&&(Y.inst=new Y),Y.inst}
ResetModel(){this.defaultView=0,this.treasureLis=new I.Z,this.treasureDic=new M.X,this.treasureInfo=null,this.actId=0,this.shopActId=0,this.isShowTreasureShopRedPoint=!0}
ClickTreasureShop(){this.isShowTreasureShopRedPoint=!1,this.isShowTreasureShopRedPoint&&this.RaiseEvent(b.RefreshTreasureShopRedPoint)}GetShopActId(){
if(!this.IsActivityOpen1(this.shopActId)){const t=this.GetFunctionOpenActId(A.x.DRAGON_TREASURE_SHOP)
0!=t&&(this.shopActId=t)}return this.shopActId}IsShowTreasureRedPoint(){if(!this.isShowTreasureShopRedPoint)return this.isShowTreasureShopRedPoint
const t=this.GetActId()
let e=!1
if(0!=t){const i=D.P.ins.GetMallDictByHuoDongId(t)
if(null!=i)for(const[t,s]of(0,N.vy)(i))if(s.CheckView()&&s.CheckBuy()&&s.type==w.f.RECHARGE_TYPE){const t=D.P.ins.GetBuyTimesByMallId(s.mallId),i=s.limit
if(i<=0){e=!0
break}if(t<i){e=!0
break}}}return!!e&&this.isShowTreasureShopRedPoint}IsActivityOpen1(t){if(U.i.ins.GetState(t)==H.V.END||U.i.ins.GetState(t)==H.V.OPEN)return!0}GetActId(){
if(!this.IsActivityOpen1(this.actId)){0!=this.GetFunctionOpenActId(A.x.DRAGON_TREASURE_MAIN)&&(this.actId=this.GetFunctionOpenActId(A.x.DRAGON_TREASURE_MAIN))}return this.actId}
GetFunctionOpenActId(t){const e=k.d.Inst_get().getItemById(t),i=_.M.SubStringWithLen(e.activityIds,1,_.M.Length(e.activityIds)-2),s=_.M.Split(i,_.M.s_SPAN_CHAR)
for(let t=0;t<=s.Count()-1;t++){const e=_.M.String2Int(s[t])
if(U.i.ins.GetState(e)==H.V.END||U.i.ins.GetState(e)==H.V.OPEN)return e}return 0}GetDefaultView(){return this.defaultView}GetTreasureCountById(t){let e=0
return null!=this.treasureInfo&&null!=this.treasureInfo.hasTreasureId2Count&&null!=this.treasureInfo.hasTreasureId2Count[t]&&(e=this.treasureInfo.hasTreasureId2Count[t]),e}
GetKeyItemId(){return F.Y.Inst_get().keyItemId}GetTenNum(){return F.Y.Inst_get().tenTime}GetConsumeNum(t){let e=1
return 10==t&&(e=this.GetTenNum()),e}GetGoldItemId(){return F.Y.Inst_get().goldId}GetSilverItemId(){return F.Y.Inst_get().silverId}GetRareShopLis(){
const t=new I.Z,e=D.P.ins.GetMallDictByHuoDongId(this.GetShopActId())
if(null!=e)for(const[i,s]of(0,N.vy)(e)){x.Z.ins.GetVoByMallId(s.mallId).show>0&&t.Add(s)}return t.Sort(this.CreateDelegate(this.SortFunc)),t}SortFunc(t,e){
const i=x.Z.ins.GetVoByMallId(t.mallId),s=x.Z.ins.GetVoByMallId(e.mallId)
return i.show-s.show}GetItemLisByAndReward(t){const e=new I.Z
if(null!=t){const i=t.rewards
for(let t=0;t<=i.count-1;t++){const s=V.M.wrapReward(i[t])
e.Add(s)}}return e}IsJumpAnim(){return 1==E.p.inst.GetClientLogicSetting(L.R.DRAGONTREASURE_JUMP_ANIM)}IsStatisfyKeyNum(){
if(m.g.Inst_get().GetItemNum(this.GetKeyItemId())>=this.GetTenNum())return!0}SetTreasureConfig(t){if(null!=t.configVos){this.treasureLis=t.configVos,this.treasureDic.Clear()
for(let t=0;t<=this.treasureLis.Count()-1;t++){const e=this.treasureLis[t]
this.treasureDic[e.id]=e}}}SetTreasureInfo(t){this.treasureInfo=t}SetTreasureEndInfo(t){this.treasureEndInfo=t}IsLimitDragonGold(){const t=this.GetGoldId()
if(null!=this.treasureInfo){const e=this.GetTreasureCountById(t)
if(0!=this.treasureDic[t].limit&&e>=this.treasureDic[t].limit||0==this.treasureDic[t].limit)return!0}return!1}GetDragonGoldCount(){
const t=this.GetGoldId(),e=this.treasureDic[t].safeTime
return null!=this.treasureInfo?e-this.treasureInfo.count:e}GetGoldId(){if(null!=this.treasureLis)for(let t=0;t<=this.treasureLis.Count()-1;t++){const e=this.treasureLis[t]
if(1==F.Y.Inst_get().GetResById(e.id).order)return e.id}}GetRemainNum(t){let e=0
if(null!=this.treasureLis)for(let i=0;i<=this.treasureLis.Count()-1;i++){const s=this.treasureLis[i]
let n=this.treasureDic[s.id].limit
n-=this.GetTreasureCountById(s.id)
const a=V.M.wrapReward(s.reward.rewards[0])
a.modelId_get()==t&&(e+=n*a.count)}return e}HasFreeOpenTime(){return null!=this.treasureInfo&&this.treasureInfo.restFreeCount>0}GetConfigVoByType(t){const e=new I.Z
for(let i=0;i<=this.treasureLis.Count()-1;i++){const s=this.treasureLis[i],n=F.Y.Inst_get().GetResById(s.id)
n.order>0&&n.type==t&&e.Add(s)}return e.Sort(this.CreateDelegate(this.SortTreasure)),e}SortTreasure(t,e){const i=F.Y.Inst_get().GetResById(t.id),s=F.Y.Inst_get().GetResById(e.id)
return i.order-s.order}IsActivityOpen(){return U.i.ins.GetState(this.GetActId())==H.V.OPEN}IsCanBuy(t){if(null!=t){const e=D.P.ins.GetBuyTimesByMallId(t.mallId),i=t.limit
if(i>0&&e>=i)return!1
const s=ue.Inst_get().GetConsume(t.consumeDefs),n=s[0].modelId_get(),a=s[0].count
if(m.g.Inst_get().GetItemNum(n)>=a)return!0}return!1}}Y.inst=null
var K=i(84193),z=i(99294),Q=i(9986),Z=i(6665),X=i(93877),j=i(72005),J=i(61911),W=i(83540),$=i(52212),q=i(33138),tt=i(9057)
class et extends tt.x{constructor(...t){super(...t),this.data=null,this.icon=null,this.item=null}InitView(){super.InitView(),this.icon=this.CreateComponent(j.w,1)}SetData(t){
this.AddLis(),this.data=t
const e=q.f.Inst().getItemById(t.itemId)
h.g.SetItemIcon(this.icon.FatherId,this.icon.ComponentId,e.icon,W.b.eItem,!1)}AddLis(){}RemoveLis(){}Clear(){this.item.Clear(),this.RemoveLis(),super.Clear()}Destroy(){
this.item.Destroy(),super.Destroy()}}var it=i(75696)
class st extends tt.x{constructor(...t){super(...t),this.data=null,this.item=null,this.buyIcon=null,this.giveIcon=null}InitView(){super.InitView(),
this.item=this.CreateComponentBinder(it.j,1),this.buyIcon=this.CreateComponent(z.z,2),this.giveIcon=this.CreateComponent(z.z,3)}SetData(t){this.AddLis(),this.data=t,
this.item.SetData(t.itemData),this.buyIcon.SetActive(t.isShowBuyIcon),this.giveIcon.SetActive(t.isShowGiveIcon)}AddLis(){}RemoveLis(){}Clear(){this.item.Clear(),this.RemoveLis(),
super.Clear()}Destroy(){this.item.Destroy(),super.Destroy()}}class nt extends J.f{constructor(){super(),this.iconIdList=null,this.closeBtn=null,this.confirmBtn=null,
this.cancelBtn=null,this.topLabel=null,this.bottomLabel=null,this.grid=null,this.titleTxt=null,this.centerWidget=null,this.icon3=null,this.vo=null,this.vec2=null,
this.iconIdList=new I.Z}InitView(){super.InitView(),this.closeBtn=this.CreateComponent(Q.W,1),this.confirmBtn=this.CreateComponent(Q.W,2),
this.cancelBtn=this.CreateComponent(Q.W,3),this.topLabel=this.CreateComponent(K.n,4),this.bottomLabel=this.CreateComponent(K.n,5),this.grid=this.CreateComponent(Z.A,6),
this.titleTxt=this.CreateComponent(X.Q,7),this.centerWidget=this.CreateComponent(z.z,8),this.icon3=this.CreateComponent(j.w,9),this.grid.SetInitInfo("ui_dragon_buyitem",null,st)}
OnAddToScene(){this.iconIdList=new I.Z,this.AddLis(),this.UpdateView()}UpdateView(){this.vo=ue.Inst_get().buyVo,this.grid.data_set(this.vo.itemLis),
this.confirmBtn.SetText(this.vo.confirmText),this.cancelBtn.SetText(this.vo.cancelText),this.topLabel.SetTxt(this.vo.topStr),this.bottomLabel.SetTxt(this.vo.bottomStr)
const t=q.f.Inst().getItemById(Y.Inst_get().GetGoldItemId())
null!=t&&h.g.SetItemIcon(this.icon3.FatherId,this.icon3.ComponentId,t.icon,W.b.eItem,!1)}SetText(t,e){const i=new I.Z
let s=1
for(;s;){let t
if([s,t]=string.find(e,'{[%w:"=]+}',s),null!=s){const n=string.sub(e,s,t)
s=t+1
const o=a.t.decode(n)
"table"==typeof o&&(o.str=n,i.Add(o))}}if(i.Count()>0){for(let s=0;s<=i.Count()-1;s++){e=string.gsub(e,i[s].str,"    ")
const n=t.CalculateSingleLineX(e,22),a=h.g.GetResFindId("ui_drogonbuytip_iconitem"),o=t.CalculateSingleLineX("    ",22)
this.vec2=new $.F(o-n/2+10,t.node.transform.GetLocalPosition().y+22*s+8),this.InitCurrency(a,i[s])}t.SetCommonTxt(e)}else t.SetCommonTxt(e)}InitCurrency(t,e){this.iconIdList.Add(t)
const i=new et
i.setId(t,null,0),i.node.transform.ComponentId=-1,i.node.transform.SetParent(this.centerWidget.FatherId,this.centerWidget.ComponentId),
i.node.transform.SetLocalPositionV2(this.vec2),i.SetData(e)}Clear(){ue.Inst_get().buyVo=null,this.grid.Clear(),super.Clear(),this.RemoveLis()}Destroy(){for(const[t,e]of(0,
N.V5)(this.iconIdList))h.g.DestroyUIById(e)
this.grid.Destroy(),super.Destroy()}AddLis(){this.AddClickEvent(this.confirmBtn,this.CreateDelegate(this.ConfirmBtnHandle)),
this.AddClickEvent(this.cancelBtn,this.CreateDelegate(this.CancelBtnHandle)),this.AddClickEvent(this.closeBtn,this.CreateDelegate(this.CloseBtnHandle))}RemoveLis(){
this.RemoveClickEvent(this.confirmBtn,this.CreateDelegate(this.ConfirmBtnHandle)),this.RemoveClickEvent(this.cancelBtn,this.CreateDelegate(this.CancelBtnHandle)),
this.RemoveClickEvent(this.closeBtn,this.CreateDelegate(this.CloseBtnHandle))}ConfirmBtnHandle(){null!=this.vo.confirmHandle&&this.vo.confirmHandle(),this.CloseBtnHandle()}
CancelBtnHandle(){null!=this.vo.cancelHandle&&this.vo.cancelHandle(),this.CloseBtnHandle()}CloseBtnHandle(){ue.Inst_get().CloseBuyTipView()}}
var at=i(3522),ot=i(13113),lt=i(36334),rt=i(15518),ht=i(60130),dt=i(28287),ut=i(62734),ct=i(68662),_t=i(5924),It=i(9776),gt=i(32208),mt=i(51868),Ct=i(61613),St=i(79534),pt=i(53905),At=i(65772),ft=i(29479),yt=i(14792),Tt=i(23649),Rt=i(57834),vt=i(70093)
class wt extends tt.x{constructor(...t){super(...t),this.numTxt=null,this.icon=null,this.iconBtn=null,this.data=null}InitView(){super.InitView(),
this.numTxt=this.CreateComponent(X.Q,1),this.icon=this.CreateComponent(j.w,2),this.iconBtn=this.CreateComponent(Q.W,3)}SetData(t){this.data=t,this.AddLis(),this.RefreshInfo()}
RefreshInfo(){const t=q.f.Inst().getItemById(this.data.itemId)
h.g.SetItemIcon(this.icon.FatherId,this.icon.ComponentId,t.icon,W.b.eItem,!1)
const e=m.g.Inst_get().GetItemNum(this.data.itemId)
this.numTxt.textSet(`×${e}`)}AddLis(){s.i.Inst.AddEventHandler(C.g.BAG_UPDATE,this.CreateDelegate(this.RefreshInfo)),
Rt.i.Get(this.icon.node).RegistonClick(this.CreateDelegate(this.IconHandle))}RemoveLis(){Rt.i.Get(this.icon.node).RemoveonClick(this.CreateDelegate(this.IconHandle)),
s.i.Inst.RemoveEventHandler(C.g.BAG_UPDATE,this.CreateDelegate(this.RefreshInfo))}IconHandle(){const t=new V.M(this.data.itemId)
t.btnType=vt.p.GetWay,g.J.Inst_get().OpenTipView(t)}Clear(){this.data=null,this.RemoveLis()}Destroy(){}}var Dt=i(30267),Et=i(18152),Lt=i(86209)
class Gt extends tt.x{constructor(...t){super(...t),this.huodongMallVo=null,this.huodongMallCfgVo=null,this.nameLabel=null,this.costLabel=null,this.costIcon=null,
this.costContainer=null,this.baseItem=null}InitView(){super.InitView(),this.nameLabel=this.CreateComponent(X.Q,1),this.costLabel=this.CreateComponent(X.Q,2),
this.costIcon=this.CreateComponent(j.w,3),this.costContainer=this.CreateComponent(Dt.V,4),this.baseItem=this.CreateComponentBinder(it.j,5)}SetData(t){this.huodongMallVo=t,
this.huodongMallCfgVo=x.Z.ins.GetVoByMallId(this.huodongMallVo.mallId),this.AddLis(),this.Update()}AddLis(){
this.m_handlerMgr.AddEventMgr(C.g.HUODONG_MALL_BUY_CNT_CHANGE,this.CreateDelegate(this.OnBuyCntChange))}RemoveLis(){}Clear(){super.Clear(),this.RemoveLis()}Destroy(){
super.Destroy()}Update(){this.nameLabel.textSet(this.huodongMallCfgVo.name)
for(let t=0;t<=this.huodongMallVo.reward.rewards.Count()-1;t++){const e=V.M.wrapReward(this.huodongMallVo.reward.rewards[t])
e.iconType=Et.s.BASE_ICON_TYPE_64_64,this.baseItem.SetData(e)
break}this.UpdateConsume()}UpdateConsume(){const t=this.huodongMallVo.Consume_Get().GetItemDataByType()
this.costLabel.textSet(Lt.w.Instance.ConvertNumToString(t.count)),h.g.SetItemIcon(this.costIcon.FatherId,this.costIcon.ComponentId,t.cfgData_get().icon,W.b.eItem,!1),
this.costContainer.CallReposition()}OnBuyCntChange(t){t==this.huodongMallVo.mallId&&this.Update()}}var Ot=i(99421)
class bt extends tt.x{constructor(){super(),this.huodongQuestVo=null,this.targetVo=null,this.rewardVo=null,this.qualityNameLis=null,this.timeTxt=null,this.icon=null,
this.canGetGo=null,
this.hasGetGo=null,this.bg=null,this.numTxt=null,this.qualityNameLis=new I.Z(["ryjlbz_sp_0004","ryjlbz_sp_0005","ryjlbz_sp_0006","ryjlbz_sp_0007","ryjlbz_sp_0008","ryjlbz_sp_0009","ryjlbz_sp_0010"])
}InitView(){super.InitView(),this.timeTxt=this.CreateComponent(X.Q,1),this.icon=this.CreateComponent(j.w,2),this.canGetGo=this.CreateComponent(j.w,3),
this.hasGetGo=this.CreateComponent(j.w,4),this.bg=this.CreateComponent(j.w,5),this.numTxt=this.CreateComponent(X.Q,6)}SetData(t){this.AddLis(),this.huodongQuestVo=t,
this.targetVo=this.huodongQuestVo.targetVos[0],this.rewardVo=this.huodongQuestVo.activityRewardVo,this.UpdatePanel()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.OnClick))}RemoveLis(){}Clear(){super.Clear(),this.RemoveLis()}Destroy(){h.g.DestroyUIObj(),super.Destroy()}
UpdatePanel(){this.hasGetGo.SetActive(!1),this.canGetGo.SetActive(!1),this.numTxt.node.SetActive(!1)
const t=V.M.wrapReward(this.rewardVo.reward.rewards[0])
this.rewardVo.isReward?this.hasGetGo.SetActive(!0):this.targetVo.curValue.ToNum()>=this.targetVo.targetValue.ToNum()&&this.canGetGo.SetActive(!0),
this.bg.spriteNameSet(this.qualityNameLis[t.Quality_get()]),t.count>1&&(this.numTxt.node.SetActive(!0),this.numTxt.textSet(t.count)),
h.g.SetItemIcon(this.icon.FatherId,this.icon.ComponentId,t.cfgData_get().icon,W.b.eItem,!1),this.timeTxt.textSet(this.targetVo.targetValue.ToNum())}OnClick(){
if(this.targetVo.curValue.ToNum()>=this.targetVo.targetValue.ToNum()&&!this.rewardVo.isReward)return void Ot.l.ins.CM_GainActivitytaskReward(Y.Inst_get().GetActId(),this.huodongQuestVo.taskId)
const t=V.M.wrapReward(this.rewardVo.reward.rewards[0])
g.J.Inst_get().OpenTipView(t)}}class Bt extends mt.${constructor(...t){super(...t),this.currencyGrid=null,this.shopGrid=null,this.timeTxt=null,this.openTimeTxt=null,
this.timeGrid=null,this.timeScrollView=null,this.bgLine=null,this.lightLine=null,this.bg=null,this.offset=null,this.timeTipBtn=null,this.currencyTipBtn=null,this.goOneBtn=null,
this.goTenBtn=null,this.animTog=null,this.descTxt=null,this.icon1=null,this.icon2=null,this.tenRedPoint=null,this.rewardPoolBtn=null,this.shopBtn=null,this.oneRedPoint=null,
this.shopRedPoint=null,this.icon3=null,this.left=null,this.right=null,this.giftBtn=null,this.time=null,this.treasureShopRedPoint=null,this.countDownTimer=null,this.curPoint=null}
InitView(){super.InitView(),this.currencyGrid=this.CreateComponent(Z.A,1),this.shopGrid=this.CreateComponent(Z.A,2),this.timeTxt=this.CreateComponent(X.Q,3),
this.openTimeTxt=this.CreateComponent(X.Q,4),this.timeGrid=this.CreateComponent(Z.A,5),this.timeScrollView=this.CreateComponent(It.h,6),this.bgLine=this.CreateComponent(j.w,7),
this.lightLine=this.CreateComponent(j.w,8),this.bg=this.CreateComponent(j.w,9),this.offset=this.CreateComponent(z.z,10),this.timeTipBtn=this.CreateComponent(Q.W,11),
this.currencyTipBtn=this.CreateComponent(Q.W,12),this.goOneBtn=this.CreateComponent(Q.W,13),this.goTenBtn=this.CreateComponent(Q.W,14),this.animTog=this.CreateComponent(gt.r,15),
this.descTxt=this.CreateComponent(X.Q,16),this.icon1=this.CreateComponent(j.w,17),this.icon2=this.CreateComponent(j.w,18),this.tenRedPoint=this.CreateComponent(z.z,19),
this.rewardPoolBtn=this.CreateComponent(Q.W,20),this.shopBtn=this.CreateComponent(Q.W,21),this.oneRedPoint=this.CreateComponent(z.z,22),
this.shopRedPoint=this.CreateComponent(z.z,23),this.icon3=this.CreateComponent(j.w,24),this.left=this.CreateComponent(ot.T,25),this.right=this.CreateComponent(ot.T,26),
this.giftBtn=this.CreateComponent(Q.W,27),this.time=this.CreateComponent(z.z,28),this.treasureShopRedPoint=this.CreateComponent(z.z,29),
this.shopGrid.SetInitInfo("ui_dragontreasure_main_shopitem",null,Gt),this.currencyGrid.SetInitInfo("ui_dragontreasure_currencyitem",null,wt),
this.timeGrid.SetInitInfo("ui_dragontreasure_timeitem",null,bt),ht.O.SetAnchorPos(this.left,!0,!1,0),ht.O.SetAnchorPos(this.right,!1,!1,0)}SetData(){
this.currencyGrid.data_set(ue.Inst_get().GetCurrencyLisByViewType(B.L.DragonTreasureMain))
const t=q.f.Inst().getItemById(Y.Inst_get().GetKeyItemId())
null!=t&&(h.g.SetItemIcon(this.icon1.FatherId,this.icon1.ComponentId,t.icon,W.b.eItem,!1),h.g.SetItemIcon(this.icon2.FatherId,this.icon2.ComponentId,t.icon,W.b.eItem,!1)),
this.AddLis(),this.UpdateInfo(),this.UpdateShopRedPointState(),this.UpdateTreasureShopRedPoint()}UpdateView(){}TimeTipBtnHandle(){const t=new pt.w
t.infoId="DRAGONTREASURE:TIPS1",t.width=384,t.position=new St.P(-436,292,0),At.Q.Inst_get().Open(t)}CurrencyTipBtnHandle(){const t=new pt.w
t.infoId="DRAGONTREASURE:TIPS2",t.width=384,t.position=new St.P(-527,41,0)
const e=Y.Inst_get().GetRemainNum(Y.Inst_get().GetGoldItemId())
t.replaceParams.Add(`\n龙魂金币剩余可获得数量：${e}`),At.Q.Inst_get().Open(t)}Clear(){this.RemoveLis(),this.ClearEndTimeHandle(),this.shopGrid.Clear(),this.currencyGrid.Clear(),
this.timeGrid.Clear(),super.Clear()}Destroy(){this.shopGrid.Destroy(),this.currencyGrid.Destroy(),this.timeGrid.Destroy(),super.Destroy()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.timeTipBtn,this.CreateDelegate(this.TimeTipBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.currencyTipBtn,this.CreateDelegate(this.CurrencyTipBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.animTog,this.CreateDelegate(this.AnimToggleHandle)),this.m_handlerMgr.AddClickEvent(this.goOneBtn,this.CreateDelegate(this.GoOneBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.goTenBtn,this.CreateDelegate(this.GoTenBtnHandle)),this.m_handlerMgr.AddClickEvent(this.shopBtn,this.CreateDelegate(this.ShopBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.giftBtn,this.CreateDelegate(this.GiftBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.rewardPoolBtn,this.CreateDelegate(this.RewardPoolBtnHandle)),
Y.Inst_get().AddEventHandler(b.OpenSuccess,this.CreateDelegate(this.OpenSuccessHandle)),Y.Inst_get().AddEventHandler(b.UpdateShopInfo,this.CreateDelegate(this.UpdateRareShopLis)),
Y.Inst_get().AddEventHandler(b.UpdateInfo,this.CreateDelegate(this.UpdateRewardInfo)),
this.m_handlerMgr.AddEventMgr(C.g.HUODONG_QUEST_CHANGE,this.CreateDelegate(this.UpdateOpenTime)),
this.m_handlerMgr.AddEventMgr(C.g.BAG_UPDATE,this.CreateDelegate(this.BagUpdateHandle)),
ut.f.Inst.AddCallback(yt.t.DRAGON_TREASURE_SHOP,this.CreateDelegate(this.UpdateShopRedPointState))}UpdateShopRedPointState(){const t=ut.f.Inst.GetData(yt.t.DRAGON_TREASURE_SHOP)
let e=!1
null!=t&&t.show&&(e=!0),this.shopRedPoint.SetActive(e)}UpdateTreasureShopRedPoint(){this.treasureShopRedPoint.SetActive(Y.Inst_get().IsShowTreasureRedPoint())}BagUpdateHandle(){
this.tenRedPoint.SetActive(Y.Inst_get().IsStatisfyKeyNum())}GetDirectData(){const t=ft.X.Inst_get().directBuyList
for(let e=0;e<=t.Count()-1;e++){const i=t[e]
if(i.id==F.Y.Inst_get().directBuyId&&i.CheckShow())return i}}OpenSuccessHandle(){}RemoveLis(){
Y.Inst_get().RemoveEventHandler(b.OpenSuccess,this.CreateDelegate(this.OpenSuccessHandle)),
Y.Inst_get().RemoveEventHandler(b.UpdateShopInfo,this.CreateDelegate(this.UpdateRareShopLis)),
Y.Inst_get().RemoveEventHandler(b.UpdateInfo,this.CreateDelegate(this.UpdateRewardInfo)),
ut.f.Inst.RemoveCallback(yt.t.DRAGON_TREASURE_SHOP,this.CreateDelegate(this.UpdateShopRedPointState))}GoOneBtnHandle(){ue.Inst_get().GoHandle(1)}GoTenBtnHandle(){
ue.Inst_get().GoHandle(10)}RewardPoolBtnHandle(){ue.Inst_get().OpenRewardPoolView()}ShopBtnHandle(){ue.Inst_get().OpenShopView()}GiftBtnHandle(){
ue.Inst_get().OpenTreasureShopView(),Y.Inst_get().ClickTreasureShop(),this.UpdateTreasureShopRedPoint()}AnimToggleHandle(){ue.Inst_get().SendSetAnim(this.animTog.GetValue())}
UpdateRareShopLis(){const t=Y.Inst_get().GetRareShopLis()
this.shopGrid.data_set(t)}UpdateRewardInfo(){if(this.goOneBtn.node.SetActive(!1),this.goTenBtn.node.SetActive(!1),this.descTxt.node.SetActive(!1),this.animTog.node.SetActive(!1),
this.icon3.node.SetActive(!1),this.giftBtn.node.SetActive(!1),Y.Inst_get().IsActivityOpen()){this.goOneBtn.node.SetActive(!0),this.goTenBtn.node.SetActive(!0),
this.descTxt.node.SetActive(!0),this.animTog.node.SetActive(!0),this.icon3.node.SetActive(!0)
let t=""
const e=q.f.Inst().getItemById(Y.Inst_get().GetGoldItemId())
if(null!=e&&h.g.SetItemIcon(this.icon3.FatherId,this.icon3.ComponentId,e.icon,W.b.eItem,!1),Y.Inst_get().IsLimitDragonGold())t="龙魂金币获取数量已达上限",
this.icon3.node.transform.SetLocalPositionXYZ(-117,-328,0)
else{const e=Y.Inst_get().GetDragonGoldCount()
this.icon3.node.transform.SetLocalPositionXYZ(0,-328,0),t=`再开启 [5FB470] ${e} [-]个宝箱必出       （可在珍宝商店兑换大奖）`}const i=Y.Inst_get().treasureInfo
let s=`开启一次(     ${Y.Inst_get().GetConsumeNum(1)})`
i.restFreeCount>0?(s="免 费",this.icon1.node.SetActive(!1),this.oneRedPoint.SetActive(!0)):(this.oneRedPoint.SetActive(!1),this.icon1.node.SetActive(!0)),this.BagUpdateHandle()
const n=`开启十次(     ${Y.Inst_get().GetConsumeNum(10)})`
this.goOneBtn.SetText(s),this.goTenBtn.SetText(n),this.descTxt.textSet(t),this.animTog.SetValue(Y.Inst_get().IsJumpAnim()),this.giftBtn.node.SetActive(!0)}}UpdateInfo(){
this.ClearEndTimeHandle(),this.countDownTimer=_t.C.Inst_get().SetInterval(this.CreateDelegate(this.RefreshEndTime),1e3,-1),this.RefreshEndTime(),this.UpdateRareShopLis(),
this.UpdateRewardInfo(),this.UpdateOpenTime()}GetFirstSpacing(){return Ct.v.GetAdaptionWidth(74,74)}GetSpacing(){return Ct.v.GetAdaptionWidth(113,113)}GetSpacingByIndex(t){let e=1
return e=1==t?this.GetFirstSpacing():this.GetSpacing()-Bt.ITEM_WIDTH,e}UpdateOpenTime(){this.curPoint=0
const t=U.i.ins.GetQuestListVoByIdAndTargetType(Y.Inst_get().GetActId(),Tt.h.DRAGON_TREASURE)
this.timeGrid.data_set(t),this.RefreshTimePos(t.Count())
let e=!1
for(let i=0;i<=t.Count()-1;i++)this.curPoint<t[i].targetVos[0].curValue.ToNum()&&(this.curPoint=t[i].targetVos[0].curValue.ToNum()),
i==t.Count()-1&&this.curPoint==t[i].targetVos[0].targetValue.ToNum()&&(e=!0)
e?(this.openTimeTxt.textSet("已达标"),this.openTimeTxt.fontSizeSet(20)):this.openTimeTxt.textSet(this.curPoint)
let i=0
for(let e=0;e<=t.Count()-1;e++){const s=this.GetSpacingByIndex(e+1)
if(!(t[e].targetVos[0].curValue.ToNum()>=t[e].targetVos[0].targetValue.ToNum())){let n=0
e>0&&(n=t[e-1].targetVos[0].targetValue.ToNum()),i+=(t[e].targetVos[0].curValue.ToNum()-n)/(t[e].targetVos[0].targetValue.ToNum()-n)*s
break}i=i+s+Bt.ITEM_WIDTH}i+=20
const s=t.Count()*this.GetSpacing()+50
this.bgLine.widthSet(s),this.bg.widthSet(s+60),0==i?this.lightLine.node.SetActive(!1):(this.lightLine.node.SetActive(!0),e?this.lightLine.widthSet(s):this.lightLine.widthSet(i))}
RefreshTimePos(t){if(t>0){let e=0
e=t>=8?8:t,this.time.transform.SetLocalPositionXYZ(56*(8-e)-14,-110,0)}}RefreshEndTime(){const t=U.i.ins.huodong_dict.LuaDic_GetItem(Y.Inst_get().GetActId())
let e=0
null!=t&&(e=t.endTime.ToNum()),e>0&&(e=.001*e-ct.D.serverTime_get()),e>0?this.timeTxt.textSet(`结束倒计时:[5FB470]${S.l.GetDateFormatBitContainZero(e,4)}[-]`):(this.timeTxt.textSet("已结束"),
this.ClearEndTimeHandle())}ClearEndTimeHandle(){null!=this.countDownTimer&&(_t.C.Inst_get().ClearInterval(this.countDownTimer),this.countDownTimer=null)}}Bt.ITEM_WIDTH=13
class Nt extends rt.k{constructor(){super(),this.closeBtn=null,this.titleLabel=null,this.closeBtnAni=null,this.leftWidget=null,this.bg=null,this._model=null,this.redPointLis=null,
this._model=Y.Inst_get()}InitView(){super.InitView(),this.closeBtn=this.CreateComponent(Q.W,1),this.titleLabel=this.CreateComponent(X.Q,2),
this.closeBtnAni=this.CreateComponent(at.k,3),this.leftWidget=this.CreateComponent(ot.T,4),this.bg=this.CreateComponent(j.w,5),
this._subPanelDatas.Add(lt.b.New(new I.Z(["ui_dragontreasure_mainpanel"]),this,Bt))}OnAddToScene(){this.titleLabel.textSet("巨龙宝藏"),this.ShowSubView(0),this.UpdateAnchors(),
this.AddLis()}Clear(){this.RemoveLis(),super.Clear()}Destroy(){super.Destroy()}OnCloseClick(){ue.Inst_get().CloseView()}ShowCurrencyBar_get(){return dt._.ShowGold_Dia_BindDia}
AddLis(){this.m_handlerMgr.AddEventMgr(C.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors)),
this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.PlayCloseAni))}RemoveLis(){}UpdateAnchors(){ht.O.SetAnchorPos(this.leftWidget,!0,!1,0)}PlayCloseAni(t,e,i){
null!=this.closeBtnAni&&(this.closeBtnAni.SetResetOnPlay(!0),this.closeBtnAni.Play(!0,!1)),null==i&&(i=this.CreateDelegate(this.OnCloseClick)),
null!=i&&this.m_handlerMgr.SetInterval(i,100,1)}GetDefaultView(){const t=this._model.GetDefaultView()
if(null==t){if(null!=this.redPointLis&&this.redPointLis.Count()>0)for(let t=0;t<=this.redPointLis.Count()-1;t++){const e=this.redPointLis[t]
if(null!=e){const i=ut.f.Inst.GetData(e)
if(null!=i&&i.show)return t}}return 0}return t}}class Pt{constructor(){this.rewardNameDic=null,this.rewardNameDic=new M.X,this.Init()}static Inst_get(){
return null==Pt.inst&&(Pt.inst=new Pt),Pt.inst}Init(){this.rewardNameDic.LuaDic_AddOrSetItem(Pt.BigRewardType,"大奖"),this.rewardNameDic.LuaDic_AddOrSetItem(Pt.MidRewardType,"中奖"),
this.rewardNameDic.LuaDic_AddOrSetItem(Pt.LowRewardType,"小奖")}GetName(t){return this.rewardNameDic[t]}}Pt.inst=null,Pt.BigRewardType=1,Pt.MidRewardType=2,Pt.LowRewardType=3
class Mt extends tt.x{constructor(...t){super(...t),this.data=null,this.item=null,this.limit=null,this.remainTxt=null,this.config=null}InitView(){super.InitView(),
this.item=this.CreateComponentBinder(it.j,1),this.limit=this.CreateComponent(z.z,2),this.remainTxt=this.CreateComponent(X.Q,3)}SetData(t){this.AddLis(),this.data=t,
this.config=F.Y.Inst_get().GetResById(t.id)
const e=V.M.wrapReward(this.data.reward.rewards[0])
this.item.SetData(e),this.UpdateItem()}AddLis(){Y.Inst_get().AddEventHandler(b.UpdateInfo,this.CreateDelegate(this.UpdateItem))}RemoveLis(){
Y.Inst_get().RemoveEventHandler(b.UpdateInfo,this.CreateDelegate(this.UpdateItem))}Clear(){this.item.Clear(),this.RemoveLis(),super.Clear()}Destroy(){this.item.Destroy(),
super.Destroy()}UpdateItem(){this.remainTxt.node.SetActive(!1),this.limit.SetActive(!1)
const t=Y.Inst_get().GetTreasureCountById(this.data.id)
if(t>=this.data.limit&&this.data.limit>0&&this.limit.SetActive(!0),this.data.limit>0){this.remainTxt.node.SetActive(!0)
const e=this.data.limit-t
let i=e
e<=0&&(i="[FF4B58]0[-]"),this.remainTxt.textSet(`剩${i}个`)}}}class Vt extends tt.x{constructor(...t){super(...t),this.data=null,this.titleTxt=null,this.grid=null,this.widget=null,
this.bg=null}InitView(){super.InitView(),this.titleTxt=this.CreateComponent(X.Q,1),this.grid=this.CreateComponent(Z.A,2),this.widget=this.CreateComponent(ot.T,3),
this.bg=this.CreateComponent(j.w,4),this.grid.SetInitInfo("ui_dragontreasure_rewarditem",null,Mt)}SetData(t){this.AddLis(),this.data=t
const e=Pt.Inst_get().GetName(this.data.rewardType)
this.titleTxt.textSet(e)
const i=Y.Inst_get().GetConfigVoByType(this.data.rewardType)
this.widget.heightSet(50+90*Math.ceil(i.Count()/9)),this.bg.heightSet(26+90*Math.ceil(i.Count()/9)),this.grid.data_set(i)}AddLis(){}RemoveLis(){}Clear(){this.grid.Clear(),
this.RemoveLis(),super.Clear()}Destroy(){this.grid.Destroy(),super.Destroy()}}class kt extends J.f{constructor(...t){super(...t),this.closeBtn=null,this.grid=null}InitView(){
super.InitView(),this.closeBtn=this.CreateComponent(Q.W,1),this.grid=this.CreateComponent(Dt.V,2),
this.grid.SetInitInfo("ui_dragontreasure_rewardpool_item",this.CreateDelegate(this.CreateItemHandler))}CreateItemHandler(t){const e=new Vt
return e.setId(t,null,0),e}OnAddToScene(){this.AddLis(),this.UpdateView()}UpdateView(){const t=new I.Z([{rewardType:Pt.BigRewardType},{rewardType:Pt.MidRewardType},{
rewardType:Pt.LowRewardType}])
this.grid.data_set(t),this.grid.CallReposition()}Clear(){super.Clear(),this.RemoveLis()}Destroy(){super.Destroy()}AddLis(){
this.AddClickEvent(this.closeBtn,this.CreateDelegate(this.CloseBtnHandle))}RemoveLis(){this.RemoveClickEvent(this.closeBtn,this.CreateDelegate(this.CloseBtnHandle))}
CloseBtnHandle(){ue.Inst_get().CloseRewardPoolView()}}var xt=i(43662),Ht=i(29562)
class Ut{constructor(t,e){this.id=null,this.itemData=null,this.id=t,this.itemData=e}}var Ft=i(25236),Yt=i(65227),Kt=i(64213),zt=i(45404)
class Qt extends tt.x{constructor(...t){super(...t),this.huodongQuestVo=null,this.targetVo=null,this.rewardVo=null,this.item=null,this.nameTxt=null,this.openAnim=null,
this.itemGo=null,this.eff_1=null,this.eff_2=null,this.eff_3=null,this.eff_4=null,this.eff_5=null,this.eff_6=null,this.eff_7=null,this.appearAnim=null,this.effLis=null,
this.data=null,this.model=null,this.timer=null}InitView(){super.InitView(),this.item=this.CreateComponentBinder(it.j,1),this.nameTxt=this.CreateComponent(X.Q,2),
this.openAnim=this.CreateComponent(at.k,3),this.itemGo=this.CreateComponent(z.z,4),this.eff_1=this.CreateComponent(z.z,5),this.eff_2=this.CreateComponent(z.z,6),
this.eff_3=this.CreateComponent(z.z,7),this.eff_4=this.CreateComponent(z.z,8),this.eff_5=this.CreateComponent(z.z,9),this.eff_6=this.CreateComponent(z.z,10),
this.eff_7=this.CreateComponent(z.z,11),this.appearAnim=this.CreateComponent(at.k,12),
this.effLis=new I.Z([this.eff_1,this.eff_2,this.eff_3,this.eff_4,this.eff_5,this.eff_6,this.eff_7])}SetData(t){this.AddLis(),this.data=t
for(let t=0;t<=this.effLis.Count()-1;t++){this.effLis[t].SetActive(!1)}this.UpdatePanel()}AddLis(){this.appearAnim.AddEventHandler(this.CreateDelegate(this.ShowItemHandle))}
RemoveLis(){this.appearAnim.RemoveEventHandler(this.CreateDelegate(this.ShowItemHandle))}OpenAnimHandle(){this.model.MainRole_get().ReSetEvent(),
this.model.MainRole_get().PlayAnim(10,0,!0),this.itemGo.SetActive(!0),this.appearAnim.SetLoopEnable(!1),this.appearAnim.SetResetOnPlay(!0),this.appearAnim.ResumeAnim(),
this.appearAnim.Play(!0,!1)}OpenItemAnimEnd(){}RefreshMonster(){null!=this.model&&this.model.Destroy(),this.model=new Kt.r
const t=ue.Inst_get().resultPanel
let e=!1
null!=t&&t.isShow_get()&&(e=t.IsOne())
let[i,s,n]=[0,-.2,1]
e||(i=this.index%5*.4-.8,s=-.4*Math.floor(this.index/5)),this.model.SetDisplayID(2090010096,Qt.STAGE_ID,0,.16,!1,this.CreateDelegate(this.InitHandle),!0,i,s,n),
zt.n.Instance_get().SetDisplayObject(Qt.STAGE_ID,this.model.MainRole_get().handle,0),xt.M.Instance_get().SetWorldRotation(Qt.STAGE_ID,0,new St.P(0,0,0)),
this.model.MainRole_get().DisableShadow()}InitHandle(){let t=Yt.o.dead,e=10
if(!Y.Inst_get().IsJumpAnim()){const i=Y.Inst_get().treasureDic[this.data.id]
null!=i&&null!=i.type&&(3==i.type?(t=Yt.o.skill1,e=14):2==i.type?(t=Yt.o.skill2,e=15):1==i.type&&(t=9,e=16))}if(t==Yt.o.dead)this.OpenAnimHandle()
else{const i=this.model.MainRole_get().GetAnimLifeTime(e)
i-.8<=0&&(0,Ft.S)(`未加载error${t}`,i),this.timer=_t.C.Inst_get().SetInterval(this.CreateDelegate(this.OpenAnimHandle),1e3*(i-.8),1)}
this.model.MainRole_get().PassEvent(t,this.CreateDelegate(this.OpenItemAnimEnd))}ShowItemHandle(){Y.Inst_get().RaiseEvent(b.OpenItemAnimEnd,this.index)}Clear(){
null!=this.model&&(this.model.Destroy(),this.model=null),this.item.Clear(),_t.C.Inst_get().ClearInterval(this.timer),super.Clear(),this.RemoveLis()}Destroy(){
null!=this.model&&(this.model.Destroy(),this.model=null),this.item.Destroy(),h.g.DestroyUIObj(),super.Destroy()}UpdatePanel(){this.itemGo.SetActive(!1),
this.appearAnim.node.SetActive(!1),this.data.itemData.IconType_Set(Et.s.NORMAL_ICON_TYPE),this.data.itemData.SpecialNumStr=" ",this.item.SetData(this.data.itemData)
const t=this.data.itemData.cfgData_get(),e=this.data.itemData.Quality_get(),i=S.l.getColorStrByQuality(e)
this.nameTxt.textSet(`[${i}]${t.name}[-] X ${this.data.itemData.count}`),this.effLis[e].SetActive(!0)
const s=Y.Inst_get().treasureDic[this.data.id]
null!=s&&null!=s.type&&this.item.SetQualityIcon(""),this.RefreshMonster()}}Qt.STAGE_ID=161
class Zt extends J.f{constructor(...t){super(...t),this.grid=null,this.timeTxt=null,this.maskLayer=null,this.texture=null,this.isEnd=null,this.list=null,this.time=null,
this.endTimer=null}InitView(){super.InitView(),this.grid=this.CreateComponent(Z.A,1),this.timeTxt=this.CreateComponent(X.Q,2),this.maskLayer=this.CreateComponent(z.z,3),
this.texture=this.CreateComponent(Ht.V,4),this.grid.SetInitInfo("ui_dragontreasure_openitem",null,Qt)}OnAddToScene(){this.AddLis(),this.RefreshMonster(),this.UpdateView()}
RefreshMonster(){xt.M.Instance_get().ActiveStage(Zt.STAGE_ID),xt.M.Instance_get().SetStageCameraPosition(Zt.STAGE_ID,St.P.zero_get()),
this.texture.SetMainTextureByPhoto(Zt.STAGE_ID)}UpdateView(){this.isEnd=!1,this.timeTxt.node.SetActive(!1),this.UpdateInfo()}Clear(){
xt.M.Instance_get().DeactiveStage(Zt.STAGE_ID,this.texture.FatherId,this.texture.ComponentId),this.RemoveLis(),this.ClearEndTime(),super.Clear()}Destroy(){super.Destroy()}AddLis(){
this.AddFullScreenCollider(this.node,this.CreateDelegate(this.OnCloseBtnHandle)),this.m_handlerMgr.AddClickEvent(this.maskLayer,this.CreateDelegate(this.OnCloseBtnHandle1)),
Y.Inst_get().AddEventHandler(b.OpenItemAnimEnd,this.CreateDelegate(this.AnimEndHandle))}RemoveLis(){
this.RemoveFullScreenCollider(this.node,this.CreateDelegate(this.OnCloseBtnHandle)),Y.Inst_get().RemoveEventHandler(b.OpenItemAnimEnd,this.CreateDelegate(this.AnimEndHandle))}
AnimEndHandle(t){t>=this.grid.itemList.Count()-1&&(this.isEnd=!0,this.timeTxt.node.SetActive(!0),this.timeTxt.textSet("点击空白处关闭"))}ConfirmBtnHandle(){
ue.Inst_get().OpenView(B.L.DragonTreasureMain)}UpdateInfo(){const t=Y.Inst_get().treasureEndInfo
if(null!=t){const e=t.reward,i=new I.Z
if(null!=e){const s=e.rewards
for(let e=0;e<=s.count-1;e++){const n=V.M.wrapReward(s[e]),a=new Ut(t.resultItems[e],n)
i.Add(a)}}this.list=i,this.grid.data_set(i)}}IsEndIdx(t){return null!=this.list&&t>=this.list.Count()-1}IsOne(){return null!=this.list&&1==this.list.Count()}OnCloseBtnHandle(){
this.isEnd&&ue.Inst_get().CloseResultView()}OnCloseBtnHandle1(){this.isEnd&&ue.Inst_get().CloseResultView()}StartTime(){this.time=9,this.ClearEndTime(),this.RefreshTime(),
this.endTimer=_t.C.Inst_get().SetInterval(this.CreateDelegate(this.RefreshTime),1e3,-1)}ClearEndTime(){null!=this.endTimer&&(_t.C.Inst_get().ClearInterval(this.endTimer),
this.endTimer=null)}RefreshTime(){this.time-=1,this.time<=0?this.ClearEndTime():(this.timeTxt.node.SetActive(!0),this.timeTxt.textSet("点击空白处关闭"))}}Zt.STAGE_ID=161
var Xt=i(15895),jt=i(68042),Jt=i(91280)
class Wt{constructor(t){this.itemData=null,this.isShowBuyIcon=!1,this.isShowGiveIcon=!1,this.itemData=t}}var $t=i(86133)
class qt{constructor(){this.confirmHandle=null,this.cancelHandle=null,this.confirmText=null,this.cancelText=null,this.isShowMask=!0,this.itemLis=null,this.layer=c.F.Alert,
this.topStr="",this.bottomStr="",this.confirmText=(0,$t.T)("确 定"),this.cancelText=(0,$t.T)("取 消"),this.itemLis=new I.Z}}class te extends tt.x{constructor(...t){super(...t),
this.limitTipLabel=null,this.nameLabel=null,this.costLabel=null,this.costIcon=null,this.buyBtn=null,this.costContainer=null,this.discountContainer=null,this.buyOverContainer=null,
this.customDiscountContainer=null,this.customDiscountLabel=null,this.baseItem=null,this.grid=null,this.bg1=null,this.redPoint=null,this.config=null,this.data=null,
this.consumeNum=null,this.consumeItemId=null}InitView(){super.InitView(),this.limitTipLabel=this.CreateComponent(X.Q,1),this.nameLabel=this.CreateComponent(X.Q,2),
this.costLabel=this.CreateComponent(X.Q,3),this.costIcon=this.CreateComponent(j.w,4),this.buyBtn=this.CreateComponent(Q.W,5),this.costContainer=this.CreateComponent(Dt.V,6),
this.discountContainer=this.CreateComponent(j.w,7),this.buyOverContainer=this.CreateComponent(z.z,8),this.customDiscountContainer=this.CreateComponent(j.w,9),
this.customDiscountLabel=this.CreateComponent(X.Q,10),this.baseItem=this.CreateComponentBinder(it.j,11),this.grid=this.CreateComponent(Dt.V,12),
this.bg1=this.CreateComponent(z.z,13),this.redPoint=this.CreateComponent(z.z,14)}ShowDiscount(){if(null==this.customDiscountContainer&&null==this.discountContainer)return
const t=this.config
null!=this.discountContainer&&this.discountContainer.node.SetActive(!1),null!=this.customDiscountContainer&&this.customDiscountContainer.SetActive(!1),
0!=t.label&&(1==t.label?(this.discountContainer.node.SetActive(!0),this.discountContainer.spriteNameSet("ryjbsd_sp_0012")):4==t.label?(this.discountContainer.node.SetActive(!0),
this.discountContainer.spriteNameSet("ryjbsd_sp_0011")):5==t.label&&(this.customDiscountContainer.node.SetActive(!0),this.customDiscountLabel.textSet(t.discount[1]),
this.customDiscountContainer.widthSet(this.customDiscountLabel.width()+35)))}SetData(t){this.data=t,this.config=x.Z.ins.GetVoByMallId(this.data.mallId)
const e=Y.Inst_get().GetItemLisByAndReward(t.reward)
if(null!=e&&e.Count()>0){const t=e[0],i=t.cfgData_get(),s=S.l.getColorStrByQuality(t.Quality_get())
this.nameLabel.textSet(`[${s}]${i.name}[-]`),t.SpecialNumStr=`X${t.count}`,this.baseItem.SetData(t)}this.AddLis(),this.RefreshInfo()}RefreshInfo(){this.bg1.SetActive(!1),
this.redPoint.SetActive(!1)
const t=D.P.ins.GetBuyTimesByMallId(this.data.mallId),e=this.data.limit
let i=`${t}/${e}`
i=t>=e&&e>0?`[ff0000]${i}[-]`:`[ffffff]${i}[-]`,null!=this.limitTipLabel&&(this.limitTipLabel.textSet(`兑换上限${i}`),
this.data.limit<=0?this.limitTipLabel.node.SetActive(!1):this.limitTipLabel.node.SetActive(!0)),null!=this.buyBtn&&(this.buyBtn.node.SetActive(!1),this.buyBtn.SetIsEnabled(!0))
const s=ue.Inst_get().GetConsume(this.data.consumeDefs)
if(null!=s&&s.Count()>0){const i=s[0],n=i.count,a=i.modelId_get()
let o=n
this.consumeNum=n,this.consumeItemId=a
const l=m.g.Inst_get().GetItemNum(a),r=q.f.Inst().getItemById(a)
h.g.SetItemIcon(this.costIcon.FatherId,this.costIcon.ComponentId,r.icon,W.b.eItem,!1),null!=this.buyBtn&&this.buyBtn.node.SetActive(!0),
this.data.limit>0&&t>=e?(o=`[ffffff]${o}[-]`,null!=this.buyOverContainer&&(this.buyOverContainer.SetActive(!0),
this.buyBtn.SetIsEnabled(!1))):o=l>=n?`[ffffff]${o}[-]`:`[ff0000]${o}[-]`,this.costLabel.textSet(o)}this.grid.CallReposition(),this.ShowDiscount(),
2==this.data.type&&(this.redPoint.SetActive(Y.Inst_get().IsCanBuy(this.data)),this.bg1.SetActive(!0))}AddLis(){
s.i.Inst.AddEventHandler(C.g.BAG_UPDATE,this.CreateDelegate(this.RefreshInfo)),s.i.Inst.AddEventHandler(C.g.HUODONG_MALL_BUY_CNT_CHANGE,this.CreateDelegate(this.RefreshInfo)),
null!=this.buyBtn&&Rt.i.Get(this.buyBtn).RegistonClick(this.CreateDelegate(this.BuyBtnHandle))}RemoveLis(){
s.i.Inst.RemoveEventHandler(C.g.BAG_UPDATE,this.CreateDelegate(this.RefreshInfo)),
s.i.Inst.RemoveEventHandler(C.g.HUODONG_MALL_BUY_CNT_CHANGE,this.CreateDelegate(this.RefreshInfo)),
s.i.Inst.RemoveEventHandler(C.g.TipsLoadCompelete,this.CreateDelegate(this.OpenBuyTipView)),
null!=this.buyBtn&&Rt.i.Get(this.buyBtn).RemoveonClick(this.CreateDelegate(this.BuyBtnHandle))}BuyBtnHandle(){const t=D.P.ins.GetBuyTimesByMallId(this.data.mallId)
if(this.data.limit>0&&t>=this.data.limit)G.y.inst.ClientSysStrMsg("当前商品已售罄")
else{const t=m.g.Inst_get().GetItemNum(this.consumeItemId)
if(this.consumeNum<=t)if(1==this.data.type)s.i.Inst.AddEventHandler(C.g.TipsLoadCompelete,this.CreateDelegate(this.OpenBuyTipView)),this.baseItem.OpenTipView()
else{const t=new qt,e=Xt.x.rep("  ",Math.floor(this.consumeNum/10))
t.topStr=`${e}是否确认消耗     X${this.consumeNum}购买如下商品`,t.confirmHandle=this.CreateDelegate(this.ConfirmHandle)
const i=Y.Inst_get().GetItemLisByAndReward(this.data.reward),s=new I.Z
if(null!=i&&i.Count()>0)for(let t=0;t<=i.Count()-1;t++){const e=i[t],n=new Wt(e)
s.Add(n)}t.itemLis=s,ue.Inst_get().OpenBuyTipView(t)}else G.y.inst.ClientSysStrMsg("货币不足，无法购买")}}OpenBuyTipView(){const t=D.P.ins.GetBuyTimesByMallId(this.data.mallId)
let e=this.data.limit-t
this.data.limit<=0&&(e=-1),s.i.Inst.RemoveEventHandler(C.g.TipsLoadCompelete,this.CreateDelegate(this.OpenBuyTipView))
const i=new Jt.v
i.InitItemData(this.consumeItemId,this.consumeNum,e,1,"购买数量",this.CreateDelegate(this.BuyHandle)),jt.o.Inst_get().OpenView(i)}BuyHandle(t){
v.$.ins.CM_ActivityMallBuy(this.data.mallId,t)}ConfirmHandle(){v.$.ins.CM_ActivityMallBuy(this.data.mallId)}Clear(){this.data=null,this.RemoveLis(),this.baseItem.Clear(),
super.Clear()}Destroy(){this.baseItem.Destroy(),super.Destroy()}}class ee extends J.f{constructor(...t){super(...t),this.closeBtn=null,this.grid=null,this.timeTxt=null,
this.tipBtn=null,this.currencyGrid=null,this.countDownTimer=null,this.exchangeLis=null}InitView(){super.InitView(),this.closeBtn=this.CreateComponent(Q.W,1),
this.grid=this.CreateComponent(Z.A,2),this.timeTxt=this.CreateComponent(X.Q,3),this.tipBtn=this.CreateComponent(Q.W,4),this.currencyGrid=this.CreateComponent(Z.A,5),
this.grid.SetInitInfo("ui_dragontreasure_shopitem",null,te),this.currencyGrid.SetInitInfo("ui_dragontreasure_currencyitem",null,wt)}OnAddToScene(){this.AddLis(),
this.currencyGrid.data_set(ue.Inst_get().GetCurrencyLisByViewType(B.L.DragonTreasureShop)),Ot.l.ins.CM_OpenActivityPanel(Y.Inst_get().GetShopActId()),this.UpdatePanel()}
UpdatePanel(){this.RefreshItemLis(),this.UpdateActivityInfo()}UpdateActivityInfo(){null!=this.countDownTimer&&this.ClearEndTimeHandle(),
this.countDownTimer=_t.C.Inst_get().SetInterval(this.CreateDelegate(this.RefreshEndTime),1e3,-1),this.RefreshEndTime()}TipBtnHandle(){const t=new pt.w
t.infoId="DRAGONTREASURE:TIPS3",t.width=384,t.position=new St.P(-401,121,0),At.Q.Inst_get().Open(t)}RefreshEndTime(){
const t=U.i.ins.huodong_dict.LuaDic_GetItem(Y.Inst_get().GetShopActId())
let e=0
null!=t&&(e=t.delayTime.ToNum()),e>0&&(e=.001*e-ct.D.serverTime_get()),e>0?this.timeTxt.textSet(`结束倒计时:${S.l.GetDateFormatBitContainZero(e,3)}`):(this.timeTxt.textSet("已结束"),
this.ClearEndTimeHandle())}ClearEndTimeHandle(){null!=this.countDownTimer&&(_t.C.Inst_get().ClearInterval(this.countDownTimer),this.countDownTimer=null)}GetShopLis(){
const t=D.P.ins.GetMallDictByHuoDongId(Y.Inst_get().GetShopActId()),e=new I.Z
if(null!=t)for(const[i,s]of(0,N.vy)(t))e.Add(s)
return e.Sort(this.CreateDelegate(this.SortFunc)),e}SortFunc(t,e){const i=x.Z.ins.GetVoByMallId(t.mallId),s=x.Z.ins.GetVoByMallId(e.mallId)
return i.order-s.order}RefreshItemLis(){this.exchangeLis=this.GetShopLis(),this.grid.data_set(this.exchangeLis)}Clear(){this.RemoveLis(),this.ClearEndTimeHandle(),
this.grid.Clear(),this.currencyGrid.Clear(),super.Clear()}Destroy(){this.grid.Destroy(),this.currencyGrid.Destroy(),super.Destroy()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.tipBtn,this.CreateDelegate(this.TipBtnHandle)),this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.CloseBtnHandle)),
this.m_handlerMgr.AddEventMgr(C.g.HUODONG_INFO_CHANGE,this.CreateDelegate(this.UpdateActivityInfo))}CloseBtnHandle(){ue.Inst_get().CloseShopView()}RemoveLis(){}}
var ie=i(35128),se=i(62370),ne=i(7601),ae=i(52513),oe=i(31896),le=i(19519),re=i(86577)
class he extends tt.x{constructor(...t){super(...t),this.huodongMallVo=null,this.huodongMallCfgVo=null,this.text_limit_time=null,this.text_name=null,this.img_discount=null,
this.btn_buy=null,this.text_buy=null,this.grid_item=null,this.consume_obj=null,this.img_consume_icon=null,this.text_consume_num=null,this.img_sell_over=null,
this.refreshTimeTxt=null,this.discountLabel=null,this.countDownId=null}InitView(){super.InitView(),this.text_limit_time=this.CreateComponent(X.Q,1),
this.text_name=this.CreateComponent(X.Q,2),this.img_discount=this.CreateComponent(j.w,3),this.btn_buy=this.CreateComponent(j.w,4),this.text_buy=this.CreateComponent(X.Q,5),
this.grid_item=this.CreateComponent(Z.A,6),this.consume_obj=this.CreateComponent(Dt.V,7),this.img_consume_icon=this.CreateComponent(j.w,8),
this.text_consume_num=this.CreateComponent(X.Q,9),this.img_sell_over=this.CreateComponent(j.w,10),this.refreshTimeTxt=this.CreateComponent(X.Q,11),
this.discountLabel=this.CreateComponent(X.Q,12),this.grid_item.SetInitInfo("ui_baseitem",this.CreateDelegate(this.OnInitItem))}OnInitItem(t){const e=new it.j
return e.SetIconType(Et.s.NORMAL_ICON_TYPE),e.setId(t,null,0),e.SetBgSize(52,52),e.SetIconSize(52,52),e}SetData(t){this.huodongMallVo=t,
this.huodongMallCfgVo=x.Z.ins.GetVoByMallId(this.huodongMallVo.mallId),this.AddLis(),this.Update()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.btn_buy,this.CreateDelegate(this.OnClickBtnBuy)),
this.m_handlerMgr.AddEventMgr(C.g.HUODONG_MALL_BUY_CNT_CHANGE,this.CreateDelegate(this.OnBuyCntChange))}RemoveLis(){}Clear(){super.Clear(),this.grid_item.Clear(),this.RemoveLis()}
Destroy(){this.grid_item.Destroy(),super.Destroy()}Update(){this.img_sell_over.SetActive(!1),this.img_discount.node.SetActive(!1),this.refreshTimeTxt.node.SetActive(!1),
this.img_consume_icon.SetActive(!1),-1==this.huodongMallVo.limit?this.text_limit_time.SetActive(!1):(this.text_limit_time.SetActive(!0),this.text_limit_time.textSet(se.o.Format((0,
$t.T)("限购{0}次"),this.huodongMallVo.limit-D.P.ins.GetBuyTimesByMallId(this.huodongMallVo.mallId)))),this.text_name.textSet(this.huodongMallCfgVo.name)
const t=new I.Z
for(let e=0;e<=this.huodongMallVo.reward.rewards.Count()-1;e++)t.Add(V.M.wrapReward(this.huodongMallVo.reward.rewards[e]))
this.grid_item.data_set(t),this.discountLabel.node.SetActive(!1),this.img_discount.node.SetActive(!0),
1==this.huodongMallCfgVo.label?this.img_discount.spriteNameSet("ryjbsd_sp_0012"):2==this.huodongMallCfgVo.label?(this.discountLabel.node.SetActive(!0),
this.img_discount.spriteNameSet("ryjbsd_sp_0027"),
this.discountLabel.textSet(`${this.huodongMallCfgVo.discount}%`)):3==this.huodongMallCfgVo.label?this.img_discount.spriteNameSet("ryjbsd_sp_0011"):this.img_discount.node.SetActive(!1),
this.img_discount.MakePixelPerfect(),
this.btn_buy.SetActive(!0),-1!=this.huodongMallVo.limit&&D.P.ins.GetBuyTimesByMallId(this.huodongMallVo.mallId)>=this.huodongMallVo.limit?(this.btn_buy.spriteNameSet("rycommon_bt_0026"),
this.text_consume_num.textSet("[4E443B]已领取[-]"),re.T.Inst_get().IsCanRefresh(this.huodongMallVo.nextRefreshTime)?(this.text_limit_time.SetActive(!1),
U.i.ins.GetState(Y.Inst_get().GetActId())==H.V.OPEN?this.StartCountDown():this.text_consume_num.textSet("[4E443B]已结束[-]")):(this.btn_buy.SetActive(!1),
this.img_sell_over.SetActive(!0))):(this.img_sell_over.SetActive(!1),U.i.ins.GetState(Y.Inst_get().GetActId())==H.V.OPEN?(this.img_consume_icon.SetActive(!0),
this.btn_buy.spriteNameSet("rycommon_bt_0024"),this.UpdateConsume()):(this.btn_buy.spriteNameSet("rycommon_bt_0026"),this.text_consume_num.textSet("[4E443B]已结束[-]")))}
UpdateConsume(){if(this.text_consume_num.SetActive(!0),this.img_consume_icon.SetActive(!0),0!=this.huodongMallVo.rechargeId){
const t=ae.O.Inst().getConfig(this.huodongMallVo.rechargeId),e=ne.W.Inst.GetCurSystem(),i=t.platformCurrency[e]
this.text_consume_num.textSet(`${i}元`),this.img_consume_icon.SetActive(!1)}else{const t=this.huodongMallVo.Consume_Get().GetItemDataByType()
this.text_consume_num.textSet(Lt.w.Instance.ConvertNumToString(t.count)),null!=t.virtualItemData_get()?this.img_consume_icon.spriteNameSet(le.J.GetCurrencyIconUrl(t.virtualItemData_get().virtualTypeStr)):this.img_consume_icon.spriteNameSet("")
}this.refreshTimeTxt.node.SetActive(!1),this.consume_obj.CallReposition()}OnClickBtnBuy(){
-1!=this.huodongMallVo.limit&&D.P.ins.GetBuyTimesByMallId(this.huodongMallVo.mallId)>=this.huodongMallVo.limit||(U.i.ins.GetState(Y.Inst_get().GetActId())==H.V.OPEN?0!=this.huodongMallCfgVo.rechargeId?oe.t.inst.Buy(ae.O.Inst().getConfig(this.huodongMallVo.rechargeId)):v.$.ins.CheckConsumeEnough(this.huodongMallVo.Consume_Get())&&v.$.ins.CM_ActivityMallBuy(this.huodongMallVo.mallId):G.y.inst.ClientSysStrMsg("活动已结束"))
}OnBuyCntChange(t){t==this.huodongMallVo.mallId&&this.Update()}StartCountDown(){this.ClearCountDown(),this.refreshTimeTxt.node.SetActive(!0),
this.countDownId=_t.C.Inst_get().SetInterval(this.CreateDelegate(this.RefreshTime),1e3,-1),this.RefreshTime()}ClearCountDown(){this.refreshTimeTxt.node.SetActive(!1),
null!=this.countDownId&&(_t.C.Inst_get().ClearInterval(this.countDownId),this.countDownId=null)}RefreshTime(){
if(null!=this.huodongMallVo.nextRefreshTime&&this.huodongMallVo.nextRefreshTime.ToNum()>0){const t=this.huodongMallVo.nextRefreshTime.ToNum()-ct.D.serverTime_get()
if(t>0){const e=S.l.GetDateFormatEX(t,!0,!0)
this.refreshTimeTxt.textSet(e)}else this.refreshTimeTxt.node.SetActive(!1)}
U.i.ins.GetState(Y.Inst_get().GetActId())!=H.V.END&&U.i.ins.GetState(Y.Inst_get().GetActId())!=H.V.CLOSE||(this.ClearCountDown(),this.Update())}}class de extends J.f{
constructor(...t){super(...t),this.grid_item=null,this.notMallGo=null,this.timeTxt=null,this.closeBtn=null,this.interval=null,this.text_time=null}ShowCurrencyBar_get(){
return dt._.ShowGold_Dia_BindDia}InitView(){super.InitView(),this.grid_item=this.CreateComponent(Z.A,1),this.notMallGo=this.CreateComponent(z.z,2),
this.timeTxt=this.CreateComponent(X.Q,3),this.closeBtn=this.CreateComponent(Q.W,4),this.grid_item.SetInitInfo("ui_dragontreasure_treasureshopitem",null,he)}OnAddToScene(){
this.AddLis(),this.m_handlerMgr.AddEventMgr(C.g.HUODONG_MALL_CHANGE,this.CreateDelegate(this.UpdateView)),Ot.l.ins.CM_OpenActivityPanel(Y.Inst_get().GetActId()),
null==this.interval&&(this.interval=_t.C.Inst_get().SetInterval(this.CreateDelegate(this.OnEachSec),1e3)),this.UpdateView(),this.OnEachSec()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.OnCloseBtnHandle))}OnCloseBtnHandle(){ue.Inst_get().CloseTreasureShopView()}RemoveLis(){}Clear(){
super.Clear(),null!=this.interval&&(_t.C.Inst_get().ClearInterval(this.interval),this.interval=null)}Destroy(){super.Destroy()}UpdateView(){
const t=D.P.ins.GetMallListByHuoDongId(Y.Inst_get().GetActId()),e=new I.Z
for(let i=0;i<=t.Count()-1;i++){const s=t[i]
t[i].CheckView()&&t[i].CheckBuy()&&s.type==w.f.RECHARGE_TYPE&&e.Add(t[i])}this.notMallGo.SetActive(0==e.Count()),this.grid_item.data_set(e)}OnEachSec(){
const t=U.i.ins.huodong_dict.LuaDic_GetItem(Y.Inst_get().GetActId())
if(null!=t){const e=ie.p.FloorToInt(t.endTime.ToNum()/1e3)-ct.D.serverTime_get()
e>0?this.timeTxt.textSet(S.l.GetDateFormatEX(e,!0,!0)):(this.text_time.textSet("[b09979]已结束[-]"),ue.Inst_get().CloseTreasureShopView())}else this.text_time.textSet("")}}class ue{
constructor(){this.view=null,this.sendTime=null,this.buyVo=null,this.buyTipView=null,this.resultPanel=null,this.AddLis(),this.RegisterProtocol()}static Inst_get(){
return null==ue.inst&&(ue.inst=new ue),ue.inst}AddLis(){}RegisterProtocol(){o.j.Inst.F_Register(-12151,T.V,this.CreateDelegate(this.SM_DragonTreasureConfigHandle)),
o.j.Inst.F_Register(-12152,R.p,this.CreateDelegate(this.SM_DragonTreasureInfoHandle)),o.j.Inst.F_Register(-12155,y.t,this.CreateDelegate(this.SM_DragonTreasureHandle))}
SM_DragonTreasureHandle(t){Y.Inst_get().SetTreasureEndInfo(t),Y.Inst_get().RaiseEvent(b.OpenSuccess,t),this.OpenResultView()}SM_DragonTreasureConfigHandle(t){
Y.Inst_get().actId=t.activityId,Y.Inst_get().SetTreasureConfig(t),Y.Inst_get().RaiseEvent(b.UpdateConfig,t)}SM_DragonTreasureInfoHandle(t){Y.Inst_get().SetTreasureInfo(t),
Y.Inst_get().RaiseEvent(b.UpdateInfo,t)}SendCM_DragonTreasure(t,e){null==e&&(e=Y.Inst_get().GetActId())
const i=new f.k
i.num=t,i.activityId=e,l.C.Inst.F_SendMsg(i)}SendSetAnim(t){let e=0
t&&(e=1),E.p.inst.SendClientLogicSetting(L.R.DRAGONTREASURE_JUMP_ANIM,e)}OpenView(t){
if(!p.P.Inst_get().IsFunctionOpened(A.x.DRAGON_TREASURE))return void S.l.SetFunctionTip(A.x.DRAGON_TREASURE)
if(Y.Inst_get().defaultView=t,null!=this.view&&this.view.isShow_get())return
const e=new r.v
e.isShowMask=!0,e.isDefaultUITween=!0,e.isSelfTween=!1,d.N.inst.OpenById(u.I.DragonTreasureView,this.CreateDelegate(this.ShowViewHandler),this.CreateDelegate(this.DestroyViewHandler),e)
}CloseView(){d.N.inst.CloseById(u.I.DragonTreasureView)}DestroyViewHandler(){h.g.DestroyUIObj(this.view),this.view=null}ShowViewHandler(t){
return null==this.view&&(this.view=new Nt,this.view.setId(t,null,0)),this.view}GoHandle(t){this.sendTime=t
const e=Y.Inst_get().GetKeyItemId(),i=m.g.Inst_get().GetItemNum(e),n=Y.Inst_get().GetConsumeNum(t)
if(1==t&&null!=Y.Inst_get().treasureInfo&&Y.Inst_get().treasureInfo.restFreeCount>0)this.SendCM_DragonTreasure(t)
else if(i<n)if(m.g.Inst_get().emptySize_get()>=2){
v.$.ins.CheckItemEnough(Y.Inst_get().GetActId(),e,n)||s.i.Inst.AddEventHandler(C.g.HUODONG_MALL_BUY_SUCCESS,this.CreateDelegate(this.BuySuccessHandle))
}else G.y.inst.ClientSysStrMsg("背包已满"),g.J.Inst_get().OpenBagSellPanel()
else this.SendCM_DragonTreasure(t)}GetConsume(t){if(!_.M.IsNullOrEmpty(t)){const e=n.d.parseJsonObjectWithFix(t,"rewardValues"),i=a.t.decode(e,O.h)
return i.Parse(),i.GetItemList()}}BuySuccessHandle(t){const e=this.GetMallInfo()
if(null!=e&&t.mallId==e.mallId){s.i.Inst.RemoveEventHandler(C.g.HUODONG_MALL_BUY_SUCCESS,this.CreateDelegate(this.BuySuccessHandle))
const t=Y.Inst_get().GetKeyItemId()
m.g.Inst_get().GetItemNum(t)>=Y.Inst_get().GetConsumeNum(this.sendTime)&&this.SendCM_DragonTreasure(this.sendTime)}}GetMallInfo(){
return D.P.ins.GetVoByHuodongIdAndType(Y.Inst_get().GetActId(),w.f.TICKET_TYPE)}GetCurrencyLisByViewType(t){let e=new I.Z
const i=Y.Inst_get().GetGoldItemId(),s=Y.Inst_get().GetSilverItemId(),n=Y.Inst_get().GetKeyItemId()
return t==B.L.DragonTreasureShop?e=new I.Z([{itemId:i},{itemId:s}]):t==B.L.DragonTreasureMain&&(e=new I.Z([{itemId:i},{itemId:s},{itemId:n}])),e}OpenBuyTipView(t){if(this.buyVo=t,
null!=this.buyTipView&&this.buyTipView.isShow_get())return void this.buyTipView.UpdateView()
const e=new r.v
e.isShowMask=t.isShowMask,e.isDefaultUITween=!0,e.isSelfTween=!1,d.N.inst.OpenById(u.I.DragonTreasureBuyTipView,this.CreateDelegate(this.ShowBuyTipViewHandler),this.CreateDelegate(this.DestroyBuyTipViewHandler),e)
}CloseBuyTipView(){d.N.inst.CloseById(u.I.DragonTreasureBuyTipView)}DestroyBuyTipViewHandler(){h.g.DestroyUIObj(this.buyTipView),this.buyTipView=null}ShowBuyTipViewHandler(t){
return null==this.buyTipView&&(this.buyTipView=new nt,this.buyTipView.setId(t,null,0)),this.buyTipView}OpenShopView(){
if(!p.P.Inst_get().IsFunctionOpened(A.x.DRAGON_TREASURE_SHOP))return void S.l.SetFunctionTip(A.x.DRAGON_TREASURE_SHOP)
const t=new r.v
t.viewClass=ee,t.isShowMask=!0,d.N.inst.OpenById(u.I.DragonTreasureShopView,null,null,t)}CloseShopView(){d.N.inst.CloseById(u.I.DragonTreasureShopView)}OpenRewardPoolView(){
const t=new r.v
t.viewClass=kt,t.isShowMask=!0,d.N.inst.OpenById(u.I.DragonRewardPoolView,null,null,t)}CloseRewardPoolView(){d.N.inst.CloseById(u.I.DragonRewardPoolView)}OpenResultView(){
const t=new r.v
t.isShowMask=!1,d.N.inst.OpenById(u.I.DragonResultView,this.CreateDelegate(this.ShowResultViewHandler),this.CreateDelegate(this.DestroyResultViewHandler),t)}
DestroyResultViewHandler(){h.g.DestroyUIObj(this.resultPanel),this.resultPanel=null}ShowResultViewHandler(t){return null==this.resultPanel&&(this.resultPanel=new Zt,
this.resultPanel.setId(t,null,0)),this.resultPanel}CloseResultView(){d.N.inst.CloseById(u.I.DragonResultView)}OpenTreasureShopView(){const t=new r.v
t.viewClass=de,t.isShowMask=!0,t.maskAlpha=.8,t.layerType=c.F.Alert,d.N.inst.OpenById(u.I.DragonTreasureTreasureShopView,null,null,t)}CloseTreasureShopView(){
d.N.inst.CloseById(u.I.DragonTreasureTreasureShopView)}}ue.inst=null},33072:(t,e,i)=>{i.d(e,{L:()=>s})
class s{}s.DragonTreasureMain=0,s.DragonTreasureShop=1},61249:(t,e,i)=>{i.d(e,{p:()=>$t})
var s=i(32076),n=i(25236),a=i(97461),o=i(38935),l=i(56937),r=i(18202),h=i(31222),d=i(5494),u=i(8334),c=i(52726),_=i(85602),I=i(38962),g=i(52212),m=i(21554),C=i(70850),S=i(63076),p=i(92679),A=i(87923),f=i(37648),y=i(55492),T=i(82536),R=i(10354),v=i(82668),w=i(14266),D=i(21851),E=i(85605),L=i(82025),G=i(60567),O=i(60647),b=i(13487),B=i(65550),N=i(56834),P=i(93727),M=i(27354)
class V{constructor(t,e,i){this.desc=null,this.itemDataLis=null,this.vec=null,this.desc=t,this.itemDataLis=e,this.vec=i}}
var k=i(86577),x=i(99294),H=i(9986),U=i(6665),F=i(78287),Y=i(93877),K=i(61911),z=i(79534),Q=i(43308)
class Z{constructor(t,e){this.id=null,this.itemData=null,this.id=t,this.itemData=e}}var X=i(5924),j=i(9057),J=i(57834),W=i(3522),$=i(72005),q=i(75696),tt=i(20886)
class et extends j.x{constructor(...t){super(...t),this.itemData=null,this.baseItem=null,this.showEff=null,this.integral=null,this.integralNumTxt=null,this.quality=null,
this.appearAnim=null,this.rareMerchant=null,this.data=null,this.appearId=null}InitView(){super.InitView(),this.baseItem=this.CreateComponentBinder(q.j,1),
this.showEff=this.CreateComponent(x.z,2),this.integral=this.CreateComponent(x.z,3),this.integralNumTxt=this.CreateComponent(Y.Q,4),this.quality=this.CreateComponent($.w,5),
this.appearAnim=this.CreateComponent(W.k,6),this.rareMerchant=this.CreateComponent(x.z,7)}Destroy(){this.baseItem.Destroy(),super.Destroy()}AppearHandle(){this.node.SetActive(!0),
this.appearAnim.node.SetActive(!0),this.appearAnim.SetResetOnPlay(!0),this.appearAnim.ResumeAnim(),this.appearAnim.Play(!0,!1),this.ShowInfo()}ShowInfo(){
if(this.node.SetActive(!0),this.quality.node.SetActive(!1),this.showEff.SetActive(!1),this.integral.SetActive(!1),this.rareMerchant.SetActive(!1),
null!=this.data&&null!=this.data.id){const t=k.T.Inst_get().GetBoxResById(this.data.id)
if(null!=t&&this.showEff.SetActive(1==t.show),null!=t&&2==t.boxType){this.quality.node.SetActive(!0),this.integral.SetActive(!0),this.integralNumTxt.textSet(t.pointReward)
const e=`rycommon_sp_005${t.quality+3}`
this.quality.spriteNameSet(e)}null!=t&&3==t.boxType&&(this.quality.node.SetActive(!0),this.rareMerchant.SetActive(!0))}this.SetBaseItem()}ClearAppearId(){
null!=this.appearId&&(X.C.Inst_get().ClearInterval(this.appearId),this.appearId=null)}SetData(t){this.data=t,this.node.SetActive(!1),this.appearAnim.node.SetActive(!1),
this.ClearAppearId(),this.appearId=X.C.Inst_get().SetInterval(this.CreateDelegate(this.AppearHandle),300*this.index,1),this.AddLis()}SetBaseItem(){
null!=this.data&&null!=this.data.itemData?(this.baseItem.SetActive(!0),this.baseItem.SetData(this.data.itemData)):this.baseItem.node.SetActive(!1)}AddLis(){
this.appearAnim.AddEventHandler(this.CreateDelegate(this.EndAnimHandle)),J.i.Get(this.node).RegistonClick(this.CreateDelegate(this._OnClickHandler)),
k.T.Inst_get().AddEventHandler(M.F.JUMP_RESULT_ANIM,this.CreateDelegate(this.JumpAnimHandle))}JumpAnimHandle(){this.appearAnim.node.SetActive(!1),this.ClearAppearId(),
this.ShowInfo(),this.EndAnimHandle()}RemoveLis(){J.i.Get(this.node).RemoveonClick(this.CreateDelegate(this._OnClickHandler)),
this.appearAnim.RemoveEventHandler(this.CreateDelegate(this.EndAnimHandle)),k.T.Inst_get().RemoveEventHandler(M.F.JUMP_RESULT_ANIM,this.CreateDelegate(this.JumpAnimHandle))}
_OnClickHandler(){if(null!=this.data){const t=k.T.Inst_get().GetBoxResById(this.data.id)
if(2==t.boxType){const t=new S.M(tt.v.FORTUNE_POINT_ID)
$t.Inst_get().OpenTipView(t)}else t.boxType}}EndAnimHandle(){k.T.Inst_get().RaiseEvent(M.F.RESULT_ANIM_END,this.index)}Clear(){this.data=null,this.baseItem.Clear(),
this.RemoveLis(),this.ClearAppearId(),super.Clear()}}class it extends K.f{constructor(...t){super(...t),this.desc=null,this.grid=null,this.goTenBtn=null,this.bar=null,
this.btnNum=null,this.confirmBtn=null,this.btnGo=null,this.bestPriceTxt=null,this.isPlaying=null,this.allItemLis=null}InitView(){super.InitView(),
this.desc=this.CreateComponent(Y.Q,1),this.grid=this.CreateComponent(U.A,2),this.goTenBtn=this.CreateComponent(H.W,3),this.bar=this.CreateComponent(F._,4),
this.btnNum=this.CreateComponent(Y.Q,5),this.confirmBtn=this.CreateComponent(H.W,6),this.btnGo=this.CreateComponent(x.z,7),this.bestPriceTxt=this.CreateComponent(Y.Q,8),
this.grid.SetInitInfo("ui_fortunetreasure_item",null,et)}OnAddToScene(){this.AddLis(),this.UpdateView()}UpdateView(){const t=k.T.Inst_get().rollResult
this.desc.textSet(`获得积分总计：[5fb470]${t.point}[-]`),this.isPlaying=!0,this.RefreshBtnName(),this.UpdateItemLis(t.reward,t.resourceIds),this.UpdatePriceTxt(),this.btnGo.SetActive(!1),
this.bar.SetValue(0)}RefreshBtnName(){k.T.Inst_get().GetDiceItemNum()>=10?this.btnNum.textSet("再投10次(    10)"):this.btnNum.textSet("再投10次(    [FF4B58]10[-])")}Clear(){
this.grid.Clear(),this.RemoveLis(),super.Clear()}Destroy(){this.grid.Destroy()}AddLis(){this.AddClickEvent(this.goTenBtn,this.CreateDelegate(this.GoTenBtnHandle)),
this.AddClickEvent(this.confirmBtn,this.CreateDelegate(this.OnCloseBtnHandle)),this.AddFullScreenCollider(this.node,this.CreateDelegate(this.OnCloseBtnHandle)),
this.m_handlerMgr.AddEventMgr(p.g.BAG_UPDATE,this.CreateDelegate(this.RefreshBtnName)),k.T.Inst_get().AddEventHandler(M.F.UPDATE_INFO,this.CreateDelegate(this.UpdatePriceTxt)),
k.T.Inst_get().AddEventHandler(M.F.RESULT_ANIM_END,this.CreateDelegate(this.ItemAnimEndHandle))}RemoveLis(){
this.RemoveClickEvent(this.goTenBtn,this.CreateDelegate(this.GoTenBtnHandle)),this.RemoveClickEvent(this.confirmBtn,this.CreateDelegate(this.OnCloseBtnHandle)),
this.RemoveFullScreenCollider(this.node,this.CreateDelegate(this.OnCloseBtnHandle)),
k.T.Inst_get().RemoveEventHandler(M.F.RESULT_ANIM_END,this.CreateDelegate(this.ItemAnimEndHandle)),
k.T.Inst_get().RemoveEventHandler(M.F.UPDATE_INFO,this.CreateDelegate(this.UpdatePriceTxt))}ItemAnimEndHandle(t){null!=t&&t>=this.allItemLis.Count()-1&&(this.isPlaying=!1,
this.btnGo.SetActive(!0))}UpdatePriceTxt(){let t=""
const e=k.T.Inst_get().rollResult.resourceIds
let i
for(let s=0;s<=e.Count()-1;s++){i=e[s]
const n=k.T.Inst_get().GetBoxResById(i)
if(null!=n){let e=null
if(3!=n.boxType&&null!=n.itemReward&&null!=n.itemReward.rewards&&1==n.boxType&&1==n.bestPrize){e=S.M.wrapReward(n.itemReward.rewards[0])
const i=e.Quality_get()
t=`[${A.l.getColorStrByQuality(i)}]${e.cfgData_get().name}[-]剩余获取次数:${k.T.Inst_get().GetBoxRemainNum(n.id)}`
break}}}this.bestPriceTxt.node.SetActive(""!=t),this.bestPriceTxt.textSet(t)}GoTenBtnHandle(){null!=k.T.Inst_get().info&&$t.Inst_get().GoHandle(!0)}OnCloseBtnHandle(){
this.isPlaying?(k.T.Inst_get().RaiseEvent(M.F.JUMP_RESULT_ANIM),this.isPlaying=!1):$t.Inst_get().CloseFateResultView()}UpdateItemLis(t,e){const i=new _.Z
let s=0
for(let n=0;n<=e.Count()-1;n++){const a=e[n],o=k.T.Inst_get().GetBoxResById(a)
if(null!=o){let e=null
if(3!=o.boxType){null!=t&&null!=t.rewards&&1==o.boxType&&(e=S.M.wrapReward(t.rewards[s]),s+=1)
const n=new Z(a,e)
null!=n&&i.Add(n)}else{const t=new Z(a,e)
null!=t&&i.Add(t)}}}this.confirmBtn.node.SetActive(!1),this.goTenBtn.node.SetActive(!1),e.Count()>1?this.goTenBtn.node.SetActive(!0):this.confirmBtn.node.SetActive(!0),
this.allItemLis=i,this.grid.data_set(i),this.grid.node.SetActive(!1),this.grid.node.SetActive(!0)}AddTimeBtnHandle(){const t=k.T.Inst_get().GetDiceItemId()
Q._.Inst_get().OpenByItem(t,z.P.zero_get(),null,!0)}}class st extends K.f{constructor(...t){super(...t),this.descTxt=null,this.grid=null}InitView(){super.InitView(),
this.descTxt=this.CreateComponent(Y.Q,1),this.grid=this.CreateComponent(U.A,2),this.grid.SetInitInfo("ui_baseitem",null,q.j),
this.AddFullScreenCollider(this.node,this.CreateDelegate(this.Close))}OnAddToScene(){const t=$t.Inst_get().roundTipData
null!=t&&(this.descTxt.textSet(t.desc),this.grid.data_set(t.itemDataLis))}Clear(){super.Clear()}Destroy(){super.Destroy()}Close(){$t.Inst_get().CloseRoundRewardTipsView()}}
var nt=i(36334),at=i(44255),ot=i(28287),lt=i(14792),rt=i(68662),ht=i(63062),dt=i(61756),ut=i(32759),ct=i(8889),_t=i(32208),It=i(51868),gt=i(83540),mt=i(60130),Ct=i(70093),St=i(53905),pt=i(65772),At=i(33138),ft=i(47786),yt=i(50679),Tt=i(35073)
class Rt extends j.x{constructor(...t){super(...t),this.quality=null,this.itemImg=null,this.integral=null,this.integralTxt=null,this.startPoint=null,this.merchant=null,
this.itemNum=null,this.eff=null,this.effPanel=null,this.bestprice=null,this.remainTxt=null,this.data=null}InitView(){super.InitView(),this.quality=this.CreateComponent($.w,1),
this.itemImg=this.CreateComponent($.w,2),this.integral=this.CreateComponent(x.z,3),this.integralTxt=this.CreateComponent(Y.Q,4),this.startPoint=this.CreateComponent(x.z,5),
this.merchant=this.CreateComponent(x.z,6),this.itemNum=this.CreateComponent(Y.Q,7),this.eff=this.CreateComponent(x.z,8),this.effPanel=this.CreateComponent(x.z,9),
this.bestprice=this.CreateComponent(x.z,10),this.remainTxt=this.CreateComponent(Y.Q,11)}Clear(){this.data=null,this.RemoveLis()}Destroy(){}SetData(t,e){this.data=t,this.index=e,
this.effPanel.SetActive(!1),this.OnPanelAniEnd(),this.UpdateInfoHandle(),this.AddLis()}AddLis(){
k.T.Inst_get().AddEventHandler(M.F.BEST_PRICE_UPDATE,this.CreateDelegate(this.UpdateRemainNum)),
k.T.Inst_get().AddEventHandler(M.F.FIRST_ROLL,this.CreateDelegate(this.UpdateInfoHandle)),J.i.Get(this.node).RegistonClick(this.CreateDelegate(this._OnClickHandler)),
a.i.Inst.AddEventHandler(p.g.TabCommonOpenAniEnd,this.CreateDelegate(this.OnPanelAniEnd))}RemoveLis(){J.i.Get(this.node).RemoveonClick(this.CreateDelegate(this._OnClickHandler)),
k.T.Inst_get().RemoveEventHandler(M.F.FIRST_ROLL,this.CreateDelegate(this.UpdateInfoHandle)),
a.i.Inst.RemoveEventHandler(p.g.TabCommonOpenAniEnd,this.CreateDelegate(this.OnPanelAniEnd)),
k.T.Inst_get().RemoveEventHandler(M.F.BEST_PRICE_UPDATE,this.CreateDelegate(this.UpdateRemainNum))}OnPanelAniEnd(){
k.T.Inst_get().isEnd&&(0==this.index&&k.T.Inst_get().IsFirstRoll(k.T.Inst_get().info)||this.effPanel.SetActive(!0))}UpdateInfoHandle(){if(this.startPoint.SetActive(!1),
this.integral.SetActive(!1),this.merchant.SetActive(!1),this.itemImg.node.SetActive(!1),this.quality.node.SetActive(!1),this.itemNum.node.SetActive(!1),
this.bestprice.SetActive(!1),null!=this.data){
if(null!=this.index&&0==this.index&&null!=k.T.Inst_get().info&&k.T.Inst_get().IsFirstRoll(k.T.Inst_get().info))return void this.startPoint.SetActive(!0)
if(1==this.data.boxType){const t=$t.Inst_get().GetItemLisByAndReward(this.data.itemReward)
if(this.itemImg.node.SetActive(!0),null!=t&&t.Count()>0){const e=t[0]
e.count>1&&(this.itemNum.textSet(e.count),this.itemNum.node.SetActive(!0)),r.g.SetItemIcon(this.itemImg.FatherId,this.itemImg.ComponentId,e.cfgData_get().icon,gt.b.eItem)}
}else 2==this.data.boxType?(this.integral.SetActive(!0),this.integralTxt.textSet(this.data.pointReward)):3==this.data.boxType&&this.merchant.SetActive(!0)
this.UpdateRemainNum()
const t=`rycommon_sp_005${this.data.quality+3}`
this.quality.spriteNameSet(t),this.quality.node.SetActive(3!=this.data.boxType),this.eff.SetActive(1==this.data.show)}}UpdateRemainNum(){
null!=this.data&&1==this.data.bestPrize&&(this.bestprice.SetActive(!0),this.remainTxt.textSet(`剩余${k.T.Inst_get().GetBoxRemainNum(this.data.id)}个`))}_OnClickHandler(){
if(null!=this.data)if(1==this.data.boxType){const t=$t.Inst_get().GetItemLisByAndReward(this.data.itemReward)
if(null!=t&&t.Count()>0){const e=t[0]
$t.Inst_get().OpenTipView(e)}}else if(2==this.data.boxType){const t=new S.M(tt.v.FORTUNE_POINT_ID)
$t.Inst_get().OpenTipView(t)}else this.data.boxType}}class vt extends K.f{constructor(...t){super(...t),this.leftTimeTxt=null,this.goOneBtn=null,this.grid=null,this.selectImg=null,
this.closeBtn=null,this.point1=null,this.point2=null,this.point3=null,this.point4=null,this.point5=null,this.point6=null,this.selectPoint=null}InitView(){super.InitView(),
this.leftTimeTxt=this.CreateComponent(Y.Q,1),this.goOneBtn=this.CreateComponent(H.W,2),this.grid=this.CreateComponent(U.A,3),this.selectImg=this.CreateComponent(x.z,4),
this.closeBtn=this.CreateComponent(H.W,5),this.point1=this.CreateComponent(x.z,6),this.point2=this.CreateComponent(x.z,7),this.point3=this.CreateComponent(x.z,8),
this.point4=this.CreateComponent(x.z,9),this.point5=this.CreateComponent(x.z,10),this.point6=this.CreateComponent(x.z,11)}UpdateView(){this.node.SetActive(!0)
const t=k.T.Inst_get().info
this.leftTimeTxt.textSet(`剩余：     [076612]${t.specialRollRemain}[-]`),this.selectPoint=5,this.selectImg.transform.SetParent(this.point5.FatherId,this.point5.ComponentId)}Clear(){
super.Clear(),this.grid.Clear(),this.RemoveLis()}Destroy(){this.grid.Destroy()}AddLis(){this.AddClickEvent(this.goOneBtn,this.CreateDelegate(this.GoOneBtnHandle)),
this.AddClickEvent(this.closeBtn,this.CreateDelegate(this.OnCloseBtnHandle)),J.i.Get(this.point1).RegistonClick(this.CreateDelegate(this.PointHandle)),
J.i.Get(this.point2).RegistonClick(this.CreateDelegate(this.PointHandle)),J.i.Get(this.point3).RegistonClick(this.CreateDelegate(this.PointHandle)),
J.i.Get(this.point4).RegistonClick(this.CreateDelegate(this.PointHandle)),J.i.Get(this.point5).RegistonClick(this.CreateDelegate(this.PointHandle)),
J.i.Get(this.point6).RegistonClick(this.CreateDelegate(this.PointHandle))}RemoveLis(){this.RemoveClickEvent(this.goOneBtn,this.CreateDelegate(this.GoOneBtnHandle)),
this.RemoveClickEvent(this.closeBtn,this.CreateDelegate(this.OnCloseBtnHandle)),J.i.Get(this.point1).RemoveonClick(this.CreateDelegate(this.PointHandle)),
J.i.Get(this.point2).RemoveonClick(this.CreateDelegate(this.PointHandle)),J.i.Get(this.point3).RemoveonClick(this.CreateDelegate(this.PointHandle)),
J.i.Get(this.point4).RemoveonClick(this.CreateDelegate(this.PointHandle)),J.i.Get(this.point5).RemoveonClick(this.CreateDelegate(this.PointHandle)),
J.i.Get(this.point6).RemoveonClick(this.CreateDelegate(this.PointHandle))}GoOneBtnHandle(){
k.T.Inst_get().info.specialRollRemain>0&&$t.Inst_get().SendCM_FortuneRoll(!0,this.selectPoint,!1),this.OnCloseBtnHandle()}OnCloseBtnHandle(){this.node.SetActive(!1)}PointHandle(t){
let e=null
t==this.point1.ComponentId?(this.selectPoint=1,e=this.point1):t==this.point2.ComponentId?(this.selectPoint=2,e=this.point2):t==this.point3.ComponentId?(e=this.point3,
this.selectPoint=3):t==this.point4.ComponentId?(e=this.point4,this.selectPoint=4):t==this.point5.ComponentId?(e=this.point5,
this.selectPoint=5):t==this.point6.ComponentId&&(e=this.point6,this.selectPoint=6),null!=e&&this.selectImg.transform.SetParent(e.FatherId,e.ComponentId)}}class wt extends j.x{
constructor(...t){super(...t),this.turnNumTxt=null,this.redPoint=null,this.achieve=null,this.itemImg=null,this.receive=null,this.noReceive=null,this.baseItem=null,this.eff=null,
this.data=null,this.canGet=null,this.itemLis=null}InitView(){super.InitView(),this.turnNumTxt=this.CreateComponent(Y.Q,1),this.redPoint=this.CreateComponent(x.z,2),
this.achieve=this.CreateComponent(x.z,3),this.itemImg=this.CreateComponent(H.W,4),this.receive=this.CreateComponent(x.z,5),this.noReceive=this.CreateComponent(x.z,6),
this.baseItem=this.CreateComponentBinder(q.j,7),this.eff=this.CreateComponent(x.z,8)}Destroy(){this.baseItem.Destroy()}SetData(t){this.eff.SetActive(!1),this.data=t,
this.UpdateInfoHandle(),k.T.Inst_get().isEnd&&this.OnPanelAniEnd(),this.AddLis()}UpdateInfoHandle(){this.turnNumTxt.textSet(`${this.data.round}圈`)
const t=k.T.Inst_get().info,e=k.T.Inst_get().roundRewardMap[t.loop]
this.receive.SetActive(!1),this.achieve.SetActive(!1),this.redPoint.SetActive(!1),this.noReceive.SetActive(!1),this.canGet=!1,
null!=e&&null!=e.roundMap&&3==e.roundMap[this.data.id]?(this.achieve.SetActive(!0),this.receive.SetActive(!0)):t.curRound>=this.data.round&&(this.achieve.SetActive(!0),
this.noReceive.SetActive(!0),this.canGet=!0)
const i=$t.Inst_get().GetItemLisByAndReward(this.data.itemReward)
if(this.data.autoRoll>0){const t=new S.M(12007)
t.count=this.data.autoRoll,i.Insert(0,t)}if(this.data.pointReward>0){const t=new S.M(12005)
t.count=this.data.pointReward,i.Add(t)}if(this.itemLis=i,i.Count()>0){const t=i[0]
this.baseItem.EnabledClickOpenTip(!1),this.baseItem.ClickHandler_Set(this.CreateDelegate(this.ClickHandle)),this.baseItem.SetData(t),this.baseItem.SetIconSize(52,52),
this.baseItem.SetBgSize(54,54)}}ClickHandle(){
this.canGet?$t.Inst_get().SendCM_FortuneReward(this.data.id):null!=this.itemLis&&$t.Inst_get().OpenRoundRewardTipsView(`圈数达到${this.data.round}可获得以下奖励`,this.itemLis,new g.F(162*this.index-162,144),this.node.transform.GetLocalPosition())
}AddLis(){k.T.Inst_get().AddEventHandler(M.F.UPDATE_INFO,this.CreateDelegate(this.UpdateInfoHandle)),
k.T.Inst_get().AddEventHandler(M.F.UPDATE_ROUND_INFO,this.CreateDelegate(this.UpdateInfoHandle)),J.i.Get(this.itemImg.node).RegistonClick(this.CreateDelegate(this.ClickHandle)),
a.i.Inst.AddEventHandler(p.g.TabCommonOpenAniEnd,this.CreateDelegate(this.OnPanelAniEnd))}RemoveLis(){
k.T.Inst_get().RemoveEventHandler(M.F.UPDATE_INFO,this.CreateDelegate(this.UpdateInfoHandle)),
k.T.Inst_get().RemoveEventHandler(M.F.UPDATE_ROUND_INFO,this.CreateDelegate(this.UpdateInfoHandle)),J.i.Get(this.itemImg.node).RemoveonClick(this.CreateDelegate(this.ClickHandle)),
a.i.Inst.RemoveEventHandler(p.g.TabCommonOpenAniEnd,this.CreateDelegate(this.OnPanelAniEnd))}OnPanelAniEnd(){this.eff.SetActive(!0)}Clear(){this.data=null,this.baseItem.Clear(),
this.RemoveLis()}}class Dt extends It.${constructor(){super(),this.isAnim=!1,this.posDic=null,this.countDownTimer=null,this.delayTimer3=null,this.delayTimer1=null,
this.calculateId=null,this.delayTimer=null,this.diceBtnTimer=null,this.canClick=!0,this.curRound=0,this.curPos=0,this.remainTime=0,this.dateInfo=null,this.allPoint=null,
this.pointIndex=-1,this.curPoint=0,this.moveTime=300,this.curTime=0,this.intervalTime=100,this.scoreEff=null,this.goOneBtn=null,this.goTenBtn=null,this.tipBtn=null,
this.endTimeTxt=null,this.animTog=null,this.integralTxt=null,this.leftTimeTxt=null,this.addTimeBtn=null,this.rareMerchantBtn=null,this.fateDiceBtn=null,this.goExchangeBtn=null,
this.newShopItem=null,this.newShopItemTxt=null,this.rareMerchantNum=null,this.fateDiceNum=null,this.itemView=null,this.turnGrid=null,this.turnSlider=null,this.headPos=null,
this.selectPoint=null,this.turnTxt=null,this.itemIcon=null,this.itemBtn=null,this.goOneRed=null,this.goTenRed=null,this.itemIcon1=null,this.itemIcon2=null,this.goOneTxt=null,
this.goTenTxt=null,this.rollDiceAnim=null,this.mask=null,this.rareMerchantAnim=null,this.effPanel=null,this.alphaTween=null,this.posTween=null,this.getFateRollAim=null,
this.roundAnim=null,this.terminalAnim=null,this.headPosAnim=null,this.rollPointSp=null,this.firstPosEff=null,this.showItemLis=null,this.refreshId=null,this.posDic=new I.X,
this.allPoint=new _.Z}InitView(){super.InitView(),this.goOneBtn=this.CreateComponent(H.W,1),this.goTenBtn=this.CreateComponent(H.W,2),this.tipBtn=this.CreateComponent(H.W,3),
this.endTimeTxt=this.CreateComponent(Y.Q,4),this.animTog=this.CreateComponent(_t.r,5),this.integralTxt=this.CreateComponent(Y.Q,6),this.leftTimeTxt=this.CreateComponent(Y.Q,7),
this.addTimeBtn=this.CreateComponent(H.W,9),this.rareMerchantBtn=this.CreateComponent(H.W,10),this.fateDiceBtn=this.CreateComponent(H.W,11),
this.goExchangeBtn=this.CreateComponent(H.W,12),this.newShopItem=this.CreateComponent(x.z,13),this.newShopItemTxt=this.CreateComponent(Y.Q,14),
this.rareMerchantNum=this.CreateComponent(Y.Q,15),this.fateDiceNum=this.CreateComponent(Y.Q,16),this.itemView=this.CreateComponent(x.z,17),
this.turnGrid=this.CreateComponent(U.A,18),this.turnSlider=this.CreateComponent(ht.p,19),this.headPos=this.CreateComponent(ct.$,20),
this.selectPoint=this.CreateComponentBinder(vt,21),this.turnTxt=this.CreateComponent(Y.Q,22),this.itemIcon=this.CreateComponent($.w,23),this.itemBtn=this.CreateComponent(H.W,24),
this.goOneRed=this.CreateComponent(x.z,25),this.goTenRed=this.CreateComponent(x.z,26),this.itemIcon1=this.CreateComponent($.w,27),this.itemIcon2=this.CreateComponent($.w,28),
this.goOneTxt=this.CreateComponent(Y.Q,29),this.goTenTxt=this.CreateComponent(Y.Q,30),this.rollDiceAnim=this.CreateComponent(W.k,31),this.mask=this.CreateComponent($.w,32),
this.rareMerchantAnim=this.CreateComponent(W.k,33),this.effPanel=this.CreateComponent(x.z,35),this.alphaTween=this.CreateComponent(dt.R,36),
this.posTween=this.CreateComponent(ut.c,37),this.getFateRollAim=this.CreateComponent(W.k,38),this.roundAnim=this.CreateComponent(W.k,39),
this.terminalAnim=this.CreateComponent(W.k,40),this.headPosAnim=this.CreateComponent(W.k,41),this.rollPointSp=this.CreateComponent($.w,42),
this.firstPosEff=this.CreateComponent(x.z,43),this.turnGrid.SetInitInfo("ui_fortune_fateturn_item",null,wt)}SetData(){this.InitData(),this.InitPanel(),this.AddLis(),
this.UpdateShopHandle(),this.OnPanelAniEnd(),this.UpdateConfigHandle()}Clear(){this.RemoveLis(),null!=this.scoreEff&&this.scoreEff.Clear(),this.ClearItemLis(),
this.turnGrid.Clear(),this.selectPoint.Clear(),this.ClearAllTimer(!0),this.allPoint=null,super.Clear()}Destroy(){this.selectPoint.Destroy(),this.turnGrid.Destroy(),super.Destroy()}
AddLis(){this.selectPoint.AddLis(),this.m_handlerMgr.AddClickEvent(this.goOneBtn,this.CreateDelegate(this.GoOneBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.goTenBtn,this.CreateDelegate(this.GoTenBtnHandle)),this.m_handlerMgr.AddClickEvent(this.tipBtn,this.CreateDelegate(this.TipBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.animTog,this.CreateDelegate(this.AnimToggleHandle)),
this.m_handlerMgr.AddClickEvent(this.addTimeBtn,this.CreateDelegate(this.AddTimeBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.rareMerchantBtn,this.CreateDelegate(this.OnRareMerchantBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.fateDiceBtn,this.CreateDelegate(this.OnFateDiceBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.goExchangeBtn,this.CreateDelegate(this.GoExchangeBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.itemBtn,this.CreateDelegate(this.ItemBtnHandle)),k.T.Inst_get().AddEventHandler(M.F.UPDATE_INFO,this.CreateDelegate(this.UpdateInfoHandle)),
k.T.Inst_get().AddEventHandler(M.F.UPDATE_SHOP,this.CreateDelegate(this.UpdateShopHandle)),
k.T.Inst_get().AddEventHandler(M.F.UPDATE_BOX,this.CreateDelegate(this.UpdateAllBoxItem)),
k.T.Inst_get().AddEventHandler(M.F.ROLL_SUCCESS,this.CreateDelegate(this.RollSuccessHandle)),
k.T.Inst_get().AddEventHandler(M.F.FORTUNE_CONFIG,this.CreateDelegate(this.UpdateConfigHandle)),
k.T.Inst_get().AddEventHandler(M.F.GET_FATE_ROLL,this.CreateDelegate(this.GetFateRollHandle)),
a.i.Inst.AddEventHandler(p.g.TabCommonOpenAniEnd,this.CreateDelegate(this.OnPanelAniEnd)),this.m_handlerMgr.AddEventMgr(p.g.BAG_UPDATE,this.CreateDelegate(this.RefreshDicNum)),
this.m_handlerMgr.AddEventMgr(p.g.HUODONG_INFO_CHANGE,this.CreateDelegate(this.ActivityInfoChangeHandle))}RemoveLis(){
k.T.Inst_get().RemoveEventHandler(M.F.UPDATE_INFO,this.CreateDelegate(this.UpdateInfoHandle)),
k.T.Inst_get().RemoveEventHandler(M.F.UPDATE_SHOP,this.CreateDelegate(this.UpdateShopHandle)),
k.T.Inst_get().RemoveEventHandler(M.F.UPDATE_BOX,this.CreateDelegate(this.UpdateAllBoxItem)),
k.T.Inst_get().RemoveEventHandler(M.F.ROLL_SUCCESS,this.CreateDelegate(this.RollSuccessHandle)),
k.T.Inst_get().RemoveEventHandler(M.F.FORTUNE_CONFIG,this.CreateDelegate(this.UpdateConfigHandle)),
k.T.Inst_get().RemoveEventHandler(M.F.GET_FATE_ROLL,this.CreateDelegate(this.GetFateRollHandle)),
a.i.Inst.RemoveEventHandler(p.g.TabCommonOpenAniEnd,this.CreateDelegate(this.OnPanelAniEnd))}ActivityInfoChangeHandle(){
P.i.ins.GetState(k.T.Inst_get().GetActivityId())==N.V.END&&(this.UpdateShopHandle(),this.fateDiceNum.node.SetActive(!1))}GetFateRollHandle(){this.PlayAnim(this.getFateRollAim,!1)}
UpdateConfigHandle(){this.isAnim?this.JumpAnimHandle():(this.RefreshEndTime(),this.UpdateInfoHandle(),this.UpdateAllBoxItem())}OnPanelAniEnd(){
if(k.T.Inst_get().isEnd&&(a.i.Inst.RemoveEventHandler(p.g.TabCommonOpenAniEnd,this.CreateDelegate(this.OnPanelAniEnd)),this.headPos.node.SetActive(!0),k.T.Inst_get().isFirstRoll)){
this.firstPosEff.SetActive(!0)
const t=this.GetPos(0)
this.firstPosEff.transform.SetLocalPosition(t)}}JumpAnimHandle(){null!=k.T.Inst_get().info&&(this.curPos=k.T.Inst_get().info.curPos),k.T.Inst_get().isPlaying=!1,this.EndAnim(),
this.ClearAllTimer(),this.UpdateInfoHandle(),this.UpdateAllBoxItem(),this.KeepLastBox()}RollSuccessHandle(){k.T.Inst_get().isPlaying=!1,this.StartAnim(),this.KeepLastBox()}
RefreshDicNum(){this.leftTimeTxt.textSet(k.T.Inst_get().GetDiceItemNum()),this.RefreshBtnState()}UpdateInfoHandle(){const t=k.T.Inst_get().info
null!=t&&(this.integralTxt.textSet(`积分      :${t.point}`),this.RefreshDicNum(),this.fateDiceNum.textSet(t.specialRollRemain),this.animTog.SetValue(t.isIgnore),
t.specialRollRemain>0&&!k.T.Inst_get().IsActivityEnd()?this.fateDiceNum.node.SetActive(!0):this.fateDiceNum.node.SetActive(!1),
this.headPos.node.transform.SetLocalPosition(this.GetPos(t.curPos)),this.curPos=t.curPos,k.T.Inst_get().isPlaying?this.FirstRollHandle():this.RefreshRoundReward(),
this.RefreshBtnState())}FirstRollHandle(){null!=k.T.Inst_get().info&&k.T.Inst_get().isFirstRoll&&(k.T.Inst_get().RaiseEvent(M.F.FIRST_ROLL),k.T.Inst_get().isFirstRoll=!1,
this.firstPosEff.SetActive(!1))}UpdateShopHandle(){const t=k.T.Inst_get().shopVoLis
null!=t&&(t.Count()>0?(this.rareMerchantNum.textSet(t.Count()),this.rareMerchantNum.node.SetActive(!k.T.Inst_get().IsActivityEnd()),
this.newShopItem.SetActive(!0)):(this.rareMerchantNum.node.SetActive(!1),this.newShopItem.SetActive(!1)))}TipBtnHandle(){const t=new St.w
t.infoId="TREASUREBOX:TIPS",t.width=384,t.position=new z.P(-462,292,0),pt.Q.Inst_get().Open(t)}ItemBtnHandle(){const t=new S.M(k.T.Inst_get().GetDiceItemId())
t.btnType=Ct.p.GetWay,$t.Inst_get().OpenTipView(t)}AnimToggleHandle(){$t.Inst_get().SendCM_FortuneIgnore(this.animTog.GetValue()),this.animTog.GetValue()&&this.JumpAnimHandle()}
GoOneBtnHandle(){null!=k.T.Inst_get().info&&(this.canClick?(this.StartDiceCountDown(),$t.Inst_get().GoHandle(!1)):B.y.inst.ClientSysMessage(11041134))}GoTenBtnHandle(){
null!=k.T.Inst_get().info&&(this.canClick?(this.StartDiceCountDown(),$t.Inst_get().GoHandle(!0)):B.y.inst.ClientSysMessage(11041134))}AddTimeBtnHandle(){
const t=k.T.Inst_get().GetDiceItemId()
Q._.Inst_get().OpenByItem(t,z.P.zero_get(),null,!0)}GoExchangeBtnHandle(){$t.Inst_get().OpenView(Tt.F.INTEGRAL_EXCHANGE_VIEW)}OnRareMerchantBtnHandle(){
$t.Inst_get().OpenView(Tt.F.FORTUNE_LIMIT_VIEW)}OnFateDiceBtnHandle(){
null!=k.T.Inst_get().info&&k.T.Inst_get().info.specialRollRemain>=1?this.selectPoint.UpdateView():B.y.inst.ClientSysMessage(11041125)}InitPanel(){
const t=At.f.Inst().getItemById(k.T.Inst_get().GetDiceItemId())
null!=t&&(r.g.SetItemIcon(this.itemIcon.FatherId,this.itemIcon.ComponentId,t.icon,gt.b.eItem,!1),
r.g.SetItemIcon(this.itemIcon1.FatherId,this.itemIcon1.ComponentId,t.icon,gt.b.eItem,!1),r.g.SetItemIcon(this.itemIcon2.FatherId,this.itemIcon2.ComponentId,t.icon,gt.b.eItem,!1)),
this.headPos.node.SetActive(!1),this.rareMerchantAnim.node.SetActive(!1),this.alphaTween.node.SetActive(!1),this.rollDiceAnim.node.SetActive(!1),
this.rollPointSp.node.SetActive(!0),this.selectPoint.node.SetActive(!1),this.mask.node.SetActive(!1),this.getFateRollAim.node.SetActive(!1),this.roundAnim.node.SetActive(!1),
this.terminalAnim.node.SetActive(!1),this.headPosAnim.node.SetActive(!1),this.firstPosEff.SetActive(!1),this.PlayAnim(this.headPosAnim,!0)
const e=mt.O.GetUIWidth()
this.mask.widthSet(e)}InitData(){null==this.showItemLis?this.showItemLis=new _.Z:this.showItemLis.Clear(),this.isAnim=!1,this.countDownTimer=null,this.calculateId=null,
this.canClick=!0,this.allPoint=null,k.T.Inst_get().isPlaying=!1}RefreshRoundReward(t){if(0==k.T.Inst_get().GetWorldLevel())return
if(null==t){t=k.T.Inst_get().info.curRound}const e=k.T.Inst_get().GetRoundLis()
this.turnGrid.data_set(e)
const i=106.5
let s=0
for(let n=0;n<=e.Count()-1;n++){const a=e[n]
if(!(t>=a.round)){if(0==n)s+=t/a.round*i
else{const o=a.round-e[n-1].round
s+=(t-e[n-1].round)/o*i}break}s=s+i+54}s/=588,this.turnSlider.DoF_SetValue(s,1),this.curRound=t,this.turnTxt.textSet(t)}RefreshBtnState(){
const t=P.i.ins.huodong_dict.LuaDic_GetItem(k.T.Inst_get().GetActivityId())
let e=0
null!=t&&(e=.001*t.endTime.ToNum()-rt.D.serverTime_get()),this.goOneBtn.node.SetActive(!1),this.goTenBtn.node.SetActive(!1),this.goExchangeBtn.node.SetActive(!1),
e<=0?this.goExchangeBtn.node.SetActive(!0):(this.goOneBtn.node.SetActive(!0),this.goTenBtn.node.SetActive(!0)),
e>0&&(null!=k.T.Inst_get().info&&k.T.Inst_get().GetDiceItemNum()>=1?(this.goOneRed.SetActive(!0),this.goOneTxt.textSet("[6D5331]投一次(     1)[-]")):(this.goOneRed.SetActive(!1),
this.goOneTxt.textSet("[6D5331]投一次(     [FF4B58]1[-])[-]")),k.T.Inst_get().GetDiceItemNum()>=10?(this.goTenRed.SetActive(!0),
this.goTenTxt.textSet("[E9D595]投十次(     10)[-]")):(this.goTenRed.SetActive(!1),this.goTenTxt.textSet("[E9D595]投十次(     [FF4B58]10[-])[-]")))}UpdateAllBoxItem(){
if(null!=k.T.Inst_get().boxShowVo&&!k.T.Inst_get().isPlaying)for(let t=0;t<=2*Dt.ROW_NUM+2*Dt.COLUMN_NUM-5;t++)this.UpdateBoxItem(t)}UpdateBoxItem(t,e){if(null==t&&(t=this.curPos),
null!=k.T.Inst_get().boxShowVo){const i=k.T.Inst_get().boxShowVo.showMap
if(null!=i){let s=null
this.showItemLis.Count()<=t?(s=this.GetShowItem(),this.showItemLis.Add(s)):s=this.showItemLis[t],null==e&&(e=i[t])
const n=k.T.Inst_get().GetBoxResById(e),a=this.GetPos(t)
s.node.transform.SetLocalPosition(a),s.SetData(n,t)}}}KeepLastBox(){if(null!=k.T.Inst_get().beforeBoxShowVo){
const t=this.showItemLis[this.curPos],e=k.T.Inst_get().beforeBoxShowVo.showMap[this.curPos],i=k.T.Inst_get().GetBoxResById(e)
t.SetData(i,this.curPos)}}GetShowItem(){let t=null
const e=r.g.GetResFindId("ui_fortune_fatebox_item")
return t=new Rt,t.setPrefabRootId(e),t.node.transform.SetParent(this.itemView.FatherId,this.itemView.ComponentId),this.m_handlerMgr.AddClearComponent(t,!1,!1),t}ClearItemLis(){
for(let t=0;t<=this.showItemLis.Count()-1;t++){const e=this.showItemLis[t]
null!=e&&(e.Clear(),r.g.DestroyView(e))}this.showItemLis.Clear()}RefreshEndTime(){this.dateInfo=P.i.ins.huodong_dict.LuaDic_GetItem(k.T.Inst_get().GetActivityId()),
null!=this.dateInfo&&null!=this.dateInfo.endTime&&this.dateInfo.endTime.ToNum()>0?(this.remainTime=.001*this.dateInfo.endTime.ToNum()-rt.D.serverTime_get(),
this.remainTime>0?(this.ClearEndTimeHandle(),
this.EndTimeCountDown(),null==this.countDownTimer&&(this.countDownTimer=X.C.Inst_get().SetInterval(this.CreateDelegate(this.EndTimeCountDown),1e3,-1))):this.ActivityEndTime()):this.ActivityEndTime()
}ActivityEndTime(){const t=ft.x.Inst().getItemStrById(11041137)
this.ClearEndTimeHandle(),this.endTimeTxt.textSet(t)}EndTimeCountDown(){if(this.dateInfo=P.i.ins.huodong_dict.LuaDic_GetItem(k.T.Inst_get().GetActivityId()),
null!=this.dateInfo&&null!=this.dateInfo.endTime&&this.dateInfo.endTime.ToNum()>0)if(this.remainTime=.001*this.dateInfo.endTime.ToNum()-rt.D.serverTime_get(),this.remainTime>0){
let t=ft.x.Inst().getItemStrById(2310004)
t+=A.l.GetDateFormatBitContainZero(this.remainTime,4),this.endTimeTxt.textSet(`结束倒计时:[047104]${t}[-]`)}else this.RefreshBtnState(),this.ActivityEndTime()
else this.ActivityEndTime()}ClearEndTimeHandle(){null!=this.countDownTimer&&(X.C.Inst_get().ClearInterval(this.countDownTimer),this.countDownTimer=null)}StartAnim(){
const t=k.T.Inst_get().rollResult
if(null!=t)if(null!=k.T.Inst_get().info&&k.T.Inst_get().info.isIgnore){if(null!=t&&null!=t.resourceIds&&t.resourceIds.Count()>0){let e=!0
if(1==t.resourceIds.Count()){const i=t.resourceIds[0],s=k.T.Inst_get().GetBoxResById(i)
null!=s&&3==s.boxType&&(e=!1)}e?$t.Inst_get().OpenFateResultView():this.PlayAnim(this.rareMerchantAnim)}
}else null!=$t.Inst_get().fateResultPanel&&$t.Inst_get().fateResultPanel.isShow_get()?$t.Inst_get().OpenFateResultView():(this.ClearAllTimer(),this.mask.node.SetActive(!0),
this.allPoint=new _.Z,this.allPoint.AddRange(t.rollNums),this.pointIndex=-1,this.SetBeforePos(),this.headPos.node.SetLocalPosition(this.GetPos(this.curPos)),this.isAnim=!0,
this.SetRefreshIdx(),this.PlayRollDiceAnim())}SetBeforePos(){this.curPos=k.T.Inst_get().info.curPos
for(let t=0;t<=this.allPoint.Count()-1;t++)this.curPos-=this.allPoint[t]
this.curPos=Math.abs(this.curPos%24)}EndAnim(){if(this.mask.node.SetActive(!1),this.isAnim=!1,this.ClearCalculatePoint(),null!=this.allPoint){const t=k.T.Inst_get().rollResult
if(null!=k.T.Inst_get().info&&null!=t&&null!=t.resourceIds&&t.resourceIds.Count()>0){let e=!0
if(1==t.resourceIds.Count()){const i=t.resourceIds[0],s=k.T.Inst_get().GetBoxResById(i)
null!=s&&3==s.boxType&&(e=!1)}e&&$t.Inst_get().OpenFateResultView()}}this.allPoint=null}PlayMoveAnim(){this.curPoint=0,this.moveTime=300,this.curTime=0,this.intervalTime=100,
this.calculateId=X.C.Inst_get().SetInterval(this.CreateDelegate(this.CalculatePoint),this.intervalTime,-1)}CalculatePoint(){this.curTime+=this.intervalTime,
this.curTime>=this.moveTime&&(this.StartMove(),this.curTime=0,this.curPoint+=1),this.curPoint>=this.allPoint[this.pointIndex]&&(this.ClearCalculatePoint(),
this.PlayAnim(this.terminalAnim),this.TerminalBoxHandle(),this.ClearDelayTimer3(),this.delayTimer3=X.C.Inst_get().SetInterval(this.CreateDelegate(this.Delay3Handle),500,1))}
ClearDelayTimer3(){null!=this.delayTimer3&&(X.C.Inst_get().ClearInterval(this.delayTimer3),this.delayTimer3=null)}Delay3Handle(){
this.pointIndex<this.allPoint.Count()-1?this.PlayRollDiceAnim():this.EndAnim()}ClearCalculatePoint(){null!=this.calculateId&&(X.C.Inst_get().ClearInterval(this.calculateId),
this.calculateId=null)}ClearDelayTimer1(){null!=this.delayTimer1&&(X.C.Inst_get().ClearInterval(this.delayTimer1),this.delayTimer1=null)}PlayRollDiceAnim(){
this.PlayAnim(this.rollDiceAnim),this.rollPointSp.node.SetActive(!1),this.ClearDelayTimer1(),
this.delayTimer1=X.C.Inst_get().SetInterval(this.CreateDelegate(this.RollTerminal),500,1)
let t=null;-1!=this.pointIndex&&null!=k.T.Inst_get().rollResult&&null!=k.T.Inst_get().rollResult.resourceIds&&null!=this.refreshId&&(t=this.refreshId[this.pointIndex+1]),
this.UpdateBoxItem(null,t)}SetRefreshIdx(){this.refreshId=new _.Z
const t=new _.Z
let e=k.T.Inst_get().info.curPos
const i=k.T.Inst_get().rollResult.rollNums,s=new _.Z
s.Add(e)
for(let t=i.Count()-1;t>=0;t+=-1)e-=i[t],e=Math.abs(e%24),s.Add(e)
if(s.Reverse(),null!=k.T.Inst_get().boxShowVo&&null!=k.T.Inst_get().boxShowVo.showMap&&null!=k.T.Inst_get().rollResult&&null!=k.T.Inst_get().rollResult.resourceIds){
const e=k.T.Inst_get().rollResult.resourceIds
for(let i=0;i<=s.Count()-1;i++){const n=s[i]
let a=null
if(i>0)for(let t=i+1;t<=s.Count()-1;t++){if(s[t]==n){a=t
break}}null==a?this.refreshId.Add(k.T.Inst_get().boxShowVo.showMap[n]):this.refreshId.Add(e[a-1]),t.Add(k.T.Inst_get().boxShowVo.showMap[n])}}else B.y.inst.ClientSysStrMsg("出错")
let n=""
for(let t=0;t<=this.refreshId.Count()-1;t++)n+=` ${this.refreshId[t]}`}RollDiceAnimEnd(){this.pointIndex+=1,this.ClearCalculatePoint(),
this.delayTimer=X.C.Inst_get().SetInterval(this.CreateDelegate(this.GoNext),500,1)}GoNext(){this.pointIndex<=this.allPoint.Count()-1&&this.isAnim?this.PlayMoveAnim():this.EndAnim()
}RollTerminal(){this.pointIndex<=this.allPoint.Count()-1&&(this.rollPointSp.spriteNameSet(`ryzhenbaoge_sp_000${this.allPoint[this.pointIndex+1]}`),
this.rollPointSp.node.SetActive(!0),this.rollDiceAnim.node.SetActive(!1),this.RollDiceAnimEnd())}ClearDelayTimer(){
null!=this.delayTimer&&(X.C.Inst_get().ClearInterval(this.delayTimer),this.delayTimer=null)}StartMove(){0==this.curPos&&this.FirstRollHandle(),this.curPos+=1,this.curPos%=24,
this.headPos.node.SetLocalPosition(this.GetPos(this.curPos)),0==this.curPos&&(this.PlayAnim(this.roundAnim),this.RefreshRoundReward(this.curRound+1))}TerminalBoxHandle(){
const t=k.T.Inst_get().rollResult
if(null!=t&&null!=t.resourceIds&&t.resourceIds.Count()>this.pointIndex){const e=t.resourceIds[this.pointIndex],i=k.T.Inst_get().GetBoxResById(e)
if(null!=i){if(1==i.boxType){const t=$t.Inst_get().GetItemLisByAndReward(i.itemReward)
for(let e=0;e<=t.Count()-1;e++){const i=t[e],s=i.GetItemNameStr(),n=i.count,a=i.modelId_get()
B.y.inst.ClientSysStrMsg(`获得>${s}*${n}&${a}`)}}else 2==i.boxType?B.y.inst.ClientSysStrMsg(`获得${i.pointReward}命运积分`):3==i.boxType&&this.PlayAnim(this.rareMerchantAnim)
1==i.bestPrize&&k.T.Inst_get().RaiseEvent(M.F.BEST_PRICE_UPDATE)}}}PlayScoreAnim(){null==this.scoreEff&&(this.scoreEff=new yt.V,
this.scoreEff.SetLocalPosition(this.node.transform.GetLocalPosition().Add(z.P.zero_get())))
this.scoreEff.SetActive(!1),this.scoreEff.SetActive(!0),this.scoreEff.CreateByName("pre_eff_bag_wear_suc_01",this.effPanel,null,null,this.effPanel)}ClearAllTimer(t){
this.ClearDelayTimer(),this.ClearDiceCountDown(),this.ClearCalculatePoint(),this.ClearDelayTimer1(),this.ClearDelayTimer3(),t&&this.ClearEndTimeHandle()}StartDiceCountDown(){
this.ClearDiceCountDown(),this.canClick=!1,this.diceBtnTimer=X.C.Inst_get().SetInterval(this.CreateDelegate(this.RollBtnCountDownEnd),500,1)}RollBtnCountDownEnd(){this.canClick=!0}
ClearDiceCountDown(){this.canClick=!0,null!=this.diceBtnTimer&&(X.C.Inst_get().ClearInterval(this.diceBtnTimer),this.diceBtnTimer=null)}PlayAnim(t,e){null==e&&(e=!1),
null!=t&&(t.node.SetActive(!0),t.SetResetOnPlay(!0),t.ResumeAnim(),t.Play(!0,!1),t.SetLoopEnable(e))}GetPos(t){if(23==t?t=0:t+=1,
t<0&&t>=2*Dt.ROW_NUM+2*Dt.COLUMN_NUM-4)return z.P.zero_get()
if(null!=this.posDic[t])return this.posDic[t]
let e=t%Dt.COLUMN_NUM*(Dt.ITEM_SIZE+Dt.SPACE),i=0
t<Dt.ROW_NUM?(e=t%Dt.ROW_NUM*(Dt.ITEM_SIZE+Dt.SPACE),i=0):t<Dt.ROW_NUM+Dt.COLUMN_NUM-1?(e=(Dt.ROW_NUM-1)*(Dt.ITEM_SIZE+Dt.SPACE)+Dt.XVEC[t-Dt.ROW_NUM+1],
i=-Dt.YVEC[t-Dt.ROW_NUM+1]):t<2*Dt.ROW_NUM+Dt.COLUMN_NUM-2?(e=(2*Dt.ROW_NUM+Dt.COLUMN_NUM-3-t)*(Dt.ITEM_SIZE+Dt.SPACE),
i=-Dt.YVEC[Dt.COLUMN_NUM-1]):(e=-Dt.XVEC[2*Dt.ROW_NUM+2*Dt.COLUMN_NUM-4-t],i=-Dt.YVEC[2*Dt.ROW_NUM+2*Dt.COLUMN_NUM-4-t])
const s=new z.P(e,i,0)
return this.posDic.LuaDic_AddOrSetItem(t,s),this.posDic[t]}}Dt.ITEM_SIZE=74,Dt.SPACE=30,Dt.ROW_NUM=9,Dt.COLUMN_NUM=5,Dt.YVEC=[53,155,257,310],Dt.XVEC=[104,126,104,0]
var Et=i(13113),Lt=i(35128),Gt=i(86133),Ot=i(62370),bt=i(30267),Bt=i(86209),Nt=i(75582),Pt=i(7601),Mt=i(52513),Vt=i(31896),kt=i(19519)
class xt extends j.x{constructor(...t){super(...t),this.huodongMallVo=null,this.huodongMallCfgVo=null,this.text_limit_time=null,this.text_name=null,this.img_discount=null,
this.btn_buy=null,this.text_buy=null,this.grid_item=null,this.consume_obj=null,this.img_consume_icon=null,this.text_consume_num=null,this.img_sell_over=null,
this.refreshTimeTxt=null,this.discountLabel=null,this.countDownId=null}InitView(){super.InitView(),this.text_limit_time=this.CreateComponent(Y.Q,1),
this.text_name=this.CreateComponent(Y.Q,2),this.img_discount=this.CreateComponent($.w,3),this.btn_buy=this.CreateComponent($.w,4),this.text_buy=this.CreateComponent(Y.Q,5),
this.grid_item=this.CreateComponent(U.A,6),this.consume_obj=this.CreateComponent(bt.V,7),this.img_consume_icon=this.CreateComponent($.w,8),
this.text_consume_num=this.CreateComponent(Y.Q,9),this.img_sell_over=this.CreateComponent($.w,10),this.refreshTimeTxt=this.CreateComponent(Y.Q,11),
this.discountLabel=this.CreateComponent(Y.Q,12),this.grid_item.SetInitInfo("ui_baseitem",this.CreateDelegate(this.OnInitItem))}OnInitItem(t){const e=new q.j
return e.setId(t,null,0),e.SetBgSize(60,60),e.SetIconSize(60,60),e}SetData(t){this.huodongMallVo=t,this.huodongMallCfgVo=Nt.Z.ins.GetVoByMallId(this.huodongMallVo.mallId),
this.AddLis(),this.Update()}AddLis(){this.m_handlerMgr.AddClickEvent(this.btn_buy,this.CreateDelegate(this.OnClickBtnBuy)),
this.m_handlerMgr.AddEventMgr(p.g.HUODONG_MALL_BUY_CNT_CHANGE,this.CreateDelegate(this.OnBuyCntChange))}RemoveLis(){}Clear(){super.Clear(),this.grid_item.Clear(),this.RemoveLis()}
Destroy(){this.grid_item.Destroy(),super.Destroy()}Update(){this.img_sell_over.SetActive(!1),this.img_discount.node.SetActive(!1),this.refreshTimeTxt.node.SetActive(!1),
this.img_consume_icon.SetActive(!1),-1==this.huodongMallVo.limit?this.text_limit_time.SetActive(!1):(this.text_limit_time.SetActive(!0),this.text_limit_time.textSet(Ot.o.Format((0,
Gt.T)("限购{0}次"),this.huodongMallVo.limit))),this.text_name.textSet(this.huodongMallCfgVo.name)
const t=new _.Z
for(let e=0;e<=this.huodongMallVo.reward.rewards.Count()-1;e++)t.Add(S.M.wrapReward(this.huodongMallVo.reward.rewards[e]))
this.grid_item.data_set(t),this.discountLabel.node.SetActive(!1),this.img_discount.node.SetActive(!0),
1==this.huodongMallCfgVo.label?this.img_discount.spriteNameSet("ryjbsd_sp_0012"):2==this.huodongMallCfgVo.label?(this.discountLabel.node.SetActive(!0),
this.img_discount.spriteNameSet("ryjbsd_sp_0027"),
this.discountLabel.textSet(`${this.huodongMallCfgVo.discount}%`)):3==this.huodongMallCfgVo.label?this.img_discount.spriteNameSet("ryjbsd_sp_0011"):this.img_discount.node.SetActive(!1),
this.img_discount.MakePixelPerfect(),
this.btn_buy.SetActive(!0),-1!=this.huodongMallVo.limit&&G.P.ins.GetBuyTimesByMallId(this.huodongMallVo.mallId)>=this.huodongMallVo.limit?(this.btn_buy.spriteNameSet("rycommon_bt_0026"),
this.text_consume_num.textSet("[4E443B]已领取[-]"),k.T.Inst_get().IsCanRefresh(this.huodongMallVo.nextRefreshTime)?(this.text_limit_time.SetActive(!1),
P.i.ins.GetState(k.T.Inst_get().GetActivityId())==N.V.OPEN?this.StartCountDown():this.text_consume_num.textSet("[4E443B]已结束[-]")):(this.btn_buy.SetActive(!1),
this.img_sell_over.SetActive(!0))):(this.img_sell_over.SetActive(!1),P.i.ins.GetState(k.T.Inst_get().GetActivityId())==N.V.OPEN?(this.img_consume_icon.SetActive(!0),
this.btn_buy.spriteNameSet("rycommon_bt_0024"),this.UpdateConsume()):(this.btn_buy.spriteNameSet("rycommon_bt_0026"),this.text_consume_num.textSet("[4E443B]已结束[-]")))}
UpdateConsume(){if(this.text_consume_num.SetActive(!0),this.img_consume_icon.SetActive(!0),0!=this.huodongMallVo.rechargeId){
const t=Mt.O.Inst().getConfig(this.huodongMallVo.rechargeId),e=Pt.W.Inst.GetCurSystem(),i=t.platformCurrency[e]
this.text_consume_num.textSet(`${i}元`),this.img_consume_icon.SetActive(!1)}else{const t=this.huodongMallVo.Consume_Get().GetItemDataByType()
this.text_consume_num.textSet(Bt.w.Instance.ConvertNumToString(t.count)),null!=t.virtualItemData_get()?this.img_consume_icon.spriteNameSet(kt.J.GetCurrencyIconUrl(t.virtualItemData_get().virtualTypeStr)):this.img_consume_icon.spriteNameSet("")
}this.refreshTimeTxt.node.SetActive(!1),this.consume_obj.CallReposition()}OnClickBtnBuy(){
-1!=this.huodongMallVo.limit&&G.P.ins.GetBuyTimesByMallId(this.huodongMallVo.mallId)>=this.huodongMallVo.limit||(P.i.ins.GetState(k.T.Inst_get().GetActivityId())==N.V.OPEN?0!=this.huodongMallCfgVo.rechargeId?Vt.t.inst.Buy(Mt.O.Inst().getConfig(this.huodongMallVo.rechargeId)):E.$.ins.CheckConsumeEnough(this.huodongMallVo.Consume_Get())&&E.$.ins.CM_ActivityMallBuy(this.huodongMallVo.mallId):B.y.inst.ClientSysStrMsg("活动已结束"))
}OnBuyCntChange(t){t==this.huodongMallVo.mallId&&this.Update()}StartCountDown(){this.ClearCountDown(),this.refreshTimeTxt.node.SetActive(!0),
this.countDownId=X.C.Inst_get().SetInterval(this.CreateDelegate(this.RefreshTime),1e3,-1),this.RefreshTime()}ClearCountDown(){this.refreshTimeTxt.node.SetActive(!1),
null!=this.countDownId&&(X.C.Inst_get().ClearInterval(this.countDownId),this.countDownId=null)}RefreshTime(){
if(null!=this.huodongMallVo.nextRefreshTime&&this.huodongMallVo.nextRefreshTime.ToNum()>0){const t=this.huodongMallVo.nextRefreshTime.ToNum()-rt.D.serverTime_get()
if(t>0){const e=A.l.GetDateFormatEX(t,!0,!0)
this.refreshTimeTxt.textSet(e)}else this.refreshTimeTxt.node.SetActive(!1)}
P.i.ins.GetState(k.T.Inst_get().GetActivityId())!=N.V.END&&P.i.ins.GetState(k.T.Inst_get().GetActivityId())!=N.V.CLOSE||(this.ClearCountDown(),this.Update())}}
class Ht extends It.${constructor(...t){super(...t),this.grid_item=null,this.left=null,this.right=null,this.interval=null,this.text_time=null}InitView(){super.InitView(),
this.grid_item=this.CreateComponent(U.A,1),this.left=this.CreateComponent(Et.T,2),this.right=this.CreateComponent(Et.T,3),mt.O.SetAnchorPos(this.left,!0,!0,0),
mt.O.SetAnchorPos(this.right,!1,!0,0),this.grid_item.SetInitInfo("ui_fortunelimit_item",null,xt)}SetData(){
k.T.Inst_get().IsClickLimitBuy()||k.T.Inst_get().IsRedFortuneLimit()&&$t.Inst_get().ClickLimitBuy(),
this.m_handlerMgr.AddEventMgr(p.g.HUODONG_MALL_CHANGE,this.CreateDelegate(this.UpdateView)),this.UpdateView()}AddLis(){}RemoveLis(){}Clear(){super.Clear(),
null!=this.interval&&(X.C.Inst_get().ClearInterval(this.interval),this.interval=null)}Destroy(){super.Destroy()}UpdateView(){
const t=G.P.ins.GetMallListByHuoDongId(k.T.Inst_get().GetActivityId()),e=new _.Z
for(let i=0;i<=t.Count()-1;i++){const s=t[i]
t[i].CheckView()&&t[i].CheckBuy()&&s.type==L.f.RECHARGE_TYPE&&e.Add(t[i])}this.grid_item.data_set(e)}OnEachSec(){
const t=P.i.ins.huodong_dict.LuaDic_GetItem(k.T.Inst_get().GetActivityId())
if(null!=t){const e=Lt.p.FloorToInt(t.endTime.ToNum()/1e3)-rt.D.serverTime_get()
e>0?this.text_time.textSet(`[b09979]结束倒计时:[-] [5fb470]${A.l.GetDateFormatEX(e,!0,!0)}[-]`):this.text_time.textSet("[b09979]已结束[-]")}else this.text_time.textSet("")}}
var Ut=i(68042),Ft=i(91280)
class Yt extends j.x{constructor(...t){super(...t),this.limitTipLabel=null,this.nameLabel=null,this.costLabel=null,this.costIcon=null,this.buyBtn=null,this.costContainer=null,
this.ui_baseitem=null,this.grid=null,this.limitGo=null,this.buyBtnGrey=null,this.data=null,this.exchangeTime=null}InitView(){super.InitView(),
this.limitTipLabel=this.CreateComponent(Y.Q,1),this.nameLabel=this.CreateComponent(Y.Q,2),this.costLabel=this.CreateComponent(Y.Q,3),this.costIcon=this.CreateComponent($.w,4),
this.buyBtn=this.CreateComponent(H.W,5),this.costContainer=this.CreateComponent(Et.T,6),this.ui_baseitem=this.CreateComponentBinder(q.j,7),this.grid=this.CreateComponent(bt.V,8),
this.limitGo=this.CreateComponent(x.z,9),this.buyBtnGrey=this.CreateComponent(x.z,10)}Destroy(){this.ui_baseitem.Destroy()}SetData(t){this.data=t
const e=$t.Inst_get().GetItemLisByAndReward(t.reward)
if(null!=e&&e.Count()>0){const t=e[0],i=t.cfgData_get(),s=A.l.getColorStrByQuality(t.Quality_get())
this.nameLabel.textSet(`[${s}]${i.name}[-]`),this.ui_baseitem.SetData(t)}this.AddLis(),this.RefreshInfo()}RefreshInfo(){
this.exchangeTime=k.T.Inst_get().GetExchangeTimeById(this.data.id)
const t=this.data.maxNum
let e=`${this.exchangeTime}/${t}`
e=this.exchangeTime>=t?`[ff0000]${e}[-]`:`[ffffff]${e}[-]`,this.limitTipLabel.textSet(`兑换上限${e}`),
-1==this.data.maxNum?this.limitTipLabel.node.SetActive(!1):this.limitTipLabel.node.SetActive(!0),this.limitGo.SetActive(!1),this.buyBtn.node.SetActive(!1),
this.buyBtnGrey.SetActive(!1)
let i=this.data.consume
const s=k.T.Inst_get().info.point
this.exchangeTime>=t&&-1!=t?(this.limitGo.SetActive(!0),i=`[ffffff]${i}[-]`,this.buyBtnGrey.SetActive(!0)):(this.buyBtn.node.SetActive(!0),
i=s>=this.data.consume?`[ffffff]${i}[-]`:`[ff0000]${i}[-]`),this.costLabel.textSet(i),this.grid.Reposition()}AddLis(){
k.T.Inst_get().AddEventHandler(M.F.UPDATE_EXCHANGE,this.CreateDelegate(this.RefreshInfo)),k.T.Inst_get().AddEventHandler(M.F.UPDATE_INFO,this.CreateDelegate(this.RefreshInfo)),
J.i.Get(this.buyBtn.node).RegistonClick(this.CreateDelegate(this.BuyBtnHandle))}RemoveLis(){
k.T.Inst_get().RemoveEventHandler(M.F.UPDATE_EXCHANGE,this.CreateDelegate(this.RefreshInfo)),
k.T.Inst_get().RemoveEventHandler(M.F.UPDATE_INFO,this.CreateDelegate(this.RefreshInfo)),J.i.Get(this.buyBtn.node).RemoveonClick(this.CreateDelegate(this.BuyBtnHandle)),
a.i.Inst.RemoveEventHandler(p.g.TipsLoadCompelete,this.CreateDelegate(this.OpenBuyTipView))}BuyBtnHandle(){const t=k.T.Inst_get().info.point
let e=0
null!=this.data&&null!=this.data.consume&&(e=this.data.consume),this.data.consume<=t?(a.i.Inst.AddEventHandler(p.g.TipsLoadCompelete,this.CreateDelegate(this.OpenBuyTipView)),
this.ui_baseitem.OpenTipView()):B.y.inst.ClientSysStrMsg("积分不足")}OpenBuyTipView(){a.i.Inst.RemoveEventHandler(p.g.TipsLoadCompelete,this.CreateDelegate(this.OpenBuyTipView))
const t=new Ft.v
let e=this.data.maxNum-this.exchangeTime;-1==this.data.maxNum&&(e=-1),t.InitCurrencyData(kt.J.FORTUNE_POINT,this.data.consume,e,1,"购买数量",this.CreateDelegate(this.BuyHandle)),
Ut.o.Inst_get().OpenView(t)}BuyHandle(t){$t.Inst_get().SendCM_FortunePoint(this.data.id,t)}Clear(){this.data=null,this.ui_baseitem.Clear(),this.RemoveLis()}}class Kt extends It.${
constructor(...t){super(...t),this.grid=null,this.tipBtn=null,this.endTimeTxt=null,this.score=null,this.countDownTimer=null,this.exchangeLis=null}InitView(){super.InitView(),
this.grid=this.CreateComponent(U.A,1),this.tipBtn=this.CreateComponent(H.W,2),this.endTimeTxt=this.CreateComponent(Y.Q,3),this.score=this.CreateComponent(Y.Q,4),
this.grid.SetInitInfo("ui_ry_fortune_integral_item",null,Yt)}SetData(){k.T.Inst_get().IsRedFortuneIntegral()&&$t.Inst_get().ClickIntegral(),this.RefreshItemLis(),this.AddLis(),
this.RefreshEndTime(),this.UpdateScore()}RefreshEndTime(){this.ClearEndTimeHandle(),this.EndTimeCountDown(),
null==this.countDownTimer&&(this.countDownTimer=X.C.Inst_get().SetInterval(this.CreateDelegate(this.EndTimeCountDown),1e3,-1))}EndTimeCountDown(){
const t=P.i.ins.huodong_dict.LuaDic_GetItem(k.T.Inst_get().GetActivityId())
if(null!=t&&null!=t.delayTime&&t.delayTime.ToNum()>0){const e=.001*t.delayTime.ToNum()-rt.D.serverTime_get()
if(e>0){let t=ft.x.Inst().getItemStrById(2310004)
t+=A.l.GetDateFormatBitContainZero(e,4),this.endTimeTxt.textSet(`兑换倒计时:[047104]${t}[-]`)}else this.ClearEndTimeHandle()}else this.ClearEndTimeHandle()}ClearEndTimeHandle(){
null!=this.countDownTimer&&(X.C.Inst_get().ClearInterval(this.countDownTimer),this.countDownTimer=null)
const t=ft.x.Inst().getItemStrById(11041137)
this.endTimeTxt.textSet(t)}TipBtnHandle(){const t=new St.w
t.infoId="TREASUREBOX:INTEGRAL",t.width=384,t.position=new z.P(-471,290,0),pt.Q.Inst_get().Open(t)}RefreshItemLis(){this.exchangeLis=k.T.Inst_get().GetIntegralLis(),
this.exchangeLis.Sort(this.CreateDelegate(this.SortExchangeFunc)),this.grid.data_set(this.exchangeLis)}SortExchangeFunc(t,e){return t.rank-e.rank}Clear(){this.RemoveLis(),
this.ClearEndTimeHandle(),super.Clear()}Destroy(){super.Destroy()}AddLis(){this.m_handlerMgr.AddClickEvent(this.tipBtn,this.CreateDelegate(this.TipBtnHandle)),
k.T.Inst_get().AddEventHandler(M.F.UPDATE_EXCHANGE,this.CreateDelegate(this.UpdateScore)),k.T.Inst_get().AddEventHandler(M.F.UPDATE_INFO,this.CreateDelegate(this.UpdateScore))}
RemoveLis(){k.T.Inst_get().RemoveEventHandler(M.F.UPDATE_EXCHANGE,this.CreateDelegate(this.UpdateScore)),
k.T.Inst_get().RemoveEventHandler(M.F.UPDATE_INFO,this.CreateDelegate(this.UpdateScore))}UpdateScore(){
this.score.textSet(Bt.w.Instance.ConvertNumToString(k.T.Inst_get().GetPoint()))}UpdateExchangeInfo(){}}class zt extends at.I{constructor(...t){super(...t),this.otherBg1=null,
this.otherBg2=null,this.model=null}ShowCurrencyBar_get(){return ot._.ShowDia_FortunePoint}InitView(){super.InitView(),this.otherBg1=this.CreateComponent(x.z,2),
this.otherBg2=this.CreateComponent(x.z,3),this.isExclusionPanel=!0,this._subPanelDatas.Add(nt.b.New(new _.Z(["ui_ry_fortune_fatetreasure_view"]),this,Dt)),
this._subPanelDatas.Add(nt.b.New(new _.Z(["ui_ry_fortune_integral_view"]),this,Kt)),this._subPanelDatas.Add(nt.b.New(new _.Z(["ui_fortunelimit_view"]),this,Ht)),
this.model=k.T.Inst_get()}Clear(){super.Clear()}Destroy(){super.Destroy()}SetViewConfig(){k.T.Inst_get().isEnd=!1,this._SetCharacterTabData(!1),this.bottomChangeBtnName=!0,
this._SetTabData0(!0,new _.Z(["珍宝阁","积分兑换","珍宝限购"]),new _.Z([lt.t.FORTUNE_FATE,lt.t.FORTUNE_INTEGRAL,lt.t.FORTUNE_LIMIT])),this._SetTabData1(!1)
let t=0
null!=this.model.defaultViewType?t=this.model.defaultViewType:this.model.defaultViewType=0,this.SelectTab0(this.model.defaultViewType,!0)}OnCloseClick(){$t.Inst_get().CloseView()}
_OnSelectTab0BeforeUpdate(t){this.otherBg1.SetActive(!1),this.otherBg2.SetActive(!1),0==this.selectTabIdx0&&(this.otherBg1.SetActive(!0),this.otherBg2.SetActive(!0)),
super._OnSelectTab0BeforeUpdate()}AddLis(){super.AddLis()}RemoveLis(){super.RemoveLis()}ConvertToView(){
this.model.defaultViewType!=this.selectTabIdx0&&(this.SelectTab0(this.model.defaultViewType,!0),this.OnAniPlayEnd())}OnAniPlayEnd(){this.model.isEnd=!0,super.OnAniPlayEnd()}}
var Qt=i(38836),Zt=i(38045),Xt=i(98800),jt=i(97960)
class Jt extends j.x{constructor(...t){super(...t),this.data=null,this.nameLabel=null,this.costLabel=null,this.costIcon=null,this.ui_baseitem=null,this.addBtn=null,
this.removeBtn=null,this.numLab=null,this.grid=null,this.noSelectImg=null,this.selectImg=null,this.rechargeBg=null,this.diamondBg=null,this.limitTimeTxt=null,this.costGo=null,
this.mask=null,this.info=null,this.rechargeRes=null,this.curSelectNum=null,this.result=null,this.maxNum=null,this.leftTimeTxt=null,this.time=null,this.timer=null}InitView(){
this.nameLabel=this.CreateComponent(Y.Q,1),this.costLabel=this.CreateComponent(Y.Q,2),this.costIcon=this.CreateComponent($.w,3),this.ui_baseitem=this.CreateComponentBinder(q.j,4),
this.addBtn=this.CreateComponent(H.W,5),this.removeBtn=this.CreateComponent(H.W,6),this.numLab=this.CreateComponent(Y.Q,7),this.grid=this.CreateComponent(bt.V,8),
this.noSelectImg=this.CreateComponent(x.z,9),this.selectImg=this.CreateComponent(x.z,10),this.rechargeBg=this.CreateComponent(x.z,11),this.diamondBg=this.CreateComponent(x.z,12),
this.limitTimeTxt=this.CreateComponent(Y.Q,13),this.costGo=this.CreateComponent(x.z,14),this.mask=this.CreateComponent(x.z,15)}Destroy(){this.ui_baseitem.Destroy()}ItemShowState(){
return 1==this.data.type?1:2==this.data.type?1==this.info.uniqueKeyLis.Count()?1:2:void 0}UpdateCurrencyHandle(){if(null!=this.data){const t=this.data.rechargeId
if(0!=t){this.rechargeBg.SetActive(!0),this.rechargeRes=Mt.O.Inst().getConfig(t)
const e=Pt.W.Inst.GetCurSystem(),i=this.rechargeRes.platformCurrency[e]
this.costLabel.textSet(`${i}元`)}else{const t=kt.J.GOLD_DIAMOND_STR,e=Xt.Y.Inst.PrimaryRoleInfo_get(),i=kt.J.GetGold(e,t)
let s=(0,Zt.tw)(this.data.currency)
this.data.currency>i&&(s=`[FF4B58]${s}[-]`),this.costIcon.node.SetActive(!0),this.costLabel.textSet(s)}}}SetData(t){this.info=t,
this.data=k.T.Inst_get().GetShopResById(this.info.shopResourceId),this.AddLis()
let e=null
if(this.costIcon.node.SetActive(!1),this.rechargeBg.SetActive(!1),this.diamondBg.SetActive(!1),null!=this.data&&(e=$t.Inst_get().GetItemLisByAndReward(this.data.reward),
this.mask.SetActive(1==this.data.type),this.UpdateCurrencyHandle()),null!=e&&e.Count()>0){const t=e[0],i=t.cfgData_get(),s=A.l.getColorStrByQuality(t.Quality_get())
this.nameLabel.textSet(`[${s}]${i.name}[-]`),this.ui_baseitem.SetData(t)}2==this.ItemShowState()&&this.diamondBg.SetActive(!0),this.grid.Reposition(),this.numLab.textSet(0),
this.curSelectNum=0,this.RefreshInfo(),this.StartCountDownTime(),0==this.index&&this.AddBtnHandle()}InputNumHandler(t,e){10==t?this.result=0:e?this.result=t:(this.result*=10,
this.result+=t),this.result<0&&(this.result=0),this.result>this.maxNum&&(this.result=this.maxNum),this.leftTimeTxt.textSet(this.result)}StartCountDownTime(){
1==this.ItemShowState()?(this.limitTimeTxt.node.transform.SetLocalPositionXYZ(92,-200,0),
null!=this.info.shopStartTime&&0==this.info.shopStartTime.ToNum()||-1==this.time?this.costGo.SetLocalPositionXYZ(88.5,-183,0):this.costGo.SetLocalPositionXYZ(88.5,-159.1,0)):(this.limitTimeTxt.node.transform.SetLocalPositionXYZ(92,-215,0),
this.costGo.SetLocalPositionXYZ(88.5,-159.1,0)),
-1==this.data.time?this.ClearCountDownTimer():this.info.shopStartTime.ToNum()>0?(this.timer=X.C.Inst_get().SetInterval(this.CreateDelegate(this.RefreshCountDown),1e3,-1),
this.RefreshCountDown()):this.ClearCountDownTimer()}RefreshCountDown(){if(null!=this.info&&null!=this.info.shopStartTime){
const t=.001*this.info.shopStartTime.ToNum()-rt.D.serverTime_get()
if(t>0){const e=A.l.GetDateFormatEX(t)
this.limitTimeTxt.node.SetActive(!0),this.limitTimeTxt.textSet(`限时:${e}`)}else this.node.SetActive(!1),k.T.Inst_get().RaiseEvent(M.F.MERCHANT_ITEM_EXPIRED),
this.ClearCountDownTimer()}else this.ClearCountDownTimer()}ClearCountDownTimer(){null!=this.timer&&(X.C.Inst_get().ClearInterval(this.timer),this.timer=null),
this.limitTimeTxt.node.SetActive(!1)}IsMultipleChoice(){return null==this.data||1!=this.data.type}AddLis(){
J.i.Get(this.addBtn.node).RegistonClick(this.CreateDelegate(this.AddBtnHandle)),J.i.Get(this.removeBtn.node).RegistonClick(this.CreateDelegate(this.RemoveBtnHandle)),
J.i.Get(this.node).RegistonClick(this.CreateDelegate(this.SelectHandle)),k.T.Inst_get().AddEventHandler(M.F.REFRESH_SELECT_ITEM,this.CreateDelegate(this.RefreshInfo)),
k.T.Inst_get().AddEventHandler(M.F.CANCEL_SELECT_INFO,this.CreateDelegate(this.CancelSelectInfo)),
Xt.Y.Inst.PrimaryRoleInfo_get().AddEventHandlerRoleGlobal(jt.A.GoldUpdate,this.CreateDelegate(this.UpdateCurrencyHandle))}RemoveLis(){
J.i.Get(this.addBtn.node).RemoveonClick(this.CreateDelegate(this.AddBtnHandle)),J.i.Get(this.removeBtn.node).RemoveonClick(this.CreateDelegate(this.RemoveBtnHandle)),
J.i.Get(this.node).RemoveonClick(this.CreateDelegate(this.SelectHandle)),k.T.Inst_get().RemoveEventHandler(M.F.REFRESH_SELECT_ITEM,this.CreateDelegate(this.RefreshInfo)),
k.T.Inst_get().RemoveEventHandler(M.F.CANCEL_SELECT_INFO,this.CreateDelegate(this.CancelSelectInfo)),
Xt.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandlerRoleGlobal(jt.A.GoldUpdate,this.CreateDelegate(this.UpdateCurrencyHandle))}CancelSelectInfo(){this.curSelectNum=0,
this.RefreshInfo()}RefreshInfo(){this.curSelectNum<=0?(this.removeBtn.SetIsEnabled(!1),this.selectImg.SetActive(!1),this.noSelectImg.SetActive(!0)):(this.selectImg.SetActive(!0),
this.noSelectImg.SetActive(!1),this.removeBtn.SetIsEnabled(!0)),this.curSelectNum>=this.info.uniqueKeyLis.Count()?this.addBtn.SetIsEnabled(!1):this.addBtn.SetIsEnabled(!0)}
AddBtnHandle(){
this.curSelectNum+1>this.info.uniqueKeyLis.Count()||($t.Inst_get().selectShopItemDic.LuaDic_Count()>0&&null!=this.data&&1==this.data.type&&(k.T.Inst_get().RaiseEvent(M.F.CANCEL_SELECT_INFO),
this.curSelectNum=0,$t.Inst_get().selectShopItemDic.Clear()),this.curSelectNum>1?this.IsMultipleChoice()&&(this.curSelectNum+=1,
this.RefreshItemSelectState(!0,this.curSelectNum-1)):(this.curSelectNum=1,this.RefreshItemSelectState(!0,this.curSelectNum-1)))}RemoveBtnHandle(){
this.curSelectNum-1>=0&&(this.curSelectNum-=1,this.RefreshItemSelectState(!1,this.curSelectNum))}RefreshItemSelectState(t,e){this.numLab.textSet(this.curSelectNum),
$t.Inst_get().RefreshSelectShopItem(this.info.uniqueKeyLis[e],t)}SelectHandle(){
1!=this.ItemShowState()||1!=this.curSelectNum||1!=this.info.uniqueKeyLis.Count()?0!=this.curSelectNum||this.AddBtnHandle():this.RemoveBtnHandle()}Clear(){
this.ClearCountDownTimer(),this.data=null,this.RemoveLis(),this.ui_baseitem.Clear()}}class Wt extends K.f{constructor(...t){super(...t),this.closeBtn=null,this.buyBtn=null,
this.buyDesc=null,this.tip1=null,this.tip2=null,this.btn1=null,this.btn2=null,this.grid=null,this.noItem=null,this.diamond=null,this.hasClick1=null,this.noClick1=null,
this.noClick2=null,this.hasClick2=null,this.bar=null,this.tab=null,this.tabLis=null,this.tabId=null}InitView(){super.InitView(),this.closeBtn=this.CreateComponent(H.W,1),
this.buyBtn=this.CreateComponent(H.W,2),this.buyDesc=this.CreateComponent(Y.Q,3),this.tip1=this.CreateComponent(x.z,4),this.tip2=this.CreateComponent(x.z,5),
this.btn1=this.CreateComponent(H.W,6),this.btn2=this.CreateComponent(H.W,7),this.grid=this.CreateComponent(U.A,8),this.noItem=this.CreateComponent(x.z,9),
this.diamond=this.CreateComponent(x.z,10),this.hasClick1=this.CreateComponent(x.z,11),this.noClick1=this.CreateComponent(x.z,12),this.noClick2=this.CreateComponent(x.z,13),
this.hasClick2=this.CreateComponent(x.z,14),this.bar=this.CreateComponent(F._,15),this.tab=this.CreateComponent(bt.V,16),
this.grid.SetInitInfo("ui_fortune_raremerchant_item",null,Jt),this.tabLis=new _.Z([this.btn1,this.btn2])}OnAddToScene(){this.buyBtn.node.SetActive(!1),
$t.Inst_get().selectShopItemDic=new I.X,this.btn2.node.SetActive(this.IsShowRecharge()),this.tabId=this.GetDefaultTab(),this.AddLis(),this.UpdateView()}GetDefaultTab(){let t=-1
if(this.IsShowRecharge()){t=Tt.F.Recharge
if(k.T.Inst_get().GetLisByTabType(t).Count()>0)return t}return t=Tt.F.Diamond,Tt.F.Diamond}UpdateView(){this.tip1.SetActive(!1),this.tip2.SetActive(!1),
this.hasClick1.SetActive(!1),this.noClick1.SetActive(!1),this.hasClick2.SetActive(!1),this.noClick2.SetActive(!1),1==this.tabId?(this.hasClick2.SetActive(!0),
this.noClick1.SetActive(!0)):2==this.tabId&&(this.hasClick1.SetActive(!0),this.noClick2.SetActive(!0)),this.UpdateItemLis()}IsShowRecharge(){
if(null!=k.T.Inst_get().config&&null!=k.T.Inst_get().config.shopMap){const t=k.T.Inst_get().config.shopMap
for(const[e,i]of(0,Qt.vy)(t))if(1==i.type)return!0}return!1}Clear(){super.Clear(),this.grid.Clear(),this.RemoveLis()}Destroy(){this.grid.Destroy()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.btn1,this.CreateDelegate(this.LimitBuyBtnHandle)),this.m_handlerMgr.AddClickEvent(this.btn2,this.CreateDelegate(this.DirectBuyBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.OnCloseBtnHandle)),this.m_handlerMgr.AddClickEvent(this.buyBtn,this.CreateDelegate(this.BuyBtnHandle)),
k.T.Inst_get().AddEventHandler(M.F.REFRESH_SELECT_ITEM,this.CreateDelegate(this.RefreshInfo)),
k.T.Inst_get().AddEventHandler(M.F.UPDATE_SHOP,this.CreateDelegate(this.UpdateItemLis)),
k.T.Inst_get().AddEventHandler(M.F.MERCHANT_ITEM_EXPIRED,this.CreateDelegate(this.UpdateItemLis))}RemoveLis(){
k.T.Inst_get().RemoveEventHandler(M.F.REFRESH_SELECT_ITEM,this.CreateDelegate(this.RefreshInfo)),
k.T.Inst_get().RemoveEventHandler(M.F.UPDATE_SHOP,this.CreateDelegate(this.UpdateItemLis)),
k.T.Inst_get().RemoveEventHandler(M.F.MERCHANT_ITEM_EXPIRED,this.CreateDelegate(this.UpdateItemLis))}RefreshInfo(){this.diamond.SetActive(!1)
const t=$t.Inst_get().selectShopItemDic,e=new _.Z
let i=0
for(const[s,n]of(0,Qt.vy)(t))if(n){const t=k.T.Inst_get().shopVoDic[s].shopResourceId
e.Add(s)
const n=k.T.Inst_get().GetShopResById(t)
null!=n&&(i=n.currency+i)}if(0==e.Count())this.buyBtn.node.SetActive(!1)
else if(this.buyBtn.node.SetActive(!0),1==this.tabId&&1==e.Count()){const t=k.T.Inst_get().shopVoDic[e[0]].shopResourceId,i=k.T.Inst_get().GetShopResById(t)
if(null!=i){const t=Mt.O.Inst().getConfig(i.rechargeId),e=Mt.O.Inst().GetCfgMoney(t)
this.buyDesc.textSet(`${e}元`)}}else{const t=kt.J.GOLD_DIAMOND_STR,e=Xt.Y.Inst.PrimaryRoleInfo_get(),s=kt.J.GetGold(e,t)
let n=(0,Zt.tw)(i)
i>s&&(n=`[FF4B58]${n}[-]`),this.diamond.SetActive(!0),this.buyDesc.textSet(n)}this.tab.CallReposition()}LimitBuyBtnHandle(){$t.Inst_get().selectShopItemDic.Clear(),
this.buyBtn.node.SetActive(!1),this.tabId=2,this.UpdateView()}DirectBuyBtnHandle(){$t.Inst_get().selectShopItemDic.Clear(),this.buyBtn.node.SetActive(!1),this.tabId=1,
this.UpdateView()}BuyBtnHandle(){const t=$t.Inst_get().selectShopItemDic,e=new _.Z,i=new _.Z
let s=0
for(const[n,a]of(0,Qt.vy)(t)){e.Add(n)
const t=k.T.Inst_get().shopVoDic[n].shopResourceId,a=k.T.Inst_get().GetShopResById(t)
null!=a&&(s=a.currency+s,a.currency>0&&i.Add(n))}if(0==e.Count())this.buyBtn.node.SetActive(!1)
else if(this.buyBtn.node.SetActive(!0),1==this.tabId&&1==e.Count()){const t=k.T.Inst_get().shopVoDic[e[0]].shopResourceId,i=k.T.Inst_get().GetShopResById(t)
if(null!=i){const t=Mt.O.Inst().getConfig(i.rechargeId)
Vt.t.inst.Buy(t)}}else $t.Inst_get().SendCM_FortuneBuy(i)}UpdateItemLis(){const t=k.T.Inst_get().GetLisByTabType(this.tabId)
this.grid.data_set(t),this.noItem.SetActive(t.Count()<=0),this.buyBtn.node.SetActive(!1),$t.Inst_get().selectShopItemDic.Clear(),this.bar.SetValue(0),this.buyBtn.node.SetActive(!1)
}OnCloseBtnHandle(){$t.Inst_get().CloseRareMerchantPanel()}}class $t{constructor(){this.fortunePanel=null,this.rareMerchantPanel=null,this.fateResultPanel=null,
this.selectShopItemDic=null,this.roundTipData=null,this.isMulti=null,this.sendNum=null,this.AddLis(),this.RegisterMsg()}static Inst_get(){return null==$t.inst&&($t.inst=new $t),
$t.inst}ResetData(){null!=this.selectShopItemDic&&this.selectShopItemDic.Clear(),k.T.Inst_get().ResetModel()}GetMallInfo(){
return G.P.ins.GetVoByHuodongIdAndType(k.T.Inst_get().GetActivityId(),L.f.TICKET_TYPE)}GetItemLisByAndReward(t){const e=new _.Z
if(null!=t){const i=t.rewards
for(let t=0;t<=i.count-1;t++){const s=S.M.wrapReward(i[t])
e.Add(s)}}return e}OpenView(t){if(f.P.Inst_get().IsFunctionOpened(y.x.FORTUNE_TREASURE))if(null==t&&(t=0),k.T.Inst_get().defaultViewType=t,
null!=this.fortunePanel&&this.fortunePanel.isShow_get())this.fortunePanel.ConvertToView()
else{const t=new l.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!1,h.N.inst.OpenById(d.I.FortuneTreasure,this.CreateDelegate(this.ShowPanelHandler),this.CreateDelegate(this.DestroyPanelHandler),t)
}else A.l.SetFunctionTip(y.x.FORTUNE_TREASURE)}ShowPanelHandler(t){return null==this.fortunePanel&&(this.fortunePanel=new zt,this.fortunePanel.setId(t,null,0)),this.fortunePanel}
DestroyPanelHandler(){r.g.DestroyUIObj(this.fortunePanel),this.fortunePanel=null}CloseView(){h.N.inst.CloseById(d.I.FortuneTreasure)}OpenRareMerchantPanel(){const t=new l.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!1,h.N.inst.OpenById(d.I.FortuneMerchant,this.CreateDelegate(this.ShowRareMerchantPanelHandler),this.CreateDelegate(this.DestroyRareMerchantPanelHandler),t)
}ShowRareMerchantPanelHandler(t){return null==this.rareMerchantPanel&&(this.rareMerchantPanel=new Wt,this.rareMerchantPanel.setId(t,null,0)),this.rareMerchantPanel}
DestroyRareMerchantPanelHandler(){r.g.DestroyUIObj(this.rareMerchantPanel),this.rareMerchantPanel=null}CloseRareMerchantPanel(){h.N.inst.CloseById(d.I.FortuneMerchant)}
RefreshSelectShopItem(t,e){null==this.selectShopItemDic&&(this.selectShopItemDic=new I.X),e?(this.selectShopItemDic[t]=e,
this.selectShopItemDic.LuaDic_AddOrSetItem(t,e)):this.selectShopItemDic.LuaDic_Remove(t),k.T.Inst_get().RaiseEvent(M.F.REFRESH_SELECT_ITEM)}OpenTipView(t){
m.J.Inst_get().ShowItemTip(t)}OpenFateResultView(){if(!f.P.Inst_get().IsFunctionOpened(y.x.FORTUNE_TREASURE))return
if(null!=this.fateResultPanel&&this.fateResultPanel.isShow_get())return void this.fateResultPanel.UpdateView()
const t=new l.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!1,h.N.inst.OpenById(d.I.FortuneFateResultPanel,this.CreateDelegate(this.ShowFortuneFateResultPanelHandler),this.CreateDelegate(this.DestroyFortuneFateResultPanelHandler),t)
}ShowFortuneFateResultPanelHandler(t){return null==this.fateResultPanel&&(this.fateResultPanel=new it,this.fateResultPanel.setId(t,null,0)),this.fateResultPanel}
DestroyFortuneFateResultPanelHandler(){r.g.DestroyUIObj(this.fateResultPanel),this.fateResultPanel=null}CloseFateResultView(){h.N.inst.CloseById(d.I.FortuneFateResultPanel)}
OpenRoundRewardTipsView(t,e,i){null==i&&((0,n.S)("错误"),i=g.F.zero_get())
const s=new l.v
s.isShowMask=!1,s.isSelfTween=!1,s.isDefaultUITween=!0,s.layerType=c.F.MainUI,s.viewClass=st,s.positionType=u.Z.eCustom,s.pos=i,this.roundTipData=new V(t,e,i),
h.N.inst.OpenById(d.I.FortuneTipView,null,null,s)}CloseRoundRewardTipsView(){h.N.inst.CloseById(d.I.FortuneTipView)}AddLis(){a.i.Inst.AddEventHandler(p.g.BAG_UPDATE,(0,
s.v)(this.BagUpdateHandle,this)),a.i.Inst.AddEventHandler(p.g.HUODONG_INFO_CHANGE,(0,s.v)(this.ActivityInfoChangeHandle,this)),
a.i.Inst.AddEventHandler(p.g.HUODONG_MALL_BUY_CNT_CHANGE,(0,s.v)(this.MallChangeHandle,this)),a.i.Inst.AddEventHandler(p.g.HUODONG_MALL_CHANGE,(0,s.v)(this.MallChangeHandle,this)),
a.i.Inst.AddEventHandler(p.g.CHOOSE_SETTING_UPDATE,(0,s.v)(this.MallChangeHandle,this))}BagUpdateHandle(){k.T.Inst_get().FateRedPoint()}ActivityInfoChangeHandle(){
P.i.ins.GetState(k.T.Inst_get().GetActivityId())==N.V.END&&k.T.Inst_get().RefreshRedPoint()}MallChangeHandle(){k.T.Inst_get().LimitBuyRedPoint()}RegisterMsg(){}
SM_FortuneConfigHandle(t){k.T.Inst_get().SetConfig(t),k.T.Inst_get().RaiseEvent(M.F.FORTUNE_CONFIG)}SM_FortuneRoundHandle(t){k.T.Inst_get().SetRoundInfo(t),
k.T.Inst_get().RaiseEvent(M.F.UPDATE_ROUND_INFO)}SM_FortuneInfoHandle(t){k.T.Inst_get().SetInfo(t),k.T.Inst_get().RaiseEvent(M.F.UPDATE_INFO)}SM_FortuneRollResultHandle(t){
k.T.Inst_get().SetRollResult(t.resultVo),k.T.Inst_get().RaiseEvent(M.F.ROLL_SUCCESS)}SM_FortuneShowHandle(t){k.T.Inst_get().SetBoxShowVo(t.showVo,t.isPlaying),
k.T.Inst_get().RaiseEvent(M.F.UPDATE_BOX)}SM_FortuneShopHandle(t){k.T.Inst_get().SetShopVoLis(t.shopVos),k.T.Inst_get().RaiseEvent(M.F.UPDATE_SHOP)}SM_FortuneExchangeHandle(t){
k.T.Inst_get().SetExchangeMap(t.exchangeMap,t.consume),k.T.Inst_get().RaiseEvent(M.F.UPDATE_EXCHANGE)}SendCM_FortuneBuy(t,e){null==e&&(e=k.T.Inst_get().GetActivityId())
const i=new I.X
for(let e=0;e<=t.Count()-1;e++)i.LuaDic_AddOrSetItem(t[e],"")
const s=new T.K
s.activityId=e,s.buyIds=i,o.C.Inst.F_SendMsg(s)}SendCM_FortuneIgnore(t,e){null==e&&(e=k.T.Inst_get().GetActivityId()),k.T.Inst_get().info.isIgnore=t
const i=new R.q
i.activityId=e,i.isIgnore=t,o.C.Inst.F_SendMsg(i)}SendCM_FortunePoint(t,e,i){null==i&&(i=k.T.Inst_get().GetActivityId())
const s=new v.O
s.activityId=i,s.resourceId=t,s.num=e,o.C.Inst.F_SendMsg(s)}SendCM_FortuneRoll(t,e,i,s){null==s&&(s=k.T.Inst_get().GetActivityId()),t||(e=0,t=!1),i||(i=!1)
const n=new D.X
n.activityId=s,n.isSpecial=t,n.roll=e,n.isMulti=i,o.C.Inst.F_SendMsg(n)}SendCM_FortuneReward(t,e){null==e&&(e=k.T.Inst_get().GetActivityId())
const i=new w.b
i.activityId=e,i.round=t,o.C.Inst.F_SendMsg(i)}ClickLimitBuy(){O.p.inst.SendClientLogicSetting(b.R.FORTUNE_LIMIT,1,!1),k.T.Inst_get().LimitBuyRedPoint()}ClickIntegral(){
k.T.Inst_get().clickIntegral=!0,k.T.Inst_get().IntegralRedPoint()}GoHandle(t){if(C.g.Inst_get().emptySize_get()>=2){this.isMulti=t,this.sendNum=k.T.Inst_get().GetConsumeNum(t)
const e=k.T.Inst_get().GetDiceItemId()
E.$.ins.CheckItemEnough(k.T.Inst_get().GetActivityId(),e,this.sendNum)?this.SendCM_FortuneRoll(!1,null,this.isMulti):a.i.Inst.AddEventHandler(p.g.HUODONG_MALL_BUY_SUCCESS,this.CreateDelegate(this.BuySuccessHandle))
}else B.y.inst.ClientSysStrMsg("背包已满"),m.J.Inst_get().OpenBagSellPanel()}BuySuccessHandle(t){const e=this.GetMallInfo()
if(null!=e&&t.mallId==e.mallId){a.i.Inst.RemoveEventHandler(p.g.HUODONG_MALL_BUY_SUCCESS,this.CreateDelegate(this.BuySuccessHandle))
k.T.Inst_get().GetDiceItemNum()>=k.T.Inst_get().GetConsumeNum(this.isMulti)&&this.SendCM_FortuneRoll(!1,null,this.isMulti)}}}$t.inst=null},27354:(t,e,i)=>{i.d(e,{F:()=>s})
class s{}s.REFRESH_SELECT_ITEM=0,s.UPDATE_INFO=1,s.ROLL_SUCCESS=2,s.UPDATE_BOX=3,s.UPDATE_SHOP=4,s.UPDATE_EXCHANGE=5,s.UPDATE_ROUND_INFO=6,s.CANCEL_SELECT_INFO=7,
s.RESULT_ANIM_END=8,s.FIRST_ROLL=9,s.MERCHANT_ITEM_EXPIRED=10,s.FORTUNE_CONFIG=11,s.GET_FATE_ROLL=12,s.BEST_PRICE_UPDATE=13,s.JUMP_RESULT_ANIM=14},35073:(t,e,i)=>{i.d(e,{F:()=>s})
class s{}s.FATE_TREASURE_VIEW=0,s.INTEGRAL_EXCHANGE_VIEW=1,s.FORTUNE_LIMIT_VIEW=2,s.Diamond=2,s.Recharge=1},86577:(t,e,i)=>{i.d(e,{T:()=>A})
var s=i(38836),n=i(68662),a=i(16812),o=i(85602),l=i(38962),r=i(70850),h=i(75439),d=i(82025),u=i(60567),c=i(14792),_=i(62734),I=i(60647),g=i(13487),m=i(56834),C=i(93727),S=i(61249),p=i(27354)
class A extends a.k{constructor(){super(),this.defaultViewType=0,this.rollResult=null,this.info=null,this.boxShowVo=null,this.shopVoLis=null,this.shopVoDic=null,
this.exchangeMap=null,this.roundRewardMap=null,this.isFirstRoll=!1,this.config=null,this.clickIntegral=!1,this.isEnd=null,this.hasClickRareMerchant=null,this.isPlaying=null,
this.beforeBoxShowVo=null,this.shopVoLis=new o.Z,this.shopVoDic=new l.X,this.exchangeMap=new l.X,this.roundRewardMap=new l.X}static Inst_get(){return null==A.inst&&(A.inst=new A),
A.inst}ResetModel(){this.defaultViewType=0,this.rollResult=null,this.info=null,this.boxShowVo=null,this.shopVoLis=new o.Z,this.shopVoDic=new l.X,this.exchangeMap=new l.X,
this.isEnd=!1,this.hasClickRareMerchant=!1,this.config=null,this.clickIntegral=!1}GetDiceItemId(){return h.D.getInstance().GetIntValue("TREASUREBOX:CONSUME")}GetConsumeNum(t){
return t?h.D.getInstance().GetIntValue("TREASUREBOX:CONSUME_TENTIME"):h.D.getInstance().GetIntValue("TREASUREBOX:CONSUME_ONETIME")}GetFreeTime(){
return h.D.getInstance().GetIntValue("TREASUREBOX:FREETIMES")}SetConfig(t){this.config=t}GetBoxResById(t){
if(null!=this.config&&null!=this.config.boxMap)return this.config.boxMap[t]}GetExchangeResById(t){
if(null!=this.config&&null!=this.config.exchangeMap)return this.config.exchangeMap[t]}GetIntegralLis(){const t=new o.Z
if(null!=this.config&&null!=this.config.exchangeMap)for(const[e,i]of(0,s.vy)(this.config.exchangeMap))t.Add(i)
return t}GetRoundResById(t){if(null!=this.config&&null!=this.config.roundMap)return this.config.roundMap[t]}GetRoundLis(){const t=new o.Z
if(null!=this.config&&null!=this.config.exchangeMap){for(const[e,i]of(0,s.vy)(this.config.roundMap))t.Add(i)
t.Sort(this.CreateDelegate(this.SortRoundFunc))}return t}SortRoundFunc(t,e){return t.round-e.round}GetShopResById(t){
if(null!=this.config&&null!=this.config.shopMap)return this.config.shopMap[t]}GetLisByTabType(t){const e=new o.Z,i=this.GetShowVoLis(t)
for(let t=0;t<=i.Count()-1;t++){const s=i[t]
this.IsShowRareItem(s)&&e.Add(s)}return e}IsShowRareItem(t){const e=this.GetShopResById(t.shopResourceId)
if(null==e)return!0
if(-1==e.time)return!0
if(null!=t.shopStartTime){if(.001*t.shopStartTime.ToNum()-n.D.serverTime_get()>0)return!0}return!1}IsTypeByResId(t,e){if(null!=this.config){const i=this.GetShopResById(t)
if(null!=i)return i.type==e}}SetInfo(t){this.isFirstRoll=!1
let e=!1
if(null!=this.info){e=this.IsFirstRoll(this.info)
this.info.specialRollRemain<t.specialRollRemain&&this.RaiseEvent(p.F.GET_FATE_ROLL)}if(e){this.IsFirstRoll(t)||(this.isFirstRoll=!0)}this.info=t,
this.isPlaying=t.isPlaying&&!this.info.isIgnore,this.RefreshRedPoint()}SetRoundInfo(t){this.roundRewardMap=t.roundRewardMap,this.isPlaying=t.isPlaying&&!this.info.isIgnore,
null!=S.p.Inst_get().fateResultPanel&&S.p.Inst_get().fateResultPanel.isShow_get()&&(this.isPlaying=!1),this.FateRedPoint()}SetRollResult(t){this.rollResult=t}SetBoxShowVo(t,e){
null!=this.boxShowVo&&(this.beforeBoxShowVo=this.boxShowVo),this.boxShowVo=t,this.isPlaying=e&&!this.info.isIgnore,
null!=S.p.Inst_get().fateResultPanel&&S.p.Inst_get().fateResultPanel.isShow_get()&&(this.isPlaying=!1)}SetExchangeMap(t,e){
if(null!=this.info&&null!=e&&(this.info.point=this.info.point-e),null!=t)for(const[e,i]of(0,s.vy)(t))this.exchangeMap.LuaDic_AddOrSetItem(e,i)
this.IntegralRedPoint()}SetShopVoLis(t){this.shopVoLis=t
for(let e=0;e<=t.Count()-1;e++)this.shopVoDic[t[e].uniqueKey]=t[e]}GetShowVoLis(t){const e=new o.Z,i=new l.X
for(let s=0;s<=this.shopVoLis.Count()-1;s++){const n=this.shopVoLis[s]
this.IsTypeByResId(n.shopResourceId,t)&&(null!=n.shopStartTime&&n.shopStartTime.ToNum()>0||this.IsTypeByResId(n.shopResourceId,1)?(n.uniqueKeyLis=new o.Z([n.uniqueKey]),
e.Add(n)):null==i[n.shopResourceId]?(n.uniqueKeyLis=new o.Z([n.uniqueKey]),i.LuaDic_AddOrSetItem(n.shopResourceId,n)):i[n.shopResourceId].uniqueKeyLis.Add(n.uniqueKey))}
const s=i.LuaDic_Values()
return e.AddRange(s),e}GetExchangeTimeById(t){return null!=this.exchangeMap[t]?this.exchangeMap[t]:0}GetDiceItemNum(){let t=0
const e=this.GetDiceItemId()
return null!=e&&(t=r.g.Inst_get().GetItemNum(e)),t}GetWorldLevel(){let t=0
const e=C.i.ins.huodong_dict.LuaDic_GetItem(this.GetActivityId())
return null!=e&&null!=e.worldLevel&&(t=e.worldLevel),t}IsClickLimitBuy(){return 1==I.p.inst.GetClientLogicSetting(g.R.FORTUNE_LIMIT)}IsCanRefresh(t){if(null!=t){
const e=C.i.ins.huodong_dict.LuaDic_GetItem(this.GetActivityId())
if(t.ToNum()>0&&t.ToNum()<e.delayTime.ToNum())return!0}return!1}GetBoxRemainNum(t){if(null!=this.info&&null!=this.config){let e=0
null!=this.info.prizeMap&&null!=this.info.prizeMap[t]&&(e=this.info.prizeMap[t])
const i=this.GetBoxResById(t).maxSpawnNum
return i<=0?-1:i-e}}IsCanExchangeByRes(t){const e=this.GetExchangeTimeById(t.id),i=t.maxNum
if(-1!=t.maxNum&&e>=i)return!1
if(null!=this.info){if(this.info.point>=t.consume)return!0}return!1}IsHadGetRoundReward(t){if(null!=this.info){const e=this.info.loop
if(null!=e){if(null==this.roundRewardMap)return!0
if(null!=this.roundRewardMap[e]){const i=t.id,s=this.roundRewardMap[e]
if(null==s||3==s.roundMap[i])return!0}}}return!1}GetPoint(){let t=0
return null!=this.info&&(t=this.info.point),t}IsFirstRoll(t){return null!=t&&null!=t.loop&&null!=t.curRound&&null!=t.curPos&&0==t.loop&&0==t.curRound&&0==t.curPos}IsActivityEnd(){
if(C.i.ins.GetState(this.GetActivityId())==m.V.END)return!0}GetActivityId(){let t=0
return null!=this.config&&(t=this.config.activityId),t}IsCanBuy(t){return!(null==t||-1!=t.limit&&u.P.ins.GetBuyTimesByMallId(t.mallId)>=t.limit)}HasClickWhenRed(){
return this.clickIntegral}IsRedFortuneLimit(){return this.IsHasRedPoint(c.t.FORTUNE_LIMIT)}IsRedFortuneIntegral(){return this.IsHasRedPoint(c.t.FORTUNE_INTEGRAL)}IsHasRedPoint(t){
const e=_.f.Inst.GetData(t)
return!(null==e||!e.show)}RefreshRedPoint(){this.FateRedPoint(),this.IntegralRedPoint(),this.LimitBuyRedPoint()}LimitBuyRedPoint(){let t=!1
if(C.i.ins.GetState(this.GetActivityId())==m.V.OPEN&&!this.IsClickLimitBuy()){const e=u.P.ins.GetMallListByHuoDongId(this.GetActivityId())
for(let i=0;i<=e.Count()-1;i++){const s=e[i]
if(null!=s&&s.CheckView()&&s.CheckBuy()&&s.type==d.f.RECHARGE_TYPE&&this.IsCanBuy(s)){t=!0
break}}}_.f.Inst.SetState(c.t.FORTUNE_LIMIT,t)}FateRedPoint(){let t=!1
if(C.i.ins.GetState(this.GetActivityId())==m.V.OPEN&&null!=this.info&&(this.GetDiceItemNum()>0&&(t=!0),!t&&this.info.specialRollRemain>0&&(t=!0),
!t&&null!=this.shopVoLis&&this.shopVoLis.Count()>0&&(t=!0),!t)){const e=this.GetRoundLis()
for(let i=0;i<=e.Count()-1;i++){const s=this.info
if(null!=s&&s.curRound>=e[i].round&&!this.IsHadGetRoundReward(e[i])){t=!0
break}}}_.f.Inst.SetState(c.t.FORTUNE_FATE,t)}IntegralRedPoint(){let t=!1
if(null!=this.info&&!this.HasClickWhenRed()){const e=this.GetIntegralLis()
for(let i=0;i<=e.Count()-1;i++)if(this.IsCanExchangeByRes(e[i])){t=!0
break}}_.f.Inst.SetState(c.t.FORTUNE_INTEGRAL,t)}}A.inst=null},956:(t,e,i)=>{i.d(e,{$:()=>zt})
var s=i(97461),n=i(90419),a=i(50089),o=i(98497),l=i(38935),r=i(56937),h=i(31222),d=i(5494),u=i(98885),c=i(70850),_=i(92679),I=i(48411),g=i(90409),m=i(62101),C=i(82661),S=i(14591),p=i(5436),A=i(83572),f=i(82142),y=i(85605),T=i(82025),R=i(60567),v=i(14792),w=i(62734),D=i(60647),E=i(13487),L=i(65550),G=i(28359)
class O{}O.OpenSuccess="OpenSuccess",O.UpdateInfo="UpdateInfo",O.OpenItemAnimEnd="OpenItemAnimEnd"
var b=i(16812),B=i(85602),N=i(38962),P=i(63076),M=i(57035),V=i(55492),k=i(75582),x=i(56834),H=i(93727),U=i(87923),F=i(75439),Y=i(74657)
class K{constructor(){this.map=null,this.keyItemId=null,this.tenTime=null,this.rewardList=null,this.exchangeList=null,this.bigPrizeItem=null,this.InitConfig()}static Inst_get(){
return null==K.inst&&(K.inst=new K),K.inst}InitConfig(){this.keyItemId=F.D.getInstance().GetIntValue("GLORYCALL:CONSUME_ITEM"),
this.tenTime=F.D.getInstance().GetIntValue("GLORYCALL:CONSUME_NUM_TEN"),this.rewardList=new B.Z,this.exchangeList=new B.Z}SetItemList(t){const e=this.map.LuaDic_Values()
e.Sort(((t,e)=>t.sort-e.sort)),this.rewardList.Clear(),this.exchangeList.Clear()
for(let i=0;i<=e.Count()-1;i++){const s=e[i]
if(t.Contains(s.activityId)){const t=Y.A.GetReward(s.rewardDefs).GetAllRewardList()
for(let e=0;e<=t.count-1;e++){t[e].gloryCallCfgId=s.id
const i=s.rewardLimit
if(i>=1?(t[e].showNum=!0,t[e].limitNum=i):t[e].showNum=!0,1!=s.prize?this.rewardList.Add(t[e]):1==s.prize&&(this.bigPrizeItem=t[e]),s.exchange>0){
const i=new P.M(t[e].modelId_get())
i.showNum=!0,i.count=t[e].count,i.limitNum=s.exchangeNum,i.gloryCallExchange=s.exchange,i.gloryCallCfgId=s.id,this.exchangeList.Add(i)}}}}}GetResById(t){return this.map[t]}
GetRewardLis(){const t=this.rewardList
for(let e=0;e<=t.count-1;e++)if(t[e].limitNum>=1){const i=t[e].limitNum-z.Inst_get().GetTreasureCountById(t[e].gloryCallCfgId)
t[e].SpecialNumStr=i<=0?`[de2524]${i}[-]/${t[e].limitNum}`:`[${U.l.txtGreenStr}]${i}/${t[e].limitNum}[-]`}return t}GetExchangeLis(){return this.exchangeList}GetBigPrizeItem(){
const t=this.bigPrizeItem.limitNum-z.Inst_get().GetTreasureCountById(this.bigPrizeItem.gloryCallCfgId)
return this.bigPrizeItem.SpecialNumStr=t<=0?`[de2524]${t}[-]/${this.bigPrizeItem.limitNum}`:`[${U.l.txtGreenStr}]${t}/${this.bigPrizeItem.limitNum}[-]`,this.bigPrizeItem}}
K.inst=null
class z extends b.k{constructor(){super(),this.defaultView=0,this.treasureLis=null,this.treasureDic=null,this.gloryCallInfo=null,this.actId=0,this.shopActId=0,
this.treasureResultInfo=null,this.redPointInfo=null,this.gloryCallResultInfo=null,this.treasureLis=new B.Z,this.treasureDic=new N.X}static Inst_get(){
return null==z.inst&&(z.inst=new z),z.inst}ResetModel(){this.defaultView=0,this.treasureLis=new B.Z,this.treasureDic=new N.X,this.gloryCallInfo=null,this.actId=0,this.shopActId=0}
GetShopActId(){if(!this.IsActivityOpen1(this.shopActId)){const t=this.GetFunctionOpenActId(V.x.DRAGON_TREASURE_SHOP)
0!=t&&(this.shopActId=t)}return this.shopActId}IsActivityOpen1(t){if(H.i.ins.GetState(t)==x.V.END||H.i.ins.GetState(t)==x.V.OPEN)return!0}GetActId(){
return this.actId=this.GetFunctionOpenActId(V.x.GLORY_CALL),this.actId}GetFunctionOpenActId(t){
const e=M.d.Inst_get().getItemById(t),i=u.M.SubStringWithLen(e.activityIds,1,u.M.Length(e.activityIds)-2),s=u.M.Split(i,u.M.s_SPAN_CHAR)
for(let t=0;t<=s.Count()-1;t++){const e=u.M.String2Int(s[t])
if(H.i.ins.GetState(e)==x.V.END||H.i.ins.GetState(e)==x.V.OPEN)return e}return 0}GetDefaultView(){return this.defaultView}GetTreasureCountById(t){let e=0
return null!=this.gloryCallInfo&&null!=this.gloryCallInfo.id2drawNum&&null!=this.gloryCallInfo.id2drawNum[t]&&(e=this.gloryCallInfo.id2drawNum[t]),e}GetExchangeCountById(t){let e=0
return null!=this.gloryCallInfo&&null!=this.gloryCallInfo.id2exchangeNum&&null!=this.gloryCallInfo.id2exchangeNum[t]&&(e=this.gloryCallInfo.id2exchangeNum[t]),e}GetScoreById(t){
let e=0
return null!=this.gloryCallInfo&&null!=this.gloryCallInfo.id2ScoreNum&&null!=this.gloryCallInfo.id2ScoreNum[t]&&(e=this.gloryCallInfo.id2ScoreNum[t]),e}GetKeyItemId(){
return K.Inst_get().keyItemId}GetTenNum(){return K.Inst_get().tenTime}GetConsumeNum(t){let e=1
return 10==t&&(e=this.GetTenNum()),e}SortFunc(t,e){const i=k.Z.ins.GetVoByMallId(t.mallId),s=k.Z.ins.GetVoByMallId(e.mallId)
return i.show-s.show}GetItemLisByAndReward(t){const e=new B.Z
if(null!=t){const i=t.rewards
for(let t=0;t<=i.count-1;t++){const s=P.M.wrapReward(i[t])
e.Add(s)}}return e}IsJumpAnim(){return 1==D.p.inst.GetClientLogicSetting(E.R.GLORY_CALL_JUMP_ANIM)}IsSatisfyKeyNum(){
return c.g.Inst_get().GetItemNum(this.GetKeyItemId())>=this.GetConsumeNum(1)}IsSatisfyTenNum(t){return c.g.Inst_get().GetItemNum(this.GetKeyItemId())>=this.GetConsumeNum(10)}
IsSatisfyExchange(){if(this.gloryCallInfo){if(this.redPointInfo&&this.redPointInfo.scoreRedPoint)return!0
const t=K.Inst_get().GetExchangeLis()
for(let e=0;e<=t.Count()-1;e++){const i=t[e]
if(this.GetExchangeCountById(i.gloryCallCfgId)<i.limitNum&&this.GetScoreById(i.gloryCallCfgId)>=i.gloryCallExchange)return!0}}return!1}SetTreasureConfig(t){if(null!=t.configVos){
this.treasureLis=t.configVos,this.treasureDic.Clear()
for(let t=0;t<=this.treasureLis.Count()-1;t++){const e=this.treasureLis[t]
this.treasureDic[e.id]=e}}}SetExchangeInfo(t){this.gloryCallInfo&&(this.gloryCallInfo.id2exchangeNum[t.id]=t.exchangeNum,this.gloryCallInfo.id2ScoreNum[t.id]=t.score),
w.f.Inst.SetState(v.t.GLORY_CALL_EXCHANGE,this.IsSatisfyExchange())}SetGloryCallInfo(t){this.gloryCallInfo=t,K.Inst_get().SetItemList(t.typeSet),
w.f.Inst.SetState(v.t.GLORY_CALL_DRAW,this.IsSatisfyKeyNum()),w.f.Inst.SetState(v.t.GLORY_CALL_EXCHANGE,this.IsSatisfyExchange())}SetGloryCallRedPiont(t){this.redPointInfo=t,
w.f.Inst.SetState(v.t.GLORY_CALL_SHOP,t.businessmanRedPoint),w.f.Inst.SetState(v.t.GLORY_CALL_EXCHANGE,this.IsSatisfyExchange())}SetGloryCallResultInfo(t){
this.gloryCallInfo&&(this.gloryCallInfo.id2ScoreNum=t.id2ScoreNum,this.gloryCallInfo.showItemVoList=t.showItemList,this.gloryCallInfo.id2drawNum=t.id2drawNum,
this.gloryCallInfo.drawMustRewardNum=t.drawMustRewardNum),this.gloryCallResultInfo=t,w.f.Inst.SetState(v.t.GLORY_CALL_EXCHANGE,this.IsSatisfyExchange())}GetRemainNum(t){let e=0
if(null!=this.treasureLis)for(let i=0;i<=this.treasureLis.Count()-1;i++){const s=this.treasureLis[i]
let n=this.treasureDic[s.id].limit
n-=this.GetTreasureCountById(s.id)
const a=P.M.wrapReward(s.reward.rewards[0])
a.modelId_get()==t&&(e+=n*a.count)}return e}HasFreeOpenTime(){return null!=this.gloryCallInfo&&this.gloryCallInfo.restFreeCount>0}IsActivityOpen(){
return H.i.ins.GetState(this.GetActId())==x.V.OPEN}IsCanBuy(t){if(null!=t){const e=R.P.ins.GetBuyTimesByMallId(t.mallId),i=t.limit
if(0!=i&&e>=i)return!1
const s=zt.Inst_get().GetConsume(t.consumeDefs),n=s[0].modelId_get(),a=s[0].count
if(c.g.Inst_get().GetItemNum(n)>=a)return!0}return!1}}z.inst=null
var Q=i(38836),Z=i(5924),X=i(99294),j=i(9986),J=i(6665),W=i(78287),$=i(93877),q=i(61911),tt=i(75696),et=i(18152),it=i(47786)
class st extends q.f{constructor(...t){super(...t),this.oneHuntBtn=null,this.tenHuntBtn=null,this.grid=null,this.effGo=null,this.desc1=null,this.desc2=null,this.confirmBtn=null,
this.continueBtn=null,this.grid1=null,this.grid2=null,this.grid3=null,this.desc3=null,this.bigDrawBtn=null,this.rybeibao_sp_0044=null,this.ryxingkongmibao_sp_0003=null,
this.bar1=null,this.bar2=null,this.bar3=null,this.continueLabel=null,this.curshowRewardIdx=-1,this.timerId=-1,this.curshowRewardIdx2=-1,this.timerId2=-1,this.isShowBtn=null,
this.isPlaying=null,this.ret=null}InitView(){super.InitView(),this.oneHuntBtn=this.CreateComponent(j.W,4),this.tenHuntBtn=this.CreateComponent(j.W,5),
this.grid=this.CreateComponent(J.A,8),this.effGo=this.CreateComponent(X.z,10),this.desc1=this.CreateComponent($.Q,11),this.desc2=this.CreateComponent($.Q,12),
this.confirmBtn=this.CreateComponent(j.W,13),this.continueBtn=this.CreateComponent(j.W,14),this.grid1=this.CreateComponent(J.A,15),this.grid2=this.CreateComponent(J.A,16),
this.grid3=this.CreateComponent(J.A,17),this.desc3=this.CreateComponent($.Q,18),this.bigDrawBtn=this.CreateComponent(j.W,19),this.rybeibao_sp_0044=this.CreateComponent(X.z,20),
this.ryxingkongmibao_sp_0003=this.CreateComponent(X.z,21),this.bar1=this.CreateComponent(W._,22),this.bar2=this.CreateComponent(W._,23),this.bar3=this.CreateComponent(W._,24),
this.continueLabel=this.CreateComponent($.Q,25),this.grid1.SetInitInfo("ui_baseitem",this.CreateDelegate(this.OnItemRefreshFun)),
this.grid1.OnReposition_set(this.CreateDelegate(this.OnGridReposition)),this.grid2.SetInitInfo("ui_baseitem",this.CreateDelegate(this.OnItemRefreshFun)),
this.grid2.OnReposition_set(this.CreateDelegate(this.OnGridReposition2)),this.grid3.SetInitInfo("ui_baseitem",this.CreateDelegate(this.OnItemRefreshFun)),
this.grid3.OnReposition_set(this.CreateDelegate(this.OnGridReposition))}OnItemRefreshFun(t){const e=new tt.j
return e.setId(t,null,0),e.SetIconType(et.s.REWARD_ICON_TYPE),e}OnAddToScene(){this.effGo.SetActive(!1),this.AddLis(),this.UpdateView()}UpdateView(){this.effGo.SetActive(!1),
this.effGo.SetActive(!0),this.isShowBtn=!1,this.isPlaying=!0,this.curshowRewardIdx=-1,this.curshowRewardIdx2=-1
0==z.Inst_get().gloryCallResultInfo.scoreItem2Num.Count()?this.UpdateItemLis():this.UpdateItemLis2(),this.continueLabel.textSet(`召唤${U.l.getNumStr(zt.Inst_get().sendTime)}次`)}
OnGridReposition(){for(const[t,e]of(0,Q.V5)(this.grid1.itemList))e.SetActive(!1)
for(const[t,e]of(0,Q.V5)(this.grid3.itemList))e.SetActive(!1)
this.StartRewardTimer()}OnGridReposition2(){for(const[t,e]of(0,Q.V5)(this.grid2.itemList))e.SetActive(!1)
this.StartRewardTimer2()}StartRewardTimer(){-1!=this.timerId&&this.ClearTimer(),this.timerId=Z.C.Inst_get().SetInterval(this.CreateDelegate(this.DrawTimerHanler),200)}
StartRewardTimer2(){-1!=this.timerId2&&this.ClearTimer2(),this.timerId2=Z.C.Inst_get().SetInterval(this.CreateDelegate(this.DrawTimerHanler2),200)}ClearTimer(){
-1!=this.timerId&&(Z.C.Inst_get().ClearInterval(this.timerId),this.timerId=-1)}ClearTimer2(){-1!=this.timerId2&&(Z.C.Inst_get().ClearInterval(this.timerId2),this.timerId2=-1)}
DrawTimerHanler(){this.curshowRewardIdx+=1
let t=!1
this.grid1.itemList[this.curshowRewardIdx]&&(t=!0,this.grid1.itemList[this.curshowRewardIdx].SetActive(!0)),this.grid3.itemList[this.curshowRewardIdx]&&(t=!0,
this.grid3.itemList[this.curshowRewardIdx].SetActive(!0)),0==t&&(this.ClearTimer(),this.curshowRewardIdx=-1)}DrawTimerHanler2(){this.curshowRewardIdx2+=1
let t=!1
this.grid2.itemList[this.curshowRewardIdx2]&&(t=!0,this.grid2.itemList[this.curshowRewardIdx2].SetActive(!0)),0==t&&(this.ClearTimer2(),this.curshowRewardIdx2=-1)}
ItemAnimEndHandle(t){null!=t&&null!=this.ret&&this.isShowBtn&&t>=this.ret.Count()-1&&(this.oneHuntBtn.node.SetActive(!0),this.tenHuntBtn.node.SetActive(!0),this.isPlaying=!1)}
Clear(){this.RemoveLis(),this.ClearTimer(),this.ClearTimer2(),super.Clear()}Destroy(){super.Destroy()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.continueBtn,this.CreateDelegate(this.OneHuntBtnHandle)),this.m_handlerMgr.AddClickEvent(this.confirmBtn,this.CreateDelegate(this.OnCloseView)),
this.m_handlerMgr.AddClickEvent(this.bigDrawBtn,this.CreateDelegate(this.OnBigDrawBtnHandle)),this.AddFullScreenCollider(this.node,this.CreateDelegate(this.OnCloseView))}
RemoveLis(){this.RemoveFullScreenCollider(this.node,this.CreateDelegate(this.OnCloseView))}OnCloseView(){zt.Inst_get().CloseResultView()}OnBigDrawBtnHandle(){
const t=z.Inst_get().gloryCallResultInfo
0==t.rewardVoList.Count()||0==t.scoreItem2Num.Count()?this.OnCloseView():this.UpdateView()}OneHuntBtnHandle(){zt.Inst_get().CloseResultView(),
zt.Inst_get().GoHandle(zt.Inst_get().sendTime)}TenHuntBtnHandle(){zt.Inst_get().CloseResultView(),zt.Inst_get().GoHandle(10)}UpdateItemLis(){this.bar1.node.SetActive(!1),
this.bar2.node.SetActive(!1),this.bar3.node.SetActive(!1),this.bar3.node.SetActive(!0)
const t=z.Inst_get().gloryCallResultInfo,e=new B.Z
for(let i=0;i<=t.rewardVoList.Count()-1;i++){this.desc1.textSet(""),this.desc2.textSet(""),this.desc3.textSet(it.x.Inst().getItemStrById(11043257))
const s=t.rewardVoList[i].bigReward.rewards
if(t.rewardVoList[i].isBigReward){e.Clear()
for(let n=0;n<=s.Count()-1;n++){const s=P.M.wrapReward(t.rewardVoList[i].bigReward.rewards[n])
e.Add(s)}return this.ryxingkongmibao_sp_0003.SetActive(!0),this.rybeibao_sp_0044.SetActive(!1),this.confirmBtn.SetActive(!1),this.continueBtn.SetActive(!1),
this.bigDrawBtn.SetActive(!0),this.grid3.data_set(e),void t.rewardVoList.RemoveAt(i)}for(let n=0;n<=s.Count()-1;n++){const s=P.M.wrapReward(t.rewardVoList[i].bigReward.rewards[n])
e.Add(s)}}this.ryxingkongmibao_sp_0003.SetActive(!1),this.rybeibao_sp_0044.SetActive(!0),this.confirmBtn.SetActive(!0),this.continueBtn.SetActive(!0),this.bigDrawBtn.SetActive(!1),
this.grid3.data_set(e)}UpdateItemLis2(){this.bar1.node.SetActive(!1),this.bar2.node.SetActive(!1),this.bar3.node.SetActive(!1)
const t=z.Inst_get().gloryCallResultInfo,e=new B.Z,i=new B.Z
let s=0
for(;s<t.rewardVoList.Count();){const i=t.rewardVoList[s].bigReward.rewards
if(t.rewardVoList[s].isBigReward){e.Clear()
for(let n=0;n<=i.Count()-1;n++){const i=P.M.wrapReward(t.rewardVoList[s].bigReward.rewards[n])
e.Add(i)}return this.ryxingkongmibao_sp_0003.SetActive(!0),this.rybeibao_sp_0044.SetActive(!1),this.confirmBtn.SetActive(!1),this.continueBtn.SetActive(!1),
this.bigDrawBtn.SetActive(!0),this.bar3.node.SetActive(!0),this.desc1.textSet(""),this.desc2.textSet(""),this.desc3.textSet(it.x.Inst().getItemStrById(11043257)),
this.grid3.data_set(e),void t.rewardVoList.RemoveAt(s)}for(let n=0;n<=i.Count()-1;n++){const i=P.M.wrapReward(t.rewardVoList[s].bigReward.rewards[n])
e.Add(i)}s+=1}for(const[e,s]of(0,Q.V5)(t.scoreItem2Num)){const t=new P.M(e)
t.showNum=!0,t.count=s,i.Add(t)}this.ryxingkongmibao_sp_0003.SetActive(!1),this.rybeibao_sp_0044.SetActive(!0),this.confirmBtn.SetActive(!0),this.continueBtn.SetActive(!0),
this.bigDrawBtn.SetActive(!1),this.bar1.node.SetActive(!0),this.bar2.node.SetActive(!0),this.desc1.textSet(it.x.Inst().getItemStrById(11043257)),
this.desc2.textSet(it.x.Inst().getItemStrById(11043258)),this.desc3.textSet(""),this.grid1.data_set(e),this.grid2.data_set(i)}}
var nt=i(3522),at=i(72005),ot=i(13113),lt=i(36334),rt=i(15518),ht=i(60130),dt=i(28287),ut=i(68662),ct=i(32759),_t=i(32208),It=i(51868),gt=i(85682),mt=i(18202),Ct=i(83540),St=i(79534),pt=i(53905),At=i(57522),ft=i(65772),yt=i(29479),Tt=i(33138),Rt=i(50426),vt=i(9057)
class wt extends vt.x{constructor(...t){super(...t),this.num=null,this.barSp=null,this.exchangeBtn=null,this.ui_baseitem=null,this.limit=null,this.fullIcon=null,this.redPoint=null,
this.barWidth=null,this.itemData=null,this.gloryCallInfo=null,this.exchangeNum=null}InitView(){super.InitView(),this.num=this.CreateComponent($.Q,1),
this.barSp=this.CreateComponent(at.w,2),this.exchangeBtn=this.CreateComponent(j.W,3),this.ui_baseitem=this.CreateComponentBinder(tt.j,4),this.limit=this.CreateComponent($.Q,5),
this.fullIcon=this.CreateComponent(X.z,6),this.redPoint=this.CreateComponent(X.z,7),this.barWidth=this.barSp.width()}SetData(t){this.itemData=t,this.AddListeners(),
this.UpdateItem()}AddListeners(){this.m_handlerMgr.AddClickEvent(this.exchangeBtn,this.CreateDelegate(this.OnBtnClick))}OnBtnClick(){
z.Inst_get().GetScoreById(this.itemData.gloryCallCfgId)>=this.itemData.gloryCallExchange?zt.Inst_get().SendCM_GloryCallExchange(this.itemData.gloryCallCfgId):L.y.inst.ClientSysMessage(11043259)
}UpdateItem(){this.gloryCallInfo=z.Inst_get().gloryCallInfo,this.ui_baseitem.SetData(this.itemData)
const t=z.Inst_get().GetScoreById(this.itemData.gloryCallCfgId)
let e=t/this.itemData.gloryCallExchange
e>1&&(e=1),this.barSp.widthSet(e*this.barWidth),this.num.textSet(`${t}/${this.itemData.gloryCallExchange}`),
this.exchangeNum=z.Inst_get().GetExchangeCountById(this.itemData.gloryCallCfgId),this.itemData.limitNum>0?this.exchangeNum>=this.itemData.limitNum?(this.exchangeBtn.SetActive(!1),
this.fullIcon.SetActive(!0)):(this.exchangeBtn.SetActive(!0),this.fullIcon.SetActive(!1),
this.limit.textSet(`兑换上限:[${U.l.txtGreenStr}]${this.exchangeNum}/${this.itemData.limitNum}[-]`)):(this.exchangeBtn.SetActive(!0),this.fullIcon.SetActive(!1),
this.limit.textSet("")),this.exchangeBtn.SetIsEnabled(t>=this.itemData.gloryCallExchange),this.redPoint.SetActive(t>=this.itemData.gloryCallExchange)}Clear(){super.Clear()}
Destroy(){super.Destroy()}}var Dt=i(43133),Et=i(57834),Lt=i(21554)
class Gt extends vt.x{constructor(...t){super(...t),this.itemData=null,this.numTxt=null,this.itemImg=null,this.remainTxt=null,this.collider=null,this.bigImg=null,
this.pre_eff_tx_ryzh003=null,this.pre_eff_tx_ryzh004=null,this.pre_eff_tx_ryzh005=null,this.pre_eff_tx_ryzh006=null,this.pre_eff_tx_ryzh007=null,this.pre_eff_tx_ryzh008=null,
this.effDic=null,this.data=null}InitView(){super.InitView(),this.numTxt=this.CreateComponent($.Q,1),this.itemImg=this.CreateComponent(at.w,2),
this.remainTxt=this.CreateComponent($.Q,3),this.collider=this.CreateComponent(Dt.V,4),this.bigImg=this.CreateComponent(at.w,5),this.pre_eff_tx_ryzh003=this.CreateComponent(X.z,6),
this.pre_eff_tx_ryzh004=this.CreateComponent(X.z,7),this.pre_eff_tx_ryzh005=this.CreateComponent(X.z,8),this.pre_eff_tx_ryzh006=this.CreateComponent(X.z,9),
this.pre_eff_tx_ryzh007=this.CreateComponent(X.z,10),this.pre_eff_tx_ryzh008=this.CreateComponent(X.z,11),this.effDic=new N.X,
this.effDic.LuaDic_AddOrSetItem(0,this.pre_eff_tx_ryzh003),this.effDic.LuaDic_AddOrSetItem(1,this.pre_eff_tx_ryzh004),this.effDic.LuaDic_AddOrSetItem(2,this.pre_eff_tx_ryzh005),
this.effDic.LuaDic_AddOrSetItem(3,this.pre_eff_tx_ryzh006),this.effDic.LuaDic_AddOrSetItem(4,this.pre_eff_tx_ryzh007),this.effDic.LuaDic_AddOrSetItem(5,this.pre_eff_tx_ryzh008)}
Destroy(){super.Destroy()}SetData(t){this.data=t,this.itemImg.node.SetActive(!1),this.bigImg.node.SetActive(!1),this.itemData=t,this.itemImg.node.SetActive(!0),
mt.g.SetItemIcon(this.itemImg.FatherId,this.itemImg.ComponentId,this.itemData.cfgData_get().icon,Ct.b.eItem)
for(let t=0;t<=5;t++)this.effDic[t].SetActive(!1)
this.AddLis()}ShowSpecialNum(){this.numTxt.SetActive(!0),this.numTxt.textSet(this.itemData.SpecialNumStr)}ShowEffect(){const t=this.itemData.cfgData_get().quality
this.effDic[t]&&this.effDic[t].SetActive(!0)}SetScale(t){this.itemImg.node.transform.SetLocalScaleXYZ(t,t,t)}ClickHandle(){Lt.J.Inst_get().ShowItemTip(this.itemData)}AddLis(){
Et.i.Get(this.itemImg.node).RegistonClick(this.CreateDelegate(this.ClickHandle)),Et.i.Get(this.bigImg.node).RegistonClick(this.CreateDelegate(this.ClickHandle))}RemoveLis(){
Et.i.Get(this.itemImg.node).RemoveonClick(this.CreateDelegate(this.ClickHandle)),Et.i.Get(this.bigImg.node).RemoveonClick(this.CreateDelegate(this.ClickHandle))}Clear(){
this.data=null,this.RemoveLis(),super.Clear()}}class Ot extends It.${constructor(){super(),this.timeTxt=null,this.offset=null,this.timeTipBtn=null,this.goOneBtn=null,
this.goTenBtn=null,this.animTog=null,this.icon1=null,this.icon2=null,this.tenRedPoint=null,this.oneRedPoint=null,this.shopRedPoint=null,this.left=null,this.right=null,
this.shopBtn=null,this.bigPrizeDesc=null,this.topDesc3=null,this.exchangeView=null,this.exchangeGrid=null,this.rewardGrid=null,this.rewardView=null,this.showGrid=null,
this.bigPrizeItem1=null,this.bigPrizeItem2=null,this.exchangeTimeTxt=null,this.rewardSp=null,this.exchangeSp=null,this.rewardTween=null,this.exchangeTween=null,
this.itemNumLabel1=null,this.itemNumLabel2=null,this.itemNumLabel3=null,this.topDesc2=null,this.exchangeRedPoint=null,this.empty=null,this.topDesc3Bg=null,this.topDesc3Sp1=null,
this.topDesc3Sp2=null,this.bigPrizeSp1=null,this.bigPrizeSp2=null,this.effect=null,this.pos0=null,this.pos1=null,this.pos2=null,this.eff1=null,this.eff0=null,this.eff2=null,
this.empty0=null,this.empty1=null,this.empty2=null,this.isShowReward=!1,this.isShowExchange=!1,this.isPlayingAnim=!1,this.bigPrizeMininum=null,this.endPos=null,
this.gloryCallInfo=null,this.delay=null,this.effTimer=null,this.countDownTimer=null
const t=z.Inst_get().GetActId()
this.bigPrizeMininum=1915==t?350:F.D.getInstance().GetIntValue("GLORYCALL:MINIMUN")}InitView(){super.InitView(),this.timeTxt=this.CreateComponent($.Q,3),
this.offset=this.CreateComponent(X.z,10),this.timeTipBtn=this.CreateComponent(j.W,11),this.goOneBtn=this.CreateComponent(j.W,13),this.goTenBtn=this.CreateComponent(j.W,14),
this.animTog=this.CreateComponent(_t.r,15),this.icon1=this.CreateComponent(at.w,17),this.icon2=this.CreateComponent(at.w,18),this.tenRedPoint=this.CreateComponent(X.z,19),
this.oneRedPoint=this.CreateComponent(X.z,22),this.shopRedPoint=this.CreateComponent(X.z,23),this.left=this.CreateComponent(ot.T,25),this.right=this.CreateComponent(ot.T,26),
this.shopBtn=this.CreateComponent(j.W,27),this.bigPrizeDesc=this.CreateComponent($.Q,29),this.topDesc3=this.CreateComponent($.Q,30),this.exchangeView=this.CreateComponent(X.z,31),
this.exchangeGrid=this.CreateComponent(J.A,32),this.rewardGrid=this.CreateComponent(J.A,33),this.rewardView=this.CreateComponent(X.z,34),this.showGrid=this.CreateComponent(J.A,35),
this.bigPrizeItem1=this.CreateComponentBinder(Gt,36),this.bigPrizeItem2=this.CreateComponentBinder(Gt,37),this.exchangeTimeTxt=this.CreateComponent($.Q,38),
this.rewardSp=this.CreateComponent(at.w,39),this.exchangeSp=this.CreateComponent(at.w,40),this.rewardTween=this.CreateComponent(ct.c,41),
this.exchangeTween=this.CreateComponent(ct.c,42),this.itemNumLabel1=this.CreateComponent($.Q,43),this.itemNumLabel2=this.CreateComponent($.Q,44),
this.itemNumLabel3=this.CreateComponent($.Q,45),this.topDesc2=this.CreateComponent($.Q,46),this.exchangeRedPoint=this.CreateComponent(X.z,47),
this.empty=this.CreateComponent(X.z,48),this.topDesc3Bg=this.CreateComponent(at.w,49),this.topDesc3Sp1=this.CreateComponent(X.z,50),this.topDesc3Sp2=this.CreateComponent(X.z,51),
this.bigPrizeSp1=this.CreateComponent(X.z,52),this.bigPrizeSp2=this.CreateComponent(X.z,53),this.effect=this.CreateComponent(X.z,54),this.pos0=this.CreateComponent(X.z,55),
this.pos1=this.CreateComponent(X.z,56),this.pos2=this.CreateComponent(X.z,57),this.eff1=this.CreateComponent(X.z,58),this.eff0=this.CreateComponent(X.z,59),
this.eff2=this.CreateComponent(X.z,60),this.empty0=this.CreateComponent(X.z,61),this.empty1=this.CreateComponent(X.z,62),this.empty2=this.CreateComponent(X.z,63),
this.exchangeGrid.SetInitInfo("ui_glorycallexchangeitem",null,wt),this.rewardGrid.SetInitInfo("ui_baseitem",null,tt.j),this.showGrid.SetInitInfo("ui_glorycallitem",null,Gt),
this.showGrid.OnReposition_set(this.CreateDelegate(this.OnReposition)),this.itemNumLabel1.SetActive(!1),this.itemNumLabel2.SetActive(!1),this.itemNumLabel3.SetActive(!1),
this.topDesc2.SetActive(!1),ht.O.SetAnchorPos(this.left,!0,!1,0),ht.O.SetAnchorPos(this.right,!1,!1,0),this.endPos=this.exchangeSp.GetPosition()}OnReposition(){
for(let t=0;t<=this.showGrid.itemList.Count()-1;t++){this.showGrid.itemList[t].ShowEffect()}}ShowCurrencyBar_get(){return dt._.ShowGOLD_GLORYCALL}SetData(){
this.gloryCallInfo=z.Inst_get().gloryCallInfo
const t=Tt.f.Inst().getItemById(z.Inst_get().GetKeyItemId())
null!=t&&(mt.g.SetItemIcon(this.icon1.FatherId,this.icon1.ComponentId,t.icon,Ct.b.eItem,!1),mt.g.SetItemIcon(this.icon2.FatherId,this.icon2.ComponentId,t.icon,Ct.b.eItem,!1)),
this.topDesc3.textSet(it.x.Inst().getItemStrById(11043253)),this.topDesc3Bg.widthSet(this.topDesc3.width()+230),
this.topDesc3Sp1.SetLocalPositionXYZ(-this.topDesc3.width()/2-25,-8.8,0),this.topDesc3Sp2.SetLocalPositionXYZ(this.topDesc3.width()/2+25,-8.8,0),this.effect.SetActive(!1),
this.AddLis(),this.UpdateInfo(),this.InitRedPoint(),this.InitLeftView()}UpdateView(){}TimeTipBtnHandle(){const t=new pt.w
t.infoId="GLORYCALL:TIPS",t.width=384,t.position=new St.P(-545,287,0),ft.Q.Inst_get().Open(t)}Clear(){this.RemoveLis(),this.ClearEndTimeHandle(),this.ClearEffTimeHandle(),
super.Clear()}Destroy(){super.Destroy()}AddLis(){this.m_handlerMgr.AddClickEvent(this.timeTipBtn,this.CreateDelegate(this.TimeTipBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.animTog,this.CreateDelegate(this.AnimToggleHandle)),this.m_handlerMgr.AddClickEvent(this.goOneBtn,this.CreateDelegate(this.GoOneBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.goTenBtn,this.CreateDelegate(this.GoTenBtnHandle)),this.m_handlerMgr.AddClickEvent(this.shopBtn,this.CreateDelegate(this.ShopBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.rewardSp.node,this.CreateDelegate(this.RewardBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.exchangeSp.node,this.CreateDelegate(this.ExchangeBtnHandle)),
this.m_handlerMgr.AddEventMgr(_.g.BAG_UPDATE,this.CreateDelegate(this.BagUpdateHandle)),z.Inst_get().AddEventHandler(O.OpenSuccess,this.CreateDelegate(this.OpenSuccessHandle)),
z.Inst_get().AddEventHandler(O.UpdateInfo,this.CreateDelegate(this.UpdateRewardInfo)),w.f.Inst.AddCallback(v.t.GLORY_CALL_SHOP,this.CreateDelegate(this.UpdateRedPoint)),
w.f.Inst.AddCallback(v.t.GLORY_CALL_EXCHANGE,this.CreateDelegate(this.UpdateRedPoint))}BagUpdateHandle(){z.Inst_get().IsSatisfyTenNum()?(this.oneRedPoint.SetActive(!1),
this.tenRedPoint.SetActive(!0)):z.Inst_get().IsSatisfyKeyNum()?(this.oneRedPoint.SetActive(!0),this.tenRedPoint.SetActive(!1)):(this.oneRedPoint.SetActive(!1),
this.tenRedPoint.SetActive(!1))}InitRedPoint(t,e){const i=w.f.Inst.GetData(v.t.GLORY_CALL_EXCHANGE),s=w.f.Inst.GetData(v.t.GLORY_CALL_SHOP)
this.exchangeRedPoint.SetActive(i.show),this.shopRedPoint.SetActive(s.show)}InitLeftView(){const t=z.Inst_get().redPointInfo
t&&(this.isShowReward=t.showReward,0==this.isShowReward?(this.rewardSp.spriteNameSet("ryryzh_bt_0004"),
this.rewardTween.ResetToBeginning()):(this.rewardSp.spriteNameSet("ryryzh_bt_0003"),this.rewardTween.PlayForward(),
zt.Inst_get().SendCM_GloryCallRedPoint(t.businessmanRedPoint,t.scoreRedPoint)))}UpdateRedPoint(t,e){
t==v.t.GLORY_CALL_EXCHANGE?this.exchangeRedPoint.SetActive(e):t==v.t.GLORY_CALL_SHOP&&this.shopRedPoint.SetActive(e)}GetDirectData(){const t=yt.X.Inst_get().directBuyList
for(let e=0;e<=t.Count()-1;e++){const i=t[e]
if(i.id==Rt.Y.Inst_get().directBuyId&&i.CheckShow())return i}}OpenSuccessHandle(t){this.effect.SetActive(!1),this.itemNumLabel1.SetActive(!1),this.itemNumLabel2.SetActive(!1),
this.itemNumLabel3.SetActive(!1),z.Inst_get().IsJumpAnim()?(this.isPlayingAnim=!1,this.OnJumpAnim()):(this.isPlayingAnim=!0,this.eff0.SetActive(!1),this.eff1.SetActive(!1),
this.eff2.SetActive(!1),this.effect.SetActive(!0),this.showGrid.data_set(null),this.empty0.SetActive(!0),this.empty1.SetActive(!0),this.empty2.SetActive(!0),
this.empty.SetActive(!0),this.delay=0,this.ClearEffTimeHandle(),this.effTimer=Z.C.Inst_get().SetInterval(this.CreateDelegate(this.OnPlayAnim),250,-1),this.OnPlayAnim())}
OnPlayAnim(){if(0==this.delay)this.eff0.SetActive(!0)
else if(250==this.delay)this.eff1.SetActive(!0)
else if(500==this.delay)this.eff2.SetActive(!0)
else if(2250==this.delay)this.ShowOneItem(0)
else if(2500==this.delay)this.ShowOneItem(1)
else if(this.delay>=2750){this.ShowOneItem(2),this.ClearEffTimeHandle(),this.UpdateRewardInfo()
z.Inst_get().gloryCallResultInfo.rewardVoList.Count()>0?this.effTimer=Z.C.Inst_get().SetInterval(this.CreateDelegate(this.OpenResultView),500,1):this.isPlayingAnim=!1}
this.delay+=250}ShowOneItem(t){const e=z.Inst_get().gloryCallInfo.showItemVoList
let i=this.showGrid.data_get()
null==i&&(i=new B.Z)
const s=e[t],n=K.Inst_get().GetResById(s.id)
if(0==s.score){this[`itemNumLabel${t+1}`].SetActive(!1)
const e=Y.A.GetReward(n.rewardDefs).GetAllRewardList()
i.Add(e[0])}else{this[`itemNumLabel${t+1}`].textSet(`碎片*${s.score}`),this[`itemNumLabel${t+1}`].SetActive(!0)
const e=new P.M(n.chipItem)
i.Add(e)
const a=this[`pos${t}`].GetPosition()
At.h.Inst_get().PlayFlyItem(a,this.endPos,n.chipItem,null,null,null,0),St.P.Recyle(a)}this[`empty${t}`].SetActive(!1),this.showGrid.data_set(i)}OnJumpAnim(){
const t=z.Inst_get().gloryCallResultInfo,e=z.Inst_get().gloryCallInfo.showItemVoList
for(let t=0;t<=e.Count()-1;t++){const i=e[t]
if(0!=i.score){const e=K.Inst_get().GetResById(i.id),s=this[`pos${t}`].GetPosition()
At.h.Inst_get().PlayFlyItem(s,this.endPos,e.chipItem,null,null,null,0),St.P.Recyle(s)}}t.rewardVoList.Count()>0&&this.OpenResultView(),this.ClearEffTimeHandle(),
this.UpdateRewardInfo()}OpenResultView(){zt.Inst_get().OpenResultView(),this.isPlayingAnim=!1}RemoveLis(){
z.Inst_get().RemoveEventHandler(O.OpenSuccess,this.CreateDelegate(this.OpenSuccessHandle)),z.Inst_get().RemoveEventHandler(O.UpdateInfo,this.CreateDelegate(this.UpdateRewardInfo)),
w.f.Inst.RemoveCallback(v.t.GLORY_CALL_SHOP,this.CreateDelegate(this.UpdateRedPoint)),w.f.Inst.RemoveCallback(v.t.GLORY_CALL_EXCHANGE,this.CreateDelegate(this.UpdateRedPoint))}
GoOneBtnHandle(){this.isPlayingAnim||zt.Inst_get().GoHandle(1)}GoTenBtnHandle(){this.isPlayingAnim||zt.Inst_get().GoHandle(10)}RewardBtnHandle(){
0==this.isShowReward?(this.rewardSp.spriteNameSet("ryryzh_bt_0003"),this.rewardTween.PlayForward()):(this.rewardSp.spriteNameSet("ryryzh_bt_0004"),this.rewardTween.PlayReverse()),
this.isShowReward=!this.isShowReward}ExchangeBtnHandle(){const t=z.Inst_get().redPointInfo
t&&t.scoreRedPoint&&(zt.Inst_get().SendCM_GloryCallRedPoint(t.businessmanRedPoint,!1),w.f.Inst.SetState(v.t.GLORY_CALL_EXCHANGE,!1)),
0==this.isShowExchange?(this.exchangeSp.spriteNameSet("ryryzh_bt_0002"),this.exchangeTween.PlayForward()):(this.exchangeSp.spriteNameSet("ryryzh_bt_0001"),
this.exchangeTween.PlayReverse()),this.isShowExchange=!this.isShowExchange}ShopBtnHandle(){const t=z.Inst_get().redPointInfo
t&&t.businessmanRedPoint&&(zt.Inst_get().SendCM_GloryCallRedPoint(!1,t.scoreRedPoint),w.f.Inst.SetState(v.t.GLORY_CALL_SHOP,!1)),h.N.inst.OpenUIByShortCutID(gt.D.GLORYCALL_SHOP)}
AnimToggleHandle(){zt.Inst_get().SendSetAnim(this.animTog.GetValue())}UpdateRewardInfo(){if(this.goOneBtn.node.SetActive(!1),this.goTenBtn.node.SetActive(!1),
this.animTog.node.SetActive(!1),this.shopBtn.node.SetActive(!1),z.Inst_get().IsActivityOpen()){this.goOneBtn.node.SetActive(!0),this.goTenBtn.node.SetActive(!0),
this.animTog.node.SetActive(!0)
const t=`召唤一次(     ${z.Inst_get().GetConsumeNum(1)})`
this.BagUpdateHandle()
const e=`召唤十次(     ${z.Inst_get().GetConsumeNum(10)})`
this.goOneBtn.SetText(t),this.goTenBtn.SetText(e),this.animTog.SetValue(z.Inst_get().IsJumpAnim()),this.shopBtn.node.SetActive(!0)}const t=K.Inst_get().GetRewardLis()
this.rewardGrid.data_set(t)
const e=K.Inst_get().GetExchangeLis()
this.exchangeGrid.data_set(e)
const i=z.Inst_get().gloryCallInfo.showItemVoList,s=new B.Z
for(let t=0;t<=i.Count()-1;t++){const e=i[t],n=K.Inst_get().GetResById(e.id)
if(0==e.score){this[`itemNumLabel${t+1}`].SetActive(!1)
const e=Y.A.GetReward(n.rewardDefs).GetAllRewardList()
s.Add(e[0])}else{this[`itemNumLabel${t+1}`].textSet(`碎片*${e.score}`),this[`itemNumLabel${t+1}`].SetActive(!0)
const i=new P.M(n.chipItem)
s.Add(i)}}this.empty.SetActive(0==s.Count()),this.empty0.SetActive(!0),this.empty1.SetActive(!0),this.empty2.SetActive(!0),this.showGrid.data_set(s)
const n=K.Inst_get().GetBigPrizeItem()
if(this.bigPrizeItem1.SetData(n),this.bigPrizeItem2.SetData(n),this.bigPrizeItem2.ShowSpecialNum(),this.bigPrizeMininum-this.gloryCallInfo.drawMustRewardNum<=0){
const t=it.x.Inst().getItemStrById(11043261)
this.bigPrizeDesc.textSet(t)}else{let t=it.x.Inst().getItemStrById(11043252)
t=u.M.Replace(t,"{0}",this.bigPrizeMininum-this.gloryCallInfo.drawMustRewardNum),this.bigPrizeDesc.textSet(t)}
this.bigPrizeSp1.SetLocalPositionXYZ(-this.bigPrizeDesc.width()/2-18,-8,0),this.bigPrizeSp2.SetLocalPositionXYZ(this.bigPrizeDesc.width()/2+18,-8,0)}UpdateInfo(){
this.ClearEndTimeHandle(),this.countDownTimer=Z.C.Inst_get().SetInterval(this.CreateDelegate(this.RefreshEndTime),1e3,-1),this.RefreshEndTime(),this.UpdateRewardInfo()}
RefreshEndTime(){const t=H.i.ins.huodong_dict.LuaDic_GetItem(z.Inst_get().GetActId())
let e=0
null!=t&&(e=t.endTime.ToNum()),e>0&&(e=.001*e-ut.D.serverTime_get()),e>0?this.timeTxt.textSet(`结束倒计时:[047104]${U.l.GetDateFormatBitContainZero(e,4)}[-]`):this.timeTxt.textSet("已结束")
let i=0
null!=t&&(i=t.delayTime.ToNum()),i>0&&(i=.001*i-ut.D.serverTime_get()),i>0?this.exchangeTimeTxt.textSet(`兑换倒计时:[5FB470]${U.l.GetDateFormatBitContainZero(i,4)}[-]`):(this.exchangeTimeTxt.textSet("已结束"),
this.ClearEndTimeHandle())}ClearEndTimeHandle(){null!=this.countDownTimer&&(Z.C.Inst_get().ClearInterval(this.countDownTimer),this.countDownTimer=null)}ClearEffTimeHandle(){
null!=this.effTimer&&(Z.C.Inst_get().ClearInterval(this.effTimer),this.effTimer=null)}}class bt extends rt.k{constructor(){super(),this.closeBtn=null,this.titleLabel=null,
this.closeBtnAni=null,this.leftWidget=null,this.bg=null,this._model=null,this._model=z.Inst_get()}InitView(){super.InitView(),this.closeBtn=this.CreateComponent(j.W,1),
this.titleLabel=this.CreateComponent($.Q,2),this.closeBtnAni=this.CreateComponent(nt.k,3),this.leftWidget=this.CreateComponent(ot.T,4),this.bg=this.CreateComponent(at.w,5),
this._subPanelDatas.Add(lt.b.New(new B.Z(["ui_glorycallmainview"]),this,Ot))}OnAddToScene(){const t=M.d.Inst_get().getItemById(V.x.GLORY_CALL)
this.titleLabel.textSet(t.name),this.ShowSubView(0),this.UpdateAnchors(),this.AddLis()}Clear(){this.RemoveLis(),super.Clear()}Destroy(){super.Destroy()}OnCloseClick(){
zt.Inst_get().CloseView()}ShowCurrencyBar_get(){const t=this.GetSubView(0)
return t&&t.ShowCurrencyBar_get?t.ShowCurrencyBar_get():dt._.ShowAll}IsFirstPanel_Get(){return!0}AddLis(){
this.m_handlerMgr.AddEventMgr(_.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors)),this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.PlayCloseAni))}
RemoveLis(){}UpdateAnchors(){ht.O.SetAnchorPos(this.leftWidget,!0,!1,0)}PlayCloseAni(t,e,i){null!=this.closeBtnAni&&(this.closeBtnAni.SetResetOnPlay(!0),
this.closeBtnAni.Play(!0,!1)),null==i&&(i=this.CreateDelegate(this.OnCloseClick)),null!=i&&this.m_handlerMgr.SetInterval(i,100,1)}}
var Bt=i(35128),Nt=i(86133),Pt=i(62370),Mt=i(30267),Vt=i(86209),kt=i(7601),xt=i(52513),Ht=i(31896),Ut=i(19519),Ft=i(86577)
class Yt extends vt.x{constructor(...t){super(...t),this.huodongMallVo=null,this.huodongMallCfgVo=null,this.text_limit_time=null,this.text_name=null,this.img_discount=null,
this.btn_buy=null,this.text_buy=null,this.grid_item=null,this.consume_obj=null,this.img_consume_icon=null,this.text_consume_num=null,this.img_sell_over=null,
this.refreshTimeTxt=null,this.discountLabel=null,this.countDownId=null}InitView(){super.InitView(),this.text_limit_time=this.CreateComponent($.Q,1),
this.text_name=this.CreateComponent($.Q,2),this.img_discount=this.CreateComponent(at.w,3),this.btn_buy=this.CreateComponent(at.w,4),this.text_buy=this.CreateComponent($.Q,5),
this.grid_item=this.CreateComponent(J.A,6),this.consume_obj=this.CreateComponent(Mt.V,7),this.img_consume_icon=this.CreateComponent(at.w,8),
this.text_consume_num=this.CreateComponent($.Q,9),this.img_sell_over=this.CreateComponent(at.w,10),this.refreshTimeTxt=this.CreateComponent($.Q,11),
this.discountLabel=this.CreateComponent($.Q,12),this.grid_item.SetInitInfo("ui_baseitem",this.CreateDelegate(this.OnInitItem))}OnInitItem(t){const e=new tt.j
return e.SetIconType(et.s.NORMAL_ICON_TYPE),e.setId(t,null,0),e.SetBgSize(52,52),e.SetIconSize(52,52),e}SetData(t){this.huodongMallVo=t,
this.huodongMallCfgVo=k.Z.ins.GetVoByMallId(this.huodongMallVo.mallId),this.AddLis(),this.Update()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.btn_buy,this.CreateDelegate(this.OnClickBtnBuy)),
this.m_handlerMgr.AddEventMgr(_.g.HUODONG_MALL_BUY_CNT_CHANGE,this.CreateDelegate(this.OnBuyCntChange))}RemoveLis(){}Clear(){super.Clear(),this.grid_item.Clear(),this.RemoveLis()}
Destroy(){this.grid_item.Destroy(),super.Destroy()}Update(){this.img_sell_over.SetActive(!1),this.img_discount.node.SetActive(!1),this.refreshTimeTxt.node.SetActive(!1),
this.img_consume_icon.SetActive(!1),-1==this.huodongMallVo.limit?this.text_limit_time.SetActive(!1):(this.text_limit_time.SetActive(!0),this.text_limit_time.textSet(Pt.o.Format((0,
Nt.T)("限购{0}次"),this.huodongMallVo.limit))),this.text_name.textSet(this.huodongMallCfgVo.name)
const t=new B.Z
for(let e=0;e<=this.huodongMallVo.reward.rewards.Count()-1;e++)t.Add(P.M.wrapReward(this.huodongMallVo.reward.rewards[e]))
this.grid_item.data_set(t),this.discountLabel.node.SetActive(!1),this.img_discount.node.SetActive(!0),
1==this.huodongMallCfgVo.label?this.img_discount.spriteNameSet("ryjbsd_sp_0012"):2==this.huodongMallCfgVo.label?(this.discountLabel.node.SetActive(!0),
this.img_discount.spriteNameSet("ryjbsd_sp_0027"),
this.discountLabel.textSet(`${this.huodongMallCfgVo.discount}%`)):3==this.huodongMallCfgVo.label?this.img_discount.spriteNameSet("ryjbsd_sp_0011"):this.img_discount.node.SetActive(!1),
this.img_discount.MakePixelPerfect(),
this.btn_buy.SetActive(!0),-1!=this.huodongMallVo.limit&&R.P.ins.GetBuyTimesByMallId(this.huodongMallVo.mallId)>=this.huodongMallVo.limit?(this.btn_buy.spriteNameSet("rycommon_bt_0026"),
this.text_consume_num.textSet("[4E443B]已领取[-]"),Ft.T.Inst_get().IsCanRefresh(this.huodongMallVo.nextRefreshTime)?(this.text_limit_time.SetActive(!1),
H.i.ins.GetState(z.Inst_get().GetActId())==x.V.OPEN?this.StartCountDown():this.text_consume_num.textSet("[4E443B]已结束[-]")):(this.btn_buy.SetActive(!1),
this.img_sell_over.SetActive(!0))):(this.img_sell_over.SetActive(!1),H.i.ins.GetState(z.Inst_get().GetActId())==x.V.OPEN?(this.img_consume_icon.SetActive(!0),
this.btn_buy.spriteNameSet("rycommon_bt_0024"),this.UpdateConsume()):(this.btn_buy.spriteNameSet("rycommon_bt_0026"),this.text_consume_num.textSet("[4E443B]已结束[-]")))}
UpdateConsume(){if(this.text_consume_num.SetActive(!0),this.img_consume_icon.SetActive(!0),0!=this.huodongMallVo.rechargeId){
const t=xt.O.Inst().getConfig(this.huodongMallVo.rechargeId),e=kt.W.Inst.GetCurSystem(),i=t.platformCurrency[e]
this.text_consume_num.textSet(`${i}元`),this.img_consume_icon.SetActive(!1)}else{const t=this.huodongMallVo.Consume_Get().GetItemDataByType()
this.text_consume_num.textSet(Vt.w.Instance.ConvertNumToString(t.count)),null!=t.virtualItemData_get()?this.img_consume_icon.spriteNameSet(Ut.J.GetCurrencyIconUrl(t.virtualItemData_get().virtualTypeStr)):this.img_consume_icon.spriteNameSet("")
}this.refreshTimeTxt.node.SetActive(!1),this.consume_obj.CallReposition()}OnClickBtnBuy(){
-1!=this.huodongMallVo.limit&&R.P.ins.GetBuyTimesByMallId(this.huodongMallVo.mallId)>=this.huodongMallVo.limit||(H.i.ins.GetState(z.Inst_get().GetActId())==x.V.OPEN?0!=this.huodongMallCfgVo.rechargeId?Ht.t.inst.Buy(xt.O.Inst().getConfig(this.huodongMallVo.rechargeId)):y.$.ins.CheckConsumeEnough(this.huodongMallVo.Consume_Get())&&y.$.ins.CM_ActivityMallBuy(this.huodongMallVo.mallId):L.y.inst.ClientSysStrMsg("活动已结束"))
}OnBuyCntChange(t){t==this.huodongMallVo.mallId&&this.Update()}StartCountDown(){this.ClearCountDown(),this.refreshTimeTxt.node.SetActive(!0),
this.countDownId=Z.C.Inst_get().SetInterval(this.CreateDelegate(this.RefreshTime),1e3,-1),this.RefreshTime()}ClearCountDown(){this.refreshTimeTxt.node.SetActive(!1),
null!=this.countDownId&&(Z.C.Inst_get().ClearInterval(this.countDownId),this.countDownId=null)}RefreshTime(){
if(null!=this.huodongMallVo.nextRefreshTime&&this.huodongMallVo.nextRefreshTime.ToNum()>0){const t=this.huodongMallVo.nextRefreshTime.ToNum()-ut.D.serverTime_get()
if(t>0){const e=U.l.GetDateFormatEX(t,!0,!0)
this.refreshTimeTxt.textSet(e)}else this.refreshTimeTxt.node.SetActive(!1)}
H.i.ins.GetState(z.Inst_get().GetActId())!=x.V.END&&H.i.ins.GetState(z.Inst_get().GetActId())!=x.V.CLOSE||(this.ClearCountDown(),this.Update())}}class Kt extends q.f{
constructor(...t){super(...t),this.grid_item=null,this.notMallGo=null,this.timeTxt=null,this.closeBtn=null,this.ryjlbz_sp_0031=null,this.ryryzh_sp_0012=null,this.interval=null}
InitView(){super.InitView(),this.grid_item=this.CreateComponent(J.A,1),this.notMallGo=this.CreateComponent(X.z,2),this.timeTxt=this.CreateComponent($.Q,3),
this.closeBtn=this.CreateComponent(j.W,4),this.ryjlbz_sp_0031=this.CreateComponent(X.z,5),this.ryryzh_sp_0012=this.CreateComponent(X.z,6),
this.grid_item.SetInitInfo("ui_dragontreasure_treasureshopitem",null,Yt),this.ryjlbz_sp_0031.SetActive(!1),this.ryryzh_sp_0012.SetActive(!0)}OnAddToScene(){this.AddLis(),
this.m_handlerMgr.AddEventMgr(_.g.HUODONG_MALL_CHANGE,this.CreateDelegate(this.UpdateView)),
null==this.interval&&(this.interval=Z.C.Inst_get().SetInterval(this.CreateDelegate(this.OnEachSec),1e3)),this.UpdateView(),this.OnEachSec()}ShowCurrencyBar_get(){
return dt._.ShowGOLD_GLORYCALL}AddLis(){this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.OnCloseBtnHandle))}OnCloseBtnHandle(){
zt.Inst_get().CloseTreasureShopView()}RemoveLis(){}Clear(){super.Clear(),null!=this.interval&&(Z.C.Inst_get().ClearInterval(this.interval),this.interval=null)}Destroy(){
super.Destroy()}UpdateView(){const t=R.P.ins.GetMallListByHuoDongId(z.Inst_get().GetActId()),e=new B.Z
for(let i=0;i<=t.Count()-1;i++){const s=t[i]
t[i].CheckView()&&t[i].CheckBuy()&&s.type==T.f.RECHARGE_TYPE&&e.Add(t[i])}this.notMallGo.SetActive(0==e.Count()),this.grid_item.data_set(e)}OnEachSec(){
const t=H.i.ins.huodong_dict.LuaDic_GetItem(z.Inst_get().GetActId())
if(null!=t){const e=Bt.p.FloorToInt(t.endTime.ToNum()/1e3)-ut.D.serverTime_get()
e>0?this.timeTxt.textSet(U.l.GetDateFormatEX(e,!0,!0)):zt.Inst_get().CloseGloryCallShopView()}}}class zt{constructor(){this.sendTime=null,this.AddLis(),this.RegisterProtocol()}
static Inst_get(){return null==zt.inst&&(zt.inst=new zt),zt.inst}AddLis(){s.i.Inst.AddEventHandler(_.g.BAG_UPDATE,this.CreateDelegate(this.BagUpdate))}BagUpdate(){
w.f.Inst.SetState(v.t.GLORY_CALL_DRAW,z.Inst_get().IsSatisfyKeyNum())}RegisterProtocol(){o.j.Inst.F_Register(-12295,S.O,this.CreateDelegate(this.SM_GloryCallExchangeHandle)),
o.j.Inst.F_Register(-12296,p.D,this.CreateDelegate(this.SM_GloryCallInfoHandle)),o.j.Inst.F_Register(-12298,f.d,this.CreateDelegate(this.SM_GloryCallRewardHandle)),
o.j.Inst.F_Register(-12301,A.f,this.CreateDelegate(this.SM_GloryCallRedPointHandle))}SM_GloryCallRewardHandle(t){z.Inst_get().SetGloryCallResultInfo(t),
z.Inst_get().RaiseEvent(O.OpenSuccess,t)}SM_GloryCallExchangeHandle(t){z.Inst_get().SetExchangeInfo(t),z.Inst_get().RaiseEvent(O.UpdateInfo,t)}SM_GloryCallInfoHandle(t){
z.Inst_get().SetGloryCallInfo(t),z.Inst_get().RaiseEvent(O.UpdateInfo,t)}SM_GloryCallRedPointHandle(t){z.Inst_get().SetGloryCallRedPiont(t)}SendCM_GloryCall(t){
1==t?this.SendCM_OneDrawGloryCall():this.SendCM_TenDrawGloryCall()}SendCM_OneDrawGloryCall(){const t=new m.t
l.C.Inst.F_SendMsg(t)}SendCM_TenDrawGloryCall(){const t=new C.O
l.C.Inst.F_SendMsg(t)}SendCM_GloryCallRedPoint(t,e){const i=new g.m
i.businessmanRedPoint=t,i.scoreRedPoint=e,i.isShowReward=!1,l.C.Inst.F_SendMsg(i)}SendCM_GloryCallExchange(t){const e=new I.x
e.id=t,l.C.Inst.F_SendMsg(e)}SendSetAnim(t){let e=0
t&&(e=1),D.p.inst.SendClientLogicSetting(E.R.GLORY_CALL_JUMP_ANIM,e)}OpenView(t=null){z.Inst_get().defaultView=t
const e=new r.v
e.isShowMask=!0,e.isDefaultUITween=!0,e.isSelfTween=!1,e.viewClass=bt,h.N.inst.OpenById(d.I.GloryCallRootView,null,null,e)}CloseView(){h.N.inst.CloseById(d.I.GloryCallRootView)}
GoHandle(t){this.sendTime=t
const e=z.Inst_get().GetKeyItemId(),i=c.g.Inst_get().GetItemNum(e),n=z.Inst_get().GetConsumeNum(t)
if(i<n){const t=z.Inst_get().GetActId()
if(0==t)return void L.y.inst.ClientSysMessage(11042910)
y.$.ins.CheckItemEnough(t,e,n)||s.i.Inst.AddEventHandler(_.g.HUODONG_MALL_BUY_SUCCESS,this.CreateDelegate(this.BuySuccessHandle))}else this.SendCM_GloryCall(t)}GetConsume(t){
if(!u.M.IsNullOrEmpty(t)){const e=n.d.parseJsonObjectWithFix(t,"rewardValues"),i=a.t.decode(e,G.h)
return i.Parse(),i.GetItemList()}}BuySuccessHandle(t){const e=this.GetMallInfo()
if(null!=e&&t.mallId==e.mallId){s.i.Inst.RemoveEventHandler(_.g.HUODONG_MALL_BUY_SUCCESS,this.CreateDelegate(this.BuySuccessHandle))
const t=z.Inst_get().GetKeyItemId()
c.g.Inst_get().GetItemNum(t)>=z.Inst_get().GetConsumeNum(this.sendTime)&&this.SendCM_GloryCall(this.sendTime)}}GetMallInfo(){
return R.P.ins.GetVoByHuodongIdAndType(z.Inst_get().GetActId(),T.f.TICKET_TYPE)}OpenResultView(){const t=h.N.inst.GetViewById(d.I.GloryCallResultView)
if(null!=t&&t.isShow_get())return void t.UpdateView()
const e=new r.v
e.isShowMask=!0,e.isDefaultUITween=!0,e.isSelfTween=!1,e.viewClass=st,h.N.inst.OpenById(d.I.GloryCallResultView,null,null,e)}CloseResultView(){
h.N.inst.CloseById(d.I.GloryCallResultView)}OpenTreasureShopView(){const t=new r.v
t.viewClass=Kt,t.isShowMask=!0,t.maskAlpha=.8,h.N.inst.OpenById(d.I.GloryCallShopView,null,null,t)}CloseTreasureShopView(){h.N.inst.CloseById(d.I.GloryCallShopView)}}zt.inst=null},
94935:(t,e,i)=>{i.d(e,{H:()=>B})
var s,n,a,o,l,r=i(42292),h=i(71409),d=i(32076),u=i(38836),c=i(97461),_=i(38935),I=i(56937),g=i(31222),m=i(5494),C=i(92679),S=i(87923),p=i(37648),A=i(55492),f=i(87893),y=i(92415),T=i(92260),R=i(33996),v=i(8211),w=i(74265),D=i(62734),E=i(99421),L=i(93727),G=i(94582),O=i(75882)
function b(t,e,i,s,n){var a={}
return Object.keys(s).forEach((function(t){a[t]=s[t]})),a.enumerable=!!a.enumerable,a.configurable=!!a.configurable,("value"in a||a.initializer)&&(a.writable=!0),
a=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),a),n&&void 0!==a.initializer&&(a.value=a.initializer?a.initializer.call(n):void 0,a.initializer=void 0),
void 0===a.initializer&&(Object.defineProperty(t,e,a),a=null),a}let B=(s=(0,h.GH)(y.k.SM_GloryRankFinishNum),n=(0,h.GH)(y.k.SM_GloryRankActivityGroup),a=(0,
h.GH)(y.k.SM_GetGloryRank),l=class t{constructor(){this.model=null,this.model=G.x.Inst_get(),c.i.Inst.AddEventHandler(C.g.HUODONG_QUEST_CHANGE,(0,d.v)(this.OnQuestChange,this)),
c.i.Inst.AddEventHandler(C.g.HUODONG_INFO_CHANGE,(0,d.v)(this.OnQuestChange,this)),v.N.GetInst().AddEventHandler(R.G.GET_MALLS,(0,d.v)(this.OnQuestChange,this)),
c.i.Inst.AddEventHandler(C.g.CHOOSE_SETTING_UPDATE,(0,d.v)(this.UpdateHaveSeen,this))}static Inst_get(){return null==t.Inst&&(t.Inst=new t),t.Inst}SM_GloryRankFinishNumHandler(t){
this.model.HandleRankFinishNum(t.type2Num)}SM_GloryRankActivityGroupHandler(t){this.model.HandleActivityGroup(t.activityList)}SM_GetGloryRankHandler(t){for(const[e,i]of(0,
u.vy)(t.type2Rank))w.k.Inst_get().SM_GetRankHandle(i)
this.model.HandleTotalRankData(),this.model.RaiseEvent(G.x.TOTALRANK_UPDATE)}OpenMainPanel(t=null,e=null){
if(!p.P.Inst_get().IsFunctionOpened(A.x.HONOR_KINGS))return void S.l.SetFunctionTip(A.x.HONOR_KINGS)
this.HandleBeforeOpenPanel(t,e)
const i=new I.v
i.isDefaultUITween=!0,i.isSelfTween=!0,i.isShowMask=!0,i.viewClass=O.z,g.N.inst.OpenById(m.I.HonorKingMainPanel,null,null,i)}UpdateHaveSeen(){G.x.Inst_get().CheckRed()}
CM_HonorKingsRank(t,e,i){const s=new f.T
s.rankTypes=t,s.startIndex=e,s.endIndex=i,_.C.Inst.F_SendMsg(s)}HandleBeforeOpenPanel(t,e){if(null!=t&&-1!=t)this.model.ui_maintab=t,this.model.ui_subtab=e
else{this.model.ui_maintab=0
let t=!1
t||(t=this.model.ChooseActivity())
let e=null
for(let i=0;i<=this.model.subAttachRedIds.Count()-1;i++)if(e=D.f.Inst.GetData(this.model.subAttachRedIds[i]),e.show){this.model.ui_subtab=i,
this.model.selectedActId=this.model.huodong_ids[i],t=!0
break}t||(this.model.ui_subtab=0,this.model.selectedActId=this.model.huodong_ids[0])}
for(let t=0;t<=this.model.huodong_ids.Count()-2;t++)L.i.ins.IsActiveState(this.model.huodong_ids[t])&&(this.model.todayActId=this.model.huodong_ids[t])
this.model.ui_maintab==G.x.ATTACH_REREWARD?(T.r.Inst_get().RegMsgUID(-11665,-11666,m.I.HonorKingMainPanel,this.model.selectedActId,this.model.selectedActId,"荣耀王者加载中..."),
E.l.ins.CM_OpenActivityPanel(this.model.selectedActId),
E.l.ins.CM_GetActivityRank(this.model.selectedActId,1,10)):this.model.ui_maintab==G.x.RANK_REWARDD&&(T.r.Inst_get().RegMsgUID(-3015,-3016,m.I.HonorKingMainPanel,null,null,"荣耀王者加载中..."),
this.ReqTotalRank())}CloseMainPanel(){g.N.inst.CloseById(m.I.HonorKingMainPanel)}ReqTotalRank(t,e){null==t&&(t=1),null==e&&(e=10)
const i=G.x.Inst_get().GetRankType(G.x.TOTALACT_ID)
w.k.Inst_get().CM_GetRank(i,t,e)}OnQuestChange(){G.x.Inst_get().CheckRed()}Test1(){return t.Inst_get().OpenMainPanel(),!0}S_Test(){return!0}},l.Inst=null,
b(o=l,"Inst_get",[r.n],Object.getOwnPropertyDescriptor(o,"Inst_get"),o),
b(o.prototype,"SM_GloryRankFinishNumHandler",[s],Object.getOwnPropertyDescriptor(o.prototype,"SM_GloryRankFinishNumHandler"),o.prototype),
b(o.prototype,"SM_GloryRankActivityGroupHandler",[n],Object.getOwnPropertyDescriptor(o.prototype,"SM_GloryRankActivityGroupHandler"),o.prototype),
b(o.prototype,"SM_GetGloryRankHandler",[a],Object.getOwnPropertyDescriptor(o.prototype,"SM_GetGloryRankHandler"),o.prototype),o)},94582:(t,e,i)=>{i.d(e,{x:()=>D})
var s=i(38836),n=i(38045),a=i(97461),o=i(16812),l=i(5924),r=i(98885),h=i(85602),d=i(38962),u=i(49603),c=i(92679),_=i(37648),I=i(55492),g=i(75439),m=i(56828),C=i(47174),S=i(14792),p=i(62734),A=i(60647),f=i(13487),y=i(56834),T=i(69622),R=i(93727),v=i(61249),w=i(51989)
class D extends o.k{constructor(){super(),this.ui_maintab=-1,this.ui_subtab=-1,this.selectedActId=-1,this.todayActId=-1,this.rankTypes=null,this.totalRankDatas=null,
this.activityDic=null,this.dayDic=null,this.huodong_ids=null,this.subActTips=null,this.rankDataDic=null,this.initServerData=!1,this.subActFinishNum=null,this.titleDic=null,
this.titleId=null,this.tipsAssistOrder=null,this.tipsExpCopyOrder=null,this.tipsActitiveOrder=null,this.tipsCopyOrder=null,this.tipsBossOrder=null,this.initRed=null,
this.subAttachRedIds=null,this.totalRankType=null,this.rankTypes=new h.Z,this.totalRankDatas=new h.Z,this.activityDic=new d.X,this.dayDic=new h.Z,this.huodong_ids=new h.Z,
this.subActTips=new d.X,this.InitCfg(),this.rankDataDic=new d.X,this.AddLis(),this.subActFinishNum=new d.X}static Inst_get(){return null==D.Inst&&(D.Inst=new D),D.Inst}InitCfg(){
this.titleDic=g.D.getInstance().GetOriginDict("GLORYKING:ACTIVITY_RUNNAME"),this.titleId=g.D.getInstance().GetIntValue("GLORYKING:TITLEID"),
this.tipsAssistOrder=g.D.getInstance().GetIntArray("GLORYKING:ASSIST_TIPS_ORDER"),this.tipsExpCopyOrder=g.D.getInstance().GetIntArray("GLORYKING:EXPCOPY_TIPS_ORDER"),
this.tipsActitiveOrder=g.D.getInstance().GetIntArray("GLORYKING:ACTIVE_TIPS_ORDER"),this.tipsCopyOrder=g.D.getInstance().GetIntArray("GLORYKING:COPY_TIPS_ORDER"),
this.tipsBossOrder=g.D.getInstance().GetIntArray("GLORYKING:BOSS_TIPS_ORDER")}AddLis(){a.i.Inst.AddEventHandler(c.g.HUODONG_QUEST_CHANGE,this.CreateDelegate(this.CheckRed))}
InitServerData(){if(this.initServerData)return
0==A.p.inst.GetClientLogicSetting(f.R.HonorKings_Red)&&p.f.Inst.SetState(S.t.HONOR_KINGS,!0),this.initServerData=!0}OnRankDailyReward(){}BuildRedIds(){if(!this.initRed){
this.subAttachRedIds=new h.Z,S.t[D.HONORKINGS_ATTACH]=p.f.Inst.GetID()
const t=new h.Z
t.Add(S.t.HONOR_KINGS),p.f.Inst.AddNode(S.t[D.HONORKINGS_ATTACH],t,!1,!1),t.Clear(),t.Add(S.t[D.HONORKINGS_ATTACH])
for(let e=0;e<=this.huodong_ids.Count()-1;e++){const i=this.GetRedId(e)
S.t[i]=p.f.Inst.GetID(),p.f.Inst.AddNode(S.t[i],t,!1,!1),this.subAttachRedIds.Add(S.t[i])}this.initRed=!0}}GetRedId(t){return`${D.HONORKINGS_ATTACH}_${t}`}GetRedIdByActivityId(t){
const e=this.huodong_ids.IndexOf(t),i=this.GetRedId(e)
return S.t[i]}ResetStatus(){this.ui_maintab=-1,this.ui_subtab=-1,this.selectedActId=-1}ChooseActivity(){
for(let t=0;t<=this.huodong_ids.Count()-1;t++)if(R.i.ins.GetState(this.huodong_ids[t])==y.V.OPEN)return this.ui_subtab=t,this.selectedActId=this.huodong_ids[t],!0
return!1}GetNextActivityid(t){let e=this.huodong_ids.IndexOf(t)
return e+=1,this.huodong_ids[e]!=D.TOTALACT_ID?this.huodong_ids[e]:0}GetRankTypeRewardes(t,e){const i=this.GetRankType(t),s=m.K.Inst_get().rank_rewards_dict[t][i].rankConfigVoList
if(null!=s)for(let t=0;t<=s.Count()-1;t++)if(e>=s[t].rank[0]&&e<=s[t].rank[1]){return v.p.Inst_get().GetItemLisByAndReward(s[t].rankReward)}return null}IsCollapseType(t,e){
const i=this.GetRankType(t),s=m.K.Inst_get().rank_rewards_dict[t][i]
for(let t=0;t<=s.rankConfigVoList.Count()-1;t++){const i=s.rankConfigVoList[t]
if(i.rank[0]<=e&&e<=i.rank[1]){if(i.rank[0]==i.rank[1])return 0
let t=0
return t=e==i.rank[0]?0:e==i.rank[0]+1?1:2,t}}}HandleTotalRankData(){this.totalRankDatas.Clear()
const t=this.GetRankDataByActid(D.TOTALACT_ID,this.totalRankType),e=(t.rankInfos.Count(),m.K.Inst_get().rank_rewards_dict[D.TOTALACT_ID][this.totalRankType])
let i=null,s=1,n=null
for(let a=0;a<=e.rankConfigVoList.Count()-1;a++)for(let o=e.rankConfigVoList[a].rank[0];o<=e.rankConfigVoList[a].rank[1];o++){const e=new w.S
e.collapseMode=!0,e.activityid=D.TOTALACT_ID,n=this.GetRankInfo(t,s),e.Rank_Set(s),e.Info_Set(n)
const a=this.IsCollapseType(e.activityid,e.rank)
1==a?i=e:2==a&&(e.parentData=i),e.ranktype=this.totalRankType,e.collapseType=w.S.COLLAPSE,s+=1,this.totalRankDatas.Add(e)}}GetRankInfo(t,e){for(const[i,n]of(0,
s.vy)(t.rankInfos))if(i==e)return n
return null}GetTotalRankDatas(){const t=new h.Z,e=this.totalRankDatas.Count()
for(let i=0;i<=e-1;i++)this.totalRankDatas[i].IsCollapsed()||t.Add(this.totalRankDatas[i])
return t}GetHonorKingsRankData(t,e){let i=new h.Z
const s=this.GetRankDataByActid(t,e)
if(null==s)return i
if(this.rankDataDic.LuaDic_ContainsKey(t))i=this.rankDataDic[t]
else{const n=m.K.Inst_get().rank_rewards_dict[t][e]
let a=null,o=1,l=1,r=null
for(let h=0;h<=n.rankConfigVoList.Count()-1;h++)for(let d=n.rankConfigVoList[h].rank[0];d<=n.rankConfigVoList[h].rank[1];d++){o=h
const n=new w.S
n.collapseMode=!0,n.activityid=t,r=this.GetRankInfo(s,l),n.Info_Set(r),n.Rank_Set(l)
const d=this.IsCollapseType(n.activityid,n.rank)
1==d?a=n:2==d&&(n.parentData=a),n.ranktype=e,n.collapseType=w.S.COLLAPSE,l+=1,i.Add(n)}this.rankDataDic.LuaDic_AddOrSetItem(t,i)}const n=new h.Z,a=i.Count()
for(let t=0;t<=a-1;t++)i[t].IsCollapsed()||n.Add(i[t])
return n}GetReqLength(t){const e=this.GetRankType(t),i=m.K.Inst_get().rank_rewards_dict[t][e]
return i.rankConfigVoList[i.rankConfigVoList.Count()-1].rank[1]}GetPhaseRankDatas(){const t=new h.Z
for(let e=this.huodong_ids.IndexOf(this.todayActId);e>=0;e+=-1)t.Add(this.huodong_ids[e])
return t}GetRankData(t){const e=this.huodong_ids[t],i=this.rankTypes[t]
return this.GetRankDataByActid(e,i)}GetRankDataByActid(t,e){const i=R.i.ins.rankInfoDic[t]
return null!=i?i[e]:null}GetRankType(t){for(let e=0;e<=this.huodong_ids.Count()-1;e++)if(this.huodong_ids[e]==t)return this.rankTypes[e]
return this.rankTypes[0]}GetGapDay(t){const e=this.GetActivityDay(this.todayActId)
return this.GetActivityDay(t)-e}GetActivityDay(t){for(let e=0;e<=this.dayDic.Count()-1;e++)if(this.dayDic[e]==t)return e+1
return 1}GettitleByActivityid(t){const e=this.GetRankType(t)
return this.titleDic.LuaDic_GetItem(e)}GetSecTitle(t){const e=this.GetRankType(t),i=this.titleDic.LuaDic_GetItem((0,n.tw)(e))
return i?r.M.SubStringWithLen(i,1,r.M.Length(i)-2):""}GetRankByType(t){return m.K.Inst_get().rankTypeDict.LuaDic_GetItem(t)}GetRewardConfigVo(t,e){const i=this.GetConfigInfo(t)
if(null!=i){const t=i.rankConfigVoList.Count()
for(let s=0;s<=t-1;s++)if(e>=i.rankConfigVoList[s].rank[0]&&e<=i.rankConfigVoList[s].rank[1])return i.rankConfigVoList[s]}return null}GetConfigInfo(t){const e=this.GetRankType(t)
let i=null
return e>=0&&m.K.Inst_get().rank_rewards_dict[t]&&(i=m.K.Inst_get().rank_rewards_dict[t][e]),i}GetItemName(t){let e=""
return r.M.IsNullOrEmpty(t.asuramName)?e+="【未加入战盟】":e+=`【${t.asuramName}】`,e}ClearRankDic(){this.rankDataDic.Clear()}CheckRed(){
_.P.Inst_get().IsFunctionOpened(I.x.HONOR_KINGS)&&l.C.Inst_get().CallLater(this.CreateDelegate(this.OnCheckRed))}OnCheckRed(){for(let t=0;t<=this.huodong_ids.Count()-1;t++){
const e=this.huodong_ids[t]
if(e!=D.TOTALACT_ID){if(R.i.ins.GetState(e)==y.V.OPEN){const i=T.J.ins.GetTargetTypesByHuoDongId(e,null)
for(let n=0;n<=i.Count()-1;n++){const a=T.J.ins.GetQuestListVoByIdAndTargetType(e,i[n])
let o=!1
for(const[t,e]of(0,s.V5)(a)){const t=R.i.ins.GetQuestVo(e.id)
if(null==t)return
if(!t.activityRewardVo.isReward){let e=!0
for(const[i,n]of(0,s.V5)(t.targetVos))if(n.curValue.ToNum()<n.targetValue.ToNum()){e=!1
break}if(e){o=!0
break}}}p.f.Inst.SetState(S.t[`${D.HONORKINGS_ATTACH}_${t}`],o)}}else p.f.Inst.SetState(S.t[`${D.HONORKINGS_ATTACH}_${t}`],!1)}
0==A.p.inst.GetClientLogicSetting(f.R.HonorKings_Red)&&p.f.Inst.SetState(S.t.HONOR_KINGS,!0)}}GetTips(t){const e=D.Inst_get().GetRankType(t)
return e==C.c.HONOR_ACTIVE||e==C.c.CROSS_HONOR_ACTIVE?"GLORYKING:ACTIVE_TIPS":e==C.c.HONOR_ASSIST||e==C.c.CROSS_HONOR_ASSIST?"GLORYKING:ASSIST_TIPS":e==C.c.HONOR_COPY||e==C.c.CROSS_HONOR_COPY?"GLORYKING:COPY_TIPS":e==C.c.HONOR_BOSS||e==C.c.CROSS_HONOR_BOSS?"GLORYKING:BOSS_TIPS":e==C.c.HONOR_EXPCOPY||e==C.c.CROSS_HONOR_EXPCOPY?"GLORYKING:EXPCOPY_TIPS":e==C.c.HONOR_FIGHT?"GLORYKING:FIGHT_TIPS":e==C.c.HONOR_DIAMONDS||e==C.c.CROSS_HONOR_DIAMONDS?"GLORYKING:DIOM_TIPS":"GLORYKING:ACTIVE_TIPS"
}HandleActivityGroup(t){this.huodong_ids=t,D.TOTALACT_ID=this.huodong_ids[this.huodong_ids.Count()-1],this.BuildRedIds(),this.dayDic.Clear(),this.rankTypes.Clear()
for(let t=0;t<=this.huodong_ids.Count()-2;t++)this.dayDic.Add(this.huodong_ids[t])
for(let t=0;t<=this.huodong_ids.Count()-1;t++){const e=u.H.Inst_get().GetActivityResById(this.huodong_ids[t])
null!=e.params.RANK_TYPE&&this.rankTypes.Add(r.M.String2Int(e.params.RANK_TYPE))}this.totalRankType=this.GetRankType(D.TOTALACT_ID)}HandleRankFinishNum(t){this.subActFinishNum=t}
GetSubActivityFinishNums(t){const e=this.GetTipsOrder(t)
if(null==e)return null
const i=new h.Z
for(let t=0;t<=e.Count()-1;t++){const s=this.GetActivityFinishNum(e[t])
i.Add(s)}return i}GetActivityFinishNum(t){const e=this.subActFinishNum.LuaDic_GetItem(t)
return e?e.ToNum():0}GetTipsOrder(t){const e=this.GetRankType(t)
return e==C.c.HONOR_ACTIVE||e==C.c.CROSS_HONOR_ACTIVE?this.tipsActitiveOrder:e==C.c.HONOR_ASSIST||e==C.c.CROSS_HONOR_ASSIST?this.tipsAssistOrder:e==C.c.HONOR_COPY||e==C.c.CROSS_HONOR_COPY?this.tipsCopyOrder:e==C.c.HONOR_BOSS||e==C.c.CROSS_HONOR_BOSS?this.tipsBossOrder:e==C.c.HONOR_EXPCOPY||e==C.c.CROSS_HONOR_EXPCOPY?this.tipsExpCopyOrder:(e==C.c.HONOR_FIGHT||e==C.c.HONOR_DIAMONDS||C.c.CROSS_HONOR_DIAMONDS,
null)}GetPanelTipsId(){return"GLORYKING:TIPS_NEW"}ResetModel(){this.initServerData=!1,this.huodong_ids=new h.Z,this.subActFinishNum.Clear(),this.initRed=!1}Test1(){
return D.Inst_get().InitCfg(),!0}S_Test(){return!0}}D.TOTALRANK_UPDATE="TOTALRANK_UPDATE",D.ATTACH_REREWARD=0,D.RANK_REWARDD=1,D.TOTAL_EXPAND="TOTAL_EXPAND",
D.TOTAL_COLLAPSE="TOTAL_COLLAPSE",D.PHASE_EXPAND="PHASE_EXPAND",D.PHASE_COLLAPSE="PHASE_COLLAPSE",D.HONORKINGS_ATTACH="HonorKings_ATTACH",D.ACTIVITY_INIT="ACTIVITY_INIT ",
D.TOTALACT_ID=0,D.HonorKings_MainRed="HonorKings_MainRed",D.Inst=null},51989:(t,e,i)=>{i.d(e,{S:()=>n})
var s=i(94582)
class n{constructor(t){this.collapseMode=null,this.cfg=null,this.rankInfo=null,this.rank=0,this.collapseAble=0,this.collapseType=0,this.ranktype=0,this.activityid=0,
this.parentData=null,null==t&&(t=!1),this.collapseMode=t}ShowExpandBtn(){return!!this.collapseMode&&(1==this.collapseAble&&this.collapseType==n.COLLAPSE)}ShowCollapseBtn(){
return!!this.collapseMode&&(1==this.collapseAble&&this.collapseType==n.EXPAND)}IsCollapsed(){
return!!this.collapseMode&&(2==this.collapseAble&&null!=this.parentData&&this.parentData.collapseType==n.COLLAPSE)}b_ShowRank(){return 0==this.collapseAble}Info_Set(t){
this.rankInfo=t}Rank_Set(t){this.rank=t,this.collapseMode&&(this.collapseAble=s.x.Inst_get().IsCollapseType(this.activityid,this.rank))}Test1(){return!0}S_Test(){return!0}}
n.COLLAPSE=0,n.EXPAND=1,n.TOTAL_EXPAND="TOTAL_EXPAND"},94945:(t,e,i)=>{i.d(e,{r:()=>S})
var s,n=i(18998),a=i(83908),o=i(9057),l=i(61613),r=i(35128),h=i(98885),d=i(85602),u=i(63076),c=i(75696),_=i(92679),I=i(79878),g=i(83434),m=i(99421),C=i(69622)
let S=n._decorator.ccclass("HonorKingsAttachItem")(s=class extends((0,a.pA)(o.x)()){constructor(...t){super(...t),this.huodongQuestVo=null,this.targetVo=null,this.rewardVo=null,
this.huodongCfgVo=null,this.flyLinkInfo=null,this.getHandler=null,this.hasIntegral=!1,this.integralItemIndex=-1}InitView(){super.InitView(),
this.grid_item.SetInitInfo("ui_baseitem",null,c.j),this.grid_item.OnReposition_set(this.CreateDelegate(this.ReSetRewardItem))
const t=l.v.GetAdaptionWidth(710,1e3)
this.bg.widthSet(t),this.bg1.widthSet(t-12),l.v.SetAdaptionPos(this.right,602,882,null)}AddLis(){
this.m_handlerMgr.AddClickEvent(this.btn_get.node,this.CreateDelegate(this.OnClickBtnGet)),this.m_handlerMgr.AddClickEvent(this.btn_go.node,this.CreateDelegate(this.OnClickBtnGo)),
this.m_handlerMgr.AddEventMgr(_.g.HUODONG_QUEST_CHANGE,this.CreateDelegate(this.UpdatePanel))}RemoveLis(){}OnInitItem(t){}SetData(t){this.huodongQuestVo=t,
this.targetVo=this.huodongQuestVo.targetVos[0],this.rewardVo=this.huodongQuestVo.activityRewardVo,this.huodongCfgVo=C.J.ins.GetQuestVoById(this.huodongQuestVo.taskId),
this.UpdatePanel(),this.AddLis()}Clear(){this.RemoveLis(),null!=this.flyLinkInfo&&(this.flyLinkInfo.Clear(),this.flyLinkInfo=null),super.Clear()}UpdatePanel(){
this.flyLinkInfo=g.f.GetLinkInfo(new d.Z([this.huodongCfgVo.targetText]),this.huodongCfgVo.TargetDefs_Get(),this.huodongQuestVo.targetVos,null),
this.text_name.textSet(this.flyLinkInfo.GetTxtLabel()),this.btn_get.node.SetActive(!1),this.btn_go.node.SetActive(!1),this.img_get.node.SetActive(!1),
this.text_progress.node.SetActive(!1),this.rewardVo.isReward?this.img_get.node.SetActive(!0):(this.text_progress.node.SetActive(!0),
this.targetVo.curValue.ToNum()>=this.targetVo.targetValue.ToNum()?this.btn_get.node.SetActive(!0):this.btn_go.node.SetActive(!0))
const t=this.targetVo.curValue.ToNum(),e=this.targetVo.targetValue.ToNum(),i=r.p.FloorToInt(t/e*100),s=h.M.Replace("目标进度[047104]{0}%[-]","{0}",i+"")
this.text_progress.textSet(s),this.hasIntegral=!1
const n=new d.Z
for(let t=0;t<=this.rewardVo.reward.rewards.Count()-1;t++){const e=u.M.wrapReward(this.rewardVo.reward.rewards[t])
n.Add(e),10211==e.modelId_get()&&(this.integralItemIndex=t,this.hasIntegral=!0)}this.grid_item.data_set(n)}ReSetRewardItem(){const t=this.grid_item.itemList
if(t)for(let e=0;e<=t.Count()-1;e++)t[e].quality_width=66,t[e].quality_height=66,t[e].SetIconSize(66,66),t[e].SetBgSize(66,66)}OnClickBtnGet(){
this.rewardVo.isReward||this.targetVo.curValue.ToNum()>=this.targetVo.targetValue.ToNum()&&(null!=this.getHandler&&this.hasIntegral&&this.grid_item.itemList[this.integralItemIndex]&&this.getHandler(this.grid_item.itemList[this.integralItemIndex]),
m.l.ins.CM_GainActivitytaskReward(this.huodongCfgVo.activityId,this.huodongCfgVo.id))}OnClickBtnGo(){this.rewardVo.isReward||I.Y.GotoByLinkStr(this.flyLinkInfo.linkStr)}Destroy(){
super.Destroy()}Test1(){return!0}S_Test(){return!0}})||s},49163:(t,e,i)=>{
var s,n=i(18998),a=i(83908),o=i(98800),l=i(30849),r=i(61613),h=i(85602),d=i(63076),u=i(75696),c=i(92679),_=i(33314),I=i(56828),g=i(94582)
n._decorator.ccclass("HonorKingsMyRankItem")(s=class extends((0,a.pA)(l.C)()){constructor(...t){super(...t),this.rankType=0,this.rankInfo=null,this.activityid=0,this.rank=0,
this.itemOringx=null}InitView(){super.InitView(),this.itemgrid.SetInitInfo("ui_baseitem",null,u.j),this.itemgrid.OnReposition_set(this.CreateDelegate(this.ReSetRewardItem))
const t=o.Y.Inst.GetMultiPlayerInfoByCreateIdx(0)
this.headIcon.spriteNameSet(_.Z.GetJobIcon(t.job,t.sex,!1)),this.itemOringx=this.itemgrid.node.getPosition().x,r.v.SetAdaptionPos(this.left,0,-140),
r.v.SetAdaptionPos(this.right,0,140)}AddLis(){this.m_handlerMgr.AddEventMgr(c.g.RANK_SELF_RANK_VALUE,this.CreateDelegate(this.RankValueHandler)),
this.m_handlerMgr.AddEventMgr(c.g.RANK_REWARD,this.CreateDelegate(this.SMRankRewardHandler))}RankValueHandler(t){t.activityId==this.activityid&&this.SetRankValue(t)}
OncolliderClick(){}SMRankRewardHandler(){this.ShowRankReward()}OnCreateItem(t){}SetRankInfo(t){this.AddLis(),this.rank=t&&t.rank||0,
this.rank<=0?this.rankNum.textSet("-"):this.rankNum.textSet(this.rank+"")
if(null!=I.K.Inst_get().self_rank_info[this.activityid]){const t=I.K.Inst_get().self_rank_info[this.activityid][this.rankType]
this.SetRankValue(t)}this.ShowRankReward()}ShowRankReward(){if(-1!=this.rank&&0!=this.rank){const t=g.x.Inst_get().GetRewardConfigVo(this.activityid,this.rank)
if(null!=t){const e=new h.Z
for(let i=0;i<=t.rankReward.rewards.Count()-1;i++){const s=d.M.wrapReward(t.rankReward.rewards[i])
e.Add(s)}const i=(e.Count()-3)*this.itemgrid.cellWidth,s=this.itemOringx-i,[n,a,o]=this.itemgrid.node.GetLocalPositionXYZ()
this.itemgrid.node.SetLocalPositionXYZ(s,a,o),this.itemgrid.data_set(e)}}}ReSetRewardItem(){const t=this.itemgrid.itemList
if(t)for(let e=0;e<=t.Count()-1;e++)t[e].quality_width=66,t[e].quality_height=66,t[e].SetIconSize(66,66),t[e].SetBgSize(66,66)}SetRankValue(t){
this.value.textSet(t.rankValue.ToString())}RemoveLis(){}Clear(){this.RemoveLis(),super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}})},75882:(t,e,i)=>{
i.d(e,{z:()=>J})
var s=i(6847),n=i(83908),a=i(46282),o=i(40053),l=i(68662),r=i(5924),h=i(36334),d=i(44255),u=i(5494),c=i(61613),_=i(35128),I=i(85602),g=i(79534),m=i(67885),C=i(53905),S=i(87923),p=i(65772),A=i(14792),f=i(60647),y=i(13487),T=i(99421),R=i(56834),v=i(93727),w=i(84049),D=i(94935),E=i(94582),L=i(72574),G=i(28236),O=i(32697),b=i(20583),B=i(70650),N=i(51868),P=i(98885),M=i(52212),V=i(49603),k=i(92679),x=i(47786),H=i(56828),U=i(65550),F=i(69622),Y=i(94945),K=i(58552)
class z extends((0,n.pA)(N.$)()){constructor(...t){super(...t),this.topPlayer=null,this.RoleRotateIndexs=-1,this.select_target_type=0,this.endTimer=-1,this.nextid=0,
this.posArr=null,this.widArr=null,this.gap=null,this.originStartX=null,this.curSelectedId=null,this.model=null,this.data=null,this.curSelectedIndex=null,this.role=null,
this.rankType=null,this.displayUIAvatarModel1=void 0,this.mouseMoveX=0,this.minMoveX=15}_initBinder(){super._initBinder(),this.posArr=new I.Z([0,-50,-50,-10,0,130]),
this.widArr=new I.Z([1,1,1,1,1,1])}InitView(){super.InitView(),this.titlegrid.SetInitInfo("ui_honorkings_tab",null,K.H,this.CreateDelegate(this._OnClickRightItem)),
this.titlegrid.OnReposition_set(this.CreateDelegate(this.OnTitleComplete)),this.contentgrid.SetInitInfo("ui_honorkings_attachitem",null,Y.r),
this.contentgrid.OnReposition_set(this.CreateDelegate(this.OnContentComplete)),c.v.SetAdaptionPos(this.leftcontainer.node,0,-140)
const t=c.v.GetAdaptionWidth(710,1e3)
this.gap=(c.v.GetAdaptionWidth(1280,1560)-1280)/2,this.bg.widthSet(t),this.contentpanel.node.transform.width=t,this.titlepanel.node.transform.width=t,
c.v.SetAdaptionPos(this.left,-190,-330),c.v.SetAdaptionPos(this.right,382,530),c.v.SetAdaptionPos(this.contentpanel.node,-210,-352),
c.v.SetAdaptionPos(this.titlepanel.node,-210,-350),this.originStartX=this.titlescrollview.node.getPosition().x,this.model=E.x.Inst_get()}AddLis(){
this.m_handlerMgr.AddEventMgr(k.g.RANK_REWARD,this.CreateDelegate(this.OnRewardMsg)),
this.m_handlerMgr.AddEventMgr(k.g.RYALLIANCE_RANK_SHOWPLAYERMODEL,this.CreateDelegate(this.ShowPlayer)),
this.m_handlerMgr.AddEventMgr(k.g.HUODONG_QUEST_CHANGE,this.CreateDelegate(this.UpdateTargetGrid)),
this.m_handlerMgr.AddEventMgr(k.g.HUODONG_RANKINFO_UPDATE,this.CreateDelegate(this.OnGetHuodongInfo)),
this.m_handlerMgr.AddEventMgr(k.g.RANK_SELF_RANK_VALUE,this.CreateDelegate(this.OnSelfRankMsg)),
this.m_handlerMgr.AddEventMgr(k.g.HUODONG_INFO_CHANGE,this.CreateDelegate(this.OnInfoChange)),
this.m_handlerMgr.AddClickEvent(this.tipsbtn.node,this.CreateDelegate(this.OnTipClick))}onDragChangeAvatar1(t){if(this.mouseMoveX=t.getDeltaX(),
this.displayUIAvatarModel1&&this.displayUIAvatarModel1.targetUIAvatar&&this.bossTexture.node.active&&(this.mouseMoveX>this.minMoveX||this.mouseMoveX<-this.minMoveX)&&(this.mouseMoveX=0,
this)){const t=this.mouseMoveX>0?1:-1,e=this.displayUIAvatarModel1.targetUIAvatar.dir
this.displayUIAvatarModel1.targetUIAvatar.dir=(e+t+8)%8}}RemoveLis(){this.m_handlerMgr.RemoveEventMgr(k.g.RANK_REWARD,this.CreateDelegate(this.OnRewardMsg)),
this.m_handlerMgr.RemoveEventMgr(k.g.RYALLIANCE_RANK_SHOWPLAYERMODEL,this.CreateDelegate(this.ShowPlayer)),
this.m_handlerMgr.RemoveEventMgr(k.g.HUODONG_QUEST_CHANGE,this.CreateDelegate(this.UpdateTargetGrid)),
this.m_handlerMgr.RemoveEventMgr(k.g.HUODONG_RANKINFO_UPDATE,this.CreateDelegate(this.OnGetHuodongInfo)),
this.m_handlerMgr.RemoveEventMgr(k.g.RANK_SELF_RANK_VALUE,this.CreateDelegate(this.OnSelfRankMsg)),
this.m_handlerMgr.RemoveEventMgr(k.g.HUODONG_INFO_CHANGE,this.CreateDelegate(this.OnInfoChange))}OnRewardMsg(t){if(t.activityId==this.curSelectedId){
const t=this.model.GetReqLength(this.curSelectedId)
T.l.ins.CM_GetActivityRank(this.curSelectedId,1,t)}}UpdateRank(){this.data=this.model.GetRankData(this.curSelectedIndex),
null!=this.data&&(null!=this.data&&(this.topPlayer=this.data.rankInfos[1],null!=this.topPlayer?this.playernamelab.textSet(this.topPlayer.name):this.playernamelab.textSet("虚位以待")),
-1==this.data.rank?this.myranklab.textSet("未上榜"):this.myranklab.textSet(this.data.rank),this.OnGetRank())}OnSelfRankMsg(t){t.activityId==this.curSelectedId&&this.UpdateSelfRank()}
OnInfoChange(t){if(this.nextid==t){if(v.i.ins.GetState(t)==R.V.OPEN){const t=this.model.huodong_ids.IndexOf(this.nextid)
this.SetSelectedId(t),this.UpdateSelectedTab(),this.UpdateTargetGrid(),this.UpdateTitles(),this.ReqInfo()}}}UpdateSelfRank(){let t=0
const e=this.model.GetRankType(this.curSelectedId)
let i=H.K.Inst_get().self_rank_info[this.curSelectedId]
null!=i&&(i=H.K.Inst_get().self_rank_info[this.curSelectedId][e],t=i.rankValue.ToString()),this.myscorelab.textSet(P.M.Replace("我的积分：{0}","{0}",t+""))}OnGetRank(){
if(null!=this.data){if(null!=this.data.rankInfos[1]){const t=H.K.inst.WrapOtherPlayerVo(this.data.topplayer[0])
this.ShowPlayer(t)}else null!=this.role&&(this.role.Destroy(),this.role=null)}}ShowPlayer(t){
this.displayUIAvatarModel1=this.InitPlayerModel(this.bossTexture,t,this.displayUIAvatarModel1)}SetData(){this.model=E.x.Inst_get(),this.AddLis()
const t=this.model.huodong_ids[this.model.ui_subtab]
v.i.ins.GetState(t)!=R.V.OPEN&&this.model.ChooseActivity(),this.SetSelectedId(this.model.ui_subtab)
const e=F.J.ins.target_type_dict.LuaDic_GetItem(this.curSelectedId)
null!=e&&e.Count()>0&&(this.select_target_type=e[0]),this.UpdateSelectedTab(),this.UpdateTargetGrid(),this.UpdateTitles(),this.UpdateRank(),this.UpdateSelfRank()}
InitPlayerModel(t,e,i){let s=new G.H
return s.Job_set(e.job),s.Level_set(e.level),s.Sex_set(e.sex),s.horseId_set(e.hoserId),s.Name_set(e.name),s.equipmentStorageVO=e.equipmentStorageVO,
i?i=b.x.inst.SetUIAvatarData(s,O.v.role,i):(i=b.x.inst.SetUIAvatarData(s)).SetTarget(t,!1),i.UpdateUIAvatar(),i.SetScale(1,1),i.SetDir(4),i.SetAct(L.Bv.FightIdle),i}UpdateTitles(){
const t=V.H.Inst_get().GetActivityResById(this.curSelectedId)
this.titlelab.textSet(t.name),this.sectitlelab.textSet(this.model.GetSecTitle(this.curSelectedId))
const e=new I.Z
for(let t=0;t<=this.model.huodong_ids.Count()-2;t++)e.Add(this.model.huodong_ids[t])
this.titlegrid.data_set(e),this.ClearTimer(),this.endTimer=r.C.Inst_get().SetInterval(this.CreateDelegate(this.RefreshTime),1e3),this.RefreshTime()}OnTitleComplete(){
if(this.titlepanel.ResetPosition(),this.titlegrid.itemList.Count()==this.model.huodong_ids.Count()-1){this.UpdateSelectedTab()
const t=this.curSelectedIndex*this.titlegrid.cellWidth
if(t>=0){const e=M.F.zero_get()
e.x=t,this.titlepanel.clipOffsetSet(e)}}}_OnClickRightItem(t){const e=this.titlegrid.itemList.IndexOf(t),i=this.model.huodong_ids[e]
if(v.i.ins.GetState(i)==R.V.NONE){const t=V.H.Inst_get().GetActivityResById(i)
let e=x.x.Inst().getItemStrById(11043203)
const s=E.x.Inst_get().GetGapDay(i)
return e=S.l.Substitute(e,new I.Z([s,t.name])),void U.y.inst.ClientSysStrMsg(e)}if(v.i.ins.GetState(i)==R.V.CLOSE||v.i.ins.GetState(i)==R.V.END){
let t=x.x.Inst().getItemStrById(11043204)
const e=V.H.Inst_get().GetActivityResById(i)
return t=P.M.Replace(t,"{0}",e.name),void U.y.inst.ClientSysStrMsg(t)}this.model.ui_subtab=e,this.SetSelectedId(e),this.UpdateSelectedTab(),this.ReqInfo()}ReqInfo(){
T.l.ins.CM_OpenActivityPanel(this.curSelectedId)}OnContentComplete(t){this.contentscroll.ResetPosition()}UpdateTargetGrid(){
const t=F.J.ins.target_type_dict.LuaDic_GetItem(this.curSelectedId)
if(null!=t&&t.Count()>0){this.select_target_type=t[0]
const e=v.i.ins.GetQuestListVoByIdAndTargetType(this.curSelectedId,this.select_target_type)
e.Sort(v.i.ins.SortTask),this.contentgrid.data_set(e)}}UpdateSelectedTab(){const t=this.titlegrid.itemList?this.titlegrid.itemList.Count():0
for(let e=0;e<=t-1;e++)e==this.curSelectedIndex?this.titlegrid.itemList[e].SetSelect(!0):this.titlegrid.itemList[e].SetSelect(!1)}OnGetHuodongInfo(t){
this.rankType==t.rankType&&this.UpdateRank()}SetSelectedId(t){this.curSelectedId=this.model.huodong_ids[t],this.curSelectedIndex=t,
this.nextid=this.model.GetNextActivityid(this.curSelectedId),this.rankType=this.model.GetRankType(this.curSelectedId)}RefreshTime(){
const t=this.curSelectedId,e=v.i.ins.huodong_dict.LuaDic_GetItem(t)
if(v.i.ins.GetState(t)!=R.V.OPEN&&this.ClearTimer(),null!=e){const t=_.p.FloorToInt(e.endTime.ToNum()/1e3)-l.D.serverTime_get()
t>0?this.actdowntime.textSet(`[b09979]结束倒计时:[-] [5fb470]${S.l.GetDateFormatEX(t,!0,!0)}[-]`):this.actdowntime.textSet("[b09979]已结束[-]")
}else this.actdowntime.textSet("[b09979]已结束[-]")}ClearTimer(){this.endTimer>-1&&(r.C.Inst_get().ClearInterval(this.endTimer),this.endTimer=-1)}OnTipClick(){
const t=new C.w,e=480+this.gap
t.position=new g.P(e,165,0),t.width=500,t.infoId=E.x.Inst_get().GetTips(this.curSelectedId),t.anchor=2
const i=this.model.GetSubActivityFinishNums(this.curSelectedId)
null!=i&&(t.replaceParams=i),p.Q.Inst_get().Open(t)}Clear(){this.RemoveLis(),this.ClearTimer(),null!=this.role&&(this.role.Destroy(),this.role=null),
-1!=this.RoleRotateIndexs&&(B.e.GetInst().UnregDrag(this.RoleRotateIndexs),this.RoleRotateIndexs=-1),super.Clear()}Destroy(){}Test1(){return!0}S_Test(){return!0}}z.STAGE_ID=149
var Q,Z=i(84473),X=i(3579)
class j extends((0,n.pA)(N.$)()){constructor(...t){super(...t),this.selectIndex=0,this.RoleRotateIndexs=-1,this.model=null,this.role=null,this.displayUIAvatarModel1=void 0,
this.mouseMoveX=0,this.minMoveX=15}InitView(){super.InitView(),this.model=E.x.Inst_get()
const t=X.W.Inst().getItemById(this.model.titleId)
t&&this.titleitem.SetData(t),c.v.SetAdaptionPos(this.leftcontainer,0,-140),c.v.SetAdaptionPos(this.totalbtn.node,320,390)
c.v.GetAdaptionWidth(355,500)
c.v.SetAdaptionPos(this.phasebtn.node,-35,-105)}AddLis(){this.m_handlerMgr.AddEventMgr(k.g.RYALLIANCE_RANK_SHOWPLAYERMODEL,this.CreateDelegate(this.ShowPlayer)),
this.m_handlerMgr.AddEventMgr(k.g.HUODONG_RANKINFO_UPDATE,this.CreateDelegate(this.OnSMGetRank)),
this.m_handlerMgr.AddEventMgr(k.g.RANK_REWARD,this.CreateDelegate(this.SMRankRewardHandler)),
this.m_handlerMgr.AddClickEvent(this.phasebtn.node,this.CreateDelegate(this.OnPhasebtnClick)),
this.m_handlerMgr.AddClickEvent(this.totalbtn.node,this.CreateDelegate(this.OnTotalbtnClick))}onDragChangeAvatar1(t){if(this.mouseMoveX=t.getDeltaX(),
this.displayUIAvatarModel1&&this.displayUIAvatarModel1.targetUIAvatar&&this.bossTexture.node.active&&(this.mouseMoveX>this.minMoveX||this.mouseMoveX<-this.minMoveX)&&(this.mouseMoveX=0,
this)){const t=this.mouseMoveX>0?1:-1,e=this.displayUIAvatarModel1.targetUIAvatar.dir
this.displayUIAvatarModel1.targetUIAvatar.dir=(e+t+8)%8}}OnPhasebtnClick(){this.selectIndex=1,this.UpdateView()}OnTotalbtnClick(){this.selectIndex=0,this.UpdateView()}
SMRankRewardHandler(t){if(null!=this.model){const e=t.activityId
if(this.model.huodong_ids.IndexOf(e)>-1){const t=this.model.GetReqLength(e)
T.l.ins.CM_GetActivityRank(e,1,t)}}}UpdateView(){0==this.selectIndex?(this.totalbtn.SetIsEnabled(!1),this.totalbtn.SetState(Z.D.ePressed,!0),this.phasebtn.SetIsEnabled(!0),
this.phasebtn.SetState(Z.D.eNormal,!1)):(this.totalbtn.SetIsEnabled(!0),this.totalbtn.SetState(Z.D.eNormal,!1),this.phasebtn.SetIsEnabled(!1),
this.phasebtn.SetState(Z.D.ePressed,!0)),this.phaseview.ShowView(1==this.selectIndex),this.totalview.ShowView(0==this.selectIndex)}RemoveLis(){
this.m_handlerMgr.RemoveEventMgr(k.g.RYALLIANCE_RANK_SHOWPLAYERMODEL,this.CreateDelegate(this.ShowPlayer)),
this.m_handlerMgr.RemoveEventMgr(k.g.HUODONG_RANKINFO_UPDATE,this.CreateDelegate(this.OnSMGetRank)),
this.m_handlerMgr.RemoveEventMgr(k.g.RANK_REWARD,this.CreateDelegate(this.SMRankRewardHandler))}ShowPlayer(t){
this.displayUIAvatarModel1=this.InitPlayerModel(this.bossTexture,t,this.displayUIAvatarModel1)}InitPlayerModel(t,e,i){let s=new G.H
return s.Job_set(e.job),s.Level_set(e.level),s.Sex_set(e.sex),s.horseId_set(e.hoserId),s.Name_set(e.name),s.equipmentStorageVO=e.equipmentStorageVO,
i?i=b.x.inst.SetUIAvatarData(s,O.v.role,i):(i=b.x.inst.SetUIAvatarData(s)).SetTarget(t,!1),i.UpdateUIAvatar(),i.SetScale(1,1),i.SetDir(4),i.SetAct(L.Bv.FightIdle),i}ReqInfo(){
for(let t=0;t<=this.model.huodong_ids.Count()-1;t++){const e=v.i.ins.GetState(this.model.huodong_ids[t])
e!=R.V.OPEN&&e!=R.V.END||T.l.ins.CM_OpenActivityPanel(this.model.huodong_ids[t])}}ReqTopPlayer(t){if(null!=t){const e=t.topplayer[0]
if(null!=e){const t=H.K.inst.WrapOtherPlayerVo(e)
this.ShowPlayer(t)}else null!=this.role&&(this.role.Destroy(),this.role=null)}}OnSMGetRank(t){if(t.activityId==E.x.TOTALACT_ID){this.model.HandleTotalRankData(),this.UpdateView()
const e=this.model.GetRankType(E.x.TOTALACT_ID),i=this.model.GetRankDataByActid(E.x.TOTALACT_ID,e)
null!=t.rankInfos[1]?this.playernamelab.textSet(i.rankInfos[1].name):this.playernamelab.textSet("虚位以待"),this.ReqTopPlayer(i)}}SetData(){this.model=E.x.Inst_get(),
this.phaseview.SetActive(!1),this.AddLis(),this.selectIndex=0,this.ReqInfo()}Clear(){this.RemoveLis(),null!=this.role&&(this.role.Destroy(),this.role=null),
this.model.ClearRankDic(),-1!=this.RoleRotateIndexs&&(B.e.GetInst().UnregDrag(this.RoleRotateIndexs),this.RoleRotateIndexs=-1),super.Clear()}Destroy(){}Test1(){return!0}S_Test(){
return!0}}j.STAGE_ID=149
let J=(0,s.s_)(u.I.HonorKingMainPanel,a.Z.ui_honorkings_mainpanel).tabsPrefab(a.Z.ui_openservergrab_right_tab,1).waitPrefab(o.Z.HonorKingMainPanel_basePrefabe).waitPrefab(m.S.modulePathList).register()(Q=class extends((0,
n.pA)(d.I)()){constructor(...t){super(...t),this.timerId=-1,this.inited=!1,this.gap=null,this.curSelectedId=null}InitView(){super.InitView()}SetViewConfig(){
this.titleLabel.textSet("荣耀王者"),this._subPanelDatas.Add(h.b.New(new I.Z(["ui_honorkings_attachview"]),this,z)),
this._subPanelDatas.Add(h.b.New(new I.Z(["ui_honorkings_rankview","ui_honorkings_phasegriditem"]),this,j))
const t=new I.Z(["荣耀积分","排行奖励"]),e=new I.Z([A.t[E.x.HONORKINGS_ATTACH],A.t.NONE])
this.rightTabGrid.SetInitInfo("ui_openservergrab_right_tab",null,w.K,this.CreateDelegate(this._OnClickRightItem)),
this.rightTabGrid.OnReposition_set(this.CreateDelegate(this.OnRepositionRight)),this._SetCharacterTabData(!1),this._SetTabData1(!0,t,e,null,null,null,null),
this.SelectTab1(E.x.Inst_get().ui_maintab,!0),this._UpdateTableSelect1(!1),this.ClearTimer(),this.timerId=r.C.Inst_get().SetInterval(this.CreateDelegate(this.RefreshTime),800),
this.RefreshTime(),f.p.inst.SendClientLogicSetting(y.R.HonorKings_Red,1),E.x.Inst_get().CheckRed(),this.gap=(c.v.GetAdaptionWidth(1280,1560)-1280)/2}RefreshTime(){
this.curSelectedId
const t=v.i.ins.huodong_dict.LuaDic_GetItem(E.x.TOTALACT_ID)
if(v.i.ins.GetState(E.x.TOTALACT_ID)!=R.V.OPEN&&this.ClearTimer(),null!=t){const e=_.p.FloorToInt(t.endTime.ToNum()/1e3)-l.D.serverTime_get()
e>0?this.downtime.textSet(`[b09979]结束倒计时:[-] [5fb470]${S.l.GetDateFormatEX(e,!0,!0)}[-]`):this.downtime.textSet("[b09979]已结束[-]")}else this.downtime.textSet("[b09979]已结束[-]")}
OnRepositionRight(){this._UpdateTableSelect1(!1)}AddLis(){this.m_handlerMgr.AddClickEvent(this.tipBtn.node,this.CreateDelegate(this.OntipsbtnClick)),super.AddLis()}
OntipsbtnClick(){const t=new C.w,e=-385-this.gap
t.position=new g.P(e,320,0),t.width=450,t.infoId=E.x.Inst_get().GetPanelTipsId(),p.Q.Inst_get().Open(t)}OnAddToScene(){super.OnAddToScene(),this.inited=!0}RemoveLis(){}
ClearTimer(){this.timerId>-1&&(r.C.Inst_get().ClearInterval(this.timerId),this.timerId=-1)}OnCloseClick(){D.H.Inst_get().CloseMainPanel()}Clear(){this.RemoveLis(),
this.ClearTimer(),E.x.Inst_get().ResetStatus(),super.Clear()}_OnSelectTab1BeforeUpdate(t){this.ShowSubView(this.selectTabIdx1)}Destroy(){super.Destroy()}PlayAni(){this.Ani,
this.HandleReShow()}HandleReShow(){
this.inited&&null!=this._subPanelDatas&&this._subPanelDatas.Count()>0&&null!=this._subPanelDatas[0].view&&this._subPanelDatas[0].view.curSelectedId>0&&T.l.ins.CM_OpenActivityPanel(this._subPanelDatas[0].view.curSelectedId)
}DoReShow(){this._OnSelectTab1BeforeUpdate()}Test1(){return!0}S_Test(){return!0}})||Q},78297:(t,e,i)=>{i.d(e,{r:()=>I})
var s,n,a=i(18998),o=i(83908),l=i(30849),r=i(61613),h=i(85602),d=i(49603),u=i(87923),c=i(94582),_=i(22593)
let I=a._decorator.ccclass("HonorKingsPhaseDataGrid")((n=class t extends((0,o.pA)(l.C)()){constructor(...t){super(...t),this.m_reposition=null,this.ranktype=null,this.model=null,
this.activityid=null}InitView(){super.InitView(),this.itemgrid.SetInitInfo("ui_honorkings_rankitem",null,_.s),this.itemgrid.OnReposition_set(this.CreateDelegate(this.OnReposition))
const t=r.v.GetAdaptionWidth(710,1e3)
this.bg.widthSet(t)}AddLis(){this.m_handlerMgr.AddNotifyEvent(c.x.Inst_get(),c.x.PHASE_EXPAND,this.CreateDelegate(this.OnExpand)),
this.m_handlerMgr.AddNotifyEvent(c.x.Inst_get(),c.x.PHASE_COLLAPSE,this.CreateDelegate(this.OnExpand))}RemoveLis(){}OnExpand(t){if(t==this.ranktype){
const t=this.model.GetHonorKingsRankData(this.activityid,this.ranktype)
this.itemgrid.data_set(t)}}OnCreateItem(t){}SetData(e){this.AddLis(),this.model=c.x.Inst_get(),this.activityid=e
const i=this.model.GetActivityDay(e),s=d.H.Inst_get().GetActivityResById(e),n=u.l.Substitute(t.TEMPLATE,new h.Z([i,s.name]))
this.titlelab.textSet(n),this.ranktype=this.model.GetRankType(e)
const a=this.model.GetHonorKingsRankData(this.activityid,this.ranktype)
this.itemgrid.data_set(a)}OnReposition(){null!=this.m_reposition&&this.m_reposition()}Clear(){this.RemoveLis(),this.itemgrid.Clear(),super.Clear()}Destroy(){super.Destroy()}
Test1(){return!0}S_Test(){return!0}},n.TEMPLATE="阶段{0}：{1}",s=n))||s},84074:(t,e,i)=>{
var s,n=i(18998),a=i(75507),o=i(83908),l=i(38836),r=i(5924),h=i(30849),d=i(18202),u=i(61613),c=i(35128),_=i(3809),I=i(85602),g=i(52212),m=i(49603),C=i(94582),S=i(78297),p=i(65294)
n._decorator.ccclass("HonorKingsPhaseRankView")(s=class extends((0,o.pA)(h.C)()){constructor(...t){super(...t),this.gridItemes=null,this.gridItemesPools=null,this.titleWidth=null,
this.model=null}_initBinder(){super._initBinder(),this.gridItemes=new I.Z,this.gridItemesPools=new I.Z}InitView(){super.InitView(),
this.titlegrid.SetInitInfo("ui_honorkings_phasetitleitem",null,p.$)
let t=u.v.GetAdaptionWidth(720,1e3)
this.bg.widthSet(t),this.scrollpanel.node.transform.width=t
const e=g.F.zero_get()
e.x=t,e.y=370,t=u.v.GetAdaptionWidth(650,940),this.rankbg.widthSet(t),u.v.SetAdaptionPos(this.title1,-301,-446,19),this.titleWidth=(t-42)/6,
this.titlegrid.cellWidthSet(this.titleWidth)
const i=c.p.FloorToInt(t/2-47-this.titleWidth/2)
this.titlegrid.node.SetLocalPositionXYZ(-i,19,0)}AddLis(){}RemoveLis(){}OnCreateTitle(t){}ShowView(t){
t?(this.m_handlerMgr.AddNotifyEvent(C.x.Inst_get(),C.x.TOTALRANK_UPDATE,this.CreateDelegate(this.OnMsg)),this.SetData(),this.SetActive(!0)):(this.Clear(),this.SetActive(!1))}
OnMsg(){this.SetData()}SetData(){this.model=C.x.Inst_get(),this.myrankitem.activityid=this.model.todayActId
let t=this.model.GetRankType(this.model.todayActId)
this.myrankitem.rankType=t
const e=C.x.Inst_get().GetRankDataByActid(this.model.todayActId,t)
this.myrankitem.SetRankInfo(e)
const i=new I.Z
for(let t=0;t<=this.model.huodong_ids.Count()-2;t++)i.Add(this.model.huodong_ids[t])
this.titlegrid.data_set(i)
const s=this.model.huodong_ids[this.model.huodong_ids.Count()-2]
m.H.Inst_get().GetActivityResById(s)
t=C.x.Inst_get().GetRankType(s),this.PushToPool()
let n=0
const a=this.model.GetPhaseRankDatas()
for(let t=0;t<=a.Count()-1;t++){const e=this.GetGridItem()
e.m_reposition=this.CreateDelegate(this.OnGridReposition),e.SetData(a[t]),e.node.setParent(this.root),e.node.SetLocalPositionXYZ(0,-n,0)
const i=e.node.getChildByName("itemgrid")
n+=Math.abs(i.y)+i.transform.height}r.C.Inst_get().CallLater(this.CreateDelegate(this.OnGridReposition)),this.scrollpanel.ResetPosition()}GetGridItem(){let t=null
if(this.gridItemesPools.Count()>0)t=_.B.PopFront(this.gridItemesPools)
else{const e=a.o.getPrefab("ui_honorkings_phasegriditem")
t=(0,n.instantiate)(e).getCNode(S.r)}return this.gridItemes.Add(t),t}PushToPool(){for(;this.gridItemes.Count()>0;){const t=_.B.PopFront(this.gridItemes)
this.gridItemesPools.Add(t),t.node.SetLocalPositionXYZ(3e3,3e3,0)}}OnGridReposition(){let t=0
for(let e=0;e<=this.gridItemes.Count()-1;e++){this.gridItemes[e].node.SetLocalPositionXYZ(0,-t,0)
const i=this.gridItemes[e].node.getChildByName("itemgrid")
t+=Math.abs(i.y)+i.transform.height}this.scrollpanel.node.getChildByPath("view/content").transform.height=t}Clear(){this.RemoveLis(),this.PushToPool(),super.Clear()}Destroy(){
for(const[t,e]of(0,l.vy)(this.gridItemes))e.Destroy(),d.g.DestroyUIObj(e)
for(const[t,e]of(0,l.vy)(this.gridItemesPools))e.Destroy(),d.g.DestroyUIObj(e)
super.Destroy()}Test1(){return!0}S_Test(){return!0}})},65294:(t,e,i)=>{i.d(e,{$:()=>h})
var s,n=i(18998),a=i(83908),o=i(9057),l=i(49603),r=i(94582)
let h=n._decorator.ccclass("HonorKingsPhaseTitleItem")(s=class extends((0,a.pA)(o.x)()){constructor(...t){super(...t),this.wid=0}InitView(){super.InitView()}AddLis(){}RemoveLis(){}
UpdateAnchor(){this.tag1.SetLocalPositionXYZ(-this.wid,0,0)}SetData(t){const e=l.H.Inst_get().GetActivityResById(t)
if(null!=e){this.title1.textSet(e.name)
const i=r.x.Inst_get().GetRankType(t),s=r.x.Inst_get().GetRankDataByActid(t,i)
null==s||0==s.rank?this.title2.textSet("-"):-1==s.rank?this.title2.textSet("未上榜"):this.title2.textSet(s.rank+"")}}Clear(){this.RemoveLis(),super.Clear()}Destroy(){super.Destroy()}
Test1(){return!0}S_Test(){return!0}})||s},22593:(t,e,i)=>{i.d(e,{s:()=>C})
var s,n,a=i(18998),o=i(83908),l=i(98800),r=i(9057),h=i(61613),d=i(98885),u=i(94148),c=i(75696),_=i(33314),I=i(44744),g=i(94582),m=i(51989)
let C=a._decorator.ccclass("HonorKingsRankItem")(((n=class extends((0,o.pA)(r.x)()){constructor(...t){super(...t),this.activityid=0,this.itemOringx=null,this.data=null}InitView(){
super.InitView(),this.itemgrid.SetInitInfo("ui_baseitem",null,c.j),this.itemgrid.OnReposition_set(this.CreateDelegate(this.ReSetRewardItem)),this.morebtn.SetActive(!1),
this.lessbtn.SetActive(!1),this.itemOringx=this.itemgrid.node.getPosition().x
const t=h.v.GetAdaptionWidth(710,1e3)
this.bg.widthSet(t),h.v.SetAdaptionPos(this.left,0,-140),h.v.SetAdaptionPos(this.right,0,140)}AddLis(){
this.m_handlerMgr.AddClickEvent(this.morebtn.node,this.CreateDelegate(this.OnMorebtnClick)),
this.m_handlerMgr.AddClickEvent(this.lessbtn.node,this.CreateDelegate(this.OnLessbtnClick)),
this.m_handlerMgr.AddClickEvent(this.collider.node,this.CreateDelegate(this.OncolliderClick))}RemoveLis(){}OnLessbtnClick(){this.data.collapseType=m.S.COLLAPSE,
g.x.Inst_get().RaiseEvent(g.x.PHASE_COLLAPSE,this.data.ranktype)}OnMorebtnClick(){this.data.collapseType=m.S.EXPAND,g.x.Inst_get().RaiseEvent(g.x.PHASE_EXPAND,this.data.ranktype)}
OncolliderClick(){const t=l.Y.Inst.PrimaryRoleInfo_get().Id_get()
this.data.rankInfo.playerId.Equal(t)||I.Z.Inst().Open(this.data.rankInfo.playerId)}SetData(t){this.AddLis(),this.data=t,null!=t.rankInfo?(this.rolecontent.SetActive(!0),
this.headIcon.spriteNameSet(_.Z.GetJobIcon(t.rankInfo.job,t.rankInfo.sex,!1)),this.serverlab.textSet(g.x.Inst_get().GetItemName(t.rankInfo)),this.name.textSet(t.rankInfo.name),
this.value.textSet(t.rankInfo.rankValue),this.emptylab.SetActive(!1)):(this.rolecontent.SetActive(!1),this.emptylab.SetActive(!0))
const e=g.x.Inst_get().GetRewardConfigVo(t.activityid,t.rank)
if(d.M.String2Int(t.rank)<=3?(this.rankNum.textSet(""),this.rankSprite.SetActive(!0),
this.rankSprite.spriteNameSet(u.b.Inst_get().GetRankIcon(t.rank))):(this.rankSprite.SetActive(!1),
t.b_ShowRank()?this.rankNum.textSet(`${e.rank[0]}-${e.rank[1]}`):this.rankNum.textSet("")),this.bgsp2.SetActive(!0),t.ShowExpandBtn())this.itemgrid.data_set(null),
this.morebtn.SetActive(!0),this.lessbtn.SetActive(!1),this.bgsp2.SetActive(!1)
else if(t.ShowCollapseBtn())this.itemgrid.data_set(null),this.morebtn.SetActive(!1),this.lessbtn.SetActive(!0),this.bgsp2.SetActive(!1)
else if(this.morebtn.SetActive(!1),this.lessbtn.SetActive(!1),0==this.data.collapseAble){const e=g.x.Inst_get().GetRankTypeRewardes(t.activityid,this.data.rank)
if(null!=e){const t=(e.Count()-3)*this.itemgrid.cellWidth,i=this.itemOringx-t,[s,n,a]=this.itemgrid.node.GetLocalPositionXYZ()
this.itemgrid.node.SetLocalPositionXYZ(i,n,a),this.itemgrid.data_set(e)}}else this.itemgrid.data_set(null),this.bgsp2.SetActive(!1)}ReSetRewardItem(){const t=this.itemgrid.itemList
if(t)for(let e=0;e<=t.Count()-1;e++)t[e].quality_width=66,t[e].quality_height=66,t[e].SetIconSize(66,66),t[e].SetBgSize(66,66)}OnCreateItem(t){}Clear(){this.RemoveLis(),
super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}}).desTemplate="荣耀积分：{0}",s=n))||s},58552:(t,e,i)=>{i.d(e,{H:()=>c})
var s,n=i(18998),a=i(83908),o=i(9057),l=i(49603),r=i(56834),h=i(93727),d=i(94582),u=i(60130)
let c=n._decorator.ccclass("HonorKingsTab")(s=class extends((0,a.pA)(o.x)()){InitView(){super.InitView(),this.redpoint.SetActive(!1)}AddLis(){}RemoveLis(){}Clear(){
this.RemoveLis(),super.Clear()}SetData(t){const e=l.H.Inst_get().GetActivityResById(t)
null!=e&&this.text_tab_0.textSet(e.name),this.SetItemClickGo(this)
const i=d.x.Inst_get().GetRedIdByActivityId(t)
this.m_handlerMgr.AddRedPointTipObj(i,this.redpoint)
const s=h.i.ins.GetState(t)
this.endsp.SetActive(s!=r.V.OPEN&&s!=r.V.NONE),this.insp.SetActive(s==r.V.OPEN),s==r.V.NONE?u.O.makeGoGray(this.node,!0):u.O.makeGoGray(this.node,!1)}SetSelect(t){
t?this.bg.spriteNameSet("atlas/common/rycommon_bt_0046"):this.bg.spriteNameSet("atlas/common/rycommon_bt_0045")}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}})||s},
110:(t,e,i)=>{i.d(e,{s:()=>C})
var s,n,a=i(18998),o=i(83908),l=i(98800),r=i(9057),h=i(61613),d=i(98885),u=i(94148),c=i(75696),_=i(33314),I=i(44744),g=i(94582),m=i(51989)
let C=a._decorator.ccclass("HonorKingsTotalRankItem")(((n=class extends((0,o.pA)(r.x)()){constructor(...t){super(...t),this.collapsemode=!1,this.itemOringx=null,this.data=null,
this.clickCheck=null}InitView(){super.InitView(),this.itemgrid.SetInitInfo("ui_baseitem",null,c.j),this.itemgrid.OnReposition_set(this.CreateDelegate(this.ReSetRewardItem)),
this.itemOringx=this.itemgrid.node.getPosition().x,this.AddLis()
const t=h.v.GetAdaptionWidth(710,1e3)
this.bg.widthSet(t),h.v.SetAdaptionPos(this.left,0,-140),h.v.SetAdaptionPos(this.right,0,140)}OnAddToScene(){this.AddLis()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.morebtn.node,this.CreateDelegate(this.OnMorebtnClick)),
this.m_handlerMgr.AddClickEvent(this.lessbtn.node,this.CreateDelegate(this.OnLessbtnClick)),
this.m_handlerMgr.AddClickEvent(this.collider.node,this.CreateDelegate(this.OncolliderClick))}OnCreateItem(t){}ReSetRewardItem(){const t=this.itemgrid.itemList
if(t)for(let e=0;e<=t.Count()-1;e++)t[e].quality_width=66,t[e].quality_height=66,t[e].SetIconSize(66,66),t[e].SetBgSize(66,66)}OncolliderClick(){
const t=l.Y.Inst.PrimaryRoleInfo_get().Id_get()
this.data.rankInfo.playerId.Equal(t)||I.Z.Inst().Open(this.data.rankInfo.playerId)}OnMorebtnClick(){if(null!=this.clickCheck){if(!this.clickCheck())return}
this.data.collapseType=m.S.EXPAND,g.x.Inst_get().RaiseEvent(g.x.TOTAL_EXPAND,this.data.rank)}OnLessbtnClick(){if(null!=this.clickCheck){if(!this.clickCheck())return}
this.data.collapseType=m.S.COLLAPSE,g.x.Inst_get().RaiseEvent(g.x.TOTAL_COLLAPSE,this.data.rank)}RemoveLis(){}SetData(t){this.AddLis(),this.data=t,
null!=t.rankInfo?(this.rolecontent.SetActive(!0),this.headIcon.spriteNameSet(_.Z.GetJobIcon(t.rankInfo.job,t.rankInfo.sex,!1)),
this.serverlab.textSet(g.x.Inst_get().GetItemName(t.rankInfo)),this.namelab.textSet(t.rankInfo.name),this.value.textSet(t.rankInfo.rankValue),
this.emptylab.SetActive(!1)):(this.rolecontent.SetActive(!1),this.emptylab.SetActive(!0))
const e=g.x.Inst_get().GetRewardConfigVo(t.activityid,t.rank)
if(d.M.String2Int(t.rank)<=3?(this.rankNum.textSet(""),this.rankSprite.SetActive(!0),this.rankSprite.spriteNameSet(u.b.Inst_get().GetRankIcon(t.rank))):(this.rankNum.SetActive(!0),
this.rankSprite.SetActive(!1),t.b_ShowRank()?this.rankNum.textSet(`${e.rank[0]}-${e.rank[1]}`):this.rankNum.textSet("")),this.bgsp2.SetActive(!0),
t.ShowExpandBtn())this.itemgrid.SetActive(!1),this.itemgrid.data_set(null),this.morebtn.SetActive(!0),this.lessbtn.SetActive(!1),this.bgsp2.SetActive(!1)
else if(t.ShowCollapseBtn())this.itemgrid.data_set(null),this.lessbtn.SetActive(!0),this.morebtn.SetActive(!1),this.bgsp2.SetActive(!1)
else if(this.morebtn.SetActive(!1),this.lessbtn.SetActive(!1),this.itemgrid.SetActive(!0),0==this.data.collapseAble){
const t=g.x.Inst_get().GetRankTypeRewardes(g.x.TOTALACT_ID,this.data.rank)
if(null!=t){const e=(t.Count()-3)*this.itemgrid.cellWidth,i=this.itemOringx-e,[s,n,a]=this.itemgrid.node.GetLocalPositionXYZ()
this.itemgrid.node.SetLocalPositionXYZ(i,n,a),this.itemgrid.data_set(t)}}else this.itemgrid.data_set(null),this.bgsp2.SetActive(!1)}Clear(){this.RemoveLis(),this.clickCheck=null,
super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}}).desTemplate="荣耀积分：{0}",s=n))||s},25166:(t,e,i)=>{
var s,n=i(18998),a=i(83908),o=i(5924),l=i(66788),r=i(30849),h=i(61613),d=i(52212),u=i(92679),c=i(94582),_=i(110)
n._decorator.ccclass("HonorKingsTotalRankView")(s=class extends((0,a.pA)(r.C)()){constructor(...t){super(...t),this.nowcurse=0,this.rankdata=null,this.timeid=-1,this.restrictId=-1,
this.inDrag=null,this.model=null}InitView(){super.InitView(),this.itemgrid.SetInitInfo("ui_honorkings_rankitem",null,_.s),
this.itemgrid.OnReposition_set(this.CreateDelegate(this.OnReposition))
const t=h.v.GetAdaptionWidth(720,1e3)
this.bg.widthSet(t),this.scrollpanel.node.transform.width=t
const e=d.F.zero_get()
e.x=t,e.y=430,this.inDrag=!1}AddLis(){this.m_handlerMgr.AddNotifyEvent(c.x.Inst_get(),c.x.TOTAL_EXPAND,this.CreateDelegate(this.OnTotalExpand)),
this.m_handlerMgr.AddNotifyEvent(c.x.Inst_get(),c.x.TOTAL_COLLAPSE,this.CreateDelegate(this.OnTotalExpand)),
this.m_handlerMgr.AddEventMgr(u.g.HUODONG_RANKINFO_UPDATE,this.CreateDelegate(this.OnSMGetRank))}OnDragStarted(){this.inDrag=!0}OnDragFinished(){this.ClearLockTimer(),
this.timeid=o.C.Inst_get().SetInterval(this.CreateDelegate(this.ReleaseLock),100)}ReleaseLock(){this.inDrag=!1}ClearLockTimer(){
this.timeid>-1&&o.C.Inst_get().ClearInterval(this.timeid),this.timeid=-1}OnStopMove(){l.Y.LogError("move stop")}OnSMGetRank(t){t.activityId==c.x.TOTALACT_ID&&(this.UpdateMyRank(),
this.UpdateDatas())}RemoveLis(){}OnCreateItem(t){}DragCheck(){return!this.inDrag}OnTotalExpand(t){this.nowcurse=0
for(let e=0;e<=this.rankdata.Count()-1;e++)t==this.rankdata[e].rank&&(this.nowcurse=e+1)
this.UpdateDatas()}ShowView(t){this.SetActive(t),t?(this.inDrag=!1,this.SetData()):this.Clear()}UpdateMyRank(){this.myrankitem.activityid=c.x.TOTALACT_ID,
this.myrankitem.rankType=this.model.GetRankType(this.myrankitem.activityid)
const t=c.x.Inst_get().GetRankDataByActid(c.x.TOTALACT_ID,this.myrankitem.rankType)
this.myrankitem.rank=t?t.rank:0,this.myrankitem.SetRankInfo(t)}UpdateMyRankValue(){}SetData(){this.model=c.x.Inst_get(),this.AddLis(),this.nowcurse=0,this.UpdateDatas(),
this.UpdateMyRank()}UpdateDatas(){this.rankdata=this.model.GetTotalRankDatas()
const[t,e,i]=this.scrollpanel.node.GetLocalPositionXYZ()
this.scrollpanel.node.SetLocalPositionXYZ(144,-87,0)
const s=this.scrollpanel.clipOffset(),n=d.F.zero_get()
n.x=s.x,n.y=0
const[a,l,r]=this.scrollpanel.node.GetLocalPositionXYZ()
this.scrollpanel.node.SetLocalPositionXYZ(a,l,r),this.itemgrid.data_set(this.rankdata),this.scrollpanel.node.SetLocalPositionXYZ(t,e,i),this.ClearRestrictTimer(),
this.restrictId=o.C.Inst_get().SetInterval(this.CreateDelegate(this.RestrictWithinBounds),50,1),this.scrollpanel.ResetPosition()}RestrictWithinBounds(){this.ClearRestrictTimer()}
ClearRestrictTimer(){this.restrictId>-1&&(o.C.Inst_get().ClearInterval(this.restrictId),this.restrictId=-1)}OnReposition(){const t=this.itemgrid.itemList
if(t){for(let e=0;e<t.Count()-1;e++)t[e].clickCheck=this.CreateDelegate(this.DragCheck)
this.RestrictWithinBounds()}}Clear(){this.RemoveLis(),this.ClearLockTimer(),this.ClearRestrictTimer(),this.itemgrid.Clear(),super.Clear()}Destroy(){super.Destroy()}Test1(){return!0
}S_Test(){return!0}})},25606:(t,e,i)=>{i.d(e,{X:()=>mt})
var s=i(42292),n=i(71409),a=i(17409),o=i(49655),l=i(77546),r=i(25236),h=i(97461),d=i(38935),u=i(56937),c=i(18202),_=i(31222),I=i(5494),g=i(32076),m=i(92415),C=i(52726),S=i(98885),p=i(21554),A=i(70850),f=i(34609),y=i(92679),T=i(74045),R=i(49067),v=i(57035),w=i(37648),D=i(55492),E=i(21103),L=i(5399),G=i(62164),O=i(85605),b=i(82025),B=i(60567),N=i(14792),P=i(62734),M=i(60647),V=i(13487),k=i(27158),x=i(65550),H=i(56834),U=i(93727),F=i(69559),Y=i(89373),K=i(99294),z=i(9986),Q=i(86290),Z=i(57834),X=i(93877),j=i(72005),J=i(61911),W=i(88653),$=i(52212),q=i(79534),tt=i(69015),et=i(93078),it=i(86209),st=i(19519)
class nt extends J.f{constructor(){super(),this.currencyUp=null,this.currencyDown=null,this.countLabel=null,this.totalPriceLabel=null,this.curCurrencyLabel=null,
this.addButton=null,this.leftButton=null,this.buyBtn=null,this.offset=null,this.noLimitObj=null,this.buyBtnLabel=null,this.maxBtn=null,this._degf_AddHandler=null,this.data=null,
this.curBuyCount=1,this.nextPrice=0,this.currencyType=null,this.curPrice=0,this.curMoney=0,this.maxBuyCount=0,this.tipIndex=null,this._degf_AddHandler=(t,e)=>this.AddHandler(t,e)}
InitView(){this.currencyUp=this.CreateComponent(j.w,1),this.currencyDown=this.CreateComponent(j.w,2),this.countLabel=this.CreateComponent(X.Q,3),
this.totalPriceLabel=this.CreateComponent(X.Q,4),this.curCurrencyLabel=this.CreateComponent(X.Q,5),this.addButton=this.CreateComponent(z.W,6),
this.leftButton=this.CreateComponent(z.W,7),this.buyBtn=this.CreateComponent(z.W,8),this.offset=this.CreateComponent(Q.G,9),this.noLimitObj=this.CreateComponent(K.z,10),
this.buyBtnLabel=this.CreateComponent(X.Q,11),this.maxBtn=this.CreateComponent(z.W,12)}OnAddToScene(){this.AddOrRemoveLis(!0),this.data=Y.X.Inst_get().m_curSelectedData,
this.currencyType=st.J.MAYA_HUNT_SCORE,this.curMoney=Y.X.Inst_get().GetScore(),this.curCurrencyLabel.textSet(it.w.Instance.ConvertNumToString(this.curMoney))
const t=st.J.GetCurrencyIconUrl(this.currencyType)
this.currencyUp.spriteNameSet(t),this.currencyDown.spriteNameSet(t),this.buyBtnLabel.textSet("兑 换"),this.maxBuyCount=this.data.limitBuy,
-1==this.maxBuyCount&&(this.maxBuyCount=9999)
const e=Y.X.Inst_get().exchangeInfo
let i=0
null!=e&&null!=e.curScore&&(i=e.curScore),i<this.maxBuyCount*this.data.prize&&(this.maxBuyCount=Math.floor(i/this.data.prize)),this.SetBuyCount(1),this.tipIndex=this.AddToLayout()}
AddToLayout(){const[t,e]=[0,140.6],[i,s]=[325,267]
return tt.g.Inst_get().AddTipByParam(null,tt.g.HorizontalAlign.Right,tt.g.VerticalAlign.Down,new $.F(t,e),new $.F(i,s))}SetBuyCount(t){this.countLabel.textSet(S.M.IntToString(t)),
this.curBuyCount=t,
this.curPrice=this.data.prize*t,this.curPrice<=this.curMoney?this.totalPriceLabel.SetColor(new W.I(.8,.796,.768)):this.totalPriceLabel.SetColor(new W.I(.8706,.1451,.1412)),
this.totalPriceLabel.textSet(it.w.Instance.ConvertNumToString(this.curPrice))}OnSetMaxBuyCount(){this.SetBuyCount(this.maxBuyCount)}AddOrRemoveLis(t){null==t&&(t=!0),
t?(Z.i.Get(this.addButton.node).RegistonClick(this.CreateDelegate(this.OnAddButtonClick)),Z.i.Get(this.leftButton.node).RegistonClick(this.CreateDelegate(this.OnSubButtonClick)),
Z.i.Get(this.buyBtn.node).RegistonClick(this.CreateDelegate(this.OnBuyButtonClick)),Z.i.Get(this.countLabel.node).RegistonClick(this.CreateDelegate(this.SelectUseNumHandler)),
INS.luaEventMgr.AddEventHandler(y.g.BASE_TIP_CLOSE,this.CreateDelegate(this.OnCloseHandler)),
this.m_handlerMgr.AddClickEvent(this.maxBtn.node,this.CreateDelegate(this.OnSetMaxBuyCount))):(Z.i.Get(this.addButton.node).RemoveonClick(this.CreateDelegate(this.OnAddButtonClick)),
Z.i.Get(this.leftButton.node).RemoveonClick(this.CreateDelegate(this.OnSubButtonClick)),Z.i.Get(this.buyBtn.node).RemoveonClick(this.CreateDelegate(this.OnBuyButtonClick)),
Z.i.Get(this.countLabel.node).RemoveonClick(this.CreateDelegate(this.SelectUseNumHandler)),
INS.luaEventMgr.RemoveEventHandler(y.g.BASE_TIP_CLOSE,this.CreateDelegate(this.OnCloseHandler)))}OnCloseHandler(){mt.Inst_get().CloseExchangeTipView()}SelectUseNumHandler(){
et.F.Instance_get().OpenView(new q.P(363,-205,0),this._degf_AddHandler)}AddHandler(t,e){10==t?this.curBuyCount=1:e?this.curBuyCount=t:(this.curBuyCount*=10,this.curBuyCount+=t),
this.curBuyCount<=0&&(this.curBuyCount=1),this.curBuyCount=Math.min(this.curBuyCount,this.maxBuyCount),this.SetBuyCount(this.curBuyCount)}OnBuyButtonClick(){
this.curPrice>this.curMoney?x.y.inst.ClientSysMessage(100543):A.g.Inst_get().getBagEmptyGridNum()<1?x.y.inst.ClientSysMessage(300005):(mt.Inst_get().SendCM_ExchangeItem(this.data.id,this.curBuyCount),
p.J.Inst_get().CloseTipView())}OnSubButtonClick(){this.curBuyCount<=1||(this.curBuyCount-=1,this.SetBuyCount(this.curBuyCount))}OnAddButtonClick(){
-1!=this.maxBuyCount&&this.maxBuyCount<=this.curBuyCount||(this.curBuyCount+=1,this.SetBuyCount(this.curBuyCount))}Clear(){et.F.Instance_get().CloseView(),
null!=this.tipIndex&&(tt.g.Inst_get().RemoveByTip(),this.tipIndex=null),this.curBuyCount=1,this.curMoney=0,this.AddOrRemoveLis(!1),this.data=null,super.Clear()}Destroy(){
et.F.Instance_get().CloseView(),this.currencyUp=null,this.currencyDown=null,this.countLabel=null,this.totalPriceLabel=null,this.curCurrencyLabel=null,this.addButton=null,
this.leftButton=null,this.buyBtn=null,this.offset=null,this.noLimitObj=null,super.Destroy()}}var at,ot,lt,rt,ht,dt,ut,ct,_t,It=i(5946)
function gt(t,e,i,s,n){var a={}
return Object.keys(s).forEach((function(t){a[t]=s[t]})),a.enumerable=!!a.enumerable,a.configurable=!!a.configurable,("value"in a||a.initializer)&&(a.writable=!0),
a=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),a),n&&void 0!==a.initializer&&(a.value=a.initializer?a.initializer.call(n):void 0,a.initializer=void 0),
void 0===a.initializer&&(Object.defineProperty(t,e,a),a=null),a}let mt=(at=(0,n.GH)(m.k.SM_ExchangeResult),ot=(0,n.GH)(m.k.SM_ExchangeShopBuyInfo),lt=(0,
n.GH)(m.k.SM_ExchangeShopConfig),rt=(0,n.GH)(m.k.SM_LotteryReplace),ht=(0,n.GH)(m.k.SM_MayaLotteryConfig),dt=(0,n.GH)(m.k.SM_MayaLotteryInfo),ut=(0,n.GH)(m.k.SM_MayaLotteryResult),
_t=class t{constructor(){this.num=0,this.isClick=null,this.actId=null,this.view=null,this.resultView=null,this.exchangeTipView=null,this.isMulti=null,this.isNotRemind1=null,
this.isNotRemind2=null,this.sendNum=null,this.isNotRemind30=null,this.isSet=null,this.selectId=null,this.isNotRemind3=null,this.isNotRemind31=null,this.isNotRemind32=null,
this.AddLis(),this.RegisterProtocol()}static Inst_get(){return null==t.inst&&(t.inst=new t),t.inst}AddLis(){h.i.Inst.AddEventHandler(y.g.BAG_UPDATE,(0,g.v)(this.BagUpdate,this)),
h.i.Inst.AddEventHandler(y.g.BAG_INITED,(0,g.v)(this.BagUpdate,this))}BagUpdate(){if(!w.P.Inst_get().IsFunctionOpened(D.x.MAYA_TREASURE))return
let t=!1
const e=A.g.Inst_get().GetItemNum(Y.X.Inst_get().GetHuntItemId())
if(e<=0)t=!1
else{const i=P.f.Inst.GetData(N.t.MAYA_TREASURE);(null!=i&&i.show&&!this.isClick||e>this.num&&(0==this.num||e>=10))&&(t=!0)}this.num=e,P.f.Inst.SetState(N.t.MAYA_TREASURE,t)}
RegisterProtocol(){}SM_ExchangeResultHandle(t){Y.X.Inst_get().SetExchangeResult(t),Y.X.Inst_get().RaiseEvent(F.E.EXCHANGE_SUCCESS)}SM_ExchangeShopBuyInfoHandle(t){
Y.X.Inst_get().SetExchangeShopInfo(t),Y.X.Inst_get().RaiseEvent(F.E.EXCHANGE_INFO_UPDATE)}SM_ExchangeShopConfigHandle(t){Y.X.Inst_get().SetExchangeShopConfig(t),
Y.X.Inst_get().RaiseEvent(F.E.EXCHANGE_CONFIG_UPDATE)}SM_LotteryReplaceHandle(t){Y.X.Inst_get().SetReplaceInfo(t),Y.X.Inst_get().RaiseEvent(F.E.REPLACE_INFO_UPDATE)}
SM_MayaLotteryConfigHandle(t){Y.X.Inst_get().SetTreasureConfig(t),this.actId=t.activityId,Y.X.Inst_get().RaiseEvent(F.E.TREASURE_CONFIG_UPDATE)}SM_MayaLotteryInfo(t){
Y.X.Inst_get().SetTreasureInfo(t),Y.X.Inst_get().RaiseEvent(F.E.TREASURE_INFO_UPDATE)}SM_MayaLotteryResultHandle(t){Y.X.Inst_get().SetTreasureResultInfo(t),
null==this.view&&this.OpenResultView(),Y.X.Inst_get().RaiseEvent(F.E.TREASURE_SUCCESS)}SendCM_ExchangeItem(t,e,i){null==i&&(i=this.GetActivityId())
const s=new E.R
s.id=t,s.num=e,s.activityId=i,d.C.Inst.F_SendMsg(s)}SendCM_LotteryReplace(t,e,i){null==i&&(i=this.GetActivityId())
const s=new L.A
s.curId=t,s.targetId=e,s.activityId=i,d.C.Inst.F_SendMsg(s)}SendCM_MayaLottery(t,e){null==t&&(t=!1),null==e&&(e=this.GetActivityId())
const i=new G.c
i.isMulti=t,i.activityId=e,d.C.Inst.F_SendMsg(i)}SendSetAnim(t){let e=0
t&&(e=1),M.p.inst.SendClientLogicSetting(V.R.MAYA_TREASURE_PASS,e)}OpenView(t=null){if(!w.P.Inst_get().IsFunctionOpened(D.x.MAYA_TREASURE))return
if(Y.X.Inst_get().defaultView=t,null!=this.view&&this.view.isShow_get())return
Y.X.Inst_get().isEnd=!1
const e=new u.v
e.isShowMask=!0,e.isDefaultUITween=!0,e.isSelfTween=!1,(0,a.Yp)(o.o.MayaTreasureView,e)}CloseView(){(0,a.sR)(o.o.MayaTreasureView)}DestroyViewHandler(){c.g.DestroyUIObj(this.view),
this.view=null}ShowViewHandler(t){}OpenResultView(){if(null!=this.resultView&&this.resultView.isShow_get())return void this.resultView.UpdateView()
const t=new u.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!1,_.N.inst.OpenById(I.I.MayaTreasureResultView,this.ShowResultViewHandler,this.DestroyResultViewHandler,t)}CloseResultView(){
_.N.inst.CloseById(I.I.MayaTreasureResultView)}DestroyResultViewHandler(){c.g.DestroyUIObj(this.resultView),this.resultView=null}ShowResultViewHandler(t){
return null==this.resultView&&(this.resultView=new It.k,this.resultView.setId(t,null,0)),this.resultView}OpenExchangeTipView(){
if(null!=this.exchangeTipView&&this.exchangeTipView.isShow_get())return
const t=new u.v
t.isShowMask=!1,t.isDefaultUITween=!0,t.isSelfTween=!1,t.layerType=C.F.Tip,_.N.inst.OpenById(I.I.MayaExchangeTipView,this.ShowExchangeTipViewHandler,this.DestroyExchangeTipViewHandler,t)
}CloseExchangeTipView(){_.N.inst.CloseById(I.I.MayaExchangeTipView)}DestroyExchangeTipViewHandler(){c.g.DestroyUIObj(this.exchangeTipView),this.exchangeTipView=null}
ShowExchangeTipViewHandler(t){return null==this.exchangeTipView&&(this.exchangeTipView=new nt,this.exchangeTipView.setId(t,null,0)),this.exchangeTipView}IsLimitBestAward(){
const t=Y.X.Inst_get().treasureConfig
if(null!=t&&null!=t.curPoolItemVos){const e=t.curPoolItemVos[1]
if(null!=e&&1==e.bonusRank){const t=e.id
if(-1==e.maxLimit)return!0
if(this.GetNumById(t)<e.maxLimit)return!0}}if(null!=t&&null!=t.historyItemVos)for(let e=0;e<=t.historyItemVos.Count()-1;e++){const i=t.historyItemVos[e]
if(null!=i&&1==i.bonusRank){const t=i.id
if(-1==i.maxLimit)return!0
if(this.GetNumById(t)<i.maxLimit)return!0}}return!1}GetNumById(t){let e=0
const i=Y.X.Inst_get().treasureInfo
return null!=i&&null!=i.lotteryId2Count&&i.lotteryId2Count.LuaDic_ContainsKey(t)&&(e=i.lotteryId2Count[t]),e}GetExchangeNumById(t){let e=0
const i=Y.X.Inst_get().exchangeInfo
return null!=i&&null!=i.buyInfo&&i.buyInfo.LuaDic_ContainsKey(t)&&(e=i.buyInfo[t]),e}GetExchangeRemainNum(t){return-1==t.limitBuy?0:t.limitBuy-this.GetExchangeNumById(t.id)}
GoHuntHandle(t){this.isMulti=t
let e=1
if(t&&(e=10),null==Y.X.Inst_get().treasureConfig||null==Y.X.Inst_get().treasureInfo){x.y.inst.ClientSysStrMsg("等待数据中...")
let t=""
return null==Y.X.Inst_get().treasureConfig&&(t+="1"),null==Y.X.Inst_get().treasureInfo&&(t+="2"),void l.s.Info(`玛雅寻宝Exception:${t}`)}
const i=Y.X.Inst_get().treasureConfig.curPoolItemVos[1]
if(this.IsLimitBestAward())this.GoHuntHandleEx()
else if(null!=i&&1==i.changeable&&this.IsCanChangeByBonus(i.bonusRank))if(this.isNotRemind1)if(this.isNotRemind2)this.GoHuntHandleEx()
else{const t="MAYA LOTTERY:BONUS_NOTICE2",e=new R.B
e.infoId=t,e.cancelHandle=this.GoHuntHandleEx,e.confirmText="暂不抽取",e.cancelText="继续抽取",e.isShowMask=!0,e.checkChanged=this.SetNotRemind2,T.t.Inst().Open(e)}else{
const t="MAYA LOTTERY:BONUS_NOTICE1",e=new R.B
e.infoId=t,e.confirmHandle=this.ConfirmHandle1,e.cancelHandle=this.GoHuntHandleEx,e.confirmText="立即前往",e.cancelText="暂不前往",e.isShowMask=!0,e.checkChanged=this.SetNotRemind1,
T.t.Inst().Open(e)}else if(this.isNotRemind2)this.GoHuntHandleEx()
else{const t="MAYA LOTTERY:BONUS_NOTICE2",e=new R.B
e.infoId=t,e.cancelHandle=this.GoHuntHandleEx,e.confirmText="暂不抽取",e.cancelText="继续抽取",e.isShowMask=!0,e.checkChanged=this.SetNotRemind2,T.t.Inst().Open(e)}}ConfirmHandle1(){
null!=this.resultView&&this.resultView.isShow_get()&&this.CloseResultView()
const t=Y.X.Inst_get().treasureConfig.curPoolItemVos[1]
if(null!=t&&1==t.changeable&&this.IsCanChangeByBonus(t.bonusRank))Y.X.Inst_get().RaiseEvent(F.E.OPEN_REPLACE_BIG)
else if(this.isNotRemind2)this.GoHuntHandleEx()
else{const t="MAYA LOTTERY:BONUS_NOTICE2",e=new R.B
e.infoId=t,e.cancelHandle=this.GoHuntHandleEx,e.confirmText="暂不抽取",e.cancelText="继续抽取",e.isShowMask=!0,e.checkChanged=this.SetNotRemind2,T.t.Inst().Open(e)}}IsCanChangeByBonus(t){
if(null!=Y.X.Inst_get().treasureConfig){const e=Y.X.Inst_get().treasureConfig.historyItemVos
if(null!=e)for(let i=0;i<=e.Count()-1;i++){const s=e[i]
if(1==s.changeable&&s.bonusRank==t){const t=s.maxLimit
if(this.GetNumById(s.id)<t)return!0}}}return!1}GoHuntHandleEx(){let t=2
if(this.isMulti&&(t=10),A.g.Inst_get().emptySize_get()>=t)this.GoHuntHandleExx()
else if(f.N.Inst_get().emptySize_get()>=t)this.GoHuntHandleExx()
else{const t="BAG:FULL_NOTICE",e=new R.B
e.infoId=t,e.confirmHandle=this.OpenOneKeyRecycle,e.confirmText="立即前往",e.cancelText="暂不前往",e.isShowMask=!0,T.t.Inst().Open(e)}}OpenOneKeyRecycle(){p.J.Inst_get().OpenBagSellPanel()
}GoHuntHandleExx(){const t=Y.X.Inst_get().GetHuntItemId(),e=A.g.Inst_get().GetItemNum(t)
let i=0,s=0,n=1
if(this.isMulti&&(n=10),this.isMulti?this.sendNum=n:this.sendNum=1,A.g.Inst_get().emptySize_get()<1&&0==e&&e<this.sendNum)return x.y.inst.ClientSysMessage(300005),
void this.OpenOneKeyRecycle()
let a=!1,o=0
const l=this.GetMallInfo()
if(null!=l&&e<n){if(o=l.Consume_Get().GetItemDataByType().count,i=l.limit,-1==i?(a=!0,i=0):i-=B.P.ins.GetBuyTimesByMallId(l.mallId),s=i,i>=n-e&&(i=n-e),i&&i<=0){
const t=k.V.GetItemNameStr(l.Cfg_get())
return void x.y.inst.ClientSysStrMsg(`${t}已售空，无法购买`)}}this.isNotRemind30=null,this.isSet=!1,e>=n?this.SendHuntHandle():this.GoHuntHandleExxx()}GoHuntHandleExxx(){
const t=Y.X.Inst_get().GetHuntItemId();(0,r.S)(this.GetActivityId())
O.$.ins.CheckItemEnough(this.GetActivityId(),t,this.sendNum,null,null)?this.SendCM_MayaLottery(this.isMulti,null):h.i.Inst.AddEventHandler(y.g.HUODONG_MALL_BUY_SUCCESS,(0,
g.v)(this.BuySuccessHandle,this))}BuySuccessHandle(t){const e=this.GetMallInfo()
null!=e&&t.mallId==e.mallId&&(h.i.Inst.RemoveEventHandler(y.g.HUODONG_MALL_BUY_SUCCESS,(0,g.v)(this.BuySuccessHandle,this)),this.SendCM_MayaLottery(this.isMulti,null))}
GetMallInfo(){return B.P.ins.GetVoByHuodongIdAndType(this.GetActivityId(),b.f.TICKET_TYPE)}SendHuntHandle(){if(null==this.isMulti)return
const t=Y.X.Inst_get().GetHuntItemId(),e=A.g.Inst_get().GetItemNum(t)
let i=1
this.isMulti&&(i=10),e>=i&&(this.SendCM_MayaLottery(this.isMulti,null),this.isMulti=null)}SetNotRemind1(t){this.isNotRemind1=t}SetNotRemind2(t){this.isNotRemind2=t}
SetNotRemind3(t){this.isNotRemind30=t}SetSelectReplaceItem(t){this.selectId=t,Y.X.Inst_get().RaiseEvent(F.E.SELECT_REPLACE_ITEM)}IsPassAnim(){
let t=1==M.p.inst.GetClientLogicSetting(V.R.MAYA_TREASURE_PASS)
return null!=this.resultView&&this.resultView.isShow_get()&&(t=t&&!0),t}GetActivityId(){if(!this.IsActivityOpen(this.actId)){const t=this.GetFunctionOpenActId()
null!=t&&(this.actId=t)}return null==this.actId&&(this.actId=0),this.actId}IsActivityOpen(t){if(U.i.ins.GetState(t)==H.V.END||U.i.ins.GetState(t)==H.V.OPEN)return!0}
GetFunctionOpenActId(){const t=v.d.Inst_get().getItemById(D.x.MAYA_TREASURE),e=S.M.SubStringWithLen(t.activityIds,1,S.M.Length(t.activityIds)-2),i=S.M.Split(e,S.M.s_SPAN_CHAR)
for(let t=0;t<=i.Count()-1;t++){const e=S.M.String2Int(i[t])
if(this.IsActivityOpen(e))return e}}ResetData(){this.selectId=null,this.isNotRemind1=null,this.isNotRemind2=null,this.isNotRemind3=null,this.isNotRemind31=null,
this.isNotRemind32=null,this.isNotRemind30=null,this.isClick=!1,this.num=0,this.actId=0,Y.X.Inst_get().ResetModel()}SetIsClick(t){this.isClick=t,
t&&P.f.Inst.SetState(N.t.MAYA_TREASURE,!1)}},_t.inst=null,gt(ct=_t,"Inst_get",[s.n],Object.getOwnPropertyDescriptor(ct,"Inst_get"),ct),
gt(ct.prototype,"SM_ExchangeResultHandle",[at],Object.getOwnPropertyDescriptor(ct.prototype,"SM_ExchangeResultHandle"),ct.prototype),
gt(ct.prototype,"SM_ExchangeShopBuyInfoHandle",[ot],Object.getOwnPropertyDescriptor(ct.prototype,"SM_ExchangeShopBuyInfoHandle"),ct.prototype),
gt(ct.prototype,"SM_ExchangeShopConfigHandle",[lt],Object.getOwnPropertyDescriptor(ct.prototype,"SM_ExchangeShopConfigHandle"),ct.prototype),
gt(ct.prototype,"SM_LotteryReplaceHandle",[rt],Object.getOwnPropertyDescriptor(ct.prototype,"SM_LotteryReplaceHandle"),ct.prototype),
gt(ct.prototype,"SM_MayaLotteryConfigHandle",[ht],Object.getOwnPropertyDescriptor(ct.prototype,"SM_MayaLotteryConfigHandle"),ct.prototype),
gt(ct.prototype,"SM_MayaLotteryInfo",[dt],Object.getOwnPropertyDescriptor(ct.prototype,"SM_MayaLotteryInfo"),ct.prototype),
gt(ct.prototype,"SM_MayaLotteryResultHandle",[ut],Object.getOwnPropertyDescriptor(ct.prototype,"SM_MayaLotteryResultHandle"),ct.prototype),ct)},69559:(t,e,i)=>{i.d(e,{E:()=>s})
class s{}s.EXCHANGE_SUCCESS="EXCHANGE_SUCCESS",s.EXCHANGE_INFO_UPDATE="EXCHANGE_INFO_UPDATE",s.EXCHANGE_CONFIG_UPDATE="EXCHANGE_CONFIG_UPDATE",
s.REPLACE_INFO_UPDATE="REPLACE_INFO_UPDATE",s.TREASURE_CONFIG_UPDATE="TREASURE_CONFIG_UPDATE",s.TREASURE_INFO_UPDATE="TREASURE_INFO_UPDATE",s.TREASURE_SUCCESS="TREASURE_SUCCESS",
s.SELECT_REPLACE_ITEM="SELECT_REPLACE_ITEM",s.OPEN_REPLACE_BIG="OPEN_REPLACE_BIG",s.RESULT_ANIM_END="RESULT_ANIM_END",s.JUMP_RESULT_ANIM="JUMP_RESULT_ANIM"},89373:(t,e,i)=>{i.d(e,{
X:()=>o})
var s=i(77546),n=i(38836),a=i(16812)
class o extends a.k{constructor(...t){super(...t),this.defaultView=0,this.exchangeResultInfo=null,this.exchangeInfo=null,this.exchangeConfig=null,this.replaceInfo=null,
this.treasureConfig=null,this.treasureInfo=null,this.treasureResultInfo=null,this.m_curSelectedData=null,this.isEnd=!1}static Inst_get(){return null==o.inst&&(o.inst=new o),o.inst}
ResetModel(){this.defaultView=0,this.isEnd=!1}GetHuntItemId(){return 12002}GetScoreItemId(){return 12008}GetScore(){let t=0
return null!=this.exchangeInfo&&null!=this.exchangeInfo.curScore&&(t=this.exchangeInfo.curScore),t}GetDefaultView(){return this.defaultView}SetExchangeResult(t){
if(this.exchangeResultInfo=t,null!=this.exchangeInfo&&null!=this.exchangeInfo.buyInfo){this.exchangeInfo.curScore=t.score
const e=this.exchangeInfo.buyInfo
let i=t.num
e.LuaDic_ContainsKey(t.itemId)&&(i=e[t.itemId]+i),this.exchangeInfo.buyInfo.LuaDic_AddOrSetItem(t.itemId,i)}}SetExchangeShopInfo(t){this.exchangeInfo=t}SetExchangeShopConfig(t){
this.exchangeConfig=t}SetReplaceInfo(t){this.replaceInfo=t
let e=null,i=null,s=null,a=null
if(null!=this.treasureConfig){if(null!=this.treasureConfig.curPoolItemVos)for(const[s,a]of(0,n.vy)(this.treasureConfig.curPoolItemVos)){const n=a
if(null!=t.exchangeBefore&&n.id==t.exchangeBefore){e=n,i=s
break}}if(null!=this.treasureConfig.historyItemVos)for(let e=0;e<=this.treasureConfig.historyItemVos.Count()-1;e++){const i=this.treasureConfig.historyItemVos[e]
if(null!=t.exchangeAfter&&i.id==t.exchangeAfter){s=i,a=e
break}}null!=s&&null!=e&&(this.treasureConfig.curPoolItemVos.LuaDic_AddOrSetItem(i,s),this.treasureConfig.historyItemVos.RemoveAt(a),this.treasureConfig.historyItemVos.Add(e))}}
SetTreasureConfig(t){let e="玛雅寻宝收到SM_MayaLotteryConfig"
null!=t&&null!=t.curPoolItemVos&&0!=t.curPoolItemVos.Count()||(e+="Exception:数据是空的"),s.s.Info(e),this.treasureConfig=t}SetTreasureInfo(t){let e="玛雅寻宝收到SM_MayaLotteryInfo"
null==t&&(e+="Exception:数据是空的"),s.s.Info(e),this.treasureInfo=t}SetTreasureResultInfo(t){this.treasureResultInfo=t}GetConfigById(t){if(null!=this.treasureConfig){
if(null!=this.treasureConfig.curPoolItemVos)for(const[e,i]of(0,n.vy)(this.treasureConfig.curPoolItemVos)){const e=i
if(e.id==t)return e}if(null!=this.treasureConfig.historyItemVos)for(let e=0;e<=this.treasureConfig.historyItemVos.Count()-1;e++){const i=this.treasureConfig.historyItemVos[e]
if(i.id==t)return i}}}}o.inst=null},16326:(t,e,i)=>{var s,n=i(18998),a=i(83908),o=i(57834),l=i(51868),r=i(85602),h=i(25606),d=i(89373),u=i(32615)
n._decorator.ccclass("MayaChangeRewardView")(s=class extends((0,a.pA)(l.$)()){constructor(...t){super(...t),this.data=null}InitView(){super.InitView(),
this.grid.SetInitInfo("ui_maya_hunttreasure_item",null,u.O)}SetData(){this.UpdateView()}UpdateView(t){this.data=t
const e=t.bonusRank,i=new r.Z
if(null!=d.X.Inst_get().treasureConfig){const t=d.X.Inst_get().treasureConfig.historyItemVos
if(null!=t)for(let s=0;s<=t.Count()-1;s++){const n=t[s]
1==n.changeable&&n.bonusRank==e&&i.Add(n)}}i.Count()>0?(h.X.Inst_get().selectId=i[0].id,this.node.SetActive(!0)):h.X.Inst_get().selectId=null,this.grid.data_set(i)}Clear(){
super.Clear(),this.grid.Clear(),this.RemoveLis()}Destroy(){}AddLis(){o.i.Get(this.confirmBtn.node).RegistonClick(this.CreateDelegate(this.OnConfirmBtnHandler)),
o.i.Get(this.closeBtn.node).RegistonClick(this.CreateDelegate(this.OnCloseBtnHandle))}RemoveLis(){
o.i.Get(this.confirmBtn.node).RemoveonClick(this.CreateDelegate(this.OnConfirmBtnHandler)),o.i.Get(this.closeBtn.node).RemoveonClick(this.CreateDelegate(this.OnCloseBtnHandle))}
OnConfirmBtnHandler(){null!=h.X.Inst_get().selectId&&h.X.Inst_get().SendCM_LotteryReplace(this.data.id,h.X.Inst_get().selectId),this.OnCloseBtnHandle()}OnCloseBtnHandle(){
this.node.SetActive(!1)}})},67764:(t,e,i)=>{var s,n=i(18998),a=i(83908),o=i(9057),l=i(57834),r=i(21554),h=i(63076),d=i(92679),u=i(87923),c=i(65550),_=i(25606),I=i(69559),g=i(89373)
n._decorator.ccclass("MayaExchangeItem")(s=class extends((0,a.pA)(o.x)()){constructor(...t){super(...t),this.data=null,this._baseItemData=null}InitView(){super.InitView()}
Destroy(){this.ui_baseitem.Destroy()}SetData(t){if(this.limitGo.SetActive(!1),this.data=t,null!=this.data){this._baseItemData=new h.M(this.data.itemId),
this._baseItemData.count=this.data.num,this.ui_baseitem.ClickHandler_Set(this.CreateDelegate(this.ClickHandle)),this.ui_baseitem.SetData(this._baseItemData)
const t=this._baseItemData.cfgData_get(),e=u.l.getColorStrByQuality(t.quality)
this.nameLabel.textSet(`[${e}]${t.name}[-]`)}this.AddLis(),this.RefreshInfo()}ClickHandle(){if(null!=this.data&&-1!=this.data.limitBuy){
_.X.Inst_get().GetExchangeNumById(this.data.id)>=this.data.limitBuy&&c.y.inst.ClientSysMessage(101523)}}RefreshInfo(){let t=!0
if(this.limitTipLabel.node.SetActive(!1),this.costContainer.node.SetActive(!0),this.buyBtn.node.SetActive(!0),null!=this.data&&-1!=this.data.limitBuy){
this.limitTipLabel.node.SetActive(!0)
const e=_.X.Inst_get().GetExchangeNumById(this.data.id)
let i=`${this.data.limitBuy-e}/${this.data.limitBuy}`
e>=this.data.limitBuy?(t=!1,i=`[ff0000]${i}[-]`):i=`[ffffff]${i}[-]`,this.limitTipLabel.textSet(`终身限购${i}`)}if(0==t)this.limitGo.SetActive(!0),
this.costContainer.node.SetActive(!1),this.buyBtn.node.SetActive(!1)
else if(null!=this.data){let t=this.data.prize,e=0
const i=g.X.Inst_get().exchangeInfo
null!=i&&null!=i.curScore&&(e=i.curScore),t=t>e?`[ff0000]${t}[-]`:`[ffffff]${t}[-]`,this.costLabel.textSet(t)}}AddLis(){
g.X.Inst_get().AddEventHandler(I.E.EXCHANGE_SUCCESS,this.CreateDelegate(this.RefreshInfo)),l.i.Get(this.buyBtn.node).RegistonClick(this.CreateDelegate(this.BuyBtnHandle))}
RemoveLis(){l.i.Get(this.buyBtn.node).RemoveonClick(this.CreateDelegate(this.BuyBtnHandle)),
g.X.Inst_get().RemoveEventHandler(I.E.EXCHANGE_SUCCESS,this.CreateDelegate(this.RefreshInfo))}BuyBtnHandle(){const t=this.data.prize
let e=0
const i=g.X.Inst_get().exchangeInfo
if(null!=i&&null!=i.curScore&&(e=i.curScore),t<=e){if(!(_.X.Inst_get().GetExchangeRemainNum(this.data)>0))return void c.y.inst.ClientSysMessage(100543)
INS.luaEventMgr.AddEventHandler(d.g.TipsLoadCompelete,this.CreateDelegate(this.OpenBuyTip)),r.J.Inst_get().ShowItemTip(this._baseItemData)}else c.y.inst.ClientSysMessage(100543)}
OpenBuyTip(){INS.luaEventMgr.RemoveEventHandler(d.g.TipsLoadCompelete,this.CreateDelegate(this.OpenBuyTip)),g.X.Inst_get().m_curSelectedData=this.data,
_.X.Inst_get().OpenExchangeTipView()}Clear(){this.data=null,this.ui_baseitem.Clear(),this.RemoveLis()}})},32615:(t,e,i)=>{i.d(e,{O:()=>I})
var s,n=i(18998),a=i(83908),o=i(38045),l=i(9057),r=i(85602),h=i(21554),d=i(63076),u=i(25606),c=i(69559),_=i(89373)
let I=n._decorator.ccclass("MayaHuntTreasureItem")(s=class extends((0,a.pA)(l.x)()){constructor(...t){super(...t),this.isShowSubIcon=!1,this.isShowSelect=!0,this.itemData=null,
this.data=null}InitView(){super.InitView()}Destroy(){this.baseItem.Destroy(),super.Destroy()}SetData(t){if(this.data=t,this.SetShowSubIcon(this.isShowSubIcon),
this.SetIsShowSelectState(this.isShowSelect),null!=this.data){const t=new r.Z
if(null!=this.data.reward&&null!=this.data.reward.rewards){let e=0
for(;e<this.data.reward.rewards.Count();){const i=d.M.wrapReward(this.data.reward.rewards[e])
t.Add(i),e+=1}}null!=t&&t.Count()>0&&(this.itemData=t[0],this.baseItem.EnabledClickOpenTip(!1),this.baseItem.ClickHandler_Set(this.CreateDelegate(this.ClickHandle)),
this.baseItem.SetData(this.itemData))}this.AddLis(),this.RefreshInfo()}ClickHandle(){if(this.isShowSelect){const t=u.X.Inst_get().selectId
null!=this.data&&this.data.id!=t&&u.X.Inst_get().SetSelectReplaceItem(this.data.id)}else h.J.Inst_get().ShowItemTip(this.itemData)}SetShowSubIcon(t){this.isShowSubIcon=t,
this.big.SetActive(!1),this.mid.SetActive(!1),this.isShowSubIcon&&null!=this.data&&(1==this.data.bonusRank?this.big.SetActive(!0):2==this.data.bonusRank&&this.mid.SetActive(!0))}
SetIsShowSelectState(t){this.isShowSelect=t,this.isShowSelect?this.RefreshSelectState():this.selectImg.SetActive(!1)}RefreshInfo(){if(this.numTxt.node.SetActive(!1),
this.noNum.SetActive(!1),null!=this.data&&-1!=this.data.maxLimit){this.numTxt.node.SetActive(!0)
let t=""
const e=this.data.maxLimit,i=u.X.Inst_get().GetNumById(this.data.id)
t=(0,o.tw)(e-i),e-i<=0&&(t=`[962424]${t}[-]`),t+=`/${e}`,this.numTxt.textSet(t),this.noNum.SetActive(i>=e)}}AddLis(){
_.X.Inst_get().AddEventHandler(c.E.SELECT_REPLACE_ITEM,this.CreateDelegate(this.RefreshSelectState)),
_.X.Inst_get().AddEventHandler(c.E.TREASURE_INFO_UPDATE,this.CreateDelegate(this.RefreshInfo))}RemoveLis(){
_.X.Inst_get().RemoveEventHandler(c.E.SELECT_REPLACE_ITEM,this.CreateDelegate(this.RefreshSelectState)),
_.X.Inst_get().RemoveEventHandler(c.E.TREASURE_INFO_UPDATE,this.CreateDelegate(this.RefreshInfo))}RefreshSelectState(){if(this.selectImg.SetActive(!1),this.isShowSelect){
const t=u.X.Inst_get().selectId
null!=t&&t==this.data.id&&this.selectImg.SetActive(!0)}}Clear(){this.data=null,this.baseItem.Clear(),this.RemoveLis(),super.Clear()}})||s},13605:(t,e,i)=>{i.d(e,{M:()=>w})
var s=i(18998),n=i(83908),a=i(38045),o=i(9057),l=i(57834),r=i(18202),h=i(83540),d=i(85602),u=i(21554),c=i(63076),_=i(87923),I=i(93984),g=i(32076),m=i(55360),C=i(98885),S=i(38962),p=i(75439),A=i(10509)
class f{constructor(){this.map=null,this.mallId=null,this.levelDic=null,this.levelLis=null
const t=m.Y.Inst.GetOrCreateCsv(I.h.eMayaLotteryResource)
this.map=t.GetCsvMap(),this._InitConfig()}static Inst_get(){return null==f.inst&&(f.inst=new f),f.inst}_InitConfig(){this.mallId=p.D.getInstance().GetIntValue("MAYA_DIAMOND")
let t=p.D.getInstance().GetStringValue("MAYA_SHOP_TIPS")
const e=C.M.Split(t,",")
this.levelDic=new S.X,this.levelLis=new d.Z
for(let i=0;i<=e.Count()-1;i++)if(t=e[i],null!=t){const e=C.M.Split(t,"_"),i=(0,a.aI)(e[0]),s=(0,a.aI)(e[1])
this.levelDic[i]=s,this.levelLis.Add(i)}this.levelLis.Sort((0,g.v)(this.SortLevel,this))}SortLevel(t,e){return t-e}GetShowLevelNumByLevel(t=0){let e=0,i=1,s=0
const n=A.L.Inst().MaxLevel_get()
if(t==n)return[null,null]
if(null!=this.levelLis)for(let n=0;n<=this.levelLis.Count()-1;n++){s=n
const a=this.levelLis
if(!(t>=a)){i=this.levelLis[s]-1
break}e=this.levelDic[a]}return 1==i&&(i=n),[i,e]}GetResById(t){return this.map[t]}}f.inst=null
var y,T=i(25606),R=i(69559),v=i(89373)
let w=s._decorator.ccclass("MayaTreasureItem")(y=class extends((0,n.pA)(o.x)()){constructor(...t){super(...t),this.itemData=null,this.data=null}InitView(){super.InitView()}
Destroy(){super.Destroy()}SetData(t){if(this.data=t,this.itemImg.node.SetActive(!1),this.bigImg.node.SetActive(!1),null!=this.data){const t=new d.Z
if(null!=this.data.reward&&null!=this.data.reward.rewards){let e=0
for(;e<this.data.reward.rewards.Count();){const i=c.M.wrapReward(this.data.reward.rewards[e])
t.Add(i),e+=1}}if(null!=t&&t.Count()>0&&(this.itemData=t[0]),1==this.data.bonusRank){this.bigImg.node.SetActive(!0)
const t=f.Inst_get().GetResById(this.data.id)
if(null!=t){const e=t.pic
this.bigImg.spriteNameSet("atlas/mayaxunbao/"+e)}}else this.itemImg.node.SetActive(!0),r.g.SetItemIcon(this.itemImg,this.itemData.cfgData_get().icon,h.b.eItem)}this.AddLis(),
this.RefreshInfo()}SetScale(t){this.itemImg.node.SetLocalScaleXYZ(t,t,t)}ClickHandle(){u.J.Inst_get().ShowItemTip(this.itemData)}RefreshInfo(){if(this.numTxt.node.SetActive(!1),
this.remainTxt.node.SetActive(!1),null!=this.data){if(-1!=this.data.maxLimit){this.remainTxt.node.SetActive(!0)
let t=""
const e=this.data.maxLimit,i=T.X.Inst_get().GetNumById(this.data.id)
t=(0,a.tw)(e-i),e-i==0&&(t=`[FF0000]${t}[-]`),this.remainTxt.textSet(`剩余:${t}`),this.remainTxt.node.SetActive(!0)}if(null!=this.itemData&&this.itemData.count>1){
const t=_.l.GetPurseVOChineseString(this.itemData.count)
this.numTxt.textSet(`x${t}`),this.numTxt.node.SetActive(!0)}}}AddLis(){v.X.Inst_get().AddEventHandler(R.E.TREASURE_INFO_UPDATE,this.CreateDelegate(this.RefreshInfo)),
l.i.Get(this.itemImg.node).RegistonClick(this.CreateDelegate(this.ClickHandle)),l.i.Get(this.bigImg.node).RegistonClick(this.CreateDelegate(this.ClickHandle))}RemoveLis(){
v.X.Inst_get().RemoveEventHandler(R.E.TREASURE_INFO_UPDATE,this.CreateDelegate(this.RefreshInfo)),l.i.Get(this.itemImg.node).RemoveonClick(this.CreateDelegate(this.ClickHandle)),
l.i.Get(this.bigImg.node).RemoveonClick(this.CreateDelegate(this.ClickHandle))}Clear(){this.data=null,this.RemoveLis(),super.Clear()}})||y},40938:(t,e,i)=>{i.d(e,{o:()=>d})
var s,n=i(18998),a=i(83908),o=i(5924),l=i(9057),r=i(69559),h=i(89373)
let d=n._decorator.ccclass("MayaTreasureResultItem")(s=class extends((0,a.pA)(l.x)()){constructor(...t){super(...t),this.itemData=null,this.data=null,this.appearId=null}InitView(){
super.InitView()}Destroy(){this.baseItem.Destroy(),super.Destroy()}SetData(t){this.data=t,this.node.SetActive(!1),this.appearAnim.node.SetActive(!1),this.ClearAppearId(),
this.appearId=o.C.Inst_get().SetInterval(this.CreateDelegate(this.AppearHandle),180*this.index,1),this.AddLis()}ClearAppearId(){
null!=this.appearId&&(o.C.Inst_get().ClearInterval(this.appearId),this.appearId=null)}AppearHandle(){this.node.SetActive(!0),this.appearAnim.node.SetActive(!0),this.ShowInfo(),
this.EndAnimHandle()}ShowInfo(){this.node.SetActive(!0),this.SetShowSubIcon(),this.SetBaseItem()}SetShowSubIcon(){if(this.big.SetActive(!1),this.mid.SetActive(!1),null!=this.data){
const t=this.data.id,e=h.X.Inst_get().GetConfigById(t)
null!=e&&(1==e.bonusRank?this.big.SetActive(!0):2==e.bonusRank&&this.mid.SetActive(!0))}}SetBaseItem(){
null!=this.data&&null!=this.data.itemData&&this.baseItem.SetData(this.data.itemData)}AddLis(){
h.X.Inst_get().AddEventHandler(r.E.JUMP_RESULT_ANIM,this.CreateDelegate(this.JumpAnimHandle))}RemoveLis(){
h.X.Inst_get().RemoveEventHandler(r.E.JUMP_RESULT_ANIM,this.CreateDelegate(this.JumpAnimHandle))}JumpAnimHandle(){this.ClearAppearId(),this.ShowInfo(),this.EndAnimHandle()}
EndAnimHandle(){h.X.Inst_get().RaiseEvent(r.E.RESULT_ANIM_END,this.index)}Clear(){this.data=null,this.baseItem.Clear(),this.RemoveLis(),this.ClearAppearId(),super.Clear()}})||s},
5946:(t,e,i)=>{i.d(e,{k:()=>p})
var s=i(6847),n=i(83908),a=i(17409),o=i(46282),l=i(61911),r=i(5494),h=i(85602),d=i(63076),u=i(67885),c=i(33138),_=i(25606),I=i(69559)
class g{constructor(t,e){this.id=null,this.itemData=null,this.id=t,this.itemData=e}}var m,C=i(89373),S=i(40938)
let p=(0,s.s_)(r.I.MayaTreasureResultView,o.Z.ui_mayatreasure_result_panel).waitPrefab(u.S.modulePathList).register()(m=class extends((0,n.pA)(l.f)()){constructor(...t){
super(...t),this.isShowBtn=null,this.isPlaying=null,this.ret=null}InitView(){super.InitView(),this.grid.SetInitInfo("ui_mayatreasure_result_item",null,S.o),
this.grid.OnReposition_set(this.CreateDelegate(this.OnReposition))}OnReposition(){this.bar.ResetPosition()}OnAddToScene(){this.effGo.SetActive(!1),this.AddLis(),this.UpdateView()}
UpdateView(){this.effGo.SetActive(!1),this.effGo.SetActive(!0),this.isShowBtn=!1,this.isPlaying=!0
const t=C.X.Inst_get().treasureResultInfo,e=C.X.Inst_get().GetScoreItemId(),i=C.X.Inst_get().GetHuntItemId()
c.f.Inst().getItemById(i),c.f.Inst().getItemById(e)
if(null!=t){let e=t.exchangeScore
null==e&&(e=0),this.itemNumTxt.textSet(e+""),this.noReward.SetActive(!1),this.oneHuntBtn.node.SetActive(!1),this.tenHuntBtn.node.SetActive(!1)
const i=C.X.Inst_get().treasureConfig.curPoolItemVos[1]
null!=i&&(1==i.changeable&&_.X.Inst_get().GetNumById(i.id)>=i.maxLimit&&this.IsCanChangeByBonus(i.bonusRank)?this.noReward.SetActive(!0):(this.isShowBtn=!0,
this.oneHuntBtn.node.SetActive(!0),this.tenHuntBtn.node.SetActive(!0))),this.UpdateItemLis()}}ItemAnimEndHandle(t){
null!=t&&null!=this.ret&&this.isShowBtn&&t>=this.ret.Count()-1&&(this.oneHuntBtn.node.SetActive(!0),this.tenHuntBtn.node.SetActive(!0),this.isPlaying=!1)}IsCanChangeByBonus(t){
if(null!=C.X.Inst_get().treasureConfig){const e=C.X.Inst_get().treasureConfig.historyItemVos
if(null!=e)for(let i=0;i<=e.Count()-1;i++){const s=e[i]
if(1==s.changeable&&s.bonusRank==t){const t=s.maxLimit
if(_.X.Inst_get().GetNumById(s.id)<t)return!0}}}return!1}Clear(){super.Clear(),this.grid.Clear(),this.RemoveLis()}Destroy(){this.grid.Destroy()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.goChangeBtn.node,this.CreateDelegate(this.GoChangeBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.oneHuntBtn.node,this.CreateDelegate(this.OneHuntBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.tenHuntBtn.node,this.CreateDelegate(this.TenHuntBtnHandle)),(0,a.D1)(this,this.CreateDelegate(this.OnCloseView)),
C.X.Inst_get().AddEventHandler(I.E.RESULT_ANIM_END,this.CreateDelegate(this.ItemAnimEndHandle))}RemoveLis(){
this.RemoveClickEvent(this.goChangeBtn.node,this.CreateDelegate(this.GoChangeBtnHandle)),this.RemoveClickEvent(this.oneHuntBtn.node,this.CreateDelegate(this.OneHuntBtnHandle)),
this.RemoveClickEvent(this.tenHuntBtn.node,this.CreateDelegate(this.TenHuntBtnHandle)),(0,a.Rt)(this),
C.X.Inst_get().RemoveEventHandler(I.E.RESULT_ANIM_END,this.CreateDelegate(this.ItemAnimEndHandle))}OnCloseView(){this.isPlaying?(C.X.Inst_get().RaiseEvent(I.E.JUMP_RESULT_ANIM),
this.isPlaying=!1):_.X.Inst_get().CloseResultView()}GoChangeBtnHandle(){C.X.Inst_get().RaiseEvent(I.E.OPEN_REPLACE_BIG),this.OnCloseView()}OneHuntBtnHandle(){
_.X.Inst_get().IsPassAnim()||_.X.Inst_get().CloseResultView(),_.X.Inst_get().GoHuntHandle(!1)}TenHuntBtnHandle(){_.X.Inst_get().IsPassAnim()||_.X.Inst_get().CloseResultView(),
_.X.Inst_get().GoHuntHandle(!0)}UpdateItemLis(){const t=C.X.Inst_get().treasureResultInfo,e=new h.Z
if(null!=t.reward&&null!=t.reward.rewards){let i=0
for(;i<t.reward.rewards.Count();){const s=d.M.wrapReward(t.reward.rewards[i]),n=new g(t.resultItems[i],s)
null!=n&&e.Add(n),i+=1}}this.ret=e,this.grid.data_set(e),this.bar.ResetPosition(),this.grid.node.y=e.count>1?66:0,this.ret.Count()>1&&(this.oneHuntBtn.node.SetActive(!1),
this.tenHuntBtn.node.SetActive(!1)),this.grid.node.SetActive(!1),this.grid.node.SetActive(!0)}})||m},72565:(t,e,i)=>{
var s,n=i(6847),a=i(83908),o=i(49655),l=i(46282),r=i(40053),h=i(36334),d=i(44255),u=i(85602),c=i(28287),_=i(14792),I=i(62734),g=i(25606),m=i(89373),C=i(18998),S=i(75507),p=i(77546),A=i(38836),f=i(98800),y=i(97960),T=i(68662),R=i(5924),v=i(51868),w=i(18202),D=i(61613),E=i(79534),L=i(63076),G=i(53905),O=i(92679),b=i(65772),B=i(65550),N=i(99421),P=i(69559),M=i(13605)
class V extends((0,a.pA)(v.$)()){constructor(...t){super(...t),this.showItemLis=null,this.posXLis=null,this.posYLis=null,this.iconGoLis=null,this.iconScaleLis=null,
this.isPlaying=null,this.time=null,this.successAnimId=null,this.countDownTimer=null}_initBinder(){super._initBinder(),this.showItemLis=new u.Z,this.posXLis=new u.Z,
this.posYLis=new u.Z,this.iconGoLis=new u.Z,this.InitPos()}InitPos(){this.posXLis=new u.Z([-44,-56,-30,-24.9,-26,-51,-32,-52,-14,-51,-18]),
this.posYLis=new u.Z([14,50,50,37,36,18,23,53,20,40,47]),this.iconScaleLis=new u.Z([1,1,1,.8,.9,.8,.9,.9,.8,.8,.8])}InitView(){this.showItemLis=new u.Z,this.posXLis=new u.Z,
this.posYLis=new u.Z,this.iconGoLis=new u.Z,this.InitPos()
const t=D.v.GetAdaptionWidth(1151,1429)
this.adapt1.widthSet(t)
const e=D.v.GetAdaptionWidth(1143,1421)
this.adapt2.widthSet(e),D.v.SetAdaptionPos(this.tip1Btn.node,-425,-565,325),this.animTog.node.SetActive(!1)}ShowCurrencyBar_get(){return c._.ShowGOLD_Dia_MAYAHUNTCOUPON}SetData(){
this.openAnimGo.SetActive(!1),this.iconGoLis=new u.Z([this.icon1,this.icon2,this.icon3,this.icon4,this.icon5,this.icon6,this.icon7,this.icon8,this.icon9,this.icon10,this.icon11]),
this.desc.textSet(""),this.eff1.SetActive(!1),this.eff2.SetActive(!1),this.eff3.SetActive(!1),this.successAnim.node.SetActive(!1),this.replaceAward.node.SetActive(!1)
const t=g.X.Inst_get().GetActivityId()
N.l.ins.CM_OpenActivityPanel(t),p.s.Info(`玛雅寻宝打开界面请求活动id:${t}`),this.successAnim.node.SetActive(!1),this.successAnim1.SetActive(!1),this.successAnim2.node.SetActive(!1),
this.AddLis(),this.itemView.SetActive(!0),this.isPlaying=!1,this.mask.node.SetActive(!1),this.isPlaying=!1,this.UpdateView()}IsCanChangeByBonus(t){
if(null!=m.X.Inst_get().treasureConfig){const e=m.X.Inst_get().treasureConfig.historyItemVos
if(null!=e)for(let i=0;i<=e.Count()-1;i++){const s=e[i]
if(1==s.changeable&&s.bonusRank==t){const t=s.maxLimit
if(g.X.Inst_get().GetNumById(s.id)<t)return!0}}}return!1}OnPanelAniEnd(){
m.X.Inst_get().isEnd&&(INS.luaEventMgr.RemoveEventHandler(O.g.TabCommonOpenAniEnd,this.CreateDelegate(this.OnPanelAniEnd)),this.eff1.SetActive(!0),this.eff2.SetActive(!0),
this.eff3.SetActive(!0),this.successAnim2.node.SetActive(!0))}UpdateView(){this.OnPanelAniEnd(),this.animTog.SetValue(g.X.Inst_get().IsPassAnim())}ShowItem(t){
if(null!=this.showItemLis)for(let e=0;e<=this.showItemLis.Count()-1;e++){this.showItemLis[e].node.SetActive(t)}}UpdateConfig(){
if(null!=m.X.Inst_get().treasureConfig&&null!=m.X.Inst_get().treasureConfig.curPoolItemVos){const t=m.X.Inst_get().treasureConfig.curPoolItemVos
for(let e=0;e<=t.LuaDic_Count()-1;e++){let i=null
e>=this.showItemLis.Count()?(i=this.GetShowItem(),i.node.setParent(this.iconGoLis[e]),this.showItemLis.Add(i)):i=this.showItemLis[e],i.node.SetActive(!0)
const s=t[e+1]
let n=null
0==e?n=this.resetBtn1.node:1==e?n=this.resetBtn2.node:2==e&&(n=this.resetBtn3.node),0!=e&&1!=e&&2!=e||n.SetActive(1==s.changeable&&this.IsCanChangeByBonus(s.bonusRank)),
i.SetData(s),i.node.transform.SetLocalPositionXYZ(this.posXLis[e],this.posYLis[e],0),i.SetScale(this.iconScaleLis[e])}}null!=m.X.Inst_get().treasureConfig&&this.desc.textSet(""),
this.RefreshEndTime()}GetShowItem(){let t=null
const e=S.o.getPrefab("ui_maya_treasure_item")
return t=(0,C.instantiate)(e).getCNode(M.M),this.m_handlerMgr.AddClearComponent(t,!1,!1),t}ClearItemLis(){for(let t=0;t<=this.showItemLis.Count()-1;t++){const e=this.showItemLis[t]
null!=e&&(e.Clear(),w.g.DestroyView(e))}this.showItemLis.Clear()}Tip1BtnHandle(){const t=new G.w
t.infoId="MAYA LOTTERY:TIPS2",t.width=384
const e=this.tip1Btn.node.transform.GetLocalPosition().x-27
t.position=new E.P(e,295,0),b.Q.Inst_get().Open(t)}GetAllMustGetItem(){let t="",e=!0
if(null!=m.X.Inst_get().treasureConfig&&null!=m.X.Inst_get().treasureConfig.curPoolItemVos)for(const[i,s]of(0,A.vy)(m.X.Inst_get().treasureConfig.curPoolItemVos)){const i=s
if(0!=i.nGuarantee){e||(t+="、"),e=!1
t+=L.M.wrapReward(i.reward.rewards[0]).GetItemNameStr()}}return t}Tip2BtnHandle(){const t=new G.w
t.infoId="MAYA LOTTERY:TIPS1",t.width=384,t.position=new E.P(-172,58,0),b.Q.Inst_get().Open(t)}Clear(){this.RemoveLis()}Destroy(){}AddLis(){
this.m_handlerMgr.AddClickEvent(this.tip1Btn,this.CreateDelegate(this.Tip1BtnHandle)),this.m_handlerMgr.AddClickEvent(this.tip2Btn,this.CreateDelegate(this.Tip2BtnHandle)),
this.m_handlerMgr.AddClickEvent(this.animTog,this.CreateDelegate(this.AnimToggleHandle)),this.m_handlerMgr.AddClickEvent(this.goOneBtn,this.CreateDelegate(this.GoOneBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.goTenBtn,this.CreateDelegate(this.GoTenBtnHandle)),this.m_handlerMgr.AddClickEvent(this.replaceBtn,this.CreateDelegate(this.ReplaceBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.resetBtn1,this.CreateDelegate(this.ReplaceBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.resetBtn2,this.CreateDelegate(this.ReplaceMid1Handle)),
this.m_handlerMgr.AddClickEvent(this.resetBtn3,this.CreateDelegate(this.ReplaceMid2Handle)),
f.Y.Inst.primaryNotify.AddEventHandler(y.A.LevelUpdate,this.CreateDelegate(this.LevelUpdateHandle)),
m.X.Inst_get().AddEventHandler(P.E.TREASURE_CONFIG_UPDATE,this.CreateDelegate(this.UpdateConfig)),
m.X.Inst_get().AddEventHandler(P.E.TREASURE_INFO_UPDATE,this.CreateDelegate(this.UpdateInfo)),
m.X.Inst_get().AddEventHandler(P.E.TREASURE_SUCCESS,this.CreateDelegate(this.TreasureSuccess)),
m.X.Inst_get().AddEventHandler(P.E.OPEN_REPLACE_BIG,this.CreateDelegate(this.ReplaceBtnHandle)),
m.X.Inst_get().AddEventHandler(P.E.REPLACE_INFO_UPDATE,this.CreateDelegate(this.UpdateConfig)),
INS.luaEventMgr.AddEventHandler(O.g.TabCommonOpenAniEnd,this.CreateDelegate(this.OnPanelAniEnd)),this.AnimEndHandle2(),this.replaceAward.AddLis()}RemoveLis(){
m.X.Inst_get().RemoveEventHandler(P.E.TREASURE_CONFIG_UPDATE,this.CreateDelegate(this.UpdateConfig)),
m.X.Inst_get().RemoveEventHandler(P.E.TREASURE_INFO_UPDATE,this.CreateDelegate(this.UpdateInfo)),
m.X.Inst_get().RemoveEventHandler(P.E.TREASURE_SUCCESS,this.CreateDelegate(this.TreasureSuccess)),
m.X.Inst_get().RemoveEventHandler(P.E.OPEN_REPLACE_BIG,this.CreateDelegate(this.ReplaceBtnHandle)),
f.Y.Inst.primaryNotify.RemoveEventHandler(y.A.LevelUpdate,this.CreateDelegate(this.LevelUpdateHandle)),
m.X.Inst_get().RemoveEventHandler(P.E.REPLACE_INFO_UPDATE,this.CreateDelegate(this.UpdateConfig)),
INS.luaEventMgr.RemoveEventHandler(O.g.TabCommonOpenAniEnd,this.CreateDelegate(this.OnPanelAniEnd)),this.replaceAward.RemoveLis()}ReplaceBtnHandle(){
if(null!=m.X.Inst_get().treasureConfig&&m.X.Inst_get().treasureConfig.curPoolItemVos){const t=m.X.Inst_get().treasureConfig.curPoolItemVos
this.replaceAward.UpdateView(t[1])}}ReplaceMid1Handle(){if(null!=m.X.Inst_get().treasureConfig&&m.X.Inst_get().treasureConfig.curPoolItemVos){
const t=m.X.Inst_get().treasureConfig.curPoolItemVos
this.replaceAward.UpdateView(t[2])}}ReplaceMid2Handle(){if(null!=m.X.Inst_get().treasureConfig&&m.X.Inst_get().treasureConfig.curPoolItemVos){
const t=m.X.Inst_get().treasureConfig.curPoolItemVos
this.replaceAward.UpdateView(t[3])}}GoOneBtnHandle(){g.X.Inst_get().GoHuntHandle(!1)}GoTenBtnHandle(){g.X.Inst_get().GoHuntHandle(!0)}AnimToggleHandle(){
this.animTog.SetValue(!this.animTog.GetValue()),g.X.Inst_get().SendSetAnim(this.animTog.GetValue()),this.animTog.GetValue()&&this.isPlaying&&(this.time=0,this.AnimEndHandle())}
UpdateInfo(){if(null!=m.X.Inst_get().treasureInfo){let t=m.X.Inst_get().treasureInfo.luck
if(null==t&&(t=0),this.luckTxt.textSet(t+""),this.goOneBtn.node.SetActive(!1),this.replaceBtn.node.SetActive(!1),this.goTenBtn.node.SetActive(!1),
null==m.X.Inst_get().treasureConfig)return B.y.inst.ClientSysStrMsg("未收到SM_MayaLotteryConfig"),void p.s.Info("玛雅寻宝未收到SM_MayaLotteryConfig")
const e=m.X.Inst_get().treasureConfig.curPoolItemVos[1]
null!=e&&(1==e.changeable&&g.X.Inst_get().GetNumById(e.id)>=e.maxLimit&&this.IsCanChangeByBonus(e.bonusRank)?this.replaceBtn.node.SetActive(!0):this.isPlaying||(this.goOneBtn.node.SetActive(!0),
this.goTenBtn.node.SetActive(!0)))}}TreasureSuccess(){g.X.Inst_get().IsPassAnim()?(this.time=0,this.AnimEndHandle()):(this.isPlaying=!0,this.mask.node.SetActive(!0),this.time=1,
this.itemView.SetActive(!1),this.ShowItem(!1),this.PlayAnim(),this.tip2Btn.node.SetActive(!1),this.goOneBtn.node.SetActive(!1),this.goTenBtn.node.SetActive(!1),
this.animTog.node.SetActive(!1))}PlayAnim(){this.time-=1,this.successAnim2.node.SetActive(!0),this.successAnim1.SetActive(!1),this.successAnim1.SetActive(!0),
this.ClearSuccessAnimId(),this.successAnimId=R.C.Inst_get().SetInterval(this.CreateDelegate(this.PlaySuccessAnim),200,1)}ClearSuccessAnimId(){
null!=this.successAnimId&&(R.C.Inst_get().ClearInterval(this.successAnimId),this.successAnimId=null)}PlaySuccessAnim(){this.AnimEndHandle()}AnimEndHandle(){
this.time>0?this.PlayAnim():(this.itemView.SetActive(!0),this.ShowItem(!0),this.isPlaying=!1,this.mask.node.SetActive(!1),this.successAnim1.SetActive(!1),
this.successAnim.node.SetActive(!1),this.AnimEndHandle2(1),g.X.Inst_get().OpenResultView(),this.UpdateInfo(),this.tip2Btn.node.SetActive(!0))}AnimEndHandle2(t){
this.successAnim2.node.SetActive(!0)}LevelUpdateHandle(){this.EndTimeCountDown()}RefreshEndTime(){let t=0
if(null!=m.X.Inst_get().treasureConfig){const e=m.X.Inst_get().treasureConfig.nextPoolFreshTime
null!=e&&e.ToNum()>0&&(t=.001*e.ToNum()-T.D.serverTime_get())}t>0?(this.ClearEndTimeHandle(),
null==this.countDownTimer&&(this.countDownTimer=R.C.Inst_get().SetInterval(this.CreateDelegate(this.EndTimeCountDown),1e3,-1))):this.ClearEndTimeHandle()}EndTimeCountDown(){let t=0
if(null!=m.X.Inst_get().treasureConfig){const e=m.X.Inst_get().treasureConfig.nextPoolFreshTime
null!=e&&e.ToNum()>0&&(t=.001*e.ToNum()-T.D.serverTime_get()),t<=0&&this.ClearEndTimeHandle()
f.Y.Inst.PrimaryRoleInfo_get().Level_get()>=m.X.Inst_get().treasureConfig.levelLimit&&t<=0&&this.SendRefreshItemLis()}else this.ClearEndTimeHandle()}SendRefreshItemLis(){
this.replaceAward.node.SetActive(!1),N.l.ins.CM_OpenActivityPanel(g.X.Inst_get().GetActivityId())}ClearEndTimeHandle(){
null!=this.countDownTimer&&(R.C.Inst_get().ClearInterval(this.countDownTimer),this.countDownTimer=null)}}(0,
n.s_)(o.o.MayaTreasureView,l.Z.ui_ry_tabcommonpanel).tabsPrefab(r.Z.MayaTreasureView_basePrefabs,0).waitPrefab(l.Z.ui_mayatreasure_panel).register()(s=class extends((0,
a.pA)(d.I)()){constructor(...t){super(...t),this._model=null,this.redPointLis=null,this.nameLis1=null}_initBinder(){super._initBinder(),this._model=m.X.Inst_get(),
this.redPointLis=new u.Z}InitView(){super.InitView(),this._subPanelDatas.Add(h.b.New(new u.Z(["ui_maya_hunttreasure_view"]),this,V))}Clear(){g.X.Inst_get().SetIsClick(!1),
super.Clear()}Destroy(){g.X.Inst_get().CloseResultView(),super.Destroy()}ShowCurrencyBar_get(){const t=this.GetSubView(this.selectTabIdx1)
return t&&t.ShowCurrencyBar_get?t.ShowCurrencyBar_get():c._.ShowGOLD_Dia_MAYAHUNTCOUPON}SetViewConfig(){g.X.Inst_get().SetIsClick(!0),this._SetCharacterTabData(!1),
this.titleLabel.textSet("玛雅寻宝"),this.nameLis1=new u.Z(["玛雅寻宝"]),this.redPointLis=new u.Z([_.t.MAYA_TREASURE]),this._SetTabData0(!0,new u.Z(["玛雅寻宝"]),this.redPointLis),
this._SetTabData1(!0,this.nameLis1,this.redPointLis,null,null),this.UpdateDefaultView()}OnCloseClick(){g.X.Inst_get().CloseView()}OnAniPlayEnd(){m.X.Inst_get().isEnd=!0,
super.OnAniPlayEnd()}AddLis(){super.AddLis()}RemoveLis(){super.RemoveLis()}UpdateDefaultView(){this.SelectTab0(0,!1),this.SelectTab1(this.GetDefaultView(),!0)}
_OnSelectTab1BeforeUpdate(t){null!=this._subPanelDatas&&this.selectTabIdx1>=0&&this.selectTabIdx1<this._subPanelDatas.Count()&&this.ShowSubView(this.selectTabIdx1)}
GetDefaultView(){const t=this._model.GetDefaultView()
if(null==t){if(null!=this.redPointLis&&this.redPointLis.Count()>0)for(let t=0;t<=this.redPointLis.Count()-1;t++){const e=this.redPointLis[t]
if(null!=e){const i=I.f.Inst.GetData(e)
if(null!=i&&i.show)return t}}return 0}return t}})},98936:(t,e,i)=>{i.d(e,{V:()=>$t})
var s=i(38045),n=i(97461),a=i(98497),o=i(38935),l=i(56937),r=i(18202),h=i(31222),d=i(5494),u=i(28192),c=i(98885),_=i(85602),I=i(92679),g=i(37648),m=i(55492),C=i(61519),S=i(47635),p=i(92260),A=i(8211),f=i(56828),y=i(60647),T=i(13487),R=i(56834),v=i(23649),w=i(69622),D=i(93727),E=i(43709),L=i(79411),G=i(86133),O=i(36334),b=i(44255),B=i(14792),N=i(65550),P=i(99421),M=i(12842),V=i(99294),k=i(9986),x=i(93877),H=i(3522),U=i(72005),F=i(11355),Y=i(16968)
class K extends Y.E{constructor(...t){super(...t),this.icon=null,this.lightLabel=null,this.bg2=null,this.img_lock=null,this.Ani=null,this.uispAni=null}InitView(){super.InitView(),
this.bg1=this.CreateComponent(V.z,1),this.label=this.CreateComponent(x.Q,3),this.redPoint=this.CreateComponent(V.z,4),this.icon=this.CreateComponent(U.w,5),
this.lightLabel=this.CreateComponent(x.Q,6),this.btn=this.CreateComponent(k.W,7),this.bg2=this.CreateComponent(V.z,8),this.img_lock=this.CreateComponent(U.w,9),
this.Ani=this.CreateComponent(H.k,10),this.uispAni=this.CreateComponent(F.I,11),this._curRedPointId=0,this.redPoint.SetActive(!1)}SetData(t){super.SetData(t),
n.i.Inst.AddEventHandler(I.g.HUODONG_INFO_CHANGE,this.CreateDelegate(this.UpdateLock)),this.lightLabel.node.SetActive(!1),this.label.node.SetActive(!0),
this.label.textSet(this.itemData.btnName),this.lightLabel.textSet(this.itemData.btnName),this.icon.node.SetActive(!1),this.bg1.SetActive(!0),this.bg2.SetActive(!1),
this.UpdateLock()}Clear(){super.Clear(),n.i.Inst.RemoveEventHandler(I.g.HUODONG_INFO_CHANGE,this.CreateDelegate(this.UpdateLock))}UpdateLock(){
null!=this.itemData.huodongId&&0!=this.itemData.huodongId&&D.i.ins.GetState(this.itemData.huodongId)==R.V.NONE?this.img_lock.node.SetActive(!0):this.img_lock.node.SetActive(!1)}
SetSelect(t){super.SetSelect(t),this.bg2.SetActive(!0),t?(this.lightLabel.node.SetActive(!0),this.label.node.SetActive(!1),
this.icon.node.SetActive(!1)):(this.lightLabel.node.SetActive(!1),this.label.node.SetActive(!0),this.icon.node.SetActive(!1))}PlayAni(){super.PlayAni(),
null!=this.Ani&&(this.Ani.SetResetOnPlay(!0),this.Ani.Play(!0,!1)),null!=this.uispAni&&(this.uispAni.node.SetActive(!0),this.uispAni.ResetToBeginning(),this.uispAni.Play())}}
var z=i(84049),Q=i(43662),Z=i(28475),X=i(31546),j=i(70650),J=i(68662),W=i(5924),$=i(6665),q=i(78287),tt=i(16261),et=i(13113),it=i(51868),st=i(61613),nt=i(60130),at=i(35128),ot=i(52212),lt=i(63076),rt=i(75696),ht=i(33314),dt=i(87923),ut=i(27122),ct=i(74265),_t=i(83434),It=i(62370),gt=i(89501),mt=i(9057),Ct=i(79878)
class St extends mt.x{constructor(...t){super(...t),this.huodongQuestVo=null,this.targetVo=null,this.rewardVo=null,this.huodongCfgVo=null,this.flyLinkInfo=null,
this.getHandler=null,this.hasIntegral=!1,this.integralItemIndex=-1,this.text_name=null,this.img_get=null,this.grid_item=null,this.text_progress=null,this.btn_get=null,
this.text_get=null,this.img_bg=null,this.img_btn_get=null,this.btn_go=null,this.mid=null,this.right=null}InitView(){super.InitView(),this.text_name=this.CreateComponent(x.Q,1),
this.img_get=this.CreateComponent(U.w,2),this.grid_item=this.CreateComponent(gt.N,3),this.text_progress=this.CreateComponent(x.Q,4),this.btn_get=this.CreateComponent(k.W,5),
this.text_get=this.CreateComponent(x.Q,6),this.img_bg=this.CreateComponent(U.w,7),this.img_btn_get=this.CreateComponent(U.w,8),this.btn_go=this.CreateComponent(k.W,9),
this.mid=this.CreateComponent(V.z,10),this.right=this.CreateComponent(V.z,11),this.grid_item.SetInitInfo("ui_baseitem",this.CreateDelegate(this.OnInitItem))}OnInitItem(t){
const e=new rt.j
return e.setId(t,null,0),e.SetBgSize(66,66),e.SetIconSize(66,66),e}SetData(t){this.AddLis(),this.huodongQuestVo=t,this.targetVo=this.huodongQuestVo.targetVos[0],
this.rewardVo=this.huodongQuestVo.activityRewardVo,this.huodongCfgVo=w.J.ins.GetQuestVoById(this.huodongQuestVo.taskId),this.UpdatePanel()}SetAdapt1(){
const t=st.v.GetAdaptionWidth(900,1157)
this.img_bg.widthSet(t),st.v.SetAdaptionPos(this.right,900,1157,0),st.v.SetAdaptionPos(this.mid,0,100,0)}SetAdapt2(){const t=st.v.GetAdaptionWidth(593,726)
this.img_bg.widthSet(t),st.v.SetAdaptionPos(this.right,593,726,0)}AddLis(){this.m_handlerMgr.AddClickEvent(this.btn_get,this.CreateDelegate(this.OnClickBtnGet)),
this.m_handlerMgr.AddClickEvent(this.btn_go,this.CreateDelegate(this.OnClickBtnGo))}RemoveLis(){}Clear(){super.Clear(),this.RemoveLis(),
null!=this.flyLinkInfo&&(this.flyLinkInfo.Clear(),this.flyLinkInfo=null)}Destroy(){this.getHandler=null,super.Destroy()}UpdatePanel(){
this.flyLinkInfo=_t.f.GetLinkInfo(new _.Z([this.huodongCfgVo.targetText]),this.huodongCfgVo.TargetDefs_Get(),this.huodongQuestVo.targetVos),
this.text_name.textSet(this.flyLinkInfo.GetTxtLabel()),this.btn_get.node.SetActive(!1),this.btn_go.node.SetActive(!1),this.img_get.node.SetActive(!1),
this.text_progress.node.SetActive(!1),this.rewardVo.isReward?this.img_get.node.SetActive(!0):(this.text_progress.node.SetActive(!0),
this.targetVo.curValue.ToNum()>=this.targetVo.targetValue.ToNum()?this.btn_get.node.SetActive(!0):this.btn_go.node.SetActive(!0)),
this.text_progress.textSet(`目标进度[047104]${It.o.Format((0,
G.T)("{0}/{1}"),dt.l.GetPurseVOChineseString(this.targetVo.curValue.ToNum(),null,2),dt.l.GetPurseVOChineseString(this.targetVo.targetValue.ToNum(),null,2))}[-]`),
this.hasIntegral=!1
const t=new _.Z
for(let e=0;e<=this.rewardVo.reward.rewards.Count()-1;e++){const i=lt.M.wrapReward(this.rewardVo.reward.rewards[e])
t.Add(i),10211==i.modelId_get()&&(this.integralItemIndex=e,this.hasIntegral=!0)}this.grid_item.data_set(t)}OnClickBtnGet(){
this.rewardVo.isReward||this.targetVo.curValue.ToNum()>=this.targetVo.targetValue.ToNum()&&(null!=this.getHandler&&this.hasIntegral&&this.grid_item.itemList[this.integralItemIndex]&&this.getHandler(this.grid_item.itemList[this.integralItemIndex]),
P.l.ins.CM_GainActivitytaskReward(this.huodongCfgVo.activityId,this.huodongCfgVo.id))}OnClickBtnGo(){this.rewardVo.isReward||Ct.Y.GotoByLinkStr(this.flyLinkInfo.linkStr)}}
class pt extends it.${constructor(){super(),this.select_target_type=0,this.interval=-1,this.STAGE_ID=148,this.m_role=null,this.roleDrags=null,this.isInit=!1,this.commonTaskVo=null,
this.grid_quest=null,this.timeTips=null,this.scroll_view=null,this.ui_baseitem=null,this.playerNameLabel=null,this.countNumLabel=null,this.roleTexture=null,
this.commTaskHadBuy=null,this.commTaskDesLabel=null,this.firstCompletePlayerName=null,this.RoleDrag1=null,this.RoleDrag2=null,this.RoleDrag3=null,this.canGet=null,this.unGet=null,
this.leftWidget=null,this.rightWidget=null,this.m_role=new _.Z,this.roleDrags=new _.Z}InitView(){super.InitView(),this.grid_quest=this.CreateComponent($.A,1),
this.timeTips=this.CreateComponent(x.Q,2),this.scroll_view=this.CreateComponent(q._,3),this.ui_baseitem=this.CreateComponentBinder(rt.j,4),
this.playerNameLabel=this.CreateComponent(x.Q,6),this.countNumLabel=this.CreateComponent(x.Q,7),this.roleTexture=this.CreateComponent(tt.X,9),
this.commTaskHadBuy=this.CreateComponent(V.z,10),this.commTaskDesLabel=this.CreateComponent(x.Q,11),this.firstCompletePlayerName=this.CreateComponent(x.Q,12),
this.RoleDrag1=this.CreateComponent(V.z,13),this.RoleDrag2=this.CreateComponent(V.z,14),this.RoleDrag3=this.CreateComponent(V.z,15),this.canGet=this.CreateComponent(V.z,19),
this.unGet=this.CreateComponent(V.z,20),this.leftWidget=this.CreateComponent(et.T,21),this.rightWidget=this.CreateComponent(et.T,22),nt.O.SetAnchorPos(this.leftWidget,!0,!1,0),
st.v.SetAdaptionPos(this.rightWidget,640,710,0),this.roleDrags.Add(this.RoleDrag1),this.roleDrags.Add(this.RoleDrag2),this.roleDrags.Add(this.RoleDrag3),
this.grid_quest.SetInitInfo("ui_openservergrab_quest_item",this.CreateDelegate(this.OnItemLoad)),this.grid_quest.OnReposition_set(this.CreateDelegate(this.RepositionFun))}
RepositionFun(){this.scroll_view.SetValue(0)}OnItemLoad(t){const e=new St
return e.setId(t,null,0),e.SetAdapt2(),e}SetData(){-1==this.interval&&(this.interval=W.C.Inst_get().SetInterval(this.CreateDelegate(this.OnEachSec),1e3)),
this.select_target_type=w.J.ins.target_type_dict.LuaDic_GetItem(L.J.Inst_get().select_huodong_id)[0],this.AddLis(),this.OnEachSec(),this.UpdatePanel(),this.isInit||(this.isInit=!0,
this.InitRole())}AddLis(){this.m_handlerMgr.AddEventMgr(I.g.HUODONG_QUEST_CHANGE,this.CreateDelegate(this.UpdatePanel)),
this.m_handlerMgr.AddEventMgr(I.g.RANK_DATA,this.CreateDelegate(this.OnGetRank)),
this.m_handlerMgr.AddEventMgr(I.g.RYALLIANCE_RANK_SHOWPLAYER,this.CreateDelegate(this.ShowRoleModel)),
this.m_handlerMgr.AddEventMgr(I.g.QUERY_FIRST_PASS_MAP_NAME,this.CreateDelegate(this.QuestFirstPassMapName))}OnClickReceiveReward(){
if(null!=this.commonTaskVo&&!this.commonTaskVo.isReward){const t=w.J.ins.GetQuestVoById(this.commonTaskVo.taskId)
P.l.ins.CM_GainActivitytaskReward(t.activityId,this.commonTaskVo.taskId)}}InitRole(){ct.k.Inst_get().CM_GetRank(17,1,1)}OnGetRank(t){const e=t.rankInfos[0]
ct.k.Inst_get().CM_QueryOtherPlayerVo(e.playerId,!0),this.playerNameLabel.textSet(e.name),this.countNumLabel.textSet(`已净化首领：${e.rankValue}个`)}UpdatePanel(){this.UpdateTargetType(),
this.UpdateCommonTaskActivity()}UpdateTargetType(){const t=D.i.ins.GetQuestListVoByIdAndTargetType(L.J.Inst_get().select_huodong_id,this.select_target_type)
t.Sort(pt.SortTask),this.grid_quest.node.SetActive(!0),this.grid_quest.data_set(t)}UpdateCommonTaskActivity(){const t=D.i.ins.GetQuestListVoByIdAndTargetType(2008,28)
t.Sort(pt.SortTask)
let e=t[0]
const i=e.targetVos[0]
this.commTaskHadBuy.SetActive(!1),this.canGet.SetActive(!1),this.unGet.SetActive(!1),this.ui_baseitem.EnabledClickOpenTip(!0),this.ui_baseitem.ClickHandler_Set(null),
e.activityRewardVo.isReward?(this.commTaskHadBuy.SetActive(!0),e=t[t.Count()-1]):i.curValue.ToNum()>=i.targetValue.ToNum()?(this.ui_baseitem.EnabledClickOpenTip(!1),
this.canGet.SetActive(!0),this.ui_baseitem.ClickHandler_Set(this.CreateDelegate(this.OnClickReceiveReward))):this.unGet.SetActive(!0),this.commonTaskVo=e
const s=w.J.ins.GetQuestVoById(e.taskId),n=_t.f.GetLinkInfo(new _.Z([s.targetText]),s.TargetDefs_Get(),e.targetVos)
this.commTaskDesLabel.textSet(n.GetTxtLabel())
const a=lt.M.wrapReward(e.activityRewardVo.reward.rewards[0])
this.ui_baseitem.SetData(a)
const o=s.TargetDefs_Get().tCTargetDefs[0]
$t.Inst_get().CM_QueryFirstPassMapName(o.value)}OnEachSec(){
const t=D.i.ins.huodong_dict.LuaDic_GetItem(L.J.Inst_get().select_huodong_id),e=at.p.FloorToInt(t.endTime.ToNum()/1e3)-J.D.serverTime_get()
e>0?this.timeTips.textSet(`[b09979]结束倒计时:[-] [5fb470]${dt.l.GetDateFormatEX(e,!0,!0)}[-]`):this.timeTips.textSet("[b09979]已结束[-]")}ShowRoleModel(){this.DestroyRole(),
Q.M.Instance_get().ActiveStage(this.STAGE_ID)
const t=f.K.Inst_get().checkRoleInfo
for(let e=0;e<=t.count-1;e++){const i=ut.Q.Inst().GetObjectByName("Role",Z.u),s=new X.O
s._displayID=ht.Z.GetDisplayId(t[e]),s._world=Q.M.Instance_get().GetStageWorldType(this.STAGE_ID),s._fSize=.9,s._vPos=new ot.F(1,1).Clone(),i.isShowAni=!0,
i.initByDisinfo(t[e],s,!0)
const n=Q.M.Instance_get().GetDisplayHeight(this.STAGE_ID,e)
i.MainRole_get().SetCastShadow(!0),i.MainRole_get().SetShadowHeight(n),Q.M.Instance_get().SetDisplayObject(this.STAGE_ID,i.MainRole_get().handle,e),
this.roleTexture.SetMainTextureByPhoto(this.STAGE_ID),this.roleTexture.SetUVRect(0,0,1,1),i.wingstand=!0,j.e.GetInst().RegDrag(this.roleDrags[e],i.MainRole_get()),
this.m_role.Add(i)}}QuestFirstPassMapName(t){let e=`（达成者：${t.passMapAccountName}）`
null!=t.passMapAccountName&&""!=t.passMapAccountName||(e="（达成者：暂无）"),this.firstCompletePlayerName.textSet(e)}static SortTask(t,e){
let i=w.J.ins.GetQuestVoById(t.taskId).sort,s=w.J.ins.GetQuestVoById(e.taskId).sort
return t.activityRewardVo.isReward&&(i+=1e11),e.activityRewardVo.isReward&&(s+=1e11),i-s}TargetTypes_Get(){
return w.J.ins.GetTargetTypesByHuoDongId(L.J.Inst_get().select_huodong_id,v.h.ACTIVITY_SCORE)}DestroyRole(){for(let t=0;t<=this.m_role.count-1;t++)this.m_role[t].Destroy()
this.m_role.Clear(),Q.M.Instance_get().DeactiveStage(this.STAGE_ID,this.roleTexture.FatherId,this.roleTexture.ComponentId)}Clear(){super.Clear(),
-1!=this.interval&&(W.C.Inst_get().ClearInterval(this.interval),this.interval=-1),this.grid_quest.Clear()}Destroy(){this.DestroyRole(),this.grid_quest.Destroy(),super.Destroy()}}
var At=i(98800),ft=i(38962),yt=i(79534),Tt=i(49603),Rt=i(53905),vt=i(65249),wt=i(65772),Dt=i(48933),Et=i(33996),Lt=i(47174),Gt=i(41864),Ot=i(62734),bt=i(44744),Bt=i(30267),Nt=i(3231),Pt=i(74657)
class Mt extends Nt.A{constructor(...t){super(...t),this.limitTipLabel=null,this.nameLabel=null,this.costLabel=null,this.costIcon=null,this.lockTipLabel=null,this.buyBtn=null,
this.costContainer=null,this.bgBtn=null,this.vipbtn=null,this.grid=null,this.discountContainer=null,this.customDiscountContainer=null,this.customDiscountLabel=null}InitView(){
super.InitView(),this.limitTipLabel=this.CreateComponent(x.Q,2),this.nameLabel=this.CreateComponent(x.Q,3),this.costLabel=this.CreateComponent(x.Q,4),
this.costIcon=this.CreateComponent(U.w,5),this.lockTipLabel=this.CreateComponent(x.Q,6),this.buyBtn=this.CreateComponent(V.z,7),this.costContainer=this.CreateComponent(Bt.V,8),
this.bgBtn=this.CreateComponent(k.W,10),this.vipbtn=this.CreateComponent(k.W,11),this.grid=this.CreateComponent($.A,12),this.discountContainer=this.CreateComponent(U.w,13),
this.customDiscountContainer=this.CreateComponent(V.z,14),this.customDiscountLabel=this.CreateComponent(x.Q,15),
this.grid.SetInitInfo("ui_baseitem",this.CreateDelegate(this.OnCreateItem))}SetData(t){
const e=w.J.ins.GetQuestVoById(t.taskId),i=c.M.String2Int(e.TargetDefs_Get().tCTargetDefs[0].param.mallId),s=A.N.GetInst().GetInfo(i)
super.SetData(s)
const n=s.Cfg_get()
this._baseItemData.showNum=n.num>1
const a=Pt.A.GetReward(n.goods)
let o=new _.Z
null!=a&&(o=a.GetAllRewardList()),this.grid.data_set(o)}ShowDiscount(){if(super.ShowDiscount(),null==this.customDiscountContainer&&null==this.discountContainer)return
const t=this.data.Cfg_get()
if(null!=this.discountContainer&&this.discountContainer.node.SetActive(!1),null!=this.customDiscountContainer&&this.customDiscountContainer.SetActive(!1),0!=t.hot&&2==t.hot){
this.discountContainer.node.SetActive(!0)
const t=["ryjbsd_sp_0013","ryjbsd_sp_0014","ryjbsd_sp_0015","ryjbsd_sp_0016","ryjbsd_sp_0017","ryjbsd_sp_0018","ryjbsd_sp_0019","ryjbsd_sp_0020","ryjbsd_sp_0021","ryjbsd_sp_0022"]
let e=0
if(0!=this.data.Cfg_get().rechargeId){null!=this.data.Cfg_get().discount[1]&&(e=Math.floor(this.data.Cfg_get().discount[1]/10))}else e=this.data.GetDiscount()
this.discountContainer.spriteNameSet(t[e])}}OnCreateItem(t){const e=new rt.j
return e.setId(t,null,0),e.SetIconSize(56,56),e.SetBgSize(56,56),e.AdjustLayout(),e}Clear(){super.Clear()}Destroy(){super.Destroy()}}var Vt=i(57834),kt=i(8889)
class xt extends mt.x{constructor(...t){super(...t),this.rankVo=null,this.text_rank=null,this.grid_item=null,this.img_rank=null,this.img_icon=null,this.text_score=null,
this.text_name=null,this.img_bg=null,this.img_icon_bg=null,this.scroll_item=null,this.content=null,this.emptyContent=null,this.awardLisBtn=null,this.emptyName=null,this.mid=null,
this.rankConfig=null,this.rankType=null,this.rankName=null}InitView(){super.InitView(),this.text_rank=this.CreateComponent(x.Q,1),this.grid_item=this.CreateComponent(gt.N,2),
this.img_rank=this.CreateComponent(U.w,3),this.img_icon=this.CreateComponent(U.w,4),this.text_score=this.CreateComponent(x.Q,5),this.text_name=this.CreateComponent(x.Q,6),
this.img_bg=this.CreateComponent(U.w,7),this.img_icon_bg=this.CreateComponent(U.w,8),this.scroll_item=this.CreateComponent(kt.$,9),this.content=this.CreateComponent(V.z,10),
this.emptyContent=this.CreateComponent(V.z,11),this.awardLisBtn=this.CreateComponent(k.W,12),this.emptyName=this.CreateComponent(x.Q,13),this.mid=this.CreateComponent(V.z,14),
this.grid_item.SetInitInfo("ui_baseitem",null,rt.j),this.SetDepth($t.Inst_get().panel.FatherId)
const t=st.v.GetAdaptionWidth(900,1157)
this.img_bg.widthSet(t),st.v.SetAdaptionPos(this.scroll_item,542,800,-17),st.v.SetAdaptionPos(this.mid,0,179,0)}SetDepth(t){h.N.inst.SetChildDepth(t,this.FatherId)}SetData(t){
this.AddLis(),this.rankVo=t,this.UpdatePanel()}AddLis(){Vt.i.Get(this.awardLisBtn.node).RegistonClick(this.CreateDelegate(this.OnAwardLisBtnHandle))}RemoveLis(){
Vt.i.Get(this.awardLisBtn.node).RemoveonClick(this.CreateDelegate(this.OnAwardLisBtnHandle))}OnAwardLisBtnHandle(){if(null!=this.rankVo&&null!=this.rankVo.rank){
const t=new _.Z,e=this.rankVo.rank[0]
let i=this.rankVo.rank[1]
null==i&&(i=e)
const n=L.J.Inst_get().GetRankInfo(L.J.Inst_get().select_huodong_id).rank
if(null!=this.rankConfig&&null!=this.rankConfig.rankConfigVoList){const e=this.rankConfig.rankConfigVoList
if(null!=e){const i=e[n]
if(null!=i)for(let e=0;e<=i.rankReward.rewards.Count()-1;e++){const s=lt.M.wrapReward(i.rankReward.rewards[e])
t.Add(s)}}}for(let a=e;a<=i;a++){const e=this.RankInfo_Get().rankInfos[a]
let i="暂无人上榜",o=""
if(null!=e){i=e.name
let t=e.rankValue
if(this.rankType==Lt.c.LEVEL){const i=(0,s.aI)(e.rankValue)
t=Gt.h.GetLevelStr(i)}o=`${this.rankName}:[5FB470]${t}[-]`}const l={rank:a,name:i,desc:o,isMy:n==a}
t.Add(l)}t.Count()>0&&$t.Inst_get().OpenRankLisPanel(t)}}Clear(){super.Clear(),this.RemoveLis()}Destroy(){super.Destroy()}UpdatePanel(){this.emptyContent.SetActive(!1),
this.content.SetActive(!1),this.awardLisBtn.node.SetActive(!1),this.img_rank.node.SetActive(!1)
let t=null
if(null!=this.rankVo&&null!=this.rankVo.rank&&null!=this.rankVo.rank[0]&&null!=this.RankInfo_Get()&&this.RankInfo_Get().rankInfos[this.rankVo.rank[0]]&&(t=this.RankInfo_Get().rankInfos[this.rankVo.rank[0]]),
this.rankName=L.J.Inst_get().GetRankNameByActivityId(L.J.Inst_get().select_huodong_id),this.rankType=L.J.Inst_get().GetRankTypeByActivityId(L.J.Inst_get().select_huodong_id),
null==t){this.emptyContent.SetActive(!0)
let t=this.rankVo.minLimit
this.rankType==Lt.c.LEVEL&&(t=Gt.h.GetLevelStr(this.rankVo.minLimit))
let e=`暂无人上榜\n(要求:${this.rankName}≥${t})`
0==this.rankVo.minLimit&&(e="暂无人上榜"),this.emptyName.textSet(e)}if(this.rankVo.rank[0]==this.rankVo.rank[1]){if(this.text_rank.textSet(""),this.img_rank.node.SetActive(!0),
this.img_rank.spriteNameSet(`rypaihangbang_sp_000${this.rankVo.rank[0]}`),null!=t){let e=t.rankValue
if(this.rankType==Lt.c.LEVEL){const i=(0,s.aI)(t.rankValue)
e=Gt.h.GetLevelStr(i)}this.content.SetActive(!0),this.text_score.textSet(It.o.Format(`${this.rankName}:{0}`,e)),this.text_name.textSet(t.name),this.img_icon.node.SetActive(!0),
this.img_icon_bg.node.SetActive(!0),this.img_icon.spriteNameSet(ht.Z.GetJobIcon(t.job,t.sex,!1))}}else this.text_rank.textSet(It.o.Format((0,
G.T)("{0}-{1}名"),this.rankVo.rank[0],this.rankVo.rank[1])),null!=t&&this.awardLisBtn.node.SetActive(!0)
const e=new _.Z
for(let t=0;t<=this.rankVo.rankReward.rewards.Count()-1;t++){const i=lt.M.wrapReward(this.rankVo.rankReward.rewards[t])
e.Add(i)}this.grid_item.data_set(e)}RankInfo_Get(){return L.J.Inst_get().GetRankInfo(L.J.Inst_get().select_huodong_id)}RankReward_Get(){
return L.J.Inst_get().GetRankConfigById(L.J.Inst_get().select_huodong_id)}}var Ht=i(38836),Ut=i(84473),Ft=i(46623)
class Yt extends mt.x{constructor(...t){super(...t),this.text_tab_0=null,this.img_red_0=null,this.img_finish_0=null,this.ui_sevenday_quest_tabbtn_item=null,this.clickHandler=null,
this.data=null,this.redId=null}InitView(){super.InitView(),this.text_tab_0=this.CreateComponent(x.Q,1),this.img_red_0=this.CreateComponent(V.z,2),
this.img_finish_0=this.CreateComponent(V.z,3),this.ui_sevenday_quest_tabbtn_item=this.CreateComponent(k.W,4)}SetData(t){this.data=t,
this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.OnClickItem)),this.text_tab_0.textSet(t.typeName),
this.redId=B.t[L.J.ins.GetRedPointName(this.data.activityId,this.data.targetType)],
null!=this.data.activityId&&Ot.f.Inst.AddCallback(this.redId,this.CreateDelegate(this._OnRedPointUpdate)),this.UpdateRedPoint(),this.UpdateFinish()}_OnRedPointUpdate(){
this.UpdateRedPoint(),this.UpdateFinish()}UpdateRedPoint(){this.img_red_0.SetActive(Ot.f.Inst.GetData(this.redId).show)}UpdateFinish(){if((0,s.t2)(this.data,Ft.h)){let t=!0
const e=D.i.ins.GetQuestListVoByIdAndTargetType(this.data.activityId,this.data.targetType)
for(const[i,s]of(0,Ht.V5)(e))if(!L.J.ins.IsActivityTaskFinish(s)){t=!1
break}this.img_finish_0.SetActive(t)}else this.img_finish_0.SetActive(!1)}OnClickItem(){this.SetSelect(!0),null!=this.clickHandler&&this.clickHandler(this.data)}SetSelect(t){
t?(null!=Yt._CurrentSelect&&Yt._CurrentSelect.SetSelect(!1),Yt._CurrentSelect=this,this.ui_sevenday_quest_tabbtn_item.SetState(Ut.D.ePressed,!0),
this.ui_sevenday_quest_tabbtn_item.SetIsEnabled(!1)):(this.ui_sevenday_quest_tabbtn_item.SetState(Ut.D.eNormal,!0),this.ui_sevenday_quest_tabbtn_item.SetIsEnabled(!0))}Clear(){
super.Clear(),null!=this.data.activityId&&Ot.f.Inst.RemoveCallback(this.redId,this.CreateDelegate(this._OnRedPointUpdate))}Destroy(){Yt._CurrentSelect=null,super.Destroy()}}
Yt._CurrentSelect=null
class Kt extends it.${constructor(){super(),this.select_target_type=0,this.endTimer=-1,this.defaultSelect=-1,this.timerId=-1,this.cacheItemList=null,this.activityItem=null,
this.isInit=!1,this.myRankInfo=null,this.info=null,this.isfirstenter=!0,this.firstInfo=null,this.rankConfig=null,this.tabGrid=null,this.timeTxt=null,this.questGrid=null,
this.mallGrid=null,this.rankGrid=null,this.bar=null,this.firstGrid=null,this.myRankGrid=null,this.myRankdescTxt=null,this.myRankdescTxt1=null,this.accessBtn=null,
this.myRankTxt=null,this.tipBtn=null,this.firstRankTxt=null,this.firstNameTxt=null,this.firstIcon=null,this.firstDescTxt=null,this.getBtn=null,this.myRankGo=null,
this.titleTxt=null,this.rankBar=null,this.noRankGo=null,this.mallBar=null,this.mallBg=null,this.leftWidget=null,this.rightWidget=null,this.myRankMid=null,this.myRankRight=null,
this.myRankBg=null,this.effPanel=null,this.oldSortListDic=null,this.hasSendRank=null,this.hasRaiseEnd=null,this.rankName=null,this.rankType=null,this.cacheItemList=new _.Z,
this.activityItem=new _.Z}InitView(){super.InitView(),this.tabGrid=this.CreateComponent($.A,1),this.timeTxt=this.CreateComponent(x.Q,2),this.questGrid=this.CreateComponent($.A,3),
this.mallGrid=this.CreateComponent($.A,4),this.rankGrid=this.CreateComponent($.A,5),this.bar=this.CreateComponent(q._,6),this.firstGrid=this.CreateComponent(gt.N,7),
this.myRankGrid=this.CreateComponent(gt.N,8),this.myRankdescTxt=this.CreateComponent(x.Q,9),this.myRankdescTxt1=this.CreateComponent(x.Q,21),
this.accessBtn=this.CreateComponent(k.W,10),this.myRankTxt=this.CreateComponent(x.Q,11),this.tipBtn=this.CreateComponent(k.W,12),this.firstRankTxt=this.CreateComponent(x.Q,13),
this.firstNameTxt=this.CreateComponent(x.Q,14),this.firstIcon=this.CreateComponent(U.w,15),this.firstDescTxt=this.CreateComponent(x.Q,16),this.getBtn=this.CreateComponent(k.W,17),
this.myRankGo=this.CreateComponent(V.z,18),this.titleTxt=this.CreateComponent(x.Q,19),this.rankBar=this.CreateComponent(q._,20),this.noRankGo=this.CreateComponent(V.z,22),
this.mallBar=this.CreateComponent(q._,23),this.mallBg=this.CreateComponent(U.w,24),this.leftWidget=this.CreateComponent(et.T,25),this.rightWidget=this.CreateComponent(et.T,26),
this.myRankMid=this.CreateComponent(V.z,27),this.myRankRight=this.CreateComponent(V.z,28),this.myRankBg=this.CreateComponent(U.w,29),this.effPanel=this.CreateComponent(V.z,30),
this.tabGrid.SetInitInfo("ui_sevenday_quest_tabbtn_item",this.CreateDelegate(this.CreateTabBtn)),this.tabGrid.OnReposition_set(this.CreateDelegate(this.OnTabGridLoaded)),
this.questGrid.SetInitInfo("ui_openservergrab_quest_item1",this.CreateDelegate(this.CreateQuestItem)),this.mallGrid.SetInitInfo("ui_openservergrab_mallitem",null,Mt),
this.rankGrid.SetInitInfo("ui_openservergrab_rank_item",null,xt),this.myRankGrid.SetInitInfo("ui_baseitem",null,rt.j),this.firstGrid.SetInitInfo("ui_baseitem",null,rt.j),
nt.O.SetAnchorPos(this.leftWidget,!0,!1,0),nt.O.SetAnchorPos(this.rightWidget,!1,!0,0)
const t=st.v.GetAdaptionWidth(900,1157)
this.mallBg.widthSet(t)
const e=st.v.GetAdaptionWidth(230,300)
this.mallGrid.cellWidthSet(e),st.v.SetAdaptionPos(this.mallGrid,0,30,-10)
const i=st.v.GetAdaptionWidth(905,1162)
this.myRankBg.widthSet(i),st.v.SetAdaptionPos(this.myRankRight,0,210,0),st.v.SetAdaptionPos(this.myRankMid,0,100,0),this.oldSortListDic=null}SetData(){
-1==this.endTimer&&(this.endTimer=W.C.Inst_get().SetInterval(this.CreateDelegate(this.RefreshTime),1e3)),this.hasSendRank=!1,this.ClearOldSortListDic(),this.RefreshTime(),
this.AddLis(),this.InitTabs(),this.UpdatePanel()}AddLis(){this.m_handlerMgr.AddEventMgr(I.g.HUODONG_QUEST_CHANGE,this.CreateDelegate(this.UpdatePanel)),
this.m_handlerMgr.AddEventMgr(I.g.RANK_SELF_RANK_VALUE,this.CreateDelegate(this.UpdateMyRankInfo)),
this.m_handlerMgr.AddEventMgr(I.g.HUODONG_RANKINFO_UPDATE,this.CreateDelegate(this.UpdateRankInfo)),
this.m_handlerMgr.AddEventMgr(I.g.RANK_REWARD,this.CreateDelegate(this.UpdateConfig)),this.m_handlerMgr.AddClickEvent(this.accessBtn,this.CreateDelegate(this.AccessBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.tipBtn,this.CreateDelegate(this.TipBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.firstIcon.node,this.CreateDelegate(this.OnHeadIconClickHandle)),
this.m_handlerMgr.AddClickEvent(this.getBtn,this.CreateDelegate(this.GetBtnHandle)),A.N.GetInst().AddEventHandler(Et.G.BUY_MALLINFO,this.CreateDelegate(this.UpdatePanel))}
RemoveLis(){-1!=this.endTimer&&(W.C.Inst_get().ClearInterval(this.endTimer),this.endTimer=-1),
A.N.GetInst().RemoveEventHandler(Et.G.BUY_MALLINFO,this.CreateDelegate(this.UpdatePanel))}GetBtnHandle(){
if(null!=L.J.Inst_get().select_huodong_id&&0!=L.J.Inst_get().select_huodong_id){const t=L.J.Inst_get().GetRankTypeByActivityId(L.J.Inst_get().select_huodong_id)
P.l.ins.CM_GainAcitivityRankReward(L.J.Inst_get().select_huodong_id,t)}}TipBtnHandle(){const t=new Rt.w,e=new vt.o
e.content=w.J.ins.GetHuoDongVo(L.J.Inst_get().select_huodong_id).tips,e.isPoint=!1,t.contents=new _.Z([e]),t.width=384,t.position=new yt.P(157,234,0),wt.Q.Inst_get().Open(t)}
OnHeadIconClickHandle(){if(null==this.firstInfo)return
const t=this.firstInfo.playerId
null==t||At.Y.Inst.IsMultiPlayer(t)||(Dt.I.calVec0.Set(-150,0,0),bt.Z.Inst().Open(t,null,null,Dt.I.calVec0))}AccessBtnHandle(){
const t=w.J.ins.GetAccessDataLisById(L.J.Inst_get().select_huodong_id)
$t.Inst_get().OpenAccessPanel(t)}CreateQuestItem(t){const e=new St
return e.setId(t,null,0),e.SetAdapt1(),e}CreateTabBtn(t){const e=new Yt
return e.setId(t,null,0),e.clickHandler=this.CreateDelegate(this.OnClickBtnTab),e}UpdatePanel(){this.hasRaiseEnd=!1
const t=w.J.ins.GetHuoDongVo(L.J.Inst_get().select_huodong_id)
if(null==t)return
const e=t.name
this.titleTxt.textSet(e),this.rankName=L.J.Inst_get().GetRankNameByActivityId(L.J.Inst_get().select_huodong_id),this.UpdateData(),this.UpdateTargetType(),this.UpdateFirstRoleInfo()
}UpdateData(){this.info=L.J.Inst_get().GetRankInfo(L.J.Inst_get().select_huodong_id),this.rankConfig=L.J.Inst_get().GetRankConfigById(L.J.Inst_get().select_huodong_id),
this.firstInfo=null,null!=this.info&&null!=this.info.rankInfos&&(this.firstInfo=this.info.rankInfos[1]),
this.rankType=L.J.Inst_get().GetRankTypeByActivityId(L.J.Inst_get().select_huodong_id)}UpdateConfig(){const[t,e]=$t.Inst_get().GetEndIdx(L.J.Inst_get().select_huodong_id)
this.hasSendRank||null==t||null==e||(this.hasSendRank=!0,P.l.ins.CM_GetActivityRank(L.J.Inst_get().select_huodong_id,t,e)),this.UpdateRankInfo()}UpdateRankInfo(){
if(this.UpdateData(),this.UpdateFirstRoleInfo(),0==this.select_target_type){this.UpdateMyRankInfo()
const t=new _.Z
if(null!=this.rankConfig)for(let e=1;e<=this.rankConfig.rankConfigVoList.Count()-1;e++)t.Add(this.rankConfig.rankConfigVoList[e])
this.rankGrid.data_set(t)}}UpdateMyRankInfo(t){this.myRankInfo=L.J.Inst_get().GetMyRankInfo(L.J.Inst_get().select_huodong_id)
let e=!1,i=0
const n=new _.Z
let a=-1
if(null!=this.myRankInfo){e=this.myRankInfo.hasGain,i=this.myRankInfo.rankValue.ToNum()
let t=null
if(null!=this.info&&(a=this.info.rank,t=this.info.rankInfos[a],null!=this.rankConfig&&null!=this.rankConfig.rankConfigVoList&&a>0)){const t=this.rankConfig.rankConfigVoList
if(null!=t){let e=null
for(let i=0;i<=t.Count()-1;i++){const s=t[i].rank
if(1==s.Count()){if(a==s[0]){e=t[i]
break}}else if(2==s.Count()&&a>=s[0]&&a<=s[1]){e=t[i]
break}}if(null!=e)for(let t=0;t<=e.rankReward.rewards.Count()-1;t++){const i=lt.M.wrapReward(e.rankReward.rewards[t])
n.Add(i)}}}}if(!(null!=t&&"boolean"==typeof t&&t)){this.noRankGo.SetActive(!1),a>0?this.myRankTxt.textSet(a):(this.myRankTxt.textSet("暂未上榜"),this.noRankGo.SetActive(!0)),
this.myRankGrid.data_set(n),null==i&&(i=0)
let t=(0,s.tw)(i)
this.rankType==Lt.c.LEVEL&&(t=i>0?Gt.h.GetLevelStr(i):"0级"),this.myRankdescTxt.textSet(t),null==this.rankName&&(this.rankName=""),this.myRankdescTxt1.textSet(`我的${this.rankName}`)}
this.getBtn.SetIsEnabled(!e&&n.Count()>0&&D.i.ins.GetState(L.J.Inst_get().select_huodong_id)==R.V.END)}UpdateFirstRoleInfo(){if(this.firstIcon.node.SetActive(!1),
this.firstRankTxt.node.SetActive(!1),null!=this.firstInfo){this.firstIcon.node.SetActive(!0),this.firstNameTxt.textSet(this.firstInfo.name)
let t=this.firstInfo.rankValue
this.rankType==Lt.c.LEVEL&&(t=Gt.h.GetLevelStr((0,s.aI)(t))),this.firstDescTxt.textSet(`${this.rankName}:${t}`),
this.firstIcon.spriteNameSet(ht.Z.GetJobIcon(this.firstInfo.job,this.firstInfo.sex,!1))}else{let t=0
if(null!=this.rankConfig&&null!=this.rankConfig.rankConfigVoList){const e=this.rankConfig.rankConfigVoList
if(null!=e){const i=e[0]
null!=i&&(t=i.minLimit)}}this.firstDescTxt.textSet("")
let e=(0,s.tw)(t)
this.rankType==Lt.c.LEVEL&&(e=Gt.h.GetLevelStr(t)),this.firstRankTxt.node.SetActive(!0)
const i=`暂无人上榜\n(要求:${this.rankName}≥${e})`
this.firstRankTxt.textSet(i),this.firstNameTxt.textSet("")}let t=new _.Z
if(null!=this.rankConfig&&null!=this.rankConfig.rankConfigVoList){const e=this.rankConfig.rankConfigVoList
if(null!=e){const i=e[0]
null!=i&&(t=Tt.H.Inst_get().GetRewardDatasByAndReward(i.rankReward))}}this.effPanel.SetActive(t.Count()>0),this.firstGrid.data_set(t)}InitTabs(){const t=this.TargetTypes_Get()
if(null==t)return
const e=new _.Z,i=this.IsShowMall()
for(let s=0;s<=t.Count()-1;s++){const n=w.J.ins.GetQuestListVoByIdAndTargetType(L.J.Inst_get().select_huodong_id,t[s])
t[s]==v.h.MALL_BUY?i&&e.Add(n[0]):e.Add(n[0])}const s={activityId:L.J.Inst_get().select_huodong_id,typeName:"排行奖励",targetType:0}
e.Insert(0,s),this.tabGrid.data_set(e)
const n=$t.Inst_get().idx3
if(this.select_target_type=-1,null!=n&&n<=e.Count()-1)this.defaultSelect=n,$t.Inst_get().idx3=null,
this.defaultSelect==E.Q.Three_1?this.select_target_type=E.Q.Target_Rank:this.select_target_type=t[this.defaultSelect-1]
else{const e=B.t[L.J.ins.GetRedPointName(L.J.Inst_get().select_huodong_id,E.Q.Target_Rank)]
;-1==this.select_target_type&&Ot.f.Inst.GetData(e).show&&(this.select_target_type=E.Q.Target_Rank,this.defaultSelect=E.Q.Three_1)
for(let e=0;e<=t.Count()-1;e++){const i=B.t[L.J.ins.GetRedPointName(L.J.Inst_get().select_huodong_id,t[e])]
if(-1==this.select_target_type&&Ot.f.Inst.GetData(i).show){this.select_target_type=t[e],this.defaultSelect=e+1
break}}-1==this.select_target_type&&(this.select_target_type=E.Q.Target_Rank,this.defaultSelect=E.Q.Three_1)}this.bar.SetValue(0),this.rankBar.SetValue(0),this.mallBar.SetValue(0)}
OnTabGridLoaded(){this.tabGrid.itemList[this.defaultSelect].SetSelect(!0)}OnClickBtnTab(t){this.select_target_type=t.targetType,this.bar.SetValue(0),this.rankBar.SetValue(0),
this.mallBar.SetValue(0),this.ClearOldSortListDic(),this.UpdateTargetType()}IsShowMall(){
const t=D.i.ins.GetQuestListVoByIdAndTargetType(L.J.Inst_get().select_huodong_id,v.h.MALL_BUY)
if(null!=t&&t.Count()>0)for(let e=0;e<=t.Count()-1;e++){const i=t[e],s=w.J.ins.GetQuestVoById(i.taskId),n=c.M.String2Int(s.TargetDefs_Get().tCTargetDefs[0].param.mallId)
if(null!=A.N.GetInst().GetInfo(n))return!0}return!1}UpdateTargetType(){if(this.questGrid.node.SetActive(!1),this.mallBar.node.SetActive(!1),this.rankGrid.node.SetActive(!1),
this.myRankGo.SetActive(!1),this.mallBg.SetActive(!1),this.select_target_type==E.Q.Target_Rank)this.rankGrid.node.SetActive(!0),this.myRankGo.SetActive(!0),this.UpdateConfig()
else{const t=D.i.ins.GetQuestListVoByIdAndTargetType(L.J.Inst_get().select_huodong_id,this.select_target_type)
this.select_target_type==v.h.MALL_BUY?(this.mallBar.node.SetActive(!0),this.mallBg.SetActive(!0),null==this.oldSortListDic?(t.Sort(this.CreateDelegate(this.SortItemList)),
this.SetOldSortListDic(t)):t.Sort(this.CreateDelegate(this.SortItemList)),this.mallGrid.data_set(t),
$t.Inst_get().SendClickMsg(L.J.Inst_get().sevenday_huodong_ids.IndexOf(L.J.Inst_get().select_huodong_id))):(t.Sort(((t,e)=>{
const i=w.J.ins.GetQuestVoById(t.taskId).sort,s=w.J.ins.GetQuestVoById(e.taskId).sort
if(t.activityRewardVo.isReward!=e.activityRewardVo.isReward){if(t.activityRewardVo.isReward)return 1
if(e.activityRewardVo.isReward)return-1}
const n=t.targetVos[0].curValue.ToNum()==t.targetVos[0].targetValue.ToNum(),a=e.targetVos[0].curValue.ToNum()==e.targetVos[0].targetValue.ToNum()
if(n!=a){if(n)return-1
if(a)return 1}return i-s})),this.questGrid.node.SetActive(!0),this.questGrid.data_set(t))}}SortItemList(t,e){
const i=w.J.ins.GetQuestVoById(t.taskId),s=w.J.ins.GetQuestVoById(e.taskId)
if(null!=this.oldSortListDic){const i=this.oldSortListDic[t.taskId],s=this.oldSortListDic[e.taskId]
if(null!=i&&null!=s){if(i<s)return-1
if(i>s)return 1}}
const n=c.M.String2Int(i.TargetDefs_Get().tCTargetDefs[0].param.mallId),a=c.M.String2Int(s.TargetDefs_Get().tCTargetDefs[0].param.mallId),o=A.N.GetInst().GetInfo(n),l=A.N.GetInst().GetInfo(a)
if(null!=o&&null!=l){const t=o.Lastnum_get()>=o.GetBuyLimit(),e=l.Lastnum_get()>=l.GetBuyLimit()
if(t!=e){if(t)return 1
if(e)return-1}return i.sort-s.sort}return 0}SetOldSortListDic(t){null==this.oldSortListDic&&(this.oldSortListDic=new ft.X)
for(let e=0;e<=t.Count()-1;e++)this.oldSortListDic[t[e].taskId]=e}ClearOldSortListDic(){null!=this.oldSortListDic&&this.oldSortListDic.Clear(),this.oldSortListDic=null}
RefreshTime(){const t=L.J.Inst_get().GetCurActivityId(),e=D.i.ins.huodong_dict.LuaDic_GetItem(t)
if(D.i.ins.GetState(L.J.Inst_get().select_huodong_id)==R.V.OPEN||this.hasRaiseEnd||(n.i.Inst.RaiseEvent(I.g.OPEN_SERVER_GRAB_END),this.UpdateMyRankInfo(),this.hasRaiseEnd=!0),
null!=e){const t=at.p.FloorToInt(e.endTime.ToNum()/1e3)-J.D.serverTime_get()
t>0?this.timeTxt.textSet(`[b09979]结束倒计时:[-] [5fb470]${dt.l.GetDateFormatEX(t,!0,!0)}[-]`):this.timeTxt.textSet("[b09979]已结束[-]")}else this.timeTxt.textSet("[b09979]已结束[-]")}
TargetTypes_Get(){return w.J.ins.GetTargetTypesByHuoDongId(L.J.Inst_get().select_huodong_id)}Clear(){this.isfirstenter=!0,this.ClearOldSortListDic(),this.RemoveLis(),super.Clear()}
Destroy(){for(let t=0;t<=this.activityItem.Count()-1;t++)this.activityItem[t].item.Destroy()
for(let t=0;t<=this.cacheItemList.Count()-1;t++)this.cacheItemList[t].Destroy()
super.Destroy()}}class zt extends b.I{constructor(...t){super(...t),this.tabIdx1=-1}InitView(){super.InitView(),
this._subPanelDatas.Add(O.b.New(new _.Z(["ui_openservergrab_quest_view","ui_openservergrab_quest_item"]),this,pt)),
this._subPanelDatas.Add(O.b.New(new _.Z(["ui_openservergrab_sevenday_view","ui_sevenday_quest_item1","ui_openservergrab_mall_item","ui_openservergrab_mall_self_item"]),this,Kt)),
this.bottomTabGrid.SetInitInfo("ui_ry_openservergrab_bottomitem",null,K,this.CreateDelegate(this._OnClickBottomItem)),
this.rightTabGrid.SetInitInfo("ui_openservergrab_right_tab",null,z.K,this.CreateDelegate(this._OnClickRightItem)),
this.bottomTabGrid.OnReposition_set(this.CreateDelegate(this.OnRepositionBottom)),this.rightTabGrid.OnReposition_set(this.CreateDelegate(this.OnRepositionRight))}AddLis(){
super.AddLis()}RemoveLis(){super.RemoveLis()}SetViewConfig(){this.titleLabel.textSet((0,G.T)("开服活动")),this._SetCharacterTabData(!1),
this.tab0RedPointList=new _.Z([B.t.OPEN_SERVER_GRAB_QUEST,B.t.OPEN_SERVER_GRAB_RANK])
const t=this.GetIdx()
this.SelectTab0(t,!0)}GetIdx(){if(null!=$t.Inst_get().idx){const t=$t.Inst_get().idx
return $t.Inst_get().idx=null,t}return this.GetRedTabIndex(null)}SelectTab0(t,e,i){
1!=t||D.i.ins.GetState(M.t.OPEN_SERVER_GRAB_RANK_1)!=R.V.NONE?super.SelectTab0(t,e,i):N.y.inst.ClientSysStrMsg((0,G.T)("明日开启"))}SelectTab1(t,e){
if(null!=L.J.Inst_get().sevenday_huodong_ids[t])if(this.m_handlerMgr.AddEventMgr(I.g.HUODONG_INFO_CHANGE,this.CreateDelegate(this.OnGetHuodongInfo)),this.tabIdx1=t,
D.i.ins.GetState(L.J.Inst_get().sevenday_huodong_ids[this.tabIdx1])!=R.V.NONE)D.i.ins.GetState(L.J.Inst_get().sevenday_huodong_ids[this.tabIdx1])!=R.V.CLOSE?P.l.ins.CM_OpenActivityPanel(L.J.Inst_get().sevenday_huodong_ids[t]):N.y.inst.ClientSysStrMsg((0,
G.T)("活动已关闭"))
else{const t=L.J.Inst_get().rankDayDic[this.tabIdx1+1]
N.y.inst.ClientSysStrMsg(`开服第${t}天开启`)}}OnGetHuodongInfo(){this.m_handlerMgr.RemoveEventMgr(I.g.HUODONG_INFO_CHANGE,this.CreateDelegate(this.OnGetHuodongInfo)),
D.i.ins.GetState(L.J.Inst_get().sevenday_huodong_ids[this.tabIdx1])!=R.V.NONE?D.i.ins.GetState(L.J.Inst_get().sevenday_huodong_ids[this.tabIdx1])!=R.V.CLOSE?(this.tabIdx1=this.GetTabIdx1(),
super.SelectTab1(this.tabIdx1,!0,!1)):N.y.inst.ClientSysStrMsg((0,G.T)("活动已关闭")):N.y.inst.ClientSysStrMsg(`开服第${this.tabIdx1+1}天开启`)}GetTabIdx1(){if(null!=$t.Inst_get().idx2){
const t=$t.Inst_get().idx2
return $t.Inst_get().idx2=null,t}return this.GetRedTabIndex(this.tabIdx1,this.tab1RedPointList)}_OnSelectTab0BeforeUpdate(t){
const e=new _.Z([w.J.ins.GetHuoDongVo(M.t.OPEN_SERVER_GRAB_QUEST).name,"开服狂欢"]),i=new _.Z([B.t.OPEN_SERVER_GRAB_QUEST,B.t.OPEN_SERVER_GRAB_RANK])
if(0==this.selectTabIdx0)L.J.Inst_get().select_huodong_id=M.t.OPEN_SERVER_GRAB_QUEST,this._SetTabData0(!0,e,i),this._SetTabData1(!1)
else if(1==this.selectTabIdx0){L.J.Inst_get().select_huodong_id=L.J.Inst_get().GetOpeningId(),
0==L.J.Inst_get().select_huodong_id&&(L.J.Inst_get().select_huodong_id=L.J.Inst_get().sevenday_huodong_ids.LastItem()),
this._SetTabData0(!0,e,i,null,null,null,null,null,new _.Z([0,M.t.OPEN_SERVER_GRAB_RANK_1]))
const t=new _.Z
for(let e=0;e<=L.J.Inst_get().sevenday_huodong_ids.Count()-1;e++)t.Add(w.J.ins.GetHuoDongVo(L.J.Inst_get().sevenday_huodong_ids[e]).name)
this._SetTabData1(!0,t,L.J.Inst_get().sevenday_red_ids,null,null,null,L.J.Inst_get().sevenday_huodong_ids),
this.SelectTab1(L.J.Inst_get().sevenday_huodong_ids.IndexOf(L.J.Inst_get().select_huodong_id),!0)}}_OnSelectTab1BeforeUpdate(t){
L.J.Inst_get().select_huodong_id=L.J.Inst_get().sevenday_huodong_ids[this.selectTabIdx1]}Clear(){super.Clear(),this.RemoveLis(),L.J.Inst_get().select_huodong_id=0}Destroy(){
super.Destroy()}OnCloseClick(){$t.Inst_get().ClosePanel()}UpdateView(){this.rightBg1.SetActive(!0),
0==this.selectTabIdx0?this.ShowSubView(0):1==this.selectTabIdx0&&(this.ShowSubView(1),this.rightBg1.SetActive(!1))}}var Qt=i(61911),Zt=i(44518),Xt=i(35639)
class jt extends Qt.f{constructor(...t){super(...t),this.btn_close=null,this.grid_icon=null}InitView(){super.InitView(),this.btn_close=this.CreateComponent(k.W,1),
this.grid_icon=this.CreateComponent($.A,2),this.grid_icon.SetInitInfo("ui_access_icon",null,Xt.R)}AddLis(){
this.m_handlerMgr.AddClickEvent(this.btn_close,this.CreateDelegate(this.OnClickClose)),this.AddFullScreenCollider(this.CreateDelegate(this.OnClickClose)),
this.m_handlerMgr.AddEventMgr(I.g.ACCESS_ICON_CLICK,this.CreateDelegate(this.OnClickClose))}RemoveLis(){this.RemoveFullScreenCollider()}OnAddToScene(){this.AddLis(),
this.UpdatePanel()}PlayTween(){nt.O.PlayNormalCloseTween(this.btn_close,this.CreateDelegate(this.OnClickClose))}OnClickClose(){$t.Inst_get().CloseAccessPanel()}Clear(){
this.RemoveLis(),super.Clear()}Destroy(){super.Destroy(),this.btn_close=null,this.grid_icon=null}UpdatePanel(){const t=$t.Inst_get().accessDataLis,e=new _.Z
for(let i=0;i<=t.Count()-1;i++){const s=t[i],n=s.accessId,a=Zt.F.ins.GetAccessById(n)
let o=!0
if(null!=a){for(let t=0;t<=a.Conditions_Get().Count()-1;t++)if(!a.Conditions_Get()[t].CheckCondition()){o=!1
break}}else o=!1
o&&e.Add(s)}this.grid_icon.data_set(e)}}class Jt extends mt.x{constructor(...t){super(...t),this.data=null,this.text_rank=null,this.descTxt=null,this.bg=null}InitView(){
super.InitView(),this.text_rank=this.CreateComponent(x.Q,1),this.descTxt=this.CreateComponent(x.Q,5),this.name=this.CreateComponent(x.Q,6),this.bg=this.CreateComponent(U.w,7)}
Destroy(){super.Destroy()}SetData(t){this.data=t
const e=t.rank
this.text_rank.textSet(e),this.name.textSet(this.data.name),this.descTxt.textSet(this.data.desc),this.bg.node.SetActive(this.data.isMy),this.AddLis()}AddLis(){}RemoveLis(){}
Clear(){this.data=null,this.RemoveLis(),super.Clear()}}class Wt extends Qt.f{constructor(...t){super(...t),this.rankLisGrid=null}InitView(){super.InitView(),
this.rankLisGrid=this.CreateComponent($.A,1),this.rankLisGrid.SetInitInfo("ui_openservergrab_ranklis_item",null,Jt)}OnAddToScene(){this.AddLis(),this.UpdateView()}UpdateView(){
this.rankLisGrid.data_set($t.Inst_get().rankLis)}Clear(){super.Clear(),this.rankLisGrid.Clear(),this.RemoveLis()}Destroy(){this.rankLisGrid.Destroy()}AddLis(){
this.AddFullScreenCollider(this.node,this.CreateDelegate(this.OnCloseView))}RemoveLis(){this.RemoveFullScreenCollider(this.node,this.CreateDelegate(this.OnCloseView))}
OnCloseView(){$t.Inst_get().CloseRankLisPanel()}}class $t{constructor(){this.panel=null,this.accessPanel=null,this.accessDataLis=null,this.m_handlerMgr=null,this.idx=null,
this.idx2=null,this.idx3=null,this.rankLis=null,this.rankLisPanel=null,this.accessDataLis=new _.Z,this.InitHandlerMgr(),this.AddLis()}static Inst_get(){
return null==$t.inst&&($t.inst=new $t),$t.inst}InitHandlerMgr(){return null==this.m_handlerMgr&&(this.m_handlerMgr=u.h.Get()),this.m_handlerMgr}AddLis(){
a.j.Inst.F_Register(-5964,S.U,this.CreateDelegate(this.SM_QueryFirstPassMapName))}SM_QueryFirstPassMapName(t){n.i.Inst.RaiseEvent(I.g.QUERY_FIRST_PASS_MAP_NAME,t)}
CM_QueryFirstPassMapName(t){const e=new C.I
e.passMapPoint=t,o.C.Inst.F_SendMsg(e)}GetEndIdx(t){const e=L.J.Inst_get().GetRankTypeByActivityId(t)
if(f.K.Inst_get().rank_rewards_dict[t]){const i=f.K.Inst_get().rank_rewards_dict[t][e],s=i.rankConfigVoList[i.rankConfigVoList.Count()-1]
return[i.rankConfigVoList[0].rank[0],s.rank[1]]}}IsCanOpen(t,e,i){if(!g.P.Inst_get().IsFunctionOpened(m.x.OPEN_SERVER_GRAB))return!1
if(t==E.Q.Quest)return!0
if(t==E.Q.SevenDay){if(null==e)return!0
const t=L.J.Inst_get().sevenday_huodong_ids[e]
if(null!=t&&D.i.ins.GetState(t)!=R.V.NONE&&D.i.ins.GetState(t)!=R.V.CLOSE){if(i!=E.Q.Three_3)return!0
if(this.IsShowMall(t))return!0}}return!1}IsShowMall(t){const e=D.i.ins.GetQuestListVoByIdAndTargetType(t,v.h.MALL_BUY)
if(null!=e&&e.Count()>0)for(let t=0;t<=e.Count()-1;t++){const i=e[t],s=w.J.ins.GetQuestVoById(i.taskId),n=c.M.String2Int(s.TargetDefs_Get().tCTargetDefs[0].param.mallId)
if(null!=A.N.GetInst().GetInfo(n))return!0}return!1}OpenPanel(t,e=null,i=null){if(!g.P.Inst_get().IsFunctionOpened(m.x.OPEN_SERVER_GRAB))return
if(this.idx=t,this.idx2=e,this.idx3=i,null==t&&(t=0),null!=this.panel&&this.panel.isShow_get())return this.panel.selectTabIdx0=t,void this.panel.UpdateView()
p.r.Inst_get().RegMsgUID(-11665,-11666,d.I.eSevenDayPanel,L.J.Inst_get().sevenday_huodong_ids[t],L.J.Inst_get().sevenday_huodong_ids[t],"开服活动加载中...")
const s=new l.v
s.isShowMask=!0,s.isDefaultUITween=!0,s.isSelfTween=!1,h.N.inst.OpenById(d.I.OpenServerGrabPanel,this.CreateDelegate(this.CallComplete),this.CreateDelegate(this.CallDestroy),s)}
ClosePanel(){h.N.inst.CloseById(d.I.OpenServerGrabPanel)}CallComplete(t){return null==this.panel&&(this.panel=new zt,this.panel.setId(t,null,0)),this.panel}CallDestroy(){
r.g.DestroyUIObj(this.panel),this.panel=null,null!=this.accessPanel&&(this.CloseAccessPanel(),this.CloseRankLisPanel())}OpenAccessPanel(t){if(this.accessDataLis=t,
null!=this.accessPanel&&this.accessPanel.isShow_get())return void this.accessPanel.UpdatePanel()
const e=new l.v
e.isShowMask=!0,e.isDefaultUITween=!0,e.isSelfTween=!1,h.N.inst.OpenById(d.I.OpenServerGrabAccessPanel,this.CreateDelegate(this.CallAccessComplete),this.CreateDelegate(this.CallAccessDestroy),e)
}CloseAccessPanel(){h.N.inst.CloseById(d.I.OpenServerGrabAccessPanel)}CallAccessComplete(t){return null==this.accessPanel&&(this.accessPanel=new jt,
this.accessPanel.setId(t,null,0)),this.accessPanel}CallAccessDestroy(){r.g.DestroyUIObj(this.accessPanel),this.accessPanel=null}OpenRankLisPanel(t){if(this.rankLis=t,
null!=this.rankLisPanel&&this.rankLisPanel.isShow_get())return void this.rankLisPanel.UpdateView()
const e=new l.v
e.isShowMask=!1,e.isDefaultUITween=!0,e.isSelfTween=!1,h.N.inst.OpenById(d.I.OpenServerGrabRankLisView,this.CreateDelegate(this.CallRankLisComplete),this.CreateDelegate(this.CallRankLisDestroy),e)
}CloseRankLisPanel(){h.N.inst.CloseById(d.I.OpenServerGrabRankLisView)}CallRankLisComplete(t){return null==this.rankLisPanel&&(this.rankLisPanel=new Wt,
this.rankLisPanel.setId(t,null,0)),this.rankLisPanel}CallRankLisDestroy(){r.g.DestroyUIObj(this.rankLisPanel),this.rankLisPanel=null}IsClickByIndex(t){
return y.p.inst.GetClientLogicSetting(T.R.OPEN_SERVER_GRAB_MALL).Contains((0,s.tw)(t))}SendClickMsg(t){const e=y.p.inst.GetClientLogicSetting(T.R.OPEN_SERVER_GRAB_MALL)
e.Contains((0,s.tw)(t))||(e.Add((0,s.tw)(t)),y.p.inst.SendClientLogicSetting(T.R.OPEN_SERVER_GRAB_MALL,e,!1),
L.J.Inst_get()._checkActivityRedPoint(L.J.Inst_get().sevenday_huodong_ids[t]))}}$t.inst=null},43709:(t,e,i)=>{i.d(e,{Q:()=>s})
class s{}s.Quest=0,s.SevenDay=1,s.Rank_1=0,s.Rank_2=1,s.Rank_3=2,s.Rank_4=3,s.Rank_5=4,s.Rank_6=5,s.Rank_7=6,s.Three_1=0,s.Three_2=1,s.Three_3=2,s.Target_Rank=0},79411:(t,e,i)=>{
i.d(e,{J:()=>R})
var s=i(38836),n=i(38045),a=i(16812),o=i(5924),l=i(98885),r=i(85602),h=i(38962),d=i(37648),u=i(75439),c=i(8211),_=i(56828),I=i(47174),g=i(14792),m=i(40621),C=i(62734),S=i(12842),p=i(56834),A=i(23649),f=i(69622),y=i(93727),T=i(98936)
class R extends a.k{constructor(){super(),this.select_huodong_id=0,this.sevenday_red_ids=null,this.sevenday_huodong_ids=null,this.rankTypeLis=null,this.rankNameDic=null,
this.rankDayDic=null,
this.sevenday_huodong_ids=new r.Z([S.t.OPEN_SERVER_GRAB_RANK_1,S.t.OPEN_SERVER_GRAB_RANK_2,S.t.OPEN_SERVER_GRAB_RANK_3,S.t.OPEN_SERVER_GRAB_RANK_4,S.t.OPEN_SERVER_GRAB_RANK_5,S.t.OPEN_SERVER_GRAB_RANK_6,S.t.OPEN_SERVER_GRAB_RANK_7]),
this.rankTypeLis=new r.Z([I.c.LEVEL,I.c.EXCELLENCE_RANK,I.c.OPEN_SERVER_HORSE_SCORE,I.c.ENHANCE_RANK,I.c.ADD_RANK,I.c.GOD_EQUIP_SCORE_RANK,I.c.HISTORY_MAX_BATTLE_SCORE_RANK]),
this.rankNameDic=new h.X,this.rankDayDic=new h.X
const t=u.D.getInstance().getContent("SEVEN_DAY:NAME").getContent().stringVal,e=l.M.Split(t,l.M.s_SPAN_CHAR_DOT)
let i=-1
for(let t=0;t<=e.Count()-1;t++){const s=l.M.Split(e[t],l.M.s_Arr_CCD_CHAR_COLON)
i=(0,n.aI)(s[0]),this.rankDayDic[t+1]=i,this.rankNameDic[t+1]=l.M.Replace(s[1],l.M.s_STRING_CHAR_DOT,"")}this.InitRed()}static Inst_get(){return null==R.ins&&(R.ins=new R),R.ins}
GetOpeningId(){const t=d.P.Inst_get()
let e=-1
for(let i=0;i<=this.sevenday_red_ids.Count()-1;i++){const s=this.sevenday_red_ids[i]
if(s>0){const n=C.f.Inst.GetData(s)
let a=!0
const o=m.c.inst.GetFunIdByRedPointId(s)
if(-1!=o&&(a=t.IsFunctionOpened(o)),a&&n&&n.show){e=i
break}}}if(-1!=e){const t=y.i.ins.GetState(this.sevenday_huodong_ids[e])
if(t==p.V.OPEN||t==p.V.END)return this.sevenday_huodong_ids[e]}
for(let t=0;t<=this.sevenday_huodong_ids.Count()-1;t++)if(y.i.ins.GetState(this.sevenday_huodong_ids[t])==p.V.OPEN)return this.sevenday_huodong_ids[t]
let i=0
for(let t=0;t<=this.sevenday_huodong_ids.Count()-1;t++)y.i.ins.GetState(this.sevenday_huodong_ids[t])==p.V.END&&(i=t)
return this.sevenday_huodong_ids[i]}GetOpeningDayIndex(){for(let t=0;t<=this.sevenday_huodong_ids.Count()-1;t++)if(y.i.ins.GetState(this.sevenday_huodong_ids[t])==p.V.OPEN)return t
return 0}CheckRed(){o.C.Inst_get().CallLater(this.CreateDelegate(this.OnCheckRed))}OnCheckRed(){for(let t=0;t<=this.sevenday_huodong_ids.Count()-1;t++){
const e=this.sevenday_huodong_ids[t]
this._checkActivityRedPoint(e)}this._checkActivityRedPoint(S.t.OPEN_SERVER_GRAB_QUEST),this._checkActivityRedPoint(S.t.OPEN_SERVER_GRAB_QUEST_ALL)}_checkActivityRedPoint(t){
const e=f.J.ins.GetTargetTypesByHuoDongId(t),i=g.t[this.GetRedPointName(t,0)]
if(C.f.Inst.SetState(i,!1),y.i.ins.GetState(t)!=p.V.CLOSE&&y.i.ins.GetState(t)!=p.V.NONE){if(y.i.ins.GetState(t)==p.V.END){const e=this.GetMyRankInfo(t)
if(null==e)return
!e.hasGain&&e.isOnRank&&C.f.Inst.SetState(i,!0)}for(let i=0;i<=e.Count()-1;i++){const n=g.t[this.GetRedPointName(t,e[i])]
C.f.Inst.SetState(n,!1)
const a=f.J.ins.GetQuestListVoByIdAndTargetType(t,e[i])
for(const[o,r]of(0,s.V5)(a)){const a=y.i.ins.GetQuestVo(r.id)
if(null!=a&&!a.activityRewardVo.isReward)if(A.h.MALL_BUY==e[i]){
const e=l.M.String2Int(f.J.ins.GetQuestVoById(a.taskId).TargetDefs_Get().tCTargetDefs[0].param.mallId),i=c.N.GetInst().GetInfo(e)
if(null==i)break
if(null!=i&&i.Lastnum_get()>=i.GetBuyLimit()||y.i.ins.GetState(t)==p.V.CLOSE)break
if(!T.V.Inst_get().IsClickByIndex(this.sevenday_huodong_ids.IndexOf(t))){C.f.Inst.SetState(n,!0)
break}}else{let t=!0
for(const[e,i]of(0,s.V5)(a.targetVos))if(i.curValue.ToNum()<i.targetValue.ToNum()){t=!1
break}if(t){C.f.Inst.SetState(n,!0)
break}}}}}}InitRed(){const t=new r.Z
g.t.OPEN_SERVER_GRAB_QUEST=C.f.Inst.GetID(),t.Clear(),t.Add(g.t.OPEN_SERVER_GRAB),C.f.Inst.AddNode(g.t.OPEN_SERVER_GRAB_QUEST,t,!1,!1),
this._CreateActivityRedPointId(g.t.OPEN_SERVER_GRAB_QUEST,S.t.OPEN_SERVER_GRAB_QUEST),this._CreateActivityRedPointId(g.t.OPEN_SERVER_GRAB_QUEST,S.t.OPEN_SERVER_GRAB_QUEST_ALL),
g.t.OPEN_SERVER_GRAB_RANK=C.f.Inst.GetID(),t.Clear(),t.Add(g.t.OPEN_SERVER_GRAB),C.f.Inst.AddNode(g.t.OPEN_SERVER_GRAB_RANK,t,!1,!1),this.sevenday_red_ids=new r.Z
for(let e=1;e<=this.sevenday_huodong_ids.Count();e++){t.Clear(),t.Add(g.t.OPEN_SERVER_GRAB_RANK)
const i=`OPEN_SERVER_GRAB_RANK_${e}`
g.t[i]=C.f.Inst.GetID(),this.sevenday_red_ids.Add(g.t[i]),C.f.Inst.AddNode(g.t[i],t,!1,!1)
const s=this.sevenday_huodong_ids[e-1]
this._CreateActivityRedPointId(g.t[i],s)}}_CreateActivityRedPointId(t,e){const i=f.J.ins.target_type_dict.LuaDic_GetItem(e),s=new r.Z
s.Add(t)
const n=new r.Z
n.Add(0),n.AddRange(i)
for(let t=0;t<=n.Count()-1;t++){const i=this.GetRedPointName(e,n[t])
g.t[i]=C.f.Inst.GetID(),C.f.Inst.AddNode(g.t[i],s,!1,!1)}}GetRedPointName(t,e){return`OPEN_SERVER_GRAB_RANK_${t}_${e}`}IsActivityTaskFinish(t){
const e=f.J.ins.GetQuestVoById(t.taskId),i=l.M.String2Int(e.TargetDefs_Get().tCTargetDefs[0].param.mallId)
if(i&&i>0){const t=c.N.GetInst().GetInfo(i)
if(t)return t.Lastnum_get()>=t.GetBuyLimit()}return t.activityRewardVo.isReward}GetRankInfo(t){if(null==t)return
const e=this.GetRankTypeByActivityId(t)
if(e>0){const i=y.i.ins.rankInfoDic
if(null!=i[t])return i[t][e]}}GetMyRankInfo(t){const e=this.GetRankTypeByActivityId(t)
if(e>0&&null!=_.K.Inst_get().self_rank_info[t])return _.K.Inst_get().self_rank_info[t][e]}GetRankTypeByActivityId(t){const e=this.sevenday_huodong_ids.IndexOf(t)
return e>=0?this.rankTypeLis[e]:-1}GetRankConfigById(t){const e=this.GetRankTypeByActivityId(t)
if(e>=0&&_.K.Inst_get().rank_rewards_dict[t])return _.K.Inst_get().rank_rewards_dict[t][e]}GetRankNameByActivityId(t){const e=this.sevenday_huodong_ids.IndexOf(t)
return e>=0?this.rankNameDic[e+1]:-1}GetCurActivityId(){const t=this.sevenday_huodong_ids
let e=t[t.Count()-1]
for(let i=0;i<=t.Count()-1;i++)if(y.i.ins.GetState(t[i])==p.V.OPEN){e=t[i]
break}return e}GetCurDayActivityId(){const t=this.sevenday_huodong_ids
let e=t[t.Count()-1]
for(let i=0;i<=t.Count()-1&&y.i.ins.GetState(t[i])!=p.V.NONE;i++)e=t[i]
return e}IsNextDayById(t){const e=this.GetCurDayActivityId(),i=r.Z.IndexOf(this.sevenday_huodong_ids,e)
return!(i>=this.sevenday_huodong_ids.Count()-1)&&t==this.sevenday_huodong_ids[i+1]}}R.ins=null},84049:(t,e,i)=>{i.d(e,{K:()=>c})
var s,n=i(18998),a=i(83908),o=i(97461),l=i(16968),r=i(92679),h=i(56834),d=i(93727),u=i(79411)
let c=n._decorator.ccclass("OpenServerGrabRightItem")(s=class extends((0,a.pA)(l.E)()){constructor(...t){super(...t),this.lastRedponitState=!1}InitView(){super.InitView(),
this._curRedPointId=0,this.redPoint.SetActive(!1)}SetData(t){super.SetData(t),o.i.Inst.AddEventHandler(r.g.HUODONG_INFO_CHANGE,this.CreateDelegate(this.UpdateLock)),
o.i.Inst.AddEventHandler(r.g.OPEN_SERVER_GRAB_END,this.CreateDelegate(this.UpdateAll)),o.i.Inst.AddEventHandler(r.g.HUODONG_QUEST_CHANGE,this.CreateDelegate(this.OnQuestChange)),
null!=this.uispAni&&this.uispAni.node.SetActive(!1),this.UpdateLock(),this.UpdateFinishState()}SetSelect(t){super.SetSelect(t),
null!=this.uispAni&&(t||this.uispAni.node.SetActive(!1),this.label.textSet(this.GetTextStr()))}Clear(){super.Clear(),
o.i.Inst.RemoveEventHandler(r.g.OPEN_SERVER_GRAB_END,this.CreateDelegate(this.UpdateAll)),o.i.Inst.RemoveEventHandler(r.g.HUODONG_INFO_CHANGE,this.CreateDelegate(this.UpdateLock)),
o.i.Inst.RemoveEventHandler(r.g.HUODONG_QUEST_CHANGE,this.CreateDelegate(this.OnQuestChange))}UpdateAll(){this.UpdateLock(),this.UpdateFinishState()}OnQuestChange(){
this.isSelect&&!this.finishObj.active&&this.UpdateFinishState()}UpdateFinishState(){this.finishObj.SetActive(!1),this.exeObj.SetActive(!1),this.endObj.SetActive(!1),
null!=this.itemData.huodongId&&0!=this.itemData.huodongId&&(d.i.ins.GetState(this.itemData.huodongId)==h.V.OPEN?this.exeObj.SetActive(!0):d.i.ins.GetState(this.itemData.huodongId)==h.V.END&&this.endObj.SetActive(!0))
}UpdateLock(){this.label.textSet(this.GetTextStr()),this.img_lock.node.SetActive(!1),
null!=this.itemData.huodongId&&0!=this.itemData.huodongId&&d.i.ins.GetState(this.itemData.huodongId)==h.V.NONE&&u.J.Inst_get().IsNextDayById(this.itemData.huodongId)&&this.img_lock.node.SetActive(!0)
}GetTextStr(){let t=this.itemData.btnName
return this.isSelect||(t=`[8F6C5D]${this.itemData.btnName}[-]`),null!=this.itemData.huodongId&&0!=this.itemData.huodongId&&d.i.ins.GetState(this.itemData.huodongId)==h.V.NONE&&(u.J.Inst_get().IsNextDayById(this.itemData.huodongId)||(t="[8F6C5D]  ????[-]")),
t}PlayAni(){super.PlayAni()}})||s},49239:(t,e,i)=>{i.d(e,{k:()=>Z})
var s=i(77546),n=i(86133),a=i(38045),o=i(98800),l=i(12480),r=i(38214),h=i(97461),d=i(70241),u=i(50089),c=i(57647),_=i(68662),I=i(56937),g=i(31222),m=i(5494),C=i(98885),S=i(85602),p=i(51262),A=i(92679),f=i(37648),y=i(55492),T=i(22662),R=i(65550),v=i(12842),w=i(56834),D=i(93727),E=i(98130)
class L{constructor(){this.payNum=-1,this.isReceive=!1}FillData(t){this.payNum=E.GF.LuaJsonToNumber(t.payNum),this.isReceive=E.GF.LuaJsonToBoolean(t.isReceive)}}class G{
constructor(){this.state=null,this.msg=null,this.data=null}FillData(t){this.state=E.GF.LuaJsonToNumber(t.state),this.msg=E.GF.LuaJsonToString(t.msg),this.data=new L,
null!=t.data&&this.data.FillData(t.data)}}
var O=i(84657),b=i(9986),B=i(6665),N=i(93877),P=i(61911),M=i(60130),V=i(95721),k=i(79534),x=i(63076),H=i(75696),U=i(53905),F=i(87923),Y=i(65772),K=i(13152),z=i(20886)
class Q extends P.f{constructor(...t){super(...t),this.timeLabel=null,this.btnClose=null,this.btnGet=null,this.runebtn=null,this.rechargeLab=null,this.grid=null,
this.rechargeLab2=null,this.time=null,this.timerId=null}InitView(){super.InitView(),this.timeLabel=this.CreateComponent(N.Q,1),this.btnClose=this.CreateComponent(b.W,2),
this.btnGet=this.CreateComponent(b.W,3),this.runebtn=this.CreateComponent(b.W,4),this.rechargeLab=this.CreateComponent(N.Q,5),this.grid=this.CreateComponent(B.A,6),
this.rechargeLab2=this.CreateComponent(N.Q,7),this.grid.SetInitInfo("ui_baseitem",null,H.j)}Clear(){this.RemoveLis(),super.Clear()}Destroy(){this.timeLabel=null,this.btnClose=null,
this.btnGet=null,this.runebtn=null,this.rechargeLab=null,this.grid=null,this.rechargeLab2=null,super.Destroy()}OnAddToScene(){this.AddLis(),this.UpdateView()}UpdateView(){
this.rechargeLab.textSet(`${O.m.GetInst().rechargeNum}元`),this.rechargeLab2.UpdateAnchors()
const t=new S.Z
let e=new x.M(z.v.DIAMOND_ID)
e.count=100*O.m.GetInst().rechargeNum,e.isShowZeroNum=!0,t.Add(e),e=new x.M(886),e.count=1,e.isShowZeroNum=!0
const i=new K.X
i.rmb=V.o.FromNumber(100*O.m.GetInst().rechargeNum),i.num=1,e.serverData_set(i),t.Add(e),this.grid.data_set(t)
let s=0
const n=D.i.ins.huodong_dict.LuaDic_GetItem(v.t.TESTREBATE_RECHARGE)
null!=n&&null!=n.endTime&&n.endTime.ToNum()>0&&(s=n.endTime.ToNum()-_.D.serverMSTime_get()),this.ClearTimer(),this.time=s/1e3,
this.timerId=this.m_handlerMgr.SetInterval(this.CreateDelegate(this.DownTimerHanler),1e3),this.DownTimerHanler()}DownTimerHanler(){this.time<=0&&(this.time=0,this.ClearTimer())
this.time>=600?this.timeLabel.textSet(F.l.GetTimeInHMS(this.time,false)):this.time<=0?this.timeLabel.textSet("活动已结束"):this.timeLabel.textSet(`${F.l.txtRedStr2}${F.l.GetTimeInHMS(this.time,false)}[-]`),
this.time-=1}ClearTimer(){this.timerId&&(this.m_handlerMgr.ClearInterval(this.timerId),this.timerId=null)}RemoveLis(){}AddLis(){
this.m_handlerMgr.AddClickEvent(this.btnClose,this.CreateDelegate(this.PlayTweenClose)),this.m_handlerMgr.AddClickEvent(this.btnGet,this.CreateDelegate(this.GetHandle)),
this.m_handlerMgr.AddClickEvent(this.runebtn,this.CreateDelegate(this.TipsShowHandle))}PlayTweenClose(){
M.O.PlayNormalCloseTween(this.btnClose,this.CreateDelegate(this.CloseHandle))}CloseHandle(){Z.GetInst().CloseRechargeByTesterView()}GetHandle(){s.s.Info((0,n.T)("请求充值返利领奖")),
Z.GetInst().GetReceive()}TipsShowHandle(){const t=new U.w
t.width=450,t.position=new k.P(-108,20,0),t.infoId="RECHARGEREBATE:TIPS",Y.Q.Inst_get().Open(t)}}class Z{constructor(){this.AddLis()}static GetInst(){
return null==Z.inst&&(Z.inst=new Z),Z.inst}AddLis(){h.i.Inst.AddEventHandler(A.g.HUODONG_INFO_CHANGE,this.CreateDelegate(this.GetReChargeNum))}GetReChargeNum(t){
if(t!=v.t.TESTREBATE_RECHARGE)return
const e=D.i.ins.GetState(v.t.TESTREBATE_RECHARGE)
e!=w.V.NONE&&e!=w.V.CLOSE&&null==O.m.GetInst().jsonData&&f.P.Inst_get().IsFuncOrActivityOpened(y.x.RechargeByTester)&&this.ReqReChargeNum()}ReqReChargeNum(){
const t=o.Y.Inst.PrimaryRoleInfo_get(),e=new p.H
if(null!=t){e.Append("http://api-support.rydts.elk20.com/api/client/rydts/mainland/rebate"),e.Append("?time="),e.Append(_.D.serverTime_get()),e.Append("&account="),
e.Append(t.accountindex),e.Append("&sid="),e.Append(l.y.Instance.selectServer.serverId),e.Append("&sign=")
const i="4189a3dac3934ee3"
e.Append(c.R.GetMD5(`rydtsmainland${r.Q.Instance.uid+(l.y.Instance.selectServer.serverId+(_.D.serverTime_get()+i))}`))}const i=e.ToString()
d.Z.SendRequest(i,this.CreateDelegate(this.OnRechargeSuccess),this.CreateDelegate(this.OnRechargeError),!0)}OnRechargeSuccess(t){t=C.M.Replace(t,"\\",""),t=C.M.Replace(t,'"{',"{"),
t=C.M.Replace(t,'"}',"}")
const e=u.t.decode(t,G,!0)
null!=e&&null!=e.data&&1==e.state&&(O.m.GetInst().jsonData=e,O.m.GetInst().rechargeNum=e.data.payNum,O.m.GetInst().isReceive=e.data.isReceive)}OnRechargeError(){s.s.Info((0,
n.T)("请求充值金额失败")),O.m.GetInst().jsonData=null}GetReceive(){const t=D.i.ins.GetState(v.t.TESTREBATE_RECHARGE)
if(t==w.V.NONE||t==w.V.CLOSE)return void R.y.inst.ClientStrMsg(T.r.SystemTipMessage,"活动时间已过")
if(null==O.m.GetInst().jsonData)return void R.y.inst.ClientStrMsg(T.r.SystemTipMessage,"没有找到充值记录！")
if(!f.P.Inst_get().IsFuncOrActivityOpened(y.x.RechargeByTester))return
if(O.m.GetInst().rechargeNum<=0)return void R.y.inst.ClientStrMsg(T.r.SystemTipMessage,"没有找到充值记录")
if(O.m.GetInst().isReceive)return void R.y.inst.ClientStrMsg(T.r.SystemTipMessage,"已经领过了哦")
const e=o.Y.Inst.PrimaryRoleInfo_get()
if(null==e)return
const i=new S.Z,s=new S.Z
i.Add("time"),s.Add((0,a.tw)(_.D.serverTime_get())),i.Add("account"),s.Add((0,a.tw)(e.accountindex)),i.Add("sid"),s.Add((0,a.tw)(l.y.Instance.selectServer.serverId)),i.Add("sign")
const h=c.R.GetMD5("rydtsmainland"+r.Q.Instance.uid+l.y.Instance.selectServer.serverId+_.D.serverTime_get()+"4189a3dac3934ee3")
s.Add((0,n.T)(h)),d.Z.PostWWW("http://api-support.rydts.elk20.com/api/client/rydts/mainland/rebate",i.GetTableOrNilFromLua(),s.GetTableOrNilFromLua(),this.CreateDelegate(this.GetReceiveSuccess),this.CreateDelegate(this.GetReceiveError))
}GetReceiveSuccess(t){const e=u.t.decode(t,G,!0)
null!=e&&1==e.state&&(O.m.GetInst().isReceive=!0)}GetReceiveError(){s.s.Info((0,n.T)("请求充值返利领奖失败")),R.y.inst.ClientStrMsg(T.r.SystemTipMessage,"已经领过了哦")}OpenRechargeByTesterView(){
if(O.m.GetInst().rechargeNum<=0)return
if(O.m.GetInst().isReceive)return void R.y.inst.ClientStrMsg(T.r.SystemTipMessage,"已经领过了哦")
const t=new I.v
t.isShowMask=!0,t.viewClass=Q,g.N.inst.OpenById(m.I.RechargeByTester,null,null,t)}CloseRechargeByTesterView(){g.N.inst.CloseById(m.I.RechargeByTester)}}Z.inst=null},
84657:(t,e,i)=>{i.d(e,{m:()=>n})
var s=i(16812)
class n extends s.k{constructor(...t){super(...t),this.rechargeNum=0,this.isReceive=!1,this.jsonData=null}static GetInst(){return null==n.inst&&(n.inst=new n),n.inst}ReSetModel(){
this.rechargeNum=0,this.isReceive=!1,this.jsonData=null}}n.inst=null},76887:(t,e,i)=>{i.d(e,{$:()=>A})
var s,n,a,o=i(42292),l=i(71409),r=i(38836),h=i(97461),d=i(68662),u=i(56937),c=i(31222),_=i(5494),I=i(52726),g=i(98789),m=i(38962),C=i(92679),S=i(92415)
function p(t,e,i,s,n){var a={}
return Object.keys(s).forEach((function(t){a[t]=s[t]})),a.enumerable=!!a.enumerable,a.configurable=!!a.configurable,("value"in a||a.initializer)&&(a.writable=!0),
a=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),a),n&&void 0!==a.initializer&&(a.value=a.initializer?a.initializer.call(n):void 0,a.initializer=void 0),
void 0===a.initializer&&(Object.defineProperty(t,e,a),a=null),a}let A=(s=(0,l.GH)(S.k.SM_RidingBuyActivityInfos),a=class t{constructor(){this.CurOpenID=0,this.ridingbuy_dict=null,
this.ridingBottonName=null,this.ridingbuy_dict=new m.X,this.ridingBottonName={RIDINGBUY:!0},this.RegisterMsg()}static Inst(){return null==t._inst&&(t._inst=new t),t._inst}
RegisterMsg(){}ResetData(){this.ridingbuy_dict.Clear()}SM_RidingBuyActivityInfosHandler(t){this.ridingbuy_dict.Clear()
for(const[e,i]of(0,r.V5)(t.activityVoList))this.ridingbuy_dict.LuaDic_AddOrSetItem(i.id,i)
h.i.Inst.RaiseEvent(C.g.RIDINGBUY_ACTIVITYINFO)}GetRidingBuyVoDict(){return this.ridingbuy_dict}GetRidingBuyOpenId(){for(const[t,e]of(0,r.V5)(this.ridingbuy_dict)){const t=e
if(t.endTime.ToNum()>d.D.serverMSTime_get())return t.id}}GetRidingBuyVo(t){return this.ridingbuy_dict.LuaDic_GetItem(t)}OpenRidingBuyPanel(t){this.CurOpenID=t
const e=new u.v
e.positionType=g.$.eCustom,e.isShowMask=!0,e.isDefaultUITween=!0,e.isSelfTween=!1,e.maskAlpha=.8,c.N.inst.OpenById(_.I.RidingBuyPanel,null,null,e)}CloseRidingBuyPanel(){
c.N.inst.CloseById(_.I.RidingBuyPanel)}OpenRidingBuyShowHorsePanel(){const t=new u.v
t.positionType=g.$.eCustom,t.layerType=I.F.MainUI,t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!1,t.maskAlpha=.8,c.N.inst.OpenById(_.I.RidingBuyShowHorsePanel,null,null,t)}
CloseRidingBuyShowHorsePanel(){c.N.inst.CloseById(_.I.RidingBuyShowHorsePanel)}OpenRidingBuyTipPanel(){const t=new u.v
t.isShowMask=!0,t.isSelfTween=!1,t.maskAlpha=.8,c.N.inst.OpenById(_.I.RidingBuyTipPanel,null,null,t)}CloseRidingBuyTipPanel(){c.N.inst.CloseById(_.I.RidingBuyTipPanel)}},
a.STAGE_ID=138,a._inst=null,p(n=a,"Inst",[o.n],Object.getOwnPropertyDescriptor(n,"Inst"),n),
p(n.prototype,"SM_RidingBuyActivityInfosHandler",[s],Object.getOwnPropertyDescriptor(n.prototype,"SM_RidingBuyActivityInfosHandler"),n.prototype),n)},75310:(t,e,i)=>{
var s,n,a=i(6847),o=i(83908),l=i(49655),r=i(46282),h=i(32697),d=i(20583),u=i(50838),c=i(31546),_=i(68662),I=i(5924),g=i(20099),m=i(92679),C=i(87923),S=i(11037),p=i(51252),A=i(52513),f=i(31896),y=i(99421),T=i(76887)
;(0,a.s_)(l.o.RidingBuyPanel,r.Z.ui_ry_ridingbuy_mainpanel).waitPrefab(r.Z.ui_ry_ridingbuy_tip).waitPrefab(r.Z.ui_ry_ridingbuy_showhorsepanel).register()(((n=class extends((0,
o.Ri)()){constructor(...t){super(...t),this.ID=0,this.RewardStatus=0,this.UpdateTimer=null,this.LeftTime=0,this.Cfg=null,this.m_horse=null}static __StaticInit(){}_initBinder(){}
InitView(){}OnAddToScene(){this.Clear(),g.V.SendClickData(300002),this.ID=T.$.Inst().CurOpenID,this.Cfg=p.q.Inst().GetRidingBuyItem(this.ID),
this.m_handlerMgr.AddClickEvent(this.tipBtn,this.CreateDelegate(this.OpenTipPanel)),this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.ClosePanel)),
this.m_handlerMgr.AddClickEvent(this.buyBtn,this.CreateDelegate(this.BuyOrGetAward)),
this.m_handlerMgr.AddClickEvent(this.detailShowBtn,this.CreateDelegate(this.OpenDetailShowPanel)),
this.m_handlerMgr.AddEventMgr(m.g.RIDINGBUY_ACTIVITYINFO,this.CreateDelegate(this.RefreshInfo)),this.RefreshInfo(),this.SetModel()}ClearUpdateTimer(){
this.UpdateTimer&&(I.C.Inst_get().ClearInterval(this.UpdateTimer),this.UpdateTimer=null)}UpdateLeftTime(){this.LeftTime<0&&(this.LeftTime=0,this.ClearUpdateTimer()),
this.leftTime.textSet(C.l.GetTimeInHMS(this.LeftTime,!0)),this.LeftTime-=1}OpenTipPanel(){T.$.Inst().OpenRidingBuyTipPanel()}ClosePanel(){T.$.Inst().CloseRidingBuyPanel()}
BuyOrGetAward(){if(0==this.RewardStatus){const t=A.O.Inst().getConfig(this.Cfg.rechargeId)
g.V.SendClickData(300003),f.t.inst.Buy(t)}else 1==this.RewardStatus&&y.l.ins.CM_AcceptRidingBuyReward(this.ID)}OpenDetailShowPanel(){T.$.Inst().OpenRidingBuyShowHorsePanel()}
RefreshBuyStatus(t){this.RewardStatus=t,0==t?(this.buyBtn.node.SetActive(!0),this.hasGot.SetActive(!1),
this.price.textSet(`${this.Cfg.discount}元购买`)):1==t?(this.buyBtn.node.SetActive(!0),this.hasGot.SetActive(!1),this.price.textSet("领取")):(this.buyBtn.node.SetActive(!1),
this.hasGot.SetActive(!0))}RefreshInfo(){this.originPrice.textSet(`商城原价：${this.Cfg.price}元`),this.price.textSet(`${this.Cfg.discount}元购买`),this.ClearUpdateTimer()
const t=T.$.Inst().GetRidingBuyVo(this.ID),e=t&&t.endTime.ToNum()-_.D.serverMSTime_get()||0
this.LeftTime=e/1e3,this.UpdateTimer=I.C.Inst_get().SetInterval(this.CreateDelegate(this.UpdateLeftTime),1e3,-1),this.UpdateLeftTime(),
t?0==t.rewardStatus?this.RefreshBuyStatus(0):1==t.rewardStatus&&this.RefreshBuyStatus(1):this.RefreshBuyStatus(2)}SetModel(){this.m_horse=new u.o,
this.m_horse.SetTarget(this.modelTexture.node,!0),this.m_horse.setUpDragNode(this.modelTexture.node)
const t=p.q.Inst().GetRidingBuyItem(this.ID),e=S.D.GetInst().GetCfg(t&&t.ridingId||-1)
if(!e)return
const i=new c.O
i._displayID=e.modelId,this.m_horse.SetScale(1,1),d.x.inst.SetUIAvatarData(i._displayID,h.v.horse,this.m_horse)}Clear(){super.Clear(),null!=this.m_horse&&(this.m_horse=null),
this.ClearUpdateTimer(),this.ID=0,this.Cfg=null}Destroy(){}Test1(){return!0}S_Test(){return!0}}).STAGE_ID=137,s=n))},83863:(t,e,i)=>{
var s,n,a=i(6847),o=i(83908),l=i(49655),r=i(46282),h=i(38836),d=i(32697),u=i(20583),c=i(50838),_=i(31546),I=i(70650),g=i(73206),m=i(5924),C=i(61911),S=i(85602),p=i(38962),A=i(92679),f=i(87923),y=i(33833),T=i(11037),R=i(51252),v=i(76887),w=i(97461),D=i(70829),E=i(79534),L=i(64501)
class G extends((0,o.Ri)()){constructor(...t){super(...t),this.skillCfg=null,this.skillId=0}InitView(){super.InitView()}SetData(t){
const e=`${t}_1`,i=D.j.Inst().GetSkillByStrId(e,!1)
this.skillCfg=i,this.skillId=t,this.skillIcon.skin="WEB:/icon/skill/"+i.skillicon+".png",this.name.textSet(i.name),this.level.textSet(""),
this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.OnClickItem))}OnClickItem(){const t=new E.P(270,100,0)
L.B.inst.ShowSkillTipsByPos(this.skillCfg,t,null,0,!1),w.i.Inst.RaiseEvent(A.g.RIDINGBUY_SKILLEFFECT,this.skillId)}Clear(){super.Clear()}Destroy(){}Test1(){return!0}S_Test(){
return!0}}(0,a.s_)(l.o.RidingBuyShowHorsePanel,r.Z.ui_ry_ridingbuy_showhorsepanel).register()(((n=class extends((0,o.pA)(C.f)()){constructor(...t){super(...t),this.ID=0,
this.Cfg=null,this.roleRotateIndex=0,this.SkillToElementId=null,this.skillElementId=null,this.playElementTimer=null,this._degf_HorseInitHandler=null,this.m_horse=null}
_initBinder(){super._initBinder(),this.SkillToElementId=new p.X}InitView(){this.MyGrid.SetInitInfo("ui_ry_ridingbuy_skillitem",null,G,this.CreateDelegate(this.ClickSkillItem)),
this._degf_HorseInitHandler=t=>this.HorseInitHandler(t)}OnAddToScene(){this.ID=v.$.Inst().CurOpenID,this.Cfg=R.q.Inst().GetRidingBuyItem(this.ID),this.SetModel(),this.SetAttr(),
this.SetSkillList(),this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.ClosePanel)),
this.m_handlerMgr.AddClickEvent(this.backBtn,this.CreateDelegate(this.ClosePanel)),this.m_handlerMgr.AddEventMgr(A.g.RIDINGBUY_SKILLEFFECT,this.CreateDelegate(this.PlaySkillAnim)),
this.m_handlerMgr.AddEventMgr(A.g.SKILLTIP_CLOSE,this.CreateDelegate(this.PlaySkillAnim))}ClosePanel(){v.$.Inst().CloseRidingBuyShowHorsePanel()}ClickSkillItem(t,e,i){}SetModel(){
this.m_horse=new c.o,this.m_horse.SetTarget(this.modelTexture.node,!0),this.m_horse.setUpDragNode(this.modelTexture.node)
const t=R.q.Inst().GetRidingBuyItem(this.ID),e=T.D.GetInst().GetCfg(t&&t.ridingId||-1)
if(!e)return
const i=new _.O
i._displayID=e.modelId,this.m_horse.SetScale(1,1),u.x.inst.SetUIAvatarData(i._displayID,d.v.horse,this.m_horse)}SetAttr(){
const t=T.D.GetInst().GetCfg(this.Cfg.ridingId),e=t.horseAttrsex.typevalues
let i=null,s=null,n=0,a=""
for(let t=0;t<=e.Count()-1;t++)i=e[t],n=Number(i.value),s=y.X.Inst().getItemByName(i.type),a=f.l.getAttrValueStr(s.id,n),
"MaxHp"==i.type?this.lifeValue.textSet(a):"Attack"==i.type?this.attackValue.textSet(a):"Defense"==i.type&&this.defLabel.textSet(a)
this.speedValue.textSet(t.speed.toString())}SetSkillList(){const t=new S.Z,e=this.Cfg.skillId,i=this.Cfg.skillElementList
for(const[s,n]of(0,h.X)(e))t.Add(n),this.SkillToElementId.LuaDic_AddOrSetItem(n,i[s])
this.MyGrid.data_set(t)}HorseInitHandler(t){}PlaySkillAnim(t){}PlaySkillElement(t,e){}ClearSkillElement(){this.skillElementId&&(g.X.Inst.DeleteElement(this.skillElementId),
this.skillElementId=null),this.playElementTimer&&(m.C.Inst_get().ClearInterval(this.playElementTimer),this.playElementTimer=null)}Clear(){
0!=this.roleRotateIndex&&(I.e.GetInst().UnregDrag(this.roleRotateIndex),this.roleRotateIndex=0),this.ID=0,this.Cfg=null,this.ClearSkillElement(),super.Clear()}Destroy(){}Test1(){
return!0}S_Test(){return!0}}).STAGE_ID=138,s=n))},63948:(t,e,i)=>{var s,n=i(6847),a=i(83908),o=i(49655),l=i(46282),r=i(61911),h=i(51252),d=i(76887);(0,
n.s_)(o.o.RidingBuyTipPanel,l.Z.ui_ry_ridingbuy_tip).register()(s=class extends((0,a.pA)(r.f)()){_initBinder(){}InitView(){}OnAddToScene(){
const t=d.$.Inst().CurOpenID,e=h.q.Inst().GetRidingBuyItem(t)
this.content.textSet(e.ridingStory),this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.ClosePanel))}ClosePanel(){d.$.Inst().CloseRidingBuyTipPanel()}Clear(){
super.Clear()}Destroy(){}Test1(){return!0}S_Test(){return!0}})},10231:(t,e,i)=>{i.d(e,{P:()=>R})
var s,n,a,o=i(42292),l=i(71409),r=i(17409),h=i(97461),d=i(38935),u=i(56937),c=i(31222),_=i(5494),I=i(28192),g=i(92679),m=i(37648),C=i(55492),S=i(61519),p=i(92415),A=i(92260),f=i(99421),y=i(24810)
function T(t,e,i,s,n){var a={}
return Object.keys(s).forEach((function(t){a[t]=s[t]})),a.enumerable=!!a.enumerable,a.configurable=!!a.configurable,("value"in a||a.initializer)&&(a.writable=!0),
a=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),a),n&&void 0!==a.initializer&&(a.value=a.initializer?a.initializer.call(n):void 0,a.initializer=void 0),
void 0===a.initializer&&(Object.defineProperty(t,e,a),a=null),a}let R=(s=(0,l.GH)(p.k.SM_QueryFirstPassMapName),a=class t{static get ins(){return null==t._ins&&(t._ins=new t),
t._ins}constructor(){this.panel=null,this.rank_reward_panel=null,this.m_handlerMgr=null,this.InitHandlerMgr(),this.AddLis()}InitHandlerMgr(){
return null==this.m_handlerMgr&&(this.m_handlerMgr=I.h.Get()),this.m_handlerMgr}AddLis(){}SM_QueryFirstPassMapName(t){h.i.Inst.RaiseEvent(g.g.QUERY_FIRST_PASS_MAP_NAME,t)}
CM_QueryFirstPassMapName(t){const e=new S.I
e.passMapPoint=t,d.C.Inst.F_SendMsg(e)}OnClickFuncItem(t){t==C.x.SEVEN_DAY&&this.OpenPanel()}OpenPanel(){if(!m.P.Inst_get().IsFunctionOpened(C.x.SEVEN_DAY))return
if(null!=this.panel&&this.panel.isShow_get())return
A.r.Inst_get().RegMsgUID(-11665,-11666,_.I.eSevenDayPanel,y.K.ins.sevenday_huodong_ids[0],y.K.ins.sevenday_huodong_ids[0],"开服活动加载中..."),
f.l.ins.CM_OpenActivityPanel(y.K.ins.sevenday_huodong_ids[0])
const t=new u.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!1,(0,r.Yp)(_.I.eSevenDayPanel,t)}ClosePanel(){c.N.inst.CloseById(_.I.eSevenDayPanel)}OpenRankRewardPanel(){
if(null!=this.rank_reward_panel&&this.rank_reward_panel.isShow_get())return
const t=new u.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!1,(0,r.Yp)(_.I.eSevenDayRankRewardPanel,t)}CloseRankRewardPanel(){(0,r.sR)(_.I.eSevenDayRankRewardPanel)}},a._ins=null,
T(n=a,"ins",[o.n],Object.getOwnPropertyDescriptor(n,"ins"),n),
T(n.prototype,"SM_QueryFirstPassMapName",[s],Object.getOwnPropertyDescriptor(n.prototype,"SM_QueryFirstPassMapName"),n.prototype),n)},24810:(t,e,i)=>{i.d(e,{K:()=>L})
var s,n,a=i(42292),o=i(32076),l=i(38836),r=i(97461),h=i(68662),d=i(5924),u=i(60130),c=i(98885),_=i(85602),I=i(92679),g=i(75439),m=i(35037),C=i(33996),S=i(8211),p=i(56828),A=i(47174),f=i(14792),y=i(62734),T=i(12842),R=i(56834),v=i(23649),w=i(69622),D=i(93727),E=i(38962)
let L=(n=class t{static get ins(){return null==t._ins&&(t._ins=new t),t._ins}constructor(){this.select_huodong_id=0,this.sevenday_red_ids=null,this.sevenday_huodong_ids=null,
this.rank_red_interval=null,
this.day0Access=null,this.redIdDic=null,this.sevenday_huodong_ids=new _.Z([T.t.SEVEN_DAY_2,T.t.SEVEN_DAY_3,T.t.SEVEN_DAY_4,T.t.SEVEN_DAY_5,T.t.SEVEN_DAY_6,T.t.SEVEN_DAY_7,T.t.SEVEN_DAY_8]),
this.InitRed(),this.AddLis()}AddLis(){r.i.Inst.AddEventHandler(I.g.HUODONG_INFO_CHANGE,(0,o.v)(this.OnHuoDongChange,this)),r.i.Inst.AddEventHandler(I.g.RANK_DAILY_REWARD,(0,
o.v)(this.OnRankDailyReward,this)),r.i.Inst.AddEventHandler(I.g.RANK_DAILY_REWARD_CONFIG,(0,o.v)(this.OnRankDailyReward,this)),S.N.GetInst().AddEventHandler(C.G.GET_MALLS,(0,
o.v)(this.CheckRed,this))}GetOpeningId(){const t=u.O.GetSelectedIndex(-1,this.sevenday_red_ids),e=D.i.ins.GetState(this.sevenday_huodong_ids[t])
if(e==R.V.OPEN||e==R.V.END)return this.sevenday_huodong_ids[t]
for(let t=0;t<=this.sevenday_huodong_ids.Count()-1;t++)if(D.i.ins.GetState(this.sevenday_huodong_ids[t])==R.V.OPEN)return this.sevenday_huodong_ids[t]
return 0}GetOpeningDayIndex(){for(let t=0;t<=this.sevenday_huodong_ids.Count()-1;t++)if(D.i.ins.GetState(this.sevenday_huodong_ids[t])==R.V.OPEN)return t
return 0}CheckRed(){d.C.Inst_get().CallLater((0,o.v)(this.OnCheckRed,this))}OnCheckRed(){for(let t=0;t<=this.sevenday_huodong_ids.Count()-1;t++){
const e=this.sevenday_huodong_ids[t]
this._checkActivityRedPoint(e)}this._checkActivityRedPoint(T.t.SEVEN_DAY_1),this._checkActivityRedPoint(1059),this.OnRankDailyReward()}_checkActivityRedPoint(t){
const e=w.J.ins.GetTargetTypesByHuoDongId(t)
for(let i=0;i<=e.Count()-1;i++){const s=this.GetRedPointName(t,e[i])
y.f.Inst.SetState(s,!1)
const n=w.J.ins.GetQuestListVoByIdAndTargetType(t,e[i])
for(const[t,a]of(0,l.V5)(n)){const t=D.i.ins.GetQuestVo(a.id)
if(null!=t&&!t.activityRewardVo.isReward){if(v.h.MALL_BUY==e[i]){
const e=c.M.String2Int(w.J.ins.GetQuestVoById(t.taskId).TargetDefs_Get().tCTargetDefs[0].param.mallId),i=S.N.GetInst().GetInfo(e)
if(null!=i&&i.Lastnum_get()>=i.GetBuyLimit())break}else{let e=!0
for(const[i,s]of(0,l.V5)(t.targetVos))if(s.curValue.ToNum()<s.targetValue.ToNum()){e=!1
break}if(e){y.f.Inst.SetState(s,!0)
break}}if(v.h.MALL_BUY==e[i]){const e=c.M.String2Int(w.J.ins.GetQuestVoById(t.taskId).TargetDefs_Get().tCTargetDefs[0].param.mallId),i=m.L.GetInst().GetCfgById(e)
if(0==i.GetPrice()){const t=S.N.GetInst().GetInfo(i.id)
if(null!=t&&t.RemainNum_get()>0){y.f.Inst.SetState(s,!0)
break}}}}}}}CheckRankRed(){d.C.Inst_get().CallLater((0,o.v)(this.OnCheckRankRed,this))}OnCheckRankRed(){let t=0
if(null!=p.K.Inst_get().self_rank_value[T.t.SEVEN_DAY_RANK]&&(t=p.K.Inst_get().self_rank_value[T.t.SEVEN_DAY_RANK][A.c.SEVENDAY]),y.f.Inst.SetState(f.t.SEVEN_DAY_RANK_DAILY,!1),
0==t||null==t)return!1
if(D.i.ins.GetState(T.t.SEVEN_DAY_RANK)!=R.V.OPEN)return!1
const e=p.K.Inst_get().daily_reward_dict.LuaDic_GetItem(A.c.SEVENDAY),i=p.K.Inst_get().daily_reward_config_dict.LuaDic_GetItem(A.c.SEVENDAY)
return null!=e&&null!=i&&(!(h.D.serverMSTime_get()>=e.nextRewardTime.ToNum()&&e.restTimes<i.totalCount)||(y.f.Inst.SetState(f.t.SEVEN_DAY_RANK_DAILY,!0),!0))}InitRed(){
this.redIdDic=new E.X,this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_1_1",f.t.SEVEN_DAY_1_1),this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_1",f.t.SEVEN_DAY_1),
this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_2",f.t.SEVEN_DAY_2),this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_3",f.t.SEVEN_DAY_3),
this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_4",f.t.SEVEN_DAY_4),this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_5",f.t.SEVEN_DAY_5),
this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_6",f.t.SEVEN_DAY_6),this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_7",f.t.SEVEN_DAY_7),
this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_8",f.t.SEVEN_DAY_8),this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_RANK_DAILY",f.t.SEVEN_DAY_RANK_DAILY),
this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_QUEST",f.t.SEVEN_DAY_QUEST),this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_RANK",f.t.SEVEN_DAY_RANK),
this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_1051_26",f.t.SEVEN_DAY_1051_26),this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_1052_5",f.t.SEVEN_DAY_1052_5),
this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_1052_1",f.t.SEVEN_DAY_1052_1),this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_1052_12",f.t.SEVEN_DAY_1052_12),
this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_1052_6",f.t.SEVEN_DAY_1052_6),this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_1053_5",f.t.SEVEN_DAY_1053_5),
this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_1053_2",f.t.SEVEN_DAY_1053_2),this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_1053_3",f.t.SEVEN_DAY_1053_3),
this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_1054_5",f.t.SEVEN_DAY_1054_5),this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_1054_7",f.t.SEVEN_DAY_1054_7),
this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_1054_14",f.t.SEVEN_DAY_1054_14),this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_1055_5",f.t.SEVEN_DAY_1055_5),
this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_1055_22",f.t.SEVEN_DAY_1055_22),this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_1055_21",f.t.SEVEN_DAY_1055_21),
this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_1056_5",f.t.SEVEN_DAY_1056_5),this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_1056_7",f.t.SEVEN_DAY_1056_7),
this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_1056_8",f.t.SEVEN_DAY_1056_8),this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_1057_5",f.t.SEVEN_DAY_1057_5),
this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_1057_10",f.t.SEVEN_DAY_1057_10),this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_1057_15",f.t.SEVEN_DAY_1057_15),
this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_1058_5",f.t.SEVEN_DAY_1058_5),this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_1058_4",f.t.SEVEN_DAY_1058_4),
this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_1058_13",f.t.SEVEN_DAY_1058_13),this.redIdDic.LuaDic_AddOrSetItem("SEVEN_DAY_1059_28",f.t.SEVEN_DAY_1059_28)
const t=new _.Z
t.Clear(),t.Add(f.t.SEVEN_DAY),y.f.Inst.AddNode(this.redIdDic.SEVEN_DAY_QUEST,t,!1,!1),t.Clear(),t.Add(f.t.SEVEN_DAY),y.f.Inst.AddNode(this.redIdDic.SEVEN_DAY_RANK,t,!1,!1),
t.Clear(),t.Add(f.t.SEVEN_DAY_RANK),y.f.Inst.AddNode(this.redIdDic.SEVEN_DAY_RANK_DAILY,t,!1,!1),this.sevenday_red_ids=new _.Z
for(let e=1;e<=this.sevenday_huodong_ids.Count();e++){t.Clear(),t.Add(f.t.SEVEN_DAY_QUEST)
const i=`SEVEN_DAY_${e}`
this.sevenday_red_ids.Add(this.redIdDic[i]),y.f.Inst.AddNode(this.redIdDic[i],t,!1,!1)
const s=this.sevenday_huodong_ids[e-1]
this._CreateActivityRedPointId(this.redIdDic[i],s)}t.Clear(),t.Add(f.t.SEVEN_DAY),y.f.Inst.AddNode(this.redIdDic.SEVEN_DAY_1_1,t,!1,!1),
this._CreateActivityRedPointId(f.t.SEVEN_DAY_1_1,T.t.SEVEN_DAY_1),this._CreateActivityRedPointId(f.t.SEVEN_DAY_1_1,1059)}_CreateActivityRedPointId(t,e){
const i=w.J.ins.target_type_dict.LuaDic_GetItem(e),s=new _.Z
s.Add(t)
for(let t=0;t<=i.Count()-1;t++){const n=this.GetRedPointName(e,i[t])
y.f.Inst.AddNode(n,s,!1,!1)}}GetRedPointName(t,e){
return this.redIdDic.LuaDic_GetItem(`SEVEN_DAY_${t}_${e}`)?this.redIdDic.LuaDic_GetItem(`SEVEN_DAY_${t}_${e}`):(console.error(`缺少红点枚举类型----： SEVEN_DAY_${t}_${e}`),null)}
OnHuoDongChange(){D.i.ins.GetState(T.t.SEVEN_DAY_RANK)==R.V.OPEN?this.rank_red_interval=d.C.Inst_get().SetInterval((0,
o.v)(this.OnCheckRankRed,this),1e3):null!=this.rank_red_interval&&(this.OnCheckRankRed(),d.C.Inst_get().ClearInterval(this.rank_red_interval),this.rank_red_interval=null)}
GetDay0Access(){return null==this.day0Access&&(this.day0Access=g.D.getInstance().GetStringValue("SEVEN_DAY:ACCESS")),this.day0Access}OnRankDailyReward(){
const t=p.K.Inst_get().daily_reward_dict.LuaDic_GetItem(A.c.SEVENDAY),e=p.K.Inst_get().daily_reward_config_dict.LuaDic_GetItem(A.c.SEVENDAY)
let i=0
null!=p.K.Inst_get().self_rank_value[T.t.SEVEN_DAY_RANK]&&(i=p.K.Inst_get().self_rank_value[T.t.SEVEN_DAY_RANK][A.c.SEVENDAY]),
D.i.ins.GetState(T.t.SEVEN_DAY_RANK)==R.V.OPEN?null!=e&&null!=t&&y.f.Inst.SetState(f.t.SEVEN_DAY_RANK,null!=i&&0!=i&&h.D.serverMSTime_get()>=t.nextRewardTime.ToNum()&&t.restTimes<e.totalCount):y.f.Inst.SetState(f.t.SEVEN_DAY_RANK,!1)
}IsActivityTaskFinish(t){const e=w.J.ins.GetQuestVoById(t.taskId),i=c.M.String2Int(e.TargetDefs_Get().tCTargetDefs[0].param.mallId)
if(i&&i>0){const t=S.N.GetInst().GetInfo(i)
if(t)return t.Lastnum_get()>=t.GetBuyLimit()}return t.activityRewardVo.isReward}},n._ins=null,G=s=n,O="ins",b=[a.n],B=Object.getOwnPropertyDescriptor(s,"ins"),N=s,P={},
Object.keys(B).forEach((function(t){P[t]=B[t]})),P.enumerable=!!P.enumerable,P.configurable=!!P.configurable,("value"in P||P.initializer)&&(P.writable=!0),
P=b.slice().reverse().reduce((function(t,e){return e(G,O,t)||t}),P),N&&void 0!==P.initializer&&(P.value=P.initializer?P.initializer.call(N):void 0,P.initializer=void 0),
void 0===P.initializer&&(Object.defineProperty(G,O,P),P=null),s)
var G,O,b,B,N,P},43977:(t,e,i)=>{i.d(e,{q:()=>u})
var s,n=i(18998),a=i(83908),o=i(97461),l=i(16968),r=i(92679),h=i(56834),d=i(93727)
let u=n._decorator.ccclass("SevenDayBottomItem")(s=class extends((0,a.pA)(l.E)()){constructor(...t){super(...t),this.width=null,this.offsetX=null}InitView(){super.InitView(),
this._curRedPointId=0,this.redPoint.SetActive(!1),this.width=108,this.offsetX=0,null!=this.uispAni&&this.uispAni.node.SetActive(!1)}SetData(t){super.SetData(t),
o.i.Inst.AddEventHandler(r.g.HUODONG_INFO_CHANGE,this.CreateDelegate(this.UpdateLock)),this.label.node.SetActive(!0),this.label.textSet(this.itemData.btnName),
this.bg1.node.SetActive(!0),this.UpdateLock()}Clear(){o.i.Inst.RemoveEventHandler(r.g.HUODONG_INFO_CHANGE,this.CreateDelegate(this.UpdateLock)),super.Clear()}SetBgWidth(t){
this.offsetX=t-this.width,this.width=t,this.bg1.widthSet(this.width),this.line.widthSet(this.width)}UpdateLock(){
null!=this.itemData.huodongId&&0!=this.itemData.huodongId&&d.i.ins.GetState(this.itemData.huodongId)==h.V.NONE?(this.img_lock.node.SetActive(!0),
this.label.node.transform.SetLocalPositionXYZ(63,-23.74,0)):(this.img_lock.node.SetActive(!1),this.label.node.transform.SetLocalPositionXYZ(53,-23.74,0))}SetSelect(t){
super.SetSelect(t),t?(this.bg1.node.SetActive(!0),this.label.textSet(`[3C1515]${this.itemData.btnName}[-]`)):(this.bg1.node.SetActive(!1),
this.label.textSet(`[FCEAB7]${this.itemData.btnName}[-]`)),null!=this.uispAni&&(t||this.uispAni.node.SetActive(!1))}PlayAni(){super.PlayAni(),
null!=this.uispAni&&this.uispAni.node.SetActive(!0)}})||s},70164:(t,e,i)=>{i.d(e,{o:()=>I})
var s,n=i(18998),a=i(83908),o=i(9057),l=i(63076),r=i(67885),h=i(18152),d=i(99421),u=i(23649),c=i(69622),_=i(93727)
let I=n._decorator.ccclass("SevenDayDailyItem")(s=class extends((0,a.pA)(o.x)()){constructor(...t){super(...t),this.huodongQuestVo=null,this.targetVo=null,this.rewardVo=null}
SetData(t){this.AddLis(),this.huodongQuestVo=t,this.targetVo=this.huodongQuestVo.targetVos[0],this.rewardVo=this.huodongQuestVo.activityRewardVo,this.UpdatePanel()}AddLis(){
this.ui_baseitem.ClickHandler_Set(this.CreateDelegate(this.OnClick))}RemoveLis(){this.ui_baseitem.ClickHandler_Set(null)}Clear(){this.ui_baseitem.Clear(),super.Clear(),
this.RemoveLis()}UpdatePanel(){this.img_had_get_0.node.SetActive(!1),this.img_can_get.node.SetActive(!1),this.lastestBg.SetActive(!1)
const t=l.M.wrapReward(this.rewardVo.reward.rewards[0])
t.IconType_Set(h.s.BASE_ICON_REWARD_TYPE),this.rewardVo.isReward?(this.img_had_get_0.node.SetActive(!0),
t.iconExtraData[r.S.GRAY_IMG]="已领取"):this.targetVo.curValue.ToNum()>=this.targetVo.targetValue.ToNum()&&(this.img_can_get.node.SetActive(!0),t.iconExtraData[r.S.GRAY_IMG]=null),
this.ui_baseitem.SetData(t),this.ui_baseitem._HideComponent(r.S.GRAY_IMG),this.ui_baseitem.EnabledClickOpenTip(!1),this.text_point.textSet(this.targetVo.targetValue.ToNum()+"")
const e=_.i.ins.GetQuestListVoByTargetType(u.h.ACTIVITY_SCORE)
this.index==e.Count()-1&&this.lastestBg.SetActive(!0)}OnClick(){
this.targetVo.curValue.ToNum()>=this.targetVo.targetValue.ToNum()&&!this.rewardVo.isReward?d.l.ins.CM_GainActivitytaskReward(c.J.ins.GetQuestVoById(this.huodongQuestVo.taskId).activityId,this.huodongQuestVo.taskId):this.ui_baseitem.OpenTipView()
}})||s},35135:(t,e,i)=>{i.d(e,{G:()=>f})
var s,n=i(18998),a=i(83908),o=i(86133),l=i(97461),r=i(62370),h=i(9057),d=i(61613),u=i(98885),c=i(70850),_=i(63076),I=i(18152),g=i(92679),m=i(35037),C=i(48481),S=i(63945),p=i(8211),A=i(69622)
let f=n._decorator.ccclass("SevenDayMallItem")(s=class extends((0,a.pA)(h.x)()){constructor(...t){super(...t),this.mallVo=null}InitView(){super.InitView()
const t=d.v.GetAdaptionWidth(900,1177)
this.img_bg.widthSet(t),d.v.SetAdaptionPos(this.right,900,1177,0),d.v.SetAdaptionPos(this.mid,0,140,0)}SetData(t){this.AddLis()
const e=u.M.String2Int(A.J.ins.GetQuestVoById(t.taskId).TargetDefs_Get().tCTargetDefs[0].param.mallId)
this.mallVo=m.L.GetInst().GetCfgById(e),this.UpdatePanel()}AddLis(){this.m_handlerMgr.AddClickEvent(this.btn_buy,this.CreateDelegate(this.OnClickBtnBuy))}RemoveLis(){
l.i.Inst.RemoveEventHandler(g.g.TipsLoadCompelete,this.CreateDelegate(this.OnTipsLoaded))}Clear(){super.Clear(),this.RemoveLis()}Destroy(){super.Destroy()}UpdatePanel(){
const t=p.N.GetInst().GetInfo(this.mallVo.id)
this.text_name.textSet(c.g.Inst_get().getItemresource(this.mallVo.itemId).name),this.btn_buy.node.SetActive(!1),this.img_had_buy.node.SetActive(!1),
this.text_price_now.textSet(this.mallVo.GetPrice()+""),this.text_price_orign.textSet(this.mallVo.GetOrginPrice()+""),
0==this.mallVo.GetPrice()?this.btnLabel.textSet("免费领取"):this.btnLabel.textSet("购 买"),t.Lastnum_get()>=t.GetBuyLimit()?(this.img_had_buy.node.SetActive(!0),
this.text_limit_num.node.SetActive(!1)):(this.btn_buy.node.SetActive(!0),this.text_limit_num.node.SetActive(!0),this.text_limit_num.textSet(`购买目标[047104]${r.o.Format((0,
o.T)("{0}/{1}"),t.Lastnum_get(),t.GetBuyLimit())}[-]`))
const e=new C.t
e.modelId=this.mallVo.itemId,e.num=this.mallVo.num
const i=new _.M(this.mallVo.itemId,e)
i.IconType_Set(I.s.BASE_ICON_MALL_TYPE),i.iconExtraData=this.mallVo.id,i.isMarketItem=!0,i.isShowZeroNum=!0,this.ui_baseitem.SetData(i)}OnClickBtnBuy(){
0==this.mallVo.GetPrice()?S.x.inst.ReqBuyMallItem(this.mallVo.id,1,!1):(l.i.Inst.AddEventHandler(g.g.TipsLoadCompelete,this.CreateDelegate(this.OnTipsLoaded)),
this.ui_baseitem.OpenTipView())}OnTipsLoaded(){l.i.Inst.RemoveEventHandler(g.g.TipsLoadCompelete,this.CreateDelegate(this.OnTipsLoaded))
const t=p.N.GetInst().GetInfo(this.mallVo.id)
S.x.inst.OpenMarketMallBuyTip(t,S.x.BuyTipPos)}})||s},86551:(t,e,i)=>{i.d(e,{$:()=>c})
var s,n,a=i(18998),o=i(83908),l=i(38836),r=i(9057),h=i(62734),d=i(93727),u=i(24810)
let c=a._decorator.ccclass("SevenDayQuestBtnItem")((n=class t extends((0,o.pA)(r.x)()){constructor(...t){super(...t),this.clickHandler=null,this.data=null,this.redId=null}
InitView(){super.InitView()}SetData(t){
this.data&&null!=this.data.activityId&&h.f.Inst.RemoveCallback(u.K.ins.GetRedPointName(this.data.activityId,this.data.targetType),this.CreateDelegate(this._OnRedPointUpdate)),
this.data=t,this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.OnClickItem)),this.text_tab_0.textSet(t.typeName),
this.redId=u.K.ins.GetRedPointName(this.data.activityId,this.data.targetType),
null!=this.data.activityId&&h.f.Inst.AddCallback(this.redId,this.CreateDelegate(this._OnRedPointUpdate)),this.UpdateRedPoint(),this.UpdateFinish()}_OnRedPointUpdate(){
this.UpdateRedPoint(),this.UpdateFinish()}UpdateRedPoint(){this.img_red_0.SetActive(h.f.Inst.GetData(this.redId).show)}UpdateFinish(){let t=!0
const e=d.i.ins.GetQuestListVoByIdAndTargetType(this.data.activityId,this.data.targetType)
for(const[i,s]of(0,l.V5)(e))if(!u.K.ins.IsActivityTaskFinish(s)){t=!1
break}this.img_finish_0.SetActive(t)}OnClickItem(){this.SetSelect(!0),null!=this.clickHandler&&this.clickHandler(this.data)}SetSelect(e){
e?(null!=t._CurrentSelect&&t._CurrentSelect.SetSelect(!1),t._CurrentSelect=this,this.img_tab_0.spriteFrame=this.ui_sevenday_quest_tabbtn_item.pressedSprite,
this.ui_sevenday_quest_tabbtn_item.SetIsEnabled(!1)):(this.img_tab_0.spriteFrame=this.ui_sevenday_quest_tabbtn_item.normalSprite,
this.ui_sevenday_quest_tabbtn_item.SetIsEnabled(!0))}Clear(){null!=this.data.activityId&&h.f.Inst.RemoveCallback(this.redId,this.CreateDelegate(this._OnRedPointUpdate)),
this.m_handlerMgr.RemoveClickEvent(this.node,this.CreateDelegate(this.OnClickItem)),t._CurrentSelect=null,super.Clear()}Test1(){return!0}S_Test(){return!0}},n._CurrentSelect=null,
s=n))||s},36408:(t,e,i)=>{i.d(e,{R:()=>p})
var s,n=i(18998),a=i(83908),o=i(86133),l=i(62370),r=i(9057),h=i(61613),d=i(85602),u=i(63076),c=i(75696),_=i(92679),I=i(87923),g=i(79878),m=i(83434),C=i(99421),S=i(69622)
let p=n._decorator.ccclass("SevenDayQuestItem")(s=class extends((0,a.pA)(r.x)()){constructor(...t){super(...t),this.huodongQuestVo=null,this.targetVo=null,this.rewardVo=null,
this.huodongCfgVo=null,this.flyLinkInfo=null,this.getHandler=null,this.hasIntegral=!1,this.integralItemIndex=-1}InitView(){super.InitView(),
this.grid_item.SetInitInfo("ui_baseitem",null,c.j)}SetAdapt1(){const t=h.v.GetAdaptionWidth(505,645)
this.img_bg.widthSet(t),h.v.SetAdaptionPos(this.right,506,645,0)}SetAdapt2(){const t=h.v.GetAdaptionWidth(900,1177)
this.img_bg.widthSet(t),h.v.SetAdaptionPos(this.right,900,1177,0),h.v.SetAdaptionPos(this.mid,0,90,0)}SetData(t){this.huodongQuestVo=t,
this.targetVo=this.huodongQuestVo.targetVos[0],this.rewardVo=this.huodongQuestVo.activityRewardVo,this.huodongCfgVo=S.J.ins.GetQuestVoById(this.huodongQuestVo.taskId),
this.UpdatePanel(),this.AddLis(),this.SetAdapt1()}AddLis(){this.m_handlerMgr.AddClickEvent(this.btn_get,this.CreateDelegate(this.OnClickBtnGet)),
this.m_handlerMgr.AddClickEvent(this.btn_go,this.CreateDelegate(this.OnClickBtnGo)),this.m_handlerMgr.AddEventMgr(_.g.HUODONG_QUEST_CHANGE,this.CreateDelegate(this.UpdatePanel))}
RemoveLis(){this.m_handlerMgr.RemoveClickEvent(this.btn_get,this.CreateDelegate(this.OnClickBtnGet)),
this.m_handlerMgr.RemoveClickEvent(this.btn_go,this.CreateDelegate(this.OnClickBtnGo)),
this.m_handlerMgr.RemoveEventMgr(_.g.HUODONG_QUEST_CHANGE,this.CreateDelegate(this.UpdatePanel))}Clear(){super.Clear(),this.RemoveLis(),
null!=this.flyLinkInfo&&(this.flyLinkInfo.Clear(),this.flyLinkInfo=null)}Destroy(){this.getHandler=null,super.Destroy()}UpdatePanel(){
this.flyLinkInfo=m.f.GetLinkInfo(new d.Z([this.huodongCfgVo.targetText]),this.huodongCfgVo.TargetDefs_Get(),this.huodongQuestVo.targetVos),
this.text_name.textSet(this.flyLinkInfo.GetTxtLabel()),this.btn_get.node.SetActive(!1),this.btn_go.node.SetActive(!1),this.img_get.node.SetActive(!1),
this.text_progress.node.SetActive(!1),this.rewardVo.isReward?this.img_get.node.SetActive(!0):(this.text_progress.node.SetActive(!0),
this.targetVo.curValue.ToNum()>=this.targetVo.targetValue.ToNum()?this.btn_get.node.SetActive(!0):this.btn_go.node.SetActive(!0)),
this.text_progress.textSet(`目标进度[047104]${l.o.Format((0,
o.T)("{0}/{1}"),I.l.GetRuleDecimalVal(this.targetVo.curValue.ToNum()),I.l.GetRuleDecimalVal(this.targetVo.targetValue.ToNum()))}[-]`),this.hasIntegral=!1
const t=new d.Z
for(let e=0;e<=this.rewardVo.reward.rewards.Count()-1;e++){const i=u.M.wrapReward(this.rewardVo.reward.rewards[e])
t.Add(i),10211==i.modelId_get()&&(this.integralItemIndex=e,this.hasIntegral=!0)}this.grid_item.data_set(t)}OnClickBtnGet(){
this.rewardVo.isReward||this.targetVo.curValue.ToNum()>=this.targetVo.targetValue.ToNum()&&(null!=this.getHandler&&this.hasIntegral&&this.grid_item.itemList[this.integralItemIndex]&&this.getHandler(this.grid_item.itemList[this.integralItemIndex]),
C.l.ins.CM_GainActivitytaskReward(this.huodongCfgVo.activityId,this.huodongCfgVo.id))}OnClickBtnGo(){this.rewardVo.isReward||g.Y.GotoByLinkStr(this.flyLinkInfo.linkStr)}})||s},
67581:(t,e,i)=>{var s,n,a=i(18998),o=i(83908),l=i(61911),r=i(33138)
a._decorator.ccclass("SevenDayQuestRoleItem")((n=class t extends((0,o.pA)(l.f)()){constructor(...t){super(...t),this.clickHandler=null,this.data=null}SetData(t){
this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.OnClickItem)),this.SetSelect(!1),this.data=t
r.f.Inst().getItemById(t.wingId)}OnClickItem(){this.SetSelect(!0)}SetSelect(e){e&&(null!=t._CurrentSelect&&t._CurrentSelect.SetSelect(!1),
t._CurrentSelect!=this&&null!=this.clickHandler&&this.clickHandler(this.data),t._CurrentSelect=this),this.select.SetActive(e)}Clear(){super.Clear()}Destroy(){t._CurrentSelect=null,
this.clickHandler=null,super.Destroy()}Test1(){return!0}S_Test(){return!0}},n._CurrentSelect=null,s=n))},71867:(t,e,i)=>{i.d(e,{E:()=>S})
var s,n=i(18998),a=i(83908),o=i(86133),l=i(62370),r=i(9057),h=i(61613),d=i(85602),u=i(63076),c=i(75696),_=i(33314),I=i(56828),g=i(47174),m=i(12842),C=i(93727)
let S=n._decorator.ccclass("SevenDayRankItem")(s=class extends((0,a.pA)(r.x)()){constructor(...t){super(...t),this.rankVo=null}InitView(){super.InitView(),
this.grid_item.SetInitInfo("ui_baseitem",null,c.j)}SetAdapt1(){const t=h.v.GetAdaptionWidth(710,772)
this.img_bg.widthSet(Math.max(t,this.node.transform.width)),this.grid_item.node.x=525.511+this.img_bg.width()-710}SetDepth(t){}SetData(t){this.AddLis(),this.rankVo=t,
this.UpdatePanel()}AddLis(){}RemoveLis(){}Clear(){super.Clear(),this.RemoveLis()}Destroy(){super.Destroy()}UpdatePanel(){const t=this.RankInfo_Get().rankInfos[this.rankVo.rank[0]]
if(this.rankVo.rank[0]<=3)this.text_rank.textSet(""),this.img_rank.node.SetActive(!0),this.img_rank.spriteNameSet(`rypaihangbang_sp_000${this.rankVo.rank[0]}`),
t?(this.content.SetActive(!0),this.emptyContent.SetActive(!1),this.text_score.textSet(l.o.Format((0,o.T)("累计积分:{0}"),t.rankValue)),this.text_name.textSet(t.name),
this.img_icon.node.SetActive(!0),this.img_icon_bg.node.SetActive(!0),this.img_icon.spriteNameSet(_.Z.GetJobIcon(t.job,t.sex,!1))):(this.content.SetActive(!1),
this.emptyContent.SetActive(!0))
else{this.content.SetActive(!0),this.emptyContent.SetActive(!1)
const t=this.RankReward_Get().rankConfigVoList,e=t[t.count-1]
this.rankVo.rank[0]==e.rank[0]?this.text_rank.textSet(l.o.Format((0,o.T)("{0}名以下"),this.rankVo.rank[0])):this.text_rank.textSet(l.o.Format((0,
o.T)("{0}-{1}名"),this.rankVo.rank[0],this.rankVo.rank[1])),this.img_rank.node.SetActive(!1),this.text_score.textSet(""),this.text_name.textSet(""),this.img_icon.node.SetActive(!1),
this.img_icon_bg.node.SetActive(!1)}const e=new d.Z
for(let t=0;t<=this.rankVo.rankReward.rewards.Count()-1;t++){const i=u.M.wrapReward(this.rankVo.rankReward.rewards[t])
e.Add(i)}this.grid_item.data_set(e),this.SetAdapt1()}RankInfo_Get(){return C.i.ins.rankInfoDic[m.t.SEVEN_DAY_RANK][g.c.SEVENDAY]}RankReward_Get(){
return I.K.Inst_get().rank_rewards_dict[m.t.SEVEN_DAY_RANK][g.c.SEVENDAY]}})||s},86985:(t,e,i)=>{i.d(e,{i:()=>g})
var s,n=i(18998),a=i(83908),o=i(38836),l=i(97461),r=i(16968),h=i(92679),d=i(56834),u=i(23649),c=i(69622),_=i(93727),I=i(24810)
let g=n._decorator.ccclass("SevenDayRightItem")(s=class extends((0,a.pA)(r.E)()){constructor(...t){super(...t),this.lastRedponitState=!1}InitView(){super.InitView(),
this._curRedPointId=0,this.redPoint.SetActive(!1)}SetData(t){super.SetData(t),l.i.Inst.AddEventHandler(h.g.HUODONG_INFO_CHANGE,this.CreateDelegate(this.UpdateLock)),
l.i.Inst.AddEventHandler(h.g.HUODONG_QUEST_CHANGE,this.CreateDelegate(this.OnQuestChange)),null!=this.uispAni&&this.uispAni.node.SetActive(!1),this.UpdateLock(),
this.UpdateFinishState()}SetSelect(t){super.SetSelect(t),null!=this.uispAni&&(t||this.uispAni.node.SetActive(!1))}Clear(){super.Clear(),
l.i.Inst.RemoveEventHandler(h.g.HUODONG_INFO_CHANGE,this.CreateDelegate(this.UpdateLock)),
l.i.Inst.RemoveEventHandler(h.g.HUODONG_QUEST_CHANGE,this.CreateDelegate(this.OnQuestChange))}OnQuestChange(){this.isSelect&&!this.finishObj.active&&this.UpdateFinishState()}
UpdateFinishState(){let t=!0
if(null!=this.itemData.huodongId&&0!=this.itemData.huodongId&&_.i.ins.GetState(this.itemData.huodongId)==d.V.NONE)t=!1
else{const e=c.J.ins.GetTargetTypesByHuoDongId(this.itemData.huodongId,u.h.ACTIVITY_SCORE)
if(null!=e)for(const[i,s]of(0,o.V5)(e)){const e=_.i.ins.GetQuestListVoByIdAndTargetType(this.itemData.huodongId,s)
for(const[i,s]of(0,o.V5)(e))if(!I.K.ins.IsActivityTaskFinish(s)){t=!1
break}}else t=!1}this.finishObj.SetActive(t)}UpdateLock(){
null!=this.itemData.huodongId&&0!=this.itemData.huodongId&&_.i.ins.GetState(this.itemData.huodongId)==d.V.NONE?this.img_lock.node.SetActive(!0):this.img_lock.node.SetActive(!1)}
PlayAni(){}})||s},1114:(t,e,i)=>{var s,n=i(18998),a=i(72005),o=i(51868),l=i(18202),r=i(83540)
n._decorator.ccclass("SevenIntegralAnimItem")(s=class extends o.${constructor(...t){super(...t),this.sprite=null}InitView(){super.InitView(),this.sprite=this.CreateComponent(a.w,1)
}Clear(){super.Clear()}Destroy(){super.Destroy(),l.g.DestroyUIObj()}SetSprite(t){l.g.SetItemIcon(this.sprite.FatherId,this.sprite.ComponentId,t,r.b.eItem,!1)}Test1(){return!0}
S_Test(){return!0}})},40106:(t,e,i)=>{
var s,n=i(18998),a=i(6847),o=i(83908),l=i(17409),r=i(46282),h=i(86133),d=i(97461),u=i(5924),c=i(36334),_=i(44255),I=i(5494),g=i(61613),m=i(60130),C=i(98130),S=i(85602),p=i(92679),A=i(28287),f=i(14792),y=i(62734),T=i(65550),R=i(67642),v=i(99421),w=i(12842),D=i(56834),E=i(69622),L=i(93727),G=i(10231),O=i(24810),b=i(43977),B=i(86985),N=i(74110),P=i(56833),M=i(41143)
;(0,
a.s_)(I.I.eSevenDayPanel,r.Z.ui_ry_sevenday_mainview).waitPrefab(r.Z.ui_sevenday_right_tab).waitPrefab(r.Z.ui_sevenday_quest_view).waitPrefab(r.Z.ui_intergral_anim_item).waitPrefab(r.Z.ui_sevenday_quest_item1).waitPrefab(r.Z.ui_sevenday_mall_item).waitPrefab(r.Z.ui_sevenday_daily_item).waitPrefab(r.Z.ui_sevenday_zhuoyue_view).waitPrefab(r.Z.ui_sevenday_rank_view).hideMainUI().register()(s=class extends((0,
o.pA)(_.I)()){constructor(...t){super(...t),this.tabIdx1=-1,this.shouldReOpenCurrencyTimer=-1}InitView(){super.InitView(),
this._subPanelDatas.Add(c.b.New(new S.Z(["ui_sevenday_zhuoyue_view","ui_sevenday_quest_item"]),this,M.g)),
this._subPanelDatas.Add(c.b.New(new S.Z(["ui_sevenday_quest_view","ui_intergral_anim_item","ui_sevenday_quest_item1","ui_sevenday_mall_item","ui_sevenday_daily_item"]),this,N.q)),
this._subPanelDatas.Add(c.b.New(new S.Z(["ui_sevenday_rank_view","ui_sevenday_rank_item"]),this,P.G)),
this.bottomTabGrid.SetInitInfo("ui_sevenday_right_tab",null,b.q,this.CreateDelegate(this._OnClickBottomItem)),
this.rightTabGrid.SetInitInfo("ui_sevenday_left_tab",null,B.i,this.CreateDelegate(this._OnClickRightItem)),
this.bottomTabGrid.OnReposition_set(this.CreateDelegate(this.OnRepositionBottom)),this.rightTabGrid.OnReposition_set(this.CreateDelegate(this.OnRepositionRight))}
OnCreateTabItem0(t){}AddLis(){d.i.Inst.AddEventHandler(p.g.CloseCurrencyBarView,this.CreateDelegate(this.shouldReOpenCurency)),super.AddLis()}RemoveLis(){
d.i.Inst.RemoveEventHandler(p.g.CloseCurrencyBarView,this.CreateDelegate(this.shouldReOpenCurency)),super.RemoveLis()}shouldReOpenCurency(){(0,
l.Di)(I.I.eSevenDayPanel)&&(this.shouldReOpenCurrencyTimer>0&&(u.C.Inst_get().ClearInterval(this.shouldReOpenCurrencyTimer),this.shouldReOpenCurrencyTimer=-1),
this.shouldReOpenCurrencyTimer=u.C.Inst_get().SetInterval(this.CreateDelegate(this.reOpenCurrencyBar),200,1))}reOpenCurrencyBar(){
this.ShowCurrencyBar_get&&this.ShowCurrencyBar_get()!=A._.None&&d.i.Inst.RaiseEvent(p.g.OpenCurrencyBarView,[this,I.I.eSevenDayPanel])}SetViewConfig(){this.titleLabel.textSet((0,
h.T)("开服活动")),this._SetCharacterTabData(!1),this.tab0RedPointList=new S.Z([f.t.SEVEN_DAY_1_1,f.t.SEVEN_DAY_QUEST,f.t.SEVEN_DAY_RANK])
let t=this.tab0RedPointList.IndexOf(f.t.SEVEN_DAY_QUEST)
for(let e=0;e<=this.tab0RedPointList.Count()-1;e++)if(y.f.Inst.GetData(this.tab0RedPointList[e]).show){t=e
break}this.SelectTab0(t,!0),v.l.ins.CM_OpenActivityPanel(w.t.SEVEN_DAY_2)}SelectTab0(t,e,i){
if(2==t)return L.i.ins.GetState(w.t.SEVEN_DAY_RANK)==D.V.NONE?void T.y.inst.ClientSysStrMsg((0,
h.T)("明日开启")):(d.i.Inst.AddEventHandler(p.g.HUODONG_RANKINFO_UPDATE,this.CreateDelegate(this.OnGetHuodongRankInfo)),v.l.ins.CM_OpenActivityPanel(w.t.SEVEN_DAY_RANK),
void v.l.ins.CM_GetActivityRank(w.t.SEVEN_DAY_RANK,1,3))
super.SelectTab0(t,e,i)}OnGetHuodongRankInfo(t){
t.activityId==w.t.SEVEN_DAY_RANK&&(d.i.Inst.RemoveEventHandler(p.g.HUODONG_RANKINFO_UPDATE,this.CreateDelegate(this.OnGetHuodongRankInfo)),super.SelectTab0(2,!0,!1))}
SelectTab1(t,e){null!=O.K.ins.sevenday_huodong_ids[t]&&(this.m_handlerMgr.AddEventMgr(p.g.HUODONG_INFO_CHANGE,this.CreateDelegate(this.OnGetHuodongInfo)),this.tabIdx1=t,
v.l.ins.CM_OpenActivityPanel(O.K.ins.sevenday_huodong_ids[t]))}OnGetHuodongInfo(){
this.m_handlerMgr.RemoveEventMgr(p.g.HUODONG_INFO_CHANGE,this.CreateDelegate(this.OnGetHuodongInfo)),
L.i.ins.GetState(O.K.ins.sevenday_huodong_ids[this.tabIdx1])!=D.V.NONE?L.i.ins.GetState(O.K.ins.sevenday_huodong_ids[this.tabIdx1])!=D.V.CLOSE?(this.tabIdx1=this.GetRedTabIndex(this.tabIdx1,this.tab1RedPointList),
super.SelectTab1(this.tabIdx1,!0,!1)):T.y.inst.ClientSysStrMsg((0,h.T)("活动已关闭")):T.y.inst.ClientSysStrMsg((0,h.T)("尚未开放，敬请期待"))}_OnSelectTab0BeforeUpdate(t){
const e=new S.Z([E.J.ins.GetHuoDongVo(w.t.SEVEN_DAY_1).name,(0,h.T)("每日目标"),(0,h.T)("积分排名")]),i=new S.Z([f.t.SEVEN_DAY_1_1,f.t.SEVEN_DAY_QUEST,f.t.SEVEN_DAY_RANK])
if(0==this.selectTabIdx0)O.K.ins.select_huodong_id=w.t.SEVEN_DAY_1,this._SetTabData0(!0,e,i),this._SetTabData1(!1)
else if(1==this.selectTabIdx0){O.K.ins.select_huodong_id=O.K.ins.GetOpeningId(),0==O.K.ins.select_huodong_id&&(O.K.ins.select_huodong_id=O.K.ins.sevenday_huodong_ids.LastItem()),
this._SetTabData0(!0,e,i,null,null,null,null,null,new S.Z([0,w.t.SEVEN_DAY_RANK]))
const t=new S.Z
for(let e=0;e<=O.K.ins.sevenday_huodong_ids.Count()-1;e++)t.Add(E.J.ins.GetHuoDongVo(O.K.ins.sevenday_huodong_ids[e]).name)
this._SetTabData1(!0,t,O.K.ins.sevenday_red_ids,null,null,null,O.K.ins.sevenday_huodong_ids),
this.tabIdx1>=0?this.SelectTab1(this.tabIdx1,!0):this.SelectTab1(O.K.ins.sevenday_huodong_ids.IndexOf(O.K.ins.select_huodong_id),!0)
}else 2==this.selectTabIdx0&&(O.K.ins.select_huodong_id=w.t.SEVEN_DAY_RANK,this._SetTabData0(!0,e,i),this._SetTabData1(!1))}_OnSelectTab1BeforeUpdate(t){
O.K.ins.select_huodong_id=O.K.ins.sevenday_huodong_ids[this.selectTabIdx1]}Clear(){super.Clear(),
d.i.Inst.RemoveEventHandler(p.g.HUODONG_RANKINFO_UPDATE,this.CreateDelegate(this.OnGetHuodongRankInfo)),this.RemoveLis(),O.K.ins.select_huodong_id=0}Destroy(){super.Destroy()}
OnCloseClick(){G.P.ins.ClosePanel()}UpdateView(){this.rightBg1.SetActive(!1),0==this.selectTabIdx0?this.ShowSubView(0):1==this.selectTabIdx0?(this.ShowSubView(1),
this.rightBg1.SetActive(!0)):2==this.selectTabIdx0&&this.ShowSubView(2)}UpdateAnchors(){const t=g.v.GetAdaptionWidth(1076,1349)
this.secondBg1.widthSet(t)
const e=g.v.GetAdaptionWidth(912,1193)
this.secondBg2.widthSet(e),this.secondBg2.heightSet(434),g.v.SetAdaptionPos(this.rightBg1,-630,-757,-2),g.v.SetAdaptionPos(this.scrollLeftGo,-578,-705,137)
const i=m.O.GetUIWidth()
null!=this.bg1&&this.bg1.widthSet(i),null!=this.bg2&&this.bg2.widthSet(i-129),m.O.SetAnchorPos(this.leftTrans,!0,!1,0),m.O.SetAnchorPos(this.rightTrans,!1,!0,0)
const s=m.O.UIScreenNotchWidth
null!=this.ui_charactertab&&this.ui_charactertab.node.transform.SetLocalPositionXYZ(71+s,0,0)
let a=6
a=C.GF.INT(i/196),this.bottomTabGrid2&&this.bottomTabGrid2.data_set(new S.Z(R.S.CreateTableArr(a,0))),
null!=this.dragWidget&&this.dragWidget.node.transform.setContentSize(new n.Size(i,80))}})},74110:(t,e,i)=>{i.d(e,{q:()=>x})
var s,n,a=i(18998),o=i(75507),l=i(83908),r=i(38836),h=i(68662),d=i(5924),u=i(51868),c=i(18202),_=i(83540),I=i(61613),g=i(60130),m=i(35128),C=i(98885),S=i(85602),p=i(21729),A=i(92679),f=i(87923),y=i(48933),T=i(35037),R=i(33996),v=i(8211),w=i(56828),D=i(47174),E=i(62734),L=i(12842),G=i(23649),O=i(69622),b=i(93727),B=i(24810),N=i(79534),P=i(70164),M=i(35135),V=i(86551),k=i(36408)
let x=a._decorator.ccclass("SevenDayQuestView")((n=class t extends((0,l.pA)(u.$)()){constructor(...t){super(...t),this.select_target_type=0,this.interval=-1,this.timerId=-1,
this.cacheItemList=null,this.activityItem=null,this.roleModel=null,this.STAGE_ID=149,this.move=94,this.prevPos=0,this.canMoveUp=!0,this.canMoveDown=!0,this.curPoint=0,
this.isInit=!1,this.isfirstenter=!0}InitView(){if(this.cacheItemList=new S.Z,this.activityItem=new S.Z,
this.tabGrid.SetInitInfo("ui_sevenday_quest_tabbtn_item",null,V.$,this.CreateDelegate(this.OnClickBtnTab)),this.tabGrid.OnReposition_set(this.CreateDelegate(this.OnTabGridLoaded)),
this.grid_quest.SetInitInfo("ui_sevenday_quest_item1",null,k.R),this.grid_quest.OnReposition_set(this.CreateDelegate(this.onReposition)),
this.grid_mall.SetInitInfo("ui_sevenday_mall_item",null,M.G),this.dailyGrid.SetInitInfo("ui_sevenday_daily_item",null,P.o),g.O.GetUIWidth()>=I.v.LONG_WIDTH_SIGN){
I.v.SetAdaptionPos(this.offset,0,-127,0)
const t=g.O.GetUIWidth()
this.timetips.node.x+=(t-1280)/2}}SetData(){-1==this.interval&&(this.interval=d.C.Inst_get().SetInterval(this.CreateDelegate(this.OnEachSec),1e3)),this.AddLis(),this.InitTabs(),
this.OnEachSec(),this.UpdatePanel()}AddLis(){this.m_handlerMgr.AddEventMgr(A.g.HUODONG_QUEST_CHANGE,this.CreateDelegate(this.UpdatePanel)),
v.N.GetInst().AddEventHandler(R.G.BUY_MALLINFO,this.CreateDelegate(this.UpdatePanel))}RemoveLis(){-1!=this.interval&&(d.C.Inst_get().ClearInterval(this.interval),this.interval=-1),
this.m_handlerMgr.RemoveEventMgr(A.g.HUODONG_QUEST_CHANGE,this.CreateDelegate(this.UpdatePanel)),
v.N.GetInst().RemoveEventHandler(R.G.BUY_MALLINFO,this.CreateDelegate(this.UpdatePanel))}onReposition(t){const e=t.getCNode(k.R)
return e.getHandler=this.CreateDelegate(this.OnGetIntegral),e.SetAdapt2(),e}OnDailyGridRepos(){const t=this.dailyGrid.itemList
if(0==t.Count())return
if(!this.isfirstenter)return
this.isfirstenter=!1
let e=0,i=-1
for(let s=0;s<=t.Count()-1;s++){const n=t[s]
if(n.rewardVo.isReward){e+=1
break}if(n.targetVo.curValue.ToNum()>=n.targetVo.targetValue.ToNum()){i=s
break}}}CreateItem(){const t=o.o.getPrefab("ui_intergral_anim_item"),e=(0,a.instantiate)(t).getCNode()
return e.node.setParent(this.node),e}OnGetIntegral(t){
const e=t.node.transform.TransformPoint(t.node.getPosition()),i=this.node.inverseTransformPoint(new N.P,e),s=this.scoreNode.node.getPosition()
let n=this.cacheItemList.Pop()
null==n&&(n=this.CreateItem()),c.g.SetItemIcon(n,t._baseItemData.cfgData_get().icon,_.b.eItem,!1),n.node.SetActive(!0),this.activityItem.Add({item:n,beginPos:i,animPos:s,dist:0}),
this.playIntegralAnim()}playIntegralAnim(){-1==this.timerId&&(this.timerId=d.C.Inst_get().SetFrameLoop(this.CreateDelegate(this.OnLoopIntegral),1))}OnLoopIntegral(){
for(let t=this.activityItem.Count()-1;t>=0;t+=-1){const e=this.activityItem[t]
e.dist+=d.C.Inst_get().distanceTime
const i=e.dist/2e3
if(i>1)e.item.node.SetActive(!1),this.cacheItemList.Add(e.item),this.activityItem.RemoveAt(t)
else{const t=p.N.Lerp(e.beginPos.x,e.animPos.x,i),s=p.N.Lerp(e.beginPos.y,e.animPos.y,i),n=p.N.Lerp(1,0,i)
y.I.calVec3.Set(t,s,0),e.item.node.setPosition(y.I.calVec3),y.I.calVec3.Set(n,n,1),e.item.node.setScale(y.I.calVec3),e.item.node.SetActive(!0)}}
0==this.activityItem.Count()&&this.ClearAnimLoop()}ClearAnimLoop(){d.C.Inst_get().ClearLoop(this.timerId),this.timerId=-1
for(let t=0;t<=this.activityItem.Count()-1;t++)this.cacheItemList.Add(this.activityItem[t].item),this.activityItem[t].item.node.transform.SetLocalPositionXYZ(1e4,0,0),
this.activityItem[t].item.node.SetActive(!1)
this.activityItem.Clear()}UpdatePanel(){this.UpdateTargetType(),this.UpdateDaily()}InitTabs(){const t=this.TargetTypes_Get(),e=new S.Z
for(let i=0;i<=t.Count()-1;i++){const s=O.J.ins.GetQuestListVoByIdAndTargetType(B.K.ins.select_huodong_id,t[i])
e.Add(s[0])}this.select_target_type=-1
for(let e=0;e<=t.Count()-1;e++){const i=B.K.ins.GetRedPointName(B.K.ins.select_huodong_id,t[e])
if(-1==this.select_target_type&&E.f.Inst.GetData(i).show){this.select_target_type=t[e]
break}}if(-1==this.select_target_type){const e=O.J.ins.GetQuestListVoByIdAndTargetType(B.K.ins.select_huodong_id,G.h.MALL_BUY)
for(const[t,i]of(0,r.V5)(e)){const t=C.M.String2Int(i.TargetDefs_Get().tCTargetDefs[0].param.mallId),e=v.N.GetInst().GetInfo(t)
if(null!=e&&e.Lastnum_get()<e.GetBuyLimit()){this.select_target_type=G.h.MALL_BUY
break}}if(-1==this.select_target_type){const t=O.J.ins.GetTargetTypesByHuoDongId(B.K.ins.select_huodong_id,G.h.MALL_BUY)
for(let e=0;e<=t.Count()-1;e++)if(t[e]!=G.h.ACTIVITY_SCORE){const i=O.J.ins.GetQuestListVoByIdAndTargetType(B.K.ins.select_huodong_id,t[e])
for(const[s,n]of(0,r.V5)(i)){const i=b.i.ins.GetQuestVo(n.id)
if(null!=i&&i.targetVos[0].curValue.ToNum()<i.targetVos[0].targetValue.ToNum()){this.select_target_type=t[e]
break}}if(-1!=this.select_target_type)break}}-1==this.select_target_type&&(e.Count()>0?this.select_target_type=G.h.MALL_BUY:this.select_target_type=t[0])}this.tabGrid.data_set(e),
this.scroll_bar.scrollToTop()}OnTabGridLoaded(){const t=this.TargetTypes_Get()
for(let t=0;t<=this.tabGrid.itemList.count-1;t++)this.tabGrid.itemList[t].clickHandler=this.CreateDelegate(this.OnClickBtnTab)
this.tabGrid.itemList[t.IndexOf(this.select_target_type)].SetSelect(!0)}OnClickBtnTab(t){this.select_target_type=t.targetType,this.scroll_bar.scrollToTop(.01),
this.grid_mall.scrollToTop(.01),this.UpdateTargetType()}GetFirstSpacing(){return I.v.GetAdaptionWidth(43,43)}GetSpacing(){return I.v.GetAdaptionWidth(141,141)}GetSpacingByIndex(e){
let i=1
return i=1==e?this.GetFirstSpacing():this.GetSpacing()-t.ITEM_WIDTH,i}UpdateDaily(){this.curPoint=0
const e=b.i.ins.GetQuestListVoByTargetType(G.h.ACTIVITY_SCORE)
this.dailyGrid.data_set(e)
for(let t=0;t<=e.Count()-1;t++)this.curPoint<e[t].targetVos[0].curValue.ToNum()&&(this.curPoint=e[t].targetVos[0].curValue.ToNum())
let i=0
null!=w.K.Inst_get().self_rank_value[L.t.SEVEN_DAY_RANK]&&(i=w.K.Inst_get().self_rank_value[L.t.SEVEN_DAY_RANK][D.c.SEVENDAY]),this.text_point.textSet(i+"")
let s=0
for(let i=0;i<=e.Count()-1;i++){const n=this.GetSpacingByIndex(i+1)
if(!(e[i].targetVos[0].curValue.ToNum()>=e[i].targetVos[0].targetValue.ToNum())){let t=0
i>0&&(t=e[i-1].targetVos[0].targetValue.ToNum()),s+=(e[i].targetVos[0].curValue.ToNum()-t)/(e[i].targetVos[0].targetValue.ToNum()-t)*n
break}s=s+n+t.ITEM_WIDTH}0==s?this.lightLine.node.SetActive(!1):(this.lightLine.node.SetActive(!0),this.lightLine.widthSet(s))}UpdateTargetType(){
const t=b.i.ins.GetQuestListVoByIdAndTargetType(B.K.ins.select_huodong_id,this.select_target_type)
this.select_target_type==G.h.MALL_BUY?(this.grid_mall.node.SetActive(!0),this.grid_quest.node.SetActive(!1),this.grid_quest.array=null,t.Sort(((t,e)=>{
const i=O.J.ins.GetQuestVoById(t.taskId),s=O.J.ins.GetQuestVoById(e.taskId),n=C.M.String2Int(i.TargetDefs_Get().tCTargetDefs[0].param.mallId),a=C.M.String2Int(s.TargetDefs_Get().tCTargetDefs[0].param.mallId),o=v.N.GetInst().GetInfo(n),l=v.N.GetInst().GetInfo(a),r=o.Lastnum_get()>=o.GetBuyLimit(),h=l.Lastnum_get()>=l.GetBuyLimit()
if(r!=h){if(r)return 1
if(h)return-1}const d=T.L.GetInst().GetCfgById(n),u=T.L.GetInst().GetCfgById(a),c=0==d.GetPrice(),_=0==u.GetPrice()
if(c!=_){if(c)return-1
if(_)return 1}const I=t.targetVos[0].curValue.ToNum()==t.targetVos[0].targetValue.ToNum(),g=e.targetVos[0].curValue.ToNum()==e.targetVos[0].targetValue.ToNum()
if(I!=g){if(I)return-1
if(g)return 1}return i.sort-s.sort})),this.grid_mall.data_set(t)):(t.Sort(((t,e)=>{const i=O.J.ins.GetQuestVoById(t.taskId).sort,s=O.J.ins.GetQuestVoById(e.taskId).sort
if(t.activityRewardVo.isReward!=e.activityRewardVo.isReward){if(t.activityRewardVo.isReward)return 1
if(e.activityRewardVo.isReward)return-1}
const n=t.targetVos[0].curValue.ToNum()==t.targetVos[0].targetValue.ToNum(),a=e.targetVos[0].curValue.ToNum()==e.targetVos[0].targetValue.ToNum()
if(n!=a){if(n)return-1
if(a)return 1}return i-s})),this.grid_mall.node.SetActive(!1),this.grid_mall.array=null,this.grid_quest.node.SetActive(!0),this.grid_quest.data_set(t)),
this.scroll_bar.ResetPosition()}OnEachSec(){const t=b.i.ins.huodong_dict.LuaDic_GetItem(B.K.ins.select_huodong_id)
if(null!=t){const e=m.p.FloorToInt(t.endTime.ToNum()/1e3)-h.D.serverTime_get()
e>0?this.timetips.textSet(`[b09979]结束倒计时:[-] [5fb470]${f.l.GetDateFormatEX(e,!0,!0)}[-]`):this.timetips.textSet("[b09979]已结束[-]")}}TargetTypes_Get(){
return O.J.ins.GetTargetTypesByHuoDongId(B.K.ins.select_huodong_id,G.h.ACTIVITY_SCORE)}Clear(){this.isfirstenter=!0,this.RemoveLis(),this.ClearAnimLoop(),this.dailyGrid.Clear(),
super.Clear()}},n.ITEM_WIDTH=74,s=n))||s},37926:(t,e,i)=>{
var s,n=i(18998),a=i(6847),o=i(83908),l=i(46282),r=i(86133),h=i(68662),d=i(62370),u=i(5924),c=i(61911),_=i(5494),I=i(60130),g=i(35128),m=i(85602),C=i(63076),S=i(75696),p=i(92679),A=i(87923),f=i(56828),y=i(47174),T=i(99421),R=i(12842),v=i(56834),w=i(93727),D=i(10231),E=i(97461),L=i(71867)
n._decorator.ccclass("SevenDayRankRewardPanel")(s=(0,a.s_)(_.I.eSevenDayRankRewardPanel,l.Z.ui_sevenday_rank_daily_reward_panel).waitPrefab(l.Z.ui_sevenday_right_tab).register()(s=class extends((0,
o.pA)(c.f)()){constructor(...t){super(...t),this.interval=-1}InitView(){this.btn_get.node.SetActive(!1),this.text_time.node.SetActive(!1),
this.grid_rank.SetInitInfo("ui_sevenday_rank_item1",null,L.E),this.grid_item.SetInitInfo("ui_baseitem",null,S.j),
this.grid_item.OnReposition_set(this.CreateDelegate(this.OnReposition1)),this.grid_rank.OnReposition_set(this.CreateDelegate(this.OnReposition2))}OnReposition1(){
this.grid_item.Reposition(),this.scroll_item.ResetPosition()}OnReposition2(){this.grid_rank.Reposition(),this.scroll_view.ResetPosition()}OnAddToScene(){this.AddLis(),
-1==this.interval&&(this.interval=u.C.Inst_get().SetInterval(this.CreateDelegate(this.OnEachSec),1e3)),this.OnEachSec(),this.UpdatePanel()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.btn_get,this.CreateDelegate(this.OnClickBtnGet)),this.m_handlerMgr.AddClickEvent(this.btn_close,this.CreateDelegate(this.OnClickBtnClose)),
E.i.Inst.AddEventHandler(p.g.RANK_DAILY_REWARD,this.CreateDelegate(this.UpdatePanel)),E.i.Inst.AddEventHandler(p.g.RANK_DAILY_REWARD_CONFIG,this.CreateDelegate(this.UpdatePanel))}
RemoveLis(){this.m_handlerMgr.RemoveClickEvent(this.btn_get,this.CreateDelegate(this.OnClickBtnGet)),
this.m_handlerMgr.RemoveClickEvent(this.btn_close,this.CreateDelegate(this.OnClickBtnClose)),
E.i.Inst.RemoveEventHandler(p.g.RANK_DAILY_REWARD,this.CreateDelegate(this.UpdatePanel)),
E.i.Inst.RemoveEventHandler(p.g.RANK_DAILY_REWARD_CONFIG,this.CreateDelegate(this.UpdatePanel))}UpdateRank(){let t=new m.Z
const e=this.DailyRewardConfig_Get().rankConfigVoList
null!=e&&(t=e),this.grid_rank.data_set(t)}Clear(){this.RemoveLis(),super.Clear(),-1!=this.interval&&(u.C.Inst_get().ClearInterval(this.interval),this.interval=-1)}Destroy(){
super.Destroy()}OnClickBtnGet(){
this.DailyRewardConfig_Get().totalCount-this.DailyReward_Get().restTimes!=0&&(h.D.serverMSTime_get()<this.DailyReward_Get().nextRewardTime.ToNum()||T.l.ins.CM_GainRankDayReward(R.t.SEVEN_DAY_RANK))
}OnClickBtnClose(){D.P.ins.CloseRankRewardPanel()}UpdatePanel(){
this.DailyRewardConfig_Get().totalCount-this.DailyReward_Get().restTimes==0?this.btn_get.node.SetActive(!1):this.btn_get.node.SetActive(!0)
const t=this.RankReward_Get().rankConfigVoList
let e=null,i=null
for(let s=0;s<=t.Count()-1;s++)this.RankInfo_Get().rank>=t[s].rank[0]&&this.RankInfo_Get().rank<=t[s].rank[1]&&(e=t[s],i=s>0?this.RankInfo_Get().rankInfos[s-1]:null)
;-1==this.RankInfo_Get().rank?(this.text_rank.textSet((0,r.T)("未上榜")),i=this.RankInfo_Get().rankInfos[t.Count()-1]):this.text_rank.textSet(this.RankInfo_Get().rank+"")
let s=0
null!=f.K.Inst_get().self_rank_value[R.t.SEVEN_DAY_RANK]&&(s=f.K.Inst_get().self_rank_value[R.t.SEVEN_DAY_RANK][y.c.SEVENDAY]),this.text_score.textSet(s+""),
null!=i?this.text_nextscore.textSet((Number(i.rankValue)-s).toString()):this.text_nextscore.textSet("无")
let n=this.DailyRewardConfig_Get().andReward
const a=this.DailyRewardConfig_Get().rankConfigVoList
if(null==n&&-1==this.RankInfo_Get().rank)n=this.DailyRewardConfig_Get().rankConfigVoList.LastItem().rankReward
else if(null!=a)for(let t=0;t<=a.Count()-1;t++){const e=a[t]
if(null!=e.rank&&e.rank.Contains(this.RankInfo_Get().rank)){n=e.rankReward
break}}const o=new m.Z
if(null!=n&&null!=n.rewards){let t=0
for(;t<n.rewards.Count();){const e=C.M.wrapReward(n.rewards[t])
o.Add(e),t+=1}}this.grid_item.data_set(o),this.UpdateRank()}OnEachSec(){if(w.i.ins.GetState(R.t.SEVEN_DAY_RANK)!=v.V.OPEN)return this.btn_get.node.SetActive(!1),
void this.text_total_time.textSet(d.o.Format((0,r.T)("活动已结束"),this.DailyRewardConfig_Get().totalCount))
if(this.DailyRewardConfig_Get().totalCount-this.DailyReward_Get().restTimes==0)this.btn_get.node.SetActive(!1),this.text_total_time.textSet(d.o.Format((0,
r.T)("每天可领取{0}次"),this.DailyRewardConfig_Get().totalCount))
else{this.text_total_time.textSet(""),this.btn_get.node.SetActive(!0)
const t=this.DailyReward_Get()
if(h.D.serverMSTime_get()<=t.nextRewardTime.ToNum()){this.text_time.node.SetActive(!0)
let e=t.nextRewardTime.ToNum()
e-=e%1e3,this.text_time.textSet(A.l.GetDateFormat(g.p.FloorToInt((e-h.D.serverMSTime_get())/1e3))),this.btn_get.SetIsEnabled(!1),I.O.makeGoGray(this.btn_get.node,!0)
}else this.text_time.node.SetActive(!1),this.btn_get.SetIsEnabled(!0),I.O.makeGoGray(this.btn_get.node,!1)}}DailyReward_Get(){
return f.K.Inst_get().daily_reward_dict.LuaDic_GetItem(y.c.SEVENDAY)}DailyRewardConfig_Get(){return f.K.Inst_get().daily_reward_config_dict.LuaDic_GetItem(y.c.SEVENDAY)}
RankInfo_Get(){return w.i.ins.rankInfoDic[R.t.SEVEN_DAY_RANK][y.c.SEVENDAY]}RankReward_Get(){return f.K.Inst_get().rank_rewards_dict[R.t.SEVEN_DAY_RANK][y.c.SEVENDAY]}})||s)},
56833:(t,e,i)=>{i.d(e,{G:()=>N})
var s,n=i(18998),a=i(83908),o=i(86133),l=i(97960),r=i(32697),h=i(20583),d=i(50838),u=i(70650),c=i(73206),_=i(68662),I=i(5924),g=i(51868),m=i(61613),C=i(60130),S=i(35128),p=i(85602),A=i(63076),f=i(75696),y=i(92679),T=i(87923),R=i(75439),v=i(11037),w=i(56828),D=i(47174),E=i(12842),L=i(56834),G=i(93727),O=i(10231),b=i(97461),B=i(71867)
let N=n._decorator.ccclass("SevenDayRankView")(s=class extends((0,a.pA)(g.$)()){constructor(...t){super(...t),this.interval=-1,this.m_horse=null,this.roleRotateIndex=null,
this.m_horseEleId=0,this.displayUIAvatarModel=void 0}InitView(){super.InitView(),m.v.SetAdaptionPos(this.right,0,72,0),this.grid_rank.SetInitInfo("ui_sevenday_rank_item",null,B.E),
this.grid_item.SetInitInfo("ui_baseitem",null,f.j),this.grid_rank.OnReposition_set(this.CreateDelegate(this.onReposition))
const t=m.v.GetAdaptionWidth(710,772)
this.rankBg1.widthSet(t)
const e=m.v.GetAdaptionWidth(722,784)
this.rankBg2.widthSet(e),this.displayUIAvatarModel=new d.o,this.displayUIAvatarModel.SetTarget(this.rideAvatar,!0),this.displayUIAvatarModel.setUpDragNode(this.rotate_obj)}
onReposition(){this.scroll_view.ResetPosition()}SetData(){this.AddLis(),this.UpdatePanel(),
-1==this.interval&&(this.interval=I.C.Inst_get().SetInterval(this.CreateDelegate(this.OnEachSec),1e3)),this.scroll_view.scrollTo(0)}AddLis(){
this.m_handlerMgr.AddClickEvent(this.img_daily,this.CreateDelegate(this.OnClickImgDaily)),b.i.Inst.AddEventHandler(y.g.RANK_DAILY_REWARD,this.CreateDelegate(this.UpdateRight)),
b.i.Inst.AddEventHandler(y.g.RANK_DAILY_REWARD_CONFIG,this.CreateDelegate(this.UpdateRight)),b.i.Inst.AddEventHandler(y.g.RANK_DATA,this.CreateDelegate(this.UpdateRight)),
b.i.Inst.AddEventHandler(y.g.RANK_SELF_RANK_VALUE,this.CreateDelegate(this.UpdateRight))}RemoveLis(){
this.m_handlerMgr.RemoveClickEvent(this.img_daily,this.CreateDelegate(this.OnClickImgDaily)),
b.i.Inst.RemoveEventHandler(y.g.RANK_DAILY_REWARD,this.CreateDelegate(this.UpdateRight)),
b.i.Inst.RemoveEventHandler(y.g.RANK_DAILY_REWARD_CONFIG,this.CreateDelegate(this.UpdateRight)),b.i.Inst.RemoveEventHandler(y.g.RANK_DATA,this.CreateDelegate(this.UpdateRight)),
b.i.Inst.RemoveEventHandler(y.g.RANK_SELF_RANK_VALUE,this.CreateDelegate(this.UpdateRight))}Clear(){super.Clear(),this.grid_rank.Clear(),
-1!=this.interval&&(I.C.Inst_get().ClearInterval(this.interval),this.interval=-1),this.RemoveHorse(),this.RemoveLis(),c.X.Inst.DeleteElement(this.m_horseEleId)}UpdatePanel(){
this.UpdateLeft(),this.UpdateRight()}UpdateLeft(){this.OnEachSec(),this.ShowHorseModel()}UpdateRight(){null!=this.RankInfo_Get()&&(this.UpdateRank(),this.UpdateMy())}UpdateRank(){
const t=this.RankReward_Get().rankConfigVoList,e=new p.Z
for(let i=0;i<=t.Count()-1;i++)e.Add(t[i])
this.grid_rank.data_set(e)}UpdateMy(){-1==this.RankInfo_Get().rank?this.text_my_rank.textSet((0,o.T)("未上榜")):this.text_my_rank.textSet(this.RankInfo_Get().rank+"")
let t=0
null!=w.K.Inst_get().self_rank_value[E.t.SEVEN_DAY_RANK]&&(t=w.K.Inst_get().self_rank_value[E.t.SEVEN_DAY_RANK][D.c.SEVENDAY]),this.text_my_score.textSet(t+"")
let e=null
if(-1!=this.RankInfo_Get().rank)for(let t=0;t<=this.RankReward_Get().rankConfigVoList.Count()-1;t++)if(this.RankInfo_Get().rank>=this.RankReward_Get().rankConfigVoList[t].rank[0]&&this.RankInfo_Get().rank<=this.RankReward_Get().rankConfigVoList[t].rank[1]){
e=this.RankReward_Get().rankConfigVoList[t].rankReward.rewards
break}const i=new p.Z
if(null!=e)for(let t=0;t<=e.Count()-1;t++){const s=A.M.wrapReward(e[t])
i.Add(s)}this.grid_item.data_set(i),this.scroll_item.ResetPosition(),this.UpdateDaily()}UpdateDaily(){let t=0
if(null!=w.K.Inst_get().self_rank_value[E.t.SEVEN_DAY_RANK]&&(t=w.K.Inst_get().self_rank_value[E.t.SEVEN_DAY_RANK][D.c.SEVENDAY]),
null==t||0==t)C.O.makeGoGray(this.img_daily.node,!0),this.pre_eff_button_to_click_01.node.SetActive(!1)
else{C.O.makeGoGray(this.img_daily.node,!1)
const t=this.DailyReward_Get(),e=this.DailyRewardConfig_Get()
if(null!=t&&null!=e){let i=0
i=null==t.nextRewardTime?0:t.nextRewardTime.ToNum(),_.D.serverMSTime_get()>=i&&t.restTimes<e.totalCount&&G.i.ins.GetState(E.t.SEVEN_DAY_RANK)==L.V.OPEN?this.pre_eff_button_to_click_01.node.SetActive(!0):this.pre_eff_button_to_click_01.node.SetActive(!1)
}}}OnEachSec(){const t=G.i.ins.huodong_dict.LuaDic_GetItem(E.t.SEVEN_DAY_RANK)
if(null==t)return
const e=S.p.CeilToInt(t.endTime.ToNum()/1e3)-_.D.serverTime_get()
e>0?this.text_time.textSet(`结束倒计时：[5fb470]${T.l.GetDateFormatEX(e,!0,!0)}[-]`):(this.text_time.textSet("已结束"),this.pre_eff_button_to_click_01.node.SetActive(!1))}OnClickImgDaily(){
if(0==w.K.Inst_get().self_rank_value[E.t.SEVEN_DAY_RANK][D.c.SEVENDAY])return
let t=0
null!=w.K.Inst_get().self_rank_value[E.t.SEVEN_DAY_RANK]&&(t=w.K.Inst_get().self_rank_value[E.t.SEVEN_DAY_RANK][D.c.SEVENDAY]),0!=t&&O.P.ins.OpenRankRewardPanel()}ShowHorseModel(){
const t=v.D.GetInst().GetCfg(R.D.getInstance().GetIntValue("SEVEN_DAY:RANK_RIDE_ID")).modelId
this.displayUIAvatarModel.SetScale(1,1),h.x.inst.SetUIAvatarData(t,r.v.horse,this.displayUIAvatarModel),this.displayUIAvatarModel.SetDir(4)}HorseInitHandler(){
null!=this.m_horse&&this.m_horse.IsInited()&&null!=this.m_horse&&(null!=this.roleRotateIndex&&(u.e.GetInst().UnregDrag(this.roleRotateIndex),this.roleRotateIndex=null),
this.roleRotateIndex=u.e.GetInst().RegDrag(this.rotate_obj,this.m_horse.MainRole_get()))}RemoveHorse(){null!=this.roleRotateIndex&&(u.e.GetInst().UnregDrag(this.roleRotateIndex),
this.roleRotateIndex=null),null!=this.m_horse&&(this.m_horse.Info_get().RemoveEventHandler(l.A.HorseInit,this.CreateDelegate(this.HorseInitHandler)),this.m_horse.Destroy(),
this.m_horse=null)}RankInfo_Get(){return G.i.ins.rankInfoDic[E.t.SEVEN_DAY_RANK][D.c.SEVENDAY]}DailyReward_Get(){
return w.K.Inst_get().daily_reward_dict.LuaDic_GetItem(D.c.SEVENDAY)}DailyRewardConfig_Get(){return w.K.Inst_get().daily_reward_config_dict.LuaDic_GetItem(D.c.SEVENDAY)}
RankReward_Get(){return w.K.Inst_get().rank_rewards_dict[E.t.SEVEN_DAY_RANK][D.c.SEVENDAY]}})||s},41143:(t,e,i)=>{i.d(e,{g:()=>b})
var s,n=i(18998),a=i(72574),o=i(83908),l=i(28236),r=i(32697),h=i(20583),d=i(50838),u=i(68662),c=i(5924),_=i(51868),I=i(61613),g=i(60130),m=i(35128),C=i(85602),S=i(63076),p=i(92679),A=i(87923),f=i(74265),y=i(56828),T=i(83434),R=i(99421),v=i(23649),w=i(69622),D=i(93727),E=i(10231),L=i(24810),G=i(97461),O=i(36408)
let b=n._decorator.ccclass("SevenDayZhuoYueView")(s=class t extends((0,o.pA)(_.$)()){constructor(...t){super(...t),this.select_target_type=0,this.interval=-1,this.STAGE_ID=148,
this.m_role=null,this.roleDrags=null,this.isInit=!1,this.commonTaskVo=null,this.displayUIAvatarModel1=void 0,this.displayUIAvatarModel2=void 0,this.displayUIAvatarModel3=void 0,
this.minMoveX=10,this.mouseMoveX=0,this.RoleDrags=null}InitView(){super.InitView(),this.m_role=new C.Z,this.roleDrags=new C.Z,g.O.SetAnchorPos(this.left,!0,!1,0),
I.v.SetAdaptionPos(this.bg,0,72,0),this.grid_quest.SetInitInfo("ui_sevenday_quest_item",null,O.R),this.grid_quest.OnReposition_set(this.CreateDelegate(this.OnReposition)),
this.displayUIAvatarModel1=new d.o,this.displayUIAvatarModel1.SetTarget(this.roleUIAvatar1,!0),this.displayUIAvatarModel1.SetDir(4),this.displayUIAvatarModel1.SetScale(.9,.9),
this.displayUIAvatarModel1.SetAct(a.Bv.FightIdle),this.displayUIAvatarModel2=new d.o,this.displayUIAvatarModel2.SetTarget(this.roleUIAvatar2,!0),
this.displayUIAvatarModel2.SetDir(4),this.displayUIAvatarModel2.SetScale(.8,.8),this.displayUIAvatarModel2.SetAct(a.Bv.FightIdle),this.displayUIAvatarModel3=new d.o,
this.displayUIAvatarModel3.SetTarget(this.roleUIAvatar3,!0),this.displayUIAvatarModel3.SetDir(4),this.displayUIAvatarModel3.SetScale(.8,.8),
this.displayUIAvatarModel3.SetAct(a.Bv.FightIdle)}OnReposition(){this.grid_quest.Reposition(),this.scroll_view.ResetPosition()}SetData(){
-1==this.interval&&(this.interval=c.C.Inst_get().SetInterval(this.CreateDelegate(this.OnEachSec),1e3)),
this.select_target_type=w.J.ins.target_type_dict.LuaDic_GetItem(L.K.ins.select_huodong_id)[0],this.AddLis(),this.OnEachSec(),this.UpdatePanel(),this.isInit||(this.isInit=!0,
this.InitRole()),this.scroll_view.scrollTo(0)}AddLis(){G.i.Inst.AddEventHandler(p.g.HUODONG_QUEST_CHANGE,this.CreateDelegate(this.UpdatePanel)),
G.i.Inst.AddEventHandler(p.g.RANK_DATA,this.CreateDelegate(this.OnGetRank)),G.i.Inst.AddEventHandler(p.g.RYALLIANCE_RANK_SHOWPLAYER,this.CreateDelegate(this.ShowRoleModel)),
G.i.Inst.AddEventHandler(p.g.QUERY_FIRST_PASS_MAP_NAME,this.CreateDelegate(this.QuestFirstPassMapName))}RemoveLis(){
G.i.Inst.RemoveEventHandler(p.g.HUODONG_QUEST_CHANGE,this.CreateDelegate(this.UpdatePanel)),G.i.Inst.RemoveEventHandler(p.g.RANK_DATA,this.CreateDelegate(this.OnGetRank)),
G.i.Inst.RemoveEventHandler(p.g.RYALLIANCE_RANK_SHOWPLAYER,this.CreateDelegate(this.ShowRoleModel)),
G.i.Inst.RemoveEventHandler(p.g.QUERY_FIRST_PASS_MAP_NAME,this.CreateDelegate(this.QuestFirstPassMapName))}OnClickReceiveReward(){
if(null!=this.commonTaskVo&&!this.commonTaskVo.isReward){const t=w.J.ins.GetQuestVoById(this.commonTaskVo.taskId)
R.l.ins.CM_GainActivitytaskReward(t.activityId,this.commonTaskVo.taskId)}}InitRole(){f.k.Inst_get().CM_GetRank(17,1,1)}OnGetRank(t){const e=t.rankInfos[0]
f.k.Inst_get().CM_QueryOtherPlayerVo(e.playerId,!0),this.playerNameLabel.textSet(e.name),this.countNumLabel.textSet(`已净化首领：${e.rankValue}个`)}UpdatePanel(){this.UpdateTargetType(),
this.UpdateCommonTaskActivity()}UpdateTargetType(){const e=D.i.ins.GetQuestListVoByIdAndTargetType(L.K.ins.select_huodong_id,this.select_target_type)
e.Sort(t.SortTask),this.grid_quest.node.SetActive(!0),this.grid_quest.data_set(e)}UpdateCommonTaskActivity(){const e=D.i.ins.GetQuestListVoByIdAndTargetType(1059,28)
e.Sort(t.SortTask)
let i=e[0]
const s=i.targetVos[0]
this.commTaskHadBuy.SetActive(!1),this.canGet.SetActive(!1),this.unGet.SetActive(!1),this.ui_baseitem.EnabledClickOpenTip(!0),this.ui_baseitem.ClickHandler_Set(null),
i.activityRewardVo.isReward?(this.commTaskHadBuy.SetActive(!0),i=e[e.Count()-1]):s.curValue.ToNum()>=s.targetValue.ToNum()?(this.ui_baseitem.EnabledClickOpenTip(!1),
this.canGet.SetActive(!0),this.ui_baseitem.ClickHandler_Set(this.CreateDelegate(this.OnClickReceiveReward))):this.unGet.SetActive(!0),this.commonTaskVo=i
const n=w.J.ins.GetQuestVoById(i.taskId),a=T.f.GetLinkInfo(new C.Z([n.targetText]),n.TargetDefs_Get(),i.targetVos)
this.commTaskDesLabel.textSet(a.GetTxtLabel())
const o=S.M.wrapReward(i.activityRewardVo.reward.rewards[0])
this.ui_baseitem.SetData(o)
const l=n.TargetDefs_Get().tCTargetDefs[0]
E.P.ins.CM_QueryFirstPassMapName(l.value)}OnEachSec(){
const t=D.i.ins.huodong_dict.LuaDic_GetItem(L.K.ins.select_huodong_id),e=m.p.FloorToInt(t.endTime.ToNum()/1e3)-u.D.serverTime_get()
e>0?this.timeTips.textSet(`[b09979]结束倒计时:[-] [5fb470]${A.l.GetDateFormatEX(e,!0,!0)}[-]`):this.timeTips.textSet("[b09979]已结束[-]")}InitPlayerModel(t,e){let i=new l.H
i.Job_set(t.job),i.Level_set(t.level),i.Sex_set(t.sex),i.horseId_set(t.hoserId),i.Name_set(t.name),i.equipmentStorageVO=t.equipmentStorageVO,
0==e?h.x.inst.SetUIAvatarData(i,r.v.role,this.displayUIAvatarModel1):1==e?h.x.inst.SetUIAvatarData(i,r.v.role,this.displayUIAvatarModel2):2==e&&h.x.inst.SetUIAvatarData(i,r.v.role,this.displayUIAvatarModel3)
}ShowRoleModel(){this.DestroyRole()
const t=y.K.Inst_get().checkRoleInfo
this.roleUIAvatar1.SetActive(!1),this.roleUIAvatar2.SetActive(!1),this.roleUIAvatar3.SetActive(!1),t[2]&&(this.roleUIAvatar3.SetActive(!0),this.InitPlayerModel(t[2],2)),
t[1]&&(this.roleUIAvatar2.SetActive(!0),this.InitPlayerModel(t[1],1)),t[0]&&(this.roleUIAvatar1.SetActive(!0),this.InitPlayerModel(t[0],0))}QuestFirstPassMapName(t){
let e=`（达成者：${t.passMapAccountName}）`
null!=t.passMapAccountName&&""!=t.passMapAccountName||(e="（达成者：暂无）"),this.firstCompletePlayerName.textSet(e)}static SortTask(t,e){
let i=w.J.ins.GetQuestVoById(t.taskId).sort,s=w.J.ins.GetQuestVoById(e.taskId).sort
return t.activityRewardVo.isReward&&(i+=1e11),e.activityRewardVo.isReward&&(s+=1e11),i-s}TargetTypes_Get(){
return w.J.ins.GetTargetTypesByHuoDongId(L.K.ins.select_huodong_id,v.h.ACTIVITY_SCORE)}DestroyRole(){}Clear(){this.RemoveLis(),super.Clear(),
-1!=this.interval&&(c.C.Inst_get().ClearInterval(this.interval),this.interval=-1),this.grid_quest.Clear()}})||s},11430:(t,e,i)=>{i.d(e,{$:()=>s})
class s{}s.UpateGoldCattleInfo=1,s.UpdateSpringCattleInfo=2,s.UpdateFiveBlessComeInfo=3,s.UpdateSpringCattleCopyStage=4,s.OpenLittleCattle=5,s.OpenBigCattle=6,s.PraySuccess=7,
s.LiveMonsterListUpdate=8},49831:(t,e,i)=>{i.d(e,{Q:()=>hi})
var s=i(71409),n=i(38836),a=i(38045),o=i(32309),l=i(97461),r=i(38952),h=i(38935),d=i(62370),u=i(56937),c=i(31222),_=i(5494),I=i(52726),g=i(995),m=i(98789),C=i(98885),S=i(85602),p=i(70850),A=i(59625),f=i(92679),y=i(85770),T=i(72800),R=i(75439),v=i(47786),w=i(92415),D=i(74305),E=i(81503),L=i(92841),G=i(85330),O=i(34877),b=i(5758),B=i(30362),N=i(73854),P=i(85605),M=i(82025),V=i(60567),k=i(60647),x=i(13487),H=i(65550),U=i(85942),F=i(99421),Y=i(12842),K=i(93727),z=i(11430),Q=i(11740),Z=i(5924),X=i(99294),j=i(9986),J=i(6665),W=i(78287),$=i(93877),q=i(72005),tt=i(61911),et=i(18202),it=i(83540),st=i(63076),nt=i(75696),at=i(18152),ot=i(87923),lt=i(33138)
class rt extends tt.f{constructor(...t){super(...t),this.oneHuntBtn=null,this.tenHuntBtn=null,this.effGo=null,this.confirmBtn=null,this.grid=null,this.desc=null,
this.rybeibao_sp_0044=null,this.ryxingkongmibao_sp_0003=null,this.bar=null,this.icon=null,this.tenHuntLabel=null,this.discountLabel=null,this.curshowRewardIdx=-1,this.timerId=-1,
this.isShowBtn=null,this.isPlaying=null,this.ret=null}InitView(){super.InitView(),this.oneHuntBtn=this.CreateComponent(j.W,1),this.tenHuntBtn=this.CreateComponent(j.W,2),
this.effGo=this.CreateComponent(X.z,3),this.confirmBtn=this.CreateComponent(j.W,4),this.grid=this.CreateComponent(J.A,5),this.desc=this.CreateComponent($.Q,6),
this.rybeibao_sp_0044=this.CreateComponent(X.z,7),this.ryxingkongmibao_sp_0003=this.CreateComponent(X.z,8),this.bar=this.CreateComponent(W._,9),
this.icon=this.CreateComponent(q.w,10),this.tenHuntLabel=this.CreateComponent($.Q,11),this.discountLabel=this.CreateComponent($.Q,12),
this.grid.SetInitInfo("ui_baseitem",this.CreateDelegate(this.OnItemRefreshFun)),this.grid.OnReposition_set(this.CreateDelegate(this.OnGridReposition))}OnItemRefreshFun(t){
const e=new nt.j
return e.setId(t,null,0),e.SetIconType(at.s.REWARD_ICON_TYPE),e}OnAddToScene(){this.effGo.SetActive(!1),this.AddLis(),this.UpdateView()}UpdateView(){this.effGo.SetActive(!1),
this.effGo.SetActive(!0),this.isShowBtn=!1,this.isPlaying=!0,this.curshowRewardIdx=-1,this.UpdateInfo(),this.UpdateMallInfo()
const t=lt.f.Inst().getItemById(Q.K.Inst_get().GetCelebrateKeyItemId())
null!=t&&et.g.SetItemIcon(this.icon.FatherId,this.icon.ComponentId,t.icon,it.b.eItem,!1)
const e=hi.Inst_get().sendTime
this.tenHuntLabel.textSet(`点燃${ot.l.getNumStr(e)}次(     ${Q.K.Inst_get().GetCelebrateConsumeNum(e)})`)
const i=Q.K.Inst_get().GetCelebrateDiscount()
10==i?this.discountLabel.SetActive(!1):(this.discountLabel.SetActive(!0),this.discountLabel.textSet(`${i}折`))}UpdateInfo(){
const t=K.i.ins.lotteryEndInfoDic[Y.t.SPRINGFESTIVAL_CELEBRATE]
if(null!=t){const e=new S.Z,i=t.lotteryIds
let s=0
for(let t=0;t<=i.count-1;t++){const n=K.i.ins.lotteryDic[Y.t.SPRINGFESTIVAL_CELEBRATE][i[t]]
s+=n.blessing
const a=n.reward.rewards
for(let t=0;t<=a.count-1;t++){const i=st.M.wrapReward(a[t])
e.Add(i)}}this.grid.data_set(e)}}UpdateMallInfo(){const t=V.P.ins.GetVoByHuodongIdAndType(Y.t.SPRINGFESTIVAL_SHOP,M.f.TICKET_TYPE)
this.desc.textSet(string.format("今日剩余次数 (%d/%d)",t.Remain_Num(),t.limit+1))}OnGridReposition(){for(const[t,e]of(0,n.V5)(this.grid.itemList))e.SetActive(!1)
this.StartRewardTimer()}StartRewardTimer(){-1!=this.timerId&&this.ClearTimer(),this.timerId=Z.C.Inst_get().SetInterval(this.CreateDelegate(this.DrawTimerHanler),200)}ClearTimer(){
-1!=this.timerId&&(Z.C.Inst_get().ClearInterval(this.timerId),this.timerId=-1)}DrawTimerHanler(){this.curshowRewardIdx+=1
let t=!1
this.grid.itemList[this.curshowRewardIdx]&&(t=!0,this.grid.itemList[this.curshowRewardIdx].SetActive(!0)),0==t&&(this.ClearTimer(),this.curshowRewardIdx=-1)}ItemAnimEndHandle(t){
null!=t&&null!=this.ret&&this.isShowBtn&&t>=this.ret.Count()-1&&(this.oneHuntBtn.node.SetActive(!0),this.tenHuntBtn.node.SetActive(!0),this.isPlaying=!1)}Clear(){this.RemoveLis(),
this.ClearTimer(),super.Clear()}Destroy(){super.Destroy()}AddLis(){this.m_handlerMgr.AddClickEvent(this.confirmBtn,this.CreateDelegate(this.OnCloseView)),
this.m_handlerMgr.AddClickEvent(this.tenHuntBtn,this.CreateDelegate(this.TenHuntBtnHandle)),
this.m_handlerMgr.AddEventMgr(f.g.HUODONG_MALL_BUY_CNT_LIST_CHANGE,this.CreateDelegate(this.UpdateMallInfo)),
this.AddFullScreenCollider(this.node,this.CreateDelegate(this.OnCloseView))}RemoveLis(){this.RemoveFullScreenCollider(this.node,this.CreateDelegate(this.OnCloseView))}
OnCloseView(){hi.Inst_get().CloseCelebrateResultView()}OneHuntBtnHandle(){hi.Inst_get().CloseCelebrateResultView(),hi.Inst_get().CelebrateGoHandle(hi.Inst_get().sendTime)}
TenHuntBtnHandle(){hi.Inst_get().CloseCelebrateResultView(),hi.Inst_get().CelebrateGoHandle(hi.Inst_get().sendTime)}}
var ht=i(98800),dt=i(9776),ut=i(32208),ct=i(68646),_t=i(9057),It=i(85751)
class gt extends _t.x{constructor(...t){super(...t),this.data=null,this.item1=null,this.item2=null,this.exchangeBtn=null,this.owner=null}InitView(){super.InitView(),
this.item1=this.CreateComponentBinder(nt.j,1),this.item2=this.CreateComponentBinder(nt.j,2),this.exchangeBtn=this.CreateComponent(j.W,3),this.owner=this.CreateComponent($.Q,4)}
SetData(t){this.data=t,this.owner.textSet(t.nickName)
const e=new st.M(t.cardId),i=new st.M(t.needCardId),s=p.g.Inst_get().GetItemNum(t.needCardId),n=s>0&&It.u.BrightGreenColorStr2||It.u.BrightRedColorStr2
e.showNum=!1,i.showNum=!0,i.SpecialNumStr=`拥有: ${n}${s}[-]`,this.item1.SetData(e),this.item2.SetData(i),
t.account==ht.Y.Inst.m_primaryRoleInfo.accountindex&&this.owner.textSet("我"),
t.account==ht.Y.Inst.m_primaryRoleInfo.accountindex||p.g.Inst_get().GetItemNum(t.needCardId)<=0?this.exchangeBtn.SetIsEnabled(!1):this.exchangeBtn.SetIsEnabled(!0),
this.m_handlerMgr.AddClickEvent(this.exchangeBtn,this.CreateDelegate(this.ExchangeClick))}ExchangeClick(){hi.Inst_get().ReqCM_CardConfirmChange(this.data.guid)}Clear(){
super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}}class mt extends tt.f{constructor(){super(),this.model=null,this.SelectIndex=0,this.HasCardForSort={},
this.HasCardCanExchangeForSort={},this.TabItemDataList=null,this.grid=null,this.contentScrollView=null,this.tabGrid=null,this.closeBtn=null,this.animTog=null,this.notCard=null,
this.TabItemDataList=new S.Z}InitView(){super.InitView(),this.grid=this.CreateComponent(J.A,1),this.contentScrollView=this.CreateComponent(dt.h,2),
this.tabGrid=this.CreateComponent(J.A,3),this.closeBtn=this.CreateComponent(j.W,7),this.animTog=this.CreateComponent(ut.r,8),this.notCard=this.CreateComponent(X.z,9),
this.model=Q.K.Inst_get(),this.tabGrid.SetInitInfo("ui_ry_right_tab5",null,ct.l,this.CreateDelegate(this._OnClickRightItem)),
this.tabGrid.OnReposition_set(this.CreateDelegate(this.OnRepositionTab)),this.grid.SetInitInfo("ui_sf_fiveblesscome_item3",null,gt,this.CreateDelegate(this._OnClickRightItem)),
this.grid.OnReposition_set(this.CreateDelegate(this.OnReposition))}OnAddToScene(){this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.OnClose)),
this.m_handlerMgr.AddClickEvent(this.animTog,this.CreateDelegate(this.AnimToggleHandle)),
this.model.AddEventHandler(z.$.UpdateFiveBlessComeInfo,this.CreateDelegate(this.UpdateContent)),this.UpdateDataForSort()
const t=this.model.GetFiveBlessConsumeList(),e=new S.Z
this.TabItemDataList.AddRange(t),this.TabItemDataList.Sort(this.CreateDelegate(this.SortCardTab))
for(const[t,i]of(0,n.V5)(this.TabItemDataList)){const t=i.cfgData_get().name
e.Add(t)}this.tabGrid.data_set(e),this.SelectIndex=0,this.UpdateContent(),hi.Inst_get().ReqFiveBlessInfo()}UpdateDataForSort(){
const t=this.model.FiveBlessComeInfo_get().changeInfoVos
this.HasCardForSort={},this.HasCardCanExchangeForSort={}
for(const[e,i]of(0,n.V5)(t))this.HasCardForSort[i.cardId]=!0,i.account!=ht.Y.Inst.m_primaryRoleInfo.accountindex&&p.g.Inst_get().GetItemNum(i.needCardId)>0&&(this.HasCardCanExchangeForSort[i.cardId]=!0)
}SortCardTab(t,e){const i=t.modelId_get(),s=e.modelId_get()
if(this.HasCardForSort[i]&&!this.HasCardForSort[s])return-1
if(!this.HasCardForSort[i]&&this.HasCardForSort[s])return 1
const n=this.model.RemindCardCanExchange_get(i),a=this.model.RemindCardCanExchange_get(s)
return n&&!a?-1:!n&&a?1:this.HasCardCanExchangeForSort[i]&&!this.HasCardCanExchangeForSort[s]?-1:!this.HasCardCanExchangeForSort[i]&&this.HasCardCanExchangeForSort[s]?1:i-s}
AnimToggleHandle(){const t=this.TabItemDataList[this.SelectIndex]
this.model.RemindCardCanExchange_set(t.modelId_get(),this.animTog.GetValue())}OnRepositionTab(){this.UpdateSelect()}OnReposition(){this.contentScrollView.ResetPosition()}
_OnClickRightItem(t,e,i){const s=this.tabGrid.itemList.IndexOf(t)
this.SelectIndex=s,this.UpdateSelect(),this.UpdateContent()}UpdateContent(){
const t=this.model.FiveBlessComeInfo_get().changeInfoVos,e=this.TabItemDataList[this.SelectIndex],i=new S.Z
if(e)for(const[s,a]of(0,n.V5)(t))a.cardId==e.modelId_get()&&i.Add(a)
this.grid.data_set(i),this.notCard.SetActive(i.Count()<=0),this.contentScrollView.SetActive(i.Count()>0),
this.animTog.SetValue(this.model.RemindCardCanExchange_get(e.modelId_get()))}UpdateSelect(){for(let t=0;t<=this.tabGrid.itemList.Count()-1;t++){
this.tabGrid.itemList[t].SetSelect(this.SelectIndex==t)}}OnClose(){hi.Inst_get().CloseFiveBlessComeExchangeView()}Clear(){
this.model.RemoveEventHandler(z.$.UpdateFiveBlessComeInfo,this.CreateDelegate(this.UpdateContent)),super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}}
var Ct=i(74657)
class St extends tt.f{constructor(...t){super(...t),this.desc=null,this.comfirmBtn=null,this.comfirmLbl=null,this.title=null,this.ScrollView=null,this.MyGrid=null,this.mask=null}
InitView(){super.InitView(),this.desc=this.CreateComponent($.Q,1),this.comfirmBtn=this.CreateComponent(j.W,2),this.comfirmLbl=this.CreateComponent($.Q,3),
this.title=this.CreateComponent(q.w,4),this.ScrollView=this.CreateComponent(dt.h,5),this.MyGrid=this.CreateComponent(J.A,6),this.mask=this.CreateComponent(X.z,7),
this.MyGrid.SetInitInfo("ui_baseitem",null,nt.j)}OnAddToScene(){this.desc.textSet("")
const t=Q.K.Inst_get().GetFiveBlessComeCfg()
for(const[e,i]of(0,n.V5)(t)){const t=i.rewardDefs
if(i.id==Q.K.Inst_get().newFiveBlessComePrayHit){const e=Ct.A.GetReward(t).GetRewardBaseItemList()
e[0].isBigPrize=i.prize,this.MyGrid.data_set(e)
break}}this.m_handlerMgr.AddClickEvent(this.mask,this.CreateDelegate(this.OnClose)),this.m_handlerMgr.AddClickEvent(this.comfirmBtn,this.CreateDelegate(this.OnClose))}OnClose(){
hi.Inst_get().CloseFiveBlessComeRewardView()}Clear(){super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}}var pt=i(48933),At=i(14792)
class ft extends _t.x{constructor(...t){super(...t),this.itemData=null,this.icon=null,this.count=null,this.widget=null}InitView(){super.InitView(),
this.icon=this.CreateComponent(q.w,1),this.count=this.CreateComponent($.Q,2),this.widget=this.CreateComponent(X.z,4),this.name=this.CreateComponent($.Q,5)}SetData(t,e){
this.itemData=t,this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.ClickItem)),this.name.textSet(this.itemData.cfgData_get().name),this.count.SetActive(!0),
e?e<0&&this.count.SetActive(!1):e=p.g.Inst_get().GetItemNum(this.itemData.modelId_get()),this.count.textSet(e),
this.icon.spriteNameSet(Q.K.Inst_get().GetCardName(this.itemData.modelId_get()))}ClickItem(){
this.onClick?this.onClick(this.ComponentId,this.FatherId):INS.itemTipManager.OpenTipView(this.itemData)}Clear(){super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){
return!0}}var yt=i(63921)
class Tt extends _t.x{constructor(...t){super(...t),this.index=0,this.content=null,this.widget=null,this.select=null}InitView(){super.InitView(),
this.name=this.CreateComponent($.Q,3),this.widget=this.CreateComponent(X.z,4),this.select=this.CreateComponent(X.z,5)}SetData(t){this.name.textSet(t),this.SetItemClickGo(this.node)
}SetNamePivotCenter(){this.name.pivotSet(yt.F.eCenter),this.name.SetLocalPositionXYZ(0,0,0)}SetNamePivotLeft(){this.name.pivotSet(yt.F.eLeft),this.name.SetLocalPositionXYZ(-50,0,0)
}Clear(){super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}}var Rt=i(66788)
class vt extends _t.x{constructor(...t){super(...t),this.data=null,this.widget=null,this.wanttxt=null,this.item=null,this.wantUIPanel=null,this.wantGrid=null,this.shareObj=null}
InitView(){super.InitView(),this.widget=this.CreateComponent(X.z,2),this.wanttxt=this.CreateComponent($.Q,3),this.item=this.CreateComponentBinder(ft,4)}SetData(t){this.data=t
const e=lt.f.Inst().getItemById(t.needCardId),i=new st.M(t.cardId)
this.item.SetData(i,-1),this.item.SetColliderEnable(!1),this.SetItemClickGo(this.node),this.wanttxt.textSet(`需要：${e.name}`)}SetPanelDepth(t){this.wantUIPanel.depthSet(t)}
OnClickItem(t,e,i){const s=this.wantGrid.itemList.IndexOf(t)
Rt.Y.LogError(`OnClickItem ${(0,a.tw)(s)}`)}OnClickMask(){this.shareObj.SetActive(!1)}ClickItem(){this.shareObj.SetActive(!0)}Clear(){super.Clear()}Destroy(){super.Destroy()}
Test1(){return!0}S_Test(){return!0}}class wt extends tt.f{constructor(){super(),this.model=null,this.SelectIndex=0,this.GiveItemData=null,this.WantItemData=null,
this.tmpWantItemList=null,this.OperateItemInfo=null,this.title=null,this.closeBtn=null,this.tabGrid=null,this.tosharepanel=null,this.sharedpanel=null,this.sureBtn=null,
this.wantScrollView=null,this.wantGrid=null,this.wantPanelPos=null,this.giveBtn=null,this.cartItem=null,this.emptyIcon=null,this.wantBtn=null,this.cardItem2=null,
this.emptyIcon2=null,this.cardScrollView=null,this.cardGrid=null,this.getBtn=null,this.wantPanel=null,this.mask=null,this.operateObj=null,this.operateMask=null,
this.operatePos=null,this.operateGrid=null,this.notCard=null,this.storeGrid=null,this.storeScrollView=null,this.storeEmpty=null,this.itemPivotLeft=null,this.tmpWantItemList=new S.Z
}InitView(){super.InitView(),this.title=this.CreateComponent($.Q,1),this.closeBtn=this.CreateComponent(X.z,2),this.tabGrid=this.CreateComponent(J.A,3),
this.tosharepanel=this.CreateComponent(X.z,4),this.sharedpanel=this.CreateComponent(X.z,5),this.sureBtn=this.CreateComponent(j.W,6),
this.wantScrollView=this.CreateComponent(dt.h,7),this.wantGrid=this.CreateComponent(J.A,8),this.wantPanelPos=this.CreateComponent(X.z,9),this.giveBtn=this.CreateComponent(X.z,10),
this.cartItem=this.CreateComponentBinder(ft,11),this.emptyIcon=this.CreateComponent(X.z,12),this.wantBtn=this.CreateComponent(X.z,13),
this.cardItem2=this.CreateComponentBinder(ft,14),this.emptyIcon2=this.CreateComponent(X.z,15),this.cardScrollView=this.CreateComponent(dt.h,16),
this.cardGrid=this.CreateComponent(J.A,17),this.getBtn=this.CreateComponent(j.W,18),this.wantPanel=this.CreateComponent(X.z,20),this.mask=this.CreateComponent(X.z,21),
this.operateObj=this.CreateComponent(X.z,22),this.operateMask=this.CreateComponent(X.z,23),this.operatePos=this.CreateComponent(X.z,24),
this.operateGrid=this.CreateComponent(J.A,25),this.notCard=this.CreateComponent(X.z,26),this.storeGrid=this.CreateComponent(J.A,27),
this.storeScrollView=this.CreateComponent(dt.h,28),this.storeEmpty=this.CreateComponent(X.z,29),this.model=Q.K.Inst_get(),
this.tabGrid.SetInitInfo("ui_ry_right_tab5",null,ct.l,this.CreateDelegate(this._OnClickRightItem)),this.tabGrid.OnReposition_set(this.CreateDelegate(this.OnReposition)),
this.wantGrid.SetInitInfo("ui_sf_fiveblesscome_item2",null,Tt,this.CreateDelegate(this._OnClickItem)),this.wantGrid.OnReposition_set(this.CreateDelegate(this.OnRepositionTab)),
this.cardGrid.SetInitInfo("ui_sf_fiveblesscome_item4",null,vt,this.CreateDelegate(this._OnClickCardItem)),
this.cardGrid.OnReposition_set(this.CreateDelegate(this.OnRepositionCard)),
this.operateGrid.SetInitInfo("ui_sf_fiveblesscome_item2",null,Tt,this.CreateDelegate(this._OnClickOperateItem)),this.storeGrid.SetInitInfo("ui_baseitem",null,nt.j),
this.storeGrid.OnReposition_set(this.CreateDelegate(this.OnRepositionStore))}OnAddToScene(){this.SelectIndex=0,this.GiveItemData=null,this.WantItemData=null,
this.tabGrid.data_set(new S.Z(["待上架","已上架"])),this.UpdateSelect(),this.UpdateToSharePanel(),this.UpdateContent(),this.OnClickOperateMask(),this.OnClickMask(),
this.operateGrid.data_set(new S.Z(["分享战盟","分享世界","下架"])),this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.OnClose)),
this.m_handlerMgr.AddClickEvent(this.sureBtn,this.CreateDelegate(this.OnClickSure)),this.m_handlerMgr.AddClickEvent(this.giveBtn,this.CreateDelegate(this.OnClickGive)),
this.m_handlerMgr.AddClickEvent(this.wantBtn,this.CreateDelegate(this.OnClickWant)),this.m_handlerMgr.AddClickEvent(this.getBtn,this.CreateDelegate(this.OnClickGet)),
this.m_handlerMgr.AddClickEvent(this.mask,this.CreateDelegate(this.OnClickMask)),this.m_handlerMgr.AddClickEvent(this.operateMask,this.CreateDelegate(this.OnClickOperateMask)),
this.model.AddEventHandler(z.$.UpdateFiveBlessComeInfo,this.CreateDelegate(this.UpdateContent)),hi.Inst_get().ReqFiveBlessInfo()}OnClickOperateMask(){this.operateObj.SetActive(!1)}
OnClickMask(){this.wantPanel.SetActive(!1)}OnClickGet(){this.model.GetSuccessShareCardCount()>0&&hi.Inst_get().ReqCM_RewardCard()}OnClickGive(){this.itemPivotLeft=!0,
this.tmpWantItemList.Clear()
const t=this.model.GetFiveBlessConsumeList(),e=new S.Z
for(const[i,s]of(0,n.V5)(t)){const t=s.modelId_get(),i=p.g.Inst_get().GetItemNum(t)
if(i>0){const t=`${s.cfgData_get().name}(${i})`
e.Add(t),this.tmpWantItemList.Add(s)}}if(e.Count()<=0)return this.tmpWantItemList.Clear(),void H.y.inst.ClientSysStrMsg("无可上架福卡")
this.wantPanel.SetActive(!0),this.wantPanelPos.SetLocalPositionXYZ(-117,0,0),this.wantGrid.data_set(e)}OnClickWant(){
if(!this.GiveItemData)return void H.y.inst.ClientSysStrMsg("请先选择上架福卡")
this.itemPivotLeft=!1,this.wantPanel.SetActive(!0),this.wantPanelPos.SetLocalPositionXYZ(364,0,0),this.tmpWantItemList.Clear()
const t=this.model.GetFiveBlessConsumeList(),e=new S.Z
for(const[i,s]of(0,n.V5)(t)){if(s.modelId_get()!=this.GiveItemData.modelId_get()){const t=s.cfgData_get().name
e.Add(t),this.tmpWantItemList.Add(s)}}this.wantGrid.data_set(e)}OnClickSure(){
this.GiveItemData&&this.WantItemData&&(hi.Inst_get().ReqCM_CardApplyChange(this.GiveItemData.modelId_get(),this.WantItemData.modelId_get()),this.GiveItemData=null,
this.WantItemData=null,this.UpdateToSharePanel())}OnClose(){hi.Inst_get().CloseFiveBlessComeShareView()}OnRepositionStore(){
this.storeGrid.itemList.Count()>5&&this.storeScrollView.ResetPosition()}OnRepositionCard(){this.cardScrollView.ResetPosition(),this.operateObj.SetActive(!1)}OnRepositionTab(){
for(const[t,e]of(0,n.V5)(this.wantGrid.itemList))this.itemPivotLeft?e.SetNamePivotLeft():e.SetNamePivotCenter()
this.wantScrollView.ResetPosition()}OnReposition(){this.tabGrid.itemList[1].SetRedPointId(At.t.FIVEBLESSCOME_CANGETCARD),this.UpdateSelect()}_OnClickOperateItem(t,e,i){
const s=this.operateGrid.itemList.IndexOf(t)
0==s?hi.Inst_get().ReqCM_ShareChangeInfo(1,this.OperateItemInfo.guid):1==s?hi.Inst_get().ReqCM_ShareChangeInfo(2,this.OperateItemInfo.guid):2==s&&hi.Inst_get().ReqCM_CardCancelChange(this.OperateItemInfo.guid),
this.OnClickOperateMask()}_OnClickCardItem(t,e,i){const s=this.cardGrid.itemList.IndexOf(t),n=this.cardGrid.itemList[s]
pt.I.calVec0.Set(100,50,0)
const a=n.TransformPoint(pt.I.calVec0),o=this.operateObj.InverseTransformPoint(a)
this.operateObj.SetActive(!0),this.OperateItemInfo=this.cardGrid.data_get()[s],this.operatePos.SetLocalPosition(o)}_OnClickItem(t,e,i){
const s=this.wantGrid.itemList.IndexOf(t),n=this.wantPanelPos.GetLocalPositionXYZ()<0,a=this.tmpWantItemList[s]
n?this.GiveItemData=a:this.WantItemData=a,this.UpdateToSharePanel(),this.OnClickMask()}_OnClickRightItem(t,e,i){const s=this.tabGrid.itemList.IndexOf(t)
this.SelectIndex=s,this.UpdateSelect()}UpdateSelect(){this.tosharepanel.SetActive(0==this.SelectIndex),this.sharedpanel.SetActive(0!=this.SelectIndex)
for(let t=0;t<=this.tabGrid.itemList.Count()-1;t++){this.tabGrid.itemList[t].SetSelect(this.SelectIndex==t)}}UpdateContent(){
const t=this.model.FiveBlessComeInfo_get().cardStore,e=new S.Z
for(const[i,s]of(0,n.V5)(t))if(s>0){const t=new st.M(i)
t.count=s,e.Add(t)}this.storeGrid.data_set(e),this.storeEmpty.SetActive(e.Count()<=0),this.storeScrollView.SetActive(e.Count()>0),this.getBtn.SetIsEnabled(e.Count()>0)
const i=this.model.FiveBlessComeInfo_get().changeInfoVos,s=new S.Z
for(const[t,e]of(0,n.V5)(i))e.account==ht.Y.Inst.m_primaryRoleInfo.accountindex&&s.Add(e)
this.cardScrollView.SetActive(s.Count()>0),this.notCard.SetActive(s.Count()<=0),s.Count()>0&&this.cardGrid.data_set(s)}UpdateToSharePanel(){
this.emptyIcon.SetActive(null==this.GiveItemData),this.cartItem.SetActive(null!=this.GiveItemData),this.GiveItemData&&this.cartItem.SetData(this.GiveItemData,-1),
this.emptyIcon2.SetActive(null==this.WantItemData),this.cardItem2.SetActive(null!=this.WantItemData),this.WantItemData&&this.cardItem2.SetData(this.WantItemData,-1),
this.GiveItemData&&this.WantItemData?this.sureBtn.SetIsEnabled(!0):this.sureBtn.SetIsEnabled(!1)}Clear(){
this.model.RemoveEventHandler(z.$.UpdateFiveBlessComeInfo,this.CreateDelegate(this.UpdateContent)),super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}}
var Dt=i(19519)
class Et extends tt.f{constructor(...t){super(...t),this.desc=null,this.comfirmBtn=null,this.comfirmLbl=null,this.smallcattle=null,this.bigcattle=null,this.desc2=null,
this.desc3=null,this.mask=null,this.MyGrid1=null,this.MyGrid2=null,this.MyGrid3=null}InitView(){super.InitView(),this.desc=this.CreateComponent($.Q,1),
this.comfirmBtn=this.CreateComponent(j.W,2),this.comfirmLbl=this.CreateComponent($.Q,3),this.smallcattle=this.CreateComponent(X.z,4),this.bigcattle=this.CreateComponent(X.z,5),
this.desc2=this.CreateComponent($.Q,9),this.desc3=this.CreateComponent($.Q,10),this.mask=this.CreateComponent(X.z,11),this.MyGrid1=this.CreateComponent(J.A,12),
this.MyGrid2=this.CreateComponent(J.A,13),this.MyGrid3=this.CreateComponent(J.A,14),this.MyGrid1.SetInitInfo("ui_baseitem",null,nt.j),
this.MyGrid2.SetInitInfo("ui_baseitem",null,nt.j),this.MyGrid3.SetInitInfo("ui_baseitem",null,nt.j)}Clear(){super.Clear()}OnAddToScene(){
const t=Q.K.Inst_get().newBigCattleInfo,e=(Q.K.Inst_get().newLittleCattleInfo,Q.K.Inst_get().openLittleCattleInfo_get())
Dt.J.GetItemID(Dt.J.GOLD_DIAMOND),Dt.J.GetItemID(Dt.J.GOLD_DIAMOND)
if(this.smallcattle.SetActive(!1),this.bigcattle.SetActive(!1),e){this.smallcattle.SetActive(!0)
const t=new S.Z
for(const[i,s]of(0,n.V5)(e.fixReward.rewards))t.Add(st.M.wrapReward(s))
const i=new S.Z
for(const[t,s]of(0,n.V5)(e.randReward.rewards))i.Add(st.M.wrapReward(s))
this.MyGrid1.data_set(t),this.MyGrid2.data_set(i)}else if(t){this.bigcattle.SetActive(!0)
const e=new S.Z
for(const[i,s]of(0,n.V5)(t.andReward.rewards))e.Add(st.M.wrapReward(s))
this.MyGrid3.data_set(e)}this.m_handlerMgr.AddClickEvent(this.comfirmBtn,this.CreateDelegate(this.OnClose))}OnClose(){hi.Inst_get().CloseGoldCattleRewardView()}Destroy(){
super.Destroy()}Test1(){return!0}S_Test(){return!0}}
var Lt=i(68662),Gt=i(36334),Ot=i(44255),bt=i(60130),Bt=i(79534),Nt=i(53905),Pt=i(28287),Mt=i(65772),Vt=i(56834),kt=i(43977),xt=i(50089),Ht=i(41664),Ut=i(30267),Ft=i(32759),Yt=i(8889),Kt=i(13113),zt=i(51868),Qt=i(61613),Zt=i(29479),Xt=i(23649),jt=i(50426)
class Jt extends _t.x{constructor(...t){super(...t),this.data=null,this.titleTxt=null,this.grid=null,this.widget=null,this.leftSp=null,this.rightSp=null,this.welfareTxt=null,
this.big=null,this.normal=null,this.gridBig=null,this.welfareTxtBig=null}InitView(){super.InitView(),this.titleTxt=this.CreateComponent($.Q,1),
this.grid=this.CreateComponent(J.A,2),this.widget=this.CreateComponent(Kt.T,3),this.leftSp=this.CreateComponent(X.z,5),this.rightSp=this.CreateComponent(X.z,6),
this.welfareTxt=this.CreateComponent($.Q,7),this.big=this.CreateComponent(X.z,8),this.normal=this.CreateComponent(X.z,9),this.gridBig=this.CreateComponent(J.A,10),
this.welfareTxtBig=this.CreateComponent($.Q,12),this.grid.SetInitInfo("ui_baseitem",null,nt.j),this.gridBig.SetInitInfo("ui_baseitem",null,nt.j)}SetData(t){this.AddLis()
const e=t,i=K.i.ins.GetConfigVoByType(Y.t.SPRINGFESTIVAL_CELEBRATE,e),s=new S.Z
for(let t=0;t<=i.Count()-1;t++){const e=i[t].reward.rewards
for(let t=0;t<=e.count-1;t++){const i=st.M.wrapReward(e[t])
s.Add(i)}}if(1==e){this.big.SetActive(!0),this.normal.SetActive(!1),this.widget.heightSet(114),this.gridBig.data_set(s),this.welfareTxtBig.SetActive(!0)
const t=K.i.ins.lotteryInfoDic[Y.t.SPRINGFESTIVAL_CELEBRATE],e=i[0].safeTime,n=i[0].limit
null!=t.lotteryId2Count[i[0].id]&&t.lotteryId2Count[i[0].id]>=n?this.welfareTxtBig.textSet(v.x.Inst().getItemStrById(11043261)):this.welfareTxtBig.textSet(`点燃${It.u.GreenColorStr2}${e-t.bigRewardUnHitCount}次[-]必出`)
}else this.big.SetActive(!1),
this.normal.SetActive(!0),e==Q.K.Inst_get().lotteryMaxType?this.widget.heightSet(84+60*(Math.ceil(i.Count()/3)-1)):this.widget.heightSet(70+60*(Math.ceil(i.Count()/3)-1)),
this.grid.data_set(s),this.welfareTxt.SetActive(!1)
1==e?this.titleTxt.textSet("鸿运大奖"):2==e?this.titleTxt.textSet("福星奖"):3==e?this.titleTxt.textSet("吉祥奖"):this.titleTxt.textSet("如意奖"),
this.leftSp.SetLocalPositionXYZ(-this.titleTxt.width()/2-6,-9,0),this.rightSp.SetLocalPositionXYZ(this.titleTxt.width()/2+6,-9,0)}AddLis(){}RemoveLis(){}Clear(){this.grid.Clear(),
this.RemoveLis(),super.Clear()}Destroy(){this.grid.Destroy(),super.Destroy()}}
var Wt=i(43662),$t=i(61447),qt=i(59475),te=i(45404),ee=i(31546),ie=i(16261),se=i(21554),ne=i(38908),ae=i(13476),oe=i(11037)
class le extends _t.x{constructor(){super(),this.huodongQuestVo=null,this.targetVo=null,this.rewardVo=null,this.qualityNameLis=null,this.timeTxt=null,this.icon=null,
this.canGetGo=null,this.hasGetGo=null,this.bg=null,this.numTxt=null,this.texture=null,this.normal=null,this.big=null,this.m_horse=null,this.horseCfg=null,
this.qualityNameLis=new S.Z(["rychunjiefufei_sp_0012","rychunjiefufei_sp_0016","rychunjiefufei_sp_0016","rychunjiefufei_sp_0015","rychunjiefufei_sp_0013","rychunjiefufei_sp_0014","rychunjiefufei_sp_0014"])
}InitView(){super.InitView(),this.timeTxt=this.CreateComponent($.Q,1),this.icon=this.CreateComponent(q.w,2),this.canGetGo=this.CreateComponent(q.w,3),
this.hasGetGo=this.CreateComponent(q.w,4),this.bg=this.CreateComponent(q.w,5),this.numTxt=this.CreateComponent($.Q,6),this.texture=this.CreateComponent(ie.X,7),
this.normal=this.CreateComponent(X.z,8),this.big=this.CreateComponent(X.z,9),this.texture.SetLocalPositionXYZ(13.6,21.4,0)}SetData(t){this.AddLis(),this.huodongQuestVo=t,
this.targetVo=this.huodongQuestVo.targetVos[0],this.rewardVo=this.huodongQuestVo.activityRewardVo,this.UpdatePanel()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.OnClick))}RemoveLis(){}Clear(){super.Clear(),this.RemoveLis()}Destroy(){
null!=this.m_horse&&(this.m_horse.Destroy(),this.m_horse=null,Wt.M.Instance_get().DeactiveStage(le.STAGE_ID,this.texture.FatherId,this.texture.ComponentId)),et.g.DestroyUIObj(),
super.Destroy()}UpdatePanel(){this.hasGetGo.SetActive(!1),this.canGetGo.SetActive(!1),this.numTxt.node.SetActive(!1)
const t=st.M.wrapReward(this.rewardVo.reward.rewards[0])
this.rewardVo.isReward?this.hasGetGo.SetActive(!0):this.targetVo.curValue.ToNum()>=this.targetVo.targetValue.ToNum()&&this.canGetGo.SetActive(!0),
this.bg.spriteNameSet(this.qualityNameLis[t.Quality_get()]),t.count>1&&(this.numTxt.node.SetActive(!0),this.numTxt.textSet(t.count)),
et.g.SetItemIcon(this.icon.FatherId,this.icon.ComponentId,t.cfgData_get().icon,it.b.eItem,!1),this.timeTxt.textSet(this.targetVo.targetValue.ToNum()),
this.index==le.maxIndex?(this.normal.SetActive(!1),this.big.SetActive(!0),this.node.SetLocalScaleXYZ(1.2,1.2,1.2),this.horseCfg=oe.D.GetInst().getActiviteCfg(t.cfgData_get().id),
this.horseCfg&&this.SetModel()):(this.normal.SetActive(!0),this.big.SetActive(!1))}SetModel(){const t=new $t.V,e=new ee.O
e._displayID=this.horseCfg.modelId,e._displayID=ae.E.Instance.TryReplaceDisplayID(ne.C.ReplaceTypeRIDING,e._displayID),Wt.M.Instance_get().ActiveStage(le.STAGE_ID),
e._world=Wt.M.Instance_get().GetStageWorldType(le.STAGE_ID)
const i=C.M.Split(this.horseCfg.parameter,d.o.s_Arr_UNDER_CHAR_DOT)
e._vPos.Set(0,0),e._fSize=C.M.String2Float(i[2])
let s=180
i.count>3&&(s=C.M.String2Float(i[3])),e._fDir=s,null==this.m_horse?(this.m_horse=new qt.t,this.m_horse.Info_set(t),this.m_horse.Owner_set(null),
this.m_horse.initByDisinfo(e)):(this.m_horse.Destroy(),this.m_horse=new qt.t,this.m_horse.Info_set(t),this.m_horse.Owner_set(null),this.m_horse.initByDisinfo(e)),
te.n.Instance_get().SetDisplayObject(le.STAGE_ID,this.m_horse.MainRole_get().handle,0),this.texture.SetMainTextureByPhoto(le.STAGE_ID),this.m_horse.MainRole_get().SetDirection(s),
this.m_horse.MainRole_get().DisableShadow()
const n=Wt.M.Instance_get().GetDisplayHeight(le.STAGE_ID,0)
this.m_horse.MainRole_get().SetCastShadow(!0),this.m_horse.MainRole_get().SetShadowHeight(n)}OnClick(){
if(this.targetVo.curValue.ToNum()>=this.targetVo.targetValue.ToNum()&&!this.rewardVo.isReward)return void F.l.ins.CM_GainActivitytaskReward(Y.t.SPRINGFESTIVAL_CELEBRATE,this.huodongQuestVo.taskId)
const t=st.M.wrapReward(this.rewardVo.reward.rewards[0])
se.J.Inst_get().OpenTipView(t)}}le.maxIndex=0,le.STAGE_ID=170
class re extends zt.${static __StaticInit(){re.ITEM_WIDTH=13}constructor(){super(),this.goOneBtn=null,this.goTenBtn=null,this.animTog=null,this.icon1=null,this.icon2=null,
this.tenRedPoint=null,this.oneRedPoint=null,this.left=null,this.right=null,this.bigPrizeDesc=null,this.poolTable=null,this.rewardView=null,this.bigPrizeItem2=null,
this.rewardTween=null,this.bigPrizeSp1=null,this.bigPrizeSp2=null,this.timeGrid=null,this.timeScrollView=null,this.lineBg=null,this.lightLine=null,this.bg=null,this.leftTween=null,
this.rightTween=null,this.topTween=null,this.bottomTween=null,this.clipPanel=null,this.time=null,this.openTimeTxt=null,this.drawTimeTxt=null,this.welfareTipBtn=null,
this.discountLabel=null,this.pre_eff_springfestival01_01=null,this.pre_eff_springfestival02_01=null,this.pre_eff_springfestival03_01=null,this.pre_eff_springfestival04_01=null,
this.pre_eff_springfestival04_02=null,this.pre_eff_springfestival07_01=null,this.pre_eff_springfestival08_01=null,this.roketSp=null,this.isShowReward=!1,this.isShowExchange=!1,
this.bigPrizeMininum=null,this.isPlayingAnim=!1,this.curPoint=null,this.delay=null,this.effTimer=null,this.bigPrizeMininum=R.D.getInstance().GetIntValue("GLORYCALL:MINIMUN")}
InitView(){super.InitView(),this.goOneBtn=this.CreateComponent(j.W,1),this.goTenBtn=this.CreateComponent(j.W,2),this.animTog=this.CreateComponent(ut.r,3),
this.icon1=this.CreateComponent(q.w,4),this.icon2=this.CreateComponent(q.w,5),this.tenRedPoint=this.CreateComponent(X.z,6),this.oneRedPoint=this.CreateComponent(X.z,7),
this.left=this.CreateComponent(Kt.T,8),this.right=this.CreateComponent(Kt.T,9),this.bigPrizeDesc=this.CreateComponent($.Q,10),this.poolTable=this.CreateComponent(Ut.V,11),
this.rewardView=this.CreateComponent(X.z,12),this.bigPrizeItem2=this.CreateComponent(X.z,13),this.rewardTween=this.CreateComponent(X.z,14),
this.bigPrizeSp1=this.CreateComponent(X.z,15),this.bigPrizeSp2=this.CreateComponent(X.z,16),this.timeGrid=this.CreateComponent(J.A,17),
this.timeScrollView=this.CreateComponent(dt.h,18),this.lineBg=this.CreateComponent(q.w,19),this.lightLine=this.CreateComponent(q.w,20),this.bg=this.CreateComponent(q.w,21),
this.leftTween=this.CreateComponent(Ft.c,22),this.rightTween=this.CreateComponent(Ft.c,23),this.topTween=this.CreateComponent(Ft.c,24),
this.bottomTween=this.CreateComponent(Ft.c,25),this.clipPanel=this.CreateComponent(Yt.$,26),this.time=this.CreateComponent(X.z,27),this.openTimeTxt=this.CreateComponent($.Q,28),
this.drawTimeTxt=this.CreateComponent($.Q,29),this.welfareTipBtn=this.CreateComponent(j.W,30),this.discountLabel=this.CreateComponent($.Q,31),
this.pre_eff_springfestival01_01=this.CreateComponent(X.z,32),this.pre_eff_springfestival02_01=this.CreateComponent(X.z,33),
this.pre_eff_springfestival03_01=this.CreateComponent(X.z,34),this.pre_eff_springfestival04_01=this.CreateComponent(X.z,35),
this.pre_eff_springfestival04_02=this.CreateComponent(X.z,36),this.pre_eff_springfestival07_01=this.CreateComponent(X.z,37),
this.pre_eff_springfestival08_01=this.CreateComponent(X.z,38),this.roketSp=this.CreateComponent(X.z,39),
this.poolTable.SetInitInfo("ui_springfestival_celebratepoolitem_ry",this.CreateDelegate(this.CreateItemHandler)),
this.timeGrid.SetInitInfo("ui_springfestival_celebratetimeitem_ry",null,le),bt.O.SetAnchorPos(this.left,!0,!1,0),bt.O.SetAnchorPos(this.right,!1,!1,0)
const t=xt.t.GetUIWidth(),e=this.clipPanel.GetRect()
e.width_set(t-133),this.clipPanel.SetRect(-68,-6,e.width,e.height)}CreateItemHandler(t){const e=new Jt
return e.setId(t,null,0),e}ShowCurrencyBar_get(){return Pt._.ShowDia}SetData(){const t=lt.f.Inst().getItemById(Q.K.Inst_get().GetCelebrateKeyItemId())
null!=t&&(et.g.SetItemIcon(this.icon1.FatherId,this.icon1.ComponentId,t.icon,it.b.eItem,!1),et.g.SetItemIcon(this.icon2.FatherId,this.icon2.ComponentId,t.icon,it.b.eItem,!1)),
this.PlayForward(),this.AddLis(),this.UpdateInfo()}Clear(){this.PlayReverse(),this.RemoveLis(),this.ClearEffTimeHandle(),super.Clear()}Destroy(){super.Destroy()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.animTog,this.CreateDelegate(this.AnimToggleHandle)),this.m_handlerMgr.AddClickEvent(this.goOneBtn,this.CreateDelegate(this.GoOneBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.goTenBtn,this.CreateDelegate(this.GoTenBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.welfareTipBtn,this.CreateDelegate(this.WelfareBtnHandle)),
this.m_handlerMgr.AddEventMgr(f.g.HUODONG_QUEST_CHANGE,this.CreateDelegate(this.UpdateWelfareValue)),
this.m_handlerMgr.AddEventMgr(f.g.BAG_UPDATE,this.CreateDelegate(this.BagUpdateHandle)),
this.m_handlerMgr.AddEventMgr(f.g.OPEN_LOTTERY_SUCCESS,this.CreateDelegate(this.OpenSuccessHandle)),
this.m_handlerMgr.AddEventMgr(f.g.UPDATE_LOTTERY_INFO,this.CreateDelegate(this.UpdateRewardInfo)),
this.m_handlerMgr.AddEventMgr(f.g.HUODONG_MALL_BUY_CNT_LIST_CHANGE,this.CreateDelegate(this.UpdateRewardInfo))}BagUpdateHandle(){
Q.K.Inst_get().IsSatisfyKeyNum()||K.i.ins.HasFreeOpenTime(Y.t.SPRINGFESTIVAL_CELEBRATE)?this.oneRedPoint.SetActive(!0):this.oneRedPoint.SetActive(!1)}GetFirstSpacing(){
return Qt.v.GetAdaptionWidth(97,97)}GetSpacing(){return Qt.v.GetAdaptionWidth(142.2*.8,142.2*.8)}GetSpacingByIndex(t){let e=1
return e=1==t?this.GetFirstSpacing():this.GetSpacing(),e}UpdateWelfareValue(){this.curPoint=0
const t=K.i.ins.GetQuestListVoByIdAndTargetType(Y.t.SPRINGFESTIVAL_CELEBRATE,Xt.h.SPRING_WELFARE_VALUE)
le.maxIndex=t.Count()-1,this.timeGrid.SetLocalScaleXYZ(.8,.8,.8),this.timeGrid.data_set(t)
let e=!1
for(let i=0;i<=t.Count()-1;i++)this.curPoint<t[i].targetVos[0].curValue.ToNum()&&(this.curPoint=t[i].targetVos[0].curValue.ToNum()),
i==t.Count()-1&&this.curPoint==t[i].targetVos[0].targetValue.ToNum()&&(e=!0)
e?(this.openTimeTxt.textSet("已达标"),this.openTimeTxt.fontSizeSet(20)):this.openTimeTxt.textSet(this.curPoint)
let i=0,s=0
for(let e=0;e<=t.Count()-1;e++){s+=this.GetSpacingByIndex(e+1)}for(let e=0;e<=t.Count()-1;e++){const s=this.GetSpacingByIndex(e+1)
if(!(t[e].targetVos[0].curValue.ToNum()>=t[e].targetVos[0].targetValue.ToNum())){let n=0
e>0&&(n=t[e-1].targetVos[0].targetValue.ToNum()),i+=(t[e].targetVos[0].curValue.ToNum()-n)/(t[e].targetVos[0].targetValue.ToNum()-n)*s
break}i+=s}i=i<s&&i||s,0==i?this.lightLine.node.SetActive(!1):(this.lightLine.node.SetActive(!0),this.lightLine.widthSet(i)),this.lineBg.widthSet(s)}RefreshWelfarePos(t){if(t>0){
let e=0
e=t>=8?8:t,this.time.SetLocalPositionXYZ(56*(8-e)-14,-110,0)}}GetDirectData(){const t=Zt.X.Inst_get().directBuyList
for(let e=0;e<=t.Count()-1;e++){const i=t[e]
if(i.id==jt.Y.Inst_get().directBuyId&&i.CheckShow())return i}}OpenSuccessHandle(){Q.K.Inst_get().IsJumpAnim()?(this.isPlayingAnim=!1,this.OnJumpAnim()):(this.isPlayingAnim=!0,
this.delay=0,this.ClearEffTimeHandle(),this.effTimer=Z.C.Inst_get().SetInterval(this.CreateDelegate(this.OnPlayAnim),500,-1),this.OnPlayAnim())}OnPlayAnim(){
0==this.delay?(this.pre_eff_springfestival02_01.SetActive(!1),this.pre_eff_springfestival04_02.SetActive(!0),this.pre_eff_springfestival07_01.SetActive(!1),
this.pre_eff_springfestival08_01.SetActive(!1),this.pre_eff_springfestival07_01.SetActive(!0),
this.pre_eff_springfestival08_01.SetActive(!0)):1e3==this.delay?(this.roketSp.SetActive(!1),this.PlayReverse(),this.pre_eff_springfestival04_02.SetActive(!1),
this.pre_eff_springfestival02_01.SetActive(!0)):1500==this.delay?Ht.j.Inst.PlayByCfgSoundId("60137"):this.delay>=2e3&&(this.roketSp.SetActive(!0),this.PlayForward(),
this.ClearEffTimeHandle(),this.UpdateRewardInfo(),this.OpenResultView(),this.isPlayingAnim=!1),this.delay+=500}PlayForward(){this.leftTween.PlayForward(),
this.rightTween.PlayForward(),this.topTween.PlayForward(),this.bottomTween.PlayForward()}PlayReverse(){this.leftTween.PlayReverse(),this.rightTween.PlayReverse(),
this.topTween.PlayReverse(),this.bottomTween.PlayReverse()}OnJumpAnim(){this.OpenResultView(),this.ClearEffTimeHandle(),this.UpdateRewardInfo()}OpenResultView(){
hi.Inst_get().OpenCelebrateResultView(),this.isPlayingAnim=!1}RemoveLis(){}GoOneBtnHandle(){this.isPlayingAnim||hi.Inst_get().CelebrateGoHandle(1)}GoTenBtnHandle(){
this.isPlayingAnim||hi.Inst_get().CelebrateGoHandle(10)}WelfareBtnHandle(){const t=new Nt.w
t.position=new Bt.P(-397.17,127.75,0),t.width=340,t.infoId="FUQI:TIPS",Mt.Q.Inst_get().Open(t)}AnimToggleHandle(){hi.Inst_get().CelebrateSendSetAnim(this.animTog.GetValue())}
UpdateRewardInfo(){const t=K.i.ins.lotteryInfoDic[Y.t.SPRINGFESTIVAL_CELEBRATE]
if(this.goOneBtn.node.SetActive(!1),this.goTenBtn.node.SetActive(!1),this.animTog.node.SetActive(!1),K.i.ins.GetState(Y.t.SPRINGFESTIVAL_CELEBRATE)==Vt.V.OPEN){
this.goOneBtn.node.SetActive(!0),this.animTog.node.SetActive(!0)
let e=`点燃一次(     ${Q.K.Inst_get().GetCelebrateConsumeNum(1)})`
if(t.restFreeCount>0)e="免 费",this.icon1.node.SetActive(!1),this.oneRedPoint.SetActive(!0),this.discountLabel.SetActive(!1)
else{this.oneRedPoint.SetActive(!1),this.icon1.node.SetActive(!0)
const t=Q.K.Inst_get().GetCelebrateDiscount()
10==t?this.discountLabel.SetActive(!1):(this.discountLabel.SetActive(!0),this.discountLabel.textSet(`${t}折`))}this.BagUpdateHandle(),this.goOneBtn.SetText(e),
this.animTog.SetValue(Q.K.Inst_get().IsJumpAnim())}const e=V.P.ins.GetVoByHuodongIdAndType(Y.t.SPRINGFESTIVAL_SHOP,M.f.TICKET_TYPE)
this.bigPrizeDesc.textSet(string.format("今日剩余次数 (%s/%s)",e.Remain_Num()+t.restFreeCount,e.limit+1))
const i=Q.K.Inst_get().lotteryMaxType,s=new S.Z
for(let t=1;t<=i;t++)s.Add(t)
this.poolTable.data_set(s),this.poolTable.CallReposition()}UpdateInfo(){this.UpdateRewardInfo(),this.UpdateWelfareValue(),this.pre_eff_springfestival02_01.SetActive(!1),
this.pre_eff_springfestival03_01.SetActive(!0),this.pre_eff_springfestival04_02.SetActive(!1),this.pre_eff_springfestival07_01.SetActive(!1),
this.pre_eff_springfestival08_01.SetActive(!1)}ClearEffTimeHandle(){null!=this.effTimer&&(Z.C.Inst_get().ClearInterval(this.effTimer),this.effTimer=null)}}var he=i(62734)
class de extends _t.x{constructor(...t){super(...t),this.itemData=null,this.icon=null,this.count=null,this.widget=null,this.grayIcon=null}InitView(){super.InitView(),
this.icon=this.CreateComponent(q.w,1),this.count=this.CreateComponent($.Q,2),this.widget=this.CreateComponent(X.z,4),this.grayIcon=this.CreateComponent(q.w,5)}SetData(t,e){
this.itemData=t,this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.ClickItem)),this.icon.SetActive(!0),this.grayIcon.SetActive(!1),this.count.SetActive(!0),
e?e<0&&this.count.SetActive(!1):e=p.g.Inst_get().GetItemNum(this.itemData.modelId_get()),e<=0&&(this.icon.SetActive(!1),this.grayIcon.SetActive(!0),
this.grayIcon.spriteNameSet(Q.K.Inst_get().GetGrayCardName(this.itemData.modelId_get()))),this.count.textSet(e),
this.icon.spriteNameSet(Q.K.Inst_get().GetCardName(this.itemData.modelId_get()))}ClickItem(){
this.onClick?this.onClick(this.ComponentId,this.FatherId):INS.itemTipManager.OpenTipView(this.itemData)}Clear(){super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){
return!0}}class ue extends zt.${constructor(){super(),this.model=null,this.fiveblesscomeItemList=null,this.rewardScrollView=null,this.rewardGrid=null,this.shareBtn=null,
this.exchangeBtn=null,this.canExchangeNum=null,this.fiveblesscome_item1=null,this.fiveblesscome_item2=null,this.fiveblesscome_item3=null,this.fiveblesscome_item4=null,
this.fiveblesscome_item5=null,this.tipText=null,this.blessBtn=null,this.canBlessTip=null,this.eff=null,this.rewardTxt=null,this.animTog=null,this.hadCardInStore=null,
this.effOriginIcon=null,this.timer1=null,this.isPlaying=null,this.time=null,this.fiveblesscomeItemList=new S.Z}InitView(){super.InitView(),
this.rewardScrollView=this.CreateComponent(dt.h,1),this.rewardGrid=this.CreateComponent(J.A,2),this.shareBtn=this.CreateComponent(X.z,3),
this.exchangeBtn=this.CreateComponent(X.z,4),this.canExchangeNum=this.CreateComponent($.Q,5),this.fiveblesscome_item1=this.CreateComponentBinder(de,6),
this.fiveblesscome_item2=this.CreateComponentBinder(de,7),this.fiveblesscome_item3=this.CreateComponentBinder(de,8),this.fiveblesscome_item4=this.CreateComponentBinder(de,9),
this.fiveblesscome_item5=this.CreateComponentBinder(de,10),this.tipText=this.CreateComponent($.Q,11),this.blessBtn=this.CreateComponent(j.W,12),
this.canBlessTip=this.CreateComponent(X.z,13),this.eff=this.CreateComponent(X.z,14),this.rewardTxt=this.CreateComponent($.Q,15),this.animTog=this.CreateComponent(ut.r,16),
this.hadCardInStore=this.CreateComponent(X.z,17),this.effOriginIcon=this.CreateComponent(X.z,18),this.model=Q.K.Inst_get()
for(let t=1;t<=5;t++){const e=this[`fiveblesscome_item${t}`]
this.fiveblesscomeItemList.Add(e)}this.rewardGrid.SetInitInfo("ui_baseitem",null,nt.j),this.rewardGrid.OnReposition_set(this.CreateDelegate(this.OnReposition))}SetData(){
this.m_handlerMgr.AddClickEvent(this.animTog,this.CreateDelegate(this.AnimToggleHandle)),this.m_handlerMgr.AddClickEvent(this.shareBtn,this.CreateDelegate(this.OnClickShareBtn)),
this.m_handlerMgr.AddClickEvent(this.exchangeBtn,this.CreateDelegate(this.OnClickExchangeBtn)),
this.m_handlerMgr.AddClickEvent(this.blessBtn,this.CreateDelegate(this.OnClickBlessBtn)),this.m_handlerMgr.AddEventMgr(f.g.BAG_UPDATE,this.CreateDelegate(this.OnBagUpdate),50),
he.f.Inst.AddCallback(At.t.FIVEBLESSCOME_CANBLESS,this.CreateDelegate(this.UpdateRedpoint)),
he.f.Inst.AddCallback(At.t.FIVEBLESSCOME_CANGETCARD,this.CreateDelegate(this.UpdateRedpoint)),
this.model.AddEventHandler(z.$.UpdateFiveBlessComeInfo,this.CreateDelegate(this.UpdateContent)),this.model.AddEventHandler(z.$.PraySuccess,this.CreateDelegate(this.OnPraySuccess)),
this.model.isPlayingUIAnim=!1,this.eff.SetActive(!1),this.effOriginIcon.SetActive(!0),this.animTog.SetValue(this.model.FiveBlessComeSkipAnim()),this.UpdateRedpoint(),
this.UpdateContent(),this.tipText.textSet(v.x.Inst().getItemById(11046018).sys_messsage)}ShowCurrencyBar_get(){return Pt._.ShowAll}OnReposition(){
this.rewardScrollView.ResetPosition()}OnBagUpdate(){this.UpdateContent()}DelayShowRewardPanel(t,e){this.model.openLittleCattleInfo_get()
this.model.isPlayingUIAnim=!1,this.UpdateContent(),hi.Inst_get().OpenFiveBlessComeRewardView()}OnPraySuccess(){this.timer1=Z.C.Inst_get().ClearInterval(this.timer1),
this.animTog.GetValue()?(this.model.isPlayingUIAnim=!1,this.DelayShowRewardPanel()):(this.eff.SetActive(!1),this.eff.SetActive(!0),this.effOriginIcon.SetActive(!1),
this.timer1=Z.C.Inst_get().SetInterval(this.CreateDelegate(this.DelayShowRewardPanel),1500,1))}UpdateContent(){const t=this.model.GetFiveBlessConsumeList()
if(this.model.isPlayingUIAnim)return
for(let e=1;e<=t.Count();e++){const i=t[e-1]
this[`fiveblesscome_item${e}`].SetData(i)}const e=this.model.GetCanExchangeCardCount(),i=this.model.FiveBlessComeInfo_get()
if(this.canExchangeNum.textSet(e),i.bigRewardTime>0)this.rewardTxt.textSet(`祈福剩余${i.bigRewardTime}次必出大奖`)
else{const t=v.x.Inst().getItemById(11046017).sys_messsage
this.rewardTxt.textSet(t)}const s=this.model.GetFiveBlessComeCfg(),a=new S.Z
s.Sort(((t,e)=>t.sort-e.sort))
for(const[t,e]of(0,n.V5)(s)){const t=e.rewardDefs,i=Ct.A.GetReward(t).GetRewardBaseItemList(),s=new st.M(i[0].modelId_get())
if(s.count=1,a.Add(s),e.rewardLimit>0){const t=this.model.GetHitCount(e.id)
s.showNum=!0,s.isBigPrize=e.prize,s.SpecialNumStr=`${e.rewardLimit-t}/${e.rewardLimit}`,s.IconType_Set(at.s.BASE_ICON_BIGPRIZE_TYPE)}}this.rewardGrid.data_set(a)}UpdateRedpoint(){
let t=he.f.Inst.GetData(At.t.FIVEBLESSCOME_CANBLESS)
this.canBlessTip.SetActive(t.show),t=he.f.Inst.GetData(At.t.FIVEBLESSCOME_CANGETCARD),this.hadCardInStore.SetActive(t.show)}OnClickBlessBtn(){if(this.model.isPlayingUIAnim)return
const t=this.model.GetFiveBlessConsumeList()
let e
for(const[i,s]of(0,n.V5)(t))if(p.g.Inst_get().GetItemNum(s.modelId_get())<=0){e=s
break}e?(INS.itemTipManager.OpenTipViewById(e.modelId_get()),H.y.inst.ClientSysStrMsg("福卡不足")):(this.model.isPlayingUIAnim=!0,hi.Inst_get().ReqCM_OxNewYearPray())}
OnClickShareBtn(){hi.Inst_get().OpenFiveBlessComeShareView()}OnClickExchangeBtn(){hi.Inst_get().OpenFiveBlessComeExchangeView()}AnimToggleHandle(){
this.model.FiveBlessComeSkipAnimSet(this.animTog.GetValue()),this.animTog.GetValue()&&this.isPlaying&&(this.time=0)}Clear(){
he.f.Inst.RemoveCallback(At.t.FIVEBLESSCOME_CANBLESS,this.CreateDelegate(this.UpdateRedpoint)),
he.f.Inst.RemoveCallback(At.t.FIVEBLESSCOME_CANGETCARD,this.CreateDelegate(this.UpdateRedpoint)),
this.model.RemoveEventHandler(z.$.UpdateFiveBlessComeInfo,this.CreateDelegate(this.UpdateContent)),
this.model.RemoveEventHandler(z.$.PraySuccess,this.CreateDelegate(this.OnPraySuccess)),this.timer1=Z.C.Inst_get().ClearInterval(this.timer1),super.Clear()}Destroy(){super.Destroy()
}Test1(){return!0}S_Test(){return!0}}var ce=i(75582),_e=i(92447),Ie=i(98958),ge=i(86209),me=i(7601),Ce=i(52513),Se=i(31896)
class pe extends _t.x{constructor(...t){super(...t),this.itemIcon=null,this.vipLabel=null,this.buyBtn=null,this.costLabel=null,this.nameLabel=null,this.orPriceLabel=null,
this.goodGrid=null,this.buyOverContainer=null,this.costIcon=null,this.costContainer=null,this.zhekouObj=null,this.zhekouLab=null,this.bg=null,this.zhekouSp=null,
this.limitLabel=null,this.redPointObj=null,this.huodongMallVo=null,this.huodongMallCfgVo=null,this.consumes=null}InitView(){super.InitView(),
this.itemIcon=this.CreateComponentBinder(nt.j,1),this.vipLabel=this.CreateComponent($.Q,2),this.buyBtn=this.CreateComponent(X.z,3),this.costLabel=this.CreateComponent($.Q,4),
this.nameLabel=this.CreateComponent($.Q,5),this.orPriceLabel=this.CreateComponent($.Q,6),this.goodGrid=this.CreateComponent(J.A,7),
this.buyOverContainer=this.CreateComponent(X.z,8),this.costIcon=this.CreateComponent(q.w,9),this.costContainer=this.CreateComponent(Ut.V,10),
this.zhekouObj=this.CreateComponent(X.z,11),this.zhekouLab=this.CreateComponent($.Q,12),this.bg=this.CreateComponent(q.w,13),this.zhekouSp=this.CreateComponent(q.w,14),
this.limitLabel=this.CreateComponent($.Q,15),this.redPointObj=this.CreateComponent(X.z,16),this.goodGrid.SetInitInfo("ui_baseitem",this.CreateDelegate(this.OnInitItem)),
this.zhekouLab.SetLocalEulerAnglesXYZ(0,0,20),this.zhekouLab.fontSizeSet(16),this.zhekouLab.SetLocalPositionXYZ(192.9,-61.2,0)}OnInitItem(t){const e=new nt.j
return e.setId(t,null,0),e.SetBgSize(60,60),e.SetIconSize(60,60),e}SetData(t){super.SetData(t),this.huodongMallVo=t,
this.huodongMallCfgVo=ce.Z.ins.GetVoByMallId(this.huodongMallVo.mallId),this.AddLis(),this.UpdateView()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.buyBtn,this.CreateDelegate(this.OnClickBtnBuy)),
this.m_handlerMgr.AddEventMgr(f.g.HUODONG_MALL_BUY_CNT_CHANGE,this.CreateDelegate(this.OnBuyCntChange)),
this.m_handlerMgr.AddEventMgr(f.g.COMMON_REMIND_DATA_RESET,this.CreateDelegate(this.UpdateRed)),this.m_handlerMgr.AddEventMgr(f.g.VIP_UPDATE,this.CreateDelegate(this.UpdateRed))}
OnClickBtnBuy(){
-1!=this.huodongMallVo.limit&&V.P.ins.GetBuyTimesByMallId(this.huodongMallVo.mallId)>=this.huodongMallVo.limit||(K.i.ins.GetState(Y.t.SPRINGFESTIVAL_SHOP)==Vt.V.OPEN?(0!=this.huodongMallVo.rechargeId?Se.t.inst.Buy(Ce.O.Inst().getConfig(this.huodongMallVo.rechargeId)):P.$.ins.CheckConsumeEnough(this.huodongMallVo.Consume_Get())&&P.$.ins.CM_ActivityMallBuy(this.huodongMallVo.mallId),
Q.K.Inst_get().AddShopNotices(this.huodongMallVo.mallId)):H.y.inst.ClientSysStrMsg("活动已结束"))}ShowDiscount(){1==this.huodongMallCfgVo.label?(this.zhekouLab.node.SetActive(!1),
this.zhekouSp.spriteNameSet("ryjbsd_sp_0012")):2==this.huodongMallCfgVo.label?(this.zhekouLab.node.SetActive(!0),this.zhekouSp.spriteNameSet("ryjbsd_sp_0027"),
this.zhekouLab.textSet(`${this.huodongMallCfgVo.discount}%`)):3==this.huodongMallCfgVo.label?(this.zhekouLab.node.SetActive(!1),
this.zhekouSp.spriteNameSet("ryjbsd_sp_0011")):this.zhekouObj.SetActive(!1),this.zhekouSp.MakePixelPerfect(),
1==this.huodongMallCfgVo.productQuality?this.bg.spriteNameSet("rygclc_sp_0010"):2==this.huodongMallCfgVo.productQuality&&this.bg.spriteNameSet("rygclc_sp_0009")}OnBuyCntChange(t){
t==this.huodongMallVo.mallId&&this.UpdateView()}UpdateRed(){Q.K.Inst_get().IsShowShopRedPoint(this.huodongMallVo),this.redPointObj.SetActive(!1)}UpdateView(){
this.nameLabel.textSet(this.huodongMallCfgVo.name)
const t=this.huodongMallVo.GetVipLimit()
t>0?(this.vipLabel.node.SetActive(!0),this.vipLabel.textSet(`V${t}可购`)):this.vipLabel.node.SetActive(!1)
const e=this.huodongMallVo.reward.rewards
if(-1!=this.huodongMallVo.limit){const t=this.huodongMallVo.limit-V.P.ins.GetBuyTimesByMallId(this.huodongMallVo.mallId)
this.buyOverContainer.SetActive(t<=0),this.limitLabel.textSet(Ie.V.Inst().replaceLangParamOne("限购{0}次",t))}else this.buyOverContainer.SetActive(!1),this.limitLabel.textSet("")
const i=st.M.wrapReward(e[0])
this.itemIcon.SetData(i)
const s=new S.Z
for(let t=1;t<=e.Count()-1;t++)s.Add(st.M.wrapReward(e[t]))
s.Count()>=3?this.goodGrid.cellWidthSet(67):this.goodGrid.cellWidthSet(80),this.goodGrid.data_set(s),
C.M.IsNullOrEmpty(this.Or_Consume_Get())?this.orPriceLabel.node.SetActive(!1):(this.orPriceLabel.node.SetActive(!0),this.orPriceLabel.textSet(this.Or_Consume_Get())),
this.UpdateConsume(),this.ShowDiscount(),this.UpdateRed()}UpdateConsume(){if(this.costLabel.SetActive(!0),this.costIcon.SetActive(!0),0!=this.huodongMallVo.rechargeId){
const t=Ce.O.Inst().getConfig(this.huodongMallVo.rechargeId),e=me.W.Inst.GetCurSystem(),i=t.platformCurrency[e]
this.costLabel.textSet(`${i}元`),this.costIcon.SetActive(!1)}else{const t=this.huodongMallVo.Consume_Get().GetItemDataByType()
this.costLabel.textSet(ge.w.Instance.ConvertNumToString(t.count)),null!=t.virtualItemData_get()?this.costIcon.spriteNameSet(Dt.J.GetCurrencyIconUrl(t.virtualItemData_get().virtualTypeStr)):this.costIcon.spriteNameSet("")
}this.costContainer.CallReposition()}Or_Consume_Get(){return this.huodongMallCfgVo.originConsumeDef}Clear(){this.consumes=null,super.Clear()}Destroy(){super.Destroy(),
this.itemIcon=null,this.vipLabel=null,this.buyBtn=null,this.costLabel=null,this.nameLabel=null,this.orPriceLabel=null,this.goodGrid=null,this.buyOverContainer=null,
this.costIcon=null,this.costContainer=null,this.zhekouObj=null,this.zhekouLab=null,this.bg=null,this.zhekouSp=null,this.limitLabel=null,this.redPointObj=null}Test1(){return!0}
S_Test(){return!0}}class Ae extends zt.${constructor(...t){super(...t),this.scrollView=null,this.myGrid=null,this.offset=null,this.bg1=null,this.bg2=null,this.bg3=null,
this.panel=null,this.ui_publicbeta_eff_view=null,this.desc1=null,this.desc2=null,this.filterList=null,this.sortList=null,this.timer=null}InitView(){super.InitView(),
this.scrollView=this.CreateComponent(dt.h,1),this.myGrid=this.CreateComponent(J.A,2),this.offset=this.CreateComponent(Kt.T,3),this.bg1=this.CreateComponent(q.w,4),
this.bg2=this.CreateComponent(q.w,5),this.bg3=this.CreateComponent(q.w,6),this.panel=this.CreateComponent(Yt.$,7),this.ui_publicbeta_eff_view=this.CreateComponentBinder(_e.k,8),
this.desc1=this.CreateComponent($.Q,9),this.desc2=this.CreateComponent($.Q,10),this.myGrid.SetInitInfo("ui_springfestival_shopitem_ry",null,pe)}SetData(){
Q.K.Inst_get().InitShopNoticeData(),this.m_handlerMgr.AddEventMgr(f.g.HUODONG_MALL_CHANGE,this.CreateDelegate(this.UpdateView)),this.UpdateView(),
this.m_handlerMgr.AddEventMgr(f.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors)),this.ui_publicbeta_eff_view.SetData(),this.UpdateAnchors()}ShowCurrencyBar_get(){
return Pt._.ShowDia}UpdateAnchors(){const t=bt.O.GetUIWidth()
let e=t-129-20-30
null!=this.bg1&&(this.bg1.widthSet(t-129-20),this.bg2.widthSet(e),this.bg3.widthSet(e)),e-=20,this.panel.baseClipRegionSetXYZW(0,-192,e,382),this.panel.clipOffsetSetXY(0,0),
this.panel.node.transform.SetLocalPositionXYZ(-65,84,0),this.myGrid.node.transform.SetLocalPositionXYZ(-e/2,-46,0),
this.filterList.count<5&&e/this.filterList.count>250?this.myGrid.cellWidthSet(e/this.filterList.count):this.myGrid.cellWidthSet(250),this.myGrid.Reposition()}UpdateView(){
const[t,e]=V.P.ins.GetMallListByHuoDongIdSort2(Y.t.SPRINGFESTIVAL_SHOP,this.sortList)
this.sortList=e
const i=new S.Z
for(let e=0;e<=t.Count()-1;e++){const s=t[e]
s.CheckView()&&s.type!=M.f.TICKET_TYPE&&i.Add(s)}this.filterList=i,this.myGrid.data_set(i)}OnTimer(){let t=v.x.Inst().getItemStrById(11046004)
if(this.filterList.Count()>0){const e=ce.Z.ins.GetVoByMallId(this.filterList[this.filterList.Count()-1].mallId),i=this.filterList[this.filterList.Count()-1].timeControl
let s
if(null==i[1])this.desc2.textSet("")
else{s=i[1].ToNum()-Lt.D.serverMSTime_get()
const n=ot.l.GetDateFormatEXX(s,!0,!0,!0)
t=C.M.Replace(t,"{0}",e.round),t=C.M.Replace(t,"{1}",n),this.desc2.textSet(t)}}}ClearTimeHandle(){null!=this.timer&&(Z.C.Inst_get().ClearInterval(this.timer),this.timer=null)}
Clear(){Q.K.Inst_get().SaveShopRedPoint(),this.ClearTimeHandle(),this.sortList=null,super.Clear()}Destroy(){super.Destroy(),this.scrollView=null,this.myGrid=null,this.offset=null,
this.bg1=null,this.bg2=null,this.bg3=null,this.panel=null,this.ui_publicbeta_eff_view=null,this.desc1=null,this.desc2=null}}
var fe=i(23833),ye=i(26055),Te=i(87722),Re=i(70650),ve=i(90419),we=i(82737),De=i(27122),Ee=i(29839),Le=i(28359),Ge=i(19276)
class Oe extends _t.x{constructor(...t){super(...t),this.isSelect=!1,this.monsterId=0,this.select=null,this.noselect=null,this.desc=null,this.img_icon=null}InitView(){
super.InitView(),this.name=this.CreateComponent($.Q,1),this.select=this.CreateComponent(X.z,3),this.noselect=this.CreateComponent(X.z,4),this.desc=this.CreateComponent($.Q,5),
this.img_icon=this.CreateComponent(q.w,6)}SetData(t){this.SetItemClickGo(this.node),this.SetSelect(!1),this.monsterId=t
const e=fe.a.inst.getObjById(this.monsterId)
this.img_icon.spriteNameSet(e.headResources),this.name.textSet(e.name)}SetDesc(t){this.desc.textSet(t)}SetSelect(t){this.isSelect=t,this.select.SetActive(t),
this.noselect.SetActive(!t)}onClick(){this.SetSelect(!this.isSelect),l.i.Inst.RaiseEvent(f.g.CLICK_SPRING_MONSTER_ITEM,this.monsterId)}Clear(){super.Clear()}Destroy(){
super.Destroy()}Test1(){return!0}S_Test(){return!0}}class be extends zt.${constructor(...t){super(...t),this.copyId=0,this.bossId=0,this.rewardScrollView=null,this.rewardGrid=null,
this.getRewardLeftCount=null,this.getRewardBtn=null,this.tipText=null,this.bossTexture=null,this.getRewardTip=null,this.rightAnchor=null,this.littleCattleTable=null,this.boss=null,
this.rotateIndex=null}InitView(){super.InitView(),this.rewardScrollView=this.CreateComponent(dt.h,1),this.rewardGrid=this.CreateComponent(J.A,2),
this.getRewardLeftCount=this.CreateComponent($.Q,3),this.getRewardBtn=this.CreateComponent(j.W,4),this.tipText=this.CreateComponent($.Q,5),
this.bossTexture=this.CreateComponent(ie.X,6),this.getRewardTip=this.CreateComponent(X.z,7),this.rightAnchor=this.CreateComponent(Kt.T,8),
this.littleCattleTable=this.CreateComponent(Ut.V,9)
const t=R.D.getInstance().GetIntArray("CHUNJIEPRAY:FUBEN_BOSS")
this.copyId=t[0],this.bossId=t[1],this.rewardGrid.SetInitInfo("ui_baseitem",null,nt.j),this.rewardGrid.OnReposition_set(this.CreateDelegate(this.OnReposition)),
this.littleCattleTable.SetInitInfo("ui_sf_springcattle_monster_item",this.CreateDelegate(this.CreateMonsterItem))}SetData(){this.UpdateContent(),this.ShowBoss(),
this.ShowMonsterList(),this.UpdateAnchors(),this.m_handlerMgr.AddClickEvent(this.getRewardBtn,this.CreateDelegate(this.OnEnterCopy)),
this.m_handlerMgr.AddEventMgr(f.g.CLICK_SPRING_MONSTER_ITEM,this.CreateDelegate(this.OnClickMonsterItem)),this.tipText.textSet(v.x.Inst().getItemById(11046015).sys_messsage),
Q.K.Inst_get().AddEventHandler(z.$.UpdateSpringCattleInfo,this.CreateDelegate(this.UpdateContent))}UpdateAnchors(){this.rightAnchor&&bt.O.SetAnchorPos(this.rightAnchor,!1,!0,0)}
ShowCurrencyBar_get(){return Pt._.ShowAll}ShowMonsterList(){this.littleCattleTable.OnReposition_set(this.CreateDelegate(this.OnRepositionTable))
const t=R.D.getInstance().GetIntArray("CHUNJIEPRAY:XIAOCHUNNIU_ID")
this.littleCattleTable.data_set(t)}OnRepositionTable(){const t=this.littleCattleTable.itemList
let e
t[0]&&t[0].SetSelect(!0)
for(let i=0;i<=t.Count()-1;i++){e=i+11046033
const s=v.x.Inst().getItemById(e)
s&&t[i].SetDesc(s.sys_messsage)}this.littleCattleTable.OnReposition_set(null),this.littleCattleTable.Reposition()}DelayReposition(){const t=this.littleCattleTable.itemList
t[0]&&t[0].SetSelect(!0),this.littleCattleTable.Reposition()}OnClickMonsterItem(t){const e=this.littleCattleTable.itemList,i=this.littleCattleTable.data_get()
for(let s=0;s<=e.Count()-1;s++)i[s]!=t&&e[s].SetSelect(!1)
this.littleCattleTable.Reposition()}CreateMonsterItem(t){const e=new Oe
return e.setId(t,null,0),e}OnReposition(){this.rewardScrollView.ResetPosition()}UpdateContent(){
const t=Q.K.Inst_get().SpringCattleInfo_get(),e=Q.K.Inst_get().GetSpringCattleActivityId()
e>0&&K.i.ins.GetState(e)==Vt.V.OPEN?(this.getRewardLeftCount.textSet(`今日可挑战次数：${t.fightNum}`),this.getRewardTip.SetActive(t.fightNum>0)):(this.getRewardLeftCount.textSet(""),
this.getRewardTip.SetActive(!1))}OnEnterCopy(){Q.K.Inst_get().SpringCattleInfo_get().fightNum<=0?H.y.inst.ClientSysMessage(11046007):Ee.p.inst.CommonEnterCopy("copyId",this.copyId)
}ShowBoss(){Wt.M.Instance_get().ActiveStage(be.STAGE_ID)
const t=fe.a.inst.getObjById(this.bossId)
if(null!=t){const e=Ge.C.Inst().GetItemByMonsterId(this.bossId).drop_get()
if(null!=e){const t=ve.d.parseJsonObjectWithFix(e,"rewardValues"),i=xt.t.decode(t,Le.h)
i.Parse(),this.rewardGrid.data_set(i.GetItemList())}const i=new ye.O
this.ClearBoss(),this.boss=De.Q.Inst().GetObjectByName("MonsterCharacter",Te._),this.boss.Info_set(i)
const s=new ee.O
s._displayID=t.displayId,s._world=Wt.M.Instance_get().GetStageWorldType(be.STAGE_ID),s._bNeedWaitAnime=!0,s.shiledType=we.g.DT_NONE,this.boss.InitPhotoByInfo(t,s,0)
const n=Wt.M.Instance_get().GetDisplayHeight(be.STAGE_ID,0)
this.boss.MainRole_get().SetCastShadow(!0),this.boss.MainRole_get().SetShadowHeight(n),Wt.M.Instance_get().SetDisplayObject(be.STAGE_ID,this.boss.MainRole_get().handle,0),
Wt.M.Instance_get().SetWorldRotation(be.STAGE_ID,0,new Bt.P(0,0,0))
const a=1.5
this.boss.SetSize(a),this.bossTexture.SetMainTextureByPhoto(be.STAGE_ID),this.bossTexture.SetUVRect(0,0,1,1),
this.rotateIndex=Re.e.GetInst().RegDrag(this.bossTexture.node,this.boss.MainRole_get())}}ClearBoss(){null!=this.boss&&(this.boss.Destroy(),this.boss=null)}Clear(){super.Clear(),
null!=this.boss&&Wt.M.Instance_get().DeactiveStage(be.STAGE_ID,this.bossTexture.FatherId,this.bossTexture.ComponentId),this.ClearBoss(),
Q.K.Inst_get().RemoveEventHandler(z.$.UpdateSpringCattleInfo,this.CreateDelegate(this.UpdateContent))}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}}be.STAGE_ID=169
class Be extends Ot.I{constructor(){super(),this.RIGHT_NAMES=null,this.RIGHT_REDIDS=null,this.TAB_FUNC_TYPES=null,this.HUODONG_IDS=null,this.timetips=null,this.bg3=null,
this.tipBtn=null,this.delayTimer=null,this.countDownTimer=null,this.RIGHT_NAMES=new S.Z(["五福临门","春牛赐福","福气冲天","超值年货"]),
this.RIGHT_REDIDS=new S.Z([At.t.SPRING_FESTIVAL_FIVEBLESSCOME,At.t.SPRING_FESTIVAL_SPRINGCATTLE,At.t.SPRING_FESTIVAL_CELEBRATE,At.t.SPRING_FESTIVAL_SHOP]),
this.TAB_FUNC_TYPES=new S.Z({}),
this.HUODONG_IDS=new S.Z([Q.K.Inst_get().GetFiveBlessComeActivityId(),Q.K.Inst_get().GetSpringCattleActivityId(),Y.t.SPRINGFESTIVAL_CELEBRATE,Y.t.SPRINGFESTIVAL_SHOP])}InitView(){
super.InitView(),this.timetips=this.CreateComponent($.Q,60),this.bg3=this.CreateComponent(q.w,61),this.tipBtn=this.CreateComponent(X.z,62),
this._subPanelDatas.Add(Gt.b.New(new S.Z(["ui_sf_fiveblesscome_view"]),this,ue)),this._subPanelDatas.Add(Gt.b.New(new S.Z(["ui_sf_springcattle_view"]),this,be)),
this._subPanelDatas.Add(Gt.b.New(new S.Z(["ui_springfestival_celebrateview_ry"]),this,re)),this._subPanelDatas.Add(Gt.b.New(new S.Z(["ui_springfestival_shopview_ry"]),this,Ae)),
this.rightTabGrid.SetInitInfo("ui_sevenday_right_tab",this.CreateDelegate(this.CreateSevenDayBottomItem),null,this.CreateDelegate(this._OnClickRightItem)),
this.rightTabGrid.OnReposition_set(this.CreateDelegate(this.OnRepositionRight))}Delay(){const t=this.rightTabGrid.itemList.Count(),e=new S.Z,i=new S.Z
for(let s=0;s<=t-1;s++){const t=Q.K.Inst_get().GetActivityIdByIndex(s)
t>0&&K.i.ins.GetState(t)==Vt.V.OPEN?e.Add(s):i.Add(s)}if(i.Count()>0){let t=0
const s=this.rightTabGrid.cellHeight()
for(const[i,a]of(0,n.V5)(e))this.rightTabGrid.itemList[a].SetLocalPositionXYZ(0,-t*s,0),t+=1
for(const[e,a]of(0,n.V5)(i))this.rightTabGrid.itemList[a].SetLocalPositionXYZ(0,-t*s,0),t+=1}}OnRepositionRight(){super.OnRepositionRight(),
this.delayTimer=Z.C.Inst_get().ClearInterval(this.delayTimer),this.delayTimer=Z.C.Inst_get().SetInterval(this.CreateDelegate(this.Delay),1,1)}_OnClickRightItem(t,e,i){
if(t&&t.img_lock.activeSelf())return void H.y.inst.ClientSysStrMsg("不在活动时间内")
const s=this.rightTabGrid.itemList.IndexOf(t),n=Q.K.Inst_get().GetActivityIdByIndex(s)
n<=0||K.i.ins.GetState(n)==Vt.V.CLOSE?H.y.inst.ClientSysStrMsg("活动已结束"):super._OnClickRightItem(t,e,i)}CreateSevenDayBottomItem(t){const e=new kt.q
return e.setId(t,null,0),e.SetBgWidth(129),e}OnAniPlayEnd(){Q.K.Inst_get().isTweenEnd=!0,super.OnAniPlayEnd()}IsLock(t){const e=t&&this.HUODONG_IDS[t]||null
return!(!e||0==e||K.i.ins.GetState(e)!=Vt.V.NONE)}GetTipId(t){
return t==Q.K.GOLDCATTLE?"CHUNJIE:TIPS1":t==Q.K.SPRINGCATTLE?"CHUNJIE:TIPS2":t==Q.K.FIVEBLESSCOME?"CHUNJIE:TIPS3":void 0}SetViewConfig(){this._SetTabData0(!1),
this.titleLabel.textSet("春节狂欢"),this._SetTabData1(!0,this.RIGHT_NAMES,this.RIGHT_REDIDS,this.TAB_FUNC_TYPES,null,null,this.HUODONG_IDS),this.rightBg3.SetActive(!1),
this.rightBg2.SetActive(!1),Q.K.Inst_get().defaul_tab_idx&&Q.K.Inst_get().defaul_tab_idx>=0&&this.IsLock(Q.K.Inst_get().defaul_tab_idx)&&(Q.K.Inst_get().defaul_tab_idx=null),
null==Q.K.Inst_get().defaul_tab_idx&&(Q.K.Inst_get().defaul_tab_idx=0),this.SelectTab1(Q.K.Inst_get().defaul_tab_idx),null==this.countDownTimer&&(this.RefreshEndTime(),
this.countDownTimer=Z.C.Inst_get().SetInterval(this.CreateDelegate(this.RefreshEndTime),500)),this.m_handlerMgr.AddClickEvent(this.tipBtn,this.CreateDelegate(this.OnClickTip))}
OnClickTip(){const t=this.GetTipId(this.selectTabIdx1)
if(t){const e=new Nt.w
e.position=new Bt.P(-470,300,0),e.width=300,e.infoId=t,Mt.Q.Inst_get().Open(e)}}UpdateAnchors(){const t=bt.O.GetUIWidth()
null!=this.bg3&&this.bg3.widthSet(t-129),super.UpdateAnchors()}_OnSelectTab1BeforeUpdate(t){this.ShowSubView(this.selectTabIdx1),this.RefreshEndTime(),
this.tipBtn.SetActive(!!this.GetTipId(this.selectTabIdx1))}RefreshEndTime(){let t=0
if(this.selectTabIdx1==Q.K.CELEBRATE?t=Y.t.SPRINGFESTIVAL_CELEBRATE:this.selectTabIdx1==Q.K.GOLDCATTLE?t=Q.K.Inst_get().GetGoldCattleActivityId():this.selectTabIdx1==Q.K.SPRINGCATTLE?t=Q.K.Inst_get().GetSpringCattleActivityId():this.selectTabIdx1==Q.K.FIVEBLESSCOME?t=Q.K.Inst_get().GetFiveBlessComeActivityId():this.selectTabIdx1==Q.K.SHOP&&(t=Y.t.SPRINGFESTIVAL_SHOP),
t>0){const e=K.i.ins.huodong_dict.LuaDic_GetItem(t)
let i=0
null!=e&&(i=e.endTime.ToNum()),i>0&&(i=.001*i-Lt.D.serverTime_get()),i>0?this.timetips.textSet(`结束倒计时:[5FB470]${ot.l.GetDateFormatBitContainZero(i,4)}[-]`):this.timetips.textSet("已结束")
}else this.timetips.textSet("")}ShowCurrencyBar_get(){const t=this.selectTabIdx1,e=this.GetSubView(t)
return e&&e.ShowCurrencyBar_get?e.ShowCurrencyBar_get():Pt._.Hide}ClearEndTimeHandle(){null!=this.countDownTimer&&(Z.C.Inst_get().ClearInterval(this.countDownTimer),
this.countDownTimer=null)}OnCloseClick(){hi.Inst_get().CloseSpringFestivalView()}Clear(){this.ClearEndTimeHandle(),super.Clear(),Q.K.Inst_get().defaul_tab_idx=null,
this.delayTimer=Z.C.Inst_get().ClearInterval(this.delayTimer)}Destroy(){Q.K.Inst_get().isTweenEnd=!1,super.Destroy()}Test1(){return!0}S_Test(){return!0}}
var Ne=i(65393),Pe=i(78752),Me=i(65530),Ve=i(30627),ke=i(57522)
class xe extends _t.x{constructor(...t){super(...t),this.icon=null}InitView(){super.InitView(),this.icon=this.CreateComponent(q.w,1)}SetData(t){this.icon.spriteNameSet(t)}Clear(){
super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}}var He,Ue,Fe,Ye,Ke,ze,Qe,Ze,Xe,je,Je,We,$e,qe,ti,ei,ii,si=i(91238),ni=i(36241),ai=i(63062)
class oi extends _t.x{constructor(...t){super(...t),this.monsterId=0,this.isDead=!1,this.btn_go=null,this.img_icon=null,this.desc=null,this.bar_num=null,this.deadIcon=null}
InitView(){super.InitView(),this.btn_go=this.CreateComponent(j.W,1),this.img_icon=this.CreateComponent(q.w,2),this.desc=this.CreateComponent($.Q,3),
this.bar_num=this.CreateComponent(ai.p,5),this.deadIcon=this.CreateComponent(X.z,6),this.name=this.CreateComponent($.Q,7)
const t=this.FindComponent($.Q,"btn_go/text_go",!0)
t&&t.textSet("攻击")}SetData(t){this.monsterId=t,this.isDead=!1
const e=fe.a.inst.getObjById(this.monsterId)
this.img_icon.spriteNameSet(e.headResources),this.name.textSet(e.name),this.deadIcon.SetActive(!1),this.RefreshBar(1),
this.m_handlerMgr.AddClickEvent(this.btn_go,this.CreateDelegate(this.OnClickGoTo))}OnClickGoTo(){if(this.isDead)return void H.y.inst.ClientSysStrMsg("怪物已死亡")
const t=ht.Y.Inst.GetMonsterDic(),e=ht.Y.Inst.PrimaryRole_get()
for(const[i,s]of(0,n.V5)(t))if(s&&s.Cfg_get().id==this.monsterId){const t=s.GetPos()
if(e){ni._.getInst().endHang(),ht.Y.Inst.setCurTarget(s,!0),e.StopPathingByForce(!0),e.gotoPoint(t,si.m.Point,this.CreateDelegate(this.OnGotoEnd),null,null)
break}}}OnGotoEnd(){const t=ht.Y.Inst.GetMonsterDic()
for(const[e,i]of(0,n.V5)(t))if(i&&i.Cfg_get().id==this.monsterId){ht.Y.Inst.setCurTarget(i,!0)
break}ni._.getInst().startHang()}IsDead(){return this.isDead}RefreshBar(t){let e
this.bar_num.DoF_SetValueEx(t,1),e=t<=0,e!=this.isDead&&(this.isDead=e,this.deadIcon.SetActive(e))}SetDesc(t){this.desc.textSet(t)}Clear(){super.Clear()}Destroy(){super.Destroy()}
Test1(){return!0}S_Test(){return!0}}class li extends tt.f{constructor(){super(),this.MonsterIdList=null,this.MonsterIdToObjId={},this.UpdateHpTimer=0,this.ShowItemTimer=0,
this.ShowItemDelayList=null,this.needTweenIndexList=null,this.currentIndex=-1,this.boxModelList={},this.boxDisppearTimers={},this.boxModelId=0,this.leftAnchor=null,
this.grid_task=null,this.item1=null,this.MonsterIdList=new S.Z,this.ShowItemDelayList=new S.Z,this.needTweenIndexList=new S.Z}InitView(){super.InitView(),
this.leftAnchor=this.CreateComponent(Kt.T,1),this.grid_task=this.CreateComponent(J.A,2),this.item1=this.CreateComponentBinder(xe,3)
const t=this.FindComponent($.Q,"leftAnchor/layer-auto6",!0)
t&&t.textSet("春牛召唤"),this.grid_task.SetInitInfo("ui_sf_springcattle_copymonster_item",null,oi),this.grid_task.OnReposition_set(this.CreateDelegate(this.OnReposition))
const e=R.D.getInstance().GetIntValue("CHUNJIEPRAY:BOX"),i=lt.f.Inst().getItemById(e)
this.boxModelId=i.dropModel}OnAddToScene(){Q.K.Inst_get().AddEventHandler(z.$.UpdateSpringCattleCopyStage,this.CreateDelegate(this.UpdateNewCardIndex)),
Q.K.Inst_get().AddEventHandler(z.$.LiveMonsterListUpdate,this.CreateDelegate(this.RefreshLiveMonsterList)),
this.m_handlerMgr.AddEventMgr(f.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors)),this.InitMonsterList(),
this.UpdateHpTimer=Z.C.Inst_get().SetInterval(this.CreateDelegate(this.RefreshMonsterHp),500,-1),
this.ShowItemTimer=Z.C.Inst_get().SetInterval(this.CreateDelegate(this.ShowItemHandler),1e3*this.ShowItemDelayList[0],1),this.ShowItemDelayList.RemoveAt(0),this.item1.SetActive(!1)
const t=Q.K.Inst_get().SpringCattleCopyStage_get()-1
this.needTweenIndexList.Clear(),this.currentIndex=t,this.RefreshBoxCount(null,this.currentIndex)}UpdateAnchors(){this.leftAnchor&&bt.O.SetAnchorPos(this.leftAnchor,!0,!0,0)}
OnReposition(){const t=R.D.getInstance().GetStringArray("CHUNJIEPRAY:XIAOCHUNNIU_DES"),e=this.grid_task.itemList.Count()
for(let i=0;i<=e-1;i++)if(t[i]){const e=C.M.SubStringWithLen(t[i],1,C.M.Length(t[i])-2)
this.grid_task.itemList[i].SetDesc(e)}this.RefreshLiveMonsterList()}InitMonsterList(){this.MonsterIdList=R.D.getInstance().GetIntArray("CHUNJIEPRAY:XIAOCHUNNIU_ID"),
this.ShowItemDelayList=R.D.getInstance().GetIntArray("CHUNJIEPRAY:PRAY_TIME"),this.grid_task.data_set(this.MonsterIdList)}RefreshLiveMonsterList(){
const t=Q.K.Inst_get().MonsterListInfo_get(),e=this.MonsterIdList.Count()
if(t.deadList)for(let i=0;i<=e-1;i++){const e=this.MonsterIdList[i],s=this.grid_task.itemList[i]
s&&t.deadList.Contains(e)&&s.RefreshBar(0)}this.RefreshMonsterHp()}RefreshMonsterHp(){const t=this.MonsterIdList.Count(),e=ht.Y.Inst.GetMonsterDic()
if(e.Count()>0)for(let i=0;i<=t-1;i++){const t=this.MonsterIdList[i],s=this.grid_task.itemList[i]
if(s&&!s.IsDead()){let i=this.MonsterIdToObjId[t]
if(!i||!e[i])for(const[s,a]of(0,n.V5)(e))if(a&&a.Cfg_get().id==t){i=s,this.MonsterIdToObjId[t]=i
break}const a=i&&e[i]
if(a){const t=a.Info_get()
if(t){const e=t.CurrentHp_get(),i=t.MaxHp_get()
s.RefreshBar(e/i)}}}}}GetIconName(t){return`rychunjiewufu_sp_00${t+27}`}ShowItemHandler(){const t=(10-this.ShowItemDelayList.Count()-1)%10
this.item1.SetActive(!1),this.item1.SetActive(!0),this.item1.SetData(this.GetIconName(t)),
this.ShowItemDelayList.Count()>0&&(this.ShowItemTimer=Z.C.Inst_get().SetInterval(this.CreateDelegate(this.ShowItemHandler),1e3*this.ShowItemDelayList[0],1),
this.ShowItemDelayList.RemoveAt(0))}UpdateNewCardIndex(){const t=Q.K.Inst_get().SpringCattleCopyStage_get()-1
for(let e=this.currentIndex+1;e<=t;e++)this.CreateBoxModel(e)
this.currentIndex=t}GetAroundPos(){return ht.Y.Inst.PrimaryRole_get().GetCurPos(pt.I.calVec0),ot.l.GetRandomPosCanArriveByRing(pt.I.calVec0,1,3)}CreateBoxModel(t){
if(!this.boxModelList[t]){const[e,i,s]=this.GetAroundPos()
this.boxModelList[t]=Ne.e.Inst_get().AddObj(Pe.M.Common,this.boxModelId,e,s,0,0,1),
this.boxDisppearTimers[t]=Z.C.Inst_get().SetIntervalForParm(this.CreateDelegate(this.DisppearBox),4e3,1,t)}}DisppearBox(t,e){if(this.boxModelList[e]){
let t=Ne.e.Inst_get().GetCharacterObj(this.boxModelList[e]).GetPos()
t=Me.x.Instance_get().WorldToScreenPoint2(t),t.z=0,t=Me.x.Instance_get().ScreenToWorldPoint(t),Ne.e.Inst_get().RemoveObj(this.boxModelList[e]),this.boxModelList[e]=null
const i=Ve.t.Inst().GetBoxPos()
i?(ke.h.Inst_get().PlayFlyItem(t,i,null,null,null,1,0),this.boxDisppearTimers[e]=Z.C.Inst_get().SetIntervalForParm(this.CreateDelegate(this.RefreshBoxCount),1e3,1,e)):this.RefreshBoxCount(null,e)
}}RefreshBoxCount(t,e){Ve.t.Inst().UpdateBoxCount(Ve.t.Inst().GetBoxCount(e+1))}ClearAllBoxModel(){for(const[t,e]of(0,n.X)(this.boxModelList))Ne.e.Inst_get().RemoveObj(e)
for(const[t,e]of(0,n.X)(this.boxDisppearTimers))Z.C.Inst_get().ClearInterval(e)
this.boxModelList={},this.boxDisppearTimers={}}Clear(){
super.Clear(),Q.K.Inst_get().RemoveEventHandler(z.$.UpdateSpringCattleCopyStage,this.CreateDelegate(this.UpdateNewCardIndex)),
Q.K.Inst_get().RemoveEventHandler(z.$.LiveMonsterListUpdate,this.CreateDelegate(this.RefreshLiveMonsterList)),this.UpdateHpTimer=Z.C.Inst_get().ClearInterval(this.UpdateHpTimer),
this.ShowItemTimer=Z.C.Inst_get().ClearInterval(this.ShowItemTimer),this.ClearAllBoxModel()}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}}function ri(t,e,i,s,n){
var a={}
return Object.keys(s).forEach((function(t){a[t]=s[t]})),a.enumerable=!!a.enumerable,a.configurable=!!a.configurable,("value"in a||a.initializer)&&(a.writable=!0),
a=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),a),n&&void 0!==a.initializer&&(a.value=a.initializer?a.initializer.call(n):void 0,a.initializer=void 0),
void 0===a.initializer&&(Object.defineProperty(t,e,a),a=null),a}let hi=(He=(0,s.GH)(w.k.SM_OxnewYearMonsterUpdate),Ue=(0,s.GH)(w.k.SM_OpenLittleCattle),Fe=(0,
s.GH)(w.k.SM_OxNewYearBossDamage),Ye=(0,s.GH)(w.k.SM_UpDateCardStore),Ke=(0,s.GH)(w.k.SM_RemoveFuCardChangeInfo),ze=(0,s.GH)(w.k.SM_AddFuCardChangeInfo),Qe=(0,
s.GH)(w.k.SM_OxNewYearBossInfo),Ze=(0,s.GH)(w.k.SM_OxNewYearCollectConfig),Xe=(0,s.GH)(w.k.SM_OxNewYearCollectInfo),je=(0,s.GH)(w.k.SM_OxNewYearPray),Je=(0,
s.GH)(w.k.SM_OxNewYearPreSentConfig),We=(0,s.GH)(w.k.SM_UpdateCardChangeList),$e=(0,s.GH)(w.k.SM_UpdateBigCattle),qe=(0,s.GH)(w.k.SM_OxNewYearPreSentInfo),ti=(0,
s.GH)(w.k.SM_UpdateLittleCattle),ii=class t{constructor(){this.cachDamageStateList=null,this.cachBoxCountList=null,this.sendTime=null,this._degf_OnBagUpdate=null,
this._degf_OnHuoDongChange=null}static Inst_get(){return null==t._inst&&(t._inst=new t),t._inst}RegMsg(){this._degf_OnBagUpdate=()=>this.OnBagUpdate(),
this._degf_OnHuoDongChange=t=>this.OnHuoDongChange(t),r.o.Inst().AddGroup(o.Z.GROUP_NORMAL_BAG,this._degf_OnBagUpdate),
l.i.Inst.AddEventHandler(f.g.HUODONG_INFO_CHANGE,this._degf_OnHuoDongChange)}SM_OxnewYearMonsterUpdateHandler(t){Q.K.Inst_get().MonsterListInfo_set(t)}
SM_OpenLittleCattleHandler(t){Q.K.Inst_get().openLittleCattleInfo_set(t)}SM_OxNewYearBossDamageHandler(t){Q.K.Inst_get().SpringCattleCopyStage_set(t.stage),
A.o.Inst_get().SetBossDamage(t.per)}SM_UpDateCardStoreHandler(t){const e=Q.K.Inst_get().FiveBlessComeInfo_get()
e.cardStore=t.cardStore,Q.K.Inst_get().FiveBlessComeInfo_set(e)}SM_RemoveFuCardChangeInfoHandler(t){const e=Q.K.Inst_get().FiveBlessComeInfo_get(),i=e.changeInfoVos
let s=!1
for(const[e,a]of(0,n.V5)(i))if(a.guid==t.guid){i.Remove(a),s=!0
break}s&&Q.K.Inst_get().FiveBlessComeInfo_set(e)}SM_AddFuCardChangeInfoHandler(t){const e=Q.K.Inst_get().FiveBlessComeInfo_get(),i=e.changeInfoVos
let s=!0
for(const[e,a]of(0,n.V5)(i))a.guid==t.fuCardChangeInfoVo.guid&&(s=!1)
s&&(i.Add(t.fuCardChangeInfoVo),Q.K.Inst_get().CardAddToExchange(t.fuCardChangeInfoVo)),Q.K.Inst_get().FiveBlessComeInfo_set(e)}SM_OxNewYearBossInfoHandler(t){
Q.K.Inst_get().SpringCattleInfo_set(t)}SM_OxNewYearCollectConfigHandler(t){Q.K.Inst_get().FiveBlessComeCfg_set(t)}SM_OxNewYearCollectInfoHandler(t){
if(Q.K.Inst_get().FiveBlessComeInfo_set(t),Q.K.Inst_get().waitingToShowPopup)if(Q.K.Inst_get().waitingToShowPopup=!1,Q.K.Inst_get().HasCardShouldRemind()){let t=""
const[e,i,s,n]=p.g.Inst_get().GetLastNoEffectEquip()
if(e){t=e.GetEquipmentByColumnAndPos(i,s).GetItemRes().name}const a=new U.N
a.showText=v.x.Inst().getItemById(11046024).sys_messsage,a.tipstype=2,a.okhandler=this.CreateDelegate(this.OpenFiveBlessComeExchange),H.y.inst.OpenCommonMessageTips(a)
}else H.y.inst.ClientSysMessage(11046029)}OpenFiveBlessComeExchange(){this.OpenSpringFestivalView(Q.K.FIVEBLESSCOME),this.OpenFiveBlessComeExchangeView()}
SM_OxNewYearPrayHandler(t){const e=Q.K.Inst_get().FiveBlessComeInfo_get()
e.bigRewardTime=t.bigRewardTime,e.hitMap=t.hitMap,Q.K.Inst_get().FiveBlessComeInfo_set(e),Q.K.Inst_get().newFiveBlessComePrayHit=t.hitId,Q.K.Inst_get().RaiseEvent(z.$.PraySuccess)}
SM_OxNewYearPreSentConfigHandler(t){Q.K.Inst_get().GoldCattleSpringFestivalCfg_set(t)}SM_UpdateCardChangeListHandler(t){const e=Q.K.Inst_get().FiveBlessComeInfo_get()
e.changeInfoVos=t.changeInfoVos,Q.K.Inst_get().FiveBlessComeInfo_set(e)}SM_UpdateBigCattleHandler(t){const e=Q.K.Inst_get().GoldCattleSpringFestivalInfo_get().bigCattleInfo
Q.K.Inst_get().newBigCattleInfo=t.bigCattleInfo,!e.reward&&t.bigCattleInfo.reward&&(Q.K.Inst_get().openLittleCattleInfo_set(null),Q.K.Inst_get().RaiseEvent(z.$.OpenBigCattle)),
Q.K.Inst_get().GoldCattleSpringFestivalInfo_get().bigCattleInfo=t.bigCattleInfo}SM_OxNewYearPreSentInfoHandler(t){Q.K.Inst_get().GoldCattleSpringFestivalInfo_set(t)}
SM_UpdateLittleCattleHandler(t){const e=Q.K.Inst_get().GoldCattleSpringFestivalInfo_get().littleCattleInfos
Q.K.Inst_get().newLittleCattleInfo=t.littleCattleInfo
for(const[i,s]of(0,n.V5)(e))if(s.type==t.littleCattleInfo.type){e[i]=t.littleCattleInfo,s.hasReward,t.littleCattleInfo.hasReward
break}Q.K.Inst_get().GoldCattleSpringFestivalInfo_set(Q.K.Inst_get().GoldCattleSpringFestivalInfo_get())}ReqCM_OpenLittleCattle(t){const e=new O.o
e.activityId=Q.K.Inst_get().GetGoldCattleActivityId(),e.type=t,h.C.Inst.F_SendMsg(e)}ReqCM_OpenBigCattle(){const t=new G.f
t.activityId=Q.K.Inst_get().GetGoldCattleActivityId(),h.C.Inst.F_SendMsg(t)}ReqCM_CardApplyChange(t,e){const i=new D.S
i.activityId=Q.K.Inst_get().GetFiveBlessComeActivityId(),i.myCardId=t,i.needCardId=e,h.C.Inst.F_SendMsg(i)}ReqCM_CardConfirmChange(t){const e=new L.W
e.activityId=Q.K.Inst_get().GetFiveBlessComeActivityId(),e.guid=t,h.C.Inst.F_SendMsg(e)}ReqCM_OxNewYearPray(){const t=new b.z
t.activityId=Q.K.Inst_get().GetFiveBlessComeActivityId(),h.C.Inst.F_SendMsg(t)}ReqCM_RewardCard(){const t=new B.G
t.activityId=Q.K.Inst_get().GetFiveBlessComeActivityId(),h.C.Inst.F_SendMsg(t)}ReqFiveBlessInfo(){F.l.ins.CM_OpenActivityPanel(Q.K.Inst_get().GetFiveBlessComeActivityId())}
ReqCM_CardCancelChange(t){const e=new E.l
e.activityId=Q.K.Inst_get().GetFiveBlessComeActivityId(),e.guid=t,h.C.Inst.F_SendMsg(e)}ReqCM_ShareChangeInfo(t,e){const i=new N.i
i.activityId=Q.K.Inst_get().GetFiveBlessComeActivityId(),i.guid=e,i.type=t,h.C.Inst.F_SendMsg(i)}OnBagUpdate(){Q.K.Inst_get().RefreshFiveBlessRedpoint(),
Q.K.Inst_get().UpdateCelebrateRedPoint()}OnHuoDongChange(t){t==Q.K.Inst_get().GetSpringCattleActivityId()&&Q.K.Inst_get().RefreshSpringCattleRedpoint(),
t==Q.K.Inst_get().GetFiveBlessComeActivityId()&&(Q.K.Inst_get().RefreshFiveBlessRedpoint(),Q.K.Inst_get().RefreshCardInExchangeTip())}GetDamageBoxList(){
if(!this.cachDamageStateList){this.cachDamageStateList=new S.Z,this.cachBoxCountList=new S.Z
if(y.a.Inst_get().curCopyType==T.S.SpringCattle){const t="CHUNJIEPRAY:HP_NUM"
let e=R.D.getInstance().GetStringValue(t)
e=C.M.SubStringWithLen(e,1,C.M.Length(e)-2)
const i=C.M.Split(e,d.o.s_Arr_UNDER_CHAR_DOU)
for(const[t,e]of(0,n.V5)(i)){const t=C.M.Split(e,d.o.s_Arr_UNDER_COLON)
let i=C.M.SubStringWithLen(t[0],1,C.M.Length(t[0])-2)
i=(0,a.aI)(i),this.cachDamageStateList.Add(i),this.cachBoxCountList.Add((0,a.aI)(t[1]))}}}return[this.cachDamageStateList,this.cachBoxCountList]}OpenSpringFestivalView(t){
const e=new u.v
let i=!1
if(t){const e=Q.K.Inst_get().GetActivityIdByIndex(t)
e>0&&K.i.ins.IsActiveState(e)&&(i=!0)}else{const e=Q.K.Inst_get().GetFirstOpenStateIdx()
if(!(t=e||Q.K.Inst_get().GetFirstActiveStateIdx()))return void H.y.inst.ClientSysStrMsg("活动已结束")
i=!0}i?(Q.K.Inst_get().defaul_tab_idx=t,e.isShowMask=!0,e.isDefaultUITween=!0,e.isSelfTween=!0,e.viewClass=Be,
c.N.inst.OpenById(_.I.RySpringFestivalMainView,null,null,e)):H.y.inst.ClientSysStrMsg("活动已结束")}CloseSpringFestivalView(){c.N.inst.CloseById(_.I.RySpringFestivalMainView)}
GetMainPanelId(){const t=c.N.inst.GetViewById(_.I.RySpringFestivalMianView)
return null!=t?t.FatherId:null}OpenGoldCattleRewardView(){const t=c.N.inst.GetViewById(_.I.RyGoldCattleRewardView)
if(t&&t.isShow_get())t.OnAddToScene()
else{const t=new u.v
t.isShowMask=!0,t.viewClass=Et,c.N.inst.OpenById(_.I.RyGoldCattleRewardView,null,null,t)}}CloseGoldCattleRewardView(){c.N.inst.CloseById(_.I.RyGoldCattleRewardView)}
OpenFiveBlessComeRewardView(){const t=new u.v
t.isShowMask=!0,t.viewClass=St,c.N.inst.OpenById(_.I.FiveBlessComeRewardView,null,null,t)}CloseFiveBlessComeRewardView(){c.N.inst.CloseById(_.I.FiveBlessComeRewardView)}
OpenFiveBlessComeExchangeView(){const t=new u.v,e=Q.K.Inst_get().GetActivityIdByIndex(Q.K.FIVEBLESSCOME)
e>0&&!K.i.ins.IsActiveState(e)||(t.isShowMask=!0,t.viewClass=mt,c.N.inst.OpenById(_.I.FiveBlessComeExchangeView,null,null,t))}CloseFiveBlessComeExchangeView(){
c.N.inst.CloseById(_.I.FiveBlessComeExchangeView)}OpenFiveBlessComeShareView(){const t=new u.v
t.isShowMask=!0,t.viewClass=wt,c.N.inst.OpenById(_.I.FiveBlessComeShareView,null,null,t)}CloseFiveBlessComeShareView(){c.N.inst.CloseById(_.I.FiveBlessComeShareView)}
OpenSpringCattleCopyView(){if(null==c.N.inst.GetViewById(_.I.SpringCattleCopyView)){const t=new u.v
t.layerType=I.F.DefaultUI,t.positionType=m.$.eCustom,t.aniDir=g.K.Left,t.viewClass=li,c.N.inst.OpenById(_.I.SpringCattleCopyView,null,null,t)}}CloseSpringCattleCopyView(){
c.N.inst.CloseById(_.I.SpringCattleCopyView)}SendCM_CommonActivityLottery(t){
1==t?F.l.ins.CM_CommonActivityLottery(Y.t.SPRINGFESTIVAL_CELEBRATE,!1):F.l.ins.CM_CommonActivityLottery(Y.t.SPRINGFESTIVAL_CELEBRATE,!0)}CelebrateSendSetAnim(t){let e=0
t&&(e=1),k.p.inst.SendClientLogicSetting(x.R.SPRING_FESTIVAL_CELEBRATE_JUMP_ANIM,e)}CelebrateGoHandle(t){this.sendTime=t
const e=Q.K.Inst_get().GetCelebrateKeyItemId(),i=p.g.Inst_get().GetItemNum(e),s=Q.K.Inst_get().GetCelebrateConsumeNum(t),n=K.i.ins.lotteryInfoDic[Y.t.SPRINGFESTIVAL_CELEBRATE]
if(null!=n&&n.restFreeCount>0)this.SendCM_CommonActivityLottery(t)
else if(i<s)if(p.g.Inst_get().emptySize_get()>=10){const t=Y.t.SPRINGFESTIVAL_SHOP
if(0==t)return void H.y.inst.ClientSysMessage(11042910)
P.$.ins.CheckItemEnough(t,e,s)||l.i.Inst.AddEventHandler(f.g.HUODONG_MALL_BUY_SUCCESS,this.CreateDelegate(this.CelebrateBuySuccessHandle))}else H.y.inst.ClientSysStrMsg("背包不足")
else this.SendCM_CommonActivityLottery(t)}CelebrateBuySuccessHandle(t){const e=this.GetCelebrateMallInfo()
if(null!=e&&t.mallId==e.mallId){l.i.Inst.RemoveEventHandler(f.g.HUODONG_MALL_BUY_SUCCESS,this.CreateDelegate(this.CelebrateBuySuccessHandle))
const t=Q.K.Inst_get().GetCelebrateKeyItemId()
p.g.Inst_get().GetItemNum(t)>=Q.K.Inst_get().GetCelebrateConsumeNum(this.sendTime)&&this.SendCM_CommonActivityLottery(this.sendTime)}}GetCelebrateMallInfo(){
return V.P.ins.GetVoByHuodongIdAndType(Y.t.SPRINGFESTIVAL_SHOP,M.f.TICKET_TYPE)}OpenCelebrateResultView(){const t=c.N.inst.GetViewById(_.I.RySpringFestivalCelebrateResultView)
if(null!=t&&t.isShow_get())return void t.UpdateView()
const e=new u.v
e.isShowMask=!0,e.isDefaultUITween=!0,e.isSelfTween=!1,e.viewClass=rt,c.N.inst.OpenById(_.I.RySpringFestivalCelebrateResultView,null,null,e)}CloseCelebrateResultView(){
c.N.inst.CloseById(_.I.RySpringFestivalCelebrateResultView)}
},ii._inst=null,ri((ei=ii).prototype,"SM_OxnewYearMonsterUpdateHandler",[He],Object.getOwnPropertyDescriptor(ei.prototype,"SM_OxnewYearMonsterUpdateHandler"),ei.prototype),
ri(ei.prototype,"SM_OpenLittleCattleHandler",[Ue],Object.getOwnPropertyDescriptor(ei.prototype,"SM_OpenLittleCattleHandler"),ei.prototype),
ri(ei.prototype,"SM_OxNewYearBossDamageHandler",[Fe],Object.getOwnPropertyDescriptor(ei.prototype,"SM_OxNewYearBossDamageHandler"),ei.prototype),
ri(ei.prototype,"SM_UpDateCardStoreHandler",[Ye],Object.getOwnPropertyDescriptor(ei.prototype,"SM_UpDateCardStoreHandler"),ei.prototype),
ri(ei.prototype,"SM_RemoveFuCardChangeInfoHandler",[Ke],Object.getOwnPropertyDescriptor(ei.prototype,"SM_RemoveFuCardChangeInfoHandler"),ei.prototype),
ri(ei.prototype,"SM_AddFuCardChangeInfoHandler",[ze],Object.getOwnPropertyDescriptor(ei.prototype,"SM_AddFuCardChangeInfoHandler"),ei.prototype),
ri(ei.prototype,"SM_OxNewYearBossInfoHandler",[Qe],Object.getOwnPropertyDescriptor(ei.prototype,"SM_OxNewYearBossInfoHandler"),ei.prototype),
ri(ei.prototype,"SM_OxNewYearCollectConfigHandler",[Ze],Object.getOwnPropertyDescriptor(ei.prototype,"SM_OxNewYearCollectConfigHandler"),ei.prototype),
ri(ei.prototype,"SM_OxNewYearCollectInfoHandler",[Xe],Object.getOwnPropertyDescriptor(ei.prototype,"SM_OxNewYearCollectInfoHandler"),ei.prototype),
ri(ei.prototype,"SM_OxNewYearPrayHandler",[je],Object.getOwnPropertyDescriptor(ei.prototype,"SM_OxNewYearPrayHandler"),ei.prototype),
ri(ei.prototype,"SM_OxNewYearPreSentConfigHandler",[Je],Object.getOwnPropertyDescriptor(ei.prototype,"SM_OxNewYearPreSentConfigHandler"),ei.prototype),
ri(ei.prototype,"SM_UpdateCardChangeListHandler",[We],Object.getOwnPropertyDescriptor(ei.prototype,"SM_UpdateCardChangeListHandler"),ei.prototype),
ri(ei.prototype,"SM_UpdateBigCattleHandler",[$e],Object.getOwnPropertyDescriptor(ei.prototype,"SM_UpdateBigCattleHandler"),ei.prototype),
ri(ei.prototype,"SM_OxNewYearPreSentInfoHandler",[qe],Object.getOwnPropertyDescriptor(ei.prototype,"SM_OxNewYearPreSentInfoHandler"),ei.prototype),
ri(ei.prototype,"SM_UpdateLittleCattleHandler",[ti],Object.getOwnPropertyDescriptor(ei.prototype,"SM_UpdateLittleCattleHandler"),ei.prototype),ei)},11740:(t,e,i)=>{i.d(e,{K:()=>N})
var s=i(38836),n=i(98800),a=i(97461),o=i(90419),l=i(50089),r=i(16812),h=i(62370),d=i(98885),u=i(85602),c=i(49603),_=i(70850),I=i(92679),g=i(75439),m=i(82025),C=i(75582),S=i(60567),p=i(19983),A=i(49892),f=i(75961),y=i(14792),T=i(62734),R=i(60647),v=i(13487),w=i(50600),D=i(39043),E=i(28359),L=i(12842),G=i(56834),O=i(69622),b=i(93727),B=i(11430)
class N extends r.k{constructor(){super(),this.defaul_tab_idx=N.CELEBRATE,this.showShopRedPoint=null,this.FiveBlessComeCfg=null,this.GoldCattleSpringFestivalCfg=null,
this.GoldCattleCfgTable={},this.GoldCattleSpringFestivalInfo=null,this.SpringCattleInfo=null,this.FiveBlessComeInfo=null,this.GoldCattleRedpointIdList=null,
this.newBigCattleInfo=null,this.newLittleCattleInfo=null,this.fiveBlessConsumeList=null,this.newFiveBlessComePrayHit=null,this.springCattleCopyStage=null,
this.openLittleCattleInfo=null,this.isPlayingUIAnim=!1,this.cardIsExchangingTable={},this.waitingToShowPopup=!1,this.monterListInfo=null,this.springCattleActivityId=0,
this.lotteryMaxType=0,this.hasNotices=null,this.showShopRedPoint=new u.Z,this.monterListInfo=new u.Z,this.AddEvent()}AddEvent(){
a.i.Inst.AddEventHandler(I.g.COMMON_REMIND_DATA_RESET_BEFORCE,this.CreateDelegate(this.ResetShopRedData)),
a.i.Inst.AddEventHandler(I.g.COMMON_REMIND_DATA_RESET,this.CreateDelegate(this.VipHandler)),a.i.Inst.AddEventHandler(I.g.VIP_UPDATE,this.CreateDelegate(this.VipHandler)),
a.i.Inst.AddEventHandler(I.g.HUODONG_MALL_CHANGE,this.CreateDelegate(this.UpdateMall)),
a.i.Inst.AddEventHandler(I.g.HUODONG_MALL_BUY_CNT_LIST_CHANGE,this.CreateDelegate(this.UpdateMall2)),
a.i.Inst.AddEventHandler(I.g.COMMON_REMIND_DATA_RESET_BEFORCE,this.CreateDelegate(this.ResetShopRedData)),
a.i.Inst.AddEventHandler(I.g.HUODONG_QUEST_CHANGE,this.CreateDelegate(this.UpdateCelebrateRedPoint)),
a.i.Inst.AddEventHandler(I.g.UPDATE_LOTTERY_CONFIG,this.CreateDelegate(this.OnUpdateLotteryConfig))}static Inst_get(){return null==N._inst&&(N._inst=new N),N._inst}ResetData(){
this.springCattleCopyStage=null,this.cardIsExchangingTable={},this.GoldCattleSpringFestivalInfo=null,this.SpringCattleInfo=null,this.FiveBlessComeInfo=null,
this.waitingToShowPopup=!1,this.lotteryMaxType=0,this.ResetShopRedData()}ResetShopRedData(){null!=this.hasNotices&&this.hasNotices.Clear(),this.showShopRedPoint.Clear()}
UpdateMall2(t){t==L.t.SPRINGFESTIVAL_SHOP&&this.VipHandler()}UpdateMall(t){t.activityId==L.t.SPRINGFESTIVAL_SHOP&&this.VipHandler()}VipHandler(){
if(!b.i.ins.IsActiveState(L.t.SPRINGFESTIVAL_SHOP))return void T.f.Inst.SetState(y.t.SPRING_FESTIVAL_SHOP,!1)
const t=S.P.ins.GetMallListByHuoDongId(L.t.SPRINGFESTIVAL_SHOP)
let e=null
const i=`${D.V.Inst_get().GetRolePrefix()}SPRING_SHOP_RED`,s=D.V.Inst_get().GetStrData(i)
d.M.IsNullOrEmpty(s)||"false"==s||(e=h.o.GetIntArr(s))
let n=!1
for(let i=0;i<=t.Count()-1;i++){const s=t[i]
if(s.CheckView()&&s.type!=m.f.TICKET_TYPE&&s.CheckBuy()&&(null==e||!e.Contains(s.mallId))){const t=s.Remain_Num()
if(-1==t||t>0){n=!0
break}}}T.f.Inst.SetState(y.t.SPRING_FESTIVAL_SHOP,n)}IsShowShopRedPoint(t){if(t.CheckView()&&t.type!=m.f.TICKET_TYPE&&t.CheckBuy()){const e=t.Remain_Num()
if(-1==e||e>0){if(this.hasNotices.Contains(t.mallId))return!1
if(!this.showShopRedPoint.Contains(t.mallId))return this.showShopRedPoint.Add(t.mallId),!0}}return!1}AddShopNotices(t){this.hasNotices.Contains(t)||this.hasNotices.Add(t),
this.showShopRedPoint.Contains(t)&&this.showShopRedPoint.Remove(t),0==this.showShopRedPoint.count&&T.f.Inst.SetState(y.t.SPRING_FESTIVAL_SHOP,!1)}InitShopNoticeData(){
const t=`${D.V.Inst_get().GetRolePrefix()}SPRING_SHOP_RED`,e=D.V.Inst_get().GetStrData(t)
this.hasNotices=null,d.M.IsNullOrEmpty(e)||"false"==e?this.hasNotices=new u.Z:this.hasNotices=h.o.GetIntArr(e),this.showShopRedPoint.Clear()}SaveShopRedPoint(){
for(let t=0;t<=this.showShopRedPoint.Count()-1;t++)this.hasNotices.Contains(this.showShopRedPoint[t])||this.hasNotices.Add(this.showShopRedPoint[t])
const t=`${D.V.Inst_get().GetRolePrefix()}SPRING_SHOP_RED`
let e=""
for(let t=0;t<=this.hasNotices.count-1;t++){if(null==this.hasNotices[t])return void T.f.Inst.SetState(y.t.SPRING_FESTIVAL_SHOP,!1)
t!=this.hasNotices.count-1?e+=`${this.hasNotices[t]},`:e+=this.hasNotices[t]}this.showShopRedPoint.Clear(),D.V.Inst_get().SetStrData(t,e),
T.f.Inst.SetState(y.t.SPRING_FESTIVAL_SHOP,!1)}GetCelebrateKeyItemId(){let t=0
const e=c.H.Inst_get().GetActivityResById(L.t.SPRINGFESTIVAL_CELEBRATE)
return e&&null!=e.params.LOTTERY_ONE_CONSUME&&(t=d.M.String2Int(d.M.Split(e.params.LOTTERY_ONE_CONSUME,"_")[0])),t}GetCelebrateOneNum(){let t=0
const e=c.H.Inst_get().GetActivityResById(L.t.SPRINGFESTIVAL_CELEBRATE)
return e&&null!=e.params.LOTTERY_ONE_CONSUME&&(t=d.M.String2Int(d.M.Split(e.params.LOTTERY_ONE_CONSUME,"_")[1])),t}GetCelebrateTenNum(){let t=0
const e=c.H.Inst_get().GetActivityResById(L.t.SPRINGFESTIVAL_CELEBRATE)
return e&&null!=e.params.LOTTERY_MUL_CONSUME&&(t=d.M.String2Int(d.M.Split(e.params.LOTTERY_MUL_CONSUME,"_")[1])),t}GetTimeControl(){
return b.i.ins.lotteryTimeControlDic[L.t.SPRINGFESTIVAL_CELEBRATE]}GetCelebrateConsumeNum(t){let e=1
return 1==t?e=this.GetCelebrateOneNum():10==t&&(e=this.GetCelebrateTenNum()),e}IsJumpAnim(){return 1==R.p.inst.GetClientLogicSetting(v.R.SPRING_FESTIVAL_CELEBRATE_JUMP_ANIM)}
IsSatisfyKeyNum(){return _.g.Inst_get().GetItemNum(this.GetCelebrateKeyItemId())>=this.GetCelebrateConsumeNum(1)}IsSatisfyTenNum(t){
return _.g.Inst_get().GetItemNum(this.GetCelebrateKeyItemId())>=this.GetCelebrateConsumeNum(10)}OnUpdateLotteryConfig(t){if(t.activityId==L.t.SPRINGFESTIVAL_CELEBRATE){
const t=b.i.ins.lotteryLisDic[L.t.SPRINGFESTIVAL_CELEBRATE]
this.lotteryMaxType=0
for(let e=0;e<=t.Count()-1;e++){const i=t[e]
i.type>this.lotteryMaxType&&(this.lotteryMaxType=i.type)}this.UpdateCelebrateRedPoint()}}UpdateCelebrateRedPoint(){let t=!1
const e=this.IsSatisfyKeyNum()
e&&(t=e),t||(t=b.i.ins.HasFreeOpenTime(L.t.SPRINGFESTIVAL_CELEBRATE)),t||(t=this.CanGetCelebrateTargetReward()),T.f.Inst.SetState(y.t.SPRING_FESTIVAL_CELEBRATE,t)}
CanGetCelebrateTargetReward(){const t=O.J.ins.GetTargetTypesByHuoDongId(L.t.SPRINGFESTIVAL_CELEBRATE)
for(let e=0;e<=t.Count()-1;e++){const i=O.J.ins.GetQuestListVoByIdAndTargetType(L.t.SPRINGFESTIVAL_CELEBRATE,t[e])
for(const[t,e]of(0,s.V5)(i)){const t=b.i.ins.GetQuestVo(e.id)
if(null!=t&&!t.activityRewardVo.isReward){let e=!0
for(const[i,n]of(0,s.V5)(t.targetVos))if(n.curValue.ToNum()<n.targetValue.ToNum()){e=!1
break}if(e)return!0}}}return!1}GetCelebrateDiscount(){
const t=S.P.ins.GetVoByHuodongIdAndType(L.t.SPRINGFESTIVAL_SHOP,m.f.TICKET_TYPE).mallId,e=C.Z.ins.GetVoByMallId(t).numDiscount,i=S.P.ins.GetBuyTimesByMallId(t),s=d.M.Split(e,"|")
let n=10,a=10
for(let t=0;t<=s.Count()-1;t++){const e=d.M.Split(s[t],"_")
i>=d.M.String2Int(e[0])&&(n=d.M.String2Int(e[1])),i+1>=d.M.String2Int(e[0])&&(a=d.M.String2Int(e[1]))}return[n,a]}GoldCattleSpringFestivalCfg_set(t){
this.GoldCattleSpringFestivalCfg=t
for(const[t,e]of(0,s.V5)(this.GoldCattleSpringFestivalCfg.chunjiePresentResourceVos))this.GoldCattleCfgTable[e.type]=e}FiveBlessComeCfg_set(t){this.FiveBlessComeCfg=t}
GetSmallGoldCattleCfg(t){return this.GoldCattleCfgTable[t]}GetFiveBlessComeCfg(){if(this.FiveBlessComeCfg)return this.FiveBlessComeCfg.chunjiePrayResourceVos}
GoldCattleSpringFestivalInfo_set(t){this.GoldCattleSpringFestivalInfo=t,this.RefreshGoldCattleRedpoint(),this.RaiseEvent(B.$.UpateGoldCattleInfo)}
GoldCattleSpringFestivalInfo_get(){return this.GoldCattleSpringFestivalInfo}FiveBlessComeInfo_set(t){const e=this.FiveBlessComeInfo
this.FiveBlessComeInfo=t,this.RaiseEvent(B.$.UpdateFiveBlessComeInfo),e||this.InitInExchangeTable(),
T.f.Inst.SetState(y.t.FIVEBLESSCOME_CANGETCARD,this.GetSuccessShareCardCount()>0)}FiveBlessComeInfo_get(){return this.FiveBlessComeInfo}SpringCattleInfo_set(t){
this.SpringCattleInfo=t,this.SpringCattleInfo&&this.SpringCattleInfo.activityId>0&&(this.springCattleActivityId=this.SpringCattleInfo.activityId),
this.RefreshSpringCattleRedpoint(),this.RaiseEvent(B.$.UpdateSpringCattleInfo)}SpringCattleInfo_get(){return this.SpringCattleInfo}SpringCattleCopyStage_set(t){
this.springCattleCopyStage!=t&&(this.springCattleCopyStage=t,this.RaiseEvent(B.$.UpdateSpringCattleCopyStage))}SpringCattleCopyStage_get(){return this.springCattleCopyStage||0}
openLittleCattleInfo_set(t){this.openLittleCattleInfo=t,t&&this.RaiseEvent(B.$.OpenLittleCattle,this.openLittleCattleInfo.type)}openLittleCattleInfo_get(){
return this.openLittleCattleInfo}GetGoldCattleRedpointId(t){return this.GoldCattleRedpointIdList[t]}GetSuccessShareCardCount(){let t=0
if(this.FiveBlessComeInfo){const e=this.FiveBlessComeInfo.cardStore
for(const[i,n]of(0,s.V5)(e))t+=1}return t}GetGoldCattleActivityId(){return this.GoldCattleSpringFestivalCfg?this.GoldCattleSpringFestivalCfg.activityId:0}
GetSpringCattleActivityId(){return this.springCattleActivityId}GetFiveBlessComeActivityId(){return this.FiveBlessComeCfg?this.FiveBlessComeCfg.activityId:0}MonsterListInfo_set(t){
this.monterListInfo=t,this.RaiseEvent(B.$.LiveMonsterListUpdate)}MonsterListInfo_get(){return this.monterListInfo}RefreshGoldCattleRedpoint(){this.GoldCattleSpringFestivalCfg}
RefreshSpringCattleRedpoint(){let t=0,e=!1
b.i.ins.GetState(this.GetSpringCattleActivityId())==G.V.OPEN&&(e=!0),e&&this.SpringCattleInfo&&(t=this.SpringCattleInfo.fightNum),T.f.Inst.SetState(y.t.SPRINGCATTLE_CANENTER,t>0)}
RefreshFiveBlessRedpoint(){let t=!1
const e=this.GetActivityIdByIndex(N.FIVEBLESSCOME)
if(e>0&&b.i.ins.GetState(e)==G.V.OPEN&&this.FiveBlessComeInfo){t=!0
const e=this.GetFiveBlessConsumeList()
for(const[i,n]of(0,s.V5)(e)){const e=n.count
if(_.g.Inst_get().GetItemNum(n.modelId_get())<e){t=!1
break}}this.RefreshCardInExchangeTip()}!T.f.Inst.GetData(y.t.FIVEBLESSCOME_CANBLESS).show==t&&T.f.Inst.SetState(y.t.FIVEBLESSCOME_CANBLESS,t)}GetFiveBlessConsumeList(){
if(!this.fiveBlessConsumeList){const t=g.D.getInstance().GetStringValue("CHUNJIEPRAY:ITEM_ID"),e=o.d.parseJsonObjectWithFix(t,"rewardValues"),i=l.t.decode(e,E.h)
i.Parse(),this.fiveBlessConsumeList=i.GetItemList()}return this.fiveBlessConsumeList}FiveBlessComeSkipAnim(){
return w.a.inst.GetBool(D.V.Inst_get().GetRolePrefix()+"FIVE_BLESS_COME_SKIPANIM")}FiveBlessComeSkipAnimSet(t){
w.a.inst.SetBool(D.V.Inst_get().GetRolePrefix()+"FIVE_BLESS_COME_SKIPANIM",t)}GetCanExchangeCardCount(){
const t=this.FiveBlessComeInfo.changeInfoVos,e=n.Y.Inst.m_primaryRoleInfo.accountindex
let i=0
for(const[n,a]of(0,s.V5)(t))if(a.account!=e){const t=a.needCardId
_.g.Inst_get().GetItemNum(t)>0&&(i+=1)}return i}RemindCardCanExchange_set(t,e){const i=`FIVE_BLESS_CARD${t}`
w.a.inst.SetBool(D.V.Inst_get().GetRolePrefix()+i,e)}RemindCardCanExchange_get(t){const e=`FIVE_BLESS_CARD${t}`
return w.a.inst.GetBool(D.V.Inst_get().GetRolePrefix()+e)}InitInExchangeTable(){if(this.ClearExchangingTable(),this.FiveBlessComeInfo){
const t=this.FiveBlessComeInfo.changeInfoVos,e=n.Y.Inst.m_primaryRoleInfo.accountindex
for(const[i,n]of(0,s.V5)(t))n.account!=e&&this.RemindCardCanExchange_get(n.cardId)&&this.cardIsExchangingTable[n.cardId].Add(n)
this.RefreshCardInExchangeTip()}}RefreshCardInExchangeTip(){const t=this.GetFiveBlessComeActivityId()
if(t>0&&b.i.ins.IsActiveState(t))for(const[t,e]of(0,s.X)(this.cardIsExchangingTable))if(e.Count()>0)for(const[t,i]of(0,s.V5)(e)){const t=i
if(_.g.Inst_get().GetItemNum(t.needCardId)>0){if(!p.S.Inst_get().hasIcon(A.K.FUCARD_EXCHANGE)){const t=new f.U(A.K.FUCARD_EXCHANGE)
p.S.Inst_get().AddIcon(t)}return}}p.S.Inst_get().hasIcon(A.K.FUCARD_EXCHANGE)&&p.S.Inst_get().RemoveIcon(A.K.FUCARD_EXCHANGE)}HasCardShouldRemind(){if(this.FiveBlessComeInfo){
const t=this.FiveBlessComeInfo.changeInfoVos,e=n.Y.Inst.m_primaryRoleInfo.accountindex
for(const[i,n]of(0,s.V5)(t))if(n.account!=e&&this.RemindCardCanExchange_get(n.cardId)&&_.g.Inst_get().GetItemNum(n.needCardId)>0)return!0}}CardAddToExchange(t){
this.RemindCardCanExchange_get(t.cardId)&&(this.cardIsExchangingTable[t.cardId].Add(t),this.RefreshCardInExchangeTip())}ClearExchangingTable(){
const t=this.GetFiveBlessConsumeList()
for(const[e,i]of(0,s.V5)(t))this.cardIsExchangingTable[i.modelId_get()]=new u.Z
p.S.Inst_get().hasIcon(A.K.FUCARD_EXCHANGE)&&p.S.Inst_get().RemoveIcon(A.K.FUCARD_EXCHANGE)}ClearOneCardExchangingRemind(t){this.cardIsExchangingTable[t]=new u.Z,
this.RefreshCardInExchangeTip()}GetHitCount(t){return this.FiveBlessComeInfo.hitMap[t]||0}GetCardName(t){return N.cardNameList[t]}GetGrayCardName(t){return N.grayCardNameList[t]}
GetActivityIdByIndex(t){
return t==N.GOLDCATTLE?this.GetGoldCattleActivityId():t==N.SPRINGCATTLE?this.GetSpringCattleActivityId():t==N.FIVEBLESSCOME?this.GetFiveBlessComeActivityId():t==N.CELEBRATE?L.t.SPRINGFESTIVAL_CELEBRATE:t==N.SHOP?L.t.SPRINGFESTIVAL_SHOP:0
}GetFirstActiveStateIdx(){for(let t=0;t<=N.SHOP;t++){const e=this.GetActivityIdByIndex(t)
if(e>0&&b.i.ins.IsActiveState(e))return t}}GetFirstOpenStateIdx(){for(let t=0;t<=N.SHOP;t++){const e=this.GetActivityIdByIndex(t)
if(e>0&&b.i.ins.GetState(e)==G.V.OPEN)return t}}}N.BaoZang_BaoXiang_ID=799,N.GOLDCATTLE=10,N.SPRINGCATTLE=1,N.FIVEBLESSCOME=0,N.CELEBRATE=2,N.SHOP=3,N._inst=null,N.temp=new u.Z,
N.cardNameList={6801:"rychunjiewufu_sp_0003",6802:"rychunjiewufu_sp_0007",6803:"rychunjiewufu_sp_0011",6804:"rychunjiewufu_sp_0005",6805:"rychunjiewufu_sp_0009"},
N.grayCardNameList={6801:"rychunjiewufu_sp_0004",6802:"rychunjiewufu_sp_0008",6803:"rychunjiewufu_sp_0012",6804:"rychunjiewufu_sp_0006",6805:"rychunjiewufu_sp_0010"}},
60028:(t,e,i)=>{i.d(e,{p:()=>ct})
var s=i(56937),n=i(31222),a=i(5494),o=i(38836),l=i(97461),r=i(5924),h=i(66788),d=i(85602),u=i(92679),c=i(37648),_=i(55492),I=i(14792),g=i(62734),m=i(69622),C=i(93727)
class S{constructor(){this.client_huodong_ids=null,this.check_red_huodong_ids=null,this.default_select_huodong_id=-1,this.default_select_target_type=-1,this.select_huodong_id=0,
this.select_target_type=0,this.show_reward_task_vos=null,this.huodongInit=!1,this.AddLis0()}AddLis0(){
l.i.Inst.AddEventHandler(u.g.FUNCTION_OPEN,this.CreateDelegate(this.OnFunctionOpen)),l.i.Inst.AddEventHandler(u.g.FUNCTION_INIT_COMPLETE,this.CreateDelegate(this.OnFunctionOpen))}
AddLis1(){l.i.Inst.AddEventHandler(u.g.HUODONG_QUEST_CHANGE,this.CreateDelegate(this.CheckRed)),
l.i.Inst.AddEventHandler(u.g.HUODONG_INFO_CHANGE,this.CreateDelegate(this.OnHuoDongInfoChange))}ResetModel(){this.client_huodong_ids=null,this.check_red_huodong_ids=null,
this.default_select_huodong_id=-1,this.default_select_target_type=-1,this.select_huodong_id=0,this.select_target_type=0,this.show_reward_task_vos=null,this.huodongInit=!1}
GetClientShowThemeIds(){return C.i.ins.GetActiveShowHuoDongIdByFunc(_.x.THEMECARNIVAL)}OnHuoDongInfoChange(){this.client_huodong_ids=null,this.check_red_huodong_ids=null,
this.CheckRed()}GetRewardTaskVos(t,e){const i=m.J.ins.GetHuoDongVo(t)
return 0!=i.themeRelation&&(t=i.themeRelation),C.i.ins.GetQuestListVoByIdAndTargetType(t,e)}OnFunctionOpen(){
c.P.Inst_get().IsFunctionOpened(_.x.THEMECARNIVAL)&&(this.huodongInit||(this.huodongInit=!0,this.AddLis1(),this.InitRed(),this.CheckRed()))}CheckRed(){
c.P.Inst_get().IsFunctionOpened(_.x.THEMECARNIVAL)&&r.C.Inst_get().CallLater(this.CreateDelegate(this.OnCheckRed))}OnCheckRed(){const t=this.GetCheckRedHuodongIds()
for(let e=0;e<=t.Count()-1;e++){const i=t[e]
if(C.i.ins.IsActiveState(i)){const t=m.J.ins.GetTargetTypesByHuoDongId(i)
if(null==t)return void h.Y.LogError(`开启的活动${i}没有对应的目标类型`)
for(let e=0;e<=t.Count()-1;e++){const s=m.J.ins.GetQuestListVoByIdAndTargetType(i,t[e])
let n=!1
for(const[t,e]of(0,o.V5)(s)){const t=C.i.ins.GetQuestVo(e.id)
if(null==t)return
if(!t.activityRewardVo.isReward){let e=!0
for(const[i,s]of(0,o.V5)(t.targetVos))if(s.curValue.ToNum()<s.targetValue.ToNum()){e=!1
break}if(e){n=!0
break}}}g.f.Inst.SetState(I.t[`THEMECARNIVAL_${i}_${t[e]}`],n)}}}}InitRed(){const t=this.GetCheckRedHuodongIds()
this.huodongInit=!0
const e=new d.Z
for(let i=0;i<=t.Count()-1;i++){const s=t[i],n=`THEMECARNIVAL_${s}`
I.t[n]=g.f.Inst.GetID(),e.Clear(),e.Add(I.t.THEMECARNIVAL),g.f.Inst.AddNode(I.t[n],e,!1,!1)
const a=m.J.ins.GetTargetTypesByHuoDongId(s)
if(null!=a)for(let t=0;t<=a.Count()-1;t++){const i=`${n}_${a[t]}`
I.t[i]=g.f.Inst.GetID(),e.Clear(),e.Add(I.t[n]),g.f.Inst.AddNode(I.t[i],e,!1,!1)}}}GetCheckRedHuodongIds(){if(null==this.check_red_huodong_ids){this.check_red_huodong_ids=new d.Z
const t=m.J.ins.GetHuoDongVosByFuncType(_.x.THEMECARNIVAL)
for(let e=0;e<=t.Count()-1;e++)1==t[e].client_show&&this.check_red_huodong_ids.Add(t[e].id)
for(let t=0;t<=this.check_red_huodong_ids.Count()-1;t++){const e=m.J.ins.GetHuoDongVo(this.check_red_huodong_ids[t]).themeRelation
0==e||this.check_red_huodong_ids.Contains(e)||this.check_red_huodong_ids.Add(e)}}return this.check_red_huodong_ids}}S.ins=null
var p=i(68662),A=i(99294),f=i(6665),y=i(32759),T=i(93877),R=i(72005),v=i(36334),w=i(15518),D=i(35128),E=i(79534),L=i(87923),G=i(56834),O=i(23649),b=i(43662),B=i(38045),N=i(45404),P=i(31546),M=i(9057),V=i(8889),k=i(11355),x=i(16261),H=i(18202),U=i(83540),F=i(98885),Y=i(38962),K=i(63076),z=i(75321),Q=i(42534),Z=i(99421)
let X=null,j=null
class J extends M.x{constructor(...t){super(...t),this.baseItemData=null,this.img_icon=null,this.text_point=null,this.img_can_get=null,this.text_had_get=null,this.rtpanel=null,
this.rttex=null,this.eff_theme_02_01=null,this.scale_obj=null,this.text_num=null,this.huodongQuestVo=null,this.targetVo=null,this.rewardVo=null,this.bPhotoInited=null}
static __StaticInit(){j=new d.Z(["d","e","f","b","a","c"]),X=new Y.X,X.LuaDic_AddOrSetItem(z.C.PART_WINGS,{equipres:null,displayId:0,displayHandle:0,photoIdx:0,xPos:0,xRot:-90}),
X.LuaDic_AddOrSetItem(z.C.PART_GUARD,{equipres:null,displayId:0,displayHandle:0,photoIdx:1,xPos:0,xRot:0})}InitView(){super.InitView(),this.img_icon=this.CreateComponent(R.w,1),
this.text_point=this.CreateComponent(T.Q,2),this.img_can_get=this.CreateComponent(A.z,3),this.text_had_get=this.CreateComponent(T.Q,4),this.rtpanel=this.CreateComponent(V.$,5),
this.rttex=this.CreateComponent(x.X,6),this.eff_theme_02_01=this.CreateComponent(k.I,7),this.scale_obj=this.CreateComponent(A.z,8),this.text_num=this.CreateComponent(T.Q,9)}
SetData(t){this.AddLis(),this.huodongQuestVo=t,this.targetVo=this.huodongQuestVo.targetVos[0],this.rewardVo=this.huodongQuestVo.activityRewardVo,
this.baseItemData=K.M.wrapReward(this.rewardVo.reward.rewards[0]),this.UpdatePanel()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.img_icon,this.CreateDelegate(this.OnClickImgIcon))}RemoveLis(){}Clear(){super.Clear(),this.RemoveLis(),this.ClearPhoto()}Destroy(){
H.g.DestroyUIObj(),super.Destroy()}UpdatePanel(){this.img_can_get.SetActive(!1),this.text_had_get.SetActive(!1),
this.rewardVo.isReward?this.text_had_get.SetActive(!0):this.targetVo.curValue.ToNum()>=this.targetVo.targetValue.ToNum()&&this.img_can_get.SetActive(!0),
this.text_point.textSet(this.targetVo.targetValue.ToNum()),this.baseItemData.count>1?this.text_num.textSet(`x${this.baseItemData.count}`):this.text_num.textSet(""),
null==Q.f.Inst().tryGetItemById(this.baseItemData.modelId_get())||F.M.IsNullOrEmpty(this.baseItemData.equipRes_get().equipModel)?(H.g.SetItemIcon(this.img_icon.FatherId,this.img_icon.ComponentId,this.baseItemData.cfgData_get().icon,U.b.eItem,!1),
this.baseItemData.cfgData_get().quality>0?(this.eff_theme_02_01.SetActive(!0),
this.eff_theme_02_01.namePrefixSet(`${j[this.baseItemData.cfgData_get().quality-1]}0`)):this.eff_theme_02_01.SetActive(!1),this.ClearPhoto()):(this.img_icon.spriteNameSet(""),
this.eff_theme_02_01.SetActive(!1),this.rtpanel.SetActive(!0),this.rtpanel.depthSet(n.N.inst.GetViewById(a.I.ThemeCarnival).GetPanelDeepth()+2),this.UpdatePhoto()),
this.huodongQuestVo==S.ins.show_reward_task_vos.LastItem()?(this.scale_obj.SetLocalScaleXYZ(1.3333,1.3333,1),
this.text_point.SetLocalPositionXYZ(0,-45,0)):(this.scale_obj.SetLocalScaleXYZ(1,1,1),this.text_point.SetLocalPositionXYZ(0,-38,0))}OnClickImgIcon(){
this.targetVo.curValue.ToNum()>=this.targetVo.targetValue.ToNum()&&!this.rewardVo.isReward?Z.l.ins.CM_GainActivitytaskReward(m.J.ins.GetQuestVoById(this.huodongQuestVo.taskId).activityId,this.huodongQuestVo.taskId):INS.itemTipManager.OpenTipView(this.baseItemData)
}UpdatePhoto(){const t=this.baseItemData.equipRes_get(),e=X.LuaDic_GetItem(t.wearPosition_get())
if(null==e)this.ClearPhoto()
else{e.equipres=t
const i=(0,B.aI)(t.equipModel)
e.displayId!=i&&(e.displayId=i,this.UpdateModel(e))}}UpdateModel(t){this.DeleteModelDisplay(t),0!=t.displayId?(this.bPhotoInited||(b.M.Instance_get().ActiveStage(J.STAGE_ID),
this.rttex.SetMainTextureByPhoto(J.STAGE_ID),this.rtpanel.SetActive(!0),this.bPhotoInited=!0),
this.CreateModelDisplay(t)):N.n.Instance_get().SetDisplayObject(J.STAGE_ID,0,t.photoIdx)}CreateModelDisplay(t){const e=new P.O
e._displayID=t.displayId,e._world=b.M.Instance_get().GetStageWorldType(J.STAGE_ID),t.displayHandle=N.n.Instance_get().CreateDisplayObject(e,null,-1,null,null,null,null),
N.n.Instance_get().SetDisplayObject(J.STAGE_ID,t.displayHandle,t.photoIdx)
const i=t.equipres.modle_show[1]+.25,s=t.equipres.modle_show[2],n=t.equipres.modle_show[3]
N.n.Instance_get().SetHeightOffset(t.displayHandle,0),N.n.Instance_get().SetPosXYZ(t.displayHandle,t.xPos,i,15),N.n.Instance_get().SetSize(t.displayHandle,n)
const a=new E.P(t.xRot,s,0)
b.M.Instance_get().SetWorldRotation_IgnoreDefaultYRot(J.STAGE_ID,t.photoIdx,a),N.n.Instance_get().SetCastShadow(t.displayHandle,!1)}DeleteModelDisplay(t){
0!=t.displayHandle&&(N.n.Instance_get().DeleteDisplayObject(t.displayHandle),t.displayHandle=0)}ClearPhoto(){if(this.bPhotoInited){for(const[t,e]of(0,
o.vy)(X))this.DeleteModelDisplay(e),e.displayId=0
b.M.Instance_get().DeactiveStage(J.STAGE_ID,this.rttex.FatherId,this.rttex.ComponentId),this.rtpanel.SetActive(!1),this.bPhotoInited=!1}}}J.STAGE_ID=158
var W=i(86133),$=i(62370),q=i(65550)
class tt extends M.x{constructor(...t){super(...t),this.huodong_id=0,this.text_name=null,this.img_red=null,this.img_bg=null,this.img_state=null,this.img_lock=null,
this.interval=null,this.redPointId=null}InitView(){super.InitView(),this.text_name=this.CreateComponent(T.Q,1),this.img_red=this.CreateComponent(R.w,2),
this.img_bg=this.CreateComponent(R.w,3),this.img_state=this.CreateComponent(R.w,4),this.img_lock=this.CreateComponent(R.w,5)}SetData(t){
null==this.interval&&(this.interval=r.C.Inst_get().SetInterval(this.CreateDelegate(this.UpdateState),1e3)),this.huodong_id=t,
this.redPointId=I.t[`THEMECARNIVAL_${this.huodong_id}`],this.AddLis(),this.Update()}AddLis(){this.m_handlerMgr.AddClickEvent(this.img_bg,this.CreateDelegate(this.OnClickImgBg)),
this.m_handlerMgr.AddEventMgr(u.g.THEME_SELECT_HUODONG,this.CreateDelegate(this.Update)),g.f.Inst.AddCallback(this.redPointId,this.CreateDelegate(this.UpdateRed))}RemoveLis(){
g.f.Inst.RemoveCallback(this.redPointId,this.CreateDelegate(this.UpdateRed))}Clear(){super.Clear(),this.RemoveLis(),r.C.Inst_get().ClearInterval(this.interval),
l.i.Inst.RemoveEventHandler(u.g.HUODONG_INFO_CHANGE,this.CreateDelegate(this.OnGetStartTime))}Destroy(){super.Destroy()}Update(){
this.text_name.textSet(m.J.ins.GetHuoDongVo(this.huodong_id).name),this.huodong_id==S.ins.select_huodong_id?(this.img_bg.spriteNameSet("ryzhutikuanghuan_sp_0004"),
this.img_bg.widthSet(193),this.img_bg.heightSet(80),this.text_name.SetLocalPositionXYZ(92,-27,0),this.img_red.SetLocalPositionXYZ(this.img_bg.width(),0,0),
this.img_state.SetLocalPositionXYZ(166,-54,0),this.text_name.SetColor(L.l.GetColorByHexStr("FEFBE3"))):(this.img_bg.spriteNameSet("ryzhutikuanghuan_sp_0005"),
this.img_bg.widthSet(152),this.img_bg.heightSet(66),this.text_name.SetLocalPositionXYZ(76,-21,0),this.img_state.SetLocalPositionXYZ(126,-42,0),
this.img_red.SetLocalPositionXYZ(this.img_bg.width(),0,0),this.text_name.SetColor(L.l.GetColorByHexStr("4C3535"))),this.UpdateState(),this.UpdateRed()}UpdateRed(){
const t=g.f.Inst.GetData(this.redPointId)
let e=t.show
const i=m.J.ins.GetHuoDongVo(this.huodong_id).themeRelation
if(!t.show&&0!=i){const t=S.ins.GetClientShowThemeIds()
let s=t.LastItem()
for(let e=0;e<=t.Count()-1;e++)if(C.i.ins.GetState(t[e])==G.V.OPEN){s=t[e]
break}this.huodong_id==s&&g.f.Inst.GetData(i).show&&(e=!0)}this.img_red.SetActive(e)}UpdateState(){this.img_state.SetActive(!1),this.img_lock.SetActive(!1),
C.i.ins.GetState(this.huodong_id)==G.V.OPEN?(this.img_state.SetActive(!0),
this.img_state.spriteNameSet("ryzhutikuanghuan_sp_0018")):C.i.ins.GetState(this.huodong_id)==G.V.END?(this.img_state.SetActive(!0),
this.img_state.spriteNameSet("ryzhutikuanghuan_sp_0019")):this.img_lock.SetActive(!0)}OnClickImgBg(){
if(!C.i.ins.IsActiveState(this.huodong_id))return l.i.Inst.AddEventHandler(u.g.HUODONG_INFO_CHANGE,this.CreateDelegate(this.OnGetStartTime)),
void Z.l.ins.CM_ActivityGetTime(new d.Z([this.huodong_id]))
S.ins.select_huodong_id!=this.huodong_id&&(S.ins.select_huodong_id=this.huodong_id,l.i.Inst.RaiseEvent(u.g.THEME_SELECT_HUODONG))}OnGetStartTime(t){
t==this.huodong_id&&(l.i.Inst.RemoveEventHandler(u.g.HUODONG_INFO_CHANGE,this.CreateDelegate(this.OnGetStartTime)),q.y.inst.ClientSysStrMsg($.o.Format((0,
W.T)("活动{0}天后开启"),D.p.CeilToInt(C.i.ins.GetStartMS(this.huodong_id)/864e5))))}}class et extends M.x{constructor(...t){super(...t),this.target_type=0,this.img_bg=null,
this.text_name=null,this.img_red=null,this.redPointId=null}InitView(){super.InitView(),this.img_bg=this.CreateComponent(R.w,1),this.text_name=this.CreateComponent(T.Q,2),
this.img_red=this.CreateComponent(R.w,3)}SetData(t){this.target_type=t,this.redPointId=I.t[`THEMECARNIVAL_${S.ins.select_huodong_id}_${this.target_type}`],this.AddLis(),
this.Update()}AddLis(){this.m_handlerMgr.AddClickEvent(this.img_bg,this.CreateDelegate(this.OnClickImgBg)),
this.m_handlerMgr.AddEventMgr(u.g.THEME_SELECT_TARGETTYPE,this.CreateDelegate(this.Update)),g.f.Inst.AddCallback(this.redPointId,this.CreateDelegate(this.UpdateRed))}RemoveLis(){
g.f.Inst.RemoveCallback(this.redPointId,this.CreateDelegate(this.UpdateRed))}Clear(){super.Clear(),this.RemoveLis()}Destroy(){super.Destroy()}Update(){
this.text_name.textSet(m.J.ins.GetQuestListVoByIdAndTargetType(S.ins.select_huodong_id,this.target_type)[0].typeName),
this.target_type==S.ins.select_target_type?(this.img_bg.spriteNameSet("ryzhutikuanghuan_sp_0014"),
this.text_name.SetColor(L.l.GetColorByHexStr("A76045"))):(this.img_bg.spriteNameSet("ryzhutikuanghuan_sp_0013"),this.text_name.SetColor(L.l.GetColorByHexStr("D6AD9B"))),
this.UpdateRed()}UpdateRed(){this.img_red.SetActive(g.f.Inst.GetData(this.redPointId).show)}OnClickImgBg(){
S.ins.select_target_type!=this.target_type&&(S.ins.select_target_type=this.target_type,l.i.Inst.RaiseEvent(u.g.THEME_SELECT_TARGETTYPE))}}
var it=i(78287),st=i(51868),nt=i(9986),at=i(63062),ot=i(79878),lt=i(83434)
class rt{}rt.THEME=1
class ht extends M.x{constructor(...t){super(...t),this.huodongQuestVo=null,this.targetVo=null,this.rewardVo=null,this.huodongCfgVo=null,this.text_name=null,this.bar_point=null,
this.text_bar=null,this.img_bar=null,this.img_bar_bg=null,this.right=null,this.img_get=null,this.btn_get=null,this.btn_go=null,this.img_currency=null,this.text_point=null,
this.img_type=null,this.flyLinkInfo=null}InitView(){super.InitView(),this.text_name=this.CreateComponent(T.Q,2),this.bar_point=this.CreateComponent(at.p,3),
this.text_bar=this.CreateComponent(T.Q,4),this.img_bar=this.CreateComponent(R.w,5),this.img_bar_bg=this.CreateComponent(R.w,6),this.right=this.CreateComponent(A.z,7),
this.img_get=this.CreateComponent(R.w,8),this.btn_get=this.CreateComponent(nt.W,9),this.btn_go=this.CreateComponent(nt.W,10),this.img_currency=this.CreateComponent(R.w,11),
this.text_point=this.CreateComponent(T.Q,12),this.img_type=this.CreateComponent(R.w,13)}SetData(t){this.huodongQuestVo=t,this.targetVo=this.huodongQuestVo.targetVos[0],
this.rewardVo=this.huodongQuestVo.activityRewardVo,this.huodongCfgVo=m.J.ins.GetQuestVoById(this.huodongQuestVo.taskId),this.UpdatePanel(),this.AddLis()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.btn_get,this.CreateDelegate(this.OnClickBtnGet)),this.m_handlerMgr.AddClickEvent(this.btn_go,this.CreateDelegate(this.OnClickBtnGo))}
RemoveLis(){}Clear(){super.Clear(),this.RemoveLis(),null!=this.flyLinkInfo&&(this.flyLinkInfo.Clear(),this.flyLinkInfo=null)}Destroy(){super.Destroy()}UpdatePanel(){
this.flyLinkInfo=lt.f.GetLinkInfo(new d.Z([this.huodongCfgVo.targetText]),this.huodongCfgVo.TargetDefs_Get(),this.huodongQuestVo.targetVos),
this.text_name.textSet(this.flyLinkInfo.GetTxtLabel()),this.img_type.SetActive(this.huodongCfgVo.taskType==rt.THEME),this.btn_get.SetActive(!1),this.btn_go.SetActive(!1),
this.img_get.SetActive(!1),
this.rewardVo.isReward?this.img_get.SetActive(!0):this.targetVo.curValue.ToNum()>=this.targetVo.targetValue.ToNum()?this.btn_get.SetActive(!0):this.btn_go.SetActive(!0)
let t=this.targetVo.curValue.ToNum()
t>this.targetVo.targetValue.ToNum()&&(t=this.targetVo.targetValue.ToNum())
const e=`[e6dfd8]${$.o.Format((0,W.T)("{0}/{1}"),L.l.GetRuleDecimalVal(t),L.l.GetRuleDecimalVal(this.targetVo.targetValue.ToNum()))}[-]`
this.text_bar.textSet(e)
const i=t/this.targetVo.targetValue.ToNum()*(this.img_bar_bg.width()-2)
0==i?this.img_bar.SetActive(!1):(this.img_bar.SetActive(!0),this.img_bar.widthSet(i))
const s=K.M.wrapReward(this.rewardVo.reward.rewards[0])
this.text_point.textSet(s.count)}OnClickBtnGet(){
if(!this.rewardVo.isReward&&this.targetVo.curValue.ToNum()>=this.targetVo.targetValue.ToNum()&&(Z.l.ins.CM_GainActivitytaskReward(this.huodongCfgVo.activityId,this.huodongCfgVo.id),
C.i.ins.GetState(this.huodongCfgVo.activityId)==G.V.OPEN)){const t=new E.P,e=this.btn_get.node.transform.TransformPoint(t)
l.i.Inst.RaiseEvent(u.g.THEMECARNIVAL_CLICK_GET_POINT,e)}}OnClickBtnGo(){this.rewardVo.isReward||(ot.Y.GotoByLinkStr(this.flyLinkInfo.linkStr),
n.N.inst.CloseById(a.I.ThemeCarnival))}}class dt extends st.${constructor(...t){super(...t),this.scroll_view=null,this.grid_quest=null,this.bar=null}InitView(){super.InitView(),
this.scroll_view=this.CreateComponent(V.$,1),this.grid_quest=this.CreateComponent(f.A,2),this.bar=this.CreateComponent(it._,3),
this.grid_quest.SetInitInfo("ui_themecarnival_quest_item",null,ht)}SetData(){this.AddLis(),this.bar.SetValue(0),this.UpdateView()}AddLis(){
this.m_handlerMgr.AddEventMgr(u.g.HUODONG_QUEST_CHANGE,this.CreateDelegate(this.UpdateView))}RemoveLis(){}Clear(){super.Clear()}Destroy(){super.Destroy()}UpdateView(){
const t=C.i.ins.GetQuestListVoByIdAndTargetType(S.ins.select_huodong_id,S.ins.select_target_type)
t.Sort(this.CreateDelegate(this.SortQuest)),this.grid_quest.data_set(t)}SortQuest(t,e){let i=-m.J.ins.GetQuestVoById(t.taskId).sort,s=-m.J.ins.GetQuestVoById(e.taskId).sort
return t.activityRewardVo.isReward&&(i+=1e7),e.activityRewardVo.isReward&&(s+=1e7),s-i}}class ut extends w.k{constructor(...t){super(...t),this.reward_items=null,
this.btn_close=null,this.grid_tab_right=null,this.grid_tab_top=null,this.reward_obj=null,this.bar_point=null,this.img_bar_bg=null,this.img_bar=null,this.text_point=null,
this.grid_reward=null,this.text_time=null,this.tween_point=null,this.img_ad=null,this.img_title=null,this.interval=null,this.curPoint=null}InitView(){super.InitView(),
this.btn_close=this.CreateComponent(R.w,1),this.grid_tab_right=this.CreateComponent(f.A,2),this.grid_tab_top=this.CreateComponent(f.A,3),
this.reward_obj=this.CreateComponent(A.z,5),this.bar_point=this.CreateComponent(A.z,6),this.img_bar_bg=this.CreateComponent(R.w,7),this.img_bar=this.CreateComponent(R.w,8),
this.text_point=this.CreateComponent(T.Q,9),this.grid_reward=this.CreateComponent(f.A,10),this.text_time=this.CreateComponent(T.Q,11),this.tween_point=this.CreateComponent(y.c,12),
this.img_ad=this.CreateComponent(R.w,13),this.img_title=this.CreateComponent(R.w,14),
this._subPanelDatas.Add(v.b.New(new d.Z(["ui_themecarnival_view","ui_themecarnival_quest_item"]),this,dt)),this.grid_tab_right.SetInitInfo("ui_themecarnival_right_btn",null,tt),
this.grid_tab_top.SetInitInfo("ui_themecarnival_top_btn",null,et),this.grid_reward.SetInitInfo("ui_themecarnival_reward_item",null,J)}OnAddToScene(){
null==this.interval&&(this.interval=r.C.Inst_get().SetInterval(this.CreateDelegate(this.OnEachSec),1e3)),this.AddLis(),this.CheckDefaultSelect(),this.UpdatePanel(),
this.tween_point.node.SetActive(!1)}AddLis(){this.m_handlerMgr.AddEventMgr(u.g.THEME_SELECT_HUODONG,this.CreateDelegate(this.UpdateHuoDong)),
this.m_handlerMgr.AddEventMgr(u.g.THEME_SELECT_TARGETTYPE,this.CreateDelegate(this.UpdateType)),
this.m_handlerMgr.AddEventMgr(u.g.THEMECARNIVAL_CLICK_GET_POINT,this.CreateDelegate(this.OnClickGetPoint)),
this.m_handlerMgr.AddEventMgr(u.g.HUODONG_QUEST_CHANGE,this.CreateDelegate(this.UpdateReward)),
this.m_handlerMgr.AddClickEvent(this.btn_close,this.CreateDelegate(this.OnClickBtnClose))}RemoveLis(){}Clear(){super.Clear(),S.ins.default_select_target_type=-1,
S.ins.default_select_huodong_id=-1,S.ins.show_reward_task_vos=null,r.C.Inst_get().ClearInterval(this.interval),
this.tween_point.RemoveEventHandler(this.CreateDelegate(this.OnTweenPointEnd))}Destroy(){super.Destroy()}UpdatePanel(){this.grid_tab_right.data_set(S.ins.GetClientShowThemeIds()),
this.UpdateHuoDong()}UpdateHuoDong(){if(-1!=S.ins.default_select_target_type)S.ins.select_target_type=S.ins.default_select_target_type,S.ins.default_select_target_type=-1
else{const t=m.J.ins.GetTargetTypesByHuoDongId(S.ins.select_huodong_id,O.h.THEME_SCORE_REWARD)
S.ins.select_target_type=t[0]
for(let e=0;e<=t.Count()-1;e++){const i=g.f.Inst.GetData(I.t[`THEMECARNIVAL_${S.ins.select_huodong_id}_${t[e]}`])
if(null!=i&&i.show){S.ins.select_target_type=t[e]
break}}}this.grid_tab_top.data_set(m.J.ins.GetTargetTypesByHuoDongId(S.ins.select_huodong_id,O.h.THEME_SCORE_REWARD))
const t=m.J.ins.GetHuoDongVo(S.ins.select_huodong_id).ClientShowParams_Get()
null!=t&&t.Count()>=2&&(this.img_title.spriteNameSet(t[0]),this.img_ad.spriteNameSet(t[1])),this.UpdateType(),this.UpdateReward(),this.OnEachSec()}UpdateType(){this.UpdateView()}
UpdateView(){this.ShowSubView(0)}CheckDefaultSelect(){if(-1!=S.ins.default_select_huodong_id)S.ins.select_huodong_id=S.ins.default_select_huodong_id,
S.ins.default_select_huodong_id=-1
else{const t=S.ins.GetClientShowThemeIds()
S.ins.select_huodong_id=0
for(let e=0;e<=t.Count()-1;e++){0==S.ins.select_huodong_id&&C.i.ins.GetState(t[e])==G.V.OPEN&&(S.ins.select_huodong_id=t[e])
const i=g.f.Inst.GetData(I.t[`THEMECARNIVAL_${t[e]}`])
if(null!=i&&i.show){S.ins.select_huodong_id=t[e]
break}}0==S.ins.select_huodong_id&&(S.ins.select_huodong_id=t[0])}}UpdateReward(){const t=S.ins.GetRewardTaskVos(S.ins.select_huodong_id,O.h.THEME_SCORE_REWARD)
if(0==t.Count())return
S.ins.show_reward_task_vos=t
const e=this.img_bar_bg.width()/t.Count(),i=this.img_bar.GetLocalPosition(),s=this.grid_reward.GetLocalPosition()
let n=0
this.curPoint=0,this.grid_reward.SetLocalPositionXYZ(i.x+e,s.y,0),this.grid_reward.cellWidthSet(e),this.grid_reward.data_set(t)
for(let e=0;e<=t.Count()-1;e++)this.curPoint<t[e].targetVos[0].curValue.ToNum()&&(this.curPoint=t[e].targetVos[0].curValue.ToNum(),n=e)
if(this.text_point.textSet(this.curPoint),n==t.Count()-1)this.img_bar.SetActive(!0),this.img_bar.widthSet(this.img_bar_bg.width())
else{let i=0
i=0==n?e*(this.curPoint/t[n].targetVos[0].targetValue.ToNum()):e*n+e*((this.curPoint-t[n-1].targetVos[0].targetValue.ToNum())/(t[n].targetVos[0].targetValue.ToNum()-t[n-1].targetVos[0].targetValue.ToNum())),
0==i?this.img_bar.SetActive(!1):this.img_bar.SetActive(!0),this.img_bar.widthSet(i)}}OnClickBtnClose(){n.N.inst.CloseById(a.I.ThemeCarnival)}OnClickGetPoint(t){
this.tween_point.node.SetActive(!0)
const e=new E.P(this.img_bar.width(),0,0)
let i=this.img_bar.node.transform.TransformPoint(e)
i=this.node.transform.InverseTransformPoint(i)
const s=this.node.transform.InverseTransformPoint(t)
this.tween_point.AddEventHandler(this.CreateDelegate(this.OnTweenPointEnd)),this.tween_point.SetFrom(s),this.tween_point.SetTo(i),this.tween_point.ResetToBeginning(),
this.tween_point.PlayForward()}OnTweenPointEnd(){this.tween_point.RemoveEventHandler(this.CreateDelegate(this.OnTweenPointEnd)),this.tween_point.node.SetActive(!1)}OnEachSec(){
const t=C.i.ins.huodong_dict.LuaDic_GetItem(S.ins.select_huodong_id)
if(null!=t){const e=D.p.FloorToInt(t.endTime.ToNum()/1e3)-p.D.serverTime_get()
e>0?this.text_time.textSet(`[b09979]结束倒计时:[-] [5fb470]${L.l.GetDateFormatEX(e,!0,!0)}[-]`):this.text_time.textSet("[b09979]已结束[-]"),
(!c.P.inst.IsFunctionOpened(_.x.THEMECARNIVAL)||t.delayTime.ToNum()<=p.D.serverMSTime_get())&&n.N.inst.CloseById(a.I.ThemeCarnival)}}}class ct{constructor(){this.AddLis()}
AddLis(){}OpenPanel(t,e){null!=t&&(S.ins.default_select_huodong_id=t),null!=e&&(S.ins.default_select_target_type=e)
const i=new s.v
i.isShowMask=!0,i.isDefaultUITween=!0,i.isSelfTween=!1,i.viewClass=ut,n.N.inst.OpenById(a.I.ThemeCarnival,null,null,i)}}ct.ins=null},82949:(t,e,i)=>{i.d(e,{R:()=>oi})
var s=i(82815),n=i(98800),a=i(57121),o=i(89549),l=i(32309),r=i(97461),h=i(38952),d=i(36241),u=i(13687),c=i(98497),_=i(38935),I=i(62370),g=i(56937),m=i(31222),C=i(5494),S=i(8334),p=i(52726),A=i(35128),f=i(98885),y=i(62699),T=i(15965),R=i(22107),v=i(84229),w=i(21554),D=i(70850),E=i(3859),L=i(84308),G=i(54415),O=i(92679),b=i(87923),B=i(29839),N=i(85770),P=i(72800),M=i(13476),V=i(43465),k=i(27509),x=i(30677),H=i(81621),U=i(83317),F=i(27877),Y=i(11869),K=i(6413),z=i(65128),Q=i(96624),Z=i(44286),X=i(64922),j=i(59843),J=i(12952),W=i(3697),$=i(63666),q=i(31105),tt=i(52073),et=i(56275),it=i(96713),st=i(17783),nt=i(85890),at=i(15398),ot=i(99535),lt=i(99421),rt=i(12842),ht=i(40312),dt=i(61911)
class ut extends dt.f{InitView(){super.InitView()}Clear(){super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}}var ct=i(99294),_t=i(13113),It=i(60130)
class gt extends dt.f{constructor(...t){super(...t),this.rewardbtn=null,this.anchor=null}InitView(){super.InitView(),this.rewardbtn=this.CreateComponent(ct.z,1),
this.anchor=this.CreateComponent(_t.T,2)}OnAddToScene(){It.O.SetAnchorPos(this.anchor,!0),this.m_handlerMgr.AddClickEvent(this.rewardbtn,this.CreateDelegate(this.RewardHandler))}
RewardHandler(){oi.Inst_get().OpenCollctRewardView()}Clear(){super.Clear()}Destroy(){super.Destroy(),this.rewardbtn=null,this.anchor=null}Test1(){return!0}S_Test(){return!0}}
var mt=i(98958),Ct=i(6665),St=i(93877),pt=i(85602),At=i(75696),ft=i(47786),yt=i(74657)
class Tt extends dt.f{constructor(...t){super(...t),this.closeBtn=null,this.closeBtn2=null,this.desLab=null,this.grid=null}InitView(){super.InitView(),
this.closeBtn=this.CreateComponent(ct.z,1),this.closeBtn2=this.CreateComponent(ct.z,2),this.desLab=this.CreateComponent(St.Q,3),this.grid=this.CreateComponent(Ct.A,4),
this.grid.SetInitInfo("ui_baseitem",this.CreateDelegate(this.OnInitItem))}OnInitItem(t){const e=new At.j
return e.setId(t,null,0),e.SetBgSize(66,66),e.SetIconSize(66,66),e}OnAddToScene(){this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.CloseHandler)),
this.m_handlerMgr.AddClickEvent(this.closeBtn2,this.CreateDelegate(this.CloseHandler))
const t=ht.B.Inst_get().GetCollectReward(),e=t.count,i=new pt.Z
for(let s=0;s<=e-1;s++)yt.A.GetRewardByAnrewardList(t[s].rewards,i)
const s=new pt.Z
for(let t=0;t<=i.count-1;t++){let e=!0
for(let n=0;n<=s.count-1;n++)if(s[n].modelId_get()==i[t].modelId_get()){s[n].count=s[n].count+i[t].count,e=!1
break}e&&s.Add(i[t])}this.grid.data_set(s),this.desLab.textSet(mt.V.Inst().replaceLangParamOne(ft.x.Inst().getItemStrById(11044017),e)),ht.B.Inst_get().CheckClearCollectData()}
CloseHandler(){oi.Inst_get().CloseCollctRewardView()}Clear(){super.Clear()}Destroy(){super.Destroy(),this.closeBtn=null,this.closeBtn2=null,this.desLab=null,this.grid=null}Test1(){
return!0}S_Test(){return!0}}var Rt=i(38045),vt=i(67075),wt=i(5924),Dt=i(64732),Et=i(9986),Lt=i(78287),Gt=i(9776),Ot=i(8889),bt=i(70377),Bt=i(92178),Nt=i(72005),Pt=i(33314)
class Mt extends Bt.E{constructor(...t){super(...t),this.rangeTxt=null,this.nameTxt=null,this.scoreTxt=null,this.headIcon=null,this.data=null}SetSelected(t){}GetMyTreeData(){
return this.treeData}InitView(){super.InitView(),this.rangeTxt=this.CreateComponent(St.Q,1),this.nameTxt=this.CreateComponent(St.Q,2),this.scoreTxt=this.CreateComponent(St.Q,3),
this.headIcon=this.CreateComponent(Nt.w,4)}Destory(){super.Destory()}SetMyTreeData(t){this.treeData=t,this.data=t.data
const e=this.data.vo
this.rangeTxt.textSet(e.level),this.nameTxt.node.SetActive(!0),this.nameTxt.textSet(e.playerName),this.headIcon.spriteNameSet(Pt.Z.GetJobIcon(e.job,e.sex,!1)),
this.scoreTxt.textSet(e.lotteryNum),this.AddLis()}AddLis(){}RemoveLis(){}Clear(){this.data=null,this.RemoveLis(),super.Clear()}}var Vt=i(9057),kt=i(88653)
class xt extends Vt.x{constructor(...t){super(...t),this.rangeTxt=null,this.grid=null,this.bg=null,this.infoObj=null,this.headIcon=null,this.nameLab=null,this.scoreLab=null,
this.treeData=null}InitView(){super.InitView(),this.rangeTxt=this.CreateComponent(St.Q,1),this.grid=this.CreateComponent(Ct.A,2),this.bg=this.CreateComponent(Nt.w,3),
this.infoObj=this.CreateComponent(ct.z,4),this.headIcon=this.CreateComponent(Nt.w,5),this.nameLab=this.CreateComponent(St.Q,6),this.scoreLab=this.CreateComponent(St.Q,7),
this.grid.SetInitInfo("ui_baseitem",this.CreateDelegate(this.OnInitItem))}OnInitItem(t){const e=new At.j
return e.setId(t,null,0),e.SetBgSize(66,66),e.SetIconSize(66,66),e}SetData(t){this.treeData=t
const e=t.data.id,i=t.data.vo,s=ht.B.Inst_get().GetLotteryConfig(e),n=bt.F.Inst_get().GetLucyCfg(e)
1==e?(this.rangeTxt.gradientTopSet(new kt.I(1,193/255,61/255,1)),this.rangeTxt.gradientBottomSet(new kt.I(241/255,228/255,147/255,1)),
this.bg.spriteNameSet("ryjinjichang_sp_0003")):2==e?(this.rangeTxt.gradientTopSet(new kt.I(123/255,161/255,200/255,1)),
this.rangeTxt.gradientBottomSet(new kt.I(191/255,222/255,235/255,1)),this.bg.spriteNameSet("ryjinjichang_sp_0004")):(this.rangeTxt.gradientTopSet(new kt.I(1,193/255,61/255,1)),
this.rangeTxt.gradientBottomSet(new kt.I(246/255,206/255,147/255,1)),this.bg.spriteNameSet("ryjinjichang_sp_0005")),null!=n&&this.rangeTxt.textSet(n.name),
this.grid.data_set(s.rewards),this.ShowInfo(i),this.AddLis()}ShowInfo(t){null!=t?(this.infoObj.SetActive(!0),this.nameLab.textSet(t.playerName),
this.headIcon.spriteNameSet(Pt.Z.GetJobIcon(t.job,t.sex,!1)),this.scoreLab.textSet(t.lotteryNum)):null!=this.infoObj&&this.infoObj.SetActive(!1)}CheckGuide(t){}SetSelected(t){
super.SetSelected(t)}GetMyTreeData(){return this.treeData}AddLis(){}RemoveLis(){}Clear(){super.Clear()}Destroy(){super.Destroy(),this.rangeTxt=null,this.grid=null,this.bg=null,
this.infoObj=null,this.headIcon=null,this.nameLab=null,this.scoreLab=null}Test1(){return!0}S_Test(){return!0}}class Ht extends dt.f{constructor(...t){super(...t),this.tree=null,
this.treeScrollView=null,this.closeBtn=null,this.numlab=null,this.grid=null,this.treeScrollBar=null,this.uipanel=null,this.rewardview=null,this.emptyObj=null,this.btn_get=null,
this.img_get=null,this.deslab=null,this.myData=null,this.lis=null,this.lastTreeData=null,this.timeid=null,this.hasreward=null}InitView(){super.InitView(),
this.tree=this.CreateComponent(Dt.f,1),this.treeScrollView=this.CreateComponent(Gt.h,2),this.closeBtn=this.CreateComponent(Et.W,3),this.numlab=this.CreateComponent(St.Q,6),
this.grid=this.CreateComponent(Ct.A,8),this.treeScrollBar=this.CreateComponent(Lt._,9),this.uipanel=this.CreateComponent(Ot.$,10),this.rewardview=this.CreateComponent(ct.z,11),
this.emptyObj=this.CreateComponent(ct.z,12),this.btn_get=this.CreateComponent(Et.W,13),this.img_get=this.CreateComponent(ct.z,14),this.deslab=this.CreateComponent(St.Q,15),
this.myData=null,this.lis=new pt.Z,this.tree.SetTitleAndItemName("ui_publicbeta_daliy_reward_part","ui_publicbeta_daliy_reward_item"),
this.tree.SetTreeItemDelegate(this.CreateDelegate(this.CreateRewardPart),this.CreateDelegate(this.CreateRewardItem)),
this.grid.SetInitInfo("ui_baseitem",this.CreateDelegate(this.OnInitItem))}OnInitItem(t){const e=new At.j
return e.setId(t,null,0),e.SetBgSize(66,66),e.SetIconSize(66,66),e}CreateRewardPart(t){const e=new xt
return e.setId(t,null,0),e}CreateRewardItem(t){const e=new Mt
return e.setId(t,null,0),e}OnInitPart(t){const e=new xt
return e.setId(t,null,0),e}OnAddToScene(){super.OnAddToScene(),this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.CloseHandler)),
this.m_handlerMgr.AddClickEvent(this.btn_get,this.CreateDelegate(this.RewardHandler)),this.AddEvent(),this.UpdateView()}AddEvent(){
ht.B.Inst_get().AddEventHandler(ht.B.PUBLICBETA_LOTTERY_INFO,this.CreateDelegate(this.UpdateView)),
ht.B.Inst_get().AddEventHandler(ht.B.PUBLICBETA_LOTTERY_CONFIG,this.CreateDelegate(this.UpdateView)),
ht.B.Inst_get().AddEventHandler(ht.B.PUBLICBETA_LOTTERY_RESULT,this.CreateDelegate(this.UpdateView)),
this.tree.AddEventHandler(O.g.TREE_ITEM_CHENGE,this.CreateDelegate(this.ItemChangeHandler)),
this.tree.AddEventHandler(O.g.TREE_ITEM_CLICK,this.CreateDelegate(this.ItemClickHandler))}RemoveEvent(){
ht.B.Inst_get().RemoveEventHandler(ht.B.PUBLICBETA_LOTTERY_INFO,this.CreateDelegate(this.UpdateView)),
ht.B.Inst_get().RemoveEventHandler(ht.B.PUBLICBETA_LOTTERY_CONFIG,this.CreateDelegate(this.UpdateView)),
ht.B.Inst_get().RemoveEventHandler(ht.B.PUBLICBETA_LOTTERY_RESULT,this.CreateDelegate(this.UpdateView)),
this.tree.RemoveEventHandler(O.g.TREE_ITEM_CHENGE,this.CreateDelegate(this.ItemChangeHandler)),
this.tree.RemoveEventHandler(O.g.TREE_ITEM_CLICK,this.CreateDelegate(this.ItemClickHandler))}SortCompareFunc(t,e){return t.id-e.id}UpdateView(){
const[t,e]=ht.B.Inst_get().LastLottoryRewardInfoList()
this.myData=e,this.lis.Clear()
for(let e=0;e<=t.Count()-1;e++){const i=t[e].id,s=new vt.t(0,(0,Rt.tw)(i),"0",(0,Rt.tw)(i),{id:i})
s.expand=!0,e==t.Count()-1&&(this.lastTreeData=s),this.lis.Add(s)
const n=ht.B.Inst_get().LastLottoryRewardInfo(t[e].level),a=1==t[e].numberLimit
for(let t=0;t<=n.count-1;t++){const e=n[t]
if(a)s.data.vo=e
else{const s=new vt.t(0,`${t}*`,(0,Rt.tw)(i),`${t}*`,{vo:e,rank:i})
this.lis.Add(s)}}}this.tree.SetData(this.lis),this.UpdateMyReward()}ItemChangeHandler(t){}ItemClickHandler(t){
this.timeid=wt.C.Inst_get().SetFrameLoop(this.CreateDelegate(this.SetBarValue),1,1)}ClearTimer(){null!=this.timeid&&(wt.C.Inst_get().ClearInterval(this.timeid),this.timeid=null)}
SetBarValue(){this.timeid=null,this.treeScrollView.UpdatePosition()}UpdateMyReward(){if(this.hasreward=null!=this.myData,this.hasreward){this.UpdateMyRewardState(),
this.emptyObj.SetActive(!1),this.rewardview.SetActive(!0),this.numlab.textSet(this.myData.lotteryNum)
const t=bt.F.Inst_get().GetLucyCfgByLevel(this.myData.level)
null!=t&&this.deslab.textSet(t.dec)
const e=ht.B.Inst_get().GetLotteryConfig(this.myData.level)
this.grid.data_set(e.rewards)}else this.emptyObj.SetActive(!0),this.rewardview.SetActive(!1)}UpdateMyRewardState(){if(!this.hasreward)return
ht.B.Inst_get().canGained?(this.btn_get.node.SetActive(!0),this.img_get.SetActive(!1)):(this.btn_get.node.SetActive(!1),this.img_get.SetActive(!0))}CloseHandler(){
oi.Inst_get().CloseDaliyLotteryRewardView()}RewardHandler(){ht.B.Inst_get().clickGainLottery=!0,oi.Inst_get().ReqCM_GetBetaLotteryReward()}Clear(){this.RemoveEvent(),super.Clear()}
Destroy(){super.Destroy(),this.tree=null,this.treeScrollView=null,this.closeBtn=null,this.numlab=null,this.grid=null,this.treeScrollBar=null,this.uipanel=null,this.rewardview=null,
this.emptyObj=null,this.btn_get=null,this.img_get=null,this.deslab=null}Test1(){return!0}S_Test(){return!0}}class Ut extends Vt.x{constructor(...t){super(...t),this.goodGrid=null,
this.costLabel=null,this.numLabel=null}InitView(){super.InitView(),this.goodGrid=this.CreateComponent(Ct.A,1),this.costLabel=this.CreateComponent(St.Q,2),
this.numLabel=this.CreateComponent(St.Q,3),this.goodGrid.SetInitInfo("ui_baseitem",null,At.j)}SetData(t){super.SetData(t)
const e=bt.F.Inst_get().GetLucyCfg(t.id)
null!=e?this.costLabel.textSet(e.name):this.costLabel.textSet(`${b.l.GetChineseNum(e.level)}等奖`)
const i=t.rewards
this.goodGrid.data_set(i),this.numLabel.textSet(`${t.numberLimit}名`)}Clear(){super.Clear()}Destroy(){super.Destroy(),this.goodGrid=null,this.costLabel=null,this.numLabel=null}
Test1(){return!0}S_Test(){return!0}}class Ft extends dt.f{constructor(...t){super(...t),this.tipview=null,this.tipsgrid=null}InitView(){super.InitView(),
this.tipview=this.CreateComponent(ct.z,1),this.tipsgrid=this.CreateComponent(Ct.A,2),this.tipsgrid.SetInitInfo("ui_publicbeta_daliy_tip_item",null,Ut)}OnAddToScene(){
super.OnAddToScene(),this.m_handlerMgr.AddClickEvent(this.tipview,this.CreateDelegate(this.CloseHandler)),this.UpdateView()}UpdateView(){
this.tipsgrid.data_set(ht.B.Inst_get().lotteryConfigList)}CloseHandler(){this.node.SetActive(!1)}Clear(){super.Clear()}Destroy(){super.Destroy(),this.tipview=null,
this.tipsgrid=null}Test1(){return!0}S_Test(){return!0}}var Yt=i(38836),Kt=i(18202),zt=i(83540),Qt=i(63076),Zt=i(85751),Xt=i(65550)
class jt extends dt.f{constructor(...t){super(...t),this.Id=null,this.closeBtn=null,this.lightBtn=null,this.chipName=null,this.chipIcon=null,this.icon0=null,this.icon1=null,
this.eff=null,this.num=null,this.text=null,this.itemData0=null,this.itemData1=null}InitView(){super.InitView(),this.closeBtn=this.CreateComponent(ct.z,1),
this.lightBtn=this.CreateComponent(ct.z,2),this.chipName=this.CreateComponent(St.Q,3),this.chipIcon=this.CreateComponent(Nt.w,4),this.icon0=this.CreateComponent(Nt.w,5),
this.icon1=this.CreateComponent(Nt.w,6),this.eff=this.CreateComponent(ct.z,7),this.num=this.CreateComponent(St.Q,8),this.text=this.CreateComponent(St.Q,9)}OnAddToScene(){
this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.ClickCloseBtn)),this.m_handlerMgr.AddClickEvent(this.lightBtn,this.CreateDelegate(this.ClickLightBtn)),
this.m_handlerMgr.AddClickEvent(this.icon0,this.CreateDelegate(this.ClickIcon0)),this.m_handlerMgr.AddClickEvent(this.icon1,this.CreateDelegate(this.ClickIcon1)),
this.m_handlerMgr.AddEventMgr(O.g.BAG_UPDATE,this.CreateDelegate(this.setConsumeNumber)),
ht.B.Inst_get().AddEventHandler(ht.B.PUBLICBETA_JIGSAW_INFO,this.CreateDelegate(this.RefreshContent)),this.Id=ht.B.Inst_get().clickJigsawChipId,this.eff.SetActive(!1),
this.RefreshContent()}ClickIcon0(){null!=this.itemData0&&w.J.Inst_get().ShowItemTip(this.itemData0)}ClickIcon1(){null!=this.itemData1&&w.J.Inst_get().ShowItemTip(this.itemData1)}
setConsumeNumber(){const t=D.g.Inst_get().GetItemNum(this.itemData0.modelId_get())
t<this.itemData0.needNum?this.num.textSet(`[de2524]${t}[-]/${this.itemData0.needNum}`):this.num.textSet(`[${Zt.u.GreenColorStr}]${t}/${this.itemData0.needNum}[-]`)}
RefreshContent(){const t=bt.F.Inst_get().GetJigsawChipConfig(this.Id)
this.chipName.textSet(t.puzzleName)
const e=ht.B.Inst_get().JigsawConfig_get().puzzleResourceVoMap[this.Id].consumeTable
let i,s=0
for(const[t,i]of(0,Yt.X)(e)){const e=new Qt.M(t)
e.needNum=i,0==s&&(Kt.g.SetItemIcon(this.icon0.FatherId,this.icon0.ComponentId,e.cfgData_get().icon,zt.b.eItem,!1),this.itemData0=e),s+=1}this.setConsumeNumber(),
ht.B.Inst_get().IsJigsawChipLighted(this.Id)?(i=t.icon,this.text.textSet("关 闭")):(i=t.iconGray,this.text.textSet("点 亮")),
t.chapter<3?this.chipIcon.SetItemIconByAtlas(i,"pre_rygckh",!0):this.chipIcon.SetItemIconByAtlas(i,"pre_rygckh1",!0)
const n=this.chipIcon.height()/139
this.chipIcon.heightSet(139),this.chipIcon.widthSet(this.chipIcon.width()/n)}ClickCloseBtn(){oi.Inst_get().CloseJigsawLightChipPanel()}ClickLightBtn(){
const[t,e]=ht.B.Inst_get().IsJigsawChipCanLight(this.Id)
t?(this.eff.SetActive(!0),oi.Inst_get().ReqCM_JigsawChipAct(this.Id)):1==e?Xt.y.inst.ClientSysStrMsg("点亮材料不足"):2==e&&this.ClickCloseBtn()}Clear(){super.Clear(),
ht.B.Inst_get().RemoveEventHandler(ht.B.PUBLICBETA_JIGSAW_INFO,this.CreateDelegate(this.RefreshContent)),ht.B.Inst_get().RaiseEvent(ht.B.PUBLICBETA_JIGSAW_INFO,null,2)}Destroy(){
super.Destroy()}Test1(){return!0}S_Test(){return!0}}
var Jt=i(68662),Wt=i(36334),$t=i(44255),qt=i(28287),te=i(55492),ee=i(14792),ie=i(56834),se=i(93727),ne=i(43977),ae=i(43662),oe=i(97960),le=i(61447),re=i(59475),he=i(45404),de=i(31546),ue=i(70650),ce=i(16261),_e=i(51868),Ie=i(38908),ge=i(75439),me=i(11037),Ce=i(92447),Se=i(57834)
class pe extends Vt.x{constructor(){super(),this.data=null,this.showItemDataLis=null,this.bg=null,this.desc=null,this.grid=null,this.getBtn=null,this.hasGet=null,
this.goRechargeBtn=null,this.progressSlider=null,this.sliderTxt=null,this.isGet=null,this.todayTotalRecharge=null,this.showItemDataLis=new CList}InitView(){
this.bg=this.CreateComponent(LuaUISprite,1),this.desc=this.CreateComponent(LuaUILabel,2),this.grid=this.CreateComponent(LuaMyUIGrid,3),
this.getBtn=this.CreateComponent(LuaMyUIButton,4),this.hasGet=this.CreateComponent(LuaGameObject,5),this.goRechargeBtn=this.CreateComponent(LuaMyUIButton,6),
this.progressSlider=this.CreateComponent(LuaUISlider,7),this.sliderTxt=this.CreateComponent(LuaUILabel,8),
this.grid.SetInitInfo("ui_welfare_dailytotalrecharge_baseitem",null,DailyTotalRechargeBaseItem)}Destroy(){this.grid.Destroy()}SetDepth(){
const t=RyPublicBetaControl.Inst_get().GetMainPanelId()
t&&UIShowMgr.inst.SetChildDepth(t,this.FatherId)}SetData(t){this.AddLis(),this.data=t,this.UpdateInfo()}AddLis(){
Se.i.Get(this.getBtn.node).RegistonClick(this.CreateDelegate(this.OnGetBtnHandle)),Se.i.Get(this.goRechargeBtn.node).RegistonClick(this.CreateDelegate(this.OnGoRechargeHandle))}
RemoveLis(){Se.i.Get(this.getBtn.node).RemoveonClick(this.CreateDelegate(this.OnGetBtnHandle)),
Se.i.Get(this.goRechargeBtn.node).RemoveonClick(this.CreateDelegate(this.OnGoRechargeHandle))}OnGetBtnHandle(){
RyPublicBetaControl.Inst_get().ReqBetaRechargeReward(this.data.activityId,this.data.id)}OnGoRechargeHandle(){
if(!RechargeModel.Inst_get().isFristRecharge)return FunctionOpenModel.Inst_get().IsFunctionOpened(FunctionType.FIRST_CHARGE)?void FirstChargeControl.Inst_get().OpenView():void CommonUtil.SetFunctionTip(FunctionType.FIRST_CHARGE)
FunctionOpenModel.Inst_get().IsFunctionOpened(FunctionType.MALL)&&(MarketMallModel.GetInst().CheckShopHasGoodsBuy(3,1)?MarketControl_ry.Inst_get().Open(null,3,1):MarketControl_ry.Inst_get().Open(null,2,1))
}UpdateInfo(){this.RefreshBtnState(),this.UpdateItemLis()}RefreshBtnState(){this.isGet=RyPublicBetaModel.Inst_get().GetHasGain(this.data.activityId,this.data.id),
this.todayTotalRecharge=RyPublicBetaModel.Inst_get().GetTotolCharge(this.data.activityId),this.isGet?(this.getBtn.node.SetActive(!1),
this.goRechargeBtn.node.SetActive(!1)):this.data.currency<=this.todayTotalRecharge?(this.getBtn.node.SetActive(!0),
this.goRechargeBtn.node.SetActive(!1)):(this.getBtn.node.SetActive(!1),this.goRechargeBtn.node.SetActive(!0)),this.hasGet.SetActive(this.isGet),this.bg.node.SetActive(!this.isGet)
let t=this.todayTotalRecharge
t>this.data.currency&&(t=this.data.currency),this.sliderTxt.textSet(`${t}/${this.data.currency}`),this.progressSlider.SetValue(t/this.data.currency),
this.desc.textSet(`累计充值${this.data.currency}元`)}UpdateItemLis(){this.showItemDataLis.Clear()
const t=this.data.rewardId.rewards
for(let e=0;e<=t.Count()-1;e++){const i=BaseItemData.wrapReward(t[e]),s=this.isGet,n={}
n.itemData=i,n.hasGet=s,this.showItemDataLis.Add(n)}this.grid.data_set(this.showItemDataLis)}Clear(){this.grid.Clear(),this.RemoveLis(),this.data=null}}const Ae=164
class fe extends _e.${constructor(...t){super(...t),this.scrollView=null,this.myGrid=null,this.bar=null,this.item1=null,this.itemIcon1=null,this.timetips=null,
this.tex_ride_show=null,this.rotate_obj=null,this.ui_publicbeta_eff_view=null,this.showItemDataLis=null,this.m_horse=null,this.roleRotateIndex=null,this.showItemData=null,
this.intervalId=null,this.info=null,this.show=null,this.tiemrId=null,this.idx=null,this.countDownTimer=null,this.lis=null}InitView(){super.InitView(),
this.scrollView=this.CreateComponent(Gt.h,1),this.myGrid=this.CreateComponent(Ct.A,2),this.bar=this.CreateComponent(Lt._,3),this.item1=this.CreateComponent(ct.z,7),
this.itemIcon1=this.CreateComponent(Nt.w,10),this.timetips=this.CreateComponent(St.Q,11),this.tex_ride_show=this.CreateComponent(ce.X,12),
this.rotate_obj=this.CreateComponent(ct.z,13),this.ui_publicbeta_eff_view=this.CreateComponentBinder(Ce.k,14),
this.myGrid.SetInitInfo("ui_welfare_dailytotalrecharge_item",this.CreateDelegate(this.OnCreateItem)),this.showItemDataLis=new pt.Z}OnCreateItem(t){const e=new pe
return e.setId(t,null,0),e.SetDepth(),e}ShowHorseModel(){const t=ge.D.getInstance().GetIntValue("PUBLICBETA:TOTALRECHARGE_RIDE_ID"),e=me.D.GetInst().GetCfg(t),i=e.modelId
ae.M.Instance_get().ActiveStage(Ae)
const s=new le.V,n=new de.O
n._displayID=i,n._displayID=M.E.Instance.TryReplaceDisplayID(Ie.C.ReplaceTypeRIDING,n._displayID),n._world=ae.M.Instance_get().GetStageWorldType(Ae)
const a=f.M.Split(e.parameter,I.o.s_Arr_UNDER_CHAR_DOT)
n._vPos.Set(0,0),n._fSize=f.M.String2Float(a[2]/1.5)
let o=180
a.count>3&&(o=f.M.String2Float(a[3])),n._fDir=o,null==this.m_horse?(this.m_horse=new re.t,this.m_horse.Info_set(s),this.m_horse.Owner_set(null),
this.m_horse.initByDisinfo(n)):(this.m_horse.Destroy(),this.m_horse=new re.t,this.m_horse.Info_set(s),this.m_horse.Owner_set(null),this.m_horse.initByDisinfo(n)),
this.m_horse.Info_get().AddEventHandler(oe.A.HorseInit,this.CreateDelegate(this.HorseInitHandler)),he.n.Instance_get().SetDisplayObject(Ae,this.m_horse.MainRole_get().handle,0),
this.tex_ride_show.SetMainTextureByPhoto(Ae),this.tex_ride_show.SetUVRect(0,0,1,1),this.m_horse.MainRole_get().IsInited()&&this.HorseInitHandler(null),
this.m_horse.setPosXYZ(f.M.String2Float(a[0]),f.M.String2Float(a[1]),0),this.m_horse.MainRole_get().SetDirection(o)
const l=ae.M.Instance_get().GetDisplayHeight(Ae,0)
this.m_horse.MainRole_get().SetCastShadow(!0),this.m_horse.MainRole_get().SetShadowHeight(l)}ShowCurrencyBar_get(){return qt._.None}HorseInitHandler(){
null!=this.m_horse&&this.m_horse.IsInited()&&null!=this.m_horse&&(null!=this.roleRotateIndex&&(ue.e.GetInst().UnregDrag(this.roleRotateIndex),this.roleRotateIndex=null),
this.roleRotateIndex=ue.e.GetInst().RegDrag(this.rotate_obj,this.m_horse.MainRole_get()))}RemoveHorse(){null!=this.roleRotateIndex&&(ue.e.GetInst().UnregDrag(this.roleRotateIndex),
this.roleRotateIndex=null),ae.M.Instance_get().DeactiveStage(Ae,this.tex_ride_show.FatherId,this.tex_ride_show.ComponentId),
null!=this.m_horse&&(this.m_horse.Info_get().RemoveEventHandler(oe.A.HorseInit,this.CreateDelegate(this.HorseInitHandler)),this.m_horse.Destroy(),this.m_horse=null)}SetData(){
super.SetData(),this.AddLis(),this.UpdateInfo(),this.ShowHorseModel(),this.ui_publicbeta_eff_view.SetData()}AddLis(){
this.myGrid.OnReposition_set(this.CreateDelegate(this.UpdateScrollBar)),this.m_handlerMgr.AddClickEvent(this.itemIcon1,this.CreateDelegate(this.ItemClickHandle)),
ht.B.Inst_get().AddEventHandler(ht.B.PUBLICBETA_INFO,this.CreateDelegate(this.CreateDelegate(this.UpdateInfo))),
ht.B.Inst_get().AddEventHandler(ht.B.PUBLICBETA_CONFIG,this.CreateDelegate(this.CreateDelegate(this.UpdateInfo)))}RemoveLis(){this.myGrid.OnReposition_set(null),
ht.B.Inst_get().RemoveEventHandler(ht.B.PUBLICBETA_INFO,this.CreateDelegate(this.CreateDelegate(this.UpdateInfo))),
ht.B.Inst_get().RemoveEventHandler(ht.B.PUBLICBETA_CONFIG,this.CreateDelegate(this.CreateDelegate(this.UpdateInfo)))}ItemClickHandle(t){
w.J.Inst_get().ShowItemTip(this.showItemData)}UpdateScrollBar(){null!=this.intervalId&&wt.C.Inst_get().ClearLoop(this.intervalId),
this.intervalId=wt.C.Inst_get().SetFrameLoop(this.CreateDelegate(this.SetScrollBarValue),2,1)}UpdateInfo(){this.info=ht.B.Inst_get().GetConfigs(rt.t.PUBLICBETA_CHARGE),
null!=this.info&&(this.show=null,this.UpdateItemLis(),this.UpdateLeftShowItem())}UpdateLeftShowItem(){if(null!=this.show){this.showItemDataLis.Clear()
for(let t=0;t<=this.show.rewards.Count()-1;t++)this.showItemDataLis.Add(Qt.M.wrapReward(this.show.rewards[t]))
this.showItemDataLis.count>0&&null==this.tiemrId&&(this.idx=0,this.tiemrId=wt.C.Inst_get().SetInterval(this.CreateDelegate(this.UpdateLeftShowItemTimer),5e3),
this.UpdateLeftShowItemTimer())}else this.ClearLeftShowItemTimer()}ClearLeftShowItemTimer(){null!=this.tiemrId&&(wt.C.Inst_get().ClearInterval(this.tiemrId),this.tiemrId=null,
this.idx=0)}UpdateLeftShowItemTimer(){this.idx<this.showItemDataLis.count&&(this.idx=0)
const t=this.showItemDataLis[this.idx]
null!=t&&(this.showItemData=t,Kt.g.SetItemIcon(this.itemIcon1.FatherId,this.itemIcon1.ComponentId,t.cfgData_get().icon,zt.b.eItem,!1),this.idx+=1)}SetScrollBarValue(){
this.bar.SetValue(0)}RefreshEndTime(){const t=se.i.ins.huodong_dict.LuaDic_GetItem(rt.t.PUBLICBETA_CHARGE)
let e=0
null!=t&&(e=t.endTime.ToNum()),e>0&&(e=.001*e-Jt.D.serverTime_get()),e>0?this.timetips.textSet(`结束倒计时:[5FB470]${b.l.GetDateFormatBitContainZero(e,4)}[-]`):(this.timetips.textSet("已结束"),
this.ClearEndTimeHandle())}ClearEndTimeHandle(){null!=this.countDownTimer&&(wt.C.Inst_get().ClearInterval(this.countDownTimer),this.countDownTimer=null)}UpdateItemLis(){
if(this.lis=new pt.Z,null!=this.info)for(let t=0;t<=this.info.Count()-1;t++){this.info[t].id
""!=this.info[t].show&&this.info[t].show.rewards.count>0&&(this.show=this.info[t].show)}this.myGrid.data_set(this.info)}Clear(){this.ClearLeftShowItemTimer(),
this.ClearEndTimeHandle(),this.RemoveLis(),this.RemoveHorse(),super.Clear()}Destroy(){super.Destroy(),this.scrollView=null,this.myGrid=null,this.bar=null,this.item1=null,
this.itemIcon1=null,this.timetips=null,this.tex_ride_show=null,this.rotate_obj=null,this.ui_publicbeta_eff_view=null}Test1(){return!0}S_Test(){return!0}}
var ye=i(65530),Te=i(89501),Re=i(27001),ve=i(33996),we=i(8211),De=i(84141),Ee=i(23649),Le=i(86133),Ge=i(79878),Oe=i(83434),be=i(69622)
class Be extends Vt.x{constructor(...t){super(...t),this.text_name=null,this.img_get=null,this.grid_item=null,this.text_progress=null,this.btn_get=null,this.text_get=null,
this.img_bg=null,this.img_btn_get=null,this.btn_go=null,this.right=null,this.huodongQuestVo=null,this.targetVo=null,this.rewardVo=null,this.huodongCfgVo=null,this.flyLinkInfo=null,
this.hasIntegral=null,this.integralItemIndex=null,this.getHandler=null}InitView(){super.InitView(),this.text_name=this.CreateComponent(St.Q,1),
this.img_get=this.CreateComponent(Nt.w,2),this.grid_item=this.CreateComponent(Te.N,3),this.text_progress=this.CreateComponent(St.Q,4),this.btn_get=this.CreateComponent(Et.W,5),
this.text_get=this.CreateComponent(St.Q,6),this.img_bg=this.CreateComponent(Nt.w,7),this.img_btn_get=this.CreateComponent(Nt.w,8),this.btn_go=this.CreateComponent(Et.W,9),
this.right=this.CreateComponent(ct.z,10),this.grid_item.SetInitInfo("ui_baseitem",this.CreateDelegate(this.OnInitItem))}OnInitItem(t){const e=new At.j
return e.setId(t,null,0),e.SetBgSize(66,66),e.SetIconSize(66,66),e}SetData(t){this.huodongQuestVo=t,this.targetVo=this.huodongQuestVo.targetVos[0],
this.rewardVo=this.huodongQuestVo.activityRewardVo,this.huodongCfgVo=be.J.ins.GetQuestVoById(this.huodongQuestVo.taskId),this.UpdateView(),this.AddLis()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.btn_get,this.CreateDelegate(this.OnClickBtnGet)),this.m_handlerMgr.AddClickEvent(this.btn_go,this.CreateDelegate(this.OnClickBtnGo)),
this.m_handlerMgr.AddEventMgr(O.g.HUODONG_GET_REWARD,this.CreateDelegate(this.ShowReward))}ShowReward(t){
t.taskId==this.huodongQuestVo.taskId&&(ht.B.Inst_get().rewards=this.rewardVo.reward.rewards,oi.Inst_get().OpenRewardShowView())}RemoveLis(){}Clear(){super.Clear(),this.RemoveLis(),
null!=this.flyLinkInfo&&(this.flyLinkInfo.Clear(),this.flyLinkInfo=null)}UpdateView(){
this.flyLinkInfo=Oe.f.GetLinkInfo(new pt.Z([this.huodongCfgVo.targetText]),this.huodongCfgVo.TargetDefs_Get(),this.huodongQuestVo.targetVos),
this.text_name.textSet(this.flyLinkInfo.GetTxtLabel()),this.btn_get.node.SetActive(!1),this.btn_go.node.SetActive(!1),this.img_get.node.SetActive(!1),
this.text_progress.node.SetActive(!1),this.rewardVo.isReward?this.img_get.node.SetActive(!0):(this.text_progress.node.SetActive(!0),
this.targetVo.curValue.ToNum()>=this.targetVo.targetValue.ToNum()?this.btn_get.node.SetActive(!0):this.btn_go.node.SetActive(!0)),
this.text_progress.textSet(`目标进度[047104]${I.o.Format((0,
Le.T)("{0}/{1}"),b.l.GetRuleDecimalVal(this.targetVo.curValue.ToNum()),b.l.GetRuleDecimalVal(this.targetVo.targetValue.ToNum()))}[-]`),this.hasIntegral=!1
const t=new pt.Z
for(let e=0;e<=this.rewardVo.reward.rewards.Count()-1;e++){const i=Qt.M.wrapReward(this.rewardVo.reward.rewards[e])
t.Add(i),10211==i.modelId_get()&&(this.integralItemIndex=e,this.hasIntegral=!0)}this.grid_item.data_set(t)}OnClickBtnGet(){
this.rewardVo.isReward||this.targetVo.curValue.ToNum()>=this.targetVo.targetValue.ToNum()&&(null!=this.getHandler&&this.hasIntegral&&this.grid_item.itemList[this.integralItemIndex]&&this.getHandler(this.grid_item.itemList[this.integralItemIndex]),
lt.l.ins.CM_GainActivitytaskReward(this.huodongCfgVo.activityId,this.huodongCfgVo.id))}OnClickBtnGo(){this.rewardVo.isReward||Ge.Y.GotoByLinkStr(this.flyLinkInfo.linkStr)}
Destroy(){this.getHandler=null,super.Destroy(),this.text_name=null,this.img_get=null,this.grid_item=null,this.text_progress=null,this.btn_get=null,this.text_get=null,
this.img_bg=null,this.img_btn_get=null,this.btn_go=null,this.right=null}}class Ne extends _e.${constructor(...t){super(...t),this.left=null,this.grid_quest=null,
this.lastNamelabel=null,this.lastNumlabel=null,this.grid_last=null,this.btn_last=null,this.numlabel=null,this.deslabe=null,this.opemTimelabel=null,this.lastview=null,
this.lastemptyview=null,this.img_bg=null,this.tipbtn=null,this.numeff=null,this.numBtn=null,this.numBtnDesLab=null,this.timeObj=null,this.hourLab=null,this.minLab=null,
this.secLab=null,this.btnEff=null,this.ui_publicbeta_daliy_tip_view=null,this.ui_publicbeta_eff_view=null,this.nowDate=null,this.tiemeArr=null,this.IsLastDay=null,this.fixNum=null,
this.isLotteryEnd=null,this.m_startPosX=null,this.m_startPosY=null,this.m_startPosZ=null,this.curPoint=null,this.TimeId=null,this.effShow=null}InitView(){super.InitView(),
this.left=this.CreateComponent(ct.z,21),this.grid_quest=this.CreateComponent(Ct.A,22),this.lastNamelabel=this.CreateComponent(St.Q,23),
this.lastNumlabel=this.CreateComponent(St.Q,24),this.grid_last=this.CreateComponent(Te.N,25),this.btn_last=this.CreateComponent(Et.W,26),
this.numlabel=this.CreateComponent(St.Q,27),this.deslabe=this.CreateComponent(St.Q,28),this.opemTimelabel=this.CreateComponent(St.Q,29),this.lastview=this.CreateComponent(ct.z,30),
this.lastemptyview=this.CreateComponent(ct.z,31),this.img_bg=this.CreateComponent(Nt.w,32),this.tipbtn=this.CreateComponent(ct.z,33),this.numeff=this.CreateComponent(ct.z,34),
this.numBtn=this.CreateComponent(ct.z,35),this.numBtnDesLab=this.CreateComponent(St.Q,36),this.timeObj=this.CreateComponent(ct.z,37),this.hourLab=this.CreateComponent(St.Q,38),
this.minLab=this.CreateComponent(St.Q,39),this.secLab=this.CreateComponent(St.Q,40),this.btnEff=this.CreateComponent(ct.z,41),
this.ui_publicbeta_daliy_tip_view=this.CreateComponentBinder(Ft,42),this.ui_publicbeta_eff_view=this.CreateComponentBinder(Ce.k,43),
this.grid_quest.SetInitInfo("ui_publicbeta_daliy_Item",null,Be),this.grid_last.SetInitInfo("ui_baseitem",null,At.j),this.nowDate=De.E.New()
const t=ge.D.getInstance().GetStringValue("PUBLICBETA:LUCKYTIME")
this.tiemeArr=I.o.GetIntArr(t,":"),this.IsLastDay=!1,this.ui_publicbeta_daliy_tip_view.node.SetActive(!1)}SetData(){
this.fixNum=ge.D.getInstance().GetIntValue("PUBLICBETA:ACTIVATION"),this.isLotteryEnd=null,this.AddLis(),this.UpdatePanel(),this.UpdateLastView(),this.UpdateReward(),
this.StartTime(),this.ui_publicbeta_eff_view.SetData()}StartCheckLotteryEnd(){this.CheckaLotteryEnd()}ShowCurrencyBar_get(){return qt._.None}AddLis(){
this.m_handlerMgr.AddEventMgr(O.g.HUODONG_TYPE_CHANGE,this.CreateDelegate(this.TypeHandler)),this.m_handlerMgr.AddClickEvent(this.tipbtn,this.CreateDelegate(this.ClickTipHandler)),
this.m_handlerMgr.AddClickEvent(this.btn_last,this.CreateDelegate(this.ClickLastHandler)),
this.m_handlerMgr.AddClickEvent(this.numBtn,this.CreateDelegate(this.ReqCM_GetBetaLotteryNum)),this.m_handlerMgr.AddPressEvent(this.numBtn,this.CreateDelegate(this.OnLongPress)),
this.m_handlerMgr.AddEventMgr(O.g.DAILY_UPDATAVALUE,this.CreateDelegate(this.UpdatePoint)),
this.m_handlerMgr.AddEventMgr(O.g.TabCommonOpenAniEnd,this.CreateDelegate(this.UpdateEffShow)),
we.N.GetInst().AddEventHandler(ve.G.BUY_MALLINFO,this.CreateDelegate(this.UpdatePanel)),
ht.B.Inst_get().AddEventHandler(ht.B.PUBLICBETA_LOTTERY_CONFIG,this.CreateDelegate(this.UpdateReward)),
ht.B.Inst_get().AddEventHandler(ht.B.PUBLICBETA_LOTTERY_INFO,this.CreateDelegate(this.UpdateMyView)),
ht.B.Inst_get().AddEventHandler(ht.B.PUBLICBETA_LOTTERY_RESULT,this.CreateDelegate(this.UpdateLastView))}RemoveLis(){
we.N.GetInst().RemoveEventHandler(ve.G.BUY_MALLINFO,this.CreateDelegate(this.UpdatePanel)),
ht.B.Inst_get().RemoveEventHandler(ht.B.PUBLICBETA_LOTTERY_CONFIG,this.CreateDelegate(this.UpdateReward)),
ht.B.Inst_get().RemoveEventHandler(ht.B.PUBLICBETA_LOTTERY_INFO,this.CreateDelegate(this.UpdateMyView)),
ht.B.Inst_get().RemoveEventHandler(ht.B.PUBLICBETA_LOTTERY_RESULT,this.CreateDelegate(this.UpdateLastView))}OnLongPress(t,e){if(e){if(null==this.m_startPosX){
const t=ye.x.Instance_get().LastEventPosition();[this.m_startPosX,this.m_startPosY,this.m_startPosZ]=[t.x,t.y,t.z]}}else{if(null!=this.m_startPosX){
const t=ye.x.Instance_get().LastEventPosition()
t.x-this.m_startPosX>50&&this.m_startPosY-t.y<30&&this.m_startPosY-t.y>-30&&this.ReqCM_GetBetaLotteryNum()}this.m_startPosX=null}}ReqCM_GetBetaLotteryNum(){
this.isLotteryEnd?Xt.y.inst.ClientSysMessage(11044012):ht.B.Inst_get().honorPoint<this.fixNum?Xt.y.inst.ClientSysStrMsg("活跃值不足"):oi.Inst_get().ReqCM_GetBetaLotteryNum()}
TypeHandler(t){t.Contains(Ee.h.PUBLICBETA_DALIY)&&this.UpdatePanel()}ClickTipHandler(){this.ui_publicbeta_daliy_tip_view.node.SetActive(!0),
this.ui_publicbeta_daliy_tip_view.OnAddToScene()}ClickLastHandler(){
null!=ht.B.Inst_get().firstlotteryData?oi.Inst_get().OpenDaliyLotteryRewardView():Xt.y.inst.ClientSysMessage(11044002)}UpdatePoint(){const t=Re.q.GetInst().GetTotalVitalityNum()
this.curPoint!=t&&(this.curPoint=t,this.CheckLotteryEnd())}UpdatePanel(){const t=se.i.ins.GetQuestListVoByTargetTypeAndGroup(Ee.h.PUBLICBETA_DALIY,rt.t.PUBLICBETA_DAILY)
this.grid_quest.data_set(t)
let e=0
e=ht.B.Inst_get().honorPoint,t.Sort(this.CreateDelegate(this.SortOn)),e>this.fixNum&&(e=this.fixNum),this.curPoint!=e&&(this.curPoint=e,this.CheckLotteryEnd()),this.curPoint=e,
this.UpdateMyView()}SortOn(t,e){return t.activityRewardVo.isReward&&!e.activityRewardVo.isReward?1:!t.activityRewardVo.isReward&&e.activityRewardVo.isReward?-1:t.taskId-e.taskId}
StartTime(){null==this.TimeId&&(this.TimeId=wt.C.Inst_get().SetInterval(this.CreateDelegate(this.UpdateTime),1e3),this.UpdateTime())}ClearTime(){
null!=this.TimeId&&(wt.C.Inst_get().ClearInterval(this.TimeId),this.TimeId=null)}UpdateTime(){const t=se.i.ins.GetLastEndMS(y.S.PUBLICBETA_DAILY)
this.IsLastDay=!1
const e=ht.B.Inst_get().GetLeftTime(ht.B.Inst_get().tiemeLotterEndArr)
if(t>0&&t>e)if(e>0){this.timeObj.SetActive(!0),this.opemTimelabel.SetActive(!1)
const[t,i,s]=b.l.GetHMS(e/1e3)
this.hourLab.textSet(t),this.minLab.textSet(i),this.secLab.textSet(s),this.IsLastDay=!0}else t<864e5?(this.opemTimelabel.SetActive(!0),this.timeObj.SetActive(!1),
this.opemTimelabel.textSet("活动结束"),this.IsLastDay=!0):(this.timeObj.SetActive(!1),this.opemTimelabel.SetActive(!0),this.opemTimelabel.textSet("已开奖，等待下一轮抽奖"))
else this.opemTimelabel.SetActive(!0),this.timeObj.SetActive(!1),this.opemTimelabel.textSet("活动结束")
this.CheckLotteryEnd()}CheckLotteryEnd(){const t=ht.B.Inst_get().GetLeftTime(ht.B.Inst_get().daliyDataFreshArr),e=ht.B.Inst_get().IsLotteryEnd()
null!=this.isLotteryEnd&&e==this.isLotteryEnd||(this.isLotteryEnd=e,this.UpdateMyView(t<0))}UpdateEffShow(){
null==this.effShow?this.numeff.SetActive(!1):this.numeff.SetActive(this.effShow&&ht.B.Inst_get().isTweenEnd)}UpdateMyView(t){const e=ht.B.Inst_get().betaLotteryNum
this.curPoint=ht.B.Inst_get().honorPoint,this.numlabel.node.SetActive(!1),this.numBtn.SetActive(!0),this.effShow=!1,
null==e||0==e?this.isLotteryEnd?this.UpdateEffShow():this.curPoint>=this.fixNum?(this.effShow=!0,this.UpdateEffShow()):this.UpdateEffShow():(this.UpdateEffShow(),
this.numlabel.textSet(e),this.numBtn.SetActive(!1),this.numlabel.node.SetActive(!0)),
this.isLotteryEnd?this.deslabe.textSet(ft.x.Inst().getItemStrById(11044012)):this.fixNum-this.curPoint<=0?this.deslabe.textSet(ft.x.Inst().getItemStrById(11044016)):this.deslabe.textSet(mt.V.Inst().replaceLangParamOne(ft.x.Inst().getItemStrById(11044003),this.fixNum-this.curPoint)),
this.btnEff.SetActive(ht.B.Inst_get().canGained)}UpdateLastView(){const t=ht.B.Inst_get().firstlotteryData
null==t?(this.lastemptyview.SetActive(!0),this.lastview.SetActive(!1)):(this.lastemptyview.SetActive(!1),this.lastview.SetActive(!0),this.lastNumlabel.textSet(t.lotteryNum),
this.lastNamelabel.textSet(t.playerName),this.img_bg.spriteNameSet(Pt.Z.GetJobIcon(t.job,t.sex,!1)))}UpdateReward(){const t=ht.B.Inst_get().GetLotteryConfig(1)
null!=t&&this.grid_last.data_set(t.rewards)}Clear(){this.RemoveLis(),this.ClearTime(),super.Clear()}Destroy(){super.Destroy(),this.left=null,this.grid_quest=null,
this.lastNamelabel=null,this.lastNumlabel=null,this.grid_last=null,this.btn_last=null,this.numlabel=null,this.deslabe=null,this.opemTimelabel=null,this.lastview=null,
this.lastemptyview=null,this.img_bg=null,this.tipbtn=null,this.numeff=null,this.numBtn=null,this.numBtnDesLab=null,this.timeObj=null,this.hourLab=null,this.minLab=null,
this.secLab=null,this.btnEff=null,this.ui_publicbeta_daliy_tip_view=null,this.ui_publicbeta_eff_view=null}Test1(){return!0}S_Test(){return!0}}
var Pe=i(25035),Me=i(70123),Ve=i(46899),ke=i(62734),xe=i(30890),He=i(3522)
class Ue extends Vt.x{constructor(...t){super(...t),this.Config=null,this.RedpointId=null,this.IsLight=null,this.IsPlayingAnim=!1,this.icon=null,this.canLight=null,
this.iconObj=null,this.widget=null,this.gray=null,this.ani=null}InitView(){super.InitView(),this.icon=this.CreateComponent(Nt.w,1),this.canLight=this.CreateComponent(ct.z,2),
this.iconObj=this.CreateComponent(ct.z,3),this.widget=this.CreateComponent(_t.T,4),this.gray=this.CreateComponent(Nt.w,5),this.ani=this.CreateComponent(He.k,6)}SetData(t){
this.Config=t,t.chapter<3?(this.icon.SetItemIconByAtlas(this.Config.icon,"pre_rygckh",!0),
this.gray.SetItemIconByAtlas(this.Config.iconGray,"pre_rygckh",!0)):(this.icon.SetItemIconByAtlas(this.Config.icon,"pre_rygckh1",!0),
this.gray.SetItemIconByAtlas(this.Config.iconGray,"pre_rygckh1",!0)),
3==this.Config.puzzleId||4==this.Config.puzzleId?this.iconObj.SetLocalPositionXYZ(23,0,0):this.iconObj.SetLocalPositionXYZ(0,0,0),
this.IsLight=ht.B.Inst_get().IsJigsawChipLighted(t.id),this.IsLight?(this.icon.SetActive(!0),this.gray.SetActive(!1)):(this.icon.SetActive(!1),this.gray.SetActive(!0))
const e=bt.F.Inst_get().GetJigsawChipList(this.Config.chapter)
4==e.Count()?this.widget.heightSet(200):6==e.Count()&&this.widget.heightSet(128),this.RedpointId=ht.B.Inst_get().GetJigsawRedpointId(this.Config.id),
this.m_handlerMgr.AddClickEvent(this.widget,this.CreateDelegate(this.ClickItem)),this.ani.AddEventHandler(this.CreateDelegate(this.OnAniPlayEnd)),this.IsPlayingAnim=!1,
ke.f.Inst.AddCallback(this.RedpointId,this.CreateDelegate(this.RedpointUpdate)),this.RedpointUpdate()}OnAniPlayEnd(){this.IsPlayingAnim=!1,this.RedpointUpdate()}Refresh(){
const t=this.IsLight
this.IsLight=ht.B.Inst_get().IsJigsawChipLighted(this.Config.id),this.IsLight&&0==t&&(this.ani.Sample(1),this.ani.Play(!1,!1),this.IsPlayingAnim=!0,this.canLight.SetActive(!1)),
this.IsLight||1!=t||(this.ani.Sample(0),this.ani.Play(!0,!1),this.IsPlayingAnim=!0,this.canLight.SetActive(!1)),this.RedpointUpdate()}RedpointUpdate(){
if(m.N.inst.GetViewById(C.I.RyPublicBetaJigsawLightChipView))return
const t=ke.f.Inst.GetData(this.RedpointId).show
this.IsPlayingAnim||this.canLight.SetActive(t)}ClickItem(){ht.B.Inst_get().clickJigsawChipId=this.Config.id,oi.Inst_get().OpenJigsawLightChipPanel()}Clear(){super.Clear(),
this.IsLight=null,ke.f.Inst.RemoveCallback(this.RedpointId,this.CreateDelegate(this.RedpointUpdate)),this.ani.RemoveEventHandler(this.CreateDelegate(this.OnAniPlayEnd))}Destroy(){
super.Destroy()}Test1(){return!0}S_Test(){return!0}}class Fe extends _e.${constructor(...t){super(...t),this.jigsawList=null,this.content=null,this.chipList=null,
this.rewardScrollView=null,this.rewardGrid=null,this.getRewardLeftCount=null,this.getRewardBtn=null,this.getRewardLbl=null,this.getRewardTip=null,this.getItemBtn=null,
this.resetEff=null,this.ui_publicbeta_eff_view=null,this.SelectChapterIndex=null,this.SelectChapter=null,this.model=null,this.delayReqRewardTimer=null}InitView(){super.InitView(),
this.jigsawList=this.CreateComponent(Ct.A,1),this.content=this.CreateComponent(ct.z,2),this.chipList=this.CreateComponent(Ct.A,3),
this.rewardScrollView=this.CreateComponent(Gt.h,4),this.rewardGrid=this.CreateComponent(Ct.A,5),this.getRewardLeftCount=this.CreateComponent(St.Q,6),
this.getRewardBtn=this.CreateComponent(ct.z,7),this.getRewardLbl=this.CreateComponent(St.Q,8),this.getRewardTip=this.CreateComponent(ct.z,9),
this.getItemBtn=this.CreateComponent(ct.z,10),this.resetEff=this.CreateComponent(ct.z,11),this.ui_publicbeta_eff_view=this.CreateComponentBinder(Ce.k,12),
this.model=ht.B.Inst_get(),this.jigsawList.SetInitInfo("ui_publicbeta_jigsaw_tab",null,xe.y,this.CreateDelegate(this.OnClickJigsawTab)),
this.jigsawList.OnReposition_set(this.CreateDelegate(this.RepositionChapterList)),this.rewardGrid.SetInitInfo("ui_baseitem",this.CreateDelegate(this.OnInitItem)),
this.rewardGrid.OnReposition_set(this.CreateDelegate(this.RepositionRewardList)),this.chipList.SetInitInfo("ui_publicbeta_jigsaw_chip",null,Ue),
this.chipList.OnReposition_set(this.CreateDelegate(this.RepositionChipList)),this.getRewardLbl.textSet("领取奖励")}OnInitItem(t){const e=new At.j
return e.setId(t,null,0),e.SetBgSize(66,66),e.SetIconSize(66,66),e}SetData(){this.m_handlerMgr.AddClickEvent(this.getItemBtn,this.CreateDelegate(this.ClickGetItem)),
this.m_handlerMgr.AddClickEvent(this.getRewardBtn,this.CreateDelegate(this.ClickGetAward)),
this.model.AddEventHandler(ht.B.PUBLICBETA_JIGSAW_INFO,this.CreateDelegate(this.RefreshChapItemList))
const t=bt.F.Inst_get().GetJigsawChapterList(),e=new pt.Z
for(const[i,s]of(0,Yt.V5)(t)){const t=bt.F.Inst_get().GetJigsawChipList(s)[0],i=this.model.GetJigsawChapterRedpointId(s),n=Pe.k.New(t.chapterNanme,i,null,0)
e.Add(n)}this.jigsawList.data_set(e),this.SelectChapterIndex=0,this.SelectChapter=this.SelectChapterIndex+1,this.resetEff.SetActive(!1),this.RefreshChapterContent(),
this.ui_publicbeta_eff_view.SetData()}ShowCurrencyBar_get(){return qt._.None}RefreshChapItemList(){if(!m.N.inst.GetViewById(C.I.RyPublicBetaJigsawLightChipView)){
for(const[t,e]of(0,Yt.V5)(this.chipList.itemList))e.Refresh()
this.OnInfoUpdate()}}ResetAllChip(){this.resetEff.SetActive(!1),this.resetEff.SetActive(!0)}OnCreateTabItem(){}ClickGetItem(){
const t=bt.F.Inst_get().GetJigsawAccess(this.SelectChapter),e=Ve.m.FillDataList(new pt.Z(t)),i=(0,Le.T)("可通过以下获取途径获取藏宝图，挖掘拼图碎片："),s=(0,Le.T)("点亮碎片")
Me.W.ins.OpenAccessListCommonPanel(e,i,s)}ClickGetAward(){
this.model.IsJigsawRewardAllGet(this.SelectChapter)?Xt.y.inst.ClientSysStrMsg("已领取完该拼图所有轮次奖励"):this.model.IsJigsawCanGetAward(this.SelectChapter)?(this.ResetAllChip(),
this.delayReqRewardTimer=wt.C.Inst_get().ClearInterval(this.delayReqRewardTimer),
this.delayReqRewardTimer=wt.C.Inst_get().SetInterval(this.CreateDelegate(this.DelayReqReward),1e3,1)):Xt.y.inst.ClientSysStrMsg("需要点亮所有碎片才能领取奖励")}DelayReqReward(){
oi.Inst_get().ReqCM_JigsawReward(this.SelectChapter)}OnClickJigsawTab(t,e,i){const s=this.jigsawList.itemList.IndexOf(t)
this.SelectChapterIndex=s,this.SelectChapter=this.SelectChapterIndex+1,this.RefreshChapterContent(),this.UpdateChapterListState()}UpdateChapterListState(){
const t=this.jigsawList.itemList,e=t.Count()
for(let i=0;i<=e-1;i++){t[i].SetSelect(this.SelectChapterIndex==i)}}RefreshChapterContent(){const t=bt.F.Inst_get().GetJigsawChipList(this.SelectChapter)
this.chipList.data_set(t),4==t.Count()?(this.chipList.cellHeightSet(190),this.chipList.SetLocalPositionXYZ(-86,20,0)):6==t.Count()&&(this.chipList.cellHeightSet(140),
this.chipList.SetLocalPositionXYZ(-86,9,0)),this.OnInfoUpdate()}OnInfoUpdate(){
const t=this.model.JigsawConfig_get(),e=this.model.JigsawInfo_get(),i=t.rewardResourceVoMap[this.SelectChapter],s=e.puzzleInfoVoMap[this.SelectChapter]
let n=s&&s.round||1
const a=i.rewardNum,o=new pt.Z,l=i.rewardId
for(const[t,e]of(0,Yt.V5)(l.rewards)){const t=Qt.M.wrapReward(e)
o.Add(t)}s&&s.isEnd&&(n=a+1),this.rewardGrid.data_set(o),a>0?(this.getRewardLeftCount.textSet(`还可领取${a-n+1}次`),
this.getRewardBtn.SetLocalPositionXYZ(0,0,0)):(this.getRewardLeftCount.textSet(""),this.getRewardBtn.SetLocalPositionXYZ(0,-12,0))
const r=ht.B.Inst_get().GetJigsawRewardRedpointId(this.SelectChapter),h=ke.f.Inst.GetData(r)
this.getRewardTip.SetActive(h.show)}RepositionChipList(){}RepositionRewardList(){this.rewardScrollView.ResetPosition()}RepositionChapterList(){
const t=this.jigsawList.itemList.Count()
for(let e=0;e<=t-1;e++){const i=this.jigsawList.itemList[e]
let s,n;[s,n]=0==e?["rycommon_bt_0043","rycommon_bt_0044"]:e==t-1?["rycommon_bt_0047","rycommon_bt_0048"]:["rycommon_bt_0045","rycommon_bt_0046"],i.SetBgSpriteIcon(s,n)}
this.UpdateChapterListState()}Clear(){super.Clear(),null!=this.model&&this.model.RemoveEventHandler(ht.B.PUBLICBETA_JIGSAW_INFO,this.CreateDelegate(this.RefreshChapItemList))}
Destroy(){super.Destroy(),this.jigsawList=null,this.content=null,this.chipList=null,this.rewardScrollView=null,this.rewardGrid=null,this.getRewardLeftCount=null,
this.getRewardBtn=null,this.getRewardLbl=null,this.getRewardTip=null,this.getItemBtn=null,this.resetEff=null,this.ui_publicbeta_eff_view=null}Test1(){return!0}S_Test(){return!0}}
var Ye=i(79534),Ke=i(43308)
class ze extends Vt.x{constructor(...t){super(...t),this.bg=null,this.titleSpr=null,this.bg2=null,this.grid=null,this.goBtn=null,this.widget=null,this.data=null,this.consumes=null}
InitView(){super.InitView(),this.bg=this.CreateComponent(Nt.w,1),this.titleSpr=this.CreateComponent(Nt.w,2),this.bg2=this.CreateComponent(Nt.w,3),
this.grid=this.CreateComponent(Ct.A,4),this.goBtn=this.CreateComponent(Et.W,5),this.widget=this.CreateComponent(ct.z,6),
this.grid.SetInitInfo("ui_baseitem",this.CreateDelegate(this.OnInitItem))}OnInitItem(t){const e=new At.j
return e.setId(t,null,0),e.SetBgSize(52,52),e.SetIconSize(52,52),e}SetData(t){this.data=t,this.AddLis()
let e="",i="",s=""
this.data.funcId==te.x.PUBLICBETA_DALIY?(e="PUBLICBETA:REWARDSHOW01",i="rygclc_sp_0015",s="rygclc_sp_0018"):this.data.funcId==te.x.PUBLICBETA_JIGSAW?(e="PUBLICBETA:REWARDSHOW02",
i="rygclc_sp_0016",s="rygclc_sp_0019"):null!=this.data.itemId&&(e="PUBLICBETA:REWARDSHOW03",i="rygclc_sp_0017",s="rygclc_sp_0020")
const n=ge.D.getInstance().GetStringValue(e)
if(""!=n){let t=new pt.Z
const e=yt.A.GetReward(n)
null!=e&&(t=e.GetAllRewardList()),this.grid.data_set(t)}this.bg.spriteNameSet(i),this.bg2.spriteNameSet(s)}AddLis(){
this.m_handlerMgr.AddClickEvent(this.goBtn,this.CreateDelegate(this.OnGoBtnHandle))}OnGoBtnHandle(){let t=0
if(this.data.funcId==te.x.PUBLICBETA_DALIY)t=ht.B.DAILY
else if(this.data.funcId==te.x.PUBLICBETA_JIGSAW)t=ht.B.JIGSAW
else if(null!=this.data.itemId)return void Ke._.Inst_get().OpenByItem(this.data.itemId,Ye.P.zero_get(),null,!0)
oi.Inst_get().OpenPublicBetaView(t)}Clear(){this.consumes=null,super.Clear()}Destroy(){super.Destroy(),this.bg=null,this.titleSpr=null,this.bg2=null,this.grid=null,this.goBtn=null,
this.widget=null}Test1(){return!0}S_Test(){return!0}}class Qe extends _e.${constructor(...t){super(...t),this.grid=null,this.bg3=null,this.ui_publicbeta_eff_view=null}InitView(){
super.InitView(),this.grid=this.CreateComponent(Ct.A,1),this.bg3=this.CreateComponent(Nt.w,2),this.ui_publicbeta_eff_view=this.CreateComponentBinder(Ce.k,3),
this.grid.SetInitInfo("ui_publicbeta_review_item",null,ze)}SetData(){this.UpdateView(),this.m_handlerMgr.AddEventMgr(O.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors)),
this.UpdateAnchors(),this.ui_publicbeta_eff_view.SetData()}UpdateView(){const t=new pt.Z([{funcId:te.x.PUBLICBETA_DALIY},{funcId:te.x.PUBLICBETA_JIGSAW},{itemId:800}])
this.grid.data_set(t)}ShowCurrencyBar_get(){return qt._.None}Clear(){this.grid.Clear(),super.Clear()}UpdateAnchors(){const t=It.O.GetUIWidth()
null!=this.bg3&&this.bg3.widthSet(t-129)}Destroy(){this.grid.Destroy(),super.Destroy(),this.grid=null,this.bg3=null,this.ui_publicbeta_eff_view=null}}
var Ze=i(60567),Xe=i(30267),je=i(86209),Je=i(85605),We=i(75582),$e=i(7601),qe=i(52513),ti=i(31896),ei=i(19519)
class ii extends Vt.x{constructor(...t){super(...t),this.itemIcon=null,this.vipLabel=null,this.buyBtn=null,this.costLabel=null,this.nameLabel=null,this.orPriceLabel=null,
this.goodGrid=null,this.buyOverContainer=null,this.costIcon=null,this.costContainer=null,this.zhekouObj=null,this.zhekouLab=null,this.bg=null,this.zhekouSp=null,
this.limitLabel=null,this.redPointObj=null,this.huodongMallVo=null,this.huodongMallCfgVo=null,this.consumes=null}InitView(){super.InitView(),
this.itemIcon=this.CreateComponentBinder(At.j,1),this.vipLabel=this.CreateComponent(St.Q,2),this.buyBtn=this.CreateComponent(ct.z,3),this.costLabel=this.CreateComponent(St.Q,4),
this.nameLabel=this.CreateComponent(St.Q,5),this.orPriceLabel=this.CreateComponent(St.Q,6),this.goodGrid=this.CreateComponent(Ct.A,7),
this.buyOverContainer=this.CreateComponent(ct.z,8),this.costIcon=this.CreateComponent(Nt.w,9),this.costContainer=this.CreateComponent(Xe.V,10),
this.zhekouObj=this.CreateComponent(ct.z,11),this.zhekouLab=this.CreateComponent(St.Q,12),this.bg=this.CreateComponent(Nt.w,13),this.zhekouSp=this.CreateComponent(Nt.w,14),
this.limitLabel=this.CreateComponent(St.Q,15),this.redPointObj=this.CreateComponent(ct.z,16),this.goodGrid.SetInitInfo("ui_baseitem",this.CreateDelegate(this.OnInitItem))}
OnInitItem(t){const e=new At.j
return e.setId(t,null,0),e.SetBgSize(60,60),e.SetIconSize(60,60),e}SetData(t){super.SetData(t),this.huodongMallVo=t,
this.huodongMallCfgVo=We.Z.ins.GetVoByMallId(this.huodongMallVo.mallId),this.AddLis(),this.UpdateView()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.buyBtn,this.CreateDelegate(this.OnClickBtnBuy)),
this.m_handlerMgr.AddEventMgr(O.g.HUODONG_MALL_BUY_CNT_CHANGE,this.CreateDelegate(this.OnBuyCntChange)),
this.m_handlerMgr.AddEventMgr(O.g.COMMON_REMIND_DATA_RESET,this.CreateDelegate(this.UpdateRed)),this.m_handlerMgr.AddEventMgr(O.g.VIP_UPDATE,this.CreateDelegate(this.UpdateRed))}
OnClickBtnBuy(){
-1!=this.huodongMallVo.limit&&Ze.P.ins.GetBuyTimesByMallId(this.huodongMallVo.mallId)>=this.huodongMallVo.limit||(se.i.ins.GetState(rt.t.PUBLICBETA_SHOP)==ie.V.OPEN?(0!=this.huodongMallVo.rechargeId?ti.t.inst.Buy(qe.O.Inst().getConfig(this.huodongMallVo.rechargeId)):Je.$.ins.CheckConsumeEnough(this.huodongMallVo.Consume_Get())&&Je.$.ins.CM_ActivityMallBuy(this.huodongMallVo.mallId),
ht.B.Inst_get().AddShopNotices(this.huodongMallVo.mallId)):Xt.y.inst.ClientSysStrMsg("活动已结束"))}ShowDiscount(){1==this.huodongMallCfgVo.label?(this.zhekouLab.node.SetActive(!1),
this.zhekouSp.spriteNameSet("ryjbsd_sp_0012")):2==this.huodongMallCfgVo.label?(this.zhekouLab.node.SetActive(!0),this.zhekouSp.spriteNameSet("ryjbsd_sp_0027"),
this.zhekouLab.textSet(`${this.huodongMallCfgVo.discount}%`)):3==this.huodongMallCfgVo.label?(this.zhekouLab.node.SetActive(!1),
this.zhekouSp.spriteNameSet("ryjbsd_sp_0011")):this.zhekouObj.SetActive(!1),this.zhekouSp.MakePixelPerfect(),
1==this.huodongMallCfgVo.productQuality?this.bg.spriteNameSet("rygclc_sp_0010"):2==this.huodongMallCfgVo.productQuality&&this.bg.spriteNameSet("rygclc_sp_0009")}OnBuyCntChange(t){
t==this.huodongMallVo.mallId&&this.UpdateView()}UpdateRed(){ht.B.Inst_get().IsShowShopRedPoint(this.huodongMallVo)?this.redPointObj.SetActive(!0):this.redPointObj.SetActive(!1)}
UpdateView(){this.nameLabel.textSet(this.huodongMallCfgVo.name)
const t=this.huodongMallVo.GetVipLimit()
t>0?(this.vipLabel.node.SetActive(!0),this.vipLabel.textSet(`V${t}可购`)):this.vipLabel.node.SetActive(!1)
const e=this.huodongMallVo.reward.rewards
if(-1!=this.huodongMallVo.limit){const t=this.huodongMallVo.limit-Ze.P.ins.GetBuyTimesByMallId(this.huodongMallVo.mallId)
this.buyOverContainer.SetActive(t<=0),this.limitLabel.textSet(mt.V.Inst().replaceLangParamOne("限购{0}次",t))}else this.buyOverContainer.SetActive(!1),this.limitLabel.textSet("")
const i=Qt.M.wrapReward(e[0])
this.itemIcon.SetData(i)
const s=new pt.Z
for(let t=1;t<=e.Count()-1;t++)s.Add(Qt.M.wrapReward(e[t]))
this.goodGrid.data_set(s),f.M.IsNullOrEmpty(this.Or_Consume_Get())?this.orPriceLabel.node.SetActive(!1):(this.orPriceLabel.node.SetActive(!0),
this.orPriceLabel.textSet(this.Or_Consume_Get())),this.UpdateConsume(),this.ShowDiscount(),this.UpdateRed()}UpdateConsume(){if(this.costLabel.SetActive(!0),
this.costIcon.SetActive(!0),0!=this.huodongMallVo.rechargeId){const t=qe.O.Inst().getConfig(this.huodongMallVo.rechargeId),e=$e.W.Inst.GetCurSystem(),i=t.platformCurrency[e]
this.costLabel.textSet(`${i}元`),this.costIcon.SetActive(!1)}else{const t=this.huodongMallVo.Consume_Get().GetItemDataByType()
this.costLabel.textSet(je.w.Instance.ConvertNumToString(t.count)),null!=t.virtualItemData_get()?this.costIcon.spriteNameSet(ei.J.GetCurrencyIconUrl(t.virtualItemData_get().virtualTypeStr)):this.costIcon.spriteNameSet("")
}this.costContainer.CallReposition()}Or_Consume_Get(){return this.huodongMallCfgVo.originConsumeDef}Clear(){this.consumes=null,super.Clear()}Destroy(){super.Destroy(),
this.itemIcon=null,this.vipLabel=null,this.buyBtn=null,this.costLabel=null,this.nameLabel=null,this.orPriceLabel=null,this.goodGrid=null,this.buyOverContainer=null,
this.costIcon=null,this.costContainer=null,this.zhekouObj=null,this.zhekouLab=null,this.bg=null,this.zhekouSp=null,this.limitLabel=null,this.redPointObj=null}Test1(){return!0}
S_Test(){return!0}}class si extends _e.${constructor(...t){super(...t),this.scrollView=null,this.myGrid=null,this.offset=null,this.bg1=null,this.bg2=null,this.bg3=null,
this.panel=null,this.ui_publicbeta_eff_view=null,this.filterList=null,this.sortList=null}InitView(){super.InitView(),this.scrollView=this.CreateComponent(Gt.h,1),
this.myGrid=this.CreateComponent(Ct.A,2),this.offset=this.CreateComponent(_t.T,3),this.bg1=this.CreateComponent(Nt.w,4),this.bg2=this.CreateComponent(Nt.w,5),
this.bg3=this.CreateComponent(Nt.w,6),this.panel=this.CreateComponent(Ot.$,7),this.ui_publicbeta_eff_view=this.CreateComponentBinder(Ce.k,8),
this.myGrid.SetInitInfo("ui_publicbeta_shop_item_ry",null,ii)}SetData(){ht.B.Inst_get().InitShopNoticeData(),
this.m_handlerMgr.AddEventMgr(O.g.HUODONG_MALL_CHANGE,this.CreateDelegate(this.UpdateView)),this.UpdateView(),
this.m_handlerMgr.AddEventMgr(O.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors)),this.ui_publicbeta_eff_view.SetData(),this.UpdateAnchors()}ShowCurrencyBar_get(){
return qt._.ShowDia}UpdateAnchors(){const t=It.O.GetUIWidth()
let e=t-129-20-30
null!=this.bg1&&(this.bg1.widthSet(t-129-20),this.bg2.widthSet(e),this.bg3.widthSet(e)),e-=20,this.panel.baseClipRegionSetXYZW(0,-192,e,382),this.panel.clipOffsetSetXY(0,0),
this.panel.node.transform.SetLocalPositionXYZ(-65,84,0),this.myGrid.node.transform.SetLocalPositionXYZ(-e/2,-46,0),
this.filterList.count<5&&e/this.filterList.count>250?this.myGrid.cellWidthSet(e/this.filterList.count):this.myGrid.cellWidthSet(250),this.myGrid.Reposition()}UpdateView(){
const[t,e]=Ze.P.ins.GetMallListByHuoDongIdSort2(rt.t.PUBLICBETA_SHOP,this.sortList)
this.sortList=e
const i=new pt.Z
for(let e=0;e<=t.Count()-1;e++){const s=t[e]
s.CheckView()&&i.Add(s)}this.filterList=i,this.myGrid.data_set(i)}Clear(){ht.B.Inst_get().SaveShopRedPoint(),this.sortList=null,super.Clear()}Destroy(){super.Destroy(),
this.scrollView=null,this.myGrid=null,this.offset=null,this.bg1=null,this.bg2=null,this.bg3=null,this.panel=null,this.ui_publicbeta_eff_view=null}}class ni extends $t.I{
constructor(){super(),this.RIGHT_NAMES=null,this.RIGHT_REDIDS=null,this.TAB_FUNC_TYPES=null,this.HUODONG_IDS=null,this.timetips=null,this.bg3=null,this.countDownTimer=null,
this.RIGHT_NAMES=new pt.Z(["狂欢一览","每日活跃","荣耀拼图","公测累充","特惠商店"]),
this.RIGHT_REDIDS=new pt.Z([ee.t.ERROR,ee.t.PUBLICBETA_DAILY,ee.t.PUBLICBETA_JIGSAW,ee.t.PUBLICBETA_RECHARGE,ee.t.PUBLICBETA_SHOP]),
this.TAB_FUNC_TYPES=new pt.Z([te.x.PUBLICBETA_REVIEW,te.x.PUBLICBETA_DALIY,te.x.PUBLICBETA_JIGSAW,te.x.PUBLICBETA_RECHARGE,te.x.PUBLICBETA_SHOP]),
this.HUODONG_IDS=new pt.Z([0,rt.t.PUBLICBETA_DAILY,rt.t.PUBLICBETA_JIGSAW,rt.t.PUBLICBETA_CHARGE,rt.t.PUBLICBETA_SHOP])}InitView(){super.InitView(),
this.timetips=this.CreateComponent(St.Q,60),this.bg3=this.CreateComponent(Nt.w,61),this._subPanelDatas.Add(Wt.b.New(new pt.Z(["ui_publicbeta_review_view"]),this,Qe)),
this._subPanelDatas.Add(Wt.b.New(new pt.Z(["ui_publicbeta_daliy_view"]),this,Ne)),this._subPanelDatas.Add(Wt.b.New(new pt.Z(["ui_publicbeta_jigsaw_view"]),this,Fe)),
this._subPanelDatas.Add(Wt.b.New(new pt.Z(["ui_publicbeta_totalrecharge_view_ry"]),this,fe)),this._subPanelDatas.Add(Wt.b.New(new pt.Z(["ui_publicbeta_shop_view"]),this,si)),
this.rightTabGrid.SetInitInfo("ui_sevenday_right_tab",this.CreateDelegate(this.CreateSevenDayBottomItem),null,this.CreateDelegate(this._OnClickRightItem)),
this.rightTabGrid.OnReposition_set(this.CreateDelegate(this.OnRepositionRight))}_OnClickRightItem(t,e,i){
t&&t.img_lock.activeSelf()?Xt.y.inst.ClientSysStrMsg("不在活动时间内"):super._OnClickRightItem(t,e,i)}CreateSevenDayBottomItem(t){const e=new ne.q
return e.setId(t,null,0),e.SetBgWidth(129),e}OnAniPlayEnd(){ht.B.Inst_get().isTweenEnd=!0,super.OnAniPlayEnd()}IsLock(t){const e=t&&this.HUODONG_IDS[t]||null
return!(!e||0==e||se.i.ins.GetState(e)!=ie.V.NONE)}SetViewConfig(){this._SetTabData0(!1),this.titleLabel.textSet("公测狂欢"),
this._SetTabData1(!0,this.RIGHT_NAMES,this.RIGHT_REDIDS,this.TAB_FUNC_TYPES,null,null,this.HUODONG_IDS),this.rightBg3.SetActive(!1),this.rightBg2.SetActive(!1),
ht.B.Inst_get().defaul_tab_idx&&ht.B.Inst_get().defaul_tab_idx>=0&&this.IsLock(ht.B.Inst_get().defaul_tab_idx)&&(ht.B.Inst_get().defaul_tab_idx=null),
null==ht.B.Inst_get().defaul_tab_idx&&(ht.B.Inst_get().defaul_tab_idx=0),this.SelectTab1(ht.B.Inst_get().defaul_tab_idx),null==this.countDownTimer&&(this.RefreshEndTime(),
this.countDownTimer=wt.C.Inst_get().SetInterval(this.CreateDelegate(this.RefreshEndTime),500))}UpdateAnchors(){const t=It.O.GetUIWidth()
null!=this.bg3&&this.bg3.widthSet(t-129),super.UpdateAnchors()}_OnSelectTab1BeforeUpdate(t){this.ShowSubView(this.selectTabIdx1),this.RefreshEndTime()}RefreshEndTime(){let t=0
if(this.selectTabIdx1==ht.B.DAILY?t=y.S.PUBLICBETA_DAILY:this.selectTabIdx1==ht.B.JIGSAW?t=rt.t.PUBLICBETA_JIGSAW:this.selectTabIdx1==ht.B.RECHARGE?t=rt.t.PUBLICBETA_CHARGE:this.selectTabIdx1==ht.B.SHOP?t=rt.t.PUBLICBETA_SHOP:this.selectTabIdx1==ht.B.REVIEW&&(t=y.S.PUBLICBETA_REVIEW),
t>0){const e=se.i.ins.huodong_dict.LuaDic_GetItem(t)
let i=0
null!=e&&(i=e.endTime.ToNum()),i>0&&(i=.001*i-Jt.D.serverTime_get()),i>0?this.timetips.textSet(`结束倒计时:[5FB470]${b.l.GetDateFormatBitContainZero(i,4)}[-]`):this.timetips.textSet("已结束")
}else this.timetips.textSet("")}ShowCurrencyBar_get(){return qt._.Hide}ClearEndTimeHandle(){null!=this.countDownTimer&&(wt.C.Inst_get().ClearInterval(this.countDownTimer),
this.countDownTimer=null)}OnCloseClick(){oi.Inst_get().ClosePublicBetaView()}Clear(){this.ClearEndTimeHandle(),super.Clear(),ht.B.Inst_get().defaul_tab_idx=null}Destroy(){
ht.B.Inst_get().isTweenEnd=!1,super.Destroy()}Test1(){return!0}S_Test(){return!0}}class ai extends dt.f{constructor(...t){super(...t),this.grid=null,this.deslab=null,
this.timerlab=null,this.closebtn=null,this.time=null,this.TimerId=null}InitView(){super.InitView(),this.grid=this.CreateComponent(Ct.A,1),this.deslab=this.CreateComponent(St.Q,2),
this.timerlab=this.CreateComponent(St.Q,3),this.closebtn=this.CreateComponent(Et.W,4),this.grid.SetInitInfo("ui_baseitem",null,At.j)}OnAddToScene(){super.OnAddToScene(),
this.m_handlerMgr.AddClickEvent(this.closebtn,this.CreateDelegate(this.CloseHandler))
const t=ht.B.Inst_get().rewards,e=new pt.Z
for(let i=0;i<=t.count-1;i++){const s=Qt.M.wrapReward(t[i])
e.Add(s)}this.grid.data_set(e),this.time=6,this.DowerTimer(),this.deslab.textSet("恭喜获得以下奖励"),this.ClearTimer(),
this.TimerId=wt.C.Inst_get().SetInterval(this.CreateDelegate(this.DowerTimer),1e3)}CloseHandler(){this.ClearTimer(),oi.Inst_get().ClosePublicBetaReward()}DowerTimer(){this.time-=1,
0!=this.time?this.timerlab.textSet(`确定(${this.time}s)`):this.CloseHandler()}ClearTimer(){null!=this.TimerId&&wt.C.Inst_get().ClearInterval(this.TimerId)}Clear(){this.ClearTimer(),
super.Clear()}Destroy(){super.Destroy(),this.grid=null,this.deslab=null,this.timerlab=null,this.closebtn=null}}class oi{constructor(){this.CurrentUseJigsawChipId=null}RegMsg(){
c.j.Inst.F_Register(-12229,j.a,this.CreateDelegate(this.SM_BetaRechargeResultHandler)),c.j.Inst.F_Register(-12228,X.Y,this.CreateDelegate(this.SM_BetaRechargeInfoHandler)),
c.j.Inst.F_Register(-12227,Z.B,this.CreateDelegate(this.SM_BetaRechargeConfigHandler)),c.j.Inst.F_Register(-12267,q.c,this.CreateDelegate(this.SM_JigsawInfoHandler)),
c.j.Inst.F_Register(-12268,tt.$,this.CreateDelegate(this.SM_JigsawPuzzleConfigHandler)),c.j.Inst.F_Register(-12269,et.P,this.CreateDelegate(this.SM_JigsawResetHandler)),
c.j.Inst.F_Register(-12314,K._,this.CreateDelegate(this.SM_BetaLotteryConfigHandler)),c.j.Inst.F_Register(-12315,z.h,this.CreateDelegate(this.SM_BetaLotteryInfoHandler)),
c.j.Inst.F_Register(-12316,Q.M,this.CreateDelegate(this.SM_BetaLotteryServerHandler)),c.j.Inst.F_Register(-12273,W.V,this.CreateDelegate(this.SM_JigsawBoxClearHandler)),
c.j.Inst.F_Register(-12274,J.P,this.CreateDelegate(this.SM_JigsawAssistInfoHandler)),c.j.Inst.F_Register(-12275,$.N,this.CreateDelegate(this.SM_JigsawGatherHandler)),
st.L.Inst_get().model.AddEventHandler(at.M.INFORM_DO_REMOVE,this.CreateDelegate(this.JigsawTaskHandler)),
h.o.Inst().AddGroup(l.Z.GROUP_NORMAL_BAG,this.CreateDelegate(this.OnBagUpdate)),r.i.Inst.AddEventHandler(O.g.MAP_UPDATE_POSITION,this.CreateDelegate(this.UpdatePosHandler)),
r.i.Inst.AddEventHandler(O.g.MAP_LOAD_COMPELETE,this.CreateDelegate(this.MapChangeHandler)),
r.i.Inst.AddEventHandler(O.g.HUODONG_INFO_CHANGE,this.CreateDelegate(this.OnHuoDongChange))}SM_BetaLotteryConfigHandler(t){ht.B.Inst_get().DealBetaLotteryConfig(t)}
SM_BetaLotteryInfoHandler(t){ht.B.Inst_get().DealBetaLotteryInfo(t)}SM_BetaLotteryServerHandler(t){ht.B.Inst_get().DealBetaLotteryServer(t)}SM_JigsawAssistInfoHandler(t){
T.V.Inst_Get().LeftAssistTime=t.assistCount,r.i.Inst.RaiseEvent(O.g.ALLIANCE_ASSIT_LEFTTIME)}JigsawTaskHandler(t){t.type_get()==nt.U.JIGSAW&&(this.OnCollectFinish(),
ht.B.Inst_get().isAutoCollectJigsaw&&this.OpenCollctRewardIcon())}SM_JigsawGatherHandler(t){ht.B.Inst_get().AddCollectReward(t)}SM_JigsawBoxClearHandler(t){
B.p.inst.IsInCopy()&&N.a.Inst_get().curCopyType==P.S.JigsawBoss&&(v.Q.Inst_get().bossModel.boxEndTime=Math.floor(t.clearTime.ToNum()/1e3),v.Q.Inst_get().bossModel.isKillBoss=!0,
R.N.inst_get().OpenBoxPanel(),it.n.inst.CloseRyAllianceCopyTaskView())}SM_JigsawResetHandler(t){ht.B.Inst_get().JigsawReset(t.chapter)}SM_JigsawPuzzleConfigHandler(t){
ht.B.Inst_get().JigsawConfig_set(t)}SM_JigsawInfoHandler(t){ht.B.Inst_get().JigsawInfo_set(t)}SM_BetaRechargeResultHandler(t){ht.B.Inst_get().DealBetaRechargeResult(t),
this.OpenRewardShowView()}SM_BetaRechargeInfoHandler(t){ht.B.Inst_get().DealBetaRechargeInfo(t)}SM_BetaRechargeConfigHandler(t){ht.B.Inst_get().DealBetaRechargeConfig(t)}
ReqCM_GetBetaLotteryNum(){const t=new k.w
t.activityId=y.S.PUBLICBETA_DAILY,_.C.Inst.F_SendMsg(t)}ReqCM_GetBetaLotteryReward(){const t=new x.x
t.activityId=y.S.PUBLICBETA_DAILY,_.C.Inst.F_SendMsg(t)}ReqBetaRechargeReward(t,e){const i=new V.K
i.activityId=t,i.resourceId=e,_.C.Inst.F_SendMsg(i)}ReqCM_JigsawChipAct(t){const e=new U.x
e.activityId=rt.t.PUBLICBETA_JIGSAW,e.id=t,_.C.Inst.F_SendMsg(e)}ReqCM_JigsawReward(t){const e=new Y.q
e.activityId=rt.t.PUBLICBETA_JIGSAW,e.chapter=t,_.C.Inst.F_SendMsg(e)}ReqCM_JigsawChallenge(t){if(0==M.E.Instance.HasResourceDone())return
const e=new H.Y
e.objId=t,_.C.Inst.F_SendMsg(e)}ReqCM_JigsawQuest(t){const e=new F.B
e.objId=t,_.C.Inst.F_SendMsg(e)}static Inst_get(){return null==oi._inst&&(oi._inst=new oi),oi._inst}Test1(){return!0}OnBagUpdate(){ht.B.Inst_get().RefreshJigsawRedpointState()}
OnCollectAdd(t){if(ht.B.Inst_get().isAutoCollectJigsaw&&t&&140==t.m_cfg.groupId){
n.Y.Inst.PrimaryRole_get().CurrentMachineState_get()!=o.k.Gather&&G.k.Inst_get().openCollectBtn(t,!0)}}OnCollectFinish(t){
ht.B.Inst_get().isAutoCollectJigsaw&&this.TryUseJigsawTreasureMapItem()}TryUseJigsawTreasureMapItem(t){if(ht.B.Inst_get().isAutoCollectJigsaw){
const e=D.g.Inst_get().GetItemListByItemType(E.q.TREASUREMAP)
if(e.Count()>0){if(n.Y.Inst.PrimaryRole_get().CurrentMachineState_get()!=o.k.Gather){if(!t&&a.M.Inst.hasNeedPick_get())return d._.getInst().endHang(),n.Y.Inst.CurTarget_set(null),
void n.Y.Inst.AddAllPlayerAI(s.R.autoTaskDropCatch)
const[i,o]=n.Y.Inst.PrimaryRole_get().GetPosXZ()
let l=1e8,r=e[0]
for(let t=0;t<=e.count-1;t++){
const s=e[t].baseData_get().serverData_get().questId,n=ot.O.Inst_get().GetConfig(s).tCTargetDefs_get().tCTargetDefs[0].param.gatherPos_get(),a=I.o.GetStringArr(n,"_"),[h,d,c]=[f.M.String2Double(a[0]),f.M.String2Double(a[1]),f.M.String2Double(a[2])]
if(h==u.b.Inst.currentMapId_get()){const s=A.p.FastDistanceXY(i,o,d,c)
s<l&&(r=e[t],l=s)}}w.J.Inst_get().UseItem(r.baseData_get(),null)}}else ht.B.Inst_get().SetAutoCollectJigsaw(!1)}}OpenPublicBetaView(t){ht.B.Inst_get().defaul_tab_idx=t,
lt.l.ins.CM_OpenActivityPanel(rt.t.PUBLICBETA_DAILY)
const e=new g.v
e.isShowMask=!0,e.isDefaultUITween=!0,e.isSelfTween=!0,e.viewClass=ni,m.N.inst.OpenById(C.I.RyPublicBetaMianView,null,null,e)}ClosePublicBetaView(){
m.N.inst.CloseById(C.I.RyPublicBetaMianView)}OpenRewardShowView(){const t=new g.v
t.isShowMask=!0,t.isDefaultUITween=!1,t.isSelfTween=!1,t.layerType=p.F.Alert,t.viewClass=ai,m.N.inst.OpenById(C.I.RyPublicBetaRewardView,null,null,t)}ClosePublicBetaReward(){
m.N.inst.CloseById(C.I.RyPublicBetaRewardView)}OpenDaliyTipView(){const t=new g.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!1,t.layerType=p.F.Alert,t.viewClass=Ft,m.N.inst.OpenById(C.I.RyPublicBetaDaliyTipView,null,null,t)}CloseDaliyTipView(){
m.N.inst.CloseById(C.I.RyPublicBetaDaliyTipView)}OpenCollctRewardView(){if(ht.B.Inst_get().isAutoCollectJigsaw||this.CloseCollctRewardIcon(),
null==ht.B.Inst_get().GetCollectReward())return!0
const t=new g.v
t.isShowMask=!1,t.isDefaultUITween=!1,t.isSelfTween=!1,t.layerType=p.F.Alert,t.viewClass=Tt,m.N.inst.OpenById(C.I.RyPublicBetaCollctRewardView,null,null,t)}CloseCollctRewardView(){
m.N.inst.CloseById(C.I.RyPublicBetaCollctRewardView),ht.B.Inst_get().isAutoCollectJigsaw||(this.CloseCollctRewardIcon(),ht.B.Inst_get().ClearCollectReward())}
OpenAutoCollctScreenIcon(){const t=new g.v
t.layerType=p.F.DefaultUI,t.viewClass=ut,t.ReLoginOrChangeRoleIsDestroy=!1,m.N.inst.OpenById(C.I.RyPublicBetaAutoCollctScreenIcon,null,null,t)}CloseAutoCollctScreenIcon(){
m.N.inst.CloseById(C.I.RyPublicBetaAutoCollctScreenIcon)}OpenCollctRewardIcon(){if(null==ht.B.Inst_get().GetCollectReward())return
const t=new g.v
t.isShowMask=!1,t.isDefaultUITween=!1,t.isSelfTween=!1,t.layerType=p.F.DefaultUI,t.positionType=S.Z.eCustom,t.viewClass=gt,
m.N.inst.OpenById(C.I.RyPublicBetaCollctRewardIcon,null,null,t)}CloseCollctRewardIcon(){m.N.inst.CloseById(C.I.RyPublicBetaCollctRewardIcon)}OpenDaliyLotteryRewardView(){
const t=new g.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!1,t.layerType=p.F.Alert,t.viewClass=Ht,m.N.inst.OpenById(C.I.RyPublicBetaDaliyRewardView,null,null,t)}
CloseDaliyLotteryRewardView(){m.N.inst.CloseById(C.I.RyPublicBetaDaliyRewardView)}GetMainPanelId(){const t=m.N.inst.GetViewById(C.I.RyPublicBetaMianView)
return null!=t?t.FatherId:null}OpenJigsawLightChipPanel(){const t=new g.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!1,t.layerType=p.F.Alert,t.viewClass=jt,m.N.inst.OpenById(C.I.RyPublicBetaJigsawLightChipView,null,null,t)}
CloseJigsawLightChipPanel(){m.N.inst.CloseById(C.I.RyPublicBetaJigsawLightChipView)}UpdatePosHandler(){this.CheckBreakAutoCollect()}MapChangeHandler(){
this.CheckBreakAutoCollect(!1)}OnHuoDongChange(t){t==rt.t.PUBLICBETA_JIGSAW&&ht.B.Inst_get().RefreshJigsawRedpointState()}GetTaskPosInfo(t){
const e=t.tCTargetDefs_get().tCTargetDefs[0].param.gatherPos_get(),i=I.o.GetStringArr(e,"_"),[s,n,a]=[f.M.String2Double(i[0]),f.M.String2Double(i[1]),f.M.String2Double(i[2])]
return[s,n,a]}GetColloctTaskId(){if(null!=w.J.Inst_get().CurrentUseJigsawChipId){const t=D.g.Inst_get().GetItemById(w.J.Inst_get().CurrentUseJigsawChipId)
if(t){const e=t.baseData_get().serverData_get().questId,i=ot.O.Inst_get().GetConfig(e)
if(null!=i){return[e,i.tCTargetDefs_get().tCTargetDefs[0].param.gatherId]}}}return 0}GetColloctId(){if(null!=w.J.Inst_get().CurrentUseJigsawChipId){
const t=D.g.Inst_get().GetItemById(w.J.Inst_get().CurrentUseJigsawChipId)
if(t){const e=t.baseData_get().serverData_get().questId,i=ot.O.Inst_get().GetConfig(e,null)
if(null!=i){return i.tCTargetDefs_get().tCTargetDefs[0].param.gatherId}}}return 0}CheckBreakAutoCollect(t){
if(null!=w.J.Inst_get().CurrentUseJigsawChipId&&ht.B.Inst_get().isAutoCollectJigsaw){const e=D.g.Inst_get().GetItemById(w.J.Inst_get().CurrentUseJigsawChipId)
if(e){const i=e.baseData_get().serverData_get().questId,s=ot.O.Inst_get().GetConfig(i)
if(null!=s){const e=s.tCTargetDefs_get().tCTargetDefs[0].param.gatherId,[i,a,o]=this.GetTaskPosInfo(s),l=L.J.Inst().getItemById(e)
i==u.b.Inst.currentMapId_get()&&(null!=t&&!t||b.l.CheckFastCharToXZDisFast(n.Y.Inst.PrimaryRole_get(),a,o,l.distance))||(this.CurrentUseJigsawChipId=null,
ht.B.Inst_get().SetAutoCollectJigsaw(!1))}}}}}oi._inst=null},70377:(t,e,i)=>{i.d(e,{F:()=>r})
var s=i(93984),n=i(38836),a=i(55360),o=i(85602),l=i(38962)
class r{constructor(){this.jigsawMap=null,this.jigsawRewardMap=null,this.jigsawBossMap=null,this.jigsawChapterList=null,this.jigsawChipMap=null,this.mapPublicbetalucky=null,
this.jigsawBossMap=new l.X,this.jigsawChapterList=new o.Z,this.jigsawChipMap=new l.X
const t=a.Y.Inst.GetOrCreateCsv(s.h.ePublicBetaJigsawResource)
this.jigsawMap=t.GetCsvMap()
let e=a.Y.Inst.GetOrCreateCsv(s.h.ePublicBetaJigsawRewardResource)
this.jigsawRewardMap=e.GetCsvMap()
const i=a.Y.Inst.GetOrCreateCsv(s.h.ePublicBetaJigsawBossResource).GetCsvMap()
e=a.Y.Inst.GetOrCreateCsv(s.h.ePublicbetaluckycharmresourceCsv),this.mapPublicbetalucky=e.GetCsvMap()
for(const[t,e]of(0,n.V5)(this.jigsawMap)){let t=this.jigsawChipMap[e.chapter]
t||(this.jigsawChipMap[e.chapter]=new o.Z,t=this.jigsawChipMap[e.chapter],this.jigsawChapterList.Add(e.chapter)),t.Add(e)}for(const[t,e]of(0,n.V5)(i))this.jigsawBossMap[e.copyId]=e
const r=(t,e)=>t.puzzleId-e.puzzleId
for(const[t,e]of(0,n.V5)(this.jigsawChipMap))e.Sort(r)
this.jigsawChapterList.Sort(((t,e)=>t-e))}static Inst_get(){return r._inst||(r._inst=new r),r._inst}GetJigsawChapterList(){return this.jigsawChapterList}GetLucyCfg(t){
return this.mapPublicbetalucky[t]}GetLucyCfgByLevel(t){for(const[e,i]of(0,n.V5)(this.mapPublicbetalucky))if(i.level==t)return i
return null}GetJigsawChipList(t){return this.jigsawChipMap[t]}GetJigsawChipConfig(t){return this.jigsawMap[t]}GetJigsawConfig(){return this.jigsawMap}GetJigsawAccess(t){
const e=this.jigsawRewardMap[t]
if(e)return e.access}GetJigsawBossConfig(t){return this.jigsawBossMap[t]}}r._inst=null},40312:(t,e,i)=>{i.d(e,{B:()=>S})
var s=i(97461),n=i(16812),a=i(62370),o=i(98885),l=i(85602),r=i(38962),h=i(62699),d=i(92679),u=i(75439),c=i(14792),_=i(62734),I=i(84141),g=i(12842),m=i(23649),C=i(93727)
class S extends n.k{constructor(){super(),this.defaul_tab_idx=S.DAILY,this.configDic=null,this.InfoDic=null,this.rewards=null,this.jigsawInfo=null,this.jigsawConfig=null,
this.clickJigsawChipId=null,this.betaLotteryNum=null,this.canGained=!1,this.honorPoint=0,this.clickGainLottery=!1,this.jigsawRedpointIdMap={},this.jigsawChapterRedpointIdMap={},
this.jigsawRewardRedpointIdMap={},this.jigsawIdSortList=null,this.isAutoCollectJigsaw=!1,this.isTweenEnd=!1,this.tiemeLotterEndArr=null,this.daliyDataFreshArr=null,
this.nowDate=null,this.fixDaliyNum=null,this.lotteryConfigList=null,this.showShopRedPoint=null,this.hasNotices=null,this.lotteryPlayeDatas=null,this.mylotteryData=null,
this.firstlotteryData=null,this.needClearCollectData=null,this.collectRewards=null,this.configDic=new r.X,this.InfoDic=new r.X,this.jigsawIdSortList=new l.Z
let t=u.D.getInstance().GetStringValue("PUBLICBETA:LUCKYTIME")
this.tiemeLotterEndArr=a.o.GetIntArr(t,":"),t=u.D.getInstance().GetStringValue("PUBLICBETA:ACTIVATION_RESET"),this.daliyDataFreshArr=a.o.GetIntArr(t,":"),this.nowDate=I.E.New(),
this.fixDaliyNum=u.D.getInstance().GetIntValue("PUBLICBETA:ACTIVATION"),this.lotteryConfigList=new l.Z,this.lotteryConfigList.Sort(this.CreateDelegate(this.SortLottery)),
this.showShopRedPoint=new l.Z,this.AddEvent()}AddEvent(){s.i.Inst.AddEventHandler(d.g.HUODONG_TYPE_CHANGE,this.CreateDelegate(this.TypeHandler)),
s.i.Inst.AddEventHandler(d.g.HUODONG_INFO_CHANGE,this.CreateDelegate(this.huoDongHandler)),s.i.Inst.AddEventHandler(d.g.DAILY_UPDATAVALUE,this.CreateDelegate(this.TypeHandler)),
s.i.Inst.AddEventHandler(d.g.VIP_UPDATE,this.CreateDelegate(this.VipHandler)),s.i.Inst.AddEventHandler(d.g.HUODONG_MALL_CHANGE,this.CreateDelegate(this.UpdateMall)),
s.i.Inst.AddEventHandler(d.g.HUODONG_MALL_BUY_CNT_LIST_CHANGE,this.CreateDelegate(this.UpdateMall2)),
s.i.Inst.AddEventHandler(d.g.COMMON_REMIND_DATA_RESET_BEFORCE,this.CreateDelegate(this.ResetShopRedData))}static Inst_get(){return null==S._inst&&(S._inst=new S),S._inst}
ResetShopRedData(){null!=this.hasNotices&&this.hasNotices.Clear(),this.showShopRedPoint.Clear()}UpdateMall2(t){t==g.t.PUBLICBETA_SHOP&&this.VipHandler()}UpdateMall(t){
t.activityId==g.t.PUBLICBETA_SHOP&&this.VipHandler()}VipHandler(){if(!C.i.ins.IsActiveState(g.t.PUBLICBETA_SHOP))return void _.f.Inst.SetState(c.t.PUBLICBETA_SHOP,!1)
const t=HuoDongMallModel.ins.GetMallListByHuoDongId(g.t.PUBLICBETA_SHOP)
let e=null
const i=`${CommonRemindModel.Inst_get().GetRolePrefix()}PUBLICBETA_SHOP_RED`,s=CommonRemindModel.Inst_get().GetStrData(i)
o.M.IsNullOrEmpty(s)||"false"==s||(e=a.o.GetIntArr(s))
let n=!1
for(let i=0;i<=t.Count()-1;i++){const s=t[i]
if(s.CheckView()&&s.CheckBuy()&&(null==e||!e.Contains(s.mallId))){const t=s.Remain_Num()
if(-1==t||t>0){n=!0
break}}}_.f.Inst.SetState(c.t.PUBLICBETA_SHOP,n)}IsShowShopRedPoint(t){if(t.CheckView()&&t.CheckBuy()){const e=t.Remain_Num()
if(-1==e||e>0){if(this.hasNotices.Contains(t.mallId))return!1
if(!this.showShopRedPoint.Contains(t.mallId))return this.showShopRedPoint.Add(t.mallId),!0}}return!1}AddShopNotices(t){
null!=t&&(this.hasNotices.Contains(t)||this.hasNotices.Add(t),this.showShopRedPoint.Contains(t)&&this.showShopRedPoint.Remove(t),
0==this.showShopRedPoint.count&&_.f.Inst.SetState(c.t.PUBLICBETA_SHOP,!1))}InitShopNoticeData(){
const t=`${CommonRemindModel.Inst_get().GetRolePrefix()}PUBLICBETA_SHOP_RED`,e=CommonRemindModel.Inst_get().GetStrData(t)
this.hasNotices=null,o.M.IsNullOrEmpty(e)||"false"==e?this.hasNotices=new l.Z:this.hasNotices=a.o.GetIntArr(e),this.showShopRedPoint.Clear()}SaveShopRedPoint(){
for(let t=0;t<=this.showShopRedPoint.Count()-1;t++)this.hasNotices.Contains(this.showShopRedPoint[t])||this.hasNotices.Add(this.showShopRedPoint[t])
const t=`${CommonRemindModel.Inst_get().GetRolePrefix()}PUBLICBETA_SHOP_RED`
let e=""
for(let t=0;t<=this.hasNotices.count-1;t++)t!=this.hasNotices.count-1?e+=`${this.hasNotices[t]},`:e+=this.hasNotices[t]
this.showShopRedPoint.Clear(),""!=e&&CommonRemindModel.Inst_get().SetStrData(t,e),_.f.Inst.SetState(c.t.PUBLICBETA_SHOP,!1)}IsLotteryEnd(){
if(C.i.ins.GetLastEndMS(h.S.PUBLICBETA_DAILY)>0){const t=C.i.ins.GetStartMS(h.S.PUBLICBETA_DAILY),e=LuaGlobal.serverMSTime_get()
if(this.nowDate.time_set(e),this.nowDate.hours_get()<this.daliyDataFreshArr[0]&&t>3600*-this.daliyDataFreshArr[0]*1e3)return!0
const i=this.GetLeftTime(this.tiemeLotterEndArr),s=this.GetLeftTime(this.daliyDataFreshArr)
return!(i>0&&s<=0)}return!0}GetLeftTime(t){const e=LuaGlobal.serverMSTime_get()
this.nowDate.time_set(e),this.nowDate.hours_set(t[0]),this.nowDate.minutes_set(t[1]),this.nowDate.seconds_set(t[2])
const i=this.nowDate.time_get()-e
return i>0?i:0}CheckShopHandler(t){}huoDongHandler(t){t==h.S.PUBLICBETA_DAILY&&this.TypeHandler()}TypeHandler(t){
if(C.i.ins.IsActiveState(h.S.PUBLICBETA_DAILY))if(this.canGained)_.f.Inst.SetState(c.t.PUBLICBETA_DAILY,!0)
else if(this.IsLotteryEnd()||0!=this.betaLotteryNum&&null!=this.betaLotteryNum||!(this.honorPoint>=this.fixDaliyNum)){if(null==t||t.Contains(m.h.PUBLICBETA_DALIY)){
const t=C.i.ins.GetQuestListVoByTargetTypeAndGroup(m.h.PUBLICBETA_DALIY,g.t.PUBLICBETA_DAILY)
let e=!1
for(let i=0;i<=t.Count()-1;i++)if(!t[i].activityRewardVo.isReward){if(t[i].targetVos[0].targetValue.ToNum()<=t[i].targetVos[0].curValue.ToNum()){e=!0
break}}_.f.Inst.SetState(c.t.PUBLICBETA_DAILY,e)}}else _.f.Inst.SetState(c.t.PUBLICBETA_DAILY,!0)
else _.f.Inst.SetState(c.t.PUBLICBETA_DAILY,!1)}GetHasGain(t,e){if(this.InfoDic.LuaDic_ContainsKey(t)){if(this.InfoDic.LuaDic_GetItem(t).hadGain.Contains(e))return!0}return!1}
GetTotolCharge(t){if(this.InfoDic.LuaDic_ContainsKey(t)){return this.InfoDic.LuaDic_GetItem(t).totalRecharge}return 0}GetConfigs(t){
return this.configDic.LuaDic_ContainsKey(t)?this.configDic.LuaDic_GetItem(t):null}DealBetaRechargeResult(t){this.rewards=t.reward.rewards}DealBetaRechargeInfo(t){
this.InfoDic.LuaDic_ContainsKey(t.activityId)?this.InfoDic.LuaDic_AddOrSetItem(t.activityId,t):this.InfoDic.LuaDic_Add(t.activityId,t)
const e=this.GetConfigs(t.activityId)
null!=e&&e.Sort(this.CreateDelegate(this.SortFunc)),t.activityId==g.t.PUBLICBETA_CHARGE&&this.CheckChrageRed(),this.RaiseEvent(S.PUBLICBETA_INFO,t.activityId)}
DealBetaRechargeConfig(t){let e=null
this.configDic.LuaDic_ContainsKey(t.activityId)?(e=this.configDic.LuaDic_GetItem(t.activityId),e.Clear()):(e=new l.Z,this.configDic.LuaDic_Add(t.activityId,e))
for(const[i,s]of Vpairs(t.resourceMap))e.Add(s)
e.Sort(this.CreateDelegate(this.SortFunc)),t.activityId==g.t.PUBLICBETA_CHARGE&&this.CheckChrageRed(),this.RaiseEvent(S.PUBLICBETA_CONFIG,t.activityId)}SortFunc(t,e){
const i=this.GetHasGain(t.activityId,t.id),s=this.GetHasGain(e.activityId,e.id)
return i&&!s?1:!i&&s?-1:t.currency-e.currency}CheckChrageRed(t,e){
if(!FunctionOpenModel.Inst_get().IsFunctionOpened(FunctionType.PUBLICBETA_RECHARGE))return void _.f.Inst.SetState(c.t.PUBLICBETA_RECHARGE,!1)
let i=!1
const s=this.GetConfigs(g.t.PUBLICBETA_CHARGE),n=this.GetTotolCharge(g.t.PUBLICBETA_CHARGE)
if(null!=s)for(let t=0;t<=s.count-1;t++)if(!this.GetHasGain(s[t].activityId,s[t].id)&&s[t].currency<n){i=!0
break}_.f.Inst.SetState(c.t.PUBLICBETA_RECHARGE,i)}JigsawInfo_set(t){this.jigsawInfo=t,this.RefreshJigsawRedpointState(),this.RaiseEvent(S.PUBLICBETA_JIGSAW_INFO)}JigsawInfo_get(){
return this.jigsawInfo}JigsawConfig_set(t){this.jigsawConfig=t
for(const[t,e]of Vpairs(this.jigsawConfig.puzzleResourceVoMap)){const t=LuaUtil.decode(e.consume1)[1],i=o.M.Split(t.value,a.o.s_Arr_UNDER_COLON),s=tonumber(i[0]),n=tonumber(i[1])
e.consumeTable[s]=n}}JigsawConfig_get(){return this.jigsawConfig}JigsawReset(t){if(this.jigsawInfo){
const e=this.jigsawInfo.puzzleInfoVoMap[t],i=this.jigsawConfig.rewardResourceVoMap[t]
e&&(e.round+=1,e.activateSet.Clear(),i.rewardNum>0&&e.round>i.rewardNum&&(e.isEnd=!0),this.RefreshJigsawRedpointState(),this.RaiseEvent(S.PUBLICBETA_JIGSAW_INFO))}}
IsJigsawChipLighted(t){if(this.jigsawInfo){const e=RyPublicBetaConfigMgr.Inst_get().GetJigsawChipConfig(t),i=this.jigsawInfo.puzzleInfoVoMap[e.chapter]
if(i)return i.activateSet.Contains(t)}return!1}IsJigsawChipCanLight(t){if(null==this.jigsawConfig)return!1
const e=this.jigsawConfig.puzzleResourceVoMap[t]
BagModel.Inst_get().GetItemNum(40301)
let i=!1
if(e){const t=e.consumeTable
for(const[e,s]of pairs(t)){BagModel.Inst_get().GetItemNum(e)>=s&&(i=!0)
break}}if(this.jigsawInfo){const e=RyPublicBetaConfigMgr.Inst_get().GetJigsawChipConfig(t),i=this.jigsawInfo.puzzleInfoVoMap[e.chapter]
if(i&&i.activateSet.Contains(t))return[!1,2]}return!!i||[!1,1]}IsJigsawRewardAllGet(t){if(this.jigsawInfo){const e=this.jigsawInfo.puzzleInfoVoMap[t]
if(e)return e.isEnd}}IsJigsawCanGetAward(t){if(this.jigsawInfo){const e=this.jigsawInfo.puzzleInfoVoMap[t]
if(e&&!e.isEnd){const i=this.jigsawConfig.rewardResourceVoMap[t]
return e.activateSet.Count()>=i.puzzleNum}}return!1}DealBetaLotteryConfig(t){this.lotteryConfigList.Clear()
for(const[e,i]of Vpairs(t.resourceVoMap)){const t=new RyPublicBetaLotteryConfigData
t.SetConfig(i),this.lotteryConfigList.Add(t)}this.lotteryConfigList.Sort(this.CreateDelegate(this.SortLottery)),this.RaiseEvent(S.PUBLICBETA_LOTTERY_CONFIG)}SortLottery(t,e){
return t.level-e.level}DealBetaLotteryInfo(t){this.clickGainLottery&&(t.canGained||(this.canGained,this.clickGainLottery=!1)),this.betaLotteryNum=t.lotteryNum,
this.canGained=t.canGained,this.honorPoint=t.honorPoint.ToNum(),this.TypeHandler(),this.RaiseEvent(S.PUBLICBETA_LOTTERY_INFO)}LastLottoryRewardInfo(t){const e=new l.Z
for(let i=0;i<=this.lotteryPlayeDatas.count-1;i++)this.lotteryPlayeDatas[i].level==t&&e.Add(this.lotteryPlayeDatas[i])
return e}LastLottoryRewardInfoList(t){const e=new l.Z,i=new l.Z
for(let t=0;t<=this.lotteryPlayeDatas.count-1;t++)i.Contains(this.lotteryPlayeDatas[t].level)||i.Add(this.lotteryPlayeDatas[t].level)
for(let t=0;t<=this.lotteryConfigList.count-1;t++)i.Contains(this.lotteryConfigList[t].level)&&e.Add(this.lotteryConfigList[t])
return[e,this.mylotteryData]}GetLotteryConfig(t){for(let e=0;e<=this.lotteryConfigList.count-1;e++)if(this.lotteryConfigList[e].level==t)return this.lotteryConfigList[e]}
DealBetaLotteryServer(t){this.lotteryPlayeDatas=t.rewardRes,this.mylotteryData=null,this.firstlotteryData=null
for(let t=0;t<=this.lotteryPlayeDatas.count-1;t++)1==this.lotteryPlayeDatas[t].level&&(this.firstlotteryData=this.lotteryPlayeDatas[t]),
this.lotteryPlayeDatas[t].account==CharacterMgr.Inst.PrimaryRoleInfo_get().accountindex&&(this.mylotteryData=this.lotteryPlayeDatas[t])
this.TypeHandler(),this.RaiseEvent(S.PUBLICBETA_LOTTERY_RESULT)}ResetData(){this.honorPoint=0,this.lotteryPlayeDatas=null,this.mylotteryData=null,this.firstlotteryData=null,
this.canGained=!1,this.betaLotteryNum=null,this.clickGainLottery=!1,this.isAutoCollectJigsaw=!1,RyPublicBetaControl.Inst_get().CloseCollctRewardIcon(),
RyPublicBetaControl.Inst_get().CloseCollctRewardView(),RyPublicBetaControl.Inst_get().CloseAutoCollctScreenIcon(),this.ClearCollectReward(),this.ResetShopRedData()}
CheckClearCollectData(){this.needClearCollectData&&this.ClearCollectReward()}InitJigsawRedpointIds(){const t=RyPublicBetaConfigMgr.Inst_get().GetJigsawConfig()
S.temp=new l.Z
for(const[e,i]of Vpairs(t)){if(!this.jigsawChapterRedpointIdMap[i.chapter]){const t=_.f.Inst.GetID()
this.jigsawChapterRedpointIdMap[i.chapter]=t,S.temp.Clear(),S.temp.Add(c.t.PUBLICBETA_JIGSAW),_.f.Inst.AddNode(t,S.temp,!1)
const e=_.f.Inst.GetID()
this.jigsawRewardRedpointIdMap[i.chapter]=e,S.temp.Clear(),S.temp.Add(t),_.f.Inst.AddNode(e,S.temp,!1)}const t=_.f.Inst.GetID()
this.jigsawRedpointIdMap[e]=t,this.jigsawIdSortList.Add(e),S.temp.Clear(),S.temp.Add(this.jigsawChapterRedpointIdMap[i.chapter]),_.f.Inst.AddNode(t,S.temp,!1)}
this.jigsawIdSortList.Sort(((t,e)=>t-e))}RefreshJigsawRedpointState(){if(FunctionOpenModel.Inst_get().IsFunctionOpened(FunctionType.PUBLICBETA_JIGSAW)){
const t=C.i.ins.IsActiveState(g.t.PUBLICBETA_JIGSAW),e={}
for(const[i,s]of Vpairs(this.jigsawIdSortList)){const i=this.jigsawRedpointIdMap[s]
if(i){let n=t&&this.IsJigsawChipCanLight(s)||!1
if(n){const t=RyPublicBetaConfigMgr.Inst_get().GetJigsawChipConfig(s).chapter
e[t]?n=!1:e[t]=!0}_.f.Inst.SetState(i,n)}}for(const[e,i]of pairs(this.jigsawRewardRedpointIdMap)){const s=t&&this.IsJigsawCanGetAward(e)||!1
_.f.Inst.SetState(i,s)}}}GetJigsawRedpointId(t){return this.jigsawRedpointIdMap[t]}GetJigsawChapterRedpointId(t){return this.jigsawChapterRedpointIdMap[t]}
GetJigsawRewardRedpointId(t){return this.jigsawRewardRedpointIdMap[t]}SetAutoCollectJigsaw(t){this.isAutoCollectJigsaw!=t&&(this.isAutoCollectJigsaw=t,
this.isAutoCollectJigsaw?(RyPublicBetaControl.Inst_get().OpenAutoCollctScreenIcon(),
RyPublicBetaControl.Inst_get().OpenCollctRewardIcon()):(RyPublicBetaControl.Inst_get().OpenCollctRewardView(),RyPublicBetaControl.Inst_get().CloseAutoCollctScreenIcon()),
this.RaiseEvent(S.AUOT_COLLECT_JIGSAW))}GetCollectReward(){return this.collectRewards}AddCollectReward(t){null==this.collectRewards&&(this.collectRewards=new l.Z),
this.collectRewards.Add(t.reward)}ClearCollectReward(){this.collectRewards=null}}S.BaoZang_BaoXiang_ID=799,S.DAILY=1,S.JIGSAW=2,S.RECHARGE=3,S.SHOP=4,S.REVIEW=0,S._inst=null,
S.PUBLICBETA_RESULT="PUBLICBETA_RESULT",S.PUBLICBETA_INFO="PUBLICBETA_INFO",S.PUBLICBETA_CONFIG="PUBLICBETA_CONFIG",S.PUBLICBETA_LOTTERY_CONFIG="PUBLICBETA_LOTTERY_CONFIG",
S.PUBLICBETA_LOTTERY_INFO="PUBLICBETA_LOTTERY_INFO",S.PUBLICBETA_LOTTERY_RESULT="PUBLICBETA_LOTTERY_RESULT",S.PUBLICBETA_JIGSAW_INFO="PUBLICBETA_JIGSAW_INFO",
S.AUOT_COLLECT_JIGSAW="AUOT_COLLECT_JIGSAW",S.temp=null},92447:(t,e,i)=>{i.d(e,{k:()=>d})
var s=i(5924),n=i(99294),a=i(11355),o=i(51868),l=i(60130),r=i(92679),h=i(40312)
class d extends o.${constructor(...t){super(...t),this.lefteff=null,this.rightEff=null,this.eff2=null,this.eff1=null,this.eff3=null,this.effTimerId=null,this.effTimerId2=null}
InitView(){super.InitView(),this.lefteff=this.CreateComponent(n.z,1),this.rightEff=this.CreateComponent(n.z,2),this.eff2=this.CreateComponent(a.I,3),
this.eff1=this.CreateComponent(a.I,4),this.eff3=this.CreateComponent(a.I,5)}Clear(){this.ClearEffTimer(),super.Clear()}Destroy(){super.Destroy(),this.lefteff=null,
this.rightEff=null,this.eff2=null,this.eff1=null,this.eff3=null}SetData(t){this.AddLis(),this.UpdateEffShow(),this.UpdateAnchors()}AddLis(){
this.m_handlerMgr.AddEventMgr(r.g.TabCommonOpenAniEnd,this.CreateDelegate(this.UpdateEffShow)),
this.m_handlerMgr.AddEventMgr(r.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors))}UpdateAnchors(){const t=l.O.GetUIWidth()
this.lefteff.transform.SetLocalPositionXYZ(-t/2+50,-253,0),this.rightEff.transform.SetLocalPositionXYZ(t/2-250,284,0)}UpdateEffShow(){h.B.Inst_get().isTweenEnd&&this.StartShowEff()
}StartShowEff(){null==this.effTimerId&&(this.lefteff.SetActive(!0),this.eff2.ResetToBeginning(),this.eff2.Play(),
this.effTimerId=s.C.Inst_get().SetInterval(this.CreateDelegate(this.ShowLeftEffEnd1),500,1),
this.effTimerId2=s.C.Inst_get().SetInterval(this.CreateDelegate(this.ShowRigthEff1),2e3,1))}ShowLeftEffEnd1(){
this.effTimerId=s.C.Inst_get().SetInterval(this.CreateDelegate(this.ShowLeftEffLoop),8e3)}ShowRigthEff1(){this.rightEff.SetActive(!0),this.eff1.ResetToBeginning(),
this.eff3.ResetToBeginning(),this.eff1.Play(),this.eff3.Play(),this.effTimerId2=s.C.Inst_get().SetInterval(this.CreateDelegate(this.ShowRigthEffLoop),8e3)}ShowLeftEffLoop(){
this.eff2.ResetToBeginning(),this.eff2.Play()}ShowRigthEffLoop(){this.eff1.ResetToBeginning(),this.eff3.ResetToBeginning(),this.eff1.Play(),this.eff3.Play()}ClearEffTimer(){
null!=this.effTimerId&&(s.C.Inst_get().ClearInterval(this.effTimerId),this.effTimerId=null),null!=this.effTimerId2&&(s.C.Inst_get().ClearInterval(this.effTimerId2),
this.effTimerId2=null)}}},69664:(t,e,i)=>{i.d(e,{E:()=>Jt})
var s=i(98497),n=i(38935),a=i(56937),o=i(31222),l=i(5494),r=i(85602),h=i(67885),d=i(18152),u=i(47786),c=i(34206),_=i(20904),I=i(25542),g=i(95132),m=i(91060),C=i(19777),S=i(52726),p=i(38836),A=i(5924),f=i(99294),y=i(9986),T=i(89501),R=i(93877),v=i(72005),w=i(61911),D=i(75696),E=i(97461),L=i(68662),G=i(16812),O=i(38962),b=i(92679)
class B{}B.UpdateSkyView=1,B.DelayObtain=2,B.RewradShowed=3
class N extends G.k{constructor(){super(),this.skyResourceDic=null,this.firstList=null,this.secondList=null,this.thirdList=null,this.skyRewardList=null,this.skyActid=0,
this.skyid2openTimes=null,this.skyRewardedList=null,this.skyUsedNum=0,this.limitActid=0,this.limitBoughtCount=0,this.freeOpenTime=null,this.skipEffect=!1,this.SkyCostItemId=12012,
this.show_btn_pool_effect=!0,this.need_reset_reward=!1,this.commLotteryBtns=null,this.defaul_tab_idx=0,this.skyResourceDic=new O.X,this.firstList=new r.Z,this.secondList=new r.Z,
this.thirdList=new r.Z,this.skyRewardList=new r.Z,this.skyRewardedList=new r.Z}static Inst_get(){return null==N._inst&&(N._inst=new N),N._inst}GetResourceLeftNumByID(t){let e=0
this.skyid2openTimes&&this.skyid2openTimes.LuaDic_ContainsKey(t)&&(e=this.skyid2openTimes.LuaDic_GetItem(t))
const i=this.skyResourceDic.LuaDic_GetItem(t)
return null!=i?i.limit-e:0}IsFirstRewardOver(){for(let t=0;t<=this.firstList.Count()-1;t++){const e=this.firstList[t]
if(this.GetResourceLeftNumByID(e.id)>0)return!1}return!0}GetAllResourceLeftNum(){let t=0
for(const[e,i]of(0,p.V5)(this.skyid2openTimes))t+=i
let e=0
for(const[t,i]of(0,p.V5)(this.skyResourceDic))e+=i.limit
return e-t}IsRewardCanGain(){if(null==this.skyRewardList)return!1
for(let t=0;t<=this.skyRewardList.Count()-1;t++)if(this.skyUsedNum>=this.skyRewardList[t].times){if(!this.skyRewardedList.Contains(this.skyRewardList[t].id))return!0}return!1}
IsSkyOnceFree(){if(this.freeOpenTime&&this.freeOpenTime.ToNum()>0){if(this.freeOpenTime.ToNum()-L.D.serverMSTime_get()>0)return!1}return!0}IsResourceOver(){for(const[t,e]of(0,
p.V5)(this.skyResourceDic)){if(!this.skyid2openTimes.LuaDic_ContainsKey(t))return!1
if(this.skyid2openTimes[t]<e.limit)return!1}return!0}InitStarResourceInfo(t){null!=t&&(this.skyActid=t.activityId,this.UpdateStarResourceList(t.starrySkyResourceVos),
this.UpdateSkyInfo(t.starrySkyInfoVo),this.skyRewardList=t.skyRewardResourceVos,this.skyRewardList.Sort(this.CreateDelegate(this.ShortSubSkyRewardData)),
this.RaiseEvent(B.UpdateSkyView))}UpdateSkyInfo(t){this.skyid2openTimes=t.id2OpenTimes,this.skyUsedNum=t.hadUsed,this.need_reset_reward=t.needReset,this.skyRewardedList.Clear()
for(const[e,i]of(0,p.vy)(t.rewardMap))3==i&&this.skyRewardedList.Add(e)
this.freeOpenTime=t.freeOpenTime,this.RaiseEvent(B.UpdateSkyView),E.i.Inst.RaiseEvent(b.g.STARSYK_UPDATE)}UpdateStarResourceList(t){if(null!=t){this.skyResourceDic.Clear(),
this.firstList.Clear(),this.secondList.Clear(),this.thirdList.Clear()
for(let e=0;e<=t.Count()-1;e++){const i=t[e]
this.skyResourceDic.LuaDic_Add(i.id,i),1==i.type?this.firstList.Add(i):2==i.type?this.secondList.Add(i):3==i.type&&this.thirdList.Add(i)}}}InitStarLimitInfo(t){
this.limitActid=t.activityId,this.limitBoughtCount=t.buyCount}GetSkyResourceDataById(t){return this.skyResourceDic.LuaDic_GetItem(t)}GetNextRewardTimes(){
if(null==this.skyRewardList||0==this.skyRewardList.Count())return 0
for(let t=0;t<=this.skyRewardList.Count()-1;t++){const e=this.skyRewardList[t],i=e.id
if(!this.skyRewardedList.Contains(i))return e.times}return this.skyRewardList[this.skyRewardList.Count()-1].times}ResetModel(){this.show_btn_pool_effect=!0,
this.need_reset_reward=!1}ShortSubSkyRewardData(t,e){return t.times-e.times}}N._inst=null
var P=i(6665),M=i(51868),V=i(18202),k=i(83540),x=i(70850),H=i(63076),U=i(87923),F=i(75439),Y=i(85605),K=i(82025),z=i(60567),Q=i(65550),Z=i(94009),X=i(93727)
class j{}j.btn_ok=1,j.btn_one=2,j.btn_ten=4,j.btn_reset=8
class J extends M.${constructor(){super(),this.btn_once=null,this.btn_ten=null,this.btn_free=null,this.lab_onece_time=null,this.btn_ok=null,this.sp_red=null,this.sp1=null,
this.sp10=null,this.lab_ten_msg=null,this.lab_one_msg=null,this.grid=null,this.btn_reset=null,this.actid=null,this.timerId=-1,this.ObtainType=-1,this.ONCE_NUM=1,this.TEN_NUM=null,
this.showBtnOne=!1,this.isObtaining=!1,this.actid=N.Inst_get().skyActid,this.TEN_NUM=F.D.getInstance().GetIntValue("STARRYSKY:CONSUME_TENTIME")}InitView(){super.InitView(),
this.btn_once=this.CreateComponent(y.W,1),this.btn_ten=this.CreateComponent(y.W,2),this.btn_free=this.CreateComponent(y.W,3),this.lab_onece_time=this.CreateComponent(R.Q,4),
this.btn_ok=this.CreateComponent(y.W,5),this.sp_red=this.CreateComponent(f.z,6),this.sp1=this.CreateComponent(v.w,7),this.sp10=this.CreateComponent(v.w,8),
this.lab_ten_msg=this.CreateComponent(R.Q,9),this.lab_one_msg=this.CreateComponent(R.Q,10),this.grid=this.CreateComponent(P.A,11),this.btn_reset=this.CreateComponent(y.W,12),
this.SetIcon()}SetData(t){this.AddEvent()
const e=0!=bit.band(t,j.btn_ok)
this.showBtnOne=0!=bit.band(t,j.btn_one)
const i=0!=bit.band(t,j.btn_ten),s=0!=bit.band(t,j.btn_reset)
if(this.btn_reset.SetActive(s),this.btn_ok.SetActive(e),this.btn_ten.SetActive(i),this.lab_onece_time.SetActive(!0),this.showBtnOne){
const t=N.Inst_get().IsSkyOnceFree(),e=N.Inst_get().IsResourceOver(),i=t&&!e
this.btn_free.SetActive(i),this.btn_once.SetActive(!i),i?this.ClearTimer():this.StarTimer()}else this.ClearTimer(),this.btn_once.SetActive(!1),this.btn_free.SetActive(!1)
this.grid.Reposition(),this.UpdateBtnMsg()}AddEvent(){this.m_handlerMgr.AddClickEvent(this.btn_free,this.CreateDelegate(this.OnFreeClick)),
this.m_handlerMgr.AddClickEvent(this.btn_once,this.CreateDelegate(this.OnOnceClick)),this.m_handlerMgr.AddClickEvent(this.btn_ten,this.CreateDelegate(this.OnTenClick)),
this.m_handlerMgr.AddClickEvent(this.btn_ok,this.CreateDelegate(this.OnOkClick)),this.m_handlerMgr.AddClickEvent(this.btn_reset,this.CreateDelegate(this.OnResetClick)),
this.m_handlerMgr.AddNotifyEvent(N.Inst_get(),B.RewradShowed,this.CreateDelegate(this.OnRewradShowed)),
E.i.Inst.AddEventHandler(b.g.BAG_UPDATE,this.CreateDelegate(this.UpdateBtnMsg))}RemoveEvent(){
this.m_handlerMgr.RemoveClickEvent(this.btn_free,this.CreateDelegate(this.OnFreeClick)),this.m_handlerMgr.RemoveClickEvent(this.btn_once,this.CreateDelegate(this.OnOnceClick)),
this.m_handlerMgr.RemoveClickEvent(this.btn_ten,this.CreateDelegate(this.OnTenClick)),this.m_handlerMgr.RemoveClickEvent(this.btn_ok,this.CreateDelegate(this.OnOkClick)),
this.m_handlerMgr.RemoveClickEvent(this.btn_reset,this.CreateDelegate(this.OnResetClick)),
this.m_handlerMgr.RemoveNotifyEvent(N.Inst_get(),B.RewradShowed,this.CreateDelegate(this.OnRewradShowed)),
E.i.Inst.RemoveEventHandler(b.g.BAG_UPDATE,this.CreateDelegate(this.UpdateBtnMsg)),
E.i.Inst.RemoveEventHandler(b.g.HUODONG_MALL_BUY_SUCCESS,this.CreateDelegate(this._BuySuccessHandle))}UpdateBtnMsg(){const t=x.g.Inst_get().GetItemNum(N.Inst_get().SkyCostItemId)
t>=this.ONCE_NUM?this.lab_one_msg.textSet(string.format("抽一次(     %s)",this.ONCE_NUM)):this.lab_one_msg.textSet(string.format("抽一次(     [ff0000]%s[-])",this.ONCE_NUM)),
t>=this.TEN_NUM?this.lab_ten_msg.textSet(string.format("抽十次(     %s)",this.TEN_NUM)):this.lab_ten_msg.textSet(string.format("抽十次(     [ff0000]%s[-])",this.TEN_NUM))}SetIcon(){
const t=new H.M(N.Inst_get().SkyCostItemId,null)
if(null!=t&&null!=t.cfgData_get()&&null!=t.cfgData_get().icon&&""!=t.cfgData_get().icon)return this.sp1.node.SetActive(!0),
V.g.SetItemIcon(this.sp1.FatherId,this.sp1.ComponentId,t.cfgData_get().icon,k.b.eItem,!1),this.sp10.node.SetActive(!0),
void V.g.SetItemIcon(this.sp10.FatherId,this.sp10.ComponentId,t.cfgData_get().icon,k.b.eItem,!1)
this.sp1.node.SetActive(!1)}OnRewradShowed(){this.isObtaining=!1}StarTimer(){-1!=this.timerId&&this.ClearTimer(),
this.timerId=A.C.Inst_get().SetInterval(this.CreateDelegate(this.TimerHanler),1e3),this.TimerHanler()}ClearTimer(){-1!=this.timerId&&(A.C.Inst_get().ClearInterval(this.timerId),
this.timerId=-1)}TimerHanler(){if(null==this.lab_onece_time&&this.ClearTimer(),N.Inst_get().IsResourceOver())return this.btn_once.SetActive(!0),this.btn_free.SetActive(!1),
this.lab_onece_time.SetActive(!1),void this.ClearTimer()
const t=N.Inst_get().freeOpenTime
if(t&&t.ToNum()>0){const e=t.ToNum()-L.D.serverMSTime_get()
if(e>0){const t=U.l.GetDateFormatEX(e/1e3,!0,!0)
this.lab_onece_time.textSet(string.format("免费:[5fb470]%s[-]",t)),this.btn_free.SetActive(!1),this.btn_once.SetActive(!0)}else this.ClearTimer()}else this.ClearTimer()}
OnFreeClick(){0!=this._CheckObtainReward()&&(this.ObtainType=0,this.MySendObtainReward())}OnOnceClick(){0!=this._CheckObtainReward()&&(this.ObtainType=1,this.MySendObtainReward())}
OnTenClick(){0!=this._CheckObtainReward()&&(N.Inst_get().IsFirstRewardOver()&&N.Inst_get().GetAllResourceLeftNum()<10?Q.y.inst.ClientSysMessage(11042906):(this.ObtainType=2,
this.MySendObtainReward()))}OnOkClick(){q.Inst_get().CloseCommRewardView()}OnResetClick(){q.Inst_get().CloseCommRewardView(),Jt.Inst_get().SendResetResource(this.actid),
E.i.Inst.RaiseEvent(b.g.COMM_REWARD_RESET_CLICK)}_CheckObtainReward(){return X.i.ins.GetLastEndMS(this.actid)/1e3<=0?(Q.y.inst.ClientSysMessage(11042910),
!1):x.g.Inst_get().IsBagFull()?(Q.y.inst.ClientSysMessage(101001),!1):this.isObtaining?(Q.y.inst.ClientSysMessage(11042909),
!1):!N.Inst_get().IsResourceOver()||(Q.y.inst.ClientSysMessage(11042905),!1)}MySendObtainReward(){let t=0
1==this.ObtainType?t=this.ONCE_NUM:2==this.ObtainType&&(t=this.TEN_NUM)
Y.$.ins.CheckItemEnough(this.actid,N.Inst_get().SkyCostItemId,t)?this._RelSendObtainReward():E.i.Inst.AddEventHandler(b.g.HUODONG_MALL_BUY_SUCCESS,this.CreateDelegate(this._BuySuccessHandle))
}_BuySuccessHandle(t){E.i.Inst.RemoveEventHandler(b.g.HUODONG_MALL_BUY_SUCCESS,this.CreateDelegate(this._BuySuccessHandle)),this._RelSendObtainReward()}_RelSendObtainReward(){
q.Inst_get().CloseCommRewardView(),
this.isObtaining=!0,0==this.ObtainType?Jt.Inst_get().SendObtainReward(this.actid,!0,!1):1==this.ObtainType?Jt.Inst_get().SendObtainReward(this.actid,!1,!1):2==this.ObtainType&&Jt.Inst_get().SendObtainReward(this.actid,!1,!0)
}GetMallInfo(){return z.P.ins.GetVoByHuodongIdAndType(X.i.ins.GetOpenHuoDongIdByGroupId(Z.$.STAR_LIMIT),K.f.TICKET_TYPE)}Clear(){this.isObtaining=!1,this.ClearTimer(),
this.RemoveEvent(),super.Clear()}Destroy(){super.Destroy()}}class W{}W.Normal=0,W.StarSky=1
class $ extends w.f{constructor(){super(),this.grid=null,this.final_reward_root=null,this.final_ui_baseitem=null,this.final_effect=null,this.bottom_root=null,
this.ui_sky_lottery_btns=null,this.final_btn_ok=null,this.sp_title=null,this.lab_msg=null,this.normal_reward_root=null,this.lab_tips=null,this.vo=null,this.curshowRewardIdx=-1,
this.timerId=-1,this.rewardItemDataList=null,this.NORMAL_REWARD_SP="ryxingkongmibao_sp_0002",this.FINAL_REWARD_SP="ryxingkongmibao_sp_0003",this.vo=q.Inst_get().curRewardVO,
this.rewardItemDataList=this.vo.rewardItemDataList}InitView(){super.InitView(),this.grid=this.CreateComponent(T.N,1),this.final_reward_root=this.CreateComponent(f.z,2),
this.final_ui_baseitem=this.CreateComponentBinder(D.j,3),this.final_effect=this.CreateComponent(f.z,4),this.bottom_root=this.CreateComponent(f.z,5),
this.ui_sky_lottery_btns=this.CreateComponentBinder(J,6),this.final_btn_ok=this.CreateComponent(y.W,7),this.sp_title=this.CreateComponent(v.w,8),
this.lab_msg=this.CreateComponent(R.Q,9),this.normal_reward_root=this.CreateComponent(f.z,10),this.lab_tips=this.CreateComponent(f.z,11),this.bottom_root.SetActive(!1),
this.lab_msg.textSet(""),this.grid.SetInitInfo("ui_baseitem",null,D.j),this.grid.OnReposition_set(this.CreateDelegate(this.SetGridCallback)),
this.grid.data_set(this.rewardItemDataList)}OnAddToScene(){this.vo.type==W.StarSky&&this.ui_sky_lottery_btns.SetData(N.Inst_get().commLotteryBtns),
this.lab_tips.SetActive(this.vo.click2close),this.AddListen()}Clear(){this.ClearTimer(),this.RemoveListen(),super.Clear()}Destroy(){super.Destroy()}AddListen(){
this.m_handlerMgr.AddClickEvent(this.final_btn_ok,this.CreateDelegate(this.OnFinalOkClick)),
this.vo.click2close&&this.AddFullScreenCollider(this.node,this.CreateDelegate(this.Check2Close))}RemoveListen(){
this.m_handlerMgr.RemoveClickEvent(this.final_btn_ok,this.CreateDelegate(this.OnFinalOkClick)),
this.vo.click2close&&this.RemoveFullScreenCollider(this.node,this.CreateDelegate(this.Check2Close))}SetGridCallback(){for(const[t,e]of(0,p.V5)(this.grid.itemList))e.SetActive(!1)
this.StartRewardTimer()}StartRewardTimer(){
-1!=this.timerId&&this.ClearTimer(),this.rewardItemDataList.Count()>1?this.timerId=A.C.Inst_get().SetInterval(this.CreateDelegate(this.DrawTimerHanler),200):(this.DrawTimerHanler(),
this.bottom_root.SetActive(!0))}ClearTimer(){-1!=this.timerId&&(A.C.Inst_get().ClearInterval(this.timerId),this.timerId=-1)}DrawTimerHanler(){if(this.curshowRewardIdx+=1,
null==this.rewardItemDataList)return void this.ClearTimer()
if(this.curshowRewardIdx>this.rewardItemDataList.Count()-1)return void this.bottom_root.SetActive(!0)
const t=this.rewardItemDataList[this.curshowRewardIdx]
t.showEffect?(this.grid.itemList[this.curshowRewardIdx].SetActive(!0),this.ClearTimer(),this.normal_reward_root.SetActive(!1),this.final_ui_baseitem.SetData(t),
this.final_reward_root.SetActive(!0),this.final_effect.SetActive(!0),this.sp_title.spriteNameSet(this.FINAL_REWARD_SP)):this.grid.itemList[this.curshowRewardIdx].SetActive(!0),
this.curshowRewardIdx==this.rewardItemDataList.Count()-1&&this.lab_msg.textSet(this.vo.msg_str)}OnFinalOkClick(){this.normal_reward_root.SetActive(!0),
this.final_reward_root.SetActive(!1),this.StartRewardTimer(),this.sp_title.spriteNameSet(this.NORMAL_REWARD_SP)}Check2Close(){
null!=this.rewardItemDataList?this.final_reward_root.activeSelf()||(1==this.rewardItemDataList.Count()||this.curshowRewardIdx>this.rewardItemDataList.Count()-1)&&q.Inst_get().CloseCommRewardView():q.Inst_get().CloseCommRewardView()
}}class q{constructor(){this.curRewardVO=null}static Inst_get(){return null==q._inst&&(q._inst=new q),q._inst}OpenCommRewardView(t){this.curRewardVO=t
const e=new a.v
e.isShowMask=!0,e.layerType=S.F.Tip,e.viewClass=$,o.N.inst.OpenById(l.I.CommRewardView,null,null,e)}CloseCommRewardView(){o.N.inst.CloseById(l.I.CommRewardView)}}q._inst=null
var tt=i(38045),et=i(72208),it=i(18161),st=i(30459),nt=i(5996),at=i(40863),ot=i(21365),lt=i(69967),rt=i(91517)
class ht extends H.M{constructor(...t){super(...t),this.showEffect=!1}wrapReward(t){let e=null
if((0,tt.t2)(t,it.e)){const i=t
e=new ht(i.itemModelId,null),ht.ParseReward(i,e),e.count=i.num}else((0,tt.t2)(t,lt.A)||(0,tt.t2)(t,et.L)||(0,tt.t2)(t,ot.e)||(0,tt.t2)(t,st.x)||(0,tt.t2)(t,at.N)||(0,
tt.t2)(t,nt.C))&&(e=new ht(0,null),e.virtualItemData_set(rt.a.GetItemByReward(t)))
return e}}ht.ParseReward=null
class dt{constructor(){this.type=0,this.msg_str="",this.rewardItemDataList=null,this.click2close=!0}}var ut=i(9057)
class ct extends ut.x{constructor(...t){super(...t),this.ui_baseitem=null,this.lab_leftnum=null}InitView(){super.InitView(),this.ui_baseitem=this.CreateComponentBinder(D.j,1),
this.lab_leftnum=this.CreateComponent(R.Q,2)}SetData(t){if(null==t)return
const e=H.M.wrapReward(t.andReward.rewards[0])
e.iconType=d.s.BASE_ICON_REWARD_TYPE
const i=N.Inst_get().GetResourceLeftNumByID(t.id)
i<=0?(this.lab_leftnum.textSet(string.format("剩[ff0000]%d[-]个",i)),e.iconExtraData[h.S.GRAY_IMG]="已抽空"):this.lab_leftnum.textSet(string.format("剩%d个",i)),
this.ui_baseitem.SetData(e)}Clear(){super.Clear()}Destroy(){super.Destroy()}}class _t extends w.f{constructor(...t){super(...t),this.btn_close=null,this.grid1=null,this.grid2=null,
this.grid3=null}InitView(){super.InitView(),this.btn_close=this.CreateComponent(y.W,1),this.grid1=this.CreateComponent(T.N,2),this.grid2=this.CreateComponent(T.N,3),
this.grid3=this.CreateComponent(T.N,4),this.grid1.SetInitInfo("ui_sky_pool_rewardshow_item",null,ct),this.grid2.SetInitInfo("ui_sky_pool_rewardshow_item",null,ct),
this.grid3.SetInitInfo("ui_sky_pool_rewardshow_item",null,ct)}OnAddToScene(){this.AddEvent(),this.grid1.data_set(N.Inst_get().firstList),
this.grid2.data_set(N.Inst_get().secondList),this.grid3.data_set(N.Inst_get().thirdList)}AddEvent(){
this.m_handlerMgr.AddClickEvent(this.btn_close,this.CreateDelegate(this.OnCloseClick))}OnCloseClick(){Jt.Inst_get().CloseRewardPoolView()}Clear(){super.Clear()}Destroy(){
super.Destroy()}}
var It=i(16261),gt=i(36334),mt=i(44255),Ct=i(62085),St=i(60130),pt=i(28287),At=i(55492),ft=i(35128),yt=i(99421),Tt=i(86133),Rt=i(62370),vt=i(30267),wt=i(86209),Dt=i(7601),Et=i(52513),Lt=i(31896),Gt=i(19519),Ot=i(75582)
class bt extends ut.x{constructor(...t){super(...t),this.huodongMallVo=null,this.huodongMallCfgVo=null,this.text_limit_time=null,this.text_name=null,this.img_discount=null,
this.btn_buy=null,this.text_buy=null,this.grid_item=null,this.consume_obj=null,this.img_consume_icon=null,this.text_consume_num=null,this.img_sell_over=null,this.discountLabel=null
}InitView(){super.InitView(),this.text_limit_time=this.CreateComponent(R.Q,1),this.text_name=this.CreateComponent(R.Q,2),this.img_discount=this.CreateComponent(v.w,3),
this.btn_buy=this.CreateComponent(v.w,4),this.text_buy=this.CreateComponent(R.Q,5),this.grid_item=this.CreateComponent(P.A,6),this.consume_obj=this.CreateComponent(vt.V,7),
this.img_consume_icon=this.CreateComponent(v.w,8),this.text_consume_num=this.CreateComponent(R.Q,9),this.img_sell_over=this.CreateComponent(v.w,10),
this.discountLabel=this.CreateComponent(R.Q,11),this.grid_item.SetInitInfo("ui_baseitem",null,D.j)}SetData(t){this.huodongMallVo=t,
this.huodongMallCfgVo=Ot.Z.ins.GetVoByMallId(this.huodongMallVo.mallId),this.AddLis(),this.Update()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.btn_buy,this.CreateDelegate(this.OnClickBtnBuy)),
this.m_handlerMgr.AddEventMgr(b.g.HUODONG_MALL_BUY_CNT_CHANGE,this.CreateDelegate(this.OnBuyCntChange))}RemoveLis(){}Clear(){super.Clear(),this.RemoveLis()}Destroy(){
super.Destroy()}Update(){-1==this.huodongMallVo.limit?this.text_limit_time.SetActive(!1):(this.text_limit_time.SetActive(!0),this.text_limit_time.textSet(Rt.o.Format((0,
Tt.T)("限购{0}次"),this.huodongMallVo.limit-z.P.ins.GetBuyTimesByMallId(this.huodongMallVo.mallId)))),this.text_name.textSet(this.huodongMallCfgVo.name)
const t=new r.Z
for(let e=0;e<=this.huodongMallVo.reward.rewards.Count()-1;e++){const i=H.M.wrapReward(this.huodongMallVo.reward.rewards[e])
i.iconType=d.s.BASE_ICON_TYPE_64_64,t.Add(i)}this.grid_item.data_set(t),this.discountLabel.node.SetActive(!1),
1==this.huodongMallCfgVo.label?this.img_discount.spriteNameSet("ryjbsd_sp_0012"):2==this.huodongMallCfgVo.label?(this.discountLabel.node.SetActive(!0),
this.img_discount.spriteNameSet("ryjbsd_sp_0027"),
this.discountLabel.textSet(`${this.huodongMallCfgVo.discount}%`)):3==this.huodongMallCfgVo.label?this.img_discount.spriteNameSet("ryjbsd_sp_0011"):this.img_discount.node.SetActive(!1),
this.img_discount.MakePixelPerfect(),
-1!=this.huodongMallVo.limit&&z.P.ins.GetBuyTimesByMallId(this.huodongMallVo.mallId)>=this.huodongMallVo.limit?(this.img_sell_over.SetActive(!0),
this.btn_buy.SetActive(!1)):(this.img_sell_over.SetActive(!1),this.btn_buy.SetActive(!0),this.UpdateConmsue())}UpdateConmsue(){if(this.text_consume_num.SetActive(!0),
this.img_consume_icon.SetActive(!0),0!=this.huodongMallVo.rechargeId){
const t=Et.O.Inst().getConfig(this.huodongMallVo.rechargeId),e=Dt.W.Inst.GetCurSystem(),i=t.platformCurrency[e]
this.text_consume_num.textSet(`${i}元`),this.img_consume_icon.SetActive(!1)}else{const t=this.huodongMallVo.Consume_Get().GetItemDataByType()
this.text_consume_num.textSet(wt.w.Instance.ConvertNumToString(t.count)),null!=t.virtualItemData_get()?this.img_consume_icon.spriteNameSet(Gt.J.GetCurrencyIconUrl(t.virtualItemData_get().virtualTypeStr)):this.img_consume_icon.spriteNameSet("")
}this.consume_obj.CallReposition()}OnClickBtnBuy(){
0!=this.huodongMallVo.rechargeId?Lt.t.inst.Buy(Et.O.Inst().getConfig(this.huodongMallVo.rechargeId)):Y.$.ins.CheckConsumeEnough(this.huodongMallVo.Consume_Get())&&Y.$.ins.CM_ActivityMallBuy(this.huodongMallVo.mallId)
}OnBuyCntChange(t){t==this.huodongMallVo.mallId&&this.Update()}}class Bt extends M.${constructor(...t){super(...t),this.grid_item=null,this.text_time=null,this.interval=null}
InitView(){super.InitView(),this.grid_item=this.CreateComponent(P.A,1),this.text_time=this.CreateComponent(R.Q,2),this.grid_item.SetInitInfo("ui_starlimit_item",null,bt)}SetData(){
yt.l.ins.CM_OpenActivityPanel(X.i.ins.GetOpenHuoDongIdByGroupId(Z.$.STAR_LIMIT)),
null==this.interval&&(this.interval=A.C.Inst_get().SetInterval(this.CreateDelegate(this.OnEachSec),1e3)),this.UpdateView(),this.OnEachSec()}AddLis(){}RemoveLis(){}Clear(){
super.Clear(),null!=this.interval&&(A.C.Inst_get().ClearInterval(this.interval),this.interval=null)}Destroy(){super.Destroy()}UpdateView(){
const t=z.P.ins.GetMallListByHuoDongId(X.i.ins.GetOpenHuoDongIdByGroupId(Z.$.STAR_LIMIT)),e=new r.Z
for(let i=0;i<=t.Count()-1;i++)t[i].CheckView()&&t[i].CheckBuy()&&e.Add(t[i])
this.grid_item.data_set(e)}OnEachSec(){const t=X.i.ins.huodong_dict.LuaDic_GetItem(X.i.ins.GetOpenHuoDongIdByGroupId(Z.$.STAR_LIMIT))
if(null!=t){const e=ft.p.FloorToInt(t.endTime.ToNum()/1e3)-L.D.serverTime_get()
e>0?this.text_time.textSet(`结束倒计时: [5fb470]${U.l.GetDateFormatEX(e,!0,!0)}[-]`):(this.text_time.textSet("已结束"),Jt.Inst_get().OpenStarSkyView())}else this.text_time.textSet("")}}
var Nt=i(14792),Pt=i(3522),Mt=i(32208),Vt=i(13113),kt=i(98130),xt=i(79534),Ht=i(53905),Ut=i(65772),Ft=i(3859),Yt=i(99327),Kt=i(70531)
class zt extends M.${constructor(...t){super(...t),this.itemImg=null,this.lab_num=null,this.lab_left_num=null,this.sp_select=null,this.noneobj=null,this.sp_bg1=null,
this.effect=null,this.root=null,this.normal_left_num=null,this.data=null,this._baseItemData=null}InitView(){super.InitView(),this.itemImg=this.CreateComponent(v.w,1),
this.lab_num=this.CreateComponent(R.Q,2),this.lab_left_num=this.CreateComponent(R.Q,3),this.sp_select=this.CreateComponent(f.z,4),this.noneobj=this.CreateComponent(v.w,5),
this.sp_bg1=this.CreateComponent(v.w,6),this.effect=this.CreateComponent(f.z,7),this.root=this.CreateComponent(Vt.T,8),this.normal_left_num=this.CreateComponent(R.Q,9)}SetData(t){
this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this._OnClickHandler)),this.data=t,this._baseItemData=H.M.wrapReward(t.andReward.rewards[0])
const e=N.Inst_get().GetResourceLeftNumByID(this.data.id)
if(e<=0?this.noneobj.SetActive(!0):this.noneobj.SetActive(!1),1==t.type){this.sp_bg1.spriteNameSet("ryxingkongmibao_sp_0012"),this.sp_bg1.widthSet(93),this.sp_bg1.heightSet(93),
this.noneobj.widthSet(80),this.noneobj.heightSet(80)
const t=1.55
this.sp_select.transform.SetLocalScaleXYZ(t,t,1),this.lab_num.SetActive(!1),0!=e?(this.lab_left_num.SetActive(!0),
this.lab_left_num.textSet(string.format("剩%d个",e))):this.lab_left_num.SetActive(!1),this.effect.SetActive(!0)
}else 2==t.type?this.sp_bg1.spriteNameSet("ryxingkongmibao_sp_0013"):this.sp_bg1.spriteNameSet("ryxingkongmibao_sp_0014"),this.sp_bg1.widthSet(60),this.sp_bg1.heightSet(60),
this.noneobj.widthSet(58),this.noneobj.heightSet(58),this.sp_select.transform.SetLocalScaleXYZ(1,1,1),0!=this._baseItemData.count?(this.lab_num.SetActive(!0),
this.lab_num.textSet(string.format("X%d",this._baseItemData.count))):this.lab_num.SetActive(!1),0!=e?(this.normal_left_num.SetActive(!0),
this.normal_left_num.textSet(string.format("剩%d个",e))):this.normal_left_num.SetActive(!1),this.lab_left_num.SetActive(!1),this.effect.SetActive(!1)
this.SetIcon(),this.SetNumText()}SetIcon(){
if(null!=this._baseItemData&&null!=this._baseItemData.cfgData_get()&&null!=this._baseItemData.cfgData_get().icon&&""!=this._baseItemData.cfgData_get().icon)return this.itemImg.node.SetActive(!0),
void V.g.SetItemIcon(this.itemImg.FatherId,this.itemImg.ComponentId,this._baseItemData.cfgData_get().icon,k.b.eItem,!1)
this.itemImg.node.SetActive(!1)}CheckResourceOver(){if(null!=this.data){return N.Inst_get().GetResourceLeftNumByID(this.data.id)<=0}return!0}SetNumText(){let t=""
this._baseItemData&&(this._baseItemData.count>1||this._baseItemData.isShowZeroNum)&&(t=this._baseItemData.count>0?`X${this._baseItemData.count}`:"[de2524]0[-]"),
this.lab_num.textSet(t)}_OnClickHandler(){if(this._baseItemData){const t=this._baseItemData.cfgData_get()
if(null==t)return
t.itemType==Ft.q.PANDORA?Kt.R.Inst_get().OpenView(this._baseItemData,null):t.itemType==Ft.q.VIPPANDORA?Yt.a.Inst_get().OpenView(this._baseItemData):INS.itemTipManager.OpenTipView(this._baseItemData)
}}HideItem(){this.root.SetColorRGBA(255,255,255,0)}ShowSelectBg(t){this.sp_select.SetActive(t)}Clear(){super.Clear()}Destroy(){super.Destroy()}}class Qt extends ut.x{
constructor(...t){super(...t),this.lab_num=null,this.sp_yellow=null,this.sp_gray=null,this.ui_baseitem=null,this.baseItem=null,this.rewardid=0,this.isenought=!1,this.isRewarded=!1}
InitView(){super.InitView(),this.lab_num=this.CreateComponent(R.Q,1),this.sp_yellow=this.CreateComponent(f.z,2),this.sp_gray=this.CreateComponent(f.z,3),
this.ui_baseitem=this.CreateComponentBinder(D.j,4)}SetData(t){this.rewardid=t.id,this.isenought=N.Inst_get().skyUsedNum>=t.times,this.baseItem=H.M.wrapReward(t.reward.rewards[0])
const e=N.Inst_get().skyRewardedList
this.isRewarded=e.Contains(t.id),this.isRewarded?this.baseItem.iconExtraData[h.S.GRAY_IMG]="已领取":this.baseItem.iconExtraData[h.S.GRAY_IMG]=null,
this.baseItem.iconExtraData[h.S.GET_EFFECT]=this.isenought&&!this.isRewarded,this.lab_num.textSet((0,tt.tw)(t.times)),this.sp_yellow.SetActive(this.isenought),
this.sp_gray.SetActive(!this.isenought),this.baseItem.iconType=d.s.SKY_REWARD_ICON_TYPE1,this.ui_baseitem.ClickHandler_Set(this.CreateDelegate(this.ClickHandle)),
this.ui_baseitem.EnabledClickOpenTip(!1),this.ui_baseitem.SetData(this.baseItem)}ClickHandle(){if(this.isenought&&!this.isRewarded){const t=N.Inst_get().skyActid
Jt.Inst_get().SendGainReward(t,this.rewardid)}else this.ShowTips()}ShowTips(){if(this.baseItem){const t=this.baseItem.cfgData_get()
t.itemType==Ft.q.PANDORA?Kt.R.Inst_get().OpenView(this.baseItem,null):t.itemType==Ft.q.VIPPANDORA?Yt.a.Inst_get().OpenView(this.baseItem):INS.itemTipManager.OpenTipView(this.baseItem)
}}Clear(){super.Clear()}Destroy(){super.Destroy()}}class Zt extends M.${constructor(){super(),this.grid=null,this.lab_num=null,this.slide_fg=null,this.SLIDE_BG_LENGTH=420,
this.GRID_HIGHT=360,this.usedNum=0,this.cell_height=0,this.datalist=null,this.datalist=new r.Z}InitView(){super.InitView(),this.grid=this.CreateComponent(T.N,1),
this.lab_num=this.CreateComponent(R.Q,2),this.slide_fg=this.CreateComponent(v.w,3),this.grid.SetInitInfo("ui_subsky_reward_item",null,Qt)}SetData(t){
this.usedNum=N.Inst_get().skyUsedNum,this.datalist.Clear()
let e=N.Inst_get().skyRewardList.Count()-1
for(;e>=0;)this.datalist.Add(N.Inst_get().skyRewardList[e]),e-=1
this.datalist.Count()>1&&(this.cell_height=this.GRID_HIGHT/(this.datalist.Count()-1)),this.grid.cellHeightSet(this.cell_height),this.grid.data_set(this.datalist),
this.lab_num.textSet(`已抽：${this.usedNum}`)
const i=this.CalSlideHeight()
this.slide_fg.heightSet(i)}CalSlideHeight(){const t=N.Inst_get().skyRewardList
for(let e=0;e<=t.Count()-1;e++){const i=t[e]
if(this.usedNum<i.times){if(0==e)return this.usedNum/i.times*(this.SLIDE_BG_LENGTH-this.GRID_HIGHT)
const s=this.SLIDE_BG_LENGTH-this.GRID_HIGHT+this.cell_height*(e-1),n=t[e-1].times
return s+(this.usedNum-n)/(i.times-n)*this.cell_height}}return this.SLIDE_BG_LENGTH}Clear(){super.Clear()}Destroy(){super.Destroy()}}class Xt extends w.f{constructor(){super(),
this.tipsreward=null,this.first_reward=null,this.second_reward=null,this.third_reward=null,this.btn_reward=null,this.btn_rewardpool=null,this.bottom=null,this.lab_timeLeft=null,
this.top_tips=null,this.ui_sky_lottery_btns=null,this.item_1_0=null,this.item_1_1=null,this.item_1_2=null,this.item_2_0=null,this.item_2_1=null,this.item_2_2=null,
this.item_2_3=null,this.item_2_4=null,this.item_2_5=null,this.item_3_0=null,this.item_3_1=null,this.item_3_2=null,this.item_3_3=null,this.item_3_4=null,this.item_3_5=null,
this.item_3_6=null,this.item_3_7=null,this.item_3_8=null,this.item_3_9=null,this.item_3_10=null,this.item_3_11=null,this.reward_btn_effect=null,this.ani=null,this.lab_num=null,
this.btn_tog=null,this.pool_btn_effect=null,this.tipBtn=null,this.eff_starrysky=null,this.model=null,this.actid=null,this.timerId=-1,this.rtimerId=-1,this.delayAniTimerId=-1,
this.first_reward_list=null,this.sec_reward_list=null,this.third_reward_list=null,this.isShowOpenAni=!1,this.last_select_idx=-1,this.tempList=null,this.tempDic=null,
this.aniResourceId=-1,this.curAniShowTimes=0,this.maxAniShowTimes=15,this.model=N.Inst_get(),this.actid=N.Inst_get().skyActid,this.first_reward_list=new r.Z,
this.sec_reward_list=new r.Z,this.third_reward_list=new r.Z,this.tempList=new r.Z,this.tempDic=new O.X}InitView(){super.InitView(),this.tipsreward=this.CreateComponentBinder(Zt,1),
this.first_reward=this.CreateComponent(f.z,2),this.second_reward=this.CreateComponent(f.z,3),this.third_reward=this.CreateComponent(f.z,4),
this.btn_reward=this.CreateComponent(y.W,5),this.btn_rewardpool=this.CreateComponent(y.W,6),this.bottom=this.CreateComponent(Vt.T,10),
this.lab_timeLeft=this.CreateComponent(R.Q,11),this.top_tips=this.CreateComponent(Vt.T,12),this.ui_sky_lottery_btns=this.CreateComponentBinder(J,13),
this.item_1_0=this.CreateComponentBinder(zt,14),this.item_1_1=this.CreateComponentBinder(zt,15),this.item_1_2=this.CreateComponentBinder(zt,16),
this.item_2_0=this.CreateComponentBinder(zt,17),this.item_2_1=this.CreateComponentBinder(zt,18),this.item_2_2=this.CreateComponentBinder(zt,19),
this.item_2_3=this.CreateComponentBinder(zt,20),this.item_2_4=this.CreateComponentBinder(zt,21),this.item_2_5=this.CreateComponentBinder(zt,22),
this.item_3_0=this.CreateComponentBinder(zt,23),this.item_3_1=this.CreateComponentBinder(zt,24),this.item_3_2=this.CreateComponentBinder(zt,25),
this.item_3_3=this.CreateComponentBinder(zt,26),this.item_3_4=this.CreateComponentBinder(zt,27),this.item_3_5=this.CreateComponentBinder(zt,28),
this.item_3_6=this.CreateComponentBinder(zt,29),this.item_3_7=this.CreateComponentBinder(zt,30),this.item_3_8=this.CreateComponentBinder(zt,31),
this.item_3_9=this.CreateComponentBinder(zt,32),this.item_3_10=this.CreateComponentBinder(zt,33),this.item_3_11=this.CreateComponentBinder(zt,34),
this.reward_btn_effect=this.CreateComponent(f.z,35),this.ani=this.CreateComponent(Pt.k,36),this.lab_num=this.CreateComponent(R.Q,37),this.btn_tog=this.CreateComponent(Mt.r,38),
this.pool_btn_effect=this.CreateComponent(f.z,39),this.tipBtn=this.CreateComponent(y.W,40),this.eff_starrysky=this.CreateComponent(f.z,41),
this.first_reward_list.Add(this.item_1_0),this.first_reward_list.Add(this.item_1_1),this.first_reward_list.Add(this.item_1_2),this.sec_reward_list.Add(this.item_2_0),
this.sec_reward_list.Add(this.item_2_1),this.sec_reward_list.Add(this.item_2_4),this.sec_reward_list.Add(this.item_2_5),this.sec_reward_list.Add(this.item_2_2),
this.sec_reward_list.Add(this.item_2_3),this.third_reward_list.Add(this.item_3_10),this.third_reward_list.Add(this.item_3_11),this.third_reward_list.Add(this.item_3_0),
this.third_reward_list.Add(this.item_3_1),this.third_reward_list.Add(this.item_3_6),this.third_reward_list.Add(this.item_3_7),this.third_reward_list.Add(this.item_3_8),
this.third_reward_list.Add(this.item_3_9),this.third_reward_list.Add(this.item_3_2),this.third_reward_list.Add(this.item_3_3),this.third_reward_list.Add(this.item_3_4),
this.third_reward_list.Add(this.item_3_5),this.InitView2Zero(),this.StarOpenAniTimer()}OnAddToScene(){this._AddEvent(),this.tipsreward.SetActive(!1),this.StartTimer(),
this.UpdateSkyView()}Clear(){this.eff_starrysky.SetActive(!1),this.ClearTimer(),this.ClearRandomTimer(),this.ClearOpenAniTimer(),this._RemoveEvent(),super.Clear()}Destroy(){
this.model.show_btn_pool_effect=!1,super.Destroy()}_AddEvent(){this.m_handlerMgr.AddClickEvent(this.btn_reward,this.CreateDelegate(this.OnRewardClick)),
this.m_handlerMgr.AddClickEvent(this.btn_rewardpool,this.CreateDelegate(this.OnShowRewardPoolClick)),
this.m_handlerMgr.AddClickEvent(this.btn_tog,this.CreateDelegate(this.OnTogClick)),this.m_handlerMgr.AddClickEvent(this.tipBtn,this.CreateDelegate(this.OnTideClick)),
this.m_handlerMgr.AddNotifyEvent(this.model,B.UpdateSkyView,this.CreateDelegate(this.UpdateSkyView)),
this.m_handlerMgr.AddNotifyEvent(this.model,B.DelayObtain,this.CreateDelegate(this.OnObtainRewardWithAni)),
E.i.Inst.AddEventHandler(b.g.COMM_REWARD_RESET_CLICK,this.CreateDelegate(this.OnResetRewardClick))}_RemoveEvent(){
this.m_handlerMgr.RemoveNotifyEvent(this.model,B.UpdateSkyView,this.CreateDelegate(this.UpdateSkyView)),
this.m_handlerMgr.RemoveNotifyEvent(this.model,B.DelayObtain,this.CreateDelegate(this.OnObtainRewardWithAni)),
E.i.Inst.RemoveEventHandler(b.g.COMM_REWARD_RESET_CLICK,this.CreateDelegate(this.OnResetRewardClick))}InitView2Zero(){this.top_tips.SetColorRGBA(255,255,255,0),
this.bottom.SetColorRGBA(255,255,255,0)
for(let t=0;t<=this.first_reward_list.Count()-1;t++)this.first_reward_list[t].HideItem()
for(let t=0;t<=this.sec_reward_list.Count()-1;t++)this.sec_reward_list[t].HideItem()
for(let t=0;t<=this.third_reward_list.Count()-1;t++)this.third_reward_list[t].HideItem()}UpdateSkyView(){this.tipsreward.SetData()
let t=bit.bor(j.btn_one,j.btn_ten)
if(N.Inst_get().need_reset_reward&&(t=j.btn_reset),this.ui_sky_lottery_btns.SetData(t),this.btn_tog.SetValue(N.Inst_get().skipEffect),
2==this.model.firstList.Count())this.first_reward_list[0].SetActive(!1),this.first_reward_list[1].SetActive(this.model.firstList[0]),
this.first_reward_list[2].SetActive(this.model.firstList[1])
else for(let t=0;t<=this.first_reward_list.Count()-1;t++)if(t<this.model.firstList.Count()){const e=this.model.firstList[t]
this.first_reward_list[t].SetData(e)}else this.first_reward_list[t].SetActive(!1)
for(let t=0;t<=this.sec_reward_list.Count()-1;t++)if(t<this.model.secondList.Count()){const e=this.model.secondList[t]
this.sec_reward_list[t].SetData(e)}else this.sec_reward_list[t].SetActive(!1)
for(let t=0;t<=this.third_reward_list.Count()-1;t++)if(t<this.model.thirdList.Count()){const e=this.model.thirdList[t]
this.third_reward_list[t].SetData(e)}else this.third_reward_list[t].SetActive(!1)
const e=N.Inst_get().IsRewardCanGain()
this.reward_btn_effect.SetActive(e)
const i=N.Inst_get().GetNextRewardTimes(),s=Math.min(N.Inst_get().skyUsedNum,i)
this.lab_num.textSet(`${s}/${i}`),this.pool_btn_effect.SetActive(this.model.show_btn_pool_effect)}OnObtainRewardWithAni(t){this.aniResourceId=t,this.curAniShowTimes=0,
this.StartRandomSelectTimer()}OnResetRewardClick(){this.eff_starrysky.SetActive(!1),this.eff_starrysky.SetActive(!0),this.ani.SetClipName("ani_eff_starrysky_08_01"),
this.ani.SetResetOnPlay(!0),this.ani.Play(!0,!1)}OnRewardClick(){const t=!this.tipsreward.isActiveAndEnabled()
this.tipsreward.SetActive(t)}OnShowRewardPoolClick(){this.model.show_btn_pool_effect=!1,this.pool_btn_effect.SetActive(!1),Jt.Inst_get().OpenRewardPoolView()}OnTogClick(){
N.Inst_get().skipEffect=this.btn_tog.GetValue()}OnTideClick(){const t=new Ht.w
t.position=new xt.P(-270,300,0),t.width=450,t.infoId="STARRYSKY:TIPS",Ut.Q.Inst_get().Open(t)}StarOpenAniTimer(){
-1==this.delayAniTimerId&&(this.delayAniTimerId=A.C.Inst_get().SetInterval(this.CreateDelegate(this._ShowOpenAni),300,1))}_ShowOpenAni(){this.ClearOpenAniTimer(),
this.ani.node.SetActive(!0),this.ani.SetClipName("ani_eff_xkmb_01"),this.ani.SetResetOnPlay(!0),this.ani.Play(!0,!1)}ClearOpenAniTimer(){
-1!=this.delayAniTimerId&&(A.C.Inst_get().ClearInterval(this.delayAniTimerId),this.delayAniTimerId=-1)}StartRandomSelectTimer(){this.ClearRandomTimer(),
this.rtimerId=A.C.Inst_get().SetInterval(this.CreateDelegate(this._ShowNextRandomSelect),300),this._ShowNextRandomSelect()}ClearRandomTimer(){this._HideRandomSelect(),
-1!=this.rtimerId&&(A.C.Inst_get().ClearInterval(this.rtimerId),this.rtimerId=-1)}StartTimer(){this.ClearTimer(),
this.timerId=A.C.Inst_get().SetInterval(this.CreateDelegate(this.TimerHanler),1e3)}ClearTimer(){-1!=this.timerId&&(A.C.Inst_get().ClearInterval(this.timerId),this.timerId=-1)}
TimerHanler(){null==this.lab_timeLeft&&this.ClearTimer()
const t=X.i.ins.GetLastEndMS(this.actid)/1e3
if(t<=0)this.lab_timeLeft.textSet("活动已结束"),this.ClearTimer()
else{const e=U.l.GetDateFormatEX(t,!0,!0)
this.lab_timeLeft.textSet(`活动倒计时：[5fb470]${e}[-]`)}}_HideRandomSelect(){this._SetItemSelect(this.last_select_idx,!1),this.last_select_idx=-1}_ShowNextRandomSelect(){
this._SetItemSelect(this.last_select_idx,!1),this.curAniShowTimes+=1,this.curAniShowTimes>this.maxAniShowTimes||N.Inst_get().skipEffect?(this.ClearRandomTimer(),
this._ShowItemSelectById(this.aniResourceId,!1),
Jt.Inst_get().RelShowRewrad()):this.curAniShowTimes==this.maxAniShowTimes?this._ShowItemSelectById(this.aniResourceId,!0):this.curAniShowTimes<this.maxAniShowTimes&&(this.last_select_idx=this._GetNexRandomIdx(),
this._SetItemSelect(this.last_select_idx,!0))}_SetItemSelect(t,e){if(-1!=t&&null!=this.tempList&&t<this.tempList.Count()&&null!=this.tempList[t]){const i=this.tempList[t]
this.tempDic[i].ShowSelectBg(e)}}_ShowItemSelectById(t,e){null!=this.tempDic&&this.tempDic.LuaDic_ContainsKey(t)&&this.tempDic[t].ShowSelectBg(e)}_GetNexRandomIdx(){
this.tempList.Clear(),this.tempDic.Clear()
for(let t=0;t<=this.first_reward_list.Count()-1;t++)if(!this.first_reward_list[t].CheckResourceOver()){const e=this.first_reward_list[t]
this.tempList.Add(e.data.id),this.tempDic.LuaDic_Add(e.data.id,e)}for(let t=0;t<=this.sec_reward_list.Count()-1;t++)if(!this.sec_reward_list[t].CheckResourceOver()){
const e=this.sec_reward_list[t]
this.tempList.Add(e.data.id),this.tempDic.LuaDic_Add(e.data.id,e)}for(let t=0;t<=this.third_reward_list.Count()-1;t++)if(!this.third_reward_list[t].CheckResourceOver()){
const e=this.third_reward_list[t]
this.tempList.Add(e.data.id),this.tempDic.LuaDic_Add(e.data.id,e)}const t=this.tempList.Count()
return kt.GF.INT(ft.p.RandomMax(t))}}class jt extends mt.I{constructor(){super(),this.RIGHT_NAMES=null,this.RIGHT_REDIDS=null,this.TAB_FUNC_TYPES=null,this.bg3=null,
this.RIGHT_NAMES=new r.Z(["星空秘宝","星空限购"]),this.RIGHT_REDIDS=new r.Z([Nt.t.STAR_SKY,Nt.t.STAR_SKY_LIMIT]),this.TAB_FUNC_TYPES=new r.Z([At.x.STAR_SKY,At.x.STAR_SKY_LIMIT])}
InitView(){super.InitView(),this.bg3=this.CreateComponent(It.X,24),this._subPanelDatas.Add(gt.b.New(new r.Z(["ui_starsky_view"]),this,Xt)),
this._subPanelDatas.Add(gt.b.New(new r.Z(["ui_starlimit_view","ui_starlimit_item"]),this,Bt)),
this.rightTabGrid.SetInitInfo("ui_ry_right_tab3",null,Ct.M,this.CreateDelegate(this._OnClickRightItem)),
this.rightTabGrid.OnReposition_set(this.CreateDelegate(this.OnRepositionRight))}SetViewConfig(){this._SetTabData0(!1),
this._SetTabData1(!0,this.RIGHT_NAMES,this.RIGHT_REDIDS,this.TAB_FUNC_TYPES),this.SelectTab1(N.Inst_get().defaul_tab_idx)}_OnSelectTab1BeforeUpdate(t){
this.ShowSubView(this.selectTabIdx1)}ShowCurrencyBar_get(){return pt._.ShowGOLD_STARSKY}UpdateAnchors(){super.UpdateAnchors()
const t=St.O.GetUIWidth(),e=St.O.GetUIHeight()
null!=this.bg3&&(this.bg3.widthSet(t),this.bg3.heightSet(e))}OnCloseClick(){Jt.Inst_get().CloseStarSkyView()}Clear(){super.Clear()}Destroy(){super.Destroy()}}class Jt{
constructor(){this.ObtainType=-1,this.tempStarrySkyReward=null}static Inst_get(){return null==Jt._inst&&(Jt._inst=new Jt),Jt._inst}RegMsg(){
s.j.Inst.F_Register(-12062,m.Y,this.CreateDelegate(this.SM_StarrySkyInfoHandler)),s.j.Inst.F_Register(-12063,C.P,this.CreateDelegate(this.SM_StarrySkyRewardHandler)),
s.j.Inst.F_Register(-12069,g.x,this.CreateDelegate(this.SM_StarrySkyGainHandler))}SM_StarrySkyRewardHandler(t){this.tempStarrySkyReward=t,
N.Inst_get().need_reset_reward=this.HasFinalReward(t),N.Inst_get().skipEffect?this.RelShowRewrad():N.Inst_get().RaiseEvent(B.DelayObtain,t.hitIds[0])}RelShowRewrad(){
const t=this.tempStarrySkyReward
N.Inst_get().UpdateSkyInfo(t.skyInfoVo)
const e=new r.Z
let i=!1
for(let s=0;s<=t.hitIds.Length()-1;s++){const n=N.Inst_get().GetSkyResourceDataById(t.hitIds[s]),a=ht.wrapReward(n.andReward.rewards[0])
a.iconType=d.s.REWARD_ICON_TYPE,1==n.type&&(a.showEffect=!0,i=!0),a.iconExtraData[h.S.REWARD_EFF]=n.type,e.Add(a)}const s=new dt
if(s.type=W.StarSky,s.rewardItemDataList=e,i)N.Inst_get().commLotteryBtns=j.btn_ok,s.click2close=!1
else if(N.Inst_get().IsResourceOver()){const t=u.x.Inst().getItemById(11042907)
s.msg_str=t.sys_messsage}q.Inst_get().OpenCommRewardView(s),N.Inst_get().RaiseEvent(B.RewradShowed),this.tempStarrySkyReward=null}HasFinalReward(t){let e=!1
for(let i=0;i<=t.hitIds.Length()-1;i++){1==N.Inst_get().GetSkyResourceDataById(t.hitIds[i]).type&&(e=!0)}return e}SM_StarrySkyGainHandler(t){N.Inst_get().UpdateSkyInfo(t.skyInfoVo)
}SM_StarrySkyInfoHandler(t){N.Inst_get().InitStarResourceInfo(t)}SendResetResource(t){const e=new _.x
e.activityId=t,n.C.Inst.F_SendMsg(e)}SendObtainReward(t,e,i){N.Inst_get().commLotteryBtns=i?bit.bor(j.btn_ok,j.btn_ten):bit.bor(j.btn_ok,j.btn_one)
const s=new I.d
s.activityId=t,s.free=e,s.multiDraw=i,n.C.Inst.F_SendMsg(s)}SendGainReward(t,e){const i=new c.I
i.activityId=t,i.resourceId=e,n.C.Inst.F_SendMsg(i)}OpenStarSkyView(t=null){null==t&&(t=0),N.Inst_get().defaul_tab_idx=t,this.CheckUpdateStarryData()
const e=new a.v
e.isShowMask=!0,e.isDefaultUITween=!0,e.isSelfTween=!0,e.viewClass=jt,o.N.inst.OpenById(l.I.StarSkyTabView,null,null,e)}CloseStarSkyView(){o.N.inst.CloseById(l.I.StarSkyTabView)}
OpenRewardPoolView(){const t=new a.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.viewClass=_t,o.N.inst.OpenById(l.I.SkyRewardPoolView,null,null,t)}CloseRewardPoolView(){o.N.inst.CloseById(l.I.SkyRewardPoolView)}
CheckUpdateStarryData(){if(null!=this.tempStarrySkyReward){const t=this.tempStarrySkyReward
N.Inst_get().UpdateSkyInfo(t.skyInfoVo),this.tempStarrySkyReward=null}}}Jt._inst=null},93061:(t,e,i)=>{i.d(e,{Z:()=>O})
var s=i(17409),n=i(93984),a=i(38836),o=i(86133),l=i(98800),r=i(97461),h=i(98958),d=i(66788),u=i(56937),c=i(18202),_=i(52726),I=i(995),g=i(98885),m=i(85602),C=i(78592),S=i(58158),p=i(97331),A=i(92679),f=i(54130),y=i(51965),T=i(37648),R=i(55492),v=i(75439),w=i(65550),D=i(85942),E=i(19983),L=i(49892),G=i(49655)
class O{constructor(){this._iconTipsPanel=null,this.addHandlesType=null,this.teamHandles=null,this.asuramHandles=null,this.asuramIncludeApplyNotice=!1,this.isAddRoleAddPoint=!0,
this._degf_CallDestory=null,this._degf_IconTipsHandle=null,this._degf_OpenRoleAddAttrsView=null,this._degf_ShowHandler=null,this.addHandlesType=new m.Z,this.teamHandles=new m.Z,
this.asuramHandles=new m.Z,this._degf_CallDestory=()=>this.CallDestory(),this._degf_IconTipsHandle=t=>this.IconTipsHandle(t),
this._degf_OpenRoleAddAttrsView=t=>this.OpenRoleAddAttrsView(t),this._degf_ShowHandler=t=>this.ShowHandler(t),this.registeEvent()}static Inst_get(){
return null==O._Inst&&(O._Inst=new O),O._Inst}registeEvent(){r.i.Inst.AddEventHandler(A.g.InviteInTeam,this._degf_IconTipsHandle)}IconTipsHandle(t){if(null!=this._iconTipsPanel){
const e=t
this._iconTipsPanel.node.SetActive(e)}}OpenIconTipsPanel(){if(null==this._iconTipsPanel||!this._iconTipsPanel.isShow_get()){const t=new u.v
t.layerType=_.F.DefaultUI,t.aniDir=I.K.Down,t.ReLoginOrChangeRoleIsDestroy=!1,(0,s.Yp)(G.o.eIconTipsPanel,t)}}CallDestory(){c.g.DestroyUIObj(this._iconTipsPanel),
this._iconTipsPanel=null}ShowHandler(t){return null}CloseView(){(0,s.sR)(G.o.eIconTipsPanel)}ForceCloseIconTipsForMapJudge(){
null!=this._iconTipsPanel&&this._iconTipsPanel.node.SetActive(!1)}ForceOpenIconTipsForMapJudge(){null!=this._iconTipsPanel&&this._iconTipsPanel.node.SetActive(!0)}
LoginIconTipShow(){if(this.AddHandlesTypeIsContain(2))return
l.Y.Inst.PrimaryRoleInfo_get()}AddHandlesTypeIsContain(t){let e=!1
for(const[i,s]of(0,a.V5)(this.addHandlesType))if(s==t){e=!0
break}return e}AddAttrPointShow(){if(!T.P.Inst_get().IsFunctionOpened(R.x.ROLEADDPOINT)||this.AddHandlesTypeIsContain(1))return
const t=l.Y.Inst.PrimaryRoleInfo_get(),e=v.D.getInstance().getContent("ATTRIBUTE:INFORM").getContent().stringVal,i=g.M.String2Int(e)
t.RemainBasePoint_get()>=i&&t.Level_get()>=p.n.Inst_get().ShowRecommLevel_get()&&this.addHandlesType.Add(1)}ShowAddPointTip(){let t=0
this.isAddRoleAddPoint?t=10430:(this.isAddRoleAddPoint=!0,t=10429)
const e=new m.Z
e.Add(g.M.IntToString(l.Y.Inst.PrimaryRoleInfo_get().RemainBasePoint_get()))
const i=new D.N
i.showText=h.V.Inst().getStr(t,n.h.eLangResource,e),i.okText=h.V.Inst().getStr(10431,n.h.eLangResource),i.tipstype=2,i.btnColorType=2,i.okhandler=this._degf_OpenRoleAddAttrsView,
w.y.inst.OpenCommonMessageTips(i)}OpenAddPoints(){
1==this.addHandlesType[this.addHandlesType.Count()-1]?this.ShowAddPointTip():2==this.addHandlesType[this.addHandlesType.Count()-1]&&this.OpenTalentView(),
this.addHandlesType.RemoveAt(this.addHandlesType.Count()-1)}RemoveAddAttrsIcon(){if(0!=this.addHandlesType.Count()){let t=-1,e=0
for(;e<this.addHandlesType.Count();){if(1==this.addHandlesType[e]){t=e
break}e+=1}-1!=t&&this.addHandlesType.RemoveAt(t)}}OpenAsuram(){this.asuramHandles[0](),this.asuramHandles.RemoveAt(0),
E.S.Inst_get().UpdateCount(L.K.ICON_TIPS_ASURAM,this.asuramHandles.Count()),0==this.asuramHandles.Count()&&E.S.Inst_get().RemoveIcon(L.K.ICON_TIPS_ASURAM)}UpdateTeamIconTips(){
const t=l.Y.Inst.PrimaryRoleInfo_get();(0==t.teamId_get().ToNum()||0!=t.teamId_get().ToNum())&&(this.teamHandles.Clear(),E.S.Inst_get().RemoveIcon(L.K.ICON_TIPS_TEAM))}
OpenRoleAddAttrsView(t){S.U.Inst_get().topViewType=f.Q.Normal,S.U.Inst_get().characterViewType=y.f.AddAttrs,C.l.Inst().Open()}OpenTalentView(){d.Y.Log((0,o.T)("打开天赋面板"),!0)}}
O._Inst=null},19983:(t,e,i)=>{i.d(e,{S:()=>g})
var s=i(86133),n=i(54967),a=i(5924),o=i(95721),l=i(85602),r=i(21554),h=i(70850),d=i(86770),u=i(65550),c=i(85942),_=i(93061),I=i(49892)
class g extends n.g{constructor(){super(),this.totalList=null,this.leftList=null,this.objList=null,this.objList2=null,this._isHaveEnterScene=!1,this._sortValue=1,
this.noticeIntervalId=-1,this.delayEquipId=o.o.ZERO,this.delayType=0,this._degf_CallNoticeIconUpdate=null,this._degf_SortFun=null,this._degf_UpdateAction=null,
this._degf_WearDelayEquip=null,this._degf_CheckDelayEquip=null,this.totalList=new l.Z,this.leftList=new l.Z,this.objList=new l.Z,this.objList2=new l.Z,
this._degf_CallNoticeIconUpdate=()=>this.CallNoticeIconUpdate(),this._degf_SortFun=(t,e)=>this.SortFun(t,e),this._degf_UpdateAction=()=>this.UpdateAction(),
this._degf_WearDelayEquip=t=>this.WearDelayEquip(t),this._degf_CheckDelayEquip=t=>this.CheckDelayEquip(t)}static Inst_get(){return null==g._Inst&&(g._Inst=new g),g._Inst}
OnEnterScene(){this._isHaveEnterScene=!0,this.NoticeIconUpdate()}AddIcon(t){let e=!1
const i=this.GetLeftVO(t.type)
if(null!=i)(t=i).count+=1
else{let i=0
for(;i<this.totalList.Count();){if(this.totalList[i].type==t.type){e=!0,this.totalList[i].count=this.totalList[i].count+1,this.totalList[i].sortValue=(()=>{const t=this._sortValue
return this._sortValue+=1,t})()
break}i+=1}}e||(t.sortValue=(()=>{const t=this._sortValue
return this._sortValue+=1,t})(),this.totalList.Add(t)),this.totalList.Sort(this._degf_SortFun),this.totalList.Count()>g.MAX_SHOW_COUNT&&(t=this.totalList[g.MAX_SHOW_COUNT],
this.leftList.Add(t),this.totalList.RemoveAt(g.MAX_SHOW_COUNT)),a.C.Inst_get().ClearInterval(this.noticeIntervalId),
this.noticeIntervalId=a.C.Inst_get().SetInterval(this._degf_CallNoticeIconUpdate,500,1)}CallNoticeIconUpdate(){this.NoticeIconUpdate()}SortFun(t,e){
return t.sortValue>e.sortValue?-1:t.sortValue<e.sortValue?1:0}RemoveIcon(t){let e=!1,i=this.totalList.Count()-1
for(;i>=0;){if(this.totalList[i].type==t){this.totalList.RemoveAt(i),e=!0
break}i-=1}if(this.GetLeftVO(t),this.totalList.Count()<g.MAX_SHOW_COUNT&&this.leftList.Count()>0){const t=this.leftList[0]
this.leftList.RemoveAt(0),this.totalList.Add(t),e=!0}e&&this.NoticeIconUpdate()}GetEquipDelayHandle(){const t=new c.N
t.titleText=(0,s.T)("装备提示"),t.tipstype=2
let e=""
0==this.delayType?(e=(0,s.T)("你有新装备可以穿戴了！\n是否立即加点进行穿戴？"),t.showText=(0,s.T)("你有新装备可以穿戴了！\n是否立即加点进行穿戴？"),t.okText=(0,s.T)("立即穿戴"),t.cancelText=(0,s.T)("暂时不穿"),
t.okhandler=this._degf_WearDelayEquip):(t.showText=(0,s.T)("你获得了一件好装备，\n是否现在查看一下？"),t.okText=(0,s.T)("立即查看"),t.cancelText=(0,s.T)("暂时不看"),t.okhandler=this._degf_CheckDelayEquip),
u.y.inst.OpenCommonMessageTips(t)}OnBagUpdate(){this.delayEquipId.Equal(o.o.ZERO)||h.g.Inst_get().GetItemById(this.delayEquipId)||(g.Inst_get().RemoveIcon(I.K.ICON_TIPS_GETEQUIP),
this.delayEquipId=o.o.ZERO)}CheckDelayEquip(t){h.g.Inst_get().viewBagType=d.D.equipTab,h.g.Inst_get().isneedreset=!1,h.g.Inst_get().isneedtips=!0,
r.J.Inst_get().openOrClose(d.D.bagTab),g.Inst_get().RemoveIcon(I.K.ICON_TIPS_GETEQUIP),this.delayEquipId=o.o.ZERO}WearDelayEquip(t){h.g.Inst_get().viewBagType=d.D.equipTab,
h.g.Inst_get().isneedreset=!1,h.g.Inst_get().isneedtips=!0,r.J.Inst_get().openOrClose(d.D.bagTab),g.Inst_get().RemoveIcon(I.K.ICON_TIPS_GETEQUIP),this.delayEquipId=o.o.ZERO}
RemoveIconByVo(t){let e=!1,i=this.totalList.Count()-1
for(;i>=0;){if(this.totalList[i]==t){this.totalList.RemoveAt(i),e=!0
break}i-=1}if(this.totalList.Count()<g.MAX_SHOW_COUNT&&this.leftList.Count()>0){const t=this.leftList[0]
this.leftList.RemoveAt(0),this.totalList.Add(t),e=!0}e&&this.NoticeIconUpdate()}GetLeftVO(t){let e=null,i=this.leftList.Count()-1
for(;i>=0;){if(this.leftList[i].type==t){e=this.leftList[i],this.leftList.RemoveAt(i)
break}i-=1}return e}UpdateCount(t,e){let i=this.totalList.Count()-1
for(;i>=0;){if(this.totalList[i].type==t){this.totalList[i].count=e,this.NoticeIconUpdate()
break}i-=1}}hasIcon(t){let e=this.totalList.Count()-1
for(;e>=0;){if(this.totalList[e].type==t)return!0
e-=1}return!1}NoticeIconUpdate(){if(!this._isHaveEnterScene)return
this.objList.Clear(),this.objList2.Clear()
let t=0
for(;t<6&&t<this.totalList.Count();)this.objList.Add(this.totalList[t]),t+=1
this.totalList.Count()>0?_.Z.Inst_get().OpenIconTipsPanel():_.Z.Inst_get().CloseView(),a.C.Inst_get().CallLater(this._degf_UpdateAction)}UpdateAction(){
this.RaiseEvent(g.UPDATE_ICON_TIPS_VIEW)}GetobjListByLim(){const t=new l.Z
if(null!=this.objList)for(let e=0;e<=4;e++)null!=this.objList[e]&&t.Add(this.objList[e])
return t}GetobjList2ByLim(){const t=new l.Z
if(null!=this.objList2)for(let e=0;e<=2;e++)null!=this.objList2[e]&&t.Add(this.objList2[e])
return t}ResetModel(){this.totalList.Clear(),this.leftList.Clear(),this.objList.Clear(),this.objList2.Clear(),this._isHaveEnterScene=!1,this._sortValue=1,
_.Z.Inst_get().asuramHandles.Clear(),_.Z.Inst_get().teamHandles.Clear(),_.Z.Inst_get().asuramIncludeApplyNotice=!1,_.Z.Inst_get().CloseView()}}
g.UPDATE_ICON_TIPS_VIEW="UPDATE_ICON_TIPS_VIEW",g.MAX_SHOW_COUNT=5,g._Inst=null},49892:(t,e,i)=>{i.d(e,{K:()=>N})
var s=i(77546),n=i(86133),a=i(31222),o=i(67585),l=i(80486),r=i(84528),h=i(77796),d=i(84229),u=i(93353),c=i(87851),_=i(21554),I=i(70850),g=i(80062),m=i(78592),C=i(26753),S=i(83171),p=i(39879),A=i(21987),f=i(50077),y=i(49831),T=i(11740),R=i(94998),v=i(57553),w=i(845),D=i(99130),E=i(62405),L=i(65550),G=i(85942),O=i(78922),b=i(93061),B=i(19983)
class N{static clickHandler(t){const e=t.type
if(s.s.Info(`小圆点点击:   ${t.type}`),"ICON_TIPS_BAG_EXTEND"==e)g.a.inst.openOrClose()
else if(e==N.ICON_TIPS_MAIL)C.d.Inst_get().controller.OpenMainPanel(!0,null,null)
else if(e==N.ICON_TIPS_CHAT_PRIVATE)C.d.Inst_get().controller.PrivateChatDefault()
else if("ICON_TIPS_ASURAM"==e)b.Z.Inst_get().OpenAsuram()
else if("ICON_TIPS_TITLE_EXPIRE"==e)m.l.Inst().ExpireTipHandle()
else if("ICON_TIPS_MARKET_AUCTIONGOUNDING"==e)R.W.GetInst().BidBeTipHandler()
else if("ICON_TIPS_ADD_ATTRS"==e)b.Z.Inst_get().OpenAddPoints()
else if(e==N.ICON_TIPS_FRIEND_RECOMMEND)f.C.Inst_get().RemoveNoticeIcon(),A.N.Inst_get().OpenReqNoticeFriend()
else if(e==N.ICON_TIPS_TEMP_NOTICE)S.d.Inst_get().OpenNotice()
else if(e==N.ICON_TIPS_PERFORMANCE_CHANGE)B.S.Inst_get().RemoveIcon(N.ICON_TIPS_PERFORMANCE_CHANGE)
else if(e==N.ICON_TIPS_GETEQUIP)B.S.Inst_get().GetEquipDelayHandle()
else if(e==N.ICON_TIPS_SPECIAL_TITLE)m.l.Inst().ClickSpecialIcon()
else if(e==N.ICON_TIPS_EQUIP_NOEFFECT){let t=""
const[e,i,s,a]=I.g.Inst_get().GetLastNoEffectEquip()
if(e){t=e.GetEquipmentByColumnAndPos(i,s).GetItemRes().name}const o=new G.N
o.showText=(0,n.T)(`[443c38]属性点不足，[962424]${t}[-]已失效，无法获得该装备属性加成\n是否前往查看？[-]`),o.tipstype=2,o.okhandler=N.OpenBagPanelHandler,L.y.inst.OpenCommonMessageTips(o)
}else if(e==N.ICON_TIPS_ASSIST)o.M.Inst_get().OpenAssistRecieveThankPanel()
else if(e==N.TRADINGMARKET_NOTICE)O.f.Inst_Get().OpenNotice()
else if(e==N.SKILL_INVALID)D.x.inst.OpenNotice()
else if(e==N.ARENA_ICON_NOTICE)u.g.Inst_get().OpenArenaNotice()
else if(e==N.ALLIANCE_THANK){const t=h.v.Inst_get().GeAsuramAssistGitfFirstBox()
t&&(h.v.Inst_get().curGiftData=t,o.M.Inst_get().OpenAssistThankPanel())
}else e==N.SPACE_ORIGIN_NOTICE?E.j.Inst_get().OpenNoticeView():e==N.FUCARD_EXCHANGE&&(T.K.Inst_get().ClearExchangingTable(),T.K.Inst_get().waitingToShowPopup=!0,
y.Q.Inst_get().ReqFiveBlessInfo())
return""}OnGodBlessHandler(t){m.l.Inst().openGodBlessView=!0,m.l.Inst().Open()}OnAsuramWarContinusWin(t){d.Q.Inst_get().defaultMainTabIndex=c.t.ACTIVITY,
d.Q.Inst_get().activityViewType=r.z.SIEGE,l.K.Inst().Open(),B.S.Inst_get().RemoveIcon(N.ASURAMWAR_CONTINUS_WIN)}OnAsuramWarEndContinusWin(t){
d.Q.Inst_get().defaultMainTabIndex=c.t.ACTIVITY,d.Q.Inst_get().activityViewType=r.z.SIEGE,l.K.Inst().Open(),B.S.Inst_get().RemoveIcon(N.ASURAMWAR_END_CONTINUS_WIN)}
OpenUIByShortCutIDStr(t){const e=p.L.Inst().getItemById(t)
null!=e&&a.N.inst.OpenUIByShortCutIDStr(e.openUI),B.S.Inst_get().RemoveIcon(N.NOITICE_FUN_CUILIAN)}static OpenBagPanelHandler(t){
const[e,i,s,n]=I.g.Inst_get().GetLastNoEffectEquip()
e?_.J.Inst_get().OpenEquipTipsInBagByRInfo(n):_.J.Inst_get().Open()}OpenSystemSetting(t){w.g.Inst_get().ViewType=1,w.g.Inst_get().scrollToRecyle=!0,v._.Inst.OpenMainPanel(!1)}
static getSpriteName(t){let e=N._getSpriteName(t)
return""==e?"":"atlas/mainui/"+e}static _getSpriteName(t){
return"ICON_TIPS_BAG_EXTEND"==t?"rymainui_bt_0018":"ICON_TIPS_LOSE_TRIG"==t?"rymainui_bt_0011":t==N.ICON_TIPS_MAIL?"rymainui_bt_0010":t==N.ICON_TIPS_CHAT_PRIVATE?"rymainui_bt_0011":"ICON_TIPS_ASURAM"==t?"rymainui_bt_0031":"ICON_TIPS_RETRIEVE"==t||"ICON_TIPS_RED_END"==t||"ICON_TIPS_TITLE_EXPIRE"==t||"ICON_TIPS_MARKET_AUCTIONGOUNDING"==t||"ICON_TIPS_SIEGE_MATCHDATA"==t?"rymainui_bt_0011":"ICON_TIPS_ADD_ATTRS"==t?"rymainui_bt_0012":"ICON_TIPS_ACHIEVE_REWARD"==t?"rymainui_bt_0011":"ICON_TIPS_FRIEND_RECOMMEND"==t?"rymainui_bt_0009":t==N.ICON_TIPS_TEMP_NOTICE||t==N.ICON_TIPS_AGAINSTQUEST_EXTRAREWARDTIP||t==N.ICON_TIPS_FORCE_UNLOCK_SUCCESS||t==N.ICON_TIPS_PERFORMANCE_CHANGE||t==N.ICON_TIPS_RECYLE||t==N.ICON_TIPS_RECYLE2||t==N.ICON_TIPS_RECYLE3||t==N.ICON_TIPS_RECYLE4||t==N.ICON_TIPS_RECYLE5||t==N.ICON_TIPS_GETEQUIP||t==N.ICON_TIPS_GETSTRONG||t==N.ICON_TIPS_TRANFER_GETRESETITEM||t==N.ICON_TIPS_SPECIAL_TITLE?"rymainui_bt_0011":t==N.ICON_TIPS_EQUIP_NOEFFECT?"rymainui_bt_0031":t==N.ICON_TIPS_RED_PACKET||t==N.ICON_TIPS_GUARD_LOSE?"rymainui_bt_0011":t==N.SKILL_INVALID?"rymainui_bt_0031":t==N.ICON_TIPS_AUTO_SELL_STAR_EXCELLENT_EQUIP||t==N.ICON_TIPS_AUTO_SELL_NORMAL_EXCELLENT_EQUIP||t==N.ICON_TIPS_AUTO_SELL_NORMAL_ITEM_EQUIP||t==N.ICON_TIPS_MINE_ASSIST||t==N.ICON_TIPS_ASSIST||t==N.BUSINESS_SOCIETY_BIDDING_OVER||t==N.GODBLESS_FULL_EXP||t==N.GODBLESS_OVER_EXP||t==N.ASURAMWAR_CONTINUS_WIN||t==N.ASURAMWAR_END_CONTINUS_WIN||t==N.NOITICE_FUN_CUILIAN?"rymainui_bt_0011":t==N.TRADINGMARKET_NOTICE?"rymainui_bt_0022":t==N.ARENA_ICON_NOTICE||t==N.ALLIANCE_THANK||t==N.SPACE_ORIGIN_NOTICE||t==N.FUCARD_EXCHANGE?"rymainui_bt_0031":""
}}N.ICON_TIPS_TEAM="ICON_TIPS_TEAM",N.ICON_TIPS_BAG_EXTEND="ICON_TIPS_BAG_EXTEND",N.ICON_TIPS_LOSE_TRIG="ICON_TIPS_LOSE_TRIG",N.ICON_TIPS_MAIL="ICON_TIPS_MAIL",
N.ICON_TIPS_ASURAM="ICON_TIPS_ASURAM",N.ICON_TIPS_RETRIEVE="ICON_TIPS_RETRIEVE",N.ICON_TIPS_TITLE_EXPIRE="ICON_TIPS_TITLE_EXPIRE",
N.ICON_TIPS_MARKET_AUCTIONGOUNDING="ICON_TIPS_MARKET_AUCTIONGOUNDING",N.ICON_TIPS_SIEGE_MATCHDATA="ICON_TIPS_SIEGE_MATCHDATA",N.ICON_TIPS_RED_END="ICON_TIPS_RED_END",
N.ICON_TIPS_ADD_ATTRS="ICON_TIPS_ADD_ATTRS",N.ICON_TIPS_ACHIEVE_REWARD="ICON_TIPS_ACHIEVE_REWARD",N.ICON_TIPS_FRIEND_RECOMMEND="ICON_TIPS_FRIEND_RECOMMEND",
N.ICON_TIPS_TEMP_NOTICE="ICON_TIPS_TEMP_NOTICE",N.ICON_TIPS_AGAINSTQUEST_EXTRAREWARDTIP="ICON_TIPS_AGAINSTQUEST_EXTRAREWARDTIP",
N.ICON_TIPS_FORCE_UNLOCK_SUCCESS="ICON_TIPS_FORCE_UNLOCK_SUCCESS",N.ICON_TIPS_PERFORMANCE_CHANGE="ICON_TIPS_PERFORMANCE_CHANGE",N.ICON_TIPS_SPECIAL_TITLE="ICON_TIPS_SPECIAL_TITLE",
N.ICON_TIPS_RECYLE="ICON_TIPS_RECYLE",N.ICON_TIPS_RECYLE2="ICON_TIPS_RECYLE2",N.ICON_TIPS_RECYLE3="ICON_TIPS_RECYLE3",N.ICON_TIPS_RECYLE4="ICON_TIPS_RECYLE4",
N.ICON_TIPS_RECYLE5="ICON_TIPS_RECYLE5",N.ICON_TIPS_GETEQUIP="ICON_TIPS_GETEQUIP",N.ICON_TIPS_GETSTRONG="ICON_TIPS_GETSTRONG",
N.ICON_TIPS_TRANFER_GETRESETITEM="ICON_TIPS_TRANFER_GETRESETITEM",N.ICON_TIPS_EQUIP_NOEFFECT="ICON_TIPS_EQUIP_NOEFFECT",N.ICON_TIPS_RED_PACKET="ICON_TIPS_RED_PACKET",
N.ICON_TIPS_AUTO_SELL_STAR_EXCELLENT_EQUIP="ICON_TIPS_AUTO_SELL_STAR_EXCELLENT_EQUIP",N.ICON_TIPS_AUTO_SELL_NORMAL_EXCELLENT_EQUIP="ICON_TIPS_AUTO_SELL_NORMAL_EXCELLENT_EQUIP",
N.ICON_TIPS_AUTO_SELL_NORMAL_ITEM_EQUIP="ICON_TIPS_AUTO_SELL_NORMAL_ITEM_EQUIP",N.ICON_TIPS_MINE_ASSIST="ICON_TIPS_MINE_ASSIST",N.ICON_TIPS_ASSIST="ICON_TIPS_ASSIST",
N.SKILL_INVALID="SKILL_INVALID",N.BUSINESS_SOCIETY_BIDDING_OVER="BUSINESS_SOCIETY_BIDDING_OVER",N.GODBLESS_FULL_EXP="GODBLESS_FULL_EXP",N.GODBLESS_OVER_EXP="GODBLESS_OVER_EXP",
N.ASURAMWAR_CONTINUS_WIN="ASURAMWAR_CONTINUS_WIN",N.ASURAMWAR_END_CONTINUS_WIN="ASURAMWAR_END_CONTINUS_WIN",N.FACADE_HEAD_EXPIRE="FACADE_HEAD_EXPIRE",
N.FACADE_CHAT_EXPIRE="FACADE_CHAT_EXPIRE",N.NOITICE_FUN_CUILIAN="NOITICE_FUN_CUILIAN",N.ICON_TIPS_CHAT_PRIVATE="CHAT_PRIVATE",N.TRADINGMARKET_NOTICE="TRADINGMARKET_NOTICE",
N.ARENA_ICON_NOTICE="ARENA_ICON_NOTICE",N.ALLIANCE_THANK="ALLIANCE_THANK",N.SPACE_ORIGIN_NOTICE="SPACE_ORIGIN_NOTICE",N.FUCARD_EXCHANGE="FUCARD_EXCHANGE",
N.ICON_TIPS_GUARD_LOSE=null},75961:(t,e,i)=>{i.d(e,{U:()=>n})
var s=i(49892)
class n{constructor(t){this.name="",this.spritename="",this.count=1,this.sortValue=1,this.param=null,this.type=null,this.type=t,this.spritename=s.K.getSpriteName(t)}}},
17749:(t,e,i)=>{
var s,n=i(6847),a=i(83908),o=i(46282),l=i(98800),r=i(97960),h=i(97461),d=i(13687),u=i(49484),c=i(60130),_=i(92679),I=i(93061),g=i(19983),m=i(49655),C=i(57834),S=i(85682),p=i(87923),A=i(68637),f=i(49892)
class y extends((0,a.yk)()){constructor(...t){super(...t),this._vo=null,this._degf_BagUpdateHandle=null,this._degf_PlayAnime=null,this._degf_clickHandler=null,this.guideId=null}
_initBinder(){super._initBinder(),this._degf_BagUpdateHandle=t=>this.BagUpdateHandle(t),this._degf_PlayAnime=t=>this.PlayAnime(t),
this._degf_clickHandler=(t,e)=>this.clickHandler(t,e)}InitView(){super.InitView(),this.pre_eff_smalliconlight.SetActive(!1)}SetData(t){this._vo=t,
this._vo.count>1?(this.countlabel.textSet(`${this._vo.count}`),this.number_bg.node.SetActive(!0)):(this.countlabel.textSet(""),this.number_bg.node.SetActive(!1)),
this._vo.type==f.K.ICON_TIPS_GETSTRONG&&(this.countlabel.textSet(""),this.number_bg.node.SetActive(!1)),
null!=this._vo.spritename&&""!=this._vo.spritename&&(this.pci.skin=this._vo.spritename),null!=this._vo.name&&""!=this._vo.name&&this.namelabel.textSet(this._vo.name),
C.i.Get(this.node).RegistonClick(this._degf_clickHandler),h.i.Inst.AddEventHandler(_.g.BAG_UPDATE,this._degf_BagUpdateHandle),
h.i.Inst.AddEventHandler(_.g.ICON_ANIME_RESET,this._degf_PlayAnime),this.RegGuide()}GetGuideId(){if(null!=this._vo){
if(this._vo.type==f.K.ICON_TIPS_MAIL)return S.D.UI_MAIN_MAIL_VIEW
if(this._vo.type==f.K.ICON_TIPS_BAG_EXTEND)return S.D.UI_MAIN_BAG_EX}return null}RegGuide(){this.UnRegGuide(),this.guideId=this.GetGuideId(),
null!=this.guideId&&A.c.Inst.RegGameObject(this.guideId,this.node)}UnRegGuide(){null!=this.guideId&&(A.c.Inst.UnRegGameObject(this.guideId),this.guideId=null)}CheckGuide(){
null!=this.guideId&&p.l.CheckBtnClickTrigger(this.guideId)}clickHandler(t,e){this.CheckGuide(),f.K.clickHandler(this._vo)}BagUpdateHandle(t){g.S.Inst_get().OnBagUpdate()}
PlayAnime(t){}Clear(){this.UnRegGuide(),C.i.Get(this.node).RemoveonClick(this._degf_clickHandler),h.i.Inst.RemoveEventHandler(_.g.BAG_UPDATE,this._degf_BagUpdateHandle),
h.i.Inst.RemoveEventHandler(_.g.ICON_ANIME_RESET,this._degf_PlayAnime),this._vo=null}Destroy(){}}(0,
n.s_)(m.o.eIconTipsPanel,o.Z.ui_icontips_panel).waitPrefab(o.Z.ui_icontips_grid).waitPrefab(o.Z.ui_icontips_grid2).layerNav().register()(s=class extends((0,a.Ri)()){
constructor(...t){super(...t),this._degf_OnItemRefreshFun=null,this._degf_PlayAnimeTogether=null,this._degf_UpdateTeamIconTip=null,this._degf_UpdateView=null}_initBinder(){
super._initBinder(),this._degf_OnItemRefreshFun=t=>{},this._degf_PlayAnimeTogether=()=>this.PlayAnimeTogether(),this._degf_UpdateTeamIconTip=t=>this.UpdateTeamIconTip(t),
this._degf_UpdateView=t=>this.UpdateView(t)}InitView(){super.InitView(),g.S.Inst_get().AddEventHandler(g.S.UPDATE_ICON_TIPS_VIEW,this._degf_UpdateView),
this.icongrid.SetInitInfo("ui_icontips_grid",null,y),this.icongrid.data_set(g.S.Inst_get().GetobjListByLim()),this.icongrid.OnReposition_set(this._degf_PlayAnimeTogether),
this.icongrid2.SetInitInfo("ui_icontips_grid2",null,y),this._OnUpdateAnchor()}OnAddToScene(){this._OnUpdateAnchor(),this.UpdateView(null),
l.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(r.A.TeamUpdate,this._degf_UpdateTeamIconTip),
this.m_handlerMgr.AddEventMgr(_.g.ALLIANCE_BASEINFO_UPDATE,this.CreateDelegate(this.UpdateView)),
this.m_handlerMgr.AddEventMgr(_.g.UPDATE_ANCHORS,this.CreateDelegate(this._OnUpdateAnchor)),u.p.Inst_get().EnterMap(d.b.Inst.currentMapId_get())}_OnUpdateAnchor(){
c.O.SetAnchorPos(this.anchor,!0,!0,-2,!1)}PlayAnimeTogether(){h.i.Inst.RaiseEvent(_.g.ICON_ANIME_RESET)}UpdateView(t){
l.Y.Inst.PrimaryRoleInfo_get().isHaveAlliance_get()?this.offset.transform.SetLocalPositionXYZ(210,0,0):this.offset.transform.SetLocalPositionXYZ(35,0,0),
this.icongrid.data_set(g.S.Inst_get().GetobjListByLim()),this.icongrid2.data_set(g.S.Inst_get().GetobjList2ByLim())}UpdateTeamIconTip(t){I.Z.Inst_get().UpdateTeamIconTips()}
Clear(){l.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(r.A.TeamUpdate,this._degf_UpdateTeamIconTip),
g.S.Inst_get().RemoveEventHandler(g.S.UPDATE_ICON_TIPS_VIEW,this._degf_UpdateView)}GetIconTipPosition(){return this.icongrid.node.transform.GetPosition()}Destroy(){
this.icongrid.destroy(),this.icongrid2.destroy()}})},25010:(t,e,i)=>{i.d(e,{G:()=>r})
var s=i(56937),n=i(31222),a=i(5494),o=i(52726),l=i(79534)
class r{constructor(){this._degf_CallComplete=null,this._degf_CallDestory=null,this.viewPos=null,this.view=null,this.res=null,this.fatherTip=null,this.SpModelId=null,
this._degf_CallComplete=t=>this.CallComplete(t),this._degf_CallDestory=t=>{this.CallDestroy(t)},this.viewPos=l.P.zero_get()}static Inst_get(){return null==r.inst&&(r.inst=new r),
r.inst}SetPosition(t){this.viewPos=t,this.IsOpen()&&this.view.SetPosition()}OpenByParam(t=null,e=null,i=null){this.res=t,this.fatherTip=e,this.SpModelId=i,this.OpenView()}
ResetPanelParam(){this.viewPos=l.P.zero_get()}OpenView(){const t=new s.v
t.layerType=o.F.Tip,n.N.inst.OpenById(a.I.ItemModelTipView,this._degf_CallComplete,this._degf_CallDestory,t)}IsOpen(){if(null!=this.view&&this.view.isShow_get())return!0}
CloseView(){n.N.inst.CloseById(a.I.ItemModelTipView)}CallComplete(t){}CallDestroy(){}}r.inst=null},11654:(t,e,i)=>{
var s,n,a=i(6847),o=i(83908),l=i(46282),r=i(32697),h=i(20583),d=i(50838),u=i(31546),c=i(97461),_=i(61911),I=i(52212),g=i(59918),m=i(69015),C=i(92679),S=i(20758),p=i(42534),A=i(25010),f=i(5494)
;(0,a.s_)(f.I.ItemModelTipView,l.Z.ui_bag_itemmodeltippanel).register()(((n=class extends((0,o.pA)(_.f)()){constructor(...t){super(...t),this.res=null,this.index=null,
this.fatherTipRoot=null,this.displayUIAvatarModel=null}InitView(){this.displayUIAvatarModel=new d.o,this.displayUIAvatarModel.SetTarget(this.rolerotategrid,!0),
this.displayUIAvatarModel.SetDir(5)}AddLis(){c.i.Inst.AddEventHandler(C.g.CLICK_CLOSEIP,this.CreateDelegate(this.TipCloseHandler))}RemoveLis(){
c.i.Inst.RemoveEventHandler(C.g.CLICK_CLOSEIP,this.CreateDelegate(this.TipCloseHandler))}OnAddToScene(){this.res=A.G.Inst_get().res,this.index=this.AddToLayout(),
this.nameTxt.textSet("模型预览"),this.SetModel(),this.AddLis(),this.AddSound(),this.UpdateFightBattle()}AddToLayout(){const t=A.G.Inst_get().fatherTip,[e,i]=[-167,250],[s,n]=[334,500]
return m.g.Inst_get().AddTipByParam(this,t,m.g.HorizontalAlign.Left,null,new I.F(e,i),new I.F(s,n))}TipCloseHandler(){A.G.Inst_get().CloseView()}AddSound(){}UpdateFightBattle(){
const t=this.res.fightBattle
0!=t?(this.bottom.SetActive(!0),this.bg.heightSet(500),this.battlescorevalue.textSet(t)):(this.bg.heightSet(440),this.bottom.SetActive(!1))}SetPosition(){
const t=A.G.Inst_get().viewPos
null!=t&&this.offset.transform.SetLocalPosition(t)}SetModel(){let t=this.res.modelId
null!=A.G.Inst_get().SpModelId&&(t=A.G.Inst_get().SpModelId)
var e=r.v.monster
let i=S.F.Inst.GenGetCfgById(t).ResName
if(p.f.Inst().getItemById(this.res.id).equipType===g.R.WINGS)this.rolerotategrid.wgid=i,this.rolerotategrid.dir=4,this.rolerotategrid.act="act14",this.rolerotategrid.node.y-=140,
e=r.v.wing
const s=new u.O
s._displayID=t,this.displayUIAvatarModel.SetScale(2,2),this.displayUIAvatarModel=h.x.inst.SetUIAvatarData(s,e,this.displayUIAvatarModel)}Clear(){A.G.Inst_get().SpModelId=null,
null!=this.index&&(m.g.Inst_get().RemoveByTip(),this.index=null),super.Clear(),this.RemoveLis()}Destroy(){super.Destroy()}}).STAGE_ID=128,s=n))},33828:(t,e,i)=>{i.d(e,{Y:()=>d})
var s=i(52726),n=i(26753),a=i(74045),o=i(39879),l=i(49067),r=i(31896),h=i(39043)
class d{constructor(){this._degf_OkHandler=null,this._degf_OkHandler=t=>this.OkHandler(t)}static Inst_get(){return null==d.inst&&(d.inst=new d),d.inst}Open(){
this.OpenTip(this._degf_OkHandler)}OpenTip(t){const e="RECHARGE:NO_DIAMOND"
if(h.V.Inst_get().GetData(h.V.Inst_get().GetRolePrefix()+e))t(null)
else{o.L.Inst().getItemById(e)
const i=new l.B
i.infoId=e,i.confirmHandle=t,i.isShowMask=!1,i.layer=s.F.Tip,a.t.Inst().Open(i)}}OkHandler(t){r.t.inst.OpenPanel(),n.d.Inst_get().controller.CloseHornPanel(),a.t.Inst().Close()}}
d.inst=null},47016:(t,e,i)=>{i.d(e,{W:()=>s})
var s={MALL:1,BOSS:2,FIRST_CHARGE:149,SUPER_HANG:122}},26348:(t,e,i)=>{i.d(e,{Z:()=>f})
var s,n,a,o=i(42292),l=i(38836),r=i(86133),h=i(98800),d=i(68662),u=i(62370),c=i(31222),_=i(98885),I=i(85602),g=i(38962),m=i(44518),C=i(6453),S=i(14440),p=i(87923),A=i(37648)
let f=(0,o.gK)("AccessCfgManager")((a=class t{constructor(){this.accessMap=null,this.accessMap=new g.X}static Inst(){return null==t._inst&&(t._inst=new t),t._inst}getItemById(t){
return m.F.ins.GetAccessById(t)}SortAccessFunc(e,i){const s=t.Inst().IsFunOpenByLevel(e)
if(s!=t.Inst().IsFunOpenByLevel(i))return s?1:-1
const n=t.Inst().getItemById(e),a=t.Inst().getItemById(i)
return n.rank!=a.rank?a.rank-n.rank:n.id-a.id}GetParamsListById(t){const e=new I.Z
let i=this.getItemById(t).additionParams
if(i=_.M.Replace(i,_.M.s_LEFT_M_K_CHAR_REPLACE,""),i=_.M.Replace(i,_.M.s_RIGHT_M_K_CHAR_REPLACE,""),""!=i){const t=_.M.Split(i,_.M.s_SPAN_CHAR_DOT)
for(const[i,s]of(0,l.V5)(t)){const t=_.M.String2Int(s)
e.Add(t)}}return e}IsFunOpen(t){return C.R.ins.CheckAccessCondition(t)}GetActivityState(e){const i=this.getItemById(e),s=S.J.Inst_get().getActivityTimeState(i.activityID)
if(null!=s){if(!s.m_end)return 0==s.startTime.ToNum()?t.statehasnext:t.statedoing
return d.D.serverMSTime_get()<s.startTime.ToNum()?t.statehasnext:t.statenonext}return 0}GetActivityOpenDes(t){
const e=this.getItemById(t),i=S.J.Inst_get().getActivityTimeState(e.activityID)
if(null!=i){if(!i.m_end)return 0==i.startTime.ToNum()?(0,r.T)("活动未开始，敬请期待"):(0,r.T)("活动进行中")
return d.D.serverMSTime_get()<i.startTime.ToNum()?(0,r.T)("下次")+(e.name+((0,r.T)("将在")+(p.l.GetDateTime4(i.startTime.ToNum())+(0,r.T)("开始")))):(0,r.T)("活动已错过")}return""}
IsFunOpenByLevelNoOpen(t){const e=this.getItemById(t)
if(null!=e&&""!=e.showLevel&&0==e.type3){
const t=h.Y.Inst.PrimaryRoleInfo_get().Level_get(),i=_.M.Split(e.showLevel,u.o.s_Arr_UNDER_CHAR_DOT),s=_.M.String2Int(i[0]),n=_.M.String2Int(i[1])
return t>=s&&t<=n}return!1}IsFunOpenByLevel(e){const i=this.getItemById(e)
if(I.Z.IndexOf(t.defaultOpenTypeList,i.type)>=0)return!1
if(null!=i&&""!=i.showLevel&&0==i.type3){
const t=h.Y.Inst.PrimaryRoleInfo_get().Level_get(),e=_.M.Split(i.showLevel,u.o.s_Arr_UNDER_CHAR_DOT),s=_.M.String2Int(e[0]),n=_.M.String2Int(e[1])
return!A.P.Inst_get().IsFuncOrActivityOpened(i.type)&&t>=s&&t<=n}return!1}OpenAccessUI(e){if(!p.l.IsEmptyStr(e.ui)&&"0"!=e.ui){const i=t.Inst().GetParamsListById(e.id)
return i.Count()>1?c.N.inst.OpenUIByStrIdWithParam(e.ui,i):1==i.Count()?c.N.inst.OpenUIByStrIdWithParam(e.ui,i[0]):c.N.inst.OpenUIByStrIdWithParam(e.ui)}return!1}
_degf_SortAccessFunc(){return t.SortAccessFunc(param0,param1)}},a.statenonext=1,a.statehasnext=2,a.statedoing=3,a._inst=null,a.defaultOpenTypeList=new I.Z([666,1e4]),y=n=a,
T="Inst",R=[o.Vx],v=Object.getOwnPropertyDescriptor(n,"Inst"),w=n,D={},Object.keys(v).forEach((function(t){D[t]=v[t]})),D.enumerable=!!D.enumerable,D.configurable=!!D.configurable,
("value"in D||D.initializer)&&(D.writable=!0),D=R.slice().reverse().reduce((function(t,e){return e(y,T,t)||t}),D),
w&&void 0!==D.initializer&&(D.value=D.initializer?D.initializer.call(w):void 0,D.initializer=void 0),void 0===D.initializer&&(Object.defineProperty(y,T,D),D=null),s=n))||s
var y,T,R,v,w,D},34659:(t,e,i)=>{i.d(e,{x:()=>s})
class s{constructor(){this.id=0,this.typeId=0,this.hideTips=!1}}},71842:(t,e,i)=>{i.d(e,{o:()=>c})
var s,n=i(18998),a=i(83908),o=i(98130),l=i(79878),r=i(26348),h=i(10909)
const{ccclass:d,property:u}=n._decorator
let c=d("AccessCopyDefeatIconItem")(s=class extends((0,a.pA)(h.j)()){constructor(...t){super(...t),this.IsCopy=!0}InitView(){}SetData(t){this.accessId=o.GF.INT(t[0]),
this.accessRes=r.Z.Inst().getItemById(this.accessId),this.icon.spriteNameSet(this.accessRes.icon,"huoqutujing"),this.nameTxt.textSet(this.accessRes.name),
l.Y.RegLuaClick(this.bg.node,this._degf_OnClick),l.Y.RegLuaClick(this.icon.node,this._degf_OnClick),
null!=t[1]?this.img_recommend.node.SetActive(t[1]):this.img_recommend.node.SetActive(1==this.accessRes.recommend)}RemoveLis(){}Clear(){this.RemoveLis(),super.Clear()}Destroy(){}
Test1(){return!0}S_Test(){return!0}})||s},10909:(t,e,i)=>{i.d(e,{j:()=>h})
var s,n=i(18998),a=i(83908),o=i(98130)
const{ccclass:l,property:r}=n._decorator
let h=l("AccessIconItem")(s=class extends((0,a.yk)()){constructor(...t){super(...t),this.accessId=0,this.accessRes=null,this._degf_OnClick=null}_initBinder(){super._initBinder(),
this._degf_OnClick=(t,e)=>this.OnClick(t,e)}InitView(){}SetData(t){this.accessId=o.GF.INT(t),this.accessRes=INS.accessCfgManager.getItemById(this.accessId),
this.icon.spriteNameSet(this.accessRes.icon),this.nameTxt.textSet(this.accessRes.name),INS.TaskUtil.RegLuaClick(this.bg.node,this._degf_OnClick),
INS.TaskUtil.RegLuaClick(this.icon.node,this._degf_OnClick)}OnClick(t,e){INS.accessMgr.GoToAccess(this.accessId),
INS.copyBaseControl.IsInMapPassBossCopy()&&(INS.mapPassModel.isClickAcccess=!0)}Clear(){INS.TaskUtil.DelLuaClick(this.bg.node,this._degf_OnClick),
INS.TaskUtil.DelLuaClick(this.icon.node,this._degf_OnClick)}})||s},80392:(t,e,i)=>{i.d(e,{H:()=>k})
var s=i(17409),n=i(82815),a=i(16854),o=i(86133),l=i(60348),r=i(98800),h=i(96098),d=i(96557),u=i(36241),c=i(19176),_=i(6700),I=i(68662),g=i(13687),m=i(71530),C=i(66788),S=i(56937),p=i(31222),A=i(5494),f=i(52726),y=i(995),T=i(13195),R=i(52212),v=i(8125),w=i(94148),D=i(75439),E=i(6071),L=i(60128),G=i(32691),O=i(61149),b=i(54383),B=i(47963),N=i(79878),P=i(75517),M=i(21334),V=i(79534)
class k extends T.W{static get Inst(){return k._inst||(k._inst=new k),k._inst}constructor(){super(!0,a.J.eJoystick,a.J.eJoystick),this.time=k.span,this.lastMoveRate=0,
this._justRotateValue=.4,this._autoRingTime=0,this.dirXYOld=null,this.oldThumbX=0,this.oldThumbY=0,this.imediateMove=!1,this.updateCount=0,this.startTimer=0,this.cansend=!0,
this.draging=!1,this.gotoposX=0,this.gotoposZ=0,this._degf_DestroyJoystickHandler=null,this._degf_InitJoystickHandler=null,this.startPos=null,this.dirValue=null,
this.startPos=new V.P(0,0,0),this.dirValue=new R.F(0,0)}isJoystickMoving_get(){return this.IsDraging()}justRotateValue_get(){
return 0==this._justRotateValue&&this.InitRotateValue(),this._justRotateValue}AutoRidingValue_get(){return 0==this._autoRingTime&&this.InitAutoTimeValue(),this._autoRingTime}
InitSingleton(){}UnInitSingleton(){}SingletonUpdate(t,e){this.JoyMove(t,e)}InitAutoTimeValue(){this._autoRingTime=1e3*D.D.getInstance().GetIntValue("RIDING:WAITING_TIMES")}
InitRotateValue(){const t=D.D.getInstance().GetIntValue("PUBLIC:ROCKING_BAR_RESPONSE_LIMIT")
t<90?this._justRotateValue=1*t/90:(C.Y.LogError((0,o.T)("PUBLIC:ROCKING_BAR_RESPONSE_LIMIT 值超过最大移动距离90, 默认修改为30")),this._justRotateValue=30/90)}JoystickMoving(){
P.W.inst_get().CloseView()}JoyMove(t,e){if(I.D.isrelogin)return
if(!this.isJoystickMoving_get())return this.time=k.span,this.oldThumbX=0,this.oldThumbY=0,this.updateCount=0,this.startTimer=I.D.serverMSTime_get(),void(this.cansend=!0)
const i=r.Y.Inst.PrimaryRole_get()
if(null==i)return
if(L.t.ins.IsForbidenScreen())return
this.JoystickMoving(),this.updateCount+=1,i.InRoom()&&(this.startTimer=I.D.serverMSTime_get())
if(I.D.serverMSTime_get()-this.startTimer>this.AutoRidingValue_get()){const t=g.b.Inst.currentMapId_get()
M.p.Inst_get().GetMapById(t).rideForbid||(G.C.Inst_get().SendAllRoleHorseDressOrOff(!0),this.cansend=!1,this.startTimer=I.D.serverMSTime_get())}
const s=this.GetThumbX(),a=this.GetThumbY()
let o=!1
this.time+=e,this.time>k.span&&(o=!0,this.oldThumbX=s,this.oldThumbY=a)
v.T.AngleOffset(s,a,this.oldThumbX,this.oldThumbY)>15&&(o=!0,this.oldThumbX=s,this.oldThumbY=a),1==this.imediateMove&&(o=!0,this.imediateMove=!1),
l.U.IsInCutSceneMode()||h.B.Inst.isOpenMaskStart||(i.removeAI(n.R.castskill,500),
i.IsInAI(n.R.castskill)||d.Q.CanMove(i.GetStates())&&(i.Statemachine_get().cannotMove()||o&&(E.T.ins.is_stop||E.T.ins.Pause(),this.time=0,this.PlayerMove(i),
this.JoystickMoveHappened())))}NextMoveNoSpan(){this.imediateMove=!0}PlayerMove(t){const e=this.GetMoveDir(),[i,s,n]=[e.x,0,e.z]
V.P.Recyle(e)
const a=k.span*t.GetMoveSpeed()*3,[o,l,r]=t.GetPosXYZ()
let[h,d,u]=[o+i*a*1,l+s*a*1,r+n*a*1]
if(this.CanGoto(t,o,l,r,h,d,u,100))return
let[c,_,I]=m.A.Rotate(i,s,n,0,1,0,20);[h,d,u]=[o+c*a,l+_*a,r+I*a],this.CanGoto(t,o,l,r,h,d,u,300)||([c,_,I]=m.A.Rotate(i,s,n,0,1,0,-20),[h,d,u]=[o+c*a,l+_*a,r+I*a],
this.CanGoto(t,o,l,r,h,d,u,300))}CanGoto(t,e,i,s,n,a,o,l){const r=_.L.Instance_get().GetLimitedAStarPath(e,s,n,o,l)
if(m.A.DistanceFastXZ(n,0,n,this.gotoposX,0,this.gotoposZ)<.01)return!1
if(r){const e=new V.P(n,a,o)
if(this.gotoposX=n,this.gotoposZ=o,w.b.Inst_get().InteraptPath(e))return
return t.gotoPoint(e),!0}return!1}JoystickMoveHappened(){const t=r.Y.Inst.PrimaryRole_get()
null!=t&&d.Q.CanMove(t.GetStates())&&(c.S.getInst().InHang_get()||b.k.Inst_get().attacked2&&O.k.inst.clearAuotoPk(),O.k.inst.clearRole(),B.c.Inst_get().isAuto_set(!1),
(N.Y.isInTaskFindWay||r.Y.isMapFindWay)&&(N.Y.isInTaskFindWay=!1,r.Y.isMapFindWay=!1,u._.getInst().openOrCloseStartIcon()),
c.S.getInst().InHang_get()||c.S.getInst().isTickStopAIHang?(c.S.getInst().IsTickStopAIHang_Set(!0),u._.getInst().endHang(!1,!1,!1,!0),u._.getInst().clearAItime(),
O.k.inst.AttackTimeChange2()):null!=t.AISingleton_get()&&t.AISingleton_get().getSingletonType()==n.R.hang?(u._.getInst().ishang_set(!0),
u._.getInst().endHang(!1)):null!=t.AISingleton_get()&&t.AISingleton_get().getSingletonType()==n.R.castskill&&(t.removeAI(n.R.castskill,500),t.IsInAI(n.R.castskill)))}IsDraging(){
return this.draging}draging_get(){return this.draging}draging_set(t){0==t&&(this.gotoposX=0,this.gotoposZ=0),this.draging=t}GetDirXY(){return null}GetMoveRate(){return 0}
GetThumbX(){return 0}GetThumbY(){return 0}GetMoveDir(){return V.P.ZEROTMP}TouchDragProcess(t,e,i,s){}ResetIfRelease(t){}ClickBegin(t,e,i,n){const a=(0,s.Y)(A.I.eJoystickPanel)
a&&a.touchDragProcess(t,e)}SetPos(){}OpenJoystickPanel(){const t=new S.v
t.layerType=f.F.DefaultUI,t.aniDir=y.K.Left,t.ReLoginOrChangeRoleIsDestroy=!1,p.N.inst.OpenById(A.I.eJoystickPanel,this._degf_InitJoystickHandler,this._degf_DestroyJoystickHandler,t)
}CloseJoystickPanel(){(0,s.sR)(A.I.eJoystickPanel)}SetBattleJoystickState(t){this.OpenJoystickPanel()}}k._inst=null,k.span=.3,k.minSpan=.15},76910:(t,e,i)=>{
var s,n=i(18998),a=i(6847),o=i(83908),l=i(49655),r=i(46282),h=i(52212),d=i(79534),u=i(80392);(0,a.s_)(l.o.eJoystickPanel,r.Z.ui_joystick_panel).register()(s=class extends((0,
o.Ri)()){constructor(...t){super(...t),this.radiusPixel=40,this.mAreaTrans=null,this.thumbTrans=null,this.pressed=!1,this.fingerId=-1,this.thumbWorldPos=null,
this.firstClickPos=null,this.m_fingerId=0,this.dirValue=null,this.moveRate=0,this.thumbXLoc=0,this.thumbYLoc=0}InitView(){this.thumbWorldPos=new d.P,this.dirValue=new h.F,
this.firstClickPos=new d.P(u.H.Inst.startPos.x,u.H.Inst.startPos.y,0)
const t=n.sys.getSafeAreaRect(),e=n.view.getVisibleSizeInPixel(),i=n.view.getVisibleSize(),s=(u.H.Inst.startPos.x-e.width/2)/e.width*i.width,a=(u.H.Inst.startPos.y-e.height/2)/e.height*i.height
this.fixGo.setPosition(s-t.x/2,a,0)}OnAddToScene(){this.thumbTrans=this.texTouch.node.transform}Clear(){}Destroy(){}OnDragProcess(t,e,i){this.thumbWorldPos.set(t,e,i),
this.checkPosition()
const s=this.AngleOffset(this.dirValue.x,this.dirValue.y)
new d.P(0,0,-1*s)}checkPosition(){let t=new d.P(this.thumbWorldPos.x-u.H.Inst.startPos.x,this.thumbWorldPos.y-u.H.Inst.startPos.y,this.thumbWorldPos.z-u.H.Inst.startPos.z)
t.Magnitude()>this.radiusPixel&&(t=t.Normalize().Mul(this.radiusPixel)),this.thumbTrans.SetLocalPosition(t),this.dirValue=new h.F(t.x,t.y),
this.moveRate=this.dirValue.SqrMagnitude()/this.radiusPixel,this.dirValue=this.dirValue.normalize(),u.H.Inst.dirValue=new h.F(this.dirValue.x,this.dirValue.y)}AngleOffset(t,e){
const i=new h.F(t,e)
let s=h.F.Angle(h.F.up,i)
return t<0&&(s=360-s),s}resetIfRelease(t){t==this.m_fingerId&&this.reset()}reset(){this.pressed=!1,this.fingerId=-1,this.thumbTrans.SetLocalPosition(d.P.zero_get()),
this.dirValue=h.F.zero_get()}touchDragProcess(t,e,i,s){0==this.pressed?(this.setPos(),this.dragProcess(t,e,i)):this.dragProcess(t,e,i)}dragProcess(t,e,i){
0!=this.pressed&&this.OnDragProcess(t,e,i)}clickBegin(t,e,i,s){this.firstClickPos=new d.P(t,e,i),this.m_fingerId=s}setPos(){this.pressed=!0}})}}])
