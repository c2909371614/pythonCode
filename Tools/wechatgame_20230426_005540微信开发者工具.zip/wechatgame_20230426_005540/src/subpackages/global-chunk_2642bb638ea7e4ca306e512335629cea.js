"use strict";(globalThis.webpackChunkProject=globalThis.webpackChunkProject||[]).push([[748],{74492:(t,e,i)=>{i.d(e,{g:()=>C})
var s,n,l,a=i(93984),r=i(38836),o=i(36241),h=i(92415),d=i(55360),_=i(42292),u=i(85602),I=i(38962),c=i(87923),g=i(2457),p=i(17783),m=i(15398),S=i(71409)
class T{constructor(){this.groupList=null,this.groupNames=null,this.onCallBack=null,this.m_groupID=0,this.isMovie=0,this.isHang=!1,this.openfanji=!0,this.isPlayStory=!1,
this.cutSceneTimeoutTimer=0,this._degf_OnStoryEnd=null,this._degf_OnStoryStart=null,this._degf_OnUICreate=null,this._degf_OnMovieEnd=null,this.movieDirectorId=null,
this.storyID=null,this.groupNames=new u.Z,this._degf_OnStoryEnd=t=>this.OnStoryEnd(t),this._degf_OnStoryStart=t=>this.OnStoryStart(t),this._degf_OnUICreate=t=>this.OnUICreate(t),
this._degf_OnMovieEnd=t=>this.OnMovieEnd(t)}Play(t,e,i){}OnStoryStart(t){this.cutSceneTimeoutTimer=CallTimer.Inst_get().ClearInterval(this.cutSceneTimeoutTimer)}_OnCutTimeout(){
let t=""
null!=this.groupNames&&this.groupNames.count>0&&(t=this.groupNames[0]),Debuger.LogError(`cutscene time out !${t}`),this.OnStoryEnd(t)}OnMovieEnd(t){
"poison3"==this.movieDirectorId&&ClickStreamMgr.SendClickData(ClickStreamType.Step_267400),this.OnStoryEnd(this.movieDirectorId)}OnStoryEnd(t){this.isPlayStory=!1,
ButtonEffectControl.inst.StopLoadEffect(),UIShowMgr.inst.ShowMainView(),UIShowMgr.inst.HideGlobalCollider(),
null!=this.groupList&&this.groupList.Count()>0&&this.groupList[this.groupList.Count()-1].resetHang&&this.isHang&&HangControl.getInst().startHang(),
PkControl.inst.openfanji=this.openfanji,StorySystemModel.Instance.StoryState=CommonConst.StoryStateNormal,StorySystemController.Instance.checkDialogStory(t),
StorySystemController.Instance.ReqDirectorEnd(),CommonUtil.CheckTrigger(GameConditionType.STORY_END_VAL,this.m_groupID)
CopyBaseModel.Inst_get().curCopyType
null!=this.onCallBack&&(this.onCallBack(this.m_groupID),this.onCallBack=null),TaskUtil.isInTaskFindWay=!1,CharacterMgr.isMapFindWay=!1,HangControl.getInst().openOrCloseStartIcon(),
BuffViewManager.Inst_get().model.OnEnterScene(),
null!=CharacterMgr.Inst.PrimaryRole_get()&&null!=CharacterMgr.Inst.PrimaryRole_get().MainRole_get()&&(CharacterMgr.Inst.PrimaryRole_get().MainRole_get().SetRootAnimClip(4),
CharacterMgr.Inst.PrimaryRole_get().ResetStateMach())}gotoAddpoint(t){CharacterUIModel.Inst_get().topViewType=CharacterUIMenu.Normal,
CharacterUIModel.Inst_get().characterViewType=CharacterUISubMenu.AddAttrs,CharacterTopControl.Inst().Open()}OnUICreate(t){StoryViewMgr.inst.CreateUI(t[0],t[1],t[2],this.storyID)}
Stop(){}}function f(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let C=(s=(0,S.GH)(h.k.SM_StartDirector),(l=class t{static get Instance(){return t._instance||(t._instance=new t),
t._instance}constructor(){this.storyGroupDic=null,this.triggerDic=null,this.storyGroup=null,this.directorGroupid=0,this.mStoryLoadingView=null,this._degf_OnPlayEnd=null,
this._degf_CallDestoryStoryLoadingView=null,this._degf_OnDirectorSort=null,this._degf_OnTaskAccepted=null,this._degf_OnTaskFinish=null,this._degf_SM_StartDirectorHandler=null,
this._degf_SM_TriggerStoryHandler=null,this._degf_ShowStoryLoadingViewHandler=null,this._degf_npcdialog=null,this._degf_SM_SM_Guider=null,this.storyGroupDic=new I.X,
this.triggerDic=new I.X,this.storyGroup=new T,this._degf_OnPlayEnd=t=>this.OnPlayEnd(t),this._degf_CallDestoryStoryLoadingView=()=>this.CallDestoryStoryLoadingView(),
this._degf_OnDirectorSort=(t,e)=>this.OnDirectorSort(t,e),this._degf_OnTaskAccepted=t=>this.OnTaskAccepted(t),this._degf_OnTaskFinish=t=>this.OnTaskFinish(t),
this._degf_SM_StartDirectorHandler=t=>this.SM_StartDirectorHandler(t),this._degf_SM_TriggerStoryHandler=t=>this.SM_TriggerStoryHandler(t),
this._degf_ShowStoryLoadingViewHandler=t=>this.ShowStoryLoadingViewHandler(t),this._degf_npcdialog=(t,e)=>this.npcdialog(t,e),this._degf_SM_SM_Guider=t=>this.SM_GuiderHandler(t),
this.InitCfg(),p.L.Inst_get().model.AddEventHandler(m.M.REWARD_ONE_TASK,this._degf_OnTaskFinish)}InitCfg(){const t=d.Y.Inst.GetOrCreateCsv(a.h.eDirectorResource).GetCsvMap()
for(const[e,i]of(0,r.vy)(t)){const i=t[e]
let s=null
s=this.storyGroupDic.LuaDic_GetItem(i.directorGroupId),null==s&&(s=new u.Z,this.storyGroupDic.LuaDic_AddOrSetItem(i.directorGroupId,s)),s.Add(i)}for(const[t,e]of(0,
r.V5)(this.storyGroupDic))e.Sort(this._degf_OnDirectorSort)}InitTrigger(t){if(null!=t.conditionJsonArr&&null!=t.conditionJsonArr.typevalues){
const e=t.conditionJsonArr.typevalues.Count()
let i=0
for(;i<e;){const e=t.conditionJsonArr.typevalues[i],s=new StoryTriggerVO
s.type=e.type,s.value=e.value,s.item=t
let n=null
n=this.triggerDic.LuaDic_GetItem(e.type),null==n&&(n=new u.Z,this.triggerDic.LuaDic_AddOrSetItem(e.type,n)),n.Add(s),i+=1}}}OnDirectorSort(t,e){return t.sequence-e.sequence}
CheckTrigger(t,e){let i=null
if(i=this.triggerDic.LuaDic_GetItem(t),null!=i){let t=i.Count()-1
for(;t>-1;){const s=i[t],n=StringProxy.String2Int(s.value)
if((s.type==CommonConst.COND_TYPE_ACCEPT_QUEST||s.type==CommonConst.COND_TYPE_QUEST_FINISHED||s.type==CommonConst.COND_TYPE_ENTER_COPY||s.type==CommonConst.COND_TYPE_PASS_COPY||s.type==CommonConst.COND_TYPE_ENTER_MAP||s.type==CommonConst.COND_TYPE_QUEST_FINISHED_DIALOG||s.type==CommonConst.COND_TYPE_ENTER_COPY_BY_GROUP)&&n==GF.INT(e)&&this.CheckTriggerTimes(s)){
Debuger.Log(gettextRy("触发剧情组：")+s.item.directorGroupId)
let t=null
return t=this.storyGroupDic.LuaDic_GetItem(s.item.directorGroupId),this.storyGroup.Play(s.item.directorGroupId,t),this.ReqTriggerUpdate(s.item.directorGroupId),!0}t-=1}}return!1}
PlayByGroupID(t,e){let i=null
i=this.storyGroupDic.LuaDic_GetItem(t),null!=i?this.storyGroup.Play(t,i,e):Debuger.LogError(gettextRy("找不到这个剧情组 groupID：")+t)}GetStoryGroupList(t){let e=null
return e=this.storyGroupDic.LuaDic_GetItem(t),e}GetStoryGroupNames(t){const e=new u.Z,i=this.GetStoryGroupList(t)
if(null==i||0==i.Count())return e
let s=0
for(;s<i.Count();)e.Add(i[s].directorId),s+=1
return e}CheckTriggerTimes(t){const e=StorySystemModel.Instance.triggerTimesDic
let i=0
return i=e.LuaDic_GetItem(t.item.directorGroupId),null==i&&(i=0),0!=i?(i<t.item.triggerRate||-1==t.item.triggerRate)&&(e[t.item.directorGroupId]=i+1,
!0):(e.LuaDic_AddOrSetItem(t.item.directorGroupId,1),!0)}checkDialogStory(t){const e=DirectorCfgManager.inst.getConfigByName(t)
if(null!=e&&null!=e.afterActionParms&&e.afterActionParms.count>0){const t=e.afterActionParms[0]
let i=0,s=0
t==CommonConst.StoryAfterActionDoQuest?(i=StringProxy.String2Int(e.afterActionParms[2]),TransportMapMgr.Inst.CM_FlyShoesTransportHandle(i),
s=StringProxy.String2Int(e.afterActionParms[1]),CharacterMgr.Inst.PrimaryRole_get().StopPathWithOutNoticeServer(),PkControl.inst.clearAuotoPk(),
CallTimer.Inst_get().SetIntervalForParm(this._degf_npcdialog,500,1,s)):t==CommonConst.StoryAfterActionTRANSPORT?(i=StringProxy.String2Int(e.afterActionParms[1]),
TransportMapMgr.Inst.CM_FlyShoesTransportHandle(i)):t==CommonConst.StoryAfterActionDoHang&&o._.getInst().startHang()}}npcdialog(t,e){const i=GF.INT(e)
CharacterMgr.Inst.PrimaryRole_get().StopPathWithOutNoticeServer(),PkControl.inst.clearAuotoPk(),c.l.FaceToNpc(i),c.l.NpcFaceToPlayer(i),
DialogueManager.Inst_get().control.Open(i,!0)}OnTaskAccepted(t){const e=t
c.l.CheckTrigger(g.u.COND_TYPE_ACCEPT_QUEST_VAL,e.resource_get().id)}OnTaskFinish(t){const e=t
c.l.CheckTrigger(g.u.COND_TYPE_QUEST_FINISHED_VAL,e.resource_get().id),c.l.CheckTrigger(g.u.COND_TYPE_QUEST_FINISHED_DIALOG_VAL,e.resource_get().id)}SM_GuiderHandler(t){
GuideModel.Instance.guideStepLogDic=t.id2group,GameMapManager.Inst.isSceneInited&&GuideManager.Inst.CheckGuideStep()}SM_TriggerStoryHandler(t){const e=t
GuideModel.Instance.UpdateTriggerTimesDic(e)}SM_StartDirectorHandler(t){const e=t
this.directorGroupid=e.directorGroupid,o._.getInst().startHang()}OnPlayEnd(t){UIShowMgr.inst.RemoveAllSingleDirectionAnimOnce()}ReqDirectorEnd(){const t=new CM_EndDirector
t.directorGroupid=this.directorGroupid,SocketManager.Inst.F_SendMsg(t)}ReqTriggerUpdate(t){const e=new CM_TriggerStoryUpdate
e.groupId=t,SocketManager.Inst.F_SendMsg(e)}OpenStoryLoadingView(){if(null!=this.mStoryLoadingView)this.mStoryLoadingView.Show()
else{
(new UIOpenParam).layerType=LayerType.Alert,UIShowMgr.inst.OpenById(eUIComponentID.StoryLoadingViewID,this._degf_ShowStoryLoadingViewHandler,this._degf_CallDestoryStoryLoadingView)
}}ShowStoryLoadingViewHandler(t){return null==this.mStoryLoadingView&&(this.mStoryLoadingView=new StoryLoadingView,this.mStoryLoadingView.setId(t,null,0)),this.mStoryLoadingView}
CallDestoryStoryLoadingView(){UIResMgr.DestroyUIObj(this.mStoryLoadingView),this.mStoryLoadingView=null}CloseStoryLoadingView(){
null!=this.mStoryLoadingView&&UIShowMgr.inst.ClosePanel(this.mStoryLoadingView)}})._instance=null,f(n=l,"Instance",[_.n],Object.getOwnPropertyDescriptor(n,"Instance"),n),
f(n.prototype,"SM_StartDirectorHandler",[s],Object.getOwnPropertyDescriptor(n.prototype,"SM_StartDirectorHandler"),n.prototype),n)},47485:(t,e,i)=>{i.d(e,{k:()=>o})
var s=i(54967),n=i(98885),l=i(38962),a=i(31922),r=i(75439)
class o extends s.g{constructor(){super(),this.triggerTimesDic=null,this.StoryState=a.z.StoryStateNormal,this.storyAutoInterval=0,this.triggerTimesDic=new l.X}
StoryAutoInterval_get(){if(0==this.storyAutoInterval){const t=r.D.getInstance().getContent("SCENARIO:AUTO_SKIP_TIME").getContent()
this.storyAutoInterval=n.M.String2Int(t.stringVal)}return this.storyAutoInterval}ResetModel(){this.triggerTimesDic.LuaDic_Clear()}}o.Instance=new o},72082:(t,e,i)=>{i.d(e,{F:()=>o
})
var s=i(93984),n=i(38836),l=i(55360),a=i(85602),r=i(38962)
class o{constructor(){this.map=null,this.capacityMap=null,this.tabMap=null,this.tabMap=new r.X
const t=l.Y.Inst.GetOrCreateCsv(s.h.eStrengthenResource)
this.map=t.GetCsvMap()
const e=l.Y.Inst.GetOrCreateCsv(s.h.eStrengthenCapacity)
this.capacityMap=e.GetCsvMap()
for(const[t,e]of(0,n.V5)(this.map)){let t=null
this.tabMap.LuaDic_ContainsKey(e.tab)||(this.tabMap[e.tab]=new a.Z),t=this.tabMap[e.tab],t.Add(e)}}static Inst(){return null==o._inst&&(o._inst=new o),o._inst}getConfig(t){
return this.map.LuaDic_ContainsKey(t)?this.map[t]:null}getConfigByTabClass(t,e){for(const[i,s]of(0,n.V5)(this.map))if(s.tab==t&&s.firstType==e)return s
return null}getMap(){return this.map}getCapacity(t){return this.capacityMap.LuaDic_ContainsKey(t)?this.capacityMap[t]:null}GetListByTab(t){return this.tabMap[t]||new a.Z}
GetFatherTabLis(){const t=new a.Z
for(const[e,i]of(0,n.V5)(this.tabMap))null!=i&&null!=i[0]&&t.Add(i[0])
return t}}o._inst=null},55967:(t,e,i)=>{i.d(e,{x:()=>C})
var s=i(56937),n=i(18202),l=i(31222),a=i(5494),r=i(52726),o=i(21759),h=i(25241),d=i(92703),_=i(51696),u=i(41664),I=i(5924),c=i(93877),g=i(3522),p=i(72005),m=i(61911),S=i(98885),T=i(48933)
class f extends m.f{constructor(){super(),this.processText1=null,this.processBg=null,this.newAttrOpenText=null,this.suitName=null,this.processText2=null,this.bg=null,
this.newAttrOpenBg=null,this.suitNameCopy=null,this.showAnim=null,this._model=null,this.timer1=-1,this.timer2=-1,this.loopTimes=0,this.startX=0,this.totalTimes=0,
this._degf_DelayCloseHandler=null,this._degf_MoveHandle=null,this._degf_PlayAnime=null,this._degf_DelayCloseHandler=()=>this.DelayCloseHandler(),
this._degf_MoveHandle=()=>this.MoveHandle(),this._degf_PlayAnime=()=>this.PlayAnime()}InitView(){this.processText1=new c.Q,
this.processText1.setId(this.FatherId,this.FatherComponentID,1),this.processBg=new p.w,this.processBg.setId(this.FatherId,this.FatherComponentID,2),this.newAttrOpenText=new c.Q,
this.newAttrOpenText.setId(this.FatherId,this.FatherComponentID,3),this.suitName=new c.Q,this.suitName.setId(this.FatherId,this.FatherComponentID,4),this.processText2=new c.Q,
this.processText2.setId(this.FatherId,this.FatherComponentID,5),this.bg=new p.w,this.bg.setId(this.FatherId,this.FatherComponentID,6),this.newAttrOpenBg=new p.w,
this.newAttrOpenBg.setId(this.FatherId,this.FatherComponentID,7),this.suitNameCopy=new c.Q,this.suitNameCopy.setId(this.FatherId,this.FatherComponentID,8),this.showAnim=new g.k,
this.showAnim.setId(this.FatherId,this.FatherComponentID,9),this._model=d.n.Inst_get(),super.InitView()}OnAddToScene(){this.SetData()}SetData(){this.ClearTimer(),
null!=this._model.curShowData&&(this._model.curShowData.suitRes.universal?(this.bg.spriteNameSet("comm_sp_0241"),this.processBg.spriteNameSet("comm_sp_0242"),
this.newAttrOpenBg.spriteNameSet("comm_sp_0243")):1==this._model.curShowData.suitRes.suitProperty?(this.bg.spriteNameSet("comm_sp_0231"),
this.processBg.spriteNameSet("comm_sp_0232"),this.newAttrOpenBg.spriteNameSet("comm_sp_0235")):(this.bg.spriteNameSet("comm_sp_0233"),this.processBg.spriteNameSet("comm_sp_0234"),
this.newAttrOpenBg.spriteNameSet("comm_sp_0236")),this.suitName.textSet(this._model.curShowData.suitName),this.suitNameCopy.textSet(this._model.curShowData.suitName),
this.processBg.node.SetActive(!1),this.processBg.node.SetActive(!0),this.processText1.textSet(this._model.curShowData.processText),
this.processText2.textSet(this._model.curShowData.processText),this.newAttrOpenBg.node.SetActive(this._model.curShowData.isNewOpen),
this.processText1.node.SetActive(!this._model.curShowData.isNewOpen),this.processText2.node.SetActive(this._model.curShowData.isNewOpen),
this.timer1=I.C.Inst_get().SetInterval(this._degf_DelayCloseHandler,this._model.delayCloseTime,1),this.PlayNameAnime()),this.showAnim.SetResetOnPlay(!0),this.showAnim.Play(!0,!1),
u.j.Inst.PlayByDivision(_.G.eSuitUpdate)}Clear(){this.ClearTimer(),this._model.curShowData=null}ClearTimer(){I.C.Inst_get().ClearInterval(this.timer1),this.timer1=-1,
I.C.Inst_get().ClearInterval(this.timer2),this.timer2=-1}DelayCloseHandler(){this.ClearTimer(),this._model.curShowData=null,C.inst.ClosePanel()}PlayNameAnime(){
this.suitName.width()<=248?(T.I.calVec0.Set(-19,63,0),this.suitName.node.transform.SetLocalPosition(T.I.calVec0),this.suitNameCopy.node.SetActive(!1,!0)):(this.ResetPos(),
this.suitNameCopy.node.SetActive(!0,!0),this.timer2=I.C.Inst_get().SetInterval(this._degf_PlayAnime,500,1))}PlayAnime(){I.C.Inst_get().ClearInterval(this.timer2),this.ResetPos(),
this.timer2=I.C.Inst_get().SetInterval(this._degf_MoveHandle,50,this.totalTimes)}MoveHandle(){this.loopTimes+=1
const t=this.suitName.node.transform.GetLocalPosition().x-2,e=this.suitNameCopy.node.transform.GetLocalPosition().x-2
T.I.calVec0.Set(t,63,0),this.suitName.node.transform.SetLocalPosition(T.I.calVec0),T.I.calVec0.Set(e,63,0),this.suitNameCopy.node.transform.SetLocalPosition(T.I.calVec0),
this.loopTimes>=this.totalTimes&&(I.C.Inst_get().ClearInterval(this.timer2),this.loopTimes=0)}ResetPos(){S.M.Length(this.suitName.text())
this.startX=(this.suitName.width()-248)/2-19,this.totalTimes=(this.suitName.width()-248)/2,T.I.calVec0.Set(this.startX,63,0),
this.suitName.node.transform.SetLocalPosition(T.I.calVec0),T.I.calVec0.Set(this.startX+this.suitName.width()+24,63,0),this.suitNameCopy.node.transform.SetLocalPosition(T.I.calVec0)
}Destroy(){this.processText1=null,this.processText2=null,this.processBg=null,this.newAttrOpenText=null,this.newAttrOpenBg=null,this.suitName=null,this.suitNameCopy=null,
this.bg=null,this.showAnim=null}}class C{constructor(){this.suitAttrTipPanel=null,this._degf_CallUIDestoryHandler=null,this._degf_ShowCompleteHandler=null,
this._degf_CallUIDestoryHandler=()=>this.CallUIDestoryHandler(),this._degf_ShowCompleteHandler=t=>this.ShowCompleteHandler(t)}OpenPanel(){if(d.n.Inst_get().isShowSuitAttrPanel=!0,
null!=this.suitAttrTipPanel&&this.suitAttrTipPanel.isShow_get())this.suitAttrTipPanel.SetData()
else{const t=new s.v
t.layerType=r.F.Tip,l.N.inst.OpenById(a.I.eSuitAttrTipPanel,this._degf_ShowCompleteHandler,this._degf_CallUIDestoryHandler,t)}}CallUIDestoryHandler(){
n.g.DestroyUIObj(this.suitAttrTipPanel),this.suitAttrTipPanel=null}ShowCompleteHandler(t){return null==this.suitAttrTipPanel&&(this.suitAttrTipPanel=new f,
this.suitAttrTipPanel.setId(t,null,0)),this.suitAttrTipPanel}ClosePanel(){d.n.Inst_get().isShowSuitAttrPanel=!1,h.w.Inst_get().Open(),o.f.inst.SM_ShowAttributeChangeHandle(null),
l.N.inst.CloseById(a.I.eSuitAttrTipPanel)}}C.inst=null},92703:(t,e,i)=>{i.d(e,{n:()=>s})
class s{constructor(){this.curShowData=null,this.delayCloseTime=2e3,this.isShowSuitAttrPanel=!1}static Inst_get(){return null==s._inst&&(s._inst=new s),s._inst}ResetModel(){
this.curShowData=null,this.isShowSuitAttrPanel=!1}CheckIsSameEquipChange(t){
return null!=this.curShowData&&!(this.curShowData.column!=t.column||this.curShowData.pos!=t.pos||!this.curShowData.equipId.Equal(t.equipId))}}s._inst=null},28272:(t,e,i)=>{i.d(e,{
P:()=>s})
class s{constructor(){this.suitName="",this.processText="",this.isNewOpen=!1,this.suitRes=null,this.isActivated=!1,this.column=0,this.pos=0,this.equipId=null}}},92125:(t,e,i)=>{
i.d(e,{s:()=>S})
var s=i(98800),n=i(54967),l=i(63076),a=i(5268),r=i(29714),o=i(14792),h=i(62734),d=i(32942),_=i(93984),u=i(38836),I=i(86133),c=i(66788),g=i(55360),p=i(45538)
class m{constructor(){this.mapEx=null
const t=g.Y.Inst.GetOrCreateCsv(_.h.eSuitenhanceresourceResource)
this.mapEx=t.GetCsvMap()}static Inst_get(){return null==m._inst&&(m._inst=new m),m._inst}getItemById(t){
return this.mapEx.LuaDic_ContainsKey(t)||0==t?this.mapEx[t]:(c.Y.LogError((0,I.T)("无此套裝強化ID:")+t),null)}getItemByTypeAndLevel(t,e,i){for(const[s,n]of(0,
u.V5)(this.mapEx))if(n.positionType==t&&n.equipColumn==e&&n.level==i)return n
return null}getAllConsumesByTypeAndColumn(t,e,i){let s=0
for(const[n,l]of(0,u.V5)(this.mapEx))p._.GetPosNumByStr(l.positionType)==t&&l.equipColumn==e&&l.level<=i&&(s+=l.Consumes)
return s}}m._inst=null
class S extends n.g{constructor(){super(),this.redDotStage=-1,this.redDotEquipIndex=-1,this.tempBaseItemData=null,this.tempBaseItemData=new l.M(0,null)}static Inst_get(){
return null==S._Inst&&(S._Inst=new S),S._Inst}CalRedDotInPanel(){this.redDotStage=this.getFirstRedDotStageInPanel(),
this.redDotEquipIndex=this.getFirstRedDotIndexInEquip(this.redDotStage)}CalEquipRedDotInPanel(){this.redDotStage=this.getFirstRedDotStageInPanel(),
this.redDotEquipIndex=this.getFirstRedDotIndexInEquip(r.C.Inst_get().SelectEquipColumn_get())}CheckRedDot(){const t=this.getRedDot()
h.f.Inst.SetState(o.t.SUIT_ENHANCE,t)}getRedDot(){s.Y.Inst.PrimaryRoleInfo_get().GetEquipmentsByColumn()
return!1}getFirstRedDotIndexInEquip(t){const e=s.Y.Inst.PrimaryRoleInfo_get().GetEquipmentsByColumn(t)
if(null==e||null==e.equipmentsGet())return-1
const i=e.equipmentsGet()
let n=0
for(;n<i.Count();){if(null!=i[n]){this.tempBaseItemData.SetDataByModelIdAndInfo(i[n].modelId,i[n])
if(this.checkCould(this.tempBaseItemData,t,n))return n}n+=1}return-1}getFirstRedDotStageInPanel(){return-1}StageHaveRed(t,e){let i=null
if(null!=t&&null!=t.equipmentsGet()&&(i=t.equipmentsGet()),null==i)return!1
let s=0
for(;s<i.Count();){if(null!=i[s]){this.tempBaseItemData.SetDataByModelIdAndInfo(i[s].modelId,i[s])
if(this.checkCould(this.tempBaseItemData,e,s))return!0}s+=1}return!1}checkCould(t,e,i){
const n=t.serverData_get(),l=e,r=i,o=d.G.GetEquipTypeByTypeFormatWeapon(r),h=n.suitEnhanceLevel,_=m.Inst_get().getItemByTypeAndLevel(o,l,h+1)
let u=!1
if(n.suitId>0){const t=a.H.Inst().getSuitById(n.suitId)
null!=t&&t.isAngelSuit&&(u=!0)}const I=n.suitType>0&&n.suitQuality>0
if(null!=_&&I){if(s.Y.Inst.PrimaryRoleInfo_get().SuitRecycle_Score_get()>=_.Consumes)return!0}return!1}}S._Inst=null},65793:(t,e,i)=>{i.d(e,{W:()=>H})
var s,n,l,a,r,o,h,d=i(42292),_=i(71409),u=i(17409),I=i(32076),c=i(98800),g=i(97960),p=i(5430),m=i(97461),S=i(38935),T=i(56937),f=i(18202),C=i(31222),E=i(5494),A=i(85602),L=i(45538),y=i(92679),D=i(82557),O=i(33245),R=i(13715),N=i(78847),M=i(92252),w=i(92415),P=i(65550),v=i(5727),k=i(48922),U=i(74302),G=i(2787),F=i(6213)
function B(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let H=(s=(0,_.GH)(w.k.SM_FashionDressInfo),n=(0,_.GH)(w.k.SM_ResolveFashionDressItem),l=(0,
_.GH)(w.k.SM_UnlockFashionDress),a=(0,_.GH)(w.k.SM_WearFashionDress),r=(0,_.GH)(w.k.SM_PlayerFashionDressChange),h=class t{constructor(){this.model=null,this.isTargetAttrView=!1,
this.showSelectView=null,this.model=v.X.Inst_get(),m.i.Inst.AddEventHandler(y.g.BAG_UPDATE,(0,I.v)(this.BagUpdateHandler,this))}static Inst_get(){
return null==t._inst&&(t._inst=new t),t._inst}Reg(){}BagUpdateHandler(){v.X.Inst_get().CheckFashionRedPoint()}SM_FashionDressInfoHandler(t){this.model.HandleFashionDressInfo(t)}
SM_ResolveFashionDressItemHandler(t){this.model.HandleResolveFashionDressItem(t)}SM_UnlockFashionDressHandler(t){this.model.HandleUnlockFashionDress(t)}
SM_WearFashionDressHandler(t){this.model.HandleWearFashionDress(t)}SM_PlayerFashionDressChangeHandler(t){const e=c.Y.Inst.getRoleInfo(t.playerId)
e&&e.Fashions_set(t.dressMap)}OpenReplaceView(){const t=new T.v
t.isShowMask=!0,v.X.Inst_get().replaceData=null,(0,u.Yp)(E.I.RySurfaceSelectView,t)}CloseRySurfaceSelectView(){(0,u.sR)(E.I.RySurfaceSelectView)}OpenSurfaceSettingView(){
const t=new T.v
t.isShowMask=!0,t.viewClass=F.H,(0,u.Yp)(E.I.RySurfaceSettingView,t)}CloseSurfaceSettingView(){C.N.inst.CloseById(E.I.RySurfaceSettingView)}OpenFashionAttrView(t){
this.isTargetAttrView=t
const e=new T.v
e.isShowMask=!0,e.viewClass=k.H,C.N.inst.OpenById(E.I.RyFashionAttrView,null,null,e)}CloseFashionAttrView(){C.N.inst.CloseById(E.I.RyFashionAttrView)}OpenFashionCabinetView(){
const t=new T.v
t.isShowMask=!0,t.viewClass=U.a,C.N.inst.OpenById(E.I.RyFashionCabinetView,null,null,t)}CloseFashionCabinetView(){C.N.inst.CloseById(E.I.RyFashionCabinetView)}
ReqSaveEquipFacadeSetting(t,e,i){const s=new N.Y
s.equipGuardColumn=-1
const n=new A.Z
for(let t=0;t<=12;t++)n[t]=new M.l,v.X.Inst_get().IsShowPart(t)?n[t].equipIndex=-1:n[t].equipIndex=0
s.isOpenUserDefined=0==i
for(let t=0;t<=e.count-1;t++)null!=e[t].vo?(n[e[t].pos].equipIndex=e[t].vo.clomn,e[t].pos==L._.POS_GUARD&&(s.equipGuardColumn=e[t].vo.clomn),
n[e[t].pos].isShowRefine=e[t].vo.showRefine):(n[e[t].pos].equipIndex=0,n[t].isShowRefine=!1)
s.playerId=t,-1==i?(s.equipColumn=-1,s.equipGuardColumn=-1):s.equipColumn=v.X.Inst_get().GetEquipColumnByStage(i),s.equipIndex=n,S.C.Inst.F_SendMsg(s)}ReqUnlockFashionDress(t,e){
const i=new O.i
i.playerId=t,i.fashionDressId=e,S.C.Inst.F_SendMsg(i)}ReqWearFashionDress(t,e,i){const s=new R.L
s.playerId=t,s.fashionDressId=e,s.wear=i,S.C.Inst.F_SendMsg(s)}ReqResolveFashionDressItem(t){const e=new D.R
e.itemId2Num=t,S.C.Inst.F_SendMsg(e)}ShowRySurfaceSelectViewHandler(t){return null==this.showSelectView&&(this.showSelectView=new G.j(null),this.showSelectView.setId(t,null,0)),
this.showSelectView}SetFacadeEquipmentSetting(t,e,i){if(null==i&&(i=!1),t.FacadeEquipmentSetting=e,i){const i=c.Y.Inst.GetMultiPlayer(t.m_id)
null!=i&&(i.EventEquipOffByPos(0),i.EventEquipOffByPos(1)),p.Y.UpdateModelDataByFacadeSetting(t,e),null!=i&&(i.ChangeEquipments(),i.RefreshAnimationClip()),
t.UpdateEquipmentStorageVOInGuard(),null!=i&&i.ResetStateMach(),P.y.inst.ClientSysMessage(437001),t.RaiseEvent(g.A.EquipFacadeUpdate)}}DestoRySurfaceSelectViewHandler(){
f.g.DestroyUIObj(this.showSelectView),this.showSelectView=null}},h._inst=null,B(o=h,"Inst_get",[d.Vx],Object.getOwnPropertyDescriptor(o,"Inst_get"),o),
B(o.prototype,"SM_FashionDressInfoHandler",[s],Object.getOwnPropertyDescriptor(o.prototype,"SM_FashionDressInfoHandler"),o.prototype),
B(o.prototype,"SM_ResolveFashionDressItemHandler",[n],Object.getOwnPropertyDescriptor(o.prototype,"SM_ResolveFashionDressItemHandler"),o.prototype),
B(o.prototype,"SM_UnlockFashionDressHandler",[l],Object.getOwnPropertyDescriptor(o.prototype,"SM_UnlockFashionDressHandler"),o.prototype),
B(o.prototype,"SM_WearFashionDressHandler",[a],Object.getOwnPropertyDescriptor(o.prototype,"SM_WearFashionDressHandler"),o.prototype),
B(o.prototype,"SM_PlayerFashionDressChangeHandler",[r],Object.getOwnPropertyDescriptor(o.prototype,"SM_PlayerFashionDressChangeHandler"),o.prototype),o)},8434:(t,e,i)=>{i.d(e,{
$:()=>s})
class s{}s.Weapon=1,s.Body=2},61768:(t,e,i)=>{i.d(e,{U:()=>s})
class s{constructor(){this.res=null,this.consumes=null,this.attrs=null,this.suitAttrs=null,this.isLock=!0,this.isWear=!1,this.canActive=!1,this.suitOrder=1,this.isPreview=!1,
this.suitRes=void 0}Test1(){return!0}S_Test(){return!0}}},66476:(t,e,i)=>{i.d(e,{L:()=>_})
var s=i(93984),n=i(38836),l=i(55360),a=i(98885),r=i(85602),o=i(38962),h=i(52429),d=i(46749)
class _{constructor(){this.fashionMap=null,this.fashionSuitAttrMap=null,this.fashionCabinetMap=null,this.fashionCabinetAttrMap=null,this.fashionConsumeMap=null,
this.fashionMap2=null,this.displayDic=null,this.fashionMap=new o.X,this.fashionSuitAttrMap=new o.X,this.fashionCabinetMap=new o.X,this.fashionCabinetAttrMap=new o.X,
this.fashionConsumeMap=new o.X,this.fashionMap2=new o.X,this.displayDic=new o.X
const t=l.Y.Inst.GetOrCreateCsv(s.h.eFashionResource)
this.fashionMap=t.GetCsvMap()
const e=l.Y.Inst.GetOrCreateCsv(s.h.eFashionAttrResource)
this.fashionSuitAttrMap=e.GetCsvMap()
const i=l.Y.Inst.GetOrCreateCsv(s.h.eFashionCabinetResource)
this.fashionCabinetMap=i.GetCsvMap()
for(const[t,e]of(0,n.V5)(this.fashionMap)){const i=d.z.CreateFromJson(e.consumes)
let s=0
for(;s<i.typevalues.count;){const n=i.typevalues[s]
n.Parse()
const l=a.M.String2Int(n.valueType)
this.fashionConsumeMap.LuaDic_AddOrSetItem(t,l),this.fashionMap2.LuaDic_AddOrSetItem(l,e),s+=1}0!=e.fashionId&&(this.displayDic[e.fashionId]=!0)}for(const[t,e]of(0,
n.V5)(this.fashionCabinetMap)){const i=new r.Z,s=h.L.CreateFromJson(e.attr)
s.parse()
const n=s.attrs,l=this.getCabinetItemById(t+1)
if(l){const t=h.L.CreateFromJson(l.attr)
t.parse()
const e=t.attrs
let s=0
for(;s<e.Count();){let t=!1,l=0
for(;l<n.Count();){if(n[l].intType==e[s].intType){const a={isNewAttr:!1}
a.intType=n[l].intType,a.value=n[l].value,a.addValue=e[s].value-n[l].value,i.Add(a),t=!0
break}l+=1}if(!t){const t={isNewAttr:!0}
t.intType=e[s].intType,t.value=e[s].value,t.addValue=0,i.Add(t)}s+=1}}else{let t=0
for(;t<n.Count();){const e={isNewAttr:!1}
e.intType=n[t].intType,e.value=n[t].value,e.addValue=0,i.Add(e),t+=1}}this.fashionCabinetAttrMap.LuaDic_AddOrSetItem(t,i)}}static Inst(){return null==_._inst&&(_._inst=new _),
_._inst}getItemById(t){return this.fashionMap.LuaDic_GetItem(t)}IsFashion(t){return this.displayDic.LuaDic_ContainsKey(t)}getSuitAttrItemBySuitId(t){for(const[e,i]of(0,
n.V5)(this.fashionSuitAttrMap))if(i.suitId==t)return i}getCabinetItemById(t){return this.fashionCabinetMap.LuaDic_GetItem(t)}getCabinetAttrsById(t){
return this.fashionCabinetAttrMap.LuaDic_GetItem(t)}getFashionConsumeById(t){return this.fashionConsumeMap.LuaDic_GetItem(t)}getFashionResByConsumeId(t){
return this.fashionMap2.LuaDic_GetItem(t)}}_._inst=null},5727:(t,e,i)=>{i.d(e,{X:()=>B})
var s,n,l,a,r,o,h=i(42292),d=i(71409),_=i(38836),u=i(98800),I=i(16812),c=i(98130),g=i(98885),p=i(16175),m=i(85602),S=i(38962),T=i(58087),f=i(70850),C=i(45538),E=i(75321),A=i(52429),L=i(75439),y=i(33138),D=i(29843),O=i(32927),R=i(92415),N=i(14792),M=i(62734),w=i(8434),P=i(61768),v=i(66476)
class k{constructor(){this.pos=0,this.vo=null,this.fashionData=null,this.isEquip=!1,this.isFashion=!1,this.isSelectView=!1,this.equipments=null,this.clomn=-1,
this.replaceFashionData=null,this.wingRefine=null}Test1(){return!0}S_Test(){return!0}}function U(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let G=null,F=null,B=(s=(0,d.GH)(R.k.SM_FashionDressInfo),n=(0,d.GH)(R.k.SM_ResolveFashionDressItem),l=(0,
d.GH)(R.k.SM_UnlockFashionDress),a=(0,d.GH)(R.k.SM_WearFashionDress),o=class t extends I.k{static __StaticInit(){
G=new m.Z([E.C.PART_NECKLACE,E.C.PART_RINGS_LEFT,E.C.PART_RINGS_RIGHT]),
F=new m.Z([E.C.PART_WEAPON_LEFT,E.C.PART_WEAPON_RIGHT,E.C.PART_HAT,E.C.PART_CLOTHES,E.C.PART_GLOVES,E.C.PART_PANTS,E.C.PART_BOOTS,E.C.PART_WINGS,E.C.PART_GUARD])}constructor(){
super(),this.selectStage=void 0,this.fashionInfo=null,this.stage=-1,this.selectData=null,this.replaceData=null,this.selectFashionData=null,this.minClomnToStage=4,
this.isTargetFashion=!1,this.fashionShowDic=null,this.dressMap=null,this.weaponBones=null,this.bodyBones=null,this.ClomnToStage=null,this.fashionShowDic=new T.y,
this.dressMap=new S.X,this.weaponBones=new m.Z([p.d.eWeapon_l,p.d.eWeapon_r]),this.bodyBones=new m.Z([p.d.ePart_helmet,p.d.ePart_body,p.d.ePart_hand,p.d.ePart_leg,p.d.ePart_shoes])
let t=L.D.getInstance().GetStringValue("EQUIPMENT:EQUIPSTEPLV_DEGREE")
t=g.M.SubStringWithLen(t,1,t.length-2)
const e=g.M.Split(t,",")
this.ClomnToStage=new m.Z
for(let t=0;t<=e.count-1;t++){const i=g.M.Split(e[t],":")
this.ClomnToStage[g.M.String2Int(g.M.Replace(i[0],'"',""))]=g.M.String2Int(i[1])}}static Inst_get(){return null==t._inst&&(t._inst=new t),t._inst}ResetModel(){
this.fashionShowDic.Clear(),this.isTargetFashion=!1}HandleFashionDressInfo(e){this.fashionInfo=e
for(const[t,i]of(0,_.V5)(e.player2Info)){const e=this.GetFashionShowData(t),s={}
let n=0
for(;n<e.Count();){const t=e[n]
t.isWear=!1
for(const[e,s]of(0,_.V5)(i.dressMap))if(t.res.id==s){t.isWear=!0
break}t.isLock=!0
let l=0
for(;l<i.unlocks.Count();){if(t.res.id==i.unlocks[l]){t.isLock=!1
break}l+=1}null==s[t.res.suitId]?t.isLock||(t.suitOrder=0,s[t.res.suitId]=0):t.suitOrder=s[t.res.suitId],n+=1}for(n=0;n<e.Count();){const t=e[n]
null==s[t.res.suitId]?t.isLock||(t.suitOrder=0,s[t.res.suitId]=0):t.suitOrder=s[t.res.suitId],n+=1}e.Sort(this.CreateDelegate(this.OnSortList))
const l=u.Y.Inst.getRoleInfo(t)
l&&l.Fashions_set(i.dressMap)}this.CheckFashionRedPoint(),this.RaiseEvent(t.UPDATE_FASHION)}HandleResolveFashionDressItem(e){this.fashionInfo.level=e.level,
this.fashionInfo.exp=e.exp,this.CheckFashionRedPoint(),this.RaiseEvent(t.UPDATE_FASHION)}HandleUnlockFashionDress(e){for(const[t,i]of(0,
_.V5)(this.fashionInfo.player2Info))t==e.playerId&&(i.unlocks=e.unlockIds)
const i=this.GetFashionShowData(e.playerId),s={}
let n=0
for(;n<i.Count();){const t=i[n]
t.isLock=!0
let l=0
for(;l<e.unlockIds.Count();){if(t.res.id==e.unlockIds[l]){t.isLock=!1
break}l+=1}null==s[t.res.suitId]?t.isLock?t.suitOrder=1:(t.suitOrder=0,s[t.res.suitId]=0):t.suitOrder=s[t.res.suitId],n+=1}for(n=0;n<i.Count();){const t=i[n]
null==s[t.res.suitId]?t.isLock||(t.suitOrder=0,s[t.res.suitId]=0):t.suitOrder=s[t.res.suitId],n+=1}i.Sort(this.CreateDelegate(this.OnSortList)),this.CheckFashionRedPoint(),
this.RaiseEvent(t.UNLOCK_FASHION),this.RaiseEvent(t.UPDATE_FASHION)}HandleWearFashionDress(e){for(const[t,i]of(0,
_.V5)(this.fashionInfo.player2Info))t==e.playerId&&(i.dressMap=e.dressMap)
const i=this.GetFashionShowData(e.playerId)
let s=0
for(;s<i.Count();){const t=i[s]
t.isWear=!1
for(const[i,s]of(0,_.V5)(e.dressMap))if(t.res.id==s){t.isWear=!0
break}s+=1}const n=u.Y.Inst.getRoleInfo(e.playerId)
n&&n.Fashions_set(e.dressMap),this.RaiseEvent(t.UPDATE_FASHION)}IsShowPart(t){return F.Contains(t)}GetSettingShowData(){const t=new m.Z
for(let e=0;e<=F.length-1;e++){const i=new k
i.pos=F[e],i.isEquip=!0,t.Add(i)}return t}GetFashionShowData(t){if(!this.fashionShowDic.LuaDic_ContainsKey(t.toString())){this.fashionShowDic.LuaDic_AddOrSetItem(t,new m.Z)
const e=u.Y.Inst.getRoleInfo(t)
if(e)for(const[i,s]of(0,_.V5)(v.L.Inst().fashionMap))if(c.GF.INT(e.Job_get()/1e3)==s.job){const e=new P.U
e.res=s,e.consumes=v.L.Inst().getFashionConsumeById(i)
const n=A.L.CreateFromJson(s.attrs)
n.parse(),e.attrs=n
const l=v.L.Inst().getSuitAttrItemBySuitId(s.suitId)
e.suitRes=l
const a=A.L.CreateFromJson(l.suitAttrs)
a.parse(),e.suitAttrs=a,this.fashionShowDic.LuaDic_GetItem(t).Add(e)}this.fashionShowDic.LuaDic_GetItem(t).Sort(this.CreateDelegate(this.OnSortList))}
return this.fashionShowDic.LuaDic_GetItem(t.toString())}OnSortList(t,e){
return t.suitOrder>e.suitOrder?1:t.suitOrder<e.suitOrder?-1:t.res.order>e.res.order?1:t.res.order<e.res.order?-1:t.res.position-e.res.position}GetActiveNum(t,e){
const i=this.GetFashionShowData(t)
let s=0,n=0
for(;n<i.Count();)i[n].res.suitId!=e||i[n].isLock||(s+=1),n+=1
return s}GetInfoFacadeEquipmentSetting(t){const e=new S.X,i=t.FacadeEquipmentSetting
if(i.isSelfDefined){this.stage=0
const s=i.facadeList
if(null!=t.allStageEquipments)for(let i=0;i<=s.count-1;i++)if(F.Contains(i))if(-1==s[i].equipIndex);else if(0==s[i].equipIndex);else{let n=null,l=null
const a=t.allStageEquipments.LuaDic_GetItem(s[i].equipIndex)
if(null!=a&&(n=a.GetEquipmentByPos(i),l=a.GetEquipmentRefine(i)),null==n){const n=this.GetStage(s[i].equipIndex),l=(y.f.Inst().equipStepMaxLv,
this.GetFixOne(i,n,t.allStageEquipments,e.LuaDic_GetItem(i)))
null!=l&&e.LuaDic_AddOrSetItem(i,l)}else{let t=e.LuaDic_GetItem(i)
null==t&&(t=new D.H,e.LuaDic_AddOrSetItem(i,t)),t.itemModelId=n.modelId,t.excellenceAttributeModels=n.exellectAttrs,t.enhanceLevel=n.Enhancelevel_get(),t.isShowVO=!0,
t.isEffective=n.isEffective,t.nowModelId=0,t.equipments=n,t.clomn=s[i].equipIndex,t.showRefine=s[i].isShowRefine,l&&(t.showRefine=l.isShow)}}}else{const s=this.stage
if(this.stage=this.GetStage(i.equipColumnShow),this.stage>1)this.GetFix(e,this.stage,t.allStageEquipments),(!e||e.Count()<=0)&&this.GetFix(e,s,t.allStageEquipments)
else if(-1==this.stage){const i=y.f.Inst().equipStepMaxLv
this.GetFix(e,i,t.allStageEquipments)}}return e}GetEquipColumnByStage(t){if(t<=0)return t
const e=this.ClomnToStage.count-1
for(let i=0;i<=e;i++)if(null!=this.ClomnToStage[i]&&t<=this.ClomnToStage[i])return i
return-1}GetStage(t){return t>0?this.ClomnToStage[t]:t}GetMaxStage(t){let e=this.minClomnToStage
for(const[i,s]of(0,_.V5)(t)){const t=this.GetStage(i)
t>e&&(e=t)}return e}GetEquipVo(t,e){const i=new S.X
if(null!=t.allStageEquipments)if(e>1)this.GetFix(i,e,t.allStageEquipments)
else if(-1==e){const e=y.f.Inst().equipStepMaxLv
this.GetFix(i,e,t.allStageEquipments)}return i}GetShowReplaceDatas(t,e,i,s,n,l){const a=new m.Z,r=e.pos,o=this.GetFashionShowData(t.Id_get())
for(let t=0;t<=o.count-1;t++){let e=!1
if(l&&(e=s==o[t]),!o[t].isLock&&this.GetSurfacePos(o[t].res.position)==r&&!e){const e=new k
e.pos=r,e.equipments=null,e.clomn=1,e.fashionData=o[t],e.replaceFashionData=o[t],e.isFashion=l,e.isSelectView=!0,a.Add(e)}}if(null!=t.allStageEquipments)for(const[s,l]of(0,
_.V5)(t.allStageEquipments)){const t=l.GetEquipmentByPos(r)
let o=l.GetEquipmentRefine(r)
if(null!=e.vo&&s==e.vo.clomn&&e.wingRefine&&(o=e.wingRefine),null!=t&&r==C._.POS_WING&&o&&o.isDressed){const e=new k,i=new O.k
i.refineValue=o.refineValue,i.isActivate=o.isActivate,i.refineCount=o.refineCount,i.isDressed=o.isDressed,i.isShow=!o.isShow,e.pos=r,e.equipments=t,e.wingRefine=i,e.clomn=s,
e.isEquip=n,e.isSelectView=!0,a.Add(e)}if(null!=t&&i!=t){const e=new k
e.pos=r,e.equipments=t,e.wingRefine=o,e.clomn=s,e.isEquip=n,e.isSelectView=!0,a.Add(e)}}return a}GetSurfacePos(t){
return t==w.$.Weapon?E.C.PART_WEAPON_LEFT:t==w.$.Body?E.C.PART_CLOTHES:void 0}GetFixOne(t,e,i,s){let n=-1
const l=this.GetMaxStage(i)
for(const[a,r]of(0,_.V5)(i))if(null!=t){const i=r.GetEquipmentByPos(t),o=r.GetEquipmentRefine(t)
if(null!=i){const t=this.GetStage(a)
let r=!1
if(this.GetStage(a)==e&&(r=!0),e==y.f.Inst().equipStepMaxLv&&(t==l||t>n&&t<e)&&(r=!0),r){if(null==s&&(s=new D.H),s.itemModelId=i.modelId,
s.excellenceAttributeModels=i.exellectAttrs,s.enhanceLevel=i.Enhancelevel_get(),s.isShowVO=!0,s.isEffective=i.isEffective,s.nowModelId=0,s.equipments=i,s.clomn=a,
o&&(s.showRefine=o.isShow),t==e)return s
n=t}}}return s}GetFix(t,e,i){for(let s=0;s<=F.count;s++){const n=F[s],l=this.GetFixOne(n,e,i,t.LuaDic_GetItem(n))
null!=l&&t.LuaDic_AddOrSetItem(n,l)}}CheckFashionRedPoint(){if(this.fashionInfo){for(const[t,e]of(0,_.V5)(this.fashionInfo.player2Info)){let e=!1
const i=this.GetFashionShowData(t)
let s=0
for(;s<i.Count();){const t=i[s]
if(t.canActive=!1,t.isLock){f.g.Inst_get().GetItemByModleID(t.consumes)?(t.canActive=!0,e=!0):t.canActive=!1}s+=1}const n=u.Y.Inst.getRoleById(t)
if(n){const t=n.Roleinfo_get().createIdx
M.f.Inst.SetState(N.t.CHARACTER_FASHION_ROLE,e,t)}}const t=v.L.Inst().getCabinetItemById(this.fashionInfo.level+1),e=this.GetResolveList()
M.f.Inst.SetState(N.t.CHARACTER_FASHION_CABINET,t.nextLevel>0&&e.Count()>0)}}GetResolveList(){const t=new m.Z
for(const[e,i]of(0,_.V5)(f.g.Inst_get().GetBagDataList())){const e=i
if(null!=e.baseData_get()){const i=e.baseData_get().cfgData_get().id,s=v.L.Inst().getFashionResByConsumeId(i)
if(s){let i=0
for(const[t,e]of(0,_.V5)(this.fashionInfo.player2Info)){let t=0
for(;t<e.unlocks.Count();){const n=v.L.Inst().getItemById(e.unlocks[t])
n.position==s.position&&n.order==s.order&&(i+=1),t+=1}}i>=3&&t.Add(e)}}}return t}GetFashionBoneList(t){return t==w.$.Weapon?this.weaponBones:this.bodyBones}},
o.SELECT_EQUIP="SELECT_EQUIP",o.REPLACE_EQUIP="REPLACE_EQUIP",o.UPDATE_FASHION="UPDATE_FASHION",o.UNLOCK_FASHION="UNLOCK_FASHION",o._inst=null,
U(r=o,"__StaticInit",[h.Vx],Object.getOwnPropertyDescriptor(r,"__StaticInit"),r),
U(r.prototype,"HandleFashionDressInfo",[s],Object.getOwnPropertyDescriptor(r.prototype,"HandleFashionDressInfo"),r.prototype),
U(r.prototype,"HandleResolveFashionDressItem",[n],Object.getOwnPropertyDescriptor(r.prototype,"HandleResolveFashionDressItem"),r.prototype),
U(r.prototype,"HandleUnlockFashionDress",[l],Object.getOwnPropertyDescriptor(r.prototype,"HandleUnlockFashionDress"),r.prototype),
U(r.prototype,"HandleWearFashionDress",[a],Object.getOwnPropertyDescriptor(r.prototype,"HandleWearFashionDress"),r.prototype),r)
B.__StaticInit()},48922:(t,e,i)=>{i.d(e,{H:()=>S})
var s,n=i(6847),l=i(83908),a=i(49655),r=i(46282),o=i(38836),h=i(85602),d=i(52429),_=i(44498),u=i(33542),I=i(65793),c=i(66476),g=i(5727),p=i(87923)
class m extends((0,l.yk)()){constructor(...t){super(...t),this.data=null}InitView(){super.InitView()}SetData(t){this.attrName.textSet(p.l.GetAttName(t.intType)),
this.attrValue.textSet(`+${p.l.getAttrValueStr(t.intType,t.value)}`)}Clear(){}Destroy(){}}let S=(0,
n.s_)(a.o.RyFashionAttrView,r.Z.ui_surface_fashionattrview_ry).register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),this.model=null}_initBinder(){
super._initBinder(),this.model=g.X.Inst_get()}InitView(){super.InitView(),this.grid.SetInitInfo("ui_surface_fashionattritem_ry",null,m)}OnAddToScene(){super.OnAddToScene(),
I.W.Inst_get().isTargetAttrView?(this.model=u.X.Inst(),this.UpdateTargetView()):(this.model=g.X.Inst_get(),this.UpdateSelfView())
const t=new h.Z,e=this.model.fashionInfo
if(e)for(const[i]of(0,o.V5)(e.player2Info)){const s=this.model.GetFashionShowData(i)
let n=0,l=0
for(;l<s.Count();){const e=s[l]
if(0==e.isLock){const s=e.attrs.Clone().attrs
if(e.res.order>n){const t=c.L.Inst().getSuitAttrItemBySuitId(e.res.suitId)
if(this.model.GetActiveNum(i,e.res.suitId)>=t.suitNum){const t=e.suitAttrs.Clone().attrs
_.I.AddAttrList(s,t)}n=e.res.order}_.I.AddAttrList(t,s)}l+=1}const a=c.L.Inst().getCabinetItemById(e.level+1),r=d.L.CreateFromJson(a.attr)
r.parse()
const o=r.attrs
_.I.AddAttrList(t,o)}t.Count()>7?this.rycommon_sp_0129.SetActive(!0):this.rycommon_sp_0129.SetActive(!1),this.grid.data_set(t),this.emptyAttr.SetActive(0==t.Count()),
this.AddEvent()}UpdateSelfView(){const t=new h.Z,e=this.model.fashionInfo
if(e)for(const[i]of(0,o.V5)(e.player2Info)){const e=this.model.GetFashionShowData(i)
let s=0,n=0
for(;n<e.Count();){const l=e[n]
if(0==l.isLock){const e=l.attrs.Clone().attrs
if(l.res.order>s){const t=c.L.Inst().getSuitAttrItemBySuitId(l.res.suitId)
if(this.model.GetActiveNum(i,l.res.suitId)>=t.suitNum){const t=l.suitAttrs.Clone().attrs
_.I.AddAttrList(e,t)}s=l.res.order}_.I.AddAttrList(t,e)}n+=1}}this.grid.data_set(t),this.emptyAttr.SetActive(0==t.Count()),this.AddEvent()}UpdateTargetView(){
const t=new h.Z,e=this.model.fashionInfo
if(e)for(const[i]of(0,o.V5)(e.player2Info)){const e=this.model.GetFashionShowData(i)
let s=0,n=0
for(;n<e.Count();){const l=e[n]
if(0==l.isLock){const e=l.attrs.Clone().attrs
if(l.res.order>s){const t=c.L.Inst().getSuitAttrItemBySuitId(l.res.suitId)
if(this.model.GetActiveNum(i,l.res.suitId)>=t.suitNum){const t=l.suitAttrs.Clone().attrs
_.I.AddAttrList(e,t)}s=l.res.order}_.I.AddAttrList(t,e)}n+=1}}this.grid.data_set(t),this.emptyAttr.SetActive(0==t.Count()),this.AddEvent()}AddEvent(){
this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.CloseHandler)),this.m_handlerMgr.AddClickEvent(this.confirmBtn,this.CreateDelegate(this.CloseHandler))}
CloseHandler(){I.W.Inst_get().CloseFashionAttrView()}Clear(){super.Clear()}Destroy(){super.Destroy()}})||s},74302:(t,e,i)=>{i.d(e,{a:()=>A})
var s,n=i(6847),l=i(83908),a=i(49655),r=i(46282),o=i(5924),h=i(98885),d=i(85602),_=i(38962),u=i(97415),I=i(1240),c=i(70850),g=i(18152),p=i(10568),m=i(92679),S=i(65793),T=i(66476),f=i(5727),C=i(87923)
class E extends((0,l.yk)()){constructor(...t){super(...t),this.data=null}InitView(){super.InitView()}SetData(t){t.isNewAttr?(this.attrName.textSet(C.l.GetAttName(t.intType)),
this.attrValue.textSet(`+${C.l.getAttrValueStr(t.intType,t.value)}`),this.addValue.textSet("新")):(this.attrName.textSet(C.l.GetAttName(t.intType)),
this.attrValue.textSet(`+${C.l.getAttrValueStr(t.intType,t.value)}`),
t.addValue>0?this.addValue.textSet("+("+C.l.getAttrValueStr(t.intType,t.addValue)+")"):this.addValue.textSet(""))}Clear(){}Destroy(){}}let A=(0,
n.s_)(a.o.RyFashionCabinetView,r.Z.ui_surface_fashioncabinetview_ry).register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),this.model=null,this.tog_exc_list=null,
this.IsClickTog3=!1,this.resolveIdDic=null,this.curLv=-1,this.curExp=-1,this.bagShowGrid=null,this.lvLabelFormat=null,this.delayId=null}_initBinder(){super._initBinder(),
this.model=f.X.Inst_get()}InitView(){super.InitView(),this.bagShowGrid=new u.H,this.bagShowGrid.Init(this.con_grid,this.img_grid_bg,this.bar,6,8),
this.attrGrid.SetInitInfo("ui_surface_fashioncabinet_attritem_ry",null,E),this.lvLabelFormat=this.lvLabel.text()}OnAddToScene(){super.OnAddToScene(),this.AddLis(),
this.UpdatePanel(!0)}AddLis(){this.m_handlerMgr.AddClickEvent(this.btn_close,this.CreateDelegate(this.OnClickClose)),
this.m_handlerMgr.AddClickEvent(this.btn_resolve,this.CreateDelegate(this.OnClickResolve)),
this.model.AddEventHandler(f.X.UPDATE_FASHION,this.CreateDelegate(this.UpdateCabinetInfo)),this.m_handlerMgr.AddEventMgr(m.g.BAG_UPDATE,this.CreateDelegate(this.UpdatePanel)),
this.m_handlerMgr.AddEventMgr(m.g.BAG_SELL_GOLD_CHANGE,this.CreateDelegate(this.UpdateExp))}RemoveLis(){
this.model.RemoveEventHandler(f.X.UPDATE_FASHION,this.CreateDelegate(this.UpdateCabinetInfo)),
this.m_handlerMgr.RemoveClickEvent(this.btn_close,this.CreateDelegate(this.OnClickClose)),
this.m_handlerMgr.RemoveClickEvent(this.btn_resolve,this.CreateDelegate(this.OnClickResolve)),
this.m_handlerMgr.RemoveEventMgr(m.g.BAG_UPDATE,this.CreateDelegate(this.UpdatePanel)),
this.m_handlerMgr.RemoveEventMgr(m.g.BAG_SELL_GOLD_CHANGE,this.CreateDelegate(this.UpdateExp))}Clear(){this.ClearDelayId(),this.RemoveLis(),this.bagShowGrid.Clear(),super.Clear()}
Destroy(){this.bagShowGrid.Destroy(),super.Destroy()}OnClickClose(){p.V.ins.bag_sell_score_list.Clear(),S.W.Inst_get().CloseFashionCabinetView()}OnClickResolve(){
const t=p.V.ins.bag_sell_score_list.GetRange(0,p.V.ins.bag_sell_score_list.Count())
if(0==t.Count())return
const e=new _.X
for(let i=0;i<=t.Count()-1;i++)e.LuaDic_AddOrSetItem(t[i].baseData_get().cfgData_get().id,t[i].serverData_get().num)
p.V.ins.bag_sell_score_list.Clear(),S.W.Inst_get().ReqResolveFashionDressItem(e)}UpdatePanel(t){this.UpdateGrid(),this.UpdateCabinetInfo()}UpdateGrid(){
const t=f.X.Inst_get().GetResolveList()
p.V.ins.bag_sell_score_list=t
let e=new d.Z
for(let i=0;i<=t.Count()-1;i++){const s=t[i],n=new I.Y
n.Clone(s),n.baseData_get().IconType_Set(g.s.BAG_SELL_ICON_TYPE),e.Add(n)}e=this.GetBagData(e)
const i=new d.Z
for(let t=0;t<=e.Count()-1;t++){const s=e[t]
null!=s?i.Add(s.baseData_get()):i.Add(null)}this.bagShowGrid.SetData(i),this.img_grid_bg.heightSet(i.Count()/8*60),null!=this.delayId&&this.ClearDelayId(),
this.delayId=o.C.Inst_get().SetFrameLoop(this.CreateDelegate(this.DelayReposition),2,1)}DelayReposition(){}ClearDelayId(){
null!=this.delayId&&(o.C.Inst_get().ClearInterval(this.delayId),this.delayId=null)}GetBagData(t){let e=new d.Z
e=c.g.Inst_get().GetShowListByClient(t,this.bagShowGrid.column_cnt)
let i=e.Count()
for(;i<t.Count();)e.Add(null),i+=1
const s=e.Count()%this.bagShowGrid.column_cnt
let n=0
if(e.Count()>=this.bagShowGrid.column_cnt*this.bagShowGrid.row_cnt?s>0&&(n=this.bagShowGrid.column_cnt-s):n=this.bagShowGrid.column_cnt*this.bagShowGrid.row_cnt-e.Count(),
n>0)for(let t=0;t<=n-1;t++)e.Add(null)
return e}UpdateCabinetInfo(){const t=this.model.fashionInfo,e=t.exp.ToNum()
if(-1!=this.curExp&&e>this.curExp&&(this.expAddEff.SetActive(!1),this.expAddEff.SetActive(!0)),-1!=this.curLv&&t.level>this.curLv&&(this.expAddEff.SetActive(!1),
this.expAddEff.SetActive(!0),this.lvUpEff.SetActive(!1),this.lvUpEff.SetActive(!0)),this.curLv=t.level,this.curExp=e,this.UpdateExp(),0==t.level)this.emptyAttr.SetActive(!0),
this.attrGrid.data_set(null)
else{this.emptyAttr.SetActive(!1)
const t=T.L.Inst().getCabinetItemById(this.curLv+1),e=T.L.Inst().getCabinetAttrsById(t.id)
this.attrGrid.data_set(e)}}UpdateExp(){if(-1!=this.curLv){let t=0
const e=p.V.ins.bag_sell_score_list.GetRange(0,p.V.ins.bag_sell_score_list.Count())
for(let i=0;i<=e.Count()-1;i++){const s=e[i].baseData_get().cfgData_get().rewards
t+=h.M.String2Int(s.typevalues[0].value)*e[i].serverData_get().num}this.lvLabel.textSet(h.M.Replace(this.lvLabelFormat,"{0}",this.curLv.toString()))
let i=this.curExp+t,s=this.curLv,n=T.L.Inst().getCabinetItemById(s+1)
if(n.nextLevel>n.level){let e=n.magnificent
const l=e
if(0==t){this.nextLvLabel.node.SetActive(!1),this.progressLabel.textSet(`${i}/${e}`)
const t=i/e>1?1:i/e
this.progressSp.fillAmountSet(t)}else{for(;i>=e&&(i-=e,s+=1,n=T.L.Inst().getCabinetItemById(s+1),!(n.nextLevel<n.level));)e=n.magnificent
s>this.curLv?(this.nextLvLabel.node.SetActive(!0),this.nextLvLabel.textSet(s.toString())):this.nextLvLabel.node.SetActive(!1)
let a=(this.curExp+t)/l
a=a>1?1:a,this.progressSp.fillAmountSet(a)}}else this.nextLvLabel.node.SetActive(!1),this.progressLabel.textSet("MAX"),this.progressSp.fillAmountSet(1)}}})||s},67605:(t,e,i)=>{
i.d(e,{D:()=>V})
var s,n,l=i(18998),a=i(72574),r=i(83908),o=i(38836),h=i(11210),d=i(28236),_=i(64213),u=i(32697),I=i(20583),c=i(51868),g=i(5494),p=i(60130),m=i(95721),S=i(98885),T=i(85602),f=i(38962),C=i(70850),E=i(63076),A=i(45538),L=i(18152),y=i(78592),D=i(92679),O=i(87923),R=i(38908),N=i(13476),M=i(42534),w=i(38486),P=i(14792),v=i(62734),k=i(65793),U=i(8434),G=i(66476),F=i(5727),B=i(7019)
const{ccclass:H}=l._decorator
let V=H("RyFashionView")((n=class t extends((0,r.pA)(c.$)()){constructor(...t){super(...t),this.model=null,this.roleInfo=null,this.pInfo=null,this.m_player=null,this.dressMap=null,
this.isReadyPlayEffect=!1,this.suitNameFormat=null,this.dataList=null,this.guardDisplay=null,this.roleRotateIndex=null,this.equipmentVOs=null,this.displayUIAvatarModel=null}
_initBinder(){super._initBinder(),this.model=F.X.Inst_get(),this.dressMap=new f.X}InitView(){super.InitView(),
this.grid.SetInitInfo("ui_surface_fashionitem_ry",null,B._,null,L.s.BASE_ICON_NO_EQUIPEX),this.grid.OnReposition_set(this.CreateDelegate(this.PlayUnlockEffect)),
this.suitNameFormat=this.suitNameLabel.text()}_OnUpdateAnchor(){p.O.SetAnchorPos(this.rightAnchor,!1,!0,0,!1)}UpdateAllItemData(){this.grid.data_set(this.dataList)}
UpdateFashionInfo(){const t=this.model.selectFashionData
if(null==t)return
this.fashionName.textSet(t.res.name)
const e=t.attrs.attrs
let i="",s=0
for(;s<e.Count();)t.isLock?i+=`[666666]${O.l.GetAttName(e[s].intType)}+${O.l.getAttrValueStr(e[s].intType,e[s].value)}[-]\n`:i+=`${O.l.GetAttName(e[s].intType)}[047104]+${O.l.getAttrValueStr(e[s].intType,e[s].value)}[-]\n`,
s+=1
this.attrLabel.textSet(i)
const n=G.L.Inst().getSuitAttrItemBySuitId(t.res.suitId),l=this.model.GetActiveNum(this.pInfo.m_id,t.res.suitId)>=n.suitNum
this.suitNameLabel.textSet(S.M.Replace(this.suitNameFormat,"{0}",t.suitRes.suitNum.toString()))
const a=t.suitAttrs.attrs
let r=""
for(s=0;s<a.Count();)r+=l?`${O.l.GetAttName(a[s].intType)}[047104]+${O.l.getAttrValueStr(a[s].intType,a[s].value)}[-]\n`:`[666666]${O.l.GetAttName(a[s].intType)}+${O.l.getAttrValueStr(a[s].intType,a[s].value)}[-]\n`,
s+=1
this.suitAttrLabel.textSet(r)
const o=new E.M(t.consumes)
if(o.showNum=!1,o.needNum=1,o.isCanOperate=!1,this.ui_baseitem.SetData(o),t.isLock){
C.g.Inst_get().GetItemByModleID(t.consumes)?this.equipBtn.SetText("激活"):1==this.model.selectFashionData.isPreview?this.equipBtn.SetText("脱下"):this.equipBtn.SetText("穿戴")
}else t.isWear?this.equipBtn.SetText("脱下"):this.equipBtn.SetText("穿戴")
const h=v.f.Inst.GetData(P.t.CHARACTER_FASHION_CABINET)
null!=h&&this.redPoint.SetActive(h.show),this.tween.ResetToBeginning(),this.tween.PlayForward()}SetData(){y.l.inst.SetRedPointId(P.t.CHARACTER_FASHION_ROLE),
this.model.selectFashionData=null,this.pInfo=h.i.Inst.GetCurSelect(g.I.CharacterUIPanel),this.dressMap.LuaDic_Clear()
for(const[t,e]of(0,o.V5)(this.pInfo.Fashions_get()))this.dressMap[t]=e
this._OnUpdateAnchor(),this.SetDefaultFashion(),this.UpdateView(),this.RemoveEvent(),this.AddEvent()}AddEvent(){
this.model.AddEventHandler(F.X.SELECT_EQUIP,this.CreateDelegate(this.SelectOne)),this.model.AddEventHandler(F.X.UPDATE_FASHION,this.CreateDelegate(this.UpdateView)),
this.model.AddEventHandler(F.X.UNLOCK_FASHION,this.CreateDelegate(this.ReadyPlayUnlockEffect)),this.m_handlerMgr.AddClickEvent(this.equipBtn,this.CreateDelegate(this.OnBtnClick)),
this.m_handlerMgr.AddClickEvent(this.attrBtn,this.CreateDelegate(this.OnAttrClick)),this.m_handlerMgr.AddClickEvent(this.cabinetBtn,this.CreateDelegate(this.OnCabinetClick)),
this.m_handlerMgr.AddEventMgr(D.g.UPDATE_ANCHORS,this.CreateDelegate(this._OnUpdateAnchor)),this.RegGuide()}RemoveEvent(){
this.model.RemoveEventHandler(F.X.SELECT_EQUIP,this.CreateDelegate(this.SelectOne)),this.model.RemoveEventHandler(F.X.UPDATE_FASHION,this.CreateDelegate(this.UpdateView)),
this.model.RemoveEventHandler(F.X.UNLOCK_FASHION,this.CreateDelegate(this.ReadyPlayUnlockEffect))}RegGuide(){}UnRegGuide(){}OnBtnClick(){if(this.model.selectFashionData.isLock){
C.g.Inst_get().GetItemByModleID(this.model.selectFashionData.consumes)?k.W.Inst_get().ReqUnlockFashionDress(this.pInfo.m_id,this.model.selectFashionData.res.id):(1==this.model.selectFashionData.isPreview?(this.model.selectFashionData.isPreview=!1,
this.equipBtn.SetText("穿戴"),this.dressMap.LuaDic_Remove(this.model.selectFashionData.res.position)):(this.model.selectFashionData.isPreview=!0,this.equipBtn.SetText("脱下"),
this.dressMap[this.model.selectFashionData.res.position]=this.model.selectFashionData.res.id),this.ShowModel(),this.UpdateAllItemData())
}else this.model.selectFashionData.isWear?k.W.Inst_get().ReqWearFashionDress(this.pInfo.m_id,this.model.selectFashionData.res.id,!1):k.W.Inst_get().ReqWearFashionDress(this.pInfo.m_id,this.model.selectFashionData.res.id,!0)
}OnAttrClick(){k.W.Inst_get().OpenFashionAttrView(!1)}OnCabinetClick(){k.W.Inst_get().OpenFashionCabinetView()}SetDefaultFashion(){let t=!1
this.dataList=this.model.GetFashionShowData(this.pInfo.m_id)
let e=0
for(;e<this.dataList.Count();){if(this.dataList[e].isPreview=!1,this.dataList[e].canActive){this.model.selectFashionData=this.dataList[e],t=!0
break}e+=1}let i=null
if(null==this.model.selectFashionData){let t=0
for(;t<this.dataList.Count();){if(this.dataList[t].isWear)if(null==i)i=this.dataList[t].res.position,this.model.selectFashionData=this.dataList[t]
else if(i==U.$.Weapon&&this.dataList[t].res.position==U.$.Body){this.model.selectFashionData=this.dataList[t]
break}t+=1}}if(null==this.model.selectFashionData){let e=0
for(;e<this.dataList.Count();){if(!this.dataList[e].isLock){this.model.selectFashionData=this.dataList[e],t=!0
break}e+=1}}null==this.model.selectFashionData&&(this.model.selectFashionData=this.dataList[0]),this.model.selectFashionData.isPreview=!0}SelectOne(){this.UpdateFashionInfo(),
this.ShowModel()}UpdateView(){this.ShowModel(),this.UpdateAllItemData(),this.UpdateFashionInfo()}ReadyPlayUnlockEffect(){this.isReadyPlayEffect=!0}PlayUnlockEffect(){
if(this.scrllView.ResetPosition(),this.isReadyPlayEffect){
if(!this.pInfo.Fashions_get().LuaDic_ContainsKey(this.model.selectFashionData.res.position))return void k.W.Inst_get().ReqWearFashionDress(this.pInfo.m_id,this.model.selectFashionData.res.id,!0)
this.isReadyPlayEffect=!1
for(let t=0;t<=this.grid.itemList.Count()-1;t++)this.grid.itemList[t].data.res.id==this.model.selectFashionData.res.id&&this.grid.itemList[t].PlayUnlockEffect()}}ClearRole(){
null!=this.guardDisplay&&(this.guardDisplay.Destroy(),this.guardDisplay=null),null!=this.m_player&&(this.m_player.Destroy(),this.m_player=null)}GetRoleInfo(){this.roleInfo=new d.H,
this.roleInfo.Id_set(m.o.ZERO),this.roleInfo.Job_set(this.pInfo.Job_get()),this.roleInfo.Sex_set(this.pInfo.Sex_get()),this.roleInfo.Name_set(""),this.roleInfo.ServerName_set(""),
this.roleInfo.Server_set(""),this.roleInfo.equipmentStorageVO=this.pInfo.equipmentStorageVO
const t=new w.v
t.talentIds=new T.Z,t.addMasterLevel=0,t.unlockColumn=!0
if((new f.X)[0]=t,this.model.selectFashionData)if(this.model.selectFashionData.isPreview)this.dressMap[this.model.selectFashionData.res.position]=this.model.selectFashionData.res.id
else{const t=this.pInfo.Fashions_get()
t.LuaDic_GetItem(this.model.selectFashionData.res.position)&&(this.dressMap[this.model.selectFashionData.res.position]=t[this.model.selectFashionData.res.position])}
this.roleInfo.Fashions_set(this.dressMap)}ShowModel(){this.ClearRole(),this.GetRoleInfo(),
this.displayUIAvatarModel=I.x.inst.SetUIAvatarData(this.roleInfo,u.v.role,this.displayUIAvatarModel,null,!0),this.displayUIAvatarModel.SetTarget(this.roleTexture.node,!0),
this.displayUIAvatarModel.SetDir(4),this.displayUIAvatarModel.SetScale(1,1),this.displayUIAvatarModel.SetAct(a.Bv.FightIdle),this.displayUIAvatarModel.RefreshTargetUI()}
ResetGuardDisplay(){const e=this.equipmentVOs.LuaDic_GetItem(A._.POS_GUARD)
if(null==e)return void(null!=this.guardDisplay&&(this.guardDisplay.Destroy(),this.guardDisplay=null))
const i=e.equipments
if(null==i)return void(null!=this.guardDisplay&&(this.guardDisplay.Destroy(),this.guardDisplay=null))
const s=i.modelId
if(null!=this.guardDisplay){if(this.guardDisplay.DisplayID_get()==s)return
this.guardDisplay.Destroy(),this.guardDisplay=null}let n=M.f.Inst().getItemById(s).guardModel
n=N.E.Instance.TryReplaceDisplayID(R.C.ReplaceTypeGUARD,n),this.guardDisplay=new _.r,this.guardDisplay.SetDisplayID(n,t.STAGE_ID,1)}Clear(){y.l.inst.SetRedPointId(null),
super.Clear(),this.RemoveEvent(),this.model.selectFashionData=null,this.isReadyPlayEffect=!1,this.UnRegGuide(),this.ClearRole()}Destroy(){this.Clear()}Test1(){return!0}S_Test(){
return!0}},n.STAGE_ID=77,s=n))||s},2787:(t,e,i)=>{i.d(e,{j:()=>c})
var s,n=i(6847),l=i(83908),a=i(49655),r=i(46282),o=i(11210),h=i(5494),d=i(18152),_=i(65793),u=i(5727),I=i(24338)
let c=(0,n.s_)(a.o.RySurfaceSelectView,r.Z.ui_surface_show_selectview_ry).register()(s=class extends((0,l.Ri)()){InitView(){
this.grid.SetInitInfo("ui_surface_showitem_ry",null,I.$,null,d.s.BASE_ICON_NO_EQUIPEX)}OnAddToScene(){super.OnAddToScene()
let t=null,e=null
const i=u.X.Inst_get().selectData.isEquip,s=u.X.Inst_get().selectData.isFashion
null!=u.X.Inst_get().selectData.vo?(t=u.X.Inst_get().selectData.vo.equipments,this.takeOffbtn.SetActive(!0)):null!=u.X.Inst_get().selectData.fashionData?(e=u.X.Inst_get().selectData.fashionData,
this.takeOffbtn.SetActive(!0)):this.takeOffbtn.SetActive(!1)
const n=o.i.Inst.GetCurSelect(h.I.RySurfaceSettingView),l=u.X.Inst_get().GetShowReplaceDatas(n,u.X.Inst_get().selectData,t,e,i,s)
this.grid.data_set(l),this.AddEvent()}AddEvent(){this.m_handlerMgr.AddClickEvent(this.takeOffbtn,this.CreateDelegate(this.OffHandler)),
this.m_handlerMgr.AddClickEvent(this.mask,this.CreateDelegate(this.CloseHandler))}OffHandler(){u.X.Inst_get().replaceData=u.X.Inst_get().selectData,
u.X.Inst_get().RaiseEvent(u.X.REPLACE_EQUIP),this.CloseHandler()}CloseHandler(){_.W.Inst_get().CloseRySurfaceSelectView()}Clear(){super.Clear()}Destroy(){}Test1(){return!0}
S_Test(){return!0}})||s},6213:(t,e,i)=>{i.d(e,{H:()=>G})
var s,n,l=i(6847),a=i(83908),r=i(49655),o=i(46282),h=i(40053),d=i(38836),_=i(32697),u=i(11210),I=i(28236),c=i(20583),g=i(50838),p=i(70650),m=i(85682),S=i(5494),T=i(95721),f=i(85602),C=i(38962),E=i(45538),A=i(18152),L=i(75321),y=i(87923),D=i(41748),O=i(3256),R=i(42534),N=i(33138),M=i(89799),w=i(29843),P=i(65793),v=i(8434),k=i(5727),U=i(24338)
let G=(0,l.s_)(r.o.RySurfaceSettingView,o.Z.ui_surface_settingview_ry).waitPrefab(h.Z.BaseItem_ry_basePrefabs).register()(((n=class extends((0,a.Ri)()){constructor(...t){
super(...t),this.defaultSelectRoleTab=-1,this.roleInfo=null,this.pInfo=null,this.m_player=null,this.guard=null,this.autoSlectMenuData=null,this.fashionSlectMenuData=null,
this.dataList=null,this.dressMap=null,this.equipmentVOs=null,this.menuData=null,this.fashionList=null,this.guardDisplay=null,this.roleRotateIndex=null,
this.displayUIAvatarModel=void 0,this.equipList=new C.X}InitView(){this.roleInfo=null,this.pInfo=null,this.m_player=null,this.guard=null,this.autoSlectMenuData=null,
this.fashionSlectMenuData=null,this.menuView.guideOpenId=m.D.UI_ROLE_ATTR_SURFACE_MENU_BTN,this.menuView.SetInitInfo("ui_surface_menuitem_ry"),
this.grid.SetInitInfo("ui_surface_showitem_ry",null,U.$,null,A.s.BASE_ICON_NO_EQUIPEX),this.grid.OnReposition_set(this.CreateDelegate(this.OnReposition)),this.grid.Reposition(),
this.ui_charactertab.SetData(S.I.RySurfaceSettingView),this.ui_charactertab.onChanged=this.CreateDelegate(this.OnSelectRole),this.InitData(),this.displayUIAvatarModel=new g.o,
this.displayUIAvatarModel.SetTarget(this.roleUIAvatar,!0),this.displayUIAvatarModel.SetResHD(!0),this.displayUIAvatarModel.SetScale(.9,.9),this.InitEquipList()}OnReposition(){
this.scollview.ResetPosition()}InitEquipList(){this.equipList.LuaDic_AddOrSetItem(0,this.ui_surface_showitem_ry_0),
this.equipList.LuaDic_AddOrSetItem(1,this.ui_surface_showitem_ry_1),this.equipList.LuaDic_AddOrSetItem(3,this.ui_surface_showitem_ry_3),
this.equipList.LuaDic_AddOrSetItem(10,this.ui_surface_showitem_ry_10),this.equipList.LuaDic_AddOrSetItem(11,this.ui_surface_showitem_ry_11)}InitData(t){
this.dataList=k.X.Inst_get().GetSettingShowData(),this.dressMap=new C.X}OnAddToScene(){const t=u.i.Inst.GetCurSelect(S.I.CharacterUIPanel)
t?this.ui_charactertab.SetCurSelectIdx(t.createIdx,!0,!0):this.ui_charactertab.SetCurSelectIdx(0,!0,!0)}OnSelectRole(t){k.X.Inst_get().GetInfoFacadeEquipmentSetting(t),
k.X.Inst_get().selectStage=k.X.Inst_get().stage,this.SetData()}ClearOneData(t,e,i,s){
if(i)for(let e=0;e<=this.dataList.count-1;e++)this.dataList[e].pos==t&&(this.dataList[e].fashionData=null,
k.X.Inst_get().GetSurfacePos(v.$.Weapon)==t&&this.dressMap.LuaDic_Remove(v.$.Weapon),k.X.Inst_get().GetSurfacePos(v.$.Body)==t&&this.dressMap.LuaDic_Remove(v.$.Body))
if(e){for(let e=0;e<=this.dataList.count-1;e++)this.dataList[e].pos==t&&(this.dataList[e].vo=null,this.dataList[e].wingRefine=null)
this.equipmentVOs.LuaDic_AddOrSetItem(t,null)}this.UpdateEquipListData(this.dataList),this.ShowModel(!1,!0),this.ResetGuardDisplay()}SetOneData(t,e,i,s,n){let l=null
if(null!=s){for(let e=0;e<=this.dataList.count-1;e++)this.dataList[e].pos==t&&(this.dataList[e].fashionData=s,this.dataList[e].isFashion=!0,this.dataList[e].isEquip=!1,
this.dressMap[s.res.position]=s.res.id)
this.EquipOff()}if(null!=e){for(let s=0;s<=this.dataList.count-1;s++)if(this.dataList[s].pos==t)if(this.dataList[s].fashionData=null,this.dataList[s].isFashion=!1,
this.dataList[s].isEquip=!0,l=this.dataList[s].vo,null==l&&(l=new w.H,this.dataList[s].vo=l),l.clomn=i,l.itemModelId=e.modelId,l.excellenceAttributeModels=e.exellectAttrs,
l.enhanceLevel=e.Enhancelevel_get(),l.isShowVO=!0,l.isEffective=e.isEffective,l.nowModelId=0,l.equipments=e,n&&(l.showRefine=n.isShow,this.dataList[s].wingRefine=n),
t==L.C.PART_WEAPON_LEFT||t==L.C.PART_WEAPON_RIGHT){
for(let t=0;t<=this.dataList.count-1;t++)this.dataList[t].pos!=L.C.PART_WEAPON_RIGHT&&this.dataList[t].pos!=L.C.PART_WEAPON_LEFT||(this.dataList[t].fashionData=null,
this.dataList[t].isFashion=!1,this.dataList[t].isEquip=!0)
this.dressMap.LuaDic_Remove(v.$.Weapon)}else if(t!=L.C.PART_WINGS&&t!=L.C.PART_GUARD){
for(let t=0;t<=this.dataList.count-1;t++)this.dataList[t].pos==L.C.PART_CLOTHES&&(this.dataList[t].fashionData=null,this.dataList[t].isFashion=!1,this.dataList[t].isEquip=!0)
this.dressMap.LuaDic_Remove(v.$.Body)}this.equipmentVOs.LuaDic_AddOrSetItem(t,l)}this.UpdateEquipListData(this.dataList),this.ShowModel(!1,!0),this.ResetGuardDisplay()}
UpdateEquipListData(t){for(let e=0;t&&e<t.count;e++){if(!t[e]||null==t[e].pos)continue
const i=this.equipList.LuaDic_GetItem(t[e].pos)
i&&i.node&&i.SetData(t[e])}}UpdateAllItemData(){const t=new f.Z
if(this.menuData&&this.menuData.selectData&&1==this.menuData.selectData.key)for(let e=0;e<=this.dataList.count-1;e++)k.X.Inst_get().GetSurfacePos(v.$.Weapon)==this.dataList[e].pos&&t.Add(this.dataList[e]),
k.X.Inst_get().GetSurfacePos(v.$.Body)==this.dataList[e].pos&&t.Add(this.dataList[e]),
this.dataList[e].pos!=L.C.PART_WINGS&&this.dataList[e].pos!=L.C.PART_GUARD||t.Add(this.dataList[e])
else t.AddRange(this.dataList)
this.UpdateEquipListData(t)}SetData(){this.pInfo=u.i.Inst.GetCurSelect(S.I.RySurfaceSettingView),this.dressMap.LuaDic_Clear()
for(const[t,e]of(0,d.V5)(this.pInfo.Fashions_get()))this.dressMap[t]=e
this.menuData=new D.l
const t=new f.Z
let e=new O.R
e.key=-1,e.showStr="默认",t.Add(e),k.X.Inst_get().stage==e.key&&(this.menuData.selectData=e),e=new O.R,e.key=0,e.showStr="自定义",e.handler=this.CreateDelegate(this.MenuClickHandler),
this.autoSlectMenuData=e
N.f.Inst().equipStepMaxLv
k.X.Inst_get().stage==e.key&&(this.menuData.selectData=e),t.Add(e),this.menuData.handler=this.CreateDelegate(this.MenuClickHandler),
this.fashionList=k.X.Inst_get().GetFashionShowData(this.pInfo.Id_get())
for(let e=0;e<=this.fashionList.count-1;e++)if(!this.fashionList[e].isLock){const e=new O.R
e.key=1,e.showStr="时装",e.handler=this.CreateDelegate(this.MenuClickHandler),this.fashionSlectMenuData=e,k.X.Inst_get().stage==e.key&&(this.menuData.selectData=e),t.Add(e),
this.menuData.handler=this.CreateDelegate(this.MenuClickHandler)
break}const i=k.X.Inst_get().ClomnToStage
let s=i.count-1
for(;s>0;){const n=this.pInfo.GetEquipmentsByColumn(s)
null!=n&&n.unlockColumn&&(e=new O.R,e.key=i[s],e.showStr=1==s?`${y.l.GetChineseNum(i[s])}阶以下`:`${y.l.GetChineseNum(i[s])}阶`,e.guideId=m.D.UI_ROLE_ATTR_SURFACE_MENU_BTN,
e.guideParam=i[s],k.X.Inst_get().stage==i[s]&&(this.menuData.selectData=e),t.Add(e)),s-=1}this.menuData.dataList=t,this.SetDefalutSeletcMenuData(),
this.menuView.InitData(this.menuData),this.UpdateView(!1),this.AddEvent()}AddEvent(){k.X.Inst_get().AddEventHandler(k.X.SELECT_EQUIP,this.CreateDelegate(this.SelectOne)),
k.X.Inst_get().AddEventHandler(k.X.REPLACE_EQUIP,this.CreateDelegate(this.ReplceOne)),this.m_handlerMgr.AddClickEvent(this.saveBtn,this.CreateDelegate(this.SaveHandler)),
this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.OnCloseClick)),this.RegGuide()}RemoveEvent(){
k.X.Inst_get().RemoveEventHandler(k.X.SELECT_EQUIP,this.CreateDelegate(this.SelectOne)),k.X.Inst_get().RemoveEventHandler(k.X.REPLACE_EQUIP,this.CreateDelegate(this.ReplceOne))}
RegGuide(){}UnRegGuide(){}SaveHandler(){const t=this.pInfo.Fashions_get()
if(!this.menuData.selectData||1!=this.menuData.selectData.key&&0!=this.menuData.selectData.key){
P.W.Inst_get().ReqSaveEquipFacadeSetting(this.pInfo.m_id,this.dataList,this.menuData.selectData.key)
for(const[e,i]of(0,d.V5)(t))P.W.Inst_get().ReqWearFashionDress(this.pInfo.m_id,i,!1)}else{
1==this.menuData.selectData.key?P.W.Inst_get().ReqSaveEquipFacadeSetting(this.pInfo.m_id,this.dataList,k.X.Inst_get().stage):0==this.menuData.selectData.key&&P.W.Inst_get().ReqSaveEquipFacadeSetting(this.pInfo.m_id,this.dataList,this.menuData.selectData.key)
for(const[e,i]of(0,d.V5)(t))this.dressMap.LuaDic_ContainsKey(e)||P.W.Inst_get().ReqWearFashionDress(this.pInfo.m_id,i,!1)
for(const[e,i]of(0,d.V5)(this.dressMap))t[e]!=i&&P.W.Inst_get().ReqWearFashionDress(this.pInfo.m_id,i,!0)}}OnCloseClick(){P.W.Inst_get().CloseSurfaceSettingView()}SelectOne(){}
ReplceOne(){const t=k.X.Inst_get().selectData,e=k.X.Inst_get().replaceData
null!=e&&(this.menuData.selectData=this.autoSlectMenuData,k.X.Inst_get().selectStage=this.autoSlectMenuData.key,this.menuView.UpdateText(),
t==e?this.ClearOneData(t.pos,t.isEquip,t.isFashion,t):this.SetOneData(t.pos,e.equipments,e.clomn,e.fashionData,e.wingRefine)),k.X.Inst_get().replaceData=null}MenuClickHandler(t){
this.menuData.selectData=t,k.X.Inst_get().selectStage=t.key,this.UpdateView(!0)}UpdateView(t){this.ShowModel(t),this.UpdateAllItemData()}ClearRole(){
null!=this.guardDisplay&&(this.guardDisplay.Destroy(),this.guardDisplay=null),null!=this.roleRotateIndex&&p.e.GetInst().UnregDrag(this.roleRotateIndex),
null!=this.m_player&&(this.m_player.Destroy(),this.m_player=null),this.roleTexture.node.SetActive(!1)}GetRoleInfo(t,e){this.roleInfo=new I.H,this.roleInfo.Id_set(T.o.ZERO),
this.roleInfo.Job_set(this.pInfo.Job_get()),this.roleInfo.Sex_set(this.pInfo.Sex_get()),this.roleInfo.Name_set(""),this.roleInfo.ServerName_set(""),this.roleInfo.Server_set("")
const i=new M.U
if(this.roleInfo.equipmentStorageVO=i,t){if(this.menuData.selectData.key>1){this.equipmentVOs=k.X.Inst_get().GetEquipVo(this.pInfo,this.menuData.selectData.key)
for(let t=0;t<=this.dataList.count-1;t++)this.equipmentVOs.LuaDic_ContainsKey(this.dataList[t].pos)?this.dataList[t].vo=this.equipmentVOs[this.dataList[t].pos]:this.dataList[t].vo=null,
this.dataList[t].fashionData=null,this.dataList[t].isFashion=!1,this.dataList[t].isEquip=!0
this.dressMap.LuaDic_Clear()}else if(1==this.menuData.selectData.key){this.dressMap.Clear()
for(let t=0;t<=this.dataList.count-1;t++){
for(let e=0;e<=this.fashionList.count-1;e++)this.fashionList[e].isLock||this.dressMap.LuaDic_ContainsKey(this.fashionList[e].res.position)||k.X.Inst_get().GetSurfacePos(this.fashionList[e].res.position)==this.dataList[t].pos&&(this.dressMap[this.fashionList[e].res.position]=this.fashionList[e].res.id,
this.dataList[t].fashionData=this.fashionList[e])
this.dataList[t].pos!=L.C.PART_WEAPON_LEFT&&this.dataList[t].pos!=L.C.PART_CLOTHES?(this.dataList[t].isFashion=!1,this.dataList[t].isEquip=!0):(this.dataList[t].vo=null,
this.dataList[t].isFashion=!0,this.dataList[t].isEquip=!1)}}else if(0==this.menuData.selectData.key){
this.equipmentVOs=k.X.Inst_get().GetEquipVo(this.pInfo,this.menuData.selectData.key)
for(let t=0;t<=this.dataList.count-1;t++)this.dataList[t].vo=null,this.dataList[t].fashionData=null,this.dataList[t].isFashion=!1,this.dataList[t].isEquip=!0
this.dressMap.LuaDic_Clear()}else if(-1==this.menuData.selectData.key){this.equipmentVOs=k.X.Inst_get().GetEquipVo(this.pInfo,this.menuData.selectData.key)
for(let t=0;t<=this.dataList.count-1;t++)this.equipmentVOs.LuaDic_ContainsKey(this.dataList[t].pos)?this.dataList[t].vo=this.equipmentVOs[this.dataList[t].pos]:this.dataList[t].vo=null,
this.dataList[t].fashionData=null,this.dataList[t].isFashion=!1,this.dataList[t].isEquip=!0
this.dressMap.LuaDic_Clear()}
}else if(e)for(let t=0;t<=this.dataList.count-1;t++)this.equipmentVOs.LuaDic_ContainsKey(this.dataList[t].pos)?this.dataList[t].vo=this.equipmentVOs[this.dataList[t].pos]:this.dataList[t].vo=null
else if(this.equipmentVOs=k.X.Inst_get().GetInfoFacadeEquipmentSetting(this.pInfo),
this.menuData&&this.menuData.selectData&&(-1==this.menuData.selectData.key||this.menuData.selectData.key>1)){
for(let t=0;t<=this.dataList.count-1;t++)this.equipmentVOs.LuaDic_ContainsKey(this.dataList[t].pos)?this.dataList[t].vo=this.equipmentVOs[this.dataList[t].pos]:this.dataList[t].vo=null,
this.dataList[t].fashionData=null,this.dataList[t].isFashion=!1,this.dataList[t].isEquip=!0
this.dressMap.LuaDic_Clear()}else{for(let t=0;t<=this.dataList.count-1;t++){
this.equipmentVOs.LuaDic_ContainsKey(this.dataList[t].pos)?this.dataList[t].vo=this.equipmentVOs[this.dataList[t].pos]:this.dataList[t].vo=null
for(let e=0;e<=this.fashionList.count-1;e++)if(this.fashionList[e].isWear){if(k.X.Inst_get().GetSurfacePos(this.fashionList[e].res.position)==this.dataList[t].pos){
this.dressMap[this.fashionList[e].res.position]=this.fashionList[e].res.id,this.dataList[t].fashionData=this.fashionList[e],this.dataList[t].isFashion=!0,
this.dataList[t].isEquip=!1
break}}else this.dataList[t].fashionData=null,this.dataList[t].isFashion=!1,this.dataList[t].isEquip=!0}this.EquipOff()}
this.roleInfo.equipmentStorageVO.equipmentVOs=this.equipmentVOs,this.roleInfo.Fashions_set(this.dressMap),k.X.Inst_get().dressMap=this.dressMap}EquipOff(){
for(let t=0;t<=this.dataList.count-1;t++)this.dressMap.LuaDic_ContainsKey(v.$.Weapon)&&(this.dataList[t].pos!=L.C.PART_WEAPON_LEFT&&this.dataList[t].pos!=L.C.PART_WEAPON_RIGHT||(this.dataList[t].vo=null,
this.dataList[t].isFashion=!0,this.dataList[t].isEquip=!1,this.equipmentVOs.LuaDic_AddOrSetItem(this.dataList[t].pos,null))),
this.dressMap.LuaDic_ContainsKey(v.$.Body)&&this.dataList[t].pos!=L.C.PART_WINGS&&this.dataList[t].pos!=L.C.PART_GUARD&&this.dataList[t].pos!=L.C.PART_WEAPON_LEFT&&this.dataList[t].pos!=L.C.PART_WEAPON_RIGHT&&(this.dataList[t].vo=null,
this.dataList[t].isFashion=!0,this.dataList[t].isEquip=!1,this.equipmentVOs.LuaDic_AddOrSetItem(this.dataList[t].pos,null))}EquipmentVOs_set(t){
this.roleInfo.equipmentStorageVO.equipmentVOs=t}ShowModel(t,e){this.GetRoleInfo(t,e),c.x.inst.SetUIAvatarData(this.roleInfo,_.v.role,this.displayUIAvatarModel),
this.displayUIAvatarModel.RefreshTargetUI()}ResetGuardDisplay(){const t=this.equipmentVOs.LuaDic_GetItem(E._.POS_GUARD)
if(null==t)return void(null!=this.guardDisplay&&(this.guardDisplay.Destroy(),this.guardDisplay=null))
const e=t.equipments
if(null==e)return void(null!=this.guardDisplay&&(this.guardDisplay.Destroy(),this.guardDisplay=null))
const i=e.modelId
if(null!=this.guardDisplay){if(this.guardDisplay.DisplayID_get()==i)return
this.guardDisplay.Destroy(),this.guardDisplay=null}R.f.Inst().getItemById(i).guardModel}SetDefalutSeletcMenuData(){const t=k.X.Inst_get().ClomnToStage
if(this.menuData&&!this.menuData.selectData)for(let e=t.count-1;e>0;e--){const i=this.pInfo.GetEquipmentsByColumn(e)
if(null!=i&&i.unlockColumn){let i=new O.R
i.key=t[e],i.showStr=1==e?`${y.l.GetChineseNum(t[e])}阶以下`:`${y.l.GetChineseNum(t[e])}阶`,i.guideId=m.D.UI_ROLE_ATTR_SURFACE_MENU_BTN,i.guideParam=t[e],k.X.Inst_get().stage=t[e],
this.menuData.selectData=i,this.menuView.ItemClickHandler(this.menuData.selectData)
break}}}Clear(){k.X.Inst_get().selectStage=-1,this.defaultSelectRoleTab=-1,this.UnRegGuide(),this.menuView.ClearData(),super.Clear(),this.RemoveEvent()}Destroy(){}Test1(){return!0}
S_Test(){return!0}}).STAGE_ID=77,s=n))||s},7019:(t,e,i)=>{i.d(e,{_:()=>a})
var s=i(83908),n=i(28192),l=i(5727)
class a extends((0,s.yk)()){constructor(...t){super(...t),this.data=null,this.uidata=null,this._m_handlerMgr=null}get m_handlerMgr(){
return this._m_handlerMgr||(this._m_handlerMgr=n.h.Get()),this._m_handlerMgr}InitView(){super.InitView(),null!=this.ui_baseitem&&this.ui_baseitem.SetUIData(this.uidata)}
SetUIData(t){null!=this.ui_baseitem&&this.ui_baseitem.SetUIData(this.uidata),this.uidata=t}SetData(t){this.lock.SetActive(t.isLock),this.equiped.SetActive(t.isWear),
this.nameLabel.textSet(t.res.name),this.quality.skin="WEB:/icon/fashion/"+t.res.quality+".png",this.activeEffect.SetActive(t.canActive),
this.itemimg.skin="WEB:/icon/fashion/"+t.res.icon+".png",this.data=t,this.AddEvent(),this.SetSelect()}AddEvent(){
l.X.Inst_get().AddEventHandler(l.X.SELECT_EQUIP,this.CreateDelegate(this.SelectOne)),this.m_handlerMgr.AddClickEvent(this,this.CreateDelegate(this.ClickHandler))}RemoveEvent(){
l.X.Inst_get().RemoveEventHandler(l.X.SELECT_EQUIP,this.CreateDelegate(this.SelectOne))}SelectOne(){this.SetSelect()}ClickHandler(){
this.data.res.id!=l.X.Inst_get().selectFashionData.res.id&&(l.X.Inst_get().selectFashionData=this.data,l.X.Inst_get().selectFashionData.isPreview=!0,
l.X.Inst_get().RaiseEvent(l.X.SELECT_EQUIP))}SetSelect(){
null!=l.X.Inst_get().selectFashionData?(this.data.res.id==l.X.Inst_get().selectFashionData.res.id?this.select.SetActive(!0):(this.select.SetActive(!1),
this.data.res.position==l.X.Inst_get().selectFashionData.res.position&&(this.data.isPreview=!1)),
this.data.isPreview&&!l.X.Inst_get().isTargetFashion?this.preview.SetActive(this.data.isLock):this.preview.SetActive(!1)):this.select.SetActive(!1)}PlayUnlockEffect(){
this.unlockEffect.SetActive(!1),this.unlockEffect.SetActive(!0)}Clear(){this.unlockEffect.SetActive(!1),this.RemoveEvent()}Destroy(){}}},24338:(t,e,i)=>{i.d(e,{$:()=>L})
var s,n=i(18998),l=i(83908),a=i(11210),r=i(18202),o=i(5494),h=i(83540),d=i(28192),_=i(63076),u=i(45538),I=i(18152),c=i(58809),g=i(75321),p=i(74045),m=i(49067),S=i(87923),T=i(42534),f=i(91388),C=i(65793),E=i(8434),A=i(5727)
let L=n._decorator.ccclass("RySurfaceItem")(s=class extends((0,l.yk)()){constructor(...t){super(...t),this._m_handlerMgr=null,this.data=null,this.uidata=null,this.repalce=null,
this.resPath="atlas/qianghua/",this.shizhuangResPath="atlas/shizhuang/"}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=d.h.Get()),this._m_handlerMgr}
SetUIData(t){null!=this.ui_baseitem&&this.ui_baseitem.SetUIData(this.uidata),this.uidata=t}SetData(t){if(this.data=t,t.isSelectView)this.mask.SetActive(!1)
else{const t=this.IsShowMask()
this.mask.SetActive(t)}if(this.UnRegGuide(),this.bg.spriteNameSet(this.resPath+f.i.Inst().GetEquipBgSpriteName(t.pos)),this.bg.node.transform.setContentSize(new n.Size(74,74)),
null!=t&&(this.repalce=null!=t.equipments||null!=t.replaceFashionData),this.AddEvent(),this.SetSelect(),this.RegGuide(),null!=t.fashionData)return this.ui_baseitem.SetData(null),
this.ShowEmpty(),this.quality.spriteNameSet(c.s.shizhuang+t.fashionData.res.quality),this.itemimg.spriteNameSet(c.s.shizhuang+t.fashionData.res.icon),
void this.fashionitem.SetActive(!0)
if(this.fashionitem.SetActive(!1),(null==t.vo||null==t.vo.equipments)&&null==t.equipments)return this.ui_baseitem.SetData(null),this.ShowEmpty(),
void this.bg.node.setSiblingIndex(1)
this.bg.node.setSiblingIndex(0)
let e=t.equipments
null==e&&(e=t.vo.equipments)
const i=new _.M(e.modelId,e)
if(this.ui_baseitem._enabledClickOpenTip=!1,i.iconType=I.s.BASE_ICON_SURFACE_TYPE,this.ui_baseitem.SetData(i),i.isCanOperate=!1,i.isEquipCompare=!1,
t.vo?t.vo.showRefine?this.stageLab.textSet("幻形"):this.stageLab.textSet(`${S.l.GetChineseNum(A.X.Inst_get().GetStage(t.vo.clomn))}阶`):t.wingRefine&&t.wingRefine.isShow?this.stageLab.textSet("幻形"):this.stageLab.textSet(`${S.l.GetChineseNum(A.X.Inst_get().GetStage(t.clomn))}阶`),
this.showview.SetActive(!0),null!=t.wingRefine&&t.wingRefine.isShow&&t.equipments){const e=t.equipments.GetEquipRes()
e&&r.g.SetItemIcon(this.ui_baseitem.itemImg,e.refineEquipIcon,h.b.eItem)}else if(t.vo&&t.vo.showRefine){const e=T.f.Inst().getItemById(t.vo.itemModelId)
e&&r.g.SetItemIcon(this.ui_baseitem.itemImg,e.refineEquipIcon,h.b.eItem)}}RegGuide(){}UnRegGuide(){this.data}AddEvent(){
this.repalce||A.X.Inst_get().AddEventHandler(A.X.SELECT_EQUIP,this.CreateDelegate(this.SelectOne)),this.m_handlerMgr.AddClickEvent(this.bg,this.CreateDelegate(this.ClickHandler))}
RemoveEvent(){A.X.Inst_get().RemoveEventHandler(A.X.SELECT_EQUIP,this.CreateDelegate(this.SelectOne))}SelectOne(){this.SetSelect()}ShowEmpty(){this.showview.SetActive(!1)}
ClickHandler(){if(this.repalce)if(this.IsShowMask()){let t=null
t=this.data.pos==g.C.PART_WEAPON_RIGHT?"FASHION:TIPS1":"FASHION:TIPS2"
const e=new m.B
e.infoId=t,e.cancelHandle=null,e.cancelParam=null,e.confirmHandle=this.CreateDelegate(this.ConfirmHandler),p.t.Inst().Open(e)}else this.ConfirmHandler()
else{if(this.data.pos==u._.POS_WING&&this.data.clomn>0){const t=a.i.Inst.GetCurSelect(o.I.RySurfaceSettingView)
if(t){const e=t.GetWingRefine(this.data.clomn,this.data.pos)
e&&(this.data.wingRefine=e)}}A.X.Inst_get().selectData=this.data,A.X.Inst_get().RaiseEvent(A.X.SELECT_EQUIP),C.W.Inst_get().OpenReplaceView()}}ConfirmHandler(){
A.X.Inst_get().replaceData=this.data,A.X.Inst_get().RaiseEvent(A.X.REPLACE_EQUIP),C.W.Inst_get().CloseRySurfaceSelectView()}SetSelect(){
if(null==this.data||null==A.X.Inst_get().selectData||this.repalce)return void this.select.SetActive(!1)
const t=A.X.Inst_get().selectData.isEquip,e=A.X.Inst_get().selectData.isFashion
if(t)return null==this.data.vo?void this.select.SetActive(!1):void(this.data.isEquip?this.select.SetActive(this.data.pos==A.X.Inst_get().selectData.pos):this.select.SetActive(!1))
if(e){if(null==this.data.fashionData)return void this.select.SetActive(!1)
this.data.isFashion?this.select.SetActive(this.data.pos==A.X.Inst_get().selectData.pos):this.select.SetActive(!1)}}IsShowMask(){let t=!1
return A.X.Inst_get().dressMap.LuaDic_ContainsKey(E.$.Weapon)&&this.data.pos==g.C.PART_WEAPON_RIGHT&&(t=!0),
t||A.X.Inst_get().dressMap.LuaDic_ContainsKey(E.$.Body)&&this.data.pos!=g.C.PART_WINGS&&this.data.pos!=g.C.PART_GUARD&&this.data.pos!=g.C.PART_WEAPON_LEFT&&this.data.pos!=g.C.PART_WEAPON_RIGHT&&this.data.pos!=g.C.PART_CLOTHES&&(t=!0),
t}InitView(){null!=this.ui_baseitem&&this.ui_baseitem.SetUIData(this.uidata)}Clear(){this.UnRegGuide(),this.RemoveEvent()}Destroy(){}})||s},41759:(t,e,i)=>{i.d(e,{q:()=>q})
var s=i(38836),n=i(38045),l=i(98800),a=i(84581),r=i(63611),o=i(28475),h=i(45549),d=i(85602),_=i(38962),u=i(79534),I=i(61149),c=i(54383),g=i(33542),p=i(30635)
class m{constructor(t,e,i){this.mId=0,this.mc=null,this.distance=0,this.mId=t,this.mc=e,this.distance=i}}class S{constructor(t,e,i,s){this.type=0,this.name=null,this.isAttack=!1,
this.id=null,this.job=0,this.sex=0,this.distance=0,this.monsterType=null,this.configId=0,this.type=t,this.name=e,this.isAttack=s,this.id=i}sortValue_get(){return 1}SortFun(t,e){
const i=t,s=e
return i.isAttack&&s.isAttack?i.distance>s.distance?1:-1:i.isAttack||s.isAttack?1:"MONSTER_BOSS"==i.monsterType&&"MONSTER_BOSS"==s.monsterType?i.distance<s.distance?-1:1:"MONSTER_BOSS"==i.monsterType||"MONSTER_BOSS"==s.monsterType?1:i.type==a.s.role&&s.type==a.s.role?i.distance<s.distance?-1:1:i.type==a.s.role||s.type==a.s.role?1:i.distance<s.distance?-1:1
}}class T{constructor(){this.t_list=null,this.m_switchDic=null,this.m_selectedIds=null,this.exceptList=null,this.t_list=new d.Z,this.m_switchDic=new _.X,this.m_selectedIds=new d.Z}
GridData(){this.t_list.Clear()
const t=this.GetNearstPkOne(!1)
return null!=t?(this.t_list.Add(t),t.type==a.s.role?(this.AddBossAndMonsters(-1,1),this.AddBossAndMonsters(-1,3),this.AddOterPlayers(),
this.AddBossAndMonsters(-1,2)):t.type==a.s.monster&&(this.AddBossAndMonsters(-1,1),this.AddBossAndMonsters(t.configId,3),this.AddOterPlayers(),
this.AddBossAndMonsters(t.configId,2))):(this.AddBossAndMonsters(-1,1),this.AddBossAndMonsters(-1,3),this.AddOterPlayers(),this.AddBossAndMonsters(-1,2)),this.t_list}
AddBossAndMonsters(t,e){null==e&&(e=-1),null==t&&(t=-1)
const i=h.x.GetInst().curAttackMeTargetId,n=l.Y.MonsterDic,a=l.Y.Inst.PrimaryRole_get().GetPos()
let o=null,d=null,_=null,I=null
for(const[l,h]of(0,s.V5)(n)){const s=h.GetPos(),n=u.P.Distance(a,s)
n<T.MAX_DISTANCE&&(this.isSameAttId(i,h.objId)||(I=h.Cfg_get().objectType,1==e?I==r.b.MONSTER_BOSS&&(_=`${h.Cfg_get().name}(Lv.${h.Cfg_get().level})`,
o=new S(h.Roletype_get(),_,h.objId,!1),
o.distance=n,this.SetMonsterType(o,h),this.t_list.Add(o)):3==e?I!=r.b.MONSTER_ELITE&&I!=r.b.ACTIVITY_ELITE||(this.m_switchDic.LuaDic_ContainsKey(h.Cfg_get().id)?(d=this.m_switchDic[h.Cfg_get().id],
n<d.distance&&(this.m_switchDic[h.Cfg_get().id]=new m(h.Cfg_get().id,h,n))):t!=h.Cfg_get().id&&(d=new m(h.Cfg_get().id,h,n),
this.m_switchDic.LuaDic_AddOrSetItem(h.Cfg_get().id,d))):2==e&&I!=r.b.MONSTER_BOSS&&I!=r.b.MONSTER_ELITE&&I!=r.b.ACTIVITY_ELITE&&(this.m_switchDic.LuaDic_ContainsKey(h.Cfg_get().id)?(d=this.m_switchDic[h.Cfg_get().id],
n<d.distance&&(this.m_switchDic[h.Cfg_get().id]=new m(h.Cfg_get().id,h,n))):t!=h.Cfg_get().id&&(d=new m(h.Cfg_get().id,h,n),
this.m_switchDic.LuaDic_AddOrSetItem(h.Cfg_get().id,d)))))}for(const[t,e]of(0,s.V5)(this.m_switchDic)){const t=e.mc
_=`${t.Cfg_get().name}(Lv.${t.Cfg_get().level})`,o=new S(t.Roletype_get(),_,t.objId,!1),o.distance=e.distance,this.SetMonsterType(o,t),this.t_list.Add(o)}
this.m_switchDic.LuaDic_Clear()}SetMonsterType(t,e){e.Info_get().isGolden?t.monsterType="MONSTER_GOLDEN":t.monsterType=e.Cfg_get().objectType}isSameAttId(t,e){
return null!=t&&t.Equal(e)}AddOterPlayers(){const t=h.x.GetInst().curAttackMeTargetId,e=l.Y.RoleDic,i=l.Y.Inst.PrimaryRole_get().GetPos(),n=l.Y.Inst.PrimaryRole_get().objId
let a=!0
for(const[l,r]of(0,s.V5)(e))if(a=!0,!r.objId.Equal(n)&&!this.isSameAttId(t,r.Roleinfo_get().Id_get())&&!r.Isdead_get()){const t=r.GetPos(),e=u.P.Distance(i,t)
if(e<T.MAX_DISTANCE){const t=r.Roleinfo_get()
if(!this.AddRedFortressOtherPlayers(t,e)&&a){const i=`${t.Name_get()}(Lv.${t.Level_get()})`,s=new S(r.Roletype_get(),i,t.Id_get(),!1)
s.sex=t.Sex_get(),s.job=t.Job_get(),s.distance=e,this.t_list.Add(s)}}}}AddRedFortressOtherPlayers(t,e){return!1}ChangeOne(t){if(null==t&&(t=!0),t){const t=l.Y.Inst.CurTarget_get()
null!=t&&null!=t.GetGameId()&&-1==this.m_selectedIds.IndexOf(t.GetGameId().ToKey(),0)&&this.m_selectedIds.Add(t.GetGameId().ToKey())}let e=null
if(c.k.Inst_get().pkModel==EPKMode.PEACE_MODEL?(e=this.GetNearstPkOne(!0),null==e&&(e=this.GetBossOne(!0)),null==e&&(e=this.GetEliteOne()),
null==e&&(e=this.GetNormalOne())):c.k.Inst_get().pkModel==EPKMode.GUILD_MODEL||c.k.Inst_get().pkModel==EPKMode.ASURAM_WAR_CAMP?(e=this.GetNearstPkOne(!0),
null==e&&(e=this.GetNoPKOne(!0)),null==e&&(e=this.GetBossOne(!1)),null==e&&(e=this.GetEliteOne()),
null==e&&(e=this.GetNormalOne())):c.k.Inst_get().pkModel==EPKMode.SLAUGHTER_MODEL&&(e=this.GetNearstPkOne(!0),null==e&&(e=this.GetNoPKOne(!1)),null==e&&(e=this.GetBossOne(!1)),
null==e&&(e=this.GetEliteOne()),null==e&&(e=this.GetNormalOne())),null!=e){const t=l.Y.Inst.getCharacterById(e.id)
if(l.Y.Inst.setCurTarget(t),this.AddToSelected(e),(0,n.t2)(t,o.u)){const e=t
e.GetGameId().Equal(l.Y.Inst.PrimaryRoleInfo_get().Id_get())||(g.X.Inst().TargetRole_set(e),g.X.Inst().canOperate=!0,p.Y.Inst().Open())}
}else this.m_selectedIds.Count()>0&&(this.m_selectedIds.Clear(),this.ChangeOne(!1))
return e}AddToSelected(t){this.m_selectedIds.Count()>5&&this.m_selectedIds.Clear(),this.m_selectedIds.Add(t.id.ToKey())}GetNearstPkOne(t){
let e=null,i=h.x.GetInst().curAttackMeTargetId
if(t&&(i=I.k.inst.getAttacker()),!(null!=this.exceptList&&this.exceptList.IndexOf(i,0)>-1))return null
if(null==i)return null
let s=null
if(s=t?l.Y.Inst.getRoleById(i):l.Y.Inst.getCharacterById(i),null!=s){const t=l.Y.Inst.PrimaryRole_get().GetPos()
if(u.P.Distance(t,s.GetPos())<T.MAX_DISTANCE){let t=null,i=null,n=null,l=0,r=0,o=0
if(s.Roletype_get()==a.s.role){const t=s.Roleinfo_get()
i=`${t.Name_get()}(Lv.${t.Level_get()})`,n=t.Id_get(),r=t.Job_get(),o=t.Sex_get()}else if(s.Roletype_get()==a.s.monster)t=s,i=t.Cfg_get().name,l=t.Cfg_get().id,
i+=`(Lv.${t.Cfg_get().level})`,n=t.objId
else if(s.Roletype_get()==a.s.pet){const t=s
i=t.Cfg_get().name,n=t.objId,i+=`(Lv.${t.Cfg_get().level})`}null!=n&&(e=new S(s.Roletype_get(),i,n,!0),e.job=r,e.configId=l,null!=t&&this.SetMonsterType(e,t),e.sex=o)}}return e}
GetBossOne(t){const e=l.Y.Inst.GetNearestBoss(T.MAX_DISTANCE,!1,this.m_selectedIds)
let i=null
if(null!=e){const t=e
i=new S(t.Roletype_get(),t.Cfg_get().name,t.objId,!1)}return i}GetEliteOne(){let t=l.Y.Inst.GetNearestMonster(T.MAX_DISTANCE,r.b.MONSTER_ELITE,this.m_selectedIds)
null==t&&(t=l.Y.Inst.GetNearestMonster(T.MAX_DISTANCE,r.b.ACTIVITY_ELITE,this.m_selectedIds))
let e=null
if(null!=t){const i=t
e=new S(i.Roletype_get(),i.Cfg_get().name,i.objId,!1)}return e}GetNormalOne(){const t=l.Y.Inst.GetNearestMonster(T.MAX_DISTANCE,r.b.MONSTER_NORMAL,this.m_selectedIds)
let e=null
if(null!=t){const i=t
i.Info_get()
e=new S(i.Roletype_get(),i.Cfg_get().name,i.objId,!1)}return e}GetNoPKOne(t){const e=l.Y.Inst.getNearestCharacter(T.MAX_DISTANCE,t,this.m_selectedIds)
let i=null
if(null!=e){const t=e.Roleinfo_get()
i=new S(e.Roletype_get(),t.Name_get(),t.Id_get(),!1),i.job=t.Job_get(),i.sex=t.Sex_get()}return i}}T.MAX_DISTANCE=7
var f=i(56937),C=i(18202),E=i(31222),A=i(5494),L=i(52726),y=i(97461),D=i(5924),O=i(9986),R=i(6665),N=i(61911),M=i(92679),w=i(99294),P=i(9057),v=i(57834),k=i(93877),U=i(72005),G=i(13113),F=i(2886),B=i(27122),H=i(48933)
class V extends P.x{constructor(){super(),this.monsterIcon=null,this.headWidget=null,this.nameTxt=null,this.collider=null,this.headObj=null,this.m_listener=null,this.vo=null,
this._degf_OnBgClick=null,this._degf_OnBgClick=(t,e)=>this.OnBgClick(t,e)}InitView(){this.monsterIcon=new U.w,this.monsterIcon.setId(this.FatherId,this.FatherComponentID,1),
this.headWidget=new G.T,this.headWidget.setId(this.FatherId,this.FatherComponentID,2),this.nameTxt=new k.Q,this.nameTxt.setId(this.FatherId,this.FatherComponentID,3),
this.collider=new w.z,this.collider.setId(this.FatherId,this.FatherComponentID,4),this.m_listener=v.i.Get(this.collider),
this.m_listener.setId(this.FatherId,null,this.collider.ComponentId),this.headObj=new F.n,this.headObj.Init(this.headWidget)}OnBgClick(t,e){
const i=l.Y.Inst.getCharacterById(this.vo.id)
if(l.Y.Inst.setCurTarget(i),q.inst_get().control.Close(),i.Roletype_get()==a.s.role){let t=B.Q.Inst().GetObjectByName("Role",o.u)
t=i,t.GetGameId().Equal(l.Y.Inst.PrimaryRoleInfo_get().Id_get())||(g.X.Inst().TargetRole_set(t),g.X.Inst().canOperate=!0,p.Y.Inst().Open())}}SetData(t){if(this.vo=t,
this.nameTxt.textSet(this.vo.name),this.vo.type==a.s.role)this.headWidget.node.SetActive(!0),this.monsterIcon.node.SetActive(!1),
this.headObj.SetHeadIcon(this.vo.job,this.vo.sex,H.I.zeroLong),this.headObj.SetSize(32,32)
else{this.headWidget.node.SetActive(!1),this.monsterIcon.node.SetActive(!0)
let t="mainui_icon_0002"
"MONSTER_BOSS"==this.vo.monsterType?t="mainui_icon_0003":"MONSTER_GOLDEN"==this.vo.monsterType&&(t="mainui_icon_0004"),this.monsterIcon.spriteNameSet(t)}
this.m_listener.RegistonClick(this._degf_OnBgClick)}Clear(){this.m_listener.RemoveonClick(this._degf_OnBgClick)}Destroy(){this.monsterIcon=null,this.headWidget=null,
this.nameTxt=null,this.collider=null}}class b extends N.f{constructor(){super(),this.grid=null,this.closebtn=null,this.m_timerId=-1,this.m_updateTimerId=-1,
this._degf_OnAction=null,this._degf_OnBtnClick=null,this._degf_OnGetItem=null,this._degf_OnViewUpdate=null,this._degf_OnAction=()=>this.OnAction(),
this._degf_OnBtnClick=(t,e)=>this.OnBtnClick(t,e),this._degf_OnGetItem=t=>this.OnGetItem(t),this._degf_OnViewUpdate=t=>this.OnViewUpdate(t)}InitView(){this.grid=new R.A,
this.grid.setId(this.FatherId,this.FatherComponentID,1),this.closebtn=new O.W,this.closebtn.setId(this.FatherId,this.FatherComponentID,2),
this.grid.SetInitInfo("ui_sw1tchtarget_item",this._degf_OnGetItem)}OnGetItem(t){const e=new V
return e.setId(t,null,0),e}OnAddToScene(){this.AddOrDelEvent(!0),this.OnViewUpdate(null),this.OnAction(),this.m_timerId=D.C.Inst_get().SetInterval(this._degf_OnAction,3e3)}
AddOrDelEvent(t){t?(this.AddClickEvent(this.closebtn,this._degf_OnBtnClick),y.i.Inst.AddEventHandler(M.g.VIEWPLAYER_UPDATE,this._degf_OnViewUpdate),
this.AddFullScreenCollider(this.node,this._degf_OnBtnClick)):(this.RemoveClickEvent(this.closebtn,this._degf_OnBtnClick),
y.i.Inst.RemoveEventHandler(M.g.VIEWPLAYER_UPDATE,this._degf_OnViewUpdate),this.RemoveFullScreenCollider())}OnViewUpdate(t){
this.m_updateTimerId<0&&(this.m_updateTimerId=D.C.Inst_get().SetInterval(this._degf_OnAction,50,1))}OnAction(){null!=this.grid&&(this.grid.data_set(q.inst_get().model.GridData()),
this.m_updateTimerId=-1)}OnBtnClick(t,e){E.N.inst.CloseById(A.I.SwitchTarget)}Clear(){this.AddOrDelEvent(!1),D.C.Inst_get().ClearInterval(this.m_timerId),
D.C.Inst_get().ClearInterval(this.m_updateTimerId)}Destroy(){this.grid.Destroy(),this.grid=null,this.closebtn=null}}class x{constructor(){this.panel=null,
this._degf_CallDestory=null,this._degf_ShowlSwitchComplete=null,this._degf_CallDestory=()=>this.CallDestory(),this._degf_ShowlSwitchComplete=t=>this.ShowlSwitchComplete(t)}Open(){
if(null==this.panel||!this.panel.isShow_get()){const t=new f.v
t.layerType=L.F.Alert,E.N.inst.OpenById(A.I.SwitchTarget,this._degf_ShowlSwitchComplete,this._degf_CallDestory,t)}}Close(){null!=this.panel&&E.N.inst.CloseById(A.I.SwitchTarget)}
ShowlSwitchComplete(t){return null==this.panel&&(this.panel=new b,this.panel.setId(t,null,0)),this.panel}CallDestory(){C.g.DestroyUIObj(this.panel),this.panel=null}RefreshGrid(){
null!=this.panel&&this.panel.OnAction()}}class q{constructor(){this.control=null,this.model=null,this.control=new x,this.model=new T}static inst_get(){
return null==q.m_mgr&&(q.m_mgr=new q),q.m_mgr}}q.m_mgr=null},25406:(t,e,i)=>{i.d(e,{U:()=>I})
var s=i(38836),n=i(38045),l=i(98800),a=i(68662),r=i(45549),o=i(85602),h=i(38962),d=i(85770),_=i(72800),u=i(75439)
class I{constructor(){this.m_selectedIds=null,this.m_pkIds_remove_temp={},this.m_pkIds=null,this.maxSelNum=null,this.pkLastTime=null,this._degf_OnCheckPkStateHandler=null,
this.m_selectedIds=new o.Z,this.m_pkIds=new h.X,this.maxSelNum=u.D.getInstance().GetNumberValue("TARGET_CLEAN_NUM"),
this.pkLastTime=u.D.getInstance().GetNumberValue("SURVIVAL:REVENGE_LAST_MINUTES"),this._degf_OnCheckPkStateHandler=()=>this.OnCheckPkStateHandler()}static Inst_get(){
return null==I._Inst&&(I._Inst=new I),I._Inst}ChangeOne(t,e,i){null==t&&(t=!1),null==i&&(i=!0)
let s=l.Y.Inst.GetCheckMaxDis_get()
if(s<=5){const t=u.D.getInstance().getContent("SETTING:MAX_FIND_OBJECT_DISTANCE")
console.error(`最小选怪距离异常dislimit:${(0,n.tw)(s)}  job:${l.Y.Inst.PrimaryRoleInfo_get().Job_get()} ${t.getContent().stringVal}`),s=15}
if(d.a.Inst_get().curCopyType!=_.S.MineRob&&d.a.Inst_get().curCopyType!=_.S.NORMAL_CROSS_ARENA&&d.a.Inst_get().curCopyType!=_.S.PEAK_CROSS_ARENA||(s=999999),t){let t=null
if(t=l.Y.Inst.CurTarget_get(),null!=t?r.x.GetInst().CheckPkTargetDistance(e,l.Y.Inst.PrimaryRole_get(),t,s)||(t=l.Y.Inst.hangAutoSelect(s,!0,!1,null,!0,!0,e)):t=l.Y.Inst.hangAutoSelect(s,!0,!1,null,!0,!1,e),
null==t||t.isAttackedable()||(t=l.Y.Inst.hangAutoSelect(s,!0,!1,null,!0,!1,e)),
d.a.Inst_get().curCopyType==_.S.MineRob||d.a.Inst_get().curCopyType==_.S.NORMAL_CROSS_ARENA||d.a.Inst_get().curCopyType==_.S.PEAK_CROSS_ARENA){
const e=null==l.Y.Inst.m_curSpecielTarget
null==t&&null!=l.Y.Inst.m_curSpecielTarget&&(t=l.Y.Inst.m_curSpecielTarget,console.error("目标选中异常1")),null==t&&console.error(`目标选中异常1 target == nil${(0,n.tw)(e)}`)}
null!=t&&l.Y.Inst.setCurTarget(t,!0)}let a=null
return t||(a=this.PickSelectTarget(s,i),null==a&&this.m_selectedIds.Count()>0&&(this.m_selectedIds.Clear(),a=this.PickSelectTarget(s,i)),null!=a&&(l.Y.Inst.setCurTarget(a,!0),
this.AddToSelected(a))),a}PickSelectTarget(t,e){
if(d.a.Inst_get().curCopyType==_.S.MineRob||d.a.Inst_get().curCopyType==_.S.NORMAL_CROSS_ARENA||d.a.Inst_get().curCopyType==_.S.PEAK_CROSS_ARENA)this.m_selectedIds.Clear()
else if(e){const t=l.Y.Inst.CurTarget_get()
this.IsSelected(t)&&this.m_selectedIds.Add(t.GetGameId().ToKey())}let i=l.Y.Inst.hangAutoSelect(t,!0,!1,null,!0,!1,null,this.m_selectedIds)
if(d.a.Inst_get().curCopyType==_.S.MineRob||d.a.Inst_get().curCopyType==_.S.NORMAL_CROSS_ARENA||d.a.Inst_get().curCopyType==_.S.PEAK_CROSS_ARENA){
const t=null==l.Y.Inst.m_curSpecielTarget
null==i&&null!=l.Y.Inst.m_curSpecielTarget&&(i=l.Y.Inst.m_curSpecielTarget,Debuger.LogError("目标选中异常2")),null==i&&Debuger.LogError(`目标选中异常2 t_character == nil ${(0,n.tw)(t)}`)}
return i}IsPKTarget(t){if(null==t)return!1
const e=t.GetGameId().ToNum()
return!!this.m_pkIds.LuaDic_ContainsKey(e)}AddPKTarget(t){const e=t.ToNum(),i=a.D.serverTime_get()+this.pkLastTime
this.m_pkIds.LuaDic_AddOrSetItem(e,i)}RemovePKTarget(t){const e=t.ToNum()
this.m_pkIds.LuaDic_ContainsKey(e)&&this.m_pkIds.LuaDic_Remove(e)}ClearPKTarget(){this.m_pkIds.LuaDic_Clear()}IsSelected(t){
return null!=t&&null!=t.GetGameId()&&-1==this.m_selectedIds.IndexOf(t.GetGameId().ToKey(),0)}ClearSelected(t){this.m_selectedIds.Clear()}AddToSelected(t){
this.m_selectedIds.Count()>=this.maxSelNum&&this.m_selectedIds.Clear(),null!=t.GetGameId()&&this.m_selectedIds.Add(t.GetGameId().ToKey())}OnCheckPkStateHandler(){
const t=a.D.serverTime_get(),e=this.m_pkIds_remove_temp
let i=1
for(const[n,l]of(0,s.V5)(this.m_pkIds))t>l&&(e.length>=i?e[i]=n:table.insert(e,n),i+=1)
if(i>1){const t=i-1
for(let i=1;i<=t;i++)this.m_pkIds.LuaDic_Remove(e[i])}}}I._Inst=null},5968:(t,e,i)=>{i.d(e,{Z:()=>S})
var s,n,l=i(42292),a=i(17409),r=i(49655),o=i(5924),h=i(56937),d=i(85942),_=i(31222),u=i(98885),I=i(39879),c=i(85770),g=i(24524),p=i(37397),m=i(23450)
let S=(0,l.wT)("GameSys.CommonHintController")((n=class t{static get Inst(){return t._Inst||(t._Inst=new t),t._Inst}constructor(){this.m_panel=null,this.m_topLayerPanel=null,
this.isTopLayerPanelCanForceClose=!1,this.tipVo=null,this.topLayerTipVo=null,this._delayTimeId=0,this._degf_CallDestory=null,this._degf_CallTopLayerDestory=null,
this._degf_ShowComplete=null,this._degf_ShowTopLayerComplete=null,this._degf_CallDestory=()=>this.CallDestory(),this._degf_CallTopLayerDestory=()=>this.CallTopLayerDestory(),
this._degf_ShowComplete=t=>this.ShowComplete(t),this._degf_ShowTopLayerComplete=t=>this.ShowTopLayerComplete(t)}OpenView(t=null){this.tipVo=t
const e=new h.v
e.isShowMask=t.isShowMask,e.isSelfTween=!1,e.layerType=t.panelLayer,e.ReLoginOrChangeRoleIsDestroy=t.roleDeadClose,0!=t.maskAlpha&&(e.maskAlpha=t.maskAlpha),p._.Inst.isShowTips=!0,
(0,a.Yp)(r.o.eCommonHintPanel,e)}OpenCopyExitHintView(t,e){if(e)t&&t()
else{const e=g.o.Inst().getItemById(c.a.Inst_get().currentCopyId)
if(null==e)return
const i=e.quitConfirm
if(u.M.IsNullOrEmpty(i))return
const s=I.L.Inst().getItemById(i),n=new d.N
n.titleText=s.title,n.showText=s.text,n.needCheckBox=s.isRemind,n.okhandler=t,n.tipstype=2,this.OpenView(n)}}OpenTopLayerView(t,e){null==e&&(e=!1),this.topLayerTipVo=t
const i=new h.v
i.isShowMask=t.isShowMask,i.isSelfTween=!1,i.layerType=LayerType.Tip,this.isTopLayerPanelCanForceClose=e,
null!=this.m_topLayerPanel&&this.m_topLayerPanel.isShow_get()?this.m_topLayerPanel.OnAddToScene():_.N.inst.OpenById(eUIComponentID.eCommonHintTopLayerPanel,this._degf_ShowTopLayerComplete,this._degf_CallTopLayerDestory,i)
}ShowTopLayerComplete(t){return null==this.m_topLayerPanel&&(this.m_topLayerPanel=new CommonHintTopLayerPanel,this.m_topLayerPanel.setId(t,null,0)),this.m_topLayerPanel}
CallTopLayerDestory(){UIResMgr.DestroyUIObj(this.m_topLayerPanel),this.m_topLayerPanel=null,this.isTopLayerPanelCanForceClose=!1}CloseTopLayerPanel(t){null==t&&(t=!1),
(0==t||this.isTopLayerPanelCanForceClose)&&(_.N.inst.ClosePanel(this.m_topLayerPanel),this.isTopLayerPanelCanForceClose=!1)}ShowComplete(t){
return null==this.m_panel&&(this.m_panel=new m.$,this.m_panel.setId(t,null,0)),this.m_panel}CallDestory(){this.m_panel=null,this.tipVo=null}OutClosePanel(){
(null==this.tipVo||this.tipVo.roleDeadClose)&&(0,a.sR)(r.o.eCommonHintPanel)}ClosePanel(){(0,a.sR)(r.o.eCommonHintPanel),
this._delayTimeId=o.C.Inst_get().ClearInterval(this._delayTimeId),this._delayTimeId=o.C.Inst_get().SetInterval(this._DelaySetVoNil,1e3,1)}_DelaySetVoNil(){
null!=this.m_panel&&this.m_panel.isOpen_get()||(this.tipVo=null)}},n._Inst=void 0,s=n))||s},6719:(t,e,i)=>{i.d(e,{p:()=>F})
var s=i(38836),n=i(86133),l=i(38045),a=i(23833),r=i(98800),o=i(68662),h=i(62370),d=i(66788),_=i(95721),u=i(35128),I=i(98885),c=i(38962),g=i(63076),p=i(64444),m=i(85751),S=i(87923),T=i(33138),f=i(11037),C=i(47786),E=i(22662),A=i(29587),L=i(65550)
let y=null,D=null,O=null,R=null,N=null,M=null,w=null,P=null,v=null,k=null,U=!1,G="047104"
class F{static __StaticInit(){y=new c.X,y.LuaDic_Add(-1009,(t=>{F.I18nItemInfoHandler(t)})),y.LuaDic_Add(-1010,(t=>{F.I18nNumInfoHandler(t)})),y.LuaDic_Add(-1011,(t=>{
F.I18nPlayerInfoHandler(t)})),y.LuaDic_Add(-1012,(t=>{F.I18nStringInfoHandler(t)})),y.LuaDic_Add(-1014,(t=>{F.I18nPositionInfoHandler(t)})),y.LuaDic_Add(-1021,(t=>{
F.I18nGatherInfoHandler(t)})),y.LuaDic_Add(-1025,(t=>{F.I18nBossAssistInfoHandler(t)})),y.LuaDic_Add(-1027,(t=>{F.I18nTimeInfoHandler(t)})),y.LuaDic_Add(-1031,(t=>{
F.I18nDateInfoHandler(t)})),y.LuaDic_Add(-1033,(t=>{F.I18nStallInfoHandler(t)})),y.LuaDic_Add(-1034,(t=>{F.I18nStallItemInfoHandler(t)})),y.LuaDic_Add(-1035,(t=>{
F.I18nAsuramTaskInfoHandler(t)})),y.LuaDic_Add(-1036,(t=>{F.I18nConvertInfoHandler(t)})),y.LuaDic_Add(-1037,(t=>{F.I18nEquipAndSuitEquipInfoHandler(t)})),y.LuaDic_Add(-3571,(t=>{
F.I18nInviteAsuramInfoHandler(t)})),y.LuaDic_Add(-11525,(t=>{F.I18nRidingInfoHandler(t)}))}static GetResultText(t,e,i,l,a,r,o){if(null==k&&(k=0),null==P&&(P=-1),null==o&&(o=!1),
D="",O="",R="",N=S.l.RegexN(t),M=e,w=i,P=l,v=a,k=r,U=o,G=U?"5FB470":"047104",null!=M){let t=0
for(;t<M.count;){for(const[e,i]of(0,s.vy)(y))M[t].getId()==e&&y[e](t)
t+=1}}if(w!=E.r.SystemTipMessage){const t=C.x.Inst().getItemById(P)
if(null==t)C.x.Inst().isNoCfg&&-1!=P&&d.Y.LogError((0,n.T)("I18NRESOURCEE表未找到id:")+P)
else if(0!=t.ui3)if(D=`${p.B.UI_OPEN}_${t.ui3}`,k>0){let e=S.l.SetStringColor(G,`[${t.tips3}]`)
e=F.SetColorTxt(w,e),N+=e,N=S.l.SetLinkStr(N,D,null,!1),L.y.inst.fullLinkStr=D}else{let e=S.l.SetLinkStr(t.tips3,D,G,!0)
e=F.SetColorTxt(w,e),N+=e,L.y.inst.fullLinkStr=null}}return L.y.inst.fullLinkStr=null,N}static I18nItemInfoHandler(t){
O=I.M.s_LEFT_B_K_CHAR+(I.M.IntToString(t)+I.M.s_RIGHT_B_K_CHAR_DOT)
const e=M[t]
let i=null,s=null,n=0,l=0
i=e.id,l=e.itemModelId,A.r.Inst_get().curModelId=e.itemModelId,s=new g.M(e.itemModelId,null),n=e.color>=0?e.color:S.l.GetQuality(s)
let a=T.f.Inst().getItemById(l).name
if(e.excellents>0&&(a=S.l.GetExcellentPre(e.excellents)+a),w==E.r.SystemTipMessage){let t=""
t=U?m.u.SetStringColorByBrightQuality(n,a):S.l.SetStringColorByQuality(n,a),N=I.M.Replace(N,O,t)}else{D=`${p.B.ITEM}_${i.low_get()}_${i.high_get()}`
let t=""
t=U?m.u.getColorStrsByBrightQuality(n):S.l.getColorStrByQuality(n)
let e=S.l.SetLinkStr(a,D,t,!0)
e=F.SetColorTxt(w,e),N=I.M.Replace(N,O,e)}}static I18nEquipAndSuitEquipInfoHandler(t){O=I.M.s_LEFT_B_K_CHAR+(I.M.IntToString(t)+I.M.s_RIGHT_B_K_CHAR_DOT)
const e=M[t],i=e.equipment,s=e.suitEquipment
let n=_.o.ZERO,l=_.o.ZERO,a=null,r=null,o=0,h=0
null!=i&&(n=i.id,h=i.itemModelId,a=new g.M(i.itemModelId,null),null!=s&&(r=new g.M(s.itemModelId,null)),o=i.color>=0?i.color:S.l.GetQuality(a)),null!=s&&(l=s.id,
0==h&&(h=s.itemModelId),r=new g.M(s.itemModelId,null),o=s.color>=0?s.color:S.l.GetQuality(r)),A.r.Inst_get().curModelId=h
let d=T.f.Inst().getItemById(h).name
if(null!=a&&null==r)d=S.l.SetGodMasterPrefix(d,a.serverData_get(),a.equipInfo_get(),null)
else if(null==a&&null!=r)d=S.l.SetGodMasterPrefix(d,r.serverData_get(),r.equipInfo_get(),null)
else{d=S.l.SetGodMasterPrefix(d,a.serverData_get(),a.equipInfo_get(),null)
d=EquipSuitCfgManager.Inst().getSuitById(r.cfgEquipData_get().suitId).suitPrefix+d}if(null!=i&&i.excellents>0&&(d=S.l.GetExcellentPre(i.excellents)+d),w==E.r.SystemTipMessage){
let t=""
t=U?m.u.SetStringColorByBrightQuality(o,d):S.l.SetStringColorByQuality(o,d),N=I.M.Replace(N,O,t)}else{
D=`${p.B.SHOW_EQUIP}_${n.low_get()}_${n.high_get()}_${l.low_get()}_${l.high_get()}`
let t=""
t=U?m.u.getColorStrsByBrightQuality(o):S.l.getColorStrByQuality(o)
let e=S.l.SetLinkStr(d,D,t,!0)
e=F.SetColorTxt(w,e),N=I.M.Replace(N,O,e)}}static I18nNumInfoHandler(t){const e=M[t]
O=I.M.s_LEFT_B_K_CHAR+(I.M.IntToString(t)+I.M.s_RIGHT_B_K_CHAR_DOT),R=F.SetColorTxt(w,I.M.IntToString(e.num)),N=I.M.Replace(N,O,R)}static I18nPlayerInfoHandler(t){const e=M[t]
O=I.M.s_LEFT_B_K_CHAR+(I.M.IntToString(t)+I.M.s_RIGHT_B_K_CHAR_DOT)
let i=`${p.B.PLAYER}_${e.objId.low_get()}_${e.objId.high_get()}`
i=S.l.SetNameLinkStr(e.name,i,null,!0),i=F.SetColorTxt(w,i),N=I.M.Replace(N,O,i)}static I18nStringInfoHandler(t){const e=M[t]
O=I.M.s_LEFT_B_K_CHAR+(I.M.IntToString(t)+I.M.s_RIGHT_B_K_CHAR_DOT)
let i=S.l.RegexN(e.str)
i=F.SetColorTxt(w,i),N=I.M.ReplaceSlow(N,O,i)}static I18nTimeInfoHandler(t){const e=M[t]
O=I.M.s_LEFT_B_K_CHAR+(I.M.IntToString(t)+I.M.s_RIGHT_B_K_CHAR_DOT)
const i=F.SetColorTxt(w,`${S.l.GetDateTimeNext(e.time.ToNum())}`)
N=I.M.Replace(N,O,i)}static I18nDateInfoHandler(t){const e=M[t]
O=I.M.s_LEFT_B_K_CHAR+(I.M.IntToString(t)+I.M.s_RIGHT_B_K_CHAR_DOT)
let i=F.SetColorTxt(w,`${S.l.GetDateTime4(e.time.ToNum())}`)
11041721==P&&(i=F.SetColorTxt(w,`${S.l.GetDateFormat(u.p.CeilToInt(e.time.ToNum()/1e3))}`)),
11043014==P&&(i=F.SetColorTxt(w,`${S.l.GetCrossBattleDateFormat(u.p.CeilToInt((e.time.ToNum()-o.D.serverMSTime_get())/1e3))}后`)),N=I.M.Replace(N,O,i)}
static I18nPositionInfoHandler(t){const e=M[t]
O=I.M.s_LEFT_B_K_CHAR+(I.M.IntToString(t)+I.M.s_RIGHT_B_K_CHAR_DOT)
const i=TransportMapModel.Inst_get().GetMapById(e.mapId),s=F.SetColorTxt(w,i.name)
N=I.M.Replace(N,O,s)
const l=new Vector3(e.positionX,0,e.positionY),a=h.o.s_UNDER_CHAR,r=p.B.POINT,o=i.id,d=l.x,_=l.z,u=e.channelId,c=e.bossId,g=BossInfoCfgManager.Inst().GetItemByMonsterId(c)
D=r+(a+(o+(a+(d+(a+(_+(a+(u+(a+c))))))))),R=null!=g?` ${S.l.SetLinkStr((0,n.T)("立即前往"),D,G,!0)}`:"",N+=R}I18nAsuramQuestInfoHandler(t){}static I18nRidingInfoHandler(t){const e=M[t]
O=I.M.s_LEFT_B_K_CHAR+(I.M.IntToString(t)+I.M.s_RIGHT_B_K_CHAR_DOT)
const i=f.D.GetInst().GetCfg(e.horseId)
let s=""
s=U?`[${m.u.getColorStrsByBrightQuality(i.horseGrade)}]${i.horseName}[-]`:`[${S.l.getColorStrByQuality(i.horseGrade)}]${i.horseName}[-]`,N=I.M.Replace(N,O,s)}
static I18nGatherInfoHandler(t){const e=M[t],i=CollectCfgManager.Inst().getItemById(e.gatherId)
O=I.M.s_LEFT_B_K_CHAR+(I.M.IntToString(t)+I.M.s_RIGHT_B_K_CHAR_DOT),R=U?m.u.SetStringColorByBrightQuality(i.gatherableEffect,i.name):m.u.SetStringColorByQuality(i.gatherableEffect,i.name),
N=I.M.Replace(N,O,R)}static I18nBossAssistInfoHandler(t){const e=M[t],i=a.a.getInst().getObjById(e.bossKey)
let s=`${i.name}Lv.${i.level}`
s=S.l.SetStringColor(G,s),D=p.B.BOSS_ASSIST
let n=""
n=null!=v&&null!=v.infoEx&&v.infoEx.type==eAllianceAssistType.ASURAM_QUEST_COPY?`我正在进行战盟任务，需要击败[e2a66a]${s}[-]，求大佬助攻！${S.l.SetLinkStr("前往协助",D,G,!0)}`:`我正在打[e2a66a]${s}[-]，求战盟大佬协助，协助成功可获得战盟贡献！${S.l.SetLinkStr("前往协助",D,G,!0)}`,
N=n,k>0&&(L.y.inst.fullLinkStr=D)}static I18nDigMineAsuramAssistInfoHandler(t){}static I18nInviteAsuramInfoHandler(t){const e=M[t]
O=I.M.s_LEFT_B_K_CHAR+(I.M.IntToString(t)+I.M.s_RIGHT_B_K_CHAR_DOT)
const i=`${p.B.ASURAM_INVITE}_${e.asuramId.low_get()}_${e.asuramId.high_get()}`
let s=`${I.M.s_LEFT_M_K_CHAR}url=${i}${I.M.s_RIGHT_M_K_CHAR}${I.M.s_LEFT_M_K_CHAR}${(0,
n.T)("一键申请")}${I.M.s_RIGHT_M_K_CHAR}${I.M.s_LEFT_M_K_CHAR}${I.M.s_F_SLASH_DOT}url${I.M.s_RIGHT_M_K_CHAR}`
s=S.l.SetStringColor(G,s),N=I.M.Replace(N,O,s)}static I18nStallItemInfoHandler(t){O=I.M.s_LEFT_B_K_CHAR+(I.M.IntToString(t)+I.M.s_RIGHT_B_K_CHAR_DOT)
const e=M[t],i=e.id
let s=null
A.r.Inst_get().curModelId=e.itemModelId,s=new g.M(e.itemModelId,null)
const n=S.l.GetItemShowName(s,!0)
if(g.M.Recycle(s),w!=E.r.SystemTipMessage||I.M.IsNullOrEmpty(O)){D=`${p.B.STALL_AD_ITEM}_${i.low_get()}_${i.high_get()}_${e.stallAccountIndex}`
let t=S.l.SetLinkStr(n,D,null,!1)
t=F.SetColorTxt(w,t),N=I.M.ReplaceSlow(N,F.STALL_ITEM_KEY,t)}else N=I.M.Replace(N,O,n)}static I18nAsuramTaskInfoHandler(t){
const e=M[t],i=AsuramquestCfgManager.Inst_Get().GetTaskItemById(e.alliancequestId)
if(null!=i){const t=TaskModel.Inst_get().GetConfig(i.questId)
if(null!=t){let i=""
if(D=p.B.ALLIANCE_ASSIST,1==e.type){const e=I.M.String2Int(t.GetNowTargetDef().param.itemModelId)
if(e>0){const t=T.f.Inst().getItemById(e)
null!=t&&(i=U?m.u.SetStringColorByBrightQuality(t.Quality_get(),t.name):m.u.SetStringColorByQuality(t.Quality_get(),t.name),
N=`我正在进行战盟任务，需要提交1个${i}，求大佬助攻~ ${S.l.SetLinkStr("前往协助",D,G,!0)}`)}}}}}static I18nStallInfoHandler(t){const e=M[t]
O=I.M.s_LEFT_B_K_CHAR+(I.M.IntToString(t)+I.M.s_RIGHT_B_K_CHAR_DOT)
let i=`${p.B.STALL_AD_STALLNAME}_${e.stallAccountIndex}`
i=S.l.SetNameLinkStr(e.stallName,i,ChatCellInfo.NAME_LINK_COLOR,!0),i=F.SetColorTxt(w,i)
let s=""
N=I.M.Replace(N,O,i),-1==I.M.IndexOf(N,":",0)&&(s=e.stallAccountIndex!=r.Y.Inst.PrimaryRoleInfo_get().accountindex?`${e.playerName}:`:"我:",N=s+N)}static I18nConvertInfoHandler(t){
const e=M[t]
O=I.M.s_LEFT_B_K_CHAR+(I.M.IntToString(t)+I.M.s_RIGHT_B_K_CHAR_DOT)
let i=S.l.RegexN(e.num.ToLongStr())
i=F.SetColorTxt(w,i)
const s=(0,l.aI)(i)
null!=s&&(i=CurrencyModel.Instance.ConvertNumToString(s)),N=I.M.ReplaceSlow(N,O,i)}static SetColorTxt(t,e){return t==E.r.CopyMsgMessage&&(e=S.l.SetStringColor("fdff4f",e)),e}}
F.STALL_ITEM_KEY="[key]0[key]",F.__StaticInit()},2295:(t,e,i)=>{i.d(e,{d:()=>I})
var s=i(38836),n=i(68662),l=i(13687),a=i(5924),r=i(85602),o=i(38962),h=i(47786),d=i(21334),_=i(29587),u=i(65550)
class I{constructor(){this.cdIntervalId=-1,this.groupCdDic=null,this._degf_UpdateCdDic=null,this.groupCdDic=new o.X,this._degf_UpdateCdDic=()=>this.UpdateCdDic()}static Inst_get(){
return null==I.inst&&(I.inst=new I),I.inst}AddMsgToQueue(t){this.IsShowRiAndLa()&&(_.r.Inst_get().riversAndLakesSaidStrs.Add(t),
_.r.Inst_get().riverIsExceed&&u.y.inst.ShowRiverAndLake())}HandleMapChange(){u.y.inst.HandleMapChange()}IsShowRiAndLa(){if(null==l.b.Inst)return!0
const t=l.b.Inst.currentMapId_get()
if(null!=t&&0!=t){return 0!=d.p.Inst_get().GetMapById(t).horseRaceLamp}return!0}AddMsg(t,e){const i=h.x.Inst().getItemById(t)
if(0!=i.showCd)if(this.groupCdDic.LuaDic_ContainsKey(i.groupId));else{this.groupCdDic.LuaDic_AddOrSetItem(i.groupId,n.D.serverTime_get()+i.showCd),this.AddMsgToQueue(e)
let t=0
for(const[e,i]of(0,s.vy)(this.groupCdDic))t+=1
1==t&&(this.cdIntervalId=a.C.Inst_get().SetInterval(this._degf_UpdateCdDic,1e3))}else this.AddMsgToQueue(e)}UpdateCdDic(){const t=new r.Z
for(const[e,i]of(0,s.vy)(this.groupCdDic))this.groupCdDic[e]<n.D.serverTime_get()&&t.Add(e)
let e=0
for(;e<t.Count();)this.groupCdDic.LuaDic_Remove(t[e]),e+=1
let i=0
for(const[t,e]of(0,s.vy)(this.groupCdDic))i+=1
0==i&&(a.C.Inst_get().ClearInterval(this.cdIntervalId),this.cdIntervalId=-1),r.Z.Recyle(t)}Clear(){a.C.Inst_get().ClearInterval(this.cdIntervalId),this.cdIntervalId=-1,
this.groupCdDic.LuaDic_Clear()}}I.inst=null},65550:(t,e,i)=>{i.d(e,{y:()=>Et})
var s,n,l,a,r,o,h,d,_,u=i(42292),I=i(71409),c=i(17409),g=i(49655),p=i(86133),m=i(38045),S=i(98800),T=i(37397),f=i(97461),C=i(36241),E=i(98958),A=i(13687),L=i(38935),y=i(62370),D=i(5924),O=i(66788),R=i(85682),N=i(56937),M=i(31222),w=i(5494),P=i(8334),v=i(52726),k=i(95721),U=i(98130),G=i(98885),F=i(85602),B=i(85430),H=i(21554),V=i(70850),b=i(95272),x=i(63076),q=i(59686),Y=i(26753),K=i(14143),J=i(16459),Q=i(64444),Z=i(83040),X=i(38903),$=i(92679),W=i(68506),j=i(24594),z=i(87923),tt=i(75439),et=i(47786),it=i(92415),st=i(54664),nt=i(36486),lt=i(22662),at=i(79124),rt=i(70966),ot=i(40161),ht=i(84876),dt=i(87817),_t=i(67541),ut=i(83236),It=i(47041),ct=i(21334),gt=i(85942),pt=i(29587),mt=i(30621),St=i(5968),Tt=i(6719),ft=i(2295)
function Ct(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let Et=(s=(0,u.gK)("SystemTipsControl"),n=(0,I.GH)(it.k.SM_NoticeItemInfo),l=(0,I.GH)(it.k.SM_NoticeItemInfoTwo),
a=(0,I.GH)(it.k.SM_Notify_Message),r=(0,I.GH)(it.k.SM_DyNotify_Message),o=(0,I.GH)(it.k.SM_UpdateDyNotifyStatus),s((_=class t{static get inst(){return t._inst||(t._inst=new t),
t._inst}get sysTipsPanel(){return this._sysTipsPanel&&this._sysTipsPanel.node||(this._sysTipsPanel=(0,c.Y)(g.o.SystemCommonMessage)),
this._sysTipsPanel&&this._sysTipsPanel.SetIndex(lt.r.SystemTipMessage),this._sysTipsPanel}get riAndLaPanel(){
return null!=this._riAndLaPanel&&this._riAndLaPanel.node||(this._riAndLaPanel=(0,c.Y)(w.I.RiversAndLakesSaid)),this._riAndLaPanel}get buffTipsPanel(){
return this._buffTipsPanel&&this._buffTipsPanel.node||(this._buffTipsPanel=(0,c.Y)(g.o.SystemCommonMessage2)),this._buffTipsPanel&&this._buffTipsPanel.SetIndex(lt.r.BuffTip),
this._buffTipsPanel}get sysChanPanel(){return null==this._sysChanPanel&&(this._sysChanPanel=(0,c.Y)(w.I.SystemMessagePanel)),this._sysChanPanel}constructor(){
this._sysTipsPanel=null,this._riAndLaPanel=null,this.selectPanel=null,this._buffTipsPanel=null,this.textStr="",this.textStr2="",this.frontTimer=0,this.delayTimer=0,this.m_value=0,
this.isOne=!0,this.frontId=0,this.sys=null,this.item=null,this.isShowRiverTips=!0,this.isDelayReceive=!1,this.timerId=0,this.blockSystemTip=!1,this._sysChanPanel=null,
this.isShowSysChanTips=!0,this.m_asuramTipIds=null,this.m_asuramAssistTipIds=null,this.m_asuramTipLans=null,this.fullLinkStr=null,this._degf_BuffShowHandler=null,
this._degf_DelayReActivity=null,this._degf_DestroyBuffShow=null,this._degf_DestroyRALShow=null,this._degf_DestroySelect=null,this._degf_DestroySysChanPanel=null,
this._degf_DestroySysShow=null,this._degf_DoDelayReceive=null,this._degf_OnLayerMaskShow=null,this._degf_RALShowHandler=null,this._degf_ReActivity=null,
this._degf_ReturnToAccount=null,this._degf_SM_DyNotify_MessageHandler=null,this._degf_SM_NoticeItemInfoHandler=null,this._degf_SM_NoticeItemInfoTwoHandler=null,
this._degf_SM_Notify_MessageHandler=null,this._degf_SM_UpdateDyNotifyStatusHandler=null,this._degf_SelectHandler=null,this._degf_SysChanPanelShowHandler=null,
this._degf_SysShowHandler=null,this._degf_RALShowHandler=t=>this.RALShowHandler(t),this._degf_ReturnToAccount=t=>this.ReturnToAccount(t),this.addLis(),this.InitAsuramTipIds()}
InitAsuramTipIds(){this.m_asuramTipIds=new F.Z,this.m_asuramAssistTipIds=new F.Z,this.m_asuramTipLans=new F.Z
let t=0
const e=tt.D.getInstance().getContent("CHAT:ASURAM_ASSIST_MSG"),i=G.M.Split(e.getContent().stringVal,G.M.s_Arr_SPAN_CHAR_DOT)
for(t=0;t<i.count;){const e=G.M.Split(i[t],y.o.s_Arr_UNDER_CHAR_DOT)
this.m_asuramAssistTipIds.Add(G.M.String2Int(e[0])),this.m_asuramTipLans.Add(G.M.String2Int(e[1])),t+=1}}addLis(){}SM_NoticeItemInfoHandler(t){const e=t
this.ShowItemTipForChat(e.item)}SM_NoticeItemInfoTwoHandler(t){const e=t
this.ShowItemTipForChatTwo(e.itemOne,e.itemTwo)}ShowItemTipForChat(t){const e=new x.M(t.modelId,t)
e.isCanOperate=!1,e.isEquipCompare=!1,e.isShowAddPointTip=!1,e.tag=1,e.tipPosType=q.l.Middle,H.J.Inst_get().ShowItemTip(e)}ShowItemTipForChatTwo(t,e){const i=new x.M(t.modelId,t)
i.isCanOperate=!1,i.isEquipCompare=!1,i.isShowAddPointTip=!1,i.showSuitEq=e,i.tag=1,i.tipPosType=q.l.Middle,H.J.Inst_get().ShowItemTip(i)}QueryItem(t){const e=new st.u
e.id=t,L.C.Inst.F_SendMsg(e)}QueryTwoEq(t,e){const i=new nt.P
i.idOne=t,i.idTwo=e,L.C.Inst.F_SendMsg(i)}QueryGuardItem(t){}SetRiAndLaPanelState(t){null!=this.riAndLaPanel&&(this.isShowRiverTips=t,this.riAndLaPanel.ClearData(),
this.riAndLaPanel.node.SetActive(this.isShowRiverTips))}SetSysState(t,e){null==e&&(e=!0),null!=this.sysTipsPanel&&this.sysTipsPanel.node&&(this.sysTipsPanel.node.SetActive(t),
e&&this.sysTipsPanel.Reset())}SM_Notify_MessageHandler(t){if(this.isDelayReceive)0==this.timerId&&(this.timerId=D.C.Inst_get().SetInterval(this._degf_DoDelayReceive,2e3,1))
else if(null!=t.infos){if(108029==t.infos.i18nId||200015==t.infos.i18nId){V.g.Inst_get().IsBagFull(b.t.NormalBag)&&It.N.Inst_get().FullBagTipEnQueue(b.t.NormalBag)}
if(11043505==t.infos.i18nId){V.g.Inst_get().IsBagFull(b.t.ElementBag)&&It.N.Inst_get().FullBagTipEnQueue(b.t.ElementBag)}
if(131034==t.infos.i18nId&&_t.p.Instance.ShowTextInForceMsg(E.V.Inst().getStr2(10806),null),101030==t.infos.i18nId&&f.i.Inst.RaiseEvent($.g.STOP_PANDORABOX_QUICKUSE),
11040400==t.infos.i18nId&&C._.getInst().endHang(),141005==t.infos.i18nId&&B.a.isInAllianceBossMap_get())return
if(111041==t.infos.i18nId){const e=new j.V
e.tiredValue=t.infos.infos[0].num,e.desc="",W.Z.Inst_get().Open(e)}this.SelectShowPanel(t.infos)}}SM_DyNotify_MessageHandler(t){const e=t,i=new Z.W
i.type=e.type,i.id=e.id,i.state=e.state,i.name=e.name,i.roleid=e.roleid,i.job=e.job,i.sex=e.sex,i.vipLevel=e.vipLevel,i.i18info=e.infos,this.SelectShowPanel(e.infos,i)}
TestDyNotify_MessageHandler(){const t=new ht.K,e=new ot.u
e.i18nId=102756,e.infos=new F.Z
const i=new at.o
i.str="str1"
const s=new at.o
s.str="str2"
const n=new at.o
n.str="str3",e.infos.Add(i),e.infos.Add(s),e.infos.Add(n),t.type=0,t.id=k.o.FromNumber(1111),t.state=1,t.name="name1",t.job=100,t.sex=1,t.vipLevel=2,t.infos=e,
t.roleid=k.o.FromNumber(1234234324),this.SM_DyNotify_MessageHandler(t)}TestMessageHandler(){const t=new dt.N,e=new ot.u
e.i18nId=102756,e.infos=new F.Z
const i=new at.o
i.str="str1"
const s=new at.o
s.str="str2"
const n=new at.o
n.str="str3",e.infos.Add(i),e.infos.Add(s),e.infos.Add(n),t.infos=e,this.SM_Notify_MessageHandler(t)}SM_UpdateDyNotifyStatusHandler(t){const e=t,i=new Z.W
i.type=e.type,i.id=e.id,i.state=e.state,i.name=e.name,i.roleid=e.roleid,i.job=e.job,i.sex=e.sex,i.vipLevel=e.vipLevel,i.param=e.param,Y.d.Inst_get().mgr.updateChatInfo(i.id,i)}
TestSend(t){const e=new Z.W
e.id=t,e.type=2,Y.d.Inst_get().mgr.updateChatInfo(e.id,e)}DoDelayReceive(){this.isDelayReceive=!1,D.C.Inst_get().ClearInterval(this.timerId),this.timerId=0}IsForceSystem(t){
return!(t.Count()<2)&&(!(t.IndexOf(lt.r.RiversAndLakesSaid,0)<0&&t.IndexOf(lt.r.SystemChannelMessage,0)<0)&&!(t.IndexOf(lt.r.UnionChannelMessage,0)<0&&t.IndexOf(lt.r.WorldChannelMessage,0)<0&&t.IndexOf(lt.r.TeamMessage,0)<0))
}SelectShowPanel(t,e){if(this.sys=et.x.Inst().getItemById(t.i18nId),null==this.sys)return void et.x.Inst().isNoCfg
const i=this.sys.sysTips.sysTip
if(this.blockSystemTip&&1==i.Count()&&i[0]==lt.r.SystemTipMessage)return
if(108029==t.i18nId);else if(190025==t.i18nId)return
const s=A.b.Inst.currentMapId_get()
let n=!1,l=!1
let a=0
for(;a<i.Count();)i[a]==lt.r.RiversAndLakesSaid&&(l=!0),i[a]==lt.r.SystemChannelMessage&&(n=!0),a+=1
l&&0==n&&i.Add(lt.r.SystemChannelMessage)
let r=!0
const o=this.IsForceSystem(i)
let h=0
for(;h<i.Count();){let n=!1
if(n){const e=et.x.Inst().getItemById(t.i18nId)
if(null!=e){let t=0
for(;t<e.noticeLimitIds.Count();){if(e.noticeLimitIds[t]==s){n=!1
break}t+=1}}}const l=i[h]
if(this.fullLinkStr=null,this.textStr=Tt.p.GetResultText(this.sys.sys_messsage,t.infos,l,t.i18nId,e,this.sys.isFullClick),
this.textStr2=Tt.p.GetResultText(this.sys.sys_messsage2,t.infos,l,t.i18nId,e,this.sys.isFullClick,!0),1==this.sys.id){let t="####技能使用攻击距离不足 玩家 : ",e=G.M.IndexOf(this.textStr,t,0)
if(e>-1){
let t=G.M.IndexOf(this.textStr,",守方",e+19),i=G.M.SubStringWithEnd(this.textStr,e+19,t-5),s=G.M.SubStringWithEnd(this.textStr,t-5,t),n=1e5*G.M.String2Double(i),l=G.M.String2Double(s),a=U.GF.INT(n/4294967296),r=U.GF.INT(n%4294967296)
r+l>4294967296?(a+=1,r=r+l-4294967296):r+=l
k.o.New(r,a)}}let a=null
if(l==lt.r.SystemTipMessage)this.isOne?(this.frontTimer=mt.R.serverMSTime_get(),this.isOne=!1):(this.m_value=mt.R.serverMSTime_get(),this.delayTimer=this.m_value-this.frontTimer)
else if(l==lt.r.UnionChannelMessage)a=Y.d.Inst_get().model.AddTipChat(K.L.ALLIANCE,this.textStr,t.i18nId,t.infos,null,r,o,e,!1,!1,this.textStr2),r=!1
else if(l==lt.r.InvieteTeamChannelMessage)a=Y.d.Inst_get().model.AddTipChat(K.L.INVITE_TEAM,this.textStr,t.i18nId,t.infos,null,!1,!1,e,!1,!1,this.textStr2)
else if(l==lt.r.SystemChannelMessage)a=Y.d.Inst_get().model.AddTipChat(K.L.SYSTEM,this.textStr,t.i18nId,t.infos,null,r,o,e,!1,!1,this.textStr2),r=!1
else if(l==lt.r.WorldChannelMessage)a=Y.d.Inst_get().model.AddTipChat(K.L.WORLD,this.textStr,t.i18nId,t.infos,null,r,o,e,!1,!1,this.textStr2),r=!1
else if(l==lt.r.TempNotice||l==lt.r.TempNotice_ShowTip||l==lt.r.TempNotice_WithClose){const i=Q.B.UI_OPEN+(y.o.s_UNDER_CHAR+this.sys.ui)
let s=null
const n=Q.B.UI_OPEN+(y.o.s_UNDER_CHAR+this.sys.ui2)
this.sys.isFullClick>0?s=z.l.SetStringColor(z.l.txtGreenStr,`[${i}]`):(s=z.l.SetLinkStr(this.sys.tips,i,null,!0),s=z.l.SetStringColor(z.l.txtGreenStr,s))
let r=z.l.SetLinkStr(this.sys.tips2,n,null,!0)
z.l.IsEmptyStr(r)||(r=z.l.SetStringColor(z.l.txtGreenStr,r))
let o=`${this.textStr} ${s+r}`
this.sys.isFullClick>0&&(o=z.l.SetLinkStr(o,i,null,!1))
let h=`${this.textStr2} ${s+r}`
this.sys.isFullClick>0&&(h=z.l.SetLinkStr(h,i,null,!1))
const d=l==lt.r.TempNotice_ShowTip||lt.r.TempNotice_WithClose,_=l==lt.r.TempNotice_WithClose
a=Y.d.Inst_get().model.AddTipChat(K.L.NOTICE,o,t.i18nId,t.infos,this.textStr,!0,!1,e,d,_,h)
}else l==lt.r.STAll_ChannelMessage?(a=Y.d.Inst_get().model.AddTipChat(K.L.STALL,this.textStr,t.i18nId,t.infos,null,r,o,e,!1,!1,this.textStr2),
r=!1):l==lt.r.NearbyMsg?(a=Y.d.Inst_get().model.AddTipChat(K.L.NEARBY,this.textStr,t.i18nId,t.infos,null,r,o,e,!1,!1,this.textStr2),
r=!1):l==lt.r.RiversAndLakesSaid||l==lt.r.CopyMsgMessage&&pt.r.Inst_get().copyTxt_set(this.textStr)
let d=-1
if(e&&e.type==X.E.BossAssist&&(d=0),d>-1){let t=!0
if(S.Y.Inst.PrimaryRoleInfo_get().AccountIndex_get()==e.account&&(t=!1),t){const t=E.V.Inst().getStr2(this.m_asuramTipLans[d])
d<this.m_asuramTipIds.Count()?Y.d.Inst_get().model.RaiseEvent(J.F.SEND_CHAT_ASURAM_I18,t):Y.d.Inst_get().model.RaiseEvent(J.F.SEND_CHAT_ASURAM_ASSIST_I18,t)}}
this.OpenPanel(this.sys.sysTips.sysTip[h],t.i18nId,n),null!=a&&(a.fullLinkStr=this.fullLinkStr),h+=1}}DoAsuramAuctionI18Info(t){let e=0
if(null!=t){let i=0
for(;i<t.count;){if((0,m.t2)(t[i],rt.i)){e=t[i].time.ToNum()}i+=1}}}ClientSysMessage(t,e=null){if(this.sys=et.x.Inst().getItemById(t),
null==this.sys)return void(et.x.Inst().isNoCfg&&O.Y.LogError(t+(0,p.T)("不存在")))
O.Y.Info(`临时提示   ${this.sys.sys_messsage}`),pt.r.Inst_get().substituteStrs=e,null!=e?(this.textStr=z.l.Substitute(this.sys.sys_messsage,e),
this.textStr2=z.l.Substitute(this.sys.sys_messsage2,e)):(this.textStr=this.sys.sys_messsage,this.textStr2=this.sys.sys_messsage2)
const i=A.b.Inst.currentMapId_get(),s=ct.p.Inst_get().GetMapById(i)
let n=0
for(;n<this.sys.sysTips.sysTip.Count();){let e=!1
if(null!=s&&s.noticeLimit&&(e=!0),e){let t=0
for(;t<this.sys.noticeLimitIds.Count();){if(this.sys.noticeLimitIds[t]==i){e=!1
break}t+=1}}this.sys.sysTips.sysTip[n]==lt.r.SystemTipMessage&&(this.isOne?(this.frontTimer=mt.R.serverMSTime_get(),this.isOne=!1):(this.m_value=mt.R.serverMSTime_get(),
this.delayTimer=this.m_value-this.frontTimer)),this.OpenPanel(this.sys.sysTips.sysTip[n],t,e),n+=1}}ClientSysStrMsg(t){this.ClientStrMsg(lt.r.SystemTipMessage,t)}
ClientStrMsg(t=2,e="",i=null,s=""){null==t&&(t=lt.r.SystemTipMessage),pt.r.Inst_get().index=t,pt.r.Inst_get().handler=i,pt.r.Inst_get().selectPanelTitle=s
let n=null
if(t==lt.r.TwoSelectCircle)this.ClosePanel(t),pt.r.Inst_get().selectCircleStr=e,n=new N.v,n.layerType=v.F.Msg,
M.N.inst.OpenById(w.I.SelectCircle,this._degf_SelectHandler,this._degf_DestroySelect,n)
else if(t==lt.r.OneOkCircle)this.ClosePanel(t),pt.r.Inst_get().selectCircleStr=e,n=new N.v,n.layerType=v.F.Msg,
M.N.inst.OpenById(w.I.SelectCircle,this._degf_SelectHandler,this._degf_DestroySelect,n)
else if(t==lt.r.SystemTipMessage){if(null==this.sysTipsPanel||null==this.sysTipsPanel.node)return
this.sysTipsPanel.CurFirstShow(e)}else if(t==lt.r.BuffTip||t==lt.r.ImportantSysMsg){if(null==this.buffTipsPanel)return
this.buffTipsPanel.CurFirstShow(e)}}OpenCommonMessageTips(t){St.Z.Inst.OpenView(t)}closeCommonMessageTips(){St.Z.Inst.OutClosePanel()}CloseTopLayerMessageTips(t){null==t&&(t=!1)}
OpenPanel(t,e,i){null==i&&(i=!1),null==e&&(e=-1),pt.r.Inst_get().index=t
let s=""
if(t==lt.r.SystemTipMessage){if(null==this.sysTipsPanel||null==this.sysTipsPanel.node)return
s=-1!=G.M.IndexOf(this.textStr,y.o.s_UNDER_CHAR_DOLL,0)||-1!=G.M.IndexOf(this.textStr,G.M.s_LEFT_H_K_CHAR,0)?this.textStr2+(y.o.s_AND_CHAR+e):-1!=G.M.IndexOf(this.textStr,G.M.s_RIGHT_H_K_CHAR,0)?this.textStr2+(y.o.s_AND_CHAR+pt.r.Inst_get().curModelId):this.textStr2,
this.sysTipsPanel.CurFirstShow(s)}else if(t==lt.r.RiversAndLakesSaid||t==lt.r.CopyMsgMessage||t==lt.r.RiversAndLakesSaidEx){if(null==this.riAndLaPanel||i)return
this.isShowRiverTips&&ft.d.Inst_get().AddMsg(e,this.textStr2)}else if(t==lt.r.ScannerMsg){if(null==ut.Y.Inst_get().msgView||i)return
ut.Y.Inst_get().isShowScanner&&ut.Y.Inst_get().msgView.setData(this.textStr)}else if(t==lt.r.SystemNoticeMessage){if(null==this.sysChanPanel||i)return
this.isShowSysChanTips&&(pt.r.Inst_get().sysChanelStrs.Add(this.textStr),pt.r.Inst_get().sysChanIsExceed&&this.sysChanPanel.CurFirstShow())}else if(t==lt.r.ImportantSysMsg){
if(null==this.buffTipsPanel)return
this.buffTipsPanel.CurFirstShow(this.textStr)}else if(t==lt.r.CommonNoticeMsg){const t=et.x.Inst().getItemById(e),i=new gt.N
i.showText=this.textStr,14==e?(i.tipstype=2,i.okhandler=this._degf_ReActivity,i.okText=(0,p.T)("马上更新"),i.cancelText=(0,
p.T)("稍候提醒")):t.ui==R.D.ReActivity&&(i.okhandler=this._degf_ReturnToAccount,i.beforecancelhandler=this._degf_ReturnToAccount,i.cancelhandler=this._degf_ReturnToAccount),
this.OpenCommonMessageTips(i)}this.frontId=e,this.textStr="",this.textStr2=""}ReturnToAccount(t){T._.Inst.gameRestart()}OpenSysTipsPanel(){
if(null==this.sysTipsPanel||null==this.sysTipsPanel.node){const t=new N.v
t.layerType=v.F.Msg,t.positionType=P.Z.eCustom,t.ReLoginOrChangeRoleIsDestroy=!1,M.N.inst.OpenById(g.o.SystemCommonMessage,this._degf_SysShowHandler,this._degf_DestroySysShow,t),
M.N.inst.OpenById(g.o.SystemCommonMessage2,this._degf_SysShowHandler,this._degf_DestroySysShow,t)}else this.SetSysState(!0,!1)}OpenRiAndLaPanel(){
if(null==this.riAndLaPanel||0==this.riAndLaPanel.isShow_get()){const t=new N.v
t.layerType=v.F.Msg,t.ReLoginOrChangeRoleIsDestroy=!1,M.N.inst.OpenById(w.I.RiversAndLakesSaid,this._degf_RALShowHandler,this._degf_DestroyRALShow,t)
}else this.SetRiAndLaPanelState(!0)}OpenBuffTipPanel(){if(null==this.buffTipsPanel||0==this.buffTipsPanel.isShow_get()){const t=new N.v
t.layerType=v.F.Msg,t.positionType=P.Z.eCustom,t.ReLoginOrChangeRoleIsDestroy=!1,M.N.inst.OpenById(w.I.BuffTipPanel,this._degf_BuffShowHandler,this._degf_DestroyBuffShow,t)}}
RALShowHandler(t){return null==this.riAndLaPanel&&this.riAndLaPanel.SetIndex(lt.r.RiversAndLakesSaid),this.riAndLaPanel}ClosePanel(t,e){null==e&&(e=!1),
t==lt.r.SystemTipMessage?e?(M.N.inst.ClosePanel(this.sysTipsPanel),
this._sysTipsPanel=null):this.SetSysState(!1):t==lt.r.RiversAndLakesSaid?this.SetRiAndLaPanelState(!1):t==lt.r.TwoSelectCircle||t==lt.r.OneOkCircle?M.N.inst.ClosePanel(this.selectPanel):t==lt.r.SystemNoticeMessage&&this.SetSysChanPanelState(!1)
}ShowRiverAndLake(){null!=this.riAndLaPanel&&this.riAndLaPanel.CurFirstShow()}HandleMapChange(){null!=this.riAndLaPanel&&this.riAndLaPanel.HandleMapChange()}
OpenSystemChannelPanel(){if(null==this.sysChanPanel||0==this.sysChanPanel.isShow_get()){const t=new N.v
t.layerType=v.F.Msg,t.ReLoginOrChangeRoleIsDestroy=!1,M.N.inst.OpenById(w.I.SystemMessagePanel,this._degf_SysChanPanelShowHandler,this._degf_DestroySysChanPanel,t)
}else this.SetSysChanPanelState(!0)}SetSysChanPanelState(t){null!=this.sysChanPanel&&(this.isShowSysChanTips=t,this.sysChanPanel.ClearData(),
this.sysChanPanel.node.SetActive(this.isShowSysChanTips))}},_._inst=null,Ct(d=_,"inst",[u.Vx],Object.getOwnPropertyDescriptor(d,"inst"),d),
Ct(d.prototype,"SM_NoticeItemInfoHandler",[n],Object.getOwnPropertyDescriptor(d.prototype,"SM_NoticeItemInfoHandler"),d.prototype),
Ct(d.prototype,"SM_NoticeItemInfoTwoHandler",[l],Object.getOwnPropertyDescriptor(d.prototype,"SM_NoticeItemInfoTwoHandler"),d.prototype),
Ct(d.prototype,"SM_Notify_MessageHandler",[a],Object.getOwnPropertyDescriptor(d.prototype,"SM_Notify_MessageHandler"),d.prototype),
Ct(d.prototype,"SM_DyNotify_MessageHandler",[r],Object.getOwnPropertyDescriptor(d.prototype,"SM_DyNotify_MessageHandler"),d.prototype),
Ct(d.prototype,"SM_UpdateDyNotifyStatusHandler",[o],Object.getOwnPropertyDescriptor(d.prototype,"SM_UpdateDyNotifyStatusHandler"),d.prototype),h=d))||h)},39043:(t,e,i)=>{i.d(e,{
V:()=>_})
var s=i(98800),n=i(97461),l=i(68662),a=i(5924),r=i(98885),o=i(92679),h=i(50600),d=i(84141)
class _{constructor(){this.timePass=0,this.listStr="",this.timerID=-1,this._degf_DoTimePass=null,this._degf_DoTimePass=()=>this.DoTimePass(),
this.listStr=h.a.inst.ReadValue(_.STRING_KEY),this.listStr||(this.listStr="")
const t=h.a.inst.ReadValue(_.TIME_PASS)
""!=t&&(this.timePass=r.M.String2Double(t)),this.CountTime()}static Inst_get(){return null==_._Inst&&(_._Inst=new _),_._Inst}SetData(t,e){h.a.inst.SetBool(t,e),
r.M.Contains(this.listStr,t)||(this.listStr+=`|${t}`,h.a.inst.SetValue(_.STRING_KEY,this.listStr))}SetStrData(t,e){h.a.inst.SetValue(t,e),
r.M.Contains(this.listStr,t)||(this.listStr+=`|${t}`,h.a.inst.SetValue(_.STRING_KEY,this.listStr))}GetData(t){return!!r.M.Contains(this.listStr,t)&&h.a.inst.GetBool(t)}
GetStrData(t){return r.M.Contains(this.listStr,t)?h.a.inst.GetStrValue(t):null}CountTime(){const t=l.D.serverMSTime_get()
this.timePass>-1e-6&&this.timePass<1e-6&&this.ResetTimeStamp(t),l.D.serverMSTime_get()<this.timePass&&this.ResetTimeStamp(t),
this.timerID=a.C.Inst_get().SetFrameLoop(this._degf_DoTimePass,30),this.DoTimePass()}DoTimePass(){
l.D.serverMSTime_get()>this.timePass&&(this.ResetTimeStamp(l.D.serverMSTime_get()),this.ResetData())}ResetTimeStamp(t){let e=d.E.New(t)
this.timePass=e.time_get(),e.setHours(0,0,0,0),this.timePass=e.time_get(),d.E.Recycle(e),e=null,this.timePass=this.timePass+864e5+18e6,
h.a.inst.SetValue(_.TIME_PASS,r.M.DoubleToString(this.timePass))}ResetData(){const t=r.M.Split(this.listStr,"|")
let e=0
for(;e<t.count;)h.a.inst.SetBool(t[e],!1),e+=1
n.i.Inst.RaiseEvent(o.g.COMMON_REMIND_DATA_RESET_BEFORCE),n.i.Inst.RaiseEvent(o.g.COMMON_REMIND_DATA_RESET)}DeleteData(){this.listStr="",h.a.inst.SetValue(_.STRING_KEY,""),
h.a.inst.SetValue(_.TIME_PASS,"")}GetRolePrefix(){return s.Y.Inst.PrimaryRoleInfo_get().accountindex}}_._Inst=null,_.STRING_KEY="STRING_KEY",_.TIME_PASS="TIME_PASS"},
85942:(t,e,i)=>{i.d(e,{N:()=>l})
var s=i(86133),n=i(52726)
class l{constructor(){this.cfgID="",this.showText="",this.titleText=null,this.okhandler=null,this.objparams=null,this.beforecancelhandler=null,this.cancelObjparams=null,
this.cancelhandler=null,this.tipstype=1,this.okText=null,this.cancelText=null,this.needCheckBox=!1,this.checkhandler=null,this.checkChanged=null,this.btnColorType=1,
this.extraStr="",this.needLefttIime=!1,this.leftTime=5,this.okBtnWidth=86,this.isShowCloseBtn=!0,this.isShowMask=!0,this.checkBoxStr=null,this.isCheckBoxOn=!0,
this.isDoCancleInClose=!0,this.isDoOkInClose=!1,this.panelLayer=n.F.Tip,this.clickMaskIsClose=!1,this.roleDeadClose=!0,this.maskAlpha=0,this.titleText=(0,s.T)("提 示"),
this.okText=(0,s.T)("确 定"),this.cancelText=(0,s.T)("取 消"),this.checkBoxStr=(0,s.T)("今天不再提醒")}}},35042:(t,e,i)=>{i.d(e,{X:()=>s})
class s{}s.Unconformity_Level=102027,s.Unconformity_Pro=102028,s.UnNumPack=101001,s.UnAttr=100533,s.EquipTypeTip=102029,s.GetMoneyGoin=100524,s.GetAutoSellMoneyGoin=200015,
s.GetBulkSellMoneyGoin=200018,s.LostMoneyCoin=100561,s.GetMoneyGold=100525,s.GetQuestionMoneyGold=114224,s.GetQuestionTop1MoneyGold=114227,s.GetConsignScore=100526,
s.GetVitalityNum=115005,s.GetHornor=100527,s.GetExp=100528,s.GetSkillPoint=100529,s.GetFriendPoint=100584,s.GetAchievePoint=100530,s.LostMoneyBlue=100532,s.GetLotteryScore=100531,
s.GetAsuramGold=100558,s.GetTimePoint=420020,s.SellKind=101502,s.Unconformity_Sex=102051,s.ClearCoolTimer=107007,s.InCopy=107002,s.EncourgeDefeat=107013,
s.PleaseSelectCompoundItem=-1901,s.CompoundConsumeItemLose=-1900,s.CompoundCoreItemLose=-1906,s.CompoundDefeat=-1902,s.NoChatToSelf=112006,s.LotteryTipByTypeOne="140005",
s.LotteryTipByTypeTwo="140006",s.LotteryTipByTypeThree="140008",s.LotteryTipByTypeFour="140009",s.HorseUp="180001",s.AstrolabeDeblocking="210004",s.AstrolabeUpLv="210005",
s.PromoteCostResUnEnough=102063,s.PromoteCostNumUnEnough=102064,s.ASURAM_SCROE_ADD=114078,s.SUIT_SCROE_ADD=250018,s.ASURAM_TOKEN_ADD=100599,s.HONOUR_POINT_ADD=10810019,
s.FactoryShopRefresh="200001",s.HONOUR__SHOP_POINT=11030322},29587:(t,e,i)=>{i.d(e,{r:()=>n})
var s=i(85602)
class n{constructor(){this.index=0,this.handler=null,this.selectPanelTitle="",this._commonTipMessageStr="",this.selectCircleStr="",this.riversAndLakesSaidStrs=null,
this.sysChanelStrs=null,this.undertoneStr="",this.curModelId=0,this.substituteStrs=null,this.TextLength=9,this.currentIndex=0,this.delayTimer=500,this.riverIsExceed=!0,
this.systemIsExceed=!0,this.buffIsExceed=!0,this.sysChanIsExceed=!0,this.m_copyTxt=null,this.riversAndLakesSaidStrs=new s.Z,this.sysChanelStrs=new s.Z}copyTxt_get(){
return this.m_copyTxt}copyTxt_set(t){this.m_copyTxt=t}static Inst_get(){return null==n._Inst&&(n._Inst=new n),n._Inst}}n._Inst=null},23450:(t,e,i)=>{i.d(e,{$:()=>p})
var s,n=i(18998),l=i(6847),a=i(83908),r=i(49655),o=i(46282),h=i(5924),d=i(66788),_=i(98130),u=i(98885),I=i(5968),c=i(39043),g=i(50089)
let p=(0,l.s_)(r.o.eCommonHintPanel,o.Z.ui_commonhint_hintpanel).layerTip().register()(s=class extends((0,a.Ri)()){constructor(...t){super(...t),this.m_tipVo=null,
this._lefttimeintervalId=-1,this._lefttime=0,this.isTrueSelect=!1,this._degf_OKHandler=null,this._degf_OnBtnClick=null,this._degf_OnFullClick=null,this._degf_SelectHandler=null,
this._degf_TimeChange=null}_initBinder(){super._initBinder(),this._degf_OKHandler=(t,e)=>this.OKHandler(t,e),this._degf_OnBtnClick=(t,e)=>this.OnBtnClick(t),
this._degf_OnFullClick=(t,e)=>this.OnFullClick(t,e),this._degf_SelectHandler=(t,e)=>this.SelectHandler(t,e),this._degf_TimeChange=()=>this.TimeChange()}InitView(){
this.txtContainer.active=!0,this.AddOrDelEvent(!0)}onPanelAdded(){this.m_tipVo=I.Z.Inst.tipVo,this.UpdateView()}UpdateView(){
u.M.IsNullOrEmpty(this.m_tipVo.okText)&&(this.m_tipVo.okText="确定",d.Y.LogError("CommonHintPanel self.m_tipVo.okText is null")),this.contextLabel.node.transform.width=490,
this.contextLabel.string=this.m_tipVo.showText,g.t.SetAllChildrenActive(this.contextLabel.node,!0),this.titleLabel.string=this.m_tipVo.titleText,
this.sureLabel.string=this.m_tipVo.okText,this.canelLabel.string=this.m_tipVo.cancelText,this.select.node.active=this.isTrueSelect,this.checkbox.active=this.m_tipVo.needCheckBox,
this.closeBtn.node.active=this.m_tipVo.isShowCloseBtn,this.checkBoxLabel.string=this.m_tipVo.checkBoxStr,this.select.node.active=this.m_tipVo.isCheckBoxOn,
this.isTrueSelect=this.m_tipVo.isCheckBoxOn,this.SetLabelY(),1==this.m_tipVo.tipstype?(this.cancelBtn.node.active=!1,
this.sureBtn.node.position=new n.Vec3(0,-110,0)):2==this.m_tipVo.tipstype&&(this.cancelBtn.node.active=!0,this.sureBtn.node.position=new n.Vec3(139,-110,0)),
this.m_tipVo.needLefttIime&&(this.sureLabel.string=`${this.m_tipVo.okText}(${this.m_tipVo.leftTime})`,h.C.Inst_get().ClearInterval(this._lefttimeintervalId),
this._lefttime=this.m_tipVo.leftTime,this._lefttimeintervalId=h.C.Inst_get().SetInterval(this._degf_TimeChange,1e3))}SetLabelY(){let t=178
this.m_tipVo.needCheckBox&&(t=142)
const e=this.contextLabel.node.transform.contentSize,i=_.GF.INT(.5*(t-e.y)),s=this.txtContainer.position
s.y=114-i,this.txtContainer.position=s}TimeChange(){if(this._lefttime-=1,this._lefttime<1)return h.C.Inst_get().ClearInterval(this._lefttimeintervalId),this._lefttimeintervalId=-1,
void this.OKHandler(0)
this.sureLabel.string=`${this.m_tipVo.okText}(${this._lefttime})`}OKHandler(t=null,e=null){null==e&&(e=0),null==t&&(t=0),h.C.Inst_get().ClearInterval(this._lefttimeintervalId),
this._lefttimeintervalId=-1,I.Z.Inst.ClosePanel(),this.m_tipVo.needCheckBox&&c.V.Inst_get().SetData(c.V.Inst_get().GetRolePrefix()+this.m_tipVo.cfgID,this.isTrueSelect),
null!=this.m_tipVo.okhandler&&this.m_tipVo.okhandler(this.m_tipVo.objparams),this.DealAfterOk()}DealAfterOk(){}SelectHandler(t,e){this.select.node.active=!this.isTrueSelect,
this.isTrueSelect=!this.isTrueSelect,null!=this.m_tipVo.checkChanged&&this.m_tipVo.checkChanged(this.isTrueSelect)}AddOrDelEvent(t){
t&&(this.sureBtn.node.on(n.NodeEventType.TOUCH_END,this._degf_OKHandler,this),this.cancelBtn.node.on(n.NodeEventType.TOUCH_END,this._degf_OnBtnClick,this),
this.closeBtn.node.on(n.NodeEventType.TOUCH_END,this._degf_OnBtnClick,this))}OnFullClick(t,e){this.m_tipVo.clickMaskIsClose&&this.OnBtnClick(this.closeBtn)}RegGuide(){}
UnRegGuide(){}OnBtnClick(t){t.target.name==this.cancelBtn.node.name?(null!=this.m_tipVo.beforecancelhandler&&this.m_tipVo.beforecancelhandler(this.m_tipVo.cancelObjparams),
null!=this.m_tipVo.cancelhandler&&this.m_tipVo.cancelhandler(!0),
I.Z.Inst.ClosePanel()):t.target.name==this.closeBtn.node.name&&(null!=this.m_tipVo.okhandler&&this.m_tipVo.isDoOkInClose&&this.m_tipVo.okhandler(!0),
null!=this.m_tipVo.cancelhandler&&this.m_tipVo.isDoCancleInClose&&this.m_tipVo.cancelhandler(!1)),I.Z.Inst.ClosePanel()}Clear(){
h.C.Inst_get().ClearInterval(this._lefttimeintervalId)}Destroy(){this.AddOrDelEvent(!1)}})||s},64004:(t,e,i)=>{i.d(e,{w:()=>p})
var s,n=i(18998),l=(i(22267),i(83908)),a=i(62370),r=i(5924),o=i(18202),h=i(83540),d=i(98130),_=i(98885),u=i(33138),I=i(19519),c=i(35042),g=i(50089)
let p=n._decorator.ccclass("GetRewardTipItem")(s=class extends((0,l.yk)()){constructor(t){super(t),this.info="",this.iconWidth=16,this.iconPreName="rycommon_currency_",
this.oneFontWidth=20,this.curSprite=null,this.curPanelIndex=0,this._handler=null,this.animTimer=-1,this.interval=-1,this.id=null,this.blankStr=null,
this._degf_FirstDelayHandler=null,
this._degf_SecondDelayHandler=null,this.blankStr=_.M.s_SPACE_CHAR+(_.M.s_SPACE_CHAR+(_.M.s_SPACE_CHAR+(_.M.s_SPACE_CHAR+(_.M.s_SPACE_CHAR+(_.M.s_SPACE_CHAR+_.M.s_SPACE_CHAR))))),
this._degf_FirstDelayHandler=()=>this.FirstDelayHandler(),this._degf_SecondDelayHandler=()=>this.SecondDelayHandler()}InitView(){}SetData(t,e,i){if(this._handler=i,
this.curPanelIndex=e,this.currencyIcon.node.SetActive(!1),this.itemIcon.node.SetActive(!1),this.expIcon.node.SetActive(!1),this.bg.node.SetActive(!1),
this.secondItemIcon.node.SetActive(!1),this.info=t,""==t)return void this.text.textSet("")
let s="",n="",l=!1,d=!1
this.curSprite=null
let p=0
if(-1==_.M.IndexOf(t,a.o.s_UNDER_CHAR_DOLL,0)&&-1==_.M.IndexOf(t,_.M.s_RIGHT_H_K_CHAR,0)&&-1==_.M.IndexOf(t,_.M.s_LEFT_H_K_CHAR,0))n=this.info
else{const e=_.M.Split(t,a.o.s_AND_CHAR)
if(null==e||e.count<2)return
var m
if(p=_.M.String2Int(e[1]),n=e[0],m=-1!=n.indexOf("[-]")?"        ":"            ",-1!=_.M.IndexOf(t,a.o.s_UNDER_CHAR_DOLL,0)){let t
this.curSprite=this.currencyIcon,l=!0,n=_.M.ReplaceSlow(n,a.o.s_UNDER_CHAR_DOLL,m),
p==c.X.GetMoneyGoin||p==c.X.GetAutoSellMoneyGoin||p==c.X.GetBulkSellMoneyGoin||p==c.X.LostMoneyCoin?t=I.J.GOLD_STR:p==c.X.GetMoneyGold||p==c.X.GetQuestionTop1MoneyGold?t=I.J.GOLD_DIAMOND_STR:p==c.X.GetConsignScore?t=I.J.ScoreStr:p==c.X.GetSkillPoint?t=I.J.SkillPointStr:p==c.X.GetAchievePoint?t=I.J.VitalityNumStr:p==c.X.GetLotteryScore?t=I.J.LotteryDragonStr:p==c.X.GetHornor?t=I.J.HonourStr:p==c.X.GetTimePoint||p==c.X.GetVitalityNum||(p==c.X.GetFriendPoint||p==c.X.GetQuestionMoneyGold?t=I.J.ReputationStr:p==c.X.GetAsuramGold?t=I.J.ALLIANCE_FUND_STR:p==c.X.SUIT_SCROE_ADD||(p==c.X.ASURAM_TOKEN_ADD?t=I.J.ASURAM_TOKEN_STR:p==c.X.HONOUR_POINT_ADD?t=I.J.HONOUR_POINT_STR:p==c.X.HONOUR__SHOP_POINT&&(t=I.J.HONOR_MANUAL_POINT))),
this.id=t,t&&(s=I.J.GetCurrencyIconUrl(t))}else if(-1!=_.M.IndexOf(t,_.M.s_RIGHT_H_K_CHAR,0)){if(n=_.M.Replace(n,_.M.s_RIGHT_H_K_CHAR,m),0!=p){const t=u.f.Inst().getItemById(p)
this.id=p,null!=t&&(this.curSprite=this.itemIcon,l=!0,s=t.icon,d=!0)}}else-1!=_.M.IndexOf(t,_.M.s_LEFT_H_K_CHAR,0)&&(n=_.M.Replace(n,_.M.s_LEFT_H_K_CHAR,m),
this.curSprite=this.expIcon,l=!0,s="rycommon_currency_0007")}""!=n&&(this.bg.node.SetActive(!0),r.C.Inst_get().ClearInterval(this.interval),this.SetBg())
const S=_.M.TransRichTextHref(n)
this.text.textSet(S),g.t.SetAllChildrenActive(this.text.node,!0),l&&this.SetIconPos(n,p),null!=this.curSprite&&(this.curSprite.node.SetActive(l),
d?o.g.SetItemIcon(this.curSprite,s,h.b.eItem,!1):this.curSprite.spriteNameSet(s)),this.widgetalpha.opacity=255,this.ClearAnimTimer(),r.C.Inst_get().ClearInterval(this.animTimer),
this.animTimer=-1,this.animTimer=r.C.Inst_get().SetInterval(this._degf_FirstDelayHandler,1e3,1)}static GetMsgItemType(t){const e=_.M.Split(t,a.o.s_AND_CHAR)
if(null==e||e.count<2)return null
const i=_.M.String2Int(e[1])
if(-1!=_.M.IndexOf(t,a.o.s_UNDER_CHAR_DOLL,0)){let t=null
return i==c.X.GetMoneyGoin||i==c.X.GetAutoSellMoneyGoin||i==c.X.GetBulkSellMoneyGoin||i==c.X.LostMoneyCoin?t=I.J.GOLD_STR:i==c.X.GetMoneyGold||i==c.X.GetQuestionTop1MoneyGold?t=I.J.GOLD_DIAMOND_STR:i==c.X.GetConsignScore?t=I.J.ScoreStr:i==c.X.GetSkillPoint?t=I.J.SkillPointStr:i==c.X.GetAchievePoint?t=I.J.VitalityNumStr:i==c.X.GetLotteryScore?t=I.J.LotteryDragonStr:i==c.X.GetHornor?t=I.J.HonourStr:i==c.X.GetFriendPoint||i==c.X.GetQuestionMoneyGold?t=I.J.ReputationStr:i==c.X.GetAsuramGold?t=I.J.ALLIANCE_FUND_STR:i==c.X.ASURAM_TOKEN_ADD?t=I.J.ASURAM_TOKEN_STR:i==c.X.HONOUR_POINT_ADD?t=I.J.HONOUR_POINT_STR:i==c.X.HONOUR__SHOP_POINT&&(t=I.J.HONOR_MANUAL_POINT),
t}return i}SetBg(){}FirstDelayHandler(){this.ClearAnimTimer(),this.animTimer=r.C.Inst_get().SetInterval(this._degf_SecondDelayHandler,100)}ClearAnimTimer(){
r.C.Inst_get().ClearInterval(this.animTimer),this.animTimer=-1}SecondDelayHandler(){this.widgetalpha.opacity=this.widgetalpha.opacity-51,
this.widgetalpha.opacity<=0&&(this.widgetalpha.opacity=0,this.ClearAnimTimer(),null!=this._handler&&this._handler())}Reset(){this.widgetalpha.opacity=0,this.ClearAnimTimer()}
SetIconPos(t,e){if(!_.M.IsNullOrEmpty(t)){for(;;){const e=_.M.IndexOf(t,_.M.s_LEFT_M_K_CHAR,0),i=_.M.IndexOf(t,_.M.s_RIGHT_M_K_CHAR,0)
if(-1==e||-1==i)break
{const s=_.M.SubStringWithEnd(t,e,i+1)
t=_.M.ReplaceSlow(t,s,""),t=_.M.ReplaceSlow(t,"[-]","")}}_.M.Length(t)
let i=0
if(i=_.M.IndexOf(t,_.M.s_SPACE_CHAR,0),-1!=i){let t=d.GF.INT((i+1)*this.oneFontWidth)-d.GF.INT(this.text.textWidth/2)
e!=c.X.GetAutoSellMoneyGoin&&e!=c.X.GetBulkSellMoneyGoin||(t-=10)
const s=new n.Vec3(t,this.curSprite.node.position.y,this.curSprite.node.position.z)
this.curSprite.node.position=s}}}Destroy(){this.ClearAnimTimer(),r.C.Inst_get().ClearInterval(this.interval)}})||s},41321:(t,e,i)=>{
var s,n=i(18998),l=i(6847),a=i(83908),r=i(17409),o=i(49655),h=i(46282),d=i(57553);(0,l.s_)(o.o.PolicyPanel,h.Z.ui_policy_view).layerTip().register()(s=class extends((0,a.Ri)()){
constructor(...t){super(...t),this.titleArr=["适龄提示","用户协议","隐私政策"],this.policyState=0,this.isTrueSelect=!1}_initBinder(){super._initBinder()}InitView(){super.InitView(),(0,
r.D1)(this,this.CreateDelegate(this.Close)),this.txtContainer.active=!0,this.AddOrDelEvent(!0)}onPanelAdded(){
this.policyState=__$LaunchLogicBridge._getLaunchPanelCtrl().policyState,this.contextLabel.string="协议",this.titleLabel.string=this.titleArr[this.policyState],
this.sureLabel.string="确定",d._.Inst.model.jsons[this.policyState]&&(this.contextLabel.string=d._.Inst.model.jsons[this.policyState],
this.content.heightSet(this.contextLabel.height()))}selectHandler(){this.isTrueSelect=!this.isTrueSelect}onCloseClick(){(0,r.sR)(o.o.PolicyPanel)}AddOrDelEvent(t){
t?this.sureBtn.node.on(n.NodeEventType.TOUCH_END,this.onCloseClick,this):this.sureBtn.node.off(n.NodeEventType.TOUCH_END,this.onCloseClick,this)}Close(){(0,r.sR)(o.o.PolicyPanel)}
RegGuide(){}UnRegGuide(){}Clear(){}Destroy(){}})},58653:(t,e,i)=>{
var s,n,l=i(18998),a=i(21370),r=i(6847),o=i(83908),h=i(46282),d=i(13687),_=i(5494),u=i(3809),I=i(98130),c=i(98885),g=i(52212),p=i(26753),m=i(98407),S=i(14143),T=i(87923),f=i(57940),C=i(94826),E=i(48933),A=i(21334),L=i(12862),y=i(71893),D=i(95155),O=i(2295),R=i(65550),N=i(35042),M=i(29587)
;(0,r.s_)(_.I.RiversAndLakesSaid,h.Z.ui_systemtips_riversandlakessaid).layerSet(a.T.msg).register()((n=class t extends((0,o.Ri)()){constructor(...t){super(...t),
this.container=null,this.viewWidth=0,this.textShow="",this.curIndex=0,this._model=null,this._degf_AnimEnd=null,this._degf_ClickHandler=null}_initBinder(){
this._degf_AnimEnd=()=>this.AnimEnd(),this._degf_ClickHandler=(t,e)=>this.ClickHandler(t,e)}InitView(){this.container=this.Container,this.container.SetActive(!1),
C.C.Inst_get().RegisterObj(f.k.riverAndLakeView,this.container),this.AddClickEvent(this.labelText.node,this._degf_ClickHandler),this.tweenPos.AddEventHandler(this._degf_AnimEnd),
this._model=M.r.Inst_get()}OnAddToScene(){}CurFirstShow(){let t=-100
const e=this.GetOffsetY()
0!=e&&(t=e),C.C.Inst_get().SetActiveById(f.k.riverAndLakeView,!0),E.I.calVec0.Set(0,t,0),this.container.transform.SetLocalPosition(E.I.calVec0),M.r.Inst_get().riverIsExceed=!1,
this.setData()}HandleMapChange(){M.r.Inst_get().riverIsExceed||(O.d.Inst_get().IsShowRiAndLa()?this.CurFirstShow():(C.C.Inst_get().SetActiveById(f.k.riverAndLakeView,!1),
M.r.Inst_get().riverIsExceed=!1))}GetOffsetY(){if(null==d.b.Inst)return 0
const t=d.b.Inst.currentMapId_get()
if(null!=t&&0!=t){const e=A.p.Inst_get().GetMapById(t)
return null!=e?e.horseRaceLamp:0}return 0}Clear(){this.ClearData()}SetIndex(t){this.curIndex=t}ClickHandler(t,e){
const i=t.touch.getLocation(),s=this.labelText.GetUrlAtPositionVec3(new l.Vec3(i.x,i.y,0))
if(!T.l.IsEmptyStr(s)){
s!=N.X.LotteryTipByTypeOne&&s!=N.X.LotteryTipByTypeTwo&&s!=N.X.LotteryTipByTypeThree&&s!=N.X.LotteryTipByTypeFour||y.u.Inst_get().isCurShowLottery||(y.u.Inst_get().viewType=D.S.LOTTETY,
L.z.inst.OpenView())
const t=p.d.Inst_get().model.GetShowList(S.L.TOTAL)
let e=0
for(;e<t.Count();)t[e].smChat.content==this.labelText.text&&m.C.OnTxtClick(this.labelText,t[e]),e+=1}}setData(){
if(!O.d.Inst_get().IsShowRiAndLa())return C.C.Inst_get().SetActiveById(f.k.riverAndLakeView,!1),void(M.r.Inst_get().riverIsExceed=!0)
if(0!=this._model.riversAndLakesSaidStrs.Count()){let e=this._model.riversAndLakesSaidStrs[0]
u.B.PopFront(this._model.riversAndLakesSaidStrs),this.labelText.widthSet(t.maxWidth),e=c.M.TransRichTextHref(e),console.log("text:",e),this.labelText.textSet(e)
const i=this.labelText.printedSize().x,s=this.labelText.printedSize().y
this.labelText.widthSet(I.GF.INT(2*i)),this.labelText.heightSet(I.GF.INT(s)),this.boxCollider.sizeSet(new g.F(i,s)),this.viewWidth=this.panel.node.transform.width,
E.I.calVec0.Set(this.viewWidth/2,0,0),this.labelText.node.transform.SetLocalPosition(E.I.calVec0),this.AnimStart()}else this.ClearData()}AnimStart(){
const t=this.labelText.node.transform.GetLocalPosition()
this.tweenPos.SetFrom(t),E.I.calVec0.Set(-(this.viewWidth/2+this.labelText.printedSize().x),0,0),this.tweenPos.SetTo(E.I.calVec0)
const e=Math.abs(this.tweenPos.GetTo().x-this.tweenPos.GetFrom().x)/120
this.tweenPos.durationSet(e),this.tweenPos.ResetToBeginning(),this.tweenPos.PlayForward()}AnimEnd(){0==this._model.riversAndLakesSaidStrs.Count()?this.ClearData():this.setData()}
ClearData(){this._model.riversAndLakesSaidStrs.Clear(),M.r.Inst_get().riverIsExceed=!0,C.C.Inst_get().SetActiveById(f.k.riverAndLakeView,!1)}closePanel(){
R.y.inst.ClosePanel(this.curIndex)}Destroy(){C.C.Inst_get().UnregisterObj(f.k.riverAndLakeView),this.tweenPos.RemoveEventHandler(this._degf_AnimEnd),
this.RemoveClickEvent(this.labelText.node,this._degf_ClickHandler),this.container=null}filterColor(t){let e=0
for(e=0;e<1;++e)(t.indexOf("[B]")>0||t.indexOf("[b]")>0)&&(t=(t=t.replace("[B]","<b>")).replace("[b]","<b>"),e--)
let i=0
for(i=0;i<1;++i)(t.indexOf("[/B]")>0||t.indexOf("[/b]")>0)&&(t=(t=t.replace("[/B]","</b>")).replace("[/b]","</b>"),i--)
let s=0
for(s=0;s<1;++s)t.indexOf("[-]")>0&&(t=t.replace("[-]","</color>"),s--)
const n=/\\\[.*?\\\]/
let l=t.match(/\[.*?\]/g)
if(l&&l.length)for(let e=0;e<l.length;e++){const i=l[e]
let s=""
if(null==i.match(/\\/)&&(s=i.substring(1,i.length-1)||"",s)){const e=`<color=#${s}>`
t=t.replace(i,e)}}let a=t.match(n),r=""
for(;null!=a;)r=a[0].slice(2,a[0].length-2),a=(t=t.replace(n,`[${r}]`)).match(n)
return t}},n.maxWidth=1e3,s=n))},48754:(t,e,i)=>{
var s,n,l=i(21370),a=i(6847),r=i(83908),o=i(46282),h=i(65530),d=i(5494),_=i(3809),u=i(98130),I=i(98885),c=i(52212),g=i(87923),p=i(57940),m=i(94826),S=i(48933),T=i(22662),f=i(12862),C=i(71893),E=i(95155),A=i(65550),L=i(35042),y=i(29587)
;(0,a.s_)(d.I.SystemMessagePanel,o.Z.ui_systemtips_riversandlakessaid).layerSet(l.T.msg).register()((n=class t extends((0,r.Ri)()){constructor(...t){super(...t),
this.container=null,this.viewWidth=0,this.textShow="",this.curIndex=0,this._model=null,this._degf_AnimEnd=null,this._degf_ClickHandler=null}_initBinder(){
this._degf_AnimEnd=()=>this.AnimEnd(),this._degf_ClickHandler=(t,e)=>this.ClickHandler(t,e)}InitView(){this.container=this.Container,
m.C.Inst_get().RegisterObj(p.k.sysChanPanelView,this.container),this.AddClickEvent(this.labelText,this._degf_ClickHandler),this.tweenPos.AddEventHandler(this._degf_AnimEnd),
this._model=y.r.Inst_get(),this.Container.SetActive(!1),this.SetIndex(T.r.SystemNoticeMessage)}OnAddToScene(){}CurFirstShow(){
this.curIndex==T.r.SystemNoticeMessage&&(m.C.Inst_get().SetActiveById(p.k.sysChanPanelView,!0),S.I.calVec0.Set(0,-180,0),this.container.transform.SetLocalPosition(S.I.calVec0),
y.r.Inst_get().sysChanIsExceed=!1),this.setData()}Clear(){this.ClearData()}SetIndex(t){this.curIndex=t}ClickHandler(t,e){
const i=this.labelText.GetUrlAtPositionVec3(h.x.Instance_get().LastWorldPosition())
g.l.IsEmptyStr(i)||i!=L.X.LotteryTipByTypeOne&&i!=L.X.LotteryTipByTypeTwo&&i!=L.X.LotteryTipByTypeThree&&i!=L.X.LotteryTipByTypeFour||C.u.Inst_get().isCurShowLottery||(C.u.Inst_get().viewType=E.S.LOTTETY,
f.z.inst.OpenView())}setData(){if(0!=this._model.sysChanelStrs.Count()){let e=this._model.sysChanelStrs[0]
e=I.M.Replace(e,"\n"," "),_.B.PopFront(this._model.sysChanelStrs),this.labelText.widthSet(t.maxWidth),e=I.M.TransRichTextHref(e),this.labelText.textSet(e)
const i=this.labelText.printedSize().x,s=this.labelText.printedSize().y
this.labelText.widthSet(u.GF.INT(2*i)),this.labelText.heightSet(u.GF.INT(s)),this.boxCollider.sizeSet(new c.F(i,s)),this.viewWidth=this.panel.node.transform.contentSize.x,
S.I.calVec0.Set(this.viewWidth/2,0,0),this.labelText.node.transform.SetLocalPosition(S.I.calVec0),this.AnimStart()}else this.ClearData()}AnimStart(){
this.tweenPos.SetFrom(this.labelText.node.transform.GetLocalPosition()),S.I.calVec0.Set(-(this.viewWidth/2+this.labelText.printedSize().x),0,0),this.tweenPos.SetTo(S.I.calVec0)
const t=Math.abs(this.tweenPos.GetTo().x-this.tweenPos.GetFrom().x)/120
this.tweenPos.durationSet(t),this.tweenPos.ResetToBeginning(),this.tweenPos.PlayForward()}AnimEnd(){
this.curIndex==T.r.SystemNoticeMessage&&(0==this._model.sysChanelStrs.Count()?this.ClearData():this.setData())}ClearData(){this._model.sysChanelStrs.Clear(),
y.r.Inst_get().sysChanIsExceed=!0,m.C.Inst_get().SetActiveById(p.k.sysChanPanelView,!1)}closePanel(){A.y.inst.ClosePanel(this.curIndex)}Destroy(){
m.C.Inst_get().UnregisterObj(p.k.sysChanPanelView),this.tweenPos.RemoveEventHandler(this._degf_AnimEnd),this.RemoveClickEvent(this.labelText,this._degf_ClickHandler),
this.container=null}},n.maxWidth=1e3,s=n))},69148:(t,e,i)=>{i.d(e,{t:()=>T})
var s,n=i(18998),l=i(21370),a=i(34565),r=i(6847),o=i(83908),h=i(49655),d=i(46282),_=i(5924),u=(i(66788),i(85602)),I=i(57940),c=i(94826),g=i(75439),p=i(22662),m=i(88010),S=i(64004)
let T=(0,r.s_)(h.o.SystemCommonMessage,d.Z.ui_systemtips_tipmessagepanel).layerSet(l.T.msg).register()(s=class extends((0,o.pA)(a.I)()){constructor(...t){super(...t),
this.textShow=null,this.text=null,this.timer=-1,this.curPanelIndex=0,this.showItem=null,this.moveHeight=10,this._curIndex=0,this._count=0,this.pos=null,this.strPosY=0,
this.targetPosY=0,this._degf_MoveAnimHandler=null,this._degf_completeHandler=null}_initBinder(){super._initBinder(),this.showItem=new u.Z,this.pos=new u.Z([110,66,22]),
this._degf_MoveAnimHandler=()=>this.MoveAnimHandler(),this._degf_completeHandler=()=>this.completeHandler(),this.textShow=new u.Z}InitView(){this.text=new u.Z,
this.text.Add(this.itemOne),this.text.Add(this.itemTwo),this.text.Add(this.itemThree),this.empty.active=!1}OnAddToScene(){this.UpdatePos()}resetPosY(t){
this.widget.position=new n.Vec3(25,this.strPosY,0)
let e=null,i=this._count-1
for(;i>=0;)e=this.text[t],null!=e&&(e.node.position=new n.Vec3(0,this.pos[i],0)),(t-=1)<0&&(t=2),i-=1}addIndex(t){return 3==(t+=1)&&(t=0),t}completeHandler(){this._count-=1,
this._count<0&&(this._count=0)}CurFirstShow(t){if(this.UpdatePos(),!this.widget)return
if(this.curPanelIndex==p.r.SystemTipMessage)c.C.Inst_get().SetActiveById(I.k.systemTipView,!0),c.C.Inst_get().SetActiveById(I.k.systemTipView,!1)
else if(this.curPanelIndex==p.r.BuffTip){if(m.F.Inst_get().isInPkUI)return
c.C.Inst_get().SetActiveById(I.k.buffView,!0),c.C.Inst_get().SetActiveById(I.k.buffView,!1)}if(""==t)return
let e=!1,i=null
const s=S.w.GetMsgItemType(t)
if(null!=s){let t=g.D.getInstance().GetIntArray("PICKUP:CONDENSE_ITEM")
t.Contains(s)?i=s:(t=g.D.getInstance().GetStringArray("PICKUP:CONDENSE_CURRENCY"),t.Contains(s)&&(i=s))}if(null!=i)for(let s=0;s<=this.text.Count()-1;s++){const n=this.text[s]
if(n.id==i){e=!0,n.SetData(t,this.curPanelIndex,this._degf_completeHandler)
break}}if(!e){this.text[this._curIndex].SetData(t,this.curPanelIndex,this._degf_completeHandler),this._count+=1,this._count>3&&(this._count=3),this.resetPosY(this._curIndex),
this._curIndex=this.addIndex(this._curIndex),this._count>=3&&(this._count=3,this.ResetAnim(),this.timer=_.C.Inst_get().SetInterval(this._degf_MoveAnimHandler,36),
this.MoveAnimHandler())}}MoveAnimHandler(){const t=this.widget.position.y+this.moveHeight
t>=this.targetPosY&&(_.C.Inst_get().ClearInterval(this.timer),this.timer=-1),this.widget.position=new n.Vec3(25,t,0)}Clear(){this.ResetAnim()}SetIndex(t){this.curPanelIndex=t}
Reset(){if(this.ResetAnim(),null!=this.showItem){let t=0
for(;t<this.showItem.Count();)this.showItem[t].Reset(),t+=1}}ResetAnim(){-1!=this.timer&&(_.C.Inst_get().ClearInterval(this.timer),this.timer=-1)}UpdatePos(){
this.curPanelIndex==p.r.SystemTipMessage?this.strPosY=90:this.curPanelIndex==p.r.BuffTip&&(this.strPosY=-200),this.widget&&(this.widget.position=new n.Vec3(25,this.strPosY,0),
this.targetPosY=this.strPosY+4*this.moveHeight)}Destroy(){}})||s},58056:(t,e,i)=>{var s,n=i(21370),l=i(6847),a=i(83908),r=i(49655),o=i(46282),h=i(69148);(0,
l.s_)(r.o.SystemCommonMessage2,o.Z.ui_systemtips_bufftippanel).layerSet(n.T.msg).register()(s=class extends((0,a.pA)(h.t)()){OnAddToScene(){super.OnAddToScene()}InitView(){
super.InitView()}})},71191:(t,e,i)=>{i.d(e,{n:()=>g})
var s,n=i(6847),l=i(83908),a=i(46282),r=i(31222),o=i(5494),h=i(60130),d=i(98885),_=i(85602),u=i(75439),I=i(65550),c=i(30635)
let g=(0,n.s_)(o.I.ReportPlayerPanel,a.Z.ui_targetplayer_reportotherpanel).layerTip().register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),
this.reasonToggleList=null,this.reasontype=0,this.playerinfo=null}InitView(){c.Y._inst.CloseOperationPanel(),this.reasonToggleList=new _.Z,this.reasonToggleList.Add(this.tog1),
this.reasonToggleList.Add(this.tog2),this.reasonToggleList.Add(this.tog3),this.reasonToggleList.Add(this.tog4),this.input.placeholder="如举报原因为“其它原因”，请详细描述其违规行为"
const t=u.D.getInstance().GetIntValue("REPORT:MAXWORD_NUM")
this.input.maxLength=t}OnAddToScene(){this.AddLis(),this.reasontype=0,this.playerinfo=c.Y.Inst().reportPlayerinfo,
null!=this.playerinfo?this.namelab.textSet(this.playerinfo.m_name):r.N.inst.CloseById(o.I.ReportPlayerPanel)}AddLis(){for(let t=0;t<=3;t++)this.reasonToggleList[t].SetValue(!1),
this.m_handlerMgr.AddClickEvent(this.reasonToggleList[t],this.CreateDelegate(this.OnToggleClick))
this.m_handlerMgr.AddClickEvent(this.confirmbtn,this.CreateDelegate(this.OnConfirmbtnClick)),
this.m_handlerMgr.AddClickEvent(this.closebtn,this.CreateDelegate(this.OnClosebtnClick)),this.m_handlerMgr.AddClickEvent(this.cancelbtn,this.CreateDelegate(this.CloseHandler))}
RemoveLis(){this.m_handlerMgr.RemoveClickEvent(this.confirmbtn,this.CreateDelegate(this.OnConfirmbtnClick)),
this.m_handlerMgr.RemoveClickEvent(this.closebtn,this.CreateDelegate(this.OnClosebtnClick)),
this.m_handlerMgr.RemoveClickEvent(this.cancelbtn,this.CreateDelegate(this.CloseHandler))}OnClosebtnClick(){
h.O.PlayNormalCloseTween(this.closebtn.node,this.CreateDelegate(this.CloseHandler))}OnConfirmbtnClick(){for(let t=0;t<=3;t++)if(this.reasonToggleList[t].GetValue()){
this.reasontype=t+1
break}if(null!=this.playerinfo)if(0!=this.reasontype){const t=this.input.string
if(4==this.reasontype&&d.M.IsNullOrEmpty(t))return void I.y.inst.ClientSysStrMsg("请详细描述玩家的其他违规行为")
c.Y.Inst().CM_ReportPlayer(this.playerinfo.mainroleId_get(),this.reasontype,t),this.CloseHandler()}else I.y.inst.ClientSysStrMsg("请选择举报原因")
else I.y.inst.ClientSysStrMsg("举报对象不存在")}OnToggleClick(t){for(let t=0;t<=3;t++)this.reasonToggleList[t].SetValue(!1)
this[t.currentTarget.name].SetValue(!this[t.currentTarget.name].GetValue())}Clear(){this.RemoveLis(),c.Y.Inst().ReportPlayer_Set(null),super.Clear()}CloseHandler(){
r.N.inst.CloseById(o.I.ReportPlayerPanel)}Test1(){return!0}S_Test(){return!0}})||s},61452:(t,e,i)=>{i.d(e,{g:()=>F})
var s,n,l=i(18998),a=i(72574),r=i(83908),o=i(38836),h=(i(43662),i(28236)),d=i(64213),_=(i(28475),i(32697)),u=i(20583),I=(i(45404),i(31546),i(70650),
i(51868)),c=i(60130),g=i(95721),p=i(98885),m=i(85602),S=i(38962),T=i(63076),f=i(45538),C=i(18152),E=(i(33314),i(87923)),A=(i(27122),
i(38908)),L=i(13476),y=i(42534),D=i(38486),O=i(89799),R=i(29843),N=i(14792),M=i(62734),w=i(65793),P=i(8434),v=i(66476),k=i(5727),U=i(7019),G=i(33542)
let F=l._decorator.ccclass("RyTargetFashionView")((n=class t extends((0,r.pA)(I.$)()){constructor(...t){super(...t),this.model=null,this.roleInfo=null,this.pInfo=null,
this.m_player=null,this.dressMap=null,this.isReadyPlayEffect=!1,this.suitNameFormat=null,this.dataList=null,this.equipmentVOs=null,this.guardDisplay=null,this.roleRotateIndex=null,
this.displayUIAvatarModel=null}_initBinder(){super._initBinder(),this.model=k.X.Inst_get(),this.dressMap=new S.X}InitView(){
this.grid.SetInitInfo("ui_surface_fashionitem_ry",null,U._,null,C.s.BASE_ICON_NO_EQUIPEX),this.grid.OnReposition_set(this.CreateDelegate(this.PlayUnlockEffect)),
this.suitNameFormat=this.suitNameLabel.text(),c.O.SetAnchorPos(this.rightAnchor,!1,!0,0,!1)}SetOneData(t,e,i){let s=null
for(let n=0;n<=this.dataList.count-1;n++)this.dataList[n].pos==t&&(null==e?this.dataList[n].vo=null:(s=this.dataList[n].vo,null==s&&(s=new R.H,this.dataList[n].vo=s),s.clomn=i,
s.itemModelId=e.modelId,s.excellenceAttributeModels=e.exellectAttrs,s.enhanceLevel=0,s.isShowVO=!0,s.isEffective=e.isEffective,s.nowModelId=0,s.equipments=e))
this.equipmentVOs.LuaDic_AddOrSetItem(t,s),this.grid.data_set(this.dataList)}UpdateAllItemData(){this.grid.data_set(this.dataList)}UpdateFashionInfo(){
const t=this.model.selectFashionData
this.fashionName.textSet(t.res.name)
const e=t.attrs.attrs
let i="",s=0
for(;s<e.Count();)t.isLock?i+=`[666666]${E.l.GetAttName(e[s].intType)}+${E.l.getAttrValueStr(e[s].intType,e[s].value)}[-]\n`:i+=`${E.l.GetAttName(e[s].intType)}[047104]+${E.l.getAttrValueStr(e[s].intType,e[s].value)}[-]\n`,
s+=1
this.attrLabel.textSet(i)
const n=v.L.Inst().getSuitAttrItemBySuitId(t.res.suitId),l=G.X.Inst().GetActiveNum(this.pInfo.m_id,t.res.suitId)>=n.suitNum
this.suitNameLabel.textSet(p.M.Replace(this.suitNameFormat,"{0}",t.suitRes.suitNum))
const a=t.suitAttrs.attrs
let r=""
for(s=0;s<a.Count();)r+=l?`${E.l.GetAttName(a[s].intType)}[047104]+${E.l.getAttrValueStr(a[s].intType,a[s].value)}[-]\n`:`[666666]${E.l.GetAttName(a[s].intType)}+${E.l.getAttrValueStr(a[s].intType,a[s].value)}[-]\n`,
s+=1
this.suitAttrLabel.textSet(r)
const o=new T.M(t.consumes)
o.showNum=!1,o.needNum=1,o.isCanOperate=!1,this.ui_baseitem.SetData(o),t.isLock?this.equipBtn.SetText("激活"):t.isWear?this.equipBtn.SetText("脱下"):this.equipBtn.SetText("穿戴")
const h=M.f.Inst.GetData(N.t.CHARACTER_FASHION_CABINET)
null!=h&&this.redPoint.SetActive(h.show),this.tween.ResetToBeginning(),this.tween.PlayForward()}SetData(t){if(k.X.Inst_get().isTargetFashion=!0,null!=t){
this.equipBtn.node.SetActive(!1),this.cabinetBtn.node.SetActive(!1),this.model.selectFashionData=null,this.pInfo=t,this.dressMap.LuaDic_Clear()
for(const[t,e]of(0,o.V5)(this.pInfo.Fashions_get()))this.dressMap[t]=e
this.SetDefaultFashion(),this.UpdateView(),this.AddEvent()}}AddEvent(){this.model.AddEventHandler(k.X.SELECT_EQUIP,this.CreateDelegate(this.SelectOne)),
this.m_handlerMgr.AddClickEvent(this.attrBtn,this.CreateDelegate(this.OnAttrClick))}RemoveEvent(){
this.model.RemoveEventHandler(k.X.SELECT_EQUIP,this.CreateDelegate(this.SelectOne))}OnAttrClick(){w.W.Inst_get().OpenFashionAttrView(!0)}SetDefaultFashion(){
this.dataList=G.X.Inst().GetFashionShowData(this.pInfo.m_id)
let t=null
if(null==this.model.selectFashionData){let e=0
for(;e<this.dataList.Count();){if(this.dataList[e].isWear)if(null==t)t=this.dataList[e].res.position,this.model.selectFashionData=this.dataList[e]
else if(t==P.$.Weapon&&this.dataList[e].res.position==P.$.Body){this.model.selectFashionData=this.dataList[e]
break}e+=1}}if(null==this.model.selectFashionData){let t=0
for(;t<this.dataList.Count();){if(!this.dataList[t].isLock){this.model.selectFashionData=this.dataList[t]
break}t+=1}}null==this.model.selectFashionData&&(this.model.selectFashionData=this.dataList[0])}SelectOne(){this.UpdateFashionInfo(),this.ShowModel()}UpdateView(){this.ShowModel(),
this.UpdateAllItemData(),this.UpdateFashionInfo()}PlayUnlockEffect(){this.scrllView.ResetPosition()}GetRoleInfo(){this.roleInfo=new h.H,this.roleInfo.Id_set(g.o.ZERO),
this.roleInfo.Job_set(this.pInfo.Job_get()),this.roleInfo.Sex_set(this.pInfo.Sex_get()),this.roleInfo.Name_set(""),this.roleInfo.ServerName_set(""),this.roleInfo.Server_set("")
const t=new D.v
t.talentIds=new m.Z,t.addMasterLevel=0,t.unlockColumn=!0;(new S.X)[0]=t
const e=new O.U
if(this.roleInfo.equipmentStorageVO=e,this.equipmentVOs=this.model.GetInfoFacadeEquipmentSetting(this.pInfo),this.roleInfo.equipmentStorageVO.equipmentVOs=this.equipmentVOs,
this.model.selectFashionData.isPreview)this.dressMap[this.model.selectFashionData.res.position]=this.model.selectFashionData.res.id
else{const t=this.pInfo.Fashions_get()
t.LuaDic_GetItem(this.model.selectFashionData.res.position)&&(this.dressMap[this.model.selectFashionData.res.position]=t[this.model.selectFashionData.res.position])}
this.roleInfo.Fashions_set(this.dressMap)}EquipmentVOs_set(t){this.roleInfo.equipmentStorageVO.equipmentVOs=t}ShowModel(){this.GetRoleInfo(),
this.displayUIAvatarModel=u.x.inst.SetUIAvatarData(this.roleInfo,_.v.role,this.displayUIAvatarModel,null,!0),this.displayUIAvatarModel.SetTarget(this.roleTexture.node,!0),
this.displayUIAvatarModel.SetDir(4),this.displayUIAvatarModel.SetScale(1,1),this.displayUIAvatarModel.SetAct(a.Bv.FightIdle)}ResetGuardDisplay(){
const e=this.equipmentVOs.LuaDic_GetItem(f._.POS_GUARD)
if(null==e)return void(null!=this.guardDisplay&&(this.guardDisplay.Destroy(),this.guardDisplay=null))
const i=e.equipments
if(null==i)return void(null!=this.guardDisplay&&(this.guardDisplay.Destroy(),this.guardDisplay=null))
const s=i.modelId
if(null!=this.guardDisplay){if(this.guardDisplay.DisplayID_get()==s)return
this.guardDisplay.Destroy(),this.guardDisplay=null}let n=y.f.Inst().getItemById(s).guardModel
n=L.E.Instance.TryReplaceDisplayID(A.C.ReplaceTypeGUARD,n),this.guardDisplay=new d.r,this.guardDisplay.SetDisplayID(n,t.STAGE_ID,1)}Clear(){k.X.Inst_get().isTargetFashion=!1,
this.model.selectFashionData=null,this.RemoveEvent(),super.Clear()}Test1(){return!0}S_Test(){return!0}},n.STAGE_ID=77,s=n))||s},59835:(t,e,i)=>{i.d(e,{j:()=>P})
var s=i(18998),n=i(72574),l=i(38836),a=i(32697),r=i(20583),o=i(50838),h=i(62370),d=i(51868),_=i(98130),u=i(98885),I=i(85602),c=i(75363),g=i(55793),p=i(87081),m=i(73583),S=i(92679),T=i(77477),f=i(87923),C=i(33833),E=i(41864),A=i(24617),L=i(83908),y=i(9057),D=i(63076),O=i(75321)
class R extends((0,L.pA)(y.x)()){constructor(...t){super(...t),this.data=null,this.repath="atlas/qianghua/"}SetData(t){this.SetItemClickGo(this)
const e=t.equipmentEx
this.data=t
let i=0
if(null!=e){const s=new D.M(e.modelId,e)
s.showEquipScoreUp=!1,s.isShowAttrCompare=!1,s.isCanOperate=!1,s.SetTargetRoleInfo(t.targetRoleInfo),this.ui_baseitem_ry.SetData(s),this.ui_baseitem_ry.SetBgSize(78,78),
this.ui_baseitem_ry.SetIconSize(78,78),this.bg.node.SetActive(!1),this.ui_baseitem_ry.node.SetActive(!0),i=e.Enhancelevel_get(t.targetRoleInfo)}else this.SetSelect(!1),
this.bg.node.SetActive(!0),this.bg.spriteNameSet(this.repath+this.GetBgSpriteNameByPos(t.pos)),this.ui_baseitem_ry.node.SetActive(!1)
this.lock.SetActive(this.data.isLock),i>0?(this.levelLabel.textSet(`+${i}`),this.levelSp.spriteNameSet(this.repath+"ryqainghua_sp_0013"),this.levelSp.node.SetActive(!0),
this.levelLabel.node.SetActive(!0)):(this.levelLabel.node.SetActive(!1),this.levelSp.node.SetActive(!1))}GetBgSpriteNameByPos(t){
return t==O.C.PART_WEAPON_LEFT?"ryqainghua_sp_0009":t==O.C.PART_WEAPON_RIGHT?"ryqainghua_sp_0026":t==O.C.PART_HAT?"ryqainghua_sp_0001":t==O.C.PART_CLOTHES?"ryqainghua_sp_0002":t==O.C.PART_GLOVES?"ryqainghua_sp_0004":t==O.C.PART_PANTS?"ryqainghua_sp_0003":t==O.C.PART_BOOTS?"ryqainghua_sp_0006":t==O.C.PART_NECKLACE?"ryqainghua_sp_0005":t==O.C.PART_RINGS_LEFT||t==O.C.PART_RINGS_RIGHT?"ryqainghua_sp_0008":t==O.C.PART_WINGS?"ryqainghua_sp_0010":t==O.C.PART_GUARD?"ryqainghua_sp_0007":void 0
}SetSelect(t){}Clear(){super.Clear()}Destroy(){super.Destroy()}}var N,M,w=i(33542)
let P=s._decorator.ccclass("RyTargetPlayerEquipView")(((M=class extends d.${constructor(...t){super(...t),this.rInfo=null,this.m_player=null,this.STAGE_ID=null,this.column=null,
this.cnode=null,this.displayUIAvatarModel=void 0}InitView(){super.InitView(),this.cnode=this.node.getCNode(),this.displayUIAvatarModel=new o.o,
this.displayUIAvatarModel.SetTarget(this.cnode.roleUIAvatar,!0),this.displayUIAvatarModel.SetDir(4),this.displayUIAvatarModel.SetScale(1,1),
this.displayUIAvatarModel.SetAct(n.Bv.FightIdle),this.cnode.detailGrid.SetInitInfo("ui_characterui_detailinfoitem_new",null,p.x),
this.cnode.equipgrid.SetInitInfo("ui_targetplayer_ryequipitem",null,R)}AddLis(){this.m_handlerMgr.AddEventMgr(S.g.UPDATE_ANCHORS,this.CreateDelegate(this._OnUpdateAnchor))}
ShowModel(){r.x.inst.SetUIAvatarData(this.rInfo,a.v.role,this.displayUIAvatarModel)}InitDetailData(){
const t=this.rInfo,e=t.Attributes_get(),i=new I.Z,s=C.X.Inst().getCanShowItemListByType(g.y.AttrIntruction_Special)
if(null!=s&&0!=s.Count()){let n=null,a=null
for(const[r,o]of(0,l.V5)(s))if(t.JudgeShowEnable(o.id)){if(a=null,n=new m.E,n.AttrName_set(o.name),1==o.valueType)if(o.id==T.Z.Treatment){e[o.id]
let t=e[T.Z.PhyAttack_Max],i=e[T.Z.PhyAttack_Min]
null==t&&(t=0),null==i&&(i=0),n.AttrVal_set(f.l.GetRuleDecimalVal((t+i)/2))}else o.id==T.Z.MoveSpeed||null!=e[o.id]?n.AttrVal_set(`${e[o.id]}`):n.AttrVal_set("0")
else 2==o.valueType?n.AttrVal_set(f.l.GetPrecentDecimalVal(e[o.id],100,2)+h.o.s_UNDER_PERCENT):n.AttrVal_set(e[o.id]+h.o.s_UNDER_PERCENT)
i.Add(n),null!=a&&i.Add(a)}}this.cnode.detailGrid.data_set(i),this.cnode.content.height=350+i.count*this.cnode.detailGrid.cellHeight}SetData(t){null!=t&&(this.AddLis(),
this._OnUpdateAnchor(),this.rInfo=t,this.column=w.X.Inst().column,this.UpdateEquipList(),this.InitDetailData(),this.ShowModel(),this.SetInfo(t),this.RoleAttributeUpdate(t))}
_OnUpdateAnchor(){}UpdateEquipList(){const t=new I.Z(c.Y.Inst_get().GetEquipcolumnresourceById(this.column).location),e=t.Count(),i=new I.Z
for(let s=0;s<=e-1;s++){const e=new A.X
e.showType=-1,e.column=this.column,e.pos=t[s],e.targetRoleInfo=this.rInfo
e.pos
e.showRed=!1
const n=this.rInfo.GetUnlockByColumnAndPos(e.column,e.pos)
e.isLock=!n
const l=this.rInfo.GetWearEquipByColumnAndPos(e.column,e.pos)
e.equipmentEx=n&&null!=l?l:null,i.Add(e)}i.Sort(this.CreateDelegate(this.SortEquipList)),this.cnode.equipgrid.data_set(i)}SortEquipList(t,e){
return null!=t.equipmentEx&&null==e.equipmentEx?-1:null!=e.equipmentEx&&null==t.equipmentEx?1:t.pos<e.pos?-1:t.pos<e.pos?1:0}SetInfo(t){this.cnode.playerName.textSet(t.m_name),
this.cnode.levelValue.textSet(E.h.GetLevelStr(t.m_level)),this.cnode.professionname.textSet(f.l.getJobStr(t.Job_get())),
""==t.asuramName?this.cnode.asuramnamelabel.textSet("尚未加入战盟"):this.cnode.asuramnamelabel.textSet(t.asuramName),this.cnode.fightnumber.textSet(t.m_battleScore+""),
this.cnode.severname.textSet(t.serverName)}RoleAttributeUpdate(t){let e=0,i=""
e=t.Attributes_get()[_.GF.INT(T.Z.MaxHp)],i=u.M.DoubleToString(e),this.cnode.hpvalue.textSet(i)
let s=t.Attributes_get()[_.GF.INT(T.Z.PhyAttack_Min)],n=t.Attributes_get()[_.GF.INT(T.Z.PhyAttack_Max)]
null==n&&(n=0),null==s&&(s=0),i=0==s&&0==n?"0":`${f.l.GetAttackRuleDecimalVal(s)}-${f.l.GetAttackRuleDecimalVal(n)}`,this.cnode.physicalatkvalue.textSet(i),
e=t.Attributes_get()[_.GF.INT(T.Z.Defense)],i=u.M.DoubleToString(e),this.cnode.defencevalue.textSet(i),e=t.Attributes_get()[_.GF.INT(T.Z.HitRate)],i=u.M.DoubleToString(e),
this.cnode.atksuccessvalue.textSet(i),e=t.Attributes_get()[_.GF.INT(T.Z.DodgeRate)],i=u.M.DoubleToString(e),this.cnode.defencesuccessvalue.textSet(i),
e=t.Attributes_get()[_.GF.INT(T.Z.AttackSpeed)],null==e&&(e=0),i=u.M.DoubleToString(e),this.cnode.attackspeedvalue.textSet(i),e=t.Attributes_get()[_.GF.INT(T.Z.MoveSpeed)],
i=u.M.DoubleToString(e),this.cnode.movespeedvalue.textSet(i)}RemoveLis(){}Clear(){this.RemoveLis()}Test1(){return!0}S_Test(){return!0}}).STAGE_ID=27,N=M))||N},65963:(t,e,i)=>{
i.d(e,{w:()=>E})
var s,n=i(6847),l=i(83908),a=i(46282),r=i(86133),o=i(28475),h=i(36334),d=i(44255),_=i(31222),u=i(5494),I=i(85602),c=i(59975),g=i(27122),p=i(8566),m=i(27742),S=i(61452),T=i(59835),f=i(33542),C=i(30635)
let E=(0,n.s_)(u.I.RyTargetPlayerMainPanel,a.Z.ui_targetplayer_rymainpanel).tabsPrefab([a.Z.ui_characterui_detailinfoitem_new,a.Z.ui_targetplayer_ryequipitem,a.Z.ui_targetplayer_ryequipview,a.Z.ui_baseitem,a.Z.ui_baseitem_swapeffect_module,a.Z.ui_baseitem_equip_module,a.Z.ui_baseitem_base_module,a.Z.ui_baseitem_element_module,a.Z.ui_baseitem_elecarve_module,a.Z.ui_baseitem_glod_diamond_module,a.Z.ui_surface_fashionview_ry]).register()(s=class extends((0,
l.pA)(d.I)()){constructor(...t){super(...t),this.model=null,this.sideColumns=null,this.curRoleInfo=null,this.viewType=null}InitView(){C.Y._inst.CloseOperationPanel(),
this.InitSubDatas(),this.model=f.X.Inst(),this.sideColumns=new I.Z}OnAddToScene(){super.OnAddToScene(),this._SetCharacterTabData(!0,u.I.RyTargetPlayerMainPanel,null,!1),
this.CharacterChanged(this.model.targetRoles[this.model.selectedCreateIndex]),this.SelectCharacter(this.model.selectedCreateIndex,!1,!1),this.model.selectedCreateIndex=0}Refresh(){
this.ui_charactertab.SetCurSelectIdx(0,!1,!1),this.CharacterChanged(this.model.targetRoles[0])}AddLis(){super.AddLis()}SetViewConfig(){const t=this.model.targetRoles
this.ui_charactertab.SetOtherRoles(t),this.ui_charactertab.onChanged=this.CreateDelegate(this.CharacterChanged)
const e=new I.Z([(0,r.T)("属 性")])
this._SetTabData0(!0,e,null,null,null,null),this.SelectTab0(this.GetFirstOpenTab(),!1)}GetFirstOpenTab(){return 0}CharacterChanged(t){this.curRoleInfo=t,this.model.info=t
const e=g.Q.Inst().GetObjectByName("Role",o.u)
null!=this.model.targetRole&&e.leaderRole_set(this.model.targetRole.leaderRole_get()),e.Roleinfo_set(this.model.info),f.X.Inst().TempRole_set(e),
this._OnSelectCharacterBeforeUpdate()}_OnSelectCharacterBeforeUpdate(){0==this.selectTabIdx0&&this.SelectTab1(this.selectTabIdx1)}InitSubDatas(){
this._subPanelDatas.Add(h.b.New(new I.Z([a.Z.ui_targetplayer_ryequipview]),this,T.j)),this._subPanelDatas.Add(h.b.New(new I.Z([a.Z.ui_surface_fashionview_ry]),this,S.g)),
p.V.Inst().subPanelDatas=new I.Z
for(let t=0;t<this._subPanelDatas.length;t++)p.V.Inst().subPanelDatas.Add(this._subPanelDatas[t])}_OnSelectTab0BeforeUpdate(t,e){if(this.HideAllSubView(),0==this.selectTabIdx0){
const t=this.curRoleInfo||this.model.targetRoles[this.model.selectedCreateIndex]
this.sideColumns=new I.Z
const e=t.GetEquipColList(0)
f.X.Inst().column=1,this.sideColumns.AddRange(e)
const i=new c.G
i.btnName="时 装",i.viewType=1,this.sideColumns.Add(i),this.rightTabGrid.node.SetActive(!0),
null==this.rightTabGrid.m_onReposition&&(this.rightTabGrid.SetInitInfo("ui_ry_right_tab",null,m.U,this.CreateDelegate(this._OnClickRightItem)),
this.rightTabGrid.OnReposition_set(this.CreateDelegate(this.OnRepositionRight))),this.rightTabGrid.data_set(this.sideColumns),this.rightBg3.node.SetActive(!0),
this._subPanelDatas[0].setDataParam=this.curRoleInfo,this.SelectTab1(0)}}_OnSelectTab1BeforeUpdate(){if(0==this.selectTabIdx0){const t=this.sideColumns[this.selectTabIdx1]
this.viewType=t.viewType,0==t.viewType&&(f.X.Inst().column=t.columnId),this._subPanelDatas[t.viewType].setDataParam=this.curRoleInfo,this.ShowSubView(t.viewType)}}OnCloseClick(){
_.N.inst.CloseById(u.I.RyTargetPlayerMainPanel)}Test1(){return!0}S_Test(){return!0}})||s},34342:(t,e,i)=>{
var s,n=i(18998),l=i(6847),a=i(83908),r=i(46282),o=i(86133),h=i(98800),d=i(97960),_=i(97461),u=i(38935),I=i(61911),c=i(5494),g=i(98130),p=i(98885),m=i(52212),S=i(79534),T=i(51628),f=i(80486),C=i(84229),E=i(92984),A=i(42975),L=i(4880),y=i(50894),D=i(26753),O=i(92679),R=i(33314),N=i(29832),M=i(84459),w=i(48933),P=i(21987),v=i(50077),k=i(10965),U=i(55617),G=i(76944),F=i(41864),B=i(65550),H=i(85942),V=i(44744),b=i(33542),x=i(30635)
;(0,l.s_)(c.I.eTargetPlayerHead,r.Z.ui_targetplayer_head).waitPrefab(r.Z.ui_buff_grid).register()(s=class extends((0,a.pA)(I.f)()){constructor(...t){super(...t),
this._roleinfo=null,this.btnList=null,this.startY=36,this.myInfo=null,this.role=null,this.targetInfo=null,this.model=null,this._msID=0,this._listener=null,this.hpBar=null,
this.shieldBar=null,this.lastHp=0,this.lastMaxHp=0,this.lastShield=0,this.lastMaxShield=0,this.m_vo=null,this.hpData=null,this.shieldData=null,this._degf_ClickBuffItem=null,
this._degf_HideMenu=null,this._degf_HpChangeHandle=null,this._degf_ShieldChangeHandle=null,this._degf_LevelUpHandle=null,this._degf_OnAddBlackListClick=null,
this._degf_OnAddFriendClick=null,this._degf_OnApplyIntoAllyClick=null,this._degf_OnApplyTeamClick=null,this._degf_OnBuffItemClick=null,this._degf_OnCallTeamateBtnClick=null,
this._degf_OnCancelCallBtnClick=null,this._degf_OnCancelFollowBtnClick=null,this._degf_OnChangeJobClick=null,this._degf_OnChangeLeaderBtnClick=null,this._degf_OnChatClick=null,
this._degf_OnCheckClick=null,this._degf_OnConfirmClick=null,this._degf_OnExpelClick=null,this._degf_OnExpelTeamateBtnClick=null,this._degf_OnFollowBtnClick=null,
this._degf_OnInviteAllyClick=null,this._degf_OnInviteTeamClick=null,this._degf_OnItemRefreshFun=null,this._degf_OnLeaveTeamBtnClick=null,this._degf_OnRemoveBlackListClick=null,
this._degf_OnRemoveFriendClick=null,this._degf_OnReportBtn=null,this._degf_OnSelectTargetUpdate=null,this._degf_OpenOperationPanel=null,this._degf_UpdateBuffList=null,
this._degf_applyTeamOkHandler=null,this.shildData=null}_initBinder(){super._initBinder(),this._degf_ClickBuffItem=t=>this.ClickBuffItem(t),
this._degf_HideMenu=(t,e)=>this.HideMenu(t,e),this._degf_HpChangeHandle=t=>this.HpChangeHandle(t),this._degf_ShieldChangeHandle=t=>this.ShieldChangeHandle(t),
this._degf_LevelUpHandle=t=>this.LevelUpHandle(t),this._degf_OnAddBlackListClick=(t,e)=>this.OnAddBlackListClick(t,e),this._degf_OnAddFriendClick=(t,e)=>this.OnAddFriendClick(t,e),
this._degf_OnApplyIntoAllyClick=(t,e)=>this.OnApplyIntoAllyClick(t,e),this._degf_OnApplyTeamClick=(t,e)=>this.OnApplyTeamClick(t,e),
this._degf_OnBuffItemClick=(t,e)=>this.OnBuffItemClick(t,e),this._degf_OnCallTeamateBtnClick=(t,e)=>this.OnCallTeamateBtnClick(t,e),
this._degf_OnCancelCallBtnClick=(t,e)=>this.OnCancelCallBtnClick(t,e),this._degf_OnCancelFollowBtnClick=(t,e)=>this.OnCancelFollowBtnClick(t,e),
this._degf_OnChangeJobClick=(t,e)=>this.OnChangeJobClick(t,e),this._degf_OnChangeLeaderBtnClick=(t,e)=>this.OnChangeLeaderBtnClick(t,e),
this._degf_OnChatClick=(t,e)=>this.OnChatClick(t,e),this._degf_OnCheckClick=(t,e)=>this.OnCheckClick(t,e),this._degf_OnConfirmClick=t=>this.OnConfirmClick(t),
this._degf_OnExpelClick=(t,e)=>this.OnExpelClick(t,e),this._degf_OnExpelTeamateBtnClick=(t,e)=>this.OnExpelTeamateBtnClick(t,e),
this._degf_OnFollowBtnClick=(t,e)=>this.OnFollowBtnClick(t,e),this._degf_OnInviteAllyClick=(t,e)=>this.OnInviteAllyClick(t,e),
this._degf_OnInviteTeamClick=(t,e)=>this.OnInviteTeamClick(t,e),this._degf_OnLeaveTeamBtnClick=(t,e)=>this.OnLeaveTeamBtnClick(t,e),
this._degf_OnRemoveBlackListClick=(t,e)=>this.OnRemoveBlackListClick(t,e),this._degf_OnRemoveFriendClick=(t,e)=>this.OnRemoveFriendClick(t,e),
this._degf_OnReportBtn=(t,e)=>this.OnReportBtn(t,e),this._degf_OnSelectTargetUpdate=t=>this.OnSelectTargetUpdate(t),
this._degf_OpenOperationPanel=(t,e)=>this.OpenOperationPanel(t,e),this._degf_UpdateBuffList=t=>this.UpdateBuffList(t),this._degf_applyTeamOkHandler=t=>this.applyTeamOkHandler(t)}
InitView(){super.InitView(),this.head.node.SetActive(!0),this.buffDetailCell.node.SetActive(!1),this.myInfo=h.Y.Inst.PrimaryRoleInfo_get(),this.model=b.X.Inst(),
this.buffDetailCell.isBgShow=!0,this.hpBar=new N.o,this.shieldBar=new N.o,this.buff.SetInitInfo("ui_buff_grid",null,L.I)}OnAddToScene(){if(this.role=this.model.TargetRole_get(),
null!=this.role){if(this.targetInfo=this.role.Roleinfo_get(),null==this.targetInfo){const t=h.Y.Inst.getCharacterById(this.role.objId)
null!=t&&(this.targetInfo=t.Roleinfo_get())}null!=this.targetInfo&&this.SetData(this.targetInfo),this.menu.SetActive(!1),null==this.targetInfo&&x.Y.Inst().CloseTargetHead(),
this.ResPos()}else x.Y.Inst().CloseTargetHead()}SetData(t){this.Clear()
const e=t
this._roleinfo=e,this.head.spriteNameSet(R.Z.GetJobIcon(e.Job_get(),e.Sex_get(),!0)),this.nameTxt.textSet(e.Name_get()),this.levelTxt.textSet(F.h.GetLevelStr(e.Level_get())),
this.UpdateShileView(e),this.UpdateHp(e),this.UpdateShield(e),this.AddListeners()}UpdateShileView(t){
null!=this.shieldPanel&&(t.ShileShowEnable_get()?(this.shieldPanel.SetActive(!0),this.otherPanel.SetLocalPosition(new S.P(0,-11,0)),
this.UpdateShield(this._roleinfo)):(this.shieldPanel.SetActive(!1),this.otherPanel.SetLocalPosition(new S.P(0,0,0))))}ResPos(){
null!=this.offset&&this.offset.transform.SetLocalPositionXYZ(0,-485,0)}SetMenu(){if(this.role=this.model.TargetRole_get(),this.targetInfo=this.role.Roleinfo_get(),
this.menu.SetActive(!0),this.myInfo.Id_get().Equal(this.targetInfo.Id_get()))return void this.grid.node.SetActive(!1)
this.grid.node.SetActive(!0)
let t=0
if(this.checkBtn.node.SetActive(!0),this.chatBtn.node.SetActive(!0),this.reportBtn.node.SetActive(!0),t+=3,this.inviteTeamBtn.node.SetActive(!1),
this.applyTeamBtn.node.SetActive(!1),this.inviteAllianceBtn.node.SetActive(!1),this.applyAllianceBtn.node.SetActive(!1),this.addFriendBtn.node.SetActive(!1),
this.deleteFriendBtn.node.SetActive(!1),this.addBlackListBtn.node.SetActive(!1),this.removeBlackListBtn.node.SetActive(!1),this.changeAllianceJobBtn.node.SetActive(!1),
this.expelBtn.node.SetActive(!1),this.followLeaderBtn.node.SetActive(!1),this.cancelFollowBtn.node.SetActive(!1),this.changeLeaderBtn.node.SetActive(!1),
this.expelTeamateBtn.node.SetActive(!1),this.leaveTeamBtn.node.SetActive(!1),this.callTeamateBtn.node.SetActive(!1),this.cancelCallBtn.node.SetActive(!1),
null==this.targetInfo.AsuramId_get()||this.targetInfo.AsuramId_get().Equal(w.I.zeroLong)?null==this.myInfo.AsuramId_get()||this.myInfo.AsuramId_get().Equal(w.I.zeroLong)||(this.inviteAllianceBtn.node.SetActive(!0),
t+=1):(null==this.myInfo.AsuramId_get()||this.myInfo.AsuramId_get().Equal(w.I.zeroLong))&&(this.applyAllianceBtn.node.SetActive(!0),t+=1),this.model.isFromAsuram){
const e=C.Q.Inst_get().checkMemberInfo
this.myInfo.AllianceJob_get()<4&&this.myInfo.AllianceJob_get()<e.job&&(this.changeAllianceJobBtn.node.SetActive(!0),this.expelBtn.node.SetActive(!0),t+=2,
this.model.isFromAsuram=!1)}
this.myInfo.isHaveTeam_get()?this.targetInfo.isHaveTeam_get()?this.targetInfo.teamId_get().Equal(this.myInfo.teamId_get())?(this.leaveTeamBtn.node.SetActive(!0),
t+=1):(this.applyTeamBtn.node.SetActive(!0),t+=1):(this.inviteTeamBtn.node.SetActive(!0),t+=1):this.targetInfo.isHaveTeam_get()?(this.applyTeamBtn.node.SetActive(!0),
t+=1):(this.inviteTeamBtn.node.SetActive(!0),t+=1),v.C.Inst_get().IsFriend(this.targetInfo.Id_get())?(this.deleteFriendBtn.node.SetActive(!0),
t+=1):(this.addFriendBtn.node.SetActive(!0),t+=1),v.C.Inst_get().IsBlackFriend(this.targetInfo.Id_get())?(this.removeBlackListBtn.node.SetActive(!0),
t+=1):(this.addBlackListBtn.node.SetActive(!0),t+=1),this.menubg.heightSet(48*t+8),this.buffDetailCell.AddEvent()}AddListeners(){
this._roleinfo.AddEventHandler(d.A.LevelUpdate,this.CreateDelegate(this.LevelUpHandle)),this._roleinfo.AddEventHandler(d.A.HpUpdate,this.CreateDelegate(this.HpChangeHandle)),
this._roleinfo.AddEventHandler(d.A.ShieldUpdate,this.CreateDelegate(this.ShieldChangeHandle)),
this.headeventlister.node.on(n.NodeEventType.TOUCH_END,this._degf_OpenOperationPanel,this),this.AddClickEvent(this.boxcollider,this._degf_HideMenu),
this.AddClickEvent(this.checkBtn,this._degf_OnCheckClick),this.AddClickEvent(this.chatBtn,this._degf_OnChatClick),this.AddClickEvent(this.addFriendBtn,this._degf_OnAddFriendClick),
this.AddClickEvent(this.deleteFriendBtn,this._degf_OnRemoveFriendClick),this.AddClickEvent(this.applyTeamBtn,this._degf_OnApplyTeamClick),
this.AddClickEvent(this.inviteTeamBtn,this._degf_OnInviteTeamClick),this.AddClickEvent(this.addBlackListBtn,this._degf_OnAddBlackListClick),
this.AddClickEvent(this.removeBlackListBtn,this._degf_OnRemoveBlackListClick),this.AddClickEvent(this.inviteAllianceBtn,this._degf_OnInviteAllyClick),
this.AddClickEvent(this.applyAllianceBtn,this._degf_OnApplyIntoAllyClick),this.AddClickEvent(this.reportBtn,this._degf_OnReportBtn),
this.AddClickEvent(this.changeAllianceJobBtn,this._degf_OnChangeJobClick),this.AddClickEvent(this.expelBtn,this._degf_OnExpelClick),
this.AddClickEvent(this.followLeaderBtn,this._degf_OnFollowBtnClick),this.AddClickEvent(this.cancelFollowBtn,this._degf_OnCancelFollowBtnClick),
this.AddClickEvent(this.changeLeaderBtn,this._degf_OnChangeLeaderBtnClick),this.AddClickEvent(this.expelTeamateBtn,this._degf_OnExpelTeamateBtnClick),
this.AddClickEvent(this.leaveTeamBtn,this._degf_OnLeaveTeamBtnClick),this.AddClickEvent(this.callTeamateBtn,this._degf_OnCallTeamateBtnClick),
this.AddClickEvent(this.cancelCallBtn,this._degf_OnCancelCallBtnClick),E.j.Inst_get().model.AddEventHandler(A.E.UPDATE_BUFF_VIEW,this._degf_UpdateBuffList),
_.i.Inst.AddEventHandler(O.g.SELECT_TARGET_CHANGE,self._degf_OnSelectTargetUpdate),_.i.Inst.AddEventHandler(O.g.CLICK_ARENABUFF,self._degf_ClickBuffItem),
this.m_handlerMgr.AddEventMgr(O.g.FuncOpenViewOpenChange,this.CreateDelegate(this.FuncOpenViewOpenChangeHandle),5),this.buffDetailCell.RemoveEvent(),
this.m_handlerMgr.AddEventMgr(O.g.BossHpBarOpenOrClose,this.CreateDelegate(this.ResPos))}FuncOpenViewOpenChangeHandle(t){t?(this.anchor.node.SetAlpha(1e-4),
_.i.Inst.RaiseEvent(O.g.OnBloodBarClose,null,5)):(this.anchor.node.SetAlpha(1),_.i.Inst.RaiseEvent(O.g.OnBloodBarOpen,null,5))}ClickBuffItem(t){this.m_vo=t,
this._roleinfo.Id_get().Equal(this.m_vo.owner)&&(this.buffDetailCell.node.SetActive(!0),this.buffDetailCell.SetData(this.m_vo),
this.AddFullScreenCollider(this.node,this._degf_OnBuffItemClick,null,!1))}OnBuffItemClick(t,e){this.buffDetailCell.node.SetActive(!1),this.m_vo=null}OnSelectTargetUpdate(t){}
UpdateBuffList(t){this._roleinfo&&(null!=this.m_vo&&null==E.j.Inst_get().model.IsHaveBuff(this.m_vo.owner,this.m_vo.buffRes_get().id)&&this.OnBuffItemClick(0,0),
this.buffDetailCell.node.active&&this.buffDetailCell.SetData(this.m_vo))}UpdateHp(t){if(null==this.hpBar)return
let e=null
e=t.InTransform()?t.maxChariotHP:t.MaxHp_get(),this.hpBar.isInit?this.lastHp==t.CurrentHp_get()&&e==this.lastMaxHp||(null==this.hpData?this.hpData=new M.F(e,t.CurrentHp_get(),this.lastHp):this.hpData.SetData(e,t.CurrentHp_get(),this.lastHp),
this.hpBar.UpdateHp(this.hpData)):(this.hpData=new M.F(e,t.CurrentHp_get(),null),this.hpBar.Init(this.topHpSpr,this.decreaseHpSpr,this.increaseHpSpr,this.hpData)),
this.lastHp=t.CurrentHp_get(),this.lastMaxHp=e,this.hpLabel.textSet(`${g.GF.INT(this.lastHp)}/${g.GF.INT(this.lastMaxHp)}`)}UpdateShield(t){
null!=this.shieldBar&&null!=t&&(this.shieldBar.isInit?this.lastShield==t.CurrentShield_get()&&t.MaxShield_get()==this.lastMaxShield||(null==this.shildData?this.shildData=new M.F(t.MaxShield_get(),t.CurrentShield_get(),this.lastShield):this.shildData.SetData(t.MaxShield_get(),t.CurrentShield_get(),this.lastShield),
this.shieldBar.UpdateHp(this.shildData)):(this.shildData=new M.F(t.MaxShield_get(),t.CurrentShield_get(),null),
this.shieldBar.Init(this.topShieldSpr,this.decreaseShieldSpr,this.increaseShieldSpr,this.shildData)),this.lastShield=t.CurrentShield_get(),this.lastMaxShield=t.MaxShield_get())}
LevelUpHandle(t){this.levelTxt.textSet(p.M.IntToString(this.targetInfo.Level_get()))}HpChangeHandle(t){const e=t
this.UpdateHp(e)}ShieldChangeHandle(t){const e=t
this.UpdateShield(e)}OpenOperationPanel(t,e){null==this._roleinfo||this._roleinfo.robotId>0||(b.X.Inst().needOpenPos=!0,b.X.Inst().openPos=new m.F(-145,100).Clone(),
V.Z.Inst().Open(this._roleinfo.Id_get()))}HideMenu(t=null,e=null){null==e&&(e=0),null==t&&(t=0),this.menu.SetActive(!1)}UpdateAsuramIdHandle(t){
this.model.canOperate&&this.SetMenu()}OnCheckClick(t,e){this.model.headlookother=!0,V.Z.Inst().Open(this.role.GetGameId()),this.HideMenu()}OnChatClick(t,e){
D.d.Inst_get().controller.PrivateChatRoleInfo(this.targetInfo,this.model.isOnline),this.HideMenu()}OnAddFriendClick(t,e){P.N.Inst_get().ReqAddFriend(this.targetInfo.Id_get()),
this.HideMenu()}OnRemoveFriendClick(t,e){P.N.Inst_get().ReqRemoveFriend(this.targetInfo.Id_get()),this.HideMenu()}OnFollowBtnClick(t,e){this.HideMenu()}OnCancelFollowBtnClick(t,e){
this.HideMenu()}OnChangeLeaderBtnClick(t,e){this.HideMenu()}OnExpelTeamateBtnClick(t,e){this.HideMenu()}OnLeaveTeamBtnClick(t,e){this.HideMenu()}OnCallTeamateBtnClick(t,e){
this.HideMenu()}OnCancelCallBtnClick(t,e){this.HideMenu()}OnApplyTeamClick(t,e){this.HideMenu()}applyTeamOkHandler(t){this.HideMenu()}OnInviteTeamClick(t,e){this.HideMenu()}
OnAddBlackListClick(t,e){P.N.Inst_get().ReqBlackFriend(this.targetInfo),this.HideMenu()}OnRemoveBlackListClick(t,e){P.N.Inst_get().ReqUnBlack(this.targetInfo.Id_get()),
this.HideMenu()}OnReportBtn(t,e){P.N.Inst_get().ReqReport(this.targetInfo.Id_get()),this.HideMenu()}OnTradeClick(t){this.HideMenu()}OnInviteAllyClick(t,e){
f.K.Inst().InviteIntoAsuramReq(this.targetInfo.Id_get()),this.HideMenu()}OnApplyIntoAllyClick(t,e){const i=new k.$
i.asuramId=this.targetInfo.AsuramId_get(),u.C.Inst.F_SendMsg(i),this.HideMenu()}OnChangeJobClick(t,e){T.D.Inst().Open(),this.HideMenu()}OnExpelClick(t,e){
const i=C.Q.Inst_get().checkMemberInfo,s=new H.N
s.titleText=(0,o.T)("逐出战盟"),s.showText=(0,o.T)("您确定要将[e2a66a]")+(y.k.inst.GetFSName(i.name,i.newTitleLevel)+(0,o.T)("[-]逐出战盟吗？")),s.okhandler=this._degf_OnConfirmClick,
s.objparams=i.id,s.tipstype=2,s.btnColorType=2,B.y.inst.OpenCommonMessageTips(s),this.HideMenu()}OnConfirmClick(t){const e=t,i=new G.q
i.firePlayerId=e,u.C.Inst.F_SendMsg(i)
const s=new U.H
u.C.Inst.F_SendMsg(s)}RemoveRoleEvent(){null!=this._roleinfo&&(this._roleinfo.RemoveEventHandler(d.A.LevelUpdate,this._degf_LevelUpHandle),
this._roleinfo.RemoveEventHandler(d.A.HpUpdate,this._degf_HpChangeHandle),this._roleinfo.RemoveEventHandler(d.A.ShieldUpdate,this._degf_ShieldChangeHandle))}Clear(){
this.RemoveRoleEvent(),this.headeventlister&&this.headeventlister.node&&this.headeventlister.node.off(n.NodeEventType.TOUCH_END,this._degf_OpenOperationPanel,this),
this.RemoveClickEvent(this.boxcollider,this._degf_HideMenu),this.RemoveClickEvent(this.checkBtn,this._degf_OnCheckClick),this.RemoveClickEvent(this.chatBtn,this._degf_OnChatClick),
this.RemoveClickEvent(this.addFriendBtn,this._degf_OnAddFriendClick),this.RemoveClickEvent(this.deleteFriendBtn,this._degf_OnRemoveFriendClick),
this.RemoveClickEvent(this.applyTeamBtn,this._degf_OnApplyTeamClick),this.RemoveClickEvent(this.inviteTeamBtn,this._degf_OnInviteTeamClick),
this.RemoveClickEvent(this.addBlackListBtn,this._degf_OnAddBlackListClick),this.RemoveClickEvent(this.removeBlackListBtn,this._degf_OnRemoveBlackListClick),
this.RemoveClickEvent(this.inviteAllianceBtn,this._degf_OnInviteAllyClick),this.RemoveClickEvent(this.applyAllianceBtn,this._degf_OnApplyIntoAllyClick),
this.RemoveFullScreenCollider(),this.RemoveClickEvent(this.reportBtn,this._degf_OnReportBtn),this.RemoveClickEvent(this.changeAllianceJobBtn,this._degf_OnChangeJobClick),
this.RemoveClickEvent(this.expelBtn,this._degf_OnExpelClick),this.RemoveClickEvent(this.followLeaderBtn,this._degf_OnFollowBtnClick),
this.RemoveClickEvent(this.cancelFollowBtn,this._degf_OnCancelFollowBtnClick),this.RemoveClickEvent(this.changeLeaderBtn,this._degf_OnChangeLeaderBtnClick),
this.RemoveClickEvent(this.expelTeamateBtn,this._degf_OnExpelTeamateBtnClick),this.RemoveClickEvent(this.leaveTeamBtn,this._degf_OnLeaveTeamBtnClick),
this.RemoveClickEvent(this.callTeamateBtn,this._degf_OnCallTeamateBtnClick),this.RemoveClickEvent(this.cancelCallBtn,this._degf_OnCancelCallBtnClick),
E.j.Inst_get().model.RemoveEventHandler(A.E.UPDATE_BUFF_VIEW,this._degf_UpdateBuffList),_.i.Inst.RemoveEventHandler(O.g.SELECT_TARGET_CHANGE,this._degf_OnSelectTargetUpdate),
_.i.Inst.RemoveEventHandler(O.g.CLICK_ARENABUFF,this._degf_ClickBuffItem),this.m_vo=null,this._roleinfo=null}Destroy(){this.Clear(),this._roleinfo=null}})},22259:(t,e,i)=>{i.d(e,{
b:()=>m})
var s,n=i(6847),l=i(83908),a=i(17409),r=i(46282),o=i(86133),h=i(61911),d=i(5494),_=i(73790),u=i(33314),I=i(65550),c=i(44744),g=i(33542),p=i(30635)
let m=(0,n.s_)(d.I.eTargetPlayerHeadPanel,r.Z.ui_targetplayer_headpanel).register()(s=class extends((0,l.pA)(h.f)()){constructor(...t){super(...t),this.model=null,this.roleId=null,
this._degf_OnClickClose=null,this._degf_OnPressClose=null,this._degf_OpenOperationPanel=null,this.PosTween=null}InitView(){super.InitView(),this.model=g.X.Inst(),
this.PosTween=this.tween.getComponent(_.a)}Clear(){this.m_handlerMgr.Clear()}Destroy(){}OnAddToScene(){
if(this.m_handlerMgr.AddClickEvent(this.collider,this.CreateDelegate(this.OnClickClose)),
this.m_handlerMgr.AddClickEvent(this.listener,this.CreateDelegate(this.OpenOperationPanel)),this.model.TargetRole_get()){const t=this.model.TargetRole_get().Roleinfo_get()
null!=t&&(this.roleId=t.Id_get(),this.name.textSet(t.Name_get()),this.headIcon.spriteNameSet(u.Z.GetJobIcon(t.Job_get(),t.Sex_get(),!0)),this.PosTween.ResetToBeginning(),
this.PosTween.PlayForward())}}OnPressClose(t,e){p.Y.Inst().Close()}OnClickClose(t,e){p.Y.Inst().Close()}OpenOperationPanel(t,e){let i=null
this.model.TargetRole_get()&&(i=this.model.TargetRole_get().Roleinfo_get()),null==i||i.robotId>0?I.y.inst.ClientStrMsg(2,(0,
o.T)("哎哟！TA不给查看呢")):null!=this.roleId&&(c.Z.Inst().Open(this.roleId),(0,a.sR)(d.I.eTargetPlayerHeadPanel))}})||s},44744:(t,e,i)=>{i.d(e,{Z:()=>Ot})
var s=i(42292),n=i(17409),l=i(25236),a=i(98800),r=i(28236),o=i(28475),h=i(97461),d=i(38935),_=i(5924),u=i(56937),I=i(18202),c=i(31222),g=i(52726),p=i(95721),m=i(79534),S=i(30036),T=i(84229),f=i(26753),C=i(92679),E=i(27122),A=i(28948),L=i(88997),y=i(84478),D=i(65550),O=i(5494),R=i(65963),N=i(43662),M=i(45404),w=i(31546),P=i(70650),v=i(99294),k=i(6665),U=i(78287),G=i(93877),F=i(72005),B=i(16261),H=i(13113),V=i(30849),b=i(35128),x=i(98130),q=i(98885),Y=i(85602),K=i(63076),J=i(59686),Q=i(59090),Z=i(59975),X=i(75363),$=i(3579),W=i(33314),j=i(57834),z=i(53824),tt=i(21554),et=i(33542)
class it extends V.C{constructor(){super(),this.noEquip=null,this.icon=null,this.index=0,this.isAddEvent=!1,this.data=null,this.equipment=null,this.equipView=null,
this._degf_OnClickEquipItem=null,this._degf_OnClickEquipItem=(t,e)=>this.OnClickEquipItem(t,e)}InitView(){this.noEquip=new v.z,
this.noEquip.setId(this.FatherId,this.FatherComponentID,1),this.icon=new z.Z,this.icon.setBinderId(this.FatherId,this.FatherComponentID,2),
this.icon._degf_OnClickHandler=this._degf_OnClickEquipItem}SetData(t,e){this.equipView=t,null==e||0==e.modelId_get()?(this.noEquip.SetActive(!0),
this.icon.node.SetActive(!1)):(this.data=e,this.noEquip.SetActive(!1),this.icon.node.SetActive(!0),this.icon.setBagData(e),this.equipment=e.serverData_get(),
this.index=t.model.info.GetEquipmentsByColumn(et.X.Inst().info.CurEquipColumn_get()).equipments.IndexOf(this.equipment,0))}Clear(){this.icon.Clear()}Destroy(){}AddOrRemoveEvent(t){
t?(this.isAddEvent||(j.i.Get(this.icon.node).Clear(),j.i.Get(this.icon.node).RegistonClick(this._degf_OnClickEquipItem)),
this.isAddEvent=!0):(this.isAddEvent&&j.i.Get(this.icon.node).RemoveonClick(this._degf_OnClickEquipItem),this.isAddEvent=!1)}OnClickEquipItem(t,e){const i=new Y.Z
i.Add(this.data)
const s=a.Y.Inst.PrimaryRoleInfo_get().GetWearEquipByColumnAndPos(et.X.Inst().info.CurEquipColumn_get(),this.index)
if(null!=s){const t=new K.M(s.GetEquipRes().id,s)
t.isCanOperate=!1,t.isShowAddPointTip=!1,t.isTakeOnEquip=!0,i.Add(t)}this.data.isEquipCompare=!0,
tt.J.Inst_get().OpenTipView(this.data,null,et.X.Inst().info,a.Y.Inst.PrimaryRoleInfo_get())}GetAffixSpriteStr(t){let e=""
return 1==t?e="comm_sp_0088":2==t?e="comm_sp_0087":3==t&&(e="comm_sp_0086"),e}}class st extends V.C{constructor(){super(),this.equipScore=null,this.roleTexture=null,
this.rotateController=null,this.helmet=null,this.clothes=null,this.armguard=null,this.pants=null,this.shoes=null,this.leftrings=null,this.wings=null,this.weapon=null,
this.subweapon=null,this.necklace=null,this.rightrings=null,this.normalEquip=null,this.effectWidget=null,this.equipColumnGrid=null,this.columnBg=null,this.scrollBar=null,
this.guard=null,this.rTMask=null,this.flag=null,this.equipList=null,this.model=null,this.inLoad=!1,this.effectName=null,this.effectFId=0,this.roleRotateIndex=0,this.playerAngle=0,
this.isAddEvent=!1,this.showRole=null,this.defalultColumnIndex=1,this._degf_InitModel=null,this._degf_OnAEvent=null,this._degf_OnColumnGridReposition=null,
this._degf_OnEquipSetBtnRefreshFun=null,this._degf_SetScrollBar=null,this._degf_UpdateEquipView=null,this.equipList=new Y.Z,this._degf_InitModel=t=>this.InitModel(t),
this._degf_OnAEvent=()=>this.OnAEvent(),this._degf_OnColumnGridReposition=()=>this.OnColumnGridReposition(),this._degf_OnEquipSetBtnRefreshFun=t=>this.OnEquipSetBtnRefreshFun(t),
this._degf_SetScrollBar=()=>this.SetScrollBar(),this._degf_UpdateEquipView=t=>this.UpdateEquipView(t)}InitView(){this.equipScore=new G.Q,
this.equipScore.setId(this.FatherId,this.FatherComponentID,2),this.roleTexture=new B.X,this.roleTexture.setId(this.FatherId,this.FatherComponentID,3),this.rotateController=new H.T,
this.rotateController.setId(this.FatherId,this.FatherComponentID,4),this.helmet=new it,this.helmet.setBinderId(this.FatherId,this.FatherComponentID,5),this.clothes=new it,
this.clothes.setBinderId(this.FatherId,this.FatherComponentID,6),this.armguard=new it,this.armguard.setBinderId(this.FatherId,this.FatherComponentID,7),this.pants=new it,
this.pants.setBinderId(this.FatherId,this.FatherComponentID,8),this.shoes=new it,this.shoes.setBinderId(this.FatherId,this.FatherComponentID,9),this.leftrings=new it,
this.leftrings.setBinderId(this.FatherId,this.FatherComponentID,10),this.wings=new it,this.wings.setBinderId(this.FatherId,this.FatherComponentID,12),this.weapon=new it,
this.weapon.setBinderId(this.FatherId,this.FatherComponentID,13),this.subweapon=new it,this.subweapon.setBinderId(this.FatherId,this.FatherComponentID,14),this.necklace=new it,
this.necklace.setBinderId(this.FatherId,this.FatherComponentID,15),this.rightrings=new it,this.rightrings.setBinderId(this.FatherId,this.FatherComponentID,16),
this.normalEquip=new v.z,this.normalEquip.setId(this.FatherId,this.FatherComponentID,17),this.effectWidget=new H.T,this.effectWidget.setId(this.FatherId,this.FatherComponentID,19),
this.equipColumnGrid=new k.A,this.equipColumnGrid.setId(this.FatherId,this.FatherComponentID,20),this.columnBg=new F.w,this.columnBg.setId(this.FatherId,this.FatherComponentID,21),
this.scrollBar=new U._,this.scrollBar.setId(this.FatherId,this.FatherComponentID,22),this.guard=new it,this.guard.setBinderId(this.FatherId,this.FatherComponentID,23),
this.rTMask=new v.z,this.rTMask.setId(this.FatherId,this.FatherComponentID,24),this.flag=new it,this.flag.setBinderId(this.FatherId,this.FatherComponentID,25),
this.equipColumnGrid.SetInitInfo("ui_bag_equipsetbtn",this._degf_OnEquipSetBtnRefreshFun),this.equipColumnGrid.OnReposition_set(this._degf_OnColumnGridReposition),
this.equipList.Add(this.weapon),this.equipList.Add(this.subweapon),this.equipList.Add(this.helmet),this.equipList.Add(this.clothes),this.equipList.Add(this.armguard),
this.equipList.Add(this.pants),this.equipList.Add(this.shoes),this.equipList.Add(this.necklace),this.equipList.Add(this.leftrings),this.equipList.Add(this.rightrings),
this.equipList.Add(this.wings),this.equipList.Add(this.guard),this.equipList.Add(this.flag),this.model=et.X.Inst()}OnColumnGridReposition(){
_.C.Inst_get().CallLater(this._degf_SetScrollBar)}SetScrollBar(){this.defalultColumnIndex>5?this.scrollBar.SetValue(1):this.scrollBar.SetValue(0)}SetColumnBg(){
const t=this.equipColumnGrid.data_get().Count()
if(t<=5){const e=103+78*(t-1)
this.columnBg.heightSet(e)}else this.columnBg.heightSet(446)}OnEquipSetBtnRefreshFun(t){const e=new Q.t
return e.setId(t,null,0),e}OnAddToScene(){this.rTMask.SetActive(!0),this.AddLis(),this.SetRoleView(),this.InitEquip()}Disactive(){this.DestroyModel()}Clear(){this.RemoveLis(),
this.ClearEquip(),this.DestroyModel(),this.helmet.Clear(),this.clothes.Clear(),this.armguard.Clear(),this.pants.Clear(),this.shoes.Clear(),this.leftrings.Clear(),
this.wings.Clear(),this.weapon.Clear(),this.subweapon.Clear(),this.necklace.Clear(),this.rightrings.Clear(),this.equipColumnGrid.Clear(),this.guard.Clear(),this.flag.Clear()}
Destroy(){this.equipScore=null,this.roleTexture=null,this.rotateController=null,this.helmet.Destroy(),this.helmet=null,this.clothes.Destroy(),this.clothes=null,
this.armguard.Destroy(),this.armguard=null,this.pants.Destroy(),this.pants=null,this.shoes.Destroy(),this.shoes=null,this.leftrings.Destroy(),this.leftrings=null,
this.wings.Destroy(),this.wings=null,this.weapon.Destroy(),this.weapon=null,this.subweapon.Destroy(),this.subweapon=null,this.necklace.Destroy(),this.necklace=null,
this.rightrings.Destroy(),this.rightrings=null,this.normalEquip=null,this.effectWidget=null,this.equipColumnGrid.Destroy(),this.equipColumnGrid=null,this.columnBg=null,
this.scrollBar=null,this.guard.Destroy(),this.guard=null,this.rTMask=null,this.flag.Destroy(),this.flag=null}AddLis(){
this.isAddEvent||h.i.Inst.AddEventHandler(C.g.TargetPlayerEquipColumnUpdate,this._degf_UpdateEquipView),this.isAddEvent=!0}RemoveLis(){
this.isAddEvent&&h.i.Inst.RemoveEventHandler(C.g.TargetPlayerEquipColumnUpdate,this._degf_UpdateEquipView),this.isAddEvent=!1}GetEquipViewColumnData(){
const t=X.Y.Inst_get().GetEquipColIdList(this.model.info,0)
this.defalultColumnIndex=t[t.Count()-1],null==this.defalultColumnIndex&&(this.defalultColumnIndex=1)
const e=new Y.Z
let i=null
const s=x.GF.INT(b.p.Max(1,t.Count()))
let n=0
for(;n<s;)i=new Z.G,i.columnId=n+1,i.isForTargetPlayer=!0,e.Add(i),n+=1
return e}InitEquip(){const t=this.GetEquipViewColumnData()
this.equipColumnGrid.data_set(t),this.SetColumnBg(),this.UpdateEquipView(this.defalultColumnIndex)}UpdateEquipView(t){const e=x.GF.INT(t)
this.model.info.CurEquipColumn_set(e)
const i=this.model.info.GetEquipmentsByColumn(e).equipments
let s=0
for(;s<i.Count();){let t=null
null!=i[s]&&(t=new K.M(i[s].GetItemRes().id,i[s],J.l.TargetPlayer),t.isCanOperate=!1,t.isShowAddPointTip=!1,t.isTakeOnEquip=!0),
s<this.equipList.Count()&&this.equipList[s].SetData(t),s+=1}}ClearEquip(){let t=0
for(;t<this.equipList.Count();)this.equipList[t].Clear(),t+=1}SetRoleView(){this.equipScore.textSet(q.M.IntToString(this.model.info.BattleScore_get())),
this.SetEffectOnHead(this.model.info.TitleId_get()),this.ShowModel()}SetEffectOnHead(t){if(0==t)this.effectWidget.node.SetActive(!1)
else if(this.effectWidget.node.SetActive(!0),!this.inLoad){this.inLoad=!0
const e=$.W.Inst().getItemById(t)
null!=this.effectName&&I.g.DestroyUIById(this.effectFId),this.effectName=e.showEffect}}LoadedHandle(t){this.effectFId=t[0]
const e=new V.C
e.setId(this.effectFId,null,0),e.node.transform.ComponentId=-1,e.node.transform.SetParent(this.effectWidget.FatherId,this.effectWidget.ComponentId),this.inLoad=!1}ShowModel(){
N.M.Instance_get().ActiveStage(st.STAGE_ID)
const t=new w.O
t._displayID=W.Z.GetDisplayId(this.model.info),t._world=N.M.Instance_get().GetStageWorldType(st.STAGE_ID),t._vPos.Set(0,0),this.model.TempRole_get().ShowRide_set(!1),
this.model.TempRole_get().wingstand=!0,this.model.TempRole_get().isShowAni=!0,this.model.TempRole_get().initEnd=this._degf_InitModel,
this.model.TempRole_get().initByDisinfo(this.model.info,t,!0),this.model.TempRole_get().SetRolePosXYZ(0,0,0),this.model.TempRole_get().SetDirection(this.playerAngle),
this.model.TempRole_get().MainRole_get().DisableShadow(),this.model.TempRole_get().SetAdditionEquipEff(),
M.n.Instance_get().SetDisplayObject(st.STAGE_ID,this.model.TempRole_get().MainRole_get().handle,0),this.roleTexture.SetMainTextureByPhoto(st.STAGE_ID),
null!=this.model.TempRole_get()&&(P.e.GetInst().UnregDrag(this.roleRotateIndex),
this.roleRotateIndex=P.e.GetInst().RegDrag(this.rotateController.node,this.model.TempRole_get().MainRole_get()))}InitModel(t){const e=this.model.TempRole_get().GetShowWeaponAni(!1)
this.model.TempRole_get().MainRole_get().PassEvent(e,this._degf_OnAEvent)}OnAEvent(){const t=this.model.TempRole_get().GetAERootClip()
this.model.TempRole_get().MainRole_get().PassEvent(t)}DestroyModel(){
null!=this.model.TempRole_get()&&null!=this.model.TempRole_get().MainRole_get()&&(this.model.TempRole_get().Destroy(),
N.M.Instance_get().DeactiveStage(st.STAGE_ID,this.roleTexture.FatherId,this.roleTexture.ComponentId),this.rTMask.SetActive(!1))}}st.STAGE_ID=60
var nt=i(87676),lt=i(35907),at=i(82737),rt=i(9986),ot=i(3522)
class ht extends V.C{constructor(){super(),this.name=null,this.level=null,this.modelTex=null,this.skillGrid=null,this.lockTip=null,this.hpBtn=null,this.defenseBtn=null,
this.attackBtn=null,this.criticalBtn=null,this.hpNormalState=null,this.hpDisableState=null,this.defenseNormalState=null,this.defenseDisableState=null,this.attackNormalState=null,
this.attackDisableState=null,this.criticalNormalState=null,this.criticalDisableState=null,this.lockAnime=null,this.mTMask=null,this.immortals=null,this.isAddEvent=!1,
this.normalObjs=null,this.disableObjs=null,this.immortalBtns=null,this.cha=null,this._degf_OnImmortalClick=null,this._degf_OnSkillItemRefresh=null,this._degf_SortImmortals=null,
this._degf_OnImmortalClick=(t,e)=>this.OnImmortalClick(t,e),this._degf_OnSkillItemRefresh=t=>this.OnSkillItemRefresh(t),this._degf_SortImmortals=(t,e)=>this.SortImmortals(t,e)}
InitView(){this.name=new G.Q,this.name.setId(this.FatherId,this.FatherComponentID,1),this.level=new G.Q,this.level.setId(this.FatherId,this.FatherComponentID,2),
this.modelTex=new B.X,this.modelTex.setId(this.FatherId,this.FatherComponentID,3),this.skillGrid=new k.A,this.skillGrid.setId(this.FatherId,this.FatherComponentID,4),
this.lockTip=new G.Q,this.lockTip.setId(this.FatherId,this.FatherComponentID,5),this.hpBtn=new rt.W,this.hpBtn.setId(this.FatherId,this.FatherComponentID,6),
this.defenseBtn=new rt.W,this.defenseBtn.setId(this.FatherId,this.FatherComponentID,7),this.attackBtn=new rt.W,this.attackBtn.setId(this.FatherId,this.FatherComponentID,8),
this.criticalBtn=new rt.W,this.criticalBtn.setId(this.FatherId,this.FatherComponentID,9),this.hpNormalState=new v.z,
this.hpNormalState.setId(this.FatherId,this.FatherComponentID,10),this.hpDisableState=new v.z,this.hpDisableState.setId(this.FatherId,this.FatherComponentID,11),
this.defenseNormalState=new v.z,this.defenseNormalState.setId(this.FatherId,this.FatherComponentID,12),this.defenseDisableState=new v.z,
this.defenseDisableState.setId(this.FatherId,this.FatherComponentID,13),this.attackNormalState=new v.z,this.attackNormalState.setId(this.FatherId,this.FatherComponentID,14),
this.attackDisableState=new v.z,this.attackDisableState.setId(this.FatherId,this.FatherComponentID,15),this.criticalNormalState=new v.z,
this.criticalNormalState.setId(this.FatherId,this.FatherComponentID,16),this.criticalDisableState=new v.z,this.criticalDisableState.setId(this.FatherId,this.FatherComponentID,17),
this.lockAnime=new ot.k,this.lockAnime.setId(this.FatherId,this.FatherComponentID,18),this.mTMask=new v.z,this.mTMask.setId(this.FatherId,this.FatherComponentID,19),
this.normalObjs=new Y.Z,this.normalObjs.Add(this.attackNormalState),this.normalObjs.Add(this.hpNormalState),this.normalObjs.Add(this.defenseNormalState),
this.normalObjs.Add(this.criticalNormalState),this.disableObjs=new Y.Z,this.disableObjs.Add(this.attackDisableState),this.disableObjs.Add(this.hpDisableState),
this.disableObjs.Add(this.defenseDisableState),this.disableObjs.Add(this.criticalDisableState),this.immortalBtns=new Y.Z,this.immortalBtns.Add(this.attackBtn),
this.immortalBtns.Add(this.hpBtn),this.immortalBtns.Add(this.defenseBtn),this.immortalBtns.Add(this.criticalBtn)}OnAddToScene(){this.mTMask.SetActive(!0),this.AddLis(),
this.RefreshImmortals(),this.SetImmortal()}RefreshImmortals(){if(this.immortals=et.X.Inst().info.Immortal_get(),4!=this.immortals.Count()){const t=new Y.Z
let e=0
for(;e<4;)t.Add(!1),e+=1
let i=0
for(;i<this.immortals.Count();)t[this.immortals[i].type]=!0,i+=1
let s=0
for(;s<t.Count();)t[s],s+=1}this.immortals.Sort(this._degf_SortImmortals)}Disactive(){}AddLis(){
this.isAddEvent||(j.i.Get(this.hpBtn.node).RegistonClick(this._degf_OnImmortalClick),j.i.Get(this.defenseBtn.node).RegistonClick(this._degf_OnImmortalClick),
j.i.Get(this.attackBtn.node).RegistonClick(this._degf_OnImmortalClick),j.i.Get(this.criticalBtn.node).RegistonClick(this._degf_OnImmortalClick),this.isAddEvent=!0)}
OnImmortalClick(t,e){}Clear(){this.RemoveLis(),N.M.Instance_get().DeactiveStage(ht.STAGE_ID,this.modelTex.FatherId,this.modelTex.ComponentId),this.mTMask.SetActive(!1)}RemoveLis(){
j.i.Get(this.hpBtn.node).RemoveonClick(this._degf_OnImmortalClick),j.i.Get(this.defenseBtn.node).RemoveonClick(this._degf_OnImmortalClick),
j.i.Get(this.attackBtn.node).RemoveonClick(this._degf_OnImmortalClick),j.i.Get(this.criticalBtn.node).RemoveonClick(this._degf_OnImmortalClick)}Destroy(){this.skillGrid.Destroy(),
this.skillGrid=null,null!=this.cha&&(this.cha.Destroy(),this.cha=null)}SetModel(){N.M.Instance_get().ActiveStage(ht.STAGE_ID)
let t=1
const e=m.P.zero_get(),i=m.P.zero_get(),s=new Y.Z
e.Set(s[7],s[8],s[9]),i.Set(s[10],s[11],s[12]),t=s[13],null!=this.cha&&(this.cha.Destroy(),this.cha=null),this.cha=new nt.t
const n=new w.O
n._displayID=-1,n._world=N.M.Instance_get().GetStageWorldType(ht.STAGE_ID),n.shiledType=at.g.DT_NONE
const l=M.n.Instance_get().CreateDisplayObject(n)
N.M.Instance_get().SetDisplayObject(ht.STAGE_ID,l,0)
const a=new lt.M(l)
this.cha.MainRole_set(a),N.M.Instance_get().SetWorldRotation(ht.STAGE_ID,0,i),this.cha.setPosXYZ(e.x,e.y,e.z),this.cha.SetSize(t),this.modelTex.SetMainTextureByPhoto(ht.STAGE_ID),
this.modelTex.SetUVRect(0,0,1,1)}ResetImmortal(){this.SetImmortal()}SetImmortal(){}SortImmortals(t,e){return t.type>e.type?1:t.type<e.type?-1:0}SetTalentItem(){}}ht.STAGE_ID=55
var dt=i(30635),_t=i(90419),ut=i(50089),It=i(9776),ct=i(30267),gt=i(61911),pt=i(87923),mt=i(52429),St=i(5268),Tt=i(93137),ft=i(29714),Ct=i(36529)
class Et extends gt.f{constructor(){super(),this.bg=null,this.level=null,this.name=null,this.armorObj=null,this.jewelryObj=null,this.helmet=null,this.helmetTip=null,
this.armguard=null,this.armguardTip=null,this.clothes=null,this.clothesTip=null,this.pants=null,this.pantsTip=null,this.shoes=null,this.shoesTip=null,this.necklace=null,
this.necklaceTip=null,this.leftrings=null,this.leftringsTip=null,this.rightrings=null,this.rightringsTip=null,this.scrollView=null,this.back=null,this.table=null,
this.equipList=null,this.tipList=null,this._degf_CloseTip=null,this._degf_OnItemRefreshFun=null,this._degf_OnItemUpdate=null,this._degf_OnReposition=null,this.equipList=new Y.Z,
this.tipList=new Y.Z,this._degf_CloseTip=(t,e)=>this.CloseTip(t,e),this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),this._degf_OnItemUpdate=t=>this.OnItemUpdate(t),
this._degf_OnReposition=()=>this.OnReposition()}InitView(){this.bg=new F.w,this.bg.setId(this.FatherId,this.FatherComponentID,1),this.level=new G.Q,
this.level.setId(this.FatherId,this.FatherComponentID,2),this.name=new G.Q,this.name.setId(this.FatherId,this.FatherComponentID,3),this.armorObj=new v.z,
this.armorObj.setId(this.FatherId,this.FatherComponentID,4),this.jewelryObj=new v.z,this.jewelryObj.setId(this.FatherId,this.FatherComponentID,5),this.helmet=new v.z,
this.helmet.setId(this.FatherId,this.FatherComponentID,6),this.helmetTip=new v.z,this.helmetTip.setId(this.FatherId,this.FatherComponentID,7),this.armguard=new v.z,
this.armguard.setId(this.FatherId,this.FatherComponentID,8),this.armguardTip=new v.z,this.armguardTip.setId(this.FatherId,this.FatherComponentID,9),this.clothes=new v.z,
this.clothes.setId(this.FatherId,this.FatherComponentID,10),this.clothesTip=new v.z,this.clothesTip.setId(this.FatherId,this.FatherComponentID,11),this.pants=new v.z,
this.pants.setId(this.FatherId,this.FatherComponentID,12),this.pantsTip=new v.z,this.pantsTip.setId(this.FatherId,this.FatherComponentID,13),this.shoes=new v.z,
this.shoes.setId(this.FatherId,this.FatherComponentID,14),this.shoesTip=new v.z,this.shoesTip.setId(this.FatherId,this.FatherComponentID,15),this.necklace=new v.z,
this.necklace.setId(this.FatherId,this.FatherComponentID,16),this.necklaceTip=new v.z,this.necklaceTip.setId(this.FatherId,this.FatherComponentID,17),this.leftrings=new v.z,
this.leftrings.setId(this.FatherId,this.FatherComponentID,18),this.leftringsTip=new v.z,this.leftringsTip.setId(this.FatherId,this.FatherComponentID,19),this.rightrings=new v.z,
this.rightrings.setId(this.FatherId,this.FatherComponentID,20),this.rightringsTip=new v.z,this.rightringsTip.setId(this.FatherId,this.FatherComponentID,21),
this.scrollView=new It.h,this.scrollView.setId(this.FatherId,this.FatherComponentID,22),this.back=new H.T,this.back.setId(this.FatherId,this.FatherComponentID,23),
this.table=new ct.V,this.table.setId(this.FatherId,this.FatherComponentID,24),this.equipList.Add(this.helmet),this.equipList.Add(this.clothes),this.equipList.Add(this.armguard),
this.equipList.Add(this.shoes),this.equipList.Add(this.pants),this.equipList.Add(this.necklace),this.equipList.Add(this.leftrings),this.equipList.Add(this.rightrings),
this.tipList.Add(this.helmetTip),this.tipList.Add(this.clothesTip),this.tipList.Add(this.armguardTip),this.tipList.Add(this.shoesTip),this.tipList.Add(this.pantsTip),
this.tipList.Add(this.necklaceTip),this.tipList.Add(this.leftringsTip),this.tipList.Add(this.rightringsTip),
this.table.SetInitInfo("ui_equiptip_suitattr",this._degf_OnItemRefreshFun),this.table.OnReposition_set(this._degf_OnReposition)}OnItemRefreshFun(t){const e=new Ct.c
return e.setId(t,null,0),e}OnAddToScene(){this.AddLis(),this.SetData(et.X.Inst().suitData)}Clear(){this.RemoveLis()}Destroy(){this.table.Destroy(),this.table=null}AddLis(){
h.i.Inst.AddEventHandler(C.g.EQUIP_TIP_SUIT_MODULE_UPDATE,this._degf_OnItemUpdate),this.AddFullScreenCollider(this.node,this._degf_CloseTip,this._degf_CloseTip)}RemoveLis(){
h.i.Inst.RemoveEventHandler(C.g.EQUIP_TIP_SUIT_MODULE_UPDATE,this._degf_OnItemUpdate),this.RemoveFullScreenCollider()}SetData(t){let e=0
const i=St.H.Inst().getSuitAttrsBySuitId(t.suitData[0].config.id)
i.Count()>0&&(e=i[i.Count()-1].suitNum),this.name.textSet(ft.C.Inst_get().GetSuitName(t.suitData[0],t.suitData.Count(),e)),this.level.textSet(pt.l.getEquiplvStr(t.suitLv)),
this.armorObj.SetActive(1==t.suitType),this.jewelryObj.SetActive(2==t.suitType)
let s=0
for(;s<this.tipList.Count();)this.tipList[s].SetActive(!1),s+=1
let n=0
for(;n<t.suitData.Count();)this.tipList[t.suitData[n].part].SetActive(!0),n+=1
const l=new Y.Z
let a=0
for(;a<i.Count();){const e=new Tt.w
e.suitConfig=t.suitData[0].config,e.config=i[a],e.suitCount=t.suitData.Count()
const s=_t.d.parseJsonObjectWithFix(i[a].suitAttrs,"attrs")
e.attrs=ut.t.decode(s,mt.L),e.attrs.parse(),l.Add(e),a+=1}this.table.data_set(l)}CloseTip(t,e){Ot.Inst().CloseSuitTipPanel()}OnItemUpdate(t){let e=!0
const i=this.table.itemList
let s=0
for(;s<i.Count();){const t=i[s]
if(t.node.activeSelf()&&0==t.IsReady_get()){e=!1
break}s+=1}e&&this.table.Reposition()}OnReposition(){this.scrollView.ResetPosition()}}var At,Lt,yt=i(86133)
class Dt extends V.C{constructor(){super(),this.lbAttackPoint=null,this.lbDefensePoint=null,this.lbCommonPoint=null,this.isAdded=!1,this._degf_OnBtnClick=null,
this._degf_OnBtnClick=(t,e)=>this.OnBtnClick(t,e)}InitView(){this.lbAttackPoint=new G.Q,this.lbAttackPoint.setId(this.FatherId,this.FatherComponentID,1),
this.lbDefensePoint=new G.Q,this.lbDefensePoint.setId(this.FatherId,this.FatherComponentID,2),this.lbCommonPoint=new G.Q,
this.lbCommonPoint.setId(this.FatherId,this.FatherComponentID,3)}OnAddToScene(){this.SetLabels()}AddOrRemoveLis(t){
t&&!this.isAdded?this.isAdded=!0:!t&&this.isAdded&&(this.isAdded=!1)}OnBtnClick(t,e){}Clear(){this.AddOrRemoveLis(!1)}Destroy(){this.lbAttackPoint=null,this.lbDefensePoint=null,
this.lbCommonPoint=null}SetLabels(){et.X.Inst().info
this.lbAttackPoint.textSet((0,yt.T)("已投 ")+(0,yt.T)(" 点")),this.lbDefensePoint.textSet((0,yt.T)("已投 ")+(0,yt.T)(" 点")),this.lbCommonPoint.textSet((0,yt.T)("已投 ")+(0,yt.T)(" 点"))}}
let Ot=(Lt=class t{constructor(){this.roleId=null,this.targetReq=!1,this.needself=!1,this.model=null,this.mainPanel=null,this.equipViewContainer=null,this.equipView=null,
this.guardViewContainer=null,this.guardView=null,this.immortalViewContainer=null,this.immortalView=null,this.talentViewContainer=null,this.talentView=null,this.shortInterval=-1,
this.suitTipView=null,this.mainPanelPos=null,this._degf_DelayCloseSuitTipPanel=null,this._degf_DestoryPanel=null,this._degf_DestorySuitTipPanel=null,
this._degf_OnEquipViewLoadComplete=null,this._degf_OnGuardViewLoadComplete=null,this._degf_OnImmortalViewLoadComplete=null,this._degf_OnTalentViewLoadComplete=null,
this._degf_ShowHandler=null,this._degf_ShowSuitTipHandler=null,this.mainPanelPos=new m.P(0,0,0),this._degf_DelayCloseSuitTipPanel=()=>this.DelayCloseSuitTipPanel(),
this._degf_DestoryPanel=()=>this.DestoryPanel(),this._degf_DestorySuitTipPanel=()=>this.DestorySuitTipPanel(),this._degf_OnEquipViewLoadComplete=t=>this.OnEquipViewLoadComplete(t),
this._degf_OnGuardViewLoadComplete=t=>this.OnGuardViewLoadComplete(t),this._degf_OnImmortalViewLoadComplete=t=>this.OnImmortalViewLoadComplete(t),
this._degf_OnTalentViewLoadComplete=t=>this.OnTalentViewLoadComplete(t),this._degf_ShowHandler=t=>this.ShowHandler(t),this._degf_ShowSuitTipHandler=t=>this.ShowSuitTipHandler(t),
this.model=et.X.Inst()}static Inst(){return null==t.inst&&(t.inst=new t),t.inst}Open(t,e=null,i=null,s=null,n=null,l=null){if(null==e&&(e=0),null==i&&(i=0),
this.mainPanelPos.Set(0,0,0),s&&this.mainPanelPos.Set(s.x,s.y,s.z),this.roleId=t,this.model.RoleId_set(t),this.targetReq=!0,this.model.queryId=t,this.model.accountIdx=n,
this.model.queryType=l,null==n){const s=new y.g
s.targetId=t,s.queryWay=e,s.sid=i,d.C.Inst.F_SendMsg(s)}else if(null==l&&(l=1),2==l){const t=new A.U
t.account=n,d.C.Inst.F_SendMsg(t)}else{const e=new L.d
e.robotId=1==l?t.ToString():n,e.queryType=l,d.C.Inst.F_SendMsg(e)}}IsTopPanelShow(){return null!=this.mainPanel&&this.mainPanel.isShow_get()}OpenInfoPanel(){if(S.P.Inst().Close(),
f.d.Inst_get().controller.CloseMainPanel(),null!=this.mainPanel&&this.mainPanel.isShow_get())this.mainPanel.OnAddToScene()
else{const t=new u.v
t.layerType=g.F.MainUI,t.isShowMask=!0,t.isDefaultUITween=!0,t.viewClass=R.w,(0,n.Yp)(O.I.RyTargetPlayerMainPanel,t)}}Close(){
null!=this.mainPanel&&c.N.inst.CloseById(O.I.RyTargetPlayerMainPanel)}DestoryPanel(){I.g.DestroyUIObj(this.mainPanel),this.mainPanel=null}ShowHandler(t){
return null==this.mainPanel&&(this.mainPanel=new R.w,this.mainPanel.setId(t,null,0)),this.mainPanel}SM_QueryOtherPlayerInfoHandler(t){this.model.targetRoles.Clear()
const e=t,i=e.info.playerInfos
let s=0
this.model.selectedCreateIndex=-1
for(let t=0;t<=i.Count()-1;t++){const e=new r.H
a.Y.Inst.ConvertOtherPlayInfo2RoleInfo(e,i[t]),!p.o.IsNullOrZero(e.m_id)&&e.m_id.Equal(this.model.queryId)&&(this.model.selectedCreateIndex=t),this.model.targetRoles.Add(e),
s+=e.m_battleScore}this.model.TotalBattleScore_set(s),this.model.selectedCreateIndex>=i.Count()&&(this.model.selectedCreateIndex=0),
-1==this.model.selectedCreateIndex&&(this.model.selectedCreateIndex=0),this.model.info=this.model.targetRoles[this.model.selectedCreateIndex],this.model.queryMsg=e,
this.model.isOnline=i[0].onlineStatus
const l=E.Q.Inst().GetObjectByName("Role",o.u)
if(null!=this.model.targetRole&&l.leaderRole_set(this.model.targetRole.leaderRole_get()),l.Roleinfo_set(this.model.info),this.model.HandleFashionDressInfo(e.info.dressInfo),
T.Q.Inst_get().isAsuramApplyRoleInfo)et.X.Inst().TempRole_set(l),this.OpenInfoPanel(),T.Q.Inst_get().isAsuramApplyRoleInfo=!1
else{
if(et.X.Inst().TempRole_set(l),a.Y.Inst.PrimaryRoleInfo_get().Id_get().Equal(this.model.info.m_id))return this.needself?et.X.Inst().needOpenPos?(dt.Y.Inst().OpenOperationPanel(1),
et.X.Inst().needOpenPos=!1):dt.Y.Inst().OpenOperationPanel():D.y.inst.ClientSysMessage(10810065),void(this.needself=!1)
null!=this.mainPanel&&this.mainPanel.isShow_get()?this.mainPanel.Refresh():0==(0,n.qJ)(O.I.TargetPlayerPanelId)?et.X.Inst().headlookother?(this.OpenInfoPanel(),
et.X.Inst().headlookother=!1):et.X.Inst().needOpenPos?(dt.Y.Inst().OpenOperationPanel(1),et.X.Inst().needOpenPos=!1):dt.Y.Inst().OpenOperationPanel():(dt.Y.Inst().Close(!1),
this.OpenInfoPanel())}this.targetReq=!1}InitEquipViewData(t){null==this.equipView&&(this.equipViewContainer=t,
I.g.LoadOne("ui_targetplayer_equipview",this._degf_OnEquipViewLoadComplete))}OnEquipViewLoadComplete(t){const e=t[0]
this.equipView=new st,this.equipView.setId(e,null,0),this.equipView.node.transform.SetParent(this.equipViewContainer.FatherId,this.equipViewContainer.ComponentId),
c.N.inst.SetChildDepth(this.mainPanel.FatherId,e),this.equipView.OnAddToScene(),this.mainPanel.equipView=this.equipView}ClearEquipViewData(){
null!=this.equipView&&this.equipView.Clear()}DestroyEquipView(){null!=this.equipView&&(this.equipView.Clear(),this.equipView.Destroy(),I.g.DestroyUIObj(this.equipView),
this.equipView=null),I.g.Unload(this._degf_OnEquipViewLoadComplete)}InitGuardViewData(t){(0,l.S)("Init Quard View error")}OnGuardViewLoadComplete(t){}ClearGuardViewData(){
null!=this.guardView&&this.guardView.Clear()}DestroyGuardView(){null!=this.guardView&&(this.guardView.Clear(),this.guardView.Destroy(),I.g.DestroyUIObj(this.guardView),
this.guardView=null),I.g.Unload(this._degf_OnGuardViewLoadComplete)}InitImmortalViewData(t){null==this.immortalView&&(this.immortalViewContainer=t,
I.g.LoadOne("ui_targetplayer_immortalview",this._degf_OnImmortalViewLoadComplete))}OnImmortalViewLoadComplete(t){const e=t[0]
this.immortalView=new ht,this.immortalView.setId(e,null,0),this.immortalView.node.transform.SetParent(this.immortalViewContainer.FatherId,this.immortalViewContainer.ComponentId),
c.N.inst.SetChildDepth(this.mainPanel.FatherId,e),this.immortalView.OnAddToScene(),this.mainPanel.immortalView=this.immortalView}ClearImmortalViewData(){
null!=this.immortalView&&this.immortalView.Clear()}DestroyImmortalView(){null!=this.immortalView&&(this.immortalView.Clear(),this.immortalView.Destroy(),
I.g.DestroyUIObj(this.immortalView),this.immortalView=null),I.g.Unload(this._degf_OnImmortalViewLoadComplete)}InitTalentViewData(t){
null==this.talentView&&(this.talentViewContainer=t,I.g.LoadOne("ui_targetplayer_talentview",this._degf_OnTalentViewLoadComplete))}OnTalentViewLoadComplete(t){const e=t[0]
this.talentView=new Dt,this.talentView.setId(e,null,0),this.talentView.node.transform.SetParent(this.talentViewContainer.FatherId,this.talentViewContainer.ComponentId),
c.N.inst.SetChildDepth(this.mainPanel.FatherId,e),this.talentView.OnAddToScene(),this.mainPanel.talentView=this.talentView}ClearTalentViewData(){
null!=this.talentView&&this.talentView.Clear()}DestroyTalentView(){null!=this.talentView&&(this.talentView.Clear(),this.talentView.Destroy(),
I.g.DestroyUIById(this.talentView.FatherId),this.talentView=null),I.g.Unload(this._degf_OnTalentViewLoadComplete)}OpenSuitTipPanel(t){if(et.X.Inst().suitData=t,
null==this.suitTipView){const t=new u.v
t.layerType=g.F.Tip,c.N.inst.OpenById(O.I.TargetPlayerSuitTip,this._degf_ShowSuitTipHandler,this._degf_DestorySuitTipPanel,t)}else _.C.Inst_get().ClearInterval(this.shortInterval),
this.shortInterval=-1,this.suitTipView.SetData(t)}CloseSuitTipPanel(){this.shortInterval=_.C.Inst_get().SetInterval(this._degf_DelayCloseSuitTipPanel,50,1)}
DelayCloseSuitTipPanel(){c.N.inst.ClosePanel(this.suitTipView),h.i.Inst.RaiseEvent(C.g.BASE_TIP_CLOSE)}DestorySuitTipPanel(){I.g.DestroyUIObj(this.suitTipView),
this.suitTipView=null}ShowSuitTipHandler(t){return null==this.suitTipView&&(this.suitTipView=new Et,this.suitTipView.setId(t,null,0)),this.suitTipView}},Lt.inst=null,Rt=At=Lt,
Nt="Inst",Mt=[s.n],wt=Object.getOwnPropertyDescriptor(At,"Inst"),Pt=At,vt={},Object.keys(wt).forEach((function(t){vt[t]=wt[t]})),vt.enumerable=!!vt.enumerable,
vt.configurable=!!vt.configurable,("value"in vt||vt.initializer)&&(vt.writable=!0),vt=Mt.slice().reverse().reduce((function(t,e){return e(Rt,Nt,t)||t}),vt),
Pt&&void 0!==vt.initializer&&(vt.value=vt.initializer?vt.initializer.call(Pt):void 0,vt.initializer=void 0),void 0===vt.initializer&&(Object.defineProperty(Rt,Nt,vt),vt=null),At)
var Rt,Nt,Mt,wt,Pt,vt},33542:(t,e,i)=>{i.d(e,{X:()=>c})
var s=i(32076),n=i(38836),l=i(95721),a=i(98130),r=i(85602),o=i(52212),h=i(52429),d=i(38962),_=i(61768),u=i(66476),I=i(5727)
class c{constructor(){this.tabType=-1,this.roleId=l.o.ZERO,this.preRoleId=null,this.targetRole=null,this.tempRole=null,this.queryMsg=null,this.curQueryMsg=null,
this.accountIdx=null,this.queryType=null,this.info=null,this.battleItemDataDic=null,this.defaultBattleItemIndex=0,this.canOperate=!0,this.preIndex=0,this.headlookother=!1,
this.isOnline=!0,this.openPos=null,this.needOpenPos=!1,this.suitData=null,this.isFromAsuram=!1,this.targetRoles=null,this.selectedCreateIndex=0,this.queryId=null,this.column=0,
this.fashionInfo=null,this.fashionShowDic=null,this.totalBattleScore=null,this.openPos=new o.F(0,0),this.targetRoles=new r.Z,this.fashionShowDic=new d.X}static Inst(){
return null==c.inst&&(c.inst=new c),c.inst}ResetModel(){this.fashionShowDic.Clear()}getRoleInfo(t){
for(let e=0;e<=this.targetRoles.Count()-1;e++)if(this.targetRoles[e].Id_get()==t)return this.targetRoles[e]
return null}RoleId_get(){return this.roleId}RoleId_set(t){this.roleId=null==t?l.o.ZERO:t}TargetRole_get(){return this.targetRole}TargetRole_set(t){
null!=this.targetRole&&(this.preRoleId=this.targetRole.GetGameId()),this.targetRole=t,null!=this.targetRole&&this.RoleId_set(this.targetRole.GetGameId())}TempRole_get(){
return this.tempRole}TempRole_set(t){this.tempRole=t,this.TargetRole_set(t)}TotalBattleScore_get(){return this.totalBattleScore}TotalBattleScore_set(t){this.totalBattleScore=t}
GainHelpBattleData(){const t=new r.Z
for(const[e,i]of(0,n.V5)(this.battleItemDataDic))0!=i.index&&null!=i.itemData.guardInfo_get()&&t.Add(i.itemData)
for(;t.Count()>3;)t.RemoveAt(t.Count()-1)
return t}SortHelpBattleGuard(t,e){const i=t,s=e
return 0==s.type&&0==i.type?0:2==s.type&&2==i.type?i.index-s.index:s.type-i.type}HandleFashionDressInfo(t){this.fashionShowDic.Clear(),this.fashionInfo=t
for(const[e,i]of(0,n.V5)(t.player2Info)){const t=this.GetFashionShowData(e),l={}
let a=0
for(;a<t.Count();){const e=t[a]
e.isWear=!1
for(const[t,s]of(0,n.V5)(i.dressMap))if(e.res.id==s){e.isWear=!0
break}e.isLock=!0
let s=0
for(;s<i.unlocks.Count();){if(e.res.id==i.unlocks[s]){e.isLock=!1
break}s+=1}null==l[e.res.suitId]?e.isLock||(e.suitOrder=0,l[e.res.suitId]=0):e.suitOrder=l[e.res.suitId],a+=1}for(a=0;a<t.Count();){const e=t[a]
null==l[e.res.suitId]?e.isLock||(e.suitOrder=0,l[e.res.suitId]=0):e.suitOrder=l[e.res.suitId],a+=1}const r=this.getRoleInfo(e)
r&&r.Fashions_set(i.dressMap),t.Sort((0,s.v)(I.X.Inst_get().OnSortList,this))}}GetFashionShowData(t){if(!this.fashionShowDic.LuaDic_ContainsKey(t)){
this.fashionShowDic.LuaDic_AddOrSetItem(t,new r.Z)
const e=this.getRoleInfo(t)
if(e)for(const[i,s]of(0,n.V5)(u.L.Inst().fashionMap))if(a.GF.INT(e.Job_get()/1e3)==s.job){const e=new _.U
e.res=s,e.consumes=u.L.Inst().getFashionConsumeById(i)
const n=h.L.CreateFromJson(s.attrs)
n.parse(),e.attrs=n
const l=u.L.Inst().getSuitAttrItemBySuitId(s.suitId)
e.suitRes=l
const a=h.L.CreateFromJson(l.suitAttrs)
a.parse(),e.suitAttrs=a,this.fashionShowDic.LuaDic_GetItem(t).Add(e)}this.fashionShowDic.LuaDic_GetItem(t).Sort((0,s.v)(I.X.Inst_get().OnSortList,this))}
return this.fashionShowDic.LuaDic_GetItem(t)}GetActiveNum(t,e){const i=this.GetFashionShowData(t)
let s=0,n=0
for(;n<i.Count();)i[n].res.suitId!=e||i[n].isLock||(s+=1),n+=1
return s}}c.inst=null},85517:(t,e,i)=>{
var s,n=i(6847),l=i(83908),a=i(46282),r=i(86133),o=i(98800),h=i(97960),d=i(97461),_=i(38935),u=i(5494),I=i(95721),c=i(98130),g=i(79534),p=i(51628),m=i(80486),S=i(84229),T=i(50894),f=i(26753),C=i(92679),E=i(33314),A=i(74045),L=i(39879),y=i(49067),D=i(87923),O=i(78417),R=i(84708),N=i(48933),M=i(21987),w=i(75439),P=i(38501),v=i(10965),k=i(55617),U=i(76944),G=i(41864),F=i(65550),B=i(39043),H=i(85942),V=i(44744),b=i(33542),x=i(30635)
;(0,n.s_)(u.I.TargetPlayerPanelId,a.Z.ui_targetplayer_operationpanel).layerTip().register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),this.asuramFlag=null,
this.equipScore=null,this.myInfo=null,this.role=null,this.targetInfo=null,this.model=null,this.noVipNamePos=null,this.havaVipNamePos=null,this._degf_OnAddBlackListClick=null,
this._degf_OnAddFriendClick=null,this._degf_OnApplyIntoAllyClick=null,this._degf_OnCallTeamateBtnClick=null,this._degf_OnCancelCallBtnClick=null,
this._degf_OnCancelFollowBtnClick=null,this._degf_OnChangeJobClick=null,this._degf_OnChangeLeaderBtnClick=null,this._degf_OnChatClick=null,this._degf_OnCheckClick=null,
this._degf_OnClickClose=null,this._degf_OnConfirmClick=null,this._degf_OnExpelClick=null,this._degf_OnExpelTeamateBtnClick=null,this._degf_OnFollowBtnClick=null,
this._degf_OnInviteAllyClick=null,this._degf_OnPlayerDie=null,this._degf_OnRemoveBlackListClick=null,this._degf_OnRemoveFriendClick=null,this._degf_OnTargetLevelUp=null,
this._degf_UpdateAsuramIdHandle=null,this._degf_OnRemoveFriendTipsHandle=null,this._degf_OnChuanGongInviteHandle=null}_initBinder(){this.noVipNamePos=new g.P(38.7,23,0),
this.havaVipNamePos=new g.P(88.5,23,0),this._degf_OnAddBlackListClick=(t,e)=>this.OnAddBlackListClick(t,e),this._degf_OnAddFriendClick=(t,e)=>this.OnAddFriendClick(t,e),
this._degf_OnApplyIntoAllyClick=(t,e)=>this.OnApplyIntoAllyClick(t,e),this._degf_OnCallTeamateBtnClick=(t,e)=>this.OnCallTeamateBtnClick(t,e),
this._degf_OnCancelCallBtnClick=(t,e)=>this.OnCancelCallBtnClick(t,e),this._degf_OnCancelFollowBtnClick=(t,e)=>this.OnCancelFollowBtnClick(t,e),
this._degf_OnChangeJobClick=(t,e)=>this.OnChangeJobClick(t,e),this._degf_OnChangeLeaderBtnClick=(t,e)=>this.OnChangeLeaderBtnClick(t,e),
this._degf_OnChatClick=(t,e)=>this.OnChatClick(t,e),this._degf_OnCheckClick=(t,e)=>this.OnCheckClick(t,e),this._degf_OnClickClose=t=>this.OnClickClose(t),
this._degf_OnConfirmClick=t=>this.OnConfirmClick(t),this._degf_OnExpelClick=(t,e)=>this.OnExpelClick(t,e),this._degf_OnExpelTeamateBtnClick=(t,e)=>this.OnExpelTeamateBtnClick(t,e),
this._degf_OnFollowBtnClick=(t,e)=>this.OnFollowBtnClick(t,e),this._degf_OnInviteAllyClick=(t,e)=>this.OnInviteAllyClick(t,e),this._degf_OnPlayerDie=t=>this.OnPlayerDie(t),
this._degf_OnRemoveBlackListClick=(t,e)=>this.OnRemoveBlackListClick(t,e),this._degf_OnRemoveFriendClick=(t,e)=>this.OnRemoveFriendClick(t,e),
this._degf_OnTargetLevelUp=t=>this.OnTargetLevelUp(t),this._degf_UpdateAsuramIdHandle=t=>this.UpdateAsuramIdHandle(t),
this._degf_OnRemoveFriendTipsHandle=t=>this.OnRemoveFriendTipsHandle(t),this._degf_OnChuanGongInviteHandle=()=>this.OnChuanGongInviteHandle()}initPos(t){
this.panel.node.setPosition(t.x,t.y,0)}InitView(){this.model=b.X.Inst(),this.myInfo=o.Y.Inst.PrimaryRoleInfo_get()}OnAddToScene(){this.role=this.model.TargetRole_get(),
null!=this.role&&null!=this.role.Roleinfo_get()||(this.role=this.model.TempRole_get()),this.targetInfo=this.role.Roleinfo_get(),this.AddListeners(),this.SetData()}SetData(){
const t=this.targetInfo
this.playerName.textSet(t.Name_get())
const e=t.Level_get()
this.SetLevel(G.h.GetLevelStr(e))
const i=this.model.TotalBattleScore_get()
this.powlab.textSet(i+""),this.headIcon.spriteNameSet(E.Z.GetMainUIJobIcon(t.Job_get(),t.Sex_get()))
const s=P.f.Inst().getItemById(t.VipLevel_get())
let n=!1
D.l.IsEmptyStr(s.vipShow)?this.vipObj.node.SetActive(!1):(n=!0,this.vipObj.node.SetActive(!0),this.vipObj.spriteNameSet("atlas/mainui/"+s.vipShow))
const l=this.playerName.node.transform.GetLocalPosition()
l.x=n?66+this.vipObj.width():66,this.playerName.node.transform.SetLocalPosition(l),this.SetMenu()}SetLevel(t){this.level.textSet(G.h.GetLevelStr(t))}Clear(){this.model.isOnline=!0,
this.RemoveListeners()}AddListeners(){o.Y.Inst.PrimaryRoleInfo_get().AddEventHandlerRoleGlobal(h.A.AsuramIdUpdate,this._degf_UpdateAsuramIdHandle),
this.targetInfo.AddEventHandler(h.A.AsuramIdUpdate,this._degf_UpdateAsuramIdHandle),d.i.Inst.AddEventHandler(C.g.PLAYER_LEVELUP,this._degf_OnTargetLevelUp),
d.i.Inst.AddEventHandler(C.g.PLAYER_DIE,this._degf_OnPlayerDie),this.m_handlerMgr.AddClickEvent(this.closeMask,this._degf_OnClickClose),
this.m_handlerMgr.AddClickEvent(this.checkBtn,this._degf_OnCheckClick),this.m_handlerMgr.AddClickEvent(this.chatBtn,this._degf_OnChatClick),
this.m_handlerMgr.AddClickEvent(this.addFriendBtn,this._degf_OnAddFriendClick),this.m_handlerMgr.AddClickEvent(this.removeFriendBtn,this._degf_OnRemoveFriendClick),
this.m_handlerMgr.AddClickEvent(this.addBlackListBtn,this._degf_OnAddBlackListClick),this.m_handlerMgr.AddClickEvent(this.removeBlackListBtn,this._degf_OnRemoveBlackListClick),
this.m_handlerMgr.AddClickEvent(this.inviteAllyBtn,this._degf_OnInviteAllyClick),this.m_handlerMgr.AddClickEvent(this.changeAllianceJobBtn,this._degf_OnChangeJobClick),
this.m_handlerMgr.AddClickEvent(this.expelBtn,this._degf_OnExpelClick),this.m_handlerMgr.AddClickEvent(this.followLeaderBtn,this._degf_OnFollowBtnClick),
this.m_handlerMgr.AddClickEvent(this.cancelFollowBtn,this._degf_OnCancelFollowBtnClick),this.m_handlerMgr.AddClickEvent(this.changeLeaderBtn,this._degf_OnChangeLeaderBtnClick),
this.m_handlerMgr.AddClickEvent(this.expelTeamateBtn,this._degf_OnExpelTeamateBtnClick),this.m_handlerMgr.AddClickEvent(this.callTeamateBtn,this._degf_OnCallTeamateBtnClick),
this.m_handlerMgr.AddClickEvent(this.cancelCallBtn,this._degf_OnCancelCallBtnClick),this.m_handlerMgr.AddClickEvent(this.chuanGongInviteBtn,this._degf_OnChuanGongInviteHandle),
this.m_handlerMgr.AddClickEvent(this.reportBtn,this.CreateDelegate(this.OnReportBtn))}RemoveListeners(){
o.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandlerRoleGlobal(h.A.AsuramIdUpdate,this._degf_UpdateAsuramIdHandle),
d.i.Inst.RemoveEventHandler(C.g.PLAYER_LEVELUP,this._degf_OnTargetLevelUp),this.targetInfo.RemoveEventHandler(h.A.AsuramIdUpdate,this._degf_UpdateAsuramIdHandle),
d.i.Inst.RemoveEventHandler(C.g.PLAYER_DIE,this._degf_OnPlayerDie),this.m_handlerMgr.RemoveClickEvent(this.closeMask,this._degf_OnClickClose),
this.m_handlerMgr.RemoveClickEvent(this.checkBtn,this._degf_OnCheckClick),this.m_handlerMgr.RemoveClickEvent(this.chatBtn,this._degf_OnChatClick),
this.m_handlerMgr.RemoveClickEvent(this.addFriendBtn,this._degf_OnAddFriendClick),this.m_handlerMgr.RemoveClickEvent(this.removeFriendBtn,this._degf_OnRemoveFriendClick),
this.m_handlerMgr.RemoveClickEvent(this.addBlackListBtn,this._degf_OnAddBlackListClick),
this.m_handlerMgr.RemoveClickEvent(this.removeBlackListBtn,this._degf_OnRemoveBlackListClick),this.m_handlerMgr.RemoveClickEvent(this.inviteAllyBtn,this._degf_OnInviteAllyClick),
this.m_handlerMgr.RemoveClickEvent(this.changeAllianceJobBtn,this._degf_OnChangeJobClick),this.m_handlerMgr.RemoveClickEvent(this.expelBtn,this._degf_OnExpelClick),
this.m_handlerMgr.RemoveClickEvent(this.followLeaderBtn,this._degf_OnFollowBtnClick),this.m_handlerMgr.RemoveClickEvent(this.cancelFollowBtn,this._degf_OnCancelFollowBtnClick),
this.m_handlerMgr.RemoveClickEvent(this.changeLeaderBtn,this._degf_OnChangeLeaderBtnClick),
this.m_handlerMgr.RemoveClickEvent(this.expelTeamateBtn,this._degf_OnExpelTeamateBtnClick),this.m_handlerMgr.RemoveClickEvent(this.callTeamateBtn,this._degf_OnCallTeamateBtnClick),
this.m_handlerMgr.RemoveClickEvent(this.cancelCallBtn,this._degf_OnCancelCallBtnClick),
this.m_handlerMgr.RemoveClickEvent(this.chuanGongInviteBtn,this._degf_OnChuanGongInviteHandle)}OnPressClose(t,e){x.Y.Inst().Close()}OnClickClose(t){t.preventSwallow=!0,
x.Y.Inst().Close(!1,!0)}OnTargetLevelUp(t){const e=t
null!=e&&e.playerId.Equal(this.model.RoleId_get())&&this.SetLevel(e.level)}OnPlayerDie(t){const e=t
null!=e&&e.objId.Equal(this.model.RoleId_get())&&null!=o.Y.Inst.getRoleById(e.objId)&&x.Y.Inst().Close()}SetMenu(){this.grid.node.SetActive(!0)
let t=0
this.checkBtn.node.SetActive(!1),this.chatBtn.node.SetActive(!1),this.inviteAllyBtn.node.SetActive(!1),this.addFriendBtn.node.SetActive(!1),this.removeFriendBtn.node.SetActive(!1),
this.addBlackListBtn.node.SetActive(!1),this.removeBlackListBtn.node.SetActive(!1),this.changeAllianceJobBtn.node.SetActive(!1),this.expelBtn.node.SetActive(!1),
this.followLeaderBtn.node.SetActive(!1),this.cancelFollowBtn.node.SetActive(!1),this.changeLeaderBtn.node.SetActive(!1),this.expelTeamateBtn.node.SetActive(!1),
this.callTeamateBtn.node.SetActive(!1),this.cancelCallBtn.node.SetActive(!1),this.chuanGongInviteBtn.node.SetActive(!1),this.serverdesc.node.SetActive(!1),
this.asuramDesc.node.SetActive(!1),this.reportBtn.SetActive(!1)
const e=this.myInfo.Server_get()!=this.targetInfo.Server_get()
if(e&&(this.asuramDesc.node.SetActive(!0),null==this.targetInfo.AsuramId_get()||this.targetInfo.AsuramId_get().Equal(N.I.zeroLong)?this.asuramName.textSet((0,
r.T)("无")):this.asuramName.textSet(this.targetInfo.AllianceName_get())),this.myInfo.Id_get().Equal(this.targetInfo.Id_get())||(this.checkBtn.node.SetActive(!0),t+=1,
this.targetInfo.isRobot||e||(this.chatBtn.node.SetActive(!0),t+=1)),!e){if(this.asuramDesc.node.SetActive(!0),
this.myInfo.Id_get().Equal(this.targetInfo.Id_get()))return null==this.targetInfo.AsuramId_get()||this.targetInfo.AsuramId_get().Equal(N.I.zeroLong)?this.asuramName.textSet((0,
r.T)("无")):this.asuramName.textSet(this.targetInfo.AllianceName_get()),this.bg.heightSet(60*c.GF.INT((t+1)/2)+145),void this.grid.Reposition()
if(null==this.targetInfo.AsuramId_get()||this.targetInfo.AsuramId_get().Equal(N.I.zeroLong))this.asuramName.textSet((0,r.T)("无")),
null!=this.targetInfo.ServerName_get()&&this.myInfo.ServerName_get()!=this.targetInfo.ServerName_get()||null==this.myInfo.AsuramId_get()||this.myInfo.AsuramId_get().Equal(N.I.zeroLong)||this.myInfo.AllianceJob_get()<4&&(this.inviteAllyBtn.node.SetActive(!0),
t+=1)
else{this.asuramName.textSet(this.targetInfo.AllianceName_get())
const e=w.D.getInstance().GetIntValue("ASURAM_LEVEL_GRADE"),i=this.targetInfo.Level_get()-this.myInfo.Level_get()
let s
this.model.isFromAsuram&&(s=S.Q.Inst_get().ShowChuanGongInviteBtn(this.targetInfo.Id_get())),
null==s&&Math.abs(i)>=e&&R.H.Inst_get().ChuanGongOpen&&O.L.GetInst().IsInAllianceScene()&&(s=!0),s&&(this.chuanGongInviteBtn.node.SetActive(!0),t+=1)}if(this.model.isFromAsuram){
const e=S.Q.Inst_get().checkMemberInfo
this.myInfo.AllianceJob_get()<4&&this.myInfo.AllianceJob_get()<e.job&&(this.changeAllianceJobBtn.node.SetActive(!0),this.expelBtn.node.SetActive(!0),t+=2,
this.model.isFromAsuram=!1)}if(null==this.targetInfo.ServerName_get()||this.myInfo.ServerName_get()==this.targetInfo.ServerName_get()){let t=this.targetInfo.mainroleId_get()
I.o.IsNullOrZero(t)&&(t=this.targetInfo.Id_get())}}this.bg.heightSet(60*c.GF.INT((t+1)/2)+145),this.grid.Reposition()}UpdateAsuramIdHandle(t){this.model.canOperate&&this.SetMenu()}
OnCheckClick(t,e){
2==b.X.Inst().queryType?V.Z.Inst().Open(this.role.GetGameId(),1,null,null,b.X.Inst().accountIdx,2):V.Z.Inst().Open(this.role.GetGameId(),1,null,null,b.X.Inst().accountIdx,0)}
OnChatClick(t,e){this.CheckTargetRoleInfo()&&f.d.Inst_get().controller.PrivateChatRoleInfo(this.targetInfo,b.X.Inst().isOnline),x.Y.Inst().Close()}OnAddFriendClick(t,e){
if(this.CheckTargetRoleInfo()){let t=this.targetInfo.mainroleId_get()
I.o.IsNullOrZero(t)&&(t=this.targetInfo.Id_get()),M.N.Inst_get().ReqAddFriend(t)}x.Y.Inst().Close()}OnRemoveFriendClick(t,e){const i=new H.N
i.showText=(0,r.T)(`是否确认和${this.targetInfo.Name_get()}解除好友关系`),i.okhandler=this._degf_OnRemoveFriendTipsHandle,i.tipstype=2,F.y.inst.OpenCommonMessageTips(i)}
OnChuanGongInviteHandle(){O.L.GetInst().ReqCM_InvitePass(this.targetInfo.Id_get())}OnRemoveFriendTipsHandle(t){if(this.CheckTargetRoleInfo()){let t=this.targetInfo.mainroleId_get()
I.o.IsNullOrZero(t)&&(t=this.targetInfo.Id_get()),M.N.Inst_get().ReqRemoveFriend(t)}x.Y.Inst().Close()}OnAddBlackListClick(t,e){
this.CheckTargetRoleInfo()&&M.N.Inst_get().ReqBlackFriend(this.targetInfo),x.Y.Inst().Close()}OnRemoveBlackListClick(t,e){if(0==this.CheckTargetRoleInfo()){
let t=this.targetInfo.mainroleId_get()
I.o.IsNullOrZero(t)&&(t=this.targetInfo.Id_get()),M.N.Inst_get().ReqUnBlack(t),x.Y.Inst().Close()}}OnReportBtn(){
this.CheckTargetRoleInfo()&&x.Y.Inst().OpenReportPanel(this.targetInfo)}OnTradeClick(t){x.Y.Inst().Close()}OnInviteAllyClick(t,e){
this.CheckTargetRoleInfo()&&m.K.Inst().InviteIntoAsuramReq(this.targetInfo.Id_get()),x.Y.Inst().Close()}OnApplyIntoAllyClick(t,e){if(this.CheckTargetRoleInfo()){const t=new v.$
t.asuramId=this.targetInfo.AsuramId_get(),_.C.Inst.F_SendMsg(t)}x.Y.Inst().Close()}OnChangeJobClick(t,e){p.D.Inst().Open(),x.Y.Inst().Close()}OnExpelClick(t,e){
const i=S.Q.Inst_get().checkMemberInfo,s="ASURAM:KICK_OUT_CONFIRM"
if(B.V.Inst_get().GetData(B.V.Inst_get().GetRolePrefix()+s))this.OnConfirmClick(i.id)
else{L.L.Inst().getItemById(s)
const t=new y.B
t.infoId=s,t.replaceParams.Add(T.k.inst.GetFSName(i.name,i.newTitleLevel)),t.confirmHandle=this._degf_OnConfirmClick,t.confirmParam=i.id,A.t.Inst().Open(t)}x.Y.Inst().Close()}
OnFollowBtnClick(t,e){x.Y.Inst().Close()}OnCancelFollowBtnClick(t,e){o.Y.Inst.PrimaryRole_get().StopPathing(),x.Y.Inst().Close()}OnChangeLeaderBtnClick(t,e){x.Y.Inst().Close()}
OnExpelTeamateBtnClick(t,e){x.Y.Inst().Close()}OnCallTeamateBtnClick(t,e){x.Y.Inst().Close()}OnCancelCallBtnClick(t,e){x.Y.Inst().Close()}OnConfirmClick(t){const e=t,i=new U.q
i.firePlayerId=e,_.C.Inst.F_SendMsg(i)
const s=new k.H
_.C.Inst.F_SendMsg(s)}CheckTargetRoleInfo(){return null!=this.targetInfo}})},30635:(t,e,i)=>{i.d(e,{Y:()=>R})
var s=i(32076),n=i(5494),l=i(98800),a=i(56937),r=i(31222),o=i(52726),h=i(98789),d=i(17409),_=i(84581),u=i(97461),I=i(19176),c=i(38935),g=i(18202),p=i(995),m=i(30627),S=i(92679),T=i(85770),f=i(72800),C=i(29743),E=i(88883),A=i(54383),L=i(71191),y=i(22259),D=i(44744),O=i(33542)
class R{static Inst(){return null==R._inst&&(R._inst=new R),R._inst}constructor(){this.headPanel=null,this.targetPanel=null,this.targetHeadPanel=null,this.model=null,
this._degf_CallDestoryHeadPanel=null,this._degf_CallDestroy=null,this._degf_CallTargetHeadDestroy=null,this._degf_ShowHandler=null,this._degf_ShowHeadPanelHandler=null,
this._degf_ShowTargetHeadPanelHandler=null,this.reportPlayerinfo=null,this._degf_CallDestoryHeadPanel=()=>this.CallDestoryHeadPanel(),this._degf_CallDestroy=()=>this.CallDestroy(),
this._degf_CallTargetHeadDestroy=()=>this.CallTargetHeadDestroy(),this._degf_ShowHandler=t=>this.ShowHandler(t),this._degf_ShowHeadPanelHandler=t=>this.ShowHeadPanelHandler(t),
this.model=O.X.Inst()}UpdateBuffList(){}TargetPanel_get(){return this.targetPanel}checkTargetPanel(t){
null!=O.X.Inst().TargetRole_get()&&O.X.Inst().TargetRole_get().GetGameId().Equal(t.GetGameId())&&this.Open()}checkTargetPanelByPkmodel(){if(null!=O.X.Inst().TargetRole_get()){
const t=l.Y.Inst.getCharacterById(O.X.Inst().TargetRole_get().objId)
null!=t&&(O.X.Inst().TargetRole_set(t),this.Open())}}Open(t){const e=O.X.Inst().TargetRole_get()
let i=!0
if(null!=e&&null!=e.Roleinfo_get()&&(i=e.isInSafeArea),I.S.getInst().isInSafeArea||i)this.OpenBottomHead()
else{const t=A.k.Inst_get().pkModel,i=l.Y.Inst.PrimaryRoleInfo_get()
if(t==E.j.PEACE_MODEL){A.k.Inst_get().IsExistPkList(e.objId)?this.OpenTargetHeadPanel():this.OpenBottomHead()}else if(t==E.j.GUILD_MODEL){
i.AsuramId_Equip(e.Roleinfo_get().AsuramId_get())?this.OpenBottomHead():this.OpenTargetHeadPanel()
}else t==E.j.ASURAM_WAR_CAMP?this.OpenBottomHead():t==E.j.SLAUGHTER_MODEL&&this.OpenTargetHeadPanel()}}OpenBottomHead(){
if(!D.Z.Inst().IsTopPanelShow()&&null!=this.model.TargetRole_get()&&null!=this.model.TargetRole_get().Roleinfo_get()&&this.model.TargetRole_get()==l.Y.Inst.CurTarget_get()&&!l.Y.Inst.PrimaryRoleInfo_get().Id_get().Equal(this.model.TargetRole_get().Roleinfo_get().Id_get())){
if(null!=this.headPanel&&this.headPanel.isShow_get())null==this.model.preRoleId||this.model.preRoleId.Equal(this.model.RoleId_get())||this.headPanel.OnAddToScene()
else{const t=new a.v
t.layerType=o.F.Alert,t.positionType=h.$.eBottom,r.N.inst.OpenById(n.I.eTargetPlayerHeadPanel,this._degf_ShowHeadPanelHandler,this._degf_CallDestoryHeadPanel,t)}
this.CloseTargetHead()}}OpenOperationPanel(t){
if(null==t&&(t=0),null!=this.targetPanel&&this.targetPanel.isShow_get())this.model.preRoleId.Equal(this.model.RoleId_get())||(this.targetPanel.OnAddToScene(),
this.InitMainPanelPos())
else{const e=new a.v
e.layerType=o.F.Tip,1==t&&(e.positionType=h.$.eCustom,e.pos=this.model.openPos.Clone()),(0,d.Yp)(n.I.TargetPlayerPanelId,e,(0,s.v)(this.rePositionPanel,this))}this.CloseHeadPanel()
}rePositionPanel(){const t=D.Z.Inst().mainPanelPos,e=(0,d.Y)(n.I.TargetPlayerPanelId)
e&&t&&e.initPos(t)}CloseOperationPanel(){(0,d.sR)(n.I.TargetPlayerPanelId)}OpenTargetHeadPanel(){
if(T.a.Inst_get().curCopyType==f.S.Arena||T.a.Inst_get().curCopyType==f.S.MineRob||T.a.Inst_get().curCopyType==f.S.NORMAL_CROSS_ARENA||T.a.Inst_get().curCopyType==f.S.PEAK_CROSS_ARENA)return
if(D.Z.Inst().IsTopPanelShow())return
const t=l.Y.Inst.CurTarget_get()
if(null!=t&&(t.roletype==_.s.role||t.roletype==_.s.monster&&t.isBoss())||(this.CloseHeadPanel(),m.t.Inst().DelayClose()),u.i.Inst.RaiseEvent(S.g.OnBloodBarOpen,null,5),
this.targetHeadPanel=(0,d.Y)(n.I.eTargetPlayerHead),null==this.targetHeadPanel){const t=new a.v
t.layerType=o.F.DefaultUI,t.positionType=h.$.eTop,t.aniDir=p.K.Up,r.N.inst.OpenById(n.I.eTargetPlayerHead,this._degf_ShowTargetHeadPanelHandler,this._degf_CallTargetHeadDestroy,t)
}else this.targetHeadPanel.OnAddToScene()}IsOpen(){return!(null==this.targetPanel||!this.targetPanel.isShow_get())}CloseHeadPanel(){
null!=this.headPanel&&r.N.inst.ClosePanel(this.headPanel)}Close(t,e){null==e&&(e=!1),null==t&&(t=!1),(0,d.qJ)(n.I.TargetPlayerPanelId)&&(0,d.sR)(n.I.TargetPlayerPanelId),(0,
d.sR)(n.I.eTargetPlayerHeadPanel),t&&l.Y.Inst.setCurTarget(null),this.targetHeadPanel=null}CallDestroy(){null!=this.targetPanel&&(g.g.DestroyUIObj(this.targetPanel),
this.targetPanel=null)}CallDestoryHeadPanel(){null!=this.headPanel&&(g.g.DestroyUIObj(this.headPanel),this.headPanel=null)}InitMainPanelPos(){const t=D.Z.Inst().mainPanelPos
this.targetPanel&&t&&this.targetPanel.node.transform.SetLocalPosition(t)}ShowHandler(t){return this.targetPanel}ShowHeadPanelHandler(t){return this.headPanel=new y.b(null),
this.headPanel.setId(t,null,0),this.headPanel}ShowTargetHeadPanelHandler(t){return this.targetHeadPanel}CallTargetHeadDestroy(){}CloseTargetHead(){(0,d.sR)(n.I.eTargetPlayerHead),
this.targetHeadPanel=null,u.i.Inst.RaiseEvent(S.g.OnBloodBarClose,null,5)}OpenReportPanel(t){this.reportPlayerinfo=t
const e=new a.v
e.viewClass=L.n,e.layerType=o.F.Tip,e.isShowMask=!0,r.N.inst.OpenById(n.I.ReportPlayerPanel,null,null,e)}ReportPlayer_Set(t){this.reportPlayerinfo=t}CM_ReportPlayer(t,e,i){
const s=new C.k
s.reportPlayerId=t,s.reportType=e,s.reportDesc=i,c.C.Inst.F_SendMsg(s)}}R._inst=null},41825:(t,e,i)=>{i.d(e,{e:()=>Tt})
var s=i(42292),n=i(71409),l=i(32076),a=i(97461),r=i(13687),o=i(38935),h=i(56937),d=i(31222),_=i(5494),u=i(49484),I=i(52726),c=i(995),g=i(47465),p=i(92679),m=i(55492),S=i(4645),T=i(19183),f=i(52396),C=i(14792),E=i(62734),A=i(57651),L=i(81599),y=i(5924),D=i(99294),O=i(61911)
class R extends O.f{constructor(...t){super(...t),this.pre_eff_sh_uitx_07=null,this.pre_eff_common_script_01=null,this.interval_eff_delay=null,this.interval_eff=null}InitView(){
super.InitView(),this.pre_eff_sh_uitx_07=this.CreateComponent(D.z,1),this.pre_eff_common_script_01=this.CreateComponent(D.z,2)}OnAddToScene(){
this.interval_eff_delay=y.C.Inst_get().SetInterval((()=>{this.pre_eff_sh_uitx_07.SetActive(!1),this.pre_eff_common_script_01.SetActive(!1),this.pre_eff_sh_uitx_07.SetActive(!0),
this.pre_eff_common_script_01.SetActive(!0)}),400,1),this.interval_eff=y.C.Inst_get().SetInterval((()=>{Tt.ins.CloseFinishEffectPanel()}),2100,1)}AddLis(){}RemoveLis(){}Clear(){
super.Clear(),this.pre_eff_sh_uitx_07.SetActive(!1),this.pre_eff_common_script_01.SetActive(!1),
null!=this.interval_eff_delay&&(y.C.Inst_get().ClearInterval(this.interval_eff_delay),this.interval_eff_delay=null),
null!=this.interval_eff&&(y.C.Inst_get().ClearInterval(this.interval_eff),this.interval_eff=null),Tt.ins.ClosePanel()}Destroy(){super.Destroy()}}
var N=i(86133),M=i(68662),w=i(9986),P=i(93877),v=i(72005),k=i(35128),U=i(87923),G=i(79878),F=i(99535)
class B extends O.f{constructor(...t){super(...t),this.link_info=null,this.text_time=null,this.btn_close=null,this.text_content=null,this.btn_go=null,this.interval=null}InitView(){
super.InitView(),this.text_time=this.CreateComponent(P.Q,1),this.btn_close=this.CreateComponent(v.w,2),this.text_content=this.CreateComponent(P.Q,3),
this.btn_go=this.CreateComponent(w.W,4)}OnAddToScene(){this.AddLis(),this.ClearInterval(),this.interval=y.C.Inst_get().SetInterval(this.CreateDelegate(this.OnEachSec),1e3),
this.UpdatePanel(),this.OnEachSec()}AddLis(){this.m_handlerMgr.AddClickEvent(this.btn_close,this.CreateDelegate(this.OnClickBtnClose)),
this.m_handlerMgr.AddClickEvent(this.btn_go,this.CreateDelegate(this.OnClickBtnGo))}RemoveLis(){}Clear(){super.Clear(),this.ClearInterval(),
null!=this.link_info&&(this.link_info.Clear(),this.link_info=null)}Destroy(){super.Destroy()}UpdatePanel(){null!=this.link_info&&(this.link_info.Clear(),this.link_info=null),
this.link_info=G.Y.GetLinkInfo(F.O.Inst_get().GetTaskById(L.$.ins.contract_task_info.questId)),this.text_content.textSet(this.link_info.GetTxtLabel())}OnClickBtnGo(){
G.Y.DoGoTaskStep(F.O.Inst_get().GetTaskById(L.$.ins.contract_task_info.questId)),Tt.ins.CloseTaskContractInfoPanel()}OnClickBtnClose(){Tt.ins.CloseTaskContractInfoPanel()}
ClearInterval(){-1!=this.interval&&(y.C.Inst_get().ClearInterval(this.interval),this.interval=-1)}OnEachSec(){
if(null==L.$.ins.contract_task_info)return void Tt.ins.CloseTaskContractInfoPanel()
const t=k.p.FloorToInt(L.$.ins.contract_task_info.endTime.ToNum()/1e3)-M.D.serverTime_get()
t>0?this.text_time.textSet(U.l.GetDateFormatBitContainZero(t,3)):(this.text_time.textSet((0,N.T)("已过期")),Tt.ins.CloseTaskContractInfoPanel())}IsFirstPanel_Get(){return!0}}
var H=i(62370),V=i(6665),b=i(63062),x=i(32759),q=i(8889),Y=i(98885),K=i(85602),J=i(79534),Q=i(75696),Z=i(67885),X=i(18152),$=i(53905),W=i(65772),j=i(75439),z=i(98580),tt=i(74657),et=i(9057)
class it extends et.x{constructor(...t){super(...t),this.img_finish=null,this.text_desc=null,this.btn_get=null,this.btn_go=null,this.img_red=null,this.text_get=null,
this.text_name=null,this.text_point=null,this.img_diamond=null,this.img_bg=null,this.price_obj=null,this.task=null,this.link_info=null}InitView(){super.InitView(),
this.img_finish=this.CreateComponent(LuaUISprite,1),this.text_desc=this.CreateComponent(LuaUILabel,4),this.btn_get=this.CreateComponent(LuaMyUIButton,5),
this.btn_go=this.CreateComponent(LuaMyUIButton,6),this.img_red=this.CreateComponent(LuaUISprite,12),this.text_get=this.CreateComponent(LuaUILabel,14),
this.text_name=this.CreateComponent(LuaUILabel,15),this.text_point=this.CreateComponent(LuaUILabel,16),this.img_diamond=this.CreateComponent(LuaUISprite,17),
this.img_bg=this.CreateComponent(LuaUISprite,18),this.price_obj=this.CreateComponent(LuaGameObject,19)}SetData(t){this.AddLis(),this.task=t,this.UpdateTask()}UpdateTask(){
null!=this.link_info&&(this.link_info.Clear(),this.link_info=null),this.link_info=TaskUtil.GetLinkInfo(this.task),this.img_finish.node.SetActive(!1),this.btn_go.node.SetActive(!1),
this.btn_get.node.SetActive(!1),this.img_red.node.SetActive(!1),this.img_bg.spriteNameSet("rycommon_sp_0128"),
TaskViewManager.Inst_get().model.IsTaskCompleted(this.task.id_get())?(this.img_finish.node.SetActive(!0),
this.img_bg.spriteNameSet("rycommon_sp_0127")):this.task.status_get()==MyTaskStatus.ACCEPTED?this.btn_go.node.SetActive(!0):this.task.status_get()==MyTaskStatus.FINISHED&&(this.btn_get.node.SetActive(!0),
this.task.resource_get().intersectionType==TaskResourceConst.INTERSECTION_NPC?this.text_get.textSet(gettextRy("前往交付")):this.text_get.textSet(gettextRy("领取奖励")),
this.img_red.node.SetActive(!0)),this.text_name.textSet(this.task.taskName_get())
let t=""
if(TaskViewManager.Inst_get().model.IsTaskCompleted(this.task.id_get())){t=StringProxy.Split(this.task.resource_get().underwayText,GameStringProxy.s_Arr_UNDER_CHAR_DOLL)[4]
}else t=this.link_info.GetTxtLabel()
const e=this.task.tCTargetDefs_get().tCTargetDefs[0].value
let i=0
TaskViewManager.Inst_get().model.IsTaskCompleted(this.task.id_get())?i=e:null!=this.task.qVo&&(i=this.task.qVo.targets[0].value_get()),i>e&&(i=e)
let s="047104"
i<e&&(s="962424")
const n=GameStringProxy.Format(gettextRy("[{0}]({1}/{2})[-]"),s,CommonUtil.GetPurseVOChineseString(i),CommonUtil.GetPurseVOChineseString(e))
if(this.text_desc.textSet(`${t}\n${n}`),this.img_diamond.node.SetActive(!1),this.text_point.textSet(""),
null!=this.task.showRewardResult_get()&&this.task.showRewardResult_get().GetAllRewardList().Count()>0){const t=this.task.showRewardResult_get().GetAllRewardList()
for(let e=0;e<=t.Count()-1;e++)t[e].modelId_get()==ObtainConst.DIAMOND_ID&&(this.img_diamond.node.SetActive(!0),this.text_point.textSet(t[e].count))}}AddLis(){
this.m_handlerMgr.AddClickEvent(this.btn_go,this.CreateDelegate(this.OnClickBtnGo)),this.m_handlerMgr.AddClickEvent(this.btn_get,this.CreateDelegate(this.OnClickBtnGet)),
TaskViewManager.Inst_get().model.AddEventHandler(TaskViewEventConst.INFORM_DO_UPDATA,this.CreateDelegate(this.OnTaskChange))}RemoveLis(){
this.m_handlerMgr.RemoveClickEvent(this.btn_go,this.CreateDelegate(this.OnClickBtnGo)),this.m_handlerMgr.RemoveClickEvent(this.btn_get,this.CreateDelegate(this.OnClickBtnGet)),
TaskViewManager.Inst_get().model.RemoveEventHandler(TaskViewEventConst.INFORM_DO_UPDATA,this.CreateDelegate(this.OnTaskChange))}Clear(){super.Clear(),this.RemoveLis(),
null!=this.link_info&&(this.link_info.Clear(),this.link_info=null)}Destroy(){super.Destroy()}OnClickBtnGo(){
CommonUtil.CheckTrigger(GameConditionType.COND_TYPE_TASK_CLICK_VAL,this.task.id_get(),0),TaskUtil.GetLinkInfo(this.task),TaskClickTrigger.inst.GotoTrigger(this.task),
RebirthControl.ins.ClosePanel()}OnClickBtnGet(){
if(this.task.resource_get().intersectionType==TaskResourceConst.INTERSECTION_NPC)CommonUtil.CheckTrigger(CommonConst.COND_TYPE_TASK_CLICK,this.task.id_get(),0),
TaskClickTrigger.inst.GotoTrigger(this.task),RebirthControl.ins.ClosePanel()
else{if(BagModel.Inst_get().emptySize_get()<1)return void SystemTipsControl.inst.ClientSysMessage(102509)
const t=new Vector3,e=this.btn_get.node.transform.TransformPoint(t)
LuaEventMgr.Inst.RaiseEvent(CommonEventType.TASKCONTRACT_CLICK_GET_POINT,e),Vector3.Recyle(t),TaskUtil.SendToServer(this.task)}}OnTaskChange(t){
null!=this.task&&t.id_get()!=this.task.id_get()||this.UpdateTask()}}class st extends O.f{constructor(...t){super(...t),this.img_girl=null,this.ui_baseitem=null,this.btn_close=null,
this.text_time=null,this.con_point=null,this.scroll_task=null,this.grid_task=null,this.btn_tip=null,this.text_pro=null,this.bar_point=null,this.img_bar_bg=null,this.img_bar=null,
this.effect_panel=null,this.tween_point=null,this.text_wcd=null,this.interval=null,this.showTaskList=null,this.intervalFinish=null}InitView(){super.InitView(),
this.img_girl=this.CreateComponent(v.w,1),this.ui_baseitem=this.CreateComponentBinder(Q.j,2),this.btn_close=this.CreateComponent(w.W,3),this.text_time=this.CreateComponent(P.Q,4),
this.con_point=this.CreateComponent(D.z,5),this.scroll_task=this.CreateComponent(q.$,6),this.grid_task=this.CreateComponent(V.A,7),this.btn_tip=this.CreateComponent(v.w,8),
this.text_pro=this.CreateComponent(P.Q,9),this.bar_point=this.CreateComponent(b.p,10),this.img_bar_bg=this.CreateComponent(v.w,11),this.img_bar=this.CreateComponent(v.w,12),
this.effect_panel=this.CreateComponent(q.$,13),this.tween_point=this.CreateComponent(x.c,14),this.text_wcd=this.CreateComponent(P.Q,15),
this.grid_task.SetInitInfo("ui_task_contract_item",null,it)}OnAddToScene(){this.AddLis(),this.ClearInterval(),
this.interval=y.C.Inst_get().SetInterval(this.CreateDelegate(this.OnEachSec),1e3),this.UpdatePanel(),this.OnEachSec()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.btn_close,this.CreateDelegate(this.OnClickBtnClose)),this.m_handlerMgr.AddClickEvent(this.btn_tip,this.CreateDelegate(this.OnClickBtnTip)),
this.m_handlerMgr.AddEventMgr(p.g.TASKCONTRACT_CLICK_GET_POINT,this.CreateDelegate(this.OnClickGetPoint)),
this.m_handlerMgr.AddEventMgr(p.g.TASKCONTRACT_CHANGE_INFO,this.CreateDelegate(this.UpdateReward)),this.ui_baseitem.ClickHandler_Set(this.CreateDelegate(this.OnClick))}RemoveLis(){
this.ui_baseitem.ClickHandler_Set(null)}Clear(){super.Clear(),this.ClearInterval(),this.RemoveLis()}Destroy(){super.Destroy()}UpdatePanel(){const t=L.$.ins.GetContractTaskList()
null!=t?(this.showTaskList=new K.Z,this.showTaskList.AddRange(t),this.showTaskList.Sort(this.CreateDelegate(this.SortByTask)),this.grid_task.data_set(this.showTaskList),
this.UpdateReward(),this.UpdateBar()):Tt.ins.ClosePanel()}SortByTask(t,e){let i=0,s=0
return t.status_get()==z.B.FINISHED?i=1e9:t.status_get()==z.B.ACCEPTED&&(i=1e6),e.status_get()==z.B.FINISHED?s=1e9:e.status_get()==z.B.ACCEPTED&&(s=1e6),
s-e.resource_get().sort-(i-t.resource_get().sort)}UpdateReward(){
const t=j.D.getInstance().GetStringValue("CONTRACT:ULTIMATE_PRIZE"),e=Y.M.Split(t,H.o.s_Arr_UNDER_COLON),i=Y.M.Split(e[0],H.o.s_Arr_UNDER_CHAR_DOT),s=e[1]
if(-1!=i.IndexOf(Y.M.IntToString(this.showTaskList[0].id_get()))){this.ui_baseitem.node.SetActive(!0),this.ui_baseitem.EnabledClickOpenTip(!1)
const t=tt.A.GetReward(s).GetBaseItemList()[0]
t.iconExtraData[Z.S.GRAY_IMG]=null,t.iconExtraData[Z.S.GET_EFFECT]=!1,t.IconType_Set(X.s.BASE_ICON_REWARD_TYPE),
1==L.$.ins.series_info.contractRewardStatus?t.iconExtraData[Z.S.GET_EFFECT]=!0:2==L.$.ins.series_info.contractRewardStatus&&(t.iconExtraData[Z.S.GRAY_IMG]="已领取"),
this.ui_baseitem.SetData(t)}else{this.ui_baseitem.node.SetActive(!1)
let t=0
for(let e=0;e<=this.showTaskList.Count()-1;e++)F.O.Inst_get().IsTaskCompleted(this.showTaskList[e].id_get())&&(t+=1)
t>=this.showTaskList.Count()&&this.PlayRewardEff()}}UpdateBar(){let t=0
for(let e=0;e<=this.showTaskList.Count()-1;e++)F.O.Inst_get().IsTaskCompleted(this.showTaskList[e].id_get())&&(t+=1)
this.text_pro.textSet(H.o.Format((0,N.T)("{0}/{1}"),t,this.showTaskList.Count())),this.bar_point.DoF_SetValueEx(t,this.showTaskList.Count())}OnClickGetPoint(t){
this.tween_point.node.SetActive(!0)
const e=new J.P(this.img_bar.width(),0,0)
let i=this.img_bar.node.transform.TransformPoint(e)
i=this.node.transform.InverseTransformPoint(i)
const s=this.node.transform.InverseTransformPoint(t)
this.tween_point.AddEventHandler(this.CreateDelegate(this.OnTweenPointEnd)),this.tween_point.SetFrom(s),this.tween_point.SetTo(i),this.tween_point.ResetToBeginning(),
this.tween_point.PlayForward(),J.P.Recyle(s),J.P.Recyle(i)}OnClick(){let t=0
for(let e=0;e<=this.showTaskList.Count()-1;e++)F.O.Inst_get().IsTaskCompleted(this.showTaskList[e].id_get())&&(t+=1)
t>=this.showTaskList.Count()?(Tt.ins.CM_AcceptContractReward(),this.PlayRewardEff()):this.ui_baseitem.OpenTipView()}PlayRewardEff(){
null==this.intervalFinish&&(this.intervalFinish=y.C.Inst_get().SetInterval((()=>{Tt.ins.OpenFinishEffectPanel()}),1e3,1))}OnTweenPointEnd(){
this.tween_point.RemoveEventHandler(this.CreateDelegate(this.OnTweenPointEnd)),this.tween_point.node.SetActive(!1),this.UpdatePanel()}OnClickBtnClose(){Tt.ins.ClosePanel()}
OnClickBtnTip(){const t=new $.w
t.infoId="CONTRACT:TIPS",t.width=360
let e=this.btn_tip.node.transform.TransformPoint(J.P.zero_get())
const i=d.N.inst.GetViewById(_.I.eTaskContractPanel)
null!=i&&(e=i.node.transform.InverseTransformPoint(e)),t.position=new J.P(e.x,e.y,0),W.Q.Inst_get().Open(t)}ClearInterval(){
-1!=this.interval&&(y.C.Inst_get().ClearInterval(this.interval),this.interval=-1),null!=this.intervalFinish&&(y.C.Inst_get().ClearInterval(this.intervalFinish),
this.intervalFinish=null)}OnEachSec(){if(null==L.$.ins.series_info)return void Tt.ins.ClosePanel()
const t=k.p.FloorToInt(L.$.ins.series_info.seriesEndTime.ToNum()/1e3)-M.D.serverTime_get()
t>0?this.text_time.textSet(U.l.GetDateFormatBitContainZero(t,3)):this.text_time.textSet((0,N.T)("已过期"))}}var nt=i(47786)
class lt extends O.f{constructor(...t){super(...t),this.btn_recover=null,this.btn_continue=null,this.btn_close=null,this.text_desc=null}InitView(){super.InitView(),
this.btn_recover=this.CreateComponent(w.W,1),this.btn_continue=this.CreateComponent(w.W,2),this.btn_close=this.CreateComponent(w.W,3),this.text_desc=this.CreateComponent(P.Q,4)}
OnAddToScene(){this.text_desc.textSet(nt.x.Inst().getItemStrById(11041804)),this.AddLis()}AddLis(){this.m_handlerMgr.AddClickEvent(this.btn_close,this.CreateDelegate(this.Close)),
this.m_handlerMgr.AddClickEvent(this.btn_continue,this.CreateDelegate(this.OnClickBtnContinue)),
this.m_handlerMgr.AddClickEvent(this.btn_recover,this.CreateDelegate(this.OnClickBtnRecover))}RemoveLis(){}Clear(){super.Clear()}Destroy(){super.Destroy()}OnClickBtnContinue(){
Tt.ins.CloseRecoverPanel(),Tt.ins.OpenTaskContractSelectEndPanel()}OnClickBtnRecover(){this.Close(),Tt.ins.OpenTaskContractSelectPanel()}Close(){L.$.ins.select_task_id=0,
Tt.ins.CloseRecoverPanel()}}class at extends et.x{constructor(...t){super(...t),this.taskId=0,this.on_click_select=null,this.btn_select=null,this.text_content_0=null,
this.grid_item=null,this.img_task_bg=null,this.text_content_2=null}InitView(){super.InitView(),this.btn_select=this.CreateComponent(w.W,1),
this.text_content_0=this.CreateComponent(P.Q,2),this.grid_item=this.CreateComponent(V.A,4),this.img_task_bg=this.CreateComponent(v.w,5),
this.text_content_2=this.CreateComponent(P.Q,6),this.grid_item.SetInitInfo("ui_baseitem",null,Q.j)}SetData(t){this.AddLis(),this.taskId=t
const e=F.O.Inst_get().GetTaskById(this.taskId),i=L.$.ins.GetStartTaskDesc()[`${this.taskId}`]
this.text_content_0.textSet(Y.M.Split(i,"_")[0]),this.text_content_2.textSet(Y.M.Split(i,"_")[1])
const s=e.showRewardResult_get().GetJobLimitItemList(),n=L.$.ins.GetStartTaskList().IndexOf(this.taskId)
this.img_task_bg.spriteNameSet(at.TASK_BG_LIST[n]),this.grid_item.data_set(s),this.grid_item.node.transform.SetLocalPositionXYZ(-(94*s.Count()-20)/2,-105,0)}AddLis(){
this.m_handlerMgr.AddClickEvent(this.btn_select,this.CreateDelegate(this.OnClickBtnSelect))}RemoveLis(){}Clear(){super.Clear(),this.RemoveLis(),this.on_click_select=null}Destroy(){
super.Destroy()}OnClickBtnSelect(){null==this.on_click_select?(L.$.ins.select_task_id=this.taskId,Tt.ins.CloseTaskContractSelectPanel(),
Tt.ins.OpenTaskContractSelectEndPanel()):this.on_click_select()}}at.TASK_BG_LIST=new K.Z(["ryqiyuerenwu_sp_0006","ryqiyuerenwu_sp_0007","ryqiyuerenwu_sp_0008"])
class rt extends O.f{constructor(...t){super(...t),this.widget_bg=null,this.ui_task_contract_select_item=null}InitView(){super.InitView(),
this.widget_bg=this.CreateComponent(D.z,1),this.ui_task_contract_select_item=this.CreateComponentBinder(at,2)}OnAddToScene(){this.AddLis(),
this.ui_task_contract_select_item.SetData(L.$.ins.select_task_id),this.ui_task_contract_select_item.on_click_select=this.CreateDelegate(this.OnClickSure)}AddLis(){
this.AddFullScreenCollider(this.node,this.CreateDelegate(this.OnClose))}RemoveLis(){this.RemoveFullScreenCollider()}OnClose(){Tt.ins.CloseTaskContractSelectEndPanel(),
L.$.ins.select_task_id=0}OnClickSure(){Tt.ins.CM_SelectContractQuest(L.$.ins.select_task_id),this.OnClose()}Clear(){super.Clear(),this.RemoveLis(),
this.ui_task_contract_select_item.on_click_select=null,this.ui_task_contract_select_item.Clear()}Destroy(){super.Destroy()}}var ot=i(13113),ht=i(21267)
class dt extends O.f{constructor(...t){super(...t),this.grid_item=null,this.text_num=null,this.widget_bg=null,this.interval=null}InitView(){super.InitView(),
this.grid_item=this.CreateComponent(V.A,1),this.text_num=this.CreateComponent(P.Q,2),this.widget_bg=this.CreateComponent(ot.T,3),
this.grid_item.SetInitInfo("ui_task_contract_select_item",null,at)}OnAddToScene(){this.AddLis(),this.ClearInterval(),
this.interval=y.C.Inst_get().SetInterval(this.CreateDelegate(this.OnEachSec),1e3),this.UpdatePanel(),this.OnEachSec()}AddLis(){
this.AddFullScreenCollider(this.widget_bg.node,this.CreateDelegate(this.OnClickBtnClose))}RemoveLis(){this.RemoveFullScreenCollider()}Clear(){super.Clear(),this.ClearInterval(),
this.RemoveLis()}Destroy(){super.Destroy()}UpdatePanel(){this.grid_item.data_set(L.$.ins.GetStartTaskList()),this.text_num.textSet(H.o.Format((0,
N.T)("目前已累计推关{0}关"),ht.u.Inst().totalPassNum))}OnClickBtnClose(){Tt.ins.CloseTaskContractSelectPanel()}ClearInterval(){
-1!=this.interval&&(y.C.Inst_get().ClearInterval(this.interval),this.interval=-1)}OnEachSec(){if(null==L.$.ins.contract_task_info)return void Tt.ins.CloseTaskContractSelectPanel()
k.p.FloorToInt(L.$.ins.contract_task_info.endTime.ToNum()/1e3)-M.D.serverTime_get()>0||Tt.ins.CloseTaskContractSelectPanel()}}var _t=i(60130)
class ut extends O.f{constructor(...t){super(...t),this.text_time=null,this.text_name=null,this.img_bg=null,this.anchor=null,this.offset=null,this.interval=null}InitView(){
super.InitView(),this.text_time=this.CreateComponent(P.Q,1),this.text_name=this.CreateComponent(P.Q,2),this.img_bg=this.CreateComponent(v.w,3),
this.anchor=this.CreateComponent(ot.T,4),this.offset=this.CreateComponent(D.z,5)}OnAddToScene(){_t.O.SetAnchorPos(this.anchor,!1,!0,0,!0),this.AddLis(),this.ClearInterval(),
this.interval=y.C.Inst_get().SetInterval(this.CreateDelegate(this.OnEachSec),1e3),this.UpdatePanel(),this.OnEachSec()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.img_bg,this.CreateDelegate(this.OnClickImgBg))}RemoveLis(){}Clear(){super.Clear(),this.ClearInterval()}Destroy(){super.Destroy()}
OnClickImgBg(){Tt.ins.OpenTaskContractInfoPanel()}ClearInterval(){-1!=this.interval&&(y.C.Inst_get().ClearInterval(this.interval),this.interval=-1)}UpdatePanel(){
L.$.ins.contract_task_info}OnEachSec(){if(null==L.$.ins.contract_task_info)return void Tt.ins.CloseTaskContractUI()
const t=k.p.FloorToInt(L.$.ins.contract_task_info.endTime.ToNum()/1e3)-M.D.serverTime_get(),e=L.$.ins.contract_task_info.endTime.ToNum()-M.D.serverMSTime_get()
t>0?(this.text_time.textSet(U.l.GetDateFormatXXX(e,!0)),t<=1200&&this.text_time.SetColor(U.l.GetColorByHexStr("962424"))):(this.text_time.textSet((0,N.T)("已过期")),
Tt.ins.CloseTaskContractUI())}}var It,ct,gt,pt,mt=i(92415)
function St(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let Tt=(It=(0,n.GH)(mt.k.SM_ContractGuideQuest),ct=(0,n.GH)(mt.k.SM_ContractSeriesQuest),pt=class t{
static get ins(){return this._ins||(this._ins=new t),this._ins}constructor(){this.RegMsg()}RegMsg(){a.i.Inst.AddEventHandler(p.g.COPY_ENTERTIMEUDPDATE,(0,
l.v)(this.OnMapChange,this)),E.f.Inst.AddCallback(C.t.TASK_CONTRACT,(0,l.v)(this.OnRedChange,this))}CreateDelegate(t){return(0,g.r)(t,this)}CM_SelectContractQuest(t){
const e=new T.O
e.questId=t,o.C.Inst.F_SendMsg(e)}CM_AcceptContractReward(){const t=new S.w
o.C.Inst.F_SendMsg(t)}SM_ContractGuideQuestHandler(t){L.$.ins.contract_task_info=t,A.i.ins.ChangeShowMainUITask()}SM_ContractSeriesQuestHandler(t){L.$.ins.series_info=t,
a.i.Inst.RaiseEvent(p.g.TASKCONTRACT_CHANGE_INFO)}OnMapChange(){d.N.inst.CloseById(_.I.eTaskContractInfoPanel)}OnRedChange(){
E.f.Inst.GetData(C.t.TASK_CONTRACT).show&&f.h.Inst_get().UpdateFuncItemEffectState(m.x.TASK_CONTRACT,!0)}OnAcceptTask(t){
-1!=L.$.ins.GetStartTaskList().IndexOf(t.id_get())&&(L.$.ins.select_task_id=t.id_get(),this.OpenTaskContractSelectEndPanel())}OpenTaskContractUI(){
if(r.b.Inst.GetCurMap().hideElementsList.Contains(u.p.TASKCONTRACT_MAINUI))return
const t=new h.v
t.layerType=I.F.DefaultUI,t.aniDir=c.K.Right2,t.viewClass=ut,d.N.inst.OpenById(_.I.eTaskContractMainUI,null,null,t),a.i.Inst.RaiseEvent(p.g.TASKCONTRACT_Updata,null,3)}
CloseTaskContractUI(){d.N.inst.CloseById(_.I.eTaskContractMainUI),a.i.Inst.RaiseEvent(p.g.TASKCONTRACT_Updata,null,3)}OpenTaskContractInfoPanel(){
if(r.b.Inst.GetCurMap().hideElementsList.Contains(u.p.TASKCONTRACT_MAINUI))return
const t=new h.v
t.viewClass=B,t.isShowMask=!0,d.N.inst.OpenById(_.I.eTaskContractInfoPanel,null,null,t)}CloseTaskContractInfoPanel(){d.N.inst.CloseById(_.I.eTaskContractInfoPanel)}
OpenTaskContractSelectPanel(){const t=new h.v
t.viewClass=dt,t.isShowMask=!0,d.N.inst.OpenById(_.I.eTaskContractSelectPanel,null,null,t)}CloseTaskContractSelectPanel(){d.N.inst.CloseById(_.I.eTaskContractSelectPanel)}
OpenTaskContractSelectEndPanel(){const t=new h.v
t.viewClass=rt,t.isShowMask=!0,d.N.inst.OpenById(_.I.eTaskContractSelectEndPanel,null,null,t)}CloseTaskContractSelectEndPanel(){d.N.inst.CloseById(_.I.eTaskContractSelectEndPanel)}
OpenPanel(){const t=new h.v
t.viewClass=st,t.isShowMask=!0,d.N.inst.OpenById(_.I.eTaskContractPanel,null,null,t)}ClosePanel(){d.N.inst.CloseById(_.I.eTaskContractPanel)}OpenFinishEffectPanel(){const t=new h.v
t.viewClass=R,d.N.inst.OpenById(_.I.eTaskContractFinishEffectPanel,null,null,t)}CloseFinishEffectPanel(){d.N.inst.CloseById(_.I.eTaskContractFinishEffectPanel)}OpenRecoverPanel(){
const t=new h.v
t.viewClass=lt,d.N.inst.OpenById(_.I.eTaskContractRecoverPanel,null,null,t)}CloseRecoverPanel(){d.N.inst.CloseById(_.I.eTaskContractRecoverPanel)}HideTaskMainUIPanel(t){
const e=d.N.inst.GetViewById(_.I.eTaskContractMainUI)
null!=e&&(t?(e.node.transform.SetLocalPositionXYZ(0,-2e3,0),this.CloseTaskContractInfoPanel()):e.node.transform.SetLocalPositionXYZ(0,0,0))}},pt._ins=null,
St(gt=pt,"ins",[s.Vx],Object.getOwnPropertyDescriptor(gt,"ins"),gt),
St(gt.prototype,"SM_ContractGuideQuestHandler",[It],Object.getOwnPropertyDescriptor(gt.prototype,"SM_ContractGuideQuestHandler"),gt.prototype),
St(gt.prototype,"SM_ContractSeriesQuestHandler",[ct],Object.getOwnPropertyDescriptor(gt.prototype,"SM_ContractSeriesQuestHandler"),gt.prototype),gt)},81599:(t,e,i)=>{i.d(e,{$:()=>p
})
var s=i(38836),n=i(50089),l=i(68662),a=i(16812),r=i(85602),o=i(37648),h=i(55492),d=i(75439),_=i(14792),u=i(62734),I=i(98580),c=i(85890),g=i(99535)
class p extends a.k{constructor(...t){super(...t),this.contract_task_info=null,this.series_info=null,this.select_task_id=0,this.contract_task_list=null,this.start_task_list=null,
this.start_task_desc=null}static get ins(){return this._ins||(this._ins=new p),this._ins}IsShowContractTaskTip(){
return null!=this.contract_task_info&&this.contract_task_info.isShow&&l.D.serverMSTime_get()<this.contract_task_info.endTime.ToNum()}GetStartTaskList(){
return null==this.start_task_list&&(this.start_task_list=n.t.decode2List(d.D.getInstance().GetStringValue("CONTRACT:TASK_SERIES"))),this.start_task_list}GetStartTaskDesc(){
return null==this.start_task_desc&&(this.start_task_desc=n.t.decode(d.D.getInstance().getContent("CONTRACT:TASK_DESC").content)),this.start_task_desc}GetContractTaskList(){
if(null==this.contract_task_list){let t=0
for(let e=0;e<=this.GetStartTaskList().Count()-1;e++)if(g.O.Inst_get().IsTaskCompleted(this.GetStartTaskList()[e])){t=this.GetStartTaskList()[e]
break}if(0==t)return null
this.contract_task_list=new r.Z
const e=g.O.Inst_get().GetConfigsByType(c.U.CONTRACT)
for(let i=0;i<=e.Count()-1;i++){const s=e[i]
s.status_get()!=I.B.ACCEPTED&&s.status_get()!=I.B.FINISHED&&!g.O.Inst_get().IsTaskCompleted(s.id_get())||-1==s.needQuestsList.IndexOf(t)||this.contract_task_list.Add(e[i])}}
return this.contract_task_list}CheckRed(){let t=!1
if(null!=this.series_info&&1==this.series_info.contractRewardStatus)t=!0
else if(o.P.Inst_get().IsFunctionOpened(h.x.TASK_CONTRACT)&&null!=this.GetContractTaskList())for(const[e,i]of(0,s.V5)(this.GetContractTaskList()))if(i.status_get()==I.B.FINISHED){
t=!0
break}u.f.Inst.SetState(_.t.TASK_CONTRACT,t)}ResetModel(){this.contract_task_info=null,this.series_info=null,this.select_task_id=0,this.contract_task_list=null}}p._ins=null},
83434:(t,e,i)=>{i.d(e,{f:()=>$})
var s=i(86133),n=i(62370),l=i(66788),a=i(98885),r=i(85602),o=i(58087),h=i(87923),d=i(89803),_=i(84458),u=i(68214),I=i(77697)
class c{constructor(){}Hand(t,e,i,s,n,l){return null}}class g extends c{Hand(t,e,i,n,o,u){const c=new r.Z(5),g=I.f.Inst().getItemById(t.param.npcId)
let p=""
null==g?l.Y.LogError((0,s.T)("找不到NPC:")+t.param.npcId):p=g.name
const m=t.param.npcPosStr_get(),S=new r.Z([a.M.IntToString(_.V.FIND_PATH),a.M.IntToString(d.d.TALK_VALUE),a.M.IntToString(i),a.M.IntToString(g.npcid),m]),T=$.JointStr(S)
return $.SetResult(c,T,h.l.SetLinkStr(p,T,null,!1)),c}}var p=i(86209),m=i(19519)
class S extends c{Hand(t,e,i,s,n,l){
const o=new r.Z(5),h=new r.Z([a.M.IntToString(_.V.OPEN_PANEL),t.OpenUI_get(),a.M.IntToString(i)]),d=$.JointStr(h),u=t.param.type,I=m.J.GetCurrencyStr(u),c=p.w.Instance.ConvertNumToUnitize(t.value)
let g=0
null!=e&&(g=e.curValue.ToNum())
const S=`${p.w.Instance.ConvertNumFloor(g)}/${c}`
return $.SetResult(o,d,I,S),o}}var T=i(98800),f=i(99535)
class C extends c{Hand(t,e,i,s,n,l){const o=new r.Z(5)
let d="",u=0,I=""
const c=new r.Z([a.M.IntToString(_.V.OPEN_PANEL),t.OpenUI_get()])
return null!=i&&c.Add(a.M.IntToString(i)),d=$.JointStr(c),null!=e&&(u=e.curValue.ToNum()),I=`${a.M.DoubleToString(u)}/${t.value}`,
$.SetResult(o,d,I,h.l.SetLinkStr(I,d),a.M.IntToString(s)),o}}class E extends c{Hand(t,e,i,s,n,l){const o=new r.Z(5)
let u=null
null!=i&&(u=f.O.Inst_get().GetConfig(i))
const c=I.f.Inst().getItemById(u.RewardNpcId_get())
if(!c)return $.GetHandler(C).Hand(t,e,i)
{
const e=new r.Z([a.M.IntToString(_.V.FIND_PATH),a.M.IntToString(d.d.TALK_VALUE),a.M.IntToString(u.id_get()),a.M.IntToString(u.RewardNpcId_get()),a.M.IntToString(c.mapid),a.M.FloatToString(c.x),a.M.FloatToString(c.y)]),i=$.JointStr(e)
let s=t.param.currencyType
h.l.IsEmptyStr(s)&&(s=t.param.type)
const n=m.J.GetCurrencyStr(s),l=m.J.GetGold(T.Y.Inst.PrimaryRoleInfo_get(),s),I=p.w.Instance.ConvertNumFloor(l),g=p.w.Instance.ConvertNumToUnitize(t.value)
let S=""
l<t.value&&(S=`${I}/${g}`),$.SetResult(o,i,n,S)}return o}}var A=i(21334)
class L extends c{Hand(t,e,i,s,n,l){
const o=new r.Z(5),d=A.p.Inst_get().GetMapById(t.param.mapId),u=new r.Z([a.M.IntToString(_.V.OPEN_PANEL),t.OpenUI_get()]),I=$.JointStr(u),c=`${e.curValue.ToNum()}/${t.value}`
return $.SetResult(o,I,h.l.SetLinkStr(d.name,I,null,!1),c),o}}var y=i(59918)
class D extends c{Hand(t,e,i,s,n,l){const o=new r.Z(5)
let u="",I=0,c="",g=new r.Z([a.M.IntToString(_.V.OPEN_PANEL),t.OpenUI_get(),a.M.IntToString(i)])
if(u=$.JointStr(g),null!=e&&(I=e.curValue.ToNum()),null!=t.param&&null!=t.param.equipType){const e=y.R.GetName(t.param.equipType)
t.type==d.d.EQUIPMENT_ENHANCE_TIME?(g=new r.Z([a.M.IntToString(_.V.OPEN_STRENG_PANEL),t.OpenUI_get(),`${d.d.EQUIPMENT_ENHANCE_TIME_VALUE}|${t.param.equipType}`]),
u=$.JointStr(g)):t.type==d.d.EQUIPMENT_ADD_TIME&&(g=new r.Z([a.M.IntToString(_.V.OPEN_STRENG_PANEL),t.OpenUI_get(),`${d.d.EQUIPMENT_ADD_TIME_VALUE}|${t.param.equipType}`]),
u=$.JointStr(g)),c=`${a.M.DoubleToString(I)}/${t.value}`,$.m_subArr=new r.Z([e,a.M.DoubleToString(t.value)]),$.SetResult(o,u,h.l.SetLinkStr(e,u,null,!1),c)
}else c=`${a.M.DoubleToString(I)}/${t.value}`,$.SetResult(o,u,h.l.SetLinkStr(c,u,null,!1),c)
return o}}class O extends c{Hand(t,e,i,s,n,l){const o=new r.Z(5)
let d=0
null!=e&&(d=e.ToNum())
const u=new r.Z([a.M.IntToString(_.V.HAND_IN),a.M.IntToString(t.OpenUI_get()),a.M.IntToString(t.param.npcId),a.M.IntToString(t.param.itemModelId)]),I=O.JointStr(u),c=y.R.GetName(t.param.equipmentType)
let g=a.M.Replace("{0}","{0}",h.l.getEquiplvStr(t.param.stepLv))
g+=a.M.Replace("{0}","{0}",c),g=h.l.SetLinkStr(g,I,null,!1)
const p=`${O.GetCountColorStr(a.M.DoubleToString(d))}/${t.value}`
return o[0]=I,o[1]=g,o[2]=p,o}}O.JointStr=null,O.GetCountColorStr=null
var R=i(33138)
class N extends c{Hand(t,e,i,n,o,d){const u=new r.Z(5)
let I=0
null!=e&&(I=e.ToNum())
const c=new r.Z([a.M.IntToString(_.V.HAND_IN),a.M.IntToString(t.OpenUI_get()),a.M.IntToString(t.param.npcId),a.M.IntToString(t.param.itemModelId)]),g=N.JointStr(c),p=R.f.Inst().GetItemGroupName(t.param.itemGroupId)
a.M.IsNullOrEmpty(p)&&l.Y.LogError((0,s.T)("itemresource表中没有配置当前组的名字：")+a.M.IntToString(t.param.itemGroupId))
const m=h.l.SetLinkStr(p,g,null,!1),S=`${N.GetCountColorStr(a.M.DoubleToString(I))}/${t.value}`
return u[0]=g,u[1]=m,u[2]=S,u}}N.JointStr=null,N.GetCountColorStr=null
var M=i(70850),w=i(84308)
class P extends c{Hand(t,e,i,s,n,l){const o=new r.Z(5)
let u=null,I=0
null!=e&&(I=e.ToNum())
const c=t.value-I
if(c>0&&c>M.g.Inst_get().GetItemNum(a.M.String2Int(t.param.itemModelId))&&(t.param.gatherId>0||t.param.groupId>0)){let e=null
t.param.gatherId>0?e=w.J.Inst().getItemById(t.param.gatherId):(e=w.J.Inst().GetItemByGroupId(t.param.groupId),t.param.gatherId=e.id),
u=new r.Z([a.M.IntToString(_.V.FIND_PATH),a.M.IntToString(d.d.GATHER_VALUE),a.M.IntToString(i),a.M.IntToString(t.param.gatherId),t.param.gatherPos_get()])
}else u=new r.Z([a.M.IntToString(_.V.HAND_IN),a.M.IntToString(t.OpenUI_get()),a.M.IntToString(t.param.npcId),a.M.IntToString(t.param.itemModelId)])
const g=P.JointStr(u),p=R.f.Inst().getItemById(a.M.String2Int(t.param.itemModelId)),m=h.l.SetLinkStr(p.name,g,null,!1),S=`${P.GetCountColorStr(a.M.DoubleToString(I))}/${t.value}`
return o[0]=g,o[1]=m,o[2]=S,o}}P.JointStr=null,P.GetCountColorStr=null
var v=i(13687),k=i(31931),U=i(12970)
class G extends c{Hand(t,e,i,s,n,l){let o=-1
if("-1"!=t.param.mapList){const e=a.M.Split(t.param.mapList,";")
o=a.M.String2Int(e[0])
for(let t=1;t<=e.Count()-1;t++){const i=A.p.Inst_get().GetMapById(a.M.String2Int(e[t]))
U.F.getInst().GetCanEnterMapByLvAndTransfer(i.id)==k.f.CAN&&i.minLevelLimit>A.p.Inst_get().GetMapById(o).minLevelLimit&&(o=a.M.String2Int(e[t]))}}let d=null
const u=new r.Z(5)
d=v.b.Inst.currentMapId_get()==o&&0!=t.param.guideBtn?new r.Z([a.M.IntToString(_.V.TRIGGER_GUIDE_BTN),a.M.IntToString(t.param.guideBtn)]):new r.Z([a.M.IntToString(_.V.TRANSMIT_PATH_MAX),a.M.IntToString(o)])
const I=$.JointStr(d)
let c
return c=null!=e?`${e.curValue.ToNum()}/${t.value}`:`${t.value}/${t.value}`,$.SetResult(u,I,h.l.SetLinkStr("",I,null,!1),c,c),u}}class F extends c{Hand(t,e,i,s,n,l){
const o=new r.Z(5)
let d=-1
if("-1"!=t.param.mapList){const e=a.M.Split(t.param.mapList,";")
d=a.M.String2Int(e[0])
for(let t=1;t<=e.Count()-1;t++){const i=A.p.Inst_get().GetMapById(a.M.String2Int(e[t]))
U.F.getInst().GetCanEnterMapByLvAndTransfer(i.id)==k.f.CAN&&i.minLevelLimit>A.p.Inst_get().GetMapById(d).minLevelLimit&&(d=a.M.String2Int(e[t]))}}
const u=new r.Z([a.M.IntToString(_.V.TRANSMIT_PATH_MAX),a.M.IntToString(d)]),I=$.JointStr(u),c=`${e.curValue.ToNum()}/${t.value}`
return $.SetResult(o,I,h.l.SetLinkStr("",I,null,!1),c,c),o}}var B=i(23833),H=i(87048),V=i(85890)
class b extends c{Hand(t,e,i,s,l,o){const u=new r.Z(5),I=t
let c=null,g="",m=0,S="",T=null,C=null,E=null,L=""
if(I.type==d.d.KILL_MONSTER||I.type==d.d.MONSTER_DROP_EQUIP)if(null!=I.OpenUI_get()&&""!=I.OpenUI_get())c=new r.Z([a.M.IntToString(_.V.OPEN_PANEL),a.M.IntToString(I.OpenUI_get()),a.M.IntToString(i)]),
g=$.JointStr(c),null!=e&&(m=e.curValue.ToNum())
else if(I.param.mapId>0){const t=A.p.Inst_get().GetMapById(I.param.mapId)
c=new r.Z([a.M.IntToString(_.V.FIND_PATH),a.M.IntToString(d.d.MONSTER_HUNT_MAP_VALUE),a.M.IntToString(i),a.M.IntToString(I.param.mapId),a.M.IntToString(I.param.mapId)]),
g=$.JointStr(c),L=t.name,null!=e&&(m=e.curValue.ToNum())}else if(h.l.IsEmptyStr(I.param.fly)){if(!a.M.IsNullOrEmpty(I.OpenUI_get())){
if(c=new r.Z([a.M.IntToString(_.V.OPEN_PANEL),I.OpenUI_get(),a.M.IntToString(i)]),g=$.JointStr(c),I.param.monsterId>0){L=B.a.getInst().getObjById(I.param.monsterId).name
}else if(I.param.monsterGroupId>0){L=H.$.Inst_get().GetItemCfg(I.param.monsterGroupId).name}null!=e&&(m=e.curValue.ToNum())}if(I.param.suggestHang>0){
const t=U.F.getInst().GetRecommendTransVo()
if(null!=t){const s=B.a.getInst().getObjById(t.objectId)
c=new r.Z([a.M.IntToString(_.V.FIND_PATH),a.M.IntToString(d.d.KILL_MONSTER_VALUE),a.M.IntToString(i),a.M.IntToString(t.objectId),t.id]),g=$.JointStr(c),L=s.name,
null!=e&&(m=e.curValue.ToNum())}}}else if(I.param.monsterId>0){const t=B.a.getInst().getObjById(I.param.monsterId)
c=new r.Z([a.M.IntToString(_.V.FIND_PATH),a.M.IntToString(d.d.KILL_MONSTER_VALUE),a.M.IntToString(i),a.M.IntToString(I.param.monsterId),I.param.flyPos_get()]),g=$.JointStr(c),
L=t.name,null!=e&&(m=e.curValue.ToNum())}else if(I.param.monsterGroupId>0){const t=H.$.Inst_get().GetItemCfg(I.param.monsterGroupId)
c=new r.Z([a.M.IntToString(_.V.FIND_PATH),a.M.IntToString(d.d.KILL_MONSTER_VALUE),a.M.IntToString(i),a.M.IntToString(I.param.monsterId),I.param.flyPos_get()]),g=$.JointStr(c),
L=t.name,null!=e&&(m=e.curValue.ToNum())
}else I.param.uesFlyId_get()>0&&(c=new r.Z([a.M.IntToString(_.V.FIND_PATH),a.M.IntToString(d.d.KILL_MONSTER_VALUE),a.M.IntToString(i),"",I.param.flyPos_get()]),g=$.JointStr(c),
L="",null!=e&&(m=e.curValue.ToNum()))
else if(I.type==d.d.GATHER||I.type==d.d.GATHER_ITEM){let t=null
I.param.gatherId>0?t=w.J.Inst().getItemById(I.param.gatherId):(t=w.J.Inst().GetItemByGroupId(I.param.groupId),I.param.gatherId=t.id),
c=new r.Z([a.M.IntToString(_.V.FIND_PATH),a.M.IntToString(d.d.GATHER_VALUE),a.M.IntToString(i),a.M.IntToString(t.id),I.param.gatherPos_get()]),g=$.JointStr(c)
let e="",s=null
if(null!=i&&(s=f.O.Inst_get().GetConfig(i)),null!=s&&s.type_get()==V.U.CHANGE_JOB){
const t=s.completeConsumsInfo_get().rewardValues[0],i=a.M.Split(t.value,n.o.s_Arr_UNDER_COLON),l=a.M.String2Int(i[0])
e=M.g.Inst_get().getItemresource(l).name}else null!=t&&(e=t.name)
L=e}else if(I.type==d.d.KILL_MONSTER_ITEM||I.type==d.d.KILL_MONSTER_RATE||I.type==d.d.FICTITIOUS_ITEM){if(null!=I.OpenUI_get()&&""!=I.OpenUI_get()){
B.a.getInst().getObjById(I.param.monsterId)
c=new r.Z([a.M.IntToString(_.V.OPEN_PANEL),a.M.IntToString(I.OpenUI_get()),a.M.IntToString(i)]),g=$.JointStr(c),null!=e&&(m=e.curValue.ToNum())
}else if(0!=I.param.npcId)E=I.param.npcPosStr_get(),c=new r.Z([a.M.IntToString(_.V.FIND_PATH),a.M.IntToString(d.d.TALK_VALUE),a.M.IntToString(i),a.M.IntToString(I.param.npcId),E]),
g=$.JointStr(c)
else{let t=d.d.KILL_MONSTER_ITEM_VALUE
I.type==d.d.KILL_MONSTER_RATE?t=d.d.KILL_MONSTER_RATE_VALUE:I.type==d.d.FICTITIOUS_ITEM&&(t=d.d.FICTITIOUS_ITEM_VALUE),
c=new r.Z([a.M.IntToString(_.V.FIND_PATH),a.M.IntToString(t),a.M.IntToString(i),a.M.IntToString(I.param.monsterId),I.param.flyPos_get()]),g=$.JointStr(c)}
L=M.g.Inst_get().getItemresource(a.M.String2Int(I.param.itemModelId)).name}return null!=e&&(m=e.curValue.ToNum()),
null==c&&(a.M.IsNullOrEmpty(I.OpenUI_get())||(c=new r.Z([a.M.IntToString(_.V.OPEN_PANEL),I.OpenUI_get(),a.M.IntToString(i)]),g=$.JointStr(c))),
T=p.w.Instance.ConvertNumToUnitize(m),C=p.w.Instance.ConvertNumToUnitize(I.value),S=`${T}/${C}`,$.SetResult(u,g,h.l.SetLinkStr(L,g,null,!1),S,S),u}}class x extends c{
Hand(t,e,i,s,n,l){const o=new r.Z(5)
let u=""
if(!h.l.IsEmptyStr(t.param.fly)){const e=new r.Z([a.M.IntToString(_.V.FIND_PATH),a.M.IntToString(d.d.LEVEL_VALUE),a.M.IntToString(i),a.M.IntToString(0),t.param.flyPos_get()])
return u=x.JointStr(e),$.SetResult(o,u,null),o}return $.GetHandler(C).Hand(t,e,i)}}x.JointStr=null
class q extends c{Hand(t,e,i,s,n,l){if(a.M.IsNullOrEmpty(t.OpenUI_get())){const i=new r.Z(5)
let s="",n=0,l=""
const o=new r.Z([a.M.IntToString(_.V.DERICT_BUY),t.param.mallId])
return s=$.JointStr(o),null!=e&&(n=e.curValue.ToNum()),l=`${a.M.DoubleToString(n)}/${t.value}`,$.SetResult(i,s,l,h.l.SetLinkStr(l,s)),i}return $.GetHandler(C).Hand(t,e,i)}}
var Y=i(72800),K=i(24524)
class J extends c{Hand(t,e,i,s,n,l){const o=new r.Z(5)
let u=null
t.param.copyId>0?u=K.o.Inst().getItemById(t.param.copyId):t.param.groupId>0&&(u=K.o.Inst().getOneItemByGroupId(t.param.groupId))
let c=null
if(a.M.IsNullOrEmpty(t.OpenUI_get()))if(0==u.NpcId)c=u.controllerType==Y.S.RyAllianceTask||u.controllerType==Y.S.Plot?new r.Z([a.M.IntToString(_.V.ENTER_COPY_JUST),a.M.IntToString(u.id),a.M.IntToString(config.id_get()),a.M.IntToString(u.controllerType)]):new r.Z([a.M.IntToString(_.V.OPEN_COPY_PANEL),a.M.IntToString(u.controllerType)])
else{t.param.npcId=u.NpcId
const e=I.f.Inst().getItemById(u.NpcId)
c=new r.Z([a.M.IntToString(_.V.FIND_PATH),a.M.IntToString(d.d.PASS_COPY_VALUE),a.M.IntToString(i),a.M.IntToString(e.npcid),a.M.IntToString(e.mapid),a.M.FloatToString(e.x),a.M.FloatToString(e.y)])
}else c=new r.Z([a.M.IntToString(_.V.OPEN_PANEL),t.OpenUI_get(),a.M.IntToString(i)])
const g=$.JointStr(c)
let p=0
null!=e&&(p=e.curValue.ToNum())
let m=""
null!=u&&(m=u.name)
const S=h.l.SetLinkStr(m,g,null,!1),T=`${a.M.DoubleToString(p)}/${t.value}`
return o[0]=g,o[1]=S,o[2]=T,o}}class Q extends c{Hand(t,e,i){const s=new r.Z(5)
let n=null,l=null,a=""
return null!=t.param&&(n=t.param.flyPos_get(),a=$.JointStr(l)),l=new r.Z(["",""]),$.SetResult(s,a,h.l.SetLinkStr("",a,null,!1)),s}}class Z extends c{Hand(t,e,i,n,o,u){
const c=new r.Z(5),g=I.f.Inst().getItemById(t.param.npcId)
let p=""
null==g?l.Y.LogError((0,s.T)("找不到NPC:")+t.param.npcId):p=g.name
const m=t.param.npcPosStr_get(),S=new r.Z([a.M.IntToString(_.V.FIND_PATH),a.M.IntToString(d.d.TALK_VALUE),a.M.IntToString(i),a.M.IntToString(g.npcid),m]),T=$.JointStr(S)
return $.SetResult(c,T,h.l.SetLinkStr(p,T,null,!1)),c}}class X extends c{Hand(t,e,i,s,n,l){
const a=new r.Z(5),o=new r.Z(["",""]),h=$.JointStr(o),d=m.J.THEME_SCORE,_=m.J.GetCurrencyStr(d),u=e.curValue.ToNum(),I=p.w.Instance.ConvertNumFloor(u),c=p.w.Instance.ConvertNumToUnitize(t.value)
let g=""
return u<t.value&&(g=`${I}/${c}`),$.SetResult(a,h,_,g),a}}class ${static GetLinkInfo(t,e,i,r){const o=$.GetTargetDefIndex(e,i)
$.m_subArr.Clear()
const d=$.handlerByType(e.tCTargetDefs[o].type,e.tCTargetDefs[o],i[o],r),_=u.a.GetInst()
let I=null
$.m_subArr.Clear(),0==$.m_subArr.Count()&&$.m_subArr.Add(d[1])
const c=a.M.Split(t[o],n.o.s_Arr_UNDER_CHAR_DOLL),g=e.tCTargetDefs[o]
c.count<=2?(l.Y.LogError((0,s.T)("的underwayText字段，$数量不匹配，应取第")+(3+(0,s.T)("段"))),I=""):g.IsNeedFixAttr()||(I=h.l.Substitute(c[2],$.m_subArr))
let p=!1
const m=a.M.RegexMatch(I,$.PRO_TAG)
let S=0
if(null!=m&&m.length>=3)S=a.M.String2Int(a.M.GetAt(m,2)),I=a.M.Replace(I,$.PRO_TAG,""),p=!0
else if(a.M.IndexOf(I,$.PRO_LINE_TAG,0)>-1){const t=a.M.IndexOf(I,$.PRO_LINE_TAG,0),e=a.M.SubStringWithEnd(I,t+6,t+7)
I=a.M.Replace(I,`{aLine${e}}`,""),_.prohangeLine=a.M.String2Int(e),p=!0}return p||(d[2]=null),_.AddItem(I,d[0],d[2],S,null),_.targetOriginalStr=d[1],_.progresOriginalStr=d[3],
_.replaceStr=d[4],_}static GetLinkStr(t,e,i){return $.handlerByType(t.type,t,e,i)[0]}static handlerByType(t,e,i,s){let n=null
let a=null
t==d.d.ATTR_VALUE?a=g:t==d.d.TALK||t==d.d.REAL_TALK?a=Z:t==d.d.KILL_MONSTER||t==d.d.GATHER||t==d.d.GATHER_ITEM||t==d.d.KILL_MONSTER_ITEM||t==d.d.KILL_MONSTER_RATE||t==d.d.FICTITIOUS_ITEM||t==d.d.KILL_MIRACLE_MONSTER||t==d.d.MONSTER_DROP_EQUIP?a=b:t==d.d.PASS_COPY||t==d.d.ENTER_COPY||t==d.d.CLIMB_TOWER_STAR?a=J:t==d.d.CONSUME_CURRENCY?a=S:t==d.d.CURRENCY||t==d.d.CURRENCY_HISTORY||t==d.d.CURRENCY_BACK?a=E:t==d.d.HAND_IN_ITEM?a=P:t==d.d.HAND_IN_ITEM_GROUP?a=N:t==d.d.HAND_IN_EQUIPMENT?a=O:t==d.d.MALL_BUY?a=q:t==d.d.LEVEL?a=x:t==d.d.EQUIP_EXCELLENT||t==d.d.EXCELLENCE_ADD_COUNT||t==d.d.EQUIP_STAR_EXCELLENT?a=C:t==d.d.EQUIPMENT_ENHANCE_TIME||t==d.d.EQUIPMENT_ADD_TIME||t==d.d.EQUIPMENT_ENHANCE_LEVEL?a=D:t==d.d.DAILY_VITALITY||t==d.d.DAILY_VITALITY_TOTAL||t==d.d.EXCELLENT_JEWELRY||t==d.d.SKILL_CULTIVATION||t==d.d.POWER||t==d.d.EQUIP_SECOND_WING_IGNORE||t==d.d.EQUIP_THIRD_WING_IGNORE||t==d.d.SKILL_LEVEL||t==d.d.SKILL_TRAIN_LEVEL||t==d.d.SUIT_EQUIP||t==d.d.PRAY||t==d.d.JOIN_ASURAM||t==d.d.MEMBER_DONATE_TIME||t==d.d.ASURAM_EQUIP_DONATE||t==d.d.ASURAM_EXCHANGE||t==d.d.ATTR_VALUE||t==d.d.EXTRA_SKILL_LEVEL||t==d.d.EQUIP_SCORE||t==d.d.WING_ENCHANCE||t==d.d.AUCTION_TRADE||t==d.d.ARENA_DAN||t==d.d.MARKET_TRADE||t==d.d.ACHIEVEMENT_POINT||t==d.d.TRANSPORT||t==d.d.ITEM_NUM_HISTORY||t==d.d.COPY_ENCOURAGE_TIME||t==d.d.FUNCTION_OPEN||t==d.d.ADD_PACK_SIZE_NUM||t==d.d.REGISTRATION_TIME||t==d.d.EQUIPMENT_ENHANCE_TOTAL_LEVEL||t==d.d.ALL_ROLE_ADD_LEVEL||t==d.d.PLAYER_DEATH||t==d.d.SEEK_TREASURE||t==d.d.AUCTION_BID_SUCC||t==d.d.AUCTION_BID_FAIL||t==d.d.AUCTION_BUY_ITEMNUM||t==d.d.AUCTION_DIMOND||t==d.d.ACTIVITY_JOIN||t==d.d.VIP||t==d.d.INVEST||t==d.d.TOTAL_RECHARGE_MONEY||t==d.d.MEMORY_ACTIVE||t==d.d.SKILL_SLOT||t==d.d.HISTORY_DIG_MINE_COUNT||t==d.d.TRANSFER_ACTIVE_STARCLOUD||t==d.d.JIGSAW||t==d.d.TRANSFER_EXP_BLESSING||t==d.d.KUNDUN_SEAL||t==d.d.OCEAN_HEART||t==d.d.ELEMENT_BOSS||t==d.d.JEW_NUM||t==d.d.SELECT_TRANSFER_DIRECTION||t==d.d.HONOR_MANUAL_LEVEL||t==d.d.ALL_ROLE_LEARN_SKILL_NUM||t==d.d.EQUIPMENT_NUM||t==d.d.ITEM_NUM||t==d.d.ITEM_GROUP_NUM||t==d.d.REBIRTH||t==d.d.CREATE_ROLE||t==d.d.ENHANCE_SUC_ONE_TIMES||t==d.d.TODAY_DROP_SUIT_EQUIP||t==d.d.FINISH_HONOR_MANUAL_TASK_NUM||t==d.d.MULTI_HANG_TIME||t==d.d.DAILY_HONOR||t==d.d.RIDING_NUM||t==d.d.STALL_GOLD_NUM||t==d.d.TALENT_LEARN_NUM||t==d.d.EQUIP_TOTAL_ADDLEVEL||t==d.d.OUTLINE_TIME||t==d.d.STALL_BUY_NUM||t==d.d.STALL_UP_NUM||t==d.d.LEVEL_CHANGE||t==d.d.ALL_ROLE_LEARN_SKILL_NUM||t==d.d.BOSS_STAMINA_REDUCE||t==d.d.SKILL_ALL_LEVEL||t==d.d.ALL_ROLE_EXCELLENT_NUM||t==d.d.ASURAM_PARTY||t==d.d.ASSIST||t==d.d.COMPLETE_QUEST||t==d.d.TREASURE_HUNT||t==d.d.EQUIPMENT_EQUIP||t==d.d.QUICK_BATTLE||t==d.d.ARENA_CHALLENGE||t==d.d.ARENA_RANK||t==d.d.PASS_MAP||t==d.d.ALL_ROLE_STAR_NUM||t==d.d.GOUI||t==d.d.TOTAL_BATTLE_SCORE||t==d.d.APPOINT_ROLE_LEARN_SKILL_NUM||t==d.d.ADD_UP_EXCELLENCE_NUM||t==d.d.ADD_UP_ENHANCE_LEVEL||t==d.d.ADD_UP_ADD_LEVEL||t==d.d.ADD_UP_BATTLE_SCORE||t==d.d.ADD_UP_SKILL_LEVEL||t==d.d.ADD_UP_HORSE_SCORE||t==d.d.GOD_EQUIP_SCORE||t==d.d.DRAGON_TREASURE||t==d.d.GOD_EQUIP_NUM||t==d.d.ASURAM_DONATE||t==d.d.ENTER_KARIMA||t==d.d.ASURAM_INTERACTION||t==d.d.KILL_ASURAM_BOSS||t==d.d.GLORY_RANK_SCORE?a=C:t==d.d.ENHANCE_EQUIP_TOTAL?(a=C,
n=e.param.equipenhancelevel):t==d.d.ADD_EQUIP_TOTAL?(a=C,
n=e.param.addLevel):t==d.d.HANG_IN_MAX?a=F:t==d.d.HANG_IN_FLY?a=G:t==d.d.SERVER_PASS_MAP?a=Q:t==d.d.THEME_SCORE?a=X:t==d.d.ENTER_MAP&&(a=L),null==a&&l.Y.LogError(`不存在目标类型${t}`)
return $.GetHandler(a).Hand(e,i,s,n,null,null)}static GetHandler(t){let e=$.handler_dict.LuaDic_GetItem(t)
return null==e&&(e=new t,$.handler_dict.LuaDic_AddOrSetItem(String(t),e)),e}static GetTargetDefIndex(t,e){
for(let i=0;i<=t.tCTargetDefs.Count()-1;i++)if(i<e.Count()&&e[i].curValue.ToNum()<t.tCTargetDefs[i].value)return i
return 0}JudgeOpenPanelHandle(t,e,i,s,n){let l="",o=0,h=""
const d=new r.Z([a.M.IntToString(_.V.OPEN_PANEL),t.OpenUI_get(),a.M.IntToString(s.id_get())])
return l=$.JointStr(d),null!=i&&(o=i[e].value_get()),h=`${a.M.DoubleToString(o)}/${n}`,s.linkStr=l,[l,h]}static JointStr(t){
if(null!=t&&t.count>=2&&t[0]==a.M.IntToString(_.V.OPEN_PANEL)&&"0"==t[1])return""
let e=""
if(null!=t){const i=t.count
let s=0
for(;s<i;)null!=t[s]&&(e+=t[s],s<i-1&&(e+=n.o.s_UNDER_CHAR)),s+=1}return e}static SetResult(t,...e){const i=[...e]
"CList"==typeof i[0]?t[0]=$.JointStr(new r.Z(i[0])):"string"==typeof i[0]&&(t[0]=i[0])
for(let e=2;e<=i.length;e++)t[e-1]=i[e-1]}}$.PRO_TAG="{a[0-9]*}",$.PRO_COLOR="{p*}",$.PRO_LINE_TAG="{aLine",$.handler_dict=new o.y,$.m_subArr=new r.Z},57651:(t,e,i)=>{i.d(e,{
i:()=>xt})
var s=i(42292),n=i(71409),l=i(17409),a=i(98800),r=i(97960),o=i(97461),h=i(36241),d=i(19176),_=i(13687),u=i(38935),I=i(62370),c=i(56937),g=i(18202),p=i(31222),m=i(49484),S=i(52726),T=i(98789),f=i(95721),C=i(98885),E=i(85602),A=i(79534),L=i(47465),y=i(92679),D=i(87923),O=i(29839),R=i(2457),N=i(98996),M=i(92415),w=i(63170),P=i(20886),v=i(29279),k=i(41825),U=i(81599),G=i(23765),F=i(79878),B=i(17783),H=i(98580),V=i(63412),b=i(15398),x=i(99294),q=i(8889),Y=i(13113),K=i(61911),J=i(60130),Q=i(32076),Z=i(85890),X=i(99535)
class ${static get ins(){return null==$._mInst&&($._mInst=new $),$._mInst}constructor(){this.finish_hide_list=null,this.contract_task_info=null,this.finish_hide_list=new E.Z,
this.AddLis()}AddLis(){X.O.Inst_get().AddEventHandler(b.M.FINISH_ONE_TASK,(0,Q.v)(this.OnAddHideTask,this))}OnAddHideTask(t){
t.type_get()==Z.U.HIDE&&t.status_get()==H.B.FINISHED&&-1==this.finish_hide_list.IndexOf(t)&&(this.finish_hide_list.Add(t),X.O.Inst_get().RaiseEvent(b.M.TASK_HIDE_FINISH,t))}}
$._mInst=null
var W=i(86133),j=i(5924),z=i(9986),tt=i(35880),et=i(93877),it=i(3522),st=i(72005),nt=i(30849),lt=i(75696),at=i(18152),rt=i(57522),ot=i(48933),ht=i(5031)
class dt extends nt.C{constructor(...t){super(...t),this.img_max_width=470,this.img_min_width=90,this.scroll_call_id=-1,this.scroll_all_times=20,this.scroll_inter=30,
this.scroll_times=0,this.is_playing=!1,this.task=null,this.rewardItem=null,this.call_end=null,this.flying=!1,this.start_deep=0,this.text_desc=null,this.text_name=null,
this.img_right=null,this.img_left=null,this.btn_get=null,this.ui_baseitem=null,this.panel_scroll=null,this.ui_task_hide_view=null,this.panel_up=null,this.widget_open=null,
this.tween_left=null,this.tween_right=null,this.effect_obj=null}InitView(){super.InitView(),this.text_desc=this.CreateComponent(et.Q,1),this.text_name=this.CreateComponent(et.Q,2),
this.img_right=this.CreateComponent(st.w,3),this.img_left=this.CreateComponent(st.w,4),this.btn_get=this.CreateComponent(z.W,6),this.ui_baseitem=this.CreateComponentBinder(lt.j,7),
this.panel_scroll=this.CreateComponent(q.$,8),this.ui_task_hide_view=this.CreateComponent(q.$,9),this.panel_up=this.CreateComponent(q.$,10),
this.widget_open=this.CreateComponent(Y.T,11),this.tween_left=this.CreateComponent(tt.d,12),this.tween_right=this.CreateComponent(tt.d,13),
this.effect_obj=this.CreateComponent(it.k,14),this.InitHandlerMgr()}AddLis(){this.m_handlerMgr.AddClickEvent(this.btn_get,this.CreateDelegate(this.OnClickItem)),
this.m_handlerMgr.AddClickEvent(this.widget_open,this.CreateDelegate(this.OnClickWidget))}RemoveLis(){}Clear(){super.Clear(),this.RemoveLis(),this.StopPlay(),
this.tween_left.RemoveEventHandler(this.CreateDelegate(this.OnScaleEnd))}Destroy(){super.Destroy()}SetData(t){this.task=t,this.AddLis(),
this.ui_task_hide_view.depthSet(this.start_deep),this.panel_up.depthSet(this.start_deep+1),this.panel_scroll.depthSet(this.start_deep+2),this.text_name.textSet((0,
W.T)(`完成隐藏任务-${this.task.taskName_get()}`))
const e=C.M.Split(this.task.resource_get().underwayText,"$")
this.text_desc.textSet(e[3]),null!=this.task.showRewardResult_get()&&null!=this.task.showRewardResult_get().GetRewardBaseItemList()&&(this.rewardItem=this.task.showRewardResult_get().GetRewardBaseItemList()[0],
null!=this.rewardItem&&(this.ui_baseitem.node.SetActive(!0),this.rewardItem.IconType_Set(at.s.BASE_ICON_TYPE_64_64),this.ui_baseitem.SetData(this.rewardItem)))}StartPlay(){
this.is_playing||(this.is_playing=!0,this.scroll_call_id=j.C.Inst_get().SetInterval(this.CreateDelegate(this.OnScroll),this.scroll_inter))}StopPlay(){
this.is_playing&&(-1!=this.scroll_call_id&&(j.C.Inst_get().ClearInterval(this.scroll_call_id),this.scroll_call_id=-1),this.btn_get.node.SetActive(!0),this.is_playing=!1)}
OnScroll(){const t=(this.img_max_width-this.img_min_width)/this.scroll_all_times*this.scroll_times
ot.I.cal4Vec0.Set(t/2,0,t,this.img_right.height()),this.panel_scroll.baseClipRegionSet(ot.I.cal4Vec0),this.img_right.widthSet(t+this.img_min_width),this.scroll_times+=1,
this.scroll_times>this.scroll_all_times&&(this.StopPlay(),null!=this.call_end&&this.call_end())}ResetToPlay(){this.flying=!1,this.img_right.node.SetLocalPositionXYZ(0,-1,0),
this.img_right.widthSet(this.img_min_width),ot.I.cal4Vec0.Set(0,0,1,this.img_right.height()),this.panel_scroll.baseClipRegionSet(ot.I.cal4Vec0),this.btn_get.node.SetActive(!1),
this.widget_open.node.SetActive(!0),this.effect_obj.ResumeAnim(),this.effect_obj.PlayForward(),this.tween_left.ResetToBeginning(),this.tween_right.ResetToBeginning(),
this.img_left.node.transform.SetLocalScaleXYZ(.6,.6,1)}OnClickItem(){if(this.flying)return
this.flying=!0
const t=ht.T.inst_get().control.GetBagWorldPos(!1),e=this.ui_baseitem.node.transform.GetPosition(),i={},s={}
s.startVec=e,s.endVec=t,s.modelId=this.rewardItem.modelId_get(),table.insert(i,s)
const n=new A.P(.5,.5,1)
rt.h.Inst_get().PlayFlyItem(0,0,0,i,n),F.Y.SendToServer(this.task),X.O.Inst_get().RaiseEvent(b.M.TASK_HIDE_SHOW_END)}OnClickWidget(){this.effect_obj.StopAnim(),
this.effect_obj.SetAnimProgress(this.effect_obj.GetClipName(),0,1),this.widget_open.node.SetActive(!1)
const t=A.P.New(.6,.6,1),e=A.P.New(1,1,1)
this.tween_left.SetFrom(t),this.tween_left.SetTo(e),this.tween_left.ResetToBeginning(),this.tween_left.AddEventHandler(this.CreateDelegate(this.OnScaleEnd)),
this.tween_left.PlayForward(),this.tween_right.SetFrom(t),this.tween_right.SetTo(e),this.tween_right.ResetToBeginning(),this.tween_right.PlayForward(),A.P.Recyle(t),A.P.Recyle(e)}
OnScaleEnd(){this.tween_left.RemoveEventHandler(this.CreateDelegate(this.OnScaleEnd)),this.StartPlay()}}class _t extends K.f{constructor(...t){super(...t),this.deep_offset=1,
this.is_playing=!1,this.anchor=null,this.offset=null,this.panel=null,this.ui_task_hide_view=null}InitView(){super.InitView(),this.anchor=this.CreateComponent(Y.T,1),
this.offset=this.CreateComponent(x.z,2),this.panel=this.CreateComponent(q.$,3),this.ui_task_hide_view=this.CreateComponentBinder(dt,4)}OnAddToScene(){this.AddLis(),
J.O.SetAnchorPos(this.anchor,null,!0,-2,!0),this.PlayEffectShow()}AddLis(){X.O.Inst_get().AddEventHandler(b.M.TASK_HIDE_FINISH,this.CreateDelegate(this.OnAddTask)),
X.O.Inst_get().AddEventHandler(b.M.TASK_HIDE_SHOW_END,this.CreateDelegate(this.OnShowEnd))}RemoveLis(){
X.O.Inst_get().RemoveEventHandler(b.M.TASK_HIDE_FINISH,this.CreateDelegate(this.OnAddTask)),
X.O.Inst_get().RemoveEventHandler(b.M.TASK_HIDE_SHOW_END,this.CreateDelegate(this.OnShowEnd))}Clear(){super.Clear(),this.RemoveLis(),this.deep_offset=1}Destroy(){super.Destroy()}
OnAddTask(t){this.PlayEffectShow()}OnShowEnd(){this.is_playing=!1,this.PlayEffectShow()}PlayEffectShow(){if(this.is_playing)return
if(0==$.ins.finish_hide_list.Count())return void xt.ins.ChangeShowMainUITask()
this.is_playing=!0
const t=$.ins.finish_hide_list[0]
$.ins.finish_hide_list.RemoveAt(0),this.ui_task_hide_view.start_deep=this.panel.depth()+this.deep_offset,this.ui_task_hide_view.deep_offset=this.deep_offset+3,
this.ui_task_hide_view.SetData(t),this.ui_task_hide_view.ResetToPlay()}}var ut=i(16950)
class It{constructor(t){this.questId=0,this.playerId=null,this.item=null,this.questId=t.questId,this.playerId=t.playerId,this.item=t.item}}
var ct,gt,pt,mt,St,Tt,ft,Ct,Et,At,Lt,yt=i(54918),Dt=i(38836),Ot=i(6665),Rt=i(9776),Nt=i(5494),Mt=i(98130),wt=i(72785),Pt=i(63076),vt=i(72800),kt=i(37648),Ut=i(55492),Gt=i(33138),Ft=i(26348),Bt=i(8211),Ht=i(95406)
class Vt extends K.f{constructor(...t){super(...t),this.equipName=null,this.item=null,this.countdown=null,this.accessGrid=null,this.scrollviewscroll=null,this.scrollview=null,
this.closelBtn=null,this.taskname=null,this.isFromTaskAccess=!1,this.model=null,this.canscroll=null}InitView(){super.InitView(),this.equipName=this.CreateComponent(et.Q,1),
this.item=this.CreateComponentBinder(lt.j,2),this.countdown=this.CreateComponent(et.Q,10),this.accessGrid=this.CreateComponent(Ot.A,11),
this.scrollviewscroll=this.CreateComponent(Rt.h,12),this.scrollview=this.CreateComponent(q.$,13),this.closelBtn=this.CreateComponent(z.W,14),
this.taskname=this.CreateComponent(et.Q,15),this.accessGrid.SetInitInfo("ui_obtain_rywayitem",null,Ht.j)}OnAddToScene(){this.AddLis(),this.SetData()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.closelBtn,this.CreateDelegate(this.CloseHandler))}CloseHandler(){p.N.inst.CloseById(Nt.I.TaskEquipCollectGuidePanel)}RemoveLis(){}SetData(){
this.model=v.w.Inst_get()
let t=null
this.model.clickItemId>0&&(t=Gt.f.Inst().getItemById(this.model.clickItemId))
const e=new Pt.M(this.model.clickItemId,null)
e.IconType_Set(at.s.BASE_ICON_BAG_TYPE),e.isCanOperate=!1,this.item.SetData(e),this.taskname.textSet(this.GetTaskStr()),this.equipName.textSet(e.GetNameStr())
let i=v.w.Inst_get().wayList
if(null==i)if(i=new E.Z,null==t)wt.c.DebugError(`itemRes is null, clickItemId is:${C.M.IntToString(this.model.clickItemId)}`)
else for(const[e,s]of(0,Dt.V5)(t.AccessList_get()))if(Ft.Z.Inst().IsFunOpen(s)){if(5==Ft.Z.Inst().getItemById(s).type){const t=Ft.Z.Inst().GetParamsListById(s)
let e=!1,n=0
for(;n<t.Count();){null==Bt.N.GetInst().GetInfo(t[n])?wt.c.DebugError((0,W.T)("获取途径参数找不到商城数据,获取途径ID:")+(s+((0,W.T)(" 商城ID：")+t[n]))):e=!0,n+=1}e&&i.Add(s)}else i.Add(s)}
i=this.FilterList(i),i.Sort(this.CreateDelegate(this.SortAccessList))
const s=this.CreateAccessDataList(i)
this.accessGrid.data_set(s),this.scrollviewscroll.SetEnabled(s.Count()>4),this.canscroll=s.Count()>4}CreateAccessDataList(t){const e=new E.Z
for(let i=0;i<=t.Count()-1;i++){const s=t[i]
1e4!=Ft.Z.Inst().getItemById(s).type&&e.Add(s)}return e}GetTaskStr(){const t=F.Y.GetLinkInfo(v.w.Inst_get().taskCfg)
return t.GetTxtLabel()+t.GetProgressLabel()}SortAccessList(t,e){const i=Ft.Z.Inst().getItemById(C.M.String2Int(t)),s=Ft.Z.Inst().getItemById(C.M.String2Int(e))
let n=this.SortByActivite(i,s)
return 0!=n?n:(n=this.SortByRecommend(i,s),0!=n||(n=this.SortByRank(i,s)),n)}SortByActivite(t,e){const i=Ft.Z.Inst().IsFunOpen(t.id),s=Ft.Z.Inst().IsFunOpen(e.id)
return i&&!s?-1:!i&&s?1:0}SortByRecommend(t,e){return 1==t.recommend&&1!=e.recommend?-1:1!=t.recommend&&1==e.recommend?1:0}SortByRank(t,e){return t.rank>e.rank?-1:t.rank<e.rank?1:0
}FilterList(t){if(this.isFromTaskAccess){const e=new E.Z,i=t.Count()
let s=0
for(;s<i;){const i=Mt.GF.INT(t[s]),n=Ft.Z.Inst().getItemById(i)
let l=!1
if(kt.P.Inst_get().IsFunctionOpened(n.type))if(1==n.judgeDaily){let i=0
n.type==Ut.x.DEMON_SQUARE&&(i=O.p.inst.GetLeftCount(vt.S.Belial),l=i>0),n.type==Ut.x.BLOOD_CASTLE&&(i=O.p.inst.GetLeftCount(vt.S.BloodTown),l=i>0),l&&e.Add(t[s])}else e.Add(t[s])
s+=1}return e}return t}Clear(){this.RemoveLis(),v.w.Inst_get().wayList=null,v.w.Inst_get().clickItemId=0,v.w.Inst_get().taskCfg=null,super.Clear()}Destroy(){super.Destroy(),
this.equipName=null,this.item=null,this.countdown=null,this.accessGrid=null,this.scrollviewscroll=null,this.scrollview=null,this.closelBtn=null,this.taskname=null}Test1(){return!0}
S_Test(){return!0}}function bt(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let xt=(ct=(0,n.GH)(M.k.SM_CanAcceptQuestsInfo),gt=(0,n.GH)(M.k.SM_FinishQuests),pt=(0,n.GH)(M.k.SM_QuestsRemove),
mt=(0,n.GH)(M.k.SM_QuestsAdd),St=(0,n.GH)(M.k.SM_AcceptQuestOnItem),Tt=(0,n.GH)(M.k.SM_QuestsInfo),ft=(0,n.GH)(M.k.SM_DrawQuestReward),Ct=(0,n.GH)(M.k.SM_UpdateQuests),Et=(0,
n.GH)(M.k.SM_OpenUi),Lt=class t{static get ins(){return null==t._ins&&(t._ins=new t),t._ins}constructor(){this.finishEffectPanel=null,this.mainuiPanel=null,this.TaskTempView=null,
this._model=null,this._model=B.L.Inst_get().model,this.AddLis()}AddLis(){X.O.Inst_get().AddEventHandler(b.M.REWARD_ONE_TASK,this.CreateDelegate(this.OnRewardOneTask)),
X.O.Inst_get().AddEventHandler(b.M.TASK_HIDE_FINISH,this.CreateDelegate(this.ChangeShowMainUITask)),
o.i.Inst.AddEventHandler(y.g.MAP_LOGIN_LOAD_COMPELETE,this.CreateDelegate(this.ReqTask)),this.AddTopTaskLis()}OpenMainUI(){const t=C.M.IntToString(_.b.Inst.currentMapId_get())
if(m.p.Inst_get().IndexOfStr(m.p.Inst_get().taskResult_get(),t))return
if(null!=this.mainuiPanel&&this.mainuiPanel.isShow_get())return
const e=new c.v
e.positionType=T.$.eCustom,e.layerType=S.F.DefaultUI,e.ReLoginOrChangeRoleIsDestroy=!1,(0,l.Yp)(Nt.I.eTaskMainUI,e,this.CreateDelegate(this.CallMainUIComplete))}CreateDelegate(t){
return(0,L.r)(t,this)}CallMainUIComplete(t){}CallMainUIDestory(){g.g.DestroyUIObj(this.mainuiPanel),this.mainuiPanel=null}CloseMainUI(){(0,l.sR)(Nt.I.eTaskMainUI)}OpenTaskHideUI(){
const t=new c.v
t.layerType=S.F.DefaultUI,t.viewClass=_t,p.N.inst.OpenById(Nt.I.eTaskHideMainUI,null,null,t)}CloseTaskHideUI(){p.N.inst.CloseById(Nt.I.eTaskHideMainUI)}HideTaskMainUIPanel(t){
const e=p.N.inst.GetViewById(Nt.I.eTaskHideMainUI)
null!=e&&(t?e.node.transform.SetLocalPositionXYZ(0,-2e3,0):e.node.transform.SetLocalPositionXYZ(0,0,0))}OnRewardOneTask(t){
null!=t&&t.resource_get().completeSpecialEffects&&this.OpenFinishEffect()}ChangeShowMainUITask(){$.ins.finish_hide_list.Count()>0?(this.OpenTaskHideUI(),
k.e.ins.CloseTaskContractUI()):(this.CloseTaskHideUI(),U.$.ins.IsShowContractTaskTip()?k.e.ins.OpenTaskContractUI():k.e.ins.CloseTaskContractUI())}OpenFinishEffect(){
if(null!=this.finishEffectPanel&&this.finishEffectPanel.isShow_get())return
const t=new c.v
t.layerType=S.F.Tip,t.isSetActiveClose=!1,p.N.inst.OpenById(Nt.I.TaskFinshEffect,this.CreateDelegate(this.CallFinishEffectComplete),this.CreateDelegate(this.CallFinishEffectDestory),t)
}CloseFinishEffectPanel(){p.N.inst.CloseById(Nt.I.TaskFinshEffect)}CallFinishEffectComplete(t){(0,l.Yp)(Nt.I.TaskFinshEffect)}CallFinishEffectDestory(){
g.g.DestroyUIObj(this.finishEffectPanel),this.finishEffectPanel=null}OpenTaskTempView(){const t=C.M.IntToString(_.b.Inst.currentMapId_get())
if(!m.p.Inst_get().IndexOfStr(m.p.Inst_get().taskTempResult_get(),t))if(null==this.TaskTempView){const t=new c.v
t.layerType=S.F.Msg,(0,l.Yp)(Nt.I.eTaskTempView,t)}else this.TaskTempView.OnAddToScene()}CloseTaskTempView(){
null==this.TaskTempView?p.N.inst.UnLoading(Nt.I.eTaskTempView):p.N.inst.CloseById(Nt.I.eTaskTempView)}OnTaskTempViewLoad(t){return t[0].getCNode(ut.W)}OnTaskTempViewDestroy(){
g.g.DestroyUIObj(this.TaskTempView),this.TaskTempView=null}GetTaskMainUIPanelAnchPosRefSpr(){
return null!=this.mainuiPanel&&this.mainuiPanel.isShow_get()&&null!=this.mainuiPanel.img_bg?this.mainuiPanel.img_bg:null}GetFuncItemPos(t){
return null!=this.mainuiPanel&&this.mainuiPanel.isShow_get()?this.mainuiPanel.GetItemPos(t):A.P.zero_get()}DoSpreadBtns(t){
null!=this.mainuiPanel&&this.mainuiPanel.isShow_get()&&this.mainuiPanel.DoSpreadBtns(t)}AddTopTaskLis(){
X.O.Inst_get().AddEventHandler(b.M.INFORM_DO_ADD,this.CreateDelegate(this.CheckAllTaskMetCondtion)),
X.O.Inst_get().AddEventHandler(b.M.ADD_TOP_TASK,this.CreateDelegate(this.CheckAllTaskMetCondtion))
a.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(r.A.LevelUpdate,this.CreateDelegate(this.CheckAllTaskMetCondtion)),
o.i.Inst.AddEventHandler(y.g.CHOOSE_SETTING_UPDATE,this.CreateDelegate(this.TopTaskSortListDataUpdate))}CheckAllTaskMetCondtion(){const t=X.O.Inst_get().GetAllQuestes(),e=t.Count()
let i=!1
const s=new E.Z
for(let n=0;n<=e-1;n++){const e=t[n],l=e.qVo
let r=f.o.ZERO
null!=l&&(r=l.playerId)
if(0==e.GetTopState()){if(F.Y.CheckIsMetCondtion(e.resource_get().top,r)||F.Y.CheckFullConditiones(e)){e.SetTopState(!0)
const t=a.Y.Inst.GetCreateIdxById(r)
s.Add(e.resource_get().id+(I.o.s_UNDER_CHAR+t)),i=!0}}}i&&(X.O.Inst_get().TopTaskSortListSet(s),X.O.Inst_get().RaiseEvent(b.M.TASK_TOP_CHANGE))}TopTaskSortListDataUpdate(){
X.O.Inst_get().TopTaskSortListUpdate(),this.CheckAllTaskMetCondtion()}OpenEquipCollectGuidePanel(t,e){const i=C.M.Split(t,";")
v.w.Inst_get().obtainType=P.v.OT_COMM
const s=new E.Z,n=C.M.Split(i[2],",")
for(let t=0;t<=n.Count()-1;t++)s.Add(C.M.String2Int(n[t]))
v.w.Inst_get().wayList=s,v.w.Inst_get().clickItemId=C.M.String2Int(i[1]),v.w.Inst_get().taskCfg=X.O.Inst_get().GetTaskById(C.M.String2Int(e),null)
const l=new c.v
l.viewClass=Vt,p.N.inst.OpenById(Nt.I.TaskEquipCollectGuidePanel,null,null,l)}GetTaskViewMainAddW(){if(null!=this.mainuiPanel){return this.mainuiPanel.GetContentAddW()}return 0}
ReqTask(){let t=new w.U
u.C.Inst.F_SendMsg(t),t=new N.F,u.C.Inst.F_SendMsg(t)}SM_CanAcceptQuestsInfoHandler(t){const e=t
if(e){if(this._model.canGetTasks&&this._model.canGetTasks.Count()>0)for(const t of this._model.canGetTasks){const e=this._model.GetJudgeDicIDByPlayerId(t.questId,t.playerId)
this._model.judgeDic.LuaDic_ContainsKey(e)&&this._model.judgeDic.LuaDic_Remove(e)}if(this._model.canGetTasks.Clear(),
e.canAcceptQuests&&e.canAcceptQuests.Count()>0)for(const t of e.canAcceptQuests){this._model.canGetTasks.Add(t)
const e=this._model.GetConfig(t.questId,t.playerId),i=this._model.GetJudgeDicIDByPlayerId(t.questId,t.playerId)
e&&(e.status_set(H.B.CAN_ACCEPT),this._model.judgeDic.LuaDic_ContainsKey(i)||this._model.judgeDic.LuaDic_AddOrSetItem(i,e))}}}SM_FinishQuestsHandler(t){const e=t
e&&this._model.DealRemveTask(e.questId,e.playerId,!0),F.Y.SendListRefresh()}SM_QuestsRemoveHandler(t){const e=t
if(e)for(const t of e.removes)this._model.DealRemveTask(t.questId,t.playerId,!1)}SM_QuestsAddHandler(t){const e=t
e&&this._model.DealAddTask(e.questList,null),this._model.RaiseEvent(b.M.SERVER_DO_ADD)}SM_AcceptQuestOnItemHandler(t){const e=t
if(e){const t=this._model.GetConfig(e.questId,e.playerId)
if(t&&this._model.GUIDE_TASK.Contains(t.id_get())&&t.resource_get().receiveType==V.U.RECEIVE_GET_ITEM){const t=new It(e)
O.p.inst.IsInCopy()?yt.Q.Inst_get().questDataList.Add(t):(d.S.getInst().InHang_get()&&(yt.Q.Inst_get().restoreHangState=!0),h._.getInst().endHang(),G.W.Inst_get().Open(t))}}}
SM_QuestsInfoHandler(t){const e=t
e&&this._model.InitServerData(e),this._model.RaiseEvent(b.M.TASK_INIT_END)}SM_DrawQuestRewardHandler(t){const e=t
MiniPlatController.sendClick(e.id)
const i=this._model.GetTaskById(e.id,null)
null!=i&&(this._model.RaiseEvent(b.M.REWARD_ONE_TASK,i),D.l.CheckTrigger(R.u.COND_TYPE_QUEST_FINISHED_VAL,e.id),
i.IsMainTask()&&D.l.CheckTrigger(R.u.COND_TYPE_QUEST_FINISH_NONEXT_VAL,e.id))}SM_UpdateQuestsHandler(t){const e=t
this._model.UpdateTaskData(e)}SM_OpenUiHandler(t){const e=t
p.N.inst.OpenUIByShortCutID(e.uiId,e.data)}},Lt._ins=null,bt(At=Lt,"ins",[s.n],Object.getOwnPropertyDescriptor(At,"ins"),At),
bt(At.prototype,"SM_CanAcceptQuestsInfoHandler",[ct],Object.getOwnPropertyDescriptor(At.prototype,"SM_CanAcceptQuestsInfoHandler"),At.prototype),
bt(At.prototype,"SM_FinishQuestsHandler",[gt],Object.getOwnPropertyDescriptor(At.prototype,"SM_FinishQuestsHandler"),At.prototype),
bt(At.prototype,"SM_QuestsRemoveHandler",[pt],Object.getOwnPropertyDescriptor(At.prototype,"SM_QuestsRemoveHandler"),At.prototype),
bt(At.prototype,"SM_QuestsAddHandler",[mt],Object.getOwnPropertyDescriptor(At.prototype,"SM_QuestsAddHandler"),At.prototype),
bt(At.prototype,"SM_AcceptQuestOnItemHandler",[St],Object.getOwnPropertyDescriptor(At.prototype,"SM_AcceptQuestOnItemHandler"),At.prototype),
bt(At.prototype,"SM_QuestsInfoHandler",[Tt],Object.getOwnPropertyDescriptor(At.prototype,"SM_QuestsInfoHandler"),At.prototype),
bt(At.prototype,"SM_DrawQuestRewardHandler",[ft],Object.getOwnPropertyDescriptor(At.prototype,"SM_DrawQuestRewardHandler"),At.prototype),
bt(At.prototype,"SM_UpdateQuestsHandler",[Ct],Object.getOwnPropertyDescriptor(At.prototype,"SM_UpdateQuestsHandler"),At.prototype),
bt(At.prototype,"SM_OpenUiHandler",[Et],Object.getOwnPropertyDescriptor(At.prototype,"SM_OpenUiHandler"),At.prototype),At)},98580:(t,e,i)=>{i.d(e,{B:()=>s})
class s{}s.NONE=0,s.READY=1,s.CAN_ACCEPT=2,s.ACCEPTED=3,s.FINISHED=4,s.FAIL=5,s.REWARDED=6},23296:(t,e,i)=>{i.d(e,{E:()=>s})
class s{}s.EXP="Exp",s.Item="Item",s.RuneItem="RuneItem",s.Currency="Currency",s.Title="Title",s.Attr="Attr",s.ASURAM_BUILDING_POINT="ASURAM_BUILDING_POINT",s.Skill="Skill",
s.Level="Level",s.WorldLevel="WorldLevel",s.ForgePoints="forgepoints",s.Courage="Courage",s.TaskType="TaskType",s.Quest="Quest",s.Map="Map",
s.AsuramContribution="AsuramContribution",s.Talent="Talent",s.MasterPoint="MASTER_POINT",s.QuestFinished="QuestFinished",s.TimeCard="TIMECARD",s.ActivityScore="ACTIVITY_SCORE",
s.FunctionOpen="FunctionOpen",s.GUAJI_EXP="GUAJI_EXP",s.Angel_Exp="ANGEL_EXP"},89803:(t,e,i)=>{i.d(e,{d:()=>s})
class s{}s.TALK="TALK",s.TALK_VALUE=1,s.KILL_MONSTER="KILL_MONSTER",s.KILL_MONSTER_VALUE=2,s.KILL_MONSTER_ITEM="KILL_MONSTER_ITEM",s.KILL_MONSTER_ITEM_VALUE=3,s.GATHER="GATHER",
s.GATHER_VALUE=4,s.TRANSPORT="TRANSPORT",s.TRANSPORT_VALUE=5,s.PASS_COPY="PASS_COPY",s.PASS_COPY_VALUE=6,s.MAP_TRANSPORTLINE_VALUE=8,s.GATHER_ITEM="GATHER_ITEM",
s.GATHER_ITEM_VALUE=10,s.COMPLETED_ACHIEVEMENT_NUM="COMPLETED_ACHIEVEMENT_NUM",s.COMPLETED_ACHIEVEMENT_NUM_VALUE=11,s.MONSTER_HUNT_MAP_VALUE=12,
s.KILL_MONSTER_RATE="KILL_MONSTER_RATE",s.KILL_MONSTER_RATE_VALUE=13,s.FICTITIOUS_ITEM="FICTITIOUS_ITEM",s.FICTITIOUS_ITEM_VALUE=14,s.CURRENCY="CURRENCY",s.CURRENCY_VALUE=15,
s.HAND_IN_ITEM="HAND_IN_ITEM",s.HAND_IN_ITEM_TYPE="HAND_IN_ITEM_TYPE",s.HAND_IN_ITEM_GROUP="HAND_IN_ITEM_GROUP",s.HAND_IN_EQUIPMENT="HAND_IN_EQUIPMENT",s.HAND_IN_NPC_TALK_VALUE=16,
s.EQUIPMENT_ENHANCE_TIME="EQUIPMENT_ENHANCE_TIME",s.EQUIPMENT_ENHANCE_TIME_VALUE=18,s.EQUIPMENT_ADD_TIME="EQUIPMENT_ADD_TIME",s.EQUIPMENT_ADD_TIME_VALUE=19,
s.COMPLETE_QUEST="COMPLETE_QUEST",s.COMPLETE_QUEST_VALUE=20,s.NEW_TITLE="NEW_TITLE",s.NEW_TITLE_VALUE=21,s.EQUIPMENT_EQUIP_EQUAL="EQUIPMENT_EQUIP_EQUAL",
s.EQUIPMENT_EQUIP="EQUIPMENT_EQUIP",s.EQUIPMENT_EQUIP_VALUE=22,s.MELTING_TIME="MELTING_TIME",s.MELTING_TIME_VALUE=23,s.GLOBING_MERCHAT_BUY="GLOBING_MERCHAT_BUY",
s.GLOBING_MERCHAT_BUY_VALUE=24,s.GLOBING_MERCHAT_REFRESH="GLOBING_MERCHAT_REFRESH",s.GLOBING_MERCHAT_REFRESH_VALUE=25,s.TRANSFER="TRANSFER",s.TRANSFER_VALUE=26,
s.ENTER_COPY="ENTER_COPY",s.ENTER_COPY_VALUE=27,s.FRIEND="FRIEND",s.FRIEND_VALUE=28,s.TEAM_TIME="TEAM_TIME",s.TEAM_TIME_VALUE=29,s.COMPOSE_TIME="COMPOSE_TIME",
s.COMPOSE_TIME_VALUE=30,s.SKILL_LEVEL_UP_TIME="SKILL_LEVEL_UP_TIME",s.SKILL_LEVEL_UP_TIME_VALUE=31,s.PASSIVE_SKILL_LEVEL_UP_TIME="PASSIVE_SKILL_LEVEL_UP_TIME",
s.PASSIVE_SKILL_LEVEL_UP_TIME_VALUE=32,s.EQUIPMENT_UP_STEP_LV_TIME="EQUIPMENT_UP_STEP_LV_TIME",s.EQUIPMENT_UP_STEP_LV_TIME_VALUE=33,s.AUCTION_ONSHELF_TIME="AUCTION_ONSHELF_TIME",
s.AUCTION_ONSHELF_TIME_VALUE=34,s.MARKET_SELL_TIME="MARKET_SELL_TIME",s.MARKET_SELL_TIME_VALUE=35,s.MARKET_BUY_TIME="MARKET_BUY_TIME",s.MARKET_BUY_TIME_VALUE=36,
s.IMMORTALS_DEBLOCK="IMMORTALS_DEBLOCK",s.IMMORTALS_DEBLOCK_VALUE=37,s.IMMORTALS_LEVEL_UP="IMMORTALS_LEVEL_UP",s.IMMORTALS_LEVEL_UP_VALUE=38,s.RUNE_NUM="RUNE_NUM",
s.RUNE_NUM_VALUE=39,s.ENTER_MAP="ENTER_MAP",s.ENTER_MAP_VALUE=40,s.EQUIPMENT_ENHANCE_LEVEL="EQUIPMENT_ENHANCE_LEVEL",s.EQUIPMENT_ENHANCE_LEVEL_VALUE=41,
s.PHOTO_POSITION="PHOTO_POSITION",s.PHOTOGRAPH_POSITION_VALUE=42,s.PHOTO_NPC="PHOTO_NPC",s.PHOTO_NPC_VALUE=43,s.PHOTO_MONSTER="PHOTO_MONSTER",s.PHOTO_MONSTER_VALUE=44,
s.PHOTO_PLAYER="PHOTO_PLAYER",s.PHOTO_PLAYER_VALUE=45,s.ONE_DRAGON="ONE_DRAGON",s.ONE_DRAGON_VALUE=46,s.UIGAME="UIGAME",s.UIGAME_VALUE=46,s.MULTI_QUEST="MULTI_QUEST",
s.MULTI_QUEST_VALUE=47,s.DAILY_VITALITY="DAILY_VITALITY",s.DAILY_VITALITY_VALUE=48,s.EXCELLENT_JEWELRY="EXCELLENT_JEWELRY",s.EXCELLENT_JEWELRY_VALUE=49,
s.SKILL_CULTIVATION="SKILL_CULTIVATION",s.SKILL_CULTIVATION_VALUE=50,s.POWER="POWER",s.POWER_VALUE=51,s.EQUIP_SECOND_WING_IGNORE="EQUIP_SECOND_WING_IGNORE",
s.EQUIP_SECOND_WING_IGNORE_VALUE=52,s.EQUIP_THIRD_WING_IGNORE="EQUIP_THIRD_WING_IGNORE",s.EQUIP_THIRD_WING_IGNORE_VALUE=53,s.ENHANCE_EQUIP_TOTAL="ENHANCE_EQUIP_TOTAL",
s.ENHANCE_EQUIP_TOTAL_VALUE=54,s.ADD_EQUIP_TOTAL="ADD_EQUIP_TOTAL",s.ADD_EQUIP_TOTAL_VALUE=55,s.SKILL_LEARN_OR="SKILL_LEARN_OR",s.SKILL_LEARN_OR_VALUE=56,
s.SKILL_LEVEL="SKILL_LEVEL",s.SKILL_LEVEL_VALUE=57,s.SKILL_TRAIN_LEVEL="SKILL_TRAIN_LEVEL",s.SKILL_TRAIN_LEVEL_VALUE=58,s.SUIT_EQUIP="SUIT_EQUIP",s.SUIT_NUM_LEVEL_VALUE=59,
s.ITEM_USE_TIME="ITEM_USE_TIME",s.ITEM_USE_TIME_VALUE=61,s.PRAY="PRAY",s.PRAY_VALUE=62,s.WORLD_CHAT="WORLD_CHAT",s.WORLD_CHAT_VALUE=64,s.JOIN_ASURAM="JOIN_ASURAM",
s.JOIN_ASURAM_VALUE=65,s.MEMBER_DONATE_TIME="MEMBER_DONATE_TIME",s.MEMBER_DONATE_TIME_VALUE=66,s.MASTER_POINT="MASTER_POINT",s.MASTER_POINT_VALUE=67,
s.TEM_NUM_HISTORY="TEM_NUM_HISTORY",s.TEM_NUM_HISTORY_VALUE=68,s.SKILL_LEVELUP="SKILL_LEVELUP",s.SKILL_LEVELUP_VALUE=69,s.WING_REFINE="WING_REFINE",s.WING_REFINE_VALUE=70,
s.ATTR_VALUE="ATTR_VALUE",s.ATTR_VALUE_VALUE=71,s.EXTRA_SKILL_LEVEL="EXTRA_SKILL_LEVEL",s.EXTRA_SKILL_LEVEL_VALUE=72,s.EQUIP_SCORE="EQUIP_SCORE",s.EQUIP_SCORE_VALUE=73,
s.WING_ENCHANCE="WING_ENCHANCE",s.WING_ENCHANCE_VALUE=74,s.AUCTION_TRADE="AUCTION_TRADE",s.AUCTION_TRADE_VALUE=75,s.ARENA_DAN="ARENA_DAN",s.ARENA_DAN_VALUE=76,
s.MARKET_TRADE="MARKET_TRADE",s.MARKET_TRADE_VALUE=77,s.ACHIEVEMENT_POINT="ACHIEVEMENT_POINT",s.ACHIEVEMENT_POINT_VALUE=78,s.ITEM_NUM_HISTORY="ITEM_NUM_HISTORY",
s.ITEM_NUM_HISTORY_VALUE=79,s.LEVEL="LEVEL",s.LEVEL_VALUE=80,s.COPY_ENCOURAGE_TIME="COPY_ENCOURAGE_TIME",s.COPY_ENCOURAGE_TIME_VALUE=81,s.FUNCTION_OPEN="FUNCTION_OPEN",
s.FUNCTION_OPEN_VALUE=82,s.CURRENCY_HISTORY="CURRENCY_HISTORY",s.CURRENCY_HISTORY_VALUE=83,s.LEARN_SKILL="LEARN_SKILL",s.LEARN_SKILL_VALUE=84,
s.ADD_PACK_SIZE_NUM="ADD_PACK_SIZE_NUM",s.ADD_PACK_SIZE_NUM_VALUE=85,s.REGISTRATION_TIME="REGISTRATION_TIME",s.REGISTRATION_TIME_VALUE=86,
s.EQUIPMENT_ENHANCE_TOTAL_LEVEL="EQUIPMENT_ENHANCE_TOTAL_LEVEL",s.EQUIPMENT_ENHANCE_TOTAL_LEVEL_VALUE=87,s.PLAYER_DEATH="PLAYER_DEATH",s.SEEK_TREASURE="SEEK_TREASURE",
s.PLAYER_DEATHL_VALUE=88,s.TREASURE_HUNT="TREASURE_HUNT",s.TREASURE_HUNT_VALUE=89,s.EQUIPMENT_CAST_TIME="EQUIPMENT_CAST_TIME",s.EQUIPMENT_CAST_TIME_VALUE=90,
s.AUCTION_BID_SUCC="AUCTION_BID_SUCC",s.AUCTION_BID_SUCC_VALUE=91,s.AUCTION_BID_FAIL="AUCTION_BID_FAIL",s.AUCTION_BID_FAIL_VALUE=92,s.AUCTION_BUY_ITEMNUM="AUCTION_BUY_ITEMNUM",
s.AUCTION_BUY_ITEMNUM_VALUE=93,s.AUCTION_DIMOND="AUCTION_DIMOND",s.AUCTION_DIMOND_VALUE=94,s.ACTIVITY_JOIN="ACTIVITY_JOIN",s.ACTIVITY_JOIN_VALUE=95,s.ARENA_RANK="ARENA_RANK",
s.ARENA_RANK_VALUE=96,s.AREAN_WIN_PERCENT="AREAN_WIN_PERCENT",s.AREAN_WIN_PERCENT_VALUE=97,s.VIP="VIP",s.VIP_VALUE=98,s.INVEST="INVEST",s.INVEST_VALUE=99,
s.TOTAL_RECHARGE_MONEY="TOTAL_RECHARGE_MONEY",s.TOTAL_RECHARGE_MONEY_VALUE=100,s.MEMORY_ACTIVE="MEMORY_ACTIVE",s.MEMORY_ACTIVE_VALUE=101,s.CURRENCY_BACK="CURRENCY_BACK",
s.HAND_IN_CURRENCY="HAND_IN_CURRENCY",s.CURRENCY_BACK_VALUE=102,s.NPC_SHOP_BUY="NPC_SHOP_BUY",s.NPC_SHOP_BUY_VALUE=103,s.PASSIVE_SKILL_TOTAL_LEVEL="PASSIVE_SKILL_TOTAL_LEVEL",
s.PASSIVE_SKILL_TOTAL_LEVEL_VALUE=104,s.LEARN_TRANSFER_SKILL="LEARN_TRANSFER_SKILL",s.LEARN_TRANSFER_SKILL_VALUE=105,s.EQUIP_EXCELLENT="EQUIP_EXCELLENT",
s.EQUIP_EXCELLENT_VALUE=106,s.EQUIP_STAR_EXCELLENT="EQUIP_STAR_EXCELLENT",s.EQUIP_STAR_EXCELLENT_VALUE=107,s.MIRACLECONTINENT_TALK="MIRACLECONTINENT_TALK",
s.MIRACLECONTINENT_TALK_VALUE=108,s.POINT_LEARN_SKILL="POINT_LEARN_SKILL",s.POINT_LEARN_SKILL_VALUE=109,s.SKILL_SLOT="SKILL_SLOT",s.SKILL_SLOT_VALUE=110,s.REAL_TALK="REAL_TALK",
s.REAL_TALK_VALUE=111,s.ONE_QUEST="ONE_QUEST",s.ONE_QUEST_VALUE=112,s.SET_AUTO_MELTING="SET_AUTO_MELTING",s.SET_AUTO_MELTING_VALUE=115,s.ASURAM_EQUIP_DONATE="ASURAM_EQUIP_DONATE",
s.ASURAM_EQUIP_DONATE_VALUE=116,s.ASURAM_EXCHANGE="ASURAM_EXCHANGE",s.ASURAM_EXCHANGE_VALUE=117,s.TRANSFER_JOB_TEST="TRANSFER_JOB_TEST",
s.TRANSFER_ACTIVE_STARCLOUD="TRANSFER_ACTIVE_STARCLOUD",s.TRANSFER_JOB_TEST_VALUE=118,s.KILL_MIRACLE_MONSTER="KILL_MIRACLE_MONSTER",s.KILL_MIRACLE_MONSTER_VALUE=119,
s.ASURAM_ENTRUST="ASURAM_ENTRUST",s.ASURAM_ENTRUST_VALUE=121,s.EXCHANGE_CONSIGN_SCORE="EXCHANGE_CONSIGN_SCORE",s.EXCHANGE_CONSIGN_SCORE_VALUE=123,
s.EXCHANGE_CONSIGN_SCORE_AND_LEARN_SKILL="EXCHANGE_CONSIGN_SCORE_AND_LEARN_SKILL",s.EXCHANGE_CONSIGN_SCORE_AND_LEARN_SKILL_VALUE=124,
s.EXCHANGE_CONSIGN_SCORE_AND_EQUIPMENT_EQUIP="EXCHANGE_CONSIGN_SCORE_AND_EQUIPMENT_EQUIP",s.EXCHANGE_CONSIGN_SCORE_AND_EQUIPMENT_EQUIP_VALUE=125,
s.DAILY_VITALITY_TOTAL="DAILY_VITALITY_TOTAL",s.DAILY_VITALITY_TOTAL_VALUE=126,s.CONSUME_CURRENCY="CONSUME_CURRENCY",s.CONSUME_CURRENCY_VALUE=127,
s.HISTORY_DIG_MINE_COUNT="HISTORY_DIG_MINE_COUNT",s.HISTORY_DIG_MINE_COUNT_VALUE=128,s.ROB_MINE_COUNT="ROB_MINE_COUNT",s.ROB_MINE_COUNT_VALUE=129,
s.CLIMB_TOWER_STAR="CLIMB_TOWER_STAR",s.CLIMB_TOWER_STAR_VALUE=130,s.EXCELLENCE_ADD_COUNT="EXCELLENCE_ADD_COUNT",s.EXCELLENCE_ADD_COUNT_VALUE=131,
s.UPGRADE_TALENT_LEVEL="UPGRADE_TALENT_LEVEL",s.UPGRADE_TALENT_LEVEL_VALUE=132,s.JIGSAW="JIGSAW",s.JIGSAW_VALUE=133,s.TRANSFER_EXP_BLESSING="TRANSFER_EXP_BLESSING",
s.TRANSFER_EXP_BLESSING_VALUE=134,s.KUNDUN_SEAL="KUNDUN_SEAL",s.KUNDUN_SEAL_VALUE=135,s.OCEAN_HEART="OCEAN_HEART",s.OCEAN_HEART_VALUE=136,s.ELEMENT_BOSS="ELEMENT_BOSS",
s.ELEMENT_BOSS_VALUE=137,s.JEW_NUM="JEW_NUM",s.JEW_NUM_VALUE=138,s.SELECT_TRANSFER_DIRECTION="SELECT_TRANSFER_DIRECTION",s.SELECT_TRANSFER_DIRECTION_VALUE=139,
s.HONOR_MANUAL_LEVEL="HONOR_MANUAL_LEVEL",s.HONOR_MANUAL_LEVEL_VALUE=140,s.ALL_ROLE_LEARN_SKILL_NUM="ALL_ROLE_LEARN_SKILL_NUM",s.ALL_ROLE_LEARN_SKILL_NUM_VALUE=141,
s.CLOSE_UI="CLOSE_UI",s.CLOSE_UI_VALUE=142,s.LYING_WALL="LYING_WALL",s.LYING_WALL_VALUE=143,s.SIT_DOWN="SIT_DOWN",s.SIT_DOWN_VALUE=144,
s.LEARN_TRANSFER_SKILL_ROLE_NUM="LEARN_TRANSFER_SKILL_ROLE_NUM",s.LEARN_TRANSFER_SKILL_ROLE_NUM_VALUE=145,s.EQUIPMENT_NUM="EQUIPMENT_NUM",s.EQUIPMENT_NUM_VALUE=146,
s.ITEM_NUM="ITEM_NUM",s.ITEM_NUM_VALUE=147,s.ITEM_GROUP_NUM="ITEM_GROUP_NUM",s.ITEM_GROUP_NUM_VALUE=148,s.REBIRTH="REBIRTH",s.REBIRTH_VALUE=149,s.CREATE_ROLE="CREATE_ROLE",
s.CREATE_ROLE_VALUE=150,s.ENHANCE_SUC_ONE_TIMES="ENHANCE_SUC_ONE_TIMES",s.ENHANCE_SUC_ONE_TIMES_VALUE=151,s.MONSTER_DROP_EQUIP="MONSTER_DROP_EQUIP",s.MONSTER_DROP_EQUIP_VALUE=152,
s.TODAY_DROP_SUIT_EQUIP="TODAY_DROP_SUIT_EQUIP",s.TODAY_DROP_SUIT_EQUIP_VALUE=153,s.MALL_BUY="MALL_BUY",s.MALL_BUY_VALUE=154,
s.FINISH_HONOR_MANUAL_TASK_NUM="FINISH_HONOR_MANUAL_TASK_NUM",s.FINISH_HONOR_MANUAL_TASK_NUM_VALUE=155,s.MULTI_HANG_TIME="MULTI_HANG_TIME",s.MULTI_HANG_TIME_VALUE=156,
s.DAILY_HONOR="DAILY_HONOR",s.DAILY_HONOR_VALUE=157,s.RIDING_NUM="RIDING_NUM",s.RIDING_NUM_VALUE=158,s.STALL_GOLD_NUM="STALL_GOLD_NUM",s.STALL_GOLD_NUM_VALUE=159,
s.TALENT_LEARN_NUM="TALENT_LEARN_NUM",s.TALENT_LEARN_NUM_VALUE=160,s.EQUIP_TOTAL_ADDLEVEL="EQUIP_TOTAL_ADDLEVEL",s.EQUIP_TOTAL_ADDLEVEL_VALUE=161,s.OUTLINE_TIME="OUTLINE_TIME",
s.OUTLINE_TIME_VALUE=162,s.STALL_BUY_NUM="STALL_BUY_NUM",s.STALL_BUY_NUM_VALUE=163,s.STALL_UP_NUM="STALL_UP_NUM",s.STALL_UP_NUM_VALUE=164,s.ROBOT_THROW_ITEM="ROBOT_THROW_ITEM",
s.ROBOT_THROW_ITEM_NUM=165,s.PASS_COPY_ROBOT="PASS_COPY_ROBOT",s.PASS_COPY_ROBOT_VALUE=166,s.LEVEL_CHANGE="LEVEL_CHANGE",s.LEVEL_CHANGE_VALUE=167,
s.APPOINT_ROLE_LEARN_SKILL_NUM="APPOINT_ROLE_LEARN_SKILL_NUM",s.APPOINT_ROLE_LEARN_SKILL_NUM_VALUE=168,s.EQUIPMENT_ENHANCE_CERTAIN_LEVEL="EQUIPMENT_ENHANCE_CERTAIN_LEVEL",
s.EQUIPMENT_ENHANCE_CERTAIN_LEVEL_VALUE=169,s.KILL_FIELD_MONSTER="KILL_FIELD_MONSTER",s.KILL_FIELD_MONSTER_VALUE=170,s.BOSS_STAMINA_REDUCE="BOSS_STAMINA_REDUCE",
s.BOSS_STAMINA_REDUCE_VALUE=171,s.SKILL_ALL_LEVEL="SKILL_ALL_LEVEL",s.SKILL_ALL_LEVEL_VALUE=172,s.ALL_ROLE_EXCELLENT_NUM="ALL_ROLE_EXCELLENT_NUM",
s.ALL_ROLE_EXCELLENT_NUM_VALUE=173,s.ASURAM_PARTY="ASURAM_PARTY",s.ASURAM_PARTY_VALUE=175,s.ASSIST="ASSIST",s.ASSIST_VALUE=176,s.ALL_ROLE_ADD_LEVEL="ALL_ROLE_ADD_LEVEL",
s.ALL_ROLE_ADD_LEVEL_VALUE=177,s.TOTAL_BATTLE_SCORE="TOTAL_BATTLE_SCORE",s.TOTAL_BATTLE_SCORE_VALUE=178,s.TALK_AND_PASS_COPY="TALK_AND_PASS_COPY",s.TALK_AND_PASS_COPY_VALUE=179,
s.UNLOCK_CHECKPOINT="UNLOCK_CHECKPOINT",s.UNLOCK_CHECKPOINT_VALUE=180,s.KILL_ASURAM_BOSS="KILL_ASURAM_BOSS",s.KILL_ASURAM_BOSS_VALUE=181,
s.ACCEPT_ASURAM_INTERACTION="ACCEPT_ASURAM_INTERACTION",s.ACCEPT_ASURAM_INTERACTION_VALUE=182,s.QUICK_BATTLE="QUICK_BATTLE",s.QUICK_BATTLE_VALUE=183,
s.ARENA_CHALLENGE="ARENA_CHALLENGE",s.ARENA_CHALLENGE_VALUE=184,s.PASS_MAP="PASS_MAP",s.PASS_MAP_VALUE=186,s.ALL_ROLE_STAR_NUM="ALL_ROLE_STAR_NUM",s.ALL_ROLE_STAR_NUM_VALUE=187,
s.BOUNTY_QUEST_NUM="BOUNTY_QUEST_NUM",s.BOUNTY_QUEST_VALUE=188,s.MEDAL_LEVEL_CHANG="MEDAL_LEVEL_CHANG",s.MEDAL_LEVEL_CHANG_VALUE=189,s.GOUI="GOUI",s.GOUI_VALUE=190,s.NONE="NONE",
s.NONE_VALUE=191,s.HANG_IN_MAX="HANG_IN_MAX",s.HANG_IN_MAX_VALUE=192,s.HANG_IN_FLY="HANG_IN_FLY",s.HANG_IN_FLY_VALUE=193,s.THEME_SCORE="THEME_SCORE",s.THEME_SCORE_VALUE=194,
s.SERVER_PASS_MAP="SERVER_PASS_MAP",s.ADD_UP_EXCELLENCE_NUM="ADD_UP_EXCELLENCE_NUM",s.ADD_UP_ENHANCE_LEVEL="ADD_UP_ENHANCE_LEVEL",s.ADD_UP_ADD_LEVEL="ADD_UP_ADD_LEVEL",
s.ADD_UP_BATTLE_SCORE="ADD_UP_BATTLE_SCORE",s.ADD_UP_SKILL_LEVEL="ADD_UP_SKILL_LEVEL",s.GOD_EQUIP_NUM="GOD_EQUIP_NUM",s.ADD_UP_HORSE_SCORE="ADD_UP_HORSE_SCORE",
s.GOD_EQUIP_SCORE="GOD_EQUIP_SCORE",s.DRAGON_TREASURE="DRAGON_TREASURE",s.GLORY_RANK_SCORE="GLORY_RANK_SCORE",s.ASURAM_DONATE="ASURAM_DONATE",s.ENTER_KARIMA="ENTER_KARIMA",
s.ASURAM_INTERACTION="ASURAM_INTERACTION"},84458:(t,e,i)=>{i.d(e,{V:()=>s})
class s{}s.FIND_PATH=1,s.ENTER_COPY_JUST=2,s.OPEN_PANEL=3,s.OPEN_COPY_PANEL=4,s.HAND_IN=5,s.OPEN_STRENG_PANEL=6,s.OPEN_BAG_PANEL=7,s.OPEN_SKILL_PANEL=8,s.OPEN_ACCESS_PANEL=9,
s.OPEN_BAG_MUTIL_PANEL=10,s.OPEN_CHAT_PANEL=11,s.OPEN_TRANSFER_TEST_PANEL=12,s.OPEN_SKILLANDTIPS_PANEL=13,s.SUGGEST_HANG=14,s.DERICT_BUY=15,s.TRANSMIT_PATH=16,
s.TRANSMIT_PATH_MAX=17,s.TRIGGER_GUIDE_BTN=18},63412:(t,e,i)=>{i.d(e,{U:()=>s})
class s{}s.RECEIVE_AUTO=1,s.RECEIVE_BY_NPC=2,s.RECEIVE_ITEM=3,s.RECEIVE_VIEW=4,s.RECEIVE_GET_ITEM=5,s.STORY_GET=6,s.INTERSECTION_AUTO=1,s.INTERSECTION_NPC=2,s.INTERSECTION_CLICK=3,
s.INTERSECTION_VIEW=4,s.NO_AUTO=0,s.AUTO_TASK=1,s.MOVE_TYPE_NO=0,s.MOVE_TYPE_GO=1,s.AUTO_SKIP_NO=0,s.AUTO_SKIP_GO=1,s.AUTO_TO_FINISH_NPC_NO=0,s.AUTO_TO_FINISH_NPC_GO=1,
s.AUTO_TO_FINISH_NPC_FLY=2},85890:(t,e,i)=>{i.d(e,{U:()=>n})
var s=i(86133)
class n{static GetName(t){return t==n.MAIN?(0,s.T)("主线任务"):t==n.BRANCH?(0,s.T)("支线任务"):t==n.CHANGE_JOB?(0,s.T)("转职任务"):t==n.MANUAL?(0,s.T)("手册任务"):t==n.REBIRTH?(0,
s.T)("转生任务"):t==n.CREATEROLE?(0,s.T)("创角任务"):t==n.ALLIANCE?(0,s.T)("战盟任务"):t==n.HIDE?(0,s.T)("隐藏任务"):t==n.BountyTask?(0,s.T)("赏金任务"):t==n.CONTRACT?(0,
s.T)("契约任务"):t==n.GOLD_SUIT_ROAD?(0,s.T)("神装之路"):t==n.JIGSAW?(0,s.T)("藏宝拼图"):t==n.JIGSAW_BOSS?(0,s.T)("藏宝BOSS"):""}static GetDialogFunIcon(t){
return t==n.MAIN?"huoqu_icon_0012":t==n.BRANCH?"huoqu_icon_0013":t==n.CHANGE_JOB?"huoqu_icon_0019":(n.BountyTask,"huodong_icon_0011")}}n.MAIN=1,n.BRANCH=2,n.CHANGE_JOB=3,
n.MANUAL=4,n.REBIRTH=5,n.CREATEROLE=6,n.ALLIANCE=7,n.HIDE=8,n.BountyTask=9,n.CONTRACT=10,n.GOLD_SUIT_ROAD=11,n.JIGSAW=12,n.JIGSAW_BOSS=13},15398:(t,e,i)=>{i.d(e,{M:()=>s})
class s{}s.REFRESH_MAIN_PANEL_LIST="refresh_main_panel_list",s.TASK_INIT_END="TASK_INIT_END",s.INFORM_DO_ADD="INFORM_DO_ADD",s.SERVER_DO_ADD="SERVER_DO_ADD",
s.INFORM_DO_UPDATA="INFORM_DO_UPDATA",s.INFORM_DO_REMOVE="INFORM_DO_REMOVE",s.REWARD_ONE_TASK="REWARD_ONE_TASK",s.DELAY_DO_ADD="DELAY_DO_ADD",s.TASK_STEP_CHANGE="TASK_STEP_CHANGE",
s.DO_UPDATA_TEMP_PANEL="DO_UPDATA_TEMP_PANEL",s.TASK_HIDE_FINISH="TASK_HIDE_FINISH",s.TASK_HIDE_SHOW_END="TASK_HIDE_SHOW_END",s.TASK_TOP_CHANGE="TASK_TOP_CHANGE",
s.TASK_ITEM_FLASH="TASK_ITEM_FLASH",s.ADD_TOP_TASK="ADD_TOP_TASK",s.FINISH_ONE_TASK="FINISH_ONE_TASK",s.REMOVE_ONE_TASK="REMOVE_ONE_TASK"},15601:(t,e,i)=>{
var s,n=i(6847),l=i(83908),a=i(46282),r=i(61911),o=i(5494),h=i(57651);(0,n.s_)(o.I.TaskFinshEffect,a.Z.ui_task_finish_effect_panel).register()(s=class extends((0,l.pA)(r.f)()){
constructor(...t){super(...t),this.interval=0,this.interval2=0,this.interval1=void 0}InitView(){super.InitView(),this.DestoryPanelLevel=r.f.DestoryLevel0}OnAddToScene(){
this.AddLis()}AddLis(){this.interval=this.m_handlerMgr.SetInterval(this.CreateDelegate(this.PlayEffect),200,1),
this.interval1=this.m_handlerMgr.SetInterval(this.CreateDelegate(this.OnPlayEnd),1400,1)}RemoveLis(){}Clear(){this.RemoveLis(),super.Clear()}Destroy(){}PlayEffect(){
this.pre_eff_quest_finish_1.node.SetActive(!0)}OnPlayEnd(){this.pre_eff_quest_finish_1.node.SetActive(!1),h.i.ins.CloseFinishEffectPanel()}})},99125:(t,e,i)=>{i.d(e,{I:()=>H})
var s=i(38836),n=i(98800),l=i(96098),a=i(97461),r=i(36241),o=i(5924),h=i(9057),d=i(85682),_=i(35128),u=i(98885),I=i(85602),c=i(38962),g=i(52212),p=i(79534),m=i(92679),S=i(87923),T=i(29839),f=i(85770),C=i(72800),E=i(2457),A=i(22662),L=i(6071),y=i(60128),D=i(68637),O=i(91690),R=i(21267),N=i(15821),M=i(65550),w=i(27363),P=i(79878),v=i(17783),k=i(83434),U=i(98580),G=i(85890),F=i(15398)
let B=null
class H extends h.x{constructor(...t){super(...t),this.task=null,this.collider_size=null,this.collider_offset=null,this.guaji=0,this.resized=!1,this.old_height=0,
this.text_max_width=H.TEXT_WIDTH,this.stepsnum=0,this.link_info=null,this.line_height=0,this.arrangeOneFlash=!1,this.added_role_events=null,this.is_next_line=void 0,
this._del_OnUpdateTask=null,this._del_OnItemFlash=null,this._del_PlayEffectLight=null,this._del_OnClickImgBg=null,this._del_TaskMainUIActiveHandler=null}static __StaticInit(){
B=new c.X,B.LuaDic_AddOrSetItem(G.U.MAIN,"rymainui_sp_0009"),B.LuaDic_AddOrSetItem(G.U.BRANCH,"rymainui_sp_0007"),B.LuaDic_AddOrSetItem(G.U.CHANGE_JOB,"rymainui_sp_0008"),
B.LuaDic_AddOrSetItem(G.U.REBIRTH,"rymainui_sp_0007"),B.LuaDic_AddOrSetItem(G.U.CREATEROLE,"rymainui_sp_0009"),B.LuaDic_AddOrSetItem(G.U.BountyTask,"rymainui_sp_0099")}
_initBinder(){super._initBinder(),this.collider_size=new g.F,this.collider_offset=new g.F,this.added_role_events=new I.Z}InitView(){super.InitView(),
this.img_bg.widthSet(H.WIDTH+30),this._del_OnUpdateTask=this.CreateDelegate(this.OnUpdateTask),this._del_OnItemFlash=this.CreateDelegate(this.OnItemFlash),
this._del_PlayEffectLight=this.CreateDelegate(this.PlayEffectLight),this._del_OnClickImgBg=this.CreateDelegate(this.OnClickImgBg),
this._del_TaskMainUIActiveHandler=this.CreateDelegate(this.TaskMainUIActiveHandler)}SetData(t){this.RemoveLis(),this.task=t,this.AddLis(),
this.text_name.textSet(this.task.traceName_get()),this.text_type.textSet(this.task.GetTypeSprite()),
null!=this.img_type&&this.img_type.spriteNameSet(B.LuaDic_GetItem(this.task.type_get())),this.UpdateTask(),this.PlayEffectLight()}AddLis(){
if(this.TaskModel_Get().AddEventHandler(F.M.INFORM_DO_UPDATA,this._del_OnUpdateTask),this.TaskModel_Get().AddEventHandler(F.M.TASK_STEP_CHANGE,this._del_OnUpdateTask),
this.TaskModel_Get().AddEventHandler(F.M.TASK_ITEM_FLASH,this._del_OnItemFlash),R.u.Inst().AddEventHandler(O.Z.UpdateMapPassInfo,this._del_PlayEffectLight),
a.i.Inst.AddEventHandler(N.i.NEWBIE_CLICK_TASK,this._del_OnClickImgBg),this.m_handlerMgr.AddClickEvent(this.node,this._del_OnClickImgBg),
this.TaskModel_Get().AddEventHandler(m.g.TASK_MIANUI_ACTIVE,this._del_TaskMainUIActiveHandler),null!=this.task){
const t=this.task.GetUpdateByRoleEvent(),e=this.task.GetUpdateByCommonEvent()
if(null!=t&&t.Count()>0){const e=n.Y.Inst.GetMultiPlayerInfo(this.task.qVo.playerId)
if(null!=e)for(const[i,n]of(0,s.V5)(t))this.added_role_events.Add(new I.Z([e,n,this.CreateDelegate(this.UpdateTask)])),e.AddEventHandler(n,this.CreateDelegate(this.UpdateTask),5)}
if(null!=e&&e.Count()>0)for(const[t,i]of(0,s.V5)(e))this.m_handlerMgr.AddEventMgr(i,this._del_OnUpdateTask,5)}this.RegGuide()}RemoveLis(){
this.TaskModel_Get().RemoveEventHandler(F.M.INFORM_DO_UPDATA,this._del_OnUpdateTask),this.TaskModel_Get().RemoveEventHandler(F.M.TASK_STEP_CHANGE,this._del_OnUpdateTask),
this.TaskModel_Get().RemoveEventHandler(F.M.TASK_ITEM_FLASH,this._del_OnItemFlash),
this.TaskModel_Get().RemoveEventHandler(m.g.TASK_MIANUI_ACTIVE,this._del_TaskMainUIActiveHandler),R.u.Inst().RemoveEventHandler(O.Z.UpdateMapPassInfo,this._del_PlayEffectLight),
a.i.Inst.RemoveEventHandler(N.i.NEWBIE_CLICK_TASK,this._del_OnClickImgBg)
for(let t=0;t<=this.added_role_events.Count()-1;t++)this.added_role_events[t][0].RemoveEventHandler(this.added_role_events[t][1],this.added_role_events[t][2])
this.added_role_events.Clear(),this.UnRegGuide(!1)}UnRegGuide(t){null!=this.task&&(D.c.Inst.UnRegGameObject(d.D.UI_TaskMainUI_ITEM,this.task.id_get(),t),
this.task.IsMainTask()&&D.c.Inst.UnRegGameObject(d.D.UI_TaskMainUI_ITEM,this.node,-1))}RegGuide(){
this.TaskModel_Get().taskMianUIHide||null!=this.task&&(D.c.Inst.RegGameObject(d.D.UI_TaskMainUI_ITEM,this.node,this.task.id_get()),
this.task.IsMainTask()&&D.c.Inst.RegGameObject(d.D.UI_TaskMainUI_ITEM,this.node,-1))}OnItemFlash(t){t.id_get()==this.task.id_get()&&(this.arrangeOneFlash=!0)}
TaskMainUIActiveHandler(t){t?this.UnRegGuide(!0):this.RegGuide()}Clear(){super.Clear(),this.RemoveLis(),o.C.Inst_get().Remove(this.CreateDelegate(this.UpdateTask)),
this.old_height=0,null!=this.link_info&&(this.link_info.Clear(),this.link_info=null)}Destroy(){super.Destroy()}UpdateTask(){this.node.active&&(this.UpdateDetail(),
this.PlayEffectLight(),this.Resize())}PlayEffectLight(){let t=!1,e=!1
;-1!=this.TaskModel_Get().show_new_list.IndexOf(this.task)?(this.TaskModel_Get().show_new_list.Remove(this.task),t=!0):this.task.status_get()==U.B.FINISHED&&(e=!0),
this.arrangeOneFlash&&(t=!0,this.arrangeOneFlash=!1),this.TaskModel_Get().Eff_TaskList.Contains(this.task.id_get())&&(e=!0),R.u.Inst().NowIsTaskLimit()&&(e=!0),
t||e?(this.effect_light_sp.SetActive(!0),this.effect_light_sp.transform.node.scale=new p.P(300/256,this.img_bg.height()/64,1),
t&&this.m_handlerMgr.SetInterval(this.CreateDelegate(this.OnPlayOnceEnd),600,1)):this.effect_light_sp.SetActive(!1)}PlayOnce(){this.effect_light_sp.SetActive(!0),
this.m_handlerMgr.SetInterval(this.CreateDelegate(this.OnPlayOnceEnd),600,1)}OnPlayOnceEnd(){this.effect_light_sp.SetActive(!1)}UpdateDetail(){
null!=this.link_info&&this.link_info.Clear(),this.link_info=P.Y.GetLinkInfo(this.task,null),this.is_next_line=!1,this.text_max_width=H.TEXT_WIDTH,
this.text_detail.widthSet(this.text_max_width),this.text_detail.textSet(this.link_info.GetTxtLabel()+this.link_info.GetProgressLabel()),this.line_height=this.text_detail.height(),
this.text_detail.textSet(this.link_info.GetTxtLabel())
let t=this.text_detail.text()
const e=this.task.GetNowStepsDic()
if(null!=e){for(const[i,n]of(0,s.V5)(e))t=n.GetCommonDes(t)
this.text_detail.textSet(t),e.LuaDic_Count()!=this.stepsnum&&(this.stepsnum=e.LuaDic_Count(),
this.task.status_get()==U.B.FINISHED||o.C.Inst_get().CallLater(this.CreateDelegate(this.PlayOnce)))}this.text_progress.textSet(this.link_info.GetProgressLabel()),
this.link_info.Clear()}Resize(){const t=this.old_height,e=H.TEXT_START_X+H.TEXT_WIDTH,i=new p.P
i.x=e
0==this.link_info.progresIndex?i.y=this.text_detail.node.transform.GetLocalPosition().y-this.line_height+22+(27.72-22):i.y=this.text_detail.node.transform.GetLocalPosition().y-22*(this.link_info.progresIndex-1)+(27.72-22),
this.text_progress.node.transform.SetLocalPosition(i),p.P.Recyle(i)
let s=_.p.Abs(this.text_progress.node.transform.GetLocalPosition().y-this.text_progress.height()-5)
const n=_.p.Abs(this.text_detail.node.transform.GetLocalPosition().y-this.text_detail.height()-5)
s=Math.max(s,n),this.old_height=s,this.img_bg.heightSet(s),this.ui_task_mainui_item.width=e,this.ui_task_mainui_item.height=s,
0!=t&&t!=this.old_height&&a.i.Inst.RaiseEvent(m.g.TASK_MAINUI_RESIZE)}Height_Get(){return this.ui_task_mainui_item.height}OnUpdateTask(t){
t.id_get()==this.task.id_get()&&o.C.Inst_get().CallLater(this.CreateDelegate(this.UpdateTask))}OnClickImgBg(){if(this.guaji=0,
null!=this.task)if(y.t.ins.IsForbidenScreen())M.y.inst.ClientSysMessage(105512)
else if(L.T.ins.Pause_Set(!0),!l.B.Inst.isOpenMaskStart){if(this.task.type_get()==G.U.MAIN&&this.task.status_get()!=U.B.ACCEPTED&&this.task.status_get()!=U.B.FINISHED){let t=""
return t=`${this.task.m_resource.minLevel}级开启此任务`,void M.y.inst.ClientStrMsg(A.r.SystemTipMessage,t)}
if(this.task.IsMainTask()&&S.l.CheckTrigger(E.u.COND_CLICK_BTN_VAL,d.D.UI_TaskMainUI_ITEM,-1),S.l.CheckTrigger(E.u.COND_CLICK_BTN_VAL,d.D.UI_TaskMainUI_ITEM,this.task.id_get()),
S.l.CheckTrigger(E.u.CLICK_UI_TASK_ITEM,this.task.id_get()),this.task.isClickReward_get())P.Y.SendToServer(this.task,null)
else if(null!=this.task){const t=this.task.GetCopyRes()
if(f.a.Inst_get().isStartExitCopy&&this.task.status_get()==U.B.FINISHED&&T.p.inst.IsInCopy()&&f.a.Inst_get().IsInPlotOrMapCopy())return void T.p.inst.ExitCopy()
if(null!=t&&t.controllerType==C.S.Plot&&T.p.inst.IsSameMapByMapID(u.M.String2Int(t.mapId))&&null!=t.SuccessConditions_get()&&null!=t.SuccessConditions_get().successConditionList){
const e=t.SuccessConditions_get().successConditionList[0]
if(null!=e.param)return this.guaji=e.guaji,void r._.getInst().startHang(null)}if(null!=this.task.GetNowStepsTarget()){
const t=k.f.GetLinkStr(this.task.GetNowStepsTarget(),null,this.task.id_get())
P.Y.GotoByLinkStr(t,!1,!1,!1,1,null,null)}else w.Y.inst.GotoTrigger(this.task)}}}TaskModel_Get(){return v.L.Inst_get().model}}H.WIDTH=300,H.HEIGHT=70,H.TEXT_WIDTH=252,
H.TEXT_START_X=35,H.ITEM_WIDTH=52},78651:(t,e,i)=>{
var s,n=i(18998),l=i(75507),a=i(38836),r=i(5924),o=i(30849),h=i(18202),d=i(35128),_=i(85602),u=i(38962),I=i(86871),c=i(92679),g=i(99125)
n._decorator.ccclass("TaskMainUIList")(s=class extends o.C{constructor(...t){super(...t),this.taskDataList=void 0,this.showItemList=void 0,this.showDict=void 0,this.interval=-1,
this.item_pool=void 0,this._del_CallLayout=null}_initBinder(){super._initBinder(),this.taskDataList=new _.Z,this.showItemList=new _.Z,this.showDict=new u.X,this.item_pool=new _.Z,
this.InitHandlerMgr(),g.I.__StaticInit()}InitView(){super.InitView(),this._del_CallLayout=this.CreateDelegate(this.CallLayout)}data_set(t){this.SetData(t)}SetData(t){this.AddLis(),
this.taskDataList=t,this.CallLayout()}AddLis(){}RemoveLis(){}Clear(){super.Clear(),this.RemoveLis(),-1!=this.interval&&(r.C.Inst_get().ClearInterval(this.interval),
this.interval=-1)
for(const[t,e]of(0,a.V5)(this.showDict))e.Clear(),h.g.DestroyView(e)
this.showDict.Clear()
for(const[t,e]of(0,a.V5)(this.item_pool))e.Clear(),h.g.DestroyView(e)
this.item_pool.Clear()}Destroy(){super.Destroy()}CallLayout(){this.Layout()}Layout(){this.interval=-1,this.m_handlerMgr.RemoveEventMgr(c.g.TASK_MAINUI_RESIZE,this._del_CallLayout)
for(const[t,e]of(0,a.V5)(this.showDict))null==e&&this.showDict.LuaDic_Remove(t),-1==this.taskDataList.IndexOf(t)&&(e.node.SetActive(!1),this.item_pool.Count()<0?(e.Clear(),
this.item_pool.Add(e)):(e.Clear(),e.node.destroy()),this.showDict.LuaDic_Remove(t))
let t=0
for(let e=0;e<=this.taskDataList.Count()-1;e++){const i=this.taskDataList[e]
let s=this.showDict.LuaDic_GetItem(i)
null==s&&(s=this.GetShowItem(),this.showDict.LuaDic_AddOrSetItem(i,s))
const n=s.node.transform.GetLocalPosition()
s.SetData(i),s.node.transform.SetLocalPositionXYZ(n.x,t,0),t=t-s.Height_Get()-3}this.table_task.transform.width=g.I.WIDTH,this.table_task.transform.height=d.p.Abs(t),
this.table_task.transform.width=g.I.WIDTH,this.table_task.transform.height=d.p.Abs(t),this.m_handlerMgr.AddEventMgr(c.g.TASK_MAINUI_RESIZE,this._del_CallLayout)}GetTableHeight(){
return null==this.table_task?0:this.table_task.transform.height}GetShowItem(){let t=null
if(this.item_pool.Count()>0)t=this.item_pool.Pop(),t.node.SetActive(!0)
else{let e=l.o.getPrefab("ui_task_mainui_item")
t=new g.I((0,n.instantiate)(e)),(0,I.I)(t),this.m_handlerMgr.AddClearComponent(t,!1,!1)}return t.node.parent=this.node,t}})},70738:(t,e,i)=>{
var s,n=i(18998),l=i(6847),a=i(83908),r=i(46282),o=i(38836),h=i(98800),d=i(97960),_=i(5924),u=i(61911),I=i(85682),c=i(5494),g=i(60130),p=i(98885),m=i(85602),S=i(79534),T=i(77399),f=i(92679),C=i(73865),E=i(24205),A=i(57035),L=i(37648),y=i(55492),D=i(48946),O=i(17783),R=i(15398),N=i(99125)
;(0,l.s_)(c.I.eTaskMainUI,r.Z.ui_task_mainui_panel).waitPrefab(r.Z.ui_task_mainui_item).waitPrefab(r.Z.ui_guide_view).layerNav().register()(s=class extends((0,a.pA)(u.f)()){
constructor(...t){super(...t),this.is_hide=!1,this.isout=!1,this.funcItemList=null,this.is_tweening_hide=null,this.funcContainer=null,this._del_FunctionUpdateHandler=null,
this._del_UpdateTask=null,this._del_OnAddTask=null,this._del_OnRemoveTask=null,this._del_OnClickBtnHide=null}_initBinder(){super._initBinder(),this.funcItemList=new m.Z}InitView(){
super.InitView(),this.UpdateAnchors(null),this.DestoryPanelLevel=u.f.DestoryLevel0,this.FuncItemGrid.SetInitInfo("ui_funcopenitem",null,E.a),
this.FuncItemGrid.OnReposition_set(this.CreateDelegate(this.OnRepositionGrid)),this._del_FunctionUpdateHandler=this.CreateDelegate(this.FunctionUpdateHandler),
this._del_UpdateTask=this.CreateDelegate(this.UpdateTask),this._del_OnAddTask=this.CreateDelegate(this.OnAddTask),this._del_OnRemoveTask=this.CreateDelegate(this.OnRemoveTask),
this._del_OnClickBtnHide=this.CreateDelegate(this.OnClickBtnHide)}UpdateAnchors(t){g.O.SetAnchorPos(this.guide_parent,!0,!0,0,!0,null,0,78.11)}AddLis(){
this.m_handlerMgr.AddClickEvent(this.btn_hide,this._del_OnClickBtnHide),this.m_handlerMgr.AddEventMgr(f.g.UITweenStateChanged,this.CreateDelegate(this.OnUITweenStateChanged)),
this.m_handlerMgr.AddEventMgr(f.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors)),
this.m_handlerMgr.AddEventMgr(f.g.TIMELIMIT_ACTIVITY_UPDATE,this.CreateDelegate(this.FunctionUpdateHandler)),
this.m_handlerMgr.AddEventMgr(f.g.EnterMap,this.CreateDelegate(this.FunctionUpdateHandler)),
this.m_handlerMgr.AddEventMgr(f.g.FUNCTION_INIT_COMPLETE,this.CreateDelegate(this.FunctionUpdateHandler)),
this.m_handlerMgr.AddEventMgr(f.g.FUNCTION_OPEN,this.CreateDelegate(this.FunctionUpdateHandler)),
this.m_handlerMgr.AddEventMgr(f.g.FUNCTION_CLOSE,this.CreateDelegate(this.FunctionUpdateHandler)),
this.m_handlerMgr.AddEventMgr(f.g.FUNCTION_UPDATE,this.CreateDelegate(this.FunctionUpdateHandler)),
this.m_handlerMgr.AddEventMgr(f.g.GUIDE_START,this.CreateDelegate(this.ScrollTByGuide)),
h.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(d.A.AsuramIdUpdate,this._del_FunctionUpdateHandler),this.TaskModel_Get().AddEventHandler(R.M.TASK_INIT_END,this._del_UpdateTask),
this.TaskModel_Get().AddEventHandler(R.M.SERVER_DO_ADD,this._del_OnAddTask),this.TaskModel_Get().AddEventHandler(R.M.DELAY_DO_ADD,this._del_OnAddTask),
this.TaskModel_Get().AddEventHandler(R.M.INFORM_DO_REMOVE,this._del_OnRemoveTask),this.TaskModel_Get().AddEventHandler(R.M.TASK_TOP_CHANGE,this._del_UpdateTask),
this.TaskModel_Get().AddEventHandler(R.M.FINISH_ONE_TASK,this._del_UpdateTask)}RemoveLis(){this.m_handlerMgr.RemoveClickEvent(this.btn_hide,this._del_OnClickBtnHide),
this.TaskModel_Get().RemoveEventHandler(R.M.TASK_INIT_END,this._del_UpdateTask),this.TaskModel_Get().RemoveEventHandler(R.M.SERVER_DO_ADD,this._del_OnAddTask),
this.TaskModel_Get().RemoveEventHandler(R.M.DELAY_DO_ADD,this._del_OnAddTask),this.TaskModel_Get().RemoveEventHandler(R.M.INFORM_DO_REMOVE,this._del_OnRemoveTask),
this.TaskModel_Get().RemoveEventHandler(R.M.TASK_TOP_CHANGE,this._del_UpdateTask),this.TaskModel_Get().RemoveEventHandler(R.M.FINISH_ONE_TASK,this._del_UpdateTask),
h.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(d.A.AsuramIdUpdate,this._del_FunctionUpdateHandler)}OnAddToScene(){this.node.SetActive(!0),this.AddLis(),this.UpdatePanel(),
this.scroll_task.scrollTo(new n.Vec2(0,1)),this.bar.scrollTo(new n.Vec2(0,1))}Clear(){super.Clear(),this.RemoveLis(),this.isout=!1,this.table_task.Clear(),this.is_tweening_hide=!1}
Destroy(){super.Destroy(),this.table_task.Destroy()}ForcePlayAni(){this.OnUITweenStateChanged(this.isout,!0)}OnUITweenStateChanged(t,e){null==e&&(e=!1),
(this.isout!=t||e)&&(this.isout=t,this.node.visible=!t)}UpdatePanel(){this.UpdateTask(),this.UpdateBtnHide(),this.FunctionUpdateHandler()}UpdateTask(){
const t=this.GetShowTaskList()
t.Count()<=0?this.FuncItemFather.SetLocalPositionXYZ(380-N.I.WIDTH,0,0):this.FuncItemFather.SetLocalPositionXYZ(380,0,0),this.table_task.data_set(t),
this.scroll_task.content.transform.height=this.table_task.GetTableHeight(),this.scroll_task.scrollTo(new n.Vec2(0,1))}UpdateBtnHide(){const t=new S.P(1,1,1)
this.is_hide&&t.Set(-1,1,1),this.img_hide.node.scale=t,S.P.Recyle(t),O.L.Inst_get().model.taskMianUIHide=this.is_hide,
O.L.Inst_get().model.RaiseEvent(f.g.TASK_MIANUI_ACTIVE,this.is_hide,1)}GetShowTaskList(){const t=new m.Z,e=this.TaskModel_Get().GetReadyMainTask()
if(-1!=e){const i=this.TaskModel_Get().GetConfig(e,null)
i&&!this.TaskModel_Get().ExistTask(i)&&t.Add(i)}const i=this.TaskModel_Get().GetAllQuestes()
let s=0
for(;s<i.Count();){const e=i[s]
e.m_resource.hide||t.Add(e),s+=1}return t.Sort(((t,e)=>this.TaskModel_Get().TopTaskSort(t,e))),t}DoSpreadBtns(t){this.is_hide!=t&&this.OnClickBtnHide()}OnClickBtnHide(){
if(this.is_tweening_hide)return
this.is_hide=!this.is_hide,this.UpdateBtnHide()
let t=null,e=null
this.is_hide?(t=new S.P(0,0,0),e=new S.P(-N.I.WIDTH,0,0)):(t=new S.P(-N.I.WIDTH,0,0),e=new S.P(0,0,0)),this.is_tweening_hide=!0,S.P.Recyle(t),S.P.Recyle(e)}OnTweenHideEnd(){
this.is_tweening_hide=!1}OnAddTask(t){this.TaskModel_Get().show_new_list.Add(t),this.UpdateTask()}OnRemoveTask(){this.UpdateTask()}OnTaskResize(){
_.C.Inst_get().CallLater(this.CreateDelegate(this.RepositionTask))}RepositionTask(){this.table_task.node.position=new n.math.Vec3}TaskModel_Get(){return O.L.Inst_get().model}
FunctionUpdateHandler(){const t=this.GetDataList()
this.FuncItemGrid.data_set(t)}GetDataList(){const t=new m.Z,e=D.m.Inst_get().GetItemList()
for(let i=0;i<=e.Count()-1;i++){const s=e[i]
if(5==s.area_type){const e=A.d.Inst_get().GetItemByNameId(s.id)
if(null!=e&&L.P.Inst_get().IsFuncOrActivityOpened(e.id))if(e.id==y.x.TIME_LIMIT_FUNCTION_TOP){const i=T.x.Inst_get().GetTimelimitTip()
if(T.x.Inst_get().AddDebug(),i&&i.IsShowIcon()){let n=!1
const l=i.timeLimitType,a=T.x.Inst_get().GetTimeLimitRes(l)
if(a)if(1==a.AsuramLimit){h.Y.Inst.PrimaryRoleInfo_get().isHaveAlliance_get()&&(n=!0)}else n=!0
if(n){const i=C.y.Inst.CreateFuncItemData(s,e),n=p.M.String2Int(a.functionId)
if(L.P.Inst_get().IsFunctionOpened(n)){const e=A.d.Inst_get().getItemById(n)
null!=e&&(i.icon=e.activityIcon),t.Add(i)}}}}else t.Add(C.y.Inst.CreateFuncItemData(s,e))}}return t.Sort(this.CreateDelegate(this.SortFuncitem)),t}SortFuncitem(t,e){
return e.areaId-t.areaId}GetItemPos(t){const e=this.FuncItemGrid.itemList
if(null!=e&&e.Count()>0)for(const[i,s]of(0,o.V5)(e)){const e=s
if(e.IsFunction(t)){let t=e.getCenterPos()
return new S.P(t.x,t.y,t.z)}}return S.P.zero_get()}GetContentAddW(){return 0==this.FuncItemGrid.itemList.Count()?0:40}OnRepositionGrid(){if(!this.FuncItemGrid.itemList)return
const t=this.FuncItemGrid.itemList.Count()
let e=0
if(t>0)for(let i=0;i<=t-1;i++){const t=this.FuncItemGrid.itemList[i]
if(i>=1){const t=this.FuncItemGrid.itemList[i-1]
null!=t&&t.timeLab.node.active?e-=105:e-=76}t.node.position=new n.math.Vec3(0,e,0)}}ScrollTByGuide(t){
if(t.controlId==I.D.UI_TaskMainUI_ITEM&&null!=t.controlParam&&0!=t.controlParam){const e=this.TaskModel_Get().GetConfig(t.controlParam,null)
if(null!=e&&null!=this.table_task&&null!=this.table_task.showDict){const t=this.table_task.showDict.LuaDic_GetItem(e)
if(null!=t){const e=this.scroll_task_ui_panel.content.transform.height
let i=-t.node.y/e
this.scroll_task_ui_panel.scrollTo(new n.Vec2(0,1-i))}}}}})},44754:(t,e,i)=>{var s,n=i(18998),l=i(83908)
n._decorator.ccclass("TaskTempItem")(s=class extends((0,l.yk)()){constructor(...t){super(...t),this.config=null,this.step=0,this.completeHandler=null}InitView(){super.InitView(),
this.AddLis()}AddLis(){}RemoveLis(){}SetData(t,e){this.node.SetActive(!0),this.config=t,this.PanelTweenAlpha.SetIsEnabled(!0),this.decs.textSet(t.GetTemporaryShowStr()),
this.bg.heightSet(this.decs.height()+12),this.completeHandler=e}Clear(){this.RemoveLis(),this.completeHandler=null}Destroy(){}OnTewwnEnd(){this.PanelTweenAlpha.node.SetAlpha(0),
this.panel.node.SetAlpha(0),this.PanelTweenAlpha.SetIsEnabled(!1),this.config=null,null!=this.completeHandler&&this.completeHandler()}Test1(){return!0}S_Test(){return!0}})},
16950:(t,e,i)=>{i.d(e,{W:()=>m})
var s,n=i(6847),l=i(83908),a=i(46282),r=i(5924),o=i(66788),h=i(61911),d=i(5494),_=i(60130),u=i(85602),I=i(48933),c=i(57651),g=i(15398),p=i(99535)
let m=(0,n.s_)(d.I.eTaskTempView,a.Z.ui_task_temp_view).waitPrefab(a.Z.ui_task_temp_item).register()(s=class extends((0,l.pA)(h.f)()){constructor(...t){super(...t),this.pos=null,
this.items=null,this.timer=-1,this.targetPosY=40,this.content=null,this._curIndex=0,this.scrollIndex=2,this._count=0,this.moveHeight=null,this.initOffsetX=null}_initBinder(){
super._initBinder(),this.pos=new u.Z([-1,-47,-95]),this.items=new u.Z,this.content=new u.Z([0,0,0])}InitView(){super.InitView(),this.moveHeight=10,this.initOffsetX=this.offset.x,
this.items.Add(this.panel),this.items.Add(this.panel2),this.items.Add(this.panel3)}Clear(){this.RemoveLis(),super.Clear()}Destroy(){super.Destroy()}OnAddToScene(){
this._OnUpdateAnchor(),this.AddLis(),this.widget.SetActive(!1)
for(let t=0;t<=2;t++)this.items[t].SetActive(!1)}updateView(t){if(null!=t){this.widget.SetActive(!1),this.widget.SetActive(!0)
const e=c.i.ins.GetTaskViewMainAddW()
0!=e&&(this.offset.x=this.initOffsetX+e)
let i=this.GetItem(t)
null==i&&(i=this.items[this._curIndex],this._count+=1,this._count>3&&(this._count=3),this.resetPosY(this._curIndex),this._curIndex=this.addIndex(this._curIndex)),
i.SetData(t,this.CreateDelegate(this.CompleteHandler)),this._count>=3&&(this._count=3,this.HandleMove())}}CompleteHandler(){this._count-=1,this._count<0&&(this._count=0),
this.HandleMove()}HandleMove(){let t=2,e=-1
for(let i=0;i<=2;i++)e=this.GetStep(this.items[i]),this.items[i].step=e,null==this.items[i].config?(e<t&&(t=e),this.content[e]=0):this.content[e]=1
this.ResetAnim(),t<2&&(this.scrollIndex=t,this.timer=r.C.Inst_get().SetInterval(this.CreateDelegate(this.MoveAnimHandler),36),this.MoveAnimHandler())}GetStep(t){const e=t.node.y
for(let t=0;t<=2;t++){if(e>=this.pos[t+1]&&e<this.pos[t])return t+1
if(e>=this.pos[t])return t}return 0}GetNextPos(t){let e=t.step
for(;e>0;){if(e-=1,!(e>=0))return e
if(1==this.content[e])return e+1}return 0}addIndex(t){return 3==(t+=1)&&(t=0),t}MoveAnimHandler(){let t=!1,e=!1
if(-1!=this.scrollIndex){for(let i=0;i<=2;i++)if(null!=this.items[i].config&&this.items[i].step>this.scrollIndex){
const s=this.items[i].GetLocalPosition(),n=this.GetNextPos(this.items[i]),l=this.pos[n]
s.y+=this.moveHeight,null==l?o.Y.LogError(`tasktempview位置出错了${n}`):s.y>=l&&(s.y=l,t=!0),this.items[i].SetLocalPosition(s),e=!0}!t&&e||this.ResetAnim()}else this.ResetAnim()}
ResetAnim(){-1!=this.timer&&(r.C.Inst_get().ClearInterval(this.timer),this.timer=-1)}_OnUpdateAnchor(){_.O.SetAnchorPos(this.anchor,!0,!0,0,!1)}AddLis(){
p.O.Inst_get().AddEventHandler(g.M.DO_UPDATA_TEMP_PANEL,this.CreateDelegate(this.updateView))}RemoveLis(){for(let t=0;t<=this.items.Count()-1;t++)this.items[t].Clear()
this.m_handlerMgr.Clear(),p.O.Inst_get().RemoveEventHandler(g.M.DO_UPDATA_TEMP_PANEL,this.CreateDelegate(this.updateView))}GetItem(t){
for(let e=0;e<=2;e++)if(null!=this.items[e].config&&this.items[e].config.id_get()==t.id_get())return this.items[e]
return null}resetPosY(t){I.I.calVec0.Set(0,0,0),this.widget.SetLocalPosition(I.I.calVec0)
let e=null,i=this._count-1
for(;i>=0;)e=this.items[t],null!=e&&(I.I.calVec0.Set(e.node.x,this.pos[i],0),e.node.position=I.I.calVec0),(t-=1)<0&&(t=2),i-=1}})||s},47963:(t,e,i)=>{i.d(e,{c:()=>C})
var s=i(82815),n=i(77546),l=i(98800),a=i(57121),r=i(36241),o=i(19176),h=i(68662),d=i(5924),_=i(98885),u=i(85602),I=i(87923),c=i(29839),g=i(87048),p=i(98580),m=i(89803),S=i(85890),T=i(79878),f=i(17783)
class C{constructor(){this.m_isAuto=!0,this._curConfig=null,this.m_isGiveupCourse=!1,this.m_autoId=-1,this.waitPickFinish=!1,this._degf_AutoTask=null,
this._degf_OnResetGiveupParam=null,this._oldConfig=null,this._degf_AutoTask=()=>this.AutoTask(),this._degf_OnResetGiveupParam=()=>this.OnResetGiveupParam()}isAuto_get(){
return this.m_isAuto}isAuto_set(t){this.m_isAuto=t,this.m_isAuto||null!=this._curConfig&&(this._curConfig.isHanging=!1)}static Inst_get(){return null==C._inst&&(C._inst=new C),
C._inst}autoTask_get(){return this._curConfig}autoTask_set(t){this.isAuto_set(!0),null!=this._curConfig&&(this._oldConfig=this._curConfig),this._curConfig=t}isGiveupCourse_set(t){
this.m_isGiveupCourse=t,d.C.Inst_get().SetInterval(this._degf_OnResetGiveupParam,100,1)}OnResetGiveupParam(){this.m_isGiveupCourse=!1}GotoAuto(){if(!this.m_isGiveupCourse){
if(c.p.inst.IsInCopy()){}this.m_autoId<0&&(this.m_autoId=d.C.Inst_get().SetInterval(this._degf_AutoTask,300,1))}}CanCollection(){const t=this.isAuto_get()
if(h.D.IsDebugCollect()&&(t?null==this._curConfig&&n.s.Info("AutoTaskCollect CanCollection _curConfig is null"):n.s.Info("AutoTaskCollect CanCollection _isAuto is false")),
t&&null!=this._curConfig&&(h.D.IsDebugCollect()&&(this._curConfig.isCollection_get()?this._curConfig.status_get()!=p.B.ACCEPTED&&n.s.Info("AutoTaskCollect _curConfig status_get is not MyTaskStatus.ACCEPTED"):n.s.Info("AutoTaskCollect _curConfig isCollection_get is false")),
this._curConfig.isCollection_get()&&this._curConfig.status_get()==p.B.ACCEPTED)){const t=this._curConfig.qVo
if(h.D.IsDebugCollect()&&(null==t?n.s.Info("AutoTaskCollect qVo is null"):null==t.targets&&n.s.Info("AutoTaskCollect qVo.targets is null")),null!=t&&null!=t.targets){let e=0
for(;e<t.targets.count;){if(t.targets[e].value_get()>0)return!0
e+=1}h.D.IsDebugCollect()&&(0==t.targets.count?n.s.Info("AutoTaskCollect qVo.targets.count is 0"):n.s.Info("AutoTaskCollect qVo.targets value is lq 0"))}}return!1}RemovetTask(t){
t==this._curConfig&&(null!=this._curConfig&&(this._oldConfig=this._curConfig),this._curConfig=null)}AutoTask(){c.p.inst.IsInCopy()&&(this.m_autoId=-1),this.m_autoId=-1,
this.CheckExcuteAutoTask()}CheckExcuteAutoTask(){if(this.isAuto_get()&&(this.waitPickFinish=!1,null!=this._curConfig)){const t=f.L.Inst_get().model
if((this._curConfig.IsFinishOrRewarded()&&this._curConfig.isKillTask_get()||null!=this._oldConfig&&this._oldConfig.isKillTask_get()&&t.IsTaskCompleted(this._oldConfig.id_get(),l.Y.Inst.PrimaryRoleInfo_get().m_id))&&a.M.Inst.hasNeedPick_get())return this.waitPickFinish=!0,
r._.getInst().endHang(),l.Y.Inst.CurTarget_set(null),void l.Y.Inst.AddAllPlayerAI(s.R.autoTaskDropCatch)
this.ExcuteAutoTask()}}ExcuteAutoTask(){if(this._oldConfig=null,this.waitPickFinish=!1,null!=this._curConfig){
if(I.l.IsEmptyStr(this._curConfig.linkStr)&&T.Y.GetLinkInfo(this._curConfig,null),I.l.IsEmptyStr(this._curConfig.linkStr))return
if(c.p.inst.IsInCopy())return
T.Y.GotoByTask(this._curConfig,null,!0,!0)}}DispathHang(){
if(null!=this._curConfig&&(!this._curConfig.autoUseHang||this._curConfig.type_get()==S.U.CHANGE_JOB&&this._curConfig.isKillTask_get())){
if(this._curConfig.isKillTask_get()||this._curConfig.tCTargetDefs_get().tCTargetDefs[0].type==m.d.KILL_MIRACLE_MONSTER){
if(this._curConfig.tCTargetDefs_get().tCTargetDefs[0].param.monsterId>0){const t=new u.Z(1)
t[0]=this._curConfig.tCTargetDefs_get().tCTargetDefs[0].param.monsterId,o.S.getInst().hangMonsterId=t
}else if(this._curConfig.tCTargetDefs_get().tCTargetDefs[0].param.monsterGroupId>0){
let t=g.$.Inst_get().GetItemCfg(this._curConfig.tCTargetDefs_get().tCTargetDefs[0].param.monsterGroupId).objectIds
t=_.M.SubStringWithLen(t,1,_.M.Length(t)-2),t=_.M.Replace(t,_.M.s_RIGHT_M_K_CHAR_REPLACE,"")
const e=_.M.Split(t,_.M.s_Arr_SPAN_CHAR_DOT),i=new u.Z(e.count)
let s=0
for(;s<e.count;)i[s]=_.M.String2Int(e[s]),s+=1
o.S.getInst().hangMonsterId=i}}else o.S.getInst().hangMonsterId=null
r._.getInst().startHang()}}}C._inst=null},23765:(t,e,i)=>{i.d(e,{W:()=>ct})
var s=i(98800),n=i(36241),l=i(41664),a=i(5924),r=i(56937),o=i(18202),h=i(31222),d=i(5494),_=i(95721),u=i(63076),I=i(3859),c=i(4794),g=i(5031),p=i(682),m=i(54918)
class S{}S.NoView=0,S.NoExeEquipView=1,S.ExeEquipView=2,S.SkillView=3,S.SuitEquipView=4
var T=i(38836),f=i(86133),C=i(86094),E=i(80443),A=i(76544),L=i(66788),y=i(62063),D=i(99294),O=i(6665),R=i(32759),N=i(93877),M=i(3522),w=i(61911),P=i(60130),v=i(98885),k=i(85602),U=i(79534),G=i(99864),F=i(1003),B=i(87923),H=i(44498),V=i(11751),b=i(39367),x=i(13375),q=i(42534),Y=i(33138),K=i(81629),J=i(17783)
class Q{}Q.SpreadStep=0,Q.StaticShowStep=1,Q.EndAnimeStep=2
class Z extends w.f{constructor(){super(),this.equipName=null,this.m_item=null,this.excellenceGrid=null,this.baseModule=null,this.flashEffect=null,this.itemEffect=null,
this.dissappearEffect=null,this.explodeEffect=null,this.flameEffect=null,this.countdown=null,this.disappearAnime=null,this.emergeAnime=null,this.flyTweenPos=null,
this.desEffect=null,this.firePanel=null,this.fire1Eff=null,this.fire2Eff=null,this.delayExecutor=null,this.sModel=null,this.IsRespondClick=!1,this.countDownNum=5,
this.countDownHandleId=-1,this.clickHandleId=-1,this.loopId1=-1,this.loopId2=-1,this.loopId3=-1,this.loopId4=-1,this.baseData=null,this.taskConfig=null,this.step=0,
this.touchTapOrHold=0,this._degf_CountDown=null,this._degf_Fire2EffEnd=null,this._degf_HandleBeforeClose=null,this._degf_OnFlyFinished=null,this._degf_OnItemRefreshFun=null,
this._degf_OnTapOrHold=null,this._degf_PlayDisappearEffect=null,this._degf_PlayFire1Eff=null,this._degf_PlayFire2Eff=null,this._degf_PlayFireEff=null,
this._degf_PlayFrameEffect=null,this._degf_PlayItemEffect=null,this._degf_SetRespondClick=null,this._degf_SortAttr=null,this._degf_CountDown=()=>this.CountDown(),
this._degf_Fire2EffEnd=()=>this.Fire2EffEnd(),this._degf_HandleBeforeClose=()=>this.HandleBeforeClose(),this._degf_OnFlyFinished=()=>this.OnFlyFinished(),
this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),this._degf_OnTapOrHold=(t,e,i,s,n)=>this.OnTapOrHold(t,e,i,s,n),
this._degf_PlayDisappearEffect=()=>this.PlayDisappearEffect(),this._degf_PlayFire1Eff=()=>this.PlayFire1Eff(),this._degf_PlayFire2Eff=()=>this.PlayFire2Eff(),
this._degf_PlayFireEff=()=>this.PlayFireEff(),this._degf_PlayFrameEffect=()=>this.PlayFrameEffect(),this._degf_PlayItemEffect=()=>this.PlayItemEffect(),
this._degf_SetRespondClick=()=>this.SetRespondClick(),this._degf_SortAttr=(t,e)=>this.SortAttr(t,e)}InitView(){this.equipName=new N.Q,
this.equipName.setId(this.FatherId,this.FatherComponentID,1),this.m_item=new G.P,this.m_item.setBinderId(this.FatherId,this.FatherComponentID,2),this.excellenceGrid=new O.A,
this.excellenceGrid.setId(this.FatherId,this.FatherComponentID,3),this.baseModule=new V.$,this.baseModule.setBinderId(this.FatherId,this.FatherComponentID,4),
this.flashEffect=new D.z,this.flashEffect.setId(this.FatherId,this.FatherComponentID,5),this.itemEffect=new D.z,this.itemEffect.setId(this.FatherId,this.FatherComponentID,6),
this.dissappearEffect=new D.z,this.dissappearEffect.setId(this.FatherId,this.FatherComponentID,7),this.explodeEffect=new D.z,
this.explodeEffect.setId(this.FatherId,this.FatherComponentID,8),this.flameEffect=new D.z,this.flameEffect.setId(this.FatherId,this.FatherComponentID,9),this.countdown=new N.Q,
this.countdown.setId(this.FatherId,this.FatherComponentID,10),this.disappearAnime=new M.k,this.disappearAnime.setId(this.FatherId,this.FatherComponentID,11),
this.emergeAnime=new M.k,this.emergeAnime.setId(this.FatherId,this.FatherComponentID,12),this.flyTweenPos=new R.c,this.flyTweenPos.setId(this.FatherId,this.FatherComponentID,13),
this.desEffect=new D.z,this.desEffect.setId(this.FatherId,this.FatherComponentID,14),this.firePanel=new D.z,this.firePanel.setId(this.FatherId,this.FatherComponentID,15),
this.fire1Eff=new M.k,this.fire1Eff.setId(this.FatherId,this.FatherComponentID,16),this.StopAniEffect(this.fire1Eff),this.fire2Eff=new M.k,
this.fire2Eff.setId(this.FatherId,this.FatherComponentID,17),this.StopAniEffect(this.fire2Eff),this.delayExecutor=new A.p,P.O.AddUIEffectSortOrderBind(this.flashEffect),
P.O.AddUIEffectSortOrderBind(this.itemEffect),P.O.AddUIEffectSortOrderBind(this.dissappearEffect),P.O.AddUIEffectSortOrderBind(this.explodeEffect),
P.O.AddUIEffectSortOrderBind(this.flameEffect),P.O.AddUIEffectSortOrderBind(this.flyTweenPos.node),P.O.AddUIEffectSortOrderBind(this.desEffect),
this.excellenceGrid.SetInitInfo("ui_equiptip_excellenceattr",this._degf_OnItemRefreshFun),this.sModel=m.Q.Inst_get(),this.m_handlerMgr.AddClearComponentAlwaysCache(this.m_item)}
OnItemRefreshFun(t){const e=new x.N
return e.setId(t,null,0),e}Clear(){this.RemoveLis(),this.IsRespondClick=!1,this.countdown.node.SetActive(!1),this.ResetAnimeState(),this.ClearTimer(),this.taskConfig=null,
this.delayExecutor.Clear(),this.StopAniEffect(this.fire1Eff),this.StopAniEffect(this.fire2Eff)}Destroy(){this.m_item=null,this.equipName=null,this.excellenceGrid.Destroy(),
this.excellenceGrid=null,this.baseModule.Destroy(),this.baseModule=null,this.flashEffect=null,this.itemEffect=null,this.dissappearEffect=null,this.explodeEffect=null,
this.flameEffect=null,this.emergeAnime=null,this.disappearAnime=null,this.countdown=null,this.flyTweenPos=null,this.desEffect=null,this.firePanel=null,this.fire1Eff=null,
this.fire2Eff=null,this.delayExecutor=null}AddLis(){this.touchTapOrHold=E.f.AutoRegTouchState(this._degf_OnTapOrHold,3,"touchTapOrHold"),
this.flyTweenPos.AddEventHandler(this._degf_OnFlyFinished),P.O.AddUIEffectSortOrderBind(this.firePanel)}RemoveLis(){E.f.UnRegTouchState(this.touchTapOrHold),
this.flyTweenPos.RemoveEventHandler(this._degf_OnFlyFinished)}OnTapOrHold(t,e,i,s,n){return this.IsRespondClick&&(this.IsRespondClick=!1,this.PlayCloseAnimeAndEffect()),!0}
OnColliderClick(t,e){this.IsRespondClick&&(this.IsRespondClick=!1,this.PlayCloseAnimeAndEffect())}OnAddToScene(){K.K.inst.StopLoadEffect(),this.node.SetActive(!0,!0),
this.step=Q.SpreadStep,h.N.inst.CloseAllExclusivePanel(),this.RemoveLis(),this.AddLis(),this.countdown.node.SetActive(!1)
const t=m.Q.Inst_get().questDataList[0]
if(null==t)return void L.Y.LogError("异常")
const e=t.item
this.taskConfig=J.L.Inst_get().model.GetTaskById(t.questId),this.baseData=new u.M(e.modelId,e)
const i=e,n=C.C.GetData(e.modelId,i),l=Y.f.Inst().getItemById(e.modelId),r=q.f.Inst().getItemById(e.modelId)
let o=B.l.SetEquipName(n,l,i)[0]
i.suitId>0&&(o=v.M.ReplaceOne(o,v.M.s_SPACE_CHAR,v.M.s_NN_CHAR)),this.equipName.textSet(o),this.m_item.SetData(this.baseData),
this.baseModule.SetData(s.Y.Inst.PrimaryRoleInfo_get(),n,this.baseData,r,l,i,this,!1)
let d=0,_=null,I=null
let c=!1
const g=new k.Z
let p=null
if(null!=i&&null!=i.exellectAttrs&&(d=i.exellectAttrs.attributeDatas.Count()),0!=d)for(const[t,e]of(0,T.V5)(i.exellectAttrs.attributeDatas))_="",
2004==e.type?_="":2005==e.type?_="1/":2006==e.type&&(_=(0,f.T)("等级/")),p=new b.G,p.isStar=H.I.IsEquipAttrStar(n.Config_get(),e.type),p.job=l.job,
p.attrType_set(F.U.GetAttrNameByType(e.type)),p.isStar&&(c=!0),2004!=e.type&&2005!=e.type&&2006!=e.type?(I=`${(0,
f.T)("[58ed58]卓越 (")}${B.l.getAttrStrWithoutSign(e.type)} +${B.l.getAttrValueStr(e.type,e.value,!e.isPercentage)})[-]`,p.str=I,g.Add(p)):(I=`${(0,
f.T)("[58ed58]卓越 (")}${B.l.getAttrStrWithoutSign(e.type)} +${_}${B.l.getAttrValueStr(e.type,e.value,!e.isPercentage)})[-]`,p.str=I,g.Add(p))
g.Sort(this._degf_SortAttr)
let S=0
for(;S<g.Count();){g[S].hasAnyStar=c,S+=1}this.excellenceGrid.data_set(g),this.ResetAnimeState(),this.PlayOpenAnimeAndEffect(),
this.clickHandleId=a.C.Inst_get().SetInterval(this._degf_SetRespondClick,m.Q.Inst_get().RespondLimitTime_get(),1)}SortAttr(t,e){const i=t,s=e
return i.isShowStarCnt!=s.isShowStarCnt?1==i.isShowStarCnt&&0==s.isShowStarCnt?-1:1:i.isStar!=s.isStar?1==i.isStar&&0==s.isStar?-1:1:i.priority!=s.priority?i.priority<s.priority?-1:1:0
}SetRespondClick(){this.IsRespondClick=!0,this.countdown.node.SetActive(!0),this.countdown.textSet(`${(0,f.T)("[ceccc5]点击任意位置继续（")}${this.sModel.CountdownTime_get()}）[-]`),
this.countDownNum=this.sModel.CountdownTime_get(),this.countDownHandleId=a.C.Inst_get().SetInterval(this._degf_CountDown,1e3),this.step=Q.StaticShowStep}CountDown(){
this.countDownNum-=1,this.countdown.textSet(`${(0,f.T)("[ceccc5]点击任意位置继续（")}${this.countDownNum}）[-]`),this.countDownNum<=0&&(a.C.Inst_get().ClearInterval(this.countDownHandleId),
this.countdown.node.SetActive(!1),this.PlayCloseAnimeAndEffect())}ResetAnimeState(){this.flashEffect.SetActive(!1),this.itemEffect.SetActive(!1),
this.dissappearEffect.SetActive(!1),this.explodeEffect.SetActive(!1),this.flameEffect.SetActive(!1),this.flyTweenPos.node.SetActive(!1),this.flyTweenPos.SetEnabled(!1),
this.desEffect.SetActive(!1)}ClearTimer(){a.C.Inst_get().ClearInterval(this.clickHandleId),a.C.Inst_get().ClearInterval(this.countDownHandleId),
a.C.Inst_get().ClearLoop(this.loopId1),a.C.Inst_get().ClearLoop(this.loopId2),a.C.Inst_get().ClearLoop(this.loopId3),a.C.Inst_get().ClearLoop(this.loopId4)}
PlayOpenAnimeAndEffect(){this.emergeAnime.SetResetOnPlay(!0),this.emergeAnime.Play(!0,!1),this.flashEffect.SetActive(!0),this.explodeEffect.SetActive(!0),
this.loopId1=a.C.Inst_get().SetFrameLoop(this._degf_PlayFrameEffect,13,1),this.loopId2=a.C.Inst_get().SetFrameLoop(this._degf_PlayItemEffect,14,1)}PlayFrameEffect(){
this.flameEffect.SetActive(!1),this.flameEffect.SetActive(!0)}PlayItemEffect(){this.itemEffect.SetActive(!1),this.itemEffect.SetActive(!0)}PlayCloseAnimeAndEffect(){
a.C.Inst_get().ClearInterval(this.countDownHandleId),this.step=Q.EndAnimeStep,this.ResetAnimeState()
m.Q.Inst_get().questDataList.Count()>1?ct.Inst_get().OpenNext(S.ExeEquipView,!1):(this.disappearAnime.SetResetOnPlay(!0),this.disappearAnime.Play(!0,!1),
this.loopId3=a.C.Inst_get().SetFrameLoop(this._degf_PlayDisappearEffect,15,1))}PlayDisappearEffect(){this.dissappearEffect.SetActive(!1),this.dissappearEffect.SetActive(!0),
c.f.Inst_get().Close(),this.PlayFlyAnime()}PlayFlyAnime(){const t=U.P.zero_get()
this.flyTweenPos.node.SetActive(!0),this.flyTweenPos.SetFrom(t),this.flyTweenPos.SetTo(new U.P(-480,50,0)),this.flyTweenPos.durationSet(.5),this.flyTweenPos.SetEnabled(!0),
this.flyTweenPos.ResetToBeginning(),this.flyTweenPos.PlayForward()}OnFlyFinished(){this.desEffect.SetActive(!0),
this.loopId4=a.C.Inst_get().SetFrameLoop(this._degf_HandleBeforeClose,10,1)}HandleBeforeClose(){const t=m.Q.Inst_get().questDataList
t.Count()>1?ct.Inst_get().OpenNext(S.ExeEquipView,!0):(t.RemoveAt(0),ct.Inst_get().CloseExeEquipPanel())}PlayFireEff(){this.delayExecutor.InvokeFrame(this._degf_PlayFire1Eff,60),
this.delayExecutor.InvokeFrame(this._degf_PlayFire2Eff,95)}PlayFire1Eff(){this.PlayAniEffect(this.fire1Eff)}PlayFire2Eff(){this.PlayAniEffect(this.fire2Eff)}PlayAniEffect(t){
t==this.fire2Eff&&y.U.AddEventToFinishedHandler(this.fire2Eff.FatherId,this.fire2Eff.ComponentId,this._degf_Fire2EffEnd),t.node.SetActive(!0),t.SetResetOnPlay(!0),t.Play(!0,!1)}
StopAniEffect(t){t==this.fire2Eff&&y.U.RemoveEventFromFinishedHandler(this.fire2Eff.FatherId,this.fire2Eff.ComponentId,this._degf_Fire2EffEnd),t.node.SetActive(!1)}Fire2EffEnd(){
this.StopAniEffect(this.fire2Eff),this.delayExecutor.Invoke(this._degf_PlayFireEff,2500)}}class X extends w.f{constructor(){super(),this.item=null,this.equipName=null,
this.desc=null,this.baseModule=null,this.flashEffect=null,this.itemEffect=null,this.dissappearEffect=null,this.explodeEffect=null,this.flameEffect=null,this.countdown=null,
this.disappearAnime=null,this.emergeAnime=null,this.flyTweenPos=null,this.desEffect=null,this.firePanel=null,this.fire1Eff=null,this.fire2Eff=null,this.delayExecutor=null,
this.sModel=null,this.IsRespondClick=!1,this.countDownNum=5,this.countDownHandleId=-1,this.clickHandleId=-1,this.loopId1=-1,this.loopId2=-1,this.loopId3=-1,this.loopId4=-1,
this.baseData=null,this.taskConfig=null,this.step=0,this.touchTapOrHold=0,this._degf_CountDown=null,this._degf_Fire2EffEnd=null,this._degf_HandleBeforeClose=null,
this._degf_OnFlyFinished=null,this._degf_OnTapOrHold=null,this._degf_PlayDisappearEffect=null,this._degf_PlayFire1Eff=null,this._degf_PlayFire2Eff=null,this._degf_PlayFireEff=null,
this._degf_PlayFrameEffect=null,this._degf_PlayItemEffect=null,this._degf_SetRespondClick=null,this._degf_CountDown=()=>this.CountDown(),
this._degf_Fire2EffEnd=()=>this.Fire2EffEnd(),this._degf_HandleBeforeClose=()=>this.HandleBeforeClose(),this._degf_OnFlyFinished=()=>this.OnFlyFinished(),
this._degf_OnTapOrHold=(t,e,i,s,n)=>this.OnTapOrHold(t,e,i,s,n),this._degf_PlayDisappearEffect=()=>this.PlayDisappearEffect(),this._degf_PlayFire1Eff=()=>this.PlayFire1Eff(),
this._degf_PlayFire2Eff=()=>this.PlayFire2Eff(),this._degf_PlayFireEff=()=>this.PlayFireEff(),this._degf_PlayFrameEffect=()=>this.PlayFrameEffect(),
this._degf_PlayItemEffect=()=>this.PlayItemEffect(),this._degf_SetRespondClick=()=>this.SetRespondClick()}InitView(){this.item=new G.P,
this.item.setBinderId(this.FatherId,this.FatherComponentID,1),this.equipName=new N.Q,this.equipName.setId(this.FatherId,this.FatherComponentID,2),this.desc=new N.Q,
this.desc.setId(this.FatherId,this.FatherComponentID,3),this.baseModule=new V.$,this.baseModule.setBinderId(this.FatherId,this.FatherComponentID,4),this.flashEffect=new D.z,
this.flashEffect.setId(this.FatherId,this.FatherComponentID,5),this.itemEffect=new D.z,this.itemEffect.setId(this.FatherId,this.FatherComponentID,6),this.dissappearEffect=new D.z,
this.dissappearEffect.setId(this.FatherId,this.FatherComponentID,7),this.explodeEffect=new D.z,this.explodeEffect.setId(this.FatherId,this.FatherComponentID,8),
this.flameEffect=new D.z,this.flameEffect.setId(this.FatherId,this.FatherComponentID,9),this.countdown=new N.Q,this.countdown.setId(this.FatherId,this.FatherComponentID,10),
this.disappearAnime=new M.k,this.disappearAnime.setId(this.FatherId,this.FatherComponentID,11),this.emergeAnime=new M.k,
this.emergeAnime.setId(this.FatherId,this.FatherComponentID,12),this.flyTweenPos=new R.c,this.flyTweenPos.setId(this.FatherId,this.FatherComponentID,13),this.desEffect=new D.z,
this.desEffect.setId(this.FatherId,this.FatherComponentID,14),this.firePanel=new D.z,this.firePanel.setId(this.FatherId,this.FatherComponentID,15),this.fire1Eff=new M.k,
this.fire1Eff.setId(this.FatherId,this.FatherComponentID,16),this.StopAniEffect(this.fire1Eff),this.fire2Eff=new M.k,this.fire2Eff.setId(this.FatherId,this.FatherComponentID,17),
this.StopAniEffect(this.fire2Eff),this.delayExecutor=new A.p,P.O.AddUIEffectSortOrderBind(this.flashEffect),P.O.AddUIEffectSortOrderBind(this.itemEffect),
P.O.AddUIEffectSortOrderBind(this.dissappearEffect),P.O.AddUIEffectSortOrderBind(this.explodeEffect),P.O.AddUIEffectSortOrderBind(this.flameEffect),
P.O.AddUIEffectSortOrderBind(this.flyTweenPos.node),P.O.AddUIEffectSortOrderBind(this.desEffect),this.sModel=m.Q.Inst_get(),
this.m_handlerMgr.AddClearComponentAlwaysCache(this.item)}Clear(){this.RemoveLis(),this.IsRespondClick=!1,this.countdown.node.SetActive(!1),this.ResetAnimeState(),
this.ClearTimer(),this.taskConfig=null,this.delayExecutor.Clear(),this.StopAniEffect(this.fire1Eff),this.StopAniEffect(this.fire2Eff)}Destroy(){this.item=null,this.equipName=null,
this.desc=null,this.baseModule.Destroy(),this.baseModule=null,this.flashEffect=null,this.itemEffect=null,this.dissappearEffect=null,this.explodeEffect=null,this.flameEffect=null,
this.emergeAnime=null,this.disappearAnime=null,this.countdown=null,this.flyTweenPos=null,this.desEffect=null,this.firePanel=null,this.fire1Eff=null,this.fire2Eff=null,
this.delayExecutor=null}AddLis(){this.touchTapOrHold=E.f.AutoRegTouchState(this._degf_OnTapOrHold,3,"touchTapOrHold"),this.flyTweenPos.AddEventHandler(this._degf_OnFlyFinished),
P.O.AddUIEffectSortOrderBind(this.firePanel)}RemoveLis(){E.f.UnRegTouchState(this.touchTapOrHold),this.flyTweenPos.RemoveEventHandler(this._degf_OnFlyFinished)}
OnTapOrHold(t,e,i,s,n){return this.IsRespondClick&&(this.IsRespondClick=!1,this.PlayCloseAnimeAndEffect()),!0}OnColliderClick(t,e){this.IsRespondClick&&(this.IsRespondClick=!1,
this.PlayCloseAnimeAndEffect())}OnAddToScene(){K.K.inst.StopLoadEffect(),this.node.SetActive(!0,!0),this.step=Q.SpreadStep,h.N.inst.CloseAllExclusivePanel(),this.AddLis(),
this.countdown.node.SetActive(!1)
const t=m.Q.Inst_get().questDataList[0],e=t.item
this.taskConfig=J.L.Inst_get().model.GetTaskById(t.questId),this.baseData=new u.M(e.modelId,e)
const i=e,n=C.C.GetData(e.modelId,i),l=Y.f.Inst().getItemById(e.modelId),r=q.f.Inst().getItemById(e.modelId)
let o=B.l.SetEquipName(n,l,i)[0]
i.suitId>0&&(o=v.M.ReplaceOne(o,v.M.s_SPACE_CHAR,v.M.s_NN_CHAR)),this.equipName.textSet(o),this.item.SetData(this.baseData),this.desc.textSet(B.l.RegexN(this.getDescText(l))),
this.baseModule.SetData(s.Y.Inst.PrimaryRoleInfo_get(),n,this.baseData,r,l,i,this,!1),this.ResetAnimeState(),this.PlayOpenAnimeAndEffect(),
this.clickHandleId=a.C.Inst_get().SetInterval(this._degf_SetRespondClick,m.Q.Inst_get().RespondLimitTime_get(),1)}getDescText(t){
return v.M.IsNullOrEmpty(t.specialTaskShow)?t.describe:t.specialTaskShow}SetRespondClick(){this.IsRespondClick=!0,this.countdown.node.SetActive(!0),this.countdown.textSet(`${(0,
f.T)("[ceccc5]点击任意位置继续（")}${this.sModel.CountdownTime_get()}）[-]`),this.countDownNum=this.sModel.CountdownTime_get(),
this.countDownHandleId=a.C.Inst_get().SetInterval(this._degf_CountDown,1e3),this.step=Q.StaticShowStep}CountDown(){this.countDownNum-=1,this.countdown.textSet(`${(0,
f.T)("[ceccc5]点击任意位置继续（")}${this.countDownNum}）[-]`),this.countDownNum<=0&&(a.C.Inst_get().ClearInterval(this.countDownHandleId),this.countdown.node.SetActive(!1),
this.PlayCloseAnimeAndEffect())}ResetAnimeState(){this.flashEffect.SetActive(!1),this.itemEffect.SetActive(!1),this.dissappearEffect.SetActive(!1),this.explodeEffect.SetActive(!1),
this.flameEffect.SetActive(!1),this.flyTweenPos.node.SetActive(!1),this.flyTweenPos.SetEnabled(!1),this.desEffect.SetActive(!1)}ClearTimer(){
a.C.Inst_get().ClearInterval(this.clickHandleId),a.C.Inst_get().ClearInterval(this.countDownHandleId),a.C.Inst_get().ClearLoop(this.loopId1),a.C.Inst_get().ClearLoop(this.loopId2),
a.C.Inst_get().ClearLoop(this.loopId3),a.C.Inst_get().ClearLoop(this.loopId4)}PlayOpenAnimeAndEffect(){this.emergeAnime.SetResetOnPlay(!0),this.emergeAnime.Play(!0,!1),
this.flashEffect.SetActive(!0),this.explodeEffect.SetActive(!0),this.loopId1=a.C.Inst_get().SetFrameLoop(this._degf_PlayFrameEffect,13,1),
this.loopId2=a.C.Inst_get().SetFrameLoop(this._degf_PlayItemEffect,14,1)}PlayFrameEffect(){this.flameEffect.SetActive(!1),this.flameEffect.SetActive(!0)}PlayItemEffect(){
this.itemEffect.SetActive(!1),this.itemEffect.SetActive(!0)}PlayCloseAnimeAndEffect(){a.C.Inst_get().ClearInterval(this.countDownHandleId),this.step=Q.EndAnimeStep,
this.ResetAnimeState()
m.Q.Inst_get().questDataList.Count()>1?ct.Inst_get().OpenNext(S.NoExeEquipView,!1):(this.disappearAnime.SetResetOnPlay(!0),this.disappearAnime.Play(!0,!1),
this.loopId3=a.C.Inst_get().SetFrameLoop(this._degf_PlayDisappearEffect,6,1))}PlayDisappearEffect(){this.dissappearEffect.SetActive(!1),this.dissappearEffect.SetActive(!0),
c.f.Inst_get().Close(),this.PlayFlyAnime()}PlayFlyAnime(){const t=U.P.zero_get()
this.flyTweenPos.node.SetActive(!0),this.flyTweenPos.SetFrom(t),this.flyTweenPos.SetTo(new U.P(480,50,0)),this.flyTweenPos.durationSet(.5),this.flyTweenPos.SetEnabled(!0),
this.flyTweenPos.ResetToBeginning(),this.flyTweenPos.PlayForward()}OnFlyFinished(){this.desEffect.SetActive(!0),
this.loopId4=a.C.Inst_get().SetFrameLoop(this._degf_HandleBeforeClose,10,1)}HandleBeforeClose(){const t=m.Q.Inst_get().questDataList
t.Count()>1?ct.Inst_get().OpenNext(S.NoExeEquipView,!0):(t.RemoveAt(0),ct.Inst_get().CloseNoExeEquipPanel())}PlayFireEff(){
this.delayExecutor.InvokeFrame(this._degf_PlayFire1Eff,60),this.delayExecutor.InvokeFrame(this._degf_PlayFire2Eff,95)}PlayFire1Eff(){this.PlayAniEffect(this.fire1Eff)}
PlayFire2Eff(){this.PlayAniEffect(this.fire2Eff)}PlayAniEffect(t){
t==this.fire2Eff&&y.U.AddEventToFinishedHandler(this.fire2Eff.FatherId,this.fire2Eff.ComponentId,this._degf_Fire2EffEnd),t.node.SetActive(!0),t.SetResetOnPlay(!0),t.Play(!0,!1)}
StopAniEffect(t){t==this.fire2Eff&&y.U.RemoveEventFromFinishedHandler(this.fire2Eff.FatherId,this.fire2Eff.ComponentId,this._degf_Fire2EffEnd),t.node.SetActive(!1)}Fire2EffEnd(){
this.StopAniEffect(this.fire2Eff),this.delayExecutor.Invoke(this._degf_PlayFireEff,2500)}}var $=i(62370),W=i(67471),j=i(6936),z=i(48933)
class tt extends w.f{constructor(){super(),this.skillName=null,this.item=null,this.descLabel=null,this.demandModule=null,this.descObj=null,this.flashEffect=null,
this.itemEffect=null,this.dissappearEffect=null,this.explodeEffect=null,this.flameEffect=null,this.countdown=null,this.disappearAnime=null,this.emergeAnime=null,
this.flyTweenPos=null,this.desEffect=null,this.sModel=null,this.IsRespondClick=!1,this.countDownNum=5,this.countDownHandleId=-1,this.clickHandleId=-1,this.loopId1=-1,
this.loopId2=-1,this.loopId3=-1,this.loopId4=-1,this.baseData=null,this.taskConfig=null,this.step=0,this.touchTapOrHold=0,this._degf_CountDown=null,
this._degf_HandleBeforeClose=null,this._degf_OnFlyFinished=null,this._degf_OnTapOrHold=null,this._degf_PlayDisappearEffect=null,this._degf_PlayFrameEffect=null,
this._degf_PlayItemEffect=null,this._degf_SetRespondClick=null,this._degf_CountDown=()=>this.CountDown(),this._degf_HandleBeforeClose=()=>this.HandleBeforeClose(),
this._degf_OnFlyFinished=()=>this.OnFlyFinished(),this._degf_OnTapOrHold=(t,e,i,s,n)=>this.OnTapOrHold(t,e,i,s,n),this._degf_PlayDisappearEffect=()=>this.PlayDisappearEffect(),
this._degf_PlayFrameEffect=()=>this.PlayFrameEffect(),this._degf_PlayItemEffect=()=>this.PlayItemEffect(),this._degf_SetRespondClick=()=>this.SetRespondClick()}InitView(){
this.skillName=new N.Q,this.skillName.setId(this.FatherId,this.FatherComponentID,1),this.item=new G.P,this.item.setBinderId(this.FatherId,this.FatherComponentID,2),
this.descLabel=new N.Q,this.descLabel.setId(this.FatherId,this.FatherComponentID,3),this.demandModule=new j.D,this.demandModule.setBinderId(this.FatherId,this.FatherComponentID,4),
this.descObj=new D.z,this.descObj.setId(this.FatherId,this.FatherComponentID,5),this.flashEffect=new D.z,this.flashEffect.setId(this.FatherId,this.FatherComponentID,6),
this.itemEffect=new D.z,this.itemEffect.setId(this.FatherId,this.FatherComponentID,7),this.dissappearEffect=new D.z,
this.dissappearEffect.setId(this.FatherId,this.FatherComponentID,8),this.explodeEffect=new D.z,this.explodeEffect.setId(this.FatherId,this.FatherComponentID,9),
this.flameEffect=new D.z,this.flameEffect.setId(this.FatherId,this.FatherComponentID,10),this.countdown=new N.Q,this.countdown.setId(this.FatherId,this.FatherComponentID,11),
this.disappearAnime=new M.k,this.disappearAnime.setId(this.FatherId,this.FatherComponentID,12),this.emergeAnime=new M.k,
this.emergeAnime.setId(this.FatherId,this.FatherComponentID,13),this.flyTweenPos=new R.c,this.flyTweenPos.setId(this.FatherId,this.FatherComponentID,14),this.desEffect=new D.z,
this.desEffect.setId(this.FatherId,this.FatherComponentID,15),P.O.AddUIEffectSortOrderBind(this.flashEffect),P.O.AddUIEffectSortOrderBind(this.itemEffect),
P.O.AddUIEffectSortOrderBind(this.dissappearEffect),P.O.AddUIEffectSortOrderBind(this.explodeEffect),P.O.AddUIEffectSortOrderBind(this.flameEffect),
P.O.AddUIEffectSortOrderBind(this.flyTweenPos.node),P.O.AddUIEffectSortOrderBind(this.desEffect),this.sModel=m.Q.Inst_get(),
this.m_handlerMgr.AddClearComponentAlwaysCache(this.item)}Clear(){this.RemoveLis(),this.IsRespondClick=!1,this.countdown.node.SetActive(!1),this.ResetAnimeState(),
this.ClearTimer(),this.taskConfig=null,null!=this.baseData&&(u.M.Recycle(this.baseData),this.baseData=null)}Destroy(){this.skillName=null,this.item=null,this.descLabel=null,
this.demandModule.Destroy(),this.demandModule=null,this.descObj=null,this.flashEffect=null,this.itemEffect=null,this.dissappearEffect=null,this.explodeEffect=null,
this.flameEffect=null,this.emergeAnime=null,this.disappearAnime=null,this.countdown=null,this.flyTweenPos=null,this.desEffect=null}AddLis(){
this.touchTapOrHold=E.f.AutoRegTouchState(this._degf_OnTapOrHold,3,"touchTapOrHold"),this.flyTweenPos.AddEventHandler(this._degf_OnFlyFinished)}RemoveLis(){
E.f.UnRegTouchState(this.touchTapOrHold),this.flyTweenPos.RemoveEventHandler(this._degf_OnFlyFinished)}OnTapOrHold(t,e,i,s,n){return this.IsRespondClick&&(this.IsRespondClick=!1,
this.PlayCloseAnimeAndEffect()),!0}OnColliderClick(t,e){this.IsRespondClick&&(this.IsRespondClick=!1,this.PlayCloseAnimeAndEffect())}OnAddToScene(){K.K.inst.StopLoadEffect(),
this.node.SetActive(!0,!0),this.step=Q.SpreadStep,h.N.inst.CloseAllExclusivePanel(),this.RemoveLis(),this.AddLis(),this.countdown.node.SetActive(!1)
const t=m.Q.Inst_get().questDataList[0]
if(null==t)return void L.Y.LogError("异常")
const e=t.item
this.taskConfig=J.L.Inst_get().model.GetTaskById(t.questId),null==this.taskConfig&&L.Y.LogError((0,f.T)("无效questId = ")),this.baseData=new u.M(e.modelId,e)
const i=Y.f.Inst().getItemById(e.modelId)
s.Y.Inst.PrimaryRoleInfo_get()
this.item.SetData(this.baseData)
const n=new W.c(this.baseData)
this.demandModule.SetData(n)
let l=0
for(const[t,e]of(0,T.vy)(i.UseAttrLimitDic_get()))0!=i.UseAttrLimitDic_get()[t]&&(l+=1)
const r=this.descObj.transform.GetLocalPosition()
r.y=-50-70*l,this.descObj.transform.SetLocalPosition(r),U.P.Recyle(r),this.descLabel.textSet(B.l.RegexN(this.getDescText(i)))
let o=`${this.GetNameStr(i.Quality_get())}${i.name}[-]`
this.skillName.textSet(o)
const d=i.Rewards_get()
let _=null
if(d.typevalues.Count()>0&&(_=d.typevalues[0],"Skill"==_.type)){const t=v.M.Split(_.value,$.o.s_Arr_UNDER_COLON),e=v.M.String2Int(t[0])
let i=!1
const n=s.Y.Inst.PrimaryRoleInfo_get().Skills_get()
for(const[t,s]of(0,T.vy)(n)){if(n[t].id==e){i=!0
break}}i&&(o+=(0,f.T)(" [58ed58]（已学习）[-]"),this.skillName.textSet(o))}this.ResetAnimeState(),this.PlayOpenAnimeAndEffect(),
this.clickHandleId=a.C.Inst_get().SetInterval(this._degf_SetRespondClick,m.Q.Inst_get().RespondLimitTime_get(),1)}getDescText(t){
return v.M.IsNullOrEmpty(t.specialTaskShow)?t.describe:t.specialTaskShow}GetNameStr(t){return v.M.s_LEFT_M_K_CHAR+(B.l.getColorStrByQuality(t)+v.M.s_RIGHT_M_K_CHAR)}
SetRespondClick(){this.IsRespondClick=!0,this.countdown.node.SetActive(!0),this.countdown.textSet(`${(0,f.T)("[ceccc5]点击任意位置继续（")}${this.sModel.CountdownTime_get()}）[-]`),
this.countDownNum=this.sModel.CountdownTime_get(),this.countDownHandleId=a.C.Inst_get().SetInterval(this._degf_CountDown,1e3),this.step=Q.StaticShowStep}CountDown(){
this.countDownNum-=1,this.countdown.textSet(`${(0,f.T)("[ceccc5]点击任意位置继续（")}${this.countDownNum}）[-]`),this.countDownNum<=0&&(a.C.Inst_get().ClearInterval(this.countDownHandleId),
this.countdown.node.SetActive(!1),this.PlayCloseAnimeAndEffect())}ResetAnimeState(){this.flashEffect.SetActive(!1),this.itemEffect.SetActive(!1),
this.dissappearEffect.SetActive(!1),this.explodeEffect.SetActive(!1),this.flameEffect.SetActive(!1),this.flyTweenPos.node.SetActive(!1),this.flyTweenPos.SetEnabled(!1),
this.desEffect.SetActive(!1)}ClearTimer(){a.C.Inst_get().ClearInterval(this.clickHandleId),a.C.Inst_get().ClearInterval(this.countDownHandleId),
a.C.Inst_get().ClearLoop(this.loopId1),a.C.Inst_get().ClearLoop(this.loopId2),a.C.Inst_get().ClearLoop(this.loopId3),a.C.Inst_get().ClearLoop(this.loopId4)}
PlayOpenAnimeAndEffect(){this.emergeAnime.SetResetOnPlay(!0),this.emergeAnime.Play(!0,!1),this.flashEffect.SetActive(!0),this.explodeEffect.SetActive(!0),
this.loopId1=a.C.Inst_get().SetFrameLoop(this._degf_PlayFrameEffect,13,1),this.loopId2=a.C.Inst_get().SetFrameLoop(this._degf_PlayItemEffect,14,1)}PlayFrameEffect(){
this.flameEffect.SetActive(!1),this.flameEffect.SetActive(!0)}PlayItemEffect(){this.itemEffect.SetActive(!1),this.itemEffect.SetActive(!0)}PlayCloseAnimeAndEffect(){
a.C.Inst_get().ClearInterval(this.countDownHandleId),this.step=Q.EndAnimeStep,this.ResetAnimeState()
m.Q.Inst_get().questDataList.Count()>1?ct.Inst_get().OpenNext(S.SkillView,!1):(this.disappearAnime.SetResetOnPlay(!0),this.disappearAnime.Play(!0,!1),
this.loopId3=a.C.Inst_get().SetFrameLoop(this._degf_PlayDisappearEffect,15,1))}PlayDisappearEffect(){this.dissappearEffect.SetActive(!1),this.dissappearEffect.SetActive(!0),
c.f.Inst_get().Close(),this.PlayFlyAnime()}PlayFlyAnime(){const t=U.P.zero_get()
this.flyTweenPos.node.SetActive(!0),this.flyTweenPos.SetFrom(t),U.P.Recyle(t),z.I.calVec0.Set(-480,50,0),this.flyTweenPos.SetTo(z.I.calVec0),this.flyTweenPos.durationSet(.5),
this.flyTweenPos.SetEnabled(!0),this.flyTweenPos.ResetToBeginning(),this.flyTweenPos.PlayForward()}OnFlyFinished(){this.desEffect.SetActive(!0),
this.loopId4=a.C.Inst_get().SetFrameLoop(this._degf_HandleBeforeClose,10,1)}HandleBeforeClose(){const t=m.Q.Inst_get().questDataList
t.Count()>1?ct.Inst_get().OpenNext(S.SkillView,!0):(t.Count()>0&&t.RemoveAt(0),ct.Inst_get().CloseSkillPanel())}}
var et=i(90419),it=i(98958),st=i(50089),nt=i(30267),lt=i(72005),at=i(13113),rt=i(5468),ot=i(98130),ht=i(53824),dt=i(1240),_t=i(52429),ut=i(5268)
class It extends w.f{constructor(){super(),this.equipName=null,this.equipItem=null,this.suitNameLabel=null,this.oneCompelete=null,this.twoCompelete=null,this.threeCompelete=null,
this.fourCompelete=null,this.oneEquipAttr=null,this.twoEquipAttr=null,this.threeEquipAttr=null,this.fourEquipAttr=null,this.table=null,this.container1=null,this.container2=null,
this.container3=null,this.container4=null,this.countdown=null,this.flashEffect=null,this.itemEffect=null,this.dissappearEffect=null,this.explodeEffect=null,this.flameEffect=null,
this.flyTweenPos=null,this.iconSgEffect=null,this.iconShowAnim=null,this.emergeAnime=null,this.firePanel=null,this.fire1Eff=null,this.fire2Eff=null,this.suitSprite=null,
this.suitIcon=null,this.disapperAnim=null,this.emergeOpenAnim=null,this.sModel=null,this.itemId=0,this.equipRes=null,this.itemRes=null,this.taskConfig=null,this.bagItemData=null,
this.compeleteList=null,this.attrList=null,this.containers=null,this.delayExecutor=null,this.loopId1=-1,this.loopId2=-1,this.loopId3=-1,this.loopId4=-1,this.loopId5=-1,
this.loopId6=-1,this.IsRespondClick=!1,this.countDownNum=5,this.countDownHandleId=-1,this.clickHandleId=-1,this.step=0,this.touchTapOrHold=0,this.oneRowPos=null,
this.twoRowPos=null,this._degf_CountDown=null,this._degf_Fire2EffEnd=null,this._degf_HandleBeforeClose=null,this._degf_OnFlyFinished=null,this._degf_OnTapOrHold=null,
this._degf_PlayDisappearEffect=null,this._degf_PlayFire1Eff=null,this._degf_PlayFire2Eff=null,this._degf_PlayFireEff=null,this._degf_PlayFrameEffect=null,
this._degf_PlayIconSgEffect=null,this._degf_PlayIconShowEffect=null,this._degf_PlayItemEffect=null,this._degf_SetRespondClick=null,this.compeleteList=new k.Z,this.attrList=new k.Z,
this.containers=new k.Z,this.oneRowPos=new U.P(-38,144,0),this.twoRowPos=new U.P(-38,153,0),this._degf_CountDown=()=>this.CountDown(),this._degf_Fire2EffEnd=()=>this.Fire2EffEnd(),
this._degf_HandleBeforeClose=()=>this.HandleBeforeClose(),this._degf_OnFlyFinished=()=>this.OnFlyFinished(),this._degf_OnTapOrHold=(t,e,i,s,n)=>this.OnTapOrHold(t,e,i,s,n),
this._degf_PlayDisappearEffect=()=>this.PlayDisappearEffect(),this._degf_PlayFire1Eff=()=>this.PlayFire1Eff(),this._degf_PlayFire2Eff=()=>this.PlayFire2Eff(),
this._degf_PlayFireEff=()=>this.PlayFireEff(),this._degf_PlayFrameEffect=()=>this.PlayFrameEffect(),this._degf_PlayIconSgEffect=()=>this.PlayIconSgEffect(),
this._degf_PlayIconShowEffect=()=>this.PlayIconShowEffect(),this._degf_PlayItemEffect=()=>this.PlayItemEffect(),this._degf_SetRespondClick=()=>this.SetRespondClick()}InitView(){
this.equipName=new N.Q,this.equipName.setId(this.FatherId,this.FatherComponentID,1),this.equipItem=new ht.Z,this.equipItem.setBinderId(this.FatherId,this.FatherComponentID,2),
this.suitNameLabel=new N.Q,this.suitNameLabel.setId(this.FatherId,this.FatherComponentID,3),this.oneCompelete=new N.Q,
this.oneCompelete.setId(this.FatherId,this.FatherComponentID,4),this.twoCompelete=new N.Q,this.twoCompelete.setId(this.FatherId,this.FatherComponentID,5),
this.threeCompelete=new N.Q,this.threeCompelete.setId(this.FatherId,this.FatherComponentID,6),this.fourCompelete=new N.Q,
this.fourCompelete.setId(this.FatherId,this.FatherComponentID,7),this.oneEquipAttr=new N.Q,this.oneEquipAttr.setId(this.FatherId,this.FatherComponentID,8),
this.twoEquipAttr=new N.Q,this.twoEquipAttr.setId(this.FatherId,this.FatherComponentID,9),this.threeEquipAttr=new N.Q,
this.threeEquipAttr.setId(this.FatherId,this.FatherComponentID,10),this.fourEquipAttr=new N.Q,this.fourEquipAttr.setId(this.FatherId,this.FatherComponentID,11),this.table=new nt.V,
this.table.setId(this.FatherId,this.FatherComponentID,12),this.container1=new at.T,this.container1.setId(this.FatherId,this.FatherComponentID,13),this.container2=new at.T,
this.container2.setId(this.FatherId,this.FatherComponentID,14),this.container3=new at.T,this.container3.setId(this.FatherId,this.FatherComponentID,15),this.container4=new at.T,
this.container4.setId(this.FatherId,this.FatherComponentID,16),this.countdown=new N.Q,this.countdown.setId(this.FatherId,this.FatherComponentID,17),this.flashEffect=new D.z,
this.flashEffect.setId(this.FatherId,this.FatherComponentID,18),this.itemEffect=new D.z,this.itemEffect.setId(this.FatherId,this.FatherComponentID,19),
this.dissappearEffect=new D.z,this.dissappearEffect.setId(this.FatherId,this.FatherComponentID,20),this.explodeEffect=new D.z,
this.explodeEffect.setId(this.FatherId,this.FatherComponentID,21),this.flameEffect=new D.z,this.flameEffect.setId(this.FatherId,this.FatherComponentID,22),this.flyTweenPos=new R.c,
this.flyTweenPos.setId(this.FatherId,this.FatherComponentID,23),this.iconSgEffect=new D.z,this.iconSgEffect.setId(this.FatherId,this.FatherComponentID,24),
this.iconShowAnim=new M.k,this.iconShowAnim.setId(this.FatherId,this.FatherComponentID,25),this.emergeAnime=new M.k,this.emergeAnime.setId(this.FatherId,this.FatherComponentID,26),
this.firePanel=new D.z,this.firePanel.setId(this.FatherId,this.FatherComponentID,27),this.fire1Eff=new M.k,this.fire1Eff.setId(this.FatherId,this.FatherComponentID,28),
this.fire2Eff=new M.k,this.fire2Eff.setId(this.FatherId,this.FatherComponentID,29),this.suitSprite=new lt.w,this.suitSprite.setId(this.FatherId,this.FatherComponentID,30),
this.suitIcon=new D.z,this.suitIcon.setId(this.FatherId,this.FatherComponentID,31),this.disapperAnim=new M.k,this.disapperAnim.setId(this.FatherId,this.FatherComponentID,32),
this.emergeOpenAnim=new M.k,this.emergeOpenAnim.setId(this.FatherId,this.FatherComponentID,33),this.StopAniEffect(this.fire1Eff),this.StopAniEffect(this.fire2Eff),
this.delayExecutor=new A.p,P.O.AddUIEffectSortOrderBind(this.flashEffect),P.O.AddUIEffectSortOrderBind(this.itemEffect),P.O.AddUIEffectSortOrderBind(this.dissappearEffect),
P.O.AddUIEffectSortOrderBind(this.explodeEffect),P.O.AddUIEffectSortOrderBind(this.flameEffect),P.O.AddUIEffectSortOrderBind(this.flyTweenPos.node),
P.O.AddUIEffectSortOrderBind(this.iconSgEffect),this.containers.Add(this.container1),this.containers.Add(this.container2),this.containers.Add(this.container3),
this.containers.Add(this.container4),this.compeleteList.Add(this.oneCompelete),this.compeleteList.Add(this.twoCompelete),this.compeleteList.Add(this.threeCompelete),
this.compeleteList.Add(this.fourCompelete),this.attrList.Add(this.oneEquipAttr),this.attrList.Add(this.twoEquipAttr),this.attrList.Add(this.threeEquipAttr),
this.attrList.Add(this.fourEquipAttr),this.sModel=m.Q.Inst_get()}Clear(){this.AddOrRemoveLis(!1),this.equipItem.Clear(),this.itemId=0,this.equipRes=null,this.IsRespondClick=!1,
this.countdown.node.SetActive(!1),this.ResetAnimeState(),this.ClearTimer(),this.taskConfig=null,this.delayExecutor.Clear(),this.StopAniEffect(this.fire1Eff),
this.StopAniEffect(this.fire2Eff)}Destroy(){this.compeleteList.Clear(),this.attrList.Clear(),this.containers.Clear(),this.equipItem.Destroy(),this.disapperAnim=null,
this.suitIcon=null,this.delayExecutor=null,this.sModel=null,this.equipName=null,this.equipItem=null,this.suitNameLabel=null,this.oneCompelete=null,this.twoCompelete=null,
this.threeCompelete=null,this.fourCompelete=null,this.oneEquipAttr=null,this.twoEquipAttr=null,this.threeEquipAttr=null,this.fourEquipAttr=null,this.table=null,
this.container1=null,this.container2=null,this.container3=null,this.container4=null,this.countdown=null,this.flashEffect=null,this.itemEffect=null,this.dissappearEffect=null,
this.explodeEffect=null,this.flameEffect=null,this.flyTweenPos=null,this.iconSgEffect=null,this.iconShowAnim=null,this.emergeAnime=null,this.firePanel=null,this.fire1Eff=null,
this.fire2Eff=null}StopAniEffect(t){t==this.fire2Eff&&y.U.RemoveEventFromFinishedHandler(this.fire2Eff.FatherId,this.fire2Eff.ComponentId,this._degf_Fire2EffEnd),
t.node.SetActive(!1)}PlayFireEff(){this.delayExecutor.InvokeFrame(this._degf_PlayFire1Eff,60),this.delayExecutor.InvokeFrame(this._degf_PlayFire2Eff,95)}PlayFire1Eff(){
this.PlayAniEffect(this.fire1Eff)}PlayFire2Eff(){this.PlayAniEffect(this.fire2Eff)}PlayAniEffect(t){
t==this.fire2Eff&&y.U.AddEventToFinishedHandler(this.fire2Eff.FatherId,this.fire2Eff.ComponentId,this._degf_Fire2EffEnd),t.node.SetActive(!0),t.SetResetOnPlay(!0),t.Play(!0,!1)}
Fire2EffEnd(){this.StopAniEffect(this.fire2Eff),this.delayExecutor.Invoke(this._degf_PlayFireEff,2500)}ResetAnimeState(){this.flashEffect.SetActive(!1),
this.itemEffect.SetActive(!1),this.dissappearEffect.SetActive(!1),this.explodeEffect.SetActive(!1),this.flameEffect.SetActive(!1),this.flyTweenPos.node.SetActive(!1),
this.flyTweenPos.SetEnabled(!1),this.iconSgEffect.SetActive(!1)}ClearTimer(){a.C.Inst_get().ClearInterval(this.clickHandleId),a.C.Inst_get().ClearInterval(this.countDownHandleId),
a.C.Inst_get().ClearLoop(this.loopId1),a.C.Inst_get().ClearLoop(this.loopId2),a.C.Inst_get().ClearLoop(this.loopId3),a.C.Inst_get().ClearLoop(this.loopId4),
a.C.Inst_get().ClearLoop(this.loopId5),a.C.Inst_get().ClearLoop(this.loopId6)}OnAddToScene(){K.K.inst.StopLoadEffect(),this.AddOrRemoveLis()
const t=m.Q.Inst_get().questDataList[0],e=t.item
this.taskConfig=J.L.Inst_get().model.GetTaskById(t.questId),this.bagItemData=new dt.Y,this.bagItemData.serverData_set(e),this.bagItemData.baseData_get().isForBag=!1,
this.equipItem.SetData(this.bagItemData)
const i=e
if(null==i)return void L.Y.LogError((0,f.T)("服务器发来的道具不是装备!!"))
const s=C.C.GetData(e.modelId,i)
this.itemRes=i.GetItemRes(),this.equipRes=i.GetEquipRes()
const n=B.l.getEquipQuality(i,s)
this.suitSprite.spriteNameSet(B.l.getSuitImgByQuality(n))
const l=i.GetEquipSuitRes(),r=it.V.Inst().getStr2(10712,0,B.l.getEquiplvStr(l.suitLevel),l.suitPrefix,l.suitName)
this.suitNameLabel.textSet(r)
let o=B.l.SetEquipName(s,this.itemRes,i)[0]
v.M.Length(o)>=19?(o=v.M.Replace(o,`${l.suitPrefix} `,`${l.suitPrefix}\n`),this.equipName.node.transform.SetLocalPosition(this.twoRowPos)):this.equipName.node.transform.SetLocalPosition(this.oneRowPos),
this.equipName.textSet(o)
const h=ut.H.Inst().getSuitAttrsBySuitId(this.equipRes.suitId)
let d=rt.E.s_Empty,_=0
for(;_<this.containers.Count();){if(h.Count()>_){const t=et.d.parseJsonObjectWithFix(h[_].suitAttrs,"attrs"),e=st.t.decode(t,_t.L)
if(e.parse(),0==e.attrs.Count());else{let t=0
for(;t<e.attrs.Count();)d+=B.l.getAttrStr(e.attrs[t].intType,!1)+B.l.getAttrValueStr(e.attrs[t].intType,e.attrs[t].value),t<e.attrs.Count()-1&&(d+="\n"),t+=1}
this.attrList[_].textSet(d),this.compeleteList[_].textSet(it.V.Inst().getStr2(10713,0,v.M.IntToString(h[_].suitNum))),this.containers[_].node.SetActive(!0),
this.containers[_].heightSet(ot.GF.INT(this.containers[_].node.GetBoundsSize().y)),d=rt.E.s_Empty}else this.containers[_].node.SetActive(!1)
_+=1}this.table.Reposition(),this.ResetAnimeState(),this.PlayOpenAnimeAndEffect(),
this.clickHandleId=a.C.Inst_get().SetInterval(this._degf_SetRespondClick,m.Q.Inst_get().RespondLimitTime_get(),1)}SetRespondClick(){this.IsRespondClick=!0,
this.countdown.node.SetActive(!0),this.countdown.textSet(`${(0,f.T)("[ceccc5]点击任意位置继续（")}${this.sModel.CountdownTime_get()}）[-]`),this.countDownNum=this.sModel.CountdownTime_get(),
this.countDownHandleId=a.C.Inst_get().SetInterval(this._degf_CountDown,1e3),this.step=Q.StaticShowStep}CountDown(){this.countDownNum-=1,this.countdown.textSet(`${(0,
f.T)("[ceccc5]点击任意位置继续（")}${this.countDownNum}）[-]`),this.countDownNum<=0&&(a.C.Inst_get().ClearInterval(this.countDownHandleId),this.countdown.node.SetActive(!1),
this.PlayCloseAnimeAndEffect())}PlayCloseAnimeAndEffect(){a.C.Inst_get().ClearInterval(this.countDownHandleId),this.step=Q.EndAnimeStep,this.ResetAnimeState()
m.Q.Inst_get().questDataList.Count()>1?ct.Inst_get().OpenNext(S.ExeEquipView,!1):(this.disapperAnim.SetResetOnPlay(!0),this.disapperAnim.Play(!0,!1),
this.loopId3=a.C.Inst_get().SetFrameLoop(this._degf_PlayDisappearEffect,6,1))}PlayDisappearEffect(){c.f.Inst_get().Close(),this.PlayFlyAnime()}PlayFlyAnime(){const t=U.P.zero_get()
this.flyTweenPos.node.SetActive(!0),this.flyTweenPos.SetFrom(t),this.flyTweenPos.SetTo(new U.P(480,50,0)),this.flyTweenPos.durationSet(.5),this.flyTweenPos.SetEnabled(!0),
this.flyTweenPos.ResetToBeginning(),this.flyTweenPos.PlayForward()}HandleBeforeClose(){const t=m.Q.Inst_get().questDataList
t.Count()>1?ct.Inst_get().OpenNext(S.SuitEquipView,!0):(t.RemoveAt(0),ct.Inst_get().CloseSuitEquipPanel())}PlayOpenAnimeAndEffect(){this.emergeAnime.SetResetOnPlay(!0),
this.emergeAnime.Play(!0,!1),this.emergeOpenAnim.SetResetOnPlay(!0),this.emergeOpenAnim.Play(!0,!1),this.flashEffect.SetActive(!0),this.explodeEffect.SetActive(!0),
this.suitIcon.SetActive(!1),this.loopId1=a.C.Inst_get().SetFrameLoop(this._degf_PlayFrameEffect,13,1),this.loopId2=a.C.Inst_get().SetFrameLoop(this._degf_PlayItemEffect,14,1),
this.loopId5=a.C.Inst_get().SetFrameLoop(this._degf_PlayIconShowEffect,30,1),this.loopId6=a.C.Inst_get().SetFrameLoop(this._degf_PlayIconSgEffect,28,1)}PlayIconShowEffect(){
null!=this.iconShowAnim&&(this.suitIcon.SetActive(!0),this.iconShowAnim.SetResetOnPlay(!0),this.iconShowAnim.Play(!0,!1))}PlayFrameEffect(){this.flameEffect.SetActive(!1),
this.flameEffect.SetActive(!0)}PlayItemEffect(){this.itemEffect.SetActive(!1),this.itemEffect.SetActive(!0)}PlayIconSgEffect(){this.iconSgEffect.SetActive(!1),
this.iconSgEffect.SetActive(!0)}OnClickHandler(t,e){this.IsRespondClick&&(this.IsRespondClick=!1,this.PlayCloseAnimeAndEffect())}OnTapOrHold(t,e,i,s,n){
return this.IsRespondClick&&(this.IsRespondClick=!1,this.PlayCloseAnimeAndEffect()),!0}OnFlyFinished(){this.dissappearEffect.SetActive(!1),this.dissappearEffect.SetActive(!0),
this.loopId4=a.C.Inst_get().SetFrameLoop(this._degf_HandleBeforeClose,10,1)}AddOrRemoveLis(t){null==t&&(t=!0),
t?(this.touchTapOrHold=E.f.AutoRegTouchState(this._degf_OnTapOrHold,3,"touchTapOrHold"),this.flyTweenPos.AddEventHandler(this._degf_OnFlyFinished),
P.O.AddUIEffectSortOrderBind(this.firePanel)):(E.f.UnRegTouchState(this.touchTapOrHold),this.RemoveFullScreenCollider(),
this.flyTweenPos.RemoveEventHandler(this._degf_OnFlyFinished))}}class ct{constructor(){this.exeEquipView=null,this.noExeEquipView=null,this.skillView=null,this.isExeEquipOpen=!1,
this.isEquipOpen=!1,this.isSkillOpen=!1,this.intervalId=-1,this.suitEquipView=null,this.isSuitEquipOpen=!1,this.exeEquipTimer=-1,this.noExeEquipTimer=-1,this.skillTimer=-1,
this._degf_CallExeEquipDestory=null,this._degf_CallNoExeEquipDestory=null,this._degf_CallSkillDestory=null,this._degf_CallSuitEquipDestory=null,this._degf_ShowExeEquipHandler=null,
this._degf_ShowNoExeEquipHandler=null,this._degf_ShowSkillHandler=null,this._degf_ShowSuitEquipHandler=null,this._degf_StartHang=null,
this._degf_CallExeEquipDestory=()=>this.CallExeEquipDestory(),this._degf_CallNoExeEquipDestory=()=>this.CallNoExeEquipDestory(),
this._degf_CallSkillDestory=()=>this.CallSkillDestory(),this._degf_CallSuitEquipDestory=()=>this.CallSuitEquipDestory(),
this._degf_ShowExeEquipHandler=t=>this.ShowExeEquipHandler(t),this._degf_ShowNoExeEquipHandler=t=>this.ShowNoExeEquipHandler(t),
this._degf_ShowSkillHandler=t=>this.ShowSkillHandler(t),this._degf_ShowSuitEquipHandler=t=>this.ShowSuitEquipHandler(t),this._degf_StartHang=()=>this.StartHang()}static Inst_get(){
return null==ct.inst&&(ct.inst=new ct),ct.inst}Open(t){g.T.inst_get().control.CloseBuffListPanel()
const e=m.Q.Inst_get().questDataList
if(t&&e.Add(t),s.Y.Inst.PrimaryRoleInfo_get().Id_get()!=_.o.ZERO&&1==e.Count()&&(c.f.Inst_get().Open(),null!=e&&null!=e[0].item)){const t=new u.M(e[0].item.modelId,e[0].item)
t.cfgData_get().itemType==I.q.EQUIPMENT?this.OpenExeEquipPanel():t.cfgData_get().IsSkillItem()&&this.OpenSkillPanel()}}OpenNext(t,e){g.T.inst_get().control.CloseBuffListPanel()
const i=m.Q.Inst_get().questDataList
if(e){const t=i[0].questId
J.L.Inst_get().model.AddBufferTaskById(t)}if(i.RemoveAt(0),i.Count()>0&&s.Y.Inst.PrimaryRoleInfo_get().Id_get()!=_.o.ZERO){c.f.Inst_get().Open()
const e=new u.M(i[0].item.modelId,i[0].item)
let s=0
e.cfgData_get().itemType==I.q.EQUIPMENT?this.OpenExeEquipPanel():e.cfgData_get().IsSkillItem()&&(s=S.SkillView,this.OpenSkillPanel()),s!=t&&this.CloseByType(t,!1)}else i.Clear()}
OpenAfterLeaveCopy(){g.T.inst_get().control.CloseBuffListPanel()
const t=m.Q.Inst_get().questDataList
if(null!=t&&t.Count()>0&&s.Y.Inst.PrimaryRoleInfo_get().Id_get()!=_.o.ZERO){c.f.Inst_get().Open()
const e=new u.M(t[0].item.modelId,t[0].item)
e.cfgData_get().itemType==I.q.EQUIPMENT?this.OpenExeEquipPanel():e.cfgData_get().IsSkillItem()&&this.OpenSkillPanel()}else t.Clear()}CloseByType(t,e){null==e&&(e=!0),
t==S.ExeEquipView?this.CloseExeEquipPanel(e):t==S.NoExeEquipView?this.CloseNoExeEquipPanel(e):t==S.SkillView?this.CloseSkillPanel(e):t==S.SuitEquipView&&this.CloseSuitEquipPanel(e),
c.f.Inst_get().Close()}OpenSuitEquipPanel(){if(p.x.Inst_get().CloseView(),null!=this.suitEquipView&&this.suitEquipView.isShow_get())this.suitEquipView.OnAddToScene()
else{this.isSuitEquipOpen=!0
const t=new r.v
h.N.inst.OpenById(d.I.eTaskSuitEquipView,this._degf_ShowSuitEquipHandler,this._degf_CallSuitEquipDestory,t)}l.j.Inst.PlayByDivision("GetGoodThing")}CloseSuitEquipPanel(t){
null==t&&(t=!0),this.isSuitEquipOpen=!1,this.CloseSuitEquipView(),t&&(J.L.Inst_get().model.AddBufferTask(),this.DelayAndHang())}CloseSuitEquipView(){
null!=this.suitEquipView&&this.suitEquipView.isShow_get()&&(h.N.inst.CloseById(d.I.eTaskSuitEquipView),this.isSuitEquipOpen=!1)}ShowSuitEquipHandler(t){
return this.suitEquipView=new It,this.suitEquipView.setId(t,null,0),this.suitEquipView}CallSuitEquipDestory(){o.g.DestroyUIObj(this.suitEquipView),this.suitEquipView=null}
OpenExeEquipPanel(){if(p.x.Inst_get().CloseView(),null!=this.exeEquipView&&this.exeEquipView.isShow_get())this.exeEquipView.OnAddToScene()
else{this.isExeEquipOpen=!0
const t=new r.v
h.N.inst.OpenById(d.I.TaskExeEquipPanel,this._degf_ShowExeEquipHandler,this._degf_CallExeEquipDestory,t)}this.ClearExeEquipTimer(),l.j.Inst.PlayByDivision("GetGoodThing")}
CloseExeEquipPanel(t){null==t&&(t=!0),this.isExeEquipOpen=!1,this.CloseExeEquip(),t&&(J.L.Inst_get().model.AddBufferTask(),this.DelayAndHang())}CloseExeEquip(){
this.ClearExeEquipTimer(),h.N.inst.CloseById(d.I.TaskExeEquipPanel)}ClearExeEquipTimer(){a.C.Inst_get().ClearInterval(this.exeEquipTimer),this.exeEquipTimer=-1}
CallExeEquipDestory(){o.g.DestroyUIObj(this.exeEquipView),this.exeEquipView=null}ShowExeEquipHandler(t){return null==this.exeEquipView&&(this.exeEquipView=new Z,
this.exeEquipView.setId(t,null,0)),this.exeEquipView}OpenNoExeEquipPanel(){if(p.x.Inst_get().CloseView(),
null!=this.noExeEquipView&&this.noExeEquipView.isShow_get())this.noExeEquipView.OnAddToScene()
else{this.isEquipOpen=!0
const t=new r.v
h.N.inst.OpenById(d.I.TaskNoExeEquipPanel,this._degf_ShowNoExeEquipHandler,this._degf_CallNoExeEquipDestory,t)}this.ClearNoExeEquipTimer(),l.j.Inst.PlayByDivision("GetGoodThing")}
CloseNoExeEquipPanel(t){null==t&&(t=!0),this.isEquipOpen=!1,this.CloseNoExeEquip(),t&&(J.L.Inst_get().model.AddBufferTask(),this.DelayAndHang())}CloseNoExeEquip(){
this.ClearNoExeEquipTimer(),h.N.inst.CloseById(d.I.TaskNoExeEquipPanel)}ClearNoExeEquipTimer(){a.C.Inst_get().ClearInterval(this.noExeEquipTimer),this.noExeEquipTimer=-1}
CallNoExeEquipDestory(){o.g.DestroyUIObj(this.noExeEquipView),this.noExeEquipView=null}ShowNoExeEquipHandler(t){return null==this.noExeEquipView&&(this.noExeEquipView=new X,
this.noExeEquipView.setId(t,null,0)),this.noExeEquipView}OpenSkillPanel(){if(this.isSkillOpen=!0,p.x.Inst_get().CloseView(),
null!=this.skillView&&this.skillView.isShow_get())this.skillView.OnAddToScene()
else{const t=new r.v
h.N.inst.OpenById(d.I.TaskSkillPanel,this._degf_ShowSkillHandler,this._degf_CallSkillDestory,t)}this.ClearSkillTimer(),l.j.Inst.PlayByDivision("GetGoodThing")}CloseSkillPanel(t){
null==t&&(t=!0),this.isSkillOpen=!1,this.CloseSkill(),t&&(J.L.Inst_get().model.AddBufferTask(),this.DelayAndHang())}CloseSkill(){this.ClearSkillTimer(),
h.N.inst.CloseById(d.I.TaskSkillPanel)}ClearSkillTimer(){a.C.Inst_get().ClearInterval(this.skillTimer),this.skillTimer=-1}CallSkillDestory(){o.g.DestroyUIObj(this.skillView),
this.skillView=null}ShowSkillHandler(t){return null==this.skillView&&(this.skillView=new tt,this.skillView.setId(t,null,0)),this.skillView}DelayAndHang(){
m.Q.Inst_get().restoreHangState&&(m.Q.Inst_get().restoreHangState=!1,a.C.Inst_get().ClearInterval(this.intervalId),
this.intervalId=a.C.Inst_get().SetInterval(this._degf_StartHang,2e3,1))}StartHang(){n._.getInst().startHang()}IsSpecialTaskViewOpen(){
return!!(this.isEquipOpen||this.isExeEquipOpen||this.isSkillOpen)}BugTest(){}}ct.inst=null},27363:(t,e,i)=>{i.d(e,{Y:()=>D})
var s=i(98800),n=i(96098),l=i(36241),a=i(85682),r=i(31222),o=i(98885),h=i(70123),d=i(70850),_=i(31922),u=i(87923),I=i(29839),c=i(85770),g=i(72800),p=i(68637),m=i(14792),S=i(62734),T=i(98580),f=i(89803),C=i(85602)
class E{constructor(){this.uiID=0,this.btnID=null,this.param=null,this.openUI=null,this.param=new C.Z(2)}OpenUI_get(){return this.openUI}OpenUI_set(t){this.openUI=t
const e=o.M.Split(t,o.M.s_CCD_CHAR)
this.uiID=o.M.String2Int(e[0])
let i=1
for(;i<e.count;)this.param[i-1]=o.M.String2Int(e[i]),i+=1}}var A=i(48550),L=i(79878),y=i(17783)
class D{constructor(){this.m_config=null}static get inst(){return D._inst||(D._inst=new D),D._inst}DealClick(t){if(null==t||n.B.Inst.isOpenMaskStart)return
t.status_get()==T.B.ACCEPTED&&u.l.CheckTrigger(_.z.COND_TYPE_TASK_CLICK_VAL,t.id_get(),0)
const e=t.GetGuidId()
if(e>0&&t.status_get()!=T.B.FINISHED){const t=p.c.Inst.GetResById(e)
if(!p.c.Inst.IsGuideFinish(o.M.String2Int(t.group)))return void p.c.Inst.AddGuideById(e)}if(t.isClickReward_get())L.Y.SendToServer(t)
else if(null!=t){const e=t.GetCopyRes()
if(c.a.Inst_get().isStartExitCopy&&t.status_get()==T.B.FINISHED&&I.p.inst.IsInCopy()&&c.a.Inst_get().IsInPlotOrMapCopy())return void I.p.inst.ExitCopy()
if(null!=e&&e.controllerType==g.S.Plot&&I.p.inst.IsSameMapByMapID(o.M.String2Int(e.mapId))&&null!=e.SuccessConditions_get()&&null!=e.SuccessConditions_get().successConditionList){
if(null!=e.SuccessConditions_get().successConditionList[0].param)return void l._.getInst().startHang()}this.GotoTrigger(t)}}GotoTrigger(t){this.m_config=t,
this.JudgeApproachTask(this.m_config)||this.PlayMoveLightEffectAndContinue()&&L.Y.DoGoTaskStep(this.m_config)}JudgeApproachTask(t){
if(null!=t.tCTargetDefs_get()&&t.tCTargetDefs_get().tCTargetDefs.Count()>0){const e=t.GetNowTargetDef()
if(null==e.param||"true"!=e.param.multiAccess){let i=null
return i=null==t.qVo?s.Y.Inst.PrimaryRoleInfo_get():s.Y.Inst.GetMultiPlayerInfo(t.qVo.playerId),this.DealApproachType(e,i)}if(t.status_get()==T.B.ACCEPTED){let i=null
if(i=null==t.qVo?s.Y.Inst.PrimaryRoleInfo_get():s.Y.Inst.GetMultiPlayerInfo(t.qVo.playerId),this.DealApproachType(e,i))return!0
if(!u.l.IsEmptyStr(e.param.multiShowItem))return h.W.ins.OpenAccessByItemId(o.M.String2Int(e.param.multiShowItem),null,null),!0}}return!1}DealApproachType(t,e){
if(t.type==f.d.PASSIVE_SKILL_LEVEL_UP_TIME&&d.g.Inst_get().isItemEnougth(t.param.multiItem,1))return r.N.inst.OpenUIByShortCutID(a.D.ProSkill),!0
if(t.type==f.d.EQUIPMENT_ENHANCE_TIME){if(S.f.Inst.GetData(m.t.ENHANCE).show)return r.N.inst.OpenUIByShortCutID(a.D.EquipEnhance),!0}return!1}PlayMoveLightEffectAndContinue(){
if(this.m_config.status_get()==T.B.FINISHED)return!0
if(null!=this.m_config.tCTargetDefs_get()&&this.m_config.tCTargetDefs_get().tCTargetDefs.Count()>0){const t=this.m_config.tCTargetDefs_get().tCTargetDefs[0]
if(t.ParseGoUI(),t.IsOpenAndFlyUIFilled()){const e=new E
e.OpenUI_set(t.OpenUI_get()),e.btnID=t.flyUI,y.L.Inst_get().model.goUIParam=e}const e=t.flyUI
if(y.L.Inst_get().model.flyUIChild=t.flyUIChild,o.M.IsNullOrEmpty(e)||A.r.Inst_get().CloseView(),!o.M.IsNullOrEmpty(t.flyUI)&&0==t.npcId)return!1}return!0}}D._inst=new D},
4586:(t,e,i)=>{i.d(e,{G:()=>a})
var s=i(98958),n=i(98885),l=i(87923)
class a{static CutColorStr(t){let e=null
if(l.l.IsEmptyStr(t))e=""
else{e=t,e=n.M.ReplaceSlow(e,a.colorEStr,"")
let i=n.M.Length(e),s=0,l=0
for(;l<i;){const t=n.M.IndexOf(e,a.startSymbol,s)
if(!(t>-1))break
if(n.M.Length(e)>=t+8&&n.M.SubStringWithEnd(e,t+7,t+8)==a.endSymbol){const s=n.M.SubStringWithEnd(e,t+1,t+7)
a.IsBBCode(s)&&(e=n.M.Remove(e,t,8),i-=8)}if(s=t+1,s>=i)break
l+=1}}return e}static IsBBCode(t){t=n.M.ToLower(t)
const e=n.M.ToCharArray(t),i=e.count
let s=0
for(;s<i;){const t=e[s],i=n.M.Char2Int(t)
if(!(i>=48&&i<=57||i>=97&&i<=102))return!1
s+=1}return!0}GetTipTaskRewardPassId(){return a.m_tipTaskRewardPassId}GetTipTaskPoint(){return a.m_tipTaskPoint}GetRewardTxt(){
return null==a.m_rewardTxt&&(a.m_rewardTxt=s.V.Inst().getStr2(10542)),a.m_rewardTxt}}a.startSymbol="[",a.endSymbol="]",a.colorEStr="[-]",a.m_tipTaskRewardPassId=-1,
a.m_tipTaskPoint=-1,a.m_rewardTxt=null},48550:(t,e,i)=>{i.d(e,{r:()=>B})
var s=i(41664),n=i(5924),l=i(56937),a=i(18202),r=i(31222),o=i(5494),h=i(52726),d=i(99294),_=i(67330),u=i(3522),I=i(61911)
class c extends I.f{constructor(){super(),this.finsheffect=null,this.pareff1=null,this.pareff2=null,this.finshtxteff=null,this.effectLayer=null,this._degf_AnimEnd=null,
this._degf_AnimEnd=()=>this.AnimEnd()}InitView(){super.InitView(),this.finsheffect=new u.k,this.finsheffect.setId(this.FatherId,this.FatherComponentID,1),this.pareff1=new d.z,
this.pareff1.setId(this.FatherId,this.FatherComponentID,3),this.pareff2=new d.z,this.pareff2.setId(this.FatherId,this.FatherComponentID,4),this.finshtxteff=new u.k,
this.finshtxteff.setId(this.FatherId,this.FatherComponentID,5),this.effectLayer=new _.b(this.node),this.DestoryPanelLevel=I.f.DestoryLevel0}playEffect(){
this.finsheffect.SetResetOnPlay(!0),this.finsheffect.Play(!0,!1),this.pareff1.SetActive(!1),this.pareff2.SetActive(!1),this.pareff1.SetActive(!0),this.pareff2.SetActive(!0),
this.finshtxteff.SetResetOnPlay(!0),this.finshtxteff.Play(!0,!1)}OnAddToScene(){this.playEffect()}AnimEnd(){B.Inst_get().CloseFinshEffectView()}Clear(){
this.effectLayer.UpdateRenders(),this.removeLis()}addLis(){this.finsheffect.AddEventHandler(this._degf_AnimEnd)}removeLis(){this.finsheffect.RemoveEventHandler(this._degf_AnimEnd)}
ClearData(){this.Clear()}Destroy(){}}
var g=i(38836),p=i(86133),m=i(9986),S=i(6665),T=i(9776),f=i(93877),C=i(85602),E=i(79534),A=i(75696),L=i(87923),y=i(5968),D=i(85942),O=i(27363),R=i(4586),N=i(79878),M=i(17783),w=i(85890),P=i(15398),v=i(9057),k=i(72005),U=i(98580)
class G extends v.x{constructor(){super(),this.clckBtn=null,this.nameTxt=null,this.lockSp=null,this.acceptTxt=null,this.clickBg=null,this.m_isSelected=!1,this.config=null,
this._degf_OnBgClick=null,this._degf_OnBgClick=(t,e)=>this.OnBgClick(t,e)}InitView(){this.clckBtn=new m.W,this.clckBtn.setId(this.FatherId,this.FatherComponentID,1),
this.nameTxt=new f.Q,this.nameTxt.setId(this.FatherId,this.FatherComponentID,2),this.lockSp=new d.z,this.lockSp.setId(this.FatherId,this.FatherComponentID,3),
this.acceptTxt=new f.Q,this.acceptTxt.setId(this.FatherId,this.FatherComponentID,4),this.clickBg=new k.w,this.clickBg.setId(this.FatherId,this.FatherComponentID,5)}SetData(t){
this.config=t,this.nameTxt.textSet(this.config.resource_get().name),N.Y.RegLuaClick(this.clckBtn.node,this._degf_OnBgClick),this.SetNormalShow()}SetNormalShow(){
this.m_isSelected=!1,this.acceptTxt.textSet(this.GetStateTxt(!1)),this.lockSp.SetActive(!1),this.clckBtn.SetIsEnabled(!0)}SetSelectedShow(){this.m_isSelected=!0,
this.acceptTxt.textSet(this.GetStateTxt(!0)),this.clckBtn.SetIsEnabled(!1)}OnBgClick(t,e){this.SetSelectState()}SetSelectState(){
this.m_isSelected||(null!=G.m_selectedCell&&G.m_selectedCell.SetNormalShow(),G.m_selectedCell=this,G.m_selectedCell.SetSelectedShow())}DealSelectedCell(){G.m_selectedCell=null}
GetStateTxt(t){let e=null
return this.config.status_get()==U.B.CAN_ACCEPT?(e=t?"f4e2b3":"593d21",L.l.SetStringColor(e,(0,p.T)("[可接]"))):this.config.status_get()==U.B.FINISHED?(e="259c2b",
L.l.SetStringColor(e,(0,p.T)("[领奖]"))):""}Clear(){this.m_isSelected=!1,N.Y.DelLuaClick(this.clckBtn.node,this._degf_OnBgClick)}Destroy(){super.Destroy()}}G.m_selectedCell=null
class F extends I.f{constructor(){super(),this.closebtn=null,this.giveUpBtn=null,this.continueBtn=null,this.targetTxt=null,this.describeTxt=null,this.rewardGrid=null,
this.nameGrid=null,this.taskNameTxt=null,this.taskTypeTxt=null,this.normalBtn=null,this.jobBtn=null,this.mainBtn=null,this.branchBtn=null,this.defaultWidget=null,
this.asuramWidget=null,this.continueBtnLabel=null,this.scrollview=null,this.m_model=null,this.btns=null,this.btnPos=null,this.timeIntervalId=-1,this.m_curConfig=null,
this.m_selectBtn=null,this.m_curType=0,this.m_useBtn=null,this._degf_JudgeType=null,this._degf_OkHandler=null,this._degf_OnBtnClick=null,this._degf_OnGetItem=null,
this._degf_OnGetRewardItem=null,this._degf_OnNameReposition=null,this._degf_OnResfresh=null,this._degf_OnRewardReposition=null,this._degf_OnselectOneTask=null,
this._degf_SetDetailTxt=null,this._degf_JudgeType=()=>this.JudgeType(),this._degf_OkHandler=t=>this.OkHandler(t),this._degf_OnBtnClick=(t,e)=>this.OnBtnClick(t,e),
this._degf_OnGetItem=t=>this.OnGetItem(t),this._degf_OnGetRewardItem=t=>this.OnGetRewardItem(t),this._degf_OnNameReposition=()=>this.OnNameReposition(),
this._degf_OnResfresh=t=>this.OnResfresh(t),this._degf_OnRewardReposition=()=>this.OnRewardReposition(),this._degf_OnselectOneTask=t=>this.OnselectOneTask(t),
this._degf_SetDetailTxt=()=>this.SetDetailTxt()}InitView(){this.isExclusionPanel=!0,this.isKillAllExcluded=!0,this.closebtn=new m.W,
this.closebtn.setId(this.FatherId,this.FatherComponentID,1),this.giveUpBtn=new m.W,this.giveUpBtn.setId(this.FatherId,this.FatherComponentID,2),this.continueBtn=new m.W,
this.continueBtn.setId(this.FatherId,this.FatherComponentID,3),this.targetTxt=new f.Q,this.targetTxt.setId(this.FatherId,this.FatherComponentID,4),this.describeTxt=new f.Q,
this.describeTxt.setId(this.FatherId,this.FatherComponentID,5),this.rewardGrid=new S.A,this.rewardGrid.setId(this.FatherId,this.FatherComponentID,6),this.nameGrid=new S.A,
this.nameGrid.setId(this.FatherId,this.FatherComponentID,7),this.taskNameTxt=new f.Q,this.taskNameTxt.setId(this.FatherId,this.FatherComponentID,8),this.taskTypeTxt=new f.Q,
this.taskTypeTxt.setId(this.FatherId,this.FatherComponentID,9),this.normalBtn=new m.W,this.normalBtn.setId(this.FatherId,this.FatherComponentID,10),this.jobBtn=new m.W,
this.jobBtn.setId(this.FatherId,this.FatherComponentID,11),this.mainBtn=new m.W,this.mainBtn.setId(this.FatherId,this.FatherComponentID,12),this.branchBtn=new m.W,
this.branchBtn.setId(this.FatherId,this.FatherComponentID,13),this.defaultWidget=new d.z,this.defaultWidget.setId(this.FatherId,this.FatherComponentID,15),
this.asuramWidget=new d.z,this.asuramWidget.setId(this.FatherId,this.FatherComponentID,16),this.continueBtnLabel=new f.Q,
this.continueBtnLabel.setId(this.FatherId,this.FatherComponentID,18),this.scrollview=new T.h,this.scrollview.setId(this.FatherId,this.FatherComponentID,19),
this.nameGrid.SetInitInfo("ui_task_mainnamecell",this._degf_OnGetItem),this.nameGrid.OnReposition_set(this._degf_OnNameReposition),
this.rewardGrid.SetInitInfo("ui_baseitem",this._degf_OnGetRewardItem),this.rewardGrid.OnReposition_set(this._degf_OnRewardReposition),this.m_model=M.L.Inst_get().model,
this.btns=new C.Z([this.normalBtn,this.jobBtn,this.mainBtn,this.branchBtn]),this.btnPos=new C.Z([new E.P(-519,195),new E.P(-524,131),new E.P(-532,64),new E.P(-538,0)])}
OnRewardReposition(){for(const[t,e]of(0,g.V5)(this.rewardGrid.itemList))e.HideIcon()}OnGetRewardItem(t){const e=new A.j
return e.setId(t,null,0),e}OnNameReposition(){const t=this.nameGrid.itemList
let e=null
if(null!=this.m_curConfig)for(const[i,s]of(0,g.V5)(t))if(s.config==this.m_curConfig){e=s
break}null==e&&t.Count()>0&&(e=t[0]),null!=e&&(e.SetSelectState(),this.OnselectOneTask(e.config)),this.scrollview.ResetPosition(),n.C.Inst_get().CallLater(this._degf_JudgeType)}
JudgeType(){const t=B.Inst_get().btnType
null!=t&&(B.Inst_get().btnType=null,t==B.TYPE_NORMAL&&this.normalBtn.node.activeSelf()?this.OnBtnClick(this.normalBtn.ComponentId,0):t==B.TYPE_JOB&&this.jobBtn.node.activeSelf()?this.OnBtnClick(this.jobBtn.ComponentId,0):t==B.TYPE_MAIN&&this.mainBtn.node.activeSelf()?this.OnBtnClick(this.mainBtn.ComponentId,0):t==B.TYPE_BRANCH&&this.branchBtn.node.activeSelf()&&this.OnBtnClick(this.branchBtn.ComponentId,0))
}OnGetItem(t){const e=new G
return e.setId(t,null,0),e}OnAddToScene(){this.AddOrDelEvent(!0),this.UpdateBtns(),this.SetGridData(this.m_useBtn)}UpdateBtns(){new C.Z
null!=this.m_useBtn&&this.m_useBtn.node.activeSelf()||(this.m_useBtn=null)}AddOrDelEvent(t){t?(this.AddClickEvent(this.closebtn,this._degf_OnBtnClick),
this.AddClickEvent(this.giveUpBtn,this._degf_OnBtnClick),this.AddClickEvent(this.continueBtn,this._degf_OnBtnClick),this.AddClickEvent(this.normalBtn,this._degf_OnBtnClick),
this.AddClickEvent(this.jobBtn,this._degf_OnBtnClick),this.AddClickEvent(this.mainBtn,this._degf_OnBtnClick),this.AddClickEvent(this.branchBtn,this._degf_OnBtnClick),
this.m_model.AddEventHandler(P.M.REFRESH_MAIN_PANEL_LIST,this._degf_OnResfresh)):(this.RemoveClickEvent(this.closebtn,this._degf_OnBtnClick),
this.RemoveClickEvent(this.giveUpBtn,this._degf_OnBtnClick),this.RemoveClickEvent(this.continueBtn,this._degf_OnBtnClick),
this.RemoveClickEvent(this.normalBtn,this._degf_OnBtnClick),this.RemoveClickEvent(this.jobBtn,this._degf_OnBtnClick),this.RemoveClickEvent(this.mainBtn,this._degf_OnBtnClick),
this.RemoveClickEvent(this.branchBtn,this._degf_OnBtnClick),this.m_model.RemoveEventHandler(P.M.REFRESH_MAIN_PANEL_LIST,this._degf_OnResfresh))}OnselectOneTask(t){
this.HideAllView(),this.m_curConfig=t,this.defaultWidget.SetActive(!0),this.taskNameTxt.textSet(R.G.CutColorStr(this.m_curConfig.taskName_get())),this.SetDetailTxt(),
n.C.Inst_get().ClearInterval(this.timeIntervalId),this.timeIntervalId=n.C.Inst_get().SetInterval(this._degf_SetDetailTxt,1e3,-1)
const e=this.m_curConfig.GetAllRewardList(!1)
this.rewardGrid.data_set(e),this.giveUpBtn.node.SetActive(!0),this.continueBtn.node.SetActive(!0)
const i=this.continueBtn.node.transform.GetLocalPosition()
let s="comm_bt_0012",l="2F2927"
this.m_curConfig.canGiveup_get()?(this.giveUpBtn.node.SetActive(!0),i.x=385):(this.giveUpBtn.node.SetActive(!1),i.x=283,s="comm_bt_0013",l="F4E2B3"),
this.continueBtn.node.transform.SetLocalPosition(i),E.P.Recyle(i)
let a=(0,p.T)("立即前往")
this.m_curConfig.isClickReward_get()&&(a=(0,p.T)("领取奖励")),this.continueBtn.normalSpriteSet(s),this.continueBtnLabel.textSet(L.l.SetStringColor(l,a))}SetDetailTxt(){
if(null==this.m_curConfig)return
let t=null
t=N.Y.GetLinkInfo(this.m_curConfig)
let e=""
null!=t.txtStr&&(e+=t.txtStr),null!=t.progresStr&&(e+=`（${t.progresStr}）`),t.Clear()}ClearView(){this.taskNameTxt.textSet(""),this.describeTxt.textSet(""),
this.targetTxt.textSet(""),this.rewardGrid.data_set(null),this.giveUpBtn.node.SetActive(!1),this.continueBtn.node.SetActive(!1)}OnResfresh(t){this.UpdateBtns(),
this.UpdateGrid(this.m_useBtn)}OnBtnClick(t,e){if(this.closebtn.ComponentId==t)B.Inst_get().CloseView()
else if(this.giveUpBtn.ComponentId==t){const t=new D.N
t.showText=(0,p.T)("确定放弃此任务吗？"),t.okhandler=this._degf_OkHandler,t.tipstype=2,y.Z.Inst.OpenView(t)}else this.continueBtn.ComponentId==t?(O.Y.inst.DealClick(this.m_curConfig),
B.Inst_get().CloseView()):this.normalBtn.ComponentId==t?this.SetGridData(this.normalBtn):this.jobBtn.ComponentId==t?this.SetGridData(this.jobBtn):this.mainBtn.ComponentId==t?this.SetGridData(this.mainBtn):this.branchBtn.ComponentId==t&&this.SetGridData(this.branchBtn)
}OkHandler(t){M.L.Inst_get().mgr.RequestCM_GiveUp(this.m_curConfig)}SetGridData(t){this.UpdateGrid(t)}UpdateGrid(t){this.HideAllView(),this.m_useBtn=t,
this.m_curType=this.GetTaskType(this.m_useBtn)}GetTaskType(t){return this.ClearView(),G.DealSelectedCell(),t==this.jobBtn?(this.taskTypeTxt.textSet((0,p.T)("转职任务")),
this.ChangeBtnState(this.jobBtn),w.U.CHANGE_JOB):t==this.mainBtn?(this.taskTypeTxt.textSet((0,p.T)("主线任务")),this.ChangeBtnState(this.mainBtn),
w.U.MAIN):t==this.branchBtn?(this.taskTypeTxt.textSet((0,p.T)("支线任务")),this.ChangeBtnState(this.branchBtn),w.U.BRANCH):(this.taskTypeTxt.textSet((0,p.T)("常规任务")),
this.ChangeBtnState(this.normalBtn),-1)}GetType(t){return 0==t?-1:1==t?w.U.CHANGE_JOB:2==t?w.U.MAIN:w.U.BRANCH}HideAllView(){this.defaultWidget.SetActive(!1),
this.asuramWidget.SetActive(!1)}ChangeBtnState(t){null!=this.m_selectBtn&&this.m_selectBtn.SetIsEnabled(!0),this.m_selectBtn=t,this.m_selectBtn.SetIsEnabled(!1)}Clear(){
n.C.Inst_get().ClearInterval(this.timeIntervalId),this.AddOrDelEvent(!1),this.m_curConfig=null,null!=this.m_selectBtn&&this.m_selectBtn.SetIsEnabled(!0),this.m_selectBtn=null}
Destroy(){this.closebtn=null,this.giveUpBtn=null,this.continueBtn=null,this.targetTxt=null,this.describeTxt=null,this.rewardGrid.Destroy(),this.rewardGrid=null,
this.nameGrid.Destroy(),this.nameGrid=null,this.taskNameTxt=null,this.taskTypeTxt=null,this.normalBtn=null,this.jobBtn=null,this.mainBtn=null,this.branchBtn=null,this.btns=null,
this.btnPos=null,this.m_useBtn=null,this.m_curConfig=null,this.defaultWidget=null,this.asuramWidget=null}}class B{constructor(){this.view=null,this.btnType=null,
this.finsheffectview=null,this.finishTaskCfg=null,this._degf_CallDestory=null,this._degf_Complete=null,this._degf_FinshEffectCallDestory=null,this._degf_FinshEffectComplete=null,
this._degf_CallDestory=()=>this.CallDestory(),this._degf_Complete=t=>this.Complete(t),this._degf_FinshEffectCallDestory=()=>this.FinshEffectCallDestory(),
this._degf_FinshEffectComplete=t=>this.FinshEffectComplete(t)}static Inst_get(){return null==B._inst&&(B._inst=new B),B._inst}OpenView(t){
if(null!=this.view&&this.view.isShow_get())return
this.btnType=t
const e=new l.v
e.isShowMask=!0,e.isDefaultUITween=!0,r.N.inst.OpenById(o.I.TaskMainPanel,this._degf_Complete,this._degf_CallDestory,e)}Complete(t){return null==this.view&&(this.view=new F,
this.view.setId(t,null,0)),this.view}CallDestory(){a.g.DestroyUIObj(this.view),this.view=null}CloseView(){
null!=this.view&&this.view.isShow_get()&&r.N.inst.CloseById(o.I.TaskMainPanel)}GetMainPanelFatherId(){return null!=this.view?this.view.FatherId:-1}OnRewardOneTask(t){const e=t
null!=e&&e.resource_get().completeSpecialEffects&&this.OpenFinshEffectView(e),n.C.Inst_get().SetInterval(this.CreateDelegate(this.CloseFinshEffectView),1800,1),
s.j.Inst.PlayByDivision("FinishTask")}OpenFinshEffectView(t){this.finishTaskCfg=t,
null!=this.finsheffectview&&(this.finsheffectview.node.activeSelf()?this.finsheffectview.OnAddToScene():this.finsheffectview.node.SetActive(!0))
const e=new l.v
e.layerType=h.F.Tip,e.isSetActiveClose=!1,r.N.inst.OpenById(o.I.TaskFinshEffect,this._degf_FinshEffectComplete,this._degf_FinshEffectCallDestory,e)}FinshEffectComplete(t){
return null==this.finsheffectview&&(this.finsheffectview=new c,this.finsheffectview.setId(t,null,0)),this.finsheffectview}FinshEffectCallDestory(){
a.g.DestroyUIObj(this.finsheffectview),this.finsheffectview=null}CloseFinshEffectView(){
null!=this.finsheffectview&&this.finsheffectview.isShow_get()&&r.N.inst.CloseById(o.I.TaskFinshEffect)}}B._inst=null,B.TYPE_NORMAL="1",B.TYPE_JOB="2",B.TYPE_MAIN="3",
B.TYPE_BRANCH="4"},79878:(t,e,i)=>{i.d(e,{Y:()=>jt})
var s=i(77546),n=i(38836),l=i(86133),a=i(31262),r=i(36241),o=i(62370),h=i(98130),d=i(98885),_=i(15965),u=i(21554),I=i(70850),c=i(74045),g=i(49067),p=i(29839),m=i(61149),S=i(84458),T=i(62265),f=i(98958),C=i(68662),E=i(95417),A=i(70829),L=i(85682),y=i(85602),D=i(72785),O=i(38962),R=i(63412),N=i(1240),M=i(86770),w=i(59918),P=i(26753),v=i(14143),k=i(54415),U=i(31922),G=i(13526),F=i(72800),B=i(46749),H=i(2457),V=i(33138),b=i(48481),x=i(37189),q=i(90156),Y=i(82949),K=i(8211),J=i(43308),Q=i(41864),Z=i(35259),X=i(82474),$=i(54918),W=i(23833),j=i(98800),z=i(96098),tt=i(91238),et=i(94954),it=i(19176),st=i(13687),nt=i(5924),lt=i(66788),at=i(31222),rt=i(79534),ot=i(84308),ht=i(87923),dt=i(86209),_t=i(87048),ut=i(9659),It=i(21267),ct=i(98504),gt=i(77697),pt=i(62783),mt=i(12970),St=i(21334),Tt=i(98580),ft=i(89803),Ct=i(85890),Et=i(15398),At=i(19519),Lt=i(68214)
class yt{constructor(t,e,i,s,n,l,a){this.mapId=0,this.x=0,this.y=0,this.isForTask=!1,this.taskId=0,this.isTask=!1,this.reduceDistance=0,this.flyId=0,this.npcId=0,
this.callback=null,this.o1=null,null==a&&(a=0),null==l&&(l=0),null==n&&(n=0),null==s&&(s=!1),this.mapId=t,this.x=e,this.y=i,this.isForTask=s,this.taskId=n,this.reduceDistance=l,
this.flyId=a}GetFlyId(){return this.flyId>0?this.flyId:this.npcId>0?this.npcId:0}}
var Dt,Ot,Rt=i(99535),Nt=i(47963),Mt=i(17783),wt=i(18998),Pt=i(42292),vt=i(33822),kt=i(61033),Ut=i(44139),Gt=i(61646),Ft=i(93701),Bt=i(4926),Ht=i(35128),Vt=i(63076),bt=i(15033),xt=i(97331),qt=i(44498),Yt=i(73341),Kt=i(47786),Jt=i(22662),Qt=i(92085),Zt=i(65550),Xt=i(85942),$t=i(31931),Wt=i(48550)
let jt=(0,Pt.Y_)("TaskUtil")((Ot=class t{GetTypeName(t,e){null==e&&(e=!0)
let i=""
if(t==Ct.U.MAIN)i=(0,l.T)("主")
else if(t==Ct.U.BRANCH)i=(0,l.T)("支")
else if(t==Ct.U.CHANGE_JOB)return i=(0,l.T)("职"),e&&(i+=(0,l.T)("任务")),i}static GetTypeNameWithoutColor(t,e){null==e&&(e=!0)
let i=""
return t==Ct.U.MAIN?i=(0,l.T)("主线"):t==Ct.U.BRANCH?i=(0,l.T)("支线"):t==Ct.U.CHANGE_JOB&&(i=(0,l.T)("转职")),e&&(i+=(0,l.T)("任务")),i}GetTraceNameColor(t){let e=""
return t==Ct.U.MAIN?e="[e2a66a]":(t==Ct.U.BRANCH||t==Ct.U.CHANGE_JOB)&&(e="[f4e2b3]"),e}GetTargetValue(t){if(null!=t.targets&&0!=t.targets.count){return t.targets[0].value_get()}
return 0}static SetResult(e,...i){const s=[...i]
let n=s[0]
"object"==typeof n?e[0]=t.JointStr(new y.Z(n)):"string"==typeof n&&(e[0]=n)
for(let t=1;t<s.length;t++)e[t]=s[t]}static JudgeOpenPanelHandle(e,i,s,n,l){let a="",r=0,o=""
const h=new y.Z([d.M.IntToString(S.V.OPEN_PANEL),e.OpenUI_get(),d.M.IntToString(n.id_get())])
return a=t.JointStr(h),null!=s&&(r=s[i].value_get()),o=`${d.M.DoubleToString(r)}/${l}`,n.linkStr=a,[a,o]}static SendListRefresh(){nt.C.Inst_get().CallLater(t.SendRefresh)}
static SendRefresh(){if(0==j.Y.Inst.PrimaryRoleInfo_get().Id_get().ToNum())return
Mt.L.Inst_get().model.RaiseEvent(Et.M.REFRESH_MAIN_PANEL_LIST),t.isEnterScene&&t.PlayEffect()}static ShowNpcFromScene(){Mt.L.Inst_get().model.npcEffectDic.LuaDic_Clear(),
t.isEnterScene=!0,t.PlayEffect()}static PlayEffect(){const e=Mt.L.Inst_get().model.judgeDic
t.npcTask.Clear(),t.npcEffIdDic.Clear()
for(const[i,s]of(0,n.V5)(e))t.SetNpcTaskState(s)
mt.F.getInst().SetTaskList(t.npcTask)}static SetNpcTaskState(e){const i=Mt.L.Inst_get().model.npcEffectDic
e.isStatusChanged&&(e.isStatusChanged=!1),e.currentEffectId>0&&(Ft.a.ins.DeleteEffShowById(e.currentEffectId),e.currentEffectId=0)
const s=e.linkNpcId_get()
if(s>0){const n=j.Y.Inst.getNpcById(s)
if(null!=n){if(i.LuaDic_ContainsKey(s)){if(null!=t.npcEffIdDic[s]&&t.GetnpcEffectIdSortId(t.npcEffIdDic[s])>=t.GetnpcEffectIdSortId(e.npcEffectId_get()))return
Ft.a.ins.DeleteEffShowById(i[s])}const l=n.GetPos()
n.GetHandle()
let a=new Bt.E
a.source=n,a.target=n,a.effRole=n,a.speedRate=4.7,a.SetCfg(e.npcEffectId_get()),a.SetPoint(l.x,l.z+1.5),e.currentEffectId=Ft.a.ins.showEffectByData(a),
t.npcEffIdDic.LuaDic_AddOrSetItem(s,e.npcEffectId_get()),e.currentEffectId>0&&i.LuaDic_AddOrSetItem(s,e.currentEffectId),t.npcTask.Add(e)}}}static GetnpcEffectIdSortId(t){
return t==Gt.k.CAN_REWARD_TASK?3:t==Gt.k.CAN_ACCEPT_TASK?2:t==Gt.k.UNFINISH_TASK?1:0}static RegLuaClick(t,e){t.on(wt.NodeEventType.TOUCH_END,e)}static DelLuaClick(t,e){
t.off(wt.NodeEventType.TOUCH_END,e)}static GetLinkInfo(e,i){null==i&&(i=!1)
let s=""
return s=e.resource_get().underwayText,t.SetDetailInfo(e,s,i)}static SetDetailInfo(e,i,s){null==s&&(s=!1)
const n=d.M.Split(i,o.o.s_Arr_UNDER_CHAR_DOLL)
let a=null,r=null,h=null
const _=Lt.a.GetInst()
let u=null
if(s)null!=e.qVo?t.DealTaskStep(e,_,n,e.qVo.targets,2):t.DealTaskStep(e,_,n,null,2)
else if(e.status_get()==Tt.B.CAN_ACCEPT||e.status_get()==Tt.B.NONE)if(e.resource_get().receiveType!=R.U.RECEIVE_BY_NPC||ht.l.IsEmptyStr(e.resource_get().receiveValue))t.DealTaskStep(e,_,n,null,1)
else{const i=gt.f.Inst().getItemById(e.AcceptNpcId_get())
let s=""
if(null==i?lt.Y.LogError((0,l.T)("2任务ID：")+(e.logId_get()+((0,l.T)("找不到NPC: AcceptNpcId:")+e.AcceptNpcId_get()))):s=i.name,
u=new y.Z([d.M.IntToString(S.V.FIND_PATH),d.M.IntToString(ft.d.TALK_VALUE),d.M.IntToString(e.id_get()),d.M.IntToString(e.AcceptNpcId_get()),d.M.IntToString(e.AcceptNpcMapId_get()),d.M.FloatToString(e.AcceptNpcX_get()),d.M.FloatToString(e.AcceptNpcY_get())]),
r=t.JointStr(u),a=ht.l.SetLinkStr(s,r,null,!1),!ht.l.IsEmptyStr(n[1])){const t=new y.Z([a])
a=ht.l.Substitute(n[1],t)}e.linkStr=r,_.AddItem(a,r,null,null,null)
}else if(e.status_get()==Tt.B.ACCEPTED)null!=e.qVo?t.DealTaskStep(e,_,n,e.qVo.targets,2):t.DealTaskStep(e,_,n,null,2)
else if(e.status_get()==Tt.B.FINISHED){const i=e.GetIntersectionType()
if(i==R.U.INTERSECTION_NPC||i==R.U.INTERSECTION_CLICK){const i=gt.f.Inst().getItemById(e.RewardNpcId_get())
if(null!=i&&(u=e.isHandInTask_get()?new y.Z([d.M.IntToString(S.V.HAND_IN),d.M.IntToString(ft.d.TALK_VALUE),d.M.IntToString(e.id_get()),d.M.IntToString(i.npcid)]):new y.Z([d.M.IntToString(S.V.FIND_PATH),d.M.IntToString(ft.d.TALK_VALUE),d.M.IntToString(e.id_get()),d.M.IntToString(i.npcid)])),
r=t.JointStr(u),r+=o.o.s_UNDER_CHAR+e.finishStateNPCPosStr_get(),null!=i&&(h=ht.l.SetLinkStr(i.name,r,null,!1)),e.linkStr=r,
e.IsCurrency_get()&&e.tCTargetDefs_get().tCTargetDefs[0].type==ft.d.CURRENCY_BACK){const t=e.tCTargetDefs_get().tCTargetDefs[0],s=(At.J.GetCurrencyStr(t.param.currencyType),
At.J.GetGold(j.Y.Inst.PrimaryRoleInfo_get(),t.param.currencyType)),l=dt.w.Instance.ConvertNumToUnitize(s),a=dt.w.Instance.ConvertNumToUnitize(t.value)
let o=""
o=s<t.value?`${l}/${a}`:`[5FB470]${a}/${a}[-]`
const h=d.M.ReplaceOne(n[3],"{0}",i.name)
_.AddItem(h,r,o,null,null)}else{if(n.count<4&&lt.Y.LogError(`${(0,l.T)("任务:")}${e.taskName_get()} id:${e.id_get()+(0,l.T)("的underwayText字段，$数量不匹配，应取第4段")}`),null!=h){
const e=new y.Z(1)
e[0]=h,a=ht.l.Substitute(t.GetStrByIndex(n,3),e)}else a=t.GetStrByIndex(n,3)
_.AddItem(a,r,null,null,null)}}else if(i==R.U.RECEIVE_ITEM)t.DealTaskStep(e,_,n,e.qVo.targets,3)
else if(i==R.U.RECEIVE_VIEW&&e.type_get()==Ct.U.CHANGE_JOB)t.DealTaskStep(e,_,n,e.qVo.targets,3)
else{let i=0
i=e.GetTargetOpenUI(),0!=i&&""!=i||(i=e.m_resource.intersectionValue),u=new y.Z([d.M.IntToString(S.V.OPEN_PANEL),i,d.M.IntToString(e.id_get())]),r=t.JointStr(u)
let s=""
n.count>3&&(s=n[3])
const l=gt.f.Inst().getItemById(e.RewardNpcId_get())
null!=l&&(s=d.M.Replace(s,"{0}",l.name)),h=ht.l.SetLinkStr(s,r,null,!1),e.linkStr=r,_.AddItem(h,r,null,null,null)}}return _}static GetStrByIndex(t,e){
return null==t||0==t.count?"":e>-1&&e<t.count?t[e]:""}static DealTaskStep(e,i,s,n,l){t.DealTaskStepEx(e,e.tCTargetDefs_get(),i,s,n,l)}static DealTaskStepEx(e,i,s,n,a,r){
let o=null,h=null
if(t.m_subArr.Clear(),e.linkTarget=null,i.tCTargetDefs.Count()>=1){const i=e.GetNowTargetDef()
o=t.JudgeType(i,i.key-1,a,e),0==t.m_subArr.Count()&&t.m_subArr.Add(o[1]),e.linkTarget=i,e.linkStr=o[0],1==n.count&&""==n[0]?h="":n.count<=r?(lt.Y.LogError(`${(0,
l.T)("任务:")}${e.taskName_get()} id:${e.id_get()+((0,l.T)("的underwayText字段，$数量不匹配，应取第")+(r+1+(0,l.T)("段")))}`),
h=""):h=i.IsNeedFixAttr()?e.status_get()==Tt.B.FINISHED?ht.l.Substitute(n[r],t.m_subArr):t.AnalysePointTask(e,i,n[r]):ht.l.Substitute(n[r],t.m_subArr)
const _=d.M.RegexMatch(h,t.PRO_COLOR_TAG)
let u=""
null!=_&&_.length>=8&&(u=d.M.SubStringWithLen(_,2,6),h=d.M.Replace(h,_,""))
let I=!1
const c=d.M.RegexMatch(h,t.PRO_TAG)
let g=0
if(null!=c&&c.length>=3)g=d.M.String2Int(d.M.GetAt(c,2)),h=d.M.Replace(h,c,""),I=!0
else if(d.M.IndexOf(h,t.PRO_LINE_TAG,0)>-1){const e=d.M.IndexOf(h,t.PRO_LINE_TAG,0),i=d.M.SubStringWithEnd(h,e+6,e+7)
h=d.M.Replace(h,`{aLine${i}}`,""),s.prohangeLine=d.M.String2Int(i),I=!0}I||(o[2]=null),s.AddItem(h,o[0],o[2],g,u),s.targetOriginalStr=o[1],s.progresOriginalStr=o[3],
s.replaceStr=o[4]}}static AnalysePointTask(e,i,s){let n=j.Y.Inst.PrimaryRoleInfo_get()
if(e.qVo){const t=j.Y.Inst.GetCreateIdxById(e.qVo.playerId)
n=j.Y.Inst.primaryRoleInfoList[t]}t.m_needPoint=0,t.needPointList=new y.Z([0,0,0,0])
let l="",a=0
if(i.type==ft.d.POINT_LEARN_SKILL){a=10534
const e=I.g.Inst_get().getItemresource(d.M.String2Int(i.param.itemModelId)).Conditions_get().typevalues
let r=0
for(;r<e.Count();){const i=e[r].valueType,l=e[r].valueNum
s=t.subAttResult(s,i,l,n),r+=1}l=A.j.Inst().GetSkillById(d.M.String2Int(i.param.skillId)).name}else if(i.type==ft.d.EQUIPMENT_EQUIP||i.type==ft.d.ONE_QUEST){a=10535
const e=new O.X,r=I.g.Inst_get().getEquipResourceCfg(d.M.String2Int(i.param.itemModelId))
l=I.g.Inst_get().getItemresource(d.M.String2Int(i.param.itemModelId)).name,i.param.equipenhancelevel,
r.strengthLimit>0&&(e.LuaDic_ContainsKey("Strength")?e.Strength+=r.strengthLimit:e.LuaDic_AddOrSetItem("Strength",r.strengthLimit)),
r.agilityLimit>0&&(e.LuaDic_ContainsKey("Agility")?e.Agility+=r.agilityLimit:e.LuaDic_AddOrSetItem("Agility",r.agilityLimit)),
r.vitalityLimit>0&&(e.LuaDic_ContainsKey("Vitality")?e.Vitality+=r.vitalityLimit:e.LuaDic_AddOrSetItem("Vitality",r.vitalityLimit)),
r.intelligenceLimit>0&&(e.LuaDic_ContainsKey("Intelligence")?e.Intelligence+=r.intelligenceLimit:e.LuaDic_AddOrSetItem("Intelligence",r.intelligenceLimit)),
e.LuaDic_ContainsKey("Strength")&&(s=t.subAttResult(s,"Strength",e.Strength,n)),e.LuaDic_ContainsKey("Agility")&&(s=t.subAttResult(s,"Agility",e.Agility,n)),
e.LuaDic_ContainsKey("Vitality")&&(s=t.subAttResult(s,"Vitality",e.Vitality,n)),e.LuaDic_ContainsKey("Intelligence")&&(s=t.subAttResult(s,"Intelligence",e.Intelligence,n))}
if(t.m_needPoint>0&&n.RemainBasePoint_get()<t.m_needPoint){const i=xt.n.Inst_get().GetUpLvByNeedPint(n,t.m_needPoint-n.RemainBasePoint_get(),t.needPointList)
if(-2==i)return Kt.x.Inst().getItemById(11020383).sys_messsage
if(s=d.M.Replace(s,"{repLevel}",d.M.IntToString(i)),s=d.M.Replace(s,"{repTarget}",l),d.M.IndexOf(s,"{all}",0)>-1){let e=t.taskRedStr
0!=n.RemainBasePoint_get()&&n.RemainBasePoint_get()>=t.m_needPoint&&(e=t.taskGreenStr)
const i=ht.l.SetStringColor(e,d.M.DoubleToString(t.m_needPoint))
s=d.M.Replace(s,"{all}",i)}e.SetIsAddedPoint(!0)}else{const t=f.V.Inst().getStr2(a)
s=d.M.Replace(t,"{repTarget}",l),e.SetIsAddedPoint(!1)}return s}static subAttResult(e,i,s,n){let a=0,r=0,o=null,h=null
if("Strength"==i){if(a=qt.I.GetAttrByStr("Strength"),r=n.getAttribute(a),o=ht.l.txtRedStr,r>=s?o=ht.l.txtGreenStr:(t.needPointList[0]=s-r,t.m_needPoint+=t.needPointList[0]),
h=ht.l.SetStringColor(o,d.M.IntToString(s)),e=d.M.Replace(e,"{str}",h),d.M.IndexOf(e,"{strLeft}",0)>-1){const i=(0,l.T)("还需{strLeft}")
r>=s?e=d.M.Replace(e,i,ht.l.SetStringColor(t.taskGreenStr,(0,l.T)("已满足"))):(h=ht.l.SetStringColor(ht.l.txtRedStr,(0,l.T)("还需")+(s-r+(0,l.T)("点"))),e=d.M.Replace(e,i,h))}
}else if("Vitality"==i){if(a=qt.I.GetAttrByStr("Vitality"),r=n.getAttribute(a),o=ht.l.txtRedStr,r>=s?o=ht.l.txtGreenStr:(t.needPointList[2]=s-r,t.m_needPoint+=t.needPointList[2]),
h=ht.l.SetStringColor(o,d.M.IntToString(s)),e=d.M.Replace(e,"{vit}",h),d.M.IndexOf(e,"{vitLeft}",0)>-1){const i=(0,l.T)("还需{vitLeft}")
r>=s?e=d.M.Replace(e,i,ht.l.SetStringColor(t.taskGreenStr,(0,l.T)("已满足"))):(h=ht.l.SetStringColor(ht.l.txtRedStr,(0,l.T)("还需")+(s-r+(0,l.T)("点"))),e=d.M.Replace(e,i,h))}
}else if("Intelligence"==i){if(a=qt.I.GetAttrByStr("Intelligence"),r=n.getAttribute(a),o=ht.l.txtRedStr,r>=s?o=ht.l.txtGreenStr:(t.needPointList[3]=s-r,
t.m_needPoint+=t.needPointList[3]),h=ht.l.SetStringColor(o,d.M.IntToString(s)),e=d.M.Replace(e,"{int}",h),d.M.IndexOf(e,"{intLeft}",0)>-1){const i=(0,l.T)("还需{intLeft}")
r>=s?e=d.M.Replace(e,i,ht.l.SetStringColor(t.taskGreenStr,(0,l.T)("已满足"))):(h=ht.l.SetStringColor(ht.l.txtRedStr,(0,l.T)("还需")+(s-r+(0,l.T)("点"))),e=d.M.Replace(e,i,h))}
}else if("Agility"==i&&(a=qt.I.GetAttrByStr("Agility"),r=n.getAttribute(a),o=ht.l.txtRedStr,r>=s?o=ht.l.txtGreenStr:(t.needPointList[1]=s-r,t.m_needPoint+=t.needPointList[1]),
h=ht.l.SetStringColor(o,d.M.IntToString(s)),e=d.M.Replace(e,"{agi}",h),d.M.IndexOf(e,"{agiLeft}",0)>-1)){const i=(0,l.T)("还需{agiLeft}")
r>=s?e=d.M.Replace(e,i,ht.l.SetStringColor(t.taskGreenStr,(0,l.T)("已满足"))):(h=ht.l.SetStringColor(ht.l.txtRedStr,(0,l.T)("还需")+(s-r+(0,l.T)("点"))),e=d.M.Replace(e,i,h))}return e}
static JudgeType(e,i,s,n){const a=new y.Z(5)
let r=null,h="",_=0,u=""
ht.l.txtGreenStr
let c=null,g=null,p=null
if(e.type==ft.d.NONE)t.SetResult(a,"","",""),n.linkStr=""
else if(e.type==ft.d.TALK||e.type==ft.d.REAL_TALK||e.type==ft.d.TRANSFER_JOB_TEST){const i=gt.f.Inst().getItemById(e.param.npcId)
let s=""
null==i?lt.Y.LogError(`${(0,l.T)("3任务ID：")}${n.logId_get()}${(0,l.T)("找不到NPC:")}${e.param.npcId}`):s=i.name,p=e.param.npcPosStr_get(e.param.npcId!=i.npcid),
0==e.param.isTransmit?r=new y.Z([d.M.IntToString(S.V.FIND_PATH),d.M.IntToString(ft.d.TALK_VALUE),d.M.IntToString(n.id_get()),d.M.IntToString(i.npcid),p]):1==e.param.isTransmit&&(r=new y.Z([d.M.IntToString(S.V.TRANSMIT_PATH),d.M.IntToString(ft.d.TALK_VALUE),d.M.IntToString(n.id_get()),d.M.IntToString(i.npcid),p])),
h=t.JointStr(r),n.linkStr=h,t.SetResult(a,h,ht.l.SetLinkStr(s,h,null,!1))
}else if(e.type==ft.d.KILL_MONSTER||e.type==ft.d.GATHER||e.type==ft.d.GATHER_ITEM||e.type==ft.d.KILL_MONSTER_ITEM||e.type==ft.d.KILL_MONSTER_RATE||e.type==ft.d.FICTITIOUS_ITEM||e.type==ft.d.KILL_MIRACLE_MONSTER||e.type==ft.d.MONSTER_DROP_EQUIP||e.type==ft.d.KILL_FIELD_MONSTER)t.JudgeKillMonster(a,e,i,s,n)
else if(e.type==ft.d.PASS_COPY||e.type==ft.d.ENTER_COPY||e.type==ft.d.CLIMB_TOWER_STAR)t.JudgePassCopy(a,e,i,s,n)
else if(e.type==ft.d.CONSUME_CURRENCY){r=new y.Z([d.M.IntToString(S.V.OPEN_PANEL),e.OpenUI_get(),d.M.IntToString(n.id_get())]),h=t.JointStr(r)
const l=e.param.type,o=At.J.GetCurrencyStr(l)
g=dt.w.Instance.ConvertNumToUnitize(e.value),null!=s&&(_=s[i].value_get()),c=dt.w.Instance.ConvertNumFloor(_),u=`${c}/${g}`,t.SetResult(a,h,o,u)
}else if(e.type==ft.d.CURRENCY||e.type==ft.d.CURRENCY_HISTORY||e.type==ft.d.CURRENCY_BACK||e.type==ft.d.HAND_IN_CURRENCY){const l=gt.f.Inst().getItemById(n.RewardNpcId_get())
if(l){
r=new y.Z([d.M.IntToString(S.V.FIND_PATH),d.M.IntToString(ft.d.TALK_VALUE),d.M.IntToString(n.id_get()),d.M.IntToString(n.RewardNpcId_get()),d.M.IntToString(l.mapid),d.M.FloatToString(l.x),d.M.FloatToString(l.y)]),
h=t.JointStr(r)
let i=e.param.currencyType
ht.l.IsEmptyStr(i)&&(i=e.param.type)
const s=At.J.GetCurrencyStr(i),o=At.J.GetGold(j.Y.Inst.PrimaryRoleInfo_get(),i)
c=dt.w.Instance.ConvertNumFloor(o),g=dt.w.Instance.ConvertNumToUnitize(e.value),o<e.value&&(u=`${c}/${g}`),t.SetResult(a,h,s,u)}else[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),
t.SetResult(a,h,d.M.DoubleToString(e.value),u)
}else if(e.type==ft.d.COMPLETED_ACHIEVEMENT_NUM)r=new y.Z([d.M.IntToString(S.V.OPEN_PANEL),e.OpenUI_get(),d.M.IntToString(n.id_get())]),h=t.JointStr(r),
null!=s&&(_=s[i].value_get()),t.SetResult(a,h,d.M.DoubleToString(e.value),`${d.M.DoubleToString(_)}/${e.value}`)
else if(e.type==ft.d.HAND_IN_ITEM)t.JudgeHandInItem(a,e,i,s,n)
else if(e.type==ft.d.HAND_IN_ITEM_GROUP)t.JudgeHandInItemGroup(a,e,i,s,n)
else if(e.type==ft.d.HAND_IN_EQUIPMENT)t.JudgeHandInEquipment(a,e,i,s,n)
else if(e.type==ft.d.EQUIPMENT_ENHANCE_TIME||e.type==ft.d.EQUIPMENT_ADD_TIME||e.type==ft.d.EQUIPMENT_ENHANCE_LEVEL){
if(r=new y.Z([d.M.IntToString(S.V.OPEN_PANEL),e.OpenUI_get(),d.M.IntToString(n.id_get())]),h=t.JointStr(r),null!=s&&(_=s[i].value_get()),null!=e.param&&null!=e.param.equipType){
const i=w.R.GetName(e.param.equipType)
e.type==ft.d.EQUIPMENT_ENHANCE_TIME?(r=new y.Z([d.M.IntToString(S.V.OPEN_STRENG_PANEL),e.OpenUI_get(),`${ft.d.EQUIPMENT_ENHANCE_TIME_VALUE}|${e.param.equipType}`]),
h=t.JointStr(r)):e.type==ft.d.EQUIPMENT_ADD_TIME&&(r=new y.Z([d.M.IntToString(S.V.OPEN_STRENG_PANEL),e.OpenUI_get(),`${ft.d.EQUIPMENT_ADD_TIME_VALUE}|${e.param.equipType}`]),
h=t.JointStr(r)),u=`${d.M.DoubleToString(_)}/${e.value}`,t.m_subArr=new y.Z([i,d.M.DoubleToString(e.value)]),t.SetResult(a,h,ht.l.SetLinkStr(i,h,null,!1),u)
}else u=`${d.M.DoubleToString(_)}/${e.value}`,t.SetResult(a,h,ht.l.SetLinkStr(u,h,null,!1),u)
n.linkStr=h}else if(e.type==ft.d.COMPLETE_QUEST){let l="",o=0
if(e.param.questId>0){const t=Mt.L.Inst_get().model.GetTaskById(e.param.questId)
o=t.type_get(),l=t.taskName_get()}else e.param.questType>0&&(o=e.param.questType,l=t.GetTypeNameWithoutColor(e.param.questType,null))
r=new y.Z([d.M.IntToString(S.V.OPEN_PANEL),e.OpenUI_get(),d.M.IntToString(n.id_get())]),h=t.JointStr(r),null!=s&&(_=s[i].value_get()),_<e.value&&(n.linkStr=h,
u=`${d.M.DoubleToString(_)}/${e.value}`),t.m_subArr=new y.Z([d.M.DoubleToString(e.value),l]),t.SetResult(a,h,ht.l.SetLinkStr(l,h,null,!1),u),n.linkStr=h
}else if(e.type==ft.d.NEW_TITLE)r=new y.Z([d.M.IntToString(S.V.OPEN_PANEL),e.OpenUI_get(),d.M.IntToString(n.id_get())]),h=t.JointStr(r),n.linkStr=h,
t.SetResult(a,h,ht.l.SetLinkStr("",h,null,!1))
else if(e.type==ft.d.EQUIPMENT_EQUIP||e.type==ft.d.EQUIPMENT_EQUIP_EQUAL){if(null!=s&&(_=s[i].value_get()),d.M.IsNullOrEmpty(e.OpenUI_get())){if(p="",e.npcId>0){
e.param.npcId=e.npcId,p=e.param.npcPosStr_get(null)
gt.f.Inst().getItemById(e.npcId)}r=new y.Z([d.M.IntToString(S.V.FIND_PATH),d.M.IntToString(ft.d.EQUIPMENT_EQUIP_VALUE),d.M.IntToString(n.id_get()),d.M.IntToString(e.npcId),p])
}else r=new y.Z([d.M.IntToString(S.V.OPEN_PANEL),e.OpenUI_get(),d.M.IntToString(n.id_get())])
h=t.JointStr(r),u=`${d.M.DoubleToString(_)}/${e.value}`,e.param.star>0?t.m_subArr=new y.Z([d.M.IntToString(e.param.star),ht.l.getEquiplvStr2(e.param.equipStepLv)+w.R.GetName(e.param.equipType)]):t.m_subArr=new y.Z([ht.l.getEquiplvStr2(e.param.equipStepLv)+w.R.GetName(e.param.equipType)]),
a[2]=ht.l.SetLinkStr(u,h,null,!1),t.SetResult(a,h,d.M.DoubleToString(e.value),ht.l.SetLinkStr(u,h,null,!1))
}else if(e.type==ft.d.MELTING_TIME)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,d.M.DoubleToString(e.value),u)
else if(e.type==ft.d.GLOBING_MERCHAT_BUY||e.type==ft.d.GLOBING_MERCHAT_REFRESH)r=new y.Z([d.M.IntToString(S.V.OPEN_PANEL),e.OpenUI_get(),d.M.IntToString(n.id_get())]),
h=t.JointStr(r),null!=s&&(_=s[i].value_get()),t.SetResult(a,h,d.M.DoubleToString(e.value),`${d.M.DoubleToString(_)}/${e.value}`)
else if(e.type==ft.d.TRANSFER)t.SetResult(a,[d.M.IntToString(S.V.OPEN_PANEL),e.OpenUI_get(),d.M.IntToString(n.id_get())],d.M.DoubleToString(e.value))
else if(e.type==ft.d.FRIEND)t.SetResult(a,[d.M.IntToString(S.V.OPEN_PANEL),e.OpenUI_get(),d.M.IntToString(n.id_get())],d.M.DoubleToString(e.value))
else if(e.type==ft.d.TEAM_TIME)t.SetResult(a,[d.M.IntToString(S.V.OPEN_PANEL),e.OpenUI_get(),d.M.IntToString(n.id_get())],d.M.DoubleToString(e.value))
else if(e.type==ft.d.COMPOSE_TIME)t.SetResult(a,[d.M.IntToString(S.V.OPEN_PANEL),e.OpenUI_get(),d.M.IntToString(n.id_get())],d.M.DoubleToString(e.value))
else if(e.type==ft.d.SKILL_LEVEL_UP_TIME)t.SetResult(a,[d.M.IntToString(S.V.OPEN_PANEL),e.OpenUI_get(),d.M.IntToString(n.id_get())],e.OpenUI_get())
else if(e.type==ft.d.PASSIVE_SKILL_LEVEL_UP_TIME)t.SetResult(a,[d.M.IntToString(S.V.OPEN_PANEL),e.OpenUI_get(),d.M.IntToString(n.id_get())],d.M.DoubleToString(e.value))
else if(e.type==ft.d.EQUIPMENT_UP_STEP_LV_TIME){if(r=new y.Z([d.M.IntToString(S.V.OPEN_PANEL),e.OpenUI_get(),d.M.IntToString(n.id_get())]),h=t.JointStr(r),
null!=e.param&&null!=e.param.equipType){w.R.GetName(e.param.equipType)
r=new y.Z([d.M.IntToString(S.V.OPEN_STRENG_PANEL),e.OpenUI_get(),`${ft.d.EQUIPMENT_UP_STEP_LV_TIME_VALUE}|${e.param.equipType}`]),h=t.JointStr(r)}
t.SetResult(a,h,d.M.DoubleToString(e.value))
}else if(e.type==ft.d.AUCTION_ONSHELF_TIME)t.SetResult(a,[d.M.IntToString(S.V.OPEN_PANEL),e.OpenUI_get(),d.M.IntToString(n.id_get())],d.M.DoubleToString(e.value))
else if(e.type==ft.d.MARKET_SELL_TIME)t.SetResult(a,[d.M.IntToString(S.V.OPEN_PANEL),e.OpenUI_get(),d.M.IntToString(n.id_get())],d.M.DoubleToString(e.value))
else if(e.type==ft.d.MARKET_BUY_TIME)t.SetResult(a,[d.M.IntToString(S.V.OPEN_PANEL),e.OpenUI_get(),d.M.IntToString(n.id_get())],d.M.DoubleToString(e.value))
else if(e.type==ft.d.IMMORTALS_DEBLOCK)t.SetResult(a,[d.M.IntToString(S.V.OPEN_PANEL),e.OpenUI_get(),d.M.IntToString(n.id_get())],d.M.DoubleToString(e.value))
else if(e.type==ft.d.IMMORTALS_LEVEL_UP);else if(e.type==ft.d.RUNE_NUM)t.SetResult(a,[d.M.IntToString(S.V.OPEN_PANEL),e.OpenUI_get(),d.M.IntToString(n.id_get())])
else if(e.type==ft.d.ENTER_MAP){const l=St.p.Inst_get().GetMapById(e.param.mapId)
r=new y.Z([d.M.IntToString(S.V.OPEN_PANEL),e.OpenUI_get(),d.M.IntToString(n.id_get())]),h=t.JointStr(r),s&&(u=`${d.M.DoubleToString(s[i].value_get())}/${e.value}`),
t.SetResult(a,h,ht.l.SetLinkStr(l.name,h,null,!1),u)}else if(e.type==ft.d.UIGAME)t.SetResult(a,[d.M.IntToString(S.V.OPEN_PANEL),e.OpenUI_get()],d.M.DoubleToString(e.value))
else if(e.type==ft.d.PHOTO_POSITION)r=new y.Z([d.M.IntToString(S.V.FIND_PATH),d.M.IntToString(ft.d.PHOTOGRAPH_POSITION_VALUE),d.M.IntToString(n.id_get()),"0",d.M.IntToString(e.param.mapId),d.M.FloatToString(e.param.x),d.M.FloatToString(e.param.y),e.OpenUI_get()]),
h=t.JointStr(r),n.linkStr=h,t.SetResult(a,h,d.M.IntToString(e.param.num))
else if(e.type==ft.d.PHOTO_NPC)p=e.param.npcPosStr_get(null),r=new y.Z([d.M.IntToString(S.V.FIND_PATH),d.M.IntToString(ft.d.PHOTO_NPC_VALUE),d.M.IntToString(n.id_get()),d.M.IntToString(e.param.npcId),p,e.OpenUI_get()]),
h=t.JointStr(r),n.linkStr=h,t.SetResult(a,h,d.M.IntToString(e.param.num))
else if(e.type==ft.d.PHOTO_PLAYER)r=new y.Z([d.M.IntToString(S.V.OPEN_PANEL),e.OpenUI_get(),d.M.IntToString(n.id_get())]),h=t.JointStr(r),n.linkStr=h,
t.SetResult(a,h,d.M.IntToString(e.param.num))
else if(e.type==ft.d.PHOTO_MONSTER)r=new y.Z([d.M.IntToString(S.V.FIND_PATH),d.M.IntToString(ft.d.PHOTO_MONSTER_VALUE),d.M.IntToString(n.id_get()),"0",e.param.flyPos_get(),e.OpenUI_get()]),
h=t.JointStr(r),t.SetResult(a,h,d.M.IntToString(e.param.num)),n.linkStr=h
else if(e.type==ft.d.DAILY_VITALITY||e.type==ft.d.DAILY_VITALITY_TOTAL)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.EXCELLENT_JEWELRY)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.SKILL_CULTIVATION)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.POWER)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.EQUIP_SECOND_WING_IGNORE)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.EQUIP_THIRD_WING_IGNORE)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.ENHANCE_EQUIP_TOTAL)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,ht.l.SetLinkStr(u,h,null,!1),d.M.IntToString(e.param.equipenhancelevel))
else if(e.type==ft.d.ADD_EQUIP_TOTAL)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,ht.l.SetLinkStr(u,h,null,!1),d.M.IntToString(e.param.addLevel))
else if(e.type==ft.d.SKILL_LEARN_OR){[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value)
let l=""
const r=d.M.Split(e.param.ids,o.o.s_UNDER_LINE)
let _=0
for(;_<r.count;){const t=A.j.Inst().GetSkillById(d.M.String2Int(r[_]))
_<r.count-1?l+=`${t.name},`:l+=t.name,_+=1}t.SetResult(a,h,ht.l.SetLinkStr(u,h,null,!1),l)}else if(e.type==ft.d.SKILL_LEVEL)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),
t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.SKILL_TRAIN_LEVEL)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.SUIT_EQUIP)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,ht.l.SetLinkStr(u,h,null,!1),d.M.IntToString(e.param.suitlevel))
else if(e.type==ft.d.ITEM_USE_TIME){[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value)
let l=""
const r=d.M.Split(e.param.itemModelId,d.M.s_CCD_CHAR_DOT)
let o=0
for(;o<r.count;){const t=I.g.Inst_get().getItemresource(d.M.String2Int(r[o]))
o<r.count-1?l+=`${t.name},`:l+=t.name,o+=1}t.SetResult(a,h,ht.l.SetLinkStr(l,h,null,!1),u)}else if(e.type==ft.d.PRAY)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),
t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.WORLD_CHAT)r=new y.Z([d.M.IntToString(S.V.OPEN_CHAT_PANEL)]),h=t.JointStr(r),null!=s&&(_=s[i].value_get()),u=`${d.M.DoubleToString(_)}/${e.value}`,
t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1)),n.linkStr=h
else if(e.type==ft.d.JOIN_ASURAM)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.MEMBER_DONATE_TIME||e.type==ft.d.ASURAM_EQUIP_DONATE||e.type==ft.d.ASURAM_EXCHANGE)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),
t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.MASTER_POINT)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.TEM_NUM_HISTORY){[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value)
let l=""
const r=d.M.Split(e.param.itemModelId,d.M.s_CCD_CHAR_DOT)
let o=0
for(;o<r.count;){const t=I.g.Inst_get().getItemresource(d.M.String2Int(r[o]))
o<r.count-1?l+=`${t.name},`:l+=t.name,o+=1}t.SetResult(a,h,ht.l.SetLinkStr(l,h,null,!1),u)}else if(e.type==ft.d.SKILL_LEVELUP){[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value)
const l=A.j.Inst().GetSkillById(d.M.String2Int(e.param.skillId))
t.SetResult(a,h,l.name,ht.l.SetLinkStr(u,h,null,!1))}else if(e.type==ft.d.WING_REFINE)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.ATTR_VALUE)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.EXTRA_SKILL_LEVEL||e.type==ft.d.UPGRADE_TALENT_LEVEL)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.EQUIP_SCORE)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.WING_ENCHANCE)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.AUCTION_TRADE)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.ARENA_DAN)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.MARKET_TRADE)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.ACHIEVEMENT_POINT)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.TRANSPORT)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.ITEM_NUM_HISTORY)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.LEVEL)ht.l.IsEmptyStr(e.param.fly)?[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value):(r=new y.Z([d.M.IntToString(S.V.FIND_PATH),d.M.IntToString(ft.d.LEVEL_VALUE),d.M.IntToString(n.id_get()),d.M.IntToString(0),e.param.flyPos_get()]),
h=t.JointStr(r)),null!=s&&(_=s[i].value_get()),u=`${Q.h.GetLevelStr2(d.M.String2Int(_))}/${Q.h.GetLevelStr2(d.M.String2Int(e.value))}`,
t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.COPY_ENCOURAGE_TIME)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.FUNCTION_OPEN)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.EXCHANGE_CONSIGN_SCORE_AND_LEARN_SKILL)t.JudgeLearnSkill(a,e,i,s,n)
else if(e.type==ft.d.EXCHANGE_CONSIGN_SCORE_AND_EQUIPMENT_EQUIP)t.JudgeExchangeAndEquip(a,e,i,s,n)
else if(e.type==ft.d.LEARN_SKILL||e.type==ft.d.POINT_LEARN_SKILL)for(;;){const o=d.M.Split(e.param.skillId,d.M.s_Arr_CCD_CHAR_DOT)
let I=0
for(;I<o.count;){const t=d.M.String2Int(o[I]),i=A.j.Inst().GetSkillById(t),s=Z.C.INSTANCE.GetLearnConsumes(i),l=d.M.String2Int(s.typevalues[0].valueType)
if($.Q.Inst_get().HasSkillItem(l)){r=new y.Z([d.M.IntToString(S.V.OPEN_SKILL_PANEL),d.M.IntToString(ft.d.LEARN_SKILL_VALUE),e.OpenUI_get()])
break}r=new y.Z([d.M.IntToString(S.V.OPEN_PANEL),e.OpenUI_get(),d.M.IntToString(n.id_get())]),I+=1}h=t.JointStr(r),null!=s&&(0==s.count?(lt.Y.LogError((0,
l.T)("任务数据异常:")+n.id_get()),_=0):_=s[i].value_get()),u=`${d.M.DoubleToString(_)}/${e.value}`,a[0]=h,a[1]=u,a[2]=ht.l.SetLinkStr(u,h,null,!1),n.linkStr=h
break}else if(e.type==ft.d.ADD_PACK_SIZE_NUM)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.REGISTRATION_TIME)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.ASSIST)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.EQUIPMENT_ENHANCE_TOTAL_LEVEL)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.PLAYER_DEATH)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.SEEK_TREASURE)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.EQUIPMENT_CAST_TIME){if(r=new y.Z([d.M.IntToString(S.V.OPEN_PANEL),e.OpenUI_get(),d.M.IntToString(n.id_get())]),h=t.JointStr(r),
null!=e.param&&null!=e.param.equipType){w.R.GetName(e.param.equipType)
r=new y.Z([d.M.IntToString(S.V.OPEN_STRENG_PANEL),e.OpenUI_get(),`${ft.d.EQUIPMENT_CAST_TIME_VALUE}|${e.param.equipType}`]),h=t.JointStr(r)}null!=s&&(_=s[i].value_get()),
u=`${d.M.DoubleToString(_)}/${e.value}`,t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1)),n.linkStr=h
}else if(e.type==ft.d.AUCTION_BID_SUCC)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.AUCTION_BID_FAIL)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.AUCTION_BUY_ITEMNUM)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.AUCTION_DIMOND)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.ACTIVITY_JOIN)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.ARENA_RANK)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,1),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.AREAN_WIN_PERCENT)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,1),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.VIP)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.INVEST)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.TOTAL_RECHARGE_MONEY)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.MEMORY_ACTIVE)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.NPC_SHOP_BUY){const o=gt.f.Inst().getItemById(e.param.npcId)
let I=""
null==o?lt.Y.LogError(`${(0,l.T)("1任务ID：")}${n.logId_get()}${(0,l.T)("找不到NPC:")}${e.param.npcId}`):I=o.name,p=e.param.npcPosStr_get(e.param.npcId!=o.npcid),
r=new y.Z([d.M.IntToString(S.V.FIND_PATH),d.M.IntToString(ft.d.NPC_SHOP_BUY_VALUE),d.M.IntToString(n.id_get()),d.M.IntToString(e.param.npcId),p]),h=t.JointStr(r),
null!=s&&(_=s[i].value_get()),u=`${d.M.DoubleToString(_)}/${e.value}`,a[0]=h,a[1]=ht.l.SetLinkStr(I,h,null,!1),a[2]=ht.l.SetLinkStr(u,h,null,!1),
t.SetResult(a,h,ht.l.SetLinkStr(I,h,null,!1),ht.l.SetLinkStr(u,h,null,!1)),t.m_subArr=new y.Z([I,d.M.DoubleToString(e.value)]),n.linkStr=h
}else if(e.type==ft.d.PASSIVE_SKILL_TOTAL_LEVEL)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,d.M.DoubleToString(e.value),ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.LEARN_TRANSFER_SKILL||e.type==ft.d.LEARN_TRANSFER_SKILL_ROLE_NUM)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),
t.SetResult(a,h,ht.l.getNumStr(e.param.transfer),ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.EQUIP_EXCELLENT||e.type==ft.d.EXCELLENCE_ADD_COUNT||e.type==ft.d.EQUIP_STAR_EXCELLENT)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),
t.SetResult(a,h,ht.l.SetLinkStr(u,h,null,!1),ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.SKILL_SLOT)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.ONE_QUEST){r=new y.Z([d.M.IntToString(S.V.OPEN_BAG_MUTIL_PANEL),e.OpenUI_get()]),h=t.JointStr(r),null!=s&&(_=s[i].value_get())
const l=new y.Z,I=d.M.Split(e.param.hideItemId,o.o.s_Arr_UNDER_CHAR_DOT)
let c=0
for(;c<I.count;){const t=d.M.String2Int(I[c])
l.Add(t),c+=1}u=`${d.M.DoubleToString(_)}/${e.value}`,a[0]=h,a[1]=u,a[2]=ht.l.SetLinkStr(u,h,null,!1),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1)),n.linkStr=h
}else if(e.type==ft.d.SET_AUTO_MELTING)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1),u)
else if(e.type==ft.d.ASURAM_ENTRUST)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1),u)
else if(e.type==ft.d.MULTI_QUEST){
const i=d.M.SubStringWithLen(e.param.ids,1,d.M.Length(e.param.ids)-2),s=d.M.Split(i,d.M.s_SPAN_CHAR_DOT),l=d.M.String2Int(s[0]),o=Mt.L.Inst_get().model.GetTaskById(l),_=o.tCTargetDefs_get().tCTargetDefs[0]
let I=0
const c=d.M.Split(e.OpenUI_get(),d.M.s_CCD_CHAR),g=d.M.String2Int(c[0])
Mt.L.Inst_get().model.IsTaskCompleted(l)?(I=_.value,r=new y.Z([d.M.IntToString(S.V.OPEN_PANEL),d.M.IntToString(g),d.M.IntToString(n.resource_get().id)])):(null!=o.qVo&&null!=o.qVo.targets&&(I=o.qVo.targets[0].value_get()),
r=new y.Z([d.M.IntToString(S.V.OPEN_PANEL),d.M.IntToString(g),d.M.IntToString(n.id_get()),Wt.r.TYPE_BRANCH])),h=t.JointStr(r),u=`${I}/${_.value}`,a[0]=h,
a[1]=d.M.DoubleToString(_.value-I),a[2]=u,n.linkStr=h}else if(e.type==ft.d.EXCHANGE_CONSIGN_SCORE)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),
t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1),u)
else if(e.type==ft.d.HISTORY_DIG_MINE_COUNT||e.type==ft.d.ROB_MINE_COUNT)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.TRANSFER_ACTIVE_STARCLOUD)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.JIGSAW)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.TRANSFER_EXP_BLESSING)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.KUNDUN_SEAL)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.OCEAN_HEART)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.ELEMENT_BOSS)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.JEW_NUM)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.SELECT_TRANSFER_DIRECTION){let l=null
null!=n&&null!=n.qVo&&null!=n.qVo.playerId&&(l=n.qVo.playerId.ToString())
const r=new y.Z([d.M.IntToString(S.V.OPEN_PANEL),e.OpenUI_get(),l])
h=t.JointStr(r),null!=s&&(_=s[i].value_get()),u=`${d.M.DoubleToString(_)}/${e.value}`,n.linkStr=h,t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
}else if(e.type==ft.d.HONOR_MANUAL_LEVEL)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.ALL_ROLE_LEARN_SKILL_NUM)[h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))
else if(e.type==ft.d.CLOSE_UI);else if(e.type==ft.d.LYING_WALL)p=e.param.flyPos_get(),
r=new y.Z([d.M.IntToString(S.V.FIND_PATH),d.M.IntToString(ft.d.LYING_WALL_VALUE),d.M.IntToString(n.id_get()),d.M.IntToString(e.param.wallId),p]),h=t.JointStr(r),n.linkStr=h,
t.SetResult(a,h,ht.l.SetLinkStr("靠墙",h,null,!1))
else if(e.type==ft.d.SIT_DOWN)p=e.param.flyPos_get(),r=new y.Z([d.M.IntToString(S.V.FIND_PATH),d.M.IntToString(ft.d.SIT_DOWN_VALUE),d.M.IntToString(n.id_get()),d.M.IntToString(e.param.wallId),p]),
h=t.JointStr(r),n.linkStr=h,t.SetResult(a,h,ht.l.SetLinkStr("坐下",h,null,!1))
else if(e.type==ft.d.PASS_COPY_ROBOT)p=e.param.flyPos_get(),r=new y.Z([d.M.IntToString(S.V.FIND_PATH),d.M.IntToString(ft.d.PASS_COPY_ROBOT_VALUE),d.M.IntToString(n.id_get()),d.M.IntToString(0),p]),
h=t.JointStr(r),n.linkStr=h,t.SetResult(a,h,ht.l.SetLinkStr("",h,null,!1))
else if(e.type==ft.d.ROBOT_THROW_ITEM)p=e.param.flyPos_get(),r=new y.Z([d.M.IntToString(S.V.FIND_PATH),d.M.IntToString(ft.d.ROBOT_THROW_ITEM_NUM),d.M.IntToString(n.id_get()),d.M.IntToString(e.param.mapId),p]),
h=t.JointStr(r),n.linkStr=h,t.SetResult(a,h,ht.l.SetLinkStr("",h,null,!1))
else if(e.type==ft.d.HANG_IN_MAX){let l=-1
if("-1"!=e.param.mapList){const t=d.M.Split(e.param.mapList,";")
l=d.M.String2Int(t[0])
for(let e=1;e<=t.Count()-1;e++){const i=St.p.Inst_get().GetMapById(d.M.String2Int(t[e]))
mt.F.getInst().GetCanEnterMapByLvAndTransfer(i.id)==$t.f.CAN&&i.minLevelLimit>St.p.Inst_get().GetMapById(l).minLevelLimit&&(l=d.M.String2Int(t[e]))}}
r=new y.Z([d.M.IntToString(S.V.TRANSMIT_PATH_MAX),d.M.IntToString(l)]),h=t.JointStr(r),n.linkStr=h,u=null!=s?`${s[i].value_get()}/${e.value}`:`${e.value}/${e.value}`,
t.SetResult(a,h,ht.l.SetLinkStr("",h,null,!1),u,u)}else if(e.type==ft.d.HANG_IN_FLY){let l=-1
if("-1"!=e.param.mapList){const t=d.M.Split(e.param.mapList,";")
l=d.M.String2Int(t[0])
for(let e=1;e<=t.Count()-1;e++){const i=St.p.Inst_get().GetMapById(d.M.String2Int(t[e]))
mt.F.getInst().GetCanEnterMapByLvAndTransfer(i.id)==$t.f.CAN&&i.minLevelLimit>St.p.Inst_get().GetMapById(l).minLevelLimit&&(l=d.M.String2Int(t[e]))}}
r=st.b.Inst.currentMapId_get()==l&&0!=e.param.guideBtn?new y.Z(["",""]):new y.Z([d.M.IntToString(S.V.TRANSMIT_PATH_MAX),d.M.IntToString(l)]),h=t.JointStr(r),n.linkStr=h,
u=null!=s?`${s[i].value_get()}/${e.value}`:`${e.value}/${e.value}`,t.SetResult(a,h,ht.l.SetLinkStr("",h,null,!1),u,u)
}else e.type==ft.d.LEVEL_CHANGE||e.type==ft.d.EQUIPMENT_NUM||e.type==ft.d.ITEM_NUM||e.type==ft.d.ITEM_GROUP_NUM||e.type==ft.d.REBIRTH||e.type==ft.d.CREATE_ROLE||e.type==ft.d.ENHANCE_SUC_ONE_TIMES||e.type==ft.d.TODAY_DROP_SUIT_EQUIP||e.type==ft.d.MALL_BUY||e.type==ft.d.FINISH_HONOR_MANUAL_TASK_NUM||e.type==ft.d.MULTI_HANG_TIME||e.type==ft.d.DAILY_HONOR||e.type==ft.d.RIDING_NUM||e.type==ft.d.STALL_GOLD_NUM||e.type==ft.d.TALENT_LEARN_NUM||e.type==ft.d.EQUIP_TOTAL_ADDLEVEL||e.type==ft.d.OUTLINE_TIME||e.type==ft.d.STALL_BUY_NUM||e.type==ft.d.STALL_UP_NUM||e.type==ft.d.APPOINT_ROLE_LEARN_SKILL_NUM||e.type==ft.d.EQUIPMENT_ENHANCE_CERTAIN_LEVEL||e.type==ft.d.ASSIST||e.type==ft.d.ASURAM_PARTY||e.type==ft.d.UNLOCK_CHECKPOINT||e.type==ft.d.KILL_ASURAM_BOSS||e.type==ft.d.ACCEPT_ASURAM_INTERACTION||e.type==ft.d.QUICK_BATTLE||e.type==ft.d.ARENA_CHALLENGE||e.type==ft.d.PASS_MAP||e.type==ft.d.ALL_ROLE_STAR_NUM||e.type==ft.d.BOUNTY_QUEST_NUM||e.type==ft.d.MEDAL_LEVEL_CHANG||e.type==ft.d.GOUI?([h,u]=t.JudgeOpenPanelHandle(e,i,s,n,e.value),
t.SetResult(a,h,u,ht.l.SetLinkStr(u,h,null,!1))):lt.Y.LogError((0,l.T)("添加了没有的任务类型：")+(e.type+((0,l.T)("，任务ID：")+n.logId_get())))
return a}static JudgeHandInItem(e,i,s,n,l){i.param.npcId=l.RewardNpcId_get()
let a=null
if(null==l.qVo)a=new y.Z([d.M.IntToString(S.V.HAND_IN),d.M.IntToString(s)])
else{const t=i.value-n[s].value_get()
if(t>0&&t>I.g.Inst_get().GetItemNum(d.M.String2Int(i.param.itemModelId))&&(i.param.gatherId>0||i.param.groupId>0)){let t=null
i.param.gatherId>0?t=ot.J.Inst().getItemById(i.param.gatherId):(t=ot.J.Inst().GetItemByGroupId(i.param.groupId),i.param.gatherId=t.id),
a=new y.Z([d.M.IntToString(S.V.FIND_PATH),d.M.IntToString(ft.d.GATHER_VALUE),d.M.IntToString(l.id_get()),d.M.IntToString(i.param.gatherId),i.param.gatherPos_get()])
}else a=new y.Z([d.M.IntToString(S.V.HAND_IN),d.M.IntToString(s)])}const r=t.JointStr(a)
let o=0
null!=n&&(o=n[s].value_get())
const h=V.f.Inst().getItemById(d.M.String2Int(i.param.itemModelId)),_=ht.l.SetLinkStr(h.name,r,null,!1),u=`${t.GetCountColorStr(d.M.DoubleToString(o))}/${i.value}`
e[0]=r,e[1]=_,e[2]=u}static JudgeHandInItemGroup(e,i,s,n,a){i.param.npcId=a.RewardNpcId_get()
const r=new y.Z([d.M.IntToString(S.V.HAND_IN),d.M.IntToString(s)]),o=t.JointStr(r),h=V.f.Inst().GetItemGroupName(i.param.itemGroupId)
d.M.IsNullOrEmpty(h)&&lt.Y.LogError((0,l.T)("itemresource表中没有配置当前组的名字：")+d.M.IntToString(i.param.itemGroupId))
const _=ht.l.SetLinkStr(h,o,null,!1)
let u=0
null!=n&&(u=n[s].value_get())
const I=`${t.GetCountColorStr(d.M.DoubleToString(u))}/${i.value}`
e[0]=o,e[1]=_,e[2]=I}static JudgeHandInEquipment(e,i,s,n,l){i.param.npcId=l.RewardNpcId_get()
const a=new y.Z([d.M.IntToString(S.V.HAND_IN),d.M.IntToString(s)]),r=t.JointStr(a)
let o=0
null!=n&&(o=n[s].value_get())
const h=w.R.GetName(i.param.equipmentType)
let _=d.M.Replace("{0}","{0}",ht.l.getEquiplvStr(i.param.stepLv))
_+=d.M.Replace("{0}","{0}",h),_=ht.l.SetLinkStr(_,r,null,!1)
const u=`${t.GetCountColorStr(d.M.DoubleToString(o))}/${i.value}`
e[0]=r,e[1]=_,e[2]=u}static GetCountColorStr(t){return ht.l.SetStringColor(ht.l.txtRedStr,t)}static JudgePassCopy(e,i,s,n,l){const a=l.GetCopyRes()
let r=null
if(d.M.IsNullOrEmpty(i.OpenUI_get()))if(0==a.NpcId)r=a.controllerType==F.S.RyAllianceTask||a.controllerType==F.S.Plot?new y.Z([d.M.IntToString(S.V.ENTER_COPY_JUST),d.M.IntToString(a.id),d.M.IntToString(l.id_get()),d.M.IntToString(a.controllerType)]):new y.Z([d.M.IntToString(S.V.OPEN_COPY_PANEL),d.M.IntToString(a.controllerType)])
else{i.param.npcId=a.NpcId
const t=gt.f.Inst().getItemById(a.NpcId)
r=new y.Z([d.M.IntToString(S.V.FIND_PATH),d.M.IntToString(ft.d.PASS_COPY_VALUE),d.M.IntToString(l.id_get()),d.M.IntToString(t.npcid),d.M.IntToString(t.mapid),d.M.FloatToString(t.x),d.M.FloatToString(t.y)])
}else r=new y.Z([d.M.IntToString(S.V.OPEN_PANEL),i.OpenUI_get(),d.M.IntToString(l.id_get())])
const o=t.JointStr(r)
let h=0
null!=n&&(h=n[s].value_get())
let _=""
null!=a&&(_=a.name)
const u=ht.l.SetLinkStr(_,o,null,!1),I=`${d.M.DoubleToString(h)}/${i.value}`
e[0]=o,e[1]=u,e[2]=I}static JudgeKillMonster(e,i,s,n,l){let a=null,r="",h=0,_=""
ht.l.txtGreenStr
let u=null,c=null,g=null,p=""
if(i.type==ft.d.KILL_MONSTER||i.type==ft.d.MONSTER_DROP_EQUIP)if(null!=i.OpenUI_get()&&""!=i.OpenUI_get())a=new y.Z([d.M.IntToString(S.V.OPEN_PANEL),d.M.IntToString(Number(i.OpenUI_get())),d.M.IntToString(l.id_get())]),
r=t.JointStr(a),null!=n&&(h=n[s].value_get())
else if(i.param.mapId>0){const e=St.p.Inst_get().GetMapById(i.param.mapId)
a=new y.Z([d.M.IntToString(S.V.FIND_PATH),d.M.IntToString(ft.d.MONSTER_HUNT_MAP_VALUE),d.M.IntToString(l.id_get()),d.M.IntToString(i.param.mapId),d.M.IntToString(i.param.mapId)]),
r=t.JointStr(a),p=e.name,null!=n&&(h=n[s].value_get())}else if(ht.l.IsEmptyStr(i.param.fly)){if(!d.M.IsNullOrEmpty(i.OpenUI_get())){
if(a=new y.Z([d.M.IntToString(S.V.OPEN_PANEL),i.OpenUI_get(),d.M.IntToString(l.id_get())]),r=t.JointStr(a),i.param.monsterId>0){p=W.a.getInst().getObjById(i.param.monsterId).name
}else if(i.param.monsterGroupId>0){p=_t.$.Inst_get().GetItemCfg(i.param.monsterGroupId).name}null!=n&&(h=n[s].value_get())}if(i.param.suggestHang>0){
const e=mt.F.getInst().GetRecommendTransVo()
if(null!=e){const i=W.a.getInst().getObjById(e.objectId)
a=new y.Z([d.M.IntToString(S.V.FIND_PATH),d.M.IntToString(ft.d.KILL_MONSTER_VALUE),d.M.IntToString(l.id_get()),d.M.IntToString(e.objectId),e.id]),r=t.JointStr(a),p=i.name,
null!=n&&(h=n[s].value_get())}}}else if(i.param.monsterId>0){const e=W.a.getInst().getObjById(i.param.monsterId)
a=new y.Z([d.M.IntToString(S.V.FIND_PATH),d.M.IntToString(ft.d.KILL_MONSTER_VALUE),d.M.IntToString(l.id_get()),d.M.IntToString(i.param.monsterId),i.param.flyPos_get()]),
r=t.JointStr(a),p=e.name,null!=n&&(h=n[s].value_get())}else if(i.param.monsterGroupId>0){const e=_t.$.Inst_get().GetItemCfg(i.param.monsterGroupId)
a=new y.Z([d.M.IntToString(S.V.FIND_PATH),d.M.IntToString(ft.d.KILL_MONSTER_VALUE),d.M.IntToString(l.id_get()),d.M.IntToString(i.param.monsterId),i.param.flyPos_get()]),
r=t.JointStr(a),p=e.name,null!=n&&(h=n[s].value_get())
}else i.param.uesFlyId_get()>0&&(a=new y.Z([d.M.IntToString(S.V.FIND_PATH),d.M.IntToString(ft.d.KILL_MONSTER_VALUE),d.M.IntToString(l.id_get()),"",i.param.flyPos_get()]),
r=t.JointStr(a),p="",null!=n&&(h=n[s].value_get()))
else if(i.type==ft.d.GATHER||i.type==ft.d.GATHER_ITEM){let e=null
if(i.param.groupId>0){const t=ot.J.Inst().GetItemListByGroupId(i.param.groupId),s=j.Y.Inst.GetNearestCollectByDis(50,t,null,null)
null==s?(e=ot.J.Inst().GetItemByGroupId(i.param.groupId),i.param.gatherId=e.id):(e=s.Cfg_get(),i.param.gatherId=e.id)}else e=ot.J.Inst().getItemById(i.param.gatherId)
0!=i.param.npcId?(g=i.param.npcPosStr_get(null),a=new y.Z([d.M.IntToString(S.V.FIND_PATH),d.M.IntToString(ft.d.TALK_VALUE),d.M.IntToString(l.id_get()),d.M.IntToString(i.param.npcId),g])):a=new y.Z([d.M.IntToString(S.V.FIND_PATH),d.M.IntToString(ft.d.GATHER_VALUE),d.M.IntToString(l.id_get()),d.M.IntToString(e.id),i.param.gatherPos_get()]),
r=t.JointStr(a)
let s=""
if(l.type_get()==Ct.U.CHANGE_JOB){const t=l.completeConsumsInfo_get().rewardValues[0],e=d.M.Split(t.value,o.o.s_Arr_UNDER_COLON),i=d.M.String2Int(e[0])
s=I.g.Inst_get().getItemresource(i).name}else null!=e&&(s=e.name)
p=s}else if(i.type==ft.d.KILL_MONSTER_ITEM||i.type==ft.d.KILL_MONSTER_RATE||i.type==ft.d.FICTITIOUS_ITEM){
if(null!=i.OpenUI_get()&&""!=i.OpenUI_get())a=new y.Z([d.M.IntToString(S.V.OPEN_PANEL),d.M.IntToString(Number(i.OpenUI_get())),d.M.IntToString(l.id_get())]),r=t.JointStr(a),
null!=n&&(h=n[s].value_get())
else if(0!=i.param.npcId)g=i.param.npcPosStr_get(null),a=new y.Z([d.M.IntToString(S.V.FIND_PATH),d.M.IntToString(ft.d.TALK_VALUE),d.M.IntToString(l.id_get()),d.M.IntToString(i.param.npcId),g]),
r=t.JointStr(a)
else{let e=ft.d.KILL_MONSTER_ITEM_VALUE
i.type==ft.d.KILL_MONSTER_RATE?e=ft.d.KILL_MONSTER_RATE_VALUE:i.type==ft.d.FICTITIOUS_ITEM&&(e=ft.d.FICTITIOUS_ITEM_VALUE),
a=new y.Z([d.M.IntToString(S.V.FIND_PATH),d.M.IntToString(e),d.M.IntToString(l.id_get()),d.M.IntToString(i.param.monsterId),i.param.flyPos_get()]),r=t.JointStr(a)}
p=I.g.Inst_get().getItemresource(d.M.String2Int(i.param.itemModelId)).name}null!=n&&(h=n[s].value_get()),
null==a&&(d.M.IsNullOrEmpty(i.OpenUI_get())||(a=new y.Z([d.M.IntToString(S.V.OPEN_PANEL),i.OpenUI_get(),d.M.IntToString(l.id_get())]),r=t.JointStr(a))),
u=dt.w.Instance.ConvertNumToUnitize(h),c=dt.w.Instance.ConvertNumToUnitize(i.value),l.linkStr=r,_=`${u}/${c}`,t.SetResult(e,r,ht.l.SetLinkStr(p,r,null,!1),_,_)}
static JudgeLearnSkill(e,i,s,n,a){let r=null,_="",u=""
for(Mt.L.Inst_get().model.isShowLenChanged=!0;;){u=`${d.M.DoubleToString(j.Y.Inst.PrimaryRoleInfo_get().Sonsign_Score_get())}/${i.param.CONSIGN_SCORE}`
const s=d.M.Split(i.param.langId,o.o.s_Arr_UNDER_CHAR_DOT)
let n=!0
const c=d.M.Split(i.param.skillId,d.M.s_Arr_CCD_CHAR_DOT)
let g=0
for(;g<c.count;){const t=d.M.String2Int(c[g]),i=Z.C.INSTANCE.GetSkillItemConsume(A.j.Inst().GetSkillById(t))
if(I.g.Inst_get().GetItemNum(i.modelId_get())>0){const a=A.j.Inst().GetSkillById(t),o=Z.C.INSTANCE.GetSkillAttrCondition(a)
let _="",u=!0,I=0
const c=j.Y.Inst.PrimaryRoleInfo_get(),g=c.RemainBasePoint_get()
let p=g
if(null!=o){let t=0
const e=o.list.Count()
for(;t<e;){const i=o.list[t],s=i.value,n=i.keyID,a=h.GF.INT(j.Y.Inst.PrimaryRoleInfo_get().Attributes_get()[n])
if(a+p<s){const t=s-a
I+=t,_+=`${i.attrName}${(0,l.T)("要求")}${ht.l.SetStringColor(ht.l.txtRedStr,s)}(${ht.l.SetStringColor(ht.l.txtRedStr,(0,l.T)("还需")+t)})`,u=!1}else a<s&&(p-=s-a),
_+=`${i.attrName}${(0,l.T)("要求")}${ht.l.SetStringColor(ht.l.txtGreenStr,s)}(${ht.l.SetStringColor(ht.l.txtGreenStr,(0,l.T)("已满足"))})`
t<e-1&&(_+="\n"),t+=1}}if(r=new y.Z([d.M.IntToString(S.V.OPEN_SKILLANDTIPS_PANEL),d.M.IntToString(i.modelId_get())]),u)e[4]=f.V.Inst().getStr2(d.M.String2Int(s[0]))
else{if(I>0&&g<I){const t=kt.l.GetInst().GetPlayerInitial(c.Job_get()),e=Ht.p.CeilToInt((I-g)/t.levelOfPoint)
_+=(0,l.T)("\n再升")+(ht.l.SetStringColor(ht.l.txtGreenStr,e+(0,l.T)("级"))+(0,l.T)("可获得足够属性点"))}e[4]=_}n=!1
break}Vt.M.Recycle(i),g+=1}
n&&j.Y.Inst.PrimaryRoleInfo_get().Sonsign_Score_get()>=i.param.CONSIGN_SCORE&&(r=new y.Z([d.M.IntToString(S.V.OPEN_PANEL),i.OpenUI_get(),d.M.IntToString(a.id_get())]),
e[4]=f.V.Inst().getStr2(d.M.String2Int(s[1])),n=!1),n&&(r=new y.Z([d.M.IntToString(S.V.OPEN_PANEL),i.OpenUI_get(),d.M.IntToString(a.id_get())])),_=t.JointStr(r),e[0]=_,e[1]=u,
e[2]=ht.l.SetLinkStr(u,_,null,!1),a.linkStr=_
break}}static JudgeExchangeAndEquip(e,i,s,n,l){let a=null,r="",h=""
for(;;){h=`${d.M.DoubleToString(j.Y.Inst.PrimaryRoleInfo_get().Sonsign_Score_get())}/${i.param.CONSIGN_SCORE}`
let s=null
const n=I.g.Inst_get().GetBagDataList()
if(d.M.IsNullOrEmpty(i.param.itemModelId)){let t=0
for(;t<n.Count();){if(null!=n[t].baseData_get()&&n[t].baseData_get().BagItemType_get()==bt.r.Equip&&n[t].baseData_get().cfgEquipData_get().equipType==w.R.GUARD){s=n[t]
break}t+=1}}else{const t=d.M.Split(i.param.itemModelId,o.o.s_UNDER_CHAR)
if(t.count>0)for(let e=0;e<=t.count-1;e++){const i=d.M.String2Int(t[e])
if(I.g.Inst_get().GetItemNum(i)>0){let t=0
for(;t<n.Count();){if(null!=n[t].baseData_get()&&n[t].baseData_get().modelId_get()==i){s=n[t]
break}t+=1}}if(null!=s)break}}null!=s?($.Q.Inst_get().targetItemId=s.serverData_get().id,a=new y.Z([d.M.IntToString(S.V.OPEN_BAG_PANEL)]),
e[4]=f.V.Inst().getStr2(10726)):j.Y.Inst.PrimaryRoleInfo_get().Sonsign_Score_get()>=i.param.CONSIGN_SCORE?(a=new y.Z([d.M.IntToString(S.V.OPEN_PANEL),i.OpenUI_get(),d.M.IntToString(l.id_get())]),
e[4]=f.V.Inst().getStr2(10727)):a=new y.Z([d.M.IntToString(S.V.OPEN_PANEL),i.OpenUI_get(),d.M.IntToString(l.id_get())]),r=t.JointStr(a),e[0]=r,e[1]=h,
e[2]=ht.l.SetLinkStr(h,r,null,!1),l.linkStr=r
break}}static GotoByTask(e,i,s){if(null==s&&(s=!1),null==i&&(i=e.status_get()==Tt.B.FINISHED?1==e.resource_get().automateNPC:1==R.U.AUTO_TO_FINISH_NPC_NO),
it.S.getInst().InHang_get()&&e.isKillTask_get()&&e.isHanging&&null!=t.m_nowTask&&t.m_nowTask.id_get()==e.id_get())return
t.m_nowTask=e,Mt.L.Inst_get().model.nowConfig_set(e)
const n=e.GetLinkCidx(),l=e.GetIntersectionType()
if(e.status_get()==Tt.B.FINISHED&&l==R.U.INTERSECTION_VIEW&&e.type_get()==Ct.U.CHANGE_JOB)return void at.N.inst.OpenUIByShortCutID(d.M.String2Int(e.resource_get().intersectionValue),e.qVo.playerId)
const a=e.GetLinkTarget()
et.e.inst_get().SetNowTaskWeightTarget(t.m_nowTask),t.GotoByLinkStr(e.linkStr,i,s,!0,null,n,a)}IsEndHang(t){return!0}static GotoByLinkStr(e,i,s,n,a,o,T){null==a&&(a=0),
null==n&&(n=!1),null==s&&(s=!1),null==i&&(i=1==R.U.AUTO_TO_FINISH_NPC_NO),m.k.inst.clearAuotoPk()
const C=t.JoinValue(e),E=h.GF.INT(C[0])
if(n||p.p.inst.IsInCopy()||E==S.V.FIND_PATH&&r._.getInst().endHang(),E==S.V.FIND_PATH)t.TryFindPath(e,i?1:0,s,n,a)
else if(E==S.V.ENTER_COPY_JUST){const t=h.GF.INT(C[1]),e=h.GF.INT(C[2]),i=h.GF.INT(C[3])
if(i==F.S.RyAllianceTask){const i=new g.B
i.infoId="COPY:ASURAM_QUEST_COPY",i.confirmHandle=t=>{_.V.Inst_Get().TaskID=t[1],p.p.inst.SendEnterCopy(t[0],null,null)},i.confirmParam=new y.Z([t,e]),i.isShowMask=!0,
c.t.Inst().Open(i)}else i==F.S.Plot&&p.p.inst.SendEnterCopy(t,null,null)}else if(E==S.V.OPEN_PANEL){const i=t.JoinValueStr(e)
C.count>=2?""!=i[1]&&"-1"!=i[1]&&"0"!=i[1]&&at.N.inst.OpenUIByShortCutIDStr(i[1],i[2],o,T):"-1"!=i[1]&&lt.Y.LogError(`link解析没有配goUI 确认下是不是不需要点击 直接找策划！直接找策划！直接找策划! ${e}`)
}else if(E==S.V.OPEN_STRENG_PANEL){const i=t.JoinValueStr(e)
at.N.inst.OpenUIByShortCutID(d.M.String2Int(i[1]),i[2])}else if(E==S.V.OPEN_COPY_PANEL)p.p.inst.OpenCopyPanel(h.GF.INT(C[1]),!0)
else if(E==S.V.HAND_IN)t.DoHandIn(e,i,s,n,a)
else if(E==S.V.OPEN_BAG_PANEL)I.g.Inst_get().viewBagType=M.D.equipTab,I.g.Inst_get().isneedreset=!1,u.J.Inst_get().openOrClose(M.D.bagTab)
else if(E==S.V.OPEN_BAG_MUTIL_PANEL)I.g.Inst_get().viewBagType=M.D.equipTab,I.g.Inst_get().isneedreset=!1,u.J.Inst_get().openOrClose(M.D.bagTab)
else if(E==S.V.OPEN_SKILL_PANEL)at.N.inst.OpenUIByShortCutID(h.GF.INT(C[2]))
else if(E==S.V.OPEN_SKILLANDTIPS_PANEL){const t=new N.Y,e=new b.t
if(e.modelId=h.GF.INT(C[1]),t.serverData_set(e),null!=t.serverData_get()){let e=t.baseData_get().cfgData_get().GetRewardsSkillId()
if(0!=e){let i=A.j.Inst().GetSkillById(e,!1)
if(1004==e||2004==e||3004==e){const t=e+1
null!=Z.C.INSTANCE.GetSkillByStudyDic(t)&&(e=t,i=A.j.Inst().GetSkillById(e,!1))}null!=i?(Z.C.INSTANCE.pre_select_skillid=i.skillid,
Z.C.INSTANCE.curShowChildView=h.GF.INT(G.c.ProSkill)):D.c.DebugError((0,l.T)("道具ID :")+(t.serverData_get().modelId+(0,l.T)("快捷打开技能界面在技能表找不到配置")))}}
at.N.inst.OpenUIByShortCutID(L.D.ProSkill,t)}else if(E==S.V.OPEN_ACCESS_PANEL){const t=h.GF.INT(C[2])
u.J.Inst_get().OpenTipViewById(t)}else if(E==S.V.OPEN_CHAT_PANEL)P.d.Inst_get().controller.m_channel=v.L.WORLD,P.d.Inst_get().controller.openTxt=f.V.Inst().getStr2(10560),
P.d.Inst_get().controller.OpenMainPanel(null,null,null)
else if(E==S.V.SUGGEST_HANG)J._.Inst_get().OnGoGuaji(null,null,null)
else if(E==S.V.DERICT_BUY)K.N.GetInst().HandleBuyMallInfo(d.M.String2Int(C[1]),1)
else if(E==S.V.TRANSMIT_PATH)t.TryTransmitPath(e,n,!1,a)
else if(E==S.V.TRANSMIT_PATH_MAX){let t=h.GF.INT(C[1])
if(-1==t){t=It.u.Inst().nowFightVo.res.mapId}const e=It.u.Inst().GetHighestGateByMap(t)
null!=e?z.B.Inst.CM_FlyShoesTransportHandle(It.u.Inst().GetTransVoById(e.id).id,null,null,!0):pt.X.inst.JudgeCanEnterMapHandler(t,!0)}else if(E==S.V.TRIGGER_GUIDE_BTN){
const t=h.GF.INT(C[1])
ht.l.CheckTrigger(H.u.COND_CLICK_BTN_VAL,t)}}static TryTransmitPath(e,i,s,n){const l=t.JoinValue(e)
let a=0
const r=h.GF.INT(l[4])
let o=0,d=new rt.P
let _=null,u=n
i&&(u=t.m_nowTask.GetReduceDistance())
const I=j.Y.Inst.PrimaryRole_get()
if(p.p.inst.IsInCopy()||(m.k.inst.openfanji=!1),I.RemoveSkillAI(),i&&(a=t.m_nowTask.flyId_get(),o=t.m_nowTask.id_get()),d=new rt.P(l[5],0,l[6]).Clone(),
st.b.Inst.currentMapId_get()==r){if(!j.Y.Inst.primaryRole.CanFindWayToEnd(d,r))return void t.SendFlyShose(i,r,d,null,u,null)
const s=I.GetPos()
if(s.y=0,rt.P.Distance(s,d)<2)return t.DealLinkTarget(e),void I.JustStand()}I.ClearMoveParam(),_=new yt(r,l[5],l[6],i,h.GF.INT(l[2]),u,a),_.npcId=h.GF.INT(l[3]),
_.callback=t.FindTargetCallBack,_.o1=null,t.ShowFlyTip(_,s,!0)}static TryFindPath(e,i,s,n,l){t.DoFindPath(e,i,s,n,Number(l.toExponential),null)}static DoFindPath(e,i,s,n,l,a){
null==a&&(a=!1)
const o=t.JoinValue(e)
let _=0
const u=h.GF.INT(o[4])
let I=0
const c=j.Y.Inst.PrimaryRole_get()
p.p.inst.IsInCopy()||(m.k.inst.openfanji=!1),c.RemoveSkillAI(),n&&(_=t.m_nowTask.flyId_get(),I=t.m_nowTask.id_get())
let g=new rt.P,S=null,T=null
if(null==c)return
S=new y.Z([e])
let f=l
n&&(f=t.m_nowTask.GetReduceDistance())
const C=h.GF.INT(o[1])
if(C==ft.d.TALK_VALUE||C==ft.d.KILL_MONSTER_VALUE||C==ft.d.GATHER_VALUE||C==ft.d.KILL_MONSTER_ITEM_VALUE||C==ft.d.KILL_MONSTER_RATE_VALUE||C==ft.d.FICTITIOUS_ITEM_VALUE||C==ft.d.PASS_COPY_VALUE||C==ft.d.ENTER_COPY_VALUE||C==ft.d.PHOTO_MONSTER_VALUE||C==ft.d.PHOTO_NPC_VALUE||C==ft.d.PHOTOGRAPH_POSITION_VALUE||C==ft.d.HAND_IN_NPC_TALK_VALUE||C==ft.d.NPC_SHOP_BUY_VALUE||C==ft.d.EQUIPMENT_EQUIP_VALUE||C==ft.d.MIRACLECONTINENT_TALK_VALUE||C==ft.d.LYING_WALL_VALUE||C==Number(ft.d.ROBOT_THROW_ITEM)||C==ft.d.PASS_COPY_ROBOT_VALUE||C==ft.d.LEVEL_VALUE||C==ft.d.SIT_DOWN_VALUE){
if(o.count<7)return
if(g=new rt.P(o[5],0,o[6]).Clone(),st.b.Inst.currentMapId_get()==u&&!a){if(!j.Y.Inst.primaryRole.CanFindWayToEnd(g,u))return void t.SendFlyShose(n,u,g,S,f,null)
const i=c.GetPos()
if(i.y=0,C==ft.d.GATHER_VALUE&&rt.P.Distance(i,g)<100){let i=null
const s=ot.J.Inst().getItemById(d.M.String2Int(o[3])),n=ot.J.Inst().GetItemListByGroupId(s.groupId)
if(i=j.Y.Inst.GetNearestCollectByDis(50,n,null,null),null!=i)return void t.DealLinkTarget(e)}if(rt.P.Distance(i,g)<2)return t.DealLinkTarget(e),void c.JustStand()}
if(c.ClearMoveParam(),r._.getInst().endHang(),t.isInTaskFindWay=!0,i==R.U.AUTO_TO_FINISH_NPC_GO)T=new yt(u,o[5],o[6],n,h.GF.INT(o[2]),f,_),T.npcId=h.GF.INT(o[3]),
T.callback=t.FindTargetCallBack,T.o1=S,t.ShowFlyTip(T,s,null)
else if(i==R.U.AUTO_TO_FINISH_NPC_FLY)T=new yt(u,o[5],o[6],n,h.GF.INT(o[2]),f,_),T.npcId=h.GF.INT(o[3]),T.callback=t.FindTargetCallBack,T.o1=S,t.ShowFlyTip(T,s,!0)
else if(st.b.Inst.currentMapId_get()!=u||a)t.SendFlyShose(n,u,g,S,f,_)
else if(null!=f){let e
if(0!=_&&(e=ut.e.Inst_get().GetCfgById(_)),null==e&&(e=ut.e.Inst_get().GetCfgByFixShoesBeeline(u,g.x,g.z)),null!=e){const t=It.u.Inst().GetMapPassVoBySpawnId(e.spawnId)
if(null!=t&&t.state==ct.s.LOCK)return void pt.X.inst.ShowPassMapTip(t)}c.gotoPoint(g,tt.m.TASK,t.FindTargetCallBack,S,u,f)}t.isInTaskFindWay&&r._.getInst().openOrCloseStartIcon()
}else C==ft.d.ENTER_MAP_VALUE||C==ft.d.MAP_TRANSPORTLINE_VALUE||C==ft.d.MONSTER_HUNT_MAP_VALUE?i==R.U.AUTO_TO_FINISH_NPC_FLY?(T=new yt(u,o[5],o[6],n,h.GF.INT(o[2]),_,null),
T.npcId=h.GF.INT(o[3]),T.callback=t.FindTargetCallBack,T.o1=S,t.ShowFlyTip(T,s,!0)):(S=new y.Z([e]),C==ft.d.MONSTER_HUNT_MAP_VALUE?(T=new yt(u,o[5],o[6],n,h.GF.INT(o[2]),_,null),
T.npcId=h.GF.INT(o[3]),T.callback=t.FindTargetCallBack,T.o1=S,t.ShowFlyTip(T,s,null)):(g=new rt.P(o[3],0,o[4]).Clone(),S=new y.Z([e]),
C==ft.d.MONSTER_HUNT_MAP_VALUE?c.gotoPoint(g,tt.m.TASK,t.FindTargetCallBack,S,u):c.gotoPoint(g,tt.m.Point,null,S,h.GF.INT(o[2])))):C==ft.d.HANG_IN_FLY_VALUE&&(st.b.Inst.currentMapId_get()!=u||a?z.B.Inst.CM_FlyShoesTransportHandle(_,null,null,!0):f&&c.gotoPoint(g,tt.m.TASK,t.FindTargetCallBack,S,u,f))
}static SendFlyShose(e,i,s,n,a,r){if(p.p.inst.IsInCopy())return t.isInTaskFindWay=!1,void Zt.y.inst.ClientStrMsg(Jt.r.SystemTipMessage,(0,l.T)("当前正在副本中，无法进行传送"))
vt.A.Inst.isCrossing=!0
let o=null
null!=r&&0!=r&&(o=ut.e.Inst_get().GetCfgById(r)),null==o&&(o=ut.e.Inst_get().GetCfgByFixShoesBeeline(i,s.x,s.z)),
e?t.m_nowTask.resource_get().isAutoPathMap?vt.A.Inst.GotoMapPointOneByOne(i,s,tt.m.TASK,t.FindTargetCallBack,n,a):(vt.A.Inst.SetCorssParam(i,s,tt.m.TASK,t.FindTargetCallBack,n,a),
t.isInTaskFindWay=!0,null==o?t.SendTransport(i,0):z.B.Inst.CM_FlyShoesTransportHandle(o.id)):(vt.A.Inst.SetCorssParam(i,s,tt.m.TASK,t.FindTargetCallBack,n,a),t.isInTaskFindWay=!1,
p.p.inst.IsInCopy()||(t.isInTaskFindWay=!0,null==o?t.SendTransport(i,0):z.B.Inst.CM_FlyShoesTransportHandle(o.id)))}DealFindIcon(e){
t.isInTaskFindWay&&(106032!=e&&106032!=e&&106034!=e||r._.getInst().CloseStartIcon())}static DoHandIn(e,i,s,n,a){
if(t.m_nowTask.status_get()==Tt.B.FINISHED)t.TryFindPath(e,i?1:0,s,n,a)
else{const r=t.m_nowTask,o=r.tCTargetDefs_get()
if(null!=o.tCTargetDefs&&0!=o.tCTargetDefs.Count()){const _=t.JoinValue(e),u=h.GF.INT(_[1]),I=o.tCTargetDefs[u]
if(d.M.IsNullOrEmpty(I.OpenUI_get())){if(0!=I.npcId){const e=gt.f.Inst().getItemById(I.npcId)
null==e&&lt.Y.LogError((0,l.T)("npcresource中不存在配置：")+d.M.IntToString(I.npcId))
const r=new y.Z([d.M.DoubleToString(_[0]),d.M.IntToString(ft.d.HAND_IN_NPC_TALK_VALUE),d.M.IntToString(t.m_nowTask.id_get()),d.M.IntToString(e.npcid),d.M.IntToString(e.mapid),d.M.FloatToString(e.x),d.M.FloatToString(e.y)]),o=t.JointStr(r)
t.TryFindPath(o,i?1:0,s,n,a)}else if("0"!=I.param.itemModelId){const t=new q.L
t.InitData(d.M.String2Int(I.param.itemModelId),r.qVo.targets[u].value_get(),I.value,r.id_get(),!1),x.o.Inst_get().OpenHandInItemView(t)}
}else at.N.inst.OpenUIByShortCutIDOpenUI(I.OpenUI_get())}}}static ShowFlyTip(e,i,s){if(null==i&&(i=!1),null==s&&(s=!1),i){Nt.c.Inst_get().isAuto_set(!1)
const i=new Xt.N
i.showText=(0,l.T)("倒计时结束后将立即传往目的地"),i.okText=(0,l.T)("立即传送"),i.titleText=(0,l.T)("立即传送"),i.needLefttIime=!0,i.tipstype=1,i.btnColorType=2,
i.okhandler=s?t.OnBlinkFlyHandler:t.OnFlyTipHandler,i.objparams=e,i.okBtnWidth=126,Zt.y.inst.OpenCommonMessageTips(i)}else s?t.OnBlinkFlyHandler(e):t.OnFlyTipHandler(e)}
static OnBlinkFlyHandler(t){let e=0,i=rt.P.zero_get(),s=null
const n=t,a=n.GetFlyId()
if(a>0){if(s=ut.e.Inst_get().GetCfgById(a),null==s)return void lt.Y.LogError((0,l.T)("playertransportresource表中不存在传送点:")+d.M.IntToString(a))
e=s.targetMapId,i=new rt.P(s.targetX,0,s.targetY).Clone()}else e=n.mapId,i=new rt.P(n.x,0,n.y).Clone()
Nt.c.Inst_get().isAuto_set(!0),z.B.Inst.flyGotoTask=Mt.L.Inst_get().model.GetTaskById(n.taskId),z.B.Inst.OpenTransportMask(z.B.TYPE_FLY,s.id,n.taskId)}static OnFlyTipHandler(e){
let i=0,s=rt.P.zero_get(),n=null
const a=e,r=a.GetFlyId()
if(r>0){if(n=ut.e.Inst_get().GetCfgById(r),null==n)return void lt.Y.LogError((0,l.T)("playertransportresource表中不存在传送点:")+d.M.IntToString(r))
i=n.targetMapId,s=new rt.P(n.targetX,0,n.targetY).Clone()}else i=a.mapId,s=new rt.P(a.x,0,a.y).Clone()
if(Nt.c.Inst_get().isAuto_set(!0),st.b.Inst.currentMapId_get()!=i)vt.A.Inst.SetCorssParam(i,s,tt.m.TASK,a.callback,a.o1,a.reduceDistance),
n=ut.e.Inst_get().GetCfgByFixShoesBeeline(i,s.x,s.z),null==n?t.SendTransport(i,a.taskId):z.B.Inst.CM_FlyShoesTransportHandle(n.id)
else{j.Y.Inst.PrimaryRole_get().gotoPoint(s,tt.m.TASK,a.callback,a.o1,i,a.reduceDistance)}}static SendTransport(t,e){const i=j.Y.Inst.PrimaryRoleInfo_get().CurLine_get()
Ut.D.Inst.RequestCM_ChangeMapAndLine(t,i,null,null,null)}static FindTargetCallBack(e){t.isInTaskFindWay=!1,r._.getInst().openOrCloseStartIcon(),t.DealLinkTarget(e[0])}
static DealLinkTarget(e){lt.Y.Log(`DealLinkTarget ${e}`)
const i=t.JoinValue(e),n=h.GF.INT(i[1])
h.GF.INT(i[3])
if(Qt._.Inst_get().IsShowPhotographView_get()||(m.k.inst.openfanji=!0),n==ft.d.TALK_VALUE||n==ft.d.PASS_COPY_VALUE||n==ft.d.ENTER_COPY_VALUE||n==ft.d.HAND_IN_NPC_TALK_VALUE||n==ft.d.NPC_SHOP_BUY_VALUE||n==ft.d.EQUIPMENT_EQUIP_VALUE){
if(!d.M.IsNullOrEmpty(i[2])&&0!=h.GF.INT(i[2])){const t=Mt.L.Inst_get().model.GetTaskById(h.GF.INT(i[2]))
if(null!=t&&t.status_get()==Tt.B.ACCEPTED){const e=t.tCTargetDefs_get().tCTargetDefs[0].endUI
if(e>0)return void at.N.inst.OpenUIByShortCutID(e,h.GF.INT(i[3]))}}n==ft.d.HAND_IN_NPC_TALK_VALUE?t.GoDialogue(i,!1):t.GoDialogue(i,!0)
}else if(n==ft.d.KILL_MONSTER_VALUE||n==ft.d.MONSTER_HUNT_MAP_VALUE||n==ft.d.KILL_MONSTER_ITEM_VALUE||n==ft.d.KILL_MONSTER_RATE_VALUE||n==ft.d.FICTITIOUS_ITEM_VALUE){
const s=d.M.String2Int(i[2])
let n=(0,l.T)("未知")
if(0==s)r._.getInst().startPlayerHang(j.Y.Inst.PrimaryRole_get())
else{Nt.c.Inst_get().DispathHang()
const e=Mt.L.Inst_get().model.GetTaskById(s)
null!=e&&(t.m_nowTask=e,e.isHanging=!0),n=e.GetNameTxt()}t.LogFindPath&&lt.Y.LogError((0,l.T)("寻路结束开始挂机：")+(n+((0,l.T)(" 任务信息：")+e)))
const a=Mt.L.Inst_get().model.GetTaskById(d.M.String2Int(i[2]))
if(null!=a){const t=a.tCTargetDefs_get().tCTargetDefs[0].endUI
t>0&&at.N.inst.OpenUIByShortCutID(t)}}else if(n==ft.d.GATHER_VALUE){let n=null
const l=ot.J.Inst().getItemById(d.M.String2Int(i[3])),a=ot.J.Inst().GetItemListByGroupId(l.groupId)
if(n=l.id==Y.R.Inst_get().GetColloctId()?j.Y.Inst.GetTargetCollectByCfgId(l.id):j.Y.Inst.GetNearestCollectByDis(50,a),null!=n){const l=n.GetPos()
if(!l)return
if(rt.P.Distance(j.Y.Inst.PrimaryRole_get().GetPos(),l)<=n.Cfg_get().distance){j.Y.Inst.PrimaryRole_get().rotateTo(l)
const t=Mt.L.Inst_get().model.GetTaskById(h.GF.INT(i[2]))
k.k.Inst_get().gatherFlyId=t.tCTargetDefs_get().tCTargetDefs[0].param.gatherFlyId
const e=t.tCTargetDefs_get().tCTargetDefs[0].param.gatherNextTask
z.B.Inst.flyGotoTask=e>0?Mt.L.Inst_get().model.GetTaskById(e):null,k.k.Inst_get().openCollectBtn(n,!0),C.D.IsDebugCollect()&&s.s.Info("DealLinkTarget TaskEventType.GATHER_VALUE 1")
}else{const i=j.Y.Inst.PrimaryRole_get()
t.goonList=T.jq.pathFindPoint(l,i.GetPos(),n.Cfg_get().distance-1),t.goonLinkStr=e,nt.C.Inst_get().SetFrameLoop(t.LaterGoon,2,1),
C.D.IsDebugCollect()&&s.s.Info("DealLinkTarget TaskEventType.GATHER_VALUE 2")}}else{const t=Mt.L.Inst_get().model.GetTaskById(h.GF.INT(i[2]))
;(null==t||t.type_get()==Ct.U.JIGSAW&&t.status_get()!=Tt.B.ACCEPTED)&&u.J.Inst_get().DirectUseJigsawTreasureMapItem(t.id_get(),i)}
}else n==ft.d.PHOTOGRAPH_POSITION_VALUE||n==ft.d.PHOTO_MONSTER_VALUE||n==ft.d.PHOTO_NPC_VALUE?(j.Y.Inst.PrimaryRole_get().JustStand(),Qt._.Inst_get().isTaskAutoComplete=!0,
at.N.inst.OpenUIByShortCutID(h.GF.INT(i[7]))):n!=ft.d.LYING_WALL_VALUE&&n!=ft.d.SIT_DOWN_VALUE||(X.$.inst.CM_WallSitDownHandler(h.GF.INT(i[3])%100),
j.Y.Inst.PrimaryRoleInfo_get().SceneTouchState=U.z.SceneTouchHide,E.U.Inst.CloseSceneTouchView())}static ResetTaskHangState(){null!=t.m_nowTask&&(t.m_nowTask.isHanging=!1)}
static GoDialogue(e,i){null==i&&(i=!0)
const s=h.GF.INT(e[3])
s>0&&(i?Yt.F.Inst_get().control.OpenByTask(t.m_nowTask,s):Yt.F.Inst_get().control.Open(s,null,null,null,null,null),ht.l.FaceToNpc(s),ht.l.NpcFaceToPlayer(s))}static LaterGoon(){
const e=new y.Z([t.goonLinkStr])
j.Y.Inst.PrimaryRole_get().goByPositions(t.goonList,t.FindTargetCallBack,e)}GetDialogueNpc(t){const e=Mt.L.Inst_get().model.GetLinkNpcs(t.npcid)
if(e.Count()>0){return e[0]}return null}static JointStr(t){if(null!=t&&t.count>=2&&t[0]==d.M.IntToString(S.V.OPEN_PANEL)&&"0"==t[1])return""
let e=""
if(null!=t){const i=t.count
let s=0
for(;s<i;)null!=t[s]&&(e+=t[s],s<i-1&&(e+=o.o.s_UNDER_CHAR)),s+=1}return e}static JoinValue(t){const e=d.M.Split(t,o.o.s_Arr_UNDER_CHAR_DOT),i=new y.Z(e.count)
let s=0
for(;s<e.count;){if(ht.l.IsEmptyStr(e[s]))i[s]=0
else{const t=a.E.TryParseDouble(e[s])
i[s]=t?d.M.String2Double(e[s]):0}s+=1}return i}static JoinValueStr(t){return d.M.Split(t,o.o.s_Arr_UNDER_CHAR_DOT)}static SendToServer(t,e){if(null!=t){const i=Mt.L.Inst_get().mgr
t.status_get()==Tt.B.CAN_ACCEPT?i.RequestCM_AcceptQuest(t.id_get(),null):t.status_get()==Tt.B.ACCEPTED?t.isTalk_get()?i.RequestCM_DrawQuestReward(t,e):t.IsRealTalk_get()?i.CM_TalkHandle(t.RealTalkNpc_get(),t.qVo.playerId):t.IsTalkCopy()&&p.p.inst.SendEnterCopy(t.GetCopyRes().id):t.status_get()==Tt.B.FINISHED&&i.RequestCM_DrawQuestReward(t,e)
}}static GetTaskStatue(t){if(t){const e=Mt.L.Inst_get().model.GetConfig(t.questId,t.playerId)
if(t.targets){for(let i=0;i<=t.targets.Count()-1;i++)if(null==e.tCTargetDefs_get()||t.targets[i].value_get()<e.tCTargetDefs_get().tCTargetDefs[i].value)return Tt.B.ACCEPTED
return Tt.B.FINISHED}}return Tt.B.NONE}static GoonTaskStep(e){if(null==e)return
if(e.isClickReward_get())return void t.SendToServer(e,null)
const i=e.GetCopyRes()
if(null!=i&&i.controllerType==F.S.Plot&&p.p.inst.IsInCopy()&&null!=i.SuccessConditions_get()&&null!=i.SuccessConditions_get().successConditionList){
const t=i.SuccessConditions_get().successConditionList[0]
if(null!=t.param)return void j.Y.Inst.PrimaryRole_get().gotoPoint(new rt.P(t.param.x,0,t.param.y))}t.DoGoTaskStep(e)}static DoGoTaskStep(e){t.GetLinkInfo(e,null),
t.DealTaskReceive(e,null,null)}static DealTaskReceive(e,i=null,s=null){if(null==s&&(s=!1),
null==i&&(i=e.status_get()==Tt.B.FINISHED?1==e.resource_get().automateNPC:1==R.U.AUTO_TO_FINISH_NPC_NO),e.status_get()==Tt.B.CAN_ACCEPT)e.resource_get().receiveType,
R.U.RECEIVE_VIEW
else if(e.status_get()==Tt.B.ACCEPTED){e.GetNowTargetDef().IsNeedFixAttr()}d.M.IsNullOrEmpty(e.linkStr)||(Nt.c.Inst_get().autoTask_set(e),t.GotoByTask(e,i,s))}GetNeedUpByItemId(t){
const e=j.Y.Inst.PrimaryRoleInfo_get(),i=V.f.Inst().getItemById(t).Conditions_get().typevalues
let s=0,n=0
for(;n<i.Count();){const t=i[n].valueType,l=i[n].valueNum,a=e.getAttribute(qt.I.GetAttrByStr(t))
a<l&&(s+=l-a),n+=1}let l=0
if(s>0&&e.RemainBasePoint_get()<s){const t=kt.l.GetInst().GetPlayerInitial(e.Job_get())
l=Ht.p.CeilToInt((s-e.RemainBasePoint_get())/t.levelOfPoint)}return l}static CheckIsMetCondtion(t,e){if(null!=t){const i=B.z.CreateFromJson(t).typevalues
for(let t=0;t<=i.Count()-1;t++){const s=i[t]
if(s.Parse(),"GTLevel"==s.type){const t=j.Y.Inst.PrimaryRoleInfo_get().Level_get(),e=d.M.Split(s.value,o.o.s_Arr_UNDER_CHAR_DOU)
if(t>=d.M.String2Int(e[0])&&(null==e[1]||t<=d.M.String2Int(e[1])))return!0}else if("acceptQuest"==s.type){const t=d.M.String2Int(s.value)
return Rt.O.Inst_get().ExistTask2(t,e)}}}return!1}static CheckFullConditiones(t){if(null==t.StepConditions)return!1
const e=t.StepConditions.conditions.Count()
let i=0
for(let s=0;s<=e-1;s++)t.StepConditions.conditions[s].CheckCondition()&&(i+=1)
return i>=e}},Ot.isInTaskFindWay=!1,Ot.isEnterScene=!1,Ot.npcTask=new y.Z,Ot.npcEffIdDic=new O.X,Ot.m_subArr=new y.Z,Ot.m_needPoint=0,Ot.needPointList=null,
Ot.taskGreenStr="5FB470",Ot.taskRedStr="ff4443",Ot.m_havePassTipTask=!1,Ot.PRO_TAG="{a[0-9]*}",Ot.PRO_COLOR_TAG="{p.-}",Ot.PRO_LINE_TAG="{aLine",Ot.m_nowTask=null,Ot.goonList=null,
Ot.goonLinkStr=null,Ot.LogFindPath=!1,Dt=Ot))||Dt},17783:(t,e,i)=>{i.d(e,{L:()=>T})
var s=i(32076),n=i(98800),l=i(97461),a=i(38935),r=i(66788),o=i(85602),h=i(92679),d=i(98996),_=i(56813),u=i(23664),I=i(63170),c=i(91552),g=i(11509),p=i(47963)
class m{constructor(){this._model=null}RegisterMsg(){l.i.Inst.AddEventHandler(h.g.MAP_LOGIN_LOAD_COMPELETE,(0,s.v)(this.ReqTask,this)),this._model=T.Inst_get().model}ReqTask(){
let t=new I.U
a.C.Inst.F_SendMsg(t),t=new d.F,a.C.Inst.F_SendMsg(t)}RequestCM_AcceptQuest(t,e){e||(e=n.Y.Inst.PrimaryRoleInfo_get().Id_get())
const i=new _.o
i.playerId=e,i.questId=t,a.C.Inst.F_SendMsg(i)}CM_TalkHandle(t,e){if(null==t)return void r.Y.LogError("npc id 为空")
const i=new g.u
i.npcId=t,i.playerId=e,a.C.Inst.F_SendMsg(i)}SendCloseUI(t){}RequestCM_DrawQuestReward(t,e){const i=new u.m
i.playerId=t.qVo.playerId,i.id=t.id_get(),null==e&&(e=new o.Z),i.consumeIds=e,a.C.Inst.F_SendMsg(i)}CM_QuestHandInHandle(t,e,i){const s=new c.e
s.playerId=n.Y.Inst.PrimaryRoleInfo_get().Id_get(),s.id=t,s.itemId=e,s.num=i,a.C.Inst.F_SendMsg(s)}RequestCM_GiveUp(t){p.c.Inst_get().isGiveupCourse_set(!0),
p.c.Inst_get().isAuto_set(!1),n.Y.Inst.PrimaryRole_get().StopPathing()}}var S=i(79878)
class T{constructor(){this.model=null,this.mgr=null,this.tranMapTaskId=-1,this.model=INS.taskModel,this.mgr=new m}static Inst_get(){return null==T._mInst&&(T._mInst=new T),T._mInst
}DealTranMapTask(){this.tranMapTaskId>0&&(this.GotoTaskStepById(this.tranMapTaskId),this.tranMapTaskId=-1)}GotoTaskStepById(t){const e=T.Inst_get().model.GetTaskById(t)
null!=e&&S.Y.DealLinkTarget(e.linkStr)}}T._mInst=null},619:(t,e,i)=>{i.d(e,{m:()=>a})
var s=i(5924),n=i(85602),l=i(79534)
class a{constructor(){this._luaTran=null,this._fromX=0,this._endX=0,this.moveValues=null,this._vec=null,this._moveCount=0,this._finishHandler=null,this._isLeft2Right=!0,
this._needBackTween=!0,this.m_moveTimer=0,this.isClear=!1,this._executeAction=null,this.callTag=0,this._degf_OnTraceBack=null,this._vec=new l.P,
this._degf_OnTraceBack=()=>this.OnTraceBack()}SetLuaParam(t,e,i,s,n,l){null==n&&(n=!0),this._luaTran=t,this._vec=this._luaTran.GetLocalPosition().clone(),this._fromX=e,
this._endX=i,this._finishHandler=s,this._isLeft2Right=i>e,this._needBackTween=n,this._executeAction=l,this.isClear=!1}StartTween(){let t=null
t=this._needBackTween?new n.Z([-10,-8,22,20,19,17,16,14,10]):new n.Z([22,19,16,15,12,9,5]),this._vec.x=this._fromX,this._luaTran.SetLocalPosition(this._vec)
const e=this._endX-this._fromX
this.moveValues=new n.Z
let i=0
for(;i<t.count;)this.moveValues[i]=t[i]/100*e,i+=1
this._moveCount=t.count,this._isLeft2Right?this.callTag=0:this.callTag=this._moveCount-1,s.C.Inst_get().ClearInterval(this.m_moveTimer),
this.m_moveTimer=s.C.Inst_get().SetFrameLoop(this._degf_OnTraceBack,1,this._moveCount)}OnTraceBack(){
this.callTag<0||this.callTag>=this.moveValues.count||null==this._luaTran||this.isClear?s.C.Inst_get().ClearInterval(this.m_moveTimer):(this._vec.x=this._vec.x+this.moveValues[this.callTag],
this._luaTran.SetLocalPosition(this._vec),null!=this._executeAction&&this._executeAction(),this._isLeft2Right?this.callTag+=1:this.callTag-=1,this._moveCount-=1,
0==this._moveCount&&(this._vec.x=this._endX,this._luaTran.SetLocalPosition(this._vec),null!=this._finishHandler&&this._finishHandler(),this._executeAction=null))}Clear(){
null!=this._luaTran&&this._luaTran.node&&(this._vec.x=this._endX,this._luaTran.SetLocalPosition(this._vec)),s.C.Inst_get().ClearInterval(this.m_moveTimer)}Destroy(){this.Clear(),
this._luaTran=null,this.moveValues=null,this._finishHandler=null,this._executeAction=null}}},83659:(t,e,i)=>{i.d(e,{h:()=>a})
var s=i(85602),n=i(98130)
class l{constructor(){this.name=null,this.nextPage=0,this.commit=!1,this.IconRes=null,this.highlight=0,this.choose=0}FillData(t){this.name=n.GF.LuaJsonToString(t.name),
this.nextPage=n.GF.LuaJsonToNumber(t.nextPage),this.commit=n.GF.LuaJsonToBoolean(t.commit),this.IconRes=n.GF.LuaJsonToString(t.IconRes),
this.highlight=n.GF.LuaJsonToNumber(t.highlight),this.choose=n.GF.LuaJsonToNumber(t.choose)}IsLastPage(){return 0==this.nextPage}}class a{constructor(){this.dialogBtns=null}
FillData(t){this.dialogBtns=new s.Z
const e=new s.Z(t.dialogBtns)
let i=0
for(;i<e.Count();){const t=e[i],s=new l
s.FillData(t),this.dialogBtns.Add(s),i+=1}}}},41161:(t,e,i)=>{i.d(e,{c:()=>n})
var s=i(98130)
class n{constructor(){this.isNpc=!1,this.text=null,this.nextPage=0,this.commit=!1,this.trace=!1,this.openui=0,this.choose=null}FillData(t){
this.isNpc=s.GF.LuaJsonToBoolean(t.isNpc),this.text=s.GF.LuaJsonToString(t.text),this.nextPage=s.GF.LuaJsonToNumber(t.nextPage),this.commit=s.GF.LuaJsonToBoolean(t.commit),
this.trace=s.GF.LuaJsonToBoolean(t.trace),this.openui=s.GF.LuaJsonToNumber(t.openui),this.choose=s.GF.LuaJsonToNumber(t.choose)}IsLastPage_get(){return 0==this.nextPage}}},
8038:(t,e,i)=>{i.d(e,{x:()=>A})
var s=i(38836),n=i(62370),l=i(95721),a=i(98130),r=i(98885),o=i(85602),h=i(1240),d=i(63076),_=i(3579),u=i(77477),I=i(33314),c=i(87923),g=i(60917),p=i(44498),m=i(15780),S=i(48481),T=i(98394),f=i(23296),C=i(19519)
class E{constructor(){this.intType=0,this.strType=null,this.num=0,this.limitDiamondId=null}IntType_get(){return this.intType}IntType_set(t){this.intType=t,
this.strType=this.typeConvertToStr(this.intType)}StrType_get(){return this.strType}StrType_set(t){this.strType=t,this.intType=this.typeConvertToInt(this.strType)}Num_get(){
return this.num}Num_set(t){this.num=t}typeConvertToStr(t){return 1==t?"GOLD":2==t?"GOLD_DIAMOND":t==C.J.GOLD_DIAMOND_LIMIT?C.J.GOLD_DIAMOND_LIMIT_STR:null}typeConvertToInt(t){
return"GOLD"==t?C.J.GOLD:"GOLD_DIAMOND"==t?C.J.GOLD_DIAMOND:t==C.J.GOLD_DIAMOND_LIMIT_STR?C.J.GOLD_DIAMOND_LIMIT:0}}class A{constructor(){this.type=null,this.value=null,
this.rewardVal=null,this.job=null,this.jobBranchsLimit=null,this.bind="false",this.handInTxt=null,this.showid=0,this.Mapicon=null,this.func=null,this.access=null,this.notShow=0,
this.listLegend=null,this._bData=null,this._bagItem=null,this._attrBagItem=null,this.AsuramBuildItem=null,this._cData=null,this._expData=null,this._goldData=null,
this._goldDiamondData=null,this._scoreData=null,this._honourData=null,this._skillPointData=null,this._vitalityData=null,this._AttrData=null,this._taskRewardAttr=null,
this._SkillData=null,this._energyPointData=null,this._jobValue=-1,this._jobBranchsLimitValue=null,this._levelGT=0,this._dragonsoulCoin=0,this._dragonsoulJiFen=0,
this._forgepoints=0,this._courage=0,this._map=0,this._asuramContribution=0,this._talent=0,this._masterPoint=0,this.m_firstValue=-1,this.m_secondValue=-1,this.currentType=null,
this.showtag=0,this.EXTRA=null,this.ONLY=null,this.functionId=null,this.soleAttr=null,this.limitId=null,this._angelExpData=null,this.listLegend=new o.Z}firstValue_get(){
return this.PauseValue(),this.m_firstValue}secondValue_get(){return this.PauseValue(),this.m_secondValue}isAccess_get(){return"true"==this.access}PauseValue(){
if(-1==this.m_firstValue){const t=r.M.Split(this.rewardVal,n.o.s_Arr_UNDER_COLON)
this.m_firstValue=r.M.String2Int(t[0]),this.m_secondValue=r.M.String2Int(t[1])}}GetItemDataByType(){
return this.type==f.E.EXP?this.expitem_get():this.type==f.E.Currency?this.currencyItem_get():this.type==f.E.Attr?this.attrBagItem_get().baseData_get():this.type==f.E.Item?this.baseItem_get():this.type==f.E.ActivityScore?this.activityScoreItem_get():this.type==f.E.Angel_Exp?this.angelexp_get():null
}Parse(){this.rewardVal=this.value}isBind_get(){return null!=this.bind&&"true"==this.bind.toLowerCase()}isExtra_get(){return null!=this.EXTRA&&"true"==this.EXTRA.toLowerCase()}
isOnly_get(){return null!=this.ONLY&&"true"==this.ONLY.toLowerCase()}jobValue_get(){
return-1==this._jobValue&&(c.l.IsEmptyStr(this.job)?this._jobValue=I.Z.NONE:this._jobValue=r.M.String2Int(this.job)),this._jobValue}jobBranchsLimit_get(){
if(c.l.IsEmptyStr(this.jobBranchsLimit))return null
if(null==this._jobBranchsLimitValue){const t=r.M.Split(this.jobBranchsLimit,n.o.s_Arr_UNDER_CHAR_DOT)
this._jobBranchsLimitValue=new o.Z([r.M.String2Int(t[0]),r.M.String2Int(t[1])])}return this._jobBranchsLimitValue}funcLimit_get(){return this.functionId}levelGT_get(){
return this.type==f.E.Level?(this._levelGT=r.M.String2Int(this.rewardVal),this._levelGT):0}baseItem_get(){if(this.type==f.E.Item){if(null==this._bData){
const t=r.M.Split(this.rewardVal,n.o.s_Arr_UNDER_COLON)
if(this._bData=new d.M(r.M.String2Int(t[0]),null),this._bData.count=r.M.String2Int(t[1]),this._bData.id=r.M.String2Int(t[2]),this._bData.isCanOperate=!1,this._bData.isForBag=!1,
this._bData.isEquipCompare=!1,this._bData.isShowAddPointTip=!1,this.isBind_get()){const t=new S.t
t.modelId=this._bData.modelId_get(),t.state=1,t.num=1,this._bData.serverData_set(t)}this._bData.isExtra=this.isExtra_get(),this._bData.isOnly=this.isOnly_get(),
null!=this._bData.equipInfo_get()&&this._bData.equipInfo_get().isOutOfPrintShow_set(this.soleAttr),this._bData.autoGetInTip=this.isAccess_get(),
this._bData.SetEquipAttrShowId(this.showid)
for(const[t,e]of(0,s.V5)(this.listLegend))this._bData.listLegend.Add(e)}return this._bData}if(this.type==f.E.RuneItem){if(null==this._bData){
const t=r.M.Split(this.rewardVal,n.o.s_Arr_UNDER_COLON)
this._bData=new d.M(r.M.String2Int(t[0]),null),this._bData.count=r.M.String2Int(t[1]),this._bData.isCanOperate=!1,this._bData.isForBag=!1,
this._bData.autoGetInTip=this.isAccess_get()}return this._bData}if(this.type==f.E.Title){if(null==this._bData){const t=_.W.Inst().getItemById(r.M.String2Int(this.value))
this._bData=new d.M(t.value,null),this._bData.count=1,this._bData.isCanOperate=!1,this._bData.isForBag=!1,this._bData.autoGetInTip=this.isAccess_get()}return this._bData}
return null}bagItem_get(){if(this.type==f.E.Item){if(null==this._bagItem){const t=r.M.Split(this.rewardVal,n.o.s_Arr_UNDER_COLON),e=new S.t
this.isBind_get()&&(e.state=1),e.modelId=r.M.String2Int(t[0]),e.num=r.M.String2Int(t[1]),this._bagItem=new h.Y,this._bagItem.serverData_set(e),
this._bagItem.baseData_get().isForBag=!1,this._bagItem.baseData_get().isCanOperate=!1,this._bagItem.baseData_get().autoGetInTip=this.isAccess_get(),
this._bagItem.baseData_get().isExtra=this.isExtra_get(),this._bagItem.baseData_get().isOnly=this.isOnly_get(),
null!=this._bagItem.baseData_get().equipInfo_get()&&this._bagItem.baseData_get().equipInfo_get().isOutOfPrintShow_set(this.soleAttr),this._bagItem.baseData_get().count=e.num,
this._bagItem.SetEquipAttrShowId(this.showid)}return this._bagItem}if(this.type==f.E.RuneItem){if(null==this._bagItem){
const t=r.M.Split(this.rewardVal,n.o.s_Arr_UNDER_COLON),e=new S.t
this.isBind_get()?e.state=1:e.state=0,e.modelId=r.M.String2Int(t[0]),e.num=r.M.String2Int(t[1]),this._bagItem=new h.Y,this._bagItem.serverData_set(e),
this._bagItem.baseData_get().isForBag=!1,this._bagItem.baseData_get().isCanOperate=!1,this._bagItem.baseData_get().isExtra=this.isExtra_get(),
this._bagItem.baseData_get().autoGetInTip=this.isAccess_get()}return this._bagItem}if(this.type==f.E.Title){if(null==this._bagItem){
const t=_.W.Inst().getItemById(r.M.String2Int(this.value)),e=new S.t
this.isBind_get()?e.state=1:e.state=0,e.modelId=t.value,e.num=1,this._bagItem=new h.Y,this._bagItem.serverData_set(e),this._bagItem.baseData_get().isForBag=!1,
this._bagItem.baseData_get().isCanOperate=!1,this._bagItem.baseData_get().autoGetInTip=this.isAccess_get(),this._bagItem.baseData_get().isExtra=this.isExtra_get()}
return this._bagItem}return null}Cdata_get(){if(this.type==f.E.Currency){const t=r.M.Split(this.rewardVal,n.o.s_Arr_UNDER_COLON)
return this._cData=new E,this._cData.Num_set(r.M.String2Int(t[1])),this._cData.StrType_set(t[0]),this._cData.limitDiamondId=r.M.String2Int(this.limitId),this._cData}return null}
Attrdata_get(){if(this.type==f.E.Attr){if(null==this._AttrData){const t=r.M.Split(this.rewardVal,n.o.s_Arr_UNDER_COLON)
this._AttrData=new g.P,this._AttrData.type=t[0],this._AttrData.intType=p.I.GetAttrByStr(t[0]),this._AttrData.value=r.M.String2Int(t[1])}return this._AttrData}return null}
taskRewardAttr_get(){return null==this._taskRewardAttr&&(this._taskRewardAttr=new g.P,this._taskRewardAttr.type=this.type,this._taskRewardAttr.intType=p.I.GetAttrByStr(this.type),
this._taskRewardAttr.value=r.M.String2Int(this.GetValue())),this._taskRewardAttr}GetValue(){return this.value}Skilldata_get(){return this.type==f.E.Skill?(this._SkillData=new m.U,
this._SkillData.type=this.type,this._SkillData.value=this.rewardVal,this._SkillData):null}expitem_get(){if(this.type==f.E.EXP){
const t=r.M.Split(this.rewardVal,n.o.s_Arr_UNDER_COLON)
this._expData=new d.M(0,null)
const e=r.M.String2Double(t[0]),i=l.o.FromNumber(e)
return this._expData.SetVirtualItemDataByParam(T.d.EXP_STR,i),this._expData.isForBag=!1,this._expData}return null}attrBagItem_get(){if(this.type==f.E.Attr){
if(null==this._attrBagItem){const t=this.Attrdata_get(),e=new S.t
if(t.intType==a.GF.INT(u.Z.Attack))e.modelId=10216,e.num=1
else{if(t.intType!=a.GF.INT(u.Z.Defense))return null
e.modelId=10217,e.num=1}this._attrBagItem=new h.Y,this._attrBagItem.serverData_set(e),this._attrBagItem.baseData_get().isCanOperate=!1}return this._attrBagItem}return null}
AsuramBuildItem_get(){if(this.type==f.E.ASURAM_BUILDING_POINT){if(null==this.AsuramBuildItem){const t=new S.t
t.modelId=10221,t.num=r.M.String2Int(this.value),this.AsuramBuildItem=new d.M(t.modelId,t)}return this.AsuramBuildItem}return null}currencyItem_get(){if(this.type==f.E.Currency){
const t=r.M.Split(this.rewardVal,n.o.s_Arr_UNDER_COLON)
this.currentType=t[0]
const e=r.M.String2Double(t[1]),i=l.o.FromNumber(e),s=this.isExtra_get()
if("GOLD"==t[0])return this._goldData=new d.M(0,null),this._goldData.SetVirtualItemDataByParam(t[0],i),this._goldData.isForBag=!1,this._goldData.count=e,this._goldData.isExtra=s,
this._goldData.isShowExtra=!0,this._goldData
if("GOLD_DIAMOND"==t[0])return this._goldDiamondData=new d.M(0,null),this._goldDiamondData.SetVirtualItemDataByParam(t[0],i),this._goldDiamondData.isForBag=!1,
this._goldDiamondData.count=e,this._goldDiamondData.isExtra=s,this._goldDiamondData.isShowExtra=!0,this._goldDiamondData
if(t[0]==C.J.GOLD_DIAMOND_LIMIT_STR)return this._goldDiamondData=new d.M(0,null),this._goldDiamondData.SetVirtualItemDataByParam(t[0],i),this._goldDiamondData.isForBag=!1,
this._goldDiamondData.count=e,this._goldDiamondData.isExtra=s,this._goldDiamondData.isShowExtra=!0,this._goldDiamondData.limitDiamondId=r.M.String2Int(this.limitId),
this._goldDiamondData
if("CONSIGN_SCORE"==t[0])return this._scoreData=new d.M(0,null),this._scoreData.SetVirtualItemDataByParam(t[0],i),this._scoreData.isForBag=!1,this._scoreData.count=e,
this._scoreData.isExtra=s,this._scoreData.isShowExtra=!0,this._scoreData
if("HONOUR"==t[0])return this._honourData=new d.M(0,null),this._honourData.SetVirtualItemDataByParam(t[0],i),this._honourData.isForBag=!1,this._honourData.count=e,
this._honourData.isExtra=s,this._honourData.isShowExtra=!0,this._honourData
if("SKILL_POINT"==t[0])return this._skillPointData=new d.M(0,null),this._skillPointData.SetVirtualItemDataByParam(t[0],i),this._skillPointData.isForBag=!1,
this._skillPointData.count=e,this._skillPointData.isExtra=s,this._skillPointData.isShowExtra=!0,this._skillPointData
if("VITALITY_NUM"==t[0])return this._vitalityData=new d.M(0,null),this._vitalityData.SetVirtualItemDataByParam(t[0],i),this._vitalityData.isForBag=!1,this._vitalityData.count=e,
this._vitalityData.isExtra=s,this._vitalityData.isShowExtra=!0,this._vitalityData
if("FRIEND_POINT"==t[0])return this._vitalityData=new d.M(0,null),this._vitalityData.SetVirtualItemDataByParam(t[0],i),this._vitalityData.isForBag=!1,this._vitalityData.count=e,
this._vitalityData.isExtra=s,this._vitalityData.isShowExtra=!0,this._vitalityData
if("REPUTATION"==t[0])return this._vitalityData=new d.M(0,null),this._vitalityData.SetVirtualItemDataByParam(t[0],i),this._vitalityData.isForBag=!1,this._vitalityData.count=e,
this._vitalityData.isExtra=s,this._vitalityData.isShowExtra=!0,this._vitalityData
if("ASURAM_TOKEN"==t[0])return this._vitalityData=new d.M(0,null),this._vitalityData.SetVirtualItemDataByParam(t[0],i),this._vitalityData.isForBag=!1,this._vitalityData.count=e,
this._vitalityData.isExtra=s,this._vitalityData.isShowExtra=!0,this._vitalityData
if("REBIRTH_QUEST_POINT"==t[0])return this._vitalityData=new d.M(0,null),this._vitalityData.SetVirtualItemDataByParam(t[0],i),this._vitalityData.isForBag=!1,
this._vitalityData.count=e,this._vitalityData.isExtra=s,this._vitalityData.isShowExtra=!0,this._vitalityData
if("THEME_SCORE"==t[0])return this._vitalityData=new d.M(0,null),this._vitalityData.SetVirtualItemDataByParam(t[0],i),this._vitalityData.isForBag=!1,this._vitalityData.count=e,
this._vitalityData.isExtra=s,this._vitalityData.isShowExtra=!0,this._vitalityData
if("TREASURES"==t[0])return this._vitalityData=new d.M(0,null),this._vitalityData.SetVirtualItemDataByParam(t[0],i),this._vitalityData.isForBag=!1,this._vitalityData.count=e,
this._vitalityData.isExtra=s,this._vitalityData.isShowExtra=!0,this._vitalityData}return null}asuramContribution_get(){
return this.type==f.E.AsuramContribution?(this._asuramContribution=r.M.String2Int(this.rewardVal),this._asuramContribution):0}forgepoints_get(){
return this.type==f.E.ForgePoints?(this._forgepoints=r.M.String2Int(this.rewardVal),this._forgepoints):0}angelexp_get(){this._angelExpData=new d.M(0,null)
const t=r.M.String2Int(this.rewardVal),e=l.o.FromNumber(t)
return this._angelExpData.SetVirtualItemDataByParam(T.d.ANGEL_EXP,e),this._angelExpData.isForBag=!1,this._angelExpData.count=t,this._angelExpData.isShowExtra=!0,this._angelExpData}
courage_get(){return this.type==f.E.Courage?(this._courage=r.M.String2Int(this.rewardVal),this._courage):0}map_get(){
return this.type==f.E.Map?(this._map=r.M.String2Int(this.rewardVal),this._map):0}Talent_get(){return this.type==f.E.Talent?(this._talent=r.M.String2Int(this.rewardVal),
this._talent):0}MasterPoint_get(){return this.type==f.E.MasterPoint?(this._masterPoint=r.M.String2Int(this.rewardVal),this._masterPoint):0}EnergyPointData_get(){return null}}},
28359:(t,e,i)=>{i.d(e,{h:()=>u})
var s=i(38836),n=i(90419),l=i(50089),a=i(98130),r=i(98885),o=i(85602),h=i(37648),d=i(17838),_=i(8038)
class u{constructor(){this.rewardValues=null,this.itemList=null}FillData(t){this.rewardValues=new o.Z
const e=new o.Z(t.rewardValues)
let i=0
for(;i<e.Count();){const t=e[i],s=new _.x
s.type=a.GF.LuaJsonToString(t.type),s.value=a.GF.LuaJsonToString(t.value),s.job=a.GF.LuaJsonToString(t.job),s.jobBranchsLimit=a.GF.LuaJsonToString(t.jobBranchsLimit),
s.bind=a.GF.LuaJsonToString(t.bind),s.EXTRA=a.GF.LuaJsonToString(t.EXTRA),s.handInTxt=a.GF.LuaJsonToString(t.handInTxt),s.showid=a.GF.LuaJsonToNumber(t.showid),
s.Mapicon=a.GF.LuaJsonToString(t.Mapicon),s.func=a.GF.LuaJsonToString(t.func),s.access=a.GF.LuaJsonToString(t.access),s.showtag=a.GF.LuaJsonToNumber(t.showtag),
s.ONLY=a.GF.LuaJsonToString(t.ONLY),s.soleAttr=a.GF.LuaJsonToBoolean(t.soleAttr),s.limitId=a.GF.LuaJsonToString(t.limitId),s.num=a.GF.LuaJsonToNumber(t.num),
1!=t.notShow&&this.rewardValues.Add(s),i+=1}}Parse(){for(const[t,e]of(0,s.V5)(this.rewardValues))e.Parse()}static CreateFromJson(t){const e=new u
e.rewardValues=new o.Z
for(let i=0;i<t.length;i++)if(1!=t[i].notShow){const s=new _.x
d.g.FillJsonData(s,t[i],!0),e.rewardValues.Add(s)}return e.Parse(),e}static valueOf(t){if(r.M.IsNullOrEmpty(t)||"[]"==t)return null
t=n.d.parseJsonObjectWithFix(t,"rewardValues")
const e=l.t.decode(t,u)
return e.Parse(),e}GetItemList(){return null==this.itemList&&(this.itemList=this.CalItemList()),this.itemList}CalItemList(){const t=new o.Z
let e=0
for(;e<this.rewardValues.Count();){const i=this.rewardValues[e].GetItemDataByType()
t.Add(i),e+=1}return t}GetFuncLimitItemList(){const t=new o.Z
let e=0
for(;e<this.rewardValues.Count();){const i=this.rewardValues[e]
if(null==i.funcLimit_get()){const e=i.GetItemDataByType()
t.Add(e)}else if(h.P.Inst_get().IsFunctionOpened(r.M.String2Int(i.funcLimit_get()))){const e=i.GetItemDataByType()
t.Add(e)}e+=1}return t}}},59586:(t,e,i)=>{i.d(e,{N:()=>E})
var s=i(50089),n=i(98130),l=i(85602),a=i(2457),r=i(62370),o=i(98885),h=i(87923),d=i(89803),_=i(86133),u=i(66788),I=i(35128),c=i(5468),g=i(79534),p=i(84308),m=i(9659),S=i(77697),T=i(96102)
class f{constructor(){this.npcId=0,this.monsterId=0,this.monsterGroupId=0,this.itemModelId=r.o.s_BLANK_CHAR,this.itemRate=0,this.gatherId=0,this.copyId=0,this.mapId=0,
this.mapList=0,this.currencyType=r.o.s_BLANK_CHAR,this.equipmentType=r.o.s_BLANK_CHAR,this.stepLv=0,this.equipStepLv=0,this.fly=null,this.equipType=r.o.s_BLANK_CHAR,this.questId=0,
this.questType=-1,this.groupId=-1,this.immortalsType=-1,this.composeTabs=1,this.num=0,this.x=0,this.y=0,this.ids=r.o.s_BLANK_CHAR,this.value=0,this.m_npcPosStr=r.o.s_BLANK_CHAR,
this.suitlevel=0,this.suitType=0,this.prayType=0,this.addLevel=0,this.skillId="",this.grade=0,this.itemGroupId=0,this.star=0,this.transfer=0,this.quality=0,
this.equipexcellencenum=0,this.excellentOrSuit=0,this.equipexcellencetype=r.o.s_BLANK_CHAR,this.equipenhancelevel=0,this.equipaddlevel=0,this.gatherFlyId=0,this.gatherNextTask=0,
this.hideItemId=r.o.s_BLANK_CHAR,this.questionId=r.o.s_BLANK_CHAR,this.transferPoint=r.o.s_BLANK_CHAR,this.multiAccess=r.o.s_BLANK_CHAR,this.multiItem=0,
this.multiShowItem=r.o.s_BLANK_CHAR,this.recommond=0,this.group=0,this.dealChild=0,this.CONSIGN_SCORE=0,this.equipColumn=0,this.type=r.o.s_BLANK_CHAR,this.langId=r.o.s_BLANK_CHAR,
this.suggestHang=0,this.skillType=0,this.talentId=0,this.m_flyPos=r.o.s_BLANK_CHAR,this.m_useFlyId=-1,this.m_gatherPos=r.o.s_BLANK_CHAR,this.time=0,
this.buttonIcon=r.o.s_BLANK_CHAR,this.isMiracleObj=0,this.UIId=0,this.attrName="",this.wallId=0,this.multiHang=0,this.isTransmit=0,this.NeedTalk=0,this.guideBtn=0}npcPosStr_get(t){
if(h.l.IsEmptyStr(this.m_npcPosStr))if(this.uesFlyId_get()>0){const t=m.e.Inst_get().GetCfgById(this.uesFlyId_get())
this.m_npcPosStr=t.targetMapId+(r.o.s_UNDER_CHAR+(t.targetX+(r.o.s_UNDER_CHAR+t.targetY)))}else{const t=S.f.Inst().getItemById(this.npcId)
this.m_npcPosStr=t.mapid+(r.o.s_UNDER_CHAR+(t.x+(r.o.s_UNDER_CHAR+t.y)))}if(t){const t=S.f.Inst().getItemById(this.npcId)
return t.mapid+(r.o.s_UNDER_CHAR+(t.x+(r.o.s_UNDER_CHAR+t.y)))}return this.m_npcPosStr}uesFlyId_get(){if(this.m_useFlyId<0&&(this.m_useFlyId=0,!h.l.IsEmptyStr(this.fly))){
const t=o.M.Split(this.fly,r.o.s_UNDER_CHAR),e=I.p.FloorToInt(I.p.RandomMax(t.count))
this.m_useFlyId=o.M.String2Int(t[e])}return this.m_useFlyId}flyPos_get(){if(h.l.IsEmptyStr(this.m_flyPos)&&(this.m_flyPos="",this.uesFlyId_get()>0)){
const t=m.e.Inst_get().GetCfgById(this.uesFlyId_get())
if(null==t)return u.Y.LogError((0,_.T)("PLAYERTRANSPORTRESOURCE表中没有配置id为")+(this.uesFlyId_get()+(0,_.T)("的项"))),this.m_flyPos
this.m_flyPos=t.targetMapId+(r.o.s_UNDER_CHAR+(t.targetX+(r.o.s_UNDER_CHAR+t.targetY)))}return this.m_flyPos}gatherPos_get(){if(this.uesFlyId_get()>0){
const t=m.e.Inst_get().GetCfgById(this.uesFlyId_get())
this.m_gatherPos=t.targetMapId+(r.o.s_UNDER_CHAR+(t.targetX+(r.o.s_UNDER_CHAR+t.targetY)))}else{let t=null
t=this.gatherId>0?p.J.Inst().getItemById(this.gatherId):p.J.Inst().GetItemByGroupId(this.groupId),this.m_gatherPos=t.mapId+(r.o.s_UNDER_CHAR+(t.x+(r.o.s_UNDER_CHAR+t.y)))}
return this.m_gatherPos}GetReduceDistance(){if(this.npcId>0){if(this.uesFlyId_get()>0)return 0
return S.f.Inst().getItemById(this.npcId).reactDistance-.2}if(this.gatherId>0){if(this.uesFlyId_get()>0)return 0
return p.J.Inst().getItemById(this.gatherId).distance-.2}return 0}GetTransTargetData(){let t=null
if(0!=this.uesFlyId_get()){const e=m.e.Inst_get().GetCfgById(this.uesFlyId_get())
null==e?u.Y.LogError((0,_.T)("playertransportresource表中不存在flyId:")+o.M.IntToString(this.uesFlyId_get())):(t=new T.B,t.mapId=e.targetMapId,
t.targetPos=new g.P(e.targetX,0,e.targetY).Clone(),t.transportCfg=e)}else if(0!=this.npcId){const e=S.f.Inst().getItemById(this.npcId)
null==e?u.Y.LogError((0,_.T)("npcresource表中不存在npcId:")+o.M.IntToString(this.npcId)):(t=new T.B,t.mapId=e.mapid,t.targetPos=new g.P(e.x,0,e.y).Clone(),t.npcCfg=e)
}else if(0!=this.gatherId||0!=this.groupId){let e=null,i=c.E.s_Empty
0!=this.gatherId?(e=p.J.Inst().getItemById(this.gatherId),i=(0,_.T)("GatherableResource表中不存在gatherId:")+o.M.IntToString(this.gatherId)):(e=p.J.Inst().GetItemByGroupId(this.groupId),
i=(0,_.T)("GatherableResource表中不存在groupId:")+o.M.IntToString(this.groupId)),null==e?u.Y.LogError(i):(t=new T.B,t.mapId=e.mapId,t.targetPos=new g.P(e.x,0,e.y).Clone(),t.gatherCfg=e)
}return t}__GetFieldType(t){
return"npcId"==t||"monsterId"==t||"monsterGroupId"==t||"itemRate"==t||"gatherId"==t||"copyId"==t||"mapId"==t?"number":"mapList"==t?"string":"stepLv"==t||"equipStepLv"==t||"questId"==t||"questType"==t||"groupId"==t||"immortalsType"==t||"composeTabs"==t||"num"==t||"x"==t||"y"==t||"value"==t||"suitlevel"==t||"suitType"==t||"prayType"==t||"addLevel"==t||"grade"==t||"itemGroupId"==t||"star"==t||"transfer"==t||"quality"==t||"equipexcellencenum"==t||"excellentOrSuit"==t||"equipenhancelevel"==t||"equipaddlevel"==t||"gatherFlyId"==t||"gatherNextTask"==t||"multiItem"==t||"recommond"==t||"group"==t||"dealChild"==t||"CONSIGN_SCORE"==t||"equipColumn"==t||"skillType"==t||"talentId"==t||"suggestHang"==t||"time"==t||"isMiracleObj"==t||"UIId"==t||"wallId"==t||"multiHang"==t||"isTransmit"==t||"NeedTalk"==t||"guideBtn"==t?"number":"string"
}}class C{constructor(){this.key=0,this.type=null,this.param=null,this.value=0,this.autoUpTrigger=0,this.openUI=null,this.npcId=0,this.endUI=0,this.flyUI=null,this.flyUIChild=null,
this.guidId=0,this.time=0,this.desc=null,this.isTrace=null,this.goUI=null,this.isParsed=!1,this.steps=null,this.condition=null,this.cIdUI=null}OpenUI_get(){
return null==this.openUI&&this.ParseGoUI(),this.openUI}OpenUI_set(t){this.openUI=t}GetCurStep(){}ParseGoUI(){if(this.isParsed)return
if(this.isParsed=!0,h.l.IsEmptyStr(this.goUI))return
const t=o.M.Split(this.goUI,r.o.s_UNDER_LINE)
this.OpenUI_set(t[0])
let e=null
2==t.count&&(e=o.M.Split(t[1],o.M.s_CCD_CHAR),this.flyUI=e[0],2==e.count&&(this.flyUIChild=e[1]))}IsNeedFixAttr(){
return this.type==d.d.POINT_LEARN_SKILL||!(this.type!=d.d.EQUIPMENT_EQUIP&&this.type!=d.d.ONE_QUEST||o.M.IsNullOrEmpty(this.param.itemModelId))}IsOpenAndFlyUIFilled(){
return"-1"!=this.OpenUI_get()&&!o.M.IsNullOrEmpty(this.flyUI)}__GetFieldType(t){
return"param"==t?f:"key"==t||"value"==t||"autoUpTrigger"==t||"endUI"==t||"time"==t||"cIdUI"==t?"number":"steps"!=t?"condition"==t?"table":"string":void 0}}class E{constructor(){
this.tCTargetDefs=null}FillData(t){this.tCTargetDefs=new l.Z
const e=new l.Z(t.tCTargetDefs)
let i=0
for(;i<e.Count();){const t=e[i],s=new C
s.key=n.GF.LuaJsonToNumber(t.key),s.value=n.GF.LuaJsonToNumber(t.value),s.autoUpTrigger=n.GF.LuaJsonToNumber(t.autoUpTrigger),s.endUI=n.GF.LuaJsonToNumber(t.endUI),
s.time=n.GF.LuaJsonToNumber(t.time),s.type=n.GF.LuaJsonToString(t.type),s.desc=n.GF.LuaJsonToString(t.desc),s.isTrace=n.GF.LuaJsonToString(t.isTrace),
s.goUI=n.GF.LuaJsonToString(t.goUI),s.cIdUI=n.GF.LuaJsonToNumber(t.cIdUI),null!=t.condition&&(s.condition=a.u.CreateFromJson(t.condition)),null!=t.param?(s.param=new f,
s.param.npcId=n.GF.LuaJsonToNumber(t.param.npcId),s.param.monsterId=n.GF.LuaJsonToNumber(t.param.monsterId),s.param.monsterGroupId=n.GF.LuaJsonToNumber(t.param.monsterGroupId),
s.param.itemModelId=n.GF.LuaJsonToString(t.param.itemModelId),s.param.itemRate=n.GF.LuaJsonToNumber(t.param.itemRate),s.param.gatherId=n.GF.LuaJsonToNumber(t.param.gatherId),
s.param.copyId=n.GF.LuaJsonToNumber(t.param.copyId),s.param.mapId=n.GF.LuaJsonToNumber(t.param.mapId),s.param.mallId=n.GF.LuaJsonToNumber(t.param.mallId),
s.param.currencyType=n.GF.LuaJsonToString(t.param.currencyType),s.param.equipmentType=n.GF.LuaJsonToString(t.param.equipmentType),
s.param.stepLv=n.GF.LuaJsonToNumber(t.param.stepLv),s.param.equipStepLv=n.GF.LuaJsonToNumber(t.param.equipStepLv),s.param.fly=n.GF.LuaJsonToString(t.param.fly),
s.param.equipType=n.GF.LuaJsonToString(t.param.equipType),s.param.questId=n.GF.LuaJsonToNumber(t.param.questId),s.param.questType=n.GF.LuaJsonToNumber(t.param.questType),
s.param.groupId=n.GF.LuaJsonToNumber(t.param.groupId),s.param.immortalsType=n.GF.LuaJsonToNumber(t.param.immortalsType),
s.param.composeTabs=n.GF.LuaJsonToNumber(t.param.composeTabs),s.param.num=n.GF.LuaJsonToNumber(t.param.num),s.param.x=n.GF.LuaJsonToNumber(t.param.x),
s.param.y=n.GF.LuaJsonToNumber(t.param.y),s.param.ids=n.GF.LuaJsonToString(t.param.ids),s.param.value=n.GF.LuaJsonToNumber(t.param.value),
s.param.suitlevel=n.GF.LuaJsonToNumber(t.param.suitlevel),s.param.suitType=n.GF.LuaJsonToNumber(t.param.suitType),s.param.prayType=n.GF.LuaJsonToNumber(t.param.prayType),
s.param.addLevel=n.GF.LuaJsonToNumber(t.param.addLevel),s.param.skillId=n.GF.LuaJsonToString(t.param.skillId),s.param.grade=n.GF.LuaJsonToNumber(t.param.grade),
s.param.itemGroupId=n.GF.LuaJsonToNumber(t.param.itemGroupId),s.param.star=n.GF.LuaJsonToNumber(t.param.star),s.param.transfer=n.GF.LuaJsonToNumber(t.param.transfer),
s.param.quality=n.GF.LuaJsonToNumber(t.param.quality),s.param.equipexcellencenum=n.GF.LuaJsonToNumber(t.param.equipexcellencenum),
s.param.excellentOrSuit=n.GF.LuaJsonToNumber(t.param.excellentOrSuit),s.param.equipexcellencetype=n.GF.LuaJsonToString(t.param.equipexcellencetype),
s.param.equipenhancelevel=n.GF.LuaJsonToNumber(t.param.equipenhancelevel),s.param.equipaddlevel=n.GF.LuaJsonToNumber(t.param.equipaddlevel),
s.param.gatherFlyId=n.GF.LuaJsonToNumber(t.param.gatherFlyId),s.param.gatherNextTask=n.GF.LuaJsonToNumber(t.param.gatherNextTask),
s.param.hideItemId=n.GF.LuaJsonToString(t.param.hideItemId),s.param.questionId=n.GF.LuaJsonToString(t.param.questionId),
s.param.transferPoint=n.GF.LuaJsonToString(t.param.transferPoint),s.param.multiAccess=n.GF.LuaJsonToString(t.param.multiAccess),
s.param.multiItem=n.GF.LuaJsonToNumber(t.param.multiItem),s.param.multiShowItem=n.GF.LuaJsonToString(t.param.multiShowItem),
s.param.recommond=n.GF.LuaJsonToNumber(t.param.recommond),s.param.group=n.GF.LuaJsonToNumber(t.param.group),s.param.dealChild=n.GF.LuaJsonToNumber(t.param.dealChild),
s.param.CONSIGN_SCORE=n.GF.LuaJsonToNumber(t.param.CONSIGN_SCORE),s.param.equipColumn=n.GF.LuaJsonToNumber(t.param.equipColumn),s.param.type=n.GF.LuaJsonToString(t.param.type),
s.param.skillType=n.GF.LuaJsonToNumber(t.param.skillType),s.param.talentId=n.GF.LuaJsonToNumber(t.param.talentId),s.param.langId=n.GF.LuaJsonToString(t.param.langId),
s.param.suggestHang=n.GF.LuaJsonToNumber(t.param.suggestHang),s.param.time=n.GF.LuaJsonToNumber(t.param.time),s.param.buttonIcon=n.GF.LuaJsonToString(t.param.buttonIcon),
s.param.isMiracleObj=n.GF.LuaJsonToNumber(t.param.isMiracleObj),s.param.UIId=n.GF.LuaJsonToNumber(t.param.UIID),
s.param.attrName=n.GF.LuaJsonToString(t.param.attrName)):s.param=null,this.tCTargetDefs.Add(s),i+=1}}static CreateFromJsonStr(t){return s.t.decode2(t,l.Z,C)}}},19519:(t,e,i)=>{
i.d(e,{J:()=>u})
var s=i(86133),n=i(98800),l=i(79534),a=i(84229),r=i(70850),o=i(89373),h=i(20886),d=i(43308),_=i(65550)
class u{static GetCurrencyIconUrl(t){let e=""
return t==u.GOLD_STR?e="atlas/common/rycommon_currency_0003":t==u.GOLD_DIAMOND_STR?e="atlas/common/rycommon_currency_0001":t==u.HonourStr?e="atlas/common/rycommon_currency_0004":t==u.SkillPointStr?e="atlas/common/rycommon_currency_0005":t==u.ScoreStr?e="atlas/common/rycommon_currency_0002":t==u.LotteryDragonStr?e="atlas/common/rycommon_currency_0012":t==u.LotteryItemStr?e="atlas/common/rycommon_currency_0008":t==u.VitalityNumStr?e="atlas/common/rycommon_currency_0006":t==u.ReputationStr?e="atlas/common/rycommon_currency_0002":t==u.SuitRecycleScoreStr?e="atlas/common/rycommon_currency_0017":t==u.ASURAM_TOKEN_STR?e="atlas/common/rycommon_currency_0024":t==u.AsuramFundStr?e="atlas/common/rycommon_currency_0011":t==u.AsuramMaterialStr?e="atlas/common/rycommon_currency_0023":t==u.FLAG_FRAGMENT_STR?e="atlas/common/rycommon_currency_0025":t==u.TREASURE_ID_ITEM_STR?e="atlas/common/rycommon_currency_0026":t==u.GUOQINGMALL_ID_ITEM_STR?e="atlas/common/rycommon_currency_0027":t==u.BAIRIMALL_ID_ITEM_STR?e="atlas/common/rycommon_currency_0028":t==u.HONOUR_POINT_STR?e="atlas/common/rycommon_currency_0030":t==u.SHUANGDANMALL_ITEM_STR?e="atlas/common/rycommon_currency_0031":t==u.EXP_STR?e="atlas/common/rycommon_currency_0007":t==u.HONOR_MANUAL_POINT?e="atlas/common/rycommon_currency_0034":t==u.FORTUNE_POINT?e="atlas/common/rycommon_sp_0214":t==u.MAYA_HUNT_COUPON?e="atlas/common/rycommon_sp_0215":t==u.MAYA_HUNT_SCORE?e="atlas/common/rycommon_sp_0213":t==u.RYALLIANCE_BUILDPOINT?e="atlas/common/rycommon_currency_0036":t==u.RYALLIANCE_TECMONEY?e="atlas/common/rycommon_currency_0035":t==u.TREASURES?e="atlas/common/rycommon_currency_00030":t==u.STAR_SKY_ITEM?e="atlas/common/rycommon_currency_0004":t==u.GOLD_DIAMOND_LIMIT_STR&&(e="atlas/common/rycommon_sp_0230"),
e}static GetCurrencyIconName(t){let e=""
return t==u.GOLD?e="atlas/common/rycommon_currency_0003":t==u.GOLD_DIAMOND?e="atlas/common/rycommon_currency_0001":t==u.Honour?e="atlas/common/rycommon_currency_0004":t==u.SkillPoint?e="atlas/common/rycommon_currency_0005":t==u.Score?e="atlas/common/rycommon_currency_0002":t==u.LotteryDragon?e="atlas/common/rycommon_currency_0012":t==u.LotteryItem?e="atlas/common/rycommon_currency_0008":t==u.VitalityNum?e="atlas/common/rycommon_currency_0006":t==u.ReputationPoint?e="atlas/common/rycommon_currency_0002":t==u.SuitRecycleScore?e="atlas/common/rycommon_currency_0017":t==u.AsuramFund?e="atlas/common/rycommon_currency_0011":t==u.AsuramMaterial?e="atlas/common/rycommon_currency_0023":t==u.ASURAM_TOKEN?e="atlas/common/rycommon_currency_0024":t==u.TREASURE_ID_ITEM?e="atlas/common/rycommon_currency_0026":t==u.HONOUR_POINT?e="atlas/common/rycommon_currency_0030":t==u.HONORSHOP_POINT?e="atlas/common/rycommon_currency_0034":t==u.RyAllianceBuildPoint?e="atlas/common/rycommon_currency_0036":t==u.RyAllianceTecMoney?e="atlas/common/rycommon_currency_0035":t==u.STAR_SKY_ITEM?e="atlas/common/rycommon_currency_0004":(t==u.GOLD_DIAMOND_LIMIT||t==u.GOLD_DIAMOND_LIMIT_STR)&&(e="atlas/common/rycommon_sp_0230"),
e}static GetCurrencyStr(t){let e=""
return t==u.GOLD_STR?e=(0,s.T)("金币"):t==u.GOLD_DIAMOND_STR?e=(0,s.T)("钻石"):t==u.GOLD_DIAMOND_LIMIT_STR?e=(0,s.T)("限时钻石"):t==u.HonourStr?e=(0,s.T)("荣誉值"):t==u.SkillPointStr?e=(0,
s.T)("技能点"):t==u.ScoreStr?e=(0,s.T)("积分"):t==u.LotteryDragonStr?e=(0,s.T)("寻宝龙鳞"):t==u.ALLIANCE_FUND_STR?e=(0,s.T)("战盟资金"):t==u.LotteryItemStr?e=(0,
s.T)("寻宝令"):t==u.VitalityNumStr?e=(0,s.T)("活跃度"):t==u.ReputationStr?e=(0,s.T)("战盟贡献"):t==u.SuitRecycleScoreStr?e=(0,s.T)("粉尘"):t==u.RYALLIANCE_TECMONEY?e=(0,
s.T)("战盟资金"):t==u.RYALLIANCE_BUILDPOINT?e=(0,s.T)("战盟建筑值"):t==u.GoblinVitality?e=(0,s.T)("护送体力"):t==u.ASURAM_TOKEN_STR?e=(0,s.T)("令牌"):t==u.FLAG_FRAGMENT_STR?e=(0,
s.T)("旗帜碎片"):t==u.TREASURE_ID_ITEM_STR?e=(0,s.T)("鉴宝券"):t==u.GUOQINGMALL_ID_ITEM_STR?e=(0,s.T)("狂欢旗帜"):t==u.BAIRIMALL_ID_ITEM_STR?e=(0,s.T)("百日纪念币"):t==u.HONOUR_POINT_STR?e=(0,
s.T)("荣誉点"):t==u.SHUANGDANMALL_ITEM_STR?e=(0,s.T)("双旦兑奖券"):t==u.HONOR_MANUAL_POINT?e=(0,s.T)("荣耀值"):t==u.THEME_SCORE?e=(0,s.T)("主题积分"):t==u.TREASURES&&(e=(0,s.T)("荣耀通宝")),e}
static GetGold(t,e,i=!0){let s=t.Gold_get()
if(e==u.GOLD)s=t.Gold_get()
else if(e==u.GOLD_DIAMOND)s=t.Gold_Diamond_get(),i&&(s+=t.Gold_Diamond_Limit_get())
else if(e==u.GOLD_DIAMOND_LIMIT)s=t.Gold_Diamond_Limit_get()
else if(e==u.GOLD_STR)s=t.Gold_get()
else if(e==u.ReputationPoint)s=t.ReputationPoint_get()
else if(e==u.GOLD_DIAMOND_STR)s=t.Gold_Diamond_get(),i&&(s+=t.Gold_Diamond_Limit_get())
else if(e==u.GOLD_DIAMOND_LIMIT_STR)s=t.Gold_Diamond_Limit_get()
else if(e==u.HonourStr)s=t.Honour_get()
else if(e==u.SkillPointStr)s=t.Skill_Point_get()
else if(e==u.ScoreStr)s=t.Sonsign_Score_get()
else if(e==u.VitalityNumStr)s=t.VitalityNum_get()
else if(e==u.ReputationStr)s=t.ReputationPoint_get()
else if(e==u.HONOUR_POINT_STR)s=t.Honour_Point_get()
else if(e==u.SuitRecycleScoreStr)s=t.SuitRecycle_Score_get()
else if(e==u.RYALLIANCE_BUILDPOINT)s=a.Q.Inst_get().curCanUseAsuramMoney
else if(e==u.RYALLIANCE_TECMONEY)s=a.Q.Inst_get().curTecMoney
else if(e==u.ASURAM_TOKEN_STR)s=t.AsuramToken_get()
else if(e==u.FLAG_FRAGMENT_STR)s=r.g.Inst_get().GetItemNum(h.v.FLAGFRAGMENT_ID)
else if(e==u.HONORSHOP_POINT)s=t.HonourShop_Point_get()
else if(e==u.HONOR_MANUAL_POINT)s=t.HonourShop_Point_get()
else if(e==u.FORTUNE_POINT)s=FortuneTreasureModel.Inst_get().GetPoint()
else if(e==u.MAYA_HUNT_COUPON){const t=o.X.Inst_get().GetHuntItemId()
s=r.g.Inst_get().GetItemNum(t)
}else e==u.MAYA_HUNT_SCORE?s=o.X.Inst_get().GetScore():e==u.TREASURES?s=t.Treasure_get():e==u.STAR_SKY_ITEM&&(s=r.g.Inst_get().GetItemNum(h.v.STAR_SKY_ITEM))
return s}static GetCurrencyVal(t,e,i){i&&(i=!0)
let s=t.Gold_get()
return e==u.GOLD?s=t.Gold_get():e==u.GOLD_DIAMOND?(s=t.Gold_Diamond_get(),i&&(s+=t.Gold_Diamond_Limit_get())):e==u.GOLD_DIAMOND_LIMIT?s=t.Gold_Diamond_Limit_get():e==u.Honour?s=t.Honour_get():e==u.SkillPoint?s=t.Skill_Point_get():e==u.Score?s=t.Sonsign_Score_get():e==u.VitalityNum?s=t.VitalityNum_get():e==u.HONOUR_POINT?s=t.Honour_Point_get():e==u.ReputationPoint?s=t.ReputationPoint_get():e==u.SuitRecycleScore?s=t.SuitRecycle_Score_get():e==u.RyAllianceBuildPoint?s=a.Q.Inst_get().curCanUseAsuramMoney:e==u.RyAllianceTecMoney?s=a.Q.Inst_get().curTecMoney:e==u.ASURAM_TOKEN?s=t.AsuramToken_get():e==u.HONORSHOP_POINT?s=t.HonourShop_Point_get():currencytype==u.TREASURES&&(s=t.Treasure_get()),
s}static GetItemID(t){let e=0
return t==u.GOLD?e=h.v.GOLD_ID:t==u.GOLD_DIAMOND?e=h.v.DIAMOND_ID:t==u.GOLD_DIAMOND_LIMIT?e=h.v.DIAMOND_LIMIT_ID:t==u.GOLD_STR?e=h.v.GOLD_ID:t==u.ScoreStr?e=h.v.SCORE_ID:t==u.HonourStr?e=h.v.HONOUR_ID:t==u.SkillPointStr?e=h.v.SPPOINT_ID:t==u.VitalityNumStr?e=h.v.VITALITY_ID:t==u.ReputationStr?e=h.v.ASURAMCONTRI_ID:t==u.RYALLIANCE_BUILDPOINT?e=h.v.RYALLIANCE_BUILDPOINT_ID:t==u.RYALLIANCE_TECMONEY?e=h.v.RYALLIANCE_TECMONEY_ID:t==u.ASURAM_TOKEN_STR?e=h.v.ASURAMTOKEN_ID:t==u.FLAG_FRAGMENT_STR?e=h.v.FLAGFRAGMENT_ID:t==u.GOLD_DIAMOND_STR?e=h.v.DIAMOND_ID:t==u.GOLD_DIAMOND_LIMIT_STR?e=h.v.DIAMOND_LIMIT_ID:t==u.HONOUR_POINT_STR?e=h.v.HONOUR_POINT_ID:t==u.REBIRTH_QUEST_POINT?e=h.v.REBIRTH_POINT_ID:t==u.FORTUNE_POINT?e=h.v.FORTUNE_POINT_ID:t==u.MAYA_HUNT_COUPON?e=h.v.MAYA_HUNT_COUPON_ID:t==u.MAYA_HUNT_SCORE?e=h.v.MAYA_HUNT_SCORE_ID:t==u.THEME_SCORE?e=h.v.THEME_SCORE:t==u.TREASURES&&(e=h.v.TREASURES),
e}static IsMoneyEnough(t,e,i){null==i&&(i=n.Y.Inst.PrimaryRoleInfo_get())
return u.GetGold(i,t)>=e}static TypeConvertToStr(t){return t==u.GOLD_DIAMOND?u.GOLD_DIAMOND_STR:t==u.GOLD_DIAMOND_LIMIT?u.GOLD_DIAMOND_LIMIT_STR:null}static TypeConvertToInt(t){
return"GOLD"==t?u.GOLD:"GOLD_DIAMOND"==t?u.GOLD_DIAMOND:t==u.GOLD_DIAMOND_LIMIT_STR?u.GOLD_DIAMOND_LIMIT:t==u.HonourStr?u.Honour:t==u.SkillPointStr?u.SkillPoint:t==u.ScoreStr?u.Score:t==u.LotteryDragonStr?u.LotteryDragon:t==u.LotteryItemStr?u.LotteryItem:t==u.VitalityNumStr?u.VitalityNum:t==u.ReputationStr?u.ReputationPoint:t==u.SuitRecycleScoreStr?u.SuitRecycleScore:t==u.RYALLIANCE_BUILDPOINT?u.RyAllianceBuildPoint:t==u.RYALLIANCE_TECMONEY?u.RyAllianceTecMoney:t==u.ASURAM_TOKEN_STR?u.ASURAM_TOKEN:t==u.TREASURE_ID_ITEM_STR?u.TREASURE_ID_ITEM:t==u.HONOUR_POINT_STR?u.HONOUR_POINT:t==u.HONOR_MANUAL_POINT?u.HONORSHOP_POINT:t==u.TREASURES?u.TREASURES:0
}static OpenSupplyCurrencyViewByTypeStr(t){const e=u.TypeConvertToInt(t)
u.OpenSupplyCurrencyViewByType(e)}static OpenSupplyCurrencyViewByType(t){const e=l.P.zero_get()
t==u.GOLD?d._.Inst_get().OpenByCurrency(u.GOLD_STR,e):t==u.GOLD_DIAMOND?AccessDiamondtipControl.Inst_get().Open():t==u.GOLD_DIAMOND_LIMIT?d._.Inst_get().OpenByCurrency(u.GOLD_DIAMOND_LIMIT_STR,e):t==u.Honour?d._.Inst_get().OpenByCurrency(u.HonourStr,e):t==u.SkillPoint?d._.Inst_get().OpenByCurrency(u.SkillPointStr,e):t==u.Score?d._.Inst_get().OpenByCurrency(u.ScoreStr,e):t==u.LotteryDragon?_.y.inst.ClientSysMessage(140002):t==u.RyAllianceBuildPoint?d._.Inst_get().OpenByCurrency(u.RYALLIANCE_BUILDPOINT,e):t==u.RyAllianceTecMoney?d._.Inst_get().OpenByCurrency(u.RYALLIANCE_TECMONEY,e):t==u.ASURAM_TOKEN?d._.Inst_get().OpenByCurrency(u.ASURAM_TOKEN_STR,e):t==u.HONOUR_POINT&&d._.Inst_get().OpenByItem(h.v.HONOUR_POINT_ID,e),
l.P.Recyle(e)}static JudgeConsumeScore(t,e,i){if(null!=n.Y.Inst.PrimaryRoleInfo_get()){n.Y.Inst.PrimaryRoleInfo_get().Sonsign_Score_get()<t&&u.OpenSupplyCurrencyViewByType(u.Score)
}}}u.GOLD=1,u.GOLD_DIAMOND=2,u.Honour=5,u.SkillPoint=6,u.Score=7,u.AllianceDonate=8,u.LotteryDragon=9,u.LotteryItem=10,u.VitalityNum=13,u.ReputationPoint=15,u.SuitRecycleScore=16,
u.ASURAM_TOKEN=17,u.HONOUR_POINT=18,u.HONORSHOP_POINT=19,u.AsuramFund=100,u.AsuramMaterial=101,u.FLAG_FRAGMENT=102,u.TREASURE_ID_ITEM=103,u.RyAllianceBuildPoint=104,
u.RyAllianceTecMoney=105,u.GOLD_DIAMOND_LIMIT=106,u.ScoreStr="CONSIGN_SCORE",u.GOLD_STR="GOLD",u.GOLD_DIAMOND_STR="GOLD_DIAMOND",u.GOLD_DIAMOND_LIMIT_STR="LIMITEDDIAMOND",
u.ALLIANCE_FUND_STR="ALLIANCE_FUND_STR",u.HonourStr="HONOUR",u.SkillPointStr="SKILL_POINT",u.AsuramContributionStr="ASURAM_CONTRIBUTION",u.LotteryDragonStr="LotteryDragon",
u.LotteryItemStr="LotteryItem",u.VitalityNumStr="VITALITY_NUM",u.ReputationStr="REPUTATION",u.SuitRecycleScoreStr="SUIT_ITEM_SCORE",u.GoblinVitality="GoblinVitality",
u.ASURAM_TOKEN_STR="ASURAM_TOKEN",u.AsuramFundStr="ASURAM_FUND",u.AsuramMaterialStr="ASURAM_MATERIAL",u.FLAG_FRAGMENT_STR="FLAG_FRAGMENT",
u.TREASURE_ID_ITEM_STR="TREASURE_ID_ITEM_STR",u.GUOQINGMALL_ID_ITEM_STR="GUOQINGMALL_ID_ITEM_STR",u.BAIRIMALL_ID_ITEM_STR="BAIRIMALL_ID_ITEM_STR",u.HONOUR_POINT_STR="HONOR_POINT",
u.SHUANGDANMALL_ITEM_STR="SHUANGDANMALL_ITEM_STR",u.EXP_STR="EXP_STR",u.REBIRTH_QUEST_POINT="REBIRTH_QUEST_POINT",u.HONOR_MANUAL_POINT="HONOR_MANUAL_POINT",
u.FORTUNE_POINT="FORTUNE_POINT",u.MAYA_HUNT_COUPON="MAYA_HUNT_COUPON",u.MAYA_HUNT_SCORE="MAYA_HUNT_SCORE",u.RYALLIANCE_BUILDPOINT="RYALLIANCE_BUILDPOINT",
u.RYALLIANCE_TECMONEY="RYALLIANCE_TECMONEY",u.THEME_SCORE="THEME_SCORE",u.TREASURES="TREASURES",u.STAR_SKY_ITEM="STAR_SKY_ITEM",u.GLORY_CALL_ITEM="GLORY_CALL_ITEM",
u.CELEBRATE_ITEM="CELEBRATE_ITEM"},68214:(t,e,i)=>{i.d(e,{a:()=>l})
var s=i(85602),n=i(87923)
class l{constructor(){this.txtStr=null,this.linkStr=null,this.progresStr=null,this.replaceStr=null,this.prohangeLine=-1,this.targetOriginalStr="",this.progresOriginalStr="",
this.progresIndex=0,this.progresColor=""}static GetInst(){if(0==l._pools.Count())return new l
const t=l._pools[0]
return l._pools.RemoveAt(0),t.prohangeLine=-1,t}AddItem(t,e,i,s,n){this.txtStr=t,this.linkStr=e,this.progresStr=i,this.progresIndex=null==s?0:s,this.progresColor=null==n?"":n}
SetTxtLabel(t){n.l.IsEmptyStr(this.txtStr)&&(this.txtStr=""),n.l.IsEmptyStr(this.replaceStr)?t.textSet(this.txtStr):t.textSet(this.replaceStr)}GetTxtLabel(){
if(n.l.IsEmptyStr(this.txtStr)&&(this.txtStr=""),!n.l.IsEmptyStr(this.replaceStr))return this.replaceStr
let t=this.txtStr
return t&&(t=t.replace(l.urlReg,"")),t}SetProgressLabel(t){if(!n.l.IsEmptyStr(this.replaceStr))return void t.textSet("")
n.l.IsEmptyStr(this.progresStr)&&(this.progresStr="")
let e=this.progresStr
n.l.IsEmptyStr(e)||(e=`(${e})`),t.textSet(e)}GetProgressLabel(){if(!n.l.IsEmptyStr(this.replaceStr))return""
n.l.IsEmptyStr(this.progresStr)&&(this.progresStr="")
let t=this.progresStr
return t&&(t=t.replace(l.urlReg,"")),n.l.IsEmptyStr(t)||(t=`(${t})`),""!=this.progresColor&&(t=`[${this.progresColor}]${t}[-]`),t}Clear(){l._pools.Add(this)}}
l.urlReg=/\[[/]*ur[^\[\]]+\]/g,l._pools=new s.Z},74657:(t,e,i)=>{i.d(e,{A:()=>y})
var s=i(93984),n=i(38836),l=i(86133),a=i(66788),r=i(55360),o=i(85602),h=i(38962),d=i(63076),_=i(98800),u=i(90419),I=i(50089),c=i(62370),g=i(70829),p=i(98885),m=i(1240),S=i(33314),T=i(37648),f=i(48481),C=i(98394),E=i(23296),A=i(28359)
class L{constructor(t){this._resource=null,this._resourcevalue=null,this.bountyRewardCfg=null,this.awardType=1,this.awardStep=1,this._rValues=null,this.expList=null,
this.currencyList=null,this.itemList=null,this.runeItemList=null,this.attrBagItemList=null,this.AsuramBuildItemList=null,this.noSortRewardList=null,this.isAnalysise=!1,
this.rewardList=null,this.baseItemRewardList=null,this.skillList=null,this.noSortRewardList=new o.Z,this._resource=t}SetResourceStr(t){this._resourcevalue=t}resourceValue_get(){
return null!=this._resource?this._resource.value:this._resourcevalue}IsEmpty(){return 0==this.rewardValues_get().rewardValues.Count()}rewardValues_get(){if(null==this._rValues){
const t=u.d.parseJsonObjectWithFix(this.resourceValue_get(),"rewardValues")
this._rValues=I.t.decode(t,A.h),this._rValues.Parse()}return this._rValues}GetRewardItemList(){if(null==this.rewardList){this.AnalysiseList(),this.rewardList=new o.Z
let t=null,e=0
if(null!=this.expList){e=this.expList.Count()
let i=0
for(;i<e;)t=this.expList[i],this.rewardList.Add(t),i+=1}if(null!=this.currencyList){e=this.currencyList.Count()
let i=0
for(;i<e;)t=this.currencyList[i],this.rewardList.Add(t),i+=1}if(null!=this.itemList){e=this.itemList.Count()
let t=0
for(;t<e;){const e=this.itemList[t]
this.rewardList.Add(e),t+=1}}}return this.rewardList}GetRewardBaseItemList(){if(null==this.baseItemRewardList){this.AnalysiseList(),this.baseItemRewardList=new o.Z
let t=null,e=0
if(null!=this.expList){e=this.expList.Count()
let i=0
for(;i<e;)t=this.expList[i],this.baseItemRewardList.Add(t),i+=1}if(null!=this.currencyList){e=this.currencyList.Count()
let i=0
for(;i<e;)t=this.currencyList[i],this.baseItemRewardList.Add(t),i+=1}if(null!=this.itemList){e=this.itemList.Count()
let t=0
for(;t<e;){const e=this.itemList[t]
e.baseData_get().isNoBagItemData=!0,this.baseItemRewardList.Add(e.baseData_get()),t+=1}}}return this.baseItemRewardList}GetSkillList(){
return null==this.skillList&&(this.skillList=new o.Z,this.AnalysiseList()),this.skillList}GeCurrencyReward(){return null==this.currencyList&&this.AnalysiseList(),this.currencyList}
GetGoldReward(){let t=0
if(null==this.currencyList&&this.AnalysiseList(),null!=this.currencyList)for(const[e,i]of(0,
n.V5)(this.currencyList))null!=i.virtualItemData_get()&&i.virtualItemData_get().virtualType==C.d.GOLD&&(t+=i.virtualItemData_get().virtualValue.ToNum())
return t}GetExpReward(){let t=0
if(null==this.expList&&this.AnalysiseList(),null!=this.expList)for(const[e,i]of(0,
n.V5)(this.expList))i.virtualItemData_get().virtualType==C.d.EXP&&(t+=i.virtualItemData_get().virtualValue.ToNum())
return t}GetSkillPointReward(){let t=0
null==this.currencyList&&this.AnalysiseList()
for(const[e,i]of(0,n.V5)(this.currencyList))i.virtualItemData_get().virtualType==C.d.SkillPoint&&(t+=i.virtualItemData_get().virtualValue.ToNum())
return t}GetAttrBagItemList(){this.AnalysiseList()
const t=new o.Z
if(null!=this.attrBagItemList)for(const[e,i]of(0,n.V5)(this.attrBagItemList))i.baseData_get().isNoBagItemData=!1,t.Add(i)
return t}AnalysiseList(){if(!this.isAnalysise){this.isAnalysise=!0
let t=_.Y.Inst.PrimaryRoleInfo_get().Job_get()
t=S.Z.GetJobBaseValue(t)
const e=this.rewardValues_get().rewardValues
let i=0
for(;i<e.Count();){const s=e[i]
if(s.jobValue_get()==S.Z.NONE||s.jobValue_get()==t)if(s.type==E.E.EXP)null==this.expList&&(this.expList=new o.Z),this.expList.Add(s.expitem_get()),
this.noSortRewardList.Add(s.expitem_get())
else if(s.type==E.E.Currency)null==this.currencyList&&(this.currencyList=new o.Z),this.currencyList.Add(s.currencyItem_get()),this.noSortRewardList.Add(s.currencyItem_get())
else if(s.type==E.E.Attr)null==this.attrBagItemList&&(this.attrBagItemList=new o.Z),this.attrBagItemList.Add(s.attrBagItem_get()),
this.noSortRewardList.Add(s.attrBagItem_get().baseData_get())
else if(s.type==E.E.ASURAM_BUILDING_POINT)null==this.AsuramBuildItemList&&(this.AsuramBuildItemList=new o.Z),this.AsuramBuildItemList.Add(s.AsuramBuildItem_get()),
this.noSortRewardList.Add(s.AsuramBuildItem_get())
else if(s.type==E.E.Item){const t=s.baseItem_get().modelId_get()
T.P.Inst_get().IsFunOpenByItemId(t)&&(null==this.itemList&&(this.itemList=new o.Z),this.itemList.Add(s.bagItem_get()),this.noSortRewardList.Add(s.bagItem_get().baseData_get()))
}else if(s.type==E.E.RuneItem)null==this.runeItemList&&(this.runeItemList=new o.Z),this.runeItemList.Add(s.bagItem_get()),this.noSortRewardList.Add(s.bagItem_get().baseData_get())
else if(s.type==E.E.AsuramContribution){null==this.itemList&&(this.itemList=new o.Z)
const t=new f.t
t.modelId=10206,t.num=s.asuramContribution_get()
const e=new m.Y
e.serverData_set(t),this.itemList.Add(e),this.noSortRewardList.Add(e.baseData_get())}else if(s.type==E.E.Courage){null==this.itemList&&(this.itemList=new o.Z)
const t=new f.t
t.modelId=10206,t.num=s.courage_get()
const e=new m.Y
e.serverData_set(t),this.itemList.Add(e),this.noSortRewardList.Add(e.baseData_get())}else if(s.type==E.E.Skill){null==this.skillList&&(this.skillList=new o.Z)
const t=s.Skilldata_get(),e=p.M.Split(t.value,c.o.s_Arr_UNDER_COLON),i=g.j.Inst().GetSkillByIdLevel(p.M.String2Int(e[0]),p.M.String2Int(e[1]))
this.skillList.Add(i)}else if(s.type==E.E.Title){const t=s.baseItem_get().modelId_get()
T.P.Inst_get().IsFunOpenByItemId(t)&&(null==this.itemList&&(this.itemList=new o.Z),this.itemList.Add(s.bagItem_get()),this.noSortRewardList.Add(s.bagItem_get().baseData_get()))}
i+=1}}}GetJobLimitItemList(){const t=this.rewardValues_get().rewardValues,e=new o.Z
let i=0
for(;i<t.Count();){const s=t[i]
if(null==s.jobBranchsLimit_get())e.Add(s.GetItemDataByType())
else{const t=s.jobBranchsLimit_get()[0]-1
if(null!=_.Y.Inst.primaryRoleInfoList[t]){const i=s.jobBranchsLimit_get()[1]
let n=_.Y.Inst.primaryRoleInfoList[t].Job_get()
n=S.Z.GetJobBaseValue(n),n==i&&e.Add(s.GetItemDataByType())}}i+=1}return e}GetNoSortAllRewards(){return this.AnalysiseList(),this.noSortRewardList}GetRealItemList(){
this.AnalysiseList()
const t=new o.Z
if(null!=this.itemList){let e=null,i=0
for(;i<this.itemList.Count();)e=this.itemList[i],e.baseData_get().isNoBagItemData=!1,null==e.baseData_get().virtualItemData_get()&&t.Add(e),i+=1}if(null!=this.runeItemList){
let e=null,i=0
for(;i<this.runeItemList.Count();)e=this.runeItemList[i],e.baseData_get().isNoBagItemData=!1,null==e.baseData_get().virtualItemData_get()&&t.Add(e),i+=1}return t}GetItemList(){
this.AnalysiseList()
const t=new o.Z
if(null!=this.itemList){let e=null,i=0
for(;i<this.itemList.Count();)e=this.itemList[i],e.baseData_get().isNoBagItemData=!1,t.Add(e),i+=1}if(null!=this.runeItemList){let e=null,i=0
for(;i<this.runeItemList.Count();)e=this.runeItemList[i],e.baseData_get().isNoBagItemData=!1,t.Add(e),i+=1}return t}GetBaseItemList(){this.AnalysiseList()
const t=new o.Z
if(null!=this.itemList){let e=null,i=0
for(;i<this.itemList.Count();)e=this.itemList[i],e.baseData_get().isNoBagItemData=!0,t.Add(e.baseData_get()),i+=1}if(null!=this.runeItemList){let e=null,i=0
for(;i<this.runeItemList.Count();)e=this.runeItemList[i],e.baseData_get().isNoBagItemData=!0,t.Add(e.baseData_get()),i+=1}return t}GetVirtualItemList(){this.AnalysiseList()
const t=new o.Z
let e=null
if(null!=this.expList){let i=0
for(;i<this.expList.Count();)e=this.expList[i],t.Add(e),i+=1}if(null!=this.currencyList){let i=0
for(;i<this.currencyList.Count();)e=this.currencyList[i],t.Add(e),i+=1}return this.SortVirtualItems(t),t}SortVirtualItems(t){let e=1
for(;e<t.Count();){let i=e+1
for(;i<t.Count();){let s=t[e],n=t[i]
if(this.GetVirtualItemSortLevel(s.virtualItemData_get())<this.GetVirtualItemSortLevel(n.virtualItemData_get())){const t=s
s=n,n=t}i+=1}e+=1}}GetVirtualItemSortLevel(t){let e=0
return t.virtualType==C.d.EXP?e=1:t.virtualType==C.d.GOLD?e=2:t.virtualType==C.d.SkillPoint?e=3:t.virtualType==C.d.Honour?e=4:t.virtualType==C.d.Score?e=5:t.virtualType==C.d.DIAMOND&&(e=6),
e}GetAllRewardList(){const t=new o.Z
this.AnalysiseList()
let e=0
for(;e<this.noSortRewardList.Count();)this.noSortRewardList[e].isNoBagItemData=!0,t.Add(this.noSortRewardList[e]),e+=1
return t}Reset(){this.isAnalysise=!1,this.expList=null,this.currencyList=null,this.attrBagItemList=null,this.itemList=null,this.runeItemList=null,this.skillList=null,
this.noSortRewardList.Clear(),null!=this.rewardList&&(this.rewardList.Clear(),this.rewardList=null),null!=this.baseItemRewardList&&(this.baseItemRewardList.Clear(),
this.baseItemRewardList=null)}}class y{constructor(){this._map=null
const t=r.Y.Inst.GetOrCreateCsv(s.h.eRewardResource).GetCsvMap()
this._map=new h.X
for(const[e,i]of(0,n.V5)(t))this._map.LuaDic_AddOrSetItem(i.id,new L(i))}static GetReward(t){return null==y._inst&&(y._inst=new y),
y._inst._map.LuaDic_ContainsKey(t)?y._inst._map[t]:("0"!=t&&""!=t&&null!=t&&a.Y.LogError((0,l.T)("REWARDRESOURCE表找不到ID：")+t),null)}GetRewardByAnrewardList(t,e){null==e&&(e=new o.Z)
for(let i=0;i<=t.Count()-1;i++){const s=d.M.wrapReward(t[i])
e.Add(s)}return e}}y._inst=null},54918:(t,e,i)=>{i.d(e,{Q:()=>I})
var s=i(38836),n=i(38045),l=i(62370),a=i(98885),r=i(85602),o=i(70850),h=i(75439),d=i(56614),_=i(17783),u=i(63412)
class I{constructor(){this.questDataList=null,this.targetItemId=null,this.skillBagData=null,this.isCommonCopyLeave=!1,this.restoreHangState=!1,this.test=!1,this.respondLimitTime=0,
this.countdownTime=0,this.delayHangTime=0,this.commonCopyTypeList=null,this.questDataList=new r.Z,this.commonCopyTypeList=new r.Z}static Inst_get(){
return null==I.inst&&(I.inst=new I),I.inst}RespondLimitTime_get(){if(0==this.respondLimitTime){const t=h.D.getInstance().getContent("QUEST:SPECIAL_UI_SHOW_TIME").getContent()
this.respondLimitTime=a.M.String2Int(t.stringVal)}return this.respondLimitTime}CountdownTime_get(){if(0==this.countdownTime){
const t=h.D.getInstance().getContent("QUEST:SPECIAL_CLICK_CONTINUE").getContent()
this.countdownTime=a.M.String2Int(t.stringVal)/1e3}return this.countdownTime}DelayHangTime_get(){if(0==this.delayHangTime){
const t=h.D.getInstance().getContent("QUEST:SPECIAL_DELAY_HANGON").getContent()
this.delayHangTime=a.M.String2Int(t.stringVal)}return this.delayHangTime}CommonCopyTypeList_get(){if(0==this.commonCopyTypeList.Count()){
const t=h.D.getInstance().getContent("QUEST:SPECIAL_COPY_HANDLE").getContent(),e=a.M.Split(t.stringVal,a.M.s_SPAN_CHAR_DOT)
let i=0
for(;i<e.count;)this.commonCopyTypeList.Add(a.M.String2Int(e[i])),i+=1}return this.commonCopyTypeList}ShowSpecialTaskEffect(t){let e=0
for(;e<this.questDataList.Count();){if(this.questDataList[e].questId==t)return!0
e+=1}return!1}ResetTaskId(t){let e=0
for(;e<this.questDataList.Count();)this.questDataList[e].questId==t&&(this.questDataList[e].questId=0),e+=1}HasSkillItem(t){const e=o.g.Inst_get().GetBagDataList()
let i=!1
for(const[n,l]of(0,s.V5)(e))if(null!=l.baseData_get()&&null!=l.baseData_get().serverData_get()&&l.baseData_get().cfgData_get().GetRewardsSkillId()==t){this.skillBagData=l,i=!0
break}return i}IsSpecialTaskItem(t){let e=0
for(;e<this.questDataList.Count();){if(this.questDataList[e].item.id.Equal(t.id))return!0
e+=1}const i=_.L.Inst_get().model
for(const[e,o]of(0,s.V5)(i.SingleTaskList)){const e=o
if(e.resource_get().receiveType==u.U.RECEIVE_GET_ITEM){const i=a.M.Split(e.resource_get().receiveValue,l.o.s_UNDER_COLON)
if(i.count>0){const e=a.M.String2Int(i[0])
if((0,n.t2)(t,d.I)){if(i.count>=3){const s=t,n=a.M.String2Int(i[1]),l=a.M.String2Int(i[2])
if(s.modelId==e&&s.Enhancelevel_get()>=n&&s.EquipmentAdd_get()>=l)return!0}}else if(t.modelId==e)return!0}r.Z.Recyle(i)}}return!1}IsOpenSpecialTaskViewCopy(t){
return this.CommonCopyTypeList_get().IndexOf(t,0)<0}ResetModel(){this.questDataList.Clear(),this.targetItemId=null,this.skillBagData=null,this.isCommonCopyLeave=!1}}I.inst=null},
99535:(t,e,i)=>{i.d(e,{O:()=>Dt})
var s=i(42292),n=i(93984),l=i(38836),a=i(98800),r=i(66107),o=i(96098),h=i(93701),d=i(97461),_=i(54967),u=i(62370),I=i(66788),c=i(5468),g=i(55360),p=i(98885),m=i(85602),S=i(38962),T=i(79534),f=i(21554),C=i(54415),E=i(92679),A=i(29839),L=i(27001),y=i(67996),D=i(75439),O=i(14792),R=i(62734),N=i(60647),M=i(13487),w=i(97943),P=i(12970),v=i(47963),k=i(38045),U=i(61033),G=i(90419),F=i(50089),B=i(85682),H=i(5494),V=i(70850),b=i(97331),x=i(77477),q=i(77845),Y=i(87923),K=i(46749),J=i(35259),Q=i(62783),Z=i(89803),X=i(84458),$=i(79878),W=i(17783)
class j{constructor(){this.CloseUIList=null,this._degf_ClosePanelHandler=null,this._degf_ClosePanelHandler=t=>this.ClosePanelHandler(t)}static Inst_get(){
return null==j._mInst&&(j._mInst=new j),j._mInst}HandleTaskType(t){const e=W.L.Inst_get().model.GetConfig(t.questId,t.playerId),i=e.tCTargetDefs_get()
if(null!=i.tCTargetDefs&&i.tCTargetDefs.Count()>0)for(let s=0;s<=i.tCTargetDefs.Count()-1;s++){const n=i.tCTargetDefs[s]
n.type==Z.d.CLOSE_UI?(null==this.CloseUIList&&(this.CloseUIList=new S.X),this.CloseUIList.LuaDic_ContainsKey(t.questId)?this.CloseUIList[t.questId]=e:this.CloseUIList.LuaDic_Add(t.questId,e),
d.i.Inst.AddEventHandler(E.g.CLOSE_ONE_PANEL,this._degf_ClosePanelHandler)):n.type==Z.d.ENTER_MAP&&(Q.X.inst.TaskOpenMap=n.param.mapId)}}ClosePanelHandler(t){
const e=this.TransferUI(t)
if(0==e)return
for(const[t,i]of(0,l.vy)(this.CloseUIList)){e==i.tCTargetDefs_get().tCTargetDefs[0].param.UIId&&(this.CloseUIList.LuaDic_Remove(t),W.L.Inst_get().mgr.SendCloseUI(e))}
this.CloseUIList.LuaDic_Count()<=0&&d.i.Inst.RemoveEventHandler(E.g.CLOSE_ONE_PANEL,this._degf_ClosePanelHandler)}TransferUI(t){
return t==H.I.eSkillPanel?B.D.ProSkill:t==H.I.eBagPanel?B.D.Bag:0}HandleAttrFlyInfo(t,e,i,s){
const n=D.D.getInstance().getContent("ADDATTR:SKILL_QUEST_TEXT").getContent().stringVal,l=p.M.Split(n,";"),r=p.M.Split(l[0],"_"),o=r[0]
let h=-1
r.Count()>1&&(h=r[1])
const d=p.M.Split(l[1],"_"),_=d[0],u=d[1]
s.value_get()
let c=0,g=""
const S=a.Y.Inst.GetPlayerInfoById(t.qVo.playerId)
if(null==S)return void I.Y.LogError(`${t.id_get()}  查下这个任务的配置`)
const T=x.Z.GetAttrKey(e.param.attrName),f=b.n.Inst_get().GetAttrName(T),C=S.getAttribute(T),E=e.value-C-S.RemainBasePoint_get()
let A=""
const L=new m.Z
if(E>0){const t=U.l.GetInst().GetPlayerInitial(S.Job_get()),i=q.A.Inst_get().GetNeedLevel(E,t.levelOfPoint)
L.Add(i),L.Add(f),L.Add(e.value),g=Y.l.Substitute(o,L),c=h}else L.Add(f),L.Add(e.value),g=Y.l.Substitute(_,L),c=(0,k.aI)(u)
A=C<e.value?`${$.Y.GetCountColorStr(p.M.DoubleToString(C))}/${e.value}`:`${Y.l.SetStringColor(Y.l.txtGreenStr,p.M.DoubleToString(C))}/${e.value}`
const y=new m.Z([p.M.IntToString(X.V.OPEN_PANEL),t.tCTargetDefs_get().tCTargetDefs[0].OpenUI_get(),p.M.IntToString(t.id_get())]),O=$.Y.JointStr(y),R=Y.l.SetLinkStr(g,O,null,!1)
t.linkStr=O,i.linkStr=O,i.progresStr=A,i.txtStr=R}GetTaskSkillId(){let t=0
const e=V.g.Inst_get().GetBagDataList()
for(const[i,s]of(0,l.V5)(e)){let e=this.GetSkillIdByBagItem(s)
0==t?e=t:e<t&&(t=e)}if(0==t){t=J.C.INSTANCE.GetJsonJobSkillGroups().arr[0].coreSkillIds[0]}return t}GetSkillIdByBagItem(t){const e=t.baseData_get().cfgData_get().reward
if(""!=e){const t=G.d.parseJsonObjectWithFix(e,"typevalues"),i=F.t.decode(t,K.z)
if("Skill"==i.typevalues[0].type)return(0,k.aI)(p.M.Split(i.typevalues[0].value,":")[0])}return 0}HandleRemoveTask(t){const e=t.tCTargetDefs_get()
if(null!=e.tCTargetDefs&&e.tCTargetDefs.Count()>0)for(let t=0;t<=e.tCTargetDefs.Count()-1;t++){e.tCTargetDefs[t].type==Z.d.ENTER_MAP&&(Q.X.inst.TaskOpenMap=0)}}}j._mInst=null
var z,tt,et,it=i(98580),st=i(63412),nt=i(85890),lt=i(15398),at=i(61646),rt=i(98130),ot=i(1240),ht=i(47520),dt=i(8849),_t=i(2457),ut=i(24524),It=i(68637),ct=i(77697),gt=i(8038),pt=i(28359),mt=i(72800),St=i(73341),Tt=i(54518),ft=i(6071),Ct=i(77097),Et=i(56542),At=i(59586),Lt=i(74657)
class yt{constructor(t){this._status=it.B.NONE,this.m_resource=null,this.linkStr=null,this.qVo=null,this.isHanging=!1,this.isStatusChanged=!1,this.isChangeStatusToFinish=!1,
this.currentEffectId=0,this._receiveArr=null,this._intersectionArr=null,this._tCTargetDefs=null,this._showRewardResult=null,this._rewardAttValue=null,this._showAttrReward=null,
this.m_completeConsumsInfo=null,this.mainUiShowReward=null,this.mainUiShowRewardItem=null,this.mainUIShowRewardSkill=null,this.accessList=null,this.isPlaySelected=!1,
this.needQuestsList=null,this.IsAddedPoint=null,this.IsStepFix=null,this.IsStepFixAndNoAdd=null,this.CanGetRoleIndex=null,this.StepConditions=null,this.RoleEventLis=null,
this.CommonEventLis=null,this._degf_UpdateScoreHandler=null,this.isTop=!1,this.linkTarget=null,this.masterReward=null,this.masterRewardItem=null,this.needQuestsList=new m.Z,
this.m_resource=t}GetLinkCidx(){if(null!=this.qVo&&0!=this.qVo.playerId.ToNum())return a.Y.Inst.GetCreateIdxById(this.qVo.playerId)}GetLinkTarget(){return this.linkTarget}
GetLinkType(){if(!Y.l.IsEmptyStr(this.linkStr)){const t=$.Y.JoinValue(this.linkStr)
if(null!=t[0]){const e=p.M.String2Int(t[0])
if(null!=e)return e}}return 0}SetIsAddedPoint(t){this.IsAddedPoint=t,this.SetStepFixAndNoAdd()}SetStepFixAndNoAdd(){const t=!this.GetIsAddedPoint()&&this.GetStepFix(null)
null!=this.IsStepFixAndNoAdd&&this.IsStepFixAndNoAdd==t||(this.IsStepFixAndNoAdd=t,
this.IsStepFixAndNoAdd?Y.l.CheckTrigger(_t.u.COND_TYPE_QUEST_FIXSTEP_VAL,this.resource_get().id):Y.l.CheckTrigger(_t.u.COND_TYPE_QUEST_NO_FIXSTEP_VAL,this.resource_get().id))}
IsMainTask(){return this.type_get()==nt.U.MAIN}SetStepFix(t){this.IsStepFix=t,this.SetStepFixAndNoAdd()}GetStepFix(t){return null==this.IsStepFix||this.IsStepFix}GetIsAddedPoint(){
return null!=this.IsAddedPoint&&this.IsAddedPoint}InitNeedsQuests(){const t=Y.l.AnalyseArrayStr(this.m_resource.needQuests)
if(null!=t){let e=0
for(;e<t.count;)this.needQuestsList.Add(p.M.String2Int(t[e])),e+=1}const e=Y.l.AnalyseArrayStr(this.m_resource.needQuestsOr)
if(null!=e){let t=0
for(;t<e.count;)this.needQuestsList.Add(p.M.String2Int(e[t])),t+=1}}status_get(){return this._status}status_set(t){if(this._status!=t)if(this.isStatusChanged=!0,
this._status!=it.B.NONE||t!=it.B.ACCEPTED&&t!=it.B.FINISHED||(this._status=t,Y.l.CheckTrigger(_t.u.COND_TYPE_ACCEPT_QUEST_VAL,this.resource_get().id)),this.isHanging=!1,
this._status=t,t==it.B.FINISHED){this.ClearSteps(),this.SetIsAddedPoint(!1),this.isChangeStatusToFinish=!0
const t=this.GetGuidId()
if(t>0){const e=It.c.Inst.GetResById(t)
It.c.Inst.RemoveGuideByType(e.classify)}Y.l.CheckTrigger(_t.u.COND_TYPE_QUEST_COMPLETE_VAL,this.m_resource.id),W.L.Inst_get().model.RaiseEvent(lt.M.FINISH_ONE_TASK,this),
this.status_get()==it.B.FINISHED&&(this.resource_get().automateNPC!=st.U.AUTO_TO_FINISH_NPC_GO&&this.resource_get().automateNPC!=st.U.AUTO_TO_FINISH_NPC_FLY||($.Y.GetLinkInfo(null,null),
$.Y.GotoByTask(this.resource_get().automateNPC,!0,null)))}else this.isChangeStatusToFinish=!1,
t==it.B.ACCEPTED&&Y.l.CheckTrigger(_t.u.COND_TYPE_ACCEPT_QUEST_NOFINISH_VAL,this.resource_get().id)}GetGuidId(){const t=this.tCTargetDefs_get()
return null!=t&&t.tCTargetDefs.Count()>0?t.tCTargetDefs[0].guidId:0}needShowProgress_get(){if(this.status_get()==it.B.ACCEPTED){const t=this.tCTargetDefs_get()
if(t.tCTargetDefs.Count()>0){const e=t.tCTargetDefs[0].type
if(e==Z.d.KILL_MONSTER||e==Z.d.GATHER||e==Z.d.GATHER_ITEM||e==Z.d.KILL_MONSTER_ITEM||e==Z.d.KILL_MONSTER_RATE||e==Z.d.FICTITIOUS_ITEM||e==Z.d.KILL_MIRACLE_MONSTER||e==Z.d.MONSTER_DROP_EQUIP){
if(this.qVo.targets.count>0){if(0==this.qVo.targets[0].value_get())return!1}return!0}}}return!1}npcEffectId_get(){
return this.status_get()==it.B.CAN_ACCEPT?at.k.CAN_ACCEPT_TASK:this.status_get()==it.B.ACCEPTED?this.resource_get().intersectionType==st.U.INTERSECTION_AUTO?at.k.CAN_REWARD_TASK:at.k.UNFINISH_TASK:this.status_get()==it.B.FINISHED?at.k.CAN_REWARD_TASK:-1
}receiveArr_get(){if(null==this._receiveArr){const t=ct.f.Inst().getItemById(p.M.String2Int(this.m_resource.receiveValue))
if(null==t)return I.Y.LogError(`questreource 找不到npc:${this.m_resource.receiveValue} id:${this.m_resource.id}`),null
this._receiveArr=new m.Z([t.npcid,t.mapid,t.x,t.y])}return this._receiveArr}AcceptNpcId_get(){return rt.GF.INT(this.receiveArr_get()[0])}AcceptNpcMapId_get(){
return rt.GF.INT(this.receiveArr_get()[1])}AcceptNpcX_get(){return this.receiveArr_get()[2]}AcceptNpcY_get(){return this.receiveArr_get()[3]}NpcSmallMapX_get(){
const t=ct.f.Inst().getItemById(this.linkNpcId_get())
return null==t?(I.Y.LogError(`questreource 找不到npc:${this.linkNpcId_get()} id:${this.m_resource.id}`),0):t.smallMapX}NpcSmallMapY_get(){
const t=ct.f.Inst().getItemById(this.linkNpcId_get())
return null==t?(I.Y.LogError(`questreource 找不到npc:${this.linkNpcId_get()} id:${this.m_resource.id}`),0):t.smallMapY}intersectionArr_get(){
const t=p.M.String2Int(this.resource_get().intersectionValue)
if(t>0){const e=ct.f.Inst().getItemById(t)
if(null==e)return null
this._intersectionArr=new m.Z([e.npcid,e.mapid,e.x,e.y])}else{this._intersectionArr=new m.Z
for(let t=1;t<=4;t++)this._intersectionArr[t-1]=0}return this._intersectionArr}RewardNpcId_get(){return null==this.intersectionArr_get()?0:rt.GF.INT(this.intersectionArr_get()[0])}
RewardNpcMapId_get(){return null==this.intersectionArr_get()?0:rt.GF.INT(this.intersectionArr_get()[1])}RewardNpcX_get(){return this.intersectionArr_get()[2]}RewardNpcY_get(){
return this.intersectionArr_get()[3]}resource_get(){return this.m_resource}hideNPCDialog_get(){return this.m_resource.hideNPCDialog}taskName_get(){let t=this.m_resource.name
return this.isRoleTask()&&null!=this.qVo&&a.Y.Inst.primaryRoleInfoList.Count()>1&&(t=`第${Y.l.getNumStr(a.Y.Inst.GetCreateIdxById(this.qVo.playerId)+1)}角色-${this.m_resource.name}`),
this.type_get()==nt.U.BountyTask&&(t+=`  (${ht.s.GetInst().GetCurLink()}/${ht.s.GetInst().GetMaxRoundorLink(1)-1})`),t}traceName_get(){
return Y.l.IsEmptyStr(this.m_resource.nameColor)?this.taskName_get():Y.l.SetStringColor(this.m_resource.nameColor,this.taskName_get())}id_get(){return this.m_resource.id}
logId_get(){return p.M.IntToString(this.m_resource.id)}type_get(){return this.m_resource.type}GetTypeSprite(){return this.resource_get().labelicon}GetNameTxt(){
return this.traceName_get()}GettypeName(){return nt.U.GetName(this.type_get())}GetTemporaryShowStr(){if(null==this.qVo)return""
let t=this.m_resource.temporaryShow
if(this.resource_get().type==nt.U.CHANGE_JOB){let e=this.GetTemporayHaveValue()
const i=Dt.Inst_get().GetAllCharacterTargetDef(this)
e>i&&(e=i),t=p.M.Replace(t,"{0}",this.GetTemporayHaveValue().toString()),t=p.M.Replace(t,"{1}",Dt.Inst_get().GetAllCharacterTargetDef(this).toString())
}else this.status_get()==it.B.FINISHED?(t=p.M.Replace(t,"{0}",this.GetNowTargetDef().value.toString()),
t=p.M.Replace(t,"{1}",this.GetNowTargetDef().value.toString())):this.status_get()==it.B.ACCEPTED&&(t=p.M.Replace(t,"{0}",this.qVo.targets[this.GetNowTargetDef().key-1].value_get()),
t=p.M.Replace(t,"{1}",this.GetNowTargetDef().value.toString()))
return t}GetTemporayHaveValue(){const t=this.GetConsumeItemId()
let e=0
return 0!=t&&(e=V.g.Inst_get().GetItemNum(t)),e}NeedTempShow(){return!Y.l.IsEmptyStr(this.m_resource.temporaryShow)}GetTargetType(){const t=this.tCTargetDefs_get()
return null!=t&&null!=t.tCTargetDefs&&t.tCTargetDefs.Count()>0?t.tCTargetDefs[0].type:""}tCTargetDefs_get(){if(null==this._tCTargetDefs){
if(""==this.resource_get().targetDefs)return
this._tCTargetDefs=new At.N,this._tCTargetDefs.tCTargetDefs=At.N.CreateFromJsonStr(this.resource_get().targetDefs)}return this._tCTargetDefs}GetNowTargetDef(){
if(null==this.qVo)return this.tCTargetDefs_get().tCTargetDefs[0]
let t=null
for(let e=0;e<=this.tCTargetDefs_get().tCTargetDefs.Count()-1;e++)if(t=this.tCTargetDefs_get().tCTargetDefs[e],t&&t.value>this.qVo.targets[e].value_get())return t
return t}GetTargetOpenUI(){const t=this.tCTargetDefs_get()
if(null!=t&&null!=t.tCTargetDefs)for(const e of t.tCTargetDefs)if(!p.M.IsNullOrEmpty(e.OpenUI_get())){const t=p.M.Split(e.OpenUI_get(),p.M.s_CCD_CHAR)
return p.M.String2Int(t[0])}return 0}IsLevelAndMiracleObjTask(){return!1}IsFinishOrRewarded(){return this._status==it.B.REWARDED||this._status==it.B.FINISHED}
finishStateNPCPosStr_get(){if(this.isTalk_get()){const t=this.tCTargetDefs_get().tCTargetDefs[0]
if(this.RewardNpcId_get()==t.param.npcId)return t.param.npcPosStr_get(null)}
return this.RewardNpcMapId_get()+(u.o.s_UNDER_CHAR+(this.RewardNpcX_get()+(u.o.s_UNDER_CHAR+this.RewardNpcY_get())))}GetReduceDistance(){if(!this.isTalk_get()){
const t=this.linkNpcId_get()
if(t>0){const e=ct.f.Inst().getItemById(t)
if(this.status_get()==it.B.CAN_ACCEPT&&this.resource_get().receiveType==st.U.RECEIVE_BY_NPC)return e.reactDistance-.2
if(this.status_get()==it.B.FINISHED&&this.GetIntersectionType()==st.U.INTERSECTION_NPC)return e.reactDistance-.2
if(this.isHandInTask_get())return e.reactDistance-.2}}if(null!=this.tCTargetDefs_get().tCTargetDefs&&this.tCTargetDefs_get().tCTargetDefs.Count()>0){
return this.tCTargetDefs_get().tCTargetDefs[0].param.GetReduceDistance()}return 0}flyId_get(){
if(null!=this.tCTargetDefs_get().tCTargetDefs&&this.tCTargetDefs_get().tCTargetDefs.Count()>0){return this.tCTargetDefs_get().tCTargetDefs[0].param.uesFlyId_get()}return 0}
TargetDefCopyId_get(){let t=0
const e=this.tCTargetDefs_get()
let i=0
for(;i<e.tCTargetDefs.Count();){const s=e.tCTargetDefs[i]
if(null!=s.param&&0!=s.param.copyId){t=s.param.copyId
break}i+=1}return t}isTalk_get(){const t=this.tCTargetDefs_get()
let e=0
for(;e<t.tCTargetDefs.Count();){if(t.tCTargetDefs[e].type==Z.d.TALK)return!0
e+=1}return!1}IsRealTalk_get(){const t=this.tCTargetDefs_get()
let e=0
for(;e<t.tCTargetDefs.Count();){if(t.tCTargetDefs[e].type==Z.d.REAL_TALK)return!0
e+=1}return!1}RealTalkNpc_get(){const t=this.tCTargetDefs_get()
let e=0
for(;e<t.tCTargetDefs.Count();){const i=t.tCTargetDefs[e]
if(i.type==Z.d.REAL_TALK)return null==i.param.npcId&&I.Y.LogError(`quest npcId 为空 id:${this.resource_get().id}`),i.param.npcId
e+=1}return 0}IsCopy_get(){const t=this.tCTargetDefs_get()
if(null!=t){let e=0
for(;e<t.tCTargetDefs.Count();){const i=t.tCTargetDefs[e]
if(i.type==Z.d.PASS_COPY||i.type==Z.d.ENTER_COPY||i.type==Z.d.CLIMB_TOWER_STAR)return!0
e+=1}}return!1}IsTalkCopy(){const t=this.tCTargetDefs_get()
if(null!=t){let e=0
for(;e<t.tCTargetDefs.Count();){const i=t.tCTargetDefs[e]
if((i.type==Z.d.PASS_COPY||i.type==Z.d.ENTER_COPY)&&1==i.param.NeedTalk&&i.param.copyId>0)return!0
e+=1}}return!1}IsMainCopyTask(){return this.IsEnterByCopyId()&&this.isEnterCopy()}IsEnterByCopyId(){
return this.status_get()!=it.B.FINISHED&&null!=this.tCTargetDefs_get().tCTargetDefs&&this.tCTargetDefs_get().tCTargetDefs.Count()>0&&null!=this.tCTargetDefs_get().tCTargetDefs[0].param&&null!=this.tCTargetDefs_get().tCTargetDefs[0].param.copyId&&0!=this.tCTargetDefs_get().tCTargetDefs[0].param.copyId
}isEnterCopy(){
return this.status_get()!=it.B.FINISHED&&null!=this.tCTargetDefs_get().tCTargetDefs&&this.tCTargetDefs_get().tCTargetDefs.Count()>0&&null!=this.tCTargetDefs_get().tCTargetDefs[0].param&&null!=this.tCTargetDefs_get().tCTargetDefs[0].param.groupId&&-1!=this.tCTargetDefs_get().tCTargetDefs[0].param.groupId
}IsPhotoTask_get(){const t=this.tCTargetDefs_get()
if(null!=t){let e=0
for(;e<t.tCTargetDefs.Count();){const i=t.tCTargetDefs[e]
if(i.type==Z.d.PHOTO_POSITION||i.type==Z.d.PHOTO_NPC||i.type==Z.d.PHOTO_MONSTER||i.type==Z.d.PHOTO_PLAYER)return!0
e+=1}}return!1}IsCurrency_get(){const t=this.tCTargetDefs_get()
if(null!=t){let e=0
for(;e<t.tCTargetDefs.Count();){const i=t.tCTargetDefs[e]
if(i.type==Z.d.CURRENCY||i.type==Z.d.CURRENCY_HISTORY||i.type==Z.d.CURRENCY_BACK)return!0
e+=1}}return!1}GetCopyRes(){if(!this.IsCopy_get())return null
let t=null
const e=this.tCTargetDefs_get()
if(null!=e){if(null==e.tCTargetDefs||0==e.tCTargetDefs.Count())return t
const i=e.tCTargetDefs[0]
i.param.copyId>0?t=ut.o.Inst().getItemById(i.param.copyId):i.param.groupId>0&&(t=ut.o.Inst().getOneItemByGroupId(i.param.groupId))}return t}TaskCopyId_get(){
const t=this.tCTargetDefs_get()
if(null!=t){let e=0
for(;e<t.tCTargetDefs.Count();){const i=t.tCTargetDefs[e]
if(i.type==Z.d.PASS_COPY||i.type==Z.d.ENTER_COPY){if(i.param.copyId>0)return i.param.copyId
if(i.param.groupId>0){return ut.o.Inst().getOneItemByGroupId(i.param.groupId).id}}e+=1}}return 0}isKillTask_get(){const t=this.tCTargetDefs_get()
let e=0
for(;e<t.tCTargetDefs.Count();){const i=t.tCTargetDefs[e].type
if(i==Z.d.KILL_MONSTER||i==Z.d.KILL_MONSTER_ITEM||i==Z.d.KILL_MONSTER_RATE||i==Z.d.FICTITIOUS_ITEM||i==Z.d.MONSTER_DROP_EQUIP||i==Z.d.KILL_FIELD_MONSTER)return!0
e+=1}return!1}isCollection_get(){const t=this.tCTargetDefs_get()
let e=0
for(;e<t.tCTargetDefs.Count();){const i=t.tCTargetDefs[e]
if(i.type==Z.d.GATHER||i.type==Z.d.GATHER_ITEM||i.type==Z.d.HAND_IN_ITEM&&(i.param.gatherId>0||i.param.groupId>0))return!0
e+=1}return!1}GetRewardItems(){if(this.type_get()==nt.U.CHANGE_JOB)return this.getTransferReward()
const t=this.showRewardResult_get()
if(null!=t){return t.GetRealItemList()}return null}GetAllRewardList(t){if(this.type_get()==nt.U.CHANGE_JOB)return this.getTransferReward()
const e=new m.Z,i=this.showRewardResult_get()
if(null!=i){const s=i.GetAllRewardList()
let n=null
if(t&&(n=this.showAttrReward_get()),null!=s){let t=0
for(;t<s.Count();)e.Add(s[t]),t+=1}if(null!=n){let t=0
for(;t<n.Count();)e.Add(n[t]),t+=1}}return e}getTransferReward(){const t=this.showRewardResult_get(),e=new m.Z
if(null!=t){const i=t.GetRewardItemList()
e.AddRange(i)}const i=this.rewardAttValue_get()
if(null!=i)for(const t of i.rewardValues){const i=t.taskRewardAttr_get(),s=this.wrapAttrData(i)
null!=s&&e.Add(s)}return e}wrapAttrData(t){const e=new AbstractItem
if(t.intType==rt.GF.INT(eAttributeKey.Attack))e.modelId=10216,e.num=t.value
else if(t.intType==rt.GF.INT(eAttributeKey.Defense))e.modelId=10217,e.num=t.value
else{if(t.intType!=rt.GF.INT(eAttributeKey.MaxHp))return null
e.modelId=10218,e.num=t.value}const i=new ot.Y
return i.serverData_set(e),i.baseData_get().isCanOperate=!1,i}showRewardResult_get(){
return null==this._showRewardResult&&(Y.l.IsEmptyStr(this.m_resource.showReward)||(this._showRewardResult=Lt.A.GetReward(this.m_resource.showReward))),this._showRewardResult}
rewardAttValue_get(){if(null==this._rewardAttValue&&"[]"!=this.m_resource.rewardAttrs){const t=G.d.parseJsonObjectWithFix(this.m_resource.rewardAttrs,"rewardValues")
this._rewardAttValue=F.t.decode(t,pt.h),this._rewardAttValue.Parse()}return this._rewardAttValue}showAttrReward_get(){if(null==this._showAttrReward&&(this._showAttrReward=new m.Z,
null!=this.rewardAttValue_get())){const t=this.rewardAttValue_get().rewardValues
let e=0
for(;e<t.Count();){const i=t[e],s=new Attr
s.intType=AttrsUtils.GetAttrByStr(i.type),s.value=p.M.String2Int(i.value),this._showAttrReward.Add(s),e+=1}}return this._showAttrReward}linkNpcId_get(){let t=0
if(this.status_get()==it.B.CAN_ACCEPT){if(this.resource_get().receiveType==st.U.RECEIVE_BY_NPC)return this.AcceptNpcId_get()}else{if(this.status_get()==it.B.ACCEPTED){let e=-1
const i=this.tCTargetDefs_get()
for(const t of i.tCTargetDefs)if(t.type==Z.d.TALK||t.type==Z.d.REAL_TALK)e=t.param.npcId
else if(t.type==Z.d.PASS_COPY)if(0!=t.param.npcId)e=t.param.npcId
else{let i=null
t.param.copyId>0?i=ut.o.Inst().getItemById(t.param.copyId):t.param.groupId>0&&(i=ut.o.Inst().getOneItemByGroupId(t.param.groupId)),
null!=i&&i.controllerType!=mt.S.Belial&&i.controllerType!=mt.S.BloodTown&&(e=i.NpcId)}else null!=t.param&&0!=t.param.npcId&&(e=t.param.npcId)
return e<0&&(t=this.GetIntersectionType(),t==st.U.INTERSECTION_NPC&&(e=this.RewardNpcId_get())),e}if(this.status_get()==it.B.FINISHED&&(t=this.GetIntersectionType(),
t==st.U.INTERSECTION_NPC))return this.RewardNpcId_get()}return-1}isAutoTask_get(){let t=!1
return this.isHandInTask_get()||(this.status_get()==it.B.ACCEPTED?t=this.m_resource.automateExecute==st.U.AUTO_TASK:this.status_get()==it.B.FINISHED&&(this.isTalk_get()||this.IsRealTalk_get()?t=this.m_resource.automateExecute==st.U.AUTO_TASK:this.GetIntersectionType()==st.U.INTERSECTION_NPC&&this.m_resource.moveType==st.U.MOVE_TYPE_GO&&(t=!0))),
t&&this.type_get()==nt.U.BountyTask&&this.resource_get().receiveType==st.U.STORY_GET&&(0==Et.S.ins.GetElementValue(Ct.$.BOUNTY_TASK_OPEN)||ft.T.ins.is_stop||ft.T.ins.is_pause)&&(t=!1),
t}IsNeedTask(t){return p.M.IndexOf(this.m_resource.needQuests,p.M.IntToString(t),0)>-1}isShowToDialogue_get(){return!0}receiveTalkList_get(){
const t=G.d.parseJsonObjectWithFix(this.m_resource.receiveTalk,"rewardValues"),e=F.t.decode(t,pt.h)
return e.Parse(),e.rewardValues}finishTalkList_get(){let t=""
t=G.d.parseJsonObjectWithFix(this.m_resource.underwayTalk,"rewardValues")
const e=F.t.decode(t,pt.h)
return e.Parse(),e.rewardValues}intersectionTalkList_get(){let t=""
t=G.d.parseJsonObjectWithFix(this.m_resource.intersectionTalk,"rewardValues")
const e=F.t.decode(t,pt.h)
return e.Parse(),e.rewardValues}intersectionTalkSoundList_get(){let t=""
if(t=this.m_resource.intersectionTalkSound,""!=t){const e=p.M.SubStringWithEnd(t,1,p.M.Length(t)-1)
return p.M.Split(e,u.o.s_Arr_UNDER_CHAR_DOU)}return null}getInterTalk(){const t=W.L.Inst_get().model
return this.status_get()==it.B.ACCEPTED?t.getIntersectionTalk(this.resource_get().unFitConditionDialog):this.status_get()==it.B.FINISHED?t.getIntersectionTalk(this.resource_get().fitConditionDialog):null
}getDialogInfo(){const t=new Tt.p,e=this.getInterTalk()
if(null!=e)return t.interTalk=e,t
if(t.dialogList=this.GetDialogueList(),0==t.dialogList.Count()){const e=new gt.x
e.type="NPC"
const i=St.F.Inst_get().control.npc
e.value=i.dialog,t.dialogList.Add(e)}return t}GetDialogueList(){
return this.status_get()==it.B.CAN_ACCEPT?this.receiveTalkList_get():this.status_get()==it.B.ACCEPTED?this.isTalk_get()?this.intersectionTalkList_get():this.finishTalkList_get():this.intersectionTalkList_get()
}completeConsumsInfo_get(){if(null==this.m_completeConsumsInfo){let t=null
t=G.d.parseJsonObjectWithFix(this.m_resource.completeConsums,"rewardValues"),null!=t&&(this.m_completeConsumsInfo=F.t.decode(t,pt.h),this.m_completeConsumsInfo.Parse())}
return this.m_completeConsumsInfo}isHandInTask_get(){
if(null!=this.tCTargetDefs_get()&&null!=this.tCTargetDefs_get().tCTargetDefs)for(const t of this.tCTargetDefs_get().tCTargetDefs)if(t.type==Z.d.HAND_IN_ITEM||t.type==Z.d.HAND_IN_ITEM_TYPE||t.type==Z.d.HAND_IN_ITEM_GROUP||t.type==Z.d.HAND_IN_EQUIPMENT)return!0
return!1}isNpcShopBuyTask_get(){if(null!=this.tCTargetDefs_get()&&null!=this.tCTargetDefs_get().tCTargetDefs)for(const[t,e]of(0,
l.V5)(this.tCTargetDefs_get().tCTargetDefs))if(e.type==Z.d.NPC_SHOP_BUY)return!0
return!1}IsNeedFixAttrTask(){if(null!=this.tCTargetDefs_get()&&null!=this.tCTargetDefs_get().tCTargetDefs)for(const[t,e]of(0,
l.V5)(this.tCTargetDefs_get().tCTargetDefs))if(e.IsNeedFixAttr())return!0
return!1}isAutoShowHandInTypeTask_get(){return this.type_get()==nt.U.MAIN}GetAccessData(){let t=""
t=this.m_resource.Access
const e=new m.Z
if(!Y.l.IsEmptyStr(t)){const i=p.M.Split(t,u.o.s_Arr_UNDER_CHAR_DOT)
let s=0
for(;s<i.count;)e.Add(p.M.String2Int(i[s])),s+=1}return e}GetIntersectionType(){return this.resource_get().intersectionType}isClickReward_get(){const t=this.GetIntersectionType()
return this.status_get()==it.B.FINISHED&&(t==st.U.INTERSECTION_CLICK||t==st.U.INTERSECTION_AUTO)}canGiveup_get(){return!1}getTargetCount(){
if(null!=this.qVo&&null!=this.qVo.targets&&this.qVo.targets.count>0){const t=this.qVo.targets[0].value_get()
return rt.GF.INT(t)}return 0}GetCfgTargetCount(){
return null!=this.tCTargetDefs_get()&&0!=this.tCTargetDefs_get().tCTargetDefs.Count()?rt.GF.INT(this.tCTargetDefs_get().tCTargetDefs[0].value):0}MainUiShowReward_get(){
if(null==this.mainUiShowReward&&!Y.l.IsEmptyStr(this.resource_get().mainUiShowReward)){const t=G.d.parseJsonObjectWithFix(this.resource_get().mainUiShowReward,"rewardValues")
this.mainUiShowReward=F.t.decode(t,pt.h),this.mainUiShowReward.Parse()}return this.mainUiShowReward}MainUiShowRewardItem_get(){
if(null==this.mainUiShowRewardItem&&null!=this.MainUiShowReward_get()){let t=0
for(;t<this.MainUiShowReward_get().rewardValues.Count();){const e=this.MainUiShowReward_get().rewardValues[t].jobValue_get()
if(JobCfgManager.Inst_get().IsInJobRelation(e)){this.mainUiShowRewardItem=this.MainUiShowReward_get().rewardValues[t].baseItem_get(),
null==this.mainUiShowRewardItem&&(this.mainUiShowRewardItem=this.MainUiShowReward_get().rewardValues[t].currencyItem_get()),
null==this.mainUiShowRewardItem&&(this.mainUiShowRewardItem=this.MainUiShowReward_get().rewardValues[t].expitem_get()),
null!=this.mainUiShowRewardItem&&(this.mainUiShowRewardItem.anchor=new Vector2(1,.5))
break}t+=1}}return this.mainUiShowRewardItem}MainUIShowRewardSkill_get(){if(null==this.mainUIShowRewardSkill&&null!=this.MainUiShowReward_get()){let t=0
for(;t<this.MainUiShowReward_get().rewardValues.Count();){const e=this.MainUiShowReward_get().rewardValues[t].jobValue_get()
if(JobCfgManager.Inst_get().IsInJobRelation(e)&&(this.mainUIShowRewardSkill=this.MainUiShowReward_get().rewardValues[t].Skilldata_get(),null!=this.mainUIShowRewardSkill))break
t+=1}}return this.mainUIShowRewardSkill}AccessList_get(){if(null==this.accessList&&!Y.l.IsEmptyStr(this.resource_get().Access)){const t=this.resource_get().Access
if(!Y.l.IsEmptyStr(t)){this.accessList=new m.Z
const e=p.M.Split(t,u.o.s_Arr_UNDER_CHAR_DOT)
for(const[t,i]of(0,l.V5)(e)){const t=p.M.String2Int(i)
this.accessList.Add(t)}}}return this.accessList}sortValue_get(){}IsCding(){return!1}GetLevelAccessList(){const t=this.m_resource.access2
if(Y.l.IsEmptyStr(t))return null
const e=p.M.Split(t,u.o.s_Arr_UNDER_CHAR_DOU),i=new m.Z
let s=0
for(;s<e.count;){const t=p.M.String2Int(e[s])
AccessCfgManager.Inst().IsFunOpen(t)&&i.Add(t),s+=1}return i}GetAccess2(){return this.m_resource.access2}isRoleTask(){return this.GetCanGetRoleList().Count()>0}CanGetThisTask(t){
return null==t&&(t=0),!(this.isRoleTask()&&!this.GetCanGetRoleList().Contains(t+1))}GetCanGetRoleList(){
return null==this.CanGetRoleIndex&&(this.CanGetRoleIndex=new m.Z(this.m_resource.isRole)),this.CanGetRoleIndex}InitSteps(){if(null==this.qVo)return
const t=this.GetNowTargetDef().steps
if(null!=t){const e={}
for(let i=0;i<=t.Count()-1;i++){const s=t[i]
null!=s.condition&&(e[i+1]=s.condition)}this.StepConditions=dt.U.CreateFromJson(e)}if(null!=this.StepConditions)for(const[t,e]of(0,
l.V5)(this.StepConditions.conditions))e.SetRoleIndex(a.Y.Inst.GetCreateIdxById(this.qVo.playerId)),
e.OpenTrigger(null,this.CreateDelegate(this.OnStepChange),eGameConditionTriggerCallType.OnlyRecv,!1,30)}ClearSteps(){if(null!=this.StepConditions){for(const[t,e]of(0,
l.V5)(this.StepConditions.conditions))e.CloseTrigger()
this.StepConditions=null}}GetNowStepsDic(){if(null!=this.GetNowTargetDef().steps){if(null==this.StepConditions)return null
const t=new Dictionary
for(let e=0;e<=this.StepConditions.conditions.Count()-1;e++)this.StepConditions.conditions[e].CheckCondition()&&t.LuaDic_AddOrSetItem(e,this.StepConditions.conditions[e])
return 0==t.LuaDic_Count()?(this.SetStepFix(!0),null):(this.SetStepFix(!1),t)}return null}GetNowStepsTarget(){
if(null!=this.GetNowTargetDef().steps)for(let t=0;t<=this.StepConditions.conditions.Count()-1;t++)if(this.StepConditions.conditions[t].CheckCondition())return this.GetNowTargetDef().steps[t]
return null}OnStepChange(t){Dt.Inst_get().RaiseEvent(lt.M.TASK_STEP_CHANGE,this),null!=t.topchange&&(Dt.Inst_get().RaiseEvent(lt.M.TASK_ITEM_FLASH,this),
Dt.Inst_get().RaiseEvent(lt.M.ADD_TOP_TASK,this))}IsFixStepOrFixAttr(){return null!=this.qVo&&(null==this.IsStepFixAndNoAdd||this.IsStepFixAndNoAdd)}GetUpdateByRoleEvent(){
return null==this.qVo?null:this.isRoleTask()&&null!=this.m_resource.UpdateByRoleEvent?(null==this.RoleEventLis&&(this.RoleEventLis=new m.Z(this.m_resource.UpdateByRoleEvent)),
this.RoleEventLis):null}GetUpdateByCommonEvent(){
return null!=this.m_resource.UpdateByCommonEvent?(null==this.CommonEventLis&&(this.CommonEventLis=new m.Z(this.m_resource.UpdateByCommonEvent)),this.CommonEventLis):null}
SetTopState(t){this.isTop=t}GetTopState(){return this.isTop}GetConsumeItemId(){const t=this.completeConsumsInfo_get().GetItemList()[0]
return null==t?0:t.modelId_get()}ResetData(){this.status_set(it.B.NONE),this.ClearSteps(),this.IsAddedPoint=null,this.IsStepFix=null,this.IsStepFixAndNoAdd=null,this.qVo=null,
this.masterReward=null,this.mainUiShowReward=null,this.masterRewardItem=null,this.mainUiShowRewardItem=null,this.linkStr=null,this.SetTopState(!1),
null!=this._showRewardResult&&(this._showRewardResult.Reset(),this._showRewardResult=null)}toString(){return this.id_get().toString()}}let Dt=(0,
s.gK)("TaskModel")((et=class t extends _.g{static get ins(){return null==t._mInst&&(t._mInst=new t),t._mInst}constructor(){super(),this._taskDic=null,this._mainTaskDic=null,
this.npcEffectDic=null,this.questTalkMap=null,this.SingleTaskList=null,this.multplayerTask=null,this.taskBufferList=null,this.HistoryFinishTaskLis=null,
this.HistoryFinishTaskDic=null,this.canGetTasks=null,this.goUIParam=null,this.flyUIChild=c.E.s_Empty,this.judgeDic=null,this.isShowLenChanged=!1,this.needAuto=!0,
this.m_nowConfig=null,this.isNewTask=!1,this.show_new_list=null,this.isFirstDeal=!0,this._isFirstInit=!0,this.m_initDelayTimerPass=!1,this.hasReset=!1,this.LastMainTaskId=-1,
this.GUIDE_TASK=null,this.Eff_TaskList=null,this.topListSortData=null,this.taskMianUIHide=!1,this._degf_OnDealyTimer=null,this.questTypeIndex=null,this.changeJobTasks=null,
this.npcEffectDic=new S.X,this.questTalkMap=new S.X,this.SingleTaskList=new m.Z,this.multplayerTask=new S.X,this.taskBufferList=new m.Z,this.HistoryFinishTaskLis=new S.X,
this.HistoryFinishTaskDic=new S.X,this.canGetTasks=new m.Z,this.judgeDic=new S.X,this.show_new_list=new m.Z,this.GUIDE_TASK=new m.Z,this.Eff_TaskList=new m.Z,
this.topListSortData=new S.X,this._degf_OnDealyTimer=()=>this.OnDealyTimer(),this.InitData()}static Inst_get(){return null==t._mInst&&(t._mInst=new t),t._mInst}InitData(){
const t=g.Y.Inst.GetOrCreateCsv(n.h.eQuestresource).GetCsvMap(),e=new m.Z([nt.U.MAIN,nt.U.BRANCH,nt.U.CHANGE_JOB])
let i=0
for(;i<e.count;){new S.X
i+=1}this._taskDic=new S.X,this._mainTaskDic=new S.X,this._taskDic.LuaDic_Add(0,new S.X),this._taskDic.LuaDic_Add(1,new S.X),this._taskDic.LuaDic_Add(2,new S.X)
let s=null
for(const[e,i]of(0,l.V5)(t))s=new yt(i),s.isRoleTask()?(this._taskDic[0].LuaDic_AddOrSetItem(i.id,s),s.resource_get().receiveType==st.U.RECEIVE_BY_NPC&&s.receiveArr_get(),
s=new yt(i),this._taskDic[1].LuaDic_AddOrSetItem(i.id,s),s.resource_get().receiveType==st.U.RECEIVE_BY_NPC&&s.receiveArr_get(),s=new yt(i),
this._taskDic[2].LuaDic_AddOrSetItem(i.id,s),s.resource_get().receiveType==st.U.RECEIVE_BY_NPC&&s.receiveArr_get()):(this._taskDic[0].LuaDic_AddOrSetItem(i.id,s),
this._taskDic[1].LuaDic_AddOrSetItem(i.id,s),this._taskDic[2].LuaDic_AddOrSetItem(i.id,s),s.type_get()==nt.U.MAIN&&this._mainTaskDic.LuaDic_AddOrSetItem(s.id_get(),s),
s.resource_get().receiveType==st.U.RECEIVE_BY_NPC&&s.receiveArr_get())
this.InitTalkData(),this.questTypeIndex=new m.Z,this.questTypeIndex.Add(nt.U.CREATEROLE),this.questTypeIndex.Add(nt.U.CHANGE_JOB),this.questTypeIndex.Add(nt.U.MAIN),
this.questTypeIndex.Add(nt.U.MANUAL),this.questTypeIndex.Add(nt.U.BRANCH),this.GUIDE_TASK=D.D.getInstance().GetIntArray("GUIDE_TASK"),
this.Eff_TaskList=D.D.getInstance().GetIntArray("ENTERMAP_EFFECT_QUEST"),this.changeJobTasks=new m.Z}InitTalkData(){g.Y.Inst.GetOrCreateCsv(n.h.eQuestTalk).GetCsvMap()}
GetTaskById(t,e){return this.GetConfig(t,e)}GetTaskByIdAndPlayIndex(t,e){(null==e||e<0||e>2)&&(e=0)
const i=this._taskDic[e][t]
if(i)return i}GetAccessItemId(t){
return null!=t&&null!=t.tCTargetDefs_get()&&t.tCTargetDefs_get().tCTargetDefs.count>0&&t.tCTargetDefs_get().tCTargetDefs[0].type==Z.d.KILL_MONSTER_ITEM?p.M.String2Int(t.tCTargetDefs_get().tCTargetDefs[0].param.itemModelId):null
}GetLinkNpcs(t){const e=new m.Z
for(const[i,s]of(0,l.V5)(this.judgeDic))s.linkNpcId_get()==t&&e.Add(s)
return e.Sort(((t,e)=>this.TraceViewSort(t,e))),e}GetTaskLisByType(t,e){null==e&&(e=!1)
const i=this.GetAllQuestes(),s=new m.Z
for(const[e,n]of(0,l.V5)(i))n&&n.type_get()==t&&s.Add(n)
return e&&s.Sort(this.CreateDelegate(this.TraceViewSort)),s}GetTaskLisByTypeInFinsh(t,e){null==e&&(e=!1)
const i=this.GetAllQuestes(),s=new m.Z
for(const[e,n]of(0,l.vy)(this.HistoryFinishTaskLis)){const n=this.GetConfig(e,null)
null!=n&&(i.Contains(n)||n.type_get()==t&&s.Add(n))}for(let e=0;e<=2;e++){const n=this.HistoryFinishTaskDic.LuaDic_GetItem(e)
if(null!=n){const r=a.Y.Inst.GetMultiPlayerInfoByCreateIdx(e)
if(null!=r){const e=r.Id_get()
for(const[a,r]of(0,l.vy)(n)){const n=this.GetConfig(a,e)
null!=n&&(i.Contains(n)||n.type_get()==t&&s.Add(n))}}}}return e&&s.Sort(this.CreateDelegate(this.TraceViewSort)),s}GetMainTask(){for(const[t,e]of(0,
l.V5)(this.SingleTaskList))if(e.type_get()==nt.U.MAIN)return e
return null}GetCurChangeJobTaskByPlayer(t){const e=this.GetAllQuestes()
for(const[i,s]of(0,l.V5)(e)){const e=s
if(s.type_get()==nt.U.CHANGE_JOB&&null!=e.qVo&&e.qVo.playerId.Equal(t)&&(e.status_get()==it.B.ACCEPTED||e.status_get()==it.B.FINISHED))return s}return null}GetCurChangeJobTask(){
const t=a.Y.Inst.primaryRoleInfoList
for(let e=0;e<=t.Count()-1;e++){const i=t[e],s=this.GetCurChangeJobTaskByPlayer(i.Id_get())
if(null!=s)return s}return null}GetDoingTaskByType(t,e){const i=this.GetAllQuestes()
for(const[s,n]of(0,l.V5)(i))if(n.type_get()==t&&null!=n.qVo&&(null==e||n.qVo.playerId.Equal(e))&&(n.status_get()==it.B.ACCEPTED||n.status_get()==it.B.FINISHED))return n
return null}SortMainUITraskJob(t,e){return 1e7*e[0]+1e5*e[1]+e[2]-(1e7*t[0]+1e5*t[1]+t[2])}IsGoingTask(t){const e=this.GetTaskById(t,null)
return null!=e&&(e.status_get()==it.B.ACCEPTED||e.status_get()==it.B.FINISHED)}nowConfig_get(){return this.m_nowConfig}nowConfig_set(t){this.m_nowConfig=t}InitServerData(t){
const e=this.GetAllQuestes()
if(e&&e.Count()>0)for(const[t,i]of(0,l.V5)(e))i.qVo?this.DealRemveTask(i.qVo.questId,i.qVo.playerId,!1):I.Y.LogError(`${i.m_resource.id}查下这个任务`)
this.nowConfig_set(null)
const i=t.questList
i&&this.DealAddTask(i,!0),this.HistoryFinishTaskLis.LuaDic_Clear(),this.HistoryFinishTaskDic.LuaDic_Clear()
for(const[e,i]of(0,l.V5)(t.questFinishList))if(this._mainTaskDic.LuaDic_ContainsKey(i.questId)&&this.LastMainTaskId<i.questId&&(this.LastMainTaskId=i.questId),
0==i.playerId.ToNum())this.HistoryFinishTaskLis.LuaDic_ContainsKey(i.questId)||this.HistoryFinishTaskLis.LuaDic_AddOrSetItem(i.questId,i.finshcount)
else{const t=a.Y.Inst.GetCreateIdxById(i.playerId)
let e=this.HistoryFinishTaskDic.LuaDic_GetItem(t)
null==e&&(e=new S.X,this.HistoryFinishTaskDic.LuaDic_AddOrSetItem(t,e)),e.LuaDic_ContainsKey(i.questId)||e.LuaDic_AddOrSetItem(i.questId,i.finshcount)}$.Y.SendListRefresh(),
I.Y.Log("任务初始化完成"),this._isFirstInit&&(this._isFirstInit=!1)}UpdateTaskData(t){if(this.needAuto=!0,this.nowConfig_set(null),this.DealCurrentQuests(t.questList),
$.Y.SendListRefresh(),!this.needAuto)return
let e=null
this.isNewTask&&(e=this.nowConfig_get()),null!=e&&e.isAutoTask_get()&&!A.p.inst.IsInCopy()&&(v.c.Inst_get().autoTask_set(e),r.h.ResetAgainstQuestState(!0),
v.c.Inst_get().GotoAuto())}DealAutoTask(){let t=null
this.isNewTask&&(t=this.nowConfig_get()),null!=t&&t.isAutoTask_get()&&!A.p.inst.IsInCopy()&&(v.c.Inst_get().autoTask_set(t),r.h.ResetAgainstQuestState(!0),
v.c.Inst_get().GotoAuto())}DealCurrentQuests(t){const e=t
if(this.isNewTask=!1,this.isShowLenChanged=!0,null!=e)for(const[t,i]of(0,l.V5)(e)){let t=!1
const e=this.GetConfig(i.questId,i.playerId)
this.nowConfig_set(e),null!=e&&(this.ExistTask(e)?((null==e.qVo&&null!=i||this.IsBetterRes(e.qVo,i))&&(t=!0),e.qVo=i,e.status_set($.Y.GetTaskStatue(i)),
e.isStatusChanged&&(this.isShowLenChanged=!0),
this.needAuto=e.isStatusChanged,e.NeedTempShow()&&t&&e.resource_get().type!=nt.U.CHANGE_JOB&&this.RaiseEvent(lt.M.DO_UPDATA_TEMP_PANEL,e),
this.InformDoUpdata(e)):this.DealAddTaskEx(e,i,null))}this.isFirstDeal&&(this.isFirstDeal=!1)}IsBetterRes(t,e){const i=t.targets.Count()
if(i!=e.targets.Count())return!1
for(let s=0;s<=i-1;s++)if(e.targets[0]._numValue>t.targets[0]._numValue)return!0
return!1}DealAddTask(t,e){null==e&&(e=!1)
const i=t
if(i&&i.Count()>0){for(const[t,s]of(0,l.V5)(i)){const t=this.GetConfig(s.questId,s.playerId)
t&&(this.DealAddTaskEx(t,s,e),I.Y.Log(`接到任务：${s.questId}   ${s.playerId.ToString()}`))}$.Y.SendListRefresh()}e||this.DealAutoTask()}DealAddTaskEx(t,e,i){null==i&&(i=!1),t.qVo=e,
t.status_set($.Y.GetTaskStatue(e)),t.InitSteps(),this.AddToShow(t,i),this.nowConfig_set(t),this.isShowLenChanged=!0,this.isNewTask=!0,j.Inst_get().HandleTaskType(e),
this.InformDoAdd(t),t.resource_get().type==nt.U.CHANGE_JOB&&-1==this.changeJobTasks.IndexOf(t)&&(this.changeJobTasks.Add(t),
f.J.Inst_get().ChangeJobTaskProgressDelegate=this.CreateDelegate(this.ChangeJobTaskProgress))}ChangeJobTaskProgress(t){for(const[e,i]of(0,l.vy)(t)){
const t=this.MatchChangeJobTask(i.modelId)
null!=t&&this.RaiseEvent(lt.M.DO_UPDATA_TEMP_PANEL,t)}}MatchChangeJobTask(t){const e=this.changeJobTasks.Count()
for(let i=0;i<=e-1;i++)if(t==p.M.String2Int(this.changeJobTasks[i].GetConsumeItemId()))return this.changeJobTasks[i]
return null}DealRemveTask(t,e,i){i=i||!1
const s=this.GetConfig(t,e)
if(null!=s){if(null==s.qVo)return void I.Y.LogError(`多次发送  ${s.id_get()}`)
i&&(s.status_set(it.B.NONE),W.L.Inst_get().model.RaiseEvent(lt.M.REMOVE_ONE_TASK,s),this.AddToHistory(t,e)),s.ClearSteps(),j.Inst_get().HandleRemoveTask(s),this.RemoveFromShow(s),
this.isShowLenChanged=!0,this.InformDoRemove(s),this.changeJobTasks.Remove(s),0==this.changeJobTasks.Count()&&(f.J.Inst_get().ChangeJobTaskProgressDelegate=null)}}
AddToHistory(t,e){if(this._mainTaskDic.LuaDic_ContainsKey(t)&&this.LastMainTaskId<t&&(this.LastMainTaskId=t),
null==e||0==e.ToNum())if(this.HistoryFinishTaskLis.LuaDic_ContainsKey(t)){const e=this.HistoryFinishTaskLis[t]
this.HistoryFinishTaskLis.LuaDic_AddOrSetItem(t,e+1)}else this.HistoryFinishTaskLis.LuaDic_AddOrSetItem(t,1)
else{const i=a.Y.Inst.GetCreateIdxById(e)
let s=this.HistoryFinishTaskDic.LuaDic_GetItem(i)
if(null==s&&(s=new S.X,this.HistoryFinishTaskDic.LuaDic_AddOrSetItem(i,s)),s.LuaDic_ContainsKey(t)){const e=s[t]
s.LuaDic_AddOrSetItem(t,e+1)}else s.LuaDic_AddOrSetItem(t,1)}}GetReadyMainTask(){if(!this.GetMainTask()&&-1!=this.LastMainTaskId){const t=new m.Z
for(const[e,i]of(0,l.V5)(this._mainTaskDic))i.needQuestsList.Contains(this.LastMainTaskId)&&t.Add(i.id_get())
let e=-1
for(const[i,s]of(0,l.V5)(t))e<s&&(e=s)
return e}return-1}GetTaskCompletedCount(t,e){let i=this.HistoryFinishTaskLis[t]
if(null!=i&&i>=0)return i
const s=a.Y.Inst.GetCreateIdxById(e),n=this.HistoryFinishTaskDic.LuaDic_GetItem(s)
return n?(i=n[t],null!=i&&i>=0?i:0):0}IsTaskCompletedByFinShCount(t,e,i){null==i&&(i=1)
let s=this.HistoryFinishTaskLis[t]
if(null!=s&&s>=i)return!0
const n=a.Y.Inst.GetCreateIdxById(e),l=this.HistoryFinishTaskDic.LuaDic_GetItem(n)
return!!l&&(s=l[t],null!=s&&s>=i)}IsTaskCompleted(t,e){const i=this.GetConfig(t,e)
let s=this.HistoryFinishTaskLis[t]
if(null!=s&&s>=i.resource_get().completeCount)return!0
const n=a.Y.Inst.GetCreateIdxById(e),l=this.HistoryFinishTaskDic.LuaDic_GetItem(n)
return!!l&&(s=l[t],null!=s&&s>=i.resource_get().completeCount)}IsTaskCompleted2(t){const e=this.GetConfig(t,null)
let i=this.HistoryFinishTaskLis[t]
if(null!=i&&i>=e.resource_get().completeCount)return!0
for(let s=0;s<=2;s++){const n=this.HistoryFinishTaskDic.LuaDic_GetItem(s)
if(n&&(i=n[t],null!=i&&i>=e.resource_get().completeCount))return!0}return!1}OnDealyTimer(){this.m_initDelayTimerPass=!0}GetConfig(t,e){const i=a.Y.Inst.GetCreateIdxById(e)
if(i<0||null==this._taskDic[i])return void I.Y.LogError(`${e.ToString()}    查下这个角色ID`)
const s=this._taskDic[i][t]
return s||(I.Y.LogError(`${t}    查下这个任务ID`),null)}GetConfigByConsumeId(t,e,i){const s=a.Y.Inst.GetCreateIdxById(i)
if(s<0)return void I.Y.LogError(`${i.ToString()}    查下这个角色ID`)
const n=this._taskDic[s]
for(const[s,a]of(0,l.vy)(n))if(null!=a.qVo&&a.qVo.playerId.Equal(i)&&a.type_get()==t&&e==a.GetConsumeItemId())return a
return null}GetConfigsByType(t,e){const i=a.Y.Inst.GetCreateIdxById(e)
if(i<0)return null
const s=new m.Z
for(const[e,n]of(0,l.V5)(this._taskDic[i]))n.type_get()==t&&s.Add(n)
return s.Sort(this.CreateDelegate(this.TraceViewSort)),s}AddBufferTask(){let t=0
for(;t<this.taskBufferList.Count();){const e=this.taskBufferList[t]
this.AddToShow(e,!0),this.RaiseEvent(lt.M.DELAY_DO_ADD,e),t+=1}this.taskBufferList.Clear(),$.Y.SendListRefresh()}AddBufferTaskById(t){let e=-1,i=0
for(;i<this.taskBufferList.Count();){const s=this.taskBufferList[i]
if(s.id_get()==t&&null!=s.qVo){this.AddToShow(s,!0),e=i
break}i+=1}e>=0&&(this.taskBufferList.RemoveAt(e),$.Y.SendListRefresh())}HasShowConfig(t){const e=this.GetAllQuestes(),i=e.Count()
let s=0
for(;s<i;){const i=e[s]
if(null!=i&&i.id_get()==t)return!0
s+=1}return!1}ExeTask(t){$.Y.GetLinkInfo(t,null),$.Y.DealTaskReceive(t,null,null)}AddToShow(t,e){null==e&&(e=!1)
for(let e=0;e<=this.canGetTasks.Count()-1;e++){const i=this.canGetTasks[e]
if(i.questId==t.qVo.questId&&i.playerId.Equal(t.qVo.playerId)){this.canGetTasks.Remove(t.qVo.questId)
break}}const i=this.GetJudgeDicIDByPlayerId(t.qVo.questId,t.qVo.playerId)
if(this.judgeDic.LuaDic_ContainsKey(i)||this.judgeDic.LuaDic_AddOrSetItem(i,t),t.resource_get().receiveType!=st.U.RECEIVE_GET_ITEM||t.status_get()==it.B.FINISHED||e||this._isFirstInit)this.ExistTask(t)||(this.isShowLenChanged=!0,
this.AddQuest(t))
else{let e=0
for(;e<this.taskBufferList.Count();){const i=this.taskBufferList[e]
if(null!=i.qVo&&null!=t.qVo&&i.id_get()==t.id_get()&&i.qVo.playerId.Equal(t.qVo.playerId))return
e+=1}this.taskBufferList.Add(t)}}RemoveFromShow(t){v.c.Inst_get().RemovetTask(t)
const e=this.GetJudgeDicIDByPlayerId(t.qVo.questId,t.qVo.playerId)
return this.judgeDic.LuaDic_ContainsKey(e)&&this.judgeDic.LuaDic_Remove(e),this.RemoveQuest(t),this.isShowLenChanged=!0,
t.currentEffectId>0&&(h.a.ins.DeleteEffShowById(t.currentEffectId),t.currentEffectId=0),P.F.getInst().RaiseEvent(w.f.MapTaskChange,t),!0}GetChatList(){const t=new m.Z
for(const[e,i]of(0,l.V5)(this.SingleTaskList))i.status_get()!=it.B.ACCEPTED&&i.status_get()!=it.B.FINISHED||t.Add(i)
return t}getIntersectionTalk(t){return this.questTalkMap.LuaDic_ContainsKey(t)?this.questTalkMap[t]:null}SetNearGaterFlyId(){for(const[t,e]of(0,
l.V5)(this.SingleTaskList))if(e.isCollection_get()&&null!=e.tCTargetDefs_get()){
const t=e.tCTargetDefs_get().tCTargetDefs[0],i=p.M.Split(t.param.gatherPos_get(),u.o.s_Arr_UNDER_CHAR_DOT),s=new T.P(p.M.String2Float(i[1]),0,p.M.String2Float(i[2])),n=a.Y.Inst.PrimaryRole_get().GetPos()
if(n.y=0,T.P.Distance(s,n)<4){C.k.Inst_get().gatherFlyId=t.param.gatherFlyId
const e=t.param.gatherNextTask
return void(o.B.Inst.flyGotoTask=e>0?W.L.Inst_get().model.GetTaskById(e):null)}}}Reset(){this.goUIParam=null,this.hasReset=!0,this.isFirstDeal=!0,this.LastMainTaskId=-1
for(const[t,e]of(0,l.V5)(this._taskDic))for(const[t,i]of(0,l.V5)(e))i.ResetData()
this.SingleTaskList.Clear(),this.multplayerTask.LuaDic_Clear(),this.taskBufferList.Clear(),this.HistoryFinishTaskLis.LuaDic_Clear(),this.HistoryFinishTaskDic.LuaDic_Clear(),
this.judgeDic.LuaDic_Clear(),this._isFirstInit=!0,this.m_initDelayTimerPass=!1,this.canGetTasks.Clear(),this.changeJobTasks.Clear()}GetQuestCfg(t){
return y.j.GetInstance().GenGetCfgById(t)}AddQuest(t){if(t.isRoleTask())if(null!=t.qVo){const e=a.Y.Inst.GetCreateIdxById(t.qVo.playerId)
let i=this.multplayerTask.LuaDic_GetItem(e)
null==i&&(i=new m.Z,this.multplayerTask.LuaDic_Add(e,i)),i.Add(t)}else this.SingleTaskList.Add(t)
else this.SingleTaskList.Add(t)}RemoveQuest(t){if(t.isRoleTask()&&null!=t.qVo){const e=a.Y.Inst.GetCreateIdxById(t.qVo.playerId),i=this.multplayerTask.LuaDic_GetItem(e)
null!=i&&(t.qVo=null,i.Remove(t),this.TopTaskSortListRemove(t.resource_get().id+(u.o.s_UNDER_CHAR+e)))}else t.qVo=null,this.SingleTaskList.Remove(t),
this.TopTaskSortListRemove(t.resource_get().id+(u.o.s_UNDER_CHAR+0))
t.GetTopState()&&t.SetTopState(!1)}ExistTask(t){return t.isRoleTask()&&null!=t.qVo?this.ExistInMultiTask(t.qVo.playerId,t.qVo.questId):this.ExistInSingleTask(t.m_resource.id)}
ExistTask2(t,e){const i=this.GetConfig(t,e)
return this.ExistTask(i)}ExistInSingleTask(t){for(const[e,i]of(0,l.vy)(this.SingleTaskList))if(i.m_resource.id==t)return!0}ExistInMultiTask(t,e){
const i=a.Y.Inst.GetCreateIdxById(t),s=this.multplayerTask.LuaDic_GetItem(i)
if(null==s)return!1
for(const[t,i]of(0,l.vy)(s))if(i.m_resource.id==e)return!0
return!1}GetTraceViewQuestes(){const t=this.GetAllQuestes()
return t.Sort(((t,e)=>this.TraceViewSort(t,e))),t}TraceViewSort(t,e){const i=t.status_get(),s=e.status_get()
if(i>s)return-1
if(i<s)return 1
const n=this.GetTaskTypeIndex(t.m_resource.type),l=this.GetTaskTypeIndex(e.m_resource.type)
if(n<l)return-1
if(n>l)return 1
if(t.m_resource.sort<e.m_resource.sort)return-1
if(t.m_resource.sort>e.m_resource.sort)return 1
if(t.m_resource.id<e.m_resource.id)return-1
if(t.m_resource.id>e.m_resource.id)return 1
if(null!=t.qVo&&null!=e.qVo){return a.Y.Inst.GetCreateIdxById(t.qVo.playerId)-a.Y.Inst.GetCreateIdxById(e.qVo.playerId)}return 0}TopTaskSort(t,e){
const i=t.GetTopState(),s=e.GetTopState()
if(i||s){if(i!=s)return i?-1:1
let n=0,l=0
null!=t.qVo&&(n=a.Y.Inst.GetCreateIdxById(t.qVo.playerId)),null!=e.qVo&&(l=a.Y.Inst.GetCreateIdxById(e.qVo.playerId))
const r=this.GetTopSort(t.m_resource.id,n),o=this.GetTopSort(e.m_resource.id,l)
if(r<o)return-1
if(r>o)return 1}const n=t.status_get(),l=e.status_get()
if(n>l)return-1
if(n<l)return 1
const r=this.GetTaskTypeIndex(t.m_resource.type),o=this.GetTaskTypeIndex(e.m_resource.type)
if(r<o)return-1
if(r>o)return 1
if(t.m_resource.sort<e.m_resource.sort)return-1
if(t.m_resource.sort>e.m_resource.sort)return 1
if(t.m_resource.id<e.m_resource.id)return-1
if(t.m_resource.id>e.m_resource.id)return 1
if(null!=t.qVo&&null!=e.qVo){return a.Y.Inst.GetCreateIdxById(t.qVo.playerId)-a.Y.Inst.GetCreateIdxById(e.qVo.playerId)}return 0}GetTopSort(t,e){
const i=t+(u.o.s_UNDER_CHAR+p.M.IntToString(e))
return null==this.topListSortData[i]?(I.Y.LogError(`任务置顶报错！！！${i}`),9999):this.topListSortData[i]}GetAllQuestes(){const t=new m.Z
t.AddRange(this.SingleTaskList)
for(const[e,i]of(0,l.vy)(this.multplayerTask))t.AddRange(i)
return t}IsFixStepOrFixAttr(t,e){const i=this.GetConfig(t,e)
return null!=i&&null!=i.qVo&&i.IsFixStepOrFixAttr()}GetFromSingleTaskList(t){for(const[e,i]of(0,l.vy)(this.SingleTaskList))if(i.m_resource.id==t)return i
return null}GetTaskTypeIndex(t){let e=this.questTypeIndex.IndexOf(t)
return-1==e&&(e=999),e}GetJudgeDicIDByPlayerId(t,e){return 1e8*(a.Y.Inst.GetCreateIdxById(e)+1)+t}GetJudgeDicIDByPlayerIndex(t,e){return 1e8*(e+1)+t}InformDoAdd(t){
if(null==t)return
t.type_get()==nt.U.MANUAL&&(d.i.Inst.RaiseEvent(E.g.MANUAL_UPDATYACHALLENGE,null),t.status_get()==it.B.FINISHED&&R.f.Inst.SetState(O.t.MANUAL_CHALLENGE,!0)),
this.RaiseEvent(lt.M.INFORM_DO_ADD,t)}InformDoUpdata(t){if(!t)return
t.type_get()==nt.U.MANUAL&&(d.i.Inst.RaiseEvent(E.g.MANUAL_UPDATYACHALLENGEITEM,t),t.status_get()==it.B.FINISHED&&R.f.Inst.SetState(O.t.MANUAL_CHALLENGE,!0)),
this.RaiseEvent(lt.M.INFORM_DO_UPDATA,t)}InformDoRemove(t){if(!t)return
t.type_get()==nt.U.MANUAL&&(d.i.Inst.RaiseEvent(E.g.MANUAL_UPDATYACHALLENGE,null),L.q.GetInst().UpdateRedPoint()),this.RaiseEvent(lt.M.INFORM_DO_REMOVE,t)}IsCanGetTask(t){
let e=this.GetConfig(t,null)
if(null==e)return!1
if(!e.isRoleTask())return e.status_get()==it.B.CAN_ACCEPT
for(let i=0;i<=2;i++)return e=this.GetTaskByIdAndPlayIndex(t,i),!(!e||e.status_get()!=it.B.CAN_ACCEPT)}TopTaskSortListUpdate(){
const t=N.p.inst.GetClientLogicSetting(M.R.TASK_TOP_SORTLIST)
this.topListSortData.Clear()
for(let e=0;e<=t.Count()-1;e++)""!=t[e]&&this.topListSortData.LuaDic_AddOrSetItem(t[e],e)}TopTaskSortListSet(t){const e=new m.Z
for(let i=0;i<=t.Count()-1;i++){const s=t[i]
e.Add(s)}const i=new m.Z
for(const[t,e]of(0,l.V5)(this.topListSortData))i.Add(t)
i.Sort(((t,e)=>{const i=this.topListSortData[t]||0,s=this.topListSortData[e]||0
return i<s?-1:i>s?1:0})),e.AddRange(i),this.topListSortData.Clear()
for(let t=0;t<=e.Count()-1;t++){const i=e[t]
this.topListSortData.LuaDic_ContainsKey(i)||this.topListSortData.LuaDic_AddOrSetItem(i,t)}N.p.inst.SendClientLogicSetting(M.R.TASK_TOP_SORTLIST,e,!1)}TopTaskSortListRemove(t){
const e=new m.Z
for(const[i,s]of(0,l.V5)(this.topListSortData))t!=i&&e.Add(i)
e.Sort(((t,e)=>{const i=this.topListSortData[t]||0,s=this.topListSortData[e]||0
return i<s?-1:i>s?1:0})),this.topListSortData.Clear()
for(let t=0;t<=e.Count()-1;t++){const i=e[t]
this.topListSortData.LuaDic_AddOrSetItem(i,t)}N.p.inst.SendClientLogicSetting(M.R.TASK_TOP_SORTLIST,e,!1)}GetAllCharacterTargetDef(t){t.resource_get().id
const e=a.Y.Inst.primaryRoleInfoList,i=t.GetConsumeItemId()
let s=0
for(const[n,a]of(0,l.vy)(e)){const e=this.GetConfigByConsumeId(nt.U.CHANGE_JOB,i,a.m_id)
null!=e&&null!=e.qVo&&(s+=t.GetNowTargetDef().value)}return s}},et._mInst=null,Ot=tt=et,Rt="ins",Nt=[s.Vx],Mt=Object.getOwnPropertyDescriptor(tt,"ins"),wt=tt,Pt={},
Object.keys(Mt).forEach((function(t){Pt[t]=Mt[t]})),Pt.enumerable=!!Pt.enumerable,Pt.configurable=!!Pt.configurable,("value"in Pt||Pt.initializer)&&(Pt.writable=!0),
Pt=Nt.slice().reverse().reduce((function(t,e){return e(Ot,Rt,t)||t}),Pt),wt&&void 0!==Pt.initializer&&(Pt.value=Pt.initializer?Pt.initializer.call(wt):void 0,
Pt.initializer=void 0),void 0===Pt.initializer&&(Object.defineProperty(Ot,Rt,Pt),Pt=null),z=tt))||z
var Ot,Rt,Nt,Mt,wt,Pt},72795:(t,e,i)=>{i.d(e,{w:()=>o})
var s=i(86133),n=i(98800),l=i(29839),a=i(22662),r=i(65550)
class o{constructor(){this.taskConfig=null,this._degf_DoLeaveAndCreateTeam=null,this._degf_DoSingleEnterCopy=null,this._degf_DoLeaveAndCreateTeam=t=>this.DoLeaveAndCreateTeam(t),
this._degf_DoSingleEnterCopy=t=>this.DoSingleEnterCopy(t)}static Inst_get(){return null==o._inst&&(o._inst=new o),o._inst}OnSingleEnterCopy(t){this.taskConfig=t
const e=new CommonTipVo
e.titleText=(0,s.T)("提示"),e.showText=(0,s.T)("该副本难度较大，建议组队前往\n是否确认单人进入？"),e.cancelText=(0,s.T)("再想想"),e.okText=(0,s.T)("确定"),e.tipstype=2,e.btnColorType=1,
e.okhandler=this._degf_DoSingleEnterCopy,r.y.inst.OpenCommonMessageTips(e)}DoSingleEnterCopy(t){if(!this.CanEnterCopy(!1))return
const e=this.GetCopyId()
l.p.inst.SendEnterCopy(e)}OnTeamEnterCopy(t){this.taskConfig=t
n.Y.Inst.PrimaryRoleInfo_get().isHaveTeam_get()}DoLeaveAndCreateTeam(t){}DoTeamEnterCopy(){if(!this.CanEnterCopy(!0))return
const t=this.GetCopyId()
l.p.inst.CM_ApplyTeamCopyOp(!1,t)}OnRecruitNpc(t){}GetCopyId(){return null==this.taskConfig?0:this.taskConfig.TargetDefCopyId_get()}GetTargetType(){return 0}CanEnterCopy(t){
return n.Y.Inst.PrimaryRole_get().Isdead_get()?(r.y.inst.ClientStrMsg(a.r.SystemTipMessage,(0,s.T)("死亡状态下不能进入副本")),
!1):l.p.inst.IsInCopy()?(r.y.inst.ClientStrMsg(a.r.SystemTipMessage,(0,s.T)("当前处于副本中，不能进入！")),
!1):null!=this.taskConfig&&(this.taskConfig.status_get()!=MyTaskStatus.CAN_ACCEPT||(r.y.inst.ClientStrMsg(a.r.SystemTipMessage,(0,s.T)("任务不存在")),!1))}}o._inst=null},
84587:(t,e,i)=>{i.d(e,{T:()=>E})
var s=i(18202),n=i(31222),l=i(5494),a=i(38836),r=i(68662),o=i(5924),h=i(6665),d=i(86290),_=i(61911),u=i(85602),I=i(79534),c=i(23833),g=i(99294),p=i(9057),m=i(63062),S=i(93877),T=i(72005)
class f extends p.x{constructor(...t){super(...t),this.mask=null,this.icon=null,this.name=null,this.time=null,this.hp=null,this.job=null,this.data=null}InitView(){
this.mask=new g.z,this.mask.setId(this.FatherId,null,1),this.icon=new T.w,this.icon.setId(this.FatherId,null,2),this.name=new S.Q,this.name.setId(this.FatherId,null,3),
this.time=new S.Q,this.time.setId(this.FatherId,null,4),this.hp=new m.p,this.hp.setId(this.FatherId,null,5),this.job=new T.w,this.job.setId(this.FatherId,null,6)}SetData(t){
this.data=t
const e=c.a.getInst().getObjById(this.data.npc.monsterId)
this.icon.spriteNameSet(e.headResources),this.name.textSet(e.name),this.job.nameSet(this.data.npc.jobIcon),this.UpdateHp(),this.UpdateTime()}Clear(){this.data=null}Destroy(){
this.mask=null,this.icon=null,this.name=null,this.time=null,this.hp=null,this.job=null}UpdateTime(){this.mask.SetActive(0!=this.data.dieBeginTime),
this.time.node.SetActive(0!=this.data.dieBeginTime),this.data.dieBeginTime}UpdateHp(){this.hp.DoF_SetValueEx(this.data.currentHp,this.data.maxHp)}}class C extends _.f{
constructor(){super(),this.npcTrans=null,this.npcGrid=null,this.timeId=0,this._degf_CreateHeadItem=null,this._degf_UpdateTime=null,
this._degf_CreateHeadItem=t=>this.CreateHeadItem(t),this._degf_UpdateTime=()=>this.UpdateTime()}InitView(){this.npcTrans=new d.G,this.npcTrans.setId(this.FatherId,null,1),
this.npcGrid=new h.A,this.npcGrid.setId(this.FatherId,null,2),this.npcGrid.SetInitInfo("ui_npchead_item",this._degf_CreateHeadItem)}OnAddToScene(){
this.npcGrid.data_set(this.GetHeadItemDataList())
const t=new I.P(-281,290,0)
this.npcTrans.SetLocalPosition(t),I.P.Recyle(t),this.timeId=o.C.Inst_get().SetInterval(this._degf_UpdateTime,1e3)}Clear(){o.C.Inst_get().ClearInterval(this.timeId),this.timeId=0}
Destroy(){this.npcTrans=null,this.npcGrid.Destroy(),this.npcGrid=null}UpdateTime(){for(const[t,e]of(0,a.V5)(this.npcGrid.itemList))e.UpdateTime()}CreateHeadItem(t){const e=new f
return e.setId(t,null,0),e}GetHeadItemDataList(){const t=new u.Z
E.Inst_get().copyId
return t}NpcLifeChange(t,e){let i=0
e&&(i=r.D.serverMSTime_get())
const s=this.GetHeadItemData(t)
null!=s&&(s.dieBeginTime=i)
const n=this.GetHeadItemObj(t)
null!=n&&(n.data.dieBeginTime=i,n.UpdateTime())}NpcHpChange(t,e){const i=this.GetHeadItemData(t)
null!=i&&(i.currentHp=e)
const s=this.GetHeadItemObj(t)
null!=s&&(s.data.currentHp=e,s.UpdateHp())}NpcMaxHpChange(t,e){const i=this.GetHeadItemData(t)
null!=i&&(i.maxHp=e)
const s=this.GetHeadItemObj(t)
null!=s&&(s.data.maxHp=e,s.UpdateHp())}GetHeadItemData(t){for(const[e,i]of(0,a.V5)(this.npcGrid.data_get()))if(i.npc.monsterId==t)return i
return null}GetHeadItemObj(t){for(const[e,i]of(0,a.V5)(this.npcGrid.itemList))if(i.data.npc.monsterId==t)return i
return null}}class E{constructor(){this.view=null,this.copyId=0,this._degf_CallDestory=null,this._degf_Complete=null,this._degf_CallDestory=()=>this.CallDestory(),
this._degf_Complete=t=>this.Complete(t)}static Inst_get(){return null==E._inst&&(E._inst=new E),E._inst}OpenView(t){null!=this.view&&this.view.isShow_get()||(this.copyId=t,
n.N.inst.OpenById(l.I.NpcHeadPanel,this._degf_Complete,this._degf_CallDestory))}Complete(t){return null==this.view&&(this.view=new C,this.view.setId(t,null,0)),this.view}
CallDestory(){s.g.DestroyUIObj(this.view),this.view=null}CloseView(){null!=this.view&&this.view.isShow_get()&&(n.N.inst.CloseById(l.I.NpcHeadPanel),this.copyId=0)}
NpcLifeChange(t,e){this.CanUpdateNpc(t)&&this.view.NpcLifeChange(t,e)}NpcHpChange(t,e){this.CanUpdateNpc(t)&&this.view.NpcHpChange(t,e)}NpcMaxHpChange(t,e){
this.CanUpdateNpc(t)&&this.view.NpcMaxHpChange(t,e)}CanUpdateNpc(t){return!(null==this.view||!this.view.isShow_get())}}E._inst=null}}])
