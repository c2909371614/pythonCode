"use strict";(globalThis.webpackChunkProject=globalThis.webpackChunkProject||[]).push([[831],{60917:(t,e,i)=>{i.d(e,{P:()=>s})
class s{constructor(){this.type="",this.intType=0,this.value=0,this.extend="",this.job="",this.intJob=0,this.rate=0}Clear(){this.type="",this.intType=0,this.value=0,this.extend="",
this.job="",this.intJob=0,this.type="",this.extend="",this.job="",this.rate=0}Clone(){const t=new s
return t.type=this.type,t.intType=this.intType,t.value=this.value,t.job=this.job,t.intJob=this.intJob,t}}},52429:(t,e,i)=>{i.d(e,{L:()=>_})
var s=i(86133),n=i(90419),l=i(50089),a=i(66788),o=i(98130),r=i(98885),h=i(85602),d=i(17838),u=i(60917),c=i(44498)
class _{constructor(){this.attrs=null,this.starAttr=void 0}FillData(t){this.attrs=new h.Z
const e=new h.Z(t.attrs)
let i=0
for(;i<e.Count();){const t=e[i],s=new u.P
s.type=o.GF.LuaJsonToString(t.type),s.intType=o.GF.LuaJsonToNumber(t.intType),s.value=o.GF.LuaJsonToNumber(t.value),s.extend=o.GF.LuaJsonToString(t.extend),
s.job=o.GF.LuaJsonToString(t.job),s.intJob=o.GF.LuaJsonToNumber(t.intJob),this.attrs.Add(s),i+=1}}parse(){if(null==this.attrs)return
let t=0
for(;t<this.attrs.Count();)this.attrs[t].intType=c.I.GetAttrByStr(this.attrs[t].type),this.attrs[t].intJob=r.M.String2Int(this.attrs[t].job),
-1==this.attrs[t].intType&&a.Y.LogError((0,s.T)("属性没有配置映射关系：")+this.attrs[t].type),t+=1}GetAttrValByType(t){if(null!=this.attrs&&this.attrs.Count()>0){let e=0
for(;e<this.attrs.Count();){if(this.attrs[e].intType==t)return this.attrs[e].value
e+=1}}return 0}Clone(){const t=new _,e=new h.Z
if(null!=this.attrs){let i=0
for(;i<this.attrs.Count();){const t=this.attrs[i].Clone()
e.Add(t),i+=1}t.attrs=e}return t}GetAttList(){const t=new h.Z
let e=0
for(;e<this.attrs.Count();)t.Add(this.attrs[e]),e+=1
return t}static CreateFromJson(t){const e=new _
e.attrs=new h.Z
for(let i=0;i<=t.length-1;i++){const s=new u.P
d.g.FillJsonData(s,t[i],!0),e.attrs.Add(s)}return e}valueOf(t){const e=n.d.parseJsonObjectWithFix(t,"attrs"),i=l.t.decode(e,_)
return i.parse(),i}}},44498:(t,e,i)=>{i.d(e,{I:()=>Ft})
var s=i(38836),n=i(86133),l=i(38045),a=i(62370),o=i(35128),r=i(98130),h=i(98885),d=i(85602),u=i(72785),c=i(38962),_=i(59918),I=i(77477),m=i(85751),g=i(87923)
class p{}p.WEAPON=0,p.SUBWEAPON=1,p.NECKLACE=2,p.RINGS=3,p.DEFENSEEQUIP=4
var C=i(56956),S=i(41850),f=i(93984),y=i(55360),v=1,D=2,E=3,T=4,A=5,L=6,w=7,R=8,O=9,G=10,b=11,M=12,P=13,B=14,x=15,N=16,k=17,V=18,F=19,U=20,H=1,q=2,Z=3,j=4,X=5,Y=6,W=7,$=8,J=9,z=10,Q=11,K=12,tt=13,et=14,it=15,st=16,nt=17,lt=18,at=19,ot=20,rt=21,ht=22,dt=23,ut=24,ct=25,_t=26,It=27,mt=28,gt=29,pt=30,Ct=31,St=32,ft=33,yt=34,vt=35,Dt=36,Et=37,Tt=38,At=39,Lt=40,wt=41,Rt=42,Ot=43,Gt=44
class bt{static GetEnhanceTypeByStr(t){
return"SINGLEWEAPON"==t?H:"DOUBLEWEAPON"==t?q:"MAINWEAPON"==t?Z:"SUBWEAPON"==t?j:"HAT"==t?X:"CLOTHES"==t?Y:"GLOVES"==t?W:"PANTS"==t?$:"BOOTS"==t?J:"ICENECKLACE"==t?z:"THUNDERNECKLACE"==t?Q:"POISONNECKLACE"==t?K:"ICERINGS"==t?tt:"THUNDERRINGS"==t?et:"POISONRINGS"==t?it:"WINGS"==t?st:"ANGELWEAPON"==t?nt:"ANGELCLOTHES"==t?lt:"MAGICSUBWEAPON"==t?at:"PHYSICSUBWEAPON"==t?ot:"GROW_RING_ATTACK"==t?rt:"GROW_RING_DEFENSE"==t?ht:"WATER_RING"==t?dt:"WING_RING"==t?ut:"FIRE_RING"==t?ct:"SOIL_RING"==t?_t:"THUNDER_RING"==t?It:"ICE_RING"==t?mt:"WATER_NECKLACE"==t?gt:"WING_NECKLACE"==t?pt:"SOIL_NECKLACE"==t?Ct:"FIRE_NECKLACE"==t?St:"SECOND_WING"==t?ft:"THREE_WING"==t?yt:"LIGHT_RING"==t?vt:"DARK_RING"==t?Dt:"HOLY_NECKLACE"==t?Et:"FIVE_RINGSONE"==t?Tt:"FIVE_RINGSTWO"==t?At:"FIVE_NECKLACE"==t?Lt:"FOUR_WINGS"==t?wt:"SIX_RINGSONE"==t?Rt:"SIX_RINGSTWO"==t?Ot:"SIX_NECKLACE"==t?Gt:1
}static GetAddTypeByStr(t){
return"SINGLEWEAPON"==t?v:"DOUBLEWEAPON"==t?D:"MAINWEAPON"==t?E:"SUBWEAPON"==t?T:"HAT"==t?A:"CLOTHES"==t?L:"GLOVES"==t?w:"PANTS"==t?R:"BOOTS"==t?O:"ICENECKLACE"==t?G:"THUNDERNECKLACE"==t?b:"POISONNECKLACE"==t?M:"ICERINGS"==t?P:"THUNDERRINGS"==t?B:"POISONRINGS"==t?x:"WINGS"==t?N:"ANGELWEAPON"==t?k:"ANGELCLOTHES"==t?V:"MAGICSUBWEAPON"==t?F:"PHYSICSUBWEAPON"==t?U:1
}}class Mt{constructor(){this.EquipEnhanceTypeMap=null,this.EquipEnhanceTypeMap=new c.X
const t=y.Y.Inst.GetOrCreateCsv(f.h.eEnhanceType)
this.EquipEnhanceTypeMap=t.GetCsvMap()}static Inst(){return null==Mt._inst&&(Mt._inst=new Mt),Mt._inst}getItemById(t){return this.EquipEnhanceTypeMap[t]}getAttrsByEnhanceType(t){
const e=new d.Z,i=bt.GetEnhanceTypeByStr(t),s=this.getItemById(i)
return 1==s.phyAttack_Max&&e.Add(r.GF.INT(I.Z.PhyAttack_Max)),1==s.phyAttack_Min&&e.Add(r.GF.INT(I.Z.PhyAttack_Min)),1==s.defense&&e.Add(r.GF.INT(I.Z.Defense)),
1==s.maxHp&&e.Add(r.GF.INT(I.Z.MaxHp)),1==s.dodgeRate&&e.Add(r.GF.INT(I.Z.DodgeRate)),1==s.attackRate&&e.Add(r.GF.INT(I.Z.AttackRate)),
1==s.equipDodgeRateAddRate&&e.Add(r.GF.INT(I.Z.EquipDodgeRateAddRate)),1==s.moveSpeed&&e.Add(r.GF.INT(I.Z.MoveSpeed)),1==s.damageUp&&e.Add(r.GF.INT(I.Z.DamageUp)),
1==s.damageDown&&e.Add(r.GF.INT(I.Z.DamageDown)),1==s.attack&&e.Add(r.GF.INT(I.Z.Attack)),1==s.attackSpeed&&e.Add(r.GF.INT(I.Z.AttackSpeed)),
1==s.expAdd&&e.Add(r.GF.INT(I.Z.ExpAdd)),1==s.hpRate&&e.Add(r.GF.INT(I.Z.HpRate)),1==s.skillDamageUp&&e.Add(r.GF.INT(I.Z.SkillDamageUp)),
1==s.ignoreHit&&e.Add(r.GF.INT(I.Z.IgnoreHit)),1==s.hpAutoRecoverRate&&e.Add(r.GF.INT(I.Z.HpAutoRecoverRate)),1==s.criticalHitRate&&e.Add(r.GF.INT(I.Z.CriticalHitRate)),
1==s.excellentHitRate&&e.Add(r.GF.INT(I.Z.ExcellentHitRate)),1==s.ignoreHitResistanceRate&&e.Add(r.GF.INT(I.Z.IgnoreHitResistanceRate)),
1==s.beTreatmentEffectUpRate&&e.Add(r.GF.INT(I.Z.BeTreatmentEffectUpRate)),1==s.defenseRate&&e.Add(r.GF.INT(I.Z.DefenseRate)),e}}Mt._inst=null
var Pt=i(14666),Bt=i(33833),xt=i(75439),Nt=i(42534),kt=i(56614),Vt=i(60917)
class Ft{static GetAttrByStr(t){return I.Z.GetAttrKey(t)}static GetAttrStrByStr(t){return g.l.getAttrStrWithoutSign(Ft.GetAttrByStr(t))}static GetOkFormatAttrVal(t,e){
const i=Bt.X.Inst().getItemById(Ft.GetAttrByStr(t))
let s=""
return null!=i?1==i.valueType?s=h.M.DoubleToString(e):2==i.valueType?s=h.M.FloatToString(e/100)+a.o.s_UNDER_PERCENT:3==i.valueType&&(s=h.M.DoubleToString(e)+a.o.s_UNDER_PERCENT):u.c.DebugError(`${(0,
n.T)("AttributeResource表中没有这个ID")}${Ft.GetAttrByStr(t)} ${t}`),s}static GetCompleteAttrVal(t,e){let i=Ft.GetOkFormatAttrVal(t,e)
if(""!=i){const e={}
table.insert(e,Ft.GetAttrStrByStr(t)),table.insert(e,h.M.s_SPACE_CHAR+a.o.s_ADD_STR),table.insert(e,i),i=table.concat(e)}return i}static Score(t,e,i){
return null==t?0:t.socre_get(e,i)}static InitScore(t,e){return null==t?0:t.initScore_get(e)}static GetTotalEquipScore(t){let e=0
const i=t.GetEquipmentsByColumn()
if(null!=i){const s=i.equipmentsGet()
if(null!=s){let i=0
for(;i<s.Count();)null!=s[i]&&(e+=Ft.GetEquipmentScoreValue(s[i],t.Job_get(),t)),i+=1}}return e}static GetSocreValue(t=null,e=null,i=null){let s=null,n=0
return s=(0,l.Z)(t.serverData_get(),kt.I),n+=Ft.GetEquipSocre(s,t.equipRes_get(),e,!1,i,t.equipInfo_get()),o.p.RoundToInt(n)}static GetInitSocreValue(t,e){
return t.equipRes_get().score}static GetEquipmentScoreValue(t,e,i){let s=0
return s=Ft.GetEquipSocre(t,null,e,!1,i),o.p.RoundToInt(s)}static GetSuitScore(t,e,i){if(!t||!e)return 0
if(null!=t&&0==t.suitId||i){let s,n=t.GetEquipRes().wearPosition_get(),l=1
if(null!=t&&(n=t.Pos_Get(),l=t.Column_Get()),s=null!=i?i:e.GetSuitEquipmentByColumnAndPos(l,n),s)return Ft.GetEquipmentScoreValue(s,null,e)}return 0}
static GetBaseSocreValueByCfg(){}static GetEquipSocre(t,e,i,s,n,l){if(null==s&&(s=!1),null==e&&null!=t&&(e=t.GetEquipRes()),null==e)return 0
let a=e.score
return a+=Ft.GetExcellenceScoreByType(t,e),null==t?null!=l&&l.isOutOfPrint?a+e.GetSoleAttrScore():a:(null==i&&(i=t.GetItemRes().job),
s||(null!=t.specialAdd&&null!=t.specialAdd.ignoreAttributes&&t.specialAdd.ignoreAttributes.Count()>0&&(a+=xt.D.getInstance().GetIntValue("SCORE_IGNOREHIT")),
null!=t&&t.isOutOfPrint&&(a+=e.GetSoleAttrScore())),o.p.RoundToInt(a))}static GetSocreValueByEquipment(t,e,i,s){return Ft.GetEquipSocre(t,null,e,i,s)}static GetScoreByBaseAttrs(t){
let e=0
for(const[i,n]of(0,s.vy)(t.attrs))n.intType==I.Z.Attack||n.intType==I.Z.Defense?e+=30*n.value:n.intType==I.Z.MaxHp?e+=1.5*n.value:n.intType==I.Z.DodgeRate?e+=90*n.value:n.intType==I.Z.SkillDamageUp?e+=12*n.value:n.intType==I.Z.SkillDamageDown?e+=10*n.value:n.intType==I.Z.ExpAdd&&(e+=2*n.value)
return e}static GetAddScoreEx(t){t.GetEquipRes()
return t.equipmentAdd,0}static GetEnhanceScoreEx(t){const e=t.GetEquipRes()
let i=0
const s=Mt.Inst().getAttrsByEnhanceType(e.enhanceType),n=S.C.Inst().getResByColumnPosLevel(t.Column_Get(),t.Pos_Get(),t.Enhancelevel_get())
let l=null
if(null==n)return i
l=null!=t.exellectAttrs&&null!=t.exellectAttrs.attributes&&0!=t.exellectAttrs.attributes.Count()||t.suitId>0||"WINGS"==e.enhanceType?n.exellectScoreAddDic:n.scoreAddDic
let a=0
for(;a<s.Count();)l.LuaDic_ContainsKey(s[a])&&(i+=l[s[a]]),a+=1
return i}static GetExcellenceScoreByType(t,e){let i=0
if(null!=t){if(null!=t.exellectAttrs&&null!=t.exellectAttrs.attributes&&null!=t.exellectAttrs.attributeDatas){for(const[e,n]of(0,s.V5)(t.exellectAttrs.attributeDatas))i+=n.score
return i}e=t.GetEquipRes()}if(null!=e){const t=e.fixExcellenceAttrs_get().attrs
for(const[n,l]of(0,s.V5)(t)){const t=Pt.g.Inst().getItemByAttr(l.intType,l.value,e.GetStage())
t&&t.score&&(i+=t.score)}}return i}static ScoreByAttrs(t){let e=0
e=Ft.GetAttrByAttrs(t,r.GF.INT(I.Z.MaxHp)),e+=12*Ft.GetAttrByAttrs(t,r.GF.INT(I.Z.Attack)),e+=12*Ft.GetAttrByAttrs(t,r.GF.INT(I.Z.Defense)),
e+=r.GF.INT(.1*Ft.GetAttrByAttrs(t,r.GF.INT(I.Z.MaxMp)))
const i=Ft.GetAttrByAttrs(t,r.GF.INT(I.Z.DodgeRate))+1660,s=Ft.GetAttrByAttrs(t,r.GF.INT(I.Z.DodgeRate))
e+=r.GF.INT(1*s/i*9120),e+=Ft.GetAttrByAttrs(t,r.GF.INT(I.Z.AttackSpeed))
const n=Ft.GetAttrByAttrs(t,r.GF.INT(I.Z.DamageDown)),l=Ft.GetAttrByAttrs(t,r.GF.INT(I.Z.DamageUp))
return e+=r.GF.INT(800*(n/1e4+l/1e4)*12),e+=r.GF.INT(Ft.GetAttrByAttrs(t,r.GF.INT(I.Z.IgnoreHit))/1e4*48e3),e}static ExcellenceScoreByAttrsList(t){
const e=Ft.GetExcellenceScoreByType(t)
return o.p.RoundToInt(e)}static AddAttrList(t,e){let i=0
for(;i<e.Count();){let s=!1,n=0
for(;n<t.Count();){if(t[n].intType==e[i].intType){t[n].value=Number(t[n].value)+Number(e[i].value),s=!0
break}n+=1}if(!s){const s=new Vt.P
s.intType=e[i].intType,s.value=Number(e[i].value),t.Add(s)}i+=1}}static GetPropertyCount(t){let e=t.Count()
const i=new d.Z
for(const[e,n]of(0,s.V5)(t))i.Add(n.intType)
return i.Contains(r.GF.INT(I.Z.PhyAttack_Max))&&i.Contains(r.GF.INT(I.Z.PhyAttack_Min))&&(e-=1),e}static GetAttrByAttrs(t,e){for(const[i,n]of(0,
s.V5)(t))if(n.intType==e)return n.value
return 0}static GetEnhanceAttrsByColumnPosAndLevel(t,e,i,n){if(!n)return new c.X
const l=new c.X
let a=null
const o=S.C.Inst().getResByColumnPosLevel(t,e,i)
if(null==o)return l
a=o.attrAddDic
const r=new d.Z
for(const[t,e]of(0,s.V5)(a))r.Add(t)
r.Sort(Ft.SortType)
let h=0
for(;h<r.Count();)l.LuaDic_AddOrSetItem(r[h],a[r[h]]),h+=1
return l}static GetEnhanceNewAttrsByEnhanceTypeAndEnhanceLevel(t,e,i,n){if(!n)return new c.X
const l=new c.X
let a=null
const o=S.C.Inst().getResByColumnPosLevel(1,t,i)
if(null==o)return l
a=o.attrNewDic
const r=new d.Z
for(const[t,e]of(0,s.V5)(a))r.Add(t)
r.Sort(Ft.SortType)
let h=0
for(;h<r.Count();)l.LuaDic_AddOrSetItem(r[h],a[r[h]]),h+=1
return l}static GetSoulAttrsByLocationAndEnhanceLevel(t,e,i,n){if(!n)return new c.X
const l=new c.X
let a=null
const o=S.C.Inst().getResByLevel(t,e,i)
if(null==o)return l
a=o.soulAttrDic
const r=new d.Z
for(const[t,e]of(0,s.V5)(a))r.Add(t)
r.Sort(Ft.SortType)
let h=0
for(;h<r.Count();)l.LuaDic_AddOrSetItem(r[h],a[r[h]]),h+=1
return l}static GetAddtionAttrsByLevel(t,e,i){let s=new c.X
new d.Z
return s=C.O.Inst().GetAttrsByLevel(t,e,i),s}static GetaddNewAttrsByLevel(t,e,i){let s=new c.X
const n=new d.Z
return s=C.O.Inst().GetAttrsByLevel(t,e,i,n,!0),s}static SortType(t,e){return t>e?1:t<e?-1:0}static SortAttr(t,e){return t.intType>e.intType?1:t.intType<e.intType?-1:0}
static GetEquipStarsNum(t){if(null!=t&&null!=t.exellectAttrs&&null!=t.exellectAttrs.attributeDatas){
const e=Nt.f.Inst().getItemById(t.modelId),i=g.l.GetAddvanceTypeByPos(e.intPosition_get())
if(i==p.SUBWEAPON||i==p.DEFENSEEQUIP||i==p.RINGS){if(t.GetExcellenceAttrVal(r.GF.INT(I.Z.HpRate))>0&&t.GetExcellenceAttrVal(r.GF.INT(I.Z.DamageDown))>0)return 1}else{
if(i!=p.WEAPON&&i!=p.NECKLACE)return 0
if(t.GetExcellenceAttrVal(r.GF.INT(I.Z.ExcellentHitRate))>0&&t.GetExcellenceAttrVal(r.GF.INT(I.Z.AttackSpeed))>0)return 1}}return 0}static IsEquipAttrStar(t,e){return!0}
static GetEquipAttrStarCount(t){let e=0
if(t.GetEquipRes().equipType==_.R.WINGS&&t.GetEquipRes().equipType==_.R.GUARD)return-1
if(null!=t.exellectAttrs&&null!=t.exellectAttrs.attributeDatas){let i=0
for(;i<t.exellectAttrs.attributeDatas.Count();){t.exellectAttrs.attributeDatas[i].CheckStar(t)&&(e+=1),i+=1}0==e&&t.exellectAttrs.attributeDatas.Count()>0&&(e=-2)}return e}
static GetExeAttrsNum(t){if(null!=t.exellectAttrs&&null!=t.exellectAttrs.attributeDatas){return t.exellectAttrs.attributeDatas.Count()}return 0}static IsExeEquipHasType(t,e){
if(null!=t.exellectAttrs){const i=Ft.GetAttrByStr(e)
for(const[e,n]of(0,s.V5)(t.exellectAttrs.attributes))if(i==n.attributeType)return!0}return!1}static IsExeEquip(t){return Ft.GetExeAttrsNum(t)>0}static GetAttrsByDic(t,e){
const i=new d.Z
for(const[e,n]of(0,s.vy)(t)){const s=new Vt.P
s.intType=e,s.value=t[e],i.Add(s)}return e&&i.Sort(Ft.SortAttr),i}static isFirstClassAttr(t){return t==I.Z.Strength||t==I.Z.Vitality||t==I.Z.Agility||t==I.Z.Intelligence}
static GetFirstClassAttrKey(){return Ft.FirstClassAttr}static isSpecialAttr(t){const e=Bt.X.Inst().getItemById(t)
return null!=e&&!g.l.IsEmptyStr(e.tipPrefix)}static GetIntAttrType(t){return Bt.X.Inst().getItemByName(t).id}static GetAttrIntType(t){
return"Strength"==t?1:"Vitality"==t?2:"Agility"==t?3:"Intelligence"==t?4:0}static GetAttrName(t){return t==Ft.Strength?(0,n.T)("力量"):t==Ft.Vitality?(0,n.T)("体力"):t==Ft.Agility?(0,
n.T)("敏捷"):t==Ft.Intelligence?(0,n.T)("智力"):""}static GetAttrsByJson(t){const e=new d.Z(t),i=new d.Z
for(let t=0;t<=e.Count()-1;t++){const s=new Vt.P
s.type=e[t].type,s.value=h.M.String2Int(e[t].value),i.Add(s)}return i}static GetOneAttrDesByIntType(t,e,i){return null==i&&(i=m.u.GreenColorStr),
Bt.X.Inst().GetLabelStrByIntKey(t,e,null,i)}static GetOneAttrDesByType(t,e,i,s){return null==i&&(i=m.u.GreenColorStr),Bt.X.Inst().GetLabelStrByStrKey(t,e,s,i)}
static GetAttrsDes(t,e){let i="",s=null
null==e&&(s="047104")
for(let e=0;e<=t.Count()-1;e++)i+=Bt.X.Inst().GetLabelStrByStrKey(t[e].type,(0,l.aI)(t[e].value),null,s),e!=t.Count()-1&&(i+="\n")
return i}}Ft.FirstClassAttr=new d.Z([I.Z.Strength,I.Z.Vitality,I.Z.Agility,I.Z.Intelligence]),Ft.Strength=null,Ft.Vitality=null,Ft.Agility=null,Ft.Intelligence=null},
63456:(t,e,i)=>{i.d(e,{d:()=>d})
var s=i(38836),n=i(98130),l=i(85602),a=i(17838),o=i(62370),r=i(98885)
class h{constructor(){this.type=null,this.value=null,this.subtype=null,this.subvalue=null}Parse(){const t=r.M.Split(this.value,o.o.s_Arr_UNDER_COLON)
1==t.count?(this.subtype=this.type,this.subvalue=t[0]):(this.subtype=t[0],this.subvalue=t[1])}}class d{constructor(){this.costs=null}FillData(t){this.costs=new l.Z
const e=new l.Z(t.costs)
let i=0
for(;i<e.Count();){const t=e[i],s=new h
s.type=n.GF.LuaJsonToString(t.type),s.value=n.GF.LuaJsonToString(t.value),s.subtype=n.GF.LuaJsonToString(t.subtype),s.subvalue=n.GF.LuaJsonToString(t.subvalue),
null!=t.num&&(s.num=t.num),this.costs.Add(s),i+=1}}Parse(){for(const[t,e]of(0,s.V5)(this.costs))e.Parse()}static CreateFromJson(t){const e=new d
e.costs=new l.Z
for(let i=0;i<t.length;i++){const s=new h
a.g.FillJsonData(s,t[i],!0),e.costs.Add(s)}return e}}},96913:(t,e,i)=>{i.d(e,{_:()=>o})
var s=i(62370),n=i(98885),l=i(53912),a=i(2457)
class o{constructor(){this.type=null,this.value="null",this.m_value=null,this.valueType=null,this.valueNum=0,this.showid=0,this.notShow=0,this._firstValue=0,this._parseAnylise=!1,
this.createIdx=null,this.intType=null,this.rate=0,this.condition=null}FirstValue_get(){return this._firstValue}Parse(){if(!this._parseAnylise&&this.value){if(this._parseAnylise=!0,
!this.value&&this.m_value&&(this.value=this.m_value),this.value=this.value.toString(),!n.M.IsNullOrEmpty(this.value))if(n.M.Contains(this.value,s.o.s_UNDER_COLON)){
const t=n.M.Split(this.value,s.o.s_Arr_UNDER_COLON)
t.count>1&&(this.valueType=t[0],this.valueNum=n.M.String2Int(t[1]))}else this.valueNum=n.M.String2Int(this.value)
this._firstValue=this.getFirstValue()}}Parse2(){if(!this._parseAnylise){if(this._parseAnylise=!0,
!n.M.IsNullOrEmpty(this.value))if(n.M.Contains(this.value,s.o.s_Arr_UNDER_CHAR_DOT)){const t=n.M.Split(this.value,s.o.s_Arr_UNDER_CHAR_DOT)
t.count>1&&(this.valueType=t[0],this.valueNum=n.M.String2Int(t[1]))}else this.valueNum=n.M.String2Int(this.value)
this._firstValue=this.getFirstValue()}}ParseGameCondition(){this.Parse(),this.intType=a.u.TypeToVal(this.type)
let t=a.u.GetClassByIntType(this.intType)
null==t&&(t=l.$),this.condition=new t,this.condition.ParseCommonTypeValue(this)}isRefreshPoint_get(){return this.type==o.t_REFRESHPOINT}getFirstValue(){let t=0
if(null!=this.value){const e=n.M.Split(this.value,s.o.s_Arr_UNDER_CHAR_DOT)
e.count>1&&(t=n.M.String2Int(e[0]))}return t}}o.t_Currency="Currency",o.t_Item="Item",o.t_Job="Job",o.t_LevelGT="LevelGT",o.t_TranferLimit="TranferLimit",o.t_LEVEL="LEVEL",
o.t_QUEST_ALREADY_COMPLETE="QUEST_ALREADY_COMPLETE",o.t_COMPLETE_QUEST="COMPLETE_QUEST",o.t_MEMORY_ACTIVE="MEMORY_ACTIVE",o.t_MEMORYCON="MEMORYCON",o.t_PASS_COPY="PASS_COPY",
o.t_TALK="TALK",o.t_EQUIPMENT_ENHANCE_LEVEL="EQUIPMENT_ENHANCE_LEVEL",o.t_EQUIPMENT_ENHANCE_TOTAL_LEVEL="EQUIPMENT_ENHANCE_TOTAL_LEVEL",
o.t_EQUIPMENT_UP_STEP_LV_TIME="EQUIPMENT_UP_STEP_LV_TIME",o.t_TRANSFER="TRANSFER",o.t_KILL_MONSTER="KILL_MONSTER",o.t_ENTER_COPY="ENTER_COPY",
o.t_PASSIVE_SKILL_LEVEL_UP_TIME="PASSIVE_SKILL_LEVEL_UP_TIME",o.t_EQUIPMENT_EQUIP="EQUIPMENT_EQUIP",o.t_SKILL_LEVEL_UP_TIME="SKILL_LEVEL_UP_TIME",o.t_LEARN_SKILL="LEARN_SKILL",
o.t_SKILL_LEVELUP="SKILL_LEVELUP",o.t_JOIN_ASURAM="JOIN_ASURAM",o.t_WING_REFINE="WING_REFINE",o.t_ATTR_VALUE="ATTR_VALUE",o.t_EXTRA_SKILL_LEVEL="EXTRA_SKILL_LEVEL",
o.t_EQUIP_SCORE="EQUIP_SCORE",o.t_WING_ENCHANCE="WING_ENCHANCE",o.t_AUCTION_TRADE="AUCTION_TRADE",o.t_MARKET_TRADE="MARKET_TRADE",o.t_IMMORTALS_DEBLOCK="IMMORTALS_DEBLOCK",
o.t_IMMORTALS_LEVEL_UP="IMMORTALS_LEVEL_UP",o.t_NEW_TITLE="NEW_TITLE",o.t_GLOBING_MERCHAT_BUY="GLOBING_MERCHAT_BUY",o.t_SUIT_EQUIP="SUIT_EQUIP",o.t_ARENA_DAN="ARENA_DAN",
o.t_ENTER_MAP="ENTER_MAP",o.t_MASTER_POINT="MASTER_POINT",o.t_EQUIP_GET_TIPS_OPEN="EQUIP_GET_TIPS_OPEN",o.t_IMMORTALS="IMMORTALS",o.t_GTAttribute="GTAttribute",
o.t_TIMECARD="TIMECARD",o.t_REFRESHPOINT="ClearPoint",o.t_RANDOMTRANSPORT="RandomTransport",o.t_EXCELLENCE_NUM="EXCELLENCE_NUM",
o.t_Position_Wear_BlessAngel="Position_Wear_BlessAngel",o.t_Sacred_Equip_Activate="Sacred_Equip_Activate",o.t_Activity_Sacredequip_Num="Activity_Sacredequip_Num",
o.t_Wear_BlessAngel_Num="Wear_BlessAngel_Num",o.t_Upto_Transfer="Upto_Transfer",o.t_Sacredequip_Level_Num="Sacredequip_Level_Num",o.t_ACC_CHECKPOINT="ACC_CHECKPOINT",o.t_PID="PID"
},46749:(t,e,i)=>{i.d(e,{z:()=>r})
var s=i(38836),n=i(98130),l=i(85602),a=i(17838),o=i(96913)
class r{constructor(){this.typevalues=null,this.add=!0,this.value=0}FillData(t){this.typevalues=new l.Z
const e=new l.Z(t.typevalues)
let i=0
for(;i<e.Count();){const t=e[i],s=new o._
s.type=n.GF.LuaJsonToString(t.type),s.value=n.GF.LuaJsonToString(t.value),s.m_value=n.GF.LuaJsonToString(t.m_value),s.valueType=n.GF.LuaJsonToString(t.valueType),
s.valueNum=n.GF.LuaJsonToNumber(t.valueNum),s.showid=n.GF.LuaJsonToNumber(t.showid),s.notShow=n.GF.LuaJsonToNumber(t.notShow),s.createIdx=n.GF.LuaJsonToNumber(t.createIdx),
1!=t.notShow&&this.typevalues.Add(s),i+=1}}Parse(){for(const[t,e]of(0,s.V5)(this.typevalues))e.Parse()}Parse2(){for(const[t,e]of(0,s.V5)(this.typevalues))e.Parse2()}
ParseGameCondition(){for(const[t,e]of(0,s.V5)(this.typevalues))e.ParseGameCondition()}FastCheckCondition(t,e,i,s,n){if(null==this.typevalues)return!0
const l=this.typevalues.Count()
if(0==l)return!0
let a=l
if(a=l,l>0)for(let o=0;o<=l-1;o++){const l=this.typevalues[o]
if(l.intType!=t){if(l.condition.CheckMutilPlayerCondition(e,s,n,i)){if(!this.add)return!0}else{if(this.add){a=0
break}a-=1}}else if(null!=e){if(l.condition.CheckMutilPlayerCondition(e,s,n,i)){if(!this.add)return!0}else{if(this.add){a=0
break}a-=1}}else if(!this.add)return!0}return a>=l}GetItem(){let t=0
for(;t<this.typevalues.Count();){if(this.typevalues[t].type==o._.t_Item)return this.typevalues[t]
t+=1}return null}static CreateFromJson(t){const e=new r
e.typevalues=new l.Z
for(let i=0;i<t.length;i++)if(1!=t[i].notShow){const s=new o._
a.g.FillJsonData(s,t[i],!0),e.typevalues.Add(s)}return e}}},52882:(t,e,i)=>{i.d(e,{J:()=>s})
class s{constructor(){this.addRateDic=null}}},94627:(t,e,i)=>{i.d(e,{X:()=>s})
class s{constructor(){this.modelId=0,this.equipStepsNum=0,this.equipStrengthNum=0,this.equipAddNum=0,this.excellentAttrNum=0,this.num=0}}},86600:(t,e,i)=>{i.d(e,{Q:()=>r})
var s=i(62370),n=i(98130),l=i(98885),a=i(85602)
class o{constructor(){this.type=null,this.value=null,this.consumeType=null,this.consumeNum=0}}class r{constructor(){this.currencyConsumeList=null}FillData(t){
this.currencyConsumeList=new a.Z
const e=new a.Z(t.currencyConsumeList)
let i=0
for(;i<e.Count();){const t=e[i],s=new o
s.type=n.GF.LuaJsonToString(t.type),s.value=n.GF.LuaJsonToString(t.value),s.consumeType=n.GF.LuaJsonToString(t.consumeType),s.consumeNum=n.GF.LuaJsonToNumber(t.consumeNum),
this.currencyConsumeList.Add(s),i+=1}}parse(){if(null==this.currencyConsumeList)return
let t=0
for(;t<this.currencyConsumeList.Count();){const e=l.M.Split(this.currencyConsumeList[t].value,s.o.s_Arr_UNDER_COLON)
this.currencyConsumeList[t].consumeType=e[0],this.currencyConsumeList[t].consumeNum=l.M.String2Int(e[1]),t+=1}}}},2345:(t,e,i)=>{i.d(e,{j:()=>s})
class s{constructor(){this.equipStepsNum=0,this.equipExcellentAttrNum=0}}},53553:(t,e,i)=>{i.d(e,{T:()=>s})
class s{constructor(){this.modelId=0,this.num=0,this.relatedAwakeId=0}}},82501:(t,e,i)=>{i.d(e,{Q:()=>s})
class s{constructor(){this.modelID=0,this.rateValue=0}}},53841:(t,e,i)=>{i.d(e,{d:()=>s})
class s{constructor(){this.modelId=0,this.num=0,this.showId=0}}},68748:(t,e,i)=>{i.d(e,{s:()=>a})
var s=i(98130),n=i(85602)
class l{constructor(){this.x_p=0,this.y_p=0,this.z_p=0,this.x_r=0,this.y_r=0,this.z_r=0,this.zoom=0,this.level=0,this.skill_1=null,this.skill_2=null}}class a{constructor(){
this.datas=null}FillData(t){this.datas=new n.Z
const e=new n.Z(t.datas)
let i=0
for(;i<e.Count();){const t=e[i],n=new l
n.x_p=s.GF.LuaJsonToNumber(t.x_p),n.y_p=s.GF.LuaJsonToNumber(t.y_p),n.z_p=s.GF.LuaJsonToNumber(t.z_p),n.x_r=s.GF.LuaJsonToNumber(t.x_r),n.y_r=s.GF.LuaJsonToNumber(t.y_r),
n.z_r=s.GF.LuaJsonToNumber(t.z_r),n.zoom=s.GF.LuaJsonToNumber(t.zoom),n.level=s.GF.LuaJsonToNumber(t.level),n.skill_1=s.GF.LuaJsonToString(t.skill_1),
n.skill_2=s.GF.LuaJsonToString(t.skill_2),this.datas.Add(n),i+=1}}}},26157:(t,e,i)=>{i.d(e,{e:()=>o})
var s=i(98130),n=i(85602),l=i(92984)
class a{constructor(){this.monsterId=0,this.cost=0,this.worldLevel=0,this.buffId=0,this.jobType=0,this.jobIcon=null}IsEnough(){
return!(l.j.Inst_get().model.worldLevel<this.worldLevel)}}class o{constructor(){this.npcValue=null}FillData(t){this.npcValue=new n.Z
const e=new n.Z(t.npcValue)
let i=0
for(;i<e.Count();){const t=e[i],n=new a
n.monsterId=s.GF.LuaJsonToNumber(t.monsterId),n.cost=s.GF.LuaJsonToNumber(t.cost),n.worldLevel=s.GF.LuaJsonToNumber(t.worldLevel),n.buffId=s.GF.LuaJsonToNumber(t.buffId),
n.jobType=s.GF.LuaJsonToNumber(t.jobType),n.jobIcon=s.GF.LuaJsonToString(t.jobIcon),this.npcValue.Add(n),i+=1}}}},26104:(t,e,i)=>{i.d(e,{o:()=>a})
var s=i(98130),n=i(85602)
class l{constructor(){this.type=null,this.valueStr=void 0,this.value=0}}class a{constructor(){this.copyResourceAttr=null}FillData(t){this.copyResourceAttr=new n.Z
const e=new n.Z(t.copyResourceAttr)
let i=0
for(;i<e.Count();){const t=e[i],n=new l
n.type=s.GF.LuaJsonToString(t.type),n.valueStr=t.value,n.value=s.GF.LuaJsonToNumber(n.valueStr),this.copyResourceAttr.Add(n),i+=1}}}},97668:(t,e,i)=>{i.d(e,{x:()=>r})
var s=i(98130),n=i(85602),l=i(62370),a=i(98885)
class o{constructor(){this.type=null,this.value=null,this.itemId=0,this.itemNum=0}Parse(){if("Item"==this.type){const t=a.M.Split(this.value,l.o.s_UNDER_COLON)
this.itemId=a.M.String2Int(t[0]),this.itemNum=a.M.String2Int(t[1])}}}class r{constructor(){this.copyResourceAttrEX=null}FillData(t){this.copyResourceAttrEX=new n.Z
const e=new n.Z(t.copyResourceAttrEX)
let i=0
for(;i<e.Count();){const t=e[i],n=new o
n.type=s.GF.LuaJsonToString(t.type),n.value=s.GF.LuaJsonToString(t.value),n.itemId=s.GF.LuaJsonToNumber(t.itemId),n.itemNum=s.GF.LuaJsonToNumber(t.itemNum),
this.copyResourceAttrEX.Add(n),i+=1}}}},56018:(t,e,i)=>{i.d(e,{T:()=>l})
var s=i(98130),n=i(85602)
class l{constructor(){this.intValue=null}FillData(t){this.intValue=new n.Z
const e=new n.Z(t.intValue)
let i=0
for(;i<e.Count();){const t=s.GF.LuaJsonToNumber(e[i])
this.intValue.Add(t),i+=1}}}},12050:(t,e,i)=>{i.d(e,{t:()=>r})
var s=i(98130),n=i(85602)
class l{constructor(){this.key=0,this.type=null,this.param=null,this.value=null,this.guaji=0}}class a{constructor(){this.MONSTERID=null,this.ITEMID=null,this.NPCID=null,
this.LEVEL=0,this.MONSTERS=null,this.x=0,this.y=0,this.score=0}}class o{constructor(){this.monsterId=0,this.value=0}}class r{constructor(){this.successConditionList=null}
FillData(t){this.successConditionList=new n.Z
const e=new n.Z(t.successConditionList)
let i=0
for(;i<e.Count();){const t=e[i],r=new l
if(r.key=s.GF.LuaJsonToNumber(t.key),r.type=s.GF.LuaJsonToString(t.type),r.value=s.GF.LuaJsonToString(t.value),null!=t.param)if(r.param=new a,
r.param.MONSTERID=s.GF.LuaJsonToString(t.param.MONSTERID),r.param.ITEMID=s.GF.LuaJsonToString(t.param.ITEMID),r.param.NPCID=s.GF.LuaJsonToString(t.param.NPCID),
r.param.x=s.GF.LuaJsonToNumber(t.param.x),r.param.y=s.GF.LuaJsonToNumber(t.param.y),r.param.score=s.GF.LuaJsonToNumber(t.param.score),null!=t.param.MONSTERS){
r.param.MONSTERS=new n.Z
const e=new n.Z(t.param.MONSTERS)
let i=0
for(;i<e.Count();){const t=e[i],n=new o
n.monsterId=s.GF.LuaJsonToNumber(t.monsterId),n.value=s.GF.LuaJsonToNumber(t.value),r.param.MONSTERS.Add(n),i+=1}}else r.param.MONSTERS=null
else r.param=null
this.successConditionList.Add(r),i+=1}}}},21375:(t,e,i)=>{i.d(e,{X:()=>n})
var s=i(78300)
class n{constructor(){this.startpoint=null,this.endpoint=null,this.startpoint=s.V.TEMP_VECTOR2D_get(),this.endpoint=s.V.TEMP_VECTOR2D_get()}}},63951:(t,e,i)=>{i.d(e,{Q:()=>o})
var s=i(98130),n=i(85602),l=i(17838)
class a{constructor(){this.job=0,this.poolId=0}}class o{constructor(){this.relivePools=null}FillData(t){this.relivePools=new n.Z
const e=new n.Z(t.relivePools)
let i=0
for(;i<e.Count();){const t=e[i],n=new a
n.job=s.GF.LuaJsonToNumber(t.job),n.poolId=s.GF.LuaJsonToNumber(t.poolId),this.relivePools.Add(n),i+=1}}static CreateFromJson(t){const e=new o
e.relivePools=new n.Z
for(let i=1;i<=t.length;i++){const s=new a
l.g.FillJsonData(s,t[i],!0),e.costs.Add(s)}return e}}},50536:(t,e,i)=>{i.d(e,{J:()=>s})
class s{constructor(){this.modelIds=null,this.skills=null}}},47043:(t,e,i)=>{i.d(e,{v:()=>s})
class s{constructor(){this.skillId=0,this.level=0,this.elementids=null}}},18919:(t,e,i)=>{i.d(e,{a:()=>V})
var s=i(85602),n=i(38962),l=i(17838)
let a=null,o=null,r=null,h=null,d=null,u=null,c=null,_=null,I=null,m=null,g=null,p=null,C=null,S=null,f=null,y=null,v=null,D=null,E=null,T=null,A=null,L=null,w=null,R=null,O=null,G=null,b=null,M=null,P=null,B=null,x=null,N=null,k=null
class V extends l.g{constructor(...t){super(...t),this.type=null,this.value=null,this.m_executeRet=!1,this.callbackParams=null,this.onFinishExecute=null,this.m_handlerMgr=null}
static __StaticInit(){a=table.insert,o=table.sort,r=table.remove,h=s.Z.new,d=s.Z.Add,u=s.Z.AddRang,c=s.Z.Clear,_=s.Z.Contains,I=s.Z.Insert,m=s.Z.InsertRange,g=s.Z.Remove,
p=s.Z.RemoveAt,C=s.Z.IndexOf,S=s.Z.Count,f=s.Z.Length,y=s.Z.RemoveRange,v=s.Z.GetRange,D=s.Z.Pop,E=s.Z.Reverse,T=s.Z.Sort,A=n.X.new,L=n.X.LuaDic_Add,w=n.X.LuaDic_SetItem,
R=n.X.LuaDic_IsNullValue,O=n.X.LuaDic_GetItem,G=n.X.LuaDic_Count,b=n.X.LuaDic_ContainsKey,M=n.X.LuaDic_AddOrSetItem,P=n.X.LuaDic_Keys,B=n.X.LuaDic_Values,x=n.X.LuaDic_Clear,
N=n.X.LuaDic_ContainsValue,k=n.X.LuaDic_Remove}Execute(t){return null==t&&(t=null),this.onFinishExecute=t,
this.IsAsyncCmd()?(null==this.m_handlerMgr&&(this.m_handlerMgr=LuaUIHandlerMgr.Get()),this.StarAddFinishEvent(),
this.m_executeRet=this.BeginExecute()):(this.m_executeRet=this.BeginExecute(),this.OnCmdFinish()),this.m_executeRet}StarAddFinishEvent(){}_OnEventRecv(t){this.OnCmdFinish()}
ClearFinishEvent(){null!=this.m_handlerMgr&&this.m_handlerMgr.Clear()}IsAsyncCmd(){return!1}BeginExecute(){return!0}OnCmdFinish(){if(this.ClearFinishEvent(),
null!=this.onFinishExecute){const t=this.onFinishExecute
this.onFinishExecute=null,t(this.m_executeRet)}}S_Test(){return!0}}},92662:(t,e,i)=>{i.d(e,{u:()=>l})
var s=i(38836),n=i(24772)
class l{static __StaticInit(){for(const[t,e]of(0,s.X)(l.s_ValToType))l.s_TypeToVal[e[1]]=t}Test1(){return!0}CreateFromJson(t){let e=t.type
null==e&&(e=t.__type)
let i=l.GetClassByType(e)
return null!=i&&(i=n.C.CreateBaseJsonClass(t,i)),null}CreateFromJsonFast(t){return n.C.CreateBaseJsonClassFast(t,l.GetClassByType,l.OnCreateBaseJsonClassFast)}
static OnCreateBaseJsonClassFast(t,e,i){t.intType=l.TypeToVal(e)}static GetClassByType(t){const e=l.s_TypeToVal[t]
if(null==e)return null
return l.s_ValToType[e][2]()}static TypeToVal(t){return l.s_TypeToVal[t]}ValToType(t){return l.s_ValToType[t][1]}GetClassByIntType(t){if(null==t)return null
return l.s_ValToType[t][2]()}CreateClassNewFast(t){return new(l.GetClassByIntType(t))}}l.UseItem_Val=1,l.RyLinkItemData_Val=2,l.RyLinkPlayerData_Val=3,l.s_TypeToVal={},
l.s_ValToType={[l.UseItem_Val]:["UseItem",()=>{}],[l.RyLinkItemData_Val]:["RyLinkItemData",()=>{}],[l.RyLinkPlayerData_Val]:["RyLinkPlayerData",()=>{}]}},30143:(t,e,i)=>{i.d(e,{
N:()=>l})
var s=i(25236),n=i(18919)
class l extends n.a{IsAsynCmd(){return!1}BeginExecute(){return(0,s.S)("GameCommandUseItem BeginExecute"),!0}S_Test(){return!0}}},53912:(t,e,i)=>{i.d(e,{$:()=>U})
var s=i(98800),n=i(98885),l=i(85602),a=i(38962)
let o=null,r=null,h=null,d=null,u=null,c=null,_=null,I=null,m=null,g=null,p=null,C=null,S=null,f=null,y=null,v=null,D=null,E=null,T=null,A=null,L=null,w=null,R=null,O=null,G=null,b=null,M=null,P=null,B=null,x=null,N=null,k=null,V=null
class F{static __StaticInit(){o=table.insert,r=table.sort,h=table.remove,d=l.Z.new,u=l.Z.Add,c=l.Z.AddRang,_=l.Z.Clear,I=l.Z.Contains,m=l.Z.Insert,g=l.Z.InsertRange,p=l.Z.Remove,
C=l.Z.RemoveAt,S=l.Z.IndexOf,f=l.Z.Count,y=l.Z.Length,v=l.Z.RemoveRange,D=l.Z.GetRange,E=l.Z.Pop,T=l.Z.Reverse,A=l.Z.Sort,L=a.X.new,w=a.X.LuaDic_Add,R=a.X.LuaDic_SetItem,
O=a.X.LuaDic_IsNullValue,G=a.X.LuaDic_GetItem,b=a.X.LuaDic_Count,M=a.X.LuaDic_ContainsKey,P=a.X.LuaDic_AddOrSetItem,B=a.X.LuaDic_Keys,x=a.X.LuaDic_Values,N=a.X.LuaDic_Clear,
k=a.X.LuaDic_ContainsValue,V=a.X.LuaDic_Remove}Test1(){return!0}S_Test(){return!0}}F.OnlyChange=1,F.OnlyChangeTrue=2,F.OnlyRecv=3,F.OnlyChangeTrueOnce=4,
F.OnlyChangeTrueOnceNeedFalseBefore=5,F.OnlyTrue=6
class U{constructor(){this.intType=0,this.type="",this.createIdx=null,this.intValue=null,this.dicValue=null,this.listValue=null,this.conditionRet=!1,
this._onConditionValChanged=null,this._triggerCallType=2,this.m_triggerCommonEvents=null,this.delayCall=0,this._roleIdx=0}static __StaticInit(){}GetConditionDesc(){return"条件描述"}
GetConditionDescByOp(t){return U.DES_OP_kaiqi==t?`${this.GetConditionDesc()}开启`:U.DES_OP_xuyao==t?`需要${this.GetConditionDesc()}`:this.GetConditionDesc()}GetErrorDescByOp(t){
return this.GetConditionDescByOp(t)}CheckCondition(){return!0}IntType_get(){return this.intType}OpenTrigger(t,e,i,s,n){return this.delayCall=n,this.AddOnConditionValChanged(e),
(i!=F.OnlyChangeTrueOnceNeedFalseBefore||(this.conditionRet=this._TriggerCheckCondition(),!this.conditionRet))&&(this._triggerCallType=i,
(this._IsShouldPreCalRet()||s)&&(this.conditionRet=this._TriggerCheckCondition()),s&&this._CallTrigger(),this._SetTriggerCommonEvent(),this._SetTriggerCustomEvent(),!0)}
AddOnConditionValChanged(t){null==this._onConditionValChanged&&(this._onConditionValChanged=new l.Z),
null!=t&&l.Z.IndexOf(this._onConditionValChanged,t)<0&&this._onConditionValChanged.Add(t)}_TriggerCheckCondition(){return this.CheckCondition()}_IsShouldPreCalRet(){
return this._triggerCallType==F.OnlyChange||this._triggerCallType==F.OnlyChangeTrue||this._triggerCallType==F.OnlyChangeTrueOnce||this._triggerCallType==F.OnlyChangeTrueOnceNeedFalseBefore
}_SetTriggerCommonEvent(){let[t,e,i]=this._GetTriggerCommonEventList()
if(null==e&&(e=this.delayCall),null!=t)for(let s=0;s<=t.Count()-1;s++)INS.luaEventMgr.AddEventHandler(t[s],this.CheckConditionChange,e,i)
if([t,e,i]=this._GetTriggerRoleEventList(),null==e&&(e=this.delayCall),null!=t)for(let s=0;s<=t.Count()-1;s++)INS.characterMgr.GetMultiPlayerInfoByCreateIdx(this._roleIdx).AddEventHandler(t[s],this.CheckConditionChange,e,i)
}_GetTriggerCommonEventList(){}_GetTriggerRoleEventList(){}_SetTriggerCustomEvent(){}_CallTrigger(){if(null==this._onConditionValChanged)return
let t=0
for(;t<this._onConditionValChanged.count;)this._onConditionValChanged[t](this.conditionRet),t+=1}CheckConditionChange(){const t=this.conditionRet
this.conditionRet=this._TriggerCheckCondition(),this._triggerCallType==F.OnlyChange?t!=this.conditionRet&&this._CallTrigger():this._triggerCallType==F.OnlyRecv?this._CallTrigger():this._triggerCallType==F.OnlyChangeTrue?0==t&&this.conditionRet&&(this._CallTrigger(),
this.CloseTrigger()):this._triggerCallType==F.OnlyChangeTrueOnce||this._triggerCallType==F.OnlyChangeTrueOnceNeedFalseBefore?0==t&&this.conditionRet&&this._CallTrigger():this._triggerCallType==F.OnlyTrue&&this.conditionRet&&this._CallTrigger()
}GetCommonDes(t){return""}CloseTrigger(){let t=this._GetTriggerCommonEventList()
if(null!=t)for(let e=0;e<=t.Count()-1;e++)INS.luaEventMgr.RemoveEventHandler(t[e],this.CheckConditionChange)
if(t=this._GetTriggerRoleEventList(),null!=t)for(let e=0;e<=t.Count()-1;e++)INS.characterMgr.GetMultiPlayerInfoByCreateIdx(this._roleIdx).RemoveEventHandler(t[e],this.CheckConditionChange)
null!=this._onConditionValChanged&&this._onConditionValChanged.Clear()}SetRoleIndex(t){this._roleIdx=t}Clear(){this.CloseTrigger()}ParseCommonTypeValue(t){this.intType=t.intType,
n.M.IsNullOrEmpty(t.value)||(this.intValue=n.M.String2Int(t.value)),0==this.intValue&&(this.listValue=n.M.Split(t.value,",")),this.createIdx=t.createIdx}
CheckMutilPlayerCondition(t,e,i,n){const l=this.createIdx
if(null!=l){if(l>s.Y.Inst.GetPrimaryRoleCount())return null!=e&&e&&this.ShowTips(i,l-1),!1
if(0==l)return this.FastCheckOnePlayerCondition(null,t,e,i,n)
if(l>0){const a=s.Y.Inst.GetMultiPlayerInfoByCreateIdx(l-1)
return this.FastCheckOnePlayerCondition(a,t,e,i,n)}const a=s.Y.Inst.primaryRoleInfoList
for(let s=0;s<=a.count-1;s++)if(this.FastCheckOnePlayerCondition(a[s],t,e,i,n)){if(-1==l)return!0}else if(-1!=l)return!1
return!0}return this.FastCheckOnePlayerCondition(null,t,e,i,n)}FastCheckCondition(t,e,i){return this.CheckCondition()}FastCheckOnePlayerCondition(t,e,i,s,n){
return!!this.FastCheckCondition(t,e,n)&&(null!=i&&i&&(null!=t?this.ShowTips(s,t.createIdx):this.ShowTips(s,null)),!0)}ShowTips(t,e){
null==t?this.ShowNoI18Tips(e):this.ShowI18Tips(t,e)}ShowNoI18Tips(t){INS.systemTipsControl.ClientSysStrMsg(this.GetCommonDes(t))}ShowI18Tips(t,e){}}U.DES_OP_kaiqi=1,
U.DES_OP_xuyao=2,U.DES_OP_skilllevelup=3},2457:(t,e,i)=>{i.d(e,{u:()=>Ja})
var s=i(38836),n=i(66788),l=i(31922),a=i(24772),o=i(21267),r=i(53912)
class h extends r.${CheckCondition(){return o.u.Inst().totalPassNum>=this.intValue}}var d=i(62370),u=i(17783),c=i(98580)
class _ extends r.${constructor(...t){super(...t),this.list=null}FastCheckCondition(t,e,i){let s=null
null!=t&&(s=t.m_id)
const n=this.list.count-1
for(let t=0;t<=n;t++){const e=u.L.Inst_get().model.GetTaskById(this.list[t],s)
if(null!=e&&(e.status_get()==c.B.ACCEPTED||e.status_get()==c.B.FINISHED))return!0}return!1}ParseCommonTypeValue(t){this.intType=null,
this.list=d.o.GetIntArr(t.value,d.o.s_UNDER_CHAR),this.createIdx=t.createIdx}}var I=i(98885),m=i(38962)
class g extends r.${FastCheckCondition(t,e,i){let n=null
null!=t&&(n=t.m_id)
let l=null
if(null!=this.dicValue){if(null!=e&&this.dicValue.LuaDic_ContainsKey(e))return l=u.L.Inst_get().model.GetTaskById(e,n),null!=l&&l.status_get()==c.B.ACCEPTED
for(const[t,e]of(0,s.V5)(this.dicValue))if(l=u.L.Inst_get().model.GetTaskById(t,n),null!=l&&l.status_get()==c.B.ACCEPTED)return!0}return!1}ParseCommonTypeValue(t){this.intType=null
const e=I.M.Split(t.value,d.o.s_UNDER_CHAR)
if(e.Count()>=1){this.dicValue=new m.X
for(let t=0;t<=e.Count()-1;t++)this.dicValue.LuaDic_AddOrSetItem(I.M.String2Int(e[t]),!0)}else this.dicValue=null
this.createIdx=t.createIdx}}var p=i(98800),C=i(97960),S=i(85602),f=i(1003)
let y=null,v=null,D=null,E=null,T=null,A=null,L=null,w=null,R=null,O=null,G=null,b=null,M=null,P=null,B=null,x=null,N=null,k=null,V=null,F=null,U=null,H=null,q=null,Z=null,j=null,X=null,Y=null,W=null,$=null,J=null,z=null,Q=null,K=null,tt=null,et=null
class it extends r.${constructor(...t){super(...t),this.value=0,this.Lastvalue=0,this.desc="",this.AttrType="Defense",this.isOver=1}static __StaticInit(){y=table.insert,
v=table.sort,D=table.remove,tt=new S.Z,et=new S.Z([C.A.AttributesUpdate]),E=S.Z.new,T=S.Z.Add,A=S.Z.AddRang,L=S.Z.Clear,w=S.Z.Contains,R=S.Z.Insert,O=S.Z.InsertRange,G=S.Z.Remove,
b=S.Z.RemoveAt,M=S.Z.IndexOf,P=S.Z.Count,B=S.Z.Length,x=S.Z.RemoveRange,N=S.Z.GetRange,k=S.Z.Pop,V=S.Z.Reverse,F=S.Z.Sort,U=m.X.new,H=m.X.LuaDic_Add,q=m.X.LuaDic_SetItem,
Z=m.X.LuaDic_IsNullValue,j=m.X.LuaDic_GetItem,X=m.X.LuaDic_Count,Y=m.X.LuaDic_ContainsKey,W=m.X.LuaDic_AddOrSetItem,$=m.X.LuaDic_Keys,J=m.X.LuaDic_Values,z=m.X.LuaDic_Clear,
Q=m.X.LuaDic_ContainsValue,K=m.X.LuaDic_Remove}_GetTriggerCommonEventList(){return tt}_GetTriggerRoleEventList(){return et}CheckCondition(){
const t=p.Y.Inst.GetMultiPlayerInfoByCreateIdx(this._roleIdx),e=f.U.GetAttKeyByName(this.AttrType),i=t.Attributes_get()[e]
return 1==this.isOver?i>=this.value?(this.Lastvalue=i,!0):(this.Lastvalue=i,!1):i<this.value?(this.Lastvalue=i,!0):(this.Lastvalue=i,!1)}ParseCommonTypeValue(t){
this._roleIdx=t.createIdx-1}GetCommonDes(t){if(null==t&&(t=""),this.CheckCondition()){let e=this.desc
return e=I.M.Replace(e,"{0}",`${this.Lastvalue}/${this.value}`),t+e}return""}}class st extends r.${CheckCondition(){return this.CheckMutilPlayerCondition()}
FastCheckCondition(t,e,i){return null==t&&(t=p.Y.Inst.PrimaryRoleInfo_get()),t.BattleScore_get()>=this.intValue}}class nt extends r.${constructor(...t){super(...t),this.min=null,
this.max=null}CheckCondition(){return this.CheckMutilPlayerCondition()}FastCheckCondition(t,e,i){return null==t&&(t=p.Y.Inst.PrimaryRoleInfo_get()),
t.BattleScore_get()>=this.min&&t.BattleScore_get()<=this.max}ParseCommonTypeValue(t){if(this.intType=t.intType,I.M.IndexOf(t.value,"_",0)){const e=d.o.GetIntArr(t.value,"_")
this.min=e[0],this.max=e[1]}else this.min=I.M.String2Int(t.value),this.max=this.min}}class lt extends r.${FastCheckCondition(t,e,i){let s=null
return null!=t&&(s=t.m_id),!1}}class at extends r.${constructor(...t){super(...t),this.controlId=null,this.controlParam=null,this.controlParams=null}FastCheckCondition(t,e,i){
if(this.controlId==e){if(null!=this.controlParams&&null!=this.controlParams&&null!=i){return this.controlParams.IndexOf(i)>0}return!0}return!1}ParseCommonTypeValue(t){
if(this.intType=t.intType,I.M.IndexOf(t.value,"_",0)>-1){const e=d.o.GetIntArr(t.value,"_")
this.controlId=e[0],this.controlParams=e}else this.controlId=I.M.String2Int(t.value)}}class ot extends r.${constructor(...t){super(...t),this.taskDic=null}
FastCheckCondition(t,e,i){return!(null==this.taskDic||!this.taskDic.LuaDic_ContainsKey(e))}ParseCommonTypeValue(t){if(this.intType=t.intType,I.M.IndexOf(t.value,"_",0)>-1){
const e=d.o.GetIntArr(t.value,"_")
this.taskDic=new m.X
for(let t=0;t<=e.Count()-1;t++)this.taskDic.LuaDic_AddOrSetItem(e[t],!0)}else this.taskDic=null}}class rt extends r.${FastCheckCondition(t,e,i){let s=null
if(null!=t&&(s=t.createIdx),null!=e&&e==this.intValue)return!0}}class ht extends r.${FastCheckCondition(t,e,i){let s=null
return null!=t&&(s=t.m_id),u.L.Inst_get().model.IsTaskCompleted(this.intValue,s)}}var dt=i(85770)
class ut extends r.${CheckCondition(){return this.intValue==dt.a.Inst_get().curCopyType&&dt.a.Inst_get().IsHaveCoinInspirCount()}}class ct extends r.${FastCheckCondition(t,e,i){
dt.a.Inst.serverCopyId=this.intValue}}class _t extends r.${FastCheckCondition(t,e,i){return dt.a.Inst.serverCopyType==this.intValue}}var It=i(92679)
let mt=null,gt=null,pt=null,Ct=null,St=null,ft=null,yt=null,vt=null,Dt=null,Et=null,Tt=null,At=null,Lt=null,wt=null,Rt=null,Ot=null,Gt=null,bt=null,Mt=null,Pt=null,Bt=null,xt=null,Nt=null,kt=null,Vt=null,Ft=null,Ut=null,Ht=null,qt=null,Zt=null,jt=null,Xt=null,Yt=null,Wt=null,$t=null
class Jt extends r.${static __StaticInit(){mt=table.insert,gt=table.sort,pt=table.remove,Wt=new S.Z([It.g.BAG_UPDATE]),$t=new S.Z,Ct=S.Z.new,St=S.Z.Add,ft=S.Z.AddRang,yt=S.Z.Clear,
vt=S.Z.Contains,Dt=S.Z.Insert,Et=S.Z.InsertRange,Tt=S.Z.Remove,At=S.Z.RemoveAt,Lt=S.Z.IndexOf,wt=S.Z.Count,Rt=S.Z.Length,Ot=S.Z.RemoveRange,Gt=S.Z.GetRange,bt=S.Z.Pop,
Mt=S.Z.Reverse,Pt=S.Z.Sort,Bt=m.X.new,xt=m.X.LuaDic_Add,Nt=m.X.LuaDic_SetItem,kt=m.X.LuaDic_IsNullValue,Vt=m.X.LuaDic_GetItem,Ft=m.X.LuaDic_Count,Ut=m.X.LuaDic_ContainsKey,
Ht=m.X.LuaDic_AddOrSetItem,qt=m.X.LuaDic_Keys,Zt=m.X.LuaDic_Values,jt=m.X.LuaDic_Clear,Xt=m.X.LuaDic_ContainsValue,Yt=m.X.LuaDic_Remove}_GetTriggerCommonEventList(){return Wt}
_GetTriggerRoleEventList(){return $t}CheckCondition(){return p.Y.Inst.primaryRoleInfoList.Count()>=this.intValue}GetCommonDes(t){return null==t&&(t=""),""}Test1(){return!0}
S_Test(){return!0}}var zt=i(33314)
let Qt=null,Kt=null,te=null,ee=null,ie=null,se=null,ne=null,le=null,ae=null,oe=null,re=null,he=null,de=null,ue=null,ce=null,_e=null,Ie=null,me=null,ge=null,pe=null,Ce=null,Se=null,fe=null,ye=null,ve=null,De=null,Ee=null,Te=null,Ae=null,Le=null,we=null,Re=null,Oe=null,Ge=null,be=null
class Me extends r.${static __StaticInit(){Qt=table.insert,Kt=table.sort,te=table.remove,Ge=new S.Z([It.g.BAG_UPDATE]),be=new S.Z,ee=S.Z.new,ie=S.Z.Add,se=S.Z.AddRang,ne=S.Z.Clear,
le=S.Z.Contains,ae=S.Z.Insert,oe=S.Z.InsertRange,re=S.Z.Remove,he=S.Z.RemoveAt,de=S.Z.IndexOf,ue=S.Z.Count,ce=S.Z.Length,_e=S.Z.RemoveRange,Ie=S.Z.GetRange,me=S.Z.Pop,
ge=S.Z.Reverse,pe=S.Z.Sort,Ce=m.X.new,Se=m.X.LuaDic_Add,fe=m.X.LuaDic_SetItem,ye=m.X.LuaDic_IsNullValue,ve=m.X.LuaDic_GetItem,De=m.X.LuaDic_Count,Ee=m.X.LuaDic_ContainsKey,
Te=m.X.LuaDic_AddOrSetItem,Ae=m.X.LuaDic_Keys,Le=m.X.LuaDic_Values,we=m.X.LuaDic_Clear,Re=m.X.LuaDic_ContainsValue,Oe=m.X.LuaDic_Remove}_GetTriggerCommonEventList(){return Ge}
_GetTriggerRoleEventList(){return be}CheckCondition(){const t=I.M.String2Int(this.listValue[0]),e=I.M.String2Int(this.listValue[1])
let i=0
for(let e=0;e<=p.Y.Inst.primaryRoleInfoList.Count()-1;e++){t==zt.Z.GetJobKind(p.Y.Inst.primaryRoleInfoList[e].job)&&(i+=1)}return i>=e}GetCommonDes(t){return null==t&&(t=""),""}
Test1(){return!0}S_Test(){return!0}}var Pe=i(91388)
class Be extends r.${CheckCondition(){return Pe.i.Inst().IsCanEnhance()}}class xe extends r.${CheckCondition(){return dt.a.Inst.serverCopyId==this.intValue}}var Ne=i(24524)
class ke extends r.${FastCheckCondition(t,e,i){if(null==e)return!1
if(0==dt.a.Inst.serverCopyId)return!1
const s=Ne.o.Inst().getItemById(dt.a.Inst.serverCopyId)
return null!=s&&s.groupId==e}}var Ve=i(13687)
class Fe extends r.${CheckCondition(){return Ve.b.Inst.currentMapId_get()==this.intValue}}class Ue extends r.${CheckCondition(){return dt.a.Inst.serverCopyType==this.intValue}}
class He extends r.${FastCheckCondition(t,e,i){let s=null
null!=t&&(s=t.m_id)
const n=u.L.Inst_get().model.GetTaskById(this.intValue,s)
return null!=n&&n.status_get()==c.B.FINISHED}}class qe extends r.${FastCheckCondition(t,e,i){let s=null
null!=t&&(s=t.m_id)
if(u.L.Inst_get().model.IsTaskCompleted(this.intValue,s)){return null==u.L.Inst_get().model.GetMainTask()}return!1}}class Ze extends r.${CheckCondition(){return!0}}
class je extends r.${CheckCondition(){return!p.Y.Inst.PrimaryRoleInfo_get().Gold_get()<this.intValue}}var Xe=i(60303)
class Ye extends r.${CheckCondition(){return Xe.p.Inst().IsHaveReward()}}var We=i(37648)
class $e extends r.${CheckCondition(){return!We.P.Inst_get().IsFunctionOpened(this.intValue)}}var Je=i(61567),ze=i(70850)
let Qe=null,Ke=null,ti=null,ei=null,ii=null,si=null,ni=null,li=null,ai=null,oi=null,ri=null,hi=null,di=null,ui=null,ci=null,_i=null,Ii=null,mi=null,gi=null,pi=null,Ci=null,Si=null,fi=null,yi=null,vi=null,Di=null,Ei=null,Ti=null,Ai=null,Li=null,wi=null,Ri=null,Oi=null,Gi=null,bi=null
class Mi extends r.${constructor(...t){super(...t),this.ItemModelId=0,this.overwrite=0,this.desc="",this.topchange=0}static __StaticInit(){Qe=table.insert,Ke=table.sort,
ti=table.remove,Gi=new S.Z([It.g.BAG_UPDATE]),bi=new S.Z,ei=S.Z.new,ii=S.Z.Add,si=S.Z.AddRang,ni=S.Z.Clear,li=S.Z.Contains,ai=S.Z.Insert,oi=S.Z.InsertRange,ri=S.Z.Remove,
hi=S.Z.RemoveAt,di=S.Z.IndexOf,ui=S.Z.Count,ci=S.Z.Length,_i=S.Z.RemoveRange,Ii=S.Z.GetRange,mi=S.Z.Pop,gi=S.Z.Reverse,pi=S.Z.Sort,Ci=m.X.new,Si=m.X.LuaDic_Add,
fi=m.X.LuaDic_SetItem,yi=m.X.LuaDic_IsNullValue,vi=m.X.LuaDic_GetItem,Di=m.X.LuaDic_Count,Ei=m.X.LuaDic_ContainsKey,Ti=m.X.LuaDic_AddOrSetItem,Ai=m.X.LuaDic_Keys,
Li=m.X.LuaDic_Values,wi=m.X.LuaDic_Clear,Ri=m.X.LuaDic_ContainsValue,Oi=m.X.LuaDic_Remove}_GetTriggerCommonEventList(){return Gi}_GetTriggerRoleEventList(){return bi}
CheckCondition(){return ze.g.Inst_get().GetItemNum(I.M.String2Int(this.ItemModelId))>0}GetCommonDes(t){if(null==t&&(t=""),this.CheckCondition()){const e=this.desc
return 0==this.overwrite?t+e:e}return""}Test1(){return!0}S_Test(){return!0}}class Pi extends r.${CheckCondition(){return p.Y.Inst.PrimaryRoleInfo_get().Gold_get()>=this.intValue}}
class Bi extends r.${CheckCondition(){return p.Y.Inst.PrimaryRoleInfo_get().Gold_get()<this.intValue}}var xi=i(28613),Ni=i(2689),ki=i(21334)
class Vi extends r.${CheckCondition(){return ki.p.Inst_get().GetMapById(Ve.b.Inst.currentMapId_get()).controllerType==Ni.N.SCENE}}class Fi extends r.${CheckCondition(t,e){
return Ve.b.Inst.lastCopyMapId>0}}class Ui extends r.${CheckCondition(){return Ve.b.Inst.lastMapId==this.intValue}}let Hi=null,qi=null,Zi=null,ji=null
class Xi extends r.${constructor(...t){super(...t),this.minLv=-1,this.maxLv=-1,this.value=null}static __StaticInit(){Hi=table.insert,qi=table.sort,Zi=table.remove,
ji=new S.Z([It.g.PLAYER_LEVELUP])}_GetTriggerCommonEventList(){return ji}CheckCondition(){return p.Y.Inst.PrimaryRoleInfo_get().Level_get()>this.intValue}GetCommonDes(){
return`角色等级不能低于${this.value}`}}let Yi=null,Wi=null,$i=null,Ji=null
class zi extends r.${constructor(...t){super(...t),this.minLv=-1,this.maxLv=-1,this.value=null}static __StaticInit(){Yi=table.insert,Wi=table.sort,$i=table.remove,
Ji=new S.Z([It.g.PLAYER_LEVELUP])}_GetTriggerCommonEventList(){return Ji}CheckCondition(){return p.Y.Inst.PrimaryRoleInfo_get().Level_get()<this.intValue}GetCommonDes(){
return`角色等级不能高于${this.value}`}}let Qi=null,Ki=null,ts=null,es=null
class is extends r.${constructor(...t){super(...t),this.minLv=-1,this.maxLv=-1}static __StaticInit(){Qi=table.insert,Ki=table.sort,ts=table.remove,es=new S.Z([It.g.PLAYER_LEVELUP])
}_GetTriggerCommonEventList(){return es}CheckCondition(){const t=p.Y.Inst.PrimaryRoleInfo_get().Level_get()
return t>=this.minLv&&t<=this.maxLv}GetCommonDes(){return`角色等级应处于${this.minLv}-${this.maxLv}之间`}ParseCommonTypeValue(t){if(this.intType=t.intType,I.M.IndexOf(t.value,"_",0)){
const e=d.o.GetIntArr(t.value,"_")
this.minLv=e[0],this.maxLv=e[1]}else this.minLv=I.M.String2Int(t.value),this.maxLv=this.minLv}}var ss=i(27001)
class ns extends r.${CheckCondition(){return ss.q.GetInst().HasVitalityRewardByVitality(this.intValue)}}let ls=null
class as extends r.${constructor(...t){super(...t),this.mappassId="",this.failTime=0}static __StaticInit(){ls=new S.Z([It.g.PLAYER_LEVELUP])}_GetTriggerCommonEventList(){return ls}
CheckCondition(){return o.u.Inst().GetFailNum(this.mappassId)>=this.failTime}GetCommonDes(){return`${this.mappassId}关卡id副本失败次数因大于${this.failTime}`}ParseCommonTypeValue(t){
if(this.intType=t.intType,I.M.IndexOf(t.value,"_",0)){const e=d.o.GetStringArr(t.value,"_")
this.mappassId=`${e[0]}_${e[1]}`,this.failTime=I.M.String2Int(e[2])}}}var os=i(38045)
let rs=null,hs=null,ds=null,us=null,cs=null,_s=null,Is=null,ms=null,gs=null,ps=null,Cs=null,Ss=null,fs=null,ys=null,vs=null,Ds=null,Es=null,Ts=null,As=null,Ls=null,ws=null,Rs=null,Os=null,Gs=null,bs=null,Ms=null,Ps=null,Bs=null,xs=null,Ns=null,ks=null,Vs=null,Fs=null,Us=null,Hs=null
class qs extends r.${constructor(...t){super(...t),this.desc=null,this.overwrite=null}static __StaticInit(){rs=table.insert,hs=table.sort,ds=table.remove,
Us=new S.Z([It.g.BAG_UPDATE]),Hs=new S.Z,us=S.Z.new,cs=S.Z.Add,_s=S.Z.AddRang,Is=S.Z.Clear,ms=S.Z.Contains,gs=S.Z.Insert,ps=S.Z.InsertRange,Cs=S.Z.Remove,Ss=S.Z.RemoveAt,
fs=S.Z.IndexOf,ys=S.Z.Count,vs=S.Z.Length,Ds=S.Z.RemoveRange,Es=S.Z.GetRange,Ts=S.Z.Pop,As=S.Z.Reverse,Ls=S.Z.Sort,ws=m.X.new,Rs=m.X.LuaDic_Add,Os=m.X.LuaDic_SetItem,
Gs=m.X.LuaDic_IsNullValue,bs=m.X.LuaDic_GetItem,Ms=m.X.LuaDic_Count,Ps=m.X.LuaDic_ContainsKey,Bs=m.X.LuaDic_AddOrSetItem,xs=m.X.LuaDic_Keys,Ns=m.X.LuaDic_Values,
ks=m.X.LuaDic_Clear,Vs=m.X.LuaDic_ContainsValue,Fs=m.X.LuaDic_Remove}_GetTriggerCommonEventList(){return Us}_GetTriggerRoleEventList(){return Hs}CheckCondition(){
const t=p.Y.Inst.primaryRoleInfoList
for(const[e,i]of(0,s.V5)(t)){const t=(0,os.tw)(i.job)
if(this.listValue.IndexOf(t)>-1)return!0}return!1}GetCommonDes(t){if(null==t&&(t=""),this.CheckCondition()){const e=this.desc
return 0==this.overwrite?t+e:e}return""}Test1(){return!0}S_Test(){return!0}}class Zs extends r.${CheckCondition(){return dt.a.Inst_get().IsHaveCoinInspirCount()}}
class js extends r.${CheckCondition(){return Ve.b.Inst.currentMapId_get()!=this.intValue}}class Xs extends r.${CheckCondition(){
const t=ki.p.Inst_get().GetMapById(Ve.b.Inst.currentMapId_get())
return null!=this.intValue?t.senceType!=`${this.intValue}`:t.controllerType!=Ni.N.SCENE}}var Ys=i(73341),Ws=i(8211)
class $s extends r.${FastCheckCondition(t,e,i){let s=null
return null!=t&&(s=t.createIdx),null!=Ys.F.Inst_get().control.DPanel_get()&&Ys.F.Inst_get().control.DPanel_get().isShow_get()&&Ys.F.Inst_get().control.DPanel_get().noviceShopView.node.activeSelf()&&Ws.N.GetInst().m_npcId==this.intValue
}}class Js extends r.${FastCheckCondition(t,e,i){let s=null
return null!=t&&(s=t.createIdx),INS.uIShowShortCut.CheckUIOpenByUIShortCutType(this.intValue,s)}CheckCondition(){return INS.uIShowShortCut.CheckGoUIByUIShortCutType(this.intValue)}
}class zs extends r.${FastCheckCondition(t,e,i){if(o.u.Inst().isClickAcccess)return!1
const s=o.u.Inst().mapPassResultVo
return!(null==s||!s.activeGuide||s.mapid!=Ve.b.Inst.lastMapId&&s.mapid!=Ve.b.Inst.currentMapId_get()||s.success)}CheckCondition(){return!1}}class Qs extends r.${CheckCondition(){
return o.u.Inst().IsFix()}}var Ks=i(98504)
class tn extends r.${constructor(...t){super(...t),this.value=null}ParseCommonTypeValue(t){this.intType=t.intType,this.value=t.value}CheckCondition(){
const t=o.u.Inst().GetMapPassVo(this.value)
return null!=t&&null!=t.state&&t.state==Ks.s.PASS}}var en=i(65550)
let sn=null,nn=null,ln=null,an=null
class on extends r.${constructor(...t){super(...t),this.minLv=-1,this.maxLv=-1,this.value=null}static __StaticInit(){sn=table.insert,nn=table.sort,ln=table.remove,
an=new S.Z([It.g.PLAYER_LEVELUP])}_GetTriggerCommonEventList(){return an}CheckCondition(){const t=p.Y.Inst.PrimaryRoleInfo_get().Level_get()
return null==this.value?t>=this.minLv&&t<=this.maxLv:t>=I.M.String2Int(this.value)}GetCommonDes(t){return null==t&&(t=""),`${t}角色等级要达到${this.value}`}
FastCheckOnePlayerCondition(t,e,i,s,n){null==i&&(i=!1)
const l=p.Y.Inst.PrimaryRoleInfo_get().Level_get()
return l<this.minLv?(i&&(null==s?en.y.inst.ClientSysStrMsg(`当前等级低于${this.minLv}`):en.y.inst.ClientSysMessage(s,this.minLv)),
!1):!(l>this.maxLv)||(i&&(null==s?en.y.inst.ClientSysStrMsg(`当前等级高于${this.maxLv}`):en.y.inst.ClientSysMessage(s,this.maxLv)),!1)}ParseCommonTypeValue(t){if(this.intType=t.intType,
I.M.IndexOf(t.value,"_",0)>-1){const e=d.o.GetIntArr(t.value,"_")
this.minLv=e[0],this.maxLv=e[1]}else if(I.M.IndexOf(t.value,",",0)>-1){const e=d.o.GetIntArr(t.value,",")
this.minLv=e[0],this.maxLv=e[1]}else this.minLv=I.M.String2Int(t.value),this.maxLv=9999}}class rn extends r.${FastCheckCondition(t,e,i){let s=null
null!=t&&(s=t.m_id)
return u.L.Inst_get().model.IsFixStepOrFixAttr(this.intValue,s)}}class hn extends r.${FastCheckCondition(t,e,i){let s=null
null!=t&&(s=t.m_id)
return!u.L.Inst_get().model.IsFixStepOrFixAttr(this.intValue,s)}}var dn=i(92202)
let un=null,cn=null,_n=null,In=null,mn=null,gn=null,pn=null,Cn=null,Sn=null,fn=null,yn=null,vn=null,Dn=null,En=null,Tn=null,An=null,Ln=null,wn=null,Rn=null,On=null,Gn=null,bn=null,Mn=null,Pn=null,Bn=null,xn=null,Nn=null,kn=null,Vn=null,Fn=null,Un=null,Hn=null,qn=null,Zn=null,jn=null
class Xn extends r.${constructor(...t){super(...t),this.desc=null,this.overwrite=null}static __StaticInit(){un=table.insert,cn=table.sort,_n=table.remove,
Zn=new S.Z([It.g.BAG_UPDATE]),jn=new S.Z,In=S.Z.new,mn=S.Z.Add,gn=S.Z.AddRang,pn=S.Z.Clear,Cn=S.Z.Contains,Sn=S.Z.Insert,fn=S.Z.InsertRange,yn=S.Z.Remove,vn=S.Z.RemoveAt,
Dn=S.Z.IndexOf,En=S.Z.Count,Tn=S.Z.Length,An=S.Z.RemoveRange,Ln=S.Z.GetRange,wn=S.Z.Pop,Rn=S.Z.Reverse,On=S.Z.Sort,Gn=m.X.new,bn=m.X.LuaDic_Add,Mn=m.X.LuaDic_SetItem,
Pn=m.X.LuaDic_IsNullValue,Bn=m.X.LuaDic_GetItem,xn=m.X.LuaDic_Count,Nn=m.X.LuaDic_ContainsKey,kn=m.X.LuaDic_AddOrSetItem,Vn=m.X.LuaDic_Keys,Fn=m.X.LuaDic_Values,
Un=m.X.LuaDic_Clear,Hn=m.X.LuaDic_ContainsValue,qn=m.X.LuaDic_Remove}_GetTriggerCommonEventList(){return Zn}_GetTriggerRoleEventList(){return jn}CheckCondition(){
const t=dn.O.Inst_get().GetHorseDataById(this.intValue)
return null!=t&&t.IsActive()}GetCommonDes(t){if(null==t&&(t=""),this.CheckCondition()){const e=this.desc
return 0==this.overwrite?t+e:e}return""}Test1(){return!0}S_Test(){return!0}}class Yn extends r.${constructor(...t){super(...t),this.value=null}ParseCommonTypeValue(t){
this.intType=t.intType,this.value=(0,os.aI)(t.value)}CheckCondition(){return null!=this.value&&null!=Ws.N.GetInst().GetInfo(this.value)}}var Wn=i(70829),$n=i(50748)
let Jn=null,zn=null,Qn=null,Kn=null,tl=null,el=null,il=null,sl=null,nl=null,ll=null,al=null,ol=null,rl=null,hl=null,dl=null,ul=null,cl=null,_l=null,Il=null,ml=null,gl=null,pl=null,Cl=null,Sl=null,fl=null,yl=null,vl=null,Dl=null,El=null,Tl=null,Al=null,Ll=null,wl=null,Rl=null,Ol=null
class Gl extends r.${constructor(...t){super(...t),this.desc=null,this.overwrite=null}static __StaticInit(){Jn=table.insert,zn=table.sort,Qn=table.remove,
Rl=new S.Z([It.g.BAG_UPDATE]),Ol=new S.Z,Kn=S.Z.new,tl=S.Z.Add,el=S.Z.AddRang,il=S.Z.Clear,sl=S.Z.Contains,nl=S.Z.Insert,ll=S.Z.InsertRange,al=S.Z.Remove,ol=S.Z.RemoveAt,
rl=S.Z.IndexOf,hl=S.Z.Count,dl=S.Z.Length,ul=S.Z.RemoveRange,cl=S.Z.GetRange,_l=S.Z.Pop,Il=S.Z.Reverse,ml=S.Z.Sort,gl=m.X.new,pl=m.X.LuaDic_Add,Cl=m.X.LuaDic_SetItem,
Sl=m.X.LuaDic_IsNullValue,fl=m.X.LuaDic_GetItem,yl=m.X.LuaDic_Count,vl=m.X.LuaDic_ContainsKey,Dl=m.X.LuaDic_AddOrSetItem,El=m.X.LuaDic_Keys,Tl=m.X.LuaDic_Values,
Al=m.X.LuaDic_Clear,Ll=m.X.LuaDic_ContainsValue,wl=m.X.LuaDic_Remove}_GetTriggerCommonEventList(){return Rl}_GetTriggerRoleEventList(){return Ol}CheckCondition(){
const t=p.Y.Inst.primaryRoleInfoList
let e=0,i=0
for(const[n,l]of(0,s.V5)(t)){const t=Wn.j.Inst().GetSkillById(this.intValue)
if(zt.Z.GetJobKind(t.job)==zt.Z.GetJobKind(l.job)){e+=1
null!=$n.m.Inst().GetSkillByStudyDic(this.intValue,l)&&(i+=1)}}return i>=e}GetCommonDes(t){if(null==t&&(t=""),this.CheckCondition()){const e=this.desc
return 0==this.overwrite?t+e:e}return""}Test1(){return!0}S_Test(){return!0}}class bl extends r.${CheckCondition(){return!0}}var Ml=i(15771)
let Pl=null,Bl=null,xl=null,Nl=null,kl=null,Vl=null,Fl=null,Ul=null,Hl=null,ql=null,Zl=null,jl=null,Xl=null,Yl=null,Wl=null,$l=null,Jl=null,zl=null,Ql=null,Kl=null,ta=null,ea=null,ia=null,sa=null,na=null,la=null,aa=null,oa=null,ra=null,ha=null,da=null,ua=null,ca=null
class _a extends r.${constructor(...t){super(...t),this.vipLv=-1,this.vipLv2=0}static __StaticInit(){Pl=table.insert,Bl=table.sort,xl=table.remove,Nl=S.Z.new,kl=S.Z.Add,
Vl=S.Z.AddRang,Fl=S.Z.Clear,Ul=S.Z.Contains,Hl=S.Z.Insert,ql=S.Z.InsertRange,Zl=S.Z.Remove,jl=S.Z.RemoveAt,Xl=S.Z.IndexOf,Yl=S.Z.Count,Wl=S.Z.Length,$l=S.Z.RemoveRange,
Jl=S.Z.GetRange,zl=S.Z.Pop,Ql=S.Z.Reverse,Kl=S.Z.Sort,ta=m.X.new,ea=m.X.LuaDic_Add,ia=m.X.LuaDic_SetItem,sa=m.X.LuaDic_IsNullValue,na=m.X.LuaDic_GetItem,la=m.X.LuaDic_Count,
aa=m.X.LuaDic_ContainsKey,oa=m.X.LuaDic_AddOrSetItem,ra=m.X.LuaDic_Keys,ha=m.X.LuaDic_Values,da=m.X.LuaDic_Clear,ua=m.X.LuaDic_ContainsValue,ca=m.X.LuaDic_Remove}CheckCondition(){
const t=Ml.U.inst.model.level_get()
return t>=this.vipLv&&t<=this.vipLv2}GetCommonDes(){return`VIP等级不在${this.vipLv}-${this.vipLv2}`}ParseCommonTypeValue(t){if(this.createIdx=t.createIdx,
t.intType>0?this.intType=t.intType:this.intType=Ja.VIPLevel_Val,!I.M.IsNullOrEmpty(t.value)){const e=d.o.GetIntArr(t.value)
this.vipLv=e[0],this.vipLv2=e[1]}}}
let Ia=null,ma=null,ga=null,pa=null,Ca=null,Sa=null,fa=null,ya=null,va=null,Da=null,Ea=null,Ta=null,Aa=null,La=null,wa=null,Ra=null,Oa=null,Ga=null,ba=null,Ma=null,Pa=null,Ba=null,xa=null,Na=null,ka=null,Va=null,Fa=null,Ua=null,Ha=null,qa=null,Za=null,ja=null,Xa=null
class Ya extends r.${constructor(...t){super(...t),this.vipLv=-1}static __StaticInit(){Ia=table.insert,ma=table.sort,ga=table.remove,pa=S.Z.new,Ca=S.Z.Add,Sa=S.Z.AddRang,
fa=S.Z.Clear,ya=S.Z.Contains,va=S.Z.Insert,Da=S.Z.InsertRange,Ea=S.Z.Remove,Ta=S.Z.RemoveAt,Aa=S.Z.IndexOf,La=S.Z.Count,wa=S.Z.Length,Ra=S.Z.RemoveRange,Oa=S.Z.GetRange,Ga=S.Z.Pop,
ba=S.Z.Reverse,Ma=S.Z.Sort,Pa=m.X.new,Ba=m.X.LuaDic_Add,xa=m.X.LuaDic_SetItem,Na=m.X.LuaDic_IsNullValue,ka=m.X.LuaDic_GetItem,Va=m.X.LuaDic_Count,Fa=m.X.LuaDic_ContainsKey,
Ua=m.X.LuaDic_AddOrSetItem,Ha=m.X.LuaDic_Keys,qa=m.X.LuaDic_Values,Za=m.X.LuaDic_Clear,ja=m.X.LuaDic_ContainsValue,Xa=m.X.LuaDic_Remove}CheckCondition(){
return Ml.U.inst.model.level_get()>=this.vipLv}GetCommonDes(){return`VIP等级低于${this.vipLv}`}ParseCommonTypeValue(t){super.ParseCommonTypeValue(t),this.vipLv=this.intValue}}
class Wa extends r.${CheckCondition(){return p.Y.Inst.PrimaryRoleInfo_get().HonourShop_Point_get()>=this.intValue}}class $a extends r.${FastCheckCondition(t,e,i){
return null==t&&(t=p.Y.Inst.PrimaryRoleInfo_get()),t.HasEquipmentById(this.intValue)}ParseCommonTypeValue(t){super.ParseCommonTypeValue(t),
null!=this.createIdx&&0!=this.createIdx||(this.createIdx=-1)}}class Ja{static __StaticInit(){for(const[t,e]of(0,s.X)(Ja.s_ValToType))null==e[1]||(Ja.s_TypeToVal[e[0]]=t)}Test1(){
return!0}static CreateFromJson(t){let e=t.type
null==e&&(e=t.__type)
let i=null
const s=Ja.GetClassByType(e)
return null!=s&&(i=a.C.CreateBaseJsonClass(t,s),i.intType=Ja.TypeToVal(e)),i}CreateFromJsonFast(t){
return a.C.CreateBaseJsonClassFast(t,Ja.GetClassByType,Ja.OnCreateBaseJsonClassFast)}static OnCreateBaseJsonClassFast(t,e,i){t.intType=Ja.TypeToVal(e)}static GetClassByType(t){
const e=Ja.s_TypeToVal[t]
if(null==e)return null
return Ja.s_ValToType[e][1]()}static GetClassByIntType(t){if(null==Ja.s_ValToType[t])return null
if(null==Ja.s_ValToType[t][1]){}return Ja.s_ValToType[t][1]()}static TypeToVal(t){let e=Ja.s_TypeToVal[t]
return null==e&&(e=null,n.Y.LogError(`GameConditionType intType is nil? ${t}`)),e}ValToType(t){return Ja.s_ValToType[t][0]}}Ja.PlayersLevelGT_Val=1,Ja.PlayersGTLevel_Val=1e3,
Ja.VIPLevelGT_Val=2,Ja.AttrGT_Val=3,Ja.BagGetItemGT_Val=4,Ja.Ride_Val=1001,Ja.SkillId_Val=1002,Ja.Job_Val=1003,Ja.Create_Val=1004,Ja.SameCreate_Val=1005,
Ja.COND_TYPE_QUEST_FINISHED_VAL=5,Ja.COND_TYPE_QUEST_COMPLETE_VAL=6,Ja.COND_TYPE_LEVEL=7,Ja.COND_TYPE_FUNCTION_INIT_VAL=8,Ja.COND_TYPE_ENTER_MAP_VAL=9,Ja.COND_LEAVE_MAP_VAL=10,
Ja.COND_TYPE_ENTER_COPY_VAL=11,Ja.COND_TYPE_ENTER_COPY_BY_TYPE_VAL=12,Ja.COND_LEAVE_ANY_COPY_VAL=13,Ja.COND_TYPE_QUEST_FINISH_NONEXT_VAL=14,Ja.COND_OPEN_UI_VAL=15,
Ja.COND_CLOSE_UI_VAL=16,Ja.COND_CLICK_BTN_VAL=17,Ja.COND_TYPE_TASK_CLICK_VAL=18,Ja.COND_TYPE_CopyResult_VAL=19,Ja.COND_TYPE_CopyResult_BY_GROUP_VAL=20,
Ja.COND_BOUNTY_TASK_FINISHED_VAL=21,Ja.COND_GOLD_DEMAND_VAL=22,Ja.COND_GOLD_LACK_VAL=23,Ja.FIRST_TITLE_VAL=24,Ja.COND_EQUIP_ENHANCE_VAL=25,Ja.COND_BATTLESCORE_LARGER_VAL=27,
Ja.COND_MIRACLE_REWARD_VAL=28,Ja.COND_LEVEL_LOWER_VAL=29,Ja.COND_LEVEL_HIGHER_VAL=30,Ja.COND_LEVEL_RANGE_VAL=31,Ja.HAVE_REWARD_FUN_VAL=32,Ja.COND_TYPE_FUNCTION_NOT_OPEN_VAL=33,
Ja.COND_TYPE_IN_SCENE_MAP_VAL=34,Ja.COND_TYPE_NOT_IN_SCENE_MAP_VAL=35,Ja.COND_TYPE_NOT_IN_MAP_VAL=36,Ja.LIVENESS_VAL=37,Ja.VITALITY_VAL=38,Ja.EQUIP_TAKE_ON_VAL=39,
Ja.COND_TYPE_FUNCTION_OPEN_VAL=40,Ja.COND_TYPE_FIRST_CLOSE_PANDORABOX_VAL=41,Ja.CUR_COPY_MISS_COIN_ENCOURAGE_VAL=42,Ja.COND_TYPE_TICK_20_VAL=43,
Ja.COND_NONE_COIN_INSPRIRE_IN_COPY_VAL=44,Ja.COND_TYPE_NPC_SHOP_VAL=45,Ja.COND_TYPE_ENTER_MAP_BEFORE_VAL=46,Ja.COND_TYPE_CREATE_ROLE_BEFORE_VAL=47,
Ja.COND_TYPE_ENTER_COPY_BEFORE_VAL=48,Ja.COND_TYPE_ENTER_COPY_BEFORE_NO_LOADING_VAL=49,Ja.COND_TYPE_LEVEL_VAL=50,Ja.COND_TYPE_ACCEPT_QUEST_NOFINISH_VAL=51,
Ja.COND_TYPE_QUEST_FIXSTEP_VAL=52,Ja.COND_TYPE_QUEST_NO_FIXSTEP_VAL=53,Ja.COND_TYPE_ENTER_COPY_BY_GROUP_VAL=54,Ja.WEAREQUIPMENT_VAL=55,Ja.COND_TYPE_ACCEPT_QUEST_VAL=56,
Ja.CON_GUIDE_NEXT_VAL=57,Ja.STORY_END_VAL=58,Ja.COND_TYPE_QUEST_FINISHED_DIALOG_VAL=60,Ja.COND_BATTLESCORE_RANGE_VAL=61,Ja.ACC_CHECKPOINT=62,Ja.COND_GUIDE_EVENT_VAL=63,
Ja.CLICK_UI_TASK_ITEM=64,Ja.COND_PASS_BOSS_FAIL_VAL=65,Ja.PASS_CHECKPOINT=66,Ja.COND_PASS_BOSS_FIX_VAL=67,Ja.SHOPID_EXIST=68,Ja.COND_FAIL_MAP_PASS=69,Ja.VIPLevel_Val=70,
Ja.s_TypeToVal={},Ja.s_ValToType={[Ja.PlayersGTLevel_Val]:["GTLevel",()=>on],[Ja.PlayersLevelGT_Val]:["LevelGT",()=>on],[Ja.VIPLevelGT_Val]:["VIPLevelGT",()=>Ya],
[Ja.VIPLevel_Val]:["VIPLevel",()=>_a],[Ja.AttrGT_Val]:["AttrGT",()=>it],[Ja.BagGetItemGT_Val]:["GetBagItemGT",()=>Mi],[Ja.Ride_Val]:["RIDE_ID",()=>Xn],
[Ja.SkillId_Val]:["SKILL_ID",()=>Gl],[Ja.Job_Val]:["NeedJob",()=>qs],[Ja.Create_Val]:["CREATE",()=>Jt],[Ja.SameCreate_Val]:["SAMECREATE",()=>Me],
[Ja.COND_TYPE_ACCEPT_QUEST_VAL]:[l.z.COND_TYPE_ACCEPT_QUEST,()=>_],[Ja.COND_TYPE_QUEST_FINISHED_VAL]:[l.z.COND_TYPE_QUEST_FINISHED,()=>He],
[Ja.COND_TYPE_QUEST_COMPLETE_VAL]:[l.z.COND_TYPE_QUEST_COMPLETE,()=>ht],[Ja.COND_TYPE_ACCEPT_QUEST_NOFINISH_VAL]:[l.z.COND_TYPE_ACCEPT_QUEST_NOFINISH,()=>g],
[Ja.COND_TYPE_QUEST_FIXSTEP_VAL]:[l.z.COND_TYPE_QUEST_FIXSTEP,()=>rn],[Ja.COND_TYPE_QUEST_NO_FIXSTEP_VAL]:[l.z.COND_TYPE_QUEST_NO_FIXSTEP,()=>hn],
[Ja.COND_TYPE_LEVEL_VAL]:[l.z.COND_TYPE_LEVEL,()=>on],[Ja.COND_TYPE_QUEST_FINISH_NONEXT_VAL]:[l.z.COND_TYPE_QUEST_FINISH_NONEXT,()=>qe],
[Ja.COND_OPEN_UI_VAL]:[l.z.COND_OPEN_UI,()=>Js],[Ja.COND_CLOSE_UI_VAL]:[l.z.COND_CLOSE_UI,()=>rt],[Ja.COND_CLICK_BTN_VAL]:[l.z.COND_CLICK_BTN,()=>at],
[Ja.CLICK_UI_TASK_ITEM]:[l.z.CLICK_UI_TASK_ITEM,()=>ot],[Ja.COND_TYPE_ENTER_MAP_VAL]:[l.z.COND_TYPE_ENTER_MAP,()=>Fe],[Ja.COND_LEAVE_MAP_VAL]:[l.z.COND_LEAVE_MAP,()=>Ui],
[Ja.COND_TYPE_IN_SCENE_MAP_VAL]:[l.z.COND_TYPE_IN_SCENE_MAP,()=>Vi],[Ja.COND_TYPE_NOT_IN_SCENE_MAP_VAL]:[l.z.COND_TYPE_NOT_IN_SCENE_MAP,()=>Xs],
[Ja.COND_TYPE_NOT_IN_MAP_VAL]:[l.z.COND_TYPE_NOT_IN_MAP,()=>js],[Ja.COND_TYPE_ENTER_COPY_VAL]:[l.z.COND_TYPE_ENTER_COPY,()=>xe],
[Ja.COND_TYPE_ENTER_COPY_BY_GROUP_VAL]:[l.z.COND_TYPE_ENTER_COPY_BY_GROUP,()=>ke],[Ja.COND_LEAVE_ANY_COPY_VAL]:[l.z.COND_LEAVE_ANY_COPY,()=>Fi],
[Ja.COND_TYPE_CopyResult_VAL]:[l.z.COND_TYPE_CopyResult,()=>ct],[Ja.COND_TYPE_CopyResult_BY_GROUP_VAL]:[l.z.COND_TYPE_CopyResult_BY_GROUP,()=>_t],
[Ja.COND_LEVEL_LOWER_VAL]:[l.z.COND_LEVEL_LOWER,()=>zi],[Ja.COND_LEVEL_HIGHER_VAL]:[l.z.COND_LEVEL_HIGHER,()=>Xi],[Ja.COND_LEVEL_RANGE_VAL]:[l.z.COND_LEVEL_RANGE,()=>is],
[Ja.COND_FAIL_MAP_PASS]:[l.z.COND_FAIL_MAP_PASS,()=>as],[Ja.COND_BATTLESCORE_LARGER_VAL]:[l.z.COND_BATTLESCORE_LARGER,()=>st],
[Ja.COND_BATTLESCORE_RANGE_VAL]:[l.z.COND_BATTLESCORE_RANGE,()=>nt],[Ja.COND_TYPE_FUNCTION_OPEN_VAL]:[l.z.COND_TYPE_FUNCTION_OPEN,()=>Je.O],
[Ja.HAVE_REWARD_FUN_VAL]:[l.z.HAVE_REWARD_FUN,()=>Ye],[Ja.COND_TYPE_FUNCTION_NOT_OPEN_VAL]:[l.z.COND_TYPE_FUNCTION_NOT_OPEN,()=>$e],
[Ja.COND_EQUIP_ENHANCE_VAL]:[l.z.COND_EQUIP_ENHANCE,()=>Be],[Ja.COND_GOLD_DEMAND_VAL]:[l.z.COND_GOLD_DEMAND,()=>Pi],[Ja.COND_GOLD_LACK_VAL]:[l.z.COND_GOLD_LACK,()=>Bi],
[Ja.FIRST_TITLE_VAL]:[l.z.FIRST_TITLE,()=>je],[Ja.WEAREQUIPMENT_VAL]:[l.z.WEAREQUIPMENT,()=>$a],[Ja.LIVENESS_VAL]:[l.z.LIVENESS,()=>ns],[Ja.VITALITY_VAL]:[l.z.VITALITY,()=>Wa],
[Ja.ACC_CHECKPOINT]:[l.z.ACC_CHECKPOINT,()=>h],[Ja.PASS_CHECKPOINT]:[l.z.PASS_CHECKPOINT,()=>tn],[Ja.SHOPID_EXIST]:[l.z.SHOPID_EXIST,()=>Yn],
[Ja.COND_TYPE_ENTER_COPY_BY_TYPE_VAL]:[l.z.COND_TYPE_ENTER_COPY_BY_TYPE,()=>Ue],[Ja.COND_TYPE_TICK_20_VAL]:[l.z.COND_TYPE_TICK_20,()=>bl],
[Ja.CUR_COPY_MISS_COIN_ENCOURAGE_VAL]:[l.z.CUR_COPY_MISS_COIN_ENCOURAGE,()=>ut],[Ja.COND_TYPE_FIRST_CLOSE_PANDORABOX_VAL]:[l.z.COND_TYPE_FIRST_CLOSE_PANDORABOX,()=>Ze],
[Ja.COND_NONE_COIN_INSPRIRE_IN_COPY_VAL]:[l.z.COND_NONE_COIN_INSPRIRE_IN_COPY,()=>Zs],[Ja.COND_TYPE_NPC_SHOP_VAL]:[l.z.COND_TYPE_NPC_SHOP,()=>$s],
[Ja.COND_TYPE_ENTER_MAP_BEFORE_VAL]:[l.z.COND_TYPE_ENTER_MAP_BEFORE,null],[Ja.COND_TYPE_CREATE_ROLE_BEFORE_VAL]:[l.z.COND_TYPE_CREATE_ROLE_BEFORE,null],
[Ja.COND_TYPE_ENTER_COPY_BEFORE_VAL]:[l.z.COND_TYPE_ENTER_COPY_BEFORE,null],[Ja.COND_TYPE_ENTER_COPY_BEFORE_NO_LOADING_VAL]:[l.z.COND_TYPE_ENTER_COPY_BEFORE_NO_LOADING,null],
[Ja.CON_GUIDE_NEXT_VAL]:[l.z.CON_GUIDE_NEXT,null],[Ja.STORY_END_VAL]:[l.z.STORY_END,null],[Ja.COND_TYPE_QUEST_FINISHED_DIALOG_VAL]:[l.z.COND_TYPE_QUEST_FINISHED_DIALOG,null],
[Ja.COND_BOUNTY_TASK_FINISHED_VAL]:[l.z.COND_BOUNTY_TASK_FINISHED,()=>lt],[Ja.COND_GUIDE_EVENT_VAL]:[l.z.COND_GUIDE_EVENT,()=>xi.e],
[Ja.COND_PASS_BOSS_FAIL_VAL]:[l.z.COND_PASS_BOSS_FAIL,()=>zs],[Ja.COND_PASS_BOSS_FIX_VAL]:[l.z.COND_PASS_BOSS_FIX,()=>Qs]},Ja.__StaticInit()},8849:(t,e,i)=>{i.d(e,{U:()=>V})
var s=i(85602),n=i(38962),l=i(2457)
let a=null,o=null,r=null,h=null,d=null,u=null,c=null,_=null,I=null,m=null,g=null,p=null,C=null,S=null,f=null,y=null,v=null,D=null,E=null,T=null,A=null,L=null,w=null,R=null,O=null,G=null,b=null,M=null,P=null,B=null,x=null,N=null,k=null
class V{static __StaticInit(){a=table.insert,o=table.sort,r=table.remove,h=s.Z.new,d=s.Z.Add,u=s.Z.AddRang,c=s.Z.Clear,_=s.Z.Contains,I=s.Z.Insert,m=s.Z.InsertRange,g=s.Z.Remove,
p=s.Z.RemoveAt,C=s.Z.IndexOf,S=s.Z.Count,f=s.Z.Length,y=s.Z.RemoveRange,v=s.Z.GetRange,D=s.Z.Pop,E=s.Z.Reverse,T=s.Z.Sort,A=n.X.new,L=n.X.LuaDic_Add,w=n.X.LuaDic_SetItem,
R=n.X.LuaDic_IsNullValue,O=n.X.LuaDic_GetItem,G=n.X.LuaDic_Count,b=n.X.LuaDic_ContainsKey,M=n.X.LuaDic_AddOrSetItem,P=n.X.LuaDic_Keys,B=n.X.LuaDic_Values,x=n.X.LuaDic_Clear,
N=n.X.LuaDic_ContainsValue,k=n.X.LuaDic_Remove}constructor(){this.tmp=0,this.conditions=null,this.isCheckConditionAnd=!0,this._triggerCallbackLater=!1,this.conditions=new s.Z}
CheckAllCondition(){if(S(this.conditions)<=0)return!0
if(this.isCheckConditionAnd){let t=0
for(;t<S(this.conditions);){if(!this.conditions[t].CheckCondition())return!1
t+=1}return!0}let t=0
for(;t<S(this.conditions);){if(this.conditions[t].CheckCondition())return!0
t+=1}return!1}OpenTrigger(t){let e=0
for(;e<S(this.conditions);)this.conditions[e].OpenTrigger(t),e+=1}CheckFailCondition(){if(S(this.conditions)<=0)return null
if(this.isCheckConditionAnd){let t=0
for(;t<S(this.conditions);){if(!this.conditions[t].CheckCondition())return this.conditions[t]
t+=1}}return null}CheckOneCondition(t){if(S(this.conditions)<=0)return null
if(this.isCheckConditionAnd){let e=0
for(;e<S(this.conditions);){if(this.conditions[e].Type_get()==t&&!this.conditions[e].CheckCondition())return this.conditions[e]
e+=1}}return null}Test1(){return!0}CreateFromJson(t){if(null==t)return null
const e=new V
for(let i=1;i<=t.length;i++){const s=l.u.CreateFromJson(t[i])
e.conditions.Add(s)}return e}}},61567:(t,e,i)=>{i.d(e,{O:()=>l})
var s=i(37648),n=i(53912)
class l extends n.${CheckCondition(){return s.P.Inst_get().IsFunctionOpened(this.intValue)}}},28613:(t,e,i)=>{i.d(e,{e:()=>l})
var s=i(98885),n=i(53912)
class l extends n.${CheckCondition(){return!1}FastCheckCondition(t,e,i){return this.intValue==l.ALL||(this.intValue==l.ALL||e==this.intValue)}ParseCommonTypeValue(t){
this.intType=t.intType,null!=t.value&&(this.intValue=s.M.String2Int(t.value)),this.createIdx=t.createIdx}}l.ALL=0,l.AusramGuide=1,l.Map_Pass1=2,l.AngelGetFirst=3,
l.AngelGetSecond=4,l.AsuramOpenMap=5,l.AsuramOpenMap2=6,l.AngelGetEnd=20,l.AllianceBuild=21,l.MazeTimeSpace_START=30,l.MazeTimeSpace_START_2=31,l.MazeTimeSpace_COLLECT_END=32,
l.MazeTimeSpace_LEVAE_2=33,l.MazeTimeSpace_KILL_BOSS_FIRST=34,l.MazeTimeSpace_KILL_ALL_BOSS_FIRST=35,l.CLICK_MAPPASS_BTN_NEED_TASK=36,l.MazeTimeSpace_START_CLOSE_UI=37,
l.ROLAN_SAVE_END_ICON_FLY=40,l.FIRST_OPEN_CHANGEJOBCARD=41,l.GUIDE_FINISH=1e4},48933:(t,e,i)=>{i.d(e,{I:()=>d})
var s=i(95721),n=i(5468),l=i(51262),a=i(52212),o=i(79534),r=i(44758),h=i(92679)
class d{isBagInSell_get(){return d._isBagInSell}isBagInSell_set(t){d._isBagInSell!=t&&(d._isBagInSell=t,INS.luaEventMgr.RaiseEvent(h.g.BAG_SELL_STATE_CHANGE))}GetIp(){return d.IP}
GetPort(){return d.Port}}d.account=null,d.reKey=n.E.s_Empty,d.IP=null,d.Port=0,d.IpStraight=null,d.responseRadius=2,d.collectResponseRadius=1.8,d.wallResponseRadius=0,
d.goldmonsterresponseRadius=1,d.SELECT_TARGET_RADIUS=6,d.LOST_TARGET_RADIUS=8,d.cal4Vec0=new r.L,d.calVec0=new o.P,d.calVec1=new o.P,d.calVec2=new o.P,d.calVec3=new o.P,
d.calVec4=new o.P,d.calVec5=new o.P,d.cal2Vec0=new a.F,d.cal2Vec1=new a.F,d.cal2Vec2=new a.F,d.cal2Vec3=new a.F,d.HIDE_POS=new o.P(1e4,0,0),d.zeroLong=s.o.New(0,0),
d.zero2=new a.F(0,0),d.zero3=new o.P(0,0,0),d._isBagInSell=!1,d.checkErrorAnim=!0,d.tmpStrBuilder=new l.H,d.ShowFightLog=!1},64276:(t,e,i)=>{i.d(e,{U:()=>a})
var s=i(98130),n=i(85602)
class l{constructor(){this.type=null,this.value=null,this.func=null}}class a{constructor(){this.conditionList=null}FillData(t){this.conditionList=new n.Z
const e=new n.Z(t.conditionList)
let i=0
for(;i<e.Count();){const t=e[i],n=new l
n.type=s.GF.LuaJsonToString(t.type),n.value=s.GF.LuaJsonToString(t.value),n.func=s.GF.LuaJsonToString(t.func),this.conditionList.Add(n),i+=1}}}},19228:(t,e,i)=>{i.d(e,{N:()=>a})
var s=i(98130),n=i(85602)
class l{constructor(){this.id=0,this.itemId=0,this.runeId=0,this.num=0,this.job=0,this.bind=null,this.showId=0,this.soleAttr=!1}GetModelId(){
return 0!=this.itemId?this.itemId:0!=this.runeId?this.runeId:0}GetIsBind(){return null!=this.bind&&"true"==this.bind.lower()?1:0}}class a{constructor(){this.showAwards=null}
FillData(t){this.showAwards=new n.Z
const e=new n.Z(t.showAwards)
let i=0
for(;i<e.Count();){const t=e[i],n=new l
n.id=s.GF.LuaJsonToNumber(t.id),n.itemId=s.GF.LuaJsonToNumber(t.itemId),n.runeId=s.GF.LuaJsonToNumber(t.runeId),n.num=s.GF.LuaJsonToNumber(t.num),n.job=s.GF.LuaJsonToNumber(t.job),
n.bind=s.GF.LuaJsonToString(t.bind),n.showId=s.GF.LuaJsonToNumber(t.showId),n.soleAttr=s.GF.LuaJsonToBoolean(t.soleAttr),this.showAwards.Add(n),i+=1}}}},64039:(t,e,i)=>{i.d(e,{
S:()=>n})
var s=i(75321)
class n{static getPositionByStr(t){return s.C.GetEquipEnum(t)}}},48876:(t,e,i)=>{i.d(e,{u:()=>n})
var s=i(98130)
class n{constructor(){this.attrModelId=null,this.level=null,this.campType=null,this.sex=null}FillData(t){this.attrModelId=s.GF.LuaJsonToNumber(t.attrModelId),
this.level=s.GF.LuaJsonToNumber(t.level),this.campType=s.GF.LuaJsonToNumber(t.campType),this.sex=s.GF.LuaJsonToNumber(t.sex)}}},92816:(t,e,i)=>{i.d(e,{k:()=>s})
class s{constructor(){this.type=null,this.value=null}}},98763:(t,e,i)=>{i.d(e,{P:()=>a})
var s=i(98130),n=i(85602),l=i(92816)
class a{constructor(){this.contents=null}FillData(t){this.contents=new n.Z
const e=new n.Z(t.contents)
let i=0
for(;i<e.Count();){const t=e[i],n=new l.k
n.type=s.GF.LuaJsonToString(t.type),n.value=s.GF.LuaJsonToString(t.value),this.contents.Add(n),i+=1}}}},15780:(t,e,i)=>{i.d(e,{U:()=>s})
class s{constructor(){this.type=null,this.value=null}Clone(){const t=new s
return t.type=this.type,t.value=this.value,t}}},46245:(t,e,i)=>{i.d(e,{l:()=>o})
var s=i(98130),n=i(85602),l=i(17838)
class a{constructor(){this.type=null,this.value=0}}class o{constructor(){this.costs=null}FillData(t){this.costs=new n.Z
const e=new n.Z(t.costs)
let i=0
for(;i<e.Count();){const t=e[i],n=new a
n.type=s.GF.LuaJsonToString(t.type),n.value=s.GF.LuaJsonToNumber(t.value),this.costs.Add(n),i+=1}}static CreateFromJson(t){const e=new o
if(e.costs=new n.Z,null!=t)for(let i=1;i<=t.length;i++){const s=new a
l.g.FillJsonData(s,t[i],!0),e.costs.Add(s)}return e}}},52235:(t,e,i)=>{i.d(e,{p:()=>l})
var s=i(98130),n=i(85602)
class l{constructor(){this.sysTip=null}FillData(t){this.sysTip=new n.Z
const e=new n.Z(t.sysTip)
let i=0
for(;i<e.Count();){const t=s.GF.LuaJsonToNumber(e[i])
this.sysTip.Add(t),i+=1}}}},81613:(t,e,i)=>{i.d(e,{i:()=>a})
var s=i(98130),n=i(85602),l=i(46899)
class a{constructor(){this.questId=null,this.icon=null,this.access=null,this.desc=null}FillData(t){this.questId=s.GF.LuaJsonToNumber(t.questId),
this.icon=s.GF.LuaJsonToString(t.icon),t.access=new n.Z(t.access),this.access=new n.Z
for(let e=0;e<=t.access.Count()-1;e++)this.access[e]=new l.m,this.access[e].FillData(t.access[e])
this.desc=s.GF.LuaJsonToString(t.desc)}}},98664:(t,e,i)=>{i.d(e,{o:()=>o})
var s=i(38836),n=i(98130),l=i(85602)
class a{constructor(){this.vipLevel=null,this.count=null}Parse(){}}class o{constructor(){this.values=null}FillData(t){this.values=new l.Z
const e=new l.Z(t.values)
let i=0
for(;i<e.Count();){const t=e[i],s=new a
s.vipLevel=n.GF.LuaJsonToNumber(t.vipLevel),s.count=n.GF.LuaJsonToNumber(t.count),this.values.Add(s),i+=1}}Parse(){for(const[t,e]of(0,s.V5)(this.values))e.Parse()}}},
72439:(t,e,i)=>{i.d(e,{t:()=>n})
var s=i(86133)
class n{GetAttrNameByType(t){return t==n.strengthLimit?(0,s.T)("力量"):t==n.agilityLimit?(0,s.T)("敏捷"):t==n.vitalityLimit?(0,s.T)("体力"):t==n.intelligenceLimit?(0,s.T)("智力"):""}}
n.strengthLimit=0,n.agilityLimit=1,n.vitalityLimit=2,n.intelligenceLimit=3},73341:(t,e,i)=>{i.d(e,{F:()=>H})
var s=i(38836),n=i(93984),l=i(62370),a=i(66788),o=i(55360),r=i(98885),h=i(85602),d=i(38962),u=i(52212),c=i(87923),_=i(75439),I=i(17783),m=i(98580),g=i(63412),p=i(82268)
class C{constructor(){this.m_dic=null,this.roleScale=0,this.roleOffset=null,this.roleAngle=0,this.selectFunModel=null,this.roleOffset=new u.F,this.GetConfig()}GetConfig(){
const t=_.D.getInstance().getContent("DIALOG:PLAYER_MODEL").getContent().stringVal,e=r.M.Split(t,r.M.s_SPAN_CHAR_DOT)
this.roleScale=r.M.String2Float(e[0]),this.roleAngle=r.M.String2Int(e[2])
const i=r.M.Split(e[1],l.o.s_UNDER_CHAR),s=r.M.String2Float(i[0]),n=r.M.String2Float(i[1])
this.roleOffset=new u.F(s,n).Clone()}GetModel(t){if(null==this.m_dic){const t=o.Y.Inst.GetOrCreateCsv(n.h.eNpcFunctionResource).GetCsvMap()
this.m_dic=new d.X
for(const[e,i]of(0,s.V5)(t)){const t=new p.d
t.rescource=i,this.m_dic.LuaDic_AddOrSetItem(i.Id,t)}}const e=this.m_dic[t]
return null==e&&a.Y.LogError(`NpcfunctionresourceCsv 找不到 id：${t}`),e}getTaskBtns(t){const e=new h.Z
for(const i of t){const t=new p.d
t.diaglogButton=i,e.Add(t)}return console.log(e),e}isTaskLink(t,e,i){let s=!1
if(t.status_get()!=m.B.CAN_ACCEPT&&t.status_get()!=m.B.ACCEPTED&&t.status_get()!=m.B.FINISHED||(t.isTalk_get()||t.IsRealTalk_get()||t.IsCopy_get()||t.isHandInTask_get()||t.IsCurrency_get()?s=!0:(t.GetIntersectionType()==g.U.INTERSECTION_NPC&&t.RewardNpcId_get()==e.npcid&&(s=!0),
t.resource_get().receiveType==g.U.RECEIVE_BY_NPC&&t.AcceptNpcId_get()==e.npcid&&(s=!0))),s&&t.IsCopy_get())for(const e of i)if(e.IsSameCopy(t.TaskCopyId_get())){s=!1
break}return s}GetNpcTasks(t,e){const i=new h.Z,s=I.L.Inst_get().model.GetLinkNpcs(t.npcid)
let n=0
for(;n<s.Count();){const l=s[n]
if(l.isShowToDialogue_get()){if(this.isTaskLink(l,t,e)){const t=new p.d
t.taskConfig=l,i.Add(t)}}n+=1}return i}GetNpcFuns(t){const e=new h.Z
if(!c.l.IsEmptyStr(t.npcFunction)){const i=r.M.Split(t.npcFunction,l.o.s_Arr_UNDER_CHAR_DOT)
let s=0
for(;s<i.count;){const t=r.M.String2Int(i[s]),n=this.GetModel(t)
null!=n&&n.isEnougth_get()&&e.Add(n),s+=1}}return e}GetNpcTaskAndFun(t){const e=new h.Z,i=this.GetNpcFuns(t),s=this.GetNpcTasks(t,i)
let n=0
for(;n<i.Count();)e.Add(i[n]),n+=1
let l=0
const a=i.count-1
for(;l<s.Count();){let t=!0
for(let e=0;e<=a;e++){if(i[e].enoughTaskId==s[l].taskConfig.id_get()){t=!1
break}}t&&e.Add(s[l]),l+=1}return e}GetTaskDialogFunList(t){if(r.M.IsNullOrEmpty(t.func))return null
const e=new h.Z,i=r.M.Split(t.func,l.o.s_UNDER_CHAR)
let s=0
for(;s<i.count;){const t=r.M.String2Int(i[s]),n=this.GetModel(t)
null!=n&&n.isEnougth_get()&&e.Add(n),s+=1}return e}GetFunModelByTask(t,e){if(null==t||null==e)return null
for(const i of t)if(null!=i.taskConfig&&i.taskConfig.id_get()==e.id_get())return i
return null}}
var S=i(17409),f=i(98800),y=i(56937),v=i(18202),D=i(31222),E=i(5494),T=i(52726),A=i(79534),L=i(80160),w=i(43076),R=i(80062),O=i(29839),G=i(72800),b=i(48933),M=i(77697),P=i(76218),B=i(44644),x=i(61149),N=i(71822),k=i(41759),V=i(30635),F=i(89803)
class U{get m_panel(){return(0,S.Y)(E.I.eDialoguePanel)}constructor(){this.npc=null,this.task=null,this.leftRoleId=null,this.taskList=null,this.endCopyId=0,
this._degf_OnCreateHandler=null,this._degf_OnDestoryPanel=null,this.exParam=null,this.showUI=null,this.isShowNovicePanel=null,this._degf_OnCreateHandler=t=>this.OnCreateHandler(t),
this._degf_OnDestoryPanel=()=>this.OnDestoryPanel()}Open(t,e,i,s,n,l){if(null==e&&(e=!1),null!=i&&null!=i.tCTargetDefs_get()&&null!=i.tCTargetDefs_get().tCTargetDefs){
const t=i.tCTargetDefs_get().tCTargetDefs
if(t.Count()>0&&t[0].type==F.d.TRANSFER_JOB_TEST)return}const a=M.f.Inst().getItemByIdRaw(t)
if(null!=a&&(this.npc=a,this.exParam=s,this.showUI=n,this.isShowNovicePanel=l,!this.IsMidWayEnterJuqing()&&this.IsSiegePartyNpc(a)&&(!L.x.inst.IsAllinceNpc(a)||t!=w.w.Inst_get().bigFireID)&&(this.JudgeInstance()||e))){
this.task=i,P.U.inst.CloseMainPanel(!1),k.q.inst_get().control.Close(),N.g.Inst.CloseView()
const t=new y.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!1,t.isCloseCamera=!1,t.layerType=T.F.NpcTalkUI,t.isSetActiveClose=!0,(0,S.Yp)(E.I.eDialoguePanel,t,this._degf_OnCreateHandler)}
}IsSiegePartyNpc(t){return!0}IsMidWayEnterJuqing(){const t=I.L.Inst_get().model.GetLinkNpcs(this.npc.npcid)
let e=null
if(null!=t&&0!=t.Count()){let i=0
for(;i<t.Count();){const s=t[i]
if(e=s.GetCopyRes(),s.status_get()==m.B.ACCEPTED&&s.IsCopy_get()&&null!=e&&(e.controllerType==G.S.Plot||e.controllerType==G.S.eMap)){const t=s.GetDialogueList()
if(null==t||0==t.Count())return O.p.inst.SendEnterCopy(e.id),x.k.inst.openfanji=!0,!0}i+=1}}return!1}OpenByTask(t,e){
null!=this.m_panel&&this.m_panel.isShow_get()||this.Open(e,!1,t)}OnCreateHandler(t){return this.m_panel,this.m_panel}OnDestoryPanel(){v.g.DestroyUIObj(this.m_panel)}ForceClose(){
null!=this.m_panel&&(D.N.inst.ClosePanel(this.m_panel),this.task=null),this.CloseRobotDialoguePanel()}ResetNpcDir(){null!=this.m_panel&&this.m_panel.ResetNPCDir()}DPanel_get(){
return this.m_panel}GetBelialPanelFatherId(){return this.DPanel_get(),0}JudgeInstance(){if(null==this.npc)return!1
const t=f.Y.Inst.PrimaryRole_get().GetPos(),e=b.I.calVec0
return e.x=this.npc.x,e.y=t.y,e.z=this.npc.y,!(A.P.Distance(t,e)>this.npc.reactDistance+.1)}SendTaskChoose(t){I.L.Inst_get().mgr.RequestCM_AcceptQuest(t)}
OpenRobotDialoguePanel(t,e,i){this.leftRoleId=t,this.taskList=e,this.endCopyId=i,B.T.inst.CloseMainPanel(),P.U.inst.CloseMainPanel(!1),k.q.inst_get().control.Close(),
N.g.Inst.CloseView(),V.Y.Inst().Close(),R.a.inst.closeExtendBag()
const s=new y.v
s.isShowMask=!0,s.isDefaultUITween=!0,s.isSelfTween=!1,s.isCloseCamera=!1,s.layerType=T.F.NpcTalkUI,s.isSetActiveClose=!0,s.viewClass=DialogueRobotPanel,
D.N.inst.OpenById(E.I.DialogueRobotPanel,null,null,s)}CloseRobotDialoguePanel(){D.N.inst.CloseById(E.I.DialogueRobotPanel)}}class H{constructor(){this.control=null,this.model=null,
this.control=new U,this.model=new C}static Inst_get(){return null==H.m_inst&&(H.m_inst=new H),H.m_inst}}H.m_inst=null},54518:(t,e,i)=>{i.d(e,{p:()=>s})
class s{constructor(){this.dialogList=null,this.interTalk=null,this.curPage=0}IsNewStyle(){return null!=this.interTalk}}},82268:(t,e,i)=>{i.d(e,{d:()=>F})
var s=i(38836),n=i(86133),l=i(98800),a=i(96098),o=i(90419),r=i(50089),h=i(62370),d=i(85682),u=i(31222),c=i(98130),_=i(98885),I=i(87717),m=i(21554),g=i(86770),p=i(27964),C=i(47520),S=i(92984),f=i(87923),y=i(29839),v=i(2457),D=i(1740),E=i(37648),T=i(55492),A=i(22662),L=i(20052),w=i(11162),R=i(8211),O=i(65550),G=i(17783),b=i(98580),M=i(23296),P=i(28359),B=i(72795),x=i(71893),N=i(13224),k=i(73341)
class V{}V.PANEL1=1,V.PANEL2=2,V.PANEL3=3,V.PANEL4=4,V.SINGLE_ENTER_COPY=5,V.TEAM_ENTER_COPY=6,V.RECRUIT_NPC=7,V.COPY=8,V.NPCSHOP=9
class F{constructor(){this.rescource=null,this.taskConfig=null,this.diaglogButton=null,this.m_param=null,this.m_condition=null,this.enoughTaskId=-1}DealParam(){
if(16==this.rescource.FunType)return void y.p.inst.SendEnterCopy(4)
const t=this.GetParams().rewardValues
let e=null
if(t.Count()>0){const i=t[0]
"UI"==i.type?this.LinkOpenPanel(i.value):"copyId"==i.type||"copyTeamMatch"==i.type||"copyMatch"==i.type?(y.p.inst.CommonEnterCopy(i.type,_.M.String2Int(i.value)),
k.F.Inst_get().control.ForceClose()):"questId"==i.type?_.M.String2Int(i.value):"asuramShare"==i.type?k.F.Inst_get().control.ForceClose():"UIId"==i.type?this.DealUIId(i):"nextDialog"==i.type?(k.F.Inst_get().control.DPanel_get().NextDialogue(),
null!=i.value&&""!=i.value&&(e=_.M.Split(i.value,h.o.s_UNDER_CHAR),
e.count>1&&1==_.M.String2Int(e[0])&&a.B.Inst.OpenTransportMask(a.B.TYPE_FROM_NOMOVE))):"closeDialog"==i.type?k.F.Inst_get().control.ForceClose():"handIn"==i.type?L.s.Inst_get().Open():"monsterPos"==i.type?k.F.Inst_get().control.ForceClose():"choose"==i.type?k.F.Inst_get().control.SendTaskChoose(c.GF.INT(i.value)):"power"==i.type?(N.w.Inst_Get().SendDailyTiredMsg(),
k.F.Inst_get().control.ForceClose()):"tranSport"==i.type?I.L.Inst_get().InterceptTranfer()||a.B.Inst.CM_FlyShoesTransportHandle(_.M.String2Int(i.value)):"getbountytask"==i.type?(C.s.GetInst().curRound<=C.s.GetInst().GetMaxRoundorLink(0)&&0==C.s.GetInst().GetCurLink()?(p.Q.GetInst().ReqBountyTask(),
O.y.inst.ClientStrMsg(A.r.SystemTipMessage,(0,n.T)("领取赏金任务成功"))):O.y.inst.ClientStrMsg(A.r.SystemTipMessage,(0,n.T)("你已经领取了赏金任务")),
k.F.Inst_get().control.ForceClose()):"getChariot"==i.type?(u.N.inst.OpenUIByShortCutID(d.D.GET_CAR),k.F.Inst_get().control.ForceClose()):i.type}}DealUIId(t){
k.F.Inst_get().control.ForceClose()
const e=_.M.String2Int(t.value)
u.N.inst.OpenUIByShortCutID(e,k.F.Inst_get().model.exParam)}IsSameCopy(t){const e=this.GetParams().rewardValues
if(e.Count()>0){const i=e[0]
if("copyId"==i.type)return t==_.M.String2Int(i.value)}return!1}LinkOpenPanel(t){const e=_.M.Split(t,h.o.s_Arr_UNDER_CHAR_DOT),i=_.M.String2Int(e[0]),s=(_.M.String2Int(e[1]),
k.F.Inst_get().model.selectFunModel)
i==V.PANEL1?1==_.M.String2Int(e[0])&&m.J.Inst_get().openOrClose(g.D.shopTab):i==V.PANEL2?D.Q.inst.OpenForgePanel(!1):i==V.PANEL3?m.J.Inst_get().openOrClose(g.D.warehouseTab):i==V.PANEL4||(i==V.SINGLE_ENTER_COPY?null!=s&&null!=s.taskConfig&&B.w.Inst_get().OnSingleEnterCopy(s.taskConfig):i==V.TEAM_ENTER_COPY?null!=s&&null!=s.taskConfig&&B.w.Inst_get().OnTeamEnterCopy(s.taskConfig):i==V.RECRUIT_NPC?null!=s&&null!=s.taskConfig&&B.w.Inst_get().OnRecruitNpc(s.taskConfig):i==V.NPCSHOP&&(R.N.GetInst().shopType=2,
R.N.GetInst().m_npcId=k.F.Inst_get().control.npc.npcid,f.l.CheckTrigger(v.u.COND_TYPE_NPC_SHOP_VAL,k.F.Inst_get().control.npc.npcid),w.O.Inst_get().OpenNoviceShopView()))}
GetParams(){if(null==this.m_param){const t=o.d.parseJsonObjectWithFix(this.rescource.Params,"rewardValues")
this.m_param=r.t.decode(t,P.h),this.m_param.Parse()}return this.m_param}isEnougth_get(){if(null!=this.taskConfig)return!0
const t=this.GetCondition(),e=G.L.Inst_get().model
let i=0
for(const[n,a]of(0,s.V5)(t.rewardValues))if(a.type==M.E.Level){const t=l.Y.Inst.PrimaryRoleInfo_get().Level_get()
if(_.M.String2Int(a.value)>t)return!1
if(17==this.rescource.FunType&&!x.u.Inst_get().isLunch&&!x.u.Inst_get().isSupper)return!1}else if(a.type==M.E.WorldLevel){const t=S.j.Inst_get().model.worldLevel
if(_.M.String2Int(a.value)>t)return!1}else if(a.type==M.E.TaskType){const t=_.M.Split(a.value,h.o.s_Arr_UNDER_CHAR_DOT)
if(0!=t.count){const e=k.F.Inst_get().model.selectFunModel
if(null==e||null==e.taskConfig)return!1
let i=!1
for(const[n,l]of(0,s.V5)(t))if(e.taskConfig.type_get()==_.M.String2Int(l)){i=!0
break}if(!i)return!1}}else{if(a.type==M.E.Quest){i=_.M.String2Int(a.value)
const t=e.GetTaskById(i)
return null!=t&&t.status_get()==b.B.ACCEPTED&&(this.enoughTaskId=i,!0)}if(a.type==M.E.QuestFinished)return i=_.M.String2Int(a.value),!!e.IsTaskCompleted(i)
if(a.type==M.E.FunctionOpen){const t=_.M.String2Int(a.value)
if(E.P.Inst_get().IsFunctionOpened(t)){if(t!=T.x.BOUNTYTASK)return!0
if(C.s.GetInst().CanFastFinsh())return!1
if(C.s.GetInst().curRound<=C.s.GetInst().GetMaxRoundorLink(0)&&0==C.s.GetInst().GetCurLink())return!0}return!1}}return!0}GetCondition(){if(null==this.m_condition){
const t=o.d.parseJsonObjectWithFix(this.rescource.openCondition,"rewardValues")
this.m_condition=r.t.decode(t,P.h),this.m_condition.Parse()}return this.m_condition}}},53075:(t,e,i)=>{i.d(e,{a:()=>d})
var s=i(98800),n=i(62370),l=i(5924),a=i(98885),o=i(85602),r=i(87923)
class h{constructor(t,e){this.m_content=null,this.m_type=0,this.m_content=t,this.m_type=e}}class d{constructor(t,e){this.m_label=null,this.m_txt=null,this.txtLen=0,this.nowLen=0,
this.nowSubstrIndex=0,this.m_timer=0,this.m_dataLis=null,this.showStr="",this.m_playEndHandler=null,this.isPlay=!1,this.m_finialStr=null,this.isTypeWriter=!0,
this._degf_OnAction=null,null==e&&(e=!0),this._degf_OnAction=()=>this.OnAction(),this.m_label=t,this.isTypeWriter=e}textSet(t,e){if(this.isTypeWriter){if(this.m_txt=t,
this.m_dataLis=this.GetStringLis(this.m_txt),this.txtLen=a.M.Length(this.m_finialStr),this.nowLen=0,this.nowSubstrIndex=0,this.ClearTimer(),this.isPlay=!0,this.m_playEndHandler=e,
r.l.IsEmptyStr(this.m_txt))return
this.m_timer=l.C.Inst_get().SetInterval(this._degf_OnAction,30),this.OnAction()}else{const i=this.ParseDialogueText(t)
this.m_label.textSet(i),null!=e&&e()}}OnAction(){if(this.nowSubstrIndex>=this.m_dataLis.Count())return this.ClearTimer(),void(null!=this.m_playEndHandler&&this.m_playEndHandler())
if(1==this.m_dataLis[this.nowSubstrIndex].m_type){const t=this.m_dataLis[this.nowSubstrIndex].m_content
this.showStr+=a.M.GetAt(t,this.nowLen),this.nowLen+=1
const e=a.M.Length(t)
this.nowLen>=e&&(this.nowLen=0,this.nowSubstrIndex+=1)}else this.showStr+=this.m_dataLis[this.nowSubstrIndex].m_content,this.nowLen=0,this.nowSubstrIndex+=1
this.m_label.textSet(this.showStr)}StopAndFull(){this.isTypeWriter&&(this.ClearTimer(),r.l.IsEmptyStr(this.m_finialStr)||this.m_label.textSet(this.m_finialStr))}ClearTimer(){
this.isPlay=!1,l.C.Inst_get().ClearInterval(this.m_timer),this.m_timer=0,this.showStr=""}ParseDialogueText(t){let e=t
if(-1!=a.M.IndexOf(t,d.NAME_TAG,0)){let t=s.Y.Inst.PrimaryRoleInfo_get().Name_get()
t=r.l.SetStringColor("5fb470",t)
let i=0
for(;-1!=a.M.IndexOf(e,d.NAME_TAG,0)&&(e=a.M.Replace(e,d.NAME_TAG,t),i+=1,!(i>10)););}return e}GetStringLis(t){let e=this.ParseDialogueText(t)
this.m_finialStr=e
const i=new o.Z
let s=null,l=a.M.IndexOf(e,d.COLOR_START,0)
if(l>-1){const t=new o.Z
let u=0
for(;l>-1;){const i=a.M.IndexOf(e,d.COLOR_END,0),s=a.M.SubStringWithEnd(e,l,i+3)
if(t.Add(s),e=a.M.ReplaceSlow(e,s,n.o.s_UNDER_CHAR_DOLL),l=a.M.IndexOf(e,d.COLOR_START,0),u+=1,u>10)break}const c=a.M.Split(e,n.o.s_Arr_UNDER_CHAR_DOLL),_=c.count
let I=null,m=0
for(;m<_;)I=c[m],r.l.IsEmptyStr(I)||(s=new h(I,1),i.Add(s)),m<_-1&&m<t.Count()&&(s=new h(t[m],2),i.Add(s)),m+=1}else s=new h(t,1),i.Add(s)
return i}}d.NAME_TAG="{name}",d.COLOR_START="[5fb470]",d.COLOR_END="[-]"},79062:(t,e,i)=>{
var s=i(18998),n=i(21370),l=i(72574),a=i(6847),o=i(83908),r=i(17409),h=i(46282),d=i(40053),u=i(77546),c=i(38836),_=i(86133),I=i(43662),m=i(98800),g=i(88956),p=i(74416),C=i(28475),S=i(32697),f=i(20583),y=i(50838),v=i(31546),D=i(97461),E=i(19176),T=i(50089),A=i(62370),L=i(51696),w=i(47640),R=i(41664),O=i(5924),G=i(61911),b=i(31222),M=i(5494),P=i(60130),B=i(95721),x=i(98130),N=i(98885),k=i(85602),V=i(38962),F=i(79534),U=i(70850),H=i(75696),q=i(47520),Z=i(92984),j=i(75321),X=i(26753),Y=i(33314),W=i(87923),$=i(27122),J=i(86605),z=i(1046),Q=i(29839),K=i(70478),tt=i(44210),et=i(2457),it=i(48933),st=i(57035),nt=i(37648),lt=i(55492),at=i(20758),ot=i(75439),rt=i(20052),ht=i(5031),dt=i(8211),ut=i(15821),ct=i(30635),_t=i(79878),It=i(17783),mt=i(98580),gt=i(85890),pt=i(15398),Ct=i(73341)
class St{}St.FUNC_BTN_NORMAL=0,St.FUNC_BTN_HIGH_LIGHT=1,St.FUNC_BTN_HIGH_LIGHT_SWEEP=2
var ft=i(82268),yt=i(4586)
class vt extends((0,o.yk)()){constructor(...t){super(...t),this.m_model=void 0,this.hasOrder=!1,this._degf_OnBtnClick=void 0}_initBinder(){super._initBinder(),
this._degf_OnBtnClick=(t,e)=>this.OnBtnClick(t,e)}InitView(){super.InitView()}Destroy(){}SetData(t){this.m_model=t,this.AddListeners(),this.UpdateView()}Clear(){
this.RemoveListeners(),this.m_model=null}AddListeners(){_t.Y.RegLuaClick(this.funBtn,this.CreateDelegate(this.OnBtnClick)),this.RegGuide()}RemoveListeners(){
_t.Y.DelLuaClick(this.funBtn,this.OnBtnClick),this.UnRegGuide()}RegGuide(){
null!=this.m_model.rescource&&(6==this.m_model.rescource.Id||29==this.m_model.rescource.Id&&null!=this.m_model.taskConfig&&(this.m_model.taskConfig.status_get(),mt.B.ACCEPTED))}
UnRegGuide(){}OnBtnClick(t,e){if(null!=this.m_model.diaglogButton)this.OnDiaglogButtonHandler()
else if(null!=this.m_model.taskConfig){const t=Ct.F.Inst_get()
t.model.selectFunModel=this.m_model,t.control.DPanel_get().GoToTaskDialogue()}else null!=this.m_model.rescource&&this.m_model.DealParam()}OnDiaglogButtonHandler(){
this.m_model.diaglogButton.IsLastPage()?Ct.F.Inst_get().control.ForceClose():(Ct.F.Inst_get().control.DPanel_get().SetPageIndex(this.m_model.diaglogButton.nextPage),
Ct.F.Inst_get().control.DPanel_get().exSetDialogue())}UpdateView(){let t=null,e=null
if(null!=this.m_model.diaglogButton)e=this.m_model.diaglogButton.name,t=this.m_model.diaglogButton.IconRes
else if(null!=this.m_model.taskConfig)e=this.m_model.taskConfig.type_get()==gt.U.BountyTask?this.m_model.taskConfig.resource_get().name:yt.G.CutColorStr(this.m_model.taskConfig.taskName_get()),
t=gt.U.GetDialogFunIcon(this.m_model.taskConfig.type_get())
else{if(29==this.m_model.rescource.Id||172==this.m_model.rescource.Id){const t=Ct.F.Inst_get().control.npc.npcid
e=dt.N.GetInst().GetNPCShopName(t)}else if(11==this.m_model.rescource.FunType){let t=this.m_model.rescource.FunName
t=N.M.Replace(t,"{0}",q.s.GetInst().GetCurRound().toString()),t=N.M.Replace(t,"{1}",q.s.GetInst().GetMaxRoundorLink(0).toString()),e=t}else e=this.m_model.rescource.FunName
t=this.m_model.rescource.IconRes}null==e?(this.nameHighlight.textSet(""),this.nameNormal.textSet("")):(this.nameHighlight.textSet(e),this.nameNormal.textSet(e)),
null==t?this.icon.spriteNameSet(""):this.icon.spriteNameSet(t)}SetHighLight(t){
t==St.FUNC_BTN_NORMAL?(null!=this.m_model.taskConfig&&this.m_model.taskConfig.type_get()==gt.U.BountyTask?this.bg.spriteNameSet("rycommon_bt_0072"):this.bg.spriteNameSet("rycommon_bt_0037"),
this.nameHighlight.node.SetActive(!1),
this.nameNormal.node.SetActive(!0),this.StopEffect()):(null!=this.m_model.taskConfig&&this.m_model.taskConfig.type_get()==gt.U.BountyTask?this.bg.spriteNameSet("rycommon_bt_0072"):this.bg.spriteNameSet("rycommon_bt_0036"),
this.nameHighlight.node.SetActive(!0),this.nameNormal.node.SetActive(!1),t==St.FUNC_BTN_HIGH_LIGHT_SWEEP?this.PlayEffect():this.StopEffect())}PlayEffect(){
this.sweepEffect.node.SetActive(!0)}StopEffect(){this.sweepEffect.node.SetActive(!1)}}var Dt,Et,Tt=i(53075);(0,
a.s_)(M.I.eDialoguePanel,h.Z.ui_dialogue_mianpanel).waitPrefab(h.Z.ui_market_novice_item).waitPrefab(d.Z.BaseItem_ry_basePrefabs).layerSet(n.T.npcTalk).hideMainUI().register()((Et=class t extends((0,
o.pA)(G.f)()){constructor(...t){super(...t),this.m_playLabel=null,this.m_dialogueModel=null,this.isTaskDialogFun=!1,this.dialogInfo=null,this.m_wid=0,this.m_npc=null,
this.m_pInfo=null,this.m_npcCharacter=null,this.m_role=null,this.m_distanceTime=-1,this.m_useDistance=4,this.m_funModel=null,this.m_tConfig=null,this.m_diaIndex=0,
this.m_handInTxt=null,this.m_isTaskDia=!1,this.soundids=null,this.cursounds=null,this.presound=null,this.preSoundId=null,this.m_autoTalkTimerId=0,this.m_isNextTask=!1,
this.m_enterCopyTimerId=0,this.m_enterCopyCD=0,this.m_enterCopyId=0,this.m_enterCopyName=null,this.m_isShowFuncBtn=!0,this.isopenotherview=!1,this._degf_AutoTalk=null,
this._degf_BloodTwonFinalHandler=null,this._degf_CallOpenHandIn=null,this._degf_CloseOtherPanel=null,this._degf_JudgeDistance=null,this._degf_OnAutoTalkEnd=null,
this._degf_OnCreateBtn=null,this._degf_OnCreateRewardItem=null,this._degf_OnGoClick=null,this._degf_OnGoClick_EnterCopyBtn=null,this._degf_OnGoClick_HandInBtn=null,
this._degf_PlayEndHandler=null,this._degf_RefresFunItem=null,this._degf_SortByOrder=null,this._degf_SortByTaskType=null,this._degf_UpdateTask=null,
this._degf_AutoEnterCopyHandler=null,this._degf_OnBLTweenFinished=null,this.oldBsgVolume=null,this.oldEsgVolume=null,this.closeOtherTimerId=null,this.bloodTownFinalId=null,
this.playerDisplayUIAvatarModel=void 0}_initBinder(){super._initBinder(),this.m_handInTxt=(0,_.T)("上交道具"),this._degf_AutoTalk=()=>this.AutoTalk(),
this._degf_BloodTwonFinalHandler=()=>this.BloodTwonFinalHandler(),this._degf_CallOpenHandIn=()=>this.CallOpenHandIn(),this._degf_CloseOtherPanel=()=>this.CloseOtherPanel(),
this._degf_JudgeDistance=()=>this.JudgeDistance(),this._degf_OnAutoTalkEnd=()=>this.OnAutoTalkEnd(),this._degf_OnCreateBtn=t=>this.OnCreateBtn(t),
this._degf_OnCreateRewardItem=t=>this.OnCreateRewardItem(t),this._degf_OnGoClick=(t,e)=>this.OnGoClick(""),this._degf_OnGoClick_EnterCopyBtn=(t,e)=>this.OnGoClick("EnterCopyBtn"),
this._degf_OnGoClick_HandInBtn=(t,e)=>this.OnGoClick("HandInBtn"),this._degf_PlayEndHandler=()=>this.PlayEndHandler(),this._degf_RefresFunItem=()=>this.RefresFunItem(),
this._degf_SortByOrder=(t,e)=>this.SortByOrder(t,e),this._degf_SortByTaskType=(t,e)=>this.SortByTaskType(t,e),this._degf_UpdateTask=t=>this.UpdateTask(t),
this._degf_AutoEnterCopyHandler=(t,e)=>this.AutoEnterCopyHandler(t,e),this._degf_OnBLTweenFinished=()=>this.OnBLTweenFinished()}InitView(){this.isExclusionPanel=!1,
this.isKillAllExcluded=!0,this.DestoryPanelLevel=G.f.DestoryLevel0,this.playerDisplayUIAvatarModel=new y.o,this.playerDisplayUIAvatarModel.SetTarget(this.playerUIAvatar,!1),
this.rewardGrid.SetInitInfo("ui_baseitem",this._degf_OnCreateRewardItem),this.m_playLabel=new Tt.a(this.dialoglabel,!1),
this.selectBtnGrid.SetInitInfo("ui_dialogue_funbtn",this.OnCreateBtn),this.selectBtnGrid.OnReposition_set(this._degf_RefresFunItem),this.m_dialogueModel=Ct.F.Inst_get().model
const t=ot.D.getInstance().getContent("QUEST:DISTANCE_CHECK")
if(null!=t){const e=t.getContent()
this.m_useDistance=N.M.String2Int(e.stringVal)+1}this.m_wid=T.t.GetAdaptWidth(),T.t.IsMoreWide()?(this.m_wid=T.t.GetAdaptWidth(),
this.leftBg.widthSet(x.GF.INT(this.m_wid))):this.m_wid<1280&&(this.m_wid=1280),this.oldBsgVolume=0,this.oldEsgVolume=0}OnBLTweenFinished(){}OnCreateBtn(t){return new vt(t[0])}
OnCreateRewardItem(t){return new H.j(t[0])}OnAddToScene(){this.belialWidget.SetActive(!1),this.bloodtownWidget.SetActive(!1),this.noviceShopView.node.SetActive(!1),
this.m_npc=Ct.F.Inst_get().control.npc,P.O.SetAnchorPos(this.leftAnchor,!0,!0,-2,!1),P.O.SetAnchorPos(this.rightAnchor,!1,!0,-2,!1),
P.O.SetAnchorPos(this.CloseBtn.node.transform,!0,!0,2,!0,null,120,-60),this.leftBg.node.transform.SetLocalPositionXYZ(-P.O.UIScreenNotchWidthLeft,0,0),
this.handInBtn.node.SetActive(!1),this.enterCopyBtn.node.SetActive(!1),this.effectObj.SetActive(!1),this.recommendedTeam.node.SetActive(!1),this.rewardObj.SetActive(!1),
this.collisionObj.SetActive(!1),this.AddOrDelEvent(!0),this.PlayTween(),this.m_pInfo=m.Y.Inst.PrimaryRoleInfo_get(),
this.m_distanceTime=O.C.Inst_get().SetInterval(this._degf_JudgeDistance,200),this.m_isTaskDia=!1
const t=this.m_dialogueModel.GetNpcTaskAndFun(this.m_npc),e=Ct.F.Inst_get().control.task,i=this.m_dialogueModel.GetFunModelByTask(t,e)
null!=i&&1==i.taskConfig.hideNPCDialog_get()?(this.m_dialogueModel.selectFunModel=i,this.GoToTaskDialogue()):this.NpcSet(t),
this.closeOtherTimerId=O.C.Inst_get().SetInterval(this._degf_CloseOtherPanel,50,1),this.SetIsShowFuncBtn(),Ct.F.Inst_get().control.isShowNovicePanel&&this.OpenNoviceShopView()}
SetIsShowFuncBtn(){Ct.F.Inst_get().control.isShowNovicePanel?(this.m_isShowFuncBtn=!1,this.selectBtnGrid.node.SetActive(!1)):(this.m_isShowFuncBtn=!0,
this.selectBtnGrid.node.SetActive(!0))}CloseOtherPanel(){m.Y.Inst.PrimaryRole_get().JustStand(),ht.T.inst_get().control.CloseBuffDetailPanel(),ct.Y.Inst().CloseHeadPanel(),
ct.Y.Inst().CloseTargetHead(),ht.T.inst_get().control.CloseBuffListPanel(),X.d.Inst_get().controller.CloseMainPanel()}NpcSet(t){let e=!1,i=""
for(const[i,s]of(0,c.V5)(t)){const t=s
if(null!=t.taskConfig&&t.taskConfig.IsMainCopyTask()){this.EnterCopyEndFunc(t.taskConfig),this.selectBtnGrid.node.SetActive(!1),this.collisionObj.SetActive(!1),e=!0
break}}q.s.GetInst().copyTalkNpcId==this.m_npc.npcid&&0!=q.s.GetInst().copystate&&(this.selectBtnGrid.node.SetActive(!1),this.collisionObj.SetActive(!1),e=!0,
1==q.s.GetInst().copystate?i=this.m_npc.bountyTaskFail:2==q.s.GetInst().copystate&&(i=this.m_npc.bountyTaskSuccess),q.s.GetInst().copyTalkNpcId=0,q.s.GetInst().copystate=0),
0==e&&this.m_isShowFuncBtn&&(this.selectBtnGrid.data_set(t),t.Count()>0&&this.collisionObj.SetActive(!0)),this.SetModelView(1),this.nameLeft.textSet(this.m_npc.name),
W.l.IsEmptyStr(i)?this.m_playLabel.textSet(this.m_npc.dialog,this._degf_PlayEndHandler):this.m_playLabel.textSet(i,this._degf_PlayEndHandler),
null!=this.presound&&this.preSoundId!=this.m_npc.dialogSoundId&&R.j.Inst.StopByKeyList(this.presound),
R.j.Inst.ExistByKeyList(this.presound)||(this.presound=R.j.Inst.PlayByCfgSoundId(this.m_npc.dialogSoundId,null,null,null,!0),
null!=this.presound&&this.presound.Count()>0&&this.LowerEffectSound(),this.preSoundId=this.m_npc.dialogSoundId)
const s=U.g.Inst_get().GetItemNum(10710)
this.m_npc.npcid==tt.w.GetInst().npcId&&s>0&&tt.w.GetInst().stage==tt.w.STAGE_NUM&&(this.handInBtn.node.SetActive(!0),this.handInTxt.textSet((0,_.T)("上交道具"))),
1000110==this.m_npc.npcid&&nt.P.Inst_get().IsFunctionOpened(3)&&null!=t&&t.Count()>0&&u.s.Info(`血色城堡${t.Count()}`),this.OpenOtherView(t)}OpenOtherView(t){
const e=st.d.Inst_get().GetFunIdByNpcId(this.m_npc.npcid)
if(0!=e){if(null!=t&&t.Count()>0&&!Ct.F.Inst_get().control.showUI)return
if(!nt.P.Inst_get().IsFunctionOpened(e))return void W.l.SetFunctionTip(e)
this.isopenotherview=!0,this.CloseBtn.node.SetActive(!1),this.belialWidget.SetActive(!1),this.bloodtownWidget.SetActive(!1),this.collisionObj.SetActive(!0),
this.effectObj.SetActive(!1),e==lt.x.DEMON_SQUARE?(this.belialWidget.SetActive(!0),
J.z.Inst_get().OpenView(this.belialWidget)):e==lt.x.BLOOD_CASTLE&&(this.bloodtownWidget.SetActive(!0),z.N.Inst_get().OpenView(this.bloodtownWidget))}else this.isopenotherview=!1,
this.CloseBtn.node.SetActive(!0)}OpenNoviceShopView(){this.noviceShopView.node.SetActive(!0),this.noviceShopView.SetData(),Ct.F.Inst_get().control.isShowNovicePanel=!1,
this.CloseBtn.node.SetActive(!1)}PlayTween(){}SetModelView(e){let i=null
I.M.Instance_get().ActiveStage(t.STAGE_ID),I.M.Instance_get().ActiveStage(t.STAGE_ID2),this.npctexture.node.SetActive(!1),this.playertexture.node.SetActive(!1),
this.npcUIAvatar.node.SetActive(!1),this.playerUIAvatar.node.SetActive(!1)
const s=this.clickTran.GetLocalPosition(),n=this.dialoglabel.node.transform.GetLocalPosition()
if(this.HideCharacter(),1==e){this.npctexture.node.SetActive(!0),null==this.m_npcCharacter?(this.m_npcCharacter=new p.B,this.m_npcCharacter.isForDialogue=!0,
this.m_npcCharacter.dialogAngle=this.m_npc.dialogAngle,this.m_npcCharacter.InitByCfg(this.m_npc,!0),
I.M.Instance_get().SetDisplayObject(t.STAGE_ID,this.m_npcCharacter.MainRole_get().handle,0),i=this.m_npcCharacter,this.npctexture.node.SetActive(!0),
this.npctexture.SetMainTextureByPhoto(t.STAGE_ID)):(this.m_npcCharacter.SetShow(!0),i=this.m_npcCharacter),s.x=1144,n.x=39,this.nameBgLeft.SetActive(!0),
this.nameBgRight.SetActive(!1),this.npcUIAvatar.node.SetActive(!0)
let e=at.F.Inst.GenGetCfgById(this.m_npc.model)
e?this.npcUIAvatar.mid=e.ResName:console.error("DisplayConfigCsv 配置缺失, modelId:"+this.m_npc.model),this.npcUIAvatar.node.setScale(1.5,1.5)}else{
if(this.playertexture.node.SetActive(!0),null==this.m_role){this.m_role=$.Q.Inst().GetObjectByName("Role",C.u),this.m_role.isForDialogue=!0,
this.m_role.dialogueAngle=this.m_dialogueModel.roleAngle,this.m_role.isphotoRole=!0
const e=new v.O,s=this.GetPlayerInfo(),n=Z.j.Inst_get().model.IsHaveShapeShiftBuff(m.Y.Inst.PrimaryRoleInfo_get().Id_get())
e._displayID=null!=n?N.M.String2Int(n.vo.values[0]):Y.Z.GetDisplayId(s),this.m_role.initByDisinfo(s,e,!0,null),
I.M.Instance_get().SetDisplayObject(t.STAGE_ID2,this.m_role.MainRole_get().handle,0),i=this.m_role,this.playertexture.node.SetActive(!0),
this.playertexture.SetMainTextureByPhoto(t.STAGE_ID2)}else this.m_role.SetShow(!0),i=this.m_role
s.x=115,n.x=185,this.nameBgLeft.SetActive(!1),this.nameBgRight.SetActive(!0),this.playerUIAvatar.node.SetActive(!0),
this.playerDisplayUIAvatarModel=f.x.inst.SetUIAvatarData(this.m_role.roleinfo,S.v.role,this.playerDisplayUIAvatarModel),this.playerDisplayUIAvatarModel.SetScale(1.5,1.5),
this.playerDisplayUIAvatarModel.SetDir(4),this.playerDisplayUIAvatarModel.SetAct(l.Bv.FightIdle)}this.dialoglabel.node.transform.SetLocalPosition(n),this.clickTran.node.position=s,
1==e?0!=this.m_npc.dialogScale&&i.SetSize(.6*this.m_npc.dialogScale):0!=this.m_dialogueModel.roleScale&&i.SetSize(.6*this.m_dialogueModel.roleScale)
const a=F.P.zero_get()
if(1==e){if(!W.l.IsEmptyStr(this.m_npc.dialogMove)){const t=N.M.Split(this.m_npc.dialogMove,A.o.s_Arr_UNDER_CHAR_DOT)
a.x+=N.M.String2Float(t[0]),a.y+=N.M.String2Float(t[1])}}else null!=Z.j.Inst_get().model.IsHaveShapeShiftBuff(m.Y.Inst.PrimaryRoleInfo_get().Id_get())?(a.x=158,
a.y=355):(a.x+=this.m_dialogueModel.roleOffset.x,a.y+=this.m_dialogueModel.roleOffset.y)
1==e?(this.m_npcCharacter.setPosXYZ(a.x,a.y,a.z),this.m_npcCharacter.SetSize(this.m_npc.dialogScale/1.33)):(this.m_role.setPosXYZ(a.x,a.y,a.z),this.m_role.SetSize(1.73)),
F.P.Recyle(a),0==this.m_npc.model&&this.npctexture.node.SetActive(!1)}InitPlayerModel(t,e,i){
return i?i=f.x.inst.SetUIAvatarData(e,S.v.monster,i):(i=f.x.inst.SetUIAvatarData(e)).SetTarget(t,!1),i.UpdateUIAvatar(),i.SetScale(1.5,1.5),i.SetDir(4),i}GetPlayerInfo(){
const t=m.Y.Inst.PrimaryRoleInfo_get(),e=new g.r
if(e.Job_set(t.Job_get()),e.Sex_set(t.Sex_get()),e.Fashions_set(t.Fashions_get()),e.SacredEquipWearing_Set(t.SacredEquipWearing_Get()),e.Id_set(B.o.New(1e4,0)),
null!=t.equipmentStorageVO.equipmentVOs){const i=t.equipmentStorageVO.equipmentVOs,s=new V.X
for(const[t,e]of(0,c.vy)(i))t!=j.C.PART_WINGS&&s.LuaDic_AddOrSetItem(t,i[t])
e.equipmentStorageVO.equipmentVOs=s}return e}DestroyModel(){this.DestroyRole(),this.DestroyNPC()}DestroyRole(){null!=this.m_role&&(this.m_role.Destroy(null),this.m_role=null)}
DestroyNPC(){null!=this.m_npcCharacter&&(this.m_npcCharacter.Destroy(),this.m_npcCharacter=null)}HideCharacter(){null!=this.m_role&&this.m_role.SetShow(!1),
null!=this.m_npcCharacter&&this.m_npcCharacter.SetShow(!1)}PlayEndHandler(){this.AgainstEndFunc(),this.BloodTwonEndFunc()}AgainstEndFunc(){}BloodTwonEndFunc(){
null!=this.m_npc&&this.m_npc.npcid==tt.w.GetInst().npcId&&E.S.getInst().InHang_get()&&(this.bloodTownFinalId=O.C.Inst_get().SetInterval(this._degf_BloodTwonFinalHandler,1e3,1))}
EnterCopyEndFunc(t){return t.IsMainCopyTask()&&(this.enterCopyBtn.node.SetActive(!0),this.selectBtnGrid.node.SetActive(!1),this.collisionObj.SetActive(!1),this.isTaskDialogFun=!0,
this.m_enterCopyId=t.tCTargetDefs_get().tCTargetDefs[0].param.copyId,this.m_enterCopyCD=t.tCTargetDefs_get().tCTargetDefs[0].param.time,
this.m_enterCopyName=t.tCTargetDefs_get().tCTargetDefs[0].param.buttonIcon,this.enterCopyTxt.textSet(`${this.m_enterCopyName}(${this.m_enterCopyCD+(0,_.T)("秒)")}`),
this.m_enterCopyTimerId=O.C.Inst_get().SetIntervalForParm(this._degf_AutoEnterCopyHandler,1e3,this.m_enterCopyCD,this.m_enterCopyId)),!1}AutoEnterCopyHandler(t,e){
null!=this.m_enterCopyCD&&(this.m_enterCopyCD<=1?(Q.p.inst.CommonEnterCopy("copyId",e),Ct.F.Inst_get().control.ForceClose()):(this.m_enterCopyCD-=1,
this.enterCopyTxt.textSet(`${this.m_enterCopyName}(${this.m_enterCopyCD+(0,_.T)("秒)")}`)))}BloodTwonFinalHandler(){K._.GetInst().ReqBackItem(),this.ClosePanel()}JudgeDistance(){
if(null==this.m_npc)return
const t=m.Y.Inst.PrimaryRole_get().GetPos(),e=it.I.calVec0
e.x=this.m_npc.x,e.y=t.y,e.z=this.m_npc.y,null!=this.m_npc&&(this.m_useDistance=this.m_npc.reactDistance),
null!=this.m_npc.bountyTalk?Math.floor(F.P.Distance(t,e))>q.s.GetInst().chat_exitdis&&b.N.inst.ClosePanel(this):Math.floor(F.P.Distance(t,e))>this.m_useDistance&&b.N.inst.ClosePanel(this)
}AddOrDelEvent(t){t?(this.handInBtn.node.on(s.NodeEventType.TOUCH_END,this._degf_OnGoClick_HandInBtn),
this.enterCopyBtn.node.on(s.NodeEventType.TOUCH_END,this._degf_OnGoClick_EnterCopyBtn),this.collider.node.on(s.NodeEventType.TOUCH_END,this._degf_OnGoClick),
D.i.Inst.AddEventHandler(ut.i.NEWBIE_JUMP_TALK,this._degf_OnGoClick),It.L.Inst_get().model.AddEventHandler(pt.M.REFRESH_MAIN_PANEL_LIST,this._degf_UpdateTask),
this.m_handlerMgr.AddClickEvent(this.CloseBtn,this.CreateDelegate(this.ClosePanel))):(this.handInBtn.node.off(s.NodeEventType.TOUCH_END,this._degf_OnGoClick_HandInBtn),
this.enterCopyBtn.node.off(s.NodeEventType.TOUCH_END,this._degf_OnGoClick_EnterCopyBtn),this.collider.node.off(s.NodeEventType.TOUCH_END,this._degf_OnGoClick),
D.i.Inst.RemoveEventHandler(ut.i.NEWBIE_JUMP_TALK,this._degf_OnGoClick),It.L.Inst_get().model.RemoveEventHandler(pt.M.REFRESH_MAIN_PANEL_LIST,this._degf_UpdateTask))}
GoToTaskDialogue(){this.m_funModel=this.m_dialogueModel.selectFunModel,this.m_tConfig=this.m_funModel.taskConfig,this.dialogInfo=this.m_tConfig.getDialogInfo(),
this.soundids=this.m_tConfig.intersectionTalkSoundList_get(),this.m_diaIndex=0,this.selectBtnGrid.node.SetActive(!1),this.collisionObj.SetActive(!1),this.m_isTaskDia=!0,
this.exSetDialogue()}OnGoClick(t){if("EnterCopyBtn"==t)return O.C.Inst_get().ClearInterval(this.m_autoTalkTimerId),O.C.Inst_get().ClearInterval(this.m_enterCopyTimerId),
Q.p.inst.CommonEnterCopy("copyId",this.m_enterCopyId),void Ct.F.Inst_get().control.ForceClose()
this.isTaskDialogFun||(O.C.Inst_get().ClearInterval(this.m_autoTalkTimerId),O.C.Inst_get().ClearInterval(this.m_enterCopyTimerId),
"HandInBtn"==t?this.m_npc.npcid==tt.w.GetInst().npcId?(K._.GetInst().ReqBackItem(),this.ClosePanel()):this.m_isNextTask?(this.m_isNextTask=!1,
this.GoToTaskDialogue()):rt.s.Inst_get().Open():this.GoOnClick())}GoOnClick(){this.GoOnDialogue()}GoOnDialogue(){if(null==this.m_playLabel)return
if(this.m_playLabel.isPlay)return this.m_playLabel.StopAndFull(),void this.exShowTaskDialogFunc()
if(null==this.dialogInfo)return void(this.selectBtnGrid.itemList&&0!=this.selectBtnGrid.itemList.Count()||this.ClosePanel())
if(!this.dialogInfo.IsNewStyle())return this.m_diaIndex+=1,void this.SetDialogue()
const t=this.dialogInfo.interTalk.getPage(this.m_diaIndex)
if(t.dialogContent.IsLastPage_get()){
1==t.dialogContent.commit?this.LastTalkDeal():t.dialogContent.trace?_t.Y.GoonTaskStep(this.m_dialogueModel.selectFunModel.taskConfig):0!=t.dialogContent.openui&&b.N.inst.OpenUIByShortCutID(t.dialogContent.openui)
const e=this.dialogInfo.interTalk.getPage(this.m_diaIndex)
null!=e&&null!=e.btnList&&e.btnList.dialogBtns.Count()>0||this.ClosePanel()}else this.SetPageIndex(t.dialogContent.nextPage),this.exSetDialogue()}SetDefaultDialogue(){}
SetPageIndex(t){this.m_diaIndex=t-1}NextDialogue(){this.isTaskDialogFun=!1,this.selectBtnGrid.node.SetActive(!1),this.selectBtnGrid.data_set(null),this.collisionObj.SetActive(!1),
this.GoOnDialogue()}checkIndex(){return this.m_diaIndex<this.dialogInfo.dialogList.Count()}exSetDialogue(){this.dialogInfo.IsNewStyle()?this.SetDialogue2():this.SetDialogue()}
SetDialogue2(){if(this.dialogInfo.interTalk.OuterLastPage(this.m_diaIndex))return this.LastTalkDeal(),void this.ClosePanel()
const t=this.dialogInfo.interTalk.getPage(this.m_diaIndex)
t.dialogContent.isNpc?(this.nameLeft.textSet(this.m_npc.name),this.SetModelView(1)):(this.nameRight.textSet(this.m_pInfo.Name_get()),this.SetModelView(2)),
this.selectBtnGrid.node.SetActive(!1),this.collisionObj.SetActive(!1),this.m_playLabel.textSet(t.dialogContent.text,this._degf_OnAutoTalkEnd),
null!=t.btnList&&t.btnList.dialogBtns.Count()>0?this.effectObj.SetActive(!1):this.effectObj.SetActive(!0)}SetDialogue(){if(this.effectObj.SetActive(!0),this.checkIndex()){
const t=this.dialogInfo.dialogList[this.m_diaIndex]
if("NPC"==t.type?(this.nameLeft.textSet(this.m_npc.name),this.SetModelView(1)):(this.nameRight.textSet(this.m_pInfo.Name_get()),this.SetModelView(2)),
null!=this.soundids&&this.m_diaIndex<this.soundids.count&&(R.j.Inst.StopByKeyList(this.cursounds),
this.cursounds=R.j.Inst.PlayByCfgSoundId(this.soundids[this.m_diaIndex],null,null,!1,!0)),this.m_playLabel.textSet(t.value,this._degf_OnAutoTalkEnd),
W.l.IsEmptyStr(t.handInTxt)||(this.m_handInTxt=t.handInTxt),
this.m_diaIndex==this.dialogInfo.dialogList.Count()-1)if(this.m_tConfig.status_get()==mt.B.ACCEPTED)this.m_tConfig.IsMainCopyTask()?(this.selectBtnGrid.node.SetActive(!1),
this.collisionObj.SetActive(!1),this.EnterCopyEndFunc(this.m_tConfig)):this.m_tConfig.isEnterCopy()&&this.OpenOtherView(null)
else if(this.m_tConfig.status_get()==mt.B.FINISHED&&null!=this.m_tConfig.showRewardResult_get()){const t=this.m_tConfig.showRewardResult_get().GetJobLimitItemList()
null!=t&&t.Count()>0&&(this.rewardObj.SetActive(!0),this.rewardGrid.data_set(t))}}else this.LastTalkDeal(),this.ClosePanel()}ChooseTalkDeal(t){
0!=t&&Ct.F.Inst_get().control.SendTaskChoose(t)}LastTalkDeal(){
if(this.m_tConfig.type_get()!=gt.U.CONTRACT||null==this.m_tConfig.GetTargetOpenUI()||0==this.m_tConfig.GetTargetOpenUI()){
if(this.m_tConfig.status_get()!=mt.B.CAN_ACCEPT&&this.m_tConfig.isHandInTask_get()||_t.Y.SendToServer(this.m_tConfig,null),
null!=this.m_dialogueModel.selectFunModel.diaglogButton&&null!=this.m_dialogueModel.selectFunModel.diaglogButton.choose)this.ChooseTalkDeal(this.m_dialogueModel.selectFunModel.diaglogButton.choose)
else if(null!=this.dialogInfo&&null!=this.dialogInfo.interTalk){const t=this.dialogInfo.interTalk.getPage(this.m_diaIndex)
null!=t&&t.dialogContent&&null!=t.dialogContent.choose&&this.ChooseTalkDeal(t.dialogContent.choose)}}else b.N.inst.OpenUIByShortCutID(this.m_tConfig.GetTargetOpenUI())}
OnAutoTalkEnd(){
this.CanAutoTalk()?this.m_autoTalkTimerId=O.C.Inst_get().SetInterval(this._degf_AutoTalk,1200,1):(!this.m_tConfig.isAutoShowHandInTypeTask_get()||this.m_tConfig.isHandInTask_get()||this.m_tConfig.IsCopy_get())&&this.exShowTaskDialogFunc()
}AutoTalk(){this.GoOnDialogue()}ClosePanel(){(0,r.sR)(M.I.eDialoguePanel),rt.s.Inst_get().Close()}UpdateTask(t){if(null!=this.m_tConfig){
const t=It.L.Inst_get().model.GetTraceViewQuestes()
for(const[e,i]of(0,c.V5)(t)){i.IsNeedTask(this.m_tConfig.id_get())&&(i.linkNpcId_get()==this.m_npc.npcid?(this.m_funModel=new ft.d,this.m_funModel.taskConfig=i,
this.m_dialogueModel.selectFunModel=this.m_funModel,this.m_handInTxt=(0,_.T)("继续任务"),this.m_isNextTask=!0,this.handInTxt.textSet(this.m_handInTxt)):(_t.Y.GetLinkInfo(i,null),
_t.Y.DealTaskReceive(i)))
break}}}ResetNPCDir(){const t=m.Y.Inst.getNpcById(this.m_npc.npcid)
null!=t&&t.ResetRotation()}Clear(){this.ResetNPCDir(),this.AddOrDelEvent(!1),O.C.Inst_get().ClearInterval(this.m_autoTalkTimerId),
O.C.Inst_get().ClearInterval(this.m_enterCopyTimerId),O.C.Inst_get().ClearInterval(this.closeOtherTimerId),
null!=this.bloodTownFinalId&&(O.C.Inst_get().ClearInterval(this.bloodTownFinalId),this.bloodTownFinalId=null),this.m_playLabel.StopAndFull(),this.m_isNextTask=!1,
null!=this.dialogInfo&&(this.dialogInfo=null),O.C.Inst_get().ClearInterval(this.m_distanceTime),Ct.F.Inst_get().model.selectFunModel=null
m.Y.Inst.PrimaryRoleInfo_get()
this.DestroyModel(),this.isTaskDialogFun=!1,this.m_tConfig=null,this.enterCopyBtn.node.SetActive(!1),this.m_enterCopyName=null,this.m_enterCopyCD=0,this.m_enterCopyId=0,
J.z.Inst_get().ClearView(),z.N.Inst_get().ClearView(),this.noviceShopView.Clear(),super.Clear()}DoHide(){super.DoHide(),O.C.Inst_get().ClearInterval(this.m_distanceTime)}Destroy(){
this.m_dialogueModel=null,this.m_playLabel=null,this.m_pInfo=null,this.m_npc=null,this.m_funModel=null,z.N.Inst_get().CloseView(),this.noviceShopView.Destroy(),
D.i.Inst.RaiseEvent(ut.i.NEWBIE_JUMP_TALK_BACK)}exShowTaskDialogFunc(){
null!=this.dialogInfo&&this.m_isShowFuncBtn&&(this.dialogInfo.IsNewStyle()?this.ShowTaskDialogFunc2():this.ShowTaskDialogFunc())}ShowTaskDialogFunc2(){
if(null==this.dialogInfo.interTalk)return
if(this.dialogInfo.interTalk.OuterLastPage(this.m_diaIndex))return
const t=this.dialogInfo.interTalk.getPage(this.m_diaIndex)
null!=t.btnList&&t.btnList.dialogBtns.Count()>0&&(this.selectBtnGrid.node.SetActive(!0),this.selectBtnGrid.data_set(this.m_dialogueModel.getTaskBtns(t.btnList.dialogBtns)),
this.collisionObj.SetActive(!0))}getBtnDatas(){return new k.Z}ShowTaskDialogFunc(){if(null==this.dialogInfo.dialogList||0==this.dialogInfo.dialogList.Count())return
const t=this.m_dialogueModel.GetTaskDialogFunList(this.dialogInfo.dialogList[this.m_diaIndex])
if(null!=t&&0!=t.Count())if(this.m_tConfig.isHandInTask_get()?(this.isTaskDialogFun=!1,
this.m_tConfig.isAutoShowHandInTypeTask_get()&&O.C.Inst_get().CallLater(this._degf_CallOpenHandIn)):this.m_tConfig.isNpcShopBuyTask_get()&&(this.isTaskDialogFun=!1,
dt.N.GetInst().shopType=2,dt.N.GetInst().m_npcId=Ct.F.Inst_get().control.npc.npcid,W.l.CheckTrigger(et.u.COND_TYPE_NPC_SHOP_VAL,Ct.F.Inst_get().control.npc.npcid),
Ct.F.Inst_get().control.ForceClose()),this.m_tConfig.IsMainCopyTask())this.selectBtnGrid.node.SetActive(!1),this.collisionObj.SetActive(!1)
else{let e=null
this.selectBtnGrid.node.active&&(e=this.selectBtnGrid.data_get()),null==e?e=t:e.AddRange(t),this.selectBtnGrid.node.SetActive(!0),this.selectBtnGrid.data_set(e),
this.collisionObj.SetActive(!0)}}CallOpenHandIn(){rt.s.Inst_get().Open()}RefresFunItem(){const t=this.selectBtnGrid.itemList
if(null!=t&&0!=t.Count())for(const[e,i]of(0,c.V5)(t))i.hasOrder||(i.hasOrder=!0)}DoHightLight(t){const e=new k.Z,i=new k.Z,s=new k.Z
for(const[n,l]of(0,c.V5)(t))l.SetHighLight(St.FUNC_BTN_NORMAL),null!=l.m_model.taskConfig?e.Add(l):null!=l.m_model.rescource?i.Add(l):null!=l.m_model.diaglogButton&&s.Add(l)
if(0!=e.Count())for(const[t,i]of(0,c.V5)(e)){i.m_model.taskConfig
;(i.m_model.taskConfig.status_get()==mt.B.CAN_ACCEPT||i.m_model.taskConfig.status_get()==mt.B.FINISHED||i.m_model.taskConfig.IsRealTalk_get())&&i.SetHighLight(St.FUNC_BTN_HIGH_LIGHT)
}if(0!=s.Count()){let t=0
for(;t<s.Count();){const e=s[t],i=e.m_model.diaglogButton.highlight
0!=i&&e.SetHighLight(i),t+=1}}if(0!=i.Count()){i.Sort(this._degf_SortByOrder)
let t=0
for(;t<i.Count();){const e=i[t],s=e.m_model.rescource.highlight
0!=s&&e.SetHighLight(s),t+=1}}}SortByTaskType(t,e){const i=t.m_model.taskConfig.type_get(),s=e.m_model.taskConfig.type_get()
return i==gt.U.MAIN&&s!=gt.U.MAIN?-1:i!=gt.U.MAIN&&s==gt.U.MAIN?1:i==gt.U.CHANGE_JOB&&s!=gt.U.CHANGE_JOB?-1:i!=gt.U.CHANGE_JOB&&s==gt.U.CHANGE_JOB?1:i==gt.U.BRANCH&&s!=gt.U.BRANCH?-1:i!=gt.U.BRANCH&&s==gt.U.BRANCH?1:i==gt.U.MANUAL&&s!=gt.U.MANUAL?-1:i!=gt.U.MANUAL&&s==gt.U.MANUAL?1:0
}LowerEffectSound(){let t=ot.D.getInstance().GetStringValue("SOUND:NPCTALK_SETTING")
t=N.M.String2Int(t)
const e=w.y.Inst_get().SoundGetGroupVolume(L.G.BACKGROUND_SOUND_GROUP),i=e*(t/100)
w.y.Inst_get().SoundSetGroupVolume(L.G.BACKGROUND_SOUND_GROUP,i)
const s=w.y.Inst_get().SoundGetGroupVolume(L.G.EFFECT2D_SOUND_GROUP),n=s*(t/100)
w.y.Inst_get().SoundSetGroupVolume(L.G.EFFECT2D_SOUND_GROUP,n),this.oldBsgVolume=e,this.oldEsgVolume=s}ResetVolume(){
this.oldBsgVolume>0&&(w.y.Inst_get().SoundSetGroupVolume(L.G.BACKGROUND_SOUND_GROUP,this.oldBsgVolume),this.oldBsgVolume=0),
this.oldEsgVolume>0&&(w.y.Inst_get().SoundSetGroupVolume(L.G.EFFECT2D_SOUND_GROUP,this.oldEsgVolume),this.oldEsgVolume=0)}SortByOrder(t,e){
const i=t.m_model.rescource.order,s=e.m_model.rescource.order
return i<s?-1:i>s?1:0}CanAutoTalk(){return null!=this.m_tConfig&&this.m_tConfig.type_get()==gt.U.BountyTask}},Et.STAGE_ID=24,Et.STAGE_ID2=123,Dt=Et))},95989:(t,e,i)=>{i.d(e,{
P:()=>N})
var s,n,l,a,o,r=i(42292),h=i(71409),d=i(17409),u=i(32076),c=i(38836),_=i(98800),I=i(97461),m=i(13687),g=i(38935),p=i(5924),C=i(66788),S=i(56937),f=i(18202),y=i(31222),v=i(5494),D=i(98130),E=i(98885),T=i(92679),A=i(55661),L=i(75439),w=i(86312),R=i(12660),O=i(60647),G=i(13487),b=i(21334),M=i(29479),P=i(95760),B=i(92415)
function x(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let N=(s=(0,h.GH)(B.k.SM_DirectBuyInfo),n=(0,h.GH)(B.k.SM_DirectBuyResult),l=(0,h.GH)(B.k.SM_DirectBuyStatus),
o=class t{get buyResultView(){return(0,d.Y)(v.I.DISCOUNT_GOODS_BUY_RESULT)}constructor(){this.mainView=null,this.openResultViewId=-1,this.interval=-1,
this.degf_LoadMainViewComplete=null,this.degf_DestroyMainView=null,this.degf_LoadBuyResultViewComplete=null,this.degf_DestroyBuyResultView=null,this.degf_SM_DirectBuyInfo=null,
this.degf_SM_DirectBuyResult=null,this.stopLimit=null,this.lastUnlockTime=null,this.openMainViewId=null,this.degf_LoadMainViewComplete=t=>{},this.degf_DestroyMainView=t=>{},
this.degf_LoadBuyResultViewComplete=t=>this.LoadBuyResultViewComplete(t),this.degf_DestroyBuyResultView=t=>this.DestroyBuyResultView(),this.degf_SM_DirectBuyInfo=t=>{
this.SM_DirectBuyInfo(t)},this.degf_SM_DirectBuyResult=t=>{this.SM_DirectBuyResult(t)},this.RegisterMessage(),I.i.Inst.AddEventHandler(T.g.CHOOSE_SETTING_UPDATE,(0,
u.v)(this.UpdateHaveSeen,this)),this.StartInterval()}static Inst_get(){return null==t.inst&&(t.inst=new t),t.inst}StartInterval(){
const t=L.D.getInstance().getContent("DIRECTBUY:TIME-OUT").getContent()
this.stopLimit=1e3*E.M.String2Int(t.stringVal),this.lastUnlockTime=_.Y.Inst.LastMouseDownTime,-1!=this.interval&&p.C.Inst_get().ClearInterval(this.interval),
this.interval=p.C.Inst_get().SetInterval((0,u.v)(this.HandleTime,this),1e3,-1)}HandleTime(){
_.Y.Inst.LastMouseDownTime!=this.lastUnlockTime&&(this.lastUnlockTime=_.Y.Inst.LastMouseDownTime,M.X.Inst_get().isStop&&this.RequestCM_DirectBuyStatus(!1))
M.X.Inst_get().directBuyList.Count()>0&&(M.X.Inst_get().isStop||D.GF.MTimer_get()-this.lastUnlockTime>=this.stopLimit&&this.RequestCM_DirectBuyStatus(!0))}RegisterMessage(){}
OpenMainView(t){this.openMainViewId=t
if(null==M.X.Inst_get().GetById(t))return void C.Y.LogError(`不存在直购信息${t}`)
const e=new S.v
e.isShowMask=!0,e.isDefaultUITween=!0,e.isSelfTween=!1,e.viewClass=P.k,y.N.inst.OpenById(v.I.DISCOUNT_GOODS_MAINVIEW,null,null,e)}CloseMainView(){
y.N.inst.CloseById(v.I.DISCOUNT_GOODS_MAINVIEW)}OpenBuyResultView(t){if(this.openResultViewId=t,null==this.buyResultView){const t=new S.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!0,y.N.inst.OpenById(v.I.DISCOUNT_GOODS_BUY_RESULT,this.degf_LoadBuyResultViewComplete,this.degf_DestroyBuyResultView,t,(0,
u.v)(this.LoadBuyResultViewComplete,this))}}CloseBuyResultView(){null!=this.buyResultView&&y.N.inst.ClosePanel(this.buyResultView)}LoadBuyResultViewComplete(t){
return this.buyResultView&&this.buyResultView.SetData(this.openResultViewId),this.buyResultView}DestroyBuyResultView(){f.g.DestroyView(this.buyResultView)}requestBuy(t){
const e=new w.i
e.resourceId=t,g.C.Inst.F_SendMsg(e)}SM_DirectBuyInfo(t){M.X.Inst_get().SetLoginServerData(t),this.StartCacheBuyActivity()}SM_DirectBuyResult(t){
t.isSuc&&(M.X.Inst_get().RemoveById(t.resourceId),this.CloseMainView(),this.OpenBuyResultView(t.resourceId),I.i.Inst.RaiseEvent(T.g.SWITCH_ACTIVITY_REMOVE,!1))}
RequestCM_DirectBuyStatus(t){const e=new R.b
e.isStop=t,g.C.Inst.F_SendMsg(e)}SM_DirectBuyStatusHandle(t){M.X.Inst_get().isStop=t.isStop,
0==t.isStop?this.lastUnlockTime=_.Y.Inst.LastMouseDownTime:1==t.isStop&&(M.X.Inst_get().StopDownTime(),M.X.Inst_get().ClearCacheInfo(),
I.i.Inst.RaiseEvent(T.g.SWITCH_ACTIVITY_STOP))}CheckNextDirectBuyActivity(t){const e=M.X.Inst_get().GetById(t)
null!=e&&e.GetRemainTime()>0||this.StartCacheBuyActivity()}StartCacheBuyActivity(){for(const[t,e]of(0,c.V5)(M.X.Inst_get().cacheDict)){const t=e[0]
null!=t&&(t.startTimeEndHandler=(0,u.v)(this.OnDirectCoolDownTimeEnd,this),t.StartShowTime())}}OnDirectCoolDownTimeEnd(t){M.X.Inst_get().CheckCacheData(),
I.i.Inst.RaiseEvent(T.g.SWITCH_ACTIVITY_ADD,!1)}CheckNeedOpenMainView(t){if(m.b.Inst.currentMapId_get()>0){
b.p.Inst_get().GetMapById(m.b.Inst.currentMapId_get()).senceType!=A.S.CopyMap&&null==this.mainView&&this.OpenMainView(t)}}UpdateHaveSeen(){
M.X.Inst_get().seenDic=O.p.inst.GetClientLogicSetting(G.R.DISCOUNT_SEEN_IDS)}},o.inst=null,x(a=o,"Inst_get",[r.n],Object.getOwnPropertyDescriptor(a,"Inst_get"),a),
x(a.prototype,"SM_DirectBuyInfo",[s],Object.getOwnPropertyDescriptor(a.prototype,"SM_DirectBuyInfo"),a.prototype),
x(a.prototype,"SM_DirectBuyResult",[n],Object.getOwnPropertyDescriptor(a.prototype,"SM_DirectBuyResult"),a.prototype),
x(a.prototype,"SM_DirectBuyStatusHandle",[l],Object.getOwnPropertyDescriptor(a.prototype,"SM_DirectBuyStatusHandle"),a.prototype),a)},29479:(t,e,i)=>{i.d(e,{X:()=>S})
var s=i(38836),n=i(97461),l=i(68662),a=i(16812),o=i(85602),r=i(38962),h=i(92679),d=i(75439),u=i(14792),c=i(62734),_=i(60647),I=i(13487),m=i(32076),g=i(5924),p=i(52389)
class C{constructor(t){this.endTime=null,this.id=null,this.isInShowTime=!1,this.startTime=null,this.timerId=-1,this.showTimeEndHandler=null,this.hasShow=!1,this.showtimerId=-1,
this.timeEndHandler=null,this.startTimeEndHandler=null,this.id=t}cfg_get(){return p.r.GetInst().GetCfg(this.id)}SetEndTime(t){this.endTime=t}SetStartTime(t){this.startTime=t}
GetRemainTime(){return this.endTime.ToNum()-1e3*l.D.serverTime_get()}CheckShow(){if(this.isInShowTime||S.Inst_get().HasActive(this.cfg_get().type))return!1
if(null!=this.startTime){if(this.startTime.ToNum()-1e3*l.D.serverTime_get()>0)return!1}return!0}StartShowTime(){if(!this.isInShowTime&&null!=this.startTime){this.isInShowTime=!0
const t=this.startTime.ToNum()-1e3*l.D.serverTime_get()
t<=0?this.OnStartTimeEnd():this.timerId=g.C.Inst_get().SetInterval((0,m.v)(this.OnStartTimeEnd,this),t)}}StartEndTime(){if(null!=this.endTime){
const t=this.endTime.ToNum()-1e3*l.D.serverTime_get()
t<=0?this.ShowTimeEnd():this.showtimerId=g.C.Inst_get().SetInterval((0,m.v)(this.ShowTimeEnd,this),t)}}ShowTimeEnd(){this.ClearEndTime(),
null!=this.timeEndHandler&&this.timeEndHandler()}OnStartTimeEnd(){this.ClearTime(),null!=this.startTimeEndHandler&&this.startTimeEndHandler()}ClearTime(){this.isInShowTime=!1,
g.C.Inst_get().ClearInterval(this.timerId),this.timerId=-1}ClearEndTime(){g.C.Inst_get().ClearInterval(this.showtimerId),this.showtimerId=-1}CanAddToShow(){
const t=p.r.GetInst().GetCfg(this.id).continueTime
return this.endTime.ToNum()-1e3*l.D.serverTime_get()-1e3*t<=0}Clear(){this.startTimeEndHandler=null,this.ClearTime(),this.timeEndHandler=null,this.ClearEndTime()}}
class S extends a.k{constructor(t){super(),this.directBuyList=null,this.redPointIdDict=null,this.cacheDict=null,this.hadCheckedStatus=null,this.isStop=!1,this.seenDic=null,
this.maxCount=null,this.redPointId=null,this.directBuyList=new o.Z,this.redPointIdDict=new r.X,this.cacheDict=new r.X,this.hadCheckedStatus=new r.X,this.seenDic=new o.Z,
this.maxCount=d.D.getInstance().GetIntValue("DIRECTBUY:SELLINGMAX"),this._UpdatePointTree()}static Inst_get(){return null==S.inst&&(S.inst=new S),S.inst}GetById(t){
if(null!=this.directBuyList)for(let e=0;e<=this.directBuyList.Count()-1;e++)if(this.directBuyList[e].id==t)return this.directBuyList[e]
return null}RemoveById(t){if(null!=this.directBuyList)for(let e=0;e<=this.directBuyList.Count()-1;e++)if(this.directBuyList[e].id==t){this.directBuyList[e].Clear(),
this.directBuyList.RemoveAt(e)
break}}HasActive(t){if(null!=this.directBuyList)for(let e=0;e<=this.directBuyList.Count()-1;e++){const i=this.directBuyList[e]
if(i.cfg_get().type==t&&i.GetRemainTime()>0)return!0}return!1}SetLoginServerData(t){this.ClearDirectBuyInfo()
for(let e=0;e<=t.directBuyList.Count()-1;e++){const i=t.directBuyList[e],s=new C(i.resourceId)
s.SetEndTime(i.endTime),s.SetStartTime(i.startTime),s.timeEndHandler=this.CreateDelegate(this.OnTimeEnd),this.isStop||s.StartEndTime(),this.directBuyList.Add(s)}
this.directBuyList.Sort(this.CreateDelegate(this.SortData))
for(const[e,i]of(0,s.V5)(t.cacheList)){const t=new o.Z
this.cacheDict.LuaDic_AddOrSetItem(e,t)
for(let e=0;e<=i.cacheMap.Count()-1;e++){const s=i.cacheMap[e],n=new C(s.resourceId)
n.SetEndTime(s.endTime),n.SetStartTime(s.startTime),t.Add(n)}}n.i.Inst.RaiseEvent(h.g.SWITCH_ACTIVITY_ADD,!1)}AddToShow(t){null==this.directBuyList&&(this.directBuyList=new o.Z),
this.directBuyList.Add(t),this.directBuyList.Sort(this.CreateDelegate(this.SortData))}AddToCache(t){const e=t.cfg_get()
let i=this.cacheDict.LuaDic_GetItem(e.type)
null==i&&(i=new o.Z,this.cacheDict.LuaDic_AddOrSetItem(e.type,i)),i.Contains(t)||i.Add(t)}HasDirectBuyActivity(t){for(let e=0;e<=this.directBuyList.Count()-1;e++){
if(this.directBuyList[e].id==t)return!0}for(const[e,i]of(0,s.V5)(this.cacheDict))for(let e=0;e<=i.Count()-1;e++){if(i[e].id==t)return!0}return!1}UpdateShow(t){}_UpdatePointTree(){
this.IsRed()
this.redPointId=u.t.DISCOUNT_GOODS_BUY,c.f.Inst.AddNode(this.redPointId,null,!1)}IsRed(){
if(null!=this.directBuyList)for(let t=0;t<=this.directBuyList.Count()-1;t++)if(!this.directBuyList[t].isInShowTime&&!this.HaveSeen(this.directBuyList[t].id))return!0
return!1}IsTimeRed(t){return t>0&&t<12e5}OnTimeEnd(t){let e=0,i=-1,s=-1
for(let n=0;n<=this.directBuyList.Count()-1;n++)if(this.directBuyList[n]&&t&&this.directBuyList[n].id==t.id){if(e=n,s=e+1,this.directBuyList.Count()>s){i=this.directBuyList[s].id
break}s=e-1,i>=0&&(i=this.directBuyList[s].id)
break}this.directBuyList.Remove(t),-1!=i&&this.RaiseEvent(S.Remove_Item,i)}GetNextId(){return this.directBuyList.Count()>0?this.directBuyList[0].id:-1}UpdateRedPointStatus(t,e){
if(this.redPointId){const t=this.IsRed()
c.f.Inst.SetState(this.redPointId,t),null!=e&&e.SetActive(c.f.Inst.GetData(this.redPointId).show)}}GetIndex(t){
for(let e=0;e<=this.directBuyList.Count()-1;e++)if(this.directBuyList[e].id==t)return e
return 0}GetSelectedId(){let t=0
for(let e=0;e<=this.directBuyList.Count()-1;e++)if(!this.directBuyList[e].hasShow){t=this.directBuyList[e].id
break}return 0==t&&this.directBuyList.Count()>0&&(t=this.directBuyList[0].id),t}IsLast(t){if(null!=this.directBuyList&&this.directBuyList.Count()>0){
const e=this.directBuyList.Length()
return this.directBuyList[e-1].id==t}}IsFirst(t){if(null!=this.directBuyList&&this.directBuyList.Count()>0)return this.directBuyList[0].id==t}ClearDirectBuyInfo(){
for(let t=0;t<=this.directBuyList.Count()-1;t++)this.directBuyList[t].Clear()
for(const[t,e]of(0,s.V5)(this.cacheDict)){for(let t=0;t<=e.Count()-1;t++)e[t].Clear()
e.Clear()}this.cacheDict.LuaDic_Clear(),this.directBuyList.Clear()}ClearCacheInfo(){for(const[t,e]of(0,s.V5)(this.cacheDict)){for(let t=0;t<=e.Count()-1;t++)e[t].Clear()
e.Clear()}this.cacheDict.LuaDic_Clear()}HaveSeen(t){return this.seenDic.IndexOf(t)>-1}HandleSeen(t){this.seenDic.Add(t),
_.p.inst.SendClientLogicSetting(I.R.DISCOUNT_SEEN_IDS,this.seenDic),this.UpdateRedPointStatus()}Clear(){this.hadCheckedStatus.Clear(),this.ClearDirectBuyInfo()}IsAllTimeOut(){
for(let t=0;t<=this.directBuyList.Count()-1;t++)if(!this.directBuyList[t].isInShowTime&&this.directBuyList[t].GetRemainTime()>0)return!1
return!0}StopDownTime(){for(let t=0;t<=this.directBuyList.Count()-1;t++)this.directBuyList[t].ClearEndTime()}CheckCacheData(){for(const[t,e]of(0,
s.V5)(this.cacheDict))if(!this.HasActive(t)&&this.directBuyList.Count()<this.maxCount&&e[0].startTime.ToNum()<l.D.serverMSTime_get()){const t=e[0]
this.AddToShow(t),e.RemoveAt(0)}}SortData(t,e){const i=t.startTime.ToNum()-e.startTime.ToNum()
return 0!=i?i:t.id-e.id}}S.Remove_Item="Remove_Item",S.inst=null},14857:(t,e,i)=>{
var s,n=i(6847),l=i(83908),a=i(46282),o=i(40053),r=i(5924),h=i(5494),d=i(75696),u=i(52389),c=i(47786),_=i(74657),I=i(95989);(0,
n.s_)(h.I.DISCOUNT_GOODS_BUY_RESULT,a.Z.ui_buy_discountgoods_panel).waitPrefab(o.Z.BaseItem_ry_basePrefabs).register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),
this.timeId=-1,this.leftTime=30}InitView(){this.goodsGrid.SetInitInfo("ui_baseitem",null,d.j),
this.m_handlerMgr.AddClickEvent(this.btnConfirm.node,this.CreateDelegate(this.OnClose))}SetData(t){const e=u.r.GetInst().GetCfg(t)
null!=e&&(t=e.rewardId)
const i=_.A.GetReward(t).GetAllRewardList()
this.goodsGrid.data_set(i),this.setTime(this.leftTime),this.titleLabel.textSet(c.x.Inst().getItemById(11040405).sys_messsage),
this.timeId=r.C.Inst_get().SetInterval(this.CreateDelegate(this.LoopTime),1e3)}LoopTime(){this.leftTime-=1,0==this.leftTime&&this.OnClose(),this.setTime(this.leftTime)}setTime(t){
this.confirmBtnLabel.textSet(`确认(${t})`)}ClearTime(){r.C.Inst_get().ClearInterval(this.timeId),this.timeId=-1}OnClose(){I.P.Inst_get().CloseBuyResultView()}Clear(){super.Clear(),
this.ClearTime()}Destroy(){}})},95760:(t,e,i)=>{i.d(e,{k:()=>O})
var s,n=i(6847),l=i(83908),a=i(46282),o=i(40053),r=i(38045),h=i(98800),d=i(97461),u=i(5924),c=i(5494),_=i(85602),I=i(75696),m=i(92679),g=i(85751),p=i(87923),C=i(86209),S=i(63456),f=i(48933),y=i(33828),v=i(52513),D=i(31896),E=i(65550),T=i(19519),A=i(74657),L=i(95989),w=i(29479)
class R extends((0,l.zB)()){constructor(...t){super(...t),this.timeid=-1,this.id=null}InitView(){this.downtimelab.SetColor(g.u.BrightGreenColor)}AddLis(){}RemoveLis(){}SetData(t){
this.id=t.id
const e=t.cfg_get()
this.normallab.textSet(e.tabName),this.presslab.textSet(e.tabName),this.ClearTimer(),this.timeid=u.C.Inst_get().SetInterval(this.CreateDelegate(this.LoopTime),300),this.LoopTime(),
this.SetItemClickGo(this.boxcollider)}LoopTime(){if(w.X.Inst_get().isStop)return void this.downtimelab.textSet("暂停计时")
const t=w.X.Inst_get().GetById(this.id)
if(t){const e=t.GetRemainTime()
e<=0&&this.ClearTimer(),this.SetTime(e)}}SetTime(t){this.downtimelab.textSet(p.l.GetTimeInHMS(t/1e3,!0)),t<12e5?(this.downtimelab.SetColor(g.u.RedColor),
t<=0&&this.downtimelab.textSet("已结束")):this.downtimelab.SetColor(g.u.BrightGreenColor)}SetSelect(t){this.pressed.SetActive(t),this.normal.SetActive(!t),
this.downtimelab.SetActive(!t),t||this.downtimelab.node.transform.SetLocalPositionXYZ(-5,-6,0)}Clear(){this.RemoveLis(),this.ClearTimer(),super.Clear()}ClearTimer(){
this.timeid>-1&&(u.C.Inst_get().ClearInterval(this.timeid),this.timeid=-1)}Destroy(){}Test1(){return!0}S_Test(){return!0}}let O=(0,
n.s_)(c.I.DISCOUNT_GOODS_MAINVIEW,a.Z.ui_discountgoods_mainview).waitPrefab(o.Z.BaseItem_ry_basePrefabs).register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),
this.timeId=-1,this.cfg=null,this.id=null,this.selectedIndex=null,this.btnThink=null,this.rightbtn=null,this.leftbtn=null}InitView(){
this.m_handlerMgr.AddClickEvent(this.btnClose.node,this.CreateDelegate(this.OnClose)),this.m_handlerMgr.AddClickEvent(this.btnBuy.node,this.CreateDelegate(this.OnBuyClick)),
this.m_handlerMgr.AddNotifyEvent(w.X.Inst_get(),w.X.Remove_Item,this.CreateDelegate(this.OnRemoveItem)),this.goodsGrid.SetInitInfo("ui_baseitem",null,I.j),
this.goodsGrid.OnReposition_set(this.CreateDelegate(this.ResetTable)),
this.grid.SetInitInfo("ui_discountgoods_tab",this.CreateDelegate(this.CreateItem),R,this.CreateDelegate(this.OnTabClick)),
this.grid.OnReposition_set(this.CreateDelegate(this.OnGridReposition))}ResetTable(){const t=this.goodsGrid.itemList.Count()*this.goodsGrid.CellWidth()/2
this.right.SetLocalPositionXYZ(t,0,0),this.left.SetLocalPositionXYZ(-t-60,0,0)}OnAddToScene(){super.OnAddToScene()
const t=L.P.Inst_get().openMainViewId
t&&(this.UpdateSelected(t),this.SetData(t))}UpdateSelected(t){
if(this.grid.itemList)for(let e=0;e<=this.grid.itemList.Count()-1;e++)this.grid.itemList[e].id==t?this.grid.itemList[e].SetSelect(!0):this.grid.itemList[e].SetSelect(!1)}
OnGridReposition(){this.UpdateSelected(this.id)}OnTabClick(t){const e=this.grid.itemList.IndexOf(t),i=w.X.Inst_get().directBuyList[e].id
this.SetData(i)
for(let t=0;t<=this.grid.itemList.Count()-1;t++)t==e?this.grid.itemList[t].SetSelect(!0):this.grid.itemList[t].SetSelect(!1)}SetData(t){C.w.Instance.showRechargeEff=!0
const e=w.X.Inst_get().GetById(t)
this.id=t,w.X.Inst_get().HaveSeen(t)||w.X.Inst_get().HandleSeen(t)
const i=e.cfg_get()
if(this.cfg=i,this.titleTip.spriteNameSet(i.title,"zhigoujiacan"),this.discountLabel.textSet(`${i.discount}%`),this.titleDescLabel.textSet(i.content),0!=i.rechargeId){
this.buyCostLabel.node.SetActive(!1),this.costIcon.node.SetActive(!1),f.I.calVec0.Set(0,0,0),this.confirmLabel.node.transform.SetLocalPosition(f.I.calVec0)
const t=v.O.Inst().getConfig(i.rechargeId)
this.confirmLabel.textSet(`${v.O.Inst().GetCfgMoney(t)}元`)}else{this.buyCostLabel.node.SetActive(!0),this.costIcon.node.SetActive(!0),f.I.calVec0.Set(-44,0,0),
this.confirmLabel.node.transform.SetLocalPosition(f.I.calVec0),this.confirmLabel.textSet("购买")
const t=S.d.CreateFromJson(i.consume).costs[0]
t.Parse(),this.costIcon.spriteNameSet(T.J.GetCurrencyIconUrl(t.subtype)),this.buyCostLabel.textSet(t.subvalue)}const s=A.A.GetReward(i.rewardId).GetAllRewardList()
this.goodsGrid.data_set(s),this.UpdatePoints(),this.ClearTime(),this.timeId=u.C.Inst_get().SetInterval(this.CreateDelegate(this.LoopTime),300),this.LoopTime()}OnRightbtnClick(){
let t=w.X.Inst_get().GetIndex(this.id)
t+=1
const e=w.X.Inst_get().directBuyList[t].id
this.SetData(e)}OnLeftbtnClick(){let t=w.X.Inst_get().GetIndex(this.id)
t-=1
const e=w.X.Inst_get().directBuyList[t].id
this.SetData(e)}UpdateStatus(){const t=w.X.Inst_get().IsLast(this.id),e=w.X.Inst_get().IsFirst(this.id)
this.UpdatePageBtn(e,t),this.UpdateBtn(t)}CreateItem(t){}OnRemoveItem(t){this.SetData(t)}UpdatePoints(){this.selectedIndex=w.X.Inst_get().GetIndex(this.id)
for(let t=0;this.grid.itemList&&t<=this.grid.itemList.Count()-1;t++)this.grid.itemList[t].selectIndex=this.selectedIndex,
w.X.Inst_get().directBuyList.Count()>t&&this.grid.itemList[t].SetData(w.X.Inst_get().directBuyList[t])
if(!this.grid.itemList||this.grid.itemList.Count()!=w.X.Inst_get().directBuyList.Count()){const t=new _.Z
for(let e=0;e<=w.X.Inst_get().directBuyList.Count()-1;e++)t.Add(w.X.Inst_get().directBuyList[e])
this.grid.data_set(t)}}UpdateBtn(t){t?this.btnThink.SetText("让我想一想"):this.btnThink.SetText("下一页")}UpdatePageBtn(t,e){e?this.rightbtn.SetActive(!1):this.rightbtn.SetActive(!0),
t?this.leftbtn.SetActive(!1):this.leftbtn.SetActive(!0)}OnThinkClick(){w.X.Inst_get().IsLast(this.id)?this.OnClose():this.OnRightbtnClick()}LoopTime(){
if(w.X.Inst_get().isStop)return this.timeLabel.textSet("暂停计时"),void this.timeLabel.SetColor(g.u.GreenColor)
const t=w.X.Inst_get().GetById(this.id)
if(t){const e=t.GetRemainTime()
e<=0&&this.ClearTime(),this.SetTime(e)}else{const t=w.X.Inst_get().GetNextId();-1==t?(L.P.Inst_get().CloseMainView(),
d.i.Inst.RaiseEvent(m.g.SWITCH_ACTIVITY_REMOVE,!1)):this.SetData(t)}}SetTime(t){this.timeLabel.textSet(p.l.GetTimeInHMS(t/1e3,!0)),t<12e5?(this.timeLabel.SetColor(g.u.RedColor),
t<=0&&(this.timeLabel.textSet("已结束"),w.X.Inst_get().IsAllTimeOut()&&(L.P.Inst_get().CloseMainView(),
d.i.Inst.RaiseEvent(m.g.SWITCH_ACTIVITY_REMOVE,!1)))):this.timeLabel.SetColor(g.u.GreenColor)}OnBuyClick(){
if(0!=this.cfg.rechargeId)D.t.inst.Buy(v.O.Inst().getConfig(this.cfg.rechargeId),null)
else{const t=S.d.CreateFromJson(this.cfg.consume).costs[0]
t.Parse()
const e=T.J.GetGold(h.Y.Inst.PrimaryRoleInfo_get(),t.subtype)
if((0,r.aI)(t.subvalue)>e)return void(t.subtype==T.J.GOLD_DIAMOND_STR?y.Y.Inst_get().OpenTip(this.CreateDelegate(this.OnOpenDiamondTip)):E.y.inst.ClientSysMessage(100501))
L.P.Inst_get().requestBuy(this.cfg.id)}}OnClose(){L.P.Inst_get().CloseMainView()}ClearTime(){u.C.Inst_get().ClearInterval(this.timeId),this.timeId=-1}OnOpenDiamondTip(t){
y.Y.Inst_get().OkHandler(null)}Clear(){C.w.Instance.showRechargeEff=!1,super.Clear(),this.ClearTime()}Destroy(){}})||s},83263:(t,e,i)=>{i.d(e,{J:()=>Z})
var s,n,l,a,o,r,h=i(42292),d=i(71409),u=i(17409),c=i(38836),_=i(32309),I=i(38952),m=i(38935),g=i(5924),p=i(56937),C=i(31222),S=i(5494),f=i(52726),y=i(85602),v=i(38962),D=i(37648),E=i(55492),T=i(41361),A=i(46915),L=i(59119),w=i(10401),R=i(13031),O=i(17343),G=i(22599),b=i(70562),M=i(92415),P=i(14792),B=i(62734),x=i(55490),N=i(48387),k=i(94295),V=i(47653),F=i(70354),U=i(22982),H=i(98043)
function q(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let Z=(s=(0,d.GH)(M.k.SM_DivineInfo),n=(0,d.GH)(M.k.SM_DivineDetail),l=(0,d.GH)(M.k.SM_DivineCoreInfo),a=(0,
d.GH)(M.k.SM_DivineCoreLevelUp),r=class t{constructor(){this._degf_SM_DivineInfo=null,this._degf_SM_DivineDetail=null,this._degf_CheckDivineRedPoint=null,
this._degf_CheckDivineCodeRedPoint=null,this._degf_SM_DivineInfo=t=>this.SM_DivineInfoHandle(t),this._degf_SM_DivineDetail=t=>this.SM_DivineDetailHandle(t),
this._degf_CheckDivineRedPoint=t=>this.CheckDivineRedPoint(),this._degf_CheckDivineCodeRedPoint=t=>this.CheckDivineCodeRedPoint(),this.AddLis()}static Inst(){
return null==t._inst&&(t._inst=new t),t._inst}AddLis(){I.o.Inst().AddGroup(_.Z.GROUP_NORMAL_BAG,this._degf_CheckDivineRedPoint),
I.o.Inst().AddGroup(_.Z.GROUP_NORMAL_BAG,this._degf_CheckDivineCodeRedPoint)}SM_DivineInfoHandle(t){console.log("SM_DivineInfoHandle"),V.x.Inst().divineInfoDic=t.divineVos,
this.CheckDivineRedPoint()}SM_DivineDetailHandle(t){console.log("SM_DivineDetailHandle"),V.x.Inst().divineInfoDic[t.divineVo.divineId]=t.divineVo,this.CheckDivineRedPoint(),
V.x.Inst().RaiseEvent(k.P.UPDATE_DIVINE_INFO,[t.divineVo.divineId,t.locId]),0==t.locId&&1==t.divineVo.stage&&g.C.Inst_get().SetInterval((()=>{
this.OpenDivineActiveView(t.divineVo.divineId)}),500,1)}SM_DivineCoreInfoHandle(t){x.X.Inst().serverCoreInfo.Clear()
for(const[e,i]of(0,c.V5)(t.coreInfoMap))x.X.Inst().serverCoreInfo.LuaDic_AddOrSetItem(i.divineId,i)
x.X.Inst().UpdateAllActiveNumDic(),this.CheckDivineCodeRedPoint()}SM_DivineCoreLevelUpHandle(t){null==x.X.Inst().serverCoreInfo&&(x.X.Inst().serverCoreInfo=new v.X)
let e=x.X.Inst().serverCoreInfo[t.divineId],i=null
if(null==e){e=new b.U,i=new v.X,e.holdInfos=i
const s=N.s.Inst().GetMaxLocIdByDivineId(t.divineId)
for(let t=1;t<=s;t++){const e=new G.N
e.id=t,e.level=0,i.LuaDic_AddOrSetItem(t,e)}e.divineId=t.divineId,x.X.Inst().serverCoreInfo.LuaDic_AddOrSetItem(t.divineId,e)}else i=e.holdInfos
i[t.holdInfo.id]=t.holdInfo,x.X.Inst().UpdateActiveNumDic(e),this.CheckDivineCodeRedPoint(),x.X.Inst().RaiseEvent(k.P.UPDATE_DIVINE_CODE_LOC_LEVEL_UP,100*t.divineId+t.holdInfo.id)}
Req_CM_DivineActiveDivine(t){const e=new T.d
e.divineId=t,m.C.Inst.F_SendMsg(e)}Req_CM_DivineActiveLoc(t,e){const i=new A.a
i.divineId=t,i.activeLoc=e,m.C.Inst.F_SendMsg(i)}Req_CM_DivineBreakLoc(t,e){const i=new L.b
i.divineId=t,i.breakLoc=e,m.C.Inst.F_SendMsg(i)}Req_CM_DivineUpgradeLoc(t,e){const i=new R.m
i.divineId=t,i.upgradeLoc=e,m.C.Inst.F_SendMsg(i)}Req_CM_DivineUpgradeStage(t){const e=new O.k
e.divineId=t,m.C.Inst.F_SendMsg(e)}OpenDivineActiveView(t){V.x.Inst().activeViewDivineId=t
const e=new p.v
e.layerType=f.F.MainUI,e.viewClass=F.l,e.isShowMask=!0,C.N.inst.OpenById(S.I.eDivineActive,null,null,e)}Req_CM_DivineCoreLevelUp(t,e){const i=new w.a
i.divineId=t,i.locId=e,m.C.Inst.F_SendMsg(i)}CloseDivineActiveView(){C.N.inst.CloseById(S.I.eDivineActive)}CheckDivineRedPoint(){
if(!D.P.Inst_get().IsFunctionOpened(E.x.DIVINE))return
const t=V.x.Inst()
let e=!1
const i=t.redPointData
i.Clear()
const s=t.GetDivineList()
for(let n=0;n<=s.Count()-1;n++){const l=s[n],a=t.GetDivineVoByDivineId(l)
if(null!=a&&(e=t.GetDivineCanLevelUp(l,a.stage+1),e)){i.LuaDic_AddOrSetItem(l,new y.Z([0]))
break}}if(!e){for(let e=0;e<=s.Count()-1;e++){const n=s[e],l=t.GetDivineLocListByDivineId(n),a=l.Count()
let o=!1,r=!1
const h=new y.Z
for(let e=0;e<=a-1;e++){const i=l[e]
0==t.GetDivineLocCanActive(n,i)&&(h.Add(i),o=!0)}if(!o)for(let e=0;e<=a-1;e++){const i=l[e]
0==t.GetDivineLocCanBreak(n,i)&&(h.Add(i),r=!0)}if(!o&&!r)for(let e=0;e<=a-1;e++){const i=l[e]
0==t.GetDivineLocCanLevelUp(n,i)&&h.Add(i)}h.Count()>0&&i.LuaDic_AddOrSetItem(n,h)}i.LuaDic_Count()>0&&(e=!0)}B.f.Inst.SetState(P.t.DIVINE_BASE,e)}CheckDivineCodeRedPoint(){
x.X.Inst().CheckRedPoint()}OpenDivineSkillTips(t,e){V.x.Inst().SetTipsSkillStrid(t,e)
const i=new p.v
i.isShowMask=!0,i.isDefaultUITween=!0,i.layerType=f.F.Tip,i.viewClass=H.k,(0,u.Yp)(S.I.RyDivineSkillTipView)}OpenDivineCodeSkillTips(t,e){x.X.Inst().SetTipsSkillStrid(t,e)
const i=new p.v
i.isShowMask=!0,i.isDefaultUITween=!0,i.layerType=f.F.Tip,i.viewClass=U.D,(0,u.Yp)(S.I.RyDivineCodeSkillTipView)}CloseDivineSkillTips(){(0,u.sR)(S.I.RyDivineSkillTipView)}
CloseDivineCodeSkillTips(){(0,u.sR)(S.I.RyDivineCodeSkillTipView)}},r._inst=null,q(o=r,"Inst",[h.Vx],Object.getOwnPropertyDescriptor(o,"Inst"),o),
q(o.prototype,"SM_DivineInfoHandle",[s],Object.getOwnPropertyDescriptor(o.prototype,"SM_DivineInfoHandle"),o.prototype),
q(o.prototype,"SM_DivineDetailHandle",[n],Object.getOwnPropertyDescriptor(o.prototype,"SM_DivineDetailHandle"),o.prototype),
q(o.prototype,"SM_DivineCoreInfoHandle",[l],Object.getOwnPropertyDescriptor(o.prototype,"SM_DivineCoreInfoHandle"),o.prototype),
q(o.prototype,"SM_DivineCoreLevelUpHandle",[a],Object.getOwnPropertyDescriptor(o.prototype,"SM_DivineCoreLevelUpHandle"),o.prototype),o)},55490:(t,e,i)=>{i.d(e,{X:()=>I})
var s=i(38836),n=i(16812),l=i(38962),a=i(70850),o=i(37648),r=i(55492),h=i(14792),d=i(62734),u=i(48387),c=i(94295),_=i(47653)
class I extends n.k{constructor(){super(),this.selectCodeLocId=0,this.serverCoreInfo=null,this.activeSuitAttrNumDic=null,this.activeSuitNumDic=null,this.divineCodeSkillLvDic=null,
this.redPointData=null,this.tipsDivineId=null,this.tipsskillLv=null,this.serverCoreInfo=new l.X,this.activeSuitAttrNumDic=new l.X,this.activeSuitNumDic=new l.X,
this.divineCodeSkillLvDic=new l.X,this.redPointData=new l.X}static Inst(){return null==I._inst&&(I._inst=new I),I._inst}ResetModel(){this.selectCodeLocId=0,
this.serverCoreInfo.Clear(),this.activeSuitAttrNumDic.Clear(),this.activeSuitNumDic.Clear(),this.divineCodeSkillLvDic.Clear(),this.redPointData.Clear()}UpdateAllActiveNumDic(){
this.activeSuitAttrNumDic.Clear(),this.activeSuitNumDic.Clear(),this.divineCodeSkillLvDic.Clear()
for(const[t,e]of(0,s.V5)(this.serverCoreInfo))this.UpdateActiveNumDic(e)}UpdateActiveNumDic(t){let[e,i,n]=[0,0,0],l=-1
for(const[e,i]of(0,s.V5)(t.holdInfos))i.level>0&&(n+=1),(-1==l||l>i.level)&&(l=i.level)
const a=u.s.Inst().GetDivineCoreSuitResList(t.divineId)
for(let t=a.Count()-1;t>=0;t+=-1){const s=a[t]
s.condition>=n?e=s.condition:i=s.condition}this.activeSuitAttrNumDic.LuaDic_AddOrSetItem(t.divineId,[e,i]),this.activeSuitNumDic.LuaDic_AddOrSetItem(t.divineId,n),
this.divineCodeSkillLvDic.LuaDic_AddOrSetItem(t.divineId,0)
const o=u.s.Inst().GetDivineCoreSkillMaxLv(t.divineId)
for(let e=1;e<=o;e++){if(!(l>=u.s.Inst().GetDivineCoreSkillRes(t.divineId,e).coreLevel))break
this.divineCodeSkillLvDic.LuaDic_AddOrSetItem(t.divineId,e)}}CheckHasRed(t,e){return!(null==this.redPointData[t]||!this.redPointData[t][e])}GetAttrActiveNum(t){
return this.activeSuitAttrNumDic[t]}GetActiveNum(t){return this.activeSuitNumDic[t]||0}GetSkillLv(t){return this.divineCodeSkillLvDic[t]||0}SetSelectCodeLocId(t,e){
this.selectCodeLocId=t,e||this.RaiseEvent(c.P.UPDATE_DIVINE_CODE_LOC_SELECT,t)}GetDefaultCodeLocId(t){return 1}GetSelectCodeLocId(){return this.selectCodeLocId}
GetDivineCoreHoldInfoDic(t){return null!=this.serverCoreInfo[t]?this.serverCoreInfo[t].holdInfos:null}GetDivineCoreHoldInfo(t,e){const i=this.GetDivineCoreHoldInfoDic(t)
return null!=i?i[e]:null}CheckRedPoint(){if(this.redPointData.Clear(),o.P.Inst_get().IsFunctionOpened(r.x.DIVINE_CODE)){const t=_.x.Inst().GetDivineCodeDivineList()
for(let e=0;e<=t.Count()-1;e++){const i=t[e],s=u.s.Inst().GetMaxLocIdByDivineId(i)
for(let t=1;t<=s;t++){const e=this.GetDivineCoreHoldInfo(i,t),s=null!=e&&e.level||0
if(this.CheckIsCanLevelUp(i,t,s)){this.redPointData.LuaDic_ContainsKey(i)||this.redPointData.LuaDic_AddOrSetItem(i,new l.X)
this.redPointData[i].LuaDic_AddOrSetItem(t,!0)}}}this.RaiseEvent(c.P.UPDATE_DIVINE_CODE_LOC_RED)}
this.redPointData.Count()>0?d.f.Inst.SetState(h.t.DIVINE_CODE,!0):d.f.Inst.SetState(h.t.DIVINE_CODE,!1)}GetDefaultSelectId(){const t=_.x.Inst().GetDivineCodeDivineList()
for(let e=0;e<=t.Count()-1;e++){const i=t[e]
if(null!=this.redPointData[i]&&this.redPointData[i].Count()>0)return i}return t[0]}SetTipsSkillStrid(t,e){this.tipsDivineId=t,this.tipsskillLv=e}GetDefaultLocId(t){let e=-1,i=0
const s=u.s.Inst().GetMaxLocIdByDivineId(t)
if(null!=this.redPointData[t]&&this.redPointData[t].Count()>0)for(let n=1;n<=s;n++){const s=this.GetDivineCoreHoldInfo(t,n),l=null!=s&&s.level||0
;(-1==e||l<i)&&this.redPointData[t][n]&&(e=n,i=l)}else for(let n=1;n<=s;n++){const s=this.GetDivineCoreHoldInfo(t,n),l=null!=s&&s.level||0;(-1==e||l<i)&&(e=n,i=l)}return e}
CheckIsCanLevelUp(t,e,i){if(i<u.s.Inst().GetMaxLocLevel(t,e)){const s=u.s.Inst().GetCodeConsumeList(t,e,i),n=s.Count()
for(let t=0;t<=n-1;t++){const e=s[t],i=e.modelId_get(),n=e.needNum
if(a.g.Inst_get().GetItemNum(i)<n)return!1}return!0}return!1}GetLevelUpNeedItem(t,e,i){const s=u.s.Inst().GetCodeConsumeList(t,e,i),n=s.Count()
for(let t=0;t<=n-1;t++){const e=s[t],i=e.modelId_get(),n=e.needNum
if(a.g.Inst_get().GetItemNum(i)<n)return i}return 0}Test1(){return!0}S_Test(){return!0}}I._inst=null},48387:(t,e,i)=>{i.d(e,{s:()=>_})
var s=i(93984),n=i(32076),l=i(38836),a=i(5583),o=i(55360),r=i(98885),h=i(85602),d=i(38962),u=i(63076),c=i(77477)
class _{constructor(){this.divineList=null,this.divineCoreDic=null,this.maxLocDic=null,this.divineCoreConsumeDic=null,this.divineCoreKeyDicToConsume=null,
this.divineCoreAttrDic=null,this.maxLevelDic=null,this.divineCoreSkillDic=null,this.divineCoreMaxSkill=null,this.divineCoreSuitDic=null,this.divineCoreSuitListDic=null,
this.divineCoreSuitAttrDic=null
let t=o.Y.Inst.GetOrCreateCsv(s.h.eDivineCoreresourceCsv).GetCsvMap()
this.divineList=new h.Z,this.divineCoreDic=new d.X,this.maxLocDic=new d.X,this.divineCoreConsumeDic=new d.X,this.divineCoreKeyDicToConsume=new d.X,this.divineCoreAttrDic=new d.X,
this.maxLevelDic=new d.X
const e=new d.X
for(const[i,s]of(0,l.V5)(t)){const t=1e6*s.divineId+1e4*s.locId+s.locLv
this.divineCoreDic.LuaDic_AddOrSetItem(t,s),e.LuaDic_ContainsKey(s.divineId)||(this.divineList.Add(s.divineId),e.LuaDic_AddOrSetItem(s.divineId,!0)),
(!this.maxLocDic.LuaDic_ContainsKey(s.divineId)||this.maxLocDic[s.divineId]<s.locId)&&this.maxLocDic.LuaDic_AddOrSetItem(s.divineId,s.locId),
(!this.maxLevelDic.LuaDic_ContainsKey(100*s.divineId+s.locId)||this.maxLevelDic[100*s.divineId+s.locId]<s.locLv)&&this.maxLevelDic.LuaDic_AddOrSetItem(100*s.divineId+s.locId,s.locLv)
const i=new d.X
let n=a.L.GetCommonTypeValuesConfig(s.attr)
if(null!=n){const t=n.typevalues
for(const[e,s]of(0,l.V5)(t)){const t=c.Z.GetAttrKey(s.type)
i.LuaDic_AddOrSetItem(t,r.M.String2Int(s.value))}}this.divineCoreAttrDic.LuaDic_AddOrSetItem(t,i),n=a.L.GetCommonTypeValuesConfig(s.consume,!0)
const o=new h.Z
if(null!=n){const t=n.typevalues
for(let e=0;e<=t.Count()-1;e++){const i=new u.M(r.M.String2Int(t[e].valueType),null)
i.needNum=r.M.String2Int(t[e].valueNum),o.Add(i)}}this.divineCoreConsumeDic.LuaDic_AddOrSetItem(t,o),
1==s.type&&1==s.locLv&&o.Count()>0&&this.divineCoreKeyDicToConsume.LuaDic_AddOrSetItem(o[0].modelId_get(),t)}t=o.Y.Inst.GetOrCreateCsv(s.h.eDivineCoreSkillresourceCsv).GetCsvMap(),
this.divineCoreSkillDic=new d.X,this.divineCoreMaxSkill=new d.X
for(const[e,i]of(0,l.V5)(t))this.divineCoreSkillDic.LuaDic_AddOrSetItem(1e4*i.divineId+i.locLv,i),
(!this.divineCoreMaxSkill.LuaDic_ContainsKey(i.divineId)||this.divineCoreMaxSkill[i.divineId]<i.locLv)&&this.divineCoreMaxSkill.LuaDic_AddOrSetItem(i.divineId,i.locLv)
t=o.Y.Inst.GetOrCreateCsv(s.h.eDivineCoreSuitresourceCsv).GetCsvMap(),this.divineCoreSuitDic=new d.X,this.divineCoreSuitListDic=new d.X,this.divineCoreSuitAttrDic=new d.X
for(const[e,i]of(0,l.V5)(t)){let t=this.divineCoreSuitListDic[i.divineId],e=this.divineCoreSuitDic[i.divineId]
null==t&&(t=new h.Z,this.divineCoreSuitListDic.LuaDic_AddOrSetItem(i.divineId,t),e=new d.X,this.divineCoreSuitDic.LuaDic_AddOrSetItem(i.divineId,e))
const s=a.L.GetCommonTypeValuesConfig(i.attr),n=new d.X
if(null!=s){const t=s.typevalues
for(const[e,i]of(0,l.V5)(t)){const t=c.Z.GetAttrKey(i.type)
n.LuaDic_AddOrSetItem(t,r.M.String2Int(i.value))}}this.divineCoreSuitAttrDic.LuaDic_AddOrSetItem(i.id,n),t.Add(i),e.LuaDic_AddOrSetItem(i.condition,i)}for(const[t,e]of(0,
l.V5)(this.divineCoreSuitListDic))e.Sort((0,n.v)(this.OnSortSuitRes,this))
t=null}static Inst(){return null==_.inst&&(_.inst=new _),_.inst}OnSortSuitRes(t,e){return t.condition<e.condition?-1:t.condition>e.condition?1:0}GetDivineCoreRes(t,e,i){
return this.divineCoreDic[1e6*t+1e4*e+i]}GetDivineCoreSkillRes(t,e){return this.divineCoreSkillDic[1e4*t+e]}GetDivineCoreSkillMaxLv(t){return this.divineCoreMaxSkill[t]}
GetDivineIdAndLocIdByCostId(t){const e=this.divineCoreKeyDicToConsume[t]
if(null!=e){const t=this.divineCoreDic[e]
if(null!=t){return[t.divineId,t.locId]}}return[0,0]}GetDivineCoreSuitRes(t,e){const i=this.divineCoreSuitDic[t]
return null!=i?i[e]:null}GetDivineCoreSuitResList(t){return this.divineCoreSuitListDic[t]}GetDivineCoreSuitAttrDic(t){return this.divineCoreSuitAttrDic[t]}GetMaxLocIdByDivineId(t){
return this.maxLocDic[t]}GetMaxLocLevel(t,e){return this.maxLevelDic[100*t+e]}GetCodeAttrDic(t,e,i){return this.divineCoreAttrDic[1e6*t+1e4*e+i]}GetCodeConsumeList(t,e,i){
return this.divineCoreConsumeDic[1e6*t+1e4*e+i]}GetShowDivineList(){return this.divineList}Test1(){return!0}S_Test(){return!0}}_.inst=null},94295:(t,e,i)=>{i.d(e,{P:()=>s})
class s{}s.UPDATE_DIVINE_SELECT="UPDATE_DIVINE_SELECT",s.UPDATE_DIVINE_LOC_SELECT="UPDATE_DIVINE_LOC_SELECT",s.UPDATE_DIVINE_INFO="UPDATE_DIVINE_INFO",
s.UPDATE_DIVINE_CODE_LOC_SELECT="UPDATE_DIVINE_CODE_LOC_SELECT",s.UPDATE_DIVINE_CODE_LOC_LEVEL_UP="UPDATE_DIVINE_CODE_LOC_LEVEL_UP",
s.UPDATE_DIVINE_CODE_LOC_RED="UPDATE_DIVINE_CODE_LOC_RED"},47653:(t,e,i)=>{i.d(e,{x:()=>m})
var s=i(38836),n=i(16812),l=i(85602),a=i(38962),o=i(70850),r=i(63076),h=i(87923),d=i(54220),u=i(35048),c=i(77086),_=i(48387),I=i(94295)
class m extends n.k{constructor(){super(),this.selectDivineId=0,this.selectLocId=0,this.divineInfoDic=null,this.activeViewDivineId=0,this.redPointData=null,
this.selectTabIdx=m.S_DIVIE_BASE_VIEW_IDX,this.tipsSkillId=null,this.skillTipsdivineCfg=null,u.j.InitInst(),c.V.InitInst(),this.divineInfoDic=new a.X,this.redPointData=new a.X}
static Inst(){return null==m._inst&&(m._inst=new m),m._inst}InitView(){}Clear(){}Destroy(){}SetTipsSkillStrid(t,e){this.tipsSkillId=t,this.skillTipsdivineCfg=e}
GetDivineLocResByParam(t,e,i,s){return u.j.Inst.GetDivineLocResByParam(t,e,i,s)}GetDivineByIdAndStage(t,e){return c.V.Inst.GetDivineByIdAndStage(t,e)}GetDivineLocListByDivineId(t){
return u.j.Inst.GetDivineLocListByDivineId(t)}GetDivineList(){return c.V.Inst.GetDivineList()}GetDivineCodeDivineList(){return _.s.Inst().GetShowDivineList()}GetSelectDivineId(){
return this.selectDivineId}SetSelectDivineId(t,e){t!=this.selectDivineId&&(this.selectDivineId=t,e||this.RaiseEvent(I.P.UPDATE_DIVINE_SELECT,t))}GetDefaultSelectId(){
const t=this.GetRedPointDivineId()
if(0!=t)return t
return this.GetDivineList()[0]}GetDefaultLocId(t){const e=this.GetDivineVoByDivineId(t).stage
if(this.GetDivineCanLevelUp(t,e+1))return 0
const i=this.GetRedPointLocId(t)
return 0!=i?i:0}GetSelectLocId(){return this.selectLocId}SetSelectLocId(t,e){this.selectLocId=t,e||this.RaiseEvent(I.P.UPDATE_DIVINE_LOC_SELECT,t)}GetRedPointDivineId(){
const t=this.GetDivineList()
for(let e=0;e<=t.Count()-1;e++){const i=t[e],s=this.redPointData[i]
if(null!=s&&s.Count()>0)return i}return 0}GetRedPointLocId(t){const e=this.redPointData[t]
return null!=e&&e.Count()>0?e[0]:0}GetUnLockConsumeItems(t){const e=new l.Z
for(const[i,n]of(0,s.V5)(t.unlockConsumeDic)){const t=new r.M(i,null),s=new d.P(t,n,!1)
e.Add(s)}return e}GetUpgradeConsumeItems(t){const e=new l.Z
for(const[i,n]of(0,s.V5)(t.upgradeConsumeDic)){const t=new r.M(i,null),s=new d.P(t,n,!1)
e.Add(s)}return e}GetBreakConsumeItems(t){const e=new l.Z
for(const[i,n]of(0,s.V5)(t.breakConsumeDic)){const t=new r.M(i,null),s=new d.P(t,n,!1)
e.Add(s)}return e}GetDivineVoByDivineId(t){return this.divineInfoDic[t]}GetHoleInfoByDivineIdAndLocId(t,e){return this.GetDivineVoByDivineId(t).holeMap[e]}GetDivineProperyLabel(t){
u.j.Inst.GetDivineLocListByDivineId(t)
const e=this.GetDivineVoByDivineId(t).holeMap,i=new a.X
for(const[n,l]of(0,s.V5)(e)){let e=l.holeLv,n=l.holeStage,a=!1
0==n&&(a=!0,n=1,e=1)
const o=this.GetDivineLocResByParam(t,l.holeId,e,n)
for(const[t,e]of(0,s.V5)(o.attrDic)){const s=i[t]||0
a?i.LuaDic_AddOrSetItem(t,0+s):i.LuaDic_AddOrSetItem(t,e+s)}}const n=new l.Z
for(const[t,e]of(0,s.V5)(i)){const i=h.l.getAttrStr(t,!0,!0),s=`+${h.l.getAttrValueStr(t,e)}`
n.Add([i,s])}return n}GetDivineCanLevelUp(t,e){const i=this.GetDivineVoByDivineId(t)
if(null!=i){const n=this.GetDivineByIdAndStage(t,e)
if(null!=n){for(const[t,e]of(0,s.V5)(n.levelUpNeedMap))if(null==i.holeMap[t]||i.holeMap[t].holeStage<e)return!1
return!0}}return!1}GetDivineActiveLocNum(t,e){const i=this.GetDivineVoByDivineId(t)
let n=0,l=0
if(null!=i){const a=this.GetDivineByIdAndStage(t,e)
if(null!=a)for(const[t,e]of(0,s.V5)(a.levelUpNeedMap))n+=1,null==i.holeMap[t]||i.holeMap[t].holeStage<e||(l+=1)}return[l,n]}GetDivineLocCanActive(t,e){
const i=this.GetDivineVoByDivineId(t)
if(null!=i){const n=i.holeMap[e]
if(null!=n){const i=n.holeStage
if(0==i){const l=this.GetDivineLocResByParam(t,e,n.holeLv,i)
for(const[t,e]of(0,s.V5)(l.unlockConsumeDic))if(o.g.Inst_get().GetItemNum(t)<e)return t
return 0}}}return-1}GetDivineLocCanBreak(t,e){const i=this.GetDivineVoByDivineId(t)
if(null!=i){const n=i.holeMap[e]
if(null!=n){const i=n.holeStage,l=this.GetDivineLocResByParam(t,e,n.holeLv,i)
if(i>0&&n.holeLv>=l.maxLv&&i!=l.maxStage){for(const[t,e]of(0,s.V5)(l.breakConsumeDic))if(o.g.Inst_get().GetItemNum(t)<e)return t
return 0}}}return-1}GetDivineLocCanLevelUp(t,e){const i=this.GetDivineVoByDivineId(t)
if(null!=i){const n=i.holeMap[e]
if(null!=n){const i=n.holeStage,l=this.GetDivineLocResByParam(t,e,n.holeLv,i)
if(i>0&&n.holeLv<l.maxLv){for(const[t,e]of(0,s.V5)(l.upgradeConsumeDic))if(o.g.Inst_get().GetItemNum(t)<e)return t
return 0}}}return-1}}m._inst=null,m.S_DIVIE_BASE_VIEW_IDX=0,m.S_DIVIE_CODE_VIEW_IDX=1},70354:(t,e,i)=>{i.d(e,{l:()=>I})
var s,n,l=i(6847),a=i(83908),o=i(17409),r=i(46282),h=i(40053),d=i(70829),u=i(5494),c=i(83263),_=i(47653)
let I=(0,l.s_)(u.I.eDivineActive,r.Z.ui_divine_activeview).waitPrefab(h.Z.BaseItem_ry_basePrefabs).register()((n=class t extends((0,a.Ri)()){constructor(...t){super(...t),
this.divineId=null,this.model=null,this.divineCfg=null,this.modelDisplay=null}static __StaticInit(){t.STAGE_ID=131}InitView(){this.divineId=0,this.model=_.x.Inst()}Clear(){
this.ClearModel(),super.Clear()}Destroy(){super.Destroy()}OnAddToScene(){this.AddLis(),this.divineId=this.model.activeViewDivineId,
this.divineCfg=this.model.GetDivineByIdAndStage(this.divineId,1)
const t=d.j.Inst().GetSkillByStrId(this.divineCfg.skillId,!1)
this.ui_skillitem.SetData(this.divineCfg.skillId),this.skillDesc.textSet(t.desc),this.skillName.textSet(t.name),this.ShowModel()}ShowModel(){
this.roleTexture.spriteNameSet(`${this.divineCfg.divinePic}_4`,"shengwu"),
"ryshengwu_sp_001"==this.divineCfg.divinePic?this.roleTexture.node.setScale(.8,.8):this.roleTexture.node.setScale(.45,.45)}ClearModel(){}AddLis(){
this.m_handlerMgr.AddClickEvent(this.btn,this.CreateDelegate(this.CloseHandel)),(0,o.D1)(this,this.CreateDelegate(this.CloseHandel))}CloseHandel(){
c.J.Inst().CloseDivineActiveView()}},n.STAGE_ID=null,s=n))||s
I.__StaticInit()},8933:(t,e,i)=>{var s,n,l=i(18998),a=i(83908),o=i(18202),r=i(83540),h=i(98130),d=i(85602),u=i(33138),c=i(55490),_=i(48387),I=i(94295)
l._decorator.ccclass("DivineCodeHole")(((n=class extends((0,a.zB)()){constructor(...t){super(...t),this.divineCodeModel=null,this.isRightShow=null,this.codeLocId=null,
this.divineId=null,this.codeRes=null,this.effId1=null,this.effId2=null,this.effId3=null,this.holdInfo=null,this.lv=null,this.resPath="atlas/shengwuhexin/"}InitView(){
this.divineCodeModel=c.X.Inst(),this.isRightShow=!1}AddLis(){
this.isRightShow||(this.divineCodeModel.AddEventHandler(I.P.UPDATE_DIVINE_CODE_LOC_SELECT,this.CreateDelegate(this.UpdateSelect)),
this.divineCodeModel.AddEventHandler(I.P.UPDATE_DIVINE_CODE_LOC_LEVEL_UP,this.CreateDelegate(this.LevelUpShow)),
this.divineCodeModel.AddEventHandler(I.P.UPDATE_DIVINE_CODE_LOC_RED,this.CreateDelegate(this.UpdateRed))),
this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.OnClickBtn))}RemoveLis(){
this.divineCodeModel.RemoveEventHandler(I.P.UPDATE_DIVINE_CODE_LOC_SELECT,this.CreateDelegate(this.UpdateSelect)),
this.divineCodeModel.RemoveEventHandler(I.P.UPDATE_DIVINE_CODE_LOC_LEVEL_UP,this.CreateDelegate(this.LevelUpShow)),
this.divineCodeModel.RemoveEventHandler(I.P.UPDATE_DIVINE_CODE_LOC_RED,this.CreateDelegate(this.UpdateRed))}SetData(t,e,i){this.isRightShow=i,this.RemoveLis(),this.AddLis(),
this.codeLocId=e,this.divineId=t,this.UpdateView(),this.UpdateSelect(),this.isRightShow?this.redDot.SetActive(!1):this.UpdateState()}LevelUpShow(t){
null!=t&&h.GF.INT(t/100)==this.divineId&&t%100==this.codeLocId&&this.PlayEff(),this.UpdateView()}UpdateState(){const t=new d.Z(this.codeRes.itempos)
this.node.transform.SetLocalPosition(new l.Vec3(t[0],t[1],0)),1==this.codeRes.type?(this.bg2.setSkin(this.resPath+"ryshengwuhexin_sp_0002"),this.bg2.widthSet(108),
this.bg2.heightSet(108),this.bg.widthSet(95),this.bg.heightSet(95),this.labelbg.widthSet(72),this.labelbg.heightSet(23),
this.selectPic.transform.SetLocalPosition(new l.Vec3(1.3,1.3,1)),this.boxCollider.setContentSize(102,102),this.redDot.transform.SetLocalPosition(new l.Vec3(32.2,30.3,0)),
this.item.widthSet(85),this.item.heightSet(85)):2==this.codeRes.type?(this.bg2.setSkin(this.resPath+"ryshengwuhexin_sp_0003"),this.bg2.widthSet(85),this.bg2.heightSet(85),
this.bg.widthSet(80),this.bg.heightSet(80),this.labelbg.widthSet(68),this.labelbg.heightSet(22),this.selectPic.setScale(new l.Vec3(1,1,1)),this.boxCollider.setContentSize(74,74),
this.redDot.transform.SetLocalPosition(new l.Vec3(32.2,30.3,0)),this.item.widthSet(70),
this.item.heightSet(70)):3==this.codeRes.type&&(this.bg2.setSkin("atlas/shengwu/ryshengwu_sp_0008"),this.bg2.widthSet(60),this.bg2.heightSet(60),this.bg.widthSet(64),
this.bg.heightSet(64),this.labelbg.widthSet(54),this.labelbg.heightSet(17.6),this.selectPic.setScale(new l.Vec3(.8,.8,1)),this.boxCollider.setContentSize(58,58),
this.redDot.transform.SetLocalPosition(new l.Vec3(26.9,21.9,0)),this.item.widthSet(70),this.item.heightSet(70))}PlayEff(){}ClearEff(){}UpdateView(t){
if(null!=t&&(null==this.codeLocId||t!=this.codeLocId+100*this.divineId))return
this.holdInfo=this.divineCodeModel.GetDivineCoreHoldInfo(this.divineId,this.codeLocId),this.lv=null!=this.holdInfo&&this.holdInfo.level||0,
this.codeRes=_.s.Inst().GetDivineCoreRes(this.divineId,this.codeLocId,this.lv)
const e=u.f.Inst().getItemById(this.codeRes.icon)
o.g.SetItemIcon(this.item,e.icon,r.b.eItem,!1),this.isRightShow?(this.lvLabel.textSet(""),this.item.SetActive(!0),this.lvLabel.SetActive(!1)):this.lv>0?(this.item.SetActive(!0),
this.lvLabel.textSet(`+${this.lv}`),this.lvLabel.SetActive(!0)):(this.item.SetActive(!1),this.lvLabel.SetActive(!1)),this.UpdateRed()}UpdateRed(){
!this.isRightShow&&this.divineCodeModel.redPointData.LuaDic_ContainsKey(this.divineId)&&null!=this.divineCodeModel.redPointData[this.divineId][this.codeLocId]?this.redDot.SetActive(!0):this.redDot.SetActive(!1)
}UpdateSelect(){if(this.isRightShow)return void this.selectPic.SetActive(!1)
const t=this.divineCodeModel.GetSelectCodeLocId()
this.codeLocId==t?this.selectPic.SetActive(!0):this.selectPic.SetActive(!1)}Clear(){this.RemoveLis()}Destroy(){super.Destroy()}OnClickBtn(){
this.divineCodeModel.SetSelectCodeLocId(this.codeLocId)}
}).HOLE_POS_LIST=new d.Z([[[-185.3,-39.3,1.4],[-186.7,113.9,1],[189.6,114.3,1],[-19.4,-142.5,0],[53.7,-142.5,.8],[125.8,-142.5,.8],[199.1,-142.5,.8]]]),s=n))},75143:(t,e,i)=>{
var s,n=i(18998),l=i(83908),a=i(85602),o=i(55490),r=i(48387)
n._decorator.ccclass("DivineCodeLine")(s=class extends((0,l.yk)()){constructor(...t){super(...t),this.divineCodeModel=null,this.codeLocId=null,this.divineId=null,
this.resPath="atlas/shengwuhexin/"}InitView(){this.divineCodeModel=o.X.Inst()}SetData(t,e){this.codeLocId=e,this.divineId=t
const i=this.divineCodeModel.GetDivineCoreHoldInfo(this.divineId,this.codeLocId),s=null!=i&&i.level||0,l=r.s.Inst().GetDivineCoreRes(this.divineId,this.codeLocId,s).linepos,o=new a.Z(l)
s>0?(this.linepoint.spriteNameSet(this.resPath+"ryshengwuhexin_sp_0005"),1==o[0]?this.linepic.spriteNameSet(this.resPath+"ryshengwuhexin_sp_0008"):this.linepic.spriteNameSet(this.resPath+"ryshengwuhexin_sp_0006")):(this.linepoint.spriteNameSet(this.resPath+"ryshengwuhexin_sp_0004"),
1==o[0]?this.linepic.spriteNameSet(this.resPath+"ryshengwuhexin_sp_0009"):this.linepic.spriteNameSet(this.resPath+"ryshengwuhexin_sp_0007")),
this.linepic.node.transform.SetLocalPosition(new n.Vec3(o[1],o[2],0)),this.linepic.widthSet(o[3]),this.linepic.heightSet(o[4]),1!=o[0]&&this.linepic.heightSet(o[4]/2),
this.linepic.node.setRotationFromEuler(new n.Vec3(0,0,o[5])),this.linepoint.node.transform.SetLocalPosition(new n.Vec3(o[6],o[7],0))}Clear(){}Destroy(){}Test1(){return!0}S_Test(){
return!0}})},27747:(t,e,i)=>{i.d(e,{d:()=>O})
var s=i(83908),n=i(38836),l=i(70829),a=i(5924),o=i(28192),r=i(85602),h=i(79534),d=i(21554),u=i(70850),c=i(70093),_=i(59686),I=i(75696),m=i(53905),g=i(92679),p=i(85751),C=i(87923),S=i(65772),f=i(65550),y=i(83263),v=i(55490)
class D{constructor(t,e,i,s){this.intType=null,this.value=null,this.nextValue=null,this.isActive=null,this.isShowBg=!1,this.intType=t,this.value=e,this.nextValue=i,this.isActive=s}
Test1(){return!0}S_Test(){return!0}}var E=i(48387),T=i(94295),A=i(47653)
class L extends((0,s.yk)()){InitView(){}SetData(t){this.property.textSet(C.l.getAttrStr(t.intType,!1,!0)),
t.isActive?(this.curVal.textSet(C.l.SetStringColor(p.u.GreenColorStr,`+${C.l.getAttrValueStr(t.intType,t.value)}`)),
this.addProperty.textSet("")):null!=t.nextValue&&t.nextValue>0?(this.curVal.textSet(C.l.getAttrValueStr(t.intType,t.value)),
this.addProperty.textSet(C.l.SetStringColor(p.u.GreenColorStr,`+${C.l.getAttrValueStr(t.intType,t.nextValue-t.value)}`))):(this.curVal.textSet(C.l.getAttrValueStr(t.intType,t.value)),
this.addProperty.textSet("")),t.isShowBg?this.bg.SetActive(!0):this.bg.SetActive(!1)}Clear(){}Destroy(){}Test1(){return!0}S_Test(){return!0}}class w extends((0,s.yk)()){
InitView(){}SetData(t){this.tipsDesc.textSet(t)}PlayEff(){this.pre_eff_awakengem09_01.SetActive(!1),this.pre_eff_awakengem09_01.SetActive(!0)}Clear(){
this.pre_eff_awakengem09_01.SetActive(!1)}Destroy(){}Test1(){return!0}S_Test(){return!0}}var R=i(70997)
class O extends((0,s.Ri)()){constructor(...t){super(...t),this._m_handlerMgr=null,this.divineCList=null,this.holeList=null,this.lineList=null,this.model=null,this.codeModel=null,
this.dalayCallReq=null,this.oldActiveNum=null,this.nowActiveNum=null,this.divineId=null,this.selectLocId=null,this.selectHolelv=null,this.maxLoc=null,this.showSuitEff=null,
this.firstHoleCoreCfg=null,this.divineCfg=null,this.divineSkillCfg=null,this.divineCoreHoldInfo=null,this.state=null,this.selectCodeLocCfg=null,this.selectCoreSuitCfg=null,
this.resPath="atlas/shengwuhexin/"}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=o.h.Get()),this._m_handlerMgr}InitView(){this.holeList=new r.Z,
this.holeList.Add(this.ui_divine_code_hole),this.holeList.Add(this.ui_divine_code_hole1),this.holeList.Add(this.ui_divine_code_hole2),this.holeList.Add(this.ui_divine_code_hole3),
this.holeList.Add(this.ui_divine_code_hole4),this.holeList.Add(this.ui_divine_code_hole5),this.holeList.Add(this.ui_divine_code_hole6),this.lineList=new r.Z,
this.lineList.Add(this.ui_divine_code_line),this.lineList.Add(this.ui_divine_code_line1),this.lineList.Add(this.ui_divine_code_line2),this.lineList.Add(this.ui_divine_code_line3),
this.lineList.Add(this.ui_divine_code_line4),this.lineList.Add(this.ui_divine_code_line5),this.lineList.Add(this.ui_divine_code_line6),
this.grid.SetInitInfo("ui_divine_item",null,R.W,this.CreateDelegate(this.OnClickDivineItem)),this.propertyGrid.SetInitInfo("ui_divine_code_property",null,L),
this.costGrid.SetInitInfo("ui_baseitem",null,I.j),this.suitgrid.SetInitInfo("ui_divine_code_suit_item",null,w),
this.suitgrid.OnReposition_set(this.CreateDelegate(this.OnRepositionSuitgrid)),this.model=A.x.Inst(),this.codeModel=v.X.Inst()}OnClickDivineItem(t,e,i){
const s=this.grid.itemList.IndexOf(t),n=this.divineCList[s]
this.model.GetSelectDivineId()!=n&&(this.model.SetSelectDivineId(n),this.codeModel.SetSelectCodeLocId(this.codeModel.GetDefaultCodeLocId(n),!0),
null!=this.dalayCallReq&&(a.C.Inst_get().ClearInterval(this.dalayCallReq),this.dalayCallReq=null),this.UpdateSelectView(),this.UpdateLeftList())}AddLis(){
this.m_handlerMgr.AddClickEvent(this.levelUpBtn,this.CreateDelegate(this.OnClickBtn)),this.m_handlerMgr.AddClickEvent(this.tipBtn,this.CreateDelegate(this.OnClickTips)),
this.m_handlerMgr.AddEventMgr(g.g.BAG_UPDATE,this.CreateDelegate(this.UpdateCost)),
this.codeModel.AddEventHandler(T.P.UPDATE_DIVINE_CODE_LOC_SELECT,this.CreateDelegate(this.UpdateRightShow)),
this.codeModel.AddEventHandler(T.P.UPDATE_DIVINE_CODE_LOC_LEVEL_UP,this.CreateDelegate(this.SuccessShow)),
this.codeModel.AddEventHandler(T.P.UPDATE_DIVINE_CODE_LOC_RED,this.CreateDelegate(this.UpdateRed))}RemoveLis(){
this.m_handlerMgr.RemoveClickEvent(this.levelUpBtn,this.CreateDelegate(this.OnClickBtn)),this.m_handlerMgr.RemoveClickEvent(this.tipBtn,this.CreateDelegate(this.OnClickTips)),
this.m_handlerMgr.RemoveEventMgr(g.g.BAG_UPDATE,this.CreateDelegate(this.UpdateCost)),
this.codeModel.RemoveEventHandler(T.P.UPDATE_DIVINE_CODE_LOC_SELECT,this.CreateDelegate(this.UpdateRightShow)),
this.codeModel.RemoveEventHandler(T.P.UPDATE_DIVINE_CODE_LOC_LEVEL_UP,this.CreateDelegate(this.SuccessShow)),
this.codeModel.RemoveEventHandler(T.P.UPDATE_DIVINE_CODE_LOC_RED,this.CreateDelegate(this.UpdateRed))}Clear(){if(this.grid.Clear(),this.RemoveLis(),
null!=this.holeList)for(let t=0;t<=this.holeList.Count()-1;t++)this.holeList[t].Clear()
super.Clear()}SuccessShow(t){this.oldActiveNum=this.nowActiveNum,t==100*this.divineId+this.selectLocId&&(this.activeSuccessEff.parent.SetActive(!0),
0==this.selectHolelv?(this.activeSuccessEff.SetActive(!1),this.activeSuccessEff.SetActive(!0)):(this.levelUpSuccessEff.SetActive(!1),this.levelUpSuccessEff.SetActive(!0)),
setTimeout((()=>{this.activeSuccessEff.parent.SetActive(!1)}),1700),this.UpdateRightShow())}Destroy(){}SetData(){this.RemoveLis(),this.AddLis(),
this.divineCList=this.model.GetDivineCodeDivineList(),this.divineId=this.model.GetSelectDivineId(),this.UpdateLeftList(),this.UpdateSelectView()}UpdateLeftList(){
this.grid.data_set(this.divineCList)}UpdateHoleList(){this.maxLoc=E.s.Inst().GetMaxLocIdByDivineId(this.divineId)
const t=this.holeList.Count()
for(let e=0;e<=t-1;e++){const t=this.holeList[e],i=e+1
i<=this.maxLoc?(t.SetActive(!0),t.SetData(this.divineId,i)):t.SetActive(!1)}const e=this.lineList.Count()
for(let t=0;t<=e-1;t++){const e=this.lineList[t],i=t+1
i<=this.maxLoc?(e.SetActive(!0),e.SetData(this.divineId,i)):e.SetActive(!1)}}OnRepositionSuitgrid(){this.showSuitEff>-1&&this.suitgrid.itemList[this.showSuitEff].PlayEff()}
UpdateSelectView(){this.divineId=this.model.GetSelectDivineId(),this.levelUpSuccessEff.SetActive(!1),this.activeSuccessEff.SetActive(!1),this.UpdateHoleList(),
this.firstHoleCoreCfg=E.s.Inst().GetDivineCoreRes(this.divineId,1,1),this.divineCfg=this.model.GetDivineByIdAndStage(this.divineId,1),
this.divineNameLabel.textSet(this.divineCfg.name),this.oldActiveNum=null,this.UpdateRightShow()}UpdateSkill(){const t=this.codeModel.GetSkillLv(this.divineId)
this.ui_skillitem.SetMask(!1),this.ui_skillitem.SetEnableToClick((()=>{y.J.Inst().OpenDivineCodeSkillTips(this.divineId,t)}))
let e=null,i=""
if(0==t)this.divineSkillCfg=E.s.Inst().GetDivineCoreSkillRes(this.divineId,1),e=l.j.Inst().GetSkillByIdLevel(this.divineSkillCfg.skillId,1),this.ui_skillitem.SetData(e.id),
this.ui_skillitem.SetIconGray(!0),this.ui_skillitem.SetTipsLabel("未激活"),i=e.desc,this.nextSkillNeedDesc.textSet(this.divineSkillCfg.unlockDesc)
else if(this.divineSkillCfg=E.s.Inst().GetDivineCoreSkillRes(this.divineId,t),e=l.j.Inst().GetSkillByIdLevel(this.divineSkillCfg.skillId,t),this.ui_skillitem.SetData(e.id),
this.ui_skillitem.SetIconGray(!1),this.ui_skillitem.SetTipsLabel(""),t<E.s.Inst().GetDivineCoreSkillMaxLv(this.divineId)){
l.j.Inst().GetSkillByIdLevel(this.divineSkillCfg.skillId,t+1)
i=e.desc
const s=E.s.Inst().GetDivineCoreSkillRes(this.divineId,t+1)
this.nextSkillNeedDesc.textSet(s.unlockDesc)}else i=e.desc,this.nextSkillNeedDesc.textSet("")
this.skillLabel.textSet(e.name),this.skillDesc.textSet(i)}UpdateRed(){this.redDot.SetActive(this.codeModel.CheckHasRed(this.divineId,this.selectLocId))}UpdateRightShow(){
this.selectLocId=this.codeModel.GetSelectCodeLocId(),this.divineCoreHoldInfo=this.codeModel.GetDivineCoreHoldInfo(this.divineId,this.selectLocId),
this.selectHolelv=null!=this.divineCoreHoldInfo&&this.divineCoreHoldInfo.level||0
const t=E.s.Inst().GetMaxLocLevel(this.divineId,this.selectLocId)
0==this.selectHolelv?this.state=0:this.selectHolelv<t?this.state=1:this.state=2,this.showhole.SetData(this.divineId,this.selectLocId,!0),
this.selectCodeLocCfg=E.s.Inst().GetDivineCoreRes(this.divineId,this.selectLocId,this.selectHolelv),this.selectCoreSuitCfg=E.s.Inst().GetDivineCoreSuitRes(this.divineId,3)
let e=this.selectCodeLocCfg.name
this.selectHolelv>0?e+=` +${this.selectHolelv}`:e+=" 未激活",this.itemNameLabel.textSet(e),this.UpdateProperty(),this.nowActiveNum=this.codeModel.GetActiveNum(this.divineId),
this.UpdateSuitProperty(),this.UpdateCost(),2==this.state?(this.maxtip.SetActive(!0),this.levelUpBtn.SetActive(!1)):(this.maxtip.SetActive(!1),this.levelUpBtn.SetActive(!0)),
this.UpdateSkill(),this.UpdateRed()}UpdateProperty(){let t=null,e=null
const i=new r.Z
let s=null
if(0!=this.state){if(t=E.s.Inst().GetCodeAttrDic(this.divineId,this.selectLocId,this.selectHolelv),2==this.state){
if(e=E.s.Inst().GetCodeAttrDic(this.divineId,this.selectLocId,this.selectHolelv),null!=e)for(const[t,l]of(0,n.V5)(e))s=new D(t,l,0,!1),i.Add(s)
}else if(e=E.s.Inst().GetCodeAttrDic(this.divineId,this.selectLocId,this.selectHolelv+1),null!=e)for(const[l,a]of(0,n.V5)(e))s=new D(l,t[l],a,!1),i.Add(s)
}else if(e=E.s.Inst().GetCodeAttrDic(this.divineId,this.selectLocId,this.selectHolelv+1),null!=e)for(const[t,l]of(0,n.V5)(e))s=new D(t,l,0,!0),i.Add(s)
const l=i.Count()
for(let t=0;t<=l-1;t++)s.isShowBg=t%2==1
this.propertyGrid.data_set(i)}UpdateSuitProperty(){let t=`${this.selectCoreSuitCfg.name}(`
t+=`${this.nowActiveNum}/${this.maxLoc})`,this.suittext.textSet(t)
const e=E.s.Inst().GetDivineCoreSuitResList(this.divineId),i=e.Count(),s=new r.Z
this.showSuitEff=-1
for(let t=0;t<=i-1;t++){const i=e[t]
let n=p.u.GrayColorStr2
this.nowActiveNum>=i.condition&&(n=p.u.GreenColorStr2,null!=this.oldActiveNum&&this.oldActiveNum<this.nowActiveNum&&this.nowActiveNum==i.condition&&(this.showSuitEff=t)),
s.Add(`${n}激活${C.l.GetChineseNum(i.condition)}件：${i.desc}[-]`)}this.suitgrid.data_set(s),
this.nowActiveNum<this.maxLoc?(this.divinePic.spriteNameSet(this.resPath+this.divineCfg.divineCorePic1),
this.divineLvLabel.textSet("未激活")):(this.divinePic.spriteNameSet(this.resPath+this.divineCfg.divineCorePic2),this.divineLvLabel.textSet(""))}UpdateCost(){if(2!=this.state){
this.costWidget.SetActive(!0)
const t=E.s.Inst().GetCodeConsumeList(this.divineId,this.selectLocId,this.selectHolelv),e=t.Count()
for(let i=0;i<=e-1;i++){const e=t[i]
e.count=u.g.Inst_get().GetItemNum(e.modelId_get())}this.costGrid.data_set(t),0==this.state?this.levelUpBtnLabel.textSet("激 活"):this.levelUpBtnLabel.textSet("进 阶")
}else this.costWidget.SetActive(!1)}OnClickBtn(){if(2!=this.state){const t=this.codeModel.GetLevelUpNeedItem(this.divineId,this.selectLocId,this.selectHolelv)
t>0?(f.y.inst.ClientSysMessage(11040321),d.J.Inst_get().OpenTipViewById(t,_.l.GetWay,c.p.GetWay)):y.J.Inst().Req_CM_DivineCoreLevelUp(this.divineId,this.selectLocId)}}
OnClickTips(){const t=new m.w
t.position=new h.P(-9.4,236,0),t.width=380,t.infoId="DIVINECORE:TIPS",S.Q.Inst_get().Open(t)}}},70997:(t,e,i)=>{i.d(e,{W:()=>r})
var s=i(18998),n=i(83908),l=i(55490),a=i(94295),o=i(47653)
class r extends((0,n.yk)()){constructor(...t){super(...t),this.model=null,this.selectTab=null,this.divineId=null,this.divineVo=null,this.divineStage=null,this.divineCfg=null,
this.resPath="atlas/shengwu/"}InitView(){this.model=o.x.Inst()}AddLis(){this.model.AddEventHandler(a.P.UPDATE_DIVINE_SELECT,this.CreateDelegate(this.SetSelect)),
l.X.Inst().AddEventHandler(a.P.UPDATE_DIVINE_CODE_LOC_RED,this.CreateDelegate(this.UpdateView))}RemoveLis(){
this.model.RemoveEventHandler(a.P.UPDATE_DIVINE_SELECT,this.CreateDelegate(this.SetSelect)),
l.X.Inst().RemoveEventHandler(a.P.UPDATE_DIVINE_CODE_LOC_RED,this.CreateDelegate(this.UpdateView))}Clear(){this.RemoveLis()}Destroy(){}SetData(t){
this.selectTab=o.x.Inst().selectTabIdx,this.UnRegGuide(),this.RemoveLis(),this.AddLis(),this.SetItemClickGo(this.node),this.divineId=t,this.UpdateView(),this.RegGuide()}
RegGuide(){}UnRegGuide(){this.divineId}UpdateView(){const t=this.model.GetSelectDivineId()
if(this.divineVo=this.model.GetDivineVoByDivineId(this.divineId),this.divineStage=this.divineVo.stage,
0==this.divineStage?this.divineCfg=this.model.GetDivineByIdAndStage(this.divineId,1):this.divineCfg=this.model.GetDivineByIdAndStage(this.divineId,this.divineStage),
this.descLabel.textSet(this.divineCfg.name),this.SetSelect(t),this.selectTab==o.x.S_DIVIE_BASE_VIEW_IDX){const t=this.model.redPointData[this.divineId]
this.redDot.SetActive(null!=t&&t.Count()>0)}else if(this.selectTab==o.x.S_DIVIE_CODE_VIEW_IDX){const t=l.X.Inst().redPointData[this.divineId]
this.redDot.SetActive(null!=t&&t.Count()>0)}}SetSelect(t){t==this.divineId?(this.selectPic.SetActive(!0),this.descLabel.SetColor(new s.Color(160,100,71,255)),
this.icon.spriteNameSet(this.resPath+`${this.divineCfg.divinePic}_0`)):(this.selectPic.SetActive(!1),this.descLabel.SetColor(new s.Color(0,0,0,255)),
this.icon.spriteNameSet(this.resPath+`${this.divineCfg.divinePic}_1`))}}},46136:(t,e,i)=>{
var s,n=i(18998),l=i(83908),a=i(18202),o=i(83540),r=i(28192),h=i(48933),d=i(33138),u=i(94295),c=i(47653)
n._decorator.ccclass("DivineLocationItem")(s=class extends((0,l.yk)()){constructor(...t){super(...t),this._m_handlerMgr=null,this.model=null,this.locId=null,this.res=null}
get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=r.h.Get()),this._m_handlerMgr}InitView(){this.model=c.x.Inst()}AddLis(){
this.model.AddEventHandler(u.P.UPDATE_DIVINE_LOC_SELECT,this.CreateDelegate(this.UpdateSelect)),this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.OnClickBtn))}
RemoveLis(){this.model||(this.model=c.x.Inst()),this.model.RemoveEventHandler(u.P.UPDATE_DIVINE_LOC_SELECT,this.CreateDelegate(this.UpdateSelect)),
this.m_handlerMgr.RemoveClickEvent(this.node,this.CreateDelegate(this.OnClickBtn))}Clear(){this.RemoveLis()}Destroy(){}SetData(t,e){this.UnRegGuide(),this.RemoveLis(),
this.AddLis(),this.locId=e
const i=this.model.GetHoleInfoByDivineIdAndLocId(t,e),s=this.model.GetDivineVoByDivineId(t),n=this.model.GetDivineLocResByParam(t,e,i.holeLv,i.holeStage)
this.res=n
const l=d.f.Inst().getItemById(n.showIcon)
a.g.SetItemIcon(this.itemImg,l.icon,o.b.eItem,!1),0==i.holeStage?(this.descLabel.node.parent.SetActive(!1),this.lock.SetActive(!0)):(this.descLabel.node.parent.SetActive(!0),
this.descLabel.textSet(`${i.holeStage}阶`),this.lock.SetActive(!1)),i.holeStage>s.stage?this.activePic.SetActive(!0):this.activePic.SetActive(!1),this.UpdateSelect()
const r=this.model.redPointData[t]
return this.redDot.SetActive(null!=r&&r.IndexOf(e)>=0),this.RegGuide(),!1}RegGuide(){}UnRegGuide(){this.res}SetBgRotation(t){h.I.calVec3.Set(0,0,t),
this.bg.setRotationFromEuler(h.I.calVec3)}UpdateSelect(){const t=this.model.GetSelectLocId()
this.locId==t?this.selectPic.SetActive(!0):this.selectPic.SetActive(!1)}OnClickBtn(){this.model.SetSelectLocId(this.locId)}})},9738:(t,e,i)=>{i.d(e,{E:()=>x})
var s=i(83908),n=i(38836),l=i(18998),a=i(68662),o=i(70829),r=i(5924),h=i(18202),d=i(83540),u=i(28192),c=i(98885),_=i(85602),I=i(38962),m=i(79534),g=i(21554),p=i(63076),C=i(70093),S=i(59686),f=i(53905),y=i(92679),v=i(73423),D=i(65772),E=i(48933),T=i(69846),A=i(33138),L=i(37322),w=i(17756),R=i(79521),O=i(65550),G=i(83263),b=i(94295),M=i(47653)
class P extends((0,s.yk)()){InitView(){}Clear(){}Destroy(){}SetData(t){this.label.textSet(t[0]),this.label2.textSet(t[1])}}var B=i(70997)
class x extends((0,s.Ri)()){constructor(...t){super(...t),this._m_handlerMgr=null,this.divineCList=null,this.locationitemList=null,this.press=null,this.model=null,
this.divineId=null,this.commonEffId=null,this.curLongpressTimes=null,this.longpressTimes=null,this.longpressTime=null,this.isPanelAniEnd=null,this.divineStage=null,
this.effid1=null,this.effid2=null,this.effid3=null,this.delayUpdateSkill=null,this.dalayCallReq=null,this.divineLocationList=null,this.divineVo=null,this.divineCfg=null,
this.modelDisplay=null,this.clickTime=null,this.resPath="atlas/shengwu/"}static __StaticInit(){x.STAGE_ID=130}get m_handlerMgr(){
return this._m_handlerMgr||(this._m_handlerMgr=u.h.Get()),this._m_handlerMgr}InitView(){this.pre_eff_divine01_sj_01.SetActive(!1),this.pre_eff_fruit_eaten_1.SetActive(!1),
this.locationitemList=new _.Z,this.locationitemList.Add(this.ui_divine_location_item),this.locationitemList.Add(this.ui_divine_location_item1),
this.locationitemList.Add(this.ui_divine_location_item2),this.locationitemList.Add(this.ui_divine_location_item3),this.locationitemList.Add(this.ui_divine_location_item4),
this.locationitemList.Add(this.ui_divine_location_item5),
this.press=new L.c(this.cultivateBtn.node,this.CreateDelegate(this.OnClickCultivateBtn),this.CreateDelegate(this.OnPressBtn),null,this.CreateDelegate(this.OnBtn)),
this.press.m_pressingSpan=50,this.skillpropertyGrid.SetInitInfo("ui_divine_attr_item",null,P),
this.grid.SetInitInfo("ui_divine_item",null,B.W,this.CreateDelegate(this.OnClickDivineItem)),this.costGrid.SetInitInfo("ui_ry_forge_materialitem",null,T.R),
this.propertyGrid.SetInitInfo("ui_divine_property_item",null,R.t),this.model=M.x.Inst(),this.divineId=0,this.divineCList=null,this.commonEffId=-1,this.curLongpressTimes=0,
this.longpressTimes=5,this.longpressTime=-1,this.isPanelAniEnd=!1,this.UpdateAnchor()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.modelBoxCollider,this.CreateDelegate(this.OnClickDivine)),
this.m_handlerMgr.AddClickEvent(this.levelUpBtn,this.CreateDelegate(this.OnClickBtn)),this.m_handlerMgr.AddClickEvent(this.tipBtn,this.CreateDelegate(this.OnClickTips)),
this.m_handlerMgr.AddEventMgr(y.g.TabCommonOpenAniEnd,this.CreateDelegate(this.OnPanelAniEnd)),
this.model.AddEventHandler(b.P.UPDATE_DIVINE_LOC_SELECT,this.CreateDelegate(this.UpdateRight)),
this.model.AddEventHandler(b.P.UPDATE_DIVINE_INFO,this.CreateDelegate(this.UpdateDivineInfo)),
this.m_handlerMgr.AddEventMgr(y.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchor))}RemoveLis(){
this.m_handlerMgr.RemoveClickEvent(this.tipBtn,this.CreateDelegate(this.OnClickTips)),
this.m_handlerMgr.RemoveEventMgr(y.g.TabCommonOpenAniEnd,this.CreateDelegate(this.OnPanelAniEnd)),
this.model.RemoveEventHandler(b.P.UPDATE_DIVINE_LOC_SELECT,this.CreateDelegate(this.UpdateRight)),
this.model.RemoveEventHandler(b.P.UPDATE_DIVINE_INFO,this.CreateDelegate(this.UpdateDivineInfo)),
this.m_handlerMgr.RemoveEventMgr(y.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchor))}UpdateAnchor(){}OnPanelAniEnd(){this.isPanelAniEnd=!0,
this.model.GetDivineCanLevelUp(this.divineId,this.divineStage+1)&&this.pre_eff_divine01_sj_01.SetActive(!0)}Clear(){if(this.RemoveLis(),this.grid.Clear(),this.costGrid.Clear(),
this.propertyGrid.Clear(),null!=this.locationitemList)for(let t=0;t<=this.locationitemList.Count()-1;t++)this.locationitemList[t].Clear()
super.Clear()}Destroy(){}SetData(){this.RemoveLis(),this.AddLis(),this.divineCList=this.model.GetDivineList(),this.UpdateLeftList(),this.UpdateSelectView(!0)}UpdateSelectView(t,e){
v.B.Inst().ClearEffect(this.effid1),v.B.Inst().ClearEffect(this.effid2),v.B.Inst().ClearEffect(this.effid3),-1!=this.commonEffId&&(v.B.Inst().ClearEffect(this.commonEffId),
this.commonEffId=-1),null!=this.delayUpdateSkill&&(r.C.Inst_get().ClearInterval(this.delayUpdateSkill),this.delayUpdateSkill=null),this.leveUpEff.SetActive(!1),
this.activeEff.SetActive(!1),this.stageUpEff.SetActive(!1),this.divineStageUpEff.SetActive(!1),this.pre_eff_fruit_eaten_1.SetActive(!1),
this.divineId=this.model.GetSelectDivineId(),this.divineLocationList=this.model.GetDivineLocListByDivineId(this.divineId),
this.divineVo=this.model.GetDivineVoByDivineId(this.divineId),this.divineStage=this.divineVo.stage,
0==this.divineStage?this.divineCfg=this.model.GetDivineByIdAndStage(this.divineId,1):this.divineCfg=this.model.GetDivineByIdAndStage(this.divineId,this.divineStage),
this.UpdateNextTips()
const i=this.model.redPointData[this.divineId]
this.activeRedEff.SetActive(null!=i&&i.IndexOf(0)>=0),this.activePic.SetActive(!0),
this.model.GetDivineCanLevelUp(this.divineId,this.divineStage+1)?this.isPanelAniEnd&&this.pre_eff_divine01_sj_01.SetActive(!0):this.pre_eff_divine01_sj_01.SetActive(!1),
0==this.divineStage?(this.divineLockPic.node.SetActive(!0),this.divineLockPic.spriteNameSet(this.resPath+`${this.divineCfg.divinePic}_3`)):(this.divineLockPic.node.SetActive(!0),
this.divineLockPic.spriteNameSet(this.resPath+`${this.divineCfg.divinePic}_4`)),this.divineLockPic.widthSet(this.divineCfg.picSize[0]),
this.divineLockPic.heightSet(this.divineCfg.picSize[1]),E.I.calVec4.Set(this.divineCfg.picSize[2],this.divineCfg.picSize[3],0),
this.divineLockPic.node.transform.SetLocalPosition(E.I.calVec4),this.ShowModel(),this.ShowLocationItem(),this.UpdateBottom(t,e),this.UpdateRight(),this.RegGuide()}OnBtn(){
this.curLongpressTimes+=1,this.curLongpressTimes<this.longpressTimes||(this.curLongpressTimes=0,this.OnClickCultivateBtn())}UpdateLeftList(){this.divineCList
this.grid.data_set(this.divineCList)}ShowModel(){this.ClearModel(),this.divineStage}ClearModel(){}ShowLocationItem(){const t=this.divineLocationList,e=t.Count()
if(e>1)for(let i=0;i<=this.locationitemList.Count()-1;i++){const s=this.locationitemList[i]
if(i>=e)s.node.SetActive(!1)
else{s.node.SetActive(!0)
const n=t[i]
s.SetData(this.divineId,n)
const l=180*(i/(e-1))-180,a=l*Math.PI/180,o=208.3*Math.cos(a)-64.7,r=65.8+208.3*Math.sin(a)
E.I.calVec0.Set(o,r,0),s.node.transform.SetLocalPosition(E.I.calVec0),s.SetBgRotation(l+180)}}}UpdateBottom(t,e){
t||this.divineStage<=1||!e?this.ui_skillitem.SetData(this.divineCfg.skillId):this.PlaySkillUpdateEff(),this.ui_skillitem.SetEnableToClick((()=>{
G.J.Inst().OpenDivineSkillTips(this.divineCfg.skillId,this.divineCfg)})),0==this.divineStage?(this.ui_skillitem.SetIconGray(!0),
this.ui_skillitem.SetTipsLabel("解封获得")):(this.ui_skillitem.SetIconGray(!1),this.ui_skillitem.SetTipsLabel("")),0==this.divineStage?(this.divineLvLabel.textSet("未解锁"),
this.divineNameLabel.textSet(this.divineCfg.name),
this.skillpropertyGrid.data_set(this.model.GetDivineProperyLabel(this.divineId))):(this.divineLvLabel.textSet(`${this.divineStage}阶`),
this.divineNameLabel.textSet(this.divineCfg.name),this.skillpropertyGrid.data_set(this.model.GetDivineProperyLabel(this.divineId)))}UpdateRight(){
const t=this.model.GetSelectLocId()
0==t?this.divineSelectEff.SetActive(!0):this.divineSelectEff.SetActive(!1)
let e=!1
if(this.locationShow.SetActive(!1),this.divineShow.SetActive(!1),this.ExplainTips.SetActive(!1),this.costWidget.SetActive(!1),this.levelUpBtn.node.SetActive(!1),
this.cultivateBtn.node.SetActive(!1),this.propertyGrid.node.SetActive(!1),this.tipLabel.textSet(""),E.I.calVec3.Set(374,-185.5,0),
this.levelUpBtn.node.transform.SetLocalPosition(E.I.calVec3),t>0){this.locationShow.SetActive(!0)
const i=this.divineVo.holeMap[t],s=i.holeStage,n=i.holeLv,l=n+1,a=this.model.GetDivineLocResByParam(this.divineId,t,n,s),o=A.f.Inst().getItemById(a.showIcon)
h.g.SetItemIcon(this.locationIcon,o.icon,d.b.eItem,!1),e=s>=a.maxStage
const r=new p.M(a.showIcon,null)
let u=a.attrDic,c=null,_=null
this.itemNameLabel.textSet(r.cfgData_get().name),this.lvshow.SetActive(!1),this.stageshow.SetActive(!1),E.I.calVec5.Set(382.3,210.1,0),
this.lvshow.transform.SetLocalPosition(E.I.calVec5),s>0?n>=a.maxLv?e?(E.I.calVec5.Set(456,210,0),this.lvshow.transform.SetLocalPosition(E.I.calVec5),this.maxLv2.textSet(""),
this.lvshow.SetActive(!0),this.fromLv2.textSet(`Lv.${n}`),this.toSp2.SetActive(!1),this.toLv2.textSet(""),this.stageLv2.textSet(`${s}阶`)):(this.stageshow.SetActive(!0),
c=this.model.GetDivineLocResByParam(this.divineId,t,1,s+1),_=c.attrDic,this.fromLv.textSet(`${s}阶`),this.toSp.SetActive(!0),this.toLv.textSet(`${s+1}阶`),
this.costGrid.data_set(this.model.GetBreakConsumeItems(a)),this.levelUpBtnLabel.textSet("突 破"),this.tipLabel.textSet("突破后可继续升级"),E.I.calVec3.Set(374,-185.5,0),
this.levelUpBtn.node.transform.SetLocalPosition(E.I.calVec3),this.costWidget.SetActive(!0),this.levelUpBtn.node.SetActive(!0),this.stageLv2.textSet("")):(this.lvshow.SetActive(!0),
c=this.model.GetDivineLocResByParam(this.divineId,t,n+1,s),_=c.attrDic,this.fromLv2.textSet(`Lv.${n}`),this.toLv2.textSet(`${l} / `),this.maxLv2.textSet(a.maxLv.toString()),
this.toSp2.SetActive(!0),this.costGrid.data_set(this.model.GetUpgradeConsumeItems(a)),this.levelUpBtn.node.SetActive(!1),this.cultivateBtn.node.SetActive(!0),
this.costWidget.SetActive(!0),this.stageLv2.textSet(`${s}阶`)):(this.costWidget.SetActive(!0),c=this.model.GetDivineLocResByParam(this.divineId,t,1,1),_=c.attrDic,u=_,
this.costGrid.data_set(this.model.GetUnLockConsumeItems(a)),this.levelUpBtnLabel.textSet("激 活"),this.levelUpBtn.node.SetActive(!0)),this.propertyGrid.node.SetActive(!0),
this.propertyGrid.data_set(this.GetPropertyData(u,_))}else{const t=new p.M(this.divineCfg.itemId,null)
this.itemNameLabel.textSet(t.cfgData_get().name),e=this.divineStage>=this.divineCfg.maxStage
const i=A.f.Inst().getItemById(this.divineCfg.itemId)
h.g.SetItemIcon(this.divineIcon,i.icon,d.b.eItem,!1),this.divineShow.SetActive(!0)
const s=o.j.Inst().GetSkillByStrId(this.divineCfg.skillId,!1)
if(this.showSkillItem.SetData(this.divineCfg.skillId),this.showSkillItem.SetEnableToClick((()=>{G.J.Inst().OpenDivineSkillTips(this.divineCfg.skillId,this.divineCfg)})),
0==this.divineStage){this.rightSkillNameLabel.textSet("解封后获得技能:"),this.divinefromLv.textSet(""),this.divinetoLv.textSet(""),this.divinetoSp.SetActive(!1),
this.skillDesc.textSet(s.desc),this.skillDesc.node.transform.SetLocalPosition(new l.Vec3(267.1,71.5,0))
const[t,e]=this.model.GetDivineActiveLocNum(this.divineId,this.divineStage+1)
t==e?this.divineTips.textSet(`激活[047104]${t}/${e}[-]个部位可解封圣物`):this.divineTips.textSet(`激活[962424]${t}/${e}[-]个部位可解封圣物`)}else if(this.rightSkillNameLabel.textSet(""),
e)this.divineTips.textSet(""),this.showSkillItem.SetIconGray(!1),this.divinefromLv.textSet(`Lv.${s.level}(已满级)`),
this.divinefromLv.node.transform.SetLocalPosition(new l.Vec3(-73.8,-26.1,0)),this.skillDesc.node.transform.SetLocalPosition(new l.Vec3(267.1,70.1,0)),this.divinetoLv.textSet(""),
this.divinetoSp.SetActive(!1),this.skillDesc.textSet(this.divineCfg.desc)
else{const t=this.model.GetDivineByIdAndStage(this.divineId,this.divineStage+1),e=o.j.Inst().GetSkillByStrId(t.skillId,!1)
this.divinefromLv.textSet(`Lv.${s.level}`),this.divinetoLv.textSet(`Lv.${e.level}`),this.divinetoSp.SetActive(!0),this.skillDesc.textSet(this.divineCfg.desc),
this.levelUpBtnLabel.textSet("圣物升阶"),this.levelUpBtn.node.SetActive(!0),this.tipLabel.textSet(""),
this.model.GetDivineCanLevelUp(this.divineId,this.divineStage+1)?this.divineTips.textSet(`所有部位[047104]${e.level}[-]阶后可升阶`):this.divineTips.textSet(`所有部位[962424]${e.level}[-]阶后可升阶`),
E.I.calVec3.Set(374,-177.2,0),this.levelUpBtn.node.transform.SetLocalPosition(E.I.calVec3),this.divinefromLv.node.transform.SetLocalPosition(new l.Vec3(-64.9,-9,0)),
this.skillDesc.node.transform.SetLocalPosition(new l.Vec3(267.1,129.2,0))}}this.cultivateBtn.node.active?this.press.AddEvent():this.press.RemoveEvent()}UpdateDivineInfo(t){
const e=t[0],i=t[1]
if(i>0){this.UpdateLeftList(),this.UpdateSelectView()
const t=this.model.GetHoleInfoByDivineIdAndLocId(e,i)
1==t.holeStage&&1==t.holeLv?this.PlaySuccess(0):1==t.holeLv?this.PlaySuccess(2):this.PlaySuccess(1)}else{this.model.SetSelectLocId(0),this.UpdateLeftList(),
this.UpdateSelectView(!1,!0)
this.model.GetDivineVoByDivineId(e).stage>1&&this.PlaySuccess(3)}}PlaySuccess(t){this.activeEff.parent.SetActive(!0),0==t?(this.activeEff.SetActive(!1),
this.activeEff.SetActive(!0)):1==t?(this.leveUpEff.SetActive(!1),this.leveUpEff.SetActive(!0)):2==t?(this.stageUpEff.SetActive(!1),
this.stageUpEff.SetActive(!0)):3==t&&(this.divineStageUpEff.SetActive(!1),this.divineStageUpEff.SetActive(!0),
c.M.IsNullOrEmpty(this.divineCfg.desc1)||(this.pre_eff_fruit_eaten_1.SetActive(!1),this.pre_eff_fruit_eaten_1.SetActive(!0))),setTimeout((()=>{this.activeEff.parent.SetActive(!1)
}),1700)}RegGuide(){}UnRegGuide(){}OnClickDivineItem(t,e,i){const s=this.grid.itemList.IndexOf(t),n=this.divineCList[s]
this.model.GetSelectDivineId()!=n&&(this.model.SetSelectDivineId(n),this.model.SetSelectLocId(this.model.GetDefaultLocId(n),!0),
null!=this.dalayCallReq&&(r.C.Inst_get().ClearInterval(this.dalayCallReq),this.dalayCallReq=null),this.UpdateSelectView(),this.UpdateLeftList())}OnClickDivine(){
if(0==this.divineStage)if(this.model.GetDivineCanLevelUp(this.divineId,this.divineStage+1)){if(null!=this.dalayCallReq)return
this.divineLockPic.node.SetActive(!1)
const t=this.divineCfg.activeEff
E.I.calVec5.Set(t[1],t[2],0),this.effPos.transform.SetLocalPosition(E.I.calVec5)
const e=this.effPos.transform.GetLocalPosition();-1!=this.commonEffId&&(v.B.Inst().ClearEffect(this.commonEffId),this.commonEffId=-1),
this.commonEffId=v.B.Inst().PlayEffect(t[0],e,e,1.5,1500),this.dalayCallReq=r.C.Inst_get().SetInterval(this.CreateDelegate(this.Req_CM_DivineActiveDivine2),1400,1)
}else O.y.inst.ClientSysStrMsg(`激活${this.divineLocationList.Count()}个部位可解封圣物`),this.model.SetSelectLocId(0),this.UpdateSelectView()
else this.model.SetSelectLocId(0),this.UpdateSelectView()}Req_CM_DivineActiveDivine(){G.J.Inst().Req_CM_DivineActiveDivine(this.divineId)}Req_CM_DivineActiveDivine2(){
this.dalayCallReq=null,G.J.Inst().Req_CM_DivineActiveDivine(this.divineId)}OnClickBtn(){const t=this.model.GetSelectLocId()
let e=-1
const i=a.D.serverMSTime_get()
if(!(null!=this.clickTime&&i-this.clickTime<500)){if(this.clickTime=i,t>0){
const i=this.divineVo.holeMap[t],s=i.holeStage,n=i.holeLv,l=!1,a=this.model.GetDivineLocResByParam(this.divineId,t,n,s)
s>0?l||(n>=a.maxLv?(e=this.model.GetDivineLocCanBreak(this.divineId,t),0==e&&G.J.Inst().Req_CM_DivineBreakLoc(this.divineId,t)):(e=this.model.GetDivineLocCanLevelUp(this.divineId,t),
0==e&&G.J.Inst().Req_CM_DivineUpgradeLoc(this.divineId,t))):(e=this.model.GetDivineLocCanActive(this.divineId,t),0==e&&G.J.Inst().Req_CM_DivineActiveLoc(this.divineId,t))
}else 0==this.divineStage?G.J.Inst().Req_CM_DivineActiveDivine(this.divineId):this.model.GetDivineCanLevelUp(this.divineId,this.divineStage+1)?G.J.Inst().Req_CM_DivineUpgradeStage(this.divineId):O.y.inst.ClientSysStrMsg(`所有部位${c.M.IntToString(this.divineStage+1)}阶后可升阶`)
e>0&&(O.y.inst.ClientSysStrMsg("道具数量不足"),g.J.Inst_get().OpenTipViewById(e,S.l.GetWay,C.p.GetWay))}}OnClickCultivateBtn(){const t=this.model.GetSelectLocId()
let e=-1
if(t>0){const i=this.divineVo.holeMap[t],s=i.holeStage,n=i.holeLv,l=!1,a=this.model.GetDivineLocResByParam(this.divineId,t,n,s)
s>0&&(l||n>=a.maxLv||(e=this.model.GetDivineLocCanLevelUp(this.divineId,t),0==e&&G.J.Inst().Req_CM_DivineUpgradeLoc(this.divineId,t)))}e>0&&(O.y.inst.ClientSysStrMsg("道具数量不足"),
g.J.Inst_get().OpenTipViewById(e,S.l.GetWay,C.p.GetWay),this.press.RemoveEvent(),this.press.AddEvent())}OnPressBtn(t,e){
e?(-1==this.longpressTime&&(this.longpressTime=a.D.serverMSTime_get()),this.OnBtn(),this.curLongpressTimes=0):(this.curLongpressTimes=0,this.longpressTime=-1)}GetPropertyData(t,e){
const i=new _.Z
null==e&&(e=new I.X)
for(const[s,l]of(0,n.vy)(t)){const n=new w.C
n.type=s,n.value=t[s],null!=e[s]&&(n.differ=e[s]-n.value),n.differ>0?n.isMiddle=!1:n.isMiddle=!0,i.Add(n)}let s=!1
for(let t=0;t<=i.Count()-1;t++)i[t].isShowBg=s,s=!s
return i}PlaySkillUpdateEff(){}DelayUpdateSkillInfo(){(new m.P).Set(37,-37,0),this.ui_skillitem.SetData(this.divineCfg.skillId)}OnClickTips(){const t=new f.w
t.position=new m.P(-9.4,236,0),t.width=380,t.infoId="DIVINE:TIPS",D.Q.Inst_get().Open(t)}UpdateNextTips(){const t=this.divineStage
if(t>0&&t<=this.divineCfg.maxStage)for(let e=t+1;e<=this.divineCfg.maxStage;e++){const t=this.model.GetDivineByIdAndStage(this.divineId,e)
if(!c.M.IsNullOrEmpty(t.desc1)){let i=c.M.ReplaceOne(t.desc1,"{0}","")
return i=c.M.ReplaceOne(i,"{1}",""),void this.nextAttrTips.textSet(`Lv.${e}解锁  ${i}`)}}this.nextAttrTips.textSet("")}}x.STAGE_ID=null},22982:(t,e,i)=>{i.d(e,{D:()=>S})
var s,n=i(6847),l=i(17409),a=i(49655),o=i(46282),r=i(34899),h=i(70829),d=i(98885),u=i(85602),c=i(51262),_=i(85751),I=i(13465),m=i(83263),g=i(55490),p=i(48387),C=i(98043)
let S=(0,n.s_)(a.o.RyDivineCodeSkillTipView,o.Z.ui_ry_divine_skilltipview).layerTip().register()(s=class extends C.k{constructor(...t){super(...t),this.tipsDivineId=null,
this.tipsskillLv=null}InitView(){super.InitView()}Clear(){super.Clear()}Destroy(){super.Destroy()}OnAddToScene(){(0,l.D1)(this,this.CreateDelegate(this.Close)),
this.tipsDivineId=g.X.Inst().tipsDivineId,this.tipsskillLv=g.X.Inst().tipsskillLv
let t=null
0==this.tipsskillLv?(t=p.s.Inst().GetDivineCoreSkillRes(this.tipsDivineId,1),this.skillCfg=h.j.Inst().GetSkillByIdLevel(t.skillId,1)):(t=p.s.Inst().GetDivineCoreSkillRes(this.tipsDivineId,this.tipsskillLv),
this.skillCfg=h.j.Inst().GetSkillByIdLevel(t.skillId,this.tipsskillLv)),this.ui_skillitem.SetData(this.skillCfg.id),this.ui_skillitem.SetLabel(`Lv.${this.skillCfg.level}`),
this.nameLabel.textSet(this.skillCfg.name),this.skillCfg.creatorType==r.z.PASSIVE?this.passiveLabel.textSet("被动技能"):this.passiveLabel.textSet("主动技能")
const e=new u.Z,i=this.skillCfg.skillid,s=new I.N
s.type=I.N.Type_SkillDescByTips,s.colorStr="F5E2D4",s.skillId=i,s.roleInfo=this.roleInfo,s.lineSpriteName="ryskill_sp_0002",s.skillLv=this.skillCfg.level,s.isShowLine=!0,
s.lineHeight=1
const n=new I.N
n.type=I.N.Type_FreeDesc
const a=new c.H,o=p.s.Inst().GetDivineCoreSkillMaxLv(this.tipsDivineId),m=t
for(let t=1;t<=o;t++){const e=h.j.Inst().GetSkillByIdLevel(m.skillId,t)
if(!d.M.IsNullOrEmpty(e.desc)){if(0!=a.Length_get()&&a.Append("\n"),this.tipsskillLv>=t?a.Append("[C4B2A1]"):a.Append("[95968E]"),a.Append(`${t}级  `),this.tipsskillLv>=t){
let t=d.M.ReplaceOne(e.desc,"{0}",_.u.BrightGreenColorStr2)
t=d.M.ReplaceOne(t,"{1}","[-]"),a.Append(t)}else{let t=d.M.ReplaceOne(e.desc,"{0}","")
t=d.M.ReplaceOne(t,"{1}",""),a.Append(t)}a.Append("[-]")}}n.freeStr=a.ToString(),n.colorStr="F5E2D4",n.lineSpriteName="ryskill_sp_0002",n.skillId=i,n.roleInfo=this.roleInfo,
0==this.tipsskillLv?n.skillLv=1:n.skillLv=this.tipsskillLv,n.isShowLine=!1,e.Add(s),e.Add(n),this.skillDescTable.data_set(e),this.skillDescTable.AjustItemPosByItemHeight()}Close(){
m.J.Inst().CloseDivineCodeSkillTips()}})||s},98043:(t,e,i)=>{i.d(e,{k:()=>S})
var s,n=i(6847),l=i(83908),a=i(17409),o=i(49655),r=i(46282),h=i(34899),d=i(70829),u=i(98885),c=i(85602),_=i(51262),I=i(85751),m=i(13465),g=i(6601),p=i(83263),C=i(47653)
let S=(0,n.s_)(o.o.RyDivineSkillTipView,r.Z.ui_ry_divine_skilltipview).layerTip().register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),this.skillCfg=null,
this.roleInfo=null}InitView(){this.skillCfg=null,this.skillDescTable.SetInitInfo("ui_ry_skill_descItem",this.CreateDelegate(this.OnCreateDescItem),g.h),
this.skillDescTable.OnReposition_set(this.CreateDelegate(this.OnRepositonDesc))}OnAddToScene(){(0,a.D1)(this,this.CreateDelegate(this.Close))
const t=C.x.Inst().tipsSkillId
this.skillCfg=d.j.Inst().GetSkillByStrId(t),this.ui_skillitem.SetData(t),this.ui_skillitem.SetLabel(`Lv.${this.skillCfg.level}`),this.nameLabel.textSet(this.skillCfg.name),
this.skillCfg.creatorType==h.z.PASSIVE?this.passiveLabel.textSet("被动技能"):this.passiveLabel.textSet("主动技能")
const e=new c.Z,i=this.skillCfg.skillid,s=new m.N
s.type=m.N.Type_SkillDescByTips,s.colorStr="F5E2D4",s.skillId=i,s.roleInfo=this.roleInfo,s.lineSpriteName="ryskill_sp_0002",s.skillLv=this.skillCfg.level,s.isShowLine=!0,
s.lineHeight=1
const n=new m.N
n.type=m.N.Type_FreeDesc
const l=new _.H,o=C.x.Inst().skillTipsdivineCfg
for(let t=1;t<=o.maxStage;t++){const e=C.x.Inst().GetDivineByIdAndStage(o.divineId,t)
if(!u.M.IsNullOrEmpty(e.desc1)){if(0!=l.Length_get()&&l.Append("\n"),o.stage>=t?l.Append("[C4B2A1]"):l.Append("[95968E]"),l.Append(`${t}级  `),o.stage>=t){
let t=u.M.ReplaceOne(e.desc1,"{0}",I.u.BrightGreenColorStr2)
t=u.M.ReplaceOne(t,"{1}","[-]"),l.Append(t)}else{let t=u.M.ReplaceOne(e.desc1,"{0}","")
t=u.M.ReplaceOne(t,"{1}",""),l.Append(t)}l.Append("[-]")}}n.freeStr=l.ToString(),n.colorStr="F5E2D4",n.lineSpriteName="ryskill_sp_0002",n.skillId=i,n.roleInfo=this.roleInfo,
n.skillLv=this.skillCfg.level,n.isShowLine=!1,e.Add(s),e.Add(n),this.skillDescTable.data_set(e),this.skillDescTable.AjustItemPosByItemHeight()}OnCreateDescItem(t){}
OnRepositonDesc(){}Close(){p.J.Inst().CloseDivineSkillTips()}Clear(){this.ui_skillitem.Clear(),super.Clear()}Destroy(){}Test1(){return!0}S_Test(){return!0}})||s},44200:(t,e,i)=>{
i.d(e,{E:()=>w})
i(32076)
var s=i(38836),n=i(98800),l=i(57121),a=i(50089),o=i(68662),r=i(71530),h=i(62370),d=i(5924),u=i(95721),c=i(35128),_=i(98885),I=i(79534),m=i(89971),g=i(3859),p=i(75321),C=i(48933),S=i(75439),f=i(85079),y=i(38045),v=i(70850),D=i(72208),E=i(18161),T=i(69967),A=i(19519)
class L{constructor(t){if(this._cfgData=null,this._cfgEquipData=null,this._expRewardValue=null,this._dragonsoulCoin=0,this._dragonsoulJiFen=0,this._currenReward=null,
this.valueInfo=null,(0,y.t2)(t,E.e)){const e=t
this._cfgData=v.g.Inst_get().getItemresource(e.itemModelId),"EQUIPMENT"==this._cfgData.itemType&&(this._cfgEquipData=v.g.Inst_get().getEquipResourceCfg(e.itemModelId)),
this.valueInfo=e.valueInfo}else if((0,y.t2)(t,T.A)){const e=t
this._expRewardValue=e.value}else if((0,y.t2)(t,D.L)){const e=t
this.CurrenReward_set(t),this._cfgData=v.g.Inst_get().getItemresource(A.J.GetItemID(e.type))}}ValueInfo_get(){return this.valueInfo}ValueInfo_set(t){this.valueInfo=t}
CurrenReward_get(){return this._currenReward}CurrenReward_set(t){this._currenReward=t}cfgData_get(){return this._cfgData}cfgEquipData_get(){return this._cfgEquipData}
ExpRewardValue_get(){return this._expRewardValue}DragonsoulCoin_get(){return this._dragonsoulCoin}DragonsoulJiFen_get(){return this._dragonsoulJiFen}Quality_get(){
return this._cfgData.quality}Destory(){this._cfgData=null,this._cfgEquipData=null,this._currenReward=null}}class w{constructor(t){this._dInfo=null,this._rewardData=null,
this.m_pickable=!1,this.canDropTime=0,this.enhanceLevel=0,this.star=0,this.luckyLevel=0,this.excellentAttr=null,this.extraAttr=null,this.suitName=null,this.suitProperty=0,
this.excellentNum=-1,this.downTimerId=-1,this.hasPickTime=null,this._dInfo=t,null!=t&&(this.InitData(),t.isNew&&this.InitCanDropTime()),
null==w.ITEM_QUALITY_DICT&&(w.ITEM_QUALITY_DICT=a.t.decode(S.D.getInstance().GetStringValue("DROP:EXCELLENT_ITEM_LIGHT"))),
null==w.EQUIP_QUALITY_DICT&&(w.EQUIP_QUALITY_DICT=a.t.decode(S.D.getInstance().GetStringValue("DROP:EXCELLENT_EUIQP_LIGHT")))}Pickable_get(){return this.m_pickable}Pickable_set(t){
this.m_pickable=t}NewDropItemInfo(t){const e=new f.h
e.objId=t.objId,e.x=t.x,e.y=t.y,e.reward=t.reward,e.isNew=t.isNew,e.ownership=t.ownership,e.protectTime=t.protectTime,e.fromX=t.fromX,e.fromY=t.fromY,e.fromObjectType=0,
e.fromMonsterId=t.fromMonsterId,e.collect=!1,e.collectTime=u.o.ZERO,e.extra=!1,e.isUseCraker=!1,this._dInfo=e,this.InitData(),this._dInfo.isNew&&this.InitCanDropTime()}
InitCanDropTime(){l.M.Inst.initData()
this.canDropTime=o.D.serverMSTime_get()+0,d.C.Inst_get().ClearInterval(this.downTimerId)}AddNeedPick(){this.downTimerId=-1}InitData(){this.GetExcellentAttr(),this.GetExtraAttr(),
this.GetIsLucky(),this.GetEnhanceLevel(),this.GetSuitName(),this.GetStar()}GetSuitName(){this.suitName=""}GetEnhanceLevel(){
if(this.rewardData_get().cfgData_get().itemType==g.q.EQUIPMENT&&null!=this.rewardData_get().ValueInfo_get()){
this.rewardData_get().ValueInfo_get().LuaDic_ContainsKey("enhanceLevel")&&(this.enhanceLevel=_.M.String2Int(this.rewardData_get().ValueInfo_get().enhanceLevel))}}GetStar(){
if(this.rewardData_get().cfgData_get().itemType==g.q.EQUIPMENT&&null!=this.rewardData_get().ValueInfo_get()){
this.rewardData_get().ValueInfo_get().LuaDic_ContainsKey("star")&&(this.star=_.M.String2Int(this.rewardData_get().ValueInfo_get().star))}}GetIsLucky(){
if(this.rewardData_get().cfgData_get().itemType==g.q.EQUIPMENT&&null!=this.rewardData_get().ValueInfo_get()){
if(this.rewardData_get().ValueInfo_get().LuaDic_ContainsKey("criticalHitRate")){const t=this.rewardData_get().ValueInfo_get().criticalHitRate,e=_.M.Split(t,h.o.s_UNDER_CHAR)
this.luckyLevel=_.M.String2Int(e[0])}}}GetExtraAttr(){
this.extraAttr="",this.rewardData_get().cfgData_get().itemType==g.q.EQUIPMENT&&null!=this.rewardData_get().ValueInfo_get()&&(this.extraAttr=this.rewardData_get().ValueInfo_get().LuaDic_GetItem("addLevel"),
null==this.extraAttr&&(this.extraAttr="")),"0"==this.extraAttr&&(this.extraAttr="")}GetExcellentAttr(){this.excellentAttr="",
this.rewardData_get().cfgData_get().itemType==g.q.EQUIPMENT&&null!=this.rewardData_get().ValueInfo_get()&&(this.excellentAttr=this.rewardData_get().ValueInfo_get().LuaDic_GetItem("excellence"),
null==this.excellentAttr&&(this.excellentAttr="")),"0"==this.excellentAttr&&(this.excellentAttr="")}getExcellentNum(){
return-1==this.excellentNum&&(this.excellentNum=this.getExcellentAttrNum()),this.excellentNum}getExcellentAttrNum(){if(_.M.IsNullOrEmpty(this.excellentAttr))return 0
return _.M.Split(this.excellentAttr,_.M.s_CCD_CHAR_DOT).count}dInfo_get(){return this._dInfo}Id_get(){return null==this._dInfo?null:this._dInfo.objId}IsCanPickUp_get(){
if(this._dInfo.isUseCraker&&!this.IsMyDrop_get())return!1
return!(o.D.serverMSTime_get()<this.canDropTime)&&!!this.IsMyDrop_get()}IsMyDrop_get(){if(null==this._dInfo.ownership||0==this._dInfo.ownership.count)return!0
n.Y.Inst.PrimaryRoleInfo_get().Id_get()
for(const[t,e]of(0,s.V5)(this._dInfo.ownership))if(n.Y.Inst.IsMultiPlayer(e))return!0
return!1}GetDistanceForPos(t){return this.GetDistanceForPosXZ(t.x,t.z)}GetDistanceForPosXZ(t,e){return r.A.DistanceFastXZ(t,0,e,this.dInfo_get().x,0,this.dInfo_get().y)}
GetFastDistanceForPos(t){const e=C.I.calVec2
e.Set(this.dInfo_get().x,0,this.dInfo_get().y)
const i=C.I.calVec0
return i.Set(t.x,0,t.z),c.p.FastDistanceVector3D(i,e)}dropPos_get(){return new I.P(this.dInfo_get().x,0,this.dInfo_get().y)}dropPos_getXYZ(){
return[this.dInfo_get().x,0,this.dInfo_get().y]}rewardData_get(){return null==this._rewardData&&(this._rewardData=new L(this._dInfo.reward)),this._rewardData}modelRes_get(){
return this.rewardData_get().cfgData_get().dropModel}modelId(){return this.rewardData_get().cfgData_get().id}GetLightEffectPaht(){
return 0!=this.rewardData_get().cfgData_get().dropLightEffect?this.rewardData_get().cfgData_get().dropLightEffect:null!=this.rewardData_get().cfgEquipData_get()&&p.C.GetEquipEnum(this.rewardData_get().cfgEquipData_get().equipType)!=p.C.WINGS?this.isHideEff(this.rewardData_get().Quality_get())||null==w.EQUIP_QUALITY_DICT[_.M.IntToString(this.rewardData_get().cfgEquipData_get().excellenceNum)]?0:w.EQUIP_QUALITY_DICT[_.M.IntToString(this.rewardData_get().cfgEquipData_get().excellenceNum)]:null!=w.ITEM_QUALITY_DICT[_.M.IntToString(this.rewardData_get().Quality_get())]?w.ITEM_QUALITY_DICT[_.M.IntToString(this.rewardData_get().Quality_get())]:0
}isHideEff(t){const e=n.Y.Inst.PrimaryRoleInfo_get().Level_get()
if(t==m.W.blue){if(l.M.Inst.blueHideLv<0)return!1
if(e>=l.M.Inst.blueHideLv)return!0}else if(t==m.W.yellow){if(l.M.Inst.yellowHideLv<0)return!1
if(e>=l.M.Inst.yellowHideLv)return!0}else if(t==m.W.green)if(this.star>0){if(l.M.Inst.starGreenHideLv<0)return!1
if(e>=l.M.Inst.starGreenHideLv)return!0}else{if(l.M.Inst.noneStarGreenHideLv<0)return!1
if(e>=l.M.Inst.noneStarGreenHideLv)return!0}else if(t==m.W.purple){if(l.M.Inst.purpleHideLv<0)return!1
if(e>=l.M.Inst.purpleHideLv)return!0}else if(t==m.W.red){if(l.M.Inst.redHideLv<0)return!1
if(e>=l.M.Inst.redHideLv)return!0}return!1}getQualityColor(){return this.rewardData_get().Quality_get()}Destory(){this._dInfo.clear(),this._dInfo=null,
null!=this._rewardData&&(this._rewardData.Destory(),this._rewardData=null),this.hasPickTime=null,d.C.Inst_get().ClearInterval(this.downTimerId)}}w.SUITID="suitId",
w.ITEM_QUALITY_DICT=null,w.EQUIP_QUALITY_DICT=null},53131:(t,e,i)=>{i.d(e,{e:()=>u})
var s=i(38836),n=i(42639),l=i(90419),a=i(50089),o=i(85602),r=i(46749),h=i(21106)
class d extends h.v{constructor(...t){super(...t),this.conditionLis=null,this.condition=null}parseCondition(){if(this.conditionLis=new o.Z,null!=this.condition){let t=null
if(""!=this.condition&&"[]"!=this.condition){const e=l.d.parseJsonObjectWithFix(this.condition,"typevalues")
t=a.t.decode(e,r.z),t.Parse(),this.conditionLis=t,this.conditionLis.ParseGameCondition()}}}parse(){this.parseCondition()}GetConditionLis(){return this.conditionLis}}
class u extends n.v{static __StaticInit(){}static CreateCSVEx(){return new u}getNewCSVItem(){return new d}_Load(){super._Load()
const t=this.GetCsvMap()
let e=null
for(const[i,n]of(0,s.vy)(t))e=t.LuaDic_GetItem(i),null!=e&&e.parse()}IsSrcType(){return!1}}},40821:(t,e,i)=>{i.d(e,{p:()=>B})
var s=i(17409),n=i(98800),l=i(5924),a=i(56937),o=i(18202),r=i(31222),h=i(5494),d=i(52726),u=i(37648),c=i(55492),_=i(63945),I=i(8211),m=i(60647),g=i(13487),p=i(19519),C=i(36813),S=i(87223),f=i(52490),y=i(83908),v=i(38045),D=i(61911),E=i(63076),T=i(92984),A=i(86209),L=i(33996),w=i(70202),R=i(65550)
class O extends((0,y.pA)(D.f)()){constructor(...t){super(...t),this.eModel=null,this.v=void 0}InitView(){this.eModel=f.b.Inst_get()}Clear(){this.SendNotRemain(),this.RemoveLis(),
super.Clear()}Destroy(){super.destroy()}OnAddToScene(){this._AddLis(),this.RefreshPanel()}_AddLis(){
this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this._OnCloseClick)),this.m_handlerMgr.AddClickEvent(this.buyBtn,this.CreateDelegate(this._OnBuyClick)),
this.m_handlerMgr.AddClickEvent(this.remind,this.CreateDelegate(this.RemindToggleHandle)),I.N.GetInst().AddEventHandler(L.G.BUY_MALLINFO,this.CreateDelegate(this.BuySuccessHandle))
}RemoveLis(){I.N.GetInst().RemoveEventHandler(L.G.BUY_MALLINFO,this.CreateDelegate(this.BuySuccessHandle)),
this.m_handlerMgr.RemoveClickEvent(this.remind,this.CreateDelegate(this.RemindToggleHandle))}RefreshPanel(){const t=S.C.Inst().GetExpItemId(),e=new E.M(t)
this.item.SetData(e)
const i=S.C.Inst().expMallId
if(null!=i&&0!=i){const t=new w.L(i)
t.Lastnum_set(0)
const e=p.J.GetCurrencyIconUrl(t.Cfg_get().consums.costs[0].subtype)
this.currencyIcon.spriteNameSet(e)
const s=A.w.Instance.ConvertNumToString((0,v.aI)(t.Cfg_get().consums.costs[0].subvalue))
this.currencyTxt.textSet(s)}const s=f.b.Inst_get().GetBuffIdByItemId(t),n=f.b.Inst_get().GetBuffRateByBuffId(s)
this.effTxt.textSet(n/100+1+"倍经验加成")
const l=T.j.Inst_get().model.GetBuffResById(s)
if(null!=l){const t=l.duration/1e3/60
this.time.textSet(`${t}分钟`)}this.v=B.Inst_get().IsNotRemain()
this.node.getChildByPath("isNotRemind/rymainui_bt_0024").SetActive(this.v)}RemindToggleHandle(){}_OnCloseClick(){B.Inst_get().CloseExpDrugView()}_OnBuyClick(){
B.Inst_get().BuyAndUseExpDrug()}BuySuccessHandle(t){null!=t&&t==S.C.Inst().expMallId&&(R.y.inst.ClientSysStrMsg("购买成功，经验加成已经开始生效！"),this.SendNotRemain(),this._OnCloseClick())}
SendNotRemain(){B.Inst_get().SendNotRemain(this.v)}}var G=i(60130),b=i(92679),M=i(61546)
class P extends((0,y.pA)(D.f)()){constructor(...t){super(...t),this.eModel=null,this.hasClick=null,this.pushIntervalTimer=null,this.pushStayTimer=null}InitView(){super.InitView(),
this.eModel=f.b.Inst_get()}Clear(){this.RemoveLis(),this.ClearPushInterval(),this.ClearPushStay(),super.Clear()}Destroy(){super.Destroy()}OnAddToScene(){
G.O.SetAnchorPos(this.widget,!0,!0,-2),this._AddLis(),this.offset.SetActive(!0),this.RefreshPanel()}_AddLis(){
this.m_handlerMgr.AddClickEvent(this.buyBtn,this.CreateDelegate(this._OnBuyClick)),this.m_handlerMgr.AddEventMgr(b.g.ADD_BUFF,this.CreateDelegate(this.UpdateBuff)),
this.m_handlerMgr.AddEventMgr(b.g.REMOVE_BUFF,this.CreateDelegate(this.UpdateBuff)),I.N.GetInst().AddEventHandler(L.G.BUY_MALLINFO,this.CreateDelegate(this.BuySuccessHandle)),
M.X.Inst_get().AddEventHandler(b.g.MULTIPLEHANG_OFF,this.CreateDelegate(this.MultipleExpHangStateChange))}_OnBuyClick(){this.hasClick=!0,
B.Inst_get().IsFirstClick()?(B.Inst_get().OpenExpDrugView(),B.Inst_get().SendFirstClick()):B.Inst_get().IsNotRemain()?B.Inst_get().BuyAndUseExpDrug():B.Inst_get().OpenExpDrugView()
}RemoveLis(){I.N.GetInst().RemoveEventHandler(L.G.BUY_MALLINFO,this.CreateDelegate(this.BuySuccessHandle)),
M.X.Inst_get().RemoveEventHandler(b.g.MULTIPLEHANG_OFF,this.CreateDelegate(this.MultipleExpHangStateChange))}MultipleExpHangStateChange(){this.CloseClick()}RefreshPanel(){
const t=S.C.Inst().pushIntervalTime
this.ClearPushInterval(),this.pushIntervalTimer=l.C.Inst_get().SetInterval(this.CreateDelegate(this.PushHandle),1e3*t,-1)}PushHandle(){if(null==this.pushStayTimer){
this.ClearPushStay()
const t=S.C.Inst().pushStayTime
this.pushStayTimer=l.C.Inst_get().SetInterval(this.CreateDelegate(this.PushStayHandle),1e3*t,1)}}PushStayHandle(){this.hasClick?this.CloseClick():this.offset.SetActive(!1)}
ClearPushStay(){null!=this.pushStayTimer&&(l.C.Inst_get().ClearInterval(this.pushStayTimer),this.pushStayTimer=null)}ClearPushInterval(){
null!=this.pushIntervalTimer&&(l.C.Inst_get().ClearInterval(this.pushIntervalTimer),this.pushIntervalTimer=null)}CloseClick(){B.Inst_get().CloseExpDrugTipView()}UpdateBuff(){
const t=f.b.Inst_get().GetItemVoByType(3)
t.actiontype!=C.y.Better&&t.actiontype!=C.y.InEff||this.offset.SetActive(!1)}BuySuccessHandle(t){null!=t&&t==S.C.Inst().expMallId&&this.offset.SetActive(!1)}}class B{constructor(){
this._degf_CallDestory=null,this._degf_ShowHandler=null,this._degf_ShowExpDrugHandler=null,this._degf_CallExpDrugViewDestory=null,this._degf_ShowExpDrugTipHandler=null,
this._degf_CallExpDrugTipViewDestory=null,this._degf_OpenExpDrugTipView=null,this.expDrugView=null,this.pushCountDownTimer=null,this.expDrugTipView=null,this.EfficiencyControl()}
static Inst_get(){return null==B.inst&&(B.inst=new B),B.inst}get ryefficiencyView(){return(0,s.Y)(h.I.eEfficiencyPanel)}EfficiencyControl(){
this._degf_CallDestory=()=>this.CallDestory(),this._degf_ShowHandler=t=>this.ShowHandler(t),this._degf_ShowExpDrugHandler=t=>this.ShowExpDrugHandler(t),
this._degf_CallExpDrugViewDestory=()=>this.CallExpDrugViewDestory(),this._degf_ShowExpDrugTipHandler=t=>this.ShowExpDrugTipHandler(t),
this._degf_CallExpDrugTipViewDestory=()=>this.CallExpDrugTipViewDestory(),this._degf_OpenExpDrugTipView=()=>this.OpenExpDrugTipView(),this.AddEventLis()}AddEventLis(){}Open(){
const t=new a.v
t.layerType=d.F.MainUI,t.isSelfTween=!1,t.isDefaultUITween=!1,t.isShowMask=!0,r.N.inst.OpenById(h.I.eEfficiencyPanel,this._degf_ShowHandler,this._degf_CallDestory,t)}Close(){
null!=this.ryefficiencyView&&r.N.inst.CloseById(h.I.eEfficiencyPanel)}CallDestory(){r.N.inst.CloseById(h.I.eEfficiencyPanel)}ShowHandler(t){return this.ryefficiencyView}
OpenExpDrugView(){const t=new a.v
t.layerType=d.F.MainUI,t.isSelfTween=!1,t.isDefaultUITween=!1,t.isShowMask=!0,r.N.inst.OpenById(h.I.eEfficiencyExpDrug,this._degf_ShowExpDrugHandler,this._degf_CallExpDrugViewDestory,t)
}CloseExpDrugView(){null!=this.expDrugView&&r.N.inst.CloseById(h.I.eEfficiencyExpDrug)}CallExpDrugViewDestory(){o.g.DestroyUIObj(this.expDrugView),this.expDrugView=null}
ShowExpDrugHandler(t){return null==this.expDrugView&&(this.expDrugView=new O(null),this.expDrugView.setId(t,null,0)),this.expDrugView}MarketBuyReq(t){
null!=this.ryefficiencyView&&this.ryefficiencyView.MarketBuyReq(t)}IsNotRemain(){return 0==m.p.inst.GetClientLogicSetting(g.R.EXP_EFFICIENCY)}SendNotRemain(t){let e=0
t&&(e=1),m.p.inst.SendClientLogicSetting(g.R.EXP_EFFICIENCY,e)}IsFirstClick(){return 0==m.p.inst.GetClientLogicSetting(g.R.EXP_EFFICIENCY_CLICK)}SendFirstClick(){
m.p.inst.SendClientLogicSetting(g.R.EXP_EFFICIENCY_CLICK,1)}BuyAndUseExpDrug(){
const t=S.C.Inst().expMallId,e=n.Y.Inst.PrimaryRoleInfo_get(),i=I.N.GetInst().GetInfo(t),s=i.GetPrice(),l=i.GetCostType()
p.J.GetGold(e,l)<s?_.x.inst.OpenMarketMallAccessView(i,s):null!=t&&0!=t&&_.x.inst.ReqBuyMallItem(t,1,!0)}OpenExpDrugTipView(){const t=f.b.Inst_get().GetItemVoByType(3)
if(t.actiontype==C.y.InEff||t.actiontype==C.y.Better)return
if(null!=this.pushCountDownTimer)return
this.pushCountDownTimer=l.C.Inst_get().SetInterval(this.PushCountDown,3e4,1)
const e=new a.v
e.layerType=d.F.DefaultUI,r.N.inst.OpenById(h.I.eEfficiencyExpDrugTip,this._degf_ShowExpDrugTipHandler,this._degf_CallExpDrugTipViewDestory,e)}ResetData(){
this.ClearPushCountTimer()}PushCountDown(){this.ClearPushCountTimer()}ClearPushCountTimer(){null!=this.pushCountDownTimer&&(l.C.Inst_get().ClearInterval(this.pushCountDownTimer),
this.pushCountDownTimer=null)}CloseExpDrugTipView(){null!=this.expDrugTipView&&r.N.inst.CloseById(h.I.eEfficiencyExpDrugTip)}CallExpDrugTipViewDestory(){
o.g.DestroyUIObj(this.expDrugTipView),this.expDrugTipView=null}ShowExpDrugTipHandler(t){return null==this.expDrugTipView&&(this.expDrugTipView=new P(null),
this.expDrugTipView.setId(t,null,0)),this.expDrugTipView}OpenEfficientTipView(){this.IsCanOpen()&&(this.CloseExpDrugTipView(),this.OpenExpDrugTipView())}IsCanOpen(){
if(u.P.Inst_get().IsFunctionOpened(c.x.EXP_EFFICIENCY)){if(n.Y.Inst.PrimaryRoleInfo_get().Level_get()>=S.C.Inst().expLevel)return!0}}}B.inst=null},36813:(t,e,i)=>{i.d(e,{y:()=>s})
class s{}s.Finish=0,s.Buy=2,s.Learn=3,s.Use=4,s.Best=9,s.NotEff=11,s.Upgrade=6,s.InBag=10,s.InEff=8,s.Better=7},87223:(t,e,i)=>{i.d(e,{C:()=>I})
var s=i(93984),n=i(38836),l=i(86133),a=i(66788),o=i(55360),r=i(98885),h=i(85602),d=i(38962),u=i(70850),c=i(75439),_=i(35037)
class I{constructor(){this._degf_sortByUpRelationShip=null,this._degf_sortType=null,this.map=null,this.typeDic=null,this.allTypeLis=null,this.pushIntervalTime=null,
this.pushStayTime=null,this.expMallId=null,this.expLevel=null,this.betterExpBuffIdLis=null,this.expItemId=null,this.expBuffId=null,
this._degf_sortByUpRelationShip=(t,e)=>this.SortByUpRelationShip(t,e),this._degf_sortType=(t,e)=>this.SortType(t,e),this.map=new d.X
const t=o.Y.Inst.GetOrCreateCsv(s.h.eEfficiencyUpResource)
this.map=t.GetCsvMap(),this.typeDic=new d.X,this.allTypeLis=new h.Z,this.InitTypeLis(),this.InitConfigValue()}static Inst(){return null==I._inst&&(I._inst=new I),I._inst}
InitTypeLis(){for(const[t,e]of(0,n.V5)(this.map)){null==this.typeDic[e.type]&&this.typeDic.LuaDic_AddOrSetItem(e.type,new h.Z)
this.typeDic[e.type].Add(e)}for(const[t,e]of(0,n.vy)(this.typeDic)){e.Sort(this._degf_sortByUpRelationShip),this.allTypeLis.Add(t)}this.allTypeLis.Sort(this._degf_sortType)}
SortByUpRelationShip(t,e){return t.UpRelationship<=e.UpRelationship?t.id-e.id:1}SortType(t,e){return t==e?-1:t-e}InitConfigValue(){
this.pushIntervalTime=c.D.getInstance().GetIntValue("EFFCIENCYUP:INTERVAL"),this.pushStayTime=c.D.getInstance().GetIntValue("EFFCIENCYUP:STAY_TIME"),
this.expMallId=c.D.getInstance().GetIntValue("EFFCIENCYUP:EXP_ITEM"),this.expLevel=c.D.getInstance().GetIntValue("EFFCIENCYUP:UNLOCK_LEVEL_ITEM"),
this.betterExpBuffIdLis=c.D.getInstance().GetIntArray("EFFCIENCYUP:OTHER_EXP_BUFF")}GetExpItemId(){if(null==this.expItemId){const t=_.L.GetInst().GetCfgById(this.expMallId)
this.expItemId=t.itemId}return this.expItemId}GetExpBuffId(){if(null==this.expBuffId){const t=u.g.Inst_get().getItemresource(this.GetExpItemId())
this.expBuffId=r.M.String2Int(t.Rewards_get().typevalues[0].value)}return this.expBuffId}GetItemById(t){if(this.map.LuaDic_ContainsKey(t))return this.map[t]
a.Y.LogError((0,l.T)("efficiencyresource表里不存在id：")+t)}GetItemsByType(t){return this.allTypeLis[t]}}I._inst=null},52490:(t,e,i)=>{i.d(e,{b:()=>y})
var s=i(38836),n=i(98800),l=i(16812),a=i(66788),o=i(98885),r=i(85602),h=i(38962),d=i(44518),u=i(70850),c=i(3859),_=i(92984),I=i(23628),m=i(77477),g=i(42534),p=i(8211),C=i(36813),S=i(87223)
class f{constructor(){this.curRes=null,this.targetRes=null,this.betterBuffId=0,this.actiontype=null,this.playerId=null,this.csvdata=null}}class y extends l.k{constructor(...t){
super(...t),this.expGuardResLis=null,this.diaoestExpGuardRes=null,this.guardInBag=null,this.guardWearing=null}static Inst_get(){return null==y.inst&&(y.inst=new y),y.inst}
GetResInConfig(t,e){const i=S.C.Inst().typeDic
let n=new r.Z
if(null==e)for(const[t,e]of(0,s.vy)(i))n.AddRange(e)
else n=i[e]
if(n)for(let e=0;e<=n.Count()-1;e++){const i=n[e]
if(i.itemId==t)return i}}GetPlayerBestWearExpGuard(t){let e
e=null!=t?new r.Z([t]):n.Y.Inst.primaryRoleInfoList
let i=null
for(let t=0;t<=e.Count()-1;t++){const n=e[t].GetEquipmentsByColumn()
for(const[t,e]of(0,s.V5)(n.equipmentsGet()))if(null!=e&&3==e.GetEquipRes().uniqueType){const t=this.GetResInConfig(e.modelId,1)
null==t||I.b.IsTimeOut(e)||(null==i||i.UpRelationship<t.UpRelationship)&&(i=t)}}return i}IsSatisfyCond(t){let e=!0
const i=t.conditionLis
if(null!=i&&null!=i.typevalues)for(let t=0;t<=i.typevalues.Count()-1;t++){const s=i.typevalues[t].condition
if(null!=s&&!s.CheckCondition()){e=!1
break}}return e}GetBagInConfigByType(t){const e=u.g.Inst_get().GetBagDataList(),i=new h.X
if(null!=e)for(let s=0;s<=e.Count()-1;s++){const n=e[s],l=n.baseData_get()
if(null!=l&&(1==t&&l.cfgData_get().itemType==c.q.EQUIPMENT&&3==l.cfgEquipData_get().uniqueType||3==t&&l.cfgData_get().itemType==c.q.MEDICINE||6==t&&l.cfgData_get().itemType==c.q.USEABLEITEM)&&!i.LuaDic_GetItem(l.modelId_get())){
const e=this.GetResInConfig(l.modelId_get(),t)
null==e||I.b.IsTimeOut(n.serverData_get())||i.LuaDic_AddOrSetItem(l.modelId_get(),e)}}return i}GetBagConfigExpGuard(){const t=u.g.Inst_get().GetBagDataList(),e=new h.X
if(null!=t)for(let i=0;i<=t.Count()-1;i++){const s=t[i].baseData_get()
if(null!=s&&s.cfgData_get().itemType==c.q.EQUIPMENT&&3==s.cfgEquipData_get().uniqueType&&!e.LuaDic_GetItem(s.modelId_get())){const t=this.GetResInConfig(s.modelId_get(),1)
null!=t&&e.LuaDic_AddOrSetItem(s.modelId_get(),t)}}return e}GetBagConfigExpDrug(){const t=u.g.Inst_get().GetBagDataList(),e=new h.X
if(null!=t)for(let i=0;i<=t.Count()-1;i++){const s=t[i].baseData_get()
if(null!=s&&s.cfgData_get().itemType==c.q.MEDICINE&&!e.LuaDic_GetItem(s.modelId_get())){const t=this.GetResInConfig(s.modelId_get(),3)
null!=t&&e.LuaDic_AddOrSetItem(s.modelId_get(),t)}}return e}GetTypeRelationDic(t){const e=new h.X
if(null!=t)for(let i=0;i<=t.Count()-1;i++){const s=t[i],n=s.UpRelationship
null==e[n]&&e.LuaDic_AddOrSetItem(n,new r.Z)
e[n].Add(s)}return e}GetItemVoByType(t,e=null){const i=S.C.Inst().typeDic[t]
if(null==i||i.Count()<=0)return
let l=this.GetBetterItemVo(t)
if(null!=l)return l
l=new f,null==e&&(e=n.Y.Inst.m_primaryRoleInfo),l.playerId=e.Id_get()
const a=this.GetInEffBestRes(t,e)
let o=-1
if(null!=a){o=a.UpRelationship,l.curRes=a,l.actiontype=C.y.InEff
if(i[i.Count()-1].UpRelationship==o)return l}const r=this.GetBagInConfigByType(t)
if(r.LuaDic_Count()>0)for(let t=i.Count()-1;t>=0;t+=-1){const e=i[t]
if(null!=r[e.itemId]&&e.UpRelationship>o&&this.IsSatisfyCond(e))return null==l.curRes?(l.actiontype=C.y.InBag,l.curRes=e):(l.targetRes=e,l.actiontype=C.y.Upgrade),l}
const h=this.GetTypeRelationDic(i)
for(const[t,e]of(0,s.vy)(h))for(let i=0;i<=e.Count()-1;i++){const s=e[i]
if(1==s.isRecommend&&t>o&&this.IsSatisfyCond(s)&&this.IsCanGetByRes(s))return null==l.curRes?(l.actiontype=C.y.NotEff,l.curRes=s):(l.targetRes=s,l.actiontype=C.y.Upgrade),l}
return null!=l.actiontype?l:void 0}GetBetterItemVo(t){let e=null
return 3==t&&(e=this.GetCurBetterBuffItemVo()),e}GetInEffBestRes(t,e){let i=null
return 1==t?i=this.GetPlayerBestWearExpGuard(e):3!=t&&6!=t||(i=this.GetCurBuffRes(t)),i}GetCurBetterBuffItemVo(){
const t=n.Y.Inst.PrimaryRoleInfo_get().Id_get(),e=new f,i=S.C.Inst().betterExpBuffIdLis
let s=0
if(null!=i)for(let e=0;e<=i.Count()-1;e++){const n=i[e]
if(_.j.Inst_get().model.IsHaveBuff(t,n)){s=n
break}}if(0!=s){e.actiontype=C.y.Better,e.betterBuffId=s
const t=this.GetBestBuffRes()
return e.curRes=t,e}return null}GetBestBuffRes(){const t=S.C.Inst().typeDic[3]
if(t.Count()>0)return t[t.Count()-1]}GetCurBestBuffVo(){const t=new f,e=n.Y.Inst.PrimaryRoleInfo_get().Id_get(),i=this.GetBestBuffRes(),s=i.itemId,l=this.GetBuffIdByItemId(s)
if(_.j.Inst_get().model.IsHaveBuff(e,l))return t.curRes=i,t.actiontype=C.y.InEff,t}GetCurBuffRes(t){const e=n.Y.Inst.PrimaryRoleInfo_get().Id_get(),i=S.C.Inst().typeDic[t]
let s=null
if(i.Count()>0)for(let t=0;t<=i.Count()-1;t++){const n=i[t],l=n.itemId,a=this.GetBuffIdByItemId(l)
null!=a&&_.j.Inst_get().model.IsHaveBuff(e,a)&&(null==s||s.UpRelationship<n.UpRelationship)&&(s=n)}return s}GetBuffIdByItemId(t){let e
if(null!=t){const i=u.g.Inst_get().getItemresource(t)
e=o.M.String2Int(i.Rewards_get().typevalues[0].value)}return null==e&&a.Y.LogError(`物品id是${t}的没有对应的buff`),e}GetBuffRateByBuffId(t){let e=0
return null!=t&&(e=_.j.Inst_get().model.GetBuffRate(t)/100),e}IsCanGetByRes(t){const e=t.accessId
if(0==e)return!1
const i=d.F.ins.GetAccessById(e)
let s=!0
if(null==i)return!1
for(let t=0;t<=i.Conditions_Get().Count()-1;t++)if(!i.Conditions_Get()[t].CheckCondition()){s=!1
break}if(!s)return!1
const n=d.F.ins.GetAccessById(e).TargetDefs_Get().tCTargetDefs[0].OpenUI_get()
if(null!=n&&""!=n){const t=this.GetMallByOpenUIStr(n)
if(null!=t&&0!=t){const e=p.N.GetInst().GetInfo(t)
return null!=e&&(-1==e.RemainNum_get()||e.RemainNum_get()>0)}}return!0}GetMallInfoByAccessId(t){if(null==t)return null
const e=d.F.ins.GetAccessById(t)
let i=!0
if(null==e)return null
for(let t=0;t<=e.Conditions_Get().Count()-1;t++)if(!e.Conditions_Get()[t].CheckCondition()){i=!1
break}if(!i)return null
const s=d.F.ins.GetAccessById(t).TargetDefs_Get().tCTargetDefs[0].OpenUI_get()
if(null!=s&&""!=s){const t=this.GetMallByOpenUIStr(s)
if(null!=t&&0!=t){const e=p.N.GetInst().GetInfo(t)
if(null!=e)return e}}}GetGuardAddRateByItemId(t){const e=g.f.Inst().getItemById(t)
let i=e.attrsDic_get()[m.Z.ExpAdd]
const s=e.SpecialAttrsDic_get()
return null==i?0:(null!=s&&s.LuaDic_ContainsKey(m.Z.ExpAdd)&&(i+=s[m.Z.ExpAdd]),i/100)}GetAllExpGuardRate(){const t=n.Y.Inst.primaryRoleInfoList
let e=0
for(let i=0;i<=t.Count()-1;i++){const n=t[i].GetEquipmentsByColumn()
for(const[t,i]of(0,s.V5)(n.equipmentsGet()))if(null!=i&&3==i.GetEquipRes().uniqueType){const t=this.GetResInConfig(i.modelId,1)
null!=t&&(e+=t.enhanceRate)}}return e}IsCanUpgrade(){let t=!0
const e=n.Y.Inst.primaryRoleInfoList
for(let i=0;i<=e.Count()-1;i++){const s=e[i],n=this.GetItemVoByType(1,s)
if(null!=n?n.actiontype!=C.y.InEff&&(t=!1):t=!1,0==t)return t}return t}GetMallByOpenUIStr(t){let e=null
if(!o.M.IsNullOrEmpty(t)){e=o.M.Split(t,o.M.s_CCD_CHAR)
return o.M.String2Int(e[3])}return 0}}y.inst=null},85056:(t,e,i)=>{
var s,n=i(18998),l=i(38836),a=i(25236),o=i(38045),r=i(98800),h=i(97960),d=i(97461),u=i(30849),c=i(38844),_=i(13060),I=i(70123),m=i(21554),g=i(70850),p=i(63076),C=i(75696),S=i(23628),f=i(92679),y=i(33314),v=i(86209),D=i(33138),E=i(63945),T=i(41864),A=i(19519),L=i(36813),w=i(52490)
n._decorator.ccclass("RyEfficiencyGuardRoot")(s=class extends u.C{constructor(...t){super(...t),this.buyBtn=null,this.upgradeBtn=null,this.equipBtn=null,this.upgradeItem=null,
this.upgradeOldTxt=null,this.upgradeNewTxt=null,this.notUpgradeGo=null,this.upgradeGo=null,this.effTxt=null,this.itemName=null,this.priceTxt=null,this.currencyIcon=null,
this.buyGo=null,this.inEff=null,this.item=null,this.cantBuyTxt=null,this.headIcon=null,this.levelTxt=null,this.data=null,this.mallInfo=null,this._degf_RefreshItem=null}InitView(){
this.buyBtn=this.node.getChildByPath("notUpgrade/buyGo/buyBtn").getComponent(_.N),this.upgradeBtn=this.node.getChildByPath("upgrade/upgradeBtn").getComponent(_.N),
this.equipBtn=this.node.getChildByPath("notUpgrade/equipBtn").getComponent(_.N),this.upgradeItem=this.node.getChildByPath("upgrade/ui_baseitem").getCNode(C.j),
this.upgradeOldTxt=this.node.getChildByPath("upgrade/upgradeDesc/upgradeOld").getComponent(n.Label),
this.upgradeNewTxt=this.node.getChildByPath("upgrade/upgradeDesc/upgradeNew").getComponent(n.Label),this.notUpgradeGo=this.node.getChildByPath("notUpgrade"),
this.upgradeGo=this.node.getChildByPath("upgrade"),this.effTxt=this.node.getChildByPath("notUpgrade/effTxt").getComponent(n.RichText),
this.itemName=this.node.getChildByPath("notUpgrade/itemName").getComponent(n.Label),this.priceTxt=this.node.getChildByPath("notUpgrade/buyGo/priceTxt").getComponent(n.RichText),
this.currencyIcon=this.node.getChildByPath("notUpgrade/buyGo/currencyIcon").getComponent(c.E),this.buyGo=this.node.getChildByPath("notUpgrade/buyGo"),
this.inEff=this.node.getChildByPath("notUpgrade/inEff").getComponent(n.Label),this.item=this.node.getChildByPath("ui_baseitem").getCNode(C.j),
this.cantBuyTxt=this.node.getChildByPath("notUpgrade/buyGo/cantBuyTxt").getComponent(n.RichText),this.headIcon=this.node.getChildByPath("headIcon").getComponent(c.E),
this.levelTxt=this.node.getChildByPath("levelTxt").getComponent(n.Label),this._degf_RefreshItem=()=>this.RefreshItem()}Clear(){
r.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandlerRoleGlobal(h.A.LevelUpdate,this.CreateDelegate(this.LevelUpdateHandler)),
r.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandlerRoleGlobal(h.A.Gold_DiamondUpdate,this.CreateDelegate(this.UpdateBuyState)),
d.i.Inst.RemoveEventHandler(f.g.BAG_UPDATE,this._degf_RefreshItem)}Destroy(){}SetData(t){this.data=t
const e=r.Y.Inst.GetPlayerInfoById(this.data.playerId)
this.headIcon.spriteNameSet(y.Z.GetMainUIJobIcon(e.Job_get(),e.Sex_get())),this.AddLis(),this.Refresh()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.buyBtn,this.CreateDelegate(this.OnBuyClick)),this.m_handlerMgr.AddClickEvent(this.upgradeBtn,this.CreateDelegate(this.OnComposeClick)),
this.m_handlerMgr.AddClickEvent(this.equipBtn,this.CreateDelegate(this.OnWearClick)),d.i.Inst.AddEventHandler(f.g.BAG_UPDATE,this._degf_RefreshItem),
r.Y.Inst.PrimaryRoleInfo_get().AddEventHandlerRoleGlobal(h.A.Gold_DiamondUpdate,this.CreateDelegate(this.UpdateBuyState)),
r.Y.Inst.PrimaryRoleInfo_get().AddEventHandlerRoleGlobal(h.A.LevelUpdate,this.CreateDelegate(this.LevelUpdateHandler))}RefreshItem(){
const t=r.Y.Inst.GetPlayerInfoById(this.data.playerId)
this.data=w.b.Inst_get().GetItemVoByType(1,t),this.Refresh()}LevelUpdateHandler(){this.mallInfo=w.b.Inst_get().GetMallInfoByAccessId(this.data.curRes.accessId),
null!=this.mallInfo&&this.data.actiontype==L.y.NotEff&&(this.buyGo.SetActive(!0),this.UpdateBuyState())
const t=r.Y.Inst.m_primaryRoleInfo.Level_get()
this.levelTxt.textSet(T.h.GetLevelStr2(t))}Refresh(){if(this.mallInfo=null,this.upgradeGo.SetActive(!1),this.notUpgradeGo.SetActive(!1),this.buyGo.SetActive(!1),
this.equipBtn.node.SetActive(!1),this.inEff.node.SetActive(!1),null==this.data.curRes)return(0,a.S)("效率提升守护出现错误"),void this.node.SetActive(!1)
const t=this.data.curRes.itemId,e=new p.M(t)
if(this.item.SetData(e),this.data.actiontype==L.y.Upgrade)this.upgradeGo.SetActive(!0),this.UpgradeState()
else{this.LevelUpdateHandler(),this.notUpgradeGo.SetActive(!0),this.data.actiontype==L.y.InEff&&this.inEff.node.SetActive(!0),
this.data.actiontype==L.y.InBag&&this.equipBtn.node.SetActive(!0)
const t=D.f.Inst().getItemById(this.data.curRes.itemId)
this.itemName.textSet(t.name),this.effTxt.textSet(`经验效率: [047104]+${this.data.curRes.enhanceRate/100}%[-]`)}}UpdateBuyState(){const t=this.mallInfo
if(null!=t){t.Lastnum_set(0)
const e=r.Y.Inst.PrimaryRoleInfo_get().Level_get(),i=t.Cfg_get().LevelMinLimit,s=t.IsFree()
let n=0
if(this.currencyIcon.node.SetActive(!1),this.priceTxt.node.SetActive(!1),this.buyBtn.node.SetActive(!1),this.cantBuyTxt.node.SetActive(!1),!s&&e>=i){
this.currencyIcon.node.SetActive(!0)
const e=A.J.GetCurrencyIconUrl(t.Cfg_get().consums.costs[0].subtype)
this.currencyIcon.spriteNameSet(e),n=(0,o.aI)(t.Cfg_get().consums.costs[0].subvalue)}let l=v.w.Instance.ConvertNumToString(n)
s?l="免费":n>A.J.GetGold(r.Y.Inst.PrimaryRoleInfo_get(),A.J.GOLD_DIAMOND)&&(l=`[DE2524]${l}[-]`),e<i?(this.cantBuyTxt.node.SetActive(!0),
this.cantBuyTxt.textSet(`${T.h.GetLevelStr(i)}可购买`)):(this.priceTxt.node.SetActive(!0),this.buyBtn.node.SetActive(!0),this.priceTxt.textSet(l))}}OnBuyClick(){
null!=this.mallInfo&&E.x.inst.ReqMallBuyEquip(this.mallInfo.mallid,this.data.playerId)}OnComposeClick(){if(null==this.data||null==this.data.targetRes)return
null==g.g.Inst_get().GetItemByModleID(this.data.targetRes.itemId)?I.W.ins.GoToAccess(this.data.targetRes.accessId):this.OnWearClick()}OnWearClick(){
if(null==this.data||null==this.data.curRes)return
const t=r.Y.Inst.GetPlayerInfoById(this.data.playerId),e=this.GetUndeprecatedBagItem(this.data.curRes.itemId)
if(null!=e){const i=e.baseData_get()
null!=t&&m.J.Inst_get().RecommendTakeOnEquip(t,i)}else this.RefreshItem()}GetUndeprecatedBagItem(t){const e=g.g.Inst_get().GetBagDataList()
for(const[i,s]of(0,l.V5)(e))if(null!=s.baseData_get()&&s.baseData_get().modelId_get()==t&&!S.b.IsTimeOut(s.serverData_get()))return s
return null}UpgradeState(){if(null==this.data||null==this.data.curRes||null==this.data.targetRes)return
const t=`+${(this.data.targetRes.enhanceRate-this.data.curRes.enhanceRate)/100}%`
this.upgradeNewTxt.textSet(t)
const e=new p.M(this.data.targetRes.itemId)
this.upgradeItem.SetData(e)
if(null!=g.g.Inst_get().GetItemByModleID(this.data.targetRes.itemId))this.upgradeBtn.SetText("立即穿戴")
else{w.b.Inst_get().GetMallInfoByAccessId(this.data.targetRes.accessId)
this.upgradeBtn.SetText("立即提升")}}})},27721:(t,e,i)=>{var s,n=i(18998),l=i(30849),a=i(13060),o=i(21554),r=i(70850),h=i(70202),d=i(40821),u=i(36813)
n._decorator.ccclass("RyEfficiencyHorseRoot")(s=class extends l.C{constructor(...t){super(...t),this.data=null,this.btn_buy=null,this.btn_use=null,this.usingObj=null}InitView(){
this.btn_buy=this.node.getChildByPath("buyGo/buyBtn").getComponent(a.N),this.btn_use=this.node.getChildByPath("useGo/useBtn").getComponent(a.N),
this.usingObj=this.node.getChildByPath("useGo")}Clear(){super.Clear()}Destroy(){super.Destroy()}SetData(t){this.data=t,this.AddList(),this.Refresh()}AddList(){
this.m_handlerMgr.AddClickEvent(this.btn_buy,this.CreateDelegate(this.OnBuyClick)),this.m_handlerMgr.AddClickEvent(this.btn_use,this.CreateDelegate(this.OnUseClick))}Refresh(){
this.btn_buy.node.SetActive(!1),this.btn_use.node.SetActive(!1),this.usingObj.SetActive(!1),this.data.actiontype==u.y.Finish&&this.usingObj.SetActive(!0),
this.data.actiontype==u.y.Buy&&this.btn_buy.node.SetActive(!0),this.data.actiontype==u.y.Use&&this.btn_use.node.SetActive(!0)}OnBuyClick(t,e){
if(null!=this.data.csvdata&&0!=this.data.csvdata.mallId){const t=new h.L(this.data.csvdata.mallId)
t.Lastnum_set(0),d.p.Inst_get().MarketBuyReq(t)}}OnUseClick(t,e){const i=r.g.Inst_get().GetItemByModleID(this.data.csvdata.itemId)
null!=i&&o.J.Inst_get().UseItem(i,!0,null,!1)}})},81705:(t,e,i)=>{i.d(e,{W:()=>a})
var s,n=i(18998),l=i(83908)
let a=n._decorator.ccclass("RyEfficiencyItem")(s=class extends((0,l.zB)()){constructor(...t){super(...t),this.data=null}InitView(){}Clear(){super.Clear()}Destroy(){super.Destroy()}
SetData(t){this._AddLis(),this.data=t,this._RefreshItemView()}_AddLis(){}_RefreshItemView(){this.point_root.node.SetActive(!1),this.guard_root.node.SetActive(!1),
null!=this.data&&null!=this.data.curRes&&(3==this.data.curRes.type?(this.point_root.SetData(this.data),
this.point_root.node.SetActive(!0)):1==this.data.curRes.type?(this.guard_root.SetData(this.data),
this.guard_root.node.SetActive(!0)):6==this.data.curRes.type&&(this.point_root.SetData(this.data),this.point_root.node.SetActive(!0)))}})||s},93093:(t,e,i)=>{
var s,n=i(18998),l=i(98800),a=i(5924),o=i(30849),r=i(13060),h=i(9842),d=i(70123),u=i(21554),c=i(70850),_=i(63076),I=i(75696),m=i(92984),g=i(92679),p=i(87923),C=i(33138),S=i(36813),f=i(52490)
n._decorator.ccclass("RyEfficiencyPotionRoot")(s=class extends o.C{constructor(...t){super(...t),this.buyGo=null,this.betterGo=null,this.inEffGo=null,this.leftTimeTxt=null,
this.timeSlider=null,this.itemName=null,this.effTxt=null,this.item=null,this.buyBtn=null,this.currencyTxt=null,this.currencyIcon=null,this.useBtn=null,this.data=null,
this.datatype=3,this.inforeverGo=null,this.mallInfo=null,this.inEffTimeId=null}InitView(){this.buyGo=this.node.getChildByPath("buyGo"),
this.betterGo=this.node.getChildByPath("betterGo"),this.inEffGo=this.node.getChildByPath("inEffGo"),
this.leftTimeTxt=this.node.getChildByPath("inEffGo/leftTimeTxt").getComponent(n.Label),this.timeSlider=this.node.getChildByPath("inEffGo/yinxiaoSlider").getComponent(h.T),
this.itemName=this.node.getChildByPath("itemName").getComponent(n.Label),this.effTxt=this.node.getChildByPath("effTxt").getComponent(n.RichText),
this.item=this.node.getChildByPath("ui_baseitem").getCNode(I.j),this.buyBtn=this.node.getChildByPath("buyGo/buyBtn").getComponent(r.N),
this.useBtn=this.node.getChildByPath("useGo/useBtn").getComponent(r.N),this.inforeverGo=this.node.getChildByPath("inforeverGo")}Clear(){this.ClearInEffTime(),super.Clear()}
Destroy(){super.Destroy()}SetData(t){this.data=t,this.datatype=t.curRes.type,this.AddLis(),this.Refresh()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.buyBtn,this.CreateDelegate(this.OnBuyClick)),this.m_handlerMgr.AddClickEvent(this.useBtn,this.CreateDelegate(this.OnUseClick)),
this.m_handlerMgr.AddEventMgr(g.g.ADD_BUFF,this.CreateDelegate(this.RefreshItem)),this.m_handlerMgr.AddEventMgr(g.g.REMOVE_BUFF,this.CreateDelegate(this.RefreshItem)),
this.m_handlerMgr.AddEventMgr(g.g.BAG_UPDATE,this.CreateDelegate(this.RefreshItem))}Refresh(){if(this.buyGo.SetActive(!1),this.betterGo.SetActive(!1),this.inEffGo.SetActive(!1),
this.inforeverGo.SetActive(!1),this.useBtn.node.SetActive(!1),null==this.data||null==this.data.curRes)return
const t=f.b.Inst_get().GetBuffIdByItemId(this.data.curRes.itemId)
if(null==t)return
const e=new _.M(this.data.curRes.itemId)
this.item.SetData(e),this.data.actiontype==S.y.Better&&this.betterGo.SetActive(!0),
this.data.actiontype==S.y.InEff||this.data.actiontype==S.y.Upgrade?this.UpdateInEffState(!0):this.UpdateInEffState(!1),this.data.actiontype==S.y.NotEff&&this.buyGo.SetActive(!0),
this.data.actiontype==S.y.InBag&&this.useBtn.node.SetActive(!0)
const i=C.f.Inst().getItemById(this.data.curRes.itemId),s=m.j.Inst_get().model.GetBuffResById(t)
if(null!=s){const t=s.duration
p.l.OneDataFormat2(t/1e3)
this.itemName.textSet(i.name),this.effTxt.textSet(`经验效率: [047104]+${this.data.curRes.enhanceRate/100}%[-]`)}}UpdateInEffState(t){
t?(this.inEffTimeId=a.C.Inst_get().SetInterval(this.CreateDelegate(this.UpdateInEffTime),1e3,-1),this.UpdateInEffTime()):this.ClearInEffTime()}UpdateInEffTime(){
if(null==this.data||null==this.data.curRes)return void this.ClearInEffTime()
const t=f.b.Inst_get().GetBuffIdByItemId(this.data.curRes.itemId)
if(null==t)return void this.ClearInEffTime()
const e=l.Y.Inst.PrimaryRoleInfo_get().Id_get(),i=m.j.Inst_get().model.IsHaveBuff(e,t)
if(i&&-1==i.buffRes_get().duration)return this.inEffGo.SetActive(!1),void this.inforeverGo.SetActive(!0)
if(this.inEffGo.SetActive(!0),null!=i){const t=i.remainTime_get(),e=i.buffRes_get().duration
if(t>0){const i=t/(e/1e3)
this.timeSlider.value=i
const s=p.l.GetDateFormatEX(t,!0,!0)
this.leftTimeTxt.textSet(s)}else this.RefreshItem()}else this.RefreshItem()}ClearInEffTime(){null!=this.inEffTimeId&&(a.C.Inst_get().ClearInterval(this.inEffTimeId),
this.inEffTimeId=null)}RefreshItem(){this.ClearInEffTime(),this.data=f.b.Inst_get().GetItemVoByType(this.datatype,null),this.Refresh()}OnBuyClick(){
d.W.ins.GoToAccess(this.data.curRes.accessId)}OnUseClick(){if(null==this.data||null==this.data.curRes)return
const t=c.g.Inst_get().GetItemByModleID(this.data.curRes.itemId)
null!=t&&u.J.Inst_get().UseItem(t.baseData_get(),!0,null,!1)}})},22760:(t,e,i)=>{
var s,n=i(18998),l=i(6847),a=i(83908),o=i(46282),r=i(77546),h=i(98800),d=i(97960),u=i(97461),c=i(5494),_=i(85602),I=i(79534),m=i(21554),g=i(63076),p=i(92984),C=i(42975),S=i(92679),f=i(63945),y=i(8211),v=i(65550),D=i(40821),E=i(36813),T=i(52490),A=i(61911),L=i(81705)
;(0,l.s_)(c.I.eEfficiencyPanel,o.Z.ui_efficiency_efficiencypanel_ry).waitPrefab([o.Z.ui_baseitem,o.Z.ui_efficiency_efficiencyitem_ry]).register()(s=class extends((0,a.pA)(A.f)()){
constructor(...t){super(...t),this._degf_OpenMarketButTipSpecial=null,this._degf_OpenMarketButTipNormal=null,this.eModel=null,this.mallRes=null,this.curMallRes=null}InitView(){
this.grid.SetInitInfo("ui_efficiency_efficiencyitem_ry",null,L.W),this.drugGrid.SetInitInfo("ui_efficiency_efficiencyitem_ry",null,L.W),
this.grid.OnReposition_set(this.CreateDelegate(this.OnReposition)),this.drugGrid.OnReposition_set(this.CreateDelegate(this.OnReposition)),
this._degf_OpenMarketButTipSpecial=t=>this.OpenMarketButTipSpecial(t),this._degf_OpenMarketButTipNormal=t=>this.OpenMarketButTipNormal(t),this.eModel=T.b.Inst_get()}OnReposition(){
this.scrollview.ResetPosition()}Clear(){p.j.Inst_get().model.RemoveEventHandler(C.E.UPDATE_BUFF_VIEW,this.CreateDelegate(this.RefreshTotalTxt)),
h.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandlerRoleGlobal(d.A.EquipmentsUpdate,this.CreateDelegate(this.RefreshTotalTxt)),
u.i.Inst.RemoveEventHandler(S.g.BAG_UPDATE,this.CreateDelegate(this.RefreshTotalTxt)),super.Clear()}Destroy(){super.Destroy()}OnAddToScene(){this._AddLis(),this.RefreshPanel(),
this.RefreshTotalTxt()
const t=h.Y.Inst.primaryRoleInfoList
for(let e=0;e<=t.Count()-1;e++)if(null!=t[e]){let i=p.j.Inst_get().model.IsHaveBuff(t[e].Id_get(),223)
i?r.s.Info(`${t[e].Id_get().ToString()}  buff 223 存在`):r.s.Info(`${t[e].Id_get().ToString()}buff 223 不存在`),i=p.j.Inst_get().model.IsHaveBuff(t[e].Id_get(),201),
i?r.s.Info(`${t[e].Id_get().ToString()}  buff 201 存在`):r.s.Info(`${t[e].Id_get().ToString()}buff 201 不存在`)}}_AddLis(){
this.btn_close.on(n.NodeEventType.TOUCH_END,this.CreateDelegate(this._OnCloseClick),this),
p.j.Inst_get().model.AddEventHandler(C.E.UPDATE_BUFF_VIEW,this.CreateDelegate(this.RefreshTotalTxt)),
h.Y.Inst.PrimaryRoleInfo_get().AddEventHandlerRoleGlobal(d.A.EquipmentsUpdate,this.CreateDelegate(this.RefreshTotalTxt)),
u.i.Inst.AddEventHandler(S.g.BAG_UPDATE,this.CreateDelegate(this.RefreshTotalTxt))}RefreshPanel(){this.guardGo.SetActive(!1),this.expDrugGo.SetActive(!1)
const t=new _.Z,e=new _.Z
let i=-10
const s=T.b.Inst_get().GetItemVoByType(6)
s?(this.foreverCard.SetData(s),this.foreverCard.SetActive(!0),i-=90):this.foreverCard.SetActive(!1)
const n=h.Y.Inst.primaryRoleInfoList
for(let e=0;e<=n.Count()-1;e++){const i=n[e],s=T.b.Inst_get().GetItemVoByType(1,i)
null!=s&&t.Add(s)}t.Count()>0&&(this.guardGo.SetActive(!0),this.grid.data_set(t),this.guardGo.SetActive(!0),this.guardGo.transform.SetLocalPositionXYZ(-2,i,0),
i=-92*t.Count()+i-15-10)
const l=T.b.Inst_get().GetItemVoByType(3)
null!=l&&e.Add(l),e.Count()>0&&(this.expDrugGo.SetActive(!0),this.drugGrid.data_set(e),this.expDrugGo.SetActive(!0),this.expDrugGo.transform.SetLocalPositionXYZ(-2,i,0),
i=-92*e.Count()+i-15-10),this.scroll_drag.heightSet(10-i),this.scrollview.ResetPosition()}RefreshTotalTxt(){let t=0
const e=T.b.Inst_get().GetAllExpGuardRate(),i=T.b.Inst_get().GetItemVoByType(3)
let s=0
null!=i&&(i.actiontype==E.y.Better?s=p.j.Inst_get().model.GetBuffRate(i.betterBuffId):i.actiontype==E.y.InEff&&(s=i.curRes.enhanceRate))
let l=0
const a=T.b.Inst_get().GetItemVoByType(6)
null!=a&&a.actiontype==E.y.InEff&&(l=a.curRes.enhanceRate),t=e+s+l,this.totalTxt.textSet(t/100+"%"),this.totalWidget.getComponent(n.UITransform).width=this.totalTxt.width()}
_OnCloseClick(){D.p.Inst_get().Close()}MarketBuyReq(t){const e=0!=t.RemainNum_get(),i=t.IsCanBuyWithOtherLimit(),s=new g.M(t.Cfg_get().itemId)
if(s.isShowMask=!0,!e&&i)return void v.y.inst.ClientSysMessage(113003)
y.N.GetInst().selectedMallItemData=this.mallRes,this.curMallRes=t
const n=I.P.zero_get()
"HORSE_SHOW"==s.cfgData_get().sign?i?u.i.Inst.AddEventHandler(S.g.TipsLoadCompelete,this._degf_OpenMarketButTipSpecial):s.tipsPos=n:i&&u.i.Inst.AddEventHandler(S.g.TipsLoadCompelete,this._degf_OpenMarketButTipNormal),
m.J.Inst_get().OpenTipView(s)}OpenMarketButTipSpecial(t){null!=this.curMallRes&&(f.x.inst.OpenMarketMallBuyTip(this.curMallRes,f.x.BuyTipPos),
u.i.Inst.RemoveEventHandler(S.g.TipsLoadCompelete,this._degf_OpenMarketButTipSpecial))}OpenMarketButTipNormal(t){
null!=this.curMallRes&&(f.x.inst.OpenMarketMallBuyTip(this.curMallRes,f.x.BuyTipPos),u.i.Inst.RemoveEventHandler(S.g.TipsLoadCompelete,this._degf_OpenMarketButTipNormal))}})},
62849:(t,e,i)=>{i.d(e,{A:()=>Ot})
var s=i(98800),n=i(97461),l=i(98497),a=i(38935),o=i(5924),r=i(56937),h=i(31222),d=i(5494),u=i(52726),c=i(95721),_=i(38962),I=i(70850),m=i(63076),g=i(92679),p=i(74045),C=i(49067),S=i(87923),f=i(64171),y=i(83907),v=i(42463),D=i(66806),E=i(52732),T=i(8394),A=i(57472),L=i(71447),w=i(95767),R=i(79577),O=i(60591),G=i(81421),b=i(65550),M=i(87530),P=i(64649),B=i(26495),x=i(99294),N=i(9986),k=i(6665),V=i(9776),F=i(93877),U=i(13113),H=i(61911),q=i(61613),Z=i(98885),j=i(85602),X=i(85751),Y=i(75439),W=i(71842),$=i(50600),J=i(38045),z=i(9057),Q=i(72005),K=i(75696),tt=i(18152),et=i(37322)
class it extends z.x{constructor(...t){super(...t),this.baseitem=null,this.remove=null,this.m_pressComp=null,this.time=0,this.ItemType=1,this.space=null,this.Sprite=null,
this.data=null,this.PortData=null}InitView(){super.InitView(),this.baseitem=this.CreateComponentBinder(K.j,1),this.remove=this.CreateComponent(Q.w,2),
this.space=this.CreateComponent(x.z,3),this.Sprite=this.CreateComponent(x.z,4)}Clear(){this.RemoveLis(),super.Clear()}Destroy(){this.baseitem=null,this.remove=null,
this.m_pressComp&&(this.m_pressComp.Destory(),this.m_pressComp=null),super.Destroy()}SetData(t){if(this.AddLis(),this.data=t,!t)return this.baseitem.SetActive(!1),
this.remove.SetActive(!1),this.space.SetActive(!0),void(this.m_pressComp&&this.m_pressComp.Clear())
if(this.baseitem.SetActive(!0),this.remove.SetActive(!0),this.space.SetActive(!1),this.baseitem.EnabledClickOpenTip(!1),1==this.ItemType)this.data.itemdata.count=this.data.count,
this.data.itemdata.SpecialNumStr="",this.baseitem.SetData(this.data.itemdata)
else if(2==this.ItemType){const t=new m.M(this.data.itemdata.modelId_get(),this.data.itemdata.serverData_get())
t.IconType_Set(tt.s.EleCarveItem_Icon_Type),this.data.num>1?t.SpecialNumStr=(0,J.tw)(this.data.num):t.showNum=!1,this.baseitem.SetData(t)
}else if(3==this.ItemType&&(this.PortData=B.p.GetInst().GetNowSubVo(),
null!=this.PortData&&this.PortData.ItemCfg&&this.data.itemdata.modelId_get()==this.PortData.ItemCfg.id&&this.PortData.CarveLvUpCfg.num>0)){const t=new m.M(this.PortData.ItemCfg.id)
t.IconType_Set(tt.s.EleCarveItem_Icon_Type),t.count=this.data.num,this.baseitem.SetData(t)}
B.p.GetInst().IsInSelectItem(this.data)?this.remove.SetActive(!0):(this.remove.SetActive(!1),this.m_pressComp&&this.m_pressComp.Clear())}AddLis(){
null==this.m_pressComp&&(this.m_pressComp=new et.c(this.remove.node,this.CreateDelegate(this.removeClickHandle),null,null,this.CreateDelegate(this.OnLongPress))),
this.m_pressComp.AddEvent(),this.m_handlerMgr.AddClickEvent(this.CreateDelegate(this.SelectClickHandle)),
this.m_handlerMgr.AddClickEvent(this.space,this.CreateDelegate(this.OnSpaceHandle)),
this.m_handlerMgr.AddEventMgr(g.g.EleCarve_SelectChange,this.CreateDelegate(this.SelectChangeHandle)),
this.m_handlerMgr.AddEventMgr(g.g.TipsLoadCompelete,this.CreateDelegate(this.OpenSelectTips))}RemoveLis(){this.m_pressComp&&this.m_pressComp.Clear(),this.m_handlerMgr.Clear()}
SelectClickHandle(){if(this.data){if(1==this.ItemType)B.p.GetInst().m_curSelectedData=this.data,INS.itemTipManager.OpenTipView(this.data.itemdata)
else if(3==this.ItemType&&null!=this.PortData&&this.PortData.CarveLvUpCfg.num>this.data.num){B.p.GetInst().BagType=3
let t=0
const e=B.p.GetInst().GetNowSubVo()
e&&e.elementCarve&&e.elementCarve.modelId>0&&(t=e.elementCarve.modelId),B.p.GetInst().BagId=t,Ot.GetInst().OpenEleCarveBagView()}}else B.p.GetInst().BagType=2,
Ot.GetInst().OpenEleCarveBagView()}OnSpaceHandle(){if(3==this.ItemType){B.p.GetInst().BagType=3
let t=0
const e=B.p.GetInst().GetNowSubVo()
e&&e.elementCarve&&e.elementCarve.modelId>0&&(t=e.elementCarve.modelId),B.p.GetInst().BagId=t,Ot.GetInst().OpenEleCarveBagView()}else B.p.GetInst().BagType=2,
Ot.GetInst().OpenEleCarveBagView()}OpenSelectTips(){1!=B.p.GetInst().BagType&&null!=this.data&&B.p.GetInst().m_curSelectedData==this.data&&Ot.GetInst().OpenEleCarveSelectView()}
removeClickHandle(){B.p.GetInst().RemoveSelectExpItem(this.data)}OnLongPress(){this.removeClickHandle()}SelectChangeHandle(t){
1==this.ItemType&&(t==this.data?this.SetData(t):B.p.GetInst().IsInSelectItem(this.data)?this.remove.SetActive(!0):this.remove.SetActive(!1))}}var st=i(89501),nt=i(8889),lt=i(30849)
class at extends z.x{constructor(...t){super(...t),this.img_bg=null,this.text_content=null,this.Select=null,this.data="",this.PopItemSortSelctType=0}InitView(){super.InitView(),
this.img_bg=this.CreateComponent(Q.w,1),this.text_content=this.CreateComponent(F.Q,2),this.Select=this.CreateComponent(Q.w,3)}Clear(){this.data="",super.Clear()}Destroy(){
this.img_bg=null,this.text_content=null,this.Select=null,super.Destroy()}SetData(t){this.AddLis(),this.data=t,this.text_content.textSet(t),
"品质排序"==t?this.PopItemSortSelctType=0:"等级排序"==t&&(this.PopItemSortSelctType=1),
this.PopItemSortSelctType==B.p.GetInst().PopItemSortSelctType?this.Select.SetActive(!0):this.Select.SetActive(!1)}AddLis(){
this.m_handlerMgr.AddClickEvent(this.img_bg,this.CreateDelegate(this.ClickHandel)),this.m_handlerMgr.AddEventMgr(g.g.EleCarve_PopLisItemClick,this.CreateDelegate(this.Update))}
ClickHandel(){n.i.Inst.RaiseEvent(g.g.EleCarve_PopLisItemClick,this.data)}Update(){
this.PopItemSortSelctType==B.p.GetInst().PopItemSortSelctType?this.Select.SetActive(!0):this.Select.SetActive(!1)}}class ot extends lt.C{constructor(...t){super(...t),
this.img_arrow=null,this.scroll_item=null,this.grid_item=null,this.screen_collider=null,this.text_content=null,this.img_bg=null,this.is_open=!1,this.list_data=null}InitView(){
super.InitView(),this.img_arrow=this.CreateComponent(Q.w,1),this.scroll_item=this.CreateComponent(nt.$,2),this.grid_item=this.CreateComponent(st.N,3),
this.screen_collider=this.CreateComponent(U.T,4),this.text_content=this.CreateComponent(F.Q,5),this.img_bg=this.CreateComponent(Q.w,6),
this.grid_item.SetInitInfo("ui_elecarve_bagview_popitem",null,at)}Clear(){this.RemoveLis(),super.Clear()}Destroy(){this.img_arrow=null,this.scroll_item=null,this.grid_item=null,
this.screen_collider=null,this.text_content=null,this.img_bg=null,super.Destroy()}SetDate(t){this.AddLis(),this.SetListData(t)
const e=B.p.GetInst().PopItemSortSelctType
0==e?this.SetSelct("品质排序"):1==e&&this.SetSelct("等级排序")}SetListData(t){this.list_data=t,this.grid_item.data_set(this.list_data),this.UpdateOpen()}SetSelct(t){
this.text_content.textSet(t)
let e=0
"品质排序"==t?e=0:"等级排序"==t&&(e=1),B.p.GetInst().PopItemSortSelctType!=e&&(B.p.GetInst().PopItemSortSelctType=e,$.a.inst.SetInteger("EleCarvePopItemSortSelctType",e),
n.i.Inst.RaiseEvent(g.g.Element_Enhance_SortTypeChange))}IsOpen_Set(t){this.is_open=t,this.UpdateOpen()}UpdateOpen(){this.scroll_item.node.SetActive(this.is_open),
this.screen_collider.node.SetActive(this.is_open),this.is_open?this.img_arrow.SetLocalEulerAnglesXYZ(0,0,0):this.img_arrow.SetLocalEulerAnglesXYZ(0,0,180)}AddLis(){
this.m_handlerMgr.AddClickEvent(this.img_bg,this.CreateDelegate(this.OnClickBg)),this.m_handlerMgr.AddClickEvent(this.screen_collider,this.CreateDelegate(this.OnClickScreen)),
this.m_handlerMgr.AddEventMgr(g.g.EleCarve_PopLisItemClick,this.CreateDelegate(this.OnSelectItem))}RemoveLis(){this.m_handlerMgr.Clear()}OnClickBg(){this.IsOpen_Set(!this.is_open)}
OnClickScreen(){this.IsOpen_Set(!1)}OnSelectItem(t){this.grid_item.data_get().Contains(t)&&(this.SetSelct(t),this.grid_item.data_set(this.list_data),this.IsOpen_Set(!1))}}
class rt extends H.f{constructor(...t){super(...t),this.anchor=null,this.Unempty=null,this.ScrollView=null,this.MyGrid=null,this.poplis=null,this.sortBtn=null,this.empty=null,
this.AccessGrid=null,this.tips=null,this.sorttype=1}InitView(){super.InitView(),this.anchor=this.CreateComponent(U.T,1),this.Unempty=this.CreateComponent(x.z,2),
this.ScrollView=this.CreateComponent(V.h,3),this.MyGrid=this.CreateComponent(k.A,4),this.poplis=this.CreateComponentBinder(ot,5),this.sortBtn=this.CreateComponent(N.W,6),
this.empty=this.CreateComponent(x.z,7),this.AccessGrid=this.CreateComponent(k.A,8),this.tips=this.CreateComponent(F.Q,9),
this.MyGrid.SetInitInfo("ui_elecarve_bagview_item",null,it),this.AccessGrid.SetInitInfo("ui_access_copydefeat_icon",this.CreateDelegate(this.OnCreateAccessItem))}Clear(){
B.p.GetInst().BagType=1,super.Clear()}Destroy(){this.anchor=null,this.Unempty=null,this.ScrollView=null,this.MyGrid=null,this.poplis=null,this.sortBtn=null,this.empty=null,
this.AccessGrid=null,this.tips=null,super.Destroy()}OnAddToScene(){this.AddLis(),q.v.SetAdaptionPos(this.anchor,174,312,88),B.p.GetInst().UpdateMaxEleCarveScoreGroup(),
this.sorttype=B.p.GetInst().PopItemSortSelctType2,1==this.sorttype?this.sortBtn.normalSpriteSet("ryyuansucuilian_sp_0013"):this.sortBtn.normalSpriteSet("ryyuansucuilian_sp_0014"),
this.poplis.SetDate(new j.Z(["品质排序","等级排序"])),this.UpdateList(),1==B.p.GetInst().BagType?this.tips.textSet("当前没有刻印可以镶嵌"):this.tips.textSet("当前没有材料可以放入")}UpdateList(){
const t=B.p.GetInst().GetBagItemLis(this.sorttype,null,!1)
if(t&&t.Count()>0)this.Unempty.SetActive(!0),this.empty.SetActive(!1),this.MyGrid.data_set(t)
else{this.Unempty.SetActive(!1),this.empty.SetActive(!0)
const t=new j.Z,e=Y.D.getInstance().GetStringValue("ELEMENT:ENHANCE_ACCESS"),i=Z.M.Split(e,",")
for(let e=0;e<=i.Count()-1;e++){const s=Z.M.Split(i[e],"_")
if(s&&s.Count()>=2){const e=new j.Z
e.Add(Z.M.String2Int(s[0])),e.Add(1==Z.M.String2Int(s[1])),t.Add(e)}}this.AccessGrid.data_set(t)}}AddLis(){
this.AddFullScreenCollider(this.node,this.CreateDelegate(this.ClosePanel),null,!0),this.m_handlerMgr.AddClickEvent(this.sortBtn,this.CreateDelegate(this.SortBtnHandle)),
this.m_handlerMgr.AddEventMgr(g.g.EleCarve_PopLisItemClick,this.CreateDelegate(this.UpdateList)),
this.m_handlerMgr.AddEventMgr(g.g.EleCarve_Wear_Update,this.CreateDelegate(this.UpdateList)),
this.m_handlerMgr.AddEventMgr(g.g.ACCESS_ICON_CLICK,this.CreateDelegate(this.ClosePanel))}RemoveLis(){this.RemoveFullScreenCollider(this.node.FatherId),this.m_handlerMgr.Clear()}
SortBtnHandle(){this.sorttype*=-1,$.a.inst.SetInteger("EleCarvePopItemSortSelctType2",this.sorttype),B.p.GetInst().PopItemSortSelctType2=this.sorttype,
1==this.sorttype?this.sortBtn.normalSpriteSet("ryyuansucuilian_sp_0013"):this.sortBtn.normalSpriteSet("ryyuansucuilian_sp_0014"),this.UpdateList()}ClosePanel(){
Ot.GetInst().CloseEleCarveBagView()}OnCreateAccessItem(t){const e=new W.o
return e.IsCopy=!1,e.setId(t,null,0),e.nameTxt.SetColor(X.u.BrightWhiteColor),e}}var ht=i(30267),dt=i(32759)
class ut extends z.x{constructor(...t){super(...t),this.icon=null,this.num=null,this.isSimple=!0}InitView(){super.InitView(),this.icon=this.CreateComponent(Q.w,1),
this.num=this.CreateComponent(F.Q,2)}Clear(){super.Clear()}Destroy(){this.icon=null,this.num=null,super.Destroy()}SetData(t){if(null==t)return void this.SetActive(!1)
const[e,i]=[t[1],t[2]]
if(null==e||e<=0)return void this.SetActive(!1)
this.SetActive(!0)
const s=this.GetIcon(e)
if(this.icon.spriteNameSet(s),this.isSimple)this.num.textSet("")
else{const t=B.p.GetQualityStr(e,!0)
this.num.textSet(`${t}x${i}`)}}GetIcon(t){return 3==t?"ryyuansukeyin_sp_0011":4==t?"ryyuansukeyin_sp_0013":5==t?"ryyuansukeyin_sp_0012":void 0}}class ct extends z.x{
constructor(...t){super(...t),this.Name=null,this.Value=null,this.UpValue=null}InitView(){super.InitView(),this.Name=this.CreateComponent(F.Q,1),
this.UpValue=this.CreateComponent(F.Q,2),this.Value=this.CreateComponent(F.Q,3)}Clear(){super.Clear()}Destroy(){this.Name=null,this.Value=null,this.UpValue=null,super.Destroy()}
SetData(t){const[e,i,s]=[t[1],t[2],t[3]],n=S.l.getAttrStrWithoutSign(e)
let l=""
if(i&&(l=S.l.getAttrValueStr(e,i)),s&&s>0){const t=S.l.getAttrValueStr(e,s)
this.UpValue.SetActive(!0),this.Value.textSet(n+l)
const i=this.Value.width()/2+15
this.UpValue.SetLocalPositionXYZ(i,0,0),this.UpValue.textSet(`(${t}    )`),this.Name.textSet("")}else this.UpValue.SetActive(!1),this.Name.textSet(""),
this.Value.textSet(`${n}  +${l}`)}}class _t extends H.f{constructor(...t){super(...t),this.bgtype=null,this.iconbg=null,this.icon=null,this.UItable=null,this.active=null,
this.attr=null,this.skill=null,this.skillTips=null,this.name=null,this.stage=null,this.closetime=null,this.activeable=null,this.attrtable=null,this.tablebg=null,this.norobj=null,
this.tween=null,this.tweeniconbg=null,this.tweenicon=null,this.tweemtime=null}InitView(){super.InitView(),this.bgtype=this.CreateComponent(Q.w,1),
this.iconbg=this.CreateComponent(Q.w,2),this.icon=this.CreateComponent(Q.w,3),this.UItable=this.CreateComponent(ht.V,4),this.active=this.CreateComponent(x.z,5),
this.attr=this.CreateComponent(x.z,6),this.skill=this.CreateComponent(x.z,7),this.skillTips=this.CreateComponent(F.Q,8),this.name=this.CreateComponent(F.Q,9),
this.stage=this.CreateComponent(F.Q,10),this.closetime=this.CreateComponent(F.Q,11),this.activeable=this.CreateComponent(ht.V,12),this.attrtable=this.CreateComponent(ht.V,13),
this.tablebg=this.CreateComponent(Q.w,14),this.norobj=this.CreateComponent(x.z,15),this.tween=this.CreateComponent(dt.c,16),this.tweeniconbg=this.CreateComponent(Q.w,17),
this.tweenicon=this.CreateComponent(Q.w,18),this.activeable.SetInitInfo("ui_elecarve_echosimple_point",this.CreateDelegate(this.CreateItem)),
this.attrtable.SetInitInfo("ui_elecarve_echoupattr",this.CreateDelegate(this.CreateItem1))}Clear(){this.RemoveFullScreenCollider(this.FatherId),super.Clear()}Destroy(){
this.bgtype=null,this.iconbg=null,this.icon=null,this.UItable=null,this.active=null,this.attr=null,this.skill=null,this.skillTips=null,this.name=null,this.stage=null,
this.closetime=null,this.activeable=null,this.attrtable=null,this.tablebg=null,this.norobj=null,this.tween=null,this.tweeniconbg=null,this.tweenicon=null,super.Destroy()}
OnAddToScene(){this.AddFullScreenCollider(this.node,this.CreateDelegate(this.PlayTween))
let t=0
const e=B.p.GetInst().OldEchoCfg,i=B.p.GetInst().NewEchoCfg
let s=!1
if(null!=i&&(null!=e?i.name!=e.name&&(s=!0):s=!0),this.name.textSet(i.name),this.stage.textSet(`(${i.echoLevel}阶)`),this.iconbg.spriteNameSet(i.icon1),
this.icon.spriteNameSet(i.icon2),this.tweeniconbg.spriteNameSet(i.icon1),this.tweenicon.spriteNameSet(i.icon2),this.norobj.SetActive(!0),this.tween.SetActive(!1),
this.tween.SetLocalPositionXYZ(0,0,0),s){this.bgtype.spriteNameSet("ryyuansukeyin_sp_0003"),this.active.SetActive(!0),this.activeable.SetLocalPositionXYZ(1.1,-21,0),t-=23
const e=new j.Z,s=i.EchoGroupSortList
for(let t=0;t<=s.Count()-1;t++)e.Add([s[t],i.EchoGroupDic[s[t]]])
this.activeable.data_set(e),t=t-25*e.Count()-10,this.attr.SetLocalPositionXYZ(0,t,0)
const n=new j.Z,l=i.GetAddValueLis()
for(let t=0;t<=l.Count()-1;t++){let e=0,i=0
const s=0
e=l[t].intType,i=l[t].value,n.Add([e,i,s])}this.attrtable.data_set(n),t-=20*n.Count(),this.skill.SetLocalPositionXYZ(0,t,0),
S.l.IsEmptyStr(i.desc)?this.skill.SetActive(!1):(this.skill.SetActive(!0),this.skillTips.textSet(i.desc)),t-=this.skillTips.height()}else{
this.bgtype.spriteNameSet("ryyuansukeyin_sp_0002"),this.active.SetActive(!1),this.attr.SetLocalPositionXYZ(0,0,0),t-=23
const s=new j.Z,n=i.GetAddValueLis(),l=e.GetAddValueDic()
for(let t=0;t<=n.Count()-1;t++){let e=0,i=0,a=0
e=n[t].intType,i=n[t].value,a=n[t].value-l[e],s.Add([e,i,a])}this.attrtable.data_set(s),t-=20*s.Count(),this.skill.SetLocalPositionXYZ(0,t,0),
S.l.IsEmptyStr(i.desc)?this.skill.SetActive(!1):(this.skill.SetActive(!0),this.skillTips.textSet(i.desc)),t-=this.skillTips.height()}this.tablebg.SetLocalPositionXYZ(0,0,0),
this.tablebg.heightSet(Math.abs(t)),this.activeable.Reposition(),this.attrtable.Reposition()}PlayTween(){null==this.tweemtime&&(this.norobj.SetActive(!1),this.tween.SetActive(!0),
this.tween.PlayForward(),this.tweemtime=this.m_handlerMgr.SetInterval(this.CreateDelegate(this.OnClose),450))}OnClose(){this.m_handlerMgr.ClearInterval(this.tweemtime),
this.tweemtime=null,Ot.GetInst().CloseEleCarveEchoUpView()}CreateItem(t){const e=new ut
return e.setId(t,null,0),e.isSimple=!1,e}CreateItem1(t){const e=new ct
return e.setId(t,null,0),e.isSimple=!1,e}}class It extends z.x{constructor(...t){super(...t),this.Name=null,this.Value=null,this.bg=null}InitView(){super.InitView(),
this.Name=this.CreateComponent(F.Q,1),this.Value=this.CreateComponent(F.Q,2),this.bg=this.CreateComponent(x.z,3)}Clear(){super.Clear()}Destroy(){this.Name=null,this.Value=null,
this.bg=null,super.Destroy()}SetData(t){const e=S.l.getAttrStrWithoutSign(t.intType),i=S.l.getAttrValueStr(t.intType,t.value)
this.Name.textSet(e),this.Value.textSet(`+${i}`),null!=this.bg&&this.bg.SetActive(this.index%2==0)}}class mt extends z.x{constructor(...t){super(...t),this.name=null,
this.Equiping=null,this.icon=null,this.active=null,this.attr=null,this.activegrid=null,this.attrstr=null,this.attrgrid=null,this.simple_point1=null,this.simple_point2=null,
this.simple_point3=null,this.iconbg=null,this.SimplePointLis=null,this.data=null}InitView(){super.InitView(),this.name=this.CreateComponent(F.Q,1),
this.Equiping=this.CreateComponent(Q.w,2),this.icon=this.CreateComponent(Q.w,3),this.active=this.CreateComponent(x.z,4),this.attr=this.CreateComponent(x.z,5),
this.activegrid=this.CreateComponent(k.A,6),this.attrstr=this.CreateComponent(F.Q,7),this.attrgrid=this.CreateComponent(k.A,8),this.simple_point1=this.CreateComponentBinder(ut,12),
this.simple_point2=this.CreateComponentBinder(ut,13),this.simple_point3=this.CreateComponentBinder(ut,14),this.iconbg=this.CreateComponent(Q.w,15),
this.SimplePointLis=new j.Z([this.simple_point1,this.simple_point2,this.simple_point3]),this.attrgrid.SetInitInfo("ui_elecarve_echoattritem",null,It)}Clear(){
for(let t=0;t<=this.SimplePointLis.Count()-1;t++)this.SimplePointLis[t].Clear()
super.Clear()}Destroy(){this.name=null,this.Equiping=null,this.icon=null,this.active=null,this.attr=null,this.activegrid=null,this.attrstr=null,this.attrgrid=null,
this.simple_point1=null,this.simple_point2=null,this.simple_point3=null,this.iconbg=null,super.Destroy()}SetData(t){this.data=t
for(let t=0;t<=this.SimplePointLis.Count()-1;t++)this.data.EchoGroupLis[t]?this.SimplePointLis[t].SetData([this.data.EchoGroupLis[t],1]):this.SimplePointLis[t].SetData()
this.activegrid.Reposition(!1)
const e=this.data.GetAddValueLis()
this.attrgrid.data_set(e),this.name.textSet(this.data.name),this.iconbg.spriteNameSet(this.data.icon1),this.icon.spriteNameSet(this.data.icon2),this.Equiping.SetActive(!1)}Test1(){
this.SetData(this.data)}}class gt extends H.f{constructor(...t){super(...t),this.closeBtn=null,this.Scrollview=null,this.EchoGrid=null,this.ScrollviewPanel=null,this.data=null,
this.cfg=null,this.roleInfo=null}InitView(){super.InitView(),this.closeBtn=this.CreateComponent(N.W,1),this.Scrollview=this.CreateComponent(V.h,2),
this.EchoGrid=this.CreateComponent(k.A,3),this.ScrollviewPanel=this.CreateComponent(nt.$,4),this.EchoGrid.SetInitInfo("ui_elecarve_echoitem",null,mt),
this.EchoGrid.OnReposition_set(this.CreateDelegate(this.OnEchoReposition))}Clear(){super.Clear()}Destroy(){this.closeBtn=null,this.Scrollview=null,this.EchoGrid=null,
this.ScrollviewPanel=null,super.Destroy()}OnAddToScene(){if(this.AddLis(),this.data=B.p.GetInst().GetNowShowVo(),this.roleInfo=P.$.Inst().GetSelectRoleInfo(),this.roleInfo){
const t=B.p.GetInst().GetReCommonEchoType(this.data,this.roleInfo.Job_get())
this.EchoGrid.data_set(t)}}AddLis(){this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.OnClose))}OnClose(){Ot.GetInst().CloseEchoView()}OnEchoReposition(){
const t=B.p.GetInst().GetPreReCommonEchoType(this.data,this.roleInfo.Job_get()),e=this.EchoGrid.itemList
for(let i=0;i<=e.Count()-1;i++){let s=""
e[i].data.EchoGroupType==this.data.GetEchoType()?s="ryyuansukeyin_sp_0005":t.Contains(e[i].data)&&(s="ryyuansukeyin_sp_0004"),
""==s?e[i].Equiping.SetActive(!1):(e[i].Equiping.SetActive(!0),e[i].Equiping.spriteNameSet(s))}}}var pt=i(38836),Ct=i(86290),St=i(52212),ft=i(21554),yt=i(69015),vt=i(93078)
class Dt extends H.f{constructor(...t){super(...t),this.countLabel=null,this.singleExp=null,this.totalExp=null,this.addButton=null,this.leftButton=null,this.AddBtn=null,
this.offset=null,this.noLimitObj=null,this.maxBtn=null,this.data=null,this.curCount=1,this.maxCount=99,this.SelectBtn=null,this.bagtype2=null,this.bagtype3=null,this.needstr=null,
this.tipIndex=null}InitView(){super.InitView(),this.countLabel=this.CreateComponent(F.Q,1),this.singleExp=this.CreateComponent(F.Q,2),this.totalExp=this.CreateComponent(F.Q,3),
this.addButton=this.CreateComponent(N.W,4),this.leftButton=this.CreateComponent(N.W,5),this.SelectBtn=this.CreateComponent(N.W,6),this.offset=this.CreateComponent(Ct.G,7),
this.maxBtn=this.CreateComponent(N.W,8),this.bagtype2=this.CreateComponent(x.z,9),this.bagtype3=this.CreateComponent(x.z,10),this.needstr=this.CreateComponent(F.Q,11)}Clear(){
vt.F.Instance_get().CloseView(),null!=this.tipIndex&&(yt.g.Inst_get().RemoveByTip(),this.tipIndex=null),this.curCount=1,super.Clear()}Destroy(){this.countLabel=null,
this.singleExp=null,this.totalExp=null,this.addButton=null,this.leftButton=null,this.AddBtn=null,this.offset=null,this.noLimitObj=null,this.maxBtn=null,super.Destroy()}
OnAddToScene(){this.AddLis(),this.data=B.p.GetInst().m_curSelectedData
const t=this.data.itemdata.serverData_get()
if(t&&t.totalExp.ToNum()>0?this.singleExp.textSet(B.p.GetInst().GetItemExp(this.data.itemdata.modelId_get())+t.totalExp.ToNum()):this.singleExp.textSet(B.p.GetInst().GetItemExp(this.data.itemdata.modelId_get())),
this.maxCount=this.data.count-this.data.num,3==B.p.GetInst().BagType){this.bagtype2.SetActive(!1),this.bagtype3.SetActive(!0)
const t=B.p.GetInst().GetNowSubVo()
if(null!=t&&t.ItemCfg&&this.data.itemdata.modelId_get()==t.ItemCfg.id&&t.CarveLvUpCfg.num>0){let e=0
if(B.p.GetInst().SelectDic.Count()>0)for(const[t,i]of(0,pt.V5)(B.p.GetInst().SelectDic))e+=i.num
this.maxCount>t.CarveLvUpCfg.num-e&&(this.maxCount=t.CarveLvUpCfg.num-e),this.SetCount(this.maxCount),
this.needstr.textSet(`${this.data.itemdata.GetNameStr(!0)} (${e}/${t.CarveLvUpCfg.num})`)}}else this.bagtype2.SetActive(!0),this.bagtype3.SetActive(!1),this.SetCount(1)
this.tipIndex=this.AddToLayout()}AddToLayout(){const[t,e]=[0,140.6],[i,s]=[325,267]
return yt.g.Inst_get().AddTipByParam(null,yt.g.HorizontalAlign.Right,yt.g.VerticalAlign.Down,new St.F(t,e),new St.F(i,s))}SetCount(t){t<=1&&(t=1),
t>=this.maxCount&&(t=this.maxCount),this.curCount=t,this.countLabel.textSet(Z.M.IntToString(t))
const e=this.data.itemdata.serverData_get()
e&&e.totalExp.ToNum()>0?this.totalExp.textSet(this.curCount*(B.p.GetInst().GetItemExp(this.data.itemdata.modelId_get())+e.totalExp.ToNum())):this.totalExp.textSet(this.curCount*B.p.GetInst().GetItemExp(this.data.itemdata.modelId_get()))
}AddLis(){this.m_handlerMgr.AddClickEvent(this.addButton,this.CreateDelegate(this.OnaddBtnClick)),
this.m_handlerMgr.AddClickEvent(this.leftButton,this.CreateDelegate(this.OnleftButtonClick)),
this.m_handlerMgr.AddClickEvent(this.countLabel,this.CreateDelegate(this.OncountLabelClick)),this.m_handlerMgr.AddClickEvent(this.SelectBtn,this.CreateDelegate(this.OnSelectBtn)),
this.m_handlerMgr.AddClickEvent(this.maxBtn,this.CreateDelegate(this.OnmaxBtn)),this.m_handlerMgr.AddEventMgr(g.g.BASE_TIP_CLOSE,this.CreateDelegate(this.OnCloseHandler))}
OnCloseHandler(){Ot.GetInst().CloseEleCarveSelectView()}OnSelectBtn(){const t=this.data.itemdata.serverData_get()
if(t&&t.level>0){const t=new C.B
t.infoId="ELEMENT_CARVE:TIPS1",t.cancelHandle=this.OnSelectBtnLater,t.cancelParam=[this.data,this.curCount],t.cancelText="直接放入",t.confirmHandle=this.OnSelectBtnLater2,
t.confirmParam=[this.data.itemdata,!1],t.confirmText="立即重置",t.replaceParams.Add(this.data.itemdata.GetItemNameStr(!1)),p.t.Inst().Open(t)
}else this.OnSelectBtnLater([this.data,this.curCount])
ft.J.Inst_get().CloseTipView()}OnSelectBtnLater(t){0!=t[2]?(B.p.GetInst().AddSelectExpItem(t[1],t[2]),Ot.GetInst().CloseEleCarveSelectView()):b.y.inst.ClientSysMessage(11043404)}
OnSelectBtnLater2(t){Ot.GetInst().TryLevelReset(t[1],t[2]),Ot.GetInst().CloseEleCarveSelectView()}OnaddBtnClick(){this.SetCount(this.curCount+1)}OnleftButtonClick(){
this.SetCount(this.curCount-1)}OncountLabelClick(){const t=this.addButton.GetPosition()
t.y-=.3,t.x-=.1,vt.F.Instance_get().OpenView(null,this.CreateDelegate(this.AddHandler),null,t)}AddHandler(t,e){10==t?this.curCount=1:e?this.curCount=t:(this.curCount*=10,
this.curCount+=t),this.curCount<=1&&(this.curCount=1),this.curCount=Math.min(this.curCount,this.maxCount),this.SetCount(this.curCount)}OnmaxBtn(){this.SetCount(this.maxCount)}}
var Et=i(21729)
class Tt extends H.f{constructor(...t){super(...t),this.data=null,this.iswer=!1,this.closebtn=null,this.closebtb2=null,this.GoReSet=null,this.tips=null,this.NowLv=null,
this.NowStage=null,this.grid_item=null,this.ReSetTips=null,this.ReSetTipsSp=null}InitView(){super.InitView(),this.closebtn=this.CreateComponent(N.W,1),
this.closebtb2=this.CreateComponent(N.W,2),this.GoReSet=this.CreateComponent(N.W,3),this.tips=this.CreateComponent(F.Q,4),this.NowLv=this.CreateComponent(F.Q,5),
this.NowStage=this.CreateComponent(F.Q,6),this.grid_item=this.CreateComponent(st.N,7),this.ReSetTips=this.CreateComponent(F.Q,8),this.ReSetTipsSp=this.CreateComponent(Q.w,9),
this.grid_item.SetInitInfo("ui_baseitem",null,K.j)}Clear(){super.Clear()}Destroy(){super.Destroy()}OnAddToScene(){
this.m_handlerMgr.AddClickEvent(this.closebtn,this.CreateDelegate(this.OnClose)),this.m_handlerMgr.AddClickEvent(this.closebtb2,this.CreateDelegate(this.OnClose)),
this.m_handlerMgr.AddClickEvent(this.GoReSet,this.CreateDelegate(this.OnReSet)),this.data=B.p.GetInst().ReSetInfo,this.iswer=B.p.GetInst().iswer
const t=this.data.serverData_get()
if(this.tips.textSet(`是否立即将${this.data.GetItemNameStr(!1)}的等级无损重置为0级？`),t){this.NowStage.textSet(`${t.stage}阶`),this.NowLv.textSet(`Lv.${t.level}`)
const e=t.totalExp.ToNum(),i=this.GetExpShowLis(e)
if(t.consumeItems.Count()>0)for(const[e,s]of(0,pt.V5)(t.consumeItems)){const t=new m.M(e)
t.count=s,t.isShowZeroNum=!0,i.Add(t)}this.grid_item.data_set(i)}const e=Y.D.getInstance().GetIntValue("ELEMENT_CARVING:RESET_COST")
this.ReSetTips.textSet(`重 置（${e}    ）`),this.ReSetTipsSp.UpdateAnchors()}GetExpShowLis(t){
const e=B.p.GetInst().ExpSortLis,i=B.p.GetInst().ExpItemDic,s=B.p.GetInst().MixexpItemExp,n=new _.X,l=new j.Z
for(let l=0;l<=e.Count()-1;l++){if(t>=i[e[l]]){const s=Et.N.Floor(t/i[e[l]])
s>0&&(t-=s*i[e[l]],n[e[l]]=s)}if(t<s)break}for(const[t,e]of(0,pt.V5)(n)){const i=new m.M(t)
i.count=e,i.isShowZeroNum=!0,l.Add(i)}return l}OnClose(){Ot.GetInst().CloseEleCarveReSetView()}OnReSet(){Ot.GetInst().Req_CM_ElementCarveLevelReset(this.data,this.iswer),
Ot.GetInst().CloseEleCarveReSetView()}}var At=i(37828),Lt=i(33138)
class wt extends z.x{constructor(...t){super(...t),this.Name=null,this.Value=null,this.UpValue=null}InitView(){super.InitView(),this.Name=this.CreateComponent(F.Q,1),
this.UpValue=this.CreateComponent(F.Q,2),this.Value=this.CreateComponent(F.Q,3)}Clear(){super.Clear()}Destroy(){this.Name=null,this.Value=null,this.UpValue=null,super.Destroy()}
SetData(t){const[e,i,s]=[t[1],t[2],t[3]],n=S.l.getAttrStrWithoutSign(e)
let l=""
if(i&&(l=S.l.getAttrValueStr(e,i)),s&&s>0){const t=S.l.getAttrValueStr(e,s)
this.UpValue.SetActive(!0),this.UpValue.textSet(t)}else this.UpValue.SetActive(!1)
this.Name.textSet(n),this.Value.textSet(l)}}class Rt extends H.f{constructor(...t){super(...t),this.CloseBtn=null,this.tips=null,this.oldstage=null,this.nowstage=null,
this.grid_item=null,this.ui_baseitem=null}InitView(){super.InitView(),this.CloseBtn=this.CreateComponent(N.W,1),this.name=this.CreateComponent(F.Q,2),
this.tips=this.CreateComponent(F.Q,3),this.oldstage=this.CreateComponent(F.Q,4),this.nowstage=this.CreateComponent(F.Q,5),this.grid_item=this.CreateComponent(st.N,6),
this.ui_baseitem=this.CreateComponentBinder(K.j,7),this.grid_item.SetInitInfo("ui_elecarve_successattr",null,wt)}Clear(){this.ui_baseitem.Clear(),
this.RemoveFullScreenCollider(this.node.FatherId),super.Clear()}Destroy(){super.Destroy()}OnAddToScene(){this.AddLis()
const t=B.p.GetInst().SuccessElementCarve,e=Lt.f.Inst().getItemById(t.modelId),i=At.b.GetInst().GetLevelUpItemByKey(e.quality,t.stage,t.level)
let s=At.b.GetInst().GetMaxLevelInStage(i.quality,i.stage-1)
const n=At.b.GetInst().GetLevelUpItemByKey(e.quality,t.stage-1,s),l=new j.Z,a=i.GetAddValueLis(),o=n.GetAddValueDic()
for(let t=0;t<=a.Count()-1;t++){let e=0,i=0,s=0
e=a[t].intType,i=o[e],s=a[t].value,l.Add([e,i,s])}this.grid_item.data_set(l),s=At.b.GetInst().GetMaxLevelInStage(i.quality,i.stage),this.tips.textSet(`刻印等级上限开放至${i.stage}阶${s}级`),
this.oldstage.textSet(i.stage-1+"阶"),this.nowstage.textSet(`${i.stage}阶`)
const r=new m.M(t.modelId,t)
r.IconType_Set(tt.s.BASE_ICON_NOSWAP_TYPE),this.ui_baseitem.SetData(r),this.name.textSet(r.GetItemNameStr(!1))}AddLis(){
this.m_handlerMgr.AddClickEvent(this.CloseBtn,this.CreateDelegate(this.OnClose)),this.AddFullScreenCollider(this.node,this.CreateDelegate(this.OnClose))}OnClose(){
Ot.GetInst().CloseEleCarveSuccessView()}}class Ot{constructor(){this.EchoUpViewTime=null,this.AddLis()}static GetInst(){return null==Ot.inst&&(Ot.inst=new Ot),Ot.inst}AddLis(){
l.j.Inst.F_Register(-12131,R.n,this.CreateDelegate(this.SM_ElementCarvePutOnHandle)),l.j.Inst.F_Register(-12133,G.D,this.CreateDelegate(this.SM_ElementCarveTakeOffHandle)),
l.j.Inst.F_Register(-12135,w.Q,this.CreateDelegate(this.SM_ElementCarveLevelUpHandle)),l.j.Inst.F_Register(-12137,L.E,this.CreateDelegate(this.SM_ElementCarveLevelResetHandle)),
l.j.Inst.F_Register(-12139,O.o,this.CreateDelegate(this.SM_ElementCarveStageUpHandle)),l.j.Inst.F_Register(-12141,A.X,this.CreateDelegate(this.SM_ElementCarveAnimationHandle))}
TryWearCarve(t){if(t&&null!=t.serverData_get()){const e=t.serverData_get().Id_get(),i=P.$.Inst().GetSelectRoleInfo()
if(i&&B.p.GetInst().CurholdType>0&&B.p.GetInst().CurSubholdType>0){const t=i.GetElementCarve(B.p.GetInst().CurholdType,B.p.GetInst().CurSubholdType)
if(t&&t.level>0){const t=new m.M(s.modelId,s)
let s=new C.B
s.infoId="ELEMENT_CARVE:TIPS2",s.cancelHandle=()=>{this.Req_CM_ElementCarvePutOn(i,B.p.GetInst().CurholdType,B.p.GetInst().CurSubholdType,e)},s.cancelText="直接放入",
s.confirmHandle=()=>{this.TryLevelReset(t,!0)},s.confirmText="立即重置",s.replaceParams.Add(t.GetItemNameStr(!1)),p.t.Inst().Open(s)
}else this.Req_CM_ElementCarvePutOn(i,B.p.GetInst().CurholdType,B.p.GetInst().CurSubholdType,e)
}else-1==B.p.GetInst().CurholdType&&-1==B.p.GetInst().CurSubholdType&&M.L.Inst().OpenEleMianView(P.$.UI_ELEMENT_Cavre,P.$.UI_ELEMENT_Carve_SUB_Carve)}}
Req_CM_ElementCarvePutOn(t,e,i,s){B.p.GetInst().RaiseEvent(g.g.EleCarve_Wear_Item_Id,s)
const n=new D.v
n.playerId=t.Id_get(),n.elementHoldType=e,n.carveHoldType=i,n.guid=s,a.C.Inst.F_SendMsg(n)}SM_ElementCarvePutOnHandle(t){const e=t
if(e){const t=s.Y.Inst.GetMultiPlayerInfo(e.playerId)
if(t){const i=t.GetElementItemHold(e.elementHoldType)
if(i){i.carveHoldMap[e.carveHoldType]=e.elementCarveHold,t.SetElementItemHold(e.elementHoldType,i)
const s=P.$.Inst().GetElementItemHoleVO(t.createIdx,e.elementHoldType)
if(s){B.p.GetInst().OldEchoCfg=null,B.p.GetInst().NewEchoCfg=null
const t=s.GetEchoCfg()
s.SetElement(i,!1),B.p.GetInst().CheckRed()
const l=s.GetEchoCfg()
B.p.GetInst().OldEchoCfg=t,B.p.GetInst().NewEchoCfg=l,null!=l&&(null!=t?l.id!=t.id&&this.TryOpenEchoUpView():this.TryOpenEchoUpView()),
n.i.Inst.RaiseEvent(g.g.EleCarve_Wear_Update,[e.elementHoldType,e.carveHoldType,!0])}}}B.p.GetInst().UpdateEleCarveNum()}this.CloseEleCarveBagView()}TryTakeOffCarve(){
const t=P.$.Inst().GetSelectRoleInfo()
t&&B.p.GetInst().CurholdType>0&&B.p.GetInst().CurSubholdType>0&&this.Req_CM_ElementCarveTakeOff(t,B.p.GetInst().CurholdType,B.p.GetInst().CurSubholdType)}
Req_CM_ElementCarveTakeOff(t,e,i){const s=new T.v
s.playerId=t.Id_get(),s.elementHoldType=e,s.carveHoldType=i,a.C.Inst.F_SendMsg(s)}SM_ElementCarveTakeOffHandle(t){const e=t
if(e){const t=s.Y.Inst.GetMultiPlayerInfo(e.playerId)
if(t){const i=t.GetElementItemHold(e.elementHoldType)
if(i){i.carveHoldMap[e.carveHoldType].elementCarve=null,t.SetElementItemHold(e.elementHoldType,i)
const s=P.$.Inst().GetElementItemHoleVO(t.createIdx,e.elementHoldType)
s&&(s.SetElement(i,!1),B.p.GetInst().CheckRed(),n.i.Inst.RaiseEvent(g.g.EleCarve_Wear_Update,[e.elementHoldType,e.carveHoldType,!1]))}}}B.p.GetInst().UpdateEleCarveNum()}
Req_CM_ElementCarveLevelUp(){if(B.p.GetInst().SelectLis.Count()>0){const t=new v.P,e=P.$.Inst().GetSelectRoleInfo()
if(e){t.playerId=e.Id_get(),t.elementHoldType=B.p.GetInst().CurholdType,t.carveHoldType=B.p.GetInst().CurSubholdType,t.carvings=new _.X,t.items=new _.X
for(let e=0;e<=B.p.GetInst().SelectLis.Count()-1;e++){const i=B.p.GetInst().SelectLis[e],s=B.p.GetInst().SelectDic[i.ToString()]
if(1==s.itemtype)t.carvings.LuaDic_AddOrSetItem(i,s.num)
else{let e=s.num
t.items.LuaDic_ContainsKey(s.itemdata.modelId_get())&&(e+=t.items[s.itemdata.modelId_get()]),t.items.LuaDic_AddOrSetItem(s.itemdata.modelId_get(),e)}}a.C.Inst.F_SendMsg(t)}
}else b.y.inst.ClientSysMessage(11045004),B.p.GetInst().BagType=2,this.OpenEleCarveBagView()}SM_ElementCarveLevelUpHandle(t){const e=t
if(e){const t=s.Y.Inst.GetMultiPlayerInfo(e.playerId)
if(t){const i=t.GetElementItemHold(e.elementHoldType)
if(i){let s=0
i.carveHoldMap[e.carveHoldType].elementCarve&&(s=e.elementCarve.level-i.carveHoldMap[e.carveHoldType].elementCarve.level),
i.carveHoldMap[e.carveHoldType].elementCarve=e.elementCarve,t.SetElementItemHold(e.elementHoldType,i)
const l=P.$.Inst().GetElementItemHoleVO(t.createIdx,e.elementHoldType)
l&&(l.SetElement(i,!1),B.p.GetInst().SelectLis.Clear(),B.p.GetInst().SelectDic.Clear(),B.p.GetInst().CheckRed(),n.i.Inst.RaiseEvent(g.g.EleCarve_LevelChange,s))}}}}
TryLevelReset(t,e){if(t){const i=t.serverData_get()
i&&i.totalExp.ToNum()>B.p.GetInst().MixexpItemExp?(B.p.GetInst().ReSetInfo=t,B.p.GetInst().iswer=e,this.OpenEleCarveReSetView()):b.y.inst.ClientSysStrMsg("无可重置经验")}}
Req_CM_ElementCarveLevelReset(t,e){if(!t)return
const i=new y.V
if(e){const t=P.$.Inst().GetSelectRoleInfo()
t&&B.p.GetInst().CurholdType>0&&B.p.GetInst().CurSubholdType&&(i.playerId=t.Id_get(),i.elementHoldType=B.p.GetInst().CurholdType,i.carveHoldType=B.p.GetInst().CurSubholdType,
i.wear=!0,i.guid=c.o.FromNumber(0),a.C.Inst.F_SendMsg(i))}else i.playerId=s.Y.Inst.m_primaryRoleInfo.Id_get(),i.elementHoldType=0,i.carveHoldType=0,i.wear=!1,
i.guid=t.serverData_get().Id_get(),a.C.Inst.F_SendMsg(i)}SM_ElementCarveLevelResetHandle(t){const e=t
if(e){if(e.wear){const t=s.Y.Inst.GetMultiPlayerInfo(e.playerId)
if(t){const i=t.GetElementItemHold(e.elementHoldType)
if(i){i.carveHoldMap[e.carveHoldType].elementCarve=e.elementCarve,t.SetElementItemHold(e.elementHoldType,i)
const s=P.$.Inst().GetElementItemHoleVO(t.createIdx,e.elementHoldType)
s&&(s.SetElement(i,!1),B.p.GetInst().CheckRed(),n.i.Inst.RaiseEvent(g.g.EleCarve_LevelChange))}}}else{const t=I.g.Inst_get().GetItemById(e.guid)
t&&t.serverData_set(e.elementCarve)}this.CloseEleCarveBagView()}}Req_CM_ElementCarveStageUp(){const t=P.$.Inst().GetSelectRoleInfo()
if(t){const e=new E.v
e.playerId=t.Id_get(),e.elementHoldType=B.p.GetInst().CurholdType,e.carveHoldType=B.p.GetInst().CurSubholdType,e.carvings=new _.X
let i=0
for(let t=0;t<=B.p.GetInst().SelectLis.Count()-1;t++){const s=B.p.GetInst().SelectLis[t]
e.carvings.LuaDic_AddOrSetItem(s,B.p.GetInst().SelectDic[s.ToString()].num),i+=B.p.GetInst().SelectDic[s.ToString()].num}
const s=P.$.Inst().GetCarveItemHoldVo(t.createIdx,e.elementHoldType,e.carveHoldType)
s&&s.CarveLvUpCfg&&s.CarveLvUpCfg.num<=i?a.C.Inst.F_SendMsg(e):(b.y.inst.ClientSysMessage(11045005),s&&s.elementCarve&&(B.p.GetInst().BagType=3,
B.p.GetInst().BagId=s.elementCarve.modelId,this.OpenEleCarveBagView()))}}SM_ElementCarveStageUpHandle(t){const e=t
if(e){const t=s.Y.Inst.GetMultiPlayerInfo(e.playerId)
if(t){const i=t.GetElementItemHold(e.elementHoldType)
if(i){i.carveHoldMap[e.carveHoldType]=e.elementCarveHold,t.SetElementItemHold(e.elementHoldType,i)
const s=P.$.Inst().GetElementItemHoleVO(t.createIdx,e.elementHoldType)
if(s){B.p.GetInst().OldEchoCfg=null,B.p.GetInst().NewEchoCfg=null
const t=s.GetEchoCfg()
s.SetElement(i,!1),B.p.GetInst().CheckRed()
const l=s.GetEchoCfg()
B.p.GetInst().OldEchoCfg=t,B.p.GetInst().NewEchoCfg=l,B.p.GetInst().SuccessElementCarve=e.elementCarveHold.elementCarve,
null!=l&&(null!=t?l.id!=t.id?this.TryOpenEchoUpView():this.OpenEleCarveSuccessView():this.TryOpenEchoUpView()),B.p.GetInst().SelectLis.Clear(),B.p.GetInst().SelectDic.Clear(),
n.i.Inst.RaiseEvent(g.g.EleCarve_LevelChange)}}}}}TryUnLock(t,e,i){null!=t&&e>0&&i.Count()>0&&(i.Sort(S.l.SortCompareFunc_Int),this.Req_CM_ElementCarveAnimation(t,e,i))}
Req_CM_ElementCarveAnimation(t,e,i){const s=new f.M
s.playerId=t,s.elementHoldType=e,s.carveHoldTypes=i,a.C.Inst.F_SendMsg(s)}SM_ElementCarveAnimationHandle(t){const e=t
if(e){const t=s.Y.Inst.GetMultiPlayerInfo(e.playerId)
if(t){const i=t.GetElementItemHold(e.elementHoldType)
if(i){for(let t=0;t<=e.carveHoldTypes.Count()-1;t++){const s=e.carveHoldTypes[t]
i.carveHoldMap[s]&&(i.carveHoldMap[s].clientAnimation=!0)}t.SetElementItemHold(e.elementHoldType,i)
const s=P.$.Inst().GetElementItemHoleVO(t.createIdx,e.elementHoldType)
s&&(s.SetElement(i,!1),n.i.Inst.RaiseEvent(g.g.EleCarve_UnLock,e))}B.p.GetInst().UpdateEleCarveNum()}}}OpenEchoView(){const t=new r.v
t.isShowMask=!0,t.viewClass=gt,h.N.inst.OpenById(d.I.EleCarveEchoView,null,null,t)}CloseEchoView(){h.N.inst.CloseById(d.I.EleCarveEchoView)}OpenEleCarveSelectView(){const t=new r.v
t.layerType=u.F.Tip,t.viewClass=Dt,h.N.inst.OpenById(d.I.EleCarveItemSelectView,null,null,t)}CloseEleCarveSelectView(){h.N.inst.CloseById(d.I.EleCarveItemSelectView)}
OpenEleCarveBagView(){const t=h.N.inst.GetViewById(d.I.EleCarveBagView)
if(null!=t&&t.isShow_get())t.OnAddToScene()
else{const t=new r.v
t.viewClass=rt,h.N.inst.OpenById(d.I.EleCarveBagView,null,null,t)}}CloseEleCarveBagView(){h.N.inst.CloseById(d.I.EleCarveBagView)}OpenEleCarveSuccessView(){
if(B.p.GetInst().SuccessElementCarve){const t=new r.v
t.isShowMask=!0,t.viewClass=Rt,h.N.inst.OpenById(d.I.EleCarveSuccessView,null,null,t)}}CloseEleCarveSuccessView(){B.p.GetInst().SuccessElementCarve=null,
h.N.inst.CloseById(d.I.EleCarveSuccessView),n.i.Inst.RaiseEvent(g.g.EleCarve_SuccessViewClose)}OpenEleCarveReSetView(){const t=new r.v
t.isShowMask=!0,t.viewClass=Tt,h.N.inst.OpenById(d.I.EleCarveReSetView,null,null,t)}CloseEleCarveReSetView(){h.N.inst.CloseById(d.I.EleCarveReSetView)}TryOpenEchoUpView(){
o.C.Inst_get().ClearInterval(this.EchoUpViewTime),this.EchoUpViewTime=o.C.Inst_get().SetInterval(this.CreateDelegate(this.OpenEleCarveEchoUpView),750,1)}OpenEleCarveEchoUpView(){
o.C.Inst_get().ClearInterval(this.EchoUpViewTime)
const t=new r.v
t.isShowMask=!0,t.maskAlpha=.8,t.viewClass=_t,h.N.inst.OpenById(d.I.EleCarveEchoUpView,null,null,t)}CloseEleCarveEchoUpView(){o.C.Inst_get().ClearInterval(this.EchoUpViewTime),
h.N.inst.CloseById(d.I.EleCarveEchoUpView),this.OpenEleCarveSuccessView()}}Ot.inst=null},21577:(t,e,i)=>{i.d(e,{P:()=>u})
var s=i(38836),n=i(98800),l=i(85602),a=i(38962),o=i(37828),r=i(64649),h=i(26495)
let d=null
class u{static __StaticInit(){d=new a.X}static IsCanReplace(t,e,i,s){if(!u.IsCanWear(t,e,i,s))return!1
if(i&&s){return null!=r.$.Inst().GetElementItemHoleVOList(t)[i-1].carveHoldItemMap[s].elementCarve}return!1}static IsCanWear(t,e,i,s,n){const l=e.cfgData_get()
if(!u.SimpleIsCanWear(t,l))return!1
if(i&&s){const n=r.$.Inst().GetElementItemHoleVOList(t)[i-1].carveHoldItemMap[s]
return!!(n.IsInited&&n.effective&&n.clientAnimation)&&(null==n.elementCarve||null==e.serverData_get()||!n.elementCarve.id.Equal(e.serverData_get().id))}return!0}
static SimpleIsCanWear(t,e){return!!u.LevelIsCanWear(t,e)&&!!u.JobIsCanWear(t,e)}static LevelIsCanWear(t,e){return!(e.level>t.Level_get())}static JobIsCanWear(t,e){
return!(0!=e.job&&!e.Jobs_get().Contains(t.Job_get()))}static SimpleIsCanWearInAllRole(t){for(const[e,i]of(0,s.V5)(n.Y.Inst.primaryRoleInfoList))if(u.SimpleIsCanWear(i,t))return!0
return!1}static IsCanReSet(t){if(null!=t.serverData_get()){const e=t.serverData_get()
if(e&&(e.totalExp.ToNum()>h.p.GetInst().MixexpItemExp||e.consumeItems.Count()>0))return!0}return!1}static IsCanTakeOff(t,e,i,s){if(i&&s){
const n=r.$.Inst().GetElementItemHoleVOList(t)[i-1].carveHoldItemMap[s]
return!!(n.IsInited&&n.elementCarve&&null!=e.serverData_get()&&e.serverData_get().Id_get().Equal(n.elementCarve.id))}return!1}GetUphold_subhold(t,e,i){
const n=u.GetUpPosScoreDictForRole(t,e,i)
if(0==n.LuaDic_Count())return[0,[0,0,0]]
const a=new l.Z
for(const[t,e]of(0,s.V5)(n))a.Add(new l.Z([t,e]))
a.Sort(u.SortByHoldType)
let o=0,r=0,h=0,d=0
for(let t=0;t<=a.Count()-1;t++){const e=a[t][1],i=e[1],s=e[2],n=e[3];(i>o||i==o&&s>r||i==o&&s==r&&n>h)&&(o=i,r=s,h=n,d=a[t][0])}return[d,[o,r,h]]}static SortByHoldType(t,e){
return t[0]-e[0]}static GetUpPosScoreDictForRole(t,e,i){const s=e.GetEleCarveRes()
if(!u.SimpleIsCanWear(t,e.cfgData_get()))return d
null==i&&(i=!0)
const n=s.score,l=e.serverData_get()
let c=null
const _=r.$.Inst().GetTypeList()
for(let e=0;e<=_.Count()-1;e++){const s=_[e],r=h.p.GetInst().GetSubTypeList()
for(let e=0;e<=r.Count()-1;e++){const h=r[e]
if(!i||t.GetCarveHoldIsUnLock(s,h)){const e=t.GetElementCarve(s,h)
let i=0,r=0,d=0
if(null==e)i=n,r=l.stage-r,d=l.level-d
else{i=n-o.b.GetInst().GetEleCarveItemById(e.modelId).score,r=l.stage-e.stage,d=l.level-e.level}null==c&&(c=new a.X),c.LuaDic_AddOrSetItem(100*s+h,[i,r,d])}}}return null==c?d:c}}},
26495:(t,e,i)=>{i.d(e,{p:()=>w})
var s=i(38836),n=i(98800),l=i(97461),a=i(16812),o=i(62370),r=i(98885),h=i(85602),d=i(38962),u=i(21729),c=i(70850),_=i(95272),I=i(63076),m=i(18152),g=i(3859),p=i(92679),C=i(75439),S=i(37828),f=i(14792),y=i(62734),v=i(50600),D=i(65550),E=i(64649)
class T{constructor(){this.itemdata=null,this.count=0,this.num=0,this.itemtype=0}InIt(t,e){this.itemdata=t,this.count=this.itemdata.serverData_get().num,this.num=e,
w.GetInst().ExpItemDic.LuaDic_ContainsKey(this.itemdata.modelId_get())?this.itemtype=0:this.itemtype=1}}var A=i(21577)
class L{}L.None=0,L.LevelUp=1,L.NeedPort=2,L.CanWera=3,L.CanUnLock=4
class w extends a.k{constructor(){super(),this.CurholdType=-1,this.CurSubholdType=-1,this.openViewId=null,this.ExpItemDic=null,this.ExpSortLis=null,this.MixexpItemExp=0,
this.PopItemSortSelctType=null,this.PopItemSortSelctType2=null,this.SelectLis=null,this.SelectDic=null,this.tempEleCarveMaxAddScoreDic=null,this.EleCarveMaxAddScoreDic=null,
this.RedType=L.None,this.RedVoLis=null,this.RedVoIndex=-1,this.RedDic=null,this.m_curSelectedData=null,this.BagType=1,this.BagId=0,this.SuccessElementCarve=null,
this.ReSetInfo=null,this.iswer=!1,this.OldEchoCfg=null,this.NewEchoCfg=null,this.holdOpenNumDic=null,this.holdEquipNumDic=null,this.ExpItemDic=new d.X,this.ExpSortLis=new h.Z,
this.PopItemSortSelctType=v.a.inst.GetInteger("EleCarvePopItemSortSelctType"),this.PopItemSortSelctType2=v.a.inst.GetInteger("EleCarvePopItemSortSelctType2"),
0==this.PopItemSortSelctType2&&(this.PopItemSortSelctType2=1),this.SelectLis=new h.Z,this.SelectDic=new d.X,this.tempEleCarveMaxAddScoreDic=new d.X,
this.EleCarveMaxAddScoreDic=new d.X,this.RedVoLis=new h.Z,this.RedDic=new d.X,this.holdOpenNumDic=new d.X,this.holdEquipNumDic=new d.X,this.Init(),this.AddLis()}static GetInst(){
return null==w.inst&&(w.inst=new w),w.inst}ResetModel(){this.CurholdType=-1,this.CurSubholdType=-1,this.ExpItemDic=new d.X,this.ExpSortLis=new h.Z,this.MixexpItemExp=0,
this.PopItemSortSelctType=v.a.inst.GetInteger("EleCarvePopItemSortSelctType"),this.PopItemSortSelctType2=v.a.inst.GetInteger("EleCarvePopItemSortSelctType2"),
0==this.PopItemSortSelctType2&&(this.PopItemSortSelctType2=1),this.SelectLis=new h.Z,this.SelectDic=new d.X,this.tempEleCarveMaxAddScoreDic=new d.X,
this.EleCarveMaxAddScoreDic=new d.X,this.RedType=L.None,this.RedVoLis=new h.Z,this.RedDic=new d.X,this.m_curSelectedData=null,this.BagType=1,this.BagId=0,
this.SuccessElementCarve=null,this.ReSetInfo=null,this.iswer=!1,this.OldEchoCfg=null,this.NewEchoCfg=null,this.holdOpenNumDic=new d.X,this.holdEquipNumDic=new d.X,this.Init()}
Init(){this.ExpItemDic.Clear(),this.ExpSortLis.Clear()
const t=C.D.getInstance().GetStringArray("ELEMENT_CARVING:EXP_ITEM")
for(let e=0;e<=t.Count()-1;e++){t[e]=r.M.Replace(t[e],'"',"")
const i=r.M.Split(t[e],o.o.s_Arr_UNDER_CHAR_DOT)
if(2==i.Count()){const t=r.M.String2Int(i[0]),e=r.M.String2Int(i[1])
this.ExpItemDic.LuaDic_ContainsKey(t)||(this.ExpItemDic.LuaDic_AddOrSetItem(t,e),this.ExpSortLis.Add(t))}}this.ExpSortLis.Sort(this.CreateDelegate(this.ExpItemSort)),
this.MixexpItemExp=this.ExpItemDic[this.ExpSortLis.LastItem()]||0}ExpItemSort(t,e){const i=this.GetItemExp(t)
return this.GetItemExp(e)-i}GetItemExp(t){if(this.ExpItemDic.LuaDic_ContainsKey(t))return this.ExpItemDic[t]
const e=S.b.GetInst().GetEleCarveItemById(t)
return e?e.exp:0}UpdateMaxEleCarveScoreGroup(){this.tempEleCarveMaxAddScoreDic.Clear(),this.EleCarveMaxAddScoreDic.Clear()
const t=c.g.Inst_get().GetItemListByItemType(g.q.elementCarve,_.t.NormalBag)
for(let e=0;e<=t.Count()-1;e++)if(null!=t[e]&&null!=t[e].baseData_get()){const i=t[e].baseData_get()
for(const[t,e]of(0,s.V5)(n.Y.Inst.primaryRoleInfoList))if(this.IsMatchEleCarveScore(e,i)&&null!=i.serverData_get()){const[t,s]=A.P.GetUphold_subhold(e,i,!0),n=s[1],l=s[2],a=s[3]
if(n>0||0==n&&l>0||0==n&&0==l&&a>0){let n=null
n=A.P.IsCanWear(e,i,u.N.Floor(t/100),t%100)?1e4*e.createIdx+10*t:1e4*e.createIdx+10*t+1
const l=i.serverData_get().id
if(this.tempEleCarveMaxAddScoreDic.LuaDic_ContainsKey(n)){const t=this.tempEleCarveMaxAddScoreDic[n]
this.EleCarveMaxAddScoreDic.LuaDic_ContainsKey(t)?this.CheckIsUp(s,this.EleCarveMaxAddScoreDic[t])&&(this.EleCarveMaxAddScoreDic.LuaDic_Remove(t),
this.tempEleCarveMaxAddScoreDic[n]=l,this.EleCarveMaxAddScoreDic.LuaDic_AddOrSetItem(l,s)):(this.EleCarveMaxAddScoreDic.LuaDic_Remove(t),this.tempEleCarveMaxAddScoreDic[n]=l,
this.EleCarveMaxAddScoreDic.LuaDic_AddOrSetItem(l,s))}else this.tempEleCarveMaxAddScoreDic.LuaDic_Add(n,l),
this.EleCarveMaxAddScoreDic.LuaDic_ContainsKey(l)?this.CheckIsUp(s,this.EleCarveMaxAddScoreDic[l])&&this.EleCarveMaxAddScoreDic.LuaDic_AddOrSetItem(l,s):this.EleCarveMaxAddScoreDic.LuaDic_AddOrSetItem(l,s)
}}}}UpdateEleCarveNum(t){null==this.holdOpenNumDic&&(this.holdOpenNumDic=new d.X),null==this.holdEquipNumDic&&(this.holdEquipNumDic=new d.X)
const e=E.$.Inst().GetTypeList()
if(null!=t){const i=t
let s=0,n=0
for(let t=0;t<=e.Count()-1;t++){const l=e[t],a=w.GetInst().GetSubTypeList()
for(let t=0;t<=a.Count()-1;t++){const e=a[t]
if(i.GetCarveHoldIsUnLock(l,e)){s+=1
null!=i.GetElementCarve(l,e)&&(n+=1)}}}this.holdOpenNumDic[i.createIdx]=s,this.holdEquipNumDic[i.createIdx]=n}else{this.holdOpenNumDic.Clear(),this.holdEquipNumDic.Clear()
for(const[t,i]of(0,s.V5)(n.Y.Inst.primaryRoleInfoList)){let t=0,s=0
for(let n=0;n<=e.Count()-1;n++){const l=e[n],a=w.GetInst().GetSubTypeList()
for(let e=0;e<=a.Count()-1;e++){const n=a[e]
if(i.GetCarveHoldIsUnLock(l,n)){t+=1
null!=i.GetElementCarve(l,n)&&(s+=1)}}}this.holdOpenNumDic[i.createIdx]=t,this.holdEquipNumDic[i.createIdx]=s}}}CheckIsUp(t,e){
const[i,s,n]=[t[1],t[2],t[3]],[l,a,o]=[e[1],e[2],e[3]]
return i>l||i==l&&s>a||i==l&&s==a&&n>o}IsMatchEleCarveScore(t,e){const i=e.cfgData_get()
return null!=i&&!!A.P.SimpleIsCanWear(t,i)}GetBagItemLis(t,e){e=e||this.PopItemSortSelctType
const i=new h.Z,s=c.g.Inst_get().GetBagDataList(_.t.NormalBag),n=E.$.Inst().GetSelectRoleInfo()
if(n){for(let t=0;t<=s.Count()-1;t++){let e=0
if(s[t].baseData_get()&&(e=s[t].baseData_get().modelId_get()),null!=s[t].baseData_get()&&e>0&&(S.b.GetInst().GetEleCarveItemById(e)||this.ExpItemDic.LuaDic_ContainsKey(e)&&1!=this.BagType)){
let l=!0
if(this.BagId>0&&3==this.BagType&&this.BagId!=e&&(l=!1),1==this.BagType){const e=s[t].baseData_get().cfgData_get()
0==e.job||e.Jobs_get().Contains(n.Job_get())||(l=!1)}if(l){const n=new T,l=new I.M(e,s[t].serverData_get())
l.serverData_set(s[t].serverData_get()),l.IconType_Set(m.s.EleCarveItem_Icon_Type)
let a=0
this.SelectDic[s[t].serverData_get().Id_get().ToString()]&&(a=this.SelectDic[s[t].serverData_get().Id_get().ToString()].num),n.InIt(l,a),i.Add(n)}}}
0==e?1==t?i.Sort(w.SortUp0):i.Sort(w.SortDown0):1==t?i.Sort(w.SortUp1):i.Sort(w.SortDown1)}return i}GetBagItemLis2(){const t=new h.Z,e=c.g.Inst_get().GetBagDataList(_.t.NormalBag)
E.$.Inst().GetSelectRoleInfo()
for(let i=0;i<=e.Count()-1;i++){let s=0
e[i].baseData_get()&&(s=e[i].baseData_get().modelId_get()),null!=e[i].baseData_get()&&s>0&&(S.b.GetInst().GetEleCarveItemById(s)||this.ExpItemDic.LuaDic_ContainsKey(s))&&t.Add(e[i])
}return t}static SortUp0(t,e){if(t.itemtype==e.itemtype){if(0==t.itemtype){return t.itemdata.cfgData_get().quality-e.itemdata.cfgData_get().quality}
const i=t.itemdata.cfgData_get(),s=e.itemdata.cfgData_get()
if(i.quality==s.quality){const i=t.itemdata.serverData_get(),s=e.itemdata.serverData_get()
return i.level-s.level}return i.quality-s.quality}return t.itemtype-e.itemtype}static SortUp1(t,e){if(t.itemtype==e.itemtype){if(0==t.itemtype){
return t.itemdata.cfgData_get().quality-e.itemdata.cfgData_get().quality}const i=t.itemdata.serverData_get(),s=e.itemdata.serverData_get()
if(i.level==s.level){const i=t.itemdata.cfgData_get(),s=e.itemdata.cfgData_get()
return i.quality-s.quality}return i.level-s.level}return t.itemtype-e.itemtype}static SortDown0(t,e){if(t.itemtype==e.itemtype){if(0==t.itemtype){
const i=t.itemdata.cfgData_get().quality
return e.itemdata.cfgData_get().quality-i}const i=t.itemdata.cfgData_get(),s=e.itemdata.cfgData_get()
if(i.quality==s.quality){const i=t.itemdata.serverData_get()
return e.itemdata.serverData_get().level-i.level}return s.quality-i.quality}return t.itemtype-e.itemtype}static SortDown1(t,e){if(t.itemtype==e.itemtype){if(0==t.itemtype){
const i=t.itemdata.cfgData_get().quality
return e.itemdata.cfgData_get().quality-i}const i=t.itemdata.serverData_get(),s=e.itemdata.serverData_get()
if(i.level==s.level){const i=t.itemdata.cfgData_get()
return e.itemdata.cfgData_get().quality-i.quality}return s.level-i.level}return t.itemtype-e.itemtype}IsInSelectItem(t){
return!!t&&!!this.SelectDic.LuaDic_ContainsKey(t.itemdata.serverData_get().Id_get().ToString())}AddSelectExpItem(t,e){if(null==t||null==e||e<=0)return
let i=4
3==this.BagType&&(i=3)
let s=0
if(3==this.BagType){const t=this.GetNowSubVo()
t.CarveLvUpCfg&&t.CarveLvUpCfg.num>0&&(s=t.CarveLvUpCfg.num)}const n=this.SelectLis.IndexOf(t.itemdata.serverData_get().Id_get())
let a=!1,o=!1
return this.SelectLis.Count()<=i?-1==n?t.count>=t.num+e&&(s<=0||t.num+e<=s)&&this.SelectLis.Count()<i?(t.num+=e,
this.SelectDic.LuaDic_AddOrSetItem(t.itemdata.serverData_get().Id_get().ToString(),t),this.SelectLis.Add(t.itemdata.serverData_get().Id_get()),a=!0):(o=!0,
D.y.inst.ClientSysMessage(11043404)):t.count>=t.num+e&&(s<=0||t.num+e<=s)&&(t.num+=e,this.SelectLis[n]=t.itemdata.serverData_get().Id_get(),
this.SelectDic.LuaDic_AddOrSetItem(t.itemdata.serverData_get().Id_get().ToString(),t),a=!0):(o=!0,D.y.inst.ClientSysMessage(11043404)),
a&&l.i.Inst.RaiseEvent(p.g.EleCarve_SelectChange,t),o}RemoveSelectExpItem(t){if(!t)return
const e=this.SelectLis.IndexOf(t.itemdata.serverData_get().Id_get());-1!=e&&(t.num>1?(t.num-=1,
this.SelectDic.LuaDic_AddOrSetItem(t.itemdata.serverData_get().Id_get().ToString(),t)):(t.num=0,this.SelectDic.LuaDic_Remove(t.itemdata.serverData_get().Id_get().ToString()),
this.SelectLis.RemoveAt(e)),l.i.Inst.RaiseEvent(p.g.EleCarve_SelectChange,t))}GetNowShowVo(){const t=E.$.Inst().GetSelectRoleInfo()
return t&&this.CurholdType>0?E.$.Inst().GetElementItemHoleVO(t.createIdx,this.CurholdType):null}GetNowSubVo(){const t=E.$.Inst().GetSelectRoleInfo()
if(t&&this.CurholdType>0){const e=E.$.Inst().GetElementItemHoleVO(t.createIdx,this.CurholdType)
if(this.CurSubholdType>0)return e.carveHoldItemMap[this.CurSubholdType]}return null}IsEqEchoTpye(t,e,i){if(null==t&&(t=E.$.Inst().GetSelectRoleInfo()),t){
const s=E.$.Inst().GetElementItemHoleVO(t.createIdx,e).GetEchoType()
if(s>0&&s==i)return!0}return!1}GetPreReCommonEchoType(t,e){let i=0,n=0,l=0
for(const[e,a]of(0,s.V5)(t.carveHoldItemMap))3==a.quality?i+=1:4==a.quality?n+=1:5==a.quality&&(l+=1)
let a=new h.Z
if(i+n+l<=0)a.Add(S.b.GetInst().GetMaxLevelEchoItemByKey(e,200)),a.Add(S.b.GetInst().GetMaxLevelEchoItemByKey(e,20)),a.Add(S.b.GetInst().GetMaxLevelEchoItemByKey(e,2))
else if(i+n+l<3){const t=100*l+10*n+1*i
a.Add(S.b.GetInst().GetMaxLevelEchoItemByKey(e,t+100)),a.Add(S.b.GetInst().GetMaxLevelEchoItemByKey(e,t+10)),a.Add(S.b.GetInst().GetMaxLevelEchoItemByKey(e,t+1))
}else a=this.GetPreReCommonEchoType2(t,e)
return a}GetPreReCommonEchoType2(t,e){const i=S.b.GetInst().GetAllEchoTypeLisByKey(e)
let s=new h.Z
const n=t.GetEchoCfg()
let l
if(n&&(l=S.b.GetInst().GetMaxLevelEchoItemByKey(e,n.EchoGroupType)),i.Count()>3)if(l){const t=i.IndexOf(l)
t>=0&&(t<=3?(s.Add(i[0]),s.Add(i[1]),s.Add(i[2])):(s.Add(i[t-3]),s.Add(i[t-2]),s.Add(i[t-1])))}else{const t=i.Count()
s.Add(i[t-3]),s.Add(i[t-2]),s.Add(i[t-1])}else s=i
return s}GetReCommonEchoType(t,e){const i=S.b.GetInst().GetAllEchoTypeLisByKey(e),s=this.GetPreReCommonEchoType(t,e)
for(let t=0;t<=s.Count()-1;t++)i.Remove(s[t])
return i.Sort(w.EchoTypeSort),s.AddRange(i),s}static EchoTypeSort(t,e){return e.GetSortVaule()-t.GetSortVaule()}GetSubTypeList(){return new h.Z([1,2,3])}GetQualityStr(t,e){
let i="史诗"
return 3==t?i="史诗":4==t?i="传奇":5==t&&(i="远古"),e&&(i+="刻印"),i}GetQualityIconStr(t){
return 3==t?"ryyuansukeyin_sp_0028":4==t?"ryyuansukeyin_sp_0030":5==t?"ryyuansukeyin_sp_0029":"ryyuansukeyin_sp_0021"}AddLis(){
l.i.Inst.AddEventHandler(p.g.BAG_INITED,this.CreateDelegate(this.CheckRed),1),l.i.Inst.AddEventHandler(p.g.EleCarve_LevelChange,this.CreateDelegate(this.CheckRed),5),
l.i.Inst.AddEventHandler(p.g.BAG_UPDATE,this.CreateDelegate(this.CheckRed),10),l.i.Inst.AddEventHandler(p.g.MULIT_ROLE_INFO_CHANGED,this.CreateDelegate(this.CheckRed),10),
l.i.Inst.AddEventHandler(p.g.FUNCTION_INIT_COMPLETE,this.CreateDelegate(this.CheckRed)),l.i.Inst.AddEventHandler(p.g.EleCarve_UnLockEnd,this.CreateDelegate(this.CheckRed))}
CheckRedForce(){this.CheckRed(!0)}CheckRed(t){this.UpdateMaxEleCarveScoreGroup(),this.RedDic.Clear(),this.RedType=L.None,this.RedVoLis.Clear(),this.RedVoIndex=-1
const e=this.GetBagItemLis2()
let i=0
for(let t=0;t<=e.Count()-1;t++)i+=this.GetItemExp(e[t].baseData_get().modelId_get())*e[t].serverData_get().num
const s=n.Y.Inst.primaryRoleInfoList
let l,a=L.None
for(let t=0;t<=s.Count()-1;t++){const e=E.$.Inst().GetElementItemHoleVOList(s[t])
for(let s=0;s<=e.Count()-1;s++){const n=e[s]
for(let e=1;e<=3;e++){a=L.None
const l=n.carveHoldItemMap[e]
if(l&&l.effective)if(l.clientAnimation)if(null!=l.elementCarve){const s=1e4*t+1e3*n.type+10*e,o=this.tempEleCarveMaxAddScoreDic[s]
if(null!=o&&null!=this.EleCarveMaxAddScoreDic[o]){const t=c.g.Inst_get().GetItemById(o)
t&&t.baseData_get().GetEleCarveRes().score>l.CarveCfg.score&&a<L.CanWera&&(a=L.CanWera)}
l.elementCarve.exp.ToNum()>=l.CarveLvUpCfg.needExp&&l.CarveLvUpCfg.num>0&&c.g.Inst_get().GetItemNum(l.elementCarve.modelId)>=l.CarveLvUpCfg.num&&a<L.NeedPort&&(a=L.NeedPort),
l.CarveLvUpCfg.needExp<=l.elementCarve.exp.ToNum()+i&&l.CarveLvUpCfg.needExp>0&&a<L.LevelUp&&(a=L.LevelUp)}else{const i=1e4*t+1e3*n.type+10*e,s=this.tempEleCarveMaxAddScoreDic[i]
null!=s&&null!=this.EleCarveMaxAddScoreDic[s]&&a<L.CanWera&&(a=L.CanWera)}else a<L.CanUnLock&&(a=L.CanUnLock)
const o=1e4*t+100*(s+1)+e
this.RedDic[o]=a,a>this.RedType&&(this.RedType=a)}}}for(let e=0;e<=s.Count()-1;e++){let i=!1
if(l=null,this.RedType>L.None){const t=E.$.Inst().GetTypeList()
for(let s=0;s<=t.Count()-1;s++){const n=this.GetSubTypeList()
for(let a=0;a<=n.Count()-1;a++){const o=1e4*e+100*t[s]+n[a]
if(this.RedDic[o]>=this.RedType&&(i=!0),this.RedDic[o]>=this.RedType)if(this.RedType==L.NeedPort)if(null==l)l=E.$.Inst().GetCarveItemHoldVo(e,t[s],n[a])
else{const i=E.$.Inst().GetCarveItemHoldVo(e,t[s],n[a])
null!=i.CarveLvUpCfg&&l.CarveLvUpCfg.stage>i.CarveLvUpCfg.stage&&(l=i)}else if(this.RedType==L.LevelUp)if(null==l)l=E.$.Inst().GetCarveItemHoldVo(e,t[s],n[a])
else{const i=E.$.Inst().GetCarveItemHoldVo(e,t[s],n[a])
null!=i.CarveLvUpCfg&&(l.CarveLvUpCfg.stage>i.CarveLvUpCfg.stage||l.CarveLvUpCfg.stage==i.CarveLvUpCfg.stage&&l.CarveLvUpCfg.level>i.CarveLvUpCfg.level)&&(l=i)}}}}
this.RedVoLis[e]=l,l&&-1==this.RedVoIndex&&(this.RedVoIndex=e),this.RedType!=L.LevelUp&&this.RedType!=L.NeedPort||this.RedVoIndex!=e&&(i=!1),
(y.f.Inst.GetData(f.t.UI_ELEMENT_CARVE_VIEW).GetIsShowByRole(e)!=i||t)&&y.f.Inst.SetState(f.t.UI_ELEMENT_CARVE_VIEW,i,e)}}GetRedState(t,e,i){if(this.RedType==L.None)return!1
if(this.RedType==L.LevelUp||this.RedType==L.NeedPort){if(t!=this.RedVoIndex)return!1
if(this.RedVoLis[t]&&this.RedVoLis[t].holdtype==e){if(-1==i){let e=!1
for(let i=1;i<=3;i++)if(this.RedVoLis[t]&&this.RedVoLis[t].Subholdtype==i){e=!0
break}return e}if(this.RedVoLis[t]&&this.RedVoLis[t].Subholdtype==i)return!0}}else{if(-1==i){let i=!1
for(let s=1;s<=3;s++){const n=this.RedDic[1e4*t+100*e+s]
if(n&&this.RedType==n){i=!0
break}}return i}const s=this.RedDic[1e4*t+100*e+i]
if(s&&this.RedType==s)return!0}return!1}GetELeCarveAttrs(t,e,i){const s=S.b.GetInst().GetLevelUpItemByKey(t,e,i)
return s?s.GetAddValueDic():new d.X}IsEleCarveItem(t){return null!=t&&null!=t.cfgData_get()&&t.cfgData_get().itemType==g.q.elementCarve}}w.inst=null},87530:(t,e,i)=>{i.d(e,{L:()=>s
})
class s{constructor(){this.view=null,this.viewShowUp=null,this.AddLis()}static Inst(){return null==s.inst&&(s.inst=new s),s.inst}AddLis(){
MessagePool.Inst.F_Register(-12085,SM_ElementPutOn,this.CreateDelegate(this.SM_ElementPutOnHandle)),
MessagePool.Inst.F_Register(-12087,SM_ElementTakeOff,this.CreateDelegate(this.SM_ElementTakeOffHandle)),
MessagePool.Inst.F_Register(-12124,SM_ElementHoldUnlock,this.CreateDelegate(this.SM_ElementHoldUnlockHandle)),
MessagePool.Inst.F_Register(-12126,SM_ElementCircleStageUp,this.CreateDelegate(this.SM_ElementCircleStageUpHandle)),
MessagePool.Inst.F_Register(-12127,SM_ElementUpdateBattleScore,this.CreateDelegate(this.SM_ElementUpdateBattleScoreUpHandle)),
MessagePool.Inst.F_Register(-12089,SM_ElementCircleStageChange,this.CreateDelegate(this.SM_ElementCircleStageChangeHandle)),ElementItemModel.Inst().AddLis()}
SM_ElementCircleStageChangeHandle(t){const e=CharacterMgr.Inst.getRoleInfo(t.playerId)
null==e||e.isPlayer||e.SetElementInfoStage(t.stage)}SM_ElementUpdateBattleScoreUpHandle(t){const e=t,i=CharacterMgr.Inst.GetMultiPlayerInfo(e.playerId)
null!=i&&i.SetElementInfoBattleScore(e.battleScore)}SM_ElementCircleStageUpHandle(t){const e=t
let i=CharacterMgr.Inst.GetMultiPlayerInfo(e.playerId)
null==i&&(i=CharacterMgr.Inst.getRoleInfo(e.playerId)),null!=i&&i.SetElementInfoStage(e.stage)}SM_ElementHoldUnlockHandle(t){
const e=t,i=CharacterMgr.Inst.GetMultiPlayerInfo(e.playerId),s=i.GetElementItemHoldMap()
if(!s.LuaDic_ContainsKey(e.holdType)){const t=new ElementHoldVo
t.element=null,t.enhanceExp=LusuoLong.New(0,0),t.enhanceLevel=0,s.LuaDic_AddOrSetItem(e.holdType,t)
const n=ElementItemModel.Inst().GetElementItemHoleVO(i.createIdx,e.holdType)
null!=n&&n.SetElement(t,!1)}ElementItemModel.Inst().unlockCId=i.createIdx,ElementItemModel.Inst().unlockType=e.holdType,
ElementItemModel.Inst().RaiseEvent(ElementItemModel.HOLE_ACTIVE)}SM_ElementPutOnHandle(t){const e=t,i=CharacterMgr.Inst.GetPlayerInfoById(e.playerId)
i.SetElementItemHold(e.holdType,e.elementHold)
const s=ElementItemModel.Inst().GetElementItemHoleVO(i.createIdx,e.holdType)
s&&s.SetElement(e.elementHold,!1),LuaEventMgr.Inst.RaiseEvent(CommonEventType.ELEMENT_WEAR_UPDATE,e.holdType)}SM_ElementTakeOffHandle(t){
const e=t,i=CharacterMgr.Inst.GetPlayerInfoById(e.playerId)
i.SetElementItemHold(e.holdType,e.elementHold)
ElementItemModel.Inst().GetElementItemHoleVO(i.createIdx,e.holdType).SetElement(e.elementHold,!1),LuaEventMgr.Inst.RaiseEvent(CommonEventType.ELEMENT_WEAR_UPDATE,e.holdType)}
Req_ElementPutOn(t,e){const i=new CM_ElementPutOn
i.playerId=t,i.guid=e,SocketManager.Inst.F_SendMsg(i)}Req_ElementCircleStageUp(t){const e=new CM_ElementCircleStageUp
e.playerId=t,SocketManager.Inst.F_SendMsg(e)}Req_ElementTakeOff(t,e){const i=new CM_ElementTakeOff
i.playerId=t,i.holdType=e,SocketManager.Inst.F_SendMsg(i)}Req_ElementHoldUnlock(t,e){const i=new CM_ElementHoldUnlock
i.playerId=t,i.holdType=e,SocketManager.Inst.F_SendMsg(i)}OpenBagByType(t){null!=this.view&&this.view.OpenBagByType(t)}SetSelectCharacter(t){
t!=ElementItemModel.Inst().curSelectIdx&&(ElementItemModel.Inst().curSelectIdx=t,null!=this.view&&(this.view.SelectCharacter(t),this.view._OnCharacterTabChange()))}
OpenEleMianViewByData(t){const e=t.GetElementRes().elementType,i=ElementItemModel.Inst().GetFixRoleCIdx(t)
ElementItemModel.Inst().select_open_item_id=t.serverData_get().Id_get(),s.Inst().OpenEleMianView(null,null,!1,e,i)}OpenEleMianView(t,e,i=null,s=null,n=null,l=null){
if(!FunctionOpenModel.Inst_get().IsFunctionOpened(FunctionType.ELEMENT_ITEM))return void CommonUtil.SetFunctionTip(FunctionType.ELEMENT_ITEM)
if(null!=t&&(ElementItemModel.Inst().topViewType=t),null!=e&&(ElementItemModel.Inst().subViewType=e),null!=i&&(ElementItemModel.Inst().showBag=i),
null!=s&&(ElementItemModel.Inst().bagSelectType=s),
t==ElementItemModel.UI_ELEMENT_Cavre&&e==ElementItemModel.UI_ELEMENT_Carve_SUB_Carve&&(null!=s&&(EleCarveModel.GetInst().CurholdType=s),
null!=l&&(EleCarveModel.GetInst().CurSubholdType=l),null!=i&&(EleCarveModel.GetInst().BagType=1)),null!=n)ElementItemModel.Inst().curSelectIdx=n
else if(ElementItemModel.Inst().curSelectIdx=0,ElementItemModel.Inst().topViewType==ElementItemModel.UI_ELEMENT_ITEM&&ElementItemModel.Inst().subViewType==ElementItemModel.UI_ELEMENT_ITEM_SUB_CIRCEL){
const t=RedPointManager.Inst.GetData(RedPointId.UI_ELEMENT_ITEM_CIRCLE_ROLE)
if(null!=t)for(let e=0;e<=t._showListByRole.count-1;e++)if(t._showListByRole[e]){ElementItemModel.Inst().curSelectIdx=e
break}}else ElementItemModel.Inst().curSelectIdx=0
if(null!=this.view)return void this.view.OnAddToScene()
const a=new UIOpenParam
a.isShowMask=!0,a.isDefaultUITween=!0,BagManager.Inst_get().CM_MergeReq(BagType.ElementBag),
UIShowMgr.inst.OpenById(eUIComponentID.ElementItemMainVIew,this.CreateDelegate(this.OnLoadMainView),this.CreateDelegate(this.DestroyMainView),a)}CloseElMainView(){
UIShowMgr.inst.CloseById(eUIComponentID.ElementItemMainVIew)}OnLoadMainView(t){return null==this.view&&(this.view=new ElementItemMainView,this.view.setId(t,null,0)),this.view}
DestroyMainView(){null!=this.view&&(UIResMgr.DestroyUIObj(this.view),this.view=null)}OpenEleShowStageUpView(){const t=new UIOpenParam
t.isShowMask=!0,t.layerType=LayerType.Alert,t.isDefaultUITween=!0,t.maskAlpha=.8,
UIShowMgr.inst.OpenById(eUIComponentID.ElementItemShowStageUpView,this.CreateDelegate(this.OnLoadShowStageUpView),this.CreateDelegate(this.DestroyShowStageUpView),t)}HideBag(){
null!=this.view&&this.view.HideBag()}CloseEleShowStageUpView(){UIShowMgr.inst.CloseById(eUIComponentID.ElementItemShowStageUpView)}OnLoadShowStageUpView(t){
return null==this.viewShowUp&&(this.viewShowUp=new ElementItemCircelShowUpStageView,this.viewShowUp.setId(t,null,0)),this.viewShowUp}DestroyShowStageUpView(){
null!=this.viewShowUp&&(UIResMgr.DestroyUIObj(this.viewShowUp),this.viewShowUp=null)}S_Test(){return!0}}s.inst=null},20364:(t,e,i)=>{i.d(e,{D:()=>u})
var s=i(38836),n=i(98800),l=i(68662),a=i(95721),o=i(65550),r=i(35042),h=i(29109),d=i(64649)
class u{IsRecommendJobForAllRole(t){for(const[e,i]of(0,s.V5)(n.Y.Inst.primaryRoleInfoList))if(u.IsRecommendJob(i.Job_get(),t.cfgData_get().Jobs_get()))return!0
return!1}static IsRecommendJob(t,e){return u.IsWillJob(t,e)||u.IsWearJob(t,e)}static IsWillJob(t,e){if(null==e||0==e.Count())return!0
const i=h.I.GetChilds(t)
for(const[t,n]of(0,s.V5)(i))for(const[t,i]of(0,s.V5)(e))if(n==i)return!0
return!1}static IsWearJob(t,e){if(null==e||0==e.Count())return!0
const i=h.I.GetParents(t)
for(const[t,n]of(0,s.V5)(i))for(const[t,i]of(0,s.V5)(e))if(n==i)return!0
return!1}static GetUpScoreForRole(t,e){const i=e.GetElementRes(),s=i.elementType,n=i.score
let l=0
const a=t.GetElement(s)
return null!=a&&(l=a.GetElementRes().score),n-l}IsRecommendForAllRole(t){for(const[e,i]of(0,s.V5)(n.Y.Inst.primaryRoleInfoList))if(u.IsRecommendForRole(i,t))return!0
return!1}static IsRecommendForRole(t,e){
return!(!u.IsWillJob(t.Job_get(),e.cfgData_get().Jobs_get())&&!u.IsWearJob(t.Job_get(),e.cfgData_get().Jobs_get()))&&(!!d.$.Inst().GetTypeIsActive(e.GetElementRes().elementType,t)&&(u.GetUpScoreForRole(t,e)>0||void 0))
}static IsWearForRole(t,e){
return!(null!=e.serverData_get().deprecatedTime&&!e.serverData_get().deprecatedTime.Equal(a.o.ZERO)&&e.serverData_get().deprecatedTime.ToNum()<l.D.serverMSTime_get())&&(!!u.IsTakeOnLevel(t.Level_get(),e.cfgData_get().level,!1)&&!!u.IsTypeUnlick(t,e,!1))
}static IsTakeOnLevel(t,e,i){return null==i&&(i=!1),!(t<e)||(i&&o.y.inst.ClientSysMessage(r.X.Unconformity_Level),!1)}static IsTypeUnlick(t,e,i){const s=e.GetElementRes()
return null!=s&&d.$.Inst().GetTypeIsUnlock(s.elementType)}Test1(){return!0}S_Test(){return!0}}},64649:(t,e,i)=>{i.d(e,{$:()=>O})
var s=i(93984),n=i(38836),l=i(98800),a=i(97461),o=i(16812),r=i(55360),h=i(98130),d=i(85602),u=i(38962),c=i(70850),_=i(95272),I=i(3859),m=i(92679),g=i(33314),p=i(55492),C=i(14792),S=i(62734),f=i(60647),y=i(13487),v=i(20364)
class D{constructor(){this.type=0,this.val=0,this.star=!1}GetDes(){return"属性+0000"}Test1(){return!0}S_Test(){return!0}}var E=i(63076),T=i(37828),A=i(41864),L=i(33138)
class w{constructor(t,e,i){this.elementCarve=null,this.effective=!1,this.clientAnimation=!1,this.IsInited=!0,this.ItemCfg=null,this.CarveLvUpCfg=null,this.CarveCfg=null,
this.holdtype=-1,this.Subholdtype=-1,this.quality=0,this.Subholdtype=i||-1,this.holdtype=e||-1,null!=t&&(this.elementCarve=t.elementCarve,this.effective=t.effective,
this.clientAnimation=t.clientAnimation,t.elementCarve&&(this.ItemCfg=L.f.Inst().getItemById(t.elementCarve.modelId),this.quality=this.ItemCfg.quality,
this.CarveLvUpCfg=T.b.GetInst().GetLevelUpItemByKey(this.quality,this.elementCarve.stage,this.elementCarve.level),
this.CarveCfg=T.b.GetInst().GetEleCarveItemById(this.elementCarve.modelId)))}Init(t,e,i){this.elementCarve=null,this.effective=!1,this.IsInited=!1,this.ItemCfg=null,
this.CarveLvUpCfg=null,this.CarveCfg=null,this.holdtype=-1,this.Subholdtype=-1,this.quality=0,this.IsInited=!0,this.holdtype=e||-1,this.Subholdtype=i||-1,
null!=t&&(this.elementCarve=t.elementCarve,this.effective=t.effective,this.clientAnimation=t.clientAnimation,
t.elementCarve&&(this.ItemCfg=L.f.Inst().getItemById(t.elementCarve.modelId),this.quality=this.ItemCfg.quality,
this.CarveLvUpCfg=T.b.GetInst().GetLevelUpItemByKey(this.quality,this.elementCarve.stage,this.elementCarve.level),
this.CarveCfg=T.b.GetInst().GetEleCarveItemById(this.elementCarve.modelId)))}}class R{constructor(){this.type=0,this.itemdata=null,this.element=null,this.severElementHoldVo=null,
this.carveHoldItemMap=null,this.createIdx=0,this.init=!1,this.carveHoldItemMap=new u.X}IsLock(){return!O.Inst().GetTypeIsUnlock(this.type)}GetStarNum(){
return null!=this.element?this.element.GetStarNum():0}SetElement(t,e){if(this.severElementHoldVo=t,null!=this.severElementHoldVo){if(this.element=this.severElementHoldVo.element,
null!=this.element){const t=new E.M(this.element.modelId,this.element)
t.isEquiped=!0,this.itemdata=t}else this.itemdata=null
const t=this.severElementHoldVo.carveHoldMap
for(let e=1;e<=3;e++)this.carveHoldItemMap[e]?this.carveHoldItemMap[e].Init(t[e],this.type,e):this.carveHoldItemMap[e]=new w(t[e],this.type,e)}else this.element=null,
this.itemdata=null;(null==e||e)&&O.Inst().RaiseEvent(O.HOLE_VO_UPDATE,this)}GetEchoType(){let t=0,e=0,i=0,s=0,n=0
for(let l=1;l<=3;l++)3==this.carveHoldItemMap[l].quality?t+=1:4==this.carveHoldItemMap[l].quality?e+=1:5==this.carveHoldItemMap[l].quality&&(i+=1),
0==s&&null!=this.carveHoldItemMap[l].elementCarve&&(s=this.carveHoldItemMap[l].elementCarve.stage,n=this.carveHoldItemMap[l].elementCarve.level),
null!=this.carveHoldItemMap[l].elementCarve&&this.carveHoldItemMap[l].elementCarve.stage<s&&this.carveHoldItemMap[l].elementCarve.stage>0&&(s=this.carveHoldItemMap[l].elementCarve.stage,
n=this.carveHoldItemMap[l].elementCarve.level)
return[100*i+10*e+t,s,n]}GetEchoCfg(){const[t,e,i]=this.GetEchoType(),s=l.Y.Inst.GetMultiPlayerInfoByCreateIdx(this.createIdx)
return s&&t>0&&e>=0?T.b.GetInst().GetEchoItemByKeyAndLevel(s.Job_get(),t,e-1):null}GetLockDes(){const t=O.Inst().GetLocCfgByType(this.type)
return`${A.h.GetLevelStr(t.unlockLevel)}开启`}IsActive(){const t=l.Y.Inst.GetMultiPlayerInfoByCreateIdx(this.createIdx)
return O.Inst().GetTypeIsActive(this.type,t)}CanActive(){const t=l.Y.Inst.GetMultiPlayerInfoByCreateIdx(this.createIdx)
return O.Inst().GetTypeCanActive(this.type,t)}}class O extends o.k{constructor(){super(),this.csv=null,this.locCsv=null,this.stageCsv=null,this.stageMap=null,this.maxStageLv=0,
this.autoUnlockList=null,this.bagSelectType=0,this.bagData=null,this.typeList=null,this.roleEleItemDic=null,this.elementMaxAddScoreDic=null,this.tempElementMaxAddScoreDic=null,
this.redPointUp=null,this.curSelectIdx=0,this.curRoleUseDefaultTab=!1,this.topViewType=0,this.subViewType=-1,this.showBag=!1,this.needBag=!1,this.selectVo=null,
this.select_open_item_id=null,this.panelTweenEnd=!1,this.redList=null,this.csv=r.Y.Inst.GetOrCreateCsv(s.h.ElementResourceCsv),
this.locCsv=r.Y.Inst.GetOrCreateCsv(s.h.ElementHoleResourceCsv),this.stageCsv=r.Y.Inst.GetOrCreateCsv(s.h.ElementcirclestageresourceCsv),this.stageMap=new u.X,
this.autoUnlockList=new d.Z
for(const[t,e]of(0,n.V5)(this.stageCsv.map)){let t=null
const i=g.Z.GetJobBaranchBaseValue(e.job)
this.stageMap.LuaDic_ContainsKey(i)?t=this.stageMap.LuaDic_GetItem(i):(t=new d.Z,this.stageMap.LuaDic_AddOrSetItem(i,t)),t[e.stage]=e}for(const[t,e]of(0,
n.V5)(this.locCsv.m_mapCSV))1==e.autoUnlock&&this.autoUnlockList.Add(e.id)
this.autoUnlockList.Sort(this.CreateDelegate(this.OnSort))
for(const[t,e]of(0,n.V5)(this.stageMap)){this.maxStageLv=e.count-1
break}this.bagData=new d.Z,this.roleEleItemDic=new u.X,this.redPointUp=new d.Z}static Inst(){return null==O.inst&&(O.inst=new O),O.inst}OnSort(t,e){return t-e}SetBagShow(t){
this.showBag=t,this.RaiseEvent(O.BAG_STATE_UPDATE)}SetNeedBagShow(t){this.needBag=t,this.RaiseEvent(O.BAG_STATE_UPDATE)}IsBagShow(){return this.needBag&&this.showBag}ResetModel(){
this.typeList=null,this.select_open_item_id=null}SetBagSelectType(t){this.bagSelectType=t,this.RaiseEvent(O.BAG_TYPE_UPDATE)}AddLis(){
a.i.Inst.AddEventHandler(m.g.MULIT_ROLE_INFO_CHANGED,this.CreateDelegate(this.InitInfo)),a.i.Inst.AddEventHandler(m.g.FUNCTION_OPEN,this.CreateDelegate(this.InitInfo2)),
a.i.Inst.AddEventHandler(m.g.FUNCTION_INIT,this.CreateDelegate(this.InitInfo)),a.i.Inst.AddEventHandler(m.g.PLAYER_LEVELUP,this.CreateDelegate(this.UpdateLockRedState)),
a.i.Inst.AddEventHandler(m.g.ELEMENT_BAG_UPDATE,this.CreateDelegate(this.UpdateTakeOnRedState)),a.i.Inst.AddEventHandler(m.g.BAG_INITED,this.CreateDelegate(this.BagInit),1),
a.i.Inst.AddEventHandler(m.g.CHOOSE_SETTING_UPDATE,this.CreateDelegate(this.UpdateFirstEffRedState)),
a.i.Inst.AddEventHandler(m.g.PLAYER_LEVELUP,this.CreateDelegate(this.UpdateFirstEffRedState)),this.AddEventHandler(O.HOLE_ACTIVE,this.CreateDelegate(this.UpdateLockRedState)),
this.AddEventHandler(O.HOLE_ACTIVE,this.CreateDelegate(this.UpdateTakeOnRedState)),this.AddEventHandler(O.STAGE_UPDATE,this.CreateDelegate(this.UpdateLockSkillRedState)),
S.f.Inst.AddCallback(C.t.UI_ELEMENT_ITEM_CIRCLE_CAN_PLAYEFF,this.CreateDelegate(this.UpdateRoleRedState)),
S.f.Inst.AddCallback(C.t.UI_ELEMENT_ITEM_CIRCLE_ACTIVE,this.CreateDelegate(this.UpdateRoleRedState)),
S.f.Inst.AddCallback(C.t.UI_ELEMENT_ITEM_CIRCLE_SKILL_ACTIVE,this.CreateDelegate(this.UpdateRoleRedState)),
S.f.Inst.AddCallback(C.t.UI_ELEMENT_ITEM_CIRCLE_ADD,this.CreateDelegate(this.UpdateRoleRedState)),
this.redList=new d.Z([C.t.UI_ELEMENT_ITEM_CIRCLE_ACTIVE,C.t.UI_ELEMENT_ITEM_CIRCLE_CAN_PLAYEFF,C.t.UI_ELEMENT_ITEM_CIRCLE_SKILL_ACTIVE,C.t.UI_ELEMENT_ITEM_CIRCLE_ADD])}InitInfo(){
this.UpdateTakeOnRedState(),this.UpdateLockRedState(),this.UpdateLockSkillRedState(),this.UpdateFirstEffRedState()}InitInfo2(t){h.GF.INT(t)==p.x.ELEMENT_ITEM&&this.InitInfo()}
UpdateFirstEffRedState(){const t=l.Y.Inst.primaryRoleInfoList
for(let e=0;e<=t.count-1;e++){const t=O.Inst().GetTypeList(),i=t.Count()
let s=!1
for(let n=0;n<=i-1;n++){if(s=1==O.Inst().GetLocCfgByType(t[n]).autoUnlock&&this.GetTypeIsUnlock(t[n])&&this.ShowFirstEff(e),s)break}
S.f.Inst.SetState(C.t.UI_ELEMENT_ITEM_CIRCLE_CAN_PLAYEFF,s,e)}}UpdateRoleRedState(t,e,i,s){let n=!1
for(let t=0;t<=this.redList.count-1;t++){const e=S.f.Inst.GetData(this.redList[t])
if(null!=e&&(n=e.GetIsShowByRole(i)),n)break}S.f.Inst.SetState(C.t.UI_ELEMENT_ITEM_CIRCLE_ROLE,n,i)}UpdateLockSkillRedState(){const t=l.Y.Inst.primaryRoleInfoList
for(let e=0;e<=t.count-1;e++){const i=this.GetEleStageCsvByRoleInfo(t[e])
if(null!=i){const s=i.stage>t[e].GetElementInfoStage()
S.f.Inst.SetState(C.t.UI_ELEMENT_ITEM_CIRCLE_SKILL_ACTIVE,s,e)}}}HasUpRedPoint(t,e){const i=100*t+e
return this.redPointUp.Contains(i)}BagInit(){0!=c.g.Inst_get().GetBagDataList(_.t.ElementBag).count&&this.UpdateTakeOnRedState()}UpdateTakeOnRedState(){
const t=l.Y.Inst.primaryRoleInfoList
let e=0,i=100
this.redPointUp.Clear()
for(let s=0;s<=t.count-1;s++){const l=t[s].GetElementItemHoldMap()
let a=!1
if(null!=l)for(const[o,r]of(0,n.V5)(l)){let n=0
null!=r.element&&(n=r.element.GetElementRes().score)
this.HasUpElement(o,n,t[s])&&(this.redPointUp.Add(100*s+o),a||(e+=i,a=!0))}i=h.GF.INT(i/10),0==i&&(i=1)}this.SetRedState(e,C.t.UI_ELEMENT_ITEM_CIRCLE_ADD,t)}UpdateLockRedState(){
let t=0
const e=l.Y.Inst.primaryRoleInfoList,i=this.locCsv.GetCsvMap()
let s=100
for(let l=0;l<=e.count-1;l++){for(const[a,o]of(0,n.V5)(i))if(this.GetTypeIsUnlock(a)&&null==e[l].GetElementItemHold(a)){t=s+t
break}s=h.GF.INT(s/10),0==s&&(s=1)}this.SetRedState(t,C.t.UI_ELEMENT_ITEM_CIRCLE_ACTIVE,e)}SetRedState(t,e,i){let s=100
for(let n=0;n<=i.count-1;n++){const i=h.GF.INT(t/s)
S.f.Inst.SetState(e,1==i,n),t%=s,s=h.GF.INT(s/10),0==s&&(s=1)}}HasUpElement(t,e,i){new d.Z
const s=c.g.Inst_get().GetBagDataList(_.t.ElementBag)
for(let n=0;n<=s.Count()-1;n++)if(null!=s[n]){const l=s[n].baseData_get()
if(null!=l){const s=l.GetElementRes()
if(s.elementType==t&&v.D.IsWearJob(i.Job_get(),l.cfgData_get().Jobs_get())&&s.score>e)return!0}}return!1}GetBagShowDataListByType(t){let e=new d.Z
const i=c.g.Inst_get().GetBagDataList(_.t.ElementBag)
for(let s=0;s<=i.Count()-1;s++)if(null!=i[s]){const n=i[s].baseData_get()
if(null!=n){const l=n.GetElementRes()
null!=l&&(0!=t&&t!=l.elementType||e.Add(i[s]))}}const s=c.g.Inst_get().GetColumnByBagType(_.t.ElementBag)
e=c.g.Inst_get().GetShowListByClient(e,s)
let n=e.Count()
for(;n<i.Count();)e.Add(null),n+=1
return e}GetTypeList(){if(null==this.typeList){this.typeList=new d.Z
const t=this.locCsv.GetCsvMap()
for(const[e,i]of(0,n.V5)(t))this.typeList.Add(e)
this.typeList.Sort(this.CreateDelegate(this.SortList))}return this.typeList}SortList(t,e){return t<e?-1:t>e?1:0}ShowFirstEff(t){
let e=f.p.inst.GetClientLogicSetting(y.R.FIRST_OPEN_ELEMENTITEM_CILCEL)
return null==e&&(e=0),0==t?e%10==0:1==t?0==h.GF.INT(e%100/10):2==t&&e<100}RecordShowFirstEff(t){if(!this.ShowFirstEff(t))return
let e=f.p.inst.GetClientLogicSetting(y.R.FIRST_OPEN_ELEMENTITEM_CILCEL)
null==e&&(e=0),0==t?e+=1:1==t?e+=10:2==t&&(e+=100),f.p.inst.SendClientLogicSetting(y.R.FIRST_OPEN_ELEMENTITEM_CILCEL,e,!1),this.UpdateFirstEffRedState()}GetLocCfgByType(t){
const e=this.locCsv.GetCsvMap()
return e.LuaDic_ContainsKey(t)?e[t]:null}IsCanWear(t){return!!this.IsElementItem(t)}IsElementItem(t){return null!=t&&null!=t.cfgData_get()&&t.cfgData_get().itemType==I.q.ELEMENT}
GetEleStage(t){const e=this.GetEleStageCsvByStarNum(this.GetEleStageStar(t),t.Job_get())
return null==e?0:e.stage}GetEleAllAttr(t){if(null==t)return null
const e=new d.Z,i=this.GetHoldMapByRoleInfo(t),s=new u.X,l=new u.X
for(const[t,e]of(0,n.V5)(i))if(null!=e.element){const t=e.element.GetElementRes()
for(const[e,i]of(0,n.V5)(t.elementAttrsDic))s.LuaDic_ContainsKey(e)?s[e]=s[e]+i:s[e]=i
for(const[e,i]of(0,n.V5)(t.attrsDic))s.LuaDic_ContainsKey(e)?s[e]=s[e]+i:s[e]=i
if(null!=e.element.starAttributes){const t=e.element.starAttributes
for(const[e,i]of(0,n.V5)(t))l.LuaDic_ContainsKey(e)?l[e]=l[e]+i:l[e]=i}}for(const[t,i]of(0,n.V5)(l)){const s=new D
s.type=t,s.val=i,s.star=!0,e.Add(s)}for(const[t,i]of(0,n.V5)(s)){const s=new D
s.type=t,s.val=i,s.star=!1,e.Add(s)}return e}GetEleStageStar(t){if(null==t)return 0
const e=this.GetHoldMapByRoleInfo(t)
if(null==e)return 0
let i=0
for(const[t,s]of(0,n.V5)(e))null!=s.element&&(i+=s.element.GetStarNum())
return i}GeCurEleStageCsvByRoleInfo(t){const e=this.GetEleStageCsvByStarNum(this.GetEleStageStar(t),t.Job_get())
return e.stage>t.GetElementInfoStage()?this.GetEleStageCsv(t.GetElementInfoStage(),null):e}GetEleStageCsvByRoleInfo(t){
return this.GetEleStageCsvByStarNum(this.GetEleStageStar(t),t.Job_get())}GetShowEleStageCsvByRoleInfo(t){this.GetEleStageStar(t)
const e=this.GetEleStageCsvByStarNum(this.GetEleStageStar(t),t.Job_get())
return e.stage>t.GetElementInfoStage()?this.GetEleStageCsv(t.GetElementInfoStage(),t.Job_get()):e}GetEleStageCsv(t,e){const i=g.Z.GetJobBaranchBaseValue(e)
if(this.stageMap.LuaDic_ContainsKey(i)){return this.stageMap.LuaDic_GetItem(i)[t]}return null}GetUnlockStage(t){return t.GetElementInfoStage()}IsMaxStage(t){
return t==this.maxStageLv}GetEleStageCsvByStarNum(t,e){let i=null
const s=g.Z.GetJobBaranchBaseValue(e)
if(this.stageMap.LuaDic_ContainsKey(s)){const e=this.stageMap.LuaDic_GetItem(s)
for(let s=0;s<=e.count-1&&!(e[s].needStar>t);s++)i=e[s]}return i}GetSelectRoleInfo(){return l.Y.Inst.GetMultiPlayerInfoByCreateIdx(this.curSelectIdx)}GetHoldMapByRoleInfo(t){
return t.GetElementItemHoldMap()}GetElementItemHoleVO(t,e){if(this.roleEleItemDic.LuaDic_ContainsKey(t))return this.roleEleItemDic[t][e-1]}GetCarveItemHoldVo(t,e,i){
if(this.roleEleItemDic.LuaDic_ContainsKey(t))return this.roleEleItemDic[t][e-1].carveHoldItemMap[i]}GetElementItemHoleVOList(t){const e=this.GetHoldMapByRoleInfo(t)
let i=null
const s=this.GetTypeList(),n=s.Count()
this.roleEleItemDic.LuaDic_ContainsKey(t.createIdx)?i=this.roleEleItemDic.LuaDic_GetItem(t.createIdx):(i=new d.Z(n),this.roleEleItemDic.LuaDic_AddOrSetItem(t.createIdx,i))
for(let l=0;l<=n-1;l++){const n=s[l]
let a=i[l]
null==a&&(a=new R,i[l]=a),a.type=n,a.createIdx=t.createIdx,null!=e?a.SetElement(e[n],null):a.SetElement(null,null),a.init=!0}return i}GetElementHoldVO(t,e){
return t.GetElementItemHold(e)}GetElement(t,e){return t.GetElement(e)}GetElementResById(t){return this.csv.GetRes(t)}GetTypeIsUnlock(t){const e=this.GetLocCfgByType(t)
return l.Y.Inst.PrimaryRoleInfo_get().Level_get()>=e.unlockLevel}GetTypeIsActive(t,e){return null!=this.GetElementHoldVO(e,t)}GetTypeCanActive(t,e){
return this.GetTypeIsUnlock(t)&&!this.GetTypeIsActive(t,e)}GetFixRoleCIdx(t){const e=this.GetFixRole(t)
return null!=e?e.createIdx:null}GetFixRole(t){const e=l.Y.Inst.primaryRoleInfoList
let i=0,s=null
for(let n=0;n<=e.count-1;n++)if(v.D.IsWearJob(e[n].Job_get(),t.cfgData_get().Jobs_get())){const l=t.GetElementRes().elementType
if(null==e[n].GetElement(l))return e[n]
const a=v.D.GetUpScoreForRole(e[n],t);(a>i||null==s)&&(i=a,s=e[n])}return s}GetFixTipsRole(t,e){if(this.CheckIsTipsRecommend(t,e))return t
const i=l.Y.Inst.primaryRoleInfoList
for(let s=0;s<=i.count-1;s++){const n=i[s]
if(null!=t&&t.createIdx==n.createIdx);else if(this.CheckIsTipsRecommend(n,e))return n
null==t&&(t=n)}return t}CheckIsTipsRecommend(t,e){if(null!=t&&v.D.IsWearJob(t.Job_get(),e.cfgData_get().Jobs_get())&&v.D.IsWearForRole(t,e)){const i=e.GetElementRes().elementType
if(null==t.GetElement(i))return!0}return!1}UpdateMaxElementScoreGroup(){null==this.tempElementMaxAddScoreDic&&(this.tempElementMaxAddScoreDic=new u.X),
null==this.elementMaxAddScoreDic&&(this.elementMaxAddScoreDic=new u.X),this.tempElementMaxAddScoreDic.Clear(),this.elementMaxAddScoreDic.Clear()
const t=c.g.Inst_get().GetBagDataList(_.t.ElementBag)
for(let e=0;e<=t.Count()-1;e++)if(null!=t[e]&&null!=t[e].baseData_get()){const i=t[e].baseData_get()
let s=O.Inst().GetSelectRoleInfo()
if(null==s&&(s=l.Y.Inst.PrimaryRoleInfo_get()),this.IsMatchElementScore(s,i)&&null!=i.serverData_get()){const t=v.D.GetUpScoreForRole(s,i)
if(t>0){let e=null
e=v.D.IsWearJob(s.Job_get(),i.cfgData_get().Jobs_get())?`${s.Job_get()}.${i.GetElementRes().elementType}..0`:`${s.Job_get()}.${i.GetElementRes().elementType}..1`
const n=i.serverData_get().id
if(this.tempElementMaxAddScoreDic.LuaDic_ContainsKey(e)){const i=this.tempElementMaxAddScoreDic[e]
if(this.elementMaxAddScoreDic.LuaDic_ContainsKey(i)){this.elementMaxAddScoreDic[i]<t&&(this.elementMaxAddScoreDic.LuaDic_Remove(i),this.tempElementMaxAddScoreDic[e]=n,
this.elementMaxAddScoreDic.LuaDic_AddOrSetItem(n,t))}else this.elementMaxAddScoreDic.LuaDic_Remove(i),this.tempElementMaxAddScoreDic[e]=n,
this.elementMaxAddScoreDic.LuaDic_AddOrSetItem(n,t)}else this.tempElementMaxAddScoreDic.LuaDic_Add(e,n),
this.elementMaxAddScoreDic.LuaDic_ContainsKey(n)?t>this.elementMaxAddScoreDic[n]&&this.elementMaxAddScoreDic.LuaDic_AddOrSetItem(n,t):this.elementMaxAddScoreDic.LuaDic_AddOrSetItem(n,t)
}}}}GetRoleListById(t){const e=h.GF.INT(t%1e6/1e5),i=l.Y.Inst.primaryRoleInfoList,s=new d.Z
for(let t=0;t<=i.count-1;t++)(0==e||e==g.Z.GetJobBranch(i[t].Job_get()))&&s.Add(i[t])
return s}IsMatchElementScore(t,e){const i=this.GetElementResById(e.modelId_get())
if(!this.GetTypeIsUnlock(i.elementType))return!1
const s=t.Job_get(),n=e.cfgData_get().Jobs_get()
return!(!v.D.IsWillJob(s,n)&&!v.D.IsWearJob(s,n))}}O.inst=null,O.UI_ELEMENT_ITEM=0,O.UI_ELEMENT_Cavre=1,O.UI_ELEMENT_ITEM_SUB_CIRCEL=0,O.UI_ELEMENT_ITEM_SUB_ENCHACE=1,
O.UI_ELEMENT_ITEM_SUB_Compound=2,O.UI_ELEMENT_Carve_SUB_Carve=0,O.SELECT_HOLE="SELECT_HOLE",O.BAG_STATE_UPDATE="BAG_STATE_UPDATE",O.HOLE_ACTIVE="HOLE_ACTIVE",
O.STAR_UPDATE="STAR_UPDATE",O.STAGE_UPDATE="STAGE_UPDATE",O.FLY_STAR_END="FLY_STAR_END",O.BAG_TYPE_UPDATE="BAG_TYPE_UPDATE",O.HOLE_VO_UPDATE="HOLE_VO_UPDATE",
O.ELEMENT_BAG_HIDE="ELEMENT_BAG_HIDE",O.ELEMENT_BATTLE_SCORE_UPDATE="ELEMENT_BATTLE_SCORE_UPDATE",O.ELEMENT_UNLOCK_EFF_END="ELEMENT_UNLOCK_EFF_END"},65048:(t,e,i)=>{
var s,n,l,a=i(42292),o=i(71409),r=i(92415),h=i(84632)
function d(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}s=(0,o.GH)(r.k.SM_MailNumInfo),l=class t{constructor(){this._degf_MailNumInfoHandler=null,
this._degf_MailNumInfoHandler=t=>this.MailNumInfoHandler(t),this.RegistProtocol()}static GetInst(){return null==t._inst&&(t._inst=new t),t._inst}RegistProtocol(){}
MailNumInfoHandler(t){const e=t
null!=e&&h.R.GetInst().HandleMailNum(e.unreadMailNum)}},l._inst=null,d(n=l,"GetInst",[a.n],Object.getOwnPropertyDescriptor(n,"GetInst"),n),
d(n.prototype,"MailNumInfoHandler",[s],Object.getOwnPropertyDescriptor(n.prototype,"MailNumInfoHandler"),n.prototype)},96058:(t,e,i)=>{i.d(e,{r:()=>v})
var s=i(38836),n=i(38935),l=i(56937),a=i(31222),o=i(5494),r=i(52726),h=i(85602),d=i(63076),u=i(59686),c=i(3859),_=i(33772),I=i(46322),m=i(49490),g=i(9986),p=i(61911),C=i(59918),S=i(75696)
class f extends p.f{constructor(...t){super(...t),this.closeBtn=null,this.closeBtn2=null,this.ui_baseitem=null,this.model=null}InitView(){super.InitView(),
this.closeBtn=this.CreateComponent(g.W,1),this.closeBtn2=this.CreateComponent(g.W,2),this.ui_baseitem=this.CreateComponentBinder(S.j,3),this.model=m.p.Inst()}OnAddToScene(){
this.InitHandlerMgr(),this.AddLis()
const t=this.model.GetSelectMainEquip(),e=new d.M(t.modelId_get(),t.serverData_get())
e.isCanOperate=!1
if(t.cfgData_get().itemType==c.q.EQUIPMENT){const i=t.equipRes_get()
i.equipType!=C.R.ANGEL_SUBWEAPON&&i.equipType!=C.R.ANGEL_SUBWEAPON&&(e.previewNextEquipNum=1)}this.ui_baseitem.SetData(e)}AddLis(){
this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.Close)),this.m_handlerMgr.AddClickEvent(this.closeBtn2,this.CreateDelegate(this.Close))}RemoveLis(){}Close(){
v.Inst().CloseEquipAdvancePeekView()}Clear(){this.RemoveLis(),super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}}var y=i(16945)
class v{constructor(){this._degf_SM_EquipExcellentLevelUpHandle=null,this.AddLis()}static Inst(){return null==v._inst&&(v._inst=new v),v._inst}AddLis(){
this._degf_SM_EquipExcellentLevelUpHandle=t=>this.SM_EquipExcellentLevelUpHandle(t)}ReqEquipAdvance(){const t=new _.I,e=m.p.Inst().GetSelectMainEquip()
t.equipObjId=e.serverData_get().id
const i=m.p.Inst().GetSelectCostDic(),l=new h.Z
for(const[t,e]of(0,s.V5)(i)){const t=e.bagItemDataList
if(e.type==c.q.EQUIPMENT)for(let e=0;e<=t.Count()-1;e++)l.Add(t[e].serverData_get().id)}t.consumeIds=l,n.C.Inst.F_SendMsg(t)}SM_EquipExcellentLevelUpHandle(t){
const e=t,i=e.equipment
if(m.p.Inst().showEquipment=i,this.RemoveAllSelectCostItem(),e.success){const t=new d.M(i.modelId,i)
t.isShowAccess=!1,t.isForBag=!1,t.isEquipCompare=!1,t.isNoBagItemData=!0,t.isShowMask=!1,t.isAutoTipsClose=!1,t.tipPosType=u.l.RyEquipAdvance,t.unSelect=!0,
this.SetSelectMainEquip(t),this.OpenEquipAdvanceSuccessView()}else this.SetSelectMainEquip(null)
m.p.Inst().RaiseEvent(I.z.EQUIP_ADVANCE_SUCCESS,e.success)}S_Test(){return!0}SetSelectMainEquip(t){m.p.Inst().SetSelectMainEquip(t)}AddSelectCostItem(t){m.p.Inst().AddSelectCost(t)
}RemoveSelectCostItem(t){m.p.Inst().RemoveSelectCost(t)}RemoveAllSelectCostItem(){m.p.Inst().RemoveAllSelectCost()}OpenEquipAdvancePeekView(){const t=new l.v
t.layerType=r.F.Alert,t.isShowMask=!0,t.viewClass=f,a.N.inst.OpenById(o.I.RyEquipAdvance,null,null,t)}CloseEquipAdvancePeekView(){a.N.inst.CloseById(o.I.RyEquipAdvance)}
OpenEquipAdvanceSuccessView(){const t=new l.v
t.layerType=r.F.Alert,t.isShowMask=!0,t.viewClass=y.m,a.N.inst.OpenById(o.I.RyEquipAdvanceSuccess,null,null,t)}CloseEquipAdvanceSuccessView(){
a.N.inst.CloseById(o.I.RyEquipAdvanceSuccess)}}v._inst=null},46322:(t,e,i)=>{i.d(e,{z:()=>s})
class s{}s.UPDATE_SELECT_MAIN_EQUIP="UPDATE_SELECT_MAIN_EQUIP",s.UPDATE_SELECT_COST="UPDATE_SELECT_COST",s.EQUIP_ADVANCE_SUCCESS="EQUIP_ADVANCE_SUCCESS",
s.EQUIP_ADVANCE_SELECT="EQUIP_ADVANCE_SELECT",s.EQUIP_STARADVANCE_SUCCESS="EQUIP_STARADVANCE_SUCCESS"},49490:(t,e,i)=>{i.d(e,{p:()=>S})
var s=i(93984),n=i(38836),l=i(90419),a=i(50089),o=i(16812),r=i(55360),h=i(98885),d=i(85602),u=i(38962),c=i(1240),_=i(70850),I=i(59686),m=i(63456)
class g{constructor(){this.num=0,this.type=0,this.bagItemDataList=null,this.bagItemDataList=new d.Z}Clear(){this.bagItemDataList.Clear(),this.bagItemDataList=null}
AddBagItemData(t){this.bagItemDataList.Add(t),this.CalNum()}RemoveBagItemData(t){this.bagItemDataList.Remove(t),this.CalNum()}CalNum(){this.num=0
const t=new d.Z
for(let e=0;e<=this.bagItemDataList.Count()-1;e++)if(null!=this.bagItemDataList[e]&&this.bagItemDataList[e].serverData_get()){const i=this.bagItemDataList[e].serverData_get()
this.num+=i.num,t.Add(this.bagItemDataList[e])}return this.bagItemDataList.Clear(),this.bagItemDataList=t,this.num}}var p=i(46322)
class C{constructor(){this.baseItemData=null,this.type=C.BAG_MAIN_EQUIP_SHOW}IsInLeftBag(){return this.type==C.BAG_MAIN_EQUIP_SHOW||this.type==C.BAG_COST_SHOW}}
C.BAG_MAIN_EQUIP_SHOW=0,C.SELECT_MAIN_EQUIP_SHOW=1,C.SELECT_COST_SHOW=2,C.BAG_COST_SHOW=3
class S extends o.k{constructor(){super(),this.selectMainEquip=null,this.selectCostDic=null,this.isInResultView=!1,this.csvMap=null,this.equipAdvanceResDic=null,this.costMap=null,
this.costEquipMap=null,this.costIdDic=null,this.selectCostDic=new u.X
const t=r.Y.Inst.GetOrCreateCsv(s.h.eEquipAdvanceResource)
this.csvMap=t.GetCsvMap(),this.equipAdvanceResDic=new u.X,this.costMap=new u.X,this.costEquipMap=new u.X
for(const[t,e]of(0,n.V5)(this.csvMap)){new u.X
const t=l.d.parseJsonObjectWithFix(e.consumesItem,"costs"),i=new u.X,s=new u.X,o=a.t.decode(t,m.d)
o.Parse()
for(const[t,e]of(0,n.V5)(o.costs)){const t=h.M.String2Int(e.subtype),s=h.M.String2Int(e.subvalue)
i.LuaDic_AddOrSetItem(t,s)}const r=new d.Z(e.consumesEquip)
for(let t=0;t<=r.Count()-1;t++){const e=r[t]
s.LuaDic_AddOrSetItem(e,1)}const c=new d.Z(e.equip)
for(let t=0;t<=c.Count()-1;t++)this.costMap.LuaDic_AddOrSetItem(c[t],i),this.costEquipMap.LuaDic_AddOrSetItem(c[t],s),this.equipAdvanceResDic.LuaDic_AddOrSetItem(c[t],e)}}
static Inst(){return null==S._inst&&(S._inst=new S),S._inst}ResetViewData(){this.selectMainEquip=null
for(const[t,e]of(0,n.V5)(this.selectCostDic))e.Clear(),e=null
this.selectCostDic.Clear()}GetItemByEquipId(t){return this.equipAdvanceResDic[t]}GetCombineTab(){const t=new d.Z,e=new d.Z
for(const[i,s]of(0,n.V5)(this.csvMap))t.Contains(s.type)||(t.Add(s.type),e.Add(s))
return e.Sort(S.SortTab),e}static SortTab(t,e){return t.index-e.index}GetCfgById(t){return this.csvMap[t]}GetAdvanceEquipListInBag(t){const e=new d.Z,i=_.g.Inst_get().GetAllItem()
for(const[s,l]of(0,n.V5)(i)){const i=new c.Y
if(i.Clone(l),null!=i.baseData_get()){const s=i.baseData_get().cfgData_get().id,n=this.GetItemByEquipId(s)
if(null!=n&&n.type==t){const t=new C
t.type=0,t.baseItemData=i.baseData_get(),t.baseItemData.isForBag=!1,t.baseItemData.isShowAccess=!1,t.baseItemData.isEquipCompare=!1,t.baseItemData.isNoBagItemData=!0,
t.baseItemData.isShowMask=!1,t.baseItemData.isAutoTipsClose=!1,t.baseItemData.tipPosType=I.l.RyEquipAdvance,t.baseItemData.unSelect=!0,e.Add(t)}}}return e}GetCostItemListInBag(t){
const e=new d.Z,i=_.g.Inst_get().GetBagDataList(),s=t.cfgData_get().id
if(null!=t){const l=this.costMap[s],a=this.costEquipMap[s]
if(null!=a)for(const[s,o]of(0,n.V5)(i)){const i=new c.Y
if(i.Clone(o),null!=i.baseData_get()){const s=i.baseData_get().cfgData_get().id,n=this.selectCostDic[s],o=new u.X
if(null!=n)for(let t=0;t<=n.bagItemDataList.Count()-1;t++){o[n.bagItemDataList[t].serverData_get().id]=!0}const r=i.serverData_get().Id_get()
if((a.LuaDic_ContainsKey(s)||l.LuaDic_ContainsKey(s))&&!r.Equal(t.serverData_get().Id_get())&&!o[r]){const t=new C
t.type=C.BAG_COST_SHOW,i.baseData_get().isShowAccess=!1,i.baseData_get().isForBag=!1,i.baseData_get().isEquipCompare=!1,i.baseData_get().isNoBagItemData=!0,
i.baseData_get().isShowMask=!1,i.baseData_get().isAutoTipsClose=!1,i.baseData_get().tipPosType=I.l.RyEquipAdvance,i.baseData_get().unSelect=!0,t.baseItemData=i.baseData_get(),
e.Add(t)}}}}else for(const[t,s]of(0,n.V5)(i)){const t=new c.Y
if(t.Clone(s),null!=t.baseData_get()){const i=t.baseData_get().cfgData_get().id
if(this.costIdDic.LuaDic_ContainsKey(i)){const i=new C
i.type=C.BAG_MAIN_EQUIP_SHOW,t.baseData_get().isForBag=!1,t.baseData_get().isShowAccess=!1,t.baseData_get().isEquipCompare=!1,t.baseData_get().isNoBagItemData=!0,
t.baseData_get().isShowMask=!1,t.baseData_get().isAutoTipsClose=!1,t.baseData_get().tipPosType=I.l.RyEquipAdvance,t.baseData_get().unSelect=!0,i.baseItemData=t.baseData_get(),
e.Add(i)}}}return e}SetSelectMainEquip(t){this.isInResultView=!1,this.selectMainEquip=t,null==t&&this.RemoveAllSelectCost(),this.RaiseEvent(p.z.UPDATE_SELECT_MAIN_EQUIP)}
GetSelectMainEquip(){return this.selectMainEquip}AddSelectCost(t){if(this.isInResultView)return
const e=t.cfgData_get().id
if(this.CheckCanPutInCostList(t)){let i=this.selectCostDic[e]
null==i&&(this.selectCostDic[e]=new g,i=this.selectCostDic[e],i.type=t.cfgData_get().itemType),i.AddBagItemData(t)}this.RaiseEvent(p.z.UPDATE_SELECT_COST)}RemoveSelectCost(t){
const e=t.baseItemData,i=e.cfgData_get().id
let s=this.selectCostDic[i]
null!=s&&s.RemoveBagItemData(e),null!=s&&0!=s.num||(null!=s&&s.Clear(),s=null,this.selectCostDic[i]=null),this.RaiseEvent(p.z.UPDATE_SELECT_COST)}RemoveAllSelectCost(){
this.selectCostDic.Clear(),this.RaiseEvent(p.z.UPDATE_SELECT_COST)}GetSelectCostDic(){return this.selectCostDic}CheckCanPutInCostList(t){
const e=this.selectMainEquip.cfgData_get().id,i=this.costMap[e],s=this.costEquipMap[e],l=this.GetItemByEquipId(e),a=t.cfgData_get().id
for(const[t,e]of(0,n.V5)(i))if(a==t){const t=this.selectCostDic[a]
if(null==t||t.num<e)return!0}let o=0
for(const[t,e]of(0,n.V5)(s)){const e=this.selectCostDic[t]
null!=e&&(o+=e.num)}return!!(o<l.consumesNum&&s[a])}CheckEnoughToAdvance(){const t=this.selectMainEquip.cfgData_get().id,e=this.costMap[t]||new u.X,i=this.costEquipMap[t]||new u.X
for(const[t,i]of(0,n.V5)(e)){const e=this.selectCostDic[t]
if(null==e||e.num<i)return t}let s=0
for(const[t,e]of(0,n.V5)(i)){const e=this.selectCostDic[t]
null!=e&&(s+=e.num)}return s<this.GetItemByEquipId(t).consumesNum?-1:0}GetEquipCostByMainItemId(t){return this.costEquipMap[t]||new u.X}GetItemCostByMainItemId(t){
return this.costMap[t]||new u.X}}S._inst=null},68579:(t,e,i)=>{i.d(e,{n:()=>l})
var s=i(83908),n=i(9057)
class l extends((0,s.pA)(n.x)()){constructor(...t){super(...t),this._degf_OnDragEnd=null,this.dropItem=null}InitView(){super.InitView(),
this._degf_OnDragEnd=(t,e)=>this.OnDragEnd(t,e)}SetData(){}OnDragEnd(t,e){}Clear(){super.Clear()}Destroy(){super.Destroy(),this._degf_OnDragEnd=null}Test1(){return!0}S_Test(){
return!0}}},5590:(t,e,i)=>{i.d(e,{m:()=>A})
var s=i(50089),n=i(99294),l=i(72005),a=i(61911),o=i(31222),r=i(60130),h=i(81973),d=i(92679),u=i(13309),c=i(38836),_=i(6665),I=i(9776),m=i(93877),g=i(51868),p=i(85602),C=i(63076),S=i(75696),f=i(87923),y=i(14666),v=i(52394),D=i(65235),E=i(90560)
class T extends g.${constructor(...t){super(...t),this.ui_baseitem=null,this.propertyScrollView=null,this.propertyGrid=null,this.equipName=null,this.model=null}InitView(){
super.InitView(),this.ui_baseitem=this.CreateComponentBinder(S.j,1),this.propertyScrollView=this.CreateComponent(I.h,2),this.propertyGrid=this.CreateComponent(_.A,3),
this.equipName=this.CreateComponent(m.Q,4),this.propertyGrid.SetInitInfo("ui_ry_equipadvance_excellenceAttrItem",null,D.k),
this.propertyGrid.OnReposition_set(this.CreateDelegate(this.OnGridReposition)),this.model=u.g.Inst_get()}SetData(t,e){const i=this.model.lastSelectEquipId,s=new C.M(t.modelId,t)
s.playerIdxSet(E.U.Inst().GetSelectRoleInfo().createIdx),s.isCanOperate=!1,s.maskThrough=!1,s.isShowMask=!1,s.targetRoleInfo=E.U.Inst().GetSelectRoleInfo()
let n=!1
i&&t.modelId!=i&&(n=!0)
const l=t.GetEquipRes(),a=l.excellenceNum,o={}
if(n&&a>0){const t=this.model.oldShowEquipment
if(a-l.fixExcellenceAttrs_get().attrs.Count()<=0)for(const[e,i]of(0,c.V5)(t.exellectAttrs.attributes))o[i.attributeType]=!0}
const r=s.equipInfo_get(),h=s.cfgData_get(),d=s.GetSuitEq()
s.isShowMask=!1
const u=f.l.SetEquipName(r,h,t,d,!0,!0,0,!0)
this.equipName.textSet(u[0]),this.ui_baseitem.SetData(s)
const _=new p.Z,I=t.exellectAttrs.attributeDatas,m=I.Count()
for(let e=0;e<=m-1;e++){let i="[5FB470]"
const s=I[e]
i+=`卓越（${f.l.getAttrStr(s.type,!1)}${f.l.getAttrValueStr(s.type,s.value,!s.isPercentage)}）[-]`
const l=new v.E
l.str=i,l.isNew=!1,l.isStar=y.g.Inst().GetShowExcellenceStar(s.type,s.value,t.GetItemRes().equipStepLv),e==m-1&&n&&!o[s.type]&&(l.isNew=!0),_.Add(l)}this.propertyGrid.data_set(_)}
OnGridReposition(){this.propertyScrollView.ResetPosition()}Clear(){this.propertyGrid.Clear(),super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}}
class A extends a.f{constructor(...t){super(...t),this.ui_ry_equipadvance_show1=null,this.ui_ry_equipadvance_show2=null,this.ui_angel_eq_show_item=null,this.maskLayer=null,
this.rightBg=null,this.leftBg=null,this.leftAnchor=null,this.rightAnchor=null,this.model=null}InitView(){super.InitView(),
this.ui_ry_equipadvance_show1=this.CreateComponentBinder(T,1),this.ui_ry_equipadvance_show2=this.CreateComponentBinder(T,2),
this.ui_angel_eq_show_item=this.CreateComponentBinder(h.D,3),this.maskLayer=this.CreateComponent(n.z,4),this.rightBg=this.CreateComponent(l.w,5),
this.leftBg=this.CreateComponent(l.w,6),this.leftAnchor=this.CreateComponent(n.z,7),this.rightAnchor=this.CreateComponent(n.z,8),this.UpdateAnchor(),this.model=u.g.Inst_get(),
this.AddFullScreenCollider(this.node,this.CreateDelegate(this.Close))}UpdateAnchor(){r.O.SetAnchorPos(this.leftAnchor,!0,!1,0,!1),r.O.SetAnchorPos(this.rightAnchor,!1,!1,0,!1)
const t=s.t.GetUIWidth()
let e=0
e=t>=1280?(t-1280)/2:(1280-t)/2,this.rightBg.widthSet(e+979),this.leftBg.widthSet(e+300)}AddLis(){
this.m_handlerMgr.AddEventMgr(d.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchor))}RemoveLis(){}OnAddToScene(){this.AddLis()
const t=this.model.showEquipment,e=this.model.oldShowEquipment
this.ui_angel_eq_show_item.ShowBlomEff(),this.ui_angel_eq_show_item.SetData(t),this.ui_ry_equipadvance_show1.SetData(e,t),this.ui_ry_equipadvance_show2.SetData(t)}Clear(){
this.RemoveLis(),this.ui_angel_eq_show_item.Clear(),this.ui_ry_equipadvance_show1.Clear(),this.ui_ry_equipadvance_show2.Clear(),super.Clear()}Destroy(){
this.RemoveFullScreenCollider(this.node.FatherId),super.Destroy()}Close(){o.N.inst.ClosePanel()}Test1(){return!0}S_Test(){return!0}}},10831:(t,e,i)=>{i.d(e,{g:()=>u})
var s=i(18998),n=i(38836),l=i(66788),a=i(18202),o=i(85602),r=i(38962),h=i(59075),d=i(48933)
class u{static __StaticInit(){}constructor(){this.item_pool=null,this.COLUMN_CNT=6,this.ROW_CNT=5,this.SPACE=6,this.ITEM_SIZE=70,this.ICON_SIZE=66.5,this.ICON_MAX_CNT=4,
this.CAPACITY=300,this.MIN_CAPACITY=100,this.CAPACITY_FIT_ITEMLIST=!0,this.grid=null,this.grid_bg=null,this.bar=null,this.scroll_view=null,this.item_datas=null,
this.show_item_dict=null,this.m_handlerMgr=null,this.m_ItemPath=null,this.m_ItemCls=null,this.item_pool=new o.Z,this.show_item_dict=new r.X}Init(t,e,i,s,n,l,a){this.m_handlerMgr=t,
this.grid=e,this.grid_bg=i,this.bar=s,this.scroll_view=n,this.m_ItemPath=l,this.m_ItemCls=a}InitLayoutParam(t,e,i,s,n,l,a){
[this.COLUMN_CNT,this.ROW_CNT,this.SPACE,this.ITEM_SIZE,this.ICON_SIZE,this.MIN_CAPACITY,this.CAPACITY_FIT_ITEMLIST]=[t,e,i,s,n,l,a],l&&this.SetCapatity(l)}SetData(t){
const e=this.GetShowListByClient(t)
this.item_datas=e,null!=this.bar&&this.scroll_view.scrollTo(s.Vec2.ZERO),this.Update()}SetCapatity(t){this.MIN_CAPACITY&&t<this.MIN_CAPACITY&&(t=this.MIN_CAPACITY),this.CAPACITY=t
const e=new o.Z
for(let i=1;i<=t;i++)e.Add(i)
this.grid_bg.data_set(e)}PutIn(t,e,i,s,n){const l=h.u.SHAPE_DEFINE.LuaDic_GetItem(e)[0]-1,a=h.u.SHAPE_DEFINE.LuaDic_GetItem(e)[1]-1
s[i]=t
for(let t=0;t<=l;t++)for(let e=0;e<=a;e++)(t>0||e>0)&&(s[i+t+e*n]=1)}CanPutIn(t,e,i,s){const n=h.u.SHAPE_DEFINE.LuaDic_GetItem(t)[0]-1,l=h.u.SHAPE_DEFINE.LuaDic_GetItem(t)[1]-1
if(e%s+n>=s)return!1
for(let t=0;t<=n;t++)for(let n=0;n<=l;n++)if(null!=i[e+t+n*s])return!1
return!0}GetShowListByClient(t){const e=new o.Z
let i=0,s=0
this.CAPACITY_FIT_ITEMLIST&&(this.CAPACITY=999999)
for(let n=0;n<=t.Count()-1;n++){const a=t[n]
if(null!=a){let t
for(t=a.shape_get?a.shape_get():null!=a.baseItemData?a.baseItemData.cfgData_get().shape:0,i=0;i<this.CAPACITY&&0==this.CanPutIn(t,i,e,this.COLUMN_CNT);)i+=1
i<this.CAPACITY?(s<i&&(s=i),this.PutIn(a,t,i,e,this.COLUMN_CNT)):l.Y.LogWarning(" some item not show")}}if(this.CAPACITY_FIT_ITEMLIST){e.Count()-1>i&&(s=e.Count()-1)
const t=Math.ceil((s+1)/this.COLUMN_CNT)
this.SetCapatity(t*this.COLUMN_CNT)}for(let t=0;t<=e.Count()-1;t++)1==e[t]&&(e[t]=null)
return e}Update(){let t=0,e=(this.ROW_CNT+this.ICON_MAX_CNT)*this.COLUMN_CNT
if(null!=this.bar){const i=1
i>0&&(t=Math.ceil((this.CAPACITY-this.COLUMN_CNT*this.ROW_CNT)*i),e=t+this.COLUMN_CNT*this.ROW_CNT+this.ICON_MAX_CNT*this.COLUMN_CNT,t-=this.ICON_MAX_CNT*this.COLUMN_CNT,
t<0&&(t=0),e>=this.CAPACITY&&(e=this.CAPACITY-1))}for(const[t,e]of(0,n.V5)(this.show_item_dict))t>=this.CAPACITY&&null!=e&&this.RemoveShowItem(e,t)
for(let i=t;i<=e;i++){const t=this.item_datas[i],e=this.show_item_dict.LuaDic_GetItem(i)
null==t?this.RemoveShowItem(e,i):this.AddShowItem(e,i,t)}}AddShowItem(t,e,i){null==t&&(t=this.GetShowItem()),t.node.setParent(this.grid),this.SetPos(t,e),
this.show_item_dict.LuaDic_AddOrSetItem(e,t),null!=i&&t.SetData(i)}RemoveShowItem(t,e){null!=t&&(t.node.SetActive(!1),this.show_item_dict.LuaDic_Remove(e),t.Clear(),
this.item_pool.Add(t))}GetShowItem(){let t=null
if(this.item_pool.Count()>0)t=this.item_pool.Pop(),t.node.SetActive(!0)
else{const e=a.g.GetResFindId(this.m_ItemPath)
t=new this.m_ItemCls,t.setPrefabRootId(e),this.m_handlerMgr.AddClearComponent(t,!0,!0)}return t}SetPos(t,e){
const i=e%this.COLUMN_CNT*(this.ITEM_SIZE+this.SPACE),s=-Math.floor(e/this.COLUMN_CNT)*(this.ITEM_SIZE+this.SPACE)
d.I.calVec0.Set(i,s,0),t.node.transform.SetLocalPosition(d.I.calVec0)}Destroy(){for(const[t,e]of(0,n.V5)(this.show_item_dict))null!=e&&this.item_pool.Add(e)
this.show_item_dict.LuaDic_Clear()
for(let t=0;t<=this.item_pool.Count()-1;t++){const e=this.item_pool[t]
a.g.DestroyView(e)}this.item_pool.Clear()}GetInfoForItemSize(){return[this.SPACE,this.ITEM_SIZE,this.ICON_SIZE]}}},16945:(t,e,i)=>{i.d(e,{m:()=>p})
var s,n=i(6847),l=i(83908),a=i(46282),o=i(5494),r=i(85602),h=i(63076),d=i(85751),u=i(87923),c=i(22811),_=i(13309),I=i(90560)
class m{constructor(){this.isNew=!1,this.str=""}Test1(){return!0}S_Test(){return!0}}class g extends((0,l.zB)()){InitView(){super.InitView()}Clear(){super.Clear()}Destroy(){
super.Destroy()}SetData(t){this.attr.textSet(t.str),t.isNew?(this.newPic.x=this.attr.node.x+this.attr.textWidth,this.newPic.SetActive(!0)):this.newPic.SetActive(!1)}S_Test(){
return!0}}let p=(0,n.s_)(o.I.RyEquipAdvanceSuccess,a.Z.ui_ry_equipadvance_success).register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),this.model=null}InitView(){
super.InitView(),this.propertyGrid.SetInitInfo("ui_equipadvance_excellenceattr",null,g),this.propertyGrid.OnReposition_set(this.CreateDelegate(this.OnGridReposition)),
this.model=_.g.Inst_get()}AddLis(){this.m_handlerMgr.AddClickEvent(this.btn.node,this.CreateDelegate(this.CloseHandle))}RemoveLis(){}Clear(){this.propertyGrid.Clear(),
this.RemoveLis(),super.Clear()}Destroy(){}OnAddToScene(){this.AddLis()
const t=this.model.showEquipment,e=this.model.lastSelectEquipId
let i=!0
if(e){const t=this.model.GetItemByEquipId(e)
t&&0==t.isInherit&&(i=!1)}if(null!=t){const e=new h.M(t.modelId,t)
e.playerIdxSet(I.U.Inst().GetSelectRoleInfo().createIdx),e.isCanOperate=!1
const s=e.equipInfo_get(),n=e.GetSuitEq(),l=e.cfgData_get(),a=u.l.SetEquipName(s,l,t,n,!0,!0,0,!1,null,null,null,null,null,!0)
this.equipName.textSet(a[0]),this.item.SetData(e)
const o=new r.Z,c=t.exellectAttrs.attributeDatas,_=c.Count()
for(let t=0;t<=_-1;t++){let e=d.u.GreenColorStr2
const s=c[t]
e+=`卓越（${u.l.getAttrStr(s.type,!1)}${u.l.getAttrValueStr(s.type,s.value,!s.isPercentage)}）[-]`
const n=new m
n.str=e,n.isNew=!1,t==_-1&&i&&(n.isNew=!0),o.Add(n)}this.propertyGrid.data_set(o)}}OnGridReposition(){this.propertyScrollView.ResetPosition()}CloseHandle(){
c.S.Inst_get().CloseEquipAdvanceSuccessView()}})||s},56956:(t,e,i)=>{i.d(e,{O:()=>d})
var s=i(93984),n=i(38836),l=i(55360),a=i(98130),o=i(85602),r=i(38962),h=i(77477)
class d{constructor(){this.ADD_LIMIT={},this.EquipmentAddMap=null,this.EquipmentAddGroupMap=null,this.enhancePosDic=null,this.EquipmentAddMap=new r.X,
this.EquipmentAddGroupMap=new r.X,this.enhancePosDic=new r.X
const t=l.Y.Inst.GetOrCreateCsv(s.h.eAddRes)
this.EquipmentAddMap=t.GetCsvMap(),this.InitEquipmentAddGroupMap()}static Inst(){return null==d._inst&&(d._inst=new d),d._inst}InitEquipmentAddGroupMap(){for(const[t,e]of(0,
n.V5)(this.EquipmentAddMap)){const t=100*e.equipCol+e.attrGroup
let i=null
i=this.EquipmentAddGroupMap[t],null==i&&(i=new r.X,this.EquipmentAddGroupMap.LuaDic_AddOrSetItem(t,i)),i.LuaDic_AddOrSetItem(e.levelId,e),
null==this.ADD_LIMIT[t]&&(this.ADD_LIMIT[t]={})
const s=this.ADD_LIMIT[t]
null==s[e.stageLimit]&&(s[e.stageLimit]=0),null==s[d.ADDMAXKEY]&&(s[d.ADDMAXKEY]=0)
const n=s[e.stageLimit]
e.levelId>n&&(s[e.stageLimit]=e.levelId),s[d.ADDMAXKEY]<=e.levelId&&(s[d.ADDMAXKEY]=e.levelId),
this.enhancePosDic.LuaDic_ContainsKey(e.equipCol)||(this.enhancePosDic[e.equipCol]=new o.Z),0==e.levelId&&this.enhancePosDic[e.equipCol].Add(e.attrGroup)}for(const[t,e]of(0,
n.V5)(this.enhancePosDic))e.Sort(((t,e)=>this.SortPos(t,e)))}GetADDLimitTableByAddType(t,e){const i=100*t+e
return this.ADD_LIMIT[i]||{}}getResByLevel(t,e,i){const s=100*t+e,n=this.EquipmentAddGroupMap[s]
let l=null,a=null
return null!=n&&(l=n.LuaDic_GetItem(i)),null!=l&&(a=l),a}GetAttrsByLevel(t,e,i,s,n){null==n&&(n=!1)
const l=100*t+e
let a=new r.X
if(!this.EquipmentAddGroupMap.LuaDic_ContainsKey(l))return a
const o=this.EquipmentAddGroupMap[l]
if(!o.LuaDic_ContainsKey(i))return a
const h=o[i]
return a=n?h.newAttrAddDic:h.attrAddDic,a}GetAttrByType(t,e){
return e==a.GF.INT(h.Z.PhyAttack_Max)?t.phyAttack_MaxEx[0]:e==a.GF.INT(h.Z.PhyAttack_Min)?t.phyAttack_MinEx[0]:e==a.GF.INT(h.Z.Defense)?t.defenseEx[0]:e==a.GF.INT(h.Z.MaxHp)?t.maxHpEx[0]:e==a.GF.INT(h.Z.DodgeRate)?t.dodgeRateEx[0]:e==a.GF.INT(h.Z.AttackRate)?t.attackRateEx[0]:e==a.GF.INT(h.Z.EquipDodgeRateAddRate)?t.equipDodgeRateAddRateEx[0]:e==a.GF.INT(h.Z.MoveSpeed)?t.moveSpeedEx[0]:e==a.GF.INT(h.Z.Attack)?t.attackEx[0]:0
}GetPosListByCol(t){return this.enhancePosDic[t]||new o.Z}SortPos(t,e){return t<e?-1:t>e?1:0}}d._inst=null,d.ADDMAXKEY="MAXLEVEL"},41850:(t,e,i)=>{i.d(e,{C:()=>_})
var s=i(93984),n=i(38836),l=i(62370),a=i(55360),o=i(98130),r=i(98885),h=i(85602),d=i(38962),u=i(51262),c=i(75439)
class _{constructor(){this.enhanceLimitMap=null,this.excellentLimitMap={},this.equipEnhanceMap=null,this.equipEnhanceDataMap=null,this.soulAllEnhanceAttrDic=null,
this.EnhanceTopLimitMap=null,this.EnhanceLowestLimitMap=null,this.enhancePosDic=null,this.MaxCastLevel=0,this.shineLevels=null,this.shineLevelsToIcon=null,this.modelids=null,
this.modelidsToIcon=null,this.EnhanceMaxLevel={},this.EnhanceMaxIdLevel={},this.EnhanceLocationSoulLvAttrDic={},this.enhanceLimitMap=new d.X,this.equipEnhanceMap=new d.X,
this.soulAllEnhanceAttrDic=new d.X,this.enhancePosDic=new d.X
const t=a.Y.Inst.GetOrCreateCsv(s.h.eEnhanceRes)
this.equipEnhanceMap=t.GetCsvMap(),this.equipEnhanceDataMap=new d.X
const e=new d.X
for(const[t,i]of(0,n.V5)(this.equipEnhanceMap)){let t=100*i.equipCol+i.location,s=null
s=this.equipEnhanceDataMap[t],null==s&&(s=new d.X,this.equipEnhanceDataMap.LuaDic_AddOrSetItem(t,s)),
s.LuaDic_AddOrSetItem(i.equipCol+(l.o.s_UNDER_CHAR+(i.location+(l.o.s_UNDER_CHAR+i.level))),i),null==e[t]&&(e[t]=new d.X)
let n=e[t],a=100*i.limitStage+i.limitExcellent;(null==n[a]||i.id>n[a])&&0!=i.level&&(n[a]=i.id),
(null==this.EnhanceMaxLevel[t]||i.level>this.EnhanceMaxLevel[t])&&(this.EnhanceMaxLevel[t]=i.level),
(null==this.EnhanceMaxIdLevel[t]||i.id>this.EnhanceMaxIdLevel[t])&&(this.EnhanceMaxIdLevel[t]=i.id),
this.enhancePosDic.LuaDic_ContainsKey(i.equipCol)||(this.enhancePosDic[i.equipCol]=new h.Z),0==i.level&&this.enhancePosDic[i.equipCol].Add(i.location)}for(const[t,i]of(0,n.V5)(e)){
let i=e[t],s=new h.Z
this.enhanceLimitMap[t]=s
for(const[t,e]of(0,n.V5)(i))s.Add([t,e])
s.Sort(((t,e)=>this.SortPos2(t,e)))}const i=c.D.getInstance().getContent("EQUIPMENT:SHINE:ENHANCEID").getContent().stringVal
let o=r.M.Split(i,r.M.s_CCD_CHAR_DOT),u=r.M.Split(o[0],r.M.s_SPAN_CHAR_DOT)
this.modelids=r.M.Split(o[1],r.M.s_SPAN_CHAR_DOT)
let _=u.Count()
this.shineLevels=new h.Z
let I=0
for(;I<_;)this.shineLevels[I]=r.M.String2Int(u[I]),I+=1
const m=c.D.getInstance().getContent("EQUIPMENT:SHINE:ENHANCEID:ICON").getContent().stringVal
for(o=r.M.Split(m,r.M.s_CCD_CHAR_DOT),u=r.M.Split(o[0],r.M.s_SPAN_CHAR_DOT),this.modelidsToIcon=r.M.Split(o[1],r.M.s_SPAN_CHAR_DOT),_=u.Count(),this.shineLevelsToIcon=new h.Z,
I=0;I<_;)this.shineLevelsToIcon[I]=r.M.String2Int(u[I]),I+=1
for(const[t,e]of(0,n.V5)(this.enhancePosDic))e.Sort(((t,e)=>this.SortPos(t,e)))}static Inst(){return null==_._inst&&(_._inst=new _),_._inst}SortPos(t,e){return t<e?-1:t>e?1:0}
SortPos2(t,e){return t[1]<e[1]?-1:t[1]>e[1]?1:0}GetNextCanEnhanceLimitKey(t,e,i,s){let n=100*t+e,l=this.enhanceLimitMap[n]
for(let t=0;t<=l.Count()-1;t++){let e=l[t][0],n=o.GF.INT(e/100),a=o.GF.INT(e%100)
if(n>i||a>s){return[e,l[t][1]]}}return[0,0]}getResById(t){return this.equipEnhanceMap[t]}getResByColumnPosLevel(t,e,i){const s=new u.H
s.Append(r.M.IntToString(t)),s.Append(l.o.s_UNDER_CHAR),s.Append(r.M.IntToString(e)),s.Append(l.o.s_UNDER_CHAR),s.Append(r.M.IntToString(i))
const n=s.ToString()
if(this.equipEnhanceDataMap.LuaDic_ContainsKey(100*t+e)){let i=this.equipEnhanceDataMap[100*t+e]
if(i.LuaDic_ContainsKey(n))return i[n]}return null}ShineIdIndex(t,e){let i=0,s=0,n=0
const l=t
i=0
let a=null
for(a=e?this.shineLevelsToIcon:this.shineLevels;i<a.count;){if(i<a.count-1){if(s=a[i],n=a[i+1],l>=s&&l<n)return i}else if(l>=s)return i
i+=1}return 0}GetMaxLevelByColumnAndPos(t,e){return this.EnhanceMaxLevel[100*t+e]}GetModelId(t,e){const i=this.ShineIdIndex(t,e)
return e?this.modelidsToIcon[i]:this.modelids[i]}GetEnhanceMaxEnhanceIdByColAndPos(t,e){return this.EnhanceMaxIdLevel[100*t+e]}GetEnhanceStageLimitByLocationAndStage(t,e,i,s){
const n=100*t+e,l=this.enhanceLimitMap[n]||new h.Z
let a=0
for(let t=0;t<=l.Count()-1;t++){const e=l[t][0],n=o.GF.INT(e/100),r=o.GF.INT(e%100)
if(n>i||r>s)return a
a=l[t][1]}return a}GetIsCanSpecialEnhanceLimit(t){return!1}GetPosListByCol(t){return this.enhancePosDic[t]||new h.Z}}_.STAGEMAX="MAX",_._inst=null},56582:(t,e,i)=>{i.d(e,{r:()=>d})
var s=i(93984),n=i(38836),l=i(62370),a=i(55360),o=i(98885),r=i(85602),h=i(38962)
class d{constructor(){this.masterMap=null,this.columnResDic=null,this.limitMap=null,this.masterKeyMap=null,this.masterMap=new h.X,this.columnResDic=new h.X
const t=a.Y.Inst.GetOrCreateCsv(s.h.eEquipAddMaster)
this.masterMap=t.GetCsvMap(),this.masterKeyMap=new h.X,this.limitMap=new h.X
for(const[t,e]of(0,n.V5)(this.masterMap)){const t=1e4*e.equipCol+e.addMasterLevel
this.masterKeyMap[t]=e}}static Inst(){return null==d._inst&&(d._inst=new d),d._inst}getItemById(t){let e=null
return e=this.masterMap[t],null!=e?e:null}getItemByLv(t,e){const i=1e4*t+e
return this.masterKeyMap[i]}getTopItemByPosAndLv(t,e){const i=new r.Z
for(const[e,s]of(0,n.vy)(this.masterMap)){const s=o.M.Split(e,l.o.s_UNDER_CHAR)[0]
t==o.M.String2Int(s)&&i.Add(this.masterMap[e])}let s=-1,a=-1
if(i.Count()>0){let t=0
for(;t<i.Count();)i[t].addLevelCondition<=e&&i[t].addLevelCondition>s&&(s=i[t].addLevelCondition,a=t),t+=1
if(-1!=a)return i[a]}return null}GetEnhanceUpPercent(t){return 0}GetEnhanceUpItems(t){const e=new r.Z
if(!this.columnResDic.LuaDic_ContainsKey(t))return e
const i=this.columnResDic[t]
let s=0
for(;s<i.Count();){const n=i[s]
0==t&&e.Add(n),s+=1}let n=0
for(;n<e.Count()-1;){let t=n+1
for(;t<e.Count();){if(e[n].addMasterLevel>e[t].addMasterLevel){const i=e[n]
e[n]=e[t],e[t]=i}t+=1}n+=1}return e}getAttr(t,e){for(const[t,i]of(0,n.V5)(e.atts.attrs))return i
return null}GetEvolutionUpItems(t){const e=new r.Z
if(!this.columnResDic.LuaDic_ContainsKey(t))return e
const i=this.columnResDic[t]
let s=0
for(;s<i.Count();){const n=i[s]
0==t&&e.Add(n),s+=1}let n=0
for(;n<e.Count()-1;){let t=n+1
for(;t<e.Count();){if(e[n].addMasterLevel>e[t].addMasterLevel){const i=e[n]
e[n]=e[t],e[t]=i}t+=1}n+=1}return e}}d._inst=null},14666:(t,e,i)=>{i.d(e,{g:()=>m})
var s=i(93984),n=i(38836),l=i(90419),a=i(50089),o=i(66788),r=i(55360),h=i(38962),d=i(52429),u=i(86133),c=i(44498),_=i(33833)
class I{constructor(t,e,i){if(this.type=0,this.isPercentage=!1,this.value=0,this.score=0,this.isStar=!1,this.isCheckStar=!1,this.transferDirection=0,this.colorStr=null,
this.isMerged=!1,this.minValue=0,this.maxValue=0,this.resource=null,this.hadExcellecnStar=null,null!=t){this.resource=t,this.type=e
const s=_.X.Inst().getItemById(e)
this.isPercentage=1!=s.valueType&&0!=s.valueType,this.value=i,this.score=t.score||0}}CheckStar(t){return this.isStar=c.I.IsEquipAttrStar(t.GetEquipRes(),this.type),
this.isCheckStar=!0,this.isStar}Clone(){const t=new I(null,null,0)
return t.type=this.type,t.value=this.value,t.isPercentage=this.isPercentage,t.isStar=this.isStar,t.score=this.score,t.minValue=this.minValue,t.maxValue=this.maxValue,
t.isMerged=this.isMerged,t.colorStr=this.colorStr,t.transferDirection=this.transferDirection,t.isCheckStar=this.isCheckStar,t.resource=this.resource,
t.hadExcellecnStar=this.hadExcellecnStar,t}SetMergeAttr(t,e){t==e?(this.isMerged=!1,0==t&&o.Y.LogError((0,u.T)("属性IDType为")+(this.type+(0,u.T)("的所有属性合并后最小值和最大值都为0 not not "))),
this.value=t):(this.isMerged=!0,this.minValue=t,this.maxValue=e)}SetHadExcellecnStar(t){this.hadExcellecnStar=t}}class m{constructor(){this.excellenceMap=null,this.IdMapAtrr=null,
this.AttrKeyDic=null,this._m_atts=null,this.excellenceMap=new h.X,this.IdMapAtrr=new h.X
const t=r.Y.Inst.GetOrCreateCsv(s.h.eEquipmentScore)
this.excellenceMap=t.GetCsvMap(),this.AttrKeyDic=new h.X
for(const[t,e]of(0,n.V5)(this.excellenceMap)){let t=e.excellentAttrs,i=l.d.parseJsonObjectWithFix(t,"attrs")
this._m_atts=a.t.decode(i,d.L),this._m_atts.parse()
let s=this._m_atts.attrs[0].intType,n=this._m_atts.attrs[0].value,o=this.GetKeyByStageAndType(e.equipStepLv,s)
if(this.IdMapAtrr.LuaDic_AddOrSetItem(e.id,this._m_atts.attrs[0]),this.AttrKeyDic.LuaDic_ContainsKey(o))this.AttrKeyDic[o].LuaDic_AddOrSetItem(n,e)
else{let t=new h.X
t.LuaDic_AddOrSetItem(n,e),this.AttrKeyDic.LuaDic_AddOrSetItem(o,t)}}}static Inst(){return null==m._inst&&(m._inst=new m),m._inst}GetKeyByStageAndType(t,e){return 1e6*t+e}
GetAttrByIdAndType(t,e,i){const s=this.getItemById(t),n=this.IdMapAtrr[t]
return new I(s,n.intType,n.value)}getItemById(t){const e=r.Y.Inst.GetOrCreateCsv(s.h.eEquipmentScore)
return this.excellenceMap=e.GetCsvMap(),this.excellenceMap[t]}getItemByAttr(t,e,i){const s=this.GetKeyByStageAndType(i,t)
return this.AttrKeyDic.LuaDic_ContainsKey(s)?this.AttrKeyDic[s][e]:null}GetEADataByAttr(t,e,i){const s=this.getItemByAttr(t,e,i)
if(null!=s){return new I(s,t,e)}return new I(null,null,1)}GetShowExcellenceStar(t,e,i){const s=this.getItemByAttr(t,e,i)
return null!=s&&1==s.star}}m._inst=null},14366:(t,e,i)=>{i.d(e,{C:()=>m})
var s=i(93984),n=i(38836),l=i(90419),a=i(50089),o=i(55360),r=i(98885),h=i(85602),d=i(38962),u=i(77477),c=i(60917),_=i(63456),I=i(46749)
class m{constructor(){this.EquipmentLuckMap=null,this.EquipmentStageAttrMap=null,this.CostMap=null,this.stageLimit=-1,this.enhancePosDic=null,this.smeltComsumes=null,
this.EquipmentLuckMap=new d.X,this.EquipmentStageAttrMap=new d.X
const t=o.Y.Inst.GetOrCreateCsv(s.h.eEquipLuckyType)
this.EquipmentLuckMap=t.GetCsvMap(),this.CostMap=new d.X,this.enhancePosDic=new d.X,this.Parse()}static Inst(){return null==m._inst&&(m._inst=new m),m._inst}Parse(){
for(const[t,e]of(0,n.V5)(this.EquipmentLuckMap)){let t=l.d.parseJsonObjectWithFix(e.consume,"costs")
this.smeltComsumes=a.t.decode(t,_.d),this.smeltComsumes.Parse()
const i=100*e.equipCol+e.location
this.CostMap.LuaDic_AddOrSetItem(i,this.smeltComsumes.costs)
let s=null
s=this.EquipmentStageAttrMap[i],null==s&&(s=new h.Z,this.EquipmentStageAttrMap.LuaDic_AddOrSetItem(i,s)),t=l.d.parseJsonObjectWithFix(e.attr,"typevalues")
const n=a.t.decode(t,I.z)
let o=0
for(;o<n.typevalues.Count();){const t=n.typevalues[o]
t.Parse()
const e=u.Z.GetAttrKey(t.type),i=new c.P
i.intType=r.M.String2Int(e),i.value=r.M.String2Int(t.value),s.Add(i),o+=1}(-1==this.stageLimit||e.id<this.stageLimit)&&(this.stageLimit=e.id),
this.enhancePosDic.LuaDic_ContainsKey(e.equipCol)||(this.enhancePosDic[e.equipCol]=new h.Z),this.enhancePosDic[e.equipCol].Add(e.location)}for(const[t,e]of(0,
n.V5)(this.enhancePosDic))e.Sort(((t,e)=>this.SortPos(t,e)))}GetAttrsByColAndPos(t,e){return this.EquipmentStageAttrMap[100*t+e]}GetConsumeDataByColAndPos(t,e){
return this.CostMap[100*t+e]}GetPosListByCol(t){return this.enhancePosDic[t]||new h.Z}SortPos(t,e){return t<e?-1:t>e?1:0}}m._inst=null},26195:(t,e,i)=>{i.d(e,{j:()=>C})
var s=i(38836),n=i(86133),l=i(97461),a=i(66788),o=i(85602),r=i(1240),h=i(3859),d=i(92679),u=i(33314),c=i(33138),_=i(65994),I=i(34101),m=i(14792),g=i(62734),p=i(47041)
class C{constructor(){this.bagData=null,this._bagSize=0,this._maxBagSize=0,this._emptySize=0,this.itemNumTab={},this.InitConfig()}static Inst_get(){
return null==C._Inst&&(C._Inst=new C),C._Inst}InitConfig(){}bagSize_get(){return this._bagSize}maxBagSize_get(){return this._maxBagSize}emptySize_get(){return this._emptySize}
InitBagData(){this.bagData=new o.Z
let t=null,e=0
for(;e<this._maxBagSize;)t=new r.Y,this.bagData[e]=t,e+=1}updateBag(t){if(null==t)return
this._bagSize=t.size,this._maxBagSize=t.maxSize,null==this.bagData&&this.InitBagData()
let e=null
if(null!=t.updates)for(const[i,n]of(0,s.vy)(t.updates))null==this.bagData[i]?(e=new r.Y,this.bagData[i]=e):e=this.bagData[i],
null!=e.serverData_get()&&this.UpdateItemNum(e.serverData_get().modelId,e.serverData_get().num,!1),e.index_set(i),e.type_set(3),e.isnew=!1,e.serverData_set(t.updates[i]),
null!=e.serverData_get()&&e.serverData_get().num>0&&this.UpdateItemNum(e.serverData_get().modelId,e.serverData_get().num,!0),null!=e.baseData_get()&&(e.baseData_get().isForBag=!0)
this._emptySize=this._maxBagSize-this._bagSize,g.f.Inst.SetState(m.t.FORGE_JEWEL_BAGMAX,0==this._emptySize),l.i.Inst.RaiseEvent(d.g.JEWEL_BAG_UPDATE),
0==t.packUpdateType&&this.ShowTipsQueue(t)}ShowTipsQueue(t){let e=null
for(const[i,n]of(0,s.vy)(t.updates)){const s=t.updates[i]
null!=s&&(e=new r.Y,e.serverData_set(s),e.IsTransferReward()||p.N.Inst_get().ShowGetTip(s,!0),r.Y.Recycle(e))}}GetItemById(t){if(null!=this.bagData){for(const[e,i]of(0,
s.V5)(this.bagData))if(null!=i.baseData_get()&&i.serverData_get().id.Equal(t))return i}else a.Y.Log((0,n.T)("符文背包为初始化，后端没发背包数据"))
return null}UpdateItemNum(t,e,i){
i?null==this.itemNumTab[t]?this.itemNumTab[t]=e:this.itemNumTab[t]=this.itemNumTab[t]+e:null!=this.itemNumTab[t]&&(this.itemNumTab[t]=this.itemNumTab[t]-e,
this.itemNumTab[t]<=0&&(this.itemNumTab[t]=null))}GetItemNum(t){return null!=this.itemNumTab[t]?this.itemNumTab[t]:0}getFilterByTab(t){const e=new o.Z
if(null!=this.bagData)for(const[t,i]of(0,s.V5)(this.bagData))null!=i&&e.Add(i)
return e}JudgeIsHasCanSmeltItem(){}GetJewelSmeltDatas(){}GetJewelSmeltIsInBag(t,e,i,s){return!1}GetJewelSmeltHasMoreQualityInBag(t,e){const i=c.f.Inst().getItemById(t)
let n=null
1==e?n=I.f.Inst().attrIds:2==e&&(n=I.f.Inst().talentIds)
let l=0
if(null!=n&&null!=i)for(const[t,e]of(0,s.V5)(n)){l=this.GetItemNum(e)
const t=c.f.Inst().getItemById(e)
if(0!=l&&null!=t&&u.Z.ReachJobLimit(t.job)&&i.Quality_get()<t.Quality_get())return!0}return!1}GetItemListByItemType(t){const e=new o.Z
if(null!=this.bagData)for(const[i,n]of(0,s.V5)(this.bagData))null!=n.baseData_get()&&n.baseData_get().cfgData_get().itemType==t&&e.Add(n)
return e}GetBagJewelExpIsCanUp(t){let e=0,i=!0
if(null!=this.bagData)for(const[n,l]of(0,s.V5)(this.bagData))if(null!=l.baseData_get()&&null!=l.baseData_get().cfgData_get()&&(i=!0,
l.baseData_get().cfgData_get().itemType==h.q.EQUIPJEWEL||l.baseData_get().cfgData_get().itemType==h.q.EQUIPJEWELMATERIAL)){
if(l.baseData_get().cfgData_get().itemType==h.q.EQUIPJEWEL){const t=l.serverData_get()
if(null!=t&&null!=t.smelt)for(const[e,n]of(0,s.V5)(t.smelt))if(null!=n&&0!=n){i=!1
break}}if(i&&null!=l.serverData_get()){const i=_.n.Inst().GetItemById(l.serverData_get().modelId)
if(null!=i&&(e+=i.resolveExp*l.serverData_get().num,e>=t))return!0}}return!1}GetItemJewelByClone(t){}GetEquipJewelSmeltByClone(t){}ResetModel(){this.bagData=null,this._bagSize=0,
this._maxBagSize=0,this._emptySize=0,this.itemNumTab={}}}C._Inst=null},54220:(t,e,i)=>{i.d(e,{P:()=>l})
var s,n=i(18998)
let l=n._decorator.ccclass("MaterialItem")(s=class{constructor(t,e,i,s){this._baseItemData=null,this.demandCount=0,this.isBind=!1,this.isCanUseBind=!1,this.isCurrency=!1,
this.guideId=null,this.guideParam=null,null==s&&(s=!0),this._baseItemData=t,this.demandCount=e,this.isBind=i,this.isCanUseBind=s,
null!=this._baseItemData.virtualItemData_get()&&(this.isCurrency=!0)}})||s},39993:(t,e,i)=>{i.d(e,{C:()=>g})
var s=i(93984),n=i(32076),l=i(38836),a=i(5583),o=i(98800),r=i(16812),h=i(55360),d=i(98885),u=i(85602),c=i(38962),_=i(63076),I=i(75321),m=i(77477)
class g extends r.k{constructor(){super(),this.awakenequipMap=null,this.awakengemMap=null,this.awakengemUpMap=null,this.awakengemRefineMap=null,this.awakenRefineSuitMap=null,
this.gemArrtDic=null,this.boxAttrDic=null,this.uniqueGemDic=null,this.fluoriteDic=null,this.colsuitArrtDic=null,this.refineColsuitAttrDic=null,this.refineColSuitListDic=null,
this.consumDic=null,this.needUpMaxLevelExpDic=null,this.boxMaxLevel=null,this.colFluoriteListDic=null,this.colAllFluoriteListDic=null,this.awakengemMap=new c.X,
this.awakengemUpMap=new c.X,this.awakengemRefineMap=new c.X,this.awakenRefineSuitMap=new c.X
const t=h.Y.Inst.GetOrCreateCsv(s.h.eAwakenEquip),e=h.Y.Inst.GetOrCreateCsv(s.h.eAwakenGem),i=h.Y.Inst.GetOrCreateCsv(s.h.eAwakenGemUpgrade),o=h.Y.Inst.GetOrCreateCsv(s.h.eAwakenGemRefine),r=h.Y.Inst.GetOrCreateCsv(s.h.eAwakenRefineSuit)
this.awakenequipMap=t.GetCsvMap(),this.awakenequipMap.declareKeyNumber(),this.awakengemMap=e.GetCsvMap(),this.awakengemUpMap=i.GetCsvMap(),this.awakengemRefineMap=o.GetCsvMap(),
this.awakenRefineSuitMap=r.GetCsvMap(),this.gemArrtDic=new c.X,this.boxAttrDic=new c.X,this.uniqueGemDic=new c.X,this.fluoriteDic=new c.X,this.colsuitArrtDic=new c.X,
this.refineColsuitAttrDic=new c.X,this.refineColSuitListDic=new c.X,this.consumDic=new c.X
for(const[t,e]of(0,l.V5)(this.awakengemRefineMap)){const i=a.L.GetCommonTypeValuesConfig(e.consumItem,!0).typevalues,s=new u.Z
for(let t=0;t<=i.Count()-1;t++){const e=new _.M(d.M.String2Int(i[t].valueType),null)
e.needNum=d.M.String2Int(i[t].valueNum),s.Add(e)}this.consumDic.LuaDic_AddOrSetItem(t,s)}for(const[t,e]of(0,l.V5)(this.awakengemMap))if(1==e.type){
1!=e.uniqueGem?(null==this.fluoriteDic[e.equipColumn]&&(this.fluoriteDic[e.equipColumn]=new c.X),
null==this.fluoriteDic[e.equipColumn][e.quality]&&(this.fluoriteDic[e.equipColumn][e.quality]=new c.X),
this.fluoriteDic[e.equipColumn][e.quality][e.refineLv]=e):(null==this.uniqueGemDic[e.equipColumn]&&(this.uniqueGemDic[e.equipColumn]=new c.X),
null==this.uniqueGemDic[e.equipColumn][e.quality]&&(this.uniqueGemDic[e.equipColumn][e.quality]=new c.X),this.uniqueGemDic[e.equipColumn][e.quality][e.refineLv]=e)
const t=new c.X,i=a.L.GetCommonTypeValuesConfig(e.attr)
if(null!=i){const e=i.typevalues
for(const[i,s]of(0,l.V5)(e)){const e=m.Z.GetAttrKey(s.type)
t.LuaDic_AddOrSetItem(e,d.M.String2Int(s.value))}}this.gemArrtDic.LuaDic_Add(e.id,t)}for(const[t,e]of(0,l.V5)(this.awakenequipMap)){
const t=new c.X,i=a.L.GetCommonTypeValuesConfig(e.suitAttr)
if(null!=i){const e=i.typevalues
for(const[i,s]of(0,l.V5)(e)){const e=m.Z.GetAttrKey(s.type)
t.LuaDic_AddOrSetItem(e,d.M.String2Int(s.value))}}this.colsuitArrtDic.LuaDic_Add(e.id,t)}for(const[t,e]of(0,l.V5)(this.awakenRefineSuitMap)){
const t=new c.X,i=a.L.GetCommonTypeValuesConfig(e.suitAttr)
if(null!=i){const e=i.typevalues
for(const[i,s]of(0,l.V5)(e)){const e=m.Z.GetAttrKey(s.type)
t.LuaDic_AddOrSetItem(e,d.M.String2Int(s.value))}}this.refineColsuitAttrDic.LuaDic_Add(1e4*e.equipCol+e.refineLv,t),
null==this.refineColSuitListDic[e.equipCol]&&(this.refineColSuitListDic[e.equipCol]=new u.Z),this.refineColSuitListDic[e.equipCol].Add(1e4*e.equipCol+e.refineLv)}
for(const[t,e]of(0,l.V5)(this.refineColSuitListDic))e.Sort((0,n.v)(this.SortRefineColLv,this))
const I=new u.Z
for(const[t,e]of(0,l.V5)(this.awakengemUpMap)){I.Add(e)
const t=new c.X,i=a.L.GetCommonTypeValuesConfig(e.attr)
if(null!=i){const e=i.typevalues
for(const[i,s]of(0,l.V5)(e)){const e=m.Z.GetAttrKey(s.type)
t.LuaDic_AddOrSetItem(e,d.M.String2Int(s.value))}}this.boxAttrDic.LuaDic_Add(e.id,t)}I.Sort((0,n.v)(this.SortLv,this))
const g=I.Count()
this.needUpMaxLevelExpDic=new c.X,this.boxMaxLevel=I[g-1].id
let p=0
for(let t=g-1;t>=1;t+=-1)p+=I[t].upgradeExp,this.needUpMaxLevelExpDic.LuaDic_Add(t-1,p)
this.colFluoriteListDic=new c.X,this.colAllFluoriteListDic=new c.X}static Inst(){return null==g._inst&&(g._inst=new g),g._inst}SortLv(t,e){return t.id<e.id?-1:t.id>e.id?1:0}
SortRefineColLv(t,e){return t<e?-1:t>e?1:0}getGemResById(t){return this.awakengemMap[t]}getGemRefineResByColAndRefineLv(t,e){return this.awakengemRefineMap[100*t+e]}
GetCostItemList(t,e){return this.consumDic[100*t+e]}GetAllGemsDic(){return this.awakengemMap}getEquipResById(t){return this.awakenequipMap[t]}getGemUpResById(t){
return this.awakengemUpMap[t]}getGemArreById(t){return this.gemArrtDic[t]}getSuitAttrById(t){return this.colsuitArrtDic[t]}getRefineSuitAttrByColAndLv(t,e){const i=1e4*t+e
return this.refineColsuitAttrDic[i]}getRefineSuitAttrByid(t){return this.refineColsuitAttrDic[t]}getRefineSuitIdListByCol(t){return this.refineColSuitListDic[t]}
getboxAttrDicById(t){return this.boxAttrDic[t]}GetColList(t){const e=new u.Z,i=new u.Z,s=null!=t
null==t&&(t=o.Y.Inst.PrimaryRoleInfo_get())
const n=null!=t&&t.Level_get()||0
for(const[a,o]of(0,l.V5)(this.awakenequipMap))if(s){const s=t.GetEquipmentsByColumn(o.id)
null!=s&&(s.unlockColumn&&t.GetUnlockByColumnAndPos(o.id,I.C.PART_WEAPON_LEFT)?o.awakenLevel<=n&&e.Add(a):o.awakenLevel<=n&&i.Add(a))}else o.awakenLevel<=n&&(e.Add(a),i.Add(a))
return e.Sort(((t,e)=>t<e?-1:t>e?1:0)),i.Sort(((t,e)=>t<e?-1:t>e?1:0)),0==e.Count()&&i.Count()>0?i:e}GetPosList(t){const e=this.getEquipResById(t)
return null!=e?new u.Z(e.awakenLoc):new u.Z}GetFluoriteListByCol(t){if(!this.colFluoriteListDic.LuaDic_ContainsKey(t)){const e=new u.Z,i=this.fluoriteDic[t]
for(const[t,s]of(0,l.V5)(i))for(const[t,i]of(0,l.V5)(s))e.Add(i)
e.Sort((0,n.v)(this.SortFluorite,this)),this.colFluoriteListDic[t]=e}return this.colFluoriteListDic[t]}GetAllFluoriteListByCol(t){
if(!this.colAllFluoriteListDic.LuaDic_ContainsKey(t)){const e=new u.Z,i=this.fluoriteDic[t]
for(const[t,s]of(0,l.V5)(i))for(const[t,i]of(0,l.V5)(s))e.Add(i)
const s=this.uniqueGemDic[t]
for(const[t,i]of(0,l.V5)(s))for(const[t,s]of(0,l.V5)(i))e.Add(s)
e.Sort((0,n.v)(this.SortFluorite,this)),this.colAllFluoriteListDic[t]=e}return this.colAllFluoriteListDic[t]}GetBetterGemByColAndGemId(t,e){const i=this.GetAllFluoriteListByCol(t)
if(0==e)return i
const s=this.getGemResById(e),n=s.quality,l=s.refineLv,a=i.Count(),o=new u.Z
for(let t=a-1;t>=0;t+=-1){const e=i[t];(e.quality>n||e.quality==n&&e.refineLv>l)&&o.Add(e)}return o}GetUniqueGemId(t,e,i){
return null!=this.uniqueGemDic[t][e]?this.uniqueGemDic[t][e][i]:null}GetNormalGemId(t,e,i){return null!=this.fluoriteDic[t][i]?this.fluoriteDic[t][e][i]:null}GetGemRes(t,e,i){
let s=this.GetNormalGemId(t,e,i)
return null==s&&(s=this.GetUniqueGemId(t,e,i)),s}SortFluorite(t,e){return t.quality>e.quality?-1:t.quality<e.quality?1:t.refineLv<e.quality?-1:t.refineLv>e.refineLv?1:0}
GetNeedUpMaxLevelExpByLevel(t){return this.needUpMaxLevelExpDic[t]}IsBoxMaxLevel(t){return t>=this.boxMaxLevel}}g._inst=null},60219:(t,e,i)=>{i.d(e,{M:()=>a})
var s=i(61911),n=i(85602),l=i(44758)
class a extends s.f{constructor(){super(),this.enhanceMasterTitle=null,this.additionMasterTitle=null,this.closeBtn=null,this.closeBtn2=null,this.activateBtn=null,
this.maxLevelTipColumn=null,this.enhanceMaxLevelTip=null,this.additionMaxLevelTip=null,this.propertyScrollView=null,this.propertyTable=null,this.weapon=null,this.subWeapon=null,
this.helmet=null,this.clothes=null,this.armguard=null,this.pants=null,this.shoes=null,this.scrollViewPanel=null,this.sucAniObj=null,this.model=null,this.curColumn=1,
this.curMasterLv=0,this.equipIndex=null,this.equipList=null,this.waitCnt=0,this.isUpgrade=!1,this.baseClipRegion=null,this._degf_OnBlockReady=null,this._degf_OnCloseBtnClick=null,
this._degf_OnPropertyBlockRefreshFun=null,this._degf_OnUpgradeBtnClick=null,this._degf_SetData=null,this.equipList=new n.Z,this.baseClipRegion=new l.L(0,-32,492,222),
this._degf_OnBlockReady=t=>this.OnBlockReady(t),this._degf_OnCloseBtnClick=(t,e)=>this.OnCloseBtnClick(t,e),
this._degf_OnPropertyBlockRefreshFun=t=>this.OnPropertyBlockRefreshFun(t),this._degf_OnUpgradeBtnClick=(t,e)=>this.OnUpgradeBtnClick(t,e),this._degf_SetData=t=>this.SetData(t)}
InitView(){}OnPropertyBlockRefreshFun(t){}OnMasterIconItemRefreshFun(t){}OnAddToScene(){}SetData(t){}OnBlockReady(t){}AddLis(){}RemoveLis(){}OnCloseBtnClick(t,e){}
OnUpgradeBtnClick(t,e){}Clear(){}Destroy(){}}},69846:(t,e,i)=>{i.d(e,{R:()=>nt})
var s=i(18998),n=i(83908),l=i(86133),a=i(97461),o=i(18202),r=i(83540),h=i(72785),d=i(21554),u=i(70850),c=i(15033),_=i(92679),I=i(87923),m=i(38836),g=i(38045),p=i(11210),C=i(98800),S=i(62370),f=i(66788),y=i(5494),v=i(95721),D=i(98130),E=i(98885),T=i(85602),A=i(38962),L=i(1240),w=i(59686),R=i(3859),O=i(1003),G=i(33314),b=i(44498),M=i(2457),P=i(39367),B=i(37648),x=i(55492),N=i(75439),k=i(42534),V=i(33138),F=i(65994),U=i(34101),H=i(14792),q=i(62734),Z=i(81476),j=i(56956),X=i(41850),Y=i(56582),W=i(93984),$=i(55360)
class J{constructor(){this.masterMap=null,this.limitMap=null,this.masterMap=new A.X
const t=$.Y.Inst.GetOrCreateCsv(W.h.eEquipEnhanceMaster)
this.masterMap=t.GetCsvMap(),this.limitMap=new A.X
for(const[t,e]of(0,m.V5)(this.masterMap)){
const t=E.M.IndexOf(e.id,S.o.s_UNDER_CHAR,0),i=E.M.SubStringWithEnd(e.id,0,t)+(S.o.s_UNDER_CHAR+(e.enhanceCastLevelCondition+e.enhanceLevelCondition))
this.limitMap.LuaDic_AddOrSetItem(i,e)}}static Inst(){return null==J._inst&&(J._inst=new J),J._inst}getItemById(t){
return this.masterMap.LuaDic_ContainsKey(t)?this.masterMap[t]:null}getItemByLv(t,e){const i=e
return this.getItemById(i)}getTopItemByPosAndLv(t,e,i){const s=new T.Z
for(const[e,i]of(0,m.vy)(this.masterMap)){const i=E.M.Split(e,S.o.s_UNDER_CHAR)[0]
t==E.M.String2Int(i)&&s.Add(this.masterMap[e])}const n=new T.Z,l=new T.Z
let a=0
for(;a<s.Count();)s[a].enhanceCastLevelCondition==e&&n.Add(s[a]),s[a].enhanceCastLevelCondition<e&&l.Add(s[a]),a+=1
let o=-1,r=-1
if(n.Count()>0){let t=0
for(;t<n.Count();)n[t].enhanceLevelCondition<=i&&n[t].enhanceLevelCondition>o&&(o=n[t].enhanceLevelCondition,r=t),t+=1
return-1!=r?n[r]:this.getTopItemByFilterList(l)}return this.getTopItemByFilterList(l)}getTopItemByFilterList(t){let e=-1,i=-1,s=-1,n=0
for(;n<t.Count();)t[n].enhanceCastLevelCondition>e&&(e=t[n].enhanceCastLevelCondition),n+=1
const l=new T.Z
let a=0
for(;a<t.Count();)t[a].enhanceCastLevelCondition==e&&l.Add(t[a]),a+=1
let o=0
for(;o<l.Count();)l[o].enhanceLevelCondition>i&&(i=l[o].enhanceLevelCondition,s=o),o+=1
return-1!=s?l[s]:null}}J._inst=null
class z{constructor(){this.stateList=null,this.stateList=new T.Z(10)}GetState(t){return this.stateList.count>t&&this.stateList[t]}SetState(t,e){
this.stateList.count>t&&(this.stateList[t]=e)}}z.equipCnt=14
class Q{constructor(){this.stateDic=null,this.stateDic=new A.X}SetBoolConditionState(t,e,i){let s=null
this.stateDic.LuaDic_ContainsKey(t)?s=this.stateDic[t]:(s=new z,this.stateDic.LuaDic_AddOrSetItem(t,s)),s.SetState(e,i)}SetIntConditionState(t,e,i){let s=null
this.stateDic.LuaDic_ContainsKey(t)?s=this.stateDic[t]:(s=new z,this.stateDic.LuaDic_AddOrSetItem(t,s)),s.SetState(e,i)}GetConditionState(t,e){let i=null
return!!this.stateDic.LuaDic_ContainsKey(t)&&(i=this.stateDic[t],i.GetState(e))}Clear(){this.stateDic.LuaDic_Clear()}}class K{constructor(){this.type=0,this.pos=0,this.openAsk=0}}
var tt,et=i(72835)
class it{constructor(){this.map=null
const t=$.Y.Inst.GetOrCreateCsv(W.h.eSuitcomposeResource)
this.map=t.GetCsvMap()}static Inst_get(){return null==it._inst&&(it._inst=new it),it._inst}GetResByEquip(t){if(0==t.initSuitId){
const e=C.Y.Inst.PrimaryRoleInfo_get().Job_get(),i=t.GetItemRes().job,s=t.GetItemRes().equipStepLv,n=e%10
let l=i
if(s>1){let t=s-1
for(l-=l%1e3;t>0;)l=et.V.Inst_get().GetNextTransferJob(l),t-=1
l-=l%10,l+=n}const a=t.GetEquipRes().intPosition_get()
let o=null
o=s<10?`${l}0${s+a}`:l+(s+a)
let r=null
if(this.map.LuaDic_ContainsKey(o))return r=this.map[o],r}return null}}it._inst=null
class st{constructor(){this.m_masterPartPos=null,this.stardata=null,this.EnhanceChildViewType=0,this.NowSelectEquipListType=0,this.intervalId=0,this.state=!1,this.isChange=!1,
this.curData=null,this.equipMasterViewData=null,this.lastData=null,this.selectEquipStage=0,this.selectEquipPos=0,this._defaultBaptizeEx=null,this.isMaterialEnough=!1,
this.isItemEnough=!1,this.isCurrencyEnough=!1,this.curEquipId=0,this.curLusuoId=null,this.extendIndex=0,this.selectIndex=0,this.enhance_master_limit=0,this.add_master_limit=0,
this.excellence_master_limit=0,this.enhanceLevelLimitStr=null,this.enhanceWingsLevelLimitStr=null,this.additionDiamondCost=-1,this.baptizeMinStarNum=-1,this.baptizeLowQuality=-1,
this.baptizeCantQuality=-1,this.activeTalentCondStr="",this.baptizeTalentState=null,this.hasDefaultSelectd=!1,this.curSelectedAttrRes=null,this.enhanceMsg=null,
this.enhanceMaterialList=null,this.enhanceRateEquipment=null,this.enhanceRateEquipmentIds=null,this.advanceMaterialList=null,this.isInAutoEnhance=!1,this.isInAutoAdd=!1,
this.compareEquip=null,this.strengthenListEnhanceEquip=null,this.showEnhanceStrengthenListEquip=!1,this.strengthenEnhanceEquipPos=null,this.strengthenListAdditionEquip=null,
this.showAdditionStrengthenListEquip=!1,this.strengthenAddEquipPos=null,this.additionRedDotRefreshLv=null,this.enhanceRedDotRefreshLv=null,this.enhanceRedDotStage=0,
this.enhanceRedDotStageList=null,this.additionRedDotStage=0,this.enhanceMasterRedColumnList=null,this.addMasterRedColumnList=null,this.elementRedColumnList=null,
this.enhanceConditionState=null,this.additionConditionState=null,this.equipInlayStepAsk=0,this.equipInlayExcellCountAsk=0,this.curSelectJewelIndex=0,this.curSelectJewelDatas={},
this.curSelfSelectJewelIndexs={},this.jewelRedColumn=-1,this.jewelRedPos=-1,this.jewelInlayRedColumn=-1,this.jewelInlayRedPos=-1,this.jewelReplaceRedColumn=-1,
this.jewelReplaceRedPos=-1,this.jewelSmeltRedColumn=-1,this.jewelSmeltRedPos=-1,this.jewelUpRedColumn=-1,this.jewelUpRedPos=-1,this.sameSmeltJewelMax=0,this.selectInlayItemId=null,
this.selectUpItemTypes=null,this.showSmeltIconMinQuality=0,this.selectShowJewelBookId=0,this.curSelectConsumeId=0,this.curSelectSmeltIndex=0,this.openUseTipQualityJudge=0,
this.suitCompoundRedDotStage=-1,this.suitCompoundRedDotPos=-1,this.awakeRedDotColumn=-1,this.awakeRedDotPos=-1,this.awakeMaterialEquipment=null,this.awakeMaterialEquipmentIds=null,
this.awakeLastEquip=null,this.awakeCurEquip=null,this.isAwakeSuccessShow=!1,this.curSoulTipsIndex=0,this._degf_ColumnSortList=null,this._degf_SortList=null,
this._degf_SortList2=null,this._degf_SortMaterialEquipByStep=null,this._degf_SortExcellenceAttr=null,this._degf_JewelEquipSortHandler=null,this.strengthenAddEquipStage=null,
this.oldRate=null,this.baptizeTalentState=new A.X,this.strengthenEnhanceEquipPos=new A.X,this.strengthenAddEquipPos=new A.X,this.enhanceMasterRedColumnList=new T.Z,
this.addMasterRedColumnList=new T.Z,this.elementRedColumnList=new T.Z,this.selectUpItemTypes=new T.Z,this._degf_ColumnSortList=(t,e)=>this.ColumnSortList(t,e),
this._degf_SortList=(t,e)=>this.SortList(t,e),this._degf_SortList2=(t,e)=>this.SortList2(t,e),this._degf_SortMaterialEquipByStep=(t,e)=>this.SortMaterialEquipByStep(t,e),
this._degf_SortExcellenceAttr=(t,e)=>this.SortExcellenceAttr(t,e),this._degf_JewelEquipSortHandler=(t,e)=>this.JewelEquipSortHandler(t,e),this.enhanceMaterialList=new T.Z,
this.advanceMaterialList=new T.Z,this.enhanceRateEquipment=new T.Z,this.enhanceRateEquipmentIds=new T.Z,this.awakeMaterialEquipment=new T.Z,this.awakeMaterialEquipmentIds=new T.Z,
this.curLusuoId=v.o.New(),this.InitConditionSet(),this.GetJewelConfigData()}static Inst(){return null==st.inst&&(st.inst=new st),st.inst}CurData_get(){return this.curData}
CurData_set(t){}SelectEquipStage_get(){return this.selectEquipStage}SelectEquipStage_set(t){this.selectEquipStage!=t&&(this.selectEquipStage=t,this.isChange=!0,
a.i.Inst.RaiseEvent(_.g.FORGE_ENHANCE_EQUIPCOLUMNCHANGE))}SelectEquipPos_get(){return this.selectEquipPos}SelectEquipPos_set(t,e){null==e&&(e=!1),
(this.selectEquipPos!=t||e)&&(this.selectEquipPos=t,this.isChange=!0)}DefaultBaptizeEx_get(){return this._defaultBaptizeEx}DefaultBaptizeEx_set(t){this._defaultBaptizeEx=t}
ENHANCE_MASTER_LIMIT_get(){if(0==this.enhance_master_limit){J.Inst()}return this.enhance_master_limit}ADD_MASTER_LIMIT_get(){if(0==this.add_master_limit){Y.r.Inst()}
return this.add_master_limit}GetJewelConfigData(){}Excellence_Master_Limit_get(){return this.excellence_master_limit}EnhanceLevelLimitStr_get(){if(null==this.enhanceLevelLimitStr){
const t=N.D.getInstance().getContent("ENHANCE:LEVEL_LIMIT_DESC")
this.enhanceLevelLimitStr=t.getContent().stringVal}return this.enhanceLevelLimitStr}EnhanceWingsLevelLimitStr_get(){if(null==this.enhanceWingsLevelLimitStr){
const t=N.D.getInstance().getContent("ENHANCE:LEVEL_LEVEL_LIMIT_WINGSDESC")
this.enhanceWingsLevelLimitStr=t.getContent().stringVal}return this.enhanceWingsLevelLimitStr}AdditionDiamondCost_get(){return this.additionDiamondCost}BaptizeMinStarNum_get(){
return this.baptizeMinStarNum}BaptizeLowQuality_get(){return this.baptizeLowQuality}BaptizeCantQuality_get(){return this.baptizeCantQuality}ActiveTalentCondStr_get(){
return this.activeTalentCondStr}IsTalentActived(t,e){null==e&&(e=-1),-1==e&&(e=this.selectEquipStage)
const i=C.Y.Inst.PrimaryRoleInfo_get().GetEquipmentsByColumn(e).talentIds
return null!=i&&i.Contains(t)}GetEquipState(t){return t.ExcellenceCount_get()>0&&0!=t.suitId?t.exellectAttrs.isAllAttrsReachCond?2:3:1}GetCurEquipState(t,e){if(null==e&&(e=0),
null==t&&null!=this.CurData_get()&&(t=this.CurData_get().serverData_get()),null!=t){const e=k.f.Inst().getItemById(t.modelId)
if(null!=e&&e.IsCanEnhance()){const i=X.C.Inst().getResByColumnPosLevel(t.Column_Get(),t.Pos_Get(),t.Enhancelevel_get())
if(null==i)return f.Y.LogError(`${(0,l.T)("强化表缺少对应等级：")}${t.Column_Get()}_${t.Pos_Get()}_${t.Enhancelevel_get()}`),0
const s=X.C.Inst().GetEnhanceMaxEnhanceIdByColAndPos(t.Column_Get(),t.Pos_Get()),n=this.GetMaxEhanceLevelByLocationAndStage(t.Column_Get(),t.Pos_Get(),e.GetStage(),t.GetCombindExcellentCount()),a=i.id
return X.C.Inst().GetIsCanSpecialEnhanceLimit(a)?-2:a<=n&&a<s?1:a<s?-3:-2}}return 0}GetCurEquipAddState(t){
if(null==t&&null!=this.CurData_get()&&(t=this.CurData_get().serverData_get()),null!=t&&t.GetEquipRes().IsCanAdd()){
const e=t.GetEquipRes(),i=t.Pos_Get(),s=this.GetMaxAddLevelByAddType(i),n=this.GetMaxAddLevelByAddTypeAndStage(t.Pos_Get(),e.GetStage()),l=t.equipmentAdd.addLevel
return l<n?1:l<s?2:3}return 0}getMasterLvByEnhanceLv(t,e,i){const s=t+(S.o.s_UNDER_CHAR+(e+(S.o.s_UNDER_CHAR+i)))
if(J.Inst().limitMap.LuaDic_ContainsKey(s))return J.Inst().limitMap[s].enhanceMasterLevel
const n=J.Inst().getTopItemByPosAndLv(t,e,i)
return null!=n?n.enhanceMasterLevel:0}getMasterLvByAdditionLv(t,e){const i=t+(S.o.s_UNDER_CHAR+e)
if(Y.r.Inst().limitMap.LuaDic_ContainsKey(i))return Y.r.Inst().limitMap[i].addMasterLevel
const s=Y.r.Inst().getTopItemByPosAndLv(t,e)
return null!=s?s.addMasterLevel:0}CanEquipmentAdvance(t){if(1==b.I.GetEquipStarsNum(t)&&(9==t.Enhancelevel_get()||12==t.Enhancelevel_get())){
if(9==t.Enhancelevel_get()&&2!=b.I.GetExeAttrsNum(t))return!1
if(12==t.Enhancelevel_get()&&3!=b.I.GetExeAttrsNum(t))return!1
k.f.Inst().getItemById(t.modelId).intPosition_get(),b.I.GetExeAttrsNum(t)
const e=0
if(u.g.Inst_get().GetAdvanceMaterialEquipList(t).Count()>=e)return!0}return!1}GetAuctionItemName(){let t="",e=null
for(const[i,s]of(0,m.V5)(this.enhanceRateEquipmentIds))if(e=u.g.Inst_get().GetItemById(s),null!=e&&0!=e.baseData_get().AuctionState_get()){
t=I.l.SetEquipName(e.baseData_get().equipInfo_get(),e.baseData_get().cfgData_get(),e.baseData_get().serverData_get())[0]
break}return t}GetEnhanceIsMaterialEnough(t,e,i){null==e&&(e=0)
const s=k.f.Inst().getItemById(t.modelId)
let n=0,l=null
if(null==s||!s.IsCanEnhance())return 0
if(0==e){const e=X.C.Inst().getResByLevel(t.Pos_Get(),t.Enhancelevel_get())
if(null==e)return 0
l=e.itemConsumesDic}else if(1==e){s.ElementTypeStr_get(i)
l=elementRes.costDict}for(const[t,e]of(0,m.vy)(l))if(n=u.g.Inst_get().GetItemNum(t),l[t]>n)return t
return 0}GetAddIsMaterialEnough(t){k.f.Inst().getItemById(t.modelId)
let e=0,i=null
const s=t.Column_Get(),n=t.Pos_Get(),l=j.O.Inst().getResByLevel(s,n,t.equipmentAdd.addLevel)
if(null!=l){i=l.itemConsumesDic
for(const[t,s]of(0,m.vy)(i))if(e=u.g.Inst_get().GetItemNum(t),i[t]>e)return t}return 0}GetIsCastMaterialEnough(t){return 0}GetIsAddMaterialEnough(t){
const e=j.O.Inst().getResByLevel(t.Column_Get(),t.Pos_Get(),t.equipmentAdd.addLevel)
if(null!=e){let t=new A.X
t=e.itemConsumesDic
let i=0
for(const[e,s]of(0,m.vy)(t))if(i=u.g.Inst_get().GetItemNum(e),t[e]>i)return e}return 0}IsShowPreviewBtn(){
return null!=this.curData&&(0==this.EnhanceChildViewType&&I.l.EquipHasShine(this.curData.cfgEquipData_get().intPosition_get()))}GetModelId(t,e,i){return X.C.Inst().GetModelId(i)}
GetNextEnhanceLevel(t){const e=X.C.Inst().getResByLevel(t.Pos_Get(),t.Enhancelevel_get()),i=X.C.Inst().ShineIdIndex(e.level)+1
if(i<X.C.Inst().shineLevels.count){const e=X.C.Inst().shineLevels[i]-1
return X.C.Inst().getResByLevel(t.Pos_Get(),e).level}return t.Enhancelevel_get()}GetNextCastLevel(t){
const e=X.C.Inst().getResByLevel(t.Pos_Get(),t.Enhancelevel_get()),i=X.C.Inst().ShineIdIndex(e.level)+1
if(i<X.C.Inst().shineLevels.count){const e=X.C.Inst().shineLevels[i]-1
return X.C.Inst().getResByLevel(t.Pos_Get(),e).castNum}return t.EnhanceSoulLevel_get()}isShineLevelChange(t,e){
const i=X.C.Inst().getResByLevel(t.Pos_Get(),t.EnhanceSoulLevel_get(),t.Enhancelevel_get()),s=X.C.Inst().ShineIdIndex(i.level),n=X.C.Inst().getResByLevel(t.Pos_Get(),t.EnhanceSoulLevel_get(),e)
return X.C.Inst().ShineIdIndex(n.level)!=s}GetEnhanceOpenState(){let t=!1
C.Y.Inst.PrimaryRoleInfo_get()
const e=new T.Z
return B.P.Inst_get().IsFunctionOpened(x.x.EQUIP_ENHANCE)&&e.Add(Z.s.EnhanceTab),B.P.Inst_get().IsFunctionOpened(x.x.EQUIP_ADD)&&e.Add(Z.s.AdditionTab),
B.P.Inst_get().IsFunctionOpened(x.x.EQUIP_LUCKY)&&e.Add(Z.s.FortuneTab),B.P.Inst_get().IsFunctionOpened(x.x.EXELLENT_ADD)&&e.Add(Z.s.ExcellentAdditionTab),
B.P.Inst_get().IsFunctionOpened(x.x.STAR_TRANSFER)&&e.Add(Z.s.StarTransferTab),B.P.Inst_get().IsFunctionOpened(x.x.EQUIP_PROMOTE)&&e.Add(Z.s.EquipPromoteTab),
e.Count()>0&&(this.EnhanceChildViewType=e[0],t=!0),t}EnhanceRedDotRefreshLv_get(){return this.enhanceRedDotRefreshLv}AdditionRedDotRefreshLv_get(){
return this.additionRedDotRefreshLv}IsInEnhanceMasterRed(t){let e=0
for(;e<this.enhanceMasterRedColumnList.Count();){if(t==this.enhanceMasterRedColumnList[e])return!0
e+=1}return!1}IsInAddMasterRed(t){let e=0
for(;e<this.addMasterRedColumnList.Count();){if(t==this.addMasterRedColumnList[e])return!0
e+=1}return!1}IsInElementMasterRed(t){let e=0
for(;e<this.elementRedColumnList.Count();){if(t==this.elementRedColumnList[e])return!0
e+=1}return!1}CheckStrengthenState(){}ColumnSortList(t,e){return t>e?-1:t<e?1:0}CheckJewelInlayRedState(){return this.jewelRedColumn=-1,this.jewelRedPos=-1,
this.jewelInlayRedColumn=-1,this.jewelInlayRedPos=-1,this.jewelReplaceRedColumn=-1,this.jewelReplaceRedPos=-1,this.jewelSmeltRedColumn=-1,this.jewelSmeltRedPos=-1,
this.jewelUpRedColumn=-1,this.jewelUpRedPos=-1,-1!=this.jewelInlayRedColumn&&-1!=this.jewelInlayRedPos?(this.jewelRedColumn=this.jewelInlayRedColumn,
this.jewelRedPos=this.jewelInlayRedPos):-1!=this.jewelReplaceRedColumn&&-1!=this.jewelReplaceRedPos?(this.jewelRedColumn=this.jewelReplaceRedColumn,
this.jewelRedPos=this.jewelReplaceRedPos):-1!=this.jewelSmeltRedColumn&&-1!=this.jewelSmeltRedPos?(this.jewelRedColumn=this.jewelSmeltRedColumn,
this.jewelRedPos=this.jewelSmeltRedPos):-1!=this.jewelUpRedColumn&&-1!=this.jewelUpRedPos&&(this.jewelRedColumn=this.jewelUpRedColumn,this.jewelRedPos=this.jewelUpRedPos),
a.i.Inst.RaiseEvent(_.g.JEWELINLAY_CONDITION_UPDATE,!1),EnhanceTopControl.Inst().UpdateEnhanceColumnAndPosRedPoint(),-1!=this.jewelRedColumn&&-1!=this.jewelRedPos}
GetResultStageEquipList(t){let e=0
const i=C.Y.Inst.PrimaryRoleInfo_get().GetEquipmentsByColumn(t),s=new T.Z
if(null!=i&&null!=i.equipmentsGet()&&0!=i.equipmentsGet().count)for(e=0;e<i.equipmentsGet().Count();)null!=i.equipmentsGet()[e]&&s.Add(this.GetResultStageEquipData(t,e,i.equipmentsGet()[e])),
e+=1
s.Sort(this._degf_JewelEquipSortHandler)
const n=new A.X
for(e=0;e<s.Count();)n.LuaDic_AddOrSetItem(s[e].pos,e),e+=1
return n}GetResultStageEquipData(t,e,i){const s=C.Y.Inst.PrimaryRoleInfo_get()
let n=null
n=new K,n.pos=e
return null!=s&&null!=i&&this.JudgeEquipJewelDataIsNull(i),n.type=0,n}JewelEquipSortHandler(t,e){if(null==t&&null==e)return 0
if(t.type>e.type)return-1
if(t.type<e.type)return 1
if(1==t.type){if(t.openAsk<e.openAsk)return-1
if(t.openAsk>e.openAsk)return 1}return t.pos<e.pos?-1:t.pos>e.pos?1:0}CheckColumnJewelRedState(t,e){if(null!=t&&0!=t.equipmentsGet()){let i=0
for(;i<t.equipmentsGet().Count();){const s=t.equipmentsGet()[i]
2==this.GetResultStageEquipData(e,i,s).type&&this.CheckEquipRedJewelPos(s.jewelData.positions,e,i),i+=1}}}CheckEquipRedJewelPos(t,e,i){if(null!=t){let s=0
const n=t.Count()
for(;s<n;){const n=t[s]
;-1==this.jewelInlayRedColumn&&-1==this.jewelInlayRedPos&&null!=n&&n.active&&null==n.equipmentJewel&&this.CheckIsHasJewelItemInBag(e,i)&&(this.jewelInlayRedColumn=e,
this.jewelInlayRedPos=i),-1==this.jewelReplaceRedColumn&&-1==this.jewelReplaceRedPos&&this.JewelIsCanReplace(n,e,i)&&(this.jewelReplaceRedColumn=e,this.jewelReplaceRedPos=i),
-1==this.jewelSmeltRedColumn&&-1==this.jewelSmeltRedPos&&this.JewelIsCanSmelt(n,e)&&(this.jewelSmeltRedColumn=e,this.jewelSmeltRedPos=i),
-1==this.jewelUpRedColumn&&-1==this.jewelUpRedPos&&this.JewelIsCanUp(n)&&(this.jewelUpRedColumn=e,this.jewelUpRedPos=i),s+=1}}}CheckIsHasJewelItemInBag(t,e){return!1}
JewelIsCanInlayOrSmelt(t,e){const i=this.GetJewelOrSmeltTransAsk(t)
let s=0
const n=V.f.Inst().getItemById(t)
return null!=n&&(s=n.job),!(!G.Z.ReachJobLimit(s)||0!=i&&i!=e)}GetJewelTypeStrByType(t){return 1==t?(0,l.T)("武器"):2==t?(0,l.T)("防具"):3==t?(0,l.T)("特殊"):""}
GetAllSmeltIdAndNumByColumn(t){const e={},i=C.Y.Inst.PrimaryRoleInfo_get().GetEquipmentsByColumn(t)
if(null!=i&&null!=i.equipmentsGet())for(const[t,s]of(0,m.V5)(i.equipmentsGet()))if(null!=s&&null!=s.jewelData&&null!=s.jewelData.positions){const t=s.jewelData.positions
for(const[i,s]of(0,m.V5)(t))if(null!=s&&null!=s.equipmentJewel&&null!=s.equipmentJewel.smelt){const t=s.equipmentJewel.smelt
for(const[i,s]of(0,m.V5)(t))null!=s&&0!=s&&(null!=e[s]?e[s]=e[s]+1:e[s]=1)}}return e}GetJewelInlayOrSmeltState(t,e){const i=this.GetJewelOrSmeltTransAsk(t)
let s=0
const n=V.f.Inst().getItemById(t)
return null!=n&&(s=n.job),0!=i&&i!=e?1e4+i:G.Z.ReachJobLimit(s)?0:2e4+s}GetJewelOrSmeltTransAsk(t){const e=V.f.Inst().getItemById(t)
if(null!=e&&null!=e.Conditions_get()&&null!=e.Conditions_get().typevalues){const t=e.Conditions_get().typevalues
for(const[e,i]of(0,m.V5)(t))if("EQUIP_STEP_LV"==i.type)return E.M.String2Int(i.value)}return 0}CheckEnhanceMasterState(){let t=!1
this.enhanceMasterRedColumnList.Clear()
for(const[e,i]of(0,m.vy)(C.Y.Inst.PrimaryRoleInfo_get().AllStageEquipments_get())){const i=null
this.CheckEnhanceMasterStateByColumn(e,i)&&(t=!0,this.enhanceMasterRedColumnList.Add(e))}return q.f.Inst.SetState(H.t.ENHANCE_MASTER,t),t}CheckAdditionMasterState(){return!1}
CheckElementMasterState(){this.elementRedColumnList.Clear()
for(const[t,e]of(0,m.vy)(C.Y.Inst.PrimaryRoleInfo_get().AllStageEquipments_get()));return!1}CheckEnhanceStrengthenState(t){const e=p.i.Inst.GetCurSelect(y.I.ForgePanel)
null==t&&(t=!0),this.strengthenListEnhanceEquip=null,this.showEnhanceStrengthenListEquip=!1,this.strengthenEnhanceEquipPos.LuaDic_Clear()
const i=C.Y.Inst.GetMultPlayerInfos()
let s=!1
for(const[n,l]of(0,m.V5)(i)){let i=null
const n=!1
let a=!1
const o=l
e.createIdx==o.createIdx&&(a=!0)
if(B.P.Inst_get().IsFunctionOpened(x.x.EQUIP_ENHANCE)){const e=new T.Z
let l=!1
const a=o.GetEquipmentsByColumn()
if(null!=a){let t=0
for(;t<a.equipmentsGet().Count();){const i=a.equipmentsGet()[t]
if(null!=i){const s=this.enhanceConditionState.GetConditionState(o.createIdx,t)
0!=s&&s>0&&(l||(e.Clear(),l=!0),e.Add(i))}t+=1}}if(e.Count()>0&&(e.Sort(this._degf_SortList),i=e[0]),q.f.Inst.SetState(H.t.EQUIP_ENHANCE,null!=i,o.createIdx),null!=i){
this.strengthenListEnhanceEquip=i,this.showEnhanceStrengthenListEquip=n
const e=o.GetEquipmentsByColumn().equipments
let l=0
for(;l<e.Count();){if(null!=e[l]&&i.id.Equal(e[l].id)){this.strengthenEnhanceEquipPos[o.createIdx]=l
break}l+=1}this.strengthenEnhanceEquipPos.LuaDic_ContainsKey(o.createIdx)&&t&&I.l.CheckTrigger(M.u.COND_EQUIP_ENHANCE_VAL),s=!0}}}return s}CheckAdditionStrengthenState(){
const t=p.i.Inst.GetCurSelect(y.I.ForgePanel)
this.strengthenListAdditionEquip=null,this.showAdditionStrengthenListEquip=!1,this.strengthenAddEquipPos.LuaDic_Clear()
const e=C.Y.Inst.GetMultPlayerInfos()
for(const[i,s]of(0,m.V5)(e)){let e=null
const i=!1
let n=!1
const l=s
t.createIdx==l.createIdx&&(n=!0)
if(B.P.Inst_get().IsFunctionOpened(x.x.EQUIP_ADD)){const t=new T.Z
this.strengthenAddEquipStage=-1
let s=!1
const n=l.GetEquipmentsByColumn()
if(null!=n){let e=0
for(;e<n.equipmentsGet().Count();){const i=n.equipmentsGet()[e]
if(null!=i){this.additionConditionState.GetConditionState(l.createIdx,e)&&(s||(t.Clear(),s=!0),t.Add(i))}e+=1}}if(t.Count()>0&&(t.Sort(this._degf_SortList2),e=t[0]),null!=e){
this.strengthenListAdditionEquip=e,this.showAdditionStrengthenListEquip=i
const t=l.GetEquipmentsByColumn().equipments
let s=0
for(;s<t.Count();){if(null!=t[s]&&e.id.Equal(t[s].id)){this.strengthenAddEquipPos[l.createIdx]=s
break}s+=1}}q.f.Inst.SetState(H.t.EQUIP_ADDITION,null!=e,l.createIdx)}}return!1}CheckEnhanceMasterStateByColumn(t,e){(e=new T.Z)[0]=0,e[1]=0
let i=null,s=null
const n=C.Y.Inst.PrimaryRoleInfo_get()
if(B.P.Inst_get().IsFunctionOpened(x.x.EQUIP_ENHANCE)){const l=n.GetEquipmentsByColumn(t)
if(null!=l&&l.unlockColumn){const t=l.historyMaxMasterLevel
if(i=J.Inst().getItemByLv(t),s=J.Inst().getItemByLv(t+1),null==s)return null==i||(e[1]=i.enhanceLevelCondition,e[0]=7),!1
e[1]=s.enhanceLevelCondition
const n=l.equipmentsGet()
let a=0
for(;a<this.m_masterPartPos.count;){const t=n[this.m_masterPartPos[a]]
null!=t&&(t.ExcellenceCount_get()>0||t.suitId>0)&&t.Enhancelevel_get()>=e[1]&&(e[0]+=1),a+=1}}}return 7==e[0]}CheckAdditionMasterStateByRoleInfo(t,e){return!1}
GetCurrentEnhanceMasterProgressByColumn(t,e){let i=0
e[0]=0
let s=null,n=null
const l=C.Y.Inst.PrimaryRoleInfo_get()
if(B.P.Inst_get().IsFunctionOpened(x.x.EQUIP_ENHANCE)){const t=l.GetEquipmentsByColumn()
if(null!=t){const l=t.masterLevel
if(s=J.Inst().getItemByLv(l),n=J.Inst().getItemByLv(l+1),null==n)return e[0]=s.enhanceLevelCondition,i=7,i
e[0]=n.enhanceLevelCondition
const a=t.equipmentsGet()
let o=0
for(;o<this.m_masterPartPos.count;){const t=a[this.m_masterPartPos[o]]
null!=t&&(t.ExcellenceCount_get()>0||t.suitId>0)&&t.Enhancelevel_get()>=e[0]&&(i+=1),o+=1}}}return i}GetCurrentElementMasterState(t){return!1}GetCurrentElementMasterProgress(t){
C.Y.Inst.PrimaryRoleInfo_get()
return 0}GetCurrentAdditionMasterProgress(t){return 0}SortList(t,e){const i=t.GetEquipPos(),s=e.GetEquipPos()
return i>s?1:i<s?-1:0}SortList2(t,e){const i=t.GetEquipPos(),s=e.GetEquipPos()
return i>s?1:i<s?-1:0}SetEnhanceStrengthenDefaultByParam(t){this.strengthenListEnhanceEquip=null,this.showEnhanceStrengthenListEquip=!1
const e=C.Y.Inst.PrimaryRoleInfo_get().AllStageEquipments_get(),i=new T.Z
for(const[t,s]of(0,m.V5)(e))i.Add(s)
let s=0
for(;s<i.Count();){const e=i[s].equipments
if(null!=e){let i=0
for(;i<e.Count();){if(null!=e[i]&&e[i].GetEquipRes().equipType==t)return this.strengthenListEnhanceEquip=e[i],void(this.showEnhanceStrengthenListEquip=!0)
i+=1}}s+=1}}SetEnhanceStrengthenDefaultByPos(t){this.strengthenListEnhanceEquip=null,this.showEnhanceStrengthenListEquip=!1
const e=C.Y.Inst.PrimaryRoleInfo_get().AllStageEquipments_get(),i=new T.Z
for(const[t,s]of(0,m.V5)(e))i.Add(s)
let s=0
for(;s<i.Count();){const e=i[s].equipments
null!=e&&null!=e[t]&&(this.strengthenListEnhanceEquip=e[t],this.showEnhanceStrengthenListEquip=!0),s+=1}}SetEnhanceAddtionhenDefaultByParam(t){
this.strengthenListAdditionEquip=null,this.showAdditionStrengthenListEquip=!1
const e=C.Y.Inst.PrimaryRoleInfo_get().AllStageEquipments_get(),i=new T.Z
for(const[t,s]of(0,m.V5)(e))i.Add(s)
let s=0
for(;s<i.Count();){const e=i[s].equipments
if(null!=e[s]&&e[s].GetEquipRes().equipType==t)return this.strengthenListAdditionEquip=e[s],void(this.showAdditionStrengthenListEquip=!0)
s+=1}}InitConditionSet(){this.enhanceConditionState=new Q,this.additionConditionState=new Q}UpdateEnhanceConditionState(){}UpdateAdditionConditionState(){}GetFinalEnhanceRate(t,e){
let i=t.succRate
return i+=e,i>t.succRateLimit&&(i=t.succRateLimit),i}GetEnhanceMaterialEquipList(t){const e=new T.Z,i=u.g.Inst_get().GetEquipList()
let s=0
for(;s<i.Count();){const n=i[s].serverData_get()
if((null==n.deprecatedTime||n.deprecatedTime.Equal(v.o.ZERO))&&!n.IsAngelEquip()){let l=!0
if(1==t.jobCondition&&D.GF.INT(n.GetItemRes().job/1e3)!=D.GF.INT(C.Y.Inst.PrimaryRoleInfo_get().Job_get()/1e3)&&(l=!1),
l&&i[s].baseData_get().cfgData_get().equipStepLv<t.materialStep&&(l=!1),l&&t.materialExcellenceNum>0&&n.ExcellenceCount_get()<t.materialExcellenceNum&&(l=!1),
l&&1==t.materialSuit&&n.suitId<=0&&(l=!1),l){const t=new L.Y
t.Clone(i[s]),t.baseData_get().isCanOperate=!1,t.baseData_get().isEquipCompare=!1,t.baseData_get().tipPosType=w.l.EnhanceMaterial,e.Add(t)}}s+=1}
return e.Sort(this._degf_SortMaterialEquipByStep),e}SortMaterialEquipByStep(t,e){const i=t,s=e
return i.baseData_get().cfgData_get().equipStepLv>s.baseData_get().cfgData_get().equipStepLv?-1:i.baseData_get().cfgData_get().equipStepLv<s.baseData_get().cfgData_get().equipStepLv?1:0
}IsInJewelRedColumnAndPos(){return this.SelectEquipStage_get()==this.jewelRedColumn&&this.SelectEquipPos_get()==this.jewelRedPos}JewelIsCanUp(t){return!1}JewelIsCanReplace(t,e,i){
return!1}JudgeCurJewelIsCanReplace(t,e,i,s){return!1}JewelIsCanSmelt(t,e){return!1}CurSelectJewelDatas_GetCount(){let t=0
for(const[e,i]of(0,m.X)(this.curSelectJewelDatas))t+=1
return t}CurSelectJewelDatas_Clear(){this.curSelectJewelDatas={}}CurSelfSelectJewelIndexs_Clear(){this.curSelfSelectJewelIndexs={}}CurSelfSelectJewelndexs_Set(t,e){
const i=null!=this.curSelfSelectJewelIndexs[t]
e?i||(this.curSelfSelectJewelIndexs[t]=1):i&&(this.curSelfSelectJewelIndexs[t]=null)}JudgeIsSelfSelectJeweByIndex(t){return null!=this.curSelfSelectJewelIndexs[t]}
CurSelectJewelDatas_Set(t,e,i){const s=null!=this.curSelectJewelDatas[t]
i?s||(this.curSelectJewelDatas[t]=e):s&&(this.curSelectJewelDatas[t]=null)}CurSelectJewelDatas_GetExp(){let t=0,e=0
for(const[i,s]of(0,m.X)(this.curSelectJewelDatas)){const i=s
if(null!=i&&null!=i.cfgData_get()&&null!=i.serverData_get()){const s=i.cfgData_get()
if(null!=s){t=0
let n=F.n.Inst().GetItemById(s.id)
if(null!=n&&(t=n.resolveExp),s.itemType==R.q.EQUIPJEWEL){const e=i.serverData_get()
if(null!=e&&(t+=e.exp.ToNum(),null!=e.smelt))for(const[i,s]of(0,m.V5)(e.smelt))null!=s&&0!=s&&(n=F.n.Inst().GetItemById(s),null!=n&&(t+=n.resolveExp))}e+=t*i.serverData_get().num}}
}return e}CurSelectJewelDatas_GetIds(){const t=new A.X
for(const[e,i]of(0,m.X)(this.curSelectJewelDatas)){const e=i.serverData_get().id.ToString()
t.LuaDic_ContainsKey(e)?t[e]=t[e]+1:t.LuaDic_AddOrSetItem(e,1)}for(const[e,i]of(0,m.vy)(t))t[e]=(0,g.tw)(t[e])
return t}CurSelectJewelDatas_IsHasSmelt(){for(const[t,e]of(0,m.X)(this.curSelectJewelDatas)){const t=e
if(null!=t&&null!=t.cfgData_get()){const e=t.cfgData_get()
if(null!=e&&e.itemType==R.q.EQUIPJEWEL){const e=t.serverData_get()
if(null!=e&&null!=e.smelt)for(const[t,i]of(0,m.V5)(e.smelt))if(null!=i&&0!=i)return!0}}}return!1}SelectUpItemTypes_Set(t,e){const i=this.selectUpItemTypes.Contains(t)
e?i||this.selectUpItemTypes.Add(t):i&&this.selectUpItemTypes.Remove(t)}SelectUpItemTypes_Clear(){this.selectUpItemTypes.Clear()}SelectUpItemTypes_Contains(t){
return this.selectUpItemTypes.Contains(t)}GetCommJewelAttrDesc(t,e,i){}GetAttrData(t,e,i,s,n){}GetNoData(t,e){}GetTitleData(t,e,i,s){}GetAttrDesc(t,e,i,s,n){null==n&&(n=!0)
let l=""
return l=n?I.l.GetQualityColorStr(s,t+(S.o.s_LEFT_S_K_CCHAR+(e+(E.M.s_SPACE_CHAR+(S.o.s_ADD_STR+(i+S.o.s_RIGHT_S_K_CCHAR)))))):I.l.GetQualityColorStr(s,t+(S.o.s_LEFT_S_K_CCHAR+(e+S.o.s_RIGHT_S_K_CCHAR))),
l}CheckIsOpenInlayPanelInUseSmelt(t){return!0}CheckIsHasNullJewelnEquip(t){for(const[e,i]of(0,m.V5)(t))if(null!=i&&i.active&&null==i.equipmentJewel)return!0
return!1}CheckIsHasNullAttachCountJewel(t){for(const[e,i]of(0,m.V5)(t))if(null!=i&&i.active&&null!=i.equipmentJewel){const t=F.n.Inst().GetItemById(i.equipmentJewel.modelId)
if(null!=t&&0==t.attachCount)return!0}return!1}CheckIsHasCanSmeltJewelnEquip(t){let e=null
for(const[i,s]of(0,m.V5)(t))if(null!=s&&null!=s.equipmentJewel&&(e=F.n.Inst().GetItemById(s.equipmentJewel.modelId),null!=e&&0!=e.attachCount))return!0
return!1}CheckIsHasCanSmeltJewelInBag(t,e){return!1}CheckSmeltIsOpenUseTip(t){return!1}IsNoInlayCanSmeltJewel(t){for(const[e,i]of(0,m.V5)(t))if(null!=i&&i.active){
if(null==i.equipmentJewel)return!0
{const t=F.n.Inst().GetItemById(i.equipmentJewel.modelId)
if(null!=t&&0==t.attachCount)return!0}}return!1}IsCanSmeltInJewel(t,e){if(null!=U.f.Inst().GetItemById(e))for(const[e,i]of(0,
m.V5)(t))if(null!=i&&i.active&&null!=i.equipmentJewel&&null!=i.equipmentJewel.smelt)for(const[t,e]of(0,m.V5)(i.equipmentJewel.smelt))if(null==e||0==e)return!0
return!1}IsHasLowQualitySmeltInJewel(t,e){const i=V.f.Inst().getItemById(e)
let s=null
if(null!=i)for(const[e,n]of(0,m.V5)(t))if(null!=n&&n.active&&null!=n.equipmentJewel&&null!=n.equipmentJewel.smelt)for(const[t,e]of(0,
m.V5)(n.equipmentJewel.smelt))if(s=V.f.Inst().getItemById(e),null!=s&&s.Quality_get()<i.Quality_get())return!0
return!1}CheckJewelIsOpenUseTip(t){return!1}IsCanInlayInEquip(t,e,i){return!1}IsHasNoInlayPosInEquip(t){for(const[e,i]of(0,
m.V5)(t))if(null!=i&&i.active&&null==i.equipmentJewel)return!0
return!1}IsHasLowQualityJewelInEquip(t,e){const i=V.f.Inst().getItemById(e.modelId)
let s=null
if(null!=i)for(const[n,l]of(0,m.V5)(t))if(null!=l&&l.active){if(null==l.equipmentJewel)return!0
if(s=V.f.Inst().getItemById(l.equipmentJewel.modelId),null!=s){if(s.Quality_get()<i.Quality_get())return!0
if(s.Quality_get()==i.Quality_get()&&e.level>l.equipmentJewel.level)return!0}}return!1}JudgeEquipJewelDataIsNull(t){if(null!=t){const e=t.GetEquipPos()
if(10!=e&&(t.excellAttrCount>=this.equipInlayExcellCountAsk||7==e||8==e)&&null!=t.jewelData&&null!=t.jewelData.positions)return!1}return!0}GetCurSelectJewelData(){
if(null!=this.CurData_get()){const t=this.CurData_get().serverData_get()
if(null!=t.jewelData&&null!=t.jewelData.positions){const e=t.jewelData.positions
let i=null,s=0
const n=e.Count()
for(;s<n;){if(i=e[s],null!=i&&null!=i.equipmentJewel&&this.curSelectJewelIndex==s)return i.equipmentJewel
s+=1}}}return null}JudgeCurSelectJewelIsMax(t){if(null!=t){const e=F.n.Inst().GetItemById(t.modelId)
if(null!=e)return 0==e.nextId}return!0}JudgeCurSelectJewelIsCanSmelt(t){if(null!=t){const e=F.n.Inst().GetItemById(t.modelId)
if(null!=e)return 0!=e.attachCount}return!1}UnNestedRune(){}DecompositionJewel(){}NestedRune(t){}SmeltJewel(t,e){}GetCurEquipSuitCompoundState(t){if(0!=t.initSuitId)return-1
const e=it.Inst_get().GetResByEquip(t)
if(null==e||e.excellenceNum>t.ExcellenceCount_get())return-2
let i=!0,s=null
for(const[t,n]of(0,m.vy)(e.itemConsumeDict)){s=e.itemConsumeDict.LuaDic_GetItem(t)
if(u.g.Inst_get().GetItemNum(t)<s){i=!1
break}}return i?1:0}CheckSuitCompoundState(){let t=!1
const e=C.Y.Inst.PrimaryRoleInfo_get().AllStageEquipments_get()
this.suitCompoundRedDotPos=-1,this.suitCompoundRedDotStage=-1
for(const[i,s]of(0,m.vy)(e)){const s=e[i]
let n=0
for(;n<s.equipmentsGet().Count();){const e=s.equipmentsGet()[n]
if(null!=e&&(null==e.deprecatedTime||e.deprecatedTime.Equal(v.o.ZERO))){1==this.GetCurEquipSuitCompoundState(e)&&(-1==this.suitCompoundRedDotStage&&(this.suitCompoundRedDotStage=i,
this.suitCompoundRedDotPos=n),t=!0)}n+=1}}return q.f.Inst.SetState(H.t.FORGE_SUIT,t),a.i.Inst.RaiseEvent(_.g.SUIT_COMPOUND_CONDITION_UPDATE,!1),t}CheckEquipAwakeState(){let t=!1
const e=C.Y.Inst.PrimaryRoleInfo_get().AllStageEquipments_get()
this.awakeRedDotColumn=-1,this.awakeRedDotPos=-1
let i=0
for(const[s,n]of(0,m.vy)(e)){const n=e[s]
let l=0
for(;l<n.equipmentsGet().Count();){const e=n.equipmentsGet()[l]
if(null!=e&&(null==e.deprecatedTime||e.deprecatedTime.Equal(v.o.ZERO))){const n=new T.Z
1==this.GetCurEquipAwakeState(e,n)&&((-1==this.awakeRedDotColumn||n[0]<i)&&(this.awakeRedDotColumn=s,this.awakeRedDotPos=l,i=n[0]),t=!0)}l+=1}}
return q.f.Inst.SetState(H.t.FORGE_AWAKE,t),a.i.Inst.RaiseEvent(_.g.AWAKE_CONDITION_UPDATE,!1),t}GetCurEquipAwakeState(t,e){return-5}GetAwakeExcellenceAttrByAwakeLevel(t,e){
const i=new T.Z
if(t.ExcellenceCount_get()>0){let e=!1
for(const[s,n]of(0,m.V5)(t.exellectAttrs.attributeDatas)){let s=0
for(const[e,i]of(0,m.V5)(t.exellectAttrs.attributes))if(n.type==i.attributeType){s=i.level
break}const a=n
let o=""
2004==a.type?o="":2005==a.type?o="1/":2006==a.type&&(o=(0,l.T)("等级/"))
const r=new P.G
r.isStar=b.I.IsEquipAttrStar(t.GetEquipRes(),a.type),r.job=t.GetItemRes().job,r.attrType_set(O.U.GetAttrNameByType(a.type)),r.isStar&&(e=!0),
2004!=a.type&&2005!=a.type&&2006!=a.type?(str="[FFFFFF",str+=`${(0,l.T)("]卓越（")}${I.l.getAttrStrWithoutSign(a.type)} +${I.l.getAttrValueStr(a.type,a.value,!a.isPercentage)}）[-]`,
r.str=str,i.Add(r)):(str="[FFFFFF",str+=`${(0,l.T)("]卓越（")}${I.l.getAttrStrWithoutSign(a.type)} +${o}${I.l.getAttrValueStr(a.type,a.value,!a.isPercentage)}）[-]`,r.str=str,i.Add(r))
}if(i.Count()>0){let t=0
for(;t<i.Count();){i[t].hasAnyStar=e,t+=1}i.Sort(this._degf_SortExcellenceAttr)}}return i}SortExcellenceAttr(t,e){const i=t,s=e
return i.isShowStarCnt!=s.isShowStarCnt?1==i.isShowStarCnt&&0==s.isShowStarCnt?-1:1:i.isStar!=s.isStar?1==i.isStar&&0==s.isStar?-1:1:i.priority!=s.priority?i.priority<s.priority?-1:1:0
}GetFinalAwakePoint(){return D.GF.INT(0)}CheckIsShowSuccessView(){}GetMaxEhanceLevelByLocationAndStage(t,e,i,s){return X.C.Inst().GetEnhanceStageLimitByLocationAndStage(t,e,i,s)}
GetCloseCanAddStage(t,e){const i=j.O.Inst().GetADDLimitTableByAddType(t)
let s=0,n=[0,1]
for(const[t,l]of(0,m.X)(i))t!=j.O.ADDMAXKEY&&t>e&&(t-e<s||0==s)&&(s=t-e,n=[t,i[t]])
return n}CheckAllRoleEquipEhanceBySoulLvAndEnhanceLv(t,e){const i=C.Y.Inst.primaryRoleInfoList
for(const[s,n]of(0,m.V5)(i)){const i=n.GetEquipmentsByColumn(),s=i.equipmentsGet()
if(null!=i&&null!=s){const i=s.Count()
for(let n=0;n<=i-1;n++)if(null!=s[n]){const i=s[n],l=i.EnhanceSoulLevel_get(),a=i.Enhancelevel_get()
if(l>t||l==t&&a>=e)return!0}}}return!1}GetForgeRoleInfo(){return p.i.Inst.GetCurSelect(y.I.ForgePanel)}GetAddEquipWearPosList(){if(null==this.m_masterPartPos){const t=new T.Z
let e={}
const i=j.O.Inst().EquipmentAddMap
for(const[s,n]of(0,m.V5)(i))null==e[n.attrGroup]&&(e[n.attrGroup]=!0,t.Add(n.attrGroup))
e=null,t.Sort(this.CreateDelegate(this.SortWearPos)),this.m_masterPartPos=t}return this.m_masterPartPos}SortWearPos(t,e){return t>e?1:-1}SetOldRate(t,e){if(null!=t.enhanceLevel){
const i=X.C.Inst().getResByLevel(e,t.EnhanceSoulLevel_get(),t.Enhancelevel_get()),s=D.GF.INT(i.succRate/100)
this.oldRate=t.enhanceLevel.enhanceSuccRate/100-s}}}st.inst=null
let nt=s._decorator.ccclass("EnhanceMatetialItem")(tt=class extends((0,n.yk)()){constructor(...t){super(...t),this._baseItemData=null,this.demandCount=0,this.isBind=!1,
this.item=null,this._degf_OnClickItem=null,this._degef_UpdateNum=null}InitView(){}Destroy(){}AddLis(){a.i.Inst.AddEventHandler(_.g.BAG_UPDATE,this.CreateDelegate(this.UpdateNum)),
this.listener.node.on(s.NodeEventType.TOUCH_END,this.CreateDelegate(this.OnClickItem),this,!1)}RemoveLis(){
a.i.Inst.RemoveEventHandler(_.g.BAG_UPDATE,this.CreateDelegate(this.UpdateNum)),this.listener.node.off(s.NodeEventType.TOUCH_END,this.CreateDelegate(this.OnClickItem),this,!1)}
Clear(){this.RemoveLis()}OnClickItem(t,e){d.J.Inst_get().OpenTipView(this._baseItemData)}SetData(t){if(this.UnRegGuide(),this.item=t,this._baseItemData=this.item._baseItemData,
this.demandCount=this.item.demandCount,this.isBind=this.item.isBind,null!=this._baseItemData){
const t=this._baseItemData.serverData_get(),e=this._baseItemData.equipInfo_get(),i=this._baseItemData.cfgEquipData_get(),s=this._baseItemData.cfgData_get()
null==s&&h.c.DebugError((0,l.T)("找不到itemresource modelid = ")+this._baseItemData.modelId_get())
let n=this._baseItemData.Quality_get()
null!=t&&null!=i&&(n=I.l.getEquipQuality(t,e),-1==n&&(n=s.quality)),0==this._baseItemData.modelId_get()?o.g.SetItemIcon(this.icon,"",r.b.eItem,!1):(this._baseItemData.BagItemType_get(),
c.r.Rune,o.g.SetItemIcon(this.icon,s.icon,r.b.eItem,!1))
const a=this._baseItemData.QualityIcon_get()
this.qualityBg.spriteNameSet(a),this.UpdateNum(null),this.RemoveLis(),this.AddLis(),this.RegGuide()}}RegGuide(){null!=this.item&&this.item.guideId}UnRegGuide(){
null!=this.item&&this.item.guideId}CheckGuide(){I.l.CheckBtnClickTrigger(this.item.guideId,this.item.guideParam)}UpdateNum(t){let e=0
if(!this.item)return
this.item.isCurrency||(e=this.item.isCanUseBind?u.g.Inst_get().GetItemNum(this._baseItemData.modelId_get()):u.g.Inst_get().GetNonBindItemNum(this._baseItemData.modelId_get()))
if(e-this.demandCount<0){const t=E.M.DealRichTextOutline(`[de2524]${e}[-]/${this.demandCount}`,2)
this.num.textSet(t),st.Inst().isMaterialEnough=!1,st.Inst().isItemEnough=!1}else{const t=E.M.DealRichTextOutline(`${e}/${this.demandCount}`,2)
this.num.textSet(t),st.Inst().isItemEnough=!0,st.Inst().isCurrencyEnough&&(st.Inst().isMaterialEnough=!0)}}})||tt},81476:(t,e,i)=>{i.d(e,{s:()=>s})
class s{}s.EnhanceTab=0,s.AdditionTab=1,s.FortuneTab=2,s.ExcellentAdditionTab=3,s.EquipPromoteTab=4,s.WingRefineTab=5,s.BaptizeTab=6,s.StarTransferTab=7,s.JewelInlayTab=8,
s.SuitTab=9,s.AwakeTab=10,s.GemTab=11},15271:(t,e,i)=>{i.d(e,{D:()=>m})
var s=i(93984),n=i(98958),l=i(99294),a=i(9986),o=i(93877),r=i(61911),h=i(98885),d=i(85602),u=i(63076),c=i(87923),_=i(18414),I=i(18497)
class m extends r.f{constructor(){super(),this.sureBtn=null,this.cancelBtn=null,this.closeBtn=null,this.contextLabel=null,this.masterName=null,this.enhanceGo=null,this.addGo=null,
this.model=null,this._degf_ClickHandler=null,this.elementGo=null,this._degf_ClickHandler=(t,e)=>this.ClickHandler(t,e)}InitView(){this.sureBtn=new a.W,
this.sureBtn.setId(this.FatherId,this.FatherComponentID,1),this.cancelBtn=new a.W,this.cancelBtn.setId(this.FatherId,this.FatherComponentID,2),this.closeBtn=new a.W,
this.closeBtn.setId(this.FatherId,this.FatherComponentID,3),this.contextLabel=new o.Q,this.contextLabel.setId(this.FatherId,this.FatherComponentID,4),this.masterName=new o.Q,
this.masterName.setId(this.FatherId,this.FatherComponentID,5),this.enhanceGo=new l.z,this.enhanceGo.setId(this.FatherId,this.FatherComponentID,6),this.addGo=new l.z,
this.addGo.setId(this.FatherId,this.FatherComponentID,7),this.elementGo=new l.z,this.elementGo.setId(this.FatherId,this.FatherComponentID,8),this.model=I.z.Inst(),super.InitView()}
OnAddToScene(){if(this.AddOrRemoveLis(),null!=this.model.equipMasterViewData){this.enhanceGo.SetActive(0==this.model.equipMasterViewData.type),
this.addGo.SetActive(1==this.model.equipMasterViewData.type),this.elementGo.SetActive(2==this.model.equipMasterViewData.type)
const t=""
let e=""
const i=this.model.GetSelectRoleInfo(),l=this.model.equipMasterViewData.column,a=this.model.equipMasterViewData.index,o=i.GetEquipmentByColumnAndPos(l,a)
if(null!=o){const a=new u.M(o.modelId,o),r=new d.Z
let _=0
if(null!=a&&null!=a.cfgData_get()){const t=c.l.SetEquipName(a.equipInfo_get(),a.cfgData_get(),o,null,!0,!0,0,!1)
r.Add(t[0])}r.Add(h.M.IntToString(this.model.equipMasterViewData.level))
const I=i.GetEquipmentsByColumn(l)
0==this.model.equipMasterViewData.type?(_=I.masterLevel,r.Add(h.M.IntToString(_+1)),
e=n.V.Inst().getStr(10639,s.h.eLangResource,r)):1==this.model.equipMasterViewData.type?(_=I.addMasterLevel,r.Add(h.M.IntToString(_+1)),
e=n.V.Inst().getStr(10640,s.h.eLangResource,r)):2==this.model.equipMasterViewData.type&&(_=I.elementMasterLevel,r.Add(h.M.IntToString(_+1)),
e=n.V.Inst().getStr2(10981,s.h.eLangResource,t))}this.masterName.textSet(t),this.contextLabel.textSet(e)}}Clear(){this.AddOrRemoveLis(!1)}AddOrRemoveLis(t){null==t&&(t=!0),
t?(this.AddClickEvent(this.sureBtn,this._degf_ClickHandler),this.AddClickEvent(this.cancelBtn,this._degf_ClickHandler),
this.AddClickEvent(this.closeBtn,this._degf_ClickHandler)):(this.RemoveClickEvent(this.sureBtn,this._degf_ClickHandler),
this.RemoveClickEvent(this.cancelBtn,this._degf_ClickHandler),this.RemoveClickEvent(this.closeBtn,this._degf_ClickHandler))}ClickHandler(t,e){
t==this.sureBtn.ComponentId&&_.v.Inst().OpenAdditionMasterPanel(),_.v.Inst().CloseMasterTipPanel()}Destroy(){this.sureBtn=null,this.cancelBtn=null,this.closeBtn=null,
this.contextLabel=null,this.masterName=null,this.enhanceGo=null,this.addGo=null,this.model.equipMasterViewData=null,this.model=null}}},5268:(t,e,i)=>{i.d(e,{H:()=>d})
var s=i(93984),n=i(38836),l=i(62370),a=i(55360),o=i(85602),r=i(38962),h=i(72835)
class d{constructor(){this.suitMap=null,this.suitAttrsMap=null,this.suitMapEx=null,this.firstSuitResMap=null,this.finalSuitResMap=null,this.overallSuitMap=null,
this.coreSuitMap=null,this._degf_SortList=null,this.suitMapEx=new r.X,this.firstSuitResMap=new r.X,this.finalSuitResMap=new r.X,this.overallSuitMap=new r.X,
this.coreSuitMap=new r.X,this._degf_SortList=(t,e)=>this.SortList(t,e)
const t=a.Y.Inst.GetOrCreateCsv(s.h.eSuitResource)
this.suitMap=t.GetCsvMap()
const e=a.Y.Inst.GetOrCreateCsv(s.h.eSuitAttrsResource)
this.suitAttrsMap=e.GetCsvMap(),this.InitMap()}static Inst(){return null==d._inst&&(d._inst=new d),d._inst}getSuitById(t){
return this.suitMap.LuaDic_ContainsKey(t)?this.suitMap[t]:null}getSuitAttrsById(t){return this.suitAttrsMap[t]}getSuitAttrsBySuitId(t){const e=new o.Z
for(const[i,s]of(0,n.V5)(this.suitAttrsMap))s.suitId==t&&e.Add(s)
return e.Sort(this._degf_SortList),e}GetMaxAttrNum(t){const e=this.getSuitAttrsBySuitId(t)
return e.Count()>0?e[e.Count()-1].suitNum:0}SortList(t,e){return t.suitNum!=e.suitNum?t.suitNum>e.suitNum?1:-1:0}getSuitConfig(t,e,i){for(const[s,l]of(0,
n.V5)(this.suitMap))if(l.suitLevel==i&&l.suitProperty==e&&l.suitType==t)return l
return null}getSuitRes(t,e,i){let s=null
0==e&&(e=1)
for(const[l,a]of(0,n.V5)(this.suitMap))if(a.job==t&&a.suitLevel==e&&a.suitProperty==i){s=a
break}return s}InitMap(){for(const[t,e]of(0,n.V5)(this.suitMap)){const t=e.job+(l.o.s_UNDER_CHAR+(e.suitType+(l.o.s_UNDER_CHAR+e.suitProperty)))
let i=null
i=this.suitMapEx[t],null==i&&(i=new o.Z,this.suitMapEx.LuaDic_AddOrSetItem(t,i)),i.Add(e)}for(const[t,e]of(0,n.vy)(this.suitMapEx)){const e=this.suitMapEx[t]
let i=null,s=null,n=0
for(;n<e.Count();){if((null==i||i.suitLevel>e[n].suitLevel)&&(i=e[n]),(null==s||s.suitLevel<e[n].suitLevel)&&(s=e[n]),e[n].overAll>0){const t=e[n].job
let i=null
i=this.overallSuitMap.LuaDic_ContainsKey(t)?this.overallSuitMap[t]:new o.Z,i.Add(e[n]),this.overallSuitMap.LuaDic_AddOrSetItem(t,i)}if(e[n].isMultiNormalSuit){let t=1
for(;t<=e[n].normalSuitTable.length;)this.coreSuitMap.LuaDic_AddOrSetItem(e[n].normalSuitTable[t],e[n]),t+=1}n+=1}this.firstSuitResMap.LuaDic_AddOrSetItem(t,i),
this.finalSuitResMap.LuaDic_AddOrSetItem(t,s)}for(const[t,e]of(0,n.vy)(this.overallSuitMap)){this.overallSuitMap[t].Sort(((t,e)=>t.overAll>e.overAll?-1:t.overAll<e.overAll?1:0))}}
getFirstSuitRes(t,e,i){let s=null
const n=t+(l.o.s_UNDER_CHAR+(e+(l.o.s_UNDER_CHAR+i)))
return s=this.firstSuitResMap.LuaDic_GetItem(n),s}getFinalSuitRes(t,e,i){let s=null
const n=t+(l.o.s_UNDER_CHAR+(e+(l.o.s_UNDER_CHAR+i)))
return s=this.finalSuitResMap.LuaDic_GetItem(n),s}GetCoreSuitRes(t){return this.coreSuitMap.LuaDic_ContainsKey(t)?this.coreSuitMap[t]:null}GetOverallSuitList(t,e){
if(this.overallSuitMap.LuaDic_ContainsKey(t)){const i=new o.Z,s=this.overallSuitMap[t]
for(const[t,l]of(0,n.V5)(s)){const t=l
t.suitLevel!=e||t.isMultiNormalSuit||i.Add(t)}return i}const i=h.V.Inst_get().GetJobNode(t)
return null!=i&&null!=i.parent?(t=i.parent.Id,this.GetOverallSuitList(t,e)):null}}d._inst=null},93137:(t,e,i)=>{i.d(e,{w:()=>s})
class s{constructor(){this.suitConfig=null,this.config=null,this.attrs=null,this.suitCount=0,this.changeSuitStr="",this.isScaredSuit=!1}}},53872:(t,e,i)=>{i.d(e,{e:()=>s})
class s{constructor(){this.config=null,this.part=0,this.level=0,this.isTakeOnEquip=!1,this.isCanChangeSuit=!1,this.isChangeSuit=!1,this.limitLevel=0,this.column=-1,this.stageId=-1}
}},29714:(t,e,i)=>{i.d(e,{C:()=>z})
var s=i(93984),n=i(38836),l=i(86133),a=i(98800),o=i(97461),r=i(98958),h=i(62370),d=i(95721),u=i(98885),c=i(85602),_=i(38962),I=i(79534),m=i(1240),g=i(70850),p=i(63076),C=i(59686),S=i(75321),f=i(92679),y=i(87923),v=i(48481),D=i(5268),E=i(18815),T=0,A=1,L=2,w=3,R=4,O=5,G=6,b=7,M=i(53872),P=i(2596),B=i(16812),x=i(5924),N=i(55360),k=i(98130),V=i(15033),F=i(45538),U=i(59918),H=i(75439),q=i(68561)
class Z{}Z.TYPE_EXCELLENT_ADDITION=1,Z.TYPE_EQUIP_AWAKE=2,Z.TYPE_EQUIP_RELIVE=3,Z.TYPE_EQUIP_MASTER=4,Z.TYPE_EQUIP_SUIT=5
class j{constructor(){this.keyTree=null,this.m_key=null,this.lowestRateDic=null,this.m_key=new c.Z}static Inst_get(){return null==j._inst&&(j._inst=new j),j._inst}
GetLowestRateByType(t){if(null==this.lowestRateDic){this.lowestRateDic=new _.X
const t=H.D.getInstance().getContent("EQUIP:LEAST_RATE").getContent().stringVal,e=u.M.Split(t,u.M.s_CCD_CHAR)
for(let t=0;t<=e.count-1;t++){const i=u.M.Split(e[t],h.o.s_UNDER_CHAR),s=u.M.String2Int(i[0]),n=u.M.String2Int(i[1])
this.lowestRateDic.LuaDic_Add(s,n)}}return this.lowestRateDic[t]}getItemSuccRateByTypeAndEquipmentEx(t,e,i){if(null==e)return 0
if(e.IsAngelEquip())return 0
if(t==Z.TYPE_EXCELLENT_ADDITION&&e.GetEquipRes().equipType==U.R.WINGS)return 0
let s=q.X.Inst_get().GetEquipExcellenceCount(e,e.GetEquipInfo())
return(e.suitId>0||e.IsMasterEquip())&&s<2&&(s=2),this.m_key.Clear(),this.m_key.Add(t),this.m_key.Add(e.GetItemRes().equipStepLv),this.m_key.Add(s),1e-4}GetEquipAddPercent(t,e,i){
const s=this.GetLowestRateByType(t),n=i*this.getItemSuccRateByTypeAndEquipmentEx(t,e)
return 0!=n&&n<s?s:n}}j._inst=null
class X extends B.k{static Inst_get(){return null==X.inst&&(X.inst=new X),X.inst}checkCanAddSuccByEquipmentEx(t){
return null!=t&&(!(t.suitId>0&&t.GetItemRes().equipStepLv>=4)&&(!(t.Enhancelevel_get()>0)&&!(t.EquipmentAdd_get()>0)))}ResetModel(){}}X.inst=null
var Y=i(32942)
class W{constructor(t){this.costTable=null,this.costKeys=null,this.judgeItemId=0,this.cfg=null,this.consumeReqList=null,this.suitList=null,this.itemModelList=null,this.cfg=t,
this.suitList=new c.Z,this.itemModelList=new c.Z
let e=y.l.AnalyseArrayStr(this.cfg.suitIds)
if(null!=e)for(const[t,i]of(0,n.V5)(e)){const t=u.M.String2Int(i)
this.suitList.Add(t)}e=u.M.Split(this.cfg.icon,u.M.s_SPAN_CHAR_DOT)
for(const[t,i]of(0,n.V5)(e)){const t=u.M.String2Int(i)
this.itemModelList.Add(t)}}GetPercentTxt(){return`${(0,l.T)("成功率：")}${this.cfg.succRate/100}%`}CheckPartEnough(t){
return!(this.cfg.show||!t.EqualPosAndColumn(this.cfg.positionType,this.cfg.equipColumn))}IsCheckEnough(t){
return!(t.suitType>0&&this.cfg.type!=t.suitType)&&!(this.cfg.needQuality!=t.suitQuality||!t.EqualPosAndColumn(this.cfg.positionType,this.cfg.equipColumn))}HasBuilded(t){
return this.cfg.type==t.suitType&&this.cfg.quality<=t.suitQuality}IsTrueCheck(t){
return null!=t&&!(this.cfg.quality!=t.suitQuality||!t.EqualPosAndColumn(this.cfg.positionType,this.cfg.equipColumn)||this.cfg.type!=t.suitType)}IsPartTrueCheck(t){
return null!=t&&!(this.cfg.quality!=t.suitQuality||!t.EqualPartAndColumn(this.cfg.positionType,this.cfg.equipColumn)||this.cfg.type!=t.suitType)}IsHasRedPoint(t){
return!(this.cfg.show||!this.IsCheckEnough(t)||!this.IsCostEnough())}IsCostEnough(){this.InitCostTable(),this.judgeItemId=0
for(const[t,e]of(0,n.vy)(this.costTable)){if(z.Inst_get().GetItemNum(t)<this.costTable[t])return this.judgeItemId=t,!1}return!0}GetTypeName(){let t=(0,l.T)("普通套装")
return 2==this.cfg.quality?t=(0,l.T)("精致套装"):3==this.cfg.quality?t=(0,l.T)("完美套装"):4==this.cfg.quality&&(t=(0,l.T)("传世套装")),t}GetCostItem(){let t=0
const e=new c.Z
for(this.InitCostTable();t<this.costKeys.count;){const i=this.costKeys[t],s=new p.M(i,null)
s.needNum=this.costTable[i],s.isSuitBag=!0,e.Add(s),t+=1}return e}InitCostTable(){if(null==this.costTable){this.costTable={}
const t=this.GetStringArr(this.cfg.itemConsumes)
let e=0
for(this.costKeys=new c.Z;e<t.count;){const i=u.M.Split(t[e],h.o.s_Arr_UNDER_COLON),s=u.M.String2Int(i[0]),n=u.M.String2Int(i[1])
this.costTable[s]=n,this.costKeys.Add(s),e+=1}}}GetStringArr(t){t=u.M.SubStringWithLen(t,1,u.M.Length(t)-1),t=u.M.SubStringWithLen(t,0,u.M.Length(t)-1)
const e=u.M.Split(t,h.o.s_Arr_UNDER_CHAR_DOU)
let i=0
for(;i<e.count;)e[i]=u.M.Replace(e[i],u.M.s_StringChar,h.o.s_BLANK_CHAR),i+=1
return e}GetConsumeList(){return this.consumeReqList,this.consumeReqList}GetMaterialItems(t){return J.Inst_get().GetMaterialItems(t,this)}GetColorName(){let t=this.cfg.quality
return t>1&&(t+=1),y.l.SetStringColorByQuality(t,this.cfg.name)}GetCanActiveSuitName(){const t=new c.Z,e=y.l.AnalyseArrayStr(this.cfg.suitIds)
if(null!=e){let i=0
for(;i<e.count;){const s=u.M.String2Int(e[i]),n=D.H.Inst().getSuitById(s)
n.isJobEnough()&&t.AddRange(n.GetNameList()),i+=1}}return t}GetNeedConfigSuitId(){const t=J.Inst_get().GetNeedConfig()
if(null!=t){const e=t.GetSuitIds()
if(e.count>0)return e[0]}return 0}GetNeedCorSuitIds(){const t=J.Inst_get().GetNeedConfig()
if(null!=t){const e=t.GetCorSuitIds()
if(null!=e)return e}return null}GetSuitIds(){const t=new c.Z,e=y.l.AnalyseArrayStr(this.cfg.suitIds)
if(null!=e){let i=0
for(;i<e.count;){const s=u.M.String2Int(e[i])
D.H.Inst().getSuitById(s).isJobEnough()&&t.Add(s),i+=1}}return t}GetCorSuitIds(){let t=null
const e=y.l.AnalyseArrayStr(this.cfg.suitIds)
if(null!=e){let i=0
for(;i<e.count;){const s=u.M.String2Int(e[i])
if(D.H.Inst().getSuitById(s).isJobEnough()){const e=D.H.Inst().getSuitById(s)
if(e.isMultiNormalSuit){null==t&&(t=new c.Z)
for(const[i,s]of(0,n.O6)(e.normalSuitTable))t.Add(s)}}i+=1}}return t}}class ${constructor(){this.isShowRedPoint=!1,this.config=null,this.isBuilded=!1}}class J extends B.k{
constructor(){super(!1,0),this.configMap=null,this.coreDict=null,this.nowConfigPerValue=0,this.nowTreeRedPointId=null,this.nowGridRedPointInex=-1,this.CheckRedPointTimerId=0,
this.hasShowDic=null,this.suitMatchMap=null,this.checkEquipEx=null,this._degf_CheckRedPoint=null,this._degf_sortCompare=null,this.hasShowDic=new _.X,this.suitMatchMap=new _.X,
this.InitData(),this._degf_CheckRedPoint=()=>this.CheckRedPoint(),this._degf_sortCompare=(t,e)=>this.sortCompare(t,e)}static Inst_get(){return null==J.inst&&(J.inst=new J),J.inst}
CheckSuitRedPoint(){0==this.CheckRedPointTimerId&&(this.CheckRedPointTimerId=x.C.Inst_get().SetInterval(this._degf_CheckRedPoint,300,1))}CheckRedPoint(){
x.C.Inst_get().ClearInterval(this.CheckRedPointTimerId),this.CheckRedPointTimerId=0
let t=!1
const e=a.Y.Inst.PrimaryRoleInfo_get().AllStageEquipments_get()
if(null!=e){if(!e.LuaDic_ContainsKey(4))return!1
const i=z.Inst_get()
for(const[s,l]of(0,n.vy)(e))if(s>=i.GetUnlockSuitColumn()){const i=e[s]
let n=0
const l=i.equipmentsGet().Count()
for(;n<l;){const e=i.equipmentsGet()[n]
null!=e&&(e.checkPosition=n,!t&&this.CheckOneEquipRedPoint(e,s,n)&&(t=!0)),n+=1}}}}InitData(){const t=new _.X,e=N.Y.Inst.GetOrCreateCsv(s.h.eSuitActivieResource2).GetCsvMap()
let i=null
for(const[s,l]of(0,n.vy)(e))i=new W(e[s]),t.LuaDic_AddOrSetItem(s,i)
this.configMap=t,this.coreDict=new _.X}GetLowQualityItemConsumes(t,e,i,s,l){const a={}
if(0==l.cfg.needQuality){const t=l.GetStringArr(l.cfg.itemConsumes)
if(null!=t)for(const[e,i]of(0,n.V5)(t)){const t=u.M.Split(i,h.o.s_Arr_UNDER_COLON),e=u.M.String2Int(t[0]),s=u.M.String2Int(t[1])
null==a[e]?a[e]=s:a[e]=a[e]+s}
}else for(const[l,o]of(0,n.V5)(this.configMap))if(null!=o.cfg&&o.cfg.type==t&&o.cfg.quality<=e&&F._.GetPosNumByStr(o.cfg.positionType)==i&&o.cfg.equipColumn==s){
const t=o.GetStringArr(o.cfg.itemConsumes)
if(null!=t)for(const[e,i]of(0,n.V5)(t)){const t=u.M.Split(i,h.o.s_Arr_UNDER_COLON),e=u.M.String2Int(t[0]),s=u.M.String2Int(t[1])
null==a[e]?a[e]=s:a[e]=a[e]+s}}return a}GetGridListData(t){const e=new c.Z
let i=0
for(const[s,l]of(0,n.V5)(this.configMap))if(l.CheckPartEnough(t)){const s=new $
s.config=l,l.IsHasRedPoint(t)?s.isShowRedPoint=!0:l.HasBuilded(t)&&(s.isBuilded=!0),e.Add(s),i+=1}this.nowGridRedPointInex=-1,this.checkEquipEx=t,e.Sort(this._degf_sortCompare),i=0
const s=e.count
for(;i<s;){if(e[i].isShowRedPoint&&-1==this.nowGridRedPointInex){this.nowGridRedPointInex=i
break}i+=1}return e}sortCompare(t,e){const i=t,s=e
return i.config.cfg.sort<s.config.cfg.sort?-1:i.config.cfg.sort>s.config.cfg.sort?1:0}GetTreeListData(t){const e={},i=new c.Z
let s=null
this.nowTreeRedPointId=null
let l=0
for(const[a,o]of(0,n.V5)(this.configMap))if(o.CheckPartEnough(t)){null==e[o.cfg.quality]&&(s=new P.y(0,`${o.cfg.id}s`,"0",o.GetTypeName(),o,0),i.Add(s),e[o.cfg.quality]=s)
const n=e[o.cfg.quality].id
s=new P.y(0,`${o.cfg.id}d`,n,o.GetColorName(),o,0),i.Add(s),o.IsHasRedPoint(t)&&(s.tempShowRedPoint=!0,null==this.nowTreeRedPointId&&(this.nowTreeRedPointId=s.id),
e[o.cfg.quality].tempShowRedPoint=!0),l+=1}return this.checkEquipEx=t,i}GetNeedConfig(t){const e=t.cfg
for(const[t,i]of(0,n.V5)(this.configMap)){const t=i.cfg
if(t.type==e.type&&t.quality==e.needQuality&&t.positionType==e.positionType&&t.equipColumn==e.equipColumn)return i}return null}CheckOneEquipRedPoint(t,e,i){
if(!z.Inst_get().GetFinalEquipSuitUnlockState(t,e,i))return!1
for(const[e,i]of(0,n.V5)(this.configMap))if(i.IsHasRedPoint(t))return!0
return!1}GetNowTrueConfig(t){if(null==t)return null
for(const[e,i]of(0,n.V5)(this.configMap))if(i.IsTrueCheck(t))return i
return null}GetNowPartTrueConfig(t){if(null==t)return null
for(const[e,i]of(0,n.V5)(this.configMap))if(i.IsPartTrueCheck(t))return i
return null}GetConfigList(t,e){if(this.suitMatchMap.LuaDic_ContainsKey(t))return this.suitMatchMap[t]
const i=new c.Z,s=new _.X
for(const[l,a]of(0,n.V5)(this.configMap))if(a.cfg.equipColumn==e){a.suitList
for(const[e,l]of(0,n.V5)(a.suitList))if(l==t){if(i.Add(a),!this.coreDict.LuaDic_ContainsKey(t)){const e=D.H.Inst().GetCoreSuitRes(t)
null!=e?this.coreDict.LuaDic_AddOrSetItem(t,e):this.coreDict.LuaDic_AddOrSetItem(t,null)}s.LuaDic_AddOrSetItem(t,!0)
break}}for(const[t,l]of(0,n.vy)(s))if(1==s[t]){const s=this.coreDict[t]
if(null!=s){const t=this.GetOneConfig(s.id,e)
null!=t&&i.Add(t)}}return this.suitMatchMap.LuaDic_AddOrSetItem(t,i),i}GetOneConfig(t,e){for(const[i,s]of(0,n.V5)(this.configMap))if(s.cfg.equipColumn==e){s.suitList
for(const[e,i]of(0,n.V5)(s.suitList))if(i==t)return s}return null}GetMaterialItems(t,e){return new c.Z}GetAccessData(){}couldAdd(t,e,i){if(t.BagItemType_get()!=V.r.Equip)return 0
const s=t.serverData_get(),n=e.GetItemRes().job,l=t.cfgData_get().job
if(0!=n){if(k.GF.INT(n/1e3)!=k.GF.INT(l/1e3))return 0}else{const t=a.Y.Inst.PrimaryRoleInfo_get().Job_get()
if(k.GF.INT(t/1e3)!=k.GF.INT(l/1e3))return 0}if(y.l.IsLimitTimeItem(t))return 0
if(s.IsAngelEquip())return 0
if(!X.Inst_get().checkCanAddSuccByEquipmentEx(s))return 0
const o=(1e4-i.cfg.succRate)/(i.cfg.consumeReq/1e4)
return j.Inst_get().GetEquipAddPercent(Z.TYPE_EQUIP_SUIT,s,o)}getItemPercent(t,e){
const i=t.equipInfo_get().Config_get().equipColumnsList_get()[0],s=t.serverData_get(),l=q.X.Inst_get().GetEquipStarLevel(s,t.equipInfo_get()),a=q.X.Inst_get().GetEquipExcellenceCount(s,t.equipInfo_get()),o=t.equipInfo_get().Config_get().type
for(const[t,s]of(0,n.V5)(e))if(s.stage==i&&a==s.excell&&o==s.godType){if(-1==s.star)return s.percent
if(s.star==l)return s.percent}return 0}GetTotalPercent(){return this.nowConfigPerValue/100+this.GetMaterialPercent()}GetMaterialPercent(){let t=0
for(const[e,i]of(0,n.V5)(this.hasShowDic)){t+=i-i%1e-4}return t/100}GetMatIds(){const t=new c.Z
for(const[e,i]of(0,n.vy)(this.hasShowDic)){const i=d.o.FromNumber(e)
t.Add(i)}return t}parsePosStr(t){
return"GLOVES"==t?Y.G.GLOVES:"BOOTS"==t?Y.G.BOOTS:"RIGHTRING"==t?Y.G.RIGHTRING:"SUBWEAPON"==t?Y.G.SUBWEAPON:"HAT"==t?Y.G.HAT:"LEFTRING"==t?Y.G.LEFTRING:"PANTS"==t?Y.G.PANTS:"WEAPON"==t?Y.G.MAINWEAPON:"NECKLACE"==t?Y.G.NECKLACE:"CLOTHES"==t?Y.G.CLOTHES:-1
}ResetModel(){}}J.UPDATE_SUITBUILD_FOR_SERVER="UPDATE_SUITBUILD_FOR_SERVER",J.UPDATE_SUITBUILD_REDPOINT="UPDATE_SUITBUILD_REDPOINT",J.inst=null,J.MAX_BUILD_QUALITY=4
class z{constructor(){this.enhanceStr=null,this.suitStr=null,this.masterSuitStr=null,this.helmetStr=null,this.clothesStr=null,this.armguardStr=null,this.shoesStr=null,
this.pantsStr=null,this.necklaceStr=null,this.ringStr=null,this.materialDic=null,this.tipPps=null,this.tipSuitLevel=4,this.SuitChildViewType=E.p.Base,this.isChange=!1,
this.curData=null,this.curSuitData=null,this.selectEquipColumn=1,this.selectEquipPos=0,this.overallEquipColumn=1,this.strengthenListSuitPos=-1,this.overallSuitId=0,
this.nowSuitSplitEquipEx=null,this.showStrengthenListSuit=!1,this._degf_ChangeSuitSortFunc=null,this._degf_SortEnhanceJewelySuitList=null,this._degf_SortNormalJewelySuitList=null,
this.bagData=null,this._bagSize=0,this._maxBagSize=0,this._emptySize=0,this.itemNumTab={},this.isAutoRecycle=!1,this.isSelectNum=!1,this.curRecycleQuality=0,
this.recycleMenuData=null,this.recycleMinQuality=0,this.recycleIdTab={},this.recycleNumTab={},this.accessId=0,this.unlockSuitColumn=0,this.curRedPointTreeNode=null,
this.isNotAutoRecycleTab={},this.enhanceStr=r.V.Inst().getStr(10188,s.h.eLangResource),this.suitStr=r.V.Inst().getStr(10189,s.h.eLangResource),
this.masterSuitStr=r.V.Inst().getStr(10970,s.h.eLangResource),this.helmetStr=r.V.Inst().getStr(10190,s.h.eLangResource),this.clothesStr=r.V.Inst().getStr(10191,s.h.eLangResource),
this.armguardStr=r.V.Inst().getStr(10192,s.h.eLangResource),this.shoesStr=r.V.Inst().getStr(10193,s.h.eLangResource),this.pantsStr=r.V.Inst().getStr(10194,s.h.eLangResource),
this.necklaceStr=r.V.Inst().getStr(10195,s.h.eLangResource),this.ringStr=r.V.Inst().getStr(10196,s.h.eLangResource),this.materialDic=new _.X,this.tipPps=I.P.zero_get(),
this._degf_ChangeSuitSortFunc=(t,e)=>this.ChangeSuitSortFunc(t,e),this._degf_SortEnhanceJewelySuitList=(t,e)=>this.SortEnhanceJewelySuitList(t,e),
this._degf_SortNormalJewelySuitList=(t,e)=>this.SortNormalJewelySuitList(t,e),this.AddLis(),this.InitMenuData()}static Inst_get(){return null==z._Inst&&(z._Inst=new z),z._Inst}
InitMenuData(){}IsCanAutoSelect(t){return!0}RecycleMenuItemClick(t){}RecycleIdTab_Set(t,e,i,s){if(e.Equal(d.o.ZERO))return
const n=null!=this.recycleIdTab[t]
null==s&&(s=!0),s?n?this.recycleNumTab[t]=this.recycleNumTab[t]+i:(this.recycleIdTab[t]=e,this.recycleNumTab[t]=i):n&&(this.recycleIdTab[t]=null,this.recycleNumTab[t]=null),
o.i.Inst.RaiseEvent(f.g.SUIT_RECYCLE_SELECTUPDATE)}RecycleIdTab_Clear(){this.recycleIdTab={},this.recycleNumTab={},o.i.Inst.RaiseEvent(f.g.SUIT_RECYCLE_SELECTUPDATE)}
GetCurRecycleScore(){let t=0
if(null!=this.recycleIdTab)for(const[e,i]of(0,n.X)(this.recycleIdTab))if(null!=this.bagData[e]&&null!=this.bagData[e].serverData_get()&&null!=this.bagData[e].baseData_get()&&null!=this.bagData[e].baseData_get().cfgData_get()){
const i=this.bagData[e].baseData_get().cfgData_get()
if(null!=i.Rewards_get()&&null!=i.Rewards_get().typevalues)for(const[s,l]of(0,n.V5)(i.Rewards_get().typevalues))if(null!=l){const i=u.M.Split(l.value,":")
if(null!=i&&i.Count()>1){t+=u.M.String2Int(i[1])*this.recycleNumTab[e]
break}}}return t}GetRecycleDataList(){const t=new c.Z
let e=null
if(null!=this.bagData)for(const[i,s]of(0,n.X)(this.bagData))if(null!=s&&null!=s.serverData_get()&&this.IsCanAutoSelect(s.serverData_get().modelId)){let i=s.serverData_get().num
null!=this.recycleNumTab[s.index_get()]&&(i-=this.recycleNumTab[s.index_get()]),i>0&&(e=new m.Y,e.Clone(s),e.baseData_get().isForBag=!1,e.baseData_get().isCanOperate=!1,
e.baseData_get().count=i,e.baseData_get().tipPosType=C.l.SuitRecycleRight,t.Add(e))}return t}GetRecycleDataSelectList(){const t=new c.Z
let e={},i=null
if(null!=this.bagData)for(const[s,l]of(0,n.X)(this.bagData))if(null!=l&&null!=l.serverData_get()&&this.IsCanAutoSelect(l.serverData_get().modelId)){let s=0
if(null!=this.recycleNumTab[l.index_get()]&&(s=this.recycleNumTab[l.index_get()]),s>0){const n=l.serverData_get().modelId
null!=e[n]?(i=e[n],i.baseData_get().count=i.baseData_get().count+s,i.numTable[l.index_get()]=s):(i=new SuitRecycleSelectData,i.Clone(l),i.baseData_get().isForBag=!1,
i.baseData_get().isCanOperate=!1,i.baseData_get().count=s,i.baseData_get().tipPosType=C.l.SuitRecycleLeft,i.numTable[l.index_get()]=s,e[n]=i,t.Add(i))}}return e=null,t}
GetSelectRecycleIds(){const t=new c.Z
if(null!=this.recycleIdTab)for(const[e,i]of(0,n.X)(this.recycleIdTab))t.Add(i)
return t}GetSelectRecycleNums(){const t=new c.Z
if(null!=this.recycleNumTab)for(const[e,i]of(0,n.X)(this.recycleNumTab))t.Add(i)
return t}bagSize_get(){return this._bagSize}maxBagSize_get(){return this._maxBagSize}emptySize_get(){return this._emptySize}UpdateItemNum(t,e,i){
i?null==this.itemNumTab[t]?this.itemNumTab[t]=e:this.itemNumTab[t]=this.itemNumTab[t]+e:null!=this.itemNumTab[t]&&(this.itemNumTab[t]=this.itemNumTab[t]-e,
this.itemNumTab[t]<=0&&(this.itemNumTab[t]=null))}GetItemNum(t){return null!=this.itemNumTab[t]?this.itemNumTab[t]:0}StartAutoRecycle(){if(this.isAutoRecycle&&null!=this.bagData){
const t=new c.Z
for(const[e,i]of(0,n.X)(this.bagData))if(null!=i&&null!=i.serverData_get()&&null!=i.baseData_get()&&null!=i.baseData_get().cfgData_get()&&this.IsCanAutoSelect(i.serverData_get().modelId)){
i.baseData_get().Quality_get()<=this.curRecycleQuality&&t.Add(i.serverData_get().id)}t.Count()}}getFilterByTab(t){const e=new c.Z
if(null!=this.bagData)for(const[i,s]of(0,n.X)(this.bagData))if(null!=s&&null!=s.serverData_get()&&null!=s.baseData_get()&&null!=s.baseData_get().cfgData_get()){
const i=s.baseData_get().Quality_get();(0==t||i==t)&&e.Add(s)}return e}updateRecycleSetting(t){if(null==t)return
this.isAutoRecycle=t.isFullClear
let e=!1
this.curRecycleQuality!=t.colorQuality&&(e=!0),this.curRecycleQuality=t.colorQuality,0==this.curRecycleQuality&&(this.curRecycleQuality=this.recycleMinQuality),
e&&o.i.Inst.RaiseEvent(f.g.SUIT_RECYCLE_QUALITYUPDATE)}AddLis(){}CurData_get(){return this.curData}CurData_set(t){this.curData=t}CurSuitData_get(){return this.curSuitData}
CurSuitData_set(t){this.curSuitData=t}OverallEquipColumn_get(){return this.overallEquipColumn<this.GetUnlockSuitColumn()&&this.OverallEquipColumn_set(this.GetUnlockSuitColumn()),
this.overallEquipColumn}OverallEquipColumn_set(t){this.overallEquipColumn!=t&&(this.overallEquipColumn=t,
this.overallEquipColumn<this.GetUnlockSuitColumn()&&(this.overallEquipColumn=this.GetUnlockSuitColumn()))}SelectEquipColumn_get(){return this.selectEquipColumn}
SelectEquipColumn_set(t){this.selectEquipColumn!=t&&(this.selectEquipColumn=t,this.isChange=!0)}SelectEquipPos_get(){return this.selectEquipPos}SelectEquipPos_set(t,e){
null==e&&(e=!1),(this.selectEquipPos!=t||e)&&(this.selectEquipPos=t,this.isChange=!0)}GetIconPath(t,e,i){let s=""
if(2==e&&i>=5){s=`wear_${u.M.Split(t,h.o.s_Arr_UNDER_CHAR_DOT)[i-5]}`
}else i==T?s=`wear_${t}_helmet`:i==A?s=`wear_${t}_body`:i==L?s=`wear_${t}_hand`:i==w?s=`wear_${t}_shoes`:i==R&&(s=`wear_${t}_leg`)
return s}GetPartName(t){return t==T?this.helmetStr:t==A?this.clothesStr:t==L?this.armguardStr:t==w?this.shoesStr:t==R?this.pantsStr:t==O?this.necklaceStr:t==G||t==b?this.ringStr:""
}GetEquipSuitName(t){let e=null
const i=D.H.Inst().getSuitById(t.suitId)
let s=(0,l.T)("装备")
return t.suitPosition>=O&&(s=(0,l.T)("首饰")),e=i.suitPrefix+(t.suitLevel+((0,l.T)("阶")+(s+this.suitStr))),e}GetQualityColorStr(t){return""}GetQualityColorStr2(t,e){return e}
GetSuitName(t,e,i,s){null==s&&(s=!0)
let n=null,a=(0,l.T)("装备")
return t.part>=S.C.NECKLACE&&(a=(0,l.T)("首饰")),n=s?t.config.suitPrefix+(a+(this.suitStr+(u.M.s_LEFT_S_K_CHAR+(e+(h.o.s_F_SLASH_ONE+(i+u.M.s_RIGHT_S_K_CHAR)))))):t.config.suitPrefix+(a+this.suitStr),
n}GetSuitNameWithLevel(t,e,i){let s=null,n=`${y.l.getEquiplvStr(t.level)} `
return t.part>=S.C.NECKLACE&&(n=""),n="",s=3!=t.config.suitType?`${n}${t.config.suitPrefix}${t.config.suitName}${this.suitStr} [57ea57]${u.M.s_LEFT_S_K_CHAR}${e}${h.o.s_F_SLASH_ONE}${i}${u.M.s_RIGHT_S_K_CHAR}[-]`:`${n}${t.config.suitName}${this.masterSuitStr} [57ea57]${u.M.s_LEFT_S_K_CHAR}${e}${h.o.s_F_SLASH_ONE}${i}${u.M.s_RIGHT_S_K_CHAR}[-]`,
s}GetSuitActivatedCount(t,e,i,s){if(s[0]=0,e.isTakeOnEquip){const n=e.config.id
s[0]=this.GetCurSuitCount(t,n,i,e.column)}}GetCurSuitCount(t,e,i,s){if(null==t)return 1
if(null==s&&(s=-1),null==i){i=0
const t=D.H.Inst().getSuitAttrsBySuitId(e)
t.Count()>0&&(i=t[t.Count()-1].suitNum)}let l=0
if(-1==s){let s=0
for(const[a,o]of(0,n.vy)(t.AllStageEquipments_get()))s=t.GetSuitActivatedCount(a,e),s>=i&&(s=i),s>l&&(l=s)}else l=t.GetSuitActivatedCount(s,e),l>=i&&(l=i)
return l}IsSuitActivated(t,e,i){null==i&&(i=-1)
let s=0
const l=D.H.Inst().getSuitAttrsBySuitId(e)[0].suitNum
if(-1==i){for(const[i,a]of(0,n.vy)(t.AllStageEquipments_get()))if(s=t.GetSuitActivatedCount(i,e),s>=l)return!0}else if(s=t.GetSuitActivatedCount(i,e),s>=l)return!0
return!1}GetSuitResInWearByColAndPos(t,e,i){const s=t.GetSuitEquipmentByColumnAndPos(e,i)
return null!=s?s.GetSuitRes():null}GetPartNamePrefix(t,e){let i=""
return i=0==t?"":u.M.s_F_SLASH_DOT.toString(),i+=e?"[e3ae5a]":"[b2b2b2]",i}SortNormalJewelySuitList(t,e){let i=0,s=0
const n=a.Y.Inst.PrimaryRoleInfo_get().SuitInfos_get()
return n.LuaDic_ContainsKey(t)&&(i=n[t].suitLevel),n.LuaDic_ContainsKey(e)&&(s=n[e].suitLevel),i!=s&&i>s?1:-1}getEquipStepLv(t){
const e=y.l.getEquipPosBySuitPosition(t.suitPosition),i=a.Y.Inst.PrimaryRoleInfo_get().GetEquipmentsByColumn(this.SelectEquipColumn_get()).equipments
if(null==i[e])return 0
return g.g.Inst_get().getItemresource(i[e].modelId).equipStepLv}isStepOk(t){t.suitLevel
const e=y.l.getEquipPosBySuitPosition(t.suitPosition),i=a.Y.Inst.PrimaryRoleInfo_get().GetEquipmentsByColumn(this.SelectEquipColumn_get()).equipments
if(null==i[e])return!1
const s=g.g.Inst_get().getItemresource(i[e].modelId)
return!(t.suitLevel>=s.equipStepLv)}getNextSuitConfig(t){if(0==t.suitLevel){const e=this.getSuitEquipType(t.suitPosition)
return D.H.Inst().getSuitConfig(e,t.suitProperty,1)}return D.H.Inst().getSuitById(t.suitId+1)}SortEnhanceJewelySuitList(t,e){let i=0,s=0
const n=a.Y.Inst.PrimaryRoleInfo_get().EnhanceSuitInfos_get()
return n.LuaDic_ContainsKey(t)&&(i=n[t].suitLevel),n.LuaDic_ContainsKey(e)&&(s=n[e].suitLevel),i!=s&&i>s?1:-1}CheckMaterialCount(t,e,i){const s=e
if(null==s)return!1
let n=null
t==T?n=s.helmetConsumes:t==A?n=s.clothesConsumes:t==L?n=s.armguardConsumes:t==w?n=s.shoesConsumes:t==R?n=s.pantsConsumes:t==O?n=s.necklaceConsumes:t!=G&&t!=b||(n=s.ringsConsumes)
const l=new c.Z
let a=0
for(;a<n.rewardValues.Count();){const t=n.rewardValues[a]
l.Add(t.baseItem_get()),a+=1}let o=!0,r=null,h=0,d=0
for(;d<l.Count();){if(r=l[d],h=g.g.Inst_get().GetItemNum(r.modelId_get()),h<r.count){o=!1
break}d+=1}return o}wrapData(t){const e=new M.e
e.level=t.suitLevel,e.part=t.suitPosition
const i=D.H.Inst().getSuitById(t.suitId)
return e.config=i,e}getConsumeItems(t){const e=new _.X
for(const[i,s]of(0,n.V5)(t)){const t=this.getConsume(s)
if(null!=t){let i=0
for(;i<t.rewardValues.Count();){const s=t.rewardValues[i],n=s.baseItem_get().modelId_get(),l=s.baseItem_get().count
e.LuaDic_ContainsKey(n)?e[n]=e[n]+l:e.LuaDic_AddOrSetItem(n,l),i+=1}}}const i=new c.Z
for(const[t,s]of(0,n.vy)(e)){const s=new v.t
s.modelId=t,s.num=e[t]
const n=new p.M(t,s)
i.Add(n)}return i}getConsume(t){let e=null
const i=D.H.Inst().getSuitById(t.suitId)
return t.suitPosition==T?e=i.helmetConsumes:t.suitPosition==A?e=i.clothesConsumes:t.suitPosition==L?e=i.armguardConsumes:t.suitPosition==w?e=i.shoesConsumes:t.suitPosition==R?e=i.pantsConsumes:t.suitPosition==O?e=i.necklaceConsumes:t.suitPosition!=G&&t.suitPosition!=b||(e=i.ringsConsumes),
e}filterValidEquip(t){const e=new c.Z
for(const[i,s]of(0,n.V5)(t))s.suitLevel<=this.getEquipStepLv(s)&&s.suitLevel>0&&e.Add(s)
return e}filterValidEquip2(t){const e=new c.Z
for(const[i,s]of(0,n.V5)(t))this.isStepOk(s)&&e.Add(s)
return e}getSuits(t,e,i){const s=a.Y.Inst.PrimaryRoleInfo_get(),l=new c.Z
let o=0
if(1==e){const e=s.SuitInfos_get()
for(const[s,a]of(0,n.V5)(e))o=this.getSuitEquipType(a.suitPosition),o==t&&i==a.suitLevel&&l.Add(a)
return l}if(2==e){const e=s.EnhanceSuitInfos_get()
for(const[s,a]of(0,n.V5)(e))o=this.getSuitEquipType(a.suitPosition),o==t&&i==a.suitLevel&&l.Add(a)
return l}return l}checkSuitType(t,e,i){return this.getSuitEquipType(t.suitPosition)==e&&!(i&&!this.hasEquip(t.suitPosition))}getMaxSuitLevel(t,e,i){null==i&&(i=!1)
let s=-1
const l=a.Y.Inst.PrimaryRoleInfo_get()
let o=null
o=1==e?l.SuitInfos_get():l.EnhanceSuitInfos_get()
for(const[e,l]of(0,n.V5)(o))this.checkSuitType(l,t,i)&&s<l.suitLevel&&(s=l.suitLevel)
return-1==s?0:s}getSuitEquipType(t){const e=y.l.getEquipPosBySuitPosition(t),i=y.l.getRoleEquipPosType(e,a.Y.Inst.PrimaryRoleInfo_get().Job_get())
return y.l.EquipIsDefense(i)?1:y.l.EquipIsJewerly(i)?2:void 0}hasEquip(t){const e=y.l.getEquipPosBySuitPosition(t)
return null!=a.Y.Inst.PrimaryRoleInfo_get().GetEquipmentsByColumn(this.SelectEquipColumn_get()).equipments[e]}ChangeSuitSortFunc(t,e){
return!t.isMaxNum&&e.isMaxNum?-1:t.isMaxNum&&!e.isMaxNum?1:t.suitLevel>e.suitLevel?-1:t.suitLevel<e.suitLevel||t.suitId>e.suitId?1:t.suitId<e.suitId?-1:0}
GetSuitPosUnlockState(t,e){return!0}GetEquipSuitUnlockState(t,e,i,s){return this.GetUnlockSuitColumn(),!0}GetFinalEquipSuitUnlockState(t,e,i,s){
return!(null==t||!this.GetSuitPosUnlockState(e,i)||!this.GetEquipSuitUnlockState(t,e,i,s)||!t.IsGodEquip()&&t.GetEquipRes().intPosition_get()!=S.C.RINGS&&t.GetEquipRes().intPosition_get()!=S.C.NECKLACE)
}GetSuitQualityBg(t,e){let i="taozhuang_sp_00"
return 1==t?1==e?i+="06":2==e?i+="09":3==e?i+="12":4==e&&(i+="15"):2==t?1==e?i+="07":2==e?i+="10":3==e?i+="13":4==e&&(i+="16"):3==t&&(1==e?i+="08":2==e?i+="11":3==e?i+="14":4==e&&(i+="17")),
i}GetSuitScoreByColumn(t,e){null==e&&(e=a.Y.Inst.PrimaryRoleInfo_get())
let i=0
const s=e.GetEquipmentsByColumn(t)
if(null!=s&&s.unlockColumn)for(const[t,l]of(0,n.V5)(s.equipments))null!=l&&l.suitId>0&&(i+=this.GetSuitScoreByEquip(l,e))
return i}GetSuitScoreByEquip(t,e){if(0==t.suitId)return 0
null==e&&(e=a.Y.Inst.PrimaryRoleInfo_get())
let i=e.GetEquipment(t)
if(null==i)return 0
i=null
let s=0,n=D.H.Inst().getSuitById(t.suitId)
if(null!=n){if(n.normalSuitTable.length>0){let t=1
for(;t<=n.normalSuitTable.length;)s+=this.CalculateSuitScore(n.normalSuitTable[t],e),t+=1}else if(n.isAngelSuit){let t=0
for(;t<n.angelList.Count();)s+=this.CalculateSuitScore(n.angelList[t],e),t+=1}else s+=this.CalculateSuitScore(t.suitId,e)
const i=J.Inst_get().GetNowPartTrueConfig(t)
null!=i&&(s+=i.cfg.score)}if(t.suitId!=t.initSuitId){if(t.GetEquipRes().suitId==t.initSuitId&&(n=D.H.Inst().getSuitById(t.initSuitId),null!=n))if(n.isAngelSuit){let t=0
for(;t<n.angelList.Count();)s+=this.CalculateSuitScore(n.angelList[t],e),t+=1}else s+=this.CalculateSuitScore(t.initSuitId,e)}return s}GetMasterSuitScoreByEquip(t,e){
if(0==t.masterId)return 0
null==e&&(e=a.Y.Inst.PrimaryRoleInfo_get())
let i=e.GetEquipment(t)
if(null==i)return 0
i=null
let s=0
return null!=D.H.Inst().getSuitById(t.masterId)&&(s+=this.CalculateSuitScore(t.masterId,e)),s}CalculateSuitScore(t,e){if(0==t)return 0
null==e&&(e=a.Y.Inst.PrimaryRoleInfo_get())
let i=0,s=0
const n=D.H.Inst().getSuitAttrsBySuitId(t)
n.Count()>0&&(s=n[n.Count()-1].suitNum)
const l=this.GetCurSuitCount(e,t,s)
let o=0
for(;o<n.Count();){const t=n[o]
l>=t.suitNum&&(i+=t.score),o+=1}return i}GetUnlockSuitColumn(){return this.unlockSuitColumn,this.unlockSuitColumn}GetAccessId(){return this.accessId}ResetModel(){this.bagData=null,
this._bagSize=0,this._maxBagSize=0,this._emptySize=0,this.itemNumTab={},this.isAutoRecycle=!1,this.curRecycleQuality=0,this.recycleMinQuality=0,this.recycleIdTab={},
this.isSelectNum=!1}}z._Inst=null},35950:(t,e,i)=>{i.d(e,{n:()=>s})
var s={eMaster:0,eAngel:1,eNormal:2,eEnhance:3,eSuitEnhance1:4,eSuitEnhance2:5,eSuitEnhance3:6,eSuitEnhance4:7,eSuitEnhance5:8}},18815:(t,e,i)=>{i.d(e,{p:()=>s})
class s{}s.Base=0,s.Enhance=1},60606:(t,e,i)=>{i.d(e,{H:()=>s})
class s{constructor(){this.type=0,this.str=null,this.isPreview=!1,this.isZeroBase=!0,this.isSacredEquip=!0,this.isDesc=!1}}},88309:(t,e,i)=>{i.d(e,{R:()=>n})
var s=i(83908)
class n extends((0,s.yk)()){InitView(){}SetData(t){const e=t
if(e.isDesc)this.attrLabel.node.SetActive(!0),this.attrLabel.textSet(e.str),this.wingattr.SetActive(!1),this.wingattrlabel.node.SetActive(!1),this.up.SetActive(!1),
this.rangeLabel.node.SetActive(!1)
else{const t=e.str
this.up.SetActive(!1),2013==e.type||2012==e.type?(this.attrLabel.node.SetActive(!1),this.wingattr.SetActive(!0),this.wingattrlabel.textSet(t)):(this.attrLabel.node.SetActive(!0),
this.wingattr.SetActive(!1),this.attrLabel.textSet(t)),e.isPreview&&this.up.SetActive(!0),this.rangeLabel.textSet("")}}Clear(){}Destroy(){}}},88431:(t,e,i)=>{i.d(e,{F:()=>l})
var s=i(9057),n=i(93877)
class l extends s.x{constructor(...t){super(...t),this.attrLabel=null}InitView(){super.InitView(),this.attrLabel=new n.Q,
this.attrLabel.setId(this.FatherId,this.FatherComponentID,1)}SetData(t){const e=t
this.attrLabel.textSet(e)}Clear(){}Destroy(){}}},13626:(t,e,i)=>{i.d(e,{n:()=>d})
var s=i(86133),n=i(62370),l=i(9057),a=i(93877),o=i(72005),r=i(98885),h=i(19519)
class d extends l.x{constructor(...t){super(...t),this.title=null,this.icon=null,this.cost=null,this.data=null}InitView(){this.title=new a.Q,
this.title.setId(this.FatherId,this.FatherComponentID,1),this.icon=new o.w,this.icon.setId(this.FatherId,this.FatherComponentID,2),this.cost=new a.Q,
this.cost.setId(this.FatherId,this.FatherComponentID,3)}Destroy(){this.title=null,this.icon=null,this.cost=null}SetData(t){this.data=t
const e=(0,s.T)("[B8ABA2]开启消耗[-]")
this.title.textSet(e)
const i=r.M.Split(this.data.value,n.o.s_Arr_UNDER_COLON),l=h.J.GetCurrencyIconUrl(i[0])
this.icon.spriteNameSet(l)
const a=r.M.Replace("[FFEFE1]{0}[-]","{0}",i[1])
this.cost.textSet(a)}Clear(){this.data=null}}},70087:(t,e,i)=>{i.d(e,{F:()=>d})
var s=i(62370),n=i(98885),l=i(85602),a=i(87923)
class o{constructor(){this.type=null,this.excellenceLevel=null}}var r=i(41850),h=i(5268)
class d{constructor(t,e){if(this.config=null,this.EquipRes=null,this.suitRes=null,this.enhanceLv=0,this.castLv=0,this.equipAddShow=0,this.qualityShow=0,this.luckShow=0,
this.luckShowValue=0,this.ignoreShow=0,this.ignoreShowValue=0,this.starShow=0,this.minStar=0,this.maxStar=0,this.suitId=0,this.isOutOfPrint=!1,this.excellenceData=null,
this.excellenceMinLevel=0,this.excellenceMaxLevel=0,this.randomExcellence=null,this.config=t,this.EquipRes=e,null!=t){this.suitId=t.suitId,
this.suitId>0&&(this.suitRes=h.H.Inst().getSuitById(this.suitId)),0==t.enhanceShow&&(t.enhanceShow=1)
const e=r.C.Inst().getResById(t.enhanceShow)
if(null!=e&&(this.enhanceLv=e.level,this.castLv=e.castNum),this.equipAddShow=t.equipAddShow,this.qualityShow=t.qualityShow,!a.l.IsEmptyStr(t.luckShow)){
const e=n.M.Split(t.luckShow,s.o.s_UNDER_CHAR)
this.luckShow=n.M.String2Int(e[0]),this.luckShowValue=n.M.String2Int(e[1])}if(!a.l.IsEmptyStr(t.ignoreShow)){const e=n.M.Split(t.ignoreShow,s.o.s_UNDER_CHAR)
this.ignoreShow=n.M.String2Int(e[0]),this.ignoreShowValue=n.M.String2Int(e[1])}this.excellenceData=new l.Z,this.randomExcellence=new l.Z
let i=t.sureExcellence
i=n.M.Replace(i,n.M.s_LEFT_M_K_CHAR_REPLACE,s.o.s_BLANK_CHAR),i=n.M.Replace(i,n.M.s_RIGHT_M_K_CHAR_REPLACE,s.o.s_BLANK_CHAR)
let d=n.M.Split(i,n.M.s_SPAN_CHAR_DOT)
if(""!=i){let t=0
for(;t<d.count;){const e=d[t],i=n.M.Split(e,s.o.s_UNDER_COLON),l=new o
l.type=i[0],l.excellenceLevel=i[1],this.excellenceMinLevel=n.M.String2Int(l.excellenceLevel),t+=1}}if(i=t.randomExcellence,
i=n.M.Replace(i,n.M.s_LEFT_M_K_CHAR_REPLACE,s.o.s_BLANK_CHAR),i=n.M.Replace(i,n.M.s_RIGHT_M_K_CHAR_REPLACE,s.o.s_BLANK_CHAR),d=n.M.Split(i,n.M.s_SPAN_CHAR_DOT),d.count>1){
let t=n.M.String2Int(d[0])
this.randomExcellence.Add(t),t=n.M.String2Int(d[1]),t!=this.randomExcellence[0]&&this.randomExcellence.Add(t)}this.starShow=-1,this.minStar=-1,this.maxStar=-1
let u=t.starShow
u=n.M.Replace(u,n.M.s_LEFT_M_K_CHAR_REPLACE,s.o.s_BLANK_CHAR),u=n.M.Replace(u,n.M.s_RIGHT_M_K_CHAR_REPLACE,s.o.s_BLANK_CHAR)
const c=n.M.Split(u,n.M.s_SPAN_CHAR_DOT)
if(c.count>1){let t=n.M.String2Int(c[0])
this.minStar=t,t=n.M.String2Int(c[1]),this.maxStar=t,this.minStar==this.maxStar&&(this.starShow=t)}}}SuitRes_get(){return this.suitRes}}},80891:(t,e,i)=>{i.d(e,{P:()=>C})
var s=i(38836),n=i(86133),l=i(98800),a=i(97960),o=i(62370),r=i(5924),h=i(6665),d=i(30849),u=i(85602),c=i(79534),_=i(87923),I=i(4896),m=i(7475)
class g{constructor(){this.type=0,this.val=0,this.str=null}}var p=i(88838)
class C extends d.C{constructor(){super(),this.grid=null,this.parent=null,this.isEquipTip=!0,this.isReady=!1,this.isShow=!1,this.interval=-1,this.cfg=null,
this._degf_DelayUpdateLevel=null,this._degf_OnItemRefreshFun=null,this._degf_OnReposition=null,this._degf_UpdateLevel=null,
this._degf_DelayUpdateLevel=(t,e)=>this.DelayUpdateLevel(t,e),this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),this._degf_OnReposition=()=>this.OnReposition(),
this._degf_UpdateLevel=t=>this.UpdateLevel(t)}InitView(){super.InitView(),this.grid=new h.A,this.grid.setId(this.FatherId,this.FatherComponentID,1),
this.grid.SetInitInfo("ui_equiptip_legendattr",this._degf_OnItemRefreshFun),this.grid.OnReposition_set(this._degf_OnReposition)}SetData(t,e,i,a){null==a&&(a=!0),null==i&&(i=!0),
this.parent=e,this.isEquipTip=i,this.cfg=t
const r=new u.Z
let h=null,d=null
if(t.IsAngelEquip()&&!_.l.IsEmptyStr(t.attrsAngelWeapon)){let e=t.attrsAngelWeapon+(o.o.s_UNDER_CHAR+l.Y.Inst.PrimaryRoleInfo_get().Level_get()),i=I.n.Inst().GetItemById(e)
if(null==i&&(e=`${t.attrsAngelWeapon}${o.o.s_UNDER_CHAR}1`,i=I.n.Inst().GetItemById(e),null!=i)){const s=i.levelLimit
e=t.attrsAngelWeapon+(o.o.s_UNDER_CHAR+s),i=I.n.Inst().GetItemById(e)}if(null!=i&&null!=i.m_atts&&null!=i.m_atts.attrs&&i.m_atts.attrs.Count()>0)for(const[t,e]of(0,
s.V5)(i.m_atts.attrs)){h="",2004==e.intType?h="":2005==e.intType?h="1/":2006==e.intType&&(h=(0,n.T)("等级/")),
d=2004!=e.intType&&2005!=e.intType&&2006!=e.intType?`[ff56cd]${_.l.getAttrStrWithoutSign(e.intType)} +${_.l.getAttrValueStr(e.intType,e.value)}[-]`:`[ff56cd]${_.l.getAttrStrWithoutSign(e.intType)} +${h}${_.l.getAttrValueStr(e.intType,e.value)}[-]`
const t=new g
t.str=d,r.Add(t)}}r.Count()>0?(this.node.SetActive(!0),a?this.grid.OnReposition_set(this._degf_OnReposition):this.grid.OnReposition_set(null),this.isShow=!0,
this.grid.data_set(r)):(this.node.SetActive(!1),a&&this.OnReposition())}AddLis(){l.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(a.A.LevelUpdate,this._degf_UpdateLevel)}
UpdateLevel(t){this.isShow&&null!=this.cfg&&this.cfg.IsAngelEquip()&&(r.C.Inst_get().ClearInterval(this.interval),
this.IsReady()?this.SetData(this.cfg,this.parent,this.isEquipTip,!1):this.interval=r.C.Inst_get().SetFrameLoopForParm(this._degf_DelayUpdateLevel,1,1,t))}DelayUpdateLevel(t,e){
this.UpdateLevel(e)}IsReady(){if(this.isShow){if(this.isEquipTip&&null!=this.parent){return this.parent.GetIsRelayoutFinish()}return this.isReady}return!1}OnItemRefreshFun(t){
const e=new p.G
return e.setId(t,null,0),e}OnReposition(){if(this.isEquipTip){this.parent.SetReady(m.L.eAngelModule)}else{const t=this.parent
t.ReadyCnt_set(t.ReadyCnt_get()+1)}}Hide(){const t=this.node.transform.GetLocalPosition()
t.y=1e4,this.node.transform.SetLocalPosition(t),c.P.Recyle(t)}Clear(){this.isShow=!1,this.isReady=!1,this.cfg=null
l.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(a.A.LevelUpdate,this._degf_UpdateLevel),r.C.Inst_get().ClearInterval(this.interval),this.interval=-1}Destroy(){
this.grid.Destroy(),this.grid=null}}},91959:(t,e,i)=>{i.d(e,{N:()=>c})
var s=i(98958),n=i(5924),l=i(99294),a=i(30267),o=i(93877),r=i(30849),h=i(79534),d=i(87923),u=i(7475)
class c extends r.C{constructor(){super(),this.auctionModule=null,this.table=null,this.auctionLabel=null,this.auctionTime=null,this.parent=null,this.isEquipTip=!0,this.timeStr="",
this.auctionTimer=-1,this.activeColor="[ffefe1]",this.inactiveColor="[fe2e2d]",this.curData=null,this._degf_OnReposition=null,this._degf_OnReposition=()=>this.OnReposition()}
InitView(){this.auctionModule=new l.z,this.auctionModule.setId(this.FatherId,this.FatherComponentID,1),this.table=new a.V,this.table.setId(this.FatherId,this.FatherComponentID,2),
this.auctionLabel=new o.Q,this.auctionLabel.setId(this.FatherId,this.FatherComponentID,3),this.auctionTime=new o.Q,this.auctionTime.setId(this.FatherId,this.FatherComponentID,4),
this.table.OnReposition_set(this._degf_OnReposition),this.timeStr=s.V.Inst().getStr2(10735),super.InitView()}SetData(t,e,i){null==i&&(i=!0),this.ClearTimer(),this.curData=t,
this.parent=e,this.isEquipTip=i,this.node.SetActive(!1),this.table.Reposition()}OnReposition(){if(this.isEquipTip){this.parent.SetReady(u.L.eAuctionModule)}else{const t=this.parent
t.ReadyCnt_set(t.ReadyCnt_get()+1)}}ClearTimer(){n.C.Inst_get().ClearInterval(this.auctionTimer),this.auctionTimer=-1}AuctionTimeChange(){let t=""
t=1==this.curData.AuctionState_get()?s.V.Inst().getStr2(10737):d.l.GetDateFormat(this.curData.AuctionState_get()),
this.auctionTime.textSet(`${this.timeStr}${this.inactiveColor}${t}[-]`)}Hide(){const t=this.node.transform.GetLocalPosition()
t.y=1e4,this.node.transform.SetLocalPosition(t),h.P.Recyle(t)}}},11751:(t,e,i)=>{i.d(e,{$:()=>D})
var s=i(38836),n=i(86133),l=i(98800),a=i(98958),o=i(6665),r=i(93877),h=i(30849),d=i(98130),u=i(85602),c=i(38962),_=i(79534),I=i(59918),m=i(75321),g=i(77477),p=i(87923),C=i(60917),S=i(52429),f=i(44498),y=i(60606),v=i(88309)
class D extends h.C{constructor(){super(),this.grid=null,this.extend=null,this.parent=null,this.isEquipTip=!0,this._degf_OnItemRefreshFun=null,this._degf_OnReposition=null,
this._degf_SortAttrData=null,this.baseObj=null,this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),this._degf_OnReposition=()=>this.OnReposition(),
this._degf_SortAttrData=(t,e)=>this.SortAttrData(t,e)}InitView(){super.InitView(),this.grid=this.CreateComponent(o.A,1),this.baseObj=this.CreateComponent(r.Q,2),
this.grid.SetInitInfo("ui_equiptip_commonattrhasstar",this._degf_OnItemRefreshFun),this.grid.OnReposition_set(this._degf_OnReposition)}SetData(t,e,i,o,r,h,_,v){null==v&&(v=!0),
this.parent=_,this.isEquipTip=v
const E=new u.Z,T=new c.X
let A=null,L=!1,w=!1,R=!1
let O=!1
const G=(0,n.T)(" [29e228]+强化[-]"),b=(0,n.T)(" [10a1ed]+追加[-]"),M=(0,n.T)(" [e2a66a]+套装[-]"),P=(0,n.T)(" [e2a66a]+培养[-]"),B=((0,n.T)(" [e5bb22]+再生[-]"),(0,n.T)(" [5bba5b]+精炼[-]"),
(0,n.T)(" [0094FD]+升品[-]"),(0,n.T)("【基础属性】（{0}{1}{2}{3}{4}{5}{6}）")),x=new c.X
o.equipType==I.R.GUARD?D.GetGuardEquipBaseData(o,h,x):D.getBaseAttrDic(o,x),D.addBaseAttrStr(x,T)
let N=o.wearPosition_get()
null!=h&&(N=h.Pos_Get())
let k=1,V=new c.X,F=!1
null!=h?(k=h.Column_Get(),V=f.I.GetEnhanceAttrsByColumnPosAndLevel(k,N,h.Enhancelevel_get(),h.GetEquipRes().IsCanEnhance())):null!=e.EquipShowConfig_get()?(F=!0,
V=f.I.GetEnhanceAttrsByColumnPosAndLevel(k,N,e.EquipShowConfig_get().enhanceLv,e.Config_get().IsCanEnhance())):V=f.I.GetEnhanceAttrsByColumnPosAndLevel(k,N,0,e.Config_get().IsCanEnhance()),
null!=h?V=f.I.GetEnhanceAttrsByColumnPosAndLevel(k,N,h.Enhancelevel_get(),e.Config_get().IsCanEnhance()):null!=e.EquipShowConfig_get()?(F=!0,
V=f.I.GetEnhanceAttrsByColumnPosAndLevel(k,N,e.EquipShowConfig_get().enhanceLv,e.Config_get().IsCanEnhance())):V=f.I.GetEnhanceAttrsByColumnPosAndLevel(k,N,e.Config_get().IsCanEnhance())
let U=e.ChangeAttrs_get()
if(null!=U&&null!=U.attrs){U=U.Clone()
for(const[t,e]of(0,s.V5)(U.attrs)){let t=0
V.LuaDic_ContainsKey(e.intType)&&(t=V[e.intType])
let i=""
2004==e.intType?i="":2005==e.intType?i="1/":2006==e.intType&&(i=(0,n.T)("等级/"))
let s="",l="[5bba5b]"
"WINGS"!=o.equipType||e.intType!=d.GF.INT(g.Z.HpRate)&&e.intType!=d.GF.INT(g.Z.AttackRate)?0!=t&&(s=p.l.getAttrValueStr(e.intType,t),
T.LuaDic_ContainsKey(e.intType)?(A=T[e.intType],2004!=e.intType&&2005!=e.intType&&2006!=e.intType?A+=` [5bba5b]+${s}[-]`:A+=` [5bba5b]+${i}${s}[-]`,
T.LuaDic_AddOrSetItem(e.intType,A),
L=!0):(2004!=e.intType&&2005!=e.intType&&2006!=e.intType?l=`${l}${p.l.getAttrStrWithoutSign(e.intType)} +${s}[-]`:l+=`${p.l.getAttrStrWithoutSign(e.intType)} +${i}${s}[-]`,
T.LuaDic_AddOrSetItem(e.intType,l),L=!0)):0!=e.value&&0!=t&&(s=p.l.getAttrValueStr(e.intType,t,!0),T.LuaDic_ContainsKey(e.intType)?(A=T[e.intType],
2004!=e.intType&&2005!=e.intType&&2006!=e.intType?A+=` [5bba5b]+${s}[-]`:A+=` [5bba5b]+${i}${s}[-]`,T.LuaDic_AddOrSetItem(e.intType,A),
L=!0):(2004!=e.intType&&2005!=e.intType&&2006!=e.intType?l+=`${p.l.getAttrStrWithoutSign(e.intType)} +${s}[-]`:l+=`${p.l.getAttrStrWithoutSign(e.intType)} +${i}${s}[-]`,
T.LuaDic_AddOrSetItem(e.intType,l),L=!0))}}else if(F){U=new S.L,U.attrs=new u.Z
for(const[t,e]of(0,s.vy)(V))if(V[t]>0){const e=new C.P
e.intType=t,e.value=V[t],U.attrs.Add(e)}for(const[t,e]of(0,s.V5)(U.attrs)){let t=0
V.LuaDic_ContainsKey(e.intType)&&(t=V[e.intType])
let i=""
2004==e.intType?i="":2005==e.intType?i="1/":2006==e.intType&&(i=(0,n.T)("等级/"))
let s="",l="[5bba5b]"
"WINGS"!=o.equipType||e.intType!=d.GF.INT(g.Z.HpRate)&&e.intType!=d.GF.INT(g.Z.AttackRate)?0!=t&&(s=p.l.getAttrValueStr(e.intType,t),
T.LuaDic_ContainsKey(e.intType)?(A=T[e.intType],A=2004!=e.intType&&2005!=e.intType&&2006!=e.intType?`${A} [5bba5b]+${s}[-]`:`${A} [5bba5b]+${i}${s}[-]`,
T.LuaDic_AddOrSetItem(e.intType,A),
L=!0):(2004!=e.intType&&2005!=e.intType&&2006!=e.intType?l=`${l}${p.l.getAttrStrWithoutSign(e.intType)} +${s}[-]`:l+=`${p.l.getAttrStrWithoutSign(e.intType)} +${i}${s}[-]`,
T.LuaDic_AddOrSetItem(e.intType,l),L=!0)):0!=e.value&&0!=t&&(s=p.l.getAttrValueStr(e.intType,t,!0),T.LuaDic_ContainsKey(e.intType)?(A=T[e.intType],
2004!=e.intType&&2005!=e.intType&&2006!=e.intType?A+=` [5bba5b]+${s}[-]`:A+=` [5bba5b]+${i}${s}[-]`,T.LuaDic_AddOrSetItem(e.intType,A),
L=!0):(2004!=e.intType&&2005!=e.intType&&2006!=e.intType?l+=`${p.l.getAttrStrWithoutSign(e.intType)} +${s}[-]`:l+=`${p.l.getAttrStrWithoutSign(e.intType)} +${i}${s}[-]`,
T.LuaDic_AddOrSetItem(e.intType,l),L=!0))}}let H=0
if(null!=h&&null!=h.equipmentAdd?H=h.equipmentAdd.addLevel:null==h&&null!=e.EquipShowConfig_get()&&(H=e.EquipShowConfig_get().equipAddShow),0!=H){let t=new c.X
t=f.I.GetAddtionAttrsByLevel(k,N,H)
const e=new u.Z
for(const[i,n]of(0,s.vy)(t))if(t[i]>0){const s=new C.P
s.intType=i,s.value=t[i],e.Add(s)}this.AddExtendAttrs(null,e,T,"[61acf2]"),w=!0}const q=new c.X
if(null!=activeCfg){const t=q,e=new u.Z
for(const[i,n]of(0,s.vy)(t))if(t[i]>0){const s=new C.P
s.intType=i,s.value=t[i],e.Add(s)}this.AddExtendAttrs(null,e,T,"[e2a66a]"),O=!0}let Z=!1
if(null!=h){null!=l.Y.Inst.PrimaryRoleInfo_get().GetEquipmentById(h.id)&&(Z=!0)}const j=new c.X,X=j.LuaDic_Count()
if(o.intPosition_get()==d.GF.INT(m.C.WINGS)&&null!=wingRefine&&X>0&&j.LuaDic_Count()>0){R=!0
const t=new u.Z
for(const[e,i]of(0,s.vy)(j)){const i=new C.P
i.intType=e,i.value=j[e],t.Add(i)}this.AddExtendAttrs(null,t,T,"[e2a66a]")}let Y=0,W=0
if(null!=h&&o.intPosition_get()==d.GF.INT(m.C.ASURAFLAG)&&(Y=h.flagLv,W=h.flagQuality),null!=h&&null!=o.relivePools){let e=h.GetReliveLevel()
if(i.isPreviewRelive&&(e+=1),e>0){const i=o.intPosition_get(),s=r.equipStepLv,n=d.GF.INT(t.job/100),l=new u.Z(4)
l[0]=i,l[1]=e,l[2]=s,l[3]=n,this.AddExtendAttrs(null,null,T)}}const $=new u.Z
for(const[t,e]of(0,s.vy)(T)){const e=new y.H
e.type=t,e.str=T[t],x.LuaDic_ContainsKey(t)&&x[t]>0&&(e.isZeroBase=!1),$.Add(e)}$.Sort(this._degf_SortAttrData)
let J=0
for(;J<$.Count();)E.Add($[J]),J+=1
E.Count()>0?(this.node.SetActive(!0),this.grid.data_set(E)):(this.node.SetActive(!1),this.OnReposition())
let z=""
const Q=new u.Z
if(L||w||R||O){L&&Q.Add(G),w&&Q.Add(b),O&&Q.Add(M),R&&Q.Add(P)
let t=Q.Count()
for(;t<7;)Q.Add(""),t+=1
z=a.V.Inst().replaceLangParam(B,Q)}else z=(0,n.T)("【基础属性】")
this.baseObj.textSet(z)}AddExtendAttrs(t,e,i,l){if(null==l&&(l="[e5bb22]"),null==e){e=new u.Z
for(const[i,n]of(0,s.vy)(t.attrs)){const t=new C.P
t.intType=n.intType,t.value=n.value,e.Add(t)}}let a=0
for(;a<e.Count();){const t=e[a].intType,s=e[a].value
let o="",r=l
2004==t?o="":2005==t?o="1/":2006==t&&(o=(0,n.T)("等级/"))
const h=p.l.getAttrValueStr(t,s)
let d=null
i.LuaDic_ContainsKey(t)?(d=i[t],d+=2004!=t&&2005!=t&&2006!=t?` ${r}+${h}[-]`:` ${r}+${o}${h}[-]`,
i.LuaDic_AddOrSetItem(t,d)):(r+=2004!=t&&2005!=t&&2006!=t?`${p.l.getAttrStrWithoutSign(t)} +${h}[-]`:`${p.l.getAttrStrWithoutSign(t)} +${o}${h}[-]`,i.LuaDic_AddOrSetItem(t,r)),a+=1
}u.Z.Recyle(e)}static getBaseAttrDic(t,e){const i=t.m_atts_get().Clone()
if(null!=i&&null!=i.attrs)for(const[t,n]of(0,s.V5)(i.attrs))e.LuaDic_AddOrSetItem(n.intType,n.value)}static GetGuardEquipBaseData(t,e,i){
const s=GuardCfgMgr.Inst().GetByItemIdAndStar(t.id,0).baseAttrList
let n=null
for(let t=0;t<=s.Count()-1;t++)n=s[t],i.LuaDic_AddOrSetItem(n.intType,n.value)}static addBaseAttrStr(t,e){let i=null
for(const[l,a]of(0,s.vy)(t))if(t[l]>0){let s=""
2004==l?s="":2005==l?s="1/":2006==l&&(s=(0,n.T)("等级/")),2012==l||2013==l?(i=`[5bba5b]${p.l.getAttrStrWithoutSign(l)}[-] [5bba5b]+${p.l.getAttrValueStr(l,t[l])}[-]`,
e.LuaDic_AddOrSetItem(l,i)):2004!=l&&2005!=l&&2006!=l?(i=`[ffefe1]${p.l.getAttrStrWithoutSign(l)}[-] [ffefe1]+${p.l.getAttrValueStr(l,t[l])}[-]`,
e.LuaDic_AddOrSetItem(l,i)):(i=`[ffefe1]${p.l.getAttrStrWithoutSign(l)}[-] [ffefe1]+${s}${p.l.getAttrValueStr(l,t[l])}[-]`,e.LuaDic_AddOrSetItem(l,i))}}isDamageUpDown(t){
return 2012==t||2013==t}SortAttrData(t,e){
return D.isDamageUpDown(t.type)&&!D.isDamageUpDown(e.type)?-1:D.isDamageUpDown(e.type)&&!D.isDamageUpDown(t.type)||t.isZeroBase&&!e.isZeroBase?1:!t.isZeroBase&&e.isZeroBase?-1:t.type>e.type?1:t.type<e.type?-1:0
}SortAttrDataType(t,e){return D.isDamageUpDown(t)&&!D.isDamageUpDown(e)?-1:D.isDamageUpDown(t)&&!D.isDamageUpDown(e)||t>e?1:t<e?-1:0}OnItemRefreshFun(t){const e=new v.R
return e.setId(t,null,0),e}OnReposition(){}Hide(){const t=this.node.transform.GetLocalPosition()
t.y=1e4,this.node.transform.SetLocalPosition(t),_.P.Recyle(t)}Destroy(){this.grid.Destroy(),this.grid=null}}},93889:(t,e,i)=>{i.d(e,{n:()=>n})
var s=i(85602)
class n{constructor(){this.pos_str=null,this.job_str=null,this.level_str=null,this.level_need_str=null,this.attr_str=null,this.attr_need_str=null,this.exdesc_str=null,
this.elementtype_need_str=null,this.attr_str=new s.Z,this.attr_need_str=new s.Z}IsEmpty(){
return null==this.job_str&&null==this.level_str&&null==this.level_need_str&&0==this.attr_str.Count()&&0==this.attr_need_str.Count()&&null==this.elementtype_need_str}}},
52833:(t,e,i)=>{i.d(e,{a:()=>r})
var s,n=i(18998),l=i(83908),a=i(85602),o=i(48933)
let r=n._decorator.ccclass("EquipTipDemandItem")(s=class extends((0,l.zB)()){constructor(...t){super(...t),this.attrList=null,this.itemHeight=null}InitView(){super.InitView(),
this.attrList=new a.Z,this.attrList.Add(new a.Z([this.attr_0,this.attr_need_0])),this.attrList.Add(new a.Z([this.attr_1,this.attr_need_1])),
this.attrList.Add(new a.Z([this.attr_2,this.attr_need_2])),this.attrList.Add(new a.Z([this.attr_3,this.attr_need_3])),this.itemHeight=26}SetData(t){this.job.node.SetActive(!1),
this.level.node.SetActive(!1),this.level_need.node.SetActive(!1)
let e=0
null!=t.job_str?(this.job.node.SetActive(!0),o.I.calVec0.Set(0,e,0),this.job.node.transform.SetLocalPosition(o.I.calVec0),this.job.textSet(t.job_str),
e-=this.itemHeight):this.job.node.SetActive(!1),null!=t.level_str?(this.level.node.SetActive(!0),o.I.calVec0.Set(0,e,0),this.level.node.transform.SetLocalPosition(o.I.calVec0),
this.level.textSet(t.level_str),e-=this.itemHeight):this.level.node.SetActive(!1),null!=t.level_need_str?(this.level_need.node.SetActive(!0),o.I.calVec0.Set(0,e,0),
this.level_need.node.transform.SetLocalPosition(o.I.calVec0),this.level_need.textSet(t.level_need_str),e-=this.itemHeight):this.level_need.node.SetActive(!1)
for(let i=0;i<=3;i++){const s=this.attrList[i][0],n=this.attrList[i][1]
i<t.attr_str.Count()?(null!=t.attr_str[i]?(s.node.SetActive(!0),o.I.calVec0.Set(0,e,0),s.node.transform.SetLocalPosition(o.I.calVec0),s.textSet(t.attr_str[i]),
e-=this.itemHeight):s.node.SetActive(!1),null!=t.attr_need_str[i]?(n.node.SetActive(!0),o.I.calVec0.Set(0,e,0),n.node.transform.SetLocalPosition(o.I.calVec0),
n.textSet(t.attr_need_str[i]),e-=this.itemHeight):n.node.SetActive(!1)):(s.node.SetActive(!1),n.node.SetActive(!1))}}Clear(){}Destroy(){}})||s},17081:(t,e,i)=>{i.d(e,{k:()=>A})
var s=i(86133),n=i(98800),l=i(97960),a=i(97461),o=i(62370),r=i(5924),h=i(6665),d=i(93877),u=i(30849),c=i(98130),_=i(98885),I=i(85602),m=i(79534),g=i(33854),p=i(84485),C=i(71143),S=i(92679),f=i(77477),y=i(87923),v=i(41864),D=i(7475),E=i(93889),T=i(52833)
class A extends u.C{constructor(){super(),this.grid=null,this.demandtxt=null,this._role=null,this._er=null,this._info=null,this._equip=null,this._ir=null,this.parent=null,
this.isEquipTip=!0,this.normalColor="[CCCBC4]",this.inactiveColor="[FB2704]",this.intervalId=-1,this.aModel=null,this._baseData=null,this._degf_AttributeUpdate=null,
this._degf_OnItemRefreshFun=null,this._degf_OnReposition=null,this._degf_UpdateAddPointState=null,this._degf_updatePoint=null,this._degf_AttributeUpdate=t=>this.AttributeUpdate(t),
this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),this._degf_OnReposition=()=>this.OnReposition(),this._degf_UpdateAddPointState=()=>this.UpdateAddPointState(),
this._degf_updatePoint=t=>this.updatePoint(t)}InitView(){super.InitView(),this.grid=this.CreateComponent(h.A,1),this.demandtxt=this.CreateComponent(d.Q,2),
this.grid.SetInitInfo("ui_equiptip_demanditem",this._degf_OnItemRefreshFun),this.aModel=p.X.Inst_get(),this.grid.OnReposition_set(this._degf_OnReposition)}AddLis(){
a.i.Inst.AddEventHandler(S.g.ATTR_PRE_CHANGE_UPDATE,this._degf_updatePoint)
n.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(l.A.AttributesChanged,this._degf_AttributeUpdate)}updatePoint(t){this._ir}AttributeUpdate(t){
t.Id_get().Equal(n.Y.Inst.PrimaryRoleInfo_get().Id_get())&&null!=this._ir&&this.SetData(this._role,this._info,this._baseData,this._equip,this.parent,this.isEquipTip,!0)}
UpdateAddPointState(){g.t.Inst_get().IsEquipAddPointTipShow()&&null!=this._ir&&this.isEquipTip&&this.SetData(this._role,this._info,this._baseData,this._equip,this.parent,!0,!0)}
SetData(t,e,i,n,l,a,h){null==h&&(h=!1),null==a&&(a=!0),r.C.Inst_get().ClearInterval(this.intervalId),
this.intervalId=r.C.Inst_get().SetInterval(this._degf_UpdateAddPointState,100,-1),this._baseData=i,this._role=t,this._info=e,this._er=i.cfgEquipData_get(),this._ir=i.cfgData_get(),
this._equip=n,this.parent=l,this.isEquipTip=a
const d=new E.n
if(this.demandtxt.textSet((0,s.T)("【穿戴要求】")),d.pos_str=`${y.l.GetChineseNum(this._ir.equipStepLv)}${(0,s.T)("阶")} ${this._er.typeName}`,0!=this._ir.Jobs_get().Count()){
let t=this.normalColor+((0,s.T)("职业：[-]")+this.normalColor),e=0
for(;e<this._ir.Jobs_get().Count();){const i=this._ir.Jobs_get()[e],s=y.l.getJobStr(i),n=C.i.HadTargetJobRole(i)
n||(t+=this.inactiveColor),t+=s,n||(t+="[-]"),e<this._ir.Jobs_get().Count()-1&&(t+=o.o.s_F_SLASH_ONE),e+=1}t+="[-]",d.job_str=""+t}0!=this._ir.level&&(d.level_str=_.M.Replace((0,
s.T)("需求等级:{0}"),"{0}",v.h.GetLevelStr(this._ir.level)),t.Level_get()<this._ir.level&&(d.level_need_str=_.M.Replace((0,s.T)("(还需{0}级)"),"{0}",this._ir.level-t.Level_get())))
const u=new I.Z([0,0,0,0])
let m=!1
const g=new I.Z([f.Z.Strength,f.Z.Vitality,f.Z.Intelligence,f.Z.Agility]),p=new I.Z([this._er.strengthLimit+u[0],this._er.vitalityLimit+u[1],this._er.intelligenceLimit+u[2],this._er.agilityLimit+u[3]]),S=new I.Z([this.aModel.strengthAddPoint,this.aModel.vitalityAddPoint,this.aModel.intelligenceAddPoint,this.aModel.agilityAddoint])
for(let e=0;e<=g.Count()-1;e++){const i=p[e]
if(i>0){let n=0
if(n=h?c.GF.INT(t.Attributes_get()[c.GF.INT(g[e])])+S[e]:c.GF.INT(t.Attributes_get()[c.GF.INT(g[e])]),d.attr_str.Add((0,s.T)(`需求${y.l.GetAttName(g[e])}：${i}`)),i>n){m=!0
let t=_.M.Replace((0,s.T)("({0}：{1}点不足)"),"{0}",y.l.GetAttName(g[e]))
t=_.M.Replace(t,"{1}",i-n),d.attr_need_str.Add(t)}else d.attr_need_str.Add(null)}}null!=n&&!n.isEffective&&m&&this.demandtxt.textSet((0,s.T)("穿戴要求[962424](属性点不足，已失效)[-]")),
d.IsEmpty()?(this.node.SetActive(!1),r.C.Inst_get().ClearInterval(this.intervalId),this.OnReposition()):(this.node.SetActive(!0),this.grid.data_set(new I.Z([d])))}
OnItemRefreshFun(t){const e=new T.a
return e.setId(t,null,0),e}OnReposition(){if(this.isEquipTip){this.parent.SetReady(D.L.eDemandModule)}else{const t=this.parent
t.ReadyCnt_set(t.ReadyCnt_get()+1)}}clear(){n.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(l.A.AttributesChanged,this._degf_AttributeUpdate),
r.C.Inst_get().ClearInterval(this.intervalId)}Hide(){const t=this.node.transform.GetLocalPosition()
t.y=1e4,this.node.transform.SetLocalPosition(t),m.P.Recyle(t)}Destroy(){null!=this.grid&&(this.grid.Destroy(),this.grid=null),
a.i.Inst.RemoveEventHandler(S.g.ATTR_PRE_CHANGE_UPDATE,this._degf_updatePoint)
n.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(l.A.AttributesChanged,this._degf_AttributeUpdate)}}},87666:(t,e,i)=>{i.d(e,{f:()=>A})
var s=i(93984),n=i(38836),l=i(86133),a=i(98958),o=i(99294),r=i(6665),h=i(30267),d=i(93877),u=i(30849),c=i(98885),_=i(85602),I=i(79534),m=i(1003),g=i(77477),p=i(87923),C=i(60917),S=i(52429),f=i(44498),y=i(14366),v=i(33833),D=i(7475),E=i(39367),T=i(13375)
class A extends u.C{constructor(){super(),this.excellenceGrid=null,this.table=null,this.sureObj=null,this.sureGrid=null,this.randomObj=null,this.randomGrid=null,
this.excellenceObj=null,this.excellenceShowObj=null,this.luckyObj=null,this.luckyGrid=null,this.ignoreObj=null,this.ignoreGrid=null,this.luckTitle=null,this.ignoreTitle=null,
this.fourStarObj=null,this.fourStargrid=null,this.fiveStarObj=null,this.fiveStargrid=null,this.auctionExcellenceObj=null,this.auctionStar=null,this.auctionFirstLabel=null,
this.extend=null,this.parent=null,this.isEquipTip=!0,this.totalAttrGrid=0,this._degf_OnItemRefreshFun=null,this._degf_OnReposition=null,this._degf_OnReposition2=null,
this._degf_SortAttr=null,this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),this._degf_OnReposition=()=>this.OnReposition(),this._degf_OnReposition2=()=>this.OnReposition2(),
this._degf_SortAttr=(t,e)=>this.SortAttr(t,e)}InitView(){super.InitView(),this.excellenceGrid=new r.A,this.excellenceGrid.setId(this.FatherId,this.FatherComponentID,1),
this.table=new h.V,this.table.setId(this.FatherId,this.FatherComponentID,2),this.sureObj=new o.z,this.sureObj.setId(this.FatherId,this.FatherComponentID,3),this.sureGrid=new r.A,
this.sureGrid.setId(this.FatherId,this.FatherComponentID,4),this.randomObj=new o.z,this.randomObj.setId(this.FatherId,this.FatherComponentID,5),this.randomGrid=new r.A,
this.randomGrid.setId(this.FatherId,this.FatherComponentID,6),this.excellenceObj=new o.z,this.excellenceObj.setId(this.FatherId,this.FatherComponentID,7),
this.excellenceShowObj=new o.z,this.excellenceShowObj.setId(this.FatherId,this.FatherComponentID,8),this.luckyObj=new o.z,
this.luckyObj.setId(this.FatherId,this.FatherComponentID,9),this.luckyGrid=new r.A,this.luckyGrid.setId(this.FatherId,this.FatherComponentID,10),this.ignoreObj=new o.z,
this.ignoreObj.setId(this.FatherId,this.FatherComponentID,11),this.ignoreGrid=new r.A,this.ignoreGrid.setId(this.FatherId,this.FatherComponentID,12),this.luckTitle=new d.Q,
this.luckTitle.setId(this.FatherId,this.FatherComponentID,13),this.ignoreTitle=new d.Q,this.ignoreTitle.setId(this.FatherId,this.FatherComponentID,14),this.fourStarObj=new o.z,
this.fourStarObj.setId(this.FatherId,this.FatherComponentID,15),this.fourStargrid=new r.A,this.fourStargrid.setId(this.FatherId,this.FatherComponentID,16),this.fiveStarObj=new o.z,
this.fiveStarObj.setId(this.FatherId,this.FatherComponentID,17),this.fiveStargrid=new r.A,this.fiveStargrid.setId(this.FatherId,this.FatherComponentID,18),
this.auctionExcellenceObj=new o.z,this.auctionExcellenceObj.setId(this.FatherId,this.FatherComponentID,19),this.auctionStar=new o.z,
this.auctionStar.setId(this.FatherId,this.FatherComponentID,20),this.auctionFirstLabel=new d.Q,this.auctionFirstLabel.setId(this.FatherId,this.FatherComponentID,21),
this.extend=new d.Q,this.extend.setId(this.FatherId,this.FatherComponentID,22),this.luckyGrid.SetInitInfo("ui_equiptip_excellenceattr",this._degf_OnItemRefreshFun),
this.luckyGrid.OnReposition_set(this._degf_OnReposition2),this.ignoreGrid.SetInitInfo("ui_equiptip_excellenceattr",this._degf_OnItemRefreshFun),
this.ignoreGrid.OnReposition_set(this._degf_OnReposition2),this.excellenceGrid.SetInitInfo("ui_equiptip_excellenceattr",this._degf_OnItemRefreshFun),
this.excellenceGrid.OnReposition_set(this._degf_OnReposition2),this.sureGrid.SetInitInfo("ui_equiptip_excellenceattr",this._degf_OnItemRefreshFun),
this.sureGrid.OnReposition_set(this._degf_OnReposition2),this.randomGrid.SetInitInfo("ui_equiptip_excellenceattr",this._degf_OnItemRefreshFun),
this.randomGrid.OnReposition_set(this._degf_OnReposition2),this.fourStargrid.SetInitInfo("ui_equiptip_excellenceattr",this._degf_OnItemRefreshFun),
this.fourStargrid.OnReposition_set(this._degf_OnReposition2),this.fiveStargrid.SetInitInfo("ui_equiptip_excellenceattr",this._degf_OnItemRefreshFun),
this.fiveStargrid.OnReposition_set(this._degf_OnReposition2),this.table.OnReposition_set(this._degf_OnReposition)}SetData(t,e,i,o,r,h,d){const u=(0,l.T)("[f64746]（觉醒{0}级）[-]")
null==d&&(d=!0),this.parent=h,this.isEquipTip=d,this.ClearItems(),this.totalAttrGrid=0
const I=new _.Z,D=new _.Z,T=new _.Z,A=new _.Z,L=new _.Z,w=new _.Z,R=new _.Z
let O=!1,G=!1,b=!1
let M=0
null!=r&&(M=r.ExcellenceCount_get())
const P=t.Config_get().excellenceNum
let B=null,x=null,N=null,k=null,V=!1
const F=new S.L
if(F.attrs=new _.Z,null!=r&&null!=r.specialAdd&&1==r.specialAdd.lucky){V=!0
let t=y.C.Inst().GetAttrsByColAndPos(r.Column_Get(),r.Pos_Get())
if(null!=t&&t.Count()>0){V=!0
for(const[e,i]of(0,n.V5)(t))F.attrs.Add(i)}if(V){this.luckTitle.textSet((0,l.T)("幸运属性")),t=F
for(const[e,i]of(0,n.V5)(t.attrs))B="",2004==i.intType?B="":2005==i.intType?B="1/":2006==i.intType&&(B=(0,l.T)("等级/")),k=new E.G,k.isStar=!1,k.job=o.job,
k.attrType_set(m.U.GetAttrNameByType(i.intType)),k.priority=0,O=!1,2004!=i.intType&&2005!=i.intType&&2006!=i.intType?(x=`${(0,
l.T)("[4D91DE]幸运（")}${p.l.getAttrStrWithoutSign(i.intType)} +${p.l.getAttrValueStr(i.intType,i.value)}）[-]`,k.str=x,I.Add(k)):(x=`${(0,
l.T)("[4D91DE]幸运（")}${p.l.getAttrStrWithoutSign(i.intType)} +${B}${p.l.getAttrValueStr(i.intType,i.value)}）[-]`,k.str=x,I.Add(k))}}else if(null==r&&null!=t.EquipShowConfig_get()){
const e=t.EquipShowConfig_get().luckShow
if(1==e||2==e){const t={}
t.attrs=new _.Z
const i=null
if(null!=i&&i.Count()>0){V=!0
for(const[e,s]of(0,n.V5)(i))t.attrs.Add(s)}if(null!=t&&null!=t.attrs&&t.attrs.Count()>0){1==e?this.luckTitle.textSet((0,l.T)("必定生成")):this.luckTitle.textSet((0,l.T)("几率生成"))
for(const[e,i]of(0,n.V5)(t.attrs))B="",2004==i.intType?B="":2005==i.intType?B="1/":2006==i.intType&&(B=(0,l.T)("等级/")),k=new E.G,k.isStar=!1,k.job=o.job,
k.attrType_set(m.U.GetAttrNameByType(i.intType)),k.priority=0,O=!1,2004!=i.intType&&2005!=i.intType&&2006!=i.intType?(x=`${(0,
l.T)("[4D91DE]幸运（")}${p.l.getAttrStrWithoutSign(i.intType)} +${p.l.getAttrValueStr(i.intType,i.value)}）[-]`,k.str=x,I.Add(k)):(x=`${(0,
l.T)("[4D91DE]幸运（")}${p.l.getAttrStrWithoutSign(i.intType)} +${B}${p.l.getAttrValueStr(i.intType,i.value)}）[-]`,k.str=x,I.Add(k))}}}let U=!1
const H=new S.L,q=new C.P
if(null!=r&&null!=r.specialAdd){let t=0
for(;t<r.specialAdd.ignoreAttributes.Count();)q.intType=r.specialAdd.ignoreAttributes[t].type,q.type=m.U.GetAttrNameByType(q.intType),
q.value=r.specialAdd.ignoreAttributes[t].value,H.attrs=new _.Z,H.attrs.Add(q),U=!0,t+=1
if(U){this.ignoreTitle.textSet((0,l.T)("无视属性")),N=H
for(const[t,e]of(0,n.V5)(N.attrs))B="",2004==e.intType?B="":2005==e.intType?B="1/":2006==e.intType&&(B=(0,l.T)("等级/")),k=new E.G,k.isStar=!1,k.job=o.job,
k.attrType_set(m.U.GetAttrNameByType(e.intType)),
k.priority=0,G=!1,2004!=e.intType&&2005!=e.intType&&2006!=e.intType?(x=`[61acf2]${p.l.getAttrStrWithoutSign(e.intType)} +${p.l.getAttrValueStr(e.intType,e.value)}[-]`,k.str=x,
D.Add(k)):(x=`[61acf2]${p.l.getAttrStrWithoutSign(e.intType)} +${B}${p.l.getAttrValueStr(e.intType,e.value)}[-]`,k.str=x,D.Add(k))}}else if(null==r&&null!=t.EquipShowConfig_get()){
const e=t.EquipShowConfig_get().ignoreShow
if(1==e){this.ignoreTitle.textSet((0,l.T)("必定生成")),q.intType=g.Z.IgnoreHit,q.type=m.U.GetAttrNameByType(q.intType),q.value=t.EquipShowConfig_get().ignoreShowValue,H.attrs=new _.Z,
H.attrs.Add(q),N=H
for(const[t,e]of(0,n.V5)(N.attrs))B="",2004==e.intType?B="":2005==e.intType?B="1/":2006==e.intType&&(B=(0,l.T)("等级/")),k=new E.G,k.isStar=!1,k.job=o.job,
k.attrType_set(m.U.GetAttrNameByType(e.intType)),
k.priority=0,G=!1,2004!=e.intType&&2005!=e.intType&&2006!=e.intType?(x=`[61acf2]${p.l.getAttrStrWithoutSign(e.intType)} +${p.l.getAttrValueStr(e.intType,e.value)}[-]`,k.str=x,
D.Add(k)):(x=`[61acf2]${p.l.getAttrStrWithoutSign(e.intType)} +${B}${p.l.getAttrValueStr(e.intType,e.value)}[-]`,k.str=x,D.Add(k))}else if(2==e){this.ignoreTitle.textSet((0,
l.T)("几率生成")),q.intType=g.Z.IgnoreHit,q.type=m.U.GetAttrNameByType(q.intType),q.value=t.EquipShowConfig_get().ignoreShowValue,H.attrs=new _.Z,H.attrs.Add(q),N=H
for(const[t,e]of(0,n.V5)(N.attrs))B="",2004==e.intType?B="":2005==e.intType?B="1/":2006==e.intType&&(B=(0,l.T)("等级/")),k=new E.G,k.isStar=!1,k.job=o.job,
k.attrType_set(m.U.GetAttrNameByType(e.intType)),
k.priority=0,G=!1,2004!=e.intType&&2005!=e.intType&&2006!=e.intType?(x=`[4D91DE]${p.l.getAttrStrWithoutSign(e.intType)} +${p.l.getAttrValueStr(e.intType,e.value)}[-]`,k.str=x,
D.Add(k)):(x=`[4D91DE]${p.l.getAttrStrWithoutSign(e.intType)} +${B}${p.l.getAttrValueStr(e.intType,e.value)}[-]`,k.str=x,D.Add(k))}}if(0!=M||e.previewNextEquipNum>0){const i=null
for(const[e,s]of(0,n.V5)(r.exellectAttrs.attributeDatas)){let e=0
for(const[t,l]of(0,n.V5)(r.exellectAttrs.attributes))if(s.type==l.attributeType){e=l.level,null!=i&&i.awakeTimes>0&&(e+=i.excellentAttrsLevel)
break}B="",2004==s.type?B="":2005==s.type?B="1/":2006==s.type&&(B=(0,l.T)("等级/")),k=new E.G,k.isStar=f.I.IsEquipAttrStar(t.Config_get(),s.type),k.job=o.job,
k.attrType_set(m.U.GetAttrNameByType(s.type)),k.isStar&&(b=!0),2004!=s.type&&2005!=s.type&&2006!=s.type?(x="[29e228",x+=`${(0,
l.T)("]卓越（")}${p.l.getAttrStr(s.type,!1)}${p.l.getAttrValueStr(s.type,s.value,!s.isPercentage)}）[-]`,k.str=x,T.Add(k)):(x="[29e228",x+=`${(0,
l.T)("]卓越（")}${p.l.getAttrStr(s.type,!1)}${B}${p.l.getAttrValueStr(s.type,s.value,!s.isPercentage)}）[-]`,k.str=x,T.Add(k))}if(e.previewNextEquipNum>0){let t=0
for(;t<e.previewNextEquipNum;)k=new E.G,k.isStar=!1,k.isShowStarCnt=!1,k.priority=1e4,k.isNew=!0,x=(0,l.T)("[5FB470]卓越（随机属性）[-]"),k.str=x,T.Add(k),t+=1}}else if(P>0){
if(t.Config_get().fixExcellenceAttrs_get().attrs.Count()>0)for(let e=0;e<=t.Config_get().fixExcellenceAttrs_get().attrs.Count()-1;e++){
const i=t.Config_get().fixExcellenceAttrs_get().attrs[e]
B=""
const s=g.Z.GetAttrKey(i.type)
2004==s?B="":2005==s?B="1/":2006==s&&(B=(0,l.T)("等级/")),k=new E.G,k.isStar=f.I.IsEquipAttrStar(t.Config_get(),s),k.job=o.job,k.attrType_set(i.type)
const n=v.X.Inst().getItemById(s),a=1!=n.valueType&&0!=n.valueType
2004!=s&&2005!=s&&2006!=s?(x="[5FB470",x+=`${(0,l.T)("]卓越（")}${p.l.getAttrStr(s,!1)}${p.l.getAttrValueStr(s,i.value,!a)}）[-]`):(x="[5FB470",x+=`${(0,
l.T)("]卓越（")}${p.l.getAttrStr(s,!1)}${B}${p.l.getAttrValueStr(s,i.value,!a)}）[-]`),k.str=x,T.Add(k)}if(P-t.Config_get().fixExcellenceAttrs_get().attrs.Count()>0){const e=new E.G
e.isStar=!1,e.isShowStarCnt=!0,e.str=(0,l.T)("[5FB470]卓越 (随机生成")+(P-t.Config_get().fixExcellenceAttrs_get().attrs.Count()+(0,l.T)("条卓越属性)[-]")),T.Add(e)}}
if(I.Sort(this._degf_SortAttr),D.Sort(this._degf_SortAttr),T.Sort(this._degf_SortAttr),A.Sort(this._degf_SortAttr),L.Sort(this._degf_SortAttr),w.Sort(this._degf_SortAttr),
R.Sort(this._degf_SortAttr),this.luckyObj.SetActive(!1),this.ignoreObj.SetActive(!1),this.excellenceObj.SetActive(!1),this.sureObj.SetActive(!1),this.randomObj.SetActive(!1),
this.excellenceShowObj.SetActive(!1),this.fourStarObj.SetActive(!1),this.fiveStarObj.SetActive(!1),this.auctionExcellenceObj.SetActive(!1),d)if(null!=r&&r.awakeLevel>0){
const t=new _.Z
t.Add(r.awakeLevel)
const e=a.V.Inst().replaceLangParam(u,t)
this.extend.textSet(e)}else this.extend.textSet("")
let Z=!1
if(null!=r&&r.appraisal&&(Z=!0),Z){this.totalAttrGrid+=1,this.auctionExcellenceObj.SetActive(!0)
const t=new _.Z
t.Add(c.M.IntToString(r.excellAttrCount)),this.auctionFirstLabel.textSet(a.V.Inst().getStr(10760,s.h.eLangResource,t))}
if(I.Count()>0||D.Count()>0||T.Count()>0||A.Count()>0||L.Count()>0||w.Count()>0||R.Count()>0){if(I.Count()>0){this.totalAttrGrid+=1,this.luckyObj.SetActive(!0)
let t=0
for(;t<I.Count();){I[t].hasAnyStar=O,t+=1}this.luckyGrid.data_set(I)}if(D.Count()>0){this.totalAttrGrid+=1,this.ignoreObj.SetActive(!0)
let t=0
for(;t<D.Count();){D[t].hasAnyStar=G,t+=1}this.ignoreGrid.data_set(D)}if(T.Count()>0&&!Z){this.totalAttrGrid+=1,this.excellenceObj.SetActive(!0)
let t=0
for(;t<T.Count();){T[t].hasAnyStar=b,t+=1}this.excellenceGrid.data_set(T)}if(A.Count()>0||L.Count()>0){if(this.excellenceShowObj.SetActive(!0),A.Count()>0){this.totalAttrGrid+=1
let t=0
for(;t<A.Count();){A[t].hasAnyStar=false,t+=1}this.sureObj.SetActive(!0),this.sureGrid.data_set(A)}if(L.Count()>0){this.totalAttrGrid+=1
let t=0
for(;t<L.Count();){L[t].hasAnyStar=false,t+=1}this.randomObj.SetActive(!0),this.randomGrid.data_set(L)}}if(w.Count()>0){this.totalAttrGrid+=1,this.fourStarObj.SetActive(!0)
let t=0
for(;t<w.Count();){w[t].hasAnyStar=!1,t+=1}this.fourStargrid.data_set(w)}if(R.Count()>0){this.totalAttrGrid+=1,this.fiveStarObj.SetActive(!0)
let t=0
for(;t<R.Count();){R[t].hasAnyStar=!1,t+=1}this.fiveStargrid.data_set(R)}Z&&this.OnReposition2()}else Z?this.OnReposition2():this.OnReposition()}SortAttr(t,e){const i=t,s=e
return i.isShowStarCnt!=s.isShowStarCnt?1==i.isShowStarCnt&&0==s.isShowStarCnt?-1:1:i.isStar!=s.isStar?1==i.isStar&&0==s.isStar?-1:1:i.priority!=s.priority?i.priority<s.priority?-1:1:0
}ClearItems(){this.luckyGrid.Clear(),this.ignoreGrid.Clear(),this.excellenceGrid.Clear(),this.sureGrid.Clear(),this.randomGrid.Clear(),this.fourStargrid.Clear(),
this.fiveStargrid.Clear()}OnItemRefreshFun(t){const e=new T.N
return e.setId(t,null,0),e}OnReposition(){if(this.isEquipTip){this.parent.SetReady(D.L.eExcellenceModule)}else{const t=this.parent
t.ReadyCnt_set(t.ReadyCnt_get()+1)}}OnReposition2(){this.totalAttrGrid-=1,0==this.totalAttrGrid&&this.table.Reposition()}Hide(){let t=this.luckyObj.transform.GetLocalPosition()
t.y=1e4,this.luckyObj.transform.SetLocalPosition(t),I.P.Recyle(t),t=this.ignoreObj.transform.GetLocalPosition(),t.y=1e4,this.ignoreObj.transform.SetLocalPosition(t),I.P.Recyle(t),
t=this.excellenceObj.transform.GetLocalPosition(),t.y=1e4,this.excellenceObj.transform.SetLocalPosition(t),I.P.Recyle(t),t=this.excellenceShowObj.transform.GetLocalPosition(),
t.y=1e4,this.excellenceShowObj.transform.SetLocalPosition(t),I.P.Recyle(t),t=this.fourStarObj.transform.GetLocalPosition(),t.y=1e4,this.fourStarObj.transform.SetLocalPosition(t),
I.P.Recyle(t),t=this.fiveStarObj.transform.GetLocalPosition(),t.y=1e4,this.fiveStarObj.transform.SetLocalPosition(t),I.P.Recyle(t)}Destroy(){this.luckyGrid.Destroy(),
this.luckyGrid=null,this.ignoreGrid.Destroy(),this.ignoreGrid=null,this.excellenceGrid.Destroy(),this.excellenceGrid=null,this.sureGrid.Destroy(),this.sureGrid=null,
this.randomGrid.Destroy(),this.randomGrid=null,this.fourStargrid.Destroy(),this.fourStargrid=null,this.fiveStargrid.Destroy(),this.fiveStargrid=null,this.auctionExcellenceObj=null,
this.auctionStar=null,this.auctionFirstLabel=null,this.extend=null}}},6816:(t,e,i)=>{i.d(e,{w:()=>m})
var s=i(38045),n=i(6665),l=i(30849),a=i(85602),o=i(79534),r=i(14140),h=i(7475),d=i(86133),u=i(9057),c=i(93877),_=i(72005)
class I extends u.x{constructor(...t){super(...t),this.attrLabel=null,this.star=null,this.unlock=null}InitView(){super.InitView(),this.attrLabel=new c.Q,
this.attrLabel.setId(this.FatherId,this.FatherComponentID,1),this.star=new _.w,this.star.setId(this.FatherId,this.FatherComponentID,2),this.unlock=new c.Q,
this.unlock.setId(this.FatherId,this.FatherComponentID,3)}SetData(t){const e=t
this.star.node.SetActive(!0),this.attrLabel.textSet(e.str),this.unlock.node.SetActive(e.showLock),0==e.moduleType?e.unlockLevel>1?this.unlock.textSet(e.unlockLevel+(0,
d.T)("次觉醒后激活")):this.unlock.textSet((0,d.T)("觉醒后激活")):1==e.moduleType?this.unlock.textSet((0,d.T)("觉醒")+(e.unlockLevel+(0,
d.T)("级激活"))):1==e.moduleType&&this.star.node.SetActive(!1)}Clear(){}Destroy(){this.star=null,this.attrLabel=null,this.unlock=null}}class m extends l.C{constructor(){super(),
this.grid=null,this.parent=null,this.isEquipTip=!0,this._degf_OnItemRefreshFun=null,this._degf_OnReposition=null,this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),
this._degf_OnReposition=()=>this.OnReposition()}InitView(){super.InitView(),this.grid=new n.A,this.grid.setId(this.FatherId,this.FatherComponentID,1),
this.grid.SetInitInfo("ui_equiptip_godattr",this._degf_OnItemRefreshFun),this.grid.OnReposition_set(this._degf_OnReposition)}SetData(t,e,i,s,n){null==n&&(n=!0),this.parent=s,
this.isEquipTip=n
const l=new a.Z
if(t.IsGodEquip()){let s=0
const n=new a.Z(4),l=t.intPosition_get(),o=e.equipStepLv
n[0]=l,n[1]=o,n[2]=s,n[3]=t.GetJobBranch(),null!=i&&(s=i.awakeLevel)}l.Count()>0?(this.node.SetActive(!0),this.grid.data_set(l)):(this.node.SetActive(!1),this.OnReposition())}
OnItemRefreshFun(t){const e=new I
return e.setId(t,null,0),e}OnReposition(){if(this.isEquipTip){this.parent.SetReady(h.L.eGodModule)}else if((0,s.t2)(this.parent,r.b)){const t=this.parent
t.ReadyCnt_set(t.ReadyCnt_get()+1)}}Hide(){const t=this.node.transform.GetLocalPosition()
t.y=1e4,this.node.transform.SetLocalPosition(t),o.P.Recyle(t)}Destroy(){this.grid.Destroy(),this.grid=null}}},86676:(t,e,i)=>{i.d(e,{D:()=>h})
var s=i(6665),n=i(30849),l=i(85602),a=i(79534),o=i(7475),r=i(88838)
class h extends n.C{constructor(){super(),this.holyGrid=null,this.parent=null,this.isEquipTip=!0,this._degf_OnItemRefreshFun=null,this._degf_OnReposition=null,
this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),this._degf_OnReposition=()=>this.OnReposition()}ColorStr_get(){}InitView(){super.InitView(),this.holyGrid=new s.A,
this.holyGrid.setId(this.FatherId,this.FatherComponentID,1),this.holyGrid.SetInitInfo("ui_equiptip_legendattr",this._degf_OnItemRefreshFun),
this.holyGrid.OnReposition_set(this._degf_OnReposition)}SetData(t,e,i,s){null==s&&(s=!0),this.parent=i,this.isEquipTip=s
const n=new l.Z
if(t.IsAngelEquip()){}n.Count()>0?(this.node.SetActive(!0),this.holyGrid.data_set(n)):(this.node.SetActive(!1),this.OnReposition())}OnItemRefreshFun(t){const e=new r.G
return e.setId(t,null,0),e}OnReposition(){if(this.isEquipTip){this.parent.SetReady(o.L.eHolyModule)}else{const t=this.parent
t.ReadyCnt_set(t.ReadyCnt_get()+1)}}Hide(){const t=this.node.transform.GetLocalPosition()
t.y=1e4,this.node.transform.SetLocalPosition(t),a.P.Recyle(t)}Destroy(){this.holyGrid.Destroy(),this.holyGrid=null}}},76195:(t,e,i)=>{i.d(e,{F:()=>g})
var s=i(38045),n=i(97461),l=i(62370),a=i(70829),o=i(93877),r=i(30849),h=i(98885),d=i(79534),u=i(92679),c=i(87923),_=i(14140),I=i(99130),m=i(7475)
class g extends r.C{constructor(){super(),this.skillName=null,this.skillDesc=null,this.parent=null,this.isEquipTip=!0,this._degf_OnDescRefresh=null,
this._degf_OnDescRefresh=t=>this.OnDescRefresh(t)}InitView(){this.skillName=new o.Q,this.skillName.setId(this.FatherId,this.FatherComponentID,1),this.skillDesc=new o.Q,
this.skillDesc.setId(this.FatherId,this.FatherComponentID,2)}SetData(t,e,i,s){null==s&&(s=!0),this.parent=i,this.isEquipTip=s,this.RemoveLis()
let n=null
if(null!=e?n=e.addSkillId:c.l.IsEmptyStr(t.addskill)||(n=h.M.Split(t.addskill,l.o.s_UNDER_COLON)[0]),c.l.IsEmptyStr(n))this.node.SetActive(!1),this.OnReposition()
else{const t=a.j.Inst().GetSkillByStrId(n)
null!=t&&null!=t.desc&&""!=t.desc?(this.skillName.textSet(t.name),this.node.SetActive(!0),
I.x.inst.RegFormulaValue(t,this.skillDesc)?this.OnReposition():this.AddLis()):(this.node.SetActive(!1),this.OnReposition())}}Clear(){this.RemoveLis()}AddLis(){
n.i.Inst.AddEventHandler(u.g.QuerySkillFormulaValueUpdate,this._degf_OnDescRefresh)}RemoveLis(){
n.i.Inst.RemoveEventHandler(u.g.QuerySkillFormulaValueUpdate,this._degf_OnDescRefresh)}OnDescRefresh(t){t==this.skillDesc&&this.OnReposition()}Hide(){
const t=this.node.transform.GetLocalPosition()
t.y=1e4,this.node.transform.SetLocalPosition(t),d.P.Recyle(t)}OnReposition(){if(this.isEquipTip){this.parent.SetReady(m.L.eSkillModule)}else if((0,s.t2)(this.parent,_.b)){
const t=this.parent
t.ReadyCnt_set(t.ReadyCnt_get()+1)}}}},75390:(t,e,i)=>{i.d(e,{m:()=>C})
var s=i(93984),n=i(38836),l=i(86133),a=i(98958),o=i(6665),r=i(93877),h=i(30849),d=i(85602),u=i(38962),c=i(79534),_=i(70850),I=i(87923),m=i(33833),g=i(60606),p=i(88431)
class C extends h.C{constructor(){super(),this.grid=null,this.parent=null,this.isEquipTip=!0,this._degf_OnItemRefreshFun=null,this._degf_OnReposition=null,
this._degf_SortAttrData=null,this.titleLabel=null,this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),this._degf_OnReposition=()=>this.OnReposition(),
this._degf_SortAttrData=(t,e)=>this.SortAttrData(t,e)}InitView(){super.InitView(),this.grid=new o.A,this.grid.setId(this.FatherId,this.FatherComponentID,1),this.titleLabel=new r.Q,
this.titleLabel.setId(this.FatherId,this.FatherComponentID,2),this.grid.SetInitInfo("ui_equiptip_specialattr",this._degf_OnItemRefreshFun),
this.grid.OnReposition_set(this._degf_OnReposition)}SetData(t,e,i){null==i&&(i=!0),this.parent=e,this.isEquipTip=i
const o=new d.Z,r=new u.X
let h=null,c=null
if(null!=t.m_specialAtts_get()&&(c=t.m_specialAtts_get().Clone()),null!=c&&null!=c.attrs){"GUARD"==_.g.Inst_get().getItemresource(t.id).sign&&this.titleLabel.textSet((0,
l.T)("觉醒属性"))
for(const[t,e]of(0,n.V5)(c.attrs)){let t=""
2004==e.intType?t="":2005==e.intType?t="1/":2006==e.intType&&(t=(0,l.T)("等级/"))
const i=m.X.Inst().getItemById(e.intType)
2004!=e.intType&&2005!=e.intType&&2006!=e.intType?(h=`${i.tipPrefix}（${I.l.getAttrStrWithoutSign(e.intType)} +${I.l.getAttrValueStr(e.intType,e.value)}）`,
r.LuaDic_AddOrSetItem(e.intType,h)):(h=`${i.tipPrefix}（${I.l.getAttrStrWithoutSign(e.intType)} +${t}${I.l.getAttrValueStr(e.intType,e.value)}）`,r.LuaDic_AddOrSetItem(e.intType,h))}
}const p=new d.Z
for(const[t,e]of(0,n.vy)(r)){const e=new g.H
e.type=t,e.str=r[t],p.Add(e)}p.Sort(this._degf_SortAttrData)
let C=0
for(;C<p.Count();)o.Add(p[C].str),C+=1
if(t.canGrow){const t=`${(0,l.T)("成长（")}${a.V.Inst().getStr(10728,s.h.eLangResource)}）`
o.Add(t)}o.Count()>0?(this.node.SetActive(!0),this.grid.data_set(o)):(this.node.SetActive(!1),this.OnReposition())}SortAttrData(t,e){return t.type>e.type?1:t.type<e.type?-1:0}
OnItemRefreshFun(t){const e=new p.F
return e.setId(t,null,0),e}OnReposition(){}Hide(){const t=this.node.transform.GetLocalPosition()
t.y=1e4,this.node.transform.SetLocalPosition(t),c.P.Recyle(t)}Destroy(){this.grid.Destroy(),this.grid=null}}},78248:(t,e,i)=>{i.d(e,{q:()=>A})
var s=i(93984),n=i(38836),l=i(86133),a=i(97461),o=i(90419),r=i(98958),h=i(50089),d=i(30267),u=i(93877),c=i(30849),_=i(98885),I=i(85602),m=i(79534),g=i(75321),p=i(92679),C=i(52429),S=i(5268),f=i(35950),y=i(93137),v=i(53872),D=i(29714),E=i(7475),T=i(36529)
class A extends c.C{constructor(){super(),this.suitName=null,this.table=null,this.attrCount=0,this.partCount=0,this.suitCount=0,this.role=null,this.parent=null,this.isEquipTip=!0,
this.moduleProperty=-1,this.normalSuitIdTag=1,this._er=null,this._degf_OnItemRefreshFun=null,this._degf_OnItemUpdate=null,this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),
this._degf_OnItemUpdate=t=>this.OnItemUpdate(t)}InitView(){super.InitView(),this.suitName=new u.Q,this.suitName.setId(this.FatherId,this.FatherComponentID,1),this.table=new d.V,
this.table.setId(this.FatherId,this.FatherComponentID,2),this.table.SetInitInfo("ui_equiptip_suitattr",this._degf_OnItemRefreshFun)}AddLis(){
a.i.Inst.AddEventHandler(p.g.EQUIP_TIP_SUIT_MODULE_UPDATE,this._degf_OnItemUpdate)}SetData(t,e,i,s,l,a,o,r,h,d){null==h&&(h=!0),this.parent=r,this.isEquipTip=h,this.role=t,
this.moduleProperty=l,this._er=i
const u=new v.e
u.isTakeOnEquip=a,u.column=o,u.part=i.intPosition_get(),null!=s&&(u.stage=s.Stage_get())
let c=null,_=0,I=0,m=0,g=0,p=0,C=0
if(null!=s?(_=s.initSuitId,I=s.suitId,m=_,g=s.suitId,C=s.masterId):(null!=e&&null!=e.EquipShowConfig_get()&&(_=e.EquipShowConfig_get().suitId,I=_,m=_,g=_),
null!=e&&null!=e.Config_get()&&(C=0)),0!=m){if(c=S.H.Inst().getSuitById(m),null!=c){if(c.isAngelSuit&&(p=c.angelList[0],null!=s&&null!=s.id&&u.isTakeOnEquip))for(const[e,i]of(0,
n.V5)(c.angelList)){if(D.C.Inst_get().IsSuitActivated(t,i,u.column)){p=i
break}}c.universal&&(u.isCanChangeSuit=!0,u.isChangeSuit=!1,u.limitLevel=c.stepLimit)}u.isTakeOnEquip&&(u.isChangeSuit=!0),c=S.H.Inst().getSuitById(g)
const e=S.H.Inst().getSuitById(m),i=S.H.Inst().getSuitById(p)
if(l==f.n.eAngel)e.isAngelSuit&&null!=i?(g=p,u.isTakeOnEquip&&(u.isCanChangeSuit=!1)):g=e.keepSuit>0?e.keepSuit:0
else{let t=!1
if(null!=c&&(c.isMultiNormalSuit||c.overAll>0)&&(t=!0),null!=c&&c.keepSuit>0&&(g=0),l==f.n.eNormal)2==c.suitProperty&&(c.universal||(g=c.extraSuit)),
e.universal&&c.isAngelSuit&&(u.isChangeSuit=!1),t&&(g=0)
else if(l==f.n.eEnhance)2!=c.suitProperty?g=0:e.universal&&c.isAngelSuit&&(u.isChangeSuit=!1),t&&(g=0)
else if(l>=f.n.eSuitEnhance1){let t=0
if(null!=c&&c.isMultiNormalSuit){d<=s.activeMultiSuits.Count()?(g=s.activeMultiSuits[d-1],c=S.H.Inst().getSuitById(g),t=D.C.Inst_get().GetCurSuitCount(this.role,g)):g=0
}else null!=c&&c.overAll>0&&1==d?(g=c.overAll,c=S.H.Inst().getSuitById(g),t=D.C.Inst_get().GetCurSuitCount(this.role,g)):g=0
2==c.suitProperty&&(c.universal||(g=c.extraSuit)),e.universal&&c.isAngelSuit&&(u.isChangeSuit=!1)}e.isAngelSuit&&m==g&&(g=0)}}l==f.n.eMaster&&(g=C),c=S.H.Inst().getSuitById(g),
null!=c&&(u.config=c,u.level=c.suitLevel),null!=u.config?(this.node.SetActive(!0),this.setData(u)):(this.node.SetActive(!1),this.OnReposition())}setData(t){
const e=t.config.id,i=D.C.Inst_get()
let n="",a=!0
if(t.isCanChangeSuit){t.isChangeSuit||(a=!1)
let e=(0,l.T)("装备")
t.part>=g.C.NECKLACE&&(e=(0,l.T)("首饰"))
let i=0
const o=new I.Z
t.limitLevel>0?(i=10711,o.Add(_.M.IntToString(t.limitLevel))):i=1071001,o.Add(e),n=r.V.Inst().getStr(i,s.h.eLangResource,o)}const d=new I.Z
if(""!=n){const e=new y.w
e.suitConfig=t.config,e.changeSuitStr=n,d.Add(e)}if(a){this.attrCount=0
const s=new I.Z
s.Add(0),this.partCount=0
const n=S.H.Inst().getSuitAttrsBySuitId(e)
n.Count()>0&&(this.partCount=n[n.Count()-1].suitNum),i.GetSuitActivatedCount(this.role,t,this.partCount,s)
let l=0
for(;l<n.Count();){const e=new y.w
e.suitConfig=t.config,e.config=n[l],e.suitCount=s[0]
const i=o.d.parseJsonObjectWithFix(n[l].suitAttrs,"attrs")
e.attrs=h.t.decode(i,C.L),e.attrs.parse(),this.attrCount+=e.attrs.attrs.Count(),d.Add(e),l+=1}this.suitName.textSet(`[dbc0a1]${i.GetSuitNameWithLevel(t,s[0],this.partCount)}[-]`)
}else this.suitName.textSet(`[dbc0a1]${r.V.Inst().getStr2(10709)}[-]`)
this.table.data_set(d)}OnItemRefreshFun(t){const e=new T.c
return e.setId(t,null,0),e}OnItemUpdate(t){let e=!0
const i=this.table.itemList
let s=0
for(;s<i.Count();){const t=i[s]
if(t.node.activeSelf()&&0==t.IsReady_get()){e=!1
break}s+=1}e&&(this.table.Reposition(),this.OnReposition())}OnReposition(){if(null!=this.parent)if(this.isEquipTip){const t=this.parent
this.moduleProperty==f.n.eAngel?t.SetReady(E.L.eAngelSuitModule):this.moduleProperty==f.n.eMaster?t.SetReady(E.L.eMasterSuitModule):this.moduleProperty==f.n.eNormal?t.SetReady(E.L.eNormalSuitModule):this.moduleProperty==f.n.eEnhance?t.SetReady(E.L.eEnhanceSuitModule):this.moduleProperty==f.n.eSuitEnhance1?t.SetReady(E.L.eMultiSuitModule1):this.moduleProperty==f.n.eSuitEnhance2?t.SetReady(E.L.eMultiSuitModule2):this.moduleProperty==f.n.eSuitEnhance3?t.SetReady(E.L.eMultiSuitModule3):this.moduleProperty==f.n.eSuitEnhance4?t.SetReady(E.L.eMultiSuitModule4):this.moduleProperty==f.n.eSuitEnhance5&&t.SetReady(E.L.eMultiSuitModule5)
}else{const t=this.parent
t.ReadyCnt_set(t.ReadyCnt_get()+1)}}Clear(){a.i.Inst.RemoveEventHandler(p.g.EQUIP_TIP_SUIT_MODULE_UPDATE,this._degf_OnItemUpdate)}Hide(){
const t=this.node.transform.GetLocalPosition()
t.y=1e4,this.node.transform.SetLocalPosition(t),m.P.Recyle(t)}Destroy(){this.table.Destroy(),this.table=null}}},85174:(t,e,i)=>{i.d(e,{I:()=>S})
var s=i(86133),n=i(68662),l=i(5924),a=i(99294),o=i(6665),r=i(93877),h=i(30849),d=i(35128),u=i(98885),c=i(79534),_=i(59918),I=i(87923),m=i(48933),g=i(84141),p=i(68366),C=i(7475)
class S extends h.C{constructor(){super(),this.timeObj=null,this.grid=null,this.limitTimeLabel=null,this.deadlineLabel=null,this.limitTimeObj=null,this.deadlineObj=null,
this._auctionIntervalId=-1,this.auctionEndTimer=null,this._leftTimeIntervalId=-1,this._lefttime=0,this._deadlineIntervalId=-1,this.normalColor="[ffefe1]",
this.activeColor="[ffefe1]",this.inactiveColor="[fe2e2d]",this._cfg=null,this.isOverdue=!1,this.parent=null,this.isEquipTip=!0,this._degf_DeadlineCheck=null,
this._degf_LeftTimeChange=null,this._degf_OnReposition=null,this._degf_DeadlineCheck=()=>this.DeadlineCheck(),this._degf_LeftTimeChange=()=>this.LeftTimeChange(),
this._degf_OnReposition=()=>this.OnReposition()}IsOverdue_get(){return this.isOverdue}IsOverdue_set(t){if(this.isOverdue!=t&&(this.isOverdue=t,null!=this.parent&&this.isEquipTip)){
this.parent.btnModule.SetButtonState()}}InitView(){super.InitView(),this.timeObj=new a.z,this.timeObj.setId(this.FatherId,this.FatherComponentID,1),this.grid=new o.A,
this.grid.setId(this.FatherId,this.FatherComponentID,2),this.limitTimeLabel=new r.Q,this.limitTimeLabel.setId(this.FatherId,this.FatherComponentID,4),this.deadlineLabel=new r.Q,
this.deadlineLabel.setId(this.FatherId,this.FatherComponentID,5),this.limitTimeObj=new a.z,this.limitTimeObj.setId(this.FatherId,this.FatherComponentID,7),this.deadlineObj=new a.z,
this.deadlineObj.setId(this.FatherId,this.FatherComponentID,8),this.grid.OnReposition_set(this._degf_OnReposition)}SetData(t,e,i){null==i&&(i=!0)
const a=t.cfgEquipData_get()
this.isOverdue=!1,this.ClearTimer(),this._cfg=t.cfgData_get(),this.parent=e,this.isEquipTip=i,this.timeObj.SetActive(!1)
let o=null
if(a.equipType==_.R.GUARD||null==t.serverData_get()&&"0"==this._cfg.validTime||null!=t.serverData_get()&&(null==t.serverData_get().id||t.serverData_get().id.Equal(m.I.zeroLong)))this.deadlineLabel.textSet(""),
this.deadlineObj.SetActive(!1),this.limitTimeLabel.textSet(""),this.limitTimeObj.SetActive(!1)
else{if(null!=t.serverData_get())if(null==t.serverData_get().deprecatedTime||t.serverData_get().deprecatedTime.Equal(m.I.zeroLong))o=`${this.normalColor}${(0,s.T)("有效时间 ")}[-]`,
"0"==this._cfg.validTime||u.M.Contains(this._cfg.validTime,":")?(this.limitTimeLabel.textSet(""),this.limitTimeObj.SetActive(!1)):(this.timeObj.SetActive(!0),
this.limitTimeObj.SetActive(!0),o+=`${this.activeColor}${I.l.GetDateFormat(u.M.String2Double(this._cfg.validTime))}[-]`,this.limitTimeLabel.textSet(o))
else if("0"!=this._cfg.validTime&&u.M.Contains(this._cfg.validTime,":"))this.limitTimeLabel.textSet(""),this.limitTimeObj.SetActive(!1)
else{this.timeObj.SetActive(!0),this.limitTimeObj.SetActive(!0)
let e=t.serverData_get().deprecatedTime.ToNum()/1e3-n.D.serverTime_get()
e=d.p.CeilToInt(e),o=`${this.normalColor}${(0,s.T)("剩余使用时长 ")}[-]`,e>0?(this._lefttime=e,o=`${o}${this.activeColor}${I.l.GetDateFormat(this._lefttime)}[-]`,
this._leftTimeIntervalId=l.C.Inst_get().SetInterval(this._degf_LeftTimeChange,1e3)):(o=`${this.inactiveColor}${(0,s.T)("该物品已失效")}[-]`,this.IsOverdue_set(!0)),
this.limitTimeLabel.textSet(o)}"0"!=this._cfg.validTime&&u.M.Contains(this._cfg.validTime,":")?(this.timeObj.SetActive(!0),this.deadlineObj.SetActive(!0),
this._deadlineIntervalId=l.C.Inst_get().SetInterval(this._degf_DeadlineCheck,0)):(this.deadlineLabel.textSet(""),this.deadlineObj.SetActive(!1))}
this.limitTimeObj.activeSelf()||this.deadlineObj.activeSelf()?(this.timeObj.SetActive(!0),this.grid.Reposition()):(this.timeObj.SetActive(!1),this.ClearTimer(),this.OnReposition())
}OnReposition(){if(this.isEquipTip){this.parent.SetReady(C.L.eTimeModule)}else{const t=this.parent
t.ReadyCnt_set(t.ReadyCnt_get()+1)}}ClearTimer(){l.C.Inst_get().ClearInterval(this._auctionIntervalId),this._auctionIntervalId=-1,
l.C.Inst_get().ClearInterval(this._leftTimeIntervalId),this._leftTimeIntervalId=-1,l.C.Inst_get().ClearInterval(this._deadlineIntervalId),this._deadlineIntervalId=-1}
LeftTimeChange(){let t=`${this.normalColor}${(0,s.T)("剩余使用时长 ")}[-]`
this._lefttime-=1,this._lefttime<1?(t=`${this.inactiveColor}${(0,s.T)("该物品已失效")}[-]`,l.C.Inst_get().ClearInterval(this._leftTimeIntervalId),this._leftTimeIntervalId=-1,
this.IsOverdue_set(!0)):t+=`${this.activeColor}${I.l.GetDateFormat(this._lefttime)}[-]`,this.limitTimeLabel.textSet(t)}DeadlineCheck(){const t=g.E.New(n.D.serverMSTime_get())
let e=t.time_get()
let i=p.N.ServerDate_get().parse(this._cfg.validTime),a=`${this.normalColor}${(0,s.T)("有效期 ")}[-]`
i-e>=0?a+=`${this.activeColor}${I.l.GetDateTime(i)}[-]`:(a=`${this.inactiveColor}${(0,s.T)("该物品已失效")}[-]`,l.C.Inst_get().ClearInterval(this._deadlineIntervalId),
this._deadlineIntervalId=-1,this.IsOverdue_set(!0)),g.E.Recycle(t),e=null,i=null,this.deadlineLabel.textSet(a)}Hide(){const t=this.node.transform.GetLocalPosition()
t.y=1e4,this.node.transform.SetLocalPosition(t),c.P.Recyle(t)}Destroy(){null!=this.grid&&this.grid.Destroy()}}},87144:(t,e,i)=>{i.d(e,{Q:()=>ai})
var s=i(86133),n=i(98800),l=i(97461),a=i(9986),o=i(6665),r=i(57834),h=i(13113),d=i(61911),u=i(31222),c=i(98130),_=i(85602),I=i(72785),m=i(52212),g=i(79534),p=i(21554),C=i(70850),S=i(86770),f=i(15033),y=i(23628),v=i(92679),D=i(87923),E=i(44498),T=i(48933),A=i(33138),L=i(43308),w=i(29279),R=i(38836),O=i(43662),G=i(28236),b=i(5430),M=i(28475),P=i(45404),B=i(31546),x=i(70650),N=i(43133),k=i(93877),V=i(16261),F=i(30849),U=i(95721),H=i(38962),q=i(75321),Z=i(76466),j=i(33314),X=i(27122),Y=i(89799)
let W=null,$=null,J=null,z=null,Q=null,K=null,tt=null,et=null,it=null,st=null,nt=null,lt=null,at=null,ot=null,rt=null,ht=null,dt=null,ut=null,ct=null,_t=null,It=null,mt=null,gt=null,pt=null,Ct=null,St=null,ft=null,yt=null,vt=null,Dt=null,Et=null,Tt=null,At=null
class Lt extends F.C{static __StaticInit(){W=table.insert,$=table.sort,J=table.remove,z=_.Z.new,Q=_.Z.Add,K=_.Z.AddRang,tt=_.Z.Clear,et=_.Z.Contains,it=_.Z.Insert,
st=_.Z.InsertRange,nt=_.Z.Remove,lt=_.Z.RemoveAt,at=_.Z.IndexOf,ot=_.Z.Count,rt=_.Z.Length,ht=_.Z.RemoveRange,dt=_.Z.GetRange,ut=_.Z.Pop,ct=_.Z.Reverse,_t=_.Z.Sort,It=H.X.new,
mt=H.X.LuaDic_Add,gt=H.X.LuaDic_SetItem,pt=H.X.LuaDic_IsNullValue,Ct=H.X.LuaDic_GetItem,St=H.X.LuaDic_Count,ft=H.X.LuaDic_ContainsKey,yt=H.X.LuaDic_AddOrSetItem,vt=H.X.LuaDic_Keys,
Dt=H.X.LuaDic_Values,Et=H.X.LuaDic_Clear,Tt=H.X.LuaDic_ContainsValue,At=H.X.LuaDic_Remove}constructor(){super(),this.playerInfo=null,this.baseItemData=null,this.m_player=null,
this.roleRotateIndex=0,this._degf_InitModel=null,this._degf_OnAEvent=null,this.leftInfo=null,this.rotateController=null,this.roleTexture=null,this.closeBtn=null,
this.labelEquipScore=null,this.rInfo=null,this._degf_InitModel=t=>this.InitModel(t),this._degf_OnAEvent=()=>this.OnAEvent()}InitView(){super.InitView(),
this.leftInfo=this.CreateComponent(h.T,1),this.rotateController=this.CreateComponent(N.V,2),this.roleTexture=this.CreateComponent(V.X,3),this.closeBtn=this.CreateComponent(a.W,4),
this.labelEquipScore=this.CreateComponent(k.Q,5)}AddLis(){r.i.Get(this.closeBtn.node).RegistonClick(this.CreateDelegate(this.OnClickClose))}RemoveLis(){
r.i.Get(this.closeBtn.node).RemoveonClick(this.CreateDelegate(this.OnClickClose)),null!=this.m_player&&x.e.GetInst().UnregDrag(this.roleRotateIndex)}SetData(t,e){this.playerInfo=t,
this.baseItemData=e,this.AddLis(),this.ShowModel(),this.labelEquipScore.textSet(this.playerInfo.GetEquipScore())}Clear(){this.RemoveLis(),
null!=this.m_player&&null!=this.m_player.MainRole_get()&&(this.m_player.Destroy(),this.m_player=null)}OnClickClose(){this.node.SetActive(!1)}ShowModel(){
O.M.Instance_get().ActiveStage(Z.b.STAGE_ID)
const t=new B.O
this.rInfo=this.CopyRoleInfo(),t._displayID=j.Z.GetDisplayId(this.rInfo),t._world=O.M.Instance_get().GetStageWorldType(Z.b.STAGE_ID),t._vPos.Set(0,0),
null==this.m_player&&(this.m_player=X.Q.Inst().GetObjectByName("Role",M.u)),this.m_player.ShowRide_set(!1),this.m_player.wingstand=!0,this.m_player.isShowAni=!0,
this.m_player.initEnd=this._degf_InitModel,this.m_player.initByDisinfo(this.rInfo,t,!0),this.m_player.SetRolePosXYZ(0,0,0),this.m_player.SetDirection(0),
this.m_player.MainRole_get().DisableShadow(),this.m_player.SetAdditionEquipEff(),P.n.Instance_get().SetDisplayObject(Z.b.STAGE_ID,this.m_player.MainRole_get().handle,0),
this.roleTexture.SetMainTextureByPhoto(Z.b.STAGE_ID),null!=this.m_player&&(x.e.GetInst().UnregDrag(this.roleRotateIndex),
this.roleRotateIndex=x.e.GetInst().RegDrag(this.rotateController.node,this.m_player.MainRole_get()))}InitModel(t){const e=this.m_player.GetShowWeaponAni(!1)
this.m_player.MainRole_get().PassEvent(e,this._degf_OnAEvent)}OnAEvent(){if(null!=this.m_player&&null!=this.m_player.MainRole_get()){const t=this.m_player.GetAERootClip()
this.m_player.MainRole_get().PassEvent(t)}}CopyRoleInfo(){const t=new G.H
t.TitleId_set(this.playerInfo.TitleId_get()),t.AsuramId_set(this.playerInfo.AsuramId_get()),null==t.AsuramId_get()&&t.AsuramId_set(U.o.New(0,0)),
t.FightStage_set(this.playerInfo.FightStage_get()),t.Fashions_set(this.playerInfo.Fashions_get()),t.SacredEquipWearing_Set(this.playerInfo.SacredEquipWearing_Get()),
t.VipLevel_set(this.playerInfo.VipLevel_get()),t.DisplayId_set(this.playerInfo.DisplayId_get()),t.Job_set(this.playerInfo.Job_get()),t.Sex_set(this.playerInfo.Sex_get()),
t.Name_set(this.playerInfo.Name_get()),t.Level_set(this.playerInfo.Level_get()),t.equipmentStorageVO=new Y.U
for(const[e,i]of(0,R.V5)(this.playerInfo.equipmentStorageVO.equipmentVOs))t.equipmentStorageVO.equipmentVOs.LuaDic_AddOrSetItem(e,i)
const e=q.C.ALL_EQUIP_TYPE_DATA[q.C.GetEquipEnum(this.baseItemData.cfgEquipData_get().equipType)][1],i=b.Y.getEquipmentVo(this.baseItemData.serverData_get())
return t.equipmentStorageVO.equipmentVOs.LuaDic_AddOrSetItem(e,i),t}}var wt=i(9057),Rt=i(72005),Ot=i(96710)
class Gt extends wt.x{constructor(...t){super(...t),this.playerInfo=null,this.itemData=null,this.img_up=null,this.img_down=null,this.img_ban=null,this.img_select=null,
this.ui_comm_sprite_head=null}InitView(){super.InitView(),this.img_up=this.CreateComponent(Rt.w,2),this.img_down=this.CreateComponent(Rt.w,3),
this.img_ban=this.CreateComponent(Rt.w,4),this.img_select=this.CreateComponent(Rt.w,5),this.ui_comm_sprite_head=this.CreateComponentBinder(Ot.I,6)}SetData(t){this.playerInfo=t,
this.itemData=INS.itemTipManager.tipData,this.AddLis(),this.img_up.node.SetActive(!1),this.img_down.node.SetActive(!1),this.img_ban.node.SetActive(!1)
const e=y.b.GetUpScoreForRole(this.playerInfo,this.itemData,!0)
e>0?this.img_up.node.SetActive(!0):e<0&&this.img_down.node.SetActive(!0),this.ui_comm_sprite_head.SetHeadIcon(this.playerInfo.Job_get(),this.playerInfo.Sex_get(),!1),
this.UpdateSelect()}Clear(){this.RemoveLis()}AddLis(){this.ui_comm_sprite_head.onClick=this.CreateDelegate(this.OnClick),
l.i.Inst.AddEventHandler(v.g.EQUIP_TIP_SELECT_LEFT_ROLE,this.CreateDelegate(this.UpdateSelect))}RemoveLis(){this.ui_comm_sprite_head.onClick=null,
this.ui_comm_sprite_head.Destory(),l.i.Inst.RemoveEventHandler(v.g.EQUIP_TIP_SELECT_LEFT_ROLE,this.CreateDelegate(this.UpdateSelect))}UpdateSelect(){
null!=INS.itemTipManager.selectTipRole&&INS.itemTipManager.selectTipRole.Id_get().Equal(this.playerInfo.Id_get())?this.img_select.node.SetActive(!0):this.img_select.node.SetActive(!1)
}OnClick(){null!=INS.itemTipManager.selectTipRole&&INS.itemTipManager.selectTipRole.Id_get().Equal(this.playerInfo.Id_get())||(INS.itemTipManager.selectTipRole=this.playerInfo,
l.i.Inst.RaiseEvent(v.g.EQUIP_TIP_SELECT_LEFT_ROLE))}}
var bt=i(5924),Mt=i(99294),Pt=i(9776),Bt=i(8889),xt=i(18202),Nt=i(83540),kt=i(78300),Vt=i(35128),Ft=i(98885),Ut=i(44758),Ht=i(70093),qt=i(59918),Zt=i(76645),jt=i(71143),Xt=i(35950),Yt=i(75439),Wt=i(68561),$t=i(99130),Jt=i(7475)
class zt extends wt.x{SetData(t){}InitView(){super.InitView()}Clear(){super.Clear()}Destroy(){super.Destroy()}}var Qt=i(38045),Kt=i(33833),te=i(88431)
class ee extends F.C{constructor(...t){super(...t),this.timeLabel=null,this.bar=null,this._totalValue=0,this._currentValue=-1,this._showLabel=!0,this.bgBar=null,
this._updateTimeIntervalId=-1,this._enabledLoop=!1,this._loopCall=null,this._width=224,this._uiWidth=224}InitView(){super.InitView(),this.timeLabel=this.CreateComponent(k.Q,1),
this.bar=this.CreateComponent(Rt.w,2),this.bgBar=this.CreateComponent(Rt.w,3)}SetTotalTime(t){this._totalValue=t,-1!=this._currentValue&&(this._currentValue=this._totalValue),
this._UpdateProgress()}SetTimeLabelVisible(t){this.timeLabel.node.SetActive(t)}SetBarWidth(t){this._width=t,this.bgBar.widthSet(t),this.timeLabel.widthSet(t)
const e=this.timeLabel.node.transform.GetLocalPosition()
e.x=(this._width-this._uiWidth)/2,this.timeLabel.node.transform.SetLocalPosition(e)}SetCurrentTime(t){this._currentValue=t,this._UpdateProgress(),
this.SetEnabledLoop(this._enabledLoop)}_UpdateProgress(){0!=this._totalValue&&(this._currentValue<=0?(this.timeLabel.node&&this.timeLabel.textSet(0),
this.bar.node.SetActive(!1)):(this.bar.node.SetActive(!0),this.timeLabel.node&&this.timeLabel.textSet(D.l.GetDateFormat(this._currentValue,!1,!1)),
this.bar.widthSet(this._currentValue/this._totalValue*this._width)))}SetEnabledLoop(t){this._enabledLoop=t,this._ClearLoop(),
t&&(this._updateTimeIntervalId=bt.C.Inst_get().SetInterval(this.CreateDelegate(this._LoopTime),1e3))}SetLoopCall(t){this._loopCall=t}_LoopTime(){this._currentValue-=1,
this._currentValue<=0&&this._ClearLoop(),this._UpdateProgress(),null!=this._loopCall&&this._loopCall(this._currentValue)}_ClearLoop(){
-1!=this._updateTimeIntervalId&&bt.C.Inst_get().ClearInterval(this._updateTimeIntervalId),this._updateTimeIntervalId=-1}Clear(){super.Clear(),this._ClearLoop()}Destroy(){
this.Clear(),this._loopCall=null,super.Destroy()}}class ie extends F.C{constructor(...t){super(...t),this.grid=null,this.baseObj=null,this.timeTipLabel=null,
this.ui_equip_time_progress=null,this.remainTime=0,this.equipCfg=null,this.star=0,this.totalTime=0,this.equipment=null}InitView(){super.InitView(),this.InitHandlerMgr(),
this.grid=this.CreateComponent(o.A,1),this.baseObj=this.CreateComponent(k.Q,2),this.timeTipLabel=this.CreateComponent(k.Q,5),
this.ui_equip_time_progress=this.CreateComponentBinder(ee,6),this.grid.SetInitInfo("ui_equiptip_commonattr_center",this.CreateDelegate(this.OnCreateAttrItem))}SetData(t,e,i,s){
if(this.ui_equip_time_progress.Clear(),e.equipType!=qt.R.GUARD)return void this.node.SetActive(!1)
this.m_handlerMgr.AddEventMgr(v.g.GUARD_EQUIPMENT_TIME_UPDATE,this.CreateDelegate(this.OnUpdateGuardTime)),this.equipCfg=e,this.node.SetActive(!0)
const n=t.cfgData_get()
this.equipment=i,this.totalTime=(0,Qt.aI)(n.validTime),this.ui_equip_time_progress.SetTotalTime(this.totalTime),null==i?this.ShowUnActiveView():this.SetBaseData(i)}
OnUpdateGuardTime(t){null!=this.equipment&&this.SetBaseData(this.equipment)}SetBaseData(t){const e=t.GetRemainTime()
this.ui_equip_time_progress.SetCurrentTime(e),-1==e?this.ShowUnActiveView():0==e?this.ShowExpireView():this.ShowActiveView()}ShowUnActiveView(){
this.ui_equip_time_progress.SetEnabledLoop(!1),this.ui_equip_time_progress.SetCurrentTime(this.totalTime),this.ShowActiveTextTip(),this.ShowAttr(!0)}ShowExpireView(){
this.baseObj.textSet(`${(0,s.T)("附加效果")}[d43e3e]（已失效）[-]`),this.timeTipLabel.textSet((0,s.T)("附加效果失效,可用[5fb470]时间沙漏[-]回复")),this.ShowAttr(!1)}ShowActiveView(){
this.ui_equip_time_progress.SetEnabledLoop(!0),this.ui_equip_time_progress.SetLoopCall(this.CreateDelegate(this.LoopTime)),this.ShowActiveTextTip(),this.ShowAttr(!0)}
ShowActiveTextTip(){this.baseObj.textSet((0,s.T)("附加效果")),this.timeTipLabel.textSet((0,s.T)("有效时长为[5fb470]")+(D.l.GetDateFormat(this.totalTime,!1,!1)+((0,s.T)("[-],")+(0,
s.T)("可用[5fb470]时间沙漏[-]回复"))))}ShowAttr(t){let e=""
e=t?"[5fb470]":"[968f87]"
const i=this.equipCfg.id,s=null.Inst().GetByItemIdAndStar(i,this.star),n=new _.Z,l=s.extraAttrList
let a=null,o=null
for(let t=0;t<=l.Count()-1;t++)a=l[t],o=Kt.X.Inst().getItemByName(a.type),n.Add(`${e}${o.name} ${D.l.getAttrValueStr(o.id,a.value)}[-]`)
const r=this.timeTipLabel.node.transform.GetLocalPosition()
r.y=-(70+n.Count()*this.grid.cellHeight()),this.timeTipLabel.node.transform.SetLocalPosition(r),this.grid.data_set(n)}LoopTime(t){
t<=0&&this.ShowExpireView(this.equipCfg.id,this.star)}Hide(){const t=this.node.transform.GetLocalPosition()
t.y=1e4,this.node.transform.SetLocalPosition(t),g.P.Recyle(t),null!=this.ui_equip_time_progress&&this.ui_equip_time_progress.Clear()}Destroy(){super.Destroy(),
null!=this.ui_equip_time_progress&&this.ui_equip_time_progress.Destroy()}OnCreateAttrItem(t){const e=new te.F
return e.setId(t,null,0),e}}
var se=i(80891),ne=i(91959),le=i(11751),ae=i(93984),oe=i(61033),re=i(98958),he=i(38935),de=i(62370),ue=i(66788),ce=i(86290),_e=i(85682),Ie=i(37142),me=i(52726),ge=i(33854),pe=i(79996),Ce=i(84485),Se=i(75237),fe=i(80062),ye=i(77477),ve=i(74045),De=i(39879),Ee=i(49067),Te=i(1740),Ae=i(57035),Le=i(37648),we=i(55492),Re=i(30421),Oe=(i(1143),
i(59844)),Ge=i(22662),be=i(94998),Me=i(65550),Pe=i(39043),Be=i(85942)
class xe extends F.C{constructor(){super(),this.btn=null,this.label=null,this.UIId=0,this.linkItem=null,this._degf_OnBtnClick=null,this._degf_OnBtnClick=(t,e)=>this.OnBtnClick(t,e)
}InitView(){this.btn=new a.W,this.btn.setId(this.FatherId,this.FatherComponentID,1),this.label=new k.Q,this.label.setId(this.FatherId,this.FatherComponentID,2)}SetData(t,e,i){
this.label.textSet(t),this.UIId=Ft.M.String2Int(e),r.i.Get(this.btn.node).RegistonClick(this._degf_OnBtnClick),this.linkItem=i}SetSize(t,e){
UIButtonColorBridge.SetSize(this.btn.FatherId,this.btn.ComponentId,t,e)}Destroy(){this.btn=null,this.label=null}Clear(){r.i.Get(this.btn.node).RemoveonClick(this._degf_OnBtnClick),
this.linkItem=null}OnBtnClick(t,e){p.J.Inst_get().openOrClose(),u.N.inst.OpenUIByShortCutID(this.UIId)}}class Ne extends F.C{constructor(){super(),this.btnObj=null,
this.btnGrid=null,this.moreBtn=null,this.moreGrid=null,this.moreCollider=null,this.moreObj=null,this.moreSp=null,this.moreBg=null,this.sellBtn=null,this.wearBtn=null,
this.takeOffBtn=null,this.auctionBtn=null,this.getOutBtn=null,this.backBagBtn=null,this.chargeBtn=null,this.tradeBtn=null,this.composeBtn=null,this.bagToWarehouseBtn=null,
this.warehouseToBagBtn=null,this.toGuildDonateBtn=null,this.renewBtn=null,this.guardPrice=null,this.sellMarketBtn=null,this.retakeOnBtn=null,this.obtainWayBtn=null,
this.accessForJobBtn=null,this.scoreSellBtn=null,this.rebuyBtn=null,this.allianceExchangeBtn=null,this.usingObj=null,this.enhanceBtn=null,this.composeInBtn=null,
this.extendBtns=null,this.extendBList=null,this.moreSpRotation=null,this.btnList=null,this.btnShowState=null,this.isMoreClosing=!1,this.btnShowCnt=0,this.isCanOperate=!1,
this.ir=null,this.er=null,this.eInfo=null,this.equipment=null,this.itemData=null,this.bagItemData=null,this.parent=null,this.excellenceCnt=0,this.star=0,
this._degf_CloseTipView=null,this._degf_BackBagBtnClick=null,this._degf_BagToWarehouseBtnClick=null,this._degf_ChargeBtnClick=null,this._degf_CloseMore=null,
this._degf_OnAccessForJobBtnClick=null,this._degf_OnAuctionBtnClick=null,this._degf_OnComposeBtnClick=null,this._degf_OnGetOutBtnClick=null,
this._degf_OnImmediatelyWearBtnClick=null,this._degf_OnReWearBtnClick=null,this._degf_OnSellBtnClick=null,this._degf_OnTakeOffBtnClick=null,this._degf_OnWearBtnClick=null,
this._degf_OpenBagView=null,this._degf_QuickToAllianceWarehouse=null,this._degf_RebuyBtnClick=null,this._degf_RenewBtnClick=null,this._degf_ResetClosingState=null,
this._degf_ScoreSellBtnClick=null,this._degf_SellMarketBtnClick=null,this._degf_ShowMore=null,this._degf_TradeBtnClick=null,this._degf_WarehouseToBagBtnClick=null,
this._degf_WearEquipHandler=null,this._degf_OnGetWayBtnClick=null,this._degf_ConfirmAddPoint=null,this._degf_DoWearEquip=null,this._degf_EnhanceBtnClick=null,
this._degf_ComposeInBtnClick=null,this._degf_OnModelBtnClick=null,this._degf_ComposeCancelCheckInHandler=null,this._degf_ComposeCheckInHandler=null,
this._degf_OnClickAddTimeBtn=null,this.immediatelyWearBtn=null,this.modelBtn=null,this.addTimeBtn=null,this.closeMoreInterval=null,this.hasRegisterGuide=null,this.role=null,
this.extendBList=new _.Z,this.moreSpRotation=new g.P(0,180,180),this.btnList=new _.Z,this.btnShowState=new _.Z,this._degf_CloseTipView=t=>this.CloseTipView(t),
this._degf_BackBagBtnClick=(t,e)=>this.BackBagBtnClick(t,e),this._degf_BagToWarehouseBtnClick=(t,e)=>this.BagToWarehouseBtnClick(t,e),
this._degf_ChargeBtnClick=(t,e)=>this.ChargeBtnClick(t,e),this._degf_CloseMore=(t,e)=>this.CloseMore(t,e),this._degf_OnAccessForJobBtnClick=(t,e)=>this.OnAccessForJobBtnClick(t,e),
this._degf_OnAuctionBtnClick=(t,e)=>this.OnAuctionBtnClick(t,e),this._degf_OnComposeBtnClick=(t,e)=>this.OnComposeBtnClick(t,e),
this._degf_OnGetOutBtnClick=(t,e)=>this.OnGetOutBtnClick(t,e),this._degf_OnImmediatelyWearBtnClick=(t,e)=>this.OnImmediatelyWearBtnClick(t,e),
this._degf_OnReWearBtnClick=(t,e)=>this.OnReWearBtnClick(t,e),this._degf_OnSellBtnClick=(t,e)=>this.OnSellBtnClick(t,e),
this._degf_OnTakeOffBtnClick=(t,e)=>this.OnTakeOffBtnClick(t,e),this._degf_OnWearBtnClick=(t,e)=>this.OnWearBtnClick(t,e),this._degf_OpenBagView=t=>this.OpenBagView(t),
this._degf_QuickToAllianceWarehouse=(t,e)=>this.QuickToAllianceWarehouse(t,e),this._degf_RebuyBtnClick=(t,e)=>this.RebuyBtnClick(t,e),
this._degf_RenewBtnClick=(t,e)=>this.RenewBtnClick(t,e),this._degf_ResetClosingState=()=>this.ResetClosingState(),this._degf_ScoreSellBtnClick=(t,e)=>this.ScoreSellBtnClick(t,e),
this._degf_SellMarketBtnClick=(t,e)=>this.SellMarketBtnClick(t,e),this._degf_ShowMore=(t,e)=>this.ShowMore(t,e),this._degf_TradeBtnClick=(t,e)=>this.TradeBtnClick(t,e),
this._degf_WarehouseToBagBtnClick=(t,e)=>this.WarehouseToBagBtnClick(t,e),this._degf_WearEquipHandler=t=>this.WearEquipHandler(t),
this._degf_OnGetWayBtnClick=(t,e)=>this.OnGetWayBtnClick(t,e),this._degf_ConfirmAddPoint=t=>this.ConfirmAddPoint(t),this._degf_DoWearEquip=t=>this.DoWearEquip(t),
this._degf_EnhanceBtnClick=(t,e)=>this.DoEnhanceEquip(t,e),this._degf_ComposeInBtnClick=(t,e)=>this.OnSComposeInBtnClick(t,e),
this._degf_OnModelBtnClick=(t,e)=>this.OnModelBtnClick(t,e),this._degf_ComposeCancelCheckInHandler=t=>this.ComposeCancelCheckInHandler(t),
this._degf_ComposeCheckInHandler=t=>this.ComposeCheckInHandler(t),this._degf_OnClickAddTimeBtn=t=>this.OnClickAddTimeBtn(t)}InitView(){super.InitView(),
this.btnObj=this.CreateComponent(Mt.z,1),this.btnGrid=this.CreateComponent(o.A,2),this.moreBtn=this.CreateComponent(a.W,3),this.moreGrid=this.CreateComponent(o.A,4),
this.moreCollider=this.CreateComponent(N.V,5),this.moreObj=this.CreateComponent(Mt.z,6),this.moreSp=this.CreateComponent(ce.G,7),this.moreBg=this.CreateComponent(Rt.w,8),
this.sellBtn=this.CreateComponent(a.W,9),this.wearBtn=this.CreateComponent(a.W,10),this.takeOffBtn=this.CreateComponent(a.W,11),this.auctionBtn=this.CreateComponent(a.W,12),
this.getOutBtn=this.CreateComponent(a.W,13),this.backBagBtn=this.CreateComponent(a.W,14),this.chargeBtn=this.CreateComponent(a.W,15),this.tradeBtn=this.CreateComponent(a.W,16),
this.composeBtn=this.CreateComponent(a.W,17),this.bagToWarehouseBtn=this.CreateComponent(a.W,18),this.warehouseToBagBtn=this.CreateComponent(a.W,19),
this.toGuildDonateBtn=this.CreateComponent(a.W,20),this.renewBtn=this.CreateComponent(a.W,21),this.guardPrice=this.CreateComponent(k.Q,22),
this.sellMarketBtn=this.CreateComponent(a.W,23),this.retakeOnBtn=this.CreateComponent(a.W,24),this.obtainWayBtn=this.CreateComponent(a.W,25),
this.accessForJobBtn=this.CreateComponent(a.W,26),this.scoreSellBtn=this.CreateComponent(a.W,27),this.rebuyBtn=this.CreateComponent(a.W,28),
this.immediatelyWearBtn=this.CreateComponent(a.W,33),this.usingObj=this.CreateComponent(Mt.z,34),this.enhanceBtn=this.CreateComponent(a.W,35),
this.composeInBtn=this.CreateComponent(a.W,36),this.modelBtn=this.CreateComponent(a.W,37),this.addTimeBtn=this.CreateComponent(a.W,38),this.btnList.Add(this.renewBtn),
this.btnList.Add(this.wearBtn),this.btnList.Add(this.retakeOnBtn),this.btnList.Add(this.rebuyBtn),this.btnList.Add(this.takeOffBtn),this.btnList.Add(this.enhanceBtn),
this.btnList.Add(this.chargeBtn),this.btnList.Add(this.getOutBtn),this.btnList.Add(this.backBagBtn),this.btnList.Add(this.composeBtn),this.btnList.Add(this.toGuildDonateBtn),
this.btnList.Add(this.sellBtn),this.btnList.Add(this.sellMarketBtn),this.btnList.Add(this.tradeBtn),this.btnList.Add(this.scoreSellBtn),this.btnList.Add(this.auctionBtn),
this.btnList.Add(this.bagToWarehouseBtn),this.btnList.Add(this.warehouseToBagBtn),this.btnList.Add(this.addTimeBtn),this.btnList.Add(this.obtainWayBtn),
this.btnList.Add(this.immediatelyWearBtn),this.btnList.Add(this.accessForJobBtn),this.btnList.Add(this.composeInBtn),this.btnList.Add(this.modelBtn)
let t=0
for(;t<this.btnList.Count();)this.btnShowState.Add(!1),t+=1}OnAddToScene(){}SetData(t,e,i,n,l,a,o,r){this.btnShowCnt=0,this.eInfo=t,this.itemData=e,this.bagItemData=i,this.er=n,
this.ir=l,this.equipment=a,this.parent=o,this.isCanOperate=r,this.AddExtendBtn()
let h=0
for(;h<this.btnList.Count();)this.btnShowState[h]=!1,h+=1
let d=this.btnList.Count()-1
for(;d>=0;)this.btnList[d].node.transform.SetParent(this.parent.node.FatherId,this.parent.node.ComponentId),d-=1
let u=this.btnList.Count()-1
for(;u>=0;)this.btnList[u].node.transform.SetParent(this.btnGrid.FatherId,this.btnGrid.ComponentId),u-=1
this.SetBtnShowState(this.obtainWayBtn,!0)
const c=this.GetBtnShowIndex(this.obtainWayBtn);-1!=c&&this.btnList[c].node.transform.SetParent(this.moreGrid.FatherId,this.moreGrid.ComponentId),this.btnObj.SetActive(!1),
this.moreObj.SetActive(!1),180==this.moreSpRotation.y&&180==this.moreSpRotation.z||ue.Y.LogError((0,s.T)("更多按钮图标旋转值被修改~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")),
this.moreSp.SetLocalEulerAngles(this.moreSpRotation)
const _=this.moreSp.GetLocalEulerAngles()
180==_.y&&180==_.z||ue.Y.LogError((0,s.T)("更多按钮图标旋转角度赋值后不对~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")),this.isMoreClosing=!1,
bt.C.Inst_get().ClearInterval(this.closeMoreInterval),this.closeMoreInterval=-1,this.SetBtnShowState(this.obtainWayBtn,!1),
this.excellenceCnt=Wt.X.Inst_get().GetEquipExcellenceCount(this.equipment,this.eInfo),this.star=Wt.X.Inst_get().GetEquipStarLevel(this.equipment,this.eInfo),
e.previewNextEquipNum>0&&(this.excellenceCnt+=e.previewNextEquipNum,this.star+=e.previewNextEquipNum),this.SetButtonState()}UpdateItemData(t,e){this.itemData=t,this.bagItemData=e}
Clear(){if(this.itemData=null,this.bagItemData=null,this.hasRegisterGuide&&(this.hasRegisterGuide=!1),null!=this.extendBtns)for(const[t,e]of(0,R.vy)(this.extendBtns)){
const e=this.extendBtns[t]
e.Clear(),this.extendBtns[t]=null,this.extendBList.Add(e)}bt.C.Inst_get().ClearInterval(this.closeMoreInterval),this.closeMoreInterval=-1,this.RemoveLis()}AddLis(){
r.i.Get(this.sellBtn.node).RegistonClick(this._degf_OnSellBtnClick),r.i.Get(this.wearBtn.node).RegistonClick(this._degf_OnWearBtnClick),
r.i.Get(this.retakeOnBtn.node).RegistonClick(this._degf_OnReWearBtnClick),r.i.Get(this.takeOffBtn.node).RegistonClick(this._degf_OnTakeOffBtnClick),
r.i.Get(this.auctionBtn.node).RegistonClick(this._degf_OnAuctionBtnClick),r.i.Get(this.obtainWayBtn.node).RegistonClick(this._degf_OnGetWayBtnClick),
r.i.Get(this.getOutBtn.node).RegistonClick(this._degf_OnGetOutBtnClick),r.i.Get(this.backBagBtn.node).RegistonClick(this._degf_BackBagBtnClick),
r.i.Get(this.chargeBtn.node).RegistonClick(this._degf_ChargeBtnClick),r.i.Get(this.tradeBtn.node).RegistonClick(this._degf_TradeBtnClick),
r.i.Get(this.scoreSellBtn.node).RegistonClick(this._degf_ScoreSellBtnClick),r.i.Get(this.moreCollider.node).RegistonClick(this._degf_CloseMore),
r.i.Get(this.moreBtn.node).RegistonClick(this._degf_ShowMore),r.i.Get(this.composeBtn.node).RegistonClick(this._degf_OnComposeBtnClick),
r.i.Get(this.bagToWarehouseBtn.node).RegistonClick(this._degf_BagToWarehouseBtnClick),r.i.Get(this.warehouseToBagBtn.node).RegistonClick(this._degf_WarehouseToBagBtnClick),
r.i.Get(this.toGuildDonateBtn.node).RegistonClick(this._degf_QuickToAllianceWarehouse),r.i.Get(this.renewBtn.node).RegistonClick(this._degf_RenewBtnClick),
r.i.Get(this.sellMarketBtn.node).RegistonClick(this._degf_SellMarketBtnClick),r.i.Get(this.immediatelyWearBtn.node).RegistonClick(this._degf_OnImmediatelyWearBtnClick),
r.i.Get(this.accessForJobBtn.node).RegistonClick(this._degf_OnAccessForJobBtnClick),r.i.Get(this.rebuyBtn.node).RegistonClick(this._degf_RebuyBtnClick),
r.i.Get(this.enhanceBtn.node).RegistonClick(this._degf_EnhanceBtnClick),r.i.Get(this.composeInBtn.node).RegistonClick(this._degf_ComposeInBtnClick),
r.i.Get(this.modelBtn.node).RegistonClick(this._degf_OnModelBtnClick),r.i.Get(this.addTimeBtn.node).RegistonClick(this._degf_OnClickAddTimeBtn)}RemoveLis(){
r.i.Get(this.sellBtn.node).RemoveonClick(this._degf_OnSellBtnClick),r.i.Get(this.wearBtn.node).RemoveonClick(this._degf_OnWearBtnClick),
r.i.Get(this.retakeOnBtn.node).RemoveonClick(this._degf_OnReWearBtnClick),r.i.Get(this.takeOffBtn.node).RemoveonClick(this._degf_OnTakeOffBtnClick),
r.i.Get(this.auctionBtn.node).RemoveonClick(this._degf_OnAuctionBtnClick),r.i.Get(this.obtainWayBtn.node).RemoveonClick(this._degf_OnGetWayBtnClick),
r.i.Get(this.getOutBtn.node).RemoveonClick(this._degf_OnGetOutBtnClick),r.i.Get(this.backBagBtn.node).RemoveonClick(this._degf_BackBagBtnClick),
r.i.Get(this.chargeBtn.node).RemoveonClick(this._degf_ChargeBtnClick),r.i.Get(this.tradeBtn.node).RemoveonClick(this._degf_TradeBtnClick),
r.i.Get(this.scoreSellBtn.node).RemoveonClick(this._degf_ScoreSellBtnClick),r.i.Get(this.moreCollider.node).RemoveonClick(this._degf_CloseMore),
r.i.Get(this.moreBtn.node).RemoveonClick(this._degf_ShowMore),r.i.Get(this.composeBtn.node).RemoveonClick(this._degf_OnComposeBtnClick),
r.i.Get(this.bagToWarehouseBtn.node).RemoveonClick(this._degf_BagToWarehouseBtnClick),r.i.Get(this.warehouseToBagBtn.node).RemoveonClick(this._degf_WarehouseToBagBtnClick),
r.i.Get(this.toGuildDonateBtn.node).RemoveonClick(this._degf_QuickToAllianceWarehouse),r.i.Get(this.renewBtn.node).RemoveonClick(this._degf_RenewBtnClick),
r.i.Get(this.sellMarketBtn.node).RemoveonClick(this._degf_SellMarketBtnClick),r.i.Get(this.immediatelyWearBtn.node).RemoveonClick(this._degf_OnImmediatelyWearBtnClick),
r.i.Get(this.accessForJobBtn.node).RemoveonClick(this._degf_OnAccessForJobBtnClick),r.i.Get(this.rebuyBtn.node).RemoveonClick(this._degf_RebuyBtnClick),
r.i.Get(this.enhanceBtn.node).RemoveonClick(this._degf_EnhanceBtnClick),r.i.Get(this.composeInBtn.node).RemoveonClick(this._degf_ComposeInBtnClick),
r.i.Get(this.modelBtn.node).RemoveonClick(this._degf_OnModelBtnClick),r.i.Get(this.addTimeBtn.node).RemoveonClick(this._degf_OnClickAddTimeBtn)}SetButtonState(){let t=!1
if(null!=this.equipment){const e=this.itemData.GetRoleInfo().GetEquipmentsByColumn()
if(null!=e&&null!=e.equipmentsGet()){let i=0
for(;i<e.equipmentsGet().Count();){if(null!=e.equipmentsGet()[i]&&e.equipmentsGet()[i].id.Equal(this.equipment.id)){t=!0
break}i+=1}}}this.usingObj.SetActive(t),this.btnShowCnt=0
Le.P.Inst_get()
if(p.J.Inst_get().isJudgeItemTipOperate&&this.isCanOperate&&this.itemData.isCanOperate){
this.SetBtnShowState(this.wearBtn,!C.g.Inst_get().warehouseShow&&this.itemData.isForBag&&!this.parent.timeModule.IsOverdue_get()&&!t&&!this.itemData.isLotteryBag&&!this.itemData.isLotteryShop&&!this.itemData.isBagWarehouseData&&C.g.Inst_get().viewType_get()==S.D.bagTab),
this.SetBtnShowState(this.takeOffBtn,!C.g.Inst_get().warehouseShow&&t&&!this.itemData.isLotteryBag&&!this.itemData.isLotteryShop&&!this.itemData.isBagWarehouseData),
this.SetBtnShowState(this.enhanceBtn,!1),this.SetBtnShowState(this.obtainWayBtn,!t&&C.g.Inst_get().CheckHasGetway(this.itemData)),
this.SetBtnShowState(this.retakeOnBtn,!C.g.Inst_get().warehouseShow&&t&&!this.itemData.isLotteryBag&&!this.itemData.isLotteryShop&&!this.itemData.isBagWarehouseData&&!this.equipment.isEffective&&this.er.equipType!=qt.R.GUARD),
this.SetBtnShowState(this.immediatelyWearBtn,!this.itemData.isForBag&&!this.parent.timeModule.IsOverdue_get()&&!t&&!this.itemData.isLotteryBag&&!this.itemData.isLotteryShop&&!this.itemData.isBagWarehouseData&&this.itemData.isShowImmediatelyWearBtn),
this.SetBtnShowState(this.accessForJobBtn,this.itemData.isShowTransferAccessBtn),this.sellBtn.node.SetActive(!1),
this.SetBtnShowState(this.getOutBtn,this.itemData.btnType==Ht.p.ExtendBag&&!this.itemData.isLotteryBag&&!this.itemData.isLotteryShop&&!this.itemData.isBagWarehouseData),
this.SetBtnShowState(this.backBagBtn,this.itemData.isLotteryBag),this.SetBtnShowState(this.chargeBtn,this.itemData.isLotteryShop),
this.SetBtnShowState(this.composeBtn,!C.g.Inst_get().warehouseShow&&0!=this.ir.GetComposeID()&&this.itemData.isForBag),
this.SetBtnShowState(this.bagToWarehouseBtn,C.g.Inst_get().warehouseShow&&null!=this.bagItemData&&0==this.bagItemData.type_get()&&0!=this.itemData.cfgData_get().storage),
this.SetBtnShowState(this.warehouseToBagBtn,C.g.Inst_get().warehouseShow&&null!=this.bagItemData&&1==this.bagItemData.type_get())
const e=0
this.er.equipType,qt.R.GUARD,this.SetBtnShowState(this.rebuyBtn,!C.g.Inst_get().warehouseShow&&this.itemData.isForBag&&!this.itemData.isLotteryBag&&!this.itemData.isLotteryShop&&!this.itemData.isBagWarehouseData&&this.parent.timeModule.IsOverdue_get()&&this.er.equipType==qt.R.GUARD),
this.SetBtnShowState(this.renewBtn,!C.g.Inst_get().warehouseShow&&null!=this.bagItemData&&this.bagItemData.baseData_get().isPastDue_get()&&0!=e&&1!=this.bagItemData.type_get())
Ft.M.IntToString(this.ir.equipStepLv),de.o.s_UNDER_CHAR,Ft.M.IntToString(this.er.intPosition_get()),de.o.s_UNDER_CHAR,Ft.M.IntToString(this.star)
if(this.SetBtnShowState(this.toGuildDonateBtn,!1),this.SetBtnShowState(this.sellMarketBtn,!C.g.Inst_get().warehouseShow&&this.itemData.isForBag&&1==this.itemData.cfgData_get().sell&&!this.itemData.isBagWarehouseData&&!this.itemData.isLotteryBag&&!this.itemData.isLotteryShop),
this.SetBtnShowState(this.auctionBtn,this.itemData.isCanOperate&&!C.g.Inst_get().warehouseShow&&0!=this.itemData.AuctionState_get()&&this.itemData.isForBag&&!this.itemData.isLotteryBag&&!this.itemData.isLotteryShop&&!this.itemData.isBagWarehouseData),
this.SetBtnShowState(this.renewBtn,!C.g.Inst_get().warehouseShow&&null!=this.bagItemData&&this.bagItemData.baseData_get().isPastDue_get()&&0!=e&&1!=this.bagItemData.type_get()),
null!=this.tradeBtn&&(!C.g.Inst_get().warehouseShow&&null!=this.itemData.cfgData_get()&&this.itemData.isForBag,this.SetBtnShowState(this.tradeBtn,!1)),
this.itemData.isForBag&&null!=this.extendBtns)for(const[t,e]of(0,R.vy)(this.extendBtns))if(null!=this.extendBtns[t]){const e=this.extendBtns[t]
this.SetBtnShowState(e,!0)}const i=this.GetBtnShowIndex(this.obtainWayBtn)
let s=0
for(;s<this.btnList.Count();)this.btnShowState[s]&&(this.btnShowCnt+=1),this.btnList[s].node.SetActive(this.btnShowState[s]),s+=1
if(-1!=i&&this.btnShowCnt<3&&(this.btnShowCnt-=1,this.SetBtnShowState(this.obtainWayBtn,!1)),this.btnShowCnt>1){let t=!0,e=0
for(;e<this.btnList.Count();)t?this.btnShowState[e]&&(t=!1):i!=e&&this.btnList[e].node.transform.SetParent(this.moreGrid.FatherId,this.moreGrid.ComponentId),e+=1
this.moreBtn.node.SetActive(!0)}else this.moreBtn.node.SetActive(!1)
this.btnShowCnt>0?this.btnObj.SetActive(!0):this.btnObj.SetActive(!1),this.moreGrid.Reposition(),this.btnGrid.Reposition()}else this.btnObj.SetActive(!1)}GetBtnShowIndex(t){
const e=this.btnList.IndexOf(t,0)
return this.btnShowState[e]?e:-1}AllianceDonateBtnClick(t,e){p.J.Inst_get().CloseTipView()}AllianceExchangeBtnClick(t,e){}OpenBagView(t){p.J.Inst_get().openOrClose()}
OnImmediatelyWearBtnClick(t,e){}OnClickAddTimeBtn(){const t=this.parent.node.transform.GetPosition()
t.x-=1.1,t.y+=.08,EquipAddTimeControl.Inst().OpenView(t,this.itemData)}SellMarketBtnClick(t,e){
if(null!=this.bagItemData&&null!=this.bagItemData.baseData_get())if(1==this.bagItemData.baseData_get().cfgData_get().sell)C.g.Inst_get().curSellItemData.Clone(this.bagItemData,!0),
this.bagItemData.baseData_get().cfgData_get().sellConfirm,p.J.Inst_get().OpenBagSellSimplePanel(this.bagItemData)
else{let t=""
t=re.V.Inst().getStr(10303,ae.h.eLangResource),Me.y.inst.ClientStrMsg(c.GF.INT(Ge.r.SystemTipMessage),t)}p.J.Inst_get().CloseTipView()}RenewBtnClick(t,e){
null!=this.bagItemData&&null!=this.bagItemData.serverData_get()&&p.J.Inst_get().CloseTipView()}WarehouseToBagBtnClick(t,e){
if(null!=this.bagItemData&&null!=this.bagItemData.serverData_get()){const t=new H.X
t.LuaDic_AddOrSetItem(this.bagItemData.index_get(),-1),p.J.Inst_get().CM_TakeReq(t),p.J.Inst_get().CloseTipView()}}QuickToAllianceWarehouse(t,e){
u.N.inst.OpenUIByShortCutID(_e.D.ALLIANCE_TECH),p.J.Inst_get().CloseTipView()}BagToWarehouseBtnClick(t,e){if(null!=this.bagItemData&&null!=this.bagItemData.serverData_get()){
const t=new H.X
t.LuaDic_AddOrSetItem(this.bagItemData.index_get(),-1),p.J.Inst_get().CM_StoreReq(t),p.J.Inst_get().CloseTipView()}}ShowMore(t,e){if(this.moreBg.node.SetActive(!1),
!this.isMoreClosing){this.moreObj.SetActive(!0)
const t=g.P.zero_get()
this.moreSp.SetLocalEulerAngles(t)
let e=-1,i=0
for(;i<this.btnList.Count();)this.btnShowState[i]&&(e+=1),i+=1
this.moreBg.heightSet(56*e)}}CloseMore(t,e){this.moreObj.SetActive(!1),180==this.moreSpRotation.y&&180==this.moreSpRotation.z||ue.Y.LogError((0,
s.T)("更多按钮图标旋转值被修改~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")),this.moreSp.SetLocalEulerAngles(this.moreSpRotation)
const i=this.moreSp.GetLocalEulerAngles()
180==i.y&&180==i.z||ue.Y.LogError((0,s.T)("更多按钮图标旋转角度赋值后不对~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")),this.isMoreClosing=!0,
this.closeMoreInterval=bt.C.Inst_get().SetInterval(this._degf_ResetClosingState,100,1)}ResetClosingState(){this.isMoreClosing=!1}TradeBtnClick(t,e){p.J.Inst_get().CloseTipView()}
ScoreSellBtnClick(t,e){
p.J.Inst_get().CloseTipView(),Le.P.Inst_get().IsFunctionOpened(we.x.SCORE_SELL)?p.J.Inst_get().OpenBagSellSimplePanel(this.bagItemData):D.l.SetFunctionTip(we.x.SCORE_SELL)}
RebuyBtnClick(t,e){p.J.Inst_get().CloseTipView()}OnSComposeInBtnClick(t,e){if(null==this.bagItemData||null==this.bagItemData.serverData_get())return
n.Y.Inst.PrimaryRoleInfo_get()
if(n.Y.Inst.IsEquipOn(this.bagItemData.serverData_get().id)){Me.y.inst.ClientSysStrMsg("该装备已穿戴，无法放入")
const t=new Ee.B
return t.infoId="COMPOSE:CHECK_IN",t.cancelHandle=this._degf_ComposeCancelCheckInHandler,t.confirmHandle=this._degf_ComposeCheckInHandler,t.layer=me.F.Tip,void ve.t.Inst().Open(t)}
this.ComposeCheckInHandler()}OnModelBtnClick(t,e){l.i.Inst.RaiseEvent(v.g.EQUIP_TIP_LEFT_MODEL)}ComposeCancelCheckInHandler(t){p.J.Inst_get().CloseTipView()}
ComposeCheckInHandler(t){null!=this.bagItemData&&null!=this.bagItemData.serverData_get()&&p.J.Inst_get().CloseTipView()}ChargeBtnClick(t,e){p.J.Inst_get().CloseTipView()}
BackBagBtnClick(t,e){p.J.Inst_get().CloseTipView()}OnSellBtnClick(t,e){const i=Ae.d.Inst_get().GetOpenParamById(19)
n.Y.Inst.PrimaryRoleInfo_get().Level_get()<i?Me.y.inst.ClientStrMsg(Ge.r.SystemTipMessage,(0,s.T)("功能未开启")):p.J.Inst_get().CloseTipView()}ShowAllotAttrMsgByClose(){
jt.i.CanTakeOnByAllotAttr(n.Y.Inst.PrimaryRoleInfo_get(),this.bagItemData.baseData_get())?this.ShowAddPointMsg("EQUIP:TIPS_DISTED_EQUIP",this._degf_CloseTipView,this._degf_DoWearEquip):this.ShowAddPointMsg("EQUIP:TIPS_DISTED",this._degf_CloseTipView,this._degf_ConfirmAddPoint)
}ShowAddPointMsg(t,e,i){const n=De.L.Inst().getItemById(t)
if(null==n)return
const l=new Be.N
Ft.M.IsNullOrEmpty(n.title)?l.titleText=(0,s.T)("提示"):l.titleText=n.title
let a=n.text
if("EQUIP:TIPS_DISTED"==t||"EQUIP:TIPS_DISTED_EQUIP"==t){let t="",e=""
const i=Ce.X.Inst_get().strengthAddPoint
0!=i&&(e=Ft.M.IntToString(i)+D.l.getAttrStrWithoutSign(ye.Z.Strength),t=this.CombineWithSplit(t,e,de.o.s_SPAN_CHAR))
const n=Ce.X.Inst_get().agilityAddoint
0!=n&&(e=Ft.M.IntToString(n)+D.l.getAttrStrWithoutSign(ye.Z.Agility),t=this.CombineWithSplit(t,e,de.o.s_SPAN_CHAR))
const o=Ce.X.Inst_get().vitalityAddPoint
0!=o&&(e=Ft.M.IntToString(o)+D.l.getAttrStrWithoutSign(ye.Z.Vitality),t=this.CombineWithSplit(t,e,de.o.s_SPAN_CHAR))
const r=Ce.X.Inst_get().intelligenceAddPoint
0!=r&&(e=Ft.M.IntToString(r)+D.l.getAttrStrWithoutSign(ye.Z.Intelligence),t=this.CombineWithSplit(t,e,de.o.s_SPAN_CHAR)),a=Ft.M.Replace(a,"{0}",t)
const h=oe.l.GetInst().GetPlayerInitial(this.role.Job_get())
a=Ft.M.Replace(a,"{1}",Ft.M.IntToString(h.levelOfPoint)),l.tipstype=2,l.btnColorType=2,l.cancelText=(0,s.T)("取消")}else{l.tipstype=1,l.btnColorType=1
const t=oe.l.GetInst().GetPlayerInitial(this.role.Job_get())
a=Ft.M.Replace(a,"{0}",Ft.M.IntToString(t.levelOfPoint))}l.showText=a,l.okText=(0,s.T)("确定"),l.okhandler=i,l.cancelhandler=e,Me.y.inst.OpenTopLayerMessageTips(l,!0)}
CombineWithSplit(t,e,i){return Ft.M.IsNullOrEmpty(t)?t=e:t+=i+e,t}OnWearBtnClick(t,e){if(this.bagItemData=this.parent.GetBagItemData(),
null!=this.bagItemData&&null!=this.bagItemData.baseData_get())if(null!=INS.itemTipManager.selectTipRole)this.bagItemData=this.parent.GetBagItemData(),this.CheckJob()
else{const t=jt.i.GetCanUsePlayerInfoByOnlyJob(this.bagItemData.baseData_get())
null!=t?(INS.itemTipManager.selectTipRole=t,l.i.Inst.RaiseEvent(v.g.EQUIP_TIP_CLICK_WEAR)):Me.y.inst.ClientSysStrMsg((0,s.T)("没有职业可穿戴"))}}CheckJob(){
if(null!=this.bagItemData&&null!=this.bagItemData.baseData_get()&&null!=this.bagItemData.baseData_get().cfgData_get()){
if(0!=this.bagItemData.baseData_get().AuctionState_get()&&c.GF.INT(this.bagItemData.baseData_get().cfgData_get().job/1e3)==c.GF.INT(n.Y.Inst.PrimaryRoleInfo_get().Job_get()/1e3)){
const t=this.bagItemData.baseData_get().SuitBranch_get()
if(t>0&&t!=D.l.GetJobBranch(n.Y.Inst.PrimaryRoleInfo_get().Job_get())){const t="ITEM:EQUIP_CONFIRM"
if(!Pe.V.Inst_get().GetData(Pe.V.Inst_get().GetRolePrefix()+t)){
const e=D.l.SetEquipName(this.bagItemData.baseData_get().equipInfo_get(),this.bagItemData.baseData_get().cfgData_get(),this.bagItemData.baseData_get().serverData_get())[0],i=new Ee.B
return i.infoId=t,i.replaceParams.Add(e),i.cancelText=(0,s.T)("坚持穿戴"),i.cancelHandle=this._degf_WearEquipHandler,i.confirmText=(0,s.T)("放弃穿戴"),this.CloseTipView(),
void ve.t.Inst().Open(i)}}}this.WearEquipHandler(null)}}ConfirmAddPoint(t){const e=new Oe.z
e.playerId=n.Y.Inst.GetMultiPlayerInfoByCreateIdx(this.bagItemData.baseData_get().playerIdx).Id_get(),e.attrToPoint=new H.X,
e.attrToPoint.LuaDic_AddOrSetItem(ye.Z.Strength,Ce.X.Inst_get().strengthAddPoint),e.attrToPoint.LuaDic_AddOrSetItem(ye.Z.Agility,Ce.X.Inst_get().agilityAddoint),
e.attrToPoint.LuaDic_AddOrSetItem(ye.Z.Vitality,Ce.X.Inst_get().vitalityAddPoint),e.attrToPoint.LuaDic_AddOrSetItem(ye.Z.Intelligence,Ce.X.Inst_get().intelligenceAddPoint),
he.C.Inst.F_SendMsg(e),Ce.X.Inst_get().strengthAddPoint=0,Ce.X.Inst_get().agilityAddoint=0,Ce.X.Inst_get().vitalityAddPoint=0,Ce.X.Inst_get().intelligenceAddPoint=0}
WearEquipHandler(t){if(ge.t.Inst_get().IsEquipAddPointTipShow()){if(0==n.Y.Inst.PrimaryRoleInfo_get().RemainBasePoint_get())return void this.ShowAddPointMsg("EQUIP:TIPS_NO_DIST")
if(!Ce.X.Inst_get().HasPreAddPoint())return void ge.t.Inst_get().PlayGuideAllotEff()
if(!jt.i.CanTakeOnByAllotAttr(n.Y.Inst.PrimaryRoleInfo_get(),this.bagItemData.baseData_get()))return void this.ShowAddPointMsg("EQUIP:TIPS_DISTED",this._degf_CloseTipView,this._degf_ConfirmAddPoint)
}else{if(INS.itemTipManager.IsShowAddPointTip(this.bagItemData.baseData_get())){const t=new pe.F
t.tipType=Se.A.WearEquip
const e=n.Y.Inst.GetMultiPlayerInfoByCreateIdx(this.bagItemData.baseData_get().playerIdx).Id_get()
return t.ItemData_set(this.bagItemData.baseData_get(),n.Y.Inst.GetMultiPlayerInfo(e)),C.g.Inst_get().curSelectItemData.Clone(this.bagItemData),ge.t.Inst_get().OpenTip(t,!1),
void this.CloseTipView()}}this.bagItemData=this.parent.GetBagItemData(),null!=this.bagItemData&&this.DoWearEquip(null)}DoWearEquip(t){this.bagItemData=this.parent.GetBagItemData(),
null!=this.bagItemData?-1!=this.GetBtnShowIndex(this.wearBtn)&&p.J.Inst_get().UseItem(this.bagItemData):this.itemData.isTakeOnEquip&&p.J.Inst_get().ForceCloseTipView()}
DoEnhanceEquip(t,e){Te.Q.inst.Open()}OnGetWayBtnClick(t,e){p.J.Inst_get().OnGetWay()}OnReWearBtnClick(t,e){if(INS.itemTipManager.IsShowAddPointTip(this.itemData)){const t=new pe.F
t.tipType=Se.A.WearEquip
const e=n.Y.Inst.GetMultiPlayerInfoByCreateIdx(this.bagItemData.baseData_get().playerIdx).Id_get()
t.ItemData_set(this.itemData,n.Y.Inst.GetMultiPlayerInfo(e)),C.g.Inst_get().curSelectItemData.Clone(this.bagItemData),ge.t.Inst_get().OpenTip(t),this.CloseTipView()}}
CloseTipView(t){null==t&&(t=!1),p.J.Inst_get().CloseTipView()}OnTakeOffBtnClick(t,e){p.J.Inst_get().TakeOffEquip(this.itemData)}OnAuctionBtnClick(t,e){this.CloseTipView(),
be.W.GetInst().autoOpenGroundingItemId=this.bagItemData.baseData_get().serverData_get().id}OnAccessForJobBtnClick(t,e){}OnGetOutBtnClick(t,e){
fe.a.inst.CM_TempPackTackReq(this.bagItemData.index_get()),p.J.Inst_get().CloseTipView()}OnComposeBtnClick(t,e){const i=this.ir.GetComposeID(),n=Re.c.Inst().getItemById(i)
if(null!=n){if(!n.isFunOpen())return Me.y.inst.ClientStrMsg(Ge.r.SystemTipMessage,(0,s.T)("等级不足，该合成配方尚未解锁")),void p.J.Inst_get().CloseTipView()
Ie.V.Inst_get().JumpToRyCompoundPanel(n.composeTabs,i),p.J.Inst_get().CloseTipView()}}AddExtendBtn(){const t=this.er.GetExtendBtnInfo()
let e=0
if(null!=t){this.extendBtns={}
const i=0
for(const[s,n]of(0,R.vy)(t)){let n=null
if(this.extendBList.count>i)n=this.extendBList[0],this.extendBList.RemoveAt(0)
else{const t=xt.g.GetResFindId("ui_equiptip_extendbtn")
n=new xe,n.setId(t,null,0)}n.SetData(s,t[s],this.itemData),this.btnList.IndexOf(n,0)<0&&this.btnList.Add(n),this.extendBtns[e]=n,e+=1}}}SetBtnShowState(t,e){
const i=this.btnList.IndexOf(t,0)
this.btnShowState[i]=e}Destroy(){if(null!=this.extendBtns){for(const[t,e]of(0,R.vy)(this.extendBtns)){this.extendBtns[t].Destroy()}this.extendBtns=null}let t=0
for(;t<this.extendBList.count;)this.extendBList[t].Destroy(),t+=1
this.extendBList=null,this.composeInBtn=null}}var ke=i(17081),Ve=i(14140),Fe=i(60606),Ue=i(88309)
class He extends F.C{constructor(){super(),this.grid=null,this.parent=null,this.isEquipTip=!0,this._degf_OnItemRefreshFun=null,this._degf_OnReposition=null,
this._degf_SortAttrData=null,this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),this._degf_OnReposition=()=>this.OnReposition(),
this._degf_SortAttrData=(t,e)=>this.SortAttrData(t,e)}InitView(){super.InitView(),this.grid=new o.A,this.grid.setId(this.FatherId,this.FatherComponentID,1),
this.grid.SetInitInfo("ui_equiptip_commonattrhasstar",this._degf_OnItemRefreshFun),this.grid.OnReposition_set(this._degf_OnReposition)}SetData(t,e,i,s,n,l,a){null==a&&(a=!0),
this.parent=l,this.isEquipTip=a
const o=new _.Z,r=new H.X,h=new H.X,d=new H.X
He.getExcellentDic(h,i,s,t,n),He.getPreviewDict(d,h,e,i,s,t,n),He.addExcellAttrStr(h,r)
const u=new _.Z
for(const[t,e]of(0,R.vy)(r)){const e=new Fe.H
e.type=t,e.str=r[t],d.LuaDic_ContainsKey(t)&&(e.isPreview=!0),u.Add(e)}u.Sort(this._degf_SortAttrData)
let c=0
for(;c<u.Count();)o.Add(u[c]),c+=1
o.Count()>0?(this.node.SetActive(!0),this.grid.data_set(o)):(this.node.SetActive(!1),this.OnReposition())}getBaseAttrDic(t,e){const i=t.m_atts_get().Clone()
if(null!=i&&null!=i.attrs)for(const[t,s]of(0,R.V5)(i.attrs))e.LuaDic_AddOrSetItem(s.intType,s.value)}static getExcellentDic(t,e,i,s,n){
const l=Wt.X.Inst_get().GetEquipExcellenceCount(n,s),a=new _.Z(4)
a[0]=e.intPosition_get(),a[1]=l,a[2]=e.equipColumnsList_get()[0],a[3]=c.GF.INT(i.job/100)}static getPreviewDict(t,e,i,s,n,l,a){}static addExcellAttrStr(t,e){for(const[i,s]of(0,
R.vy)(t)){const s=t[i]
if(s>0){const t=He.getExcellStr(i,s)
e.LuaDic_AddOrSetItem(i,t)}}}static getExcellStr(t,e,i){null==i&&(i=!1)
let n=""
2004==t?n="":2005==t?n="1/":2006==t&&(n=(0,s.T)("等级/"))
const l=D.l.getAttrValueStr(t,e)
let a=""
return 2004!=t&&2005!=t&&2006!=t?i?a=l:a+=`[e5bb22]${D.l.getAttrStrWithoutSign(t)} +${l}[-]`:a=i?n+l:`${a}[e5bb22]${D.l.getAttrStrWithoutSign(t)} +${n}${l}[-]`,a}isDamageUpDown(t){
return 2012==t||2013==t}SortAttrData(t,e){
return this.isDamageUpDown(t.type)&&!this.isDamageUpDown(e.type)?-1:this.isDamageUpDown(e.type)&&!this.isDamageUpDown(t.type)||t.type>e.type?1:t.type<e.type?-1:0}
OnItemRefreshFun(t){const e=new Ue.R
return e.setId(t,null,0),e}OnReposition(){if(this.isEquipTip){this.parent.SetReady(Jt.L.eExcellenceBaseModule)}else if((0,Qt.t2)(this.parent,Ve.b)){const t=this.parent
t.ReadyCnt_set(t.ReadyCnt_get()+1)}}Hide(){const t=this.node.transform.GetLocalPosition()
t.y=1e4,this.node.transform.SetLocalPosition(t),g.P.Recyle(t)}Destroy(){this.grid.Destroy(),this.grid=null}}var qe=i(87666),Ze=i(6816),je=i(97960),Xe=i(22370)
class Ye extends F.C{constructor(){super(),this.grid=null,this.growLevel=null,this.expBar=null,this.exp=null,this.parent=null,this.isEquipTip=!0,this.activatedColor="[ffefe1]",
this.inactivatedColor="[8e8279]",this.curEquipId=U.o.ZERO,this.isReady=!1,this.isShow=!1,this.interval=-1,this._degf_DelayUpdateExp=null,this._degf_OnItemRefreshFun=null,
this._degf_OnReposition=null,this._degf_OnReposition2=null,this._degf_UpdateExp=null,this._degf_DelayUpdateExp=(t,e)=>this.DelayUpdateExp(t,e),
this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),this._degf_OnReposition=()=>this.OnReposition(),this._degf_OnReposition2=()=>this.OnReposition2(),
this._degf_UpdateExp=t=>this.UpdateExp(t)}InitView(){this.grid=new o.A,this.grid.setId(this.FatherId,this.FatherComponentID,1),this.growLevel=new k.Q,
this.growLevel.setId(this.FatherId,this.FatherComponentID,2),this.expBar=new Xe.f,this.expBar.setId(this.FatherId,this.FatherComponentID,3),this.exp=new k.Q,
this.exp.setId(this.FatherId,this.FatherComponentID,4),this.grid.SetInitInfo("ui_equiptip_commonattr",this._degf_OnItemRefreshFun),
this.grid.OnReposition_set(this._degf_OnReposition)}OnItemRefreshFun(t){const e=new te.F
return e.setId(t,null,0),e}AddLis(){n.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(je.A.EquipGrowExpUpdate,this._degf_UpdateExp)}Clear(){this.isShow=!1,this.isReady=!1,
this.curEquipId=U.o.ZERO
n.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(je.A.EquipGrowExpUpdate,this._degf_UpdateExp),bt.C.Inst_get().ClearInterval(this.interval),this.interval=-1}UpdateExp(t){const e=t
this.isShow&&null!=e&&e.id.Equal(this.curEquipId)&&(bt.C.Inst_get().ClearInterval(this.interval),
this.IsReady()?this.SetData(e.GetEquipInfo(),e.GetEquipRes(),e,this.parent,this.isEquipTip,!1):this.interval=bt.C.Inst_get().SetFrameLoopForParm(this._degf_DelayUpdateExp,1,1,t))}
DelayUpdateExp(t,e){this.UpdateExp(e)}SetData(t,e,i,s,n,l){null==l&&(l=!0),null==n&&(n=!0),this.isReady=!1,this.parent=s,this.isEquipTip=n
new _.Z
if(this.exp.textSet(""),e.canGrow){let t=0,e=0
null!=i&&(this.curEquipId=i.id,t=i.equipLevel,e=i.equipExp.ToNum())}else this.node.SetActive(!1),l&&this.OnReposition()}OnReposition(){if(this.isEquipTip){
this.parent.SetReady(Jt.L.eGrowModule)}else if((0,Qt.t2)(this.parent,Ve.b)){const t=this.parent
t.ReadyCnt_set(t.ReadyCnt_get()+1)}this.isReady=!0}IsReady(){if(this.isShow){if(this.isEquipTip&&null!=this.parent){return this.parent.GetIsRelayoutFinish()}return this.isReady}
return!1}OnReposition2(){if(this.isReady=!0,"MAX"==this.exp.text())if(this.isEquipTip){const t=this.parent,e=new _.Z
let i=0
for(;i<li.MODULE_COUNT;)e.Add(1),i+=1
const s=g.P.zero_get(),n=new _.Z([!0,s,-1])
t.Relayout(!1,e,n)}else if((0,Qt.t2)(this.parent,Ve.b)){this.parent.Relayout()}}Hide(){const t=this.node.transform.GetLocalPosition()
t.y=1e4,this.node.transform.SetLocalPosition(t),g.P.Recyle(t)}Destroy(){this.grid.Destroy(),this.grid=null}}var We=i(30267)
class $e extends wt.x{constructor(...t){super(...t),this.desc=null,this.perfect=null,this.zeroDesc=null}InitView(){super.InitView(),this.desc=new k.Q,
this.desc.setId(this.FatherId,this.FatherComponentID,1),this.perfect=new Mt.z,this.perfect.setId(this.FatherId,this.FatherComponentID,2),this.zeroDesc=new k.Q,
this.zeroDesc.setId(this.FatherId,this.FatherComponentID,3)}SetData(t){const e=t
let i=null
e.isPerfect||3==e.level?this.perfect.SetActive(!0):this.perfect.SetActive(!1),0!=e.talentId||null!=e.data.attribute&&(i=D.l.getAttrStr(e.data.attribute.intType,!1)+D.l.getAttrValueStr(e.data.attribute.intType,e.data.attribute.value)),
i=`${e.colorStr}${e.str}[-]`,this.zeroDesc.textSet(i),this.desc.textSet("")}SetPerfectAttrPos(){this.desc.textSet(this.zeroDesc.text()),this.zeroDesc.textSet("")}Clear(){
super.Clear()}Destroy(){super.Destroy()}}class Je extends F.C{constructor(){super(),this.table=null,this.parent=null,this.isEquipTip=!0,this.hasPerfect=!1,this.role=null,
this._degf_OnItemRefreshFun=null,this._degf_OnReposition=null,this._degf_SortAttrData=null,this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),
this._degf_OnReposition=()=>this.OnReposition(),this._degf_SortAttrData=(t,e)=>this.SortAttrData(t,e)}InitView(){super.InitView(),this.table=new We.V,
this.table.setId(this.FatherId,this.FatherComponentID,1),this.table.SetInitInfo("ui_equiptip_reliveattr",this._degf_OnItemRefreshFun),
this.table.OnReposition_set(this._degf_OnReposition)}SetData(t,e,i,s){null==s&&(s=!0),this.parent=i,this.role=t,this.isEquipTip=s,this.hasPerfect=!1,this.node.SetActive(!1),
this.OnReposition()}OnItemRefreshFun(t){const e=new $e
return e.setId(t,null,0),e}OnReposition(){}Hide(){const t=this.node.transform.GetLocalPosition()
t.y=1e4,this.node.transform.SetLocalPosition(t),g.P.Recyle(t)}Destroy(){this.table.Destroy(),this.table=null}}var ze=i(76195),Qe=i(75390),Ke=i(78248),ti=i(85174),ei=i(30726)
class ii{constructor(){this.type=0,this.typeStr=null,this.level=null,this.componentId=0}}class si extends wt.x{constructor(){super(),this.sp_type=null,this.label_type=null,
this.grid=null,this.data=null,this._degf_OnBtnClick=null,this._degf_OnItemLoaded=null,this._degf_OnReposition=null,this._degf_OnBtnClick=(t,e)=>this.OnBtnClick(t,e),
this._degf_OnItemLoaded=t=>this.OnItemLoaded(t),this._degf_OnReposition=()=>this.OnReposition()}InitView(){this.sp_type=new Rt.w,
this.sp_type.setId(this.FatherId,this.FatherComponentID,1),this.label_type=new k.Q,this.label_type.setId(this.FatherId,this.FatherComponentID,2),this.grid=new o.A,
this.grid.setId(this.FatherId,this.FatherComponentID,3),this.grid.SetInitInfo("ui_equiptip_commonattr",this._degf_OnItemLoaded),this.grid.OnReposition_set(this._degf_OnReposition)}
OnItemLoaded(t){const e=new te.F
return e.setId(t,null,0),e}OnReposition(){l.i.Inst.RaiseEvent(v.g.ELEMENTAL_Attr_Loaded,this.data.componentId)}SetData(t){this.AddOrRemoveLis(!0)
let e=null
this.data=t,0==t.type?(this.sp_type.spriteNameSet("comm_icon_0087"),e=(0,s.T)("攻击")):1==t.type&&(this.sp_type.spriteNameSet("comm_icon_0086"),e=(0,s.T)("防御")),
this.label_type.textSet(D.l.ConcatStr((0,s.T)("元素"),e,t.level,(0,s.T)("级：")))
const i=new _.Z
this.grid.data_set(i)}AddOrRemoveLis(t){}OnBtnClick(t,e){}Clear(){this.AddOrRemoveLis(!1),this.grid.Clear()}Destroy(){this.sp_type=null,this.label_type=null,this.grid.Destroy(),
this.grid=null}}class ni extends F.C{constructor(){super(),this.table=null,this.totalNum=0,this._degf_OnBtnClick=null,this._degf_OnItemLoaded=null,this._degf_OnReposition=null,
this._degf_RepositionComplete=null,this.fatherView=null,this._degf_OnBtnClick=(t,e)=>this.OnBtnClick(t,e),this._degf_OnItemLoaded=t=>this.OnItemLoaded(t),
this._degf_OnReposition=()=>this.OnReposition(),this._degf_RepositionComplete=t=>this.RepositionComplete(t)}InitView(){this.table=new We.V,
this.table.setId(this.FatherId,this.FatherComponentID,1),this.table.SetInitInfo("ui_equiptip_elementattr",this._degf_OnItemLoaded),
this.table.OnReposition_set(this._degf_OnReposition)}OnItemLoaded(t){const e=new si
return e.setId(t,null,0),e}SetData(t,e){this.AddOrRemoveLis(!0),this.fatherView=e
let i=null
const s=new _.Z
if(null!=t&&null!=t.equipElementEnhance)for(const[e,n]of(0,R.V5)(t.equipElementEnhance.elementEnhanceDict))n>0&&(i=new ii,i.type=e,i.level=n,
i.typeStr=t.GetEquipRes().ElementTypeStr_get(e),i.componentId=this.ComponentId,s.Add(i))
s.Count()>0?(this.totalNum=s.count_get(),this.node.SetActive(!0),this.table.data_set(s)):(this.totalNum=0,this.node.SetActive(!1),this.OnReposition())}OnReposition(){
0==this.totalNum&&this.SetReady()}SetReady(){this.fatherView.SetReady(Jt.L.eElementEnhanceModule)}RepositionComplete(t){this.ComponentId==t&&(this.totalNum-=1,
0==this.totalNum&&this.table.Reposition())}Hide(){const t=this.node.transform.GetLocalPosition()
t.y=1e4,this.node.transform.SetLocalPosition(t),g.P.Recyle(t)}AddOrRemoveLis(t){
t?l.i.Inst.AddEventHandler(v.g.ELEMENTAL_Attr_Loaded,this._degf_RepositionComplete):l.i.Inst.RemoveEventHandler(v.g.ELEMENTAL_Attr_Loaded,this._degf_RepositionComplete)}
OnBtnClick(t,e){}Clear(){this.AddOrRemoveLis(!1),this.table.Clear()}Destroy(){this.table.Destroy(),this.table=null}}class li extends F.C{constructor(){super(),this.scrollView=null,
this.qualityBg=null,this.equipIcon=null,this.lockObj=null,this.equipLv=null,this.nameLabel=null,this.stepLabel=null,this.typeLabel=null,this.root=null,this.timeModule=null,
this.demandModule=null,this.baseModule=null,this.excellenceModule=null,this.normalSuitModule=null,this.enhanceSuitModule=null,this.enhanceWingrefineModule=null,
this.skillModule=null,this.descLabel=null,this.getWayBtn=null,this.scoreLabel=null,this.scrollPanel=null,this.scrollBack=null,this.scrollBarFG=null,this.descChannelLabel=null,
this.descObj=null,this.descChannelObj=null,this.background=null,this.totalScoreLabel=null,this.specialModule=null,this.growModule=null,this.auctionModule=null,
this.qualityAnimOne=null,this.qualityAnimTwo=null,this.qualityAnimThree=null,this.qualityAnimFour=null,this.qualityAnimFive=null,this.qualityAnimSix=null,
this.excellenceBaseModule=null,this.angelModule=null,this.angelSuitModule=null,this.auctionTipDesc=null,this.auctionTipBg=null,this.godModule=null,this.btnModule=null,
this.reliveModule=null,this.masterSuitModule=null,this.isCanOperate=!1,this.ir=null,this.er=null,this.eInfo=null,this.compareData=null,this.equipment=null,this.itemData=null,
this.bagItemData=null,this.role=null,this.qualityAnimList=null,this.relayoutState=null,this.noBtnPanelSize=null,this.hasBtnPanelSize=null,this.hasBtnAndAuctionPanelSize=null,
this.hasAuctionPanelSize=null,this.btnObjPos=null,this.auctionTipPos=null,this.moreObjPos=null,this.bgOffset=0,this.excellenceCnt=0,this.star=0,this.updateInterval=-1,
this.m_pos=null,this.m_setPosCallback=null,this.relayoutParam=null,this.equipTypeLabel=null,this._degf_OnGetWayBtnClick=null,this._degf_UpdateItemData=null,
this.multiSuitModule1=null,this.multiSuitModule2=null,this.multiSuitModule3=null,this.multiSuitModule4=null,this.multiSuitModule5=null,this.elementEnhanceModule=null,
this.offset=null,this.img_addvalue=null,this.img_addallvalue=null,this.additionalModule=null,this.starContainer=null,this.scrollbg=null,this.ShowWayBtn=null,
this.qualityAnimList=new _.Z,this.noBtnPanelSize=new Ut.L(0,-37,395,440),this.hasBtnPanelSize=new Ut.L(0,0,395,365),this.hasBtnAndAuctionPanelSize=new Ut.L(0,19,395,328),
this.hasAuctionPanelSize=new Ut.L(0,-17,395,400),this.btnObjPos=new g.P(0,-287,0),this.auctionTipPos=new g.P(0,-200,0),this.moreObjPos=new g.P(0,0,0),this.m_pos=new g.P
const t=g.P.zero_get()
this.relayoutParam=new _.Z([!0,t,-1]),this._degf_OnGetWayBtnClick=(t,e)=>this.OnGetWayBtnClick(t,e),this._degf_UpdateItemData=(t,e)=>this.UpdateItemData(t,e)}SetReady(t){
if(0==this.relayoutState[t]){this.relayoutState[t]=1
let e=!0
let i=c.GF.INT(this.relayoutParam[2])+1
for(;i<t;){if(0==this.relayoutState[i]){e=!1
break}i+=1}e&&this.Relayout(!0,this.relayoutState,this.relayoutParam)}}GetIsRelayoutFinish(){return c.GF.INT(this.relayoutParam[2])==li.MODULE_COUNT-1}BgOffset_get(){
return this.bgOffset}BgOffset_set(t){this.bgOffset=t<-340?-340:t>0?0:t
const e=new g.P(this.btnObjPos.x,this.btnObjPos.y-this.bgOffset,this.btnObjPos.z)
this.btnModule.btnObj.transform.SetLocalPosition(e),e.Set(this.moreObjPos.x,this.moreObjPos.y-this.bgOffset,this.moreObjPos.z),this.btnModule.moreObj.transform.SetLocalPosition(e),
this.background.heightSet(c.GF.INT(ai.bgHeight+this.bgOffset)),e.Set(this.auctionTipPos.x,this.auctionTipPos.y-this.bgOffset,this.auctionTipPos.z)
let i=!1
if(null!=this.itemData&&(i=0!=this.itemData.AuctionState_get()),i&&this.btnModule.btnShowCnt>0?this.auctionTipBg.SetActive(!1):(this.auctionTipBg.SetActive(!0),
i&&this.btnModule.btnShowCnt<=0&&e.Set(this.auctionTipPos.x,this.auctionTipPos.y-this.bgOffset-72,this.auctionTipPos.z)),this.auctionTipDesc.node.transform.SetLocalPosition(e),
g.P.Recyle(e),null!=this.itemData&&1==this.itemData.tag){let t=this.m_pos.y
t+=.5*this.bgOffset
const e=new g.P(this.m_pos.x,t,this.m_pos.z)
this.node.transform.SetLocalPosition(e),g.P.Recyle(e),null!=this.m_setPosCallback&&this.m_setPosCallback()}}InitView(){super.InitView(),this.scrollView=new Pt.h,
this.scrollView.setId(this.FatherId,this.FatherComponentID,1),this.qualityBg=new Rt.w,this.qualityBg.setId(this.FatherId,this.FatherComponentID,2),this.equipIcon=new Rt.w,
this.equipIcon.setId(this.FatherId,this.FatherComponentID,3),this.lockObj=new Mt.z,this.lockObj.setId(this.FatherId,this.FatherComponentID,4),this.equipLv=new k.Q,
this.equipLv.setId(this.FatherId,this.FatherComponentID,5),this.nameLabel=new k.Q,this.nameLabel.setId(this.FatherId,this.FatherComponentID,6),this.stepLabel=new k.Q,
this.stepLabel.setId(this.FatherId,this.FatherComponentID,7),this.typeLabel=new k.Q,this.typeLabel.setId(this.FatherId,this.FatherComponentID,8),this.root=new Mt.z,
this.root.setId(this.FatherId,this.FatherComponentID,9),this.timeModule=new ti.I,this.timeModule.setBinderId(this.FatherId,this.FatherComponentID,10),this.demandModule=new ke.k,
this.demandModule.setBinderId(this.FatherId,this.FatherComponentID,11),this.baseModule=new le.$,this.baseModule.setBinderId(this.FatherId,this.FatherComponentID,12),
this.excellenceModule=new qe.f,this.excellenceModule.setBinderId(this.FatherId,this.FatherComponentID,13),this.normalSuitModule=new Ke.q,
this.normalSuitModule.setBinderId(this.FatherId,this.FatherComponentID,14),this.enhanceSuitModule=new Ke.q,
this.enhanceSuitModule.setBinderId(this.FatherId,this.FatherComponentID,15),this.descLabel=new k.Q,this.descLabel.setId(this.FatherId,this.FatherComponentID,16),
this.getWayBtn=new a.W,this.getWayBtn.setId(this.FatherId,this.FatherComponentID,17),this.enhanceWingrefineModule=new ei.g,
this.enhanceWingrefineModule.setBinderId(this.FatherId,this.FatherComponentID,20),this.scrollPanel=new Bt.$,this.scrollPanel.setId(this.FatherId,this.FatherComponentID,21),
this.scrollBack=new h.T,this.scrollBack.setId(this.FatherId,this.FatherComponentID,22),this.scrollBarFG=new Rt.w,this.scrollBarFG.setId(this.FatherId,this.FatherComponentID,23),
this.descChannelLabel=new k.Q,this.descChannelLabel.setId(this.FatherId,this.FatherComponentID,24),this.skillModule=new ze.F,
this.skillModule.setBinderId(this.FatherId,this.FatherComponentID,25),this.descObj=new Mt.z,this.descObj.setId(this.FatherId,this.FatherComponentID,26),
this.descChannelObj=new Mt.z,this.descChannelObj.setId(this.FatherId,this.FatherComponentID,27),this.background=new Rt.w,
this.background.setId(this.FatherId,this.FatherComponentID,28),this.totalScoreLabel=new k.Q,this.totalScoreLabel.setId(this.FatherId,this.FatherComponentID,29),
this.specialModule=new Qe.m,this.specialModule.setBinderId(this.FatherId,this.FatherComponentID,31),this.growModule=new Ye,
this.growModule.setBinderId(this.FatherId,this.FatherComponentID,32),this.auctionModule=new ne.N,this.auctionModule.setBinderId(this.FatherId,this.FatherComponentID,33),
this.qualityAnimOne=new Mt.z,this.qualityAnimOne.setId(this.FatherId,this.FatherComponentID,35),this.qualityAnimTwo=new Mt.z,
this.qualityAnimTwo.setId(this.FatherId,this.FatherComponentID,36),this.qualityAnimThree=new Mt.z,this.qualityAnimThree.setId(this.FatherId,this.FatherComponentID,37),
this.qualityAnimFour=new Mt.z,this.qualityAnimFour.setId(this.FatherId,this.FatherComponentID,38),this.qualityAnimFive=new Mt.z,
this.qualityAnimFive.setId(this.FatherId,this.FatherComponentID,39),this.qualityAnimSix=new Mt.z,this.qualityAnimSix.setId(this.FatherId,this.FatherComponentID,40),
this.excellenceBaseModule=new He,this.excellenceBaseModule.setBinderId(this.FatherId,this.FatherComponentID,41),this.angelModule=new se.P,
this.angelModule.setBinderId(this.FatherId,this.FatherComponentID,42),this.angelSuitModule=new Ke.q,this.angelSuitModule.setBinderId(this.FatherId,this.FatherComponentID,45),
this.auctionTipDesc=new k.Q,this.auctionTipDesc.setId(this.FatherId,this.FatherComponentID,47),this.auctionTipBg=new Mt.z,
this.auctionTipBg.setId(this.FatherId,this.FatherComponentID,48),this.godModule=new Ze.w,this.godModule.setBinderId(this.FatherId,this.FatherComponentID,49),
this.multiSuitModule1=new Ke.q,this.multiSuitModule1.setBinderId(this.FatherId,this.FatherComponentID,50),this.multiSuitModule2=new Ke.q,
this.multiSuitModule2.setBinderId(this.FatherId,this.FatherComponentID,51),this.multiSuitModule3=new Ke.q,
this.multiSuitModule3.setBinderId(this.FatherId,this.FatherComponentID,52),this.multiSuitModule4=new Ke.q,
this.multiSuitModule4.setBinderId(this.FatherId,this.FatherComponentID,53),this.multiSuitModule5=new Ke.q,
this.multiSuitModule5.setBinderId(this.FatherId,this.FatherComponentID,54),this.btnModule=new Ne,this.btnModule.setBinderId(this.FatherId,this.FatherComponentID,55),
this.reliveModule=new Je,this.reliveModule.setBinderId(this.FatherId,this.FatherComponentID,56),this.masterSuitModule=new Ke.q,
this.masterSuitModule.setBinderId(this.FatherId,this.FatherComponentID,63),this.elementEnhanceModule=new ni,
this.elementEnhanceModule.setBinderId(this.FatherId,this.FatherComponentID,64),this.offset=this.CreateComponent(Mt.z,65),this.img_addvalue=this.CreateComponent(Rt.w,68),
this.img_addallvalue=this.CreateComponent(Rt.w,72),this.additionalModule=this.CreateComponentBinder(ie,74),this.starContainer=this.CreateComponent(o.A,75),
this.starContainer.SetInitInfo("ui_equip_star_item",null,zt),this.scrollbg=this.CreateComponent(Rt.w,76),this.qualityAnimList.Add(null),
this.qualityAnimList.Add(this.qualityAnimOne),this.qualityAnimList.Add(this.qualityAnimTwo),this.qualityAnimList.Add(this.qualityAnimThree),
this.qualityAnimList.Add(this.qualityAnimFour),this.qualityAnimList.Add(this.qualityAnimFive),this.qualityAnimList.Add(this.qualityAnimSix),this.ShowWayBtn=!0}OnAddToScene(){
this.AddLis(),this.btnModule.OnAddToScene()}Clear(){this.itemData=null,$t.x.inst.RemoveFormulaValue(),this.RemoveLis(),this.timeModule.ClearTimer(),this.auctionModule.ClearTimer(),
this.demandModule.clear(),this.skillModule.Clear(),this.angelSuitModule.Clear(),this.masterSuitModule.Clear(),this.normalSuitModule.Clear(),this.enhanceSuitModule.Clear(),
this.multiSuitModule1.Clear(),this.multiSuitModule2.Clear(),this.multiSuitModule3.Clear(),this.multiSuitModule4.Clear(),this.multiSuitModule5.Clear(),this.growModule.Clear(),
this.angelModule.Clear(),this.btnModule.Clear(),this.elementEnhanceModule.Clear(),bt.C.Inst_get().ClearInterval(this.updateInterval),this.updateInterval=-1,this.HideObj()}AddLis(){
r.i.Get(this.getWayBtn.node).RegistonClick(this._degf_OnGetWayBtnClick),this.demandModule.AddLis(),this.angelSuitModule.AddLis(),this.masterSuitModule.AddLis(),
this.normalSuitModule.AddLis(),this.enhanceSuitModule.AddLis(),this.multiSuitModule1.AddLis(),this.multiSuitModule2.AddLis(),this.multiSuitModule3.AddLis(),
this.multiSuitModule4.AddLis(),this.multiSuitModule5.AddLis(),this.growModule.AddLis(),this.angelModule.AddLis(),this.btnModule.AddLis()}RemoveLis(){
r.i.Get(this.getWayBtn.node).RemoveonClick(this._degf_OnGetWayBtnClick)}SetPos(){this.m_pos=this.node.transform.GetLocalPosition().Clone()}SetQualityAnim(t){let e=1
for(;e<this.qualityAnimList.Count();)this.qualityAnimList[e].SetActive(!1),e+=1
0!=t&&t<this.qualityAnimList.Count()&&this.qualityAnimList[t].SetActive(!0)}SetData(t,e,i,s,l){this.node.SetActive(!0),this.BgOffset_set(0),this.m_setPosCallback=s,
bt.C.Inst_get().ClearInterval(this.updateInterval),this.relayoutState=new _.Z
let a=0
for(;a<li.MODULE_COUNT;)this.relayoutState.Add(0),a+=1
this.relayoutParam[0]=!0,this.relayoutParam[1]=g.P.zero_get(),this.relayoutParam[2]=-1,this.ir=t.cfgData_get(),this.er=t.cfgEquipData_get(),this.eInfo=t.equipInfo_get(),
this.auctionTipDesc.node.SetActive(!1),this.ShowWayBtn=!0,this.itemData=t,this.bagItemData=e,this.compareData=l,
this.itemData.isForBag&&(null!=t.serverData_get()&&null!=t.serverData_get().id&&(this.updateInterval=bt.C.Inst_get().SetFrameLoopForParm(this._degf_UpdateItemData,1,-1,t.serverData_get().id)),
this.bagItemData=C.g.Inst_get().GetItemById(this.itemData.serverData_get().id),
null==this.bagItemData&&(this.bagItemData=C.g.Inst_get().GetHouseItemById(this.itemData.serverData_get().id))),this.role=i,
null==i&&(-1==t.playerIdx?this.role=n.Y.Inst.PrimaryRoleInfo_get():this.role=n.Y.Inst.GetMultiPlayerInfoByCreateIdx(t.playerIdx)),this.equipment=t.serverData_get(),
this.btnModule.SetData(this.eInfo,this.itemData,this.bagItemData,this.er,this.ir,this.equipment,this,this.isCanOperate),
xt.g.SetItemIcon(this.equipIcon.FatherId,this.equipIcon.ComponentId,t.cfgData_get().icon,Nt.b.eItem,!0),
null!=this.equipment&&xt.g.SetItemIcon(this.equipIcon.FatherId,this.equipIcon.ComponentId,this.equipment.GetItemRes().icon,Nt.b.eItem,!0),
null!=t.serverData_get()?this.lockObj.SetActive(Zt.t.IsBindState(t.serverData_get().state)):this.lockObj.SetActive(!1)
let o=0
const r=Wt.X.Inst_get().IsEquipHasLucky(this.equipment,this.eInfo)
this.excellenceCnt=Wt.X.Inst_get().GetEquipExcellenceCount(this.equipment,this.eInfo),this.star=Wt.X.Inst_get().GetEquipStarLevel(this.equipment,this.eInfo),
t.previewNextEquipNum>0&&(this.excellenceCnt+=t.previewNextEquipNum,this.star+=t.previewNextEquipNum)
const h=Wt.X.Inst_get().GetEquipEnhanceLevel(this.equipment,this.eInfo),d=Wt.X.Inst_get().GetEquipSuitProperty(this.equipment,this.eInfo),u=Wt.X.Inst_get().IsSpecialRing(this.equipment,this.eInfo),c=Wt.X.Inst_get().GetEquipGodType(this.equipment,this.eInfo)
if(this.er.equipType!=qt.R.GUARD&&this.excellenceCnt>=0&&!u)o=D.l.GetEquipQualityColor(this.excellenceCnt,this.star,r,h,d,c),this.qualityBg.spriteNameSet(D.l.GetTipQulityBg(o))
else{o=D.l.getEquipQuality(this.equipment,this.eInfo),-1==o&&(o=this.ir.Quality_get())
const t=D.l.GetQulityBgName(o)
this.qualityBg.spriteNameSet(t)}this.SetQualityAnim(o)
const I=Yt.D.getInstance().GetIntValue("TIPS:MAX_NUM_WORDS"),m=D.l.SetEquipName(this.eInfo,this.ir,this.equipment,null,!0,!0,t.previewNextEquipNum)
let p=m[0],S=m[2]
if((d>0||u||this.excellenceCnt>0)&&Ft.M.Length(S)>I){p=Ft.M.ReplaceOne(p,Ft.M.s_SPACE_CHAR,Ft.M.s_NN_CHAR),S=Ft.M.ReplaceOne(S,Ft.M.s_SPACE_CHAR,Ft.M.s_CCD_CHAR)
const t=Ft.M.Split(S,Ft.M.s_CCD_CHAR)
t.Count()>=2&&(S=t[1],Ft.M.Length(S)>I&&(p=Ft.M.ReplaceOne(p,Ft.M.s_SPACE_CHAR,Ft.M.s_NN_CHAR),p=Ft.M.ReplaceOne(p,Ft.M.s_NN_CHAR,Ft.M.s_SPACE_CHAR)))}this.nameLabel.textSet(p),
this.SetScore()
const f=jt.i.IsEquipedOn(this.role,this.equipment)
this.timeModule.SetData(t,this),this.auctionModule.SetData(t,this),this.demandModule.SetData(this.role,this.eInfo,t,this.equipment,this),
this.baseModule.SetData(this.role,this.eInfo,t,this.er,this.ir,this.equipment,this),this.angelModule.SetData(this.er,this),this.specialModule.SetData(this.er,this),
this.skillModule.SetData(this.er,this.equipment,this),this.excellenceModule.SetData(this.eInfo,t,this.er,this.ir,this.equipment,this),
this.godModule.SetData(this.er,this.ir,this.equipment,this),this.excellenceBaseModule.SetData(this.eInfo,t,this.er,this.ir,this.equipment,this),
this.additionalModule.SetData(t,this.er,this.equipment,this),this.SetExeAddUp(),
this.masterSuitModule.SetData(this.role,this.eInfo,this.er,this.equipment,Xt.n.eMaster,f[0],f[1],this),
this.angelSuitModule.SetData(this.role,this.eInfo,this.er,this.equipment,Xt.n.eAngel,f[0],f[1],this),
this.normalSuitModule.SetData(this.role,this.eInfo,this.er,this.equipment,Xt.n.eNormal,f[0],f[1],this),
this.enhanceSuitModule.SetData(this.role,this.eInfo,this.er,this.equipment,Xt.n.eEnhance,f[0],f[1],this),
this.multiSuitModule1.SetData(this.role,this.eInfo,this.er,this.equipment,Xt.n.eSuitEnhance1,f[0],f[1],this,!0,1),
this.multiSuitModule2.SetData(this.role,this.eInfo,this.er,this.equipment,Xt.n.eSuitEnhance2,f[0],f[1],this,!0,2),
this.multiSuitModule3.SetData(this.role,this.eInfo,this.er,this.equipment,Xt.n.eSuitEnhance3,f[0],f[1],this,!0,3),
this.multiSuitModule4.SetData(this.role,this.eInfo,this.er,this.equipment,Xt.n.eSuitEnhance4,f[0],f[1],this,!0,4),
this.multiSuitModule5.SetData(this.role,this.eInfo,this.er,this.equipment,Xt.n.eSuitEnhance5,f[0],f[1],this,!0,5),this.enhanceWingrefineModule.SetData(!0,this.er,this.equipment),
this.growModule.SetData(this.eInfo,this.er,this.equipment,this),this.reliveModule.SetData(this.role,this.equipment,this),this.elementEnhanceModule.SetData(this.equipment,this),
null==this.ir.describe||""==this.ir.describe?this.descObj.SetActive(!1):(this.descObj.SetActive(!0),this.descLabel.textSet(this.ir.describe)),
null==this.ir.describeChannel||""==this.ir.describeChannel?this.descChannelObj.SetActive(!1):(this.descChannelObj.SetActive(!0),
this.descChannelLabel.textSet(this.ir.describeChannel)),this.itemData.btnType==Ht.p.GetWay&&this.OnGetWayBtnClick(0,0),this.SetWayBtnVisible()}SetWayBtnVisible(){
null!=this.itemData&&null!=this.itemData.cfgData_get()&&null!=this.itemData.cfgData_get().accessList&&this.itemData.cfgData_get().accessList.count>0?this.getWayBtn.node.SetActive(this.ShowWayBtn):this.getWayBtn.node.SetActive(!1)
}UpdateGuardStar(){if(this.er.equipType==undefined.GUARD){const t=new _.Z
for(let e=0;e<=4;e++)t.Add({})
this.starContainer.data_set(t)}}UpdateItemData(t,e){if(!this.itemData.isForBag)return
const i=e
this.bagItemData=C.g.Inst_get().GetItemById(i),null==this.bagItemData&&(this.bagItemData=C.g.Inst_get().GetHouseItemById(this.itemData.serverData_get().id)),
null!=this.bagItemData&&(this.itemData=this.bagItemData.baseData_get()),this.btnModule.UpdateItemData(this.itemData,this.bagItemData)}SetExeAddUp(){}CalculateBgSize(){let t=1.5
t+=this.root.GetBoundsSize().y
const e=0!=this.itemData.AuctionState_get()
this.auctionTipDesc.node.SetActive(e),this.btnModule.btnShowCnt>0&&!e?this.BgOffset_set(t-this.hasBtnPanelSize.w):this.btnModule.btnShowCnt>0&&e?this.BgOffset_set(t-this.hasBtnAndAuctionPanelSize.w):this.btnModule.btnShowCnt<=0&&e?this.BgOffset_set(t-this.hasAuctionPanelSize.w):this.BgOffset_set(t-this.noBtnPanelSize.w)
}AdjustTipSize(t){const e=this.bgOffset
this.CalculateBgSize()
const i=0!=this.itemData.AuctionState_get()
if(t||e-this.bgOffset>.01||this.bgOffset-e>.01){const t=this.scrollBack.node.transform.GetLocalPosition()
if(0!=this.btnModule.btnShowCnt||i)if(0==this.btnModule.btnShowCnt||i){if(0!=this.btnModule.btnShowCnt&&i){
const e=new Ut.L(this.hasBtnAndAuctionPanelSize.x,this.hasBtnAndAuctionPanelSize.y,this.hasBtnAndAuctionPanelSize.z,this.hasBtnAndAuctionPanelSize.w)
e.y-=this.BgOffset_get()/2,e.w+=this.BgOffset_get(),this.scrollPanel.baseClipRegionSet(e),this.scrollBack.heightSet(c.GF.INT(e.w)),t.y=e.y}else if(0==this.btnModule.btnShowCnt&&i){
const e=new Ut.L(this.hasAuctionPanelSize.x,this.hasAuctionPanelSize.y,this.hasAuctionPanelSize.z,this.hasAuctionPanelSize.w)
e.y-=this.BgOffset_get()/2,e.w+=this.BgOffset_get(),this.scrollPanel.baseClipRegionSet(e),this.scrollBack.heightSet(c.GF.INT(e.w)),t.y=e.y}}else{
const e=new Ut.L(this.hasBtnPanelSize.x,this.hasBtnPanelSize.y,this.hasBtnPanelSize.z,this.hasBtnPanelSize.w)
e.y-=this.BgOffset_get()/2,e.w+=this.BgOffset_get(),this.scrollPanel.baseClipRegionSet(e),this.scrollBack.heightSet(c.GF.INT(e.w)),t.y=e.y}else{
const e=new Ut.L(this.noBtnPanelSize.x,this.noBtnPanelSize.y,this.noBtnPanelSize.z,this.noBtnPanelSize.w)
e.y-=this.BgOffset_get()/2,e.w+=this.BgOffset_get(),this.scrollPanel.baseClipRegionSet(e),this.scrollBack.heightSet(c.GF.INT(e.w)),t.y=e.y}const e=g.P.zero_get()
this.scrollPanel.node.transform.SetLocalPosition(e),g.P.Recyle(e),this.scrollPanel.clipOffsetSet(kt.V.TEMP_VECTOR2D_get()),this.scrollBack.node.transform.SetLocalPosition(t),
g.P.Recyle(t),this.scrollView.ResetPosition()
const s=this.scrollPanel.baseClipRegion()
this.scrollbg.widthSet(s.z-8),this.scrollbg.heightSet(s.w),this.scrollbg.node.transform.SetLocalPosition(new g.P(s.x,s.y,0))}}GetBagItemData(){
return null!=this.bagItemData&&null!=this.itemData&&null!=this.itemData.serverData_get()&&(this.bagItemData=C.g.Inst_get().GetItemById(this.itemData.serverData_get().id)),
this.btnModule.UpdateItemData(this.itemData,this.bagItemData),this.bagItemData}OnGetWayBtnClick(t,e){p.J.Inst_get().OnGetWay()}Relayout(t,e,i){let s=i[0]
const n=i[1]
let l=g.P.zero_get(),a=0
if(1==e[Jt.L.eTimeModule])a=this.timeModule.node.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),l=this.timeModule.node.transform.GetLocalPosition(),n.x=l.x,n.y-=8,s?n.y=0:n.y+=4,
this.timeModule.node.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,i[1]=n),e[Jt.L.eTimeModule]=2,i[2]=Jt.L.eTimeModule
else if(0==e[Jt.L.eTimeModule])return
if(1==e[Jt.L.eAuctionModule])a=this.auctionModule.node.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),l=this.auctionModule.node.transform.GetLocalPosition(),n.x=l.x,n.y-=15,s?n.y=0:n.y+=4,
this.auctionModule.node.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,i[1]=n),e[Jt.L.eAuctionModule]=2,i[2]=Jt.L.eAuctionModule
else if(0==e[Jt.L.eAuctionModule])return
if(1==e[Jt.L.eDemandModule])a=this.demandModule.node.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),l=this.demandModule.node.transform.GetLocalPosition(),n.x=l.x,n.y-=15,s?n.y=0:n.y+=4,
this.demandModule.node.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,i[1]=n),e[Jt.L.eDemandModule]=2,i[2]=Jt.L.eDemandModule
else if(0==e[Jt.L.eDemandModule])return
if(1==e[Jt.L.eBaseModule])a=this.baseModule.node.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),l=this.baseModule.node.transform.GetLocalPosition(),n.x=l.x,n.y-=15,s?n.y=0:n.y+=4,
this.baseModule.node.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,i[1]=n),e[Jt.L.eBaseModule]=2,i[2]=Jt.L.eBaseModule
else if(0==e[Jt.L.eBaseModule])return
if(1==e[Jt.L.eAngelModule])a=this.angelModule.node.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),l=this.angelModule.node.transform.GetLocalPosition(),n.x=l.x,n.y-=15,s?n.y=0:n.y+=4,
this.angelModule.node.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,i[1]=n),e[Jt.L.eAngelModule]=2,i[2]=Jt.L.eAngelModule
else if(0==e[Jt.L.eAngelModule])return
if(1==e[Jt.L.eSpecialModule])a=this.specialModule.node.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),l=this.specialModule.node.transform.GetLocalPosition(),n.x=l.x,n.y-=15,s?n.y=0:n.y+=4,
this.specialModule.node.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,i[1]=n),e[Jt.L.eSpecialModule]=2,i[2]=Jt.L.eSpecialModule
else if(0==e[Jt.L.eSpecialModule])return
if(1==e[Jt.L.eSkillModule])a=this.skillModule.node.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),l=this.skillModule.node.transform.GetLocalPosition(),n.x=l.x,n.y-=15,s?n.y=0:n.y+=4,
this.skillModule.node.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,n.y+=8,i[1]=n),e[Jt.L.eSkillModule]=2,i[2]=Jt.L.eSkillModule
else if(0==e[Jt.L.eSkillModule])return
if(1==e[Jt.L.eGodModule])a=this.godModule.node.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),l=this.godModule.node.transform.GetLocalPosition(),n.x=l.x,n.y-=15,s?n.y=0:n.y+=4,
this.godModule.node.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,i[1]=n),e[Jt.L.eGodModule]=2,i[2]=Jt.L.eGodModule
else if(0==e[Jt.L.eGodModule])return
if(1==e[Jt.L.eExcellenceBaseModule])a=this.excellenceBaseModule.node.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),l=this.excellenceBaseModule.node.transform.GetLocalPosition(),n.x=l.x,
n.y-=15,s?n.y=0:n.y+=4,this.excellenceBaseModule.node.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,i[1]=n),e[Jt.L.eExcellenceBaseModule]=2,i[2]=Jt.L.eExcellenceBaseModule
else if(0==e[Jt.L.eExcellenceBaseModule])return
if(1==e[Jt.L.eExcellenceModule])a=this.excellenceModule.luckyObj.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),l=this.excellenceModule.luckyObj.transform.GetLocalPosition(),n.x=l.x,
n.y-=15,s?n.y=0:n.y+=4,this.excellenceModule.luckyObj.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,i[1]=n),a=this.excellenceModule.ignoreObj.GetBoundsSize().y,
a>.1&&(g.P.Recyle(l),l=this.excellenceModule.ignoreObj.transform.GetLocalPosition(),n.x=l.x,n.y-=15,s?n.y=0:n.y+=4,this.excellenceModule.ignoreObj.transform.SetLocalPosition(n),
s=!1,i[0]=!1,n.y-=a,i[1]=n),a=this.excellenceModule.excellenceObj.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),l=this.excellenceModule.excellenceObj.transform.GetLocalPosition(),n.x=l.x,
n.y-=15,s?n.y=0:n.y+=4,this.excellenceModule.excellenceObj.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,i[1]=n),a=this.excellenceModule.auctionExcellenceObj.GetBoundsSize().y,
a>.1&&(g.P.Recyle(l),l=this.excellenceModule.auctionExcellenceObj.transform.GetLocalPosition(),n.x=l.x,n.y-=15,s?n.y=0:n.y+=4,
this.excellenceModule.auctionExcellenceObj.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,i[1]=n),a=this.excellenceModule.fourStarObj.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),
l=this.excellenceModule.fourStarObj.transform.GetLocalPosition(),n.x=l.x,n.y-=15,s?n.y=0:n.y+=4,this.excellenceModule.fourStarObj.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,
i[1]=n),a=this.excellenceModule.fiveStarObj.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),l=this.excellenceModule.fiveStarObj.transform.GetLocalPosition(),n.x=l.x,n.y-=15,s?n.y=0:n.y+=4,
this.excellenceModule.fiveStarObj.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,i[1]=n),a=this.excellenceModule.excellenceShowObj.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),
l=this.excellenceModule.excellenceShowObj.transform.GetLocalPosition(),n.x=l.x,n.y-=15,s?n.y=0:n.y+=4,this.excellenceModule.excellenceShowObj.transform.SetLocalPosition(n),s=!1,
i[0]=!1,n.y-=a,i[1]=n),e[Jt.L.eExcellenceModule]=2,i[2]=Jt.L.eExcellenceModule
else if(0==e[Jt.L.eExcellenceModule])return
if(1==e[Jt.L.eMasterSuitModule])a=this.masterSuitModule.node.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),l=this.masterSuitModule.node.transform.GetLocalPosition(),n.x=l.x,n.y-=15,
s?n.y=0:n.y+=4,this.masterSuitModule.node.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,n.y+=8,i[1]=n),e[Jt.L.eMasterSuitModule]=2,i[2]=Jt.L.eMasterSuitModule
else if(0==e[Jt.L.eMasterSuitModule])return
if(1==e[Jt.L.eAngelSuitModule])a=this.angelSuitModule.node.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),l=this.angelSuitModule.node.transform.GetLocalPosition(),n.x=l.x,n.y-=15,
s?n.y=0:n.y+=4,this.angelSuitModule.node.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,n.y+=8,i[1]=n),e[Jt.L.eAngelSuitModule]=2,i[2]=Jt.L.eAngelSuitModule
else if(0==e[Jt.L.eAngelSuitModule])return
if(1==e[Jt.L.eNormalSuitModule])a=this.normalSuitModule.node.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),l=this.normalSuitModule.node.transform.GetLocalPosition(),n.x=l.x,n.y-=15,
s?n.y=0:n.y+=4,this.normalSuitModule.node.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,n.y+=8,i[1]=n),e[Jt.L.eNormalSuitModule]=2,i[2]=Jt.L.eNormalSuitModule
else if(0==e[Jt.L.eNormalSuitModule])return
if(1==e[Jt.L.eEnhanceSuitModule])a=this.enhanceSuitModule.node.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),l=this.enhanceSuitModule.node.transform.GetLocalPosition(),n.x=l.x,n.y-=15,
s?n.y=0:n.y+=4,this.enhanceSuitModule.node.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,n.y+=8,i[1]=n),e[Jt.L.eEnhanceSuitModule]=2,i[2]=Jt.L.eEnhanceSuitModule
else if(0==e[Jt.L.eEnhanceSuitModule])return
if(1==e[Jt.L.eMultiSuitModule1])a=this.multiSuitModule1.node.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),l=this.multiSuitModule1.node.transform.GetLocalPosition(),n.x=l.x,n.y-=15,
s?n.y=0:n.y+=4,this.multiSuitModule1.node.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,n.y+=8,i[1]=n),e[Jt.L.eMultiSuitModule1]=2,i[2]=Jt.L.eMultiSuitModule1
else if(0==e[Jt.L.eMultiSuitModule1])return
if(1==e[Jt.L.eMultiSuitModule2])a=this.multiSuitModule2.node.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),l=this.multiSuitModule2.node.transform.GetLocalPosition(),n.x=l.x,n.y-=15,
s?n.y=0:n.y+=4,this.multiSuitModule2.node.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,n.y+=8,i[1]=n),e[Jt.L.eMultiSuitModule2]=2,i[2]=Jt.L.eMultiSuitModule2
else if(0==e[Jt.L.eMultiSuitModule2])return
if(1==e[Jt.L.eMultiSuitModule3])a=this.multiSuitModule3.node.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),l=this.multiSuitModule3.node.transform.GetLocalPosition(),n.x=l.x,n.y-=15,
s?n.y=0:n.y+=4,this.multiSuitModule3.node.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,n.y+=8,i[1]=n),e[Jt.L.eMultiSuitModule3]=2,i[2]=Jt.L.eMultiSuitModule3
else if(0==e[Jt.L.eMultiSuitModule3])return
if(1==e[Jt.L.eMultiSuitModule4])a=this.multiSuitModule4.node.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),l=this.multiSuitModule4.node.transform.GetLocalPosition(),n.x=l.x,n.y-=15,
s?n.y=0:n.y+=4,this.multiSuitModule4.node.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,n.y+=8,i[1]=n),e[Jt.L.eMultiSuitModule4]=2,i[2]=Jt.L.eMultiSuitModule4
else if(0==e[Jt.L.eMultiSuitModule4])return
if(1==e[Jt.L.eMultiSuitModule5])a=this.multiSuitModule5.node.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),l=this.multiSuitModule5.node.transform.GetLocalPosition(),n.x=l.x,n.y-=15,
s?n.y=0:n.y+=4,this.multiSuitModule5.node.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,n.y+=8,i[1]=n),e[Jt.L.eMultiSuitModule5]=2,i[2]=Jt.L.eMultiSuitModule5
else if(0==e[Jt.L.eMultiSuitModule5])return
if(1==e[Jt.L.eWingrefineModule])a=this.enhanceWingrefineModule.node.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),l=this.enhanceWingrefineModule.node.transform.GetLocalPosition(),n.x=l.x,
n.y-=15,s?n.y=0:n.y+=4,this.enhanceWingrefineModule.node.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,i[1]=n),e[Jt.L.eWingrefineModule]=2,i[2]=Jt.L.eWingrefineModule
else if(0==e[Jt.L.eWingrefineModule])return
if(1==e[Jt.L.eGrowModule])a=this.growModule.node.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),l=this.growModule.node.transform.GetLocalPosition(),n.x=l.x,n.y-=15,s?n.y=0:n.y+=4,
this.growModule.node.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,i[1]=n),e[Jt.L.eGrowModule]=2,i[2]=Jt.L.eGrowModule
else if(0==e[Jt.L.eGrowModule])return
if(1==e[Jt.L.eReliveModule])a=this.reliveModule.node.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),l=this.reliveModule.node.transform.GetLocalPosition(),n.x=l.x,n.y-=15,s?n.y=0:n.y+=4,
this.reliveModule.node.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y=n.y-a+8,i[1]=n),e[Jt.L.eReliveModule]=2,i[2]=Jt.L.eReliveModule
else if(0==e[Jt.L.eReliveModule])return
if(1==e[Jt.L.eElementEnhanceModule])a=this.elementEnhanceModule.node.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),l=this.elementEnhanceModule.node.transform.GetLocalPosition(),n.x=l.x,
n.y-=15,s?n.y=0:n.y+=4,this.elementEnhanceModule.node.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,n.y+=4,i[1]=n),e[Jt.L.eElementEnhanceModule]=2,
i[2]=Jt.L.eElementEnhanceModule
else if(0==e[Jt.L.eElementEnhanceModule])return
e[Jt.L.eAdditionPropModule]&&(a=this.additionalModule.node.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),l=this.additionalModule.node.transform.GetLocalPosition(),n.x=l.x,n.y-=30,
s?n.y=0:n.y+=4,this.additionalModule.node.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,n.y+=4,i[1]=n)),a=this.descObj.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),
l=this.descObj.transform.GetLocalPosition(),n.x=l.x,n.y-=15,s?n.y=0:n.y+=4,this.descObj.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,i[1]=n),
a=this.descChannelObj.GetBoundsSize().y,a>.1&&(g.P.Recyle(l),l=this.descChannelObj.transform.GetLocalPosition(),n.x=l.x,n.y-=8,s?n.y=0:n.y+=4,
this.descChannelObj.transform.SetLocalPosition(n),s=!1,i[0]=!1,n.y-=a,i[1]=n),this.AdjustTipSize(t),g.P.Recyle(l)}SetScore(){let t=""
t=(0,s.T)("[B28669]装备评分:[-]")
const e=E.I.Score(this.itemData,this.role.Job_get(),this.role)
if(t+=`[CCCBC4]${e}[-]`,this.img_addallvalue.node.SetActive(!1),null!=this.equipment&&this.itemData.isEquipCompare){this.img_addallvalue.node.SetActive(!0)
const i=this.compareData
let s=0
null!=i&&(s=E.I.Score(i,this.role.Job_get(),this.role)),s<e?(t+=`[5fb470](${Vt.p.Abs(s-e)})[-]`,
this.img_addallvalue.spriteNameSet("rybeibao_sp_0042.png")):s>e?(t+=`[d43e3e](${Vt.p.Abs(s-e)})[-]`,
this.img_addallvalue.spriteNameSet("rybeibao_sp_0043.png")):this.img_addallvalue.node.SetActive(!1)}this.totalScoreLabel.textSet(t),
T.I.calVec0.Set(this.totalScoreLabel.node.transform.GetLocalPosition().x+this.totalScoreLabel.width()/2,this.img_addallvalue.node.transform.GetLocalPosition().y,0),
this.img_addallvalue.node.transform.SetLocalPosition(T.I.calVec0)}HideObj(){this.scrollView.StopSpringPanel(),this.scrollView.ResetPosition(),this.timeModule.Hide(),
this.demandModule.Hide(),this.specialModule.Hide(),this.skillModule.Hide(),this.excellenceModule.Hide(),this.excellenceBaseModule.Hide(),this.angelSuitModule.Hide(),
this.normalSuitModule.Hide(),this.enhanceSuitModule.Hide(),this.multiSuitModule1.Hide(),this.multiSuitModule2.Hide(),this.multiSuitModule3.Hide(),this.multiSuitModule4.Hide(),
this.multiSuitModule5.Hide(),this.masterSuitModule.Hide(),this.additionalModule.Hide(),this.enhanceWingrefineModule.Hide(),this.growModule.Hide(),this.baseModule.Hide(),
this.auctionModule.Hide(),this.angelModule.Hide(),this.godModule.Hide(),this.reliveModule.Hide(),this.elementEnhanceModule.Hide()
let t=this.descObj.transform.GetLocalPosition()
t.y=1e4,this.descObj.transform.SetLocalPosition(t),g.P.Recyle(t),t=this.descChannelObj.transform.GetLocalPosition(),t.y=1e4,this.descChannelObj.transform.SetLocalPosition(t),
g.P.Recyle(t),EquipAddTimeControl.Inst().CloseView()}Destroy(){this.demandModule.Destroy(),this.timeModule.Destroy(),this.specialModule.Destroy(),this.baseModule.Destroy(),
this.enhanceWingrefineModule.Destroy(),this.excellenceModule.Destroy(),this.excellenceBaseModule.Destroy(),this.angelSuitModule.Destroy(),this.normalSuitModule.Destroy(),
this.enhanceSuitModule.Destroy(),this.multiSuitModule1.Destroy(),this.multiSuitModule2.Destroy(),this.multiSuitModule3.Destroy(),this.multiSuitModule4.Destroy(),
this.multiSuitModule5.Destroy(),this.masterSuitModule.Destroy(),this.growModule.Destroy(),this.auctionModule=null,this.angelModule.Destroy(),this.godModule.Destroy(),
this.reliveModule.Destroy(),this.elementEnhanceModule.Destroy(),this.auctionTipDesc=null,this.auctionTipBg=null
let t=0
for(;t<this.qualityAnimList.Count();)this.qualityAnimList[t]=null,t+=1
this.qualityAnimList.Clear(),this.qualityAnimList=null,this.btnModule.Destroy(),EquipAddTimeControl.Inst().CloseView()}}li.MODULE_COUNT=32
class ai extends d.f{constructor(){super(),this.baseTip=null,this.compareTip=null,this.closeBtn=null,this.leftOffset=null,this.rightOffset=null,this.bd1=null,this.bd2=null,
this.bagItem1=null,this.bagItem2=null,this.itemData=null,this.r=null,this.obtainViewId=0,this._degf_CloseTip=null,this._degf_CloseTip2=null,this._degf_OnBaseSetFinalPos=null,
this._degf_ShowTipHandler=null,this.modelTip=null,this.grid_player=null,this.boardtip=null,this.equip_width=null,this.compare_width=null,this.model_width=null,
this.board_width=null,this.leftOffset=new m.F(1,.5),this.rightOffset=new m.F(0,.5),this._degf_CloseTip=(t,e)=>this.CloseTip(t,e),this._degf_CloseTip2=(t,e)=>this.CloseTip2(t,e),
this._degf_OnBaseSetFinalPos=()=>this.OnBaseSetFinalPos(),this._degf_ShowTipHandler=t=>this.ShowTipHandler(t)}InitView(){super.InitView(),this.DestoryPanelLevel=d.f.DestoryLevel0,
this.baseTip=new li,this.baseTip.setBinderId(this.FatherId,this.FatherComponentID,1),this.baseTip.isCanOperate=!0,this.compareTip=new li,
this.compareTip.setBinderId(this.FatherId,this.FatherComponentID,2),this.compareTip.isCanOperate=!1,this.closeBtn=new a.W,
this.closeBtn.setId(this.FatherId,this.FatherComponentID,3),this.modelTip=new Lt,this.modelTip.setBinderId(this.FatherId,this.FatherComponentID,4),
this.grid_player=this.CreateComponent(o.A,5),this.grid_player.SetInitInfo("ui_equiptip_roleicon",this.CreateDelegate(this.OnInitRoleIcon)),this.boardtip=new h.T,
this.boardtip.setId(this.FatherId,this.FatherComponentID,6),this.m_handlerMgr.AddClearComponentAlwaysCache(this.grid_player)}OnAddToScene(){p.J.Inst_get().RefreshTip(f.r.Equip)}
OnActivated(){this.closeBtn.node.SetActive(C.g.Inst_get().viewBagType==S.D.attrTab),this.AddLis()}OnInitRoleIcon(t){const e=new Gt
return e.setId(t,null,0),e}ClearData(){this.RemoveLis(),this.CloseObtainView()}Clear(){this.ClearData(),ai.OffsetY0=0}AddLis(){this.baseTip.OnAddToScene(),
this.compareTip.OnAddToScene(),this.AddFullScreenCollider(this.node,this._degf_CloseTip),r.i.Get(this.closeBtn.node).RegistonClick(this._degf_CloseTip2),
l.i.Inst.AddEventHandler(v.g.ITEM_CLICK_SHOWTIP,this._degf_ShowTipHandler),l.i.Inst.AddEventHandler(v.g.EQUIP_TIP_CLICK_WEAR,this.CreateDelegate(this.OnSelectRole)),
l.i.Inst.AddEventHandler(v.g.EQUIP_TIP_SELECT_LEFT_ROLE,this.CreateDelegate(this.OnSelectRole)),
l.i.Inst.AddEventHandler(v.g.EQUIP_TIP_LEFT_MODEL,this.CreateDelegate(this.OnShowModel))}OnFullScreenColliderInit(){
null!=this.bd1&&(this.bd1.isForBag||this.bd1.isShowMask)?(u.N.inst.SetFullScreenColliderMask(this.node.FatherId,!0),
u.N.inst.SetFullScreenColliderThrough(this.node.FatherId,!1)):(u.N.inst.SetFullScreenColliderMask(this.node.FatherId,!1),
u.N.inst.SetFullScreenColliderThrough(this.node.FatherId,!0))}RemoveLis(){this.baseTip.Clear(),this.compareTip.Clear(),this.compareTip.node.SetActive(!1),
this.RemoveFullScreenCollider(),r.i.Get(this.closeBtn.node).RemoveonClick(this._degf_CloseTip2),l.i.Inst.RemoveEventHandler(v.g.ITEM_CLICK_SHOWTIP,this._degf_ShowTipHandler),
l.i.Inst.RemoveEventHandler(v.g.EQUIP_TIP_CLICK_WEAR,this.CreateDelegate(this.OnSelectRole)),
l.i.Inst.RemoveEventHandler(v.g.EQUIP_TIP_SELECT_LEFT_ROLE,this.CreateDelegate(this.OnSelectRole)),
l.i.Inst.RemoveEventHandler(v.g.EQUIP_TIP_LEFT_MODEL,this.CreateDelegate(this.OnShowModel))}ShowTipHandler(t){p.J.Inst_get().ClearShortDelay()}CloseTip(t,e){
p.J.Inst_get().CanShowAllotAttrMsgByClose()?this.baseTip.btnModule.ShowAllotAttrMsgByClose():p.J.Inst_get().CloseTipView()}CloseTip2(t,e){p.J.Inst_get().CloseTipView()}Destroy(){
this.baseTip.Destroy(),this.baseTip=null,this.compareTip.Destroy(),this.compareTip=null}SetData(t,e,i,s){if(this.bagItem1=null,this.bagItem2=null,null!=t&&(t[1]=null,
t.RemoveAt(1)),null!=e&&(e[1]=null,e.RemoveAt(1)),null!=t[0]&&null==i&&(i=-1==t[0].playerIdx?n.Y.Inst.PrimaryRoleInfo_get():n.Y.Inst.GetMultiPlayerInfoByCreateIdx(t[0].playerIdx)),
null!=t[1]&&null==s&&(s=-1==t[1].playerIdx?n.Y.Inst.PrimaryRoleInfo_get():n.Y.Inst.GetMultiPlayerInfoByCreateIdx(t[1].playerIdx)),this.bd1=t[0],this.bd2=t[1],
null!=e&&(this.bagItem1=e[0],this.bagItem2=e[1]),this.r=i,this.boardtip.node.SetActive(!1),
t[0].BagItemType_get()==f.r.Equip&&t[0].isEquipCompare&&p.J.Inst_get().isJudgeItemTipCompare){t.Count()>1&&t.RemoveAt(1),INS.itemTipManager.selectTipRole=null
let e=c.GF.INT32_MIN_VALUE_get(),i=c.GF.INT32_MIN_VALUE_get()
for(let t=0;t<=n.Y.Inst.primaryRoleInfoList.Count()-1;t++){const s=n.Y.Inst.primaryRoleInfoList[t]
null==INS.itemTipManager.selectTipRole&&y.b.IsRecommendJob(s.Job_get(),this.bd1.cfgData_get().Jobs_get())&&(INS.itemTipManager.selectTipRole=s),e=y.b.GetUpScoreForRole(s,this.bd1),
e>0&&e>i&&(i=e,INS.itemTipManager.selectTipRole=s)}return s=null,void this.OnSelectRole()}this.compareTip.node.SetActive(!1),this.modelTip.node.SetActive(!1),
this.grid_player.node.SetActive(!1),this.baseTip.node.SetActive(!0)
const l=p.J.Inst_get().EnoughCompareLv()
if(1==t.Count())null!=this.compareTip&&this.compareTip.node.SetActive(!1),null!=e&&e.Count()>0&&(this.bagItem1=e[0]),
this.baseTip.SetData(t[0],this.bagItem1,i,this._degf_OnBaseSetFinalPos),this.OnFullScreenColliderInit()
else if(2==t.Count())null!=e&&(e.Count()>0&&(this.bagItem1=e[0]),e.Count()>1&&(this.bagItem2=e[1])),this.baseTip.SetData(t[0],this.bagItem1,i,this._degf_OnBaseSetFinalPos),
l&&(this.bd1.autoGetInTip||(this.compareTip.node.SetActive(!0),this.compareTip.SetData(t[1],this.bagItem2,s,this._degf_OnBaseSetFinalPos)))
else if(3==t.Count()){const n=E.I.Score(t[1],s.Job_get()),a=E.I.Score(t[2],s.Job_get())
let o=null
o=n<a?t[1]:t[2],null!=e&&(e.Count()>0&&(this.bagItem1=e[0]),2==e.Count()&&(this.bagItem2=e[1]),3==e.Count()&&(this.bagItem2=n<a?e[1]:e[2])),
this.baseTip.SetData(t[0],this.bagItem1,i,this._degf_OnBaseSetFinalPos),l&&(this.bd1.autoGetInTip||(this.compareTip.node.SetActive(!0),
this.compareTip.SetData(o,this.bagItem2,s,this._degf_OnBaseSetFinalPos)))}this.layout(),this.ShowAccessView()}ShowAccessView(){
this.compareTip.node.activeSelf()||null==this.bd1||!this.bd1.isShowAccess?(this.baseTip.btnModule.SetBtnShowState(this.baseTip.btnModule.obtainWayBtn,!1),
this.baseTip.ShowWayBtn=!1,this.baseTip.btnModule.SetButtonState()):(this.baseTip.btnModule.SetBtnShowState(this.baseTip.btnModule.obtainWayBtn,!0),this.baseTip.ShowWayBtn=!0,
this.baseTip.btnModule.SetButtonState()),this.baseTip.SetWayBtnVisible(),this.bd1.autoGetInTip&&this.OpenObtainView()}OnGetWay(){
L._.Inst_get().IsOpen()?this.CloseObtainView():this.OpenObtainView()}OpenObtainView(){
A.f.Inst().getItemById(this.bd1.modelId_get()).AccessList_get().Count()>0?this.bd1.IsSetAccessPos()?this.OpenObtain(this.bd1.modelId_get(),this.bd1.accessPos):this.OpenObtain(this.bd1.modelId_get(),T.I.calVec0,this.baseTip.background):I.c.DebugError((0,
s.T)("装备没配获取途径：ID")+this.bd1.modelId_get())}CloseObtainView(){this.obtainViewId==w.w.Inst_get().lastOpenId&&(this.obtainViewId=0,L._.Inst_get().CloseView())}OpenObtain(t,e,i){
L._.Inst_get().OpenByItem(t,e,i),this.obtainViewId=w.w.Inst_get().lastOpenId}layout(){const t=new g.P
let e=0
this.baseTip.node.activeSelf()&&(e+=this.equip_width),this.compareTip.node.activeSelf()&&(e+=this.compare_width),this.modelTip.node.activeSelf()&&(e+=this.model_width),
this.boardtip.node.activeSelf()&&(e+=this.board_width),t.Set(e/2-this.equip_width/2+ai.OffsetY0,0,0),this.baseTip.node.transform.SetLocalPosition(t),
null==this.bd1.tipsPos||t.Set(t.x+this.bd1.tipsPos.x,this.bd1.tipsPos.y,this.bd1.tipsPos.z),this.baseTip.node.transform.SetLocalPosition(t),t.Set(t.x-this.compare_width,0,0),
this.compareTip.node.transform.SetLocalPosition(t),t.Set(-(e/2-this.model_width/2),0,0),this.modelTip.node.transform.SetLocalPosition(t),t.Set(-(e/2-this.equip_width/2),0,0),
this.boardtip.node.transform.SetLocalPosition(t),t.Set(-500,110,0),this.grid_player.node.transform.SetLocalPosition(t),g.P.Recyle(t),this.baseTip.SetPos(),this.compareTip.SetPos()}
OnBaseSetFinalPos(){const t=this.baseTip.node.transform.GetLocalPosition(),e=this.compareTip.node.transform.GetLocalPosition()
e.y=t.y,this.compareTip.node.transform.SetLocalPosition(e),g.P.Recyle(e)}GetTipPosition(t,e){const i=new m.F(.5,.5),s=i-t,n=new g.P(0,0,0)
return null==e&&(e=n),n.x=e.x+s.x*ai.bgWidth,n.y=e.y+s.y*ai.bgHeight,n.z=e.z,m.F.Recycle(i),m.F.Recycle(s),n}CallOnClose(){
null!=this.bd1&&null!=this.bd1.tipCloseHandler&&this.bd1.tipCloseHandler(this.bd1)}GetLeftRoleList(){const t=n.Y.Inst.primaryRoleInfoList,e=new _.Z
for(let i=0;i<=t.Count()-1;i++){const s=t[i]
y.b.IsRecommendJob(s.Job_get(),this.bd1.cfgData_get().Jobs_get())&&e.Add(s)}return e}OnSelectRole(){
if(null==INS.itemTipManager.selectTipRole)return this.compareTip.node.SetActive(!1),this.boardtip.node.SetActive(!1),this.modelTip.node.SetActive(!1),
this.grid_player.node.SetActive(!1),this.baseTip.SetData(this.bd1,this.bagItem1,this.r,this._degf_OnBaseSetFinalPos),void this.layout()
this.bd1.playerIdxSet(INS.itemTipManager.selectTipRole.createIdx)
let t=null
const e=D.l.GenerateEquipTipData(this.bd1,INS.itemTipManager.selectTipRole)
this.grid_player.node.SetActive(!0)
const i=this.GetLeftRoleList()
this.grid_player.data_set(i),1==e.count?(t=null,this.compareTip.node.SetActive(!1),this.modelTip.node.SetActive(!1),this.boardtip.node.SetActive(this.bd1.isEquipCompare)):(t=e[1],
t.isTakeOnEquip=!0,t.isCanOperate=!1,t.isShowAddPointTip=!1,t.playerIdx.playerIdxSet(INS.itemTipManager.selectTipRole.createIdx),this.compareTip.node.SetActive(!0),
this.boardtip.node.SetActive(!1),this.modelTip.node.SetActive(!1),this.compareTip.SetData(t,null,INS.itemTipManager.selectTipRole,this._degf_OnBaseSetFinalPos)),
this.baseTip.SetData(this.bd1,this.bagItem1,INS.itemTipManager.selectTipRole,this._degf_OnBaseSetFinalPos,t),this.layout()}OnShowModel(){const t=this.GetLeftRoleList()
0!=t.Count()&&(null==INS.itemTipManager.selectTipRole&&(INS.itemTipManager.selectTipRole=t[0]),this.grid_player.node.SetActive(!1),this.compareTip.node.SetActive(!1),
this.boardtip.node.SetActive(!1),this.modelTip.node.SetActive(!0),this.modelTip.SetData(INS.itemTipManager.selectTipRole,this.bd1),this.layout())}}ai.bgWidth=397,
ai.equip_width=400,ai.compare_width=500,ai.model_width=400,ai.board_width=500,ai.bgHeight=592,ai.OffsetY0=0},25220:(t,e,i)=>{i.d(e,{m:()=>d})
var s=i(86133),n=i(93877),l=i(30849),a=i(79534),o=i(59918),r=i(87923),h=i(7475)
class d extends l.C{constructor(...t){super(...t),this.typeLabel=null,this.typeObj=null,this._eq=null,this._er=null,this.parent=null,this.isEquipTip=!0}InitView(){super.InitView(),
this.typeLabel=new n.Q,this.typeLabel.setId(this.FatherId,this.FatherComponentID,1),this.typeObj=new n.Q,this.typeObj.setId(this.FatherId,this.FatherComponentID,2)}
SetData(t,e,i,s,n){null==n&&(n=!0),this._eq=i,this._er=e,this.parent=s,this.isEquipTip=n
const l=r.l.getEquiplvStr(e.equipColumnsList_get()[0]),a=this.GetEquipTypeStr(l)
this.typeLabel.textSet(a)
const o=r.l.getColorByQuality(r.l.GetQuality(t))
this.typeLabel.SetColor(o),this.typeObj.SetColor(o),this.node.SetActive(!0),this.OnReposition()}GetEquipTypeStr(t){if(this._er.equipType==o.R.GUARD)return(0,s.T)("守护")
let e=!1,i=t
return null==this._eq?(this._er.IsMasterEquip()&&(i=r.l.ConcatStr(i,(0,s.T)("大师")),e=!0),this._er.IsGodEquip()&&(i=r.l.ConcatStr(i,(0,s.T)("神装")),e=!0),
this._er.IsAngelEquip()&&(i=r.l.ConcatStr(i,(0,s.T)("大天使")),e=!0)):(this._eq.IsMasterEquip()&&(i=r.l.ConcatStr(i,(0,s.T)("大师")),e=!0),this._eq.IsGodEquip()&&(i=r.l.ConcatStr(i,(0,
s.T)("神装")),e=!0),this._eq.IsAngelEquip()&&(i=r.l.ConcatStr(i,(0,s.T)("大天使")),e=!0)),e||(i=r.l.ConcatStr(i,(0,s.T)("装备"))),i}Hide(){const t=this.node.transform.GetLocalPosition()
t.y=1e4,this.node.transform.SetLocalPosition(t),a.P.Recyle(t)}OnReposition(){if(this.isEquipTip){this.parent.SetReady(h.L.eTypeModule)}else{const t=this.parent
t.ReadyCnt_set(t.ReadyCnt_get()+1)}}}},30726:(t,e,i)=>{i.d(e,{g:()=>u})
var s=i(6665),n=i(30849),l=i(79534),a=i(7475),o=i(9057),r=i(93877),h=i(72005)
class d extends o.x{constructor(...t){super(...t),this.attrLabel=null,this.icon=null}InitView(){super.InitView(),this.attrLabel=new r.Q,
this.attrLabel.setId(this.FatherId,this.FatherComponentID,1),this.icon=new h.w,this.icon.setId(this.FatherId,this.FatherComponentID,2)}SetData(t){const e=t
this.icon.spriteNameSet(`comm_icon_000${4+e.type}`),this.attrLabel.textSet(e.name)}Clear(){}Destroy(){}}class u extends n.C{constructor(){super(),this.grid=null,this.parent=null,
this.isEquipTip=!0,this._degf_OnItemRefreshFun=null,this._degf_OnReposition=null,this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),
this._degf_OnReposition=()=>this.OnReposition()}InitView(){super.InitView(),this.grid=new s.A,this.grid.setId(this.FatherId,this.FatherComponentID,1),
this.grid.SetInitInfo("ui_equiptip_wingrefine_attr",this._degf_OnItemRefreshFun),this.grid.OnReposition_set(this._degf_OnReposition)}SetData(t,e,i,s){this.parent=t,
this.isEquipTip=e,this.node.SetActive(!1),this.OnReposition()}OnItemRefreshFun(t){const e=new d
return e.setId(t,null,0),e}OnReposition(){if(this.isEquipTip){this.parent.SetReady(a.L.eWingrefineModule)}else{const t=this.parent
t.ReadyCnt_set(t.ReadyCnt_get()+1)}}Hide(){const t=this.node.transform.GetLocalPosition()
t.y=1e4,this.node.transform.SetLocalPosition(t),l.P.Recyle(t)}Destroy(){this.grid.Destroy(),this.grid=null}}},39367:(t,e,i)=>{i.d(e,{G:()=>s})
class s{constructor(){this.job=0,this.isStar=!1,this.str=null,this.hasAnyStar=!1,this.priority=100,this.isShowStarCnt=!1,this.isUp=!1,this._attrType=null,this.isNew=!1}
attrType_get(){return this._attrType}attrType_set(t){this._attrType=t,this.SetRecommand()}SetRecommand(){}}},13375:(t,e,i)=>{i.d(e,{N:()=>a})
var s=i(83908),n=i(79534),l=i(48933)
class a extends((0,s.yk)()){constructor(...t){super(...t),this.hasStarPos=null,this.noStarPos=null}_initBinder(){this.hasStarPos=new n.P(-164,0,0),this.noStarPos=new n.P(-190,0,0)}
InitView(){}SetData(t){const e=t
this.star.node.SetActive(e.isStar),this.attr.textSet(e.str),this.new.SetActive(!1),this.up.SetActive(!1),e.isUp&&(this.up.SetActive(!0),
l.I.calVec0.Set(this.attr.node.transform.GetLocalPosition().x+this.attr.width()/2+15,this.attr.node.transform.GetLocalPosition().y,0),
this.up.transform.SetLocalPosition(l.I.calVec0)),e.isNew&&(this.new.SetActive(!0),
l.I.calVec0.Set(this.attr.node.transform.GetLocalPosition().x+this.attr.width()/2+15,this.attr.node.transform.GetLocalPosition().y+5,0),
this.new.transform.SetLocalPosition(l.I.calVec0))}Clear(){}Destroy(){}}},88838:(t,e,i)=>{i.d(e,{G:()=>a})
var s=i(9057),n=i(93877),l=i(72005)
class a extends s.x{constructor(...t){super(...t),this.attrLabel=null,this.star=null}InitView(){super.InitView(),this.attrLabel=new n.Q,
this.attrLabel.setId(this.FatherId,this.FatherComponentID,1),this.star=new l.w,this.star.setId(this.FatherId,this.FatherComponentID,2)}SetData(t){const e=t
this.star.node.SetActive(!0),this.attrLabel.textSet(e.str)}Clear(){}Destroy(){this.star=null,this.attrLabel=null}}},30993:(t,e,i)=>{i.d(e,{V:()=>s})
class s{constructor(){this.str="",this.titleStr="",this.suitNum=0,this.isSkill=!1}Test1(){return!0}S_Test(){return!0}}},34881:(t,e,i)=>{i.d(e,{s:()=>l})
var s=i(83908),n=i(29464)
class l extends((0,s.pA)(n.x)()){InitView(){super.InitView()}SetData(t){this.label.textSet(t)}SetLabelColor(t){this.label.SetColor(t)}Clear(){super.Clear()}Destroy(){
super.Destroy()}}},36529:(t,e,i)=>{i.d(e,{c:()=>g})
var s=i(93984),n=i(86133),l=i(38045),a=i(97461),o=i(98958),r=i(9057),h=i(30267),d=i(93877),u=i(98885),c=i(85602),_=i(92679),I=i(87923),m=i(88431)
class g extends r.x{constructor(){super(),this.numLabel=null,this.attrGrid=null,this.activeColor="[c67bff]",this.inactiveColor="[8e8279]",this.isReady=!1,
this._degf_OnItemRefreshFun=null,this._degf_OnReposition=null,this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),this._degf_OnReposition=()=>this.OnReposition()}IsReady_get(){
return this.isReady}IsReady_set(t){this.isReady=t,a.i.Inst.RaiseEvent(_.g.EQUIP_TIP_SUIT_MODULE_UPDATE)}InitView(){super.InitView(),this.numLabel=new d.Q,
this.numLabel.setId(this.FatherId,this.FatherComponentID,1),this.attrGrid=new h.V,this.attrGrid.setId(this.FatherId,this.FatherComponentID,2),
this.attrGrid.SetInitInfo("ui_equiptip_suitattritem",this._degf_OnItemRefreshFun),this.attrGrid.OnReposition_set(this._degf_OnReposition)}OnItemRefreshFun(t){const e=new m.F
return e.setId(t,null,0),e}SetDataEx(t){const e=t,i=new c.Z
if(""!=e.changeSuitStr)return this.numLabel.textSet(`[e2a66a]${e.changeSuitStr}[-]`),i.Add(" "),void this.attrGrid.data_set(i)
const l=e.suitCount
this.isReady=!1
const a=e.config.suitNum
let r=""
const h=new c.Z
h.Add(u.M.IntToString(a))
let d=null
d=3!=e.suitConfig.suitType?o.V.Inst().getStr(10197,s.h.eLangResource,h):o.V.Inst().getStr(10971,s.h.eLangResource,h),
l>=a?this.numLabel.textSet(`${this.activeColor}${d}[-]`):this.numLabel.textSet(`${this.inactiveColor}${d}[-]`)
const _=e.attrs.attrs
let m=0
for(;m<_.Count();){let t=""
2004==_[m].intType?t="":2005==_[m].intType?t="1/":2006==_[m].intType&&(t=(0,n.T)("等级/")),
2004!=_[m].intType&&2005!=_[m].intType&&2006!=_[m].intType?l>=a?(r=`${this.activeColor}${I.l.getAttrStrWithoutSign(_[m].intType)} +${I.l.getAttrValueStr(_[m].intType,_[m].value)}[-]`,
i.Add(r)):(r=`${this.inactiveColor}${I.l.getAttrStrWithoutSign(_[m].intType)} +${I.l.getAttrValueStr(_[m].intType,_[m].value)}[-]`,
i.Add(r)):l>=a?(r=`${this.activeColor}${I.l.getAttrStrWithoutSign(_[m].intType)} +${t}${I.l.getAttrValueStr(_[m].intType,_[m].value)}[-]`,
i.Add(r)):(r=`${this.inactiveColor}${I.l.getAttrStrWithoutSign(_[m].intType)} +${t}${I.l.getAttrValueStr(_[m].intType,_[m].value)}[-]`,i.Add(r)),m+=1}
I.l.IsEmptyStr(e.config.talentId),this.attrGrid.data_set(i)}OnReposition(){this.IsReady_set(!0)}SetSacredData(t){const e=t
this.isReady=!1
const i=e.config.suitNum
let s=`[${(0,l.tw)(i)}]${(0,n.T)("件激活:")}`
e.config.id,e.suitCount
this.numLabel.textSet(`${this.inactiveColor}${s}[-]`)
const a=new c.Z,o=e.attrs.attrs
let r=0
for(;r<o.Count();){const t=""
s=`${this.inactiveColor}${I.l.getAttrStrWithoutSign(o[r].intType)} +${t}${I.l.getAttrValueStr(o[r].intType,o[r].value)}[-]`,a.Add(s),r+=1}this.attrGrid.data_set(a)}SetData(t){
t.isScaredSuit?this.SetSacredData(t):this.SetDataEx(t)}Clear(){}Destroy(){this.attrGrid.Destroy(),this.attrGrid=null}}},41071:(t,e,i)=>{i.d(e,{e:()=>n})
var s=i(83908)
class n extends((0,s.zB)()){InitView(){}SetData(t){this.title.textSet(t.titleStr),this.attr.node.SetLocalPositionXYZ(""==t.titleStr?0:79,0,0),this.attr.textSet(t.str),
this.node.transform.height=this.attr.node.transform.height}Clear(){super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}}},7475:(t,e,i)=>{i.d(e,{L:()=>s})
var s={eTimeModule:0,eAuctionModule:1,eDemandModule:2,eBaseModule:3,eLegendModule:4,eAngelModule:5,eSpecialModule:6,eSkillModule:7,eGodModule:8,eFlagAwakeModule:9,
eFlagAwakeSkillModule:10,eFlagStripeAttrModule:11,eFlagStripeSkillModule:12,eFlagQualityModule:13,eExcellenceBaseModule:14,eExcellenceModule:15,eMasterSuitModule:16,
eAngelSuitModule:17,eNormalSuitModule:18,eEnhanceSuitModule:19,eMultiSuitModule1:20,eMultiSuitModule2:21,eMultiSuitModule3:22,eMultiSuitModule4:23,eMultiSuitModule5:24,
eWingrefineModule:25,eGrowModule:26,eJewelModule:27,eReliveModule:28,eElementEnhanceModule:29,eAdditionPropModule:30}},70391:(t,e,i)=>{i.d(e,{d:()=>it})
var s=i(17409),n=i(38935),l=i(56937),a=i(18202),o=i(31222),r=i(5494),h=i(52726),d=i(90034),u=i(80740),c=i(10802),_=i(74265),I=i(47174),m=i(59265),g=i(9986),p=i(6665),C=i(9776),S=i(93877),f=i(61911),y=i(85602),v=i(85770),D=i(72800),E=i(9057),T=i(72005),A=i(33314),L=i(65379)
class w extends E.x{constructor(...t){super(...t),this.icon=null,this.jobIcon=null,this.desc=null,this.quality=null,this.numLab=null,this.data=null}InitView(){super.InitView(),
this.icon=this.CreateComponent(T.w,1),this.jobIcon=this.CreateComponent(T.w,2),this.name=this.CreateComponent(S.Q,3),this.desc=this.CreateComponent(S.Q,4),
this.quality=this.CreateComponent(T.w,5),this.numLab=this.CreateComponent(S.Q,6)}Destroy(){super.Destroy()}SetData(t){this.data=t,this.AddLis()
const e=m.t.Inst_get().GetBuffCfg(t)
if(this.jobIcon.node.SetActive(!1),this.icon.spriteNameSet(e.icon),this.quality.spriteNameSet(L.C.Inst_get().GetQualitySmallSp(e.showQuality)),0!=e.job){
this.jobIcon.node.SetActive(!0)
const t=A.Z.GetJobSignIcon(e.job)
this.jobIcon.spriteNameSet(t)}this.name.textSet(e.name)
const i=m.t.Inst_get().GetBuffChooseTimes(t)
if(i>1){const[t,e,s]=this.name.node.transform.GetLocalPositionXYZ(),n=this.name.width()
this.numLab.node.transform.SetLocalPositionXYZ(t+n+20,-28,0),this.numLab.node.SetActive(!0),this.numLab.textSet(i)}else this.numLab.node.SetActive(!1)
this.desc.textSet(e.desc)}AddLis(){}RemoveLis(){}Clear(){this.data=null,this.RemoveLis(),super.Clear()}}class R extends f.f{constructor(...t){super(...t),this.closeBtn=null,
this.grid=null,this.scrollView=null,this.title=null,this.noEff=null,this.info=null}InitView(){super.InitView(),this.closeBtn=this.CreateComponent(g.W,1),
this.grid=this.CreateComponent(p.A,2),this.scrollView=this.CreateComponent(C.h,3),this.title=this.CreateComponent(S.Q,4),this.noEff=this.CreateComponent(S.Q,5),
this.grid.SetInitInfo("ui_exorcism_badgeeffect_item",null,w)}OnAddToScene(){this.AddLis(),this.UpdateView()}UpdateView(){this.noEff.node.SetActive(!1),
this.scrollView.node.SetActive(!1),this.info=v.a.Inst_get().copyRecordDic[D.S.Exorcism]
let t=!1
if(null==this.info||null==this.info.buffs)t=!0
else{0==this.info.buffs.Count()?t=!0:(this.scrollView.node.SetActive(!0),this.UpdateItemLis())}t&&this.noEff.node.SetActive(!0)}Clear(){super.Clear(),this.grid.Clear(),
this.RemoveLis()}Destroy(){this.grid.Destroy()}AddLis(){this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.OnCloseView))}RemoveLis(){}OnCloseView(){
it.Inst_get().CloseBadgeEffView()}UpdateItemLis(){const t=new y.Z,e=m.t.Inst_get().buffChooseTimes
e.LuaDic_Clear()
for(let i=0;i<=this.info.buffs.count-1;i++){const s=this.info.buffs[i]
t.Contains(s)?e.LuaDic_AddOrSetItem(s,e[s]+1):(t.Add(s),e.LuaDic_AddOrSetItem(s,1))}this.grid.data_set(t)}SortByRank(t,e){return t.rank-e.rank}}
var O=i(38045),G=i(67075),b=i(5924),M=i(99294),P=i(64732),B=i(78287),x=i(8889),N=i(98885),k=i(75696),V=i(92679),F=i(74657),U=i(80518),H=i(88653)
class q extends U.A{constructor(...t){super(...t),this.rangeTxt=null,this.grid=null,this.bg=null,this.infoObj=null,this.headIcon=null,this.nameLab=null,this.scoreLab=null,
this.uipanel=null,this.isShowInfo=null,this.treeData=null,this.data=null}InitView(){super.InitView(),this.rangeTxt=this.CreateComponent(S.Q,1),
this.grid=this.CreateComponent(p.A,2),this.bg=this.CreateComponent(T.w,3),this.infoObj=this.CreateComponent(M.z,4),this.headIcon=this.CreateComponent(T.w,5),
this.nameLab=this.CreateComponent(S.Q,6),this.scoreLab=this.CreateComponent(S.Q,7),this.uipanel=this.CreateComponent(x.$,8),this.grid.SetInitInfo("ui_baseitem",null,k.j),
this.isShowInfo=!1}Destory(){this.grid.Destroy(),super.Destory()}SetData(t){this.treeData=t
const e=t.data.id,i=t.data.vo,s=m.t.Inst_get().rankMap[e]
if(null==s)return
let n=""
this.isShowInfo=s.rank[2]==s.rank[1],n=s.rank[2]==s.rank[1]?(0,O.tw)(s.rank[2]):`${s.rank[1]}-${s.rank[2]}`,1==e?(this.rangeTxt.gradientTopSet(new H.I(1,193/255,61/255,1)),
this.rangeTxt.gradientBottomSet(new H.I(241/255,228/255,147/255,1)),
this.bg.spriteNameSet("ryjinjichang_sp_0003")):2==e?(this.rangeTxt.gradientTopSet(new H.I(123/255,161/255,200/255,1)),
this.rangeTxt.gradientBottomSet(new H.I(191/255,222/255,235/255,1)),this.bg.spriteNameSet("ryjinjichang_sp_0004")):(this.rangeTxt.gradientTopSet(new H.I(1,193/255,61/255,1)),
this.rangeTxt.gradientBottomSet(new H.I(246/255,206/255,147/255,1)),this.bg.spriteNameSet("ryjinjichang_sp_0005")),
null!=this.uipanel&&null!=t.data.depth&&this.uipanel.depthSet(t.data.depth+1),this.rangeTxt.textSet(`第${n}名`)
const l=s.rewardId
let a=null
if(l){a=F.A.GetReward(l).GetAllRewardList()}const o=s.titleReward
if(!N.M.IsNullOrEmpty(o)){const t=F.A.GetReward(o).GetAllRewardList()
null==a||t.AddRange(a),a=t}this.grid.data_set(a),this.isShowInfo?this.ShowInfo(i):this.ShowInfo(null),this.AddLis()}ShowInfo(t){
if(null==t)return void(null!=this.infoObj&&this.infoObj.SetActive(!1))
this.infoObj.SetActive(!0)
let e="0"
null!=t&&null!=t.rankValue&&(e=t.rankValue),this.nameLab.textSet(t.name),this.headIcon.spriteNameSet(A.Z.GetJobIcon(t.job,t.sex,!1)),this.scoreLab.textSet(`累计积分:${e}`)}
SetSelected(t){super.SetSelected(t)}GetMyTreeData(){return this.treeData}AddLis(){}RemoveLis(){}Clear(){this.data=null,this.grid.Clear(),this.RemoveLis(),super.Clear()}}
var Z=i(92178)
class j extends Z.E{constructor(...t){super(...t),this.rangeTxt=null,this.nameTxt=null,this.scoreTxt=null,this.headIcon=null,this.data=null}SetSelected(t){}GetMyTreeData(){
return this.treeData}InitView(){super.InitView(),this.rangeTxt=this.CreateComponent(S.Q,1),this.nameTxt=this.CreateComponent(S.Q,2),this.scoreTxt=this.CreateComponent(S.Q,3),
this.headIcon=this.CreateComponent(T.w,4)}Destory(){super.Destory()}SetMyTreeData(t,e){this.treeData=t,this.data=t.data
const i=this.data.vo
e?(this.rangeTxt.textSet(`我的排名:${this.data.rank}`),0==this.data.rank&&this.rangeTxt.textSet("我的排名:未上榜"),this.nameTxt.node.SetActive(!1)):(this.rangeTxt.textSet(this.data.rank),
this.nameTxt.node.SetActive(!0),this.nameTxt.textSet(i.name))
let s="0"
null!=i&&null!=i.rankValue&&(s=i.rankValue),this.headIcon.spriteNameSet(A.Z.GetJobIcon(i.job,i.sex,!1)),this.scoreTxt.textSet(`累计积分:${s}`),this.AddLis()}AddLis(){}RemoveLis(){}
Clear(){this.data=null,this.RemoveLis(),super.Clear()}}class X extends f.f{constructor(...t){super(...t),this.tree=null,this.treeScrollView=null,this.closeBtn=null,
this.myScore=null,this.myRank=null,this.deslab=null,this.grid=null,this.treeScrollBar=null,this.uipanel=null,this.doubleIcon=null,this.lis=null,this.lastTreeData=null,
this.myRankLv=null,this.timeid=null}InitView(){super.InitView(),this.tree=this.CreateComponent(P.f,1),this.treeScrollView=this.CreateComponent(C.h,2),
this.closeBtn=this.CreateComponent(g.W,3),this.myScore=this.CreateComponent(S.Q,5),this.myRank=this.CreateComponent(S.Q,6),this.deslab=this.CreateComponent(M.z,7),
this.grid=this.CreateComponent(p.A,8),this.treeScrollBar=this.CreateComponent(B._,9),this.uipanel=this.CreateComponent(x.$,10),this.doubleIcon=this.CreateComponent(M.z,11),
this.tree.SetTitleAndItemName("ui_exorcism_rankreward_item","ui_exorcism_rankreward_roleitem"),
this.tree.SetTreeItemDelegate(this.CreateDelegate(this.CreateRankRewardItem),this.CreateDelegate(this.CreateRankRoleItem)),
this.grid.SetInitInfo("ui_baseitem",this.CreateDelegate(this.OnCreateItem))}OnCreateItem(t){const e=new k.j
return e.setId(t,null,0),e.SetIconSize(60,60),e.SetBgSize(60,60),e}CreateRankRewardItem(t){const e=new q
return e.setId(t,null,0),e}CreateRankRoleItem(t){const e=new j
return e.setId(t,null,0),e}OnAddToScene(){this.tree.SetNeedAutoClose(!1),this.AddLis(),this.UpdateView()}SortById(t,e){return t-e}IsForceCloseByGoAccess(){return!0}UpdateView(){
const t=this.GetUIPanel()
this.lis=new y.Z
const e=m.t.Inst_get().rankMap.LuaDic_Keys()
e.Sort(this.CreateDelegate(this.SortById))
const i=m.t.Inst_get().GetRankInfo()
if(this.lastTreeData=null,null!=i){for(let s=0;s<=e.Count()-1;s++){const n=e[s],l=new G.t(0,(0,O.tw)(n),"0",(0,O.tw)(n),{id:n,depth:t})
l.expand=!0,s==e.Count()-1&&(this.lastTreeData=l),this.lis.Add(l)
const a=m.t.Inst_get().rankMap[n].rank,o=a[1]==a[2]
for(let e=a[1];e<=a[2];e++){const s=i.rankInfos[e-1]
if(null==s)break
if(o)l.data.vo=s
else{const i=new G.t(0,`${e}*`,(0,O.tw)(n),`${e}*`,{vo:s,rank:e,depth:t})
this.lis.Add(i)}}}this.tree.SetData(this.lis)
let s="暂未上榜"
null!=i.rank&&i.rank>0&&(this.myRankLv=i.rank,s=(0,O.tw)(i.rank)),this.myRank.textSet(s)
let n="0"
null!=i.selfRankInfo&&(n=i.selfRankInfo.rankValue),this.myScore.textSet(n)}this.UpdateReward(),this.UpdateDoubleGo()}UpdateView1(){this.lis=new y.Z
const t=new y.Z([{id:1,rank:"1-1",rewardId:"DAILY_TOTAL_RECHARGE_REWARD_101"},{id:2,rank:"2-9",rewardId:"DAILY_TOTAL_RECHARGE_REWARD_102"}]),e=new y.Z,i=new G.t(0,"1","0","1",t[0])
e.Add(i)
const s=new G.t(0,"4","0","4",t[1])
e.Add(s)
const n=new G.t(0,"2","1","2",{rank:3,name:"1",score:100})
e.Add(n)
const l=new G.t(0,"3","4","3",{rank:2,name:"2",score:99})
e.Add(l),this.tree.SetData(e)}UpdateDoubleGo(){const t=m.t.Inst_get().IsDoubleReward()
this.doubleIcon.SetActive(t)}UpdateReward(){if(null!=this.myRankLv){this.deslab.SetActive(0==m.t.Inst_get().RewardState()),this.grid.node.SetActive(!0)
const t=m.t.Inst_get().GetResByRank(this.myRankLv),e=t.rewardId
let i=null
if(!N.M.IsNullOrEmpty(e)){i=F.A.GetReward(e).GetAllRewardList()}const s=t.titleReward
if(!N.M.IsNullOrEmpty(s)){const t=F.A.GetReward(s).GetAllRewardList()
null==i?i=t:i.AddRange(t)}this.grid.data_set(i)}else this.deslab.SetActive(!1),this.grid.node.SetActive(!1)}Clear(){this.ClearTimer(),this.tree.Destroy(),this.RemoveLis(),
super.Clear()}Destroy(){this.tree.Destroy(),super.Destroy()}AddLis(){this.AddClickEvent(this.closeBtn,this.CreateDelegate(this.OnCloseView)),
this.tree.AddEventHandler(V.g.TREE_ITEM_CHENGE,this.CreateDelegate(this.ItemChangeHandler)),
this.tree.AddEventHandler(V.g.TREE_ITEM_CLICK,this.CreateDelegate(this.ItemClickHandler)),
this.m_handlerMgr.AddEventMgr(V.g.COPYRECORD_UPDATE,this.CreateDelegate(this.UpdateReward))}RemoveLis(){this.RemoveClickEvent(this.closeBtn,this.CreateDelegate(this.OnCloseView)),
this.tree.RemoveEventHandler(V.g.TREE_ITEM_CHENGE,this.CreateDelegate(this.ItemChangeHandler)),
this.tree.RemoveEventHandler(V.g.TREE_ITEM_CLICK,this.CreateDelegate(this.ItemClickHandler))}GetUIPanel(t){return this.uipanel.depth()}ItemChangeHandler(t){}ItemClickHandler(t){
this.timeid=b.C.Inst_get().SetFrameLoop(this.CreateDelegate(this.SetBarValue),1,1)}ClearTimer(){null!=this.timeid&&(b.C.Inst_get().ClearInterval(this.timeid),this.timeid=null)}
SetBarValue(){this.timeid=null,this.treeScrollView.UpdatePosition()}OnCloseView(){it.Inst_get().CloseRankRewardView()}}var Y=i(98958)
class W extends f.f{constructor(...t){super(...t),this.grid=null,this.deslab=null,this.timerlab=null,this.closebtn=null,this.time=null,this.TimerId=null}InitView(){
super.InitView(),this.grid=this.CreateComponent(p.A,1),this.deslab=this.CreateComponent(S.Q,2),this.timerlab=this.CreateComponent(S.Q,3),this.closebtn=this.CreateComponent(g.W,4),
this.grid.SetInitInfo("ui_baseitem",null,k.j)}OnAddToScene(){super.OnAddToScene()
const t=m.t.Inst_get().showRewardMsg,e=t.rewardId,i=t.rank,s=F.A.GetReward(e).GetAllRewardList()
this.grid.data_set(s),this.time=6,this.DowerTimer(),this.deslab.textSet(Y.V.Inst().replaceLangParamOne("恭喜你在上次试炼中获得第{0}名的成绩",i)),this.ClearTimer(),
this.TimerId=b.C.Inst_get().SetInterval(this.CreateDelegate(this.DowerTimer),1e3),this.m_handlerMgr.AddClickEvent(this.closebtn,this.CreateDelegate(this.CloseHandler))}
CloseHandler(){this.ClearTimer(),it.Inst_get().CloseExorcismRewardShowView()}DowerTimer(){this.time-=1,0!=this.time?this.timerlab.textSet(`确定(${this.time}s)`):this.CloseHandler()}
ClearTimer(){null!=this.TimerId&&b.C.Inst_get().ClearInterval(this.TimerId)}Clear(){this.ClearTimer(),super.Clear()}Destroy(){super.Destroy(),this.grid=null,this.deslab=null,
this.timerlab=null,this.closebtn=null}Test1(){return!0}S_Test(){return!0}}var $=i(68662),J=i(63076),z=i(29839),Q=i(24524),K=i(47786),tt=i(65550)
class et extends f.f{constructor(...t){super(...t),this.grid=null,this.label=null,this.clostbtn=null,this.btn=null,this.enterBtn=null,this.info=null,this.isComplete=null,
this.copyRes=null}InitView(){super.InitView(),this.grid=this.CreateComponent(p.A,1),this.label=this.CreateComponent(S.Q,2),this.clostbtn=this.CreateComponent(g.W,3),
this.btn=this.CreateComponent(g.W,4),this.enterBtn=this.CreateComponent(g.W,5),this.grid.SetInitInfo("ui_baseitem",null,k.j)}OnAddToScene(){super.OnAddToScene(),
this.UpdateRewardLis(),this.m_handlerMgr.AddClickEvent(this.clostbtn,this.CreateDelegate(this.CloseHandler)),
this.m_handlerMgr.AddClickEvent(this.enterBtn,this.CreateDelegate(this.OnEnterBtnHandle))}CloseHandler(){it.Inst_get().CloseExorcismTotalRewardView()}UpdateRewardLis(){
if(this.info=v.a.Inst_get().copyRecordDic[D.S.Exorcism],null==this.info)return
if(this.isComplete=!1,0!=this.info.maxCopyId)this.copyRes=Q.o.Inst().getNextItemByCopyType(D.S.Exorcism,this.info.maxCopyId),null==this.copyRes&&(this.isComplete=!0,
this.copyRes=Q.o.Inst().getItemById(this.info.maxCopyId))
else{const t=Q.o.Inst().allExorcismCopy
this.copyRes=t[0]}const t=this.info.rewards,e=new y.Z
if(null!=t&&null!=t.rewards){let i=0
for(;i<t.rewards.Count();){const s=J.M.wrapReward(t.rewards[i])
e.Add(s),i+=1}}if(0==e.Count()){const t=this.copyRes.SuccessRewardIdValue_get()
for(let i=0;i<=t.Count()-1;i++)if(null!=t[i]){const s=F.A.GetReward(t[i])
if(null!=s){const t=s.GetAllRewardList()
t.Count()>0&&e.AddRange(t)}}}this.grid.data_set(e)
const i=K.x.Inst().getItemStrById(11042407)
this.label.textSet(Y.V.Inst().replaceLangParamOne(i,this.copyRes.level)),this.UpdateEnterState()}UpdateEnterState(){if(this.enterBtn.node.SetActive(!1),null==this.info)return
const t=m.t.Inst_get().GetEndTime()
let e=!1;(0==t||$.D.serverTime_get()>=t)&&(e=!0),e||(this.IsFailure()?this.enterBtn.node.SetActive(!0):this.isComplete||this.enterBtn.node.SetActive(!0))}OnEnterBtnHandle(){
null!=this.info&&null!=this.copyRes&&(this.IsFailure()?tt.y.inst.ClientSysMessage(11042402):z.p.inst.SendEnterCopy(this.copyRes.id)),it.Inst_get().CloseExorcismTotalRewardView()}
IsForceCloseByGoAccess(){return!0}IsFailure(){return!1}Clear(){super.Clear()}Destroy(){super.Destroy(),this.grid=null,this.label=null,this.clostbtn=null,this.btn=null,
this.enterBtn=null}Test1(){return!0}S_Test(){return!0}}class it{constructor(){this.badgeEffView=null,this.rankRewardView=null,this.showRewardView=null,this.totalRewardView=null,
this.RegMsg()}static Inst_get(){return null==it._inst&&(it._inst=new it),it._inst}RegMsg(){}SendCM_GetRank(){_.k.Inst_get().CM_GetRank(I.c.EXORICISM_RANK,1,m.t.Inst_get().maxRank)}
SendCM_GetReward(){const t=new c.d
n.C.Inst.F_SendMsg(t)}OpenRyExorcismView(t){d.s.Inst_get().Open(u.F.Exorcism)}OpenBadgeEffView(){
if(null!=this.badgeEffView&&this.badgeEffView.isShow_get())return void this.badgeEffView.UpdateView()
const t=new l.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!1,o.N.inst.OpenById(r.I.ExorcismBadgeEffView,this.CreateDelegate(this.ShowBadgeEffViewHandler),this.CreateDelegate(this.DestroyBadgeEffViewHandler),t)
}CloseBadgeEffView(){(0,s.sR)(r.I.ExorcismBadgeEffView)}DestroyBadgeEffViewHandler(){a.g.DestroyUIObj(this.badgeEffView),this.badgeEffView=null}ShowBadgeEffViewHandler(t){
return null==this.badgeEffView&&(this.badgeEffView=new R,this.badgeEffView.setId(t,null,0)),this.badgeEffView}OpenRankRewardView(){
if(null!=this.rankRewardView&&this.rankRewardView.isShow_get())return void this.rankRewardView.UpdateView()
const t=new l.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!1,o.N.inst.OpenById(r.I.ExorcismRankRewardView,this.CreateDelegate(this.ShowRankRewardViewHandler),this.CreateDelegate(this.DestroyRankRewardViewHandler),t)
}CloseRankRewardView(){o.N.inst.CloseById(r.I.ExorcismRankRewardView),(0,s.sR)(r.I.ExorcismRankRewardView)}DestroyRankRewardViewHandler(){a.g.DestroyUIObj(this.rankRewardView),
this.rankRewardView=null}ShowRankRewardViewHandler(t){return null==this.rankRewardView&&(this.rankRewardView=new X,this.rankRewardView.setId(t,null,0)),this.rankRewardView}
OpenExorcismRewardShowView(){const t=new l.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!1,t.layerType=h.F.Alert,o.N.inst.OpenById(r.I.ExorcismRewardShowView,this.CreateDelegate(this.ExorcismRewardShowViewHandler),this.CreateDelegate(this.DestroyExorcismRewardShowViewHandler),t)
}CloseExorcismRewardShowView(){o.N.inst.CloseById(r.I.ExorcismRewardShowView)}DestroyExorcismRewardShowViewHandler(){a.g.DestroyUIObj(this.showRewardView),this.showRewardView=null}
ExorcismRewardShowViewHandler(t){return null==this.showRewardView&&(this.showRewardView=new W,this.showRewardView.setId(t,null,0)),this.showRewardView}
OpenExorcismTotalRewardView(){const t=new l.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!1,t.layerType=h.F.Alert,o.N.inst.OpenById(r.I.ExorcismTotalRewardView,this.CreateDelegate(this.ExorcismTotalRewardViewHandler),this.CreateDelegate(this.DestroyExorcismTotalRewardViewHandler),t)
}CloseExorcismTotalRewardView(){o.N.inst.CloseById(r.I.ExorcismTotalRewardView)}DestroyExorcismTotalRewardViewHandler(){a.g.DestroyUIObj(this.totalRewardView),
this.totalRewardView=null}ExorcismTotalRewardViewHandler(t){return null==this.totalRewardView&&(this.totalRewardView=new et,this.totalRewardView.setId(t,null,0)),
this.totalRewardView}}it._inst=null},66345:(t,e,i)=>{i.d(e,{W:()=>ut})
var s=i(98497),n=i(38935),l=i(56937),a=i(18202),o=i(31222),r=i(5494),h=i(52726),d=i(98789),u=i(95721),c=i(40162),_=i(81872),I=i(88351),m=i(11362),g=i(49876),p=i(65379),C=i(59265),S=i(5924),f=i(6665),y=i(93877),v=i(61911),D=i(35128),E=i(98130),T=i(85602),A=i(99294),L=i(9986),w=i(9057),R=i(72005),O=i(98885),G=i(85770),b=i(72800)
class M extends w.x{constructor(...t){super(...t),this.nextbtn=null,this.desLab=null,this.jobicon=null,this.icon=null,this.selectSp=null,this.nameLab=null,this.icon2=null,
this.recomonObj=null,this.data=null}InitView(){super.InitView(),this.nextbtn=this.CreateComponent(L.W,1),this.desLab=this.CreateComponent(y.Q,2),
this.jobicon=this.CreateComponent(R.w,3),this.icon=this.CreateComponent(R.w,4),this.selectSp=this.CreateComponent(A.z,5),this.nameLab=this.CreateComponent(y.Q,6),
this.icon2=this.CreateComponent(R.w,7),this.recomonObj=this.CreateComponent(A.z,8)}SetData(t){super.SetData(t),this.data=t,this.selectSp.SetActive(!1),
this.nextbtn.node.SetActive(!1),p.C.Inst_get().AddEventHandler(p.C.SELECT_BUFF,this.CreateDelegate(this.SelectBuffHandler)),
this.m_handlerMgr.AddClickEvent(this.nextbtn,this.CreateDelegate(this.ClickNextHandler)),this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.ClickHandler))
const e=p.C.Inst_get().GetJobSignIcon(this.data.job)
O.M.IsNullOrEmpty(e)?this.jobicon.node.SetActive(!1):(this.jobicon.node.SetActive(!0),this.jobicon.spriteNameSet(e))
let i=!1
if(null!=this.data.relatedId&&this.data.relatedId>0){const t=G.a.Inst_get().copyRecordDic[b.S.Exorcism]
null!=t&&null!=t.buffs&&(i=t.buffs.Contains(this.data.relatedId))}this.recomonObj.SetActive(i),this.nameLab.textSet(this.data.name),this.icon.spriteNameSet(this.data.icon),
this.icon2.spriteNameSet(p.C.Inst_get().GetQualitySp(this.data.showQuality)),this.desLab.textSet(this.data.desc_2),this.SelectBuffHandler(-1)}SelectBuffHandler(t){
this.selectSp.SetActive(this.index==t),this.nextbtn.node.SetActive(this.index==t),
this.index==t?this.icon.node.transform.SetLocalScaleXYZ(1,1,1):this.icon.node.transform.SetLocalScaleXYZ(.9,.9,1)}ClickNextHandler(){
p.C.Inst_get().RaiseEvent(p.C.SHOW_BUFF_EFF,this),ut.Inst_get().CloseExorcismBuffSelectView()}ClickHandler(){p.C.Inst_get().buffIdx=this.index,
p.C.Inst_get().RaiseEvent(p.C.SELECT_BUFF,this.index)}Clear(){p.C.Inst_get().RemoveEventHandler(p.C.SELECT_BUFF,this.CreateDelegate(this.SelectBuffHandler)),super.Clear()}
Destroy(){super.Destroy(),this.nextbtn=null,this.desLab=null,this.jobicon=null,this.icon=null,this.selectSp=null,this.nameLab=null,this.icon2=null}}class P extends v.f{
constructor(...t){super(...t),this.tipLab=null,this.grid=null,this.count=null,this.timerId=null,this.msg=null,this.buffIds=null}InitView(){super.InitView(),
this.tipLab=this.CreateComponent(y.Q,1),this.grid=this.CreateComponent(f.A,2),this.grid.SetInitInfo("ui_exorcism_copy_buffselectitem_ry",null,M)}OnAddToScene(){
super.OnAddToScene(),this.ClearTimer(),this.count=p.C.Inst_get().GetTiemr(1)+1,this.DownTimer(),this.timerId=S.C.Inst_get().SetInterval(this.CreateDelegate(this.DownTimer),1e3),
this.UpdateGrid(),p.C.Inst_get().buffIdx=-1}UpdateGrid(){this.msg=p.C.Inst_get().demonTrialSingleEndMsg,this.buffIds=this.msg.buffIds
const t=new T.Z
for(let e=0;e<=this.buffIds.count-1;e++){const i=C.t.Inst_get().GetBuffCfg(this.buffIds[e])
t.Add(i)}this.grid.data_set(t)}DownTimer(){this.count-=1,this.tipLab.textSet(`(${this.count}秒后自动选择)`),this.count<=0&&(this.ClearTimer(),this.SelectOneRandom())}SelectOneRandom(){
let t=p.C.Inst_get().buffIdx
if(-1==t){if(null==this.buffIds||0==this.buffIds.count)return void ut.Inst_get().CloseExorcismBuffSelectView()
t=E.GF.INT(D.p.RandomMinMax(0,this.buffIds.count)),t==this.buffIds.count&&(t=this.buffIds.count-1)}if(null!=this.grid.itemList&&null!=this.grid.itemList[t]){
const e=this.grid.itemList[t]
p.C.Inst_get().RaiseEvent(p.C.SHOW_BUFF_EFF,e),ut.Inst_get().CloseExorcismBuffSelectView()}}ClearTimer(){null!=this.timerId&&(S.C.Inst_get().ClearInterval(this.timerId),
this.timerId=null)}Clear(){this.ClearTimer(),super.Clear()}Destroy(){super.Destroy(),this.tipLab=null,this.grid=null}Test1(){return!0}S_Test(){return!0}}
var B=i(98800),x=i(62370),N=i(32759),k=i(35880),V=i(67292),F=i(3522),U=i(83540),H=i(21729),q=i(57522),Z=i(87923),j=i(29839),X=i(55492),Y=i(5031),W=i(5968)
class ${constructor(){this.showEff=!1,this.baseItem=null}Test1(){return!0}S_Test(){return!0}}var J=i(62063),z=i(75696)
class Q extends w.x{constructor(...t){super(...t),this.ui_baseitem=null,this.pre_eff_bag_boxopen_002=null,this.timerId2=null,this.timerId=null}InitView(){super.InitView(),
this.ui_baseitem=this.CreateComponentBinder(z.j,1),this.pre_eff_bag_boxopen_002=this.CreateComponent(F.k,2),this.pre_eff_bag_boxopen_002.node.SetActive(!1)}SetData(t){
this.RemoveEvent(),this.ui_baseitem.SetData(t.baseItem),t.showEff&&(this.ui_baseitem.node.SetActive(!1),this.AddEvent()),super.SetData(t)}Clear(){this.RemoveEvent(),super.Clear()}
AddEvent(){this.ClearTimer(),this.timerId2=S.C.Inst_get().SetInterval(this.CreateDelegate(this.OnRewardEffect1End),300*(this.index+1),1),
0==this.index?this.StartEff():this.timerId=S.C.Inst_get().SetInterval(this.CreateDelegate(this.StartEff),300*this.index,1)}RemoveEvent(){this.ClearTimer(),
J.U.RemoveEventFromFinishedHandler(this.pre_eff_bag_boxopen_002.FatherId,this.pre_eff_bag_boxopen_002.ComponentId,this.CreateDelegate(this.OnRewardEffect1End))}StartEff(){
this.timerId=null,this.pre_eff_bag_boxopen_002.node.SetActive(!1),this.pre_eff_bag_boxopen_002.node.SetActive(!0),this.pre_eff_bag_boxopen_002.SetResetOnPlay(!0),
this.pre_eff_bag_boxopen_002.Play(!0,!1)}OnRewardEffect1End(){this.timerId2=null,this.pre_eff_bag_boxopen_002.node.SetActive(!1),this.ui_baseitem.node.SetActive(!0)}ClearTimer(){
null!=this.timerId&&(S.C.Inst_get().ClearInterval(this.timerId),this.timerId=null),null!=this.timerId2&&(S.C.Inst_get().ClearInterval(this.timerId2),this.timerId2=null)}Destroy(){
super.Destroy(),this.ui_baseitem=null,this.pre_eff_bag_boxopen_002=null}Test1(){return!0}S_Test(){return!0}}class K extends v.f{constructor(...t){super(...t),this.failObj=null,
this.successObj=null,this.failtotalLab=null,this.rankLab=null,this.rankLab2=null,this.upLab=null,this.upSp=null,this.downSp=null,this.star0=null,this.star1=null,this.star2=null,
this.starLab=null,this.sucscoreLab=null,this.suctotalLab=null,this.grid=null,this.exitbtn=null,this.nextbtn=null,this.jobicon=null,this.jobicon2=null,this.eff0=null,this.eff1=null,
this.eff2=null,this.doubleAnim=null,this.efftotal=null,this.itemimgPos=null,this.itemimgPos1=null,this.itemimgPos2=null,this.itemimgPos3=null,this.itemimgPos4=null,
this.itemimg=null,this.itemimg1=null,this.itemimg2=null,this.itemimg3=null,this.itemimg4=null,this.bgreward0=null,this.bgreward1=null,this.backObj=null,this.itemimgScale=null,
this.itemimgScale1=null,this.itemimgScale2=null,this.itemimgScale3=null,this.itemimgScale4=null,this.label3=null,this.exitbtn2=null,this.scrollview=null,this.stars=null,
this.effs=null,this.tweenPos=null,this.tweenScale=null,this.itemimgs=null,this.needColseCommonHint=null,this.isEnd=null,this.TimerId2=null,this.TimerId1=null,this.isClick=null,
this.leftTime=null,this.downTimerId=null,this.res=null,this.showPosEff=null,this.rewards=null,this.msg=null,this.oldcopyTotolScore=null,this.idx=null,this.timerId=null,
this.rate=null,this.from=null,this.to=null,this.flyTimerId=null,this.nextTimerId=null}InitView(){super.InitView(),this.failObj=this.CreateComponent(A.z,1),
this.successObj=this.CreateComponent(A.z,2),this.failtotalLab=this.CreateComponent(y.Q,3),this.rankLab=this.CreateComponent(y.Q,4),this.rankLab2=this.CreateComponent(y.Q,5),
this.upLab=this.CreateComponent(y.Q,6),this.upSp=this.CreateComponent(R.w,7),this.downSp=this.CreateComponent(R.w,8),this.star0=this.CreateComponent(R.w,9),
this.star1=this.CreateComponent(R.w,10),this.star2=this.CreateComponent(R.w,11),this.starLab=this.CreateComponent(y.Q,12),this.sucscoreLab=this.CreateComponent(V.b,13),
this.suctotalLab=this.CreateComponent(V.b,14),this.grid=this.CreateComponent(f.A,15),this.exitbtn=this.CreateComponent(L.W,16),this.nextbtn=this.CreateComponent(L.W,17),
this.jobicon=this.CreateComponent(R.w,18),this.jobicon2=this.CreateComponent(R.w,19),this.eff0=this.CreateComponent(A.z,20),this.eff1=this.CreateComponent(A.z,21),
this.eff2=this.CreateComponent(A.z,22),this.efftotal=this.CreateComponent(A.z,23),this.itemimgPos=this.CreateComponent(N.c,24),this.itemimgPos1=this.CreateComponent(N.c,25),
this.itemimgPos2=this.CreateComponent(N.c,26),this.itemimgPos3=this.CreateComponent(N.c,27),this.itemimgPos4=this.CreateComponent(N.c,28),this.itemimg=this.CreateComponent(R.w,29),
this.itemimg1=this.CreateComponent(R.w,30),this.itemimg2=this.CreateComponent(R.w,31),this.itemimg3=this.CreateComponent(R.w,32),this.itemimg4=this.CreateComponent(R.w,33),
this.bgreward0=this.CreateComponent(A.z,34),this.bgreward1=this.CreateComponent(A.z,35),this.backObj=this.CreateComponent(A.z,36),this.itemimgScale=this.CreateComponent(k.d,37),
this.itemimgScale1=this.CreateComponent(k.d,38),this.itemimgScale2=this.CreateComponent(k.d,39),this.itemimgScale3=this.CreateComponent(k.d,40),
this.itemimgScale4=this.CreateComponent(k.d,41),this.label3=this.CreateComponent(A.z,42),this.exitbtn2=this.CreateComponent(L.W,43),this.scrollview=this.CreateComponent(A.z,44),
this.doubleAnim=this.CreateComponent(F.k,45),this.stars=new T.Z,this.stars.Add(this.star0),this.stars.Add(this.star1),this.stars.Add(this.star2),this.effs=new T.Z,
this.effs.Add(this.eff0),this.effs.Add(this.eff1),this.effs.Add(this.eff2),this.tweenPos=new T.Z,this.tweenPos.Add(this.itemimgPos),this.tweenPos.Add(this.itemimgPos1),
this.tweenPos.Add(this.itemimgPos2),this.tweenPos.Add(this.itemimgPos3),this.tweenPos.Add(this.itemimgPos4),this.tweenScale=new T.Z,this.tweenScale.Add(this.itemimgScale),
this.tweenScale.Add(this.itemimgScale1),this.tweenScale.Add(this.itemimgScale2),this.tweenScale.Add(this.itemimgScale3),this.tweenScale.Add(this.itemimgScale4),
this.itemimgs=new T.Z,this.itemimgs.Add(this.itemimg),this.itemimgs.Add(this.itemimg1),this.itemimgs.Add(this.itemimg2),this.itemimgs.Add(this.itemimg3),
this.itemimgs.Add(this.itemimg4),this.grid.SetInitInfo("ui_exorcism_copy_result_item",this.CreateDelegate(this.OnItemRefreshFun)),this.needColseCommonHint=!1}OnItemRefreshFun(t){
const e=new Q
return e.setId(t,null,0),e}Clear(){this.isEnd&&p.C.Inst_get().AddEvent(),this.needColseCommonHint&&W.Z.Inst.ClosePanel(),this.ClearBackTimer(),super.Clear(),
null!=this.tweenPos[0]&&(this.tweenPos[0].RemoveEventHandler(this.CreateDelegate(this.PlayPosEff2)),this.tweenPos[0].RemoveEventHandler(this.CreateDelegate(this.SetReward)),
this.tweenPos[0].Clear()),this.ClearDownTimerId(),null!=this.sucscoreLab&&(this.sucscoreLab.Clear(),this.suctotalLab.Clear()),
null!=this.TimerId2&&(S.C.Inst_get().ClearInterval(this.TimerId2),this.TimerId2=null),null!=this.TimerId1&&(S.C.Inst_get().ClearInterval(this.TimerId1),this.TimerId1=null),
this.ClearNextTimer(),this.ClearTimer()}Destroy(){super.Destroy(),this.failObj=null,this.successObj=null,this.failtotalLab=null,this.rankLab=null,this.rankLab2=null,
this.upLab=null,this.upSp=null,this.downSp=null,this.star0=null,this.star1=null,this.star2=null,this.starLab=null,this.sucscoreLab=null,this.suctotalLab=null,this.grid=null,
this.exitbtn=null,this.nextbtn=null,this.jobicon=null,this.jobicon2=null,this.eff0=null,this.eff1=null,this.eff2=null,this.doubleAnim=null}OnAddToScene(){super.OnAddToScene(),
this.m_handlerMgr.AddClickEvent(this.nextbtn,this.CreateDelegate(this.NextHandler)),this.m_handlerMgr.AddClickEvent(this.exitbtn,this.CreateDelegate(this.ExitHanlder3)),
this.m_handlerMgr.AddClickEvent(this.exitbtn2,this.CreateDelegate(this.ExitHanlder2)),this.isClick=!1,this.UpdateView()}ExitHanlder3(){
this.isClick?this.ExitHanlder():(this.isClick=!0,this.exitbtn.SetText(`退出(${this.leftTime}s)`),this.ReqGetReward(),this.FlyToBack())}NextHandler(){this.ClearNextTimer(),
ut.Inst_get().CloseExorcismResultView(),ut.Inst_get().OpenExorcismBuffSelectView()}DownTimerHandler(){this.leftTime-=1,
this.leftTime<0||(this.isEnd?this.isClick?this.exitbtn.SetText(`退出(${this.leftTime}s)`):this.exitbtn.SetText(`收下奖励(${this.leftTime}s)`):this.nextbtn.SetText(`继续挑战(${this.leftTime}s)`),
this.isEnd&&0==this.leftTime&&this.ExitHanlder())}ClearDownTimerId(){null!=this.downTimerId&&(S.C.Inst_get().ClearInterval(this.downTimerId),this.downTimerId=null)}ResetPos(t){
t>5&&(t=5),this.bgreward0.transform.SetLocalPositionXYZ(40*(5-t)-72,-68,0),this.bgreward1.transform.SetLocalPositionXYZ(397-40*(5-t),-68,0)}UpdateView(){
this.doubleAnim.node.SetActive(!1),this.res=G.a.Inst.GetCurCopyRes(),this.isEnd=p.C.Inst_get().isEnd,this.showPosEff=!1
for(let t=0;t<=this.stars.count-1;t++)this.stars[t].spriteNameSet("rycmsl_sp_0009"),this.effs[t].SetActive(!1)
for(let t=0;t<=this.tweenPos.count-1;t++)this.tweenPos[t].SetActive(!1)
this.ClearDownTimerId(),this.leftTime=this.res.escTime+1
const t=G.a.Inst_get().GetCopyRecByKey(b.S.Exorcism)
let e=null
if(this.isEnd){const t=p.C.Inst_get().demonTrialAllEndMsg
e=p.C.Inst_get().GetCopyRewardList(t.rewards)}else e=p.C.Inst_get().GetCopyRewardList(t.rewards)
const i=p.C.Inst_get().oldReward
this.showPosEff=null!=i&&!this.isEnd,this.rewards=new T.Z
const s=e.count
for(let t=0;t<=s-1;t++){const s=new $
s.baseItem=e[t],s.showEff=null==i&&!this.isEnd,this.rewards.Add(s)}p.C.Inst_get().oldReward=this.rewards,
s>=5?this.grid.node.transform.SetLocalPositionXYZ(-197,39,0):this.grid.node.transform.SetLocalPositionXYZ(40*(5-s)-197,39,0)
const n=B.Y.Inst.PrimaryRoleInfo_get().JobKind_get()
if(1==n?(this.jobicon.spriteNameSet("ryresult_sp_0025"),this.jobicon2.spriteNameSet("ryresult_sp_0028")):2==n?(this.jobicon.spriteNameSet("ryresult_sp_0026"),
this.jobicon2.spriteNameSet("ryresult_sp_0029")):3==n&&(this.jobicon.spriteNameSet("ryresult_sp_0003"),this.jobicon2.spriteNameSet("ryresult_sp_0007")),this.backObj.SetActive(!1),
this.isEnd){this.efftotal.SetActive(!1),this.efftotal.SetActive(!0)
const t=p.C.Inst_get().demonTrialAllEndMsg
this.exitbtn2.node.SetActive(!1),this.exitbtn.node.SetActive(!0),this.nextbtn.node.SetActive(!1),this.successObj.SetActive(!1),this.failObj.SetActive(!0)
const e=p.C.Inst_get().GetRankLv()
let i=t.rank;-1==i&&(i=9999)
const s=e-i
this.failtotalLab.textSet(Z.l.GetRuleDecimalValEx(t.totalScore.ToNum())),this.upSp.node.SetActive(s>0&&9999!=e),this.downSp.node.SetActive(s<0&&9999!=e),
this.upLab.node.SetActive(0!=s&&9999!=e),this.upLab.textSet(s),9999==e?this.rankLab.textSet("未上榜"):this.rankLab.textSet(e),this.rankLab2.textSet(i),
this.grid.data_set(this.rewards),this.ResetPos(this.rewards.count),this.ClearBackTimer(),null!=t&&t.isDouble&&this.PlayDoubleAnim()
}else if(this.msg=p.C.Inst_get().demonTrialSingleEndMsg,this.successObj.SetActive(!0),this.failObj.SetActive(!1),this.exitbtn.node.SetActive(!1),this.nextbtn.node.SetActive(!0),
this.oldcopyTotolScore=this.msg.totalScore.ToNum()-this.msg.score.ToNum(),this.oldcopyTotolScore<0&&(this.oldcopyTotolScore=0),this.suctotalLab.textSet(this.oldcopyTotolScore),
this.starLab.textSet(""),this.sucscoreLab.textSet(0),this.sucscoreLab.callback=this.CreateDelegate(this.SetSucTotal),this.leftTime=p.C.Inst_get().GetTiemr(0),this.StartPlayEff(),
null!=i){for(let t=0;t<=i.count-1;t++)i[t].showEff=!1
this.grid.data_set(i),this.ResetPos(i.count),this.label3.SetActive(!0)}else this.label3.SetActive(!1)
this.DownTimerHandler(),this.StartTime()}StartPlayEff(){this.idx=0,this.msg.star>0?(this.StarEff(),
null==this.timerId&&(this.timerId=S.C.Inst_get().SetInterval(this.CreateDelegate(this.StarEff),500))):this.ScoreEff()}StarEff(){this.idx+=1,
this.idx>this.msg.star?this.ScoreEff():(this.effs[this.idx-1].SetActive(!0),this.stars[this.idx-1].spriteNameSet("rycmsl_sp_0008"))}ScoreEff(){if(this.ClearTimer(),this.rate=1,
null!=this.res.extraRewardId){const t=x.o.GetStringArr(this.res.extraRewardId)
null!=t[this.msg.star]&&(this.rate=O.M.String2Double(t[this.msg.star]))}this.from=0,this.to=this.msg.score.ToNum(),0==this.msg.star?(this.from=this.msg.score.ToNum(),
this.starLab.textSet(""),this.SetSucTotal(),this.ShowNextSorce2()):(this.starLab.textSet(""),this.from=E.GF.INT(this.msg.score.ToNum()/this.rate),
this.sucscoreLab.textSet(this.from),null==this.TimerId1&&(this.TimerId1=S.C.Inst_get().SetInterval(this.CreateDelegate(this.ShowNextSorce1),200,1)))}ShowNextSorce1(){
if(this.TimerId1=null,this.rate<=1)this.ShowNextSorce2()
else{const[t,e,i]=this.sucscoreLab.node.transform.GetLocalPositionXYZ(),s=this.sucscoreLab.width()
this.starLab.node.transform.SetLocalPositionXYZ(t+s+10,e,i),this.starLab.textSet(`(${this.msg.star}星通关X${this.rate})`),
null==this.TimerId2&&(this.TimerId2=S.C.Inst_get().SetInterval(this.CreateDelegate(this.ShowNextSorce2),200,1))}}ShowNextSorce2(){this.TimerId2=null,
p.C.Inst_get().copyTotolScore=this.msg.totalScore.ToNum(),this.from==this.to&&this.SetReward(),this.sucscoreLab.ChangeNumberFromTo(this.from,this.to,20,36,!0,!1,!0,"")}
PlayPosEff(){let t=this.rewards.count
if(t>5&&(t=5),0==t)return void this.SetReward()
const e=3.14,i=e/t
if(this.showPosEff)for(let e=0;e<=this.tweenPos.count-1;e++)if(t>e){this.tweenPos[e].SetActive(!0),
a.g.SetItemIcon(this.itemimgs[e].FatherId,this.itemimgs[e].ComponentId,this.rewards[e].baseItem.cfgData_get().icon,U.b.eItem,!1)
const t=D.p.RandomMinMax(90,110)
let s=t*H.N.Sin(i*e)
i*e>1.57&&(s=-s)
let n=t*H.N.Cos(i*e)
i*e>.785&&i*e<2.355&&(n=-n),s=530+s,n=88+n,this.tweenPos[e].SetFromXYZ(530,88,0),this.tweenPos[e].SetToXYZ(s,n,0),
0==e&&this.tweenPos[e].AddEventHandler(this.CreateDelegate(this.PlayPosEff2)),this.tweenPos[e].durationSet(.4),this.tweenPos[e].SetEnabled(!0),this.tweenPos[e].ResetToBeginning(),
this.tweenPos[e].PlayForward(),this.tweenScale[e].SetFromXYZ(.2,.2,1),this.tweenScale[e].SetToXYZ(1,1,1),this.tweenScale[e].durationSet(.4),this.tweenScale[e].SetEnabled(!0),
this.tweenScale[e].ResetToBeginning(),this.tweenScale[e].PlayForward()}}PlayPosEff2(){this.tweenPos[0].RemoveEventHandler(this.CreateDelegate(this.PlayPosEff2)),this.showPosEff=!1
for(let t=0;t<=this.tweenPos.count-1;t++){const[e,i,s]=this.tweenPos[t].node.transform.GetLocalPositionXYZ()
this.tweenPos[t].SetFromXYZ(e,i,s),this.tweenPos[t].SetToXYZ(162,-66,0),0==t&&this.tweenPos[t].AddEventHandler(this.CreateDelegate(this.SetReward)),
this.tweenPos[t].durationSet(.3),this.tweenPos[t].SetEnabled(!0),this.tweenPos[t].ResetToBeginning(),this.tweenPos[t].PlayForward()}}ClearBackTimer(){
null!=this.flyTimerId&&(S.C.Inst_get().ClearInterval(this.flyTimerId),this.flyTimerId=null)}ReqGetReward(){}FlyToBack(){this.flyTimerId=null
const t=this.rewards,e=(this.grid.MaxPerLine_get(),this.scrollview.transform.GetPosition())
if(null!=t&&t.Count()>0){this.backObj.SetActive(!0)
const i=Y.T.inst_get().GetWorldPosInRightBottom(X.x.BAG)
i.x=i.x/2-20,i.y=70-i.y,this.backObj.transform.SetPosition(i)
let s=0
for(let n=0;n<=t.Count()-1;n++){const l=t[n].baseItem.count,a=t[n].baseItem.cfgData_get().id
for(let t=1;t<=l;t++)q.h.Inst_get().PlayFlyItem(e,i,a,null,null,null,100*s),s+=1}this.flyTimerId=S.C.Inst_get().SetInterval(this.CreateDelegate(this.HideBack),1200,1)}}HideBack(){
this.flyTimerId=null,this.backObj.SetActive(!1)}SetReward(){if(this.showPosEff)this.PlayPosEff()
else{for(let t=0;t<=this.tweenPos.count-1;t++)this.tweenPos[t].SetActive(!1)
this.tweenPos[0].RemoveEventHandler(this.CreateDelegate(this.SetReward)),this.grid.data_set(this.rewards),this.ResetPos(this.rewards.count),this.label3.SetActive(!0)
const t=p.C.Inst_get().demonTrialAllEndMsg
null!=t&&t.isDouble&&this.PlayDoubleAnim()}}PlayDoubleAnim(){this.doubleAnim.node.SetActive(!0),this.doubleAnim.SetResetOnPlay(!0),this.doubleAnim.ResumeAnim(),
this.doubleAnim.Play(!0,!1)}StartTime(){this.isEnd||(this.ClearNextTimer(),this.nextTimerId=S.C.Inst_get().SetInterval(this.CreateDelegate(this.NextHandler),1e3*this.leftTime)),
null==this.downTimerId&&(this.downTimerId=S.C.Inst_get().SetInterval(this.CreateDelegate(this.DownTimerHandler),1e3))}ClearNextTimer(){
null!=this.nextTimerId&&(S.C.Inst_get().ClearInterval(this.nextTimerId),this.nextTimerId=null)}ClearTimer(){null!=this.timerId&&(S.C.Inst_get().ClearInterval(this.timerId),
this.timerId=null)}SetSucTotal(){this.suctotalLab.callback=this.CreateDelegate(this.SetReward),
this.suctotalLab.ChangeNumberFromTo(this.oldcopyTotolScore,this.msg.totalScore.ToNum(),20,36,!0,!1,!0,"")}ExitHanlder(){this.ClearDownTimerId(),j.p.inst.ExitCopy(),
ut.Inst_get().CloseExorcismResultView()}ExitHanlder2(){this.needColseCommonHint=!0,W.Z.Inst.OpenCopyExitHintView(this.CreateDelegate(this.IsExit),null)}IsExit(t){
this.needColseCommonHint=!1,this.ClearDownTimerId(),j.p.inst.ExitCopy(),ut.Inst_get().CloseExorcismResultView()}}
var tt=i(9776),et=i(13113),it=i(60130),st=i(79534),nt=i(18152),lt=i(92679),at=i(70391),ot=i(30849),rt=i(85751)
class ht extends ot.C{constructor(...t){super(...t),this.label=null,this.starsp=null,this.label2=null,this.data=null,this.timeId=null,this.laststate=null}InitView(){
super.InitView(),this.label=this.CreateComponent(y.Q,1),this.starsp=this.CreateComponent(R.w,2),this.label2=this.CreateComponent(y.Q,3)}SetData(t){if(this.data=t,
null==this.data)return this.Clear(),void this.node.SetActive(!1)
this.node.SetActive(!0),this.AddEvent(),this.UpdateDes(),this.UpdateStar()}UpdateDes(){let t=""
this.data.type==p.C.TRIAL_ROLE_DEATH?(t=`死亡角色不超过${rt.u.BrightGreenColorStr2}${this.data.value}个[-]`,
this.m_handlerMgr.AddEventMgr(lt.g.PLAYER_DIE,this.CreateDelegate(this.UpdateStar))):this.data.type==p.C.TRIAL_TIME_REMAIN?(t=`剩余时间大于${rt.u.BrightGreenColorStr2}${this.data.value}秒[-]`,
null==this.timeId&&(this.timeId=S.C.Inst_get().SetInterval(this.CreateDelegate(this.UpdateStar),500))):this.data.type==p.C.TRIAL_HP_REMAIN?(t=`剩余血量不低于${rt.u.BrightGreenColorStr2}${this.data.value/100}%[-]`,
null==this.timeId&&(this.timeId=S.C.Inst_get().SetInterval(this.CreateDelegate(this.UpdateStar),500))):this.data.type==p.C.TRIAL_SUCCESS&&(t="击败所有怪物",
null==this.timeId&&(this.timeId=S.C.Inst_get().SetInterval(this.CreateDelegate(this.UpdateStar),500))),this.label.textSet(t)}UpdateStar(){
const[t,e]=p.C.Inst_get().GetStarState(this.data)
t!=this.laststate&&(t?this.starsp.spriteNameSet("rycmsl_sp_0008"):this.starsp.spriteNameSet("rycmsl_sp_0009"),this.laststate=t),this.label2.textSet(e)}AddEvent(){}RemoveEvent(){
null!=this.timeId&&(S.C.Inst_get().ClearInterval(this.timeId),this.timeId=null)}Clear(){this.RemoveEvent()}}class dt extends v.f{constructor(...t){super(...t),this.grid=null,
this.conditionItem=null,this.conditionItem1=null,this.conditionItem2=null,this.tltlelab=null,this.btnBadge=null,this.anchor=null,this.iconTweenPos=null,this.iconTweenScale=null,
this.icon=null,this.tipslab=null,this.rewardlab=null,this.bufficon=null,this.icon2=null,this.scrollview=null,this.eff=null,this.backObj=null,this.doubleIcon=null,this.items=null,
this.buffindex=null,this.bufficonName=null,this.timeEffId=null}InitView(){super.InitView(),this.grid=this.CreateComponent(f.A,1),
this.conditionItem=this.CreateComponentBinder(ht,2),this.conditionItem1=this.CreateComponentBinder(ht,3),this.conditionItem2=this.CreateComponentBinder(ht,4),
this.tltlelab=this.CreateComponent(y.Q,5),this.btnBadge=this.CreateComponent(L.W,6),this.anchor=this.CreateComponent(et.T,7),this.iconTweenPos=this.CreateComponent(N.c,8),
this.iconTweenScale=this.CreateComponent(k.d,9),this.icon=this.CreateComponent(R.w,10),this.tipslab=this.CreateComponent(y.Q,11),this.rewardlab=this.CreateComponent(y.Q,12),
this.bufficon=this.CreateComponent(R.w,13),this.icon2=this.CreateComponent(R.w,14),this.scrollview=this.CreateComponent(tt.h,15),this.eff=this.CreateComponent(A.z,16),
this.doubleIcon=this.CreateComponent(A.z,17),this.items=new T.Z,this.items.Add(this.conditionItem),this.items.Add(this.conditionItem1),this.items.Add(this.conditionItem2),
this.grid.SetInitInfo("ui_baseitem",this.CreateDelegate(this.OnItemRefreshFun)),this.icon.node.SetActive(!1)}OnItemRefreshFun(t){const e=new z.j
return e.setId(t,null,0),e}OnAddToScene(){super.OnAddToScene(),this.AddEvent(),this.UpdateView(),it.O.SetAnchorPos(this.anchor,!0,!0,0)}UpdateDoubleGo(){
const t=C.t.Inst_get().IsDoubleReward()
this.doubleIcon.SetActive(t)}AddEvent(){this.m_handlerMgr.AddClickEvent(this.btnBadge,this.CreateDelegate(this.ClickBadgeHandler)),
this.m_handlerMgr.AddEventMgr(lt.g.COPYRECORD_UPDATE,this.CreateDelegate(this.UpdateReward)),p.C.Inst_get().AddEventHandler(p.C.SHOW_BUFF_EFF,this.CreateDelegate(this.ShowBuffEff))
}RemoveEvent(){p.C.Inst_get().RemoveEventHandler(p.C.SHOW_BUFF_EFF,this.CreateDelegate(this.ShowBuffEff)),
null!=this.iconTweenPos&&this.iconTweenPos.RemoveEventHandler(this.CreateDelegate(this.playBuffEffEnd))}ShowBuffEff(t){this.iconTweenPos.node.SetActive(!0),
null!=t.data&&(this.icon.spriteNameSet(t.data.icon),this.icon2.spriteNameSet(p.C.Inst_get().GetQualitySp(t.data.showQuality)))
let e=t.node.transform.GetPosition(),i=it.O.WorldPosToLayoutLocalPosQuick(e,h.F.MainUI)
this.iconTweenPos.SetFrom(i),st.P.Recyle(e),st.P.Recyle(i),e=this.btnBadge.node.transform.GetPosition(),i=it.O.WorldPosToLayoutLocalPosQuick(e,h.F.MainUI),this.buffindex=t.index,
this.bufficonName=t.data.icon,this.iconTweenPos.SetTo(i),st.P.Recyle(e),st.P.Recyle(i),this.iconTweenPos.AddEventHandler(this.CreateDelegate(this.playBuffEffEnd)),
this.iconTweenPos.durationSet(1),this.iconTweenPos.SetEnabled(!0),this.iconTweenPos.ResetToBeginning(),this.iconTweenPos.PlayForward(),this.iconTweenScale.SetFromXYZ(1,1,1),
this.iconTweenScale.SetToXYZ(.3,.3,.3),this.iconTweenScale.durationSet(.8),this.iconTweenScale.SetEnabled(!0),this.iconTweenScale.ResetToBeginning(),
this.iconTweenScale.PlayForward()}playBuffEffEnd(){this.iconTweenPos.node.SetActive(!1),this.eff.SetActive(!1),this.eff.SetActive(!0),this.ClearTimer(),
this.timeEffId=S.C.Inst_get().SetInterval(this.CreateDelegate(this.ReqSelectBuff),300,1)}ClearTimer(){null!=this.timeEffId&&S.C.Inst_get().ClearInterval(this.timeEffId)}
ReqSelectBuff(){this.timeEffId=null,this.eff.SetActive(!1),ut.Inst_get().ReqSelectBuff(this.buffindex)}UpdateReward(){const t=G.a.Inst_get().GetCopyRecByKey(b.S.Exorcism)
let e=null
if(null==t.rewards){const t=G.a.Inst.GetCurCopyRes()
null!=t&&(e=t.getSuccessRewardItemList()),this.tipslab.node.SetActive(!1),this.rewardlab.textSet("本层奖励")}else e=p.C.Inst_get().GetCopyRewardList(t.rewards),
this.tipslab.node.SetActive(!0),this.rewardlab.textSet("累计奖励")
null==e&&(e=new T.Z)
for(let t=0;t<=e.count-1;t++)e[t].IconType_Set(nt.s.BASE_ICON_BAG_TYPE)
const[i,s,n]=this.grid.node.transform.GetLocalPositionXYZ(),l=this.grid.cellWidth()/2
1==e.count?this.grid.node.transform.SetLocalPositionXYZ(85,s,n):2==e.count?this.grid.node.transform.SetLocalPositionXYZ(8+l,s,n):this.grid.node.transform.SetLocalPositionXYZ(8,s,n),
this.grid.data_set(e),this.scrollview.SetEnabled(e.count>3)}UpdateView(){const t=G.a.Inst_get().GetCurCopyRes(),e=t.starTargetDefs_get().tCTargetDefs
for(let t=0;t<=this.items.count-1;t++)t<e.count?this.items[t].SetData(e[t]):this.items[t].SetData(null)
this.tltlelab.textSet(`第${t.level}层`),this.UpdateReward(),this.UpdateDoubleGo()}ClickBadgeHandler(){at.d.Inst_get().OpenBadgeEffView()}Clear(){this.ClearTimer(),this.RemoveEvent(),
super.Clear()}Destroy(){super.Destroy(),this.grid=null,this.conditionItem=null,this.conditionItem1=null,this.conditionItem2=null,this.tltlelab=null,this.btnBadge=null,
this.anchor=null,this.iconTweenPos=null,this.iconTweenScale=null,this.icon=null,this.tipslab=null,this.rewardlab=null,this.bufficon=null,this.icon2=null,this.scrollview=null,
this.eff=null,this.backObj=null}}class ut{constructor(){this.viewExorcismCopyTrace=null,this.viewExorcismResult=null,this.viewExorcismBuffSelect=null}static Inst_get(){
return null==ut._inst&&(ut._inst=new ut),ut._inst}DealEnterCopy(){p.C.Inst_get().InitCopyData(),this.OpenExorcismCopyTraceView()}DealExitCopy(){p.C.Inst_get().copyTotolScore=0,
this.CloseExorcismCopyTraceView(),this.CloseExorcismResultView(),p.C.Inst_get().ResetCopyData(),p.C.Inst_get().AddEvent()}OpenExorcismCopyTraceView(){
if(null!=this.viewExorcismCopyTrace)return void this.viewExorcismCopyTrace.OnAddToScene()
const t=new l.v
t.positionType=d.$.eCustom,t.layerType=h.F.DefaultUI,t.ReLoginOrChangeRoleIsDestroy=!1,
o.N.inst.OpenById(r.I.RyExorcismCopyTraceView,this.CreateDelegate(this.OnLoadExorcismCopyTraceView),this.CreateDelegate(this.DestroyExorcismCopyTraceView),t)}
CloseExorcismCopyTraceView(){o.N.inst.CloseById(r.I.RyExorcismCopyTraceView)}OnLoadExorcismCopyTraceView(t){
return null==this.viewExorcismCopyTrace&&(this.viewExorcismCopyTrace=new dt,this.viewExorcismCopyTrace.setId(t,null,0)),this.viewExorcismCopyTrace}DestroyExorcismCopyTraceView(){
null!=this.viewExorcismCopyTrace&&(a.g.DestroyUIObj(this.viewExorcismCopyTrace),this.viewExorcismCopyTrace=null)}OpenExorcismResultView(){p.C.Inst_get().IsCopyEnd=!0,
o.N.inst.ClearAllPanel(!0,!0)
const t=new l.v
t.positionType=d.$.eCustom,t.layerType=h.F.Alert,t.isShowMask=!0,o.N.inst.OpenById(r.I.RyExorcismCopyResultView,this.CreateDelegate(this.OnLoadExorcismResultView),this.CreateDelegate(this.DestroyExorcismResultView),t)
}CloseExorcismResultView(){o.N.inst.CloseById(r.I.RyExorcismCopyResultView)}OnLoadExorcismResultView(t){return null==this.viewExorcismResult&&(this.viewExorcismResult=new K,
this.viewExorcismResult.setId(t,null,0)),this.viewExorcismResult}DestroyExorcismResultView(){null!=this.viewExorcismResult&&(a.g.DestroyUIObj(this.viewExorcismResult),
this.viewExorcismResult=null)}OpenExorcismBuffSelectView(){const t=new l.v
t.positionType=d.$.eCustom,t.layerType=h.F.Alert,t.isShowMask=!0,t.maskAlpha=.8,
o.N.inst.OpenById(r.I.RyExorcismCopyBuffSelectView,this.CreateDelegate(this.OnLoadExorcismBuffSelectView),this.CreateDelegate(this.DestroyExorcismBuffSelectView),t)}
CloseExorcismBuffSelectView(){o.N.inst.CloseById(r.I.RyExorcismCopyBuffSelectView)}OnLoadExorcismBuffSelectView(t){
return null==this.viewExorcismBuffSelect&&(this.viewExorcismBuffSelect=new P,this.viewExorcismBuffSelect.setId(t,null,0)),this.viewExorcismBuffSelect}
DestroyExorcismBuffSelectView(){null!=this.viewExorcismBuffSelect&&(a.g.DestroyUIObj(this.viewExorcismBuffSelect),this.viewExorcismBuffSelect=null)}RegMsg(){
s.j.Inst.F_Register(-12004,I.c,this.CreateDelegate(this.SM_DemonTrialAllEndHandler)),s.j.Inst.F_Register(-12003,g.q,this.CreateDelegate(this.SM_DemonTrialSingleEndHandler)),
s.j.Inst.F_Register(-12007,m.U,this.CreateDelegate(this.SM_DemonTrialGainRankRewardHandler))}SM_DemonTrialGainRankRewardHandler(t){C.t.Inst_get().showRewardMsg=t,
at.d.Inst_get().OpenExorcismRewardShowView()}Test_DemonTrialAllEndHandler(){const t=new I.c
t.rank=5,t.totalScore=u.o.New(222222,2),this.SM_DemonTrialAllEndHandler(t)}SM_DemonTrialAllEndHandler(t){p.C.Inst_get().isEnd=!0,p.C.Inst_get().demonTrialAllEndMsg=t,
t.totalScore.Equal(u.o.ZERO)?c.v.inst.OpenPanel():this.OpenExorcismResultView()}SM_DemonTrialSingleEndHandler(t){p.C.Inst_get().isEnd=!1,p.C.Inst_get().demonTrialSingleEndMsg=t,
this.OpenExorcismResultView()}ReqSelectBuff(t){o.N.inst.ClearAllPanel(!0,!0)
const e=new _.E
e.index=t,n.C.Inst.F_SendMsg(e)}}ut._inst=null},57257:(t,e,i)=>{i.d(e,{A:()=>s})
class s{}s.RESET_TIME="RESET_TIME"},65379:(t,e,i)=>{i.d(e,{C:()=>S})
var s=i(98800),n=i(97461),l=i(16812),a=i(38935),o=i(98130),r=i(98885),h=i(85602),d=i(63076),u=i(92679),c=i(33314),_=i(29839),I=i(85770),m=i(90034),g=i(80740),p=i(75439),C=i(59265)
class S extends l.k{constructor(){super(),this.demonTrialAllEndMsg=null,this.demonTrialSingleEndMsg=null,this.isEnd=null,this.buffIdx=-1,this.copyTotolScore=0,this.timerlist=null,
this.oldReward=null,this.killMonNum=0,this.killMonSum=0,this.IsCopyEnd=!1,this.leftTime=0,this.timerlist=p.D.getInstance().GetIntArray("DEMONTRIAL_EXITTIME")}static Inst_get(){
return null==S._inst&&(S._inst=new S),S._inst}GetTiemr(t){return this.timerlist[t]}InitCopyData(){this.killMonNum=0,this.killMonSum=0,this.IsCopyEnd=!1
const t=I.a.Inst_get().GetCurCopyRes().SuccessConditions_get().successConditionList
if(null!=t)for(let e=0;e<=t.count-1;e++){const i=t[e]
"KILL_ANY_MONSTER"!=i.type&&"KILL_MONSTER"!=i.type||(this.killMonSum=r.M.String2Int(i.value))}n.i.Inst.AddEventHandler(u.g.MONSTER_DEAD,this.CreateDelegate(this.KillMonster)),
n.i.Inst.AddEventHandler(u.g.ROBOT_DEAD,this.CreateDelegate(this.KillMonster))}KillMonster(){this.killMonNum+=1}ResetCopyData(t){
n.i.Inst.RemoveEventHandler(u.g.MONSTER_DEAD,this.CreateDelegate(this.KillMonster)),n.i.Inst.RemoveEventHandler(u.g.ROBOT_DEAD,this.CreateDelegate(this.KillMonster))}
GetStarState(t){if(t.type==S.TRIAL_ROLE_DEATH){let e=0
const i=s.Y.Inst.primaryRoleList
for(let t=0;t<=i.count-1;t++)i[t].isdead&&(e+=1)
return[e<t.value,e]}return t.type==S.TRIAL_TIME_REMAIN?(this.IsCopyEnd||(this.leftTime=I.a.Inst_get().GetCopyLeftTimeExpectPre()),
[1e3*t.value<=this.leftTime,`${o.GF.INT(this.leftTime/1e3)}秒`]):t.type==S.TRIAL_HP_REMAIN?this.CheckPlayerHp(t.value):t.type==S.TRIAL_SUCCESS?[0==s.Y.Inst.MonsterDic.LuaDic_Count(),`${this.killMonNum}/${this.killMonSum}`]:[!0,""]
}CheckPlayerHp(t){let e=0,i=0
const n=t/1e4,l=s.Y.Inst.primaryRoleInfoList
for(let t=0;t<=l.count-1;t++)e+=l[t].CurrentHp_get(),i+=l[t].MaxHp_get()
0==i&&(i=1)
const a=e/i
return[a>=n,`${o.GF.INT(100*a)}%`]}GetCopyLeftTime(){return I.a.Inst_get().GetCopyLeftTime()}GetCopyRewardList(t){const e=new h.Z
if(null!=t){const i=t.rewards
for(let t=0;t<=i.count-1;t++){const s=d.M.wrapReward(i[t])
s.cfgData_get().CurrencyNum&&(s.count=s.cfgData_get().CurrencyNum),e.Add(s)}}return e}GetRankLv(){return C.t.Inst_get().GetRankLv()}GetJobSignIcon(t){return c.Z.GetJobSignIcon(t)}
AddEvent(){a.C.Inst.IsConnected()&&n.i.Inst.AddEventHandler(u.g.MAP_LOAD_COMPELETE,this.CreateDelegate(this.OpenViewHandler))}OpenViewHandler(){this.ClearData(),
_.p.inst.IsInCopy()||(this.oldReward=null,a.C.Inst.IsConnected()&&m.s.Inst_get().Open(g.F.Exorcism))}ClearData(){
n.i.Inst.RemoveEventHandler(u.g.MAP_LOAD_COMPELETE,this.CreateDelegate(this.OpenViewHandler))}GetQualitySp(t){
return 1==t?"rycmsl_sp_0011":2==t?"rycmsl_sp_0012":3==t?"rycmsl_sp_0013":"rycmsl_sp_0011"}GetQualitySmallSp(t){
return 1==t?"rycmsl_sp_0040":2==t?"rycmsl_sp_0038":3==t?"rycmsl_sp_0039":"rycmsl_sp_0040"}GetCopyBuffList(){return new h.Z}}S._inst=null,S.TRIAL_ROLE_DEATH="TRIAL_ROLE_DEATH",
S.TRIAL_TIME_REMAIN="TRIAL_TIME_REMAIN",S.TRIAL_HP_REMAIN="TRIAL_HP_REMAIN",S.TRIAL_SUCCESS="TRIAL_SUCCESS",S.SHOW_BUFF_EFF="SHOW_BUFF_EFF",S.SELECT_BUFF="SELECT_BUFF"},
59265:(t,e,i)=>{i.d(e,{t:()=>R})
var s=i(93984),n=i(38836),l=i(97461),a=i(68662),o=i(16812),r=i(55360),h=i(98885),d=i(85602),u=i(38962),c=i(77399),_=i(92679),I=i(85770),m=i(72800),g=i(37648),p=i(55492),C=i(24524),S=i(75439),f=i(56828),y=i(47174),v=i(14792),D=i(62734),E=i(50600),T=i(39043),A=i(84141),L=i(57257)
const w="EXORCISM_LAST_OPEN_TIME"
class R extends o.k{constructor(){super(),this.buffMap=null,this.rankMap=null,this.showRewardMsg=null,this.buffChooseTimes=null,this.severOpenDay=null,this.maxRank=null,
this.endTime=null,this.initRed=null,this.showNoticeAct=null
const t=r.Y.Inst.GetOrCreateCsv(s.h.eDemontrialbuffresourceCsv)
this.buffMap=t.GetCsvMap()
const e=r.Y.Inst.GetOrCreateCsv(s.h.eDemonTrialRankResource)
this.rankMap=e.GetCsvMap(),this.InitConfig(),this.buffChooseTimes=new u.X,this.severOpenDay=S.D.getInstance().GetIntValue("DEMONTRIAL_NOTICE_OPENDAY")}InitConfig(){
this.maxRank=S.D.getInstance().GetIntValue("DEMONTRIAL_RANKNUM")}IsInOpenDay(){return a.D.serverOpenDay_get()<=this.severOpenDay}static Inst_get(){
return null==R._inst&&(R._inst=new R),R._inst}GetBuffCfg(t){return this.buffMap.LuaDic_ContainsKey(t)?this.buffMap.LuaDic_GetItem(t):null}GetResByRank(t){for(const[e,i]of(0,
n.V5)(this.rankMap))if(i.rank[1]<=t&&t<=i.rank[2])return i
return null}GetRobotId(t){const e=I.a.Inst_get().GetCopyRecByKey(m.S.Exorcism)
return null!=e&&e.copyId2RobotId.LuaDic_ContainsKey(t)?e.copyId2RobotId.LuaDic_GetItem(t):null}SubmitFireEndTime(t){this.endTime=t,this.CheckShowRedPoint(),
this.RaiseEvent(L.A.RESET_TIME)}InitRedState(){null==this.initRed&&(this.initRed=!0,this.CheckShowRedPoint(),
l.i.Inst.AddEventHandler(_.g.COPYRECORD_UPDATE,this.CreateDelegate(this.CopyRecordUpdate)))}CopyRecordUpdate(){this.CheckShowRedPoint(),
c.x.Inst_get().UpdateTimeLimitShow(new d.Z([p.x.Exorcism]),!0)}IsDoubleReward(){const t=I.a.Inst_get().GetCopyRecByKey(m.S.Exorcism)
return null!=t&&t.isDouble}CheckShowRedPoint(){const t=this.HasReward(),e=I.a.Inst_get().GetCopyRecByKey(m.S.Exorcism)
let i=!1
if(null!=e){let t=!1
if(!(e.failTimes>0)){if(0!=e.maxCopyId){null==C.o.Inst().getNextItemByCopyType(m.S.Exorcism,e.maxCopyId)&&(t=!0)}t||(i=!0),i&&(i=this.CheckShowNoticeOpen())}}
this.showNoticeAct=i&&this.IsAct(),this.showNoticeAct?g.P.Inst_get().IsFunctionOpened(p.x.Exorcism)?D.f.Inst.SetState(v.t.EXORCISM_ACT,i):(this.showNoticeAct=!1,
D.f.Inst.SetState(v.t.EXORCISM_ACT,!1),l.i.Inst.AddEventHandler(_.g.FUNCTION_OPEN,this.CreateDelegate(this.FuncOpenHandler))):D.f.Inst.SetState(v.t.EXORCISM_ACT,!1),
D.f.Inst.SetState(v.t.EXORCISM_REWARD,t)}CheckIsCanShowIcon(){const t=I.a.Inst_get().GetCopyRecByKey(m.S.Exorcism)
return!(null!=t&&t.failTimes>0)}FuncOpenHandler(){
g.P.Inst_get().IsFunctionOpened(p.x.Exorcism)&&(l.i.Inst.RemoveEventHandler(_.g.FUNCTION_OPEN,this.CreateDelegate(this.FuncOpenHandler)),this.CheckShowRedPoint())}
CheckShowNoticeOpen(){const t=E.a.inst.GetDouble(T.V.Inst_get().GetRolePrefix()+w)
if(null==t)return!0
const e=a.D.serverTime_get()
if(e-t>86400)return!0
const i=A.E.New(1e3*e),s=A.E.New(1e3*t)
return s.getFullYear()<i.getFullYear()||(s.month_get()<i.month_get()||(s.date_get()<i.date_get()||i.hours_get()>20&&s.hours_get()<20))}SetNoticeOpen(){if(this.showNoticeAct){
const t=a.D.serverTime_get()
E.a.inst.SetValue(T.V.Inst_get().GetRolePrefix()+w,h.M.DoubleToString(t)),this.showNoticeAct=!1,D.f.Inst.SetState(v.t.EXORCISM_ACT,this.showNoticeAct)}}RewardState(){
const t=I.a.Inst_get().GetCopyRecByKey(m.S.Exorcism)
return null!=t?t.rankRewardStatus:0}GetBuffChooseTimes(t){return this.buffChooseTimes.LuaDic_GetItem(t)?this.buffChooseTimes.LuaDic_GetItem(t):0}HasReward(){
return 1==this.RewardState()}IsAct(){const t=this.GetEndTime()
let e=!0
return(0==t||a.D.serverTime_get()>=t)&&(e=!1),e}GetEndTime(){return null==this.endTime&&(this.endTime=0),this.endTime}GetRankInfo(){
return f.K.Inst_get().rankTypeDict.LuaDic_GetItem(y.c.EXORICISM_RANK)}GetRankLv(){const t=f.K.Inst_get().rankTypeDict.LuaDic_GetItem(y.c.EXORICISM_RANK)
return null==t||-1==t.rank?9999:t.rank}GetLockCopyRes(){let t=null
const e=I.a.Inst_get().copyRecordDic[m.S.Exorcism]
if(null==e||null==e.maxCopyId)return t
if(0!=e.maxCopyId)t=C.o.Inst().getNextItemByCopyType(m.S.Exorcism,e.maxCopyId),null==t&&(t=C.o.Inst().getItemById(e.maxCopyId))
else{t=C.o.Inst().allExorcismCopy[0]}return this.IsPassAll(),t}IsPassAll(){const t=I.a.Inst_get().copyRecordDic[m.S.Exorcism]
if(null==t||null==t.maxCopyId)return!1
if(0!=t.maxCopyId){return null==C.o.Inst().getNextItemByCopyType(m.S.Exorcism,t.maxCopyId)}return!1}ResetModel(){this.endTime=null}}R._inst=null},21725:(t,e,i)=>{i.d(e,{w:()=>et})
var s=i(43662),n=i(98800),l=i(97461),a=i(68662),o=i(13687),r=i(62370),h=i(5924),d=i(99294),u=i(9986),c=i(6665),_=i(78287),I=i(9776),m=i(93877),g=i(8889),p=i(29562),C=i(72005),S=i(13113),f=i(51868),y=i(85602),v=i(79534),D=i(63076),E=i(75696),T=i(92679),A=i(28287),L=i(55661),w=i(87923),R=i(29839),O=i(85770),G=i(72800),b=i(24524),M=i(75439),P=i(14792),B=i(62734),x=i(65550),N=i(35042),k=i(21334),V=i(19276),F=i(70391),U=i(57257),H=i(59265),q=i(23833),Z=i(26055),j=i(87722),X=i(28475),Y=i(31546),W=i(82737),$=i(9057),J=i(57834),z=i(52212),Q=i(27122)
class K extends $.x{constructor(){super(),this.locksp=null,this.left=null,this.right=null,this.bottomBg=null,this.layerTxtBg=null,this.layerTxt=null,this.complete=null,
this.widget=null,this.arrowWidget=null,this.rewardBtn=null,this.hasGet=null,this.hasreward=null,this.posX=0,this.posY=0,this.posZ=0,this.bottomLis=null,this.fontSize=null,
this.fontBgSize=null,this.sendRewards=null,this.isLock=null,this.data=null,this.info=null,this.isUnLock=null,this.isShowBoss=null,this.objRes=null,this.role=null,this.boss=null,
this.bottomLis=[new z.F(278,208),new z.F(222,166),new z.F(145,114)],this.fontSize=[20,18],this.fontBgSize=[new z.F(166,40),new z.F(133,32)]}InitView(){
this.locksp=this.CreateComponent(d.z,1),this.left=this.CreateComponent(d.z,2),this.right=this.CreateComponent(d.z,3),this.bottomBg=this.CreateComponent(C.w,4),
this.layerTxtBg=this.CreateComponent(C.w,5),this.layerTxt=this.CreateComponent(m.Q,6),this.complete=this.CreateComponent(d.z,7),this.widget=this.CreateComponent(S.T,8),
this.arrowWidget=this.CreateComponent(S.T,9),this.rewardBtn=this.CreateComponent(u.W,10),this.hasGet=this.CreateComponent(d.z,11),this.hasreward=this.CreateComponent(d.z,12)}
Clear(){this.RemoveLis(),this.ClearBoss()}Destroy(){this.m_Destroyed||this.Clear(),super.Destroy(),this.locksp=null,this.left=null,this.right=null,this.bottomBg=null,
this.layerTxtBg=null,this.layerTxt=null,this.complete=null,this.widget=null,this.arrowWidget=null,this.rewardBtn=null,this.hasGet=null,this.hasreward=null}AddLis(){
J.i.Get(this.node).RegistonClick(this.CreateDelegate(this.OnItemClick)),l.i.Inst.AddEventHandler(T.g.BOSS_SELECT,this.CreateDelegate(this.OnBossSelectHandle)),
this.m_handlerMgr.AddClickEvent(this.rewardBtn,this.CreateDelegate(this.OnRewardClick))}RemoveLis(){J.i.Get(this.node).RemoveonClick(this.CreateDelegate(this.OnItemClick)),
l.i.Inst.RemoveEventHandler(T.g.BOSS_SELECT,this.CreateDelegate(this.OnBossSelectHandle)),l.i.Inst.RemoveEventHandler(T.g.COPYRECORD_UPDATE,this.CreateDelegate(this.UpdateReward)),
this.m_handlerMgr.RemoveClickEvent(this.rewardBtn,this.CreateDelegate(this.OnRewardClick))}OnRewardClick(){
this.sendRewards?x.y.inst.ClientSysStrMsg("奖励已领取"):F.d.Inst_get().OpenExorcismTotalRewardView()}OnItemClick(){
this.isLock?x.y.inst.ClientSysStrMsg("击败上一关首领后解锁"):l.i.Inst.RaiseEvent(T.g.BOSS_SELECT,this.index)}OnBossSelectHandle(){}SetData(t){this.locksp.SetActive(!1),
this.rewardBtn.SetActive(!1),this.layerTxt.node.SetActive(!1),this.layerTxtBg.node.SetActive(!1),this.complete.SetActive(!1),
l.i.Inst.RemoveEventHandler(T.g.COPYRECORD_UPDATE,this.CreateDelegate(this.UpdateReward))
const e=b.o.Inst().allExorcismCopy,[i,s,n]=this.node.transform.GetLocalPositionXYZ(),a=e.Count()
if(null==t||-1==t)return this.left.SetActive(!1),this.right.SetActive(!1),this.bottomBg.SetActive(!1),void(-1!=t&&this.node.transform.SetLocalPositionXYZ(150+250*a,s,0))
this.data=t
const o=H.t.Inst_get().GetLockCopyRes().level
let r=!1,h=null
if(this.isLock=!0,t.level>o)this.locksp.SetActive(!0),h=this.bottomLis[3],this.right.transform.SetLocalPositionXYZ(-40,37,0),this.widget.SetAlpha(.5),
this.node.transform.SetLocalPositionXYZ(150+250*(t.level-1)+10,s,0)
else{this.isLock=!1,r=!0,this.layerTxt.node.SetActive(!0),this.layerTxtBg.node.SetActive(!0)
let e=null,i=0
this.info=O.a.Inst_get().copyRecordDic[G.S.Exorcism],t.id==this.info.maxCopyId&&this.complete.SetActive(!0),
t.level==o?(1==o?this.node.transform.SetLocalPositionXYZ(150+250*(t.level-1),s,0):this.node.transform.SetLocalPositionXYZ(150+250*(t.level-1)+10,s,0),
this.right.transform.SetLocalPositionXYZ(0,74,0),h=this.bottomLis[1],e=this.fontBgSize[1],i=this.fontSize[1],this.arrowWidget.SetAlpha(.5),this.isUnLock=!0,
this.rewardBtn.SetActive(1!=t.level),
this.UpdateReward(),l.i.Inst.AddEventHandler(T.g.COPYRECORD_UPDATE,this.CreateDelegate(this.UpdateReward))):(this.node.transform.SetLocalPositionXYZ(150+250*(t.level-1),s,0),
this.right.transform.SetLocalPositionXYZ(-24,48,0),h=this.bottomLis[2],e=this.fontBgSize[2],i=this.fontSize[2],this.complete.SetActive(!0)),this.layerTxtBg.widthSet(e.x),
this.layerTxtBg.heightSet(e.y),this.layerTxt.fontSizeSet(i),this.layerTxt.textSet(`第${t.level}层`)}t.level==a&&this.right.SetActive(!1),this.bottomBg.widthSet(h.x),
this.bottomBg.heightSet(h.y),this.isShowBoss=r,this.objRes=q.a.getInst().getObjById(t.bossShow,!1),r&&this.RefreshMonster(),this.AddLis()}UpdateReward(){
const t=O.a.Inst_get().copyRecordDic[G.S.Exorcism]
this.sendRewards=t.sendRewards,this.hasGet.SetActive(this.sendRewards),this.hasreward.SetActive(!t.sendRewards)}RefreshMonster(){if(this.isShowBoss){
const t=H.t.Inst_get().GetRobotId(this.data.id),e=q.a.getInst().getObjById(this.data.bossShow,!1)
this.ClearBoss()
let i=.6,n=null,l=null
if(null!=t&&t>0){this.role=Q.Q.Inst().GetObjectByName("Role",X.u),this.role.initEnd=this.CreateDelegate(this.ResetPos),this.role.InitRobotDisplayConfig(t,!0,K.STAGE_ID),
l=this.role,n=new v.P
b.o.Inst().allExorcismCopy.Count()
const e=this.data.level
n.x=1.3*(e-1)-.85,n.y=1.2*(e-1)-1,s.M.Instance_get().SetDisplayObject(K.STAGE_ID,l.MainRole_get().handle,0),this.role.SetDirection(180),this.isUnLock||(i*=.8),n.z=1
}else if(null!=e){n=new v.P(e.v_position.x,e.v_position.y,e.v_position.z);(b.o.Inst().allExorcismCopy.Count()-this.data.level)%2==1?n.x=.8+n.x:n.x=-.85+n.x,
n.y=n.y+.9*(this.data.level-1)-1
const t=new Z.O
this.boss=Q.Q.Inst().GetObjectByName("MonsterCharacter",j._),this.boss.Info_set(t)
const a=new Y.O
a._displayID=e.displayId,a._world=s.M.Instance_get().GetStageWorldType(K.STAGE_ID),a._bNeedWaitAnime=!0,a.shiledType=W.g.DT_NONE,this.boss.isphotoRole=!0,
this.boss.InitPhotoByInfo(e,a,n.y),l=this.boss,i=e.scale/1e4,s.M.Instance_get().SetDisplayObject(K.STAGE_ID,l.MainRole_get().handle,0),
null!=e&&null!=e.rotationList&&s.M.Instance_get().SetWorldRotation(K.STAGE_ID,0,new v.P(e.rotationList[0],e.rotationList[1],e.rotationList[2])),l.SetDirection(180),
this.isUnLock||(i*=.6)}null!=l&&([this.posX,this.posY,this.posZ]=[n.x,n.y,n.z],l.setPosXYZ(n.x,n.y,n.z),l.SetSize(i))}}ResetPos(){
null!=this.role&&this.role.setPosXYZ(this.posX,this.posY,this.posZ)}IsNeedShow(){return this.isShowBoss}IsShow(){return null!=this.boss}ClearBoss(){
null!=this.boss&&(this.boss.Destroy(),this.boss=null),null!=this.role&&(this.role.initEnd=null,this.role.Destroy(),this.role=null)}}K.STAGE_ID=150
class tt extends $.x{constructor(...t){super(...t),this.sortTxt=null,this.nameTxt=null,this.scoreTxt=null,this.firstGo=null,this.secondGo=null,this.threeGo=null,
this.noSortObj=null,this.data=null,this.bg=null}InitView(){super.InitView(),this.sortTxt=this.CreateComponent(m.Q,1),this.nameTxt=this.CreateComponent(m.Q,2),
this.scoreTxt=this.CreateComponent(m.Q,3),this.firstGo=this.CreateComponent(d.z,4),this.secondGo=this.CreateComponent(d.z,5),this.threeGo=this.CreateComponent(d.z,6),
this.noSortObj=this.CreateComponent(d.z,7)}SetData(t,e){if(this.data=t,this.noSortObj.SetActive(!1),this.firstGo.SetActive(!1),this.secondGo.SetActive(!1),
this.threeGo.SetActive(!1),this.scoreTxt.node.SetActive(!1),this.sortTxt.node.SetActive(!1),null!=t){let i=0
i=e||this.index+1,i<=0?this.noSortObj.SetActive(!0):(this.sortTxt.node.SetActive(!0),e?(this.scoreTxt.node.SetActive(!0),
this.sortTxt.textSet(`我的排名\n${i}`)):i>3?(this.scoreTxt.node.SetActive(!0),this.sortTxt.textSet(i)):(this.firstGo.SetActive(1==i),this.secondGo.SetActive(2==i),
this.threeGo.SetActive(3==i))),this.scoreTxt.node.SetActive(!0),this.nameTxt.textSet(t.name),this.scoreTxt.textSet(t.rankValue)}else if(e){this.noSortObj.SetActive(!0)
const t=n.Y.Inst.PrimaryRoleInfo_get().m_name
this.nameTxt.textSet(t),this.scoreTxt.node.SetActive(!0),this.scoreTxt.textSet(0)}}Clear(){super.Clear()}Destroy(){super.Destroy(),this.sortTxt=null,this.nameTxt=null,
this.scoreTxt=null,this.firstGo=null,this.secondGo=null,this.threeGo=null,this.noSortObj=null}SetBgVisible(t){this.bg.SetActive(t)}Test1(){return!0}S_Test(){return!0}}
class et extends f.${constructor(...t){super(...t),this.info=null,this.copyRes=null,this.isComplete=!1,this.bossInfo=null,this.enterBtn=null,this.endTimeTxt=null,
this.rewardDescTxt=null,this.rewardGrid=null,this.rankGrid=null,this.noRankGo=null,this.myRankItem=null,this.rankBtn=null,this.noOpenTxt=null,this.layerGrid=null,this.bar=null,
this.bossTexture=null,this.scrollview=null,this.completeGo=null,this.badgeBtn=null,this.scrollPanel=null,this.hasGet=null,this.canGet=null,this.rightWidget=null,this.enterSp=null,
this.redpointObj=null,this.scrollbar2=null,this.bossTextPosObj=null,this.pos=null,this.rate=null,this.enterTimerId=null,this.itemLis=null,this.boss=null,this.curBossData=null,
this.scrollIndex=null,this.showBossList=null,this.cfg=null,this.index=null,this.barTimer=null}InitView(){super.InitView(),this.enterBtn=this.CreateComponent(u.W,1),
this.endTimeTxt=this.CreateComponent(m.Q,2),this.rewardDescTxt=this.CreateComponent(m.Q,3),this.rewardGrid=this.CreateComponent(c.A,4),this.rankGrid=this.CreateComponent(c.A,5),
this.noRankGo=this.CreateComponent(d.z,6),this.myRankItem=this.CreateComponentBinder(tt,7),this.rankBtn=this.CreateComponent(u.W,8),this.noOpenTxt=this.CreateComponent(m.Q,9),
this.layerGrid=this.CreateComponent(c.A,10),this.bar=this.CreateComponent(_._,11),this.bossTexture=this.CreateComponent(p.V,12),this.scrollview=this.CreateComponent(I.h,13),
this.completeGo=this.CreateComponent(d.z,14),this.badgeBtn=this.CreateComponent(u.W,15),this.scrollPanel=this.CreateComponent(g.$,16),this.hasGet=this.CreateComponent(d.z,17),
this.canGet=this.CreateComponent(d.z,18),this.rightWidget=this.CreateComponent(S.T,19),this.enterSp=this.CreateComponent(C.w,20),this.redpointObj=this.CreateComponent(d.z,21),
this.scrollbar2=this.CreateComponent(_._,22),this.bossTextPosObj=this.CreateComponent(d.z,23),this.pos=new v.P,this.rankGrid.SetInitInfo("ui_exorcism_mainrank_item",null,tt),
this.rewardGrid.SetInitInfo("ui_baseitem",null,E.j),this.layerGrid.SetInitInfo("ui_exorcism_mainlayer_item",null,K),this.layerGrid.resetPos=!1,this.rate=1.56}ShowCurrencyBar_get(){
return A._.ShowGold_Score_BindDia}SetData(){this.AddLis(),this.UpdateView(),H.t.Inst_get().SetNoticeOpen()}UpdateRecord(){const t=this.copyRes
this.UpdateCopyInfo(),this.copyRes.level!=t.level&&this.UpdateView()}UpdateCopyInfo(){if(this.info=O.a.Inst_get().copyRecordDic[G.S.Exorcism],
null!=this.info&&null!=this.info.maxCopyId){if(this.isComplete=!1,0!=this.info.maxCopyId)this.copyRes=b.o.Inst().getNextItemByCopyType(G.S.Exorcism,this.info.maxCopyId),
null==this.copyRes&&(this.isComplete=!0,this.copyRes=b.o.Inst().getItemById(this.info.maxCopyId))
else{const t=b.o.Inst().allExorcismCopy
this.copyRes=t[0]}this.bossInfo=V.C.Inst().GetItemByMonsterId(this.copyRes.bossShow)}}UpdateView(){F.d.Inst_get().SendCM_GetRank(),this.UpdateCopyInfo(),this.UpdateEnterState(),
this.RefreshMonster(),this.UpdateLayerItemLis(),this.UpdateRewardLis()
const t=B.f.Inst.GetData(P.t.EXORCISM_REWARD)
null!=t&&this.redpointObj.SetActive(t.show)}UpdateRewardLis(){const t=M.D.getInstance().GetStringValue("DEMONTRIAL_REWARDSHOW"),e=r.o.GetStringArr(t),i=new y.Z
for(let t=0;t<=e.count-1;t++){const s=r.o.GetIntArr(e[t],"_"),n=new D.M(s[0])
n.count=s[1],i.Add(n)}this.rewardGrid.data_set(i)}StartEndTimer(){
null==this.enterTimerId&&(this.enterTimerId=h.C.Inst_get().SetInterval(this.CreateDelegate(this.RefreshEndTime),1e3,-1))}UpdateEnterState(){if(null==this.info)return
this.endTimeTxt.node.SetActive(!1),this.enterBtn.node.SetActive(!1),this.noOpenTxt.node.SetActive(!1),this.completeGo.SetActive(!1),this.enterSp.spriteNameSet("rycommon_bt_0023")
const t=H.t.Inst_get().GetEndTime()
let e=!1
if((0==t||a.D.serverTime_get()>=t)&&(e=!0),this.ClearEndTime(),e){this.noOpenTxt.node.SetActive(!0)
let t=""
t=H.t.Inst_get().IsInOpenDay()?M.D.getInstance().GetStringValue("DEMONTRIAL_NOTICE"):M.D.getInstance().GetStringValue("DEMONTRIAL_NOTICE_1"),this.noOpenTxt.textSet(t)}else{
this.endTimeTxt.node.SetActive(!0)
const t=H.t.Inst_get().GetEndTime()-a.D.serverTime_get()
this.endTimeTxt.textSet(`${w.l.GetTimeInHMS(t)}后结束`),this.endTimeTxt.node.SetActive(!0),this.StartEndTimer(),this.IsFailure()?(this.enterBtn.node.SetActive(!0),
this.enterBtn.SetText("进入挑战"),this.enterSp.spriteNameSet("rycommon_bt_0026")):(this.isComplete?(this.completeGo.SetActive(!0),
this.canGet.SetActive(!1)):this.enterBtn.node.SetActive(!0),0==this.info.maxCopyId?this.enterBtn.SetText("进入挑战"):this.enterBtn.SetText("继续挑战"))}}IsFailure(){return!1}
RefreshEndTime(){const t=H.t.Inst_get().GetEndTime()-a.D.serverTime_get()
t<=0?this.UpdateEnterState():this.endTimeTxt.textSet(`${w.l.GetTimeInHMS(t)}后结束`)}ClearEndTime(){null!=this.enterTimerId&&(h.C.Inst_get().ClearInterval(this.enterTimerId),
this.enterTimerId=null)}Clear(){this.RemoveLis(),this.rankGrid.Clear(),this.rewardGrid.Clear(),this.layerGrid.Clear(),
s.M.Instance_get().DeactiveStage(et.STAGE_ID,this.bossTexture.FatherId,this.bossTexture.ComponentId),this.ClearEndTime(),this.ClearBarTimer(),super.Clear()}Destroy(){
this.rankGrid.Destroy(),this.rewardGrid.Destroy(),this.layerGrid.Destroy(),super.Destroy()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.rankBtn,this.CreateDelegate(this.OnRankBtnHandle)),this.m_handlerMgr.AddClickEvent(this.badgeBtn,this.CreateDelegate(this.OnBadgeBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.enterBtn,this.CreateDelegate(this.OnEnterBtnHandle)),l.i.Inst.AddEventHandler(T.g.RANK_DATA,this.CreateDelegate(this.UpdateRankItemLis)),
this.scrollview.RegistonDragingMoving(this.CreateDelegate(this.OnDragingMoving)),this.scrollview.RegistonDragStarted(this.CreateDelegate(this.OnDragingStart)),
this.scrollview.RegistonDragFinished(this.CreateDelegate(this.OnDragingFinished)),this.layerGrid.OnReposition_set(this.CreateDelegate(this.OnRepositionHandle)),
l.i.Inst.AddEventHandler(T.g.BOSS_SELECT,this.CreateDelegate(this.OnBossSelectHandle)),B.f.Inst.AddCallback(P.t.EXORCISM_REWARD,this.CreateDelegate(this.UpdateRedPoint)),
H.t.Inst_get().AddEventHandler(U.A.RESET_TIME,this.CreateDelegate(this.UpdateView)),l.i.Inst.AddEventHandler(T.g.COPYRECORD_UPDATE,this.CreateDelegate(this.UpdateRecord)),
l.i.Inst.AddEventHandler(T.g.DAY_UPDATE,this.CreateDelegate(this.UpdateEnterState))}RemoveLis(){
l.i.Inst.RemoveEventHandler(T.g.RANK_DATA,this.CreateDelegate(this.UpdateRankItemLis)),l.i.Inst.RemoveEventHandler(T.g.BOSS_SELECT,this.CreateDelegate(this.OnBossSelectHandle)),
this.scrollview.RemoveonDragingMoving(this.CreateDelegate(this.OnDragingMoving)),this.scrollview.RemoveonDragStarted(this.CreateDelegate(this.OnDragingStart)),
this.scrollview.RemoveonDragFinished(this.CreateDelegate(this.OnDragingFinished)),this.layerGrid.OnReposition_set(null),
B.f.Inst.RemoveCallback(P.t.EXORCISM_REWARD,this.CreateDelegate(this.UpdateRedPoint)),H.t.Inst_get().RemoveEventHandler(U.A.RESET_TIME,this.CreateDelegate(this.UpdateView)),
l.i.Inst.RemoveEventHandler(T.g.COPYRECORD_UPDATE,this.CreateDelegate(this.UpdateRecord)),l.i.Inst.RemoveEventHandler(T.g.DAY_UPDATE,this.CreateDelegate(this.UpdateEnterState))}
UpdateRedPoint(t,e){this.redpointObj.SetActive(e)}OnDragingStart(){}OnDragingFinished(){this.OnDragingMoving()}OnDragingMoving(t,e){
let[i,s,n]=this.scrollview.node.transform.GetLocalPositionXYZ(),l=0,a=0
null!=t&&(l=t.x,a=t.y,l<0&&(l=-l),t.y<0&&(a=-a)),l>=a?(s=this.rate*(i- -310)-440,this.bar.SetValue(1-(s- -440)/-5736)):(i=(s- -440)/this.rate-310,
this.scrollbar2.SetValue((i- -310)/-5760)),this.UpdatePhotoPos()}UpdatePhotoPos(){const t=this.bossTextPosObj.transform.GetPosition()
this.bossTexture.node.transform.SetPosition(t)
const e=b.o.Inst().allExorcismCopy,i=H.t.Inst_get().GetLockCopyRes(),n=e.Count(),l=(i.level,1.175*n)
this.pos.Set(30.06*this.scrollbar2.GetValue(),l*(1-this.bar.GetValue()),0),s.M.Instance_get().SetStageCameraPosition(et.STAGE_ID,this.pos)}OnBadgeBtnHandle(){
F.d.Inst_get().OpenBadgeEffView()}OnBossSelectHandle(t){}OnRepositionHandle(){this.scrollview.SetDragAmount(0,0),this.scrollview.UpdatePosition()
const t=this.copyRes.level
this.ScrollToIndex(this.itemLis.Count()-1-t),this.OnDragingMoving()}OnRankBtnHandle(){H.t.Inst_get().HasReward()&&F.d.Inst_get().SendCM_GetReward(),
F.d.Inst_get().OpenRankRewardView()}OnEnterBtnHandle(){
null!=this.info&&null!=this.copyRes&&(this.IsFailure()?x.y.inst.ClientSysMessage(11042402):this.CheckCanEnter()&&R.p.inst.SendEnterCopy(this.copyRes.id))}CheckCanEnter(){
if(n.Y.Inst.PrimaryRole_get().Isdead_get())return!1
const t=o.b.Inst.currentMapId_get()
return k.p.Inst_get().GetMapById(t).senceType!=L.S.CopyMap||(x.y.inst.ClientSysMessage(N.X.InCopy),!1)}UpdateRankItemLis(){const t=H.t.Inst_get().GetRankInfo()
if(null!=t){this.noRankGo.SetActive(0==t.rankInfos.Count())
const e=new y.Z
for(let i=0;i<=t.rankInfos.Count()-1;i++){const s=t.rankInfos[i]
if(!(i<=2))break
e.Add(s)}this.rankGrid.data_set(e),this.myRankItem.SetData(t.selfRankInfo,t.rank)}}UpdateLayerItemLis(){this.bossInfo=V.C.Inst().GetItemByMonsterId(this.copyRes.bossShow)
const t=b.o.Inst().allExorcismCopy
this.itemLis=new y.Z,this.itemLis.Add(-1),this.itemLis.Add(null)
for(let e=t.Count()-1;e>=0;e+=-1){const i=t[e]
this.itemLis.Add(i)}this.layerGrid.data_set(this.itemLis)}RefreshMonster(){s.M.Instance_get().ActiveStage(et.STAGE_ID),
s.M.Instance_get().SetStageCameraPosition(et.STAGE_ID,v.P.zero_get()),this.bossTexture.SetMainTextureByPhoto(et.STAGE_ID)}ClearBoss(){null!=this.boss&&(this.boss.Destroy(),
this.boss=null)}BossSelectHandler(t){const e=t
this.curBossData=e,this.scrollIndex=this.GetIndex(),this.ChangeScrollPosByIndex(this.scrollIndex),this.SetData()}GetIndex(){this.bar.GetValue()
const t=this.showBossList
let e=0
for(let i=0;i<=t.Count()-1;i++)t[i].sortId==this.cfg.id_get()&&(e=i)
const i=t.Count()
return e<3?e=0==e?-1:0:e+2>=i?e=e==i-1?i-4:i-5:e-=2,e}ScrollToIndex(t){t<=1&&(t=1),this.ClearBarTimer(),this.index=t
let e=0,i=0
const s=this.itemLis.Count()
e=150+250*(s-this.index-2)+10,i=6090
let n=234*(this.index-.5)/(234*s-450),l=(e-15*this.index)/6090
n>1&&(n=1),n<0&&(n=0),l>1&&(l=1),l<0&&(l=0),this.bar.SetValue(n),this.scrollbar2.SetValue(l)
const[a,o,r]=this.layerGrid.itemList[0].node.transform.GetLocalPositionXYZ(),[d,u,c]=this.layerGrid.itemList[1].node.transform.GetLocalPositionXYZ()
this.rate=o/d,this.barTimer=h.C.Inst_get().SetFrameLoop(this.CreateDelegate(this.ScrollValue),2,1)}ScrollValue(){this.OnDragingMoving()}ClearBarTimer(){
null!=this.barTimer&&(h.C.Inst_get().ClearInterval(this.barTimer),this.barTimer=null)}}et.STAGE_ID=150},7571:(t,e,i)=>{i.d(e,{a:()=>w})
var s,n,l,a=i(42292),o=i(71409),r=i(32076),h=i(38836),d=i(98800),u=i(97461),c=i(56937),_=i(18202),I=i(31222),m=i(5494),g=i(52726),p=i(995),C=i(85602),S=i(70850),f=i(75321),y=i(42534),v=i(51943),D=i(33996),E=i(8211),T=i(73824),A=i(92415)
function L(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let w=(s=(0,o.GH)(A.k.SM_OverDueReminder),l=class t{constructor(){this.expireBtnView=null,this.loadExpireBtnView=!1,
this.RegisterMessage(),u.i.Inst.AddEventHandler(D.G.GET_MALLS,(0,r.v)(this.OnMall,this))}static Inst_get(){return null==t.inst&&(t.inst=new t),t.inst}RegisterMessage(){}Open(){
const t=new c.v
t.isShowMask=!0,t.layerType=g.F.Alert,I.N.inst.OpenById(m.I.ExpireTip,null,null,t)}Close(){I.N.inst.CloseById(m.I.ExpireTip)}OpenExpireBtnView(){if(null==this.expireBtnView){
const t=new c.v
t.layerType=g.F.DefaultUI,t.aniDir=p.K.Down,I.N.inst.OpenById(m.I.ExpireTipBtn,(0,r.v)(this.OnLoadExpireViewComplete,this),(0,r.v)(this.OnExpireBtnViewDestroy,this),t)}}
OnLoadExpireViewComplete(t){return this.loadExpireBtnView=!1,this.expireBtnView}CloseExpireBtnView(){this.loadExpireBtnView=!1,I.N.inst.CloseById(m.I.ExpireTipBtn)}
OnExpireBtnViewDestroy(){_.g.DestroyUIObj(this.expireBtnView),this.expireBtnView=null}SM_OverDueReminder(t){for(let e=0;e<=t.remindList.Count()-1;e++)this.AddItem(t.remindList[e])}
OnMall(){const t=T.G.Inst_get().cacheExpireIds
if(t.Count()>0){const e=new C.Z
e.AddRange(t),t.Clear()
for(let t=0;t<=e.Count()-1;t++)this.AddItem(e[t])}}AddItem(t){let e=!1
const i=v.H.Inst().GetItemById(t)
if(null!=i.itemId&&0!=i.itemId){if(S.g.Inst_get().GetItemsByModleID(i.itemId).Count()>0)e=!0
else{const t=i.targetDefs.mallid,s=this.GetMallDataByExpireCfg(t),n=this.bGetReplaceItem(i)
null!=s&&n&&(e=!0)}}else e=!0
e?T.G.Inst_get().expireIds.Add(t):T.G.Inst_get().cacheExpireIds.Add(t),T.G.Inst_get().expireIds.Count()>0?this.loadExpireBtnView||null!=this.expireBtnView||(this.loadExpireBtnView=!0,
this.OpenExpireBtnView()):this.CloseExpireBtnView()}LoadMapComplete(){const t=T.G.Inst_get().expireIds
for(let e=0;e<=t.Count()-1;e++)this.AddItem(t[e])}GetMallDataByExpireCfg(t){if(null==t)return null
let e=null
for(let i=0;i<=t.length;i++){const s=E.N.GetInst().GetInfo(t[i])
if(null!=s){if(!s.IsLimitBuy()){e=s
break}if(s.RemainNum_get()>0){e=s
break}}}return e}bGetReplaceItem(t){if(null==t.targetDefs.itemId)return!0
const e=t.targetDefs.itemId[0]
if(null==e||0==e)return!1
const i=y.f.Inst().getItemById(e).score
let s=0
return s=this.GetCompareCount(i),s<d.Y.Inst.primaryRoleInfoList.Count()}GetCompareCount(t){let e=0
const i=d.Y.Inst.primaryRoleInfoList
let s=null
for(const[n,l]of(0,h.vy)(i)){s=d.Y.Inst.GetRolePosEquipments(l,f.C.GUARD)
for(let i=0;i<=s.Count()-1;i++)this.bCompareEquipByEquipment(s[i],t)&&(e+=1)}return e}bCompareEquip(t,e){if(null==t.equipRes)return!1
if(!t.IsPernament())return!1
return t.equipRes.score>e}bCompareEquipByEquipment(t,e){if(null==t.equipRes)return!1
if(null!=t.deprecatedTime&&0!=t.deprecatedTime.ToNum())return!1
return t.equipRes.score>e}},l.inst=null,L(n=l,"Inst_get",[a.n],Object.getOwnPropertyDescriptor(n,"Inst_get"),n),
L(n.prototype,"SM_OverDueReminder",[s],Object.getOwnPropertyDescriptor(n.prototype,"SM_OverDueReminder"),n.prototype),n)},73824:(t,e,i)=>{i.d(e,{G:()=>n})
var s=i(85602)
class n{constructor(){this.expireIds=null,this.cacheExpireIds=null,this.currentOpenId=0,this.expireIds=new s.Z,this.cacheExpireIds=new s.Z}static Inst_get(){
return null==n.inst&&(n.inst=new n),n.inst}Clear(){this.cacheExpireIds.Clear(),this.expireIds.Clear()}}n.inst=null},90690:(t,e,i)=>{
var s,n=i(18998),l=i(6847),a=i(83908),o=i(46282),r=i(5924),h=i(61911),d=i(5494),u=i(13224),c=i(7571),_=i(73824);(0,
l.s_)(d.I.ExpireTipBtn,o.Z.ui_expire_btn_view).register()(s=class extends((0,a.pA)(h.f)()){constructor(...t){super(...t),this.loopTimeId=-1}InitView(){super.InitView(),
this.m_handlerMgr.AddClickEvent(this.openBtn,this.CreateDelegate(this.Next))}onPlanelAdded(){this.loopTimeId=r.C.Inst_get().SetInterval(this.CreateDelegate(this.CheckPos),100),
this.CheckPos(),this.PlayBtnAni()}Next(){c.a.Inst_get().Open()
const t=_.G.Inst_get().expireIds.Pop()
null!=t&&(_.G.Inst_get().currentOpenId=t,c.a.Inst_get().Open()),_.G.Inst_get().expireIds.Count()<=0&&c.a.Inst_get().CloseExpireBtnView()}CheckPos(){
if(null!=u.w.Inst_Get().redPacketView){this.ClearTime()
const t=this.openBtn.transform.GetLocalPosition()
t.x=80,this.openBtn.transform.SetLocalPosition(t)}}PlayBtnAni(){this.openBtn.getComponent(n.Animation).play()}ClearTime(){r.C.Inst_get().ClearInterval(this.loopTimeId),
this.loopTimeId=-1}Clear(){super.Clear()}Destroy(){super.Destroy(),this.ClearTime()}})},2837:(t,e,i)=>{
var s,n,l=i(6847),a=i(83908),o=i(46282),r=i(98800),h=i(32697),d=i(20583),u=i(50838),c=i(31546),_=i(70650),I=i(31222),m=i(5494),g=i(85602),p=i(21554),C=i(70850),S=i(86770),f=i(63076),y=i(3859),v=i(23628),D=i(87923),E=i(86209),T=i(44498),A=i(42534),L=i(68561),w=i(51943),R=i(33138),O=i(7601),G=i(63945),b=i(70202),M=i(8211),P=i(52513),B=i(31896),x=i(19519),N=i(74657),k=i(7571),V=i(73824),F=i(9057),U=i(75696)
class H extends F.x{constructor(...t){super(...t),this.ui_baseitem=null}InitView(){super.InitView(),this.ui_baseitem=this.CreateComponentBinder(U.j,1)}SetData(t){
this.ui_baseitem.SetData(t)}Clear(){super.Clear(),this.ui_baseitem.Clear()}Destroy(){super.Destroy(),this.ui_baseitem.Destroy(),this.ui_baseitem=null}Test1(){return!0}S_Test(){
return!0}}(0,l.s_)(m.I.ExpireTip,o.Z.ui_expire_tip_view).register()(((n=class extends((0,a.Ri)()){constructor(...t){super(...t),this.id=0,this.cfg=null,this.m_item=null,
this.mallData=null,this.roleRotateIndex=0,this.displayUIAvatarModel=null}InitView(){super.InitView(),
this.m_handlerMgr.AddClickEvent(this.gotoBtn,this.CreateDelegate(this.OnClickGoTo)),this.m_handlerMgr.AddClickEvent(this.closebtn,this.CreateDelegate(this.Close)),
this.m_handlerMgr.AddClickEvent(this.useBtn,this.CreateDelegate(this.OnUseItem)),this.itemGrid.SetInitInfo("ui_expire_baseitem",this.CreateDelegate(this.createItem)),
this.displayUIAvatarModel=new u.o,this.displayUIAvatarModel.SetTarget(this.rolerotategrid,!0),this.displayUIAvatarModel.setUpDragNode(this.texture.node)}OnAddToScene(){
if(this.id=V.G.Inst_get().currentOpenId,this.cfg=w.H.Inst().GetItemById(this.id),this.descLabel.textSet(this.cfg.tips),"MONTH_CARD"==this.cfg.type)this.ShowMonthCard(1)
else if("HONOUR_CARD"==this.cfg.type)this.ShowMonthCard(2)
else{if(null!=this.cfg.itemId&&0!=this.cfg.itemId){if(C.g.Inst_get().GetItemsByModleID(this.cfg.itemId).Count()>0){
if(R.f.Inst().getItemById(this.cfg.itemId).itemType==y.q.EQUIPMENT){"GUARD"==A.f.Inst().getItemById(this.cfg.itemId).equipType?this.ShowGuardUseItem():this.ShowUseItem()
}else this.ShowUseItem()
return}}this.mallData=k.a.Inst_get().GetMallDataByExpireCfg(this.cfg.targetDefs.mallid),this.ShowMall()}}ShowMonthCard(t){this.costContainer.node.SetActive(!1),
this.guardContainer.SetActive(!1),this.itemContainer.SetActive(!1),this.gotoBtnLabel.node.SetActive(!0),this.monthCardIcon.node.SetActive(!0),this.useBtn.node.SetActive(!1),
1==t?this.monthCardIcon.spriteNameSet("ryfulidating_sp_0029"):this.monthCardIcon.spriteNameSet("rymeiritili_sp_0008")}ShowMall(){this.monthCardIcon.node.SetActive(!1),
this.gotoBtnLabel.node.SetActive(!1),this.useBtn.node.SetActive(!1)
const t=this.mallData.Cfg_get()
if(R.f.Inst().getItemById(t.itemId).itemType==y.q.EQUIPMENT){if("GUARD"==A.f.Inst().getItemById(t.itemId).equipType)return this.itemContainer.SetActive(!1),this.SetItemBtnStatus(),
void this.SetModel(t.itemId)}this.guardContainer.SetActive(!1)
let e=null
if(D.l.IsEmptyStr(t.goods)){const i=new f.M(t.itemId)
e.Add(i)}else{e=N.A.GetReward(t.goods).GetAllRewardList()}this.itemGrid.data_set(e),this.SetItemBtnStatus()}ShowUseItem(){this.monthCardIcon.node.SetActive(!1),
this.gotoBtn.node.SetActive(!1),this.guardContainer.SetActive(!1),this.descLabel.textSet(this.cfg.tips2)
const t=new g.Z,e=new f.M(this.cfg.itemId)
t.Add(e),this.itemGrid.data_set(t)}ShowGuardUseItem(){this.monthCardIcon.node.SetActive(!1),this.gotoBtn.node.SetActive(!1),this.itemContainer.SetActive(!1),
this.descLabel.textSet(this.cfg.tips2),this.SetModel(this.cfg.itemId)}SetItemBtnStatus(){const t=this.mallData.Cfg_get()
if(0!=t.rechargeId){const e=P.O.Inst().getConfig(t.rechargeId),i=O.W.Inst.GetCurSystem(),s=e.platformCurrency[i]
this.costLabel.textSet(`${s}元`),this.costIcon.node.SetActive(!1)}else{let e,i=0,s=M.N.GetInst().GetInfo(t.id)
null==s&&(s=new b.L(t.id)),i=s.GetPrice(),e=s.GetCostType(),this.costLabel.textSet(E.w.Instance.ConvertNumToString(i))
const n=x.J.GetCurrencyIconUrl(e)
this.costIcon.spriteNameSet(n)}this.costContainer.Reposition()}OnClickGoTo(){
if("MONTH_CARD"==this.cfg.type||"HONOUR_CARD"==this.cfg.type)I.N.inst.OpenUIByShortCutIDOpenUI(this.cfg.targetDefs.goUI)
else if(null!=this.cfg.targetDefs.goUI)I.N.inst.OpenUIByShortCutIDOpenUI(this.cfg.targetDefs.goUI)
else{const t=this.mallData.Cfg_get()
0!=t.rechargeId?B.t.inst.Buy(P.O.Inst().getConfig(t.rechargeId),null):G.x.inst.ReqBuyMallItem(t.id,1,!0)}this.Close()}OnUseItem(){
R.f.Inst().getItemById(this.cfg.itemId).itemType==y.q.EQUIPMENT?this.EquipDress():p.J.Inst_get().UseItemByModelId(this.cfg.itemId,C.g.Inst_get().GetItemNum(this.cfg.itemId)),
this.Close()}EquipDress(){const t=C.g.Inst_get().GetItemsByModleID(this.cfg.itemId)
let e=null
for(let i=0;i<=t.Count()-1&&(e=t[i].baseData_get(),0==e.GetRemainTime());i++);let i=!0,s=null,n=null
const l=r.Y.Inst.GetMultPlayerInfos()
if(L.X.Inst_get().GetEquipExcellenceCount(e.serverData_get(),e.equipInfo_get())<2)s=this.GetRoleInfoByData(e),i=!1
else for(let t=0;t<=l.Count()-1;t++)if(s=l[t],v.b.IsWearForRole(s,e,!1)&&v.b.IsTakeOnJob(s.Job_get(),e.cfgData_get().Jobs_get())){const a=T.I.Score(e,s.Job_get(),s)
if(v.b.GetUpScore(s,e)==a){i=!1
break}n=l[t],i=!0}else s=null
null==s||i?null!=n&&i&&(C.g.Inst_get().select_open_item_id=e.serverData_get().id,
p.J.Inst_get().openOrClose(S.D.bagTab)):v.b.IsWearForRole(s,e)?p.J.Inst_get().RecommendTakeOnEquip(s,e):(C.g.Inst_get().select_open_item_id=e.serverData_get().Id_get(),
C.g.Inst_get().default_open_tip=!1,p.J.Inst_get().openOrClose(S.D.bagTab))}GetRoleInfoByData(t){const e=r.Y.Inst.GetMultPlayerInfos()
let i=-1,s=null
for(let n=0;n<=e.Count()-1;n++){const l=e[n]
if(v.b.IsWearForRole(l,t,!1)&&v.b.IsTakeOnJob(l.Job_get(),t.cfgData_get().Jobs_get())){const e=v.b.GetUpScore(l,t)
e>i&&(s=l,i=e)}}return s}SetModel(t){const e=R.f.Inst().getItemById(t)
var i=h.v.monster
const s=e.modelId,n=new c.O
n._displayID=s,this.displayUIAvatarModel.SetScale(2,2),this.displayUIAvatarModel=d.x.inst.SetUIAvatarData(n,i,this.displayUIAvatarModel)}Close(){k.a.Inst_get().Close()}Clear(){
super.Clear()}Destroy(){null!=this.m_item&&(0!=this.roleRotateIndex&&_.e.GetInst().UnregDrag(this.roleRotateIndex),this.m_item.Destroy(),this.m_item=null),super.Destroy()}
createItem(t){return new H(this.node)}Test1(){return!0}S_Test(){return!0}}).STAGE_ID=128,s=n))},38908:(t,e,i)=>{i.d(e,{C:()=>n})
var s=i(54967)
class n extends s.g{constructor(...t){super(...t),this.curr_down_size=0,this._isDone=!1,this.ExtraPackageSize=0,this.IsDownloading=!1,this.total_packet_size=0,
this.total_progress=0,this.download_speed=0,this.type=0,this.total_progress_per=0,this.hasReward=!1}isDone_get(){return this._isDone}isDone_set(t){this._isDone=t}}
n.UPDATE_DOWNLOAD_INFO="UPDATE_DOWNLOAD_INFO",n.UPDATE_ERROR="UPDATE_ERROR",n.DOWNLOAD_FINISH="DOWNLOAD_FINISH",n.DOWNLOAD_Start="DOWNLOAD_Start",n.DOWNLOAD_Stop="DOWNLOAD_Stop",
n.HASREWARD_UPDATE="HASREWARD_UPDATE",n.ExtraPackageActivityUpdate="ExtraPackageActivityUpdate",n.ReplaceTypeEquip="EQUIP",n.ReplaceTypeEquipUI="equipType",
n.ReplaceTypeSingleWeapon="SINGLEWEAPON",n.ReplaceTypeDOUBLEWEAPON="DOUBLEWEAPON",n.ReplaceTypeMAINWEAPON="MAINWEAPON",n.ReplaceTypeSUBWEAPON="SUBWEAPON",
n.ReplaceTypeWINGS="WINGS",n.ReplaceTypeGUARD="GUARD",n.ReplaceTypeMONSTER="MONSTER",n.ReplaceTypeRIDING="RIDING",n.ReplaceTypeNPC="NPC",n.ReplaceTypeDrop="DROP",
n.ReplaceTypeCollect="COLLECT",n.ReplaceTypeFlag="FLAG",n.StateNeedDown=1,n.StateDownFinish=2,n.Instance=new n},81031:(t,e,i)=>{
var s,n=i(18998),l=i(77546),a=i(37397),o=i(97461),r=i(96617),h=i(55458),d=i(57834),u=i(30849),c=i(92679),_=i(75439),I=i(38908),m=i(13476)
const{ccclass:g}=n._decorator
g("ExtraPackageBtn")(s=class extends u.C{constructor(...t){super(...t),this.btn_get_reward=null,this.btn_down=null,this.btn_downloading=null,this.lab_progress=null,
this.anchor=null,this.offset=null,this._degf_OnHasReward=null,this._degf_OnDownFinish=null,this._degf_OnDownStart=null,this._degf_OnExtraClick=null,
this._degf_OnUpdateDownloadInfo=null,this.btn_stop=null,this.lab_progress2=null}_initBinder(){super._initBinder(),this._degf_OnHasReward=t=>this.OnHasReward(t),
this._degf_OnDownFinish=t=>this.OnDownFinish(t),this._degf_OnDownStart=t=>this.OnDownStart(t),this._degf_OnExtraClick=(t,e)=>this.OnExtraClick(t,e),
this._degf_OnUpdateDownloadInfo=t=>this.OnUpdateDownloadInfo(t)}OnExtraClick(t,e){m.E.Instance.OpenExtraPackageLoadingPanel()}OnUpdateDownloadInfo(t){
this.lab_progress.textSet(`${I.C.Instance.total_progress_per}%`),this.lab_progress2.textSet(`${I.C.Instance.total_progress_per}%`)}OnDownStart(t){this.OnReset()}OnDownFinish(t){
this.OnReset()}OnHasReward(t){this.OnReset()}OnAddToScene(){l.s.Info(`ExtraLoaderModel.Instance.isDone :${r.A.Bool2Str(I.C.Instance.isDone_get())}`),this.OnReset()}UpdateBtnShow(){
if(0==m.E.CanExtraLoad())return this.node.SetActive(!1),void l.s.Info("下载B包按钮隐藏 IsIosShenhe")
if(!a._.Inst.IsLoginCompleted())return this.node.SetActive(!1),void l.s.Info("下载B包按钮隐藏 not IsLoginCompleted")
if(h.f.is_split_res)if(I.C.Instance.isDone_get()){null==_.D.getInstance().GetStringValue("EXTRAPACKAGE:DOWNLOAD_REWARD")||I.C.Instance.hasReward?(this.node.SetActive(!1),
l.s.Info("下载B包按钮隐藏 领取完奖励了")):(this.node.SetActive(!0),l.s.Info("下载B包按钮显示  未领取奖励"))}else this.node.SetActive(!0),l.s.Info("下载B包按钮显示   下载未完成")
else this.node.SetActive(!1),l.s.Info("下载B包按钮隐藏 BuildConfig.is_split_res = false")}OnReset(){if(h.f.is_split_res)if(this.btn_get_reward.node.SetActive(!1),
this.btn_down.node.SetActive(!1),this.btn_downloading.node.SetActive(!1),this.btn_stop.node.SetActive(!1),I.C.Instance.isDone_get()){
if(null!=_.D.getInstance().GetStringValue("EXTRAPACKAGE:DOWNLOAD_REWARD")){const t=I.C.Instance.hasReward
this.btn_get_reward.node.SetActive(!t)}else this.btn_get_reward.node.SetActive(!1)
}else I.C.Instance.IsDownloading||I.C.Instance.total_progress_per>0?m.E.Instance.isPause?this.btn_stop.node.SetActive(!0):this.btn_downloading.node.SetActive(!0):this.btn_down.node.SetActive(!0)
this.UpdateBtnShow()}Destory(){I.C.Instance.RemoveEventHandler(I.C.DOWNLOAD_FINISH,this._degf_OnDownFinish),
I.C.Instance.RemoveEventHandler(I.C.DOWNLOAD_Start,this._degf_OnDownStart),I.C.Instance.RemoveEventHandler(I.C.UPDATE_DOWNLOAD_INFO,this._degf_OnUpdateDownloadInfo),
I.C.Instance.RemoveEventHandler(I.C.HASREWARD_UPDATE,this._degf_OnHasReward),I.C.Instance.RemoveEventHandler(I.C.DOWNLOAD_Stop,this._degf_OnHasReward),
o.i.Inst.RemoveEventHandler(c.g.MAP_LOGIN_LOAD_COMPELETE,this.CreateDelegate(this.OnReset)),d.i.Get(this.btn_down.node).RemoveonClick(this._degf_OnExtraClick),
d.i.Get(this.btn_downloading.node).RemoveonClick(this._degf_OnExtraClick),d.i.Get(this.btn_get_reward.node).RemoveonClick(this._degf_OnExtraClick),this.btn_get_reward=null,
this.btn_down=null,this.btn_downloading=null,this.lab_progress=null,this.lab_progress2=null,this.anchor=null,this.offset=null,super.Destroy()}})},13476:(t,e,i)=>{i.d(e,{E:()=>k})
var s,n,l,a=i(42292),o=i(93984),r=i(77546),h=i(38836),d=i(86133),u=i(38045),c=i(98800),_=i(75309),I=i(57647),m=i(35201),g=i(6700),p=i(28088),C=i(56381),S=i(68662),f=i(98497),y=i(56937),v=i(18202),D=i(31222),E=i(5494),T=i(52726),A=i(35128),L=i(55360),w=i(98885),R=i(72785),O=i(38962),G=i(33314),b=i(24524),M=i(23951),P=i(22662),B=i(65550),x=i(85942),N=i(38908)
let k=(0,a.gK)("LuaExtraPackageLoaderController")((l=class t{static get Instance(){return null==t._Instance&&(t._Instance=new t),t._Instance}constructor(){this.replaceDic=null,
this.isChecked=!1,this.isPause=!1,this.mExtraPackageLoadingPanel=null,this._degf_SM_ExtendPackRewardHandler=null,this._degf_CallDestoryExtraPackageLoadingPanel=null,
this._degf_OnResUpdateErrHander=null,this._degf_OnResUpdateSuccessHandler=null,this._degf_ShowExtraPackageLoadingPanelHandler=null,this._degf_StartLoadPackage=null,
this.replaceDic=new O.X,this._degf_SM_ExtendPackRewardHandler=t=>this.SM_ExtendPackRewardHandler(t),
this._degf_CallDestoryExtraPackageLoadingPanel=()=>this.CallDestoryExtraPackageLoadingPanel(),this._degf_OnResUpdateErrHander=t=>this.OnResUpdateErrHander(t),
this._degf_OnResUpdateSuccessHandler=()=>this.OnResUpdateSuccessHandler(),this._degf_ShowExtraPackageLoadingPanelHandler=t=>this.ShowExtraPackageLoadingPanelHandler(t),
this._degf_StartLoadPackage=t=>this.StartLoadPackage(t),
N.C.Instance.type=0,0!=N.C.Instance.ExtraPackageSize&&(N.C.Instance.total_progress=N.C.Instance.curr_down_size/N.C.Instance.ExtraPackageSize,
N.C.Instance.total_progress_per=A.p.CeilToInt(100*N.C.Instance.total_progress),N.C.Instance.RaiseEvent(N.C.UPDATE_DOWNLOAD_INFO)),
N.C.Instance.total_packet_size=N.C.Instance.ExtraPackageSize
const t=L.Y.Inst.GetOrCreateCsv(o.h.eReplace).GetCsvMap()
for(const[e,i]of(0,h.V5)(t)){let t=null,e=i.type
"equipType"==i.type&&(e+=i.parts),t=this.replaceDic.LuaDic_GetItem(e),null==t&&(t=new O.X,this.replaceDic[e]=t)
let s=null
s=t.LuaDic_GetItem(i.job),null==s&&(s=new O.X,t[i.job]=s),s.LuaDic_ContainsKey(i.gender)?R.c.DebugError((0,
d.T)("REPLACERESOURCE 配置冲突，不能有相同type, job, gender的配置 key = ")+e):s.LuaDic_AddOrSetItem(i.gender,i)}this.AddLis()}AddLis(){
f.j.Inst.F_Register(-11757,M.s,this._degf_SM_ExtendPackRewardHandler)}SM_ExtendPackRewardHandler(t){const e=t
N.C.Instance.hasReward=e.hadReward,N.C.Instance.RaiseEvent(N.C.HASREWARD_UPDATE)}LocalHasDisplayID(t){return!(!N.C.Instance.isDone_get()&&!g.L.HasResourceByDisplayID(t))}
TryReplaceDisplayID(t,e){return N.C.Instance.isDone_get()||g.L.HasResourceByDisplayID(e)?e:this.GetReplaceDisplayID(t)}GetReplaceDisplayID(t){let e=!1,i=0
if(this.replaceDic.LuaDic_ContainsKey(t)){const s=this.replaceDic[t]
if(s.LuaDic_ContainsKey(0)){const t=s[0]
t.LuaDic_ContainsKey(0)&&(i=t[0].replaceModelId,e=!0)}}return e||R.c.DebugError((0,d.T)("找不到替代的形象ID type=")+t),i}GetReplaceSuitName(t,e,i){
if(!this.replaceDic.LuaDic_ContainsKey(t))return""
e=G.Z.GetJobBaseValue(e)
let s="",n=!1
if(this.replaceDic.LuaDic_ContainsKey(t)){const l=this.replaceDic[t]
if(l.LuaDic_ContainsKey(e)){const t=l[e]
t.LuaDic_ContainsKey(i)&&(s=t[i].replaceSuitName,n=!0)}}return n||R.c.DebugError(`${(0,d.T)("找不到替代的套装 type=")}${t} job = ${e} sex = ${i}`),s}GetReplaceSuitDisplayID(t,e,i){
if(!this.replaceDic.LuaDic_ContainsKey(t))return 0
if(e=G.Z.GetJobBaseValue(e),this.replaceDic.LuaDic_ContainsKey(t)){const s=this.replaceDic[t]
if(s.LuaDic_ContainsKey(e)){const t=s[e]
if(t.LuaDic_ContainsKey(i))return t[i].replaceModelId}}return R.c.DebugError(`${(0,d.T)("找不到替代的套装 type=")}${t} job = ${e} sex = ${i}`),0}TryGetReplaceSuitDisplayID(t,e,i,s){
return s}TryGetReplaceEquipUIDisplayID(t,e,i,s){return this.TryGetReplaceSuitDisplayID(N.C.ReplaceTypeEquipUI+t,e,i,s)}InitSceneCheck(){if(!this.isChecked&&(this.isChecked=!0,
!N.C.Instance.isDone_get()&&!BuildConfig.isInnerNet)){const e=C.m.inst.GetCurNetType()
r.s.Info(`curNetType=${e}`),e!=p.N.WIFI&&e!=p.N._4G&&e!=p.N._3G||t.CanExtraLoad()&&this.StartLoadPackage()}}static CanExtraLoad(){return 0==S.D.IsIosShenhe()&&0==S.D.isCloud}
StartLoadPackage(e){if(r.s.Info("StartLoadPackage"),0==t.CanExtraLoad())return
this.isPause=!1
const i=_.n.AddCallBackOnFinished(this._degf_OnResUpdateSuccessHandler),s=_.n.AddCallBackStringDelegate(this._degf_OnResUpdateErrHander)
c.Y.Inst.PrimaryRoleInfo_get().Level_get()>=150||BuildConfig.is_gm?I.R.SetDownLoadSpeed(0):I.R.SetDownLoadSpeed(307200)
const n=(g.L.GetExtraPackageSize()-g.L.GetCurrDownExtraPackageSize())/1024
if(r.s.Info((0,d.T)("B包大小:")+(0,u.tw)(n)),S.D.IsIos){const t=m.g.Instance_get().GetFreeDiskSpaceCommon()
if(-1==m.g.Instance_get().GetToltalDiskSpace()||t>=1.5*n)g.L.StartExtraUpdate(i,s)
else{const t=new x.N
t.showText=(0,d.T)("手机存储空间不足，请清理手机空间"),B.y.inst.OpenCommonMessageTips(t)}}else if(S.D.IsAndroid){if(C.m.inst.GetFreeDiskSpaceCommon()>=1.5*n)g.L.StartExtraUpdate(i,s)
else{const t=new x.N
t.showText=(0,d.T)("手机存储空间不足，请清理手机空间"),B.y.inst.OpenCommonMessageTips(t)}}else g.L.StartExtraUpdate(i,s)}PauseExtraUpdate(){
if(!this.isPause&&!N.C.Instance.IsDownloading)return B.y.inst.ClientSysMessage(100579),!1
if(this.isPause)return B.y.inst.ClientSysMessage(100579),!1
const t=g.L.PauseExtraUpdate()
return r.s.Info(`PauseExtraUpdate err=${t}`),w.M.IsNullOrEmpty(t)?(this.isPause=!0,B.y.inst.ClientSysMessage(100578),!0):(R.c.DebugError((0,
d.T)("PauseExtraUpdate 暂停下载B包错误： = ")+t),B.y.inst.ClientStrMsg(P.r.SystemTipMessage,t),!1)}RestartExtraUpdate(){if(r.s.Info("RestartExtraUpdate"),0==t.CanExtraLoad())return
if(!this.isPause)return B.y.inst.ClientSysMessage(100580),!1
const e=(g.L.GetExtraPackageSize()-g.L.GetCurrDownExtraPackageSize())/1024
r.s.Info((0,d.T)("B包大小:")+(0,u.tw)(e))
const i=m.g.Instance_get().GetFreeDiskSpaceCommon(),s=m.g.Instance_get().GetToltalDiskSpace()
if(!(-1==s||i>=1.5*e&&i>=.1*s)){const t=new x.N
return t.showText=(0,d.T)("手机存储空间不足，请清理手机空间"),B.y.inst.OpenCommonMessageTips(t),!1}const n=g.L.RestartExtraUpdate()
return r.s.Info(`RestartExtraUpdate err=${n}`),w.M.IsNullOrEmpty(n)?(this.isPause=!1,N.C.Instance.RaiseEvent(N.C.DOWNLOAD_Start),!0):(R.c.DebugError((0,
d.T)("RestartExtraUpdate 恢复下载B包错误： = ")+n),B.y.inst.ClientStrMsg(P.r.SystemTipMessage,n),!1)}OnResUpdateSuccessHandler(){r.s.Info("OnResUpdateSuccessHandler"),this.isPause=!1,
N.C.Instance.IsDownloading=!1,N.C.Instance.isDone_set(!0),N.C.Instance.RaiseEvent(N.C.DOWNLOAD_FINISH),I.R.SetDownLoadSpeed(0)}OnResUpdateProgressHandler(t,e,i,s){
N.C.Instance.IsDownloading||(N.C.Instance.IsDownloading=!0,N.C.Instance.RaiseEvent(N.C.DOWNLOAD_Start)),N.C.Instance.total_progress=e,
N.C.Instance.total_progress_per=A.p.CeilToInt(100*N.C.Instance.total_progress),N.C.Instance.total_packet_size=i,N.C.Instance.download_speed=s,N.C.Instance.type=t,
N.C.Instance.RaiseEvent(N.C.UPDATE_DOWNLOAD_INFO)}OnResUpdateErrHander(t){r.s.Info(`OnResUpdateErrHander ${t}`),N.C.Instance.IsDownloading=!1
const e=new x.N
e.showText=t,e.okText=(0,d.T)("确定"),e.tipstype=1,e.btnColorType=2,B.y.inst.OpenCommonMessageTips(e),N.C.Instance.RaiseEvent(N.C.UPDATE_ERROR)}OpenExtraPackageLoadingPanel(){
if(0!=t.CanExtraLoad())if(null!=this.mExtraPackageLoadingPanel)this.mExtraPackageLoadingPanel.node.SetActive(!0)
else{const t=new y.v
t.layerType=T.F.Tip,D.N.inst.OpenById(E.I.ExtraLoadingPanel,this._degf_ShowExtraPackageLoadingPanelHandler,this._degf_CallDestoryExtraPackageLoadingPanel,t)}}
ShowExtraPackageLoadingPanelHandler(t){return this.mExtraPackageLoadingPanel}CallDestoryExtraPackageLoadingPanel(){v.g.DestroyUIObj(this.mExtraPackageLoadingPanel),
this.mExtraPackageLoadingPanel=null}CloseExtraPackageLoadingPanel(){null!=this.mExtraPackageLoadingPanel&&D.N.inst.ClosePanel(this.mExtraPackageLoadingPanel)}HasSceneID(t,e){
return N.C.Instance.isDone_get(),!0}HasCopyId(t,e){const i=b.o.Inst().getItemById(t)
return null==i||this.HasSceneID(w.M.String2Int(i.mapId),e)}HasResourceDone(){return!!N.C.Instance.isDone_get()||(B.y.inst.ClientStrMsg(P.r.SystemTipMessage,(0,
d.T)("下载扩展包后才可进入地图")),this.OpenExtraPackageLoadingPanel(),!1)}},l._Instance=null,V=n=l,F="Instance",U=[a.Vx],H=Object.getOwnPropertyDescriptor(n,"Instance"),q=n,Z={},
Object.keys(H).forEach((function(t){Z[t]=H[t]})),Z.enumerable=!!Z.enumerable,Z.configurable=!!Z.configurable,("value"in Z||Z.initializer)&&(Z.writable=!0),
Z=U.slice().reverse().reduce((function(t,e){return e(V,F,t)||t}),Z),q&&void 0!==Z.initializer&&(Z.value=Z.initializer?Z.initializer.call(q):void 0,Z.initializer=void 0),
void 0===Z.initializer&&(Object.defineProperty(V,F,Z),Z=null),s=n))||s
var V,F,U,H,q,Z},91897:(t,e,i)=>{i.d(e,{v:()=>x})
var s,n,l,a,o,r=i(42292),h=i(71409),d=i(17409),u=i(49655),c=i(38935),_=i(56937),I=i(18202),m=i(31222),g=i(5494),p=i(98789),C=i(44132),S=i(20099),f=i(74045),y=i(49067),v=i(87923),D=i(73865),E=i(37648),T=i(55492),A=i(21153),L=i(92415),w=i(5031),R=i(31896),O=i(7155),G=i(65550),b=i(56532),M=i(93002),P=i(81534)
function B(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let x=(s=(0,h.GH)(L.k.SM_FirstRechargeConfig),n=(0,h.GH)(L.k.SM_FirstRechargeInfo),l=(0,
h.GH)(L.k.SM_FirstRechargeSuccess),o=class t extends C.D{constructor(){super(),this.model=null,this.icon=null,this.firstChargeView=null,this._degf_CallDestroy=null,
this._degf_OnShowComplete=null,this.RegistMsg(),this.model=b.F.Inst_get(),this._degf_CallDestroy=()=>this.CallDestroy(),this._degf_OnShowComplete=t=>{}}static Inst_get(){
return null==t.inst&&(t.inst=new t),t.inst}RegistMsg(){}OpenView(){if(!E.P.Inst_get().IsFunctionOpened(T.x.FIRST_CHARGE))return void v.l.SetFunctionTip(T.x.FIRST_CHARGE)
this.model.whoOpen=S.V.GetLastClick(null,null,null,null,null,[300100,301001,310300]),301001==this.model.whoOpen&&(this.model.whoOpen=301300)
const t=new _.v
t.positionType=p.$.eCustom,t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!1,m.N.inst.OpenById(g.I.FirstChargePanel,this._degf_OnShowComplete,this._degf_CallDestroy,t)}
CallDestroy(){}ClosePanel(){(0,d.qJ)(u.o.FirstChargePanel)&&(0,d.sR)(u.o.FirstChargePanel)}CloseRechargeIcon(){null!=this.icon&&(w.T.inst_get().control.RemoveAttach(this.icon),
this.icon.Clear(),I.g.DestroyUIObj(this.icon),this.icon=null)}OpenRewardShow(t){if(b.F.Inst_get().ChargeState_get()>=b.F.GETOVER)return void G.y.inst.ClientSysMessage(121028)
this.model.showRechargeCfg=t
const e=new _.v
e.positionType=p.$.eCustom,e.isShowMask=!0,e.isDefaultUITween=!0,e.isSelfTween=!1,e.viewClass=M.L,(0,d.Yp)(u.o.FirstChargeRewardShow,e)}OpenFirstChargeSucPanel(){const t=new _.v
t.positionType=p.$.eCustom,t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!1,t.viewClass=P.H,(0,d.Yp)(u.o.FirstChargeSuccessPanel,t)}SM_FirstRechargeConfigHandler(t){
this.model.HandleConfig(t.dayReward,t.rewardIds,t.extraReward)}SM_FirstRechargeInfoHandler(t){this.model.HandleInfo(t.rechargeRewardVos),
this.model.rewardInfoes.Count()>0&&this.CloseRechargeIcon()}SM_FirstRechargeSuccessHandler(t){this.OpenFirstChargeSucPanel()}SM_OpenServerAdvantageHandler(t){}CM_GetReward(t){
const e=new A.L
e.rewardId=t,c.C.Inst.F_SendMsg(e)}CheckFirstCharge(t){let e=!0
if(22==t.type)return!0
if(!b.F.Inst_get().noRemind){if(!O.o.Inst_get().isFristRecharge){const e=new y.B
return e.infoId="FIRST_RECHARGE:NOTICE",e.cancelHandle=this.CreateDelegate(this.ContinueRecharge),e.cancelParam=t,e.confirmText="前往首充",e.cancelText="继续充值",e.isShowMask=!0,
e.checkChanged=this.CreateDelegate(this.SetNoRemind),e.confirmHandle=this.CreateDelegate(this.OpenView),f.t.Inst().Open(e),!1}e=!0}return e}ContinueRecharge(t){
R.t.inst.Buy(t,null,!1)}SetNoRemind(t){b.F.Inst_get().noRemind=t}ChargeIntercept(){
return!O.o.Inst_get().isFristRecharge&&(E.P.Inst_get().IsFunctionOpened(T.x.FIRST_CHARGE)?(this.OpenView(),!0):(v.l.SetFunctionTip(T.x.FIRST_CHARGE),!0))}UpdateIcon(t){
D.y.Inst.UpdateFuncIcon(T.x.FIRST_CHARGE,t)}},o.inst=null,B(a=o,"Inst_get",[r.n],Object.getOwnPropertyDescriptor(a,"Inst_get"),a),
B(a.prototype,"SM_FirstRechargeConfigHandler",[s],Object.getOwnPropertyDescriptor(a.prototype,"SM_FirstRechargeConfigHandler"),a.prototype),
B(a.prototype,"SM_FirstRechargeInfoHandler",[n],Object.getOwnPropertyDescriptor(a.prototype,"SM_FirstRechargeInfoHandler"),a.prototype),
B(a.prototype,"SM_FirstRechargeSuccessHandler",[l],Object.getOwnPropertyDescriptor(a.prototype,"SM_FirstRechargeSuccessHandler"),a.prototype),a)},56532:(t,e,i)=>{i.d(e,{F:()=>S})
var s=i(38836),n=i(97461),l=i(16812),a=i(62370),o=i(5924),r=i(98885),h=i(85602),d=i(92679),u=i(87923),c=i(205),_=i(55492),I=i(75439),m=i(52513),g=i(14792),p=i(62734),C=i(91897)
class S extends l.k{constructor(){super(),this.rechargeList=null,this.showtomorrowId=-1,this.noRemind=!1,this.hasClick=!1,this.chargeState=0,this.dayChargeTxts=null,
this.showRecharge=!1,this.openChargeLevel=0,this.topRechargeValue=0,this.firstRechargeChecked=!1,this.rewardInfoes=null,this.showRechargeCfg=null,this.superiorTime=null,
this.curDay=null,this.whoOpen=null,this.resRewards=null,this.rewardIds=null,this.extrarewards=null,this.animTimer=void 0,this.rechargeList=new h.Z,this.InitRecharge()}
static Inst_get(){return null==S.inst&&(S.inst=new S),S.inst}ChargeState_get(){if(null==this.rewardInfoes||0==this.rewardInfoes.Count())return S.NONE
let t=!0
for(let e=0;e<=2;e++)this.rewardInfoes[e].isReward||(t=!1)
return t?S.GETOVER:S.ACTIVE}ResetData(){this.hasClick=!1,this.chargeState=0,this.showRecharge=!1,this.openChargeLevel=0,this.showRechargeCfg=null,this.superiorTime=null,
this.curDay=0,this.whoOpen=0,this.noRemind=!1,this.ClearTomorrowTime()}RefreshState(t){}checkChargeState(t){null==t&&(t=!0)
let e=!0
return e=!0,t&&(c.D.Inst().FakeFunctionOpen(_.x.CHARGE),n.i.Inst.RaiseEvent(d.g.FUNCTION_OPEN,_.x.CHARGE)),true}GetModelByDay(t){let e=null
1==t?e=I.D.getInstance().getContent("RECHARGE:SECOND_DAY_DISPLAY"):2==t&&(e=I.D.getInstance().getContent("RECHARGE:THIRD_DAY_DISPLAY")),e.parse()
return r.M.Split(e.getContent().stringVal,a.o.s_UNDER_COLON)}GetModelByJob(t){
const e=I.D.getInstance().getContent("RECHARGE:JOB_WEAPON"),i=r.M.Split(e.getContent().stringVal,r.M.s_SPAN_CHAR_DOT)
if(null!=i)for(const[e,n]of(0,s.V5)(i)){const e=r.M.Split(n,a.o.s_UNDER_COLON)
if(null!=e){if(r.M.String2Int(e[0])==t)return e}}return null}GetRewards(){return this.resRewards}IsUnique(t){
const e=I.D.getInstance().getContent("ITEM:UNIQUE"),i=r.M.Split(e.getContent().stringVal,r.M.s_SPAN_CHAR_DOT)
if(null!=i)for(const[e,n]of(0,s.V5)(i)){if(r.M.String2Int(n)==t)return!0}return!1}IsPerpetual(t){
const e=I.D.getInstance().getContent("ITEM:PERPETUAL"),i=r.M.Split(e.getContent().stringVal,r.M.s_SPAN_CHAR_DOT)
if(null!=i)for(const[e,n]of(0,s.V5)(i)){if(r.M.String2Int(n)==t)return!0}return!1}InitRecharge(){if(this.rechargeList=new h.Z,0!=this.rechargeList.length)return
let t=I.D.getInstance().getContent("FIRSTRECHARGE:RECHARGE_COUNT")
t=t.getContent().arrayVal
for(let e=0;e<=t.Count()-1;e++){const i=r.M.String2Int(t[e])
this.rechargeList.Add(m.O.Inst().getConfig(i))}if(this.rechargeList.Count()>0){const t=m.O.Inst().getConfig(this.rechargeList[this.rechargeList.Count()-1].id)
this.topRechargeValue=m.O.Inst().GetCfgMoney(t)}}GetRechargeValue(t){if(t<=this.rechargeList.Count()-1){const e="1"
return this.rechargeList[t].platformCurrency[e]}}GetRechargeDiamond(t){if(t<=this.rechargeList.Count()-1){const e="1"
return this.rechargeList[t].platformDiamond[e]}return 0}GetUnGainIndex(){let t=-1
for(let e=0;e<=2;e++){const i=this.IsRewarded(e)
if(i==S.ACTIVE)return e
i==S.NONE&&-1==t&&(t=e)}return t>-1?t:0}GetRewardId(t){return this.rewardIds[t]}IsTop(t){return m.O.Inst().GetCfgMoney(t)>=this.topRechargeValue}GetSuperiorityFirstTIme(){}
GetSuperioritySecondTIme(){}GetFinalChargeCfg(){return this.rechargeList[this.rechargeList.Count()-1]}HandleInfo(t){this.rewardInfoes=t,this.HandleRedPoint()}HandleRedPoint(){
let t=!1
if(null!=this.rewardInfoes&&0!=this.rewardInfoes.Count())for(let e=0;e<=this.rewardInfoes.Count()-1;e++)if(this.CanGetReward(this.rewardInfoes[e])){t=!0
break}p.f.Inst.SetState(g.t.FIRSTCHARGE,t)
const e=this.GetIconName()
if(null!=this.rewardInfoes&&0!=this.rewardInfoes.Count())for(let t=0;t<=this.rewardInfoes.Count()-1;t++)if(!this.rewardInfoes[t].isReward&&!u.l.OverTime(this.rewardInfoes[t].timeLimit.ToNum())){
this.ClearTomorrowTime(),this.SetTomorrowTime(this.rewardInfoes[t].timeLimit.ToNum())
break}C.v.Inst_get().UpdateIcon(e),this.RaiseEvent(S.CONFIG_UPDATE)}GetIconName(){let t=!1
if(null!=this.rewardInfoes&&0!=this.rewardInfoes.Count())for(let e=0;e<=this.rewardInfoes.Count()-1&&null!=this.rewardInfoes[e];e++)if(!this.rewardInfoes[e].isReward){
t=!u.l.OverTime(this.rewardInfoes[e].timeLimit.ToNum())
break}let e="rymainui_functionicon_2005"
return t&&(e="rymainui_functionicon_2006"),e}ClearTomorrowTime(){this.showtomorrowId>-1&&(o.C.Inst_get().ClearInterval(this.showtomorrowId),this.showtomorrowId=-1)}
SetTomorrowTime(t){this.ClearTomorrowTime()
const e=u.l.GetTimeOffset(t)
this.showtomorrowId=o.C.Inst_get().SetInterval(this.CreateDelegate(this.TomorrowDelay),e)}TomorrowDelay(){this.ClearTomorrowTime(),this.HandleRedPoint()}CanGetReward(t){
if(null==t)return!1
let e=!t.isReward
return e=e&&u.l.OverTime(t.timeLimit),e}HandleConfig(t,e,i){this.resRewards=t,this.rewardIds=e,this.extrarewards=i,this.RaiseEvent(S.CONFIG_UPDATE)}IsRewarded(t){
return 0==this.rewardInfoes.Count()?S.NONE:t<this.rewardInfoes.Count()?this.rewardInfoes[t].isReward?S.GAIN:S.ACTIVE:S.NONE}GetRechargeCfg(t){
return t<this.rechargeList.Count()?this.rechargeList[t]:null}GetRewardCount(t){return null!=this.resRewards?this.resRewards[t].rewards.Count():0}GetTime(t){
return null==this.rewardInfoes?0:this.rewardInfoes[t].timeLimit}}S.inst=null,S.CONFIG_UPDATE="CONFIG_UPDATE",S.NONE=0,S.ACTIVE=1,S.GAIN=2,S.GETOVER=3},93002:(t,e,i)=>{i.d(e,{
L:()=>v})
var s,n,l=i(6847),a=i(83908),o=i(17409),r=i(46282),h=i(86133),d=i(28192),u=i(98885),c=i(85602),_=i(20099),I=i(87923),m=i(47786),g=i(52513),p=i(31896),C=i(56532),S=i(49655),f=i(63076),y=i(23628)
let v=(0,l.s_)(S.o.FirstChargeRewardShow,r.Z.ui_ryfirstcharge_rewardpanel).register()(((n=class extends((0,a.Ri)()){constructor(...t){super(...t),this.unattach=null,
this.rewardData=null,this.model=null,this.rechargeCfg=null,this._m_handlerMgr=null}OnAddToScene(){this.AddLis(),this.UpdateView()}get m_handlerMgr(){
return this._m_handlerMgr||(this._m_handlerMgr=d.h.Get()),this._m_handlerMgr}UpdateView(){this.model=C.F.Inst_get()
const t=this.model.extrarewards
this.rechargeCfg=this.model.showRechargeCfg,this.rewardData=f.M.wrapReward(t.rewards[0]),this.rewardData.isCanOperate=!1,this.rewarditem.SetData(this.rewardData)
const e=y.b.GetNameStr(this.rewardData,null,!1,null,null)
this.itemnamelab.textSet(e),this.rechargevalue.textSet(u.M.Replace("{0}元","{0}",""+this.model.topRechargeValue)),
this.contentlab.textSet(m.x.Inst().getItemById(11040202).sys_messsage)
const i=g.O.Inst().GetCfgMoney(this.rechargeCfg),s=C.F.Inst_get().whoOpen
300100==s?6==i?_.V.SendClickData(300106):30==i?_.V.SendClickData(300107):60==i&&_.V.SendClickData(300108):310300==s?6==i?_.V.SendClickData(310306):30==i?_.V.SendClickData(310307):60==i&&_.V.SendClickData(310308):301300==s&&(6==i?_.V.SendClickData(301306):30==i?_.V.SendClickData(301307):60==i&&_.V.SendClickData(301308))
let n=null,l=null
const a=this.btnrecharge.node.transform.GetLocalPosition()
if(this.model.IsTop(this.rechargeCfg)){n=11040201
const t=m.x.Inst().getItemById(n).sys_messsage
l=u.M.Replace(t,"{0}",""+i),this.lowerchargelab.textSet((0,h.T)("确定")),this.closebtn.node.SetActive(!1),a.x=0}else{this.lowerchargelab.textSet(u.M.Replace("{0}元","{0}",""+i)),
n=11040203
const t=m.x.Inst().getItemById(n).sys_messsage
l=I.l.Substitute(t,new c.Z([this.model.topRechargeValue])),this.closebtn.node.SetActive(!0),a.x=126}this.btnrecharge.node.transform.SetLocalPosition(a),this.titlelab.textSet(l)}
AddLis(){this.m_handlerMgr.AddClickEvent(this.btnrecharge,this.CreateDelegate(this.OnChargeClick)),
this.m_handlerMgr.AddClickEvent(this.closebtn,this.CreateDelegate(this.CancelbtnClick)),this.m_handlerMgr.AddClickEvent(this.closebtn2,this.CreateDelegate(this.ClosebtnClick))}
ClosebtnClick(){this.model.IsTop(this.model.showRechargeCfg)||(this.model.firstRechargeChecked=!0),this.CloseHandler()}OnChargeClick(){this.model.firstRechargeChecked=!0
g.O.Inst().GetCfgMoney(this.rechargeCfg)
const t=C.F.Inst_get().whoOpen
300100==t?_.V.SendClickData(300112):310300==t?_.V.SendClickData(310312):301300==t&&_.V.SendClickData(301312),p.t.inst.Buy(this.model.GetFinalChargeCfg(),null,null),
this.CloseHandler()}CancelbtnClick(){this.model.firstRechargeChecked=!0
const t=g.O.Inst().GetCfgMoney(this.rechargeCfg),e=C.F.Inst_get().whoOpen
300100==e?6==t?_.V.SendClickData(300109):30==t?_.V.SendClickData(300110):60==t&&_.V.SendClickData(300111):310300==e?6==t?_.V.SendClickData(310309):30==t?_.V.SendClickData(310310):60==t&&_.V.SendClickData(310311):301300==e&&(6==t?_.V.SendClickData(301309):30==t?_.V.SendClickData(301310):60==t&&_.V.SendClickData(301311)),
p.t.inst.Buy(this.rechargeCfg,null,null),this.CloseHandler()}RemoveLis(){this.m_handlerMgr.RemoveClickEvent(this.btnrecharge,this.CreateDelegate(this.OnChargeClick)),
this.m_handlerMgr.RemoveClickEvent(this.closebtn,this.CreateDelegate(this.CancelbtnClick)),
this.m_handlerMgr.RemoveClickEvent(this.closebtn2,this.CreateDelegate(this.ClosebtnClick))}CloseHandler(){(0,o.sR)(S.o.FirstChargeRewardShow)}InitView(){super.InitView()}Clear(){
super.Clear(),this.model.firstRechargeChecked=!1,this.RemoveLis()}Destroy(){super.destroy(),this.unattach=null}Test1(){return!0}S_Test(){return!0}}).POS=[126,-248],s=n))||s},
81534:(t,e,i)=>{i.d(e,{H:()=>I})
var s,n=i(6847),l=i(83908),a=i(17409),o=i(46282),r=i(63076),h=i(23628),d=i(56532),u=i(49655),c=i(28192),_=i(67885)
let I=(0,n.s_)(u.o.FirstChargeSuccessPanel,o.Z.ui_ryfirstcharge_successpanel).waitPrefab(_.S.modulePathList).register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),
this.model=null,this.rewardData=null,this._m_handlerMgr=null}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=c.h.Get()),this._m_handlerMgr}InitView(){
super.InitView()}OnAddToScene(){this.AddLis(),this.model=d.F.Inst_get()
const t=this.model.extrarewards
this.rewardData=r.M.wrapReward(t.rewards[0]),this.itemnamelab.textSet(h.b.GetNameStr(this.rewardData,null,null,null,null)),this.rewarditem.SetData(this.rewardData)}AddLis(){
this.m_handlerMgr.AddClickEvent(this.closebtn,this.CreateDelegate(this.CloseHandler)),this.m_handlerMgr.AddClickEvent(this.confirmbtn,this.CreateDelegate(this.CloseHandler))}
CloseHandler(){(0,a.sR)(u.o.FirstChargeSuccessPanel)}RemoveLis(){this.m_handlerMgr.RemoveClickEvent(this.closebtn,this.CreateDelegate(this.CloseHandler)),
this.m_handlerMgr.RemoveClickEvent(this.confirmbtn,this.CreateDelegate(this.CloseHandler))}Clear(){this.RemoveLis(),super.Clear()}Destroy(){super.destroy()}Test1(){return!0}
S_Test(){return!0}})||s},56959:(t,e,i)=>{
var s,n=i(6847),l=i(83908),a=i(49655),o=i(46282),r=i(38836),h=i(97461),d=i(65530),u=i(68662),c=i(62370),_=i(5924),I=i(76544),m=i(66788),g=i(5494),p=i(28192),C=i(98885),S=i(85602),f=i(52212),y=i(79534),v=i(70850),D=i(63076),E=i(67885),T=i(20099),A=i(92679),L=i(33314),w=i(87923),R=i(75439),O=i(33138),G=i(47786),b=i(31896),M=i(65550),P=i(70531),B=i(38787),x=i(91897),N=i(56532),k=i(31222),V=i(34402),F=i(7155),U=i(41347)
class H extends((0,l.yk)()){constructor(...t){super(...t),this.basedata=null}InitView(){super.InitView()}Destroy(){this.baseItem.destroy()}SetData(t){this.baseItem.SetData(t),
this.basedata=t
const e=this.basedata.cfgData_get().id,i=N.F.Inst_get().IsUnique(e)
this.jueban.SetActive(i)
const s=N.F.Inst_get().IsPerpetual(e)
this.yongjiu.SetActive(s),this.getedicon.SetActive(!1)}SetGeted(t){this.getedicon.SetActive(t)}Clear(){}}(0,
n.s_)(a.o.FirstChargePanel,o.Z.ui_firstcharge_mainpanel).waitPrefab(E.S.modulePathList).register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),
this._rewardConfigs=null,this.delayExecutor=null,this.typeIndex=0,this.dayDetailArr=null,this._intervalId=-1,this._degf_OnCharge=null,this._degf_OnClose=null,
this._degf_OnCreateItem=null,this._degf_OnItemTips=null,this._degf_OnReward=null,this._degf_OnDayBtn=null,this._degf_UpdataForServer=null,this._degf_OnTabSelect=null,
this._degf_GetRewardedCell=null,this._degf_TimeChange=null,this.job=null,this.tabBtnList=null,this.model=null,this.roleRotateIndex=null,this.rewardData=null,this.time=null,
this.rewardRes=null,this._m_handlerMgr=null}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=p.h.Get()),this._m_handlerMgr}_initBinder(){super._initBinder(),
this.delayExecutor=new I.p,this._degf_OnCharge=(t,e)=>this.OnCharge(t,e),this._degf_OnCreateItem=t=>{},this._degf_OnItemTips=t=>this.OnItemTips(t),
this._degf_OnReward=(t,e)=>this.OnReward(t,e),this._degf_OnDayBtn=(t,e)=>this.OnDayBtn(t,e),this._degf_UpdataForServer=t=>this.UpdataForServer(t),
this._degf_OnTabSelect=t=>this.OnTabSelect(t),this._degf_GetRewardedCell=t=>{},this._degf_TimeChange=()=>this.DoTimerInterval()}closeThisPanel(){x.v.Inst_get().ClosePanel()}
InitView(){super.InitView(),this.job=0,this.tabBtnList=new S.Z,this.tabBtnList.Add(this.btn1),this.tabBtnList.Add(this.btn2),this.tabBtnList.Add(this.btn3),
this.dayDetailArr=[this.dayDetail1,this.dayDetail2,this.dayDetail3],this.rewardGrid.SetInitInfo("ui_firstcharge_item",null,H),
this.rewardGrid.OnReposition_set(this.CreateDelegate(this.RewardOnReposition)),this.rewardTagGrid.SetInitInfo("ui_v1p_rewardedcell",null,B.Q),this.model=N.F.Inst_get(),
this.model.InitRecharge(),this.tipslabel.textSet(G.x.Inst().getItemStrById(122024))}RewardOnReposition(){const t=this.model.IsRewarded(this.typeIndex)==N.F.GAIN
for(let e=0;e<=this.rewardGrid.itemList.Count()-1;e++)this.rewardGrid.itemList[e].SetGeted(t)}Destroy(){this.rewardGrid.destroy(),this.rewardTagGrid.destroy()
for(let t=0;t<=this.tabBtnList.Count()-1;t++)this.tabBtnList[t].destroy()}OnAddToScene(){const t=N.F.Inst_get().whoOpen
if(300100==t?T.V.SendClickData(300101):310300==t?T.V.SendClickData(310301):301300==t&&T.V.SendClickData(301301),this.AddListeners(),F.o.Inst_get().IncreaseOpenCount(),
this._rewardConfigs=this.model.GetRewards(),!this._rewardConfigs||0==this._rewardConfigs.Count())return
this.rewardRes=this._rewardConfigs[0]
const e=this._rewardConfigs[0].rewards[0].itemModelId,i=O.f.Inst().getItemById(e)
this.job=L.Z.GetJobKind(i.job),this.rewardGrid.data_set(this.GetDataList()),this.SetState()
for(let t=0;t<=this.tabBtnList.Count()-1;t++)this.tabBtnList[t].SetData(t),this.tabBtnList[t].clickHandler=this._degf_OnTabSelect
this.tabBtnList[this.model.GetUnGainIndex()].SetSelect(!0)
let s=""
1==this.job?s="ryshouchong_bt_0003":2==this.job?s="ryshouchong_bt_0005":3==this.job&&(s="ryshouchong_bt_0004"),this.extrashow.spriteNameSet(s),
s=C.M.Replace("{0}元","{0}",""+this.model.GetRechargeValue(0)),this.chargelab1.textSet(s),s=C.M.Replace("{0}元","{0}",""+this.model.GetRechargeValue(1)),this.chargelab2.textSet(s),
s=C.M.Replace("{0}元","{0}",""+this.model.GetRechargeValue(2)),this.chargelab3.textSet(s),s=C.M.Replace("{0}元","{0}",""+this.model.GetRechargeValue(3)),this.chargelab4.textSet(s),
this.diammondlab1.textSet(`获得${this.model.GetRechargeDiamond(0)}`),this.diammondlab2.textSet(`获得${this.model.GetRechargeDiamond(1)}`),
this.diammondlab3.textSet(`获得${this.model.GetRechargeDiamond(2)}`),this.diammondlab4.textSet(`获得${this.model.GetRechargeDiamond(3)}`)}OnDayBtn(t,e){}Clear(){this.RemoveListeners(),
this._rewardConfigs=null,this.rewardRes=null,this.delayExecutor.Clear(),this.ClearTime(),this.ClearEffect(),this.roleRotateIndex=null,super.Clear()}AddListeners(){
this.m_handlerMgr.AddClickEvent(this.closeBtn,this.closeThisPanel),this.m_handlerMgr.AddClickEvent(this.rewardBtn,this._degf_OnReward),
this.model.AddEventHandler(N.F.CONFIG_UPDATE,this._degf_UpdataForServer),this.m_handlerMgr.AddClickEvent(this.collider,this.CreateDelegate(this.OnColliderClick)),
h.i.Inst.AddEventHandler(A.g.TipsLoadCompelete,this.CreateDelegate(this.OpenEquipTips)),this.m_handlerMgr.AddClickEvent(this.chargebtn1,this.CreateDelegate(this.OnCharge)),
this.m_handlerMgr.AddClickEvent(this.chargebtn2,this.CreateDelegate(this.OnCharge)),this.m_handlerMgr.AddClickEvent(this.chargebtn3,this.CreateDelegate(this.OnCharge)),
this.m_handlerMgr.AddClickEvent(this.chargebtn4,this.CreateDelegate(this.OnCharge)),this.m_handlerMgr.AddClickEvent(this.extrashow,this.CreateDelegate(this.OnExtraShow))}
RemoveListeners(){this.m_handlerMgr.RemoveClickEvent(this.closeBtn,this.closeThisPanel),this.m_handlerMgr.RemoveClickEvent(this.rewardBtn,this._degf_OnReward),
this.model.RemoveEventHandler(N.F.CONFIG_UPDATE,this._degf_UpdataForServer),this.m_handlerMgr.RemoveClickEvent(this.collider,this.CreateDelegate(this.OnColliderClick)),
h.i.Inst.RemoveEventHandler(A.g.TipsLoadCompelete,this.CreateDelegate(this.OpenEquipTips)),this.m_handlerMgr.RemoveClickEvent(this.chargebtn1,this.CreateDelegate(this.OnCharge)),
this.m_handlerMgr.RemoveClickEvent(this.chargebtn2,this.CreateDelegate(this.OnCharge)),this.m_handlerMgr.RemoveClickEvent(this.chargebtn3,this.CreateDelegate(this.OnCharge)),
this.m_handlerMgr.RemoveClickEvent(this.chargebtn4,this.CreateDelegate(this.OnCharge)),this.m_handlerMgr.RemoveClickEvent(this.extrashow,this.CreateDelegate(this.OnExtraShow))}
OnColliderClick(){const t=this.rewardRes.rewards[0],e=D.M.wrapReward(t)
if(0==this.typeIndex)INS.itemTipManager.OpenBaseItemDataTip(e)
else if(1==this.typeIndex)INS.itemTipManager.OpenBaseItemDataTip(e)
else if(2==this.typeIndex){let t=null
const i=V.$.Inst().GetRewardList(e.modelId_get())
for(let e=0;e<=i.Count()-1;e++){const s=O.f.Inst().getItemById(i[e].itemId)
if(L.Z.GetJobKind(s.job)==this.job){t=new D.M(s.id),t.isShowModelTip=!1,t.isShowMask=!1
break}}this.rewardData=t,U.i.Inst_get().selectingGroupId=this.job,P.R.Inst_get().OpenView(e,null)
k.N.inst.GetViewById(g.I.RyPandoraTipsPanel)&&P.R.Inst_get().PandoraShowChildTips(this.rewardData,null)}}OpenEquipTips(t){
t==g.I.RyPandoraTipsPanel&&null!=this.rewardData&&_.C.Inst_get().CallLater(this.CreateDelegate(this.ShowTips))}ShowTips(){P.R.Inst_get().PandoraShowChildTips(this.rewardData,null)}
OnCharge(t,e){const i=N.F.Inst_get().whoOpen
this.chargebtn1.tweenTarget.name==t.target._name?(300100==i?T.V.SendClickData(300102):310300==i?T.V.SendClickData(310302):301300==i&&T.V.SendClickData(301302),
x.v.Inst_get().OpenRewardShow(this.model.rechargeList[0])):this.chargebtn2.tweenTarget.name==t.target._name?(300100==i?T.V.SendClickData(300103):310300==i?T.V.SendClickData(310303):301300==i&&T.V.SendClickData(301303),
x.v.Inst_get().OpenRewardShow(this.model.rechargeList[1])):this.chargebtn3.tweenTarget.name==t.target._name?(300100==i?T.V.SendClickData(300104):310300==i?T.V.SendClickData(310304):301300==i&&T.V.SendClickData(301304),
x.v.Inst_get().OpenRewardShow(this.model.rechargeList[2])):this.chargebtn4.tweenTarget.name==t.target._name&&(300100==i?T.V.SendClickData(300105):310300==i?T.V.SendClickData(310305):301300==i&&T.V.SendClickData(301305),
b.t.inst.Buy(this.model.GetFinalChargeCfg(),this.model.GetRechargeValue(3),!1))}OnExtraShow(){x.v.Inst_get().OpenRewardShow(this.model.rechargeList[3])}OnReward(t,e){
v.g.Inst_get().getBagEmptyGridNum()<this.model.GetRewardCount(this.typeIndex)?M.y.inst.ClientSysMessage(101001):(x.v.Inst_get().CM_GetReward(this.model.GetRewardId(this.typeIndex)),
0==this.typeIndex?this.tabBtnList[1].SetSelect(!0):1==this.typeIndex&&this.tabBtnList[2].SetSelect(!0))}UpdateModel(t){if(this.ClearEffect(),
1==t)this.jobRewardSp.node.SetActive(!1),this.ShowTitle()
else{this.HideTitle(),this.jobRewardSp.node.SetActive(!0)
let e="",i=null,s=1,n=0,l=0
1==this.job?0==t?(e="atlas/shouchong/ryshouchong_sp_0013",i="pre_eff_first_recharge_sm",s=1.2,n=-2,l=-5):(e="atlas/shouchong/ryshouchong_sp_0016",
i="pre_eff_first_recharge_sm_02"):2==this.job?0==t?(e="atlas/shouchong/ryshouchong_sp_0012",i="pre_eff_first_recharge_mg",s=1.3):(e="atlas/shouchong/ryshouchong_sp_0015",
i="pre_eff_first_recharge_mg_02"):3==this.job&&(0==t?(e="atlas/shouchong/ryshouchong_sp_0011",i="pre_eff_first_recharge_ac"):(e="atlas/shouchong/ryshouchong_sp_0014",
i="pre_eff_first_recharge_ac_02")),this.ShowEffect(i,s,n,l),this.jobRewardSp.skin=e}}ShowEffect(t,e,i,s){if(null!=t){this.effect.node.active=!0,this.effect.path=t
;(new y.P).Set(e,e,1)
const n=y.P.zero_get()
n.x=i,n.y=s,n.z=0}}ClearEffect(){null!=this.effect&&(this.effect.node.active=!1)}HideTitle(){this.titleWarrior.SetActive(!1)}ShowTitle(){this.titleWarrior.SetActive(!0)}getPos(){
const t=new S.Z,e=R.D.getInstance().GetStringValue("RECHARGE:JOB_WEAPON_EFF"),i=C.M.Split(e,C.M.s_Arr_CCD_CHAR_DOT)
for(const[e,s]of(0,r.V5)(i)){const e=C.M.Split(s,c.o.s_Arr_UNDER_CHAR_DOT),i=new y.P
i.x=C.M.String2Float(e[0]),i.y=C.M.String2Float(e[1]),i.z=C.M.String2Float(e[2]),t.Add(i)}return t}UpdataForServer(t){this._rewardConfigs=this.model.GetRewards(),
this.OnTabSelect(this.typeIndex)}SetState(){const t=N.F.Inst_get().ChargeState_get()
if(0==t)this.chargebtn1.node.SetActive(!0),this.chargebtn2.node.SetActive(!0),this.chargebtn3.node.SetActive(!0),this.chargebtn4.node.SetActive(!0),
this.rewardBtn.node.SetActive(!1),this.chargeTiparea.SetActive(!0),this.day3Sp.node.SetActive(!1),this.day2Sp.textSet(""),this.maintag.SetActive(!0)
else{this.chargebtn1.node.SetActive(!1),this.chargebtn2.node.SetActive(!1),this.chargebtn3.node.SetActive(!1),this.chargebtn4.node.SetActive(!1),this.chargeTiparea.SetActive(!1),
this.maintag.SetActive(!1),this.rewardBtn.node.SetActive(1==t)
const e=this.model.IsRewarded(this.typeIndex),i=new y.P(406,0,0),s=new y.P(-138,110,0)
this.day3Sp.node.SetActive(e==N.F.GAIN),this.time=this.model.GetTime(this.typeIndex).ToNum(),this.SetTimeTxt(),y.P.Recyle(i),y.P.Recyle(s)}this.UpdateRedPoint()}SetTimeTxt(){
this.ClearTime(),this.time>u.D.serverMSTime_get()?(this.rewardBtn.node.SetActive(!1),this._intervalId=_.C.Inst_get().SetInterval(this._degf_TimeChange,1e3),
this.DoTimerInterval()):this.day2Sp.textSet(""),this.HandleRewardBtn()}HandleRewardBtn(){let t=!1
this.model.IsRewarded(this.typeIndex)==N.F.ACTIVE&&this.time<u.D.serverMSTime_get()&&(t=!0),this.rewardBtn.node.SetActive(t)}DoTimerInterval(){
const t=this.time-u.D.serverMSTime_get()
if(t<0)return this.ClearTime(),this.day2Sp.textSet(""),void this.HandleRewardBtn()
const e=w.l.GetDateFormatEXX(t,!0,!0,null),i=C.M.Replace("{0}后可领取","{0}",e)
this.day2Sp.textSet(i)}ClearTime(){_.C.Inst_get().ClearInterval(this._intervalId),this._intervalId=-1}UpdateRedPoint(){let t=!1,e=!1,i=!1
t=this.model.CanGetReward(this.model.rewardInfoes[0]),e=this.model.CanGetReward(this.model.rewardInfoes[1]),i=this.model.CanGetReward(this.model.rewardInfoes[2]),
this.tip1.SetActive(t&&0!=this.typeIndex),this.tip2.SetActive(e&&1!=this.typeIndex),this.tip3.SetActive(i&&2!=this.typeIndex)}OnTabSelect(t){this.typeIndex=t,
this.rewardRes=this._rewardConfigs[t]
const e=this.GetDataList()
this.rewardGrid.data_set(e)
for(let t=0;t<this.dayDetailArr.length;t++)this.dayDetailArr[t].SetActive(!1)
this.dayDetailArr[t].SetActive(!0),this.SetState(),this.UpdateModel(t)
let i=!0
2!=this.typeIndex&&1!=this.typeIndex||(i=!1)}GetDataList(){const t=new S.Z,e=this.rewardRes.rewards
for(const[i,s]of(0,r.V5)(e)){const e=s,i=new D.M(e.itemModelId,null)
i.count=e.num,i.isNoBagItemData=!0,i.tag=1,i.isCanOperate=!1,t.Add(i)}return t}OnItemTips(t){const e=this.node.getPosition()
d.x.Instance_get().WorldToScreenPoint(e)
t.anchor=new f.F(.5,.5),t.tipsPos=new y.P(221,0,0)}TestLoad(){m.Y.LogError("reload succed")}})},90330:(t,e,i)=>{var s,n,l=i(18998),a=i(51868)
l._decorator.ccclass("FirstTabBtn")((n=class t extends a.${constructor(...t){super(...t),this.tip=null,this.normal=null,this.selected=null,this.index=-1,this.clickHandler=null}
InitView(){super.InitView(),this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.OnClickItem)),this.tip=this.node.getChildByPath("tip"),
this.normal=this.node.getChildByPath("normal"),this.selected=this.node.getChildByName("selected")}SetData(t){this.index=t,this.SetSelect(!1)}OnClickItem(){this.SetSelect(!0)}
SetSelect(e){e?(null!=t._selectItem&&t._selectItem.SetSelect(!1),this.selected.SetActive(!0,null,null),this.normal.SetActive(!1,null,null),
t._selectItem!=this&&null!=this.clickHandler&&this.clickHandler(this.index),t._selectItem=this):(this.selected.SetActive(!1,null,null),this.normal.SetActive(!0,null,null))}
Destroy(){null!=t._selectItem&&t._selectItem.SetSelect(!1),t._selectItem=null,this.clickHandler=null,super.destroy()}},n._selectItem=null,s=n))},1740:(t,e,i)=>{i.d(e,{Q:()=>d})
var s=i(56937),n=i(18202),l=i(31222),a=i(5494),o=i(20099),r=i(88911),h=i(54461)
class d{constructor(){this.forgeView=null,this.topUseDefaultTab=!1,this.enhanceUseDefaultTab=!1,this.suitUseDefaultTab=!1,this.compoundUseDefaultTab=!1,this.wingUseDefaultTab=!1,
this.flagUseDefaultTab=!1,this._degf_ForgeDestroyHandler=null,this._degf_ForgeShowHandler=null,this._degf_ForgeDestroyHandler=()=>this.ForgeDestroyHandler(),
this._degf_ForgeShowHandler=t=>this.ForgeShowHandler(t)}OpenForgePanel(t){null==t&&(t=!1),this.topUseDefaultTab=t,this.enhanceUseDefaultTab=t,this.suitUseDefaultTab=t,
this.compoundUseDefaultTab=t,this.wingUseDefaultTab=t,this.flagUseDefaultTab=t,o.V.SendClickData(r.p.Step_312000),this.Open()}GetForgeViewFindId(){
return null!=this.forgeView?this.forgeView.node.FatherId:0}Open(){if(null!=this.forgeView&&this.forgeView.isShow_get())this.forgeView.ShowViewByType()
else{const t=new s.v
t.isShowMask=!0,t.isDefaultUITween=!0,l.N.inst.OpenById(a.I.ForgePanel,this._degf_ForgeShowHandler,this._degf_ForgeDestroyHandler,t)}}ForgeDestroyHandler(){
n.g.DestroyUIObj(this.forgeView),this.forgeView=null}ForgeShowHandler(t){return null==this.forgeView&&(this.forgeView=new h.c,this.forgeView.setId(t,null,0)),this.forgeView}
CloseForgePanel(){null!=this.forgeView&&l.N.inst.ClosePanel(this.forgeView)}GetMainPanelFatherId(){return null!=this.forgeView?this.forgeView.FatherId:-1}IsForgeOpen(){
if(null!=this.forgeView)return this.forgeView.isShow_get()}}d.inst=null},21987:(t,e,i)=>{i.d(e,{N:()=>bt})
var s=i(42292),n=i(71409),l=i(86133),a=i(98800),o=i(28236),r=i(28475),h=i(68662),d=i(38935),u=i(56937),c=i(18202),_=i(31222),I=i(5494),m=i(52726),g=i(95721),p=i(98130),C=i(98885),S=i(85602),f=i(52212),y=i(26753),v=i(82803),D=i(74045),E=i(39879),T=i(49067),A=i(27122),L=i(74328),w=i(77599),R=i(24730),O=i(60983),G=i(62091),b=i(68069),M=i(7152),P=i(48875),B=i(29883),x=i(68866),N=i(22662),k=i(14792),V=i(62734),F=i(65550),U=i(39043),H=i(33542),q=i(30635),Z=i(92415),j=i(50077),X=i(66788),Y=i(99294),W=i(9986),$=i(6665),J=i(9776),z=i(69029),Q=i(30849),K=i(87923),tt=i(24315),et=i(43133),it=i(9057),st=i(57834),nt=i(93877),lt=i(72005),at=i(33314),ot=i(41864),rt=i(6251)
class ht extends it.x{constructor(){super(),this._listener=null,this.spr_headIcon=null,this.lab_roleName=null,this.btn_ok=null,this.lab_level=null,this.viplevel=null,
this.bgBox=null,this.btn_ignore=null,this._vo=null,this._degf_OnBoxClick=null,this._degf_OnOkClick=null,this._degf_OnIgnoreClick=null,this._degf_OnShowMenuClick=null,
this._degf_OnFriendAddCallback=null,this.btn_add=null,this.headwidget=null,this.chatbtn=null,this.onlinearea=null,this.onlinelab=null,this.headcollider=null,this.headIcon=null,
this._degf_OnBoxClick=(t,e)=>this.OnBoxClick(t,e),this._degf_OnOkClick=(t,e)=>this.OnOkClick(t,e),this._degf_OnIgnoreClick=(t,e)=>this.OnNoClick(t,e),
this._degf_OnShowMenuClick=()=>this.OnShowMenuClick(),this._degf_OnFriendAddCallback=t=>this.OnFriendAddCallback(t)}InitView(){super.InitView(),
this.spr_headIcon=this.CreateComponent(et.V,1),this.lab_roleName=this.CreateComponent(nt.Q,2),this.btn_ok=this.CreateComponent(W.W,4),this.lab_level=this.CreateComponent(nt.Q,6),
this.bgBox=this.CreateComponent(et.V,9),this.btn_ignore=this.CreateComponent(W.W,10),this.btn_add=this.CreateComponent(W.W,12),this.headwidget=this.CreateComponent(Y.z,13),
this.chatbtn=this.CreateComponent(W.W,14),this.onlinearea=this.CreateComponent(Y.z,15),this.onlinelab=this.CreateComponent(nt.Q,16),this.headcollider=this.CreateComponent(Y.z,17),
this.headIcon=this.CreateComponent(lt.w,18)}HeadClick(){bt.Inst_get().OpenOperationPanel(this._vo)}OnShowMenuClick(){bt.Inst_get().OpenOperationPanel(this._vo)}OnNoClick(t,e){
null!=this._vo&&this._vo.m_type==v.u.ReqList&&bt.Inst_get().ReqRecommendResult(this._vo.m_vo.playerId,!1)}ChatBtnClick(){
y.d.Inst_get().controller.PrivateChat(this._vo.m_vo.name,this._vo.m_vo.playerId,0==this._vo.m_vo.offlineTime.ToNum(),this._vo.m_vo.job,this._vo.m_vo.sex),
_.N.inst.CloseById(I.I.RYFriendPanel)}OnBoxClick(t,e){
this._vo.m_type==v.u.FriendList?y.d.Inst_get().controller.PrivateChat(this._vo.m_vo.name,this._vo.m_vo.playerId,0==this._vo.m_vo.offlineTime.ToNum(),this._vo.m_vo.job,this._vo.m_vo.sex):bt.Inst_get().OpenOperationPanel(this._vo)
}OnOkClick(t,e){
null!=this._vo&&(this._vo.m_type==v.u.SearchList?bt.Inst_get().ReqAddFriend(this._vo.m_vo.playerId):this._vo.m_type==v.u.ReqList?bt.Inst_get().ReqRecommendResult(this._vo.m_vo.playerId,!0):this._vo.m_type==v.u.FriendList?y.d.Inst_get().controller.PrivateChat(this._vo.m_vo.name,this._vo.m_vo.playerId,0==this._vo.m_vo.offlineTime.ToNum(),this._vo.m_vo.job,this._vo.m_vo.sex):this._vo.m_type==v.u.BlackList&&bt.Inst_get().ReqUnBlack(this._vo.m_vo.playerId))
}OnFriendAddCallback(t){this._vo.m_vo.playerId.Equal(t)&&(this.btn_add.SetIsEnabled(!1),rt.d.LuaMakeGoGray(this.btn_add.node.FatherId,this.btn_add.node.ComponentId,!0,!0))}
Destroy(){st.i.Get(this.btn_ok.node).RemoveonClick(this._degf_OnOkClick),st.i.Get(this.btn_ignore.node).RemoveonClick(this._degf_OnIgnoreClick),
st.i.Get(this.btn_add.node).RemoveonClick(this._degf_OnOkClick),st.i.Get(this.bgBox.node).RemoveonClick(this._degf_OnBoxClick),super.Destroy()}SetData(t){
if(st.i.Get(this.btn_ok.node).RegistonClick(this._degf_OnOkClick),st.i.Get(this.btn_ignore.node).RegistonClick(this._degf_OnIgnoreClick),
st.i.Get(this.btn_add.node).RegistonClick(this._degf_OnOkClick),st.i.Get(this.bgBox.node).RegistonClick(this._degf_OnBoxClick),this.InitHandlerMgr(),
this.m_handlerMgr.AddClickEvent(this.spr_headIcon,this.CreateDelegate(this.HeadClick)),this.m_handlerMgr.AddClickEvent(this.chatbtn,this.CreateDelegate(this.ChatBtnClick)),
this.addListeners(),this._vo=t,null==this._vo)return
this.lab_roleName.textSet(this._vo.m_vo.name)
const e=at.Z.GetJobIcon(this._vo.m_vo.job,this._vo.m_vo.sex,!1)
if(this.headIcon.spriteNameSet(e),this.chatbtn.node.SetActive(!1),this._vo.m_type==v.u.SearchList?(this.btn_ok.node.SetActive(!1),this.btn_ignore.node.SetActive(!1),
this.btn_add.node.SetActive(!0)):this._vo.m_type==v.u.ReqList?(this.btn_ok.SetText((0,l.T)("接受")),this.btn_ok.node.SetActive(!0),this.btn_ignore.node.SetActive(!0),
this.btn_add.node.SetActive(!1)):this._vo.m_type==v.u.BlackList?(this.btn_ok.SetText((0,l.T)("移除")),this.btn_ok.node.SetActive(!0),this.btn_ignore.node.SetActive(!1),
this.btn_add.node.SetActive(!1)):this._vo.m_type==v.u.FriendList&&(this.chatbtn.node.SetActive(!0),this.btn_ok.node.SetActive(!1),this.btn_ignore.node.SetActive(!1),
this.btn_add.node.SetActive(!1)),this.lab_level.textSet(ot.h.GetLevelStr(this._vo.m_vo.level)),
0==this._vo.m_vo.offlineTime.ToNum())rt.d.LuaMakeGoGray(this.FatherId,this.onlinearea.ComponentId,!1,!0,!1),this.onlinelab.textSet((0,l.T)("[047104]在线[-]"))
else{rt.d.LuaMakeGoGray(this.FatherId,this.onlinearea.ComponentId,!0,!0,!1)
const t=bt.Inst_get().GetOffsetTimeStr(this._vo.m_vo.offlineTime.ToNum())
this.onlinelab.textSet((0,l.T)(`[CCCCCC]${t}[-]`))}}Clear(){this.removeListeners(),this.btn_add.SetIsEnabled(!0),
rt.d.LuaMakeGoGray(this.btn_add.node.FatherId,this.btn_add.node.ComponentId,!1,!0)}addListeners(){
j.C.Inst_get().AddEventHandler(j.C.eFriendAddCallback,this._degf_OnFriendAddCallback)}removeListeners(){
j.C.Inst_get().RemoveEventHandler(j.C.eFriendAddCallback,this._degf_OnFriendAddCallback),this.m_handlerMgr.RemoveClickEvent(this.spr_headIcon,this.CreateDelegate(this.HeadClick))}}
var dt=i(13113),ut=i(60130),ct=i(2886),_t=i(37151),It=i(63563)
class mt extends it.x{constructor(){super(),this._listener=null,this.headObject=null,this.spr_headIcon=null,this.lab_roleName=null,this.btn_chat=null,this.btn_del=null,
this.lab_online=null,this.lab_level=null,this.viplevel=null,this.marry=null,this.bgBox=null,this.youhaodu_icon=null,this.level=null,this._vo=null,this._degf_OnBoxClick=null,
this._degf_OnFriendUpdate=null,this._degf_OnHeadClick=null,this._degf_OnDelClick=null,this._degf_OnChatClick=null,this.jobTime=null,this._degf_OnBoxClick=(t,e)=>this.OnShowMenu(),
this._degf_OnFriendUpdate=t=>this.OnFriendUpdate(t),this._degf_OnHeadClick=()=>this.OnShowMenu(),this._degf_OnDelClick=(t,e)=>this.OnUnBlack(),
this._degf_OnChatClick=(t,e)=>this.OnChat()}InitView(){super.InitView(),this.spr_headIcon=new dt.T,this.spr_headIcon.setId(this.FatherId,this.FatherComponentID,1),
this.headObject=new ct.n,this.headObject.Init(this.spr_headIcon,this._degf_OnHeadClick),this.lab_roleName=new nt.Q,this.lab_roleName.setId(this.FatherId,this.FatherComponentID,2),
this.btn_chat=new W.W,this.btn_chat.setId(this.FatherId,this.FatherComponentID,3),this.btn_del=new W.W,this.btn_del.setId(this.FatherId,this.FatherComponentID,4),
this.lab_online=new nt.Q,this.lab_online.setId(this.FatherId,this.FatherComponentID,5),this.lab_level=new nt.Q,this.lab_level.setId(this.FatherId,this.FatherComponentID,6),
this.viplevel=new lt.w,this.viplevel.setId(this.FatherId,this.FatherComponentID,7),this.marry=new lt.w,this.marry.setId(this.FatherId,this.FatherComponentID,8),this.bgBox=new et.V,
this.bgBox.setId(this.FatherId,this.FatherComponentID,9),this.level=new lt.w,this.level.setId(this.FatherId,this.FatherComponentID,13),this.jobTime=this.CreateComponent(nt.Q,14),
st.i.Get(this.btn_chat.node).RegistonClick(this._degf_OnChatClick),st.i.Get(this.btn_del.node).RegistonClick(this._degf_OnDelClick),
st.i.Get(this.bgBox.node).RegistonClick(this._degf_OnBoxClick),j.C.Inst_get().AddEventHandler(j.C.eFriendUpdate,this._degf_OnFriendUpdate)}OnFriendUpdate(t){const e=t
null!=e&&null!=this._vo&&e.playerId.Equal(this._vo.m_vo.playerId)&&(this._vo.m_vo=e,this.SetData(this._vo))}OnShowMenuClick(t,e){this.OnShowMenu()}OnShowMenu(){
bt.Inst_get().OpenOperationPanel(this._vo)}OnUnBlack(){bt.Inst_get().ReqUnBlack(this._vo.m_vo.playerId)}OnChat(){
y.d.Inst_get().controller.PrivateChat(this._vo.m_vo.name,this._vo.m_vo.playerId,0==this._vo.m_vo.offlineTime.ToNum())}Destroy(){
st.i.Get(this.btn_chat.node).RemoveonClick(this._degf_OnChatClick),st.i.Get(this.btn_del.node).RemoveonClick(this._degf_OnDelClick),
st.i.Get(this.bgBox.node).RemoveonClick(this._degf_OnBoxClick),j.C.Inst_get().RemoveEventHandler(j.C.eFriendUpdate,this._degf_OnFriendUpdate),this.headObject.Destory(),
super.Destroy()}SetData(t){this._vo=t,null!=this._vo&&(this.headObject.SetHeadIcon(this._vo.m_vo.job,this._vo.m_vo.sex,this._vo.m_vo.playerId),this.marry.node.SetActive(!1),
this.btn_chat.node.SetActive(!1),this.btn_del.node.SetActive(!1),this.lab_online.node.SetActive(!1),this.viplevel.node.SetActive(this._vo.m_vo.vipLevel>0),
this.viplevel.spriteNameSet(It.m.GetVipSpriteName(this._vo.m_vo.vipLevel)),null!=this.jobTime&&this.jobTime.node.SetActive(!1),this.SetOnlineState(this._vo.m_vo.offlineTime),
this._vo.m_type==v.u.FriendList?(this.btn_chat.node.SetActive(!0),this.btn_del.node.SetActive(!1),this.lab_online.node.SetActive(!0),
this.lab_online.textSet(j.C.Inst_get().GetOnlineStatus(this._vo.m_vo.offlineTime))):this._vo.m_type==v.u.BlackList&&(this.btn_chat.node.SetActive(!1),
this.btn_del.node.SetActive(!0)))}SetOnlineState(t){const e=_t.Q.model.GetMasterStartLevel()
0==t.ToNum()?(this.lab_roleName.textSet(this._vo.m_vo.name),this._vo.m_vo.level>e?(this.level.spriteNameSet("mbcommon_sp_0120"),
this.lab_level.textSet(C.M.IntToString(this._vo.m_vo.level-e))):(this.level.spriteNameSet("mbcommon_sp_0120"),this.lab_level.textSet(C.M.IntToString(this._vo.m_vo.level))),
this.level.MakePixelPerfect(),ut.O.makeGoGray(this.level.node,!1,!1),ut.O.makeGoGray(this.viplevel.node,!1,!1),
this.headObject.SetGray(!1)):(this.lab_roleName.textSet(`[A0A0A0FF]${this._vo.m_vo.name}[-]`),this._vo.m_vo.level>e?(this.level.spriteNameSet("mbcommon_sp_0120"),
this.lab_level.textSet(`[A0A0A0FF]${C.M.IntToString(this._vo.m_vo.level-e)}[-]`)):(this.level.spriteNameSet("mbcommon_sp_0120"),
this.lab_level.textSet(`[A0A0A0FF]${C.M.IntToString(this._vo.m_vo.level)}[-]`)),this.level.MakePixelPerfect(),ut.O.makeGoGray(this.level.node,!0,!1),
ut.O.makeGoGray(this.viplevel.node,!0,!1),this.headObject.SetGray(!0))}Clear(){}}class gt extends Q.C{constructor(){super(),this.grid=null,this.closebtn=null,this.btn_search=null,
this.ipt_roleName=null,this.lab_none=null,this.btn_clearList=null,this.scrollview=null,this.dataList=null,this.lastSearchTime=0,this._degf_OnAddFriendHandler=null,
this._degf_OnClearList=null,this._degf_OnIptChange=null,this._degf_OnItemRefreshFun=null,this._degf_OnSeachClick=null,this._degf_OnSearchListHandler=null,
this._degf_UpdateRankData=null,this._degf_closeHandler=null,this.searchbtn=null,this.input=null,this.searchChatObj=null,this.grid2=null,this.listObj=null,this.nodata=null,
this.searchType=null,this.dataList=new S.Z,this._degf_OnAddFriendHandler=t=>this.OnAddFriendHandler(t),this._degf_OnClearList=(t,e)=>this.OnClearList(t,e),
this._degf_OnIptChange=()=>this.OnIptChange(),this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),this._degf_OnSeachClick=(t,e)=>this.OnSeachClick(t,e),
this._degf_OnSearchListHandler=t=>this.OnSearchListHandler(t),this._degf_UpdateRankData=()=>this.UpdateRankData(),this._degf_closeHandler=(t,e)=>this.closeHandler(t,e)}InitView(){
super.InitView(),this.grid=this.CreateComponent($.A,1),this.scrollview=this.CreateComponent(J.h,2),this.btn_search=this.CreateComponent(W.W,3),
this.ipt_roleName=this.CreateComponent(z.z,4),this.searchbtn=this.CreateComponent(W.W,5),this.input=this.CreateComponent(z.z,6),this.searchChatObj=this.CreateComponent(Y.z,7),
this.grid2=this.CreateComponent($.A,8),this.listObj=this.CreateComponent(Y.z,9),this.nodata=this.CreateComponent(Y.z,10),
this.grid.SetInitInfo("ui_ryfriend_addItem",this.CreateDelegate(this.OnItemRefreshFun))}OnSeachClick(t,e){const i=this.ipt_roleName.GetText()
K.l.IsEmptyStr(i)?F.y.inst.ClientStrMsg(N.r.SystemTipMessage,(0,l.T)("请输入要搜索的玩家名称")):(this.scrollview.ResetPosition(),bt.Inst_get().ResetSearchFriend(),
bt.Inst_get().SearchFriend(i))}OnClearList(t,e){this.ipt_roleName.SetText(""),this.OnSearchListHandler(new S.Z)}OnSearchListHandler(t){const e=t,i=0==this.searchType&&this.grid
this.dataList=new S.Z
let s=0
for(;s<e.Count();)e[s].playerId.Equal(a.Y.Inst.PrimaryRoleInfo_get().Id_get())||this.dataList.Add(new tt.O(0==this.searchType&&v.u.SearchList||v.u.SearchChatList,e[s])),s+=1
i.data_set(this.dataList),this.nodata.SetActive(0==this.dataList.Count())}OnAddFriendHandler(t){this.grid.Clear()
const e=t
let i=this.dataList.Count()-1
for(;i>-1;){if(this.dataList[i].m_vo.playerId.Equal(e.playerId)){this.dataList.RemoveAt(i)
break}i-=1}this.grid.data_set(this.dataList),this.scrollview.ResetPosition()}UpdateRankData(){p.GF.Timer_get()<this.lastSearchTime?X.Y.Log((0,
l.T)("太频繁")):(bt.Inst_get().SearchFriendNexPage(),this.lastSearchTime=p.GF.Timer_get()+1)}SetSelect(t){if(this.node.SetActive(t),t){this.nodata.SetActive(!1),
this.searchType=bt.Inst_get().friendSearchType,this.addListeners(),this.searchChatObj.SetActive(!1),this.listObj.SetActive(!0)
const t={show:!1}
j.C.Inst_get().RaiseEvent(j.C.eFriendViewNodata,t)}}addListeners(){this.m_handlerMgr.AddClearComponent(this.grid,!0),
this.m_handlerMgr.AddClickEvent(this.btn_search,this._degf_OnSeachClick),this.ipt_roleName.AddChangeEventHandler(this._degf_OnIptChange),
this.scrollview.RegiestGetSection(this.grid,this._degf_UpdateRankData),j.C.Inst_get().AddEventHandler(j.C.eFriendSearchList,this._degf_OnSearchListHandler),
j.C.Inst_get().AddEventHandler(j.C.eFriendAdd,this._degf_OnAddFriendHandler)}removeListeners(){this.m_handlerMgr.RemoveClickEvent(this.btn_search,this._degf_OnSeachClick),
this.ipt_roleName.RemoveChangeEventHandler(this._degf_OnIptChange),this.scrollview.RemoveGetSection(this._degf_UpdateRankData),
j.C.Inst_get().RemoveEventHandler(j.C.eFriendSearchList,this._degf_OnSearchListHandler),j.C.Inst_get().RemoveEventHandler(j.C.eFriendAdd,this._degf_OnAddFriendHandler)}
OnIptChange(){C.M.Length(this.ipt_roleName.GetText())}closeHandler(t,e){bt.Inst_get().CloseFriendAddView()}OnItemRefreshFun(t){const e=new ht
return e.setId(t,null,0),e}OnItem2RefreshFun(t){const e=new mt
return e.setPrefabRootId(t),e}Clear(){this.removeListeners(),bt.Inst_get().ResetSearchFriend(),this.grid.Clear(),super.Clear()}}var pt=i(61911),Ct=i(25035),St=i(68646),ft=i(38962)
class yt extends Q.C{constructor(){super(),this.grid=null,this.closebtn=null,this.lab_friendNum=null,this.btn_add=null,this.btn_reqList=null,this.typeTab=null,this.lab_title=null,
this.scrollview=null,this.scrollbar=null,this._degf_OnAddClick=null,this._degf_OnBlackListUpdate=null,this._degf_OnItemRefreshFun=null,this._degf_OnReqListClick=null,
this._degf_OnTypeSelect=null,this._degf_SetValue=null,this._degf_UpdateRedPoint=null,this.isExclusionPanel=null,this._degf_OnAddClick=(t,e)=>this.OnAddClick(t,e),
this._degf_OnBlackListUpdate=t=>this.OnBlackListUpdate(t),this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),this._degf_OnReqListClick=(t,e)=>this.OnReqListClick(t,e),
this._degf_OnTypeSelect=t=>this.OnTypeSelect(t),this._degf_SetValue=()=>this.SetValue(),this._degf_UpdateRedPoint=(t,e)=>this.UpdateRedPoint(t,e)}InitView(){super.InitView(),
this.isExclusionPanel=!0,this.scrollview=this.CreateComponent(J.h,1),this.grid=this.CreateComponent($.A,2),this.lab_friendNum=this.CreateComponent(nt.Q,3),
this.grid.SetInitInfo("ui_ryfriend_addItem",this.CreateDelegate(this.OnItemRefreshFun))}SetSelect(t){this.node.SetActive(t),t&&(this.addListeners(),this.OnBlackListUpdate())}
addListeners(){j.C.Inst_get().AddEventHandler(j.C.eBlackListUpdate,this._degf_OnBlackListUpdate),j.C.Inst_get().AddEventHandler(j.C.eBlackFriend,this._degf_OnBlackListUpdate),
j.C.Inst_get().AddEventHandler(j.C.eUnBlackFriend,this._degf_OnBlackListUpdate),bt.Inst_get().ReqGetBlackList()}removeListeners(){
j.C.Inst_get().RemoveEventHandler(j.C.eBlackListUpdate,this._degf_OnBlackListUpdate),j.C.Inst_get().RemoveEventHandler(j.C.eBlackFriend,this._degf_OnBlackListUpdate),
j.C.Inst_get().RemoveEventHandler(j.C.eUnBlackFriend,this._degf_OnBlackListUpdate)}SetValue(){}OnBlackListUpdate(t){this.grid.Clear()
const e=j.C.Inst_get().blackList,i=new S.Z
let s=0
for(;s<e.Count();){const t=e[s]
i.Add(new tt.O(v.u.BlackList,t)),s+=1}this.grid.data_set(i),this.lab_friendNum.textSet(`${(0,l.T)("人数：[047104]")}${i.Count()}[-]/${j.C.BlackNumMax}`),
this.scrollview.ResetPosition()
const n={}
n.show=0==j.C.Inst_get().blackList.Count(),n.show&&(n.str=(0,l.T)("暂无黑名单")),j.C.Inst_get().RaiseEvent(j.C.eFriendViewNodata,n)}OnItemRefreshFun(t){const e=new ht
return e.setId(t,null,0),e}OnTypeSelect(t){}Clear(){this.removeListeners(),this.grid.Clear(),q.Y.Inst().Close(),bt.Inst_get().CloseFriendAddView(),
bt.Inst_get().CloseFriendReqListView(),super.Clear()}Destroy(){super.Destroy()}}class vt extends Q.C{constructor(){super(),this.grid=null,this.btn_allIgnore=null,
this.btn_allPass=null,this.scrollview=null,this._degf_OnAllIgnoreClick=null,this._degf_OnAllPassClick=null,this._degf_OnItemRefreshFun=null,this._degf_OnListUpdate=null,
this._degf_closeHandler=null,this._degf_OnAllIgnoreClick=(t,e)=>this.OnAllIgnoreClick(t,e),this._degf_OnAllPassClick=(t,e)=>this.OnAllPassClick(t,e),
this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),this._degf_OnListUpdate=t=>this.OnListUpdate(t),this._degf_closeHandler=(t,e)=>this.closeHandler(t,e)}InitView(){
super.InitView(),this.grid=this.CreateComponent($.A,1),this.btn_allIgnore=this.CreateComponent(W.W,2),this.btn_allPass=this.CreateComponent(W.W,3),
this.scrollview=this.CreateComponent(J.h,4),this.grid.SetInitInfo("ui_ryfriend_addItem",this.CreateDelegate(this.OnItemRefreshFun))}OnAllIgnoreClick(t,e){
bt.Inst_get().ReqOneKeyRecommend(!1)}OnAllPassClick(t,e){bt.Inst_get().ReqOneKeyRecommend(!0)}SetSelect(t){this.node.SetActive(t),t&&this.addListeners()}addListeners(){
this.m_handlerMgr.AddClickEvent(this.btn_allIgnore,this._degf_OnAllIgnoreClick),this.m_handlerMgr.AddClickEvent(this.btn_allPass,this._degf_OnAllPassClick),
j.C.Inst_get().AddEventHandler(j.C.eRecommendListUpdate,this._degf_OnListUpdate),bt.Inst_get().ReqGetRecommendList(),this.OnListUpdate()}removeListeners(){
this.m_handlerMgr.RemoveClickEvent(this.btn_allIgnore,this._degf_OnAllIgnoreClick),this.m_handlerMgr.RemoveClickEvent(this.btn_allPass,this._degf_OnAllPassClick),
j.C.Inst_get().RemoveEventHandler(j.C.eRecommendListUpdate,this._degf_OnListUpdate)}OnListUpdate(t){this.grid.Clear(),this.grid.data_set(j.C.Inst_get().recomendList)
const e={}
e.show=0==j.C.Inst_get().recomendList.Count(),e.show&&(e.str=(0,l.T)("暂无好友申请")),j.C.Inst_get().RaiseEvent(j.C.eFriendViewNodata,e),this.scrollview.ResetPosition()}
closeHandler(t,e){bt.Inst_get().CloseFriendReqListView(),j.C.Inst_get().UpdateRecommendListChange()}OnItemRefreshFun(t){const e=new ht
return e.setId(t,null,0),e}Clear(){V.f.Inst.SetState(k.t.FRIEND_APPLICATION,!1),this.removeListeners(),this.grid.Clear(),super.Clear()}Destroy(){super.Destroy()}}
var Dt,Et,Tt,At,Lt,wt=i(5924)
class Rt extends Q.C{constructor(){super(),this.grid=null,this.closebtn=null,this.lab_friendNum=null,this.btn_add=null,this.btn_reqList=null,this.typeTab=null,this.lab_title=null,
this.scrollview=null,this.scrollbar=null,this._degf_OnAddClick=null,this._degf_OnBlackListUpdate=null,this._degf_OnItemRefreshFun=null,this._degf_OnReqListClick=null,
this._degf_OnTypeSelect=null,this._degf_closeHandler=null,this._degf_SetValue=null,this._degf_UpdateRedPoint=null,this.isExclusionPanel=null,
this._degf_OnAddClick=(t,e)=>this.OnAddClick(t,e),this._degf_OnBlackListUpdate=t=>this.OnBlackListUpdate(t),this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),
this._degf_OnReqListClick=(t,e)=>this.OnReqListClick(t,e),this._degf_OnTypeSelect=t=>this.OnTypeSelect(t),this._degf_closeHandler=(t,e)=>this.closeHandler(t,e),
this._degf_SetValue=()=>this.SetValue(),this._degf_UpdateRedPoint=(t,e)=>this.UpdateRedPoint(t,e)}InitView(){super.InitView(),this.isExclusionPanel=!0,
this.scrollview=this.CreateComponent(J.h,1),this.grid=this.CreateComponent($.A,2),this.lab_friendNum=this.CreateComponent(nt.Q,3),
this.grid.SetInitInfo("ui_ryfriend_addItem",this.CreateDelegate(this.OnItemRefreshFun))}SetSelect(t){this.node.SetActive(t),t?this.addListeners():this.Clear()}addListeners(){
j.C.Inst_get().AddEventHandler(j.C.eFriendListUpdate,this.CreateDelegate(this.OnFriendListUpdate)),
j.C.Inst_get().AddEventHandler(j.C.eFriendAdd,this.CreateDelegate(this.OnFriendListUpdate)),
j.C.Inst_get().AddEventHandler(j.C.eFriendRemove,this.CreateDelegate(this.OnFriendListUpdate)),bt.Inst_get().ReqGetFriendList(),
V.f.Inst.AddCallback(k.t.FRIEND_APPLICATION,this._degf_UpdateRedPoint)}removeListeners(){
j.C.Inst_get().RemoveEventHandler(j.C.eFriendListUpdate,this.CreateDelegate(this.OnFriendListUpdate)),
j.C.Inst_get().RemoveEventHandler(j.C.eFriendAdd,this.CreateDelegate(this.OnFriendListUpdate)),
j.C.Inst_get().RemoveEventHandler(j.C.eFriendRemove,this.CreateDelegate(this.OnFriendListUpdate)),V.f.Inst.RemoveCallback(k.t.FRIEND_APPLICATION,this._degf_UpdateRedPoint)}
UpdateRedPoint(t,e){}OnFriendListUpdate(t){const e=j.C.Inst_get().friendList,i=new S.Z
let s=0
for(;s<e.Count();){const t=e[s]
i.Add(new tt.O(v.u.FriendList,t)),s+=1}this.grid.data_set(i),this.lab_friendNum.textSet(`${(0,l.T)("好友人数：[047104]")}${i.Count()}[-]/${j.C.FriendNumMax}`),
wt.C.Inst_get().SetInterval(this._degf_SetValue,200,1)
const n={}
n.show=0==j.C.Inst_get().friendList.Count(),n.show&&(n.str=(0,l.T)("暂无好友")),j.C.Inst_get().RaiseEvent(j.C.eFriendViewNodata,n)}SetValue(){}OnAddClick(t,e){
bt.Inst_get().OpenFriendAddView()}OnReqListClick(t,e){bt.Inst_get().OpenFriendReqListView()}closeHandler(t,e){bt.Inst_get().CloseFriendView()}OnItemRefreshFun(t){const e=new ht
return e.setId(t,null,0),e}OnTypeSelect(t){}Clear(){this.removeListeners(),q.Y.Inst().Close(),bt.Inst_get().CloseFriendAddView(),bt.Inst_get().CloseFriendReqListView(),
this.grid.Clear(),super.Clear()}Destroy(){super.Destroy()}}class Ot extends pt.f{constructor(...t){super(...t),this.closebtn=null,this.rightTabGrid=null,this.friendaddview=null,
this.friendlistview=null,this.friendreqlistview=null,this.friendblackview=null,this.nodata=null,this.nodatalabel=null,this.tabs=null,this.model=null,this.selectTabIdx1=null}
InitView(){super.InitView(),this.closebtn=this.CreateComponent(W.W,1),this.rightTabGrid=this.CreateComponent($.A,2),this.friendaddview=this.CreateComponentBinder(gt,3),
this.friendlistview=this.CreateComponentBinder(Rt,4),this.friendreqlistview=this.CreateComponentBinder(vt,5),this.friendblackview=this.CreateComponentBinder(yt,6),
this.nodata=this.CreateComponent(Y.z,7),this.nodatalabel=this.CreateComponent(nt.Q,8),this.tabs=new ft.X,this.tabs.LuaDic_Add(0,this.friendlistview),
this.tabs.LuaDic_Add(1,this.friendaddview),this.tabs.LuaDic_Add(2,this.friendreqlistview),this.tabs.LuaDic_Add(3,this.friendblackview),this.rightTabGrid.node.SetActive(!0),
null==this.rightTabGrid.m_onReposition&&(this.rightTabGrid.SetInitInfo("ui_ry_right_tab2",null,St.l,this.CreateDelegate(this._OnClickRightItem)),
this.rightTabGrid.OnReposition_set(this.CreateDelegate(this.OnRepositionRight)))
const t=Ct.k.NewToList(new S.Z([(0,l.T)("好友"),(0,l.T)("添加好友"),(0,l.T)("好友申请"),(0,l.T)("黑名单")]),new S.Z([0,0,k.t.FRIEND_APPLICATION]),null,null)
this.rightTabGrid.data_set(t)}Clear(){this.model.RemoveEventHandler(j.C.eFriendViewNodata,this.CreateDelegate(this.ShowNodataHandler)),this.friendaddview.Clear(),
this.friendlistview.Clear(),this.friendreqlistview.Clear(),this.friendblackview.Clear(),super.Clear()}Destroy(){this.friendaddview.Destroy(),this.friendlistview.Destroy(),
this.friendreqlistview.Destroy(),this.friendblackview.Destroy(),super.Destroy(),this.closebtn=null,this.rightTabGrid=null,this.friendaddview=null,this.friendlistview=null,
this.friendreqlistview=null,this.friendblackview=null,this.nodata=null,this.nodatalabel=null}OnAddToScene(){super.OnAddToScene(),this.model=j.C.Inst_get(),
this.model.AddEventHandler(j.C.eFriendViewNodata,this.CreateDelegate(this.ShowNodataHandler)),
this.m_handlerMgr.AddClickEvent(this.closebtn,this.CreateDelegate(this.ClosebtnClick)),this.nodata.SetActive(!1)
let t=0
this.model.useDefaultTab||(t=this.model.curSelectTab),this.selectTabIdx1=t,this.SelectTab1(this.selectTabIdx1)}ClosebtnClick(){bt.Inst_get().CloseFriendPanel()}
ShowNodataHandler(t){this.nodata&&(this.nodata.SetActive(t.show),t.show&&null!=t.str&&this.nodatalabel.textSet(t.str))}OnRepositionRight(){this.TabbtnSelected()}TabbtnSelected(){
const t=this.rightTabGrid.itemList.Count()
for(let e=0;e<=t-1;e++){const t=this.rightTabGrid.itemList[e]
e!=this.selectTabIdx1?t.SetSelect(!1):t.SetSelect(!0)}}_UpdateTableSelect1(){this.TabbtnSelected()
const t=this.tabs.LuaDic_Count()
for(let e=0;e<=t-1;e++){const t=this.tabs[e]
e!=this.selectTabIdx1?t.SetSelect(!1):t.SetSelect(!0)}}_OnClickRightItem(t,e,i){const s=this.rightTabGrid.itemList.IndexOf(t)
this.SelectTab1(s,!0)}SelectTab1(t){this.selectTabIdx1=t,this._UpdateTableSelect1()}Test1(){return!0}S_Test(){return!0}}function Gt(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let bt=(Dt=(0,n.GH)(Z.k.SM_GetFriendList),Et=(0,n.GH)(Z.k.SM_GetFriendVo),Tt=(0,n.GH)(Z.k.SM_SearchFriend),
Lt=class t{constructor(){this.lastSearchName=null,this.page=0,this.searchList=null,this.m_isForChatSearch=!1,this.friendView=null,this.friendAddView=null,this.friendSearchType=0,
this.friendReqListView=null,this._degf_BlackFriendConfirmOK=null,this._degf_CallDestoryFriendAddView=null,this._degf_CallDestoryFriendReqListView=null,
this._degf_CallDestoryFriendView=null,this._degf_GetBlackListHandler=null,this._degf_OnGetFriendVoHandler=null,this._degf_RecommendAggreOrRefuseHandler=null,
this._degf_RecommendListHandler=null,this._degf_ReportConfirmOK=null,this._degf_SM_AddFriendHandler=null,this._degf_SM_AddRecommendHandler=null,
this._degf_SM_BlackFriendHandler=null,this._degf_SM_FriendListHandler=null,this._degf_SM_RemoveFriendHandler=null,this._degf_SM_SearchFriendHandler=null,
this._degf_SM_UpdateFriendHandler=null,this._degf_ShowFriendAddViewHandler=null,this._degf_ShowFriendReqListViewHandler=null,this._degf_ShowFriendViewHandler=null,
this._degf_UnBlackHandler=null,this._degf_OnDelFriendVoHandler=null,this._degf_SM_AddFriendCallbackHandler=null,this.friendPanel=null,this.searchList=new S.Z,
this._degf_BlackFriendConfirmOK=t=>this.BlackFriendConfirmOK(t),this._degf_CallDestoryFriendAddView=()=>this.CallDestoryFriendAddView(),
this._degf_CallDestoryFriendReqListView=()=>this.CallDestoryFriendReqListView(),this._degf_CallDestoryFriendView=()=>this.CallDestoryFriendView(),
this._degf_GetBlackListHandler=t=>this.GetBlackListHandler(t),this._degf_OnGetFriendVoHandler=t=>this.OnGetFriendVoHandler(t),
this._degf_RecommendAggreOrRefuseHandler=t=>this.RecommendAggreOrRefuseHandler(t),this._degf_RecommendListHandler=t=>this.RecommendListHandler(t),
this._degf_ReportConfirmOK=t=>this.ReportConfirmOK(t),this._degf_SM_AddFriendHandler=t=>this.SM_AddFriendHandler(t),
this._degf_SM_AddRecommendHandler=t=>this.SM_AddRecommendHandler(t),this._degf_SM_BlackFriendHandler=t=>this.SM_BlackFriendHandler(t),
this._degf_SM_FriendListHandler=t=>this.SM_FriendListHandler(t),this._degf_SM_RemoveFriendHandler=t=>this.SM_RemoveFriendHandler(t),
this._degf_SM_SearchFriendHandler=t=>this.SM_SearchFriendHandler(t),this._degf_SM_UpdateFriendHandler=t=>this.SM_UpdateFriendHandler(t),
this._degf_ShowFriendAddViewHandler=t=>this.ShowFriendAddViewHandler(t),this._degf_ShowFriendReqListViewHandler=t=>this.ShowFriendReqListViewHandler(t),
this._degf_ShowFriendViewHandler=t=>this.ShowFriendViewHandler(t),this._degf_UnBlackHandler=t=>this.UnBlackHandler(t),
this._degf_OnDelFriendVoHandler=t=>this.OnDelFriendVoHandler(t),this._degf_SM_AddFriendCallbackHandler=t=>this.SM_AddFriendCallbackHandler(t)}static Inst_get(){
return null==t.inst&&(t.inst=new t,t.inst.registeProtocol()),t.inst}registeProtocol(){}ReqReport(t){const e="SOCIAL:REPORT_CONFIRM"
if(U.V.Inst_get().GetData(U.V.Inst_get().GetRolePrefix()+e))this.ReportConfirmOK(t)
else{E.L.Inst().getItemById(e)
const i=new T.B
i.infoId=e,i.confirmHandle=this._degf_ReportConfirmOK,i.confirmParam=t,i.layer=m.F.Tip,D.t.Inst().Open(i)}}OpenFriendPanel(t=null){null==t&&(t=!1)
const e=new u.v
e.layerType=m.F.Tip,e.isShowMask=!0,_.N.inst.OpenById(I.I.RYFriendPanel,this.CreateDelegate(this.ShowFriendPanelHandler),this.CreateDelegate(this.CallDestoryFriendPanel),e)}
ShowFriendPanelHandler(t){return null==this.friendPanel&&(this.friendPanel=new Ot(null),this.friendPanel.setId(t,null,0)),this.friendPanel}CallDestoryFriendPanel(){
c.g.DestroyUIObj(this.friendPanel),this.friendPanel=null}CloseFriendPanel(){null!=this.friendPanel&&_.N.inst.ClosePanel(this.friendPanel)}ReportConfirmOK(t){}OpenOperationPanel(t){
const e=t.m_vo,i=new o.H
i.Id_set(e.playerId),i.Name_set(e.name),i.Job_set(e.job),i.Sex_set(e.sex),i.Level_set(e.level),i.AllianceName_set(e.asuramName),i.AsuramId_set(e.asuramId),
i.VipLevel_set(e.vipLevel),i.teamId_set(e.teamId),i.BattleScore_set(e.power.ToNum()),i.Server_set(a.Y.Inst.PrimaryRoleInfo_get().Server_get()),i.asuramFlag=e.flagInfo
const s=A.Q.Inst().GetObjectByName("Role",r.u)
s.Roleinfo_set(i),H.X.Inst().isOnline=0==e.offlineTime.ToNum(),H.X.Inst().TargetRole_set(s),
t.m_type==v.u.FriendList||t.m_type==v.u.BlackList?H.X.Inst().openPos=new f.F(0,0).Clone():H.X.Inst().openPos=new f.F(-347,0).Clone(),q.Y.Inst().OpenOperationPanel(1)}
ReqGetFriendList(){const t=new O.$
d.C.Inst.F_SendMsg(t)}SM_FriendListHandler(t){const e=t
j.C.Inst_get().UpdateFriendList(e.friendVos,null)}ResetSearchFriend(){this.searchList.Clear(),this.page=1,this.lastSearchName=""}ReqSearchFriendByID(t,e){const i=new G._
i.playerId=t,d.C.Inst.F_SendMsg(i),this.m_isForChatSearch=e}OnGetFriendVoHandler(e){const i=e
null!=i.friendVo&&t.Inst_get().m_isForChatSearch&&(t.Inst_get().m_isForChatSearch=!1,y.d.Inst_get().model.privateModel.UpdateOnLineInfo(i.friendVo))}SearchFriend(t){
this.lastSearchName!=t&&(this.page=1,this.searchList.Clear(),this.lastSearchName=t)
const e=new B.K
e.searchInfo=t,e.page=this.page,e.pageSize=10,d.C.Inst.F_SendMsg(e)}SearchFriendNexPage(){this.page+=1
const t=new B.K
t.searchInfo=this.lastSearchName,t.page=this.page,t.pageSize=10,d.C.Inst.F_SendMsg(t)}SM_SearchFriendHandler(t){const e=t
if(e.page==this.page){const t=e.vos.Count()
let i=0
for(;i<t;){const t=e.vos[i]
null!=t&&this.searchList.Add(t),i+=1}}j.C.Inst_get().RaiseEvent(j.C.eFriendSearchList,this.searchList)}ReqAddFriend(t){const e=new L.v
e.playerId=t,d.C.Inst.F_SendMsg(e)}SM_AddFriendCallbackHandler(t){t.isSuccess&&(F.y.inst.ClientStrMsg(N.r.SystemTipMessage,"申请成功，请等待对方同意"),
j.C.inst.RaiseEvent(j.C.eFriendAddCallback,t.playerId))}SM_AddFriendHandler(t){const e=t
if(null==e.friendVos||0==e.friendVos.Count())return
const i=e.friendVos.Count()-1
let s=0
for(;s<i;)j.C.Inst_get().AddFriend(e.friendVos[s],!1),s+=1
j.C.Inst_get().AddFriend(e.friendVos[i],!0),a.Y.Inst.SetAllOtherRoleShowByPhoto(null)}ReqRemoveFriend(t){const e=new P.s
e.playerId=t,d.C.Inst.F_SendMsg(e)}SM_RemoveFriendHandler(t){const e=t
j.C.Inst_get().RemoveFriend(e.playerId,null),a.Y.Inst.SetAllOtherRoleShowByPhoto(null)}ReqBlackFriend(t){const e="SOCIAL:BLACKLIST_CONFIRM"
if(U.V.Inst_get().GetData(U.V.Inst_get().GetRolePrefix()+e))this.BlackFriendConfirmOK(t.Id_get())
else{E.L.Inst().getItemById(e)
const i=new T.B
i.infoId=e,i.layer=m.F.Tip,i.isShowMask=!0,i.replaceParams.Add(t.Name_get()),i.confirmHandle=this._degf_BlackFriendConfirmOK
let s=t.mainroleId_get()
g.o.IsNullOrZero(s)&&(s=t.Id_get()),i.confirmParam=s,D.t.Inst().Open(i)}}BlackFriendConfirmOK(t){const e=t,i=new w.N
i.playerId=e,d.C.Inst.F_SendMsg(i),q.Y.Inst().Close()}SM_BlackFriendHandler(t){const e=t
j.C.Inst_get().BlackFriend(e.friendVo,null),F.y.inst.ClientStrMsg(N.r.SystemTipMessage,"加入黑名单成功")}ReqUnBlack(t){const e=new x.l
e.playerId=t,d.C.Inst.F_SendMsg(e)}UnBlackHandler(t){const e=t
j.C.Inst_get().UnBlackFriend(e.playerId,null)}OnDelFriendVoHandler(t){if(j.C.inst.RemoveFriend(t.playerId,!0),q.Y.Inst().IsOpen()){q.Y.Inst().TargetPanel_get().SetMenu()}}
ReqGetBlackList(){const t=new R.W
d.C.Inst.F_SendMsg(t)}GetBlackListHandler(t){const e=t
j.C.Inst_get().UpdateBlackList(e.vos,null)}ReqGetRecommendList(){const t=new b.f
d.C.Inst.F_SendMsg(t)}RecommendListHandler(t){const e=t
j.C.Inst_get().UpdateRecomendFriendList(e.vos),e.vos.Count()>0?V.f.Inst.SetState(k.t.FRIEND_APPLICATION,!0):V.f.Inst.SetState(k.t.FRIEND_APPLICATION,!1)}SM_AddRecommendHandler(t){
const e=t
j.C.Inst_get().AddRecomendFriend(e.friendVo),V.f.Inst.SetState(k.t.FRIEND_APPLICATION,!0)}SM_UpdateFriendHandler(t){const e=t
j.C.Inst_get().RaiseEvent(j.C.eFriendUpdate,e.friendVo)}ReqRecommendResult(t,e){const i=new M._
i.isOnekey=!1,i.isAggre=e,i.playerId=t,d.C.Inst.F_SendMsg(i)}ReqOneKeyRecommend(t){const e=new M._
e.isOnekey=!0,e.isAggre=t,e.playerId=g.o.ZERO,d.C.Inst.F_SendMsg(e)}RecommendAggreOrRefuseHandler(t){const e=t
j.C.Inst_get().RecommendAggreOrRefuse(e.playerIds)}OpenReqNoticeFriend(){j.C.Inst_get().curSelectTab=j.C.ReqFriendList,j.C.Inst_get().skipHandleFriendIcon=!0,this.OpenFriendPanel()
}OpenFriendView(){_.N.inst.OpenById(I.I.eFriendView,this._degf_ShowFriendViewHandler,this._degf_CallDestoryFriendView)}ShowFriendViewHandler(t){
return null==this.friendView&&(this.friendView=new Rt,this.friendView.setId(t,null,0)),this.friendView}CallDestoryFriendView(){c.g.DestroyUIObj(this.friendView),
this.friendView=null}CloseFriendView(){null!=this.friendView&&_.N.inst.ClosePanel(this.friendView)}OpenFriendAddView(t){const e=new u.v
null==t&&(t=0),this.friendSearchType=t,1==t&&(e.layerType=m.F.Tip),_.N.inst.OpenById(I.I.eFriendAddView,this._degf_ShowFriendAddViewHandler,this._degf_CallDestoryFriendAddView,e)}
ShowFriendAddViewHandler(t){return null==this.friendAddView&&(this.friendAddView=new gt,this.friendAddView.setId(t,null,0)),this.friendAddView}CallDestoryFriendAddView(){
c.g.DestroyUIObj(this.friendAddView),this.friendAddView=null}CloseFriendAddView(){null!=this.friendAddView&&_.N.inst.ClosePanel(this.friendAddView)}OpenFriendReqListView(){
const t=new u.v
_.N.inst.OpenById(I.I.eFriendReqListView,this._degf_ShowFriendReqListViewHandler,this._degf_CallDestoryFriendReqListView,t)}ShowFriendReqListViewHandler(t){
return null==this.friendReqListView&&(this.friendReqListView=new vt,this.friendReqListView.setId(t,null,0)),this.friendReqListView}CallDestoryFriendReqListView(){
c.g.DestroyUIObj(this.friendReqListView),this.friendReqListView=null}CloseFriendReqListView(){null!=this.friendReqListView&&_.N.inst.ClosePanel(this.friendReqListView)}
GetOffsetTimeStr(t){let e="",i=h.D.serverMSTime_get()-t
const s=p.GF.INT(i/864e5)
if(s>=30)e=(0,l.T)("一个月前离线")
else if(s>=7){const t=Math.floor(s/7)
e=C.M.Replace((0,l.T)("{0}周前离线"),"{0}",""+t)}else if(s>=1)e=C.M.Replace((0,l.T)("{0}天前离线"),"{0}",""+s)
else{i%=864e5
const t=Math.floor(i/36e5)
if(t>=1)e=C.M.Replace((0,l.T)("{0}小时前离线"),"{0}",""+t)
else if(t>.5)e=(0,l.T)("半小时离线")
else{i%=36e5
const t=Math.floor(i/6e4)
e=t>=1?C.M.Replace((0,l.T)("{0}分钟前离线"),"{0}",""+t):(0,l.T)("刚刚离线")}}return e}},Lt.inst=null,Gt(At=Lt,"Inst_get",[s.n],Object.getOwnPropertyDescriptor(At,"Inst_get"),At),
Gt(At.prototype,"SM_FriendListHandler",[Dt],Object.getOwnPropertyDescriptor(At.prototype,"SM_FriendListHandler"),At.prototype),
Gt(At.prototype,"OnGetFriendVoHandler",[Et],Object.getOwnPropertyDescriptor(At.prototype,"OnGetFriendVoHandler"),At.prototype),
Gt(At.prototype,"SM_SearchFriendHandler",[Tt],Object.getOwnPropertyDescriptor(At.prototype,"SM_SearchFriendHandler"),At.prototype),At)},50077:(t,e,i)=>{i.d(e,{C:()=>S})
var s=i(38836),n=i(86133),l=i(68662),a=i(54967),o=i(66788),r=i(98130),h=i(98885),d=i(85602),u=i(38962),c=i(82803),_=i(19983),I=i(49892),m=i(75961),g=i(14792),p=i(62734),C=i(24315)
class S extends a.g{constructor(){super(),this.friendList=null,this.friendListDic=null,this.blackList=null,this.blackListDic=null,this.recomendList=null,this.itv=null,
this.barValue=0,this.barSize=0,this._degf_SortFriendListFunc=null,this.curSelectTab=0,this.skipHandleFriendIcon=!1,this.friendList=new d.Z,this.friendListDic=new u.X,
this.blackList=new d.Z,this.blackListDic=new u.X,this.recomendList=new d.Z,this._degf_SortFriendListFunc=(t,e)=>this.SortFriendListFunc(t,e)}static Inst_get(){
return null==S.inst&&(S.inst=new S),S.inst}IsFriend(t){return this.friendListDic.LuaDic_ContainsKey(t.ToString())}IsBlackFriend(t){
return this.blackListDic.LuaDic_ContainsKey(t.ToString())}AddRecomendFriend(t){let e=0
const i=this.recomendList.Count()
for(;e<i;){if(this.recomendList[e].m_vo.playerId.Equal(t.playerId))return
e+=1}this.recomendList.Insert(0,new C.O(c.u.ReqList,t)),this.UpdateRecommendListChange()}UpdateRecomendFriendList(t){if(this.recomendList.Clear(),null!=t){let e=0
for(;e<t.Count();)this.recomendList.Add(new C.O(c.u.ReqList,t[e])),e+=1}this.UpdateRecommendListChange()}RecommendAggreOrRefuse(t){const e=t
let i=this.recomendList.Count()-1
for(;i>-1;){const t=this.recomendList[i]
let s=e.Count()-1
for(;s>-1;)t.m_vo.playerId.Equal(e[s])&&(e.RemoveAt(s),this.recomendList.RemoveAt(i)),s-=1
i-=1}i<=0&&p.f.Inst.SetState(g.t.FRIEND_APPLICATION,!1),S.Inst_get().RaiseEvent(S.eRecommendListUpdate)}UpdateRecommendListChange(){this.RaiseEvent(S.eRecommendListUpdate),
o.Y.Log((0,n.T)("好友推送：")+this.recomendList.Count()),this.skipHandleFriendIcon||(this.recomendList.Count()>0?this.AddNoticeIcon():this.RemoveNoticeIcon()),
this.skipHandleFriendIcon=!1}RemoveNoticeIcon(){_.S.Inst_get().RemoveIcon(I.K.ICON_TIPS_FRIEND_RECOMMEND),this.itv=null}AddNoticeIcon(){
null==this.itv&&(this.itv=new m.U(I.K.ICON_TIPS_FRIEND_RECOMMEND),_.S.Inst_get().AddIcon(this.itv)),
_.S.Inst_get().UpdateCount(I.K.ICON_TIPS_FRIEND_RECOMMEND,this.recomendList.Count())}AddFriend(t,e){null==e&&(e=!0),
this.friendListDic.LuaDic_ContainsKey(t.playerId.ToString())||(0==t.offlineTime.ToNum()?this.friendList.Insert(0,t):this.friendList.Add(t),
this.friendListDic.LuaDic_AddOrSetItem(t.playerId.ToString(),t),e&&(this.friendList.Sort(this._degf_SortFriendListFunc),this.RaiseEvent(S.eFriendAdd,t)))}UpdateFriendList(t,e){
null==e&&(e=!0),this.friendList=t,this.friendList.Sort(this._degf_SortFriendListFunc),this.friendListDic.LuaDic_Clear()
for(const[e,i]of(0,s.V5)(t))this.friendListDic.LuaDic_AddOrSetItem(i.playerId.ToString(),i)
e&&this.RaiseEvent(S.eFriendListUpdate)}SortFriendListFunc(t,e){
const i=0==t.offlineTime.low_get()&&0==t.offlineTime.high_get(),s=0==e.offlineTime.low_get()&&0==e.offlineTime.high_get()
return i&&s?h.M.Compare(t.name,e.name):i||s?i?-1:s?1:0:r.GF.INT(e.offlineTime.ToNum()-t.offlineTime.ToNum())}RemoveFriend(t,e){if(null==e&&(e=!0),null==this.friendList)return
let i=this.friendList.Count()-1
for(;i>-1;){if(this.friendList[i].playerId.Equal(t)){this.friendList.RemoveAt(i)
break}i-=1}this.friendListDic.LuaDic_Remove(t.ToString()),e&&this.RaiseEvent(S.eFriendRemove,t)}UpdateBlackList(t,e){null==e&&(e=!0),this.blackList=t,
this.blackListDic.LuaDic_Clear()
for(const[e,i]of(0,s.V5)(t))this.blackListDic.LuaDic_AddOrSetItem(i.playerId.ToString(),i)
e&&this.RaiseEvent(S.eBlackListUpdate)}BlackFriend(t,e){null==e&&(e=!0),this.blackList.Insert(0,t),this.blackListDic.LuaDic_AddOrSetItem(t.playerId.ToString(),t),
e&&this.RaiseEvent(S.eBlackFriend,t)}UnBlackFriend(t,e){null==e&&(e=!0)
let i=this.blackList.Count()-1
for(;i>-1;){if(this.blackList[i].playerId.Equal(t)){this.blackList.RemoveAt(i)
break}i-=1}this.blackListDic.LuaDic_Remove(t.ToString()),e&&this.RaiseEvent(S.eUnBlackFriend,t)}GetOnlineStatus(t){const e=t.ToNum()/1e3,i=l.D.serverTime_get()-r.GF.INT(e)
let s=(0,n.T)("[047104]在线[-]")
return 0==e||(s=i<60?(0,n.T)("刚刚 离线"):i<1800?Math.floor(i/60)+(0,n.T)("分钟前 离线"):i<3600?(0,n.T)("半小时前 离线"):i<86400?Math.floor(i/60/60)+(0,
n.T)("小时前 离线"):i<604800?Math.floor(i/60/60/24)+(0,n.T)("天前 离线"):i<2592e3?Math.floor(i/60/60/24/7)+(0,n.T)("周前 离线"):"一月前 离线"),s}ResetModel(){
S.Inst_get().UpdateRecomendFriendList(null),this.blackListDic.LuaDic_Clear(),this.blackList.Clear(),this.friendList.Clear(),this.friendListDic.LuaDic_Clear(),this.curSelectTab=0}
SetBarValue(t){this.barValue=t}GetBarValue(){return this.barValue}SetBarSize(t){this.barSize=t}GetBarSize(){return this.barSize}}S.FriendNumMax=50,S.BlackNumMax=50,
S.eFriendListUpdate="FriendListUpdate",S.eFriendSearchList="FriendSearchList",S.eFriendAdd="FriendAdd",S.eFriendRemove="FriendRemove",S.eBlackListUpdate="BlackListUpdate",
S.eBlackFriend="BlackListAdd",S.eUnBlackFriend="BlackListRemove",S.eRecommendListUpdate="eGetRecommendList",S.eRecommendAddFriend="eRecommendAddFriend",
S.eFriendUpdate="eFriendUpdate",S.eFriendAddCallback="eFriendAddCallback",S.eFriendViewNodata="eFriendViewNodata",S.FriendList=0,S.FriendAdd=1,S.ReqFriendList=2,S.BlackList=3,
S.inst=null},24315:(t,e,i)=>{i.d(e,{O:()=>s})
class s{constructor(t,e){this.m_vo=null,this.m_type=0,this.apply=!1,this.m_type=t,this.m_vo=e}}},76689:(t,e,i)=>{i.d(e,{r:()=>h})
var s=i(93984),n=i(38836),l=i(55360),a=i(85602),o=i(38962),r=i(77477)
class h{constructor(){this.fruitDict=null,this.fruitList=null,this.allAttrType=null,this.fruitDict=new o.X
const t=l.Y.Inst.GetOrCreateCsv(s.h.eFruitResource)
this.fruitDict=t.GetCsvMap(),this.allAttrType=new a.Z
for(const[t,e]of(0,n.V5)(this.fruitDict)){const t=e.fruitRewards.rewardList
if(null!=t&&0!=t.Count()){let e=0
for(;e<t.Count();){const i=t[e],s=r.Z.GetAttrKey(i.type);-1==this.allAttrType.IndexOf(s)&&this.allAttrType.Add(s),e+=1}}}}static Inst_get(){return null==h._inst&&(h._inst=new h),
h._inst}GetFruitList(){if(null==this.fruitList){this.fruitList=new a.Z
for(const[t,e]of(0,n.V5)(this.fruitDict))this.fruitList.Add(e)
this.fruitList.Sort(this.SortItem)}return this.fruitList}SortItem(t,e){return t.itemId-e.itemId}GetFruitCfg(t){for(const[e,i]of(0,n.V5)(this.fruitDict))if(i.itemId==t)return i
return null}}h._inst=null},93481:(t,e,i)=>{i.d(e,{u:()=>g})
var s=i(38836),n=i(3578),l=i(90419),a=i(50089),o=i(62370),r=i(98885),h=i(38962),d=i(40623),u=i(98130),c=i(85602)
class _{constructor(){this.type=null,this.value=0}}class I{constructor(){this.rewardList=null}FillData(t){this.rewardList=new c.Z
const e=new c.Z(t.rewardList)
let i=0
for(;i<e.Count();){const t=e[i],s=new _
s.type=u.GF.LuaJsonToString(t.type),s.value=u.GF.LuaJsonToNumber(t.value),this.rewardList.Add(s),i+=1}}}class m extends d.t{constructor(){super(),this.fruitRewards=null,
this.limitDict=null,this.reward=null,this.limit=null,this.fruitRewards=new I,this.limitDict=new h.X}Parse(){const t=l.d.parseJsonObjectWithFix(this.reward,"rewardList")
this.fruitRewards=a.t.decode(t,I)
let e=r.M.Replace(this.limit,"{","")
e=r.M.Replace(e,"}","")
const i=r.M.Split(e,r.M.s_Arr_SPAN_CHAR_DOT)
if(null!=i)for(const[t,e]of(0,s.V5)(i)){const t=r.M.Split(e,o.o.s_UNDER_CHAR)
if(null!=t&&2==t.count){const e=r.M.String2Int(t[0]),i=r.M.String2Int(t[1])
this.limitDict.LuaDic_AddOrSetItem(e,i)}}}}class g extends n.N{static CreateCSVEx(){return new g}getNewCSVItem(){return new m}_Load(){super._Load()
const t=this.GetCsvMap()
let e=null
for(const[i,n]of(0,s.vy)(t))e=t.LuaDic_GetItem(i),null!=e&&e.Parse()}IsSrcType(){return!1}}},6667:(t,e,i)=>{i.d(e,{h:()=>f})
var s,n,l,a,o=i(42292),r=i(71409),h=i(17409),d=i(38836),u=i(97461),c=i(56937),_=i(18202),I=i(5494),m=i(13195),g=i(92679),p=i(92415),C=i(59033)
function S(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let f=(s=(0,r.GH)(p.k.SM_FruitUseInfo),n=(0,r.GH)(p.k.SM_FruitUseNumUpdate),a=class t extends m.W{constructor(){
super(),this.view=null,this._degf_CallComplete=null,this._degf_CallDestory=null,this._degf_SM_FruitUseInfoHandle=null,this._degf_SM_FruitUseNumUpdateHandle=null,
this._degf_CallDestory=()=>this.CallDestory(),this._degf_SM_FruitUseInfoHandle=t=>this.SM_FruitUseInfoHandle(t),
this._degf_SM_FruitUseNumUpdateHandle=t=>this.SM_FruitUseNumUpdateHandle(t)}static Inst(){return null==t.inst&&(t.inst=new t),t.inst}OpenView(t,e){if((0,
h.qJ)(I.I.FruitPanel))return
null==e&&(e=-1),C.t.Inst_get().selectPlayerIdx=e,C.t.Inst_get().selectFruitId=t
const i=new c.v
i.isShowMask=!0,(0,h.Yp)(I.I.FruitPanel,i)}CallDestory(){_.g.DestroyUIObj(this.view),this.view=null}CloseView(){(0,h.qJ)(I.I.FruitPanel)&&(0,h.sR)(I.I.FruitPanel)}
SM_FruitUseInfoHandle(t){for(const[e,i]of(0,d.V5)(t.infos))C.t.Inst_get().playerFruitVos.LuaDic_AddOrSetItem(e,i)
u.i.Inst.RaiseEvent(g.g.UPDATE_FRUIT_PANEL)}SM_FruitUseNumUpdateHandle(t){C.t.Inst_get().playerFruitVos.LuaDic_AddOrSetItem(t.playerId.ToString(),t.vo),
u.i.Inst.RaiseEvent(g.g.UPDATE_FRUIT_PANEL)}},a.inst=null,S(l=a,"Inst",[o.Vx],Object.getOwnPropertyDescriptor(l,"Inst"),l),
S(l.prototype,"SM_FruitUseInfoHandle",[s],Object.getOwnPropertyDescriptor(l.prototype,"SM_FruitUseInfoHandle"),l.prototype),
S(l.prototype,"SM_FruitUseNumUpdateHandle",[n],Object.getOwnPropertyDescriptor(l.prototype,"SM_FruitUseNumUpdateHandle"),l.prototype),l)},59033:(t,e,i)=>{i.d(e,{t:()=>_})
var s=i(38836),n=i(98800),l=i(38962),a=i(70850),o=i(77477),r=i(37648),h=i(55492),d=i(14792),u=i(62734),c=i(76689)
class _{constructor(){this.selectFruitId=0,this.selectPlayerIdx=-1,this.selectPlayerInfo=null,this.playerFruitVos=null,this.IsOpened=!1,
this.selectPlayerInfo=n.Y.Inst.PrimaryRoleInfo_get(),this.playerFruitVos=new l.X}static Inst_get(){return null==_._inst&&(_._inst=new _),_._inst}ResetData(){
this.playerFruitVos.LuaDic_Clear(),this.selectFruitId=0,this.selectPlayerIdx=-1}GetUseNum(t,e){let i=0
const s=this.playerFruitVos.LuaDic_GetItem(e.ToString())
return null!=s&&(i=s.fruitUses.LuaDic_GetItem(t),null==i&&(i=0)),i}GetRemainUseNum(t,e){const i=this.GetUseNum(t,e.m_id)
return this.GetUseLimit(t,e.Level_get())-i}GetAttrNum(t,e){let i=0
const s=this.playerFruitVos.LuaDic_GetItem(e.ToString())
return null!=s&&(i=s.allAttrs.LuaDic_GetItem(t)),i}GetInfo(t){return this.playerFruitVos.LuaDic_GetItem(t.ToString())}GetUseLimit(t,e){let i=null,n=0
const l=c.r.Inst_get().GetFruitCfg(t)
if(null!=l){for(const[t,n]of(0,s.vy)(l.limitDict))e>=t&&(null==i&&(i=t),t>=i&&(i=t))
i=i||0,l.limitDict.LuaDic_ContainsKey(i)&&(n=l.limitDict[i])}return n}GetNextUseLevel(t,e){let i=null
const n=c.r.Inst_get().GetFruitCfg(t)
for(const[t,l]of(0,s.vy)(n.limitDict))e<t&&(null==i&&(i=t),t<=i&&(i=t))
return i=i||0,i}GetCfgAttrNum(t,e){let i=0
const s=c.r.Inst_get().GetFruitCfg(t)
if(null!=s){const t=s.fruitRewards.rewardList
if(null!=t&&0!=t.Count()){let s=0
for(;s<t.Count();){const n=t[s]
if(o.Z.GetAttrKey(n.type)==e){i=n.value
break}s+=1}}}return i}IsOpened_set(t){this.IsOpened=t,this.CheckRed()}CheckRedPlayer(t,e){let i=!1
const s=a.g.Inst_get().getItemresource(t).level
if(e.Level_get()<s)return i
if(r.P.Inst_get().IsFunctionOpened(h.x.FRUIT)&&a.g.Inst_get().GetItemNum(t)>0){i=this.GetUseNum(t,e.Id_get())<this.GetUseLimit(t,e.Level_get())}return i}CheckRed(){
for(const[t,e]of(0,s.V5)(n.Y.Inst.primaryRoleInfoList)){let t=!1
for(const[i,n]of(0,s.V5)(c.r.Inst_get().fruitDict))if(this.CheckRedPlayer(n.itemId,e)){t=!0
break}if(u.f.Inst.SetState(d.t.ADD_FRUIT,t,e.createIdx),t)return!0}return!1}}_._inst=null},14435:(t,e,i)=>{i.d(e,{Z:()=>S})
var s,n=i(18998),l=i(83908),a=i(86133),o=i(97461),r=i(5924),h=i(60130),d=i(98885),u=i(70850),c=i(63076),_=i(92679),I=i(87923),m=i(33138),g=i(41864),p=i(59033)
const{ccclass:C}=n._decorator
let S=C("FruitItem")(s=class extends((0,l.yk)()){constructor(...t){super(...t),this.data=null,this._degf_OnSelect=null,this._degf_SetGray=null}_initBinder(){super._initBinder(),
this._degf_OnSelect=(t,e)=>this.OnSelect(t,e)}InitView(){this._degf_SetGray=()=>{this.SetGray()}}SetData(t){this.node.on(n.NodeEventType.TOUCH_END,this._degf_OnSelect),this.data=t,
this.UpdateView()}OnSelect(t,e){p.t.Inst_get().selectFruitId!=this.data.itemId&&(p.t.Inst_get().selectFruitId=this.data.itemId,o.i.Inst.RaiseEvent(_.g.FRUIT_PANEL_SELECT))}
UpdateView(){this.UpdateSelect()
const t=new c.M(this.data.itemId,null)
t.showNum=!0,t.isShowZeroNum=!0,t.count=u.g.Inst_get().GetItemNum(this.data.itemId),this.baseItem.SetData(t)
const e=m.f.Inst().getItemById(this.data.itemId)
if(this.name.textSet(e.name),p.t.Inst_get().selectPlayerInfo.Level_get()>=this.data.unlock)this.unlockLabel.textSet(""),this.unLockIcon.SetActive(!1),h.O.makeGoGray(this.node,!1)
else{const t=d.M.Replace((0,a.T)("{0}解锁"),"{0}",g.h.GetLevelStr(this.data.unlock))
this.unlockLabel.textSet(t),this.unLockIcon.SetActive(!0),r.C.Inst_get().SetFrameLoop(this._degf_SetGray,1,1)}this.name.SetColor(I.l.getColorByQuality(t.Quality_get())),
this.UpdateRedPoint()}SetGray(){h.O.makeGoGray(this.node,!0)}UpdateSelect(){const t=p.t.Inst_get().selectFruitId==this.data.itemId
this.selectBg.SetActive(t)}UpdateRedPoint(){this.redPoint.SetActive(p.t.Inst_get().CheckRedPlayer(this.data.itemId,p.t.Inst_get().selectPlayerInfo))}Destroy(){super.destroy()}
Clear(){this.data=null,this.node.off(n.NodeEventType.TOUCH_END,this._degf_OnSelect)}})||s},36091:(t,e,i)=>{
var s,n=i(6847),l=i(83908),a=i(49655),o=i(46282),r=i(40053),h=i(38836),d=i(86133),u=i(11210),c=i(98800),_=i(5924),I=i(85682),m=i(18202),g=i(5494),p=i(83540),C=i(28192),S=i(98885),f=i(85602),y=i(38962),v=i(83543),D=i(21554),E=i(70850),T=i(63076),A=i(92679),L=i(77477),w=i(85751),R=i(87923),O=i(44498),G=i(33138),b=i(47786),M=i(22662),P=i(68637),B=i(41864),x=i(14792),N=i(65550),k=i(76689),V=i(6667),F=i(59033),U=i(14435)
;(0,n.s_)(a.o.FruitPanel,o.Z.ui_fruit_panel).waitPrefab(r.Z.BaseItem_ry_basePrefabs).register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),this.attr_type_list=null,
this.select_info=null,this.animTimer=-1,this.rewardCount=0,this.barInterval=-1,this.Interval=null,this.animIndex=null,this._m_handlerMgr=null}static __StaticInit(){}
get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=C.h.Get()),this._m_handlerMgr}_initBinder(){super._initBinder(),this.attr_type_list=new f.Z}InitView(){
super.InitView(),this.list_fruit.SetInitInfo("ui_fruit_item",this.CreateDelegate(this.OnInitList)),this.list_fruit.OnReposition_set(this.CreateDelegate(this.GridOnReposition))
for(let t=0;t<=4;t++)t>=k.r.Inst_get().allAttrType.Count()&&(this[`text_attr_name_${t}`].textSet(""),this[`text_attr_${t}`].textSet(""),this[`text_attr_add_${t}`].textSet(""))
this.select_info=c.Y.Inst.PrimaryRoleInfo_get()}RegUIShow(){INS.uIShowShortCut.RegUIShowDic(I.D.Fruit,g.I.FruitPanel)}UnRegUIShow(){INS.uIShowShortCut.UnRegUIShowDic(I.D.Fruit)}
OnAddToScene(){this.AddLis(),this.character_tab.SetData(g.I.FruitPanel),this.character_tab.onChanged=t=>{this.UpdatePanel()}
let t=-1
for(let e=0;e<=c.Y.Inst.primaryRoleInfoList.Count()-1;e++){const i=c.Y.Inst.primaryRoleInfoList[e]
if(0==F.t.Inst_get().selectFruitId){const s=k.r.Inst_get().GetFruitList()
for(let n=0;n<=s.Count()-1;n++){const l=s[n]
if(F.t.Inst_get().CheckRedPlayer(l.itemId,i)){t=e,F.t.Inst_get().selectFruitId=l.itemId
break}}}else if(F.t.Inst_get().CheckRedPlayer(F.t.Inst_get().selectFruitId,i)){t=e
break}if(-1!=t)break}F.t.Inst_get().selectPlayerIdx>-1&&(t=F.t.Inst_get().selectPlayerIdx),-1==t&&(t=0),this.character_tab.SetCurSelectIdx(t,!0,!0),
this.character_tab.SetRedPointId(x.t.ADD_FRUIT),this.UpdatePanel()}AddLis(){this.m_handlerMgr.AddPressEvent(this.btn_use,this.CreateDelegate(this.OnPressUse)),
this.m_handlerMgr.AddClickEvent(this.btn_close,this.CreateDelegate(this.OnClickClose)),this.m_handlerMgr.AddClickEvent(this.btn_use,this.CreateDelegate(this.OnClickUse)),
this.m_handlerMgr.AddEventMgr(A.g.BAG_UPDATE,this.CreateDelegate(this.UpdateItem)),this.m_handlerMgr.AddEventMgr(A.g.PLAYER_LEVELUP,this.CreateDelegate(this.UpdateList)),
this.m_handlerMgr.AddEventMgr(A.g.PLAYER_TRANSFER_JOB,this.CreateDelegate(this.UpdateAttr)),
this.m_handlerMgr.AddEventMgr(A.g.UPDATE_FRUIT_PANEL,this.CreateDelegate(this.UpdateFruitInfo)),
this.m_handlerMgr.AddEventMgr(A.g.FRUIT_PANEL_SELECT,this.CreateDelegate(this.UpdatePanel))}RemoveLis(){
this.m_handlerMgr.RemovePressEvent(this.btn_use,this.CreateDelegate(this.OnPressUse)),this.m_handlerMgr.RemoveClickEvent(this.btn_close,this.CreateDelegate(this.OnClickClose)),
this.m_handlerMgr.RemoveClickEvent(this.btn_use,this.CreateDelegate(this.OnClickUse)),this.m_handlerMgr.RemoveEventMgr(A.g.BAG_UPDATE,this.CreateDelegate(this.UpdateItem)),
this.m_handlerMgr.RemoveEventMgr(A.g.PLAYER_LEVELUP,this.CreateDelegate(this.UpdateList)),
this.m_handlerMgr.RemoveEventMgr(A.g.PLAYER_TRANSFER_JOB,this.CreateDelegate(this.UpdateAttr)),
this.m_handlerMgr.RemoveEventMgr(A.g.UPDATE_FRUIT_PANEL,this.CreateDelegate(this.UpdateFruitInfo)),
this.m_handlerMgr.RemoveEventMgr(A.g.FRUIT_PANEL_SELECT,this.CreateDelegate(this.UpdatePanel))}RegGuide(){P.c.Inst.RegGameObject(I.D.UI_FRUIT_USE_BTN,this.btn_use.node,null)}
UnRegGuide(){P.c.Inst.UnRegGameObject(I.D.UI_FRUIT_USE_BTN,null,null)}OnInitList(t){return t[0].getCNode(U.Z)}GridOnReposition(){
0!=F.t.Inst_get().selectFruitId&&(_.C.Inst_get().ClearInterval(this.barInterval),this.barInterval=_.C.Inst_get().SetFrameLoop(this.CreateDelegate(this.ScrollToTarget),1,1)),
this.scroll_bar.ResetPosition()}ScrollToTarget(){let t=1
const e=this.list_fruit.itemList.Count()
for(let i=0;i<=e-1;i++)if(this.list_fruit.itemList[i].data.itemId==F.t.Inst_get().selectFruitId){t=i+1
break}if(t>3){const i=(t-3)/(e-3)
this.scroll_bar.getComponent(v.D).value=i}}OnClickClose(t,e){V.h.Inst().CloseView()}OnClickUse(){this.TryUse(),this.ClearTimer(),R.l.CheckBtnClickTrigger(I.D.UI_FRUIT_USE_BTN)}
OnMultUse(){this.TryUse()||this.ClearTimer()}OnPressUse(t=!0){this.ClearTimer(),t&&(this.Interval=_.C.Inst_get().SetInterval(this.CreateDelegate(this.OnMultUse),150))}ClearTimer(){
-1!=this.Interval&&(_.C.Inst_get().ClearInterval(this.Interval),this.Interval=-1),-1!=this.animTimer&&(this.animTimer=_.C.Inst_get().ClearInterval(this.animTimer),
this.animTimer=-1)}TryUse(){if(null==this.select_info)return
const t=F.t.Inst_get().selectFruitId,e=G.f.Inst().getItemById(t),i=E.g.Inst_get().GetItemByModleID(t)
if(null==i){const t=S.M.Replace((0,d.T)("{0}不足"),"{0}",e.name)
return N.y.inst.ClientStrMsg(M.r.SystemTipMessage,t),!1}if(F.t.Inst_get().GetUseNum(t,this.select_info.Id_get())>=F.t.Inst_get().GetUseLimit(t,this.select_info.Level_get())){
const t=S.M.Replace((0,d.T)("{0}使用已达上限"),"{0}",e.name)
return N.y.inst.ClientStrMsg(M.r.SystemTipMessage,t),!1}const s=new y.X
return s.LuaDic_AddOrSetItem(this.select_info.Id_get().ToString(),1),D.J.Inst_get().SendUseItem(i.serverData_get().Id_get(),1,s),!0}UpdateFruitInfo(){this.UpdatePanel(),
this.PlayEffect()}UpdatePanel(){F.t.Inst_get().selectPlayerInfo=u.i.Inst.GetCurSelect(g.I.FruitPanel),this.select_info=F.t.Inst_get().selectPlayerInfo,this.UpdateList(),
this.UpdateAttr(),this.UpdateItem()}UpdateAttr(){const t=F.t.Inst_get().selectFruitId,e=k.r.Inst_get().GetFruitCfg(t).fruitRewards.rewardList
this.rewardCount=e.Count()
for(let i=0;i<=4;i++){const s=this[`text_attr_name_${i}`],n=this[`text_attr_${i}`],l=this[`text_attr_add_${i}`]
if(i<e.Count()){this[`prop${i}`].SetActive(!0)
const a=L.Z.GetAttrKey(e[i].type)
s.textSet(R.l.GetAttName(a)),n.textSet("")
const o=O.I.GetOkFormatAttrVal(e[i].type,F.t.Inst_get().GetUseNum(t,this.select_info.Id_get())*e[i].value)
l.textSet(`[CCCBC4]${o}[-] +${O.I.GetOkFormatAttrVal(e[i].type,F.t.Inst_get().GetCfgAttrNum(t,a))}`)}else this[`prop${i}`].SetActive(!1)}}UpdateItem(){
const t=F.t.Inst_get().selectFruitId,e=new T.M(t,null)
m.g.SetItemIcon(this.itemImg,e.cfgData_get().icon,p.b.eItem,!1)
const i=F.t.Inst_get().GetUseNum(t,this.select_info.Id_get()),s=F.t.Inst_get().GetUseLimit(t,this.select_info.Level_get())
let n=w.u.GreenColorStr
i>=s&&(n=w.u.RedColorStr)
let l=S.M.Replace((0,d.T)("使用限制：[{0}]{1}/[-][{2}]{3}[-]"),"{0}",n)
l=S.M.Replace(l,"{1}",i.toString()),l=S.M.Replace(l,"{2}","CCCBC4"),l=S.M.Replace(l,"{3}",s.toString()),this.text_limit.textSet(l)
const a=F.t.Inst_get().GetNextUseLevel(t,this.select_info.Level_get())
if(0==a)this.text_next_limit.textSet("")
else{const e=F.t.Inst_get().GetUseLimit(t,a)
let i=S.M.Replace(b.x.Inst().getItemById(100701).sys_messsage,"{0}",B.h.GetLevelStr(a))
i=S.M.Replace(i,"{1}",S.M.IntToString(e)),this.text_next_limit.textSet(i)}}UpdateList(){const t=this.GetFruitList()
if(0==F.t.Inst_get().selectFruitId){const e=t[0]
F.t.Inst_get().selectFruitId=e.itemId}this.list_fruit.data_set(t)}PlayEffect(){this.eff0.SetActive(!1),this.eff1.SetActive(!1),this.eff2.SetActive(!1),this.eff3.SetActive(!1),
this.eff4.SetActive(!1),-1!=this.animTimer&&(this.animTimer=_.C.Inst_get().ClearInterval(this.animTimer),this.animTimer=-1),this.animIndex=0,
this.animTimer=_.C.Inst_get().SetInterval(this.CreateDelegate(this.AnimHandler),200,-1),this.AnimHandler()}AnimHandler(){this[`eff${this.animIndex}`].SetActive(!0),
this.animIndex+=1,this.animIndex>=this.rewardCount&&(this.animTimer=_.C.Inst_get().ClearInterval(this.animTimer),this.animTimer=-1)}GetFruitList(){const t=new f.Z
for(const[e,i]of(0,h.V5)(k.r.Inst_get().fruitDict))i.showLv<=this.select_info.Level_get()&&t.Add(i)
return t.Sort(this.CreateDelegate(this.SortByRank)),t}SortByRank(t,e){const i=t,s=e
return i.rank<s.rank?-1:i.rank>s.rank?1:0}Clear(){this.RemoveLis(),this.character_tab.Clear(),this.ClearTimer(),F.t.Inst_get().selectFruitId=0,
_.C.Inst_get().ClearInterval(this.barInterval)}Destroy(){super.destroy(),this.ClearTimer()}})}}])
