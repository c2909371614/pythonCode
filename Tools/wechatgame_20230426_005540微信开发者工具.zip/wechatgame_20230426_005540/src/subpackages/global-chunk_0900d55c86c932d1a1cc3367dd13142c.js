(globalThis.webpackChunkProject=globalThis.webpackChunkProject||[]).push([[23],{31186:(e,t,i)=>{"use strict"
i.d(t,{N:()=>H})
var n=i(38836),s=i(38214),a=i(98958),r=i(68662),l=i(38935),o=i(98885),_=i(14440),u=i(62699),h=i(39433),c=i(14792),d=i(62734),m=i(56937),p=i(18202),g=i(31222),I=i(5494),E=i(99294),C=i(9986),S=i(6665),T=i(61911),f=i(52726),A=i(85602),y=i(79534),R=i(77399),D=i(49603),w=i(1240),L=i(29904),v=i(55094),O=i(53905),P=i(74045),N=i(39879),M=i(49067),b=i(65772),G=i(65550)
class U extends T.f{constructor(){super(),this.model=null,this._degf_OnClose=null,this._degf_OnTip=null,this._degf_OnGain=null,this._degf_CreateItem=null,this.closeBtn=null,
this.tipBtn=null,this.androidIcon=null,this.scrollGrid=null,this.gainBtn=null,this.redPoint=null,this.iosIcon=null,this.model=H.Inst(),this._degf_OnClose=(e,t)=>this.OnClose(e,t),
this._degf_OnTip=(e,t)=>this.OnTip(e,t),this._degf_OnGain=(e,t)=>this.OnGain(e,t),this._degf_CreateItem=e=>this.CreateItem(e)}InitView(){this.closeBtn=new C.W,
this.closeBtn.setId(this.FatherId,this.FatherComponentID,1),this.tipBtn=new C.W,this.tipBtn.setId(this.FatherId,this.FatherComponentID,2),this.androidIcon=new E.z,
this.androidIcon.setId(this.FatherId,this.FatherComponentID,3),this.scrollGrid=new S.A,this.scrollGrid.setId(this.FatherId,this.FatherComponentID,4),this.gainBtn=new C.W,
this.gainBtn.setId(this.FatherId,this.FatherComponentID,5),this.redPoint=new E.z,this.redPoint.setId(this.FatherId,this.FatherComponentID,6),this.iosIcon=new E.z,
this.iosIcon.setId(this.FatherId,this.FatherComponentID,7),this.scrollGrid.SetInitInfo("ui_bag_rwditem76_76",this._degf_CreateItem)}Destroy(){this.closeBtn=null,this.tipBtn=null,
this.androidIcon=null,this.scrollGrid.Destroy(),this.scrollGrid=null,this.gainBtn=null,this.redPoint=null,this.iosIcon=null}OnAddToScene(){this.AddListeners(),this.UpdateView()}
Clear(){this.RemoveListeners()}AddListeners(){this.AddClickEvent(this.closeBtn,this._degf_OnClose),this.AddClickEvent(this.tipBtn,this._degf_OnTip),
this.AddClickEvent(this.gainBtn,this._degf_OnGain)}RemoveListeners(){this.RemoveClickEvent(this.closeBtn,this._degf_OnClose),this.RemoveClickEvent(this.tipBtn,this._degf_OnTip),
this.RemoveClickEvent(this.gainBtn,this._degf_OnGain)}OnClose(e,t){B.Inst.CloseMainView()}OnTip(e,t){const[i,n]=this.model.GetPlatformInfo(),s=new O.w
r.D.IsEditor||r.D.IsAndroid?s.infoId="UPDATE:REWARD_ANDROIDTIPS":s.infoId="UPDATE:REWARD_TIPS",s.replaceParams.Add(n),s.width=384,s.position=new y.P(-212,251,0),
b.Q.Inst_get().Open(s)}OnGain(e,t){const i=_.J.Inst_get().GetActivityConfig(u.S.VERSION_ACTIVITY)
if(null==i)return
const s=i.AcVo_get()
if(null==s)return
let a=null,l=h.W.NONE
for(const[e,t]of(0,n.V5)(s.rewards)){a=D.H.Inst_get().GetRewardById(e),l=t
break}if(l==h.W.GAIN)return void G.y.inst.ClientSysMessage(120001)
if(!H.Inst().IsNewApp()){let e=null
e=r.D.IsEditor||r.D.IsAndroid?N.L.Inst().getItemById("UPDATE:LEAD_ANDROIDTIPS"):N.L.Inst().getItemById("UPDATE:LEAD_TIPS")
const[t,i]=this.model.GetPlatformInfo(),n=new M.B
return n.infoId=e.id,n.replaceParams.Add(i),n.layer=f.F.Tip,n.tipstype=1,void P.t.Inst().Open(n)}null!=a&&R.x.Inst_get().SendReward(u.S.VERSION_ACTIVITY,a.resource.id)}
UpdateView(){this.androidIcon.SetActive(r.D.IsEditor||r.D.IsAndroid),this.iosIcon.SetActive(r.D.IsIos)
const e=this.GetDataList()
this.scrollGrid.data_set(e)
const t=d.f.Inst.GetData(c.t.VERSION_ACTIVITY)
null!=t?this.redPoint.SetActive(t.show):this.redPoint.SetActive(!1)}GetDataList(){const e=new A.Z,t=_.J.Inst_get().GetActivityConfig(u.S.VERSION_ACTIVITY)
if(null!=t){const i=t.AcVo_get(),s=t.GetRewards()
if(null!=i)for(const[t,a]of(0,n.V5)(i.rewards)){let i=new A.Z,n=0
for(;n<s.Count();){if(s[n].rewardVO.id==t){i=s[n].GetItemRewards()
break}n+=1}for(let t=1;t<=i.Count();t++){const n=i[t-1],s=new v.a
a==h.W.GAIN?s.hasGain=!0:s.hasGain=!1
const r=new w.Y
r.serverData_set(n.serverData_get()),r.baseData_get().isCanOperate=!1,r.baseData_get().isEquipCompare=!1,r.baseData_get().isShowAccess=!0,r.baseData_get().isNoBagItemData=!0,
s.bagData=r,e.Add(s)}}}return e}CreateItem(e){const t=new L.N
return t.setId(e,null,0),t}}class B{constructor(){this.mainView=null,this._degf_LoadMainView=null,this._degf_DestroyMainView=null,this._degf_LoadMainView=e=>this.LoadMainView(e),
this._degf_DestroyMainView=()=>this.DestroyMainView()}OpenMainView(){if(null!=this.mainView&&this.mainView.isShow_get())return
const e=new m.v
e.isShowMask=!0,e.maskAlpha=.7,e.isDefaultUITween=!0,e.isSelfTween=!0,g.N.inst.OpenById(I.I.eVersionActivityPanel,this._degf_LoadMainView,this._degf_DestroyMainView,e)}
LoadMainView(e){return null==this.mainView&&(this.mainView=new U,this.mainView.setId(e,null,0)),this.mainView}CloseMainView(){
null!=this.mainView&&this.mainView.isShow_get()&&g.N.inst.CloseById(I.I.eVersionActivityPanel)}DestroyMainView(){p.g.DestroyUIObj(this.mainView),this.mainView=null}
UpdateMainView(e){null!=this.mainView&&this.mainView.isShow_get()&&(null==e?this.CloseMainView():this.mainView.UpdateView())}}B.Inst=null
var k=i(26421)
class F extends k.k{constructor(...e){super(...e),this.isNewestPackage=!1}reading(){return this.isNewestPackage=this.readBool(),!0}writing(){
return this.writeBool(this.isNewestPackage),!0}getId(){return-4116}}class H{constructor(){this.hasSendPackageInfo=!1}static Inst(){return null==H._inst&&(H._inst=new H),H._inst}
ResetData(){this.hasSendPackageInfo=!1}IsNewApp(){if(r.D.IsEditor)return!1
const e=BuildConfig.appVersionStr
if(o.M.IsNullOrEmpty(e))return!1
let t=e
return r.D.IsIos?t="200.9.2":r.D.IsAndroid&&(t="1.9.2"),e==t}IsShowEntranceIcon(){const e=_.J.Inst_get().GetActivityConfig(u.S.VERSION_ACTIVITY)
if(null==e)return!1
if(!this.IsNewApp())return!0
{const t=e.AcVo_get()
for(const[e,i]of(0,n.V5)(t.rewards))return i!=h.W.GAIN}}ChangeActivityInfo(){const e=_.J.Inst_get().GetActivityConfig(u.S.VERSION_ACTIVITY)
let t=!1
if(null!=e&&this.IsNewApp()){const i=e.AcVo_get()
for(const[e,s]of(0,n.V5)(i.rewards)){s!=h.W.GAIN&&(t=!0)
break}}if(d.f.Inst.SetState(c.t.VERSION_ACTIVITY,t),!this.hasSendPackageInfo){this.hasSendPackageInfo=!0
const e=new F
e.isNewestPackage=this.IsNewApp(),l.C.Inst.F_SendMsg(e)}B.Inst.UpdateMainView(e)}GetPlatformInfo(e){let t=null,i=null
return"46"==(e=e||s.Q.Instance.pid)?(t="gengxinyouli_sp_0002",i=a.V.Inst().getStr2(10992)):(t="gengxinyouli_sp_0003",i=a.V.Inst().getStr2(10991)),[t,i]}}H._inst=null},
15771:(e,t,i)=>{"use strict"
i.d(t,{U:()=>u})
var n=i(70959),s=i(49655),a=i(5494),r=i(56937),l=i(17409)
class o{constructor(){this.panel=null,this.isOpenAddExp=!1,this.leftCount=0,this.copyType=0,this._degf_CallBuyDestory=null,this._degf_CallDestory=null,
this._degf_OnBuyShowComplete=null,this._degf_OnShowComplete=null,this._degf_handler=null,this.useExpView=null,this.m_upgradePanel=null,this._degf_CallBuyDestory=()=>{},
this._degf_CallDestory=()=>{},this._degf_OnBuyShowComplete=e=>{},this._degf_OnShowComplete=e=>{},this._degf_handler=e=>{}}OpenPanel(e=null,t=null){null==e&&(e=!1),
this.isOpenAddExp=e
const i=new r.v
i.isShowMask=!1,i.isSelfTween=!1,i.isDefaultUITween=!0,(0,l.Yp)(s.o.VIPPanel,i)}CloseVipPanel(){(0,l.sR)(a.I.VIPPanel)}OpenExpUseView(){if(null==this.useExpView){const e=new r.v
e.isShowMask=!0,e.isSelfTween=!1,e.isDefaultUITween=!0,(0,l.Yp)(s.o.VIPExpView,e)}}CloseExpUseView(){(0,l.sR)(s.o.VIPExpView)}OpenBuyPanel(e,t){}CloseBuyPanel(){(0,
l.sR)(s.o.VIPBuyPanel)}OpenUpgradePanel(){if(null==this.m_upgradePanel){(new r.v).isShowMask=!1,(0,l.Yp)(s.o.VIPUpgradeView),this.m_upgradePanel=(0,l.Y)(s.o.VIPUpgradeView)
}else this.m_upgradePanel.UpdateView()}CloseUpgradePanel(){(0,l.sR)(s.o.VIPUpgradeView)}}var _=i(63563)
class u{static get inst(){return u._inst||(u._inst=new u),u._inst}constructor(){this.mgr=null,this.model=null,this.controller=null,this.mgr=_.m.Inst(),this.model=new n.A,
this.controller=new o}}u._inst=null},63563:(e,t,i)=>{"use strict"
i.d(t,{m:()=>C})
var n,s,a,r,l,o,_=i(98800),u=i(92415),h=i(99156),c=i(19699),d=i(38935),m=i(38962),p=i(42292),g=i(71409),I=i(15771)
function E(e,t,i,n,s){var a={}
return Object.keys(n).forEach((function(e){a[e]=n[e]})),a.enumerable=!!a.enumerable,a.configurable=!!a.configurable,("value"in a||a.initializer)&&(a.writable=!0),
a=i.slice().reverse().reduce((function(i,n){return n(e,t,i)||i}),a),s&&void 0!==a.initializer&&(a.value=a.initializer?a.initializer.call(s):void 0,a.initializer=void 0),
void 0===a.initializer&&(Object.defineProperty(e,t,a),a=null),a}let C=(n=(0,g.GH)(u.k.SM_ChangeVipLevel),s=(0,g.GH)(u.k.SM_ShowVip),a=(0,g.GH)(u.k.SM_DrawVipReward),r=(0,
g.GH)(u.k.SM_VipInfo),o=class e{constructor(){this._degf_SM_DrawVipRewardoHandler=null,this._degf_SM_ShowVipHandler=null,this._degf_SM_UpdateVipSettingHandler=null,
this._degf_SM_VipInfoHandler=null,this._degf_SM_ChangeVipLevelHandle=null,this._degf_SM_DrawVipRewardoHandler=e=>this.SM_DrawVipRewardoHandler(e),
this._degf_SM_ShowVipHandler=e=>this.SM_ShowVipHandler(e),this._degf_SM_UpdateVipSettingHandler=e=>this.SM_UpdateVipSettingHandler(e),
this._degf_SM_VipInfoHandler=e=>this.SM_VipInfoHandler(e),this._degf_SM_ChangeVipLevelHandle=e=>this.SM_ChangeVipLevelHandle(e)}static Inst(){
return null==this._inst&&(this._inst=new e),this._inst}Reg(){}SM_ChangeVipLevelHandle(e){I.U.inst.model.SM_ChangeVipLevelHandle(e)}SM_ShowVipHandler(e){
const t=e,i=_.Y.Inst.getRoleInfo(t.playerId)
null!=i&&(i.VipLevel_set(t.vipLevel),i.ShowVip_set(t.showVip))}SM_UpdateVipSettingHandler(e){}SM_DrawVipRewardoHandler(e){const t=e
I.U.inst.model.UpdateRewardInfo(t.level)}SM_VipInfoHandler(e){const t=e
I.U.inst.model.Update(t)}RequestCM_DrawVipReward(e){const t=new h.m
t.level=e,d.C.Inst.F_SendMsg(t)}RequestCM_UpdateVipSetting(e){}ReqCM_VipInfo(){const e=new c.t
d.C.Inst.F_SendMsg(e)}GetVipSpriteName(t){return e._GetVipSpriteName(t,!1)}GetVipHeadSpriteName(t){return e._GetVipSpriteName(t,!0)}static _GetVipSpriteName(e,t){
return I.U.inst.model.GetPanelResVO(e).res.vipShow}},o.VipSpriteName=new m.X,o.VipHeadSpriteName=new m.X,o._inst=null,
E(l=o,"Inst",[p.n],Object.getOwnPropertyDescriptor(l,"Inst"),l),
E(l.prototype,"SM_ChangeVipLevelHandle",[n],Object.getOwnPropertyDescriptor(l.prototype,"SM_ChangeVipLevelHandle"),l.prototype),
E(l.prototype,"SM_ShowVipHandler",[s],Object.getOwnPropertyDescriptor(l.prototype,"SM_ShowVipHandler"),l.prototype),
E(l.prototype,"SM_DrawVipRewardoHandler",[a],Object.getOwnPropertyDescriptor(l.prototype,"SM_DrawVipRewardoHandler"),l.prototype),
E(l.prototype,"SM_VipInfoHandler",[r],Object.getOwnPropertyDescriptor(l.prototype,"SM_VipInfoHandler"),l.prototype),l)},70959:(e,t,i)=>{"use strict"
i.d(t,{A:()=>M})
var n=i(38836),s=i(38045),a=i(98800),r=i(97461),l=i(62370),o=i(98885),_=i(85602),u=i(38962),h=i(92679),c=i(75439),d=i(32076),m=i(5924),p=i(70850),g=i(33138),I=i(62734),E=i(15771),C=i(86133),S=i(72800),T=i(46749),f=i(74657),A=i(12417),y=i(22046),R=i(90419),D=i(50089)
class w{constructor(e){this.vipLv=null,this.nodeIndex=null,this.needExp=null,this.reward=null,this.showConsume=null,this.consume=null,this.isRewarded=null,this.VipPowerCellVO(e)}
VipPowerCellVO(e){this.vipLv=0,this.nodeIndex=0,this.needExp=0,this.reward=null,this.showConsume=null,this.consume=null,this.isRewarded=!1}GetIsRewarded(){
return E.U.inst.model.isHasRewarded(this.vipLv)}GetLeftExp(){const e=E.U.inst.model.diamond
return this.needExp-e}IsCanReward(){return!this.GetIsRewarded()&&this.GetLeftExp()<=0}GetGiftList(){const e=f.A.GetReward(this.reward)
return null!=e?e.GetAllRewardList():this.reward}}class L{constructor(e){this.res=null,this.m_powerList=null,this.m_consume=null,this.m_showConsume=null,this.nowPriceList=null,
this.giftPartList=null,this.res=e}GetPowerList(){return null==this.m_powerList&&(this.m_powerList=new _.Z,this.Init()),this.m_powerList}GetPartVO(){return this.GetPartVOList()[0]}
GetPartVOList(){if(null==this.giftPartList){this.giftPartList=new _.Z
const e=this.res.needExp,t=T.z.CreateFromJson(this.res.consume)
t.Parse()
const i=T.z.CreateFromJson(this.res.consumeShow)
i.Parse()
const n=1
let s=0
for(;s<n;){const n=new w(null)
n.vipLv=this.res.level,n.needExp=e,n.reward=this.res.reward,n.showConsume=i.typevalues[s],n.consume=t.typevalues[s],this.giftPartList.Add(n),s+=1}}return this.giftPartList}
GetCopyAddCount(e){if(e==S.S.WORLDBOSS)return this.GetCopyAdd_Special(e)
const t=this.GetCopyList(e)
return null!=t?(this.nowPriceList=t,t.count):0}GetCopyPrice(e,t){const i=this.GetCopyList(e)
return null!=i?o.M.String2Int(i[t]):0}GetCopyList(e){let t=null
if(A._.Inst().IsVipBossCopy(e)){for(let i=0;i<=this.res.vipbossBuy.length;i++)if(this.res.vipbossBuy[i].type==e){t=this.res.vipbossBuy[i].value
break}}else e==S.S.Belial?t=this.res.devilBuy:e==S.S.BloodTown?t=this.res.bloodBuy:e==S.S.Arena?t=this.res.arenaBuy:S.S.LostAbyss
return null!=t&&(t=new _.Z(t)),t}GetSpecialBossPower(e){
return e==y.l.WORLDBOSS?this.res.bossPower1:e==y.l.ANCIENTBOSS?this.res.bossPower2:e==y.l.CROSSBOSS?this.res.bossPower3:void 0}GetMultipleTimes(){return 0}Init(){}GetPanelTxtSts(){
const e=new _.Z(3)
return e[0]=`V${this.res.level+(0,C.T)("特权")}`,e[1]=`VIP${this.res.level+(0,C.T)("专属礼包")}`,e}GetGiftList(){const e=f.A.GetReward(this.res.reward)
return null!=e?e.GetAllRewardList():null}GetConsume(){if(null==this.m_consume){const e=R.d.parseJsonObjectWithFix(this.res.consume.value,"typevalues"),t=D.t.decode(e,T.z)
t.Parse(),this.m_consume=t.typevalues[0]}return this.m_consume}GetShowConsume(){if(null==this.m_showConsume){
const e=R.d.parseJsonObjectWithFix(this.res.consumeShow.value,"typevalues"),t=D.t.decode(e,T.z)
t.Parse(),this.m_showConsume=t.typevalues[0]}return this.m_showConsume}Reset(){const e=f.A.GetReward(this.res.reward)
null!=e&&e.Reset()}GetCopyAdd_Special(e){return e==S.S.WORLDBOSS?this.res.bossTiredBuy1.value:0}}var v=i(21554),O=i(87923),P=i(38501),N=i(14792)
class M{constructor(){this.diamond=0,this.rewards=null,this.vipInfo=null,this.m_res=null,this.defaultVipGiftIndex=-1,this.canHigherLv=0,this.m_frontRedVipLv=-1,
this.clckedRedPoints=null,this.m_resDic=null,this.hasShowPoint=!1,this.curMaxLv=M.MAX_LEVEL,this.nowPriceList=null,this.changeMsg=null,this.autoUseVipLv=null,this.vipCardIds=null,
this.vipCardNums=null,this.delayUseItemTimeId=null,this._degf_CheckAutoUseCard=null,this.clckedRedPoints=new u.X,this.m_resDic=new u.X,M.MAX_LEVEL=P.f.Inst().GetMaxVipLevel(),
M.MIN_UNHIDE_LEVEL=-1,this.autoUseVipLv=c.D.getInstance().GetIntValue("VIP:CARDAUTOUSE")
const e=c.D.getInstance().GetStringArray("VIP:CARDTYPE")
this.vipCardIds=new _.Z,this.vipCardNums=new _.Z
for(let t=0;t<=e.count-1;t++){const i=o.M.Split(e[t],l.o.s_Arr_UNDER_CHAR_DOT),n=(0,s.aI)(i[0])
this.vipCardIds.Add(n),this.vipCardNums.Add((0,s.aI)(i[1]))}this._degf_CheckAutoUseCard=()=>this.CheckAutoUseCard(),r.i.Inst.AddEventHandler(h.g.BAG_INITED,(0,
d.v)(this.UpdateExpItemRedPoint,this)),r.i.Inst.AddEventHandler(h.g.BAG_UPDATE,(0,d.v)(this.UpdateExpItemRedPoint,this))}isHasRewarded(e){
return!(!this.rewards.LuaDic_ContainsKey(e)||this.rewards.LuaDic_IsNullValue(this.rewards[e]))&&this.rewards[e]}isPartHasReward(e){
return this.GetPanelResVO(e).GetPartVO().IsCanReward()}Update(e){this.vipInfo=e,this.diamond=e.vipExp,this.rewards=e.rewards
const t=a.Y.Inst.PrimaryRoleInfo_get()
let i=0
if(i=e.level<e.tempLevel?e.tempLevel:e.level,t.VipLevel_set(i),t.ShowVip_set(e.showVip),this.m_res=null,M.isShowLog,r.i.Inst.RaiseEvent(h.g.VIP_UPDATE),
-1!=this.m_frontRedVipLv&&i>this.m_frontRedVipLv&&(this.hasShowPoint=!1),this.m_frontRedVipLv=i,i>=1&&!this.hasShowPoint){let e=i
for(;e>=1;)this.isPartHasReward(e)&&(this.clckedRedPoints.LuaDic_ContainsKey(e)||I.f.Inst.SetState(N.t.VIP_BOX+e,!0),this.hasShowPoint=!0),e-=1}}SM_ChangeVipLevelHandle(e){
this.changeMsg=e,E.U.inst.controller.OpenUpgradePanel()}UpdateRewardInfo(e){this.rewards[e]=!0,I.f.Inst.SetState(N.t.VIP_BOX+e,!1),r.i.Inst.RaiseEvent(h.g.VIP_UPDATE)}level_get(){
return null!=this.vipInfo?this.vipInfo.level<this.vipInfo.tempLevel?this.vipInfo.tempLevel:this.vipInfo.level:0}effectiveLevel_get(){return this.level_get()}trueLevel_get(){
return null!=this.vipInfo?this.vipInfo.level:0}tempLevel_get(){return null!=this.vipInfo?this.vipInfo.tempLevel:0}isVipActive_get(){
return null!=this.vipInfo&&(this.vipInfo.level>0||this.vipInfo.tempLevel>0)}vipRes_get(){return null==this.m_res&&(this.m_res=P.f.Inst().getItemById(this.effectiveLevel_get())),
this.m_res}GetPanelResVO(e){if(!this.m_resDic.LuaDic_ContainsKey(e)){const t=P.f.Inst().getItemById(e),i=new L(t)
this.m_resDic.LuaDic_AddOrSetItem(e,i)}return this.m_resDic[e]}IsAllVipGiftDrawed(){let e=1
for(;e<=this.level_get();){if(!this.vipInfo.rewards.LuaDic_ContainsKey(e)||!this.vipInfo.rewards[e])return!1
e+=1}return!0}GetCopyPrice(e,t){return this.GetPanelResVO(this.level_get()).GetCopyPrice(e,t)}GetQuentonPrice(e,t){return 0}GetNextRes(){
return this.isMaxLevel_get()?null:P.f.Inst().getItemById(this.effectiveLevel_get()+1)}GetNeedExp(e){return e.needExp}isMaxLevel_get(){return this.effectiveLevel_get()==M.MAX_LEVEL}
SetCurMaxLevel(e){this.curMaxLv=e}GetLevelCellData(){const e=new _.Z
let t=0
for(;t<=M.MAX_LEVEL;)e.Add(t),t+=1
return e}GetCopyAddCount(e){const t=this.GetPanelResVO(this.level_get()),i=t.GetCopyAddCount(e)
return this.nowPriceList=t.nowPriceList,i}GetCopyFreeNum(e){let t=0
const i=P.f.Inst().getItemById(this.level_get())
for(let n=0;n<i.vipBossFree.length;n++)if(i.vipBossFree[n].type==e){t=i.vipBossFree[n].value
break}return t}GetUpVipBossCopyNum(e){if(S.S.VipBoss==e){let e=this.level_get(),t=0,i=0,n=null
if(0!=e){n=P.f.Inst().getItemById(e)
const i=O.l.AnalyseArrayStr(n.personalBuy)
t=n.vipBossFree+i.count}for(e+=1;e<P.f.Inst().maxLv;){n=P.f.Inst().getItemById(e)
const s=O.l.AnalyseArrayStr(n.personalBuy)
if(i=n.vipBossFree+s.count,i>t)return e+1
e+=1}}}GetUpVipBossCopyBuyNum(e){let t=0
if(A._.Inst().IsVipBossCopy(e)){let i=this.level_get()
t=this.GetPanelResVO(i).GetCopyAddCount(e),i+=1
const n=P.f.Inst().GetMaxVipLevel()
for(;i<n;){const n=this.GetPanelResVO(i).GetCopyAddCount(e)
if(n>t)return[i,n]
i+=1}}return[0,0]}NeedUpVipForCopy(e){if(this.isMaxLevel_get())return!1
const t=this.GetCopyAddCount(e)
let i=this.level_get()+1
for(;i<=M.MAX_LEVEL;){const n=this.GetPanelResVO(i)
if(n.GetCopyAddCount(e)>t)return this.canHigherLv=i,this.nowPriceList=n.nowPriceList,!0
i+=1}return!1}ResetModel(){this.hasShowPoint=!1,this.clckedRedPoints=new u.X
for(const[e,t]of(0,n.V5)(this.m_resDic))t.Reset()
M.MIN_UNHIDE_LEVEL=-1}GetCopyAddHigher(e){return this.GetPanelResVO(this.canHigherLv).GetCopyAddCount(e)}GetMinUnHideLevel(){
const e=c.D.getInstance().GetIntArray("VIP:LIMITLEVEL"),t=this.level_get()
let i=e[0]
for(let n=0;n<=e.Count()-1&&e[n]<=t;n++)null!=e[n+1]&&(i=e[n+1])
return i=Math.min(i,M.MAX_LEVEL),i}CheckAutoUseCard(){this.delayUseItemTimeId=null
let e=0
for(let t=0;t<=this.vipCardIds.Count()-1;t++){const i=p.g.Inst_get().GetItemNum(this.vipCardIds[t])
if(i>0&&(v.J.Inst_get().UseItemByModelId(this.vipCardIds[t],i),e+=1),5==e){m.C.Inst_get().SetInterval(this._degf_CheckAutoUseCard,5e3,1)
break}}}UpdateExpItemRedPoint(){if(I.f.Inst.SetState(N.t.VIP_EXP,!1),this.autoUseVipLv<=this.level_get());else for(let e=0;e<=this.vipCardIds.Count()-1;e++){
const t=this.vipCardIds[e],i=this.vipCardNums[e],n=g.f.Inst().getItemById(t),a=p.g.Inst_get().GetItemNum(t),r=n.Conditions_get().typevalues[0],l=this.level_get()
if(a>=i&&l>=(0,s.aI)(r.value)){I.f.Inst.SetState(N.t.VIP_EXP,!0)
break}}}IsVipCard(e){return this.vipCardIds.Contains(e)}IsVipCardLvLimit(){return this.level_get()<this.autoUseVipLv}IsVipCardLimit(e){
return this.IsVipCardLvLimit()&&this.IsVipCardLvLimit()}}M.MAX_LEVEL=15,M.isShowLog=!1,M.MIN_UNHIDE_LEVEL=null},38787:(e,t,i)=>{"use strict"
i.d(t,{Q:()=>s})
var n=i(83908)
class s extends((0,n.yk)()){_initBinder(){super._initBinder(),this.VipGiftRewardedCell()}VipGiftRewardedCell(){}InitView(){super.InitView()}SetData(e){const t=e.vo,i=e.item
this.hadReceive.SetActive(t.GetIsRewarded()),this.ui_baseitem.SetData(i)}Clear(){}Destroy(){super.destroy()}Test1(){return!0}S_Test(){return!0}}},91517:(e,t,i)=>{"use strict"
i.d(t,{a:()=>T})
var n=i(86133),s=i(38045),a=i(98958),r=i(62370),l=i(95721),o=i(98885),_=i(19519),u=i(53037),h=i(88162),c=i(72208),d=i(30459),m=i(5996),p=i(40863),g=i(21365),I=i(81358),E=i(69967)
class C{constructor(){this.virtualType=0,this.virtualValue=null,this.virtualTypeStr=null,this.limitId=null}}var S=i(98394)
class T{static GetItemByReward(e){let t=null
if((0,s.t2)(e,E.A)){const i=e
t=new C,t.virtualType=S.d.EXP,t.virtualTypeStr=S.d.EXP_STR,t.virtualValue=i.value}else if((0,s.t2)(e,c.L)){const i=e
t=new C,t.virtualType=_.J.TypeConvertToInt(i.type),t.virtualTypeStr=i.type,t.virtualValue=i.num}else if((0,s.t2)(e,g.e)){const i=e
t=new C,t.virtualType=S.d.ACTIVITY_SCORE,t.virtualTypeStr=S.d.ACTIVITY_SCORE_STR,t.virtualValue=i.activityScore}else if((0,s.t2)(e,d.x)){const i=e
t=new C,t.virtualType=S.d.FORTUNE_POINT,t.virtualTypeStr=S.d.FORTUNE_POINT_STR,t.virtualValue=l.o.New(i.rollNum,0)}else if((0,s.t2)(e,p.N)){const i=e
t=new C,t.virtualType=S.d.NORMAL_ROLL,t.virtualTypeStr=S.d.NORMAL_ROLL_STR,t.virtualValue=l.o.New(i.rollNum,0)}else if((0,s.t2)(e,m.C)){const i=e
t=new C,t.virtualType=S.d.LOCKY_ROLL,t.virtualTypeStr=S.d.LOCKY_ROLL_STR,t.virtualValue=l.o.New(i.rollNum,0)}else if((0,s.t2)(e,h._)){const i=e
t=new C,t.virtualType=S.d.ASURAM_BUILDING_POINT,t.virtualTypeStr=S.d.ASURAM_BUILDING_POINTStr,t.virtualValue=l.o.New(i.point,0)}else if((0,s.t2)(e,I.C)){const i=e
t=new C,t.virtualType=S.d.THEME_SCORE,t.virtualTypeStr=S.d.THEME_SCORE_STR,t.virtualValue=i.activityScore}else if((0,s.t2)(e,u.h)){const i=e
t=new C,t.virtualType=S.d.ANGEL_EXP,t.virtualTypeStr=S.d.ANGEL_EXP_STR,t.virtualValue=i.exp}return t}static GetVirtualIconUrlByInt(e){let t=""
return e==S.d.GOLD?t="atlas_common_0313":e==S.d.DIAMOND?t="atlas_common_0315":e==S.d.BIND_DIAMOND?t="atlas_common_0317":e==S.d.BLUE_DIAMOND?t="atlas_common_0319":e==S.d.EXP&&(t="atlas_common_0353"),
t}static GetItemByParam(e,t){const i=new C
return e==S.d.EXP_STR?i.virtualType=S.d.EXP:(i.virtualType=_.J.TypeConvertToInt(e),i.virtualTypeStr=e),i.virtualValue=t,i}static GetItemIcon(e){let t=""
return e.virtualType==S.d.GOLD?t="i10122":e.virtualType==S.d.DIAMOND?t="i10121":e.virtualType==S.d.BIND_DIAMOND?t="i10114":e.virtualType==S.d.BLUE_DIAMOND?t="i10113":e.virtualType==S.d.EXP?t="i10120":e.virtualType==S.d.Honour?t="i10112":e.virtualType==S.d.Score?t="i10249":e.virtualType==S.d.SkillPoint&&(t="i10190"),
t}static GetItemTips(e){let t="",i=0
e.virtualType==S.d.GOLD?i=10035:e.virtualType==S.d.DIAMOND?i=10036:e.virtualType==S.d.BIND_DIAMOND?i=10037:e.virtualType==S.d.EXP&&(i=10038)
const n=e.virtualValue.ToNum()
return t=a.V.Inst().getStr2(i,0,o.M.DoubleToString(n)),t}static GetVirtualItemSourceTips(e){let t="",i=0
return e.virtualType==S.d.GOLD?i=10056:e.virtualType==S.d.DIAMOND?i=10059:e.virtualType==S.d.BIND_DIAMOND?i=10057:e.virtualType==S.d.JINPO?i=10060:e.virtualType==S.d.EXP?i=10055:e.virtualType==S.d.BLUE_DIAMOND&&(i=10058),
t=a.V.Inst().getStr2(i),t}static GetVirtualItemPurposTips(e){let t="",i=0
e.virtualType==S.d.GOLD?i=10035:e.virtualType==S.d.DIAMOND?i=10036:e.virtualType==S.d.BIND_DIAMOND?i=10037:e.virtualType==S.d.EXP?i=10038:e.virtualType==S.d.BLUE_DIAMOND?i=10053:e.virtualType==S.d.JINPO&&(i=10054)
e.virtualValue.ToNum()
return t=a.V.Inst().getStr2(i),t}static GetVirtualItemName(e){let t="",i=0
e.virtualType==S.d.GOLD?i=10061:e.virtualType==S.d.DIAMOND?i=10062:e.virtualType==S.d.BIND_DIAMOND?i=10063:e.virtualType==S.d.EXP?i=10064:e.virtualType==S.d.BLUE_DIAMOND?i=10065:e.virtualType==S.d.JINPO&&(i=10066)
e.virtualValue.ToNum()
return t=a.V.Inst().getStr2(i),t}static GetVirtualItemNum(e,t){null==t&&(t=1)
const i=e.ToNum()*t
let s=r.o.NumToString(i,0),a=0,l="",_="",u="",h=""
if(o.M.Length(s)>4&&o.M.Length(s)<9)a=o.M.Length(s)-4,u=o.M.SubStringWithLen(s,0,a),h=o.M.SubStringWithLen(s,a,2),h="00"!=h&&o.M.Length(u)<3?o.M.s_DOT_CHAR_DOT+h:"",
o.M.Length(u)>3?(l=o.M.SubStringWithEnd(u,0,1),_=o.M.SubStringWithEnd(u,1,o.M.Length(u)),s=`${l},${_+(h+(0,n.T)("万"))}`):s=u+(h+(0,n.T)("万"))
else if(o.M.Length(s)>8&&o.M.Length(s)<13){a=o.M.Length(s)-8,u=o.M.SubStringWithLen(s,0,a),h=o.M.SubStringWithLen(s,a,2),h="00"!=h&&o.M.Length(u)<3?o.M.s_DOT_CHAR_DOT+h:""
let e=u
if(o.M.Length(u)>3){let t=a-3
for(;t>0;)l=o.M.SubStringWithEnd(e,0,t),_=o.M.SubStringWithEnd(e,t,o.M.Length(e)),e=`${l},${_}`,t-=3
s=e+(h+(0,n.T)("亿"))}else s=e+(h+(0,n.T)("亿"))}else if(o.M.Length(s)>12){a=o.M.Length(s)-12,u=o.M.SubStringWithLen(s,0,a),h=o.M.SubStringWithLen(s,a,2),
"00"!=h&&o.M.Length(u)<3?(2==o.M.Length(u)&&(h=o.M.SubStringWithLen(s,a,1),"0"==h&&(h="")),""!=h&&(h=o.M.s_DOT_CHAR_DOT+h)):h=""
let e=u
if(o.M.Length(u)>3){let t=a-3
for(;t>0;)l=o.M.SubStringWithEnd(e,0,t),_=o.M.SubStringWithEnd(e,t,o.M.Length(e)),e=`${l},${_}`,t-=3
s=e+(0,n.T)("万亿")}else s=3==o.M.Length(u)?e+(0,n.T)("万亿"):e+(h+(0,n.T)("万亿"))}else o.M.Length(s)>3&&(l=o.M.SubStringWithEnd(s,0,1),_=o.M.SubStringWithEnd(s,1,o.M.Length(s)),
s=`${l},${_}`)
return s}static GetItemQuality(e){return e.virtualType==S.d.GOLD||e.virtualType==S.d.DIAMOND||e.virtualType==S.d.BIND_DIAMOND||(e.virtualType,S.d.EXP),1}static GetCurrencyStr(e){
let t=""
return e==S.d.GOLD?t=(0,n.T)("金币"):e==S.d.DIAMOND?t=(0,n.T)("金钻"):e==S.d.BIND_DIAMOND?t=(0,n.T)("绑钻"):e==S.d.BLUE_DIAMOND?t=(0,n.T)("蓝钻"):e==S.d.Honour?t=(0,
n.T)("荣誉值"):e==S.d.SkillPoint?t=(0,n.T)("技能点"):e==S.d.Score?t=(0,n.T)("积分"):e==S.d.EXP?t=(0,n.T)("经验"):e==S.d.JINPO?t=(0,n.T)("精魄"):e==S.d.VITALITY_NUM?t=(0,
n.T)("活跃度"):e==S.d.REPUTATION_POINT?t=(0,n.T)("声望"):e==S.d.ANGEL_EXP&&(t=(0,n.T)("天使祝福")),t}}},98394:(e,t,i)=>{"use strict"
i.d(t,{d:()=>n})
class n{}n.GOLD=1,n.DIAMOND=2,n.BLUE_DIAMOND=3,n.BIND_DIAMOND=4,n.Honour=5,n.SkillPoint=6,n.Score=7,n.EXP=11,n.JINPO=12,n.VITALITY_NUM=13,n.REPUTATION_POINT=15,n.EXP_STR="EXP",
n.GOLD_STR="GOLD",n.FriendPointModelId=10234,n.AsuramContribute=10206,n.ACTIVITY_SCORE=11,n.ACTIVITY_SCORE_STR="ACTIVITY_SCORE",n.ASURAM_BUILDING_POINT=44,
n.ASURAM_BUILDING_POINTStr="ASURAM_BUILDING_POINT",n.NORMAL_ROLL=41,n.NORMAL_ROLL_STR="NORMAL_ROLL",n.LOCKY_ROLL=42,n.LOCKY_ROLL_STR="LOCKY_ROLL",n.FORTUNE_POINT=43,
n.FORTUNE_POINT_STR="FORTUNE_POINT",n.THEME_SCORE=44,n.THEME_SCORE_STR="THEME_SCORE",n.ANGEL_EXP=45,n.ANGEL_EXP_STR="ANGEL_VIP",n.TREASURES="TREASURES"},73082:(e,t,i)=>{
"use strict"
i.d(t,{N:()=>u})
var n=i(93984),s=i(38836),a=i(86133),r=i(66788),l=i(55360),o=i(85602),_=i(38962)
class u{constructor(){this.wallmap=null,this.wallListGroup=null,this.wallListGroup=new _.X
const e=l.Y.Inst.GetOrCreateCsv(n.h.eWall)
this.wallmap=e.GetCsvMap()
for(const[e,t]of(0,s.V5)(this.wallmap)){let e=null
e=this.wallListGroup.LuaDic_GetItem(t.mapId),null==e&&(e=new o.Z,this.wallListGroup.LuaDic_AddOrSetItem(t.mapId,e)),e.Add(t)}}static Inst(){return null==u._inst&&(u._inst=new u),
u._inst}getWallItemById(e){return this.wallmap.LuaDic_ContainsKey(e)?this.wallmap[e]:(r.Y.LogError(`${(0,a.T)("npcwallresource表找不到id:")}${e}`),null)}}u._inst=null},82474:(e,t,i)=>{
"use strict"
i.d(t,{$:()=>g})
var n,s,a=i(42292),r=i(98800),l=i(89549),o=i(36241),_=i(98497),u=i(38935),h=i(95417),c=i(38962),d=i(60546),m=i(51782),p=i(73082)
let g=(s=class e{static get inst(){return null==e._inst&&(e._inst=new e),e._inst}constructor(){this.pickDic=null,this._degf_SM_WallSitDownHandler=null,this.pickDic=new c.X,
this._degf_SM_WallSitDownHandler=e=>this.SM_WallSitDownHandler(e),this.registeProtocol()}registeProtocol(){_.j.Inst.F_Register(-1271,m.f,this._degf_SM_WallSitDownHandler)}
CM_WallSitDownHandler(e){r.Y.Inst.PrimaryRole_get().StopPathing()
const t=new d.z
t.objectId=e,u.C.Inst.F_SendMsg(t)}SM_WallSitDownHandler(e){const t=e,i=r.Y.Inst.getCharacterById(t.playerID,null,null,!0)
if(null!=i){const e=i
if(0!=t.flag){const i=p.N.Inst().getWallItemById(t.objectId)
e.SetPosXYZ(i.playerPosX,i.playerPosY),e.Statemachine_get().ResetEvent(),50==i.animationID?e.ChangeToWall(50):53==i.animationID&&e.ChangeToSit(53),e.MainRole_get().StopRotate(),
e.MainRole_get().SetDirection(i.dirtction),h.U.Inst.CheckCurrTouchDestory(i),e.isPlayer&&o._.getInst().endHang()
}else e.CurrentMachineState_get()!=l.k.Sit&&e.CurrentMachineState_get()!=l.k.Wall&&e.CurrentMachineState_get()!=l.k.Attack||e.ChangeToStand(!0)}
this.UpdateWallDic(t.objectId,t.playerID,1==t.flag)}UpdateWallDic(e,t,i){this.pickDic[e]=i?t:null}},s._inst=null,I=n=s,E="inst",C=[a.Vx],
S=Object.getOwnPropertyDescriptor(n,"inst"),T=n,f={},Object.keys(S).forEach((function(e){f[e]=S[e]})),f.enumerable=!!f.enumerable,f.configurable=!!f.configurable,
("value"in f||f.initializer)&&(f.writable=!0),f=C.slice().reverse().reduce((function(e,t){return t(I,E,e)||e}),f),
T&&void 0!==f.initializer&&(f.value=f.initializer?f.initializer.call(T):void 0,f.initializer=void 0),void 0===f.initializer&&(Object.defineProperty(I,E,f),f=null),n)
var I,E,C,S,T,f},23973:(e,t,i)=>{"use strict"
i.d(t,{j:()=>u})
var n=i(98800),s=i(84581),a=i(21697),r=i(45404),l=i(35907),o=i(31546),_=i(19833)
class u extends a.s{constructor(){super(),this.uiloaded=!1,this.cfg=null,this._degf_OnInit=null,this._degf_OnInit=e=>this.OnInit(e)}Cfg_get(){return this.cfg}Cfg_set(e){this.cfg=e}
InitByCfg(e){const t=new o.O,i=r.n.Instance_get().CreateDisplayObject(t,this.objId,-1,_.X.WALLCHARACTER,this._degf_OnInit,null,this._degf_OnMoveEnd)
return this.MainRole_set(new l.M(i)),this.m_worldtype=t._world,this.roletype=s.s.wall,this.Cfg_set(e),this.MainRole_get().IsInited()&&this.OnInit(this.MainRole_get()),
this.InitStateMachine(),this.AddEvents(),!0}InitByInfo(e,t){if(null==t)return!1
this.objId=e.objId
const i=new o.O
i._displayID=209000400,i._vPos.Set(e.x,e.y)
const n=r.n.Instance_get().CreateDisplayObject(i,this.objId,-1,_.X.WALLCHARACTER,this._degf_OnInit,null,this._degf_OnMoveEnd)
return this.MainRole_set(new l.M(n)),this.m_worldtype=i._world,this.roletype=s.s.wall,this.Cfg_set(t),this.MainRole_get().IsInited()&&this.OnInit(this.MainRole_get()),
this.InitStateMachine(),this.AddEvents(),!0}GetGameId(){return this.objId}AddEvents(){}UpdateTime(e,t){null!=this.Statemachine_get()&&this.Statemachine_get().AniUpdate()}
startWall(){}wallBreak(){n.Y.Inst.PrimaryRole_get().ChangeToStand(!0)}isAttackedable(){return!1}OnInit(e){null!=e&&(super.OnInit(e),this.uiloaded||(this.uiloaded=!0))}Destroy(){
this.cfg=null,super.Destroy()}}},13224:(e,t,i)=>{"use strict"
i.d(t,{w:()=>J})
var n=i(17409),s=i(49655),a=i(77546),r=i(32076),l=i(86133),o=i(98800),_=i(97960),u=i(97461),h=i(56937),c=i(18202),d=i(31222),m=i(5494),p=i(52726),g=i(995),I=i(79534),E=i(87839),C=i(92679),S=i(87923),T=i(59732),f=i(37648),A=i(55492),y=i(22662),R=i(31896),D=i(7155),w=i(43308),L=i(65550),v=i(19519),O=i(79475),P=i(80460),N=i(56782),M=i(33665),b=i(12826),G=i(27216),U=i(89675),B=i(50139),k=i(93877),F=i(30849),H=i(85682),x=i(47786),V=i(9986),Y=i(61911),W=i(85602),K=i(75439),Z=i(68637)
class z extends Y.f{constructor(...e){super(...e),this.expTimeLabel=null,this.expLabel=null,this.expBtn=null,this.numUseOver=null,this.expFreeBtn=null,this.expCostLabel=null}
UpdateView(){const e=P.r.Inst_Get(),t=e.GetExpStatus()
let i=0
i=e.firstPrayExp?K.D.getInstance().GetIntValue("FIRST_WISH"):e.GetExpBenift()
const n=new W.Z([S.l.GetPurseVOChineseStringEEx(i,2,1)])
this.expLabel.textSet(S.l.Substitute((0,l.T)("J{0}"),n))
let s="",a=`${e.maxExpTimes-e.expTimes}/${e.maxExpTimes}`
if(t==O.W.CostOver&&(a=S.l.SetStringColor("962424",a)),s=S.l.Substitute((0,l.T)("今日剩余次数：{0}次"),new W.Z([a])),this.expTimeLabel.textSet(s),t==O.W.CostTime){
const t=e.GetExpPrayCost()
this.expCostLabel.textSet(t)}this.UpdateBtn(t)}AddLis(){this.m_handlerMgr.AddClickEvent(this.expFreeBtn.node,this.CreateDelegate(this.FreebtnClick)),
this.m_handlerMgr.AddClickEvent(this.expBtn.node,this.CreateDelegate(this.CostbtnClick)),
this.m_handlerMgr.AddClickEvent(this.numUseOver.node,this.CreateDelegate(this.OverbtnClick))}RemoveLis(){
this.m_handlerMgr.RemoveClickEvent(this.expFreeBtn.node,this.CreateDelegate(this.FreebtnClick)),
this.m_handlerMgr.RemoveClickEvent(this.expBtn.node,this.CreateDelegate(this.CostbtnClick)),
this.m_handlerMgr.RemoveClickEvent(this.numUseOver.node,this.CreateDelegate(this.OverbtnClick)),this.UnRegGuide()}RegGuide(){this.UnRegGuide(),
this.expFreeBtn.node.activeSelf()?Z.c.Inst.RegGameObject(H.D.UI_WELF_PREY_L_BTN,this.expFreeBtn.node):Z.c.Inst.RegGameObject(H.D.UI_WELF_PREY_L_BTN,this.expBtn.node)}UnRegGuide(){
Z.c.Inst.UnRegGameObject(H.D.UI_WELF_PREY_L_BTN)}CheckGuide(){S.l.CheckBtnClickTrigger(H.D.UI_WELF_PREY_L_BTN)}FreebtnClick(){this.CheckGuide(),this.SendMsg()}CostbtnClick(){
this.CheckGuide(),this.SendMsg()}OverbtnClick(){this.SendMsg()}SendMsg(){J.Inst_Get().SendExpPrayMsg()}UpdateBtn(e){this.numUseOver.node.SetActive(e==O.W.CostOver),
this.expFreeBtn.node.SetActive(e==O.W.FreeTime),this.expBtn.node.SetActive(e==O.W.CostTime),this.RegGuide()}Activate(){this.InitHandlerMgr(),this.AddLis(),this.UpdateView()}
Deactivate(){this.RemoveLis()}InitView(){super.InitView(),this.expTimeLabel=this.CreateComponent(k.Q,1),this.expLabel=this.CreateComponent(k.Q,2),
this.expBtn=this.CreateComponent(V.W,3),this.numUseOver=this.CreateComponent(V.W,4),this.expFreeBtn=this.CreateComponent(V.W,5),this.expCostLabel=this.CreateComponent(k.Q,6)}
Clear(){super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}}class q extends F.C{constructor(...e){super(...e),this.moneyTimeLabel=null,this.moneyLabel=null,
this.costLabel=null,this.freeBtn=null,this.payBtn=null,this.numUseOver=null}UpdateView(){
const e=P.r.Inst_Get(),t=e.GetMoneyStatus(),i=e.GetMoneyBenifit(),n=new W.Z([S.l.GetPurseVOChineseStringEEx(i,2,1)])
this.moneyLabel.textSet(S.l.Substitute((0,l.T)("S{0}"),n))
let s="",a=`${e.maxMoneyTimes-e.moneyTimes}/${e.maxMoneyTimes}`
if(t==O.W.CostOver&&(a=S.l.SetStringColor("962424",a)),s=S.l.Substitute((0,l.T)("今日剩余次数：{0}次"),new W.Z([a])),this.moneyTimeLabel.textSet(s),t==O.W.CostTime){
const t=e.GetMoneyPrayCost()
this.costLabel.textSet(t)}this.UpdateBtn(t)}AddLis(){this.m_handlerMgr.AddClickEvent(this.freeBtn.node,this.CreateDelegate(this.FreebtnClick)),
this.m_handlerMgr.AddClickEvent(this.payBtn.node,this.CreateDelegate(this.CostbtnClick)),
this.m_handlerMgr.AddClickEvent(this.numUseOver.node,this.CreateDelegate(this.OverbtnClick))}RemoveLis(){
this.m_handlerMgr.RemoveClickEvent(this.freeBtn.node,this.CreateDelegate(this.FreebtnClick)),
this.m_handlerMgr.RemoveClickEvent(this.payBtn.node,this.CreateDelegate(this.CostbtnClick)),
this.m_handlerMgr.RemoveClickEvent(this.numUseOver.node,this.CreateDelegate(this.OverbtnClick)),this.UnRegGuide()}RegGuide(){this.UnRegGuide(),
this.freeBtn.node.activeSelf()?Z.c.Inst.RegGameObject(H.D.UI_WELF_PREY_R_BTN,this.freeBtn.node):Z.c.Inst.RegGameObject(H.D.UI_WELF_PREY_R_BTN,this.payBtn.node)}UnRegGuide(){
Z.c.Inst.UnRegGameObject(H.D.UI_WELF_PREY_R_BTN)}CheckGuide(){S.l.CheckBtnClickTrigger(H.D.UI_WELF_PREY_R_BTN)}FreebtnClick(){this.CheckGuide(),this.SendMsg()}CostbtnClick(){
this.CheckGuide(),this.SendMsg()}OverbtnClick(){this.CheckGuide(),this.SendMsg()}SendMsg(){J.Inst_Get().SendMoneyPrayMsg()}UpdateBtn(e){
this.numUseOver.node.SetActive(e==O.W.CostOver),this.freeBtn.node.SetActive(e==O.W.FreeTime),this.payBtn.node.SetActive(e==O.W.CostTime),this.RegGuide()}Activate(){
this.InitHandlerMgr(),this.AddLis(),this.UpdateView()}Deactivate(){this.RemoveLis()}InitView(){super.InitView(),this.moneyTimeLabel=this.CreateComponent(k.Q,1),
this.moneyLabel=this.CreateComponent(k.Q,3),this.costLabel=this.CreateComponent(k.Q,4),this.freeBtn=this.CreateComponent(V.W,5),this.payBtn=this.CreateComponent(V.W,6),
this.numUseOver=this.CreateComponent(V.W,7)}Clear(){super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}}class $ extends F.C{constructor(...e){super(...e),
this.expView=null,this.moneyView=null,this.tiplabel=null,this.registerUIScId=null,this.registerUIId=null}SMExpPrayHandler(){this.expView.UpdateView()}SMMoneyPrayHandler(){
this.moneyView.UpdateView()}OnAddToScene(){this.moneyView.Activate(),this.expView.Activate(),this.tiplabel.textSet(x.x.Inst().getItemById(11030495).sys_messsage),
this.node.SetActive(!0),this.RegUIShow()}InitView(){super.InitView(),this.expView=this.CreateComponentBinder(z,1),this.moneyView=this.CreateComponentBinder(q,2),
this.tiplabel=this.CreateComponent(k.Q,3)}RegUIShow(){this.registerUIScId=H.D.Pray,this.registerUIId=m.I.WelfarePanelId,
null!=this.registerUIScId&&INS.uIShowShortCut.RegUIShowDic(this.registerUIScId,this.registerUIId)}UnRegUIShow(e){
null!=this.registerUIScId&&(INS.uIShowShortCut.UnRegUIShowDic(this.registerUIScId),null!=e&&e&&(this.registerUIScId=null))}Clear(){this.node.SetActive(!1),super.Clear(),
this.moneyView.Deactivate(),this.expView.Deactivate(),this.UnRegUIShow()}Destroy(){super.Destroy(),this.moneyView=null,this.expView=null,this.tiplabel=null,this.expView=null,
this.moneyView=null,this.tiplabel=null}}i(9007)
var X=i(71294),Q=i(73830),j=i(73193)
class J{get redPacketView(){return(0,n.Y)(m.I.REDPACKET)}constructor(){this.netHandler=null,this.prayModel=null,this.prayView=null,this.tiredValView=null,this.levelRewardView=null,
this.mainPanel=null,this.monthCardView=null,this.advTipType=0,this.fighttoken=null,this.fighttokenReward=null,this.welfareContainer=null,this.CDKeyView=null,
this.dailyTotalRechargeView=null,this.dailyRedPacket=null,this.monthCardContainer=null,this.netHandler=j.c.inst,this.prayModel=P.r.Inst_Get(),P.r.Inst_Get().SetMaxTimes(),
o.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(_.A.VipUpdate,(0,r.v)(this.VipUpdateHandler,this)),o.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(_.A.LevelUpdate,(0,
r.v)(this.LevelUpdateHandler,this)),u.i.Inst.AddEventHandler(C.g.FUNCTION_OPEN,(0,r.v)(this.RefreshLevelRewardRedPoint,this)),
D.o.Inst_get().AddEventHandler(R.t.inst.BUY_SUCCESS_EVENT,(0,r.v)(this.RechargeSuccess,this))}RechargeSuccess(){
null!=P.r.Inst_Get().redPacketInfo&&(P.r.Inst_Get().redPacketInfo.rechargeToday=!0,u.i.Inst.RaiseEvent(C.g.UPDATE_REDPACKET_DAILY))}SendMoneyPrayMsg(){
const e=this.prayModel.GetMoneyStatus()
if(e!=O.W.CostOver){if(e==O.W.CostTime){const e=v.J.GetGold(o.Y.Inst.PrimaryRoleInfo_get(),v.J.GOLD_DIAMOND)
if(this.prayModel.GetMoneyPrayCost()>e){const e=I.P.zero_get()
return void w._.Inst_get().OpenByCurrency(v.J.GOLD_DIAMOND_STR,e)}}return this.netHandler.CMMoneyPray(),1}this.ShowOverTips()}IsShowLevelRewardTab(){
const e=P.r.Inst_Get().levelRewardList
a.s.Info(`配置数据${e.Count()}`)
for(let t=e.Count()-1;t>=0;t+=-1){const i=e[t],n=this.GetInfoById(i.id)
if(2!=n.state&&3!=n.state)return!0}return!1}SendExpPrayMsg(){const e=this.prayModel.GetExpStatus()
if(e!=O.W.CostOver){if(e==O.W.CostTime){if(this.prayModel.GetExpPrayCost()>v.J.GetGold(o.Y.Inst.PrimaryRoleInfo_get(),v.J.GOLD_DIAMOND)){const e=I.P.zero_get()
return void w._.Inst_get().OpenByCurrency(v.J.GOLD_DIAMOND_STR,e)}}return this.netHandler.CMExpPray(),1}this.ShowOverTips()}SendDailyTiredMsg(){
this.netHandler.CM_RewardDailyBossTired()}SendCDKeyMsg(e){this.netHandler.CM_ExchangeCode(e)}ShowOverTips(){L.y.inst.ClientStrMsg(y.r.SystemTipMessage,(0,l.T)("今日次数已用完"))}
SMMoneyPrayHandler(e){this.prayModel.moneyTimes=e,this.prayModel.HandleRedPoint(),this.prayView&&this.prayView.SMMoneyPrayHandler()}SMExpPrayHandler(e,t){this.prayModel.expTimes=e,
this.prayModel.firstPrayExp=t,this.prayModel.HandleRedPoint(),this.prayView&&this.prayView.SMExpPrayHandler()}SMPrayBigRewardHandler(){
L.y.inst.ClientStrMsg(y.r.SystemTipMessage,"这是一个大奖")}OpenPanel(){const e=new h.v
e.isShowMask=!0,e.isDefaultUITween=!0,e.isSelfTween=!0,e.viewClass=X.i,(0,n.Yp)(s.o.WelfareHallPanel,e)}ShowPrayView(e){null==this.prayView?(this.welfareContainer=e,
c.g.LoadOne("ui_pray_prayview",(0,r.v)(this.ShowPrayViewComplete,this))):this.prayView.OnAddToScene()}ClosePrayView(){null!=this.prayView&&this.prayView.Clear()}
ShowTiredValueView(e){null==this.tiredValView?(this.welfareContainer=e,c.g.LoadOne("ui_welfara_tiredvalue",(0,
r.v)(this.ShowTiredValueViewComplete,this))):this.tiredValView.OnAddToScene()}CloseTiredValueView(){null!=this.tiredValView&&this.tiredValView.Clear()}VipUpdateHandler(){
this.prayModel.SetMaxTimes(),this.prayModel.LevelChangeHandle()}LevelUpdateHandler(){this.prayModel.LevelChangeHandle()}RefreshLevelRewardRedPoint(){
this.prayModel.RefreshRedPointState()}ShowPrayViewComplete(e){const t=e[0]
this.prayView=new $,this.prayView.setId(t,null,0),this.prayView.node.transform.SetParent(this.welfareContainer.FatherId,this.welfareContainer.ComponentId),
d.N.inst.SetChildDepth(this.GetMainPanelId(),t),this.prayView.OnAddToScene()}DestroyPrayView(){null!=this.prayView?(this.prayView.Clear(),this.prayView.Destroy(),
c.g.DestroyUIObj(this.prayView),this.prayView=null):c.g.Unload(this.ShowPrayViewComplete)}ShowTiredValueViewComplete(e){}DestroyTiredValueView(){
null!=this.tiredValView?(this.tiredValView.Clear(),this.tiredValView.Destroy(),c.g.DestroyUIObj(this.tiredValView),
this.tiredValView=null):c.g.Unload(this.ShowTiredValueViewComplete)}OpenCDKeyView(){if(f.P.Inst_get().IsFunctionOpened(A.x.WELFARE_CDK)){if(null==this.CDKeyView){const e=new h.v
e.isShowMask=!0,e.isDefaultUITween=!0,e.isSelfTween=!0,d.N.inst.OpenById(m.I.CDKeyView,(0,r.v)(this.ShowCDKeyViewComplete,this),(0,r.v)(this.DestroyCDKeyView,this),e)}
}else S.l.SetFunctionTip(A.x.WELFARE_CDK)}CloseCDKeyView(){(0,n.sR)(m.I.CDKeyView)}ShowCDKeyViewComplete(e){return this.CDKeyView=new M.T,this.CDKeyView.setId(e,null,0),
this.CDKeyView}DestroyCDKeyView(){null!=this.CDKeyView&&(c.g.DestroyUIObj(this.CDKeyView),this.CDKeyView=null)}GetMainPanelId(){
if(null!=d.N.inst.GetViewById(m.I.WelfarePanelId))return d.N.inst.GetViewById(m.I.WelfarePanelId).FatherId}CloseView(){(0,n.sR)(s.o.WelfareHallPanel)}ResetPanel(){
this.CloseRedPacketMainView()}ShowLevelRewardView(e){null==this.levelRewardView?(this.welfareContainer=e,c.g.LoadOne("ui_welfare_levelRewardView",(0,
r.v)(this.ShowLevelRewardComplete,this))):this.levelRewardView.OnAddToScene()}ShowLevelRewardComplete(e){const t=e[0]
this.levelRewardView=new Q.I,this.levelRewardView.setId(t,null,0),this.levelRewardView.node.transform.SetParent(this.welfareContainer.FatherId,this.welfareContainer.ComponentId),
d.N.inst.SetChildDepth(this.GetMainPanelId(),t),this.levelRewardView.OnAddToScene()}CloseLevelRewardView(){null!=this.levelRewardView&&this.levelRewardView.Clear()}
DestroyLevelRewardView(){null!=this.levelRewardView?(this.levelRewardView.Clear(),this.levelRewardView.Destroy(),c.g.DestroyUIObj(this.levelRewardView),
this.levelRewardView=null):c.g.Unload(this.ShowLevelRewardComplete)}ShowDailyTotalRechargeView(e){null==this.dailyTotalRechargeView?(this.welfareContainer=e,
c.g.LoadOne("ui_welfare_dailytotalrecharge_view",(0,r.v)(this.ShowDailyTotalRechargeComplete,this))):this.dailyTotalRechargeView.OnAddToScene()}ShowDailyTotalRechargeComplete(e){
const t=e[0]
this.dailyTotalRechargeView=new G.z,this.dailyTotalRechargeView.setId(t,null,0),
this.dailyTotalRechargeView.node.transform.SetParent(this.welfareContainer.FatherId,this.welfareContainer.ComponentId),d.N.inst.SetChildDepth(this.GetMainPanelId(),t),
this.dailyTotalRechargeView.OnAddToScene()}CloseDailyTotalRechargeView(){null!=this.dailyTotalRechargeView&&this.dailyTotalRechargeView.Clear()}DestroyDailyTotalRechargeView(){
null!=this.dailyTotalRechargeView?(this.dailyTotalRechargeView.Clear(),this.dailyTotalRechargeView.Destroy(),c.g.DestroyUIObj(this.dailyTotalRechargeView),
this.dailyTotalRechargeView=null):c.g.Unload(this.ShowDailyTotalRechargeComplete)}ShowDailyRedPacketView(e){null==this.dailyRedPacket?(this.welfareContainer=e,
c.g.LoadOne("ui_welfare_daily_redpacket_view",(0,r.v)(this.ShowDailyRedPacketComplete,this))):this.dailyRedPacket.OnAddToScene()}ShowDailyRedPacketComplete(e){const t=e[0]
this.dailyRedPacket=new b.M,this.dailyRedPacket.setId(t,null,0),this.dailyRedPacket.node.transform.SetParent(this.welfareContainer.FatherId,this.welfareContainer.ComponentId),
d.N.inst.SetChildDepth(this.GetMainPanelId(),t),this.dailyRedPacket.OnAddToScene()}CloseDailyRedPacketView(){null!=this.dailyRedPacket&&this.dailyRedPacket.Clear()}
DestroyDailyRedPacketView(){null!=this.dailyRedPacket?(this.dailyRedPacket.Clear(),this.dailyRedPacket.Destroy(),c.g.DestroyUIObj(this.dailyRedPacket),
this.dailyRedPacket=null):c.g.Unload(this.ShowDailyRedPacketComplete)}OpenRedPacketMainView(){if(null!=this.redPacketView&&this.redPacketView.isShow_get())return
const e=new h.v
e.layerType=p.F.DefaultUI,e.aniDir=g.K.Down,d.N.inst.OpenById(m.I.REDPACKET,(0,r.v)(this.ShowRedPacketMainViewHandler,this),(0,r.v)(this.DestroyRedPacketMainVCiewHandler,this),e)}
CloseRedPacketMainView(){d.N.inst.CloseById(m.I.REDPACKET)}DestroyRedPacketMainVCiewHandler(){c.g.DestroyUIObj(this.redPacketView)}ShowRedPacketMainViewHandler(e){
return this.redPacketView,this.redPacketView}ShowLotteryView(e){E.v.Inst_get().Open(e)}CloseLotteryView(){E.v.Inst_get().Close()}DestroyLotteryView(){
E.v.Inst_get().OnDestroyMainView()}ShowDailyRechargeView(e){T.T.Inst_Get().Open(e)}CloseDailyRechargeView(){T.T.Inst_Get().Close()}DestroyDailyRechargeView(){
T.T.Inst_Get().OnDestroyMainView()}ShowMonthCardView(e){null==this.monthCardView?(this.monthCardContainer=e,c.g.LoadOne("ui_monthcard_view",(0,
r.v)(this.OnLoadMonthCardView,this))):this.monthCardView.SetData()}OnLoadMonthCardView(e){const t=e[0]
this.monthCardView=new B.B,this.monthCardView.setId(t,null,0),this.monthCardView.node.transform.SetParent(this.monthCardContainer.FatherId,this.monthCardContainer.ComponentId),
d.N.inst.SetChildDepth(this.GetMainPanelId(),t),this.monthCardView.SetData(),this.monthCardContainer=null}CloseMonthCardView(){null!=this.monthCardView&&this.monthCardView.Clear()}
DestroyMonthCardView(){null!=this.monthCardView&&(this.monthCardView.Clear(),this.monthCardView.Destroy(),c.g.DestroyUIObj(this.monthCardView),this.monthCardView=null)}
OpenAdvFightTokeTip(e){null==e&&(e=J.Fight_Token),this.advTipType=e
const t=new h.v
t.isShowMask=!0,t.viewClass=N.$,d.N.inst.OpenById(m.I.AdvanceFightTokenTip,null,null,t)}CloseAdvFightTokenTip(){this.advTipType=0,d.N.inst.CloseById(m.I.AdvanceFightTokenTip)}
GetInfoById(e){const t=P.r.Inst_Get().levelRewardMap[e],i={}
let n=0,s=0
return n=0==t.limit?Number.MAX_VALUE:this.prayModel.idLevelRewardNum.LuaDic_ContainsKey(e)?t.limit-this.prayModel.idLevelRewardNum[e]:t.limit,
this.prayModel.idLevelRewardState.LuaDic_ContainsKey(e)&&(s=this.prayModel.idLevelRewardState[e]),i.num=n,i.state=s,i}GetFightTokenReward(e,t){null==e&&(e=0),null==t&&(t=!1),
this.netHandler.CM_RewardFightToken(e,t)}GetAngelFightTokenReward(e,t){null==e&&(e=0),null==t&&(t=!1),this.netHandler.CM_RewardAngelFightToken(e,t)}OpenFightTokenReward(){
const e=new h.v
e.viewClass=U.z,e.isShowMask=!0,d.N.inst.OpenById(m.I.FightTokenGetTipPanel,null,null,e)}static Inst_Get(){return null==J.Inst&&(J.Inst=new J),J.Inst}}J.Fight_Token=0,
J.Angel_Fight_Token=1,J.Inst=null},73193:(e,t,i)=>{"use strict"
i.d(t,{c:()=>P})
var n,s,a,r,l,o,_,u,h,c,d=i(42292),m=i(71409),p=i(38935),g=i(9186),I=i(85743),E=i(90393),C=i(96077),S=i(4282),T=i(89040),f=i(11144),A=i(51045),y=i(92415),R=i(26394),D=i(18126),w=i(92721),L=i(11134),v=i(13224)
function O(e,t,i,n,s){var a={}
return Object.keys(n).forEach((function(e){a[e]=n[e]})),a.enumerable=!!a.enumerable,a.configurable=!!a.configurable,("value"in a||a.initializer)&&(a.writable=!0),
a=i.slice().reverse().reduce((function(i,n){return n(e,t,i)||i}),a),s&&void 0!==a.initializer&&(a.value=a.initializer?a.initializer.call(s):void 0,a.initializer=void 0),
void 0===a.initializer&&(Object.defineProperty(e,t,a),a=null),a}let P=(n=(0,m.GH)(y.k.SM_LevelRewardInfo),s=(0,m.GH)(y.k.SM_LevelRewardConfig),a=(0,m.GH)(y.k.SM_FightTokenInfo),
r=(0,m.GH)(y.k.SM_BeSuperMan),l=(0,m.GH)(y.k.SM_RewardFightToken),o=(0,m.GH)(y.k.SM_DailyRechargeInfo),_=(0,m.GH)(y.k.SM_RedPacketInfo),u=(0,m.GH)(y.k.SM_DailyTotalRechargeInfo),
c=class e{static get inst(){return null==e._inst&&(e._inst=new e),e._inst}CMMoneyPray(){const e=new f.C
p.C.Inst.F_SendMsg(e)}CMExpPray(){const e=new A.I
p.C.Inst.F_SendMsg(e)}CM_RewardDailyBossTired(){const e=new D._
p.C.Inst.F_SendMsg(e)}CM_ExchangeCode(e){const t=new R.N
t.exchangeCode=e,p.C.Inst.F_SendMsg(t)}SM_AngelBlessInfoHandler(e){w.M.Inst_get().HandleInfo(e.highToken,e.angleBlessMap,e.angleBlessExp,e.startTime),
w.M.Inst_get().RaiseEvent(w.M.FightToken_Update)}SM_AngelBlessRewardHandler(e){w.M.Inst_get().HandleUpdate(e.angelBlessVo),v.w.Inst_Get().fighttoken=e.angelBlessVo,
v.w.Inst_Get().fighttokenReward=e.reward,v.w.Inst_Get().OpenFightTokenReward()}SM_AngelBlessVipHandler(){w.M.Inst_get().HandleBrokenEffect()}SMMoneyPrayHandler(e){
v.w.Inst_Get().SMMoneyPrayHandler(e.prayCoinTime)}SMExpPrayHandler(e){v.w.Inst_Get().SMExpPrayHandler(e.prayExpTime,e.firstPrayExp)}SMPrayBigRewardHandler(e){
v.w.Inst_Get().SMPrayBigRewardHandler()}SendGetLevelReward(e){const t=new T.j
t.id=e,p.C.Inst.F_SendMsg(t)}SM_LevelRewardInfohandle(e){v.w.Inst_Get().prayModel.SetLevelRewardInfo(e)}SM_LevelRewardConfigHandle(e){
v.w.Inst_Get().prayModel.SetLevelRewardConfig(e)}SM_FightTokenInfoHandler(e){L.c.Inst_Get().high=e.high,L.c.Inst_Get().fightTokenVoMap=e.fightTokenVoMap,
L.c.Inst_Get().HandleInfo(e.high,e.fightTokenVoMap),L.c.Inst_Get().RaiseEvent(L.c.FightToken_Update)}SM_BrokeAdvEffect(){L.c.Inst_Get().HandleBrokenEffect()}
SM_RewardFightTokenHandler(e){L.c.Inst_Get().HandleUpdate(e.update),v.w.Inst_Get().fighttoken=e.update,v.w.Inst_Get().fighttokenReward=e.reward,
v.w.Inst_Get().OpenFightTokenReward()}CM_RewardFightToken(e,t){const i=new S.E
i.type=t,i.id=e,p.C.Inst.F_SendMsg(i)}CM_RewardAngelFightToken(e,t){const i=new I.t
i.high=t,i.id=e,p.C.Inst.F_SendMsg(i)}SM_DailyRechargeInfoHander(e){console.log("SM_DailyRechargeInfoHander"),g.i.Inst_Get().DailyRechargeInfoSet(e)}SM_RedPacketInfoHandle(e){
console.log("SM_RedPacketInfoHandle"),v.w.Inst_Get().prayModel.SetRedPacketInfo(e)}SendCM_OpenRedPacket(e){null==e&&(e=!1)
const t=new E.v
t.extra=e,p.C.Inst.F_SendMsg(t)}SendCM_DailyTotalRechargeReward(e){const t=new C.P
t.resourceId=e,p.C.Inst.F_SendMsg(t)}SM_DailyTotalRechargeInfoHandle(e){v.w.Inst_Get().prayModel.UpdateTotalRechargeInfo(e)}SM_DailyTotalRechargeSuccessHandle(e){
v.w.Inst_Get().prayModel.SM_DailyTotalRechargeSuccessHandle(e)}Test1(){return!0}S_Test(){return!0}},c._inst=void 0,O(h=c,"inst",[d.Vx],Object.getOwnPropertyDescriptor(h,"inst"),h),
O(h.prototype,"SM_LevelRewardInfohandle",[n],Object.getOwnPropertyDescriptor(h.prototype,"SM_LevelRewardInfohandle"),h.prototype),
O(h.prototype,"SM_LevelRewardConfigHandle",[s],Object.getOwnPropertyDescriptor(h.prototype,"SM_LevelRewardConfigHandle"),h.prototype),
O(h.prototype,"SM_FightTokenInfoHandler",[a],Object.getOwnPropertyDescriptor(h.prototype,"SM_FightTokenInfoHandler"),h.prototype),
O(h.prototype,"SM_BrokeAdvEffect",[r],Object.getOwnPropertyDescriptor(h.prototype,"SM_BrokeAdvEffect"),h.prototype),
O(h.prototype,"SM_RewardFightTokenHandler",[l],Object.getOwnPropertyDescriptor(h.prototype,"SM_RewardFightTokenHandler"),h.prototype),
O(h.prototype,"SM_DailyRechargeInfoHander",[o],Object.getOwnPropertyDescriptor(h.prototype,"SM_DailyRechargeInfoHander"),h.prototype),
O(h.prototype,"SM_RedPacketInfoHandle",[_],Object.getOwnPropertyDescriptor(h.prototype,"SM_RedPacketInfoHandle"),h.prototype),
O(h.prototype,"SM_DailyTotalRechargeInfoHandle",[u],Object.getOwnPropertyDescriptor(h.prototype,"SM_DailyTotalRechargeInfoHandle"),h.prototype),h)},79475:(e,t,i)=>{"use strict"
i.d(t,{W:()=>n})
class n{}n.FreeTime=1,n.CostTime=2,n.CostOver=3},92721:(e,t,i)=>{"use strict"
i.d(t,{M:()=>I})
var n=i(93984),s=i(38836),a=i(16812),r=i(55360),l=i(85602),o=i(38962),_=i(21729),u=i(63076),h=i(14792),c=i(62734),d=i(65550),m=i(74657),p=i(13224),g=i(13671)
class I extends a.k{constructor(){super(),this.cfgList=null,this.high=!1,this.totalExp=0,this.startTime=0,this.fightTokenVoMap=null,this.csvMap=null,this.cfgList=new l.Z,
this.InitCfg()}static Inst_get(){return null==I.Inst&&(I.Inst=new I),I.Inst}InitCfg(){if(null==this.csvMap){const e=r.Y.Inst.GetOrCreateCsv(n.h.eAngelresource)
this.csvMap=e.GetCsvMap()
for(const[e,t]of(0,s.vy)(this.csvMap))this.cfgList.Add(t)
this.cfgList.Sort(this.CreateDelegate(this.SortAngelFightToken))}}SortAngelFightToken(e,t){return e.exp-t.exp}GetProgress(){const e=new l.Z,t=this.cfgList.Count()
for(let i=0;i<=t-1;i++)e.Add(this.cfgList[i].exp)
return e}HandleInfo(e,t,i,n){this.high=e,this.fightTokenVoMap=t,this.totalExp=i.ToNum(),this.startTime=_.N.Floor(.001*n.ToNum())
const s=this.HaveReward()
c.f.Inst.SetState(h.t.ANGEL_FIGHT_TOKEN,s)}HandleUpdate(e){this.fightTokenVoMap.LuaDic_AddOrSetItem(e.id,e),this.RaiseEvent(I.SINGLE_UPDATE,e)
const t=this.HaveReward()
c.f.Inst.SetState(h.t.ANGEL_FIGHT_TOKEN,t)}HaveReward(){if(null!=this.fightTokenVoMap){for(const[e,t]of(0,s.vy)(this.cfgList))if(this.CanGetReward(t.id))return!0
return!1}}GetRewardList(){const e=new l.Z,t=this.cfgList.Count()
for(let i=0;i<=t-1;i++){let t=null
t=this.GetPassRewardItemData(this.cfgList[i],this.cfgList[i].rewards,!0),e.Add(t)}return e}GetAdvRewardList(){const e=new l.Z
let t=null
const i=this.cfgList.Count()
for(let n=0;n<=i-1;n++)t=this.GetPassRewardItemData(this.cfgList[n],this.cfgList[n].advancedRewards,!1),e.Add(t)
return e}GetTotalNum(){return this.totalExp}GetIntegerProgress(){let e=this.GetHaveRewardLevel()
0==e&&(e=this.GetTotalNum())
let t=0
const i=this.cfgList.Count()
let n=0,s=!1
for(let a=0;a<=i-1;a++)this.cfgList[a].exp<=e&&(s=!0,t=this.cfgList[a].exp<e?a+1:a,n=this.cfgList[a].exp)
return t+=(e-n)/this.cfgList[t].exp,t}GetPassRewardItemData(e,t,i){const n=m.A.GetReward(t)
if(null==n)return void d.y.inst.ClientStrMsg(null,`reward表里没配angel表里id：${e.id}奖励字段`)
const s=n.GetAllRewardList(),a=new g.J
a.id=e.id,a.type=p.w.Angel_Fight_Token
const r=this.fightTokenVoMap.LuaDic_GetItem(e.id)
return r?(a.geted=i?r.normalReward:r.highReward,a.showmask=!1):e.exp>this.GetTotalNum()?(a.geted=!1,a.showmask=!0):(a.geted=!1,a.showmask=!1),a.normal=i,s[0].showNum=!0,
a.item=s[0],s.Count()>1?(s[1].showNum=!0,a.item2=s[1]):a.item2=null,a.lock=!i&&!this.high,a}GetProgressPercent(){const e=this.GetTotalNum()
let t=0
const i=this.cfgList.Count()
let n=0,s=0
for(let a=0;a<=i-1;a++){if(!(this.cfgList[a].exp<=e)){s=this.cfgList[a].exp
break}t=a+1,n=this.cfgList[a].exp,s=n}return s>n&&(t+=(e-n)/(s-n)),t<0&&(t=0),t}GetTotalAdvanceList(){const e=new o.X
for(const[t,i]of(0,s.vy)(this.cfgList)){const t=m.A.GetReward(i.advancedRewards).GetAllRewardList()
for(let i=0;i<=t.Count()-1;i++){const n=t[i].modelId_get()
if(e.LuaDic_ContainsKey(n))e[n].count=e[n].count+t[i].count
else{const s=new u.M(n)
s.count=t[i].count,e.LuaDic_Add(n,s)}}}const t=new l.Z
for(const[i,n]of(0,s.vy)(e))n.SpecialNumStr=n.count,t.Add(n)
return t}GetCurAdvanceList(){const e=new o.X
for(const[t,i]of(0,s.vy)(this.cfgList))if(this.CanGetHighReward(i.id)){const t=m.A.GetReward(i.advancedRewards).GetAllRewardList()
for(let i=0;i<=t.Count()-1;i++){const n=t[i].modelId_get()
if(e.LuaDic_ContainsKey(n))e[n].count=e[n].count+t[i].count
else{const s=new u.M(n)
s.count=t[i].count,e.LuaDic_Add(n,s)}}}const t=new l.Z
for(const[i,n]of(0,s.vy)(e))n.SpecialNumStr=n.count,t.Add(n)
return t}CanGetHighReward(e){const t=this.fightTokenVoMap.LuaDic_GetItem(e)
return this.GetTotalNum()>=this.GetCfg(e).exp&&null==t||null!=t&&0==t.highReward}CanGetReward(e){const t=this.fightTokenVoMap.LuaDic_GetItem(e)
return!!(this.GetTotalNum()>=this.GetCfg(e).exp&&null==t||null!=t&&(this.high&&0==t.highReward||0==t.normalReward))}RefreshFightTokenData(e){
const t=this.fightTokenVoMap.LuaDic_GetItem(e.id)
if(t)e.normal?e.geted=t.normalReward:e.geted=t.highReward,e.showmask=!1
else{this.GetCfg(e.id).exp>this.GetTotalNum()?(e.geted=!1,e.showmask=!0):(e.geted=!1,e.showmask=!1)}e.normal?e.lock=!1:e.lock=!this.high}GetHaveRewardLevel(){
const e=this.cfgList.Count()
let t=null
for(let i=0;i<=e-1;i++){t=this.cfgList[i]
const e=this.fightTokenVoMap.LuaDic_GetItem(t.id)
let n=!1
if(null==e?this.GetTotalNum()>=t.exp&&(n=!0):(!this.high||e.highReward&&e.normalReward)&&e.normalReward||(n=!0),n)return t.exp}return 0}GetCfg(e){for(const[t,i]of(0,
s.vy)(this.cfgList))if(i.id==e)return i}GetProgressActive(e){return e<=this.GetTotalNum()}HandleBrokenEffect(){this.RaiseEvent(I.BrokenEffect)}Test1(){return!0}S_Test(){return!0}}
I.BrokenEffect="BrokenEffect",I.FightToken_Update="FightToken_Update",I.SINGLE_UPDATE="SINGLE_UPDATE",I.GET_REWARD="GET_REWARD",I.Inst=null},11134:(e,t,i)=>{"use strict"
i.d(t,{c:()=>g})
var n=i(93984),s=i(38836),a=i(16812),r=i(55360),l=i(85602),o=i(38962),_=i(63076),u=i(21267),h=i(14792),c=i(62734),d=i(65550),m=i(74657),p=i(13671)
class g extends a.k{constructor(){super(),this.high=!1,this.fightTokenVoMap=null,this.csvMap=null,this.fightTokenLevel=0,this.cfgList=null,this.cfgList=new l.Z,this.InitCfg()}
static Inst_Get(){return null==g.Inst&&(g.Inst=new g),g.Inst}InitCfg(){if(null==this.csvMap){const e=r.Y.Inst.GetOrCreateCsv(n.h.ePassResouceCsv)
this.csvMap=e.GetCsvMap()
for(const[e,t]of(0,s.vy)(this.csvMap))this.cfgList.Add(t)
this.cfgList.Sort(this.CreateDelegate(this.SortFightToken))}this.AddEventHandler(g.Passnum_Update,this.CreateDelegate(this.PassnumUpdateHandler))}PassnumUpdateHandler(){
const e=this.HaveReward()
c.f.Inst.SetState(h.t.WEL_PASS_REWARD,e),this.RaiseEvent(g.FightToken_Update)}GetProgress(){const e=new l.Z,t=this.cfgList.Count()
for(let i=0;i<=t-1;i++)e.Add(this.cfgList[i].needCertificateExp)
return e}SortFightToken(e,t){return e.needCertificateExp>t.needCertificateExp?1:e.needCertificateExp<t.needCertificateExp?-1:0}GetRewardList(){
const e=new l.Z,t=this.cfgList.Count()
for(let i=0;i<=t-1;i++){let t=null
t=this.GetPassRewardItemData(this.cfgList[i],this.cfgList[i].rewards,!0),e.Add(t)}return e}GetAdvRewardList(){const e=new l.Z
let t=null
const i=this.cfgList.Count()
for(let n=0;n<=i-1;n++)t=this.GetPassRewardItemData(this.cfgList[n],this.cfgList[n].advancedRewards,!1),e.Add(t)
return e}GetPassRewardItemData(e,t,i){const n=m.A.GetReward(t)
if(null==n)return void d.y.inst.ClientStrMsg(null,`reward表里没配pass表里id：${e.id}奖励字段`)
const s=n.GetAllRewardList(),a=new p.J
a.id=e.id
const r=this.fightTokenVoMap.LuaDic_GetItem(e.id)
return r?(a.geted=i?r.normalReward:r.highReward,a.showmask=!1):e.needCertificateExp>u.u.Inst().totalPassNum?(a.geted=!1,a.showmask=!0):(a.geted=!1,a.showmask=!1),a.normal=i,
s[0].showNum=!0,s[0].num=s[0].count,a.item=s[0],a.lock=!i&&!this.high,a}RefreshFightTokenData(e){const t=this.fightTokenVoMap.LuaDic_GetItem(e.id)
if(t)e.normal?e.geted=t.normalReward:e.geted=t.highReward,e.showmask=!1
else{this.GetCfg(e.id).needCertificateExp>u.u.Inst().totalPassNum?(e.geted=!1,e.showmask=!0):(e.geted=!1,e.showmask=!1)}e.normal?e.lock=!1:e.lock=!this.high}HandleInfo(e,t){
this.high=e,this.fightTokenVoMap=t
const i=this.HaveReward()
c.f.Inst.SetState(h.t.WEL_PASS_REWARD,i)}HandleUpdate(e){this.fightTokenVoMap.LuaDic_AddOrSetItem(e.id,e),this.RaiseEvent(g.SINGLE_UPDATE,e)
const t=this.HaveReward()
c.f.Inst.SetState(h.t.WEL_PASS_REWARD,t)}HaveReward(){if(null!=this.fightTokenVoMap){for(const[e,t]of(0,s.vy)(this.cfgList))if(this.CanGetReward(t.id))return!0
return!1}}HaveHighReward(){if(null!=this.fightTokenVoMap){for(const[e,t]of(0,s.vy)(this.cfgList))if(this.CanGetHighReward(t.id))return!0
return!1}}GetCfg(e){for(const[t,i]of(0,s.vy)(this.cfgList))if(i.id==e)return i}GetTotalAdvanceList(){const e=new o.X
for(const[t,i]of(0,s.vy)(this.cfgList)){const t=m.A.GetReward(i.advancedRewards).GetAllRewardList()
for(let i=0;i<=t.Count()-1;i++){const n=t[i].modelId_get()
if(e.LuaDic_ContainsKey(n))e[n].count=e[n].count+t[i].count
else{const s=new _.M(n)
s.count=t[i].count,e.LuaDic_Add(n,s)}}}const t=new l.Z
for(const[i,n]of(0,s.vy)(e))n.SpecialNumStr=n.count,t.Add(n)
return t}GetCurAdvanceList(){const e=new o.X
for(const[t,i]of(0,s.vy)(this.cfgList))if(this.CanGetHighReward(i.id)){const t=m.A.GetReward(i.advancedRewards).GetAllRewardList()
for(let i=0;i<=t.Count()-1;i++){const n=t[i].modelId_get()
if(e.LuaDic_ContainsKey(n))e[n].count=e[n].count+t[i].count
else{const s=new _.M(n)
s.count=t[i].count,e.LuaDic_Add(n,s)}}}const t=new l.Z
for(const[i,n]of(0,s.vy)(e))n.SpecialNumStr=n.count,t.Add(n)
return t}CanGetHighReward(e){const t=this.fightTokenVoMap.LuaDic_GetItem(e)
return u.u.Inst().totalPassNum>=this.GetCfg(e).needCertificateExp&&null==t||null!=t&&0==t.highReward}CanGetReward(e){const t=this.fightTokenVoMap.LuaDic_GetItem(e)
return!!(u.u.Inst().totalPassNum>=this.GetCfg(e).needCertificateExp&&null==t||null!=t&&(this.high&&0==t.highReward||0==t.normalReward))}HaveNoGainLevel(e){
const t=u.u.Inst().totalPassNum
for(const[i,n]of(0,s.vy)(this.cfgList))if(n.needCertificateExp>e&&n.needCertificateExp<=t)return!0
return!1}GetProgressPercent(){const e=u.u.Inst().totalPassNum
let t=0
const i=this.cfgList.Count()
let n=0,s=0
for(let a=0;a<=i-1;a++){if(!(this.cfgList[a].needCertificateExp<=e)){s=this.cfgList[a].needCertificateExp
break}t=a+1,n=this.cfgList[a].needCertificateExp,s=n}return s>n&&(t+=(e-n)/(s-n)),t<0&&(t=0),t}GetIntegerProgress(){let e=this.GetHaveRewardLevel()
0==e&&(e=u.u.Inst().totalPassNum)
let t=0
const i=this.cfgList.Count()
let n=0
for(let s=0;s<=i-1;s++)this.cfgList[s].needCertificateExp<=e&&(t=this.cfgList[s].needCertificateExp<e?s+1:s,n=this.cfgList[s].needCertificateExp)
return t}GetHaveRewardLevel(){const e=this.cfgList.Count()
let t=null
for(let i=0;i<=e-1;i++){t=this.cfgList[i]
const e=this.fightTokenVoMap.LuaDic_GetItem(t.id)
let n=!1
if(null==e?u.u.Inst().totalPassNum>=t.needCertificateExp&&(n=!0):(!this.high||e.highReward&&e.normalReward)&&e.normalReward||(n=!0),n)return t.needCertificateExp}return 0}
GetProgressActive(e){return e<=u.u.Inst().totalPassNum}HandleBrokenEffect(){this.RaiseEvent(g.BrokenEffect)}Test1(){return!0}S_Test(){return!0}}
g.FightToken_Update="FightToken_Update",g.Passnum_Update="Passnum_Update",g.RECHARGE="RECHARGE",g.GET_REWARD="GET_REWARD",g.SINGLE_UPDATE="SINGLE_UPDATE",
g.BrokenEffect="BrokenEffect",g.Inst=null},13671:(e,t,i)=>{"use strict"
i.d(t,{J:()=>n})
class n{constructor(){this.lock=!1,this.showmask=!1,this.item=null,this.geted=!1,this.normal=!0,this.id=0,this.type=0,this.item2=null}Test1(){return!0}S_Test(){return!0}}},
80460:(e,t,i)=>{"use strict"
i.d(t,{r:()=>D})
var n=i(93984),s=i(77546),a=i(38836),r=i(38045),l=i(98800),o=i(97461),_=i(68662),u=i(16812),h=i(55360),c=i(98885),d=i(85602),m=i(38962),p=i(92679),g=i(37648),I=i(55492),E=i(3435),C=i(4014),S=i(10509),T=i(14792),f=i(62734),A=i(6212),y=i(13224),R=i(79475)
class D extends u.k{constructor(){super(),this.moneyTimes=0,this.expTimes=0,this.moneyFreeTime=!1,this.expFreeTime=!1,this.maxMoneyTimes=0,this.maxExpTimes=0,
this.levelRewardList=null,this.levelRewardMap=null,this.levelRewardByLevel=null,this.idLevelRewardState=null,this.idLevelRewardNum=null,this.redPacketInfo=null,
this.firstPrayExp=!1,this.openRedPack=null,this.hasGetRechargeDic=null,this.dailyRechargeInfo=null,h.Y.Inst.GetOrCreateCsv(n.h.ePrayResource),this.levelRewardList=new d.Z,
this.levelRewardMap=new m.X,this.levelRewardByLevel=new m.X,this.idLevelRewardState=new m.X,this.idLevelRewardNum=new m.X}GetExpStatus(){
return 0==this.GetExpPrayCost()?R.W.FreeTime:this.expTimes>=this.maxExpTimes?R.W.CostOver:R.W.CostTime}GetMoneyStatus(){
return 0==this.GetMoneyPrayCost()?R.W.FreeTime:this.moneyTimes>=this.maxMoneyTimes?R.W.CostOver:R.W.CostTime}GetMoneyBenifit(){
const e=l.Y.Inst.m_primaryRoleInfo.Level_get(),t=E.E.GetInstance().GenGetCfgByLevel(e)
return(0,r.aI)(this.GetCost(t.prayGold,this.moneyTimes+1))}GetExpBenift(){const e=l.Y.Inst.m_primaryRoleInfo.Level_get(),t=E.E.GetInstance().GenGetCfgByLevel(e)
return(0,r.aI)(S.L.Inst().getItemById(e).rexp*t.prayExp)}GetExpPrayCost(){
const e=l.Y.Inst.m_primaryRoleInfo.Level_get(),t=E.E.GetInstance().GenGetCfgByLevel(e),i=this.GetCost(t.prayExpCost,this.expTimes+1)
return(0,r.aI)(i)}GetMoneyPrayCost(){const e=l.Y.Inst.m_primaryRoleInfo.Level_get(),t=E.E.GetInstance().GenGetCfgByLevel(e)
if(null==t)return 0
const i=this.GetCost(t.prayGoldCost,this.moneyTimes+1)
return(0,r.aI)(i)}GetCost(e,t){e=c.M.SubStringWithEnd(e,1,c.M.Length(e)-1)
const i=c.M.Split(e,",")
let n=0
const s=i.Count()
for(;n<s;){const e=c.M.SubStringWithEnd(i[n],1,c.M.Length(i[n])-1),s=c.M.Split(e,"_")
if((0,r.aI)(s[0])==t||n==i.Count()-1)return(0,r.aI)(s[1])
n+=1}return 0}HandleRedPoint(){0==this.GetMoneyPrayCost()||0==this.GetExpPrayCost()?f.f.Inst.SetState(T.t.PRAY,!0):f.f.Inst.SetState(T.t.PRAY,!1)}SetMaxTimes(){
h.Y.Inst.GetOrCreateCsv(n.h.eVipResource)
const e=l.Y.Inst.PrimaryRoleInfo_get().VipLevel_get(),t=C.j.GetInstance().GenGetCfgByLevel(e)
this.maxExpTimes=t.expPrayTimes,this.maxMoneyTimes=t.goldPrayTimes}ResetModel(){this.SetMaxTimes(),this.idLevelRewardState=new m.X,this.idLevelRewardNum=new m.X,
this.openRedPack=!1,this.redPacketInfo=null,this.ResetDailyTotalRechargeInfo()}SetLevelRewardConfig(e){if(this.levelRewardList=e.levelRewardVoList,
null!=e.levelRewardVoList)for(let t=0;t<=e.levelRewardVoList.Count()-1;t++){const i=e.levelRewardVoList[t],n=i.id,s=i.level
this.levelRewardMap.LuaDic_AddOrSetItem(n,i),this.levelRewardByLevel.LuaDic_AddOrSetItem(s,i)}}SetLevelRewardInfo(e){
const t=l.Y.Inst.PrimaryRoleInfo_get().Level_get(),i=l.Y.Inst.PrimaryRoleInfo_get().VipLevel_get()
for(const[t,i]of(0,a.vy)(e.serverProgress)){const e=t,n=this.levelRewardMap[e]
null!=n&&(n.limit>0&&n.limit<=i&&this.idLevelRewardState.LuaDic_AddOrSetItem(e,3),i>n.limit&&(i=n.limit),s.s.Info(`id${e}数量${i}`),this.idLevelRewardNum.LuaDic_AddOrSetItem(e,i))}
if(null!=e.accountRewardRecode)for(const[n,s]of(0,a.vy)(e.accountRewardRecode)){const e=this.levelRewardByLevel[n]
if(null!=e){const n=e.id,a=this.idLevelRewardState[n]
2==s?this.idLevelRewardState.LuaDic_AddOrSetItem(n,2):t>=e.level?1==s?i>=e.vipLevel?this.idLevelRewardState.LuaDic_AddOrSetItem(n,5):this.idLevelRewardState.LuaDic_AddOrSetItem(n,4):3!=a&&this.idLevelRewardState.LuaDic_AddOrSetItem(n,1):3!=a&&this.idLevelRewardState.LuaDic_AddOrSetItem(n,0)
}}this.InitLevelRewardState(),this.RefreshRedPointState(),o.i.Inst.RaiseEvent(p.g.LEVELREWARDINFO_UPDATE)}InitLevelRewardState(){
const e=l.Y.Inst.PrimaryRoleInfo_get().Level_get(),t=(l.Y.Inst.PrimaryRoleInfo_get().VipLevel_get(),this.levelRewardMap)
for(const[i,n]of(0,a.vy)(t)){const n=this.idLevelRewardState[i]
if(null==n||0==n){e>=t[i].level?this.idLevelRewardState.LuaDic_AddOrSetItem(i,1):this.idLevelRewardState.LuaDic_AddOrSetItem(i,0)}}}LevelChangeHandle(){
const e=l.Y.Inst.PrimaryRoleInfo_get().Level_get(),t=l.Y.Inst.PrimaryRoleInfo_get().VipLevel_get()
if(null!=this.levelRewardMap&&this.levelRewardMap.LuaDic_Count()>0){for(const[i,n]of(0,a.vy)(this.idLevelRewardState)){const n=this.idLevelRewardState[i]
if(3!=n&&2!=n){const s=this.levelRewardMap[i]
e>=s.level?4==n||5==n?t>=s.vipLevel?this.idLevelRewardState.LuaDic_AddOrSetItem(i,5):this.idLevelRewardState.LuaDic_AddOrSetItem(i,4):this.idLevelRewardState.LuaDic_AddOrSetItem(i,1):this.idLevelRewardState.LuaDic_AddOrSetItem(i,0)
}}this.RefreshRedPointState(),o.i.Inst.RaiseEvent(p.g.LEVELREWARDINFO_UPDATE)}}RefreshRedPointState(){let e=!1
for(const[t,i]of(0,a.vy)(this.idLevelRewardState))if(1==i||5==i){e=!0
break}f.f.Inst.SetState(T.t.LEVEL_REWARD,e)}SetRedPacketInfo(e){let t=0
this.openRedPack=!1,null!=this.redPacketInfo&&e.openPacket&&(t=1,this.openRedPack=!0),this.redPacketInfo=e,o.i.Inst.RaiseEvent(p.g.UPDATE_REDPACKET_DAILY,t)}CheckRedPackRedPoint(){
let e=!1
return null!=this.redPacketInfo&&g.P.Inst_get().IsFunctionOpened(I.x.DAILY_RED_PACKET)&&(this.CanOpenRedPacket()||this.redPacketInfo.extraDiamond>0&&this.redPacketInfo.rechargeToday)&&(e=!0),
e}IsInOpenRedPack(){return!(null==y.w.Inst_Get().dailyRedPacket||!y.w.Inst_Get().dailyRedPacket.node.activeSelf())&&this.openRedPack}CanOpenRedPacket(){
return null!=this.redPacketInfo&&this.redPacketInfo.leftTime>0&&this.redPacketInfo.nextTime.ToNum()<=_.D.serverTime_get()}SM_DailyTotalRechargeSuccessHandle(e){
null==this.hasGetRechargeDic&&(this.hasGetRechargeDic=new m.X),this.hasGetRechargeDic[e.rewardIds]=!0,this.RefreshDailyTotalRechargeRedPoint(),
o.i.Inst.RaiseEvent(p.g.UPDATE_GET_SUCCESS,e.rewardIds)}UpdateTotalRechargeInfo(e){if(this.ResetDailyTotalRechargeInfo(),this.dailyRechargeInfo=e,
null!=this.dailyRechargeInfo.hasRewardIds)for(let e=0;e<=this.dailyRechargeInfo.hasRewardIds.Count()-1;e++){const t=this.dailyRechargeInfo.hasRewardIds[e]
this.hasGetRechargeDic[t]=!0}this.RefreshDailyTotalRechargeRedPoint(),o.i.Inst.RaiseEvent(p.g.UPDATE_DAILYACCULUMN_INFO,e.hasRewardIds)}ResetDailyTotalRechargeInfo(){
null==this.hasGetRechargeDic?this.hasGetRechargeDic=new m.X:this.hasGetRechargeDic.Clear(),this.dailyRechargeInfo=null}RefreshDailyTotalRechargeRedPoint(){let e=!1
if(null!=this.dailyRechargeInfo&&g.P.Inst_get().IsFunctionOpened(I.x.DailyTotalRecharge)&&null!=this.dailyRechargeInfo.hasRewardIds&&null!=this.dailyRechargeInfo.allConfigResources)for(let t=0;t<=this.dailyRechargeInfo.allConfigResources.Count()-1;t++){
const i=this.dailyRechargeInfo.allConfigResources[t]
if(this.IsCanGetRechargeById(i)){e=!0
break}}f.f.Inst.SetState(T.t.DAILY_TOTAL_RECHARGE,e)}IsCanGetRechargeById(e){if(null!=this.hasGetRechargeDic&&null!=this.dailyRechargeInfo&&!this.hasGetRechargeDic[e]){
const t=A.K.Inst().dailyTotalRechargeMap[e]
if(null!=t&&t.currency<=this.dailyRechargeInfo.todayTotalRecharge.ToNum())return!0}return!1}Test1(){return!0}S_Test(){return!0}static Inst_Get(){
return null==D.Inst&&(D.Inst=new D),D.Inst}}D.Inst=null},56782:(e,t,i)=>{"use strict"
i.d(t,{$:()=>S})
var n,s,a=i(6847),r=i(83908),l=i(46282),o=i(61911),_=i(31222),u=i(5494),h=i(98885),c=i(75696),d=i(92679),m=i(52513),p=i(31896),g=i(63921),I=i(13224),E=i(92721),C=i(11134)
let S=(0,a.s_)(u.I.AdvanceFightTokenTip,l.Z.ui_welfara_advancefighttokentip).waitPrefab(l.Z.ui_baseitem).register()((s=class e extends((0,r.pA)(o.f)()){constructor(...e){
super(...e),this.type=0,this.labelTemplate=null}InitView(){super.InitView(),this.totalgrid.SetInitInfo("ui_baseitem",null,c.j),
this.totalgrid.OnReposition_set(this.CreateDelegate(this.OnTotalResposition)),this.curgrid.OnReposition_set(this.CreateDelegate(this.OnCurResposition)),
this.curgrid.SetInitInfo("ui_baseitem",null,c.j),this.labelTemplate="{0}元购买"}AddLis(){this.m_handlerMgr.AddClickEvent(this.btn,this.CreateDelegate(this.OnClickHandler)),
this.m_handlerMgr.AddClickEvent(this.closeMask,this.CreateDelegate(this.OnClose)),this.m_handlerMgr.AddEventMgr(d.g.ACCESS_ICON_CLICK,this.CreateDelegate(this.OnClose))}
RemoveLis(){this.m_handlerMgr.RemoveClickEvent(this.btn,this.CreateDelegate(this.OnClickHandler)),
this.m_handlerMgr.RemoveClickEvent(this.closeMask,this.CreateDelegate(this.OnClose)),this.m_handlerMgr.RemoveEventMgr(d.g.ACCESS_ICON_CLICK,this.CreateDelegate(this.OnClose))}
OnFullClick(){I.w.Inst_Get().CloseAdvFightTokenTip()}OnClickHandler(){const e=m.O.Inst().getConfig(this.GetChargeId())
p.t.inst.Buy(e),this.OnFullClick()}OnAddToScene(){this.AddLis(),this.type=I.w.Inst_Get().advTipType
const e=this.GetTotalAdvanceList()
this.totalgrid.data_set(e)
const t=this.GetCurAdvanceList()
this.curgrid.data_set(t),t.Count()>0?this.nowtips.SetActive(!0):this.nowtips.SetActive(!1),e.Count()>1&&(this.leftwing.SetLocalPositionXYZ(-115,39,0),
this.rightwing.SetLocalPositionXYZ(115,39,0))
const i=m.O.Inst().getConfig(this.GetChargeId()),n=m.O.Inst().GetCfgMoney(i)
this.btnlabel.textSet(h.M.Replace(this.labelTemplate,"{0}",n+"")),this.bg1.SetActive(this.type==I.w.Fight_Token),this.bg2.SetActive(this.type==I.w.Angel_Fight_Token)}
AdaptGrid2Count(e,t,i){let[n,s,a]=t.node.GetLocalPositionXYZ()
e>=3?(n=-90,i.SetContentPivot(g.F.eTopLeft)):(n=-37,i.SetContentPivot(g.F.eCenter)),t.node.SetLocalPositionXYZ(n,s,a)}OnCurResposition(){}OnTotalResposition(){}
GetTotalAdvanceList(){return this.type==I.w.Fight_Token?C.c.Inst_Get().GetTotalAdvanceList():this.type==I.w.Angel_Fight_Token?E.M.Inst_get().GetTotalAdvanceList():void 0}
GetCurAdvanceList(){return this.type==I.w.Fight_Token?C.c.Inst_Get().GetCurAdvanceList():this.type==I.w.Angel_Fight_Token?E.M.Inst_get().GetCurAdvanceList():void 0}GetChargeId(){
return this.type==I.w.Fight_Token?e.ChargeId:this.type==I.w.Angel_Fight_Token?e.Angel_ChargeId:void 0}OnClose(){_.N.inst.CloseById(u.I.AdvanceFightTokenTip)}Test1(){return!0}
S_Test(){return!0}},s.ChargeId=202,s.Angel_ChargeId=203,n=s))||n},33665:(e,t,i)=>{"use strict"
i.d(t,{T:()=>p})
var n,s=i(6847),a=i(83908),r=i(46282),l=i(86133),o=i(5924),_=i(5494),u=i(98885),h=i(75439),c=i(65550),d=i(71893),m=i(13224)
let p=(0,s.s_)(_.I.CDKeyView,r.Z.ui_welfara_cdkeyview).register()(n=class extends((0,a.Ri)()){constructor(...e){super(...e),this.model=null,this.cdTime=0,this.timeId=-1,
this.startValue=null,this.configTime=null}_initBinder(){super._initBinder(),this.model=d.u.Inst_get()}InitView(){super.InitView(),this.startValue=this.input.GetText()}
OnAddToScene(){this.UpdateView(),this.m_handlerMgr.AddClickEvent(this.exchangeBtn,this.CreateDelegate(this.OnBtnClick)),
this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.OnClose)),this.node.SetActive(!0),this.RegUIShow()}RegUIShow(){}UnRegUIShow(e){}RegGuide(){}UnRegGuide(){}
LoopTime(){this.cdTime-=1,this.cdTime<=0&&this.ClearTime()}ClearTime(){o.C.Inst_get().ClearInterval(this.timeId),this.timeId=-1,this.cdTime=0}OnBtnClick(){if(this.cdTime<=0){
const e=this.input.GetText()
u.M.IsNullOrEmpty(e)||e==this.startValue||(m.w.Inst_Get().SendCDKeyMsg(e),this.ClearTime(),this.cdTime=this.configTime/1e3,
this.timeId=o.C.Inst_get().SetInterval(this.CreateDelegate(this.LoopTime),1e3))}else c.y.inst.ClientStrMsg(null,(0,l.T)("您点的太快啦"))}UpdateView(){
this.configTime=u.M.String2Int(h.D.getInstance().getContent("CDKEY:CD").getContent().stringVal)
const e=u.M.String2Int(h.D.getInstance().getContent("CDKEY_MAX").getContent().stringVal)
this.input.maxLength=e}OnClose(){m.w.Inst_Get().CloseCDKeyView()}Clear(){this.m_handlerMgr.RemoveClickEvent(this.exchangeBtn,this.CreateDelegate(this.OnBtnClick)),
this.m_handlerMgr.RemoveClickEvent(this.closeBtn,this.CreateDelegate(this.OnClose)),this.ClearTime(),this.node.SetActive(!1),super.Clear()}Destroy(){super.Destroy()}})||n},
12826:(e,t,i)=>{"use strict"
i.d(t,{M:()=>C})
var n=i(83908),s=i(97461),a=i(50089),r=i(68662),l=i(5924),o=i(60130),_=i(34334),u=i(92679),h=i(74045),c=i(49067),d=i(87923),m=i(86209),p=i(31896),g=i(19519),I=i(13224),E=i(80460)
class C extends((0,n.Ri)()){constructor(...e){super(...e),this.info=null,this.isAnim=null,this.intervalId=null,this.countDownTimer=null}SetData(){this.isAnim=!1,
this.info=E.r.Inst_Get().redPacketInfo,this.AddLis(),null!=this.info&&(this.RefreshEndTime(),this.UpdateInfo())}InitView(){}Clear(){E.r.Inst_Get().openRedPack=!1,
this.node.SetActive(!1),this.diamondEff.SetActive(!1),null!=this.intervalId&&l.C.Inst_get().ClearLoop(this.intervalId),this.RemoveLis(),this.ClearEndTimeHandle(),super.Clear()}
AddLis(){s.i.Inst.AddEventHandler(u.g.UPDATE_REDPACKET_DAILY,this.CreateDelegate(this.UpdateInfo)),this.AddClickEvent(this.getBtn.node,this.CreateDelegate(this.GetBtnHandle)),
this.AddClickEvent(this.openBtn.node,this.CreateDelegate(this.OpenBtnHandle))}RemoveLis(){
s.i.Inst.RemoveEventHandler(u.g.UPDATE_REDPACKET_DAILY,this.CreateDelegate(this.UpdateInfo))}EndAnimHandle(){this.isAnim=!1,
this.isAnim||(this.redGetNumTxt.textSet(this.info.thisTime.toString()),this.redDescTxt.SetActive(!0),this.hasOpen.SetActive(!0)),E.r.Inst_Get().openRedPack=!1,
m.w.Instance.diamondEffType=1,_.O.Inst().OpenDiamondGetEffect(g.J.GOLD_DIAMOND)}UpdateInfo(e){this.info=E.r.Inst_Get().redPacketInfo,null!=e&&1==e&&this.OpenRedPacketHandle(),
this.RefreshBtnState(),this.RefreshEndTime()
let t=`[5FB470]${this.info.leftTime}[-]个`
0==this.info.leftTime&&(t="无"),this.leftTimeTxt.textSet(`剩余个数:${t}`)}OpenRedPacketHandle(){this.isAnim=!0,this.EndAnimHandle()}GetBtnHandle(){
E.r.Inst_Get().redPacketInfo.openPacket=!1,
E.r.Inst_Get().openRedPack=!1,this.info.rechargeToday?this.info.extraDiamond>0&&I.w.Inst_Get().netHandler.SendCM_OpenRedPacket(!0):this.NoRechargeHandle()}OpenBtnHandle(){
E.r.Inst_Get().CanOpenRedPacket()&&I.w.Inst_Get().netHandler.SendCM_OpenRedPacket()}RefreshPanel(){}RefreshBtnState(){this.canOpenGo.SetActive(!1),this.hasOpen.SetActive(!1),
this.openBtn.node.SetActive(!1),this.getBtn.SetIsEnabled(!0),o.O.makeGoGray(this.getBtn.node,!1),this.getBtn.node.SetActive(!1),this.diamondTab.node.SetActive(!1),
this.redDescTxt.SetActive(!1),this.canGetDesc.SetActive(!1),this.extraDesc.SetActive(!1),E.r.Inst_Get().CanOpenRedPacket()?(this.canOpenGo.SetActive(!0),
this.openBtn.node.SetActive(!0)):(this.diamondEff.SetActive(!0),this.redGetNumTxt.textSet(`本次获得：${this.info.thisTime}`),this.redDescTxt.SetActive(!0),this.hasOpen.SetActive(!0),
this.info.thisTimeExtra>0&&(this.getDiamondNumTxt.node.SetActive(!0),this.getDiamondNumTxt.textSet(this.info.thisTimeExtra.toString()),this.diamondTab.node.SetActive(!0)),
this.info.extraDiamond>0&&(this.getDiamondNumTxt.node.SetActive(!0),this.getDiamondNumTxt.textSet(this.info.extraDiamond.toString()),this.diamondTab.node.SetActive(!0)),
this.extraDesc.SetActive(!0),this.info.rechargeToday?(this.getBtn.node.SetActive(!0),this.info.rewardExtra&&this.info.extraDiamond<=0?(o.O.makeGoGray(this.getBtn.node,!0),
this.getBtn.SetIsEnabled(!1),this.getBtn.SetText("已领取")):this.getBtn.SetText("立即领取")):(this.getBtn.node.SetActive(!0),this.getBtn.SetText("额外领取"))),
a.t.SetAllChildrenActive(this.getBtn.richText.node,!0)}NoRechargeHandle(){const e=new c.B
e.infoId="DAILYREDPACK:RECHARGE_NOTICE",e.confirmHandle=this.CreateDelegate(this.GoToRecharge),e.confirmText="前往充值",e.cancelText="取消",e.isShowMask=!0,
e.replaceParams.Add(this.info.extraDiamond),h.t.Inst().Open(e)}GoToRecharge(){p.t.inst.CommonRechargeHandle()}RefreshEndTime(){let e=0
null!=this.info&&null!=this.info.nextTime&&this.info.nextTime.ToNum()>0&&(e=this.info.nextTime.ToNum()-r.D.serverTime_get()),this.EndTimeCountDown(),
e>0?null==this.countDownTimer&&(this.countDownTimer=l.C.Inst_get().SetInterval(this.CreateDelegate(this.EndTimeCountDown),1e3,-1)):this.ClearEndTimeHandle()}EndTimeCountDown(){
let e=0,t=""
this.info=E.r.Inst_Get().redPacketInfo,null!=this.info&&null!=this.info.nextTime&&this.info.nextTime.ToNum()>0?(e=this.info.nextTime.ToNum()-r.D.serverTime_get(),
e>0?(t=d.l.GetDateFormatEX(e,!0),this.endTimeTxt.node.SetActive(!0),this.endTimeTxt.textSet(`（${t}后可再次开启）`)):(this.RefreshBtnState(),
this.ClearEndTimeHandle())):this.ClearEndTimeHandle()}ClearEndTimeHandle(){null!=this.countDownTimer&&(l.C.Inst_get().ClearInterval(this.countDownTimer),this.countDownTimer=null),
this.endTimeTxt.node.SetActive(!1)}Destroy(){}}},17366:(e,t,i)=>{"use strict"
i.d(t,{X:()=>f})
var n,s=i(18998),a=i(83908),r=i(17409),l=i(49655),o=i(57834),_=i(85602),u=i(87923),h=i(91897),c=i(37648),d=i(55492),m=i(11162),p=i(8211),g=i(7155),I=i(74657),E=i(6212),C=i(13224),S=i(80460)
class T extends((0,a.yk)()){constructor(...e){super(...e),this.data=null,this.index=0}InitView(){super.InitView()}Clear(){this.baseItem.Clear(),this.RemoveLis()}Destroy(){
super.destroy(),this.baseItem.destroy()}SetData(e){this.data=e,this.baseItem.SetData(this.data.itemData),this.hasGet.SetActive(!1),this.data.hasGet&&this.hasGet.SetActive(!0)}
AddLis(){}RemoveLis(){}}let f=s._decorator.ccclass("DailyTotalRechargeItem")(n=class extends((0,a.yk)()){constructor(...e){super(...e),this.data=null,this.rewardValues=null,
this.isGet=null,this.index=0}InitView(){this.grid.SetInitInfo("ui_welfare_dailytotalrecharge_baseitem",null,T)}Destroy(){this.grid.Destroy()}SetDepth(){}SetData(e){this.AddLis(),
this.data=e,this.UpdateInfo()}AddLis(){o.i.Get(this.getBtn.node).RegistonClick(this.CreateDelegate(this.OnGetBtnHandle)),
o.i.Get(this.goRechargeBtn.node).RegistonClick(this.CreateDelegate(this.OnGoRechargeHandle))}RemoveLis(){
o.i.Get(this.getBtn.node).RemoveonClick(this.CreateDelegate(this.OnGetBtnHandle)),o.i.Get(this.goRechargeBtn.node).RemoveonClick(this.CreateDelegate(this.OnGoRechargeHandle))}
OnGetBtnHandle(){C.w.Inst_Get().netHandler.SendCM_DailyTotalRechargeReward(this.data.id)}OnGoRechargeHandle(){
if(!g.o.Inst_get().isFristRecharge)return c.P.Inst_get().IsFunctionOpened(d.x.FIRST_CHARGE)?void h.v.Inst_get().OpenView():void u.l.SetFunctionTip(d.x.FIRST_CHARGE)
c.P.Inst_get().IsFunctionOpened(d.x.MALL)&&((0,r.Y)(l.o.MarketPanel_ry)?C.w.Inst_Get().CloseView():p.N.GetInst().CheckShopHasGoodsBuy(3,1)?m.O.Inst_get().Open(null,3,1):m.O.Inst_get().Open(null,2,1))
}UpdateInfo(){this.RefreshBtnState(),this.UpdateItemLis()}RefreshBtnState(){this.goRechargeBtn.node.SetActive(!1),this.getBtn.node.SetActive(!1),this.hasGet.SetActive(!1),
this.bg.node.SetActive(!0),this.isGet=!1
const e=S.r.Inst_Get().hasGetRechargeDic,t=S.r.Inst_Get().dailyRechargeInfo
if(null!=e&&null!=t){if(e[this.data.id])this.isGet=!0,this.hasGet.SetActive(!0),this.bg.node.SetActive(!1)
else{E.K.Inst().dailyTotalRechargeMap[this.data.id].currency<=t.todayTotalRecharge.ToNum()?this.getBtn.node.SetActive(!0):this.goRechargeBtn.node.SetActive(!0)}
let i=t.todayTotalRecharge.ToNum()
i>this.data.currency&&(i=this.data.currency),this.sliderTxt.textSet(`${i}/${this.data.currency}`),
i/this.data.currency>1?this.progressSlider.widthSet(142):this.progressSlider.widthSet(i/this.data.currency*142),this.desc.textSet(`累计充值${this.data.currency}元`)}}UpdateItemLis(){
if(""!=this.data.rewardId){const e=I.A.GetReward(this.data.rewardId)
if(null!=e){const t=e.GetAllRewardList(),i=new _.Z
for(let e=0;e<=t.Count()-1;e++){const n=t[e],s=this.isGet,a={}
a.itemData=n,a.hasGet=s,i.Add(a)}this.grid.data_set(i)}}}Clear(){this.grid.Clear(),this.RemoveLis(),this.data=null}})||n},27216:(e,t,i)=>{"use strict"
i.d(t,{z:()=>E})
var n=i(83908),s=i(97461),a=i(5924),r=i(18202),l=i(83540),o=i(85602),_=i(79534),u=i(21554),h=i(53905),c=i(92679),d=i(65772),m=i(74657),p=i(6212),g=i(80460),I=i(17366)
class E extends((0,n.Ri)()){constructor(...e){super(...e),this.info=null,this.show="",this.itemLis=null,this.itemIconLis=null,this.showItemDataLis=null,this.intervalId=null,
this.lis=null,this.animDelay=null,this.shouldChangeTimes=3,this.curTimes=0,this.itemYOffset=1}SetData(){this.itemLis=new o.Z([this.item1,this.item2,this.item3]),
this.itemIconLis=new o.Z([this.itemIcon1,this.itemIcon2,this.itemIcon3]),this.AddLis(),this.UpdateInfo()}AddLis(){
this.myGrid.OnReposition_set(this.CreateDelegate(this.UpdateScrollBar)),this.m_handlerMgr.AddClickEvent(this.tipBtn,this.CreateDelegate(this.TipBtnHandle))
for(let e=0;e<=this.itemIconLis.Count()-1;e++)this.m_handlerMgr.AddClickEvent(this.itemIconLis[e],this.CreateDelegate(this.ItemClickHandle))
this.animDelay=a.C.Inst_get().SetInterval((()=>{this.ChangeItemPos()})),s.i.Inst.AddEventHandler(c.g.UPDATE_DAILYACCULUMN_INFO,this.CreateDelegate(this.UpdateInfo)),
s.i.Inst.AddEventHandler(c.g.UPDATE_GET_SUCCESS,this.CreateDelegate(this.UpdateInfo))}ChangeItemPos(){}RemoveLis(){this.myGrid.OnReposition_set(null),
this.m_handlerMgr.RemoveClickEvent(this.tipBtn,this.CreateDelegate(this.TipBtnHandle))
for(let e=0;e<=this.itemIconLis.Count()-1;e++)this.m_handlerMgr.RemoveClickEvent(this.itemIconLis[e],this.CreateDelegate(this.ItemClickHandle))
s.i.Inst.RemoveEventHandler(c.g.UPDATE_DAILYACCULUMN_INFO,this.CreateDelegate(this.UpdateInfo)),
s.i.Inst.RemoveEventHandler(c.g.UPDATE_GET_SUCCESS,this.CreateDelegate(this.UpdateInfo))}ItemClickHandle(e){
for(let t=0;t<=this.itemIconLis.Count()-1;t++)e.target.name==this.itemIconLis[t].node.name&&u.J.Inst_get().ShowItemTip(this.showItemDataLis[t])}TipBtnHandle(){const e=new h.w
e.infoId="DAILY_TOTAL_RECHARGE:TIPS",e.width=402,e.position=new _.P(12,221,0),d.Q.Inst_get().Open(e)}UpdateScrollBar(){
null!=this.intervalId&&a.C.Inst_get().ClearLoop(this.intervalId),this.intervalId=a.C.Inst_get().SetFrameLoop(this.CreateDelegate(this.SetScrollBarValue),2,1),this.RepositionFun()}
UpdateInfo(){this.info=g.r.Inst.dailyRechargeInfo,null!=this.info&&(this.show="",this.UpdateItemLis(),this.UpdateLeftShowItem())}UpdateLeftShowItem(){
for(let e=0;e<=this.itemLis.Count()-1;e++)this.itemLis[e].SetActive(!1),this.itemIconLis[e].node.SetActive(!1)
if(""!=this.show){const e=m.A.GetReward(this.show)
if(null!=e){const t=e.GetAllRewardList()
this.showItemDataLis=t
for(let e=0;e<=t.Count()-1;e++){const i=t[e]
if(e<3){this.itemLis[e].SetActive(!0),this.itemIconLis[e].node.SetActive(!0)
const t=this.itemIconLis[e]
r.g.SetItemIcon(t,i.cfgData_get().icon,l.b.eItem,!1)}}}}}SetScrollBarValue(){}UpdateItemLis(){this.lis=new o.Z
const e=new o.Z
if(null!=this.info.allConfigResources)for(let t=0;t<=this.info.allConfigResources.Count()-1;t++){const i=this.info.allConfigResources[t],n=p.K.Inst().dailyTotalRechargeMap[i]
null!=n&&(g.r.Inst_Get().hasGetRechargeDic[n.id]?e.Add(n):this.lis.Add(n),""!=n.show&&(this.show=n.show))}this.lis.Sort(this.CreateDelegate(this.SortFunc)),
e.Sort(this.CreateDelegate(this.SortFunc)),this.lis.AddRange(e),this.myGrid.data_set(this.lis)}SortFunc(e,t){return e.currency-t.currency}InitView(){
this.myGrid.SetInitInfo("ui_welfare_dailytotalrecharge_item",null,I.X),this.myGrid.OnReposition_set(this.CreateDelegate(this.RepositionFun))}OnCreateItem(e){}RepositionFun(){
this.scrollView.ResetPosition()}Clear(){null!=this.intervalId&&a.C.Inst_get().ClearLoop(this.intervalId),this.node.SetActive(!1),this.myGrid.Clear(),this.RemoveLis(),super.Clear()}
Destroy(){super.destroy()}}},89675:(e,t,i)=>{"use strict"
i.d(t,{z:()=>C})
var n,s=i(6847),a=i(83908),r=i(46282),l=i(38045),o=i(61911),_=i(31222),u=i(5494),h=i(85602),c=i(63076),d=i(75696),m=i(14534),p=i(55355),g=i(13224),I=i(92721),E=i(11134)
let C=(0,s.s_)(u.I.FightTokenGetTipPanel,r.Z.ui_fighttoken_getreward_tippanel).register()(n=class extends((0,a.pA)(o.f)()){constructor(...e){super(...e),this.fighttoken=null,
this.angelfighttoken=null,this.type=null}InitView(){super.InitView(),this.type=0,this.grid.SetInitInfo("ui_baseitem",null,d.j),this.advgrid.SetInitInfo("ui_baseitem",null,d.j)}
OnAddToScene(){this.AddLis(),this.UpdateView()}UpdateView(){const e=g.w.Inst_Get().fighttoken
let t=null;(0,l.t2)(e,p.w)?(this.type=g.w.Fight_Token,t=E.c.Inst_Get().high,this.fighttoken=e):(0,l.t2)(e,m.Q)&&(this.type=g.w.Angel_Fight_Token,t=I.M.Inst_get().high,
this.angelfighttoken=e)
this.comfirmBtn.SetActive(!0),this.cancelbtn.SetActive(!1),this.advbtn.SetActive(!1),this.advarea.SetActive(!1),this.normalarea.SetLocalPositionXYZ(0,80,0)
const i=new h.Z,n=g.w.Inst_Get().fighttokenReward
if(null!=n){const e=n.rewards
for(let t=0;t<=e.count-1;t++){const n=c.M.wrapReward(e[t])
n.cfgData_get().CurrencyNum&&(n.count=n.cfgData_get().CurrencyNum),i.Add(n)}}this.grid.data_set(i)}Clear(){super.Clear(),g.w.Inst_Get().fighttokenReward=null,this.grid.Clear(),
this.RemoveLis()}AddLis(){this.m_handlerMgr.AddClickEvent(this.comfirmBtn,this.CreateDelegate(this.OnCloseBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.cancelbtn,this.CreateDelegate(this.OnCloseBtnHandle)),this.m_handlerMgr.AddClickEvent(this.advbtn,this.CreateDelegate(this.OnAdvbtnClick))}
RemoveLis(){this.m_handlerMgr.RemoveClickEvent(this.comfirmBtn,this.CreateDelegate(this.OnCloseBtnHandle)),
this.m_handlerMgr.RemoveClickEvent(this.cancelbtn,this.CreateDelegate(this.OnCloseBtnHandle)),
this.m_handlerMgr.RemoveClickEvent(this.advbtn,this.CreateDelegate(this.OnAdvbtnClick))}UpdateItemLis(){}OnCloseBtnHandle(){_.N.inst.CloseById(u.I.FightTokenGetTipPanel)}
OnAdvbtnClick(){g.w.Inst_Get().OpenAdvFightTokeTip(this.type)}})||n},50139:(e,t,i)=>{"use strict"
i.d(t,{B:()=>l})
var n,s=i(18998),a=i(34565),r=i(92679)
let l=s._decorator.ccclass("MonthCardView")(n=class extends a.I{constructor(...e){super(...e),this.cnode=null}InitView(){this.cnode=this.node.getCNode(),super.InitView(),
this.addlist()}RegUIShow(){}UnRegUIShow(e){}addlist(){this.m_handlerMgr.AddEventMgr(r.g.MONTHCARD_REWARD,this.CreateDelegate(this.SetData)),
this.m_handlerMgr.AddEventMgr(r.g.MONTHCARD_INFO,this.CreateDelegate(this.SetData))}removelist(){
this.m_handlerMgr.AddEventMgr(r.g.MONTHCARD_REWARD,this.CreateDelegate(this.SetData)),this.m_handlerMgr.AddEventMgr(r.g.MONTHCARD_INFO,this.CreateDelegate(this.SetData))}SetData(){
this.cnode.ui_monthcard_item1.SetData2(1,this.cnode.ui_monthcard_item1),this.cnode.ui_monthcard_item2.SetData2(2,this.cnode.ui_monthcard_item2)}Clear(){this.removelist(),
super.Clear()}})||n},78046:(e,t,i)=>{"use strict"
i.d(t,{W:()=>u})
var n,s=i(18998),a=i(83908),r=i(9057),l=i(13224),o=i(92721),_=i(11134)
let u=s._decorator.ccclass("PassRewardItem")(n=class extends((0,a.pA)(r.x)()){constructor(...e){super(...e),this.data=null,this.resPath="atlas/rongyaozhanling/"}AddLis(){
this.m_handlerMgr.AddClickEvent(this.boxcollider,this.CreateDelegate(this.OnClick)),_.c.Inst_Get().AddEventHandler(_.c.SINGLE_UPDATE,this.CreateDelegate(this.OnEventUpdate)),
this.m_handlerMgr.AddNotifyEvent(o.M.Inst_get(),o.M.SINGLE_UPDATE,this.CreateDelegate(this.OnAngelEventUpdate))}RemoveLis(){
_.c.Inst_Get().RemoveEventHandler(_.c.SINGLE_UPDATE,this.CreateDelegate(this.OnEventUpdate))}OnClick(){let e=null
e=this.data.type==l.w.Fight_Token?_.c.Inst_Get():o.M.Inst_get(),this.data.showmask||this.data.geted||!this.data.normal&&!e.high?INS.itemTipManager.OpenTipView(this.data.item):this.data.type==l.w.Fight_Token?_.c.Inst_Get().RaiseEvent(_.c.GET_REWARD,this.data):o.M.Inst_get().RaiseEvent(o.M.GET_REWARD,this.data)
}OnEventUpdate(e){e.id==this.data.id&&this.OnRefresh()}OnAngelEventUpdate(e){e.id==this.data.id&&this.OnRefresh()}SetData(e){this.AddLis(),this.data=e,
e.type==l.w.Fight_Token&&(e.normal?this.bg.spriteNameSet(this.resPath+"ryrongyaozhanling_sp003"):this.bg.spriteNameSet(this.resPath+"ryrongyaozhanling_sp004")),this.RefreshUI(),
this.item.EnabledClickOpenTip(!1)}OnRefresh(){
this.data.type==l.w.Fight_Token?_.c.Inst_Get().RefreshFightTokenData(this.data):this.data.type==l.w.Angel_Fight_Token&&o.M.Inst_get().RefreshFightTokenData(this.data),
this.RefreshUI()}RefreshUI(){this.mask.SetActive(this.data.showmask),this.lock.SetActive(this.data.lock),this.itemmask.SetActive(this.data.lock),this.item.SetData(this.data.item),
this.geted.SetActive(this.data.geted)}Clear(){this.RemoveLis(),super.Clear()}})||n},34067:(e,t,i)=>{"use strict"
i.d(t,{o:()=>f})
var n,s,a=i(18998),r=i(34565),l=i(93984),o=i(98958),_=i(5924),u=i(98885),h=i(85602),c=i(74045),d=i(49067),m=i(75439),p=i(21267),g=i(65550),I=i(62783),E=i(13224),C=i(11134),S=i(78046),T=i(6431)
let f=a._decorator.ccclass("PassRewardView")((s=class e extends r.I{constructor(...e){super(...e),this.tipshow=!1,this.times=0,this.diamands=0,this.curCfg=null,this.inited=null,
this.status_tmplate=null,this.model=null,this.scrollInterval=null,this.fighttokennum=null,this.cnode=null}InitView(){this.cnode=this.node.getCNode(),
this.cnode.cursor.SetActive(!1),this.cnode.grid.SetInitInfo("ui_welfara_passrewarditem",null,S.W),this.cnode.progressgrid.SetInitInfo("ui_welfara_passrewardprogressitem",null,T.I),
this.cnode.advancegrid.SetInitInfo("ui_welfara_passrewarditem",null,S.W),this.cnode.grid.OnReposition_set(this.CreateDelegate(this.OnReposition)),
this.cnode.advancegrid.OnReposition_set(this.CreateDelegate(this.OnAdvReposition)),this.inited=!1,this.InitCfg()}InitCfg(){
this.status_tmplate="关卡累计通关数量达标可领取（当前累计通关：[067A06]{0}[-]）",this.times=m.D.getInstance().GetIntValue("FIGHTTOKEN:TIMESNUM"),
this.diamands=m.D.getInstance().GetIntValue("FIGHTTOKEN:DIOMANDNUM"),this.cnode.tiplab.textSet(o.V.Inst().getStr(11012,l.h.eLangResource))}AddLis(){
this.m_handlerMgr.AddClickEvent(this.cnode.advancefighttoken,this.CreateDelegate(this.OnAdvClick)),
C.c.Inst_Get().AddEventHandler(C.c.FightToken_Update,this.CreateDelegate(this.OnFightTokenHandler)),
this.m_handlerMgr.AddClickEvent(this.cnode.onekeyreward,this.CreateDelegate(this.OnAdvClick)),C.c.Inst_Get().AddEventHandler(C.c.GET_REWARD,this.CreateDelegate(this.OnGetReward)),
this.m_handlerMgr.AddClickEvent(this.cnode.gotobtn,this.CreateDelegate(this.OnClickHandler)),C.c.Inst_Get().AddEventHandler(C.c.BrokenEffect,this.CreateDelegate(this.ShowEffect))}
RemoveLis(){C.c.Inst_Get().RemoveEventHandler(C.c.FightToken_Update,this.CreateDelegate(this.OnFightTokenHandler)),
C.c.Inst_Get().RemoveEventHandler(C.c.GET_REWARD,this.CreateDelegate(this.OnGetReward)),C.c.Inst_Get().RemoveEventHandler(C.c.BrokenEffect,this.CreateDelegate(this.ShowEffect))}
OnClickHandler(){I.X.inst.OpenMapPanel(I.X.WORD_MAP)}OnGetReward(e){if(e.showmask){const t=this.model.GetCfg(e.id)
g.y.inst.ClientSysMessage(11040905,new h.Z([t.needCertificateExp]))}else e.geted?g.y.inst.ClientSysMessage(11040904):E.w.Inst_Get().GetFightTokenReward(e.id,!e.normal)}
ShowHighNotice(){const e=new d.B
e.infoId="PASS:UNLOCK",e.confirmHandle=this.CreateDelegate(this.OnAdvClick),c.t.Inst().Open(e)}OnFightTokenHandler(){this.node&&(this.RefreshDes(),this.OnReposition(),
this.UpdateGrid())}OnAdvClick(){C.c.Inst_Get().high?g.y.inst.ClientSysMessage(11040906):E.w.Inst_Get().OpenAdvFightTokeTip()}OnReposition(){this.cnode.scrollview.ResetPosition()
const e=this.GetCurProgressItem()
if(null!=e){this.cnode.cursor.SetActive(!0)
const t=this.cnode.cursor.position
this.cnode.cursor.setPosition(e.node.position.x+this.cnode.grid.node.position.x-20,t.y,t.z)}else this.cnode.cursor.SetActive(!1)}GetCurProgressItem(){let e=null
for(let t=0;t<=this.cnode.grid.itemList.Count()-1;t++){const i=this.cnode.grid.itemList[t].data
if(this.model.GetCfg(i.id).needCertificateExp>p.u.Inst().totalPassNum){e=this.cnode.grid.itemList[t]
break}}return e}ShowEffect(){this.cnode.lock.SetActive(!1),this.cnode.effect.SetActive(!1),this.cnode.effect.SetActive(!0),this.cnode.borkeneffect.SetActive(!1),
this.cnode.borkeneffect.SetActive(!0),this.UpdateBtns()}UpdateView(){this.RefreshDes()
const t=this.GetProgress()
this.cnode.progressgrid.data_set(t)
const i=this.GetRewardList()
this.cnode.grid.data_set(i)
const n=this.GetAdvRewardList()
this.cnode.advancegrid.data_set(n),this.cnode.progressbg.widthSet(e.SingleLen*t.Count())
const s=this.GetLen()
this.cnode.progressfg.widthSet(s),this.cnode.diomandlab.textSet(this.diamands+""),this.cnode.timeslab.textSet(this.times+""),this.inited&&this.ScrollAct()
const a=this.IsEmpty()
this.cnode.progressfg.SetActive(!a),this.UpdateBtns()}ScrollAct(){const e=this.GetProgressPercent()
this.ClearScrollInteral(),this.cnode.scrollview.scrollToPercentHorizontal(e,.01,!1)}ClearScrollInteral(){
null!=this.scrollInterval&&(_.C.Inst_get().ClearInterval(this.scrollInterval),this.scrollInterval=null)}UpdateBtns(){
this.model.high?(this.cnode.gotobtn.node.SetLocalPositionXYZ(e.RIGHT_BTN_POS,e.BTN_POS_Y,0),
this.cnode.onekeyreward.SetActive(!1)):(this.cnode.gotobtn.node.SetLocalPositionXYZ(e.LEFT_BTN_POS,e.BTN_POS_Y,0),this.cnode.onekeyreward.SetActive(!0))}UpdateGrid(){
let e=this.cnode.progressgrid.itemList.Count()
for(let t=0;t<=e-1;t++)this.cnode.progressgrid.itemList[t].Refresh()
e=this.cnode.grid.itemList.Count()
for(let t=0;t<=e-1;t++)this.cnode.grid.itemList[t].OnRefresh()
e=this.cnode.advancegrid.itemList.Count()
for(let t=0;t<=e-1;t++)this.cnode.advancegrid.itemList[t].OnRefresh()
const t=this.GetLen()
this.cnode.progressfg.widthSet(t),this.cnode.progressfg.SetActive(!0)}RefreshDes(){const e=this.GetTotalNum(),t=u.M.Replace(this.status_tmplate,"{0}",e+"")
this.cnode.statuslab.textSet(t),this.model.high?this.cnode.lock.SetActive(!1):this.cnode.lock.SetActive(!0)}GetLen(){const t=this.model.GetProgressPercent()*e.SingleLen
return Math.floor(t)}IsEmpty(){return p.u.Inst().totalPassNum<=0}Clear(){this.RemoveLis()}SetData(){this.cnode||(this.cnode=this.node.getCNode()),this.AddLis(),
this.cnode.effect.SetActive(!1),this.cnode.borkeneffect.SetActive(!1),this.fighttokennum=0,this.tipshow=!1,this.AfterSetData(),this.UpdateView()}AfterSetData(){
this.model=C.c.Inst_Get()}GetProgress(){return this.model.GetProgress()}GetRewardList(){return this.model.GetRewardList()}GetAdvRewardList(){return this.model.GetAdvRewardList()}
GetTotalNum(){return p.u.Inst().totalPassNum}GetProgressPercent(){const e=this.model.cfgList.Count()
return this.model.GetIntegerProgress()/(e-6)}Destroy(){}OnGetRewardClick(){
C.c.Inst_Get().HaveReward()?E.w.Inst_Get().GetFightTokenReward():!C.c.Inst_Get().high&&C.c.Inst_Get().HaveHighReward()?g.y.inst.ClientSysMessage(11040907):g.y.inst.ClientSysMessage(11040902)
}OnAdvReposition(){this.ScrollAct(),this.inited=!0,this.cnode.scrollview.ResetPosition()}Test1(){return!0}S_Test(){return!0}},s.SingleLen=135,s.LEFT_BTN_POS=167,
s.RIGHT_BTN_POS=342,s.BTN_POS_Y=-245,n=s))||n},6431:(e,t,i)=>{"use strict"
i.d(t,{I:()=>_})
var n,s=i(18998),a=i(83908),r=i(38045),l=i(9057),o=i(11134)
let _=s._decorator.ccclass("PassrewardProgressItem")(n=class extends((0,a.pA)(l.x)()){constructor(...e){super(...e),this.data=null}InitView(){super.InitView()}AddLis(){}
RemoveLis(){}Clear(){this.RemoveLis(),super.Clear()}SetData(e){this.data=e,this.Label.textSet((0,r.tw)(e))
o.c.Inst_Get().GetProgressActive(e)}Refresh(){}})||n},9007:(e,t,i)=>{"use strict"
i.d(t,{I:()=>R})
var n=i(83908),s=i(98800),a=i(38935),r=i(62370),l=i(85682),o=i(98885),_=i(92679),u=i(74045),h=i(49067),c=i(87923),d=i(48933),m=i(20758),p=i(75439),g=i(71427),I=i(68637),E=i(33828),C=i(77697),S=i(19519),T=i(12417),f=i(15771),A=i(71893),y=i(13224)
class R extends((0,n.Ri)()){constructor(...e){super(...e),this.tiplabel=null,this.model=null,this.npcId=1000101,this.buyPrice=0,this.m_npc=null,this.m_npcCharacter=null,
this.canClick=!0}InitView(){super.InitView(),this.model=A.u.Inst_get()}SetData(){A.u.Inst_get().DailyTiredInfo_set(),this.m_npc=C.f.Inst().getItemByIdNew(this.npcId),
this.SetModelView(),this.UpdateView(),this.m_handlerMgr.AddEventMgr(_.g.WORLD_BOSS_TIRED_UPDATE,this.CreateDelegate(this.UpdateView)),
this.m_handlerMgr.AddClickEvent(this.btn,this.CreateDelegate(this.OnBtnClick)),this.m_handlerMgr.AddClickEvent(this.lunchBuyBtn,this.CreateDelegate(this.OnLunckBuyClick)),
this.m_handlerMgr.AddClickEvent(this.supperBuyBtn,this.CreateDelegate(this.OnSupperBuyClick)),this.RegGuide()}RegGuide(){
I.c.Inst.RegGameObject(l.D.UI_WELF_DV_REWARD_BTN,this.btn.node)}UnRegGuide(){I.c.Inst.UnRegGameObject(l.D.UI_WELF_DV_REWARD_BTN)}CheckGuide(){
c.l.CheckBtnClickTrigger(l.D.UI_WELF_DV_REWARD_BTN)}OnBtnClick(){if(!this.canClick)return
const e=C.f.Inst().getItemByIdNew(this.npcId)
e&&(y.w.Inst_Get().CloseView(),e.GOToNpc())}OnLunckBuyClick(){this.ShowTipBuyTired(0)}OnSupperBuyClick(){this.ShowTipBuyTired(1)}UpdateView(){
const e=p.D.getInstance().getContent("BOSSINFO:BOSS_TIRED_SUPPLY_TIME"),t=p.D.getInstance().getContent("BOSSINFO:BOSS_TIRED_SUPPLY_NUM"),i=e.getContent().arrayVal
this.time1.textSet(o.M.Replace(o.M.Replace(i[0],r.o.s_Arr_UNDER_CHAR_DOT,r.o.s_MID_CHAR),o.M.s_STRING_CHAR_DOT,"")),
this.time2.textSet(o.M.Replace(o.M.Replace(i[1],r.o.s_Arr_UNDER_CHAR_DOT,r.o.s_MID_CHAR),o.M.s_STRING_CHAR_DOT,""))
const n=o.M.String2Int(t.getContent().stringVal)
let s=`+${n}`,a=`+${n}`
const l=f.U.inst.model.GetPanelResVO(f.U.inst.model.level_get())
0!=l.res.powerGet&&(s+=`[BD9962](VIP+${l.res.powerGet})[-]`,a+=`[BD9962](VIP+${l.res.powerGet})[-]`),this.tiredLabel.textSet(s),this.tiredLabel2.textSet(a)
let _=this.triedTip1.transform.GetLocalPosition()
d.I.calVec0.Set(-(this.tiredLabel.width()/2+20),_.y,_.z),this.triedTip1.transform.SetLocalPosition(d.I.calVec0),_=this.triedTip2.transform.GetLocalPosition(),
d.I.calVec0.Set(-(this.tiredLabel2.width()/2+20),_.y,_.z),this.triedTip2.transform.SetLocalPosition(d.I.calVec0)
const u=T._.Inst().HasDailyReward_get()
this.lunchStateObj1.SetActive(!1),this.lunchStateObj2.SetActive(!1),this.supperStateObj1.SetActive(!1),this.supperStateObj2.SetActive(!1),this.RedPoint.SetActive(!1),
this.lunchBuyBtn.node.SetActive(!1),this.supperBuyBtn.node.SetActive(!1),this.eff1.SetActive(!1),this.eff2.SetActive(!1)
let h=!1
u.IndexOf(0)>-1?(this.lunchStateSp.skin="atlas/meiritili/rymeiritili_sp_0006",this.lunchStateObj2.SetActive(!0),this.lunchStateObj2.skin="atlas/meiritili/rymeiritili_sp_0007",
this.lunchStateLabel.textSet("已享用")):this.model.isLunch?(this.lunchStateSp.skin="atlas/meiritili/rymeiritili_sp_0004",this.lunchStateObj1.SetActive(!0),this.eff1.SetActive(!0),
h=!0):this.lunchStateSp.skin="atlas/meiritili/rymeiritili_sp_0005",u.IndexOf(1)>-1?(this.supperStateSp.skin="atlas/meiritili/rymeiritili_sp_0006",
this.supperStateObj2.SetActive(!0),this.supperStateLabel.textSet("已享用")):this.model.isSupper?(this.supperStateSp.skin="atlas/meiritili/rymeiritili_sp_0004",
this.supperStateObj1.SetActive(!0),this.eff2.SetActive(!0),h=!0):this.supperStateSp.skin="atlas/meiritili/rymeiritili_sp_0005",
this.btnSp.skin=h?"atlas/common/rycommon_bt_0001":"atlas/common/rycommon_bt_0004",this.canClick=h}ShowTipBuyTired(e){const t=new h.B
t.infoId="BOSS:TIRED_RECEIVE_CONSUME",t.isCancelForCheckBox=!1,t.confirmHandle=this.CreateDelegate(this.RequestBuyTired),t.confirmParam=e,t.replaceParams.Add(this.buyPrice),
u.t.Inst().Open(t)}RequestBuyTired(e){if(S.J.GetGold(s.Y.Inst.PrimaryRoleInfo_get(),S.J.GOLD_DIAMOND)>=this.buyPrice){const t=new g.s
t.index=e,a.C.Inst.F_SendMsg(t)}else E.Y.Inst_get().OpenTip(this.CreateDelegate(this.OnOpenDiamondTip))}OnOpenDiamondTip(e){E.Y.Inst_get().OkHandler(null)}SetModelView(){
let e=m.F.Inst.GenGetCfgById(this.m_npc.model)
e?this.npcUIAvatar.mid=e.ResName:console.error("DisplayConfigCsv 配置缺失, modelId:"+this.m_npc.model),this.npcUIAvatar.node.setScale(1.5,1.5)}DestroyNPC(){
null!=this.m_npcCharacter&&(this.m_npcCharacter.Destroy(),this.m_npcCharacter=null)}Clear(){super.Clear()}Destroy(){}}R.STAGE_ID=122},71294:(e,t,i)=>{"use strict"
i.d(t,{i:()=>q})
var n=i(18998),s=i(6847),a=i(83908),r=i(17409),l=i(49655),o=i(46282),_=i(40053),u=i(97461),h=i(68662),c=i(5924),d=i(36334),m=i(44255),p=i(62085),g=i(60130),I=i(85602),E=i(24547),C=i(98424),S=i(92679),T=i(28287),f=i(88199),A=i(72631),y=i(60186),R=i(37648),D=i(93727),w=i(14792),L=i(65550),v=i(71893),O=i(95155),P=i(13224),N=i(26034),M=i(90034),b=i(75439),G=i(92721),U=i(34067)
class B extends U.o{constructor(...e){super(...e),this.timeid=null,this.lastTime=null,this.endTime=null}InitView(){}AddLis(){}RemoveLis(){}ShowEffect(){}InitCfg(){
this.status_tmplate=(0,N._T)("日常活跃可领取天使祝福（当前天使祝福：     [65b07c]{0}[-]）"),this.times=b.D.getInstance().GetIntValue("ANGEL:TIMESNUM"),
this.lastTime=3600*b.D.getInstance().GetIntValue("ANGEL:TIME")}UpdateView(){}UpdateTime(){}ClearTimer(){null!=this.timeid&&(c.C.Inst_get().ClearInterval(this.timeid),
this.timeid=null)}AfterSetData(){this.model=G.M.Inst_get()}IsEmpty(){return this.model.GetTotalNum()<=0}GetProgress(){return this.model.GetProgress()}GetRewardList(){
return this.model.GetRewardList()}GetAdvRewardList(){return this.model.GetAdvRewardList()}GetTotalNum(){return this.model.GetTotalNum()}GetProgressPercent(){
const e=this.model.cfgList.Count()
return this.model.GetIntegerProgress()/e}OnClickHandler(){M.s.Inst_get().Open()}OnAdvClick(){
G.M.Inst_get().high?L.y.inst.ClientSysMessage(11040906):P.w.Inst_Get().OpenAdvFightTokeTip(P.w.Angel_Fight_Token)}OnGetReward(e){if(e.showmask){const t=this.model.GetCfg(e.id)
L.y.inst.ClientSysMessage(11040909,new I.Z([t.exp]))}else e.geted?L.y.inst.ClientSysMessage(11040904):P.w.Inst_Get().GetAngelFightTokenReward(e.id,!e.normal)}UpdateBtns(){}
OnIconClick(){INS.itemTipManager.OpenTipViewById(10214)}GetCurProgressItem(){return null}Clear(){}Destroy(){}Test1(){return!0}S_Test(){return!0}}B.LEFT_BTN_POS=null,
B.RIGHT_BTN_POS=null,B.BTN_POS_Y=null
var k,F=i(12826),H=i(27216),x=i(50139),V=i(9007),Y=i(73830)
let W=null,K=null,Z=null,z=null,q=(0,s.s_)(l.o.WelfareHallPanel,o.Z.ui_welfare_tabpanel).tabsPrefab(o.Z.ui_welfare_levelRewardView,f.Z.WELFARE_LEVELREWARD,1).tabsPrefab(o.Z.ui_welfare_dailytotalrecharge_view,f.Z.WELFARE_DAILY_TATAL_RECHARGE,1).tabsPrefab(o.Z.ui_activity_lottery_view,f.Z.WELFARE_LOTTERY,1).tabsPrefab(o.Z.ui_monthcard_view,f.Z.MONTH_CARD,1).tabsPrefab(o.Z.ui_dailyrecharge_view,f.Z.DAILY_RECHARGE,1).tabsPrefab(o.Z.ui_welfara_passreward,f.Z.PASS_REWARD,1).tabsPrefab(o.Z.ui_welfara_angelfighttoken,f.Z.ANGEL_FIGHT_TOKEN,1).tabsPrefab(o.Z.ui_welfare_daily_redpacket_view,f.Z.WELFARE_DAILY_RED_PACKET,1).tabsPrefab(o.Z.ui_welfara_tiredvalue,f.Z.WELFARE_TIREDVALUE,1).waitPrefab(_.Z.WelfareHallPanel_basePrefabs).layerNav().register()(k=class e extends((0,
a.pA)(m.I)()){constructor(...e){super(...e),this.shouldReOpenCurrencyTimer=-1}static __StaticInit(){W=new I.Z(["等级奖励","每日累充","幸运转盘","超值月卡","每日馈赠","荣耀战令","天使战令","每日红包","每日体力"]),
K=new I.Z([f.Z.WELFARE_LEVELREWARD,f.Z.WELFARE_DAILY_TATAL_RECHARGE,f.Z.WELFARE_LOTTERY,f.Z.MONTH_CARD,f.Z.DAILY_RECHARGE,f.Z.PASS_REWARD,f.Z.ANGEL_FIGHT_TOKEN,f.Z.WELFARE_DAILY_RED_PACKET,f.Z.WELFARE_TIREDVALUE]),
Z=new I.Z([w.t.LEVEL_REWARD,w.t.DAILY_TOTAL_RECHARGE,w.t.LUCK_LOTTERY,w.t.MONTH_CARD,w.t.DAILY_RECHARGE,w.t.WEL_PASS_REWARD,w.t.ANGEL_FIGHT_TOKEN,w.t.DAILY_RED_PACKET,w.t.TIREDVALUE]),
z=new I.Z([O.S.LEVEL_REWARD,O.S.DAILY_TOTAL_RECHARGE,O.S.LOTTETY,O.S.MONTH_CARD,O.S.DAILY_RECHARGE,O.S.PASSREWARD,O.S.ANGEL_FIGHT_TOKEN,O.S.REDPACKET,O.S.TIREDVALUE])}
_initBinder(){super._initBinder(),e.__StaticInit(),this._subPanelDatas.Add(d.b.New(new I.Z([o.Z.ui_welfare_levelRewardView]),this,Y.I)),
this._subPanelDatas.Add(d.b.New(new I.Z([o.Z.ui_welfare_dailytotalrecharge_view]),this,H.z)),this._subPanelDatas.Add(d.b.New(new I.Z([o.Z.ui_activity_lottery_view]),this,C.I)),
this._subPanelDatas.Add(d.b.New(new I.Z([o.Z.ui_monthcard_view]),this,x.B)),this._subPanelDatas.Add(d.b.New(new I.Z([o.Z.ui_dailyrecharge_view]),this,y.y)),
this._subPanelDatas.Add(d.b.New(new I.Z([o.Z.ui_welfara_passreward]),this,U.o)),this._subPanelDatas.Add(d.b.New(new I.Z([o.Z.ui_welfara_angelfighttoken]),this,B)),
this._subPanelDatas.Add(d.b.New(new I.Z([o.Z.ui_welfare_daily_redpacket_view]),this,F.M)),this._subPanelDatas.Add(d.b.New(new I.Z([o.Z.ui_welfara_tiredvalue]),this,V.I))}
InitView(){h.D.IsIosShenhe()
this.AddLis()}AddLis(){super.AddLis(),u.i.Inst.AddEventHandler(S.g.CloseCurrencyBarView,this.CreateDelegate(this.shouldReOpenCurency)),
this.closeBtn.node.on(n.NodeEventType.TOUCH_END,this.fun_CloseClickHandler,this)}shouldReOpenCurency(){(0,
r.Di)(l.o.WelfareHallPanel)&&(this.shouldReOpenCurrencyTimer>0&&(c.C.Inst_get().ClearInterval(this.shouldReOpenCurrencyTimer),this.shouldReOpenCurrencyTimer=-1),
this.shouldReOpenCurrencyTimer=c.C.Inst_get().SetInterval(this.CreateDelegate(this.reOpenCurrencyBar),200,1))}reOpenCurrencyBar(){
this.ShowCurrencyBar_get&&this.ShowCurrencyBar_get()!=T._.None&&u.i.Inst.RaiseEvent(S.g.OpenCurrencyBarView,[this,l.o.WelfareHallPanel])}SetViewConfig(){
this._SetCharacterTabData(!1)
const[e,t,i,n]=this.GetViewInfo()
this._SetTabData1(!0,e,i,null,t),this._SetTabData0(!1)
let s=0
s=-1==v.u.Inst_get().viewType?this.GetRedTabIndex(v.u.Inst_get().viewType,this.tab1RedPointList):n.IndexOf(v.u.Inst_get().viewType),this.SelectTab1(s,!0)}GetViewInfo(){
const e=new I.Z,t=new I.Z,i=new I.Z,n=new I.Z
for(let s=0;s<=K.Count()-1;s++){const a=A.E.Inst().getItemById(K[s]).tabOpenID
;(0==a||R.P.Inst_get().IsFuncOrActivityOpened(a))&&(K[s]==f.Z.WELFARE_LOTTERY?D.i.ins.huodong_dict.LuaDic_ContainsKey(E.R.Inst_get().currentActivityId)&&(e.Add(W[s]),t.Add(K[s]),
i.Add(Z[s]),n.Add(z[s])):(e.Add(W[s]),t.Add(K[s]),i.Add(Z[s]),n.Add(z[s])))}return[e,t,i,n]}_SetTabData1(e,t,i,n,s,a){
this.rightTabGrid.SetInitInfo("ui_ry_right_tab3",null,p.M,this.CreateDelegate(this._OnClickRightItem)),
this.rightTabGrid.OnReposition_set(this.CreateDelegate(this.OnRepositionRight)),super._SetTabData1(e,t,i,n,s,a)}_OnClickRightItem(e,t,i){super._OnClickRightItem(e,t,i),
e.CheckGuide()}OnRepositionBottom(){this._UpdateTableSelect0()}Clear(){u.i.Inst.RemoveEventHandler(S.g.CloseCurrencyBarView,this.CreateDelegate(this.shouldReOpenCurency)),
v.u.Inst_get().viewType=-1,super.Clear()}Destroy(){super.Destroy()}OnCloseClick(){}_OnSelectTab1BeforeUpdate(e){if(this.rightTabGrid.data_get().Count()>0){
const e=this.rightTabGrid.data_get()[this.selectTabIdx1].tabId
if(e==f.Z.WELFARE_LEVELREWARD&&!P.w.Inst_Get().IsShowLevelRewardTab())return void L.y.inst.ClientSysMessage(120100)
this.ShowSubView(K.IndexOf(e))}}UpdateView(){if(this.bg1.node.SetActive(!1),this.bg2.node.SetActive(!0),this.qiyuanBg.node.SetActive(!1),this.mask.node.SetActive(!1),
this.rightTabGrid.data_get().Count()>0){const e=this.rightTabGrid.data_get()[this.selectTabIdx1].tabId
e==f.Z.WELFARE_PRAY?(this.qiyuanBg.node.SetActive(!0),this.bg1.node.SetActive(!1),
this.bg2.node.SetActive(!1)):e==f.Z.WELFARE_LOTTERY||e==f.Z.MONTH_CARD?(this.bg1.node.SetActive(!1),this.bg2.node.SetActive(!1),
this.mask.node.SetActive(!0)):e==f.Z.WELFARE_DAILY_RED_PACKET&&(this.bg2.node.SetActive(!1),this.mask.node.SetActive(!0))}}UpdateAnchors(){
const e=g.O.GetUIWidth(),t=g.O.GetUIHeight()
this.bg1.widthSet(e),this.bg2.widthSet(e),this.mask.widthSet(e+10),this.mask.heightSet(t+10),g.O.SetAnchorPos(this.leftTrans,!0,!1,0),g.O.SetAnchorPos(this.rightTrans,!1,!0,0)}
fun_CloseClickHandler(){(0,r.sR)(l.o.WelfareHallPanel)}})||k},73830:(e,t,i)=>{"use strict"
i.d(t,{I:()=>S})
var n,s=i(18998),a=i(34565),r=i(97461),l=i(68662),o=i(5924),_=i(85682),u=i(5494),h=i(85602),c=i(92679),d=i(87923),m=i(99421),p=i(12842),g=i(93727),I=i(13224),E=i(80460),C=i(86172)
let S=s._decorator.ccclass("WelfareLevelRewardView")(n=class extends a.I{constructor(...e){super(...e),this.intervalId=null,this.lis=null,this.countDownTimer=null,this.cnode=null}
SetData(){m.l.ins.CM_OpenActivityPanel(p.t.LEVEL_REWARD),this.RegUIShow(),this.AddLis(),this.RefreshEndTime(),this.UpdateInfo()}AddLis(){
r.i.Inst.AddEventHandler(c.g.LEVELREWARDINFO_UPDATE,this.CreateDelegate(this.ShowHighItem))}RemoveLis(){
r.i.Inst.RemoveEventHandler(c.g.LEVELREWARDINFO_UPDATE,this.CreateDelegate(this.ShowHighItem))}UpdateScrollBar(){null!=this.intervalId&&o.C.Inst_get().ClearLoop(this.intervalId),
this.intervalId=o.C.Inst_get().SetFrameLoop(this.CreateDelegate(this.SetScrollBarValue),2,1)}UpdateInfo(){this.ShowHighItem(),this.UpdateItemLis()}ShowHighItem(){
const e=E.r.Inst_Get().levelRewardList,t=new h.Z,i=new h.Z,n=new h.Z,s=new h.Z
for(let a=e.Count()-1;a>=0;a+=-1){const r=e[a],l=I.w.Inst_Get().GetInfoById(r.id)
2!=l.state&&(0==l.state||1==l.state?r.limit>0?t.Add(r):i.Add(r):4!=l.state&&5!=l.state||(r.limit>0?n.Add(r):s.Add(r)))}const a=new h.Z([t,i,n,s])
for(let e=0;e<=a.Count()-1;e++){const t=a[e]
if(t.Sort(this.CreateDelegate(this.SortFunc)),t.Count()>0){this.cnode.highItem.SetData(t[0])
break}}}SetScrollBarValue(){const e=this.lis.Count()
let t=0
for(let i=0;i<=e-1;i++){const e=this.lis[i],n=I.w.Inst_Get().GetInfoById(e.id).state
if(1==n||5==n){t=i+1
break}}let i=0
i=t<=2?0:t>e-3?1:(t-3)/(e-4),this.cnode.bar.SetValue(i)}UpdateItemLis(){const e=E.r.Inst_Get().levelRewardList,t=new h.Z,i=new h.Z
for(let n=0;n<=e.Count()-1;n++){2!=I.w.Inst_Get().GetInfoById(e[n].id).state?t.Add(e[n]):i.Add(e[n])}t.AddRange(i),this.lis=t,this.cnode.myGrid.data_set(t),
this.cnode.myGrid.Reposition(),this.cnode.scrollView.ResetPosition()}SortFunc(e,t){return t.level-e.level}InitView(){this.cnode=this.node.getCNode(),
this.cnode.myGrid.SetInitInfo("ui_welfarelevelreward_item",null,C.i),this.cnode.myGrid.OnReposition_set(this.CreateDelegate(this.RepositionFun)),this.cnode.highItem.SetIsHight()}
RepositionFun(){this.cnode.scrollView.ResetPosition()}RegUIShow(){this.cnode.registerUIScId=_.D.LevelAward,this.cnode.registerUIId=u.I.WelfarePanelId,
null!=this.cnode.registerUIScId&&INS.uIShowShortCut.RegUIShowDic(this.cnode.registerUIScId,this.cnode.registerUIId)}UnRegUIShow(e){
null!=this.cnode.registerUIScId&&(INS.uIShowShortCut.UnRegUIShowDic(this.cnode.registerUIScId),null!=e&&e&&(this.cnode.registerUIScId=null))}Clear(){
null!=this.intervalId&&o.C.Inst_get().ClearLoop(this.intervalId),this.node.SetActive(!1),this.RemoveLis(),this.ClearEndTimeHandle(),super.Clear()}RefreshEndTime(){let e=0
const t=g.i.ins.huodong_dict.LuaDic_GetItem(p.t.LEVEL_REWARD)
null!=t&&null!=t.endTime&&t.endTime.ToNum()>0&&(e=.001*t.endTime.ToNum()-l.D.serverTime_get()),this.EndTimeCountDown(),
e>0?null==this.countDownTimer&&(this.countDownTimer=o.C.Inst_get().SetInterval(this.CreateDelegate(this.EndTimeCountDown),1e3,-1)):this.ClearEndTimeHandle()}EndTimeCountDown(){
let e=0,t=""
const i=g.i.ins.huodong_dict.LuaDic_GetItem(p.t.LEVEL_REWARD)
null!=i&&null!=i.endTime&&i.endTime.ToNum()>0?(e=.001*i.endTime.ToNum()-l.D.serverTime_get(),e>0?(t=d.l.GetDateFormat3(e),
this.cnode.endTimeTxt.textSet(`[F5E6D8]活动剩余时间:[-][047104]${t}[-]`)):this.ClearEndTimeHandle()):this.ClearEndTimeHandle(),this.cnode.endTimeTxt._activateChildren(!0)}
ClearEndTimeHandle(){this.cnode.endTimeTxt.textSet("[F5E6D8]活动已结束[-]"),null!=this.countDownTimer&&(o.C.Inst_get().ClearInterval(this.countDownTimer),this.countDownTimer=null)}})||n
},86172:(e,t,i)=>{"use strict"
i.d(t,{i:()=>f})
var n,s=i(18998),a=i(83908),r=i(25236),l=i(98800),o=i(97461),_=i(9057),u=i(85682),h=i(85602),c=i(79534),d=i(63076),m=i(92679),p=i(85751),g=i(87923),I=i(68637),E=i(41864),C=i(15771),S=i(13224),T=i(80065)
let f=s._decorator.ccclass("WelfareLevelRwardItem")(n=class extends((0,a.pA)(_.x)()){constructor(...e){super(...e),this.data=null,this.isHight=null,this.info=null}InitView(){
super.InitView(),this.MyGrid.SetInitInfo("ui_welfare_levelreward_dunitem",null,T.T)}RegGuide(){
this.GoBtn.node.active?I.c.Inst.RegGameObject(u.D.UI_WELF_LEVEL_REWARD_BTN,this.GoBtn.node):this.UnRegGuide(),
this.goVipBtn.node.active?I.c.Inst.RegGameObject(u.D.UI_WELF_LEVEL_VIP_BTN,this.goVipBtn.node):this.UnRegGuide1()}UnRegGuide(){
I.c.Inst.UnRegGameObject(u.D.UI_WELF_LEVEL_REWARD_BTN)}UnRegGuide1(){I.c.Inst.UnRegGameObject(u.D.UI_WELF_LEVEL_VIP_BTN)}CheckGuide(){
g.l.CheckBtnClickTrigger(u.D.UI_WELF_LEVEL_REWARD_BTN)}CheckGuide1(){g.l.CheckBtnClickTrigger(u.D.UI_WELF_LEVEL_VIP_BTN)}Clear(){this.UnRegGuide(),this.UnRegGuide1(),super.Clear(),
this.RemoveLis()}SetData(e){if(this.data=e,null==this.data)return this.lab.node.SetActive(!1),this.labLevel.node.SetActive(!1),void this.content.SetActive(!1)
this.lab.node.SetActive(!0),this.labLevel.node.SetActive(!0),this.content.SetActive(!0),this.RemoveLis(),this.AddLis(),this.SetInfo(),
this.lab.textSet(`${E.h.GetLevelStr2(this.data.level)}级可领取`),this.RefreshVipItemLis()}RefreshVipItemLis(){const e=new h.Z
if(null!=this.data&&null!=this.data.reward&&null!=this.data.reward.rewards){let t=0
for(;t<this.data.reward.rewards.Count();){const i={},n=d.M.wrapReward(this.data.reward.rewards[t])
i.itemData=n,i.vipLevel=0,i.state=this.info.state,e.Add(i),t+=1}}if(null!=this.data&&null!=this.data.vipReward&&null!=this.data.vipReward.rewards){let t=0
for(;t<this.data.vipReward.rewards.Count();){const i={},n=d.M.wrapReward(this.data.vipReward.rewards[t])
i.itemData=n,i.vipLevel=this.data.vipLevel,i.state=this.info.state,e.Add(i),t+=1}}this.MyGrid.data_set(e)}SetInfo(){const e=l.Y.Inst.PrimaryRoleInfo_get().Level_get()
this.info=S.w.Inst_Get().GetInfoById(this.data.id),this.goVipBtn.node.SetActive(!1),this.labLevel.node.SetActive(!1),this.GoBtn.node.SetActive(!1),this.hasGet.SetActive(!1),
this.cantGetNum.node.SetActive(!1),this.remainNum.node.SetActive(!1)
let t=new c.P(89,3,0)
if(this.lab.node.transform.SetLocalPosition(t),null!=this.info){const i=this.info.state
0==i?(this.cantGetNum.textSet(this.GetRemainStr()),this.cantGetNum.node.SetActive(!0),this.labLevel.node.SetActive(!0),
this.isHight?this.labLevel.textSet(`(还差${p.u.BrightRedColorStr2}${this.data.level-e}[-]级可领取)`):this.labLevel.textSet(`(还差[962424]${this.data.level-e}[-]级可领取)`),t=new c.P(89,22,0),
this.lab.node.transform.SetLocalPosition(t)):1==i||5==i?(this.GoBtn.node.SetActive(!0),this.remainNum.textSet(this.GetRemainStr()),
this.remainNum.node.SetActive(!0)):2==i?this.hasGet.SetActive(!0):3==i?(this.cantGetNum.textSet(this.GetRemainStr()),
this.cantGetNum.node.SetActive(!0)):4==i&&(this.goVipBtn.node.SetActive(!0),this.vipBtnTxt.textSet(`成为VIP${this.data.vipLevel}`))}else(0,r.S)(`error${this.data.id}`)
this.RegGuide()}GetRemainStr(){if(this.data.limit<=0)return"全服不限量"
const e="全服限量",t=`${this.info.num}/${this.data.limit}`
return 0==this.info.num?`${e}已领完`:`${e}[FFFFFF]${t}[-]`}AddLis(){this.m_handlerMgr.AddClickEvent(this.GoBtn,this.CreateDelegate(this.OnGetBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.goVipBtn,this.CreateDelegate(this.GoVipBtnHandle)),
o.i.Inst.AddEventHandler(m.g.LEVELREWARDINFO_UPDATE,this.CreateDelegate(this.RewardInfoChange))}RemoveLis(){this.m_handlerMgr.Clear(),
o.i.Inst.RemoveEventHandler(m.g.LEVELREWARDINFO_UPDATE,this.CreateDelegate(this.RewardInfoChange))}SetIsHight(){this.isHight=!0}RewardInfoChange(){null!=this.data&&(this.SetInfo(),
this.RefreshVipItemLis())}OnGetBtnHandle(){this.CheckGuide(),S.w.Inst_Get().netHandler.SendGetLevelReward(this.data.id)}GoVipBtnHandle(){this.CheckGuide1(),
C.U.inst.model.defaultVipGiftIndex=this.data.vipLevel,C.U.inst.controller.OpenPanel()}})||n},80065:(e,t,i)=>{"use strict"
i.d(t,{T:()=>l})
var n,s=i(18998),a=i(83908),r=i(9057)
let l=s._decorator.ccclass("WelfareLevelRwardVipItem")(n=class extends((0,a.pA)(r.x)()){constructor(...e){super(...e),this.data=null}Destroy(){this.baseItem.Destroy()}SetData(e){
this.data=e
const t=e.vipLevel
null!=t&&t>0?(this.vipTab.SetActive(!0),this.vipDesc.textSet(`V${t}可领`)):this.vipTab.SetActive(!1),this.baseItem.SetData(this.data.itemData)
const i=e.state
2==i?this.hasGet.SetActive(!0):4==i||5==i?null!=t&&t>0?this.hasGet.SetActive(!1):this.hasGet.SetActive(!0):this.hasGet.SetActive(!1)}Clear(){this.baseItem.Clear(),this.data=null}
})||n},8455:(e,t,i)=>{"use strict"
i.d(t,{L:()=>F})
var n=i(78816),s=i(56937),a=i(18202),r=i(31222),l=i(5494),o=i(995),_=i(79534),u=i(38836),h=i(98800),c=i(97960),d=i(97461),m=i(6665),p=i(72005),g=i(61911),I=i(5468),E=i(98130),C=i(98885),S=i(85602),T=i(92679),f=i(57035),A=i(37648),y=i(48946),R=i(86662),D=i(14792),w=i(40621),L=i(62734),v=i(17783),O=i(9986),P=i(9057),N=i(57834),M=i(93877),b=i(11355),G=i(87923),U=i(12862)
class B extends P.x{constructor(){super(),this.iconBtn=null,this.tipSpr=null,this.funcName=null,this.effect=null,this.data=null,this._degf_OnFunc=null,
this._degf_OnFunc=(e,t)=>this.OnFunc(e,t)}InitView(){this.iconBtn=new O.W,this.iconBtn.setId(this.FatherId,this.FatherComponentID,1),this.tipSpr=new p.w,
this.tipSpr.setId(this.FatherId,this.FatherComponentID,2),this.funcName=new M.Q,this.funcName.setId(this.FatherId,this.FatherComponentID,3),this.effect=new b.I,
this.effect.setId(this.FatherId,this.FatherComponentID,4)}Destroy(){this.iconBtn=null,this.tipSpr=null,this.funcName=null}ShowOrHideEffect(e){this.effect.node.SetActive(e),
e?(this.effect.ResetToBeginning(),this.effect.Play()):this.effect.Pause()}SetData(e){this.AddListeners(),this.data=e,this.iconBtn.normalSpriteSet(this.data.icon),
this.iconBtn.hoverSpriteSet(this.data.icon),this.iconBtn.pressedSpriteSet(this.data.icon),this.tipSpr.node.SetActive(w.c.Instance_get().RedPointIsShowByFuncId(this.data.id))
const t=f.d.Inst_get().getItemById(this.data.id)
null!=t&&this.funcName.textSet(t.name),this.ShowOrHideEffect(!1)}GetCenterPos(){return this.iconBtn.node.transform.GetPosition()}Clear(){this.RemoveListeners(),
this.ShowOrHideEffect(!1),this.data=null}AddListeners(){N.i.Get(this.iconBtn.node).RegistonClick(this._degf_OnFunc)}RemoveListeners(){
N.i.Get(this.iconBtn.node).RemoveonClick(this._degf_OnFunc)}OnFunc(e,t){if(this.ShowOrHideEffect(!1),null==this.data)return
A.P.Inst_get().IsFuncOrActivityOpened(this.data.id)?(U.z.inst.OpenView(this.data.id,!0),F.Inst_get().CloseView()):G.l.SetFunctionTip(this.data.id)}}class k extends g.f{
constructor(){super(),this.maskSpr=null,this.bgSpr=null,this.itemGrid=null,this.srcBgPos=null,this._degf_CreateItem=null,this._degf_OnClose=null,this._degf_OnFuncOpen=null,
this._degf_OnGridItemLoaded=null,this._degf_OnLevelUp=null,this._degf_OnUpdateRedPoint=null,this.srcBgPos=_.P.zero_get(),this._degf_CreateItem=e=>this.CreateItem(e),
this._degf_OnClose=(e,t)=>this.OnClose(e,t),this._degf_OnFuncOpen=e=>this.OnFuncOpen(e),this._degf_OnGridItemLoaded=()=>this.OnGridItemLoaded(),
this._degf_OnLevelUp=e=>this.OnLevelUp(e),this._degf_OnUpdateRedPoint=(e,t)=>this.OnUpdateRedPoint(e,t)}InitView(){this.maskSpr=new p.w,
this.maskSpr.setId(this.FatherId,this.FatherComponentID,1),this.bgSpr=new p.w,this.bgSpr.setId(this.FatherId,this.FatherComponentID,2),
this.srcBgPos=this.bgSpr.node.transform.GetLocalPosition().Clone(),this.itemGrid=new m.A,this.itemGrid.setId(this.FatherId,this.FatherComponentID,3),
this.itemGrid.SetInitInfo("ui_moreitem",this._degf_CreateItem),this.itemGrid.OnReposition_set(this._degf_OnGridItemLoaded)}OnGridItemLoaded(){
if(!C.M.IsNullOrEmpty(v.L.Inst_get().model.flyUIChild)){const e=v.L.Inst_get().model.flyUIChild
let t=null,i=0
for(;i<this.itemGrid.itemList.Count();){if(t=this.itemGrid.itemList[i],t.data.btnId==e){t.ShowOrHideEffect(!0)
break}i+=1}v.L.Inst_get().model.flyUIChild=I.E.s_Empty}}Destroy(){this.maskSpr=null,this.bgSpr=null,this.itemGrid.Destroy(),this.itemGrid=null}OnAddToScene(){this.AddListeners(),
this.UpdateView()}Clear(){this.RemoveListeners()}AddListeners(){this.AddClickEvent(this.maskSpr,this._degf_OnClose),
d.i.Inst.AddEventHandler(T.g.FUNCTION_OPEN,this._degf_OnFuncOpen),h.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(c.A.LevelUpdate,this._degf_OnLevelUp),
L.f.Inst.AddCallback(D.t.LEVEL_REWARD,this._degf_OnUpdateRedPoint),L.f.Inst.AddCallback(D.t.PRAY,this._degf_OnUpdateRedPoint),
L.f.Inst.AddCallback(D.t.LOTTERY,this._degf_OnUpdateRedPoint)}RemoveListeners(){this.RemoveClickEvent(this.maskSpr,this._degf_OnClose),
d.i.Inst.RemoveEventHandler(T.g.FUNCTION_OPEN,this._degf_OnFuncOpen),h.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(c.A.LevelUpdate,this._degf_OnLevelUp),
L.f.Inst.RemoveCallback(D.t.LEVEL_REWARD,this._degf_OnUpdateRedPoint),L.f.Inst.RemoveCallback(D.t.PRAY,this._degf_OnUpdateRedPoint),
L.f.Inst.RemoveCallback(D.t.LOTTERY,this._degf_OnUpdateRedPoint)}OnClose(e,t){F.Inst_get().CloseView()}OnFuncOpen(e){const t=E.GF.INT(e),i=f.d.Inst_get().getItemById(t)
if(null==i)return
const n=y.m.Inst_get().getItemById(i.nameId)
null!=n&&4==n.area_type&&this.UpdateView()}OnLevelUp(e){this.UpdateView()}OnUpdateRedPoint(e,t){
if(null!=this.itemGrid&&null!=this.itemGrid.itemList&&0!=this.itemGrid.itemList.Count()){let t=!1
const i=w.c.Instance_get().GetFunIdByRedPointIdEx(e)
for(const[e,n]of(0,u.V5)(this.itemGrid.itemList))null!=n.data&&n.data.id==i&&(t=w.c.Instance_get().RedPointIsShowByFuncId(n.data.id),n.tipSpr.node.SetActive(t))}}UpdateView(){
const e=new S.Z,t=y.m.Inst_get().GetItemList()
let i=t.Count()-1
for(;i>=0;){const n=t[i]
if(4==n.area_type){const t=f.d.Inst_get().GetItemByNameId(n.id)
if(null!=t&&A.P.Inst_get().IsFuncOrActivityOpened(t.id)){const i=new R.T
i.id=t.id,i.areaId=n.area_id,i.icon=n.icon,i.btnId=n.id,i.efftype=n.type,e.Add(i)}}i-=1}this.itemGrid.data_set(e)
let n=0
n=e.Count()%4==0?e.Count()/4:e.Count()/4+1
const s=this.itemGrid.node.transform.GetLocalPosition(),a=Math.abs(s.y)+n*this.itemGrid.cellHeight()+3
this.bgSpr.heightSet(E.GF.INT(a))
const r=F.Inst_get().refWorldPos,l=this.node.transform.WorldToLocalMatrixMultiplyPoint3x4(r)
l.y=this.srcBgPos.y,l.z=this.srcBgPos.z,this.bgSpr.node.transform.SetLocalPosition(l),_.P.Recyle(l)}CreateItem(e){const t=new B
return t.setId(e,null,0),t}}class F{constructor(){this.view=null,this.refWorldPos=null,this._degf_CallComplete=null,this._degf_CallDestory=null,this.refWorldPos=_.P.zero_get(),
this._degf_CallComplete=e=>this.CallComplete(e),this._degf_CallDestory=()=>this.CallDestory()}static Inst_get(){return null==F._inst&&(F._inst=new F),F._inst}OpenView(e){
if(this.refWorldPos=e.Clone(),null!=this.view&&this.view.isShow_get())this.view.UpdateView()
else{const e=new s.v
e.aniDir=o.K.Up,r.N.inst.OpenById(l.I.eWelfareXPanel,this._degf_CallComplete,this._degf_CallDestory,e),n.a.inst_get().PlayOpenSound(l.I.eWelfareXPanel)}}CallComplete(e){
return null==this.view&&(this.view=new k,this.view.setId(e,null,0)),this.view}CallDestory(){a.g.DestroyUIObj(this.view),this.view=null}CloseView(){
null!=this.view&&this.view.isShow_get()&&(r.N.inst.CloseById(l.I.eWelfareXPanel),n.a.inst_get().PlayCloseSound(l.I.eWelfareXPanel))}}F._inst=null},6212:(e,t,i)=>{"use strict"
i.d(t,{K:()=>r})
var n=i(93984),s=i(55360),a=i(38962)
class r{constructor(){this.prayMap=null,this.levelRewardMap=null,this.dailyTotalRechargeMap=null,this.prayMap=new a.X,this.levelRewardMap=new a.X,this.dailyTotalRechargeMap=new a.X
const e=s.Y.Inst.GetOrCreateCsv(n.h.ePrayResource)
this.prayMap=e.GetCsvMap()
const t=s.Y.Inst.GetOrCreateCsv(n.h.eLevelRewardResource)
this.levelRewardMap=t.GetCsvMap()
const i=s.Y.Inst.GetOrCreateCsv(n.h.eDailyRechargeResource)
this.dailyTotalRechargeMap=i.GetCsvMap()}static Inst(){return null==r._inst&&(r._inst=new r),r._inst}getPrayByLevel(e){
return this.prayMap.LuaDic_ContainsKey(e)?this.prayMap[e]:null}}r._inst=null},12862:(e,t,i)=>{"use strict"
i.d(t,{z:()=>le})
var n=i(97461),s=i(56937),a=i(18202),r=i(31222),l=i(5494),o=i(995),_=i(70850),u=i(92679),h=i(87923),c=i(37648),d=i(55492),m=i(5031),p=i(14792),g=i(62734),I=i(71893),E=i(95155),C=i(98800),S=i(98958),T=i(5924),f=i(99294),A=i(9986),y=i(9776),R=i(30267),D=i(86290),w=i(8889),L=i(3522),v=i(61911),O=i(85602),P=i(79534),N=i(28287),M=i(13796),b=i(88199),G=i(51322),U=i(86209),B=i(48933),k=i(20641),F=i(19519),H=i(37848),x=i(86133),V=i(62370),Y=i(57834),W=i(93877),K=i(30849),Z=i(98885),z=i(74045),q=i(39879),$=i(49067),X=i(10509),Q=i(38501),j=i(33828),J=i(31896),ee=i(65550),te=i(39043),ie=i(15771),ne=i(6212)
class se extends K.C{constructor(){super(),this.moneyLabel=null,this.moneyTimeLabel=null,this.moneyVipPray=null,this.moneyFreePray=null,this.moneyCostLabel=null,
this.moneyVipPrayBtn=null,this.moneyCDLabel=null,this.moneyFreePrayBtn=null,this.expLabel=null,this.expTimeLabel=null,this.expCostLabel=null,this.expVipPrayBtn=null,
this.anime=null,this.scoreSuccessEffect=null,this.expSuccessEffect=null,this.model=null,this.intervalId=0,this.role=null,this.moneyCost=0,this.expCost=0,
this._degf_CM_FreeMoneyPray=null,this._degf_CM_VipExpPray=null,this._degf_CM_VipMoneyPray=null,this._degf_Interval=null,this._degf_Refresh=null,this._degf_handler=null,
this._degf_CM_FreeMoneyPray=(e,t)=>this.CM_FreeMoneyPray(e,t),this._degf_CM_VipExpPray=(e,t)=>this.CM_VipExpPray(e,t),this._degf_CM_VipMoneyPray=(e,t)=>this.CM_VipMoneyPray(e,t),
this._degf_Interval=()=>this.Interval(),this._degf_Refresh=e=>this.Refresh(e),this._degf_handler=e=>this.handler(e)}InitView(){super.InitView(),this.moneyLabel=new W.Q,
this.moneyLabel.setId(this.FatherId,this.FatherComponentID,1),this.moneyTimeLabel=new W.Q,this.moneyTimeLabel.setId(this.FatherId,this.FatherComponentID,2),
this.moneyVipPray=new f.z,this.moneyVipPray.setId(this.FatherId,this.FatherComponentID,3),this.moneyFreePray=new f.z,
this.moneyFreePray.setId(this.FatherId,this.FatherComponentID,4),this.moneyCostLabel=new W.Q,this.moneyCostLabel.setId(this.FatherId,this.FatherComponentID,5),
this.moneyVipPrayBtn=new A.W,this.moneyVipPrayBtn.setId(this.FatherId,this.FatherComponentID,6),this.moneyCDLabel=new W.Q,
this.moneyCDLabel.setId(this.FatherId,this.FatherComponentID,7),this.moneyFreePrayBtn=new A.W,this.moneyFreePrayBtn.setId(this.FatherId,this.FatherComponentID,8),
this.expLabel=new W.Q,this.expLabel.setId(this.FatherId,this.FatherComponentID,9),this.expTimeLabel=new W.Q,this.expTimeLabel.setId(this.FatherId,this.FatherComponentID,10),
this.expCostLabel=new W.Q,this.expCostLabel.setId(this.FatherId,this.FatherComponentID,11),this.expVipPrayBtn=new A.W,
this.expVipPrayBtn.setId(this.FatherId,this.FatherComponentID,12),this.anime=new L.k,this.anime.setId(this.FatherId,this.FatherComponentID,13),this.scoreSuccessEffect=new f.z,
this.scoreSuccessEffect.setId(this.FatherId,this.FatherComponentID,14),this.expSuccessEffect=new f.z,this.expSuccessEffect.setId(this.FatherId,this.FatherComponentID,15),
this.model=I.u.Inst_get()}OnAddToScene(){this.AddLis(),this.scoreSuccessEffect.SetActive(!1),this.expSuccessEffect.SetActive(!1),this.Refresh(null),this.anime.SetResetOnPlay(!0),
this.anime.Play(!0,!1)}Clear(){this.RemoveLis(),this.intervalId>0&&(T.C.Inst_get().ClearInterval(this.intervalId),this.intervalId=-1)}Destroy(){this.moneyLabel=null,
this.moneyTimeLabel=null,this.moneyVipPray=null,this.moneyFreePray=null,this.moneyCostLabel=null,this.moneyVipPrayBtn=null,this.moneyCDLabel=null,this.moneyFreePrayBtn=null,
this.expLabel=null,this.expTimeLabel=null,this.expCostLabel=null,this.expVipPrayBtn=null}AddLis(){Y.i.Get(this.moneyVipPrayBtn.node).RegistonClick(this._degf_CM_VipMoneyPray),
Y.i.Get(this.moneyFreePrayBtn.node).RegistonClick(this._degf_CM_FreeMoneyPray),Y.i.Get(this.expVipPrayBtn.node).RegistonClick(this._degf_CM_VipExpPray),
n.i.Inst.AddEventHandler(u.g.PRAY_UPDATE,this._degf_Refresh)}RemoveLis(){Y.i.Get(this.moneyVipPrayBtn.node).RemoveonClick(this._degf_CM_VipMoneyPray),
Y.i.Get(this.moneyFreePrayBtn.node).RemoveonClick(this._degf_CM_FreeMoneyPray),Y.i.Get(this.expVipPrayBtn.node).RemoveonClick(this._degf_CM_VipExpPray),
n.i.Inst.RemoveEventHandler(u.g.PRAY_UPDATE,this._degf_Refresh)}Refresh(e){this.role=C.Y.Inst.PrimaryRoleInfo_get()
const t=this.role.Level_get(),i=ne.K.Inst().getPrayByLevel(t),n=Q.f.Inst().getItemById(ie.U.inst.model.effectiveLevel_get()).moneyPrayTimes,s=Q.f.Inst().getItemById(ie.U.inst.model.effectiveLevel_get()).expPrayTimes,a=n-this.model.MoneyRestPrayTimes_get()+1,r=s-this.model.ExpRestPrayTimes_get()+1
let l=0,o=0
this.moneyCost=0,this.expCost=0
let _=i.prayCost
_=Z.M.SubStringWithEnd(_,1,Z.M.Length(_)-1),_=Z.M.Replace(_,Z.M.s_StringChar,"")
const u=Z.M.Split(_,Z.M.s_SPAN_CHAR_DOT)
let c=i.prayExpCost
c=Z.M.SubStringWithEnd(c,1,Z.M.Length(c)-1),c=Z.M.Replace(c,Z.M.s_StringChar,"")
const d=Z.M.Split(c,Z.M.s_SPAN_CHAR_DOT)
let m=0
for(;m<u.count;){const e=Z.M.Split(u[m],V.o.s_Arr_UNDER_CHAR_DOT),t=Z.M.String2Int(e[0])
l=Z.M.String2Int(e[1]),0==this.moneyCost&&a<=t&&(this.moneyCost=l),m+=1}let p=0
for(;p<d.count;){const e=Z.M.Split(d[p],V.o.s_Arr_UNDER_CHAR_DOT),t=Z.M.String2Int(e[0])
o=Z.M.String2Int(e[1]),0==this.expCost&&r<=t&&(this.expCost=o),p+=1}0==this.moneyCost&&(this.moneyCost=l),0==this.expCost&&(this.expCost=o),
this.model.MoneyRestActiveTime_get()<=0?(this.moneyFreePray.SetActive(!0),this.moneyVipPray.SetActive(!1),this.intervalId>0&&(T.C.Inst_get().ClearInterval(this.intervalId),
this.intervalId=-1),this.moneyCDLabel.textSet("")):(this.moneyFreePray.SetActive(!1),this.moneyVipPray.SetActive(!0),this.moneyCostLabel.textSet(Z.M.IntToString(this.moneyCost)),
this.moneyCDLabel.textSet(h.l.GetDateFormat(this.model.MoneyRestActiveTime_get()/1e3)+(0,x.T)("后免费许愿")),this.intervalId>0&&(T.C.Inst_get().ClearInterval(this.intervalId),
this.intervalId=-1),this.intervalId=T.C.Inst_get().SetInterval(this._degf_Interval,500)),this.moneyLabel.textSet(`S${h.l.GetPurseVOChineseStringEEx(i.prayMoney,2)}`),
this.moneyTimeLabel.textSet(`${Z.M.IntToString(this.model.MoneyRestPrayTimes_get())}/${Z.M.IntToString(n)+(0,x.T)("次")}`)
const g=X.L.Inst().getItemById(t).rexp*i.prayExp
this.expLabel.textSet(`J${h.l.GetPurseVOChineseStringEEx(g,2)}`),this.expCostLabel.textSet(Z.M.IntToString(this.expCost)),
this.expTimeLabel.textSet(`${Z.M.IntToString(this.model.ExpRestPrayTimes_get())}/${Z.M.IntToString(s)+(0,x.T)("次")}`)}Interval(){
if(this.model.MoneyRestActiveTime_get()<=0)return this.moneyFreePray.SetActive(!0),this.moneyVipPray.SetActive(!1),
void(this.intervalId>0&&(T.C.Inst_get().ClearInterval(this.intervalId),this.intervalId=-1))
this.moneyCDLabel.textSet(h.l.GetDateFormat(this.model.MoneyRestActiveTime_get()/1e3)+(0,x.T)("后免费许愿"))}DoHide(){this.scoreSuccessEffect.SetActive(!1),
this.expSuccessEffect.SetActive(!1)}CM_FreeMoneyPray(e,t){}CM_VipMoneyPray(e,t){}CM_VipExpPray(e,t){C.Y.Inst.PrimaryRoleInfo_get().Level_get()
C.Y.Inst.PrimaryRoleInfo_get().Exp_get().ToNum()>=C.Y.Inst.PrimaryRoleInfo_get().CurMaxExp_get()?ee.y.inst.ClientSysMessage(270003):this.model.ExpRestPrayTimes_get()<=0?this.OpenTipView():F.J.GetGold(C.Y.Inst.PrimaryRoleInfo_get(),F.J.GOLD_DIAMOND)>=this.expCost||j.Y.Inst_get().Open()
}PlayPrayEffect(e){1==e?(this.scoreSuccessEffect.SetActive(!1),this.scoreSuccessEffect.SetActive(!0)):(this.expSuccessEffect.SetActive(!1),this.expSuccessEffect.SetActive(!0))}
OpenTipView(){if(ie.U.inst.model.isMaxLevel_get())return void ee.y.inst.ClientSysMessage(270002)
const e="VIP:NO_MORE_WISH_TIMES"
if(te.V.Inst_get().GetData(te.V.Inst_get().GetRolePrefix()+e))this.handler(null)
else{q.L.Inst().getItemById(e)
const t=new $.B
t.infoId=e,t.confirmHandle=this._degf_handler,z.t.Inst().Open(t)}}handler(e){J.t.inst.OpenPanel()}}class ae extends H.Y{constructor(){super(),this.view=null,
this.prayContainer=null,this._degf_OnPrayLoadComplete=null,this._degf_OnPrayLoadComplete=e=>this.OnPrayLoadComplete(e)}static Inst_get(){return null==ae.inst&&(ae.inst=new ae),
ae.inst}InitPrayViewData(e){if(null==this.view){this.prayContainer=e
new O.Z([""])
a.g.LoadOne("ui_pray_prayview",this._degf_OnPrayLoadComplete)}else this.view.OnAddToScene()}OnPrayLoadComplete(e){const t=e[0]
this.view=new se,this.view.setId(t,null,0),this.view.node.transform.SetParent(this.prayContainer.FatherId,this.prayContainer.ComponentId),
r.N.inst.SetChildDepth(le.inst.GetWelfarePanelFatherId(),t),this.view.OnAddToScene()}ClearPrayViewData(){null!=this.view&&this.view.Clear()}DoHide(){
null!=this.view&&this.view.DoHide()}DestroyPrayView(){null!=this.view?(this.view.Clear(),this.view.Destroy(),a.g.DestroyUIObj(this.view),
this.view=null):a.g.Unload(this._degf_OnPrayLoadComplete)}}ae.inst=null
class re extends v.f{constructor(){super(),this.closeBtn=null,this.investBtn=null,this.fundBtn=null,this.prayBtn=null,this.lotteryBtn=null,this.giftBtn=null,this.giftWidget=null,
this.investWidget=null,this.fundWidget=null,this.prayWidget=null,this.lotteryEquipWidget=null,this.investRedPoint=null,this.prayRedPoint=null,this.signBtn=null,
this.signWidget=null,this.signRedPoint=null,this.levelBtn=null,this.levelWidget=null,this.levelRedPoint=null,this.btnPanel=null,this.btnTable=null,this.bg=null,
this.sevenDayBtn=null,this.sevenDayPoint=null,this.sevenDayWidget=null,this.lotteryShopWidget=null,this.lotteryWarehouseWidget=null,this.lotteryEquipBtn=null,
this.lotteryShopBtn=null,this.lotteryWarehouseBtn=null,this.lotteryRedPoint=null,this.lotteryWarehouseRedPoint=null,this.btnScrollView=null,this.warehouseOpenAnim=null,
this.fundRedPoint=null,this.giftRedPoint=null,this.upTran=null,this.lotteryEquipRedPoint=null,this.lotteryExchangeBtn=null,this.lotteryExchangeWidget=null,this.curRoleInfo=null,
this.model=null,this.tabsObj=null,this.tabIds=null,this.buttons=null,this.guideInterval=-1,this.isOne=!0,this._degf_DelayRegGuide=null,this._degf_OnCloseBtnClick=null,
this._degf_OnDailyGiftBtnClick=null,this._degf_OnFundBtnClick=null,this._degf_OnInvestBtnClick=null,this._degf_OnLevelBtnClick=null,this._degf_OnLotteryBtnClick=null,
this._degf_OnLotteryEquipBtnClick=null,this._degf_OnLotteryShopBtnClick=null,this._degf_OnLotteryWarehouseBtnClick=null,this._degf_OnLotteryExchangeBtnClick=null,
this._degf_OnPrayBtnClick=null,this._degf_OnSevenDayBtnClick=null,this._degf_OnSignBtnClick=null,this._degf_UpdateRedPoint=null,this.lotteryWarehousePos=null,
this.lotteryShopPos=null,this.lotteryExchangePos=null,this._degf_DelayRegGuide=()=>this.DelayRegGuide(),this._degf_OnCloseBtnClick=(e,t)=>this.OnCloseBtnClick(e,t),
this._degf_OnDailyGiftBtnClick=(e,t)=>this.OnDailyGiftBtnClick(e,t),this._degf_OnFundBtnClick=(e,t)=>this.OnFundBtnClick(e,t),
this._degf_OnInvestBtnClick=(e,t)=>this.OnInvestBtnClick(e,t),this._degf_OnLevelBtnClick=(e,t)=>this.OnLevelBtnClick(e,t),
this._degf_OnLotteryBtnClick=(e,t)=>this.OnLotteryBtnClick(e,t),this._degf_OnLotteryEquipBtnClick=(e,t)=>this.OnLotteryEquipBtnClick(e,t),
this._degf_OnLotteryShopBtnClick=(e,t)=>this.OnLotteryShopBtnClick(e,t),this._degf_OnLotteryWarehouseBtnClick=(e,t)=>this.OnLotteryWarehouseBtnClick(e,t),
this._degf_OnLotteryExchangeBtnClick=(e,t)=>this.OnLotteryExchangeBtnClick(e,t),this._degf_OnPrayBtnClick=(e,t)=>this.OnPrayBtnClick(e,t),
this._degf_OnSevenDayBtnClick=(e,t)=>this.OnSevenDayBtnClick(e,t),this._degf_OnSignBtnClick=(e,t)=>this.OnSignBtnClick(e,t),
this._degf_UpdateRedPoint=(e,t)=>this.UpdateRedPoint(e,t)}ShowCurrencyBar_get(){if(this.model.viewType!=E.S.LOTTETY&&le.inst.mFuncId!=d.x.LOTTERY)return N._.ShowSome
{const e=k.f.getInst().getShopResourceById(9003)
if(null!=e){if(e.buytype==F.J.GOLD_DIAMOND_STR)return N._.ShowGold_Dia_Lottery
if(e.buytype==F.J.ScoreStr)return N._.ShowScore_Lottery}}}InitView(){super.InitView(),this.isExclusionPanel=!0,this.closeBtn=new A.W,
this.closeBtn.setId(this.FatherId,this.FatherComponentID,1),this.investBtn=new A.W,this.investBtn.setId(this.FatherId,this.FatherComponentID,2),this.fundBtn=new A.W,
this.fundBtn.setId(this.FatherId,this.FatherComponentID,3),this.prayBtn=new A.W,this.prayBtn.setId(this.FatherId,this.FatherComponentID,4),this.lotteryBtn=new A.W,
this.lotteryBtn.setId(this.FatherId,this.FatherComponentID,5),this.giftBtn=new A.W,this.giftBtn.setId(this.FatherId,this.FatherComponentID,34),this.giftWidget=new f.z,
this.giftWidget.setId(this.FatherId,this.FatherComponentID,35),this.investWidget=new f.z,this.investWidget.setId(this.FatherId,this.FatherComponentID,6),this.fundWidget=new f.z,
this.fundWidget.setId(this.FatherId,this.FatherComponentID,7),this.prayWidget=new f.z,this.prayWidget.setId(this.FatherId,this.FatherComponentID,8),this.lotteryEquipWidget=new f.z,
this.lotteryEquipWidget.setId(this.FatherId,this.FatherComponentID,9),this.investRedPoint=new f.z,this.investRedPoint.setId(this.FatherId,this.FatherComponentID,10),
this.prayRedPoint=new f.z,this.prayRedPoint.setId(this.FatherId,this.FatherComponentID,11),this.signBtn=new A.W,this.signBtn.setId(this.FatherId,this.FatherComponentID,12),
this.signWidget=new f.z,this.signWidget.setId(this.FatherId,this.FatherComponentID,13),this.signRedPoint=new f.z,this.signRedPoint.setId(this.FatherId,this.FatherComponentID,14),
this.levelBtn=new A.W,this.levelBtn.setId(this.FatherId,this.FatherComponentID,15),this.levelWidget=new f.z,this.levelWidget.setId(this.FatherId,this.FatherComponentID,16),
this.levelRedPoint=new f.z,this.levelRedPoint.setId(this.FatherId,this.FatherComponentID,17),this.btnPanel=new w.$,this.btnPanel.setId(this.FatherId,this.FatherComponentID,18),
this.btnTable=new R.V,this.btnTable.setId(this.FatherId,this.FatherComponentID,19),this.bg=new f.z,this.bg.setId(this.FatherId,this.FatherComponentID,20),this.sevenDayBtn=new A.W,
this.sevenDayBtn.setId(this.FatherId,this.FatherComponentID,21),this.sevenDayPoint=new f.z,this.sevenDayPoint.setId(this.FatherId,this.FatherComponentID,22),
this.sevenDayWidget=new f.z,this.sevenDayWidget.setId(this.FatherId,this.FatherComponentID,23),this.lotteryShopWidget=new f.z,
this.lotteryShopWidget.setId(this.FatherId,this.FatherComponentID,24),this.lotteryWarehouseWidget=new f.z,
this.lotteryWarehouseWidget.setId(this.FatherId,this.FatherComponentID,25),this.lotteryEquipBtn=new A.W,this.lotteryEquipBtn.setId(this.FatherId,this.FatherComponentID,26),
this.lotteryShopBtn=new A.W,this.lotteryShopBtn.setId(this.FatherId,this.FatherComponentID,27),this.lotteryWarehouseBtn=new A.W,
this.lotteryWarehouseBtn.setId(this.FatherId,this.FatherComponentID,28),this.lotteryRedPoint=new f.z,this.lotteryRedPoint.setId(this.FatherId,this.FatherComponentID,29),
this.lotteryWarehouseRedPoint=new f.z,this.lotteryWarehouseRedPoint.setId(this.FatherId,this.FatherComponentID,30),this.btnScrollView=new y.h,
this.btnScrollView.setId(this.FatherId,this.FatherComponentID,31),this.warehouseOpenAnim=new L.k,this.warehouseOpenAnim.setId(this.FatherId,this.FatherComponentID,32),
this.fundRedPoint=new f.z,this.fundRedPoint.setId(this.FatherId,this.FatherComponentID,33),this.giftRedPoint=new f.z,
this.giftRedPoint.setId(this.FatherId,this.FatherComponentID,36),this.upTran=new D.G,this.upTran.setId(this.FatherId,this.FatherComponentID,37),this.lotteryEquipRedPoint=new f.z,
this.lotteryEquipRedPoint.setId(this.FatherId,this.FatherComponentID,38),this.lotteryExchangeBtn=new A.W,this.lotteryExchangeBtn.setId(this.FatherId,this.FatherComponentID,39),
this.lotteryExchangeWidget=new f.z,this.lotteryExchangeWidget.setId(this.FatherId,this.FatherComponentID,40),this.curRoleInfo=C.Y.Inst.PrimaryRoleInfo_get(),
this.model=I.u.Inst_get(),this.lotteryWarehousePos=this.lotteryWarehouseBtn.node.transform.GetLocalPosition(),
this.lotteryShopPos=this.lotteryShopBtn.node.transform.GetLocalPosition(),this.lotteryExchangePos=this.lotteryExchangeBtn.node.transform.GetLocalPosition()
let e=S.V.Inst().getStr2(10901)
this.lotteryBtn.SetText(e),e=S.V.Inst().getStr2(10902),this.lotteryEquipBtn.SetText(e),e=S.V.Inst().getStr2(10903),this.lotteryShopBtn.SetText(e),e=S.V.Inst().getStr2(10904),
this.lotteryWarehouseBtn.SetText(e)}InitTab(){this.InitBtnAndTabIdsState(),this.tabsObj=null,this.tabsObj=new G.G(this.buttons,this.tabIds,null,this.node,this.btnTable,!1),
this.tabsObj.RefreshTab(!0)}InitBtnAndTabIdsState(){const e=le.inst.mFuncId
this.signBtn.node.SetActive(this.GetChildFuncById(e,d.x.SIGN)),this.levelBtn.node.SetActive(this.GetChildFuncById(e,d.x.LEVEL_REWARD)),
this.prayBtn.node.SetActive(this.GetChildFuncById(e,d.x.PRAY)),this.lotteryBtn.node.SetActive(this.GetChildFuncById(e,d.x.LOTTERY))
const t=this.GetChildTabIds(e)
this.tabIds=new O.Z,this.buttons=new O.Z
let i=0
for(;i<t.Count();)t[i]==d.x.SIGN?(this.tabIds[i]=b.Z.WELFARE_SIGN,this.buttons[i]=this.signBtn):t[i]==d.x.OPERATING_ACTIVITY?(this.tabIds[i]=b.Z.WELFARE_SEVENDAY,
this.buttons[i]=this.sevenDayBtn):t[i]==d.x.LEVEL_REWARD?(this.tabIds[i]=b.Z.WELFARE_LEVELREWARD,this.buttons[i]=this.levelBtn):t[i]==d.x.DAILYGIFT?(this.tabIds[i]=b.Z.DAILYGIFT,
this.buttons[i]=this.giftBtn):t[i]==d.x.PRAY?(this.tabIds[i]=b.Z.WELFARE_PRAY,this.buttons[i]=this.prayBtn):t[i]==d.x.LOTTERY&&(this.tabIds[i]=b.Z.WELFARE_LOTTERY,
this.buttons[i]=this.lotteryBtn),i+=1}GetChildFuncById(e,t){if(e==d.x.LOTTERY||e==d.x.FINANCING){if(t==d.x.DAILYGIFT)return!0
if(t==d.x.PRAY)return!0
if(t==d.x.LOTTERY)return!0
if(t==d.x.LEVEL_REWARD)return!0
if(t==d.x.SIGN)return!0}return!1}GetChildTabIds(e){const t=new O.Z
return e!=d.x.LOTTERY&&e!=d.x.FINANCING||(t.Add(d.x.PRAY),t.Add(d.x.SIGN),t.Add(d.x.OPERATING_ACTIVITY),t.Add(d.x.LEVEL_REWARD),t.Add(d.x.LOTTERY)),t}GetFatherFuncIdByChildType(){
return-1}DoHide(){super.DoHide(),ae.Inst_get().DoHide()}OnAddToScene(){T.C.Inst_get().ClearInterval(this.guideInterval),
this.guideInterval=T.C.Inst_get().SetInterval(this._degf_DelayRegGuide,300,1),this.addLis(),this.ShowViewByType(this.model.viewType),pointData=g.f.Inst.GetData(p.t.PRAY),
null!=pointData&&this.prayRedPoint.SetActive(pointData.show),this.signRedPoint.SetActive(t_isShow),pointData=g.f.Inst.GetData(p.t.LEVEL_REWARD),
null!=pointData&&this.levelRedPoint.SetActive(pointData.show),pointData=g.f.Inst.GetData(p.t.LOTTERY),null!=pointData&&this.lotteryRedPoint.SetActive(pointData.show),
pointData=g.f.Inst.GetData(p.t.LOTTERYWAREHOUSE),null!=pointData&&this.lotteryWarehouseRedPoint.SetActive(pointData.show),pointData=g.f.Inst.GetData(p.t.LOTTERYEQUIP),pointData}
DelayRegGuide(){}Clear(){this.model.isCurShowLottery=!1,this.removeLis(),T.C.Inst_get().ClearInterval(this.guideInterval),ae.Inst_get().ClearPrayViewData()}Destroy(){
this.closeBtn=null,this.investBtn=null,this.fundBtn=null,this.prayBtn=null,this.lotteryBtn=null,this.investRedPoint=null,this.prayRedPoint=null,this.signBtn=null,
this.signWidget=null,this.signRedPoint=null,this.levelBtn=null,this.levelWidget=null,this.levelRedPoint=null,this.sevenDayBtn=null,this.sevenDayPoint=null,this.sevenDayWidget=null,
this.btnPanel=null,this.btnTable=null,this.btnScrollView=null,this.lotteryEquipBtn=null,this.lotteryShopBtn=null,this.lotteryWarehouseBtn=null,this.lotteryExchangeBtn=null,
this.lotteryShopWidget=null,this.lotteryWarehouseWidget=null,this.lotteryExchangeWidget=null,this.warehouseOpenAnim=null,this.fundRedPoint=null,this.fundWidget=null,
this.investWidget=null,ae.Inst_get().DestroyPrayView(),this.prayWidget=null,this.lotteryEquipWidget=null,null!=this.tabsObj&&(this.tabsObj.Destroy(),this.tabsObj=null),
this.lotteryWarehousePos=null,this.lotteryShopPos=null,this.lotteryExchangePos=null}ShowViewByType(e,t){null==t&&(t=!1)
let i=0
t||(le.inst.mFuncId=this.GetFatherFuncIdByChildType()),this.InitTab(),t?le.inst.mFuncId!=d.x.INVESTMENT&&le.inst.mFuncId!=d.x.FINANCING&&le.inst.mFuncId!=d.x.LOTTERY||(i=M.B.GetDefaultViewType(this.tabIds,re.redPointIds1,re.redPointTabIds1)):i=e,
i==E.S.FUND?this.OnFundBtnClick(0,0):i==E.S.LOTTETY?this.OnLotteryBtnClick(0,0):i==E.S.INVSET?this.OnInvestBtnClick(0,0):i==E.S.PRAY?this.OnPrayBtnClick(0,0):i==E.S.SIGN?this.OnSignBtnClick(0,0):i==E.S.LEVEL?this.OnLevelBtnClick(0,0):i==E.S.SEVEN_DAY?this.OnSevenDayBtnClick(0,0):i==E.S.DAILYGIFT&&this.OnDailyGiftBtnClick(0,0)
}IsClickLottery(e){if(null==e&&(e=!1),e){this.lotteryEquipBtn.node.SetActive(!0),this.lotteryWarehouseBtn.node.SetActive(!0),this.lotteryExchangeBtn.node.SetActive(!0)
const e=c.P.Inst_get().IsFunctionOpened(d.x.LOTTERY_SHOP)
this.lotteryShopBtn.node.SetActive(e),e?(this.lotteryWarehouseBtn.node.transform.SetLocalPosition(this.lotteryWarehousePos),
this.lotteryExchangeBtn.node.transform.SetLocalPosition(this.lotteryExchangeBtn)):(this.lotteryWarehouseBtn.node.transform.SetLocalPosition(this.lotteryShopPos),
this.lotteryExchangeBtn.node.transform.SetLocalPosition(this.lotteryWarehousePos))}else this.lotteryEquipBtn.node.SetActive(!1),this.lotteryShopBtn.node.SetActive(!1),
this.lotteryWarehouseBtn.node.SetActive(!1),this.lotteryExchangeBtn.node.SetActive(!1)
this.btnTable.Reposition()}HideBtnAndWidget(){const e=B.I.calVec0
e.Set(0,1e3,0),this.investWidget.transform.SetLocalPosition(e),this.fundWidget.transform.SetLocalPosition(e),this.prayWidget.transform.SetLocalPosition(e),
this.signWidget.transform.SetLocalPosition(e),this.levelWidget.transform.SetLocalPosition(e),this.sevenDayWidget.transform.SetLocalPosition(e),
this.giftWidget.transform.SetLocalPosition(e),this.investBtn.SetIsEnabled(!0),this.fundBtn.SetIsEnabled(!0),this.prayBtn.SetIsEnabled(!0),this.lotteryBtn.SetIsEnabled(!0),
this.signBtn.SetIsEnabled(!0),this.levelBtn.SetIsEnabled(!0),this.sevenDayBtn.SetIsEnabled(!0),this.giftBtn.SetIsEnabled(!0),ae.Inst_get().ClearPrayViewData(),
this.HideLotteryBtnAndWidget()}addLis(){this.AddClickEvent(this.fundBtn,this._degf_OnFundBtnClick),this.AddClickEvent(this.investBtn,this._degf_OnInvestBtnClick),
this.AddClickEvent(this.prayBtn,this._degf_OnPrayBtnClick),this.AddClickEvent(this.lotteryBtn,this._degf_OnLotteryBtnClick),
this.AddClickEvent(this.closeBtn,this._degf_OnCloseBtnClick),this.AddClickEvent(this.signBtn,this._degf_OnSignBtnClick),
this.AddClickEvent(this.levelBtn,this._degf_OnLevelBtnClick),this.AddClickEvent(this.sevenDayBtn,this._degf_OnSevenDayBtnClick),
this.AddClickEvent(this.lotteryEquipBtn,this._degf_OnLotteryEquipBtnClick),this.AddClickEvent(this.lotteryShopBtn,this._degf_OnLotteryShopBtnClick),
this.AddClickEvent(this.lotteryWarehouseBtn,this._degf_OnLotteryWarehouseBtnClick),this.AddClickEvent(this.lotteryExchangeBtn,this._degf_OnLotteryExchangeBtnClick),
this.AddClickEvent(this.giftBtn,this._degf_OnDailyGiftBtnClick),g.f.Inst.AddCallback(p.t.PRAY,this._degf_UpdateRedPoint),
g.f.Inst.AddCallback(p.t.LEVEL_REWARD,this._degf_UpdateRedPoint),g.f.Inst.AddCallback(p.t.LOTTERY,this._degf_UpdateRedPoint),
g.f.Inst.AddCallback(p.t.LOTTERYWAREHOUSE,this._degf_UpdateRedPoint),g.f.Inst.AddCallback(p.t.LOTTERYEQUIP,this._degf_UpdateRedPoint)}removeLis(){
this.RemoveClickEvent(this.fundBtn,this._degf_OnFundBtnClick),this.RemoveClickEvent(this.investBtn,this._degf_OnInvestBtnClick),
this.RemoveClickEvent(this.prayBtn,this._degf_OnPrayBtnClick),this.RemoveClickEvent(this.lotteryBtn,this._degf_OnLotteryBtnClick),
this.RemoveClickEvent(this.closeBtn,this._degf_OnCloseBtnClick),this.RemoveClickEvent(this.signBtn,this._degf_OnSignBtnClick),
this.RemoveClickEvent(this.levelBtn,this._degf_OnLevelBtnClick),this.RemoveClickEvent(this.sevenDayBtn,this._degf_OnSevenDayBtnClick),
this.RemoveClickEvent(this.lotteryEquipBtn,this._degf_OnLotteryEquipBtnClick),this.RemoveClickEvent(this.lotteryShopBtn,this._degf_OnLotteryShopBtnClick),
this.RemoveClickEvent(this.lotteryWarehouseBtn,this._degf_OnLotteryWarehouseBtnClick),this.RemoveClickEvent(this.lotteryExchangeBtn,this._degf_OnLotteryExchangeBtnClick),
this.RemoveClickEvent(this.giftBtn,this._degf_OnDailyGiftBtnClick),g.f.Inst.RemoveCallback(p.t.PRAY,this._degf_UpdateRedPoint),
g.f.Inst.RemoveCallback(p.t.LEVEL_REWARD,this._degf_UpdateRedPoint),g.f.Inst.RemoveCallback(p.t.LOTTERY,this._degf_UpdateRedPoint),
g.f.Inst.RemoveCallback(p.t.LOTTERYWAREHOUSE,this._degf_UpdateRedPoint),g.f.Inst.RemoveCallback(p.t.LOTTERYEQUIP,this._degf_UpdateRedPoint)}OnFundBtnClick(e,t){
m.T.inst_get().control.ForceCloseExpForMapJudge(),U.w.Instance.RaiseEvent(U.w.eUpdateCurrency,N._.ShowSome),this.HideBtnAndWidget(),this.fundBtn.SetIsEnabled(!1)
const i=P.P.zero_get()
this.fundWidget.transform.SetLocalPosition(i),P.P.Recyle(i),this.bg.SetActive(!0),this.NoLotteryViewShow()}OnLevelBtnClick(e,t){m.T.inst_get().control.ForceCloseExpForMapJudge(),
U.w.Instance.RaiseEvent(U.w.eUpdateCurrency,N._.ShowSome),this.HideBtnAndWidget(),this.levelBtn.SetIsEnabled(!1)
const i=P.P.zero_get()
this.levelWidget.transform.SetLocalPosition(i),P.P.Recyle(i),this.bg.SetActive(!0),this.NoLotteryViewShow()}OnSevenDayBtnClick(e,t){
m.T.inst_get().control.ForceCloseExpForMapJudge(),U.w.Instance.RaiseEvent(U.w.eUpdateCurrency,N._.ShowSome),this.HideBtnAndWidget(),this.sevenDayBtn.SetIsEnabled(!1)
const i=P.P.zero_get()
this.sevenDayWidget.transform.SetLocalPosition(i),P.P.Recyle(i),this.bg.SetActive(!1),this.NoLotteryViewShow()}OnDailyGiftBtnClick(e,t){
m.T.inst_get().control.ForceCloseExpForMapJudge(),U.w.Instance.RaiseEvent(U.w.eUpdateCurrency,N._.ShowSome),this.HideBtnAndWidget(),this.giftBtn.SetIsEnabled(!1)
const i=P.P.zero_get()
this.giftWidget.transform.SetLocalPosition(i),P.P.Recyle(i),this.bg.SetActive(!0),this.NoLotteryViewShow()}NoLotteryViewShow(){
(this.isOne||this.model.isCurShowLottery)&&(this.isOne=!1,this.model.isCurShowLottery=!1,this.IsClickLottery(),this.UpdateScrollView())}CheckBtnsDepth(){
U.w.Instance.RaiseEvent(U.w.eUpdateCurrency,N._.ShowSome),r.N.inst.ChangeDepthValue(this.FatherId,this.btnPanel.ComponentId,30)}OnSignBtnClick(e,t){
m.T.inst_get().control.ForceCloseExpForMapJudge(),U.w.Instance.RaiseEvent(U.w.eUpdateCurrency,N._.ShowSome),this.HideBtnAndWidget(),this.signBtn.SetIsEnabled(!1)
const i=P.P.zero_get()
this.signWidget.transform.SetLocalPosition(i),P.P.Recyle(i),this.bg.SetActive(!0),this.NoLotteryViewShow()}OnInvestBtnClick(e,t){m.T.inst_get().control.ForceCloseExpForMapJudge(),
U.w.Instance.RaiseEvent(U.w.eUpdateCurrency,N._.ShowSome),this.HideBtnAndWidget(),this.investBtn.SetIsEnabled(!1)
const i=P.P.zero_get()
this.investWidget.transform.SetLocalPosition(i),P.P.Recyle(i),this.bg.SetActive(!0),this.NoLotteryViewShow()}OnPrayBtnClick(e,t){m.T.inst_get().control.ForceOpenExpForMapJudge(),
U.w.Instance.RaiseEvent(U.w.eUpdateCurrency,N._.ShowSome),this.HideBtnAndWidget(),this.prayBtn.SetIsEnabled(!1)
const i=P.P.zero_get()
this.prayWidget.transform.SetLocalPosition(i),P.P.Recyle(i),ae.Inst_get().InitPrayViewData(this.prayWidget),this.bg.SetActive(!1),this.NoLotteryViewShow()}OnLotteryBtnClick(e,t){
m.T.inst_get().control.ForceCloseExpForMapJudge()
const i=k.f.getInst().getShopResourceById(9003)
null!=i&&(i.buytype==F.J.GOLD_DIAMOND_STR?U.w.Instance.RaiseEvent(U.w.eUpdateCurrency,N._.ShowGold_Dia_Lottery):i.buytype==F.J.ScoreStr&&U.w.Instance.RaiseEvent(U.w.eUpdateCurrency,N._.ShowScore_Lottery)),
this.HideBtnAndWidget(),this.model.isCurShowLottery=!0,this.lotteryBtn.SetIsEnabled(!1),this.IsClickLottery(!0),this.bg.SetActive(!1),this.UpdateScrollView(!1)}UpdateScrollView(e){
null==e&&(e=!1),this.btnScrollView.UpdateScrollbars(),e?this.btnScrollView.SetDragAmount(0,1,!0):this.btnScrollView.SetDragAmount(0,0,!0)}HideLotteryBtnAndWidget(){
this.lotteryEquipWidget.SetActive(!1),this.lotteryShopWidget.SetActive(!1),this.lotteryWarehouseWidget.SetActive(!1),this.lotteryExchangeWidget.SetActive(!1),
this.lotteryEquipBtn.SetIsEnabled(!0),this.lotteryShopBtn.SetIsEnabled(!0),this.lotteryWarehouseBtn.SetIsEnabled(!0),this.lotteryExchangeBtn.SetIsEnabled(!0)}
OnLotteryWarehouseBtnClick(e,t){this.HideLotteryBtnAndWidget(),this.lotteryWarehouseBtn.SetIsEnabled(!1),this.lotteryWarehouseWidget.SetActive(!0)}OnLotteryExchangeBtnClick(e,t){
this.HideLotteryBtnAndWidget(),this.lotteryExchangeBtn.SetIsEnabled(!1),this.lotteryExchangeWidget.SetActive(!0)}OnLotteryShopBtnClick(e,t){this.HideLotteryBtnAndWidget(),
this.lotteryShopBtn.SetIsEnabled(!1),this.lotteryShopWidget.SetActive(!0)}OnLotteryEquipBtnClick(e,t){this.HideLotteryBtnAndWidget(),this.lotteryEquipBtn.SetIsEnabled(!1),
this.lotteryEquipWidget.SetActive(!0)}OnCloseBtnClick(e,t){le.inst.CloseView()}UpdateRedPoint(e,t){
e==p.t.PRAY?this.prayRedPoint.SetActive(t):e==p.t.LEVEL_REWARD?this.levelRedPoint.SetActive(t):e==p.t.LOTTERY||(e==p.t.LOTTERYWAREHOUSE?this.lotteryWarehouseRedPoint.SetActive(t):p.t.LOTTERYEQUIP)
}ShowWarehouseOpenAnim(){this.warehouseOpenAnim.node.SetActive(!0),this.warehouseOpenAnim.SetResetOnPlay(!0),this.warehouseOpenAnim.Play(!0,!1)}SetBarScrollBarBottomVal(){
this.btnScrollView.SetDragAmount(0,0,!0)}DoReShow(){super.DoReShow()}}re.redPointIds1=new O.Z([p.t.PRAY,p.t.LEVEL_REWARD,p.t.DAILYGIFT,p.t.LOTTERY]),
re.redPointTabIds1=new O.Z([b.Z.WELFARE_PRAY,b.Z.WELFARE_LEVELREWARD,b.Z.DAILYGIFT,b.Z.WELFARE_LOTTERY])
class le{static get inst(){return null==le._inst&&(le._inst=new le),le._inst}constructor(){this.xunbaoID=5001,this.view=null,this.topUseDefaultTab=!1,this.mFuncId=0,
this._degf_BagUpdateHandler=null,this._degf_CallDestory=null,this._degf_SM_ExpPrayHandle=null,this._degf_SM_MoneyPrayHandle=null,this._degf_ShowlComplete=null,
this._degf_BagUpdateHandler=e=>this.BagUpdateHandler(e),this._degf_CallDestory=()=>this.CallDestory(),this._degf_SM_ExpPrayHandle=e=>this.SM_ExpPrayHandle(e),
this._degf_SM_MoneyPrayHandle=e=>this.SM_MoneyPrayHandle(e),this._degf_ShowlComplete=e=>this.ShowlComplete(e),this.AddLis(),
n.i.Inst.AddEventHandler(u.g.BAG_UPDATE,this._degf_BagUpdateHandler)}AddLis(){}BagUpdateHandler(e){const t=_.g.Inst_get().GetItemNum(this.xunbaoID)
g.f.Inst.SetState(p.t.LOTTERYEQUIP,t>0)}SM_MoneyPrayHandle(e){}SM_ExpPrayHandle(e){}OpenView(e,t){if(null==t&&(t=!1),null==e&&(e=0),this.topUseDefaultTab=t,this.mFuncId=e,
t)this.Open()
else{const e=this.GetFuncIdByViewType()
c.P.Inst_get().IsFuncOrActivityOpened(e)||-1==e?this.Open():h.l.SetFunctionTip(e)}}Open(){
if(null!=this.view&&this.view.isShow_get())this.view.ShowViewByType(I.u.Inst_get().viewType)
else{const e=new s.v
e.isShowMask=!0,e.isDefaultUITween=!0,e.noTweenDirIndex=o.K.ExpbarDown,r.N.inst.OpenById(l.I.WelfarePanelId,this._degf_ShowlComplete,this._degf_CallDestory,e)}
I.u.Inst_get().viewType!=E.S.PRAY&&m.T.inst_get().control.ForceCloseExpForMapJudge()}CloseView(){m.T.inst_get().control.ForceOpenExpForMapJudge(),r.N.inst.ClosePanel(this.view),
this.mFuncId=0}ShowlComplete(e){return null==this.view&&(this.view=new re,this.view.setId(e,null,0)),this.view}CallDestory(){a.g.DestroyUIObj(this.view),this.view=null}
GetWelfarePanelFatherId(){return null!=this.view?this.view.FatherId:0}GetFuncIdByViewType(){
return I.u.Inst_get().viewType==E.S.SIGN?d.x.SIGN:I.u.Inst_get().viewType==E.S.PRAY?d.x.PRAY:I.u.Inst_get().viewType==E.S.LOTTETY?d.x.LOTTERY:I.u.Inst_get().viewType==E.S.LEVEL?d.x.LEVEL_REWARD:I.u.Inst_get().viewType==E.S.TIREDVALUE?d.x.DAILY_TIRED:I.u.Inst_get().viewType==E.S.CDK?d.x.WELFARE_CDK:-1
}GetViewTypeByFuncId(e){
return e==d.x.SIGN?E.S.SIGN:e==d.x.PRAY?E.S.PRAY:e==d.x.LOTTERY?E.S.LOTTETY:e==d.x.INVEST?E.S.INVSET:e==d.x.LEVEL_REWARD?E.S.LEVEL:e==d.x.OPERATING_ACTIVITY?E.S.SEVEN_DAY:e==d.x.DAILYGIFT?E.S.DAILYGIFT:e==d.x.WELFARE_CDK?E.S.CDK:-1
}SelectLotteryWarehouse(){null!=this.view&&I.u.Inst_get().isCurShowLottery&&this.view.OnLotteryWarehouseBtnClick(0,0)}ShowWarehouseOpenAnim(){
null!=this.view&&this.view.ShowWarehouseOpenAnim()}SetBarScrollBarBottomVal(){null!=this.view&&this.view.SetBarScrollBarBottomVal()}}le._inst=null},71893:(e,t,i)=>{"use strict"
i.d(t,{u:()=>I})
var n=i(97461),s=i(68662),a=i(16812),r=i(62370),l=i(5924),o=i(39950),_=i(98130),u=i(98885),h=i(92679),c=i(75439),d=i(14792),m=i(62734),p=i(12417),g=i(84141)
class I extends a.k{constructor(){super(!1,_.GF.INT(o.Y.eUISingleton)),this.viewType=-1,this.isCurShowLottery=!1,this.prayTimerId=0,this.startServerTime=0,this.expRestPrayTimes=0,
this.moneyRestActiveTime=0,this.moneyRestPrayTimes=0,this.isLunch=!1,this.isSupper=!1,this.isLunchOverdue=!1,this.isSupperOverdue=!1,this._degf_PrayTimerHandle=null,
this.timeInfo=null,this._degf_PrayTimerHandle=()=>this.PrayTimerHandle()
const e={},t=c.D.getInstance().getContent("BOSSINFO:BOSS_TIRED_SUPPLY_TIME").getContent().arrayVal,i=u.M.Split(u.M.Replace(t[0],u.M.s_STRING_CHAR_DOT,""),r.o.s_Arr_UNDER_CHAR_DOT),n=u.M.Split(i[0],r.o.s_Arr_UNDER_COLON)
e.hour1=u.M.String2Int(n[0]),e.min1=u.M.String2Int(n[1])
const s=u.M.Split(u.M.Replace(t[1],u.M.s_STRING_CHAR_DOT,""),r.o.s_Arr_UNDER_CHAR_DOT),a=u.M.Split(s[0],r.o.s_Arr_UNDER_COLON)
e.hour2=u.M.String2Int(a[0]),e.min2=u.M.String2Int(a[1]),this.timeInfo=e}static Inst_get(){return null==I._Inst&&(I._Inst=new I),I._Inst}Clear(){this.ClearPrayTimer()}
DailyTiredInfo_set(){const e=p._.Inst().HasDailyReward_get(),t=g.E.New()
t.time_set(s.D.serverMSTime_get())
const i=3600*t.hours_get()+60*t.minutes_get()+t.seconds_get()
this.isLunch=!1,(i>=3600*this.timeInfo.hour1+60*this.timeInfo.min1||i<18e3)&&(this.isLunch=!0),this.isSupper=!1,
(i>=3600*this.timeInfo.hour2+60*this.timeInfo.min2||i<18e3)&&(this.isSupper=!0),
(this.isLunch||this.isSupper)&&(-1==e.IndexOf(0)&&this.isLunch||-1==e.IndexOf(1)&&this.isSupper)?m.f.Inst.SetState(d.t.TIREDVALUE,!0):m.f.Inst.SetState(d.t.TIREDVALUE,!1),
g.E.Recycle(t)}ExpRestPrayTimes_get(){return this.expRestPrayTimes}ExpRestPrayTimes_set(e){this.expRestPrayTimes=e}MoneyRestActiveTime_get(){return this.moneyRestActiveTime}
MoneyRestActiveTime_set(e){this.moneyRestActiveTime=e,this.moneyRestActiveTime<=0?(this.ClearPrayTimer(),this.moneyRestPrayTimes=0,n.i.Inst.RaiseEvent(h.g.PRAY_UPDATE),
m.f.Inst.SetState(d.t.PRAY,!0)):this.AddPrayTimer(this.moneyRestActiveTime)}MoneyRestPrayTimes_get(){return this.moneyRestPrayTimes}MoneyRestPrayTimes_set(e){
this.moneyRestPrayTimes=e}AddPrayTimer(e){e>0&&(this.startServerTime=s.D.serverMSTime_get(),
0==this.prayTimerId&&(this.prayTimerId=l.C.Inst_get().SetInterval(this._degf_PrayTimerHandle,500)))}PrayTimerHandle(){const e=s.D.serverMSTime_get()-this.startServerTime
this.MoneyRestActiveTime_set(this.moneyRestActiveTime-e)}ClearPrayTimer(){this.prayTimerId>0&&(l.C.Inst_get().ClearInterval(this.prayTimerId),this.prayTimerId=0)}ResetModel(){
this.viewType=-1,this.isCurShowLottery=!1}}I._Inst=null},95155:(e,t,i)=>{"use strict"
i.d(t,{S:()=>n})
class n{}n.LEVEL=0,n.DAILY_TOTAL_RECHARGE=1,n.LOTTETY=2,n.MONTH_CARD=3,n.DAILY_RECHARGE=4,n.PASSREWARD=5,n.REDPACKET=6,n.TIREDVALUE=7,n.RECOVER=8,n.CDK=9,n.ANGEL_FIGHT_TOKEN=10,
n.LEVEL_REWARD=11,n.PRAY=0},89921:(e,t,i)=>{"use strict"
i.d(t,{S:()=>R})
var n=i(38836),s=i(98800),a=i(62370),r=i(18202),l=i(31222),o=i(5494),_=i(98885),u=i(1240),h=i(21554),c=i(33314),d=i(74045),m=i(49067),p=i(75439),g=i(48481),I=i(86133),E=i(96098),C=i(36241),S=i(9986),T=i(93877),f=i(61911),A=i(53824)
class y extends f.f{constructor(){super(),this.closeBtn=null,this.tipLabel=null,this.wingItem=null,this.getBtn=null,this.wingData=null,this._degf_OnClose=null,
this._degf_OnGet=null,this._degf_OnClose=(e,t)=>this.OnClose(e,t),this._degf_OnGet=(e,t)=>this.OnGet(e,t)}InitView(){this.closeBtn=new S.W,
this.closeBtn.setId(this.FatherId,this.FatherComponentID,1),this.tipLabel=new T.Q,this.tipLabel.setId(this.FatherId,this.FatherComponentID,2),this.wingItem=new A.Z,
this.wingItem.setBinderId(this.FatherId,this.FatherComponentID,3),this.getBtn=new S.W,this.getBtn.setId(this.FatherId,this.FatherComponentID,4)}Destroy(){this.closeBtn=null,
this.tipLabel=null,this.wingItem.Destroy(),this.wingItem=null,this.getBtn=null}OnAddToScene(){this.AddListeners(),this.tipLabel.textSet((0,I.T)("需要穿戴翅膀才能进入天空之城！")),
this.wingData=this.GetWingData(),this.wingItem.SetData(this.wingData),C._.getInst().CloseStartIcon()}Clear(){this.RemoveListeners(),this.wingItem.Clear(),this.wingData=null,
E.B.Inst.Reset(!0)}AddListeners(){this.AddClickEvent(this.closeBtn,this._degf_OnClose),this.AddClickEvent(this.getBtn,this._degf_OnGet)}RemoveListeners(){
this.RemoveClickEvent(this.closeBtn,this._degf_OnClose),this.RemoveClickEvent(this.getBtn,this._degf_OnGet)}OnClose(e,t){R.inst_get().CloseView()}OnGet(e,t){
const i=this.GetBagItemData(this.wingData.baseData_get().modelId_get())
i.baseData_get().autoGetInTip=!0,h.J.Inst_get().ShowItemTip(i.baseData_get())}GetWingData(){let e=null
const t=c.Z.GetJobBaseValue(s.Y.Inst.PrimaryRoleInfo_get().Job_get()),i=p.D.getInstance().getContent("NOTICE:ENTER_SKYCITY_ACCESS"),r=_.M.Split(i.getContent().stringVal,_.M.s_CCD_CHAR)
if(null!=r&&0!=r.count)for(const[i,s]of(0,n.V5)(r)){const i=_.M.Split(s,a.o.s_UNDER_CHAR)
if(null!=i&&2==i.count){if(_.M.String2Int(i[0])==t){e=this.GetBagItemData(_.M.String2Int(i[1]))
break}}}return e}GetBagItemData(e){const t=new g.t
t.modelId=e,t.num=1
const i=new u.Y
return i.serverData_set(t),i.baseData_get().isCanOperate=!1,i.baseData_get().isEquipCompare=!1,i}}class R{constructor(){this.view=null,this.itemId=0,this._degf_CallComplete=null,
this._degf_CallDestory=null,this._degf_OnGet=null,this._degf_CallComplete=e=>this.CallComplete(e),this._degf_CallDestory=()=>this.CallDestory(),
this._degf_OnGet=(e,t)=>this.OnGet(e,t)}static inst_get(){return null==R._inst&&(R._inst=new R),R._inst}OpenView(){
null!=this.view&&this.view.isShow_get()||(this.itemId=this.GetWingData(),this.ShowTipGetWing(this.itemId))}GetWingData(){let e=null
const t=c.Z.GetJobBaseValue(s.Y.Inst.PrimaryRoleInfo_get().Job_get()),i=p.D.getInstance().getContent("NOTICE:ENTER_SKYCITY_ACCESS"),r=_.M.Split(i.getContent().stringVal,_.M.s_CCD_CHAR)
if(null!=r&&0!=r.count)for(const[i,s]of(0,n.V5)(r)){const i=_.M.Split(s,a.o.s_UNDER_CHAR)
if(null!=i&&2==i.count){if(_.M.String2Int(i[0])==t){e=_.M.String2Int(i[1])
break}}}return e}ShowTipGetWing(e){const t=new m.B
t.infoId="MAP:ENTER_NEED_WINGS_NO",t.confirmParam=e,t.confirmHandle=this._degf_OnGet,t.isCancelForCheckBox=!0,t.tipstype=1,t.dontClose=!0,t.confirmText="获取翅膀",
t.replaceParams.Add(_.M.IntToString(e)),t.replaceParams.Add(""),d.t.Inst().Open(t)}GetBagItemData(e){const t=new g.t
t.modelId=e,t.num=1
const i=new u.Y
return i.serverData_set(t),i.baseData_get().isCanOperate=!1,i.baseData_get().isEquipCompare=!1,i}CallComplete(e){return null==this.view&&(this.view=new y,
this.view.setId(e,null,0)),this.view}CallDestory(){r.g.DestroyUIObj(this.view),this.view=null}OnGet(e,t){const i=this.GetBagItemData(this.itemId)
i.baseData_get().autoGetInTip=!0,h.J.Inst_get().ShowItemTip(i.baseData_get())}CloseView(){null!=this.view&&this.view.isShow_get()&&l.N.inst.CloseById(o.I.eGetWingPanel)}}
R._inst=null},82400:(e,t,i)=>{"use strict"
i.d(t,{s:()=>g})
var n=i(38836),s=i(86133),a=i(98800),r=i(16812),l=i(38935),o=i(39950),_=i(98130),u=i(98885),h=i(85602),c=i(38962),d=i(92679),m=i(20641),p=i(21790)
class g extends r.k{constructor(){super(!1,_.GF.INT(o.Y.eUISingleton)),this.item=null,this.SelectIsShow=!1,this.WithOneShopId=1,this.withOneShopBuyList=null,
this.withOneShopReturnBuyList=null,this.PageItemNum=10,this.curPageNum=0,this.curShowView=0,this.LoseStr=null,this.CoinTypeNum=1,this.ReturnItemMaxNum=40,
this.buyIItemLoseTime=null,this.returnBagFullStr=null,this._degf_Fun=null,this.LoseStr=(0,s.T)("后无法回购"),this.returnBagFullStr=(0,s.T)("当前回购商店已满！继续出售将清除最早出售的物品，是否继续？"),
this._degf_Fun=(e,t)=>this.Fun(e,t),this.WithOneShopBuyList_set(new h.Z)
const e=a.Y.Inst.PrimaryRoleInfo_get()
this.WithOneShopBuyList_set(m.f.getInst().getShopListByShopId(this.WithOneShopId,e.Level_get())),this.WithOneShopReturnBuyList_set(new h.Z),this.buyIItemLoseTime=new c.X}
static Inst_get(){return null==g._Inst&&(g._Inst=new g),g._Inst}WithOneShopReturnBuyList_get(){return this.withOneShopReturnBuyList}WithOneShopReturnBuyList_set(e){
this.withOneShopReturnBuyList=e,this.RaiseEvent(d.g.ReturnBuyListUpdate,this)}WithOneShopBuyList_get(){return this.withOneShopBuyList}WithOneShopBuyList_set(e){
this.withOneShopBuyList=e,null!=this.withOneShopBuyList&&(this.ItemSort(this.withOneShopBuyList),this.RaiseEvent(d.g.BuyListUpdate,this))}ItemSort(e){
return 0==e.Count()?null:(e.Sort(this._degf_Fun),e)}Fun(e,t){return e.order>t.order?1:e.order<t.order?-1:0}GetItemTotalPage(e,t){const i=_.GF.INT(e.Count()/t),n=e.Count()%t
return i>0?0==n?i:i+1:1}GetItemTotalPageEx(e,t){const i=_.GF.INT(e.Count()/t),n=e.Count()%t
return i>0?0==n?i:i+1:1}SendShopBuy(e,t){const i=new p.n
i.ShopItemId=e,i.CountNum=t,l.C.Inst.F_SendMsg(i)}SendBuyBack(e,t){}GetItemDic(e){const t=new c.X
let i=0,s=""
for(const[a,r]of(0,n.vy)(e))i=a.ToNum(),s=u.M.DoubleToString(i),t.LuaDic_AddOrSetItem(s,e[a])
return t}GetAbsList(e){const t=new h.Z
let i=0
for(;i<e.count;)null!=e[i]&&t.Add(e[i]),i+=1
return t}GetReturnListFull(){return this.withOneShopReturnBuyList.Count()>=this.ReturnItemMaxNum}UpdateData(){const e=a.Y.Inst.PrimaryRoleInfo_get()
this.WithOneShopBuyList_set(m.f.getInst().getShopListByShopId(this.WithOneShopId,e.Level_get()))}}g._Inst=null},68965:(e,t,i)=>{"use strict"
i.d(t,{v:()=>ee})
var n=i(97461),s=i(99294),a=i(9057),r=i(83207),l=i(57834),o=i(93877),_=i(72005),u=i(53824),h=i(92679),c=i(20641),d=i(19519),m=i(98497),p=i(18202),g=i(31222),I=i(21554),E=i(70850)
class C{}C.None=0,C.ShortcutGoodsItem=1
var S=i(64808),T=i(65550),f=i(38836),A=i(86133),y=i(98800),R=i(97960),D=i(68662),w=i(66788),L=i(9986),v=i(6665),O=i(30849),P=i(98130),N=i(98885),M=i(85602),b=i(79534),G=i(1240),U=i(93078),B=i(98863),k=i(87923),F=i(86209),H=i(33138),x=i(48481),V=i(94026),Y=i(33828),W=i(43308),K=i(61149),Z=i(79528),z=i(34685),q=i(44393),$=i(27158)
class X{constructor(e,t,i,n,s,a){this.price=null,this.itemName=null,this.itemData=null,this.loseTime=null,this.isDoubleClick=!1,this.index=-1,this.priceType=null,this.buyNum=1,
this.levelTable=1,this.buyState=0,this.merchantcfg=null,this.maxNum=1,null==a&&(a=""),null==s&&(s=!1),this.price=e,this.itemName=t,this.itemData=i,this.loseTime=a,
this.isDoubleClick=s,this.index=n}PriceType_get(){return this.priceType}PriceType_set(e){this.priceType=e}Price_get(){return this.price}ItemName_get(){return this.itemName}
ItemData_get(){return this.itemData}LoseTime_get(){return this.loseTime}IsDoubleClick_get(){return this.isDoubleClick}Index_get(){return this.index}}var Q=i(82400)
class j extends O.C{constructor(){super(),this.itemGrid=null,this.cost=null,this.own=null,this.buyBtn=null,this.addBtn=null,this.removeBtn=null,this.input=null,this.itemName=null,
this.costIcon=null,this.ownIcon=null,this.goodsDesc=null,this.count=null,this.model=null,this.itemRes=null,this.inputNumCtrl=null,this.rInfo=null,this.singlePrice=0,this.buyNum=0,
this.numPadPos=null,this.numList=null,this._degf_BuyNumChangeHandle=null,this._degf_GoldUpdate=null,this._degf_InputCallBack=null,this._degf_OnBuyClick=null,
this._degf_OnInputClick=null,this._degf_OnItemCreateFun=null,this._degf_OnItemRefreshFun=null,this.numPadPos=new b.P(243,-8,0),
this._degf_BuyNumChangeHandle=e=>this.BuyNumChangeHandle(e),this._degf_GoldUpdate=e=>this.GoldUpdate(e),this._degf_InputCallBack=(e,t)=>this.InputCallBack(e,t),
this._degf_OnBuyClick=(e,t)=>this.OnBuyClick(e,t),this._degf_OnInputClick=(e,t)=>this.OnInputClick(e,t),this._degf_OnItemCreateFun=e=>this.OnItemCreateFun(e),
this._degf_OnItemRefreshFun=()=>this.OnItemRefreshFun()}InitView(){super.InitView(),this.itemGrid=new v.A,this.itemGrid.setId(this.FatherId,this.FatherComponentID,1),
this.cost=new o.Q,this.cost.setId(this.FatherId,this.FatherComponentID,2),this.own=new o.Q,this.own.setId(this.FatherId,this.FatherComponentID,3),this.buyBtn=new L.W,
this.buyBtn.setId(this.FatherId,this.FatherComponentID,4),this.addBtn=new L.W,this.addBtn.setId(this.FatherId,this.FatherComponentID,5),this.removeBtn=new L.W,
this.removeBtn.setId(this.FatherId,this.FatherComponentID,6),this.input=new s.z,this.input.setId(this.FatherId,this.FatherComponentID,7),this.itemName=new o.Q,
this.itemName.setId(this.FatherId,this.FatherComponentID,8),this.costIcon=new _.w,this.costIcon.setId(this.FatherId,this.FatherComponentID,9),this.ownIcon=new _.w,
this.ownIcon.setId(this.FatherId,this.FatherComponentID,10),this.goodsDesc=new q.W,this.goodsDesc.setBinderId(this.FatherId,this.FatherComponentID,11),this.count=new o.Q,
this.count.setId(this.FatherId,this.FatherComponentID,12),this.model=Q.s.Inst_get(),this.rInfo=y.Y.Inst.PrimaryRoleInfo_get(),this.numList=new M.Z,
this.itemGrid.SetInitInfo("ui_shop_buyitem",this._degf_OnItemCreateFun),this.itemGrid.OnReposition_set(this._degf_OnItemRefreshFun)}OnItemCreateFun(e){const t=new ee
return t.setId(e,null,0),t}OnItemRefreshFun(){let e=null
const t=V.e.Inst_get().GetHandInTargetItem(this.itemGrid.itemList)
if(null!=t&&(e=t,e.handIn.SetActive(!0)),null==e&&null!=this.itemGrid.itemList&&0!=this.itemGrid.itemList.Count()){e=this.itemGrid.itemList[0]
const t=Q.s.Inst_get().item
if(null!=t)for(const[i,n]of(0,f.V5)(this.itemGrid.itemList)){const i=n.Data_get()
if(null!=i&&i.Index_get()==t.Index_get()){e=n
break}}}null!=e&&e.BuyClick(0,0)}OnAddToScene(){this.rInfo=y.Y.Inst.PrimaryRoleInfo_get(),
this.inputNumCtrl=new B.c(this._degf_BuyNumChangeHandle,this.count,this.removeBtn,this.addBtn),this.model.SelectIsShow=!1,this.model.item=null,this.model.curShowView=0,
this.addLis(),this.ItemUpdate(),this.inputNumCtrl.num_set(0),this.itemName.textSet(""),this.cost.textSet("0"),this.costIcon.spriteNameSet(d.J.GetCurrencyIconUrl("GOLD")),
this.costIcon.MakePixelPerfect(),this.own.textSet(F.w.Instance.GetStrValByType("GOLD")),this.ownIcon.spriteNameSet(d.J.GetCurrencyIconUrl("GOLD")),this.ownIcon.MakePixelPerfect()
const e=$.V.GetResetDescStr(Z.g.ST_BAG)
this.goodsDesc.ResetView(e),this.model.item=null,this.inputNumCtrl.SetEnabled(!1,!1,!1,!1),l.i.Get(this.input).RemoveonClick(this._degf_OnInputClick)}ItemUpdate(){let e=0
this.model.UpdateData()
const t=new M.Z
let i=0
for(;i<this.model.WithOneShopBuyList_get().Count();){e=this.model.WithOneShopBuyList_get()[i].sellId,this.itemRes=H.f.Inst().getItemById(e)
const n=this.GetBuyItemData(e,this.model.WithOneShopBuyList_get()[i].buytype,this.model.WithOneShopBuyList_get()[i].price,!0,i)
E.g.Inst_get().openViewFromType==C.ShortcutGoodsItem?"SCMEDICINE"==this.itemRes.itemType&&t.Add(n):t.Add(n),i+=1}this.itemGrid.data_set(t)}ItemSelectHandle(){
const e=this.model.item,t=e.ItemData_get().baseData_get().cfgData_get(),i=new z.B
i.itemCfg=t,this.itemName.textSet(t.name),this.itemName.SetColor(k.l.getColorByQuality(k.l.GetQuality(e.ItemData_get().baseData_get()))),this.goodsDesc.UpdateView(i),
this.numList.Clear(),l.i.Get(this.input).RegistonClick(this._degf_OnInputClick),this.inputNumCtrl.SetEnabled(!0,!0,!0,!0),this.inputNumCtrl.min_set(1),this.inputNumCtrl.num_set(1),
this.SetCost(),this.UpdateCurrencyType(e.PriceType_get())}UpdateCurrencyType(e){const t=d.J.GetCurrencyIconUrl(e)
t!=this.costIcon.spriteName()&&(this.costIcon.spriteNameSet(t),this.costIcon.MakePixelPerfect()),t!=this.ownIcon.spriteName()&&(this.ownIcon.spriteNameSet(t),
this.costIcon.MakePixelPerfect())}SetCost(){if(null!=this.model.item){const e=N.M.Replace(this.model.item.Price_get(),N.M.s_SPAN_CHAR,"")
this.singlePrice=N.M.String2Int(e)
const t=d.J.GetGold(this.rInfo,this.model.item.PriceType_get())
0==P.GF.INT(t/this.singlePrice)?this.inputNumCtrl.max_set(1):P.GF.INT(t/this.singlePrice)>999?this.inputNumCtrl.max_set(999):this.inputNumCtrl.max_set(P.GF.INT(t/this.singlePrice))
const i=this.singlePrice*this.inputNumCtrl.num_get()
i>t?this.cost.textSet(`[DA2222]${F.w.Instance.ConvertNumToString(i)}[-]`):this.cost.textSet(`[E2A66A]${F.w.Instance.ConvertNumToString(i)}[-]`),
this.own.textSet(F.w.Instance.GetStrValByType(this.model.item.PriceType_get()))}}BuyNumChangeHandle(e){this.buyNum=e
const t=this.singlePrice*this.buyNum
null!=this.model.item&&(t>d.J.GetGold(this.rInfo,this.model.item.PriceType_get())?this.cost.textSet(`[DA2222]${F.w.Instance.ConvertNumToString(t)}[-]`):this.cost.textSet(`[E2A66A]${F.w.Instance.ConvertNumToString(t)}[-]`))
}OnBuyClick(e,t){if(null==this.model.item)return
if(y.Y.Inst.PrimaryRoleInfo_get().PkPoint_get()>=1)return void K.k.inst.OpenBuyTipsPanel()
if(this.singlePrice*this.buyNum>d.J.GetGold(this.rInfo,this.model.item.PriceType_get())){if(this.model.item.PriceType_get()==d.J.GOLD_STR){const e=b.P.zero_get()
W._.Inst_get().OpenByCurrency(this.model.item.PriceType_get(),e)}else this.model.item.PriceType_get()==d.J.GOLD_DIAMOND_STR&&Y.Y.Inst_get().Open()
return}const i=c.f.getInst().getShopIdByItemId(this.model.item.ItemData_get().serverData_get().modelId).id
Q.s.Inst_get().SendShopBuy(i,this.buyNum)}OnChargeClick(e,t){}InputCallBack(e,t){if(10==e)this.numList.Clear(),this.SetInput(this.numList)
else if(t)this.numList.Clear(),this.numList.Add(e),this.SetInput(this.numList)
else if(3==this.numList.Count()){const e=new M.Z
e.Add(9),e.Add(9),e.Add(9),this.SetInput(e)}else 0==e?this.numList.Count()>0&&this.numList[0]>0?(this.numList.Add(e),this.SetInput(this.numList)):(this.numList.Clear(),
this.SetInput(this.numList)):(this.numList.Add(e),this.SetInput(this.numList))}SetInput(e){let t=0,i=0
for(;i<e.Count();)t+=this.GetValue(e[i],e.Count()-i),i+=1
t>this.inputNumCtrl.max_get()?this.inputNumCtrl.num_set(this.inputNumCtrl.max_get()):0==t?this.inputNumCtrl.num_set(this.inputNumCtrl.min_get()):this.inputNumCtrl.num_set(t)}
GetValue(e,t){let i=0,n=1,s=1
for(;s<t;)n*=10,s+=1
return i=n*e,i}GetBuyItemData(e,t,i,n,s,a){if(this.itemRes=H.f.Inst().getItemById(e),""==t)return w.Y.LogError((0,A.T)("货币不正确!")),null
const r=i,l=k.l.GetPurseVOString(r)
let o=new x.t,_=0
if(null==a)o.modelId=e
else{const e=Q.s.Inst_get().buyIItemLoseTime,t=a.id.ToNum(),i=N.M.DoubleToString(t)
e.LuaDic_ContainsKey(i)&&(_=e[i].ToNum()/1e3),o=a}const u=new G.Y
u.serverData_set(o)
const h=k.l.GetQualityColorStr(k.l.GetQuality(u.baseData_get()),this.itemRes.name),c=s
let d=null
if(n)d=new X(l,h,u,c),d.PriceType_set(t)
else{const e=_-D.D.serverTime_get()
let i=""
e>0&&(i=k.l.OneDataFormat(e),""!=i&&(i+=Q.s.Inst_get().LoseStr)),d=new X(l,h,u,c,!0,i),d.PriceType_set(t)}return d.maxNum=this.itemRes.stack,d}Clear(){
U.F.Instance_get().CloseView(),this.inputNumCtrl.removeListeners(),this.removeLis()}addLis(){this.rInfo.AddEventHandler(R.A.CurrenciesUpdate,this._degf_GoldUpdate),
l.i.Get(this.buyBtn.node).RegistonClick(this._degf_OnBuyClick),l.i.Get(this.input).RegistonClick(this._degf_OnInputClick)}removeLis(){
this.rInfo.RemoveEventHandler(R.A.CurrenciesUpdate,this._degf_GoldUpdate),l.i.Get(this.buyBtn.node).RemoveonClick(this._degf_OnBuyClick),
l.i.Get(this.input).RemoveonClick(this._degf_OnInputClick)}OnInputClick(e,t){this.numList.Clear(),U.F.Instance_get().OpenView(this.numPadPos,this._degf_InputCallBack)}
GoldUpdate(e){this.SetCost()}Destroy(){this.itemGrid.Destroy(),this.itemGrid=null,this.cost=null,this.own=null,this.buyBtn=null,this.addBtn=null,this.removeBtn=null,
this.input=null,this.itemName=null,this.costIcon=null,this.ownIcon=null,this.goodsDesc.Destory(),this.goodsDesc=null,this.count=null}}class J{constructor(){
this.withOneShopView=null,this.shopContainer=null,this._degf_OnShopViewLoadComplete=null,this._degf_SM_ShopBuyHandle=null,
this._degf_OnShopViewLoadComplete=e=>this.OnShopViewLoadComplete(e),this._degf_SM_ShopBuyHandle=e=>this.SM_ShopBuyHandle(e),this.addLis()}addLis(){
m.j.Inst.F_Register(-1959,S.r,this._degf_SM_ShopBuyHandle)}SM_ShopBuyHandle(e){const t=e
0==t.code?E.g.Inst_get().openViewFromType==C.ShortcutGoodsItem&&I.J.Inst_get().closeBag():T.y.inst.ClientSysMessage(t.code)}InitShopViewData(e){
null==this.withOneShopView?(this.shopContainer=e,p.g.LoadOne("ui_shop_withoneshop",this._degf_OnShopViewLoadComplete)):this.withOneShopView.OnAddToScene()}
OnShopViewLoadComplete(e){const t=e[0]
this.withOneShopView=new j,this.withOneShopView.setId(t,null,0),this.withOneShopView.node.transform.SetParent(this.shopContainer.FatherId,this.shopContainer.ComponentId),
g.N.inst.SetChildDepth(I.J.Inst_get().GetBagPanelFatherId(),t),this.withOneShopView.OnAddToScene()}ClearShopViewData(){null!=this.withOneShopView&&this.withOneShopView.Clear()}
DestroyShopView(){null!=this.withOneShopView?(this.withOneShopView.Clear(),this.withOneShopView.Destroy(),p.g.DestroyUIObj(this.withOneShopView),
this.withOneShopView=null):p.g.Unload(this._degf_OnShopViewLoadComplete)}RefreshShopView(){null!=this.withOneShopView&&this.withOneShopView.ItemSelectHandle()}}J.inst=null
class ee extends a.x{constructor(){super(),this.price=null,this.itemName=null,this.btn=null,this.selectBg=null,this.item=null,this.currencyIcon=null,this.handIn=null,
this._buyItemData=null,this.isDoubleClick=!1,this.shopId=0,this.returnBuyNum=0,this.modelId=0,this._degf_BuyClick=null,this._degf_SelectHandle=null,this.index=-1,
this._degf_BuyClick=(e,t)=>this.BuyClick(e,t),this._degf_SelectHandle=e=>this.SelectHandle(e)}InitView(){super.InitView(),this.price=new o.Q,
this.price.setId(this.FatherId,this.FatherComponentID,1),this.itemName=new o.Q,this.itemName.setId(this.FatherId,this.FatherComponentID,2),this.btn=new r.s,
this.btn.setId(this.FatherId,this.FatherComponentID,3),this.selectBg=new _.w,this.selectBg.setId(this.FatherId,this.FatherComponentID,4),this.item=new u.Z,
this.item.setBinderId(this.FatherId,this.FatherComponentID,5),this.currencyIcon=new _.w,this.currencyIcon.setId(this.FatherId,this.FatherComponentID,6),this.handIn=new s.z,
this.handIn.setId(this.FatherId,this.FatherComponentID,7)}Data_get(){return this._buyItemData}addLis(){l.i.Get(this.btn.node).RegistonClick(this._degf_BuyClick),
n.i.Inst.AddEventHandler(h.g.WITHSHOP_ITEM_SELECT,this._degf_SelectHandle)}removeLis(){l.i.Get(this.btn.node).RemoveonClick(this._degf_BuyClick),
n.i.Inst.RemoveAllEventHandler(h.g.WITHSHOP_ITEM_SELECT)}SelectHandle(e){
Q.s.Inst_get().item.Index_get()==this._buyItemData.Index_get()?this.selectBg.node.SetActive(!0):this.selectBg.node.SetActive(!1)}BuyClick(e,t){
Q.s.Inst_get().item=this._buyItemData,n.i.Inst.RaiseEvent(h.g.WITHSHOP_ITEM_SELECT),J.inst.RefreshShopView()}ReturnBuyClickHandler(e){
Q.s.Inst_get().SendBuyBack(this.index,this.returnBuyNum)}SetData(e){if(this.selectBg.node.SetActive(!1),this._buyItemData=e,null==this._buyItemData&&null!=e)return
this.handIn.SetActive(!1),this.price.textSet(this._buyItemData.Price_get()),this.itemName.textSet(this._buyItemData.ItemName_get())
const t=this._buyItemData.ItemData_get().serverData_get()
if(this._buyItemData.ItemData_get().baseData_get().needtip=!1,this._buyItemData.ItemData_get().baseData_get().isForBag=!1,this.item.SetData(this._buyItemData.ItemData_get()),
this.isDoubleClick=this._buyItemData.IsDoubleClick_get(),this.modelId=t.modelId,this.index=this._buyItemData.Index_get(),this.isDoubleClick)this.returnBuyNum=t.num
else{const e=c.f.getInst().getShopIdByItemId(this.modelId)
this.shopId=e.id}this.UpdateCurrencyType(),this.addLis()}UpdateCurrencyType(){const e=d.J.GetCurrencyIconUrl(this._buyItemData.PriceType_get())
this.currencyIcon.node.SetActive(!0),e!=this.currencyIcon.spriteName()&&(this.currencyIcon.spriteNameSet(e),this.currencyIcon.MakePixelPerfect())}Clear(){this.removeLis()}
Destroy(){this.price=null,this.itemName=null,this.btn=null,this.selectBg=null,this.item=null,this.handIn=null}}},67420:(e,t,i)=>{"use strict"
i.d(t,{m:()=>T})
var n=i(93984),s=i(38836),a=i(98800),r=i(68662),l=i(62370),o=i(55360),_=i(98885),u=i(85602),h=i(38962),c=i(46963),d=i(68366)
class m{constructor(){this.timeStr=null,this.beginTime=0,this.list=null,this.index=0}}var p=i(38045),g=i(87923),I=i(55492)
class E{constructor(){this.cfg=null,this.sortIndex=0,this.sortExtra=0,this.m_weekInfo=null,this.beginTimeStr=null,this.beginTimeValue=0,this.endTimeValue=0,
this.beginSignTimeValue=0,this.endSignTimeValue=0,this.SpecialDateInfo=null,this.SpecialDateInfo=new u.Z}parse(){this.m_weekInfo=_.M.Split(this.cfg.week,l.o.s_Arr_UNDER_CHAR_DOT)
const e=_.M.Split(this.cfg.time,l.o.s_Arr_UNDER_LINE)
this.beginTimeStr=_.M.SubStringWithEnd(e[0],0,5),this.beginTimeValue=c.E.GetCfgTime(this.cfg.time,-1),this.endTimeValue=c.E.GetCfgTime(this.cfg.time,1),
g.l.IsEmptyStr(this.cfg.specialdate)||(this.SpecialDateInfo=_.M.Split(this.cfg.specialdate,l.o.s_Arr_UNDER_CHAR_DOT))}isShowByDay(e){const t=r.D.serverOpenDay_get()
let i=t
if(i=_.M.String2Int(e)>r.D.weekDay_get()-t?t+_.M.String2Int(e)-r.D.weekDay_get():t+_.M.String2Int(e)-r.D.weekDay_get()+7,this.cfg.kaifu>0&&t>0&&i<this.cfg.kaifu)return!1
if(i<=c.E.openDay&&this.SpecialDateInfo.Count()>0&&!g.l.IsEmptyStr(this.SpecialDateInfo[0])){const n=new u.Z
for(let e=0;e<=this.SpecialDateInfo.Count()-1;e++){const i=_.M.String2Int(this.SpecialDateInfo[e]),s=(r.D.weekDay_get()-t)%7
n.Add((s+i-1)%7+1)}n.Sort(g.l.SortCompareFunc_Int)
for(let t=0;t<=n.Count()-1;t++)if((0,p.tw)(n[t])==e)return!0
if(_.M.String2Int(this.SpecialDateInfo[this.SpecialDateInfo.Count()-1])>=i)return!1
if(this.cfg.functionId==I.x.ASURAM_WAR&&this.SpecialDateInfo.Contains((0,p.tw)(i-1)))return!1}for(const[t,i]of(0,s.V5)(this.m_weekInfo))if(i==e)return!0
return!1}CheckTime(e,t){return this.beginTimeValue>=e&&this.beginTimeValue<t}}var C=i(83010)
class S{constructor(){this.timeindex=0,this.day=0,this.res=null,this.name="fuckyouyouos"}GetActivityContent(){const e=this.res.cfg
let t="",i="",n=""
const s=C.x.GetWeekAndTimeDes(e.week,e.time,e.kaifu,this.res.SpecialDateInfo)
return""!=s&&(t=s),""!=this.res.activityType&&(i=`[DBDBDB]${e.activityType}[-]`),n=`[DBDBDB]${e.level}级[-]`,[t,i,n]}}class T{constructor(){this.map=null,this.m_xMap=null,
this.calenderList=null,this.timeseg=null,this.timevaluseg=null,this.weekDay=-1,this.calenderList=new u.Z,this.timeseg=new u.Z
const e=o.Y.Inst.GetOrCreateCsv(n.h.eActivityShow)
this.map=e.GetCsvMap()}static Inst(){return null==T._inst&&(T._inst=new T,T._inst.InitXMapInfo()),T._inst}InitXMapInfo(){this.m_xMap=new h.X
for(const[e,t]of(0,s.V5)(this.map)){const e=new E
e.cfg=t,e.parse(),this.m_xMap.LuaDic_AddOrSetItem(t.id,e)}}InitTimeInfo(){const e=r.D.weekDay_get()
if(e!=this.weekDay){this.calenderList.Clear(),this.weekDay=e,this.InitTimeSeg(),this.timevaluseg=new u.Z
for(const[e,t]of(0,s.V5)(this.timeseg)){const e=_.M.Split(t,"_")[0]
this.timevaluseg.Contains(e)||this.timevaluseg.Add(e)}const t=this.timeseg.Count()
let i=0,n=0,a=0
for(;a<t;){const e=_.M.Split(this.timeseg[a],"_"),t=e[0],s=_.M.String2Int(e[1]),r=new m
r.timeStr=t,i=c.E.GetBeginTimeByStr(t),n=this.GetNextTime(i),r.list=this.getCalendarDatas(i,n,a,s),r.index=a,this.calenderList.Add(r),a+=1}}}GetNextTime(e){
for(let t=0;t<=this.timevaluseg.Count()-1;t++){const i=c.E.GetBeginTimeByStr(this.timevaluseg[t])
if(e<i)return i}return c.E.GetBeginTimeByStr("24:00")}getCalendarDatas(e,t,i,n){const s=new u.Z
let a=1
for(;a<8;){const r=new S
r.day=a,r.timeindex=i,r.res=this.getAct(e,t,_.M.IntToString(a),n),s.Add(r),a+=1}return s}getAct(e,t,i,n){for(const[a,r]of(0,
s.V5)(this.m_xMap))if(r.cfg.line==n&&r.isShowByDay(i)&&r.CheckTime(e,t))return r
return null}InitTimeSeg(){this.timeseg.Clear()
for(const[e,t]of(0,s.V5)(this.m_xMap))this.timeseg.Contains(`${t.beginTimeStr}_${t.cfg.line}`)||this.timeseg.Add(`${t.beginTimeStr}_${t.cfg.line}`)
this.timeseg.Sort(this.timeSort)}timeSort(e,t){const i=_.M.Split(e,"_"),n=c.E.GetBeginTimeByStr(i[0]),s=i[1],a=_.M.Split(t,"_"),r=c.E.GetBeginTimeByStr(a[0]),l=a[1]
return n==r?s-l:n-r}GetItem(e,t,i){if(!i.LuaDic_ContainsKey(e))return null
const n=i[e],a=_.M.IntToString(t)
for(const[e,t]of(0,s.V5)(n))if(t.isShowByDay(a))return t
return null}SortItem(e,t){const i=c.E.GetBeginTimeByStr(e),n=c.E.GetBeginTimeByStr(t)
return i>n?1:i<n?-1:0}getActivityShowItemById(e){let t=null
return t=this.map[e],null!=t?t:null}GetTypeIcons(e){const t=new u.Z,i=_.M.Split(e,_.M.s_SPAN_CHAR_DOT)
if(null!=i){let e=0
for(;e<i.count;)t.Add(i[e]),e+=1}return t}IsTodayHasThisActivity(e){const t=this.getActivityShowItemById(e),i=_.M.Split(t.week,l.o.s_Arr_UNDER_CHAR_DOT),n=new u.Z
let s=0
for(;s<i.count;){const e=_.M.String2Int(i[s])
n.Add(e),s+=1}let a=d.N.ServerDate_get(),r=a.day_get()
return a=null,0==r&&(r=7),n.IndexOf(r,0)>=0}GetOpenDays(e){const t=this.getActivityShowItemById(e),i=_.M.Split(t.week,l.o.s_Arr_UNDER_CHAR_DOT),n=new u.Z
let s=0
for(;s<i.count;){const e=_.M.String2Int(i[s])
n.Add(e),s+=1}return n}IsLevelAndRoleNumEnough(e){const t=a.Y.Inst.GetMultPlayerInfos()
let i=0
for(const[n,a]of(0,s.V5)(t))a.Level_get()>=e.level&&(i+=1)
return i>=1}getActivityEXById(e){let t=null
return t=this.m_xMap[e],null!=t?t:null}ClearCalData(e){this.calenderList.Clear(),this.weekDay=-1}}T._inst=null},66781:(e,t,i)=>{"use strict"
i.d(t,{v:()=>y})
var n=i(18202),s=i(31222),a=i(5494),r=i(93984),l=i(98800),o=i(98958),_=i(9986),u=i(57834),h=i(69029),c=i(93877),d=i(72005),m=i(61911),p=i(98130),g=i(79534),I=i(22662),E=i(65550),C=i(19519),S=i(93078),T=i(98863)
class f{constructor(){this.curViewData=null}static Inst_get(){return null==f.inst&&(f.inst=new f),f.inst}}f.inst=null
class A extends m.f{constructor(){super(),this.closeBtn=null,this.useBtn=null,this.numTxt=null,this.minusBtn=null,this.addBtn=null,this.maxBtn=null,this.num=null,this.price=null,
this.icon=null,this.cancelbtn=null,this._numCtrl=null,this._model=null,this.result=0,this._degf_AddHandler=null,this._degf_ChangeHandler=null,this._degf_SelectUseNumHandler=null,
this._degf_SendBuyHandler=null,this._degf_closeHandler=null,this._degf_useHandler=null,this._degf_AddHandler=(e,t)=>this.AddHandler(e,t),
this._degf_ChangeHandler=e=>this.ChangeHandler(e),this._degf_SelectUseNumHandler=(e,t)=>this.SelectUseNumHandler(e,t),this._degf_SendBuyHandler=e=>this.SendBuyHandler(e),
this._degf_closeHandler=(e,t)=>this.closeHandler(e,t),this._degf_useHandler=(e,t)=>this.useHandler(e,t)}InitView(){this.closeBtn=new _.W,
this.closeBtn.setId(this.FatherId,this.FatherComponentID,1),this.useBtn=new _.W,this.useBtn.setId(this.FatherId,this.FatherComponentID,2),this.numTxt=new h.z,
this.numTxt.setId(this.FatherId,this.FatherComponentID,3),this.minusBtn=new _.W,this.minusBtn.setId(this.FatherId,this.FatherComponentID,4),this.addBtn=new _.W,
this.addBtn.setId(this.FatherId,this.FatherComponentID,5),this.maxBtn=new _.W,this.maxBtn.setId(this.FatherId,this.FatherComponentID,6),this.num=new c.Q,
this.num.setId(this.FatherId,this.FatherComponentID,7),this.price=new c.Q,this.price.setId(this.FatherId,this.FatherComponentID,8),this.icon=new d.w,
this.icon.setId(this.FatherId,this.FatherComponentID,9),this.cancelbtn=new _.W,this.cancelbtn.setId(this.FatherId,this.FatherComponentID,11),this._model=f.Inst_get(),
super.InitView()}OnAddToScene(){this.setData()}setData(){if(null==this._model.curViewData)return
null==this._numCtrl&&(this._numCtrl=new T.c(this._degf_ChangeHandler,this.num,this.minusBtn,this.addBtn,this.maxBtn)),
this.maxBtn.node.SetActive(this._model.curViewData.IsShowMaxBtn_get())
const e=l.Y.Inst.PrimaryRoleInfo_get()
let t=C.J.GetCurrencyVal(e,this._model.curViewData.CurCurrencyType_get())
this._model.curViewData.CurCurrencyType_get()==C.J.Score&&(t+=C.J.GetCurrencyVal(e,C.J.GOLD_DIAMOND)),
this.icon.spriteNameSet(C.J.GetCurrencyIconName(this._model.curViewData.CurCurrencyType_get())),this.icon.node.SetActive(!0)
let i=0
i=p.GF.INT(t/this._model.curViewData.CurPrice_get()),i>this._model.curViewData.MaxNum_get()&&(i=p.GF.INT(this._model.curViewData.MaxNum_get())),i<=0&&(i=1),
this._numCtrl.max_set(i),this._numCtrl.num_set(1),this.addListeners()}ChangeHandler(e){this.price.textSet(""+e*this._model.curViewData.CurPrice_get())}addListeners(){
u.i.Get(this.closeBtn.node).RegistonClick(this._degf_closeHandler),u.i.Get(this.useBtn.node).RegistonClick(this._degf_useHandler),
u.i.Get(this.num.node).RegistonClick(this._degf_SelectUseNumHandler),u.i.Get(this.cancelbtn.node).RegistonClick(this._degf_closeHandler)}SelectUseNumHandler(e,t){
S.F.Instance_get().OpenView(new g.P(0,200,0),this._degf_AddHandler)}AddHandler(e,t){10==e?this.result=0:t?this.result=e:(this.result*=10,this.result+=e),
this.result<0&&(this.result=0),this.result>this._numCtrl.max_get()&&(this.result=this._numCtrl.max_get()),this._numCtrl.num_set(this.result)}removeListeners(){
u.i.Get(this.closeBtn.node).RemoveonClick(this._degf_closeHandler),u.i.Get(this.useBtn.node).RemoveonClick(this._degf_useHandler),
u.i.Get(this.num.node).RemoveonClick(this._degf_SelectUseNumHandler),u.i.Get(this.cancelbtn.node).RemoveonClick(this._degf_closeHandler)}closeHandler(e,t){null==t&&(t=0),
null==e&&(e=0),this.result=0,y.inst.CloseBuyAlert()}useHandler(e,t){if(0==this._numCtrl.num_get()){const e=o.V.Inst().getStr(10392,r.h.eLangResource)
return void E.y.inst.ClientStrMsg(I.r.SystemTipMessage,e)}const i=l.Y.Inst.PrimaryRoleInfo_get(),n=C.J.GetCurrencyVal(i,this._model.curViewData.CurCurrencyType_get())
this._numCtrl.num_get()*this._model.curViewData.CurPrice_get()>n?this._model.curViewData.CurCurrencyType_get()==C.J.GOLD?C.J.OpenSupplyCurrencyViewByType(C.J.GOLD):this._model.curViewData.CurCurrencyType_get()==C.J.GOLD_DIAMOND?C.J.OpenSupplyCurrencyViewByType(C.J.GOLD_DIAMOND):this._model.curViewData.CurCurrencyType_get()==C.J.Score&&C.J.JudgeConsumeScore(this._numCtrl.num_get()*this._model.curViewData.CurPrice_get(),this._degf_SendBuyHandler,this._numCtrl.num_get()):this.SendBuyHandler(this._numCtrl.num_get()),
this.closeHandler()}SendBuyHandler(e){null!=this._model.curViewData.Handler_get()&&this._model.curViewData.Handler_get()(p.GF.INT(e))}Clear(){this.removeListeners(),
this._numCtrl.removeListeners()}Destroy(){this.closeBtn=null,this.useBtn=null,this.cancelbtn=null,this.numTxt=null,this.minusBtn=null,this.addBtn=null,this.maxBtn=null,
this.num=null,this.price=null,this.icon=null,this._numCtrl=null}}class y{constructor(){this.buyAlert=null,this._degf_BuyAlertDestroy=null,this._degf_BuyAlertHandler=null,
this._degf_BuyAlertDestroy=()=>this.BuyAlertDestroy(),this._degf_BuyAlertHandler=e=>this.BuyAlertHandler(e)}OpenBuyAlertView(){
s.N.inst.OpenById(a.I.BuyAlertPanel,this._degf_BuyAlertHandler,this._degf_BuyAlertDestroy)}BuyAlertDestroy(){n.g.DestroyUIObj(this.buyAlert),this.buyAlert=null}BuyAlertHandler(e){
return null==this.buyAlert&&(this.buyAlert=new A,this.buyAlert.setId(e,null,0)),this.buyAlert}CloseBuyAlert(){null!=this.buyAlert&&s.N.inst.ClosePanel(this.buyAlert)}}y.inst=null},
68042:(e,t,i)=>{"use strict"
i.d(t,{o:()=>w})
var n=i(56937),s=i(31222),a=i(5494),r=i(52726),l=i(9986),o=i(93877),_=i(72005),u=i(61911),h=i(18202),c=i(83540),d=i(98885),m=i(88653),p=i(52212),g=i(21554),I=i(69015),E=i(86209),C=i(33138),S=i(19519),T=i(92679),f=i(93078),A=i(98800),y=i(70850)
class R{static Inst_get(){return null==R.inst&&(R.inst=new R),R.inst}GetConsumeItemId(){const e=w.Inst_get().tipVo
let t=0
return null!=e.consumeItemId?t=e.consumeItemId:null!=e.consumeCurrencyType&&(t=S.J.GetItemID(e.consumeCurrencyType)),t}GetRemainNum(){const e=w.Inst_get().tipVo
let t=0
return null!=e.consumeItemId?t=y.g.Inst_get().GetItemNum(e.consumeItemId):null!=e.consumeCurrencyType&&(t=S.J.GetGold(A.Y.Inst.PrimaryRoleInfo_get(),e.consumeCurrencyType)),t}}
R.inst=null
class D extends u.f{constructor(...e){super(...e),this.titleTxt=null,this.maxBtn=null,this.addBtn=null,this.sliceBtn=null,this.countTxt=null,this.priceTxt=null,this.priceIcon=null,
this.ownIcon=null,this.ownNumTxt=null,this.buyBtn=null,this.data=null,this.curCount=1,this.curPrice=0,this.ownNum=0,this.maxCount=0,this.tipIndex=null,this.curBuyCount=null,
this.currencyUp=null,this.currencyDown=null,this.countLabel=null,this.totalPriceLabel=null,this.curCurrencyLabel=null,this.addButton=null,this.leftButton=null,this.offset=null,
this.noLimitObj=null}InitView(){super.InitView(),this.titleTxt=this.CreateComponent(o.Q,1),this.maxBtn=this.CreateComponent(l.W,2),this.addBtn=this.CreateComponent(l.W,3),
this.sliceBtn=this.CreateComponent(l.W,4),this.countTxt=this.CreateComponent(o.Q,5),this.priceTxt=this.CreateComponent(o.Q,6),this.priceIcon=this.CreateComponent(_.w,7),
this.ownIcon=this.CreateComponent(_.w,8),this.ownNumTxt=this.CreateComponent(o.Q,9),this.buyBtn=this.CreateComponent(l.W,10)}OnAddToScene(){this.InitData(),this.InitPanel(),
this.AddLis()}InitData(){this.data=w.Inst_get().tipVo,this.tipIndex=this.AddToLayout()
let e=this.data.maxCount
const t=R.Inst_get().GetRemainNum(),i=Math.floor(t/this.data.onePrice)
e>i&&(e=i),this.maxCount=e,this.ownNumTxt.textSet(E.w.Instance.ConvertNumToString(t))}InitPanel(){if(null!=this.data.consumeItemId){
const e=C.f.Inst().getItemById(this.data.consumeItemId)
h.g.SetItemIcon(this.priceIcon.FatherId,this.priceIcon.ComponentId,e.icon,c.b.eItem,!1),h.g.SetItemIcon(this.ownIcon.FatherId,this.ownIcon.ComponentId,e.icon,c.b.eItem,!1)
}else if(null!=this.data.consumeCurrencyType){const e=S.J.GetCurrencyIconUrl(this.data.consumeCurrencyType)
this.priceIcon.spriteNameSet(e),this.ownIcon.spriteNameSet(e)}this.titleTxt.textSet(this.data.titleStr),this.buyBtn.SetText("购 买"),this.SetBuyCount(this.data.defaultCount)}
AddLis(){this.m_handlerMgr.AddClickEvent(this.addBtn.node,this.CreateDelegate(this.OnAddBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.sliceBtn.node,this.CreateDelegate(this.OnSliceBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.maxBtn.node,this.CreateDelegate(this.OnMaxBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.countTxt.node,this.CreateDelegate(this.SelectUseNumHandler)),
this.m_handlerMgr.AddClickEvent(this.buyBtn.node,this.CreateDelegate(this.OnBuyBtnHandle)),
this.m_handlerMgr.AddEventMgr(T.g.BASE_TIP_CLOSE,this.CreateDelegate(this.OnCloseHandler))}RemoveLis(){}UpdateOwnHandle(){}AddToLayout(){const[e,t]=[0,140.6],[i,n]=[325,267]
return I.g.Inst_get().AddTipByParam(null,I.g.HorizontalAlign.Right,I.g.VerticalAlign.Down,new p.F(e,t),new p.F(i,n))}SetBuyCount(e){e>this.maxCount&&(e=this.maxCount),
this.curBuyCount=e,this.countTxt.textSet(d.M.IntToString(e)),this.curPrice=this.data.onePrice*e,this.priceTxt.SetColor(new m.I(.8,.796,.768)),
this.priceTxt.textSet(E.w.Instance.ConvertNumToString(this.curPrice))}OnMaxBtnHandle(){this.SetBuyCount(this.maxCount)}OnCloseHandler(){w.Inst_get().CloseView()}
SelectUseNumHandler(){const e=this.addBtn.GetPosition()
e.y-=.3,e.x-=.1,f.F.Instance_get().OpenView(null,this.CreateDelegate(this.AddHandler),null,e)}AddHandler(e,t){10==e?this.curBuyCount=1:t?this.curBuyCount=e:(this.curBuyCount*=10,
this.curBuyCount+=e),this.curBuyCount<=0&&(this.curBuyCount=1),this.curBuyCount=Math.min(this.curBuyCount,this.maxCount),this.SetBuyCount(this.curBuyCount)}OnBuyBtnHandle(){
null!=this.data.buyHandle&&this.data.buyHandle(this.curBuyCount),g.J.Inst_get().CloseTipView(),this.OnCloseHandler()}OnSliceBtnHandle(){this.curBuyCount<=1||(this.curBuyCount-=1,
this.SetBuyCount(this.curBuyCount))}OnAddBtnHandle(){this.maxCount<=this.curBuyCount||(this.curBuyCount+=1,this.SetBuyCount(this.curBuyCount))}Clear(){
f.F.Instance_get().CloseView(),w.Inst_get().tipVo=null,null!=this.tipIndex&&(I.g.Inst_get().RemoveByTip(),this.tipIndex=null),this.curBuyCount=1,this.data=null,super.Clear()}
Destroy(){f.F.Instance_get().CloseView(),this.currencyUp=null,this.currencyDown=null,this.countLabel=null,this.totalPriceLabel=null,this.curCurrencyLabel=null,this.addButton=null,
this.leftButton=null,this.buyBtn=null,this.offset=null,this.noLimitObj=null,super.Destroy()}}class w{constructor(){this.tipVo=null}static Inst_get(){
return null==w.inst&&(w.inst=new w),w.inst}OpenView(e){this.tipVo=e
const t=new n.v
t.isShowMask=!1,t.layerType=r.F.Tip,t.viewClass=D,s.N.inst.OpenById(a.I.BuyTipPanel,null,null,t)}CloseView(){s.N.inst.CloseById(a.I.BuyTipPanel)}}w.inst=null},91280:(e,t,i)=>{
"use strict"
i.d(t,{v:()=>n})
class n{constructor(){this.consumeItemId=null,this.consumeCurrencyType=null,this.onePrice=null,this.maxCount=null,this.defaultCount=null,this.buyHandle=null,this.titleStr="购买数量"}
InitCurrencyData(e,t,i,n,s,a){this.consumeCurrencyType=e,this._CommonInit(t,i,n,s,a)}InitItemData(e,t,i,n,s,a){this.consumeItemId=e,this._CommonInit(t,i,n,s,a)}
_CommonInit(e,t,i,n,s){null==n&&(n=this.titleStr),-1==t&&(t=9999),-1==i&&(i=t),this.onePrice=e,this.maxCount=t,this.defaultCount=i,this.titleStr=n,this.buyHandle=s}}},
65801:(e,t,i)=>{"use strict"
i.d(t,{x:()=>s})
var n=i(79534)
class s{constructor(e,t,i,n,s,a,r,l,o,_){this.effectPath=null,this.startPos=null,this.endPos=null,this.duration=null,this.endTime=null,this.endCallbackFun=null,
this.startSacleX=null,this.startSacleY=null,this.endSacleX=null,this.endSacleY=null,this.flowPointEffect=null,this.id=-1,this.uiCreate=null,this.effectPath=e,this.startPos=t,
this.endPos=i,this.duration=n,this.endTime=s,this.endCallbackFun=a,this.startSacleX=r,this.startSacleY=l,this.endSacleX=o,this.endSacleY=_}Clone(e){this.effectPath=e.effectPath,
this.startPos.CopyFrom(e.startPos),this.endPos.CopyFrom(e.endPos),this.duration=e.duration,this.endTime=e.endTime,this.endCallbackFun=e.endCallbackFun}Recyle(){
this.startPos.Set(0,0,0),this.endPos.Set(0,0,0),this.flowPointEffect.Clear(),this.flowPointEffect.node.SetActive(!1),this.duration=null,this.endTime=null,this.endCallbackFun=null,
this.startSacleX=null,this.startSacleY=null,this.endSacleX=null,this.endSacleY=null}Clear(){this.flowPointEffect.Clear(),this.uiCreate.Clear(),this.uiCreate.Destroy()}Destroy(){
this.effectPath=null,this.flowPointEffect=null,n.P.Recyle(this.startPos),n.P.Recyle(this.endPos),this.startPos=null,this.endPos=null,this.duration=null,this.endTime=null,
this.endCallbackFun=null,this.uiCreate=null}}},22878:(e,t,i)=>{"use strict"
i.d(t,{C:()=>y})
var n=i(17409),s=i(73206),a=i(56937),r=i(18202),l=i(31222),o=i(5494),_=i(52726),u=i(995),h=i(98789),c=i(98885),d=i(79534),m=i(22107),p=i(36022),g=i(95741),I=i(98800),E=i(5924),C=i(93877),S=i(3522),T=i(72005),f=i(61911)
class A extends f.f{constructor(){super(),this.showAnim=null,this.artTxt=null,this.desc=null,this.icon=null,this.startAnim=null,this.closeInterval=-1,this.animTimer=-1,
this.closeTime=6e3,this.model=null,this.loopCount=0,this._degf_DelayClose=null,this._degf_DelayShowAnimHandler=null,this._degf_DelayClose=()=>this.DelayClose(),
this._degf_DelayShowAnimHandler=()=>this.DelayShowAnimHandler()}InitView(){this.showAnim=new S.k,this.showAnim.setId(this.FatherId,this.FatherComponentID,1),this.artTxt=new C.Q,
this.artTxt.setId(this.FatherId,this.FatherComponentID,2),this.desc=new C.Q,this.desc.setId(this.FatherId,this.FatherComponentID,3),this.icon=new T.w,
this.icon.setId(this.FatherId,this.FatherComponentID,4),this.startAnim=new S.k,this.startAnim.setId(this.FatherId,this.FatherComponentID,5),this.model=g.p.Inst_get(),
super.InitView()}OnAddToScene(){-1==this.animTimer&&(this.animTimer=E.C.Inst_get().SetFrameLoop(this._degf_DelayShowAnimHandler,1,10)),this.SetData()}DelayShowAnimHandler(){
this.loopCount+=1,5==this.loopCount?(this.startAnim.SetResetOnPlay(!0),this.startAnim.Play(!0,!1)):10==this.loopCount&&(this.showAnim.node.SetActive(!0),
this.showAnim.SetResetOnPlay(!0),this.showAnim.Play(!0,!1),this.ClearAnimTimer())}Clear(){this.ClearInterval(),this.ClearAnimTimer()}ClearInterval(){
E.C.Inst_get().ClearInterval(this.closeInterval),this.closeInterval=-1}ClearAnimTimer(){E.C.Inst_get().ClearInterval(this.animTimer),this.animTimer=-1,this.loopCount=0}SetData(){
if(this.ClearInterval(),null!=this.model.noticeRes){if(null!=this.model.noticeRes.element&&""!=this.model.noticeRes.element){const e=d.P.zero_get()
s.X.Inst.PlayElement(c.M.String2Int(this.model.noticeRes.element),I.Y.Inst.PrimaryRole_get().GetHandle(),0,e,e)}let e="",t=""
"0"==this.model.noticeRes.icon||(e=this.model.noticeRes.icon),t="0"==this.model.noticeRes.name?TeamModel.Inst_get().getLeaderName():this.model.noticeRes.name,
this.icon.spriteNameSet(e),this.artTxt.textSet(t),this.desc.textSet(this.model.noticeRes.desc)}this.closeInterval=E.C.Inst_get().SetInterval(this._degf_DelayClose,this.closeTime,1)
}DelayClose(){this.ClearInterval(),y.inst.CloseCommonTipView()}Destroy(){this.ClearInterval(),this.ClearAnimTimer(),this.showAnim=null,this.artTxt=null,this.desc=null,
this.icon=null,this.startAnim=null}}class y{static get inst(){return y._inst||(y._inst=new y),y._inst}constructor(){this.commonView=null,this.npcView=null,
this._degf_DestroyCommonPanel=null,this._degf_DestroyNPCPanel=null,this._degf_ShowCommonHandler=null,this._degf_ShowNPCHandler=null,
this._degf_DestroyCommonPanel=()=>this.DestroyCommonPanel(),this._degf_DestroyNPCPanel=()=>this.DestroyNPCPanel(),this._degf_ShowCommonHandler=e=>this.ShowCommonHandler(e),
this._degf_ShowNPCHandler=e=>this.ShowNPCHandler(e)}static Inst_Get(){return y._inst||(y._inst=new y),y._inst}JudgeOpenViewById(e){const t=p.e.Inst().getItemById(e)
if(null!=t)if(g.p.Inst_get().noticeRes=t,0==t.noticeType)this.OpenNPCTipView()
else if(1==t.noticeType)this.OpenCommonTipView()
else if(2==t.noticeType){const e=d.P.zero_get()
s.X.Inst.PlayElement(c.M.String2Int(t.element),0,0,e,e)}else 3==t.noticeType&&this.OpenNPCTipView()}OpenCommonTipView(){
if(null!=this.commonView&&this.commonView.isShow_get())this.commonView.SetData()
else{const e=new a.v
e.positionType=h.$.eCustom,e.layerType=_.F.DefaultUI,e.aniDir=u.K.Up,l.N.inst.OpenById(o.I.CopyMonsterTip,this._degf_ShowCommonHandler,this._degf_DestroyCommonPanel,e)}
this.SendOpenTip()}DestroyCommonPanel(){r.g.DestroyUIObj(this.commonView),this.commonView=null}ShowCommonHandler(e){return null==this.commonView&&(this.commonView=new A,
this.commonView.setId(e,null,0)),this.commonView}CloseCommonTipView(){null!=this.commonView&&l.N.inst.ClosePanel(this.commonView)}OpenNPCTipView(){if(null==this.npcView){
const e=new a.v
e.positionType=h.$.eCustom,e.layerType=_.F.DefaultUI,e.aniDir=u.K.Left,l.N.inst.OpenById(o.I.CopyNPCTip,this._degf_ShowNPCHandler,this._degf_DestroyNPCPanel,e)
}else this.npcView.SetData()
this.SendOpenTip()}DestroyNPCPanel(){}ShowNPCHandler(e){}CloseNPCTipView(){null!=this.npcView?((0,n.sR)(o.I.CopyNPCTip),m.N.inst_get().UpdateCountTipVisible(!1)):(0,
n.sR)(o.I.CopyNPCTip)}IsTipOpen(){return null!=this.npcView||null!=this.commonView}SendOpenTip(){m.N.inst_get().UpdateCountTipVisible(!0)}SwitchToPk(){
null!=this.npcView&&this.npcView.SwitchToPk()}SwitchToNormal(){null!=this.npcView&&this.npcView.SwitchToNormal()}}y._inst=null},95741:(e,t,i)=>{"use strict"
i.d(t,{p:()=>n})
class n{constructor(){this.noticeRes=null}static Inst_get(){return null==n._inst&&(n._inst=new n),n._inst}}n._inst=null},56505:(e,t,i)=>{"use strict"
i.d(t,{t:()=>d})
var n,s=i(18998),a=i(83908),r=i(5924),l=i(18202),o=i(83540),_=i(79534),u=i(33138)
const{ccclass:h,property:c}=s._decorator
let d=h("CommonFlyItem")(n=class extends((0,a.yk)()){constructor(...e){super(...e),this.delayTime=null,this.startVec=null,this.endVec=null,this.isPlay=!1,this.intervalId=-1,
this._degf_OnIconFlyFinished=null,this._degf_ResetState=null,this.modelId=null,this.start=null,this.p_end=null,this.targetScale=null,this.speed=null}InitView(){
this.startVec=_.P.zero_get(),this.endVec=_.P.zero_get()}Clear(){null!=this.delayTime&&(r.C.Inst_get().ClearInterval(this.delayTime),this.delayTime=null),
r.C.Inst_get().ClearInterval(this.intervalId),this.tween.RemoveEventHandler(this.CreateDelegate(this.OnIconFlyFinished))}Destroy(){}Play(e,t,i,n,s,a){this.modelId=i,this.start=e,
this.p_end=t,this.targetScale=n,this.speed=s,this.isPlay=!0,null!=this.delayTime&&(r.C.Inst_get().ClearInterval(this.delayTime),this.delayTime=null),null==a&&(a=0),
0==a?this.PlayNow():(this.node.SetActive(!1),this.delayTime=r.C.Inst_get().SetInterval(this.CreateDelegate(this.PlayNow),a,1))}PlayNow(){if(this.node.SetActive(!0),
null!=this.modelId&&0!=this.modelId){const e=u.f.Inst().getItemById(this.modelId)
l.g.SetItemIcon(this.icon,e.icon,o.b.eItem,!1)}this.startVec=this.start,this.endVec=this.p_end,this.boom.SetActive(!1),this.flyEff.SetActive(!0),
this.tween.AddEventHandler(this.CreateDelegate(this.OnIconFlyFinished)),this.tween.SetFrom(this.startVec),this.tween.SetTo(this.p_end),this.tween.durationSet(this.speed),
this.tween.enabled=!0,this.tween.ResetToBeginning(),this.tween.PlayForward(),this.targetScale&&(this.tweenScale.SetTo(this.targetScale),this.tweenScale.durationSet(this.speed),
this.tween.enabled=!0,this.tweenScale.ResetToBeginning(),this.tweenScale.PlayForward())}OnIconFlyFinished(){this.flyEff.SetActive(!1),
this.boom.transform.SetLocalPosition(this.endVec),this.boom.SetActive(!1),this.boom.SetActive(!0),r.C.Inst_get().ClearInterval(this.intervalId),
this.intervalId=r.C.Inst_get().SetInterval(this.CreateDelegate(this.ResetState),200,1)}ResetState(){this.isPlay=!1,this.node.SetActive(!1)}})||n},57522:(e,t,i)=>{"use strict"
i.d(t,{h:()=>h})
var n=i(17409),s=i(56937),a=i(18202),r=i(31222),l=i(5494),o=i(52726),_=i(79534),u=i(61182)
class h{constructor(){this.flyItemView=null,this.startVec=null,this.endVec=null,this.modelId=0,this.multipleModelId=null,this.targetScale=null,
this._degf_CallDestoryFlyItemView=null,this._degf_OnFlyItemViewLoaded=null,this.speed=null,this.delay=null,this.startVec=_.P.zero_get(),this.endVec=_.P.zero_get(),
this._degf_CallDestoryFlyItemView=()=>this.CallDestoryFlyItemView(),this._degf_OnFlyItemViewLoaded=e=>this.OnFlyItemViewLoaded(e)}static Inst_get(){
return null==h.inst&&(h.inst=new h),h.inst}PlayFlyItem(e,t,i,s,a,r,o){null==r&&(r=1),this.flyItemView=(0,n.Y)(l.I.eCommonFlyItemPanel),
this.flyItemView?this.flyItemView.PlayFlyItem(e,t,i,s,a,r,o):(s||(this.startVec=e.Clone(),this.endVec=t.Clone(),this.modelId=i),this.multipleModelId=s,this.targetScale=a,
this.speed=r,this.delay=o,this.OpenFlyItemView())}OpenFlyItemView(){const e=new s.v
e.layerType=o.F.Effect,r.N.inst.OpenById(l.I.eCommonFlyItemPanel,this._degf_OnFlyItemViewLoaded,this._degf_CallDestoryFlyItemView,e)}OnFlyItemViewLoaded(e){
return null==this.flyItemView&&(this.flyItemView=new u.C(null),this.flyItemView.setId(e,null,0)),this.flyItemView}CallDestoryFlyItemView(){
null!=this.flyItemView&&(a.g.DestroyUIObj(this.flyItemView),this.flyItemView=null)}CloseFlyItemView(){r.N.inst.CloseById(l.I.eCommonFlyItemPanel)}}h.inst=null},61182:(e,t,i)=>{
"use strict"
i.d(t,{C:()=>I})
var n,s=i(18998),a=i(75507),r=i(6847),l=i(83908),o=i(46282),_=i(38836),u=i(5924),h=i(61911),c=i(18202),d=i(5494),m=i(85602),p=i(56505),g=i(57522)
let I=(0,r.s_)(d.I.eCommonFlyItemPanel,o.Z.ui_comm_flyitemview).waitPrefab(o.Z.ui_comm_flyitem).register()(n=class extends((0,l.pA)(h.f)()){constructor(...e){super(...e),
this.needPickDic=null,this.flyItems=null,this.intervalId=-1,this._degf_AutoClose=null,this.flyItemControl=null}InitView(){super.InitView(),this.flyItems=new m.Z,
this.flyItemControl=g.h.Inst_get(),this.DestoryPanelLevel=h.f.DestoryLevel0}OnAddToScene(){super.OnAddToScene(),
this.flyItemControl.speed&&this.flyItemControl.delay&&this.PlayFlyItem(this.flyItemControl.startVec,this.flyItemControl.endVec,this.flyItemControl.modelId,this.flyItemControl.multipleModelId,this.flyItemControl.targetScale,this.flyItemControl.speed,this.flyItemControl.delay)
}PlayFlyItem(e,t,i,n,s,a,r){if(n)for(const[l,o]of(0,_.O6)(n)){e=o.startVec,t=o.endVec,i=o.modelId
this.GetFlyItem().Play(e,t,i,s,a,r),u.C.Inst_get().ClearInterval(this.intervalId),this.intervalId=u.C.Inst_get().SetInterval(this.CreateDelegate(this.AutoClose),1e4,1)}else{
this.GetFlyItem().Play(e,t,i,s,a,r),u.C.Inst_get().ClearInterval(this.intervalId),this.intervalId=u.C.Inst_get().SetInterval(this.CreateDelegate(this.AutoClose),1e4,1)}}
GetFlyItem(){let e=null,t=0
for(;t<this.flyItems.count;){if(!this.flyItems[t].isPlay){e=this.flyItems[t]
break}t+=1}if(null==e){const t=a.o.getPrefab("ui_comm_flyitem"),i=(0,s.instantiate)(t)
e=i.getCNode(p.t),this.flyItems.Add(e),this.itemContainer.addChild(i)}return e}AutoClose(){this.Clear()}Clear(){super.Clear(),u.C.Inst_get().ClearInterval(this.intervalId)
let e=0
for(;e<=this.flyItems.count;)this.flyItems[e]&&this.flyItems[e].Clear(),e+=1
for(const[e,t]of(0,_.V5)(this.flyItems))t.Destroy(),c.g.DestroyUIObj(t)
this.flyItems.Clear(),this.itemContainer.destroyAllChildren(),this.intervalId=-1}Destroy(){super.Destroy()}})||n},68506:(e,t,i)=>{"use strict"
i.d(t,{Z:()=>y})
var n,s,a,r=i(42292),l=i(71409),o=i(17409),_=i(97461),u=i(56937),h=i(18202),c=i(5494),d=i(85602),m=i(63076),p=i(75439),g=i(92415),I=i(49239),E=i(84657),C=i(67632),S=i(92679),T=i(85751),f=i(24594)
function A(e,t,i,n,s){var a={}
return Object.keys(n).forEach((function(e){a[e]=n[e]})),a.enumerable=!!a.enumerable,a.configurable=!!a.configurable,("value"in a||a.initializer)&&(a.writable=!0),
a=i.slice().reverse().reduce((function(i,n){return n(e,t,i)||i}),a),s&&void 0!==a.initializer&&(a.value=a.initializer?a.initializer.call(s):void 0,a.initializer=void 0),
void 0===a.initializer&&(Object.defineProperty(e,t,a),a=null),a}let y=(n=(0,l.GH)(g.k.SM_CommonRewardTips),a=class e{constructor(){this.param=null,this.view=null,
this.RegisterProtocal()}static Inst_get(){return null==e.inst&&(e.inst=new e),e.inst}RegisterProtocal(){}SM_CommonRewardTipsHandle(e){const t=e.andReward,i=new d.Z
if(null!=t&&null!=t.rewards){let e=0
for(;e<t.rewards.Count();){const n=m.M.wrapReward(t.rewards[e])
i.Add(n),e+=1}}i.Sort(this.SortFunc)
const n=new f.V
if(n.rewardLis=i,204241==e.reasonCode&&(n.countDownTime=p.D.getInstance().GetIntValue("REWARDSHOW:TIME")),10109==e.reasonCode){const e=n.rewardLis[0]
if(e){const t=n.rewardLis[0].cfgData_get(),i=T.u.SetStringColor(T.u.getColorStrByQuality(e.Quality_get()),t.name)
n.desc=`恭喜您获得了珍稀道具${i}`}_.i.Inst.RaiseEvent(S.g.STOP_PANDORABOX_QUICKUSE)}10034==e.reasonCode&&(E.m.GetInst().isReceive=!0,I.k.GetInst().CloseRechargeByTesterView()),this.Open(n)}
SortFunc(e,t){const i=C.n.Inst_get().IsKeyItemId(e.cfgData_get().id),n=C.n.Inst_get().IsKeyItemId(t.cfgData_get().id)
if(i&&!n)return-1
if(!i&&n)return 1
const[s,a]=[e.Quality_get(),t.Quality_get()]
return s!=a?a-s:e.cfgData_get().sort-t.cfgData_get().sort}Open(e){if(this.param=e,null!=this.view&&this.view.isShow_get())this.view.UpdateView()
else if(null==this.view||!this.view.isShow_get()){const e=new u.v
e.layerType=this.param.layer,e.isShowMask=!0,e.maskAlpha=.7,(0,o.Yp)(c.I.GetRewardTipPanel,e)}}ShowHandler(e){return this.view}CallDestroy(){h.g.DestroyUIObj(this.view),
this.view=null}Close(){(0,o.sR)(c.I.GetRewardTipPanel)}},a.inst=null,A(s=a,"Inst_get",[r.Vx],Object.getOwnPropertyDescriptor(s,"Inst_get"),s),
A(s.prototype,"SM_CommonRewardTipsHandle",[n],Object.getOwnPropertyDescriptor(s.prototype,"SM_CommonRewardTipsHandle"),s.prototype),s)},24594:(e,t,i)=>{"use strict"
i.d(t,{V:()=>a})
var n=i(52726),s=i(85602)
class a{constructor(){this.confirmBtnHandle=null,this.confimBtnLbl="确定",this.desc="恭喜您获得以下奖励",this.layer=n.F.Tip,this.rewardLis=null,this.countDownTime=0,this.tiredValue=0,
this.rewardLis=new s.Z}}},2886:(e,t,i)=>{"use strict"
i.d(t,{n:()=>_})
var n=i(18202),s=i(60130),a=i(96710),r=i(16261),l=i(30849)
class o extends l.C{constructor(...e){super(...e),this.headIcon=null}InitView(){this.headIcon=new r.X,this.headIcon.setId(this.FatherId,this.FatherComponentID,1)}Destory(){
this.headIcon=null}SetHeadIcon(e){}SetSize(e,t){this.headIcon.widthSet(e),this.headIcon.heightSet(t)}}class _{constructor(){this.headSpr=null,this.headTex=null,
this.headContainer=null,this.isGray=!1,this.headId=0}Init(e,t){this.headContainer=e,this.headSpr=new a.I
let i=n.g.GetResFindId("ui_comm_sprite_head")
this.headSpr.setId(i,null,0),this.headSpr.node.transform.SetParent(this.headContainer.FatherId,this.headContainer.ComponentId),this.headSpr.node.SetActive(!1),
this.headSpr.onClick=t,this.headTex=new o,i=n.g.GetResFindId("ui_comm_texture_head"),this.headTex.setId(i,null,0),
this.headTex.node.transform.SetParent(this.headContainer.FatherId,this.headContainer.ComponentId),this.headTex.node.SetActive(!1)}Destory(){this.headSpr.Destory(),
n.g.DestroyUIObj(this.headSpr),this.headSpr=null,this.headTex.Destory(),n.g.DestroyUIObj(this.headTex),this.headTex=null,this.headContainer=null,this.headId=0}SetHeadIcon(e,t,i,n){
null==n&&(n=!1),this.headId=e,this.headSpr.node.SetActive(0!=e),this.headTex.node.SetActive(0==e),this.headSpr.headFrame.node.SetActive(!1),
0==e?this.headTex.SetHeadIcon(i):this.headSpr.SetHeadIcon(e,t,n)}SetGray(e){null==e&&(e=!1),this.isGray=e,
0==this.headId?s.O.makeGoGray(this.headTex.node,e,!0):s.O.makeGoGray(this.headSpr.node,e,!0)}SetSize(e,t){0==this.headId?this.headTex.SetSize(e,t):this.headSpr.SetSize(e,t)}
SetHeadFrame(e){this.headSpr.SetHeadFrameIcon(e)}SetFrameSize(e,t){this.headSpr.SetFrameSize(e,t)}}},96710:(e,t,i)=>{"use strict"
i.d(t,{I:()=>o})
var n=i(57834),s=i(72005),a=i(30849),r=i(98885),l=i(33314)
class o extends a.C{constructor(){super(),this.headIcon=null,this.onClick=null,this._degf_OnHeadClick=null,this.headFrame=null,this._degf_OnHeadClick=(e,t)=>this.OnHeadClick(e,t)}
InitView(){super.InitView(),this.headIcon=this.CreateComponent(s.w,1),this.headFrame=this.CreateComponent(s.w,2)}Destory(){
n.i.Get(this.headIcon.node).RemoveonClick(this._degf_OnHeadClick),this.onClick=null}OnHeadClick(e,t){null!=this.onClick&&this.onClick()}SetHeadIcon(e,t,i){
const s=l.Z.GetJobIcon(e,t,i)
r.M.IsNullOrEmpty(s)||(n.i.Get(this.headIcon.node).RegistonClick(this._degf_OnHeadClick),this.headIcon.spriteNameSet(s),this.headIcon.MakePixelPerfect())}SetSize(e,t){
this.headIcon.widthSet(e),this.headIcon.heightSet(t)}SetHeadFrameIcon(e){this.headFrame.node.SetActive(!0),this.headFrame.spriteNameSet(e),this.headFrame.MakePixelPerfect()}
SetFrameSize(e,t){this.headFrame.widthSet(e),this.headFrame.heightSet(t)}}},74045:(e,t,i)=>{"use strict"
i.d(t,{t:()=>o})
var n=i(17409),s=i(49655),a=(i(66788),i(56937)),r=i(18202),l=i(33854)
class o{get view(){return(0,n.Y)(s.o.InfoTipView)}constructor(){this.tipVo=null,this._degf_CallDestroy=null,this._degf_ShowHandler=null,
this._degf_CallDestroy=()=>this.CallDestroy(),this._degf_ShowHandler=e=>this.ShowHandler(e)}static Inst(){return null==o.inst&&(o.inst=new o),o.inst}Open(e){this.tipVo=e
const t=new a.v
t.layerType=this.tipVo.layer,t.isShowMask=this.tipVo.isShowMask,0!=e.maskAlpha&&(t.maskAlpha=e.maskAlpha),this.view?this.view.OnAddToScene():(0,n.Yp)(s.o.InfoTipView,t)}
ShowHandler(e){return this.view}CallDestroy(){r.g.DestroyUIObj(this.view),this.view=null,l.t.Inst_get().CloseWayTip(),this.tipVo=null}Close(){(0,n.sR)(s.o.InfoTipView)}}o.inst=null
},39879:(e,t,i)=>{"use strict"
i.d(t,{L:()=>o})
var n=i(93984),s=i(86133),a=i(66788),r=i(55360),l=i(38962)
class o{constructor(){this.noticeMap=null,this.noticeMap=new l.X
const e=r.Y.Inst.GetOrCreateCsv(n.h.eCommonNoticeResource)
this.noticeMap=e.GetCsvMap()}static Inst(){return null==o._inst&&(o._inst=new o),o._inst}getItemById(e){
return this.noticeMap.LuaDic_ContainsKey(e)?this.noticeMap[e]:(a.Y.LogError((0,s.T)("CommonNotice表里面没有这个id：")+e),null)}}o._inst=null},90930:(e,t,i)=>{"use strict"
i.d(t,{i:()=>n})
class n{constructor(e,t){this.index=0,this.type=null,this.index=e,this.type=t}}},2446:(e,t,i)=>{"use strict"
i.d(t,{u:()=>a})
var n=i(85602),s=i(90930)
class a{constructor(e,t,i,a,r){if(this.text=null,this.pureText=null,this.startIndex=0,this.endIndex=0,this.currencyList=null,this.currencyList=new n.Z,this.text=e,this.pureText=t,
this.startIndex=i,this.endIndex=a,null!=r){let e=0
for(;e<r.Count();){if(r[e].index>=this.startIndex&&r[e].index<=this.endIndex){const t=r[e].index-this.startIndex,i=new s.i(t,r[e].type)
this.currencyList.Add(i)}e+=1}}}}},49067:(e,t,i)=>{"use strict"
i.d(t,{B:()=>r})
var n=i(86133),s=i(52726),a=i(85602)
class r{constructor(){this.infoId=null,this.confirmHandle=null,this.cancelHandle=null,this.closeHandle=null,this.confirmParam=null,this.cancelParam=null,this.cancelDontClose=!1,
this.dontClose=!1,this.isDoCancleInClose=!1,this.isJudgeSafeLock=!1,this.showNum=!1,this.replaceParams=null,this.confirmText=null,this.cancelText=null,this.needCheckBox=!1,
this.isCheckBoxOn=!1,this.checkhandler=null,this.checkChanged=null,this.isShowMask=!0,this.tipstype=2,this.isCancelForCheckBox=!1,this.layer=s.F.Alert,this.showConfirmCountdown=!1,
this.confirmCountdown=0,this.confirmCountdownHandle=null,this.banConfirmBtnInCountdown=!1,this.showEquip=null,this.topContent=null,this.maskAlpha=0,this.replaceParams=new a.Z,
this.confirmText=(0,n.T)("确 定"),this.cancelText=(0,n.T)("取 消")}}},48823:(e,t,i)=>{"use strict"
i.d(t,{I:()=>o})
var n,s=i(18998),a=i(83908),r=i(30849),l=i(19519)
let o=s._decorator.ccclass("InfoTipCurrencyItem")(n=class extends((0,a.pA)(r.C)()){InitView(){super.InitView()}SetData(e){const t=l.J.GetCurrencyIconUrl(e)
this.icon.spriteNameSet(t),this.node.SetActive(!0)}Hide(){this.node.SetActive(!1)}})||n},62875:(e,t,i)=>{"use strict"
i.d(t,{t:()=>g})
var n=i(84193),s=i(99294),a=i(57834),r=i(93877),l=i(30849),o=i(18202),_=i(98885),u=i(85602),h=i(79534),c=i(81433),d=i(90930),m=i(2446),p=i(48823)
class g extends l.C{constructor(){super(),this.label=null,this.currencyWidget=null,this.text=null,this.fontSize=20,this.spacingY=4,this.isTrueSelect=!1,this.btnColorType=0,
this.centerWidgetPos=null,this.countdown=0,this.priot=0,this.spriteList=null,this.pools=null,this.vecX=null,this.vecY=null,this.centerWidgetPos=new h.P(8,36,0)}InitView(){
super.InitView(),this.label=this.CreateComponent(n.n,1),this.currencyWidget=this.CreateComponent(s.z,2),this.text=this.CreateComponent(r.Q,3),this.spriteList=new u.Z,
this.pools=new u.Z
const e=a.i.Get(this.text.node)
null!=e&&e.RegistonClick(this.CreateDelegate(this.OnTextClick)),this.vecX=0,this.vecY=0,this.fontSize=this.text.fontSize(),this.spacingY=this.text.spacingY(),
this.fontSize=this.text.fontSize()}OnTextClick(e,t){c.J.OnCommonClick(this.text)}Text_Set(e,t){this.SetText(this.label,e,t)}SetText(e,t,i){null==i&&(i=!1),this.RelcyItem()
const n=new u.Z,s=new u.Z
let a=null,r=0,l=0,o=e.StripSymbols(t),h=0
for(;h<g.currencyStrList.count;){const e=g.currencyStrList[h]
for(;_.M.IndexOf(o,e,0)>=0;){r=_.M.IndexOf(o,e,0),t=_.M.ReplaceSlow(t,e,"     "),o=_.M.ReplaceSlow(o,e,"     ")
const i=new d.i(r,g.currencyTypeStrList[h])
n.Add(i)}h+=1}if(_.M.IndexOf(t,_.M.s_NN_CHAR,0)<0)a=new m.u(t,e.StripSymbols(t),0,_.M.Length(o)-1,n),s.Add(a)
else{let i=0,u=0,h=null,c=null
for(;_.M.IndexOf(t,_.M.s_NN_CHAR,i)>=0;)r=_.M.IndexOf(t,_.M.s_NN_CHAR,i),l=_.M.IndexOf(o,_.M.s_NN_CHAR,u),h=_.M.SubStringWithEnd(t,i,r),c=e.StripSymbols(h),a=new m.u(h,c,u,l,n),
s.Add(a),i=r+_.M.Length(_.M.s_NN_CHAR),u=l+_.M.Length(_.M.s_NN_CHAR)
h=_.M.SubStringWithEnd(t,i,_.M.Length(t)),c=e.StripSymbols(h),a=new m.u(h,c,u,_.M.Length(o),n),s.Add(a)}let c=0
for(;c<s.Count();){const t=e.CalculateSingleLineX(s[c].text,this.fontSize)
let n=0
for(;n<s[c].currencyList.Count();){const a=e.CalculateSingleLineX(_.M.SubStringWithEnd(s[c].pureText,0,s[c].currencyList[n].index),this.fontSize)
0==this.priot?this.vecX=a-7:this.vecX=a-t/2+10,this.vecY=i?e.node.transform.GetLocalPosition().y+(s.Count()-c)*(this.fontSize+this.spacingY)+5:e.node.transform.GetLocalPosition().y-c*(this.fontSize+this.spacingY)+5
const r=this.GetPool()
this.InitCurrencyPos(r,s[c].currencyList[n].type),n+=1}c+=1}e.SetCommonTxt(t)}GetPool(){let e=null
if(this.pools.count>0)e=this.pools[this.pools.count-1],this.pools.RemoveAt(this.pools.count-1)
else{const t=o.g.GetResFindId("ui_infotip_currency")
e=new p.I,e.setId(t,null,0),e.node.transform.ComponentId=-1}return this.spriteList.Add(e),e}InitCurrencyPos(e,t){
e.node.transform.SetParent(this.currencyWidget.FatherId,this.currencyWidget.ComponentId),e.node.transform.SetLocalPositionXYZ(this.vecX,this.vecY,0),e.SetData(t)}GetTextRows(e){
return _.M.Split(e,_.M.s_NN_CHAR).count}RelcyItem(){if(null!=this.spriteList){const e=this.spriteList.count-1
for(let t=0;t<=e;t++)this.spriteList[t].Hide(),this.pools.Add(this.spriteList[t])
this.spriteList.Clear()}}Clear(){super.Clear(),this.RelcyItem()}Destroy(){const e=a.i.Get(this.text.node)
null!=e&&e.RemoveonClick(this.CreateDelegate(this.OnTextClick)),super.Destroy(),this.RelcyItem()
const t=this.pools.count-1
for(let e=0;e<=t;e++)this.pools[e].Destroy()
this.pools=null,this.spriteList=null,this.label=null,this.currencyWidget=null,this.text=null}}
g.currencyTypeStrList=new u.Z(["GOLD","GOLD_DIAMOND","BLUE_DIAMOND","BIND_DIAMOND","HONOUR","SKILL_POINT","CONSIGN_SCORE","ASURAM_TOKEN"]),
g.currencyStrList=new u.Z(["[CURRENCY:GOLD]","[CURRENCY:GOLD_DIAMOND]","[CURRENCY:BLUE_DIAMOND]","[CURRENCY:BIND_DIAMOND]","[CURRENCY:HONOUR]","[CURRENCY:SKILL_POINT]","[CURRENCY:CONSIGN_SCORE]","[CURRENCY:ASURAM_TOKEN]"])
},13796:(e,t,i)=>{"use strict"
i.d(t,{B:()=>A})
var n=i(85602),s=i(84528),a=i(41163),r=i(12779),l=i(87851),o=i(86770),_=i(37927),u=i(81476),h=i(18815),c=i(37648),d=i(62734),m=i(20719),p=i(22046),g=i(95155),I=i(54130),E=i(51965),C=i(37104),S=i(13526),T=i(88199),f=i(72631)
class A{GetDefaultViewIndex(e,t,i){null==t&&(t=new n.Z)
const s=t.count
let a=0
for(;a<s;){const e=d.f.Inst.GetData(t[a])
if(null!=e&&e.show)return a
a+=1}return 0}static GetDefaultViewType(e,t,i){null==t&&(t=new n.Z)
const s=t.count
let a=0
for(;a<s;){const e=d.f.Inst.GetData(t[a])
if(null!=e&&e.show)return A.GetViewTypeByTabId(i[a])
a+=1}let r="",l=100
const o=c.P.Inst_get()
let _=0
for(;_<e.count;){const t=f.E.Inst().getItemById(e[_])
null!=t&&t.tabStep<l&&(0==t.tabOpenID||o.IsFunctionOpened(t.tabOpenID))&&(r=t,l=t.tabStep),_+=1}return A.GetViewTypeByTabId(r.ID)}static GetViewTypeByTabId(e){
return e==T.Z.CHARACTER_PROPERTY?I.Q.Normal:e==T.Z.CHARACTER_PROPERTY_BASE?E.f.Normal:e==T.Z.CHARACTER_PROPERTY_ADDPOINT?E.f.AddAttrs:e==T.Z.CHARACTER_PROPERTY_FIGHTSTAGE?E.f.FightStage:e==T.Z.CHARACTER_PROPERTY_TITLE?E.f.TITLE:e==T.Z.CHARACTER_SKILL_PROSKILL?S.c.ProSkill:e==T.Z.CHARACTER_SKILL_PASSIVESKILL?S.c.PassiveSkill:e==T.Z.CHARACTER_SKILL_MASTERTALENT?S.c.TalentSkill:e==T.Z.CHARACTER_FASHION_WEAR?0:e==T.Z.CHARACTER_FASHION_RESOLVE?1:e==T.Z.FORGE_ENHANCE_EQUIPENHANCE?u.s.EnhanceTab:e==T.Z.FORGE_ENHANCE_EQUIPADD?u.s.AdditionTab:e==T.Z.FORGE_ENHANCE_LUCKYADD?u.s.FortuneTab:e==T.Z.FORGE_ENHANCE_PROMOTE?u.s.EquipPromoteTab:e==T.Z.FORGE_ENHANCE_SUIT?u.s.SuitTab:e==T.Z.FORGE_ENHANCE_AWAKE?u.s.AwakeTab:e==T.Z.FORGE_SUIT_BASE?h.p.Base:e==T.Z.FORGE_SUIT_ENHANCE?h.p.Enhance:e==T.Z.FORGE_COMPOSE_ITEM?m.Z.CommonCompoundTab:e==T.Z.FORGE_COMPOSE_WING?m.Z.WingCompoundTab:e==T.Z.FORGE_COMPOSE_JEWELRY?m.Z.SuperiorCompoundTab:e==T.Z.FORGE_COMPOSE_GUARD?m.Z.GuardCompoundTab:e==T.Z.FORGE_COMPOSE_MASTER?m.Z.MasterCompoundTab:e==T.Z.FORGE_COMPOSE_ANGEL?m.Z.AngelCompoundTab:e==T.Z.BAG_BAG?o.D.bagTab:e==T.Z.BAG_WAREHOUSE?o.D.warehouseTab:e==T.Z.BAG_SHOP?o.D.shopTab:e==T.Z.BAG_SHOP_WITHONESHOP?A.UNDEFINED:e==T.Z.DAILY_COPY_BELIEL?_.i.BelielTab:e==T.Z.DAILY_COPY_BLOOD?_.i.BloodTownTab:e==T.Z.DAILY_COPY_DREAMLAND?_.i.DreamlandTab:e==T.Z.DAILY_COPY_LOSTSECRETES?_.i.LoseTab:e==T.Z.DAILY_COPY_BRAVE?_.i.BraveTab:e==T.Z.DAILY_RECOVER_DAYONE||e==T.Z.DAILY_RECOVER_DAYTWO||e==T.Z.DAILY_RECOVER_DAYTHREE?A.UNDEFINED:e==T.Z.BOSS_WORLDBOSS?p.l.WORLDBOSS:e==T.Z.BOSS_NEUTROLBOSS?p.l.NEUTROLBOSS:e==T.Z.BOSS_VIPBOSS?p.l.VIPBOSS:e==T.Z.BOSS_KARIMABOSS?p.l.KARIMABOSS:e==T.Z.BOSS_ANCIENTBOSS?p.l.ANCIENTBOSS:e==T.Z.MARKET_MALL?C.$.Mall:e==T.Z.MARKET_BLACK?C.$.BlackMarket:e==T.Z.MARKET_TRADE?C.$.Trade:e==T.Z.MARKET_AUCTION?C.$.Auction:e==T.Z.MARKET_RECHARGE?C.$.Recharge:e==T.Z.MARKET_MALL_WEEKLIMIT?0:e==T.Z.MARKET_MALL_ITEM?1:e==T.Z.MARKET_MALL_GROW?2:e==T.Z.MARKET_MALL_SCORE?4:e==T.Z.MARKET_MALL_HONOR?5:e==T.Z.MARKET_BLACK_LV1?0:e==T.Z.MARKET_BLACK_LV2?1:e==T.Z.MARKET_BLACK_LV3?2:e==T.Z.MARKET_BLACK_LV4?3:e==T.Z.MARKET_BLACK_LV5?4:e==T.Z.MARKET_TRADE_BUY?0:e==T.Z.MARKET_TRADE_SELL?1:e==T.Z.MARKET_TRADE_CONSIGN?2:e==T.Z.MARKET_TRADE_CONSIGN_SELL?3:e==T.Z.MARKET_AUCTION_LIST?0:e==T.Z.MARKET_AUCTION_ASURAM_LIST?1:e==T.Z.MARKET_AUCTION_MYAUCTION?3:e==T.Z.MARKET_AUCTION_RECORD?4:e==T.Z.MARKET_AUCTION_ATTENTION?5:e==T.Z.MARKET_AUCTION_GROUNDING?2:e==T.Z.WELFARE_SEVENDAY?g.S.SEVEN_DAY:e==T.Z.DAILYGIFT?g.S.DAILYGIFT:e==T.Z.WELFARE_SIGN?g.S.SIGN:e==T.Z.WELFARE_LEVELREWARD?g.S.LEVEL:e==T.Z.WELFARE_INVEST?g.S.INVSET:e==T.Z.WELFARE_FUND?g.S.FUND:e==T.Z.WELFARE_PRAY?g.S.LEVEL:e==T.Z.WELFARE_TIREDVALUE?g.S.TIREDVALUE:e==T.Z.MONTH_CARD?g.S.MONTH_CARD:e==T.Z.WELFARE_LOTTERY?g.S.LOTTETY:e==T.Z.WELFARE_LOTTERY_SEARCH||e==T.Z.WELFARE_LOTTERY_WAREHOUSE||e==T.Z.WELFARE_LOTTERY_SHOP?A.UNDEFINED:e==T.Z.WELFARE_RECOVER?g.S.RECOVER:e==T.Z.WELFARE_CDK?g.S.CDK:e==T.Z.ASURAM_INFO?l.t.ASURAM:e==T.Z.ASURAM_BUILD?l.t.BUILDING:e==T.Z.ASURAM_TASK?l.t.TASK:e==T.Z.ASURAM_ACTIVITY?l.t.ACTIVITY:e==T.Z.ASURAM_INFO_OVERVIEW?a.Z.OVERVIEW:e==T.Z.ASURAM_INFO_MEMBERS?a.Z.MEMBER:e==T.Z.ASURAM_INFO_ALLIANCELIST?a.Z.ALLIANCELIST:e==T.Z.ASURAM_ACTIVITY_BOSS?s.z.ALLIANCEBOSS:e==T.Z.ASURAM_ACTIVITY_MATCH||e==T.Z.RANK_RANK||e==T.Z.RANK_RANK_LEVEL||e==T.Z.RANK_RANK_EQUIP||e==T.Z.RANK_RANK_BATTLESCORE||e==T.Z.RANK_RANK_CULTIVATION||e==T.Z.RANK_RANK_WEALTH||e==T.Z.RANK_RANK_FRIENDSHIP||e==T.Z.RANK_RANK_ASURAM?A.UNDEFINED:e==T.Z.ARMYEQUIP_IMMORTAL?r.Q.IMMORTAL:e==T.Z.ARMYEQUIP_RUNE?r.Q.RUNES:e==T.Z.ARMYEQUIP_HORSE||e==T.Z.SETTING_SETTING?A.UNDEFINED:e==T.Z.SETTING_HANG?0:e==T.Z.SETTING_SYSTEM?1:e==T.Z.SETTING_PRIVATE||e==T.Z.SETTING_CHAT?2:e==T.Z.SETTING_SAFELOCK?4:e==T.Z.FORGE_ENHANCE_EXELLENTADD?u.s.ExcellentAdditionTab:e==T.Z.FORGE_ENHANCE_STARTRANSFER?u.s.StarTransferTab:e==T.Z.FORGE_ENHANCE_JEWELINLAY?u.s.JewelInlayTab:A.UNDEFINED
}}A.UNDEFINED=-100},14207:(e,t,i)=>{"use strict"
i.d(t,{E:()=>l})
var n=i(9986),s=i(9057),a=i(57834),r=i(92679)
class l extends s.x{constructor(){super(),this.button=null,this.tabItemData=null,this._degf_OnButtonClick=null,this._degf_OnButtonClick=(e,t)=>this.OnButtonClick(e,t)}InitView(){
this.button=new n.W,this.button.setId(this.FatherId,this.FatherComponentID,1),this.AddLis()}SetData(e){this.tabItemData=e,this.SetButtonName()}SetButtonName(){
null!=this.button&&null!=this.tabItemData&&null!=this.tabItemData.btnName&&this.button.SetText(this.tabItemData.btnName)}AddLis(){
null!=this.button&&a.i.Get(this.button.node).RegistonClick(this._degf_OnButtonClick)}RemoveLis(){
null!=this.button&&a.i.Get(this.button.node).RemoveonClick(this._degf_OnButtonClick)}OnButtonClick(e,t){
null!=this.tabItemData&&this.tabItemData.RaiseEvent(r.g.TAB_BTN_CLICK,this.tabItemData.id)}Clear(){}Destroy(){this.RemoveLis(),this.button=null}SetIsEnabled(e){
null!=this.button&&this.button.SetIsEnabled(e)}}},10821:(e,t,i)=>{"use strict"
i.d(t,{j:()=>F})
var n=i(16812),s=i(85602),a=i(38962)
let r=null,l=null,o=null,_=null,u=null,h=null,c=null,d=null,m=null,p=null,g=null,I=null,E=null,C=null,S=null,T=null,f=null,A=null,y=null,R=null,D=null,w=null,L=null,v=null,O=null,P=null,N=null,M=null,b=null,G=null,U=null,B=null,k=null
class F extends n.k{static __StaticInit(){r=table.insert,l=table.sort,o=table.remove,_=s.Z.new,u=s.Z.Add,h=s.Z.AddRang,c=s.Z.Clear,d=s.Z.Contains,m=s.Z.Insert,p=s.Z.InsertRange,
g=s.Z.Remove,I=s.Z.RemoveAt,E=s.Z.IndexOf,C=s.Z.Count,S=s.Z.Length,T=s.Z.RemoveRange,f=s.Z.GetRange,A=s.Z.Pop,y=s.Z.Reverse,R=s.Z.Sort,D=a.X.new,w=a.X.LuaDic_Add,
L=a.X.LuaDic_SetItem,v=a.X.LuaDic_IsNullValue,O=a.X.LuaDic_GetItem,P=a.X.LuaDic_Count,N=a.X.LuaDic_ContainsKey,M=a.X.LuaDic_AddOrSetItem,b=a.X.LuaDic_Keys,G=a.X.LuaDic_Values,
U=a.X.LuaDic_Clear,B=a.X.LuaDic_ContainsValue,k=a.X.LuaDic_Remove}constructor(e,t,i,n,s,a=null){super(),this.m_button=null,this.id=0,this.m_funcId=0,this.sortIndex=0,
this.m_level=0,this.btnName=null,this.userData=null,this.guideId=null,this.guideParam=null,null==s&&(s=0),null==i&&(i=0),this.id=e,this.userData=a,this.m_funcId=i,this.sortIndex=t,
this.btnName=n,this.m_level=s}}},11e3:(e,t,i)=>{"use strict"
i.d(t,{u:()=>m})
var n=i(38836),s=i(98800),a=i(16812),r=i(31222),l=i(39950),o=i(85602),_=i(38962),u=i(37648),h=i(63945),c=i(92679),d=i(14207)
class m extends a.k{constructor(){super(!1,GF.INT(l.Y.eUISingleton)),this._degf_OnMallTopTabLoaded=null,this._degf_OnMallTopTabReposition=null,this._degf_OnButtonClick=null,
this._degf_OnTabButtonClick=null,this.viewObj=null,this.curId=-1,this.tabDataList=null,this.tabItemList=null,this.m_IsGrid=!0,this.isTab=!0,this.isClear=!0,this.grid=null,
this.funcDic=null,this.loadpath=null,this.defaultId=0,this.IsDestory=!0,this.table=null,this.funcId=null,this.id=null,this._degf_OnMallTopTabLoaded=e=>this.OnMallTopTabLoaded(e),
this._degf_OnMallTopTabReposition=()=>this.OnMallTopTabReposition(),this._degf_OnButtonClick=(e,t)=>this.OnButtonClick(e,t),this._degf_OnTabButtonClick=e=>this.OnTabButtonClick(e)}
OnMallTopTabLoaded(e){const t=new d.E
return t.setId(e,null,0),r.N.inst.SetChildDepth(h.x.inst.GetMarketMainPanelFatherId(),e),t}OnMallTopTabReposition(){
this.IsDestory||this.grid.itemList.Count()==this.tabDataList.Count()&&(0!=this.isClear?(this.isClear=!1,this.SetItems(this.grid.itemList),
this.RefreshTab()):this.tabItemList.Count()!=this.grid.itemList.Count()&&(this.SetItems(this.grid.itemList),this.RefreshTab()))}SetItems(e){
if(null==e)return void(this.tabItemList=null)
let t=0
for(null==this.tabItemList?this.tabItemList=new o.Z:this.tabItemList.Clear();t<e.Count();)this.tabItemList.Add(e[t]),t+=1}SetData(e,t,i,n,s){this.RemoveLis(),this.IsDestory=!1,
null==s&&(s=!0),this.isClear=!0,this.funcDic=new _.X,this.tabDataList=e,this.grid=t,this.viewObj=i,this.isTab=s,this.defaultId=n,this.curId=n,
this.grid.OnReposition_set(this._degf_OnMallTopTabReposition),this.SortData(),this.grid.data_set(this.tabDataList)}SortData(){new o.Z
let e=0
for(;e<this.tabDataList.Count()-1;){let t=e+1
for(;t<this.tabDataList.Count();){const i=this.tabDataList[e],n=this.tabDataList[t]
if(i.sortIndex>n.sortIndex){const i=this.tabDataList[e]
this.tabDataList[e]=this.tabDataList[t],this.tabDataList[t]=i}t+=1}e+=1}}RefreshTab(e){null!=this.tabItemList&&0!=this.tabItemList.Count()&&(null==e&&(e=!0),this.RemoveLis(),
this.SetButtonState(),this.AddLis(),e&&this.BtnReposition(),this.isTab&&this.SetIsEnable())}BtnReposition(){if(null==this.tabItemList)return
let e=0
for(;e<this.tabItemList.Count();)this.tabItemList[e].node.transform.SetParent(this.viewObj.FatherId,this.viewObj.ComponentId),e+=1
let t=null
t=this.m_IsGrid?this.grid.node:this.table.node
let i=0
for(;i<this.tabItemList.Count();)this.tabItemList[i].node.transform.SetParent(t.FatherId,t.ComponentId),i+=1
this.m_IsGrid?this.grid.Reposition():this.table.Reposition()}SetId(e){this.curId=e,this.RefreshTab()}SetButtonState(){if(null==this.tabItemList)return
let e=0
for(;e<this.tabItemList.Count();){const t=this.tabItemList[e].tabItemData,i=s.Y.Inst.PrimaryRoleInfo_get().m_level>t.m_level
if(0==t.m_funcId||null==t.m_funcId)t.node.SetActive(i)
else{const n=u.P.Inst_get().IsFuncOrActivityOpened(t.m_funcId)
this.tabItemList[e].button.node.SetActive(n&&i)}e+=1}}SetIsEnable(){if(null==this.tabItemList)return
let e=!1,t=0,i=-1
for(;t<this.tabItemList.Count();){const n=this.tabItemList[t],s=n.tabItemData
if(null!=n.button){const a=n.button.node.activeSelf()
a&&-1==i&&(i=t),0==s.id||null==s.id||s.id!=this.curId||0==a?n.SetIsEnabled(!0):(n.SetIsEnabled(!1),e=!0)}t+=1}if(0==e){const e=this.tabItemList[i]
e.SetIsEnabled(!1)
const t=e.tabItemData
this.curId=t.id}this.RaiseEvent(c.g.TAB_BTN_SELECT,this.curId)}AddLis(){if(null!=this.tabItemList)for(const[e,t]of(0,n.V5)(this.tabItemList)){const e=t.tabItemData
e.AddEventHandler(c.g.TAB_BTN_CLICK,this._degf_OnTabButtonClick),this.funcDic.LuaDic_AddOrSetItem(e.id,e.m_funcId)}}RemoveLis(){if(null!=this.tabDataList)for(const[e,t]of(0,
n.V5)(this.tabDataList))t!=nill&&t.RemoveEventHandler(c.g.TAB_BTN_CLICK,this._degf_OnTabButtonClick)
null!=this.funcDic&&this.funcDic.LuaDic_Clear()}OnTabButtonClick(e){let t=e,i=0
null==t&&(t=0),i=this.funcDic[e],null==i&&(i=0),this.curId=t,this.SetIsEnable()}Destroy(){this.RemoveLis(),null!=this.tabItemList&&this.tabItemList.Clear(),
null!=this.funcDic&&this.funcDic.LuaDic_Clear(),this.funcId=0,this.id=0,this.isClear=!0,this.IsDestory=!0}}},72631:(e,t,i)=>{"use strict"
i.d(t,{E:()=>l})
var n=i(93984),s=i(66788),a=i(55360),r=i(38962)
class l{constructor(){this.tabMap=null,this.tabMap=new r.X
const e=a.Y.Inst.GetOrCreateCsv(n.h.eTabResource)
this.tabMap=e.GetCsvMap()}static Inst(){return null==l._inst&&(l._inst=new l),l._inst}getItemById(e){const t=this.tabMap[e]
return null==t&&s.Y.LogError(`TABRESOURCE 找不到 id:${e}`),t}}l._inst=null},51322:(e,t,i)=>{"use strict"
i.d(t,{G:()=>m})
var n=i(38836),s=i(86133),a=i(98800),r=i(66788),l=i(57834),o=i(85602),_=i(38962),u=i(37648),h=i(87923),c=i(72631)
class d{constructor(e,t){if(this.m_button=null,this.m_id=0,this.m_funcId=0,this.m_tabId=null,this.sortIndex=0,this.m_level=0,this.m_button=e,this.m_tabId=t,null!=t&&""!=t){
const e=c.E.Inst().getItemById(t)
this.m_funcId=e.tabOpenID,this.sortIndex=e.tabStep}}}class m{constructor(e,t,i,n,l,u,h){if(this.data=null,this.funcDic=null,this.viewObj=null,this.grid=null,this.table=null,
this.m_IsGrid=!0,this.rInfo=null,this._degf_OnButtonClick=null,this.m_Destroyed=!1,this.isAddTabEvent=null,this._type_=null,null==u&&(u=!0),
this._degf_OnButtonClick=(e,t)=>this.OnButtonClick(e,t),this.grid=i,this.viewObj=n,this.m_IsGrid=u,this.table=l,null==e||null==t)return void r.Y.LogError((0,s.T)("前两个参数不能为空"))
if(e.count!=t.count)return void r.Y.LogError((0,s.T)("按钮数必须和页签id数相同"))
this.funcDic=new _.X,this.rInfo=a.Y.Inst.PrimaryRoleInfo_get(),this.data=new o.Z
let m=0
for(;m<e.count;){let i=null,n=null
null!=t&&(n=c.E.Inst().getItemById(t[m])),null!=n?i=new d(e[m],t[m]):null!=h&&(i=new d(e[m]),i.sortIndex=h[m].sortIndex,i.m_level=h[m].m_level,i.m_funcId=h[m].m_funcId),
null!=i&&this.data.Add(i),m+=1}this.SortData()}GetTypeName(){let e=""
if(null!=this.data)for(const[t,i]of(0,n.V5)(this.data))if(this.funcDic.LuaDic_ContainsKey(i.m_button.ComponentId)){e=i.m_button.GetTypeName()
break}return` 类名:${this._type_._type_full_name_} 第一个按钮信息:${e}`}__GetInternalComponents(){const e={}
if(null!=this.data)for(const[t,i]of(0,n.V5)(this.data))this.funcDic.LuaDic_ContainsKey(i.m_button.ComponentId)&&(e[t]=i.m_button)
return e}SortData(){new o.Z
let e=0
for(;e<this.data.Count()-1;){let t=e+1
for(;t<this.data.Count();){if(this.data[e].sortIndex>this.data[t].sortIndex){const i=this.data[e]
this.data[e]=this.data[t],this.data[t]=i}t+=1}e+=1}}RefreshTab(e){null==e&&(e=!0),this.SetButtonState(),null==this.isAddTabEvent||this.isAddTabEvent,e&&this.BtnReposition()}
GetBtnIdx(e){for(let t=0;t<=this.data.Count()-1;t++){const i=this.data[t]
if(null!=i.m_button&&(i.m_button.ComponentId==e||i.m_button==e))return t}return-1}BtnReposition(){let e=0
for(;e<this.data.Count();)this.viewObj.addChild(this.data[e].m_button.node),e+=1
let t=null
t=this.m_IsGrid?this.grid.node:this.table.node
let i=0
for(;i<this.data.Count();)t.addChild(this.data[i].m_button.node),i+=1}SetButtonState(){let e=0
for(;e<this.data.Count();){const t=this.data[e]
if(0==t.m_funcId||null==t.m_funcId)t.m_button.node.SetActive(!0)
else{const e=u.P.Inst_get().IsFuncOrActivityOpened(t.m_funcId)
t.m_button.node.SetActive(e)}e+=1}}AddLis(){if(null!=this.data)for(const[e,t]of(0,
n.V5)(this.data))t.m_funcId>0&&u.P.Inst_get().IsFunctionShow(t.m_funcId)&&!u.P.Inst_get().IsFunctionOpened(t.m_funcId)&&(l.i.Get(t.m_button.node).ClearClickHandler(),
l.i.Get(t.m_button.node).RegistonClick(this._degf_OnButtonClick),this.funcDic.LuaDic_AddOrSetItem(t.m_button.ComponentId,t.m_funcId))}RemoveLis(){
if(null!=this.funcDic&&0!=this.funcDic.count){if(null!=this.data)for(const[e,t]of(0,n.V5)(this.data))l.i.Get(t.m_button.node).ClearClickHandler(this._degf_OnButtonClick)
this.funcDic.LuaDic_Clear()}}OnButtonClick(e,t){let i=0
i=this.funcDic[e],null==i&&(i=0),0!=i&&i>0&&h.l.SetFunctionTip(i)}IsDestroyed(){return this.m_Destroyed}Clear(){this.data.Clear(),this.funcDic.LuaDic_Clear()}Destroy(){
this.m_Destroyed=!0,this.data.Clear(),this.funcDic.LuaDic_Clear()}}},88199:(e,t,i)=>{"use strict"
i.d(t,{Z:()=>n})
var n={CHARACTER_PROPERTY:"100100",CHARACTER_PROPERTY_BASE:"100101",CHARACTER_PROPERTY_ADDPOINT:"100102",CHARACTER_PROPERTY_FIGHTSTAGE:"100103",CHARACTER_PROPERTY_TITLE:"100104",
CHARACTER_SKILL:"100200",CHARACTER_SKILL_PROSKILL:"100201",CHARACTER_SKILL_PASSIVESKILL:"100202",CHARACTER_SKILL_EXERSIZESKILL:"100203",CHARACTER_SKILL_MASTERTALENT:"100204",
CHARACTER_SKILL_GODSKILL:"100205",CHARACTER_DIVINE:"100400",CHARACTER_SURFACE:"100300",CHARACTER_FASHION_WEAR:"100301",CHARACTER_FASHION_RESOLVE:"100302",FORGE_ENHANCE:"110100",
FORGE_ENHANCE_EQUIPENHANCE:"110101",FORGE_ENHANCE_EQUIPADD:"110102",FORGE_ENHANCE_LUCKYADD:"110103",FORGE_ENHANCE_PROMOTE:"110104",FORGE_ENHANCE_EXELLENTADD:"110105",
FORGE_ENHANCE_BAPTIZE:"110106",FORGE_ENHANCE_STARTRANSFER:"110107",FORGE_ENHANCE_JEWELINLAY:"110108",FORGE_ENHANCE_SUIT:"110109",FORGE_ENHANCE_AWAKE:"110110",
FORGE_ENHANCE_GEM:"110111",FORGE_SUIT:"110200",FORGE_SUIT_BASE:"110201",FORGE_SUIT_ENHANCE:"110202",FORGE_COMPOSE:"110300",FORGE_COMPOSE_ITEM:"110301",FORGE_COMPOSE_WING:"110302",
FORGE_COMPOSE_JEWELRY:"110303",FORGE_COMPOSE_GUARD:"110304",FORGE_COMPOSE_EQUIP_ADVANCE:"110305",FORGE_COMPOSE_DECOMPOSE:"110307",FORGE_COMPOSE_MASTER:"110306",FORGE_WING:"190700",
FORGE_WING_REFINE:"190701",FORGE_FLAG:"110500",FORGE_FLAG_REFINE:"110501",FORGE_FLAG_QUALITY:"110502",FORGE_FLAG_STRIPE:"110503",FORGE_FLAG_AWAKE:"110504",
FORGE_SACRED_MAKE:"110400",BAG_BAG:"120100",BAG_RYCOMPOUND:"120101",BAG_SUIT:"120103",BAG_WAREHOUSE:"120200",BAG_SHOP:"120300",BAG_SHOP_WITHONESHOP:"120301",
DAILY_ACTIVITY:"130100",DAILY_COPY:"130200",DAILY_COPY_BELIEL:"130201",DAILY_COPY_BLOOD:"130202",DAILY_COPY_LOSTSECRETES:"130203",DAILY_COPY_BRAVE:"130205",
DAILY_COPY_DREAMLAND:"130206",DAILY_COPY_ELEMENTDUNGEON:"130207",DAILY_ARENA:"130300",DAILY_HANG:"130400",WELFARE_RECOVER:"130500",DAILY_RECOVER_DAYONE:"130501",
DAILY_RECOVER_DAYTWO:"130502",DAILY_RECOVER_DAYTHREE:"130503",DAILY_MINE:"130700",BOSS_WORLDBOSS:"140100",BOSS_VIPBOSS:"140200",BOSS_NEUTROLBOSS:"140300",BOSS_KARIMABOSS:"140400",
BOSS_ANCIENTBOSS:"140500",MARKET_MALL:"150100",MARKET_MALL_WEEKLIMIT:"150101",MARKET_MALL_ITEM:"150102",MARKET_MALL_GROW:"150103",MARKET_MALL_SCORE:"150104",
MARKET_MALL_HONOR:"150105",MARKET_MALL_REPUTATION:"150106",MARKET_BLACK:"150200",MARKET_BLACK_LV1:"150201",MARKET_BLACK_LV2:"150202",MARKET_BLACK_LV3:"150203",
MARKET_BLACK_LV4:"150204",MARKET_BLACK_LV5:"150205",MARKET_TRADE:"150300",MARKET_TRADE_BUY:"150301",MARKET_TRADE_SELL:"150302",MARKET_TRADE_CONSIGN:"150303",
MARKET_TRADE_CONSIGN_SELL:"150304",MARKET_AUCTION:"150400",MARKET_AUCTION_LIST:"150401",MARKET_AUCTION_ASURAM_LIST:"150402",MARKET_AUCTION_MYAUCTION:"150403",
MARKET_AUCTION_RECORD:"150404",MARKET_AUCTION_ATTENTION:"150405",MARKET_AUCTION_GROUNDING:"150406",MARKET_AUCTION_CROSSAUCTION:"150407",MARKET_RECHARGE:"150500",
WELFARE_SEVENDAY:"160100",WELFARE_SIGN:"160200",WELFARE_LEVELREWARD:"240101",WELFARE_INVEST:"160400",WELFARE_FUND:"160500",WELFARE_PRAY:"240102",WELFARE_LOTTERY:"240108",
DAILYGIFT:"160800",WELFARE_LOTTERY_SEARCH:"160701",WELFARE_LOTTERY_WAREHOUSE:"160702",WELFARE_LOTTERY_SHOP:"160703",WELFARE_TIREDVALUE:"240103",MONTH_CARD:"240104",
PASS_REWARD:"240105",ANGEL_FIGHT_TOKEN:"240112",DAILY_RECHARGE:"240110",WELFARE_DAILY_RED_PACKET:"240109",WELFARE_DAILY_TATAL_RECHARGE:"240111",ASURAM_INFO:"170100",
ASURAM_INFO_OVERVIEW:"170101",ASURAM_INFO_MEMBERS:"170102",ASURAM_INFO_ALLIANCELIST:"170103",ASURAM_BUILD:"170200",ASURAM_TASK:"170300",ASURAM_ACTIVITY:"170400",
ASURAM_ACTIVITY_BOSS:"170401",ASURAM_ACTIVITY_MATCH:"170402",ASURAM_ACTIVITY_BELIEL:"170403",ASSIST:"170500",ASURAM_ASSIST:"170501",ASURAM_ASSIST_GOBLIN:"170502",
RANK_RANK:"180100",RANK_RANK_LEVEL:"180101",RANK_RANK_EQUIP:"180102",RANK_RANK_BATTLESCORE:"180103",RANK_RANK_CULTIVATION:"180104",RANK_RANK_WEALTH:"180105",
RANK_RANK_FRIENDSHIP:"180106",RANK_RANK_ASURAM:"180107",ARMYEQUIP_IMMORTAL:"190100",ARMYEQUIP_RUNE:"190200",ARMYEQUIP_HORSE:"190300",ARMYEQUIP_IMMORTAL_HP:"190101",
ARMYEQUIP_IMMORTAL_DEFENSE:"190102",ARMYEQUIP_IMMORTAL_ATTACK:"190103",ARMYEQUIP_IMMORTAL_CRITICAL:"190104",STRENTHEN_STRENTHEN:"200100",STRENTHER_ACHIEVE:"200200",
SETTING_SETTING:"210100",SETTING_HANG:"210101",SETTING_SYSTEM:"210102",SETTING_PRIVATE:"210103",SETTING_CHAT:"210104",SETTING_SAFELOCK:"210105",EXTEND_IMMORTAL:"190400",
PYX_IMMORTAL1:"190401",PYX_IMMORTAL2:"190402",PYX_IMMORTAL3:"190403",PYX_IMMORTAL4:"190404",ARMYEQUIP_SHIELD:"190500",ARMYEQUIP_RING:"190600",DOUBLEFESTVAIL_EVENT:"220100",
DOUBLEFESTVAIL_AWARD:"220101",DOUBLEFESTVAIL_RECHARGE:"220102",DOUBLEFESTVAIL_SHOP:"220103",DOUBLEFESTVAIL_BOSS:"220104",DOUBLEFESTVAIL_SNOWBALL:"220105",
DOUBLEFESTVAIL_DIAMONDGIFT:"220106",RY_FORGE_ENHANCE:"220100",RY_FORGE_EQUIPADD:"220200",RY_FORGE_LUCKYADD:"220300",RY_FORGE_SUIT:"220400",RY_EQUIPADVANCE:"220401",
RY_FORGE_WINGREFINE:"220500",RY_STALL_MARKET:"220400",RY_STALL_MYBAG:"220500",RY_MEDAL_HONERMEDAL:"250101",RY_TRADINGMARKET_BUY:"260001",RY_TRADINGMARKET_SELL:"260002",GEM:"100500"
}},95414:(e,t,i)=>{"use strict"
i.d(t,{I:()=>c})
var n=i(17409),s=i(86133),a=i(56937),r=i(31222),l=i(5494),o=i(52726),_=i(995),u=i(98789),h=i(37325)
class c{static get inst(){return null==c._inst&&(c._inst=new c),c._inst}constructor(){this.commonKillTipView=null,this._degf_DestroyCommonKillTipPanel=null,
this._degf_ShowCommonKillTipHandler=null}OpenCommonKillTipView(e){h.r.Inst_get().killShowText=`${(0,s.T)("你击败了 [ff0000]")}${e}[-]`
const t=new a.v
t.positionType=u.$.eCustom,t.layerType=o.F.DefaultUI,t.aniDir=_.K.Down,(0,n.Yp)(l.I.eCommonKillTipPanel,t)}CloseCommonKillTipView(){r.N.inst.CloseById(l.I.eCommonKillTipPanel)}}
c._inst=null},22914:(e,t,i)=>{"use strict"
i.d(t,{s:()=>r})
var n=i(98885),s=i(38962)
class a{constructor(){this.realData=null,this.key=-1,this.child=null,this.child=new s.X}GetLeafData(){return this.realData}GetChildNode(e){let t=null
return t=this.child[e],t}AddChildNode(e){const t=new a
t.key=e,this.child.LuaDic_AddOrSetItem(e,t)}CheckIsLeaf(){return null!=this.realData}}class r{constructor(){this.root=null,this.root=new a}AddNewData(e,t,i){const s=n.M.Split(e,t)
this.CreateNode(s,0,i,this.root)}AddNewDataWithArrayKey(e,t){this.CreateNode2(e,0,t,this.root)}AddNewDataWithAnyKey(e,...t){let i=[...t]
this.CreateNode3(i,1,e,this.root),i=null}AddNewDataWithLeafPos(e,t,i,s){const a=n.M.Split(e,t)
if(s<a.Count()){const e=a[s]
let t=s
for(;t+1<a.Count();)a[t]=a[t+1],t+=1
a[a.Count()-1]=e}this.CreateNode(a,0,i,this.root)}CreateNode(e,t,i,s){if(t<e.count){const a=e[t],r=n.M.String2Int(a)
let l=null
l=s.GetChildNode(r),null!=l?(t==e.count-1&&(l.realData=i),t+=1,this.CreateNode(e,t,i,l)):(s.AddChildNode(r),this.CreateNode(e,t,i,s))}}CreateNode2(e,t,i,n){if(t<e.count){
const s=e[t]
let a=null
a=n.GetChildNode(s),null!=a?(t==e.count-1&&(a.realData=i),t+=1,this.CreateNode2(e,t,i,a)):(n.AddChildNode(s),this.CreateNode2(e,t,i,n))}}CreateNode3(e,t,i,n){if(t<=e.length){
const s=e[t]
let a=null
a=n.GetChildNode(s),null!=a?(t==e.length&&(a.realData=i),t+=1,this.CreateNode3(e,t,i,a)):(n.AddChildNode(s),this.CreateNode3(e,t,i,n))}}GetData(e){
return this.GetLeafData(e,0,this.root)}GetDataWithAnyKey(...e){let t=[...e]
const i=this.GetLeafData2(t,1,this.root)
return t=null,i}GetNodeData(e){return this.GetBranchData(e,0,this.root)}GetLeafData(e,t,i){if(t<e.count){const n=e[t]
let s=null
return s=i.GetChildNode(n),null!=s?s.CheckIsLeaf()?s.GetLeafData():(t+=1,this.GetLeafData(e,t,s)):i.CheckIsLeaf()?i.GetLeafData():null}return null}GetLeafData2(e,t,i){
if(t<=e.length){const n=e[t]
let s=null
return s=i.GetChildNode(n),null!=s?s.CheckIsLeaf()?s.GetLeafData():(t+=1,this.GetLeafData2(e,t,s)):i.CheckIsLeaf()?i.GetLeafData():null}return null}GetBranchData(e,t,i){
if(t<e.count){const n=e[t]
let s=null
return s=i.GetChildNode(n),null!=s?t==e.count-1?s:(t+=1,this.GetBranchData(e,t,s)):null}return null}}},92679:(e,t,i)=>{"use strict"
i.d(t,{g:()=>n})
var n={PRIMARY_ROLE_CHANGED:"PRIMARY_ROLE_CHANGED",PRIMARY_ROLE_CHANGED_BEFORE:"PRIMARY_ROLE_CHANGED_BEFORE",CHARACTER_DEAD:"CHARACTER_DEAD",
PRIMARY_ROLE_LIST_CHANGED:"PRIMARY_ROLE_LIST_CHANGED",PRIMARY_ROLE_LIST_BY_SORT_CHANGED:"PRIMARY_ROLE_LIST_BY_SORT_CHANGED",OTHER_ROLE_LEADER_CHANGED:"OTHER_ROLE_LEADER_CHANGED",
BAG_INITED:"BAG_INITED",BAG_UPDATE:"BAG_UPDATE",ELEMENT_BAG_UPDATE:"ELEMENT_BAG_UPDATE",BAG_HIDE_NEW:"BAG_HIDE_NEW",BAG_SIZE_UPDATE:"BAG_SIZE_UPDATE",
MAX_BAG_SIZE_UPDATE:"MAX_BAG_SIZE_UPDATE",BAG_ITEM_CLICK:"BAG_ITEM_CLICK",BAG_CLICK_WEAR_EQUIP:"BAG_CLICK_WEAR_EQUIP",BAG_EMPTY_SIZE_UPDATE:"BAG_EMPTY_SIZE_UPDATE",
BAG_SELL_GOLD_CHANGE:"BAG_SELL_GOLD_CHANGE",EQUIP_POS_LOCK_TIP:"EQUIP_POS_LOCK_TIP",FORGE_SUIT_COL_CHANGE:"FORGE_SUIT_COL_CHANGE",SHORTCUT_GOODS_UPDATE:"SHORTCUT_GOODS_UPDATE",
SHORTCUT_GOODS_UPDATE_CD:"SHORTCUT_GOODS_UPDATE_CD",SHORTCUT_GOODS_BAG_UPDATE:"SHORTCUT_GOODS_BAG_UPDATE",BAG_MERGE_FALSE:"BAG_MERGE_FALSE",BAG_ROLE_CHANGE:"BAG_ROLE_CHANGE",
EQUIP_UNLOCK_BAG_ITEM_EFFECT:"EQUIP_UNLOCK_BAG_ITEM_EFFECT",WAREHOUSE_INITED:"WAREHOUSE_INITED",WAREHOUSE_UPDATE:"WAREHOUSE_UPDATE",WAREHOUSE_SIZE_UPDATE:"WAREHOUSE_SIZE_UPDATE",
MAX_WAREHOUSE_SIZE_UPDATE:"MAX_WAREHOUSE_SIZE_UPDATE",BAG_SELL_STATE_CHANGE:"BAG_SELL_STATE_CHANGE",TOGGLE_GROUP_SELECT:"TOGGLE_GROUP_SELECT",EQUIP_ITEM_EVENT:"EQUIP_ITEM_EVENT",
ROLE_BUILD_COMPLETED:"ROLE_BUILD_COMPLETED",FUNCTION_OPEN:"FUNCTION_OPEN",FUNCTION_CLOSE:"FUNCTION_CLOSE",FUNCTION_UPDATE:"FUNCTION_UPDATE",FUNCTION_INIT:"FUNCTION_INIT",
FUNCTION_VISIBLE:"FUNCTION_VISIBLE",MAIN_ICON_TIP_CHANGE:"MAIN_ICON_TIP_CHANGE",MAIN_ICON_TIP_CLOSE:"MAIN_ICON_TIP_CLOSE",TREE_ITEM_CLICK:"TREE_ITEM_CLICK",
TREE_ITEM_CHENGE:"TREE_ITEM_CHENGE",TREE_SHOWNUM_CHENGE:"TREE_SHOWNUM_CHENGE",HORSE_ACTIVE_CHENGE:"HORSE_ACTIVE_CHENGE",SKILL_UPDATE:"SKILL_UPDATE",
CHECK_PLAYER_DATA:"CHECK_PLAYER_DATA",ReturnBuyListUpdate:"ReturnBuyListUpdate",BuyListUpdate:"BuyListUpdate",CompoundBaseRateUpdate:"CompoundBaseRateUpdate",
CompoundAddRateUpdate:"CompoundAddRateUpdate",AUTOENHANCE_OR_ADD:"AUTOENHANCE_OR_ADD",ALLIANCE_NOTICE_UPDATE:"ALLIANCE_NOTICE_UPDATE",
ALLIANCE_NOTICE_BACKUP_CLICK:"ALLIANCE_NOTICE_BACKUP_CLICK",ALLIANCE_APPLYLIST_UPDATE:"ALLIANCE_APPLYLIST_UPDATE",ALLIANCE_MEMBER_CHECK:"ALLIANCE_MEMBER_CHECK",
ALLIANCE_APPLIED_UPDATE:"ALLIANCE_APPLIED_UPDATE",ALLIANCE_SEARCH_UPDATE:"ALLIANCE_SEARCH_UPDATE",ALLIANCE_APPLYER_CHECK:"ALLIANCE_APPLYER_CHECK",PASSIVE_UPDATE:"PASSIVE_UPDATE",
PASSIVE_UPGRADE:"PASSIVE_UPGRADE",JINGPO_UPDATE:"JINGPO_UPDATE",ACTIVE_UPDATE:"ACTIVE_UPDATE",ASURAM_DATAUPDATE:"ASURAM_DATAUPDATE",UPDATE_ATTENTION:"UPDATE_ATTENTION",
BOSS_DROP_UPDATE:"BOSS_DROP_UPDATE",BOSS_REMOVE:"BOSS_REMOVE",UPDATE_BOSS_PLAYERNUM:"UPDATE_BOSS_PLAYERNUM",ACHIEVE_UPDATE:"ACHIEVE_UPDATE",GM_SEND:"GM_SEND",
ACHIEVE_TREEUPDATE:"ACHIEVE_TREEUPDATE",RETRIEVE_UPDATE:"RETRIEVE_UPDATE",WORLDLEVEL_UPDATE:"WORLDLEVEL_UPDATE",ASURAM_EVENT_PLAYER_CHECK:"ASURAM_EVENT_PLAYER_CHECK",
PLAYER_LEVELUP:"PLAYER_LEVELUP",GET_EXP_MONSTER:"GET_EXP_MONSTER",ROLE_HP_UPDATE:"ROLE_HP_UPDATE",ROLE_SHIELD_UPDATE:"ROLE_SHIELD_UPDATE",PLAYER_DIE:"PLAYER_DIE",
CHANGE_LINE:"CHANGE_LINE",LONGLINNUM_UPDATE:"LONGLINNUM_UPDATE",SERVERLOG_UPDATE:"SERVERLOG_UPDATE",PERSONLOG_UPDATE:"PERSONLOG_UPDATE",
LOTTERYBAGDATA_UPDATE:"LOTTERYBAGDATA_UPDATE",LOTTERYBAGEMPTYNUM_UPDATE:"LOTTERYBAGEMPTYNUM_UPDATE",WORLD_BOSS_TIRED_UPDATE:"WORLD_BOSS_TIRED_UPDATE",
CROSS_BOSS_TIRED_UPDATE:"CROSS_BOSS_TIRED_UPDATE",CHANGE_TITLE:"CHANGE_TITLE",MARKET_RECOVERYUPDATE:"MARKET_RECOVERYUPDATE",TOGGLE_LIST_CHANGE:"TOGGLE_LIST_CHANGE",
TRYON_TOGGLE_LIST_CHANGE:"TRYON_TOGGLE_LIST_CHANGE",TITLE_EXPIRE:"TITLE_EXPIRE",MARKET_NEWCHANGEUPDATE:"MARKET_NEWCHANGEUPDATE",
MARKET_ONEITEMCHANGEUPDATE:"MARKET_ONEITEMCHANGEUPDATE",MARKET_TOTALITEMCHANGEUPDATE:"MARKET_TOTALITEMCHANGEUPDATE",MARKET_SCORESHOWUPDATE:"MARKET_SCORESHOWUPDATE",
MARKET_DIAMONDSHOWUPDATE:"MARKET_DIAMONDSHOWUPDATE",MARKET_SCORENUMUPDATE:"MARKET_SCORENUMUPDATE",MARKET_GOUNGINGUPDATE:"MARKET_GOUNGINGUPDATE",
ACCESS_ITEM_CLICK:"ACCESS_ITEM_CLICK",ACCESS_ICON_CLICK:"ACCESS_ICON_CLICK",DOUBLE_SLEVEN_ITEM_CLICK:"DOUBLE_SLEVEN_ITEM_CLICK",
DOUBLE_SLEVEN_ACTIVITY_UPDATE:"DOUBLE_SLEVEN_ACTIVITY_UPDATE",DOUBLE_FESTVAIL_ACTIVITY_UPDATE:"DOUBLE_FESTVAIL_ACTIVITY_UPDATE",TEAM_APPLY_ITEM_CLICK:"TEAM_APPLY_ITEM_CLICK",
TEAM_MENU_ITEM_CLICK:"TEAM_MENU_ITEM_CLICK",ASTROLABE_INFOUPDATE:"ASTROLABE_INFOUPDATE",NEWROLE_CREATE:"NEWROLE_CREATE",ENHANCE_MATERIAL_SELECT:"ENHANCE_MATERIAL_SELECT",
ADVANCE_MATERIAL_SELECT:"ADVANCE_MATERIAL_SELECT",SKILL_SHOW_SKILL_DISPLAYDONE:"SKILL_SHOW_SKILL_DISPLAYDONE",MARKET_ATTENTIONUPDATE:"MARKET_ATTENTIONUPDATE",
MARKET_SELLITEMCHANGEUPDATE:"MARKET_SELLITEMCHANGEUPDATE",MARKET_GROUNDINGITEMCHANGEUPDATE:"MARKET_GROUNDINGITEMCHANGEUPDATE",
MARKET_TRADEITEMCHANGEUPDATE:"MARKET_TRADEITEMCHANGEUPDATE",MARKET_MALL_ITEM_SELECT:"MARKET_MALL_ITEM_SELECT",MULIT_ROLE_INFO_CHANGED:"MULIT_ROLE_INFO_CHANGED",
ALLIANCE_BOSS_RANK_UPDATA:"ALLIANCE_BOSS_RANK_UPDATA",ALLIANCE_BOSS_UP_RANK_LEVEL:"ALLIANCE_BOSS_UP_RANK_LEVEL",ALLIANCE_BOSSJOINTIME:"ALLIANCE_BOSSJOINTIME",
ALLIANCE_BOSSDELAYDIE:"ALLIANCE_BOSSDELAYDIE",ALLIANCE_BOSS_INSPIRE_NOTIFY:"ALLIANCE_BOSS_INSPIRE_NOTIFY",ALLIANCE_BOSS_MONSTER_COUNT_UPDATE:"ALLIANCE_BOSS_MONSTER_COUNT_UPDATE",
ALLIANCE_ACTIVITY_UPDATE:"ALLIANCE_ACTIVITY_UPDATE",I18N_MESSAGE_NOTIFY:"I18N_MESSAGE_NOTIFY",SELECT_TARGET_CHANGE:"SELECT_TARGET_CHANGE",EQUIP_ROLE_SELECT:"EQUIP_ROLE_SELECT",
SIEGE_MATCHDATA_UPDATE:"SIEGE_MATCHDATA_UPDATE",SIEGE_KINGDATA_UPDATE:"SIEGE_KINGDATA_UPDATE",SIEGE_MSGSORTDATA_UPDATE:"SIEGE_MSGSORTDATA_UPDATE",
SIEGE_STATUESTATE_UPDATE:"SIEGE_STATUESTATE_UPDATE",SIEGE_COPYMSGDATA_UPDATE:"SIEGE_COPYMSGDATA_UPDATE",SIEGE_BATTLEDATA_UPDATE:"SIEGE_BATTLEDATA_UPDATE",
SIEGE_REWARDSTATE_UPDATE:"SIEGE_REWARDSTATE_UPDATE",SIEGE_STATUECLICK_HANDLER:"SIEGE_STATUECLICK_HANDLER",SIEGE_BACKHOMETIME_HANDLER:"SIEGE_BACKHOMETIME_HANDLER",
MULTIROLE_TABSELECT:"MULTIROLE_TABSELECT",CHECK_ASURAM_LEADER:"CHECK_ASURAM_LEADER",RUNE_BAG_UPDATE:"RUNE_BAG_UPDATE",EQUIP_SUIT_UPDATE:"EQUIP_SUIT_UPDATE",
VIEWPLAYER_UPDATE:"VIEWPLAYER_UPDATE",PRAY_UPDATE:"PRAY_UPDATE",WITHSHOP_ITEM_SELECT:"WITHSHOP_ITEM_SELECT",MARKET_ARENA_SHOP_ITEM_SELECT:"MARKET_ARENA_SHOP_ITEM_SELECT",
TEAM_TARGET_SELECT:"TEAM_TARGET_SELECT",UPDATE_MONSTER_COUNT:"UPDATE_MONSTER_COUNT",ADD_COLLECT:"ADD_COLLECT",REMOVE_COLLECT:"REMOVE_COLLECT",
HANG_SETDATA_UPDATE:"HANG_SETDATA_UPDATE",STRENGTHEN_PANEL_UPDATE:"STRENGTHEN_PANEL_UPDATE",STRENGTHEN_PANEL_CLOSE:"STRENGTHEN_PANEL_CLOSE",
SYSTEM_POWER_UPDATE:"SYSTEM_POWER_UPDATE",MARKET_CANGETREWARD_UPDATE:"MARKET_CANGETREWARD_UPDATE",MARKET_BIDBEOVERTAKEN_UPDATE:"MARKET_BIDBEOVERTAKEN_UPDATE",
BOSS_SELECT:"BOSS_SELECT",BOSS_SET_SEARCH_BTN:"BOSS_SET_SEARCH_BTN",COMPOUND_COREMATSELECT:"COMPOUND_COREMATSELECT",COMPOUND_ADDMATERIALCLICK:"COMPOUND_ADDMATERIALCLICK",
COMPOUND_ADDMATERIALSELECT:"COMPOUND_ADDMATERIALSELECT",COMPOUND_ADDEXMAT_IN:"COMPOUND_ADDEXMAT_IN",COMPOUND_REMOVEMATERIALCLICK:"COMPOUND_REMOVEMATERIALCLICK",
PLAYER_TRANSFER_JOB:"PLAYER_TRANSFER_JOB",PLAYER_TRANSFER_DIRECTION:"PLAYER_TRANSFER_DIRECTION",TRANSFER_CLICK_SKILL:"TRANSFER_CLICK_SKILL",
TRANSFER_ICON_SHOW_LIGHT:"TRANSFER_ICON_SHOW_LIGHT",EQUIP_FORGE:"EQUIP_FORGE",EQUIP_SUIT_FORGE:"EQUIP_SUIT_FORGE",ALLIANCE_SELECT:"ALLIANCE_SELECT",
LOSESECRETS_COPYITEM_CLICK:"LOSESECRETS_COPYITEM_CLICK",LOSESECRETS_COPYENTERCOUNT_UPDATE:"LOSESECRETS_COPYENTERCOUNT_UPDATE",
LOSESECRETS_COPYMSG_UPDATE:"LOSESECRETS_COPYMSG_UPDATE",UPDATE_RECOVER_ITEM_LIST:"UPDATE_RECOVER_ITEM_LIST",UPDATE_RECOVER_COPY_COUNT_ITEM:"UPDATE_RECOVER_COPY_COUNT_ITEM",
UPDATE_RECOVER_TASK_REWARD_ITEM:"UPDATE_RECOVER_TASK_REWARD_ITEM",ITEM_CLICK_SHOWTIP:"ITEM_CLICK_SHOWTIP",EQUIP_TIP_CLICK_WEAR:"EQUIP_TIP_CLICK_WEAR",
EQUIP_TIP_SELECT_LEFT_ROLE:"EQUIP_TIP_SELECT_LEFT_ROLE",EQUIP_TIP_SELECT_COLUMN:"EQUIP_TIP_SELECT_COLUMN",EQUIP_TIP_LEFT_MODEL:"EQUIP_TIP_LEFT_MODEL",
UPGRADE_FASHION:"UPGRADE_FASHION",WEAR_FASHION:"WEAR_FASHION",FIT_FASHION:"FIT_FASHION",VISIBLE_FASHION_MODEL:"VISIBLE_FASHION_MODEL",UPGRADE_WARDROBE:"UPGRADE_WARDROBE",
ADD_FASHION_ITEM:"ADD_FASHION_ITEM",ROLE_CHANGE_STATE:"ROLE_CHANGE_STATE",OpenRechargeView:"OpenRechargeView",OpenCurrencyBarView:"OpenCurrencyBarView",
OpenExclusionPanel:"OpenExclusionPanel",CloseCurrencyBarView:"CloseCurrencyBarView",CURRENCY_BAR_DEEPTH:"CURRENCY_BAR_DEEPTH",CURRENCY_BAR_TYPE:"CURRENCY_BAR_TYPE",
TIP_VIEW_UPDATE_DATA:"TIP_VIEW_UPDATE_DATA",MARKET_DRAGON_SHOP_ITEM_SELECT:"MARKET_DRAGON_SHOP_ITEM_SELECT",EXP_HANG_UPDATE:"EXP_HANG_UPDATE",VIP_UPDATE:"VIP_UPDATE",
AGAINST_REWARDSUCCESS:"AGAINST_REWARDSUCCESS",WLKBOSSKILL_UPDATA:"WLKBOSSKILL_UPDATA",WLKOTHERACTIVITY_UPDATA:"WLKOTHERACTIVITY_UPDATA",WLKRANK_UPDATA:"WLKRANK_UPDATA",
WLKOTHERRANK_UPDATA:"WLKOTHERRANK_UPDATA",TRADEBUY_UPDATA:"TRADEBUY_UPDATA",TRADESELL_UPDATA:"TRADESELL_UPDATA",ANGELWEAPON_SWITCH:"ANGELWEAPON_SWITCH",
SKILLEXERCISE_UPDATE:"SKILLEXERCISE_UPDATE",SKILLEXERCISE_CHANGESELECT:"SKILLEXERCISE_CHANGESELECT",SKILLEXERCISE_DATACOMPLETE:"SKILLEXERCISE_DATACOMPLETE",
SKILLEXERCISE_EXERCISESUCCESS:"SKILLEXERCISE_EXERCISESUCCESS",EQUIPCHANGE_UPDATE:"EQUIPCHANGE_UPDATE",WING_REFINE_CLICK:"WING_REFINE_CLICK",
WING_REFINE_PAGE_CLICK:"WING_REFINE_PAGE_CLICK",WING_BAGITEM_CLICK:"WING_BAGITEM_CLICK",WING_BAGITEM_SELECT_CLICK:"WING_BAGITEM_SELECT_CLICK",WING_INFO_CHANGE:"WING_INFO_CHANGE",
TASK_SELECT:"TASK_SELECT",TASK_MAINUI_RESIZE:"TASK_MAINUI_RESIZE",FIRST_CHARGE_UPDATE:"FIRST_CHARGE_UPDATE",FUNCITEM_EFFECT_UPDATE:"FUNCITEM_EFFECT_UPDATE",
ITEM_CLICK_BAGEXTEND:"ITEM_CLICK_BAGEXTEND",SHOW_MASK_LAYER:"SHOW_MASK_LAYER",TITLE_CLICK:"TITLE_CLICK",HANG_SKILL_UPDATE:"HANG_SKILL_UPDATE",HANG_BUFF_UPDATE:"HANG_BUFF_UPDATE",
HANG_STATE_UPDATE:"HANG_STATE_UPDATE",GOBLIN_PROTECTER_GEN_STATE_UPDATE:"GOBLIN_PROTECTER_GEN_STATE_UPDATE",GOBLIN_ASSISTER_GEN_STATE_UPDATE:"GOBLIN_ASSISTER_GEN_STATE_UPDATE",
PK_STATE_UPDATE:"PK_STATE_UPDATE",PK_STATE_EFFECT_UPDATE:"PK_STATE_EFFECT_UPDATE",REMAINS_UPDATE:"REMAINS_UPDATE",GOLD_MONSTER_PANEL_INFO:"GOLD_MONSTER_PANEL_INFO",
REPLEVY_OFFLINEEXP_SUCCESS:"REPLEVY_OFFLINEEXP_SUCCESS",SELECT_CURRENT_MAP_ITEM:"SELECT_CURRENT_MAP_ITEM",FLOOR_SELECT:"FLOOR_SELECT",
ALLIANCE_BASEINFO_UPDATE:"ALLIANCE_BASEINFO_UPDATE",ALLIANCE_VAULTATTRINUM_UPDATE:"ALLIANCE_VAULTATTRINUM_UPDATE",ALLIANCE_VAULTLOG_UPDATE:"ALLIANCE_VAULTLOG_UPDATE",
ALLIANCE_TECITEMDATA_UPDATE:"ALLIANCE_TECITEMDATA_UPDATE",ALLIANCE_WAREHOUSELOG_UPDATE:"ALLIANCE_WAREHOUSELOG_UPDATE",ALLIANCE_WAREHOUSE_UPDATE:"ALLIANCE_WAREHOUSE_UPDATE",
ALLIANCE_CONTRIBUTE_UPDATE:"ALLIANCE_CONTRIBUTE_UPDATE",ALLIANCE_WAREHOUCLEARDATA_UPDATE:"ALLIANCE_WAREHOUCLEARDATA_UPDATE",
ALLIANCE_WAREHOUSEDONATENUM_UPDATE:"ALLIANCE_WAREHOUSEDONATENUM_UPDATE",BOSS_EXTRA_DROP:"BOSS_EXTRA_DROP",REMAINS_OPEN:"REMAINS_OPEN",TRANSERJOB_SKILLCLICK:"TRANSERJOB_SKILLCLICK",
SKILLTIP_CLOSE:"SKILLTIP_CLOSE",ALLIANCE_MEMBER_SELECT:"ALLIANCE_MEMBER_SELECT",ALLIANCE_SUCCESS_INVITE:"ALLIANCE_SUCCESS_INVITE",BAG_EQUIP_UPDATE:"BAG_EQUIP_UPDATE",
BAG_NOEQUIP_UPDATE:"BAG_NOEQUIP_UPDATE",MARKET_AUCTION_ATTENTIONEQUIP_UPDATE:"MARKET_AUCTION_ATTENTIONEQUIP_UPDATE",
MARKET_GROUNDING_OTHERGROUNDING_UPDATE:"MARKET_GROUNDING_OTHERGROUNDING_UPDATE",MARKET_GROUNDING_ITEMCLICK:"MARKET_GROUNDING_ITEMCLICK",
EQUIP_TIP_SUIT_MODULE_UPDATE:"EQUIP_TIP_SUIT_MODULE_UPDATE",FORGE_SUIT_COMPOUND_ATTR_UPDATE:"FORGE_SUIT_COMPOUND_ATTR_UPDATE",TARGET_PLAYER_SUIT_SELECT:"TARGET_PLAYER_SUIT_SELECT",
BASE_TIP_CLOSE:"BASE_TIP_CLOSE",ARENA_POINT:"ARENA_POINT",ARENA_DAN_REWARD:"ARENA_DAN_REWARD",CULTIVATION_UPDATE:"CULTIVATION_UPDATE",ACHIEVE_OPEN:"ACHIEVE_OPEN",
BLOOD_TOWN_NUM:"BLOOD_TOWN_NUM",CLICK_ARENABUFF:"CLICK_ARENABUFF",WLKCLOSEACTIVITY_UPDATA:"WLKCLOSEACTIVITY_UPDATA",WLKCLICKACTIVITY_HANDLER:"WLKCLICKACTIVITY_HANDLER",
CLICK_CLOSEIP:"CLICK_CLOSEIP",PHOTOGRAPH_STATE_UPDATE:"PHOTOGRAPH_STATE_UPDATE",PHOTOGRAPH_SHIELD_UPDATE:"PHOTOGRAPH_SHIELD_UPDATE",PHOTOGRAPH_HEAD_UPDATE:"PHOTOGRAPH_HEAD_UPDATE",
PHOTOGRAPH_ROLEMODEL_UPDATE:"PHOTOGRAPH_ROLEMODEL_UPDATE",PHOTOGRAPH_STALLROLE_UPDATE:"PHOTOGRAPH_STALLROLEMODEL_UPDATE",
PHOTOGRAPH_TASKFINISH_UPDATE:"PHOTOGRAPH_TASKFINISH_UPDATE",PHOTOGRAPH_NPCHEADCAMERAICON_UPDATE:"PHOTOGRAPH_NPCHEADCAMERAICON_UPDATE",
PHOTOGRAPH_MONSTERHEADCAMERAICON_UPDATE:"PHOTOGRAPH_MONSTERHEADCAMERAICON_UPDATE",PHOTOGRAPH_ROLEHEADCAMERAICON_UPDATE:"PHOTOGRAPH_ROLEHEADCAMERAICON_UPDATE",
PHOTOGRAPH_HEADCAMERAICON_CLOSE:"PHOTOGRAPH_HEADCAMERAICON_CLOSE",PHOTOGRAPH_HEADCAMERAICON_UPDATE:"PHOTOGRAPH_HEADCAMERAICON_UPDATE",
PHOTOGRAPH_CUT_ICONUPDATE:"PHOTOGRAPH_CUT_ICONUPDATE",ALLIANCEBUILD_UPLEVEL_END:"ALLIANCEBUILD_UPLEVEL_END",ALLIANCEBUILD_INFODATA_UPDATE:"ALLIANCEBUILD_INFODATA_UPDATE",
MARKET_TRADE_TAXTIP_OPEN:"MARKET_TRADE_TAXTIP_OPEN",MASTERROAD_OPEN:"MASTERROAD_OPEN",GUIDE_FINISHBUTTON_CLICK:"GUIDE_FINISHBUTTON_CLICK",GUIDE_EVENT:"GUIDE_EVENT",
GUIDE_FINISH_GROUP:"GUIDE_FINISH_GROUP",MAIL_CNT_UPDATE:"MAIL_CNT_UPDATE",QuerySkillFormulaValueUpdate:"QuerySkillFormulaValueUpdate",SOUL_VIEW_UPDATE:"SOUL_VIEW_UPDATE",
MAP_CHANGE_UPDATE:"MAP_CHANGE_UPDATE",MAP_LOAD_COMPELETE:"MAP_LOAD_COMPELETE",MAP_LOGIN_LOAD_COMPELETE:"MAP_LOGIN_LOAD_COMPELETE",ATTR_PRE_CHANGE_UPDATE:"ATTR_PRE_CHANGE_UPDATE",
ACTIVITE_CHANGE_UPDATE:"ACTIVITE_CHANGE_UPDATE",MIRACLE_CONTINENT_GAIN_UPDATE:"MIRACLE_CONTINENT_GAIN_UPDATE",GUARD_BATTLELISTINFO_UPDATE:"GUARD_BATTLELISTINFO_UPDATE",
GUARD_WAREHOUSEDATA_UPDATE:"GUARD_WAREHOUSEDATA_UPDATE",GUARD_LEVEL_UPDATE:"GUARD_LEVEL_UPDATE",ENERGY_UPDATE:"ENERGY_UPDATE",GUARD_BATTLESELECT_UPDATE:"GUARD_BATTLESELECT_UPDATE",
GUARD_BOOKITEMCLICKNOTIPS_HANDLER:"GUARD_ITEMCLICKNOTIPS_HANDLER",GUARD_PRAYLEVEL_UPDATE:"GUARD_PRAYLEVEL_UPDATE",GUARD_SKILLSELECT_STUDY:"GUARD_SKILLSELECT_STUDY",
GUARD_GETNEW:"GUARD_GETNEW",MAP_TASK_UPDATE:"MAP_TASK_UPDATE",OPEN_WORLD_MAP:"OPEN_WORLD_MAP",GUARD_COLLECTADD_UPDATE:"GUARD_COLLECTADD_UPDATE",GET_IN_SAFE_AREA:"GET_IN_SAFE_AREA",
GET_OUT_SAFE_AREA:"GET_OUT_SAFE_AREA",GET_IN_DOUBLE_EXP_AREA:"GET_IN_DOUBLE_EXP_AREA",GET_IN_QUATRA_EXP_AREA:"GET_IN_QUATRA_EXP_AREA",GET_IN_OCTA_EXP_AREA:"GET_IN_OCTA_EXP_AREA",
GET_IN_ASURAMWAR_GUIDEAREA:"GET_IN_ASURAMWAR_GUIDEAREA",TOUCH_RELEASED:"TOUCH_RELEASED",SKILL_EXCHANGE_SELECT_UPDATE:"SKILL_EXCHANGE_SELECT_UPDATE",
ANGLESKILL_EXCHANGE_SELECT_UPDATE:"ANGLESKILL_EXCHANGE_SELECT_UPDATE",ADDPOINT_TIP_POINT_UPDATE:"ADDPOINT_TIP_POINT_UPDATE",ADDPOINT_TIP_POINT_TOTAL:"ADDPOINT_TIP_POINT_TOTAL",
ADDPOINT_TIP_SKILL_CLICK:"ADDPOINT_TIP_SKILL_CLICK",CHANGEQUEST_MODEL_UPDATE:"CHANGEQUEST_MODEL_UPDATE",JOB_SKILL_LEVELUP:"JOB_SKILL_LEVELUP",
SHOW_SKILL_NEW_OR_Level:"SHOW_SKILL_NEW_OR_Level",UPDATE_TASK_RIGHT_TRACE_LIST:"UPDATE_TASK_RIGHT_TRACE_LIST",UPDATE_BOUNTY_TASK_VIEW:"UPDATE_BOUNTY_TASK_VIEW",
FUNCTION_OPEN_ANI_FINISH:"FUNCTION_OPEN_ANI_FINISH",CURRENCY_BAR_INITED:"CURRENCY_BAR_INITED",SCENE_LOADING:"SCENE_LOADING",UPDATE_FRUIT_PANEL:"UPDATE_FRUIT_PANEL",
FRUIT_PANEL_SELECT:"FRUIT_PANEL_SELECT",GOTO_MIRACLE_DANGEROUS_SPAWN_GROUP:"GOTO_MIRACLE_DANGEROUS_SPAWN_GROUP",SELECT_MAP_TREE_ITEM:"SELECT_MAP_TREE_ITEM",
MY_SPAWN_UPDATE:"MY_SPAWN_UPDATE",MIRACLE_MAP_SPAWN_SUGGEST:"MIRACLE_SPAWN_SUGGEST",MIRACLE_CHANGE_AREA_SUGGEST:"MIRACLE_CHANGE_AREA_SUGGEST",MAP_UNLOCK:"MAP_UNLOCK",
FUNC_GRID_UPDATE:"FUNC_GRID_UPDATE",BAG_ITEMCLICK_CHANGE:"BAG_ITEMCLICK_CHANGE",CHAT_DOWN:"CHAT_DOWN",OPERATION_DOWN:"OPERATION_DOWN",CURRENT_SPAWN_UPDATE:"CURRENT_SPAWN_UPDATE",
COPYEXPPANEL_BUYSUCCESS_SKILL:"COPYEXPPANEL_BUYSUCCESS_SKILL",COPYEXPPANEL_USESUCCESS_ITEM:"COPYEXPPANEL_USESUCCESS_ITEM",
MIRACLE_ALL_CURRENT_SPAWN_UPDATE:"MIRACLE_ALL_CURRENT_SPAWN_UPDATE",COPY_PRETIME_END:"COPY_PRETIME_END",ENHANCE_MASTER_UPGRADE:"ENHANCE_MASTER_UPGRADE",
ADDITION_MASTER_UPGRADE:"ADDITION_MASTER_UPGRADE",COPY_ITEM_CLICK:"COPY_ITEM_CLICK",COPY_ITEM_ID_SELECT:"COPY_ITEM_ID_SELECT",ApplicationFocus:"ApplicationFocus_Lua",
COPY_INFOPANEL_SHOWSTATE:"COPY_INFOPANEL_SHOWSTATE",ICON_ANIME_RESET:"ICON_ANIME_RESET",MIRACLELAND_TREEITEM_CLICK:"MIRACLELAND_TREEITEM_CLICK",
MIRACLELAND_MONSTEREXPEFFI_UPDATE:"MIRACLELAND_MONSTEREXPEFFI_UPDATE",MIRACLELAND_SPAWN_DIFFICULTY_UPDATE:"MIRACLELAND_SPAWN_DIFFICULTY_UPDATE",
MIRACLELAND_OPENTIP:"MIRACLELAND_OPENTIP",MASTER_ACTIVITY_DATA_UPDATE:"MASTER_ACTIVITY_DATA_UPDATE",LOGIN:"LOGIN",LOGIN_VIEW_OPEN:"LOGIN_VIEW_OPEN",
MiracleMapUnlockUpdate:"MiracleMapUnlockUpdate",OffLineRewardItemClick:"OffLineRewardItemClick",MasterActivityClickReward:"MasterActivityClickReward",
MiracleShowBtnUpdate:"MiracleShowBtnUpdate",eRoleVisibleChange:"eRoleVisibleChange",BossHpBarOpenOrClose:"BossHpBarOpenOrClose",BossHpBarUpdata:"BossHpBarUpdata",
CommonFuncItemClick:"CommonFuncItemClick",GuardTalkTriggerEvent:"GuardTalkTriggerEvent",BloodTownEffect:"BloodTownEffect",SelectMiracleMapGroup:"SelectMiracleMapGroup",
SelectMiracleMap:"SelectMiracleMap",ReciveVitalityActivityReward:"ReciveVitalityActivityReward",BagSelectEquipColumn:"BagSelectEquipColumn",
ForgeSelectEquipColumn:"ForgeSelectEquipColumn",UpdateEnhanceConditionState:"UpdateEnhanceConditionState",UpdateAdditionConditionState:"UpdateAdditionConditionState",
SelectMusTowerChapter:"SelectMusTowerChapter",SelectMusTowerCopy:"SelectMusTowerCopy",ClearCopyColdTime:"ClearCopyColdTime",AllianceUpdateEntrustHome:"AllianceUpdateEntrustHome",
AllianceUpdateSelectEntrust:"AllianceUpdateSelectEntrust",MusTowerEvaluateUpdate:"MusTowerEvaluateUpdate",BossAssistState:"BossAssistState",
MusTowerTargetUpdate:"MusTowerTargetUpdate",BUY_LIMIT_PAGE_SELECT:"BUY_LIMIT_PAGE_SELECT",BUY_LIMIT_BUY_COMPLETE:"BUY_LIMIT_BUY_COMPLETE",
EXCELLENCE_MASTER_STATUS_UPDATE:"EXCELLENCE_MASTER_STATUS_UPDATE",EXCELLENCE_MASTER_ACTIVATE:"EXCELLENCE_MASTER_ACTIVATE",
EXCELLENCE_MASTER_BRANCH_SELECT:"EXCELLENCE_MASTER_BRANCH_SELECT",EXCELLENCE_MASTER_RESET:"EXCELLENCE_MASTER_RESET",EQUIPCOULMN_SELECT_UPDATE:"EQUIPCOULMN_SELECT_UPDATE",
GUARD_EQUIPMENT_UPDATE:"GUARD_EQUIPMENT_UPDATE",GUARD_SKILL_UPDATE:"GUARD_SKILL_UPDATE",ELEMENT_WEAR_UPDATE:"ELEMENT_WEAR_UPDATE",SELECT_BOX_ITEM:"SELECT_BOX_ITEM",
SELECT_BOSS_EFFECT:"SELECT_BOSS_EFFECT",TransferJobViewBoxUpdat:"TransferJobViewBoxUpdat",TransferRequireItemStateUpdate:"TransferRequireItemStateUpdate",
TargetPlayerGuardSelected:"TargetPlayerGuardSelected",TargetPlayerEquipColumnUpdate:"TargetPlayerEquipColumnUpdate",CHANGE_MAP:"CHANGE_MAP",DROP_REMOVE:"DROP_REMOVE",
CHECK_PANDORABOX_CLOSE_GUIDE:"CHECK_PANDORABOX_CLOSE_GUIDE",STOP_PANDORABOX_QUICKUSE:"STOP_PANDORABOX_QUICKUSE",ENHANCE_MATERIAL_EQUIP_REFRESH:"ENHANCE_MATERIAL_EQUIP_REFRESH",
MASTER_MATERIAL_EQUIP_REFRESH:"MASTER_MATERIAL_EQUIP_REFRESH",ENHANCE_RATE_UPDATE:"ENHANCE_RATE_UPDATE",MASTER_RATE_UPDATE:"MASTER_RATE_UPDATE",
AWAKE_MATERIAL_EQUIP_REFRESH:"AWAKE_MATERIAL_EQUIP_REFRESH",MIRACLE_SPAWN_CLICK:"MIRACLE_SPAWN_CLICK",MIRACLE_SPAWN_CANCEL:"MIRACLE_SPAWN_CANCEL",
SCORECHARGE_SELECT_UPDATE:"SCORECHARGE_SELECT_UPDATE",MIRACLE_POPULATION_UPDATE:"MIRACLE_POPULATION_UPDATE",BULKSELL_SETTING_UPDATE:"BULKSELL_SETTING_UPDATE",
IS_HANG_UPDATE:"IS_HANG_UPDATE",MIRACLE_HANG_UPDATE:"MIRACLE_HANG_UPDATE",BULKSELL_EFFECT_CLOSE:"BULKSELL_EFFECT_CLOSE",MARKET_MALL_BTN_CLICK:"MARKET_MALL_BTN_CLICK",
MONSTER_INIT_FINISHED:"MONSTER_INIT_FINISHED",FuncItemLoaded:"FuncItemLoaded",CURRENCY_CHARGE_WAVEANIM:"CURRENCY_CHARGE_WAVEANIM",
CURRENCY_CHARGE_WAVEANIMBEFORE:"CURRENCY_CHARGE_WAVEANIMBEFORE",CURRENCY_CHARGE_WAVEANIMEND:"CURRENCY_CHARGE_WAVEANIMEND",CURRENCY_LAYER_UPDATE:"CURRENCY_LAYER_UPDATE",
EQUIP_MASTER_PROPERTYBLOCK_UPDATE:"EQUIP_MASTER_PROPERTYBLOCK_UPDATE",MoreItemClick:"MoreItemClick",TRANSFER_EQUIPMENT_UPDATE:"TRANSFER_EQUIPMENT_UPDATE",
CommonFuncAnimeFinished:"CommonFuncAnimeFinished",MiracleSpawnNoMonster:"MiracleSpawnNoMonster",MiracleSpawnDefenseTipUpdate:"MiracleSpawnDefenseTipUpdate",
EnhanceEquipItemClick:"EnhanceEquipItemClick",BaptizeAttrItemClick:"BaptizeAttrItemClick",BaptizeAttrSuccess:"BaptizeAttrSuccess",BaptizeTalentUpdate:"BaptizeTalentUpdate",
CloseMiracleVitalityTip:"CloseMiracleVitalityTip",AddScoreAniEnd:"AddScoreAniEnd",ScoreLightStart:"ScoreLightStart",InviteInTeam:"InviteInTeam",
AuctionMenuItemClickEvent:"AuctionMenuItemClickEvent",FuncBtnAnimeEnd:"FuncBtnAnimeEnd",VitalityUpdated:"VitalityUpdated",TipsLoadCompelete:"TipsLoadCompelete",
ABossLayerSelected:"ABossLayerSelected",SELECT_ABLAYER_EFFECT:"SELECT_ABLAYER_EFFECT",Gold_DiamondAdd:"Gold_DiamondAdd",Rebate_Activity_Update:"Rebate_Activity_Update",
EXCELLENCE_MASTER_SCORE_RETURN:"EXCELLENCE_MASTER_SCORE_RETURN",SCORE_RECOVER_REFRESH:"SCORE_RECOVER_REFRESH",SCORE_RECOVER_REMOVE:"SCORE_RECOVER_REMOVE",
UITweenStateChanged:"UITweenStateChanged",learnNewSkillDown:"learnNewSkillDown",SIEGE_PARTY_UPDATE:"SIEGE_PARTY_UPDATE",MIRACLE_MAP_CLICK:"MIRACLE_MAP_CLICK",
CREATE_ALLIANCE_FLAG_SELECT:"CREATE_ALLIANCE_FLAG_SELECT",CREATE_ALLIANCE_ICON_SELECT:"CREATE_ALLIANCE_ICON_SELECT",
CREATE_ALLIANCE_FLAG_COLOR_SELECT:"CREATE_ALLIANCE_FLAG_COLOR_SELECT",CREATE_ALLIANCE_ICON_COLOR_SELECT:"CREATE_ALLIANCE_ICON_COLOR_SELECT",
FORGE_ENHANCE_EQUIPCOLUMNCHANGE:"FORGE_ENHANCE_EQUIPCOLUMNCHANGE",FORGE_JEWELSMELT_JEWELSELECT:"FORGE_JEWELSMELT_JEWELSELECT",
FORGE_JEWELSMELT_CONSUMESELECT:"FORGE_JEWELSMELT_CONSUMESELECT",FORGE_JEWELDATA_UPDATE:"FORGE_JEWELDATA_UPDATE",
FORGE_JEWELSMELT_OTHERJEWELSELECT:"FORGE_JEWELSMELT_OTHERJEWELSELECT",FORGE_JEWELSMELT_OTHERCONSUMESELECT:"FORGE_JEWELSMELT_OTHERCONSUMESELECT",
FORGE_JEWEL_ATTRTABLEREFRESH:"FORGE_JEWEL_ATTRTABLEREFRESH",FLASHSALE_TAB_SELECT:"FLASHSALE_TAB_SELECT",TEAM_CREATEORDISBAND:"TEAM_CREATEORDISBAND",
KARIMA_BOSS_SELECT:"KARIMA_BOSS_SELECT",KARIMA_MAP_SELECT:"KARIMA_MAP_SELECT",KARIMA_ENTERTIMES_CHANGE:"KARIMA_ENTERTIMES_CHANGE",
TIMELIMIT_ACTIVITY_UPDATE:"TIMELIMIT_ACTIVITY_UPDATE",FLASHSALE_BOUGHTTIMES_UPDATE:"FLASHSALE_BOUGHTTIMES_UPDATE",MIRACLE_ENTRANCE_EFFECT_UPDATE:"MIRACLE_ENTRANCE_EFFECT_UPDATE",
FUNCTION_INIT_COMPLETE:"FUNCTION_INIT_COMPLETE",KARIMA_RUNE_UPDATE:"KARIMA_RUNE_UPDATE",FORGE_JEWELINLAY_SELECT:"FORGE_JEWELINLAY_SELECT",
FORGE_JEWELINLAY_NUM:"FORGE_JEWELINLAY_NUM",FORGE_JEWELUP_JEWELSELECT:"FORGE_JEWELUP_JEWELSELECT",FORGE_JEWELUP_OTHERJEWELSELECT:"FORGE_JEWELUP_OTHERJEWELSELECT",
FORGE_JEWELUP_CONSUMESELECT:"FORGE_JEWELUP_CONSUMESELECT",FORGE_JEWELUP_CONSUMEADDEXP:"FORGE_JEWELUP_CONSUMEADDEXP",FORGE_JEWELBOOK_SELECT:"FORGE_JEWELBOOK_SELECT",
FORGE_JEWELBOOK_OTHERSELECT:"FORGE_JEWELBOOK_OTHERSELECT",FORGE_JEWELBOOK_TABLEREFRESH:"FORGE_JEWELBOOK_TABLEREFRESH",WORLD_SERVER_GRIDITEM_CLICK:"WORLD_SERVER_GRIDITEM_CLICK",
WORLD_SERVER_SERVERITEM_CLICK:"WORLD_SERVER_SERVERITEM_CLICK",WORLD_SERVER_SERVERITEM_CANCEL:"WORLD_SERVER_SERVERITEM_CANCEL",TITLE_SCORE_UPDATE:"TITLE_SCORE_UPDATE",
UPDATE_ANCHORS:"UPDATE_ANCHORS",WORLD_SERVER_ITEMINIT_COMPLETE:"WORLD_SERVER_ITEMINIT_COMPLETE",LIMIT_ACTIVITY_ENROLL_UPDATE:"LIMIT_ACTIVITY_ENROLL_UPDATE",
JEWELINLAY_CONDITION_UPDATE:"JEWELINLAY_CONDITION_UPDATE",ASURAM_AGENT_UPDATE:"ASURAM_AGENT_UPDATE",ASURAM_LEADER_UPDATE:"ASURAM_LEADER_UPDATE",
Immortal_Talent_Updated:"Immortal_Talent_Updated",RECOMMEND_ATTR_SELECT:"RECOMMEND_ATTR_CLICK",Immortal_Select_Talent:"Immortal_Select_Talent",
AWAKE_CONDITION_UPDATE:"AWAKE_CONDITION_UPDATE",SUIT_COMPOUND_CONDITION_UPDATE:"SUIT_COMPOUND_CONDITION_UPDATE",GUIDE_START:"GUIDE_START",GUIDE_FINISH:"GUIDE_FINISH",
JEWELSMELT_SMELTATTR_SELECT:"JEWELSMELT_SMELTATTR_SELECT",JEWELSMELT_UpgradeConsumeItem:"JEWELSMELT_UpgradeConsumeItem",
UPDATE_UNLOCK_BOSS_CHANLLENGE_INFO:"UPDATE_UNLOCK_BOSS_CHANLLENGE_INFO",UPDATE_UNLOCK_BOSS_NEWMAP_TIP:"UPDATE_UNLOCK_BOSS_NEWMAP_TIP",ATTACKED_LIST_UPDATE:"ATTACKED_LIST_UPDATE",
PKMODEL_UPDATE:"PKMODEL_UPDATE",SIEGE_KILLREWARDUPDATE:"SIEGE_KILLREWARDUPDATE",SPRINGSALE_UPDATE:"SPRINGSALE_UPDATE",SPRINGSALE_UPDATE_ShowItem:"SPRINGSALE_UPDATE_ShowItem",
PERFECTWING_COUNT_UPDATE:"PERFECTWING_COUNT_UPDATE",RECOVER_UPDATE:"RECOVER_UPDATE",RECOVER_ITEM_UPDATE:"RECOVER_ITEM_UPDATE",RECOVER_DOUBLE_UPDATE:"RECOVER_DOUBLE_UPDATE",
WORLDACTIVITY_ACTIVITY_UPDATE:"WORLDACTIVITY_ACTIVITY_UPDATE",WORLDACTIVITY_ACTIVITY_CHANGE:"WORLDACTIVITY_ACTIVITY_CHANGE",
WORLDACTIVITY_ELEMENT_UPDATE:"WORLDACTIVITY_ELEMENT_UPDATE",WORLDACTIVITY_GOLDBATTLE_DATA_UPDATE:"WORLDACTIVITY_GOLDBATTLE_DATA_UPDATE",
FORGE_SUIT_ACTIVE_ATTR_UPDATE:"FORGE_SUIT_ACTIVE_ATTR_UPDATE",FORGE_SUIT_ACTIVE_BLOCK_UPDATE:"FORGE_SUIT_ACTIVE_BLOCK_UPDATE",FORGE_SUIT_POS_SELECT:"FORGE_SUIT_POS_SELECT",
ASURAM_NAME_UPDATE:"ASURAM_NAME_UPDATE",SUIT_BAG_INITED:"SUIT_BAG_INITED",SUIT_BAG_UPDATE:"SUIT_BAG_UPDATE",SUIT_RECYCLE_QUALITYUPDATE:"SUIT_RECYCLE_QUALITYUPDATE",
SUIT_RECYCLE_SELECTUPDATE:"SUIT_RECYCLE_SELECTUPDATE",SUIT_RECYCLE_SELECTNUM:"SUIT_RECYCLE_SELECTNUM",SUIT_RECYCLE_SELECTALL:"SUIT_RECYCLE_SELECTALL",
SUIT_RECYCLE_SELECTFINISH:"SUIT_RECYCLE_SELECTFINISH",SUIT_OVERALL_ITEM_SELECT:"SUIT_OVERALL_ITEM_SELECT",EnterMap:"EnterMap",
WORLD_SERVER_SCROLLBAR_UPDATE:"WORLD_SERVER_SCROLLBAR_UPDATE",SUIT_RESOLVE_SUCCESS:"SUIT_RESOLVE_SUCCESS",LUCKY_NUM_UPDATE:"LUCKY_NUM_UPDATE",FACADE_POS_SELECT:"FACADE_POS_SELECT",
FACADE_SETTING_UPDATE:"FACADE_SETTING_UPDATE",FACADE_SETTING_CHANGE_ONE_GRID:"FACADE_SETTING_CHANGE_ONE_GRID",QUENTON_STATE_UPDATE:"QUENTON_STATE_UPDATE",
GoldWarSceneInfoUpdate:"GoldWarSceneInfoUpdate",GoldCallMsgUpdate:"GoldCallMsgUpdate",QuentonCopyInfoUpdate:"QuentonCopyInfoUpdate",
SKILL_SETSKILL_SELECT_UPDATE:"SKILL_SETSKILL_SELECT_UPDATE",COLLECT_SLIDER_UPDATE:"COLLECT_SLIDER_UPDATE",PK_UI_UPDATE:"PK_UI_UPDATE",
SKILL_SETSKILL_CHANGEPAGE:"SKILL_SETSKILL_CHANGEPAGE",EquipReliveSelectColumn:"EquipReliveSelectColumn",ReliveEquipItemClick:"ReliveEquipItemClick",
RELIVE_MATERIAL_EQUIP_REFRESH:"RELIVE_MATERIAL_EQUIP_REFRESH",EQUIP_RELIVE:"EQUIP_RELIVE",RELIVE_CONDITION_UPDATE:"RELIVE_CONDITION_UPDATE",CLOSE_ONE_PANEL:"CLOSE_ONE_PANEL",
OPEN_ONE_PANEL:"OPEN_ONE_PANEL",UNPLAY_UNLOCK_MAP_UPDATE:"UNPLAY_UNLOCK_MAP_UPDATE",SUMMON_MONSTER_UPDATE:"SUMMON_MONSTER_UPDATE",GOLDEN_TREASURE_INIT:"GOLDEN_TREASURE_INIT",
GOLDEN_TREASURE_UPDATE:"GOLDEN_TREASURE_UPDATE",GOLDEN_TREASURE_UPDATE_LAYER:"GOLDEN_TREASURE_UPDATE_LAYER",ASURAM_DISTRIBUTE_SELECT_UPDATE:"ASURAM_DISTRIBUTE_SELECT_UPDATE",
ASURAM_SALARY_GET:"ASURAM_SALARY_GET",ASURAM_TECHMONEY_UPDATE:"ASURAM_TECHMONEY_UPDATE",ASURAM_MATERIAL_UPDATE:"ASURAM_MATERIAL_UPDATE",
ASURAM_FLAG_EQUIPCOLUMN_UPDATE:"ASURAM_FLAG_EQUIPCOLUMN_UPDATE",GOBLINTREASURE_ASSOCIATION_DATAUPDATE:"GOBLINTREASURE_ASSOCIATION_DATAUPDATE",ASURAM_BOX_GET:"ASURAM_BOX_GET",
FlagAwakeNumUpdate:"FlagAwakeNumUpdate",FlagAwakeSkillUpdate:"FlagAwakeSkillUpdate",FlagAwakeSkillSelect:"FlagAwakeSkillSelect",
ASURAM_WELFARE_CHECK_REWARD:"ASURAM_WELFARE_CHECK_REWARD",GOBLIN_ROB_DATAUPDATE:"GOBLIN_ROB_DATAUPDATE",GOBLIN_DISTRIBUTE_UPDATE:"GOBLIN_DISTRIBUTE_UPDATE",
AllianceBuildingsOpenStateUpdate:"AllianceBuildingsOpenStateUpdate",FLAGSTRIPEATTRREFRESHCOMPLETE:"FLAGSTRIPEATTRREFRESHCOMPLETE",
FLAGSTRIPE_SELECT_UPDATE:"FLAGSTRIPE_SELECT_UPDATE",FLAGSTRIPE_STRIPEDATA_UPDATE:"FLAGSTRIPE_STRIPEDATA_UPDATE",FLAGSTRIPE_SUIT_SELECTITEM:"FLAGSTRIPE_SUIT_SELECTITEM",
FLAGSTRIPE_SUIT_UPDATE:"FLAGSTRIPE_SUIT_UPDATE",FLAGSTRIPE_UPGRADE_SELECTITEM:"FLAGSTRIPE_UPGRADE_SELECTITEM",FLAGSTRIPE_UPGRADE_SUCCESS:"FLAGSTRIPE_UPGRADE_SUCCESS",
FLAGSTRIPE_MASTERATTR_UPDATE:"FLAGSTRIPE_MASTERATTR_UPDATE",FLAGSTRIPE_MASTERLEVEL_UPDATE:"FLAGSTRIPE_MASTERLEVEL_UPDATE",MAIL_REWARD_UPDATE:"MAIL_REWARD_UPDATE",
EXPITEM_EXPIRED_SELECT:"EXPITEM_EXPIRED_SELECT",EXPITEM_EXPIRED_MALLBUY_SUCCESS:"EXPITEM_EXPIRED_MALLBUY_SUCCESS",JEWEL_BAG_UPDATE:"JEWEL_BAG_UPDATE",
GodBlessUpdatePrayType:"GodBlessUpdatePrayType",GodBlessUpgradeLevel:"GodBlessUpgradeLevel",RyWingSkillLearn:"RyWingSkillLearn",Roland_Defense_SMT1:"Roland_Defense_SMT1",
Roland_Defense_SMT2:"Roland_Defense_SMT2",Roland_Defense_State2CopyUpdate:"Roland_Defense_State2CopyUpdate",MOON_RECHARGE_UPDATE:"MoonRechargeUpdate",
SWITCH_ACTIVITY_ADD:"SWITCH_ACTIVITY_ADD",SWITCH_ACTIVITY_REMOVE:"SWITCH_ACTIVITY_REMOVE",SWITCH_ACTIVITY_UPDATE:"SWITCH_ACTIVITY_UPDATE",
SWITCH_ACTIVITY_STOP:"SWITCH_ACTIVITY_STOP",SWITCH_FIRST_CHARGE_UPDATE:"SWITCH_FIRST_CHARGE_UPDATE",FASHION_SUIT_SELECT:"FASHION_SUIT_SELECT",
FASHION_POS_SELECT:"FASHION_POS_SELECT",FASHION_SUIT_ACTIVATE_UPDATE:"FASHION_SUIT_ACTIVATE_UPDATE",FASHION_POS_CANCEL:"FASHION_POS_CANCEL",BUY_TIP_UPDATE:"BUY_TIP_UPDATE",
BUY_TIP_LOADED:"BUY_TIP_LOADED",DAILY_REPUTATION_LIMIT_UPDATE:"DAILY_REPUTATION_LIMIT_UPDATE",DAILY_REPUTATION_UPDATE:"DAILY_REPUTATION_UPDATE",
ALLIANCE_CLOSE_AUTO_DISTRIBUTE_PANEL:"ALLIANCE_CLOSE_AUTO_DISTRIBUTE_PANEL",ALLIANCE_BOX_DISTRIBUTE_TYPE_UPDATE:"ALLIANCE_BOX_DISTRIBUTE_TYPE_UPDATE",
SixTransferCopyEnterUpdate:"SixTransferCopyEnterUpdate",MASTER_COMPOUND_SETBTN_SELECT:"MASTER_COMPOUND_SETBTN_SELECT",MASTER_COMPOUND_SUCC:"MASTER_COMPOUND_SUCC",
ENHANCE_UPDATE_NORMALORELEMENT:"ENHANCE_UPDATE_NORMALORELEMENT",CHAT_FACADE_UPDATE:"CHAT_FACADE_UPDATE",FACADE_HEAD_SELECT:"FACADE_HEAD_SELECT",
ELEMENTAL_DUNGEON_TAB_SELECT:"ELEMENTAL_DUNGEON_TAB_SELECT",ELEMENTAL_DUNGEON_SERVERDATA_SELECT:"ELEMENTAL_DUNGEON_SERVERDATA_SELECT",
ELEMENTAL_DUNGEON_DETAILVIEW_CLOSE:"ELEMENTAL_DUNGEON_DETAILVIEW_CLOSE",ELEMENTAL_Attr_Loaded:"ELEMENTAL_Attr_Loaded",CROSSARENA_BattleRoundStart:"CROSSARENA_BattleRoundStart",
PEAKARENA_BattleRoundStart:"PEAKARENA_BattleRoundStart",PEAK_ARENA_CIRCLE_UPDATE:"PEAK_ARENA_CIRCLE_UPDATE",PEAK_ARENA_WIN_UPDATE:"PEAK_ARENA_WIN_UPDATE",
PEAK_ARENA_SELF_WIN_UPDATE:"PEAK_ARENA_SELF_WIN_UPDATE",SEASON_RING_STATE_UPDATE:"SEASON_RING_STATE_UPDATE",PEAK_ARENA_LIVEBTN_SELECT:"PEAK_ARENA_LIVEBTN_SELECT",
PEAK_ARENA_GUESS_TIP:"PEAK_ARENA_GUESS_TIP",PEAK_ARENA_CIRCLE_BATTLE_START:"PEAK_ARENA_CIRCLE_START",COPY_ENTER:"COPY_ENTER",COPY_ENTEREND:"COPY_ENTEREND",
COPY_ENTERTIMEUDPDATE:"COPY_ENTERTIMEUDPDATE",PEAK_ARENA_ENTER_TIP:"PEAK_ARENA_ENTER_TIP",CROSS_AUCTION_DATA_INIT:"CROSS_AUCTION_DATA_INIT",
CROSS_AUCTION_SINGLE_DATA_UPDATE:"CROSS_AUCTION_SINGLE_DATA_UPDATE",CROSS_AUCTION_ROUND_UPDATE:"CROSS_AUCTION_ROUND_UPDATE",UpdateSpecialSkills:"UpdateSpecialSkills",
SACRED_EQUIP_SUIT_ATTR_UPDATE:"SACRED_EQUIP_SUIT_ATTR_UPDATE",SACRED_EQUIP_SUIT_BLOCK_UPDATE:"SACRED_EQUIP_SUIT_BLOCK_UPDATE",AUCTION_SHARE_UPDATE:"AUCTION_SHARE_UPDATE",
SWITCH_FIRST_MALL_UPDATE:"SWITCH_FIRST_MALL_UPDATE",FLY_EFFECT_TWEEN_END:"FLY_EFFECT_TWEEN_END",TAB_BTN_SELECT:"TAB_BTN_SELECT",TAB_BTN_CLICK:"TAB_BTN_CLICK",
CHARACTER_TAB_CHANGED:"CHARACTER_TAB_CHANGED",EQUIP_COLLECT_TAB_SELECT:"EQUIP_COLLECT_TAB_SELECT",EXCSCROLL_UPDATE:"EXCSCROLL_UPDATE",EXCSCROLL_FIRST:"EXCSCROLL_FIRST",
WINGREFINE_SELECT_ITEM:"WINGREFINE_SELECT_ITEM",WINGREFINE_UPDATE:"WINGREFINE_UPDATE",WINGREFINE_SHOW_ITEMS:"WINGREFINE_SHOW_ITEMS",DROPEXP_BALL_TWEEN_END:"DROPEXP_BALL_TWEEN_END",
MANUAL_NEW_VERSION:"MANUAL_NEW_VERSION",MANUAL_SHOPUPDATA:"MANUAL_SHOPUPDATA",MANUAL_UPDATYALEVEL:"MANUAL_UPDATYALEVEL",MANUAL_LEVEL_UP:"MANUAL_LEVEL_UP",
MANUAL_UPDATYACHALLENGE:"MANUAL_UPDATYACHALLENGE",MANUAL_UPDATYACHALLENGEITEM:"MANUAL_UPDATYACHALLENGEITEM",MANUAL_CHALLENGE_GAINREW:"MANUAL_CHALLENGE_GAINREW",
DAILY_UPDATAITEM:"DAILY_UPDATAITEM",DAILY_GETREAWARD:"DAILY_GETREAWARD",DAILY_UPDATAVALUE:"DAILY_UPDATAVALUE",JOB_SKILL_VIEW_RAW_UPDATE:"JOB_SKILL_VIEW_RAW_UPDATE",
CAN_NEW_ROLE:"CAN_NEW_ROLE",SKILL_USE_LIST_TYPE_CHANGE:"SKILL_USE_LIST_TYPE_CHANGE",EQUIP_COLLECT_CACHE_TEX_UPDATE:"EQUIP_COLLECT_CACHE_TEX_UPDATE",
EQUIP_COLLECT_RED_UPDATE:"EQUIP_COLLECT_RED_UPDATE",SOUL_CLICK_UPDATE:"SOUL_CLICK_UPDATE",SOUL_TIP_CLICK:"SOUL_TIP_CLICK",RECHARGE_SIGN:"RECHARGE_SIGN",
GOLDSPAWN_CLICK_MONSTER_ICON:"GOLDSPAWN_CLICK_MONSTER_ICON",GOLDSPAWN_CLICK_MONSTER_ITEM:"GOLDSPAWN_CLICK_MONSTER_ITEM",GOLDSPAWN_NEW_POINT_OPEN:"GOLDSPAWN_NEW_POINT_OPEN",
GOLDSPAWN_RECOMMEND_SPAWN:"GOLDSPAWN_RECOMMEND_SPAWN",GOLDSPAWN_ROLE_NUM_RETURN:"GOLDSPAWN_ROLE_NUM_RETURN",GOLDSPAWN_RANGE_CHANGE:"GOLDSPAWN_RANGE_CHANGE",
COPYRECORD_UPDATE:"COPYRECORD_UPDATE",COPYSWEEP_SUCCESS:"COPYSWEEP_SUCCESS",SMALL_MAP_SHOW_MONSTER:"SMALL_MAP_SHOW_MONSTER",SMALL_MAP_CLICK_MONSTER:"SMALL_MAP_CLICK_MONSTER",
SMALL_MAP_TREE_CLICK_MONSTER:"SMALL_MAP_TREE_CLICK_MONSTER",SMALL_MAP_MOVE_TO_MONSTER:"SMALL_MAP_MOVE_TO_MONSTER",SMALL_MAP_CLOSE_MONSTER_TIP:"SMALL_MAP_CLOSE_MONSTER_TIP",
GOLDSPAWN_TIME_UPDATE:"GOLDSPAWN_TIME_UPDATE",CHOOSE_SETTING_UPDATE:"CHOOSE_SETTING_UPDATE",SCENE_CHANGE:"SCENE_CHANGE",MULTIPLEHANG_TIME_UPDATE:"MULTIPLEHANG_TIME_UPDATE",
MULTIPLEHANG_TOTAL_UPDATE:"MULTIPLEHANG_TOTAL_UPDATE",MULTIPLEHANG_RANGE_CHANGE:"MULTIPLEHANG_RANGE_CHANGE",MULTIPLEHANG_ON:"MULTIPLEHANG_ON",MULTIPLEHANG_OFF:"MULTIPLEHANG_OFF",
MULTIPLEHANG_EXP_RATE_CHANGE:"MULTIPLEHANG_EXP_RATE_CHANGE",MULTIPLEHANG_PK_LIST_CHANGE:"MULTIPLEHANG_PK_LIST_CHANGE",HANG_RECOMMOND_POINT_CHANGE:"HANG_RECOMMOND_POINT_CHANGE",
HANG_RECOMMOND_POINT_REFRESH:"HANG_RECOMMOND_POINT_REFRESH",ROLE_MAX_DEFENSE_CHANGE:"ROLE_MAX_DEFENSE_CHANGE",SHOW_MAP_PASS_BTN_EXP_TIPS:"SHOW_MAP_PASS_BTN_EXP_TIPS",
RY_PANDORA_SELECT_CHANGE:"RY_PANDORA_SELECT_CHANGE",RY_PANDORA_SELECT_NUM_CHANGE:"RY_PANDORA_SELECT_NUM_CHANGE",RY_PANDORA_SELECT_END:"RY_PANDORA_SELECT_END",
COPY_STAGE_UPDATE:"COPY_STAGE_UPDATE",COPY_STAGE_UPDATE_REAL:"COPY_STAGE_UPDATE_REAL",SKILL_ALERT:"SKILL_ALERT",ADD_BUFF:"ADD_BUFF",REMOVE_BUFF:"REMOVE_BUFF",
RY_STALL_MENU_ITEM_CLICK:"RY_STALL_MENU_ITEM_CLICK",RY_MARKET_GOOD_CHANGE:"RY_MARKET_GOOD_CHANGE",RY_STALL_OTHER_VIEW_CLOSE:"RY_STALL_OTHER_VIEW_CLOSE",
RY_STALL_BAG_DATA_INIT:"RY_STALL_BAG_DATA_INIT",RY_STALL_RENT_TIME_UPDATE:"RY_STALL_RENT_TIME_UPDATE",RY_STALL_AD_CD_UPDATE:"RY_STALL_AD_CD_UPDATE",
RY_STALL_CHAT_CD_TIME:"RY_STALL_CHAT_CD_TIME",RY_AD_ITEM_SELLLECT:"RY_AD_ITEM_SELLLECT",RY_STALL_BAG_DATA_UPDATE:"RY_STALL_BAG_DATA_UPDATE",
RY_STALL_RENAME_UPDATE:"RY_STALL_RENAME_UPDATE",RY_STALL_BAG_DATA_EMPTY:"RY_STALL_BAG_DATA_EMPTY",RY_STALL_OHTER_PLYAER_UPDATE:"RY_STALL_OHTER_PLYAER_UPDATE",
RY_STALL_OHTER_PLYAER_SELECT:"RY_STALL_OHTER_PLYAER_SELECT",RY_STALL_LOG_UPDATE:"RY_STALL_LOG_UPDATE",RY_STALL_TIME_UPDATE:"RY_STALL_TIME_UPDATE",
RY_STALL_OTHER_BAG_DATA_UPDATE:"RY_STALL_OTHER_BAG_DATA_UPDATE",COPY_ITEM_SELECT_BELIAL:"COPY_ITEM_SELECT_BELIAL",COPY_ITEM_SELECT_BLOODTOWN:"COPY_ITEM_SELECT_BLOODTOWN",
HORSE_UPGRADE:"HORSE_UPGRADE",HORSE_ACTIVE:"HORSE_ACTIVE",HORSE_RIDING_UPDATE:"HORSE_RIDING_UPDATE",REBIRTH_ICON_SHOW_LIGHT:"REBIRTH_ICON_SHOW_LIGHT",
REBIRTH_STAGE_CHANGE:"REBIRTH_STAGE_CHANGE",REBIRTH_POINT_CHANGE:"REBIRTH_POINT_CHANGE",REBIRTH_CLICK_GET_POINT:"REBIRTH_CLICK_GET_POINT",
REBIRTH_MONSTER_CNT_CHANGE:"REBIRTH_MONSTER_CNT_CHANGE",REBIRTH_ATTACK_MONSTER_CHANGE:"REBIRTH_ATTACK_MONSTER_CHANGE",RY_EXCALIBUR_BEGIN:"RY_EXCALIBUR_BEGIN",
RY_EXCALIBUR_END:"RY_EXCALIBUR_END",RYCOMPOUND_RESULT:"RYCOMPOUND_RESULT",RYCOMPOUND_REDPOINTCHECK:"RYCOMPOUND_REDPOINTCHECK",TALENT_CHANGE:"TALENT_CHANGE",
UPDATE_ALLIANCE_TASK_VIEW:"UPDATE_ALLIANCE_TASK_VIEW",UPDATE_ALLIANCE_TASK_ITEM:"UPDATE_ALLIANCE_TASK_ITEM",Get_ALLIANCE_TASK_Award:"Get_ALLIANCE_TASK_Award",
TIPROOTVIEW_REFRESHPOS:"TIPROOTVIEW_REFRESHPOS",OPEN_BAG:"OPENBAG",LEVELREWARDINFO_UPDATE:"LEVELREWARDINFO_UPDATE",RECHARGE_INFO_CHANGE:"RECHARGE_INFO_CHANGE",
CLICK_REDPOINTINFO_UPDTAE:"CLICK_REDPOINTINFO_UPDTAE",RYALLIANCE_RECEIVE_ALLIANCELIST:"RYALLIANCE_RECEIVE_ALLIANCELIST",RYALLIANCE_BUILDING_UPDATE:"RYALLIANCE_BUILDING_UPDATE",
CROSS_BOSS_UPDATE:"CROSS_BOSS_UPDATE",SPACE_ORIGIN_UPDATE:"SPACE_ORIGIN_UPDATE",RANK_DATA:"RANK_DATA",RANK_DAILY_REWARD:"RANK_DAILY_REWARD",
RANK_DAILY_REWARD_CONFIG:"RANK_DAILY_REWARD_CONFIG",RANK_REWARD:"RANK_REWARD",RANK_SELF_RANK_VALUE:"RANK_SELF_RANK_VALUE",HUODONG_QUEST_CHANGE:"HUODONG_QUEST_CHANGE",
HUODONG_GET_REWARD:"HUODONG_GET_REWARD",HUODONG_INFO_CHANGE:"HUODONG_INFO_CHANGE",HUODONG_TYPE_CHANGE:"HUODONG_TYPE_CHANGE",OPEN_LOTTERY_SUCCESS:"OPEN_LOTTERY_SUCCESS",
UPDATE_LOTTERY_CONFIG:"UPDATE_LOTTERY_CONFIG",UPDATE_LOTTERY_INFO:"UPDATE_LOTTERY_INFO",HUODONG_DROP:"HUODONG_DROP",HUODONG_RANKINFO_UPDATE:"HUODONG_RANKINFO_UPDATE",
HUODONG_RANKREWARD_GAIN:"HUODONG_RANKREWARD_GAIN",HUODONG_MALL_BUY_SUCCESS:"HUODONG_MALL_BUY_SUCCESS",HUODONG_MALL_CHANGE:"HUODONG_MALL_CHANGE",
HUODONG_MALL_BUY_PANEL_CLOSE:"HUODONG_MALL_BUY_PANEL_CLOSE",HUODONG_MALL_BUY_PANEL_SURE:"HUODONG_MALL_BUY_PANEL_SURE",HUODONG_MALL_BUY_CNT_CHANGE:"HUODONG_MALL_BUY_CNT_CHANGE",
HUODONG_MALL_BUY_CNT_LIST_CHANGE:"HUODONG_MALL_BUY_CNT_LIST_CHANGE",HUODONG_MALL_SUCCESS_PANEL_CLOSE:"HUODONG_MALL_SUCCESS_PANEL_CLOSE",SET_ADDPOINT_ATT:"SET_ADDPOINT_ATT",
TITLE_SHOW_UPDATE:"TITLE_SHOW_UPDATE",TITLE_SWITCH:"TITLE_SWITCH",TITLE_LIGHT:"TITLE_LIGHT",TITLE_PREVIEW:"TITLE_PREVIEW",TabCommonOpenAniEnd:"TabCommonOpenAniEnd",
RYALLIANCE_BOREFIRE_UPDATE:"RYALLIANCE_BOREFIRE_UPDATE",RYALLIANCE_CHUANGONG_UPDATE:"RYALLIANCE_CHUANGONG_UPDATE",RYALLIANCE_FIREOH:"RYALLIANCE_FIREOH",
RYALLIANCE_REFRESHEXP:"RYALLIANCE_REFRESHEXP",RYALLIANCE_REFRESHFIREMSG:"RYALLIANCE_REFRESHFIREMSG",RYALLIANCE_CHUANGONGINVITE:"RYALLIANCE_CHUANGONGINVITE",
RYALLIANCE_SHOWHIDE_SUBMITPANEL:"RYALLIANCE_SHOWHIDE_SUBMITPANEL",RYALLIANCE_GET_FIRSTSUBMITAWARD:"RYALLIANCE_GET_FIRSTSUBMITAWARD",
RYALLIANCE_CHUANGONGDOUBLE:"RYALLIANCE_CHUANGONGDOUBLE",CLICK_FUNC_ITEM:"CLICK_FUNC_ITEM",RYALLIANCE_TREASUREINFO:"RYALLIANCE_TREASUREINFO",
RYALLIANCE_REFRESHTREASUREITEM:"RYALLIANCE_REFRESHTREASUREITEM",RYALLIANCE_CHUANGONG_ASSIST:"RYALLIANCE_CHUANGONG_ASSIST",RYALLIANCE_RANK_SHOWPLAYER:"RYALLIANCE_RANK_SHOWPLAYER",
RYALLIANCE_RANK_SHOWPLAYERMODEL:"RYALLIANCE_RANK_SHOWPLAYERMODEL",RYALLIANCE_RANK_REFRESH:"RYALLIANCE_RANK_REFRESH",RYALLIANCE_ADDALLIANCE_CD:"RYALLIANCE_ADDALLIANCE_CD",
RYALLIANCE_INFOVIEW_PANELDEPTH:"RYALLIANCE_INFOVIEW_PANELDEPTH",MONTHCARD_REWARD:"MONTHCARD_REWARD",RIDINGBUY_ACTIVITYINFO:"RIDINGBUY_ACTIVITYINFO",MONTHCARD_INFO:"MONTHCARD_INFO",
CANNOTUSEBOSSITEM:"CANNOTUSEBOSSITEM",ALLIANCEBOSS_STRATEGY_CLICK:"ALLIANCEBOSS_STRATEGY_CLICK",AllianceDontionUpdate:"AllianceDontionUpdate",
AllianceDontionTipsUpdate:"AllianceDontionTipsUpdate",UPDATE_SYSTEM_SETTING:"UPDATE_SYSTEM_SETTING",UPDATE_CHAT_SETTING:"UPDATE_CHAT_SETTING",
UPDATE_PRIVATE_SETTING:"UPDATE_PRIVATE_SETTING",UPDATE_SKILL_SELECT:"UPDATE_SKILL_SELECT",BLOCK_ITEM_DRAG:"BLOCK_ITEM_DRAG",GAMEGM_INFO_CHANGE:"GAMEGM_INFO_CHANGE",
GAMEGM_CLICK_WEAR_EQUIP:"GAMEGM_CLICK_WEAR_EQUIP",SELECT_COMBOX_ITEM:"SELECT_COMBOX_ITEM",CLICK_COMBOX_ITEM:"CLICK_COMBOX_ITEM",
GAMEGM_SELECT_COMBOX_ITEM:"GAMEGM_SELECT_COMBOX_ITEM",GAMEGM_CLICK_COMBOX_ITEM:"GAMEGM_CLICK_COMBOX_ITEM",GAMEGM_STOP_CHANGE:"GAMEGM_STOP_CHANGE",
GAMEGM_PAUSE_CHANGE:"GAMEGM_PAUSE_CHANGE",GAMEGM_BTN_VALUE_CHANGE:"GAMEGM_BTN_VALUE_CHANGE",GAMEGM_EXECUTING_CHANGE:"GAMEGM_EXECUTING_CHANGE",
GAMEGM_ONLINE_INFO:"GAMEGM_ONLINE_INFO",GAMEGM_OFFLINE_INFO:"GAMEGM_OFFLINE_INFO",GAMEGM_BountyTaskUpdate:"GAMEGM_BountyTaskUpdate",
RYEQUIPADVANCE_REMOVEADDEQUIP:"RYEQUIPADVANCE_REMOVEADDEQUIP",RYEQUIPSTARADVANCE_REMOVEADDEQUIP:"RYEQUIPSTARADVANCE_REMOVEADDEQUIP",QUESTIONINFO_CHANGE:"QUESTIONINFO_CHANGE",
QUESTIONRANK_CHANGE:"QUESTIONRANK_CHANGE",QUESTIO_SUC:"QUESTIO_SUC",ACTIVITY_LOTTERY_OPEN:"ACTIVITY_LOTTERY_OPEN",ACTIVITY_LOTTERY_UPDATE:"ACTIVITY_LOTTERY_UPDATE",
UPDATE_CHARIOT_SKILL:"UPDATE_CHARIOT_SKILL",MOVIE_BEGIN:"MOVIE_BEGIN",MOVIE_END:"MOVIE_END",GEM_UPDATE:"GEM_UPDATE",GEM_CHANGE:"GEM_CHANGE",
Element_Enhance_PopLisItemClick:"Element_Enhance_PopLisItemClick",Element_Enhance_SortTypeChange:"Element_Enhance_SortTypeChange",
Element_Enhance_JoinChange:"Element_Enhance_JoinChange",Element_Enhance_Success:"Element_Enhance_Success",Element_Auto_Enhance_Success:"Element_Auto_Enhance_Success",
Element_Hole_Selcet:"Element_Hole_Selcet",EleCompound_TabItem_Selcet:"EleCompound_TabItem_Selcet",EleCompound_TabSubItem_Selcet:"EleCompound_TabSubItem_Selcet",
EleCompound_TabItem_Change:"EleCompound_TabItem_Change",Element_Compound_SelectChange:"Element_Compound_SelectChange",Element_Compound_End:"Element_Compound_End",
EleCarve_Wear_Update:"EleCarve_Wear_Update",EleCarve_Wear_Item_Id:"EleCarve_Wear_Item_Id",EleCarve_PopLisItemClick:"EleCarve_PopLisItemClick",
EleCarve_SortTypeChange:"EleCarve_SortTypeChange",EleCarve_SelectChange:"EleCarve_SelectChange",EleCarve_LevelChange:"EleCarve_LevelChange",
EleCarve_LeftListItemClick:"EleCarve_LeftListItemClick",EleCarve_MidItemClick:"EleCarve_MidItemClick",EleCarve_EchoItemClick:"EleCarve_EchoItemClick",
EleCarve_UnLock:"EleCarve_UnLock",EleCarve_UnLockEnd:"EleCarve_UnLockEnd",EleCarve_SuccessViewClose:"EleCarve_SuccessViewClose",OnBloodBarOpen:"OnBloodBarOpen",
OnBloodBarClose:"OnBloodBarClose",FuncOpenViewOpenChange:"FuncOpenViewOpenChange",RIDINGBUY_SKILLEFFECT:"RIDINGBUY_SKILLEFFECT",WEEK_NET_UPDATE:"WEEK_NET_UPDATE",
FORBIDEN_SKILL_USE:"FORBIDEN_SKILL_USE",TASKCONTRACT_CLICK_GET_POINT:"TASKCONTRACT_CLICK_GET_POINT",TASKCONTRACT_CHANGE_INFO:"TASKCONTRACT_CHANGE_INFO",
TASKCONTRACT_Updata:"TASKCONTRACT_Updata",PrenoticePanelUpdata:"PrenoticePanelUpdata",DYNAMIC_REGIST_CONTROLID:"DYNAMIC_REGIST_CONTROLID",COM_FUN_VIEW_ACTIVE:"COM_FUN_VIEW_ACTIVE",
UPDATE_INFO_TIP_VIEW:"UPDATE_INFO_TIP_VIEW",SUITFUSE_SUCCESS:"SUITFUSE_SUCCESS",ROLE_SELECT_CHANGE:"ROLE_SELECT_CHANGE",ROLE_SELECT_CHANGE_HIDE:"ROLE_SELECT_CHANGE_HIDE",
UPDATE_EFFICIENCY:"UPDATE_EFFICIENCY",UPDATE_REDPACKET_DAILY:"UPDATE_REDPACKET_DAILY",SKILL_RECHARGE_BUY_CLICK:"SKILL_RECHARGE_BUY_CLICK",
BOSS_RIGHTPANEL_CLICK:"BOSS_RIGHTPANEL_CLICK",UPDATE_GET_SUCCESS:"UPDATE_GET_SUCCESS",UPDATE_DAILYACCULUMN_INFO:"UPDATE_DAILYACCULUMN_INFO",
QUERY_FIRST_PASS_MAP_NAME:"QUERY_FIRST_PASS_MAP_NAME",GUILD_ACTIVITY_OPENSUBVIEW:"GUILD_ACTIVITY_OPENSUBVIEW",GUILD_ACTIVITY_OPENSUBVIEW2:"GUILD_ACTIVITY_OPENSUBVIEW2",
TASK_MIANUI_ACTIVE:"TASK_MIANUI_ACTIVE",COPY_UPDATE_END_TIME:"COPY_UPDATE_END_TIME",MONSTER_DEAD:"MONSTER_DEAD",ROBOT_DEAD:"ROBOT_DEAD",ROLE_DEAD:"ROLE_DEAD",
MAZE_SUB_ENERGY:"MAZE_SUB_ENERGY",MAZE_ADD_ENERGY:"MAZE_ADD_ENERGY",MAZE_UPDATE_EVENTDATA:"MAZE_UPDATE_EVENTDATA",MAZE_UPDATE_ROOM:"MAZE_UPDATE_ROOM",
MAZE_ROOM_UNLOCK:"MAZE_ROOM_UNLOCK",PLAY_END_TRANSPORT:"PLAY_END_TRANSPORT",ADD_DROP:"ADD_DROP",BOSS_DAMAGE_BOSSID_UPDATE:"BOSS_DAMAGE_BOSSID_UPDATE",
OPEN_SERVER_GRAB_END:"OPEN_SERVER_GRAB_END",MAZE_TIME_SPACE_ROOM_UPDATE:"MAZE_TIME_SPACE_ROOM_UPDATE",DAY_UPDATE:"DAY_UPDATE",STARSYK_UPDATE:"STARSYK_UPDATE",
THEME_SELECT_HUODONG:"THEME_SELECT_HUODONG",THEME_SELECT_TARGETTYPE:"THEME_SELECT_TARGETTYPE",THEMECARNIVAL_CLICK_GET_POINT:"THEMECARNIVAL_CLICK_GET_POINT",
POPITEM_CLICK:"POPITEM_CLICK",POPITEM_SELECT:"POPITEM_SELECT",COMM_REWARD_RESET_CLICK:"COMM_REWARD_FINAL_CLICK",ROLAND_NOTICE_TIME_UPDATE:"ROLAND_NOTICE_TIME_UPDATE",
ROLANDSAVE_INFO_INIT:"ROLANDSAVE_INFO_INIT",ROLANDSAVE_INFO_CHANGE:"ROLANDSAVE_INFO_CHANGE",ROLANDSAVE_NESTINFO_UPDATE:"ROLANDSAVE_NESTINFO_UPDATE",
ROLANDSAVE_POWER_INIT:"ROLANDSAVE_POWER_INIT",ROLANDSAVE_POWER_CHANGE:"ROLANDSAVE_POWER_CHANGE",ROLANDSAVE_BOSSWAKE:"ROLANDSAVE_BOSSWAKE",
ROLAND_SAVE_REPUTATION_UPDATE:"ROLAND_SAVE_REPUTATION_UPDATE",ROLANDSAVE_END:"ROLANDSAVE_END",FIRST_PANEL_OPEN:"FIRST_PANEL_OPEN",MAP_UPDATE_POSITION:"MAP_UPDATE_POSITION",
MARKET_OLD_GOODS_UPDATE:"MARKET_OLD_GOODS_UPDATE",CRIME_CLICK_POINT:"CRIME_CLICK_POINT",CRIME_SELECT_BUFF:"CRIME_SELECT_BUFF",CRIME_GET_VALUE_REWARD:"CRIME_GET_VALUE_REWARD",
CRIME_UNLOCK_EFFECT_END:"CRIME_UNLOCK_EFFECT_END",CRIME_GET_RANK_REWARD:"CRIME_GET_RANK_REWARD",CRIME_POINT_UNLOCK:"CRIME_POINT_UNLOCK",
OBELISK_CLICK_UI_ITEM:"OBELISK_CLICK_UI_ITEM",OBELISK_CHANGE_SHOW_UI_MAP:"OBELISK_CHANGE_SHOW_UI_MAP",OBELISK_BOARD_INFO_CHANGE:"OBELISK_BOARD_INFO_CHANGE",
OBELISK_SHOW_REWARD_INFO_CHANGE:"OBELISK_SHOW_REWARD_INFO_CHANGE",OBELISK_TIME_INFO_CHANGE:"OBELISK_TIME_INFO_CHANGE",OBELISK_ASURAM_INFO_CHANGE:"OBELISK_ASURAM_INFO_CHANGE",
ROLAND_VALLEY_CLOSE_SUCCESSPANEL:"ROLAND_VALLEY_CLOSE_SUCCESSPANEL",ALLIANCE_ASSIT_LEFTTIME:"ALLIANCE_ASSIT_LEFTTIME",
COMMON_REMIND_DATA_RESET_BEFORCE:"COMMON_REMIND_DATA_RESET_BEFORCE",COMMON_REMIND_DATA_RESET:"COMMON_REMIND_DATA_RESET",Gold_Diamond_Limit_Update:"Gold_Diamond_Limit_Update",
CLICK_SPRING_MONSTER_ITEM:"CLICK_SPRING_MONSTER_ITEM",UPDATE_SLIDER:"UPDATE_SLIDER"}},54130:(e,t,i)=>{"use strict"
i.d(t,{Q:()=>n})
class n{}n.Normal=0,n.MEDEL=1,n.HORSE=1,n.DIVINE=2,n.GEM=3,n.HORSE_UNREAL=100,n.HORSE_RIDING=101},51965:(e,t,i)=>{"use strict"
i.d(t,{f:()=>n})
class n{}n.Normal=0,n.AddAttrs=1,n.TITLE=2,n.SURFACE_FASHION=3},31922:(e,t,i)=>{"use strict"
i.d(t,{z:()=>s})
var n=i(86133)
class s{}s.JOBSKILL_CONDITION_ATTR_NO=0,s.JOBSKILL_CONDITION_ATTR_YES=1,s.JOBSKILL_CONDITION_ATTR_USEPOINT=2,s.JOBSKILL_CONDITION_ATTR_NOCFG=3,s.MapViewTreeNPC="NPC",
s.MapViewTreeMonster=(0,n.T)("怪物"),s.MapViewTreeGoldMonster=(0,n.T)("黄金怪"),s.MapViewTreeBoss=(0,n.T)("首领"),s.MapViewTreeMultipleExpPoint=(0,n.T)("主线关卡"),s.RadarMapShowAll="All",
s.MapViewTreeTransNPC=(0,n.T)("异世界传送阵"),s.MapViewTreeDoubleArea=(0,n.T)("二倍收益区"),s.MapViewTreeQuadrupleArea=(0,n.T)("四倍收益区"),s.MapViewTreeOctaArea=(0,n.T)("八倍收益区"),
s.MapViewTreeTransport=(0,n.T)("传送点"),s.MapViewTreeElite=(0,n.T)("精英怪"),s.MapViewTreeDoor=(0,n.T)("城门"),s.MapViewTreeStone=(0,n.T)("守护石像"),s.MapViewTreeTown=(0,n.T)("龙塔"),
s.MSViewQuadrupleArea=(0,n.T)("四倍收益区"),s.MSViewQuintupleArea=(0,n.T)("五倍收益区"),s.MSViewSextupleArea=(0,n.T)("六倍收益区"),s.MSViewSetupleArea=(0,n.T)("七倍收益区"),s.MSViewEightfoldArea=(0,
n.T)("八倍收益区"),s.MSViewNinefoldArea=(0,n.T)("九倍收益区"),s.MSViewTenfoldArea=(0,n.T)("十倍收益区"),s.MSViewThirteenArea=(0,n.T)("十三倍收益区"),s.MSViewEightingArea=(0,n.T)("十八倍收益区"),
s.COND_TYPE_ACCEPT_QUEST="ACCEPT_QUEST",s.COND_TYPE_QUEST_FINISHED="QUEST_FINISHED",s.COND_TYPE_QUEST_FINISH_NONEXT="QUEST_FINISH",s.COND_TYPE_QUEST_COMPLETE="QUEST_COMPLETE",
s.COND_TYPE_ACCEPT_QUEST_NOFINISH="ACCEPT_QUEST_NOFINISH",s.COND_TYPE_QUEST_FIXSTEP="QUEST_FIXSTEP",s.COND_TYPE_QUEST_NO_FIXSTEP="QUEST_NO_FIXSTEP",
s.COND_TYPE_QUEST_FINISHED_DIALOG="QUEST_FINISHED_DIALOGUE",s.COND_TYPE_ENTER_COPY_BEFORE="ENTER_COPY_BEFORE",s.COND_TYPE_ENTER_COPY_BEFORE_NO_LOADING="ENTER_COPY_BEFORE_FORCE",
s.COND_TYPE_ENTER_COPY="ENTER_COPY",s.COND_TYPE_ENTER_COPY_BY_GROUP="ENTER_COPY_BY_GROUPID",s.COND_TYPE_PASS_COPY="PASS_COPY",s.COND_TYPE_ENTER_MAP="ENTER_MAP",
s.COND_TYPE_ENTER_MAP_BEFORE="ENTER_MAP_BEFORE",s.COND_TYPE_NOT_IN_MAP="NOT_IN_MAP",s.COND_TYPE_KILL_MONSTER="KILL_MONSTER",s.COND_TYPE_NOT_IN_MIRALCE="COND_TYPE_NOT_IN_MIRALCE",
s.COND_TYPE_LEVEL="LEVEL",s.COND_TYPE_FUNCTION_OPEN="FUNCTION_OPEN",s.COND_TYPE_FUNCTION_INIT="FUNCTION_INIT",s.COND_TYPE_FUNCTION_NOT_OPEN="FUNCTION_NOT_OPEN",
s.COND_TYPE_CREATE_ROLE="CREATE_ROLE",s.COND_TYPE_DISCONNECT="DISCONNECT",s.COND_TYPE_CopyResult="COPY_RESULT",s.COND_TYPE_CopyResult_BY_GROUP="COPY_RESULT_BY_GROUP",
s.COND_TYPE_LOGIN="LOGIN",s.COND_TYPE_REWARD_BIG="REWARD_BIG",s.COND_TYPE_REWARD_SMALL="REWARD_SMALL",s.MASTER_POINT="MASTER_POINT",s.STORY_END="STORY_END",
s.COND_TYPE_EQUIP_GET_TIPS_OPEN="EQUIP_GET_TIPS_OPEN",s.COND_TYPE_NPC_SHOP="NPC_SHOP",s.COND_TYPE_TASK_CLICK="COND_TYPE_TASK_CLICK",s.COND_JOB="JOB",s.FIRST_TITLE="FIRST_TITLE",
s.COND_OPEN_UI="OPEN_UI",s.COND_OPEN_SECOND_SKILL_SLOT="OPEN_SECOND_SKILL_SLOT",s.COND_BOUNTY_TASK_FINISHED="BOUNTY_TASK_FINISHED",s.COND_GOLD_DEMAND="GOLD_DEMAND",
s.COND_GOLD_LACK="GOLD_LACK",s.COND_EQUIP_ENHANCE="EQUIP_ENHANCE",s.ENTER_AREA="ENTER_AREA",s.ENTER_COPY_BY_GROUPID_END_PRE="ENTER_COPY_BY_GROUPID_END_PRE",
s.COND_USE_ITEM="USE_ITEM",s.COND_OFFLINE_HANG_REWARD="OFFLINE_HANG_REWARD",s.COND_LEAVE_MAP="LEAVE_MAP",s.COND_LEAVE_ANY_COPY="COND_LEAVE_ANY_COPY",
s.COND_MIRACLE_REWARD="MIRACLE_REWARD",s.COND_VITALITY_REWARD="VITALITY_REWARD",s.COND_BATTLESCORE_LARGER="BATTLESCORE_LARGER",s.COND_BATTLESCORE_RANGE="BATTLESCORE_RANGE",
s.COND_LEVEL_LOWER="LEVEL_LOWER",s.COND_LEVEL_HIGHER="LEVEL_HIGHER",s.COND_LEVEL_RANGE="LEVEL_RANGE",s.COND_FAIL_MAP_PASS="MAP_FAILED",s.HAVE_REWARD_FUN="HAVE_REWARD_FUN",
s.COND_TYPE_ENTER_COPY_BY_TYPE="COND_TYPE_ENTER_COPY_BY_TYPE",s.COND_TYPE_IN_SCENE_MAP="IN_SCENE_MAP",s.COND_TYPE_NOT_IN_SCENE_MAP="NOT_IN_SCENE_MAP",
s.COND_TYPE_TICK_20="COND_TYPE_TICK_20",s.COND_TYPE_TICK_15="COND_TYPE_TICK_15",s.COND_TYPE_TICK_10="COND_TYPE_TICK_10",s.COND_VIP_LEVEL="VIP_LEVEL",
s.COND_KILL_MONSTER="KILL_MONSTER",s.COND_KILL_MONSTER_TYPE="KILL_MONSTER_TYPE",s.COND_GET_EQUIP_STAR_EQUAL="GET_EQUIP_STAR_EQUAL",s.COND_GET_EQUIP_STAR_MORE="GET_EQUIP_STAR_MORE",
s.COND_GET_EQUIP_STAR_LESS="GET_EQUIP_STAR_LESS",s.COND_GET_EQUIP_EXEATTR_EQUAL="GET_EQUIP_EXEATTR_EQUAL",s.COND_GET_EQUIP_EXEATTR_MORE="GET_EQUIP_EXEATTR_MORE",
s.COND_GET_EQUIP_EXEATTR_LESS="GET_EQUIP_EXEATTR_LESS",s.COND_GET_ITEM_QUALITY_EQUAL="GET_ITEM_QUALITY_EQUAL",s.COND_GET_ITEM_QUALITY_HIGHER="GET_ITEM_QUALITY_HIGHER",
s.COND_GET_ITEM_QUALITY_LOWER="GET_ITEM_QUALITY_LOWER",s.COND_GET_ITEM="GET_ITEM",s.COND_CURRENT_COPY_RATE_EQUAL="CURRENT_COPY_RATE_EQUAL",
s.COND_CURRENT_COPY_RATE_HIGHER="CURRENT_COPY_RATE_HIGHER",s.COND_CURRENT_COPY_RATE_LOWER="CURRENT_COPY_RATE_LOWER",s.COND_IN_MAP="IN_MAP",s.COND_IN_AREA="IN_AREA",
s.COND_IN_COPY="IN_COPY",s.COND_IN_COPY_TYPE="IN_COPY_TYPE",s.COND_NO_OPERATION="NO_OPERATION",s.COND_TASK_NOT_FINISHED="TASK_NOT_FINISHED",
s.COND_COPY_EXP_MEDICINE="COND_COPY_EXP_MEDICINE:COPYTYPE",s.CUR_COPY_MISS_COIN_ENCOURAGE="CUR_COPY_MISS_COIN_ENCOURAGE",
s.CUR_ALLIANCE_MISS_COIN_ENCOURAGE="CUR_ALLIANCE_MISS_COIN_ENCOURAGE",s.COND_NONE_COIN_INSPRIRE_IN_ALLICANCE="NONE_COIN_INSPRIRE_IN_ALLICANCE",
s.COND_NONE_COIN_INSPRIRE_IN_COPY="NONE_COIN_INSPRIRE_IN_COPY",s.COND_GUARD_MAIN_BATTLE="GUARD_MAIN_BATTLE",s.COND_PICKUP_EQUIP_STAR_EQUAL="PICKUP_EQUIP_STAR_EQUAL",
s.COND_PICKUP_EQUIP_STAR_MORE="PICKUP_EQUIP_STAR_MORE",s.COND_PICKUP_EQUIP_STAR_LESS="PICKUP_EQUIP_STAR_LESS",s.COND_PICKUP_EQUIP_EXEATTR_EQUAL="PICKUP_EQUIP_EXEATTR_EQUAL",
s.COND_PICKUP_EQUIP_EXEATTR_MORE="PICKUP_EQUIP_EXEATTR_MORE",s.COND_PICKUP_EQUIP_EXEATTR_LESS="PICKUP_EQUIP_EXEATTR_LESS",
s.COND_PICKUP_ITEM_QUALITY_EQUAL="PICKUP_ITEM_QUALITY_EQUAL",s.COND_PICKUP_ITEM_QUALITY_HIGHER="PICKUP_ITEM_QUALITY_HIGHER",
s.COND_PICKUP_ITEM_QUALITY_LOWER="PICKUP_ITEM_QUALITY_LOWER",s.COND_PICKUP_ITEM="PICKUP_ITEM",s.COND_OPEN_EQUIP_POSITION="OPEN_EQUIP_POSITION",s.CON_GUIDE_NEXT="CON_GUIDE_NEXT",
s.CON_ENTER_FIELD_OCCUPY_RING="CON_ENTER_FIELD_OCCUPY_RING",s.COND_DEFENSE_LOWER="COND_DEFENSE_LOWER",s.COND_DEFENSE_LARGER="COND_DEFENSE_LARGER",
s.COND_DEFENSE_RANGE="COND_DEFENSE_RANGE",s.COND_HAS_EXCELLENTADD_EQUIP="HAS_EXCELLENTADD_EQUIP",s.COND_HAS_EXCELLENTADD_MATERIAL="HAS_EXCELLENTADD_MATERIAL",
s.COND_GTLEVEL="GTLevel",s.COND_ACCEPTQUEST="acceptQuest",s.COND_CLOSE_UI="CLOSE_UI",s.COND_CLICK_BTN="CLICKBTN",s.CLICK_UI_TASK_ITEM="CLICK_UI_TASK_ITEM",s.LIVENESS="LIVENESS",
s.WEAREQUIPMENT="WEAREQUIPMENT",s.MOVE_SPEED_FACTOR=62.5,s.SKILL_ID_XCYN=2125,s.SceneTouchBtnType_NPC=1,s.SceneTouchBtnType_Wall=2,s.SceneTouchBtnType_Drop=3,
s.SceneTouchBtnType_Collect=4,s.SceneTouchStateNormal=0,s.SceneTouchStateShow=1,s.SceneTouchHide=2,s.PRELOAD_UNLOAD_CHANGE_ROLE=0,s.PRELOAD_UNLOAD_DEFAULT=1,
s.PRELOAD_UNLOAD_CHANGE_MAP=2,s.StoryStateNormal=0,s.StoryStateLoading=1,s.StoryStatePlaying=2,s.StoryAfterActionDoQuest="DO_QUEST",s.StoryAfterActionDoHang="DO_HANG",
s.StoryAfterActionTRANSPORT="TRANSPORT",s.COND_TYPE_GET_FIRST_STAR_EQUIPMENT="GET_FIRST_STAR_EQUIPMENT",s.TASK_UNLOCK_MAP="TASK_UNLOCK_MAP",s.TerrainTypeUnSafe=-1,
s.TerrainTypeSafe=0,s.TerrainTypeDragonTower=1,s.TerrainTypeDeepWater=2,s.TerrainTypeShallowWater=3,s.TerrainTypeDoubleExp=4,s.TerrainTypeQuatraExp=5,s.TerrainTypeOctaExp=6,
s.AsuramWarGuideArea=7,s.ServerGroupTypeRecommend=3,s.ServerGroupTypeHistory=2,s.ServerGroupTypeNormal=1,s.DeviceQualityHigh=2,s.DeviceQualityMiddle=1,s.DeviceQualityLow=0,
s.DISPLAY_TYPE_GUARD="GUARD",s.DISPLAY_TYPE_MONSTER="MONSTER",s.DISPLAY_TYPE_RIDING="RIDING",s.DISPLAY_TYPE_NPC="NPC",s.ASURAMWAR_BEGIN="ASURAMWAR_BEGIN",s.VITALITY="VITALITY",
s.COND_TYPE_CREATE_ROLE_BEFORE="CREATE_CHARACTER",s.COND_TYPE_FIRST_CLOSE_PANDORABOX="COND_TYPE_FIRST_CLOSE_PANDORABOX",s.SKY_ILLUSION_MOVESPEED_DOWN="SKY_ILLUSION_MOVESPEED_DOWN",
s.ACC_CHECKPOINT="ACC_CHECKPOINT",s.PASS_CHECKPOINT="PASS_CHECKPOINT",s.COND_GUIDE_EVENT="GUIDE_EVENT",s.COND_PASS_BOSS_FAIL="PASS_BOSS_FAIL",s.COND_PASS_BOSS_FIX="PASS_BOSS_FIX",
s.SHOPID_EXIST="SHOPID_EXIST",s.TerrainHalfSkyland=4},1003:(e,t,i)=>{"use strict"
i.d(t,{U:()=>r})
var n=i(86133),s=i(66788),a=i(77477)
class r{static GetAttKeyByName(e){
return"Strength"==e?a.Z.Strength:"Vitality"==e?a.Z.Vitality:"Agility"==e?a.Z.Agility:"Intelligence"==e?a.Z.Intelligence:"Level"==e?a.Z.Level:"FreePoint"==e?a.Z.FreePoint:"PhyAttack_Max"==e?a.Z.PhyAttack_Max:"PhyAttack_Min"==e?a.Z.PhyAttack_Min:"Defense"==e?a.Z.Defense:"Attack"==e?a.Z.Attack:"MaxHp"==e?a.Z.MaxHp:"MaxMp"==e?a.Z.MaxMp:"AttackFix"==e?a.Z.AttackFix:"DefenseFix"==e?a.Z.DefenseFix:"HpFix"==e?a.Z.HpFix:"MpFix"==e?a.Z.MpFix:"HitRate"==e?a.Z.HitRate:"DodgeRate"==e?a.Z.DodgeRate:"AttackSpeed"==e?a.Z.AttackSpeed:"MoveSpeed"==e?a.Z.MoveSpeed:"MpRate"==e?a.Z.MpRate:"AttackRate"==e?a.Z.AttackRate:"DefenseRate"==e?a.Z.DefenseRate:"HpRate"==e?a.Z.HpRate:"BaseHpRate"==e?a.Z.BaseHpRate:"BaseAttackRate"==e?a.Z.BaseAttackRate:"BaseDefenseRate"==e?a.Z.BaseDefenseRate:"HitRateUpRate"==e?a.Z.HitRateUpRate:"EquipDodgeRateAddRate"==e?a.Z.EquipDodgeRateAddRate:"DodgeRateAddRate"==e?a.Z.DodgeRateAddRate:"SkillDamageDown"==e?a.Z.SkillDamageDown:"SkillDamageUp"==e?a.Z.SkillDamageUp:"PveSkillDamageUp"==e?a.Z.PveSkillDamageUp:"PveSkillDamageDown"==e?a.Z.PveSkillDamageDown:"PveDamageDown"==e?a.Z.PveDamageDown:"PveDamageUp"==e?a.Z.PveDamageUp:"PvpSkillDamageDown"==e?a.Z.PvpSkillDamageDown:"PvpSkillDamageUp"==e?a.Z.PvpSkillDamageUp:"AttackSpeedAddRate"==e?a.Z.AttackSpeedAddRate:"MoveSpeedAddRate"==e?a.Z.MoveSpeedAddRate:"Hedge"==e?a.Z.Hedge:"hitFix"==e?a.Z.hitFix:"PveBossDamageUp"==e?a.Z.PveBossDamageUp:"SkillDamageBase"==e?a.Z.SkillDamageBase:"HpAutoRecoverRate"==e?a.Z.HpAutoRecoverRate:"DamageDown"==e?a.Z.DamageDown:"DamageDownFix"==e?a.Z.DamageDownFix:"DamageUp"==e?a.Z.DamageUp:"DamageUpFix"==e?a.Z.DamageUpFix:"SceneDamageUp"==e?a.Z.SceneDamageUp:"BeDamageUpRate"==e?a.Z.BeDamageUpRate:"CreateDamageDownRate"==e?a.Z.CreateDamageDownRate:"PvpDamageDown"==e?a.Z.PvpDamageDown:"PvpDamageUp"==e?a.Z.PvpDamageUp:"ReflectDamage"==e?a.Z.ReflectDamage:"ReflectDamageFix"==e?a.Z.ReflectDamageFix:"ParryRate"==e?a.Z.ParryRate:"ParryDamageUp"==e?a.Z.ParryDamageUp:"IgnoreHit"==e?a.Z.IgnoreHit:"IgnoreHitResistanceRate"==e?a.Z.IgnoreHitResistanceRate:"Treatment"==e?a.Z.Treatment:"TreatmentUpRate"==e?a.Z.TreatmentUpRate:"TreatmentDownRate"==e?a.Z.TreatmentDownRate:"TreatmentFix"==e?a.Z.TreatmentFix:"TreatmentEffectUpRate"==e?a.Z.TreatmentEffectUpRate:"TreatmentEffectDownRate"==e?a.Z.TreatmentEffectDownRate:"BeTreatmentEffectUpRate"==e?a.Z.BeTreatmentEffectUpRate:"BeTreatmentEffectDownRate"==e?a.Z.BeTreatmentEffectDownRate:"CriticalHitRate"==e?a.Z.CriticalHitRate:"CriticalHit"==e?a.Z.CriticalHit:"CriticalHitResistance"==e?a.Z.CriticalHitResistance:"CriticalResistRate"==e?a.Z.CriticalResistRate:"CriticalHitDamageUpFix"==e?a.Z.CriticalHitDamageUpFix:"CriticalHitDamageDownFix"==e?a.Z.CriticalHitDamageDownFix:"ExcellentHitRate"==e?a.Z.ExcellentHitRate:"ExcellentHit"==e?a.Z.ExcellentHit:"ExcellentHitResistance"==e?a.Z.ExcellentHitResistance:"ExcellentHitResistRate"==e?a.Z.ExcellentHitResistRate:"ExcellentHitDamageUpFix"==e?a.Z.ExcellentHitDamageUpFix:"ExcellentHitDamageDownFix"==e?a.Z.ExcellentHitDamageDownFix:"DeadHitRate"==e?a.Z.DeadHitRate:"DeadHitDamageUp"==e?a.Z.DeadHitDamageUp:"DeadHitDamageDown"==e?a.Z.DeadHitDamageDown:"DeadHitResistanceRate"==e?a.Z.DeadHitResistanceRate:"DeadHitDamageUpFix"==e?a.Z.DeadHitDamageUpFix:"DeadHitDamageDownFix"==e?a.Z.DeadHitDamageDownFix:"RageRate"==e?a.Z.RageRate:"RageDamageUp"==e?a.Z.RageDamageUp:"RageDamageDown"==e?a.Z.RageDamageDown:"RageResistRate"==e?a.Z.RageResistRate:"RageDamageFixUp"==e?a.Z.RageDamageFixUp:"RageDamageFixDown"==e?a.Z.RageDamageFixDown:"CdUpRate"==e?a.Z.CdUpRate:"CdUpBase"==e?a.Z.CdUpBase:"CdDownRate"==e?a.Z.CdDownRate:"CdDownBase"==e?a.Z.CdDownBase:"DebuffDuationUpFix"==e?a.Z.DebuffDuationUpFix:"DebuffDuationUpRate"==e?a.Z.DebuffDuationUpRate:"DebuffDuationDownFix"==e?a.Z.DebuffDuationDownFix:"DebuffDuationDownRate"==e?a.Z.DebuffDuationDownRate:"EX_DamageDown"==e?a.Z.EX_DamageDown:"EX_MapHP"==e?a.Z.EX_MapHP:"EX_DamageUp"==e?a.Z.EX_DamageUp:"EX_Attack"==e?a.Z.EX_Attack:"EX_DEFENSE"==e?a.Z.EX_DEFENSE:"EX_HIT_RATE"==e?a.Z.EX_HIT_RATE:"KILL_MONSTER_HP_RECOVER"==e?a.Z.KILL_MONSTER_HP_RECOVER:"GoldSummonInherit"==e?a.Z.GoldSummonInherit:"AddDropGoldKillMon"==e?a.Z.AddDropGoldKillMon:"ExpAdd"==e?a.Z.ExpAdd:"MonsterAttackInterval"==e?a.Z.MonsterAttackInterval:"MoveVelocity"==e?a.Z.MoveVelocity:"PoisoningDamageRateUp"==e?a.Z.PoisoningDamageRateUp:"EquipColumnHpRate"==e?a.Z.EquipColumnHpRate:"EquipColumnAttackRate"==e?a.Z.EquipColumnAttackRate:"EquipColumnDefenseRate"==e?a.Z.EquipColumnDefenseRate:"TheEquipBaseAttrRate"==e?a.Z.TheEquipBaseAttrRate:"StageEquipmentMaxHpAddRate"==e?a.Z.StageEquipmentMaxHpAddRate:"StageEquipmentDefenseAddRate"==e?a.Z.StageEquipmentDefenseAddRate:"StageEquipmentAttackAddRate"==e?a.Z.StageEquipmentAttackAddRate:"DamageDownLevelAddRate"==e?a.Z.DamageDownLevelAddRate:"MaxHpLevelAddRate"==e?a.Z.MaxHpLevelAddRate:"AttackLevelLevelAddRate"==e?a.Z.AttackLevelLevelAddRate:"HitRateLevelAddRate"==e?a.Z.HitRateLevelAddRate:"DamageUpLevelAddRate"==e?a.Z.DamageUpLevelAddRate:"EquipColumnAllGemAttrRatio"==e?a.Z.EquipColumnAllGemAttrRatio:"EnhanceUp"==e?a.Z.EnhanceUp:"ElementBaseRate"==e?a.Z.ElementBaseRate:(s.Y.LogError((0,
n.T)("属性:")+(e+(0,n.T)(" 前端未做ID映射"))),0)}static GetAttrNameByType(e){
return e==a.Z.Strength?"Strength":e==a.Z.Vitality?"Vitality":e==a.Z.Agility?"Agility":e==a.Z.Intelligence?"Intelligence":e==a.Z.Level?"Level":e==a.Z.FreePoint?"FreePoint":e==a.Z.PhyAttack_Max?"PhyAttack_Max":e==a.Z.PhyAttack_Min?"PhyAttack_Min":e==a.Z.Defense?"Defense":e==a.Z.Attack?"Attack":e==a.Z.MaxHp?"MaxHp":e==a.Z.MaxMp?"MaxMp":e==a.Z.AttackFix?"AttackFix":e==a.Z.DefenseFix?"DefenseFix":e==a.Z.HpFix?"HpFix":e==a.Z.MpFix?"MpFix":e==a.Z.HitRate?"HitRate":e==a.Z.DodgeRate?"DodgeRate":e==a.Z.AttackSpeed?"AttackSpeed":e==a.Z.MoveSpeed?"MoveSpeed":e==a.Z.MpRate?"MpRate":e==a.Z.AttackRate?"AttackRate":e==a.Z.DefenseRate?"DefenseRate":e==a.Z.HpRate?"HpRate":e==a.Z.BaseHpRate?"BaseHpRate":e==a.Z.BaseAttackRate?"BaseAttackRate":e==a.Z.BaseDefenseRate?"BaseDefenseRate":e==a.Z.HitRateUpRate?"HitRateUpRate":e==a.Z.EquipDodgeRateAddRate?"EquipDodgeRateAddRate":e==a.Z.DodgeRateAddRate?"DodgeRateAddRate":e==a.Z.SkillDamageDown?"SkillDamageDown":e==a.Z.SkillDamageUp?"SkillDamageUp":e==a.Z.PveSkillDamageUp?"PveSkillDamageUp":e==a.Z.PveSkillDamageDown?"PveSkillDamageDown":e==a.Z.PveDamageDown?"PveDamageDown":e==a.Z.PveDamageUp?"PveDamageUp":e==a.Z.PvpSkillDamageDown?"PvpSkillDamageDown":e==a.Z.PvpSkillDamageUp?"PvpSkillDamageUp":e==a.Z.AttackSpeedAddRate?"AttackSpeedAddRate":e==a.Z.MoveSpeedAddRate?"MoveSpeedAddRate":e==a.Z.Hedge?"Hedge":e==a.Z.hitFix?"hitFix":e==a.Z.PveBossDamageUp?"PveBossDamageUp":e==a.Z.SkillDamageBase?"SkillDamageBase":e==a.Z.HpAutoRecoverRate?"HpAutoRecoverRate":e==a.Z.DamageDown?"DamageDown":e==a.Z.DamageDownFix?"DamageDownFix":e==a.Z.DamageUp?"DamageUp":e==a.Z.DamageUpFix?"DamageUpFix":e==a.Z.SceneDamageUp?"SceneDamageUp":e==a.Z.BeDamageUpRate?"BeDamageUpRate":e==a.Z.CreateDamageDownRate?"CreateDamageDownRate":e==a.Z.PvpDamageDown?"PvpDamageDown":e==a.Z.PvpDamageUp?"PvpDamageUp":e==a.Z.ReflectDamage?"ReflectDamage":e==a.Z.ReflectDamageFix?"ReflectDamageFix":e==a.Z.ParryRate?"ParryRate":e==a.Z.ParryDamageUp?"ParryDamageUp":e==a.Z.IgnoreHit?"IgnoreHit":e==a.Z.IgnoreHitResistanceRate?"IgnoreHitResistanceRate":e==a.Z.Treatment?"Treatment":e==a.Z.TreatmentUpRate?"TreatmentUpRate":e==a.Z.TreatmentDownRate?"TreatmentDownRate":e==a.Z.TreatmentFix?"TreatmentFix":e==a.Z.TreatmentEffectUpRate?"TreatmentEffectUpRate":e==a.Z.TreatmentEffectDownRate?"TreatmentEffectDownRate":e==a.Z.BeTreatmentEffectUpRate?"BeTreatmentEffectUpRate":e==a.Z.BeTreatmentEffectDownRate?"BeTreatmentEffectDownRate":e==a.Z.CriticalHitRate?"CriticalHitRate":e==a.Z.CriticalHit?"CriticalHit":e==a.Z.CriticalHitResistance?"CriticalHitResistance":e==a.Z.CriticalResistRate?"CriticalResistRate":e==a.Z.CriticalHitDamageUpFix?"CriticalHitDamageUpFix":e==a.Z.CriticalHitDamageDownFix?"CriticalHitDamageDownFix":e==a.Z.ExcellentHitRate?"ExcellentHitRate":e==a.Z.ExcellentHit?"ExcellentHit":e==a.Z.ExcellentHitResistance?"ExcellentHitResistance":e==a.Z.ExcellentHitDamageUpFix?"ExcellentHitDamageUpFix":e==a.Z.ExcellentHitDamageDownFix?"ExcellentHitDamageDownFix":e==a.Z.ExcellentHitResistRate?"ExcellentHitResistRate":e==a.Z.DeadHitRate?"DeadHitRate":e==a.Z.DeadHitDamageUp?"DeadHitDamageUp":e==a.Z.DeadHitDamageDown?"DeadHitDamageDown":e==a.Z.DeadHitResistanceRate?"DeadHitResistanceRate":e==a.Z.DeadHitDamageUpFix?"DeadHitDamageUpFix":e==a.Z.DeadHitDamageDownFix?"DeadHitDamageDownFix":e==a.Z.RageRate?"RageRate":e==a.Z.RageDamageUp?"RageDamageUp":e==a.Z.RageDamageDown?"RageDamageDown":e==a.Z.RageResistRate?"RageResistRate":e==a.Z.RageDamageFixUp?"RageDamageFixUp":e==a.Z.RageDamageFixDown?"RageDamageFixDown":e==a.Z.CdUpRate?"CdUpRate":e==a.Z.CdUpBase?"CdUpBase":e==a.Z.CdDownRate?"CdDownRate":e==a.Z.CdDownBase?"CdDownBase":e==a.Z.DebuffDuationUpFix?"DebuffDuationUpFix":e==a.Z.DebuffDuationUpRate?"DebuffDuationUpRate":e==a.Z.DebuffDuationDownFix?"DebuffDuationDownFix":e==a.Z.DebuffDuationDownRate?"DebuffDuationDownRate":e==a.Z.EX_DamageDown?"EX_DamageDown":e==a.Z.EX_MapHP?"EX_MapHP":e==a.Z.EX_DamageUp?"EX_DamageUp":e==a.Z.EX_Attack?"EX_Attack":e==a.Z.EX_DEFENSE?"EX_DEFENSE":e==a.Z.EX_HIT_RATE?"EX_HIT_RATE":e==a.Z.KILL_MONSTER_HP_RECOVER?"KILL_MONSTER_HP_RECOVER":e==a.Z.GoldSummonInherit?"GoldSummonInherit":e==a.Z.AddDropGoldKillMon?"AddDropGoldKillMon":e==a.Z.ExpAdd?"ExpAdd":e==a.Z.MonsterAttackInterval?"MonsterAttackInterval":e==a.Z.MoveVelocity?"MoveVelocity":e==a.Z.PoisoningDamageRateUp?"PoisoningDamageRateUp":e==a.Z.EquipColumnHpRate?"EquipColumnHpRate":e==a.Z.EquipColumnAttackRate?"EquipColumnAttackRate":e==a.Z.EquipColumnDefenseRate?"EquipColumnDefenseRate":e==a.Z.TheEquipBaseAttrRate?"TheEquipBaseAttrRate":e==a.Z.StageEquipmentMaxHpAddRate?"StageEquipmentMaxHpAddRate":e==a.Z.StageEquipmentDefenseAddRate?"StageEquipmentDefenseAddRate":e==a.Z.StageEquipmentAttackAddRate?"StageEquipmentAttackAddRate":e==a.Z.DamageDownLevelAddRate?"DamageDownLevelAddRate":e==a.Z.MaxHpLevelAddRate?"MaxHpLevelAddRate":e==a.Z.AttackLevelLevelAddRate?"AttackLevelLevelAddRate":e==a.Z.HitRateLevelAddRate?"HitRateLevelAddRate":e==a.Z.DamageUpLevelAddRate?"DamageUpLevelAddRate":e==a.Z.EquipColumnAllGemAttrRatio?"EquipColumnAllGemAttrRatio":e==a.Z.EnhanceUp?"EnhanceUp":e==a.Z.ElementBaseRate?"ElementBaseRate":(s.Y.LogError((0,
n.T)("属性:")+(e+(0,n.T)(" 前端未做ID映射"))),"")}GetRoleAttValueByKeyName(e,t){const i=r.GetAttKeyByName(t)
return e.Attributes_get().LuaDic_ContainsKey(i)?e.Attributes_get()[i]:0}static GetRoleAttValueByKey(e,t){return e.Attributes_get().LuaDic_ContainsKey(t)?e.Attributes_get()[t]:0}}
r.LevelGT="LevelGT",r.Item="Item",r.VIPLevelGT="VIPLevelGT",r.Currency="Currency",r.MEMORYCON_PRE="MEMORYCON_PRE",r.GTAttribute="GTAttribute"},28287:(e,t,i)=>{"use strict"
i.d(t,{_:()=>n})
class n{}n.None=0,n.Hide=1,n.ShowAll=2,n.ShowSome=3,n.ShowGold_Score_BindDia=4,n.ShowGold_Dia_BindDia=5,n.ShowGold_Dia_Lottery=7,n.ShowGold_Dia_Honour=8,
n.ShowGold_Dia_SkillPoint=9,n.ShowGold_Score_Honour=10,n.ShowGold_Dia_Reputation=11,n.ShowScore_Lottery=12,n.ShowScore_Reputation_Token=13,n.ShowReputation_Fund_Material=14,
n.ShowDia_Reputation_Token=15,n.ShowDia_Score_Token=16,n.ShowDia_Score_Trea=17,n.ShowFund_Material=18,n.ShowGold_Score_Guoqing=19,n.ShowGold_Score_Bairi=20,
n.ShowHonour_Diamond_Bairi=21,n.ShowGold_Score_Shuangdan=22,n.ShowGold_Dia_HonourShopPoint=23,n.ShowDia_FortunePoint=24,n.ShowGOLD_Dia_MAYAHUNTCOUPON=25,
n.ShowGOLD_Dia_MAYAHUNTSCORE=26,n.ShowGOLD_GLOD_MARKET=27,n.ShowGOLD_STARSKY=28,n.ShowGOLD_GLORYCALL=29,n.ShowDia=30,n.ShowGOLD_CELEBRATE=31},82803:(e,t,i)=>{"use strict"
i.d(t,{u:()=>n})
class n{}n.FriendList=0,n.BlackList=1,n.ReqList=2,n.SearchList=3,n.SearchChatList=4},33314:(e,t,i)=>{"use strict"
i.d(t,{Z:()=>p})
var n=i(38836),s=i(86133),a=i(38045),r=i(98800),l=i(28475),o=i(32697),_=(i(66788),i(98130)),u=i(98885),h=i(85602),c=i(21729),d=i(72835),m=i(87888)
class p{static GetJobBaseValue(e){return 1e3*p.GetJobType(e)}static GetJobBaranchBaseValue(e){return 1e3*p.GetJobType(e)+e%10}static GetJobBaseBaranchValue(e){
return 1e3*c.N.Floor(e/1e3)+e%10}static FinishFirstTransfer(e){const t=d.V.Inst_get().GetJobItemById(e)
return null!=t&&t.time>0}static IsSameJobType(e,t){return Math.floor(e/1e3)==Math.floor(t/1e3)}static IsSameTypeAndBranch(e,t){if(Math.floor(e/1e3)==Math.floor(t/1e3)){
const i=p.GetJobBranch(e),n=p.GetJobBranch(t)
if(i==n||0==i||0==n)return!0}return!1}static GetJobType(e){const t=d.V.Inst_get().GetJobItemById(e)
return null==t?p.NONE:t.type}static getJobPic(e){const t=p.GetJobType(e)
return 1==t?"duiwu_icon_0001":2==t?"duiwu_icon_0002":3==t?"duiwu_icon_0003":""}static GetInitRoleAvatarStr(e){const t=p.GetJobType(e)
return 1==t?o.v.sm:2==t?o.v.mg:3==t?o.v.ac:""}static GetCommonJobPic(e){return d.V.Inst_get().GetJobItemById(e).icon5}static GetJobTime(e){const t=d.V.Inst_get().GetJobItemById(e)
return null==t?0:t.time}static GetJobKind(e){return _.GF.INT(e/1e3)}static GetJobBranch(e){const t=d.V.Inst_get().GetJobItemById(e)
return null==t?0:t.branch}static GetJobBranchName(e){const t=d.V.Inst_get().GetJobItemById(e)
return null==t?"":1==t.branch?"力量向":2==t.branch?"智力向":3==t.branch?"敏捷向":""}static GetBranchName(e){return 1==e?"力量":2==e?"智力":3==e?"敏捷":""}static GetJobFullBranchName(e){
const t=e%10
return 1==t?`力·${p.GetJobName(e-t)}`:2==t?`智·${p.GetJobName(e-t)}`:3==t?`敏·${p.GetJobName(e-t)}`:p.GetJobName(e)}static GetJobNameByConfig(e){return""}
static GetJobNameByTransfor(e){const t=1e3*_.GF.INT(r.Y.Inst.PrimaryRoleInfo_get().Job_get()/1e3)+10*e
return p.GetJobName(t)}static GetJobName(e){const t=d.V.Inst_get().GetJobItemById(e)
if(null!=t)return t.name
if(null==t){if(e<1e3){const t=_.GF.INT(e/10)
if(0==t)return p.JOBNAME0
if(1==t)return p.JOBNAME1
if(2==t)return p.JOBNAME2
if(3==t)return p.JOBNAME3
if(4==t)return p.JOBNAME4
if(5==t)return p.JOBNAME5
if(6==t)return p.JOBNAME6
if(7==t)return p.JOBNAME7
if(8==t)return p.JOBNAME8
if(9==t)return p.JOBNAME9}else if(e>=1e3){const t=_.GF.INT(e/1e3),i=_.GF.INT((e-1e3*t)/10)
if(0==e%10&&0!=i){let e=""
return 1==t?(e=(0,s.T)("剑士"),1==i?e=(0,s.T)("骑士"):2==i?e=(0,s.T)("神骑士"):3==i||4==i?e=(0,s.T)("神圣骑士"):5!=i&&6!=i||(e=(0,s.T)("神佑骑士"))):2==t?(e=(0,s.T)("魔法师"),1==i?e=(0,
s.T)("帕希的师"):2==i?e=(0,s.T)("神导师"):3==i||4==i?e=(0,s.T)("神圣导师"):5!=i&&6!=i||(e=(0,s.T)("神佑导师"))):3==t&&(e=(0,s.T)("弓箭手"),1==i?e=(0,s.T)("圣射手"):2==i?e=(0,
s.T)("神射手"):3==i||4==i?e=(0,s.T)("神圣射手"):5!=i&&6!=i||(e=(0,s.T)("神佑射手"))),e}}return""}return""}static GetJobDesc(e){const t=d.V.Inst_get().GetJobItemById(e)
return null==t?StringHelper.s_Empty:t.desc}static GetJobIcon(e,t,i){if(null==e||null==t||null==i)return""
const n=d.V.Inst_get().GetJobItemById(e)
if(null==n)return""
let s
return s=i?t==_.GF.INT(m.$.Female)?n.icon4:n.icon3:t==_.GF.INT(m.$.Female)?n.icon2:n.icon,`atlas/common/${s}`}static GetMainUIJobIcon(e,t){if(null==e||null==t)return""
const i=d.V.Inst_get().GetJobItemById(e)
return null==i?"":t==_.GF.INT(m.$.Female)?`atlas/mainui/${i.icon7}`:`atlas/mainui/${i.icon6}`}static GetJobIconToCharacterTabHightLight(e){if(null==e)return""
const t=_.GF.INT(e/1e3)
return 1==t?"rycommon_sp_0007":2==t?"rycommon_sp_0006":3==t?"rycommon_sp_0008":""}static GetJobIconToCharacterTab(e){if(null==e)return""
const t=_.GF.INT(e/1e3)
return 1==t?"rycommon_sp_0004":2==t?"rycommon_sp_0003":3==t?"rycommon_sp_0005":""}static IsArcherByAnim(e){const t=e
return!!(0,a.t2)(t,l.u)&&p.IsArcher(t.Roleinfo_get().Job_get())}static IsArcher(e){const t=d.V.Inst_get().GetJobItemById(e)
return null!=t&&t.type==p.ARCHER}static IsMagicianByAnim(e){const t=e
return!!(0,a.t2)(t,l.u)&&p.IsMagician(t.Roleinfo_get().Job_get())}static IsMagician(e){const t=d.V.Inst_get().GetJobItemById(e)
return null!=t&&t.type==p.MAGICIAN}static IsUseMagician(e){return!1}static IsSwordByAnim(e){const t=e
return!!(0,a.t2)(t,l.u)&&p.IsSwordman(t.Roleinfo_get().Job_get())}static IsSwordman(e){const t=d.V.Inst_get().GetJobItemById(e)
return null!=t&&t.type==p.SWORDMAN}static ReachJobLimit(e,t){null==t&&(t=r.Y.Inst.PrimaryRoleInfo_get().Job_get())
const i=d.V.Inst_get().GetJobItemById(t)
if(null==i)return!1
const n=_.GF.INT(e/1e3),s=_.GF.INT(e%1e3/10),a=e%10
return(0==n||n==i.type)&&i.time>=s&&(0==a||i.branch==a)}static GetJobIdTime(e){return _.GF.INT(e%1e3/10)}static GetDisplayId(e){const t=d.V.Inst_get().GetJobItemById(e.Job_get())
return null==t?0:e.Sex_get()==_.GF.INT(m.$.Female)?u.M.IsNullOrEmpty(t.femaleModel)?0:u.M.String2Int(t.femaleModel):u.M.IsNullOrEmpty(t.maleModel)?0:u.M.String2Int(t.maleModel)}
static IsTransferContainsJob(e,t){const i=d.V.Inst_get().GetTransferJobList(e)
if(0==i.Count())return!1
for(const[e,s]of(0,n.V5)(i))if(s==t)return!0
return!1}static GetTransTimeTxt(e,t){
return 0==e?1==t?p.JOBNAME0Ex:p.JOBNAME0:1==e?p.JOBNAME1:2==e?p.JOBNAME2:3==e?p.JOBNAME3:4==e?p.JOBNAME4:5==e?p.JOBNAME5:6==e?p.JOBNAME6:7==e?p.JOBNAME7:8==e?p.JOBNAME8:9==e?p.JOBNAME9:10==e?p.JOBNAME10:""
}static GetJobSignName(e){return 101==e?"力战":103==e?"智战":202==e?"智法":203==e?"敏法":302==e?"智弓":303==e?"敏弓":""}static GetJobSignIcon(e){
return 101==e?"rycmsl_sp_0006":103==e?"rycmsl_sp_0004":202==e?"rycmsl_sp_0005":203==e?"rycmsl_sp_0002":302==e?"rycmsl_sp_0003":303==e?"rycmsl_sp_0007":100==e?"rycmsl_sp_0037":200==e?"rycmsl_sp_0036":300==e?"rycmsl_sp_0035":""
}static GetJobPreStr(e){return"1"==e||"1"==e.toString()?"sm":"2"==e||"2"==e.toString()?"mg":"3"==e||"3"==e.toString()?"ac":void 0}}p.NONE=0,p.SWORDMAN=1,p.MAGICIAN=2,p.ARCHER=3,
p.BASE_SWORDMAN=1e3,p.BASE_MAGICIAN=2e3,p.BASE_ARCHER=3e3,p.JOBNAME0=(0,s.T)("无职业需求"),p.JOBNAME0Ex=(0,s.T)("零转"),p.JOBNAME1=(0,s.T)("一转"),p.JOBNAME2=(0,s.T)("二转"),p.JOBNAME3=(0,
s.T)("三转"),p.JOBNAME4=(0,s.T)("四转"),p.JOBNAME5=(0,s.T)("五转"),p.JOBNAME6=(0,s.T)("六转"),p.JOBNAME7=(0,s.T)("七转"),p.JOBNAME8=(0,s.T)("八转"),p.JOBNAME9=(0,s.T)("九转"),p.JOBNAME10=(0,
s.T)("十转"),p.BASE_JOB=new h.Z([p.BASE_SWORDMAN,p.BASE_MAGICIAN,p.BASE_ARCHER])},18660:(e,t,i)=>{"use strict"
i.d(t,{$:()=>s})
var n=i(85602)
class s{constructor(e,t,i,n){this.Id=0,this.Type=0,this.Time=0,this.Branch=0,this.parent=null,this.Child=null,this.Id=e,this.Type=t,this.Time=i,this.Branch=n}AddChild(e){
null==this.Child&&(this.Child=new n.Z)
for(let t=0;t<=this.Child.Count();t++){if(t==this.Child.Count()){this.Child.Add(e)
break}if(e.Id<this.Child[t].Id){this.Child.Insert(t,e)
break}}}SetParent(e){this.parent=e}}},55661:(e,t,i)=>{"use strict"
i.d(t,{S:()=>n})
class n{}n.WildMap="1001",n.CopyMap="1002",n.MiracleMap="1009",n.GoldMap="1003",n.MapCopy="MAPCOPY"},37104:(e,t,i)=>{"use strict"
i.d(t,{$:()=>n})
class n{}n.Auction=0,n.BlackMarket=1,n.Exchange=5,n.Mall=3,n.Recharge=2,n.Intergration=6,n.Trade=4},87888:(e,t,i)=>{"use strict"
i.d(t,{$:()=>n})
class n{}n.None=0,n.Male=1,n.Female=2},13526:(e,t,i)=>{"use strict"
i.d(t,{c:()=>n})
class n{}n.ProSkill=0,n.PassiveSkill=2,n.TalentSkill=3,n.AngleSkill=4},77477:(e,t,i)=>{"use strict"
i.d(t,{Z:()=>s})
var n=i(38962)
class s{static GetAttrKey(e){return null==s.attrDefine&&(s.attrDefine=new n.X,s.SetAttrKey("Strength",1),s.SetAttrKey("Vitality",2),s.SetAttrKey("Agility",3),
s.SetAttrKey("Intelligence",4),s.SetAttrKey("Level",5),s.SetAttrKey("FreePoint",6),s.SetAttrKey("PhyAttack_Max",1e4),s.SetAttrKey("PhyAttack_Min",10001),
s.SetAttrKey("Defense",10002),s.SetAttrKey("Attack",10003),s.SetAttrKey("MaxHp",10004),s.SetAttrKey("MaxMp",10005),s.SetAttrKey("AttackFix",10006),s.SetAttrKey("DefenseFix",10007),
s.SetAttrKey("HpFix",10008),s.SetAttrKey("MpFix",10009),s.SetAttrKey("HitRate",10010),s.SetAttrKey("DodgeRate",10011),s.SetAttrKey("AttackSpeed",10012),
s.SetAttrKey("MoveSpeed",10013),s.SetAttrKey("MpRate",2e4),s.SetAttrKey("AttackRate",20001),s.SetAttrKey("DefenseRate",20002),s.SetAttrKey("HpRate",20003),
s.SetAttrKey("BaseHpRate",20004),s.SetAttrKey("BaseAttackRate",20005),s.SetAttrKey("BaseDefenseRate",20006),s.SetAttrKey("HitRateUpRate",20007),
s.SetAttrKey("EquipDodgeRateAddRate",20008),s.SetAttrKey("DodgeRateAddRate",20009),s.SetAttrKey("SkillDamageDown",20010),s.SetAttrKey("SkillDamageUp",20011),
s.SetAttrKey("PveSkillDamageUp",20012),s.SetAttrKey("PveSkillDamageDown",20013),s.SetAttrKey("PveDamageDown",20014),s.SetAttrKey("PveDamageUp",20015),
s.SetAttrKey("PvpSkillDamageDown",20016),s.SetAttrKey("PvpSkillDamageUp",20017),s.SetAttrKey("AttackSpeedAddRate",20018),s.SetAttrKey("MoveSpeedAddRate",20019),
s.SetAttrKey("Hedge",20020),s.SetAttrKey("hitFix",20021),s.SetAttrKey("PveBossDamageUp",20022),s.SetAttrKey("SkillDamageBase",3e4),s.SetAttrKey("HpAutoRecoverRate",30001),
s.SetAttrKey("DamageDown",30100),s.SetAttrKey("DamageDownFix",30101),s.SetAttrKey("DamageUp",30102),s.SetAttrKey("DamageUpFix",30103),s.SetAttrKey("SceneDamageUp",30105),
s.SetAttrKey("BeDamageUpRate",30200),s.SetAttrKey("CreateDamageDownRate",30201),s.SetAttrKey("PvpDamageDown",30202),s.SetAttrKey("PvpDamageUp",30203),
s.SetAttrKey("ReflectDamage",30300),s.SetAttrKey("ReflectDamageFix",30301),s.SetAttrKey("ParryRate",30302),s.SetAttrKey("ParryDamageUp",30303),s.SetAttrKey("IgnoreHit",30304),
s.SetAttrKey("IgnoreHitResistanceRate",30305),s.SetAttrKey("Treatment",30400),s.SetAttrKey("TreatmentUpRate",30401),s.SetAttrKey("TreatmentDownRate",30402),
s.SetAttrKey("TreatmentFix",30403),s.SetAttrKey("TreatmentEffectUpRate",30404),s.SetAttrKey("TreatmentEffectDownRate",30405),s.SetAttrKey("BeTreatmentEffectUpRate",30406),
s.SetAttrKey("BeTreatmentEffectDownRate",30407),s.SetAttrKey("CriticalHitRate",30500),s.SetAttrKey("CriticalHit",30501),s.SetAttrKey("CriticalHitResistance",30502),
s.SetAttrKey("CriticalResistRate",30503),s.SetAttrKey("CriticalHitDamageUpFix",30504),s.SetAttrKey("CriticalHitDamageDownFix",30505),s.SetAttrKey("ExcellentHitRate",30600),
s.SetAttrKey("ExcellentHit",30601),s.SetAttrKey("ExcellentHitResistance",30602),s.SetAttrKey("ExcellentHitResistRate",30603),s.SetAttrKey("ExcellentHitDamageUpFix",30704),
s.SetAttrKey("ExcellentHitDamageDownFix",30705),s.SetAttrKey("DeadHitRate",30700),s.SetAttrKey("DeadHitDamageUp",30701),s.SetAttrKey("DeadHitDamageDown",30702),
s.SetAttrKey("DeadHitResistanceRate",30703),s.SetAttrKey("DeadHitDamageUpFix",30704),s.SetAttrKey("DeadHitDamageDownFix",30705),s.SetAttrKey("RageRate",30800),
s.SetAttrKey("RageDamageUp",30801),s.SetAttrKey("RageDamageDown",30802),s.SetAttrKey("RageResistRate",30803),s.SetAttrKey("RageDamageFixUp",30804),
s.SetAttrKey("RageDamageFixDown",30805),s.SetAttrKey("CdUpRate",30900),s.SetAttrKey("CdUpBase",30901),s.SetAttrKey("CdDownRate",30902),s.SetAttrKey("CdDownBase",30903),
s.SetAttrKey("DebuffDuationUpFix",30904),s.SetAttrKey("DebuffDuationUpRate",30905),s.SetAttrKey("DebuffDuationDownFix",30906),s.SetAttrKey("DebuffDuationDownRate",30907),
s.SetAttrKey("EquipColumnAllGemAttrRatio",30908),s.SetAttrKey("EX_DamageDown",4e4),s.SetAttrKey("EX_MapHP",40001),s.SetAttrKey("EX_DamageUp",40002),s.SetAttrKey("EX_Attack",40003),
s.SetAttrKey("EX_DEFENSE",40004),s.SetAttrKey("EX_HIT_RATE",40005),s.SetAttrKey("KILL_MONSTER_HP_RECOVER",40100),s.SetAttrKey("GoldSummonInherit",5e4),
s.SetAttrKey("AddDropGoldKillMon",6e4),s.SetAttrKey("ExpAdd",60001),s.SetAttrKey("MonsterAttackInterval",60002),s.SetAttrKey("MoveVelocity",60003),
s.SetAttrKey("PoisoningDamageRateUp",60004),s.SetAttrKey("EquipColumnHpRate",7e4),s.SetAttrKey("EquipColumnAttackRate",70001),s.SetAttrKey("EquipColumnDefenseRate",70002),
s.SetAttrKey("TheEquipBaseAttrRate",70003),s.SetAttrKey("StageEquipmentMaxHpAddRate",70006),s.SetAttrKey("StageEquipmentDefenseAddRate",70007),
s.SetAttrKey("StageEquipmentAttackAddRate",70008),s.SetAttrKey("DamageDownLevelAddRate",70009),s.SetAttrKey("MaxHpLevelAddRate",70010),s.SetAttrKey("AttackLevelAddRate",70011),
s.SetAttrKey("HitRateLevelAddRate",70012),s.SetAttrKey("DamageUpLevelAddRate",70013),s.SetAttrKey("ElementMaxHpRate",70014),s.SetAttrKey("ElementAttackRate",70015),
s.SetAttrKey("ElementDefenseRate",70016),s.SetAttrKey("ElementBaseRate",70017),s.SetAttrKey("EnhanceUp",70021),s.SetAttrKey("Attack_Max",900001),s.SetAttrKey("Attack_Min",900002),
s.SetAttrKey("SkillAdd",900003),s.SetAttrKey("DebuffRes",900004)),s.attrDefine.LuaDic_ContainsKey(e)?s.attrDefine[e]:-1}static SetAttrKey(e,t){s.attrDefine[e]=t}}s.attrDefine=null,
s.Strength=1,s.Vitality=2,s.Agility=3,s.Intelligence=4,s.Level=5,s.FreePoint=6,s.PhyAttack_Max=1e4,s.PhyAttack_Min=10001,s.Defense=10002,s.Attack=10003,s.MaxHp=10004,s.MaxMp=10005,
s.AttackFix=10006,s.DefenseFix=10007,s.HpFix=10008,s.MpFix=10009,s.HitRate=10010,s.DodgeRate=10011,s.AttackSpeed=10012,s.MoveSpeed=10013,s.MpRate=2e4,s.AttackRate=20001,
s.DefenseRate=20002,s.HpRate=20003,s.BaseHpRate=20004,s.BaseAttackRate=20005,s.BaseDefenseRate=20006,s.HitRateUpRate=20007,s.EquipDodgeRateAddRate=20008,s.DodgeRateAddRate=20009,
s.SkillDamageDown=20010,s.SkillDamageUp=20011,s.PveSkillDamageUp=20012,s.PveSkillDamageDown=20013,s.PveDamageDown=20014,s.PveDamageUp=20015,s.PvpSkillDamageDown=20016,
s.PvpSkillDamageUp=20017,s.AttackSpeedAddRate=20018,s.MoveSpeedAddRate=20019,s.Hedge=20020,s.hitFix=20021,s.PveBossDamageUp=20022,s.SkillDamageBase=3e4,s.HpAutoRecoverRate=30001,
s.DamageDown=30100,s.DamageDownFix=30101,s.DamageUp=30102,s.DamageUpFix=30103,s.SceneDamageUp=30105,s.BeDamageUpRate=30200,s.CreateDamageDownRate=30201,s.PvpDamageDown=30202,
s.PvpDamageUp=30203,s.ReflectDamage=30300,s.ReflectDamageFix=30301,s.ParryRate=30302,s.ParryDamageUp=30303,s.IgnoreHit=30304,s.IgnoreHitResistanceRate=30305,s.Treatment=30400,
s.TreatmentUpRate=30401,s.TreatmentDownRate=30402,s.TreatmentFix=30403,s.TreatmentEffectUpRate=30404,s.TreatmentEffectDownRate=30405,s.BeTreatmentEffectUpRate=30406,
s.BeTreatmentEffectDownRate=30407,s.CriticalHitRate=30500,s.CriticalHit=30501,s.CriticalHitResistance=30502,s.CriticalResistRate=30503,s.CriticalHitDamageUpFix=30504,
s.ExcellentHitRate=30600,s.ExcellentHit=30601,s.ExcellentHitResistance=30602,s.ExcellentHitResistRate=30603,s.ExcellentHitDamageUpFix=300604,s.ExcellentHitDamageDownFix=300605,
s.DeadHitRate=30700,s.DeadHitDamageUp=30701,s.DeadHitDamageDown=30702,s.DeadHitResistanceRate=30703,s.DeadHitDamageUpFix=30704,s.DeadHitDamageDownFix=30705,s.RageRate=30800,
s.RageDamageUp=30801,s.RageDamageDown=30802,s.RageResistRate=30803,s.RageDamageFixUp=30804,s.RageDamageFixDown=30805,s.CdUpRate=30900,s.CdUpBase=30901,s.CdDownRate=30902,
s.CdDownBase=30903,s.DebuffDuationUpFix=30904,s.DebuffDuationUpRate=30905,s.DebuffDuationDownFix=30906,s.DebuffDuationDownRate=30907,s.EquipColumnAllGemAttrRatio=30908,
s.EX_DamageDown=4e4,s.EX_MapHP=40001,s.EX_DamageUp=40002,s.EX_Attack=40003,s.EX_DEFENSE=40004,s.EX_HIT_RATE=40005,s.KILL_MONSTER_HP_RECOVER=40100,s.GoldSummonInherit=5e4,
s.AddDropGoldKillMon=6e4,s.ExpAdd=60001,s.MonsterAttackInterval=60002,s.MoveVelocity=60003,s.PoisoningDamageRateUp=60004,s.EquipColumnHpRate=7e4,s.EquipColumnAttackRate=70001,
s.EquipColumnDefenseRate=70002,s.TheEquipBaseAttrRate=70003,s.StageEquipmentMaxHpAddRate=70006,s.StageEquipmentDefenseAddRate=70007,s.StageEquipmentAttackAddRate=70008,
s.DamageDownLevelAddRate=70009,s.MaxHpLevelAddRate=70010,s.AttackLevelLevelAddRate=70011,s.HitRateLevelAddRate=70012,s.DamageUpLevelAddRate=70013,s.ElementMaxHpRate=70014,
s.ElementAttackRate=70015,s.ElementDefenseRate=70016,s.ElementBaseRate=70017,s.EnhanceUp=70021,s.Attack_Max=900001,s.Attack_Min=900002,s.SkillAdd=900003,s.DebuffRes=900004},
29832:(e,t,i)=>{"use strict"
i.d(t,{o:()=>s})
var n=i(5924)
class s{constructor(){this.topHpSpr=null,this.decreaseHpSpr=null,this.increaseHpSpr=null,this.hpData=null,this.terminalAmount=0,this.deltaAmount=0,this.speedAmount=.2,
this.timeId=0,this.delayTime=50,this.repeatLongTime=20,this.repeatShortTime=10,this.repeatNowTime=0,this.isInit=!1,this._degf_LongTimeDecrease=null,
this._degf_LongTimeIncrease=null,this._degf_ShortTimeDecrease=null,this._degf_ShortTimeIncrease=null,this._degf_LongTimeDecrease=()=>this.LongTimeDecrease(),
this._degf_LongTimeIncrease=()=>this.LongTimeIncrease(),this._degf_ShortTimeDecrease=()=>this.ShortTimeDecrease(),this._degf_ShortTimeIncrease=()=>this.ShortTimeIncrease()}
Init(e,t,i,n){this.isInit=!0,this.topHpSpr=e,this.decreaseHpSpr=t,this.increaseHpSpr=i,this.hpData=n
const s=1-this.hpData.deLength
this.topHpSpr.fillRange=s,this.decreaseHpSpr.fillRange=s,this.increaseHpSpr.fillRange=s}Clear(){this.isInit=!1,this.StopTimer(),null!=this.topHpSpr&&this.topHpSpr.widthSet(155),
null!=this.decreaseHpSpr&&this.decreaseHpSpr.widthSet(155),null!=this.decreaseHpSpr&&this.increaseHpSpr.widthSet(155)}UpdateHp(e){this.hpData=e,
this.terminalAmount=this.hpData.currentHp/this.hpData.maxHp,0!=this.timeId?(this.StopTimer(),
this.hpData.currentHp-this.GetAnimeHp()<0?this.DecreaseHp():this.IncreaseHp()):this.hpData.currentHp-this.hpData.lastHp<0?this.DecreaseHp():this.IncreaseHp()}DecreaseHp(){
this.topHpSpr.fillRange=this.terminalAmount,this.increaseHpSpr.node.SetActive(!1),this.decreaseHpSpr.node.SetActive(!0),
this.decreaseHpSpr.fillRange-this.terminalAmount>this.speedAmount?(this.deltaAmount=(this.terminalAmount-this.decreaseHpSpr.fillRange)/this.repeatLongTime,
this.timeId=n.C.Inst_get().SetInterval(this._degf_LongTimeDecrease,this.delayTime,this.repeatLongTime)):(this.deltaAmount=(this.terminalAmount-this.decreaseHpSpr.fillRange)/this.repeatShortTime,
this.timeId=n.C.Inst_get().SetInterval(this._degf_ShortTimeDecrease,this.delayTime,this.repeatShortTime))}IncreaseHp(){this.decreaseHpSpr.node.SetActive(!1),
this.decreaseHpSpr.fillRange=this.terminalAmount,this.increaseHpSpr.node.SetActive(!0),this.increaseHpSpr.fillRange=this.terminalAmount,
this.terminalAmount-this.topHpSpr.fillRange>this.speedAmount?(this.deltaAmount=(this.terminalAmount-this.topHpSpr.fillRange)/this.repeatLongTime,
this.timeId=n.C.Inst_get().SetInterval(this._degf_LongTimeIncrease,this.delayTime,this.repeatLongTime)):(this.deltaAmount=(this.terminalAmount-this.topHpSpr.fillRange)/this.repeatShortTime,
this.timeId=n.C.Inst_get().SetInterval(this._degf_ShortTimeIncrease,this.delayTime,this.repeatShortTime))}LongTimeDecrease(){this.repeatNowTime+=1
const e=this.decreaseHpSpr.fillRange+this.deltaAmount
this.decreaseHpSpr.fillRange=e,this.increaseHpSpr.fillRange=e,this.repeatNowTime>=this.repeatLongTime&&this.StopTimer()}ShortTimeDecrease(){this.repeatNowTime+=1
const e=this.decreaseHpSpr.fillRange+this.deltaAmount
this.decreaseHpSpr.fillRange=e,this.increaseHpSpr.fillRange=e,this.repeatNowTime>=this.repeatShortTime&&this.StopTimer()}LongTimeIncrease(){this.repeatNowTime+=1
const e=this.topHpSpr.fillRange+this.deltaAmount
this.topHpSpr.fillRange=e,this.repeatNowTime>=this.repeatLongTime&&this.StopTimer()}ShortTimeIncrease(){this.repeatNowTime+=1
const e=this.topHpSpr.fillRange+this.deltaAmount
this.topHpSpr.fillRange=e,this.repeatNowTime>=this.repeatShortTime&&this.StopTimer()}GetAnimeHp(){return this.increaseHpSpr.fillRange*this.hpData.maxHp}StopTimer(){
0!=this.timeId&&(n.C.Inst_get().ClearInterval(this.timeId),this.timeId=0,this.repeatNowTime=0)}}},84459:(e,t,i)=>{"use strict"
i.d(t,{F:()=>n})
class n{constructor(e,t,i){this.maxHp=0,this.currentHp=0,this.lastHp=0,this.hpLength=1,this.deLength=0,null==i&&(i=-1),this.SetData(e,t,i)}SetData(e,t,i){null==i&&(i=-1),
this.maxHp=e,this.currentHp=t,this.lastHp=i,-1==i&&(this.lastHp=t),this.deLength=(e-t)/e*this.hpLength}}},85721:(e,t,i)=>{"use strict"
i.d(t,{Y:()=>a})
var n=i(5924),s=i(98130)
class a{constructor(){this.topHpSpt=null,this.tempHpSpt=null,this.maxHp=0,this.currentHp=0,this.lastHp=0,this.deLength=0,this.hpWidth=94,this.fillAmount=0,this.isInAnime=!1,
this.tempHp=0,this.longTimes=0,this.shortTimes=0,this.terminalAmount=0,this.singleMoveAmount=0,this.count=0,this.intervalId=-1,this._degf_LongTimeDecreaseSingleMove=null,
this._degf_LongTimeIncreaseSingleMove=null,this._degf_ShortTimeDecreaseSingleMove=null,this._degf_ShortTimeIncreaseSingleMove=null,
this._degf_LongTimeDecreaseSingleMove=()=>this.LongTimeDecreaseSingleMove(),this._degf_LongTimeIncreaseSingleMove=()=>this.LongTimeIncreaseSingleMove(),
this._degf_ShortTimeDecreaseSingleMove=()=>this.ShortTimeDecreaseSingleMove(),this._degf_ShortTimeIncreaseSingleMove=()=>this.ShortTimeIncreaseSingleMove()}Init(e,t,i,n,s){
this.topHpSpt=e,this.tempHpSpt=t,this.maxHp=i,this.currentHp=n,this.lastHp=s,-1==s&&(this.lastHp=n),this.deLength=(i-n)/i,this.topHpSpt.widthSet((1-this.deLength)*this.hpWidth),
this.tempHpSpt.widthSet((1-this.deLength)*this.hpWidth)}SetStyle(e,t){this.topHpSpt=e,this.tempHpSpt=t}UpdateHp(e,t,i,r){if(null==r&&(r=!0),
n.C.Inst_get().ClearInterval(this.intervalId),this.maxHp=e,this.currentHp=t,this.lastHp=i,this.terminalAmount=this.currentHp/this.maxHp,
this.terminalAmount>1&&(this.terminalAmount=1),!r)return this.isInAnime=!1,this.topHpSpt.widthSet(this.terminalAmount*this.hpWidth),
void this.tempHpSpt.widthSet(this.terminalAmount*this.hpWidth)
this.longTimes=s.GF.INT(a.PERIOD_LONG/a.INTERVAL*1e3),this.shortTimes=s.GF.INT(a.PERIOD_SHORT/a.INTERVAL*1e3),this.count=0,
this.isInAnime?this.currentHp-this.GetTempHp()<0?this.DecreaseHp():this.IncreaseHp():this.currentHp-this.lastHp<0?this.DecreaseHp():this.IncreaseHp()}DecreaseHp(){
this.isInAnime=!0,
this.topHpSpt.widthSet(this.terminalAmount*this.hpWidth),this.tempHpSpt.width()/this.hpWidth-this.terminalAmount>a.speedParam?(this.singleMoveAmount=(this.terminalAmount-this.tempHpSpt.width()/this.hpWidth)/this.longTimes,
this.intervalId=n.C.Inst_get().SetInterval(this._degf_LongTimeDecreaseSingleMove,a.INTERVAL,this.longTimes)):(this.singleMoveAmount=(this.terminalAmount-this.tempHpSpt.width()/this.hpWidth)/this.shortTimes,
this.intervalId=n.C.Inst_get().SetInterval(this._degf_ShortTimeDecreaseSingleMove,a.INTERVAL,this.shortTimes))}IncreaseHp(){this.isInAnime=!0,
this.tempHpSpt.widthSet(this.terminalAmount*this.hpWidth),
this.terminalAmount-this.topHpSpt.width()/this.hpWidth>a.speedParam?(this.singleMoveAmount=(this.terminalAmount-this.topHpSpt.width()/this.hpWidth)/this.longTimes,
this.intervalId=n.C.Inst_get().SetInterval(this._degf_LongTimeIncreaseSingleMove,a.INTERVAL,this.longTimes)):(this.singleMoveAmount=(this.terminalAmount-this.topHpSpt.width()/this.hpWidth)/this.shortTimes,
this.intervalId=n.C.Inst_get().SetInterval(this._degf_ShortTimeIncreaseSingleMove,a.INTERVAL,this.shortTimes))}LongTimeDecreaseSingleMove(){this.count+=1,
this.fillAmount=this.tempHpSpt.width()/this.hpWidth/this.hpWidth+this.singleMoveAmount,this.fillAmount>1&&(this.fillAmount=1),this.tempHpSpt.widthSet(this.fillAmount*this.hpWidth),
this.count>=this.longTimes&&(this.isInAnime=!1,n.C.Inst_get().ClearInterval(this.intervalId),this.count=0)}ShortTimeDecreaseSingleMove(){this.count+=1,
this.fillAmount=this.tempHpSpt.width()/this.hpWidth+this.singleMoveAmount,this.fillAmount>1&&(this.fillAmount=1),this.tempHpSpt.widthSet(this.fillAmount*this.hpWidth),
this.count>=this.shortTimes&&(this.isInAnime=!1,n.C.Inst_get().ClearInterval(this.intervalId),this.count=0)}LongTimeIncreaseSingleMove(){this.count+=1,
this.fillAmount=this.topHpSpt.width()/this.hpWidth+this.singleMoveAmount,this.fillAmount>1&&(this.fillAmount=1),this.topHpSpt.widthSet(this.fillAmount*this.hpWidth),
this.count>=this.longTimes&&(this.isInAnime=!1,n.C.Inst_get().ClearInterval(this.intervalId),this.count=0)}ShortTimeIncreaseSingleMove(){this.count+=1,
this.fillAmount=this.topHpSpt.width()/this.hpWidth+this.singleMoveAmount,this.fillAmount>1&&(this.fillAmount=1),this.topHpSpt.widthSet(this.fillAmount*this.hpWidth),
this.count>=this.shortTimes&&(this.isInAnime=!1,n.C.Inst_get().ClearInterval(this.intervalId),this.count=0)}GetTempHp(){return this.tempHpSpt.width()/this.hpWidth*this.maxHp}
Clear(){n.C.Inst_get().ClearInterval(this.intervalId),this.isInAnime=!1,this.topHpSpt&&null!=this.topHpSpt&&(this.topHpSpt.widthSet(1*this.hpWidth),
this.tempHpSpt.widthSet(1*this.hpWidth))}}a.PERIOD_LONG=1,a.PERIOD_SHORT=.5,a.INTERVAL=50,a.speedParam=.2},98863:(e,t,i)=>{"use strict"
i.d(t,{c:()=>l})
var n=i(18998),s=i(38045),a=i(98885),r=i(37322)
class l{constructor(e,t,i,n,s,a=null){this._numTxt=null,this._minusBtn=null,this._addBtn=null,this._maxBtn=null,this._min=1,this._max=0,this._num=0,this._deltaNum=1,
this._changeHandler=null,this.m_addLong=null,this.m_reduceLong=null,this._isCanChangeNum=!0,this.m_reduceTimeDistance=0,this.m_reduceStart=!1,this.m_reduceTime=0,
this.m_addTimeDistance=0,this.m_addStart=!1,this.m_addTime=0,this._degf_AddFrameHandler=null,this._degf_OnAddClick=null,this._degf_OnAddPress=null,this._degf_OnReduceClick=null,
this._degf_OnReducePress=null,this._degf_ReduceFrameHandler=null,this._degf_maxClickHandler=null,null==a&&(a=!0),this._degf_AddFrameHandler=()=>this.AddFrameHandler(),
this._degf_OnAddClick=()=>this.OnAddClick(),this._degf_OnAddPress=(e,t)=>this.OnAddPress(e,t),this._degf_OnReduceClick=()=>this.OnReduceClick(),
this._degf_OnReducePress=(e,t)=>this.OnReducePress(e,t),this._degf_ReduceFrameHandler=()=>this.ReduceFrameHandler(),this._degf_maxClickHandler=(e,t)=>this.maxClickHandler(e,t),
this._numTxt=t,this._minusBtn=i,this._addBtn=n,this._maxBtn=s,this._changeHandler=e,this._isCanChangeNum=a,this.m_addLong=new r.c(n,this._degf_OnAddClick,this._degf_OnAddPress),
this.m_addLong.needcheckMove=!1,this.m_addLong.frameHandler=this._degf_AddFrameHandler,this.m_reduceLong=new r.c(i,this._degf_OnReduceClick,this._degf_OnReducePress),
this.m_reduceLong.needcheckMove=!1,this.m_reduceLong.frameHandler=this._degf_ReduceFrameHandler,this.addListeners()}min_get(){return this._min}min_set(e){e=Math.floor(e),
this._min=e}max_get(){return this._max}max_set(e){e=Math.floor(e),this._max=e}num_get(){return this._num}num_set(e){e<this.min_get()&&(e=this.min_get()),e=Math.floor(e),
this._num=e,this._numTxt.textSet(`${(0,s.tw)(this._num)}`),null!=this._changeHandler&&this._changeHandler(this._num)}deltaNum_get(){return this._deltaNum}deltaNum_set(e){
e=Math.floor(e),this._deltaNum=e}ReduceFrameHandler(){this.m_reduceTime+=50,this.m_reduceStart&&this.m_reduceTime>this.m_reduceTimeDistance&&(this.m_reduceTime=0,
this.m_reduceTimeDistance>60&&(this.m_reduceTimeDistance-=60),this.OnReduceClick())}OnReduceClick(){
this._isCanChangeNum&&this.num_get()>this.min_get()&&(this.num_set(this.num_get()-this.deltaNum_get()),this.num_get()<this.min_get()&&this.num_set(this.min_get()))}
OnReducePress(e,t){t?(this.m_reduceStart=!0,this.m_reduceTimeDistance=360):this.m_reduceStart=!1}AddFrameHandler(){this.m_addTime+=50,
this.m_addStart&&this.m_addTime>this.m_addTimeDistance&&(this.m_addTime=0,this.m_addTimeDistance>60&&(this.m_addTimeDistance-=60),this.OnAddClick())}OnAddClick(){
this._isCanChangeNum&&this._num<this._max&&(this.num_set(this.num_get()+this.deltaNum_get()),this.num_get()>this.max_get()&&this.num_set(this.max_get()))}OnAddPress(e,t){
t?(this.m_addStart=!0,this.m_addTimeDistance=360):this.m_addStart=!1}init(){this.num_set(1)}addListeners(){this.m_addLong.AddEvent(),this.m_reduceLong.AddEvent(),
null!=this._maxBtn&&this._maxBtn.on(n.NodeEventType.TOUCH_END,this._degf_maxClickHandler,this)}removeListeners(){
null!=this._maxBtn&&this._maxBtn.on(n.NodeEventType.TOUCH_END,this._degf_maxClickHandler,this),null!=this.m_addLong&&this.m_addLong.Destory(),
null!=this.m_reduceLong&&this.m_reduceLong.Destory(),this.m_addLong=null,this.m_reduceLong=null}changeHandler(){let e=0
if(null==this._numTxt)return
const t=this._numTxt.string
""!=t&&(e=a.M.String2Int(t)),this._num!=e&&(e>this._max&&(e=this._max),e<this._min&&(e=this._min),this.num_set(e))}maxClickHandler(e,t){
this._min>this._max?this.num_set(this._min):this.num_set(this._max)}SetEnabled(e,t,i,n){null==n&&(n=!0),this._addBtn.active=e,this._minusBtn.active=t,this._numTxt.node.active=i,
null!=this._maxBtn&&(this._maxBtn.active=n)}}},93078:(e,t,i)=>{"use strict"
i.d(t,{F:()=>d})
var n=i(17409),s=i(49655),a=i(56937),r=i(18202),l=i(31222),o=i(5494),_=i(52726),u=i(79534)
class h{constructor(){this.inputCallback=null,this.closeCallback=null,this.inputPosition=null,this.inputWorldPos=null,this.inputText=null,this.min=0,this.max=0,this.useWorldPos=!1,
this.inputPosition=new u.P,this.inputWorldPos=new u.P}Clear(){this.useWorldPos=!1,this.inputCallback=null,this.closeCallback=null,this.inputPosition=u.P.zero_get(),
this.inputWorldPos=u.P.zero_get(),this.inputText=null,this.min=0,this.max=0}}var c=i(83466)
class d{constructor(){this.view=null,this.data=null,this._degf_CallDestory=null,this._degf_Complete=null,this.data=new h,this._degf_CallDestory=()=>this.CallDestory(),
this._degf_Complete=e=>this.Complete(e)}static Instance_get(){return null==d.inst&&(d.inst=new d),d.inst}OpenViewByLabel(e,t,i,r,l){
if(null!=this.view&&this.view.isShow_get())return
this.data.Clear(),this.data.inputPosition=e.Clone(),this.data.inputText=t,this.data.min=i,this.data.max=r,this.data.closeCallback=l
const o=new a.v
o.layerType=_.F.Msg,(0,n.Yp)(s.o.InputNumberView,o)}OpenViewByLabelWorld(e,t,i,r,l,o){if(null!=this.view&&this.view.isShow_get())return
this.data.Clear(),this.data.inputWorldPos=e.Clone(),this.data.inputPosition=t.Clone(),this.data.useWorldPos=!0,this.data.inputText=i,this.data.min=r,this.data.max=l,
this.data.closeCallback=o
const u=new a.v
u.layerType=_.F.Msg,(0,n.Yp)(s.o.InputNumberView,u)}OpenViewByNormal(e,t,i,r){if(null!=this.view&&this.view.isShow_get())return
this.data.Clear(),this.data.inputWorldPos=e.Clone(),this.data.inputPosition=t.Clone(),this.data.useWorldPos=!0,this.data.inputCallback=i,this.data.closeCallback=r
const l=new a.v
l.layerType=_.F.Msg,(0,n.Yp)(s.o.InputNumberView,l)}OpenView(e,t,i,r){if((0,n.Y)(s.o.InputNumberView))return
this.data.Clear(),null!=e&&(this.data.inputPosition=e),this.data.inputCallback=t,this.data.closeCallback=i,null!=r&&(this.data.inputWorldPos=r.Clone(),this.data.useWorldPos=!0)
let l=new a.v
l.layerType=_.F.Msg,(0,n.Yp)(s.o.InputNumberView,l)}OpenViewByWorld(e,t,i){if(null!=this.view&&this.view.isShow_get())return
this.data.Clear(),this.data.inputWorldPos=e.Clone(),this.data.inputPosition=t.Clone(),this.data.useWorldPos=!0,this.data.inputCallback=i
const n=new a.v
n.layerType=_.F.Msg,l.N.inst.OpenById(o.I.InputNumberPanel,this._degf_Complete,this._degf_CallDestory,n)}CallDestory(){r.g.DestroyUIObj(this.view),this.view=null}Complete(e){
return null==this.view&&(this.view=new c.X(null),this.view.setId(e,null,0)),this.view}CloseView(){(0,n.Y)(s.o.InputNumberView)&&(0,n.sR)(s.o.InputNumberView),
null!=this.data&&this.data.Clear()}}d.inst=null},83466:(e,t,i)=>{"use strict"
i.d(t,{X:()=>m})
var n,s=i(18998),a=i(6847),r=i(83908),l=i(49655),o=i(46282),_=i(38836),u=i(61911),h=i(98885),c=i(85602),d=i(93078)
let m=(0,a.s_)(l.o.InputNumberView,o.Z.ui_inputnumberpanel).layerPanel().register()(n=class extends((0,r.pA)(u.f)()){constructor(...e){super(...e),this.inputBtns=null,
this.isReplace=!1,this._degf_OnInput=null,this._degf_OnLayerMaskShow=null,this._degf_OnMask=null}_initBinder(){super._initBinder(),this._degf_OnInput=e=>this.OnInput(e),
this._degf_OnLayerMaskShow=e=>this.OnLayerMaskShow(e),this._degf_OnMask=(e,t)=>this.OnMask(e,t)}InitView(){this.inputBtns=new c.Z,this.inputBtns.Add(this.num0),
this.inputBtns.Add(this.num1),this.inputBtns.Add(this.num2),this.inputBtns.Add(this.num3),this.inputBtns.Add(this.num4),this.inputBtns.Add(this.num5),this.inputBtns.Add(this.num6),
this.inputBtns.Add(this.num7),this.inputBtns.Add(this.num8),this.inputBtns.Add(this.num9),this.inputBtns.Add(this.ClearBtn),this.inputBtns.Add(this.Ok)}OnAddToScene(){
this.AddListeners(),this.background.node.position=this.getOffsetPos(),this.isReplace=!0}getOffsetPos(){const e=d.F.Instance_get().data
return 0==e.useWorldPos?e.inputPosition:new s.Vec3(0,0,0)}Clear(){this.RemoveListeners()}Destroy(){null!=this.inputBtns&&(this.inputBtns.Clear(),this.inputBtns=null)}
AddListeners(){for(const[e,t]of(0,_.V5)(this.inputBtns))t.node.on(s.NodeEventType.TOUCH_END,this.OnInput,this)
this.mask.on(s.NodeEventType.TOUCH_END,this.OnMask,this)}OnLayerMaskShow(e){null!=d.F.Instance_get().data.closeCallback&&d.F.Instance_get().data.closeCallback(!1),
d.F.Instance_get().CloseView()}RemoveListeners(){for(const[e,t]of(0,_.V5)(this.inputBtns))t.node.off(s.NodeEventType.TOUCH_END,this.OnInput,this)
this.mask.off(s.NodeEventType.TOUCH_END,this.OnMask,this)}OnInput(e){let t=0
for(;t<this.inputBtns.Count();){if(this.inputBtns[t].node.name==e.target.name){this.HandleNum(t)
break}t+=1}}OnMask(e,t){this.HandleNum(12)}HandleNum(e){if(11==e||12==e){const t=11==e
null!=d.F.Instance_get().data.closeCallback&&d.F.Instance_get().data.closeCallback(t),d.F.Instance_get().CloseView()
}else if(null!=d.F.Instance_get().data.inputCallback)d.F.Instance_get().data.inputCallback(e,this.isReplace),10==e?this.isReplace=!0:this.isReplace&&(this.isReplace=!1)
else if(null!=d.F.Instance_get().data.inputText)if(10==e){const e=Math.max(0,d.F.Instance_get().data.min)
d.F.Instance_get().data.inputText.textSet(h.M.IntToString(e)),this.isReplace=!0}else{let t=d.F.Instance_get().data.inputText.text()
this.isReplace?(t=h.M.IntToString(e),this.isReplace=!1):t+=e
let i=h.M.String2Int(t)
i=Math.max(i,d.F.Instance_get().data.min),i=Math.min(i,d.F.Instance_get().data.max),d.F.Instance_get().data.inputText.textSet(h.M.IntToString(i))}}})||n},37325:(e,t,i)=>{
"use strict"
i.d(t,{r:()=>r})
var n=i(98885),s=i(38962),a=i(75439)
class r{constructor(){this.noHideMonsterIdDic=null,this.monsterStageDestroyDic={},this.killShowText="",this.noHideMonsterIdDic=new s.X,this.ParseCfg()}static Inst_get(){
return null==r.inst&&(r.inst=new r),r.inst}ParseCfg(){const e=a.D.getInstance().getContent("UI:AUTO_SHOW_DISPLAY").getContent().stringVal,t=n.M.Split(e,n.M.s_CCD_CHAR)
let i=0
if(null!=t)for(i=0;i<t.count;)this.noHideMonsterIdDic.LuaDic_AddOrSetItem(n.M.String2Int(t[0]),0),i+=1}IsShowByMonsterId(e){return this.noHideMonsterIdDic.LuaDic_ContainsKey(e)}}
r.inst=null},77845:(e,t,i)=>{"use strict"
i.d(t,{A:()=>T})
var n=i(38836),s=i(86133),a=i(98800),r=i(61033),l=i(35128),o=i(98130),_=i(85602),u=i(38962),h=i(3859),c=i(97331),d=i(26778),m=i(72439),p=i(57035),g=i(37648),I=i(55492),E=i(65550),C=i(85942),S=i(77477)
class T{static Inst_get(){return null==T.inst&&(T.inst=new T),T.inst}IsAttrEnough(e,t){null==t&&(t=!1)
const i=new u.X,r=a.Y.Inst.PrimaryRoleInfo_get(),l=new _.Z([0,0,0,0])
let c=0
if(e.cfgData_get().itemType==h.q.EQUIPMENT){const t=e.cfgEquipData_get().wearAttrLimitDic_get()
for(const[e,s]of(0,n.vy)(t))i.LuaDic_AddOrSetItem(e,t[e])
c=0}else{const t=e.cfgData_get().UseAttrLimitDic_get()
for(const[e,s]of(0,n.vy)(t))i.LuaDic_AddOrSetItem(e,t[e])
c=1,3==e.cfgData_get().whetherBatch&&(c=2)}let d=0
if(i[m.t.strengthLimit]=i[m.t.strengthLimit]+l[0],i[m.t.agilityLimit]=i[m.t.agilityLimit]+l[3],i[m.t.vitalityLimit]=i[m.t.vitalityLimit]+l[1],
i[m.t.intelligenceLimit]=i[m.t.intelligenceLimit]+l[2],d+=o.GF.INT(this.IsTakeOnAtr(r.Attributes_get()[S.Z.Strength],i[m.t.strengthLimit])),
d+=o.GF.INT(this.IsTakeOnAtr(r.Attributes_get()[S.Z.Agility],i[m.t.agilityLimit])),d+=o.GF.INT(this.IsTakeOnAtr(r.Attributes_get()[S.Z.Vitality],i[m.t.vitalityLimit])),
d+=o.GF.INT(this.IsTakeOnAtr(r.Attributes_get()[S.Z.Intelligence],i[m.t.intelligenceLimit])),d<=r.RemainBasePoint_get())return!0
if(t){let e=""
0==c?e+=(0,s.T)("该装备穿戴条件为\n"):1==c?e+=(0,s.T)("该道具使用条件为\n"):2==c&&(e+=(0,s.T)("该技能学习条件为\n")),
e+=this.GetAttrStr(m.t.strengthLimit,r.getAttribute(S.Z.Strength),i[m.t.strengthLimit]),e+=this.GetAttrStr(m.t.agilityLimit,r.getAttribute(S.Z.Agility),i[m.t.agilityLimit]),
e+=this.GetAttrStr(m.t.vitalityLimit,r.getAttribute(S.Z.Vitality),i[m.t.vitalityLimit]),
e+=this.GetAttrStr(m.t.intelligenceLimit,r.getAttribute(S.Z.Intelligence),i[m.t.intelligenceLimit]),e+=this.GetConditionStr(r,d-r.RemainBasePoint_get(),i)
const t=new C.N
t.titleText=(0,s.T)("属性不足"),t.showText=e,t.cancelText=(0,s.T)("取消"),t.tipstype=2,g.P.Inst_get().IsFunctionOpened(I.x.STRENGTHEN),t.okText=(0,s.T)("确定"),
E.y.inst.OpenCommonMessageTips(t)}return!1}StrengthenHandle(e){E.y.inst.closeCommonMessageTips()}GetAttrStr(e,t,i){let n=""
return 0!=i&&(n+=`${m.t.GetAttrNameByType(e)}：`,n+=t>=i?`[12ed26]${t}[-]/${i}`:`[de2524]${t}[-]/${i}`,n+="\n"),n}GetConditionStr(e,t,i,n){null==n&&(n=1)
let a=""
const _=r.l.GetInst().GetPlayerInitial(e.Job_get()),u=r.l.GetInst().GetLevelOfPoint(0)
let h=0
let E=0
if(g.P.Inst_get().IsFunctionOpened(I.x.ROLEADDPOINT))E=t,h=e.Level_get()+this.GetNeedLevel(E,_.levelOfPoint)
else{const t=p.d.Inst_get().GetOpenParamById(I.x.ROLEADDPOINT),n=c.n.Inst_get().GetDefaultRecommType(e.Job_get()),s=c.n.Inst_get().GetStandardAttrValList(n,t)
if(s[0]>=i[0]&&s[1]>=i[1]&&s[2]>=i[2]&&s[3]>i[3]){const t=d.q.Inst().GetItemByLevelAndJob(e.Level_get(),e.Job_get())
let n=0
if(i[0]>=e.getAttribute(S.Z.Strength)){const s=l.p.CeilToInt((i[0]-e.getAttribute(S.Z.Strength))*(1e4/t.strengthRatio)/u)
s>n&&(n=s)}if(i[1]>=e.getAttribute(S.Z.Agility)){const s=l.p.CeilToInt((i[1]-e.getAttribute(S.Z.Agility))*(1e4/t.agilityRatio)/u)
s>n&&(n=s)}if(i[2]>=e.getAttribute(S.Z.Vitality)){const s=l.p.CeilToInt((i[2]-e.getAttribute(S.Z.Vitality))*(1e4/t.spRatio)/u)
s>n&&(n=s)}if(i[3]>=e.getAttribute(S.Z.Intelligence)){const s=l.p.CeilToInt((i[3]-e.getAttribute(S.Z.Intelligence))*(1e4/t.intelligenceRatio)/u)
s>n&&(n=s)}h=e.Level_get()+n}else{const n=u*(t-e.Level_get())
let a=o.GF.INT(this.IsTakeOnAtr(s[0],i[m.t.strengthLimit]))
a+=o.GF.INT(this.IsTakeOnAtr(s[1],i[m.t.agilityLimit])),a+=o.GF.INT(this.IsTakeOnAtr(s[2],i[m.t.vitalityLimit])),a+=o.GF.INT(this.IsTakeOnAtr(s[3],i[m.t.intelligenceLimit])),E=n+a,
h=t+this.GetNeedLevel(a,_.levelOfPoint)}}1==n?a=(0,s.T)("再升[12ed26]")+(h-e.Level_get()+(0,s.T)("级[-]可以获得足够的点数")):2==n&&(a=(0,s.T)("再升[12ed26]")+(h-e.Level_get()+(0,s.T)("级[-]")))
const C=r.l.GetInst().GetPlayerInitial(e.Job_get())
return a+=(0,s.T)("\n（每级可获得[12ed26]")+(C.levelOfPoint+(0,s.T)("点[-]剩余点数）")),a}GetNeedLevel(e,t){let i=0
return e<=0?0:(i=e%t==0?e/t:(e-e%t)/t+1,i)}GetTransLevelStr(e){return 1==e?(0,s.T)("[12ed26]一转[-]"):2==e?(0,s.T)("[12ed26]二转[-]"):3==e?(0,s.T)("[12ed26]三转[-]"):4==e?(0,
s.T)("[12ed26]四转[-]"):""}IsTakeOnAtr(e,t){return e>=t?0:t-e}}T.inst=null},85751:(e,t,i)=>{"use strict"
i.d(t,{u:()=>l})
var n=i(98885),s=i(85602),a=i(38962),r=i(88653)
class l{static __StaticInit(){l.QUALITY_ANI_URL.LuaDic_AddOrSetItem(l.YELLOWINDEX,"mod_eff_icontips_orange_1_01"),
l.QUALITY_ANI_URL.LuaDic_AddOrSetItem(l.REDINDEX,"mod_eff_icontips_red_1_01"),l.QUALITY_ANI_URL.LuaDic_AddOrSetItem(l.PINKINDEX,"mod_eff_icontips_pink_1_01")}
static getColorByQuality(e){return(e>=l.qualityColors.count||e<0)&&(e=0),l.qualityColors[e]}static getColorStrByQuality(e){return(e>=l.qualityColorStrs.count||e<0)&&(e=0),
l.qualityColorStrs[e]}static getColorByBrightQuality(e){return(e>=l.BrightqualityColors.count||e<0)&&(e=0),l.BrightqualityColors[e]}static getColorStrsByBrightQuality(e){
return(e>=l.BrightqualityColorStrs.count||e<0)&&(e=0),l.BrightqualityColorStrs[e]}static getSpecialColorByQuality(e){return(e>=l.specialQualityColors.count||e<0)&&(e=0),
l.specialQualityColors[e]}static getSpecialColorStrByQuality(e){return(e>=l.specialQualityColorStrs.count||e<0)&&(e=0),l.specialQualityColorStrs[e]}static getDropColorByQuality(e){
return(e>=l.DropQualityColors.count||e<0)&&(e=0),l.DropQualityColors[e]}getDropColorStrByQuality(e){return(e>=l.DropQualityColorStrs.count||e<0)&&(e=0),l.DropQualityColorStrs[e]}
static GetColorByHexStr(e){const t=parseInt("0x"+e.substring(0,2)),i=parseInt("0x"+e.substring(2,4)),n=parseInt("0x"+e.substring(4,6))
return new r.I(t/255,i/255,n/255,1)}static GetColorByHexStrRBGA(e){if(!e||e.length<9)return
const t=parseInt(e.slice(1,3),16),i=parseInt(e.substring(3,5),16),n=parseInt(e.substring(5,7),16),s=parseInt(e.substring(7,9),16)
return new r.I(t,i,n,s)}static GetqualityStrWithChar(e){return n.M.s_LEFT_M_K_CHAR+(l.getColorStrByQuality(e)+n.M.s_RIGHT_M_K_CHAR)}GetcolorstrWithChar(e){
return n.M.s_LEFT_M_K_CHAR+(e+n.M.s_RIGHT_M_K_CHAR)}static SetStringColor(e,t){
return`${n.M.s_LEFT_M_K_CHAR}${e}${n.M.s_RIGHT_M_K_CHAR}${t}${n.M.s_LEFT_M_K_CHAR}-${n.M.s_RIGHT_M_K_CHAR}`}static GetColorString(e,t){return e+(t+l.EndSymbol)}
static SetStringColorByQuality(e,t){return l.SetStringColor(l.getColorStrByQuality(e),t)}static SetStringColorByBrightQuality(e,t){
return l.SetStringColor(l.getColorStrsByBrightQuality(e),t)}static DesaturateDesc(e){return e}}l.UNKNOW_COLORINDEX=-1,l.WHITEINDEX=0,l.BLUEINDEX=1,l.GREENINDEX=2,l.PURPLEINDEX=3,
l.YELLOWINDEX=4,l.REDINDEX=5,l.PINKINDEX=6,l.MAXQUALITYINDEX=7,l.EndSymbol="[-]",l.BtnColorYellow=new r.I(233/255,213/255,149/255),l.BtnColorYellowStr="E9D595",
l.BtnColorYellowStr2="[E9D595]",l.BtnColorSienna=new r.I(109/255,83/255,49/255),l.BtnColorSiennaStr="6D5331",l.BtnColorSiennaStr2="[6D5331]",l.WhiteColor=new r.I(1,1,1,1),
l.WhiteColorStr="FFFFFF",l.WhiteColorStr2="[FFFFFF]",l.SiennaColor=new r.I(73/255,54/255,47/255,1),l.SiennaColorStr="49362F",l.SiennaColorStr2="[49362F]",
l.BrownColor=new r.I(68/255,60/255,56/255,1),l.BrownColorStr="443C38",l.BrownColorStr2="[443C38]",l.YellowColor=new r.I(140/255,79/255,0,1),l.YellowColorStr="8C4F00",
l.YellowColorStr2="[8C4F00]",l.GreenColor=new r.I(4/255,113/255,7/255,1),l.GreenColorStr="047104",l.GreenColorStr2="[047104]",l.RedColor=new r.I(150/255,36/255,36/255,1),
l.RedColorStr="962424",l.RedColorStr2="[962424]",l.GrayColor=new r.I(99/255,91/255,87/255,1),l.GrayColorStr="635B57",l.GrayColorStr2="[635B57]",l.BrightWhiteColor=new r.I(1,1,1,1),
l.BrightWhiteColorStr="FFFFFF",l.BrightWhiteColorStr2="[FFFFFF]",l.BrightGrayColor=new r.I(149/255,150/255,142/255,1),l.BrightGrayColorStr="95968E",
l.BrightGrayColorStr2="[95968E]",l.BrightWheatColor=new r.I(196/255,178/255,161/255,1),l.BrightWheatColorStr="C4B2A1",l.BrightWheatColorStr2="[C4B2A1]",
l.BrightBlueColor=new r.I(146/255,202/255,1,1),l.BrightBlueColorStr="92CAFF",l.BrightBlueColorStr2="[92CAFF]",l.BrightGreenColor=new r.I(95/255,180/255,112/255,1),
l.BrightGreenColorStr="5FB470",l.BrightGreenColorStr2="[5FB470]",l.BrightRedColor=new r.I(1,75/255,88/255,1),l.BrightRedColorStr="FF4B58",l.BrightRedColorStr2="[FF4B58]",
l.BrightCyanColor=new r.I(105/255,188/255,188/255,1),l.BrightCyanColorStr="69BCBC",l.BrightCyanColorStr2="[69BCBC]",l.BrightGoldColor=new r.I(232/255,200/255,104/255,1),
l.BrightGoldColorStr="E8C868",l.BrightGoldColorStr2="[E8C868]",l.BrightYellowColor=new r.I(219/255,169/255,104/255,1),l.BrightYellowColorStr="DBA968",
l.BrightYellowColorStr2="[DBA968]",l.NPCNameColor=new r.I(105/255,189/255,188/255,1),l.RoleNameColor=new r.I(219/255,169/255,134/255,1),
l.PlayerNameColor=new r.I(95/255,180/255,112/255,1),l.LowMonsterNameColor=new r.I(196/255,178/255,161/255,1),l.NormalMonsterNameColor=new r.I(.8,203/255,196/255,1),
l.HightMonsterNameColor=new r.I(.8,203/255,196/255,1),l.quality0=new r.I(1,1,1,1),l.qualityStr0="FFFFFF",l.quality1=new r.I(15/255,.4,200/255,1),l.qualityStr1="0F66C8",
l.quality2=new r.I(4/255,113/255,4/255,1),l.qualityStr2="047104",l.quality3=new r.I(137/255,53/255,180/255,1),l.qualityStr3="8935B4",l.quality4=new r.I(140/255,79/255,0,1),
l.qualityStr4="8C4F00",l.quality5=new r.I(150/255,36/255,36/255,1),l.qualityStr5="962424",l.quality6=new r.I(178/255,64/255,150/255,1),l.qualityStr6="B24096",
l.qualityColors=new s.Z([l.quality0,l.quality1,l.quality2,l.quality3,l.quality4,l.quality5,l.quality6]),
l.qualityColorStrs=new s.Z([l.qualityStr0,l.qualityStr1,l.qualityStr2,l.qualityStr3,l.qualityStr4,l.qualityStr5,l.qualityStr6]),l.Brightquality0=new r.I(1,1,1,1),
l.BrightqualityStr0="FFFFFF",l.Brightquality1=new r.I(146/255,202/255,1,1),l.BrightqualityStr1="92CAFF",l.Brightquality2=new r.I(95/255,180/255,112/255,1),
l.BrightqualityStr2="5FB470",l.Brightquality3=new r.I(199/255,171/255,1,1),l.BrightqualityStr3="C7ABFF",l.Brightquality4=new r.I(219/255,169/255,104/255,1),
l.BrightqualityStr4="DBA968",l.Brightquality5=new r.I(1,75/255,88/255,1),l.BrightqualityStr5="FF4B58",l.Brightquality6=new r.I(1,95/255,193/255,1),l.BrightqualityStr6="FF5FC1",
l.BrightqualityColors=new s.Z([l.Brightquality0,l.Brightquality1,l.Brightquality2,l.Brightquality3,l.Brightquality4,l.Brightquality5,l.Brightquality6]),
l.BrightqualityColorStrs=new s.Z([l.BrightqualityStr0,l.BrightqualityStr1,l.BrightqualityStr2,l.BrightqualityStr3,l.BrightqualityStr4,l.BrightqualityStr5,l.BrightqualityStr6]),
l.specialQuality0=new r.I(1,1,1,1),l.specialQualityStr0="FFFFFF",l.specialQuality1=new r.I(15/255,.4,200/255,1),l.specialQualityStr1="0F66C8",
l.specialQuality2=new r.I(4/255,113/255,4/255,1),l.specialQualityStr2="047104",l.specialQuality3=new r.I(137/255,53/255,180/255,1),l.specialQualityStr3="8935B4",
l.specialQuality4=new r.I(140/255,79/255,0,1),l.specialQualityStr4="8C4F00",l.specialQuality5=new r.I(150/255,36/255,36/255,1),l.specialQualityStr5="962424",
l.specialQuality6=new r.I(178/255,64/255,150/255,1),l.specialQualityStr6="B24096",
l.specialQualityColors=new s.Z([l.specialQuality0,l.specialQuality1,l.specialQuality2,l.specialQuality3,l.specialQuality4,l.specialQuality5,l.specialQuality6]),
l.specialQualityColorStrs=new s.Z([l.specialQualityStr0,l.specialQualityStr1,l.specialQualityStr2,l.specialQualityStr3,l.specialQualityStr4,l.specialQualityStr5,l.specialQualityStr6]),
l.dropQuality0=new r.I(1,1,1,1),l.dropQualityStr0="FFFFFF",l.dropQuality1=new r.I(146/255,202/255,1,1),l.dropQualityStr1="92CAFF",l.dropQuality2=new r.I(142/255,226/255,178/255,1),
l.dropQualityStr2="5FB470",l.dropQuality3=new r.I(199/255,171/255,1,1),l.dropQualityStr3="C7ABFF",l.dropQuality4=new r.I(219/255,169/255,104/255,1),l.dropQualityStr4="DBA968",
l.dropQuality5=new r.I(1,75/255,88/255,1),l.dropQualityStr5="FF4B58",l.dropQuality6=new r.I(1,95/255,193/255,1),l.dropQualityStr6="FF5FC1",
l.DropQualityColors=new s.Z([l.dropQuality0,l.dropQuality1,l.dropQuality2,l.dropQuality3,l.dropQuality4,l.dropQuality5,l.dropQuality6]),
l.DropQualityColorStrs=new s.Z([l.dropQualityStr0,l.dropQualityStr1,l.dropQualityStr2,l.dropQualityStr3,l.dropQualityStr4,l.dropQualityStr5,l.dropQualityStr6]),
l.QUALITY_ANI_URL=new a.X},73423:(e,t,i)=>{"use strict"
i.d(t,{B:()=>h})
var n=i(17409),s=i(56937),a=i(5494),r=i(52726),l=i(98789),o=i(65801),_=i(49655),u=i(79534)
class h{constructor(){this.effList=null,this.vo=null}static Inst(){return null==h._inst&&(h._inst=new h),h._inst}PlayEffect(e,t,i,s,r,l,_,h,c,d){const m=(0,n.Y)(a.I.FLYEFFVIEW)
return t=new u.P(0,0,0),i=new u.P(0,0,0),this.vo=new o.x(e,t,i,s,r,l,_,h,c,d),null!=m&&m.isShow_get()?m.PlayEffect():(this.OpenInitView(),-1)}ClearEffect(e){const t=(0,
n.Y)(a.I.FLYEFFVIEW)
if(null!=t&&null!=e)return t.ClearEffect(e)}OpenInitView(){const e=new s.v
e.layerType=r.F.Effect,e.positionType=l.$.eCenter,e.viewClass="CommonFlyEffPanel",(0,n.Yp)(_.o.FLYEFFVIEW,e)}S_Test(){return!0}}h._inst=null},87923:(e,t,i)=>{"use strict"
i.d(t,{l:()=>Ie})
var n,s,a=i(92984),r=i(99535),l=i(38836),o=i(86133),_=i(38045),u=i(98800),h=i(28236),c=i(68662),d=i(71530),m=i(62370),p=i(66788),g=i(35128),I=i(98130),E=i(98885),C=i(85602),S=i(38962),T=i(88653),f=i(14772),A=i(59918),y=i(3859),R=i(75321),D=i(57035),w=i(37648),L=i(55492),v=i(33833),O=i(75439),P=i(68561),N=i(33138),M=i(10509),b=i(38486),G=i(89799),U=i(29843),B=i(77191),k=i(41864),F=i(63076),H=i(75363),x=i(2457),V=i(65550),Y=i(77477),W=i(33314),K=i(85751),Z=i(42292),z=i(73136),q=i(70829),$=i(5924),X=i(95721),Q=i(2372),j=i(51262),J=i(79534),ee=i(18998),te=(i(22267),
i(17409)),ie=i(49655),ne=i(26034),se=i(67493),ae=i(38935),re=i(48933),le=i(73896),oe=i(27564),_e=i(43366),ue=i(68637),he=i(83836),ce=i(61546),de=i(77697),me=i(35259),pe=i(84141)
class ge{static getMapMatrix(e){let t=ge.config[e.toString()]
if(t)return new ee.Mat4(t[0],t[4],t[8],t[12],t[1],t[5],t[9],t[13],t[2],t[6],t[10],t[14],t[3],t[7],t[11],t[15])}static getMapHeight(e){return ge.config[e.toString()][16]}
static getMapCameraOrtSize(e){return ge.config[e.toString()][17]}}ge.config={
10001:[.00265165023,0,-.00265165069,-.0128074987,.00309269223,.00503139757,.00309269154,-.87213105,.00106764084,-.00131251162,.00106764073,-.5380971,0,0,0,1,10.263,150],
10003:[.00795495,0,-.007954951,.06037808,.009278076,.0150941918,.009278074,-1.06231678,.00106764084,-.00131251162,.00106764073,-.906333447,0,0,0,1,1.652,50],
10004:[.003977475,0,-.00397747569,.02903549,.004639038,.007547096,.004639037,-.695240438,.00106764084,-.00131251162,.00106764073,-.3970297,0,0,0,1,1.652,100],
10005:[.00795495,0,-.007954951,-.183759555,.009278076,.0150941918,.009278074,-.7614276,.00106764084,-.00131251162,.00106764073,-.3246436,0,0,0,1,1.522,50],
10002:[.003977475,0,-.00397747569,.0182964038,.004639038,.007547096,.004639037,-.932848632,.00106764084,-.00131251162,.00106764073,-.9103463,0,0,0,1,2.185,100],
10006:[.003977475,0,-.00397747569,-.004772991,.004639038,.007547096,.004639037,-.5255411,.00106764084,-.00131251162,.00106764073,-.8166075,0,0,0,1,2.546,100],
10008:[.00795495,0,-.007954951,-.0572756939,.009278076,.0150941918,.009278074,-.730060935,.00106764084,-.00131251162,.00106764073,-.779667139,0,0,0,1,2.299,50],
10012:[.003977475,0,-.00397747569,-.17779316,.004639038,.007547096,.004639037,-.5046655,.00106764084,-.00131251162,.00106764073,-.8118031,0,0,0,1,2.299,100],
10013:[.003977475,0,-.00397747569,-.078356266,.004639038,.007547096,.004639037,-.8052751,.00106764084,-.00131251162,.00106764073,-.8809862,0,0,0,1,2.483,100],
10014:[.00265165023,0,-.00265165069,.0331456549,.00309269223,.00503139757,.00309269154,-.8276185,.00106764084,-.00131251162,.00106764073,-.9929514,0,0,0,1,2.101,150],
10015:[.003977475,0,-.00397747569,-.169042736,.004639038,.007547096,.004639037,-.8629589,.00106764084,-.00131251162,.00106764073,-.6542723,0,0,0,1,3.6,100],
11015:[.003977475,0,-.00397747569,-.162917376,.004639038,.007547096,.004639037,-.8473048,.00106764084,-.00131251162,.00106764073,-.890659034,0,0,0,1,3.6,100],
10016:[.00265165023,0,-.00265165069,-.008220109,.00309269223,.00503139757,.00309269154,-.638909,.00106764084,-.00131251162,.00106764073,-.91621834,0,0,0,1,1.881,150],
10017:[.00265165023,0,-.00265165069,.0259861853,.00309269223,.00503139757,.00309269154,-.800315142,.00106764084,-.00131251162,.00106764073,-.9890148,0,0,0,1,2.505,150],
10018:[.003977475,0,-.00397747569,.0799472556,.004639038,.007547096,.004639037,-.628063858,.00106764084,-.00131251162,.00106764073,-.840202332,0,0,0,1,1.87,100],
11018:[.003977475,0,-.00397747569,.09705035,.004639038,.007547096,.004639037,-.694111645,.00106764084,-.00131251162,.00106764073,-.590103149,0,0,0,1,1.87,100],
10019:[.003977475,0,-.00397747569,-.299901634,.004639038,.007547096,.004639037,-1.071092,.00106764084,-.00131251162,.00106764073,-.942162037,0,0,0,1,2.22,100],
11019:[.00265165023,0,-.00265165069,-.0662912652,.00309269223,.00503139757,.00309269154,-.4712342,.00106764084,-.00131251162,.00106764073,-.8851696,0,0,0,1,2.22,150],
10020:[.00265165023,0,-.00265165069,-.04375223,.00309269223,.00503139757,.00309269154,-.689218342,.00106764084,-.00131251162,.00106764073,-.803375661,0,0,0,1,1.4,150],
10021:[.003977475,0,-.00397747569,-.06562834,.004639038,.007547096,.004639037,-.9628848,.00106764084,-.00131251162,.00106764073,-.8157132,0,0,0,1,2.3,100],
11020:[.003977475,0,-.00397747569,.003977477,.004639038,.007547096,.004639037,-1.05614328,.00106764084,-.00131251162,.00106764073,-.832296968,0,0,0,1,1.4,100],
11021:[.003977475,0,-.00397747569,-.0175008923,.004639038,.007547096,.004639037,-.9655082,.00106764084,-.00131251162,.00106764073,-.8379374,0,0,0,1,2.3,100],
10025:[.003977475,0,-.00397747569,-.0175008923,.004639038,.007547096,.004639037,-.7276993,.00106764084,-.00131251162,.00106764073,-.879294634,0,0,0,1,3.1,100],
10027:[.00795495,0,-.007954951,-.221943125,.009278076,.0150941918,.009278074,-.9273292,.00106764084,-.00131251162,.00106764073,-.8811641,0,0,0,1,5.11,50],
11025:[.003977475,0,-.00397747569,.0465364642,.004639038,.007547096,.004639037,-.7284262,.00106764084,-.00131251162,.00106764073,-.9093463,0,0,0,1,3.1,100],
11027:[.00795495,0,-.007954951,-.227511615,.009278076,.0150941918,.009278074,-.9621926,.00106764084,-.00131251162,.00106764073,-.876820445,0,0,0,1,5.11,50],
10026:[.00265165023,0,-.00265165069,.01776606,.00309269223,.00503139757,.00309269154,-.819333,.00106764084,-.00131251162,.00106764073,-.812919736,0,0,0,1,8.1,150],
10028:[.00265165023,0,-.00265165069,.01776606,.00309269223,.00503139757,.00309269154,-.6593346,.00106764084,-.00131251162,.00106764073,-.85465765,0,0,0,1,8.13,150],
11026:[.00265165023,0,-.00265165069,-.05091169,.00309269223,.00503139757,.00309269154,-.8177221,.00106764084,-.00131251162,.00106764073,-.7647927,0,0,0,1,8.1,150],
11028:[.003977475,0,-.00397747569,-.213192716,.004639038,.007547096,.004639037,-1.04360437,.00106764084,-.00131251162,.00106764073,-.73213464,0,0,0,1,8.13,100],
20001:[.00795495,0,-.007954951,.015909791,.009278076,.0150941918,.009278074,-.759502232,.00106764084,-.00131251162,.00106764073,-.6226554,0,0,0,1,10.129,50],
20002:[.00795495,0,-.007954951,-.07636757,.009278076,.0150941918,.009278074,-.6150127,.00106764084,-.00131251162,.00106764073,-.766428351,0,0,0,1,1.82,50],
20006:[.003977475,0,-.00397747569,-.0743788,.004639038,.007547096,.004639037,-.411884725,.00106764084,-.00131251162,.00106764073,-.7904503,0,0,0,1,.82,100],
20010:[.00795495,0,-.007954951,-.0151144294,.009278076,.0150941918,.009278074,-.83335197,.00106764084,-.00131251162,.00106764073,-.8604699,0,0,0,1,8.73,50],
20023:[.00795495,0,-.007954951,.015909791,.009278076,.0150941918,.009278074,-.374600142,.00106764084,-.00131251162,.00106764073,-.6561245,0,0,0,1,2.6,50],
20016:[.00795495,0,-.007954951,.015909791,.009278076,.0150941918,.009278074,-.374600142,.00106764084,-.00131251162,.00106764073,-.6561245,0,0,0,1,1.11,50],
20014:[.00795495,0,-.007954951,.0509116724,.009278076,.0150941918,.009278074,-.438728869,.00106764084,-.00131251162,.00106764073,-.8687298,0,0,0,1,3.1,50],
20009:[.00795495,0,-.007954951,-.0803450346,.009278076,.0150941918,.009278074,-.942044258,.00106764084,-.00131251162,.00106764073,-.7464263,0,0,0,1,.3,50],
20040:[.003977475,0,-.00397747569,.01380181,.004639038,.007547096,.004639037,-.8297246,.00106764084,-.00131251162,.00106764073,-.636865556,0,0,0,1,2.33,100],
10023:[.003977475,0,-.00397747569,.0213589873,.004639038,.007547096,.004639037,-.6400502,.00106764084,-.00131251162,.00106764073,-.6734131,0,0,0,1,.889,100],
20015:[.00795495,0,-.007954951,.0310242735,.009278076,.0150941918,.009278074,-.339246124,.00106764084,-.00131251162,.00106764073,-.7508575,0,0,0,1,5.08,50],
20017:[.00795495,0,-.007954951,.0310242735,.009278076,.0150941918,.009278074,-.339246124,.00106764084,-.00131251162,.00106764073,-.7508575,0,0,0,1,3.45,50],
20018:[.00795495,0,-.007954951,-.0670602843,.009278076,.0150941918,.009278074,-.376221418,.00106764084,-.00131251162,.00106764073,-.726142764,0,0,0,1,3.12,50]}
let Ie=(0,Z.Y_)("GameSys.CommonUtil")((s=class e{static ExcellenceColorLevel_get(){if(null==e.excellenceColorLevel){
const t=O.D.getInstance().getContent("EQUIPMENT:EQUIP_COLOR_RULE").getContent()
e.excellenceColorLevel=new C.Z
let i=0
for(;i<t.arrayVal.count;){const n=E.M.String2Int(t.arrayVal[i])
e.excellenceColorLevel.Add(n),i+=1}}return e.excellenceColorLevel}static IsRyMonIcon(t){return E.M.StartsWith(t,e.RY_MON_ICON_PRE)}static DealRyMonIcon(t,i,n){
E.M.StartsWith(t,e.RY_MON_ICON_PRE)?(n.spriteNameSet(t),n.node.SetActive(!0),i.node.SetActive(!1)):(n.node.SetActive(!1),i.spriteNameSet(t),i.node.SetActive(!0))}
static GetEquipExcellenSp(e){e.GetEquipInfo()
return`beibao_nb_000${e.ExcellenceCount_get()+1}`}static GetEquipBgColor(t){const i=t.GetEquipRes(),n=t.GetItemRes().Quality_get()
if(i.equipType==A.R.ASURAMFLAG)return n
if(i.equipType==A.R.GUARD)return n
const s=t.GetEquipInfo()
if(!P.X.Inst_get().IsSpecialRing(t,s)){
const i=P.X.Inst_get().IsEquipHasLucky(t,s,null),n=P.X.Inst_get().GetEquipExcellenceCount(t,s),a=P.X.Inst_get().GetEquipStarLevel(t,s),r=P.X.Inst_get().GetEquipEnhanceLevel(t,s,null),l=P.X.Inst_get().GetEquipSuitProperty(t,s),o=P.X.Inst_get().GetEquipGodType(t,s)
return e.GetEquipQualityColor(n,a,i,r,l,o)}return n}static GetQualitySortValue(t){return null==t||null==t.cfgData_get()?0:e.GetQuality(t)}static GetQuality(t,i=-1,n=-1){
if(null==t)return 0
if(null==t.cfgData_get())return 0
if(t.cfgData_get().itemType==y.q.EQUIPMENT){const s=t.serverData_get(),a=t.equipInfo_get()
let r=e.getEquipQuality(s,a,i,n)
return-1==r&&(r=t.cfgData_get().Quality_get()),r}return t.cfgData_get().Quality_get()}static getEquipQuality(e=null,t=null,i=null,n=null){null==n&&(n=-1),null==i&&(i=-1)
let s=-1
if(null!=t&&null!=t.Config_get()&&t.Config_get().equipType!=A.R.GUARD){const e=N.f.Inst().getItemById(t.Config_get().id)
null!=e?s=e.Quality_get():t.isSpecialRing()||t.IsGodEquip()&&(s=K.u.PURPLEINDEX)}return s}static GetEquipQualityColor(e,t,i,n,s,a){return 0}static getColorByQuality(e){
return K.u.getColorByQuality(e)}static getColorStrByQuality(e){return K.u.getColorStrByQuality(e)}static getDropColorByQuality(e){return K.u.getDropColorByQuality(e)}
static getSpecialColorByQuality(e){return K.u.getSpecialColorByQuality(e)}static getSpecialColorStrByQuality(e){return K.u.getSpecialColorStrByQuality(e)}
static GetColorByHexStr(e){return K.u.GetColorByHexStr(e)}static GetqualityStrWithChar(e){return K.u.GetqualityStrWithChar(e)}static SetStringColorByQuality(e,t){
return K.u.SetStringColorByQuality(e,t)}static SetStringColor(e,t){return K.u.SetStringColor(e,t)}static GetQualityColorStr(e,t){return K.u.SetStringColorByQuality(e,t)}
static GetBagItemName(t){const i=t.cfgData_get().name,n=e.GetSuitPrefix(t)
let s=""
return s=e.IsEmptyStr(n)?i:n+(E.M.s_SPACE_CHAR+i),s}static GetSuitPrefix(e){let t=null,i=null
e.isEquip_get()&&(t=e.serverData_get(),i=t.GetEquipInfo())
e.cfgData_get().name
return null!=t||null!=i&&i.EquipShowConfig_get(),""}static SetGodMasterPrefix(e,t=null,i=null,n=null){let s=e,a=null
return null!=t&&null!=t.GetEquipRes()?a=t.GetEquipRes():null!=i&&null!=i.Config_get()?a=i.Config_get():null!=n&&(a=n),null==a||a.IsAngelEquip()||(a.IsGodEquip()?s=(0,
o.T)("神·")+s:a.IsMasterEquip()&&(1==a.jobBranch?s=(0,o.T)("【力】大师·")+s:2==a.jobBranch?s=(0,o.T)("【智】大师·")+s:3==a.jobBranch&&(s=(0,o.T)("【敏】大师·")+s))),s}static GetItemShowName(t,i){
return null!=t?t.isEquip_get()&&null!=t.serverData_get()?e.GetEquipName(t.serverData_get(),!0,null,null,null,null,i):e.GetItemNameWithQuCollor(t,t.cfgData_get(),i):""}
static SetUnderLineStr(e){return`[u]${e}[/u]`}static GetItemNameWithQuCollor(t,i,n){let s=null
return s=null!=i?i.name:t.cfgData_get().name,null!=n&&n&&(s=`[${s}]`),t?`${e.GetqualityStrWithChar(t.Quality_get())}${s}[-]`:`${e.GetqualityStrWithChar(i.Quality_get())}${s}[-]`}
static GetEquipName(t,i,n,s,a,r,l){if(null==t)return""
return e.SetEquipName(t.GetEquipInfo(),t.GetItemRes(),t,n,i,s,a,r,l)[0]}static SetEquipName(t,i,n,s,a,r,l,o,_,u,h,c,d,m,p){null==o&&(o=!0),null==l&&(l=0),null==r&&(r=!0),
null==a&&(a=!0),null==c&&(c=!1),null==d&&(d=E.M.s_SPACE_CHAR)
let g=e.getEquipQuality(n,t);-1==g&&(g=i.Quality_get())
P.X.Inst_get().IsEquipHasLucky(n,t,p)
const S=P.X.Inst_get().GetEquipExcellenceCount(n,t)+l,T=(P.X.Inst_get().GetEquipStarLevel(n,t),P.X.Inst_get().GetEquipEnhanceLevel(n,t,p))
P.X.Inst_get().GetEquipSuitProperty(n,t),P.X.Inst_get().IsSpecialRing(n,t),P.X.Inst_get().GetEquipGodType(n,t)
let f=i.name
if(null!=n&&(f=n.GetItemRes().name),f=e.SetGodMasterPrefix(f,n,t,null),null==s||null!=n&&0!=n.GetEquipRes().suitId){const t=""
e.IsEmptyStr(t)||(f=h?t+(E.M.s_NN_CHAR+f):r?t+(E.M.s_SPACE_CHAR+f):t+f)}else{const e=s.GetSuitRes()
f=m?e.suitPrefix+f:e.suitPrefix+(E.M.s_NN_CHAR+f),g=s.GetItemRes().quality}S>0&&(f=e.GetExcellentPre(S,d)+f)
const A=g
let y=""
y=c?K.u.getColorStrsByBrightQuality(A):e.getColorStrByQuality(A)
let D="",w=""
null!=n?0!=T&&o?(D=`${f} +${T}`,w=`+${T}`):(D=f,w=""):null!=t.EquipShowConfig_get()&&0!=t.EquipShowConfig_get().enhanceLv&&o?(D=`${f} +${t.EquipShowConfig_get().enhanceLv}`,
w=`+${t.EquipShowConfig_get().enhanceLv}`):(D=f,w=""),t.Config_get().intPosition_get()!=I.GF.INT(R.C.GUARD)||c||(y=e.getColorStrByQuality(i.Quality_get())),null!=u&&(y=u),
null!=_&&_&&(D=`[${D}]`)
const L=D
a&&(D=e.SetStringColor(y,D))
const v=new C.Z
return v.Add(D),v.Add(w),a||v.Add(y),v.Add(L),v}static SetEquipNameWithoutServerItem(t,i,n,s){null==s&&(s=!0),null==n&&(n=!0)
const a=t.Quality_get(),r=t.ExcellenceNum,l=t.starExcellence
i.suitId
let o=t.name
r>0&&(o=e.GetExcellentPre(r,null)+o)
e.IsEmptyStr("")||(o=s?""+(E.M.s_SPACE_CHAR+o):""+o)
let _=a
r>=0&&(_=e.GetEquipQualityColor(r,l,false,0,0,0))
let u=e.getColorStrByQuality(_),h=o
i.intPosition_get()==I.GF.INT(R.C.GUARD)&&(u=e.getColorStrByQuality(t.Quality_get()))
const c=h
n&&(h=e.SetStringColor(u,h))
const d=new C.Z
return d.Add(h),d.Add(""),n||d.Add(u),d.Add(c),d}static GetNameStr(t){return`[${e.getColorStrByQuality(t)}]`}static getQualityImgByQuality(t){
return(t>=e.qualityImgStrs.count||t<0)&&(t=0),e.qualityImgStrs[t]}static getWingQualityStrByQuality(t){return(t>=e.wingqualityColorStrs.count||t<0)&&(t=0),e.wingqualityColorStrs[t]
}static SetStringBold(e){return`${E.M.s_LEFT_M_K_CHAR}b${E.M.s_RIGHT_M_K_CHAR}${e}${E.M.s_LEFT_M_K_CHAR}-${E.M.s_RIGHT_M_K_CHAR}`}static getJobStr(e){return W.Z.GetJobName(e)}
static getJobTransferStr(t,i){return e.getEquiplvStr(i)+W.Z.GetJobName(t)}static getSubWeaponName(e){return W.Z.IsSwordman(e)?(0,o.T)("副手武器"):W.Z.IsMagician(e)?(0,
o.T)("盾牌"):W.Z.IsArcher(e)?(0,o.T)("箭筒"):(0,o.T)("副手")}static getMainWeaponType(e){return W.Z.IsSwordman(e)?I.GF.INT(R.C.SINGLEWEAPON):(W.Z.IsMagician(e)||W.Z.IsArcher(e),
I.GF.INT(R.C.MAINWEAPON))}static getSubWeaponType(e){return W.Z.IsSwordman(e)?I.GF.INT(R.C.SINGLEWEAPON):(W.Z.IsMagician(e)||W.Z.IsArcher(e),I.GF.INT(R.C.SUBWEAPON))}
static getEquiplvStr(e){return H.Y.Inst_get().GetEquipcolumnresourceById(e).name}static getShenZhuangStrByType(e){return 1==e?"首饰神装":"防具神装"}static getWeekNumStr(t){return 7==t?(0,
o.T)("日"):e.getNumStr(t)}static getNumStr(t=null,i=null){if(null==i&&(i=!1),i&&2==t)return(0,o.T)("双")
if(t>=1e3)return""
if(t>=100)return t%10==0?`${e.getNumStr(Math.floor(t/100))}百${e.getNumStr(Math.floor(t%100/10))}十`:`${e.getNumStr(Math.floor(t/100))}百${e.getNumStr(Math.floor(t%100/10))}十${e.getNumStr(Math.floor(t%10))}`
if(t>=20)return t%10==0?`${e.getNumStr(Math.floor(t/10))}十`:`${e.getNumStr(Math.floor(t/10))}十${e.getNumStr(Math.floor(t%10))}`
if(t>10)return`十${e.getNumStr(Math.floor(t%10))}`
if(t<=10){if(0==t)return(0,o.T)("零")
if(1==t)return(0,o.T)("一")
if(2==t)return i?(0,o.T)("双"):(0,o.T)("二")
if(3==t)return(0,o.T)("三")
if(4==t)return(0,o.T)("四")
if(5==t)return(0,o.T)("五")
if(6==t)return(0,o.T)("六")
if(7==t)return(0,o.T)("七")
if(8==t)return(0,o.T)("八")
if(9==t)return(0,o.T)("九")
if(10==t)return(0,o.T)("十")}return""}static getEquiplvStr2(e){return 1==e?(0,o.T)("1阶"):2==e?(0,o.T)("2阶"):3==e?(0,o.T)("3阶"):4==e?(0,o.T)("4阶"):5==e?(0,o.T)("5阶"):6==e?(0,
o.T)("6阶"):7==e?(0,o.T)("7阶"):8==e?(0,o.T)("8阶"):9==e?(0,o.T)("9阶"):10==e?(0,o.T)("10阶"):""}static getPosStr(e){return R.C.ALL_EQUIP_TYPE_DATA[e][2]}static getPosStrEx(e){
return R.C.ALL_EQUIP_TYPE_DATA[e][3]}static GetGuardPosStr(e){return""}static GetGuardQualityStrByQuality(e){return 1==e?(0,o.T)("白色"):2==e?(0,o.T)("蓝色"):3==e?(0,
o.T)("绿色"):4==e?(0,o.T)("紫色"):5==e?(0,o.T)("红色"):(0,o.T)("白色")}static GetItemQualityStrByQuality(e){return 0==e?(0,o.T)("白色"):1==e?(0,o.T)("蓝色"):2==e?(0,o.T)("黄色"):3==e?(0,
o.T)("绿色"):4==e?(0,o.T)("紫色"):5==e?(0,o.T)("红色"):(0,o.T)("白色")}static EnhanceSortPriority(e){
return e==I.GF.INT(R.C.SINGLEWEAPON)?2:e==I.GF.INT(R.C.DOUBLEWEAPON)?3:e==I.GF.INT(R.C.MAINWEAPON)?4:e==I.GF.INT(R.C.SUBWEAPON)?5:e==I.GF.INT(R.C.HAT)?8:e==I.GF.INT(R.C.CLOTHES)?6:e==I.GF.INT(R.C.GLOVES)?9:e==I.GF.INT(R.C.PANTS)?10:e==I.GF.INT(R.C.BOOTS)?11:e==I.GF.INT(R.C.NECKLACE)?0:e==I.GF.INT(R.C.RINGS)?1:e==I.GF.INT(R.C.WINGS)?7:e==I.GF.INT(R.C.GUARD)?12:0
}static EquipHasShine(e){
return e==I.GF.INT(R.C.SINGLEWEAPON)||e==I.GF.INT(R.C.DOUBLEWEAPON)||e==I.GF.INT(R.C.MAINWEAPON)||e==I.GF.INT(R.C.SUBWEAPON)||e==I.GF.INT(R.C.HAT)||e==I.GF.INT(R.C.CLOTHES)||e==I.GF.INT(R.C.GLOVES)||e==I.GF.INT(R.C.PANTS)||e==I.GF.INT(R.C.BOOTS)||e==I.GF.INT(R.C.WINGS)||e==I.GF.INT(R.C.ANGELWEAPON)||e==I.GF.INT(R.C.ANGELCLOTHES)
}static EquipIsDefense(e){return e==I.GF.INT(R.C.HAT)||e==I.GF.INT(R.C.CLOTHES)||e==I.GF.INT(R.C.GLOVES)||e==I.GF.INT(R.C.PANTS)||e==I.GF.INT(R.C.BOOTS)}static EquipIsJewerly(e){
return e==I.GF.INT(R.C.NECKLACE)||e==I.GF.INT(R.C.RINGS)}static getWearPosByPosition(e){return R.C.ALL_EQUIP_TYPE_DATA[e][0]}static getSuitPosByEquipPosition(e){
return e==I.GF.INT(R.C.HAT)?0:e==I.GF.INT(R.C.CLOTHES)?1:e==I.GF.INT(R.C.GLOVES)?2:e==I.GF.INT(R.C.BOOTS)?3:e==I.GF.INT(R.C.PANTS)?4:e==I.GF.INT(R.C.NECKLACE)?5:e==I.GF.INT(R.C.RINGS)?6:-1
}static getSuitPosByEquipIndex(e){
return 2==e?eEquipSuitPartEnum.eHelmet:3==e?eEquipSuitPartEnum.eClothes:4==e?eEquipSuitPartEnum.eArmguard:6==e?eEquipSuitPartEnum.eShoes:5==e?eEquipSuitPartEnum.ePants:7==e?eEquipSuitPartEnum.eNecklace:8==e?eEquipSuitPartEnum.eLeftRing:9==e?eEquipSuitPartEnum.eRightRing:-1
}static getEquipPosBySuitPosition(e){
return e==eEquipSuitPartEnum.eHelmet?2:e==eEquipSuitPartEnum.eClothes?3:e==eEquipSuitPartEnum.eArmguard?4:e==eEquipSuitPartEnum.eShoes?6:e==eEquipSuitPartEnum.ePants?5:e==eEquipSuitPartEnum.eNecklace?7:e==eEquipSuitPartEnum.eLeftRing?8:e==eEquipSuitPartEnum.eRightRing?9:-1
}static isDontPickType(e){return e==I.GF.INT(R.C.NECKLACE)||(e==I.GF.INT(R.C.RINGS)||(e==I.GF.INT(R.C.WINGS)||e==I.GF.INT(R.C.GUARD)))}static getRoleEquipPosStr(t,i){
return null==i&&(i=0),t==R.C.PART_WEAPON_RIGHT?e.getSubWeaponName(i):R.C.ALL_PART_DATA[t][2]}static GetEquipPosMasterStr(e){return""}static getRoleEquipPosType(t,i){
return null==i&&(i=0),t==R.C.PART_WEAPON_LEFT?e.getMainWeaponType(i):t==R.C.PART_WEAPON_RIGHT?e.getSubWeaponType(i):R.C.ALL_PART_DATA[t][1]}static getRoleEquipSort(e){
return 0==e?100:1==e?99:2==e?98:3==e?97:4==e?96:5==e?95:6==e?94:7==e?93:8==e?92:9==e?91:10==e?90:11==e?89:12==e?88:13==e?87:-1}static GetAttName(e){
const t=v.X.Inst().getItemById(e)
return null==t?(p.Y.LogError((0,o.T)("ATTRIBUTERESOURCE表没有id：")+e),(0,o.T)("未配置")):t.name}static getAttrStrWithoutSign(t){return e.GetAttName(t)}static getAttrStr(t,i,n=null){
const s=e.GetAttName(t)
return t==I.GF.INT(Y.Z.EX_DamageDown)||t==I.GF.INT(Y.Z.EX_MapHP)||t==I.GF.INT(Y.Z.EX_DamageUp)||t==I.GF.INT(Y.Z.EX_Attack)||t==I.GF.INT(Y.Z.EX_DEFENSE)||t==I.GF.INT(Y.Z.EX_HIT_RATE)||t==I.GF.INT(Y.Z.DamageDownLevelAddRate)||t==I.GF.INT(Y.Z.MaxHpLevelAddRate)||t==I.GF.INT(Y.Z.AttackLevelLevelAddRate)||t==I.GF.INT(Y.Z.HitRateLevelAddRate)||t==I.GF.INT(Y.Z.DamageUpLevelAddRate)?(0,
o.T)(s):1==n?s:i?`${s}：`:`${s} +`}static getAttrValue(e,t,i){null==i&&(i=100)
const n=v.X.Inst().getItemById(e)
return null==n?0:2==n.valueType?t/i:(n.valueType,t)}static getAttrValueStr(t,i,n=null,s=null){null==s&&(s=100),null==n&&(n=!1)
const a=v.X.Inst().getItemById(t)
return null==a?"":n?E.M.IntToString(i):2!=a.valueType||n?3!=a.valueType||n?4==a.valueType?E.M.IntToString(e.GetPrecentDecimalVal(i,1e4,1)):E.M.IntToString(i):`${E.M.IntToString(i)}%`:`${E.M.IntToString(i/s)}%`
}static IsStarExellentAttr(e){
return e==I.GF.INT(Y.Z.HpRate)||e==I.GF.INT(Y.Z.HitRate)||e==I.GF.INT(Y.Z.AttackRate)||e==I.GF.INT(Y.Z.DamageDown)||e==I.GF.INT(Y.Z.AttackSpeed)||e==I.GF.INT(Y.Z.ExcellentHitRate)}
static GetStarExellAttrsNum(t){let i=0
if(null!=t.exellectAttrs)for(const[n,s]of(0,l.V5)(t.exellectAttrs.attributeDatas))e.IsStarExellentAttr(s.type)&&(i+=1)
return i}static getJobsStr(t){let i=""
if(null!=t){const n=t.Count()
let s=0
for(;s<n;)s>0&&(i+="、"),i+=e.getJobStr(t[s]),s+=1}return i}static GetFormatHHmm(e){const t=new j.H,i=e.getHours()
i<10?(t.Append("0"),t.Append(i.toString()),t.Append(E.M.s_CCD_CHAR)):(t.Append(i.toString()),t.Append(m.o.s_UNDER_COLON))
const n=e.getMinutes()
return n<10?(t.Append("0"),t.Append(n.toString())):t.Append(n.toString()),t.ToString()}static GetTimeStrMinSecond(t){const i=t%60,n=I.GF.INT(t/60)
return 0==i?(0,_.tw)(n)+(0,o.T)("分钟"):e.GetDateFormat(t)}static GalScollToGridRate(e,t,i,n,s,a){if(0==n)return 0
let r=1*e/t
null==a&&(a=!1),a&&(r/=2)
let l=0
if(null!=s&&s&&(l=.5),n-=a?2*r:r,i<r-l)return i/n
if(i-r+l>n)return 1
let o=0
return o=a?(1*i-r+l)/n:(1*i+l)/n,o}static GalGridTopRate(e,t,i,n,s){const a=.1*e/t
let r=0
if(null==s||s||(r=.5),i<a)return 0
const l=i+a+r
if(l>n)return 1
return(1*l-a-r)/n}static GetDateFormat(e,t,i,n){null==t&&(t=!1),null==n&&(n=!0),null==e&&(e=0),null==i&&(i=!0)
let s=""
const a=I.GF.INT(e/86400)
if(a>0&&(s+=a+(0,o.T)("天"),e%=86400,t))return s
const r=I.GF.INT(e/3600)
if(r>0&&(s+=r+(0,o.T)("小时"),e%=3600,t))return s
const l=I.GF.INT(e/60)
return l>0&&(s+=l+(0,o.T)("分"),e%=60,t)||(0==e?i&&n?s+=I.GF.INT(e)+(0,o.T)("秒"):l>0&&(s+="钟"):n&&(s+=I.GF.INT(e)+(0,o.T)("秒"))),s}static GetCrossBattleDateFormat(e){null==e&&(e=0)
let t=""
const i=I.GF.INT(e/86400)
if(i>0)return t+=i+(0,o.T)("天"),t
const n=I.GF.INT(e/3600)
n>0&&(t+=n+(0,o.T)("小时"),e%=3600)
const s=I.GF.INT(e/60)
return s>0&&(t+=s+(0,o.T)("分钟")),""==t&&(t=(e%=60)+(0,o.T)("秒钟")),t}static GetItemTipDateFormat(t){null==t&&(t=0)
let i=""
if(t>=3600)i=e.GetDateFormatHour(t)
else if(t>=60){i=`${I.GF.INT(t/60)}分`}else i=`${t}秒`
return i}static GetDateFormatBit(e,t){null==t&&(t=2)
let i=""
const n=I.GF.INT(e/86400)
if(n>0&&(i+=n+(0,o.T)("天"),e%=86400,(t-=1)<=0))return i
const s=I.GF.INT(e/3600)
if(s>0&&(i+=s+(0,o.T)("时"),e%=3600,(t-=1)<=0))return i
const a=I.GF.INT(e/60)
return a>0&&(i+=a+(0,o.T)("分"),e%=60,(t-=1)<=0)||e>=0&&(i+=I.GF.INT(e)+(0,o.T)("秒")),i}static GetDateFormatBitContainZero(e,t){null==t&&(t=2)
let i=""
const n=I.GF.INT(e/86400)
if(n>0&&(i+=n+(0,o.T)("天"),e%=86400,(t-=1)<=0))return i
if(n>0&&0==e)return`${i}0${(0,o.T)("小时")}`
const s=I.GF.INT(e/3600)
if(s>0&&(i+=s+(0,o.T)("小时"),e%=3600,(t-=1)<=0))return i
if(s>0&&0==e)return`${i}0${(0,o.T)("分")}`
const a=I.GF.INT(e/60)
return a>0&&(i+=a+(0,o.T)("分"),e%=60,(t-=1)<=0)||e>=0&&(i+=I.GF.INT(e)+(0,o.T)("秒")),i}static GetDateFormatHour(e){let t=""
const i=I.GF.INT(e/86400)
i>0&&(t+=i+(0,o.T)("天"),e%=86400)
const n=I.GF.INT(e/3600)
return n>0&&(t+=n+(0,o.T)("时"),e%=3600),t}static GetActivityDateFormat(t){const i=pe.E.New(1e3*t),n=i.hours_get(),s=i.minutes_get()
return`${K.u.BrightGreenColorStr2}${n}:${e.AddFrontZeroFromNum(2,s)}开始[-]`}static GetActivityOpenFormat(e){let t=""
const i=I.GF.INT(e/60)
return i>0?(t=`${K.u.BrightGreenColorStr2}${i+(0,o.T)("分钟后开始")}[-]`,t):(t=`${K.u.BrightGreenColorStr2}${e+(0,o.T)("秒后开始")}[-]`,t)}static GetActivityEndFormat(e){let t=""
const i=I.GF.INT(e/3600)
if(i>0)return t=`${K.u.BrightGreenColorStr2}${i+(0,o.T)("小时后结束")}[-]`,t
const n=I.GF.INT(e/60)
return n>0?(t=`${K.u.BrightGreenColorStr2}${n+(0,o.T)("分钟后结束")}[-]`,t):(t=`${K.u.BrightRedColorStr2}${e+(0,o.T)("秒后结束")}[-]`,t)}static GetDateFormat3(e){let t=""
const i=I.GF.INT(e/86400)
i>0&&(t+=i+(0,o.T)("天"),e%=86400)
const n=I.GF.INT(e/3600)
n>0&&(t+=n+(0,o.T)("时"),e%=3600)
const s=I.GF.INT(e/60)
return s>0&&(t+=s+(0,o.T)("分"),e%=60),""==t&&(t+=(0,o.T)("1分")),t}static GetDateFormatNosec(e){let t=""
const i=I.GF.INT(e/86400)
i>0&&(t+=i+(0,o.T)("天"),e%=86400)
const n=I.GF.INT(e/3600)
n>0&&(t+=n+(0,o.T)("小时"),e%=3600)
const s=I.GF.INT(e/60)
return s>0&&(t+=s+(0,o.T)("分"),e%=60),t}static OneDataFormat(e){let t=""
const i=I.GF.INT(e/86400)
if(i>0)return t+=i+(0,o.T)("天"),t
const n=I.GF.INT(e/3600)
if(n>0)return t+=n+(0,o.T)("小时"),t
const s=I.GF.INT(e/60)
return s>0?(t+=s+(0,o.T)("分"),t):t}static DateDiffFormat(e){let t=""
const i=I.GF.INT(e/86400)
i>0&&(t+=i+(0,o.T)("天"))
let n=e-86400*i
const s=I.GF.INT(n/3600);(s>0||i>0)&&(t+=s+(0,o.T)("时")),n-=3600*s
const a=I.GF.INT(n/60)
return(a>0||s>0||i>0)&&(t+=a+(0,o.T)("分")),n-=60*a,n=I.GF.INT(n),t+=n+(0,o.T)("秒"),t}static IsEqualDay(e){return!(c.D.serverMSTime_get()-e>=864e5)}static OneDataFormat2(e){let t=""
const i=I.GF.INT(e/86400)
if(i>0)return t+=i+(0,o.T)("天"),t
const n=I.GF.INT(e/3600)
if(n>0)return t+=n+(0,o.T)("小时"),t
const s=I.GF.INT(e/60)
if(s>0)return t+=s+(0,o.T)("分"),t
const a=I.GF.INT(e%60)
return a>0?(t+=a+(0,o.T)("秒"),t):t}static GetDateFormatEX(e,t,i){null==i&&(i=!1),null==t&&(t=!0)
let n=""
if(i){const t=I.GF.INT(e/86400)
t>0&&(n+=t+(0,o.T)("天"),e%=86400)}if(t){const t=I.GF.INT(e/3600)
t>0?(n=0==I.GF.INT(t/10)?`${n}0${t}:`:`${n}${t}:`,e%=3600):n+="00:"}const s=I.GF.INT(e/60)
if(s>0?(0==I.GF.INT(s/10)?n+=`0${s}:`:n+=`${s}:`,e%=60):n+="00:",e>0){const t=I.GF.INT(e)
0==I.GF.INT(t/10)?n=`${n}0${t}`:n+=E.M.IntToString(t)}else n=`${n}00`
return n}static GetDateFormatEXX(e,t,i,n){null==t&&(t=!0)
let s=""
if(null==i&&(i=!1),n&&(s+=K.u.BrightGreenColorStr2),i){const t=I.GF.INT(e/864e5)
t>0&&(s+=t+(0,o.T)("天"),e%=864e5)}if(t){const t=I.GF.INT(e/36e5)
t>0?(0==I.GF.INT(t/10)?s+=`0${t}:`:s+=`${t}:`,e%=36e5):s+="00:"}const a=I.GF.INT(e/6e4)
if(a>0?(0==I.GF.INT(a/10)?s+=`0${a}:`:s+=`${a}:`,e%=6e4):s+="00:",e>0){const t=I.GF.INT(e/1e3)
let i=E.M.IntToString(t)
i=t<10?`0${i}`:E.M.IntToString(t),s+=i}else s+="00"
return n&&(s+="[-]"),s}static GetDateFormatEXXX(e,t,i){null==t&&(t=!1),null==i&&(i=!0)
let n=""
if(t){const t=I.GF.INT(e/36e5)
t>0?(n=0==I.GF.INT(t/10)?`${n}0${t}:`:`${n}${t}:`,e%=36e5):n+="00:"}const s=I.GF.INT(e/6e4)
if(s>0?(0==I.GF.INT(s/10)?n+=`0${s}:`:n+=`${s}:`,e%=6e4):n=`${n}00:`,e>0){const t=I.GF.INT(e/1e3)
let i=E.M.IntToString(t)
i=t<10?`0${i}`:E.M.IntToString(t),n+=i,e%=1e3}else n+="00"
return i&&(n=`${n}:`,e>0?n+=I.GF.INT(e/10):n=`${n}00`),n}static GetDateFormatXXX(e,t){null==t&&(t=!1)
let i=""
if(t){const t=I.GF.INT(e/36e5)
t>0?(i=0==I.GF.INT(t/10)?`${i}0${t}:`:`${i}${t}:`,e%=36e5):i+="00:"}const n=I.GF.INT(e/6e4)
if(n>0?(i=0==I.GF.INT(n/10)?`${i}0${n}:`:`${i}${n}:`,e%=6e4):i+="00:",e>0){const t=I.GF.INT(e/1e3)
let n=E.M.IntToString(t)
n=t<10?`0${n}`:E.M.IntToString(t),i+=n,e%=1e3}else i+="00"
return i}static GetMDateFormat(e){let t=""
const i=I.GF.INT(e/6e4)
i>0?(0==I.GF.INT(i/10)?t+=`0${i}:`:t+=`${i}:`,e%=6e4):t+="00:"
const n=I.GF.INT(e/1e3)
if(n>0?(0==I.GF.INT(n/10)?t+=`0${n}:`:t+=`${n}:`,e%=1e3):t+="00:",e>0){const i=I.GF.INT(e)
let n=E.M.IntToString(i)
n=1==E.M.Length(n)?`0${n}`:E.M.SubStringWithLen(n,0,2),t+=n}else t=`${t}00`
return t}static GetMDateFormatEx(e){let t=""
I.GF.INT(e/6e4)>0&&(e%=6e4)
const i=I.GF.INT(e/1e3)
if(i>0?(0==I.GF.INT(i/10)?t+=`0${i}:`:t+=`${i}:`,e%=1e3):t+="00:",e>0){const i=I.GF.INT(e)
let n=E.M.IntToString(i)
n=1==E.M.Length(n)?`0${n}`:E.M.SubStringWithLen(n,0,2),t+=n}else t+="00"
return t}static SetRefreshTime(e,t){if(t<0)e.node.SetActive(!1),e.text_set((0,o.T)("已刷新")),e.color_set(new T.I(27/255,236/255,28/255,1).Clone())
else if(t<60)e.node.SetActive(!0),e.text_set((0,o.T)("即将刷新")),e.color_set(new T.I(27/255,236/255,28/255,1).Clone())
else{e.node.SetActive(!0)
const i=I.GF.INT(t/60+1)
e.text_set(i+(0,o.T)("分钟后刷新")),e.color_set(new T.I(212/255,52/255,36/255,1).Clone())}}static GetDateTime(t,i,n){null==n&&(n=!0),null==i&&(i="-")
let s=pe.E.New(t),a=s.fullYear_get()+i
return a+=e.AddFrontZeroFromNum(2,s.month_get()+1)+i,a+=`${e.AddFrontZeroFromNum(2,s.date_get())} `,n&&(a+=`${e.AddFrontZeroFromNum(2,s.hours_get())}:`,
a+=`${e.AddFrontZeroFromNum(2,s.minutes_get())}:`,a+=e.AddFrontZeroFromNum(2,s.seconds_get())),pe.E.Recycle(s),s=null,a}static GetDateTime2(t){const i=pe.E.New(t)
let n=""
return n+=`${e.AddFrontZeroFromNum(2,i.month_get()+1)}-`,n+=`${e.AddFrontZeroFromNum(2,i.date_get())} `,n+=`${e.AddFrontZeroFromNum(2,i.hours_get())}:`,
n+=`${e.AddFrontZeroFromNum(2,i.minutes_get())}:`,n+=e.AddFrontZeroFromNum(2,i.seconds_get()),pe.E.Recycle(i),n}static GetDateTime3(t){let i=pe.E.New(t),n=""
return n+=`${e.AddFrontZeroFromNum(2,i.month_get()+1)}-`,n+=`${e.AddFrontZeroFromNum(2,i.date_get())} `,n+=`${e.AddFrontZeroFromNum(2,i.hours_get())}:`,
n+=e.AddFrontZeroFromNum(2,i.minutes_get()),pe.E.Recycle(i),i=null,n}static GetDateTime4(t){const i=pe.E.New(t)
let n=""
return n+=e.AddFrontZeroFromNum(2,i.fullYear_get())+(0,o.T)("年"),n+=e.AddFrontZeroFromNum(2,i.month_get()+1)+(0,o.T)("月"),n+=e.AddFrontZeroFromNum(2,i.date_get())+(0,o.T)("日"),
n+=e.AddFrontZeroFromNum(2,i.hours_get())+(0,o.T)("时"),n+=e.AddFrontZeroFromNum(2,i.minutes_get())+(0,o.T)("分"),pe.E.Recycle(i),n}static GetDateTimeNext(t){const i=pe.E.New(t)
let n=""
const s=pe.E.New(c.D.serverMSTime_get())
return i.date_get()!=s.date_get()?(n+=e.GetDayStr(i.day_get()),n+=e.AddFrontZeroFromNum(2,i.hours_get())+(0,o.T)("时"),n+=e.AddFrontZeroFromNum(2,i.minutes_get())+(0,
o.T)("分")):(n+=e.AddFrontZeroFromNum(2,i.hours_get())+(0,o.T)("时"),n+=e.AddFrontZeroFromNum(2,i.minutes_get())+(0,o.T)("分")),pe.E.Recycle(i),pe.E.Recycle(s),n}static GetDayStr(e){
return 0==e?(0,o.T)("周日"):1==e?(0,o.T)("周一"):2==e?(0,o.T)("周二"):3==e?(0,o.T)("周三"):4==e?(0,o.T)("周四"):5==e?(0,o.T)("周五"):6==e?(0,o.T)("周六"):""}static GetDateTime5(t){
const i=pe.E.New(t)
let n=""
return n+=`${e.AddFrontZeroFromNum(2,i.fullYear_get())}-`,n+=`${e.AddFrontZeroFromNum(2,i.month_get()+1)}-`,n+=`${e.AddFrontZeroFromNum(2,i.date_get())} `,
n+=`${e.AddFrontZeroFromNum(2,i.hours_get())}:`,n+=`${e.AddFrontZeroFromNum(2,i.minutes_get())}:`,n+=e.AddFrontZeroFromNum(2,i.seconds_get()),pe.E.Recycle(i),n}
static GetDateTimeInHour(t){const i=pe.E.New(t)
let n=`${e.AddFrontZeroFromNum(2,i.hours_get())}:`
return n+=e.AddFrontZeroFromNum(2,i.minutes_get()),pe.E.Recycle(i),n}static GetRightNowInHourMin(){const t=pe.E.GetCurTime()
let i=`${e.AddFrontZeroFromNum(2,t.hours_get())}:`
return i+=e.AddFrontZeroFromNum(2,t.minutes_get()),i}static GetDateTimeInMinutes(t){const i=pe.E.New(t)
let n=`${e.AddFrontZeroFromNum(2,i.minutes_get())}:`
return n+=e.AddFrontZeroFromNum(2,i.seconds_get()),pe.E.Recycle(i),n}static GetDateTimeInHMS(t){const i=pe.E.New(t)
let n=`${e.AddFrontZeroFromNum(2,i.hours_get())}:`
return n+=`${e.AddFrontZeroFromNum(2,i.minutes_get())}:`,n+=e.AddFrontZeroFromNum(2,i.seconds_get()),pe.E.Recycle(i),n}static GetTimeInHMS(t,i){const n=I.GF.INT(I.GF.INT(t)/3600)
t%=3600
const s=I.GF.INT(t/60),a=I.GF.INT(t%60)
return null!=i&&i||0!=n?`${n}:${e.AddFrontZeroFromNum(2,s)}:${e.AddFrontZeroFromNum(2,a)}`:`${e.AddFrontZeroFromNum(2,n)}:${e.AddFrontZeroFromNum(2,s)}:${e.AddFrontZeroFromNum(2,a)}`
}static GetHMS(t,i){const n=I.GF.INT(I.GF.INT(t)/3600)
t%=3600
const s=I.GF.INT(t/60),a=I.GF.INT(t%60)
return null!=i&&i||0!=n?[n,e.AddFrontZeroFromNum(2,s),e.AddFrontZeroFromNum(2,a)]:[e.AddFrontZeroFromNum(2,n),e.AddFrontZeroFromNum(2,s),e.AddFrontZeroFromNum(2,a)]}
static GetTimeInMS(t){const i=I.GF.INT(t/60),n=I.GF.INT(t%60)
return`${e.AddFrontZeroFromNum(2,i)}:${e.AddFrontZeroFromNum(2,n)}`}static GetYear(e){const t=1e3*e,i=pe.E.New(t),n=i.fullYear_get()
return pe.E.Recycle(i),n}static GetMonth(e){const t=e,i=pe.E.New(t),n=i.month_get()
return pe.E.Recycle(i),n}static GetDay(e){const t=e,i=pe.E.New(t),n=i.date_get()
return pe.E.Recycle(i),n}static GetHour(e){const t=e,i=pe.E.New(t),n=i.hours_get()
return pe.E.Recycle(i),n}static GetMinites(e){const t=e,i=pe.E.New(t),n=i.minutes_get()
return pe.E.Recycle(i),n}static GetSecs(e){const t=1e3*e,i=pe.E.New(t),n=i.seconds_get()
return pe.E.Recycle(i),n}static GetDateTimeEx(t){const i=pe.E.New(t)
let n=e.AddFrontZeroFromNum(2,i.month_get()+1)+(0,o.T)("月")
return n+=e.AddFrontZeroFromNum(2,i.date_get())+(0,o.T)("日"),n+=`${e.AddFrontZeroFromNum(2,i.hours_get())}:`,n+=e.AddFrontZeroFromNum(2,i.minutes_get()),pe.E.Recycle(i),n}
static progressing(e,t){let i=c.D.serverMSTime_get()
const n=pe.E.New(c.D.serverMSTime_get())
i=n.time_get()
const s=E.M.Split(e,m.o.s_Arr_UNDER_COLON),a=pe.E.New(c.D.serverMSTime_get())
a.hours_set(E.M.String2Int(s[0])),a.minutes_set(E.M.String2Int(s[1])),a.seconds_set(E.M.String2Int(s[2]))
const r=E.M.Split(t,m.o.s_Arr_UNDER_COLON),l=pe.E.New(c.D.serverMSTime_get())
return l.hours_set(E.M.String2Int(r[0])),l.minutes_set(E.M.String2Int(r[1])),l.seconds_set(E.M.String2Int(r[2])),pe.E.Recycle(n),a.time_get()<=i&&l.time_get()>i?(pe.E.Recycle(a),
pe.E.Recycle(l),0):i<a.time_get()?(pe.E.Recycle(a),pe.E.Recycle(l),-1):(pe.E.Recycle(a),pe.E.Recycle(l),1)}static leftStartTime(e){let t=DateNow.ServerDate_get().time_get()
const i=E.M.Split(e,m.o.s_Arr_UNDER_COLON)
let n=pe.E.New(null)
t=n.time_get(),n.hours_set(E.M.String2Int(i[0])),n.minutes_set(E.M.String2Int(i[1])),n.seconds_set(E.M.String2Int(i[2]))
const s=n.time_get()
return pe.E.Recycle(n),n=null,s-t}static calEndTime(e){let t=pe.E.New(1e3*e)
const i=e+3600*(24-t.getHours()-1)+60*(60-t.getMinutes()-1)+(60-t.getSeconds())
return pe.E.Recycle(t),t=null,i}static calEndTimeFive(e){let t=pe.E.New(1e3*e)
const i=e+3600*(5-t.getHours()-1)+60*(60-t.getMinutes()-1)+(60-t.getSeconds())
return pe.E.Recycle(t),t=null,i}static calEndTimeEx(e,t,i){null==t&&(t=0),null==i&&(i=0)
let n=pe.E.New(e)
const s=3600*(24-t-n.getHours()-1)+60*(60-i-n.getMinutes()-1)+(60-n.getSeconds())
return pe.E.Recycle(n),n=null,s}static GetYMDTime(t){let i=pe.E.New(t),n=`${i.fullYear_get()}-`
return n+=`${e.AddFrontZeroFromNum(2,i.month_get()+1)}-`,n+=e.AddFrontZeroFromNum(2,i.date_get()),pe.E.Recycle(i),i=null,n}static GetYMDTime2(t){
let i=pe.E.New(t),n=`${i.fullYear_get()}.`
return n+=`${e.AddFrontZeroFromNum(2,i.month_get()+1)}.`,n+=e.AddFrontZeroFromNum(2,i.date_get()),pe.E.Recycle(i),i=null,n}static GetTime(t){
let i=pe.E.New(t),n=`${e.AddFrontZeroFromNum(2,i.hours_get())}:`
return n+=`${e.AddFrontZeroFromNum(2,i.minutes_get())}:`,n+=e.AddFrontZeroFromNum(2,i.seconds_get()),pe.E.Recycle(i),i=null,n}static GetChineseDateTime(t){
let i=pe.E.New(t),n=i.fullYear_get()+(0,o.T)("年")
return n+=e.AddFrontZeroFromNum(2,i.month_get()+1)+(0,o.T)("月"),n+=e.AddFrontZeroFromNum(2,i.date_get())+(0,o.T)("日"),pe.E.Recycle(i),i=null,n}static GetChineseDateTimeEx(t,i,n,s){
null==n&&(n=!0),null==s&&(n=!1),i=i||"/"
let a=pe.E.New(t),r=""
return n&&(r=a.getFullYear()+i),r+=e.AddFrontZeroFromNum(2,a.getMonth()+1)+i,r+=e.AddFrontZeroFromNum(2,a.getDate()),s&&(r+=" ",r+=`${e.AddFrontZeroFromNum(2,a.getHours())}:`,
r+=`${e.AddFrontZeroFromNum(2,a.getMinutes())}:`,r+=e.AddFrontZeroFromNum(2,a.getSeconds())),a=null,r}static AddFrontZeroFromNum(t,i){const n=E.M.IntToString(i)
return e.AddFrontZero(t,n)}static AddFrontZero(e,t){let i=E.M.Length(t)
for(;i<e;)t=`0${t}`,i+=1
return t}static GetDicContainLusuoLongKey(e,t){for(const[i,n]of(0,l.vy)(t))if(i.Equal(e))return i
return null}static Substitute(e,t){if(null==e)return""
if(null==t)return e
const i=t.length
let n=0
for(;n<i;)e=E.M.Replace(e,`{${n}}`,t[n]),n+=1
return e}static SubstituteEx(e,t){if(null==e)return""
if(null==t)return e
const i=t.Count()
let n=0
for(;n<i;)e=E.M.Replace(e,`{${n}}`,t[n]),n+=1
return e}static StringJoin(e,...t){const i=[...t]
for(let e=1;e<=i.length;e++)i[e]=(0,_.tw)(i[e])
return table.concat(i,e)}static StringJoinObjs(e,...t){const i=[...t]
return table.concat(i,e)}static StringJoinByList(e,t){const i=t._dt_
return table.concat(i,e)}static StringJoinByObjList(e,t){const i=t._dt_
for(let e=1;e<=i.length;e++)i[e]=(0,_.tw)(i[e])
return table.concat(i,e)}static SubstituteEx2(e,...t){if(null==e)return""
let i=[...t]
const n=i.length
let s=0
for(;s<n;)e=E.M.Replace(e,`{${s}}`,i[s+1]),s+=1
return i=null,e}static RegexN(e){const t="\\n"
let i=20
for(;E.M.IndexOf(t,t,0)>=0&&(e=E.M.ReplaceSlow(e,t,"\n"),i-=1,!(i<0)););return e}static add0(t,i){if(null==i&&(i=2),2==i)return t>9?`${t}`:`0${t}`
const n=`${t}`,s=i-E.M.Length(n)
return s>0?E.M.SubStringWithEnd(e.ZEROS,0,s)+n:n}static sendGMComand(e){p.Y.Log(`${e}`)
const t=E.M.Split(e," ")
if("--debug"==t[0])return void _e.C.ParseDebugCmd(e)
if("ef"==t[0])return void(0,te.Yp)(ie.o.EffectShowEditor)
if("showme"==t[0])return void oe.z.Inst().OpenGMMiniPanel()
if("showmeout"==t[0])return void oe.z.Inst().CloseGMMiniPanel()
const i=new le.q
i.command=e,ae.C.Inst.F_SendMsg(i)}static GetPathPos(e,t){const i=J.P.zero_get(),n=J.P.zero_get()
let s=Q.p.MAX_VALUE_get(),a=t.x-.5
for(;a<t.x+1;){let r=t.z-.5
for(;r<t.z+1;){if(i.Set(a,t.y,r),z.c.Instance_get().CanArriveByPos(i)){const t=J.P.Distance(e,i)
t<s&&(s=t,n.Set(i.x,i.y,i.z))}r+=.5}a+=.5}return n}static FaceToNpc(e){const t=de.f.Inst().getItemByIdRaw(e)
if(null!=t){const e=u.Y.Inst.PrimaryRole_get(),i=re.I.calVec0
i.x=t.x,i.y=0,i.z=t.y,e.rotateTo(i,null)}}static NpcFaceToPlayer(e){const t=de.f.Inst().getItemByIdRaw(e),i=u.Y.Inst.getNpcById(e)
if(null!=t&&1==t.turn&&null!=i){const e=u.Y.Inst.PrimaryRole_get(),t=J.P.zero_get()
e.GetCurPos(t),i.rotateTo(t,null)}}static SetLinkStr(t,i,n,s){null==s&&(s=!0)
let a=""
return e.IsEmptyStr(t)||(a=s?`${E.M.s_LEFT_M_K_CHAR}url=${i}${E.M.s_RIGHT_M_K_CHAR}${E.M.s_LEFT_M_K_CHAR}${t}${E.M.s_RIGHT_M_K_CHAR}${E.M.s_LEFT_M_K_CHAR}${E.M.s_F_SLASH_DOT}url${E.M.s_RIGHT_M_K_CHAR}`:`${E.M.s_LEFT_M_K_CHAR}url=${i}${E.M.s_RIGHT_M_K_CHAR}${t}${E.M.s_LEFT_M_K_CHAR}${E.M.s_F_SLASH_DOT}url${E.M.s_RIGHT_M_K_CHAR}`,
e.IsEmptyStr(n)||(a=e.SetStringColor(n,a))),a}static SetNameLinkStr(t,i,n,s){null==s&&(s=!0)
let a=""
return e.IsEmptyStr(t)||(a=s?`${E.M.s_LEFT_M_K_CHAR}url=${i}${E.M.s_RIGHT_M_K_CHAR}${m.o.s_LEFT_NAME_CHAR}${t}${m.o.s_RIGHT_NAME_CHAR}${E.M.s_LEFT_M_K_CHAR}${E.M.s_F_SLASH_DOT}url${E.M.s_RIGHT_M_K_CHAR}`:`${E.M.s_LEFT_M_K_CHAR}url=${i}${E.M.s_RIGHT_M_K_CHAR}${t}${E.M.s_LEFT_M_K_CHAR}${E.M.s_F_SLASH_DOT}url${E.M.s_RIGHT_M_K_CHAR}`,
e.IsEmptyStr(n)||(a=e.SetStringColor(n,a))),a}static IsEmptyStr(e){return null==e||""==e}static GetLusuoLongStr(e,t){return null==t&&(t=0),null!=e?m.o.NumToString(e.ToNum(),t):null
}static GetPurseVOString(e,t){null==t&&(t=0)
let i=m.o.NumToString(e,t)
const n=E.M.Length(i)
if(n<=3)return i
let s=I.GF.INT(n/3)
const a=n-3*s
for(;0!=s&&(s-=1,0!=s||0!=a);){i=`${E.M.SubStringWithEnd(i,0,a+3*s)},${E.M.SubStringWithEnd(i,a+3*s,E.M.Length(i))}`}return i}static GetRuleDecimalValEx(t){
if(t<e.DanWeiDecima[e.DanWeiDecima.count-1])return e.GetStringSplitByDou(t)
let i=""
for(let n=0;n<=e.DanWeiDecima.count-1;n++){let s=t/e.DanWeiDecima[n]
if(s>=1){if(i=e.GetStringSplitByDou(I.GF.INT(s)),s=t%e.DanWeiDecima[n],s>=1){const t=s
let a=s%10,r=1
for(;s>=1&&a<1;)a=s%10,s/=10,s>=1&&a<1&&(r*=10)
s=(e.DanWeiDecima[n]+t)/r
let l=`${I.GF.INT(s)}`
const o=Math.min(l.length-1,2)
l=E.M.SubStringWithLen(l,1,o)
let _=-1
for(let e=E.M.Length(l)-1;e>=0;e+=-1){if("0"!=E.M.GetAt(l,e)){_=e
break}}return-1==_?i+e.DanWeis[n]:(l=E.M.SubStringWithEnd(l,0,_+1),`${i}.${l+e.DanWeis[n]}`)}return i+e.DanWeis[n]}}return e.GetStringSplitByDou(t)}
static GetPurseVOChineseString(e,t=null,i=null,n=null,s=!1,a=!0){let r=`${e}`
Math.floor(e)!=Math.ceil(e)&&(r=`${e.toFixed(1)}`)
let l=0,_="",u="",h=""
if(null==t&&(t=!0),null==n&&(n=!1),E.M.Length(r)>4&&E.M.Length(r)<9)l=E.M.Length(r)-4,h=E.M.SubStringWithLen(r,l,2),r=E.M.SubStringWithLen(r,0,l),
E.M.Length(r)>3?(_=E.M.SubStringWithEnd(r,0,1),null==i&&(i=E.M.Length(r)),u=E.M.SubStringWithEnd(r,1,i),r=E.M.String2Int(h)>0||n?`${_},${u}.${h+(0,o.T)("万")}`:`${_},${u+(0,
o.T)("万")}`):E.M.String2Int(h)>0||n?r=`${r}.${h+(0,o.T)("万")}`:r+=(0,o.T)("万")
else if(E.M.Length(r)>8&&E.M.Length(r)<13||s&&E.M.Length(r)>8){l=E.M.Length(r)-8,h=E.M.SubStringWithLen(r,l,2),r=E.M.SubStringWithLen(r,0,l)
let e=r
if(E.M.Length(r)>3){let t=l-3
for(;t>0;)_=E.M.SubStringWithEnd(e,0,t),u=E.M.SubStringWithEnd(e,t,E.M.Length(e)),e=a?`${_},${u}`:`${_}${u}`,t-=3
r=E.M.String2Int(h)>0||n?`${e}.${h+(0,o.T)("亿")}`:e+(0,o.T)("亿")}else E.M.String2Int(h)>0||n?r=`${r}.${h+(0,o.T)("亿")}`:r+=(0,o.T)("亿")}else if(E.M.Length(r)>12){
l=E.M.Length(r)-12,h=E.M.SubStringWithLen(r,l,2),r=E.M.SubStringWithLen(r,0,l)
let e=r
if(E.M.Length(r)>3){let i=l-3
for(;i>0;)_=E.M.SubStringWithEnd(e,0,i),u=E.M.SubStringWithEnd(e,i,E.M.Length(e)),e=`${_},${u}`,i-=3
r=t||n?`${e}.${h+(0,o.T)("万亿")}`:e+(0,o.T)("万亿")}else t||n?r=`${r}.${h+(0,o.T)("万亿")}`:r+=(0,o.T)("万亿")}else t&&E.M.Length(r)>3&&(_=E.M.SubStringWithEnd(r,0,1),
u=E.M.SubStringWithEnd(r,1,E.M.Length(r)),r=`${_},${u}`)
return r}static GetChineseStringByType(e,t){let i=""
return 1==t?i=Math.floor(e/100)/100+(0,o.T)("万"):2==t?i=Math.floor(e/1e6)/100+(0,o.T)("亿"):3==t&&(i=Math.floor(e/1e9)/100+(0,o.T)("万亿")),i}static GetCopyExpChineseString(t){
let i=m.o.NumToString(t,0),n=0,s="",a=""
if(E.M.Length(i)>8){n=E.M.Length(i)-8,s=e.GetStringSplitByDou(t/1e8),a=E.M.SubStringWithEnd(i,n,E.M.Length(i))
E.M.Length(a)>2&&(a=E.M.SubStringWithEnd(a,0,2)),i=`${s}.${a}E`}else i=e.GetStringSplitByDou(t)
return i}static GetCopyExpChineseStringEX(t,i){let n=m.o.NumToString(t,0),s=0,a="",r=""
if(E.M.Length(n)>6&&i){s=E.M.Length(n)-8,s<0&&(s=0),a=e.GetStringSplitByDou(t/1e8),r=E.M.SubStringWithEnd(n,s,E.M.Length(n))
7==E.M.Length(n)&&(r=`0${r}`),E.M.Length(r)>2&&(r=E.M.SubStringWithEnd(r,0,2)),n=`${a}.${r}E`}else n=e.GetStringSplitByDou(t)
return n}static GetStringSplitByDou(e){let t=E.M.DoubleToString(m.o.NumDigit(e,null)),i="",n="",s=E.M.Length(t)-3
for(;s>=1;)i=E.M.SubStringWithEnd(t,0,s),n=E.M.SubStringWithEnd(t,s,E.M.Length(t)),t=`${i},${n}`,s-=3
return t}static GetPurseVOChineseStringEx(e){let t=m.o.NumToString(e,0),i=0
if(E.M.Length(t)>4&&E.M.Length(t)<=8)i=E.M.Length(t)-4,t=E.M.SubStringWithLen(t,0,i),t+="W"
else if(E.M.Length(t)>8){i=E.M.Length(t)-8,t=E.M.SubStringWithLen(t,0,i)
t=`${t}Y`}return t}static GetPurseVOChineseStringEEx(e,t,i){let n=""
e>=1e12?(e/=1e12,n="WY"):e>=1e8?(e/=1e8,n="Y"):e>=1e4&&(e/=1e4,n="W")
return m.o.NumToString(e,t,i)+n}static SetAsuramJob(e){return e==f.o.Member?(0,o.T)("成员"):e==f.o.Elite?(0,o.T)("精英"):e==f.o.Elder?(0,o.T)("长老"):e==f.o.ViceLeader?(0,
o.T)("副盟主"):e==f.o.AgentLeader?(0,o.T)("代理盟主"):e==f.o.Leader?(0,o.T)("盟主"):""}static GetRomaNumByInt(e){
return 0==e?"0":1==e?"Ⅰ":2==e?"Ⅱ":3==e?"Ⅲ":4==e?"Ⅳ":5==e?"Ⅴ":6==e?"Ⅵ":7==e?"Ⅶ":8==e?"Ⅷ":9==e?"Ⅸ":10==e?"Ⅹ":11==e?"Ⅺ":12==e?"Ⅻ":""}static isStrMatched(e,t){
const i=E.M.Length(e),n=E.M.Length(t)
let s=0,a=0
for(s=0;s<i-n+1;){for(a=0;a<n&&E.M.GetAt(t,a)==E.M.GetAt(e,s+a);)a+=1
if(a==n)return!0
s+=1}return!1}static GetAddvanceTypeByPos(e){
return e==I.GF.INT(R.C.SINGLEWEAPON)||e==I.GF.INT(R.C.DOUBLEWEAPON)||e==I.GF.INT(R.C.MAINWEAPON)?0:e==I.GF.INT(R.C.SUBWEAPON)?1:e==I.GF.INT(R.C.NECKLACE)?2:e==I.GF.INT(R.C.RINGS)?3:e==I.GF.INT(R.C.HAT)||e==I.GF.INT(R.C.CLOTHES)||e==I.GF.INT(R.C.BOOTS)||e==I.GF.INT(R.C.GLOVES)||e==I.GF.INT(R.C.PANTS)?4:-1
}static GetTimeType(e){let t="",i=0,n=0
return e<3600?(i=e/60,i<1&&(i=1),n=I.GF.INT(i),t=n+(LangUtil.Inst().getStr(10248,eGameAllCSV.eLangResource)+LangUtil.Inst().getStr(10257,eGameAllCSV.eLangResource))):e>=3600&&e<86400?(i=e/3600,
n=I.GF.INT(i),t=n+(LangUtil.Inst().getStr(10247,eGameAllCSV.eLangResource)+LangUtil.Inst().getStr(10257,eGameAllCSV.eLangResource))):e>=86400&&e<2538e3?(i=e/86400,n=I.GF.INT(i),
t=n+(LangUtil.Inst().getStr(10246,eGameAllCSV.eLangResource)+LangUtil.Inst().getStr(10257,eGameAllCSV.eLangResource))):(i=e/2538e3,n=I.GF.INT(i),
t=n+(LangUtil.Inst().getStr(10256,eGameAllCSV.eLangResource)+LangUtil.Inst().getStr(10257,eGameAllCSV.eLangResource))),t}static SetFunctionTip(t){
const i=D.d.Inst_get().getItemById(t),n=i.name,s=D.d.Inst_get().GetOpenParamById(t)
let l=null
if(w.P.Inst_get().CheckExtraPackageFunction(t,!0))if(0==i.type)l=new C.Z([k.h.GetLevelStr(s),n]),
i.activityType&&D.d.Inst_get().IsLevelEnough(t)?V.y.inst.ClientSysMessage(121003):t==L.x.MIRACLE_TOWER?V.y.inst.ClientSysMessage(100590,l):t==L.x.STAR_SKY||t==L.x.STAR_SKY_LIMIT?V.y.inst.ClientSysMessage(11042910):t==L.x.DRAGON_TREASURE||t==L.x.DRAGON_TREASURE_MAIN||t==L.x.DRAGON_TREASURE_SHOP||t==L.x.FORTUNE_TREASURE||t==L.x.MAYA_TREASURE?V.y.inst.ClientSysStrMsg(`${n}未开启`):V.y.inst.ClientSysMessage(100538,l)
else if(1==i.type){const e=r.O.Inst_get().GetTaskById(s,null),t=E.M.ToLower(e.taskName_get())
l=new C.Z([t,n]),V.y.inst.ClientSysMessage(100556,l)}else if(2==i.type)l=new C.Z([e.GetChineseNum(s),n]),V.y.inst.ClientSysMessage(100562,l)
else if(4==i.type)l=new C.Z([e.GetChineseNum(s),E.M.IntToString(i.funOpenLevel),n]),V.y.inst.ClientSysMessage(100592,l)
else if(5==i.type){const e=i.GetOpenConditionList()
c.D.serverOpenDay_get()<e[0]?(l=new C.Z([E.M.IntToString(e[0]),n]),V.y.inst.ClientSysMessage(10330003,l)):a.j.Inst_get().model.worldLevel<e[2]?(l=new C.Z([E.M.IntToString(e[2]),n]),
V.y.inst.ClientSysMessage(10330001,l)):u.Y.Inst.PrimaryRoleInfo_get().Level_get()<e[1]?(l=new C.Z([E.M.IntToString(e[1]),n]),
V.y.inst.ClientSysMessage(10330002,l)):i.activityType&&V.y.inst.ClientSysMessage(10340016)}else if(9==i.type){const t=s
if(null!=t){const i=e.ConcatStr("通关",t.res.mapName,t.res.name,(0,o.T)("开启"),n)
V.y.inst.ClientSysStrMsg(i)}}else if(10==i.type){const t=e.ConcatStr("累计通关",s,(0,o.T)("次开启"),n)
V.y.inst.ClientSysStrMsg(t)}else if(11==i.type){const e=(0,o.T)("首充开启")
V.y.inst.ClientSysStrMsg(e)}else if(12==i.type){const t=e.ConcatStr("在GM工具中开启",n)
V.y.inst.ClientSysStrMsg(t)}else if(13==i.type){const t=e.ConcatStr("vip",s,"开启",n)
V.y.inst.ClientSysStrMsg(t)}else if(14==i.type){const t=e.ConcatStr("使用道具[",i.OpenItemCfg.name,"]开启",n)
V.y.inst.ClientSysStrMsg(t)}else if(15==i.type){const t=e.ConcatStr("镶嵌",s,"个荧石开启",n)
V.y.inst.ClientSysStrMsg(t)}else V.y.inst.ClientSysStrMsg("功能未开启！")}static GetFunctionTip(t){const i=D.d.Inst_get().getItemById(t)
if(null==i)return""
const n=i.name
let s=D.d.Inst_get().GetOpenParamById(t),l=""
if(0==i.type)l=119==i.id?u.Y.Inst.PrimaryRoleInfo_get().Level_get()<E.M.String2Int(i.funOpenLevel)?k.h.GetLevelStr(s)+((0,o.T)("开启")+n):(0,o.T)("首充开启")+n:k.h.GetLevelStr(s)+((0,
o.T)("开启")+n)
else if(1==i.type){l=`[${r.O.Inst_get().GetTaskById(s,null).resource_get().minLevel+((0,o.T)("级]主线任务开启")+n)}`}else if(2==i.type)l=s+((0,o.T)("转开启")+n)
else if(3==i.type)l=(0,o.T)("消耗")+(i.vitalityLimit+((0,o.T)("点活跃度开启")+n))
else if(4==i.type)l=s+((0,o.T)("转")+(i.funOpenLevel+((0,o.T)("级开启")+n)))
else if(5==i.type)s=i.GetOpenConditionList(),c.D.serverOpenDay_get()<s[0]?l=(0,o.T)("开服")+(s[0]+((0,o.T)("天开启")+n)):u.Y.Inst.PrimaryRoleInfo_get().Level_get()<s[1]?l=s[1]+(0,
o.T)("级开启"):a.j.Inst_get().model.worldLevel<s[2]&&(l=(0,o.T)("世界等级")+(s[2]+(0,o.T)("级开启").funcName))
else if(7==i.type)l=s<=400?e.ConcatStr((0,o.T)("常规竞技场将在"),s,(0,o.T)("级开启"),n):e.ConcatStr((0,o.T)("常规竞技场将在大师"),s,(0,o.T)("级开启"),n)
else if(8==i.type)l=s<=400?e.ConcatStr((0,o.T)("巅峰竞技场将在"),s,(0,o.T)("级开启"),n):e.ConcatStr((0,o.T)("巅峰竞技场将在大师"),s,(0,o.T)("级开启"),n)
else if(9==i.type){const t=s
null!=t&&(l=e.ConcatStr("通关",t.res.mapName,t.res.name,(0,o.T)("开启"),n))}else 10==i.type?l=e.ConcatStr("累计通关",s,(0,o.T)("次开启"),n):11==i.type?l=(0,o.T)(`首充开启${n}`):12==i.type?l=(0,
o.T)(`在GM工具中开启${n}`):13==i.type?l=e.ConcatStr("vip",s,"开启",n):14==i.type?l=e.ConcatStr("使用道具[",i.OpenItemCfg.name,"]开启",n):15==i.type?l=e.ConcatStr("镶嵌",s,"个荧石后开启",n):16==i.type&&(l=e.ConcatStr(D.d.Inst_get().getItemById(i.needFuncId).name,"功能开启，且达到",k.h.GetLevelStr(i.funOpenLevel),"级后开启",n))
return l}static GetExcellentPre(t,i){let n="",s=" "
return i&&(s=i),t>0?(n=t>1?e.GetChineseNum2(t)+((0,o.T)("卓越的")+(s+n)):(0,o.T)("卓越的")+(s+n),n):""}static GetChineseNum2(t){return 1==t?(0,o.T)("单"):2==t?(0,o.T)("双"):e.getNumStr(t)}
static GetChineseNum(e){let t=""
return 0==e?t=(0,o.T)("零"):1==e?t=(0,o.T)("一"):2==e?t=(0,o.T)("二"):3==e?t=(0,o.T)("三"):4==e?t=(0,o.T)("四"):5==e?t=(0,o.T)("五"):6==e?t=(0,o.T)("六"):7==e?t=(0,o.T)("七"):8==e?t=(0,
o.T)("八"):9==e?t=(0,o.T)("九"):10==e&&(t=(0,o.T)("十")),t}static GetChineseDoubleNum(t){let i=""
if(t>10&&t<100){const n=E.M.String2Int(t/10)
n>1?(i=e.GetChineseNum(n),i+=e.GetChineseNum(10),i+=e.GetChineseNum(t%10)):1==n&&(i=e.GetChineseNum(10),i+=e.GetChineseNum(t%10))}else i=e.GetChineseNum(t)
return i}static GetTimeText(e){let t="",i=0,n=0
if(e<60)t=e+LangUtil.Inst().getStr(10248,eGameAllCSV.eLangResource)
else if(e>=60&&e<1440)i=I.GF.INT(e/60),n=I.GF.INT(e%60),t=0==n?i+LangUtil.Inst().getStr(10247,eGameAllCSV.eLangResource):i+(LangUtil.Inst().getStr(10247,eGameAllCSV.eLangResource)+(n+LangUtil.Inst().getStr(10248,eGameAllCSV.eLangResource)))
else{const n=I.GF.INT(e/1440)
i=I.GF.INT(e%1440/60),t=0==i?n+LangUtil.Inst().getStr(10246,eGameAllCSV.eLangResource):n+(LangUtil.Inst().getStr(10246,eGameAllCSV.eLangResource)+(i+LangUtil.Inst().getStr(10247,eGameAllCSV.eLangResource)))
}return t}static GetTimeMonth(e){if(e<60)return`${Math.floor(e)+(0,o.T)("秒")}`
const t=I.GF.INT(e/60)
if(t<60)return`${Math.floor(t)+(0,o.T)("分")}`
let i=0
if(t<1440)return i=t/60,`${Math.floor(i)+(0,o.T)("时")}`
let n=0
if(t<42300)return n=t/60/24,`${Math.floor(n)+(0,o.T)("天")}`
const s=I.GF.INT(t/60/24/30)
return`${Math.floor(s)+(0,o.T)("月")}`}static getIntValByExcelArray(e){const t=new C.Z
e=E.M.Replace(e,E.M.s_LEFT_M_K_CHAR_REPLACE,m.o.s_BLANK_CHAR),e=E.M.Replace(e,E.M.s_RIGHT_M_K_CHAR_REPLACE,m.o.s_BLANK_CHAR)
const i=E.M.Split(e,E.M.s_SPAN_CHAR)
if(null!=i){let e=0
for(const[n,s]of(0,l.V5)(i))e=E.M.String2Int(s),t.Add(e)}return 0!=t.Count()?t:null}static GetQulityBgName(e){let t=""
return e==K.u.WHITEINDEX?t="atlas/common/rycommon_sp_0147":e==K.u.BLUEINDEX?t="atlas/common/rycommon_sp_0149":e==K.u.GREENINDEX?t="atlas/common/rycommon_sp_0150":e==K.u.PURPLEINDEX?t="atlas/common/rycommon_sp_0151":e==K.u.YELLOWINDEX?t="atlas/common/rycommon_sp_0152":e==K.u.REDINDEX?t="atlas/common/rycommon_sp_0153":e==K.u.PINKINDEX&&(t="atlas/common/rycommon_sp_0154"),
t}static GetWingQulityBgName(e){let t=""
return 0==e||1==e?t="comm_sp_0034":2==e?t="comm_sp_0035":3==e&&(t="comm_sp_0036"),t}static GetBagitemWingQulityBgName(e){let t=""
return 0==e||1==e?t="mbcommon_sp_0130":2==e?t="mbcommon_sp_0131":3==e&&(t="mbcommon_sp_0134"),t}static GetWingNameColorQuilty(e){return 0==e||1==e?1:2==e?3:3==e?4:0}
static GetTipQulityBg(t){return e.GetQulityBgName(t)}static GetIconQuality(t,i,n,s,a,r){null==a&&(a=0),null==s&&(s=0),null==n&&(n=!1),null==r&&(r=0)
let l=""
return 1==r||1==a?l=e.qualityImgStrs[4]:2==a?l=e.qualityImgStrs[5]:0==t?l=s>=7?e.qualityImgStrs[2]:n?e.qualityImgStrs[1]:e.qualityImgStrs[0]:t>0&&(l=e.qualityImgStrs[3]),l}
static GetStarBgColor(e,t,i){let n="comm_sp_0137"
return 1==i||1==t?n="comm_sp_0135":2==t?n="comm_sp_0136":e>0&&(n="comm_sp_0137"),n}GetVerticalStarBgWidth(e){return 1==e?34:2==e?54:3==e?74:4==e?94:5==e?114:0}
static GetStarBgWidth(e,t){
return 1==t?86==e||80==e?26:78==e||76==e?22:70==e?20:66==e?19:56==e?15:52==e?14:26:2==t?86==e||80==e?41:78==e?37:76==e?36:70==e?33:66==e?31:56==e?25:52==e?23:41:3==t?86==e||80==e?56:78==e?52:76==e?50:70==e?46:66==e?43:56==e?35:52==e?32:56:0
}static GetStarPos(e,t,i){const n=new J.P(0,0,0)
return 1==t?n.x=86==e||80==e?12:78==e||76==e?11:70==e?10:66==e?9:56==e||52==e?7:13:2==t?0==i?n.x=86==e||80==e?12:78==e||76==e?10:70==e?9:66==e?8:56==e?7:52==e?6:12:1==i&&(n.x=86==e||80==e?28:78==e?26:76==e?25:70==e?23:66==e?21:56==e?18:52==e?16:28):3==t&&(0==i?n.x=86==e||80==e?10:78==e||76==e?9:70==e?8:66==e?7:56==e||52==e?6:10:1==i?n.x=86==e||80==e?26:78==e?25:76==e?24:70==e?22:66==e?20:56==e?16:52==e?15:26:2==i&&(n.x=86==e||80==e?42:78==e?41:76==e?39:70==e?36:66==e?33:56==e?26:52==e?24:42)),
n}static GetLevelAddIconPosX(e,t){
return t<10?86==e||80==e||78==e||76==e?-15:70==e||66==e?-12:56==e||52==e?-11:-15:86==e||80==e||78==e||76==e?-23:70==e||66==e?-22:56==e||52==e?-17:-23}static GetIconByNumStr(e){
const t="comm_nb_00"
let i="",n=E.M.String2Int(e)
return 0==n?(i=`${t}61`,i):(n+=51,i=t+n,i)}static GetLevelIconName(e){return e?"comm_sp_0062":"comm_sp_0069"}static GetRuleStringVal(e){let t="",i=0
for(;e>=1e3;){i=e%1e3
t=`,${CommonBridge.ToFillInt(i,3)+t}`,e/=1e3}return t=E.M.IntToString(e)+t,t}static GetRuleDecimalVal(t,i=null,n=null){if(null==n&&(n=!0),null==i&&(i=1),
t<=9999)return`${I.GF.INT(t)}`
if(t>9999&&t<=99999999){let s=0
return n&&(s=i),e.MathRound(t/1e4,s)+(0,o.T)("万")}return t>99999999&&t<=999999999999?e.MathRound(t/1e8,i)+(0,o.T)("亿"):t>999999999999?e.MathRound(t/1e12,i)+(0,o.T)("万亿"):""}
static GetRuleDecimalValByFloorToInt(t,i,n){if(null==n&&(n=!0),null==i&&(i=1),null==t)return""
if(t<=9999)return`${I.GF.INT(t)}`
if(t>9999&&t<=99999999){let s=0
return n&&(s=i),e.MathFloorToInt(t/1e4,s)+(0,o.T)("万")}return t>99999999&&t<=999999999999?e.MathFloorToInt(t/1e8,i)+(0,o.T)("亿"):t>999999999999?e.MathFloorToInt(t/1e12,i)+(0,
o.T)("万亿"):""}static GetPrecentDecimalVal(t,i,n){return null==t&&(t=0),null==n&&(n=1),null==i&&(i=100),e.MathRound(t/i,n)}static SortCompareFunc_Int(e,t){return e-t}
static SortCompareFunc_Int2(e,t){return t-e}static MathRound(e,t){null==t&&(t=1)
let i=0,n=1,s=0
for(;s<t;)n*=10,s+=1
return i=g.p.RoundToInt(e*n),i/n}static MathFloorToInt(e,t){null==t&&(t=1)
let i=0,n=1,s=0
for(;s<t;)n*=10,s+=1
return i=g.p.FloorToInt(e*n),i/n}static JudgeIsPow(e,t){for(null==t&&(t=2);e>=0;){if(e==t)return!0
if(e%t!=0)return!1
e/=t}return!1}static SelectStr(e,t,i){return e?t:i}static GetRoleVIPLevelIcon(e){return`comm_nb_00${E.M.IntToString(e+1)}`}static CheckBtnClickTrigger(t,i=null,n=null){
e.CheckTrigger(x.u.COND_CLICK_BTN_VAL,t,i,n)}static CheckTrigger(e,t,i,n){null==n&&(n=150),null==e&&p.Y.LogError("空引导"),ue.c.Inst.CheckTrigger(e,t,n,i)}
static GetSignItemQualityIconByQuality(e){let t=""
return 0==e?t="qiandao_sp_0008":1==e||2==e?t="qiandao_sp_0009":3==e?t="qiandao_sp_0010":4==e?t="qiandao_sp_0011":5==e&&(t="qiandao_sp_0012"),t}
static GetAllianceBuildIconByType(e,t){const i="zhanmengjianzhu_sp_00",n=GuildbuildingCfgMgr.Inst().GetItemById(`${e}_1`)
if(!t)return n.icon
let s=E.M.String2Int(E.M.ReplaceOne(n.icon,i,""))
return s+=1,i+s}static GetItemQualityImg(t){let i="",n=null
if(0==t.modelId_get())return i
if(t.BagItemType_get()==eBagItemType.Equip){n=t.serverData_get()
let s=e.getEquipQuality(n,t.equipInfo_get());-1==s&&(s=t.cfgData_get().Quality_get()),i=e.getQualityImgByQuality(s)}else i=e.getQualityImgByQuality(t.cfgData_get().Quality_get())
if(null!=t.serverData_get()&&t.BagItemType_get()==eBagItemType.Equip){n=t.serverData_get()
const s=P.X.Inst_get().GetEquipExcellenceCount(n,t.equipInfo_get()),a=P.X.Inst_get().IsSpecialRing(n,t.equipInfo_get())
if(s>=0&&!a){
const a=P.X.Inst_get().IsEquipHasLucky(n,null,null),r=P.X.Inst_get().GetEquipStarLevel(n,t.equipInfo_get()),l=P.X.Inst_get().GetEquipEnhanceLevel(n,t.equipInfo_get(),null),o=P.X.Inst_get().GetEquipSuitProperty(n,t.equipInfo_get()),_=P.X.Inst_get().GetEquipGodType(n,t.equipInfo_get())
i=e.GetIconQuality(s,r,a,l,o,_)}}return i}static AnalyseArrayStr(t){return e.IsEmptyStr(t)||"[]"==t?null:(t=E.M.Replace(t,E.M.s_LEFT_M_K_CHAR_REPLACE,""),
t=E.M.Replace(t,E.M.s_RIGHT_M_K_CHAR_REPLACE,""),E.M.Split(t,E.M.s_Arr_SPAN_CHAR_DOT))}static parseTransferorm(t){
const i=new C.Z,n=E.M.Split(t,E.M.s_CCD_CHAR),s=e.getVector3List(n[0]),a=e.getVector3List(n[1]),r=e.getVector3List(n[2])
return i.Add(s),i.Add(a),i.Add(r),i}static getVector3List(e){const t=new J.P,i=E.M.Split(e,m.o.s_UNDER_CHAR)
return t.x=E.M.String2Float(i[0]),t.y=E.M.String2Float(i[1]),t.z=E.M.String2Float(i[2]),t}static GetTitleIconNameByType(e){let t="mainui_sp_"
return t+=0==e?"0063":1==e?"0148":2==e?"0054":3==e?"0058":4==e?"0059":5==e?"0060":6==e?"0062":"0061",t}static GetMSRadomEnd2(e){let t=""
const i=I.GF.INT(e/6e4)
i>0?(0==I.GF.INT(i/10)?t+=`0${i}:`:t+=`${i}:`,e%=6e4):t+="00:"
const n=I.GF.INT(e/1e3)
if(n>0?(0==I.GF.INT(n/10)?t+=`0${n}:`:t+=`${n}:`,e%=1e3):t+="00:",e>0){const i=g.p.RoundToInt(g.p.RandomMinMax(0,9)),n=I.GF.INT(e)
let s=E.M.IntToString(n)
if(1==E.M.Length(s))s=`0${s}`
else{s=E.M.SubStringWithLen(s,0,2)
const e=E.M.ToCharArray(s),t=E.M.Char2Int(e[0]),n=E.M.Char2Int("0"),a=new C.Z(2)
a[0]=t-n,a[1]=i,s=E.M.IntToString(a[0])+E.M.IntToString(a[1])}t+=s}else t+="00"
return t}static GetItemValidTime(e){if(null!=e.serverData_get()&&null!=e.serverData_get().deprecatedTime){const t=e.serverData_get().deprecatedTime.ToNum()
if(0!=t)return I.GF.INT(t/1e3)}return I.GF.INT32_MAX_VALUE_get()}static IsLimitTimeItem(e){if(null!=e.serverData_get()&&null!=e.serverData_get().deprecatedTime){
if(0!=e.serverData_get().deprecatedTime.ToNum())return!0}return!1}static GetEquipSortValue(e){
return e==I.GF.INT(R.C.ANGELWEAPON)?100:e==I.GF.INT(R.C.ANGELCLOTHES)?99:e==I.GF.INT(R.C.NECKLACE)?98:e==I.GF.INT(R.C.RINGS)?97:e==I.GF.INT(R.C.WINGS)?96:e==I.GF.INT(R.C.SUBWEAPON)?95:e==I.GF.INT(R.C.MAINWEAPON)||e==I.GF.INT(R.C.SINGLEWEAPON)||e==I.GF.INT(R.C.DOUBLEWEAPON)?94:e==I.GF.INT(R.C.CLOTHES)?93:e==I.GF.INT(R.C.HAT)?92:e==I.GF.INT(R.C.GLOVES)?91:e==I.GF.INT(R.C.PANTS)?90:e==I.GF.INT(R.C.BOOTS)?89:0
}static GetAdditionSortValue(e){
return e==I.GF.INT(R.C.MAINWEAPON)||e==I.GF.INT(R.C.SINGLEWEAPON)||e==I.GF.INT(R.C.DOUBLEWEAPON)?96:e==I.GF.INT(R.C.SUBWEAPON)?95:e==I.GF.INT(R.C.HAT)?94:e==I.GF.INT(R.C.CLOTHES)?93:e==I.GF.INT(R.C.GLOVES)?91:e==I.GF.INT(R.C.PANTS)?90:e==I.GF.INT(R.C.BOOTS)?89:0
}static isAngelEquip(e){if(null==e)return!1
if(null==e.cfgData_get())return!1
if(e.cfgData_get().itemType!=y.q.EQUIPMENT)return!1
const t=e.equipInfo_get()
return null!=t&&null!=t.Config_get()&&(t.Config_get().intPosition_get()==I.GF.INT(R.C.ANGELCLOTHES)||t.Config_get().intPosition_get()==I.GF.INT(R.C.ANGELWEAPON))}
static GetAttrTransferDirectionStr(e){
return 1==e?LangUtil.Inst().getStr(10655,eGameAllCSV.eLangResource):2==e?LangUtil.Inst().getStr(10656,eGameAllCSV.eLangResource):3==e?LangUtil.Inst().getStr(10657,eGameAllCSV.eLangResource):""
}static IsValueInRangeStr(e,t){let i=0,n=0
const s=E.M.Split(e,m.o.s_MID_CHAR)
return i=E.M.String2Int(s[0]),n=E.M.String2Int(s[1]),n<=i?(p.Y.LogError((0,o.T)("config表Id为：FAKETITLE:LEVEL_RESNAME配置区间错误，请检查!!!")),!1):t>=i&&t<=n}static getSuitImgByQuality(t){
return(t>=e.suitImgStrs.count||t<0)&&(t=0),e.suitImgStrs[t]}static GetStarBg2Width(e){return 86==e||80==e?20:78==e?19:76==e?18:70==e||66==e?16:56==e||52==e?14:20}
static GetStarBg2Height(e,t){
return 1==t?86==e||80==e?30:78==e?28:76==e||70==e||66==e?20:56==e||52==e?14:32:2==t?86==e?38:80==e?44:78==e?42:76==e||70==e?40:66==e?36:56==e?32:52==e?30:38:3==t?86==e?54:80==e?60:78==e?54:76==e?52:70==e?48:66==e?44:56==e?40:52==e?38:54:4==t?86==e||80==e?70:78==e?66:76==e?64:70==e?60:66==e?54:56==e?48:52==e?46:70:5==t?86==e?86:80==e?80:78==e?78:76==e?76:70==e?70:66==e?66:56==e?56:52==e?52:86:0
}static GetStarPos_New(e,t){const i=new J.P(0,0,0)
let n=0,s=0
return 86==e?(i.x=10,n=-10,s=15):80==e?(i.x=10,n=-10,s=14):78==e?(i.x=9,n=-9,s=14):76==e?(i.x=9,n=-9,s=13):70==e?(i.x=8,n=-8,s=12):66==e?(i.x=8,n=-8,s=11):56==e||52==e?(i.x=7,n=-7,
s=9):(i.x=10,n=-10,s=15),n-=s*t,i.y=n,i}static GetOneAttrStr(t,i){let n="",s=""
return 2004==t?s="":2005==t?s="1/":2006==t&&(s=(0,o.T)("等级/")),n=2004!=t&&2005!=t&&2006!=t?e.getAttrStr(t,!1,null)+e.getAttrValueStr(t,i,null,null):e.getAttrStr(t,!1,null)+(s+e.getAttrValueStr(t,i,null,null)),
n}static GetAttrStr(t){let i="",n=""
return 2004==t.intType?n="":2005==t.intType?n="1/":2006==t.intType&&(n=(0,o.T)("等级/")),
i=2004!=t.intType&&2005!=t.intType&&2006!=t.intType?e.getAttrStr(t.intType,!1)+e.getAttrValueStr(t.intType,t.value):e.getAttrStr(t.intType,!1)+(n+e.getAttrValueStr(t.intType,t.value)),
i}static JudgeTwoTimePaddingDay(e,t){const i=t-e
let n=0
return i>0&&(n=I.GF.INT(i/864e5)),n}static GetChineseCharNum(t){if(E.M.IsNullOrEmpty(t))return 0
const i=E.M.ToCharArray(t)
let n=0
for(const[t,s]of(0,l.V5)(i))e.isChineseCharacter(s)&&(n+=1)
return n}static isChineseCharacter(e){const t=E.M.Char2Int(e)
return t>=19968&&t<=40891}static GainGameName(){return e.IsEmptyStr(e.gameName)&&(e.gameName="MUS"),e.gameName}static GainLogoName(){{e.logoSpName=""
const t=AccoutModel.Instance,i=new C.Z(["1006218"]),n=new C.Z(["1006220"])
let s=0
for(;s<n.count;){if(n[s]==t.gid)return e.logoSpName="logo_sp_0005",e.logoSpName
s+=1}let a=0
for(;a<i.count;){if(i[a]==t.gid)return e.logoSpName="logo_sp_0004",e.logoSpName
a+=1}}return e.logoSpName}static GetDragAmount(e,t,i,n){return null==n&&(n=0),e<=i?0:e-t<=i-n?1:(t-n)/(e-i)}static GetRewardItems(e){const t=new C.Z
if(null!=e&&null!=e.rewards){let i=0
for(;i<e.rewards.Count();){const n=F.M.wrapReward(e.rewards[i])
t.Add(n),i+=1}}return t}static GetJobBranch(e){const t=I.GF.INT(e/1e3),i=e%10
if(1==t){if(1==i)return 1
if(2==i)return 3}else if(2==t){if(1==i)return 3
if(2==i)return 2}else if(3==t){if(1==i)return 2
if(2==i)return 3}return 0}static IsSkillMaxLevel(t){const i=N.f.Inst().getItemById(t).Rewards_get()
if(0!=i.typevalues.Count()){const t=i.typevalues[0].value,n=E.M.Split(t,":")
if(!e.IsEmptyStr(t)&&n.count>=1){const e=E.M.String2Int(n[0]),t=u.Y.Inst.primaryRoleInfoList
for(const[i,n]of(0,l.V5)(t))for(const[t,i]of(0,l.V5)(n.Skills_get()))if(i.id==e){const t=q.j.Inst().GetSkillByIdLevel(e,i.level)
if(i.level>=t.maxLevel)return!0}}}return!1}static IsSkillLearnedByItemId(t){const i=N.f.Inst().getItemById(t).Rewards_get()
if(0!=i.typevalues.Count()){const t=i.typevalues[0].value,n=E.M.Split(t,":")
if(!e.IsEmptyStr(t)&&n.count>=1){const e=E.M.String2Int(n[0]),t=u.Y.Inst.primaryRoleInfoList
for(const[i,n]of(0,l.V5)(t))for(const[t,i]of(0,l.V5)(n.Skills_get())){const t=me.C.INSTANCE.IsBreakJudge(e)
if(i.id==e)return!0
if(null!=t&&i.id==t)return!0}}}return!1}static ClearIntervals(...e){const t=[...e]
for(const[e,i]of(0,l.O6)(t))-1!=i&&$.C.Inst_get().ClearInterval(i)}static IsSameDate(e,t){
const i=pe.E.New(e),n=pe.E.New(t),s=i.fullYear_get()==n.fullYear_get()&&i.month_get()==n.month_get()&&i.date_get()==n.date_get()
return pe.E.Recycle(i),pe.E.Recycle(n),s}static ConcatStr(...t){return e.ConcatStrBySep(null,...t)}static ConcatStrBySep(e,...t){let i=[...t]
const n=table.concat(i,e)
return i=null,n}static GetDateFormat4(e){let t=""
const i=I.GF.INT(e/86400)
i>0&&(t+=i+(0,o.T)("天"),e%=86400)
const n=I.GF.INT(e/3600)
if(n>0&&(t+=n+(0,o.T)("小时"),e%=3600),i>0&&n>0)return t
const s=I.GF.INT(e/60)
return s>0&&(t+=s+(0,o.T)("分钟"),e%=60),""==t&&(t+=(0,o.T)("1分钟")),t}static GetNextFive(e){let t=pe.E.New(1e3*e)
const i=t.getHours()
let n=0,s=0,a=0
n=i<5?5-i-1:29-i-1,s=60-t.getMinutes()-1,a=60-t.getSeconds()
const r=e+3600*n+60*s+a
return pe.E.Recycle(t),t=null,r}static GetSecondsByStr(e){const t=E.M.Split(e,m.o.s_UNDER_COLON)
return 3600*E.M.String2Int(t[0])+60*E.M.String2Int(t[1])+E.M.String2Int(t[2])}static GetServerHMSTime(){const e=pe.E.New()
e.time_set(c.D.serverMSTime_get())
const t=3600*e.hours_get()+60*e.minutes_get()+e.seconds_get()
return pe.E.Recycle(e),t}static GetDayByTime(e){let t=""
const i=I.GF.INT(e/86400)
return i>0&&(t+=i+(0,o.T)("天")),""==t&&(t+=(0,o.T)("1天")),t}static GetDaysOfDifferenceBySeconds(t,i){const n=e.GetDaysBySeconds(t,i)
return e.GetDaysBySeconds(c.D.serverMSTime_get()/1e3,i)-n}static GetDayOffBySeconds(t,i=null){return e.GetDaysOfDifferenceBySeconds(t,i)+1}static GetDaysBySeconds(e,t){
null==t&&(t=0)
let i=pe.E.New(1e3*e)
return i.getHours()<t&&(e-=86400),i=pe.E.New(1e3*e),i.hours_set(0),i.minutes_set(0),i.seconds_set(0),I.GF.INT(i.time_get()/1e3/86400)}CreateRoleInfo(e,t){const i=new h.H
if(null!=e?(i.TitleId_set(e.TitleId_get()),i.AsuramId_set(e.AsuramId_get()),null==i.AsuramId_get()&&i.AsuramId_set(X.o.New(0,0)),i.FightStage_set(e.FightStage_get()),
i.Fashions_set(e.Fashions_get()),i.SacredEquipWearing_Set(e.SacredEquipWearing_Get()),i.VipLevel_set(e.VipLevel_get()),i.DisplayId_set(e.DisplayId_get()),i.Job_set(e.Job_get()),
i.Sex_set(e.Sex_get()),i.Name_set(e.Name_get()),i.Level_set(e.Level_get())):i.Name_set(""),null!=t){const e=new S.X,i=new b.v
i.talentIds=new C.Z,i.masterLevel=0,i.addMasterLevel=0,i.unlockColumn=!0,i.elementMasterLevel=0,e[0]=i
const n=new G.U
n.equipmentVOs=new S.X
for(const[e,s]of(0,l.vy)(t)){const s=t[e]
i.equipmentsGet()[e]=s
const a=new U.H
a.itemModelId=s.modelId,a.excellenceAttributeModels=s.exellectAttrs,a.enhanceLevel=0,a.isShowVO=!0,a.isEffective=s.isEffective,n.equipmentVOs[e]=a}
}else null!=e&&(i.equipmentStorageVO=e.equipmentStorageVO)
return i.equipmentStorageVO=equipmentStorageVO,i.Equipments_set(t),i.AllStageEquipments_set(allStageEquipments),i}static CalCharDisFastXZ(e,t){
const[i,n,s]=e.GetPosXYZ(),[a,r,l]=t.GetPosXYZ()
return d.A.DistanceFastXZ(i,n,s,a,r,l)}static CheckFastCharDisFastXZ(t,i,n){return n*n>=e.CalCharDisFastXZ(t,i)}static CheckFastCharToXZDisFast(e,t,i,n){const[s,a,r]=e.GetPosXYZ()
return n*n>=d.A.DistanceFastXZ(s,0,r,t,0,i)}static CalFastCharToXZDisFast(e,t,i){const[n,s,a]=e.GetPosXYZ()
return d.A.DistanceFastXZ(n,0,a,t,0,i)}static FastDistanceVector3XZ(e,t){return(e.x-t.x)*(e.x-t.x)+(e.z-t.z)*(e.z-t.z)}static FastDistanceXZ(e,t,i,n){return(e-i)*(e-i)+(t-n)*(t-n)}
static FindPathEndPosOffsetDis(t,i,n,s,a){const r=n
n*=n
const l=t.length
if(l>0){const o=t[l-1]
let _=e.FastDistanceVector3XZ(o,i)
if(_>n/2)return t
if(1!=l&&(s=t[l-2].x,a=t[l-2].z),_=d.A.DistanceFastXZ(s,0,a,i.x,0,i.z),n>_)return t.splice(l-1,1),t
const u=t[l-1]
_=e.FastDistanceVector3XZ(u,i),_=r-Math.sqrt(_)
const h=t[l-1],c=d.A.DistanceFastXZ(s,0,a,h.x,0,h.z),m=_/Math.sqrt(c),p=h.x+(s-h.x)*m,g=h.z+(a-h.z)*m
t[l-1]=new J.P(p,0,g)}return t}static FindPathEndPosOffsetByPrimary(t,i,n){const s=u.Y.Inst.PrimaryRole_get()
if(s.inMove()&&null!=s.m_vLastMovePathEX&&s.m_vLastMovePathEx.count>0){const a=s.m_vLastMovePathEX[s.m_vLastMovePathEx.count-1]
return e.FindPathEndPosOffsetDis(t,i,n,a.x,a.z)}const[a,r,l]=s.GetPosXYZ()
return e.FindPathEndPosOffsetDis(t,i,n,a,l)}static GetRandomPosCanArriveByRing(e,t,i,n){null==n&&(n=20)
let s=0,a=0,r=0
for(;;){let l
s+=1,a=g.p.RandomMinMax(e.x-i,e.x+i),r=g.p.RandomMinMax(e.z-i,e.z+i),l=new J.P(a-e.x,0,r-e.z),l=J.P.Normalize(l)
const o=g.p.RandomMinMax(t,i)
if(a=l.x*o+e.x,r=l.z*o+e.z,z.c.Instance_get().CanArrive(a,r))break
if(s==n){a=e.x,r=e.z
break}}return[a,0,r]}static GetPosBetweenTwoPos(e,t,i,n){const s=J.P.Sub(t,e)
s.y=0
const a=Math.random()*(n-i)+i
return s.Normalize(),J.P.multiplyScalar(s,s,a).add(e)}static GetPosOnCircelNoLineBlock(t,i,n,s){if(re.I.calVec0.Set(t,0,i),1!=s){
for(let s=0;s<=7;s++)if(e.GotoPosByDirAndRand(s,re.I.calVec0,n),!z.c.Instance_get().IsLineBlock(re.I.calVec0.x,re.I.calVec0.z,t,i))return[re.I.calVec0.x,re.I.calVec0.z]}else{
let s=7
for(;s>=0;){if(e.GotoPosByDirAndRand(s,re.I.calVec0,n),!z.c.Instance_get().IsLineBlock(re.I.calVec0.x,re.I.calVec0.z,t,i))return[re.I.calVec0.x,re.I.calVec0.z]
s-=1}}return[t,i]}static GotoPosByDirAndRand(e,t,i){const n=1.414
0==e?t.x+=i:1==e?(t.x+=i/n,t.z+=i/n):2==e?t.z+=i:3==e?(t.x+=i/n,t.z-=i/n):4==e?t.z-=i:5==e?(t.x-=i/n,t.z-=i/n):6==e?t.x-=i:7==e&&(t.x-=i/n,t.z+=i/n)}static IsLineBlock(e,t){
const[i,n]=e.GetPosXZ(),[s,a]=t.GetPosXZ()
return z.c.Instance_get().IsLineBlock(i,n,s,a)}static GetBagItemListByAb(e){if(null==e)return null
const t=new C.Z
for(let i=0;i<=e.length-1;i++){const n=new BagItemData
n.serverData_set(e[i]),n.baseData_get().isNoBagItemData=!0,n.baseData_get().isCanOperate=!1,t.Add(n)}return t}static GetExpString(t,i){if(ce.X.Inst_get().multiHangState==he.O.On){
let n="",s=""
return i>0?(n=E.M.s_LEFT_S_K_CHAR+(m.o.s_ADD_STR+(E.M.IntToString(i)+m.o.s_UNDER_PERCENT)),s="x"):s=E.M.s_LEFT_S_K_CHAR,
s+=E.M.IntToString(ce.X.Inst_get().buffAddExp)+(m.o.s_UNDER_PERCENT+E.M.s_RIGHT_S_K_CHAR),`E${E.M.DoubleToString(t)+(n+e.ChangeExpStringYellow(s))}`}
return i<=0?`E${E.M.DoubleToString(t)}`:`E${E.M.DoubleToString(t)+(E.M.s_LEFT_S_K_CHAR+(m.o.s_ADD_STR+(E.M.IntToString(i)+(m.o.s_UNDER_PERCENT+E.M.s_RIGHT_S_K_CHAR))))}`}
static ChangeExpStringYellow(e){const t=new j.H
for(let i=1;i<=e.length;i++){const n=string1.sub(e,i,i)
n==m.o.s_ADD_STR?t.Append("k"):n==E.M.s_LEFT_S_K_CHAR?t.Append("l"):n==E.M.s_RIGHT_S_K_CHAR?t.Append("m"):n==m.o.s_UNDER_PERCENT?t.Append("n"):"x"==n?t.Append("x"):t.Append(string1.char(string1.byte(n)+49))
}return t.ToString()}static GetAttrIconByAttrType(e){const t=v.X.Inst().getItemById(e)
return null!=t?t.attrIcon:""}static GetTimeOffset(e){return e-se.os.timeMS()}static OverTime(t){return e.GetTimeOffset(t)<0}static GetSuitExQualityNameByQuality(e){
return 0==e?"普通":1==e?"优秀":2==e?"精良":3==e?"卓越":4==e?"史诗":5==e?"传说":""}static GetCommonTabSpriteName(e,t){
return"世界首领"==e||"黄金首领"==e?"ryyeqian_sp_0017":"卡利玛神庙"==e?"ryyeqian_sp_0009":"特权首领"==e?"ryyeqian_sp_0007":"强 化"==e?"ryyeqian_sp_0014":"追 加"==e?"ryyeqian_sp_0025":"幸运附加"==e?"ryyeqian_sp_0021":"翅膀精炼"==e?"ryyeqian_sp_0003":"信 息"==e?"ryyeqian_sp_0020":"建 筑"==e?"ryyeqian_sp_0013":"属 性"==e?"ryyeqian_sp_0019":"坐 骑"==e?"ryyeqian_sp_0026":"合 成"==e?"ryyeqian_sp_0008":"背 包"==e?"ryyeqian_sp_0002":"商 城"==e?"ryyeqian_sp_0016":"技 能"==e?"ryyeqian_sp_0010":"技能装配"==e?"ryyeqian_sp_0012":"技能修炼"==e?"ryyeqian_sp_0011":"充值"==e?"ryyeqian_sp_0004":"市 场"==e||"罗兰市场"==e?"ryyeqian_sp_0018":"摆 摊"==e?"ryyeqian_sp_0001":"战力排行"==e?"ryyeqian_sp_0023":"等级排行"==e?"ryyeqian_sp_0005":"职业排行"==e?"ryyeqian_sp_0024":"坐骑排行"==e?"ryyeqian_sp_0027":"装备排行"==e?"ryyeqian_sp_0040":"战士排行"==e?"ryyeqian_sp_0041":"法师排行"==e?"ryyeqian_sp_0042":"弓手排行"==e?"ryyeqian_sp_0043":"剑士一转"==e||"魔法师一转"==e||"弓箭手一转"==e?"ryyeqian_sp_0022":"剑士二转"==e||"魔法师二转"==e||"弓箭手二转"==e?"ryyeqian_sp_0006":"剑士三转"==e||"魔法师三转"==e||"弓箭手三转"==e?"ryyeqian_sp_0015":"转生天赋"==e?"ryyeqian_sp_0048":"一机多开"==e?"ryyeqian_sp_0055":"添加装备位"==e?"ryyeqian_sp_0054":"自动日常"==e?"ryyeqian_sp_0053":"战 勋"==e?"ryyeqian_sp_0012":"卓越进阶"==e?"ryyeqian_sp_0058":"珍宝阁"==e?"ryyeqian_sp_0051":"积分兑换"==e?"ryyeqian_sp_0052":"罗兰战场"==e?"ryyeqian_sp_0059":"元 素"==e?"ryyeqian_sp_0060":"涤罪之路"==e?"ryyeqian_sp_0061":"元素刻印"==e?"ryyeqian_sp_0062":null
}static GetAddExpCanLevelUp(e){const t=u.Y.Inst.PrimaryRoleInfo_get()
let i=0,n=0,s=t.Exp_get().ToNum(),a=t.Level_get(),r=!1,l=!1
const o=B.g.ins.GetVoByLevel(a).id
for(;e>0;){const t=M.L.Inst().getItemById(a).exp-s,_=B.g.ins.GetVoByLevel(a+1),u=null!=_&&_.id||-1
e>=t?(s=0,o==u?(i+=1,a+=1,e-=t):(n=t,e=0,r=!0,-1==u&&(l=!0))):(n=e,e=0)}return[i,n,r,l]}static GetIntArrayFromStr(e){if(""!=e){
const t=E.M.SubStringWithEnd(e,1,E.M.Length(e)-1),i=E.M.Split(t,m.o.s_Arr_UNDER_CHAR_DOU),n=new C.Z
for(let e=0;e<=i.Count()-1;e++)n.Add(E.M.String2Int(i[e]))
return n}return null}static CalcLineCross(e,t,i,n,s,a,r,l){const o=J.P.New()
let _=0,u=0
e==i?_=null:(_=(n-t)/(i-e),u=t-_*e)
let h=0,c=0
return s==r?h=null:(h=(l-a)/(r-s),c=a-h*s),null==_&&null==h?null:(null==_?(o.x=e,o.z=e*h+c):null==h?(o.x=s,o.z=s*_+u):(o.x=(c-u)/(_-h),o.z=_*o.x+u),o)}
static GetAttackRuleDecimalVal(t,i=null,n=null){if(null==n&&(n=!0),null==i&&(i=1),t<=9999999)return`${I.GF.INT(t)}`
if(t>9999999&&t<=99999999){let s=0
return n&&(s=i),e.MathRound(t/1e4,s)+(0,ne._T)("万")}return t>99999999&&t<=999999999999?e.MathRound(t/1e8,i)+(0,o.T)("亿"):t>999999999999?e.MathRound(t/1e12,i)+(0,o.T)("万亿"):""}
static GetStrLen(e,t=!1){const i=e.length
let n=0,s=1
for(;s<=i;){const i=E.M.Byte(e,s)
let a=1
i>0&&i<=127?a=1:i>=192&&i<=223?a=2:i>=224&&i<=239?a=3:i>=240&&i<=247&&(a=4),s+=a,1==a?32==i&&t||(n+=1):n+=2}return n}static GetColName(e){var t=0
return t="string"==typeof e?parseInt(e)+3:e+3,`${E.M.IntToString(t)}阶`}static GetWeekPresent(t,i,n){null==i&&(i=!0),null==n&&(n=!0)
let s=""
const a=new pe.E
a.time_set(t)
const r=a.day_get(),l=new pe.E
l.time_set(c.D.serverMSTime_get())
const o=864e5*(6-l.day_get()+1),_=e.GetTodayLastTime(c.D.serverMSTime_get())
return t>c.D.serverMSTime_get()+o+_&&(s+="下"),s+=e.GetDayStr(r),i&&(s+=e.AddFrontZeroFromNum(2,a.hours_get())),n&&(s+=`:${e.AddFrontZeroFromNum(2,a.minutes_get())}`),s}
static GetTodayLastTime(e){const t=new pe.E
return t.time_set(e),t.minutes_set(59),t.seconds_set(59),t.hours_set(23),t.time_get()+1e3-e}static ReplaceAllAByB(e,t,i){for(;E.M.IndexOf(e,t,0)>=0;)e=E.M.ReplaceSlow(e,t,i)
return e}static UnityMapPos2CocosMapPos(e,t,i){let n=ge.getMapMatrix(e),s=ge.getMapHeight(e)
const a=ge.getMapCameraOrtSize(e)
new ee.Vec4(t,s,i,1)
let r=t*n.m00+s*n.m04+i*n.m08+n.m12,l=t*n.m01+s*n.m05+i*n.m09+n.m13,o=new ee.Vec2(.5*r+.5,.5*l+.5)
return o.x=1.28*o.x*(2*a),o.y=.72*o.y*(2*a),[o.x,o.y]}static CocosMapPos2UnityMapPos(e,t,i){let n=ge.getMapMatrix(e)
if(!n)return[t,i]
let s=ge.getMapHeight(e)
const a=ge.getMapCameraOrtSize(e)
t=2*(t/1.28/(2*a)-.5),i=2*(i/.72/(2*a)-.5)
const r=n.m00/n.m01*(i-n.m13-s*n.m05),l=(t-n.m12-s*n.m04-r)*n.m01/(n.m08*n.m01-n.m00*n.m09)
return[(t-l*n.m08-n.m12-s*n.m04)/n.m00,l]}static setComponentPosByNode(e,t,i,n=!1){if(e){var s=e.getPosition().x+t,a=e.getPosition().y+i,r=e.getPosition().z
e.setPosition(s,a,r)}}
},s.qualityImgStrs=new C.Z(["atlas/common/rycommon_sp_0053","atlas/common/rycommon_sp_0055","atlas/common/rycommon_sp_0056","atlas/common/rycommon_sp_0057","atlas/common/rycommon_sp_0060","atlas/common/rycommon_sp_0058","atlas/common/rycommon_sp_0059"]),
s.wingqualityColorStrs=new C.Z(["","","",(0,o.T)("精良品质"),(0,o.T)("卓越品质"),(0,o.T)("史诗品质"),(0,o.T)("传说品质")]),
s.forgeQualityImgStrs=new C.Z(["atlas/zuoqi/ryzuoqi_sp_0003","atlas/zuoqi/ryzuoqi_sp_0007","atlas/zuoqi/ryzuoqi_sp_0008","atlas/zuoqi/ryzuoqi_sp_0002","atlas/zuoqi/ryzuoqi_sp_0006","atlas/zuoqi/ryzuoqi_sp_0005","atlas/zuoqi/ryzuoqi_sp_0004"]),
s.txtGrayColor=new T.I(.5882353,.5607843,.5294118),s.txtOrangeColor=new T.I(.8862,.6509,.4156),s.txtGreenStr="5fb470",s.txtGreenColor=new T.I(.149,.7921,.2117),
s.txtYellowStr="f4e2b3",s.txtYellowColor=new T.I(.9568,.8862,.7019),s.txtRedStr="d43e3e",s.txtRedColor=new T.I(.7921,.149,.149),s.txtRedStr2="[962424]",s.txtGreenStr2="[047104]",
s.greenColorStr="[047104]",s.excellenceColorLevel=null,s.suitImgStrs=new C.Z(["","","","","comm_sp_0225","comm_sp_0226"]),s.RY_MON_ICON_PRE="rymonster",s.ZEROS="0000000000",
s.DanWeiDecima=new C.Z([1e12,1e8,1e4]),s.DanWeis=new C.Z(["万亿","亿","万"]),s.gameName=null,s.logoSpName=null,n=s))||n},94650:(e,t,i)=>{"use strict"
i.d(t,{h:()=>p})
var n=i(38836),s=i(86133),a=i(23833),r=i(98800),l=i(70829),o=i(66788),_=i(35128),u=i(98885),h=i(75439),c=i(19276),d=i(70415),m=i(77477)
class p{GetBossSkillDmgRate(e){const t=a.a.getInst().getObjById(e),i=t.skillWeights.datalis
d.i.Inst().getItemById(e)
let s=null
if(null!=i&&i.Count()>0){let e=0
for(const[i,a]of(0,n.V5)(t.skillWeights.datalis))s=l.j.Inst().GetSkillByStrId(a.id),e+=s.pveMainHurtRate*a.weightPercent
return e}return 0}GetPlayerBaseMultiAtkSkillId(){const e=r.Y.Inst.PrimaryRoleInfo_get().Skills_get()
let t="",i=0
for(const[s,a]of(0,n.vy)(e)){const n=l.j.Inst().GetSkillByIdLevel(e[s].id,e[s].level)
if(null!=n&&n.cd<=300&&n.maxTarget>1){const e=n.pveMainHurtRate*n.maxTarget
e>i&&(i=e,t=tempId)}}return t}GetPlayerBaseSingleAtcSkillId(){const e=r.Y.Inst.PrimaryRoleInfo_get().Skills_get()
let t="",i=0
for(const[s,a]of(0,n.vy)(e)){const n=l.j.Inst().GetSkillByIdLevel(e[s].id,e[s].level)
if(null!=n&&n.cd<=300&&1==n.maxTarget){const e=n.pveMainHurtRate
e>i&&(i=e,t=tempId)}}return t}GetPerSecsSingleAtkSkillExtraDmgRate(){const e=r.Y.Inst.PrimaryRoleInfo_get().Skills_get(),t=p.GetPlayerBaseSingleAtcSkillId()
let i=0
const s=l.j.Inst().GetSkillByStrId(t,!1)
null!=s&&(i=s.pveMainHurtRate)
let a=0
for(const[t,r]of(0,n.vy)(e)){const n=l.j.Inst().GetSkillByIdLevel(e[t].id,e[t].level)
n.cd>300&&(a+=n.perdamage-(1+_.p.Max(0,n.skillFrame-p.publicCd_get())/p.publicCd_get())*i/_.p.Max(1,s.skillFrame/p.publicCd_get())/_.p.Max(1,n.cd))}return a}static publicCd_get(){
if(-1==p.m_publicCd){const e=h.D.getInstance().getContent("ONHOOK:PUBLIC_CD_FRAME")
p.m_publicCd=u.M.String2Int(e.getContent().stringVal)}return p.m_publicCd}GetPerSecsMultiAtkSkillExtraDmgRate(){
const e=r.Y.Inst.PrimaryRoleInfo_get().Skills_get(),t=p.GetPlayerBaseMultiAtkSkillId()
let i=0
const s=l.j.Inst().GetSkillByStrId(t,!1)
null!=s&&(i=s.pveMainHurtRate)
let a=0
for(const[t,s]of(0,n.vy)(e)){const n=l.j.Inst().GetSkillByIdLevel(e[t].id,e[t].level)
n.maxTarget>1&&n.cd>300&&(a+=n.perdamage-i/Math.max(1,n.cd/1e3))}return a}GetPerSecsSingleAtkSkillDmgRate(){
const e=r.Y.Inst.PrimaryRoleInfo_get(),t=p.GetPlayerBaseSingleAtcSkillId(),i=l.j.Inst().GetSkillByStrId(t,!1)
let n=0
null!=i&&(n=i.pveMainHurtRate)
const s=p.GetPerSecsSingleAtkSkillExtraDmgRate()
return n/_.p.Max(1,i.skillFrame/p.publicCd_get())*p.GetRealAttackSpeed(e.getAttribute(m.Z.AttackSpeed))+s}GetPerSecsMultiAtkSkillDmgRate(){
const e=r.Y.Inst.PrimaryRoleInfo_get(),t=p.GetPlayerBaseMultiAtkSkillId(),i=l.j.Inst().GetSkillByStrId(t,!1)
let n=0
null!=i&&(n=i.pveMainHurtRate)
const s=p.GetPerSecsMultiAtkSkillExtraDmgRate()
return n*p.GetRealAttackSpeed(e.getAttribute(m.Z.AttackSpeed))+s}GetPlayerDieSecs(e){
const t=d.i.Inst().getItemById(e),i=r.Y.Inst.PrimaryRoleInfo_get(),n=p.GetLevelStifleRatio(i,e),s=t.attack,a=i.getAttribute(m.Z.Defense),l=t.monsterAttackInterval,o=p.GetBossSkillDmgRate(e)/1e4,u=i.getAttribute(m.Z.DamageDown)
return i.MaxHp_get()/_.p.Max(1,1e3*(s*(1+n)-a/2)/l*o*(1-u/1e4))}static GetLevelStifleRatio(e,t){const i=a.a.getInst().getObjById(t)
null==i&&o.Y.LogError((0,s.T)("OBJECTRESOURCE表中不存在:")+u.M.IntToString(t))
const n=e.Level_get(),r=i.level,l=i.stifleLevelDiff,h=i.everyLevStifleRatio/1e4,c=i.baseStifleRatio/1e4
return _.p.Max(0,(r-n-l)*h)+_.p.Min(1,_.p.Max(0,_.p.FloorToInt((r-n)/l)))*c}GetBossDiesSecs(e){const t=d.i.Inst().getItemById(e),i=(c.C.Inst().GetItemByMonsterId(e),
r.Y.Inst.PrimaryRoleInfo_get()),n=t.maxHp,s=i.getAttribute(m.Z.Attack),a=t.defense,l=p.GetPerSecsSingleAtkSkillDmgRate()/1e4
return n/_.p.Max(1,(s-a/2)*l)}static GetRealAttackSpeed(e){return 1/Math.max(.3,1-.25*Math.sqrt(e/25))}}p.m_publicCd=-1},94826:(e,t,i)=>{"use strict"
i.d(t,{C:()=>o})
var n=i(38962),s=i(79534),a=i(18998),r=i(5924)
class l{constructor(e,t,i){this.objId=0,this.obj=null,this.intervalId=-1,this.initVec=null,this.isAlphaControl=!1,this.isFakeActive=!1,this.hasSetActive=!1,this._degf_Handle=null,
this.initVec=s.P.zero_get(),this._degf_Handle=()=>this.Handle(),this.objId=e,this.obj=t,this.isAlphaControl=i
let n=new a.Vec3
n=t.transform.GetLocalPosition(),this.initVec=n}SetFakeActive(e,t){r.C.Inst_get().ClearInterval(this.intervalId),this.hasSetActive=!0,this.isFakeActive=e,null==t&&(t=!0),
e?this.obj.SetActive(!0,this.isAlphaControl,t):(this.obj.SetActive(!1,this.isAlphaControl,t),this.intervalId=r.C.Inst_get().SetInterval(this._degf_Handle,o.delay,1))}Handle(){
null!=this.obj&&this.obj.SetActive(!1,!0)}Clear(){r.C.Inst_get().ClearInterval(this.intervalId),this.intervalId=-1,this.obj=null}}class o{static Inst_get(){
return null==o.inst&&(o.inst=new o),o.inst}RegisterObj(e,t,i){null==i&&(i=!1)
let n=null
o.objDic.LuaDic_ContainsKey(e)?(o.objDic.LuaDic_Remove(e),n=new l(e,t,i),o.objDic.LuaDic_AddOrSetItem(e,n)):(n=new l(e,t,i),o.objDic.LuaDic_AddOrSetItem(e,n))}UnregisterObj(e){
if(!o.objDic.LuaDic_ContainsKey(e))return
o.objDic[e].Clear(),o.objDic.LuaDic_Remove(e)}SetActiveById(e,t,i){if(!o.objDic.LuaDic_ContainsKey(e))return
null==i&&(i=!0),o.objDic[e].SetFakeActive(t,i)}IsActiveById(e){if(!o.objDic.LuaDic_ContainsKey(e))return!1
const t=o.objDic[e]
return!!t.hasSetActive&&t.isFakeActive}ResetData(){}}o.inst=null,o.delay=18e4,o.farPos=new s.P(0,5e3,0),o.objDic=new n.X},57940:(e,t,i)=>{"use strict"
i.d(t,{k:()=>n})
var n={sceneTouchView:1,changeAttrView:2,systemTipView:3,buffView:4,riverAndLakeView:5,simpleNotice:6,getEquipTip:7,getItemTip:8,fullBagTip:9,buyMedicineTip:10,
marketAttentionTip:11,bossRefreshTip:12,battleScoreAnimeView:13,taskFinishEffect:14,hangStartIcon:15,offlineTip:16,sysChanPanelView:17,activityTip:18,unlockEquipTip:19,
scoreSellTip:20,auctionItemTip:21,asuramAuctionTip:23,goldWarBossRefreshTip:24,scannerMsgView:25,bgObjView:26,attrPointTip:27,ryAllianceActivityTip:28}},27122:(e,t,i)=>{
"use strict"
i.d(t,{Q:()=>u})
var n=i(38836),s=i(66788),a=i(95721),r=(i(26133),i(85602)),l=i(38962),o=i(52212),_=i(79534)
class u{constructor(){this.commPoolDic=null,this.commCountDic=null,this.commPoolDic=new l.X,this.commCountDic=new l.X,
this.commCountDic.LuaDic_AddOrSetItem("LuaElementCombineLocation",30),this.commCountDic.LuaDic_AddOrSetItem("DoubleAttackHurtVo",10),
this.commCountDic.LuaDic_AddOrSetItem("MonsterInfo",20)}static Inst(){return null==u.inst&&(u.inst=new u),u.inst}Recycle(e,t){}static AddRecycleCheck(e){const t=getmetatable(e)
rawset(e,"__reclye_stack",debug.traceback())
const i={__index:(e,i)=>{const n=t.__index[i]
return s.Y.LogError(`Recycled Obj can not call ,isRecycle:${ToString(rawget(e,"isRecycle"))}m_destroyed:${ToString(rawget(e,"m_destroyed"))} \nrecycle_stack:${rawget(e,"__reclye_stack")}`),
setmetatable(e,t),n},__ResetMeta:e=>{setmetatable(e,t)}}
setmetatable(e,i)}static RemoveRecycleCheck(e){}GetObjectByName(e,t,...i){let n=null
return this.commPoolDic.LuaDic_ContainsKey(e)&&0!=this.commPoolDic[e].Count()&&(n=this.commPoolDic[e].Pop()),null==n?n=new t(...i):(t._init_&&t._init_(n,...i),n.isRecycle=!1),n}
RecycleCListContent(e,t){if(null!=t){if("Vector3"==e)for(const[e,i]of(0,n.V5)(t))_.P.Recyle(i)
else if("Vector2"==e)for(const[e,i]of(0,n.V5)(t))o.F.Recycle(i)
else if("LusuoLong"==e)for(const[e,i]of(0,n.V5)(t))a.o.Recyle(i)
t.Clear()}}RecycleCList(e,t){this.RecycleCListContent(e,t),r.Z.Recyle(t)}RecycleCListData(e,t){this.RecycleCListContent(e,t)}RecycleDicContent(e,t,i){if(null!=i){
for(const[s,r]of(0,n.vy)(i))"Vector3"==e?_.P.Recyle(s):"Vector2"==e?o.F.Recycle(s):"LusuoLong"==e&&a.o.Recyle(s),
"Vector3"==t?_.P.Recyle(i[s]):"Vector2"==t?o.F.Recycle(i[s]):"LusuoLong"==t&&a.o.Recyle(i[s])
i.Clear()}}RecycleDic(e,t,i){this.RecycleDicContent(e,t,i),l.X.Recyle(i)}}u.inst=null},41748:(e,t,i)=>{"use strict"
i.d(t,{l:()=>n})
class n{constructor(){this.dataList=null,this.selectData=null,this.handler=null}}},3256:(e,t,i)=>{"use strict"
i.d(t,{R:()=>n})
class n{constructor(){this.key=0,this.showStr="",this.isFinal=!1,this.handler=null,this.guideId=null,this.guideParam=null}}},35280:(e,t,i)=>{"use strict"
i.d(t,{h:()=>n})
class n{constructor(){this.key=1,this.objCls=null,this.count=0,this.buf={},this.lastGetTime=0,this.minCount=0,this.maxPoolCount=32}GetObj(...e){let t=null
const i=this.count
return i>0?(t=this.buf[i],this.buf[i]=null,this.count=i-1,this.count<this.minCount&&(this.minCount=this.count)):t=new this.objCls(...e),t}RecycleObj(e){const t=this.count
t<this.maxPoolCount&&(this.buf[t+1]=e,this.count=t+1)}Tick(){this.count
for(let e=1;e<=this.minCount-1&&this.count>0;e++)this.buf[this.count]=null,this.count-=1
this.minCount=this.count}}},15696:(e,t,i)=>{"use strict"
i.d(t,{A:()=>h})
var n=i(18998),s=i(75507),a=i(38836),r=i(66788),l=i(85602),o=i(38962),_=i(59075),u=i(28170)
class h{static __StaticInit(){}constructor(){this.item_pool=null,this.COLUMN_CNT=6,this.ROW_CNT=5,this.SPACE=6,this.ITEM_SIZE=70,this.ICON_SIZE=66.5,this.ICON_MAX_CNT=4,
this.CAPACITY=300,this.MIN_CAPACITY=100,this.CAPACITY_FIT_ITEMLIST=!0,this.grid=null,this.grid_bg=null,this.bar=null,this.scroll_view=null,this.item_datas=null,
this.show_item_dict=null,this.startShowIndex=0,this.endShowIndex=0,this.m_handlerMgr=null,this.m_ItemPath=null,this.m_ItemCls=null,this.m_uidata=null,this.item_pool=new l.Z,
this.show_item_dict=new o.X}Init(e,t,i,n,s,a,r,l){this.m_handlerMgr=e,this.grid=t,this.grid_bg=i,this.bar=n,this.scroll_view=s,this.m_ItemPath=a,this.m_ItemCls=r,this.bar.value=0}
InitLayoutParam(e,t,i,n,s,a,r){[this.COLUMN_CNT,this.ROW_CNT,this.SPACE,this.ITEM_SIZE,this.ICON_SIZE,this.MIN_CAPACITY,this.CAPACITY_FIT_ITEMLIST]=[e,t,i,n,s,a,r],
this.m_uidata=new u.X,this.m_uidata.ITEM_SIZE=this.ITEM_SIZE,this.m_uidata.ICON_SIZE=this.ICON_SIZE,this.m_uidata.SPACE=this.SPACE,this.m_uidata.showQuipGird=!0,
a&&this.SetCapatity(a)}SetData(e){const t=this.GetShowListByClient(e)
this.item_datas=t,this.Update()}AddDataToIndex(e,t){let i
if(i=e.shape_get?e.shape_get():e.baseData_get().cfgData_get().shape,this.CAPACITY_FIT_ITEMLIST){const e=_.u.SHAPE_DEFINE.LuaDic_GetItem(i)[1],n=Math.ceil((t+1)/this.COLUMN_CNT)
this.SetCapatity((n+e-1)*this.COLUMN_CNT)}return!!this.CanPutIn(i,t,this.item_datas,this.COLUMN_CNT)&&(this.PutIn(e,i,t,this.item_datas,this.COLUMN_CNT),this.Update(),!0)}
AddDataListFromRightTop(e){for(const[t,i]of(0,a.V5)(e)){let e
e=i.shape_get?i.shape_get():i.baseData_get().cfgData_get().shape
let t=this.COLUMN_CNT-1
for(;t<this.CAPACITY&&0==this.CanPutIn(e,t,this.item_datas,this.COLUMN_CNT);)t%this.COLUMN_CNT==0?t=t+2*this.COLUMN_CNT-1:t-=1
t<this.CAPACITY&&this.PutIn(i,e,t,this.item_datas,this.COLUMN_CNT)}this.Update()}CheckCanAddItem(e){let t
t=e.shape_get?e.shape_get():e.baseData_get().cfgData_get().shape
let i=0
for(;i<this.CAPACITY&&0==this.CanPutIn(t,i,this.item_datas,this.COLUMN_CNT);)i+=1
return i<this.CAPACITY}GetStartEndItem(){return[this.show_item_dict[this.startShowIndex],this.show_item_dict[this.endShowIndex]]}SetCapatity(e){
this.MIN_CAPACITY&&e<this.MIN_CAPACITY&&(e=this.MIN_CAPACITY),this.CAPACITY=e
const t=new l.Z
for(let i=1;i<=e;i++)t.Add(i)
this.grid_bg.data_set(t)}PutIn(e,t,i,n,s){const a=_.u.SHAPE_DEFINE.LuaDic_GetItem(t)[0]-1,r=_.u.SHAPE_DEFINE.LuaDic_GetItem(t)[1]-1
n[i]=e
for(let e=0;e<=a;e++)for(let t=0;t<=r;t++)(e>0||t>0)&&(n[i+e+t*s]=1)}CanPutIn(e,t,i,n){const s=_.u.SHAPE_DEFINE.LuaDic_GetItem(e)[0]-1,a=_.u.SHAPE_DEFINE.LuaDic_GetItem(e)[1]-1
if(t%n+s>=n)return!1
for(let e=0;e<=s;e++)for(let s=0;s<=a;s++){const a=t+e+s*n
if(a>=this.CAPACITY||null!=i[a])return!1}return!0}GetShowListByClient(e){const t=new l.Z
let i=0,n=0
this.CAPACITY_FIT_ITEMLIST&&(this.CAPACITY=999999)
for(let s=0;s<=e.Count()-1;s++){const a=e[s]
if(null!=a){let e
for(e=a.shape_get?a.shape_get():a.baseData_get().cfgData_get().shape,i=0;i<this.CAPACITY&&0==this.CanPutIn(e,i,t,this.COLUMN_CNT);)i+=1
i<this.CAPACITY?(n<i&&(n=i),this.PutIn(a,e,i,t,this.COLUMN_CNT)):r.Y.LogWarning(" some item not show")}}if(this.CAPACITY_FIT_ITEMLIST){t.Count()-1>i&&(n=t.Count()-1)
const e=Math.ceil((n+1)/this.COLUMN_CNT)
this.SetCapatity(e*this.COLUMN_CNT)}for(let e=0;e<=t.Count()-1;e++)t[e]
return t}Update(){let e=0,t=(this.ROW_CNT+this.ICON_MAX_CNT)*this.COLUMN_CNT
const i=this.bar.value
i>0&&(e=Math.ceil((this.CAPACITY-this.COLUMN_CNT*this.ROW_CNT)*i),t=e+this.COLUMN_CNT*this.ROW_CNT+this.ICON_MAX_CNT*this.COLUMN_CNT,e-=this.ICON_MAX_CNT*this.COLUMN_CNT,
e<0&&(e=0),t>=this.CAPACITY&&(t=this.CAPACITY-1))
for(const[e,t]of(0,a.V5)(this.show_item_dict))e>=this.CAPACITY&&null!=t&&this.RemoveShowItem(t,e);[this.startShowIndex,this.endShowIndex]=[t,e]
for(let i=e;i<=t;i++){const e=this.item_datas[i],t=this.show_item_dict.LuaDic_GetItem(i)
null==e||1==e?this.RemoveShowItem(t,i):(i<this.startShowIndex&&(this.startShowIndex=i),i>this.endShowIndex&&(this.endShowIndex=i),this.AddShowItem(t,i,e))}}AddShowItem(e,t,i){
null==e&&(e=this.GetShowItem()),this.SetPos(e,t),this.grid.node.addChild(e.node),this.show_item_dict.LuaDic_AddOrSetItem(t,e),null!=i&&e.SetData(i)}RemoveShowItem(e,t){
null!=e&&(e.node.SetActive(!1),this.show_item_dict.LuaDic_Remove(t),this.grid.node.removeChild(e.node),e.Clear(),this.item_pool.Add(e))}GetShowItem(){let e=null
if(this.item_pool.Count()>0)e=this.item_pool.Pop()
else{const t=s.o.getPrefab(this.m_ItemPath)
e=(0,n.instantiate)(t).getCNode(this.m_ItemCls),e.SetUIData(this.m_uidata)}return e.node.SetActive(!0),e}SetPos(e,t){
const i=t%this.COLUMN_CNT*(this.ITEM_SIZE+this.SPACE),n=-Math.floor(t/this.COLUMN_CNT)*(this.ITEM_SIZE+this.SPACE)
e.node.x=i,e.node.y=n}Destroy(){for(const[e,t]of(0,a.V5)(this.show_item_dict))null!=t&&this.item_pool.Add(t)
this.show_item_dict.LuaDic_Clear()
for(let e=0;e<=this.item_pool.Count()-1;e++){this.item_pool[e]}this.item_pool.Clear()}GetInfoForItemSize(){return[this.SPACE,this.ITEM_SIZE,this.ICON_SIZE]}}},5031:(e,t,i)=>{
"use strict"
i.d(t,{T:()=>Me})
var n=i(86133),s=i(98800),a=i(97461),r=i(36241),l=i(19176),o=i(5494),_=i(79534),u=i(21554),h=i(92679),c=i(87923),d=i(73865),m=i(57035),p=i(37648),g=i(55492),I=i(48946),E=i(14792),C=i(52396),S=i(17409),T=i(49655),f=i(77546),A=i(68662),y=i(13687),R=i(56937),D=i(31222),w=i(52726),L=i(98789),v=i(98885),O=i(85602),P=i(18202),N=i(995),M=i(26753),b=i(57940),G=i(94826),U=i(88010),B=i(57651),k=i(62783)
class F{constructor(){this.icon=null,this.funType=0,this.offset=null,this.insertIconCount=1}Test1(){return!0}S_Test(){return!0}}
var H=i(38836),x=i(38045),V=i(84581),Y=i(73206),W=i(50089),K=i(70829),Z=i(2577),z=i(5924),q=i(99294),$=i(9986),X=i(86290),Q=i(93877),j=i(3522),J=i(72005),ee=i(13113),te=i(61911),ie=i(49484),ne=i(83540),se=i(98130),ae=i(70850),re=i(3859),le=i(22662),oe=i(378),_e=i(79653),ue=i(54383),he=i(99130),ce=i(34294),de=i(35259),me=i(25406),pe=i(65550)
class ge extends te.f{constructor(){super(),this.changeSkillbtn=null,this.anchor=null,this.normalSkillItem=null,this.skillItem1=null,this.skillItem2=null,this.skillItem3=null,
this.skillItem4=null,this.changeModeBtn=null,this.changeTargetBtn=null,this.hangBtn=null,this.hangbg=null,this.anime=null,this.offsetTran=null,this.switchAnime=null,this.isShow=!1,
this._leftTimeIntervalId=-1,this.offset=0,this.ITEM_LEN=4,this._timerId=-1,this.skillItemList=null,this.drugItem=null,this._degf_changeSkillHandler=null,
this._degf_changeModeHandler=null,this._degf_changeTargetHandler=null,this._degf_showSkill=null,this._degf_OnHangStateUpdate=null,this._degf_TimeChange=null,
this._degf_hangHandler=null,this._degf_drugHandler=null,this._degf_snowBallHandler=null,this._degf_UpdateDrugGrid=null,this._degf_OnShortcutGoodsUpdateCD=null,
this._degf_OnFrame=null,this._degf_UpdateAnchors=null,this._degf_UpdateSnowBallNum=null,this._degf_ShowSpecialSkills=null,this.drugBtn=null,this.drugbg=null,this.drugadd=null,
this.drugnum=null,this.cd_bg=null,this.cd_light=null,this.cantUseSp=null,this.specialSkillItem1=null,this.specialSkillItem2=null,this.specialSkillItem3=null,this.snowBallNum=null,
this.snowBallBtn=null,this.snowBallNumGroup=null,this.specialSkillItems=null,this.cdEndTime=null,this.CDTime=null,this.CDTimeCount=null,this.m_grid=null,
this._degf_changeSkillHandler=(e,t)=>this.changeSkillHandler(e,t),this._degf_changeModeHandler=(e,t)=>this.changeModeHandler(e,t),
this._degf_changeTargetHandler=(e,t)=>this.changeTargetHandler(e,t),this._degf_showSkill=e=>this.showSkill(e),this._degf_OnHangStateUpdate=e=>this.OnHangStateUpdate(e),
this._degf_TimeChange=()=>this.TimeChange(),this._degf_hangHandler=()=>this.hangHandler(),this._degf_drugHandler=()=>this.drugHandler(),
this._degf_snowBallHandler=()=>this.snowBallHandler(),this._degf_UpdateDrugGrid=e=>this.UpdateDrugGrid(e),this._degf_OnShortcutGoodsUpdateCD=e=>this.OnShortcutGoodsUpdateCD(e),
this._degf_OnFrame=()=>this.OnFrame(),this._degf_UpdateAnchors=e=>this.UpdateAnchors(),this._degf_UpdateSnowBallNum=e=>this.UpdateSnowBallNum(e),
this._degf_ShowSpecialSkills=()=>this.ShowSpecialSkills()}InitView(){this.anchor=new ee.T,this.anchor.setId(this.FatherId,this.FatherComponentID,1),this.normalSkillItem=new oe.Q,
this.normalSkillItem.setBinderId(this.FatherId,this.FatherComponentID,2),this.normalSkillItem.SetIndex(0),this.skillItem1=new oe.Q,
this.skillItem1.setBinderId(this.FatherId,this.FatherComponentID,3),this.skillItem1.SetIndex(1),this.skillItem2=new oe.Q,
this.skillItem2.setBinderId(this.FatherId,this.FatherComponentID,4),this.skillItem2.SetIndex(2),this.skillItem3=new oe.Q,
this.skillItem3.setBinderId(this.FatherId,this.FatherComponentID,5),this.skillItem3.SetIndex(3),this.skillItem4=new oe.Q,
this.skillItem4.setBinderId(this.FatherId,this.FatherComponentID,6),this.skillItem4.SetIndex(4),this.changeSkillbtn=new $.W,
this.changeSkillbtn.setId(this.FatherId,this.FatherComponentID,7),this.changeModeBtn=new $.W,this.changeModeBtn.setId(this.FatherId,this.FatherComponentID,8),
this.changeTargetBtn=new $.W,this.changeTargetBtn.setId(this.FatherId,this.FatherComponentID,9),this.hangBtn=new $.W,this.hangBtn.setId(this.FatherId,this.FatherComponentID,11),
this.hangbg=new J.w,this.hangbg.setId(this.FatherId,this.FatherComponentID,12),this.drugBtn=new $.W,this.drugBtn.setId(this.FatherId,this.FatherComponentID,13),this.anime=new j.k,
this.anime.setId(this.FatherId,this.FatherComponentID,14),this.drugbg=new J.w,this.drugbg.setId(this.FatherId,this.FatherComponentID,15),this.drugadd=new q.z,
this.drugadd.setId(this.FatherId,this.FatherComponentID,16),this.drugnum=new Q.Q,this.drugnum.setId(this.FatherId,this.FatherComponentID,17),this.cd_bg=new J.w,
this.cd_bg.setId(this.FatherId,this.FatherComponentID,18),this.cd_light=new J.w,this.cd_light.setId(this.FatherId,this.FatherComponentID,19),this.offsetTran=new X.G,
this.offsetTran.setId(this.FatherId,this.FatherComponentID,20),this.switchAnime=new j.k,this.switchAnime.setId(this.FatherId,this.FatherComponentID,21),this.cantUseSp=new q.z,
this.cantUseSp.setId(this.FatherId,this.FatherComponentID,22),this.specialSkillItem1=new _e.I,this.specialSkillItem1.setBinderId(this.FatherId,this.FatherComponentID,23),
this.specialSkillItem2=new _e.I,this.specialSkillItem2.setBinderId(this.FatherId,this.FatherComponentID,24),this.specialSkillItem3=new _e.I,
this.specialSkillItem3.setBinderId(this.FatherId,this.FatherComponentID,25),this.snowBallNum=new Q.Q,this.snowBallNum.setId(this.FatherId,this.FatherComponentID,26),
this.snowBallBtn=new $.W,this.snowBallBtn.setId(this.FatherId,this.FatherComponentID,27),this.snowBallNumGroup=new q.z,
this.snowBallNumGroup.setId(this.FatherId,this.FatherComponentID,28),this.skillItemList=new O.Z,this.skillItemList.Add(this.normalSkillItem),
this.skillItemList.Add(this.skillItem1),this.skillItemList.Add(this.skillItem2),this.skillItemList.Add(this.skillItem3),this.skillItemList.Add(this.skillItem4),
this.specialSkillItems=new O.Z,this.specialSkillItems.Add(this.specialSkillItem1),this.specialSkillItems.Add(this.specialSkillItem2),
this.specialSkillItems.Add(this.specialSkillItem3),this.anchor.SetAnchorTransform(!1),W.t.ResetAnchorPos(this.anchor,!1),this.ResetOffset()}OnAddToScene(){
this.isShow||(this.UpdateView(),this.ShowSpecialSkills(),this.m_handlerMgr.AddEventMgr(Z.g.CD_CHANGE,this._degf_showSkill),
this.m_handlerMgr.AddEventMgr(Z.g.SHORTCUT_CHANGE,this._degf_showSkill),this.AddClickEvent(this.changeSkillbtn,this._degf_changeSkillHandler),
this.AddClickEvent(this.changeModeBtn,this._degf_changeModeHandler),this.AddClickEvent(this.changeTargetBtn,this._degf_changeTargetHandler),
this.AddClickEvent(this.hangBtn,this._degf_hangHandler),this.AddClickEvent(this.drugBtn,this._degf_drugHandler),this.AddClickEvent(this.snowBallBtn,this._degf_snowBallHandler),
this.isShow=!0,ie.p.Inst_get().EnterMap(y.b.Inst.currentMapId_get()),this.m_handlerMgr.AddEventMgr(h.g.HANG_STATE_UPDATE,this._degf_OnHangStateUpdate),
this.m_handlerMgr.AddEventMgr(h.g.BAG_UPDATE,this._degf_UpdateDrugGrid),this.m_handlerMgr.AddEventMgr(h.g.COPY_ENTEREND,this._degf_UpdateDrugGrid),
this.m_handlerMgr.AddEventMgr(h.g.SHORTCUT_GOODS_UPDATE_CD,this._degf_OnShortcutGoodsUpdateCD),this.m_handlerMgr.AddEventMgr(h.g.UPDATE_ANCHORS,this._degf_UpdateAnchors),
this.m_handlerMgr.AddEventMgr(h.g.BAG_UPDATE,this._degf_UpdateSnowBallNum),this.m_handlerMgr.AddEventMgr(h.g.UpdateSpecialSkills,this._degf_ShowSpecialSkills),
this.m_handlerMgr.AddEventMgr(h.g.PRIMARY_ROLE_CHANGED,this._degf_showSkill),this.m_handlerMgr.AddEventMgr(h.g.SKILL_USE_LIST_TYPE_CHANGE,this._degf_showSkill),
this.UpdateDrugGrid(null),this.drugBtn.node.SetActive(!1))}ResetOffset(){const e=W.t.GetUIHeight()
if(e>W.t.height){const t=new _.P(0,-336,0),i=(e-W.t.height)/2
t.y-=i,this.offsetTran.SetLocalPosition(t),_.P.Recyle(t)}}changeSkillHandler(e,t){const i=ce.L.Inst_get().GetPrimaryRoleSkillSlotVO()
null!=i&&(1!=i.slots.Count()?(2==ce.L.Inst_get().battleSkillState?ce.L.Inst_get().battleSkillState=1:ce.L.Inst_get().battleSkillState=2,a.i.Inst.RaiseEvent(Z.g.SHORTCUT_CHANGE,!0),
this.switchAnime.SetResetOnPlay(!0),this.switchAnime.Play(!0,!1)):pe.y.inst.ClientStrMsg(le.r.SystemTipMessage,(0,n.T)("战斗模式未开启")))}GetNextSkillSlotIndex(){
const e=ce.L.Inst_get().GetPrimaryRoleSkillSlotVO(),t=e.slots.Count()
for(let i=0;i<=t;i++){if(e.slots[i].idx==e.selectIdx)return t-i>=1?e.slots[i+1].idx:e.slots[0].idx}return e.slots[0].idx}changeModeHandler(e,t){U.F.Inst_get().SwitchToNormal()}
changeTargetHandler(e,t){let i=null
i=null==INS.skillModel.currentPressSkill?me.U.Inst_get().ChangeOne(!1):me.U.Inst_get().ChangeOne(!0,INS.skillModel.currentPressSkill),
null!=i&&i.roletype==V.s.role&&ue.k.Inst_get().IsExistPkList(i.GetGameId())&&(l.S.getInst().InHang_get()||U.F.Inst_get().isInPkUI||(l.S.getInst().InHang_set(!0),
r._.getInst().openOrCloseStartIcon()))}ChangeSkillModel(e){const t=s.Y.Inst.PrimaryRoleInfo_get(),i=ce.L.Inst_get().GetSkillSlotByIdx(t).selectIdx
let n=e.IndexOf(i,0)
n+=1,n>=e.Count()&&(n=0),he.x.inst.CM_SelectSlotReq(e[n])}UpdateView(){this.showSkill()}showSkill(e){this.drugBtn.node.SetActive(!1)
let t=!1
null!=e&&(t=e)
const i=ce.L.Inst_get().GetPrimaryRoleSkillSlotVO()
if(null==i)return
this.changeSkillbtn.node.SetActive(!1)
const n=i.slots
let s=null,a=0
const r=ce.L.Inst_get().curUseSkillListType
for(;a<n.Count();)n[a].idx==r&&(s=n[a].skillUpM),a+=1
if(null==s)return
this.ITEM_LEN=4
const l=new O.Z
let o=1,_=0
for(2==ce.L.Inst_get().battleSkillState&&(_=4);o<=this.ITEM_LEN;){let e=0
e=s.LuaDic_GetItem(o+_),null==e&&(e=0)
const i=de.C.INSTANCE.GetSkillByStudyDic(e)
if(null==i)l.Add(null)
else{const n=K.j.Inst().GetSkillByIdLevel(e,i.level)
n.needClear=t,l.Add(n)}o+=1}const u=new O.Z
u.Add(1001),u.Add(2001),u.Add(3001)
for(const[e,i]of(0,H.V5)(u)){const e=de.C.INSTANCE.GetSkillByStudyDic(i)
if(null!=e){const n=K.j.Inst().GetSkillByIdLevel(i,e.level)
n.needClear=t,this.skillItemList[0].SetData(n)
break}}this.skillItemList[1].SetData(l[0]),this.skillItemList[2].SetData(l[1]),this.skillItemList[3].SetData(l[2]),this.skillItemList[4].SetData(l[3]),this.UpdateDrugGrid(null)}
ShowSpecialSkills(){const e=ce.L.Inst_get().specialSkillList
for(let t=0;t<=2;t++){this.specialSkillItems[t].SetData(e[t])}}hangHandler(e,t){Me.inst_get().OnFunItemClick(o.I.HangOpenPanel)}drugHandler(e,t){
null!=this.drugItem?u.J.Inst_get().UseItem(this.drugItem):u.J.Inst_get().OpenShortcutGoodsSelectPanel(this.drugBtn)}snowBallHandler(e,t){}updateHang(){
l.S.getInst().InHang_get()||r._.getInst().ishang_get()}OnHangStateUpdate(e){e?this.startAnimation():(z.C.Inst_get().ClearInterval(this._leftTimeIntervalId),
this._leftTimeIntervalId=-1)}startAnimation(){this.offset=0,z.C.Inst_get().ClearInterval(this._leftTimeIntervalId),
this._leftTimeIntervalId=z.C.Inst_get().SetInterval(this._degf_TimeChange,33)}TimeChange(){this.offset+=2,this.offset>=180&&(this.offset-=180)
const e=_.P.zero_get()
e.Set(0,0,this.offset),this.hangbg.node.transform.SetEulerAngles(e),_.P.Recyle(e)}ClearCd(){for(const[e,t]of(0,H.V5)(this.skillItemList)){null!=t&&t.cleanCD()}}Clean(){
for(const[e,t]of(0,H.V5)(this.skillItemList)){null!=t&&t.clean()}}Clear(){this.RemoveClickEvent(this.changeSkillbtn,this._degf_changeSkillHandler),
this.RemoveClickEvent(this.changeModeBtn,this._degf_changeModeHandler),this.RemoveClickEvent(this.changeTargetBtn,this._degf_changeTargetHandler),
this.RemoveClickEvent(this.hangBtn,this._degf_hangHandler),this.RemoveClickEvent(this.drugBtn,this._degf_drugHandler),
this.RemoveClickEvent(this.snowBallBtn,this._degf_snowBallHandler),this.isShow=!1,INS.skillModel.currentPressSkill=null,
INS.skillModel.roundEffectHandleId>0&&(Y.X.Inst.DeleteElement(INS.skillModel.roundEffectHandleId),INS.skillModel.roundEffectHandleId=0)}UpdateDrugGrid(e){
const t=ae.g.Inst_get().GetSCMedicineList()
if(this.drugItem=null,t.count>0){this.drugbg.node.SetActive(!0)
const e=t[0]
P.g.SetItemIcon(this.FatherId,this.drugbg.ComponentId,e.baseData_get().cfgData_get().icon,ne.b.eItem,!1),this.drugadd.SetActive(!1)
const i=ae.g.Inst_get().GetItemNum(e.baseData_get().cfgData_get().id)
i<=99?this.drugnum.textSet((0,x.tw)(i)):this.drugnum.textSet("99+"),null!=y.b.Inst.IsLockRecoverPKInMap()&&e.baseData_get().cfgData_get().itemType==re.q.SCMEDICINE?this.cantUseSp.SetActive(!0):this.cantUseSp.SetActive(!1),
this.drugItem=e}else this.drugbg.node.SetActive(!1),this.drugadd.SetActive(!0),this.cantUseSp.SetActive(!1)}UpdateSnowBallNum(e){}PlayAnime(e){e?(this.anime.SetResetOnPlay(!0),
this.anime.Play(!0,!1)):(this.anime.SetResetOnPlay(!1),this.anime.Play(!1,!1))}OnShortcutGoodsUpdateCD(e){this.cdEndTime=se.GF.INT(e),
0!=this.cdEndTime&&(z.C.Inst_get().ClearLoop(this._timerId),this._timerId=-1,null!=this.drugItem&&(this.cdEndTime=this.cdEndTime,
this._timerId=z.C.Inst_get().SetFrameLoop(this._degf_OnFrame,1),this.CDTime=0,this.CDTimeCount=this.cdEndTime-A.D.serverMSTime_get()))}OnFrame(){
if(this.CDTime=this.cdEndTime-A.D.serverMSTime_get(),this.CDTime<0)this.cd_bg.node.SetActive(!1),z.C.Inst_get().ClearLoop(this._timerId),this._timerId=-1
else{this.cd_bg.node.SetActive(!0)
const e=this.CDTime/this.CDTimeCount
this.cd_light.fillAmountSet(1-e),this.cd_bg.fillAmountSet(e)}}UpdateAnchors(e){this.anchor.UpdateAnchors(),this.ResetOffset()}Destroy(){null!=this.m_grid&&this.m_grid.Destroy(),
this.isShow=!1}}class Ie extends te.f{constructor(...e){super(...e),this.midLabel=null,this.clostbtn=null,this.confirmbtn=null,this.cancelbtn=null}InitView(){super.InitView(),
this.midLabel=this.CreateComponent(q.z,1),this.clostbtn=this.CreateComponent(q.z,2),this.confirmbtn=this.CreateComponent(q.z,3),this.cancelbtn=this.CreateComponent(q.z,4),
this.DestoryPanelLevel=te.f.DestoryLevel0}OnAddToScene(){this.m_handlerMgr.AddClickEvent(this.clostbtn,this.CreateDelegate(this._OnClose)),
this.m_handlerMgr.AddClickEvent(this.confirmbtn,this.CreateDelegate(this._OnExit)),this.m_handlerMgr.AddClickEvent(this.cancelbtn,this.CreateDelegate(this._OnClose))}_OnClose(){
D.N.inst.ClosePanel()}_OnExit(){CommonBridge.ApplicationQuit()}Clear(){super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}}
var Ee=i(92984),Ce=i(42975),Se=i(95619)
class Te extends te.f{constructor(){super(),this.buffCell=null,this.m_vo=null,this._degf_OnFullClick=null,this._degf_UpdateBuffList=null,
this._degf_OnFullClick=(e,t)=>this.OnFullClick(e,t),this._degf_UpdateBuffList=e=>this.UpdateBuffList(e)}InitView(){this.buffCell=new Se.x,
this.buffCell.setBinderId(this.FatherId,this.FatherComponentID,1),this.buffCell.isBgShow=!0}OnAddToScene(){null!=this.buffCell&&(this.m_vo=Me.inst_get().control.bVO,
this.buffCell.AddEvent(),this.buffCell.SetData(this.m_vo),null!=this.buffCell&&(Ee.j.Inst_get().model.AddEventHandler(Ce.E.UPDATE_BUFF_VIEW,this._degf_UpdateBuffList),
this.AddFullScreenCollider(this.node,this._degf_OnFullClick)))}UpdateBuffList(e){
null!=this.m_vo&&null!=Ee.j.Inst_get().model.IsHaveBuff(this.m_vo.owner,this.m_vo.buffRes_get().id)||(this.RemoveFullScreenCollider(),Me.inst_get().control.CloseBuffDetailPanel())}
OnFullClick(e,t){this.RemoveFullScreenCollider(),Me.inst_get().control.bVO=null,Me.inst_get().control.CloseBuffDetailPanel()}Clear(){
Ee.j.Inst_get().model.RemoveEventHandler(Ce.E.UPDATE_BUFF_VIEW,this._degf_UpdateBuffList),this.buffCell.RemoveEvent(),this.buffCell.Clear()}Destroy(){this.buffCell.Destroy(),
this.buffCell=null,this.m_vo=null}}var fe=i(60130),Ae=i(6665),ye=i(9057),Re=i(33314),De=i(49894)
class we extends ye.x{constructor(){super(),this._degf_OnRemoveBuff=null,this.head=null,this.buffGrid=null,this.noneObj=null,this.roleObj=null,this.buffModel=null,
this.roleIdx=null,this.m_pInfo=null,this.isPKUI=null,this._degf_OnRemoveBuff=e=>this.OnRemoveBuff(e)}InitView(){this.head=this.CreateComponent(J.w,1),
this.buffGrid=this.CreateComponent(Ae.A,2),this.noneObj=this.CreateComponent(q.z,3),this.roleObj=this.CreateComponent(q.z,4),
this.buffGrid.SetInitInfo("ui_mainview_headbuffitem",this.CreateDelegate(this.GetBuffItem)),this.buffModel=Ee.j.Inst_get().model}GetBuffItem(e){const t=new De.o
return t.setId(e,null,0),t}GetRoleInfo(){const e=s.Y.Inst.primaryRoleInfoListBySortId.Count()
return this.roleIdx>=e?this.m_pInfo=null:this.m_pInfo=s.Y.Inst.primaryRoleInfoListBySortId[this.roleIdx],this.m_pInfo}OnAddToScene(){this.GetRoleInfo(),
null!=this.m_pInfo&&(this.AddOrDelEvent(!0),this.OnChangeRole(null))}OnChangeRole(e){this.GetRoleInfo(),null==this.m_pInfo?(this.noneObj.SetActive(!0),
this.roleObj.SetActive(!1)):(this.noneObj.SetActive(!1),this.roleObj.SetActive(!0),this.head.spriteNameSet(Re.Z.GetJobIcon(this.m_pInfo.Job_get(),this.m_pInfo.Sex_get(),!0)),
this.UpdateBuffList(null))}UpdateBuffList(e){Me.inst_get().model.UpdaeBuffData(),Me.inst_get().control.UpdateBuffListData()
const t=this.m_pInfo.Id_get()
this.buffGrid.data_set(this.buffModel.GetMainViewBuffList(t,this.isPKUI))}AddOrDelEvent(e){
e?(Ee.j.Inst_get().model.AddEventHandler(Ce.E.UPDATE_BUFF_VIEW,this.CreateDelegate(this.UpdateBuffList)),
a.i.Inst.AddEventHandler(h.g.PRIMARY_ROLE_LIST_CHANGED,this.CreateDelegate(this.OnChangeRole))):(Ee.j.Inst_get().model.RemoveEventHandler(Ce.E.UPDATE_BUFF_VIEW,this.CreateDelegate(this.UpdateBuffList)),
a.i.Inst.RemoveEventHandler(h.g.PRIMARY_ROLE_LIST_CHANGED,this.CreateDelegate(this.OnChangeRole)))}OnRemoveBuff(e){
null!=this.m_pInfo&&null!=e.owner&&e.owner.Equal(this.m_pInfo.Id_get())&&this.UpdateBuffList()}Clear(){this.AddOrDelEvent(!1),this.buffGrid.Clear()}Destroy(){this.Clear(),
this.buffGrid.Destroy()}}class Le extends te.f{constructor(...e){super(...e),this.bg=null,this.roleItem0=null,this.roleItem1=null,this.roleItem2=null,this.roleItem3=null,
this.roleItem4=null,this.offset=null,this.roleItems=null}InitView(){this.bg=this.CreateComponent(J.w,1),this.roleItem0=this.CreateComponentBinder(we,2),
this.roleItem1=this.CreateComponentBinder(we,3),this.roleItem2=this.CreateComponentBinder(we,4),this.roleItem3=this.CreateComponentBinder(we,5),
this.roleItem4=this.CreateComponentBinder(we,6),this.offset=this.CreateComponent(q.z,7),
this.roleItems=new O.Z([this.roleItem0,this.roleItem1,this.roleItem2,this.roleItem3,this.roleItem4])
for(let e=0;e<=this.roleItems.Count()-1;e++)this.roleItems[e].roleIdx=e}OnAddToScene(){fe.O.SetAnchorPos(this.offset,!0,!0,2,!0),
this.AddFullScreenCollider(this.node,this.CreateDelegate(this.CloseBuffPanel),null,!1)
for(let e=0;e<=this.roleItems.Count()-1;e++)this.roleItems[e].OnAddToScene()}Clear(){this.RemoveFullScreenCollider()
for(let e=0;e<=this.roleItems.Count()-1;e++)this.roleItems[e].Clear()}CloseBuffPanel(e,t){Me.inst_get().control.CloseAllBuffListPanel()}Destroy(){
for(let e=0;e<=this.roleItems.Count()-1;e++)this.roleItems[e].Destroy()}}var ve=i(83908)
class Oe extends((0,ve.zB)()){constructor(...e){super(...e),this.isFirstShow=!0,this.lastPosY=-7,this._degf_CloseBuffPanel=null,this._degf_GetItemFun=null,
this._degf_onReposition=null}InitView(){super.InitView(),this.grid.SetInitInfo("ui_mainview_buffcell",null,Se.x),this.grid.OnReposition_set(this.CreateDelegate(this.onReposition)),
this.bg.node.SetActive(!1)}onReposition(){this.bg.node.SetActive(!0)
let e=this.grid.node.transform.contentSize.height
e+=12
let t=!1
e>330&&(e=330,t=!0),this.scrollview.enabled=t,this.bg.heightSet(se.GF.INT(e)),e-=20,this.UpdateScrollBar(!t)}OnAddToScene(){const e=Me.inst_get().model.buffList
null!=e&&0==e.Count()?(this.grid.node.SetActive(!1),this.nobuffTip.node.SetActive(!0),this.bg.node.SetActive(!0),this.bg.heightSet(74)):(this.grid.node.SetActive(!0),
this.nobuffTip.node.SetActive(!1),this.OnViewUpdate())}OnViewUpdate(){const e=this.scrollPanel.node.transform.GetLocalPosition()
this.lastPosY=e.y,this.grid.data_set(Me.inst_get().model.buffList)}UpdateScrollBar(e){if(this.isFirstShow)this.isFirstShow=!1
else if(e);else{let e=this.grid.node.transform.contentSize.height
e+=12
const t=e-this.scrollPanel.node.transform.width-7
if(this.lastPosY>t){const e=this.scrollPanel.node.transform.GetLocalPosition()
e.y=t,this.scrollPanel.node.transform.SetLocalPosition(e)}}}Clear(){}CloseBuffPanel(e,t){Me.inst_get().control.CloseBuffListPanel()}Destroy(){this.lastPosY=-7}}var Pe=i(78612)
class Ne{get m_expView(){return this._m_expView=(0,S.Y)(o.I.eMainViewExp),this._m_expView}constructor(){this.karimaPanel=null,this.funcSetView=null,this.headView=null,
this.m_funUpView=null,this.m_funDownView=null,this._mainViewPanel=null,this.buffListPanel=null,this.allBuffListPanel=null,this.m_skillView=null,this.m_battleSkillView=null,
this._m_expView=null,this.expTip=null,this.isExpTipOpen=!1,this.m_operationPanel=null,this.ui_scene_touch_view=null,this.m_buffDetailPanel=null,this.pkFuncView=null,
this.btn_extra_package=null,this.bVO=null,this._degf_CallDestoryBuffListPanel=null,this._degf_CallDestoryMainViewPanel=null,this._degf_CallHeadBuffDetailPanelDestory=null,
this._degf_CallKarimaDestory=null,this._degf_CallSkillDestory=null,this._degf_CallBattleSkillDestory=null,this._degf_ExpTipDestory=null,this._degf_OnExpTipComplete=null,
this._degf_OnSkillShowComplete=null,this._degf_OnBattleSkillShowComplete=null,this._degf_OpenBuffListComplete=null,this._degf_OpenMainViewComplete=null,
this._degf_ShowHeadBuffDetailPanel=null,this._degf_ShowKarimaComplete=null,this.moveLength=1200,this.configList=null,this.isLoad=void 0,
this._degf_CallDestoryBuffListPanel=()=>this.CallDestoryBuffListPanel(),this._degf_CallDestoryMainViewPanel=()=>this.CallDestoryMainViewPanel(),
this._degf_CallHeadBuffDetailPanelDestory=()=>this.CallHeadBuffDetailPanelDestory(),this._degf_CallKarimaDestory=()=>this.CallKarimaDestory(),
this._degf_CallSkillDestory=()=>this.CallSkillDestory(),this._degf_CallBattleSkillDestory=()=>this.CallBattleSkillDestory(),this._degf_ExpTipDestory=()=>this.ExpTipDestory(),
this._degf_OnExpTipComplete=e=>this.OnExpTipComplete(e),this._degf_OnSkillShowComplete=e=>this.OnSkillShowComplete(e),
this._degf_OnBattleSkillShowComplete=e=>this.OnBattleSkillShowComplete(e),this._degf_OpenBuffListComplete=e=>this.OpenBuffListComplete(e),
this._degf_OpenMainViewComplete=e=>this.OpenMainViewComplete(e),this._degf_ShowHeadBuffDetailPanel=e=>this.ShowHeadBuffDetailPanel(e),
this._degf_ShowKarimaComplete=e=>this.ShowKarimaComplete(e),this.configList=new O.Z}get mainViewPanel(){return(0,S.Y)(T.o.MainViewPanel)}OpenInitView(){this.OpenMainView(),
this.OpenTaskView(),this.OpenSkillList(),this.OpenExpBar(),k.X.inst.OpenPanel()}loadTipsPrefab(){}UpdateAnchors(){null!=this.mainViewPanel&&this.mainViewPanel.UpdateAnchors()}
OpenTaskView(){B.i.ins.OpenMainUI(),B.i.ins.OpenTaskTempView()}ForceCloseHeadForMapJudge(){null!=this.headView&&(this.headView.node.SetActive(!1),this.headView.Clear())}
OpenGameExitTip(){const e=new R.v
e.positionType=L.$.eCenter,e.layerType=w.F.Effect,e.ReLoginOrChangeRoleIsDestroy=!1,e.isShowMask=!0,e.viewClass=Ie,D.N.inst.OpenById(o.I.eGameExit,null,null,e)}
ForceOpenHeadForMapJudge(){null!=this.headView&&(this.headView.node.SetActive(!0),this.headView.OnAddToScene())}ForceCloseFuncForMapJudge(){
null!=this.m_funUpView&&(this.m_funUpView.node.SetActive(!1),this.m_funUpView.Clear()),null!=this.m_funDownView&&this.m_funDownView.ShowMarketBtn(!1),this.ForceCloseFuncSetView()}
ForceCloseUpFuncForMapJudge(){null!=this.m_funUpView&&(this.m_funUpView.node.SetActive(!1),this.m_funUpView.Clear()),this.ForceCloseTouchFuncForMapJudge()}
ForceCloseDownFuncForMapJudge(){null!=this.m_funDownView&&(this.m_funDownView.node.SetActive(!1),this.m_funDownView.Clear())}ForceCloseTouchFuncForMapJudge(){
null!=this.ui_scene_touch_view&&(G.C.Inst_get().SetActiveById(b.k.sceneTouchView,!1),this.ui_scene_touch_view.Clear())}ForceClosePkFuncView(){
null!=this.pkFuncView&&this.pkFuncView.Clear()}ForceOpenFuncForMapJudge(){null!=this.m_funUpView&&(this.m_funUpView.node.SetActive(!0),this.m_funUpView.OnAddToScene()),
this.ForceOpenFuncSetView()}ForceOpenUpFuncForMapJudge(){null!=this.m_funUpView&&(this.m_funUpView.node.SetActive(!0),this.m_funUpView.OnAddToScene())}
ForceOpenDownFuncForMapJudge(){null!=this.m_funDownView&&(this.m_funDownView.node.SetActive(!0),this.m_funDownView.ShowMarketBtn(!0),this.m_funDownView.OnAddToScene())}
ForceOpenPkFuncView(){null!=this.pkFuncView&&(this.pkFuncView.node.SetActive(!0),this.pkFuncView.OnAddToScene())}ForceOpenFuncSetView(){
null!=this.funcSetView&&(this.funcSetView.node.SetActive(!0),this.funcSetView.OnAddToScene(),this.funcSetView.ForcePlayAni())}ForceCloseFuncSetView(){
null!=this.funcSetView&&(this.funcSetView.node.SetActive(!1),this.funcSetView.Clear())}OpenMainView(){const e=new R.v
e.positionType=L.$.eCustom,e.layerType=w.F.DefaultUI,e.ReLoginOrChangeRoleIsDestroy=!1,D.N.inst.OpenById(T.o.MainViewPanel,null,null,e,this._degf_OpenMainViewComplete)}
OpenMainViewComplete(){}ResetPanel(){null!=this.mainViewPanel&&this.mainViewPanel.ResetPanel()}GetFunOpenGrid1Count(){
return null!=this.mainViewPanel?this.mainViewPanel.GetFunOpenGrid1Count():0}UpdateGoodsItemLockState(){null!=this.mainViewPanel&&this.mainViewPanel.UpdateGoodsItemLockState()}
CallDestoryMainViewPanel(){P.g.DestroyUIObj(this.mainViewPanel),this.mainViewPanel=null}CloseMainViewPanel(){null!=this.mainViewPanel&&this.mainViewPanel.node.SetActive(!1),
this.ForceCloseSkillForMapJudge(),this.ForceCloseDownFuncForMapJudge(),this.ForceCloseUpFuncForMapJudge(),this.ForceCloseHeadForMapJudge()}GetMarketWorldPos(){
return null!=this.mainViewPanel?this.mainViewPanel.GetMarketWorldPos():_.P.zero_get()}GetBagWorldPos(e){
return null!=this.mainViewPanel?this.mainViewPanel.GetBagWorldPos(e):_.P.zero_get()}GetRuneBtnWorldPos(){
return null!=this.mainViewPanel?this.mainViewPanel.GetRuneBtnWorldPos():_.P.zero_get()}GetFirstRowFuncNum(){
return null!=this.mainViewPanel?this.mainViewPanel.GetFisrtRowFuncNum():0}GetFuncEmptyObj(){return null!=this.mainViewPanel?this.mainViewPanel.GetFuncEmptyObj():null}
GetHeadEmptyObj(){return null!=this.mainViewPanel?this.mainViewPanel.GetHeadEmptyObj():null}GetOperationEntranceAnchorObj(){
return null!=this.mainViewPanel?this.mainViewPanel.GetOperationEntranceAnchorObj():null}ChangePKBuffState(e){null!=this.mainViewPanel&&this.mainViewPanel.ChangePKBuffState(e)}
OpenBuffListPanel(){if(null!=this.buffListPanel&&this.buffListPanel.isShow_get())this.CloseBuffListPanel()
else if(null==this.buffListPanel||!this.buffListPanel.isShow_get()){const e=new R.v
e.layerType=w.F.Alert,D.N.inst.OpenById(o.I.MainBuffListPanel,this._degf_OpenBuffListComplete,this._degf_CallDestoryBuffListPanel,e)}}CallDestoryBuffListPanel(){
P.g.DestroyUIObj(this.buffListPanel),this.buffListPanel=null}OpenBuffListComplete(e){return null==this.buffListPanel&&(this.buffListPanel=new Oe,
this.buffListPanel.setId(e,null,0)),this.buffListPanel}CloseBuffListPanel(){
null!=Me.inst_get().control&&null!=Me.inst_get().control.headView&&(Me.inst_get().control.headView.m_isListLoading=!1),
null!=this.buffListPanel&&D.N.inst.ClosePanel(this.buffListPanel),M.d.Inst_get().controller.CloseHornPanel()}UpdateBuffListData(){
null!=this.buffListPanel&&this.buffListPanel.OnAddToScene()}OpenAllBuffListPanel(){}CallDestoryAllBuffListPanel(){P.g.DestroyUIObj(this.allBuffListPanel),this.allBuffListPanel=null
}OpenAllBuffListComplete(e){return null==this.allBuffListPanel&&(this.allBuffListPanel=new Le,this.allBuffListPanel.setId(e,null,0)),this.allBuffListPanel}CloseAllBuffListPanel(){
null!=Me.inst_get().control&&null!=Me.inst_get().control.headView&&(Me.inst_get().control.headView.m_isListLoading=!1),
null!=this.allBuffListPanel&&D.N.inst.ClosePanel(this.allBuffListPanel),M.d.Inst_get().controller.CloseHornPanel()}OpenSkillList(){const e=new R.v
e.positionType=L.$.eCustom,e.layerType=w.F.DefaultUI,e.ReLoginOrChangeRoleIsDestroy=!1,
D.N.inst.OpenById(T.o.MainSkillListPanel,this._degf_OnSkillShowComplete,this._degf_CallSkillDestory,e),null!=this.m_skillView&&this.m_skillView.showSkill()}OnSkillShowComplete(e){
return null==this.m_skillView&&(this.m_skillView=new Pe.g,this.m_skillView.setPrefabRootId(e)),this.m_skillView}CallSkillDestory(){P.g.DestroyUIObj(this.m_skillView),
this.m_skillView=null}GetSkillListPanel(){return this.m_battleSkillView}OpenBattleSkillPanel(){const e=new R.v
e.positionType=L.$.eCustom,e.layerType=w.F.DefaultUI,e.aniDir=N.K.Right2,e.ReLoginOrChangeRoleIsDestroy=!1,
D.N.inst.OpenById(o.I.eBattleSkillPanel,this._degf_OnBattleSkillShowComplete,this._degf_CallBattleSkillDestory,e),null!=this.m_battleSkillView&&this.m_battleSkillView.showSkill()}
OnBattleSkillShowComplete(e){return null==this.m_battleSkillView&&(this.m_battleSkillView=new ge,this.m_battleSkillView.setId(e,null,0)),this.m_battleSkillView}
CallBattleSkillDestory(){P.g.DestroyUIObj(this.m_battleSkillView),this.m_battleSkillView=null}ForceCloseSkillForMapJudge(){
null!=this.m_skillView&&this.m_skillView.node.SetActive(!1),null!=this.m_battleSkillView&&this.m_battleSkillView.node.SetActive(!1)}ForceOpenSkillForMapJudge(){
const e=U.F.Inst_get().isInPkUI
null!=this.m_skillView&&(e?this.m_skillView.DoSpread(!1):(this.m_skillView.node.SetActive(!0),this.m_skillView.OnAddToScene(),Me.inst_get().DoSpreadBtns(!1)),
this.m_skillView.ForcePlayAni()),null!=this.m_battleSkillView&&(e?(this.m_battleSkillView.node.SetActive(!0),this.m_battleSkillView.showSkill(null),
this.m_battleSkillView.PlayAnime(!0)):this.m_battleSkillView.node.SetActive(!1))}ChangeBattleSkillMode(){
const e=y.b.Inst.currentMapId_get(),t=v.M.IntToString(HideMapUIExtend.Inst_get().GetUseMapId(e))
HideMapUIExtend.Inst_get().IndexOfStr(HideMapUIExtend.Inst_get().skillResult_get(),t)||Me.inst_get().control.ForceOpenSkillForMapJudge()}ClearSkillCD(){
null!=this.m_skillView&&(this.m_skillView.ClearCd(),null!=this.m_battleSkillView&&this.m_battleSkillView.Clean())}DoSpreadSkillView(e){
null!=this.m_skillView&&this.m_skillView.DoSpread(e)}OpenExpBar(){const e=new R.v
e.positionType=L.$.eCustom,e.layerType=w.F.DefaultUI,e.aniDir=N.K.Expbar,e.ReLoginOrChangeRoleIsDestroy=!1,(0,S.Yp)(o.I.eMainViewExp,e)}ResetMainExp(){
null!=this.m_expView&&this.m_expView.node&&this.m_expView.Hideallexpeffect()}ForceCloseExpForMapJudge(){
null!=this.m_expView&&this.m_expView.node&&(this.m_expView.node.SetActive(!1),this.m_expView.Hideallexpeffect())}ForceOpenExpForMapJudge(){
null!=this.m_expView&&this.m_expView.node&&this.m_expView.node.SetActive(!0)}OpenExpTip(){if(this.isExpTipOpen)return void(null!=this.expTip&&this.expTip.SetInfo())
this.isExpTipOpen=!0
const e=new R.v
e.positionType=L.$.eCustom,e.layerType=w.F.DefaultUI,e.aniDir=N.K.Down2,D.N.inst.OpenById(o.I.MainViewEffectiveTip,this._degf_OnExpTipComplete,this._degf_ExpTipDestory,e)}
CloseExpTip(){this.isExpTipOpen=!1,D.N.inst.CloseById(o.I.MainViewEffectiveTip)}UpdateExpTip(){null!=this.expTip&&this.expTip.SetInfo()}OnExpTipComplete(e){
return null==this.expTip&&(this.expTip=new HangEffectiveTipPanel,this.expTip.setId(e,null,0)),this.expTip}ExpTipDestory(){P.g.DestroyUIObj(this.expTip),this.expTip=null}
GetFuncItem(e){return null}UpdateOperationView(){null!=this.m_operationPanel&&this.m_operationPanel.UpdateView()}ForceOpenOperationPanel(e){null==e&&(e=!0),
null!=this.m_operationPanel&&(this.m_operationPanel.node.SetActive(!0),this.m_operationPanel.OnAddToScene(),e&&this.m_operationPanel.ForcePlayAni())}ForceCloseOperationPanel(e){
null!=this.m_operationPanel&&(null==e&&(e=!1),e||(this.m_operationPanel.node.SetActive(!1),this.m_operationPanel.Clear()))}UpdateOperationTime(){
null!=this.m_operationPanel&&(this.m_operationPanel.lastOperTime=A.D.serverMSTime_get())}AttachToOperationPanel(e,t,i,n){null==n&&(n=1)
let s=null
null!=e&&(s=this.GetOperationData(e),s.icon=e,s.offset=i,s.funType=t,s.count=n),this.configList.Sort(this.CreateDelegate(this.SortConfigList)),
null!=this.m_operationPanel&&this.m_operationPanel.UpdateView()}SortConfigList(e,t){
const i=FunctionCfgManager.Inst_get().getItemById(e.funType),n=FunctionCfgManager.Inst_get().getItemById(t.funType),s=i.nameId,a=n.nameId,r=TopIconCfgManager.Inst_get().getItemById(s),l=TopIconCfgManager.Inst_get().getItemById(a)
return TopIconCfgManager.Inst_get().SortItemList(r,l)}GetOperationData(e){for(let t=0;t<=this.configList.Count()-1;t++)if(this.configList[t].icon==e)return this.configList[t]
const t=new F
return this.configList.Add(t),t}RemoveAttach(e){for(let t=0;t<=this.configList.Count()-1;t++)this.configList[t].icon==e&&this.configList.Remove(this.configList[t])
null!=this.m_operationPanel&&this.m_operationPanel.UpdateView()}RapidUpdateView(){null!=this.m_operationPanel&&this.m_operationPanel.OnInterval()}GetTouchAnchorGo(){
return this.ui_scene_touch_view,null}OpenBuffDetailPanel(e){this.bVO=e
const t=new R.v
t.layerType=w.F.Alert,D.N.inst.OpenById(o.I.eHeadBuffDetailPanel,this._degf_ShowHeadBuffDetailPanel,this._degf_CallHeadBuffDetailPanelDestory,t)}ShowHeadBuffDetailPanel(e){
return null==this.m_buffDetailPanel&&(this.m_buffDetailPanel=new Te,this.m_buffDetailPanel.setId(e,null,0)),this.m_buffDetailPanel}CallHeadBuffDetailPanelDestory(){
P.g.DestroyUIObj(this.m_buffDetailPanel),this.m_buffDetailPanel=null}CloseBuffDetailPanel(){null!=this.m_buffDetailPanel&&D.N.inst.CloseById(o.I.eHeadBuffDetailPanel)}
GetOperationPanelFatherId(){if(null!=this.m_operationPanel)return this.m_operationPanel.FatherId}SetBattleScore(){null!=this.headView&&this.headView.SetBattleSocre()}
ForceHideExtraPackageBtn(){null!=this.btn_extra_package&&(this.btn_extra_package.node.SetActive(!1),f.s.Info("下载B包按钮隐藏 ForceHideExtraPackageBtn"))}JudgeShowExtraPackageBtn(){
null!=this.btn_extra_package&&this.btn_extra_package.OnAddToScene()}ShowOperationPanel(e){
null!=this.m_operationPanel&&0==this.m_operationPanel.IsDestroyed()&&this.m_operationPanel.ShowView(e)}}class Me{constructor(){this.control=null,this.model=null,this.clickIndex=0,
this.control=new Ne,this.model=C.h.Inst_get()}static inst_get(){return null==Me.m_inst&&(Me.m_inst=new Me),Me.m_inst}UpdateAnchors(){LuaUIUtil._InitUIDatas(),LuaGlobal.IsIos,
a.i.Inst.RaiseEvent(h.g.UPDATE_ANCHORS),Me.inst_get().control.UpdateAnchors()}LogoMovieOnFinish(){LuaCommonBridge._ShowLogoMovieEnd()}OnFunItemClick(e){
if(e==o.I.eBagPanel)u.J.Inst_get().openOrClose()
else if(e==o.I.SwitchTarget)SwitchTargetManager.inst_get().model.ChangeOne()
else if(e==o.I.MarketPanel)p.P.Inst_get().IsFunctionOpened(g.x.MALL)?MarketControl_ry.Inst_get().Open(1):c.l.SetFunctionTip(g.x.MALL)
else if(e==o.I.HangOpenPanel){if(l.S.getInst().isTickStopAIHang||l.S.getInst().isClickStopAIHang)return r._.getInst().endHang(),l.S.getInst().IsTickStopAIHang_Set(!1),
l.S.getInst().IsClickStopAIHang_Set(!1),r._.getInst().clearAItime(),void r._.getInst().ClosePauseIcon()
r._.getInst().ishang_get()?(r._.getInst().endHang(),r._.getInst().ishang_set(!1),s.Y.Inst.ClearCurTarget()):r._.getInst().startOrEndHang(s.Y.Inst.PrimaryRole_get())
}else e==o.I.GMOpenPanel&&GmControl.Inst().Open()}OnFunItemPress(e,t){e==o.I.SwitchTarget&&t&&SwitchTargetManager.inst_get().control.Open()}GetBtnImgId(e){
return e==o.I.eBagPanel?17:e==o.I.eTeamPanel?29:e==o.I.SwitchTarget?20:e==o.I.MarketPanel?35:0}GetBtnFunName(e){return e==o.I.eBagPanel?(0,n.T)("背包"):e==o.I.eTeamPanel?(0,
n.T)("组队"):e==o.I.SwitchTarget?(0,n.T)("目标"):e==o.I.MarketPanel?(0,n.T)("积分商城"):e==o.I.HangOpenPanel?(0,n.T)("挂机"):e==o.I.GMOpenPanel?"GM":e==o.I.GetAuctionPanel?(0,n.T)("拍卖"):""}
GetBtnResName(e){
return e==o.I.eBagPanel?"mainui_functionicon_0001":e==o.I.eTeamPanel?"mainui_functionicon_0006":e==o.I.SwitchTarget?"mainui_functionicon_0011":e==o.I.MarketPanel?"mainui_functionicon_0051":e==o.I.HangOpenPanel?"mainui_functionicon_0006":e==o.I.GMOpenPanel?"mainui_functionicon_0001":e==o.I.GetAuctionPanel?"mainui_functionicon_0002":""
}GetPointId(e){let t=0
return e==o.I.eBagPanel?E.t.BAG:e==o.I.eTeamPanel||e==o.I.SwitchTarget?t:e==o.I.MarketPanel?(t=MarketMainModel.GetInst().GetPointIdByKey("marketId"),t):t}GetGuideID(e){return 0}
GetFuncItemByFuncId(e){const t=this.control.mainViewPanel
return null!=t&&t.isShow_get()&&t.ui_mainview_operationentrance.node.activeInHierarchy?t.ui_mainview_operationentrance.GetFuncItem(e):null}GetFuncItemByFuncIdEx(e){
const t=this.control.mainViewPanel
let i=null
return t&&(!i&&t.ui_mainview_operationentrance&&(i=t.ui_mainview_operationentrance.GetFuncItem(e)),!i&&t.ui_funcopenpanel&&(i=t.ui_funcopenpanel.GetFuncItemById(e))),i}
DoSpreadBtns(e){C.h.Inst_get().isBtnSpread=e
const t=this.control.mainViewPanel
null!=t&&t.isShow_get()&&null!=t.funcSetPanel&&t.funcSetPanel.UpdateList()}CheckToSpread(e){if(null!=e&&p.P.Inst_get().IsFunctionOpened(e)){const t=m.d.Inst_get().getItemById(e)
if(null!=t){const e=I.m.Inst_get().getItemById(t.nameId)
if(1!=e.stay)if(1==e.area_type){const e=this.control.mainViewPanel
null!=e&&e.isShow_get()&&null!=e.funcSetPanel&&e.funcSetPanel.OnChangeBattleClick()}else 0==e.area_type&&d.y.Inst.ShowSpecialContainer(!0)}}}IsSpreadBtns(){
const e=this.control.mainViewPanel
if(null!=e&&e.isShow_get()&&null!=e.funcSetView){return e.funcSetView.funcContainer.activeInHierarchy}return!1}OpenCommonBtns(e){null==e&&(e=!0)
const t=this.control.mainViewPanel
null!=t&&t.isShow_get()&&null!=t.ui_funcopenpanel&&(e?t.ui_funcopenpanel.OpenCommonBtns():t.ui_funcopenpanel.CloseCommonBtns())}IsCommonBtnsSpread(){
const e=this.control.mainViewPanel
return null==e||!e.isShow_get()||null==e.ui_funcopenpanel||!!e.ui_funcopenpanel.commonFuncContainer.activeInHierarchy}GetFuncBtnState(){
const e=this.control.mainViewPanel.funcSetView
return this.IsFuncBtnInAnime()?0:e.funcContainer.activeInHierarchy?1:2}IsFuncBtnInAnime(){const e=this.control.mainViewPanel
return!(null==e||!e.isShow_get()||null==e.funcSetView)&&e.funcSetView.IsInAnime()}GetWorldPosInRightBottom(e){var t=(0,S.Y)(T.o.MainViewPanel)
return t&&t.funcSetPanel?t.funcSetPanel.GetWorldPos(e):_.P.zero_get()}GetInittalWorldPosInRightBottom(e){const t=this.control.mainViewPanel
return null!=t&&t.isShow_get()&&null!=t.funcSetView?t.funcSetView.GetInitialWorldPosByFunId(e):_.P.zero_get()}GetBtnSprName(e){
return e==o.I.eBagPanel?"背包":e==o.I.eTeamPanel?"组队":e==o.I.SwitchTarget?"目标":e==o.I.MarketPanel?"积分商城":e==o.I.HangOpenPanel?"挂机":e==o.I.GMOpenPanel?"GM":e==o.I.GetAuctionPanel?"拍卖":""
}}Me.m_inst=null},47552:(e,t,i)=>{"use strict"
i.d(t,{x:()=>A})
var n=i(17409),s=i(86133),a=i(98800),r=i(89549),l=i(73206),o=i(97461),_=i(36241),u=i(19176),h=i(18202),c=i(5494),d=i(98130),m=i(85602),p=i(92679),g=i(55661),I=i(22662),E=i(96964),C=i(61149),S=i(41864),T=i(65550),f=i(21334)
class A{get view(){return this._view||(this._view=(0,n.Y)(c.I.MapChangeProgress)),this._view}constructor(){this.Callback=null,this.toMapId=0,this.parm=null,this.isChangeing=!1,
this.isCutDowning=!1,this.gotoMap=null,this._view=null,this.elementid=0,this.hasCallback=!1,this._degf_CallDestoryMapChangeProgressView=null,
this._degf_CloseMapChangeProgressView=null,this._degf_OnRoleChangeState=null,this._degf_OnShowProgressView=null,
this._degf_CallDestoryMapChangeProgressView=()=>this.CallDestoryMapChangeProgressView(),this._degf_CloseMapChangeProgressView=e=>this.CloseMapChangeProgressView(e),
this._degf_OnRoleChangeState=e=>this.OnRoleChangeState(e),this._degf_OnShowProgressView=e=>this.OnShowProgressView(e)}ChangeMap(e,t,i){
if(E.o.getInstance().InKarima())return void T.y.inst.ClientStrMsg(I.r.SystemTipMessage,(0,s.T)("当前在卡利玛中，禁止传送。"))
this.hasCallback=!1,a.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(p.g.ROLE_CHANGE_STATE,this._degf_OnRoleChangeState)
const n=f.p.Inst_get().GetMapById(a.Y.Inst.PrimaryRoleInfo_get().MapId_get())
if(this.gotoMap=f.p.Inst_get().GetMapById(e),null!=n&&null!=this.gotoMap)if(a.Y.Inst.PrimaryRoleInfo_get().Level_get()<this.gotoMap.minLevelLimit){
const e=S.h.GetLevelStr(this.gotoMap.minLevelLimit),t=new m.Z([e])
T.y.inst.ClientSysMessage(106043,t)}else if(C.k.inst.clearAuotoPk(),n.senceType!=g.S.WildMap||this.gotoMap.senceType!=g.S.WildMap)null!=t&&t(i)
else{u.S.getInst().InHang_get()&&_._.getInst().endHang(),a.Y.Inst.PrimaryRole_get().JustStand(),this.Callback=t,this.toMapId=e,this.parm=i
a.Y.Inst.PrimaryRole_get().MainRole_get().GetDisplayHandle()
this.ShowProgressView()}}OnRoleChangeState(e){const t=d.GF.INT(e)
t==r.k.Idle&&t!=r.k.None||this.BreakChangeMap()}BreakChangeMap(){this.CloseMapChangeProgressView(),
a.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(p.g.ROLE_CHANGE_STATE,this._degf_OnRoleChangeState),this.Callback=null,this.toMapId=0}ProgressOver(){
this.CloseMapChangeProgressView(),null!=this.Callback&&(this.hasCallback=!0,this.Callback(this.parm))}ShowProgressView(){(0,
n.Yp)(c.I.MapChangeProgress,null,this._degf_OnShowProgressView)}OnShowProgressView(e){return this.addList(),this.isCutDowning=!0,this.view}CallDestoryMapChangeProgressView(){
h.g.DestroyUIObj(this.view)}CloseMapChangeProgressView(e){0!=this.elementid&&(l.X.Inst.DeleteElement(this.elementid),this.elementid=0),this.isCutDowning=!1,(0,
n.sR)(c.I.MapChangeProgress),this.removeList()}addList(){o.i.Inst.AddEventHandler(p.g.CHANGE_MAP,this._degf_CloseMapChangeProgressView)}removeList(){
o.i.Inst.RemoveEventHandler(p.g.CHANGE_MAP,this._degf_CloseMapChangeProgressView)}}A.Instance=new A},93997:(e,t,i)=>{"use strict"
i.d(t,{p:()=>b})
var n=i(17409),s=i(77546),a=i(32076),r=i(86133),l=i(38045),o=i(98800),_=i(37397),u=i(12480),h=i(97461),c=i(57647),d=i(68662),m=i(13687),p=i(62370),g=i(5924),I=i(66788),E=i(56937),C=i(18202),S=i(31222),T=i(5494),f=i(52726),A=i(98789),y=i(35128),R=i(98130),D=i(98885),w=i(85602),L=i(92679),v=i(8013),O=i(75439),P=i(47786),N=i(21334),M=i(94568)
class b{constructor(){this.m_panel=null,this.m_isLoading=!1,this.m_showLoading=!1,this.mapLoadingType=3,this.isStopShow=!1,this.onFinishCallback=null,this.m_copyEntrancePanel=null,
this.gotoMapId=0,this.showHandler=null,this.m_loadType=0,this.m_copyStrs=null,this.m_nameStrs=null,this._updateLoadingTimer=0,this.copyEnterNameSpStr="",
this._degf_CallDestoryLoadingView=null,this._degf_CallEntranceDestory=null,this._degf_OnCreateLoadingView=null,this._degf_ShowEntranceHandler=null,
this._degf_OnArenaLoadingPanelLoad=null,this._degf_OnArenaLoadingPanelDestroy=null,this.arenaLoadingPanel=null,this.onFinishCallback=new w.Z,
this._degf_CallDestoryLoadingView=()=>this.CallDestoryLoadingView(),this._degf_CallEntranceDestory=()=>this.CallEntranceDestory(),
this._degf_OnCreateLoadingView=e=>this.OnCreateLoadingView(e),this._degf_ShowEntranceHandler=e=>this.ShowEntranceHandler(e),
this._degf_OnArenaLoadingPanelLoad=e=>this.OnArenaLoadingPanelLoad(e),this._degf_OnArenaLoadingPanelDestroy=()=>this.OnArenaLoadingPanelDestroy()}OpenLoading(){let e=""
null!=d.D.serverMSTime_get()&&(e=(0,l.tw)(d.D.serverMSTime_get())),s.s.Info(`${(0,r.T)("切图开始，打开通用loading界面，当前时间戳：")}${e} ${this.gotoMapId}`),
I.Y.Log(`MapLoadingControl OpenLoading ${(0,l.tw)(this.m_isLoading)}`)
const t=new E.v
t.layerType=f.F.Effect,t.positionType=A.$.eCustom,t.isShowMask=!1,S.N.inst.OpenById(T.I.MapLoading,this._degf_OnCreateLoadingView,this._degf_CallDestoryLoadingView,t),
o.Y.Inst.ResetMouseDownTime()}OnCreateLoadingView(e){return null==this.m_panel&&(this.m_panel=new M.i,this.m_panel.setId(e,null,0)),this.m_isLoading=!1,this.m_panel}
GotoShowHandler(){null!=this.showHandler&&this.showHandler()}CallDestoryLoadingView(){C.g.DestroyUIObj(this.m_panel),this.m_panel=null}CloseLoading(){
if(I.Y.Log("MapLoadingControl CloseLoading"),this.m_isLoading)return void(this.isStopShow=!0)
if(this.isStopShow=!1,u.y.Instance.isLoginLoading)return void(null!=this.m_panel&&S.N.inst.ClosePanel(this.m_panel))
o.Y.Inst.ResetMouseDownTime(),null!=this.m_panel||null!=this.m_copyEntrancePanel&&(this.m_copyEntrancePanel.isTransportEnd=!0)
let e=0
for(;e<this.onFinishCallback.Count();)null!=this.onFinishCallback[e]&&this.onFinishCallback[e](),e+=1
this.onFinishCallback.Clear()}RegistCallBack(e){this.onFinishCallback.Add(e)}UpdateValue(){let e=(0,n.Y)(T.I.MapLoading)
0==this.m_loadType&&null!=e&&e.StartUpdateValue()}OpenCopyCloseAuto(){let e=""
null!=d.D.serverMSTime_get()&&(e=(0,l.tw)(d.D.serverMSTime_get())),s.s.Info((0,r.T)("切图开始，打开副本loading界面，当前时间戳：")+e),this.OpenEnterCopyPanel()}OpenEnterCopyPanel(){const e=new E.v
e.layerType=f.F.Effect,S.N.inst.OpenById(T.I.eCopyEntrancePanel,this._degf_ShowEntranceHandler,this._degf_CallEntranceDestory,e),h.i.Inst.RaiseEvent(L.g.SCENE_LOADING,!0)}
ShowEntranceHandler(e){return null==this.m_copyEntrancePanel&&(this.m_copyEntrancePanel=new v.u,this.m_copyEntrancePanel.setId(e,null,0)),this.m_copyEntrancePanel}
CallEntranceDestory(){C.g.DestroyUIObj(this.m_copyEntrancePanel),this.m_copyEntrancePanel=null}CloseCopyPanel(){S.N.inst.ClosePanel(T.I.eCopyEntrancePanel),
h.i.Inst.RaiseEvent(L.g.SCENE_LOADING,!1)}IsEntranceOpen(){return!(null==this.m_copyEntrancePanel||!this.m_copyEntrancePanel.isShow_get())}OpenArenaCloseAuto(){let e=""
null!=d.D.serverMSTime_get()&&(e=(0,l.tw)(d.D.serverMSTime_get())),s.s.Info((0,r.T)("切图开始，打开竞技场副本loading界面，当前时间戳：")+e),this.OpenArenaLoadingPanel()}OpenArenaLoadingPanel(){
const e=new E.v
e.layerType=f.F.Effect,e.isShowMask=!0}CloseArenaLoadingPanel(){
null==this.arenaLoadingPanel?S.N.inst.UnLoading(T.I.eCrossArenaEntrancePanel):S.N.inst.CloseById(T.I.eCrossArenaEntrancePanel)}OnArenaLoadingPanelLoad(e){}
OnArenaLoadingPanelDestroy(){C.g.DestroyUIObj(this.arenaLoadingPanel),this.arenaLoadingPanel=null}DealTransportImg(e,t,i,n){if(null==i&&(i=!0),null==n&&(n=!1),this.m_loadType=0,
null!=this.m_panel&&this.m_panel.isShow&&e!=this.gotoMapId)return this.gotoMapId=e,this.showHandler=t,void this.m_panel.ShowMapLoadingAtShowing()
this.gotoMapId=e,this.showHandler=t
const s=N.p.Inst_get().GetMapById(this.gotoMapId)
this._updateLoadingTimer=g.C.Inst_get().ClearInterval(this._updateLoadingTimer),n?(_._.Inst.EndLoginLoading(!0,!0),this.m_loadType=3,this.showHandler(),
this._updateLoadingTimer=g.C.Inst_get().SetInterval((0,a.v)(this._UpdateLoadValue,this),100)):this.IsCopyEnter(s.controllerType)?(_._.Inst.EndLoginLoading(!0,!0),this.m_loadType=1,
this.OpenCopyCloseAuto()):(_._.Inst.EndLoginLoading(!0),i&&this.OpenLoading())}_UpdateLoadValue(){let e=!1
m.b.Inst.IsReady()&&(3==this.m_loadType?c.R.LogoMovieFinished&&(e=!0):e=!0),e&&(this._updateLoadingTimer=g.C.Inst_get().ClearInterval(this._updateLoadingTimer),
3==this.m_loadType&&c.R.UnLoadLogoMovie())}IsCopyEnter(e){let t=0
for(;t<this.copyStrs_get().count;){if(this.m_copyStrs[t]==e)return this.copyEnterNameSpStr=this.m_nameStrs[t],!0
t+=1}return!1}copyStrs_get(){if(null==this.m_copyStrs){const e=O.D.getInstance().getContent("COPY:ENTER_ANIMATION"),t=D.M.Split(e.getContent().stringVal,p.o.s_Arr_UNDER_CHAR_DOLL)
this.m_copyStrs=D.M.Split(t[0],p.o.s_Arr_UNDER_CHAR_DOU),t.count>1&&(this.m_nameStrs=D.M.Split(t[1],p.o.s_Arr_UNDER_CHAR_DOU))}return this.m_copyStrs}GetTransportDes(){
if(u.y.Instance.isLoginLoading)return""
const e=N.p.Inst_get().GetMapById(this.gotoMapId),t=D.M.Split(e.transportDesc,p.o.s_Arr_UNDER_CHAR_DOT)
let i=R.GF.INT(y.p.RandomMinMax(0,t.count))
i=D.M.String2Int(t[i])
const n=P.x.Inst().getItemById(i)
return null==n?(I.Y.LogError(`gotoMapId：${this.gotoMapId+((0,r.T)("的loading文字描述Id：")+(i+(0,r.T)("没有找到,速叫策划查看")))}`),""):n.sys_messsage}}b.inst=new b},11845:(e,t,i)=>{"use strict"
i.d(t,{F:()=>C})
var n=i(17409),s=i(13687),a=i(5924),r=i(61911),l=i(56937),o=i(18202),_=i(31222),u=i(5494),h=i(52726),c=i(87923),d=i(21334),m=i(9312),p=i(99294),g=i(3522),I=i(72005)
class E extends r.f{constructor(){super(),this.txtSp=null,this.anime=null,this.effect=null,this.m_timerId=0,this.effectIntervalId=-1,this._degf_OnInterval=null,
this._degf_PlayEffect=null,this._degf_OnInterval=()=>this.OnInterval(),this._degf_PlayEffect=()=>this.PlayEffect()}InitView(){this.DestoryPanelLevel=r.f.DestoryLevel4,
this.txtSp=new I.w,this.txtSp.setId(this.FatherId,this.FatherComponentID,1),this.anime=new g.k,this.anime.setId(this.FatherId,this.FatherComponentID,2),this.effect=new p.z,
this.effect.setId(this.FatherId,this.FatherComponentID,3)}OnAddToScene(){const e=d.p.Inst_get().GetMapById(s.b.Inst.currentMapId_get())
this.txtSp.spriteNameSet(e.senceUi),this.txtSp.MakePixelPerfect(),this.anime.SetResetOnPlay(!0),this.anime.Play(!0,!1),this.effect.SetActive(!1),
this.effectIntervalId=a.C.Inst_get().SetInterval(this._degf_PlayEffect,300,1),this.m_timerId=a.C.Inst_get().SetInterval(this._degf_OnInterval,4e3,1)}PlayEffect(){
this.effect.SetActive(!1),this.effect.SetActive(!0)}OnInterval(){C.inst.CloseMiracleMapTitlePanel()}Clear(){a.C.Inst_get().ClearInterval(this.m_timerId),
a.C.Inst_get().ClearInterval(this.effectIntervalId)}Destroy(){this.txtSp=null,this.anime=null,this.effect=null}}class C{get m_panel(){return(0,n.Y)(u.I.MapTitleDirfting)}
constructor(){this.m_isFrontPLOT=!1,this.m_isFrontLostabyss=!1,this.miracleMapTitlePanel=null,this.m_eliteTipPanel=null,this._degf_CallDestoryEliteTip=null,
this._degf_CallDestoryLoadingView=null,this._degf_CallDestoryMiracleMapTitle=null,this._degf_CloseEliteTipPanel=null,this._degf_OnCreateEliteTip=null,
this._degf_OnCreateLoadingView=null,this._degf_OnCreateMiracleMapTitle=null,this._degf_CallDestoryEliteTip=()=>this.CallDestoryEliteTip(),
this._degf_CallDestoryLoadingView=()=>this.CallDestoryLoadingView(),this._degf_CallDestoryMiracleMapTitle=()=>this.CallDestoryMiracleMapTitle(),
this._degf_CloseEliteTipPanel=()=>this.CloseEliteTipPanel(),this._degf_OnCreateEliteTip=e=>this.OnCreateEliteTip(e),this._degf_OnCreateLoadingView=e=>this.OnCreateLoadingView(e),
this._degf_OnCreateMiracleMapTitle=e=>this.OnCreateMiracleMapTitle(e)}Open(){let e=!0
this.m_isFrontPLOT&&(e=!1),this.m_isFrontLostabyss&&(e=!1)
const t=d.p.Inst_get().GetMapById(s.b.Inst.currentMapId_get())
null!=t&&(this.m_isFrontPLOT=!1,this.m_isFrontLostabyss=!1,"PLOT"==t.controllerType&&(this.m_isFrontPLOT=!0,e=!1),"LOST_ABYSS"==t.controllerType&&(this.m_isFrontLostabyss=!0),
(c.l.IsEmptyStr(t.senceUi)||"0"==t.senceUi)&&(e=!1),e&&this.OpenNormalMapTitle())}OpenNormalMapTitle(){const e=new l.v
e.layerType=h.F.Story,_.N.inst.OpenById(u.I.MapTitleDirfting,this._degf_OnCreateLoadingView,this._degf_CallDestoryLoadingView,e)}OnCreateLoadingView(e){
return null==this.m_panel&&(this.m_panel=new m.B,this.m_panel.setId(e,null,0)),this.m_panel}CallDestoryLoadingView(){o.g.DestroyUIObj(this.m_panel),this.m_panel=null}
CloseNormalPanel(){null!=this.m_panel&&_.N.inst.CloseById(u.I.MapTitleDirfting)}OpenMiracleMapTitle(){const e=new l.v
e.layerType=h.F.Story,_.N.inst.OpenById(u.I.eMiracleMapTitlePanel,this._degf_OnCreateMiracleMapTitle,this._degf_CallDestoryMiracleMapTitle,e)}OnCreateMiracleMapTitle(e){
return null==this.miracleMapTitlePanel&&(this.miracleMapTitlePanel=new E,this.miracleMapTitlePanel.setId(e,null,0)),this.miracleMapTitlePanel}CallDestoryMiracleMapTitle(){
o.g.DestroyUIObj(this.miracleMapTitlePanel),this.miracleMapTitlePanel=null}CloseMiracleMapTitlePanel(){
null!=this.miracleMapTitlePanel&&this.miracleMapTitlePanel.isShow_get()&&_.N.inst.CloseById(u.I.eMiracleMapTitlePanel)}OpenTipElite(){const e=new l.v
e.layerType=h.F.Story,_.N.inst.OpenById(u.I.eEliteTipPanel,this._degf_OnCreateEliteTip,this._degf_CallDestoryEliteTip,e)}OnCreateEliteTip(e){
return null==this.m_eliteTipPanel&&(this.m_eliteTipPanel=new r.f,this.m_eliteTipPanel.setId(e,null,0),a.C.Inst_get().SetInterval(this._degf_CloseEliteTipPanel,8e3,1)),
this.m_eliteTipPanel}CallDestoryEliteTip(){o.g.DestroyUIObj(this.m_eliteTipPanel),this.m_eliteTipPanel=null}CloseEliteTipPanel(){
null!=this.m_eliteTipPanel&&this.m_eliteTipPanel.isShow_get()&&_.N.inst.CloseById(u.I.eEliteTipPanel)}}C.inst=new C},67541:(e,t,i)=>{"use strict"
i.d(t,{p:()=>c})
var n=i(86133),s=i(5924),a=i(18202),r=i(31222),l=i(5494),o=i(31922),_=i(93877),u=i(61911)
class h extends u.f{constructor(){super(),this.lab_msg=null,this.delayTimer=-1,this._degf_Hide=null,this._degf_Hide=()=>this.Hide()}InitView(){this.lab_msg=new _.Q,
this.lab_msg.setId(this.FatherId,this.FatherComponentID,1)}OnAddToScene(){this.ClearDelayTimer(),this.lab_msg.textSet(c.Instance.showContent),
this.delayTimer=s.C.Inst_get().SetInterval(this._degf_Hide,c.Instance.delayTime,1)}Update(){this.lab_msg.textSet(c.Instance.showContent)}Hide(){this.ClearDelayTimer(),
c.Instance.CloseView()}ClearDelayTimer(){s.C.Inst_get().ClearInterval(this.delayTimer),this.delayTimer=-1,c.Instance.delayTime=c.defaultDelayTime}Clear(){this.ClearDelayTimer(),
super.Clear()}Destroy(){super.Destroy()}}class c{constructor(){this.showContent=null,this.delayTime=c.defaultDelayTime,this.CON_ENTER_FIELD_OCCUPY_RING_FLAG=!1,
this.systemForceMsgView=null,this._degf_CallDestoryView=null,this._degf_DelayEnterCopy37ShowView=null,this._degf_ShowViewHandler=null,
this._degf_CallDestoryView=()=>this.CallDestoryView(),this._degf_DelayEnterCopy37ShowView=()=>this.DelayEnterCopy37ShowView(),this._degf_ShowViewHandler=e=>this.ShowViewHandler(e)}
CheckTrigger(e,t){e==o.z.CON_GUIDE_NEXT_VAL?103202==t&&(this.showContent=(0,n.T)("快拿上第一把武器开始勇者冒险吧！"),
this.OpenView()):e==o.z.COND_TYPE_ENTER_COPY_VAL?37==t&&s.C.Inst_get().SetInterval(this._degf_DelayEnterCopy37ShowView,6e3,1):e==o.z.STORY_END_VAL&&(1018==t?(this.showContent=(0,
n.T)("快去帮智力MM抢回魔化之地挂机点！"),this.OpenView()):1019==t&&(this.showContent=(0,n.T)("和智力MM组队在魔化之地升级吧！"),this.OpenView()))}DelayEnterCopy37ShowView(){this.showContent=(0,
n.T)("魔化之地是经验效率最高的刷怪点！"),this.OpenView()}ShowTextInForceMsg(e,t){this.showContent=e,this.delayTime=t&&t||c.defaultDelayTime,this.OpenView()}OpenView(){
null!=this.systemForceMsgView&&this.systemForceMsgView.isShow_get()?this.systemForceMsgView.OnAddToScene():r.N.inst.OpenById(l.I.eSystemForceMsgPanel,this._degf_ShowViewHandler,this._degf_CallDestoryView)
}ShowViewHandler(e){return null==this.systemForceMsgView&&(this.systemForceMsgView=new h,this.systemForceMsgView.setId(e,null,0)),this.systemForceMsgView}CallDestoryView(){
a.g.DestroyUIObj(this.systemForceMsgView),this.systemForceMsgView=null}CloseView(){null!=this.systemForceMsgView&&r.N.inst.ClosePanel(this.systemForceMsgView)}}
c.defaultDelayTime=3e3,c.Instance=null},52396:(e,t,i)=>{"use strict"
i.d(t,{h:()=>A})
var n=i(38836),s=i(98800),a=i(97461),r=i(13687),l=i(54967),o=i(38935),_=i(66788),u=i(85602),h=i(38962),c=i(92984),d=i(92679),m=i(52864),p=i(57035),g=i(37648),I=i(75439),E=i(10136),C=i(76887),S=i(40621),T=i(62734),f=i(21334)
class A extends l.g{constructor(){super(),this.funcItemDic=null,this.buffList=null,this.FuncItemEffectDic=null,this.isBtnSpread=!1,this.UsingSpreadStageIDList=new u.Z,
this.EffCliclEdList=null,this.isBattle=!1,this.funcItemDic=new h.X,this.FuncItemEffectDic=new h.X,this.EffCliclEdList=new u.Z}static Inst_get(){return null==A.inst&&(A.inst=new A),
A.inst}Inst_set(e){A.inst=e}ResetModel(){this.FuncItemEffectDic.LuaDic_Clear(),this.EffCliclEdList.Clear(),this.UsingSpreadStageIDList={}}GetSkillIcons(){const e=new u.Z
let t=0
for(;t<4;)e.Add(t),t+=1
return e}IsShowRedPoint(e){if(null==e.funcData)return!1
const t=S.c.Instance_get().GetIdByFunc(e.funcData.id),i=T.f.Inst.GetData(t)
return!!i&&i.show}UpdaeBuffData(){this.buffList=c.j.Inst_get().model.getBuffsByPlayerId(s.Y.Inst.PrimaryRoleInfo_get().Id_get()),c.j.Inst_get().model.arenaRewardBuffIndex=0}
UpdateFuncItemEffectState(e,t){null==t&&(t=!1)
let i=0
t&&(i=1),this.FuncItemEffectDic[e]=i
const n=new m.V
n.id=e,n.isShowEffect=t,a.i.Inst.RaiseEvent(d.g.FUNCITEM_EFFECT_UPDATE,n)}ShowOperation(e){if(2!=e.area_type)return!1
const t=f.p.Inst_get().GetMapById(r.b.Inst.currentMapId_get())
if(null!=t&&t.HideButtonsList.Count()>0&&t.HideButtonsList.Contains(e.id))return!1
if("OPENASURAMWAR"==e.id&&AsuramPreNoticeModel.inst.btnActive)return!0
if("QUESTIONNAIRE"==e.id)return PlayerCommunityControl.Inst_Get().IsShowTopBtn()
if("RIDINGBUY"==e.id&&C.$.Inst().GetRidingBuyVoDict().LuaDic_Count()>0)return!0
const i=p.d.Inst_get().GetItemByNameId(e.id)
if(null==i)return!1
if(g.P.Inst_get().IsFunctionClosed(i.id))return!1
const n=g.P.Inst_get().IsFuncOrActivityOpened(i.id)
if("TESTREBATE"==e.id&&n){if(RechargeByTesterModel.GetInst().isReceive)return!1
if(RechargeByTesterModel.GetInst().rechargeNum<=0)return!1}return n}GetOpFixNum(){return I.D.getInstance().GetIntValue("UI:OP_ICON_SHOW")}GetOpArrowNum(){
return I.D.getInstance().GetIntValue("UI:OP_FOLD_ICON_NUM")}GetOpChatNum(){I.D.getInstance().GetIntValue("UI:AUTO_CLOSE_OP")
return 2}GetOpCloseTime(){return I.D.getInstance().GetIntValue("UI:AUTO_CLOSE_OP_TIME")}UseSpreadStageID(){for(const[e,t]of(0,
n.O6)(A.AllSpreadStageIDs))if(!this.UsingSpreadStageIDList[t])return this.UsingSpreadStageIDList[t]=!0,t
_.Y.LogError("无可用stageid")}RecyleSpreadStageID(e){e&&(this.UsingSpreadStageIDList[e]=null)}ReqFunctionRedPoint(e){if(!this.EffCliclEdList.Contains(e)){const t=new E.e
t.functionId=e,o.C.Inst.F_SendMsg(t),this.EffCliclEdList.Add(e),this.UpdateFuncItemEffectState(e,!1)}}GetEffState(e,t){
if(2==t)return!this.FuncItemEffectDic.LuaDic_ContainsKey(e)||1==this.FuncItemEffectDic[e]
if(3==t){if(!this.EffCliclEdList.Contains(e))return!0}else if(4==t)return!0
return!1}}A.UPDATE_FUN_ITEM="update_fun_item",A.inst=null,A.AllSpreadStageIDs=[132,133,134,135,136]},37322:(e,t,i)=>{"use strict"
i.d(t,{c:()=>o})
var n=i(18998),s=i(68662),a=i(30621),r=i(5924),l=i(81629)
class o{constructor(e,t,i,n=null,s=null,a=null){this.m_listener=null,this.m_clickHandler=null,this.m_longPressHandler=null,this.m_PressHandler=null,this.m_pressingHandler=null,
this.m_goTran=null,this.m_startPosX=0,this.m_startPosY=0,this.m_startPosZ=0,this.moveFixX=10,this.moveFixY=10,this.m_isMove=!1,this.needcheckMove=!0,this.frameHandler=null,
this.moveEndHandler=null,this.delayTime=500,this.m_pressingSpan=200,this.pressingId=0,this.m_timerid=-1,this.m_loopCount=0,this.m_pressCalled=!1,this.clickInterval=-1,
this._degf_OnAction=null,this._degf_OnBgClick=null,this._degf_OnBgPressed=null,this._degf_OnBgPressedOut=null,this._degf_doPressingFun=null,this.onpresstime=0,null==a&&(a=200),
this._degf_OnAction=()=>this.OnAction(),this._degf_OnBgClick=()=>this.OnBgClick(),this._degf_OnBgPressed=e=>this.OnBgPressed(e,!0),
this._degf_OnBgPressedOut=e=>this.OnBgPressed(e,!1),this._degf_doPressingFun=()=>this.doPressingFun(),o.m_useKey=(o.M_KEY+=1,o.M_KEY),this.m_goTran=e,this.m_listener=e,
this.m_clickHandler=t,this.m_longPressHandler=i,this.m_PressHandler=n,this.m_pressingHandler=s,this.m_pressingSpan=a}AddEvent(){
this.m_listener.on(n.NodeEventType.TOUCH_START,this._degf_OnBgPressed,this),this.m_listener.on(n.NodeEventType.TOUCH_END,this._degf_OnBgPressedOut,this),
this.m_listener.on(n.NodeEventType.TOUCH_CANCEL,this._degf_OnBgPressedOut,this)}RemoveEvent(){
this.m_listener&&(this.m_listener.off(n.NodeEventType.TOUCH_START,this._degf_OnBgPressed,this),this.m_listener.off(n.NodeEventType.TOUCH_END,this._degf_OnBgPressedOut,this),
this.ClearPressingFun())}OnBgPressed(e,t){if(this.doPress(e,t),this.doPressingProcess(e,t),t)this.m_pressCalled=!1,this.m_isMove=!1,
[this.m_startPosX,this.m_startPosY]=[e.clientX,e.clientY],this.onpresstime=a.R.serverMSTime_get(),r.C.Inst_get().ClearInterval(this.m_timerid),
this.m_timerid=r.C.Inst_get().SetInterval(this._degf_OnAction,30),this.OnAction()
else{if(r.C.Inst_get().ClearInterval(this.m_timerid),this.m_timerid=0,this.m_isMove&&!this.m_pressCalled)return null!=this.moveEndHandler&&this.moveEndHandler(),
void(this.onpresstime=0)
this.m_pressCalled?null!=this.m_longPressHandler&&this.m_longPressHandler(e):!this.m_pressCalled&&this.onpresstime>0&&this.OnBgClick(),this.onpresstime=0}}OnBgClick(){
this.clickInterval=0,this.ButtonClick(),null!=this.m_clickHandler&&this.m_clickHandler(),console.log("OnBgClick")}ClearPressingFun(){
this.pressingId&&this.pressingId>0&&(r.C.Inst_get().ClearInterval(this.pressingId),this.pressingId=0)}doPressingProcess(e,t){
null!=this.m_pressingHandler&&(t?(this.ClearPressingFun(),this.pressingId=r.C.Inst_get().SetInterval(this._degf_doPressingFun,this.m_pressingSpan,-1)):this.ClearPressingFun())}
doPressingFun(){null!=this.m_pressingHandler&&this.m_pressingHandler()}doPress(e,t){null!=this.m_PressHandler&&this.m_PressHandler(e,t)}ButtonClick(){const e=this.m_goTran.position
l.K.inst.PlayClickEffect(e.x,e.y)}OnAction(){if(null==this.m_goTran)return r.C.Inst_get().ClearInterval(this.m_timerid),void(this.m_timerid=0)
if(this.m_isMove||(this.m_isMove=this.isMove()),this.m_isMove&&this.needcheckMove)return
null!=this.frameHandler&&this.frameHandler()
s.D.serverMSTime_get()-this.onpresstime>this.delayTime&&!this.m_pressCalled&&(this.m_pressCalled=!0,null!=this.m_longPressHandler&&this.m_longPressHandler())}isMove(){return!1}
Clear(){this.RemoveEvent(),this.ClearPressingFun(),r.C.Inst_get().ClearInterval(this.m_timerid),this.m_timerid=0,r.C.Inst_get().ClearInterval(this.clickInterval),
this.clickInterval=0}Destory(){this.m_listener=null,this.m_clickHandler=null,this.m_longPressHandler=null,this.m_PressHandler=null,this.m_goTran=null,this.frameHandler=null,
this.moveEndHandler=null}}o.M_KEY=1,o.m_useKey=0},78612:(e,t,i)=>{"use strict"
i.d(t,{g:()=>P})
var n,s=i(18998),a=i(6847),r=i(83908),l=i(49655),o=i(46282),_=i(38836),u=i(98800),h=i(97461),c=i(36241),d=i(70829),m=i(2577),p=i(98130),g=i(85602),I=i(94148),E=i(92679),C=i(37648),S=i(55492),T=i(12605),f=i(71379),A=i(28501),y=i(14792),R=i(62734),D=i(99130),w=i(34294),L=i(35259),v=i(52396),O=i(60130)
let P=(0,a.s_)(l.o.MainSkillListPanel,o.Z.ui_mainview_skilllist).layerNav().register()(n=class extends((0,r.Ri)()){constructor(...e){super(...e),this.m_startX=0,this.m_endX=0,
this.m_isMoveing=!1,this.redPoint=null,this.m_index=1,this.isout=!1,this._degf_OnGetItem=null,this._degf_clickAoYiHandler=null,this._degf_clickHandler=null,
this._degf_showSkill=null,this._degf_OnDragFinished=null,this._degf_OnDragStarted=null,this._degf_ExecuteAction=null,this._degf_FinishHandler=null,this._degf_SetMoveState=null,
this._degf_UpdateRedPoint=null,this.InChariot=null,this.aoyiNum=null,this.spreadAoYi=null,this.m_useX=null,this.skillother=void 0,this.isShow=void 0,this.ITEM_LEN=void 0,
this.scrollOffSetBegin=null}_initBinder(){this._degf_OnGetItem=e=>this.OnGetItem(e),this._degf_clickAoYiHandler=(e,t)=>this.clickAoYiHandler(e,t),
this._degf_clickHandler=(e,t)=>this.clickHandler(e,t),this._degf_showSkill=e=>this.showSkill(e),this._degf_OnDragFinished=()=>this.OnDragFinished(),
this._degf_OnDragStarted=()=>this.OnDragStarted(),this._degf_ExecuteAction=()=>this.ExecuteAction(),this._degf_FinishHandler=()=>this.FinishHandler(),
this._degf_SetMoveState=()=>this.SetMoveState(),this._degf_UpdateRedPoint=(e,t)=>this.UpdateRedPoint(e,t)}InitView(){
this.m_grid.SetInitInfo("ui_bottomfunction_shortcutitem",this._degf_OnGetItem,A.d),this.m_grid1.SetInitInfo("ui_bottomfunction_shortcutitem",this._degf_OnGetItem,A.d),
this.m_grid2.SetInitInfo("ui_bottomfunction_shortcutitem",this._degf_OnGetItem,A.d),this.redPoint=this.RedPoint,this.m_grid3.SetInitInfo("ui_bottomfunction_shortcutitem",null,f.j),
this.skillother=new g.Z,this.skillother.Add(this.skill1),this.skillother.Add(this.skill2),this.skillother.Add(this.skill3),this.skillother.Add(this.skill4),this.InChariot=!1,
this.aoyiNum=0,this.node.SetActive(v.h.inst.isBattle)}SetIndex(e){1==e?(this.point_page1.spriteNameSet("rymainui_sp_0051"),
this.point_page2.spriteNameSet("rymainui_sp_0052")):2==e&&(this.point_page1.spriteNameSet("rymainui_sp_0052"),this.point_page2.spriteNameSet("rymainui_sp_0051"))}OnGetItem(e){}
OnAddToScene(){this.ChangeTaret.node.SetActive(C.P.Inst_get().IsFunctionOpened(S.x.CHANGE_TARGET)),C.P.Inst_get().IsFunctionOpened(S.x.CHANGE_TARGET)
let e=w.L.Inst_get().GetPrimaryRoleSkillSlotVO()
this.isShow?this.SetIndex(e.selectIdx):(this.UpdateView(),this.RemoveLis(),this.AddLis(),this._OnUpdateAnchor(),this.isShow=!0,this.DoSpread(!0),this.SetSpreadBtnRedPoint(),
this.RegGuide(),this.UpdateAUTOPosHandler())}OnChangeTaret(){c._.OnChangeTaret()}ForcePlayAni(){this.OnUITweenStateChanged(this.isout,!0)}OnUITweenStateChanged(e,t){
null==t&&(t=!1),(this.isout!=e||t)&&(this.isout=e)}RegGuide(){}UnRegGuide(){}CheckGuide(){}_OnUpdateAnchor(){O.O.SetAnchorPos(this.anchor,!1,!0,-2,!1)}clickAoYiHandler(e,t){
T.g.Inst_get().SetShowAoYiSkill(!T.g.Inst_get().showAoYiSkill)}UpdateAUTOPosHandler(e){
this.ChangeTaret.node.transform.SetLocalPosition(new s.Vec3(T.g.Inst_get().auotoBtnX-220,163,0))}UpdateAoYiShow(e,t){let i=76
if(t){if(this.aoyiBtn.node.transform.SetLocalPosition(new s.Vec3(-76*this.aoyiNum+180,0,0)),this.spreadAoYi)t=!1
else{let e=this.aoyiTweenObj.node.transform.GetLocalPosition(),[n,a,r]=[e.x,e.y,e.z]
!(t=n==i*(this.aoyiNum-2))&&this.aoyiNum>2&&this.aoyiTweenObj.node.transform.SetLocalPosition(new s.Vec3(i*this.aoyiNum-400,0,0))}
this.spreadAoYi&&this.skillbg.widthSet(i*this.aoyiNum+344+30)}if(this.aoyiNum>1){if(this.aoyiBtn.node.SetActive(!0),
!T.g.Inst_get().initAoYi||this.spreadAoYi!=T.g.Inst_get().showAoYiSkill||t){this.spreadAoYi=T.g.Inst_get().showAoYiSkill,T.g.Inst_get().initAoYi=!0,
this.spreadAoYi?this.skillbg.widthSet(i*this.aoyiNum+344+40):this.skillbg.widthSet(460)
let e=this.aoyiTweenObj.node.transform.GetLocalPosition(),[t,n,a]=[e.x,e.y,e.z]
this.spreadAoYi?(this.aoyiBtn.node.transform.SetLocalPosition(new s.Vec3(-50,0,0)),this.aoyiTweenObj.SetLocalPosition(new s.Vec3(i*(3-this.aoyiNum)-185,0,0)),
this.aoyiBtn.node.setRotationFromEuler(0,0,180)):(this.aoyiTweenObj.SetLocalPosition(new s.Vec3(i*(this.aoyiNum-1)-185+i*(3-this.aoyiNum),0,0)),
this.aoyiBtn.node.setRotationFromEuler(0,0,0),this.aoyiBtn.node.transform.SetLocalPosition(new s.Vec3(-50,0,0)))}}else 1==this.aoyiNum?(this.aoyiBtn.node.SetActive(!1),
this.skillbg.widthSet(420),this.aoyiTweenObj.node.transform.SetLocalPosition(new s.Vec3(-30,0,0))):this.skillbg.widthSet(344)}clickHandler(e,t){}ChangeSkillModel(e){
let t=w.L.Inst_get().GetPrimaryRoleSkillSlotVO().selectIdx,i=e.IndexOf(t,0)
i+=1,i>=e.Count()&&(i=0),D.x.inst.CM_SelectSlotReq(e[i])}UpdateView(){let e=w.L.Inst_get().GetPrimaryRoleSkillSlotVO()
this.showSkill(),this.SetIndex(e.selectIdx),this.ChangeTaret.node.SetActive(C.P.Inst_get().IsFunctionOpened(S.x.CHANGE_TARGET)),C.P.Inst_get().IsFunctionOpened(S.x.CHANGE_TARGET),
this.UpdatePos()}OnFunctionOpen(e){e==S.x.CHANGE_TARGET&&this.ChangeTaret.node.SetActive(!0)}showSkill(e){
if(null==u.Y.Inst.primaryRole||null==u.Y.Inst.primaryRole.roleinfo||u.Y.Inst.primaryRole.roleinfo.InTransform())return
let t=w.L.Inst_get().GetPrimaryRoleSkillSlotVO(),i=!1
if(null!=e&&(i=e),null==t)return
t.slots
let n=null,s=w.L.Inst_get().GetRoleCurUseSkillSlot(u.Y.Inst.PrimaryRoleInfo_get().createIdx)
null!=s&&(n=s.skillUpM,null!=n&&this.UpdateSkill(n))}UpdateSkill(e){this.ITEM_LEN=8
let t=new g.Z,i=new g.Z,n=1
for(;n<=this.ITEM_LEN;){let s=0
s=e.LuaDic_GetItem(n),null==s&&(s=0)
let a=L.C.INSTANCE.GetSkillByStudyDic(s)
if(null==a)n<=4?t.Add(null):i.Add(null)
else{let e=d.j.Inst().GetSkillByIdLevel(s,a.level)
n<=4?t.Add(e):i.Add(e)}n+=1}this.m_grid1.data_set(t),this.m_grid2.data_set(i)
p.GF.INT(this.m_grid.cellWidth*t.Count())
this.skill1.spriteNameSet(""),this.skill2.spriteNameSet(""),this.skill3.spriteNameSet(""),this.skill4.spriteNameSet(""),this.UpdateAoYiSkill()}SkillLevelUpdateHandler(e){
3!=this.aoyiNum&&d.j.Inst().IsAoYiSkill(e)&&this.UpdateAoYiSkill()}UpdateAoYiSkill(){let e=INS.skillModel.GetAllAoYiSkill()
T.g.Inst_get().initAoYi||(this.aoyiNum=0)
let t=this.aoyiNum
this.aoyiNum=e.count
this.aoyiNum>0?(this.aoyiview.SetActive(!0),this.m_grid3.data_set(e),this.UpdateAoYiShow(null,this.aoyiNum!=t)):this.HideAoYi()}HideAoYi(){this.aoyiview.SetActive(!1),
this.skillbg.widthSet(344)}UpdateChariotSkill(){this.showSkill()}UpdateChariotSkillView(e){this.ITEM_LEN=8
let t=new g.Z,i=new g.Z,n=1
for(;n<=this.ITEM_LEN;){let s=""
if(s=e.LuaDic_GetItem(n),null==s)s="",n<=4?t.Add(null):i.Add(null)
else{let e=d.j.Inst().GetSkillByStrId(s)
n<=4?t.Add(e):i.Add(e)}n+=1}this.m_grid1.data_set(t),this.m_grid2.data_set(i),this.UpdateAoYiSkill()}OnDragStarted(){console.warn("开始滑动！"),
this.m_isMoveing||(this.m_startX=this.scrollView.node.transform.GetLocalPosition().x)}OnDragFinished(){console.warn("结束滑动！"),
this.m_isMoveing||(this.m_endX=this.scrollView.node.transform.GetLocalPosition().x,this.ChangeScrollPos())}ChangeScrollPos(){let e=!0
this.m_useX=this.m_startX
let t=this.m_endX-this.m_startX
if(t<20&&t>-20?(this.m_useX=this.m_startX,e=!1):(this.m_isMoveing=!0,Math.abs(this.m_startX-0)<100?t<=-20?(this.m_useX=-350,this.m_index=2):(this.m_useX=0,
this.m_index=1):t>=-20?(this.m_useX=0,this.m_index=1):(this.m_useX=-350,this.m_index=2)),e);else{let e=this.scrollView.node.transform.GetLocalPosition()
e.x=this.m_useX,this.scrollView.node.transform.SetLocalPosition(e),this.SetClipX(-this.m_useX,!1)}}ExecuteAction(){}SetMoveState(){this.m_isMoveing=!1}UpdateRedPoint(e,t){
this.SetSpreadBtnRedPoint()}SetSpreadBtnRedPoint(){let e=g.Z.TEMP_get()
e.Add(R.f.Inst.GetData(y.t.ASURAM)),e.Add(R.f.Inst.GetData(y.t.FORGE)),e.Add(R.f.Inst.GetData(y.t.SKILL_VIEW))
let t=!1,i=0
for(;i<e.Count();){if(null!=e[i]&&e[i].show){t=!0
break}i+=1}this.redPoint.SetActive(t)}FinishHandler(){this.m_isMoveing=!1,this.SetIndex(this.m_index)}SetClipX(e,t){}CDChangeHandler(){
if(null!=u.Y.Inst.primaryRole&&null!=u.Y.Inst.primaryRole.roleinfo&&u.Y.Inst.primaryRole.roleinfo.InTransform()){
if(null!=I.b.Inst_get().skillMap)return void this.UpdateChariotSkillView(I.b.Inst_get().skillMap)}else this.showSkill()}DoSpread(e){}ClearCd(){if(null!=this.m_grid){
let e=this.m_grid.itemList
if(null!=e)for(const[t,i]of(0,_.V5)(e)){null!=i&&i.cleanCD()}}}AddLis(){this.scrollView.node.on("page-turning",this.updatePageViewChange,this),
h.i.Inst.AddEventHandler(E.g.PRIMARY_ROLE_CHANGED,this._degf_showSkill),h.i.Inst.AddEventHandler(m.g.CD_CHANGE,this.CreateDelegate(this.CDChangeHandler)),
h.i.Inst.AddEventHandler(m.g.SHORTCUT_CHANGE,this._degf_showSkill),h.i.Inst.AddEventHandler(E.g.SKILL_USE_LIST_TYPE_CHANGE,this._degf_showSkill),
h.i.Inst.AddEventHandler(E.g.UPDATE_CHARIOT_SKILL,this.CreateDelegate(this.UpdateChariotSkill)),
T.g.Inst_get().AddEventHandler(T.g.AOYI_SKILL_SHOW,this.CreateDelegate(this.UpdateAoYiShow)),
T.g.Inst_get().AddEventHandler(T.g.AOUTO_POS_UPDATE,this.CreateDelegate(this.UpdateAUTOPosHandler)),this.m_handlerMgr.AddClickEvent(this.aoyiBtn,this._degf_clickAoYiHandler),
this.m_handlerMgr.AddEventMgr(E.g.UPDATE_ANCHORS,this.CreateDelegate(this._OnUpdateAnchor)),
this.m_handlerMgr.AddEventMgr(E.g.FUNCTION_OPEN,this.CreateDelegate(this.OnFunctionOpen)),
this.m_handlerMgr.AddEventMgr(E.g.FUNCTION_INIT_COMPLETE,this.CreateDelegate(this.UpdateView)),
this.m_handlerMgr.AddEventMgr(E.g.UITweenStateChanged,this.CreateDelegate(this.OnUITweenStateChanged)),
this.m_handlerMgr.AddEventMgr(E.g.JOB_SKILL_LEVELUP,this.CreateDelegate(this.SkillLevelUpdateHandler)),
this.m_handlerMgr.AddClickEvent(this.ChangeTaret,this.CreateDelegate(this.OnChangeTaret))}RemoveLis(){this.scrollView.node.off("page-turning",this.updatePageViewChange,this),
h.i.Inst.RemoveEventHandler(E.g.PRIMARY_ROLE_CHANGED,this._degf_showSkill),h.i.Inst.RemoveEventHandler(m.g.CD_CHANGE,this.CreateDelegate(this.CDChangeHandler)),
h.i.Inst.RemoveEventHandler(m.g.SHORTCUT_CHANGE,this._degf_showSkill),h.i.Inst.RemoveEventHandler(E.g.SKILL_USE_LIST_TYPE_CHANGE,this._degf_showSkill),
T.g.Inst_get().RemoveEventHandler(T.g.AOYI_SKILL_SHOW,this.CreateDelegate(this.UpdateAoYiShow)),
T.g.Inst_get().RemoveEventHandler(T.g.AOUTO_POS_UPDATE,this.CreateDelegate(this.UpdateAUTOPosHandler)),R.f.Inst.RemoveCallback(y.t.ASURAM,this._degf_UpdateRedPoint),
R.f.Inst.RemoveCallback(y.t.SETUP,this._degf_UpdateRedPoint),R.f.Inst.RemoveCallback(y.t.FORGE,this._degf_UpdateRedPoint),
R.f.Inst.RemoveCallback(y.t.SKILL_VIEW,this._degf_UpdateRedPoint)}onTouchScrollBegin(){this.scrollOffSetBegin=this.scrollPanel.getScrollOffset()}onTouchScrollEnd(){
const e=this.scrollPanel.getScrollOffset()
this.scrollOffSetBegin&&(e.x-this.scrollOffSetBegin.x>=10?this.scrollPanel.scrollToLeft():e.x-this.scrollOffSetBegin.x<=-10&&this.scrollPanel.scrollToRight(),
Math.abs(e.x-this.scrollOffSetBegin.x)<10&&(e.x-this.scrollOffSetBegin.x<0?this.scrollPanel.scrollToLeft():this.scrollPanel.scrollToRight()),this.scrollOffSetBegin=null)}
UpdatePos(){let e=O.O.GetUICanvasSize()
this.anchor.x=e.width/2,this.anchor.y=-e.height/2}updatePageViewChange(){let e=this.scrollView.curPageIdx+1
this.SetIndex(e)}Clear(){console.log("MainSkillListPanel Clear"),this.RemoveLis(),this.isShow=!1,this.isout=!1,this.aoyiNum=0,T.g.Inst_get().showAoYiSkill=!1,
this.aoyiview.SetActive(!1),this.UnRegGuide()}Destroy(){this.Clear()}})||n},94568:(e,t,i)=>{"use strict"
i.d(t,{i:()=>M})
var n,s,a=i(18998),r=i(21370),l=i(6847),o=i(83908),_=i(46282),u=i(77546),h=i(86133),c=i(38045),d=i(96098),m=i(12480),p=i(6700),g=i(68662),I=i(13687),E=i(62370),C=i(5924),S=i(66788),T=i(61911),f=i(31222),A=i(5494),y=i(60130),R=i(35128),D=i(98130),w=i(98885),L=i(72785),v=i(79534),O=i(75439),P=i(21334),N=i(93997)
let M=(0,l.s_)(A.I.MapLoading,_.Z.ui_map_loading).layerSet(r.T.tip).register()((s=class e extends((0,o.pA)(T.f)()){constructor(...e){super(...e),this.m_isLoadingComplete=!1,
this.m_isLoginLoadingComplete=!1,this.m_vec3=null,this.sliderTime=3e3,this.quickTime=150,this.progressUpValue=0,this.progressQuickUpValue=0,this.textureHeight=1440,this.isShow=!0,
this.interval1=-1,this.interval2=-1,this.progressOffset=0,this.isTransport=!1,this.isReady=!1,this._loadTexMaxTimeId=0,this.isLoadMapComplete=!1,this.loading_eff_container=null,
this.anim=null,this.uiwidget=null,this.loadingBar=null,this.loadingEffect=null,this.startUpdateValueTime=0}_initBinder(){super._initBinder(),this.m_vec3=new v.P}InitView(){}
OnAddToScene(){let t=!0
if(g.D.IsIosShenhe(!0)&&(t=!1),t||(this.bgSp.node.SetActive(!1),this.blackSp.node.SetActive(!1),this.loadingBar.SetActive(!1),this.loadingEffect.SetActive(!1)),this.isShow=!0,
N.p.inst.isStopShow)N.p.inst.CloseLoading()
else{if(m.y.Instance.isLoginLoading)this.sliderTime=5e3,this.progressUpValue=100/(this.sliderTime/e.sliderInterval),this.progressQuickUpValue=2*this.progressUpValue,
this.ClearForceCloseTimer(),this.SetAdapt(),this.UpdateView(),this.silder.DoF_SetValueEx(0,100)
else{let t=P.p.Inst_get().GetMapById(I.b.Inst.currentMapId_get()).loadingTimee
t<0&&(t=0),this.sliderTime=t,this.progressUpValue=100/(this.sliderTime/e.sliderInterval),this.progressQuickUpValue=2*this.progressUpValue,this.ClearForceCloseTimer(),
this.interval2=C.C.Inst_get().SetInterval(this.CreateDelegate(this.ForceClosePorgress),1e4,1),this.SetAdapt(),this.UpdateView(),this.silder.DoF_SetValueEx(0,100)}
this.progressUpValue<1&&(this.progressUpValue=1),this.progressQuickUpValue<10&&(this.progressQuickUpValue=10)}}SetAdapt(){const t=a.sys.getSafeAreaRect()
y.O.SetAnchorPos(this.bottom.transform,null,!0,-2,!1),y.O.SetAnchorPos(this.bottomleft.transform,!0,!0,-2,!1,null,-t.x)
const i=a.view.getVisibleSize().x,n=y.O.GetUIHeight()
this.bg.node.position.set(-t.x/2,this.bg.node.position.y,this.bg.node.position.z),this.bgSp.node.position.set(-t.x/2,this.bgSp.node.position.y,this.bgSp.node.position.z),
this.blackSp.node.position.set(-t.x/2,this.blackSp.node.position.y,this.blackSp.node.position.z),this.bgSp.widthSet(i-60),this.bg.widthSet(i),this.bg.heightSet(n),
this.blackSp.widthSet(i),this.blackSp.heightSet(n),this.frontimage.widthSet(i-e.REDUCE_VALUE),this.growimage.widthSet(i-e.REDUCE_VALUE),this.texture.widthSet(2*n),
this.texture.heightSet(2*n),this.textureHeight=2*n}UpdateView(){const e=this.GetLoadingImg()
let t=w.M.Split(e,E.o.s_Arr_UNDER_CHAR_DOT)
const i=D.GF.INT(R.p.RandomMinMax(0,t.count))
let n=w.M.String2Int(t[i]),s=D.GF.INT(.25*this.textureHeight)
n%2==0&&(s=D.GF.INT(.75*this.textureHeight),n-=1)
const a=this.texture.node.transform.GetLocalPosition()
a.y=s,this.texture.node.transform.SetLocalPosition(a)
let r=`transportmap_${n}`
S.Y.Log(`MapLoading ${r}`),this.m_isLoadingComplete=!1,this.m_isLoginLoadingComplete=!1,this._loadTexMaxTimeId=C.C.Inst_get().ClearInterval(this._loadTexMaxTimeId),
this._loadTexMaxTimeId=C.C.Inst_get().SetInterval(this.CreateDelegate(this.LoadTexMaxHandler),3e3,1),this.BgLoadComplete(),this.descLabel.textSet(N.p.inst.GetTransportDes())}
LoadTexMaxHandler(){this.AfterLoadTex()}GetLoadingImg(){let e=""
if(m.y.Instance.isLoginLoading)e="1001"
else{const t=N.p.inst
if(2==t.mapLoadingType){e=O.D.getInstance().getContent("CREATE_ROLE:LOADING_IMG").getContent().stringVal}else{e=P.p.Inst_get().GetMapById(t.gotoMapId).transportImg}}return e}
BgLoadComplete(e){S.Y.Log("MapLoadingPanel LoadComplete"),this.AfterLoadTex()}BgLoadComplete2(e){S.Y.Log("MapLoadingPanel LoadComplete2"),this.AfterLoadTex()}AfterLoadTex(){
this.m_isLoadingComplete||(this.m_isLoadingComplete=!0,
m.y.Instance.isLoginLoading?this.m_isLoginLoadingComplete=!0:(this._loadTexMaxTimeId=C.C.Inst_get().ClearInterval(this._loadTexMaxTimeId),p.L.Instance_get().CloseRender(),
N.p.inst.GotoShowHandler()))}ShowMapLoadingAtShowing(){this.m_isLoadingComplete&&this.m_isLoginLoadingComplete&&(S.Y.Log("MapLoadingPanel m_isLoginLoadingComplete"),
this.m_isLoginLoadingComplete=!1,this._loadTexMaxTimeId=C.C.Inst_get().ClearInterval(this._loadTexMaxTimeId),p.L.Instance_get().CloseRender(),N.p.inst.GotoShowHandler())}
StartUpdateValue(){this.startUpdateValueTime=g.D.serverMSTime_get(),this.m_isLoadingComplete=!0,this._loadTexMaxTimeId=C.C.Inst_get().ClearInterval(this._loadTexMaxTimeId),
this.ClearProgressTimer(),this.ClearForceCloseTimer(),this.UpdateValue(),this.interval1=C.C.Inst_get().SetInterval(this.CreateDelegate(this.UpdateValue),e.sliderInterval)}
ForceClosePorgress(){S.Y.LogWarning((0,h.T)("当前要转场的地图：")+(I.b.Inst.currentMapId_get()+(0,h.T)("加载时间大于10秒，强行关闭加载界面"))),this.LoadMapComplete(),this.progressOffset=100,
this.SetProgress(),this.ClearProgressTimer(),this.interval2=-1,this.ProgressLoadCompelete()}ClearProgressTimer(){this.interval1=C.C.Inst_get().ClearInterval(this.interval1)}
ClearForceCloseTimer(){-1!=this.interval2&&(C.C.Inst_get().ClearInterval(this.interval2),this.interval2=-1)}UpdateValue(){
if(m.y.Instance.isLoginLoading)this.progressOffset+=this.progressUpValue,this.progressOffset>50&&(this.progressOffset=50),this.SetProgress()
else{if((this.isReady||I.b.Inst.IsReady())&&g.D.serverMSTime_get()-this.startUpdateValueTime>2e3?(this.progressOffset+=10*this.progressUpValue,
this.isReady=!0):(this.progressOffset+=this.progressUpValue,this.progressOffset>98&&(this.progressOffset=98)),this.progressOffset>=100){let e=""
return null!=g.D.serverMSTime_get()&&(e=(0,c.tw)(g.D.serverMSTime_get())),u.s.Info(`${(0,h.T)("地图加载结束，当前时间戳：")}${e}  地图id:${I.b.Inst.currentMapId_get()}`),
C.C.Inst_get().SetFrameLoop(this.CreateDelegate(this.ProgressLoadCompelete),1,1),this.LoadMapComplete(),this.progressOffset=100,this.SetProgress(),this.ClearForceCloseTimer(),
void this.ClearProgressTimer()}this.SetProgress()}}SetProgress(){if(null==this.silder)return void L.c.DebugError((0,
h.T)("slider已经为空，但还是调用了SetProgress，进度条定时器为")+(this.interval1+((0,h.T)("，强关界面定时器为")+this.interval2)))
this.silder.DoF_SetValueEx(this.progressOffset,100),this.m_vec3.x=this.frontimage.width(),this.progressOffset
const e=this.progressOffset/100,t=`${D.GF.INT(100*e)}%`
this.progressLabel.textSet(t)}LoadMapComplete(){this.isLoadMapComplete||(I.b.Inst.loadMapComplete(),this.isLoadMapComplete=!0)}ProgressLoadCompelete(){this.isShow=!1,
p.L.Instance_get().OpenRender(),f.N.inst.ClosePanel(A.I.MapLoading),f.N.inst.ClosePanel(A.I.eMap),this.progressOffset=0,S.Y.Log((0,h.T)("地图转场完成"))}Clear(){
this.isLoadMapComplete=!1,this.isShow=!1,this.isReady=!1,this.ClearProgressTimer(),this.ClearForceCloseTimer(),
this._loadTexMaxTimeId=C.C.Inst_get().ClearInterval(this._loadTexMaxTimeId),N.p.inst.mapLoadingType=3,d.B.Inst.DealTransportEnd(!1)}Destroy(){
this._loadTexMaxTimeId=C.C.Inst_get().ClearInterval(this._loadTexMaxTimeId)}},s.sliderInterval=50,s.REDUCE_VALUE=84,n=s))||n},85638:(e,t,i)=>{"use strict"
i.d(t,{w:()=>m})
var n=i(5924),s=i(9057),a=i(93877),r=i(72005),l=i(18202),o=i(83540),_=i(98885),u=i(92984),h=i(26753),c=i(87923),d=i(79878)
class m extends s.x{constructor(){super(),this._intervalId=-1,this.m_VO=null,this._degf_OnClick=null,this._degf_TimeChange=null,this._degf_DelayRemoveBuff=null,this.icon=null,
this.countLabel=null,this.timeTxt=null,this.nameLabel=null,this._degf_OnLaterUpdate=null,this._degf_OnClick=(e,t)=>this.OnClick(e,t),this._degf_TimeChange=()=>this.TimeChange(),
this._degf_DelayRemoveBuff=(e,t)=>this.DelayRemoveBuff(e,t)}InitView(){this.icon=new r.w,this.icon.setId(this.FatherId,this.FatherComponentID,1),this.countLabel=new a.Q,
this.countLabel.setId(this.FatherId,this.FatherComponentID,2),this.timeTxt=new a.Q,this.timeTxt.setId(this.FatherId,this.FatherComponentID,3),this.nameLabel=new a.Q,
this.nameLabel.setId(this.FatherId,this.FatherComponentID,4)}SetData(e){this.Clear(),this.m_VO=e,
l.g.SetItemIcon(this.FatherId,this.icon.ComponentId,this.m_VO.buffRes_get().icon,o.b.eBuff,!1),this.nameLabel.textSet(this.m_VO.buffRes_get().buffName)
let t=""
if(this.m_VO.vo.showLayer>1&&(t=_.M.IntToString(this.m_VO.vo.showLayer)),this.countLabel.textSet(t),d.Y.RegLuaClick(this.icon.node,this._degf_OnClick),this.m_VO.vo.isStop){
const e=c.l.GetDateFormatEX(this.m_VO.vo.remainTime,!0,!0)
this.SetTimeTxt(e)
}else this.m_VO.buffRes_get().duration>0||u.j.Inst_get().model.IsSpecialDurationBuff(this.m_VO.buffRes_get().id)?(this._intervalId<0&&(this._intervalId=n.C.Inst_get().SetInterval(this._degf_TimeChange,1e3)),
this.TimeChange()):this.SetTimeTxt("")}ExpHangTimeHang(){}TimeChange(){if(null==this.m_VO)return
let e=""
this.m_VO.remainTime_get()<=0?(e+="0",n.C.Inst_get().ClearInterval(this._intervalId),this._intervalId=-1,
n.C.Inst_get().SetInterval(this._degf_DelayRemoveBuff,300,1)):e+=c.l.GetDateFormatEX(this.m_VO.remainTime_get(),!0,!0),c.l.IsEmptyStr(e)&&(e="00:00:00"),
null!=this.timeTxt&&this.timeTxt.IsObjectExist()&&this.SetTimeTxt(e)}DelayRemoveBuff(e,t){
null!=this.m_VO&&this.m_VO.remainTime_get()<=0&&(u.j.Inst_get().model.ForceMove(this.m_VO.owner,this.m_VO.buffRes_get().id),n.C.Inst_get().CallLater(this._degf_OnLaterUpdate))}
SetTimeTxt(e){this.timeTxt.textSet(e)}OnClick(e,t){h.d.Inst_get().controller.showPanel_get().SetDebuffTip(this.m_VO,2)}Clear(){d.Y.DelLuaClick(this.icon.node,this._degf_OnClick),
n.C.Inst_get().ClearInterval(this._intervalId),this._intervalId=-1,this.m_VO=null}Destroy(){super.Destroy()}}},24239:(e,t,i)=>{"use strict"
i.d(t,{w:()=>E})
var n=i(5924),s=i(99294),a=i(9057),r=i(93877),l=i(72005),o=i(18202),_=i(83540),u=i(60130),h=i(98885),c=i(79534),d=i(92984),m=i(26753),p=i(87923),g=i(79878),I=i(5031)
class E extends a.x{constructor(){super(),this.isDebuff=!1,this._intervalId=-1,this.m_VO=null,this._degf_OnClick=null,this._degf_TimeChange=null,this._degf_DelayRemoveBuff=null,
this.icon=null,this.Label=null,this.timeTxt=null,this.timeSp=null,this._degf_OnLaterUpdate=null,this.timeLabel=null,this._degf_OnClick=(e,t)=>this.OnClick(e,t),
this._degf_TimeChange=()=>this.TimeChange(),this._degf_DelayRemoveBuff=(e,t)=>this.DelayRemoveBuff(e,t)}InitView(){this.icon=new l.w,
this.icon.setId(this.FatherId,this.FatherComponentID,1),this.Label=new r.Q,this.Label.setId(this.FatherId,this.FatherComponentID,2),this.timeTxt=new r.Q,
this.timeTxt.setId(this.FatherId,this.FatherComponentID,3),this.timeSp=new s.z,this.timeSp.setId(this.FatherId,this.FatherComponentID,4),super.InitView()}SetData(e){this.Clear(),
this.m_VO=e,o.g.SetItemIcon(this.FatherId,this.icon.ComponentId,this.m_VO.buffRes_get().icon,_.b.eBuff,!1)
let t=""
if(this.m_VO.vo.showLayer>1&&(t=h.M.IntToString(this.m_VO.vo.showLayer)),this.Label.textSet(t),g.Y.RegLuaClick(this.icon.node,this._degf_OnClick),this.m_VO.vo.isStop){
const e=p.l.GetDateFormatEX(this.m_VO.vo.remainTime,!0,!0)
this.SetTimeTxt(e)
}else this.m_VO.buffRes_get().duration>0||d.j.Inst_get().model.IsSpecialDurationBuff(this.m_VO.buffRes_get().id)?(this._intervalId<0&&(this._intervalId=n.C.Inst_get().SetInterval(this._degf_TimeChange,1e3)),
this.TimeChange()):this.SetTimeTxt("")}OnClick(e,t){if(this.isDebuff){const e=u.O.GetRelateMousePiont(this.icon.node.transform)
m.d.Inst_get().controller.showPanel_get().SetDebuffTip(this.m_VO,1,e.x,e.y),c.P.Recyle(e)
}else I.T.inst_get().control.mainViewPanel.ui_mainview_headpanel.ShowPkDetailBuff(this.m_VO)}ExpHangTimeHang(){}TimeChange(){if(null==this.m_VO)return
let e=""
this.m_VO.remainTime_get()<=0?(e+="0",n.C.Inst_get().ClearInterval(this._intervalId),this._intervalId=-1,
n.C.Inst_get().SetInterval(this._degf_DelayRemoveBuff,300,1)):e+=p.l.GetDateFormatEX(this.m_VO.remainTime_get(),!0,!0),p.l.IsEmptyStr(e)&&(e="00:00:00"),
null!=this.timeTxt&&this.timeTxt.IsObjectExist()&&this.SetTimeTxt(e)}DelayRemoveBuff(e,t){
null!=this.m_VO&&this.m_VO.remainTime_get()<=0&&(d.j.Inst_get().model.ForceMove(this.m_VO.owner,this.m_VO.buffRes_get().id),n.C.Inst_get().CallLater(this._degf_OnLaterUpdate))}
SetTimeTxt(e){this.timeTxt.textSet(e)
const t=p.l.IsEmptyStr(e)
this.timeSp.SetActive(!t)}Clear(){g.Y.DelLuaClick(this.icon.node,this._degf_OnClick),n.C.Inst_get().ClearInterval(this._intervalId),this._intervalId=-1,this.m_VO=null}Destroy(){
this.icon=null,this.Label=null,this.timeLabel=null}}},49894:(e,t,i)=>{"use strict"
i.d(t,{o:()=>h})
var n=i(9057),s=i(93877),a=i(72005),r=i(18202),l=i(83540),o=i(98885),_=i(79878),u=i(5031)
class h extends n.x{constructor(){super(),this.icon=null,this.Label=null,this.m_VO=null,this._degf_OnClick=null,this.isDebuff=void 0,this._degf_OnClick=(e,t)=>this.OnClick(e,t)}
InitView(){this.icon=new a.w,this.icon.setId(this.FatherId,this.FatherComponentID,1),this.Label=new s.Q,this.Label.setId(this.FatherId,this.FatherComponentID,2)}SetData(e){
this.m_VO=e,r.g.SetItemIcon(this.FatherId,this.icon.ComponentId,this.m_VO.buffRes_get().icon,l.b.eBuff,!1)
let t=""
this.m_VO.vo.showLayer>1&&(t=o.M.IntToString(this.m_VO.vo.showLayer)),this.Label.textSet(t),_.Y.RegLuaClick(this.icon.node,this._degf_OnClick)}OnClick(e,t){
u.T.inst_get().control.OpenBuffDetailPanel(this.m_VO)}Clear(){null!=this.icon&&_.Y.DelLuaClick(this.icon.node,this._degf_OnClick)}Destroy(){this.Clear(),this.icon=null,
this.Label=null,this.m_VO=null}}},95619:(e,t,i)=>{"use strict"
i.d(t,{x:()=>g})
var n,s=i(18998),a=i(83908),r=i(5924),l=i(18202),o=i(83540),_=i(35128),u=i(98130),h=i(92984),c=i(42975),d=i(87923),m=i(75439),p=i(5031)
let g=s._decorator.ccclass("MainHeadBuffCell")(n=class extends((0,a.zB)()){constructor(...e){super(...e),this._VO=null,this._intervalId=-1,this.isBgShow=!1,this.bgHei=0,
this._degf_OnLaterUpdate=null,this._degf_TimeChange=null,this._degf_UpdateBuffList=null,this._degf_DelayRemoveBuff=null}InitView(){}AddEvent(){
h.j.Inst_get().model.AddEventHandler(c.E.UPDATE_BUFF_VIEW,this.CreateDelegate(this.UpdateBuffList))}RemoveEvent(){
h.j.Inst_get().model.RemoveEventHandler(c.E.UPDATE_BUFF_VIEW,this.CreateDelegate(this.UpdateBuffList))}UpdateBuffList(e){if(null!=this._VO&&9==this._VO.buffRes_get().relationType){
const e=h.j.Inst_get().model.IsHaveBuff(this._VO.owner,this._VO.buffRes_get().id)
null!=e?this.SetData(e):this.node.SetActive(!1)}}SetData(e){this.Clear(),this._VO=e,l.g.SetItemIcon(this.icon,this._VO.buffRes_get().icon,o.b.eBuff),
this.nameTxt.textSet(this._VO.showName_get())
let t=d.l.Substitute(this._VO.buffRes_get().desc,this._VO.values)
if(t=d.l.RegexN(t),this.expTxt.textSet(t),this.statusTxt.node.SetActive(this._VO.vo.isStop),this._VO.vo.isStop){const e=m.D.getInstance().getContent("BUFF:PAUSE_TEXT")
this.statusTxt.textSet(e.getContent().stringVal)
const t=d.l.GetDateFormatEX(this._VO.vo.remainTime,!0,!0)
this.timeTxt.textSet(t)
}else this._VO.buffRes_get().duration>0||h.j.Inst_get().model.IsSpecialDurationBuff(this._VO.buffRes_get().id)?(this._intervalId<0&&(this._intervalId=r.C.Inst_get().SetInterval(this.CreateDelegate(this.TimeChange),1e3)),
this.TimeChange()):this.timeTxt.textSet("")
this.SetSize()}SetSize(){if(null==this.expTxt)return
let e=30
e+=this.expTxt.height(),e>78?e+=10:e=78
const t=this.statusTxt.node.transform.GetLocalPosition(),i=this.expTxt.node.transform.GetLocalPosition()
this._VO.vo.isStop?i.y=t.y-this.statusTxt.height():i.y=t.y,this.expTxt.node.transform.SetLocalPosition(i)
const n=this.line.transform.GetLocalPosition()
if(n.y=i.y-this.expTxt.height()-10,this.line.transform.SetLocalPosition(n),this.isBgShow){let e=_.p.Abs(i.y+134)
e+=this.expTxt.height()+8,this.bg.heightSet(u.GF.INT(e)),this.bgHei=e}}TimeChange(){if(null==this._VO)return
let e=""
this._VO.remainTime_get()<=0?(e+="0",r.C.Inst_get().ClearInterval(this._intervalId),this._intervalId=-1,
r.C.Inst_get().SetInterval(this.CreateDelegate(this.DelayRemoveBuff),300,1)):e+=d.l.GetDateFormatEX(this._VO.remainTime_get(),!0,!0),d.l.IsEmptyStr(e)&&(e="00:00:00"),
this.timeTxt&&this.timeTxt.textSet(e)}DelayRemoveBuff(e,t){null!=this._VO&&this._VO.remainTime_get()<=0&&(h.j.Inst_get().model.ForceMove(this._VO.owner,this._VO.buffRes_get().id),
r.C.Inst_get().CallLater(this.CreateDelegate(this.OnLaterUpdate)))}OnLaterUpdate(){p.T.inst_get().control.headView.UpdateBuffList(null)}ExpHangTimeHang(){}
SetExpHangLeftTimeLabel(){}Clear(){r.C.Inst_get().ClearInterval(this._intervalId),this._intervalId=-1,this._VO=null}Destroy(){this._VO=null}})||n},9312:(e,t,i)=>{"use strict"
i.d(t,{B:()=>c})
var n,s=i(6847),a=i(83908),r=i(46282),l=i(13687),o=i(5924),_=i(5494),u=i(21334),h=i(11845)
let c=(0,s.s_)(_.I.MapTitleDirfting,r.Z.ui_map_titledrifting).register()(n=class extends((0,a.Ri)()){constructor(...e){super(...e),this.m_timerId=0,this._degf_OnInterval=null}
_initBinder(){super._initBinder(),this._degf_OnInterval=()=>this.OnInterval()}InitView(){}OnAddToScene(){const e=u.p.Inst_get().GetMapById(l.b.Inst.currentMapId_get())
this.txtSp.textSet(e.name),this.tween.ResetToBeginning(),this.tween.Play(),this.m_timerId=o.C.Inst_get().SetInterval(this._degf_OnInterval,4e3,1)}OnInterval(){
h.F.inst.CloseNormalPanel()}Clear(){o.C.Inst_get().ClearInterval(this.m_timerId)}Destroy(){}})||n},49821:(e,t,i)=>{"use strict"
i.d(t,{N:()=>d})
var n=i(93984),s=i(38836),a=i(86133),r=i(98800),l=i(62370),o=i(55360),_=i(98885),u=i(85602),h=i(72785),c=i(38962)
class d{constructor(){this.map=null,this.swordAttackNum=0,this.swordDefenceNum=0,this.swordCommonNum=0,this.maxNum=0,this.magicAttackNum=0,this.magicDefenceNum=0,
this.magicCommonNum=0,this.bowAttackNum=0,this.bowDefenceNum=0,this.bowCommonNum=0,this.swordAttack=null,this.swordDefence=null,this.swordCommon=null,this.magicAttack=null,
this.magicDefence=null,this.magicCommon=null,this.bowAttack=null,this.bowDefence=null,this.bowCommon=null,this.skilldic=null,this.allianceMasterProSkillMap=null,
this.attrRewardMap=null,this.allianceMasterProSkillMap=new c.X,this.attrRewardMap=new c.X
const e=o.Y.Inst.GetOrCreateCsv(n.h.eMasterTalent)
this.map=e.GetCsvMap(),this.InitList(),this.calNumByJob(1),this.calNumByJob(2),this.calNumByJob(3),this.InitAllianceMasterProSkillMap(),this.InitAttrRewardData()}static Inst(){
return null==d._inst&&(d._inst=new d),d._inst}ResetInitData(){this.maxNum=0,this.InitList(),this.calNumByJob(1),this.calNumByJob(2),this.calNumByJob(3)}InitAttrRewardData(){
for(const[e,t]of(0,s.V5)(this.map))this.attrRewardMap.LuaDic_AddOrSetItem(t.id,t.m_rValues)}InitAllianceMasterProSkillMap(){let e=null,t=null,i=""
for(const[n,a]of(0,s.V5)(this.map))6==a.talentType&&(e=new u.Z,i=a.preSkill,i=_.M.Replace(i,_.M.s_LEFT_M_K_CHAR_REPLACE,""),i=_.M.Replace(i,_.M.s_RIGHT_M_K_CHAR_REPLACE,""),
i=_.M.SubStringWithEnd(i,1,_.M.Length(i)-1),""!=i&&(t=_.M.Split(i,l.o.s_UNDER_CHAR),null!=t&&2==t.count&&(e[0]=_.M.String2Int(t[0]),e[1]=_.M.String2Int(t[1]),
this.allianceMasterProSkillMap.LuaDic_AddOrSetItem(_.M.IntToString(a.talentId)+(l.o.s_UNDER_CHAR+_.M.IntToString(a.level)),e))))}InitList(){this.swordAttack=new u.Z,
this.swordDefence=new u.Z,this.swordCommon=new u.Z,this.magicAttack=new u.Z,this.magicDefence=new u.Z,this.magicCommon=new u.Z,this.bowAttack=new u.Z,this.bowDefence=new u.Z,
this.bowCommon=new u.Z}getMap(){return this.map}getItemById(e){return this.map.LuaDic_ContainsKey(e)?this.map[e]:null}getItemByIdAndLevelEx(e,t,i){null==i&&(i=!0)
for(const[i,n]of(0,s.V5)(this.map))if(e==n.talentId&&n.level==t)return n
return i&&h.c.DebugError(`${(0,a.T)("TALENTRESOURCEEX里不存在 talentId:")}${e} level:${t}`),null}getItemByIdAndLevel(e,t,i){const n=100*(1e5*i+e)+t
return this.getItemById(n)}calNumByJob(e){}GetTalentResLisByJobAndType(e,t){
return 1==e?1==t?this.swordAttack:2==t?this.swordDefence:this.swordCommon:2==e?1==t?this.magicAttack:2==t?this.magicDefence:this.magicCommon:1==t?this.bowAttack:2==t?this.bowDefence:this.bowCommon
}getMinOrMaxLevelRes(e,t){if(null==t&&(t=!1),null!=this.map)for(const[i,n]of(0,s.V5)(this.map))if(n.talentId==e)if(t){if(n.level==n.maxLevel)return n}else if(1==n.level)return n
return null}getExerciseMinLevelRes(){let e=r.Y.Inst.PrimaryRoleInfo_get().Job_get()
e/=1e3
const t=new u.Z
if(null!=this.map)for(const[i,n]of(0,s.V5)(this.map))1==n.level&&2==n.talentType&&n.jobType==e&&t.Add(n)
return t}GetAllianceMasterProskillById(e,t){null==t&&(t=1)
const i=_.M.IntToString(e)+(l.o.s_UNDER_CHAR+_.M.IntToString(t))
return this.allianceMasterProSkillMap.LuaDic_ContainsKey(i)?this.allianceMasterProSkillMap[i]:null}GetAttrRewardById(e,t,i){const n=this.getItemByIdAndLevel(e,t,i)
return null!=n&&this.attrRewardMap.LuaDic_ContainsKey(n.id)?this.attrRewardMap[n.id]:null}}d._inst=null},26614:(e,t,i)=>{"use strict"
i.d(t,{C:()=>l})
var n=i(91385),s=i(16812),a=i(85602),r=i(38962)
class l extends s.k{constructor(){super(),this._degf_OnMutilTouch=null,this._degf_OnMutilTouchEnd=null,this._degf_OnMutilTouchOneEnd=null,this._degf_OnMutilTouchMove=null,
this._degf_OnMutilTouchStationary=null,this.callbackList=null,this.callbackMoveList=null,this.callbackStationaryList=null,this.TouchVoDic=null,this.callbackOneEndList=null,
this.callbackTouchList=null,this.callbackId=null,this.callbackIdTouch=null,this.callbackOneEndId=null,this.callbackId2=null,this.callbackId3=null,this.touchcount=null,
this._degf_OnMutilTouch=(e,t,i)=>this.OnMutilTouch(e,t,i),this._degf_OnMutilTouchEnd=e=>this.OnMutilTouchEnd(e),this._degf_OnMutilTouchOneEnd=e=>this.OnMutilTouchOneEnd(e),
this._degf_OnMutilTouchMove=(e,t,i,n,s)=>this.OnMutilTouchMove(e,t,i,n,s),this._degf_OnMutilTouchStationary=(e,t,i)=>this.OnMutilTouchStationary(e,t,i),this.callbackList=new a.Z,
this.callbackMoveList=new a.Z,this.callbackStationaryList=new a.Z,this.TouchVoDic=new r.X,this.callbackOneEndList=new a.Z,this.callbackTouchList=new a.Z}static Inst_get(){
return null==l._inst&&(l._inst=new l),l._inst}InitData(){}CheckAddEvent(){
this.callbackList.count>0?null==this.callbackId&&(this.callbackId=n.c.Inst_get().AddMutilTouchEndHandler(this._degf_OnMutilTouchEnd)):null!=this.callbackId&&(n.c.Inst_get().RemoveMutilTouchEndHandler(this.callbackId),
this.callbackId=null),
this.callbackTouchList.count>0?null==this.callbackIdTouch&&(this.callbackIdTouch=n.c.Inst_get().AddMutilTouchHandler(this._degf_OnMutilTouch)):null!=this.callbackIdTouch&&(n.c.Inst_get().RemoveMutilTouchHandler(this.callbackIdTouch),
this.callbackIdTouch=null),
this.callbackOneEndList.count>0?null==this.callbackOneEndId&&(this.callbackOneEndId=n.c.Inst_get().AddMutilTouchOneEndHandler(this._degf_OnMutilTouchOneEnd)):null!=this.callbackOneEndId&&(n.c.Inst_get().RemoveMutilTouchOneEndHandler(this.callbackOneEndId),
this.callbackOneEndId=null),
this.callbackMoveList.count>0?null==this.callbackId2&&(this.callbackId2=n.c.Inst_get().AddMutilTouchMoveHandler(this._degf_OnMutilTouchMove)):null!=this.callbackId2&&(this.callbackId2=n.c.Inst_get().RemoveMutilTouchMoveHandler(this.callbackId2),
this.callbackId2=null),
this.callbackStationaryList.count>0?null==this.callbackId3&&(this.callbackId3=n.c.Inst_get().AddMutilTouchStationaryHandler(this._degf_OnMutilTouchStationary)):null!=this.callbackId3&&(this.callbackId3=n.c.Inst_get().RemoveMutilTouchStationaryHandler(this.callbackId3),
this.callbackId3=null)}ResetData(){null!=this.callbackId&&(n.c.Inst_get().RemoveMutilTouchEndHandler(this.callbackId),this.callbackId=null),
null!=this.callbackId2&&(n.c.Inst_get().RemoveMutilTouchMoveHandler(this.callbackId2),this.callbackId2=null),
null!=this.callbackId3&&(this.callbackId3=n.c.Inst_get().RemoveMutilTouchStationaryHandler(this.callbackId3)),
null!=this.callbackOneEndId&&(this.callbackOneEndId=n.c.Inst_get().RemoveMutilTouchOneEndHandler(this.callbackOneEndId)),
null!=this.callbackIdTouch&&(this.callbackIdTouch=n.c.Inst_get().RemoveMutilTouchHandler(this.callbackIdTouch)),this.callbackList.Clear(),this.callbackMoveList.Clear(),
this.callbackStationaryList.Clear(),this.callbackOneEndList.Clear(),this.callbackTouchList.Clear()}AddMutilTouchEndHandler(e){
null==e||this.callbackList.Contains(e)||(this.callbackList.Add(e),this.CheckAddEvent())}RemoveMutilTouchEndHandler(e){if(null!=e){const t=this.callbackList.IndexOf(e)
t>-1&&(this.callbackList.RemoveAt(t),this.CheckAddEvent())}}AddMutilTouchHandler(e){null==e||this.callbackTouchList.Contains(e)||(this.callbackTouchList.Add(e),
this.CheckAddEvent())}RemoveMutilTouchHandler(e){if(null!=e){const t=this.callbackTouchList.IndexOf(e)
t>-1&&(this.callbackTouchList.RemoveAt(t),this.CheckAddEvent())}}AddMutilTouchOneEndHandler(e){null==e||this.callbackOneEndList.Contains(e)||(this.callbackOneEndList.Add(e),
this.CheckAddEvent())}RemoveMutilTouchOneEndHandler(e){if(null!=e){const t=this.callbackOneEndList.IndexOf(e)
t>-1&&(this.callbackOneEndList.RemoveAt(t),this.CheckAddEvent())}}AddMutilTouchMoveHandler(e){null==e||this.callbackMoveList.Contains(e)||(this.callbackMoveList.Add(e),
this.CheckAddEvent())}RemoveMutilTouchMoveHandler(e){if(null!=e){const t=this.callbackMoveList.IndexOf(e)
t>-1&&this.callbackMoveList.RemoveAt(t),this.CheckAddEvent()}}AddMutilTouchStationaryHandler(e){
null==e||this.callbackStationaryList.Contains(e)||(this.callbackStationaryList.Add(e),this.CheckAddEvent())}RemoveMutilTouchStationaryHandler(e){if(null!=e){
const t=this.callbackStationaryList.IndexOf(e)
t>-1&&(this.callbackStationaryList.RemoveAt(t),this.CheckAddEvent())}}OnMutilTouchEnd(e){this.touchcount=e
let t=null
if(e>0){t=new a.Z
for(let i=0;i<=e-1;i++){const e=n.c.Inst_get().GetFingerIDkPathPots(i)
t.Add(e)}for(let e=0;e<=this.callbackList.count-1;e++){(0,this.callbackList[e])(t)}}}OnMutilTouchOneEnd(e){for(let t=0;t<=this.callbackOneEndList.count-1;t++){(0,
this.callbackOneEndList[t])(e)}}OnMutilTouch(e,t,i){for(let n=0;n<=this.callbackTouchList.count-1;n++){(0,this.callbackTouchList[n])(e,t,i)}}OnMutilTouchMove(e,t,i,n,s){
for(let a=0;a<=this.callbackMoveList.count-1;a++){(0,this.callbackMoveList[a])(e,t,i,n,s)}}OnMutilTouchStationary(e,t,i){for(let n=0;n<=this.callbackStationaryList.count-1;n++){(0,
this.callbackStationaryList[n])(e,t,i)}}}l._inst=null},6189:(e,t,i)=>{"use strict"
i.d(t,{F:()=>l})
var n=i(85602),s=i(26614)
class a{constructor(){this.gameObject=null,this.scaleFac=null,this.maxScale=null,this.minScale=null,this.scaleX=null,this.scaleY=null,this.type=null}DealScale(e,t){
0==this.type?t=e=(e+t)/2:1==this.type||(2==this.type?t=e:3==this.type&&(e=t))
let i=e*this.scaleFac,n=t*this.scaleFac
const s=this.node.transform.GetLocalScale()
this.scaleX&&(i=s.x+i,i>this.maxScale&&(i=this.maxScale),i<this.minScale&&(i=this.minScale),s.x=i),this.scaleY&&(n=s.y+n,n>this.maxScale&&(n=this.maxScale),
n<this.minScale&&(n=this.minScale),s.y=n),this.node.transform.SetLocalScale(s)}}class r{constructor(){this.idx=-1,this.x=0,this.y=0,this.preX=0,this.preY=0,this.active=!1}
SetActive(e,t){this.preX=this.x,this.preY=this.y,this.x=e,this.y=t,this.active=!0}SetPos(e,t){this.preX=this.x,this.preY=this.y,this.x=e,this.y=t}SetUnActive(){this.preX=0,
this.preY=0,this.x=0,this.y=0,this.active=!1}}class l{constructor(){this.list=null,this.touchCount=0,this.scaleGoList=null,this.addEvent=!1,this.callbackList=null,
this.list=new n.Z,this.scaleGoList=new n.Z}static Inst_get(){return null==l._inst&&(l._inst=new l),l._inst}RegSacleGo(e,t,i,n,s,r,l){null==t&&(t=.01),null==i&&(i=10),
null==n&&(n=.5),null==r&&(r=!0),null==l&&(l=!0),null==s&&(s=0)
const o=this.scaleGoList.count-1
let _=null
for(let t=0;t<=o;t++){if(this.scaleGoList[t].node==e)break}null==_&&(_=new a,this.scaleGoList.Add(_),_.node=e),_.scaleFac=t,_.maxScale=i,_.minScale=n,_.scaleX=r,_.scaleY=l,
_.type=s,this.CheckAddEvent()}UnRegSacleGo(e){const t=this.scaleGoList.count-1
for(let i=0;i<=t;i++){if(this.scaleGoList[i].node==e){this.scaleGoList.RemoveAt(i)
break}}this.CheckAddEvent()}DealSacle(e,t){const i=this.scaleGoList.count-1
for(let n=0;n<=i;n++){this.scaleGoList[n].DealScale(e,t)}}AddHandler(e){null==e||this.callbackList.Contains(e)||(this.callbackList.Add(e),this.CheckAddEvent())}RemoveHandler(e){
if(null!=e){const t=this.callbackList.IndexOf(e)
t>-1&&(this.callbackList.RemoveAt(t),this.CheckAddEvent())}}CheckAddEvent(){this.list.count>0||this.scaleGoList.count>0?this.AddEvent():this.RemoveEvent()}AddEvent(){
this.addEvent||(s.C.Inst_get().AddMutilTouchMoveHandler(this.CreateDelegate(this.TouchMoveHandler)),
s.C.Inst_get().AddMutilTouchOneEndHandler(this.CreateDelegate(this.TouchOneEndHandler)),s.C.Inst_get().AddMutilTouchHandler(this.CreateDelegate(this.TouchHandler)),
this.addEvent=!0)}RemoveEvent(){this.addEvent&&(s.C.Inst_get().RemoveMutilTouchMoveHandler(this.CreateDelegate(this.TouchMoveHandler)),
s.C.Inst_get().RemoveMutilTouchOneEndHandler(this.CreateDelegate(this.TouchOneEndHandler)),s.C.Inst_get().RemoveMutilTouchHandler(this.CreateDelegate(this.TouchHandler)),
this.addEvent=!1)}TouchHandler(e,t,i){null==this.list[e]&&(this.list[e]=new r,this.list[e].idx=e),this.list[e].active||(this.list[e].SetActive(t,i),this.touchCount+=1)}
TouchOneEndHandler(e){null!=this.list[e]&&this.list[e].active&&(this.list[e].SetUnActive(),this.touchCount-=1)}TouchMoveHandler(e,t,i,n,s){if(this.touchCount>1&&e<2){let a=0
0==e&&(a=1)
const r=this.list[a].x,l=this.list[a].y
let[o,_]=[1,1]
t-r<0&&(o=-1),i-l<0&&(_=-1)
const u=o*(n-t),h=_*(s-i)
this.DealSacle(u,h),this.list[e].active&&this.list[e].SetPos(n,s)}}}l._inst=null},84141:(e,t,i)=>{"use strict"
i.d(t,{E:()=>_})
var n=i(86133),s=i(25236),a=i(98885),r=i(26133)
const l=globalThis.Date
let o=null
class _{static __StaticInit(){o=new r.G}constructor(){this._dt=null,this._baseDt=null,this._dt=new l,this._baseDt=new l(0)}static Recycle(e){if(o.Count()<20)return o.Add(e)}
static New(e=null){null!=e&&e<0&&(e=null)
let t=null
return o.Count()>0?(t=o.Pop(),null!=t&&(e?t.time_set(e):t._dt=new l)):(t=new _,e?t.time_set(e):t._dt=new l),t}GetTimeZone(){return 60*(new l).getTimezoneOffset()}date_get(){
return this._dt.getDate()}date_set(e){this._dt.setDate(e)}day_get(){return this._dt.getDay()}fullYear_get(){return this._dt.getFullYear()}fullYear_set(e){this._dt.setFullYear(e)}
hours_get(){return this._dt.getHours()}hours_set(e){this._dt.setHours(e)}hoursUTC_get(){return this._dt.getUTCHours()}milliseconds_get(){return this._dt.getTime()}minutes_get(){
return this._dt.getMinutes()}minutes_set(e){this._dt.setMinutes(e)}minutesUTC_get(){return this._dt.getUTCMinutes()}month_get(){return this._dt.getMonth()}month_set(e){
this._dt.setMonth(e)}seconds_get(){return this._dt.getSeconds()}seconds_set(e){this._dt.setSeconds(e)}secondsUTC_get(){return this._dt.getUTCSeconds()}time_get(){
return this._dt.getTime()}time_set(e){this._dt.setTime(e)}static time_set(e,t){t&&e.setTime(t)}getDate(){return this.date_get()}getDay(){return this.day_get()}getFullYear(){
return this.fullYear_get()}getHours(){return this.hours_get()}getMilliseconds(){return this.milliseconds_get()}getMinutes(){return this.minutes_get()}getMonth(){
return this.month_get()}getSeconds(){return this.seconds_get()}parse(e,t){null==t&&(t=!0)
const i=a.M.Split(e," ")
if(2!=i.Count())return void(0,s.S)((0,n.T)("参数字符串非法"))
const r=a.M.Split(i[0],"-")
if(3!=r.Count())return void(0,s.S)((0,n.T)("参数字符串日期非法"))
const o=a.M.Split(i[1],":")
if(3!=o.Count())return void(0,s.S)((0,n.T)("参数字符串时间非法"))
r[0],r[1],r[2],o[0],o[1],o[2]
const _=new l
if(t)return _.setUTCFullYear(Number(r[0])),_.setUTCMonth(Number(r[1])),_.setUTCDate(Number(r[2])),_.setUTCHours(Number(o[0])),_.setUTCMinutes(Number(o[1])),
_.setUTCSeconds(Number(o[2])),_.getTime()
_.setFullYear(Number(r[0])),_.setMonth(Number(r[1])),_.setDate(Number(r[2])),_.setHours(Number(o[0])),_.setMinutes(Number(o[1])),_.setSeconds(Number(o[2]))
return _.getTime()}setDate(e){return this.date_set(e),this.time_get()}setHours(e,t,i,n){this._dt.setHours(e),this._dt.setMinutes(t),this._dt.setSeconds(i)}setTime(e){
return this.time_set(e),this.time_get()}ResetCurTime(){this._dt.setTime(l.now())}static GetCurTime(){return null==_.CurDate&&(_.CurDate=_.New()),_.CurDate.ResetCurTime(),_.CurDate}
ToString(){return null==this._dt?null:_.ConcatStr(this._dt.getFullYear(),(0,n.T)("年"),this._dt.getMonth()+1,(0,n.T)("月"),this._dt.getDate(),(0,
n.T)("日"),this._dt.getHours(),":",this._dt.getMinutes(),":",this._dt.getSeconds())}static ConcatStr(...e){return e.join("")}}_.CurDate=null,_._dt=void 0,_.__StaticInit()},
68366:(e,t,i)=>{"use strict"
i.d(t,{N:()=>l})
var n=i(86133),s=i(68662),a=i(58178),r=i(84141)
class l extends r.E{Recycle(e){a.R.LogError((0,n.T)("只读时间，外部不允许修改"))}static New(){a.R.LogError((0,n.T)("只读时间，外部不允许修改"))}setDate(e){a.R.LogError((0,n.T)("只读时间，外部不允许修改"))}
setHours(e,t,i,s){a.R.LogError((0,n.T)("只读时间，外部不允许修改"))}setTime(e){a.R.LogError((0,n.T)("只读时间，外部不允许修改"))}time_set(e){a.R.LogError((0,n.T)("只读时间，外部不允许修改"))}ResetCurTime(){
a.R.LogError((0,n.T)("只读时间，外部不允许修改"))}static Inst_get(){return l.Inst||(l.Inst=new l),l.Inst._dt||(l.Inst._dt=new globalThis.Date),l.Inst}static ServerDate_get(){
return l.ServerDate?l.ServerDate._dt||super.time_set(l.ServerDate,s.D.serverMSTime_get()):(l.ServerDate=new l,super.time_set(l.ServerDate,s.D.serverMSTime_get())),l.ServerDate}
Update(){l.Inst&&(l.Inst._dt=null),l.ServerDate&&(l.ServerDate._dt=null)}}l.ServerDate=null,l.Inst=null},6251:(e,t,i)=>{"use strict"
i.d(t,{d:()=>s})
var n=i(78175)
class s{static LuaMakeGoGray(e,t){(0,n.FJ)(e,t)}static SetGray(e,t){e.grayscale=!!t}}},78300:(e,t,i)=>{"use strict"
i.d(t,{V:()=>r})
var n=i(52212),s=i(79534),a=i(44758)
class r{ONE_VECTOR3D_get(){return new s.P(1,1,1)}ZERO_VECTOR3D_get(){return new s.P(0,0,0)}ZERO_VECTOR4D_get(){return new a.L(0,0,0)}X_VECTOR3D_get(){return new s.P(1,0,0)}
NX_VECTOR3D_get(){return new s.P(-1,0,0)}Y_VECTOR3D_get(){return new s.P(0,1,0)}NY_VECTOR3D_get(){return new s.P(0,-1,0)}Z_VECTOR3D_get(){return new s.P(0,0,1)}NZ_VECTOR3D_get(){
return new s.P(0,0,-1)}static TEMP_VECTOR2D_get(){return new n.F(0,0)}static TEMP_VECTOR3D_get(){return new s.P(0,0,0)}TEMP_VECTOR4D_get(){return new a.L(0,0,0,0)}}r.s_Resinfo=1,
r.s_CsvDataID=2,r.s_AnimEventID=3,r.s_FootShadowID=4,r.s_ErrorResID=5,r.s_ElementCombineResID=6,r.s_SceneBlackID=7,r.s_LoadShaderID=8,r.s_ErrorTexID=9,r.s_ErrorModel=10,
r.s_DistortionID=11,r.s_DistortionAID=12,r.s_ConcomiID=13,r.s_TransparentTexID=14,r.s_DefaultTexID=15,r.s_SoundConfigID=16,r.s_TerrainElementID=17,r.s_UIDataID=18,
r.s_DropItemID=19,r.s_EnvID=70,r.s_bStopPreLoadAnimEvent=!1,r.s_bStopPreLoadElementCombineRes=!1,r.s_bStopPreLoadCCEventRes=!0,r.s_bStopPreLoadSoundConfigRes=!1,
r.s_bStopPreLoadTerrainElementRes=!0,r.s_DefaultModelID=0,r.s_ModelDelayTime=.5,r.s_FloatString=34,r.s_DynamicRes=50,r.s_DynamicResEnd=60,r.s_FontStart=61,r.s_FontEnd=70,
r.s_Font0=61,r.s_Font1=62,r.s_Font2=63,r.s_Font3=64,r.s_FontTexStart=71,r.s_FontTexEnd=80,r.s_FontTex0=71,r.s_FontTex1=72,r.s_FontTex2=73,r.s_FontTex3=74,r.s_CustomDataStart=81,
r.s_CustomDataEnd=100},13195:(e,t,i)=>{"use strict"
i.d(t,{W:()=>n})
class n{constructor(e=!1,t=0,i=0){this.m_fFrameTimeOutTime=4,this.m_bAutoUpdate=!1,this.m_eType=0,this.m_eUpdateType=0,this.m_bAutoUpdate=e,this.m_eType=i,this.m_eUpdateType=t,
cus.updateInvoker.add(this.SingletonUpdate,this,null,!0)}FrameTimeOutTime_get(){return this.m_fFrameTimeOutTime}IsAutoUpdate(){return this.m_bAutoUpdate}InitSingleton(){}
UnInitSingleton(){}QuestIOData(e,t){}UpdateForCreate(e,t){}SingletonUpdate(e,t){}UpdateForDestroy(e,t){}WaitForSync(e,t){return!1}PrepareRender(){}OnRestTime(e){}
SingletonType_get(){return this.m_eType}SingletonUpdateType_get(){return this.m_eUpdateType}OnFrameTimeOut(){}OnCanStartRender(){}OnEngineQualityLevelChange(e){}
OnEngineInitedAndProLoadResLoaded(){}OnReSize(e,t){}OnDeviceReCreate(e){}}},58178:(e,t,i)=>{"use strict"
i.d(t,{R:()=>s})
var n=i(66788)
class s{LogPassLevel_get(){return s.m_nLogPassLevel}LogPassLevel_set(e){s.m_nLogPassLevel=e}ClampInt(e,t,i){return e<t?t:e>i?i:e}Log(e,t){n.Y.Log(e)}Warning(e){n.Y.LogWarning(e)}
Error(e,t){n.Y.LogError(e)}static LogError(e,t){n.Y.LogError(e)}}s.m_nLogPassLevel=0},95721:(e,t,i)=>{"use strict"
i.d(t,{o:()=>r})
var n=i(66788)
const s={}
let a=0
class r{constructor(e=0,t=0){this.low=0,this.high=0,this._str10="",this.low=e,this.high=t}static GetNum(e=0,t=0){
return t>=2147483648?t=-(4294967296*(t=4294967295-t)+(4294967296-e)):4294967296*t+e}high_get(){return this.high}high_set(e){n.Y.LogError("不允许设置LusuoLong")}low_get(){return this.low
}low_set(e){n.Y.LogError("不允许设置LusuoLong")}static FromNumber(e){if(e<0){let t=Math.floor(-e/4294967296),i=-e-4294967296*t
return i=4294967296-i,t=4294967295-t,r.New(i,t)}const t=Math.floor(e/4294967296),i=e-4294967296*t
return r.New(i,t)}static FromString(e){if(!e)return r.ZERO
const t=(e=e.split(".")[0]).match(/\d/g)
let i,n=0
const s=t.length
for(i=0;i<s;i++)t[i]=parseInt(t[i],10)
let a=""
for(;0==t[0]&&t.shift(),0!=t.length;){for(i=0;i<t.length;i++)n&&(t[i]+=10*n,n=0),n=t[i]%16,t[i]>>=4
a="0123456789ABCDEF".substr(n,1)+a,n=0}let l,o
return a||(a="0"),a.length>8?(l=parseInt(`0x${a.substr(0,a.length-8)}`),o=parseInt(`0x${a.substr(a.length-8,8)}`)):(l=0,o=parseInt(`0x${a}`)),r.New(o,l)}Lesser(e){
return this.high<e.high||this.high==e.high&&this.low<e.low}LesserEq(e){return this.high<e.high||this.high==e.high&&this.low<=e.low}Greater(e){
return this.high>e.high||this.high==e.high&&this.low>e.low}GreaterEq(e){return this.high>e.high||this.high==e.high&&this.low>=e.low}ToNum(){let e=this.high
return e>=2147483648?(e=4294967295-e,e=-(4294967296*e+(4294967296-this.low)),e):4294967296*e+this.low}ToLongStr(e=10){const t=this._strByRadix(e)
if(t)return t
if(e<2||e>36)throw new Error("指定要用于数字到字符串的转换的基数不在从 2 到 36 的范围内")
if(0==this.high)return this._strByRadix(e,this.low.toString(e))
let i=`00000000000000000000000000000000${this.low.toString(2)}`
i=this.high.toString(2)+i.substr(i.length-32)
const n=[],s=[1]
for(let t=i.length-1;t>=0;t--)"1"==i.substr(t,1)&&this.addBit(n,s,e),this.addBit(s,s,e)
let a=""
for(let e=n.length-1;e>=0;e--)a+="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ".substr(n[e],1)
return this._strByRadix(e,a)}_strByRadix(e,t){if(10===e)return t&&(this._str10=t),this._str10
throw new Error(`do support radix ${e}`)}ToKey(){return this.ToLongStr()}ToString(){return this.ToLongStr()}toString(){return this.ToLongStr()}Div(e){
const t=this.high%e,i=(this.low%e+6*t)%e
this.high/=e
const n=(4294967296*t+this.low)/e
return this.high+=n/4294967296,this.low=n,i}Mul(e){const t=this.low*e
this.high*=e,this.high+=t/4294967296,this.low*=e}BitwiseNot(){this.low=~this.low,this.high=~this.high}Equal(e){return null!=e&&(e.high==this.high&&e.low==this.low)}Add(e){
let t=this.low+e.low,i=this.high+e.high
return t>=4294967296&&(t-=4294967296,i+=1),r.New(t,i)}And(e){const t=this.high&e.high,i=this.low&e.low
return r.New(i,t)}Or(e){let t=this.high|e.high
t=l(t)
let i=this.low|e.low
return i=l(i),r.New(i,t)}Xor(e){let t=this.high^e.high
t=l(t)
let i=this.low^e.low
return i=l(i),r.New(i,t)}ByteValue(){return 255&this.low}ToStringByRadix(e){return this.ToLongStr(e)}addBit(e,t,i){let n,s=!1
const a=Math.max(e.length,t.length)
for(n=0;n<a;n++)n>=e.length&&(e[n]=0),n>=t.length&&(t[n]=0),e[n]+=t[n],s&&e[n]++,s=!1,e[n]>=i&&(e[n]-=i,s=!0)
return s&&e.push(1),e}IntToBinStr(e){let t=""
return t+=this.NumToAscii(this.RightShift(e,24)),t+=this.NumToAscii(this.RightShift(e,16)),t+=this.NumToAscii(this.RightShift(e,8)),t+=this.NumToAscii(e),t}NumToAscii(e){
return e%=256,String.fromCharCode(e)}shiftLeft(e){if(0==e)return this
if(e>63)return r.create(0,0)
if(32==e)return r.create(0,this.low)
let t=this.high,i=this.low
let n,s
Math.floor(e/32)>0&&(t=i,i=0),e%=32
let a=0
for(s=1;s<=e;s++)a|=1<<32-s,a=l(a)
return n=t&a,t<<=e,n=i&a,t|=n>>>32-e,t=l(t),i<<=e,r.create(i,t)}shiftRight(e){if(0==e)return this
if(e>63)return this
let t=this.high,i=this.low
let n,s
Math.floor(e/32)>0&&(i=t,t=t>=0?0:-1),e%=32
let a=0
for(s=0;s<e;s++)a|=1<<s,a=l(a)
return n=i&a,i>>>=e,n=t&a,i|=n<<32-e,i=l(i),t>>=e,r.create(i,t)}shiftRightNo(e){if(0==e)return this
if(e>63)return this
let t=this.high,i=this.low
let n,s
Math.floor(e/32)>0&&(i=t,t=0),e%=32
let a=0
for(s=0;s<e;s++)a|=1<<s,a=l(a)
return n=i&a,i>>>=e,n=t&a,i|=n<<32-e,i=l(i),t>>>=e,r.create(i,t)}RightShift(e,t){return Math.floor(e/(2^t))}Clone(){return r.New(this.low,this.high)}static New(e=0,t=0){
let i=null,l=s[t]
return null==l&&(l={},s[t]=l),a+=1,a>1e4&&(a=0),i=l[e],null!=i?(i.high==t&&i.low==e||n.Y.LogError(`LusuoLong Cache error ${t} ${e} ${i.high} ${i.low}`),i):(i=r.create(e,t),l[e]=i,
i)}static IsNullOrZero(e){return null==e||0==e.low&&0==e.high}static create(e=0,t=0){
return e==r.ZERO.low&&t==r.ZERO.high?r.ZERO:e==r.ONE.low&&t==r.ONE.high?r.ONE:e==r.SIGN.low&&t==r.SIGN.high?r.SIGN:e==r.MARK.low&&t==r.MARK.high?r.MARK:new r(e,t)}
static Recyle(e){}}function l(e){return e<0&&(e=4294967296+e),e}r.ZERO=new r,r.ONE=new r(1,0),r.SIGN=new r(4294967295,4294967295),r.MARK=new r(4294967168,4294967295)},
61991:(e,t,i)=>{"use strict"
i.d(t,{U:()=>n})
class n{static NumberEqual(e,t){return n._s=e-t,n._s>-1e-5&&n._s<1e-5}static IsZero(e){return n._s=e-0,n._s>-1e-5&&n._s<1e-5}}n.epsilon=1e-16,n.RADIANS_TO_DEGREES=180/Math.PI,
n.DEGREES_TO_RADIANS=Math.PI/180,n.TwoPI=2*Math.PI,n.ColorConverToNumber=1/255,n._s=0},35128:(e,t,i)=>{"use strict"
i.d(t,{p:()=>d})
var n=i(18998),s=i(80121),a=i(63054),r=i(52212),l=i(79534),o=i(98130)
class _{static Add(e,t){return l.P.Add(e,t)}static Subtract(e,t){return l.P.Sub(e,t)}static Mul(e,t){return l.P.Mul(e,t)}static Scale(e,t){return l.P.Scale(e,t)}static Dev(e,t){
return l.P.Div(e,t)}static NearEquals(e,t,i){const n=l.P.Sub(e,t)
return i=i>0&&i||-i,n.x<i&&n.x>-i&&n.y<i&&n.y>-i&&n.z<i&&n.z>-i}static Negate(e){e.x=-e.x,e.y=-e.y,e.z=-e.z}static AngleBetween(e,t){return e=l.P.Normalize(e),t=l.P.Normalize(t),
Math.acos(l.P.Dot(e,t))}static CopyFrom(e,t){e.x=t.x,e.y=t.y,e.z=t.z}static CrossProduct(e,t){return l.P.Cross(e,t)}static DecrementBy(e,t){e.x-=t.x,e.y-=t.y,e.z-=t.z}
static IncrementBy(e,t){e.x+=t.x,e.y+=t.y,e.z+=t.z}static ScaleBy(e,t){e.x*=t,e.y*=t,e.z*=t}static BuildFromVector2(e){return new l.P(e.x,e.y,0)}}var u=i(61991)
let h=new l.P
const c=new l.P(0,0,1)
class d{static Modf(e,t,i){const n=i-t,s=e-t,a=e-o.GF.INT(s/n)*n
return a<t?a+n:a}static SmoothStep(e,t,i){if(i<=e)return 0
if(i>=t)return 1
const n=(i-e)/(t-e)
return n*n*(3-2*n)}static GetRayCastPoint(e,t,i){return!!e.Raycast(t,0)&&(t.GetPoint(0).Clone(),!0)}static ToUint(e){return e<0?-e:e}
static CalYRotateDirectionByVector3DXZ_XYZ(e,t,i,n,s,a){h.Set(e-n,0,i-a),h.Normalize()
const r=h.x,o=l.P.Dot(c,h),_=Math.acos(o)
return r>=0&&_||-_}static CalYRotateDirectionByVector3DXZ(e,t){return d.CalYRotateDirectionByVector3DXZ_XYZ(e.x,e.y,e.z,t.x,t.y,t.z)}static CalZRotateDirectionByVector3DXY(e,t){
h.Set(e.x-t.x,e.y-t.y,0),h.Normalize()
const i=h.x,n=l.P.Dot(l.P.up_get(),h),s=Math.acos(n)
return i>=0&&-s||s}static LerpInt(e,t,i){return i<=0?e:i>=1?t:e+i*(t-e)}static LerpUInt(e,t,i){return i<=0?e:i>=1?t:e+i*(t-e)}static LerpNumber(e,t,i){
return i<=0?e:i>=1?t:e+i*(t-e)}static LerpUnclampedNumber(e,t,i){return e+i*(t-e)}static LerpPoint(e,t,i){if(i<=0)return e
if(i>=1)return t
const n=new r.F
return n.x=e.x+i*(t.x-e.x),n.y=e.y+i*(t.y-e.y),n}static LerpVector3D(e,t,i){if(i<=0)return e
if(i>=1)return t
const n=new l.P
return n.x=e.x+i*(t.x-e.x),n.y=e.y+i*(t.y-e.y),n.z=e.z+i*(t.z-e.z),n}static SlerpVector3D(e,t,i){if(i<=0)return e
if(i>=1)return t
const n=e.Magnitude(),s=t.Magnitude(),a=1/n,r=1/s,o=n*(1-i)+s*i,_=e.x*t.x+e.y*t.y+e.z*t.z,u=Math.acos(_*a*r),h=o/Math.sin(u),c=Math.sin((1-i)*u)*a*h,d=Math.sin(i*u)*r*h,m=new l.P
return m.x=e.x*c+t.x*d,m.y=e.y*c+t.y*d,m.z=e.z*c+t.z*d,m}static RotatePointWithAxis(e,t,i){a._.Euler(t.x,t.y,t.z)}static LerpUnclampedVector3D(e,t,i){const n=new l.P
return n.x=e.x+i*(t.x-e.x),n.y=e.y+i*(t.y-e.y),n.z=e.z+i*(t.z-e.z),n}static LerpVector3DOut(e,t,i,n){i<=0?i=0:i>=1&&(i=1),n.x=e.x+i*(t.x-e.x),n.y=e.y+i*(t.y-e.y),
n.z=e.z+i*(t.z-e.z)}static ZeroVector3D(e){e.x=0,e.y=0,e.z=0}static Abs(e){return e<-1e-6&&-e||e}static Max(e,t){return e>t&&e||t}static Min(e,t){return e<t&&e||t}
static GetSmoothHeight(e,t,i,n,s){if(e<0||e>=i-1||t<0||t>=n-1)return 0
const a=o.GF.INT(e),r=a+1,l=(e-a)/(r-a),_=o.GF.INT(t),u=_+1,h=(t-_)/(u-_)
let c=0,d=0,m=0,p=0,g=0
return c=s[_*i+a],d=s[u*i+a],m=s[_*i+r],p=s[u*i+r],l+h<1?(g=c,g+=h*(d-c),g+=l*(m-c)):(g=p,g+=(1-h)*(m-p),g+=(1-l)*(d-p)),g}static GetMinRotateAngleInt(e,t){let i=t
return t-e>180&&(i=t-360),i}static GetMinRotateAngleNumber(e,t){let i=t
const n=t-e
return n>180&&(i=t-360),n<-180&&(i=t+360),i}static MoveFromLine(e,t,i){return(t.y-e.z)/(t.x-e.x)*(i-e.x)+e.z}static FastDistanceXYZ(e,t,i,n,s,a){const r=e-n,l=t-s,o=i-a
return r*r+l*l+o*o}static FastDistanceXY(e,t,i,n){const s=e-i,a=t-n
return s*s+a*a}static FastDistanceVector3D(e,t){const i=e.x-t.x,n=e.y-t.y,s=e.z-t.z
return i*i+n*n+s*s}static FastDistanceVector3DXZ(e,t){const i=e.x-t.x,n=e.z-t.z
return i*i+n*n}static FastDistance(e,t,i,n){const s=e-i,a=t-n
return s*s+a*a}static GetTriPoint(e,t,i,n){const s=new l.P
let a=(t.x-e.x)*(t.x-e.x)
return a+=(t.y-e.y)*(t.y-e.y),a=Math.sqrt(a),s.x=e.x+(t.x-e.x)*(n/a),s.y=e.y+(t.y-e.y)*(n/a),s.z=e.z+n*Math.sin(i),s}static GetTriPointByAbBc90(e,t,i){
const n=l.P.Distance(e,t)*Math.tan(i*u.U.DEGREES_TO_RADIANS),s=Math.atan((e.z-t.z)/(e.x-t.x)),a=new l.P
return a.x=t.x-n*Math.sin(s),a.z=t.z+n*Math.cos(s),a.y=0,a}static IsDimensionValid(e){return e>=1&&e<=d.MAX_SIZE&&d.IsPowerOfTwo(e)}static IsPowerOfTwo(e){return e>0&&(e&-e)==e}
static GetCurCamera25DRect(e,t,i,s,a,r,o){const _=l.P.Distance(e,t)*Math.tan(.5*i*u.U.DEGREES_TO_RADIANS),h=n.view.getVisibleSize(),c=_/(h.width/h.height)
r.x=t.x-_,r.z=t.z+c,a.x=t.x+_,a.z=t.x+_,r.x=t.x-_,r.z=t.x-_,o.x=t.x+_,o.z=t.x-_}static Rotate(e,t){const i=e.x,n=Math.cos(t),s=Math.sin(t)
e.x=i*n-e.y*s,e.y=i*s+e.y*n}static ComputeBallPosRad(e,t,i){return e.x+=.5*t*Math.cos(i),e.y+=.5*t*Math.sin(i),e}static ComputeBallPosAngle(e,t,i){const n=u.U.DEGREES_TO_RADIANS*i
return e.x+=.5*t*Math.cos(n),e.y+=.5*t*Math.sin(n),e}static ComputeBallPos(e,t,i,n,s){const a=Math.sqrt(d.FastDistance(e,t,i,n)),l=new r.F(.5*(e+i),.5*(t+n))
return l.x+=.5*a*Math.cos(s),l.y+=.5*a*Math.sin(s),l}static iWrap(e,t){return e<0?(e%t+t)%t:e%t}static GetParallelogramBoundPointByCenterRay(e,t,i,n,s){
h=d.CalVectorDirectionXZ(t.x,t.z,e.x,e.z,h).Clone()
let a=_.AngleBetween(n,h)
return a=.5*l.P.Distance(e,t)/Math.cos(a),n.scaleBy(a),l.P.Add(n,i),!0}static SegmentsIntr(e,t,i,n,s){const a=(t.z-e.z)*(n.x-i.x)-(e.x-t.x)*(i.z-n.z)
if(0==a)return!1
const r=((t.x-e.x)*(n.x-i.x)*(i.z-e.z)+(t.z-e.z)*(n.x-i.x)*e.x-(n.z-i.z)*(t.x-e.x)*i.x)/a,l=-((t.z-e.z)*(n.z-i.z)*(i.x-e.x)+(t.x-e.x)*(n.z-i.z)*e.z-(n.x-i.x)*(t.z-e.z)*i.z)/a
return(r-e.x)*(r-t.x)<=0&&(l-e.z)*(l-t.z)<=0&&(r-i.x)*(r-n.x)<=0&&(l-i.z)*(l-n.z)<=0&&(s.x=r,s.z=l,!0)}static PointInTriangle(e,t,i,n){
const s=i.subtract(e),a=t.subtract(e),r=n.subtract(e),o=l.P.Dot,_=o(s,s),u=o(s,a),h=o(s,r),c=o(a,a),d=o(a,r),m=1/(_*c-u*u),p=(c*h-u*d)*m
if(p<0||p>1)return!1
const g=(_*d-u*h)*m
return!(g<0||g>1)&&p+g<=1}static ClampUInt(e,t,i){return e>i?i:e<t?t:e}static ClampInt(e,t,i){return e>i?i:e<t?t:e}static GetNear2PowNumber(e){let t=1
for(;t<16;){const i=1<<t-1
if(i<=e&&e<=1<<t)return i
t+=1}return-1}static GetMore2PowNumber(e){let t=1
for(;t<16;){const i=s.d.lshift(1,t-1),n=s.d.lshift(1,t)
if(i<=e&&e<=n)return n
t+=1}return-1}static GetFloorLog2Num(e){let t=1,i=2
for(;i<e;)i*=2,t+=1
return t}static ClampNumber(e,t,i){return e>i?i:e<t?t:e}static Clamp01(e){return e>1?1:e<0?0:e}static IntersectTriangle(e,t,i,n,s,a){
const r=n.subtract(i),o=s.subtract(i),_=l.P.Cross(e,o)
let u=l.P.Dot(r,_),h=null
if(u>0?h=t.subtract(i).Clone():(h=i.subtract(t).Clone(),u=-u),u<1e-4)return a.Set(0,0,0),!1
const c=l.P.Dot(h,_)
let d=0,m=0
if(c<0||c>u)return a.Set(0,0,0),!1
const p=l.P.Cross(h,r)
if(m=l.P.Dot(e,p),m<0||c+m>u)return a.Set(0,0,0),!1
d=l.P.Dot(o,p)
return d*=1/u,(a=e.Clone()).scaleBy(d),!0}static CalDirection(e,t,i){i.Set(e.x-t.x,e.y-t.y,e.z-t.z),i.Normalize(),u.U.IsZero(i.SqrMagnitude())&&i.Set(0,0,0)}
static CalYRotateDirectionXZ(e,t,i,n){const s=i-e,a=n-t
let r=Math.atan2(a,s)
return r*=u.U.RADIANS_TO_DEGREES,r<0&&(r+=360),r}static CalYRotateDirectionXY(e,t,i,n){h.Set(e-i,t-n,0),h.Normalize()
const s=e*t-n*i,a=Math.acos(l.P.Dot(l.P.right,h))
return s<0&&a||-a}static CalVector3DXYZByYRotate(e){const t=e*u.U.DEGREES_TO_RADIANS,i=new l.P
return i.x=Math.cos(t),i.y=0,i.z=-Math.sin(t),i}static CalVector3DXYZByYRotateXZ(e){const t=e*u.U.DEGREES_TO_RADIANS
return[Math.cos(t),-Math.sin(t)]}static CalVectorDirectionXZ(e,t,i,n,s){return s.x=e-i,s.z=t-n,s.Normalize(),s.SqrMagnitude(),s}static CalVectorDirectionXY(e,t,i,n,s){
return s.x=e-i,s.z=t-n,s.Normalize(),s.SqrMagnitude(),s}static RandomMinMax(e,t){return Math.random()*(t-e)+e}static RandomMax(e){return d.RandomMinMax(0,e)}
static RandomSpherePointXZ(e,t,i){const n=new r.F
return n.x=d.RandomMinMax(-e,e)+t,n.y=d.RandomMinMax(-e,e)+i,n}static RandomSpherePoint(e,t){const i=new r.F
return i.x=d.RandomMinMax(-e,e)+t.x,i.y=d.RandomMinMax(-e,e)+t.y,i}static RandomInsideUnitCircle(){
return new l.P(.001*d.RandomMinMax(-1e3,1e3),.001*d.RandomMinMax(-1e3,1e3),.001*d.RandomMinMax(-1e3,1e3))}static CalOvalY(e,t,i){const n=Math.acos(e/t)
return i*Math.sin(n)}static GetAngle(e,t){const i=Math.atan2,n=i(e.y,e.x),s=i(t.y,t.x)
return d.Abs(n-s)}static CalNormal(e,t,i){const n=e.subtract(t),s=i.subtract(t),a=l.P.Cross(n,s)
return a.Normalize(),a}static FloorToInt(e){return o.GF.INT(e)}static RoundToInt(e){return 0==e?0:o.GF.INT(e>0&&e+.5||e-.5)}static CeilToInt(e){
return o.GF.INT(u.U.NumberEqual(e%1,0)&&e||e+1)}static Sign(e){return e>=0?1:-1}static LerpVector2(e,t,i){return r.F.Lerp(e,t,i)}}d.MAX_SIZE=4096},5468:(e,t,i)=>{"use strict"
i.d(t,{E:()=>n})
class n{}n.s_THIS_CHAR="this",n.s_0="0",n.s_1="1",n.s_2="2",n.s_3="3",n.s_4="4",n.s_5="5",n.s_6="6",n.s_7="7",n.s_8="8",n.s_9="9",n.s_DOT1="0.0",n.s_DOT2="0.00",n.s_DOT3="0.000",
n.s_DOT4="0.0000",n.s_DOT5="0.00000",n.s_DOT6="0.000000",n.s_DOT7="0.0000000",n.s_DOT8="0.00000000",n.s_DOT9="0.000000000",n.s_Empty="",n.s_FRAGMENT_SIGN="f&",n.s_VERTEX_SIGN="v&",
n.s_TEX_SIGN="t&",n.s_GAME_FOLDER="game/",n.s_DATA_FOLDER="data/"},69071:(e,t,i)=>{"use strict"
i.d(t,{z:()=>v})
var n=i(38836),s=i(66788),a=i(18998)
class r{constructor(){this.m_name=null,this.m_hideFlags=null,this.m_bClone=!1}LeakTracker(e){}name_get(){return this.m_name&&this.m_name||"none"}name_set(e){this.m_name=e}
hideFlags_get(){return this.m_hideFlags}hideFlags_set(e){this.m_hideFlags=e}bClone_get(){return this.m_bClone}Destroy(){}CloneTo(e,t){null!=e&&(e.m_name=this.m_name,e.m_bClone=!0)}
NewEmpty(){return(0,a.log)("Not Implement --\x3eLeakTracker.NewEmpty()"),null}Clone(e){e=e&&e||!1
const t=this.NewEmpty()
return this.CloneTo(t,e),t}PrintDebugInfo(){return"Not Implement --\x3e LeakTracker.PrintDebugInfo()"}}
var l=6,o=i(89123),_=0,u=1,h=2,c=3,d=4,m=5,p=6,g=7,I=9,E=10,C=11,S=12,T=13,f=14,A=30,y=i(53908)
Object.freeze({}),Object.freeze([])
class R{constructor(){this.cls=void 0,this.file=void 0,this.sign=void 0,this.clsName=void 0,this.bytes=null,this.isReadHead=!1,this.modelFieldNames=[],this.modelDataTypes=[],
this.modelReadFuncs=[],this.rowPositions=[],this.rowPositionOffset=0,this.keyValArray=[],this.keyValRecord=null,this.isKeyRead=!1,this.cfgVos=null,this.count=0}readAll(e,t,i){
const n=(0,y.k5)(t,!0)
n||console.error(`csvbytes '${t}' is not loaded`),this.bytes=n,n&&this.readHead()
const s=this.keyValArray
for(let t=0;t<this.count;t++){const a=e.getNewCSVItem()
n&&this.readIndex(t,a)
const r=s[t]
i.LuaDic_AddOrSetItem(r,a)}this.bytes=null}readHead(){if(this.isReadHead)return!0
this.isReadHead=!0
const e=this.bytes
if(!e)return(0,a.error)(`cfgClass '${this.clsName}' is not loaded`),!1
e.position=0
const t=Date.now()
e.isGZip&&e.gunzip(),R._unzipTime+=Date.now()-t
const i=e.readString()
this.sign&&i&&this.sign!=i&&console.error(`cfgClass '${this.clsName}' 特征码不一致，请重新导出配置`)
const n=e.readShort(),s=this.modelDataTypes,r=this.modelReadFuncs,l=this.modelFieldNames
s.length=0,r.length=0
for(let t=0;t<n;t++){l[t]=e.readString()
const i=e.readUnsignedByte()
s[t]=i,r[t]=D(i)}const o=e.readInt()
this.count=o
const _=this.rowPositions
_.length=0
for(let t=0;t<o;t++)_[t]=e.readUnsignedInt()
return this.rowPositionOffset=e.position,this.keyValArray.length=0,this.keyValRecord={},this.isKeyRead=!1,this.cfgVos={},this.readKey(),!0}readKey(){if(this.isKeyRead)return
this.isKeyRead=!0
const e=this.count
if(e>0){const t=this.keyValArray,i=this.keyValRecord,n=this.modelReadFuncs[0],s=this.bytes
s.position=this.rowPositionOffset
for(let a=0;a<e;a++){const e=n.call(s)
i[e]=a,t[a]=e}}}readIndex(e,t){const i=this.modelFieldNames
t[i[0]]=this.keyValArray[e]
const n=this.bytes
n.position=this.rowPositionOffset+this.rowPositions[e]
const s=this.modelReadFuncs,r=this.modelDataTypes
for(let e=1;e<s.length;e++){let l=s[e].call(n)
const o=r[e]
if(o>=S&&"string"==typeof l)switch(o){case S:l="[]"==l?[]:l?JSON.parse(l):null
break
case A:l=l?JSON.parse(l):null
break
default:(0,a.error)(`unsupport DataType(${o})`)}t[i[e]]=l}}get isLoad(){return null!=this.bytes}}function D(e){switch(e){case _:return o.SK.prototype.readByte
case u:return o.SK.prototype.readUnsignedByte
case h:return o.SK.prototype.readShort
case c:return o.SK.prototype.readUnsignedShort
case d:return o.SK.prototype.readInt
case m:return o.SK.prototype.readUnsignedInt
case p:return o.SK.prototype.readLusuoLong
case g:return o.SK.prototype.readBoolean
case I:case E:case C:return o.SK.prototype.readBufferArray
case T:return o.SK.prototype.readFloat
case f:return o.SK.prototype.readDouble}return o.SK.prototype.readString}R._unzipTime=0
var w=i(98130)
class L{constructor(){this.m_dt=null,this.m_bBytes=!1,this.m_dtRowCount=0}Clear(){this.m_dt=null,this.m_dtRowCount=0}GetRows(){return this.m_dtRowCount}IsBytes_get(){
return this.m_bBytes}GetFloatData(e,t){return this._GetNumber(e,t)}GetDoubleData(e,t){return this._GetNumber(e,t)}GetUIntData(e,t){return w.GF.INT(this._GetNumber(e,t))}
GetIntData(e,t){return w.GF.INT(this._GetNumber(e,t))}GetBoolData(e,t){return 1==w.GF.INT(this._GetNumber(e,t))}GetData(e,t){if(this.m_dtRowCount>e){const i=this.m_dt[e+1][t+1]
return i&&i||""}return""}GetRowData(e){if(this.m_dtRowCount>e){const t=this.m_dt[e+1]
return t&&t||""}return null}_GetNumber(e,t){if(this.m_dtRowCount>e){const i=this.m_dt[e+1][t+1]
return"boolean"==typeof i?i?1:0:i&&i||0}return 0}LoadCsv(e){return l}}class v extends r{constructor(){super(),this.m_csv=null,this.m_bLoaded=!1,this.keyName=null,
this.m_mapCSV=null,this.m_csv=new L}CombinStr_get(){return!1}SetCsv(e){this.m_csv=e}Csv_get(){return this.m_csv}LoadCsvBytes(e,t){if(!this.m_bLoaded&&this.m_mapCSV){
this.m_bLoaded=!0;(new R).readAll(this,e,this.m_mapCSV),this._Load()}}NeedTrans(){return!1}LoadCsv(e){return l}ReloadCsv(e){}ForceReload(){}ClearCsv(){}Destroy(){}GetFileNums(){
return null==this.m_csv?0:this.m_csv.GetRows()}IsSrcType(){return!0}DoLoad(e){this.keyName=e
for(const[e,t]of(0,n.V5)(this.m_mapCSV))this.ReLoadFunc&&this.ReLoadFunc(t)}_Load(){}ReCreateCSVTitle(){s.Y.LogError("ReCreateCSVTitle() is not implement")}}},55360:(e,t,i)=>{
"use strict"
i.d(t,{Y:()=>_})
var n=i(77546),s=i(86133),a=i(13195),r=i(58178),l=i(39950),o=212
class _ extends a.W{static get Inst(){return null==_._Inst&&(_._Inst=new _),_._Inst}static Inst_get(){return _.Inst}constructor(){super(!1,o,l.Y.eCsvSingleton),
this.m_NumsCreated=null,this.m_mapCSV=null,this.m_mapCSVCreate=null,this.m_mapString2ID=null,this.m_firstLoadCsvs=null,this.m_NumsCreated=0,this.m_mapCSV={},this.m_mapCSVCreate={},
this.m_mapString2ID={},this.m_firstLoadCsvs={bountyselect:1,copyguaji:1,excellentspecialattrsresource:1,runeresource:1,spawngroupresource:1,buffresource:1,copyresource:1,
skillresource:1,questresource:1,equipresource:1,equipmentenhanceresource:1,objectresource:1,equipmentfartherexcellenceresource:1,i18nresource:1,talentresource:1,itemresource:1}}
static CreateCSV(){r.R.LogError((0,s.T)("函数没有意义 --\x3e LuaCsvWrapperManager.CreateCSV()"))}InitSingleton(){}UnInitSingleton(){this.m_mapCSV=null}GetOrCreateCsv(e){
let t=this.m_mapCSV[e]
if(null==t){const i=this.GetCsvNameByCsvId(e)
null!=i&&(t=this.LoadCsvTable(i,e),this.m_mapCSV[e]=t)}return t}AddCSVCreate(e,t,i){null==this.m_mapCSVCreate[e]?(this.m_mapCSVCreate[e]=i,
this.m_mapString2ID[t]=e):r.R.LogError(`${(0,s.T)("重复的csv标志ID--")}${e} ${t}`)}RemoveCSV(e){this.m_mapCSV[e]=null}GetCsvNameByCsvId(e){const t=this.m_mapString2ID
for(const i in t)if(null!=t[i]&&null!=e&&t[i]==e)return i
return null}LoadAllCustomCsv(){n.s.Info("-------------------------------------------------------------------")
const e=this.m_mapString2ID
for(const t in e){const i=e[t]
this.LoadCsvTable(t,i)}}LoadCsvTable(e,t){const i=this.GetOrCreateCsvEx(t)
return i.LoadCsvBytes(e,t),i}GetOrCreateCsvEx(e){let t=this.m_mapCSV[e]
if(null==t){const i=this.m_mapCSVCreate[e]
null!=i&&(t=i(),this.m_mapCSV[e]=t,this.m_NumsCreated+=1)}return t}ReloadCsv(e){return!0}}_.f_OutCsvString2Type=null,_.eCoreEnd=150,_._Inst=null},55945:(e,t,i)=>{"use strict"
i.d(t,{W:()=>n})
var n={eResinfo:1,eAnimation:2,eDisplay:3,eMap:4,ePhotoStage:5,eObjectAnimationResID:6,eResourceReleaseship:7,eVirtualPoint:8,eShaderIndex:9,ePostEffect:10,eUIInfo:11,
eFloatString:12,eFeatureInfo:13,eElementInfo:14,eCutSceneInfo:15,eScene2DInfo:16,eCoreEnd:100}},39950:(e,t,i)=>{"use strict"
i.d(t,{Y:()=>n})
var n={eMouseManager:2,eKeyManager:3,eTouchManager:4,eParallel:5,eUISingleton:6,eUIObjectSingleton:7,ePackageManager:8,eVersionManager:9,eShaderManager:10,eThreadPool:12,
eVectorCacheManager:13,eOutBegine:50,eOutEnd:199,eMergeEquipManager:200,eTextureSingleton:201,eResourceSingleton:202,eObjectsSingleton:203,eSceneSingleton:204,
eElementSingleton:205,eSoundSinleton:206,eFloatStringEffectManager:207,eUIObjectFactory:208,eCutScenesSingleton:209,ePhotoSingleton:210,eEnvironmentSingleton:211,
eMaterialsSingleton:212,eRenderSingleton:213,eCsvSingleton:214,eDataBlockSingleton:215,eDownloadSingleton:216,eProgram:217,eContext3DBuffer:218,ePoolSingleton:219,
eXlsxSingleton:220,ePostEffectSingleton:221,eBitFactorySingleton:222,eLightingSingleton:223,eShadowMapManagerSingleton:224,eUIResourceSingleton:225,eLuaSingleton:226,
eTerrainElementSingleton:227,eVideoSingleton:228,eCustomFontManager:229,eCustomLateSingletones:1e3}},48712:(e,t,i)=>{"use strict"
i.d(t,{a:()=>n})
var n={eTrueWorld:0,eUIWorld:1,eUIWorld3D:2,eCutSceneWorld:3,eSmallPhotoWorld:4,eNormalPhotoWorld:5,eBigPhotoWorld:6,eTipsPhotoWorld:7,eCustomWorld0:8,eCustomWorld1:9,
eCustomWorld2:10,eCustomWorld3:11,ePosteffectWorld:12,ePreCameraWorld:13,eUICutSceneWorld:14,eOnlyCutScene:15,eDynamicSceneWorld:16,eMaxWorld:33}},3809:(e,t,i)=>{"use strict"
i.d(t,{B:()=>n})
class n{static PopFront(e){return e.length?e.shift():null}static DictionaryAdd(e,t,i){e.LuaDic_AddOrSetItem(t,i)}static DictionaryRemove(e,t){e.LuaDic_Remove(t)}
static DictionaryValueIs(e,t,i){return e.LuaDic_GetItem(t)==i}static DictionaryHasAny(e){return e.Count()>0}static PopBack(e){return e.length?e.pop:null}static PushFront(e,t){
return e.unshift(t),e.length}static ArrayClear(e,t,i){e.splice(t,i)}static SortRemoveIndex(e,t){e.splice(t,1)}static SortRemoveItem(e,t){const i=e.indexOf(t)
return i>=0&&(e.splice(i,1),!0)}}n.PopFront_Better=n.PopFront,n.PushFront_Better=n.PushFront,n.SortRemoveIndexEx=n.SortRemoveIndex,n.SortRemoveItemEx=n.SortRemoveItem},
98130:(e,t,i)=>{"use strict"
i.d(t,{GF:()=>s})
var n=i(38045)
class s{static INT32_MAX_VALUE_get(){return s.INT32_MAX_VALUE}static INT32_MIN_VALUE_get(){return s.INT32_MIN_VALUE}static NewFrame(e){s._deltaTime=e-s.m_fCurFrameBeginTime,
s.m_fCurFrameBeginTime=e}static DeltaTime_get(){return s._deltaTime}static GetClassName(e){return e.constructor.name}static GetType(e,t,i){return null}static MTimer_get(){
return Math.floor(1e3*s.m_fCurFrameBeginTime)}static FloorDoubleUint(e){return Math.floor(e/4294967296)}static Timer_get(){return s.m_fCurFrameBeginTime}static CreateInstance(e){
return new e}static INT(e){return e<0&&Math.ceil(e)||Math.floor(e)}static RoundToInt(e){return e<0&&Math.ceil(e-.5)||Math.floor(e+.5)}static LuaJsonToString(e){
return null==e?null:"string"==typeof e?e:JSON.stringify(e)}static LuaJsonToNumber(e){return null==e||""==e?0:(0,n.aI)(e)}static LuaJsonToBoolean(e){
return 1==e||"TRUE"==e||"true"==e||"True"==e||1==e||"1"==e}}s.m_fCurFrameBeginTime=0,s.INT32_MAX_VALUE=2147483647,s.INT32_MIN_VALUE=-2147483648,s._deltaTime=0},2372:(e,t,i)=>{
"use strict"
i.d(t,{p:()=>n})
class n{static MAX_VALUE_get(){return 34028235e31}static MIN_VALUE_get(){return 1401298e-51}}},98885:(e,t,i)=>{"use strict"
i.d(t,{M:()=>o})
var n=i(18998),s=i(38045),a=i(85602)
const r=["(",")",".","+","-","*","?","[","^","$"],l=[/\(/g,/\)/g,/\./g,/\+/g,/-/g,/\*/g,/\?/g,/\[/g,/\^/g,/$/g]
String.prototype.replaceAll||(String.prototype.replaceAll=function(e,t){const i=this.split(e)
return i.length<=1?this:i.join(t)})
class o{static ToLower(e){return e.toLowerCase()}static ToToUpper(e){return e.toUpperCase()}static Length(e){return e.length}static IndexOf(e,t,i=0){return e.indexOf(t,i)}
static LastIndexOf(e,t,i){return e.lastIndexOf(t,i)}static Trim(e){return e.trim()}static SubStringWithLen(e,t,i){return i?e.slice(t,t+i):e.slice(t)}static SubStringWithEnd(e,t,i){
return e.slice(t,i)}static Compare(e,t){return e==t?0:e>t?1:-1}static _MagicOffSlow(e){e=e.replace(/%%/g,"%%%%")
for(let t=0;t<l.length;t++)e=e.replace(l[t],`%%${r[t]}`)
return e}static ReplaceSlow(e,t,i){return o.Replace(e,t,i)}static Replace(e,t,i){return e.replaceAll(t,i)}static ReplaceOne(e,t,i){return e.replace(t,i)}static Remove(e,t,i){
return t>0?e.slice(0,t)+e.slice(t+i):e.slice(t+i)}static IsNullOrEmpty(e){return null==e||""==e}static StartsWith(e,t){return e.startsWith(t)}static Char2Int(e){
return e.charCodeAt(0)}static Int2Char(e){return String.fromCharCode(e)}static Reverse(e){if(e.length<=1)return e
const t=[],i=e.length
for(let n=i-1;n>=0;n--){t[i-n-1]=e.charAt(n)}return t.join("")}static String2Int(e){if("FALSE"==e)return 0
if("TRUE"==e)return 1
const t=Number(e)
return isNaN(t)?0:t<0&&Math.ceil(t)||Math.floor(t)}static Split_depred(e,t){const i=e.split(t)
return new a.Z(i)}static Split(e,t){const i=e.split(t)
return new a.Z(i)}static Split1(e,t){return e.split(t)}static String2UInt(e){return"FALSE"==e?0:"TRUE"==e?1:(0,s.aI)(e)}static String2Float(e){return(0,s.aI)(e)}
static String2Double(e){return(0,s.aI)(e)}static GetAt(e,t){return e.charAt(t)}static ToFixed(e,t=10){return e.toFixed(t)}static IntToString(e){return`${e}`}
static FloatToString(e){return`${e}`}static DoubleToString(e){return`${e}`}static Contains(e,t){return null!=e.indexOf&&e.indexOf(t)>=0}static RegexMatch(e,t){const i=e.match(t)
return i&&i[0]?i[0]:null}static StringToString(e){return e}static ToCharArray(e){if(!e)return new a.Z
const t=e.split("")
return new a.Z(t)}static StringConcat(...e){return e.join("")}static StringConcatSeq(e,...t){return t.join(e)}static StringReverse(e){let t=""
for(let i of e)t=i+t
return t}static Byte(e,t){return e.charCodeAt(t)}static TransRichTextHref(e){const t=e.match(/\[url=.*?\[\/url\]/g)
if(t&&t.length)for(let i=0;i<t.length;i++){const s=t[i]
let a=""
const r=s.match(/\[url=.*?\]/g)
r&&(a=r[0].substring(5,r[0].length-1)||"")
let l=""
const o=s.match(/\].*?\[\//g)
if(o&&(l=o[0].substring(1,o[0].length-2)||""),a&&l){const t=`<click="onClick" param="${a}">${l}</>`
e=e.replace(s,t)}else(0,n.error)(`error href ${s}`)}return e}static DeleRichTextUrl(e){const t=(e=(e=e.replace(/\[url=.*?\]/g,"")).replace(/\[\/url\]/g,"")).match(/\]\[.*?\]\[/g)
let i=""
return t&&(i=t[0].substring(2,t[0].length-2)||"",i=`]${i}[`,e=e.replace(t[0],i)),e}static GetLabelLineSizeByStr(e,t){const i=n.director.getScene().getChildByName("UICanvas")
let s=t
const a=new n.Node
a.parent=i,a.active=!0
const r=a.addComponent(n.Label)
r.fontSize=e.fontSize,r.lineHeight=e.lineHeight,r.horizontalAlign=e.horizontalAlign,r.verticalAlign=e.verticalAlign,e instanceof n.RichText&&(s=this.GetRichtTextLabel(t),
0==e.maxWidth?r.enableWrapText=!1:(r.enableWrapText=!0,r.node.transform.width=e.maxWidth,r.overflow=n.Overflow.RESIZE_HEIGHT)),r.string=s,r.updateRenderData()
let l=r.node.transform.contentSize
return a.parent=null,l}static getPrintLength(e){let t=e
const i=/\<.*?\>/
let n=t.match(i)
for(;null!=n;)t=t.replace(i,""),n=t.match(i)
let s=t.match(/\[url=.*?\[\/url\]/g)
if(s&&s.length)for(let e=0;e<s.length;e++){const i=s[e]
let n=""
const a=i.match(/\].*?\[\//g)
if(a&&(n=a[0].substring(1,a[0].length-2)||""),n){const e=`${n}`
t=t.replace(i,e)}}const a=/\[.*?\]/g,r=/\\\[.*?\\\]/
if(s=t.match(a),s&&s.length)for(let e=0;e<s.length;e++){const i=s[e]
let n=""
if(null==i.match(/\\/)&&(n=i.substring(1,i.length-1)||"",n)){const e=""
t=t.replace(i,e)}}n=t.match(a)
let l=t.match(r),o=""
for(l=t.match(r);null!=l;)o=l[0].slice(2,l[0].length-2),t=t.replace(r,`[${o}]`),l=t.match(r)
s=t.match(/[a-zA-Z0-9\+\%\.]/g)
return t.length-.44375*s.length}static GetRichtTextLabel(e){let t=e
const i=/\<.*?\>/
let n=t.match(i)
for(;null!=n;)t=t.replace(i,""),n=t.match(i)
let s=t.match(/\[url=.*?\[\/url\]/g)
if(s&&s.length)for(let e=0;e<s.length;e++){const i=s[e]
let n=""
const a=i.match(/\].*?\[\//g)
if(a&&(n=a[0].substring(1,a[0].length-2)||""),n){const e=`${n}`
t=t.replace(i,e)}}const a=/\[.*?\]/g,r=/\\\[.*?\\\]/
if(s=t.match(a),s&&s.length)for(let e=0;e<s.length;e++){const i=s[e]
let n=""
if(null==i.match(/\\/)&&(n=i.substring(1,i.length-1)||"",n)){const e=""
t=t.replace(i,e)}}n=t.match(a)
let l=t.match(r),o=""
for(l=t.match(r);null!=l;)o=l[0].slice(2,l[0].length-2),t=t.replace(r,`[${o}]`),l=t.match(r)
return t}static DealRichTextOutline(e,t=2){return`<outline color=black width = ${t}> ${e} </outline>`}}o.s_DStringChar='""',o.s_StringChar='"',o.s_StringJsonChar='\\"',
o.s_DCharChar="''",o.s_CharChar="'",o.s_CharChar_DOT="'",o.s_DCharChar_DOT='"',o.s_NR_CHAR_DOT="\r",o.s_NN_CHAR_DOT="\n",o.s_SPACE_CHAR_DOT=" ",o.s_TAB_CHAR_DOT="\t",
o.s_CCD_CHAR_DOT=";",o.s_EQUAL_CHAR_DOT="=",o.s_DOT_CHAR_DOT=".",o.s_STRING_CHAR_DOT='"',o.s_SPAN_CHAR_DOT=",",o.s_LEFT_S_K_CHAR_DOT="(",o.s_RIGHT_S_K_CHAR_DOT=")",
o.s_LEFT_M_K_CHAR_DOT="[",o.s_LEFT_M_K_CHAR_REPLACE="[",o.s_RIGHT_M_K_CHAR_DOT="]",o.s_LEFT_B_K_CHAR_DOT="{",o.s_RIGHT_B_K_CHAR_DOT="}",o.s_LEFT_H_K_CHAR_DOT="<",
o.s_RIGHT_H_K_CHAR_DOT=">",o.s_F_SLASH_DOT="/",o.s_B_SLASH_DOT="\\",o.s_Arr_CharChar_DOT="'",o.s_Arr_DCharChar_DOT='"',o.s_Arr_NR_CHAR_DOT="\r",o.s_Arr_NN_CHAR_DOT="\n",
o.s_Arr_SPACE_CHAR_DOT=" ",o.s_Arr_TAB_CHAR_DOT="\t",o.s_Arr_CCD_CHAR_DOT=";",o.s_Arr_CCD_CHAR_COLON=":",o.s_Arr_EQUAL_CHAR_DOT="=",o.s_Arr_DOT_CHAR_DOT=".",
o.s_Arr_STRING_CHAR_DOT='"',o.s_Arr_SPAN_CHAR_DOT=",",o.s_Arr_LEFT_S_K_CHAR_DOT="(",o.s_Arr_RIGHT_S_K_CHAR_DOT=")",o.s_Arr_LEFT_M_K_CHAR_DOT="[",o.s_Arr_RIGHT_M_K_CHAR_DOT="]",
o.s_Arr_LEFT_B_K_CHAR_DOT="{",o.s_Arr_RIGHT_B_K_CHAR_DOT="}",o.s_Arr_LEFT_H_K_CHAR_DOT="<",o.s_Arr_RIGHT_H_K_CHAR_DOT=">",o.s_Arr_F_SLASH_DOT="/",o.s_Arr_B_SLASH_DOT="\\",
o.s_F_SLASH="//",o.s_B_SLASH="\\",o.s_NR_CHAR="\r",o.s_NN_CHAR="\n",o.s_SPACE_CHAR=" ",o.s_TAB_CHAR="\t",o.s_CCD_CHAR=";",o.s_EQUAL_CHAR="=",o.s_DOT_CHAR=".",o.s_SPAN_CHAR=",",
o.s_LEFT_S_K_CHAR="(",o.s_RIGHT_S_K_CHAR=")",o.s_LEFT_M_K_CHAR="[",o.s_RIGHT_M_K_CHAR="]",o.s_RIGHT_M_K_CHAR_REPLACE="]",o.s_LEFT_B_K_CHAR="{",o.s_RIGHT_B_K_CHAR="}",
o.s_LEFT_H_K_CHAR="<",o.s_RIGHT_H_K_CHAR=">",o.s_FRAGMENT_SIGN="f&",o.s_VERTEX_SIGN="v&",o.s_strCloneSign="_cloned_asset_",o.s_nTempInt=0},16175:(e,t,i)=>{"use strict"
i.d(t,{d:()=>n})
var n={eBody:0,eClavicle_l:1,eClavicle_r:2,eBuff:3,eBack:4,eWeapon_l:5,eWeapon_r:6,eHead:7,eEffect:8,eEffect1:9,eEffect2:10,eEffect3:11,ePhoto1:12,ePhoto2:13,eWeapon:14,
eRide_link:15,eMax_Bone:16,ePart_body:17,ePart_helmet:18,ePart_hand:19,ePart_leg:20,ePart_shoes:21,ePart_end:22,eBoneCount:23}},26133:(e,t,i)=>{"use strict"
i.d(t,{G:()=>n})
class n extends Array{get count(){return this.length}Add(e){if(!this.Contains(e))return this.push(e),e}AddRange(e,t=0,i){let n
n=i?Math.min(e.length,t+i):e.length
for(let i=t;i<n;i++)this.push(e[i])}Clear(){this.length=0}Contains(e){return this.indexOf(e)>=0}Insert(e,t){e==this.length?this.push(t):this.splice(e,0,t)}InsertRange(e,t){
this.splice(e,0,...t)}Remove(e){const t=this.indexOf(e)
return t>=0&&(this.splice(t,1),!0)}RemoveAt(e){this.splice(e,1)}IndexOf(e,t=0,i){let n
n=i?Math.min(this.length,t+i):this.length
for(let i=t;i<n;i++)if(this[i]==e)return i
return-1}Count(){return this.length}count_get(){return this.length}Length(){return this.length}RemoveRange(e,t){this.splice(e,t)}GetRange(e,t){
const i=new n,s=Math.min(this.length,e+t)
for(let t=e;t<s;t++)i[t-e]=this[t]
return i}Pop(){if(this.length)return this.pop()}}},85602:(e,t,i)=>{"use strict"
i.d(t,{Z:()=>s})
const n=[]
class s extends Array{get count(){return this.length}static Recyle(e){e&&n.length<30&&(e.Clear(),n.push(e))}constructor(e){if(super(),null!=e)if("number"==typeof e)this.length=e
else if(Array.isArray(e))for(let t=0;t<e.length;t++)this[t]=e[t]
else if(null!=e[Symbol.iterator])for(const t of e)this.push(t)
else if("string"==typeof e){const t=e.split("_")
for(let e=0;e<t.length;e++)this[e]=Number(t[e])}else if("number"==typeof e)for(let t=0;t<e;t++)this.push(null)
else if(null!=e[0]||null!=e[1]){const t=null!=e[0]?0:-1
for(const i in e){const n=Number(i)
isNaN(n)||(this[n+t]=e[i])}}}static TEMP_get(){return s.TEMP_LIST.Clear(),s.TEMP_LIST}static GetAtDefault(e,t,i){return e?t<0||t>=e.length?i:e[t]:i}static IndexOf(e,t){
return e.indexOf(t)}LastItem(){return this.length?this[this.length-1]:null}FirstItem(){return this.length?this[0]:null}Dequeue(){return this.length&&this.shift()||null}Add(e){
this.push(e)}AddByNum(e,t){for(let i=1;i<=t;i++)this.push(e)}AddByNeedCount(e,t){if(!(t>=this.length))for(let i=1;i<=t-this.length;i++)this.push(e)}AddRange(e){this.push(...e)}
Clear(){this.length&&(this.length=0)}Contains(e){return this.indexOf(e)>=0}Insert(e,t){e>=this.length?this.push(t):this.splice(e,0,t)}InsertRange(e,t){
e>=this.length?this.push(...t):this.splice(e,0,...t)}Remove(e){const t=this.indexOf(e)
return t>=0&&(this.splice(t,1),!0)}RemoveFast(e){return null!=this.shift()}RemoveAt(e){e>=0&&e<this.length&&this.splice(e,1)}RemoveAtFast(e){
return!(e<0||e>=this.length)&&(this.splice(e,1),!0)}IndexOf(e,t=0,i){let n
n=i?Math.min(this.length,t+i):this.length
for(let i=t;i<n;i++)if(this[i]==e)return i
return-1}Equal(e){const t=this.length
if(t!=e.length)return!1
for(let i=0;i<=t-1;i++)if(this[i]!=e[i])return!1
return!0}Swap(e,t){const i=this[e],n=this[t]
this[t]=i,this[e]=n}Count(){return this.length}count_get(){return this.length}Length(){return this.length}RemoveRange(e,t){this.splice(e,t)}GetRange(e,t){
const i=new s,n=Math.min(this.length,e+t)
for(let t=e;t<n;t++)i[t-e]=this[t]
return i}Pop(){return this.length?this.pop():null}Push(e){this.push(e)}Reverse(){if(this.count>1){const e=this.count-1,t=Math.floor(this.count/2)
for(let i=0;i<t;i++){const t=this[i]
this[i]=this[e-i],this[e-i]=t}}}ToArray(){const e=new s
for(let t=0,i=this.length;t<i;t++)e[t]=this[t]
return e}ToLuaTable(){const e={}
for(let t=0,i=this.length;t<i;t++)e[t]=this[t]
return e}Sort(e){this.sort(e)}static GetTableOrNilFromLua(e){return null==e?null:e}GetTableOrNilFromCS(e){if(null==e)return null
const t=new s
return t.AddRange(e),t}GetLuaToArray(){return this}}s.TEMP_LIST=new s},72785:(e,t,i)=>{"use strict"
i.d(t,{c:()=>a})
var n=i(18998)
let s=null
class a{static __StaticInit(){s={warning:{},err:{},log:{}}}DebugWarning(e){(0,n.warn)(`# Warning--\x3e: ${e}`)}static DebugError(e){(0,n.error)(`# Error--\x3e: ${e}`)}
static DebugLog(e){(0,n.log)(`# Log--\x3e: ${e}`)}}},38962:(e,t,i)=>{"use strict"
i.d(t,{X:()=>_})
i(22267)
var n=i(38836),s=(i(66788),i(85602))
let a
const r={done:!0},l=Symbol("KeyNumber"),o=[]
a=Symbol.iterator
class _{constructor(e){this[l]=!1,e&&(this[l]=!0)}static new(){if(o.length>0){return o.pop()}return new _}static newByWeak(e,t){return new _}declareKeyNumber(){this[l]=!0}
static Recyle(e){e.LuaDic_Clear(),o.length<30&&o.push(e)}LuaDic_Add(e,t){this[u(e)]=t}LuaDic_SetItem(e,t){this[u(e)]=t}LuaDic_IsNullValue(e){return null==e}
static LuaDic_IsNullValue(e){return null==e}static checkKey(e){return!0}LuaDic_IsNotNullValue(e){return null!=e}IsNotNull(e){return null!=this[u(e)]}IsNull(e){
return null==this[u(e)]}static LuaDic_GetItem(e,t){var i
return null!==(i=e[u(t)])&&void 0!==i?i:null}LuaDic_GetItem(e){var t
return null!==(t=this[u(e)])&&void 0!==t?t:null}Get(e){var t
return null!==(t=this[u(e)])&&void 0!==t?t:null}LuaDic_Count(){let e=0
for(const t in this)null!=this[t]&&e++
return e}Count(){let e=0
for(const t in this)null!=this[t]&&e++
return e}LuaDic_ContainsKey(e){return null!=this[u(e)]}LuaDic_AddOrSetItem(e,t){this[u(e)]=t}LuaDic_Keys(){const e=this[l],t=new s.Z
for(const i in this)t[t.length]=e?Number(i):i
return t}LuaDic_Values(){const e=new s.Z
for(const t in this){const i=this[t]
null!=i&&(e[e.length]=i)}return e}ClearNull(){}LuaDic_Clear(){for(const e in this)delete this[e]}Clear(){for(const e in this)delete this[e]}LuaDic_ContainsValue(e){
for(const t in this)if(e===this[t])return!0
return!1}LuaDic_Remove(e){const t=u(e)
void 0!==this[t]&&delete this[t]}static LuaDic_Remove(e,t){const i=u(t)
void 0!==e[i]&&delete e[i]}[a](){const e=this,t=Object.keys(this),i=!!this[l]
let s=0
return{next(){for(;s<t.length;){const a=t[s++],r=e[a]
return n.C$[0]=i?Number(a):a,n.C$[1]=r,{value:n.C$}}return r}}}}function u(e){if(null==e)return""
const t=typeof e
return"string"==t?e:"number"==t?`${e}`:("object"==t||console.error("key only support 'string or number or object', please use Dictionary1 ",e),e.toString())}},58087:(e,t,i)=>{
"use strict"
i.d(t,{y:()=>o})
i(22267)
var n=i(38836),s=(i(66788),i(85602))
let a
const r={done:!0},l=[]
a=Symbol.iterator
class o{constructor(){this._map=new Map}get LuaDic_count(){return this._map.size}static new(){if(l.length>0){return l.pop()}return new o}static newByWeak(e,t){return new o}
Recyle(e){l.length<30&&(e.LuaDic_Clear(),l.push(e))}LuaDic_Add(e,t){this._map.set(e,null!=t?t:null)}LuaDic_SetItem(e,t){this._map.set(e,null!=t?t:null)}
static LuaDic_IsNullValue(e){return null==e}LuaDic_IsNotNullValue(e){return null!=e}IsNotNull(e){return null!=this._map.get(e)}IsNull(e){return null==this._map.get(e)}
LuaDic_GetItem(e){var t
return null!==(t=this._map.get(e))&&void 0!==t?t:null}Get(e){var t
return null!==(t=this._map.get(e))&&void 0!==t?t:null}LuaDic_Count(){return this._map.size}Count(){return this._map.size}LuaDic_ContainsKey(e){return this._map.has(e)}
LuaDic_AddOrSetItem(e,t){this._map.set(e,null!=t?t:null)}LuaDic_Keys(){return new s.Z(this._map.keys())}LuaDic_Values(){const e=new s.Z,t=this._map.values()
for(const i of t)null!=i&&e.push(i)
return e}LuaDic_Clear(){this._map.clear()}Clear(){this._map.clear()}LuaDic_ContainsValue(e){for(const t of this._map.values())if(t==e)return!0
return!1}LuaDic_Remove(e){this._map.delete(e)}[a](){const e=this._map,t=e.keys()
return{next(){const i=t.next()
if(i.done)return r
const s=i.value
return n.C$[0]=s,n.C$[1]=e.get(s),{value:n.C$}}}}}},51262:(e,t,i)=>{"use strict"
i.d(t,{H:()=>a})
var n=i(38045)
const s=[]
class a{constructor(){this.Length=0,this._str="",this._strTable=[]}Length_get(){return this.Length}Append(e){null==e?e="":"number"==typeof e&&(e=(0,n.tw)(e)),this.Length+=e.length,
this._strTable.push(e)}ToString(){this._str=this._strTable.join("")
const e=this._str
return this.ClearData(),e}toString(){return this.ToString()}ClearData(){this.Length=0,this._str="",this._strTable.length=0}static New(e,t){if(s.length>0){return s.pop()}
return new a}static Recycle(e){s.length<10&&(e.ClearData(),s.push(e))}}},82306:(e,t,i)=>{"use strict"
i.d(t,{q:()=>s})
var n=i(18998)
class s{static get unscaledDeltaTime(){return n.game.deltaTime}static get deltaTime(){return n.game.deltaTime}static get frameCount(){return n.director._totalFrames}}},
88653:(e,t,i)=>{"use strict"
i.d(t,{I:()=>r})
var n=i(18998),s=i(21729)
const a=[]
class r extends n.Color{static get red(){return r.New(255,0,0,255)}static get green(){return r.New(0,255,0,255)}static get blue(){return r.New(0,0,255,255)}static get white(){
return r.New(255,255,255,255)}static get black(){return r.New(0,0,0,255)}static get yellow(){return r.New(255,.9215686,.01568628,255)}static get cyan(){return r.New(0,255,255,255)}
static get magenta(){return r.New(255,0,255,255)}static get gray(){return r.New(.5,.5,.5,255)}static get clear(){return r.New(0,0,0,0)}static gamma(e){
return r.New(s.N.LinearToGammaSpace(e._r),s.N.LinearToGammaSpace(e._g),s.N.LinearToGammaSpace(e._b),e._a)}static linear(e){
return r.New(s.N.GammaToLinearSpace(e._r),s.N.GammaToLinearSpace(e._g),s.N.GammaToLinearSpace(e._b),e._a)}static red_get(){return r.New(255,0,0,255)}static green_get(){
return r.New(0,255,0,255)}static blue_get(){return r.New(0,0,255,255)}static white_get(){return r.New(255,255,255,255)}static black_get(){return r.New(0,0,0,255)}
static yellow_get(){return r.New(255,.9215686,.01568628,255)}static cyan_get(){return r.New(0,255,255,255)}static magenta_get(){return r.New(255,0,255,255)}static gray_get(){
return r.New(.5,.5,.5,255)}static clear_get(){return r.New(0,0,0,0)}static Recyle(e){a.length<20&&(e.Set(1,1,1,1),a.push(e))}static New(e=0,t=0,i=0,n=1){if(a.length>0){
const s=a.pop()
return s.Set(e,t,i,n),s}return new r(e,t,i,n)}constructor(e=0,t=0,i=0,n=1){super(Math.floor(255*e),Math.floor(255*t),Math.floor(255*i),Math.floor(255*n)),this._r=0,this._g=0,
this._b=0,this._a=0,this._r=e,this._g=t,this._b=i,this._a=n}Set(e=0,t=0,i=0,n=1){this._r=e,this._g=t,this._b=i,this._a=n||1,this._syncCC()}Get(){
return[this._r,this._g,this._b,this._a]}Equals(e){return this._r==e._r&&this._g==e._g&&this._b==e._b&&this._a==e._a}static Lerp(e,t,i){return i=s.N.Clamp01(i),
r.New(e._r+i*(t._r-e._r),e._g+i*(t._g-e._g),e._b+i*(t._b-e._b),e._a+i*(t._a-e._a))}static LerpUnclamped(e,t,i){
return r.New(e._r+i*(t._r-e._r),e._g+i*(t._g-e._g),e._b+i*(t._b-e._b),e._a+i*(t._a-e._a))}static HSVToRGB(e,t,i,n){if(n=!0,0==t)return r.New(i,i,i,1)
if(0==i)return r.New(0,0,0,1)
const a=r.New(1,1,1,1)
a._r=0,a._g=0,a._b=0
const l=t,o=i,_=6*e,u=s.N.Floor(_),h=_-u,c=o*(1-l),d=o*(1-l*h),m=o*(1-l*(1-h)),p=u+1
return 0==p?(a._r=o,a._g=c,a._b=d):1==p?(a._r=o,a._g=m,a._b=c):2==p?(a._r=d,a._g=o,a._b=c):3==p?(a._r=c,a._g=o,a._b=m):4==p?(a._r=c,a._g=d,a._b=o):5==p?(a._r=m,a._g=c,
a._b=o):6==p?(a._r=o,a._g=c,a._b=d):7==p&&(a._r=o,a._g=m,a._b=c),n||(a._r=s.N.Clamp(a._r,0,1),a._g=s.N.Clamp(a._g,0,1),a._b=s.N.Clamp(a._b,0,1)),a._syncCC()}static RGBToHSV(e){
return e._b>e._g&&e._b>e._r?l(4,e._b,e._r,e._g):e._g>e._r?l(2,e._g,e._b,e._r):l(0,e._r,e._g,e._b)}static GrayScale(e){return.299*e._r+.587*e._g+.114*e._b}Clone(){
return r.New(this._r,this._g,this._b,this._a)}static Add(e,t){return r.New(e._r+t._r,e._g+t._g,e._b+t._b,e._a+t._a)}static Sub(e,t){
return r.New(e._r-t._r,e._g-t._g,e._b-t._b,e._a-t._a)}static Mul(e,t){return"number"==typeof t?r.New(e._r*t,e._g*t,e._b*t,e._a*t):r.New(e._r*t._r,e._g*t._g,e._b*t._b,e._a*t._a)}
static Div(e,t){return r.New(e._r/t,e._g/t,e._b/t,e._a/t)}static _syncCC(e){return e.r=255*e._r,e.g=255*e._g,e.b=255*e._b,e.a=255*e._a,e}_syncCC(){
return this.r=Math.floor(255*this._r),this.g=Math.floor(255*this._g),this.b=Math.floor(255*this._b),this.a=Math.floor(255*this._a),this}ToTsColor(){return this}}
function l(e,t,i,n){if(0!=t){let t=0
t=i>n?n:i
const s=t-t
let a=0,r=0
return 0!=s?(r=s/t,a=e+(i-n)/s):(r=0,a=e+(i-n)),a/=6,a<0&&(a+=1),[a,r,t]}return[0,0,t]}},21729:(e,t,i)=>{"use strict"
i.d(t,{N:()=>o})
var n=i(82306)
function s(e){return e/180*Math.PI}function a(e){return e/Math.PI*180}Math.rad=s,Math.deg=a
const r=Math.floor,l=Math.abs
class o{static Approximately(e,t){return l(t-e)<Math.max(1e-6*Math.max(l(e),l(t)),1121039e-50)}static Clamp(e,t,i){return e<t?e=t:e>i&&(e=i),e}static Clamp01(e){
return e<0?0:e>1?1:e}static DeltaAngle(e,t){let i=o.Repeat(t-e,360)
return i>180&&(i-=360),i}static Gamma(e,t,i){let n=!1
e<0&&(n=!0)
const s=l(e)
if(s>t)return!n&&s||-s
const a=(s/t)**i*t
return!n&&a||-a}static InverseLerp(e,t,i){return e<t?i<e?0:i>t?1:(i-=e,i/=t-e):e<=t?0:i<t?1:i>e?0:1-(i-t)/(e-t)}static Lerp(e,t,i){return e+(t-e)*o.Clamp01(i)}
static LerpAngle(e,t,i){let n=o.Repeat(t-e,360)
return n>180&&(n-=360),e+n*o.Clamp01(i)}static LerpUnclamped(e,t,i){return e+(t-e)*i}static MoveTowards(e,t,i){return l(t-e)<=i?t:e+o.Sign(t-e)*i}static MoveTowardsAngle(e,t,i){
return t=e+o.DeltaAngle(e,t),o.MoveTowards(e,t,i)}static PingPong(e,t){return e=o.Repeat(e,2*t),t-l(e-t)}static Repeat(e,t){return e-r(e/t)*t}static Round(e){return r(e+.5)}
static Sign(e){return e=e>0?1:e<0?-1:0}static SmoothDamp(e,t,i,s,a,r){a=a||o.Infinity,r=r||n.q.deltaTime
const l=2/(s=o.Max(1e-4,s)),_=l*r,u=1/(1+_+.48*_*_+.235*_*_*_)
let h=e-t
const c=t,d=a*s
h=o.Clamp(h,-d,d)
const m=(i+l*h)*r
i=(i-l*m)*u
let p=(t=e-h)+(h+m)*u
return c>e==p>c&&(p=c,i=(p-c)/r),[p,i]}static SmoothDampAngle(e,t,i,s,a,r){return r=r||n.q.deltaTime,a=a||o.Infinity,t=e+o.DeltaAngle(e,t),o.SmoothDamp(e,t,i,s,a,r)}
static SmoothStep(e,t,i){return t*(i=-2*(i=o.Clamp01(i))*i*i+3*i*i)+e*(1-i)}static HorizontalAngle(e){return a(Math.atan2(e.x,e.z))}static IsNan(e){return isNaN(e)}
static LinearToGammaSpace(e){return Math.sqrt(e)}static GammaToLinearSpace(e){return e*e}}o.huge=Number.MAX_SAFE_INTEGER,o.Deg2Rad=s(1),o.Epsilon=14013e-49,o.Infinity=o.huge,
o.NegativeInfinity=-o.huge,o.PI=Math.PI,o.Rad2Deg=a(1),o.Abs=Math.abs,o.Acos=Math.acos,o.Asin=Math.asin,o.Atan=Math.atan,o.Atan2=Math.atan2,o.Ceil=Math.ceil,o.Cos=Math.cos,
o.Exp=Math.exp,o.Floor=Math.floor,o.Log=Math.log,o.Log10=Math.log10,o.Max=Math.max,o.Min=Math.min,o.Pow=Math.pow,o.Sin=Math.sin,o.Sqrt=Math.sqrt,o.Tan=Math.tan,o.Deg=a,o.Rad=s,
o.Random=Math.random},63054:(e,t,i)=>{"use strict"
i.d(t,{_:()=>y})
var n=i(75327),s=i(38045),a=i(21729),r=i(79534)
const l=Math.sin,o=Math.cos,_=Math.acos,u=Math.asin,h=Math.sqrt,c=Math.min,d=Math.atan2,m=a.N.Clamp,p=Math.abs,g=a.N.Rad2Deg,I=.5*a.N.Deg2Rad,E=[2,3,1],C=-1e-4,S=a.N.PI,T=.5*S,f=2*S,A=f-1e-4
class y{static New(e=0,t=0,i=0,n=0){return new y(e,t,i,n)}constructor(e=0,t=0,i=0,n=0){this.x=0,this.y=0,this.z=0,this.w=0,this.x=e,this.y=t,this.z=i,this.w=n}Set(e=0,t=0,i=0,n=0){
this.x=e||0,this.y=t||0,this.z=i||0,this.w=n||0}Clone(){return new y(this.x,this.y,this.z,this.w)}Get(){return[this.x,this.y,this.z,this.w]}static Dot(e,t){
return e.x*t.x+e.y*t.y+e.z*t.z+e.w*t.w}static Angle(e,t){let i=y.Dot(e,t)
return i<0&&(i=-i),2*_(c(i,1))*57.29578}static AngleAxis(e,t){const i=t.Normalize(),n=l(e*=I),s=o(e),a=i.x*n,r=i.y*n,_=i.z*n
return new y(a,r,_,s)}static Equals(e,t){return e.x==t.x&&e.y==t.y&&e.z==t.z&&e.w==t.w}static Euler(e,t,i){t*=.0087266462599716,i*=.0087266462599716
const n=l(e*=.0087266462599716)
e=o(e)
const s=l(t)
t=o(t)
const a=l(i)
return i=o(i),new y(t*n*i+s*e*a,s*e*i-t*n*a,t*e*a-s*n*i,t*e*i+s*n*a)}SetEuler(e,t,i){let n
"number"==typeof e?(n=e,t=t||0,i=i||0):(n=e.x,null==t&&(t=e.y),null==i&&(i=e.z)),n*=.0087266462599716,t*=.0087266462599716,i*=.0087266462599716
const s=l(n),a=o(n),r=l(t),_=o(t),u=l(i),h=o(i)
return this.w=_*a*h+r*s*u,this.x=_*s*h+r*a*u,this.y=r*a*h-_*s*u,this.z=_*a*u-r*s*h,this}Normalize(){const e=this.Clone()
return e.SetNormalize(),e}SetNormalize(){let e=this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w
1!=e&&e>0&&(e=1/h(e),this.x*=e,this.y*=e,this.z*=e,this.w*=e)}static SetNormalize(e){return e.SetNormalize(),e}static FromToRotation(e,t){const i=y.New()
return i.SetFromToRotation(e,t),i}SetFromToRotation1(e,t){const i=e.Normalize(),n=t.Normalize(),s=r.P.Dot(i,n)
if(!(s>-.999999)){if(s>.999999)return new y(0,0,0,1)
{let e=r.P.Cross(r.P.right,i)
return e.SqrMagnitude()<1e-6&&(e=r.P.Cross(r.P.forward,i)),this.Set(e.x,e.y,e.z,0),this}}{const e=h(2*(1+s)),t=1/e,a=r.P.Mul(r.P.Cross(i,n),t)
this.Set(a.x,a.y,a.z,.5*e)}return this}SetFromToRotation(e,t){e=e.Normalize(),t=t.Normalize()
const i=r.P.Dot(e,t)
if(i>.999999)this.Set(0,0,0,1)
else if(i<-.999999){const t=[0,e.z,e.y]
let i=t[2]*t[2]+t[3]*t[3]
i<1e-6&&(t[1]=-e.z,t[2]=0,t[3]=e.x,i=t[1]*t[1]+t[3]*t[3])
const n=1/h(i)
t[1]*=n,t[2]*=n,t[3]*=n
const s=[0,0,0]
s[1]=t[2]*e.z-t[3]*e.y,s[2]=t[3]*e.x-t[1]*e.z,s[3]=t[1]*e.y-t[2]*e.x
const a=-e.x*e.x,r=-e.y*e.y,l=-e.z*e.z,o=-e.x*e.y,_=-e.x*e.z,u=-e.y*e.z,c=s[1]*s[1],d=s[2]*s[2],m=s[3]*s[3],p=s[1]*s[2],g=s[1]*s[3],I=s[2]*s[3],E=-t[1]*t[1],C=-t[2]*t[2],S=-t[3]*t[3],T=-t[1]*t[2],f=-t[1]*t[3],A=-t[2]*t[3]
R([[a+c+E,o+p+T,_+g+f],[o+p+T,r+d+C,u+I+A],[_+g+f,u+I+A,l+m+S]],this)}else{const n=r.P.Cross(e,t),s=(1-i)/r.P.Dot(n,n),a=s*n.x,l=s*n.z,o=a*n.y,_=a*n.z,u=l*n.y
R([[i+a*n.x,o-n.z,_+n.y],[o+n.z,i+s*n.y*n.y,u-n.x],[_-n.y,u+n.x,i+l*n.z]],this)}}Inverse(){const e=y.New()
return e.x=-this.x,e.y=-this.y,e.z=-this.z,e.w=this.w,e}static Lerp(e,t,i){i=m(i,0,1)
const n=y.New(0,0,0,1)
return y.Dot(e,t)<0?(n.x=e.x+i*(-t.x-e.x),n.y=e.y+i*(-t.y-e.y),n.z=e.z+i*(-t.z-e.z),n.w=e.w+i*(-t.w-e.w)):(n.x=e.x+(t.x-e.x)*i,n.y=e.y+(t.y-e.y)*i,n.z=e.z+(t.z-e.z)*i,
n.w=e.w+(t.w-e.w)*i),y.SetNormalize(n),n}static LookRotation(e,t){const i=e.Magnitude()
if(i<1e-6)return(0,n.vU)(`error input forward to Quaternion.LookRotation${(0,s.tw)(e)}`),null
e=r.P.Div(e,i),t=t||r.P.up
let a=r.P.Cross(t,e)
a.SetNormalize(),t=r.P.Cross(e,a),a=r.P.Cross(t,e)
let l=a.x+t.y+e.z
if(l>0){l+=1
const i=.5/h(l),n=i*l,s=(t.z-e.y)*i,r=(e.x-a.z)*i,o=(a.y-t.x)*i,_=new y(s,r,o,n)
return _.SetNormalize(),_}const o=[[a.x,t.x,e.x],[a.y,t.y,e.y],[a.z,t.z,e.z]],_=[0,0,0]
let u=1
t.y>a.x&&(u=2),e.z>o[u][u]&&(u=3)
const c=E[u],d=E[c]
l=o[u][u]-o[c][c]-o[d][d]+1
const m=.5/h(l)
_[u]=m*l
const p=(o[d][c]-o[c][d])*m
_[c]=(o[c][u]+o[u][c])*m,_[d]=(o[d][u]+o[u][d])*m
const g=new y(_[1],_[2],_[3],p)
return g.SetNormalize(),g}SetIdentity(){this.x=0,this.y=0,this.z=0,this.w=1}static Slerp(e,t,i){return i<0?i=0:i>1&&(i=1),D(e,t,i)}static RotateTowards(e,t,i){const n=y.Angle(e,t)
if(0==n)return t
return D(e,t,c(1,i/n))}ToAngleAxis(){const e=2*_(this.w)
if(p(e-0)<1e-6)return[57.29578*e,r.P.New(1,0,0)]
const t=1/h(1-h(this.w))
return[57.29578*e,r.P.New(this.x*t,this.y*t,this.z*t)]}ToEulerAngles(){const e=this.x,t=this.y,i=this.z,n=this.w,s=2*(t*i-n*e)
if(s<.999){if(s>-.999){const a=r.P.New(-u(s),d(2*(e*i+n*t),1-2*(e*e+t*t)),d(2*(e*t+n*i),1-2*(e*e+i*i)))
return w(a),a.Mul(g),a}const a=r.P.New(T,d(2*(e*t-n*i),1-2*(t*t+i*i)),0)
return w(a),a.Mul(g),a}const a=r.P.New(-T,d(-2*(e*t-n*i),1-2*(t*t+i*i)),0)
return w(a),a.Mul(g),a}Forward(){return this.MulVec3(r.P.forward)}MulVec3(e){
const t=r.P.New(),i=2*this.x,n=2*this.y,s=2*this.z,a=this.x*i,l=this.y*n,o=this.z*s,_=this.x*n,u=this.x*s,h=this.y*s,c=this.w*i,d=this.w*n,m=this.w*s
return t.x=(1-(l+o))*e.x+(_-m)*e.y+(u+d)*e.z,t.y=(_+m)*e.x+(1-(a+o))*e.y+(h-c)*e.z,t.z=(u-d)*e.x+(h+c)*e.y+(1-(a+l))*e.z,t}MulVec3XYZ(e,t,i){
const n=2*this.x,s=2*this.y,a=2*this.z,r=this.x*n,l=this.y*s,o=this.z*a,_=this.x*s,u=this.x*a,h=this.y*a,c=this.w*n,d=this.w*s,m=this.w*a
return[(1-(l+o))*e+(_-m)*t+(u+d)*i,(_+m)*e+(1-(r+o))*t+(h-c)*i,(u-d)*e+(h+c)*t+(1-(r+l))*i]}static MulVec3XYZ(e,t,i,n){return e.MulVec3XYZ(t,i,n)}toString(){
return`[${this.x},${this.y},${this.z},${this.w}]`}}function R(e,t){const i=e[1][1]+e[2][2]+e[3][3]
if(i>0){let n=h(i+1)
t.w=.5*n,n=.5/n,t.x=(e[3][2]-e[2][3])*n,t.y=(e[1][3]-e[3][1])*n,t.z=(e[2][1]-e[1][2])*n,t.SetNormalize()}else{let i=1
const n=[0,0,0]
e[2][2]>e[1][1]&&(i=2),e[3][3]>e[i][i]&&(i=3)
const s=E[i],a=E[s],r=e[i][i]-e[s][s]-e[a][a]+1,l=.5/h(r)
n[i]=l*r
const o=(e[a][s]-e[s][a])*l
n[s]=(e[s][i]+e[i][s])*l,n[a]=(e[a][i]+e[i][a])*l,t.Set(n[1],n[2],n[3],o),t.SetNormalize()}}function D(e,t,i){let n=e.x*t.x+e.y*t.y+e.z*t.z+e.w*t.w
if(n<0&&(n=-n,t=new y(-t.x,-t.y,-t.z,-t.w)),n<.95){const s=_(n),a=1/l(s),r=l((1-i)*s)*a,o=l(i*s)*a
return e=new y(e.x*r+t.x*o,e.y*r+t.y*o,e.z*r+t.z*o,e.w*r+t.w*o)}return e=new y(e.x+i*(t.x-e.x),e.y+i*(t.y-e.y),e.z+i*(t.z-e.z),e.w+i*(t.w-e.w)),y.SetNormalize(e),e}function w(e){
e.x<C?e.x+=f:e.x>A&&(e.x-=f),e.y<C?e.y+=f:e.y>A&&(e.y-=f),(e.z<C||e.z>A)&&(e.z+=f)}},34143:(e,t,i)=>{"use strict"
i.d(t,{U:()=>a})
var n=i(52212)
const s=[]
class a{static Recyle(e){return s.length<20?(e.x=0,e.y=0,e.width=0,e.height=0,s.push(e),e):null}Clone(){if(s.length>0){const e=s.pop()
return e.x=this.x,e.y=this.y,e.width=this.width,e.height=this.height,e}return new a(this.x,this.y,this.width,this.height)}static new(e=0,t=0,i=0,n=0){if(s.length>0){const a=s.pop()
return a.x=e,a.y=t,a.width=i,a.height=n,a}return new a(e,t,i,n)}constructor(e=0,t=0,i=0,n=0){this.x=0,this.y=0,this.width=0,this.height=0,this.x=e,this.y=t,this.width=i,
this.height=n}static zero(){return new a}max_get(){return new n.F(this.x+this.width,this.y+this.height)}min_get(){return new n.F(this.x,this.y)}yMax_get(){return this.y+this.height
}xMax_get(){return this.x+this.width}yMin_get(){return this.y}xMin_get(){return this.x}x_get(){return this.x}x_set(e){this.x=e}y_get(){return this.y}y_set(e){this.y=e}height_get(){
return this.height}height_set(e){this.height=e}width_get(){return this.width}width_set(e){this.width=e}center_get(){return new n.F(this.x+.5*this.width,this.y+.5*this.height)}
position_get(){return new n.F(this.x,this.y)}position_set(e){this.x=e.x,this.y=e.y}size_get(){return new n.F(this.width,this.height)}size_set(e){this.width=e.x,this.height=e.y}
Overlaps(e){const t=Math.max(this.xMax_get(),e.xMax_get())-Math.min(this.xMin_get(),e.xMin_get()),i=Math.max(this.yMax_get(),e.yMax_get())-Math.min(this.yMin_get(),e.yMin_get())
return this.width+e.width-t>0&&this.height+e.height-i>0}Contains(e){return this.x<e.x&&this.x+this.width>e.x&&this.y<e.y&&this.y+this.height>e.y}Set(e=0,t=0,i=0,n=0){this.x=e,
this.y=t,this.width=i,this.height=n}}},52212:(e,t,i)=>{"use strict"
i.d(t,{F:()=>u})
var n=i(18998),s=i(92456),a=i(82306),r=i(21729)
const l=Math.sqrt,o=Math.acos,_=(Math.max,[])
class u extends n.Vec2{constructor(...e){super(...e),this.isCanRecycle=!1}static get up(){return new u(0,1)}static Recycle(e){
return _.length<30&&e.isCanRecycle&&null!=e?(e.Set(0,0),_.push(e),e):null}static New(e=0,t=0){if(_.length>0){const i=_.pop()
return i.Set(e,t),i}const i=new u
return i.x=e,i.y=t,i.isCanRecycle=!0,i}Set(e=0,t=0){this.x=e||0,this.y=t||0}Get(){return[this.x,this.y]}SqrMagnitude(){return this.x*this.x+this.y*this.y}Clone(){
return new u(this.x,this.y)}static Normalize_depred(e){let t=e.x,i=e.y
const n=l(t*t+i*i)
return n>1e-5?(t/=n,i/=n):(t=0,i=0),new u(t,i)}static Normalize(e){const[t,i]=[e.x,e.y],n=l(t*t+i*i)
return n>1e-5?([e.x,e.y]=[t/n,i/n],e):([e.x,e.y]=[0,0],e)}SetNormalize(){const e=l(this.x*this.x+this.y*this.y)
return e>1e-5?(this.x/=e,this.y/=e):(this.x=0,this.y=0),this}static Dot(e,t){return e.x*t.x+e.y*t.y}static Angle(e,t){let[i,n]=[e.x,e.y],s=l(i*i+n*n)
s>1e-5?(i/=s,n/=s):[i,n]=[0,0]
let[a,r]=[t.x,t.y]
return s=l(a*a+r*r),s>1e-5?(a/=s,r/=s):[a,r]=[0,0],s=i*a+n*r,s<-1?s=-1:s>1&&(s=1),57.29578*o(s)}static Magnitude(e){return l(e.x*e.x+e.y*e.y)}static Reflect(e,t){
const i=e.x,n=e.y,s=t.x,a=t.y,r=-2*(i*s+n*a)
return new u(r*s+i,r*a+n)}static Distance(e,t){return l((e.x-t.x^2)+(e.y-t.y^2))}static Lerp(e,t,i){return i<0?i=0:i>1&&(i=1),new u(e.x+(t.x-e.x)*i,e.y+(t.y-e.y)*i)}
static LerpUnclamped(e,t,i){return new u(e.x+(t.x-e.x)*i,e.y+(t.y-e.y)*i)}static MoveTowards(e,t,i){const n=e.x,s=e.y,a=t.x-n,r=t.y-s
let o=a*a+r*r
return o>i*i&&0!=o?(o=i/l(o),new u(n+a*o,s+r*o)):new u(t.x,t.y)}static ClampMagnitude(e,t){let i=e.x,n=e.y
const a=i*i+n*n
if(a>t*t){const e=t/l(a)
return i*=e,n*=e,(0,s.L)({x:i,y:n},u)}return(0,s.L)({x:i,y:n},u)}static SmoothDamp(e,t,i,n,o,_){_=_||a.q.deltaTime,o=o||r.N.huge
const h=2/(n=Math.max(1e-4,n))
let c=h*_
c=1/(1+c+.48*c*c+.235*c*c*c)
const d=t.x,m=t.y,p=e.x,g=e.y
let I=p-d,E=g-m,C=I*I+E*E,S=o*n
C>S*S&&(C=S/l(C),I*=C,E*=C),C=i.x,S=i.y
const T=(C+h*I)*_,f=(S+h*E)*_
return i.x=(C-h*T)*c,i.y=(S-h*f)*c,C=p-I+(I+T)*c,S=g-E+(E+f)*c,(d-p)*(C-d)+(m-g)*(S-m)>0&&(C=d,S=m,i.x=0,i.y=0),[(0,s.L)({x:C,y:S},u),i]}static Max(e,t){return(0,s.L)({
x:Math.max(e.x,t.x),y:Math.max(e.y,t.y)},u)}static Min(e,t){return(0,s.L)({x:Math.min(e.x,t.x),y:Math.min(e.y,t.y)},u)}static Scale(e,t){return(0,s.L)({x:e.x*t.x,y:e.y*t.y},u)}
Div(e){return this.x/=e,this.y/=e,this}Mul(e){return this.x*=e,this.y*=e,this}Add(e){return this.x+=e.x,this.y+=e.y,this}Sub(e){this.x-=e.x,this.y-=e.y}static zero_get(){
return u.New(0,0)}static one_get(){return u.New(1,1)}toString(){return`(${this.x},${this.y})`}}u.normalized=u.Normalize_depred,u.zero=new u(0,0)},79534:(e,t,i)=>{"use strict"
i.d(t,{P:()=>I})
var n=i(18998),s=i(92456),a=i(82306),r=i(21729),l=i(63054)
const o=Math.acos,_=Math.sqrt,u=Math.max,h=Math.min,c=r.N.Clamp,d=(Math.cos,Math.sin),m=Math.abs,p=(r.N.Sign,57.295779513082),g=[]
class I extends n.Vec3{static Recyle(e){}static New(e=0,t=0,i=0){return I.count+=1,new I(e,t,i)}Set(e=0,t=0,i=0){this.x=e||0,this.y=t||0,this.z=i||0}CopyFrom(e){this.x=e.x,
this.y=e.y,this.z=e.z}static Get(e){return[e.x,e.y,e.z]}Clone(){if(g.length>0){const e=g.pop()
return e.Set(this.x,this.y,this.z),e}return new I(this.x,this.y,this.z)}static Distance(e,t){return _((e.x-t.x)**2+(e.y-t.y)**2+(e.z-t.z)**2)}static Dot(e,t){
return e.x*t.x+e.y*t.y+e.z*t.z}static Lerp(e,t,i){return i=c(i,0,1),I.New(e.x+(t.x-e.x)*i,e.y+(t.y-e.y)*i,e.z+(t.z-e.z)*i)}Magnitude(){
return _(this.x*this.x+this.y*this.y+this.z*this.z)}static Max(e,t){return I.New(u(e.x,t.x),u(e.y,t.y),u(e.z,t.z))}static Min(e,t){return I.New(h(e.x,t.x),h(e.y,t.y),h(e.z,t.z))}
static Normalize_depred(e){const[t,i,n]=[e.x,e.y,e.z],a=_(t*t+i*i+n*n)
return a>1e-5?(0,s.L)({x:t/a,y:i/a,z:n/a},I):(0,s.L)({x:0,y:0,z:0},I)}Normalize_depred(){return I.Normalize_depred(this)}Normalize(){return I.Normalize(this)}static Normalize(e){
const[t,i,n]=[e.x,e.y,e.z],s=_(t*t+i*i+n*n)
return s>1e-5?([e.x,e.y,e.z]=[t/s,i/s,n/s],e):([e.x,e.y,e.z]=[0,0,0],e)}SetNormalize(){const e=_(this.x*this.x+this.y*this.y+this.z*this.z)
return e>1e-5?(this.x/=e,this.y/=e,this.z/=e):(this.x=0,this.y=0,this.z=0),this}SqrMagnitude(){return this.x*this.x+this.y*this.y+this.z*this.z}static Angle(e,t){
return o(c(I.Dot(e.Normalize_depred(),t.Normalize_depred()),-1,1))*p}ClampMagnitude(e){return this.SqrMagnitude()>e*e&&(this.SetNormalize(),this.Mul(e)),this}
static OrthoNormalize(e,t,i){return e.SetNormalize(),t.Sub(t.Project(e)),t.SetNormalize(),null==i?[e,t,null]:(i.Sub(i.Project(e)),i.Sub(i.Project(t)),i.SetNormalize(),[e,t,i])}
ToXYZ(){return[this.x,this.y,this.z]}static MoveTowards(e,t,i){const n=I.Sub(t,e),s=n.SqrMagnitude()
if(s>i*i){const t=_(s)
return t>1e-6?(n.Mul(i/t),n.Add(e),n):e.Clone()}return t.Clone()}static RotateTowards(e,t,i,n){const s=e.Magnitude(),a=t.Magnitude()
if(s>1e-6&&a>1e-6){const r=I.Div(e,s),_=I.Div(t,a),u=I.Dot(r,_)
if(u>.999999)return I.MoveTowards(e,t,n)
if(u<-.999999){const e=C(r),t=l._.AngleAxis(i*p,e).MulVec3(r),o=E(s,a,n)
return t.Mul(o),t}const c=o(u),d=I.Cross(r,_)
d.SetNormalize()
const m=l._.AngleAxis(h(i,c)*p,d).MulVec3(r),g=E(s,a,n)
return m.Mul(g),m}return I.MoveTowards(e,t,n)}static SmoothDamp(e,t,i,n){
const s=r.N[1/0],l=a.q.deltaTime,o=2/(n=u(1e-4,n)),_=o*l,h=1/(1+_+.48*_*_+.235*_*_*_),c=t.Clone(),d=s*n,m=I.Sub(e,t)
m.ClampMagnitude(d),t=I.Sub(e,m)
const p=I.Mul(I.Add(i,I.Mul(m,o)),l)
i=I.Mul(I.Sub(i,I.Mul(p,o)),h)
let g=I.Add(t,I.Mul(I.Add(m,p),h))
return I.Dot(I.Sub(c,e),I.Sub(g,c))>0&&(g=c,i.Set(0,0,0)),[g,i]}static Scale(e,t){const i=e.x*t.x,n=e.y*t.y,s=e.z*t.z
return I.New(i,n,s)}scaleBy(e){this.x*=e,this.y*=e,this.z*=e}static Cross(e,t){const i=e.y*t.z-e.z*t.y,n=e.z*t.x-e.x*t.z,s=e.x*t.y-e.y*t.x
return I.New(i,n,s)}static Equals(e,t){return e.x==t.x&&e.y==t.y&&e.z==t.z}Equals(e){return this.x==e.x&&this.y==e.y&&this.z==e.z}static Reflect(e,t){const i=-2*I.Dot(t,e)
return t.Mul(i),t.Add(e),t}static Project(e,t){const i=t.SqrMagnitude()
if(i<1175494e-44)return I.New(0,0,0)
const n=I.Dot(e,t),s=t.Clone()
return s.Mul(n/i),s}Project(e){return I.Project(this,e)}static ProjectOnPlane(e,t){const i=I.Project(e,t)
return i.Mul(-1),i.Add(e),i}static Slerp(e,t,i){if(i<=0)return e.Clone()
if(i>=1)return t.Clone()
const n=t.Clone(),s=e.Clone(),a=t.Magnitude(),r=e.Magnitude()
n.Div(a),s.Div(r)
const _=(a-r)*i+r,u=s.x*n.x+s.y*n.y+s.z*n.z
let h,c
if(u>.999999)h=1-i,c=i
else{if(u<-.999999){const t=C(e),n=l._.AngleAxis(180*i,t).MulVec3(e)
return n.Mul(_),n}{const e=o(u),t=d(e)
h=d((1-i)*e)/t,c=d(i*e)/t}}return s.Mul(h),n.Mul(c),n.Add(s),n.Mul(_),n}Mul(e){return"number"==typeof e?(this.x*=e,this.y*=e,this.z*=e):this.MulQuat(e),this}static Mul(e,t){
return e.Clone().Mul(t)}Div(e){return this.x/=e,this.y/=e,this.z/=e,this}static Div(e,t){return e.Clone().Div(t)}Add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}
static Add(e,t){return e.Clone().Add(t)}Sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}Subtract(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}static Sub(e,t){
return I.New(e.x-t.x,e.y-t.y,e.z-t.z)}MulQuat(e){
const t=2*e.x,i=2*e.y,n=2*e.z,s=e.x*t,a=e.y*i,r=e.z*n,l=e.x*i,o=e.x*n,_=e.y*n,u=e.w||0,h=u*t,c=u*i,d=u*n,m=(1-(a+r))*this.x+(l-d)*this.y+(o+c)*this.z,p=(l+d)*this.x+(1-(s+r))*this.y+(_-h)*this.z,g=(o-c)*this.x+(_+h)*this.y+(1-(s+a))*this.z
return this.Set(m,p,g),this}static AngleAroundAxis(e,t,i){e.Sub(I.Project(e,i)),t.Sub(I.Project(t,i))
return I.Angle(e,t)*(I.Dot(i,I.Cross(e,t))<0?-1:1)}static zero_get(){return I.New(0,0,0)}static one_get(){return I.New(1,1,1)}static get up(){return I.New(0,1,0)}static up_get(){
return I.New(0,1,0)}static get down(){return I.New(0,-1,0)}static get right(){return I.New(1,0,0)}static get left(){return I.New(-1,0,0)}static get forward(){return I.New(0,0,1)}
static get back(){return I.New(0,0,-1)}static get one(){return I.New(1,1,1)}toString(){return`[${this.x},${this.y},${this.z}]`}}function E(e,t,i){const n=t-e
return n>0?e+h(n,i):e-h(-n,i)}function C(e){const t=I.New()
if(m(e.z)>.7071067811865476){const i=e.y*e.y+e.z*e.z,n=1/_(i)
t.x=0,t.y=-e.z*n,t.z=e.y*n}else{const i=e.x*e.x+e.y*e.y,n=1/_(i)
t.x=-e.y*n,t.y=e.x*n,t.z=0}return t}I._type_full_name_="Vector3",I._type_name_="Vector3",I.map={},I.map2={},I.count=0,I.ZEROTMP=new I(0,0,0),I.normalized=I.Normalize_depred},
44758:(e,t,i)=>{"use strict"
i.d(t,{L:()=>u})
var n=i(18998),s=i(21729)
const a=s.N.Clamp,r=s.N.Sqrt,l=s.N.Min,o=s.N.Max,_=[]
class u extends n.Vec4{static Recyle(e){return _.length<20?(e.Set(0,0,0,0),_.push(e),e):null}static New(e=0,t=0,i=0,n=0){if(_.length>0){const s=_.pop()
return s.Set(e,t,i,n),s}return new u(e,t,i,n)}Set(e=0,t=0,i=0,n=0){this.x=e||0,this.y=t||0,this.z=i||0,this.w=n||0}Get(){return[this.x,this.y,this.z,this.w]}static Lerp(e,t,i){
return i=a(i,0,1),u.New(e.x+(t.x-e.x)*i,e.y+(t.y-e.y)*i,e.z+(t.z-e.z)*i,e.w+(t.w-e.w)*i)}static MoveTowards(e,t,i){const n=u.Sub(t,e),s=n.Magnitude()
return s>i&&0!=s?(i/=s,n.Mul(i),n.Add(e),n):t}static Scale(e,t){return u.New(e.x*t.x,e.y*t.y,e.z*t.z,e.w*t.w)}SetScale(e){this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w}
Normalize(){return u.New(this.x,this.y,this.z,this.w).SetNormalize()}SetNormalize(){const e=this.Magnitude()
return 1==e||(e>1e-5?this.Div(e):this.Set(0,0,0,0)),this}Div(e){return this.x/=e,this.y/=e,this.z/=e,this.w/=e,this}static Div(e,t){return e.Clone().Div(t)}Mul(e){return this.x*=e,
this.y*=e,this.z*=e,this.w*=e,this}static Mul(e,t){return e.Clone().Mul(t)}Add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}static Add(e,t){
return e.Clone().Add(t)}Sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}static Sub(e,t){return e.Clone().Sub(t)}static Dot(e,t){
return e.x*t.x+e.y*t.y+e.z*t.z+e.w*t.w}static Project(e,t){const i=u.Dot(e,t)/u.Dot(t,t)
return u.Mul(t,i)}static Distance(e,t){const i=u.Sub(e,t)
return u.Magnitude(i)}static Magnitude(e){return r(e.x*e.x+e.y*e.y+e.z*e.z+e.w*e.w)}Magnitude(){return u.Magnitude(this)}static SqrMagnitude(e){
return e.x*e.x+e.y*e.y+e.z*e.z+e.w*e.w}SqrMagnitude(){return u.SqrMagnitude(this)}static Min(e,t){return u.New(o(e.x,t.x),o(e.y,t.y),o(e.z,t.z),o(e.w,t.w))}static Max(e,t){
return u.New(l(e.x,t.x),l(e.y,t.y),l(e.z,t.z),l(e.w,t.w))}static zero_get(){return new u(0,0,0,0)}static one_get(){return new u(1,1,1,1)}Clone(){if(_.length>0){const e=_.pop()
return e.Set(this.x,this.y,this.z,this.w),e}return new u(this.x,this.y,this.z,this.w)}toString(){return`[${this.x},${this.y},${this.z},${this.w}]`}Equals(e){
return this.x==e.x&&this.y==e.y&&this.z==e.z&&this.w==e.w}}},80121:(e,t,i)=>{"use strict"
i.d(t,{d:()=>n})
class n{static band(e,t){return e&t}static bor(e,t){return e|t}static lshift(e,t){return e<<t}static rshift(e,t){return e>>t}}},15895:(e,t,i)=>{"use strict"
i.d(t,{x:()=>n})
class n{static byte(e,t){return e.charCodeAt(t)}static len(e){return e.length}static find(e,t,i,n){return e.indexOf(t,i)}static rep(e,t){let i=""
for(let n=0;n<t;n++)i+=e
return i}}},92456:(e,t,i)=>{"use strict"
function n(e,t){const i=new t
for(const t in e)i[t]=e[t]
return i}i.d(t,{L:()=>n})},39229:()=>{globalThis.RYMACRO={MAPTILE:!1}},53908:(e,t,i)=>{"use strict"
i.d(t,{k5:()=>l,kc:()=>r})
var n=i(75507),s=i(89123)
const a=new Map
function r(e){const t=new s.SK(e)
t.isGZip&&t.gunzip()
const i=t.readShort()
for(let e=0;e<i;e++){const e=t.readString(),i=t.readUnsignedInt(),n=new s.SK
t.readBytes(n,0,i),a.set(e,n)}console.log(`--- ry config pack count: ${i}`)}function l(e,t){const i=a.get(e)
return i?(t&&a.delete(e),i):null}globalThis._loadCfgJson=function(){const e=n.o._getRemoteUrl("ryconfigs/configpack1.bin")
console.log(`--- wx '${e}'`)
const t=globalThis.window.wx,i=t.getFileSystemManager()
let s=t.env.USER_DATA_PATH+"/res/ConfigPack",a=performance.now(),r=performance.now()
i.mkdir({dirPath:s,recursive:!0,complete(){t.downloadFile({url:e,success(e){console.log("--- wx "),console.log(e),console.log("--- wx download "+(performance.now()-a)),
a=performance.now()
const t=e.tempFilePath
i.unzip({zipFilePath:t,targetPath:s,success(e){console.log("--- wx "),console.log(e),console.log("--- wx unzip "+(performance.now()-a)),a=performance.now()
const t=`${s}/configpack.json`
console.log(`jsonFilePath '${t}'`),i.readFile({filePath:t,encoding:"utf8",complete(e,t){e&&console.error(e),console.log("--- wx readFile "+(performance.now()-a)),
a=performance.now()
JSON.parse(t)
console.log("--- wx JSON.parse "+(performance.now()-a)),a=performance.now(),console.log("--- wx all "+(performance.now()-r))}})},fail(){console.error("unzip fail")}})},fail(){
console.error("_loadCfgJson fail")}})}})}},34272:(e,t,i)=>{"use strict"
i.d(t,{yt:()=>C,h0:()=>S,UK:()=>T})
var n=i(18998),s=i(50107),a=i(54986),r=i(71409),l=i(39407),o=i(98497),_=i(82198),u=(i(22267),i(89123)),h=i(41295),c=i(5924),d=i(37397)
const m=[]
class p{constructor(){this.host=null,this.port=0,this._webSocket=null,this._inputBytes=new u.SK,this._msgLen=0,this._closeStatus=!0,this.reConnectNum=0,this.reConnectTime=0,
this.reConnecting=!1,this.bodySize=-1,this._connected=!1,this.lastMsgkey=0,this.eventCallback=null,this.buffMessages=[],this.timer=-1,this._def_loginConnext=void 0,
this.isConnextSuccess=!1,this.sendEvent=void 0}connect(e,t){if(this._connected)return
this.host=e,this.port=t,this._webSocket&&this.close()
let i="https:"===window.location.protocol?`wss://${e}:${t}`:`ws://${e}:${t}`
i=`wss://gamewx.gmryxyx.elk20.com:9443/?host=${e}:${t}`
const n=new WebSocket(i)
n.binaryType="arraybuffer",n.onopen=()=>{this._onConnect()},n.onmessage=e=>{this._onMessage(e)},n.onclose=e=>{console.warn(`socket onclose ${new Date}  ${e}`),this._onClose()},
n.onerror=e=>{console.error(e),this._onError()},this._webSocket=n,this._inputBytes.endian="bigEndian",this._inputBytes.length=0,this._inputBytes.position=0,this.bodySize=-1,
this._def_loginConnext=this.loginConnext.bind(this)}getConnected(){return this._connected}releaseMsgData(e){e.bytes=null,m.push(e)}_onConnect(){(0,
l.t4)("Socket onConnect... success"),this.isConnextSuccess=!0,this._connected=!0,this.reConnectNum=0,this.reConnecting=!1,this.clearTimer(),
this.eventCallback&&this.eventCallback(s.C.SOCKET_CONNECTED)}_onMessage(e){const t=e?e.data:null
if(!t)return
const i=this._inputBytes
for(i.writeArrayBuffer(t),i.position=0;!(i.bytesAvailable<3);){if(this._msgLen=i.readVarInt(),i.readVarInt(),this._msgLen--,!(i.bytesAvailable>=this._msgLen&&this._msgLen>0)){
i.position-=4
break}{const e=i.readVarInt(),t=new u.SK
let n
this._msgLen>2&&i.readBytes(t,0,this._msgLen-2),m.length?(n=m.pop(),n.packId=e,n.bytes=t,n.clientTime=cus.currTime,n.serverTime=cus.currTime):n={packId:e,bytes:t,
clientTime:cus.currTime,serverTime:cus.currTime},this.buffMessages.push(n)}}i.clear()}_onClose(){let e=d._.Inst
this.sendEvent=!1,this.isConnextSuccess?(this._connected||this.reConnecting?(this._closeStatus=!0,e.closeConnectTime=(new Date).getTime(),
this.eventCallback&&this.eventCallback(s.C.SOCKET_CLOSED)):this.sendEvent=!0,this._connected=!1,console.log("[net] Socket onClose..."),this.openTimer()):e.neverConnextTips()}
openTimer(){-1==this.timer&&(console.log("首次重新连接"),(0,r.bG)(h.b.LOGIN_CONNECT),this.timer=c.C.Inst_get().SetInterval(this._def_loginConnext,1e3))}clearTimer(){
-1!=this.timer&&(c.C.Inst_get().ClearInterval(this.timer),this.timer=-1)}loginConnext(){let e=(new Date).getTime(),t=d._.Inst
if(this.sendEvent&&e-t.closeConnectTime>=2e5)this.clearTimer(),t.openLoginTips()
else if(!t.isShowTips){if(e-t.closeConnectTime>=1e4)return this.clearTimer(),void t.openDisconnectTips((()=>{this.openTimer()}))
e-t.closeConnectTime>=200&&t.openLoading(),(0,r.bG)(h.b.LOGIN_CONNECT),console.log("定时重新连接")}}_onError(){this._connected=!1,this._closeStatus=!0,this.openTimer(),
console.log("[net] Socket onError...")}loop(){}sendBeanData(e,t){const i=new u.SK
i.writeByte(0),i.writeVarInt(e),t&&i.writeBytes(t)
const n=new u.SK
n.writeVarInt(i.length),n.writeBytes(i),this._webSocket&&this._webSocket.send(n.__getBuffer())}close(){const e=this._webSocket
if(e){this._webSocket=null,e.onopen=null,e.onmessage=null,e.onclose=null,e.onerror=null
try{e.close()}catch(e){console.error(e)}}this._connected=!1,this.bodySize=-1}}var g=i(87115)
let I
class E{constructor(){this.logined=!1,this._delay=0,this._lastTime=0,this._paused=!1,this.socket=null,this.socket=new p,
this.socket.eventCallback=this.onSocketEventCallback.bind(this),cus.requestFrame(this.update,this)}connect(e,t){this.socket.connect(e,t)}onSocketEventCallback(e){
e===s.C.SOCKET_CONNECTED?(this.resetPack(),this.logined||(this.logined=!0),(0,r.bG)(s.C.SOCKET_CONNECTED)):e===s.C.SOCKET_CLOSED&&(0,r.bG)(s.C.SOCKET_CLOSED)}debugPack(e=800){
this._delay=e}resetPack(){this._delay=0}setPaused(e){this._paused=e}update(){if(this._paused)return
const e=cus.currTime
if(!n.game.isPaused()&&e-this._lastTime<this._delay)return
this._lastTime=e
const t=this.socket.buffMessages,i=t.length
if(0===i)return
let s=6
i>50?s=50:i>40?s=40:i>30?s=30:i>25?s=25:i>20?s=20:i>12?s=12:i>8&&(s=8)
let u=0
for(let e=0,i=Math.min(s,t.length);e<i;e++){const i=t[e],n=i.packId,s=g.vr[n]
if(s)try{const e=new s
_.b.readBuffer=i.bytes,e.read()
{const t=a.o.ins
t.isPrintProto&&(-1232!=n&&-1112!=n||t.isPrintMoveProto)&&console.log(`%c >>> [${s.name} ${n}] ${JSON.stringify(e,l.RT)}`,"color:#4ec9b0;")}o.j.Inst.F_SendHandler(n,e),(0,
r.bG)(`${n}`,e)}catch(e){console.error(`[net] ${n} --- ${e.message}`),console.error(e)}else console.error(`>>> [proto] '${n}' class cannot be found`)
if(this.socket.releaseMsgData(i),u+=1,this._paused)break}t.splice(0,u)}}function C(e,t){return I||(I=new E),I.connect(e,t),I}function S(){return I}function T(e,t){
I.socket._connected&&I.socket.sendBeanData(e,t)}},87115:(e,t,i)=>{"use strict"
i.d(t,{$_:()=>r,$e:()=>l,D_:()=>o,vr:()=>s})
var n=i(18998)
i(22267),i(39407)
const s={},a=new Map
function r(e){return t=>{null!=s[e]&&(0,n.error)(`repeat toc packId '${e}'`),s[e]=t,a.set(t,e)}}function l(e){return s[e]}function o(e){const t=e.constructor
const i=a.get(t)
return null==i?(console.error("undefined service vo"),0):i}},34565:(e,t,i)=>{"use strict"
i.d(t,{I:()=>_})
var n=i(18998),s=i(38045),a=i(28192),r=i(28287),l=i(83908),o=i(17409)
class _ extends((0,l.yk)()){constructor(...e){super(...e),this._panelID=null,this._panelUserData=null,this._m_handlerMgr=null}get m_handlerMgr(){
return this._m_handlerMgr||(this._m_handlerMgr=a.h.Get()),this._m_handlerMgr}isShow_get(){return this._isPanelActive}isOpen_get(){return this._isPanelActive}uiId_get(){
return this._isPanelActive?this._panelID:null}OnAddToScene(){}setId(e,t,i){}_panelReset(e){this._panelClean(),this._isPanelActive=e}_panelClean(){this._panelID=null,
this._panelUserData=void 0}_enableObserver(){throw new Error("UI Panel Component cannot call")}__isPanelScript(){return!0}removeSelfPanel(e){(0,o.sR)(this,e)}ShowCurrencyBar_get(){
return r._.None}AddClickEvent(e,t){(0,s.t2)(e,n.Component)&&(e=e.node),e.on(n.NodeEventType.TOUCH_END,t,this,!1)}RemoveClickEvent(e,t){(0,s.t2)(e,n.Component)&&(e=e.node),
e.off(n.NodeEventType.TOUCH_END,t,this,!1)}Clear(){}ClearChild(e){__$LaunchLogicBridge._clearBinderObject(e)}DestroyChild(e){__$LaunchLogicBridge._destroyBinderObject(e)}
Destroy(){}}},58542:(e,t,i)=>{"use strict"
i.d(t,{C:()=>n})
var n={closed:0,closing:1,openning:2,opened:3}},6847:(e,t,i)=>{"use strict"
i.d(t,{s_:()=>p})
var n=i(18998),s=i(34441),a=i(21370),r=i(17409),l=i(58542),o=(i(22267),i(75507)),_=i(89123)
const u={}
function h(e,t,i){let s=null;("string"==typeof e?[e]:e).forEach((e=>{"%"==e.charAt(0)&&(e=e.slice(1))
const t=u[e]
t?t.isLoad||(null==s&&(s=[]),s.push(function(e){const t=e.toLowerCase()
return new Promise(((e,i)=>{o.o.listenRes(o.o.loadBundleRes(`configs/${t}`,"preload",n.BufferAsset),(t=>{if(t){const n=o.o.getBuffer(t)
n?e(n):i()}}))}))}(e).then((e=>{!function(e,t){e.bytes=t}(t,new _.SK(e))})))):(0,n.error)(`cannot find cfgclass '${e}'`)})),t&&(s?Promise.all(s).then((()=>{t.call(i)})):t.call(i))}
class c{constructor(){this._$prefabs=null,this._$prefabCaches=null,this._$resArray=null,this._resPaths=null,this._configs=null,this._configLoadedCallback=null,
this._waitCallback=null,this._resLoaded=!1,this._retainResIds=null,this._binderOverTime=this._overtime.bind(this),this._loadBundle=null}get __IS_PANEL_WAIT__(){return!0}
prefab(e,t){if(!e)return console.error("null prefab"),this
const i=this._$prefabs||(this._$prefabs=[]),n=this._$prefabCaches||(this._$prefabCaches=[])
if("string"==typeof e)-1===i.indexOf(e)&&(i.push(e),n.push(t))
else for(let a=0;a<e.length;a++){const r=e[a]
r?-1===i.indexOf(r)&&(i.push(r),n.push(t?t[a]:s.X.RefTime)):console.error("null prefab")}return this}wait(e){const t=this._$resArray||(this._$resArray=[])
if(Array.isArray(e))for(let i=0;i<e.length;i++)t.push(e[i])
else t.push(e)
return this}_load(e,t){this.parseArray(),this._resLoaded=!1,this._configLoadedCallback=e,this._waitCallback=t,cus.unschedule(this._binderOverTime),
cus.scheduleOnce(60,this._binderOverTime),this._configs&&this._configs.length>0?h(this._configs,this._onConfigLoaded,this):this._onConfigLoaded()
const i=this,n=i._resPaths
let a=n?n.length:0
if(n&&a>0)for(let e=0;e<n.length;e++){const t=n[e]
o.o.listenRes(this._loadBundle?o.o.loadBundleRes(t.url,this._loadBundle,t.type,void 0!==t.cache?t.cache:s.X.RefTime):o.o.loadRes(t.url,t.type,void 0!==t.cache?t.cache:s.X.RefTime),r)
}else i._resLoaded=!0,i._checkResLoaded()
function r(e,t){if(a-=1,null!=i._waitCallback){const e=i._retainResIds||(i._retainResIds=new Set)
e.has(t)||(e.add(t),o.o._$retainRes(t))}0===a&&(i._resLoaded=!0,i._checkResLoaded())}}_onConfigLoaded(){this._configs=null
const e=this._configLoadedCallback
this._configLoadedCallback=null,null!=e&&e(!1),this._checkResLoaded()}_checkResLoaded(){if(null!=this._configLoadedCallback)return
if(!this._resLoaded)return
cus.unschedule(this._binderOverTime)
const e=this._waitCallback
this._waitCallback=null,null!=e&&e(!1)}_overtime(){const e=this._configLoadedCallback,t=this._waitCallback
this._configLoadedCallback=null,this._waitCallback=null,e?e(!0):t&&t(!0)}_cancel(){const e=this._retainResIds
e&&e.size&&(e.forEach(o.o._$releaseRes),e.clear()),this._waitCallback=null,this._configLoadedCallback=null,this._resLoaded=!1,cus.unschedule(this._binderOverTime)}_destroy(){
this._cancel()}parseArray(){const e=this._$resArray
if(e){this._$resArray=null
for(let t=0;t<e.length;t++){const i=e[t]
i&&("string"==typeof i?"%"===i.charAt(0)?(this._configs||(this._configs=[])).push(i):-1===i.indexOf("\\")&&-1===i.indexOf("/")?(this._resPaths||(this._resPaths=[])).push({
url:`atlas/${i}`,type:n.SpriteAtlas}):(this._resPaths||(this._resPaths=[])).push({url:i}):(this._resPaths||(this._resPaths=[])).push(i))}}const t=this._$prefabs
if(t){this._$prefabs=null,this._$prefabCaches=null
const e=this._resPaths||(this._resPaths=[])
for(let i=0;i<t.length;i++){const a=t[i]
e.push({url:a,type:n.Prefab,cache:s.X.RefTick})}}}}function d(e,t){const i=new c
return e&&i.wait(e),t&&i.wait(t),i}class m{constructor(){this.cls=null,this.prefabUrl="",this.panelId="",this.dependId="",this.panelWait=null,this.panelInout=void 0,
this.layer=a.T.None,this.layerMask=!1,this.layerMaskClickClose=!0,this.layerRemoveOther=!1,this.clickOutsideClose=!1,this.needOutsideBlock=!1,this.panelBlockEvent=void 0,
this._delayDestorySec=0,this._openCloseOnlyActive=!1,this._fullTest=!1,this._loadBundle=null,this._cache=s.X.RefTime,this._exclusive=!1,this.tabsPrefabObJ=void 0,
this.params=void 0,this._isHideMainUI=!1,this._isHideNPCTalkLayerUI=!1,this._childIndex=-1,this.view=null,this.script=void 0,this.userData=void 0,this.opcode=0,
this.state=l.C.closed,this.destroyFlag=!1,this.lastCloseTime=0}layerSet(e,t,i,n=!0){return this.layer=e,t&&(this.layerMask=t),i&&(this.layerRemoveOther=i),
this.layerMaskClickClose=n,this}layerPanel(e,t,i=!0,n=!1){return this.layer=a.T.panel,e&&(this.layerMask=e),t&&(this.layerRemoveOther=t),this.layerMaskClickClose=i,
this.clickOutsideClose=n,this}layerNav(){return this.layer=a.T.nav,this}layerTip(e=!1,t=!1){return this.layer=a.T.tip,this.clickOutsideClose=e,this.needOutsideBlock=t,this}
layerMsg(e=!1,t=!1){return this.layer=a.T.msg,this.clickOutsideClose=e,this.needOutsideBlock=t,this}wait(e,t){var i
return"object"==typeof(i=e)&&!0===i.__IS_PANEL_WAIT__?(this.panelWait&&(0,n.error)("already PanelWait"),this.panelWait=e):this.panelWait?(e&&this.panelWait.wait(e),
t&&this.panelWait.wait(t)):this.panelWait=d(e,t),this}waitPrefab(e,t){return(this.panelWait||(this.panelWait=d())).prefab(e,t),this}tabsPrefab(e,...t){let i=null!=t[0]?t[0]:999
return this.tabsPrefabObJ||(this.tabsPrefabObJ={}),this.tabsPrefabObJ[i]=e,this.params=t,this}inout(e,t=.1){return this.panelInout=e,this}blockEvent(e){
return this.panelBlockEvent=e,this}fullTest(){return this._fullTest=!0,this}bundle(e){return this._loadBundle=e,this}cache(e){return this._cache=e,this}delayDestroySec(e){
return this._delayDestorySec=null==e?6:e,this}openCloseOnlyActive(){return this._openCloseOnlyActive=!0,this}exclusive(){return this._exclusive=!0,this}hideMainUI(){
return this._isHideMainUI=!0,this}hideNPCLayerUI(){return this._isHideNPCTalkLayerUI=!0,this}isPanelActive(e){return(0,r.qJ)(this.panelId,e)}setChildAt(e=-1){
return this._childIndex=e,this}getPanelInout(){const e=this.panelInout
return e?null!=e.panelInoutFactory?e.panelInoutFactory():"object"==typeof e?e:new e:null}register(){return e=>(this.cls=e,
this.prefabUrl&&this.waitPrefab(this.prefabUrl,this._cache),this.layer!==a.T.panel&&this.layer!==a.T.scene||void 0!==this.panelBlockEvent||(this.panelBlockEvent=!0),
this._loadBundle&&this.panelWait&&(this.panelWait._loadBundle=this._loadBundle),this._fullTest&&this.layerMask&&((0,
n.error)(`'${this.panelId}' -> this._fullTest && this.layerMask`),this.layerMask=!1),(0,r.os)(this),e)}}function p(e,t){const i=new m
return i.panelId=e,i.prefabUrl=t,i.layer=a.T.panel,i}},10781:(e,t,i)=>{"use strict"
i.d(t,{R:()=>n})
const n=__$LaunchLogicBridge._Handler},83908:(e,t,i)=>{"use strict"
i.d(t,{Ri:()=>l,pA:()=>r,yk:()=>_,zB:()=>o})
var n=i(30849),s=i(84501),a=i(34565)
function r(e){return()=>e}function l(){return a.I}function o(){return n.C}function _(){return s.X}},57258:(e,t,i)=>{"use strict"
i.d(t,{E:()=>s})
var n=i(18998)
class s extends n.Vec2{constructor(e,t){super(),this.x=0,this.y=0,this.x=e,this.y=t}}},17409:(e,t,i)=>{"use strict"
i.d(t,{D1:()=>oe,mE:()=>ce,dU:()=>de,eW:()=>me,Z_:()=>Ie,C8:()=>pe,V9:()=>he,Rt:()=>_e,S1:()=>Ee,qJ:()=>ne,os:()=>X,sR:()=>J,Y:()=>se,Di:()=>le,Ue:()=>re,U6:()=>ae,Yp:()=>Q})
var n=i(18998),s=i(85602),a=i(52726),r=i(85688),l=i(75507),o=i(21370),_=i(50107),u=i(15317),h=i(66008),c=i(49655),d=i(38836),m=i(38045),p=i(97461),g=i(30621),I=i(5924),E=i(56937),C=i(5494),S=i(92679),T=i(28287),f=i(58087),A=i(38844),y=i(86871)
class R{static panelInoutFactory(){return this._ins||(this._ins=new R)}panelIn(e,t,i,s){if(!t)return
let a=t.getComponent(n.Widget)
a||(a=t.addComponent(n.Widget),a.isAlignVerticalCenter=!0,a.isAlignHorizontalCenter=!0,a.horizontalCenter=0,a.verticalCenter=0),a.updateAlignment(),
a.alignMode!==n.Widget.AlignMode.ALWAYS&&t.removeComponent(a),t.scale2d=.8,t.opacity=0,(0,n.tween)(t).to(.22,{scale2d:1.02,opacity:255}).to(.21,{scale2d:1}).start()}
panelOut(e,t,i,s,a){return(0,n.tween)(t).to(.11,{scale2d:1.02}).to(.11,{scale2d:.8,opacity:0}).start(),0}}R._ins=void 0
var D=i(58542)
const w={},L=new Set,v=new Set,O=new Map,P=new Map,N=[],M=[c.o.BagView,C.I.ForgePanel,C.I.eSkillPanel,C.I.TreasurePanel,C.I.RYDailyPanel,C.I.eSevenDayPanel,C.I.Market_Gold_Panel_ry]
let b=new s.Z
const G=new WeakMap
let U=null,B="",k=[],F=0,H=-1,x=new s.Z
const V=new WeakMap
let Y=null,W=[],K=!1,Z=null
const z=new WeakMap,q=new f.y
let $=new s.Z
function X(e){const t=e.panelId
null!=w[t]&&(0,n.error)(`repeat panelVo('${t}') ${w[t].cls.name} --- ${e.cls.name}`),w[t]=e}function Q(e,t,i){
if(null!=W&&e!=C.I.MapLoading&&e!=c.o.Createroleview_Ry&&e!=C.I.eCopyEntrancePanel)return void W.push([e,t,i])
if(null!=t&&"function"==typeof t&&(i=t,t=void 0),L.has(e))return
L.add(e),v.delete(e)
let s=null,l=-1
if(K=!1,Z=null,w[e]&&(0,m.t2)(t,E.v)){const i=t
K=i.isShowMask,$[e]=K,Z=i,w[e].layer=function(e){if(a.F.Alert==e)return o.T.Alert
if(a.F.Effect==e)return o.T.effect
if(a.F.Msg==e)return o.T.msg
if(a.F.Tip==e)return o.T.tip
if(a.F.Story==e)return o.T.nav
if(a.F.Msg==e)return o.T.msg
if(a.F.DefaultUI==e)return o.T.nav
if(a.F.NpcTalkUI==e)return o.T.npcTalk
if(a.F.Sound==e)return o.T.sound
return o.T.panel}(i.layerType),q.LuaDic_AddOrSetItem(e,Z)}function _(a){if(l<0||!s)return
const r=l
l-=1
const o=a?w[a]:void 0
if(o&&!o.view)return void(0,n.error)(`error dependPanel(${o.panelId}) view is null`)
const u=s[r]
if(o){const t=null!=o.script._panelTrySelectSub?o.script._panelTrySelectSub(u):void 0
if(!t)return
if(t!==u)return void j(a,t,void 0,0,!1,!0,void 0,t==e?i:void 0)
null!=o.script.setSelectPanelId&&o.script.setSelectPanelId(u)}const h=w[u],c=0===r
if(h.state!==D.C.opened)j(a||h.layer,u,c?t:void 0,0,c,c,c?void 0:_,u==e?i:void 0)
else{if(c&&h.script&&(h._openCloseOnlyActive,null!=h.script.onUserDataUpdate))try{h.script.onUserDataUpdate(t)}catch(t){(0,n.error)(`${e} ${t.message}`),(0,n.error)(t)}c||_(u)}}
w[e]?(!function(a){if(a._exclusive&&B)return void N.push([e,t])
if(!a.dependId)return void j(a.layer,e,t,0,!0,!0,void 0,i)
s=[e]
let r=a
for(;r.dependId;){const e=r.dependId
if(r=w[e],!r)return void(0,n.error)(`cannot find dependId(${e})`)
s.push(e)}l=s.length-1,_()}(w[e]),w[e]._isHideMainUI&&(te(!1),w[e].layer!=o.T.npcTalk&&ie(!1)),w[e]._isHideNPCTalkLayerUI&&r.n.ins.setLayerVisible(o.T.npcTalk,!1)):(0,
n.error)(`cannot find panelId: '${e}'`)}function j(e,t,i,s,a,u,h,c){const d=w[t]
if(!d)return(0,n.warn)(`cannot find panelId('${t}')`),void ee(t)
{let e
e="number"==typeof t?`eUIComponentID.${C.I[t]}`:t,console.log(`---doOpenPanel: ${e}`)}if(d.state===D.C.opened){if(a&&d.script&&(d._openCloseOnlyActive,
null!=d.script.onUserDataUpdate))try{d.script.onUserDataUpdate(i)}catch(e){(0,n.error)(`${t} ${e.message}`),(0,n.error)(e)}h&&h(t)}let m=k.indexOf(d)
if(m>-1&&(d.lastCloseTime=0,k.splice(m,1),Se()),"string"==typeof e||e>0){const i=O.get(e)
if(i){const e=w[i]
e&&e._openCloseOnlyActive||J(i,void 0,!1)}O.set(e,t),P.set(t,e)}if(d.state===D.C.opened)return
L.add(t),v.delete(t),d.opcode+=1
const g=d.opcode
let I
d.state=D.C.openning
let f=!1,A=!1
function N(e){F()||e&&((0,n.error)(`panel load overtime --- '${t}'`),J(t,void 0,!1))}function M(s){if(F())return
if(s)return(0,n.error)(`panel load overtime --- '${t}'`),void J(t,void 0,!1)
d._fullTest&&(0,n.log)(`--\x3e PanelId: ${t}  -- fullTest`)
let _=d.view
if(!_){try{const e=l.o.get(d.prefabUrl,n.Prefab,d._loadBundle)
if(!(e instanceof n.Prefab))return(0,n.error)(`error prefab ${d.prefabUrl}`),void J(t,void 0,!1)
if(_=(0,n.instantiate)(e),F())return}catch(e){return(0,n.error)(`${t} ${e.message}`),(0,n.error)(e),void J(t,void 0,!1)}d.view=_}if(!_)return
d._exclusive&&(B=t)
const u=!0
if(I=_.getComponent(d.cls),!I&&(I=_.addComponent(d.cls),F()))return
d.script&&d.script!==I&&(0,n.error)("error panelVo.script!!!"),d.script=I,d.destroyFlag=!1,
d.panelBlockEvent&&!_.getComponent(n.BlockInputEvents)&&_.addComponent(n.BlockInputEvents)
try{I._panelReset(u),I._panelID=t,I._panelUserData=i}catch(e){return(0,n.error)(`${t} ${e.message}`),(0,n.error)(e),void J(t,void 0,!1)}if(F())return
if("string"==typeof e||e>0){const i=w[e]
if(!i||!i.view)return(0,n.error)(`parentId('${e}') has no view`),void J(t,void 0,!1)
const s=i.view.getChildByName("content")
s?s.addChild(_):i.view.addChild(_)}else if(!r.n.ins.addToLayer(e,_,d))return(0,n.error)(`cannot find PanelLayer(${d.layer})`),void J(t,void 0,!1)
if(F())return
d.state=D.C.opened
const h=d.dependId?w[d.dependId]:void 0,c=h?h.script:void 0
if(I._isPanelOpenCall=a,(0,y.I)(I),null!=I.onPanelAdded){try{I.onPanelAdded(i,t,c?c._panelUserData:void 0)}catch(e){(0,n.error)(`${t} ${e.message}`),(0,n.error)(e)}if(F())return}
null!=I.OnAddToScene&&I.OnAddToScene(),d.clickOutsideClose&&oe(I,(function(){J(t)})),$[t]&&ce(I),
I.ShowCurrencyBar_get&&I.ShowCurrencyBar_get()!=T._.None&&p.i.Inst.RaiseEvent(S.g.OpenCurrencyBarView,[I,t])
let m=q.LuaDic_GetItem(t)
if(I&&m){const e=new E.v
e.maskAlpha=m.maskAlpha,e.isShowMask=m.isShowMask,z.set(I,e),m.isDefaultUITween&&(p.i.Inst.RaiseEvent(S.g.UITweenStateChanged,!0),r.n.ins.setLayerVisible(o.T.nav,!1)),
function(e,t){e.ShowCurrencyBar_get&&e.ShowCurrencyBar_get()!=T._.None&&p.i.Inst.RaiseEvent(S.g.OpenCurrencyBarView,[e,e._panelID])
Z&&Z.isExclusionPanel&&p.i.Inst.RaiseEvent(S.g.OpenExclusionPanel)
if(e.isExclusionPanel){if(B==e._panelID)return
B>0&&e.isKillAllExcluded,e.isKillAllExcluded?L.forEach((e=>{const t=w[e]
if(t){const e=t.panelId
!function(e){if(ne(e)&&w[e]){const t=w[e].script
if(null!=t&&t.IsFirstPanel_Get&&t.IsFirstPanel_Get())return!0}return!1}(e)?function(e){if(ne(e)&&w[e]){const t=w[e].script
if(null!=t&&t.IsForceCloseByGoAccess&&t.IsForceCloseByGoAccess())return!0}return!1}(e)&&J(e):J(e)}})):B=e._panelID}}(I)}if(c&&null!=c.onSubPanelAdded){try{c.onSubPanelAdded(t,i)
}catch(e){(0,n.error)(`${t} ${e.message}`),(0,n.error)(e)}if(F())return}G(),b()}function b(){if(A)return
if(A=!0,F())return
const s=d.view
if(!s)return
if(!(0,n.isValid)(s))return
s.off(_.C.PANEL_UPDATED,b),d._fullTest&&r.n.ins.invalid()
const a=d.getPanelInout()
a&&(a instanceof R?O.has(t)||("string"==typeof e||e>0||d._fullTest,a.panelIn(t,s,I,i)):a.panelIn(t,s,I,i)),null!=c&&c(t)}function G(){if(d.view&&d.view.off(_.C.PANEL_READY,G),
cus.unschedule(U),!f&&!F()){if(f=!0,null!=I.onPanelReady)try{I.onPanelReady()}catch(e){(0,n.error)(`${t} ${e.message}`),(0,n.error)(e)}if(null!=h&&h(t),u){
const e=null!=I._panelTrySelectSub?I._panelTrySelectSub(void 0):void 0
e&&null!=I.setSelectId&&I.setSelectId(e,I._panelSelIdData(),!1,!0)}}}function U(){F()||(0,n.warn)(`PanelId(${t}) should handle the panelReady!!!`),G()}function F(){
return g!==d.opcode}d.panelWait?d.panelWait._load(N,M):(N(!1),M(!1))}function J(e,t,i=!0){if(!e)return
const s="string"==typeof e||"number"==typeof e?e:e._panelID
if(!s)return void(0,n.warn)(`error panelId in value('${e}')`)
const l=w[s]
if(!l)return
if(ee(s),l.state===D.C.closed||l.state===D.C.closing)return
if(i){const e=P.get(s)
if(e)return void J(e,t)}const _=!P.get(s)
P.delete(s),v.add(s),l.opcode+=1
const u=l.opcode
l.state=D.C.closing
const h=l.script,c=l.view
if(c&&c.parent&&h){let e=0
if(!l._fullTest&&_&&!l.clickOutsideClose){const i=l.getPanelInout()
i&&(e=i.panelOut(s,c,h,t,l.layerMask))}e>0?(e>5&&(e=5,(0,n.error)(`delay(${e}) large!!!`)),cus.scheduleOnce(e,m)):(m(),l.layer==o.T.panel&&function(e){for(const[e,t]of(0,
d.V5)(q))t.layerType==a.F.Tip&&J(e)}(o.T.tip))}function m(){if(cus.unschedule(m),u!==l.opcode)return
if(l.state=D.C.closed,l.destroyFlag=!0,c){h&&h.ShowCurrencyBar_get&&h.ShowCurrencyBar_get()!=T._.None&&p.i.Inst.RaiseEvent(S.g.CloseCurrencyBarView,s)
let e=q.LuaDic_GetItem(s)
if(e&&e.isDefaultUITween&&!ne(C.I.AlliancePanel)&&(r.n.ins.setLayerVisible(o.T.nav,!0),p.i.Inst.RaiseEvent(S.g.UITweenStateChanged,!1)),h&&null!=h.onPanelBeforeRemoved)try{
h.onPanelBeforeRemoved()}catch(e){(0,n.error)(`${s} ${e.message}`),(0,n.error)(e)}if(h&&null!=h.Clear)try{h.Clear()}catch(e){(0,n.error)(`${s} ${e.message}`),(0,n.error)(e)}
l.layer===o.T.None?c.removeFromParent():r.n.ins.removeFromLayer(l.layer,c,l)}if(h){if(null!=h.onPanelRemoved)try{h.onPanelRemoved(t)}catch(e){(0,n.error)(`${s} ${e.message}`),(0,
n.error)(e)}h._panelClean()}const e=O.get(s)
if(O.delete(s),e&&J(e,t,!1),-1==M.indexOf(l.panelId)?l._delayDestorySec>0?cus.scheduleOnce(l._delayDestorySec,I):I():(l.lastCloseTime=g.R.serverTime_get(),
-1==k.indexOf(l)&&k.push(l),Se()),l._exclusive&&l.panelId===B&&(B="",N.length)){const{0:e,1:t}=N.shift()
Q(e,t)}}function I(){if(cus.unschedule(I),u===l.opcode&&(l.panelWait&&l.panelWait._cancel(),l.view=null,l.script=void 0,v.delete(s),c&&(0,n.isValid)(c,!0)))try{c.destroy()
}catch(e){(0,n.error)(`${s} ${e.message}`),(0,n.error)(e)}}}function ee(e){L.delete(e)
const t=w[e]
if(null!=t){if(_e(t.script),t._isHideMainUI){let e=!1,t=!1
L.forEach((i=>{const n=w[i]
n&&n._isHideMainUI&&(e=!0,n.layer!=o.T.npcTalk&&(t=!0))})),te(!e),ie(!t)}if(t._isHideNPCTalkLayerUI){let e=!1
L.forEach((t=>{const i=w[t]
i&&i._isHideNPCTalkLayerUI&&(e=!0)})),r.n.ins.setLayerVisible(o.T.npcTalk,!e)}}var i
null!=t&&(i=t.script)&&(x[x.count-1]==i&&i.node.removeChild(Y),x.Remove(i),ge())}function te(e){r.n.ins.setLayerVisible(o.T.nav,e)}function ie(e){
h.n.gameStage.scene.setLayerVisible(u.W.BottomTex,e),h.n.gameStage.scene.setLayerVisible(u.W.Bottom,e),h.n.gameStage.scene.setLayerVisible(u.W.Middle,e),
h.n.gameStage.scene.setLayerVisible(u.W.Top,e),h.n.gameStage.scene.setLayerVisible(u.W.Texture,e)}function ne(e,t){const i=w[e]
if(i){if(!L.has(e))return!1
if(t)return!0
if(i.script&&i.script._isPanelActive)return!0}return!1}function se(e){if(ne(e)){return w[e].script}return null}function ae(e){if(ne(e)){return w[e].tabsPrefabObJ}return null}
function re(e){if(ne(e)){return w[e].params}return null}function le(e){if(ne(e)){return w[e].state}return null}function oe(e,t){U||(U=new n.Node,U.name="fullScreenCollider",
U.addComponent(n.UITransform),U.getComponent(n.UITransform).width=5e3,U.getComponent(n.UITransform).height=5e3),G.has(e)?(b.Remove(e),b.push(e),G.set(e,t)):(b.push(e),G.set(e,t)),
ue()}function _e(e){e&&(b[b.count-1]==e&&e.node.removeChild(U),b.Remove(e),ue())}function ue(){if(U){const e=new s.Z
for(let t=0;t<b.count;t++)G.has(b[t])&&e.Add(b[t])
if(b=e,b.count>0){U.active=!0
const e=b[b.count-1]
e.node?e.node.addChild(U):e.addChild(U),(e.node?e.node.getChildByName("fullScreenMask"):e.getChildByName("fullScreenMask"))?U.setSiblingIndex(1):U.setSiblingIndex(0),
U.off(n.NodeEventType.TOUCH_END),U.on(n.NodeEventType.TOUCH_END,G.get(e),e)}else U.active=!1}}function he(){Y||(Y=new n.Node,Y.name="fullScreenMask",Y.addComponent(n.UITransform),
Y.getComponent(n.UITransform).width=5e3,Y.getComponent(n.UITransform).height=5e3,Y.addComponent(A.E),Y.getComponent(A.E).sizeMode=0,
Y.getComponent(A.E).SetColor(new n.Color(255,255,255,128)),Y.getComponent(A.E).skin="/atlas/common/rycommon_sp_black",Y.addComponent(n.BlockInputEvents))}
function ce(e,t=function(){}){e.isBattleScore||(Y||(Y=new n.Node,Y.name="fullScreenMask",Y.addComponent(n.UITransform),Y.getComponent(n.UITransform).width=5e3,
Y.getComponent(n.UITransform).height=5e3,Y.addComponent(A.E),Y.getComponent(A.E).sizeMode=0,Y.getComponent(A.E).SetColor(new n.Color(255,255,255,128)),
Y.getComponent(A.E).skin="/atlas/common/rycommon_sp_black",Y.addComponent(n.BlockInputEvents)),V.has(e)?(x.Remove(e),x.push(e),V.set(e,t)):(x.push(e),V.set(e,t)),ge())}
function de(e,t=!1,i=!1){for(const[i,n]of(0,d.V5)(q))i!=e&&t&&n.ReLoginOrChangeRoleIsDestroy&&J(i)}function me(e){for(const[t,i]of(0,
d.V5)(q))t!=e&&i.isExclusionPanel&&!i.isCanNotBeExcluded&&J(t)}function pe(e){const t=w[e._panelID]
let i=0
return t.layer!=o.T.None&&(i=1e4*(t.layer+1e3)+100*e.node.getSiblingIndex()),i}function ge(){if(Y){const e=new s.Z
for(let t=0;t<x.count;t++)V.has(x[t])&&e.Add(x[t])
if(x=e,x.count>0){Y.active=!0
const e=x[x.count-1]
if(e.node.addChild(Y),Y.setSiblingIndex(0),Y.off(n.NodeEventType.TOUCH_END),Y.on(n.NodeEventType.TOUCH_END,V.get(e),e),z.has(e)){const t=z.get(e)
Y.getComponent(A.E).SetColor(new n.Color(255,255,255,255*t.maskAlpha))}else Y.getComponent(A.E).SetColor(new n.Color(255,255,255,128))}else Y.active=!1}}function Ie(){return Y}
function Ee(){const e=W
return W=null,e||[]}function Ce(){let e=g.R.serverTime_get()
if(e-F>40){F=e
for(let t=k.length-1;t>=0;t--)e-k[t].lastCloseTime>300&&k.splice(t,1)
0==k.length&&Te()}}function Se(){k.length>0?-1==H&&(H=I.C.Inst_get().SetInterval(Ce,6e4)):0==k.length&&Te()}function Te(){-1!=H&&(I.C.Inst_get().ClearInterval(H),H=-1)}},
41295:(e,t,i)=>{"use strict"
i.d(t,{b:()=>n})
const n={LOGIN_CONNECT:"login_connect",LOAD_END:"LOAD_END"}},49655:(e,t,i)=>{"use strict"
i.d(t,{o:()=>s})
var n=i(5494)
const s={...i(82662).b,...n.I}},46282:(e,t,i)=>{"use strict"
i.d(t,{Z:()=>n})
const n={Empty:"ui/Empty",ui_bag_itemmodeltippanel:"ui/Itemmodeltip/ui_bag_itemmodeltippanel",ui_joystick_panel:"ui/JoyStick/ui_joystick_panel",
ui_multipleExpHang_addtime:"ui/MultipleExpHang/ui_multipleExpHang_addtime",ui_multipleExpHang_buff_tips:"ui/MultipleExpHang/ui_multipleExpHang_buff_tips",
ui_multipleExpHang_mainR:"ui/MultipleExpHang/ui_multipleExpHang_mainR",ui_multipleExpHang_mainR_item:"ui/MultipleExpHang/ui_multipleExpHang_mainR_item",
ui_multipleExpHang_panel:"ui/MultipleExpHang/ui_multipleExpHang_panel",ui_multipleExpHang_remaind_time:"ui/MultipleExpHang/ui_multipleExpHang_remaind_time",
ui_multipleExpHang_result:"ui/MultipleExpHang/ui_multipleExpHang_result",Test:"ui/Test",ui_upgrade_panel:"ui/UpgradeTip/ui_upgrade_panel",
ui_access_iconitem:"ui/access/ui_access_iconitem",ui_access_commonlist_panel:"ui/access_ry/ui_access_commonlist_panel",
ui_access_copydefeat_icon:"ui/access_ry/ui_access_copydefeat_icon",ui_access_currency_panel:"ui/access_ry/ui_access_currency_panel",
ui_access_currency_panel2:"ui/access_ry/ui_access_currency_panel2",ui_access_icon:"ui/access_ry/ui_access_icon",ui_access_kindspanel:"ui/access_ry/ui_access_kindspanel",
ui_access_mall_item:"ui/access_ry/ui_access_mall_item",ui_access_normal_item:"ui/access_ry/ui_access_normal_item",ui_access_panel:"ui/access_ry/ui_access_panel",
ui_activity_lottery_goods_item:"ui/activitylottery/ui_activity_lottery_goods_item",ui_activity_lottery_view:"ui/activitylottery/ui_activity_lottery_view",
ui_gain_item:"ui/activitylottery/ui_gain_item",ui_gain_item_view:"ui/activitylottery/ui_gain_item_view",
ui_alliance_activity_enteritem:"ui/alliance/activity/ui_alliance_activity_enteritem",ui_alliance_chuangong_ry:"ui/alliance/activity/ui_alliance_chuangong_ry",
ui_alliance_minxiang_ry:"ui/alliance/activity/ui_alliance_minxiang_ry",ui_alliance_alliancebuildpanel:"ui/alliance/allianceBuild/ui_alliance_alliancebuildpanel",
ui_alliance_alliancehallitem:"ui/alliance/allianceBuild/ui_alliance_alliancehallitem",ui_alliance_alliancehallitem_new:"ui/alliance/allianceBuild/ui_alliance_alliancehallitem_new",
ui_alliance_alliancehallpanel:"ui/alliance/allianceBuild/ui_alliance_alliancehallpanel",ui_alliance_alliancetecitem:"ui/alliance/allianceBuild/ui_alliance_alliancetecitem",
ui_alliance_alliancetreasureitem:"ui/alliance/allianceBuild/ui_alliance_alliancetreasureitem",
ui_alliance_alliancetreasurepanel:"ui/alliance/allianceBuild/ui_alliance_alliancetreasurepanel",
ui_alliance_alliancevaultitem:"ui/alliance/allianceBuild/ui_alliance_alliancevaultitem",ui_alliance_build_itemContainer:"ui/alliance/allianceBuild/ui_alliance_build_itemContainer",
ui_alliance_rytechiconitem:"ui/alliance/allianceBuild/ui_alliance_rytechiconitem",ui_alliance_rytechitem:"ui/alliance/allianceBuild/ui_alliance_rytechitem",
ui_alliance_rytechview:"ui/alliance/allianceBuild/ui_alliance_rytechview",ui_ry_alliance_donationpanel:"ui/alliance/allianceBuild/ui_ry_alliance_donationpanel",
ui_ry_alliance_donationtipsitem:"ui/alliance/allianceBuild/ui_ry_alliance_donationtipsitem",ui_alliance_assist_assistantitem:"ui/alliance/assist/ui_alliance_assist_assistantitem",
ui_alliance_assist_basepanel:"ui/alliance/assist/ui_alliance_assist_basepanel",ui_alliance_assist_goblinresponseview:"ui/alliance/assist/ui_alliance_assist_goblinresponseview",
ui_alliance_assist_goblinview:"ui/alliance/assist/ui_alliance_assist_goblinview",ui_alliance_assist_goblinviewitem:"ui/alliance/assist/ui_alliance_assist_goblinviewitem",
ui_alliance_assist_griditem:"ui/alliance/assist/ui_alliance_assist_griditem",ui_alliance_assist_mainview:"ui/alliance/assist/ui_alliance_assist_mainview",
ui_alliance_assist_msgitem:"ui/alliance/assist/ui_alliance_assist_msgitem",ui_alliance_assist_recievethankview:"ui/alliance/assist/ui_alliance_assist_recievethankview",
ui_alliance_assist_recievethankview_1:"ui/alliance/assist/ui_alliance_assist_recievethankview_1",ui_alliance_assist_thankview:"ui/alliance/assist/ui_alliance_assist_thankview",
ui_alliance_chuangongapply_griditem:"ui/alliance/assist/ui_alliance_chuangongapply_griditem",ui_alliance_chuangongapply_view:"ui/alliance/assist/ui_alliance_chuangongapply_view",
ui_assist_gainrewpanel:"ui/alliance/assist/ui_assist_gainrewpanel",ui_asuramwar_altartracepanel:"ui/alliance/asuramwar/ui_asuramwar_altartracepanel",
ui_asuramwar_awscoreshowpanel:"ui/alliance/asuramwar/ui_asuramwar_awscoreshowpanel",ui_asuramwar_bufficon:"ui/alliance/asuramwar/ui_asuramwar_bufficon",
ui_asuramwar_bufficonitem:"ui/alliance/asuramwar/ui_asuramwar_bufficonitem",ui_asuramwar_enrollitem:"ui/alliance/asuramwar/ui_asuramwar_enrollitem",
ui_asuramwar_exploit_item:"ui/alliance/asuramwar/ui_asuramwar_exploit_item",ui_asuramwar_headitem:"ui/alliance/asuramwar/ui_asuramwar_headitem",
ui_asuramwar_lastrecorditem:"ui/alliance/asuramwar/ui_asuramwar_lastrecorditem",ui_asuramwar_matchingpanel:"ui/alliance/asuramwar/ui_asuramwar_matchingpanel",
ui_asuramwar_rank_item:"ui/alliance/asuramwar/ui_asuramwar_rank_item",ui_asuramwar_rank_panel:"ui/alliance/asuramwar/ui_asuramwar_rank_panel",
ui_asuramwar_resitem:"ui/alliance/asuramwar/ui_asuramwar_resitem",ui_asuramwar_ruleitem:"ui/alliance/asuramwar/ui_asuramwar_ruleitem",
ui_asuramwar_runenoticpanel:"ui/alliance/asuramwar/ui_asuramwar_runenoticpanel",ui_asuramwar_scorereward_item:"ui/alliance/asuramwar/ui_asuramwar_scorereward_item",
ui_asuramwar_scoreshowitem:"ui/alliance/asuramwar/ui_asuramwar_scoreshowitem",ui_asuramwar_target_altaritem:"ui/alliance/asuramwar/ui_asuramwar_target_altaritem",
ui_asuramwar_target_throneitem:"ui/alliance/asuramwar/ui_asuramwar_target_throneitem",ui_rune_head:"ui/alliance/asuramwar/ui_rune_head",
ui_alliance_boss_boxpanel:"ui/alliance/boss/ui_alliance_boss_boxpanel",ui_alliance_boss_countdown_ry:"ui/alliance/boss/ui_alliance_boss_countdown_ry",
ui_alliance_boss_rankpanel:"ui/alliance/boss/ui_alliance_boss_rankpanel",ui_alliance_boss_rankpanelcell:"ui/alliance/boss/ui_alliance_boss_rankpanelcell",
ui_alliance_bossalert:"ui/alliance/boss/ui_alliance_bossalert",ui_alliance_bossblood:"ui/alliance/boss/ui_alliance_bossblood",
ui_alliance_bossup:"ui/alliance/boss/ui_alliance_bossup",ui_alliance_bossview:"ui/alliance/boss/ui_alliance_bossview",
ui_alliance_bossview_rankcell:"ui/alliance/boss/ui_alliance_bossview_rankcell",ui_alliance_createalliance_flagitem:"ui/alliance/createalliance/ui_alliance_createalliance_flagitem",
ui_alliance_car_attrList:"ui/alliance/factory/ui_alliance_car_attrList",ui_alliance_car_oneattr:"ui/alliance/factory/ui_alliance_car_oneattr",
ui_alliance_car_oneattr2:"ui/alliance/factory/ui_alliance_car_oneattr2",ui_alliance_caritem:"ui/alliance/factory/ui_alliance_caritem",
ui_alliance_carlockitem:"ui/alliance/factory/ui_alliance_carlockitem",ui_alliance_factory:"ui/alliance/factory/ui_alliance_factory",
ui_alliance_pullcar:"ui/alliance/factory/ui_alliance_pullcar",ui_alliance_question_chat_totalcell:"ui/alliance/question/ui_alliance_question_chat_totalcell",
ui_alliance_question_chatview_ry:"ui/alliance/question/ui_alliance_question_chatview_ry",ui_alliance_question_rankitem_ry:"ui/alliance/question/ui_alliance_question_rankitem_ry",
ui_alliance_questionview_ry:"ui/alliance/question/ui_alliance_questionview_ry",ui_alliance_taskItem:"ui/alliance/task/ui_alliance_taskItem",
ui_alliance_taskpanel:"ui/alliance/task/ui_alliance_taskpanel",ui_alliance_activeview_ry:"ui/alliance/ui_alliance_activeview_ry",
ui_alliance_activityenter:"ui/alliance/ui_alliance_activityenter",ui_alliance_alliancelistview:"ui/alliance/ui_alliance_alliancelistview",
ui_alliance_apply:"ui/alliance/ui_alliance_apply",ui_alliance_applyagentview:"ui/alliance/ui_alliance_applyagentview",
ui_alliance_applyinfo_new:"ui/alliance/ui_alliance_applyinfo_new",ui_alliance_appoint:"ui/alliance/ui_alliance_appoint",
ui_alliance_assist_lefttime_view:"ui/alliance/ui_alliance_assist_lefttime_view",ui_alliance_asuramwardamagepanel:"ui/alliance/ui_alliance_asuramwardamagepanel",
ui_alliance_asuramwardowntimepanel:"ui/alliance/ui_alliance_asuramwardowntimepanel",ui_alliance_asuramwarfailpanel:"ui/alliance/ui_alliance_asuramwarfailpanel",
ui_alliance_asuramwarhistorypanel:"ui/alliance/ui_alliance_asuramwarhistorypanel",ui_alliance_asuramwarinfo:"ui/alliance/ui_alliance_asuramwarinfo",
ui_alliance_asuramwarmatchitem:"ui/alliance/ui_alliance_asuramwarmatchitem",ui_alliance_asuramwarrewardpanel:"ui/alliance/ui_alliance_asuramwarrewardpanel",
ui_alliance_asuramwarscoreitem:"ui/alliance/ui_alliance_asuramwarscoreitem",ui_alliance_asuramwarscoreshowpanel:"ui/alliance/ui_alliance_asuramwarscoreshowpanel",
ui_alliance_asuramwarstatuspanel:"ui/alliance/ui_alliance_asuramwarstatuspanel",ui_alliance_asuramwarsucpanel:"ui/alliance/ui_alliance_asuramwarsucpanel",
ui_alliance_bloginfo:"ui/alliance/ui_alliance_bloginfo",ui_alliance_blogview:"ui/alliance/ui_alliance_blogview",ui_alliance_charioticon:"ui/alliance/ui_alliance_charioticon",
ui_alliance_chariotinprocess:"ui/alliance/ui_alliance_chariotinprocess",ui_alliance_createalliance:"ui/alliance/ui_alliance_createalliance",
ui_alliance_fireview_ry:"ui/alliance/ui_alliance_fireview_ry",ui_alliance_infoview:"ui/alliance/ui_alliance_infoview",ui_alliance_invite:"ui/alliance/ui_alliance_invite",
ui_alliance_memberinfo:"ui/alliance/ui_alliance_memberinfo",ui_alliance_memberinfo_new:"ui/alliance/ui_alliance_memberinfo_new",
ui_alliance_membersview:"ui/alliance/ui_alliance_membersview",ui_alliance_notice:"ui/alliance/ui_alliance_notice",
ui_alliance_notice_backupitem:"ui/alliance/ui_alliance_notice_backupitem",ui_alliance_overview:"ui/alliance/ui_alliance_overview",
ui_alliance_postallianceinfo:"ui/alliance/ui_alliance_postallianceinfo",ui_alliance_postallianceinfo_new:"ui/alliance/ui_alliance_postallianceinfo_new",
ui_alliance_quittip:"ui/alliance/ui_alliance_quittip",ui_alliance_statisticspanel:"ui/alliance/ui_alliance_statisticspanel",
ui_asuramwar_camppanel:"ui/alliance/ui_asuramwar_camppanel",ui_asuramwar_rulepanel:"ui/alliance/ui_asuramwar_rulepanel",
ui_ry_alliancefactory_mainpanel:"ui/alliance/ui_ry_alliancefactory_mainpanel",ui_ry_tabcommonpanel_alliance:"ui/alliance/ui_ry_tabcommonpanel_alliance",
ui_angel_eq_get_view:"ui/angel_equip_get_ry/ui_angel_eq_get_view",ui_angel_eq_show_item:"ui/angel_equip_get_ry/ui_angel_eq_show_item",
ui_ry_equipadvance_show:"ui/angel_equip_get_ry/ui_ry_equipadvance_show",ui_arena_buynumview_ry:"ui/arena_ry/ui_arena_buynumview_ry",
ui_arena_cleanup_view_ry:"ui/arena_ry/ui_arena_cleanup_view_ry",ui_arena_cleanupitem_ry:"ui/arena_ry/ui_arena_cleanupitem_ry",
ui_arena_damage_view_ry:"ui/arena_ry/ui_arena_damage_view_ry",ui_arena_detail_view_ry:"ui/arena_ry/ui_arena_detail_view_ry",
ui_arena_exitbtn_view:"ui/arena_ry/ui_arena_exitbtn_view",ui_arena_head_hpitem:"ui/arena_ry/ui_arena_head_hpitem",ui_arena_head_l_ry:"ui/arena_ry/ui_arena_head_l_ry",
ui_arena_head_r_ry:"ui/arena_ry/ui_arena_head_r_ry",ui_arena_hisrewarditem_ry:"ui/arena_ry/ui_arena_hisrewarditem_ry",ui_arena_logitem_ry:"ui/arena_ry/ui_arena_logitem_ry",
ui_arena_logview_ry:"ui/arena_ry/ui_arena_logview_ry",ui_arena_result_view_ry:"ui/arena_ry/ui_arena_result_view_ry",
ui_arena_rewarddaliyitem_ry:"ui/arena_ry/ui_arena_rewarddaliyitem_ry",ui_arena_rewarditem_ry:"ui/arena_ry/ui_arena_rewarditem_ry",
ui_arena_rewardview_ry:"ui/arena_ry/ui_arena_rewardview_ry",ui_arena_role_item_ry:"ui/arena_ry/ui_arena_role_item_ry",ui_arena_timer_ry:"ui/arena_ry/ui_arena_timer_ry",
ui_arena_view_ry:"ui/arena_ry/ui_arena_view_ry",ui_attrchangetip_changeattritem:"ui/attrchangetip/ui_attrchangetip_changeattritem",
ui_attrchangetip_excellent:"ui/attrchangetip/ui_attrchangetip_excellent",ui_attrchangetip_tippanel:"ui/attrchangetip/ui_attrchangetip_tippanel",AniTestView1:"ui/bag/AniTestView1",
AniTestitem:"ui/bag/AniTestitem",BagEquipItem:"ui/bag/BagEquipItem",BagView:"ui/bag/BagView",ui_baseitem:"ui/bag/baseitem/ui_baseitem",
ui_baseitem_bag2_module:"ui/bag/baseitem/ui_baseitem_bag2_module",ui_baseitem_bag_module:"ui/bag/baseitem/ui_baseitem_bag_module",
ui_baseitem_base_module:"ui/bag/baseitem/ui_baseitem_base_module",ui_baseitem_bigprize_module:"ui/bag/baseitem/ui_baseitem_bigprize_module",
ui_baseitem_elecarve_module:"ui/bag/baseitem/ui_baseitem_elecarve_module",ui_baseitem_element_module:"ui/bag/baseitem/ui_baseitem_element_module",
ui_baseitem_elementup_module:"ui/bag/baseitem/ui_baseitem_elementup_module",ui_baseitem_equip_module:"ui/bag/baseitem/ui_baseitem_equip_module",
ui_baseitem_equipadvance_select_module:"ui/bag/baseitem/ui_baseitem_equipadvance_select_module",
ui_baseitem_equipstaradvance_select_module:"ui/bag/baseitem/ui_baseitem_equipstaradvance_select_module",ui_baseitem_equipup_module:"ui/bag/baseitem/ui_baseitem_equipup_module",
ui_baseitem_gained_effect_module:"ui/bag/baseitem/ui_baseitem_gained_effect_module",ui_baseitem_get_effect_module:"ui/bag/baseitem/ui_baseitem_get_effect_module",
ui_baseitem_glod_diamond_module:"ui/bag/baseitem/ui_baseitem_glod_diamond_module",ui_baseitem_gray_img_module:"ui/bag/baseitem/ui_baseitem_gray_img_module",
ui_baseitem_leftup_sign_module:"ui/bag/baseitem/ui_baseitem_leftup_sign_module",ui_baseitem_mall_module:"ui/bag/baseitem/ui_baseitem_mall_module",
ui_baseitem_multitimes_module:"ui/bag/baseitem/ui_baseitem_multitimes_module",ui_baseitem_new_module:"ui/bag/baseitem/ui_baseitem_new_module",
ui_baseitem_numberous_module:"ui/bag/baseitem/ui_baseitem_numberous_module",ui_baseitem_reweard_effect_module:"ui/bag/baseitem/ui_baseitem_reweard_effect_module",
ui_baseitem_sell_select_module:"ui/bag/baseitem/ui_baseitem_sell_select_module",ui_baseitem_shape_module:"ui/bag/baseitem/ui_baseitem_shape_module",
ui_baseitem_single_module:"ui/bag/baseitem/ui_baseitem_single_module",ui_baseitem_skilllearn_module:"ui/bag/baseitem/ui_baseitem_skilllearn_module",
ui_baseitem_stagelabel_module:"ui/bag/baseitem/ui_baseitem_stagelabel_module",ui_baseitem_swapeffect_module:"ui/bag/baseitem/ui_baseitem_swapeffect_module",
ui_baseitem_wingrefine_module:"ui/bag/baseitem/ui_baseitem_wingrefine_module",ui_use_drugs_item:"ui/bag/battleusedrugs/ui_use_drugs_item",
ui_use_drugs_view:"ui/bag/battleusedrugs/ui_use_drugs_view",ui_baseModule:"ui/bag/itemtip/comp/ui_baseModule",ui_btns_container:"ui/bag/itemtip/comp/ui_btns_container",
ui_demandModule:"ui/bag/itemtip/comp/ui_demandModule",ui_descChannelObj:"ui/bag/itemtip/comp/ui_descChannelObj",ui_descObj:"ui/bag/itemtip/comp/ui_descObj",
ui_divine_core_active_module:"ui/bag/itemtip/comp/ui_divine_core_active_module",ui_divine_core_skill_module:"ui/bag/itemtip/comp/ui_divine_core_skill_module",
ui_elecarve_topcontainer:"ui/bag/itemtip/comp/ui_elecarve_topcontainer",ui_elecarvetip_demandmodule:"ui/bag/itemtip/comp/ui_elecarvetip_demandmodule",
ui_elementModule:"ui/bag/itemtip/comp/ui_elementModule",ui_element_base_module:"ui/bag/itemtip/comp/ui_element_base_module",
ui_element_topcontainer:"ui/bag/itemtip/comp/ui_element_topcontainer",ui_elementstar_module:"ui/bag/itemtip/comp/ui_elementstar_module",
ui_elementtip_demanditem:"ui/bag/itemtip/comp/ui_elementtip_demanditem",ui_elementtip_demandmodule:"ui/bag/itemtip/comp/ui_elementtip_demandmodule",
ui_elementtip_element_star_attr:"ui/bag/itemtip/comp/ui_elementtip_element_star_attr",ui_elementtip_elementattr:"ui/bag/itemtip/comp/ui_elementtip_elementattr",
ui_equip_demandModule:"ui/bag/itemtip/comp/ui_equip_demandModule",ui_equip_descChannelObj:"ui/bag/itemtip/comp/ui_equip_descChannelObj",
ui_equip_descObj:"ui/bag/itemtip/comp/ui_equip_descObj",ui_equip_skill_module:"ui/bag/itemtip/comp/ui_equip_skill_module",
ui_equip_topcontainer:"ui/bag/itemtip/comp/ui_equip_topcontainer",ui_equiptip_role_icon:"ui/bag/itemtip/comp/ui_equiptip_role_icon",
ui_equiptip_role_icon_list:"ui/bag/itemtip/comp/ui_equiptip_role_icon_list",ui_excellenceModule:"ui/bag/itemtip/comp/ui_excellenceModule",
ui_gem_prop_item:"ui/bag/itemtip/comp/ui_gem_prop_item",ui_gem_prop_module:"ui/bag/itemtip/comp/ui_gem_prop_module",ui_grow_attr_module:"ui/bag/itemtip/comp/ui_grow_attr_module",
ui_horse_baseprop_module:"ui/bag/itemtip/comp/ui_horse_baseprop_module",ui_horse_skill_module:"ui/bag/itemtip/comp/ui_horse_skill_module",
ui_ignoreModule:"ui/bag/itemtip/comp/ui_ignoreModule",ui_inlayModule:"ui/bag/itemtip/comp/ui_inlayModule",ui_legendModule:"ui/bag/itemtip/comp/ui_legendModule",
ui_luckyModule:"ui/bag/itemtip/comp/ui_luckyModule",ui_metagemsModule:"ui/bag/itemtip/comp/ui_metagemsModule",ui_outofprintModule:"ui/bag/itemtip/comp/ui_outofprintModule",
ui_pandoraSelNumModule:"ui/bag/itemtip/comp/ui_pandoraSelNumModule",ui_pandora_reward_item:"ui/bag/itemtip/comp/ui_pandora_reward_item",
ui_pandora_reward_module:"ui/bag/itemtip/comp/ui_pandora_reward_module",ui_pandora_select_num_module:"ui/bag/itemtip/comp/ui_pandora_select_num_module",
ui_pandora_select_tip_module:"ui/bag/itemtip/comp/ui_pandora_select_tip_module",ui_priceObj:"ui/bag/itemtip/comp/ui_priceObj",ui_refineModule:"ui/bag/itemtip/comp/ui_refineModule",
ui_rewardShowObj:"ui/bag/itemtip/comp/ui_rewardShowObj",ui_rewardsObj:"ui/bag/itemtip/comp/ui_rewardsObj",ui_sacred_attr_module:"ui/bag/itemtip/comp/ui_sacred_attr_module",
ui_scroller_container:"ui/bag/itemtip/comp/ui_scroller_container",ui_suitModule:"ui/bag/itemtip/comp/ui_suitModule",ui_timeModule:"ui/bag/itemtip/comp/ui_timeModule",
ui_tiproot:"ui/bag/itemtip/comp/ui_tiproot",ui_top_container:"ui/bag/itemtip/comp/ui_top_container",ui_useLimitModule:"ui/bag/itemtip/comp/ui_useLimitModule",
ui_ry_bag_itemtippanel:"ui/bag/itemtip/ui_ry_bag_itemtippanel",ui_ry_elecarvetip_panel:"ui/bag/itemtip/ui_ry_elecarvetip_panel",
ui_ry_elementtip_panel:"ui/bag/itemtip/ui_ry_elementtip_panel",ui_ry_equiptip_panel:"ui/bag/itemtip/ui_ry_equiptip_panel",
ui_ry_pandoratip_panel:"ui/bag/itemtip/ui_ry_pandoratip_panel",ui_bag_bagexpandalert:"ui/bag/ui_bag_bagexpandalert",ui_bag_bagitem:"ui/bag/ui_bag_bagitem",
ui_bag_baseitem:"ui/bag/ui_bag_baseitem",ui_bag_batchusealert:"ui/bag/ui_bag_batchusealert",ui_bag_itembg:"ui/bag/ui_bag_itembg",ui_bag_leftpart:"ui/bag/ui_bag_leftpart",
ui_bag_materialitem:"ui/bag/ui_bag_materialitem",ui_bag_sell:"ui/bag/ui_bag_sell",ui_bag_sell_simple:"ui/bag/ui_bag_sell_simple",ui_bag_sellitem:"ui/bag/ui_bag_sellitem",
ui_bag_titletippanel:"ui/bag/ui_bag_titletippanel",ui_itemtip_demanditem:"ui/bag/ui_itemtip_demanditem",ui_usehangupitem_view:"ui/bag/ui_usehangupitem_view",
ui_bag_equip_item:"ui/bag_ry/ui_bag_equip_item",ui_bag_view:"ui/bag_ry/ui_bag_view",ui_pandora_select_num_item:"ui/bag_ry/ui_pandora_select_num_item",
ui_pandora_select_panel:"ui/bag_ry/ui_pandora_select_panel",ui_bagextend_panel:"ui/bagextend/ui_bagextend_panel",ui_flyPanel:"ui/bagfly/ui_flyPanel",
ui_flybagItem:"ui/bagfly/ui_flybagItem",ui_battlescoreanime_animepanel:"ui/battlescoreanime/ui_battlescoreanime_animepanel",ui_blank_blankview:"ui/blank/ui_blank_blankview",
ui_boss_boopanel_hp:"ui/boss_ry/ui_boss_boopanel_hp",ui_boss_bosspanel_ry:"ui/boss_ry/ui_boss_bosspanel_ry",ui_boss_buffitem_ry:"ui/boss_ry/ui_boss_buffitem_ry",
ui_boss_buffpanel_ry:"ui/boss_ry/ui_boss_buffpanel_ry",ui_boss_damage_bar:"ui/boss_ry/ui_boss_damage_bar",ui_buff_grid:"ui/buff/ui_buff_grid",
ui_buff_mainview:"ui/buff/ui_buff_mainview",ui_buffer_item:"ui/buff/ui_buffer_item",ui_getbuff_tippanel:"ui/buff/ui_getbuff_tippanel",
ui_tip_captiontipsitem:"ui/captionCommTips/ui_tip_captiontipsitem",ui_tip_captiontipsitem2:"ui/captionCommTips/ui_tip_captiontipsitem2",
ui_tip_commtipsview:"ui/captionCommTips/ui_tip_commtipsview",ui_changejob_detailpanel:"ui/changejob/ui_changejob_detailpanel",
ui_changejob_effectpanel:"ui/changejob/ui_changejob_effectpanel",ui_changejob_mainpanel:"ui/changejob/ui_changejob_mainpanel",
ui_changejob_respanel:"ui/changejob/ui_changejob_respanel",ui_changename_view:"ui/changename/ui_changename_view",CharacterBaseinfoView:"ui/characterui/CharacterBaseinfoView",
CharacterPanel:"ui/characterui/CharacterPanel",ui_charactertab:"ui/characterui/charactertab/ui_charactertab",ui_dropexp_ball:"ui/characterui/dropexp/ui_dropexp_ball",
ui_dropexp_panel:"ui/characterui/dropexp/ui_dropexp_panel",ui_character_extend_head:"ui/characterui/ui_character_extend_head",
ui_character_guard_head:"ui/characterui/ui_character_guard_head",ui_character_hpwarning_panel:"ui/characterui/ui_character_hpwarning_panel",
ui_character_monsterheadcameraui:"ui/characterui/ui_character_monsterheadcameraui",ui_character_monsterheadui:"ui/characterui/ui_character_monsterheadui",
ui_character_newtitleattritem:"ui/characterui/ui_character_newtitleattritem",ui_character_newtitletipview:"ui/characterui/ui_character_newtitletipview",
ui_character_newtotaltip:"ui/characterui/ui_character_newtotaltip",ui_character_npc_head:"ui/characterui/ui_character_npc_head",
ui_character_stallheadview:"ui/characterui/ui_character_stallheadview",ui_character_titleitem:"ui/characterui/ui_character_titleitem",
ui_character_titleview:"ui/characterui/ui_character_titleview",ui_characterhead:"ui/characterui/ui_characterhead",
ui_characterui_baseinfoui:"ui/characterui/ui_characterui_baseinfoui",ui_characterui_characteruipanel:"ui/characterui/ui_characterui_characteruipanel",
ui_characterui_characterview:"ui/characterui/ui_characterui_characterview",ui_characterui_characterview_1:"ui/characterui/ui_characterui_characterview_1",
ui_characterui_correctui:"ui/characterui/ui_characterui_correctui",ui_characterui_detailinfoitem:"ui/characterui/ui_characterui_detailinfoitem",
ui_characterui_detailinfoitem_new:"ui/characterui/ui_characterui_detailinfoitem_new",ui_chariot_head_blank:"ui/characterui/ui_chariot_head_blank",
ui_ry_common_titleitem:"ui/characterui/ui_ry_common_titleitem",ui_chat_channelflag:"ui/chat/phone/ui_chat_channelflag",ui_chat_copytip:"ui/chat/phone/ui_chat_copytip",
ui_chat_crosstotalcell:"ui/chat/phone/ui_chat_crosstotalcell",ui_chat_hornpanel:"ui/chat/phone/ui_chat_hornpanel",ui_chat_personcell:"ui/chat/phone/ui_chat_personcell",
ui_chat_privateBtn:"ui/chat/phone/ui_chat_privateBtn",ui_chat_show_microitem:"ui/chat/phone/ui_chat_show_microitem",ui_chat_showchannelitem:"ui/chat/phone/ui_chat_showchannelitem",
ui_chat_showpanel:"ui/chat/phone/ui_chat_showpanel",ui_chat_simplenotice:"ui/chat/phone/ui_chat_simplenotice",ui_chat_taskcell:"ui/chat/phone/ui_chat_taskcell",
ui_chat_totalcell:"ui/chat/phone/ui_chat_totalcell",ui_chat_voice:"ui/chat/phone/ui_chat_voice",ui_chat_cell:"ui/chat/ui_chat_cell",ui_chat_face:"ui/chat/ui_chat_face",
ui_collect_btn:"ui/collect/ui_collect_btn",ui_collect_head:"ui/collect/ui_collect_head",ui_collect_slider_head:"ui/collect/ui_collect_slider_head",bottomTab:"ui/comm/bottomTab",
ui_comm_buy_tip:"ui/comm/buytip/ui_comm_buy_tip",charactertabRole:"ui/comm/charactertabRole",ui_comm_reward_view:"ui/comm/reward/ui_comm_reward_view",
tabcommonpanel:"ui/comm/tabcommonpanel",ui_button_effect:"ui/comm/ui_button_effect",ui_charactertab_role:"ui/comm/ui_charactertab_role",
ui_comm_btn_close:"ui/comm/ui_comm_btn_close",ui_comm_buyalertpanel:"ui/comm/ui_comm_buyalertpanel",ui_comm_commkilltippanel:"ui/comm/ui_comm_commkilltippanel",
ui_comm_commmenuitem:"ui/comm/ui_comm_commmenuitem",ui_comm_copynpcrefreshpanel:"ui/comm/ui_comm_copynpcrefreshpanel",ui_comm_currency_bar:"ui/comm/ui_comm_currency_bar",
ui_comm_currency_item:"ui/comm/ui_comm_currency_item",ui_comm_flyitem:"ui/comm/ui_comm_flyitem",ui_comm_flyitemview:"ui/comm/ui_comm_flyitemview",
ui_comm_fullscreen_toppanel:"ui/comm/ui_comm_fullscreen_toppanel",ui_comm_fullscreencollider:"ui/comm/ui_comm_fullscreencollider",
ui_comm_fullscreenmask:"ui/comm/ui_comm_fullscreenmask",ui_comm_onetreeitem:"ui/comm/ui_comm_onetreeitem",ui_comm_sprite_head:"ui/comm/ui_comm_sprite_head",
ui_comm_story_loading:"ui/comm/ui_comm_story_loading",ui_comm_texttippanel:"ui/comm/ui_comm_texttippanel",ui_comm_texture_head:"ui/comm/ui_comm_texture_head",
ui_common_getreward_tippanel:"ui/comm/ui_common_getreward_tippanel",ui_common_redpoint:"ui/comm/ui_common_redpoint",ui_common_ruleitem:"ui/comm/ui_common_ruleitem",
ui_drop_down_list:"ui/comm/ui_drop_down_list",ui_drop_down_list_item:"ui/comm/ui_drop_down_list_item",ui_inputnumberpanel:"ui/comm/ui_inputnumberpanel",
ui_policy_view:"ui/comm/ui_policy_view",ui_ry_bottom_tab:"ui/comm/ui_ry_bottom_tab",ui_ry_bottom_tab_2:"ui/comm/ui_ry_bottom_tab_2",
ui_ry_bottom_tab_market:"ui/comm/ui_ry_bottom_tab_market",ui_ry_bottombg:"ui/comm/ui_ry_bottombg",ui_ry_right_tab:"ui/comm/ui_ry_right_tab",
ui_ry_right_tab2:"ui/comm/ui_ry_right_tab2",ui_ry_right_tab3:"ui/comm/ui_ry_right_tab3",ui_ry_right_tab3_1:"ui/comm/ui_ry_right_tab3_1",ui_ry_right_tab5:"ui/comm/ui_ry_right_tab5",
ui_ry_right_tab_4:"ui/comm/ui_ry_right_tab_4",ui_ry_right_tab_new:"ui/comm/ui_ry_right_tab_new",ui_ry_tabcommonpanel:"ui/comm/ui_ry_tabcommonpanel",
ui_ry_tabcommonpanel_custom:"ui/comm/ui_ry_tabcommonpanel_custom",ui_ry_tabcommonpanel_nocharacter:"ui/comm/ui_ry_tabcommonpanel_nocharacter",
ui_ry_tabcommonpanel_scrollright:"ui/comm/ui_ry_tabcommonpanel_scrollright",ui_ry_tabcommonpanel_sign:"ui/comm/ui_ry_tabcommonpanel_sign",
ui_commonhint_hintpanel:"ui/commonhint/ui_commonhint_hintpanel",ui_alliancecopy_beginfire_ry:"ui/copybaseui/ryalliancecopy/ui_alliancecopy_beginfire_ry",
ui_alliancecopy_bornfire_ry:"ui/copybaseui/ryalliancecopy/ui_alliancecopy_bornfire_ry",ui_alliancecopy_chuangong_ry:"ui/copybaseui/ryalliancecopy/ui_alliancecopy_chuangong_ry",
ui_alliancecopy_headitem:"ui/copybaseui/ryalliancecopy/ui_alliancecopy_headitem",
ui_alliancecopy_submitfire_confirm:"ui/copybaseui/ryalliancecopy/ui_alliancecopy_submitfire_confirm",
ui_alliancecopy_submitfire_ry:"ui/copybaseui/ryalliancecopy/ui_alliancecopy_submitfire_ry",ui_copybaseui_fireitem:"ui/copybaseui/ryalliancecopy/ui_copybaseui_fireitem",
ui_alliancecopy_task_ry:"ui/copybaseui/ui_alliancecopy_task_ry",ui_copybase_bloodtown_lefttime:"ui/copybaseui/ui_copybase_bloodtown_lefttime",
ui_copybase_bloodtownetrace:"ui/copybaseui/ui_copybase_bloodtownetrace",ui_copybase_bloodtownresult_ry:"ui/copybaseui/ui_copybase_bloodtownresult_ry",
ui_copybase_gainview:"ui/copybaseui/ui_copybase_gainview",ui_copybase_lefttime:"ui/copybaseui/ui_copybase_lefttime",
ui_copybaseui_alliance_task_successpanel:"ui/copybaseui/ui_copybaseui_alliance_task_successpanel",
ui_copybaseui_asuramtasktrace_panel:"ui/copybaseui/ui_copybaseui_asuramtasktrace_panel",ui_copybaseui_belialpanel:"ui/copybaseui/ui_copybaseui_belialpanel",
ui_copybaseui_belialsquareresult_ry:"ui/copybaseui/ui_copybaseui_belialsquareresult_ry",ui_copybaseui_belielexp_item:"ui/copybaseui/ui_copybaseui_belielexp_item",
ui_copybaseui_belielexp_panel:"ui/copybaseui/ui_copybaseui_belielexp_panel",ui_copybaseui_belielexpbuy_panel:"ui/copybaseui/ui_copybaseui_belielexpbuy_panel",
ui_copybaseui_commonrightview:"ui/copybaseui/ui_copybaseui_commonrightview",ui_copybaseui_copyentertimer:"ui/copybaseui/ui_copybaseui_copyentertimer",
ui_copybaseui_copyinspirepanel:"ui/copybaseui/ui_copybaseui_copyinspirepanel",ui_copybaseui_copysoonendtime:"ui/copybaseui/ui_copybaseui_copysoonendtime",
ui_copybaseui_defeatpanel:"ui/copybaseui/ui_copybaseui_defeatpanel",ui_copybaseui_duntimer:"ui/copybaseui/ui_copybaseui_duntimer",
ui_copybaseui_fail_panel_ry:"ui/copybaseui/ui_copybaseui_fail_panel_ry",ui_copybaseui_inspirepanel:"ui/copybaseui/ui_copybaseui_inspirepanel",
ui_copybaseui_mapfail_panel:"ui/copybaseui/ui_copybaseui_mapfail_panel",ui_copybaseui_slowdowntippanel:"ui/copybaseui/ui_copybaseui_slowdowntippanel",
ui_copybaseui_successpanel:"ui/copybaseui/ui_copybaseui_successpanel",ui_copybaseui_sweeppanel_ry:"ui/copybaseui/ui_copybaseui_sweeppanel_ry",
ui_ry_copyentrance_panel:"ui/copypanel/copyentrance/ui_ry_copyentrance_panel",ui_copypanel_bloodtown:"ui/copypanel/ui_copypanel_bloodtown",
ui_copypanel_bloodtown_item:"ui/copypanel/ui_copypanel_bloodtown_item",ui_copypanel_bloodtown_rankitem_ry:"ui/copypanel/ui_copypanel_bloodtown_rankitem_ry",
ui_copypanel_bloodtown_rankview_ry:"ui/copypanel/ui_copypanel_bloodtown_rankview_ry",ui_crossboss_recorditem_ry:"ui/crossbattle/ui_crossboss_recorditem_ry",
ui_crossboss_statusview_ry:"ui/crossbattle/ui_crossboss_statusview_ry",ui_crossboss_usebadgeview:"ui/crossbattle/ui_crossboss_usebadgeview",
ui_crossbossview_ry:"ui/crossbattle/ui_crossbossview_ry",ui_ry_tabcommonpanel_crossbattle:"ui/crossbattle/ui_ry_tabcommonpanel_crossbattle",
ui_activity_calendar_mainview:"ui/daily_ry/ui_activity_calendar_mainview",ui_becomestronger_item:"ui/daily_ry/ui_becomestronger_item",
ui_becomestronger_mainview:"ui/daily_ry/ui_becomestronger_mainview",ui_daily_CopyView:"ui/daily_ry/ui_daily_CopyView",ui_daily_GetRewardItem:"ui/daily_ry/ui_daily_GetRewardItem",
ui_daily_GetRewardView:"ui/daily_ry/ui_daily_GetRewardView",ui_daily_TaskView:"ui/daily_ry/ui_daily_TaskView",ui_daily_panel:"ui/daily_ry/ui_daily_panel",
ui_daily_taskItem:"ui/daily_ry/ui_daily_taskItem",ui_daily_task_info:"ui/daily_ry/ui_daily_task_info",ui_belialsquare_item:"ui/dialogue/BelialPanel/ui_belialsquare_item",
ui_belialsquare_view:"ui/dialogue/BelialPanel/ui_belialsquare_view",ui_dialogue_funbtn:"ui/dialogue/ui_dialogue_funbtn",
ui_dialogue_handinpanel:"ui/dialogue/ui_dialogue_handinpanel",ui_dialogue_mianpanel:"ui/dialogue/ui_dialogue_mianpanel",ui_dialogue_robotpanel:"ui/dialogue/ui_dialogue_robotpanel",
ui_buy_discountgoods_panel:"ui/discountgoods/ui_buy_discountgoods_panel",ui_discountgoods_mainview:"ui/discountgoods/ui_discountgoods_mainview",
ui_discountgoods_pageitem:"ui/discountgoods/ui_discountgoods_pageitem",ui_discountgoods_tab:"ui/discountgoods/ui_discountgoods_tab",
ui_divine_activeview:"ui/divine/ui_divine_activeview",ui_divine_attr_item:"ui/divine/ui_divine_attr_item",ui_divine_code_hole:"ui/divine/ui_divine_code_hole",
ui_divine_code_hole_eff1:"ui/divine/ui_divine_code_hole_eff1",ui_divine_code_hole_eff2:"ui/divine/ui_divine_code_hole_eff2",
ui_divine_code_hole_eff3:"ui/divine/ui_divine_code_hole_eff3",ui_divine_code_line:"ui/divine/ui_divine_code_line",ui_divine_code_property:"ui/divine/ui_divine_code_property",
ui_divine_code_suit_item:"ui/divine/ui_divine_code_suit_item",ui_divine_code_view:"ui/divine/ui_divine_code_view",ui_divine_eff1:"ui/divine/ui_divine_eff1",
ui_divine_eff2:"ui/divine/ui_divine_eff2",ui_divine_eff3:"ui/divine/ui_divine_eff3",ui_divine_eff4:"ui/divine/ui_divine_eff4",
ui_divine_eff_skill_eff_ry:"ui/divine/ui_divine_eff_skill_eff_ry",ui_divine_item:"ui/divine/ui_divine_item",ui_divine_location_item:"ui/divine/ui_divine_location_item",
ui_divine_panel:"ui/divine/ui_divine_panel",ui_divine_property_item:"ui/divine/ui_divine_property_item",ui_ry_divine_skilltipview:"ui/divine/ui_ry_divine_skilltipview",
ui_dun_access_item:"ui/dun/ui_dun_access_item",ui_dun_exp_item:"ui/dun/ui_dun_exp_item",ui_dun_exp_view:"ui/dun/ui_dun_exp_view",ui_v1p_buytippanel:"ui/dun/ui_v1p_buytippanel",
ui_v1p_levelcell_ry:"ui/dun/ui_v1p_levelcell_ry",ui_v1p_panel_ry:"ui/dun/ui_v1p_panel_ry",ui_v1p_powertxtcell_ry:"ui/dun/ui_v1p_powertxtcell_ry",
ui_v1p_powertxtcellitem_ry:"ui/dun/ui_v1p_powertxtcellitem_ry",ui_v1p_rewardedcell:"ui/dun/ui_v1p_rewardedcell",ui_v1p_upgradepanel_ry:"ui/dun/ui_v1p_upgradepanel_ry",
skill_test:"ui/effectshoweditor/skill_test",ui_effectshoweditor_effectshowEditor:"ui/effectshoweditor/ui_effectshoweditor_effectshowEditor",
ui_effectshoweditor_effectshowItem:"ui/effectshoweditor/ui_effectshoweditor_effectshowItem",ui_efficiency_efficiencyitem_ry:"ui/efficiency/ui_efficiency_efficiencyitem_ry",
ui_efficiency_efficiencypanel_ry:"ui/efficiency/ui_efficiency_efficiencypanel_ry",ui_efficiency_expdrugpanel_ry:"ui/efficiency/ui_efficiency_expdrugpanel_ry",
ui_efficiency_tippanel_ry:"ui/efficiency/ui_efficiency_tippanel_ry",ui_elecaeve_resetview:"ui/element/elecarve/ui_elecaeve_resetview",
ui_elecarve_addview:"ui/element/elecarve/ui_elecarve_addview",ui_elecarve_bagview:"ui/element/elecarve/ui_elecarve_bagview",
ui_elecarve_bagview_item:"ui/element/elecarve/ui_elecarve_bagview_item",ui_elecarve_bagview_popitem:"ui/element/elecarve/ui_elecarve_bagview_popitem",
ui_elecarve_bagview_poplis:"ui/element/elecarve/ui_elecarve_bagview_poplis",ui_elecarve_echoactive_view:"ui/element/elecarve/ui_elecarve_echoactive_view",
ui_elecarve_echoattritem:"ui/element/elecarve/ui_elecarve_echoattritem",ui_elecarve_echoattritem1:"ui/element/elecarve/ui_elecarve_echoattritem1",
ui_elecarve_echoitem:"ui/element/elecarve/ui_elecarve_echoitem",ui_elecarve_echosimple_point:"ui/element/elecarve/ui_elecarve_echosimple_point",
ui_elecarve_echoupattr:"ui/element/elecarve/ui_elecarve_echoupattr",ui_elecarve_echoview:"ui/element/elecarve/ui_elecarve_echoview",
ui_elecarve_listitem:"ui/element/elecarve/ui_elecarve_listitem",ui_elecarve_listitemhold:"ui/element/elecarve/ui_elecarve_listitemhold",
ui_elecarve_midhold:"ui/element/elecarve/ui_elecarve_midhold",ui_elecarve_simple_echotype:"ui/element/elecarve/ui_elecarve_simple_echotype",
ui_elecarve_successattr:"ui/element/elecarve/ui_elecarve_successattr",ui_elecarve_successview:"ui/element/elecarve/ui_elecarve_successview",
ui_elecarve_view:"ui/element/elecarve/ui_elecarve_view",ui_elecarve_viewattritem:"ui/element/elecarve/ui_elecarve_viewattritem",
ui_ele_elecompound_item:"ui/element/elecompound/ui_ele_elecompound_item",ui_ele_elecompound_matitem:"ui/element/elecompound/ui_ele_elecompound_matitem",
ui_ele_elecompound_tabitem:"ui/element/elecompound/ui_ele_elecompound_tabitem",ui_ele_elecompound_tabsubitem:"ui/element/elecompound/ui_ele_elecompound_tabsubitem",
ui_ele_elecompound_view:"ui/element/elecompound/ui_ele_elecompound_view",ui_elecompound_bagview:"ui/element/elecompound/ui_elecompound_bagview",
ui_elecompoundsuccess:"ui/element/elecompound/ui_elecompoundsuccess",ui_elecompoundsuccess_attr:"ui/element/elecompound/ui_elecompoundsuccess_attr",
ui_element_enhance_effobj:"ui/element/enhance/ui_element_enhance_effobj",ui_element_enhance_view:"ui/element/enhance/ui_element_enhance_view",
ui_element_enhanceattr_item:"ui/element/enhance/ui_element_enhanceattr_item",ui_element_enhancebag_item:"ui/element/enhance/ui_element_enhancebag_item",
ui_element_enhancebag_popitem:"ui/element/enhance/ui_element_enhancebag_popitem",ui_element_enhancebag_poplis:"ui/element/enhance/ui_element_enhancebag_poplis",
ui_element_enhancebag_view:"ui/element/enhance/ui_element_enhancebag_view",ui_element_enhancecostitem_item:"ui/element/enhance/ui_element_enhancecostitem_item",
ui_element_element_starlis:"ui/element/ui_element_element_starlis",ui_ry_element_bag_tab:"ui/element/ui_ry_element_bag_tab",
ui_ry_element_bag_view:"ui/element/ui_ry_element_bag_view",ui_ry_element_circle_attr_item:"ui/element/ui_ry_element_circle_attr_item",
ui_ry_element_circle_showup_view:"ui/element/ui_ry_element_circle_showup_view",ui_ry_element_circle_skillItem:"ui/element/ui_ry_element_circle_skillItem",
ui_ry_element_circle_star_item:"ui/element/ui_ry_element_circle_star_item",ui_ry_element_circle_view:"ui/element/ui_ry_element_circle_view",
ui_ry_element_hold_item:"ui/element/ui_ry_element_hold_item",ui_ry_element_hold_list_view:"ui/element/ui_ry_element_hold_list_view",
ui_ry_element_itembg:"ui/element/ui_ry_element_itembg",ui_ry_element_main_view:"ui/element/ui_ry_element_main_view",
ui_ry_element_star_fly_item:"ui/element/ui_ry_element_star_fly_item",ui_ry_element_star_item:"ui/element/ui_ry_element_star_item",
ui_equipenhance_property:"ui/equipenhance/ui_equipenhance_property",ui_equipenhance_property_success:"ui/equipenhance/ui_equipenhance_property_success",
ui_forge_luck_property_ry:"ui/equipenhance/ui_forge_luck_property_ry",ui_equip_star_item:"ui/equiptip/ui_equip_star_item",ui_equiptip_boardtip:"ui/equiptip/ui_equiptip_boardtip",
ui_equiptip_commonattr:"ui/equiptip/ui_equiptip_commonattr",ui_equiptip_commonattrhasstar:"ui/equiptip/ui_equiptip_commonattrhasstar",
ui_equiptip_demanditem:"ui/equiptip/ui_equiptip_demanditem",ui_equiptip_elementattr:"ui/equiptip/ui_equiptip_elementattr",
ui_equiptip_excellenceattr:"ui/equiptip/ui_equiptip_excellenceattr",ui_equiptip_extendbtn:"ui/equiptip/ui_equiptip_extendbtn",
ui_equiptip_metagemsattr:"ui/equiptip/ui_equiptip_metagemsattr",ui_equiptip_outoff_attr:"ui/equiptip/ui_equiptip_outoff_attr",
ui_equiptip_refineattr:"ui/equiptip/ui_equiptip_refineattr",ui_equiptip_roleicon:"ui/equiptip/ui_equiptip_roleicon",ui_equiptip_selectcolumn:"ui/equiptip/ui_equiptip_selectcolumn",
ui_equiptip_specialattr:"ui/equiptip/ui_equiptip_specialattr",ui_equiptip_suit_legendattr:"ui/equiptip/ui_equiptip_suit_legendattr",
ui_equiptip_suitattr:"ui/equiptip/ui_equiptip_suitattr",ui_equiptip_suitattritem:"ui/equiptip/ui_equiptip_suitattritem",ui_simple_attr_item:"ui/equiptip/ui_simple_attr_item",
ui_excalibur_view_ry:"ui/excalibur/ui_excalibur_view_ry",ui_excscroll_bigitem:"ui/excscroll/ui_excscroll_bigitem",ui_excscroll_getpanel:"ui/excscroll/ui_excscroll_getpanel",
ui_excscroll_item:"ui/excscroll/ui_excscroll_item",ui_excscroll_panel:"ui/excscroll/ui_excscroll_panel",
ui_exorcism_copy_buffselectitem_ry:"ui/exorcism_ry/ui_exorcism_copy_buffselectitem_ry",ui_exorcism_copy_buffselectview_ry:"ui/exorcism_ry/ui_exorcism_copy_buffselectview_ry",
ui_exorcism_copy_result_item:"ui/exorcism_ry/ui_exorcism_copy_result_item",ui_exorcism_copy_resultview_ry:"ui/exorcism_ry/ui_exorcism_copy_resultview_ry",
ui_exorcism_copy_traceview_ry:"ui/exorcism_ry/ui_exorcism_copy_traceview_ry",ui_exorcism_rewardshowview_ry:"ui/exorcism_ry/ui_exorcism_rewardshowview_ry",
ui_exorcism_totalrewardview_ry:"ui/exorcism_ry/ui_exorcism_totalrewardview_ry",ui_ry_element_circle_des_item:"ui/exorcism_ry/ui_ry_element_circle_des_item",
ui_exorcism_badgeeffect_item:"ui/exorcismmain/ui_exorcism_badgeeffect_item",ui_exorcism_badgeeffect_panel:"ui/exorcismmain/ui_exorcism_badgeeffect_panel",
ui_exorcism_main_panel:"ui/exorcismmain/ui_exorcism_main_panel",ui_exorcism_main_view:"ui/exorcismmain/ui_exorcism_main_view",
ui_exorcism_mainlayer_item:"ui/exorcismmain/ui_exorcism_mainlayer_item",ui_exorcism_mainrank_item:"ui/exorcismmain/ui_exorcism_mainrank_item",
ui_exorcism_rankreward_item:"ui/exorcismmain/ui_exorcism_rankreward_item",ui_exorcism_rankreward_panel:"ui/exorcismmain/ui_exorcism_rankreward_panel",
ui_exorcism_rankreward_roleitem:"ui/exorcismmain/ui_exorcism_rankreward_roleitem",ui_expire_baseitem:"ui/expiretip/ui_expire_baseitem",
ui_expire_btn_view:"ui/expiretip/ui_expire_btn_view",ui_expire_tip_view:"ui/expiretip/ui_expire_tip_view",ui_fasterFight_levelup_eff:"ui/fasterFight/ui_fasterFight_levelup_eff",
ui_fasterFight_ry:"ui/fasterFight/ui_fasterFight_ry",ui_level_slider_ry:"ui/fasterFight/ui_level_slider_ry",ui_firstcharge_item:"ui/firstcharge/ui_firstcharge_item",
ui_firstcharge_mainpanel:"ui/firstcharge/ui_firstcharge_mainpanel",ui_ryfirstcharge_rewardpanel:"ui/firstcharge/ui_ryfirstcharge_rewardpanel",
ui_ryfirstcharge_successpanel:"ui/firstcharge/ui_ryfirstcharge_successpanel",ui_ry_flow_point_eff:"ui/flypointeff/ui_ry_flow_point_eff",
ui_ry_fly_eff_panel:"ui/flypointeff/ui_ry_fly_eff_panel",ui_compound_treeitem:"ui/forge/ui_compound_treeitem",ui_compound_treetitleitem:"ui/forge/ui_compound_treetitleitem",
ui_enhance_excellentadditionmatergrid:"ui/forge/ui_enhance_excellentadditionmatergrid",ui_equiptransfer_tipview:"ui/forge/ui_equiptransfer_tipview",
ui_forge_equipmaster_propertyblock:"ui/forge/ui_forge_equipmaster_propertyblock",ui_forge_equipmaster_propertyitem:"ui/forge/ui_forge_equipmaster_propertyitem",
ui_forge_equipmasterview:"ui/forge/ui_forge_equipmasterview",ui_forge_luckypanel:"ui/forge/ui_forge_luckypanel",ui_forge_luckyproperty:"ui/forge/ui_forge_luckyproperty",
ui_fortune_fatebox_item:"ui/fortunetreasure/ui_fortune_fatebox_item",ui_fortune_fateresure_resultpanel:"ui/fortunetreasure/ui_fortune_fateresure_resultpanel",
ui_fortune_fateturn_item:"ui/fortunetreasure/ui_fortune_fateturn_item",ui_fortune_raremerchant_item:"ui/fortunetreasure/ui_fortune_raremerchant_item",
ui_fortune_raremerchant_panel:"ui/fortunetreasure/ui_fortune_raremerchant_panel",ui_fortune_round_tips:"ui/fortunetreasure/ui_fortune_round_tips",
ui_fortunelimit_item:"ui/fortunetreasure/ui_fortunelimit_item",ui_fortunelimit_view:"ui/fortunetreasure/ui_fortunelimit_view",
ui_fortunetreasure_item:"ui/fortunetreasure/ui_fortunetreasure_item",ui_fortunetreasure_panel:"ui/fortunetreasure/ui_fortunetreasure_panel",
ui_ry_fortune_fatetreasure_view:"ui/fortunetreasure/ui_ry_fortune_fatetreasure_view",ui_ry_fortune_integral_item:"ui/fortunetreasure/ui_ry_fortune_integral_item",
ui_ry_fortune_integral_view:"ui/fortunetreasure/ui_ry_fortune_integral_view",ui_fruit_item:"ui/fruit/ui_fruit_item",ui_fruit_panel:"ui/fruit/ui_fruit_panel",
ui_funcopenitem:"ui/functionopen/ui_funcopenitem",ui_funcopenitem_texobj:"ui/functionopen/ui_funcopenitem_texobj",
ui_functionopen_animepanel:"ui/functionopen/ui_functionopen_animepanel",ui_functionopen_leftspreaditem:"ui/functionopen/ui_functionopen_leftspreaditem",
ui_functionopen_pkfuncitem:"ui/functionopen/ui_functionopen_pkfuncitem",ui_functionopen_spreaditem:"ui/functionopen/ui_functionopen_spreaditem",
ui_functionopen_spreaditem2:"ui/functionopen/ui_functionopen_spreaditem2",ui_prenotice_listitem:"ui/functionprenotice/ui_prenotice_listitem",
ui_prenotice_listpanel:"ui/functionprenotice/ui_prenotice_listpanel",ui_game_gm_combox:"ui/gamegm_ry/component/ui_game_gm_combox",
ui_game_gm_combox_item:"ui/gamegm_ry/component/ui_game_gm_combox_item",ui_game_gm_reward_comp:"ui/gamegm_ry/component/ui_game_gm_reward_comp",
ui_game_gm_switch:"ui/gamegm_ry/component/ui_game_gm_switch",ui_game_gm_text_combox:"ui/gamegm_ry/component/ui_game_gm_text_combox",
ui_game_gm_tog:"ui/gamegm_ry/component/ui_game_gm_tog",ui_game_gm_tog_switch:"ui/gamegm_ry/component/ui_game_gm_tog_switch",
ui_game_gm_auto_exe_view:"ui/gamegm_ry/subview/auto/ui_game_gm_auto_exe_view",ui_game_gm_auto_hook_comp:"ui/gamegm_ry/subview/auto/ui_game_gm_auto_hook_comp",
ui_game_gm_auto_paodian_comp:"ui/gamegm_ry/subview/auto/ui_game_gm_auto_paodian_comp",ui_game_gm_auto_pass_point:"ui/gamegm_ry/subview/auto/ui_game_gm_auto_pass_point",
ui_game_gm_auto_view:"ui/gamegm_ry/subview/auto/ui_game_gm_auto_view",ui_game_gm_bountytask_comp:"ui/gamegm_ry/subview/auto/ui_game_gm_bountytask_comp",
ui_game_gm_createrole_icon:"ui/gamegm_ry/subview/createrole/ui_game_gm_createrole_icon",
ui_game_gm_createrole_select_panel:"ui/gamegm_ry/subview/createrole/ui_game_gm_createrole_select_panel",
ui_game_gm_createrole_skill_icon:"ui/gamegm_ry/subview/createrole/ui_game_gm_createrole_skill_icon",
ui_game_gm_createrole_view:"ui/gamegm_ry/subview/createrole/ui_game_gm_createrole_view",
ui_game_gm_equip_exc_combox_item:"ui/gamegm_ry/subview/equipexc/ui_game_gm_equip_exc_combox_item",
ui_game_gm_equip_exc_item:"ui/gamegm_ry/subview/equipexc/ui_game_gm_equip_exc_item",ui_game_gm_equip_exc_view:"ui/gamegm_ry/subview/equipexc/ui_game_gm_equip_exc_view",
ui_game_gm_equip_show_item:"ui/gamegm_ry/subview/equipunlock/ui_game_gm_equip_show_item",
ui_game_gm_equip_unlock_item:"ui/gamegm_ry/subview/equipunlock/ui_game_gm_equip_unlock_item",
ui_game_gm_equip_unlock_view:"ui/gamegm_ry/subview/equipunlock/ui_game_gm_equip_unlock_view",ui_gem_attr_item:"ui/gem/ui_gem_attr_item",
ui_gem_attr_item2:"ui/gem/ui_gem_attr_item2",ui_gem_gemop:"ui/gem/ui_gem_gemop",ui_gem_hole_max_item:"ui/gem/ui_gem_hole_max_item",
ui_gem_hole_min_item:"ui/gem/ui_gem_hole_min_item",ui_gem_master_item:"ui/gem/ui_gem_master_item",ui_gem_master_view:"ui/gem/ui_gem_master_view",
ui_gem_part_item:"ui/gem/ui_gem_part_item",ui_gem_preview_item:"ui/gem/ui_gem_preview_item",ui_gem_select_item:"ui/gem/ui_gem_select_item",
ui_gem_select_view:"ui/gem/ui_gem_select_view",ui_gem_totalProperty:"ui/gem/ui_gem_totalProperty",ui_gem_view:"ui/gem/ui_gem_view",
ui_getexptips_item:"ui/getexptips/ui_getexptips_item",ui_getexptips_panel:"ui/getexptips/ui_getexptips_panel",ui_element_printpanel:"ui/gm/ui_element_printpanel",
ui_gm_gmbtn:"ui/gm/ui_gm_gmbtn",ui_gm_gmpanel:"ui/gm/ui_gm_gmpanel",ui_gm_imageItem:"ui/gm/ui_gm_imageItem",ui_gm_minigmpanel:"ui/gm/ui_gm_minigmpanel",
ui_gm_searchitem:"ui/gm/ui_gm_searchitem",ui_gm_sonTabBtn:"ui/gm/ui_gm_sonTabBtn","01":"ui/godsuitroad/01",ui_godsuitroad_item:"ui/godsuitroad/ui_godsuitroad_item",
ui_godsuitroad_mainpanel:"ui/godsuitroad/ui_godsuitroad_mainpanel",ui_goldspawn_addtime:"ui/goldspawn/ui_goldspawn_addtime",
ui_goldspawn_defense:"ui/goldspawn/ui_goldspawn_defense",ui_goldspawn_mapListitem:"ui/goldspawn/ui_goldspawn_mapListitem",
ui_goldspawn_map_icon:"ui/goldspawn/ui_goldspawn_map_icon",ui_goldspawn_map_item:"ui/goldspawn/ui_goldspawn_map_item",
ui_goldspawn_map_item_t:"ui/goldspawn/ui_goldspawn_map_item_t",ui_goldspawn_monster_tip:"ui/goldspawn/ui_goldspawn_monster_tip",
ui_goldspawn_out_result:"ui/goldspawn/ui_goldspawn_out_result",ui_goldspawn_panel:"ui/goldspawn/ui_goldspawn_panel",
ui_goldspawn_remaind_time:"ui/goldspawn/ui_goldspawn_remaind_time",ui_goldspawn_result:"ui/goldspawn/ui_goldspawn_result",ui_goldspwan_mainR:"ui/goldspawn/ui_goldspwan_mainR",
ui_goldspwan_mainR_item:"ui/goldspawn/ui_goldspwan_mainR_item",AlertTestV:"ui/gui/AlertTestV",AlertV:"ui/gui/AlertV",ui_guide_effect:"ui/guide/ui_guide_effect",
ui_guide_roundeffect:"ui/guide/ui_guide_roundeffect",ui_guide_view:"ui/guide/ui_guide_view",ui_handinitem_view:"ui/handin/ui_handinitem_view",
ui_handexpup_tip_view:"ui/hang/ui_handexpup_tip_view",ui_hang_recommend:"ui/hang/ui_hang_recommend",ui_hang_selectskillpanel:"ui/hang/ui_hang_selectskillpanel",
ui_hang_sreenicon:"ui/hang/ui_hang_sreenicon",ui_hang_stopicon:"ui/hang/ui_hang_stopicon",ui_honorkings_attachitem:"ui/honorkings/ui_honorkings_attachitem",
ui_honorkings_attachview:"ui/honorkings/ui_honorkings_attachview",ui_honorkings_mainpanel:"ui/honorkings/ui_honorkings_mainpanel",
ui_honorkings_myrankitem:"ui/honorkings/ui_honorkings_myrankitem",ui_honorkings_phasegriditem:"ui/honorkings/ui_honorkings_phasegriditem",
ui_honorkings_phasetitleitem:"ui/honorkings/ui_honorkings_phasetitleitem",ui_honorkings_rankitem:"ui/honorkings/ui_honorkings_rankitem",
ui_honorkings_rankview:"ui/honorkings/ui_honorkings_rankview",ui_honorkings_tab:"ui/honorkings/ui_honorkings_tab",ui_honortrib_item:"ui/honortrib/ui_honortrib_item",
ui_honortrib_result_view:"ui/honortrib/ui_honortrib_result_view",ui_honortrib_view:"ui/honortrib/ui_honortrib_view",ui_bag_horse_skill_item:"ui/horse/ui_bag_horse_skill_item",
ui_bag_horsetippanel:"ui/horse/ui_bag_horsetippanel",ui_bag_tipBtn:"ui/horse/ui_bag_tipBtn",ui_horse_attcell:"ui/horse/ui_horse_attcell",
ui_horse_basepanel:"ui/horse/ui_horse_basepanel",ui_horse_dress_item:"ui/horse/ui_horse_dress_item",ui_horse_dresspanel:"ui/horse/ui_horse_dresspanel",
ui_horse_item:"ui/horse/ui_horse_item",ui_horse_mainview:"ui/horse/ui_horse_mainview",ui_horse_riding_attritem:"ui/horse/ui_horse_riding_attritem",
ui_horse_riding_cost_item:"ui/horse/ui_horse_riding_cost_item",ui_horse_riding_item:"ui/horse/ui_horse_riding_item",ui_horse_riding_itemGroup:"ui/horse/ui_horse_riding_itemGroup",
ui_horse_ridingview:"ui/horse/ui_horse_ridingview",ui_horse_select_item:"ui/horse/ui_horse_select_item",ui_horse_selectpanel:"ui/horse/ui_horse_selectpanel",
ui_horse_skill_item:"ui/horse/ui_horse_skill_item",ui_horse_skill_mainview:"ui/horse/ui_horse_skill_mainview",ui_horse_skill_mainview_item:"ui/horse/ui_horse_skill_mainview_item",
ui_horse_skilltipview:"ui/horse/ui_horse_skilltipview",ui_horse_tips_left_part:"ui/horse/ui_horse_tips_left_part",ui_horse_up_panel:"ui/horse/ui_horse_up_panel",
ui_horseskill_new_ry:"ui/horse/ui_horseskill_new_ry",ui_rechargebytester_view:"ui/huodong_ry/ReChargeByTester/ui_rechargebytester_view",
ui_dragon_buyitem:"ui/huodong_ry/dragontreasure/ui_dragon_buyitem",ui_dragon_shopview:"ui/huodong_ry/dragontreasure/ui_dragon_shopview",
ui_dragontreasure_currencyitem:"ui/huodong_ry/dragontreasure/ui_dragontreasure_currencyitem",
ui_dragontreasure_main_shopitem:"ui/huodong_ry/dragontreasure/ui_dragontreasure_main_shopitem",
ui_dragontreasure_mainpanel:"ui/huodong_ry/dragontreasure/ui_dragontreasure_mainpanel",ui_dragontreasure_openitem:"ui/huodong_ry/dragontreasure/ui_dragontreasure_openitem",
ui_dragontreasure_panel:"ui/huodong_ry/dragontreasure/ui_dragontreasure_panel",ui_dragontreasure_rareshop_panel:"ui/huodong_ry/dragontreasure/ui_dragontreasure_rareshop_panel",
ui_dragontreasure_result_panel:"ui/huodong_ry/dragontreasure/ui_dragontreasure_result_panel",
ui_dragontreasure_rewarditem:"ui/huodong_ry/dragontreasure/ui_dragontreasure_rewarditem",
ui_dragontreasure_rewardpool_item:"ui/huodong_ry/dragontreasure/ui_dragontreasure_rewardpool_item",
ui_dragontreasure_rewardpool_panel:"ui/huodong_ry/dragontreasure/ui_dragontreasure_rewardpool_panel",
ui_dragontreasure_shopitem:"ui/huodong_ry/dragontreasure/ui_dragontreasure_shopitem",ui_dragontreasure_shoppanel:"ui/huodong_ry/dragontreasure/ui_dragontreasure_shoppanel",
ui_dragontreasure_timeitem:"ui/huodong_ry/dragontreasure/ui_dragontreasure_timeitem",
ui_dragontreasure_treasureshop_view:"ui/huodong_ry/dragontreasure/ui_dragontreasure_treasureshop_view",
ui_dragontreasure_treasureshopitem:"ui/huodong_ry/dragontreasure/ui_dragontreasure_treasureshopitem",
ui_drogonbuytip_iconitem:"ui/huodong_ry/dragontreasure/ui_drogonbuytip_iconitem",ui_glorycallexchangeitem:"ui/huodong_ry/glorycall/ui_glorycallexchangeitem",
ui_glorycallitem:"ui/huodong_ry/glorycall/ui_glorycallitem",ui_glorycallmainview:"ui/huodong_ry/glorycall/ui_glorycallmainview",
ui_glorycallresultview:"ui/huodong_ry/glorycall/ui_glorycallresultview",ui_glorycallrootview:"ui/huodong_ry/glorycall/ui_glorycallrootview",
ui_openservergrab_accesspanel:"ui/huodong_ry/openservergrab/ui_openservergrab_accesspanel",ui_openservergrab_mall_item:"ui/huodong_ry/openservergrab/ui_openservergrab_mall_item",
ui_openservergrab_mall_self_item:"ui/huodong_ry/openservergrab/ui_openservergrab_mall_self_item",
ui_openservergrab_mallitem:"ui/huodong_ry/openservergrab/ui_openservergrab_mallitem",ui_openservergrab_quest_item:"ui/huodong_ry/openservergrab/ui_openservergrab_quest_item",
ui_openservergrab_quest_item1:"ui/huodong_ry/openservergrab/ui_openservergrab_quest_item1",ui_openservergrab_quest_view:"ui/huodong_ry/openservergrab/ui_openservergrab_quest_view",
ui_openservergrab_rank_item:"ui/huodong_ry/openservergrab/ui_openservergrab_rank_item",ui_openservergrab_ranklis_item:"ui/huodong_ry/openservergrab/ui_openservergrab_ranklis_item",
ui_openservergrab_rewardranklis_view:"ui/huodong_ry/openservergrab/ui_openservergrab_rewardranklis_view",
ui_openservergrab_right_tab:"ui/huodong_ry/openservergrab/ui_openservergrab_right_tab",
ui_openservergrab_sevenday_view:"ui/huodong_ry/openservergrab/ui_openservergrab_sevenday_view",
ui_ry_openservergrab_bottombg:"ui/huodong_ry/openservergrab/ui_ry_openservergrab_bottombg",
ui_ry_openservergrab_bottomitem:"ui/huodong_ry/openservergrab/ui_ry_openservergrab_bottomitem",
ui_ry_openservergrab_mainview:"ui/huodong_ry/openservergrab/ui_ry_openservergrab_mainview",ui_ry_ridingbuy_mainpanel:"ui/huodong_ry/ridingbuy/ui_ry_ridingbuy_mainpanel",
ui_ry_ridingbuy_showhorsepanel:"ui/huodong_ry/ridingbuy/ui_ry_ridingbuy_showhorsepanel",ui_ry_ridingbuy_skillitem:"ui/huodong_ry/ridingbuy/ui_ry_ridingbuy_skillitem",
ui_ry_ridingbuy_tip:"ui/huodong_ry/ridingbuy/ui_ry_ridingbuy_tip",ui_intergral_anim_item:"ui/huodong_ry/sevenday/ui_intergral_anim_item",
ui_ry_sevenday_mainview:"ui/huodong_ry/sevenday/ui_ry_sevenday_mainview",ui_sevenday_daily_item:"ui/huodong_ry/sevenday/ui_sevenday_daily_item",
ui_sevenday_left_tab:"ui/huodong_ry/sevenday/ui_sevenday_left_tab",ui_sevenday_mall_item:"ui/huodong_ry/sevenday/ui_sevenday_mall_item",
ui_sevenday_quest_item:"ui/huodong_ry/sevenday/ui_sevenday_quest_item",ui_sevenday_quest_item1:"ui/huodong_ry/sevenday/ui_sevenday_quest_item1",
ui_sevenday_quest_role_item:"ui/huodong_ry/sevenday/ui_sevenday_quest_role_item",ui_sevenday_quest_tabbtn_item:"ui/huodong_ry/sevenday/ui_sevenday_quest_tabbtn_item",
ui_sevenday_quest_view:"ui/huodong_ry/sevenday/ui_sevenday_quest_view",ui_sevenday_rank_daily_reward_panel:"ui/huodong_ry/sevenday/ui_sevenday_rank_daily_reward_panel",
ui_sevenday_rank_item:"ui/huodong_ry/sevenday/ui_sevenday_rank_item",ui_sevenday_rank_item1:"ui/huodong_ry/sevenday/ui_sevenday_rank_item1",
ui_sevenday_rank_view:"ui/huodong_ry/sevenday/ui_sevenday_rank_view",ui_sevenday_right_tab:"ui/huodong_ry/sevenday/ui_sevenday_right_tab",
ui_sevenday_zhuoyue_view:"ui/huodong_ry/sevenday/ui_sevenday_zhuoyue_view",ui_sf_fiveblesscome_exchangeview:"ui/huodong_ry/springfestival_ry/ui_sf_fiveblesscome_exchangeview",
ui_sf_fiveblesscome_getreward_view:"ui/huodong_ry/springfestival_ry/ui_sf_fiveblesscome_getreward_view",
ui_sf_fiveblesscome_item:"ui/huodong_ry/springfestival_ry/ui_sf_fiveblesscome_item",ui_sf_fiveblesscome_item1:"ui/huodong_ry/springfestival_ry/ui_sf_fiveblesscome_item1",
ui_sf_fiveblesscome_item2:"ui/huodong_ry/springfestival_ry/ui_sf_fiveblesscome_item2",ui_sf_fiveblesscome_item3:"ui/huodong_ry/springfestival_ry/ui_sf_fiveblesscome_item3",
ui_sf_fiveblesscome_item4:"ui/huodong_ry/springfestival_ry/ui_sf_fiveblesscome_item4",ui_sf_fiveblesscome_shareview:"ui/huodong_ry/springfestival_ry/ui_sf_fiveblesscome_shareview",
ui_sf_fiveblesscome_view:"ui/huodong_ry/springfestival_ry/ui_sf_fiveblesscome_view",
ui_sf_goldcattle_getreward_view:"ui/huodong_ry/springfestival_ry/ui_sf_goldcattle_getreward_view",ui_sf_goldcattle_view:"ui/huodong_ry/springfestival_ry/ui_sf_goldcattle_view",
ui_sf_smallgoldcattle_item:"ui/huodong_ry/springfestival_ry/ui_sf_smallgoldcattle_item",ui_sf_springcattle_copyitem:"ui/huodong_ry/springfestival_ry/ui_sf_springcattle_copyitem",
ui_sf_springcattle_copymonster_item:"ui/huodong_ry/springfestival_ry/ui_sf_springcattle_copymonster_item",
ui_sf_springcattle_copypanel:"ui/huodong_ry/springfestival_ry/ui_sf_springcattle_copypanel",
ui_sf_springcattle_monster_item:"ui/huodong_ry/springfestival_ry/ui_sf_springcattle_monster_item",ui_sf_springcattle_view:"ui/huodong_ry/springfestival_ry/ui_sf_springcattle_view",
ui_springfestival_celebrateitem_ry:"ui/huodong_ry/springfestival_ry/ui_springfestival_celebrateitem_ry",
ui_springfestival_celebratepoolitem_ry:"ui/huodong_ry/springfestival_ry/ui_springfestival_celebratepoolitem_ry",
ui_springfestival_celebratetimeitem_ry:"ui/huodong_ry/springfestival_ry/ui_springfestival_celebratetimeitem_ry",
ui_springfestival_celebrateview_ry:"ui/huodong_ry/springfestival_ry/ui_springfestival_celebrateview_ry",
ui_springfestival_mainview_ry:"ui/huodong_ry/springfestival_ry/ui_springfestival_mainview_ry",
ui_springfestival_resultview_ry:"ui/huodong_ry/springfestival_ry/ui_springfestival_resultview_ry",
ui_springfestival_shopitem_ry:"ui/huodong_ry/springfestival_ry/ui_springfestival_shopitem_ry",
ui_springfestival_shopview_ry:"ui/huodong_ry/springfestival_ry/ui_springfestival_shopview_ry",ui_themecarnival_panel:"ui/huodong_ry/themecarnival/ui_themecarnival_panel",
ui_themecarnival_quest_item:"ui/huodong_ry/themecarnival/ui_themecarnival_quest_item",ui_themecarnival_reward_item:"ui/huodong_ry/themecarnival/ui_themecarnival_reward_item",
ui_themecarnival_right_btn:"ui/huodong_ry/themecarnival/ui_themecarnival_right_btn",ui_themecarnival_top_btn:"ui/huodong_ry/themecarnival/ui_themecarnival_top_btn",
ui_themecarnival_view:"ui/huodong_ry/themecarnival/ui_themecarnival_view",ui_starlimit_item:"ui/huodongmall_ry/starlimit/ui_starlimit_item",
ui_starlimit_view:"ui/huodongmall_ry/starlimit/ui_starlimit_view",ui_huodongmall_buy_panel:"ui/huodongmall_ry/ui_huodongmall_buy_panel",
ui_huodongmall_success_panel:"ui/huodongmall_ry/ui_huodongmall_success_panel",ui_icontips_grid:"ui/icontips/ui_icontips_grid",ui_icontips_grid2:"ui/icontips/ui_icontips_grid2",
ui_icontips_panel:"ui/icontips/ui_icontips_panel",ui_infotip_commonitem:"ui/infotip/ui_infotip_commonitem",ui_infotip_currency:"ui/infotip/ui_infotip_currency",
ui_infotip_tipview:"ui/infotip/ui_infotip_tipview",ui_innerlogin_button:"ui/innerlogin/ui_innerlogin_button",ui_innerlogin_loginpanel:"ui/innerlogin/ui_innerlogin_loginpanel",
ui_karima_rightstatusitem:"ui/karima/ui_karima_rightstatusitem",ui_rykarima_rightview:"ui/karima/ui_rykarima_rightview",ui_rykarima_statusview:"ui/karima/ui_rykarima_statusview",
ui_limitedencore_mainview:"ui/limitedencore/ui_limitedencore_mainview",ui_limitedencore_tab:"ui/limitedencore/ui_limitedencore_tab",
ui_loading_circleview_ry:"ui/loading_ry/ui_loading_circleview_ry",ui_create_role_view_ry:"ui/login/ui_create_role_view_ry",ui_gaininfonotice_view:"ui/login/ui_gaininfonotice_view",
ui_login_gmloginpanel:"ui/login/ui_login_gmloginpanel",ui_notice_left_tab:"ui/login/ui_notice_left_tab",ui_notice_view:"ui/login/ui_notice_view",
ui_select_role_view_ry:"ui/login/ui_select_role_view_ry",ui_lostabyss_battleview_ry:"ui/lostabyss_ry/ui_lostabyss_battleview_ry",
ui_lostabyss_item_ry:"ui/lostabyss_ry/ui_lostabyss_item_ry",ui_lostabyss_successview_ry:"ui/lostabyss_ry/ui_lostabyss_successview_ry",
ui_lostabyssview_ry:"ui/lostabyss_ry/ui_lostabyssview_ry",ui_mail_detail:"ui/mail/ui_mail_detail",ui_mail_infoitem:"ui/mail/ui_mail_infoitem",ui_mail_main:"ui/mail/ui_mail_main",
ui_mail_rewarditem:"ui/mail/ui_mail_rewarditem",btn_extra_package:"ui/mainView/btn_extra_package",pkfuncview:"ui/mainView/pkfuncview",
ui_function_prenotice:"ui/mainView/ui_function_prenotice",ui_mainview_allbuffList:"ui/mainView/ui_mainview_allbuffList",
ui_mainview_battleskillpanel:"ui/mainView/ui_mainview_battleskillpanel",ui_mainview_battleskillpanel_skill:"ui/mainView/ui_mainview_battleskillpanel_skill",
ui_mainview_buffList:"ui/mainView/ui_mainview_buffList",ui_mainview_collect_btn:"ui/mainView/ui_mainview_collect_btn",ui_mainview_expbar:"ui/mainView/ui_mainview_expbar",
ui_mainview_fpspanel:"ui/mainView/ui_mainview_fpspanel",ui_mainview_funcSetPanel:"ui/mainView/ui_mainview_funcSetPanel",
ui_mainview_funcopenpanel:"ui/mainView/ui_mainview_funcopenpanel",ui_mainview_function_down:"ui/mainView/ui_mainview_function_down",
ui_mainview_function_up:"ui/mainView/ui_mainview_function_up",ui_mainview_funitem:"ui/mainView/ui_mainview_funitem",ui_mainview_hangexptip:"ui/mainView/ui_mainview_hangexptip",
ui_mainview_headpanel:"ui/mainView/ui_mainview_headpanel",ui_mainview_operationentrance:"ui/mainView/ui_mainview_operationentrance",
ui_mainview_panel:"ui/mainView/ui_mainview_panel",ui_mainview_pkbuffitem:"ui/mainView/ui_mainview_pkbuffitem",ui_mainview_pkenemybuff:"ui/mainView/ui_mainview_pkenemybuff",
ui_mainview_skilllist:"ui/mainView/ui_mainview_skilllist",ui_bottomfunction_shortcutitem:"ui/mainui/bottomfunction/ui_bottomfunction_shortcutitem",
ui_shortcutgoods:"ui/mainui/shortcut/ui_shortcutgoods",ui_extra_loading_panel:"ui/mainui/ui_extra_loading_panel",ui_game_exit:"ui/mainui/ui_game_exit",
ui_map_change_progress:"ui/mainui/ui_map_change_progress",ui_map_loading:"ui/mainui/ui_map_loading",ui_map_titledrifting:"ui/mainui/ui_map_titledrifting",
ui_map_transport_mask:"ui/mainui/ui_map_transport_mask",ui_manual_challengeitem:"ui/manual/ui_manual_challengeitem",ui_manual_gainrewpanel:"ui/manual/ui_manual_gainrewpanel",
ui_manual_manualview:"ui/manual/ui_manual_manualview",ui_manual_somethingopen:"ui/manual/ui_manual_somethingopen",ui_maparea_mapareatips:"ui/maparea/ui_maparea_mapareatips",
ui_gate_reward_tips_ry:"ui/mappass/ui_gate_reward_tips_ry",ui_goldhangTips:"ui/mappass/ui_goldhangTips",ui_map_pass_Btn:"ui/mappass/ui_map_pass_Btn",
ui_map_pass_alert_ry:"ui/mappass/ui_map_pass_alert_ry",ui_map_pass_eff:"ui/mappass/ui_map_pass_eff",ui_map_pass_fb_failpanel_ry:"ui/mappass/ui_map_pass_fb_failpanel_ry",
ui_map_pass_fb_info:"ui/mappass/ui_map_pass_fb_info",ui_map_pass_fb_successpanel_ry:"ui/mappass/ui_map_pass_fb_successpanel_ry",ui_map_pass_flyeff:"ui/mappass/ui_map_pass_flyeff",
ui_map_pass_info_tip:"ui/mappass/ui_map_pass_info_tip",ui_map_pass_reward_baseitem:"ui/mappass/ui_map_pass_reward_baseitem",
ui_map_pass_reward_item:"ui/mappass/ui_map_pass_reward_item",ui_map_pass_reward_view:"ui/mappass/ui_map_pass_reward_view",ui_mappass_enter_eff:"ui/mappass/ui_mappass_enter_eff",
ui_unlockboss_fb_info:"ui/mappass/ui_unlockboss_fb_info",ui_maptitle_title:"ui/maptitle/ui_maptitle_title",ui_marekt_goods_bookself_ry:"ui/market/mall/ui_marekt_goods_bookself_ry",
ui_marekt_goods_item1_ry:"ui/market/mall/ui_marekt_goods_item1_ry",ui_marekt_goods_item2_ry:"ui/market/mall/ui_marekt_goods_item2_ry",
ui_marekt_limitgitf_bookself_ry:"ui/market/mall/ui_marekt_limitgitf_bookself_ry",ui_marekt_limittimetrib_baseitemex:"ui/market/mall/ui_marekt_limittimetrib_baseitemex",
ui_marekt_limittimetrib_item:"ui/market/mall/ui_marekt_limittimetrib_item",ui_market_buyicon:"ui/market/mall/ui_market_buyicon",
ui_market_mall_accessView:"ui/market/mall/ui_market_mall_accessView",ui_market_mall_buyTip:"ui/market/mall/ui_market_mall_buyTip",
ui_market_mall_item:"ui/market/mall/ui_market_mall_item",ui_market_mall_tab_item:"ui/market/mall/ui_market_mall_tab_item",ui_market_mallview:"ui/market/mall/ui_market_mallview",
ui_market_novice_item:"ui/market/mall/ui_market_novice_item",ui_market_gold_mainview_ry:"ui/market/ui_market_gold_mainview_ry",
ui_market_gold_shop_list_ry:"ui/market/ui_market_gold_shop_list_ry",ui_market_limittime_view:"ui/market/ui_market_limittime_view",
ui_market_limittimetrib_view_ry:"ui/market/ui_market_limittimetrib_view_ry",ui_market_mainview_ry:"ui/market/ui_market_mainview_ry",
ui_market_mall_shop_list_ry:"ui/market/ui_market_mall_shop_list_ry",ui_market_recharge_getitem:"ui/market/ui_market_recharge_getitem",
ui_market_recharge_panel_ry:"ui/market/ui_market_recharge_panel_ry",ui_market_rechargeitem_ry:"ui/market/ui_market_rechargeitem_ry",
ui_market_rechargetrib_view:"ui/market/ui_market_rechargetrib_view",ui_market_servicetrib_view_ry:"ui/market/ui_market_servicetrib_view_ry",
ui_market_servicetribitem_ry:"ui/market/ui_market_servicetribitem_ry",ui_newserver_advantage_tip:"ui/market/ui_newserver_advantage_tip",
ui_ry_NoviceShop1:"ui/market/ui_ry_NoviceShop1",ui_task_approachitem:"ui/market/ui_task_approachitem",ui_mastertalent_panel:"ui/mastertalent/ui_mastertalent_panel",
ui_talent_descitem:"ui/mastertalent/ui_talent_descitem",ui_talent_skillitem:"ui/mastertalent/ui_talent_skillitem",ui_talentline_item:"ui/mastertalent/ui_talentline_item",
ui_talentrebirth_item:"ui/mastertalent/ui_talentrebirth_item",ui_maya_hunttreasure_item:"ui/mayatreasure/ui_maya_hunttreasure_item",
ui_maya_hunttreasure_view:"ui/mayatreasure/ui_maya_hunttreasure_view",ui_maya_hunttreasure_view_02:"ui/mayatreasure/ui_maya_hunttreasure_view_02",
ui_maya_treasure_item:"ui/mayatreasure/ui_maya_treasure_item",ui_mayaexchange_item:"ui/mayatreasure/ui_mayaexchange_item",ui_mayaexchange_tip:"ui/mayatreasure/ui_mayaexchange_tip",
ui_mayaexchange_view:"ui/mayatreasure/ui_mayaexchange_view",ui_mayatreasure_panel:"ui/mayatreasure/ui_mayatreasure_panel",
ui_mayatreasure_result_item:"ui/mayatreasure/ui_mayatreasure_result_item",ui_mayatreasure_result_panel:"ui/mayatreasure/ui_mayatreasure_result_panel",
ui_mayatreasure_result_panel_2:"ui/mayatreasure/ui_mayatreasure_result_panel_2",ui_maze_collect_head:"ui/mazetimespace/ui_maze_collect_head",
ui_maze_copy_info_panel:"ui/mazetimespace/ui_maze_copy_info_panel",ui_maze_event_info:"ui/mazetimespace/ui_maze_event_info",
ui_maze_getenergyview:"ui/mazetimespace/ui_maze_getenergyview",ui_maze_mall_btn:"ui/mazetimespace/ui_maze_mall_btn",ui_maze_mall_item:"ui/mazetimespace/ui_maze_mall_item",
ui_maze_market_view:"ui/mazetimespace/ui_maze_market_view",ui_maze_resetview:"ui/mazetimespace/ui_maze_resetview",ui_maze_result_view:"ui/mazetimespace/ui_maze_result_view",
ui_maze_reward_item:"ui/mazetimespace/ui_maze_reward_item",ui_maze_room_item:"ui/mazetimespace/ui_maze_room_item",ui_maze_room_line_h:"ui/mazetimespace/ui_maze_room_line_h",
ui_maze_room_line_v:"ui/mazetimespace/ui_maze_room_line_v",ui_maze_room_map:"ui/mazetimespace/ui_maze_room_map",ui_maze_room_min_map:"ui/mazetimespace/ui_maze_room_min_map",
ui_maze_room_view:"ui/mazetimespace/ui_maze_room_view",ui_maze_rule_view:"ui/mazetimespace/ui_maze_rule_view",
ui_maze_timespace_info_item:"ui/mazetimespace/ui_maze_timespace_info_item",ui_maze_timespace_item:"ui/mazetimespace/ui_maze_timespace_item",
ui_maze_timespace_mainview:"ui/mazetimespace/ui_maze_timespace_mainview",ui_maze_transport_name:"ui/mazetimespace/ui_maze_transport_name",ui_moreitem:"ui/more/ui_moreitem",
ui_morepanel:"ui/more/ui_morepanel",ui_npc_speakpanel:"ui/npc/ui_npc_speakpanel",ui_obelisk_hex_big_item:"ui/obelisk_ry/ui_obelisk_hex_big_item",
ui_obelisk_hex_ui_item:"ui/obelisk_ry/ui_obelisk_hex_ui_item",ui_obelisk_left_hex_map:"ui/obelisk_ry/ui_obelisk_left_hex_map",
ui_obelisk_left_ready_view:"ui/obelisk_ry/ui_obelisk_left_ready_view",ui_obelisk_panel:"ui/obelisk_ry/ui_obelisk_panel",
ui_obelisk_right_end_view:"ui/obelisk_ry/ui_obelisk_right_end_view",ui_obelisk_right_list_item:"ui/obelisk_ry/ui_obelisk_right_list_item",
ui_obelisk_right_list_view:"ui/obelisk_ry/ui_obelisk_right_list_view",ui_obtain_exitem:"ui/obtain/ui_obtain_exitem",ui_obtain_panel:"ui/obtain/ui_obtain_panel",
ui_obtain_rywayitem:"ui/obtain/ui_obtain_rywayitem",ui_obtain_subwayitem:"ui/obtain/ui_obtain_subwayitem",ui_obtain_wayitem:"ui/obtain/ui_obtain_wayitem",
ui_taskobtain_panel:"ui/obtain/ui_taskobtain_panel",ui_taskobtain_wayitem:"ui/obtain/ui_taskobtain_wayitem",
ui_officialaccount_panel_ry:"ui/officialaccount/ui_officialaccount_panel_ry",ui_offlinehangup_item:"ui/offlinehangup/ui_offlinehangup_item",
ui_onlinehang_icon_ry:"ui/onlinehang_ry/ui_onlinehang_icon_ry",ui_onlinehang_view_ry:"ui/onlinehang_ry/ui_onlinehang_view_ry",
ui_openservice_mainpanel:"ui/openservice/ui_openservice_mainpanel",ui_pandora_recharge_panel:"ui/pandora/ui_pandora_recharge_panel",
ui_pandora_rewardshowpanel:"ui/pandora/ui_pandora_rewardshowpanel",ui_pandora_selectItem_tipspanel:"ui/pandora/ui_pandora_selectItem_tipspanel",
ui_pandora_selectitem:"ui/pandora/ui_pandora_selectitem",ui_pandora_tipsinfopanel:"ui/pandora/ui_pandora_tipsinfopanel",ui_pandora_tipspanel:"ui/pandora/ui_pandora_tipspanel",
ui_pandora_v1ptipsinfopanel:"ui/pandora/ui_pandora_v1ptipsinfopanel",ui_pandora_v1ptipspanel:"ui/pandora/ui_pandora_v1ptipspanel",
ui_pandora_box_item:"ui/pandorabox/ui_pandora_box_item",ui_pandora_box_mainpanel:"ui/pandorabox/ui_pandora_box_mainpanel",
ui_buttoneffect_panel:"ui/panelEffect/ui_buttoneffect_panel",ui_loading_panel:"ui/panelEffect/ui_loading_panel",ui_screen_notch_view:"ui/panelEffect/ui_screen_notch_view",
ui_pet_petheadui:"ui/pet/ui_pet_petheadui",ui_photograph_capturepanel:"ui/photograph/ui_photograph_capturepanel",ui_photograph_mainpanel:"ui/photograph/ui_photograph_mainpanel",
ui_pk_tips:"ui/pk/ui_pk_tips",ui_pk_tips_Role:"ui/pk/ui_pk_tips_Role",ui_pksw1tchpanel:"ui/pk/ui_pksw1tchpanel",
ui_ry_wonderful_event_activityitem:"ui/playercommunity/ui_ry_wonderful_event_activityitem",ui_ry_wonderful_event_picitem:"ui/playercommunity/ui_ry_wonderful_event_picitem",
ui_ry_wonderful_event_pointitem:"ui/playercommunity/ui_ry_wonderful_event_pointitem",ui_ry_wonderful_event_titleitem:"ui/playercommunity/ui_ry_wonderful_event_titleitem",
ui_ry_wondful_event:"ui/playercommunity/ui_ry_wondful_event",ui_pray_prayview:"ui/pray/ui_pray_prayview",
ui_publicbeta_collect_reward_icon:"ui/publicbeta_ry/ui_publicbeta_collect_reward_icon",ui_publicbeta_collect_rewardview_ry:"ui/publicbeta_ry/ui_publicbeta_collect_rewardview_ry",
ui_publicbeta_collect_sreenicon:"ui/publicbeta_ry/ui_publicbeta_collect_sreenicon",ui_publicbeta_daliy_Item:"ui/publicbeta_ry/ui_publicbeta_daliy_Item",
ui_publicbeta_daliy_reward_item:"ui/publicbeta_ry/ui_publicbeta_daliy_reward_item",ui_publicbeta_daliy_reward_part:"ui/publicbeta_ry/ui_publicbeta_daliy_reward_part",
ui_publicbeta_daliy_reward_view:"ui/publicbeta_ry/ui_publicbeta_daliy_reward_view",ui_publicbeta_daliy_tip_item:"ui/publicbeta_ry/ui_publicbeta_daliy_tip_item",
ui_publicbeta_daliy_tip_view:"ui/publicbeta_ry/ui_publicbeta_daliy_tip_view",ui_publicbeta_daliy_view:"ui/publicbeta_ry/ui_publicbeta_daliy_view",
ui_publicbeta_eff_view:"ui/publicbeta_ry/ui_publicbeta_eff_view",ui_publicbeta_jigsaw_chip:"ui/publicbeta_ry/ui_publicbeta_jigsaw_chip",
ui_publicbeta_jigsaw_lightchip_view:"ui/publicbeta_ry/ui_publicbeta_jigsaw_lightchip_view",ui_publicbeta_jigsaw_tab:"ui/publicbeta_ry/ui_publicbeta_jigsaw_tab",
ui_publicbeta_jigsaw_view:"ui/publicbeta_ry/ui_publicbeta_jigsaw_view",ui_publicbeta_mainview_ry:"ui/publicbeta_ry/ui_publicbeta_mainview_ry",
ui_publicbeta_review_item:"ui/publicbeta_ry/ui_publicbeta_review_item",ui_publicbeta_review_view:"ui/publicbeta_ry/ui_publicbeta_review_view",
ui_publicbeta_shop_item_ry:"ui/publicbeta_ry/ui_publicbeta_shop_item_ry",ui_publicbeta_shop_view:"ui/publicbeta_ry/ui_publicbeta_shop_view",
ui_publicbeta_totalrecharge_item_ry:"ui/publicbeta_ry/ui_publicbeta_totalrecharge_item_ry",
ui_publicbeta_totalrecharge_rewardview_ry:"ui/publicbeta_ry/ui_publicbeta_totalrecharge_rewardview_ry",
ui_publicbeta_totalrecharge_view_ry:"ui/publicbeta_ry/ui_publicbeta_totalrecharge_view_ry",ui_rainbow_panel:"ui/rainbow_ry/ui_rainbow_panel",
ui_ranking_rankitem:"ui/ranking/ui_ranking_rankitem",ui_ry_ranking_item:"ui/ranking/ui_ry_ranking_item",ui_ry_ranking_panel:"ui/ranking/ui_ry_ranking_panel",
ui_ry_tabcommonpanel_ranking:"ui/ranking/ui_ry_tabcommonpanel_ranking",ui_rebirth_boss_icon_panel:"ui/rebirth_ry/fight/ui_rebirth_boss_icon_panel",
ui_rebirth_boss_wildtime_panel:"ui/rebirth_ry/fight/ui_rebirth_boss_wildtime_panel",ui_rebirth_help_come_panel:"ui/rebirth_ry/fight/ui_rebirth_help_come_panel",
ui_rebirth_monster_item:"ui/rebirth_ry/fight/ui_rebirth_monster_item",ui_rebirth_monster_panel:"ui/rebirth_ry/fight/ui_rebirth_monster_panel",
ui_rebirth_player_icon:"ui/rebirth_ry/fight/ui_rebirth_player_icon",ui_rebirth_boss_fail_item:"ui/rebirth_ry/ui_rebirth_boss_fail_item",
ui_rebirth_boss_fail_panel:"ui/rebirth_ry/ui_rebirth_boss_fail_panel",ui_rebirth_boss_suc_panel:"ui/rebirth_ry/ui_rebirth_boss_suc_panel",
ui_rebirth_boss_view:"ui/rebirth_ry/ui_rebirth_boss_view",ui_rebirth_get_view:"ui/rebirth_ry/ui_rebirth_get_view",
ui_rebirth_lock_task_view:"ui/rebirth_ry/ui_rebirth_lock_task_view",ui_rebirth_lock_taskitem:"ui/rebirth_ry/ui_rebirth_lock_taskitem",
ui_rebirth_mainui_icon:"ui/rebirth_ry/ui_rebirth_mainui_icon",ui_rebirth_skill_info_panel:"ui/rebirth_ry/ui_rebirth_skill_info_panel",
ui_rebirth_submit_panel:"ui/rebirth_ry/ui_rebirth_submit_panel",ui_rebirth_suc_panel:"ui/rebirth_ry/ui_rebirth_suc_panel",
ui_rebirth_talent_tip:"ui/rebirth_ry/ui_rebirth_talent_tip",ui_recover_copycount_item:"ui/recover/ui_recover_copycount_item",
ui_recover_copycounttips_panel:"ui/recover/ui_recover_copycounttips_panel",ui_recover_countpanel_ry:"ui/recover/ui_recover_countpanel_ry",
ui_recover_offlinereward_item:"ui/recover/ui_recover_offlinereward_item",ui_recover_panel:"ui/recover/ui_recover_panel",ui_recover_recoveritem:"ui/recover/ui_recover_recoveritem",
ui_recover_taskreward_item:"ui/recover/ui_recover_taskreward_item",ui_recover_taskrewardtips_panel:"ui/recover/ui_recover_taskrewardtips_panel",
ui_relive_reliveBtn:"ui/relive/ui_relive_reliveBtn",ui_relive_relivepanel:"ui/relive/ui_relive_relivepanel",ui_relive_role_item:"ui/relive/ui_relive_role_item",
ui_relive_role_panel:"ui/relive/ui_relive_role_panel",ui_roland_notice_view:"ui/rolandnotice/ui_roland_notice_view",ui_rychat_face:"ui/rychat/ui_rychat_face",
ui_rychat_mainpanel:"ui/rychat/ui_rychat_mainpanel",ui_rychat_searchplayeritem:"ui/rychat/ui_rychat_searchplayeritem",
ui_rychat_searchplayerpanel:"ui/rychat/ui_rychat_searchplayerpanel",ui_equipadvance_excellenceattr:"ui/rycompound/ui_equipadvance_excellenceattr",
ui_ry_compound_autoscrollitem:"ui/rycompound/ui_ry_compound_autoscrollitem",ui_ry_compound_cellitem:"ui/rycompound/ui_ry_compound_cellitem",
ui_ry_compound_itembg:"ui/rycompound/ui_ry_compound_itembg",ui_ry_compound_matitem:"ui/rycompound/ui_ry_compound_matitem",
ui_ry_compound_oneclause:"ui/rycompound/ui_ry_compound_oneclause",ui_ry_compound_panel:"ui/rycompound/ui_ry_compound_panel",
ui_ry_compound_peek_panel:"ui/rycompound/ui_ry_compound_peek_panel",ui_ry_compound_peekitem:"ui/rycompound/ui_ry_compound_peekitem",
ui_ry_compound_put_itemtip:"ui/rycompound/ui_ry_compound_put_itemtip",ui_ry_compound_tabbtn_item:"ui/rycompound/ui_ry_compound_tabbtn_item",
ui_ry_equipAdvance_panel:"ui/rycompound/ui_ry_equipAdvance_panel",ui_ry_equipadvance_cellitem:"ui/rycompound/ui_ry_equipadvance_cellitem",
ui_ry_equipadvance_peek_panel:"ui/rycompound/ui_ry_equipadvance_peek_panel",ui_ry_equipadvance_success:"ui/rycompound/ui_ry_equipadvance_success",
ui_ry_equipadvance_success2:"ui/rycompound/ui_ry_equipadvance_success2",ui_ry_equipstaradvance_success:"ui/rycompound/ui_ry_equipstaradvance_success",
ui_ry_progressSlider:"ui/rycompound/ui_ry_progressSlider",ui_crime_copy_end_time_panel:"ui/rycrossserver/crime/fight/ui_crime_copy_end_time_panel",
ui_crime_copy_fail_panel:"ui/rycrossserver/crime/fight/ui_crime_copy_fail_panel",ui_crime_copy_suc_panel:"ui/rycrossserver/crime/fight/ui_crime_copy_suc_panel",
ui_crime_fight_buff_item:"ui/rycrossserver/crime/fight/ui_crime_fight_buff_item",ui_crime_fight_buff_panel:"ui/rycrossserver/crime/fight/ui_crime_fight_buff_panel",
ui_crime_buff_select_item:"ui/rycrossserver/crime/ui_crime_buff_select_item",ui_crime_buff_select_panel:"ui/rycrossserver/crime/ui_crime_buff_select_panel",
ui_crime_monsterfigure:"ui/rycrossserver/crime/ui_crime_monsterfigure",ui_crime_point_item:"ui/rycrossserver/crime/ui_crime_point_item",
ui_crime_progressitem:"ui/rycrossserver/crime/ui_crime_progressitem",ui_crime_rank_item:"ui/rycrossserver/crime/ui_crime_rank_item",
ui_crime_rank_reward_panel:"ui/rycrossserver/crime/ui_crime_rank_reward_panel",ui_crime_reward_item:"ui/rycrossserver/crime/ui_crime_reward_item",
ui_crime_reward_rank_item0:"ui/rycrossserver/crime/ui_crime_reward_rank_item0",ui_crime_reward_rank_item1:"ui/rycrossserver/crime/ui_crime_reward_rank_item1",
ui_crime_reward_rank_panel:"ui/rycrossserver/crime/ui_crime_reward_rank_panel",ui_crime_tip_view:"ui/rycrossserver/crime/ui_crime_tip_view",
ui_crime_value_reward_panel:"ui/rycrossserver/crime/ui_crime_value_reward_panel",ui_crime_view:"ui/rycrossserver/crime/ui_crime_view",
ui_roland_end_tipview:"ui/rycrossserver/rolandappear/ui_roland_end_tipview",ui_roland_monster_item:"ui/rycrossserver/rolandappear/ui_roland_monster_item",
ui_roland_tower_stoneitem:"ui/rycrossserver/rolandappear/ui_roland_tower_stoneitem",ui_rolandappear_mainpanel:"ui/rycrossserver/rolandappear/ui_rolandappear_mainpanel",
ui_rolandappear_rank_item:"ui/rycrossserver/rolandappear/ui_rolandappear_rank_item",ui_rolandappear_rewarditem:"ui/rycrossserver/rolandappear/ui_rolandappear_rewarditem",
ui_rolandbuff_flyitem:"ui/rycrossserver/rolandappear/ui_rolandbuff_flyitem",ui_rolandbuff_item:"ui/rycrossserver/rolandappear/ui_rolandbuff_item",
ui_rolandbuff_rewardview:"ui/rycrossserver/rolandappear/ui_rolandbuff_rewardview",ui_rolandprogress_item:"ui/rycrossserver/rolandappear/ui_rolandprogress_item",
ui_rolandprogress_panel:"ui/rycrossserver/rolandappear/ui_rolandprogress_panel",ui_rolandvalley_bossInfo_view:"ui/rycrossserver/rolandappear/ui_rolandvalley_bossInfo_view",
ui_rolandvalley_boxInfo_item:"ui/rycrossserver/rolandappear/ui_rolandvalley_boxInfo_item",ui_rolandvalley_copy_success:"ui/rycrossserver/rolandappear/ui_rolandvalley_copy_success",
ui_rolandvalley_copypanel:"ui/rycrossserver/rolandappear/ui_rolandvalley_copypanel",ui_rolandvalley_guide_flybtn:"ui/rycrossserver/rolandappear/ui_rolandvalley_guide_flybtn",
ui_rolandvalley_guide_showview:"ui/rycrossserver/rolandappear/ui_rolandvalley_guide_showview",
ui_rolandvalley_monsteritem:"ui/rycrossserver/rolandappear/ui_rolandvalley_monsteritem",
ui_rolandvalley_monsteritem_big:"ui/rycrossserver/rolandappear/ui_rolandvalley_monsteritem_big",
ui_rolandvalley_monsteritem_small:"ui/rycrossserver/rolandappear/ui_rolandvalley_monsteritem_small",ui_rolandvalley_panel:"ui/rycrossserver/rolandappear/ui_rolandvalley_panel",
ui_rolandvalley_rankreward_item:"ui/rycrossserver/rolandappear/ui_rolandvalley_rankreward_item",
ui_rolanddefense_bosspanel:"ui/rycrossserver/rolanddefense/ui_rolanddefense_bosspanel",ui_rolanddefense_copysuccess1:"ui/rycrossserver/rolanddefense/ui_rolanddefense_copysuccess1",
ui_rolanddefense_copyview1:"ui/rycrossserver/rolanddefense/ui_rolanddefense_copyview1",ui_rolanddefense_copyview2:"ui/rycrossserver/rolanddefense/ui_rolanddefense_copyview2",
ui_rolanddefense_copyview2_item:"ui/rycrossserver/rolanddefense/ui_rolanddefense_copyview2_item",
ui_rolanddefense_main_view:"ui/rycrossserver/rolanddefense/ui_rolanddefense_main_view",ui_rolanddefense_monster_item:"ui/rycrossserver/rolanddefense/ui_rolanddefense_monster_item",
ui_rolanddefense_monster_skillitem:"ui/rycrossserver/rolanddefense/ui_rolanddefense_monster_skillitem",
ui_rolanddefense_monster_view:"ui/rycrossserver/rolanddefense/ui_rolanddefense_monster_view",
ui_rolanddefense_repaircrack_view:"ui/rycrossserver/rolanddefense/ui_rolanddefense_repaircrack_view",
ui_rolanddefense_senceview:"ui/rycrossserver/rolanddefense/ui_rolanddefense_senceview",ui_rolanddefense_state2item:"ui/rycrossserver/rolanddefense/ui_rolanddefense_state2item",
ui_rolandsave_copy_bossassistpanel:"ui/rycrossserver/rolandsave/crusade/ui_rolandsave_copy_bossassistpanel",
ui_rolandsave_copy_resultitem_ry:"ui/rycrossserver/rolandsave/crusade/ui_rolandsave_copy_resultitem_ry",
ui_rolandsave_copy_resultview_ry:"ui/rycrossserver/rolandsave/crusade/ui_rolandsave_copy_resultview_ry",
ui_rolandsave_crusade_resultview_ry:"ui/rycrossserver/rolandsave/crusade/ui_rolandsave_crusade_resultview_ry",
ui_rolandsave_crusade_traceview_ry:"ui/rycrossserver/rolandsave/crusade/ui_rolandsave_crusade_traceview_ry",
ui_rolandsave_efficiency_mainui:"ui/rycrossserver/rolandsave/crusade/ui_rolandsave_efficiency_mainui",
ui_rolandsave_boss_cd_panel:"ui/rycrossserver/rolandsave/fight/ui_rolandsave_boss_cd_panel",
ui_rolandsave_boss_come_time_panel:"ui/rycrossserver/rolandsave/fight/ui_rolandsave_boss_come_time_panel",
ui_rolandsave_fight_rank_panel:"ui/rycrossserver/rolandsave/fight/ui_rolandsave_fight_rank_panel",
ui_rolandsave_first_enter_black_panel:"ui/rycrossserver/rolandsave/fight/ui_rolandsave_first_enter_black_panel",
ui_rolandsave_add_power_panel:"ui/rycrossserver/rolandsave/ui_rolandsave_add_power_panel",
ui_rolandsave_boss_reward_rank_tip:"ui/rycrossserver/rolandsave/ui_rolandsave_boss_reward_rank_tip",
ui_rolandsave_boss_reward_rank_tip_item:"ui/rycrossserver/rolandsave/ui_rolandsave_boss_reward_rank_tip_item",
ui_rolandsave_boss_view:"ui/rycrossserver/rolandsave/ui_rolandsave_boss_view",ui_rolandsave_fight_rank_item:"ui/rycrossserver/rolandsave/ui_rolandsave_fight_rank_item",
ui_rolandsave_monster_item:"ui/rycrossserver/rolandsave/ui_rolandsave_monster_item",ui_rolandsave_nest_item:"ui/rycrossserver/rolandsave/ui_rolandsave_nest_item",
ui_rolandsave_nest_view:"ui/rycrossserver/rolandsave/ui_rolandsave_nest_view",ui_rolandsave_panel:"ui/rycrossserver/rolandsave/ui_rolandsave_panel",
ui_rolandsave_power_comp:"ui/rycrossserver/rolandsave/ui_rolandsave_power_comp",ui_rolandsave_rank_item:"ui/rycrossserver/rolandsave/ui_rolandsave_rank_item",
ui_rolandsave_reward_rank_item0:"ui/rycrossserver/rolandsave/ui_rolandsave_reward_rank_item0",
ui_rolandsave_reward_rank_item1:"ui/rycrossserver/rolandsave/ui_rolandsave_reward_rank_item1",
ui_rolandsave_reward_rank_panel:"ui/rycrossserver/rolandsave/ui_rolandsave_reward_rank_panel",
ui_rolandsave_storyloadingview_ry:"ui/rycrossserver/rolandsave/ui_rolandsave_storyloadingview_ry",
ui_rolandsave_wish_buff_item:"ui/rycrossserver/rolandsave/ui_rolandsave_wish_buff_item",ui_rolandsave_wish_buff_tip:"ui/rycrossserver/rolandsave/ui_rolandsave_wish_buff_tip",
UI_rydtsnb_example8ItemRy:"ui/rydtsnb/UI_rydtsnb_example8ItemRy",ui_rydtsnb_example1:"ui/rydtsnb/ui_rydtsnb_example1",ui_rydtsnb_example11:"ui/rydtsnb/ui_rydtsnb_example11",
ui_rydtsnb_example12:"ui/rydtsnb/ui_rydtsnb_example12",ui_rydtsnb_example13:"ui/rydtsnb/ui_rydtsnb_example13",ui_rydtsnb_example2:"ui/rydtsnb/ui_rydtsnb_example2",
ui_rydtsnb_example3:"ui/rydtsnb/ui_rydtsnb_example3",ui_rydtsnb_example4:"ui/rydtsnb/ui_rydtsnb_example4",ui_rydtsnb_example5:"ui/rydtsnb/ui_rydtsnb_example5",
ui_rydtsnb_example6:"ui/rydtsnb/ui_rydtsnb_example6",ui_rydtsnb_example7:"ui/rydtsnb/ui_rydtsnb_example7",ui_rydtsnb_view:"ui/rydtsnb/ui_rydtsnb_view",
ui_rydtsnb_view_btn:"ui/rydtsnb/ui_rydtsnb_view_btn",ui_ry_equipadvance_baseAttrItem:"ui/ryequipadvance/ui_ry_equipadvance_baseAttrItem",
ui_ry_equipadvance_consumeitem:"ui/ryequipadvance/ui_ry_equipadvance_consumeitem",ui_ry_equipadvance_excellenceAttrItem:"ui/ryequipadvance/ui_ry_equipadvance_excellenceAttrItem",
ui_ry_equipadvance_panel_new:"ui/ryequipadvance/ui_ry_equipadvance_panel_new",ui_ry_equipadvance_peekattrpanel:"ui/ryequipadvance/ui_ry_equipadvance_peekattrpanel",
ui_ry_equipadvance_peekitem:"ui/ryequipadvance/ui_ry_equipadvance_peekitem",ui_ry_equipadvance_selectpanel:"ui/ryequipadvance/ui_ry_equipadvance_selectpanel",
ui_ry_equipStarAdvance_excellenceAttrItem:"ui/ryequipstaradvance/ui_ry_equipStarAdvance_excellenceAttrItem",
ui_ry_equipstaradvance_consumeitem:"ui/ryequipstaradvance/ui_ry_equipstaradvance_consumeitem",
ui_ry_equipstaradvance_panel_new:"ui/ryequipstaradvance/ui_ry_equipstaradvance_panel_new",
ui_ry_equipstaradvance_selectpanel:"ui/ryequipstaradvance/ui_ry_equipstaradvance_selectpanel",
ui_ry_equipstaradvance_staritem:"ui/ryequipstaradvance/ui_ry_equipstaradvance_staritem",ui_staradvance_eq_show_item:"ui/ryequipstaradvance/ui_staradvance_eq_show_item",
ui_ry_forge_equiprefine_attritem:"ui/ryforge/equiprefine/ui_ry_forge_equiprefine_attritem",
ui_ry_forge_equiprefine_attrview:"ui/ryforge/equiprefine/ui_ry_forge_equiprefine_attrview",
ui_ry_forge_equiprefine_commitem:"ui/ryforge/equiprefine/ui_ry_forge_equiprefine_commitem",ui_ry_forge_equiprefine_item:"ui/ryforge/equiprefine/ui_ry_forge_equiprefine_item",
ui_ry_forge_equiprefine_refineitem:"ui/ryforge/equiprefine/ui_ry_forge_equiprefine_refineitem",
ui_ry_forge_equiprefine_refineview:"ui/ryforge/equiprefine/ui_ry_forge_equiprefine_refineview",
ui_ry_forge_equiprefine_replaceview:"ui/ryforge/equiprefine/ui_ry_forge_equiprefine_replaceview",
ui_ry_forge_equiprefine_smallicon:"ui/ryforge/equiprefine/ui_ry_forge_equiprefine_smallicon",
ui_ry_forge_equiprefine_upgradesucview:"ui/ryforge/equiprefine/ui_ry_forge_equiprefine_upgradesucview",
ui_ry_forge_equiprefineview:"ui/ryforge/equiprefine/ui_ry_forge_equiprefineview",ui_metagems_property:"ui/ryforge/ui_metagems_property",
ui_ry_forge_addtionView:"ui/ryforge/ui_ry_forge_addtionView",ui_ry_forge_drag_Item:"ui/ryforge/ui_ry_forge_drag_Item",ui_ry_forge_enhanceView:"ui/ryforge/ui_ry_forge_enhanceView",
ui_ry_forge_enhancesuccess:"ui/ryforge/ui_ry_forge_enhancesuccess",ui_ry_forge_equip_item:"ui/ryforge/ui_ry_forge_equip_item",
ui_ry_forge_equip_item2:"ui/ryforge/ui_ry_forge_equip_item2",ui_ry_forge_luckyAddView:"ui/ryforge/ui_ry_forge_luckyAddView",
ui_ry_forge_materialitem:"ui/ryforge/ui_ry_forge_materialitem",ui_ry_forge_metage_eff1:"ui/ryforge/ui_ry_forge_metage_eff1",
ui_ry_forge_metagems_baseitem:"ui/ryforge/ui_ry_forge_metagems_baseitem",ui_ry_forge_metagems_baseitem_hasadd:"ui/ryforge/ui_ry_forge_metagems_baseitem_hasadd",
ui_ry_forge_metagems_blessactive_view:"ui/ryforge/ui_ry_forge_metagems_blessactive_view",ui_ry_forge_metagems_box_eff:"ui/ryforge/ui_ry_forge_metagems_box_eff",
ui_ry_forge_metagems_box_view:"ui/ryforge/ui_ry_forge_metagems_box_view",ui_ry_forge_metagems_gemitem:"ui/ryforge/ui_ry_forge_metagems_gemitem",
ui_ry_forge_metagems_item:"ui/ryforge/ui_ry_forge_metagems_item",ui_ry_forge_metagems_item_label:"ui/ryforge/ui_ry_forge_metagems_item_label",
ui_ry_forge_metagems_max_property:"ui/ryforge/ui_ry_forge_metagems_max_property",ui_ry_forge_metagems_tips:"ui/ryforge/ui_ry_forge_metagems_tips",
ui_ry_forge_metagems_tips_item:"ui/ryforge/ui_ry_forge_metagems_tips_item",ui_ry_forge_metagemsview:"ui/ryforge/ui_ry_forge_metagemsview",
ui_ry_forge_panel:"ui/ryforge/ui_ry_forge_panel",ui_ry_forge_quicksuccess:"ui/ryforge/ui_ry_forge_quicksuccess",ui_ry_forge_suitView:"ui/ryforge/ui_ry_forge_suitView",
ui_ry_forge_suitView_item:"ui/ryforge/ui_ry_forge_suitView_item",ui_ry_forge_suitView_item2:"ui/ryforge/ui_ry_forge_suitView_item2",
ui_ry_forge_suitView_module:"ui/ryforge/ui_ry_forge_suitView_module",ui_ry_forge_suit_tip:"ui/ryforge/ui_ry_forge_suit_tip",
ui_ry_forge_suitsuccess:"ui/ryforge/ui_ry_forge_suitsuccess",ui_ry_forge_wayItem:"ui/ryforge/ui_ry_forge_wayItem",
ui_ry_forge_wingRefineView:"ui/ryforge/ui_ry_forge_wingRefineView",ui_ry_forge_wingRefine_selectpanel:"ui/ryforge/ui_ry_forge_wingRefine_selectpanel",
ui_ry_forge_wingRefine_success:"ui/ryforge/ui_ry_forge_wingRefine_success",ui_ry_forge_wingRefine_successAttrItem:"ui/ryforge/ui_ry_forge_wingRefine_successAttrItem",
ui_ry_forge_wingpreview:"ui/ryforge/ui_ry_forge_wingpreview",ui_ry_forge_wingrefineAttrItem:"ui/ryforge/ui_ry_forge_wingrefineAttrItem",
ui_ry_forge_wingrefineconsumeitem:"ui/ryforge/ui_ry_forge_wingrefineconsumeitem",ui_ry_friendpanel:"ui/ryfriend/ui_ry_friendpanel",
ui_ryfriend_addItem:"ui/ryfriend/ui_ryfriend_addItem",ui_medalview_ry:"ui/rymedal/ui_medalview_ry",ui_medalview_skillitem:"ui/rymedal/ui_medalview_skillitem",
ui_ry_offlinehangup_panel:"ui/ryofflinehangup/ui_ry_offlinehangup_panel",line1_pos:"ui/ryskill/line1_pos",ui_ry_box_item_eff:"ui/ryskill/ui_ry_box_item_eff",
ui_ry_skill_ChangeView:"ui/ryskill/ui_ry_skill_ChangeView",ui_ry_skill_LearnView:"ui/ryskill/ui_ry_skill_LearnView",ui_ry_skill_PracticeView:"ui/ryskill/ui_ry_skill_PracticeView",
ui_ry_skill_bar_item:"ui/ryskill/ui_ry_skill_bar_item",ui_ry_skill_bar_item_eff:"ui/ryskill/ui_ry_skill_bar_item_eff",ui_ry_skill_common_item:"ui/ryskill/ui_ry_skill_common_item",
ui_ry_skill_descItem:"ui/ryskill/ui_ry_skill_descItem",ui_ry_skill_descItem2:"ui/ryskill/ui_ry_skill_descItem2",ui_ry_skill_job_raw:"ui/ryskill/ui_ry_skill_job_raw",
ui_ry_skill_main_view:"ui/ryskill/ui_ry_skill_main_view",ui_ry_skill_praticeEffView:"ui/ryskill/ui_ry_skill_praticeEffView",
ui_ry_skill_praticeSkillDesc:"ui/ryskill/ui_ry_skill_praticeSkillDesc",ui_ry_skill_praticeSkillView:"ui/ryskill/ui_ry_skill_praticeSkillView",
ui_ry_skill_tips:"ui/ryskill/ui_ry_skill_tips",ui_ry_skill_view_item:"ui/ryskill/ui_ry_skill_view_item",ui_ry_skilltipview:"ui/ryskill/ui_ry_skilltipview",
ui_skill_new_desc_ry:"ui/ryskill/ui_skill_new_desc_ry",ui_skill_new_to_other_ry:"ui/ryskill/ui_skill_new_to_other_ry",
ui_skill_new_to_skill_ry:"ui/ryskill/ui_skill_new_to_skill_ry",ui_skillitem:"ui/ryskill/ui_skillitem",ui_taozhuangronghe_item:"ui/rytaozhuangronghe/ui_taozhuangronghe_item",
ui_taozhuangronghe_success_view:"ui/rytaozhuangronghe/ui_taozhuangronghe_success_view",ui_taozhuangronghe_suitfuseattr:"ui/rytaozhuangronghe/ui_taozhuangronghe_suitfuseattr",
ui_taozhuangronghe_view:"ui/rytaozhuangronghe/ui_taozhuangronghe_view",ui_taozhuangronghe_view_02:"ui/rytaozhuangronghe/ui_taozhuangronghe_view_02",
ui_sceneani_panel:"ui/scene/ui_sceneani_panel",ui_diamond_limit_noticeicon_ry:"ui/scoreFly/ui_diamond_limit_noticeicon_ry",
ui_diamond_limit_noticeview_ry:"ui/scoreFly/ui_diamond_limit_noticeview_ry",ui_diamond_limit_rewardview_ry:"ui/scoreFly/ui_diamond_limit_rewardview_ry",
ui_diamondfly_item:"ui/scoreFly/ui_diamondfly_item",ui_diamondfly_panel:"ui/scoreFly/ui_diamondfly_panel",ui_scorefly_panel:"ui/scoreFly/ui_scorefly_panel",
ui_scoreflytobar_panel:"ui/scoreFly/ui_scoreflytobar_panel",ui_selectroletip_item:"ui/selectroletip/ui_selectroletip_item",
ui_selectroletip_view:"ui/selectroletip/ui_selectroletip_view",ui_server_areaitem:"ui/server/ui_server_areaitem",ui_server_groupitem:"ui/server/ui_server_groupitem",
ui_server_panel_ry:"ui/server/ui_server_panel_ry",ui_server_roleitem:"ui/server/ui_server_roleitem",ui_setting_activityitem:"ui/setting/ui_setting_activityitem",
ui_setting_chataudiopanel:"ui/setting/ui_setting_chataudiopanel",ui_setting_lockscreenpanel:"ui/setting/ui_setting_lockscreenpanel",
ui_setting_offlinedielogtip:"ui/setting/ui_setting_offlinedielogtip",ui_setting_offlinerecoverpanel:"ui/setting/ui_setting_offlinerecoverpanel",
ui_setting_offlinerewardpanel:"ui/setting/ui_setting_offlinerewardpanel",ui_setting_recommendpanel:"ui/setting/ui_setting_recommendpanel",
ui_setting_settinghangpanel:"ui/setting/ui_setting_settinghangpanel",ui_setting_skillsetitem:"ui/setting/ui_setting_skillsetitem",
ui_setting_systempanel:"ui/setting/ui_setting_systempanel",ui_setting_userinfopanel:"ui/setting/ui_setting_userinfopanel",ui_settingmainpanel:"ui/setting/ui_settingmainpanel",
ui_shop_buyitem:"ui/shop/ui_shop_buyitem",ui_shop_commonattr:"ui/shop/ui_shop_commonattr",ui_shop_commoncost:"ui/shop/ui_shop_commoncost",
ui_shop_withoneshop:"ui/shop/ui_shop_withoneshop",ui_ry_skill_panel:"ui/skill/ui_ry_skill_panel",ui_skill_bar_item:"ui/skill/ui_skill_bar_item",
ui_skill_effect:"ui/skill/ui_skill_effect",ui_skill_job_raw:"ui/skill/ui_skill_job_raw",ui_skill_jobskill_info_tip:"ui/skill/ui_skill_jobskill_info_tip",
ui_skill_jobskillview:"ui/skill/ui_skill_jobskillview",ui_skill_tips:"ui/skill/ui_skill_tips",ui_skill_tips_descitem:"ui/skill/ui_skill_tips_descitem",
ui_skill_tips_toppanel:"ui/skill/ui_skill_tips_toppanel",ui_skill_view_item:"ui/skill/ui_skill_view_item",ui_skilllimitbuy_item_ry:"ui/skilllimitbuy_ry/ui_skilllimitbuy_item_ry",
ui_skilllimitbuy_reward_view_ry:"ui/skilllimitbuy_ry/ui_skilllimitbuy_reward_view_ry",ui_skilllimitbuy_second_view_ry:"ui/skilllimitbuy_ry/ui_skilllimitbuy_second_view_ry",
ui_skilllimitbuy_view_ry:"ui/skilllimitbuy_ry/ui_skilllimitbuy_view_ry",ui_spaceorigin_item2_ry:"ui/spaceorigin/ui_spaceorigin_item2_ry",
ui_spaceorigin_item_ry:"ui/spaceorigin/ui_spaceorigin_item_ry",ui_spaceorigin_notice_ry:"ui/spaceorigin/ui_spaceorigin_notice_ry",
ui_spaceorigin_rankitem_ry:"ui/spaceorigin/ui_spaceorigin_rankitem_ry",ui_spaceorigin_root_ry:"ui/spaceorigin/ui_spaceorigin_root_ry",
ui_spaceorigin_ry:"ui/spaceorigin/ui_spaceorigin_ry",ui_stall_aditem_ry:"ui/stall_ry/ui_stall_aditem_ry",ui_stall_bagitem_ry:"ui/stall_ry/ui_stall_bagitem_ry",
ui_stall_bagitemex_ry:"ui/stall_ry/ui_stall_bagitemex_ry",ui_stall_buyview_ry:"ui/stall_ry/ui_stall_buyview_ry",ui_stall_dunrare_item_ry:"ui/stall_ry/ui_stall_dunrare_item_ry",
ui_stall_expensivelogitem_ry:"ui/stall_ry/ui_stall_expensivelogitem_ry",ui_stall_expensivelogview_ry:"ui/stall_ry/ui_stall_expensivelogview_ry",
ui_stall_logitem_ry:"ui/stall_ry/ui_stall_logitem_ry",ui_stall_logview_ry:"ui/stall_ry/ui_stall_logview_ry",ui_stall_market_item_ry:"ui/stall_ry/ui_stall_market_item_ry",
ui_stall_market_menuitem_ry:"ui/stall_ry/ui_stall_market_menuitem_ry",ui_stall_marketview_onetreeitem:"ui/stall_ry/ui_stall_marketview_onetreeitem",
ui_stall_marketview_onetreetitleitem:"ui/stall_ry/ui_stall_marketview_onetreetitleitem",ui_stall_marketview_ry:"ui/stall_ry/ui_stall_marketview_ry",
ui_stall_marketview_treeitem_ry:"ui/stall_ry/ui_stall_marketview_treeitem_ry",ui_stall_marketview_treetitleitem_ry:"ui/stall_ry/ui_stall_marketview_treetitleitem_ry",
ui_stall_mystallview_ry:"ui/stall_ry/ui_stall_mystallview_ry",ui_stall_otherplayerview_ry:"ui/stall_ry/ui_stall_otherplayerview_ry",
ui_stall_putoffview_ry:"ui/stall_ry/ui_stall_putoffview_ry",ui_stall_putonview_ry:"ui/stall_ry/ui_stall_putonview_ry",ui_stall_rerentview_ry:"ui/stall_ry/ui_stall_rerentview_ry",
ui_stall_stallview_ry:"ui/stall_ry/ui_stall_stallview_ry",ui_ry_starsky_tabview:"ui/starsky_ry/ui_ry_starsky_tabview",ui_sky_lottery_btns:"ui/starsky_ry/ui_sky_lottery_btns",
ui_sky_pool_rewardshow_item:"ui/starsky_ry/ui_sky_pool_rewardshow_item",ui_sky_reward_pool_view:"ui/starsky_ry/ui_sky_reward_pool_view",
ui_sky_show_item:"ui/starsky_ry/ui_sky_show_item",ui_starsky_limit_view:"ui/starsky_ry/ui_starsky_limit_view",ui_starsky_view:"ui/starsky_ry/ui_starsky_view",
ui_subsky_reward_item:"ui/starsky_ry/ui_subsky_reward_item",ui_story_boss_show:"ui/story/ui_story_boss_show",ui_story_bossbinghou:"ui/story/ui_story_bossbinghou",
ui_story_break:"ui/story/ui_story_break",ui_story_dialog:"ui/story/ui_story_dialog",ui_story_dynic_boss_show:"ui/story/ui_story_dynic_boss_show",
ui_story_talk1:"ui/story/ui_story_talk1",ui_story_talk2:"ui/story/ui_story_talk2",ui_story_talk3:"ui/story/ui_story_talk3",ui_story_talk4:"ui/story/ui_story_talk4",
ui_story_talk5:"ui/story/ui_story_talk5",ui_story_talk6:"ui/story/ui_story_talk6",ui_story_talk7:"ui/story/ui_story_talk7",ui_story_talk8:"ui/story/ui_story_talk8",
ui_superVip:"ui/supervip/ui_superVip",ui_surface_fashionattritem_ry:"ui/surface_ry/ui_surface_fashionattritem_ry",
ui_surface_fashionattrview_ry:"ui/surface_ry/ui_surface_fashionattrview_ry",ui_surface_fashioncabinet_attritem_ry:"ui/surface_ry/ui_surface_fashioncabinet_attritem_ry",
ui_surface_fashioncabinetview_ry:"ui/surface_ry/ui_surface_fashioncabinetview_ry",ui_surface_fashionitem_ry:"ui/surface_ry/ui_surface_fashionitem_ry",
ui_surface_fashionview_ry:"ui/surface_ry/ui_surface_fashionview_ry",ui_surface_menuitem_ry:"ui/surface_ry/ui_surface_menuitem_ry",
ui_surface_settingview_ry:"ui/surface_ry/ui_surface_settingview_ry",ui_surface_show_selectview_ry:"ui/surface_ry/ui_surface_show_selectview_ry",
ui_surface_showitem_ry:"ui/surface_ry/ui_surface_showitem_ry",ui_surface_showview_ry:"ui/surface_ry/ui_surface_showview_ry",
ui_sw1tchtarget_item:"ui/switchtarget/ui_sw1tchtarget_item",ui_sw1tchtarget_panel:"ui/switchtarget/ui_sw1tchtarget_panel",
ui_systemtips_SystemChannelPanel:"ui/systemtips/ui_systemtips_SystemChannelPanel",ui_systemtips_bufftippanel:"ui/systemtips/ui_systemtips_bufftippanel",
ui_systemtips_riversandlakessaid:"ui/systemtips/ui_systemtips_riversandlakessaid",ui_systemtips_scannermsgview:"ui/systemtips/ui_systemtips_scannermsgview",
ui_systemtips_tipmessageitem:"ui/systemtips/ui_systemtips_tipmessageitem",ui_systemtips_tipmessageitem2:"ui/systemtips/ui_systemtips_tipmessageitem2",
ui_systemtips_tipmessagepanel:"ui/systemtips/ui_systemtips_tipmessagepanel",ui_mainview_buffList1:"ui/targetplayer/ui_mainview_buffList1",
ui_mainview_buffcell:"ui/targetplayer/ui_mainview_buffcell",ui_targetplayer_head:"ui/targetplayer/ui_targetplayer_head",
ui_targetplayer_headpanel:"ui/targetplayer/ui_targetplayer_headpanel",ui_targetplayer_operationpanel:"ui/targetplayer/ui_targetplayer_operationpanel",
ui_targetplayer_reportotherpanel:"ui/targetplayer/ui_targetplayer_reportotherpanel",ui_targetplayer_ryequipitem:"ui/targetplayer/ui_targetplayer_ryequipitem",
ui_targetplayer_ryequipview:"ui/targetplayer/ui_targetplayer_ryequipview",ui_targetplayer_rymainpanel:"ui/targetplayer/ui_targetplayer_rymainpanel",
ui_task_exeequippanel:"ui/task/ui_task_exeequippanel",ui_task_skillpanel:"ui/task/ui_task_skillpanel",ui_task_equipcollectguidepanel:"ui/task_ry/ui_task_equipcollectguidepanel",
ui_task_finish_effect_panel:"ui/task_ry/ui_task_finish_effect_panel",ui_task_hide_view:"ui/task_ry/ui_task_hide_view",
ui_task_mainui_hide_panel:"ui/task_ry/ui_task_mainui_hide_panel",ui_task_mainui_item:"ui/task_ry/ui_task_mainui_item",ui_task_mainui_panel:"ui/task_ry/ui_task_mainui_panel",
ui_task_temp_item:"ui/task_ry/ui_task_temp_item",ui_task_temp_view:"ui/task_ry/ui_task_temp_view",
ui_task_contract_finish_eff_panel:"ui/taskcontract_ry/ui_task_contract_finish_eff_panel",ui_task_contract_info_panel:"ui/taskcontract_ry/ui_task_contract_info_panel",
ui_task_contract_item:"ui/taskcontract_ry/ui_task_contract_item",ui_task_contract_panel:"ui/taskcontract_ry/ui_task_contract_panel",
ui_task_contract_recover_panel:"ui/taskcontract_ry/ui_task_contract_recover_panel",ui_task_contract_select_end_panel:"ui/taskcontract_ry/ui_task_contract_select_end_panel",
ui_task_contract_select_item:"ui/taskcontract_ry/ui_task_contract_select_item",ui_task_contract_select_panel:"ui/taskcontract_ry/ui_task_contract_select_panel",
ui_task_mainui_contract_panel:"ui/taskcontract_ry/ui_task_mainui_contract_panel",ui_npchead_item:"ui/teamtask/ui_npchead_item",
ui_npchead_mainpanel:"ui/teamtask/ui_npchead_mainpanel",ui_tipsqueue_bagitemeffect:"ui/tipsqueue/ui_tipsqueue_bagitemeffect",
ui_tipsqueue_fathertip:"ui/tipsqueue/ui_tipsqueue_fathertip",ui_topsmallmap_lineitem:"ui/topsmallmap/changeline/ui_topsmallmap_lineitem",
ui_topsmallmap_linepanel:"ui/topsmallmap/changeline/ui_topsmallmap_linepanel",ui_topsmallmap_mappanel:"ui/topsmallmap/mappanel/ui_topsmallmap_mappanel",
ui_smallmap_levep_tips_ry:"ui/topsmallmap/ui_smallmap_levep_tips_ry",ui_smallmapbosstip:"ui/topsmallmap/ui_smallmapbosstip",
ui_smallmapmonstertip:"ui/topsmallmap/ui_smallmapmonstertip",ui_topsmallmap_bosschallenge_view:"ui/topsmallmap/ui_topsmallmap_bosschallenge_view",
ui_topsmallmap_bossitem:"ui/topsmallmap/ui_topsmallmap_bossitem",ui_topsmallmap_crossbosschallenge_view:"ui/topsmallmap/ui_topsmallmap_crossbosschallenge_view",
ui_topsmallmap_crossbossitem_ry:"ui/topsmallmap/ui_topsmallmap_crossbossitem_ry",ui_topsmallmap_currentmapinfoitem:"ui/topsmallmap/ui_topsmallmap_currentmapinfoitem",
ui_topsmallmap_currentmapinfoitem_t:"ui/topsmallmap/ui_topsmallmap_currentmapinfoitem_t",
ui_topsmallmap_currentmaplinemenuitem_ry:"ui/topsmallmap/ui_topsmallmap_currentmaplinemenuitem_ry",ui_topsmallmap_endpoint:"ui/topsmallmap/ui_topsmallmap_endpoint",
ui_topsmallmap_flyItem:"ui/topsmallmap/ui_topsmallmap_flyItem",ui_topsmallmap_gate_conetpoint:"ui/topsmallmap/ui_topsmallmap_gate_conetpoint",
ui_topsmallmap_gate_info_ry:"ui/topsmallmap/ui_topsmallmap_gate_info_ry",ui_topsmallmap_gate_info_tip:"ui/topsmallmap/ui_topsmallmap_gate_info_tip",
ui_topsmallmap_goldmonsteritem:"ui/topsmallmap/ui_topsmallmap_goldmonsteritem",ui_topsmallmap_mainmap:"ui/topsmallmap/ui_topsmallmap_mainmap",
ui_topsmallmap_mainmap_02:"ui/topsmallmap/ui_topsmallmap_mainmap_02",ui_topsmallmap_mapicon:"ui/topsmallmap/ui_topsmallmap_mapicon",
ui_topsmallmap_miracle_obj_item:"ui/topsmallmap/ui_topsmallmap_miracle_obj_item",ui_topsmallmap_monsterinfo:"ui/topsmallmap/ui_topsmallmap_monsterinfo",
ui_topsmallmap_monsterinfo_tip:"ui/topsmallmap/ui_topsmallmap_monsterinfo_tip",ui_topsmallmap_monsterinfopanel:"ui/topsmallmap/ui_topsmallmap_monsterinfopanel",
ui_topsmallmap_obj_item:"ui/topsmallmap/ui_topsmallmap_obj_item",ui_topsmallmap_point:"ui/topsmallmap/ui_topsmallmap_point",
ui_topsmallmap_radar:"ui/topsmallmap/ui_topsmallmap_radar",ui_topsmallmap_radarbossitem:"ui/topsmallmap/ui_topsmallmap_radarbossitem",
ui_topsmallmap_radarendpoint:"ui/topsmallmap/ui_topsmallmap_radarendpoint",ui_topsmallmap_radargoldmonsteritem:"ui/topsmallmap/ui_topsmallmap_radargoldmonsteritem",
ui_topsmallmap_radartaskitem:"ui/topsmallmap/ui_topsmallmap_radartaskitem",ui_topsmallmap_radartransferitem:"ui/topsmallmap/ui_topsmallmap_radartransferitem",
ui_topsmallmap_relivepointitem:"ui/topsmallmap/ui_topsmallmap_relivepointitem",ui_topsmallmap_siegebuilditem:"ui/topsmallmap/ui_topsmallmap_siegebuilditem",
ui_topsmallmap_teamitem:"ui/topsmallmap/ui_topsmallmap_teamitem",ui_topsmallmap_textitem:"ui/topsmallmap/ui_topsmallmap_textitem",
ui_topsmallmap_topmappanel:"ui/topsmallmap/ui_topsmallmap_topmappanel",ui_topsmallmap_transferitem:"ui/topsmallmap/ui_topsmallmap_transferitem",
ui_topsmallmap_unlock_view_ry:"ui/topsmallmap/ui_topsmallmap_unlock_view_ry",ui_topsmallmap_updef_item:"ui/topsmallmap/ui_topsmallmap_updef_item",
ui_topsmallmap_updef_panel:"ui/topsmallmap/ui_topsmallmap_updef_panel",ui_topsmallmap_worldmapsubitem:"ui/topsmallmap/ui_topsmallmap_worldmapsubitem",
ui_topsmallmap_worldunlockeffect:"ui/topsmallmap/ui_topsmallmap_worldunlockeffect",ui_world_map_gate_item_ry:"ui/topsmallmap/ui_world_map_gate_item_ry",
ui_topsmallmap_world_expitem:"ui/topsmallmap/worldexp/ui_topsmallmap_world_expitem",ui_topsmallmap_world_expview:"ui/topsmallmap/worldexp/ui_topsmallmap_world_expview",
ui_tradingmaket_logview:"ui/tradingmarket/ui_tradingmaket_logview",ui_tradingmarket_attentionitem:"ui/tradingmarket/ui_tradingmarket_attentionitem",
ui_tradingmarket_attentionpanel:"ui/tradingmarket/ui_tradingmarket_attentionpanel",ui_tradingmarket_buyview:"ui/tradingmarket/ui_tradingmarket_buyview",
ui_tradingmarket_logitem:"ui/tradingmarket/ui_tradingmarket_logitem",ui_tradingmarket_logpanel:"ui/tradingmarket/ui_tradingmarket_logpanel",
ui_tradingmarket_mainview:"ui/tradingmarket/ui_tradingmarket_mainview",ui_tradingmarket_operation:"ui/tradingmarket/ui_tradingmarket_operation",
ui_tradingmarket_sellview:"ui/tradingmarket/ui_tradingmarket_sellview",ui_tradingmarket_tipview:"ui/tradingmarket/ui_tradingmarket_tipview",
ui_tradingmarketview_treetitleitem:"ui/tradingmarket/ui_tradingmarketview_treetitleitem",ui_tradingmask_buyitem:"ui/tradingmarket/ui_tradingmask_buyitem",
ui_transjob_branch_select:"ui/transjob/ui_transjob_branch_select",ui_transjob_branch_select_skill:"ui/transjob/ui_transjob_branch_select_skill",
ui_transjob_getskill_icon:"ui/transjob/ui_transjob_getskill_icon",ui_transjob_getskill_panel:"ui/transjob/ui_transjob_getskill_panel",
ui_transjob_job_icon:"ui/transjob/ui_transjob_job_icon",ui_transjob_mainui_icon:"ui/transjob/ui_transjob_mainui_icon",ui_transjob_select_view:"ui/transjob/ui_transjob_select_view",
ui_transjob_skill_descItem:"ui/transjob/ui_transjob_skill_descItem",ui_transjob_skill_icon:"ui/transjob/ui_transjob_skill_icon",ui_transjob_view:"ui/transjob/ui_transjob_view",
ui_transjob_view_skillitem:"ui/transjob/ui_transjob_view_skillitem",ui_transjob_view_taskitem:"ui/transjob/ui_transjob_view_taskitem",
ui_bossassist_assisting:"ui/treasure/bossassist/ui_bossassist_assisting",ui_bossassist_item:"ui/treasure/bossassist/ui_bossassist_item",
ui_bossassist_item2:"ui/treasure/bossassist/ui_bossassist_item2",ui_bossassist_successpanel:"ui/treasure/bossassist/ui_bossassist_successpanel",
ui_bossassistpanel:"ui/treasure/bossassist/ui_bossassistpanel",ui_bossassisttip:"ui/treasure/bossassist/ui_bossassisttip",
ui_ancient_bosslist_item:"ui/treasure/ui_ancient_bosslist_item",ui_buybattleboss_tip:"ui/treasure/ui_buybattleboss_tip",
ui_rydunboss_defeatpanel:"ui/treasure/ui_rydunboss_defeatpanel",ui_rydunboss_successpanel:"ui/treasure/ui_rydunboss_successpanel",
ui_select_dun_times_item:"ui/treasure/ui_select_dun_times_item",ui_treasure_bossdropitem:"ui/treasure/ui_treasure_bossdropitem",
ui_treasure_bossdropitem_big:"ui/treasure/ui_treasure_bossdropitem_big",ui_treasure_bosshometip:"ui/treasure/ui_treasure_bosshometip",
ui_treasure_dropinfo:"ui/treasure/ui_treasure_dropinfo",ui_treasure_dropview:"ui/treasure/ui_treasure_dropview",ui_treasure_dunview_ry:"ui/treasure/ui_treasure_dunview_ry",
ui_treasure_karima_relivepanel:"ui/treasure/ui_treasure_karima_relivepanel",ui_treasure_karima_ry:"ui/treasure/ui_treasure_karima_ry",
ui_treasure_karima_staritem:"ui/treasure/ui_treasure_karima_staritem",ui_treasure_karima_starview:"ui/treasure/ui_treasure_karima_starview",
ui_treasure_karimaitem_ry:"ui/treasure/ui_treasure_karimaitem_ry",ui_treasure_karimapopitem:"ui/treasure/ui_treasure_karimapopitem",ui_treasure_tomb:"ui/treasure/ui_treasure_tomb",
ui_treasure_v1pbossruletip:"ui/treasure/ui_treasure_v1pbossruletip",ui_treasure_vbossitem:"ui/treasure/ui_treasure_vbossitem",
ui_treasure_vbossitem_left:"ui/treasure/ui_treasure_vbossitem_left",ui_treasure_vbossitem_small:"ui/treasure/ui_treasure_vbossitem_small",
ui_treasure_vbview:"ui/treasure/ui_treasure_vbview",ui_treasure_wbossitem_ry:"ui/treasure/ui_treasure_wbossitem_ry",
ui_treasure_wbview_boss_show_item:"ui/treasure/ui_treasure_wbview_boss_show_item",ui_treasure_wbview_ry:"ui/treasure/ui_treasure_wbview_ry",
ui_treasure_worldbossruletip:"ui/treasure/ui_treasure_worldbossruletip",ui_treasure_worldboss_extrarewardinfo_ry:"ui/treasure/worldboss/ui_treasure_worldboss_extrarewardinfo_ry",
ui_treasure_worldboss_extrasuccessview:"ui/treasure/worldboss/ui_treasure_worldboss_extrasuccessview",
ui_treasure_worldboss_flyeffect_ry:"ui/treasure/worldboss/ui_treasure_worldboss_flyeffect_ry",
ui_treasure_worldboss_flyitem_ry:"ui/treasure/worldboss/ui_treasure_worldboss_flyitem_ry",
ui_treasure_worldboss_normalsuccessview:"ui/treasure/worldboss/ui_treasure_worldboss_normalsuccessview",ui_treausre_bossshowitem:"ui/treasure/worldboss/ui_treausre_bossshowitem",
ui_upLoadLogItem:"ui/upLoadLog/ui_upLoadLogItem",ui_upLoadLogView:"ui/upLoadLog/ui_upLoadLogView",ui_vitality_calendar_item_ry:"ui/vitality/ui_vitality_calendar_item_ry",
ui_vitality_calendar_itemcell:"ui/vitality/ui_vitality_calendar_itemcell",ui_dailyrecharge_item:"ui/welfare/ui_dailyrecharge_item",
ui_dailyrecharge_view:"ui/welfare/ui_dailyrecharge_view",ui_fighttoken_getreward_tippanel:"ui/welfare/ui_fighttoken_getreward_tippanel",
ui_monthcard_view:"ui/welfare/ui_monthcard_view",ui_redpacket_panel:"ui/welfare/ui_redpacket_panel",ui_welfara_advancefighttokentip:"ui/welfare/ui_welfara_advancefighttokentip",
ui_welfara_angelfighttoken:"ui/welfare/ui_welfara_angelfighttoken",ui_welfara_angelfighttokenitem:"ui/welfare/ui_welfara_angelfighttokenitem",
ui_welfara_cdkeyview:"ui/welfare/ui_welfara_cdkeyview",ui_welfara_fighttokennormalitem:"ui/welfare/ui_welfara_fighttokennormalitem",
ui_welfara_passreward:"ui/welfare/ui_welfara_passreward",ui_welfara_passrewarditem:"ui/welfare/ui_welfara_passrewarditem",
ui_welfara_passrewardprogressitem:"ui/welfare/ui_welfara_passrewardprogressitem",ui_welfara_tiredvalue:"ui/welfare/ui_welfara_tiredvalue",
ui_welfare_daily_redpacket_view:"ui/welfare/ui_welfare_daily_redpacket_view",ui_welfare_dailytotalrecharge_baseitem:"ui/welfare/ui_welfare_dailytotalrecharge_baseitem",
ui_welfare_dailytotalrecharge_item:"ui/welfare/ui_welfare_dailytotalrecharge_item",ui_welfare_dailytotalrecharge_view:"ui/welfare/ui_welfare_dailytotalrecharge_view",
ui_welfare_levelRewardView:"ui/welfare/ui_welfare_levelRewardView",ui_welfare_levelreward_dunitem:"ui/welfare/ui_welfare_levelreward_dunitem",
ui_welfare_tabpanel:"ui/welfare/ui_welfare_tabpanel",ui_welfarelevelreward_item:"ui/welfare/ui_welfarelevelreward_item"}},40053:(e,t,i)=>{"use strict"
i.d(t,{Z:()=>s})
var n=i(46282)
const s={RyForgeModel_enhancePrefabs:[n.Z.ui_ry_forge_enhanceView,n.Z.ui_equipenhance_property],
RyForgeModel_addtionPrefabs:[n.Z.ui_ry_forge_addtionView,n.Z.ui_baseitem_bag_module,n.Z.ui_baseitem_shape_module],
RyForgeModel_equipEquipRefinePrefabs:[n.Z.ui_ry_forge_equiprefineview],
RyForgeModel_equipAdvancePrefabs:[n.Z.ui_ry_equipadvance_panel_new,n.Z.ui_ry_equipadvance_consumeitem,n.Z.ui_ry_compound_matitem,n.Z.ui_equiptip_excellenceattr],
RyForgeModel_wingRefinePrefabs:[n.Z.ui_ry_forge_wingRefineView],RyForgeModel_addLuckyPrefabs:[n.Z.ui_ry_forge_luckyAddView],
RyForgeModel_metagemsPrefabs:[n.Z.ui_ry_forge_metagemsview],
RyForgeModel_basePrefabs:[n.Z.ui_ry_forge_metagems_box_view,n.Z.ui_ry_forge_metagems_tips,n.Z.ui_forge_luck_property_ry,n.Z.ui_ry_forge_wayItem,n.Z.ui_ry_forge_enhancesuccess,n.Z.ui_equipenhance_property_success,n.Z.ui_ry_forge_metagems_blessactive_view],
RyForgeEquipListItem_baseItemPrefabs:[n.Z.ui_baseitem_base_module,n.Z.ui_baseitem_bag2_module,n.Z.ui_baseitem_equip_module,n.Z.ui_baseitem_element_module,n.Z.ui_baseitem_elecarve_module,n.Z.ui_baseitem_swapeffect_module,n.Z.ui_baseitem_glod_diamond_module,n.Z.ui_baseitem,n.Z.ui_ry_forge_metagems_item,n.Z.ui_ry_forge_metagems_baseitem],
WelfareHallPanel_basePrefabs:[n.Z.ui_welfare_levelRewardView,n.Z.ui_welfare_dailytotalrecharge_view,n.Z.ui_activity_lottery_view,n.Z.ui_monthcard_view,n.Z.ui_dailyrecharge_view,n.Z.ui_welfara_passreward,n.Z.ui_welfara_angelfighttoken,n.Z.ui_welfare_daily_redpacket_view,n.Z.ui_welfara_tiredvalue],
BaseItem_ry_basePrefabs:[n.Z.ui_baseitem_base_module,n.Z.ui_baseitem_bag2_module,n.Z.ui_baseitem_equip_module,n.Z.ui_baseitem_element_module,n.Z.ui_baseitem_elecarve_module,n.Z.ui_baseitem_swapeffect_module,n.Z.ui_baseitem_skilllearn_module,n.Z.ui_baseitem_glod_diamond_module,n.Z.ui_ry_forge_metagems_max_property,n.Z.ui_surface_fashionview_ry,n.Z.ui_surface_fashionattrview_ry,n.Z.ui_surface_fashioncabinetview_ry],
CharacterTopView_basePrefabs:[n.Z.CharacterPanel,n.Z.ui_baseitem,n.Z.ui_ry_right_tab,n.Z.ui_ry_right_tab],
Character_Prefabs:[n.Z.ui_characterui_baseinfoui,n.Z.ui_characterui_characterview,n.Z.ui_characterui_correctui,n.Z.ui_character_titleview,n.Z.ui_characterui_detailinfoitem_new],
Character_horse_Prefabs:[n.Z.ui_horse_mainview,n.Z.ui_horse_item,n.Z.ui_horse_ridingview,n.Z.ui_horse_riding_item,n.Z.ui_horse_riding_itemGroup],
Character_divine_Prefabs:[n.Z.ui_divine_panel,n.Z.ui_divine_panel,n.Z.ui_divine_eff2,n.Z.ui_divine_eff3,n.Z.ui_divine_eff4,n.Z.ui_divine_code_view],
Character_gem_Prefabs:[n.Z.ui_gem_view,n.Z.ui_gem_part_item,n.Z.ui_gem_preview_item,n.Z.ui_gem_attr_item],RySkillMain_Prefabs:[n.Z.ui_ry_skill_main_view,n.Z.ui_ry_skill_job_raw],
RyRebirthTalent_Prefabs:[n.Z.ui_mastertalent_panel],RyFasterFightPanel_basePrefabs:[n.Z.ui_level_slider_ry],
GameGmCreateRole_basePrefabe:[n.Z.ui_game_gm_createrole_view,n.Z.ui_game_gm_createrole_icon],
GameGmAuto_basePrefabe:[n.Z.ui_game_gm_auto_view,n.Z.ui_game_gm_auto_exe_view,n.Z.ui_game_gm_combox,n.Z.ui_game_gm_combox_item,n.Z.ui_game_gm_switch,n.Z.ui_game_gm_text_combox,n.Z.ui_game_gm_tog,n.Z.ui_game_gm_auto_pass_point,n.Z.ui_game_gm_auto_hook_comp,n.Z.ui_game_gm_auto_paodian_comp,n.Z.ui_game_gm_reward_comp,n.Z.ui_game_gm_bountytask_comp],
GameGmEquip_basePrefabe:[n.Z.ui_game_gm_equip_unlock_view,n.Z.ui_game_gm_equip_unlock_item,n.Z.ui_game_gm_equip_show_item],
MayaTreasureView_basePrefabs:[n.Z.ui_maya_hunttreasure_item,n.Z.ui_maya_hunttreasure_view,n.Z.ui_maya_hunttreasure_view_02,n.Z.ui_maya_treasure_item,n.Z.ui_mayaexchange_item,n.Z.ui_mayaexchange_tip,n.Z.ui_mayaexchange_view,n.Z.ui_mayatreasure_panel,n.Z.ui_mayatreasure_result_item,n.Z.ui_mayatreasure_result_panel,n.Z.ui_mayatreasure_result_panel_2,n.Z.ui_horse_item,n.Z.ui_divine_panel,n.Z.ui_divine_eff2,n.Z.ui_divine_eff3,n.Z.ui_divine_eff4,n.Z.ui_divine_code_view],
AllianveQuestion_basePrefabe:[n.Z.ui_alliance_questionview_ry,n.Z.ui_alliance_question_rankitem_ry,n.Z.ui_alliance_question_chatview_ry,n.Z.ui_alliance_question_chat_totalcell,n.Z.ui_chat_personcell],
AllianceMainView_basePrefabe:[n.Z.ui_alliance_overview,n.Z.ui_alliance_membersview,n.Z.ui_alliance_build_itemContainer,n.Z.ui_alliance_chuangong_ry],
HonorKingMainPanel_basePrefabe:[n.Z.ui_honorkings_attachitem,n.Z.ui_honorkings_attachview,n.Z.ui_honorkings_myrankitem,n.Z.ui_honorkings_phasegriditem,n.Z.ui_honorkings_phasetitleitem,n.Z.ui_honorkings_rankitem,n.Z.ui_honorkings_rankview,n.Z.ui_honorkings_tab],
SettingMianView_basePrefabe:[n.Z.ui_setting_settinghangpanel,n.Z.ui_setting_systempanel,n.Z.ui_setting_chataudiopanel,n.Z.ui_setting_userinfopanel],
RyTipCompFactory_AllTipCompPath:[n.Z.ui_top_container,n.Z.ui_equip_topcontainer],
RyTipCompFactory_AllTipTxteCompPath:[n.Z.ui_descObj,n.Z.ui_btns_container,n.Z.ui_scroller_container,n.Z.ui_baseModule,n.Z.ui_priceObj,n.Z.ui_equiptip_boardtip,n.Z.ui_equip_demandModule,n.Z.ui_rewardShowObj,n.Z.ui_excellenceModule,n.Z.ui_luckyModule,n.Z.ui_horse_baseprop_module,n.Z.ui_horse_skill_module,n.Z.ui_descChannelObj,n.Z.ui_timeModule,n.Z.ui_suitModule,n.Z.ui_demandModule,n.Z.ui_itemtip_demanditem,n.Z.ui_useLimitModule,n.Z.ui_equip_skill_module,n.Z.ui_sacred_attr_module,n.Z.ui_equiptip_role_icon_list]
}},82662:(e,t,i)=>{"use strict"
i.d(t,{b:()=>n})
const n={AlertV:"AlertV",AlertV1:"AlertV1",TabCommonPanel:"TabCommonPanel",BagView:"BagView",AniTestView1:"AniTestView1",MainViewPanel:"MainViewPanel",
ChatShowPanel:"ChatShowPanel",MainSkillListPanel:"MainSkillListPanel",TopSmallMapView:"TopSmallMapView",CharacterPanel:"CharacterPanel",
CharacterBaseinfoView:"CharacterBaseinfoView",ItemTip:"ItemTip",EquipTip:"EquipTip",CurrencyBar:"CurrencyBar",PandoraSelectPanel:"PandoraSelectPanel",
RyPandoraTipsView:"RyPandoraTipsView",eCommonHintPanel:"eCommonHintPanel",InfoTipView:"InfoTipView",GmView:"GmView",BatchUserAlert:"BatchUserAlert",
InputNumberView:"InputNumberView",SystemCommonMessage:"SystemCommonMessage",CharacterTopView:"CharacterTopView",RyForgeView:"RyForgeView",TreasurePanel:"TreasurePanel",
WelfareHallPanel:"WelfareHallPanel",RySkillPanel:"RySkillPanel",RySkillTipsView:"RySkillTipsView",GemView:"GemView",GemSelectView:"GemSelectView",GameGM:"GameGMMainPanel",
RyCommonCompoundView:"RyCommonCompoundView",HorseSelectView:"HorseSelectView",HorseMainView:"HorseMainView",HorseDress:"HorseDress",HorseItemTipPanel:"HorseItemTipPanel",
HorseSkillTipView:"HorseSkillTipView",HorseSkillMainView:"HorseSkillMainView",HorseSkillAddView:"HorseSkillAddView",HorseRidingView:"HorseRidingView",
AllianceTaskView:"AllianceTaskView",KarimaBossView:"KarimaBossView",KarimaStarView:"KarimaStarView",TestPanel:"TestPanel",SystemCommonMessage2:"SystemCommonMessage2"}},
45480:(e,t,i)=>{"use strict"
i(75331),i(11210),i(48975),i(22948),i(82874),i(31381)
var n=i(98800),s=i(59377),a=(i(33822),i(57121),i(22919),i(48748),i(19854),i(76164),i(59475),i(50717),i(62265),i(45404)),r=i(73206),l=(i(20738),i(63454),
i(97461)),o=i(36241),_=(i(26396),i(26697),i(6700)),u=i(13687),h=(i(58207),i(14236),i(45549),i(83995),i(3838),i(44255),i(62085),i(17705),i(60130)),c=(i(43133),i(67292),
i(3522)),d=(i(11355),i(73136),i(70123)),m=(i(2597),i(10288),i(30951),i(19973),i(87918),i(77399)),p=(i(34334),i(53423),i(10602),i(48475),i(72434),i(68857),i(12745),i(54705),
i(96164),i(37899),i(25727),i(56387),i(53810),i(364),i(24536),i(53525),i(10938),i(52364),i(8081),i(64929),i(95790),i(20699),i(94148),i(86349),i(88400),i(53903),i(73385),i(73889),
i(34603),i(74064),i(67172),i(67585),i(85430),i(80486),i(80160),i(53610),i(54516),i(6385),i(23476),i(6345),i(43567),i(74207),i(93320),i(26376),i(65080),i(27792),i(11816),i(19161),
i(64254),i(69138),i(16048),i(43042),i(60076),i(11570),i(25582),i(7122),i(23757),i(18312),i(45158),i(17272),i(64867),i(75963),i(21357),i(1422),i(10793),i(17444),i(8308),i(6858),
i(1023),i(18824),i(77077),i(50560),i(29099),i(26314),i(81973),i(93353),i(76108),i(81513),i(86124),i(18877),i(98833),i(28420),i(34855),i(4469),i(87017),i(1170),i(91422),i(6403),
i(14283),i(5280),i(2099),i(85054),i(88055),i(79532),i(34415),i(21554)),g=(i(83159),i(54223),i(66488),i(67745),i(14665),i(75696)),I=(i(42029),i(923),i(86601),i(86549),i(11562),
i(13931),i(19175),i(73571),i(93590),i(7118),i(24483),i(28169),i(70187),i(94753),i(75380),i(36942),i(83234),i(42894),i(40207),i(27964),i(92984)),E=(i(65029),i(18798),i(75145),
i(59756),i(870),i(60706),i(86399),i(952),i(78592),i(54151),i(54798),i(15907),i(35894),i(13833),i(76466),i(80799),i(92606),i(33864),i(17782),i(23459),i(32080),i(68323),i(8664),
i(19381),i(43263),i(94533),i(64290),i(89543),i(55104),i(7182),i(79335),i(49413),i(38314),i(18449),i(24499),i(66999),i(69688),i(96464),i(50018),i(4603),i(50277),i(54415),i(62342),
i(89029),i(65772),i(8802),i(8013),i(54490),i(8079),i(40162),i(91420),i(11158),i(98606),i(96103),i(8006),i(2129),i(25773),i(29839)),C=(i(70478),i(78417),i(85770)),S=(i(60776),
i(19883),i(14228),i(32858),i(33320),i(86209)),T=(i(58097),i(85001),i(98673),i(90034),i(42660),i(85976),i(23167),i(33938),i(61265),i(84938),i(88206),i(52946),i(76076),i(28397),
i(79062),i(95989),i(14857),i(95760),i(83263),i(70354),i(8933),i(75143),i(46136),i(22982),i(98043),i(85056),i(27721),i(81705),i(93093),i(22760),i(65048),i(16945),i(54220),i(69846),
i(52833),i(7571),i(90690),i(2837),i(81031),i(13476),i(91897)),f=(i(93002),i(81534),i(56959),i(90330),i(21987),i(6667),i(14435),i(36091),i(19678),i(37924),i(17007),i(84211),
i(65110),i(86370),i(35902),i(24205),i(83651),i(36659),i(45346),i(69633),i(56647),i(73504),i(205),i(93583),i(28462),i(72779),i(4729),i(60128),i(40514),i(75499),i(99519),i(39646),
i(95970),i(23526),i(63859),i(73543),i(84787),i(88316),i(53520),i(29801),i(9291),i(31413),i(67170),i(5336),i(43253),i(37732),i(89895),i(12003),i(34813),i(59707),i(4193),i(55575),
i(53265),i(92131),i(55415),i(60697),i(11449),i(19512),i(35285),i(57942),i(46046),i(90879),i(5435),i(64514),i(31726),i(21543),i(96658),i(87996),i(75199),i(92036),i(77289),i(28224),
i(86012),i(84097),i(69167),i(90561),i(44294),i(58797),i(65136),i(22714),i(63346),i(34510),i(44127),i(37791),i(24160),i(44439),i(10965),i(45482),i(55617),i(52547),i(2660),i(83765),
i(83353),i(58563),i(34948),i(9647),i(93334),i(64489),i(36127),i(57838),i(98996),i(24468),i(92545),i(84357),i(21569),i(68645),i(9032),i(18281),i(65216),i(81624),i(26331),i(95435),
i(66810),i(82146),i(1851),i(40466),i(2970),i(75256),i(84223),i(50520),i(76944),i(72081),i(80226),i(22326),i(2065),i(46467),i(20921),i(88626),i(90140),i(56389),i(88147),i(35875),
i(96892),i(93089),i(48952),i(6356),i(44599),i(82214),i(97210),i(59116),i(47324),i(66479),i(53189),i(92625),i(54977),i(98165),i(58e3),i(27673),i(74342),i(47824),i(87414),i(34074),
i(14600),i(41997),i(52787),i(435),i(93843),i(5732),i(73833),i(42105),i(32206),i(50323),i(62967),i(18258),i(84535),i(5981),i(84825),i(75708),i(85201),i(20935),i(49499),i(78833),
i(76553),i(71672),i(71610),i(44425),i(17574),i(8264),i(99866),i(99047),i(9348),i(94864),i(50109),i(55681),i(1969),i(78401),i(79119),i(24820),i(35183),i(92171),i(35563),i(14678),
i(45473),i(12931),i(22435),i(88321),i(80195),i(5935),i(39324),i(84278),i(18172),i(27508),i(65714),i(24769),i(80965),i(35727),i(80646),i(5783),i(82304),i(92690),i(87940),i(60674),
i(24656),i(17813),i(91336),i(37218),i(7881),i(40573),i(14534),i(85743),i(61540),i(56659),i(79562),i(78025),i(96747),i(9758),i(78808),i(77826),i(5245),i(44509),i(16650),i(70384),
i(46554),i(28948),i(13969),i(92863),i(28019),i(88997),i(94400),i(36860),i(26948),i(94150),i(74165),i(61122),i(8309),i(62834),i(7953),i(60710),i(35025),i(48481)),A=(i(60642),
i(46235),i(76488),i(10473),i(20007),i(35878),i(68583),i(16732),i(3169),i(25239),i(86953),i(6156),i(45207),i(31485),i(67836),i(50138),i(90722),i(73887),i(89547),i(45701),i(66103),
i(32460),i(53993),i(75665),i(56614),i(49878),i(38486),i(89771),i(50495),i(29298),i(82211),i(48395),i(81108),i(87502),i(67540),i(75149),i(42068),i(98523),i(62443),i(83473),i(13152),
i(12389),i(24738),i(84484),i(55810),i(41458),i(93709),i(18594),i(34532),i(41854),i(89332),i(94879),i(45736),i(87183),i(16086),i(41331),i(21988),i(77183),i(76045),i(94969),i(86817),
i(33888),i(56415),i(95645),i(58520),i(67246),i(90237),i(22064),i(24928),i(25119),i(47638),i(4478),i(67859),i(89476),i(68291),i(78085),i(58058),i(86447),i(2197),i(15604),i(68402),
i(66776),i(13542),i(45136),i(19429),i(2230),i(35278),i(59615),i(7101),i(2523),i(95165),i(86210),i(38403),i(28888),i(21978),i(32847),i(44865),i(42755),i(87572),i(21830),i(83438),
i(83091),i(65012),i(66825),i(6322),i(74457),i(34975),i(29),i(77519),i(93504),i(98602),i(50324),i(59844),i(71702),i(40726),i(36230),i(30488),i(84478),i(36835),i(84183),i(23009),
i(99197),i(12755),i(83897),i(89799),i(29843),i(80727),i(62143),i(92232),i(75006),i(29273),i(14093),i(45515),i(25673),i(67147),i(82505),i(25434),i(75422),i(3451),i(42518),i(61420),
i(78309),i(81028),i(59266),i(61303),i(36026),i(60943),i(73993),i(97466),i(33225),i(43876),i(29893),i(41596),i(42867),i(97479),i(41742),i(15559),i(79638),i(48471),i(39596),i(24593),
i(53246),i(72739),i(70012),i(40331),i(80881),i(29743),i(58077),i(17210),i(700),i(75755),i(89683),i(58458),i(48580),i(96685),i(62227),i(56225),i(52777),i(50571),i(42896),i(99733),
i(79924),i(28054),i(58385),i(40923),i(1930),i(83813),i(73986),i(23418),i(74244),i(34778),i(34321),i(81669),i(37328),i(39873),i(58065),i(4137),i(22126),i(76698),i(83277),i(71331),
i(25064),i(96609),i(98216),i(40995),i(29580),i(28128),i(84421),i(39652),i(60495),i(32337),i(95490),i(90336),i(54785),i(25549),i(90393),i(45745),i(96077),i(46109),i(29646),i(86312),
i(12660),i(60840),i(36186),i(78837),i(52482),i(68620),i(41361),i(46915),i(59119),i(84241),i(10401),i(13031),i(17343),i(22599),i(70562),i(78664),i(60080),i(26202),i(1648),i(43462),
i(96161),i(50236),i(48703),i(21444),i(20460),i(68173),i(29847),i(85464),i(53037),i(88162),i(30189),i(12967),i(72208),i(66176),i(18161),i(85079),i(14990),i(34720),i(15639),i(3701),
i(88485),i(99048),i(94487),i(16871),i(51682),i(42162),i(90916),i(59289),i(99738),i(81411),i(95123),i(17559),i(46442),i(34576),i(31873),i(60087),i(64171),i(83907),i(42463),i(66806),
i(52732),i(8394),i(25646),i(65678),i(57472),i(71447),i(95767),i(79577),i(60591),i(81421),i(11183),i(5038),i(48299),i(90936),i(12959),i(58379),i(32927),i(273),i(53145),i(6111),
i(97321),i(39020),i(90758),i(33772),i(67187),i(40984),i(20510),i(62845),i(84850),i(48040),i(43392),i(19464),i(63287),i(60289),i(61868),i(564),i(51254),i(79122),i(60238),i(82223),
i(35730),i(62126),i(26227),i(76404),i(64607),i(34002),i(45690),i(63216),i(77538),i(80988),i(44585),i(57531),i(84419),i(81872),i(10802),i(47773),i(45969),i(88351),i(11362),i(49876),
i(24774),i(50866),i(23951),i(82557),i(33245),i(13715),i(81511),i(93737),i(49646),i(54108),i(30680),i(8769),i(4282),i(55355),i(58360),i(14999),i(43145),i(21153),i(77709),i(61284),
i(17781),i(65600),i(45108),i(27611),i(8129),i(82536),i(10354),i(82668),i(14266),i(21851),i(30459),i(32887),i(11159),i(21417),i(33820),i(5996),i(40863),i(34527),i(66918),i(29577),
i(9633),i(36166),i(62652),i(51299),i(89915),i(65069),i(3755),i(59596),i(74328),i(77599),i(24730),i(60983),i(62091),i(68069),i(7152),i(48875),i(29883),i(68866),i(12102),i(95906),
i(94020),i(78419),i(8350),i(69877),i(93929),i(85335),i(10906),i(61255),i(99492),i(97701),i(46880),i(69650),i(1250),i(75652),i(38003),i(1916),i(86678),i(10136),i(84061),i(1352),
i(75874),i(15407),i(60631),i(56613),i(68963),i(18986),i(5187),i(55712),i(45802),i(55825),i(79216),i(56796),i(96878),i(92810),i(4254),i(66592),i(27527),i(33345),i(21237),i(67489),
i(32801),i(24733),i(48411),i(90409),i(62101),i(82661),i(28018),i(14591),i(5436),i(83572),i(82142),i(35943),i(53729),i(73896),i(74259),i(47616),i(63175),i(29961),i(12068),i(6525),
i(88757),i(29126),i(68253),i(37167),i(96669),i(87893),i(45471),i(17296),i(32008),i(33048),i(74663),i(91135),i(78730),i(46590),i(90522),i(40451),i(32441),i(94266),i(45275),i(48412),
i(26449),i(44683),i(54464),i(43769),i(22938),i(65627),i(66910),i(12234),i(59521),i(39241),i(21341),i(41938),i(80661),i(21365),i(12653),i(55025),i(18797),i(8010),i(17259),i(26770),
i(35517),i(23539),i(35868),i(61519),i(61536),i(53386),i(97935),i(51913),i(42809),i(56411),i(67825),i(81708),i(97656),i(87645),i(47635),i(33029),i(2430),i(56530),i(35619),i(28430),
i(73321),i(81358),i(39491),i(38119),i(68519),i(48008),i(77485),i(36923),i(16707),i(55212),i(67716),i(2955),i(13234),i(67962),i(17166),i(82781),i(85124),i(28964),i(49542),i(71891),
i(92940),i(89040),i(79399),i(3376),i(60344),i(9847),i(75488)),y=(i(17653),i(64027)),R=i(9959),D=(i(93522),i(73470)),w=(i(27422),i(78847),i(92252),i(85562),i(35731),i(22477),
i(90423),i(15632),i(90913),i(96012),i(61952),i(77195),i(36079),i(18758),i(68841),i(13950),i(96061),i(24398),i(36576),i(61731),i(7521),i(45913),i(98397),i(69764),i(7063),i(93675),
i(8969),i(19263),i(79873),i(93142),i(13290),i(54875),i(14695),i(50870),i(76577),i(59514),i(54603),i(36969),i(54069),i(36042),i(57949),i(16960),i(4776),i(33071),i(84875),i(37869),
i(92476),i(83568),i(36328),i(88518),i(48275),i(63574),i(83406),i(88410),i(91053),i(70843),i(29974),i(65867),i(68801),i(49353),i(75965),i(30276),i(52213),i(21103),i(5399),i(62164),
i(32457),i(88660),i(36212),i(86554),i(30723),i(60310),i(62506),i(61522),i(77532),i(53820),i(29134),i(1248),i(47870),i(49691),i(59816),i(64093),i(76737),i(39027),i(51101),i(63280),
i(93486),i(44937),i(86275),i(17923),i(39856),i(2938),i(70400),i(88215),i(78806),i(20353),i(12651),i(41497),i(34976)),L=(i(4627),i(76029),i(94323),i(25669),i(21524),i(78556),
i(19289),i(76151),i(88692),i(17508),i(15633),i(8921),i(2069),i(31259),i(47990),i(52837),i(46703),i(95922),i(47923),i(42022),i(28319),i(49572),i(86220),i(68570),i(5093),i(74025),
i(15077),i(19273),i(37106),i(88761),i(96417),i(5250),i(17022),i(35937),i(10620),i(89399),i(53565),i(65773),i(31202),i(4098),i(49589),i(21527),i(16291),i(77935),i(23216),i(71677),
i(40171),i(84660),i(95098),i(59395),i(97873),i(47234),i(73288),i(44476),i(11144),i(51045),i(15235),i(167),i(23328),i(26367),i(31764),i(17333),i(43465),i(27509),i(30677),i(81621),
i(83317),i(27877),i(11869),i(27352),i(84974),i(1129),i(6413),i(65128),i(96624),i(44286),i(64922),i(59843),i(12952),i(3697),i(63666),i(31105),i(52073),i(56275),i(89620),i(76260),
i(31270),i(22093),i(65091),i(67951),i(5579),i(94622),i(8444),i(80173),i(34658),i(97046),i(85849),i(67317),i(97232),i(50947),i(5321),i(19164),i(76125),i(1349),i(86071),i(55535),
i(37800),i(11323),i(92948),i(17942),i(31085),i(1793),i(98973),i(26638),i(76725),i(88747),i(19587),i(45806),i(17870),i(94429),i(45631),i(46557),i(51927),i(19676),i(30666),i(40301),
i(56807),i(86033),i(62007),i(37774),i(58749),i(30160),i(25200),i(66195),i(5686),i(83046),i(6044),i(75511),i(64753),i(92190),i(36571),i(45426),i(88388),i(74674),i(76961),i(50490),
i(61140),i(18452),i(75043),i(71326),i(57446),i(54379),i(47470),i(15197),i(39269),i(17670),i(12475),i(72537),i(70982),i(56198),i(10663),i(78342),i(41694),i(35612),i(29075),i(1421),
i(43815),i(9545),i(59129),i(77398),i(2857),i(98578),i(84312),i(9887),i(85309),i(49485),i(26394),i(84625),i(42156),i(73048),i(3109),i(35011),i(80358),i(15968),i(18611),i(72641),
i(83726),i(55260),i(25651),i(11286),i(6763),i(18694),i(29857),i(54782),i(68314),i(89028),i(32e3),i(63014),i(23398),i(17011),i(84801),i(12149),i(68651),i(21790),i(64808),i(8018),
i(46475),i(72812),i(86355),i(11540),i(49642),i(80732),i(47839),i(33553),i(66959),i(72962),i(59277),i(45841),i(74369),i(72041),i(85247),i(2481),i(4781),i(67390),i(68043),i(81948),
i(94324),i(39610),i(33327),i(94543),i(54297),i(87532),i(60035),i(88824),i(69324),i(44637),i(65561),i(88523),i(76384),i(21420),i(22181),i(13453),i(63542),i(45931),i(56774),i(17912),
i(32120),i(22544),i(95870),i(49673),i(19898),i(77204),i(63418),i(77847),i(74305),i(81503),i(92841),i(85330),i(34877),i(5758),i(30362),i(73854),i(38733),i(30409),i(86407),i(58025),
i(98345),i(10703),i(76116),i(25641),i(26092),i(74381),i(30689),i(79897),i(95050),i(77316),i(41998),i(11322),i(71623),i(44928),i(86746),i(15369),i(49795),i(6192),i(20637),i(87788),
i(87061),i(72961),i(1376),i(65237),i(18e3),i(1534),i(27181),i(10920),i(46190),i(50424),i(11668),i(87211),i(96516),i(11130),i(28351),i(78238),i(4912),i(99034),i(24903),i(45226),
i(27694),i(34206),i(20904),i(25542),i(95132),i(91060),i(19777),i(56821),i(65221),i(60862),i(11425),i(17145),i(45387),i(45925),i(2269),i(57654),i(37947),i(16977),i(31953),i(34856),
i(30936),i(54664),i(36486),i(63056),i(10505),i(99740),i(72188),i(99602),i(47355),i(52834),i(10562),i(55218),i(44958),i(54305),i(12623),i(57685),i(31521),i(86849),i(79124),i(70966),
i(40161),i(84876),i(59398),i(15443),i(87817),i(93598),i(56813),i(23664),i(63170),i(91552),i(11509),i(80695),i(32779),i(78945),i(45739),i(91247),i(69743),i(1611),i(77789),i(16333),
i(24197),i(28002),i(38395),i(4645),i(19183),i(1188),i(61160),i(15831),i(57079),i(9964),i(79880),i(16280),i(94177),i(92023),i(59454),i(84767),i(17410),i(56348),i(85450),i(90099),
i(12175),i(18088),i(84066),i(99365),i(37730),i(40489),i(69759),i(92039),i(89660),i(96206),i(72911),i(6383),i(12503),i(8406),i(92896),i(95575),i(91692),i(44632),i(43292),i(34330),
i(15718),i(59713),i(41428),i(33869),i(7856),i(54095),i(12723),i(50526),i(47023),i(64629),i(42983),i(22365),i(85465),i(53931),i(80040),i(99649),i(69967),i(69615),i(76754),i(81498),
i(59594),i(82108),i(61574),i(71240),i(71114),i(25396),i(54469),i(23472),i(58987),i(46420),i(8601),i(57993),i(69600),i(90064),i(91271),i(65720),i(48905),i(36505),i(2398),i(26341),
i(76624),i(65629),i(89748),i(92890),i(35445),i(96412),i(76773),i(54420),i(25369),i(37879),i(79670),i(83152),i(26191),i(35796),i(20143),i(11153),i(73273),i(34218),i(776),i(65886),
i(70094),i(52335),i(55280),i(88453),i(25667),i(78775),i(79451),i(99828),i(16282),i(4864),i(82039),i(57411),i(3213),i(61280),i(71427),i(47149),i(43294),i(63920),i(18126),i(5334),
i(68277),i(75539),i(5309),i(79877),i(23907),i(55989),i(71386),i(8374),i(11530),i(68641),i(22377),i(13389),i(50407),i(26249),i(37795),i(39683),i(53734),i(99156),i(45174),i(19699),
i(69197),i(16769),i(17173),i(21039),i(85982),i(36001),i(60546),i(51782),i(67180),i(24835),i(50738),i(69587),i(14064),i(7113),i(87486),i(89317),i(62512),i(62810),i(89160),i(76874),
i(16189),i(2321),i(54939),i(72504),i(81338),i(89944),i(34),i(51469),i(50134),i(29830),i(44798),i(32691),i(58322),i(90045),i(98909),i(24924),i(56568),i(51100),i(12488),i(52435),
i(21660),i(23937),i(27129),i(10328),i(12712),i(92905),i(55227),i(59810),i(7790),i(12966),i(87558),i(91021),i(19636),i(85605),i(95523),i(62605),i(92962),i(99421),i(69622),i(94935),
i(94945),i(49163),i(75882),i(78297),i(84074),i(65294),i(22593),i(58552),i(110),i(25166),i(25606),i(16326),i(67764),i(32615),i(13605),i(40938),i(5946),i(72565),i(84049),
i(76887)),v=(i(75310),i(83863),i(63948),i(10231),i(24810),i(43977),i(70164),i(35135),i(86551),i(36408),i(67581),i(71867),i(86985),i(1114),i(40106),i(74110),i(37926),i(56833),
i(41143),i(17749),i(11654),i(26348)),O=(i(71842),i(10909),i(76910),i(96964)),P=(i(18753),i(70583),i(73670),i(57693),i(5988),i(71161),i(4564),i(30859),i(72942),i(30236),i(32889),
i(57148),i(35279),i(18572),i(7601)),N=(i(84632),i(69162),i(60096),i(57367),i(96713),i(8231),i(27007),i(96165),i(58306),i(4958),i(73814),i(12195),i(65504),
i(20028)),M=i(1746),b=(i(70204),i(16279),i(83900),i(26478),i(69630),i(42181),i(21267),i(2465),i(87791),i(7517),i(31896)),G=(i(63945),i(34258),i(73904),i(90715),i(65656),i(99001),
i(27120),i(93640),i(53223),i(66988),i(67877),i(51704),i(74332),i(74867),i(2574)),U=(i(6288),i(93280),i(14353),i(71822)),B=(i(97802),i(20310),i(59989),i(19581),i(74265),i(84783),
i(90122),i(4489),i(59136),i(14506),i(32242),i(62397),i(23837),i(90179),i(16215),i(84562),i(75185),i(8052),i(4519),i(36584),i(22424),i(73024),i(28155),i(76787),i(27051),i(8762),
i(5246),i(8566),i(42502),i(85625),i(83963),i(22811),i(61288),i(23598),i(65235),i(8230),i(26511),i(37559),i(18414),i(10481),i(49662),i(80148),i(52043),i(81030),i(53799),i(18593),
i(6),i(1730),i(66635),i(2312),i(70364),i(54461),i(52576),i(43434),i(502),i(26926),i(47538),i(20805),i(47166),i(36924),i(94334),i(42575),i(53698),i(98704),i(53012),i(44924),i(6237),
i(93845),i(86850),i(52053),i(81257),i(16683),i(6601),i(15007),i(96997),i(88666),i(80839),i(60340),i(45052),i(88275),i(82836),i(32934),i(25902),i(84616),i(85864),i(28034),i(25421),
i(60461),i(15995),i(78328),i(60647),i(57553),i(2561),i(16857),i(96518),i(5094),i(88375),i(739),i(99130)),k=(i(33698),i(4078),i(76293),i(64365),i(74492),i(65793),i(5727),i(48922),
i(74302),i(67605),i(2787),i(6213),i(24338),i(5968),i(65550)),F=(i(23450),i(64004),i(41321),i(58653),i(48754),i(69148),i(58056),i(71191),i(61452),i(59835),i(65963),i(34342),
i(22259),i(44744),i(85517),i(41825),i(57651),i(15601),i(78651),i(70738),i(44754),i(16950),i(79878),i(99535),i(64269),i(15337),i(93605),i(94529),i(70351),i(66957),i(30355),i(81035),
i(2487),i(53186),i(20544),i(62783),i(54695),i(91118),i(9544),i(57019),i(32298),i(51347),i(32953),i(96531),i(39793),i(32426),i(85986),i(94801),i(36041),i(36197),i(78922),i(29001),
i(21979),i(25705),i(58408),i(91322),i(5364),i(37151),i(55904),i(32527),i(10305),i(76034),i(42120),i(55986),i(93505),i(50394),i(25877),i(40718),i(13699),i(21334)),H=(i(70531),
i(54053),i(33065)),x=(i(66837),i(88934),i(34923),i(2042),i(81110),i(24087),i(8621),i(19592),i(1809),i(42650),i(46233),i(27610),i(17279),i(2229),i(52512),i(40050),i(66696),i(86258),
i(14955),i(91037),i(63563),i(6847)),V=i(83908),Y=i(46282),W=i(38045),K=i(62370),Z=i(98885),z=i(85602),q=i(92679),$=i(75439),X=i(15771),Q=i(49655),j=i(28192),J=i(67885),ee=i(9057)
class te extends((0,V.pA)(ee.x)()){constructor(...e){super(...e),this.accessId=null,this._m_handlerMgr=null}InitView(){}get m_handlerMgr(){
return this._m_handlerMgr||(this._m_handlerMgr=j.h.Get()),this._m_handlerMgr}SetData(e){this.accessId=e
const t=v.Z.Inst().getItemById(e)
this.icon.skin="atlas/huoqutujing/"+t.icon,this.name.textSet(t.name),this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.OnClickItem))}OnClickItem(){
d.W.ins.GoToAccess(this.accessId)}Clear(){}Destroy(){super.destroy()}Test1(){return!0}S_Test(){return!0}}var ie,ne=i(70850),se=i(63076),ae=i(33138)
class re extends((0,V.pA)(ee.x)()){constructor(...e){super(...e),this.canUse=!1,this.basItemData=null,this._m_handlerMgr=null}InitView(){}get m_handlerMgr(){
return this._m_handlerMgr||(this._m_handlerMgr=j.h.Get()),this._m_handlerMgr}SetData(e){this.basItemData=new se.M(e.itemId)
const t=new f.t
this.basItemData.serverData_set(t),this.ui_baseitem.SetData(this.basItemData)
const i=ae.f.Inst().getItemById(e.itemId)
this.itemNameLabel.textSet(i.name)
const n=i.Rewards_get().typevalues[0]
this.descLabel.textSet(`使用后可获得[047104]${n.value}点[-]VIP经验`)
const s=ne.g.Inst_get().GetItemNum(e.itemId)
this.itemCountLabel.textSet(""+s)
const a=i.Conditions_get().typevalues[0]
X.U.inst.model.level_get()>=(0,W.aI)(a.value)?(this.useBtn.node.SetActive(!0),this.unUseBtn.node.SetActive(!1),this.canUse=!0):(this.useBtn.node.SetActive(!1),
this.unUseBtn.node.SetActive(!0),this.unUsebtnLabel.textSet(`VIP${a.value}可使用`),this.canUse=!1),this.m_handlerMgr.AddClickEvent(this.useBtn,this.CreateDelegate(this.OnUseClick))}
OnUseClick(){if(this.canUse){const e=ne.g.Inst_get().GetItemNum(this.basItemData.modelId_get())
e>0?p.J.Inst_get().UseItemByModelId(this.basItemData.modelId_get(),e):k.y.inst.ClientSysStrMsg("道具不足")}}Clear(){}Destroy(){super.destroy()}Test1(){return!0}S_Test(){return!0}}(0,
x.s_)(Q.o.VIPExpView,Y.Z.ui_dun_exp_view).waitPrefab(J.S.modulePathList).register()(ie=class extends((0,V.Ri)()){constructor(...e){super(...e),this._m_handlerMgr=null}InitView(){
super.InitView(),this.grid.SetInitInfo("ui_dun_exp_item",null,re),this.accessGrid.SetInitInfo("ui_dun_access_item",null,te),
this.m_handlerMgr.AddClickEvent(this.btnClose,this.CreateDelegate(this.CLose)),l.i.Inst.AddEventHandler(q.g.VIP_UPDATE,this.CreateDelegate(this.UpdateView))}OnAddToScene(){
const e=$.D.getInstance().GetStringArray("VIP:CARDTYPE"),t=new z.Z
for(let i=0;i<=e.Count()-1;i++){const n=e[i],s=Z.M.Split(n,K.o.s_Arr_UNDER_CHAR_DOT)
t.Add({itemId:(0,W.aI)(s[0]),num:(0,W.aI)(s[1])})}this.grid.data_set(t),this.grid.OnReposition_set(this.CreateDelegate(this.onBaseItemLoaded)),this.topContainer.UpdateView(2)
const i=$.D.getInstance().GetIntArray("VIP:EXPUID")
this.accessGrid.data_set(i)}onBaseItemLoaded(){this.scrollView.ResetPosition()}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=j.h.Get()),this._m_handlerMgr}
UpdateView(){this.OnAddToScene()}Clear(){this.m_handlerMgr.RemoveClickEvent(this.btnClose,this.CreateDelegate(this.CLose)),
l.i.Inst.RemoveEventHandler(q.g.VIP_UPDATE,this.CreateDelegate(this.UpdateView)),super.Clear()}CLose(){X.U.inst.controller.CloseExpUseView()}Destroy(){super.destroy()}})
var le,oe=i(18998),_e=i(86133),ue=i(66788),he=i(30849),ce=i(14792),de=i(62734),me=i(70959)
oe._decorator.ccclass("VipLeftView")(le=class extends((0,V.pA)(he.C)()){constructor(...e){super(...e),this.m_model=null,this._degf_UpdateRedPointHandler=null,this.rightView=null}
_initBinder(){super._initBinder(),this._degf_UpdateRedPointHandler=()=>{this.UpdateRedPoint()}}InitView(){this.rightView=null}OnAddToScene(){this.AddOrDelEvent(!0),
null!=this.addExpBtn&&this.m_handlerMgr.AddClickEvent(this.addExpBtn,this.CreateDelegate(this.ClickExpBtn))}ClickExpBtn(){X.U.inst.controller.OpenExpUseView()}AddOrDelEvent(e){
e?de.f.Inst.AddCallback(ce.t.VIP_EXP,this._degf_UpdateRedPointHandler):de.f.Inst.RemoveCallback(ce.t.VIP_EXP,this._degf_UpdateRedPointHandler)}UpdateView(e){
this.m_model=X.U.inst.model
this.m_model.level_get()
let t=0
const i=this.m_model.effectiveLevel_get()
let n=i
if(this.m_model.isMaxLevel_get()){this.vipMaxTip.SetActive(!0),this.notTopWidget.SetActive(!1)
const i=this.sliderUp.node.getComponent(oe.UITransform)
i.width=2==e?380:283.7
const n=this.m_model.vipRes_get(),s=`${Z.M.IntToString(this.m_model.diamond)}/${this.m_model.GetNeedExp(n)}`
this.sliderTxtLen.textSet(s),t=this.m_model.GetNeedExp(n)}else{this.vipMaxTip.SetActive(!1),this.notTopWidget.SetActive(!0),0==i?(this.rechargeSp.SetActive(!0),
this.rechargeAgainSp.SetActive(!1)):(this.rechargeSp.SetActive(!1),this.rechargeAgainSp.SetActive(!0))
const s=this.m_model.GetNextRes()
let a=this.m_model.diamond
null==a&&(a=0)
const r=$.D.getInstance().GetIntValue("VIPEXP:RMBTRANSFORM")
t=this.m_model.GetNeedExp(s),this.rechargeTxt.textSet(`${Z.M.IntToString(Math.ceil((t-a)/r))}元`),this.vipLevelNextLabel.textSet(""+s.level),me.A.isShowLog&&ue.Y.LogError(`${(0,
_e.T)("VipLeftView打印UpdateView：level=")}${this.m_model.vipInfo.level}，diamond=${this.m_model.diamond}`),n=this.m_model.level_get()
const l=this.sliderUp.node.getComponent(oe.UITransform)
l.width=2==e?a/t>1?380:380*a/t:a/t>1?283.7:283.7*a/t
const o=`${Z.M.IntToString(a)}/${Z.M.IntToString(t)}`
this.sliderTxtLen.textSet(o)}this.vipLevelSp.textSet(""+this.m_model.level_get()),this.ChangeBgSp(e),this.UpdateRedPoint()}UpdateRedPoint(){if(null!=this.RedPoint){
const e=null!=de.f.Inst.GetData(ce.t.VIP_EXP)&&de.f.Inst.GetData(ce.t.VIP_EXP).show
this.RedPoint.node.SetActive(e)}}ChangeBgSp(e){this.m_model=X.U.inst.model
const t=this.m_model.level_get()
let i=null,n=0
0==t?(i="ryvip_sp_0017",1==e&&(n=-7.614)):t>=1&&t<=3?(i="ryvip_sp_0018",1==e&&(n=-7.614)):t>=4&&t<=6?(i="ryvip_sp_0019",1==e&&(n=5.71)):t>=7&&t<=9?(i="ryvip_sp_0020",
1==e&&(n=5.71)):t>=10&&t<=12?(i="ryvip_sp_0021",1==e&&(n=5.71)):t>=13&&t<=15&&(i="ryvip_sp_0022",1==e&&(n=5.71)),this.iconBg.skin="atlas/vip/"+i,
this.iconBg.node.setPosition(this.iconBg.node.x,n)}Destroy(){this.m_Destroyed||(this.AddOrDelEvent(!1),super.Destroy(),this.m_model=null)}})
var pe,ge=i(19519),Ie=i(38787)
oe._decorator.ccclass("VipLiftPartItem")(pe=class extends((0,V.yk)()){constructor(...e){super(...e),this._degf_OnBtnClick=null,this._degf_GetRewardedCell=null,this.vo=null,
this._m_handlerMgr=null}_initBinder(){super._initBinder(),this._degf_OnBtnClick=(e,t)=>this.OnBtnClick(e,t),this._degf_GetRewardedCell=e=>{}}InitView(){
this.giftGrid.SetInitInfo("ui_v1p_rewardedcell",null,Ie.Q)}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=j.h.Get()),this._m_handlerMgr}SetData(e){const t=e
this.vo=t
const i=t.GetGiftList(),n=new z.Z
for(let e=0;e<=i.Count()-1;e++)n.Add({item:i[e],vo:t})
this.giftGrid.data_set(n),this.canBuyTxt.node.SetActive(!1),this.detailPart.SetActive(!1)
const s=X.U.inst.model.tempLevel_get(),a=X.U.inst.model.trueLevel_get(),r=s>a
let l=t.showConsume
this.originalPriceTxt.textSet(Z.M.IntToString(l.valueNum)),this.priceLine.widthSet(this.originalPriceTxt.width()+6),
this.originalPriceIcon.spriteNameSet(ge.J.GetCurrencyIconUrl(l.valueType)),l=t.consume,this.nowPriceTxt.textSet(Z.M.IntToString(l.valueNum)),
this.nowPriceIcon.spriteNameSet(ge.J.GetCurrencyIconUrl(l.valueType)),this.originalContainer.SetActive(!0),this.nowContainer.SetActive(!0),
t.vipLv-a>=1?r||(this.canBuyTxt.node.SetActive(!0),this.canBuyTxt.textSet(`VIP${t.vipLv+(0,_e.T)("解锁")}`)):(this.m_handlerMgr.AddClickEvent(this.rewardBtn,this._degf_OnBtnClick),
this.detailPart.SetActive(!0),this.rewardBtn.node.SetActive(!1),this.rewarded.SetActive(!1),t.GetIsRewarded()?this.rewarded.SetActive(!0):this.rewardBtn.node.SetActive(!0))}
OnBtnClick(e,t){X.U.inst.mgr.RequestCM_DrawVipReward(this.vo.vipLv)}Clear(){this.m_handlerMgr.RemoveClickEvent(this.rewardBtn,this.OnBtnClick)}Destroy(){this.giftGrid.destroy(),
super.destroy()}})
var Ee,Ce=i(17409),Se=i(5924),Te=i(28287),fe=i(87923),Ae=i(37648),ye=i(55492),Re=i(47786),De=i(11162),we=i(8211),Le=i(7155);(0,
x.s_)(Q.o.VIPPanel,Y.Z.ui_v1p_panel_ry).waitPrefab(J.S.modulePathList).layerNav().register()(Ee=class extends((0,V.Ri)()){constructor(...e){super(...e),this._degf_OnBtnClose=null,
this._degf_PlayEnd=null,this._degf_UpdateView=null,this.showTabIdx=1,this.shouldReOpenCurrencyTimer=-1,this._m_handlerMgr=null}_initBinder(){super._initBinder(),
this._degf_OnBtnClose=(e,t)=>this.OnBtnClose(e,t),this._degf_PlayEnd=()=>this.PlayEnd(),this._degf_UpdateView=e=>this.UpdateView(e)}ShowCurrencyBar_get(){
return Te._.ShowGold_Dia_BindDia}InitView(){this.leftContainer.rightView=this.rightContainer,this.rightContainer.leftView=this.leftContainer}get m_handlerMgr(){
return this._m_handlerMgr||(this._m_handlerMgr=j.h.Get()),this._m_handlerMgr}OnAddToScene(){l.i.Inst.AddEventHandler(q.g.VIP_UPDATE,this.CreateDelegate(this.UpdateView)),
this.m_handlerMgr.AddClickEvent(this.closeBtn,this._degf_OnBtnClose),this.m_handlerMgr.AddClickEvent(this.rechargeBtn,this.CreateDelegate(this.OnRecharge)),
this.leftContainer.OnAddToScene(),this.rightContainer.OnAddToScene(),this.UpdateView(null),X.U.inst.mgr.ReqCM_VipInfo(),
X.U.inst.controller.isOpenAddExp&&Se.C.Inst_get().SetFrameLoop(this.CreateDelegate(this.OpenAddExp),1,1),this.ruleTipLabel.textSet(Re.x.Inst().getItemById(132014).sys_messsage)}
OpenAddExp(){X.U.inst.controller.OpenExpUseView()}OnRecharge(){
if(!Le.o.Inst_get().isFristRecharge)return Ae.P.Inst_get().IsFunctionOpened(ye.x.FIRST_CHARGE)?(T.v.Inst_get().OpenView(),
void this.Close()):void fe.l.SetFunctionTip(ye.x.FIRST_CHARGE)
Ae.P.Inst_get().IsFunctionOpened(ye.x.MALL)&&(we.N.GetInst().CheckShopHasGoodsBuy(3,1)?De.O.Inst_get().Open(null,3,1):De.O.Inst_get().Open(null,2,1)),this.Close()}PlayEnd(){}
OnBtnClose(e,t){this.m_handlerMgr.SetInterval(this.CreateDelegate(this.Close),550,1)}Close(){(0,Ce.sR)(Q.o.VIPPanel)}UpdateView(e){const t=X.U.inst.model
me.A.isShowLog&&ue.Y.LogError(`${(0,_e.T)("VipPanel打印UpdateView：level=")}${t.vipInfo.level}，diamond=${t.diamond}`),this.leftContainer.UpdateView(1),this.rightContainer.UpdateView()
}Clear(){l.i.Inst.RemoveEventHandler(q.g.VIP_UPDATE,this.CreateDelegate(this.UpdateView)),this._m_handlerMgr.RemoveClickEvent(this.closeBtn,this._degf_OnBtnClose),
this.showTabIdx=1,this.leftContainer.Clear(),this.rightContainer.Clear()}Destroy(){this.leftContainer.Destroy(),this.rightContainer.Destroy()}})
var ve,Oe,Pe=i(35128)
class Ne extends((0,V.pA)(ee.x)()){InitView(){super.InitView()}SetData(e){super.SetData(e)
const t=Z.M.IndexOf(e,"<"),i=Z.M.IndexOf(e,">")
if(-1!=t&&-1!=i){let t=Z.M.Split(e,"<")
this.label.textSet(t[0]),this.label.node.transform.width=this.label.textWidth+3
let i=Z.M.Replace(t[1],">","")
this.vipIcon.node.SetActive(!0),this.vipIcon.skin="atlas/mainui/"+i}else this.vipIcon.node.SetActive(!1),this.label.textSet(e)}Clear(){super.Clear()}Destroy(){super.Destroy()}
Test1(){return!0}S_Test(){return!0}}class Me extends((0,V.pA)(ee.x)()){InitView(){this.grid.SetInitInfo("ui_v1p_powertxtcellitem_ry",null,Ne)}SetData(e){let t=e,i=(0,_e.T)("核心特权")
let n=(0,Ce.Y)(Q.o.VIPPanel)
n.showTabIdx%2==0&&(i=(0,_e.T)("其他特权")),n.showTabIdx+=1,this.typeTxt.textSet(i)
const s=Z.M.Split(t,"\n")
this.grid.data_set(s)
const a=50+Pe.p.CeilToInt(s.count/2)*this.grid.cellHeight
this.Container.trans.height=a,this.colider.trans.width=900,this.colider.trans.height=a}Clear(){super.Clear(),this.grid.Clear()}Destroy(){this.grid.destroy()}}class be extends((0,
V.yk)()){constructor(...e){super(...e),this.vipLv=0,this.onSelectHandler=null,this.vipLevel=null,this._m_handlerMgr=null}InitView(){}get m_handlerMgr(){
return this._m_handlerMgr||(this._m_handlerMgr=j.h.Get()),this._m_handlerMgr}SetData(e){this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.OnClickItem)),
this.vipLevel=e.vipLevel,this.onSelectHandler=e.onSelectHandler,this.activeLevel.textSet("V"+this.vipLevel),this.selectLevel.textSet("V"+this.vipLevel),
this.normalLevel.textSet("V"+this.vipLevel),this.UpdateData(),this.UpdateRedPoint()}UpdateData(){this.SetState(!0)}UpdateVipHanler(e){this.UpdateData()}OnClickItem(){
this.SetSelect(!0)}SetState(e){const t=X.U.inst.model.trueLevel_get()
this.active.SetActive(!1),this.select.SetActive(!1),this.normal.SetActive(!1),e?this.vipLevel>t&&e?this.active.SetActive(!0):this.normal.SetActive(!0):this.select.SetActive(!0)}
UpdateRedPoint(){const e=ce.t.VIP_BOX+this.vipLevel,t=null!=de.f.Inst.GetData(e)&&de.f.Inst.GetData(e).show
this.redDot.SetActive(t)}SetSelect(e){if(e){null!=be.selectItem&&be.selectItem.SetSelect(!1),this.SetState(!1),
be.selectItem!=this&&null!=this.onSelectHandler&&this.onSelectHandler(this.vipLevel),be.selectItem=this
const e=ce.t.VIP_BOX+this.vipLevel
de.f.Inst.GetData(e)&&de.f.Inst.GetData(e).show&&(X.U.inst.model.clckedRedPoints.LuaDic_AddOrSetItem(e,!0),de.f.Inst.SetState(e,!1))}else this.SetState(!0)}Destroy(){
null!=be.selectItem&&be.selectItem.SetSelect(!1),be.selectItem=null,super.destroy()}Clear(){}}be.selectItem=null
oe._decorator.ccclass("VipRightView")(((Oe=class extends((0,V.pA)(he.C)()){constructor(...e){super(...e),this.m_model=null,this.m_nowLv=1,this.m_pVO=null,this.m_timerId=-1,
this.isOnAddToScene=!1,this.changePosValue=0,this.totalPosValue=0,this.frontLv=-1,this.delayPosTimerId=-1,this._degf_OnBtnClick=null,this._degf_OnCellSelectHandler=null,
this._degf_OnDragFinished=null,this._degf_OnGetPowerCell=null,this._degf_RefreshRewardItem=null,this._degf_UpdateCells=null,this._degf_UpdateRedPoint=null,
this._degf_OnDelayUpdateBar=null,this._degf_OnCreateVipCell=null,this.leftView=null,this.showMaxLv=null,this._m_handlerMgr=null}get m_handlerMgr(){
return this._m_handlerMgr||(this._m_handlerMgr=j.h.Get()),this._m_handlerMgr}_initBinder(){super._initBinder(),this._degf_OnBtnClick=(e,t)=>this.OnBtnClick(e,t),
this._degf_OnCellSelectHandler=e=>this.OnCellSelectHandler(e),this._degf_OnDragFinished=()=>this.OnDragFinished(),this._degf_OnGetPowerCell=e=>{},
this._degf_RefreshRewardItem=()=>{},this._degf_UpdateCells=()=>this.UpdateCells(),this._degf_UpdateRedPoint=(e,t)=>this.UpdateRedPoint(e,t),
this._degf_OnDelayUpdateBar=()=>this.OnDelayUpdateBar(),this._degf_OnCreateVipCell=e=>this.CreateVipCell(e)}InitView(){this.vipGrid.SetInitInfo("ui_v1p_levelcell_ry",null,be),
this.vipGrid.OnReposition_set(this.CreateDelegate(this.OnVipGridLoaded)),this.m_model=X.U.inst.model,this.powerTable.SetInitInfo("ui_v1p_powertxtcell_ry",null,Me)}OnAddToScene(){
this.isOnAddToScene=!0,this.AddOrDelEvent(!0)
const e=X.U.inst.model.GetMinUnHideLevel()
this.showMaxLv=e
const t=new z.Z
for(let i=1;i<=e;i++)t.Add({vipLevel:i,onSelectHandler:this._degf_OnCellSelectHandler})
if(this.m_nowLv=this.m_model.defaultVipGiftIndex,this.m_model.defaultVipGiftIndex=-1,-1==this.m_nowLv)for(let t=1;t<=e;t++){const e=de.f.Inst.GetData(ce.t.VIP_BOX+t)
if(e&&e.show){this.m_nowLv=t
break}}if(-1==this.m_nowLv)for(let t=1;t<=e;t++)if(t==X.U.inst.model.trueLevel_get()){this.m_nowLv=t
break}-1==this.m_nowLv&&(this.m_nowLv=1),this.vipGrid.data_set(t),this.UpdateView()}CreateVipCell(e){const t=e[0].getCNode(be)
return t.onSelectHandler=this._degf_OnCellSelectHandler,t}OnVipGridLoaded(){let e=-1
this.scrollviewbar.ResetPosition(),this.UpdateRedPoint()
for(let t=1;t<=this.showMaxLv;t++){const i=this.m_model.GetPanelResVO(t).GetPartVOList()
if(i&&i[0]){if(!i[0].GetIsRewarded()){e=t-1
break}}}-1==e?this.vipGrid.itemList[this.m_nowLv-1].SetSelect(!0):this.vipGrid.itemList[e].SetSelect(!0)}OnCellSelectHandler(e){this.m_nowLv=e,this.UpdateView(),
Se.C.Inst_get().SetInterval(this._degf_OnDelayUpdateBar,60,1)}OnDelayUpdateBar(){this.SetBtnEnabled()}AddOrDelEvent(e){const t=ce.t.VIP_BOX
e?(this.scrollviewbar.RegistonDragingMoving(this.CreateDelegate(this.DragMoving)),this.m_handlerMgr.AddClickEvent(this.upBtn.node,this._degf_OnBtnClick),
this.m_handlerMgr.AddClickEvent(this.downBtn.node,this._degf_OnBtnClick)):(this.scrollviewbar.RemoveonDragMoving(this.CreateDelegate(this.DragMoving)),
this.m_handlerMgr.RemoveClickEvent(this.upBtn.node,this._degf_OnBtnClick),this.m_handlerMgr.RemoveClickEvent(this.downBtn.node,this._degf_OnBtnClick))
let i=1
for(;i<=me.A.MAX_LEVEL;)e?de.f.Inst.AddCallback(t+i,this.CreateDelegate(this.UpdateRedPoint)):de.f.Inst.RemoveCallback(t+i,this.CreateDelegate(this.UpdateRedPoint)),i+=1}
UpdateRedPoint(e,t){if(this.vipGrid&&this.vipGrid.itemList){const e=this.vipGrid.itemList
for(let t=0;t<=e.Count()-1;t++)e[t].UpdateRedPoint()}}OnDragFinished(){this.SetBtnEnabled()}UpdateView(){this.m_pVO=this.m_model.GetPanelResVO(this.m_nowLv),
this.vipTitleTxt.textSet(""+this.m_pVO.res.level)
const e=this.m_pVO.GetPartVOList()
this.giftPart.SetData(e[0]),this.totalPosValue=0,-1==this.m_timerId&&(this.m_timerId=Se.C.Inst_get().SetInterval(this._degf_UpdateCells,50,1))
const t=X.U.inst.model.GetMinUnHideLevel()
if(t!=this.showMaxLv){this.showMaxLv=t
const e=new z.Z
for(let i=1;i<=t;i++)e.Add({vipLevel:i,onSelecetHandler:this._degf_OnCellSelectHandler})
this.vipGrid.data_set(e)}}UpdateCells(){if(this.m_timerId=-1,null!=this.powerTable){const e=new z.Z
e.Add(this.m_pVO.res.desc1),fe.l.IsEmptyStr(this.m_pVO.res.desc2)||e.Add(this.m_pVO.res.desc2),this.powerTable.data_set(e)}
-1!=this.delayPosTimerId&&Se.C.Inst_get().ClearInterval(this.delayPosTimerId),this.delayPosTimerId=Se.C.Inst_get().SetFrameLoop(this.CreateDelegate(this.Reposition),2,1)}
Reposition(){this.powerTable.Reposition()}OnBtnClick(e,t){
this.upBtn.node.name==e.target._name?this.ChangeScrollLevel(!0):this.downBtn.node.name==e.target._name&&this.ChangeScrollLevel(!1)}ChangeScrollLevel(e){let t=this.m_nowLv
e?t-=1:t+=1,t<1&&(t=1),t>this.showMaxLv&&(t=this.showMaxLv),this.m_nowLv=t,this.vipGrid.itemList[t-1].SetSelect(!0),
e?this.contentTrs.node.y-104.5<=0?this.contentTrs.node.y=0:this.contentTrs.node.y=this.contentTrs.node.y-104.5:this.contentTrs.node.y+104.5>=550?this.contentTrs.node.y=550:this.contentTrs.node.y=this.contentTrs.node.y+104.5
}SetBtnEnabled(){if(null==this.upBtn||null==this.downBtn||null==this.scrollviewbar)return
this.downBtn.node.SetActive(!0),this.upBtn.node.SetActive(!0)
const e=this.contentTrs.node.y/550
e>.9?this.downBtn.node.SetActive(!1):e<.1?this.upBtn.node.SetActive(!1):(this.upBtn.node.SetActive(!0),this.downBtn.node.SetActive(!0))}DragMoving(){
const e=this.contentTrs.node.y/550
e>.9?this.downBtn.node.SetActive(!1):e<.1?this.upBtn.node.SetActive(!1):(this.upBtn.node.SetActive(!0),this.downBtn.node.SetActive(!0))}ClearTime(){
Se.C.Inst_get().ClearInterval(this.delayPosTimerId),this.delayPosTimerId=-1,Se.C.Inst_get().ClearInterval(this.m_timerId),this.m_timerId=-1}Clear(){this.ClearTime(),this.m_pVO=null
}Destroy(){this.m_Destroyed||super.destroy()}}).M_MOVE_VALUE=.166,ve=Oe))
var Ge;(0,x.s_)(Q.o.VIPUpgradeView,Y.Z.ui_v1p_upgradepanel_ry).register()(Ge=class extends((0,V.Ri)()){constructor(...e){super(...e),this.info=null,this._m_handlerMgr=null}
get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=j.h.Get()),this._m_handlerMgr}InitView(){super.InitView()}OnAddToScene(){this.AddLis(),this.UpdateView()}
UpdateView(){if(this.eff.SetActive(!1),this.eff.SetActive(!0),this.info=X.U.inst.model.changeMsg,null==this.info)return
const e=this.info.newVipLevel
this.desc.textSet(`恭喜您的VIP等级提升到${e}级！`),this.vipTxt.textSet(e),1==(0,W.tw)(e).length?this.vipGo.transform.SetLocalPositionXYZ(-13.3,0,0):this.vipGo.transform.SetLocalPositionXYZ(-23.1,0,0)
let t=null,i=0
0==e?(t="ryvip_sp_0017",i=-1.227):e>=1&&e<=3?(t="ryvip_sp_0018",i=-1.227):e>=4&&e<=6?(t="ryvip_sp_0019",i=12):e>=7&&e<=9?(t="ryvip_sp_0020",i=12):e>=10&&e<=12?(t="ryvip_sp_0021",
i=12):e>=13&&e<=15&&(t="ryvip_sp_0022",i=12),this.icon.skin="atlas/vip/"+t,this.icon.node.setPosition(this.icon.node.x,i)}Clear(){super.Clear(),this.RemoveLis()}Destroy(){
super.destroy()}AddLis(){this.m_handlerMgr.AddClickEvent(this.confirmBtn,this.CreateDelegate(this.OnConfirmBtnHandle)),
this.m_handlerMgr.AddClickEvent(this.mask,this.CreateDelegate(this.OnCloseView))}RemoveLis(){
this.m_handlerMgr.RemoveClickEvent(this.confirmBtn,this.CreateDelegate(this.OnConfirmBtnHandle)),this.m_handlerMgr.RemoveClickEvent(this.mask,this.CreateDelegate(this.OnCloseView))
}OnCloseView(){X.U.inst.controller.CloseUpgradePanel()}OnConfirmBtnHandle(){X.U.inst.controller.OpenPanel(null,null),X.U.inst.controller.CloseUpgradePanel()}})
var Ue=i(42292),Be=i(71409),ke=i(38935),Fe=i(38962)
class He{constructor(){this.rewardListDict=null,this.remainDayDict=null,this.activateDict=null,this.totalDayDict=null,this.everyDayReward=null,this.totalRewardShow=null,
this.timesRate=null,this.rewardListDict=new Fe.X,this.remainDayDict=new Fe.X,this.activateDict=new Fe.X,this.totalDayDict=$.D.getInstance().GetDict("MONTHCARD:CYCLE"),
this.everyDayReward=$.D.getInstance().GetDict("MONTHCARD:EVERYDAY_REWARD"),this.totalRewardShow=$.D.getInstance().GetDict("MONTHCARD:FULLTIME_REWARD"),
this.timesRate=$.D.getInstance().GetDict("MONTHCARD:REWARD_TIMESNUM")}static Inst_Get(){return null==He.Inst&&(He.Inst=new He),He.Inst}HandlerCardInfo(e){
this.rewardListDict.Clear(),this.activateDict.Clear(),this.remainDayDict.Clear()
for(let t=0;t<=e.monthCardInfos.Count()-1;t++){const i=e.monthCardInfos[t]
this.rewardListDict.LuaDic_SetItem(i.type,i.todayReward),this.activateDict.LuaDic_SetItem(i.type,i.activate),this.remainDayDict.LuaDic_SetItem(i.type,i.day)}
l.i.Inst.RaiseEvent(q.g.MONTHCARD_REWARD),l.i.Inst.RaiseEvent(q.g.MONTHCARD_INFO)}isRewarded(e){return this.rewardListDict.LuaDic_GetItem(e)}IsActive(e){
return this.activateDict.LuaDic_GetItem(e)}GetTotalDay(e){return this.totalDayDict.LuaDic_GetItem(e)}GetEveryDayRewardNum(e){return this.everyDayReward.LuaDic_GetItem(e)}
GetTotalRewardShow(e){return this.totalRewardShow.LuaDic_GetItem(e)}GetTimeRate(e){return this.timesRate.LuaDic_GetItem(e)}GetRemainDay(e){
return this.remainDayDict.LuaDic_GetItem(e)}}He.Inst=null
var xe,Ve,Ye,We,Ke=i(92415)
function Ze(e,t,i,n,s){var a={}
return Object.keys(n).forEach((function(e){a[e]=n[e]})),a.enumerable=!!a.enumerable,a.configurable=!!a.configurable,("value"in a||a.initializer)&&(a.writable=!0),
a=i.slice().reverse().reduce((function(i,n){return n(e,t,i)||i}),a),s&&void 0!==a.initializer&&(a.value=a.initializer?a.initializer.call(s):void 0,a.initializer=void 0),
void 0===a.initializer&&(Object.defineProperty(e,t,a),a=null),a}let ze=(xe=(0,Be.GH)(Ke.k.SM_MonthCardReward),Ve=(0,Be.GH)(Ke.k.SM_MonthCardInfo),We=class e{constructor(){
this.RegisterMessage()}static Inst_Get(){return null==e.Inst&&(e.Inst=new e),e.Inst}RegisterMessage(){}SM_MonthCardReward(e){
He.Inst_Get().rewardListDict.LuaDic_SetItem(e.type,e.reward),l.i.Inst.RaiseEvent(q.g.MONTHCARD_REWARD),this.UpdateRedPoint()}SM_MonthCardInfo(e){He.Inst_Get().HandlerCardInfo(e),
this.UpdateRedPoint(),l.i.Inst.RaiseEvent(q.g.MONTHCARD_INFO)}CM_MonthCardReward(e){const t=new w.d
t.type=e,ke.C.Inst.F_SendMsg(t)}UpdateRedPoint(){const e=new z.Z([1,2])
de.f.Inst.SetState(ce.t.MONTH_CARD,!1)
for(let t=0;t<=e.Count()-1;t++)if(He.Inst_Get().IsActive(e[t])&&!He.Inst_Get().isRewarded(e[t])){de.f.Inst.SetState(ce.t.MONTH_CARD,!0)
break}}},We.Inst=null,Ze(Ye=We,"Inst_Get",[Ue.n],Object.getOwnPropertyDescriptor(Ye,"Inst_Get"),Ye),
Ze(Ye.prototype,"SM_MonthCardReward",[xe],Object.getOwnPropertyDescriptor(Ye.prototype,"SM_MonthCardReward"),Ye.prototype),
Ze(Ye.prototype,"SM_MonthCardInfo",[Ve],Object.getOwnPropertyDescriptor(Ye.prototype,"SM_MonthCardInfo"),Ye.prototype),Ye)
i(73193),i(56782),i(33665),i(17366),i(89675)
var qe,$e=i(51868),Xe=i(52513)
oe._decorator.ccclass("MonthCardItem")(qe=class extends $e.${constructor(...e){super(...e),this.monthCardType=null,this.cnode=null}InitView(){super.InitView()}SetData2(e,t){
this.cnode=t,this.m_handlerMgr.AddClickEvent(this.cnode.rechargeBtn,this.CreateDelegate(this.OnClickRecharge)),
this.m_handlerMgr.AddClickEvent(this.cnode.getBtn,this.CreateDelegate(this.OnClickReceive)),this.cnode.monthCardType=e,
He.Inst_Get().IsActive(e)?this.ShowActive():this.ShowUnActive(),this.cnode.timesLabel.textSet(He.Inst_Get().GetTimeRate(e)+"")}ShowUnActive(){
this.cnode.unactiveContainer.SetActive(!0),this.cnode.activityContainer.SetActive(!1),
this.cnode.totalRewardLabel.textSet(`累计可得：${He.Inst_Get().GetTotalRewardShow(this.monthCardType)}`),
this.cnode.everyDayRewardLabel.textSet(`每日可领：${He.Inst_Get().GetEveryDayRewardNum(this.monthCardType)}`)
let e=199
2==this.monthCardType&&(e=200)
const t=P.W.Inst.GetCurSystem(),i=Xe.O.Inst().getConfig(e),n=i.platformDiamond[t]
this.cnode.nowRewardLabel.textSet(`立即获得：${n}`)
const s=i.platformCurrency[t]
this.cnode.rechargeBtnLabel.textSet(`${s}元激活`)}ShowActive(){this.cnode.unactiveContainer.SetActive(!1),this.cnode.activityContainer.SetActive(!0),
this.cnode.everyDayRewardActiveLabel.textSet(`每日可领：${He.Inst_Get().GetEveryDayRewardNum(this.monthCardType)}`),
this.cnode.remainDayLabel.textSet(`剩余${He.Inst_Get().GetRemainDay(this.monthCardType)}天`),He.Inst_Get().isRewarded(this.monthCardType)?(this.cnode.receivedTip.SetActive(!0),
this.cnode.getBtn.node.SetActive(!1)):(this.cnode.receivedTip.SetActive(!1),this.cnode.getBtn.node.SetActive(!0))}OnClickReceive(){
ze.Inst_Get().CM_MonthCardReward(this.monthCardType)}OnClickRecharge(){let e=199
2==this.monthCardType&&(e=200),b.t.inst.Buy(Xe.O.Inst().getConfig(e),null,!1)}Clear(){
this.m_handlerMgr.RemoveClickEvent(this.cnode.rechargeBtn,this.CreateDelegate(this.OnClickRecharge)),
this.m_handlerMgr.RemoveClickEvent(this.cnode.getBtn,this.CreateDelegate(this.OnClickReceive)),super.Clear()}})
i(50139),i(78046),i(34067),i(6431)
var Qe,je=i(5494),Je=i(71893),et=i(95155),tt=i(13224),it=i(80460);(0,x.s_)(je.I.REDPACKET,Y.Z.ui_redpacket_panel).register()(Qe=class extends((0,V.Ri)()){InitView(){}
OnAddToScene(){h.O.SetAnchorPos(this.widget,null,!0,-2),this.eff.SetActive(!1),this.AddLis(),this.UpdateView()}UpdateView(){
it.r.Inst_Get().CanOpenRedPacket()?this.eff.SetActive(!0):this.eff.SetActive(!1)}Clear(){super.Clear(),this.RemoveLis()}Destroy(){super.Destroy()}AddLis(){
de.f.Inst.AddCallback(ce.t.DAILY_RED_PACKET,this.CreateDelegate(this.UpdateView)),this.m_handlerMgr.AddClickEvent(this.btn,this.CreateDelegate(this.OpenRedPacketView)),
l.i.Inst.AddEventHandler(q.g.UPDATE_REDPACKET_DAILY,this.CreateDelegate(this.UpdateView))}RemoveLis(){
de.f.Inst.RemoveCallback(ce.t.DAILY_RED_PACKET,this.CreateDelegate(this.UpdateView)),l.i.Inst.RemoveEventHandler(q.g.UPDATE_REDPACKET_DAILY,this.CreateDelegate(this.UpdateView))}
OpenRedPacketView(){Je.u.Inst_get().viewType=et.S.REDPACKET,tt.w.Inst_Get().OpenPanel()}})
i(71294),i(73830),i(86172),i(80065)
var nt,st=i(98130),at=i(79534),rt=i(88010),lt=i(33314),ot=i(22878),_t=i(95741);(0,x.s_)(je.I.CopyNPCTip,Y.Z.ui_comm_copynpcrefreshpanel).register()(nt=class extends((0,V.Ri)()){
constructor(...e){super(...e),this.closeInterval=-1,this.endAnimTimer=-1,this.closeTime=6e3,this.model=null,this.isOne=!0,this._degf_CloseViewHandler=null,
this._degf_DelayClose=null}_initBinder(){super._initBinder(),this._degf_CloseViewHandler=()=>this.CloseViewHandler(),this._degf_DelayClose=()=>this.DelayClose()}InitView(){
this.effect.node.active=!1,this.model=_t.p.Inst_get(),super.InitView()}OnAddToScene(){rt.F.Inst_get().isInPkUI?this.SwitchToPk():this.SwitchToNormal(),this.SetData(),
this.UpdateAnchors()}UpdateAnchors(){h.O.SetAnchorPos(this.anchor,!0,!0,0,!1)}Clear(){this.ClearInterval(),this.ClearEndAnimTimer()}ClearInterval(){
Se.C.Inst_get().ClearInterval(this.closeInterval),this.closeInterval=-1}ClearEndAnimTimer(){Se.C.Inst_get().ClearInterval(this.endAnimTimer),this.endAnimTimer=-1}ShowStartAnim(){
this.showAnim.SetFrom(new oe.Vec3(0,0,0)),this.showAnim.SetTo(new oe.Vec3(1,1,1))}ShowEndAnim(){this.showAnim.SetFrom(new oe.Vec3(1,1,1)),this.showAnim.SetTo(new oe.Vec3(0,0,0)),
-1==this.endAnimTimer&&(this.endAnimTimer=Se.C.Inst_get().SetInterval(this._degf_CloseViewHandler,240,1))}CloseViewHandler(){this.ClearEndAnimTimer(),ot.C.inst.CloseNPCTipView()}
SetData(){if(this.ClearInterval(),(-1!=this.endAnimTimer||this.isOne)&&(this.isOne=!1,this.ClearEndAnimTimer(),this.ShowStartAnim()),null!=this.model.noticeRes){
if(null!=this.model.noticeRes.element&&""!=this.model.noticeRes.element){const e=at.P.zero_get()
r.X.Inst.PlayElement(Z.M.String2Int(this.model.noticeRes.element),n.Y.Inst.PrimaryRole_get().GetHandle(),0,e,e)}let e=null,t="",i=""
if(3==this.model.noticeRes.noticeType){const i=n.Y.Inst.GetOtherPlayerInfos()
if(i.Count()>0){const n=i[0]
t=lt.Z.GetJobIcon(n.Job_get(),n.Sex_get(),!0),this.iconEx.node.SetActive(!0),this.icon.node.SetActive(!1),this.iconRy.node.SetActive(!1),e=this.iconEx}
}else Z.M.IsNullOrEmpty(this.model.noticeRes.icon)||"0"==this.model.noticeRes.icon||(t=this.model.noticeRes.icon,
Z.M.StartsWith(t,fe.l.RY_MON_ICON_PRE)?(this.iconEx.node.SetActive(!1),this.icon.node.SetActive(!1),this.iconRy.node.SetActive(!0),e=this.iconRy):(e=this.icon,
this.iconEx.node.SetActive(!1),this.iconRy.node.SetActive(!1),this.icon.node.SetActive(!0)))
if(3==this.model.noticeRes.noticeType){const e=n.Y.Inst.GetOtherPlayerInfos()
if(e.Count()>0){i=e[0].Name_get()}}else"0"==this.model.noticeRes.name?(i=TeamModel.Inst_get().getLeaderName(),
""==i&&(i=n.Y.Inst.PrimaryRoleInfo_get().Name_get())):i=this.model.noticeRes.name
e.spriteNameSet(t),this.artTxt.textSet(i)
const s=this.GetDesc(this.model.noticeRes.desc)
this.desc.textSet(s)}this.closeInterval=Se.C.Inst_get().SetInterval(this._degf_DelayClose,this.closeTime,1)}GetDesc(e){
const t=Z.M.Replace(e,"||",K.o.s_NEXT_ONELINE),i=Z.M.Split(t,K.o.s_NEXT_ONELINE)
return i[st.GF.INT(Pe.p.RandomMinMax(0,100))%i.count]}SwitchToPk(){const e=new at.P(-10,60,0)
this.posObj.transform.SetLocalPosition(e),at.P.Recyle(e)}SwitchToNormal(){const e=new at.P(72,49,0)
this.posObj.transform.SetLocalPosition(e),at.P.Recyle(e)}DelayClose(){this.ClearInterval(),this.ShowEndAnim()}Destroy(){this.ClearInterval(),this.ClearEndAnimTimer()}})
i(56505),i(61182)
var ut,ht=i(68506),ct=i(61911);(0,x.s_)(je.I.GetRewardTipPanel,Y.Z.ui_common_getreward_tippanel).waitPrefab(J.S.modulePathList).register()(ut=class extends((0,V.pA)(ct.f)()){
constructor(...e){super(...e),this.param=null,this.countDownTime=null,this.countDownId=null,this._m_handlerMgr=null}get m_handlerMgr(){
return this._m_handlerMgr||(this._m_handlerMgr=j.h.Get()),this._m_handlerMgr}InitView(){super.InitView(),this.grid.SetInitInfo("ui_baseitem",null,g.j),
this.grid.OnReposition_set(this.CreateDelegate(this.RepositionFun))}RepositionFun(){this.grid.itemList[0]}OnAddToScene(){this.AddLis(),this.UpdateView()}UpdateView(){
this.param=ht.Z.Inst_get().param,this.countDownTime=this.param.countDownTime,this.CountdownHandle(!0),this.desc.textSet(this.param.desc),this.UpdateItemLis(),
this.countDownTime>0?this.countDownId=Se.C.Inst_get().SetInterval(this.CreateDelegate(this.CountdownHandle),1e3,-1):this.ClearCountDownHandle(),
this.param.tiredValue>0?(this.tiredValueObj.SetActive(!0),this.tiredLabel.textSet(`+${this.param.tiredValue}`)):this.tiredValueObj.SetActive(!1)}ClearCountDownHandle(){
null!=this.countDownId&&(Se.C.Inst_get().ClearInterval(this.countDownId),this.countDownId=null)}Clear(){super.Clear(),this.grid.Clear(),this.RemoveLis(),this.ClearCountDownHandle()
}Destroy(){}AddLis(){this.m_handlerMgr.AddClickEvent(this.comfirmBtn.node,this.CreateDelegate(this.OnConfirmBtnHandler))}RemoveLis(){
this.m_handlerMgr.RemoveClickEvent(this.comfirmBtn.node,this.CreateDelegate(this.OnConfirmBtnHandler))}OnConfirmBtnHandler(){
null!=this.param.confirmBtnHandle&&this.param.confirmBtnHandle(),this.OnCloseBtnHandle()}UpdateItemLis(){if(this.param.rewardLis.Count()>0){const e=new z.Z
for(let t=0;t<=this.param.rewardLis.Count()-1;t++){const i=this.param.rewardLis[t],n=new se.M(i.modelId_get())
n.Clone(i),n.count=i.count,n.isShowAccess=!1,e.Add(n)}this.grid.data_set(e)}}CountdownHandle(e){if(e){let e=""
this.countDownTime>0&&(e=`(${this.countDownTime})`),this.comfirmLbl.textSet(this.param.confimBtnLbl+e)}else this.countDownTime-=1,
this.countDownTime>=0&&(this.comfirmLbl.textSet(`${this.param.confimBtnLbl}(${this.countDownTime})`),0==this.countDownTime&&this.OnCloseBtnHandle())}OnCloseBtnHandle(){
ht.Z.Inst_get().Close()}})
var dt,mt=i(59686)
oe._decorator.ccclass("InfoSkillItem")(dt=class extends((0,V.yk)()){constructor(...e){super(...e),this.itemImg=null,this.itemData=null,this._degf_OnIconClick=null}_initBinder(){
this._degf_OnIconClick=(e,t)=>this.OnIconClick(e,t)}InitView(){this.itemImg=this.icon}Clear(){}Destroy(){}AddLis(){}RemoveLis(){}OnIconClick(e,t){
B.x.inst.OpenTipViewById(this.itemData.id,mt.l.Default)}SetData(e){if(null==this.itemImg&&(this.itemImg=this.icon),this.AddLis(),this.itemData=e,this.itemImg.node.SetActive(!1),
null!=this.itemData){const e=this.itemData.skillicon
this.itemImg.spriteNameSet(e),this.itemImg.node.SetActive(!0)}else this.itemImg.spriteNameSet("")}})
var pt,gt=i(48823),It=(i(22267),i(75507)),Et=i(34565),Ct=i(38836),St=i(18202),Tt=i(78300),ft=i(52212),At=i(48933),yt=i(39043),Rt=i(12417),Dt=i(74045),wt=i(39879),Lt=i(90930),vt=i(2446)
class Ot extends((0,V.yk)()){InitView(){}Destroy(){}SetData(e){const t=e
this.baseItem.node.SetActive(!1),this.ui_infotip_skillitem.node.SetActive(!1),null!=t&&(this.baseItem.node.SetActive(!0),this.baseItem.SetData(t),
this.baseItem.EnabledClickOpenTip(!0))}}
(0,x.s_)(Q.o.InfoTipView,Y.Z.ui_infotip_tipview).waitPrefab(g.j.CompListPath).waitPrefab(Y.Z.ui_infotip_currency).layerTip().register()(pt=class extends((0,V.pA)(Et.I)()){
constructor(...e){super(...e),this.spriteIdList=null,this.vec2=null,this.tipVo=null,this.currencyTypeStrList=null,this.currencyStrList=null,this.fontSize=20,this.spacingY=0,
this.isTrueSelect=!1,this.btnColorType=0,this.centerWidgetPos=null,this.countdown=0,this.intervalId=-1,this._degf_OnBagUpdate=null,this._degf_OnCancelClick=null,
this._degf_OnCloseClick=null,this._degf_OnConfirmClick=null,this._degf_OnItemRefreshFun=null,this._degf_SelectHandler=null,this._degf_CountdownHandle=null,this.m_ItemPath=null,
this.m_ItemCls=null}_initBinder(){super._initBinder(),this.spriteIdList=new z.Z,this.vec2=Tt.V.TEMP_VECTOR2D_get(),
this.currencyTypeStrList=new z.Z(["GOLD","GOLD_DIAMOND","BLUE_DIAMOND","BIND_DIAMOND","HONOUR","SKILL_POINT","CONSIGN_SCORE","ASURAM_TOKEN","TREASURE_HUNT_COUPON"]),
this.currencyStrList=new z.Z(["[CURRENCY:GOLD]","[CURRENCY:GOLD_DIAMOND]","[CURRENCY:BLUE_DIAMOND]","[CURRENCY:BIND_DIAMOND]","[CURRENCY:HONOUR]","[CURRENCY:SKILL_POINT]","[CURRENCY:CONSIGN_SCORE]","[CURRENCY:ASURAM_TOKEN]","[CURRENCY:TREASURE_HUNT_COUPON]"]),
this.centerWidgetPos=new at.P(8,36,0),this._degf_OnBagUpdate=e=>this.OnBagUpdate(e),this._degf_OnCancelClick=(e,t)=>this.OnCancelClick(e,t),
this._degf_OnCloseClick=(e,t)=>this.OnCloseClick(e,t),this._degf_OnConfirmClick=(e,t)=>this.OnConfirmClick(e,t),this._degf_OnItemRefreshFun=e=>this.OnItemRefreshFun(e),
this._degf_SelectHandler=(e,t)=>this.SelectHandler(e,t),this._degf_CountdownHandle=()=>this.CountdownHandle()}InitView(){console.log("initView"),super.InitView(),
this.m_ItemPath="ui_infotip_currency",this.m_ItemCls=gt.I,this.grid.SetInitInfo("ui_infotip_commonitem",this._degf_OnItemRefreshFun,Ot)}OnItemRefreshFun(e){return new Ot(null)}
OnAddToScene(){this.AddLis(),this.tipVo=Dt.t.Inst().tipVo,this.isTrueSelect=!1,this.ResetView(),this.SetData(),this.UpdateView()}ResetView(){this.SetText(this.topLabel,"",!0),
this.SetText(this.bottomLabel,"",!1),this.SetText(this.midLabel,"",!1),this.grid.node.SetActive(!1),this.currencyWidget.removeAllChildren()}UpdateView(){
this.select.node.SetActive(this.isTrueSelect),this.select.node.SetActive(this.tipVo.isCheckBoxOn),this.isTrueSelect=this.tipVo.isCheckBoxOn,
1==this.tipVo.tipstype?(this.cancelBtn.node.SetActive(!1),At.I.calVec0.Set(0,-83),
this.confirmBtn.node.transform.SetLocalPosition(At.I.calVec0)):2==this.tipVo.tipstype&&(this.cancelBtn.node.SetActive(!0),At.I.calVec0.Set(128,-83),
this.confirmBtn.node.transform.SetLocalPosition(At.I.calVec0))}Clear(){this.RemoveLis(),Se.C.Inst_get().ClearInterval(this.intervalId),this.intervalId=-1,
Rt._.Inst().isOpenAddTip=!1}Destroy(){}AddLis(){this.AddClickEvent(this.confirmBtn.node,this._degf_OnConfirmClick),this.AddClickEvent(this.cancelBtn.node,this._degf_OnCancelClick),
this.AddClickEvent(this.closeBtn.node,this._degf_OnCloseClick),this.AddClickEvent(this.selectbg.node,this._degf_SelectHandler),
l.i.Inst.AddEventHandler(q.g.UPDATE_INFO_TIP_VIEW,this.CreateDelegate(this.UpdateInfoTipView))}RemoveLis(){this.RemoveClickEvent(this.confirmBtn.node,this._degf_OnConfirmClick),
this.RemoveClickEvent(this.cancelBtn.node,this._degf_OnCancelClick),this.RemoveClickEvent(this.closeBtn.node,this._degf_OnCloseClick),
l.i.Inst.RemoveEventHandler(q.g.UPDATE_INFO_TIP_VIEW,this.CreateDelegate(this.UpdateInfoTipView))}UpdateInfoTipView(){this.SetData()}OnBagUpdate(e){this.SetData()}
OnConfirmClick(e,t){let i=!0
if(this.tipVo.isJudgeSafeLock,this.tipVo.dontClose&&(i=!1),i&&Dt.t.Inst().Close(),
this.tipVo.needCheckBox&&yt.V.Inst_get().SetData(yt.V.Inst_get().GetRolePrefix()+this.tipVo.infoId,this.isTrueSelect),null!=this.tipVo&&null!=this.tipVo.confirmHandle){
const e=this.tipVo.dontClose
this.tipVo.confirmHandle(this.tipVo.confirmParam,this.isTrueSelect),e||(this.tipVo.confirmHandle=null),this.tipVo.checkChanged=null}}OnCancelClick(e,t){let i=!0
this.tipVo.cancelDontClose&&(i=!1),i&&Dt.t.Inst().Close(),this.tipVo.isCancelForCheckBox&&yt.V.Inst_get().SetData(yt.V.Inst_get().GetRolePrefix()+this.tipVo.infoId,this.isTrueSelect),
null!=this.tipVo&&null!=this.tipVo.cancelHandle&&(this.tipVo.cancelHandle(this.tipVo.cancelParam),this.tipVo.cancelDontClose||(this.tipVo.cancelHandle=null),
this.tipVo.checkChanged=null)}OnCloseClick(e,t){if(Dt.t.Inst().Close(),null!=this.tipVo){
if(null!=this.tipVo.cancelHandle&&this.tipVo.isDoCancleInClose)return this.tipVo.cancelHandle(this.tipVo.cancelParam),void(this.tipVo.cancelHandle=null)
null!=this.tipVo.closeHandle&&this.tipVo.closeHandle(),this.tipVo.cancelHandle=null,this.tipVo.confirmHandle=null,this.tipVo.closeHandle=null,this.tipVo.checkChanged=null}}
PlayCloseAni(){}CountdownHandle(){this.confirmLabel.textSet(this.tipVo.confirmText+((0,_e.T)("(")+(this.countdown+(0,_e.T)(")")))),
this.banConfirmLabel.textSet(this.tipVo.confirmText+((0,_e.T)("(")+(this.countdown+(0,_e.T)(")")))),this.countdown-=1,this.countdown<0&&(this.confirmBtn.SetIsEnabled(!0),
this.confirmLabel.textSet(this.tipVo.confirmText),this.confirmLabel.node.SetActive(!0),this.banConfirmLabel.node.SetActive(!1),Se.C.Inst_get().ClearInterval(this.intervalId),
this.intervalId=-1,0==this.tipVo.banConfirmBtnInCountdown&&(null!=this.tipVo.confirmCountdownHandle?this.tipVo.confirmCountdownHandle():this.OnConfirmClick(0,0)))}Init(){
this.ResetView()
for(const[e,t]of(0,Ct.V5)(this.spriteIdList))St.g.DestroyUIById(t)
this.spriteIdList.Clear(),At.I.calVec0.Set(0,80,0),this.topLabel.node.transform.SetLocalPosition(At.I.calVec0),At.I.calVec0.Set(0,20,0),
this.midLabel.node.transform.SetLocalPosition(At.I.calVec0),At.I.calVec0.Set(0,-58,0),this.bottomLabel.node.transform.SetLocalPosition(At.I.calVec0)}SetData(){this.Init()
const e=wt.L.Inst().getItemById(this.tipVo.infoId)
let t=e.text
t=fe.l.RegexN(t),this.checkbox.node.SetActive(e.isRemind),null!=e.remindContent&&this.checkBoxTxt.textSet(e.remindContent),this.tipVo.needCheckBox=e.isRemind&&e.rightActive,
this.tipVo.isCancelForCheckBox=e.isRemind&&e.leftActive,this.confirmBtn.SetIsEnabled(!0),this.confirmLabel.node.SetActive(!0),this.banConfirmLabel.node.SetActive(!1),
this.tipVo.showConfirmCountdown?(Se.C.Inst_get().ClearInterval(this.intervalId),this.countdown=this.tipVo.confirmCountdown,this.CountdownHandle(),
this.intervalId=Se.C.Inst_get().SetInterval(this._degf_CountdownHandle,1e3,this.tipVo.confirmCountdown),this.tipVo.banConfirmBtnInCountdown&&(this.confirmBtn.SetIsEnabled(!1),
this.confirmLabel.node.SetActive(!1),this.banConfirmLabel.node.SetActive(!0))):this.confirmLabel.textSet(this.tipVo.confirmText),this.cancelLabel.textSet(this.tipVo.cancelText),
""==e.title?this.title.textSet((0,_e.T)("提 示")):this.title.textSet(e.title)
let i=0
for(;i<this.tipVo.replaceParams.Count();)t=Z.M.Replace(t,Z.M.s_LEFT_B_K_CHAR+(i+Z.M.s_RIGHT_B_K_CHAR),this.tipVo.replaceParams[i].toString()),i+=1
const n=new z.Z
let s=Z.M.IndexOf(t,Z.M.s_LEFT_B_K_CHAR,0),a=Z.M.IndexOf(t,Z.M.s_RIGHT_B_K_CHAR,0),r="",l="",o="",_=null
if(s>=0&&a>=0){_=Z.M.SubStringWithEnd(t,s+1,a),r=Z.M.SubStringWithEnd(t,0,s),l=Z.M.SubStringWithEnd(t,a+1,Z.M.Length(t))
const e=Z.M.Split(_,Z.M.s_SPAN_CHAR)
let i=0
for(;i<e.count;){if(Z.M.StartsWith(e[i],"MIDDLE_STR:"))o=Z.M.Remove(e[i],0,"MIDDLE_STR:".length)
else if(Z.M.IndexOf(e[i],K.o.s_UNDER_COLON,0)>=0){const t=Z.M.Split(e[i],K.o.s_UNDER_COLON),s=Z.M.String2Int(t[0]),a=Z.M.String2Int(t[1]),r=new se.M(s,null)
this.tipVo.showNum?(r.showNum=!0,r.count=a):r.needNum=a,n.Add(r)}else e[i]
i+=1}}if(s=Z.M.IndexOf(l,Z.M.s_LEFT_B_K_CHAR,0),a=Z.M.IndexOf(l,Z.M.s_RIGHT_B_K_CHAR,0),s>=0&&a>=0){_=Z.M.SubStringWithEnd(l,s+1,a),l=Z.M.SubStringWithEnd(l,a+1,Z.M.Length(l))
const e=Z.M.Split(_,Z.M.s_SPAN_CHAR)
let t=0
for(;t<e.count;){if(Z.M.IndexOf(e[t],K.o.s_UNDER_COLON,0)>=0){const i=Z.M.Split(e[t],K.o.s_UNDER_COLON),s=Z.M.String2Int(i[0]),a=Z.M.String2Int(i[1]),r=new se.M(s,null)
this.tipVo.showNum?(r.showNum=!0,r.count=a):r.needNum=a,n.Add(r)}t+=1}}if(null!=this.tipVo.showEquip){const e=this.tipVo.showEquip
n.Add(e)}this.tipVo.topContent
let u=0
const h=new at.P
if(n.Count()>0){const e=this.GetTextRows(r)
u=(this.GetTextRows(l)-e)*((this.fontSize+this.spacingY)/2),this.centerWidgetPos=new at.P(0,36,0),this.centerWidgetPos.y=this.centerWidgetPos.y+u,
this.centerWidget.transform.SetLocalPosition(this.centerWidgetPos),this.centerWidgetPos.y=this.centerWidgetPos.y-u,this.SetText(this.topLabel,r,!0),
this.SetText(this.bottomLabel,l,!1),this.grid.node.SetActive(!0),this.grid.data_set(n)}else if(""!=o){const e=this.GetTextRows(r)
u=(this.GetTextRows(l)-e)*((this.fontSize+this.spacingY)/2),this.centerWidgetPos=new at.P(0,36,0),this.centerWidgetPos.y=this.centerWidgetPos.y+u,
this.centerWidget.transform.SetLocalPosition(this.centerWidgetPos),this.centerWidgetPos.y=this.centerWidgetPos.y-u,this.SetText(this.topLabel,r,!0),
this.SetText(this.bottomLabel,l,!1),h.y+=(this.GetTextRows(t)-1)*((this.fontSize+this.spacingY)/2),this.midLabel.node.transform.SetLocalPosition(h),this.SetText(this.midLabel,o,!1)
}else h.y+=(this.GetTextRows(t)-1)*((this.fontSize+this.spacingY)/2),this.midLabel.node.transform.SetLocalPosition(h),this.SetText(this.midLabel,t,!1),
this.midLabel.handleTouchEvent=""!=t
console.log(this.midLabel),at.P.Recyle(h)}SetText(e,t,i){null==i&&(i=!0),t=t.replace(/\s/g,"")
const n=new z.Z,s=new z.Z
let a=null,r=0,l=0,o=t,_=0
for(;_<this.currencyStrList.count;){const e=this.currencyStrList[_]
for(;Z.M.IndexOf(o,e,0)>=0;){r=Z.M.IndexOf(o,e,0),t=Z.M.ReplaceSlow(t,e,"      "),o=Z.M.ReplaceSlow(o,e,"      ")
const i=new Lt.i(r,this.currencyTypeStrList[_])
n.Add(i)}_+=1}if(Z.M.IndexOf(t,Z.M.s_NN_CHAR,0)<0)a=new vt.u(t,t,0,Z.M.Length(o)-1,n),s.Add(a)
else{let e=0,i=0,_=null,u=null
for(;Z.M.IndexOf(t,Z.M.s_NN_CHAR,e)>=0;)r=Z.M.IndexOf(t,Z.M.s_NN_CHAR,e),l=Z.M.IndexOf(o,Z.M.s_NN_CHAR,i),_=Z.M.SubStringWithEnd(t,e,r),u=_,a=new vt.u(_,u,i,l,n),s.Add(a),
e=r+Z.M.Length(Z.M.s_NN_CHAR),i=l+Z.M.Length(Z.M.s_NN_CHAR)
_=Z.M.SubStringWithEnd(t,e,Z.M.Length(t)),u=_,a=new vt.u(_,u,i,Z.M.Length(o),n),s.Add(a)}let u=20
i&&(u=22)
let h=0
for(;h<s.Count();){this.testRich.textSet(s[h].text)
const t=this.testRich.textWidth
let n=0
for(;n<s[h].currencyList.Count();){this.testRich.textSet(Z.M.SubStringWithEnd(s[h].pureText,0,s[h].currencyList[n].index))
const a=this.testRich.textWidth
this.vec2=i?new ft.F(-t/2+a+14,e.node.transform.GetLocalPosition().y+h*(u+this.spacingY)+14).Clone():new ft.F(-t/2+a,e.node.transform.GetLocalPosition().y-h*(u+this.spacingY)+16).Clone()
const r=St.g.GetResFindId("ui_infotip_currency")
this.InitCurrency(r,s[h].currencyList[n].type),n+=1}h+=1}e.string=t}InitCurrency(e,t){let i=null
const n=It.o.getPrefab(this.m_ItemPath)
i=(0,oe.instantiate)(n).getCNode(this.m_ItemCls),i.setId(e,null,0),this.currencyWidget.addChild(i.node)
i.node.transform.width,i.node.transform.height
i.node.transform.SetLocalPositionXYZ(this.vec2.x,this.vec2.y-14,0),i.SetData(t)}GetTextRows(e){return Z.M.Split(e,Z.M.s_NN_CHAR).count}SelectHandler(e,t){
this.select.node.SetActive(!this.isTrueSelect),this.isTrueSelect=!this.isTrueSelect,null!=this.tipVo.checkChanged&&this.tipVo.checkChanged(this.isTrueSelect)}AddClickEvent(e,t){
e.on(oe.NodeEventType.TOUCH_END,t,this,!1)}RemoveClickEvent(e,t){e.off(oe.NodeEventType.TOUCH_END,t,this,!1)}})
i(83466)
var Pt,Nt=i(70707)
const{ccclass:Mt,executeInEditMode:bt,menu:Gt,property:Ut,type:Bt}=oe._decorator
Mt("RyTree")(Pt=class extends $e.${constructor(...e){super(...e),this.OnSelect=null,this.notifier=null,this.treeTitleItemName=null,this.treeItemName=null,this.m_titleitemCls=null,
this.m_itemCls=null,this.titleDatas=null,this.treeDataDic=null,this.titleItems=null,this.titleItemPool=null,this.titleCellH=68,this.titleH=68,this.maxH=517,this.offsetH=0,
this.itemH=0,this.ScrollH=0,this.maxScrollH=517,this.selectOneForce=!1,this.itemVx=null,this.curScrollH=null,this._refreshData=null,this.curTitleTreeData=null,
this.curTreeData=null,this.expandTitleID=null,this._sIndex=null,this.m_onReposition=null,this.m_onSelect=null}_initBinder(){super._initBinder(),this.notifier=new Nt.k,
this.titleDatas=new z.Z,this.treeDataDic=new Fe.X,this.titleItems=new z.Z,this.titleItemPool=new z.Z}InitView(){super.InitView(),this.itemH=this.grid.cellHeight,
this.itemVx=this.itemview.position.x,this.curScrollH=this.ScrollH}InitData(e,t,i){this.titleCellH=e,this.maxH=t,null==i&&(this.offsetH=0)}SetTitleAndItemName(e,t,i,n){
this.treeTitleItemName=e,this.treeItemName=t,this.m_titleitemCls=i,this.m_itemCls=n,this.grid.OnReposition_set(this.CreateDelegate(this.OnGridReposition)),
this.grid.SetInitInfo(t,null,n,this.CreateDelegate(this.ItemClickHandler))}SetData(e){this._refreshData=e,this.titleDatas.Clear(),this.treeDataDic.LuaDic_Clear()
const t=this._refreshData.count-1
this.curTitleTreeData=null,this.curTreeData=null,this.expandTitleID=null
for(let e=0;e<=t;e++){const t=this._refreshData[e]
if(t.IsTitle())this.titleDatas.Add(t),t.expand&&(this.curTitleTreeData=t)
else{let e=null
this.treeDataDic.LuaDic_ContainsKey(t.parentID)?e=this.treeDataDic[t.parentID]:(e=new z.Z,this.treeDataDic.LuaDic_AddOrSetItem(t.parentID,e)),e.Add(t),
t.expand&&(this.curTreeData=t)}}this.titleH=this.titleDatas.count*this.titleCellH,this.maxScrollH=this.maxH-this.titleH,
null!=this.curTitleTreeData&&(this.expandTitleID=this.curTitleTreeData.id),this.SetGridData(),this.Refresh()}SetGridData(){
null!=this.curTitleTreeData&&this.curTitleTreeData.expand?this.grid.data_set(this.GetChildList(this.curTitleTreeData.id)):this.grid.data_set(null)}Refresh(){this.ToPool()
const e=this.titleDatas.count-1
for(let t=0;t<=e;t++){const e=this.GetItem()
e.onClick=this.CreateDelegate(this.ItemClickHandler),e.SetData(this.titleDatas[t]),this.titleItems.Add(e)}this.SelectTitleAndItem(this.curTreeData,this.curTitleTreeData,null)}
OnGridReposition(){null!=this.curTreeData&&this.UpdateItemSelect(this.curTreeData)}ChangeTreeSelect(e,t){if(null==t&&(t=!1),
null==e?this.SelectTitleAndItem(null,null,t):e.expand=!0,e.IsTitle())this.SelectTitleAndItem(null,e,t)
else{const i=this.GetTreeTitleById(e.parentID)
i.expand=!0,this.SelectTitleAndItem(e,i,t)}}SelectTitleAndItem(e,t,i){if(null!=e)null==t&&((t=this.GetTreeTitleById(e.parentID)).expand=!0)
else if(null==t&&(t=this.titleDatas[0]),this.selectOneForce||t.expand){let i=null
this.treeDataDic.LuaDic_ContainsKey(t.id)&&(i=this.treeDataDic.LuaDic_GetItem(t.id),i.count>0&&(e=i[0]))}null!=e&&(null!=t&&(t.expand=!0),e.expand=!0),
this.UpdateTitleSelect(t,t.expand),this.UpdateItemSelect(e),i&&(null!=this.curTreeData?this.CallOnSelect(this.curTreeData):this.CallOnSelect(this.curTitleTreeData))}
GetChildList(e){return this.treeDataDic.LuaDic_ContainsKey(e)?this.treeDataDic.LuaDic_GetItem(e):null}ToPool(){const e=this.titleItems.count-1
for(let t=0;t<=e;t++)this.titleItems[t].Clear(),this.titleItemPool.Add(this.titleItems[t])
this.titleItems.Clear()}GetItem(){let e=null
if(null!=this.titleItemPool&&this.titleItemPool.count>0)return e=this.titleItemPool[this.titleItemPool.count-1],e
const t=St.g.GetResFindId(this.treeTitleItemName)
return e=new this.m_titleitemCls,e.setPrefabRootId(t),e}GetDataByIndex(e){return this._refreshData[this._sIndex+e]}CallReposition(){null!=this.m_onReposition&&this.m_onReposition()
}OnReposition_set(e){this.m_onReposition=e}CallOnSelect(e){null!=this.m_onSelect&&this.m_onSelect(e)}OnSelect_set(e){this.m_onSelect=e}ItemClickHandler(e){
e.treeData.IsTitle()?(e.treeData.expand=!e.treeData.expand,this.SelectTitleAndItem(null,e.treeData,!0)):(e.treeData.expand=!0,this.SelectTitleAndItem(e.treeData,null,!0))}
GetTreeTitleById(e){const t=this.titleDatas.count-1
for(let i=0;i<=t;i++)if(this.titleDatas[i].id==e)return this.titleDatas[i]
return null}UpdateItemSelect(e){if(this.curTreeData!=e&&(null!=this.curTreeData&&(this.curTreeData.expand=!1),this.curTreeData=e),null!=e){const t=this.grid.itemList
if(null!=t){const i=t.count-1
for(let n=0;n<=i;n++){const i=t[n]
i.treeData==e?(i.treeData.expand=!0,i.SetSelect(!0)):(i.treeData.expand=!1,i.SetSelect(!1))}}}}UpdateTitleSelect(e,t){
this.curTitleTreeData!=e&&(null!=this.curTitleTreeData&&(this.curTitleTreeData.expand=!1),this.curTitleTreeData=e)
let i=null
null!=this.curTitleTreeData&&this.curTitleTreeData.expand&&(i=this.curTitleTreeData.id),this.expandTitleID!=i&&(this.SetGridData(),this.expandTitleID=i)
const n=this.titleItems.count-1
let s=0
for(let e=0;e<=n;e++)if(this.titleItems[e].node.transform.SetLocalPositionXYZ(0,s,0),s-=this.titleCellH,this.titleItems[e].treeData==this.curTitleTreeData){
if(this.titleItems[e].SetSelect(t),t){const e=this.GetChildList(this.curTitleTreeData.id)
if(null!=e){this.itemview.transform.SetLocalPositionXYZ(this.itemVx,s,0)
let t=e.count*this.itemH
t>this.maxScrollH&&(t=this.maxScrollH),t>this.ScrollH&&(t=this.ScrollH),this.curScrollH!=t&&(this.curScrollH=t),s-=t}}}else this.titleItems[e].treeData.expand=!1,
this.titleItems[e].SetSelect(!1)}selectById(e){}AddEventHandler(e,t){this.notifier.AddEventHandler(e,t)}RemoveEventHandler(e,t){this.notifier.AddEventHandler(e,t)}Clear(){
super.Clear()}Destroy(){this.ToPool(),this.notifier.Destroy()
const e=this.titleItemPool.count-1
for(let t=0;t<=e;t++)this.titleItemPool[t].Clear(),this.titleItemPool[t].Destroy(),St.g.DestroyUIById(this.titleItemPool[t].FatherId)
this.titleItemPool=null}})
var kt,Ft=i(95414),Ht=i(37325);(0,x.s_)(Q.o.eCommonKillTipPanel,Y.Z.ui_comm_commkilltippanel).register()(kt=class extends((0,V.pA)(Et.I)()){constructor(...e){super(...e),
this._model=null,this.delayTimer=-1,this._degf_CloseHandler=null}_initBinder(){super._initBinder(),this._degf_CloseHandler=()=>this.CloseHandler()}InitView(){
this._model=Ht.r.Inst_get()}Clear(){this.ClearDelayData(),this._model.killShowText=""}Destroy(){}OnAddToScene(){this.anim.resume(),this.SetData()}SetData(){this.ClearDelayData(),
null!=this._model&&null!=this._model.killShowText&&""!=this._model.killShowText?(this.showText.textSet(this._model.killShowText),
this.delayTimer=Se.C.Inst_get().SetInterval(this._degf_CloseHandler,3e3)):this.CloseHandler()}CloseHandler(){this.ClearDelayData(),Ft.I.inst.CloseCommonKillTipView()}
ClearDelayData(){Se.C.Inst_get().ClearInterval(this.delayTimer),this.delayTimer=-1}})
var xt,Vt=i(2689),Yt=i(57834),Wt=i(95721),Kt=i(92473),Zt=i(22662),zt=i(69429),qt=i(21370),$t=i(40053),Xt=i(619);(0,
x.s_)(je.I.BossMemberDamagePanel,Y.Z.ui_copybaseui_commonrightview).waitPrefab(Y.Z.ui_bossassistpanel).waitPrefab(Y.Z.ui_treasure_bossdropitem_big).waitPrefab($t.Z.RyForgeEquipListItem_baseItemPrefabs).waitPrefab(Y.Z.ui_bossassist_item).layerSet(qt.T.nav).register()(xt=class extends((0,
V.Ri)()){constructor(...e){super(...e),this.isPanelOut=!0,this.m_moveTween=null,this.m_iconRotate=null,this.m_btnIndex=1,this.curTeamTipType=0,this.showType=0,
this._degf_FinishHandler=null,this._degf_OnBtnClick=null,this._degf_OnBossBtnClick=null,this._degf_OnTeamStateRefresh=null,this._degf_UpdateAnchors=null,
this._degf_OnPkUIUpdate=null,this.msgContainer=null,this.m_teamBtn=null,this.m_taskBtn=null,this.bgBtn=null,this.teamColider=null,this.taskColider=null,this.taskSymbol=null,
this.teamSymbol=null,this.inSpName=null,this.outSpName=null,this.bAncientBoss=null}_initBinder(){super._initBinder(),this.m_iconRotate=new at.P,
this._degf_FinishHandler=()=>this.FinishHandler(),this._degf_OnBtnClick=e=>this.OnBtnClick(e),this._degf_OnBossBtnClick=(e,t)=>this.OnBossBtnClick(e,t),
this._degf_OnTeamStateRefresh=e=>this.OnTeamStateRefresh(e),this._degf_UpdateAnchors=e=>this.UpdateAnchors(e),this._degf_OnPkUIUpdate=e=>this.OnPkUIUpdate(e)}InitView(){
this.inSpName="mbcommon_bt_0053",this.outSpName="mbcommon_bt_0054",this.m_moveTween=new Xt.m
let e=""
const t=u.b.Inst.GetCurMap()
null!=t&&(e=t.controllerType,this.bAncientBoss=e==Vt.N.BATTLEFIELD||e==Vt.N.CROSS_BOSS_CLIENT,h.O.SetAnchorPos(this.anchor,!0,!0,0))}AddToScene(){this.AddOrDelEvent(!0),
null!=this.m_taskBtn&&this.OnBtnClick(this.m_taskBtn)
const e=F.p.Inst_get().GetMapById(u.b.Inst.currentMapId_get())
"SCENE"!=e.controllerType&&"MIRACLEMAINLAND"!=e.controllerType&&"MIRACLEMAINLAND_SCENE_COPY"!=e.controllerType||(rt.F.Inst_get().isInPkUI?this.SwitchToPk():this.SwitchToNormal())}
InitTeamTipType(e){null==e&&(e=0),this.curTeamTipType=e}AddOrDelEvent(e){this.outBtn&&this.outBtn.node&&(e?(Yt.i.Get(this.outBtn.node).RegistonClick(this._degf_OnBtnClick),
null!=this.m_teamBtn&&(Yt.i.Get(this.m_teamBtn.node).RegistonClick(this._degf_OnBtnClick),Yt.i.Get(this.teamColider.node).RegistonClick(this._degf_OnBtnClick),
Yt.i.Get(this.taskColider.node).RegistonClick(this._degf_OnBtnClick),Yt.i.Get(this.m_taskBtn.node).RegistonClick(this._degf_OnBtnClick)),
null!=this.bossBtn&&Yt.i.Get(this.bossBtn.node).RegistonClick(this._degf_OnBossBtnClick),Yt.i.Get(this.hideBtn.node).RegistonClick(this._degf_OnBtnClick),
null!=this.bgBtn&&Yt.i.Get(this.bgBtn.node).RegistonClick(this._degf_OnBtnClick),l.i.Inst.AddEventHandler(q.g.TEAM_CREATEORDISBAND,this._degf_OnTeamStateRefresh),
l.i.Inst.AddEventHandler(q.g.UPDATE_ANCHORS,this._degf_UpdateAnchors),
l.i.Inst.AddEventHandler(q.g.PK_UI_UPDATE,this._degf_OnPkUIUpdate)):(Yt.i.Get(this.outBtn.node).RemoveonClick(this._degf_OnBtnClick),
null!=this.m_teamBtn&&(Yt.i.Get(this.m_teamBtn.node).RemoveonClick(this._degf_OnBtnClick),Yt.i.Get(this.teamColider.node).RemoveonClick(this._degf_OnBtnClick),
Yt.i.Get(this.taskColider.node).RemoveonClick(this._degf_OnBtnClick),Yt.i.Get(this.m_taskBtn.node).RemoveonClick(this._degf_OnBtnClick)),
null!=this.bossBtn&&(Yt.i.Get(this.hideBtn.node).RemoveonClick(this._degf_OnBtnClick),Yt.i.Get(this.bossBtn.node).RemoveonClick(this._degf_OnBossBtnClick)),
null!=this.bgBtn&&Yt.i.Get(this.bgBtn.node).RemoveonClick(this._degf_OnBtnClick),l.i.Inst.RemoveEventHandler(q.g.TEAM_CREATEORDISBAND,this._degf_OnTeamStateRefresh),
l.i.Inst.RemoveEventHandler(q.g.UPDATE_ANCHORS,this._degf_UpdateAnchors),l.i.Inst.RemoveEventHandler(q.g.PK_UI_UPDATE,this._degf_OnPkUIUpdate)))}UpdateAnchors(e){}
OnTeamStateRefresh(e){e?this.OnBtnClick(this.m_teamBtn):this.OnBtnClick(this.m_taskBtn)}OnPkUIUpdate(e){const t=F.p.Inst_get().GetMapById(u.b.Inst.currentMapId_get())
"SCENE"!=t.controllerType&&"MIRACLEMAINLAND"!=t.controllerType&&"MIRACLEMAINLAND_SCENE_COPY"!=t.controllerType||(rt.F.Inst_get().isInPkUI?this.SwitchToPk():this.SwitchToNormal())}
SetData(e,t,i,n,s,a,r,l,o){this.msgContainer=e,this.m_teamBtn=i,this.m_taskBtn=n,this.bgBtn=s,this.teamColider=a,this.taskColider=r,this.taskSymbol=l,this.teamSymbol=o,
this.RefreshPos()}RefreshPos(e,t){zt.v.ins&&zt.v.ins.IsInRolandSaveCommon()?(this.hideBtn.node.transform.SetLocalPositionXYZ(-23,-20,0),this.bossBtn.SetActive(!1),
this.offset.transform.SetLocalPositionXYZ(45,50,0)):(this.hideBtn.node.transform.SetLocalPositionXYZ(-23,43,0),this.bossBtn.SetActive(!0),
O.o.getInstance().InKarima()||Kt.R.Inst_get().IsInCrossBattle()?this.offset.transform.SetLocalPositionXYZ(45,23,0):this.offset.transform.SetLocalPositionXYZ(45,91,0))}
OnBossBtnClick(e,t){if(l.i.Inst.RaiseEvent(q.g.BOSS_RIGHTPANEL_CLICK),!this.bAncientBoss)return
const i=H.x.Inst_get(),n=!i.IsShowingBossList()
i.memberDmgView.FocusBossListView(n),i.memberDmgView.SetShowBossList(n)}OnBtnClick(e){let t=(0,W.t2)(e,oe.EventTouch)?e.target:e
if(this.hideBtn.node==t)this.isPanelOut?(this.outIcon.spriteNameSet(this.outSpName),this.isPanelOut=!1,
this.m_moveTween.SetLuaParam(this.moveContainer.transform,-8,-410,this._degf_FinishHandler),this.m_moveTween.StartTween(),this.m_iconRotate.z=0,
this.hideIcon.node.eulerAngles=this.m_iconRotate):(this.msgContainer.SetActive(0==this.showType),this.isPanelOut=!0,
this.m_moveTween.SetLuaParam(this.moveContainer.transform,-410,-8,this._degf_FinishHandler),this.m_moveTween.StartTween(),this.outIcon.spriteNameSet(this.inSpName),
this.m_iconRotate.z=180,this.hideIcon.node.eulerAngles=this.m_iconRotate)
else if(null!=this.m_taskBtn&&this.m_taskBtn==t)this.showType=0,this.taskColider.node.SetActive(!0),this.teamColider.node.SetActive(!1),this.m_taskBtn.SetIsEnabled(!1),
this.m_teamBtn.SetIsEnabled(!0),this.OnTabSelected(this.showType),l.i.Inst.RaiseEvent(q.g.COPY_INFOPANEL_SHOWSTATE,!0)
else if(null!=this.m_teamBtn.node&&this.m_teamBtn.node==t)this.showType=1,this.msgContainer.SetActive(!1),this.taskColider.node.SetActive(!1),this.teamColider.node.SetActive(!0),
this.m_taskBtn.SetIsEnabled(!0),this.m_teamBtn.SetIsEnabled(!1),this.OnTabSelected(this.showType),l.i.Inst.RaiseEvent(q.g.COPY_INFOPANEL_SHOWSTATE,!1)
else if(null!=this.taskColider&&this.taskColider==t);else if(null!=this.bgBtn&&this.bgBtn==t)o._.getInst().startPlayerHang(n.Y.Inst.PrimaryRole_get())
else if(null!=this.teamColider&&this.teamColider==t){if(n.Y.Inst.PrimaryRoleInfo_get().teamId_get().Equal(Wt.o.New(0,0))){
if(HideMapUIExtend.Inst_get().banTeamResult_get().Contains(u.b.Inst.currentMapId_get()))return void SystemTipsControl.inst.ClientStrMsg(Zt.r.SystemTipMessage,(0,_e.T)("该地图禁止组队"))
TeamControl.Inst_get().openOrClose(0)}else;}}OnTabSelected(e){this.m_btnIndex=e
let t="mainui_icon_0024",i="mainui_icon_0028"
1==e&&(t="mainui_icon_0025",i="mainui_icon_0027"),this.taskSymbol.spriteNameSet(t),this.teamSymbol.spriteNameSet(i)}FinishHandler(){this.isPanelOut||this.msgContainer.SetActive(!1)
const e=0==this.showType&&this.isPanelOut
l.i.Inst.RaiseEvent(q.g.COPY_INFOPANEL_SHOWSTATE,e)}SwitchToPk(){if(this.isPanelOut){this.isPanelOut=!1
const e=new at.P(256,this.moveContainer.position.y,0)
this.moveContainer.transform.SetLocalPosition(e),this.FinishHandler(),this.m_iconRotate.z=180,this.outIcon.spriteNameSet(this.inSpName)}}SwitchToNormal(){
this.isPanelOut||this.OnBtnClick(this.outBtn)}Clear(){this.AddOrDelEvent(!1),this.m_moveTween.isClear=!0}Destroy(){this.m_moveTween.Destroy(),this.m_moveTween=null}})
var Qt,jt=i(65801),Jt=i(73423);(0,x.s_)(Q.o.FLYEFFVIEW,Y.Z.ui_ry_fly_eff_panel).waitPrefab(Y.Z.ui_map_pass_eff).register()(Qt=class extends((0,V.Ri)()){constructor(...e){
super(...e),this._effClassDic=null,this.poolDic=null,this.poolTotalLen=null,this.key=null,this._effClassDic2=null}InitView(){super.InitView(),this._effClassDic=new Fe.X,
this._effClassDic2=new Fe.X,this.poolDic=new Fe.X,this.poolTotalLen=0,this.key=0}OnAddToScene(){this.PlayEffect()}GetKey(){
return this.key==st.GF.INT32_MAX_VALUE_get()&&(this.key=0),this.key+=1,this.key}PlayEffect(){const e=Jt.B.Inst().vo
if(null!=e){let t=null
const i=e.effectPath
null==this._effClassDic2[i]?(t=new jt.x(i,e.startPos,e.endPos,e.duration,e.endTime,e.endCallbackFun,null,null,null,null),t.id=this.GetKey(),Jt.B.Inst().vo=null,
"ui_map_pass_eff"==i?t.uiCreate=St.g.LoadScriptPrefab(Y.Z.ui_map_pass_eff,N.a,this.CreateDelegate(this.OnLoadEffect),this.effListObj):"ui_mappass_enter_eff"==i&&(t.uiCreate=St.g.LoadScriptPrefab(Y.Z.ui_mappass_enter_eff,M.b,this.CreateDelegate(this.OnLoadEffect),this.effListObj)),
this._effClassDic2[i]=t.uiCreate):this._effClassDic2[i].node._cnode.OnAddToScene()}return-1}ClearEffect(e){}OnLoadEffect(e){}CalNum(e){this.poolTotalLen+=e}GetEffInPool(e){
const t=e.effectPath
if(this.poolDic.LuaDic_ContainsKey(t)){const i=this.poolDic[t].Pop()
if(null!=i)return this.CalNum(-1),i.Clone(e),i}return null}EffPlayEnd(e){this._effClassDic[e]}Clear(){for(const[e,t]of(0,Ct.V5)(this._effClassDic))t.Clear(),t.Destroy()
this._effClassDic.Clear()
for(const[e,t]of(0,Ct.V5)(this.poolDic)){for(let e=0;e<=t.Count()-1;e++)t[e].Clear(),t[e].Destroy()
t.Clear()}this.poolDic.Clear(),super.Clear()}Destroy(){this._effClassDic=null,this.poolDic=null,super.destroy()}})
class ei extends((0,V.yk)()){constructor(...e){super(...e),this.curData=null,this._degf_ClickHandler=null}_initBinder(){this._degf_ClickHandler=(e,t)=>this.ClickHandler(e,t)}
InitView(){Yt.i.Get(this.itembtn.node).RegistonClick(this._degf_ClickHandler)}ClickHandler(e,t){null!=this.curData&&null!=this.curData.handler&&(this.curData.guideId,
this.curData.handler(this.curData))}SetIsEnabled(e){this.itembtn.SetIsEnabled(e)}SetData(e){this.UnRegGuide(),null!=e&&(this.curData=e,this.itembtn.SetText(this.curData.showStr),
this.splitGo.SetActive(!this.curData.isFinal),this.itembtn.SetIsEnabled(!0),this.RegGuide())}SetSelect(e){this.isSelect.node.active=e}RegGuide(){
null!=this.curData&&this.curData.guideId}UnRegGuide(){null!=this.curData&&this.curData.guideId}Clear(){this.UnRegGuide()}Destroy(){}}var ti
oe._decorator.ccclass("CommonMenuView")(ti=class extends((0,V.pA)(he.C)()){constructor(...e){super(...e),this.showText=null,this.openCollider=null,this.closeCollider=null,
this._model=null,this.menuData=null,this._degf_ClickHander=null,this._degf_CreateMenuItem=null,this._degf_ItemClickHander=null,this._degf_GridOnReposition=null,
this._degf_ItemClickHandler=null,this.guideOpenId=null,this.selectData=null}_initBinder(){this._degf_ClickHander=(e,t)=>this.ClickHander(e,t),
this._degf_CreateMenuItem=e=>this.CreateMenuItem(e),this._degf_ItemClickHander=e=>{},this._degf_GridOnReposition=()=>this.GridOnReposition(),
this._degf_ItemClickHandler=e=>this.ItemClickHandler(e)}InitView(){this.showText=this.typeText,this.grid.SetInitInfo("ui_surface_menuitem_ry",this.CreateMenuItem,ei),
this.grid.OnReposition_set(this._degf_GridOnReposition),this.guideOpenId=null,this._model=Ht.r.Inst_get(),super.InitView()}SetInitInfo(e){}CreateMenuItem(e){}GridOnReposition(){
this.UpdateMenuItemSelect()}UpdateMenuItemSelect(){if(null!=this.grid.itemList&&null!=this.menuData&&null!=this.menuData.selectData)for(const[e,t]of(0,
Ct.V5)(this.grid.itemList))null!=t&&null!=t.curData&&(t.SetIsEnabled(t.curData.key!=this.menuData.selectData.key),t.SetSelect(t.curData.key==this.menuData.selectData.key))}
InitData(e){if(this.menuData=e,this.AddOrRemoveLis(),null!=this.menuData&&null!=this.menuData.dataList)for(const[e,t]of(0,
Ct.V5)(this.menuData.dataList))t.handler=this._degf_ItemClickHandler
let t=null
null!=this.menuData&&(t=this.menuData.dataList),this.grid.data_set(t),this.SetGoState(!1),
null!=this.menuData&&null!=this.menuData.selectData&&this.showText.textSet(this.menuData.selectData.showStr),this.RegGuide()}RegGuide(){this.guideOpenId}UnRegGuide(){
this.guideOpenId}ClearData(){this.UnRegGuide(),this.AddOrRemoveLis(!1),this.grid.Clear(),this.menuData=null,this.selectData=null}AddOrRemoveLis(e){null==e&&(e=!0),
e?this.AddLis():this.RemoveLis()}AddLis(){this.typeBg.node.on(oe.NodeEventType.TOUCH_END,this.ClickHanderOpen,this)}RemoveLis(){
this.typeBg.node.off(oe.NodeEventType.TOUCH_END,this.ClickHanderOpen,this)}ClickHander(e,t){e==this.openCollider.ComponentId?(this.UpdateMenuItemSelect(),
this.ClickHanderOpen()):e==this.closeCollider.ComponentId&&this.ClickHanderClose()}ClickHanderOpen(){(0,Ce.D1)(this,this.ClickHanderClose),this.UpdateMenuItemSelect(),
this.SetGoState(!0),this.guideOpenId}ClickHanderClose(){(0,Ce.Rt)(this),this.SetGoState(!1)}ItemClickHandler(e){
null!=e&&null!=this.menuData&&null!=this.menuData.selectData&&e.key!=this.menuData.selectData.key&&(this.menuData.selectData=e,this.UpdateText(),this.SetGoState(!1),
null!=this.menuData.handler&&this.menuData.handler(this.menuData.selectData))}UpdateText(e){this.showText.textSet(this.menuData.selectData.showStr)}SetGoState(e){
this.openIcon.SetActive(!e),e?this.UnRegGuide():this.RegGuide(),this.closeIcon.SetActive(e)}Destroy(){}})
var ii,ni,si=i(88653),ai=i(44758),ri=i(3110),li=i(93078)
oe._decorator.ccclass("RyNumSlider")((ni=class e extends((0,V.pA)(oe.Slider)()){constructor(...e){super(...e),this.noticeStrMax=null,this.noticeStrMin=null,this.showDragEff=!1,
this.enbaleLimitBtn=!1,this.clickMoveEnable=!0,this.isOpenNumInput=!1,this.UseNumPos=null,this.setWidthProgressBar=null,this.dragLength=null,this.leftEndX=null,this.rightEndX=null,
this.addpress=null,this.removepress=null,this.endY=null,this.callBack=null,this.curNum=null,this.MaxNum=null,this.MinNum=null,this.intervalId=-1,
this.SetWidthProgressBarOriginW=null,this.dragIndex=null,this.TetTimerId=null}_initBinder(){(0,ri.v)(this,this.node)}InitView(){this.dragWidget.getComponent(oe.UITransform).width
this.endY=0,this.callBack=null,this.curNum=0,this.MaxNum=0,this.MinNum=0,this.handle=this.dragBar}AddLis(){this.addBtn.node.on(oe.NodeEventType.TOUCH_END,this.OnAddClick,this,!1),
this.subBtn.node.on(oe.NodeEventType.TOUCH_END,this.OnRemoveClick,this,!1),this.UseNumPos,this.curNum=this.MaxNum,this.updateSliderView()}RemoveLis(){
this.addBtn.node.off(oe.NodeEventType.TOUCH_END,this.OnAddClick,this,!1),this.subBtn.node.off(oe.NodeEventType.TOUCH_END,this.OnRemoveClick,this,!1)}doScrollHandler(){
if(this.progressBar.widthSet(this.handle.x+55),this.MaxNum>1){const e=(this.handle.x+55)/115
this.curNum=Pe.p.RoundToInt((this.MaxNum-this.MinNum)*e)+this.MinNum,this.CheckNum()}this.numLbl.textSet(Z.M.IntToString(this.curNum)),l.i.Inst.RaiseEvent(q.g.UPDATE_SLIDER)}
SetCur(e,t=null){this.curNum=e,this.updateSliderView()}updateSliderView(){this.handle.x=this.curNum/this.MaxNum*115-55,this.progressBar.widthSet(this.handle.x+55),
this.numLbl.textSet(Z.M.IntToString(this.curNum)),this.CheckNum(),this.UpdateNum(),l.i.Inst.RaiseEvent(q.g.UPDATE_SLIDER)}_updateHandlePosition(){
this.progressBar&&1!=this.MaxNum&&(super._updateHandlePosition(),this.doScrollHandler())}SelectUseNumHandler(e){li.F.Instance_get().CloseView(),
li.F.Instance_get().OpenView(this.UseNumPos,this.CreateDelegate(this.InputNumHandler),this.CreateDelegate(this.CloseInputNumHandler)),this.isOpenNumInput=!0}
CloseInputNumHandler(e,t){this.isOpenNumInput=!1,this.curNum<this.MinNum&&(this.curNum=this.MinNum),this.UpdateSlider()}InputNumHandler(e,t){
1!=this.MaxNum?(10==e?this.curNum=0:t?this.curNum=e:(this.curNum*=10,this.curNum+=e),this.curNum>this.MaxNum&&(this.curNum=this.MaxNum),
this.curNum>=this.MinNum?this.UpdateSlider():this.UpdateNum()):null!=this.noticeStrMax&&k.y.inst.ClientSysStrMsg(this.noticeStrMax)}OnAddClick(e,t){
this.curNum!=this.MaxNum?this.curNum>=this.MaxNum||(this.curNum+=1,this.SetCur(this.curNum)):null!=this.noticeStrMax&&k.y.inst.ClientSysStrMsg(this.noticeStrMax)}
OnRemoveClick(e,t){this.curNum<=1||(this.curNum-=1,this.SetCur(this.curNum))}OnBarPress(e,t){}OnWidgetPress(e,t){}SetProcessBarValue(e){}CalSilderNum(e){if(this.MaxNum>1){
const t=(this.dragBar.transform.GetLocalPosition().x-this.leftEndX)/this.dragLength
this.curNum=Pe.p.RoundToInt((this.MaxNum-this.MinNum)*t)+this.MinNum,this.CheckNum(),
this.MaxNum==this.MinNum?this.SetProcessBarValue(1):this.SetProcessBarValue((this.curNum-this.MinNum)/(this.MaxNum-this.MinNum)),this.UpdateNum(e)}}CheckNum(){
this.curNum>this.MaxNum&&(this.curNum=this.MaxNum),this.curNum<this.MinNum&&(this.curNum=this.MinNum)}GetCurNum(){return this.curNum}AddPressHandler(){
this.curNum!=this.MaxNum?(this.curNum+=1,this.UpdateSlider()):null!=this.noticeStrMax&&k.y.inst.ClientSysStrMsg(this.noticeStrMax)}RemovePressHandler(){
this.curNum!=this.MinNum?(this.curNum-=1,this.UpdateSlider()):null!=this.noticeStrMin&&k.y.inst.ClientSysStrMsg(this.noticeStrMin)}UpdateSlider(){
if(0==this.MaxNum)return this.dragBar.transform.SetLocalPositionXYZ(0,this.endY,0),this.curNum=0,this.UpdateNum(),void this.SetProcessBarValue(0)
this.CheckNum(),this.UpdateNum()
let e=this.leftEndX
0!=this.MaxNum&&(e=this.MaxNum-this.MinNum==0?this.leftEndX+this.dragLength:this.leftEndX+this.dragLength*(this.curNum-this.MinNum)/(this.MaxNum-this.MinNum)),
e<this.leftEndX?e=this.leftEndX:e>this.leftEndX+this.dragLength&&(e=this.leftEndX+this.dragLength),this.dragBar.transform.SetLocalPositionXYZ(e,this.endY,0)
let t=(e-this.leftEndX)/this.dragLength
t<0?t=0:t>1&&(t=1),this.SetProcessBarValue(t)}SetBtnState(){this.subBtn.SetIsEnabled(this.curNum>this.MinNum),this.addBtn.SetIsEnabled(this.curNum<this.MaxNum)}InitData(e,t,i){
this.MinNum=t,this.MaxNum=i,this.curNum=e,this.UpdateSlider(),this.AddLis()
new ai.L(this.leftEndX,this.endY,this.rightEndX,this.endY)}DragCallBack(e,t){
1!=this.MaxNum?this.CalSilderNum(!0):null!=this.noticeStrMax&&k.y.inst.ClientSysStrMsg(this.noticeStrMax)}DragEndHandler(e,t){this.UpdateNum(!1)}AddCallBack(e){this.callBack=e}
SetMax(e,t){this.MaxNum=e,null!=t&&t&&this.UpdateSlider()}SetMin(e,t){this.MinNum=e,null!=t&&t&&this.UpdateSlider()}ClearData(){this.MinNum=0,this.MaxNum=0,this.curNum=0}
UpdateNum(e=null){this.numLbl.textSet(Z.M.IntToString(this.curNum)),this.curNum>0?this.dragVal.textSet(Z.M.IntToString(this.curNum)):this.dragVal.textSet(""),
this.enbaleLimitBtn&&this.SetBtnState(),this.SetTxtState(e),null!=this.callBack&&this.callBack()}SetTxtState(t){null==t&&(t=!1),
null!=this.bubbleVal&&(t?(this.bubbleObj.SetActive(!0),this.bubbleVal.textSet(Z.M.IntToString(this.curNum))):this.bubbleObj.SetActive(!1)),
null!=this.TetTimerId&&Se.C.Inst_get().ClearInterval(this.TetTimerId),
this.showDragEff&&(t?(this.TetTimerId=Se.C.Inst_get().SetInterval(this.CreateDelegate(this.TextHandler),150,1),this.numLbl.fontSize=26,
this.numLbl.SetColor(e.greenColor)):(this.numLbl.fontSize=18,this.numLbl.SetColor(e.normalColor)))}TextHandler(){this.UpdateNum(!1)}Clear(){
this.isOpenNumInput&&(li.F.Instance_get().CloseView(),this.isOpenNumInput=!1),null!=this.UseNumPos&&(at.P.Recyle(this.UseNumPos),this.UseNumPos=null),
null!=this.TetTimerId&&Se.C.Inst_get().ClearInterval(this.TetTimerId),this.callBack=null,this.ClearData(),this.RemoveLis(),Se.C.Inst_get().ClearInterval(this.intervalId),
this.intervalId=-1}Destroy(){}},ni.greenColor=new si.I(88/255,237/255,88/255,1),ni.normalColor=new si.I(.8,203/255,196/255,1),ii=ni))
var oi
const{ccclass:_i,executeInEditMode:ui,menu:hi,property:ci,type:di}=oe._decorator
oe._decorator.ccclass("RyPageComponent")(oi=class extends $e.${constructor(...e){super(...e),this.nextBtn=null,this.previousBtn=null,this.pageLab=null,this.total=0,this.curPage=0,
this.isHide=!0,this.callback=null}InitView(){super.InitView()
let e=Yt.i.Get(this.nextBtn.node)
null!=e&&e.RegistonClick(this.CreateDelegate(this.NextHandler)),e=Yt.i.Get(this.previousBtn.node),null!=e&&e.RegistonClick(this.CreateDelegate(this.PreviousHandler))}
NextHandler(e){this.SetCurrentPage(this.curPage+1,!0)}PreviousHandler(e){this.SetCurrentPage(this.curPage-1,!0)}SetTotalPage(e){this.total=e,this.UpdateText(null)}UpdateText(e){
this.curPage>this.total&&(this.curPage=this.total),this.curPage<1&&(this.curPage=1),
this.isHide&&(1==this.curPage?this.previousBtn.node.SetActive(!1):this.previousBtn.node.SetActive(!0),
this.curPage==this.total?this.nextBtn.node.SetActive(!1):this.nextBtn.node.SetActive(!0)),this.pageLab.textSet(`${this.curPage}/${this.total}`),
null!=e&&e&&null!=this.callback&&this.callback(this.curPage)}SetCurrentPage(e,t){this.curPage=e,this.UpdateText(t)}GetCurrentPage(){return this.curPage}GetTotalPage(e){
return this.total}SetHandler(e){this.callback=e}RemoveHandler(e){e==this.callback&&(this.callback=null)}Clear(){super.Clear()}Destroy(){if(null!=this.nextBtn){
let e=Yt.i.Get(this.nextBtn.node)
null!=e&&e.RemoveonClick(this.CreateDelegate(this.NextHandler)),e=Yt.i.Get(this.previousBtn.node),null!=e&&e.RemoveonClick(this.CreateDelegate(this.PreviousHandler))}
this.nextBtn=null,this.previousBtn=null,this.pageLab=null}})
var mi,pi=i(95272),gi=i(87530),Ii=i(64649),Ei=i(47041),Ci=i(98359)
oe._decorator.ccclass("FactoryShopTipPanel")(mi=class extends Ci.k{constructor(...e){super(...e),this.bagType=null}InitView(){super.InitView()}AddLis(){super.AddLis()}RemoveLis(){
super.RemoveLis()}OnCloseBtnHandle(){Ei.N.Inst_get().FullBagTipDeQueue(this.bagType)}OnOptBtnHandle(){
this.bagType==pi.t.ElementBag?gi.L.Inst().OpenEleMianView(Ii.$.UI_ELEMENT_ITEM,Ii.$.UI_ELEMENT_ITEM_SUB_CIRCEL,!0,0):p.J.Inst_get().openOrClose(0),
Ei.N.Inst_get().FullBagTipDeQueue(this.bagType)}SetData(e){this.AddLis(),this.bagType=e.tipSubType
let t=""
t=this.bagType==pi.t.ElementBag?"元素背包已满":"背包已满",this.fatherView.descTxt.textSet(`[dba968]${t}[-]`),this.fatherView.optBtn.SetText(Z.M.DealRichTextOutline("清 理")),
this.fatherView.SetIconByAtlasAndName("mainui","rymainui_open_1028",1.1),this.fatherView.baseItem.node.SetActive(!1)}Clear(){this.RemoveLis(),super.Clear()}Destroy(){
super.Destroy()}})
var Si=i(19176),Ti=i(38844)
const fi=(0,Ue.O$)("app/TweenRotation")
var Ai=i(57035),yi=i(48946),Ri=i(12605),Di=i(86662)
class wi{constructor(){this.moreData=null,this.pos=null,this.spreadDelay=0,this.pos=new at.P(-100,0,0)}}var Li,vi,Oi=i(52396)
const{ccclass:Pi}=oe._decorator
Pi("FuncSetView")(((vi=class extends((0,V.pA)(ct.f)()){constructor(...e){super(...e),this.spreadContainer=null,this.spreadItemList=new z.Z,this.PkChangeBtnState=0,
this.autoBtnNode=null,this.funcItemList=new z.Z,this.dataLis=new z.Z,this.openUpList=new z.Z,this.openMinList=new z.Z,this.openDownList=new z.Z,this.intervalId=-1,
this.shrinkIntervalId=-1,this.spreadInterval=-1,this.isInAnime=!1,this.isout=!1,
this.autoBtnData=new Map([["name","挂机"],["iconPath","atlas/mainui/rymainui_functionicon_0060"],["position","-78,0"],["position_1","-148,0"],["bgPath","atlas/mainui/rymainui_functionicon_0009"],["spritePath","atlas/mainui/rymainui_functionicon_0010"]])
}_initBinder(){}InitView(){this.autoBtnNode=this.autoBtn.node,this.AddLis(),this.UpdateList(),this.DoSpreadSkillView()}AddLis(){
this.m_handlerMgr.AddEventMgr(q.g.PLAYER_LEVELUP,this.CreateDelegate(this.OnLevelUpdate)),this.m_handlerMgr.AddEventMgr(q.g.FUNCTION_OPEN,this.CreateDelegate(this.OnFuncUpdate)),
this.m_handlerMgr.AddEventMgr(q.g.FUNCTION_UPDATE,this.CreateDelegate(this.OnFuncUpdate)),this.m_handlerMgr.AddEventMgr(q.g.FUNCTION_CLOSE,this.CreateDelegate(this.OnFuncUpdate)),
this.m_handlerMgr.AddEventMgr(q.g.FUNCTION_INIT_COMPLETE,this.CreateDelegate(this.OnFuncUpdate)),
this.m_handlerMgr.AddEventMgr(q.g.HANG_STATE_UPDATE,this.CreateDelegate(this.OnHangStateUpdate)),
this.m_handlerMgr.AddEventMgr(q.g.UITweenStateChanged,this.CreateDelegate(this.OnUITweenStateChanged)),
this.m_handlerMgr.AddEventMgr(q.g.UPDATE_ANCHORS,this.CreateDelegate(this._OnUpdateAnchor)),
this.m_handlerMgr.RedPointAddCallback(ce.t.BAG,this.CreateDelegate(this.UpdateRedPoint)),
this.m_handlerMgr.RedPointAddCallback(ce.t.GROW_CHARACTER,this.CreateDelegate(this.UpdateRedPoint)),
this.m_handlerMgr.RedPointAddCallback(ce.t.ENHANCE_LARGE,this.CreateDelegate(this.UpdateRedPoint)),
this.m_handlerMgr.RedPointAddCallback(ce.t.SKILL_VIEW,this.CreateDelegate(this.UpdateRedPoint)),
this.m_handlerMgr.RedPointAddCallback(ce.t.ASURAM,this.CreateDelegate(this.UpdateRedPoint)),
this.m_handlerMgr.RedPointAddCallback(ce.t.RANKING,this.CreateDelegate(this.UpdateRedPoint)),
this.m_handlerMgr.RedPointAddCallback(ce.t.SETUP,this.CreateDelegate(this.UpdateRedPoint))}OnHangStateUpdate(e){this.autoBtn.item.UpdateHangState(e),this.eff_guaji.SetActive(e),
this.effBg.getComponent(fi).SetActive(e)}UpdateRedPoint(e,t){this.SetRedPoint()}SetRedPoint(){if(Oi.h.inst.isBattle){
let e=de.f.Inst.GetData(ce.t.SKILL_VIEW),t=de.f.Inst.GetData(ce.t.ASURAM),i=de.f.Inst.GetData(ce.t.RANKING),n=de.f.Inst.GetData(ce.t.SETUP),s=!1
null!=e&&(s=s||e.show&&this.IsNotMapHide(e.funcId)),null!=t&&(s=s||t.show&&this.IsNotMapHide(t.funcId)),null!=i&&(s=s||i.show&&this.IsNotMapHide(i.funcId)),
null!=n&&(s=s||n.show&&this.IsNotMapHide(n.funcId)),this.redPoint.SetActive(s)}else{let e=!1
this.redPoint.SetActive(e)}}OnLevelUpdate(e){this.funcContainer.active&&this.UpdateList()}OnFuncUpdate(){this.UpdateList()}UpdateList(){this.dataLis.Clear(),
this.DealDataForUpdateList()
let e=0
for(;e<this.funcItemList.Count();)this.funcItemList[e].node.SetActive(!1),e+=1
this.openUpList.Clear(),this.openMinList.Clear(),this.openDownList.Clear()
let t=0
for(;t<this.dataLis.Count();){let e=null
e=t<=this.funcItemList.Count()-1?this.funcItemList[t]:this.loadOneFuncItem(),e.SetData(this.dataLis[t],this.isInAnime)
e.Container.node.getChildByName("icon")
let i=st.GF.INT(this.dataLis[t].moreData.areaId/100)
Oi.h.inst.isBattle,e.node.SetActive(!0),1==i?this.openUpList.Add(this.dataLis[t].moreData.areaId):2==i?this.openMinList.Add(this.dataLis[t].moreData.areaId):3==i&&this.openDownList.Add(this.dataLis[t].moreData.areaId),
this.SetPosAndDelay(this.dataLis[t]),e.node.transform.SetLocalPosition(this.dataLis[t].pos),t+=1}for(;t<this.funcItemList.Count();){this.funcItemList[t].item.UnRegGuide(),t+=1}
this.autoBtn.node.transform.SetLocalPosition(new oe.Vec3(-76*this.openMinList.length,-76,0)),Ri.g.Inst_get().SetAuotBtnX(-76*this.openMinList.Count()),this.SetAutoBtnSkin(),
this.pkchangeBtn.node.on(oe.NodeEventType.TOUCH_END,this.OnChangeBattleClick,this,!1)}DealDataForUpdateList(){
let e=yi.m.Inst_get().GetItemList(),t=F.p.Inst_get().GetMapById(u.b.Inst.currentMapId_get()),i=e.Count()-1
for(;i>=0;){let s=e[i]
if("锻造"==s.name&&console.log("锻造"),1==s.area_type&&(s.shrink==!Oi.h.inst.isBattle||1==s.stay)){let e=Ai.d.Inst_get().GetItemByNameId(s.id)
if(e){n.Y.Inst.PrimaryRoleInfo_get().Level_get()
let i=!0
if(e.id==ye.x.GM&&(i=!1,n.Y.Inst.PrimaryRoleInfo_get().IsGmOpen_get()&&(i=!0)),t&&t.HideButtonsList.Count()>0&&t.HideButtonsList.Contains(s.id)&&(i=!1),e.id,ye.x.MALL,
i&&(e.id==ye.x.GM||Ae.P.Inst_get().IsFunctionShow(e.id)||Ae.P.Inst_get().IsFunctionOpened(e.id)||(i=!1)),i){let t=new Di.T
t.id=e.id,t.areaId=s.area_id,t.icon=s.icon,t.btnId=s.id,t.efftype=s.type,t.stay=s.stay,t.name=s.name
let i=new wi
i.moreData=t,this.dataLis.Add(i)}}}i-=1}}loadOneFuncItem(){const e=It.o.getPrefab("ui_functionopen_spreaditem"),t=(0,oe.instantiate)(e)
let i=null
return i=t.getCNode(),this.funcContainer.addChild(t),this.funcItemList.Add(i),i}SetPosAndDelay(e){let t=e.moreData.areaId,i=st.GF.INT(t/100),n=0,s=0
1==i?(n=this.openUpList.IndexOf(t,0),n+=1,s=0,e.spreadDelay=n-1):2==i?(n=this.openMinList.IndexOf(t,0),s=-76,e.spreadDelay=n-1):3==i&&(n=this.openDownList.IndexOf(t,0),s=-152,
e.spreadDelay=n-1)
let a=new oe.Vec3(-76*n,s,0)
e.pos=a}OnChangeBattleClick(){Oi.h.inst.isBattle=!Oi.h.inst.isBattle,this.UpdateList(),this.DoSpreadSkillView(),this.UpdateRedPoint()}SetAutoBtnSkin(e=!1){
const t=this.funcContainer.getChildByName("autoBtn").getCNode()
t.bg.skin=this.autoBtnData.get("bgPath"),t.bg.node.getChildByName("content").active=!0
const i=t.Container.node.getChildByName("icon").getChildByName("background").getComponent(Ti.E)
if(Si.S.getInst().InHang_get())i.skin="atlas/mainui/rymainui_sp_empty"
else{const e=this.autoBtnData.get("iconPath")
i.skin=e}}GetWorldPos(e){
for(let t=0;t<this.dataLis.length;t++)if(this.dataLis[t].moreData.id==e)return new at.P(this.funcContainer.getWorldPosition().x+this.dataLis[t].pos.x,this.funcContainer.getWorldPosition().y+Math.abs(this.dataLis[t].pos.y),0)
return at.P.zero_get()}SetItemPositionByStr(e,t){const i=null==t?void 0:t.split(",",2),n=[Number(i[0]),Number(i[1])]
e.setPosition(n[0],n[1])}DoSpreadSkillView(){console.log("DoSpreadSkillView")
let e=(0,Ce.Y)(Q.o.MainSkillListPanel)
e&&(Oi.h.inst.isBattle?e.node.SetActive(!0):e.node.SetActive(!1))}_OnUpdateAnchor(){h.O.SetAnchorPos(this.anchor,!1,!0,-2,!1)}IsNotMapHide(e){let t=Ai.d.Inst_get().getItemById(e)
if(t&&!fe.l.IsEmptyStr(t.nameId)){let e=F.p.Inst_get().GetMapById(u.b.Inst.currentMapId_get())
if(null!=e&&e.HideButtonsList.Count()>0&&e.HideButtonsList.Contains(t.nameId))return!1}return!0}OnUITweenStateChanged(e,t){null==t&&(t=!1),(this.isout!=e||t)&&(this.isout=e,
this.node.visible=!e)}OnAddToScene(){this._OnUpdateAnchor()
const e=yi.m.Inst_get().getItemById("AUTO"),t=Ai.d.Inst_get().GetItemByNameId(e.id),i=new Di.T
i.id=t.id,i.areaId=e.area_id,i.icon=e.icon,i.btnId=e.id,i.efftype=e.type,i.stay=e.stay
const n=new wi
n.moreData=i,this.autoBtn.SetData(n),this.OnHangStateUpdate(Si.S.getInst().InHang_get()),this.UpdateRedPoint()}Clear(){}Destory(){}
}).spreadItemIconNames=[new Map([["name","GM"],["iconPath","atlas/mainui/rymainui_open_1034"],["position","-8,70"]]),new Map([["name","角色"],["iconPath","atlas/mainui/rymainui_functionicon_1004"],["position","-8,0"]]),new Map([["name","背包"],["iconPath","atlas/mainui/rymainui_functionicon_1006"],["position","62,0"]]),new Map([["name","技能"],["iconPath","atlas/mainui/rymainui_functionicon_1001"],["position","-78,0"],["active","false"]]),new Map([["name","设置"],["iconPath","atlas/mainui/rymainui_functionicon_1007"],["position","62,-70"],["active","false"]]),new Map([["name","锻造"],["iconPath","atlas/mainui/rymainui_functionicon_1005"],["position","-8,-70"],["active","false"]])],
Li=vi))
var Ni
const{ccclass:Mi}=oe._decorator
Mi("FuncSpreadItem")(Ni=class extends((0,V.yk)()){constructor(...e){super(...e),this.item=null,this.shrinkTweenPos=null,this.shrinkTweenAlpha=null,this.animeWidget=null,
this.dat=null,this.lastDelay=0,this.shrinkIntervalId=-1,this.loopId=-1,this._degf_DelaySpread=null,this.resPath="atlas/mainui/"}_initBinder(){super._initBinder(),
this._degf_DelaySpread=()=>this.DelaySpread()}InitView(){this.item=this.ui_moreitem}Clear(){this.item.Clear(),Se.C.Inst_get().ClearLoop(this.loopId),this.loopId=-1}Destroy(){}
SetData(e,t=!1){const i=e
this.dat=i,this.item.SetData(i.moreData)
const n=new at.P(-40,0,0)
at.P.Recyle(n),i.moreData.id==ye.x.AUTO?this.bg.spriteNameSet(this.resPath+"rymainui_functionicon_0009"):this.bg.spriteNameSet(this.resPath+"rymainui_sp_0019"),this.UpdateView()}
UpdateView(){const e=this.Container.node.getChildByName("icon").getChildByName("background")
if(!this.dat.moreData.icon||""==this.dat.moreData.icon)return
const t=this.resPath+this.dat.moreData.icon
e.getComponent(Ti.E).skin=t}GetCenterPos(){return this.item.getCenterPos()}GetCenterLocalPos(){return this.item.GetCenterLocalPos()}PlaySpreadAnime(e){}DelaySpread(){}
PlayShrinkAnime(){}ResetTweenState(){}})
i(78612)
var bi=i(97960)
const Gi=(0,Ue.O$)("app/MyUISlider")
var Ui,Bi=i(82589),ki=i(77477),Fi=i(10509),Hi=i(5031);(0,x.s_)(je.I.eMainViewExp,Y.Z.ui_mainview_expbar).layerNav().register()(Ui=class extends((0,V.Ri)()){constructor(...e){
super(...e),this.timeIntervalId=-1,this.m_effPos=null,this.m_pInfo=null,this.effectlowflag=0,this.effectmediumflag=0,this.effecthighflag=0,this.lowEffectlist=null,
this.mediumEffectlist=null,this.highEffectlist=null,this.firstSetExp=!0,this.m_runTimeId=0,this.m_level=0,this.m_expShow=0,this.m_frontExp=0,this.m_frontLv=0,this.fValue=0,
this._animTimerId=0,this._animTargetLvAdd=0,this._animTargetFv=0,this._animBeginTime=0,this._animBeginFv=0,this._animCurFv=0,this._degf_RefreshDottomTime=null,
this._degf_hangExpHandler=null,this.lasttimestr=""}_initBinder(){super._initBinder(),this.m_effPos=new at.P,this._degf_RefreshDottomTime=()=>this.RefreshDottomTime(),
this._degf_hangExpHandler=e=>this.hangExpHandler(e)}InitView(){this.lowEffectlist=new z.Z([this.effeclow,this.effectlow2,this.effectlow3]),
this.mediumEffectlist=new z.Z([this.effectmedium,this.effectmedium2,this.effectmedium3]),this.highEffectlist=new z.Z([this.effecthigh,this.effecthigh2,this.effecthigh3]),
this.m_effPos=this.effeclow.transform.GetLocalPosition().clone(),this.InitLoc(),this.timeIntervalId=Se.C.Inst_get().SetInterval(this._degf_RefreshDottomTime,1e4),
this.m_pInfo=n.Y.Inst.PrimaryRoleInfo_get(),this.m_frontExp=this.m_pInfo.Exp_get().ToNum(),this.pre_eff_exp_flash_01.SetActive(!1),this.expCrazyUp.SetActive(!1),this.AddLis(),
this.UILabel_effect.SetActive(!1)}InitLoc(){const e=h.O.GetUIWidth()||1056
this.BottomAdapt(e)}BottomAdapt(e){let t=e-100-112.7
h.O.HasNotch?h.O.IsNotchAtLeft&&(t-=h.O.UIScreenSafeAreaBottomOffset):t-=h.O.UIScreenSafeAreaBottomOffset
const i=t/10
this.grid.cellWidth=i}RefreshDottomTime(){if(globalThis.window.wx&&globalThis.window.wx.getBatteryInfoSync){const e=globalThis.window.wx.getBatteryInfoSync().level/100
this.batterySprite.fillAmountSet(e)}const e=fe.l.GetRightNowInHourMin()
if(this.lasttimestr!=e&&(this.lasttimestr=e,this.UILabel_time.textSet(e)),globalThis.window.wx&&globalThis.window.wx.getConnectedWifi){
let e=globalThis.window.wx.getSystemInfoSync(),t=t=>{let i=t.signalStrength
"ios"==e.platform?i<.5?this.wifi2.node.visible=!1:i<.1?this.wifi1.node.visible=!1:(this.wifi2.node.visible=!0,
this.wifi1.node.visible=!0):i<50?this.wifi2.node.visible=!1:i<10?this.wifi1.node.visible=!1:(this.wifi2.node.visible=!0,this.wifi1.node.visible=!0)}
globalThis.window.wx.getConnectedWifi({partiallnfo:!0,success:t})}}LongPress(e,t){t?Hi.T.inst_get().control.OpenExpTip():Hi.T.inst_get().control.CloseExpTip()}_OnUpdateAnchors(){}
AddLis(){n.Y.Inst.PrimaryRoleInfo_get().AddEventHandlerRoleGlobal(bi.A.ExpUpdate,this._degf_hangExpHandler),
n.Y.Inst.PrimaryRoleInfo_get().AddEventHandlerRoleGlobal(bi.A.AttributesUpdate,this.CreateDelegate(this.SetExpAdd)),
l.i.Inst.AddEventHandler(q.g.UPDATE_ANCHORS,this.CreateDelegate(this._OnUpdateAnchors))}RemoveLis(){
n.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandlerRoleGlobal(bi.A.ExpUpdate,this._degf_hangExpHandler),
n.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandlerRoleGlobal(bi.A.AttributesUpdate,this.CreateDelegate(this.SetExpAdd)),
l.i.Inst.RemoveEventHandler(q.g.UPDATE_ANCHORS,this.CreateDelegate(this._OnUpdateAnchors))}hangExpHandler(e){this.m_pInfo=n.Y.Inst.PrimaryRoleInfo_get(),this.Setexp(),
this.SetEffectiveTotal()}hangExpRateHandler(e){this.SetEffectiveTotal(),Hi.T.inst_get().control.UpdateExpTip()}SetEffectiveTotal(){
let e=this.m_pInfo.Exp_get().ToNum()/this.m_pInfo.CurMaxExp_get()
e*=100
const t=fe.l.GetPrecentDecimalVal(e,1,2)
this.speedLevel.textSet(`${t}%`)}OnAddToScene(){this.Hideallexpeffect(),this.m_level=this.m_pInfo.Level_get(),this.m_frontLv=this.m_pInfo.Level_get(),
this.m_frontExp=this.m_pInfo.Exp_get().ToNum(),this._OnUpdateAnchors(),this.Setexp(),this.SetEffectiveTotal(),this.RefreshDottomTime()}Hideallexpeffect(){for(const[e,t]of(0,
Ct.V5)(this.lowEffectlist))t.SetActive(!1)
for(const[e,t]of(0,Ct.V5)(this.mediumEffectlist))t.SetActive(!1)
for(const[e,t]of(0,Ct.V5)(this.highEffectlist))t.SetActive(!1)}Setexp(){this.realSetExp()}SetExpAdd(){
n.Y.Inst.PrimaryRoleInfo_get().getAttribute(ki.Z.ExpAdd)<=0?this.Lvevl.textSet(""):this.Lvevl.textSet(`${(0,
_e.T)("加成")}${st.GF.INT(n.Y.Inst.PrimaryRoleInfo_get().getAttribute(ki.Z.ExpAdd)/100)}%`)}realSetExp(){const e=this.m_pInfo.Exp_get().ToNum(),t=this.m_pInfo.CurMaxExp_get()
this.fValue=e/t,this._animTargetFv=e/t,this._animTargetLvAdd=this.m_pInfo.Level_get()-this.m_frontLv
const i=this.getExpOffset(),s=this.NeedPlay(i)
s>0&&this.PlayExpEffect(s)
const a=this.GetExpByLevel(this.m_pInfo.Level_get(),this.m_frontLv)+e-this.m_frontExp
this.PlayExpAnim(a),this.m_frontExp=e,this.m_frontLv=this.m_pInfo.Level_get(),n.Y.Inst.PrimaryRoleInfo_get().getAttribute(ki.Z.ExpAdd)<=0?this.Lvevl.textSet(""):this.Lvevl.textSet(`${(0,
_e.T)("加成")}${st.GF.INT(n.Y.Inst.PrimaryRoleInfo_get().getAttribute(ki.Z.ExpAdd)/100)}%`)}GetExpByLevel(e,t){let i=0
if(e<=t)return i
for(let n=t;n<=e-1;n++)i+=this.GetLevelUpExpByLevel(n)
return i}GetLevelUpExpByLevel(e){return Fi.L.Inst().getItemById(e).exp}GetCrazyUpProportion(){return Fi.L.Inst().getItemById(this.m_frontLv).expCrazyUp}PlayExpAnim(e){
const t=st.GF.MTimer_get()
if(!this.expCrazyUp.active){const t=this.m_pInfo.CurMaxExp_get()
this.GetCrazyUpProportion()/1e4*t<=e?this.expCrazyUp.SetActive(!0):this.expCrazyUp.SetActive(!1)}this._animBeginTime=t,this._animBeginFv=this._animCurFv,
this._animTimerId=this.m_handlerMgr.SetIntervalByCurId(this._animTimerId,this.CreateDelegate(this.UpdateAnim),10,-1)}UpdateAnim(){
const e=st.GF.MTimer_get(),t=this._animTargetLvAdd>0?300:800
let i=this._animTargetLvAdd>0?1:this._animTargetFv
if(e>=this._animBeginTime+t)this._animCurFv=i,this._animTargetLvAdd>0?(this._animTargetLvAdd-=1,this._animCurFv=0,this._animBeginTime=e,
this._animBeginFv=this._animCurFv):(this.pre_eff_exp_flash_01.SetActive(!1),this.expCrazyUp.SetActive(!1),this._animTimerId=this.m_handlerMgr.ClearInterval(this._animTimerId))
else{let n=(e-this._animBeginTime)/t
n=Pe.p.Clamp01(n),i<this._animBeginFv&&(i+=1),this._animCurFv=this._animBeginFv+n*(i-this._animBeginFv),
this._animTimerId>1&&(this._animTargetLvAdd<1&&this._animCurFv>=1||(this._animCurFv-=Math.floor(this._animCurFv)))}let n=1056*this._animCurFv,s=n
if(n>=1056&&(s=n-1056),s>=1056&&(s=1056),this.barSprite.widthSet(s),this.UISprite_bar.getComponent(Gi).DoF_SetValueEx(this._animCurFv,1),
At.I.calVec0.Set(this.barSprite.width(),0,0),this.pre_eff_exp_flash_01.transform.SetLocalPosition(At.I.calVec0),At.I.calVec1.Set(this.barSprite.width()+8,-3,0),
this.expCrazyUp.transform.SetLocalPosition(At.I.calVec1),1==this._animCurFv)this.SetEffectiveTotal()
else{let e=this._animCurFv
e*=100
const t=fe.l.GetPrecentDecimalVal(e,1,2)
this.speedLevel.textSet(`${t}%`)}}getExpOffset(){if(this.m_level==this.m_pInfo.Level_get())return this.m_pInfo.Exp_get().ToNum()-this.m_frontExp
return Fi.L.Inst().getItemById(this.m_level).exp-this.m_frontExp+this.m_pInfo.Exp_get().ToNum()}PlayExpEffect(e){const t=this.barSprite.width()
this.m_effPos.x=t+5
const i=this.getEffectGameObject(e)
i&&i.active&&(i.transform.SetLocalPosition(this.m_effPos),i.SetActive(!0),i.getComponent(Bi.J).replay(1))}getEffectGameObject(e){
return 1==e?(this.effectlowflag=(this.effectlowflag+1)%this.lowEffectlist.count,
this.lowEffectlist[this.effectlowflag]):2==e?(this.effectmediumflag=(this.effectmediumflag+1)%this.mediumEffectlist.count,
this.mediumEffectlist[this.effectmediumflag]):(this.effecthighflag=(this.effecthighflag+1)%this.highEffectlist.count,this.highEffectlist[this.effectmediumflag])}NeedPlay(e){
this.m_pInfo.Level_get()!=this.m_level&&(this.m_level=this.m_pInfo.Level_get())
const t=Fi.L.Inst().getItemById(this.m_level)
return this.GetClassLevel(t.expShowList,e)}GetClassLevel(e,t){let i=0
for(i=0;i<e.Count();){if(t<e[i])return i
i+=1}return i}UpdateEffectPos(){this.PlayEffect(),Se.C.Inst_get().ClearInterval(this.m_runTimeId),this.m_runTimeId=0}PlayEffect(){}Clear(){this.Hideallexpeffect(),
-1!=this.timeIntervalId&&Se.C.Inst_get().ClearInterval(this.timeIntervalId),this.RemoveLis(),this.highEffectlist.Clear(),this.lowEffectlist.Clear(),this.mediumEffectlist.Clear(),
super.Clear()}})
var xi,Vi=i(49609),Yi=i(32076),Wi=i(13602),Ki=i(49484),Zi=i(10877),zi=i(43610);(0,
x.s_)(Q.o.MainViewPanel,Y.Z.ui_mainview_panel).layerNav().waitPrefab(Y.Z.ui_functionopen_spreaditem).waitPrefab(Y.Z.ui_funcopenitem).waitPrefab(Y.Z.ui_guide_view).waitPrefab(Y.Z.ui_function_prenotice).waitPrefab(Y.Z.ui_functionopen_spreaditem2).waitPrefab(Y.Z.ui_character_hpwarning_panel).register()(xi=class extends((0,
V.Ri)()){constructor(...e){super(...e),this._degf_DelayAdjustAnchor=null,this._degf_DelayHideMask=null,this._degf_OnFullClick=null,this._hPWarningPanel=null}_initBinder(){
super._initBinder(),this._degf_DelayAdjustAnchor=()=>this.DelayAdjustAnchor(),this._degf_DelayHideMask=()=>this.DelayHideMask(),this._degf_OnFullClick=(e,t)=>this.OnFullClick(e,t)}
getPrefabLoader(){return this.node.getOrAddComponent(Wi.A)}InitView(){this.node.removeComponent(oe.BlockInputEvents),this.ResetOffset(),this.unschedule((0,
Yi.v)(this.loadTipsPrefab,this)),this.scheduleOnce((0,Yi.v)(this.loadTipsPrefab,this),1)}loadTipsPrefab(){let e=this
this.getPrefabLoader().loadPrefabs($t.Z.RyTipCompFactory_AllTipTxteCompPath,(function(){e.unschedule(e.loadTipsPrefab)}))}OnAddToScene(){
Hi.T.inst_get().control.m_operationPanel=this.ui_mainview_operationentrance,Hi.T.inst_get().control.headView=this.ui_mainview_headpanel,
Hi.T.inst_get().control.ui_scene_touch_view=this.ui_scene_touch_view,Se.C.Inst_get().SetInterval(this._degf_DelayHideMask,1e3,1),
Se.C.Inst_get().SetFrameLoop(this._degf_DelayAdjustAnchor,1,1),this.ui_mainview_operationentrance.OnAddToScene(),this.ui_mainview_headpanel.OnAddToScene(),
this.ui_funcopenpanel.OnAddToScene(),this.ui_function_prenotice.OnAddToScene(),this.funcSetPanel.OnAddToScene(),this.pkfuncview.OnAddToScene(),
Ki.p.Inst_get().EnterMap(u.b.Inst.currentMapId_get()),this.m_handlerMgr.AddEventMgr(q.g.UPDATE_ANCHORS,(0,Yi.v)(this.UpdateAnchors,this)),
Vi.t.ins.isAutoGm&&launcher._testFlag(1)&&(Zi.k.Inst_get().initialize(),(0,oe.setDisplayStats)(!0),cus.scheduleOnce(480,this.__timerUpdateHandler.bind(this)))
let e=oe.director.getScene().getChildByName("UICanvas").getChildByName("LayerNav"),t=e.getChildByName("ui_topsmallmap_topmappanel")
t&&e.insertChild(t,e.children.length-1)}__timerUpdateHandler(){zi.n.AutoGM()}ResetOffset(){}UpdateAnchors(){this.ResetOffset(),this.ui_mainview_operationentrance.SetAnchorPos(),
this.ui_scene_touch_view.SetAnchorPos(),this.ui_funcopenpanel.SetAnchorPos(),this.ui_mainview_headpanel._OnUpdateAnchor()}OnFullClick(e,t){}DelayHideMask(){}DelayAdjustAnchor(){}
get hPWarningPanel(){return this._hPWarningPanel}set hPWarningPanel(e){this._hPWarningPanel=e}Clear(){this.ui_mainview_operationentrance.Clear(),this.ui_mainview_headpanel.Clear(),
this.ui_funcopenpanel.Clear(),this.ui_scene_touch_view.Clear(),this.funcSetPanel.Clear()}Destroy(){this.ui_mainview_operationentrance.Destory(),
this.ui_mainview_headpanel.Destory(),this.ui_funcopenpanel.Destory(),this.ui_scene_touch_view.Destroy(),this.funcSetPanel.Destory()}})
var qi,$i=i(68662),Xi=i(47552);(0,x.s_)(je.I.MapChangeProgress,Y.Z.ui_map_change_progress).register()(qi=class extends((0,V.Ri)()){constructor(...e){super(...e),this.maskWidth=0,
this._timerId=-1,this.timeTotal=1500,this.time=0,this.beginTime=0,this._degf_OnFrame=null}_initBinder(){super._initBinder(),this._degf_OnFrame=()=>this.OnFrame()}InitView(){
this.OnAddToScene()}OnAddToScene(){this.maskWidth=this.progress.GetBoundsSize().x,this.progress.node.transform.width=this.maskWidth,this.StartProgress()}OnMaskClick(e,t){
Xi.x.Instance.CloseMapChangeProgressView()}StartProgress(){this.ClearTimer(),this._timerId=Se.C.Inst_get().SetFrameLoop(this._degf_OnFrame,1),this.beginTime=$i.D.serverMSTime_get()
}OnFrame(){if(this.node.y=-324,this.time=$i.D.serverMSTime_get()-this.beginTime,this.time>this.timeTotal)return this.ClearTimer(),Xi.x.Instance.ProgressOver(),void(0,
Ce.sR)(je.I.MapChangeProgress)
const e=(this.timeTotal-this.time)/1e3
null!=Xi.x.Instance.gotoMap?this.lab_desc.textSet(Xi.x.Instance.gotoMap.name+((0,_e.T)(" 传送中... [F4E2B3FF]（")+(e.toFixed(1)+(0,_e.T)("秒）[-]")))):this.lab_desc.textSet((0,
_e.T)("传送中... [F4E2B3FF]（")+(e.toFixed(1)+(0,_e.T)("秒）[-]"))),this.progress.node.transform.width=this.maskWidth*(this.time/this.timeTotal)}Clear(){this.ClearTimer()}Destroy(){}
ClearTimer(){Se.C.Inst_get().ClearLoop(this._timerId),this._timerId=-1}CloseProgress(e){Xi.x.Instance.CloseMapChangeProgressView()}})
i(94568)
var Qi=i(82815),ji=i(41664),Ji=i(62063),en=i(35880),tn=i(83207),nn=i(8889),sn=i(72005),an=i(37322)
class rn extends ee.x{constructor(){super(),this.skillBg=null,this.redPoint=null,this.bg2=null,this.uId=0,this.m_pressComp=null,this.tweenscale=null,this.bgsp=null,
this.SpriteEffect=null,this.targetEffect=null,this.targetEffectPanel=null,this.getScoreAni=null,this.animPanel=null,this.lightAni=null,this.pointId=0,this._leftTimeIntervalId=-1,
this.getScoreTimer=-1,this.lightTimer=-1,this.tmpTimer=-1,this.offset=0,this._degf_ClearLightAnimTimer=null,this._degf_ClickHandler=null,this._degf_LongPressHandler=null,
this._degf_OnHangStateUpdate=null,this._degf_OnPkEffectStateUpdate=null,this._degf_OnPkStateUpdate=null,this._degf_PlayGetScoreEndHandler=null,this._degf_PlayLightAni=null,
this._degf_PlayLightAniEndHandler=null,this._degf_ScoreFlyAniEndHandler=null,this._degf_TimeChange=null,this._degf_UpdatePointState=null,
this._degf_ClearLightAnimTimer=e=>this.ClearLightAnimTimer(e),this._degf_ClickHandler=(e,t)=>this.ClickHandler(e,t),this._degf_LongPressHandler=(e,t)=>this.LongPressHandler(e,t),
this._degf_OnHangStateUpdate=e=>this.OnHangStateUpdate(e),this._degf_OnPkEffectStateUpdate=e=>this.OnPkEffectStateUpdate(e),this._degf_OnPkStateUpdate=e=>this.OnPkStateUpdate(e),
this._degf_PlayGetScoreEndHandler=()=>this.PlayGetScoreEndHandler(),this._degf_PlayLightAni=()=>this.PlayLightAni(),
this._degf_PlayLightAniEndHandler=()=>this.PlayLightAniEndHandler(),this._degf_ScoreFlyAniEndHandler=e=>this.ScoreFlyAniEndHandler(e),this._degf_TimeChange=()=>this.TimeChange(),
this._degf_UpdatePointState=(e,t)=>this.UpdatePointState(e,t)}InitView(){this.skillBg=new tn.s,this.skillBg.setId(this.FatherId,this.FatherComponentID,1),this.redPoint=new sn.w,
this.redPoint.setId(this.FatherId,this.FatherComponentID,2),this.bg2=new tn.s,this.bg2.setId(this.FatherId,this.FatherComponentID,4),this.tweenscale=new en.d,
this.tweenscale.setId(this.FatherId,this.FatherComponentID,5),this.bgsp=new sn.w,this.bgsp.setId(this.FatherId,this.FatherComponentID,6),this.SpriteEffect=new sn.w,
this.SpriteEffect.setId(this.FatherId,this.FatherComponentID,7),this.targetEffect=new c.k,this.targetEffect.setId(this.FatherId,this.FatherComponentID,8),
this.targetEffectPanel=new nn.$,this.targetEffectPanel.setId(this.FatherId,this.FatherComponentID,9),this.getScoreAni=new c.k,
this.getScoreAni.setId(this.FatherId,this.FatherComponentID,10),this.animPanel=new nn.$,this.animPanel.setId(this.FatherId,this.FatherComponentID,11),this.lightAni=new c.k,
this.lightAni.setId(this.FatherId,this.FatherComponentID,12),this.m_pressComp=new an.c(this.skillBg.node,null,this._degf_LongPressHandler)}ClickHandler(e,t){
Hi.T.inst_get().clickIndex=this.index,Hi.T.inst_get().OnFunItemClick(this.uId)}LongPressHandler(e,t){Hi.T.inst_get().clickIndex=this.index,
Hi.T.inst_get().OnFunItemPress(this.uId,t)}IsMarket(){return this.uId==je.I.MarketPanel}IsAuctionPanel(){return this.uId==je.I.GetAuctionPanel}IsBag(){
return this.uId==je.I.eBagPanel}SetData(e){this.uId=st.GF.INT(e),this.pointId=Hi.T.inst_get().GetPointId(this.uId),this.RegiestGuide(this.uId)
const t=Hi.T.inst_get().GetBtnResName(this.uId)
this.skillBg.normalSpriteSet(t),this.skillBg.hoverSpriteSet(t),this.skillBg.pressedSpriteSet(t),this.SpriteEffect.spriteNameSet(t),this.bg2.node.SetActive(!1),
this.uId==je.I.HangOpenPanel&&(this.skillBg.normalSpriteSet("mainui_sp_0077"),this.skillBg.hoverSpriteSet("mainui_sp_0077"),this.skillBg.pressedSpriteSet("mainui_sp_0077"),
this.bg2.normalSpriteSet("mainui_sp_0078"),this.bg2.hoverSpriteSet("mainui_sp_0078"),this.bg2.pressedSpriteSet("mainui_sp_0078"),this.bg2.node.SetActive(!0),
this.m_pressComp=new an.c(this.bg2.node,null,this._degf_LongPressHandler))
Hi.T.inst_get().GetBtnSprName(this.uId)
this.uId==je.I.HangOpenPanel&&this.updateHang(),this.SetPointState(),this.m_pressComp.AddEvent(),this.AddLis()}RegiestGuide(e){}AddLis(){
de.f.Inst.AddCallback(this.pointId,this._degf_UpdatePointState)
Hi.T.inst_get().model.funcItemDic.LuaDic_AddOrSetItem(this.uId,this),Yt.i.Get(this.skillBg.node).RegistonClick(this._degf_ClickHandler),
Yt.i.Get(this.SpriteEffect.node).RegistonClick(this._degf_ClickHandler),Yt.i.Get(this.bg2.node).RegistonClick(this._degf_ClickHandler),
this.uId==je.I.HangOpenPanel&&l.i.Inst.AddEventHandler(q.g.HANG_STATE_UPDATE,this._degf_OnHangStateUpdate),
this.uId==je.I.SwitchTarget&&(l.i.Inst.AddEventHandler(q.g.PK_STATE_UPDATE,this._degf_OnPkStateUpdate),
l.i.Inst.AddEventHandler(q.g.PK_STATE_EFFECT_UPDATE,this._degf_OnPkEffectStateUpdate)),
this.uId==je.I.eBagPanel&&(l.i.Inst.AddEventHandler(q.g.ScoreLightStart,this._degf_ScoreFlyAniEndHandler),
l.i.Inst.AddEventHandler(q.g.AddScoreAniEnd,this._degf_ClearLightAnimTimer),
Ji.U.AddEventToFinishedHandler(this.lightAni.FatherId,this.lightAni.ComponentId,this._degf_PlayLightAniEndHandler),
Ji.U.AddEventToFinishedHandler(this.getScoreAni.FatherId,this.getScoreAni.ComponentId,this._degf_PlayGetScoreEndHandler))}GetCenterWorldPos(){
return this.skillBg.node.transform.GetPosition()}updateHang(){let e=!1
if(null!=n.Y.Inst.PrimaryRole_get()&&null!=n.Y.Inst.PrimaryRole_get().AISingleton_get()&&n.Y.Inst.PrimaryRole_get().AISingleton_get().getSingletonType()==Qi.R.precastskill&&(e=!0),
Si.S.getInst().InHang_get()||o._.getInst().ishang_get()||e||-1!=o._.getInst()._optIntervalID)this.startAnimation()
else{Hi.T.inst_get().GetBtnSprName(this.uId)
Se.C.Inst_get().ClearInterval(this._leftTimeIntervalId),this._leftTimeIntervalId=-1}}OnHangStateUpdate(e){if(e)this.startAnimation()
else{Hi.T.inst_get().GetBtnSprName(this.uId)
Se.C.Inst_get().ClearInterval(this._leftTimeIntervalId),this._leftTimeIntervalId=-1}}OnPkStateUpdate(e){}OnPkEffectStateUpdate(e){e?(this.targetEffect.node.SetActive(!0),
this.targetEffect.SetResetOnPlay(!0),this.targetEffect.Play(!0,!1),h.O.AddUIEffectSortOrderBind(this.targetEffectPanel.node),
ji.j.Inst.PlayByDivision("ui_warning")):this.targetEffect.node.SetActive(!1)}UpdatePointState(e,t){this.redPoint.node.SetActive(t)}SetPointState(){
const e=de.f.Inst.GetData(this.pointId)
null!=e&&this.redPoint.node.SetActive(e.show)}startAnimation(){this.offset=0,Se.C.Inst_get().ClearInterval(this._leftTimeIntervalId),
this._leftTimeIntervalId=Se.C.Inst_get().SetInterval(this._degf_TimeChange,33)}TimeChange(){this.offset+=2,this.offset>=180&&(this.offset-=180)
const e=at.P.zero_get()
e.Set(0,0,this.offset),this.skillBg.node.transform.SetEulerAngles(e),at.P.Recyle(e)}RemoveLis(){de.f.Inst.RemoveCallback(this.pointId,this._degf_UpdatePointState)
Hi.T.inst_get().model.funcItemDic.LuaDic_Remove(this.uId),Yt.i.Get(this.skillBg.node).RemoveonClick(this._degf_ClickHandler),
Yt.i.Get(this.bg2.node).RemoveonClick(this._degf_ClickHandler),Yt.i.Get(this.SpriteEffect.node).RemoveonClick(this._degf_ClickHandler),
this.uId==je.I.HangOpenPanel&&(Se.C.Inst_get().ClearInterval(this._leftTimeIntervalId),this._leftTimeIntervalId=-1,
l.i.Inst.RemoveEventHandler(q.g.HANG_STATE_UPDATE,this._degf_OnHangStateUpdate)),
this.uId==je.I.SwitchTarget&&(l.i.Inst.RemoveEventHandler(q.g.PK_STATE_UPDATE,this._degf_OnPkStateUpdate),
l.i.Inst.RemoveEventHandler(q.g.PK_STATE_EFFECT_UPDATE,this._degf_OnPkEffectStateUpdate)),
this.uId==je.I.eBagPanel&&(l.i.Inst.RemoveEventHandler(q.g.ScoreLightStart,this._degf_ScoreFlyAniEndHandler),
l.i.Inst.RemoveEventHandler(q.g.AddScoreAniEnd,this._degf_ClearLightAnimTimer),
Ji.U.RemoveEventFromFinishedHandler(this.lightAni.FatherId,this.lightAni.ComponentId,this._degf_PlayLightAniEndHandler),
Ji.U.RemoveEventFromFinishedHandler(this.getScoreAni.FatherId,this.getScoreAni.ComponentId,this._degf_PlayGetScoreEndHandler))}ScoreFlyAniEndHandler(e){
this.ClearLightAnimTimer(null),this.animPanel.node.SetActive(!0),h.O.AddUIEffectSortOrderBind(this.animPanel.node),
this.lightTimer=Se.C.Inst_get().SetInterval(this._degf_PlayLightAni,167,3),this.PlayLightAni(),this.PlayLightAnimHandler(),
this.tmpTimer=Se.C.Inst_get().SetInterval(this._degf_PlayLightAniEndHandler,501,1)}PlayLightAnimHandler(){this.getScoreAni.SetResetOnPlay(!0),this.getScoreAni.Play(!0,!1)}
ClearLightAnimTimer(e){Se.C.Inst_get().ClearInterval(this.getScoreTimer),this.getScoreTimer=-1,Se.C.Inst_get().ClearInterval(this.lightTimer),this.lightTimer=-1,
Se.C.Inst_get().ClearInterval(this.tmpTimer),this.tmpTimer=-1}PlayLightAni(){this.lightAni.node.SetActive(!0),this.lightAni.SetResetOnPlay(!0),this.lightAni.Play(!0,!1)}
PlayLightAniEndHandler(){this.animPanel.node.SetActive(!1)}PlayGetScoreEndHandler(){At.I.calVec0.Set(1,1,1),this.getScoreAni.node.transform.SetLocalScale(At.I.calVec0)}Clear(){
this.m_pressComp.Clear(),this.RemoveLis()}Destroy(){this.m_pressComp.Destory(),this.m_pressComp=null,this.skillBg=null,this.redPoint=null,this.bg2=null}}
var ln,on=i(61756),_n=i(32759)
class un extends he.C{constructor(){super(),this.item=null,this.spreadAnime=null,this.tweenPos=null,this.tweenAlpha=null,this.dat=null,this.loopId=-1,this._degf_DelaySpread=null,
this._degf_DelaySpread=()=>this.DelaySpread()}InitView(){super.InitView(),this.item=new rn,this.item.setBinderId(this.FatherId,this.FatherComponentID,1),this.spreadAnime=new c.k,
this.spreadAnime.setId(this.FatherId,this.FatherComponentID,2),this.tweenPos=new _n.c,this.tweenPos.setId(this.FatherId,this.FatherComponentID,3),this.tweenAlpha=new on.R,
this.tweenAlpha.setId(this.FatherId,this.FatherComponentID,4),this.tweenPos.SetEnabled(!1),this.tweenAlpha.SetEnabled(!1)}Clear(){this.item.Clear(),
Se.C.Inst_get().ClearLoop(this.loopId),this.loopId=-1}Destroy(){this.item.Destroy(),this.item=null,this.spreadAnime=null,this.tweenPos=null,this.tweenAlpha=null}SetData(e){
const t=e
this.dat=t,this.item.SetData(t.uId)}GetCenterPos(){return this.item.GetCenterWorldPos()}PlaySpreadAnime(){0==this.dat.spreadDelay?(this.spreadAnime.SetResetOnPlay(!0),
this.spreadAnime.Play(!0,!1)):this.loopId=Se.C.Inst_get().SetFrameLoop(this._degf_DelaySpread,this.dat.spreadDelay,1)}DelaySpread(){this.spreadAnime.SetResetOnPlay(!0),
this.spreadAnime.Play(!0,!1)}PlayShrinkAnime(){this.tweenPos.SetEnabled(!0),this.tweenPos.ResetToBeginning(),this.tweenPos.PlayForward(),this.tweenAlpha.SetFrom(1),
this.tweenAlpha.SetTo(0),this.tweenAlpha.durationSet(.15),this.tweenAlpha.SetEnabled(!0),this.tweenAlpha.ResetToBeginning(),this.tweenAlpha.PlayForward()}ResetTweenState(){
this.tweenPos.SetEnabled(!1),this.tweenPos.SetEnabled(!1)}}const{ccclass:hn,property:cn}=oe._decorator
hn("MianOpenFunDown")(ln=class extends((0,V.yk)()){constructor(...e){super(...e),this.funcItemList=null,this.dataLis=null,this.posList=null,this.spreadDelayList=null,
this.shrinkIntervalId=-1,this.isShow=!1,this.shortcutGoodsItem=null,this._degf_OnGetItem=null,this._degf_OnShrinkEnd=null,this._degf_OnUpate=null,this._degf_RefresList=null,
this._degf_onLevelUpHandle=null,this.firstUpdate=null}_initBinder(){super._initBinder(),this.funcItemList=new z.Z,this.dataLis=new z.Z,this.posList=new z.Z,
this.spreadDelayList=new z.Z,this._degf_OnGetItem=e=>this.OnGetItem(e),this._degf_OnShrinkEnd=()=>this.OnShrinkEnd(),this._degf_OnUpate=e=>this.OnUpate(e),
this._degf_RefresList=()=>this.RefresList(),this._degf_onLevelUpHandle=e=>this.onLevelUpHandle(e)}InitView(){this.m_grid.SetInitInfo("ui_mainview_funitem",this._degf_OnGetItem),
this.posList.Add(new at.P(0,0,0)),this.posList.Add(new at.P(-76,0,0)),this.posList.Add(new at.P(-152,0,0)),this.posList.Add(new at.P(-228,0,0)),this.spreadDelayList.Add(3),
this.spreadDelayList.Add(2),this.spreadDelayList.Add(1),this.spreadDelayList.Add(0)}OnGetItem(e){return e[0].getCNode(rn)}OnAddToScene(){
this.isShow||(Hi.T.inst_get().model.AddEventHandler(Oi.h.UPDATE_FUN_ITEM,this._degf_OnUpate),
n.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(bi.A.LevelUpdate,this._degf_onLevelUpHandle),this.firstUpdate=!0,this.OnUpate(null),this.isShow=!0)}OnUpate(e){}RefresList(){}
loadOneFuncItem(){const e=It.o.getPrefab("ui_functionopen_spreaditem2"),t=(0,oe.instantiate)(e).getCNode(un)
return t.node.setParent(this.funcContainer),this.funcItemList.Add(t),t}InitShortcutGoodsItem(){}UpdateGoodsItemLockState(){
null!=this.shortcutGoodsItem&&this.shortcutGoodsItem.UpdateLockIconState()}onLevelUpHandle(e){this.InitShortcutGoodsItem()}DoSpread(e){
Se.C.Inst_get().ClearInterval(this.shrinkIntervalId),e?(this.funcContainer.SetActive(!0),this.PlaySpreadAnime()):(this.PlayShrinkAnime(),
this.shrinkIntervalId=Se.C.Inst_get().SetInterval(this._degf_OnShrinkEnd,300,1))}PlaySpreadAnime(){let e=0
for(;e<this.funcItemList.Count();)this.funcItemList[e].PlaySpreadAnime(),e+=1}PlayShrinkAnime(){let e=0
for(;e<this.funcItemList.Count();)this.funcItemList[e].PlayShrinkAnime(),e+=1}OnShrinkEnd(){this.funcContainer.SetActive(!1)
let e=0
for(;e<this.funcItemList.Count();)this.funcItemList[e].ResetTweenState(),e+=1}ShowMarketBtn(e){let t=0
for(;t<this.funcItemList.Count();){if(this.funcItemList[t].item.IsAuctionPanel())return void this.funcItemList[t].node.SetActive(e)
t+=1}}Clear(){Hi.T.inst_get().model.RemoveEventHandler(Oi.h.UPDATE_FUN_ITEM,this._degf_OnUpate),
n.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(bi.A.LevelUpdate,this._degf_onLevelUpHandle),Se.C.Inst_get().ClearInterval(this.shrinkIntervalId),this.isShow=!1
let e=0
for(;e<this.funcItemList.Count();)this.funcItemList[e].Clear(),e+=1}Destory(){null!=this.m_grid&&this.m_grid.Destroy(),this.isShow=!1
let e=0
for(;e<this.funcItemList.Count();)this.funcItemList[e].Destroy(),e+=1
this.funcItemList.Clear()}})
var dn
const{ccclass:mn,property:pn}=oe._decorator
mn("MianOpenFunUp")(dn=class extends((0,V.yk)()){constructor(...e){super(...e),this.isShow=!1,this._degf_OnGetItem=null,this._degf_OnUpate=null,this._degf_RefresList=null}
_initBinder(){super._initBinder(),this._degf_OnGetItem=e=>this.OnGetItem(e),this._degf_OnUpate=e=>this.OnUpate(e),this._degf_RefresList=()=>this.RefresList()}InitView(){
this.m_grid.SetInitInfo("ui_mainview_funitem",this._degf_OnGetItem)}OnGetItem(e){return e[0].getCNode(rn)}OnAddToScene(){
this.isShow||(Hi.T.inst_get().model.AddEventHandler(Oi.h.UPDATE_FUN_ITEM,this._degf_OnUpate),this.OnUpate(null),this.isShow=!0)}GetMarketWorldPos(){const e=this.m_grid.itemList
for(const[t,i]of(0,Ct.V5)(e)){const e=i
if(e.IsMarket())return e.GetCenterWorldPos()}return at.P.zero_get()}GetBagWorldPos(){const e=this.m_grid.itemList
for(const[t,i]of(0,Ct.V5)(e)){const e=i
if(e.IsBag())return e.GetCenterWorldPos()}return at.P.zero_get()}OnUpate(e){Se.C.Inst_get().CallLater(this._degf_RefresList)}RefresList(){}Clear(){
Hi.T.inst_get().model.RemoveEventHandler(Oi.h.UPDATE_FUN_ITEM,this._degf_OnUpate),this.isShow=!1}Destory(){null!=this.m_grid&&this.m_grid.Destroy(),this.isShow=!1}})
var gn,In=i(31222),En=i(72800),Cn=i(29479),Sn=i(73865),Tn=i(32819),fn=i(28893)
class An{constructor(){this.funcData=null,this.pos=null,this.spreadDelay=0,this.empty=!1}Equal(e){if(this.funcData&&e.funcData&&this.funcData.Equal(e.funcData))return!0}}
class yn extends((0,V.zB)()){constructor(...e){super(...e),this.shrinkTweenPos=null,this.shrinkTweenAlpha=null,this.dat=null,this.loopId=-1}InitView(){
this.item.tip.node.SetActive(!1)}Clear(){this.item.Clear(),this.RemoveListeners(),Se.C.Inst_get().ClearLoop(this.loopId),this.loopId=-1,super.Clear()}Destroy(){}AddListeners(){}
RemoveListeners(){}OnClickItem(){this.item.OnFunc()}SetData(e){const t=e
if(this.dat=t,this.dat.empty){if(null!=this.content)return this.content.SetActive(!1),void this.empty.SetActive(!0)}else null!=this.content&&(this.content.SetActive(!0),
this.empty.SetActive(!1))
this.item.SetData(this.dat.funcData),this.AddListeners()}GetCenterPos(){return this.item.getCenterPos()}}const{ccclass:Rn}=oe._decorator
Rn("OperationEntrancePanel")(gn=class extends((0,V.Ri)()){constructor(...e){super(...e),this._degf_CreateFuncItem=null,this._degf_DoUpdate=null,this._degf_OnArrorClick=null,
this._degf_OnGridReposition=null,this._degf_OnInterval=null,this._degf_OnLevelUpHandle=null,this._degf_OnOperationDown=null,this._degf_SortByAreaId=null,
this._degf_UpdateRedPoint=null,this._degf_FunctionOpenHandler=null,this._degf_SwitchActivityHandler=null,this.updateTimerId=void 0,this.IsClear=void 0,this.m_isFirstUpdate=!0,
this.m_isOpen=!0,this.IsForceDoUpdate=void 0,this.isShow=void 0,this.emptyBtnData=void 0,this.isout=void 0,this.emptyObj=void 0,this.listCount=void 0}_initBinder(){
this._degf_CreateFuncItem=e=>this.CreateFuncItem(e),this._degf_DoUpdate=()=>this.DoUpdate(),this._degf_OnArrorClick=(e,t)=>this.OnArrorClick(e,t),
this._degf_OnGridReposition=()=>this.OnGridReposition(),this._degf_OnInterval=()=>this.OnInterval(),this._degf_OnLevelUpHandle=e=>this.OnLevelUpHandle(e),
this._degf_OnOperationDown=e=>this.OnOperationDown(e),this._degf_SortByAreaId=(e,t)=>this.SortByAreaId(e,t),this._degf_UpdateRedPoint=(e,t)=>this.UpdateRedPoint(e,t),
this._degf_FunctionOpenHandler=e=>this.FunctionOpenHandler(e),this._degf_SwitchActivityHandler=e=>this.SwitchActivityHandler(e)}InitView(){
this.grid.SetInitInfo("ui_functionopen_leftspreaditem",this._degf_CreateFuncItem,yn),this.grid.OnReposition_set(this._degf_OnGridReposition),this.arrowBtn.node.SetActive(!1),
this.SetAnchorPos(),this.spreadContainer.SetActive(!1),this.emptyBtnData=null}OnGridReposition(){Se.C.Inst_get().SetInterval(this._degf_OnInterval,100,1)}SetAnchorPos(){
h.O.SetAnchorPos(this.anchor,!1,!0,0,!1)}OnInterval(){if(null!=this.grid&&this.grid.itemList){let e=this.grid.itemList
for(const[t,i]of(0,Ct.V5)(e))i.item.ResetEffPos()
this.HandlePosOffset()}}HandlePosOffset(){let e=Hi.T.inst_get().control.configList
for(let t=0;t<=e.Count()-1;t++)this.LayoutOperationData(e[t])}Destory(){}OnAddToScene(){this.ForcePlayAni(),
this.isShow&&E.p.inst.IsInCopy()&&C.a.Inst_get().serverCopyType!=En.S.Arena||(this.AddOrDelEvent(!0),this.UpdateView(),this.isShow=!0)}Clear(){this.AddOrDelEvent(!1),
this.isShow=!1,this.isout=!1,this.IsForceDoUpdate=!0,this.grid.Clear()}AddOrDelEvent(e){e?(Yt.i.Get(this.arrowBtn.node).RegistonClick(this._degf_OnArrorClick),
de.f.Inst.AddCallback(ce.t.FIRSTCHARGE,this._degf_UpdateRedPoint),n.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(bi.A.LevelUpdate,this._degf_OnLevelUpHandle),
this.m_handlerMgr.AddEventMgr(q.g.OPERATION_DOWN,this._degf_OnOperationDown),this.m_handlerMgr.AddEventMgr(q.g.EnterMap,this.CreateDelegate(this.ForceDoUpdate)),
this.m_handlerMgr.AddEventMgr(q.g.FUNCTION_OPEN,this._degf_FunctionOpenHandler),this.m_handlerMgr.AddEventMgr(q.g.SWITCH_ACTIVITY_ADD,this._degf_SwitchActivityHandler),
this.m_handlerMgr.AddEventMgr(q.g.SWITCH_ACTIVITY_REMOVE,this._degf_SwitchActivityHandler),this.m_handlerMgr.AddEventMgr(q.g.SWITCH_ACTIVITY_STOP,this._degf_SwitchActivityHandler),
this.m_handlerMgr.AddEventMgr(q.g.FUNCTION_INIT_COMPLETE,this._degf_DoUpdate),this.m_handlerMgr.AddEventMgr(q.g.RIDINGBUY_ACTIVITYINFO,this._degf_DoUpdate),
this.m_handlerMgr.AddEventMgr(q.g.FUNCTION_CLOSE,this.CreateDelegate(this.FunctionUpdateHandler)),
this.m_handlerMgr.AddEventMgr(q.g.FUNCTION_UPDATE,this.CreateDelegate(this.FunctionUpdateHandler)),
this.m_handlerMgr.AddEventMgr(q.g.HUODONG_INFO_CHANGE,this.CreateDelegate(this.OnHuoDongInfoUpdate)),
this.m_handlerMgr.AddEventMgr(q.g.UITweenStateChanged,this.CreateDelegate(this.OnUITweenStateChanged)),
this.m_handlerMgr.AddEventMgr(q.g.PrenoticePanelUpdata,this.CreateDelegate(this.ForceDoUpdate))):(Yt.i.Get(this.arrowBtn.node).RemoveonClick(this._degf_OnArrorClick),
de.f.Inst.RemoveCallback(ce.t.FIRSTCHARGE,this._degf_UpdateRedPoint),n.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(bi.A.LevelUpdate,this._degf_OnLevelUpHandle),
this.RemoveLis()),this.IsClear=!e}RemoveLis(){this.m_handlerMgr.RemoveEventMgr(q.g.OPERATION_DOWN,this._degf_OnOperationDown),
this.m_handlerMgr.RemoveEventMgr(q.g.EnterMap,this.CreateDelegate(this.ForceDoUpdate)),this.m_handlerMgr.RemoveEventMgr(q.g.FUNCTION_OPEN,this._degf_FunctionOpenHandler),
this.m_handlerMgr.RemoveEventMgr(q.g.SWITCH_ACTIVITY_ADD,this._degf_SwitchActivityHandler),
this.m_handlerMgr.RemoveEventMgr(q.g.SWITCH_ACTIVITY_REMOVE,this._degf_SwitchActivityHandler),
this.m_handlerMgr.RemoveEventMgr(q.g.SWITCH_ACTIVITY_STOP,this._degf_SwitchActivityHandler),this.m_handlerMgr.RemoveEventMgr(q.g.FUNCTION_INIT_COMPLETE,this._degf_DoUpdate),
this.m_handlerMgr.RemoveEventMgr(q.g.RIDINGBUY_ACTIVITYINFO,this._degf_DoUpdate),
this.m_handlerMgr.RemoveEventMgr(q.g.FUNCTION_CLOSE,this.CreateDelegate(this.FunctionUpdateHandler)),
this.m_handlerMgr.RemoveEventMgr(q.g.FUNCTION_UPDATE,this.CreateDelegate(this.FunctionUpdateHandler)),
this.m_handlerMgr.RemoveEventMgr(q.g.HUODONG_INFO_CHANGE,this.CreateDelegate(this.OnHuoDongInfoUpdate)),
this.m_handlerMgr.RemoveEventMgr(q.g.UITweenStateChanged,this.CreateDelegate(this.OnUITweenStateChanged)),
this.m_handlerMgr.RemoveEventMgr(q.g.PrenoticePanelUpdata,this.CreateDelegate(this.ForceDoUpdate))}ForcePlayAni(){this.OnUITweenStateChanged(this.isout,!0)}
OnUITweenStateChanged(e,t){null==t&&(t=!1),(this.isout!=e||t)&&(this.isout=e,this.node.visible=!e)}UpdateView(){
-1==this.updateTimerId&&(this.updateTimerId=Se.C.Inst_get().SetInterval(this._degf_DoUpdate,500,1)),this.ForceDoUpdate()}ForceDoUpdate(){this.IsForceDoUpdate=!0,this.DoUpdate()}
DoUpdate(e){if(this.updateTimerId=-1,this.IsClear)return
null==e&&(e=!0),this.m_isFirstUpdate&&(this.m_isFirstUpdate=!1,this.m_isOpen=!0)
let t=this.GetDataList()
t.Count(),this.UpdateByFix(t)
let i=new z.Z
for(const[e,n]of(0,Ct.V5)(t))(this.m_isOpen||!this.m_isOpen&&1==n.funcData.stay)&&i.Add(n)
if(this.HandleInsertEmptyIcons(i),this.IsForceDoUpdate||this.NeedRefresh(i,this.grid.data_get()))this.IsForceDoUpdate=!1,this.grid.data_set(i)
else if(i&&this.grid&&this.grid.itemList&&i.Count()==this.grid.itemList.Count()){let e=i.Count()
for(let t=0;t<=e-1;t++){let e=this.grid.itemList[t]
e.Clear(),e.SetData(i[t])}}e&&this.redPoint&&this.redPoint.SetActive(!1)}NeedRefresh(e,t){if(e.Count()!=t.Count())return!0
let i=e.Count()
for(let n=0;n<=i-1;n++){let i=e[n],s=t[n]
if(!i.Equal(s))return!0}return!1}UpdateByFix(e){let t=e.Count()
if(t>0){let i=!1,n=0
for(;n<t&&(i=Hi.T.inst_get().model.IsShowRedPoint(e[n]),!i);)n+=1
this.redPoint.SetActive(i)}}OnArrorClick(e,t){this.DoUpdate()}ShowView(e){this.isShow!=e&&(this.isShow?(this.isShow=!1,this.grid.node.SetActive(!1)):(this.isShow=!0,
this.grid.node.SetActive(!0)),this.DoUpdate())}UpdateRedPoint(e,t){this.UpdateView()}OnLevelUpHandle(e){this.DoUpdate()}SwitchActivityHandler(e){this.DoUpdate(e)}
FunctionUpdateHandler(e){if(null==e)return
let t=Ai.d.Inst_get().getItemById(e)
if(null==t||Z.M.IsNullOrEmpty(t.nameId))return
let i=yi.m.Inst_get().getItemById(t.nameId)
null!=i&&2==i.area_type&&this.DoUpdate()}FunctionOpenHandler(e){null!=e&&this.DoUpdate()}OnHuoDongInfoUpdate(e){}HandleInsertEmptyIcons(e){
let t=Hi.T.inst_get().control.configList,i=t.Count()
null==this.emptyBtnData&&(this.emptyBtnData=this.GetEmptyData())
let n=In.N.inst.GetViewById(je.I.eTaskContractMainUI)
null!=n&&n.isShow_get()&&(e.Count()>=0+this.grid.MaxPerLine_get()?(e.Insert(0,this.emptyBtnData),
e.Insert(0+this.grid.MaxPerLine_get(),this.emptyBtnData)):e.Count()>0&&e.Insert(0,this.emptyBtnData))
for(let n=0;n<=i-1;n++){let i=this.FindDataIndex(e,t[n].funType)
if(-1!=i){let s=t[n].count
if(s=2-i%3,s>0){let t=0
for(let n=0;n<=s-1;n++)t=i+(n+1),e.Insert(t,this.emptyBtnData)}}}}GetEmptyData(){let e=new An
return e.empty=!0,e}FindDataIndex(e,t){let i=e.Count()
for(let n=0;n<=i-1;n++)if(null!=e[n].funcData&&e[n].funcData.id==t)return n
return-1}LayoutOperationData(e){let t=At.I.calVec0
if(t.x=0,t.y=0,t.z=0,null!=e.funType){let i=this.GetItem(e.funType)
if(null!=i){e.icon.node.setParent(this.emptyObj)
let n=i.node.transform.TransformPoint(at.P.zero_get())
t=this.emptyObj.transform.convertToNodeSpaceAR(n),null!=e.offset&&(t.x=t.x+e.offset.x,t.y=t.y+e.offset.y),e.icon.node.transform.SetLocalPosition(t),e.icon.node.SetActive(!0)
}else e.icon.node.SetActive(!1)}else e.icon.node.setParent(this.emptyObj),null!=e.offset&&(t.x=t.x+e.offset.x,t.y=t.y+e.offset.y),e.icon.node.transform.SetLocalPosition(t)}
OnOperationDown(e){e&&this.m_isOpen&&this.OnArrorClick(0,0)}CreateFuncItem(e){}GetDataList(){let e=new z.Z,t=yi.m.Inst_get().GetItemList(),i=0
for(;i<t.Count();){let s=t[i]
if(Hi.T.inst_get().model.ShowOperation(s)){let t=Ai.d.Inst_get().GetItemByNameId(s.id)
if(null!=t&&Ae.P.Inst_get().IsFuncOrActivityOpened(t.id))if("SKILLLIMITBUY"==s.id)fn.F.Inst_get().ShowBuySkillBtn()&&e.Add(this.CreateBtnData(s,t))
else if("DIRECTBUY"==s.id){let i=Cn.X.Inst_get().directBuyList
if(null!=i&&i.Count()>0&&!i[0].isInShowTime&&i[0].GetRemainTime()>0){let n=Sn.y.Inst.CreateFuncItemData(s,t,i[0].id),a=new An
a.funcData=n,e.Add(a)}}else if("RIDINGBUY"==s.id){let i=L.$.Inst().GetRidingBuyVoDict()
for(const[n,a]of(0,Ct.V5)(i)){let i=a
if(i.endTime.ToNum()>$i.D.serverMSTime_get()){let n=Sn.y.Inst.CreateFuncItemData(s,t,i.id),a=new An
a.funcData=n,e.Add(a)}}}else if(t.id==ye.x.TIME_LIMIT_FUNCTION_TOP){let i=m.x.Inst_get().GetTimelimitTip()
if(i){let a=!1,r=i.timeLimitType,l=m.x.Inst_get().GetTimeLimitRes(r)
if(l)if(1==l.AsuramLimit){n.Y.Inst.PrimaryRoleInfo_get().isHaveAlliance_get()&&(a=!0)}else a=!0
if(a){let i=Sn.y.Inst.CreateFuncItemData(s,t),n=Z.M.String2Int(l.functionId),a=Ai.d.Inst_get().getItemById(n)
null!=a&&(i.icon=a.activityIcon)
let r=new An
r.funcData=i,e.Add(r)}}}else e.Add(this.CreateBtnData(s,t))}i+=1}return e.Sort(this._degf_SortByAreaId),this.listCount=e.count,e}CreateBtnData(e,t,i){let n=new Tn.l
"OPENASURAMWAR"==e.id?n.id=ye.x.ASURAM_PRENOTICE:n.id=t.id,n.areaId=e.area_id,n.areaType=e.area_type,n.icon=e.icon,n.btnId=e.id,n.name=e.name,n.stay=e.stay,n.effType=e.type,
n.userData=i,n.isShowEffect=Oi.h.Inst_get().GetEffState(t.id,e.type)
let s=new An
return s.funcData=n,s}SortByAreaId(e,t){let i=e,n=t
return i.funcData.areaId<n.funcData.areaId?-1:i.funcData.areaId>n.funcData.areaId?1:0}GetItem(e){let t=null
if(null!=this.grid.itemList)for(const[i,n]of(0,Ct.V5)(this.grid.itemList))if(null!=n.item.data&&n.item.data.id==e){t=n.item
break}return t}GetFirstChargeItem(){let e=null
if(null!=this.grid.itemList)for(const[t,i]of(0,Ct.V5)(this.grid.itemList))if(null!=i.item.data&&i.item.data.id==ye.x.FIRST_CHARGE){e=i.item
break}return e}GetAnchorObj(){return this.arrowBtn.node}GetGridCount(){let e=0
return this.m_isOpen?e=this.listCount:null!=this.grid.itemList&&(e=this.grid.itemList.Count()),e}GetFuncItem(e){let t=this.grid.itemList
for(const[i,n]of(0,Ct.V5)(t)){let t=n
if(null!=t&&t.item.IsFunction(e))return t}return null}})
i(95619)
var Dn,wn=i(56937),Ln=i(37318),vn=i(42975),On=i(88883),Pn=i(54383),Nn=i(41864)
const{ccclass:Mn}=oe._decorator
Mn("MainHeadPanel")(Dn=class extends((0,V.Ri)()){constructor(...e){super(...e),this.cnode=null,this.lastScore=0,this.roleInfo=null,this.m_pInfo=null,this.newPlayerLevel=70}
onLoad(){}InitView(){this.cnode=this.node.getCNode(),this.roleInfo=n.Y.Inst.PrimaryRoleInfo_get(),this.SetData(),this.SetBtnClickEvent(),this._OnUpdateAnchor()
const e=$.D.getInstance().GetIntArray("XINSHOU")
this.newPlayerLevel=e[0]}_OnUpdateAnchor(){h.O.SetAnchorPos(this.Container,!0,!1,2,!1)}OnAddToScene(){console.log("--------------MainHeadPanel---------"),this.addLis(),
this.OnRoleInfoChange()
oe.sys.platform
this.cnode.currencyBtn.node.active=!MiniPlatController.isTiShen(),this.cnode.vipBox.node.active=!MiniPlatController.isTiShen()}OnRoleInfoChange(e){this.AddOrDelEventRole(!1),
this.m_pInfo=n.Y.Inst.PrimaryRoleInfo_get(),this.lastScore=n.Y.Inst.getAllBattleScore(),this.AddOrDelEvent(!0),this.OnUpdate(),this.UpdateBuffList(null),this.UpdatePkModel()
let t=de.f.Inst.GetData(ce.t.VIP_BOX)
null!=t&&this.vipRedDot.SetActive(t.show)}addLis(){this.AddOrDelEvent(!0)}SetData(){this.cnode.score.string=this.roleInfo.totalBattleScore.toString(),
this.cnode.currencylab.string=S.w.Instance.ConvertNumToString(this.roleInfo.gold_Diamond),
this.roleInfo.IsMaster()?this.cnode.levellabel.string=this.roleInfo.GetMasterLevel().toString():this.cnode.levellabel.string=Nn.h.GetLevelStr(this.roleInfo.Level_get())
this.roleInfo.Job_get(),this.roleInfo.Sex_get()
this.cnode.head.skin=`${lt.Z.GetMainUIJobIcon(this.roleInfo.Job_get(),this.roleInfo.Sex_get())}`,this.UpdateVipPart()}AddOrDelEvent(e){
e?(this.roleInfo&&(this.roleInfo.AddEventHandler(bi.A.LevelUpdate,this.CreateDelegate(this.OnUpdate)),
this.roleInfo.AddEventHandler(bi.A.HpUpdate,this.CreateDelegate(this.OnUpdate)),this.roleInfo.AddEventHandler(bi.A.AttributesUpdate,this.CreateDelegate(this.OnUpdate)),
this.roleInfo.AddEventHandler(bi.A.JobUpdate,this.CreateDelegate(this.OnUpdate)),this.roleInfo.AddEventHandler(bi.A.Gold_DiamondUpdate,this.CreateDelegate(this.OnUpdate)),
l.i.Inst.AddEventHandler(q.g.PKMODEL_UPDATE,this.CreateDelegate(this.UpdatePkModel))),
this.m_handlerMgr.AddEventMgr(q.g.PRIMARY_ROLE_LIST_BY_SORT_CHANGED,this.CreateDelegate(this.OnRoleInfoChange)),
l.i.Inst.AddEventHandler(q.g.UPDATE_DAILYACCULUMN_INFO,this.CreateDelegate(this.CurrOnUpdate)),l.i.Inst.AddEventHandler(q.g.VIP_UPDATE,this.CreateDelegate(this.UpdateVipPart)),
I.j.Inst_get().model.AddEventHandler(vn.E.UPDATE_BUFF_VIEW,this.CreateDelegate(this.UpdateBuffList)),
de.f.Inst.AddCallback(ce.t.VIP_BOX,this.CreateDelegate(this.UpdateVipPart))):(this.roleInfo&&(this.roleInfo.RemoveEventHandler(bi.A.LevelUpdate,this.CreateDelegate(this.OnUpdate)),
this.roleInfo.RemoveEventHandler(bi.A.HpUpdate,this.CreateDelegate(this.OnUpdate)),this.roleInfo.RemoveEventHandler(bi.A.AttributesUpdate,this.CreateDelegate(this.OnUpdate)),
this.roleInfo.RemoveEventHandler(bi.A.JobUpdate,this.CreateDelegate(this.OnUpdate)),
this.roleInfo.RemoveEventHandler(bi.A.Gold_DiamondUpdate,this.CreateDelegate(this.CurrOnUpdate)),
l.i.Inst.RemoveEventHandler(q.g.PKMODEL_UPDATE,this.CreateDelegate(this.UpdatePkModel))),
this.m_handlerMgr.RemoveEventMgr(q.g.PRIMARY_ROLE_LIST_BY_SORT_CHANGED,this.CreateDelegate(this.OnRoleInfoChange)),
l.i.Inst.RemoveEventHandler(q.g.UPDATE_DAILYACCULUMN_INFO,this.CreateDelegate(this.OnUpdate)),
I.j.Inst_get().model.RemoveEventHandler(vn.E.UPDATE_BUFF_VIEW,this.CreateDelegate(this.UpdateBuffList)),
de.f.Inst.RemoveCallback(ce.t.VIP_BOX,this.CreateDelegate(this.UpdateVipPart)))}AddOrDelEventRole(e){
e?null!=this.m_pInfo&&(this.m_pInfo.AddEventHandler(bi.A.LevelUpdate,this.CreateDelegate(this.OnUpdate)),
this.m_pInfo.AddEventHandler(bi.A.HpUpdate,this.CreateDelegate(this.OnUpdate)),this.m_pInfo.AddEventHandler(bi.A.AttributesUpdate,this.CreateDelegate(this.OnUpdate)),
this.m_pInfo.AddEventHandler(bi.A.JobUpdate,this.CreateDelegate(this.OnUpdate)),this.m_pInfo.AddEventHandler(bi.A.VipUpdate,this.CreateDelegate(this.OnUpdate)),
this.m_pInfo.AddEventHandler(bi.A.Gold_DiamondUpdate,this.CreateDelegate(this.CurrOnUpdate))):null!=this.m_pInfo&&(this.m_pInfo.RemoveEventHandler(bi.A.LevelUpdate,this.CreateDelegate(this.OnUpdate)),
this.m_pInfo.RemoveEventHandler(bi.A.HpUpdate,this.CreateDelegate(this.OnUpdate)),this.m_pInfo.RemoveEventHandler(bi.A.AttributesUpdate,this.CreateDelegate(this.OnUpdate)),
this.m_pInfo.RemoveEventHandler(bi.A.JobUpdate,this.CreateDelegate(this.OnUpdate)),this.m_pInfo.RemoveEventHandler(bi.A.VipUpdate,this.CreateDelegate(this.OnUpdate)),
this.m_pInfo.RemoveEventHandler(bi.A.VipUpdate,this.CreateDelegate(this.OnUpdate)),this.m_pInfo.RemoveEventHandler(bi.A.Gold_DiamondUpdate,this.CreateDelegate(this.CurrOnUpdate)))}
SetBtnClickEvent(){this.cnode.head.node.on(oe.NodeEventType.TOUCH_END,this.OnBtnClickHead,this,!1),
this.cnode.currencyBtn.node.on(oe.NodeEventType.TOUCH_END,this.OnClickRechargePanel,this,!1),this.cnode.vipCollider.on(oe.NodeEventType.TOUCH_END,this.onClickVIPHandle,this,!1),
this.cnode.buffbtn.node.on(oe.NodeEventType.TOUCH_END,this.buffBtnClickFun,this,!1),this.cnode.statusbtn.node.on(oe.NodeEventType.TOUCH_END,this.fightStateClickFun,this,!1)}
OnBtnClickHead(){const e=new wn.v
e.isShowMask=!0,(0,Ce.Yp)(Q.o.CharacterTopView,e)}onClickVIPHandle(){X.U.inst.controller.OpenPanel(null,null)}UpdateVipPart(){
this.cnode.vipLabel.string=`VIP ${this.roleInfo.mVipLevel}`
let e=de.f.Inst.GetData(ce.t.VIP_BOX)
e?this.cnode.vipRedDot.SetActive(e.show):this.cnode.vipRedDot.SetActive(!1)}UpdateBuffList(e){Hi.T.inst_get().model.UpdaeBuffData()
let t="Buff x"+this.GetBuffCount()
this.cnode.buffLabel.string=t}GetBuffCount(){let e=n.Y.Inst.primaryRoleInfoList,t=null,i=null,s=0,a=new z.Z
for(let n=0;n<=e.Count()-1;n++){t=e[n],i=I.j.Inst_get().model.getBuffsByPlayerId(t.Id_get())
let r=null
for(let e=0;e<=i.Count()-1;e++){r=i[e]
let t=r.buffRes_get()
null!=t.icon&&""!=t.icon&&((2!=t.showType||a.Contains(t.id))&&(1!=t.showType||a.Contains(t.id))||(a.Add(t.id),s+=1))}}return s}buffBtnClickFun(){Ln.m.Inst_get().Open()}
fightStateClickFun(){if(n.Y.Inst.m_primaryRoleInfo.Level_get()<this.newPlayerLevel){const e=K.o.Format("{0}级之前不能切换PK模式",this.newPlayerLevel)
k.y.inst.ClientSysStrMsg(e)}else U.g.Inst.OpenView()}OnClickRechargePanel(){
if(!Le.o.Inst_get().isFristRecharge)return Ae.P.Inst_get().IsFunctionOpened(ye.x.FIRST_CHARGE)?void T.v.Inst_get().OpenView():void fe.l.SetFunctionTip(ye.x.FIRST_CHARGE)
Ae.P.Inst_get().IsFunctionOpened(ye.x.MALL)&&(we.N.GetInst().CheckShopHasGoodsBuy(5,1)?De.O.Inst_get().Open(null,5,1):we.N.GetInst().CheckShopHasGoodsBuy(3,1)?De.O.Inst_get().Open(null,3,1):De.O.Inst_get().Open(null,2,1))
}UpdatePkModel(){let e,t
Pn.k.Inst_get().pkModel==On.j.PEACE_MODEL?(e="和平",t="atlas/mainui/rymainui_bt_0001"):Pn.k.Inst_get().pkModel==On.j.GUILD_MODEL?(e="强制",
t="atlas/mainui/rymainui_bt_0014"):Pn.k.Inst_get().pkModel==On.j.ASURAM_WAR_CAMP?(e="王国",t="atlas/mainui/rymainui_bt_0014"):(e="全体",t="atlas/mainui/rymainui_bt_0015"),
this.cnode.stateImg.skin=t,this.cnode.statelabel.textSet(e)}OnUpdate(){this.roleInfo=n.Y.Inst.PrimaryRoleInfo_get(),this.m_pInfo=n.Y.Inst.PrimaryRoleInfo_get(),this.SetData()}
CurrOnUpdate(){this.roleInfo=n.Y.Inst.PrimaryRoleInfo_get(),this.cnode.currencylab.string=S.w.Instance.ConvertNumToString(this.roleInfo.gold_Diamond)}SetBattleSocre(){}Clear(){
this.AddOrDelEvent(!1)}Destory(){}})
var bn,Gn,Un,Bn,kn,Fn,Hn,xn,Vn,Yn,Wn,Kn,Zn,zn,qn,$n,Xn,Qn,jn,Jn,es,ts,is,ns,ss,as,rs,ls,os,_s,us,hs,cs,ds,ms,ps,gs,Is,Es,Cs,Ss,Ts,fs,As,ys,Rs,Ds,ws,Ls,vs,Os,Ps,Ns,Ms,bs,Gs,Us,Bs,ks,Fs,Hs,xs,Vs,Ys,Ws,Ks,Zs,zs,qs,$s,Xs,Qs,js,Js,ea,ta,ia,na,sa,aa
i(9312)
function ra(e,t,i,n,s){var a={}
return Object.keys(n).forEach((function(e){a[e]=n[e]})),a.enumerable=!!a.enumerable,a.configurable=!!a.configurable,("value"in a||a.initializer)&&(a.writable=!0),
a=i.slice().reverse().reduce((function(i,n){return n(e,t,i)||i}),a),s&&void 0!==a.initializer&&(a.value=a.initializer?a.initializer.call(s):void 0,a.initializer=void 0),
void 0===a.initializer&&(Object.defineProperty(e,t,a),a=null),a}const la=Object.defineProperty
Object.defineProperty=function(e,t,i){try{return la.call(Object,e,t,i)}catch(e){}return e}
let oa=(bn=(0,Ue.Dr)("GameSys.ArrowDisplayMgr"),Gn=(0,Ue.Dr)("GameSys.CharacterMgr"),Un=(0,Ue.Dr)("CrossMapExtand"),Bn=(0,Ue.Dr)("StateMach",1),kn=(0,Ue.Dr)("HorseCharacter",1),
Fn=(0,Ue.Dr)("Player",1),Hn=(0,Ue.Dr)("PathFindUtil",1),xn=(0,Ue.Dr)("GameSys.LuaDisplayBridgeManager"),Vn=(0,Ue.Dr)("ElementMgr"),Yn=(0,Ue.Dr)("LuaElementBridgeManager"),Wn=(0,
Ue.Dr)("GameSys.LuaEventMgr"),Kn=(0,Ue.Dr)("GameSys.LuaEngineBridgeManager"),Zn=(0,Ue.Dr)("GameMapManager"),zn=(0,Ue.Dr)("GameSys.SkillModel"),qn=(0,Ue.Dr)("GameSys.AniSoundMgr"),
$n=(0,Ue.Dr)("GameSys.UIShowShortCut"),Xn=(0,Ue.Dr)("GameSys.LuaUIUtil",1),Qn=(0,Ue.Dr)("LuaSceneBridgeManager"),jn=(0,Ue.Dr)("AccessMgr"),Jn=(0,Ue.Dr)("GameSys.AsuramWarModel"),
es=(0,Ue.Dr)("AllianceBossUtil",1),ts=(0,Ue.Dr)("GameSys.BagManager"),is=(0,Ue.Dr)("GameSys.ItemTipManager"),ns=(0,Ue.Dr)("RyTipCompFactory"),ss=(0,
Ue.Dr)("GameSys.BuffViewManager"),as=(0,Ue.Dr)("CopyBaseControl"),rs=(0,Ue.Dr)("GameSys.CopyBaseModel"),ls=(0,Ue.Dr)("LuaExtraPackageLoaderController"),os=(0,
Ue.Dr)("AccessCfgManager"),_s=(0,Ue.Dr)("MapPassModel"),us=(0,Ue.Dr)("RechargeControl"),hs=(0,Ue.Dr)("SettingMainControl"),cs=(0,Ue.Dr)("SystemTipsControl"),ds=(0,
Ue.Dr)("TaskUtil",1),ms=(0,Ue.Dr)("TaskModel"),ps=(0,Ue.Dr)("TransportMapModel"),gs=(0,Ue.Dr)("GameSys.RyPandoraTipsControl"),Is=(0,Ue.Dr)("FunctionUtil",1),Es=(0,
Ue.Dr)("GameSys.CommonUtil",1),(aa=class{}).arrowDisplayMgr=void 0,aa.characterMgr=void 0,aa.crossMapExtand=void 0,aa.StateMach=void 0,aa.HorseCharacter=void 0,aa.Player=void 0,
aa.PathFindUtil=void 0,aa.luaDisplayBridgeManager=void 0,aa.elementMgr=void 0,aa.luaElementBridgeManager=void 0,aa.luaEventMgr=void 0,aa.luaEngineBridgeManager=void 0,
aa.gameMapManager=void 0,aa.skillModel=void 0,aa.aniSoundMgr=void 0,aa.uIShowShortCut=void 0,aa.LuaUIUtil=void 0,aa.luaSceneBridgeManager=void 0,aa.accessMgr=void 0,
aa.asuramWarModel=void 0,aa.AllianceBossUtil=void 0,aa.bagManager=void 0,aa.itemTipManager=void 0,aa.ryTipCompFactory=void 0,aa.buffViewManager=void 0,aa.copyBaseControl=void 0,
aa.copyBaseModel=void 0,aa.luaExtraPackageLoaderController=void 0,aa.accessCfgManager=void 0,aa.mapPassModel=void 0,aa.rechargeControl=void 0,aa.settingMainControl=void 0,
aa.systemTipsControl=void 0,aa.TaskUtil=void 0,aa.taskModel=void 0,aa.transportMapModel=void 0,aa.ryPandoraTipsControl=void 0,aa.FunctionUtil=void 0,aa.CommonUtil=void 0,
ra(Cs=aa,"arrowDisplayMgr",[bn],(Ss=(Ss=Object.getOwnPropertyDescriptor(Cs,"arrowDisplayMgr"))?Ss.value:void 0,{enumerable:!0,configurable:!0,writable:!0,initializer:function(){
return Ss}}),Cs),ra(Cs,"characterMgr",[Gn],(Ts=(Ts=Object.getOwnPropertyDescriptor(Cs,"characterMgr"))?Ts.value:void 0,{enumerable:!0,configurable:!0,writable:!0,
initializer:function(){return Ts}}),Cs),ra(Cs,"crossMapExtand",[Un],(fs=(fs=Object.getOwnPropertyDescriptor(Cs,"crossMapExtand"))?fs.value:void 0,{enumerable:!0,configurable:!0,
writable:!0,initializer:function(){return fs}}),Cs),ra(Cs,"StateMach",[Bn],(As=(As=Object.getOwnPropertyDescriptor(Cs,"StateMach"))?As.value:void 0,{enumerable:!0,configurable:!0,
writable:!0,initializer:function(){return As}}),Cs),ra(Cs,"HorseCharacter",[kn],(ys=(ys=Object.getOwnPropertyDescriptor(Cs,"HorseCharacter"))?ys.value:void 0,{enumerable:!0,
configurable:!0,writable:!0,initializer:function(){return ys}}),Cs),ra(Cs,"Player",[Fn],(Rs=(Rs=Object.getOwnPropertyDescriptor(Cs,"Player"))?Rs.value:void 0,{enumerable:!0,
configurable:!0,writable:!0,initializer:function(){return Rs}}),Cs),ra(Cs,"PathFindUtil",[Hn],(Ds=(Ds=Object.getOwnPropertyDescriptor(Cs,"PathFindUtil"))?Ds.value:void 0,{
enumerable:!0,configurable:!0,writable:!0,initializer:function(){return Ds}}),Cs),
ra(Cs,"luaDisplayBridgeManager",[xn],(ws=(ws=Object.getOwnPropertyDescriptor(Cs,"luaDisplayBridgeManager"))?ws.value:void 0,{enumerable:!0,configurable:!0,writable:!0,
initializer:function(){return ws}}),Cs),ra(Cs,"elementMgr",[Vn],(Ls=(Ls=Object.getOwnPropertyDescriptor(Cs,"elementMgr"))?Ls.value:void 0,{enumerable:!0,configurable:!0,
writable:!0,initializer:function(){return Ls}}),Cs),ra(Cs,"luaElementBridgeManager",[Yn],(vs=(vs=Object.getOwnPropertyDescriptor(Cs,"luaElementBridgeManager"))?vs.value:void 0,{
enumerable:!0,configurable:!0,writable:!0,initializer:function(){return vs}}),Cs),
ra(Cs,"luaEventMgr",[Wn],(Os=(Os=Object.getOwnPropertyDescriptor(Cs,"luaEventMgr"))?Os.value:void 0,{enumerable:!0,configurable:!0,writable:!0,initializer:function(){return Os}
}),Cs),ra(Cs,"luaEngineBridgeManager",[Kn],(Ps=(Ps=Object.getOwnPropertyDescriptor(Cs,"luaEngineBridgeManager"))?Ps.value:void 0,{enumerable:!0,configurable:!0,writable:!0,
initializer:function(){return Ps}}),Cs),ra(Cs,"gameMapManager",[Zn],(Ns=(Ns=Object.getOwnPropertyDescriptor(Cs,"gameMapManager"))?Ns.value:void 0,{enumerable:!0,configurable:!0,
writable:!0,initializer:function(){return Ns}}),Cs),ra(Cs,"skillModel",[zn],(Ms=(Ms=Object.getOwnPropertyDescriptor(Cs,"skillModel"))?Ms.value:void 0,{enumerable:!0,
configurable:!0,writable:!0,initializer:function(){return Ms}}),Cs),ra(Cs,"aniSoundMgr",[qn],(bs=(bs=Object.getOwnPropertyDescriptor(Cs,"aniSoundMgr"))?bs.value:void 0,{
enumerable:!0,configurable:!0,writable:!0,initializer:function(){return bs}}),Cs),
ra(Cs,"uIShowShortCut",[$n],(Gs=(Gs=Object.getOwnPropertyDescriptor(Cs,"uIShowShortCut"))?Gs.value:void 0,{enumerable:!0,configurable:!0,writable:!0,initializer:function(){
return Gs}}),Cs),ra(Cs,"LuaUIUtil",[Xn],(Us=(Us=Object.getOwnPropertyDescriptor(Cs,"LuaUIUtil"))?Us.value:void 0,{enumerable:!0,configurable:!0,writable:!0,initializer:function(){
return Us}}),Cs),ra(Cs,"luaSceneBridgeManager",[Qn],(Bs=(Bs=Object.getOwnPropertyDescriptor(Cs,"luaSceneBridgeManager"))?Bs.value:void 0,{enumerable:!0,configurable:!0,writable:!0,
initializer:function(){return Bs}}),Cs),ra(Cs,"accessMgr",[jn],(ks=(ks=Object.getOwnPropertyDescriptor(Cs,"accessMgr"))?ks.value:void 0,{enumerable:!0,configurable:!0,writable:!0,
initializer:function(){return ks}}),Cs),ra(Cs,"asuramWarModel",[Jn],(Fs=(Fs=Object.getOwnPropertyDescriptor(Cs,"asuramWarModel"))?Fs.value:void 0,{enumerable:!0,configurable:!0,
writable:!0,initializer:function(){return Fs}}),Cs),ra(Cs,"AllianceBossUtil",[es],(Hs=(Hs=Object.getOwnPropertyDescriptor(Cs,"AllianceBossUtil"))?Hs.value:void 0,{enumerable:!0,
configurable:!0,writable:!0,initializer:function(){return Hs}}),Cs),ra(Cs,"bagManager",[ts],(xs=(xs=Object.getOwnPropertyDescriptor(Cs,"bagManager"))?xs.value:void 0,{
enumerable:!0,configurable:!0,writable:!0,initializer:function(){return xs}}),Cs),
ra(Cs,"itemTipManager",[is],(Vs=(Vs=Object.getOwnPropertyDescriptor(Cs,"itemTipManager"))?Vs.value:void 0,{enumerable:!0,configurable:!0,writable:!0,initializer:function(){
return Vs}}),Cs),ra(Cs,"ryTipCompFactory",[ns],(Ys=(Ys=Object.getOwnPropertyDescriptor(Cs,"ryTipCompFactory"))?Ys.value:void 0,{enumerable:!0,configurable:!0,writable:!0,
initializer:function(){return Ys}}),Cs),ra(Cs,"buffViewManager",[ss],(Ws=(Ws=Object.getOwnPropertyDescriptor(Cs,"buffViewManager"))?Ws.value:void 0,{enumerable:!0,configurable:!0,
writable:!0,initializer:function(){return Ws}}),Cs),ra(Cs,"copyBaseControl",[as],(Ks=(Ks=Object.getOwnPropertyDescriptor(Cs,"copyBaseControl"))?Ks.value:void 0,{enumerable:!0,
configurable:!0,writable:!0,initializer:function(){return Ks}}),Cs),ra(Cs,"copyBaseModel",[rs],(Zs=(Zs=Object.getOwnPropertyDescriptor(Cs,"copyBaseModel"))?Zs.value:void 0,{
enumerable:!0,configurable:!0,writable:!0,initializer:function(){return Zs}}),Cs),
ra(Cs,"luaExtraPackageLoaderController",[ls],(zs=(zs=Object.getOwnPropertyDescriptor(Cs,"luaExtraPackageLoaderController"))?zs.value:void 0,{enumerable:!0,configurable:!0,
writable:!0,initializer:function(){return zs}}),Cs),ra(Cs,"accessCfgManager",[os],(qs=(qs=Object.getOwnPropertyDescriptor(Cs,"accessCfgManager"))?qs.value:void 0,{enumerable:!0,
configurable:!0,writable:!0,initializer:function(){return qs}}),Cs),ra(Cs,"mapPassModel",[_s],($s=($s=Object.getOwnPropertyDescriptor(Cs,"mapPassModel"))?$s.value:void 0,{
enumerable:!0,configurable:!0,writable:!0,initializer:function(){return $s}}),Cs),
ra(Cs,"rechargeControl",[us],(Xs=(Xs=Object.getOwnPropertyDescriptor(Cs,"rechargeControl"))?Xs.value:void 0,{enumerable:!0,configurable:!0,writable:!0,initializer:function(){
return Xs}}),Cs),ra(Cs,"settingMainControl",[hs],(Qs=(Qs=Object.getOwnPropertyDescriptor(Cs,"settingMainControl"))?Qs.value:void 0,{enumerable:!0,configurable:!0,writable:!0,
initializer:function(){return Qs}}),Cs),ra(Cs,"systemTipsControl",[cs],(js=(js=Object.getOwnPropertyDescriptor(Cs,"systemTipsControl"))?js.value:void 0,{enumerable:!0,
configurable:!0,writable:!0,initializer:function(){return js}}),Cs),ra(Cs,"TaskUtil",[ds],(Js=(Js=Object.getOwnPropertyDescriptor(Cs,"TaskUtil"))?Js.value:void 0,{enumerable:!0,
configurable:!0,writable:!0,initializer:function(){return Js}}),Cs),ra(Cs,"taskModel",[ms],(ea=(ea=Object.getOwnPropertyDescriptor(Cs,"taskModel"))?ea.value:void 0,{enumerable:!0,
configurable:!0,writable:!0,initializer:function(){return ea}}),Cs),ra(Cs,"transportMapModel",[ps],(ta=(ta=Object.getOwnPropertyDescriptor(Cs,"transportMapModel"))?ta.value:void 0,
{enumerable:!0,configurable:!0,writable:!0,initializer:function(){return ta}}),Cs),
ra(Cs,"ryPandoraTipsControl",[gs],(ia=(ia=Object.getOwnPropertyDescriptor(Cs,"ryPandoraTipsControl"))?ia.value:void 0,{enumerable:!0,configurable:!0,writable:!0,
initializer:function(){return ia}}),Cs),ra(Cs,"FunctionUtil",[Is],(na=(na=Object.getOwnPropertyDescriptor(Cs,"FunctionUtil"))?na.value:void 0,{enumerable:!0,configurable:!0,
writable:!0,initializer:function(){return na}}),Cs),ra(Cs,"CommonUtil",[Es],(sa=(sa=Object.getOwnPropertyDescriptor(Cs,"CommonUtil"))?sa.value:void 0,{enumerable:!0,
configurable:!0,writable:!0,initializer:function(){return sa}}),Cs),Cs)
globalThis.INS=oa,Object.defineProperty=la
var _a=i(69641),ua=i(39407),ha=i(87115),ca=i(62846),da=i(75309),ma=i(80392),pa=i(34441),ga=i(50107),Ia=i(53908),Ea=i(41295),Ca=i(41766),Sa=i(37397),Ta=i(69442),fa=i(55360),Aa=i(76791)
class ya{constructor(){this._isLoading=!1,this._isChecked=!1,this._isResLoaded=!1,this._isConfigParsed=!1,this._isGlobalSetup=!1}startPreload(){if(this._isLoading)return
this._isLoading=!0
const e=[]
e.push({url:"ryconfigs/configpack.bin",loadType:"remote",callback:this._onConfigLoaded.bind(this)},{url:"materials/sprite_flow",type:oe.Material,addRef:!0,cache:pa.X.Long},{
url:"atlas/fightword",type:oe.SpriteAtlas,addRef:!0,cache:pa.X.Long},{url:"ui/commonhint/ui_commonhint_hintpanel",type:oe.Prefab,addRef:!0,cache:pa.X.Long},{
url:"ui/loading_ry/ui_loading_circleview_ry",type:oe.Prefab,addRef:!0,cache:pa.X.Long},{url:"texts/flow",type:oe.JsonAsset,callback:wa}),Ra(e,(()=>{this._isResLoaded=!0,(0,
ua.t4)("--- Preload ResLoaded complete"),this._checkPreloadEnd()}))}_onConfigLoaded(e){(0,Ia.kc)(e),(0,ua.t4)("--- Preload CfgMgr.Inst"),Ca.g.Inst
let t=0;(0,ua.t4)("--- Preload LoadAllCustomCsv")
const i=fa.Y.Inst_get(),n=i.m_mapString2ID,s=Object.getOwnPropertyNames(n),a=()=>{let e=performance.now()
const r=s.pop()
i.LoadCsvTable(r,n[r]),t+=performance.now()-e,s.length>0?this._isGlobalSetup?a():cus.scheduleOnce(0,a):((0,ua.t4)(`--- Preload LoadAllCustomCsv done ${t}`),this._onConfigParsed())}
cus.scheduleOnce(0,a)}_onConfigParsed(){this._isConfigParsed=!0,INS.settingMainControl.initWxDeviceInfo(),de.f.Inst.AddTree(),Ki.p.Inst_get().headAllUI(),da.n.Inst,
Ta._.Instance.Init(),G.k.Inst_get().RegMsg(),Sa._.Inst.Init(),s.M.Inst_get().AddEvent(),(0,Ue.bD)(),(0,ua.t4)("--- Preload onConfigParsed done"),this._checkPreloadEnd()}
_checkPreloadEnd(){!this._isChecked&&this._isResLoaded&&this._isConfigParsed&&this._isGlobalSetup&&(this._isChecked=!0,(0,ua.t4)("--- GEvent.LOGIN_CONNECT"),(0,
Be.bG)(Ea.b.LOGIN_CONNECT),(0,Be.bG)(ga.C.CREATE_SCENE),(0,Ce.V9)(),Aa.v.update(Aa.v.Flag.LOADING_COMPLETE))}}function Ra(e,t){let i=e.length
function n(e,n){null!=e.callback&&e.callback(n,e),e.append&&e.append.length>0?Ra(e.append,(()=>{i-=1,0===i&&null!=t&&t()})):(i-=1,0===i&&null!=t&&t())}e.forEach((e=>{
switch(e.loadType){case"bundles":!function(e,t){const i=[]
if(i.length){let n=i.length
i.forEach((i=>{i.loadBundle((()=>{n--,0==n&&t(e)}))}))}else t(e)}(e,n)
break
case"remote":!function(e,t,i){It.o.listenRes(It.o.loadRemote(e.url,pa.X.RefTick),(t=>{i(e,t)}))}(e,e.native,n)
break
case"cremote":!function(e,t,i){oe.assetManager.loadRemote(e.url,null,((t,n)=>{i(e,n)}))}(e,0,n)
break
case"packin":!function(e,t,i){It.o.listenRes(It.o.loadPackin(e.url,pa.X.RefTick),(t=>{i(e,t)}))}(e,e.native,n)
break
case"preload":!function(e,t){let i=0
const n=n=>{i--,0==i&&t(e)},s=getText("%loadTexts"),a=s?s.split(";"):[]
if(i+=a.length,0==i)return void t(e)
for(let e=0;e<a.length;e++)It.o.listenRes(It.o.loadRemote(`texts/${a[e]}.txt`),(e=>{e&&Da(e),n(e)}))}(e,n)
break
default:!function(e,t){const i=e.bundle||"wealth"
It.o.listenRes(It.o.loadBundleRes(e.url,i,e.type,e.addRef?pa.X.Long:e.cache||pa.X.RefTime),(i=>{i&&e.addRef&&i.addRef(),t(e,i)}))}(e,n)}}))}function Da(e){
cus._setTextRecord(cus._assignKeyValue(cus._getTextRecord(),e))}function wa(e,t){console.log("assetFlow"),a.n.InitFlowColorData(e)}ya.ins=new ya
var La=i(11356),va=i(8125),Oa=i(60579)
i(39229)
launcher._gameLogicInterfaces={init(){(0,Oa.G)(),(0,Ue.aH)()},preload(){(0,ua.t4)("--- Main preload"),It.o.setup(),ya.ins.startPreload()},setup(){(0,ua.t4)("--- Main Setup"),
cus._pauseInvokers(!0),_a.o.LuaCallBackMgr=da.n,_a.o.CharacterMgr=n.Y,_a.o.UIUtilBridge=va.T,_a.o.LuaDisplayBridgeManager=a.n,_a.o.JoystickControl=ma.H,_a.o.LostHpManager=ca.b,
_a.o.getServiceVo=ha.$e,_a.o.getServiceVoId=ha.D_,_a.o.LusuoLong=Wt.o,cus._refreshGameTime=(e,t)=>{st.GF.NewFrame(e/1e3)},st.GF.NewFrame(cus.currTime/1e3),
MiniPlatController.sendClick(38),cus.beforeUpdateInvoker.add(Ct.pF),La.y.setup(),va.T.setup(),ya.ins._isGlobalSetup=!0,ya.ins._checkPreloadEnd()}}
const Pa=__$LaunchLogicBridge
Pa.UrlPrefab=Y.Z,Pa.CList=z.Z
var Na,Ma,ba,Ga,Ua,Ba=i(84187),ka=i(66008),Fa=i(83236)
function Ha(e,t,i,n,s){var a={}
return Object.keys(n).forEach((function(e){a[e]=n[e]})),a.enumerable=!!a.enumerable,a.configurable=!!a.configurable,("value"in a||a.initializer)&&(a.writable=!0),
a=i.slice().reverse().reduce((function(i,n){return n(e,t,i)||i}),a),s&&void 0!==a.initializer&&(a.value=a.initializer?a.initializer.call(s):void 0,a.initializer=void 0),
void 0===a.initializer&&(Object.defineProperty(e,t,a),a=null),a}Na=(0,Be.GH)(Ba.V.SCENE_READY),Ma=(0,Be.GH)(Ke.k.SM_EnterWorld),ba=(0,Be.GH)(ga.C.CREATE_SCENE),(0,
Be.Oo)((Ha((Ua=class{constructor(){this.isSceneCreated=!1,this.isFirstSceneReady=!0}onSceneReady(){if(!this.isFirstSceneReady)return
this.isFirstSceneReady=!1,console.log("--- MMOSceneProxy FirstSceneReady")
const e=[()=>{k.y.inst.OpenSysTipsPanel()},()=>{k.y.inst.OpenRiAndLaPanel()},()=>{k.y.inst.OpenSystemChannelPanel()},()=>{Fa.Y.Inst_get().Open()},()=>{(0,Ce.Yp)(Q.o.ChatShowPanel)
},()=>{Hi.T.inst_get().control.OpenInitView()}],t=(0,Ce.S1)(),i=()=>{if(e.length>0){const t=e.shift()
return e.length>0&&cus.updateInvoker.add(i),void t()}if(t.length>0){const e=t.shift()
t.length>0&&cus.updateInvoker.add(i),(0,Ce.Yp)(e[0],e[1],e[2])}}
cus.scheduleOnce(.1,i)}onSM_EnterWorldHandler(e){u.b.Inst.OnSM_EnterWorld()}onCreateScene(){this.isSceneCreated||(this.isSceneCreated=!0,ka.n.gameStage._setup())}
}).prototype,"onSceneReady",[Na],Object.getOwnPropertyDescriptor(Ua.prototype,"onSceneReady"),Ua.prototype),
Ha(Ua.prototype,"onSM_EnterWorldHandler",[Ma],Object.getOwnPropertyDescriptor(Ua.prototype,"onSM_EnterWorldHandler"),Ua.prototype),
Ha(Ua.prototype,"onCreateScene",[ba],Object.getOwnPropertyDescriptor(Ua.prototype,"onCreateScene"),Ua.prototype),Ga=Ua))
var xa=i(85688),Va=i(34272)
const Ya=(0,Ue.ll)("launch.CommonUtil")
var Wa,Ka,Za,za,qa,$a,Xa,Qa,ja,Ja,er=i(99276)
function tr(e,t,i,n,s){var a={}
return Object.keys(n).forEach((function(e){a[e]=n[e]})),a.enumerable=!!a.enumerable,a.configurable=!!a.configurable,("value"in a||a.initializer)&&(a.writable=!0),
a=i.slice().reverse().reduce((function(i,n){return n(e,t,i)||i}),a),s&&void 0!==a.initializer&&(a.value=a.initializer?a.initializer.call(s):void 0,a.initializer=void 0),
void 0===a.initializer&&(Object.defineProperty(e,t,a),a=null),a}Wa=(0,Be.GH)(Ea.b.LOGIN_CONNECT),Ka=(0,Be.GH)(ga.C.SOCKET_CONNECTED),Za=(0,Be.GH)(Ke.k.SM_UpdateReconnectInfo),
za=(0,Be.GH)(Ke.k.SM_LoginFail),qa=(0,Be.GH)(Ke.k.SM_LoginPlayerInfoList),$a=(0,Be.GH)(Ke.k.SM_ReconnectSuccess),Xa=(0,Be.GH)(Ke.k.SM_BackpackItems),Qa=(0,Be.GH)(Ba.V.SCENE_READY),
(0,Be.Oo)((tr((Ja=class{constructor(){this._isResLoaded=!1,this._hadSendRoleLogin=!1,this._hadCloseLogin=!1,this._sock=null,this._reconnectEnabled=!0,this._loginComplete=!1,
this._isKickOff=!1,this._heartT=0,this._reConnectStartTime=0,this._reConnectNum=0,this._reTryT=0,this._lastHeartbeatTime=0,this.isInitPlayer=!1,this.reconnectInfo=void 0}
onStartConnect(){Ya.isKickOff=()=>this._isKickOff
const e=launcher.config
MiniPlatController.sendClick(39),(0,ua.t4)(`--- connectWebSocket ip: ${e.socketIp} port: ${e.socketPort} [server: ${e.serverId}]`),this._sock=(0,Va.yt)(e.socketIp,e.socketPort)}
SendHeartbeat(){P.W.Inst.StartHeartbeat()}onNetSocketConnected(){(0,ua.t4)("--- onNetSocketConnected"),this.SendHeartbeat()
const e=new R.T,t=launcher.config
e.account=launcher.userName,e.pid=t.op,e.server=t.serverId,e.os="1",e.time=22,e.downloadB=!0,e.net_type=0,e.guid="",e.account=t.account,e.pid=`${t.pid}`,e.gid=`${t.gid}`,
e.server=`${t.serverId}`,e.os="wxapp",e.sign=t.sign,e.time=Number(t.time),e.guid=t.sdkData.guid,this.reconnectInfo&&(e.reKey=this.reconnectInfo.reKey),(0,
ua.t4)(`---cmlogin ${JSON.stringify(e)}`),MiniPlatController.sendClick(40),ke.C.Inst.F_SendMsg(e),this._lastHeartbeatTime=cus.currTime,
this._sock.socket.isConnextSuccess&&$i.D.ResetDataInScene(),null!=n.Y.Inst&&n.Y.Inst.ReconnectClear()}onSMUpdateReconnectInfo(e){(0,ua.t4)("--- SM_UpdateReconnectInfo"),
this.reconnectInfo=e}onSMLoginFail(e){(0,ua.t4)(`--- SM_LoginFail ${JSON.stringify(e)}`),17==e.code?(MiniPlatController.sendClick(43),
Sa._.Inst.openLoginTips()):8!=e.code&&P.W.Inst.registerError.error[e.code]?k.y.inst.ClientStrMsg(Zt.r.SystemTipMessage,P.W.Inst.registerError.error[e.code]):(MiniPlatController.sendClick(43),
-1==Vi.t.ins.jobID?(0,Ce.Yp)(Q.o.Createroleview_Ry):er.J.getInst().SendCreateRole(Vi.t.ins.jobID,"",Vi.t.ins.sexType))}onSMLoginPlayerInfoList(e){(0,
ua.t4)(`--- SM_LoginPlayerInfoList ${JSON.stringify(e)}`),MiniPlatController.sendClick(42)
const t=new D.j
t.playerId=e.lastLogin,ke.C.Inst.F_SendMsg(t)}onSMReconnectSuccess(){(0,ua.t4)("--- SM_ReconnectSuccess"),(0,Ce.sR)(je.I.eRyLoadingCircleView),(0,Ce.sR)(Q.o.eCommonHintPanel),
Sa._.Inst.isShowTips=!1,ke.C.Inst.F_SendMsg(new A.t)}SM_BackpackItemsHandler(e){for(const[t,i]of e.packMap)ne.g.Inst_get().setBagData(i,null,t)}onSceneReady(){
cus._pauseInvokers(!1),__$LaunchLogicBridge._shutdownLaunchLayer(xa.n.ins.getLayer(qt.T.panel)),_.L.sceneLoadFinish=!0,u.b.Inst.loadMapComplete()}_onFrame(){
cus.currTime-this._lastHeartbeatTime>=5e3&&(this._lastHeartbeatTime=cus.currTime,ke.C.Inst.F_SendMsg(new y.e))}
}).prototype,"onStartConnect",[Wa],Object.getOwnPropertyDescriptor(Ja.prototype,"onStartConnect"),Ja.prototype),
tr(Ja.prototype,"onNetSocketConnected",[Ka],Object.getOwnPropertyDescriptor(Ja.prototype,"onNetSocketConnected"),Ja.prototype),
tr(Ja.prototype,"onSMUpdateReconnectInfo",[Za],Object.getOwnPropertyDescriptor(Ja.prototype,"onSMUpdateReconnectInfo"),Ja.prototype),
tr(Ja.prototype,"onSMLoginFail",[za],Object.getOwnPropertyDescriptor(Ja.prototype,"onSMLoginFail"),Ja.prototype),
tr(Ja.prototype,"onSMLoginPlayerInfoList",[qa],Object.getOwnPropertyDescriptor(Ja.prototype,"onSMLoginPlayerInfoList"),Ja.prototype),
tr(Ja.prototype,"onSMReconnectSuccess",[$a],Object.getOwnPropertyDescriptor(Ja.prototype,"onSMReconnectSuccess"),Ja.prototype),
tr(Ja.prototype,"SM_BackpackItemsHandler",[Xa],Object.getOwnPropertyDescriptor(Ja.prototype,"SM_BackpackItemsHandler"),Ja.prototype),
tr(Ja.prototype,"onSceneReady",[Qa],Object.getOwnPropertyDescriptor(Ja.prototype,"onSceneReady"),Ja.prototype),ja=Ja))
oe.Button.prototype.SetText=function(e){const t=this.getComponentInChildren(oe.Label)
t&&(t.string=e)},oe.Button.prototype.normalSpriteSet=function(e){},oe.Button.prototype.hoverSpriteSet=function(e){},oe.Button.prototype.pressedSpriteSet=function(e){},
oe.Button.prototype.setValue=function(e){const t=this.getComponentInChildren(oe.Sprite)
t&&(t.node.visible=e)}
const ir=oe.Button.prototype._onTouchEnded
oe.Button.prototype._onTouchEnded=function(e){if(!this._interactable||!this.enabledInHierarchy)return
ir.call(this,e)
let t=null
const i=this._sprite
i&&i.spriteFrame&&(t=i.spriteFrame.name,ue.Y.Log("按钮图片名称："+t))}
var nr=i(47465)
oe.Component.prototype.GetIsEnabled=function(){return this.enabled},oe.Component.prototype.SetIsEnabled=function(e){this.enabled=e},
oe.Component.prototype.CreateDelegate=function(e){return(0,nr.r)(e,this)},oe.Component.prototype.GetBoundsSize=function(){const e=this.node.transform.getBoundingBoxToWorld()
return new oe.Vec2(e.width,e.height)},oe.Component.prototype.SetItemIconByAtlas=function(e,t,i){},oe.Label.prototype.text=function(){return this.string},
oe.Label.prototype.textSet=function(e){this.string=e,this.updateRenderer()},oe.Label.prototype.printedSize=function(){return this.updateRenderer(),
new ft.F(this.node.transform.width,this.node.transform.height)},oe.Node.prototype.SetActive=function(e){this.active=e},oe.Node.prototype.GetAlpha=function(){return this.opacity/255
},oe.Node.prototype.SetAlpha=function(e){this.opacity=Math.floor(255*e)},oe.Node.prototype.SetLocalPositionXYZ=function(e,t,i){this.setPosition(e,t,i)}
var sr,ar=i(63921)
function rr(e){e.pivotSet=function(e){let t=.5,i=.5
switch(e){case ar.F.eTopLeft:t=0,i=1
break
case ar.F.eTop:t=.5,i=1
break
case ar.F.eTopRight:t=1,i=1
break
case ar.F.eLeft:t=0,i=.5
break
case ar.F.eCenter:t=.5,i=.5
break
case ar.F.eRight:t=1,i=.5
break
case ar.F.eBottomLeft:t=0,i=0
break
case ar.F.eBottom:t=.5,i=0
break
case ar.F.eBottomRight:t=1,i=0}this.node.transform.setAnchorPoint(t,i)},e.GetPivot=function(){const e=this.node.transform
return new oe.Vec2(e.anchorX,e.anchorY)},e.width=function(){return this.node.transform.width},e.widthSet=function(e){this.node.transform.width=e},e.height=function(){
return this.node.transform.height},e.heightSet=function(e){this.node.transform.height=e},e.SetColor=function(e){this.color=e},e.SetColorRGBA=function(e,t,i,n){
this.color=new oe.Color(Math.floor(255*e),Math.floor(255*t),Math.floor(255*i),Math.floor(255*n))},e.GetAlpha=function(){return this.node.opacity/255},e.SetAlpha=function(e){
this.node.opacity=Math.floor(255*e)},e.isVisible=function(){return this.node.opacity>0}}rr(oe.UIRenderer.prototype),oe.RichText.prototype.text=function(){return this.string},
oe.RichText.prototype.textSet=function(e){this.string=e,this.node.active&&this.GetIsEnabled()&&this._updateRichText()},oe.RichText.prototype.lineCount=function(){
return this._linesWidth.length},rr(oe.RichText.prototype),oe.UITransform.prototype.GetLocalPosition=function(e){return this.node.getPosition(e)},
oe.UITransform.prototype.SetLocalPosition=function(e){this.node.setPosition(e)},oe.UITransform.prototype.SetRotate=function(e){this.node.setRotationFromEuler(e)},
oe.UITransform.prototype.SetLocalPositionXYZ=function(e,t,i){this.node.setPosition(new oe.Vec3(e,t,i))},oe.UITransform.prototype.GetLocalPositionXYZ=function(){
return[this.node.x,this.node.y,0]}
const{ccclass:lr,executeInEditMode:or,menu:_r,property:ur,type:hr}=oe._decorator
lr("app/RyUIGrid")(sr=_r("app/RyUIGrid")(sr=class extends oe.Component{})||sr)
var cr
const{ccclass:dr,executeInEditMode:mr,menu:pr,property:gr,type:Ir}=oe._decorator
dr("app/RyUITable")(cr=pr("app/RyUITable")(cr=class extends oe.Component{})||cr)
i(39470),i(96175),i(62463),i(70167),i(18043),i(64302)},29567:(e,t,i)=>{"use strict"
i.d(t,{x:()=>T})
var n=i(18998),s=i(15317),a=i(11568),r=i(66008),l=i(10781),o=i(57258)
class _{static getAngle(e,t,i,n){const s=i-e,a=n-t,r=Math.sqrt(s*s+a*a)
if(0==r)return 0
const l=s/r
let o=Math.floor(Math.floor(180*Math.acos(l)/Math.PI))
return a<0&&(o=360-o),o}static distance(e,t,i,n){return Math.sqrt(_.distanceSQ(e,t,i,n))}static distanceSQ(e,t,i,n){const s=e-i,a=t-n
return s*s+a*a}static getFormatDir(e,t,i,n=!1){const s=e<0
e=Math.abs(e)
let a,r=0
return a=!(i<=0)&&(i>=4||_.fivePath[0].indexOf(t)>=0),n&&(a=!1),r=a?e<22.5?0:e<67.5?45:e<112.5?90:e<157.5?135:180:e<90?45:135,s&&(r*=-1),r}static getFormatDirByNum(e,t){const i=e<0
e=Math.abs(e)
let n=0
return n=2==t?e<90?45:135:3==t?e<45?0:e<=135?90:180:5==t?e<22.5?0:e<67.5?45:e<112.5?90:e<157.5?135:180:e<90?45:135,i&&(n*=-1),n}static getTargetAngle(e){if(isNaN(e))return 0
let t=e%360
return t=(t+360)%360,t>=180&&(t-=360),t}static _getFitTargetAngle(e){return e>0&&e<=7&&(e*=45),this.getTargetAngle(e)}static filterColor(e){let t=0
for(t=0;t<1;++t)(e.indexOf("[B]")>0||e.indexOf("[b]")>0)&&(e=(e=e.replace("[B]","<b>")).replace("[b]","<b>"),t--)
let i=0
for(i=0;i<1;++i)(e.indexOf("[/B]")>0||e.indexOf("[/b]")>0)&&(e=(e=e.replace("[/B]","</b>")).replace("[/b]","</b>"),i--)
let n=0
for(n=0;n<1;++n)e.indexOf("[-]")>0&&(e=e.replace("[-]","</color>"),n--)
const s=/\[.*?\]/
let a=e.match(s)
for(;null!=a;){const t=a[0].slice(1,a[0].length-1)
a=(e=e.replace(s,`<color=#${t}>`)).match(s)}return e}}_.fivePath=[["act03","act04","act103","act203"]]
var u=i(62265),h=i(36354),c=i(63715),d=i(89632),m=i(23407),p=i(75321),g=i(87923),I=i(33138),E=i(98130),C=i(93701)
const S=[]
class T extends n.Component{constructor(...e){super(...e),this._state=T.State_None,this._cfg=null,this._newCfg=null,this._baseDir=0,this._offsetDir=0,this._offset=0,
this._offsetRight=0,this._offsetY=0,this._scale=0,this._source=null,this._target=null,this._isFollow=!1,this._vmcView=null,this._layaView=null,this._sppeedRate=0,
this._beginPos=null,this._isGlobalPoint=!1,this._effTargetRole=null,this._floor=0,this._index=0,this._effParent=null,this._maxTime=0,this._displayTime=0,this._ignorePause=!1,
this._playTimes=0,this._isBuffEffect=-1,this._projectiveArr=[],this._uId=-1,this.m_onPlay=null,this.m_onDestroy=null,this.m_onAddRoot=null,this.m_key=null,this.m_personIds=null,
this.data=null,this._coverNode=!1,this._readydestory=!1,this._delayId=0}get cfg(){return this._cfg}Play(e,t,i,n,s,r,l,h,c,d,C,S,f,A=null,y=!1,R=-1,D=-1,w=1,L=!1,v=0,O=0){
if(this.data=t,100312201==e.id&&console.log("EffectShow100312201 p"),this._state!=T.State_None)return console.error(`EffectShow 播放时状态异常:${this._state} id:${e.id}`),
void this.Destroy()
if(1==e.onBody||R>=0){if(!s||1==s.curStatus||null!=s.Info_get&&!s.Info_get())return void this.Destroy()
if(e.ballType>0)return console.error(`直线弹道不能在特效绑定到角色上的情况下使用.id:${e.id}`),void this.Destroy()}if(!(e.ballType>1)||i&&i.Info_get()&&n&&n.Info_get()){
if(3!=e.ballType&&!s&&!f)return console.error(`特效指定pos 和特效持有者都不存在，找不到特效的起始坐标。。。 :${e.id}`),void this.Destroy()
if(100312201==e.id&&console.log("EffectShow100312201 s"),this._state=T.State_Play,this._uId=cus.currTime+Math.random(),this._cfg=e,this._offsetDir=l,this._baseDir=r,this._offset=h,
this._offsetRight=c,this._offsetY=d,this._isBuffEffect=R,this._isFollow=1==e.onBody,T.Global_Scale>0?this._scale=C*T.Global_Scale*w:this._scale=C*T.Global_Default_Scale*w,
this._source=i,this._target=n,this._ignorePause=y,this._sppeedRate=S*e.skillspeed/100,this._effParent=A,this._playTimes=D,this._effTargetRole=s,this._isGlobalPoint=L,this._floor=v,
this._index=O,f||(this._isGlobalPoint=!1),1==e.angleType)this._baseDir=0
else if((2==e.angleType||8==e.angleType)&&this._source&&this._source.Info_get&&this._source.Info_get()&&!this._source.IsDestroyed()&&this._target&&this._target.Info_get&&this._target.Info_get()&&!this._target.IsDestroyed()){
let[e,t]=(0,u.cH)(this._source.GetPos().x,this._source.GetPos().z),[i,n]=(0,u.cH)(this._target.GetPos().x,this._target.GetPos().z)
this._baseDir=_.getAngle(e,t,i,n)+90}if(3==this._cfg.ballType){let[e,t]=(0,u.cH)(this._target.GetPos().x,this._target.GetPos().z)
this._beginPos=f||new o.E(e,t)}else{let[e,t]=(0,u.cH)(this._effTargetRole.GetPos().x,this._effTargetRole.GetPos().z)
this._beginPos=f||new o.E(e,t)}if(this._cfg.weaponEffect){const t=this._source.Roleinfo_get().equipmentStorageVO
let i=null
const n=E.GF.INT(p.C.MAINWEAPON),s=g.l.getWearPosByPosition(n)
if(i=t.equipmentVOs.LuaDic_GetItem(s),i){const t=i.itemModelId
let n=I.f.Inst().getItemById(t).equipStepLv,s=e.weaponEffect[n]
this._newCfg=m.r.ins.getEffectShowCfg(s.toString(),!1)}}if(this.m_onPlay&&(this.m_onPlay.runWith([this]),this.m_onPlay=null),
this.data&&this.data.m_onPlay&&this.data.m_onPlay.runWith([this,O]),e.effect.indexOf&&e.effect.indexOf("ani")>=0)this.loadAnimationView()
else{const e=this.getVmcUrl(),t=a.n.createVMC(a.n.VMCType.SELF)
t.setPosition(0,0),this.node.addChild(t.node),this._vmcView=t,t.loadVMCData(e),t.vmcData?this._onloadVmcView(t.vmcData):t.node.once(a.n.DATA_COMPLETE,this._onloadVmcView,this)}
}else this.Destroy()}loadAnimationView(){}_onloadVmcView(e){if(!e)return void this.Destroy()
const t=this._vmcView
if(!t||t.vmcData!=e)return void console.error("error _onloadVmcView")
if(this._state!=T.State_Play)return void this.Destroy()
if((this._isFollow||this._isBuffEffect>=0)&&(!this._effTargetRole||1==this._effTargetRole.curStatus||null!=this._effTargetRole.Info_get&&!this._effTargetRole.Info_get()))return void this.Destroy()
if(!t.vmcData)return void this.Destroy()
let i
if(t.node.once(a.n.EVENT_VIEW_RECOVER,this.Destroy,this),t.resClearTime=3e4,t.playInterMultiple=this._sppeedRate,t.offsetY=.45,
i=this._newCfg?this._newCfg.offsetXY:this.cfg.offsetXY,i){let e=i.toString().split(",")
e[0]&&(t.baseOffsetX=Number(e[0].trim())),e[1]&&(t.baseOffsetY=Number(e[1].trim()))}this.node.opacity=255*(this._cfg.transparency>0?this._cfg.transparency:1)
const n=e.dirs
let s=""
n&&(-1!=n.indexOf(c.S.FRONT)?s=c.S.FRONT:-1!=n.indexOf(c.S.BACK)&&(s=c.S.BACK)),t.roleScale=this._scale,t.roleScaleY=this._scale,
this.data&&(1==this.data.mirrorType?t.roleScale*=-1:2==this.data.mirrorType&&(t.roleScaleY*=-1))
const r=this.checkDirAndAngle(e)
let o=0
o=1==this._cfg.direction?_.getFormatDir(r,"",4):2==this._cfg.direction?_.getFormatDirByNum(r,3):_.getFormatDir(r,"",0)
const u=Math.abs(o)
this._maxTime=this._cfg.time.val,this._maxTime=this._playTimes>0?this._playTimes:this._maxTime
let h=this._maxTime>0||-1==this._maxTime
1==this._cfg.endStop&&(h=!1),this.setVMcEffectLayer(s,r)
let d=!h
1==this._cfg.endStop&&(d=!1),e.hasDirName(`${u}`)||e.hasDirName(`front_${u}`)||e.hasDirName(`back_${u}`)?t.updatePose(e.url,o,h?0:1,d,!1,s):t.updatePose(e.url,90,h?0:1,d,!1,s)
const m=(90-r)*Math.PI/180
this.node.x+=Math.cos(m)*this._offset,2==this._cfg.angleType||8==this._cfg.angleType?this.node.y-=Math.sin(m)*this._offset+this._offsetY:this.node.y+=Math.sin(m)*this._offset+this._offsetY
const p=(90-r-90)*Math.PI/180
switch(this.node.x+=Math.cos(p)*this._offsetRight,this.node.y+=Math.sin(p)*this._offsetRight,this._vmcView.actCompleteCallBack=l.R.create(this,this.ActCompleteCallBack),
this._vmcView.stopCallBack=l.R.create(this,this.StopCallBack),this.m_onAddRoot&&(this.m_onAddRoot.runWith([this]),this.m_onAddRoot=null),
this.data&&this.data.m_onAddRoot&&this.data.m_onAddRoot.runWith([this,this._index]),this.smoothStart(),this.checkProjective(),this._displayTime=this._maxTime,this._cfg.ballType){
case 1:this.handleBallLine()
break
case 2:this.handleBallBack()
break
case 3:this.handleBackLine()
break
case 4:this.handleStraightLine(r)}100312201==this._cfg.id&&console.log("EffectShow100312201 :"+this._maxTime),
(h&&-1!=this._maxTime||!h&&this._maxTime>0)&&this.scheduleOnce(this.Destroy,this._displayTime/1e3)}setVMcEffectLayer(e,t){let i=0,n=0
if(0==this._isBuffEffect)i=0,n=-this._effTargetRole.firstCalHeight*this._vmcView.offsetY,
this.setEffectLayer(e,t,this._effTargetRole.GetFrontBody(),this._effTargetRole.GetBackBody())
else if(this._isFollow)this._vmcView.move(-this._vmcView.offsetX+this._effTargetRole.width/8,0),i=0,n=-this._effTargetRole.firstCalHeight*this._vmcView.offsetY,
this.setEffectLayer(e,t,this._effTargetRole.GetFrontBody(),this._effTargetRole.GetBackBody())
else{let a
this._vmcView.move(-this._vmcView.offsetX,0),i=this._beginPos.x,n=this._beginPos.y+(this._effTargetRole&&this._effTargetRole.firstCalHeight?this._effTargetRole.firstCalHeight:0)*this._vmcView.offsetY,
this._effParent?(this._coverNode=!0,a=this._effParent,this._effParent.addChild(this.node)):(this._coverNode=!0,d.N.ins._topLayer=r.n.gameStage.scene.getSceneLayer(s.W.Top),
d.N.ins._bottomLayer=r.n.gameStage.scene.getSceneLayer(s.W.Bottom),a=this.setEffectLayer(e,t,d.N.ins._topLayer,d.N.ins._bottomLayer)),this._isGlobalPoint}this.node.x=i,
this.node.y=n}setEffectLayer(e,t,i,n){let s
return 1==this._cfg.layer?s=i:2==this._cfg.layer?n&&(s=n):s=3==this._cfg.layer?Math.abs(t)<90?n:i:e==c.S.BACK?n:e==c.S.FRONT?i:Math.abs(t)<90?n:i,
null==this.node.parent&&s?s.addChild(this.node):s!=this.node.parent&&s&&(this.node.removeFromParent(),s.addChild(this.node)),this.node.setPosition(0,0),s}checkDirAndAngle(e=null){
let t=0
if(8==this._cfg.angleType){let e
if(this._baseDir=_.getTargetAngle(this._baseDir),this._baseDir<0&&this._baseDir>=-180){this.node.setScale(-1,1,1)
const t=Math.abs(this._baseDir)
e=t<45?t-0:t<=135?t-90:t-180,this.node.angle=-e,e=Math.abs(this._baseDir)}else this.node.setScale(1,1,1),
e=this._baseDir<45?this._baseDir-0:this._baseDir<=135?this._baseDir-90:this._baseDir-180,this.node.angle=-e,e=this._baseDir
t=e}else if(7==this._cfg.angleType)this.node.setScale(-1,1,1),this.node.angle=0,t=this._baseDir+this._offsetDir
else if(6==this._cfg.angleType)this.node.angle=0,t=this._offsetDir
else if(5==this._cfg.angleType)this.node.setScale(1,1,1),t=this._baseDir+this._offsetDir,this.node.angle=-(t-90)
else if(3==this._cfg.angleType){let e
this._baseDir=_.getTargetAngle(this._baseDir),this._baseDir<0&&this._baseDir>=-180?(this.node.setScale(-1,1,1),e=this._baseDir-this._offsetDir,
this.node.angle=-(e-180-90)):(this.node.setScale(1,1,1),e=this._baseDir+this._offsetDir,this.node.angle=-(e-90)),t=e
}else 4==this._cfg.angleType||e&&e.rotate360||this._vmcView&&this._vmcView.vmcData&&this._vmcView.vmcData.rotate360||2==this._cfg.angleType?(this.node.angle=this._baseDir-90,
t=this._baseDir+this._offsetDir):(this._cfg.angleType,this.node.angle=0,t=this._baseDir+this._offsetDir)
if(1==this._cfg.perspective&&(2==this._cfg.angleType||5==this._cfg.angleType||4==this._cfg.angleType||e&&e.rotate360||this._vmcView&&this._vmcView.vmcData&&this._vmcView.vmcData.rotate360)){
let e=-this.node.angle
e+=90,e>180&&(e-=360),e=e>90?90-90*Math.sin((90-(e-90))*Math.PI/180)+90:e<-90?-90-90*Math.sin((-90+(e+90))*Math.PI/180)-90:90*Math.sin(e*Math.PI/180),e-=90,this.node.angle=-e
let i=1
const n=T.minRadius*Math.sin(e*Math.PI/180),s=T.maxRadius*Math.cos(e*Math.PI/180)
i=Math.sqrt(n*n+s*s)
let a=1
a=T.perspectivebegin+Math.sin(e*Math.PI/180)*T.perspectiveoffset,this._vmcView&&(this._vmcView.roleScale=this._vmcView.roleScale*a*i),this._layaView&&(this._layaView.scaleX=a*i),
t=e+90}return t=_.getTargetAngle(t),t}static createEffectShow(){if(S.length){const e=S.pop()
return e._state!=T.State_Recovered&&console.error("error createEffectShow"),e._state=T.State_None,e}return n.Node.createUINode("EffectShow").addComponent(T)}ActCompleteCallBack(){
1!=this._cfg.endStop&&this.Destroy()}StopCallBack(){1!=this._cfg.endStop&&this.Destroy()}CanRecover(){
return this._state!=T.State_Play&&this._state!=T.State_Recovered&&!(S.length>30)}Recover(){this._state=T.State_Recovered,S.push(this)}ClearVmc(){if(this._vmcView){
let e=this._vmcView
this._vmcView=null,e.node.off(a.n.DATA_COMPLETE,this._onloadVmcView,this),e.node.off(a.n.EVENT_VIEW_RECOVER,this.Destroy,this),e.recover()}}ClearLayaView(){
this._layaView&&(this._layaView.filters&&this._layaView.filters.length>0&&(this._layaView.filters=[]),this._layaView.off(a.n.EVENT_VIEW_RECOVER,this,this.Destroy),
this._layaView.recover(),this._layaView=null)}ClearData(){this.m_key=-1,this.m_personIds="",this._ignorePause=!1,this._state=T.State_None,this._cfg=null,this._newCfg=null,
this._baseDir=0,this._offsetDir=0,this._offset=0,this._offsetRight=0,this._offsetY=0,this._scale=1,this.m_onPlay=null,this.m_onDestroy=null,this.m_onAddRoot=null,this._source=null,
this._effTargetRole=null,this._isBuffEffect=-1,this._target=null,this._isFollow=!1,this._vmcView=null,this._layaView=null,this._sppeedRate=0,this._beginPos=null,
this._isGlobalPoint=!1,this._effTargetRole=null,this._effParent=null,this._maxTime=0,this._displayTime=0,this._floor=-1,this._index=-1,this.data=null,this._coverNode=!1}Destroy(){
if(this.unschedule(this.Destroy),!this._readydestory)if(this._delayId>0&&(C.a.ins.clearTimer(this._delayId),this._delayId=0),this._state!=T.State_Recovered){this._readydestory=!0,
this.ClearVmc(),this._state!=T.State_Play&&(this._readydestory=!1,console.log("EffectShowErre 销毁异常")),this._state=T.State_Over,this.ClearLayaView()
var e=this.CanRecover()
this.node.parent&&this.node.parent.removeChild(this.node),this.data&&this.data.m_onDestroy&&this.data.m_onDestroy.runWith([this,this._index]),
this.m_onDestroy&&(this.m_onDestroy.runWith([this]),this.m_onDestroy=null),this.ClearData(),e?this.Recover():this.node=null,this._readydestory=!1
}else console.trace("EffectShowErre 已经在对象池里")}handleBallLine(){if(this._isBuffEffect>=0)return void console.error(`buff特效不能为直线弹道.id:${this._cfg.id}`)
if(this._isFollow)return void console.error(`直线弹道不能再特效绑定到角色上的情况下使用.id:${this._cfg.id}`)
const e=this._cfg.ballParams.split(","),t=e.length>0?parseInt(e[0],10):0
let i=e.length>1?parseInt(e[1],10):0
const s=!(e.length>2)||"1"!=e[2]
e.length>3&&Number(e[3]),e.length>4&&Number(e[4])
if(!t||!i)return void console.error(`EffectShow 直线弹道参数配置错误 id:${this._cfg.id}`)
let a=0,r=0
if(s&&this._target&&this._target.Info_get()){let[e,t]=(0,u.cH)(this._target.GetPos().x,this._target.GetPos().z)
a=e,r=t+this._target.firstCalHeight*(this._vmcView?this._vmcView.offsetY:0),i=_.distance(this.node.x,this.node.y,a,r)}else{if(!this._target||!this._target.Info_get())return
{let[e,t]=(0,u.cH)(this._target.GetPos().x,this._target.GetPos().z)
a=e,r=t+this._target.firstCalHeight*(this._vmcView?this._vmcView.offsetY:0)}}let l=i/t*1e3
const o=(_.getAngle(this.node.x,this.node.y,a,r)+90)%360*Math.PI/180,h=Math.sin(o)*i,c=Math.cos(o)*i,d=this.node.x+h,m=this.node.y-c;(0,n.tween)(this.node).to(l/1e3,{x:d,y:m
}).start(),this._displayTime=l}handleBallBack(){}onFinishBallBackFly(e,t){}onFinishBallBackStop(e){}handleBackLine(){
if(this._isBuffEffect>=0)return void console.error(`buff特效不能为返回弹道.id:${this._cfg.id}`)
if(this._isFollow)return void console.error(`返回弹道不能再特效绑定到角色上的情况下使用id:${this._cfg.id}`)
const e=this._cfg.ballParams.split(","),t=e.length>0?parseInt(e[0],10):0
if(!t)return void console.error(`EffectShow 返回弹道参数配置错误 id:${this._cfg.id}`)
const i=this._beginPos.x,s=this._beginPos.y+this._target.firstCalHeight*(this._vmcView?this._vmcView.offsetY:0)
this.node.x=i,this.node.y=s
const a=this._source.pos2.x,r=this._source.pos2.y+this._source.firstCalHeight*(this._vmcView?this._vmcView.offsetY:0)
this._baseDir=(_.getAngle(this.node.x,this.node.y,a,r)+90)%360
const l=this.checkDirAndAngle()
let o=0
o=1==this._cfg.direction?_.getFormatDir(l,"",4):2==this._cfg.direction?_.getFormatDirByNum(l,3):_.getFormatDir(l,"",0)
Math.abs(o)
this._maxTime=this._cfg.time.val,this._maxTime=this._playTimes>0?this._playTimes:this._maxTime
this._maxTime
const u=this._vmcView?this._vmcView.vmcData:null,h=u?u.dirs:null
let d=""
h&&-1!=h.indexOf(c.S.FRONT)?d=c.S.FRONT:h&&-1!=h.indexOf(c.S.BACK)&&(d=c.S.BACK)
const m=(_.getAngle(this.node.x,this.node.y,a,r)+90)%360,p=_.distance(this.node.x,this.node.y,a,r),g=m*Math.PI/180,I=Math.sin(g)*p,E=Math.cos(g)*p,C=this.node.x+I,S=this.node.y-E,T=p/t*1e3
;(0,n.tween)(this.node).to(T/1e3,{x:C,y:S}).start()}handleStraightLine(e){if(this._isBuffEffect>=0)return void console.error(`buff特效不能为直线弹道.id:${this._cfg.id}`)
if(this._isFollow)return void console.error(`直线弹道不能再特效绑定到角色上的情况下使用.id:${this._cfg.id}`)
const t=this._cfg.ballParams.split(","),i=t.length>0?parseInt(t[0],10):0,s=t.length>1?parseInt(t[1],10):0
if(!i||!s)return void console.error(`EffectShow 直线弹道参数配置错误 id:${this._cfg.id}`)
let a=i*s/1e3
const r=(e=90-e)*Math.PI/180,l=Math.cos(r)*a,o=Math.sin(r)*a,_=this.node.x+l,u=this.node.y+o;(0,n.tween)(this.node).to(s/1e3,{x:_,y:u}).start(),this._displayTime=s}smoothEnd(){}
smoothStart(){}initEffect(){}checkProjective(){}projective(e=.8,t=.2,i=300){}removeBt(e){}resetRootPos(e,t){}getVmcUrl(){let e
if(this._cfg.layoutGroup>0&&this._floor>0&&this._cfg.layoutEffect){const t=this._cfg.layoutEffect
e=`${c.S.SKILL_PATH+t+(this._floor<10?`0${this._floor}`:this._floor)}.json`
}else if(this._cfg.mulEffDelayArr&&this._cfg.mulEffDelayArr.length>0&&this._index>0)e=`${c.S.SKILL_PATH+this._cfg.effect+this._index}.json`
else{let t
this._newCfg&&(t=this._newCfg.effect),t||(t=this._cfg.effect),e=`${c.S.SKILL_PATH+t}.json`}return h.k.changeSkillPath(e)}getLayaUrl(){let e
if(this._cfg.layoutGroup>0&&this._floor>0&&this._cfg.layoutEffect){const t=this._cfg.layoutEffect
e=c.S.X5_LAYAFX+t+(this._floor<10?`0${this._floor}`:this._floor)+this._cfg.effect.substring(this._cfg.effect.lastIndexOf("."))}else e=c.S.X5_LAYAFX+this._cfg.effect
return e}}T.State_None=0,T.State_Play=1,T.State_Over=2,T.State_Recovered=3,T.Global_Scale=0,T.Global_Default_Scale=1,T.maxRadius=1.2,T.minRadius=.9,T.perspectivebegin=1,
T.perspectiveoffset=.5,T.s_testSkillColor=!1,T.s_speedRate=65},76791:(e,t,i)=>{"use strict"
i.d(t,{v:()=>a})
var n=i(50107),s=i(71409)
class a{static test(e){return(this._flag&e)==e}static update(e,t=!1){const i=this._flag|e
return i!=this._flag&&(this._flag=i,t||this._delayCount>0?(this._delayCount+=1,cus.scheduleOnce(0,(()=>{this._delayCount-=1,(0,s.bG)(n.C.LOGIN_FLAG_UPDATE,e)}))):(0,
s.bG)(n.C.LOGIN_FLAG_UPDATE,e),!0)}static isLoadingComplete(){return this.test(this.Flag.LOADING_START|this.Flag.LOADING_COMPLETE)}}a.Flag={LOADING_START:1,LOADING_COMPLETE:2,
PLAYER_CREATED:4,PLAYER_INFO:8,PREV_ENTER_SCENE:16,NEXT_ENTER_SCENE:32},a._flag=0,a._delayCount=0},81224:(e,t,i)=>{"use strict"
i.d(t,{Qk:()=>n})
i(22267),i(39407),i(17409)
const n={None:"None",Ok:"Ok",Cancel:"Cancel",CancelOk:"CancelOk",OkCancel:"OkCancel"}},99942:(e,t,i)=>{"use strict"
i.d(t,{a:()=>n})
const n=(0,i(42292).O$)("app/AutoUpdatePosition")},84501:(e,t,i)=>{"use strict"
i.d(t,{X:()=>a})
var n=i(42292),s=i(71409)
const a=(0,n.O$)("app/BinderComponent")
a.__addObserver=s.BE,a.__removeObserver=s.XC},30438:(e,t,i)=>{"use strict"
i.d(t,{i:()=>n})
const n=(0,i(42292).O$)("app/FlowSprite")},38844:(e,t,i)=>{"use strict"
i.d(t,{E:()=>n})
const n=(0,i(42292).O$)("app/Image")},73851:(e,t,i)=>{"use strict"
i.d(t,{G:()=>n})
const n=(0,i(42292).O$)("app/MButton")},13060:(e,t,i)=>{"use strict"
i.d(t,{N:()=>n})
const n=(0,i(42292).O$)("app/MyUIButton")},60960:(e,t,i)=>{"use strict"
i.d(t,{T:()=>n})
const n=(0,i(42292).O$)("app/MyUIGridItem")},83543:(e,t,i)=>{"use strict"
i.d(t,{D:()=>n})
const n=(0,i(42292).O$)("app/MyUIScrollBar")},11294:(e,t,i)=>{"use strict"
i.d(t,{E:()=>n})
const n=(0,i(42292).O$)("app/MyUIScrollView")},44434:(e,t,i)=>{"use strict"
i.d(t,{m:()=>n})
const n=(0,i(42292).O$)("app/PrefabBinder")},13235:(e,t,i)=>{"use strict"
i.d(t,{h:()=>n})
const n=(0,i(42292).O$)("app/TweenAlpha")},73790:(e,t,i)=>{"use strict"
i.d(t,{a:()=>n})
const n=(0,i(42292).O$)("app/TweenPosition")},80156:(e,t,i)=>{"use strict"
i.d(t,{E:()=>n})
const n=(0,i(42292).O$)("app/TweenScale")},47681:(e,t,i)=>{"use strict"
i.d(t,{s:()=>n})
const n=(0,i(42292).O$)("app/UIAvatar")},82589:(e,t,i)=>{"use strict"
i.d(t,{J:()=>n})
const n=(0,i(42292).O$)("app/UIEffect")},9842:(e,t,i)=>{"use strict"
i.d(t,{T:()=>n})
const n=(0,i(42292).O$)("app/UISlider")},86871:(e,t,i)=>{"use strict"
i.d(t,{I:()=>n})
const n=__$LaunchLogicBridge._initBinderObject},3110:(e,t,i)=>{"use strict"
i.d(t,{v:()=>n})
const n=__$LaunchLogicBridge._assignBinder},11356:(e,t,i)=>{"use strict"
i.d(t,{y:()=>l})
var n=i(18998),s=i(17409),a=i(49655),r=i(27564)
class l{static setup(){n.input.on(n.Input.EventType.KEY_DOWN,this.onKeyDownOrUp,this),n.input.on(n.Input.EventType.KEY_UP,this.onKeyDownOrUp,this)}static onKeyDownOrUp(e){
const t=e.type==n.Input.EventType.KEY_DOWN
switch(e.keyCode){case n.KeyCode.CTRL_LEFT:case n.KeyCode.CTRL_RIGHT:this.ctrl=t
break
case n.KeyCode.ALT_LEFT:case n.KeyCode.ALT_RIGHT:this.alt=t
break
case n.KeyCode.SHIFT_LEFT:case n.KeyCode.SHIFT_RIGHT:this.shift=t
break
case n.KeyCode.HOME:(0,s.Yp)(a.o.GmView)
break
case n.KeyCode.INSERT:(0,s.Yp)(a.o.EffectShowEditor)
break
case n.KeyCode.END:(0,s.sR)(a.o.GmView)
break
case n.KeyCode.PAGE_UP:r.z.Inst().OpenGMMiniPanel()
break
case n.KeyCode.PAGE_DOWN:r.z.Inst().CloseGMMiniPanel()}}}l.ctrl=!1,l.alt=!1,l.shift=!1},44132:(e,t,i)=>{"use strict"
i.d(t,{D:()=>s})
var n=i(47465)
class s{CreateDelegate(e){return(0,n.r)(e,this)}}},8125:(e,t,i)=>{"use strict"
i.d(t,{T:()=>h})
var n=i(18998),s=i(49609),a=i(66008),r=i(16286),l=i(99942)
const o=new n.Vec2,_=[]
let u=!1
class h{static setup(){const e=new n.Node("CANVAS_NODE")
e.addComponent(n.UITransform).setContentSize(5e3,5e3),this._uiNode=e,u=launcher._testFlag(1)
n.director.getScene().getChildByName("UICanvas").addChild(e),e.on(n.NodeEventType.TOUCH_END,this.onTouchEnd,this),e.on(n.NodeEventType.TOUCH_START,this.onTouch,this),
e.on(n.NodeEventType.TOUCH_MOVE,this.onTouchMove,this),e.on(n.NodeEventType.TOUCH_CANCEL,this.onTouch,this),e.on(n.NodeEventType.MOUSE_MOVE,this.onMouseMove,this),
n.game.on(n.Game.EVENT_HIDE,this._onGameHide,this)}static openTip(){if(!this._tipLabel){const e=n.Node.createUINode("UI_TIP")
e.transform.setAnchorPoint(0,1)
const t=e.addComponent(n.Label)
t.horizontalAlign=n.Label.HorizontalAlign.LEFT,t.verticalAlign=n.Label.VerticalAlign.TOP,t.fontSize=18,t.lineHeight=t.fontSize+1,this._tipLabel=t,this._uiNode.addChild(e),
e.addComponent(n.LabelOutline)}this._tipLabel.node.active=!0,this._renderTip()}static closeTip(){this._tipLabel&&(this._tipLabel.node.active=!1)}static _renderTip(){
const e=this._tipLabel
if(!e||!e.node.active)return
const t=n.view.getVisibleSize()
e.node.setPosition(this.touchLocation.x-t.width/2,this.touchLocation.y-t.height/2-30),
a.n.gameStage.sceneCamera.convertScreenPosTo2DWorldPos(o.set(this.touchLocation.x,this.touchLocation.y),o)
const i=Math.round(o.x),s=Math.round(o.y);(0,r.C8)(i,s,o)
const l=o.x,u=o.y
_.length=0,a.n.mapTiles.canPass(l,u,!1)||_.push("阻挡"),a.n.mapTiles.isAlpha(l,u,!1)&&_.push("半透"),a.n.mapTiles.isSafe(l,u,!1)&&_.push("安全区"),404==l&&117==u&&console.log(11)
const h=a.n.mapTiles.getAreaId(l,u)
h>0&&_.push(`区域${h}`)
const c=_.length?_.join(","):""
_.length=0,_.push(`tile  ${l},${u}`),_.push(`unity ${i/100},${s/100}`),c&&_.push(c),e.string=_.join("\n"),_.length=0}static addTouchMove(e,t,i){const n=this._listenTouchMoves
for(let s=0;s<n.length;s++){const a=n[s]
if(e==a.method&&t==a.thisArg)return void(a.touchendMethod=i)}n.push({method:e,thisArg:t,touchendMethod:i})}static removeTouchMove(e,t){const i=this._listenTouchMoves
for(let n=i.length-1;n>=0;n--){const s=i[n]
if(e==s.method&&t==s.thisArg){i.splice(n,1)
break}}}static onTouch(e){e.preventSwallow=!u||!s.t.ins.isAutoGm,e.getLocation(this.touchLocation),this._renderTip()}static onTouchMove(e){e.preventSwallow=!u||!s.t.ins.isAutoGm,
e.getLocation(this.touchLocation)
const t=this._listenTouchMoves
for(let i=0;i<t.length;i++){const n=t[i]
n.method.call(n.thisArg,e)}this._renderTip()}static onMouseMove(e){e.preventSwallow=!u||!s.t.ins.isAutoGm,e.getLocation(this.touchLocation),this._renderTip()}static onTouchEnd(e){
e.preventSwallow=!u||!s.t.ins.isAutoGm,e.getLocation(this.touchLocation),this._clearTouchMove(e)}static _onGameHide(){this._clearTouchMove(null)}static _clearTouchMove(e){
const t=this._listenTouchMoves
for(let i=t.length-1;i>=0;i--){const n=t[i]
n.touchendMethod&&n.touchendMethod.call(n.thisArg,e)}t.length=0}static GetMousePosition(){let e=new n.Vec3
return this.isSetUp||this.setup(),e.x=this.touchLocation.x,e.y=this.touchLocation.y,e.z=0,e}static WorldToLocalMatrixMultiplyPoint3x4(e,t){
return e.transform.convertToNodeSpaceAR(t)}static SetGuideAutoPositionState(e,t,i=!1){let n=e.getComponent(l.a)
null!=n&&(n.IsWorld=!1,n.Target=null,i&&(e.worldPosition=t.worldPosition,i&&(n.IsWorld=!0,n.Target=t)))}static GetRelateMousePoint(e){let t=h.touchLocation
return e.parent.transform.convertToNodeSpaceAR(new n.Vec3(t.x,t.y,0))}static AngleOffset(e,t,i,n){return 0}}h.touchLocation=new n.Vec2,h.targetNode=null,h.mouseMoveX=0,
h.handler=null,h.lastTime=0,h.isSetUp=!1,h._uiNode=void 0,h._tipLabel=null,h._listenTouchMoves=[]},47465:(e,t,i)=>{"use strict"
i.d(t,{r:()=>n})
const n=__$LaunchLogicBridge._CreateDelegate}}])
