"use strict";(globalThis.webpackChunkProject=globalThis.webpackChunkProject||[]).push([[489],{64269:(t,e,s)=>{s.d(e,{F:()=>I})
var i,n=s(6847),l=s(83908),o=s(49655),a=s(46282),r=s(18202),h=s(31222),d=s(5494)
class c{constructor(){this.testPanel=null}OpenPanel(){}ShowHandler(t){return null==this.testPanel&&(this.testPanel=new I,this.testPanel.setId(t,null,0)),this.testPanel}
DestroyHandler(){r.g.DestroyUIObj(this.testPanel),this.testPanel=null}Close(){h.N.inst.CloseById(d.I.eTestPanel)}}c.inst=null
let I=(0,n.s_)(o.o.TestPanel,a.Z.Test).register()(i=class extends((0,l.Ri)()){InitView(){this.skillList.ResetPosition()}OnAddToScene(){}CloseHandler(t,e){c.inst.Close()}})||i},
12399:(t,e,s)=>{s.d(e,{f:()=>y})
var i=s(38836),n=s(98800),l=s(68662),o=s(85602),a=s(38962),r=s(63076),h=s(48933),d=s(20364),c=s(64649),I=s(37648),u=s(55492),p=s(33138),_=s(54918),g=s(8828),m=s(36713)
class S{constructor(){this.element=null,this.rInfo=null,this.scoreUp=0,this.tipType=m.q.GetElementTip}Test1(){return!0}S_Test(){return!0}}var f=s(2933),C=s(28963),T=s(47041)
class y{constructor(){this.scoreDic=null,this.scoreDic=new a.X}static Inst(){return null==y.inst&&(y.inst=new y),y.inst}IsCanShow(t){for(const[e,s]of(0,
i.V5)(n.Y.Inst.primaryRoleInfoList))if(d.D.IsWearForRole(s,t,!1)&&d.D.IsWearJob(s.Job_get(),t.cfgData_get().Jobs_get()))return!0
return!1}GetDataCanUpInAllPlayer(t,e,s){let i=!1
this.IsHasElementInQueue(t)&&(i=!0)
const l=p.f.Inst().getItemById(t.modelId),a=n.Y.Inst.GetMultPlayerInfos(),h=new o.Z
for(let n=0;n<=a.Count()-1;n++){const o=a[n]
if(d.D.IsWearJob(o.Job_get(),l.Jobs_get())&&(null==s||!s.Contains(o.createIdx))){const s=new r.M(t.modelId,t),n=d.D.GetUpScoreForRole(o,s)
if(n>0){let s=!1
const l=new S
l.rInfo=o,l.scoreUp=n
const a=this.IsWearOrCheckTip(o,t)
a==y.WearState?(l.tipSubType=C.p.SubEquipTips,l.priority=f.$.GetElementTip):a==y.CheckState&&(e||i?(l.tipSubType=C.p.SubViewEquipTips,l.priority=f.$.GetElementTip):s=!0),
s||(l.element=t,h.Add(l))}}}return h.Sort(this.CreateDelegate(this.SortUpScore)),h}IsCanJudgeItem(t){return!_.Q.Inst_get().IsSpecialTaskItem(t)&&!this.IsDeprecated1(t)}
IsHasElementInQueue(t){const e=g.N.Inst_get().GetDataByTipsType(m.q.GetElementTip)
for(let s=0;s<=e.Count()-1;s++){const i=e[s]
if(null!=i){if(i.element.Id_get().Equal(t.Id_get()))return g.N.Inst_get().RemoveData(i),!0}}}GetShowElementTipData(t,e,s){
if(!I.P.Inst_get().IsFunctionOpened(u.x.ELEMENT_ITEM))return null
if(!this.IsCanJudgeItem(t))return null
const i=this.GetDataCanUpInAllPlayer(t,e,s)
if(0==i.count)return null
let n=0
for(;n<i.count;){const[t,e]=this.IsEnQueue(i[n])
if(null!=t)return T.N.Inst_get().GetElementEnQueue(t),null!=e&&n<i.count-1&&(null==s&&(s=new o.Z),s.Add(e.rInfo.createIdx),T.N.Inst_get().ShowGetTip(e.element,!0,s)),t
n+=1}return!1}GetElementTipsData(){const t=m.q.GetElementTip
let e=C.p.SubEquipTips,s=g.N.Inst_get().GetDataByTipsType(t,e)
if(null!=s){if(s.Count()>0)return s
if(e=C.p.SubViewEquipTips,s=g.N.Inst_get().GetDataByTipsType(t,e),null!=s&&s.Count()>0)return s}return new o.Z}SortUpScore(t,e){if(e.tipSubType==t.tipSubType){
const s=t.element.GetScore(),i=e.element.GetScore()
if(s==i){return t.rInfo.createIdx-e.rInfo.createIdx}if(s-i>0)return 1
if(s-i<0)return-1}return t.tipSubType==C.p.SubEquipTips?1:0}IsCanInsertData(t,e){const s=t.modelId,i=p.f.Inst().getItemById(s)
return!!d.D.IsWearJob(e.Job_get(),i.Jobs_get())}IsDeprecated1(t){if(null==t.deprecatedTime||t.deprecatedTime.Equal(h.I.zeroLong))return!1
return t.deprecatedTime.ToNum()/1e3-l.D.serverTime_get()<3}IsWearOrCheckTip(t,e){const s=e,i=new r.M(s.modelId,s)
return d.D.IsTakeOnLevel(t.Level_get(),i.cfgData_get().level,!1)?y.WearState:y.CheckState}IsEnQueue(t){const e=t.rInfo,s=t.element,i=c.$.Inst().GetElementResById(s.modelId)
let n=null,l=0
const h=new o.Z
let d=0,I=null,u=null
const p=new a.X,_=this.GetEquipTipsDataById(t.tipType,t.tipSubType,e.Id_get())
for(;d<_.Count();){n=_[d]
if(c.$.Inst().GetElementResById(n.element.modelId).elementType==i.elementType){const t=new r.M(n.element.modelId,n.element)
h.Add(t),p.LuaDic_AddOrSetItem(n.element.id.ToNum(),d)}d+=1}this.SortBaseItemLis(h)
const m=h.Count(),S=new r.M(s.modelId,s)
I=t
let f=0
null!=e.GetElement(i.elementType)&&(f=1)
let C=0
if(c.$.Inst().GetTypeIsActive(i.elementType,e)&&(C=1),m+f<C||0==m)this.AddQueue1(I)
else{const t=this.GetCompareState(e,S,h,i.elementType)
if(0==t)this.AddQueue1(I)
else{if(1!=t)return null
l=p[h[0].serverData_get().Id_get().ToNum()],u=_[l],g.N.Inst_get().RemoveData(u),this.AddQueue1(I)}}return[I,u]}GetCompareState(t,e,s,n){const l=new o.Z
l.Add(e)
for(const[t,e]of(0,i.V5)(s))l.Add(e)
const a=t.GetElementItemHold(n)
if(null!=a&&null!=a.element){const t=new r.M(a.element.modelId,a.element)
l.Add(t)}this.SortBaseItemLis(l)
let h=!1,d=!1
let c=l.Count()-1-1
for(;c>=0;)s.IndexOf(l[c],0)>=0&&(h=!0),e==l[c]&&(d=!0),r.M.Recycle(l[c].baseData),c-=1
return h?1:d?2:0}AddQueue1(t){let e=0
const s=t.scoreUp,i=this.GetEquipTipsDataById(t.tipType,t.tipSubType)
let n=!1
for(let t=0;t<=i.Count()-1;t++){if(e=t,!(s>i[t].scoreUp)){n=!1
break}n=!0}0==i.Count()||n?g.N.Inst_get().AddData(t):i.Insert(e,t)}GetPosEquipedNum(t,e){let s=0
return null!=e.GetElement(t.elementType)&&(s+=1),s}SortBaseItemLis(t){let e=null,s=0
for(;s<t.Count()-1;){let i=s+1
for(;i<t.Count();){c.$.Inst().GetElementResById(t[s].modelId_get()).score>c.$.Inst().GetElementResById(t[i].modelId_get()).score&&(e=t[s],t[s]=t[i],t[i]=e),i+=1}s+=1}}
GetEquipTipsDataById(t,e,s){const i=g.N.Inst_get().GetDataByTipsType(t,e),n=new o.Z
for(let t=0;t<=i.Count()-1;t++){const e=i[t]
if(null!=e&&null!=e.rInfo){if(null==s)return i
s.Equal(e.rInfo.Id_get())&&n.Add(e)}}return n}}y.inst=null,y.WearState=1,y.CheckState=2},5633:(t,e,s)=>{s.d(e,{F:()=>M})
var i=s(32076),n=s(38836),l=s(98800),o=s(68662),a=s(85602),r=s(38962),h=s(63076),d=s(75363),c=s(59918),I=s(76645),u=s(23628),p=s(71143),_=s(87923),g=s(44498),m=s(48933),S=s(42534),f=s(33138),C=s(54918),T=s(8828),y=s(20531),A=s(36713)
class v extends y.R{constructor(...t){super(...t),this.equip=null,this.rInfo=null,this.columnPos=0,this.scoreUp=0,this.tipType=A.q.GetEquipTip}}var D=s(2933),w=s(28963),B=s(47041)
class M{static Inst(){return null==M.inst&&(M.inst=new M),M.inst}IsCanShow(t){for(const[e,s]of(0,
n.V5)(l.Y.Inst.primaryRoleInfoList))if(u.b.IsWearForRole(s,t,!1)&&u.b.IsTakeOnJob(s.Job_get(),t.cfgData_get().Jobs_get()))return!0
return!1}GetDataCanUpInAllPlayer(t,e,s){let o=!1
this.IsHasEquipInQueue(t)&&(o=!0)
const r=f.f.Inst().getItemById(t.modelId),d=l.Y.Inst.GetMultPlayerInfos(),c=new a.Z
for(let i=0;i<=d.Count()-1;i++){const l=d[i]
if(p.i.IsTakeOnPro(l.Job_get(),r.Jobs_get(),!1)&&(null==s||!s.Contains(l.createIdx))){const s=new h.M(t.modelId,t),i=u.b.GetUpPosScoreDictForRole(l,s)
for(const[s,a]of(0,n.vy)(i))if(a>0&&this.IsCanInsertData(t,l)){let i=!1
const n=new v
n.rInfo=l,n.scoreUp=a,n.columnPos=Math.floor(s/100),this.IsWearOrCheckTip(l,t)==M.WearState?(n.tipSubType=w.p.SubEquipTips,
n.priority=D.$.GetEquipTip):this.IsWearOrCheckTip(l,t)==M.CheckState&&(e||o?(n.tipSubType=w.p.SubViewEquipTips,n.priority=D.$.ViewEquipTip):i=!0),i||(n.equip=t,c.Add(n))}}}
return c.Sort((0,i.v)(this.SortUpScore,this)),c}IsCanJudgeItem(t){return!C.Q.Inst_get().IsSpecialTaskItem(t)&&!this.IsDeprecated1(t)}IsHasEquipInQueue(t){
const e=T.N.Inst_get().GetDataByTipsType(A.q.GetEquipTip)
for(let s=0;s<=e.Count()-1;s++){const i=e[s]
if(null!=i){if(i.equip.Id_get().Equal(t.Id_get()))return T.N.Inst_get().RemoveData(i),!0}}}GetShowEquipTipData(t,e,s){if(!this.IsCanJudgeItem(t))return null
const i=this.GetDataCanUpInAllPlayer(t,e,s)
if(0==i.count)return null
let n=0
for(;n<i.count;){const[t,e]=this.IsEnQueue(i[n])
if(null!=t)return B.N.Inst_get().GetEquipEnQueue(t),null!=e&&n<i.count-1&&(null==s&&(s=new a.Z),s.Add(e.rInfo.createIdx),B.N.Inst_get().ShowGetTip(e.equip,!0,s)),t
n+=1}return!1}SortUpScore(t,e){if(e.tipSubType==t.tipSubType){
const s=new h.M(t.equip.GetItemRes().id,t.equip),i=new h.M(e.equip.GetItemRes().id,e.equip),n=g.I.Score(s,t.rInfo.Job_get()),l=g.I.Score(i,e.rInfo.Job_get())
if(n==l){return t.rInfo.createIdx-e.rInfo.createIdx}return n-l}return t.tipSubType==w.p.SubEquipTips?1:-1}IsCanInsertData(t,e){const s=t.modelId,i=f.f.Inst().getItemById(s)
return!!p.i.IsTakeOnPro(e.Job_get(),i.Jobs_get(),!1)}IsDeprecated1(t){if(null==t.deprecatedTime||t.deprecatedTime.Equal(m.I.zeroLong))return!1
return t.deprecatedTime.ToNum()/1e3-o.D.serverTime_get()<3}IsEquipPosOpen(t,e){
const s=e,i=_.l.getWearPosByPosition(s.GetEquipRes().intPosition_get()),n=s.GetEquipRes().equipColumnsList_get()
let l=0
for(;l<n.Count();){if(d.Y.Inst_get().IsEquipPosUnlock(n[l],i,t))return!0
l+=1}return!1}IsWearOrCheckTip(t,e){const s=e,i=new h.M(s.modelId,s)
return p.i.IsAttrCanTakeOnTips(t,i,!1,!1,!0,!1)&&I.t.Inst_get().IsReachUseLevel(s.modelId)?M.WearState:M.CheckState}IsEnQueue(t){
const e=t.rInfo,s=t.equip,i=S.f.Inst().getItemById(s.modelId)
let n=null,l=0
const o=new a.Z
let d=0,c=null,I=null
const u=new r.X,p=this.GetEquipTipsDataById(t.tipType,t.tipSubType,e.Id_get(),t.columnPos)
for(;d<p.Count();){n=p[d]
const t=S.f.Inst().getItemById(n.equip.modelId).intPosition_get(),e=S.f.Inst().getItemById(n.equip.modelId).equipColumnsList_get()
if(t==i.intPosition_get()&&e[0]==i.equipColumnsList_get()[0]){const t=new h.M(n.equip.modelId,n.equip)
o.Add(t),u.LuaDic_AddOrSetItem(n.equip.id.ToNum(),d)}d+=1}this.SortBaseItemLis(o,e.Job_get())
const _=this.GetOpenedEquipPosNum(i,e),g=this.GetPosEquipedNum(i,e),m=o.Count(),f=new h.M(s.modelId,s)
if(c=t,m+g<_||0==m)this.AddQueue1(c)
else{const t=this.GetCompareState(e,f,o,_)
if(0==t)this.AddQueue1(c)
else{if(1!=t)return[null,null]
l=u[o[0].serverData_get().Id_get().ToNum()],I=p[l],T.N.Inst_get().RemoveData(I),this.AddQueue1(c)}}return[c,I]}AddQueue1(t){let e=0
const s=t.scoreUp,i=this.GetEquipTipsDataById(t.tipType,t.tipSubType)
let n=!1
for(let t=0;t<=i.Count()-1;t++){if(e=t,!(s>i[t].scoreUp)){n=!1
break}n=!0}0==i.Count()||n?T.N.Inst_get().AddData(t):i.Insert(e,t)}GetPosEquipedNum(t,e){let s=0
const i=e.AllStageEquipments_get(),l=_.l.getWearPosByPosition(t.intPosition_get())
for(const[e,o]of(0,n.vy)(i))if(t.equipColumnsList_get().IndexOf(e,0)>=0){const t=i[e]
null!=t.equipmentsGet()[l]&&(s+=1,0==l&&t.equipmentsGet()[l].GetEquipRes().equipType==c.R.DOUBLE_WEAPON&&(s+=1))}return s}GetCompareState(t,e,s,i){const l=new a.Z
l.Add(e)
for(const[t,e]of(0,n.V5)(s))l.Add(e)
const o=t.AllStageEquipments_get(),r=_.l.getWearPosByPosition(e.cfgEquipData_get().intPosition_get())
for(const[t,s]of(0,n.vy)(o))if(e.cfgEquipData_get().equipColumnsList_get().IndexOf(t,0)>=0){const e=o[t]
if(null!=e.equipmentsGet()[r]){const t=e.equipmentsGet()[r],s=new h.M(t.modelId,t)
l.Add(s)}}this.SortBaseItemLis(l,t.Job_get())
let d=!1,c=!1
let I=l.Count()-1-i
for(;I>=0;)s.IndexOf(l[I],0)>=0&&(d=!0),e==l[I]&&(c=!0),h.M.Recycle(l[I].baseData),I-=1
return d?1:c?2:0}GetOpenedEquipPosNum(t,e){let s=0
return t.equipType==c.R.SINGLE_WEAPON||t.equipType==c.R.DOUBLE_WEAPON||t.equipType==c.R.RINGS?s+=2:s+=1,s}SortBaseItemLis(t,e){let s=null,i=0
for(;i<t.Count()-1;){let n=i+1
for(;n<t.Count();){g.I.Score(t[i],e)>g.I.Score(t[n],e)&&(s=t[i],t[i]=t[n],t[n]=s),n+=1}i+=1}}GetEquipTipsDataById(t,e,s,i){const n=T.N.Inst_get().GetDataByTipsType(t,e),l=new a.Z
for(let t=0;t<=n.Count()-1;t++){const e=n[t]
if(null!=e&&null!=e.rInfo){if(null==s)return n
s.Equal(e.rInfo.Id_get())&&(null!=i?e.columnPos==i&&l.Add(e):l.Add(e))}}return l}GetEquipTipsData(){const t=A.q.GetEquipTip
let e=w.p.SubEquipTips,s=T.N.Inst_get().GetDataByTipsType(t,e)
if(null!=s){if(s.Count()>0)return s
if(e=w.p.SubViewEquipTips,s=T.N.Inst_get().GetDataByTipsType(t,e),null!=s&&s.Count()>0)return s}return new a.Z}}M.inst=null,M.WearState=1,M.CheckState=2},66721:(t,e,s)=>{s.d(e,{
f:()=>v})
var i=s(38836),n=s(98800),l=s(68662),o=s(70829),a=s(85602),r=s(38962),h=s(70850),d=s(3859),c=s(33314),I=s(59033),u=s(75439),p=s(33138),_=s(34402),g=s(61546),m=s(78388),S=s(50748),f=s(60647),C=s(28893),T=s(54918),y=s(27327),A=s(47041)
class v{constructor(){this.practiceCdTime=0,this.firstSkillDic=null,this.firstSkillDic=new r.X}static Inst(){return null==v.inst&&(v.inst=new v),v.inst}StartPracticeCd(){
const t=u.D.getInstance().GetIntValue("SKILL:PRACTICE_CD")
this.practiceCdTime=l.D.serverTime_get()+t}ClearData(){this.practiceCdTime=0,this.firstSkillDic=new r.X}WhetherShowItemTip(t){
const e=n.Y.Inst.PrimaryRoleInfo_get(),s=p.f.Inst().getItemById(t.modelId)
if(s.level>e.Level_get())return!1
if(s.itemType==d.q.FRUIT)return this.IsPopFruit(s)
const l=new a.Z,o=n.Y.Inst.primaryRoleInfoList
for(const[t,e]of(0,i.V5)(o)){const t=e;(0==s.job||c.Z.ReachJobLimit(s.job,t.Job_get()))&&l.Add(t)}if(T.Q.Inst_get().IsSpecialTaskItem(t))return this.IsPopSkill(s,l),!1
if(0==l.count)return!1
if(3==s.whetherBatch)return this.IsPopSkill(s,l)
if(2==s.whetherBatch&&null!=C.F.Inst_get().skillExpItemCsvmap[s.id]){const e=this.IsPopSkillPractice(t,s)
return e&&this.StartPracticeCd(),e}return(s.id!=g.X.Inst_get().itemId||!g.X.Inst_get().IsMax())&&(s.itemType!=d.q.VIPPANDORA||this.IsPopVIPPANDORA(s))}IsPopSkillPractice(t,e){
const s=n.Y.Inst.primaryRoleInfoList
for(const[t,n]of(0,i.V5)(s))if(0==e.job||c.Z.ReachJobLimit(e.job,n.Job_get()))for(const[t,e]of(0,i.V5)(n.Skills_get())){const t=e.level,s=o.j.Inst().GetSkillByIdLevel(e.id,t,!1)
if(S.m.Inst().CanPracticeSkill(e.id,n,s,!0)){if(S.m.Inst().GetSkillPracticeLvById(n.Id_get(),e.id).level>-1)return!0}}let a=!1
if(this.practiceCdTime<=l.D.serverTime_get())for(const[t,n]of(0,i.V5)(s))if(0==e.job||c.Z.ReachJobLimit(e.job,n.Job_get()))for(const[t,e]of(0,i.V5)(n.Skills_get())){
if(null!=m.r.Inst().GetSkillDicBySkillId(e.id))return!1
a=!0}return a}IsPopSkill(t,e){const s=S.m.Inst().GetSkillIdByItemRes(t)
for(const[n,l]of(0,i.V5)(e)){let e=0
const i=S.m.Inst().GetSkillByStudyDic(s,l)
if(null!=i&&(e=i.level),0!=e){if(S.m.Inst().IsCanUseItemLevelUp(s,l,e))return this.firstSkillDic[t.id]=!1,!0}else{
if(f.p.inst.GetSkillSetting(l.Id_get(),s))return f.p.inst.SendSkillSetting(l.Id_get(),s),this.firstSkillDic[t.id]=!0,!0
if(this.firstSkillDic[t.id]=!1,S.m.Inst().IsCanUseItemLevelUp(s,l,e))return!0}}return!1}IsHasInQueue(t){const e=p.f.Inst().getItemById(t.modelId),s=y.$.Inst()
for(let i=0;i<=s.itemQueue.Count()-1;i++){if(s.itemQueue[i].data.modelId==e.id){if(2==e.whetherBatch){s.itemQueue[i].data=t
const e=s.itemQueue[i],n=A.N.Inst_get().GetItemPriority(s.itemQueue[i].data)
let l=i+1
for(;l<s.itemQueue.Count();){if(A.N.Inst_get().GetItemPriority(s.itemQueue[l].data)>n)break
l+=1}l!=i&&(s.itemQueue[i]=s.itemQueue[l-1],s.itemQueue[l-1]=e,A.N.Inst_get().RefreshTip())}return!0}}return!1}IsPopFruit(t){let e=null,s=!1
const i=n.Y.Inst.GetMultPlayerInfos()
for(let n=0;n<=i.count-1;n++)I.t.Inst_get().GetRemainUseNum(t.id,i[n])>0&&(null==e&&(e=i[n]),s=!0)
return!!s}IsPopVIPPANDORA(t){const e=h.g.Inst_get().GetItemByModleID(t.modelId)
if(null!=e){const t=e.serverData_get(),s=_.$.Inst().getItemById(e.baseData_get().cfgData_get().id)
if(t.todayUseTimes>=s.daiLimit)return!1}return!0}}v.inst=null},47041:(t,e,s)=>{s.d(e,{N:()=>z})
var i=s(17409),n=s(32076),l=s(38836),o=s(98800),a=s(97461),r=s(68662),h=s(56937),d=s(18202),c=s(31222),I=s(5494),u=s(52726),p=s(38962),_=s(70850),g=s(95272),m=s(59918),S=s(3859),f=s(92679),C=s(59265),T=s(55492),y=s(75439),A=s(42534),v=s(33138),D=s(12417),w=s(20531),B=s(8828),M=s(27327),b=s(2933),O=s(28963),R=s(36713),L=s(15337),G=s(85602),P=s(63076),E=s(48933),k=s(21577),N=s(26495),V=s(64649),x=s(37648),F=s(37828),U=s(54918)
class H{constructor(){this.elementCarve=null,this.rInfo=null,this.scoreUp=0,this.stageUp=0,this.levelUp=0,this.poskey=0,this.tipType=R.q.GetElementCarveTip}Test1(){return!0}
S_Test(){return!0}}class j{constructor(){this.scoreDic=null,this.equipQueue=null,this._degf_BagUpdateHandle=null,this._degf_WearUpdate=null,this.scoreDic=new p.X,
this._degf_BagUpdateHandle=()=>this.BagUpdateHandle(),this._degf_WearUpdate=t=>this.WearUpdate(t),this.AddLis()}static Inst(){return null==j.inst&&(j.inst=new j),j.inst}
IsCanShow(t){const e=t.cfgData_get()
return!(null==e||!k.P.SimpleIsCanWearInAllRole(e))}AddLis(){a.i.Inst.AddEventHandler(f.g.BAG_UPDATE,this._degf_BagUpdateHandle(this.BagUpdateHandle)),
N.p.GetInst().AddEventHandler(f.g.EleCarve_Wear_Item_Id,this._degf_WearUpdate(this.WearUpdate))}IsCanJudgeItem(t){return!U.Q.Inst_get().IsSpecialTaskItem(t)&&!this.IsDeprecated1(t)
}IsDeprecated1(t){if(null==t.deprecatedTime||t.deprecatedTime.Equal(E.I.zeroLong))return!1
return t.deprecatedTime.ToNum()/1e3-r.D.serverTime_get()<3}IsHasElementCarveInQueue(t){const e=B.N.Inst_get().GetDataByTipsType(R.q.GetElementCarveTip)
let s=0,i=null
for(let n=0;n<=e.Count()-1;n++){const l=e[n]
if(null!=l){l.elementCarve.Id_get().Equal(t.Id_get())&&(s+=1,i=l)}}if(null!=i&&s>=t.num){const e=_.g.Inst_get().GetItemById(t.Id_get())
if(null!=e&&null!=e.serverData_get()&&s>=e.serverData_get().num)return B.N.Inst_get().RemoveData(i),!0}}GetDataCanUpInAllPlayer(t,e,s){let i=!1
this.IsHasElementCarveInQueue(t)&&(i=!0)
const n=v.f.Inst().getItemById(t.modelId),l=o.Y.Inst.GetMultPlayerInfos(),a=new G.Z
for(let o=0;o<=l.Count()-1;o++){const r=l[o]
if(k.P.JobIsCanWear(r,n)&&(null==s||!s.Contains(r.createIdx))){const s=new P.M(t.modelId,t),[n,l]=k.P.GetUphold_subhold(r,s),o=l[1],h=l[2],d=l[3]
if(o>0||0==o&&h>0||0==o&&0==h&&d>0){let s=!1
const l=new H
l.rInfo=r,l.scoreUp=o,l.stageUp=h,l.levelUp=d,l.poskey=n
const c=this.IsWearOrCheckTip(r,t)
c==j.WearState?(l.tipSubType=O.p.SubEquipTips,l.priority=b.$.GetElementCarveTip):c==j.CheckState&&(e||i?(l.tipSubType=O.p.SubViewEquipTips,l.priority=b.$.GetElementCarveTip):s=!0),
s||(l.elementCarve=t,a.Add(l))}}}return a.Sort(this.CreateDelegate(this.SortUpScore)),a}IsWearOrCheckTip(t,e){const s=e,i=new P.M(s.modelId,s)
return k.P.LevelIsCanWear(t,i.cfgData_get())?j.WearState:j.CheckState}SortUpScore(t,e){if(e.tipSubType==t.tipSubType){const s=t.scoreUp,i=e.scoreUp
if(s>i)return-1
if(s<i)return 1
const n=t.stageUp,l=e.stageUp
if(n>l)return-1
if(n<l)return 1
const o=t.levelUp,a=e.levelUp
if(o>a)return-1
if(o<a)return 1
return t.rInfo.createIdx-e.rInfo.createIdx}return t.tipSubType==O.p.SubEquipTips?1:0}GetShowElementTipData(t,e,s){if(!x.P.Inst_get().IsFunctionOpened(T.x.ELEMENT_Carve))return null
if(!this.IsCanJudgeItem(t))return null
const i=this.GetDataCanUpInAllPlayer(t,e,s)
if(0==i.count)return null
let n=0
for(;n<i.count;){var l=this.IsEnQueue(i[n])[0],o=this.IsEnQueue(i[n])[1]
if(null!=l)return z.Inst_get().GetElementCarveEnQueue(l),null!=o&&n<i.count-1&&(null==s&&(s=new G.Z),s.Add(o.rInfo.createIdx),z.Inst_get().ShowGetTip(o.elementCarve,!0,s)),l
n+=1}return null}IsEnQueue(t){const e=t.rInfo,s=t.elementCarve
let i=null,n=0
const l=new G.Z
let o=0,a=null,r=null
const h=new p.X,d=this.GetEquipTipsDataById(t.tipType,t.tipSubType,e.Id_get())
for(;o<d.Count();){i=d[o]
const t=new P.M(i.elementCarve.modelId,i.elementCarve)
l.Add(t),h.LuaDic_AddOrSetItem(i.elementCarve.id.ToNum(),o),o+=1}
const c=N.p.GetInst().holdOpenNumDic[e.createIdx]||0,I=N.p.GetInst().holdEquipNumDic[e.createIdx]||0,u=l.Count(),_=new P.M(s.modelId,s)
if(a=t,u+I<c||0==u)this.AddQueue1(a)
else{const t=this.GetCompareState(e,_,l,c)
if(0==t)this.AddQueue1(a)
else{if(1!=t)return null
n=h[l[0].serverData_get().Id_get().ToNum()],r=d[n],B.N.Inst_get().RemoveData(r),this.AddQueue1(a)}}return[a,r]}GetEquipTipsDataById(t,e,s){
const i=B.N.Inst_get().GetDataByTipsType(t,e),n=new G.Z
for(let t=0;t<=i.Count()-1;t++){const e=i[t]
if(null!=e&&null!=e.rInfo){if(null==s)return i
s.Equal(e.rInfo.Id_get())&&n.Add(e)}}return n}GetElementCarveTipsData(){const t=R.q.GetElementCarveTip
let e=O.p.SubEquipTips,s=B.N.Inst_get().GetDataByTipsType(t,e)
if(null!=s){if(s.Count()>0)return s
if(e=O.p.SubViewEquipTips,s=B.N.Inst_get().GetDataByTipsType(t,e),null!=s&&s.Count()>0)return s}return new G.Z}GetCompareState(t,e,s,i){const n=new G.Z
n.Add([e,1])
for(const[t,e]of(0,l.V5)(s))n.Add([e,2])
const o=V.$.Inst().GetTypeList()
for(let e=0;e<=o.Count()-1;e++){const s=o[e],i=N.p.GetInst().GetSubTypeList()
for(let e=0;e<=i.Count()-1;e++){const l=i[e],o=t.GetElementCarve(s,l)
if(null!=o){const t=new P.M(o.modelId,o)
n.Add([t,3])}}}n.Sort(this.CreateDelegate(this.SortBaseItemLis))
let a=!1,r=!1
let h=n.Count()-1-i
const d=s.Count()
for(;h>=0;){for(let t=0;t<=d-1;t++)null!=s[t].serverData_get()&&null!=n[h][1].serverData_get()&&s[t].serverData_get().id.Equal(n[h][1].serverData_get().id)&&(a=!0)
e==n[h][1]&&(r=!0),h-=1}return a?1:r?2:0}SortBaseItemLis(t,e){
const s=t[1],i=e[1],n=F.b.GetInst().GetEleCarveItemById(s.modelId_get()).score,l=F.b.GetInst().GetEleCarveItemById(i.modelId_get()).score
if(n==l){const n=s.serverData_get(),l=i.serverData_get(),o=n.stage,a=l.stage
if(o!=a)return o-a
const r=n.level,h=l.level
return r!=r?r-h:t[2]-e[2]}return n-l}AddQueue1(t){let e=0
const s=t.scoreUp,i=t.stageUp,n=t.levelUp,l=this.GetEquipTipsDataById(t.tipType,t.tipSubType)
let o=!1
for(let t=0;t<=l.Count()-1;t++){const a=l[t].scoreUp,r=l[t].stageUp,h=l[t].levelUp
if(e=t,!(s>a||s==a&&i>r||s==a&&i==r&&n>h)){o=!1
break}o=!0}0==l.Count()||o?B.N.Inst_get().AddData(t):l.Insert(e,t)}DebugAllData(t){}BagUpdateHandle(){if(this.equipQueue=this.GetElementCarveTipsData(),
null!=this.equipQueue&&this.equipQueue.Count()>0){let t=this.equipQueue.Count()-1
for(;t>=0;){if(t<this.equipQueue.Count()){const e=this.equipQueue[t].elementCarve
if(null==_.g.Inst_get().GetItemById(e.Id_get()))return void(t==this.equipQueue.Count()-1?z.Inst_get().GetElementCarveDeQueue(null):this.equipQueue.RemoveAt(t))}t-=1}}}
WearUpdate(t){if(this.equipQueue=this.GetElementCarveTipsData(),null!=this.equipQueue&&this.equipQueue.Count()>0){
this.equipQueue[this.equipQueue.Count()-1].elementCarve.Id_get()==t&&z.Inst_get().GetElementCarveDeQueue()}}Test1(){return!0}S_Test(){return!0}}j.inst=null,j.WearState=1,
j.CheckState=2
var W=s(12399),Y=s(5633),q=s(66721)
class z{get m_tip(){return this._m_tip=(0,i.Y)(I.I.TipListPanel),this._m_tip}constructor(){this._m_tip=null,this.timeDic=null,this.model=null,this.curRecordData=null,
this._degf_ShowHandler=null,this._degf_CallDestroy=null,this.timeDic=new p.X,this.model=B.N.Inst_get(),this._degf_ShowHandler=t=>this.ShowHandler(t),
this._degf_CallDestroy=()=>this.CallDestroy(),this.AddLis()}static Inst_get(){return null==z._inst&&(z._inst=new z),z._inst}AddLis(){a.i.Inst.AddEventHandler(f.g.OPEN_BAG,(0,
n.v)(this.OpenBagHandle,this)),a.i.Inst.AddEventHandler(f.g.BAG_UPDATE,(0,n.v)(this.BagUpdateHandle,this))}BagUpdateHandle(){
const t=B.N.Inst_get().GetDataByTipsType(R.q.GetEquipTip)
let e=!1
if(null!=t)for(let s=t.Count()-1;s>=0;s+=-1){const i=t[s]
null==_.g.Inst_get().GetItemById(i.equip.id)&&(this.model.RemoveData(i),this.curRecordData.tipType==R.q.GetEquipTip&&(e=!0))}
const s=B.N.Inst_get().GetDataByTipsType(R.q.GetElementTip)
if(null!=s)for(let t=s.Count()-1;t>=0;t+=-1){const i=s[t]
null==_.g.Inst_get().GetItemById(i.element.Id_get(),g.t.ElementBag)&&(this.model.RemoveData(i),this.curRecordData.tipType==R.q.GetElementTip&&(e=!0))}e&&this.RefreshTip()}
OpenBagHandle(){this.ViewEquipDeQueue()}DeQueueByData(t){null!=t&&this.model.RemoveData(t),this.RefreshTip()}EnQueue(t){this.UpdateTipsQueue(t,null)}ResetPanel(){
null!=this.m_tip&&this.m_tip.node&&this.m_tip.Reset()}ResetModel(){this.model.Clear(),M.$.Inst().Reset(),q.f.Inst().ClearData(),this.timeDic.Clear()}RefreshTip(){
if(null!=this.m_tip&&this.m_tip.node){this.model.GetAllData().Count()>0?(this.curRecordData=this.model.GetNextData(),
this.m_tip.ShowTip(this.curRecordData)):(this.curRecordData=null,this.m_tip.Reset())}}HideOrShowTip(t){
null!=this.m_tip&&this.m_tip.node&&this.m_tip.isShow_get()&&this.m_tip.CrossMapCheck(t)}GetCurRecord(){return this.curRecordData}GetCurTipType(){
return null!=this.curRecordData?this.curRecordData.tipType:-1}UpdateTipsQueue(t,e=null){if(!e)if(t.IsMostOne()){
0==this.model.GetDataByTipsType(t.tipType).Count()&&this.model.AddData(t)}else this.model.AddData(t)
this.RefreshTip()}RemoveTipsQueue(t=null){t||this.model.RemoveData(this.curRecordData),this.RefreshTip()}Open(){const t=new h.v
t.layerType=u.F.DefaultUI,t.ReLoginOrChangeRoleIsDestroy=!1,c.N.inst.OpenById(I.I.TipListPanel,this._degf_ShowHandler,this._degf_CallDestroy,t)}ShowHandler(t){
return null==this.m_tip&&(this.m_tip=new L.W(null),this.m_tip.setId(t,null,0)),this.m_tip}CallDestroy(){d.g.DestroyUIObj(this.m_tip),this.m_tip=null}ShowCrackerUseTip(){
const t=_.g.Inst_get().GetBagDataList()
if(null!=t)for(const[e,s]of(0,l.V5)(t))if(null!=s.baseData_get()&&s.baseData_get().cfgData_get().itemType==S.q.CRACKER){this.ShowGetTip(s.serverData_get(),null,null)
break}}ShowTipAfterSpecialEquip(t,e,s){if(null!=e&&null!=s){const t=e.GetEquipRes(),i=s.GetEquipRes()
if(t.equipType==m.R.DOUBLE_WEAPON&&i.equipType==m.R.SINGLE_WEAPON||i.equipType==m.R.MAIN_WEAPON){const t=_.g.Inst_get().GetBagDataList()
for(const[e,s]of(0,l.V5)(t)){if(null==t)return
if(null!=s.baseData_get()){const t=v.f.Inst().getItemById(s.baseData_get().modelId_get())
if(t.itemType==S.q.EQUIPMENT){const e=A.f.Inst().getItemById(t.id)
e.equipType!=m.R.SINGLE_WEAPON&&e.equipType!=m.R.SUB_WEAPON||this.ShowGetTip(s.serverData_get(),null,null)}}}}}this.RefreshTip()}ShowGetTip(t,e=null,s=null){
const i=v.f.Inst().getItemById(t.modelId)
if(0!=i.whetherBatch)if(null==e&&(e=!1),i.itemType==S.q.EQUIPMENT||i.itemType==S.q.FLAG){if(null!=t&&t.appraisal)return
Y.F.Inst().GetShowEquipTipData(t,e,s)}else if(i.itemType==S.q.ELEMENT)W.f.Inst().GetShowElementTipData(t,e,s)
else if(i.itemType==S.q.elementCarve){if(null!=t&&t.num>0)for(let i=1;i<=t.num;i++)j.Inst().GetShowElementTipData(t,e,s)}else{if(q.f.Inst().IsHasInQueue(t))return
if(q.f.Inst().WhetherShowItemTip(t)){const e=M.$.Inst().itemQueue,s=new w.R
s.data=t,e.Insert(0,s),this.GetItemEnQueue(t)}}}ShowTipsAfterStronger(){if(null!=_.g.Inst_get().GetBagDataList())for(const[t,e]of(0,
l.V5)(_.g.Inst_get().GetBagDataList()))if(null!=e.baseData_get()){const t=v.f.Inst().getItemById(e.serverData_get().modelId)
t.itemType!=S.q.EQUIPMENT&&3!=t.whetherBatch||this.ShowGetTip(e.serverData_get(),null,null)}this.RefreshTip()}CheckAllItem(){if(null!=_.g.Inst_get().GetBagDataList(g.t.NormalBag)){
const t=_.g.Inst_get().GetBagDataList(g.t.NormalBag)
if(t)for(const[e,s]of(0,l.V5)(t))null!=s.baseData_get()&&this.ShowGetTip(s.serverData_get())}if(null!=_.g.Inst_get().GetBagDataList(g.t.ElementBag)){
const t=_.g.Inst_get().GetBagDataList(g.t.ElementBag)
if(t)for(const[e,s]of(0,l.V5)(t))null!=s.baseData_get()&&this.ShowGetTip(s.serverData_get())}this.RefreshTip()}ShowTipsAfterStronger_Attr(){
if(null!=_.g.Inst_get().GetBagDataList())for(const[t,e]of(0,l.V5)(_.g.Inst_get().GetBagDataList()))if(null!=e.baseData_get()){
const t=v.f.Inst().getItemById(e.serverData_get().modelId)
t.itemType!=S.q.EQUIPMENT&&3!=t.whetherBatch||this.ShowGetTip(e.serverData_get())}this.RefreshTip()}ShowTipsAfterStronger_Special(){
if(null!=_.g.Inst_get().GetBagDataList())for(const[t,e]of(0,l.V5)(_.g.Inst_get().GetBagDataList()))if(null!=e.baseData_get()){
v.f.Inst().getItemById(e.serverData_get().modelId).itemType==S.q.EQUIPMENT&&this.ShowGetTip(e.serverData_get(),!0)}}ShowTipsAfterMaze_Special(){
if(null!=_.g.Inst_get().GetBagDataList())for(const[t,e]of(0,l.V5)(_.g.Inst_get().GetBagDataList()))if(null!=e.baseData_get()){
v.f.Inst().getItemById(e.serverData_get().modelId).itemType==S.q.SPACE_MAZE_ITEM&&this.ShowGetTip(e.serverData_get(),!0)}}GetEquipEnQueue(t){this.UpdateTipsQueue(t,!0)}
GetEquipDeQueue(){this.GetCurTipType()==R.q.GetEquipTip&&this.RemoveTipsQueue()}ViewElementDeQueue(){
this.GetCurTipType()==R.q.GetElementTip&&this.curRecordData.tipSubType==O.p.SubViewEquipTips&&(this.model.RemoveDataBySubType(R.q.GetElementTip,O.p.SubViewEquipTips),
this.RemoveTipsQueue(!0))}RefreshItemQueue(){const t=M.$.Inst().itemQueue
let e=0
for(;e<t.Count()-1;){let s=e+1
const i=this.GetItemPriority(t[e].data)
for(;s<t.Count();){if(i>=this.GetItemPriority(t[s].data)){const i=t[e]
t[e]=t[s],t[s]=i}s+=1}e+=1}}GetElementEnQueue(t){this.UpdateTipsQueue(t,!0)}GetElementDeQueue(t){this.GetCurTipType()==R.q.GetElementTip&&this.RemoveTipsQueue()}
GetElementCarveEnQueue(t){t.elementCarve.modelId
this.UpdateTipsQueue(t,!0)}GetElementCarveDeQueue(t){this.GetCurTipType()==R.q.GetElementCarveTip&&this.RemoveTipsQueue()}ViewEquipDeQueue(){
this.GetCurTipType()==R.q.GetEquipTip&&this.curRecordData.tipSubType==O.p.SubViewEquipTips&&(this.model.RemoveDataBySubType(R.q.GetEquipTip,O.p.SubViewEquipTips),
this.RemoveTipsQueue(!0))}GetItemEnQueue(t){this.RefreshItemQueue()
const e=M.$.Inst(),s=v.f.Inst().getItemById(e.itemQueue[e.itemQueue.Count()-1].data.modelId),i=new w.R
i.tipType=R.q.GetItemTip,s.itemType!=S.q.PANDORA&&s.itemType!=S.q.VIPPANDORA||(i.isPandora=!0)
3==v.f.Inst().getItemById(t.modelId).whetherBatch?(i.priority=b.$.LearnSkill,i.tipSubType=O.p.LearnSkill):i.priority=b.$.GetItemTip,this.UpdateTipsQueue(i)}GetItemPriority(t){
let e=b.$.GetItemTip
if(null==t)return e
return 3==v.f.Inst().getItemById(t.modelId).whetherBatch&&(e=b.$.LearnSkill),e}GetItemDeQueue(){if(this.GetCurTipType()==R.q.GetItemTip){const t=M.$.Inst()
t.itemQueue.Count()>0&&t.itemQueue.RemoveAt(t.itemQueue.Count()-1),this.RemoveTipsQueue()}}BuyMedicineEnQueue(t,e){if(o.Y.Inst.PrimaryRoleInfo_get().PkPoint_get()>1)return
if(this.model.GetDataByTipsType(R.q.BuyMedicineTip).Count()>0)return
let s=0
if(this.timeDic[R.q.BuyMedicineTip]&&(s=this.timeDic[R.q.BuyMedicineTip]),r.D.serverTime_get()>s){
this.timeDic[R.q.BuyMedicineTip]=y.D.getInstance().GetIntValue("HANG:MEDICINE_TIPS_CD")+r.D.serverTime_get()
const s=new w.R
s.InitBuyMedicineTip(t,e),this.UpdateTipsQueue(s,null)}}BuyMedicineDeQueue(){this.GetCurTipType()==R.q.BuyMedicineTip&&this.RemoveTipsQueue(null)}FullBagTipEnQueue(t){
const e=new w.R
e.tipType=R.q.BagFullTip,e.priority=b.$.BagFullTip,e.tipSubType=t
B.N.Inst_get().GetDataByTipsType(e.tipType,e.tipSubType).Count()>0||this.UpdateTipsQueue(e)}FullBagTipDeQueue(t){const e=B.N.Inst_get().GetDataByTipsType(R.q.BagFullTip,t)
if(e.Count()>0)for(let t=e.Count()-1;t>=0;t+=-1)this.model.RemoveData(e[t])
this.RefreshTip()}ScoreSellTipEnQueue(t){const e=new w.R
e.tipType=R.q.OneKeySellTip,e.priority=b.$.OneKeySell,this.UpdateTipsQueue(e)}ScoreSellDeQueue(){this.GetCurTipType()==R.q.OneKeySellTip&&this.RemoveTipsQueue()}
AttrPointTipEnQueue(t){if(!t)return
if(this.model.GetDataByTipsType(R.q.AttrPointTip).Count()>0)return
const e=new w.R
e.tipType=R.q.AttrPointTip,e.priority=b.$.AttrPointTip,e.playerId=t,this.UpdateTipsQueue(e)}AttrPointTipDeQueue(t){const e=this.model.GetDataByTipsType(R.q.AttrPointTip,0)
let s=-1
for(let i=0;i<=e.Count()-1;i++){if(e[i].playerId.Equal(t)){s=i
break}}-1!=s&&(s==e.Count()-1&&this.GetCurTipType()==R.q.AttrPointTip?this.RemoveTipsQueue():this.model.RemoveDataByPos(R.q.AttrPointTip,null,s))}BossRefreshTipEnQueue(t){
const e=D._.Inst()
e.bossIdQueue.Add(t),e.refreshBossId=e.bossIdQueue[e.bossIdQueue.Count()-1]
const s=new w.R
s.tipType=R.q.BossRefreshTip,s.priority=b.$.BossRefreshTip,this.UpdateTipsQueue(s)}BossRefreshTipDeQueue(){if(this.GetCurTipType()==R.q.BossRefreshTip){const t=D._.Inst()
t.bossIdQueue.Count()>0&&t.bossIdQueue.RemoveAt(t.bossIdQueue.Count()-1),this.RemoveTipsQueue()}}RemoveMsg(t){const e=this.GetCurRecord()
null==e||e.tipType!=R.q.ActivityTip||e.functionId!=t.id?this.model.RemoveActivityTipByFuncId(t.id):this.ActivityDeQueue()}ActivityEnQueue(t,e,s){
if(this.model.RemoveActivityTipByFuncId(t),t==T.x.Exorcism&&C.t.Inst_get().IsPassAll())return
const i=new w.R
i.tipType=R.q.ActivityTip,i.functionId=t,i.endTime=e,i.priority=b.$.ScheduledActivity,null!=s&&(i.timeLimitType=s),this.UpdateTipsQueue(i,!1)}RemoveAsuramActTip(){
const t=this.GetCurRecord()
null==t||t.tipType!=R.q.ActivityTip||t.functionId!=T.x.ASURAM_BOSS?this.model.RemoveActivityTipByFuncId(T.x.ASURAM_BOSS):this.ActivityDeQueue()}RemoveLimitTimeActTip(t){
const e=this.GetCurRecord()
null==e||e.tipType!=R.q.ActivityTip||e.functionId!=t?this.model.RemoveActivityTipByFuncId(t):this.ActivityDeQueue()}ActivityDeQueue(){
this.GetCurTipType()==R.q.ActivityTip&&this.RemoveTipsQueue()}GameGMOfflineEnQueue(){const t=new w.R
t.tipType=R.q.GameGMOffline,t.priority=b.$.ScheduledActivity,this.UpdateTipsQueue(t)}GameGMOfflineDeQueue(){B.N.Inst_get().RemoveDataByType(R.q.GameGMOffline),this.RefreshTip()}
RolandSaveBossEnQueue(){if(this.model.GetDataByTipsType(R.q.RolandSaveBoss).Count()>0)return
const t=new w.R
t.tipType=R.q.RolandSaveBoss,t.priority=b.$.ScheduledActivity,this.UpdateTipsQueue(t)}RolandSaveBossDeQueue(){B.N.Inst_get().RemoveDataByType(R.q.RolandSaveBoss),this.RefreshTip()}
RolandValleyBossEnQueue(){const t=new w.R
t.tipType=R.q.RolandValleyBoss,t.priority=b.$.ScheduledActivity,this.UpdateTipsQueue(t)}RolandValleyBossDeQueue(){B.N.Inst_get().RemoveDataByType(R.q.RolandValleyBoss),
this.RefreshTip()}}z._inst=null},20531:(t,e,s)=>{s.d(e,{R:()=>l})
var i=s(2933),n=s(36713)
class l{constructor(){this.tipType=0,this.tipSubType=0,this.priority=0,this.playerId=null,this.endTime=0,this.activityType=0,this.functionId=0,this.data=null,this.timeLimitType=0,
this.hangBuyVo=null,this.itemId=0,this.isPandora=!1}IsMostOne(){return this.tipType==n.q.OneKeySellTip||this.tipType==n.q.BuyMedicineTip}InitBuyMedicineTip(t,e){
this.tipType=n.q.BuyMedicineTip,this.priority=i.$.BuyMedicineTip,this.itemId=t,this.hangBuyVo=e}}},8828:(t,e,s)=>{s.d(e,{N:()=>h})
var i=s(38836),n=s(25236),l=s(16812),o=s(85602),a=s(38962),r=s(36713)
class h extends l.k{constructor(){super(),this.tipDic=null,this.tipDic=new a.X}GetNextData(){let t=-1,e=-1,s=-1
for(const[n,l]of(0,i.vy)(this.tipDic))for(const[o,a]of(0,i.vy)(l))if(a.Count()>0){const i=a[0].priority
i>t&&(t=i,e=n,s=o)}if(t>-1){const t=this.tipDic[e][s]
return t[t.Count()-1]}return null}AddData(t){const e=t.tipType,s=t.tipSubType
this.tipDic.LuaDic_ContainsKey(e)||this.tipDic.LuaDic_Add(e,new a.X)
const i=this.tipDic.LuaDic_GetItem(e)
i.LuaDic_ContainsKey(s)||i.LuaDic_Add(s,new o.Z)
const n=i.LuaDic_GetItem(s)
n.Contains(t)||n.Add(t)}GetDataByTipsType(t,e=null){let s=new o.Z
if(this.tipDic.LuaDic_ContainsKey(t)){const n=this.tipDic.LuaDic_GetItem(t)
for(const[t,l]of(0,i.vy)(n))if(null!=l&&l.Count()>0){if(null!=e&&e==t){s=l
break}null==e&&s.AddRange(l)}}return s}GetAllData(){const t=new o.Z
for(const[e,s]of(0,i.vy)(this.tipDic)){const s=this.GetDataByTipsType(e)
t.AddRange(s)}return t}RemoveData(t){const e=t.tipType,s=t.tipSubType
if(this.tipDic.LuaDic_ContainsKey(e)){const i=this.tipDic.LuaDic_GetItem(e)
if(i.LuaDic_ContainsKey(s)){const e=i.LuaDic_GetItem(s)
e.Contains(t)&&e.Remove(t),(0,n.S)("")}}}RemoveDataByPos(t,e,s){if(null==e&&(e=0),this.tipDic.LuaDic_ContainsKey(t)){const i=this.tipDic.LuaDic_GetItem(t)
if(i.LuaDic_ContainsKey(e)){const t=i.LuaDic_GetItem(e)
t.Count()>s&&t.RemoveAt(s)}}}RemoveDataByType(t){if(this.tipDic.LuaDic_ContainsKey(t)){this.tipDic.LuaDic_GetItem(t).Clear()}}RemoveDataBySubType(t,e){
if(this.tipDic.LuaDic_ContainsKey(t)){const s=this.tipDic.LuaDic_GetItem(t)
if(s.LuaDic_ContainsKey(e)){s.LuaDic_GetItem(e).Clear()}}}RemoveActivityTipByFuncId(t){for(const[e,s]of(0,i.vy)(this.tipDic))for(const[e,n]of(0,
i.vy)(s))for(let e=n.Count()-1;e>=0;e+=-1)n[e].tipType==r.q.ActivityTip&&n[e].functionId==t&&n.RemoveAt(e)}static Inst_get(){return null==h._inst&&(h._inst=new h),h._inst}Clear(){
for(const[t,e]of(0,i.vy)(this.tipDic))null!=e&&e.Clear()
this.tipDic.Clear()}}h._inst=null},27327:(t,e,s)=>{s.d(e,{$:()=>n})
var i=s(85602)
class n{constructor(){this.itemQueue=null,this.itemQueue=new i.Z}static Inst(){return null==n.inst&&(n.inst=new n),n.inst}Reset(){this.itemQueue.Clear()}}n.inst=null},
2933:(t,e,s)=>{s.d(e,{$:()=>i})
class i{}i.Default=0,i.BagFullTip=1,i.OneKeySell=2,i.BuyMedicineTip=3,i.OtherFunction=4,i.ViewEquipTip=5,i.AttrPointTip=6,i.GetItemTip=7,i.GetEquipTip=8,i.GetElementCarveTip=9,
i.GetElementTip=10,i.LearnSkill=11,i.BossRefreshTip=12,i.ScheduledActivity=13},28963:(t,e,s)=>{s.d(e,{p:()=>i})
class i{}i.SubDefault=0,i.SubEquipTips=1,i.SubViewEquipTips=2,i.LearnSkill=1},36713:(t,e,s)=>{s.d(e,{q:()=>i})
class i{}i.GetEquipTip=1,i.GetItemTip=2,i.BagFullTip=3,i.BuyMedicineTip=4,i.BossRefreshTip=5,i.ActivityTip=6,i.OneKeySellTip=7,i.AttrPointTip=8,i.GameGMOffline=9,
i.GetElementTip=10,i.RolandSaveBoss=11,i.RolandValleyBoss=12,i.GetElementCarveTip=13},98359:(t,e,s)=>{s.d(e,{k:()=>l})
var i=s(51868),n=s(47041)
class l extends i.${constructor(...t){super(...t),this.fatherView=null,this.curData=null}InitView(){super.InitView()}SetData(t){this.curData=t}Clear(){this.RemoveLis(),
super.Clear()}Destroy(){}AddLis(){}RemoveLis(){}OnCloseBtnHandle(){n.N.Inst_get().DeQueueByData(this.curData)}OnOptBtnHandle(){}}},15337:(t,e,s)=>{s.d(e,{W:()=>L})
var i,n,l=s(18998),o=s(6847),a=s(83908),r=s(46282),h=s(32076),d=s(38836),c=s(38045),I=s(97461),u=s(2689),p=s(13687),_=s(66788),g=s(61911),m=s(5494),S=s(38962),f=s(79534),C=s(67885),T=s(3859),y=s(92679),A=s(29839),v=s(33138),D=s(15821),w=s(21334),B=s(47041),M=s(27327),b=s(36713),O=s(98885),R=s(98359)
let L=(0,o.s_)(m.I.TipListPanel,r.Z.ui_tipsqueue_fathertip).waitPrefab(C.S.modulePathList).layerNav().register()((n=class t extends((0,a.pA)(g.f)()){constructor(...t){super(...t),
this.curtipdata=null,this.isout=!1,this.typeGoDic=null,this.subPanel=null}InitView(){super.InitView(),this.typeGoDic=new S.X}OnAddToScene(){this.AddLis(),
this.baseItem.SetIconSize(66,66),this.baseItem.SetBgSize(66,66),this.InitData(),this.HideFakeObj(),
B.N.Inst_get().model.GetAllData().Count()>0&&(B.N.Inst_get().curRecordData=B.N.Inst_get().model.GetNextData(),this.ShowTip(B.N.Inst_get().curRecordData))}InitData(){
null==this.typeGoDic?this.typeGoDic=new S.X:this.typeGoDic.Clear(),this.typeGoDic.LuaDic_AddOrSetItem(b.q.GetEquipTip,this.getEquipTip),
this.typeGoDic.LuaDic_AddOrSetItem(b.q.GetItemTip,this.getItemTip),this.typeGoDic.LuaDic_AddOrSetItem(b.q.BagFullTip,this.fullBagTip),
this.typeGoDic.LuaDic_AddOrSetItem(b.q.BuyMedicineTip,this.buyMedicineTip),this.typeGoDic.LuaDic_AddOrSetItem(b.q.BossRefreshTip,this.bossRefreshTip),
this.typeGoDic.LuaDic_AddOrSetItem(b.q.ActivityTip,this.activityTip),this.typeGoDic.LuaDic_AddOrSetItem(b.q.OneKeySellTip,this.oneKeySellTip),
this.typeGoDic.LuaDic_AddOrSetItem(b.q.AttrPointTip,this.attrPointTip),this.typeGoDic.LuaDic_AddOrSetItem(b.q.GameGMOffline,this.gamegmOfflineTip),
this.typeGoDic.LuaDic_AddOrSetItem(b.q.GetElementTip,this.getElementTip),this.typeGoDic.LuaDic_AddOrSetItem(b.q.RolandSaveBoss,this.rolandsaveBossTip),
this.typeGoDic.LuaDic_AddOrSetItem(b.q.RolandValleyBoss,this.rolandvalleyBossTip),this.typeGoDic.LuaDic_AddOrSetItem(b.q.GetElementCarveTip,this.getElementCarveTip)}Clear(){
this.RemoveLis(),this.isout=!1,I.i.Inst.RaiseEvent(D.i.NEWBIE_WEAR_EQUIP_BACK)}Destroy(){I.i.Inst.RaiseEvent(D.i.NEWBIE_WEAR_EQUIP_BACK)}SetSlider(t,e){let s=t/e*223
s<=0&&(s=0),this.bg1.transform.SetLocalPositionXYZ(s,-1,0)}AddLis(){this.m_handlerMgr.AddEventMgr(y.g.UPDATE_ANCHORS,this.CreateDelegate(this.MoveAnchors)),
this.optBtn.node.on(l.NodeEventType.TOUCH_END,this.OnOptBtnHandle,this),I.i.Inst.AddEventHandler(D.i.NEWBIE_WEAR_EQUIP,(0,h.v)(this.OnOptBtnHandle,this)),
this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.OnCloseBtnHandle)),
this.m_handlerMgr.AddEventMgr(y.g.UITweenStateChanged,this.CreateDelegate(this.OnUITweenStateChanged))}RemoveLis(){
this.optBtn.node.off(l.NodeEventType.TOUCH_END,this.OnOptBtnHandle,this),I.i.Inst.RemoveEventHandler(D.i.NEWBIE_WEAR_EQUIP,(0,h.v)(this.OnOptBtnHandle,this))}OnOptBtnHandle(){
null!=this.subPanel&&(0,c.t2)(this.subPanel,R.k)&&this.subPanel.OnOptBtnHandle()}OnCloseBtnHandle(){null!=this.subPanel&&(0,
c.t2)(this.subPanel,R.k)&&this.subPanel.OnCloseBtnHandle()}SetIconByAtlasAndName(t,e,s,i,n=!1){if(null==t||""==t||""==e||""==e)return
null==s&&(s=1),null==i&&(i=f.P.zero_get()),this.icon.setSkin("atlas/"+t+"/"+e),this.iconWidget.setScale(new l.math.Vec3(s,s,s)),this.icon.node.transform.SetLocalPosition(i)
const o=O.M.DealRichTextOutline(this.btnDescTxt.string)
this.btnDescTxt.string=o,this.icon.sizeMode=n?l.Sprite.SizeMode.TRIMMED:l.Sprite.SizeMode.CUSTOM}ForcePlayAni(){this.OnUITweenStateChanged(this.isout,!0)}
OnUITweenStateChanged(t,e){null==e&&(e=!1),(this.isout!=t||e)&&(this.isout=t,this.node.visible=!t)}MoveAnchors(){}SetCommonCompAct(t){this.optBtn.node.SetActive(t),
this.closeBtn.node.SetActive(t),this.baseItem.node.SetActive(t),this.icon.node.SetActive(t),this.descTxt.node.SetActive(t),this.bgObj.SetActive(t)}ShowTip(t){const e=t.tipType
if(t.tipType==b.q.GetElementCarveTip);else if(this.curtipdata==t)return
this.curtipdata=t,this.Reset(),this.SetCommonCompAct(!0),this.CheckIsShow(e)
const s=this.typeGoDic[e]
null!=s?(s.node.SetActive(!0),(0,c.t2)(s,R.k)&&(s.fatherView=this,this.subPanel=s),s.SetData(t)):_.Y.LogError(`出现未定义的弹窗类型:${(0,c.tw)(e)}`)}HideFakeObj(){for(const[t,e]of(0,
d.vy)(this.typeGoDic))e.node.SetActive(!1)
this.SetCommonCompAct(!1)}Reset(){for(const[t,e]of(0,d.vy)(this.typeGoDic))e.Clear()
this.subPanel=null,this.HideFakeObj(),this.icon.node.transform.SetLocalPositionXYZ(1,1,1),this.SetSlider(1,1)}SetGetItemOrEquipPos(t){this.LogicNode.SetActive(t)}CheckIsShow(e){
const s=p.b.Inst.GetCurMap()
if(null==s||!s.hideElementsList.Contains(t.TIPFATHER))if(A.p.inst.IsInCopy()){const t=w.p.Inst_get().GetMapById(p.b.Inst.currentMapId_get())
if(t){if(t.controllerType==u.N.SPACE_MAZE&&e!=b.q.BossRefreshTip)return void this.SetGetItemOrEquipPos(!0)
if(t.controllerType==u.N.WORLD_BOSS||t.controllerType==u.N.WORLD_BOSS_NEWHAND||A.p.inst.IsInArenaCopy())return}if(e==b.q.GetEquipTip)this.SetGetItemOrEquipPos(!0)
else if(e==b.q.GetItemTip){const t=M.$.Inst().itemQueue.Count()-1
let e=null
if(t>=0&&(e=M.$.Inst().itemQueue[t]),null==e)return
if(null==e.data)return
const s=e.data.modelId,i=v.f.Inst().getItemById(s)
if(null==i)return
i.itemType==T.q.ALLIANCEBOSSHURT||3==i.whetherBatch?this.SetGetItemOrEquipPos(!0):this.SetGetItemOrEquipPos(!1)
}else e==b.q.AttrPointTip?this.SetGetItemOrEquipPos(!0):this.SetGetItemOrEquipPos(!1)}else this.SetGetItemOrEquipPos(!0)}CrossMapCheck(t){
t?null!=this.curtipdata?this.CheckIsShow(this.curtipdata.tipType):this.SetGetItemOrEquipPos(!0):this.SetGetItemOrEquipPos(!1)}},n.TIPFATHER=null,i=n))||i},93605:(t,e,s)=>{
var i,n=s(18998),l=s(68662),o=s(5924),a=s(98885),r=s(77399),h=s(37639),d=s(57035),c=s(47041),I=s(98359)
n._decorator.ccclass("ActivityTipView")(i=class extends I.k{constructor(){super(),this.curData=null,this.timerId=0,this._degf_CoundDownFun=null,this.funcRes=null,
this._degf_CoundDownFun=()=>this.CoundDownFun()}InitView(){super.InitView()}SetData(){this.AddLis()
const t=c.N.Inst_get().GetCurRecord()
this.curData=t,this.funcRes=d.d.Inst_get().getItemById(this.curData.functionId),this.fatherView.descTxt.textSet(`${this.funcRes.name}开始`)
const e=r.x.Inst_get().GetTimeLimitRes(this.curData.timeLimitType)
this.fatherView.baseItem.node.SetActive(!1),this.fatherView.optBtn.SetText(a.M.DealRichTextOutline("点击前往")),this.fatherView.SetIconByAtlasAndName("huodongicon2",e.tipsIcon,1),
this.ClearCountDown(),this.CoundDownFun(),this.timerId=o.C.Inst_get().SetInterval(this._degf_CoundDownFun,500)}ClearCountDown(){
0!=this.timerId&&(o.C.Inst_get().ClearInterval(this.timerId),this.timerId=0)}CoundDownFun(){this.curData.endTime-l.D.serverTime_get()<0&&(this.ClearCountDown(),
this.OnCloseBtnHandle())}Clear(){this.RemoveLis(),super.Clear(),this.funcRes=null,this.ClearCountDown()}AddLis(){super.AddLis()}RemoveLis(){super.RemoveLis()}OnCloseBtnHandle(){
c.N.Inst_get().ActivityDeQueue()}OnOptBtnHandle(){const t=this.funcRes.id
h.K.OnClickHandelByFuncId(t),this.OnCloseBtnHandle()}})},94529:(t,e,s)=>{
var i,n=s(18998),l=s(98800),o=s(98885),a=s(84485),r=s(78592),h=s(54130),d=s(51965),c=s(47041),I=s(36713),u=s(98359)
n._decorator.ccclass("AttrPointTipPanel")(i=class extends u.k{constructor(...t){super(...t),this.roleInfoId=null}InitView(){super.InitView()}AddLis(){super.AddLis()}RemoveLis(){
super.RemoveLis()}OnCloseBtnHandle(){c.N.Inst_get().AttrPointTipDeQueue(this.roleInfoId)}OnOptBtnHandle(){if(this.roleInfoId){const t=l.Y.Inst.getRoleInfo(this.roleInfoId)
a.X.Inst_get().waitAddPoint=null,r.l.Inst().OpenByParam(!0,h.Q.Normal,d.f.AddAttrs,t.createIdx)}c.N.Inst_get().AttrPointTipDeQueue(this.roleInfoId)}SetData(){
const t=c.N.Inst_get().model.GetDataByTipsType(I.q.AttrPointTip,0)
this.roleInfoId=t[t.Count()-1].playerId,this.AddLis()
this.fatherView.optBtn.SetText(o.M.DealRichTextOutline("点击前往")),this.fatherView.descTxt.textSet("[dba968]分配属性点[-]"),this.fatherView.baseItem.node.SetActive(!1),
this.fatherView.SetIconByAtlasAndName("mainui","rymainui_open_1025",1.1,null,!1),this.fatherView.icon.node.transform.height=76,this.fatherView.icon.node.transform.width=76}Clear(){
this.RemoveLis(),super.Clear()}Destroy(){super.Destroy()}})},70351:(t,e,s)=>{var i,n=s(18998),l=s(98885),o=s(48933),a=s(60128),r=s(56955),h=s(47041),d=s(98359)
n._decorator.ccclass("GameGMOfflineTip")(i=class extends d.k{InitView(){super.InitView()}Destroy(){super.Destroy()}AddLis(){super.AddLis()}RemoveLis(){super.RemoveLis()}SetData(){
this.AddLis(),this.fatherView.descTxt.textSet("[dba968]有离线挂机收益[-]"),this.fatherView.baseItem.node.SetActive(!1),this.fatherView.optBtn.SetText(l.M.DealRichTextOutline("点击前往")),
o.I.calVec0.Set(1.5,5,0),this.fatherView.SetIconByAtlasAndName("huodongicon2","ryhongdongicon2_sp_0020",1,o.I.calVec0)}OnCloseBtnHandle(){h.N.Inst_get().GameGMOfflineDeQueue()}
OnOptBtnHandle(){a.t.ins.OpenPanel(r.g.TAB_AUTO),h.N.Inst_get().GameGMOfflineDeQueue()}Clear(){this.RemoveLis(),super.Clear()}})},66957:(t,e,s)=>{
var i,n=s(18998),l=s(86133),o=s(98800),a=s(5924),r=s(98885),h=s(63076),d=s(18152),c=s(85751),I=s(87530),u=s(20364),p=s(33138),_=s(12399),g=s(47041),m=s(28963),S=s(98359)
n._decorator.ccclass("GetElementTipPanel")(i=class extends S.k{constructor(...t){super(...t),this.equipQueue=null,this.baseData=null,this.timeId=null}InitView(){super.InitView()}
Clear(){this.UnRegGuide(),this.equipQueue=null,this.RemoveLis(),this.ClearTimer(),this.baseData=null,super.Clear()}Destroy(){super.Destroy()}RegGuide(){}UnRegGuide(){}
CheckGuide(){}AddLis(){this.RegGuide(),super.AddLis()}RemoveLis(){super.RemoveLis()}OnCloseBtnHandle(){g.N.Inst_get().GetElementDeQueue()}OnOptBtnHandle(){
const t=this.equipQueue[this.equipQueue.Count()-1].tipSubType==m.p.SubEquipTips,e=this.equipQueue[this.equipQueue.Count()-1].tipSubType==m.p.SubViewEquipTips
;(t||e)&&I.L.Inst().OpenEleMianViewByData(this.baseData)}GetRoleInfoByData(t){const e=o.Y.Inst.GetMultPlayerInfos()
let s=-1,i=null
for(let n=0;n<=e.Count()-1;n++){const l=e[n]
if(u.D.IsWearForRole(l,t,!1)&&u.D.IsTakeOnJob(l.Job_get(),t.cfgData_get().Jobs_get())){const e=u.D.GetUpScoreForRole(l,t)
e>s&&(i=l,s=e)}}return i}SetButtonState(){
const t=this.equipQueue[this.equipQueue.Count()-1].tipSubType==m.p.SubEquipTips,e=this.equipQueue[this.equipQueue.Count()-1].tipSubType==m.p.SubViewEquipTips
t?this.fatherView.optBtn.SetText(r.M.DealRichTextOutline((0,l.T)("镶嵌元素"))):e&&this.fatherView.optBtn.SetText(r.M.DealRichTextOutline((0,l.T)("点击查看")))}SetData(){
if(this.equipQueue=_.f.Inst().GetElementTipsData(),this.fatherView.icon.node.SetActive(!1),null!=this.equipQueue&&this.equipQueue.Count()>0){this.AddLis()
const t=this.equipQueue[this.equipQueue.Count()-1].element,e=t.modelId,s=p.f.Inst().getItemById(e)
this.SetButtonState()
const i=s.Quality_get(),n=c.u.getColorStrsByBrightQuality(i)
if(this.fatherView.descTxt.textSet(`[${n}]${s.name}[-]`),this.baseData=new h.M(e,t),!this.ShowJudge())return void g.N.Inst_get().GetElementDeQueue()
this.baseData.IconType_Set(d.s.EQUIP_UP_ICON_TYPE),this.fatherView.baseItem.SetData(this.baseData),this.AddTimer()}else g.N.Inst_get().GetElementDeQueue()}ShowJudge(){
return!(this.equipQueue[this.equipQueue.Count()-1].tipSubType==m.p.SubEquipTips)||!!_.f.Inst().IsCanShow(this.baseData)}AddTimer(){-1!=this.timeId&&this.ClearTimer(),
this.timeId=a.C.Inst_get().SetInterval(this.CreateDelegate(this.RefreshLeftTime),1e3,-1),this.RefreshLeftTime()}RefreshLeftTime(){null!=this.baseData||(this.ClearTimer(),
g.N.Inst_get().GetElementDeQueue())}ClearTimer(){-1!=this.timeId&&(a.C.Inst_get().ClearInterval(this.timeId),this.timeId=-1)}})},30355:(t,e,s)=>{
var i,n=s(18998),l=s(86133),o=s(98800),a=s(86094),r=s(5924),h=s(85682),d=s(21554),c=s(70850),I=s(86770),u=s(63076),p=s(2227),_=s(18152),g=s(23628),m=s(87923),S=s(44498),f=s(68561),C=s(33138),T=s(22662),y=s(65550),A=s(5633),v=s(47041),D=s(28963),w=s(98359),B=s(98885)
n._decorator.ccclass("GetEquipTipPanel")(i=class extends w.k{constructor(...t){super(...t),this.baseData=null,this.timeId=-1,this.equipQueue=null}InitView(){super.InitView()}
Clear(){this.UnRegGuide(),this.equipQueue=null,this.RemoveLis(),this.ClearTimer(),this.baseData=null,super.Clear()}Destroy(){super.Destroy()}RegGuide(){}UnRegGuide(){}CheckGuide(){
m.l.CheckBtnClickTrigger(h.D.UI_MAIN_USE_NOTICE)}AddLis(){super.AddLis(),this.RegGuide()}RemoveLis(){super.RemoveLis()}OnCloseBtnHandle(){v.N.Inst_get().GetEquipDeQueue()}
OnOptBtnHandle(){const t=this.equipQueue[this.equipQueue.Count()-1].tipSubType==D.p.SubEquipTips,e=this.equipQueue[this.equipQueue.Count()-1].tipSubType==D.p.SubViewEquipTips
if(t){this.CheckGuide()
const t=this.equipQueue[this.equipQueue.Count()-1]
if(null==t||null==t.equip)return v.N.Inst_get().GetEquipDeQueue(),void y.y.inst.ClientStrMsg(T.r.SystemTipMessage,(0,l.T)("已穿戴该装备"))
const e=t.equip,s=new u.M(e.modelId,e)
let i=!0,n=null,a=null
const r=o.Y.Inst.GetMultPlayerInfos()
if(f.X.Inst_get().GetEquipExcellenceCount(s.serverData_get(),s.equipInfo_get())<2)n=this.GetRoleInfoByData(s),i=!1
else for(let t=0;t<=r.Count()-1;t++)if(n=r[t],g.b.IsWearForRole(n,s,!1)&&g.b.IsTakeOnJob(n.Job_get(),s.cfgData_get().Jobs_get())){const e=S.I.Score(s,n.Job_get(),n)
if(g.b.GetUpScore(n,s)==e){i=!1
break}a=r[t],i=!0}else n=null
if(null!=n&&!i)return void(g.b.IsWearForRole(n,s)?d.J.Inst_get().RecommendTakeOnEquip(n,s):(c.g.Inst_get().select_open_item_id=s.serverData_get().Id_get(),
c.g.Inst_get().default_open_tip=!1,d.J.Inst_get().openOrClose(I.D.bagTab)))
if(null!=a&&i)return c.g.Inst_get().select_open_item_id=t.equip.id,void d.J.Inst_get().openOrClose(I.D.bagTab)
v.N.Inst_get().GetEquipDeQueue()}else e&&(d.J.Inst_get().openOrClose(I.D.bagTab,p.Y.Dynamic),v.N.Inst_get().ViewEquipDeQueue())}GetRoleInfoByData(t){
const e=o.Y.Inst.GetMultPlayerInfos()
let s=-1,i=null
for(let n=0;n<=e.Count()-1;n++){const l=e[n]
if(g.b.IsWearForRole(l,t,!1)&&g.b.IsTakeOnJob(l.Job_get(),t.cfgData_get().Jobs_get())){const e=g.b.GetUpScore(l,t)
e>s&&(i=l,s=e)}}return i}SetButtonState(){
const t=this.equipQueue[this.equipQueue.Count()-1].tipSubType==D.p.SubEquipTips,e=this.equipQueue[this.equipQueue.Count()-1].tipSubType==D.p.SubViewEquipTips
t?this.fatherView.optBtn.SetText(B.M.DealRichTextOutline((0,l.T)("点击穿戴"))):e&&this.fatherView.optBtn.SetText(B.M.DealRichTextOutline((0,l.T)("点击查看")))
const s=B.M.DealRichTextOutline(this.fatherView.optBtn.richText.string)
this.fatherView.optBtn.richText.string=s}SetScrollLabel(t,e,s){const i=m.l.SetEquipName(t,e,s,null,null,null,null,null,null,null,null,!0,"")[0]
this.fatherView.descTxt.textSet(i)}SetData(){if(this.equipQueue=A.F.Inst().GetEquipTipsData(),this.fatherView.icon.node.SetActive(!1),
null!=this.equipQueue&&this.equipQueue.Count()>0){this.AddLis()
const t=this.equipQueue[this.equipQueue.Count()-1].equip,e=t.modelId,s=C.f.Inst().getItemById(e),i=new a.C(e)
if(this.SetButtonState(),this.SetScrollLabel(i,s,t),this.baseData=new u.M(e,t),!this.ShowJudge()||g.b.IsTimeOut(t))return void v.N.Inst_get().GetEquipDeQueue()
this.baseData.IconType_Set(_.s.EQUIP_UP_ICON_TYPE),this.fatherView.baseItem.SetData(this.baseData),this.AddTimer()}else v.N.Inst_get().GetEquipDeQueue()}ShowJudge(){
return!(this.equipQueue[this.equipQueue.Count()-1].tipSubType==D.p.SubEquipTips)||!!A.F.Inst().IsCanShow(this.baseData)}AddTimer(){-1!=this.timeId&&this.ClearTimer(),
this.timeId=r.C.Inst_get().SetInterval(this.CreateDelegate(this.RefreshLeftTime),1e3,-1),this.RefreshLeftTime()}RefreshLeftTime(){
null!=this.baseData?g.b.IsTimeOut(this.baseData.serverData_get())&&(this.ClearTimer(),v.N.Inst_get().GetEquipDeQueue()):(this.ClearTimer(),v.N.Inst_get().GetEquipDeQueue())}
ClearTimer(){-1!=this.timeId&&(r.C.Inst_get().ClearInterval(this.timeId),this.timeId=-1)}})},81035:(t,e,s)=>{
var i=s(18998),n=s(38836),l=s(86133),o=s(38045),a=s(98800),r=s(97461),h=s(13687),d=s(5924),c=s(85682),I=s(31222),u=s(98885),p=s(85602),_=s(38962),g=s(21554),m=s(70850),S=s(95272),f=s(63076),C=s(76645),T=s(23628),y=s(92679),A=s(33314),v=s(55661),D=s(85751),w=s(33138),B=s(34402),M=s(10509),b=s(47786),O=s(22662),R=s(68637),L=s(65550),G=s(21334),P=s(57647),E=s(68662),k=s(66788),N=s(56937),V=s(18202),x=s(5494),F=s(52726),U=s(87923),H=s(50089),j=s(43133),W=s(99294),Y=s(9986),q=s(6665),z=s(9776),Z=s(86290),X=s(93877),Q=s(8889),J=s(72005),$=s(13113),K=s(61911),tt=s(37142),et=s(83540),st=s(78300),it=s(35128),nt=s(98130),lt=s(52212),ot=s(79534),at=s(44758),rt=s(1240),ht=s(70093),dt=s(75696),ct=s(80062),It=s(48933),ut=s(37648),pt=s(30421),_t=s(72835),gt=(s(1143),
s(48481)),mt=s(94998),St=s(43308),ft=s(67020),Ct=s(87144),Tt=s(41347),yt=s(8816),At=s(9057),vt=s(57834)
class Dt extends At.x{constructor(){super(),this.iconBg=null,this.icon=null,this.selectBg=null,this.num=null,this.selectIcon=null,this.data=null,this._degf_OnSelect=null,
this._degf_OnSelect=(t,e)=>this.OnSelect(t,e)}InitView(){this.iconBg=new J.w,this.iconBg.setId(this.FatherId,this.FatherComponentID,1),this.icon=new J.w,
this.icon.setId(this.FatherId,this.FatherComponentID,2),this.selectBg=new W.z,this.selectBg.setId(this.FatherId,this.FatherComponentID,3),this.num=new X.Q,
this.num.setId(this.FatherId,this.FatherComponentID,4),this.selectIcon=new W.z,this.selectIcon.setId(this.FatherId,this.FatherComponentID,5)}Destroy(){this.iconBg=null,
this.icon=null,this.selectBg=null,this.num=null,this.selectIcon=null}SetData(t){this.AddListeners(),this.data=t
const e=U.l.GetItemQualityImg(this.data.bag.baseData_get())
this.iconBg.spriteNameSet(e),V.g.SetItemIcon(this.icon.FatherId,this.icon.ComponentId,this.data.bag.baseData_get().cfgData_get().icon,et.b.eItem,!1),
this.num.textSet(u.M.IntToString(this.data.bag.serverData_get().num))
const s=Tt.i.Inst_get().selectRewardList.Contains(this.data.group)
this.selectIcon.SetActive(s),this.selectBg.SetActive(!1)}Clear(){this.RemoveListeners(),this.data=null}AddListeners(){vt.i.Get(this.icon.node).RegistonClick(this._degf_OnSelect)}
RemoveListeners(){vt.i.Get(this.icon.node).RemoveonClick(this._degf_OnSelect)}OnSelect(t,e){Bt.Inst_get().OnSelectReward()}}class wt extends K.f{constructor(){super(),
this.close=null,this.rewards=null,this.tips=null,this.open=null,this.bg=null,this._degf_CreateSelectItem=null,this._degf_OnClose=null,this._degf_OnOpen=null,
this._degf_CreateSelectItem=t=>this.CreateSelectItem(t),this._degf_OnClose=(t,e)=>this.OnClose(t,e),this._degf_OnOpen=(t,e)=>this.OnOpen(t,e)}InitView(){this.close=new Y.W,
this.close.setId(this.FatherId,this.FatherComponentID,1),this.rewards=new q.A,this.rewards.setId(this.FatherId,this.FatherComponentID,2),
this.rewards.SetInitInfo("ui_pandora_selectitem",this._degf_CreateSelectItem),this.tips=new X.Q,this.tips.setId(this.FatherId,this.FatherComponentID,3),this.open=new Y.W,
this.open.setId(this.FatherId,this.FatherComponentID,4),this.bg=new J.w,this.bg.setId(this.FatherId,this.FatherComponentID,5),this.isExclusionPanel=!0}OnAddToScene(){
this.AddListeners()
const t=Bt.Inst_get().itemData
this.rewards.data_set(this.GetRewardItemData(t.baseData_get().cfgData_get().id)),this.UpdateTips()}Clear(){this.RemoveListeners(),Tt.i.Inst_get().selectRewardList.Clear()}
Destroy(){this.close=null,this.rewards.Destroy(),this.rewards=null,this.tips=null,this.open=null,this.bg=null}AddListeners(){this.AddClickEvent(this.close,this._degf_OnClose),
this.AddClickEvent(this.open,this._degf_OnOpen)}RemoveListeners(){this.RemoveClickEvent(this.close,this._degf_OnClose),this.RemoveClickEvent(this.open,this._degf_OnOpen)}
OnClose(t,e){Bt.Inst_get().CloseView()}OnOpen(t,e){const s=Bt.Inst_get().itemData,i=B.$.Inst().GetOptionalNum(s.baseData_get().cfgData_get().id),l=Tt.i.Inst_get().selectRewardList
if(l.Count()<i){const t=i-l.Count(),e=b.x.Inst().getItemById(101507),s=u.M.Replace(e.sys_messsage,"{0}",u.M.IntToString(t))
L.y.inst.ClientStrMsg(O.r.SystemTipMessage,s)}else{let t=""
for(const[e,s]of(0,n.V5)(l))""==t?t=u.M.IntToString(s):t+=`,${u.M.IntToString(s)}`
const e=new _.X
e.LuaDic_AddOrSetItem("optionals",t),g.J.Inst_get().CM_UseItemReq(s.serverData_get().id,1,e),Bt.Inst_get().CloseView()}}UpdateTips(){
const t=Bt.Inst_get().itemData,e=B.$.Inst().GetOptionalNum(t.baseData_get().cfgData_get().id),s=Tt.i.Inst_get().selectRewardList
if(s.Count()<e){const t=e-s.Count(),i=u.M.Replace((0,l.T)("还需要选择[5FB470]{0}[-]个奖励"),"{0}",u.M.IntToString(t))
this.tips.textSet(i)}else this.tips.textSet((0,l.T)("奖励已选满"))}GetSelectItem(t){let e=0
for(;e<this.rewards.itemList.Count();){const s=this.rewards.itemList[e]
if(null!=s&&null!=s.data&&s.data.group==t)return s
e+=1}return null}CreateSelectItem(t){const e=new Dt
return e.setId(t,null,0),e}GetRewardItemData(t){const e=new p.Z,s=B.$.Inst().GetRewardList(t)
for(const[t,i]of(0,n.V5)(s)){const t=new gt.t
t.modelId=i.itemId,0==i.num?t.num=1:t.num=i.num
const s=new rt.Y
s.serverData_set(t),s.baseData_get().isCanOperate=!1,s.baseData_get().isShowAccess=!1,s.baseData_get().isEquipCompare=!1,0!=i.showId&&s.SetEquipAttrShowId(i.showId)
const n=new yt.O
n.bag=s,n.group=u.M.String2Int(i.id),e.Add(n)}return e}}class Bt{constructor(){this.itemData=null,this.view=null,this.previewMode=!1,this._degf_CallDestory=null,
this._degf_Complete=null,this._degf_CallDestory=()=>this.CallDestory(),this._degf_Complete=t=>this.Complete(t)}static Inst_get(){return null==Bt._inst&&(Bt._inst=new Bt),Bt._inst}
OpenView(t){if(null!=this.view&&this.view.isShow_get())return
null!=this.view&&this.view.node.SetActive(!0),this.itemData=t
const e=new N.v
e.layerType=F.F.MainUI,I.N.inst.OpenById(x.I.PandoraSelectPanel,this._degf_Complete,this._degf_CallDestory,e)}Complete(t){return null==this.view&&(this.view=new wt,
this.view.setId(t,null,0)),this.view}CallDestory(){V.g.DestroyUIObj(this.view),this.view=null}CloseView(){
null!=this.view&&this.view.isShow_get()&&I.N.inst.CloseById(x.I.PandoraSelectPanel)}OnSelectReward(t){if(this.previewMode)return void this.OnTips(t,!0)
const e=Tt.i.Inst_get().selectRewardList
if(e.Contains(t.data.group))e.Remove(t.data.group),t.selectIcon.SetActive(!1)
else{const s=B.$.Inst().GetOptionalNum(this.itemData.baseData_get().cfgData_get().id)
if(e.Count()>=s){const t=this.view.GetSelectItem(e[0])
e.Remove(t.data.group),t.selectIcon.SetActive(!1)}e.Add(t.data.group),t.selectIcon.SetActive(!0),this.OnTips(t,!0)}this.view.UpdateTips()}OnTips(t,e){if(e){
const e=this.view.node.transform.GetLocalPosition(),s=this.view.bg.width()
let i=0
i=e.x+s/2+Ct.Q.equip_width/2,t.data.bag.baseData_get().tipsPos=new ot.P(i,0,0),g.J.Inst_get().ShowItemTip(t.data.bag.baseData_get())}else g.J.Inst_get().CloseTipView()}}
Bt._inst=null
class Mt extends K.f{constructor(){super(),this.tip=null,this.icon=null,this.name=null,this.scrollView=null,this.root=null,this.level=null,this.vipTip=null,this.vip=null,
this.timeTip=null,this.time=null,this.desc=null,this.rewards=null,this.open=null,this.select=null,this.pay=null,this.payType=null,this.payNum=null,this.access=null,this.grid1=null,
this.bg=null,this.timeObj=null,this.descObj=null,this.rewardsObj=null,this.btnObj=null,this.scrollPanel=null,this.scrollBack=null,this.payTip=null,this.payTypeSp=null,
this.payLabel=null,this.moreBtn=null,this.sellBtn=null,this.auctionBtn=null,this.tradeBtn=null,this.composeBtn=null,this.backBagBtn=null,this.getOutBtn=null,this.chargeBtn=null,
this.bagToWarehouseBtn=null,this.warehouseToBagBtn=null,this.btnGrid=null,this.moreGrid=null,this.moreCollider=null,this.moreObj=null,this.moreSp=null,this.moreBg=null,
this.jobTip=null,this.jobLabel=null,this.lockObj=null,this.levelTip=null,this.isMoreClosing=!1,this.closeMoreInterval=-1,this.moreSpRotation=null,this.itemType=null,
this.conditionObj=null,this.qualityBg=null,this.obtainWayBtn=null,this.qualityAnimOne=null,this.qualityAnimTwo=null,this.qualityAnimThree=null,this.qualityAnimFour=null,
this.qualityAnimFive=null,this.qualityAnimSix=null,this.qualityAnimList=null,this.noBtnPanelSize=null,this.hasBtnPanelSize=null,this.btnObjPos=null,this.moreObjPos=null,
this.m_bgWidth=412,this.bgHeight=592,this.btnShowCnt=0,this.bgOffset=0,this.normalColor="[ffefe1]",this.activeColor="[ffefe1]",this.inactiveColor="[fe2e2d]",
this._leftTimeIntervalId=-1,this._lefttime=0,this.btnList=null,this.btnShowState=null,this.bagItemData=null,this._degf_OnAuctionBtnClick=null,this._degf_BackBagBtnClick=null,
this._degf_BagToWarehouseBtnClick=null,this._degf_ChargeBtnClick=null,this._degf_ClickTipsCallback=null,this._degf_CloseMore=null,this._degf_CreateRewardItem=null,
this._degf_LeftTimeChange=null,this._degf_OnAccess=null,this._degf_OnComposeBtnClick=null,this._degf_OnGetOutBtnClick=null,this._degf_OnMask=null,this._degf_OnOpen=null,
this._degf_OnPay=null,this._degf_OnSelect=null,this._degf_OnSellBtnClick=null,this._degf_RefreshRewardItem=null,this._degf_ResetClosingState=null,this._degf_ShowMore=null,
this._degf_TradeBtnClick=null,this._degf_WarehouseToBagBtnClick=null,this.moreSpRotation=new ot.P(0,180,180),this.qualityAnimList=new p.Z,
this.noBtnPanelSize=new at.L(0,-37,395,442),this.hasBtnPanelSize=new at.L(0,0,395,367),this.btnObjPos=new ot.P(0,-252,0),this.moreObjPos=new ot.P(0,0,0),this.btnList=new p.Z,
this.btnShowState=new p.Z,this._degf_OnAuctionBtnClick=(t,e)=>this.OnAuctionBtnClick(t,e),this._degf_BackBagBtnClick=(t,e)=>this.BackBagBtnClick(t,e),
this._degf_BagToWarehouseBtnClick=(t,e)=>this.BagToWarehouseBtnClick(t,e),this._degf_ChargeBtnClick=(t,e)=>this.ChargeBtnClick(t,e),
this._degf_ClickTipsCallback=t=>this.ClickTipsCallback(t),this._degf_CloseMore=(t,e)=>this.CloseMore(t,e),this._degf_CreateRewardItem=t=>this.CreateRewardItem(t),
this._degf_LeftTimeChange=()=>this.LeftTimeChange(),this._degf_OnAccess=(t,e)=>this.OnAccess(t,e),this._degf_OnComposeBtnClick=(t,e)=>this.OnComposeBtnClick(t,e),
this._degf_OnGetOutBtnClick=(t,e)=>this.OnGetOutBtnClick(t,e),this._degf_OnMask=(t,e)=>this.OnMask(t,e),this._degf_OnOpen=(t,e)=>this.OnOpen(t,e),
this._degf_OnPay=(t,e)=>this.OnPay(t,e),this._degf_OnSelect=(t,e)=>this.OnSelect(t,e),this._degf_OnSellBtnClick=(t,e)=>this.OnSellBtnClick(t,e),
this._degf_RefreshRewardItem=()=>this.RefreshRewardItem(),this._degf_ResetClosingState=()=>this.ResetClosingState(),this._degf_ShowMore=(t,e)=>this.ShowMore(t,e),
this._degf_TradeBtnClick=(t,e)=>this.TradeBtnClick(t,e),this._degf_WarehouseToBagBtnClick=(t,e)=>this.WarehouseToBagBtnClick(t,e)}BgOffset_get(){return this.bgOffset}
BgOffset_set(t){this.bgOffset=t<-340?-340:t>0?0:t
let e=new ot.P(this.btnObjPos.x,this.btnObjPos.y-this.bgOffset,this.btnObjPos.z)
this.btnObj.transform.SetLocalPosition(e),ot.P.Recyle(e),this.bg.heightSet(nt.GF.INT(this.bgHeight+this.bgOffset)),
e=new ot.P(this.moreObjPos.x,this.moreObjPos.y-this.bgOffset,this.moreObjPos.z),this.moreObj.transform.SetLocalPosition(e),ot.P.Recyle(e)}InitView(){this.tip=new W.z,
this.tip.setId(this.FatherId,this.FatherComponentID,1),this.icon=new J.w,this.icon.setId(this.FatherId,this.FatherComponentID,2),this.name=new X.Q,
this.name.setId(this.FatherId,this.FatherComponentID,3),this.scrollView=new z.h,this.scrollView.setId(this.FatherId,this.FatherComponentID,4),this.root=new W.z,
this.root.setId(this.FatherId,this.FatherComponentID,5),this.level=new X.Q,this.level.setId(this.FatherId,this.FatherComponentID,6),this.vipTip=new W.z,
this.vipTip.setId(this.FatherId,this.FatherComponentID,7),this.vip=new X.Q,this.vip.setId(this.FatherId,this.FatherComponentID,8),this.timeTip=new W.z,
this.timeTip.setId(this.FatherId,this.FatherComponentID,9),this.time=new X.Q,this.time.setId(this.FatherId,this.FatherComponentID,10),this.desc=new X.Q,
this.desc.setId(this.FatherId,this.FatherComponentID,11),this.rewards=new q.A,this.rewards.setId(this.FatherId,this.FatherComponentID,12),
this.rewards.SetInitInfo("ui_baseitem",this._degf_CreateRewardItem),this.rewards.OnReposition_set(this._degf_RefreshRewardItem),this.open=new Y.W,
this.open.setId(this.FatherId,this.FatherComponentID,13),this.select=new Y.W,this.select.setId(this.FatherId,this.FatherComponentID,14),this.pay=new Y.W,
this.pay.setId(this.FatherId,this.FatherComponentID,15),this.payType=new J.w,this.payType.setId(this.FatherId,this.FatherComponentID,16),this.payNum=new X.Q,
this.payNum.setId(this.FatherId,this.FatherComponentID,17),this.access=new Y.W,this.access.setId(this.FatherId,this.FatherComponentID,18),this.grid1=new q.A,
this.grid1.setId(this.FatherId,this.FatherComponentID,20),this.bg=new J.w,this.bg.setId(this.FatherId,this.FatherComponentID,21),this.timeObj=new W.z,
this.timeObj.setId(this.FatherId,this.FatherComponentID,22),this.descObj=new W.z,this.descObj.setId(this.FatherId,this.FatherComponentID,23),this.rewardsObj=new W.z,
this.rewardsObj.setId(this.FatherId,this.FatherComponentID,24),this.btnObj=new W.z,this.btnObj.setId(this.FatherId,this.FatherComponentID,25),this.scrollPanel=new Q.$,
this.scrollPanel.setId(this.FatherId,this.FatherComponentID,26),this.scrollBack=new $.T,this.scrollBack.setId(this.FatherId,this.FatherComponentID,27),this.payTip=new W.z,
this.payTip.setId(this.FatherId,this.FatherComponentID,28),this.payTypeSp=new J.w,this.payTypeSp.setId(this.FatherId,this.FatherComponentID,29),this.payLabel=new X.Q,
this.payLabel.setId(this.FatherId,this.FatherComponentID,30),this.moreBtn=new Y.W,this.moreBtn.setId(this.FatherId,this.FatherComponentID,31),this.sellBtn=new Y.W,
this.sellBtn.setId(this.FatherId,this.FatherComponentID,32),this.auctionBtn=new Y.W,this.auctionBtn.setId(this.FatherId,this.FatherComponentID,33),this.tradeBtn=new Y.W,
this.tradeBtn.setId(this.FatherId,this.FatherComponentID,34),this.composeBtn=new Y.W,this.composeBtn.setId(this.FatherId,this.FatherComponentID,35),this.backBagBtn=new Y.W,
this.backBagBtn.setId(this.FatherId,this.FatherComponentID,36),this.getOutBtn=new Y.W,this.getOutBtn.setId(this.FatherId,this.FatherComponentID,37),this.chargeBtn=new Y.W,
this.chargeBtn.setId(this.FatherId,this.FatherComponentID,38),this.bagToWarehouseBtn=new Y.W,this.bagToWarehouseBtn.setId(this.FatherId,this.FatherComponentID,39),
this.warehouseToBagBtn=new Y.W,this.warehouseToBagBtn.setId(this.FatherId,this.FatherComponentID,40),this.btnGrid=new q.A,
this.btnGrid.setId(this.FatherId,this.FatherComponentID,41),this.moreGrid=new q.A,this.moreGrid.setId(this.FatherId,this.FatherComponentID,42),this.moreCollider=new j.V,
this.moreCollider.setId(this.FatherId,this.FatherComponentID,43),this.moreObj=new W.z,this.moreObj.setId(this.FatherId,this.FatherComponentID,44),this.moreSp=new Z.G,
this.moreSp.setId(this.FatherId,this.FatherComponentID,45),this.moreBg=new J.w,this.moreBg.setId(this.FatherId,this.FatherComponentID,46),this.jobTip=new W.z,
this.jobTip.setId(this.FatherId,this.FatherComponentID,47),this.jobLabel=new X.Q,this.jobLabel.setId(this.FatherId,this.FatherComponentID,48),this.itemType=new X.Q,
this.itemType.setId(this.FatherId,this.FatherComponentID,49),this.conditionObj=new W.z,this.conditionObj.setId(this.FatherId,this.FatherComponentID,50),this.qualityBg=new J.w,
this.qualityBg.setId(this.FatherId,this.FatherComponentID,51),this.lockObj=new W.z,this.lockObj.setId(this.FatherId,this.FatherComponentID,52),this.levelTip=new W.z,
this.levelTip.setId(this.FatherId,this.FatherComponentID,53),this.obtainWayBtn=new Y.W,this.obtainWayBtn.setId(this.FatherId,this.FatherComponentID,54),this.qualityAnimOne=new W.z,
this.qualityAnimOne.setId(this.FatherId,this.FatherComponentID,55),this.qualityAnimTwo=new W.z,this.qualityAnimTwo.setId(this.FatherId,this.FatherComponentID,56),
this.qualityAnimThree=new W.z,this.qualityAnimThree.setId(this.FatherId,this.FatherComponentID,57),this.qualityAnimFour=new W.z,
this.qualityAnimFour.setId(this.FatherId,this.FatherComponentID,58),this.qualityAnimFive=new W.z,this.qualityAnimFive.setId(this.FatherId,this.FatherComponentID,59),
this.qualityAnimSix=new W.z,this.qualityAnimSix.setId(this.FatherId,this.FatherComponentID,60),this.qualityAnimList.Add(null),this.qualityAnimList.Add(this.qualityAnimOne),
this.qualityAnimList.Add(this.qualityAnimTwo),this.qualityAnimList.Add(this.qualityAnimThree),this.qualityAnimList.Add(this.qualityAnimFour),
this.qualityAnimList.Add(this.qualityAnimFive),this.qualityAnimList.Add(this.qualityAnimSix),this.btnList.Add(this.open),this.btnList.Add(this.select),this.btnList.Add(this.pay),
this.btnList.Add(this.chargeBtn),this.btnList.Add(this.getOutBtn),this.btnList.Add(this.backBagBtn),this.btnList.Add(this.composeBtn),this.btnList.Add(this.tradeBtn),
this.btnList.Add(this.auctionBtn),this.btnList.Add(this.sellBtn),this.btnList.Add(this.bagToWarehouseBtn),this.btnList.Add(this.warehouseToBagBtn),
this.btnList.Add(this.obtainWayBtn)
let t=0
for(;t<this.btnList.Count();)this.btnShowState.Add(!1),t+=1
this.DestoryPanelLevel=K.f.DestoryLevel0}OnAddToScene(){this.bagItemData=bt.Inst_get().itemData,this.AddListeners(),this.UpdateView()}Clear(){this.RemoveListeners(),
St._.Inst_get().CloseView(),d.C.Inst_get().ClearInterval(this._leftTimeIntervalId),this._leftTimeIntervalId=-1}Destroy(){null!=this.btnGrid&&this.btnGrid.Destroy(),
null!=this.moreGrid&&this.moreGrid.Destroy(),this.tip=null,this.icon=null,this.name=null,this.scrollView=null,this.root=null,this.level=null,this.vipTip=null,this.vip=null,
this.timeTip=null,this.time=null,this.desc=null,this.rewards.Destroy(),this.rewards=null,this.open=null,this.select=null,this.pay=null,this.payType=null,this.payNum=null,
this.access=null,this.grid1.Destroy(),this.grid1=null,this.bg=null,this.timeObj=null,this.descObj=null,this.rewardsObj=null,this.btnObj=null,this.scrollPanel=null,
this.scrollBack=null,this.payTip=null,this.payTypeSp=null,this.payLabel=null,this.itemType=null,this.conditionObj=null,this.qualityBg=null,this.lockObj=null,this.obtainWayBtn=null
let t=0
for(;t<this.qualityAnimList.Count();)this.qualityAnimList[t]=null,t+=1
this.qualityAnimList.Clear(),this.qualityAnimList=null}SetQualityAnim(t){let e=1
for(;e<this.qualityAnimList.Count();)this.qualityAnimList[e].SetActive(!1),e+=1
0!=t&&t<this.qualityAnimList.Count()&&this.qualityAnimList[t].SetActive(!0)}AddListeners(){this.AddClickEvent(this.open,this._degf_OnOpen),
this.AddClickEvent(this.select,this._degf_OnSelect),this.AddClickEvent(this.pay,this._degf_OnPay),this.AddClickEvent(this.access,this._degf_OnAccess),
this.AddClickEvent(this.obtainWayBtn,this._degf_OnAccess),this.AddFullScreenCollider(this.node,this._degf_OnMask,this._degf_OnMask),
this.AddClickEvent(this.sellBtn,this._degf_OnSellBtnClick),this.AddClickEvent(this.getOutBtn,this._degf_OnGetOutBtnClick),
this.AddClickEvent(this.backBagBtn,this._degf_BackBagBtnClick),this.AddClickEvent(this.chargeBtn,this._degf_ChargeBtnClick),
this.AddClickEvent(this.moreCollider,this._degf_CloseMore),this.AddClickEvent(this.tradeBtn,this._degf_TradeBtnClick),this.AddClickEvent(this.moreBtn,this._degf_ShowMore),
this.AddClickEvent(this.composeBtn,this._degf_OnComposeBtnClick),this.AddClickEvent(this.bagToWarehouseBtn,this._degf_BagToWarehouseBtnClick),
this.AddClickEvent(this.warehouseToBagBtn,this._degf_WarehouseToBagBtnClick),this.AddClickEvent(this.auctionBtn,this._degf_OnAuctionBtnClick)}RemoveListeners(){
this.RemoveClickEvent(this.open,this._degf_OnOpen),this.RemoveClickEvent(this.select,this._degf_OnSelect),this.RemoveClickEvent(this.pay,this._degf_OnPay),
this.RemoveClickEvent(this.access,this._degf_OnAccess),this.RemoveClickEvent(this.obtainWayBtn,this._degf_OnAccess),this.RemoveFullScreenCollider(),
this.RemoveClickEvent(this.sellBtn,this._degf_OnSellBtnClick),this.RemoveClickEvent(this.getOutBtn,this._degf_OnGetOutBtnClick),
this.RemoveClickEvent(this.backBagBtn,this._degf_BackBagBtnClick),this.RemoveClickEvent(this.chargeBtn,this._degf_ChargeBtnClick),
this.RemoveClickEvent(this.moreCollider,this._degf_CloseMore),this.RemoveClickEvent(this.tradeBtn,this._degf_TradeBtnClick),this.RemoveClickEvent(this.moreBtn,this._degf_ShowMore),
this.RemoveClickEvent(this.composeBtn,this._degf_OnComposeBtnClick),this.RemoveClickEvent(this.bagToWarehouseBtn,this._degf_BagToWarehouseBtnClick),
this.RemoveClickEvent(this.warehouseToBagBtn,this._degf_WarehouseToBagBtnClick),this.RemoveClickEvent(this.auctionBtn,this._degf_OnAuctionBtnClick)}OnAuctionBtnClick(t,e){
bt.Inst_get().CloseView(),mt.W.GetInst().autoOpenGroundingItemId=this.bagItemData.baseData_get().serverData_get().id}OnFullScreenColliderInit(){
null!=this.bagItemData&&this.bagItemData.baseData_get().isForBag?(I.N.inst.SetFullScreenColliderMask(this.node.FatherId,!0),
I.N.inst.SetFullScreenColliderThrough(this.node.FatherId,!1)):(I.N.inst.SetFullScreenColliderMask(this.node.FatherId,!1),
I.N.inst.SetFullScreenColliderThrough(this.node.FatherId,!0))}OnSellBtnClick(t,e){null!=this.bagItemData&&g.J.Inst_get().SellItem(this.bagItemData),bt.Inst_get().CloseView()}
OnGetOutBtnClick(t,e){ct.a.inst.CM_TempPackTackReq(this.bagItemData.index_get()),bt.Inst_get().CloseView()}BackBagBtnClick(t,e){bt.Inst_get().CloseView()}ChargeBtnClick(t,e){
bt.Inst_get().CloseView()}CloseMore(t,e){this.moreObj.SetActive(!1),this.moreSp.SetLocalEulerAngles(this.moreSpRotation),this.isMoreClosing=!0,
this.closeMoreInterval=d.C.Inst_get().SetInterval(this._degf_ResetClosingState,100,1)}ResetClosingState(){this.isMoreClosing=!1}TradeBtnClick(t,e){bt.Inst_get().CloseView()}
ShowMore(t,e){if(this.moreBg.node.SetActive(!1),!this.isMoreClosing){this.moreObj.SetActive(!0)
const t=ot.P.zero_get()
this.moreSp.SetLocalEulerAngles(t)
let e=-1,s=0
for(;s<this.btnList.Count();)this.btnShowState[s]&&(e+=1),s+=1
this.moreBg.heightSet(56*e)}}OnComposeBtnClick(t,e){const s=this.bagItemData.baseData_get().cfgData_get().GetComposeID(),i=pt.c.Inst().getItemById(s)
null!=i&&(tt.V.Inst_get().JumpToRyCompoundPanel(i.composeTabs,s),bt.Inst_get().CloseView())}BagToWarehouseBtnClick(t,e){
if(null!=this.bagItemData&&null!=this.bagItemData.serverData_get()){const t=new _.X
t.LuaDic_AddOrSetItem(this.bagItemData.index_get(),-1),g.J.Inst_get().CM_StoreReq(t),bt.Inst_get().CloseView()}}WarehouseToBagBtnClick(t,e){
if(null!=this.bagItemData&&null!=this.bagItemData.serverData_get()){const t=new _.X
t.LuaDic_AddOrSetItem(this.bagItemData.index_get(),-1),g.J.Inst_get().CM_TakeReq(t),bt.Inst_get().CloseView()}}OnOpen(t,e){
const s=bt.Inst_get().itemData,i=B.$.Inst().getItemById(s.baseData_get().cfgData_get().id)
if(s.baseData_get().cfgData_get().hasOpenUIId()&&null!=i&&i.throwType){const t=G.p.Inst_get().GetMapById(h.b.Inst.currentMapId_get())
if(null!=t&&t.senceType==v.S.WildMap){I.N.inst.OpenUIByStrIdWithParam(s.baseData_get().cfgData_get().ui,this.bagItemData)&&bt.Inst_get().CloseView()}else{
const t=b.x.Inst().getItemById(101527)
null!=t&&L.y.inst.ClientStrMsg(O.r.SystemTipMessage,t.sys_messsage)}}else{if(0==s.baseData_get().cfgData_get().batch){const t=new _.X
t.LuaDic_AddOrSetItem("optionals",""),g.J.Inst_get().CM_UseItemReq(s.serverData_get().id,1,t)}else m.g.Inst_get().curSelectItemData.Clone(s,!0),g.J.Inst_get().OpenBatchAlert()
bt.Inst_get().CloseView()}}OnSelect(t,e){const s=bt.Inst_get().itemData
Bt.Inst_get().OpenView(s),bt.Inst_get().CloseView()}OnPay(t,e){const s=bt.Inst_get().itemData
g.J.Inst_get().OnConsumeItem(s,!0),bt.Inst_get().CloseView()}OnAccess(t,e){if(St._.Inst_get().IsOpen())St._.Inst_get().CloseView()
else{const t=bt.Inst_get().itemData.baseData_get().cfgData_get().id,e=new ot.P(0,0,0)
St._.Inst_get().OpenByItem(t,e,this.bg)}}OnMask(t,e){bt.Inst_get().CloseView()}UpdateView(){this.btnShowCnt=1
let t=0
for(;t<this.btnList.Count();)this.btnShowState[t]=!1,t+=1
let e=this.btnList.Count()-1
for(;e>=0;)this.btnList[e].node.transform.SetParent(this.node.FatherId,this.node.ComponentId),e-=1
let s=this.btnList.Count()-1
for(;s>=0;)this.btnList[s].node.transform.SetParent(this.btnGrid.FatherId,this.btnGrid.ComponentId),s-=1
this.SetBtnShowState(this.obtainWayBtn,!0)
const i=this.GetBtnShowIndex(this.obtainWayBtn);-1!=i&&this.btnList[i].node.transform.SetParent(this.moreGrid.FatherId,this.moreGrid.ComponentId),this.moreObj.SetActive(!1),
this.moreSp.SetLocalEulerAngles(this.moreSpRotation),this.isMoreClosing=!1,d.C.Inst_get().ClearInterval(this.closeMoreInterval),this.closeMoreInterval=-1,this.tip.SetActive(!0)
const n=bt.Inst_get().itemData
this.OnFullScreenColliderInit()
const o=g.J.Inst_get().GetTipPosition(n.baseData_get().tipPosType)
this.node.transform.SetLocalPosition(o),ot.P.Recyle(o),V.g.SetItemIcon(this.icon.FatherId,this.icon.ComponentId,n.baseData_get().cfgData_get().icon,et.b.eItem,!1)
const r=`${U.l.GetqualityStrWithChar(n.baseData_get().Quality_get())}${n.baseData_get().cfgData_get().name}[-]`
this.name.textSet(r),this.itemType.textSet(n.baseData_get().cfgData_get().describeType),this.qualityBg.spriteNameSet(U.l.GetQulityBgName(n.baseData_get().Quality_get())),
this.lockObj.SetActive(n.baseData_get().IsBind())
const h=m.g.Inst_get().CheckHasGetway(n.baseData_get())
this.access.node.SetActive(h),this.SetBtnShowState(this.obtainWayBtn,h),St._.Inst_get().CloseView()
const c=n.baseData_get().cfgData_get().job
this.jobTip.SetActive(0!=c)
let I=""
if(0!=c){I=_t.V.Inst_get().JobRelationDict[a.Y.Inst.PrimaryRoleInfo_get().Job_get()].Contains(c)?`[cccbc4]${U.l.getJobStr(c)}[-]`:`[d43e3e]${U.l.getJobStr(c)}[-]`,
this.jobLabel.textSet(I)}const p=a.Y.Inst.PrimaryRoleInfo_get().Level_get(),_=n.baseData_get().cfgData_get().level
this.levelTip.SetActive(0!=_)
let S=""
p>=_?S=u.M.Replace("[cccbc4]{0}[-]","{0}",_):(S=u.M.Replace((0,l.T)("[cccbc4]{0}[-][d43e3e] (还差{1}级)[-]"),"{0}",_),S=u.M.Replace(S,"{1}",_-p)),this.level.textSet(S)
const f=Tt.i.Inst_get().GetVipLimit(n.baseData_get().cfgData_get().Conditions_get())
if(0==f)this.vipTip.SetActive(!1)
else{this.vipTip.SetActive(!0)
const t=a.Y.Inst.PrimaryRoleInfo_get().VipLevel_get()
let e=u.M.IntToString(f)
e=t>=f?u.M.Replace("[FFEFE1FF]{0}[-]","{0}",e):u.M.Replace("[E02C2CFF]{0}[-]","{0}",e),this.vip.textSet(e)}this.timeObj.SetActive(!1),this.time.textSet("")
let C=null
if(null!=n.serverData_get()){const t=n.baseData_get().cfgData_get()
if(null==n.serverData_get().deprecatedTime||n.serverData_get().deprecatedTime.Equal(It.I.zeroLong))C=`${this.normalColor}${(0,l.T)("有效时间 ")}[-]`,
"0"==t.validTime||u.M.Contains(t.validTime,":")?(this.time.textSet(""),this.timeObj.SetActive(!1)):(this.timeObj.SetActive(!0),
C+=`${this.activeColor}${U.l.GetDateFormat(u.M.String2Double(t.validTime))}[-]`,this.time.textSet(C))
else if("0"!=t.validTime&&u.M.Contains(t.validTime,":"))this.time.textSet(""),this.timeObj.SetActive(!1)
else{this.timeObj.SetActive(!0)
let t=n.serverData_get().deprecatedTime.ToNum()/1e3-E.D.serverTime_get()
t=it.p.CeilToInt(t),C=`${this.normalColor}${(0,l.T)("剩余使用时长 ")}[-]`,t>0?(this._lefttime=t,C=`${C}${this.activeColor}${U.l.GetDateFormat(this._lefttime)}[-]`,
this._leftTimeIntervalId=d.C.Inst_get().SetInterval(this._degf_LeftTimeChange,1e3)):C=`${this.inactiveColor}${(0,l.T)("该物品已失效")}[-]`,this.time.textSet(C)}}
this.SetQualityAnim(n.baseData_get().Quality_get())
const T=Tt.i.Inst_get().GetCfgResIcon(n.baseData_get().cfgData_get().id)
this.payType.spriteNameSet(T),this.payTypeSp.spriteNameSet(T)
const y=Tt.i.Inst_get().GetCfgResNum(n.baseData_get().cfgData_get().id)
this.payNum.textSet(u.M.DoubleToString(y)),this.payLabel.textSet(u.M.DoubleToString(y)),this.payTip.SetActive(""!=T),
this.conditionObj.SetActive(this.jobTip.activeSelf()||this.levelTip.activeSelf()||this.vipTip.activeSelf()||this.payTip.activeSelf()),this.grid1.Reposition()
const A=Tt.i.Inst_get().GetItemDesc(n.baseData_get().cfgData_get())
this.desc.textSet(A)
const v=this.GetRewardItemData(n.baseData_get().cfgData_get().id)
0==v.Count()?(this.rewardsObj.SetActive(!1),this.Relayout()):(this.rewardsObj.SetActive(!0),this.rewards.data_set(v)),this.SetButtonState()}LeftTimeChange(){
let t=`${this.normalColor}${(0,l.T)("剩余使用时长 ")}[-]`
this._lefttime-=1,this._lefttime<1?(t=`${this.inactiveColor}${(0,l.T)("该物品已失效")}[-]`,d.C.Inst_get().ClearInterval(this._leftTimeIntervalId),
this._leftTimeIntervalId=-1):t+=`${this.activeColor}${U.l.GetDateFormat(this._lefttime)}[-]`,this.time.textSet(t)}GetBtnShowIndex(t){const e=this.btnList.IndexOf(t,0)
return this.btnShowState[e]?e:-1}SetButtonState(){this.btnShowCnt=0
ut.P.Inst_get()
const t=this.bagItemData.baseData_get(),e=B.$.Inst().getItemById(t.modelId_get())
if(null==e&&k.Y.LogError((0,l.T)("PANDORARESOURCE中没有配置：")+(0,o.tw)(t.modelId_get())),g.J.Inst_get().isJudgeItemTipOperate&&t.isCanOperate){
this.SetBtnShowState(this.open,!m.g.Inst_get().warehouseShow&&0==e.optionalNum&&0==t.cfgData_get().Consums_get().costs.Count()&&t.isForBag&&!t.isLotteryBag&&!t.isLotteryShop&&!m.g.Inst_get().warehouseShow),
this.SetBtnShowState(this.select,!m.g.Inst_get().warehouseShow&&0!=e.optionalNum&&t.isForBag&&!t.isLotteryBag&&!t.isLotteryShop&&!m.g.Inst_get().warehouseShow),
this.SetBtnShowState(this.pay,!m.g.Inst_get().warehouseShow&&0!=t.cfgData_get().Consums_get().costs.Count()&&t.isForBag&&!t.isLotteryBag&&!t.isLotteryShop&&!m.g.Inst_get().warehouseShow),
this.SetBtnShowState(this.sellBtn,!m.g.Inst_get().warehouseShow&&t.isForBag&&1==t.cfgData_get().sell&&!t.isLotteryBag&&!t.isLotteryShop&&!m.g.Inst_get().warehouseShow),
this.SetBtnShowState(this.getOutBtn,t.btnType==ht.p.ExtendBag&&!t.isLotteryBag&&!t.isLotteryShop&&!m.g.Inst_get().warehouseShow),
this.SetBtnShowState(this.backBagBtn,t.isLotteryBag),this.SetBtnShowState(this.chargeBtn,t.isLotteryShop),
this.SetBtnShowState(this.bagToWarehouseBtn,m.g.Inst_get().warehouseShow&&null!=this.bagItemData&&0==this.bagItemData.type_get()),
this.SetBtnShowState(this.warehouseToBagBtn,m.g.Inst_get().warehouseShow&&null!=this.bagItemData&&1==this.bagItemData.type_get()),
this.SetBtnShowState(this.composeBtn,!m.g.Inst_get().warehouseShow&&0!=t.cfgData_get().GetComposeID()&&t.isForBag),
this.SetBtnShowState(this.auctionBtn,t.isCanOperate&&!m.g.Inst_get().warehouseShow&&0!=t.AuctionState_get()&&t.isForBag&&!t.isLotteryBag&&!t.isLotteryShop&&!t.isBagWarehouseData),
null!=this.tradeBtn&&(!m.g.Inst_get().warehouseShow&&null!=t.cfgData_get()&&t.isForBag,this.SetBtnShowState(this.tradeBtn,!1)),this.btnShowCnt=0
let s=0
for(;s<this.btnList.Count();)this.btnShowState[s]&&(this.btnShowCnt+=1),this.btnList[s].node.SetActive(this.btnShowState[s]),s+=1
const i=this.GetBtnShowIndex(this.obtainWayBtn)
if(-1!=i&&this.btnShowCnt<3&&(this.btnShowCnt-=1,this.SetBtnShowState(this.obtainWayBtn,!1)),this.btnShowCnt>0)if(this.btnObj.SetActive(!0),1==this.btnShowCnt){let t=-1,e=0
for(;e<this.btnShowState.Count();)this.btnShowState[e]&&(t=e),e+=1
this.btnList[t].SetSize(380,56),this.moreBtn.node.SetActive(!1)}else{let t=!0,e=0
for(;e<this.btnList.Count();)t?this.btnShowState[e]&&(t=!1):i!=e&&this.btnList[e].node.transform.SetParent(this.moreGrid.FatherId,this.moreGrid.ComponentId),e+=1
let s=0
for(;s<this.btnShowState.Count();)this.btnShowState[s]&&this.btnList[s].SetSize(184,56),s+=1
this.moreBtn.node.SetActive(!0)}else this.btnObj.SetActive(!1),this.moreBtn.node.SetActive(!1)
this.moreGrid.Reposition(),this.btnGrid.Reposition()}else this.btnObj.SetActive(!1)
this.AdjustTipSize()}SetBtnShowState(t,e){const s=this.btnList.IndexOf(t,0)
this.btnShowState[s]=e}RefreshRewardItem(){this.Relayout()}CreateRewardItem(t){const e=new dt.j
return e.setId(t,null,0),e.SetIconSize(50,50),e.SetBgSize(56,56),e}GetRewardItemData(t){const e=new p.Z,s=B.$.Inst().GetShowRewards(t)
for(const[t,i]of(0,n.V5)(s)){const t=new gt.t
t.modelId=i.GetModelId(),t.state=i.GetIsBind(),0==i.num?t.num=1:t.num=i.num
const s=new rt.Y
s.serverData_set(t),s.baseData_get().isCanOperate=!1,s.baseData_get().isShowAccess=!1,s.baseData_get().isEquipCompare=!1,
s.baseData_get().tipPosSetHandler=this._degf_ClickTipsCallback,0!=i.showId&&s.SetEquipAttrShowId(i.showId),e.Add(s)}return e}ClickTipsCallback(t){
St._.Inst_get().IsOpen()&&St._.Inst_get().CloseView()
const e=this.node.transform.GetLocalPosition(),s=this.bg.width(),i=H.t.GetAdaptWidth()/2,n=e.x+s/2+ft.Y.TipsFitDis
let l=0
null==t.cfgData_get()||"PANDORA"!=t.cfgData_get().itemType&&"VIPPANDORA"!=t.cfgData_get().itemType?n<=i?(l=e.x+s/2,t.anchor=new lt.F(0,.5)):(l=e.x-s/2,
t.anchor=new lt.F(1,.5)):l=n<=i?e.x+s:e.x-s,t.tipsPos=new ot.P(l,e.y,0)}Relayout(){let t=0
const e=ot.P.zero_get()
let s=ot.P.zero_get(),i=!0
t=this.timeObj.GetBoundsSize().y,t>.1&&(ot.P.Recyle(s),s=this.timeObj.transform.GetLocalPosition(),e.x=s.x,i&&(e.y=0),this.timeObj.transform.SetLocalPosition(e),e.y-=t,i=!1),
t=this.conditionObj.GetBoundsSize().y,t>.1&&(ot.P.Recyle(s),s=this.conditionObj.transform.GetLocalPosition(),e.x=s.x,e.y-=15,i?e.y=0:e.y+=4,
this.conditionObj.transform.SetLocalPosition(e),e.y-=t,i=!1,this.payTip.activeSelf()&&(e.y+=6)),t=this.descObj.GetBoundsSize().y,t>.1&&(ot.P.Recyle(s),
s=this.descObj.transform.GetLocalPosition(),e.x=s.x,e.y-=15,i?e.y=0:e.y+=4,this.descObj.transform.SetLocalPosition(e),e.y-=t,i=!1),t=this.rewardsObj.GetBoundsSize().y,
t>.1&&(ot.P.Recyle(s),s=this.rewardsObj.transform.GetLocalPosition(),e.x=s.x,e.y-=8,i&&(e.y=0),this.rewardsObj.transform.SetLocalPosition(e),e.y-=t,i=!1),ot.P.Recyle(e),
ot.P.Recyle(s),this.AdjustTipSize()}CalculateBgSize(){let t=1.5
t+=this.root.GetBoundsSize().y,this.btnShowCnt>0?this.BgOffset_set(t-this.hasBtnPanelSize.w):this.BgOffset_set(t-this.noBtnPanelSize.w)}AdjustTipSize(){this.CalculateBgSize()
const t=this.scrollBack.node.transform.GetLocalPosition()
if(0==this.btnShowCnt){const e=new at.L(this.noBtnPanelSize.x,this.noBtnPanelSize.y,this.noBtnPanelSize.z,this.noBtnPanelSize.w)
e.y-=this.BgOffset_get()/2,e.w+=this.BgOffset_get(),this.scrollPanel.baseClipRegionSet(e),this.scrollBack.heightSet(nt.GF.INT(e.w)),t.y=e.y}else{
const e=new at.L(this.hasBtnPanelSize.x,this.hasBtnPanelSize.y,this.hasBtnPanelSize.z,this.hasBtnPanelSize.w)
e.y-=this.BgOffset_get()/2,e.w+=this.BgOffset_get(),this.scrollPanel.baseClipRegionSet(e),this.scrollBack.heightSet(nt.GF.INT(e.w)),t.y=e.y}const e=ot.P.zero_get()
this.scrollPanel.node.transform.SetLocalPosition(e),ot.P.Recyle(e),this.scrollPanel.clipOffsetSet(st.V.TEMP_VECTOR2D_get()),this.scrollBack.node.transform.SetLocalPosition(t),
ot.P.Recyle(t),this.scrollView.ResetPosition()}}class bt{constructor(){this.itemData=null,this.view=null,this._degf_CallDestory=null,this._degf_Complete=null,
this._degf_EditorQuickAddItem=null,this._degf_SendEditorQuickAddItem=null,this._degf_CallDestory=()=>this.CallDestory(),this._degf_Complete=t=>this.Complete(t),
this._degf_EditorQuickAddItem=t=>this.EditorQuickAddItem(t),this._degf_SendEditorQuickAddItem=t=>this.SendEditorQuickAddItem(t)}static Inst_get(){
return null==bt._inst&&(bt._inst=new bt,r.i.Inst.AddEventHandler("QuickAddItemOnlyEditor3",bt._inst._degf_EditorQuickAddItem),
r.i.Inst.AddEventHandler("SendQuickAddItemOnlyEditor",bt._inst._degf_SendEditorQuickAddItem)),bt._inst}OpenView(t){if(null!=this.view&&this.view.isShow_get())return
null!=this.view&&this.view.node.SetActive(!0),this.itemData=t,this.EditorQuickAddItem(null)
const e=new N.v
e.layerType=F.F.Tip,I.N.inst.OpenById(x.I.PandoraTipsPanel,this._degf_Complete,this._degf_CallDestory,e),g.J.Inst_get().ForceCloseTipView()}EditorQuickAddItem(t){
E.D.IsEditor&&(null!=this.itemData&&null!=this.itemData._baseData?P.R.LuaCallCSEventString("QuickAddItemOnlyEditorBack",this.itemData._baseData._cfgData.name):P.R.LuaCallCSEventString("QuickAddItemOnlyEditorBack",null))
}SendEditorQuickAddItem(t){if(E.D.IsEditor){const e=t
if(null!=this.itemData&&null!=this.itemData._baseData){const t=`addItem ${this.itemData._baseData._modelId} ${e}`
k.Y.LogGMInEditor(t),U.l.sendGMComand(t)}}}Complete(t){return null==this.view&&(this.view=new Mt,this.view.setId(t,null,0)),this.view}CallDestory(){V.g.DestroyUIObj(this.view),
this.view=null,this.itemData=null}CloseView(){null!=this.view&&this.view.isShow_get()&&(r.i.Inst.RaiseEvent(y.g.CLICK_CLOSEIP),I.N.inst.CloseById(x.I.PandoraTipsPanel),
this.itemData=null)}}bt._inst=null
var Ot,Rt=s(70531),Lt=s(15771),Gt=s(66721),Pt=s(47041),Et=s(27327),kt=s(98359)
i._decorator.ccclass("GetItemTipPanel")(Ot=class extends kt.k{constructor(...t){super(...t),this.closeBtn=null,this.useBtn=null,this.useLabel=null,this.getItemTipWidget=null,
this.numLab=null,this.baseData=null,this.m_data=null,this.model=null,this.curQueueData=null,this.useNum=1,this.timeId=-1,this.autoUseTimeId=-1,this.guideid=null,
this.autoUseTime=null}InitView(){super.InitView(),this.model=Et.$.Inst()}Clear(){this.RemoveLis(),this.UnReg(),this.ClearTimer(),this.ClearAutoUseTimer(),this.m_data=null,
super.Clear()}Destroy(){this.RemoveLis(),super.Destroy()}AddLis(){super.AddLis(),r.i.Inst.AddEventHandler(y.g.BAG_UPDATE,this.CreateDelegate(this.BagUpdateHandle)),
r.i.Inst.AddEventHandler(y.g.BAG_INITED,this.CreateDelegate(this.BagUpdateHandle))}RemoveLis(){super.RemoveLis(),
r.i.Inst.RemoveEventHandler(y.g.BAG_UPDATE,this.CreateDelegate(this.BagUpdateHandle)),r.i.Inst.RemoveEventHandler(y.g.BAG_INITED,this.CreateDelegate(this.BagUpdateHandle))}
BagUpdateHandle(){if(null!=this.model.itemQueue&&this.model.itemQueue.Count()>0){let t=this.model.itemQueue.Count()-1
for(;t>=0;){if(t<this.model.itemQueue.Count()){const e=this.model.itemQueue[t]
let s=m.g.Inst_get().GetItemById(e.data.id)
if(null==s){if(s=this.GetItemByModelID(e.data.modelId),null==s)return this.model.itemQueue.RemoveAt(t),void Pt.N.Inst_get().GetItemDeQueue()
e.data=s.serverData_get()}}t-=1}const e=this.model.itemQueue[this.model.itemQueue.Count()-1]
if(null!=e&&null!=this.curQueueData){const t=e.data
if(this.curQueueData.data.modelId==t.modelId){this.GetItemNumById(t.modelId)!=this.useNum&&this.RefreshItemNum()}else this.UpdatePanel()}}}IsLimitVipAutoUse(t){
return Lt.U.inst.model.IsVipCardLimit(t)}RefreshItemNum(){this.ClearAutoUseTimer()
let t=null
if(null!=this.model.itemQueue&&this.model.itemQueue.Count()>0){this.curQueueData=this.model.itemQueue[this.model.itemQueue.Count()-1]
const e=this.curQueueData.data
null!=this.baseData&&e.modelId==this.baseData.modelId_get()||(this.baseData=new f.M(e.modelId,e))
const s=e.modelId
if(t=w.f.Inst().getItemById(s),this.IsExist(e)){if(3==t.whetherBatch&&!Gt.f.Inst().firstSkillDic[t.id]){const e=new p.Z,s=a.Y.Inst.primaryRoleInfoList
for(const[i,l]of(0,n.V5)(s)){const s=l;(0==t.job||A.Z.ReachJobLimit(t.job,s.Job_get()))&&e.Add(s)}if(!Gt.f.Inst().IsPopSkill(t,e))return void Pt.N.Inst_get().GetItemDeQueue()}
if(2==t.whetherBatch){const e=this.GetItemNumById(s)
this.useNum=e
const i=this.GetMaxUseNumById(s)
this.useNum>i&&(this.useNum=i),this.useNum>0&&(this.baseData.count=e,this.useNum>1?this.baseData.SpecialNumStr=(0,o.tw)(e):this.baseData.SpecialNumStr="",
0==t.autoUse||this.IsLimitVipAutoUse(s)?this.fatherView.optBtn.SetText(u.M.DealRichTextOutline(`使用${this.useNum}个`)):this.AddAutoUseTimer())}else this.baseData.count=1,
this.baseData.SpecialNumStr=" ",this.useNum=1,7==t.whetherBatch?this.fatherView.optBtn.SetText(u.M.DealRichTextOutline((0,
l.T)("点击使用"))):3==t.whetherBatch?this.fatherView.optBtn.SetText(u.M.DealRichTextOutline((0,l.T)("学习技能"))):this.fatherView.optBtn.SetText(u.M.DealRichTextOutline((0,l.T)("使用1个"))),
this.fatherView.optBtn.SetText(u.M.DealRichTextOutline((0,l.T)("使用1个")))}}if(0==this.useNum)Pt.N.Inst_get().GetItemDeQueue()
else{const e=this.baseData.Quality_get(),s=D.u.getColorStrsByBrightQuality(e)
this.fatherView.descTxt.textSet(`[${s}]${t.name}[-]`),this.baseData.showGoldDiamond=!1,this.fatherView.baseItem.SetData(this.baseData)}}GetMaxUseNumById(t){let e=Math.huge
if(10200==t){const t=a.Y.Inst.PrimaryRoleInfo_get().Level_get()
e=M.L.Inst().MaxLevel_get()-t}return e}GetItemNumById(t){const e=m.g.Inst_get().GetBagDataList()
if(null==e)return 0
let s=0
for(const[i,l]of(0,n.V5)(e))null!=l.baseData_get()&&l.baseData_get().cfgData_get().id==t&&(T.b.IsTimeOut(l.baseData_get().serverData_get())||(s+=l.baseData_get().serverData_get().num))
return s}GetItemByModelID(t,e){if(null==e){const s=w.f.Inst().getItemById(t)
e=null!=s?m.g.Inst_get().GetBagTypeByItemType(s.itemType):S.t.NormalBag}const s=m.g.Inst_get().GetBagDataList(e)
for(const[e,i]of(0,n.V5)(s))if(null!=i.baseData_get()&&i.baseData_get().modelId_get()==t&&!T.b.IsTimeOut(i.baseData_get().serverData_get()))return i
return null}IsExist(t){return null!=t&&(null!=m.g.Inst_get().GetItemById(t.Id_get())&&!C.t.Inst_get().IsDeprecated(t))}SetData(){this.AddLis(),this.UnReg(),this.UpdatePanel()}
UpdatePanel(){if(this.fatherView.icon.node.SetActive(!1),null!=this.model.itemQueue&&this.model.itemQueue.Count()>0){
this.curQueueData=this.model.itemQueue[this.model.itemQueue.Count()-1]
const t=this.curQueueData.data,e=t.modelId
if(this.baseData=null,this.baseData=new f.M(e,t),this.RefreshItemNum(),0==this.useNum)return
this.guideid=e,R.c.Inst.RegGameObject(c.D.UI_QUEUE_TIP_ITEM_BTN,this.fatherView.optBtn.node,this.guideid),this.AddTimer()}else Pt.N.Inst_get().GetItemDeQueue()}UnReg(){
null!=this.guideid&&R.c.Inst.UnRegGameObject(c.D.UI_QUEUE_TIP_ITEM_BTN,this.fatherView.optBtn.node,this.guideid)}OnOptBtnHandle(t){
this.IsExist(this.curQueueData.data)&&(this.m_data=m.g.Inst_get().GetItemById(this.model.itemQueue[this.model.itemQueue.Count()-1].data.id).baseData_get(),
t&&Lt.U.inst.model.IsVipCard(this.curQueueData.data.modelId)?g.J.Inst_get().UseItemByModelId(this.m_data.modelId_get(),this.useNum):this.SendToServer()),
Pt.N.Inst_get().GetItemDeQueue()}SendToServer(){const t=B.$.Inst().getItemById(this.m_data.cfgData_get().id)
if(null!=t&&0==this.m_data.cfgData_get().autoUse){const e=m.g.Inst_get().GetItemById(this.model.itemQueue[this.model.itemQueue.Count()-1].data.id)
if(this.m_data.cfgData_get().hasOpenUIId()&&null!=t&&t.throwType){const t=G.p.Inst_get().GetMapById(h.b.Inst.currentMapId_get())
if(null!=t&&t.senceType==v.S.WildMap){I.N.inst.OpenUIByStrIdWithParam(this.m_data.cfgData_get().ui,this.m_data)&&bt.Inst_get().CloseView()}else{
const t=b.x.Inst().getItemById(101527)
null!=t&&L.y.inst.ClientStrMsg(O.r.SystemTipMessage,t.sys_messsage)}return}
0!=t.optionalNum||null!=this.m_data.cfgData_get().consums||0==this.m_data.cfgData_get().consums.costs.Count()?Rt.R.Inst_get().OpenView(this.m_data,e):this.UseItemReq()
}else this.UseItemReq()}UseItemReq(){const t=w.f.Inst().getItemById(this.m_data.modelId_get())
if(g.J.Inst_get().IsHangExpItem(t.id))g.J.Inst_get().OpenUseHangItemView(this.baseData)
else if(t.autoUse>0&&(this.m_data.isAutoUse=!0),2==t.whetherBatch)if(this.useNum=this.GetItemNumById(t.id),g.J.Inst_get().UseItem(this.m_data,!1)){const t=new _.X
this.m_data.isAutoUse&&(t.isAutoUse="true"),g.J.Inst_get().UseItemByModelId(this.m_data.modelId_get(),this.useNum,null,t)}else g.J.Inst_get().UseItem(this.m_data)
else g.J.Inst_get().UseItem(this.m_data)}UseItemHandler(){g.J.Inst_get().UseItemByModelId(this.baseData.modelId_get(),this.useNum)}OnCloseBtnHandle(){
Pt.N.Inst_get().GetItemDeQueue()}AddTimer(){-1!=this.timeId&&this.ClearTimer(),this.timeId=d.C.Inst_get().SetInterval(this.CreateDelegate(this.RefreshLeftTime),1e3,-1),
this.RefreshLeftTime()}RefreshLeftTime(){let t
if(null!=this.model.itemQueue&&this.model.itemQueue.Count()>0){const e=m.g.Inst_get().GetItemById(this.model.itemQueue[this.model.itemQueue.Count()-1].data.id)
null!=e&&(t=e.serverData_get())}this.IsExist(t)||(this.ClearTimer(),Pt.N.Inst_get().GetItemDeQueue())}ClearTimer(){-1!=this.timeId&&(d.C.Inst_get().ClearInterval(this.timeId),
this.timeId=-1)}AddAutoUseTimer(){const t=this.baseData.cfgData_get();-1!=this.autoUseTimeId&&this.ClearAutoUseTimer(),
t.autoUse>0&&!this.IsLimitVipAutoUse(t.id)&&(this.fatherView.SetSlider(0,1),this.autoUseTime=t.autoUse,
this.autoUseTimeId=d.C.Inst_get().SetInterval(this.CreateDelegate(this.RefreshAutoUseTime),50,-1),this.RefreshAutoUseTime())}RefreshAutoUseTime(){if(this.autoUseTime-=.05,
this.autoUseTime<=0)this.ClearAutoUseTimer(),this.fatherView.SetSlider(1,1),this.OnOptBtnHandle(!0)
else{const t=this.baseData.cfgData_get().autoUse
this.fatherView.SetSlider(this.autoUseTime,t)
const e=Math.ceil(this.autoUseTime)
this.fatherView.optBtn.SetText(u.M.DealRichTextOutline(`自动使用(${e}s)`))}}ClearAutoUseTimer(){-1!=this.autoUseTimeId&&(this.fatherView.SetSlider(1,1),
d.C.Inst_get().ClearInterval(this.autoUseTimeId),this.autoUseTimeId=-1)}})},2487:(t,e,s)=>{var i,n=s(18998),l=s(98885),o=s(21554),a=s(47041),r=s(98359)
n._decorator.ccclass("OneKeySellTipPanel")(i=class extends r.k{InitView(){super.InitView()}AddLis(){super.AddLis()}RemoveLis(){super.RemoveLis()}OnCloseBtnHandle(){
a.N.Inst_get().ScoreSellDeQueue()}OnOptBtnHandle(){a.N.Inst_get().ScoreSellDeQueue(),o.J.Inst_get().OpenBagSellPanel()}SetData(){this.AddLis()
this.fatherView.descTxt.textSet("[dba968]装备可回收[-]"),this.fatherView.optBtn.SetText(l.M.DealRichTextOutline("点击前往")),
this.fatherView.SetIconByAtlasAndName("mainui","rymainui_open_1028",1.1),this.fatherView.baseItem.node.SetActive(!1)}Clear(){this.RemoveLis(),super.Clear()}Destroy(){
super.Destroy()}})},53186:(t,e,s)=>{var i,n=s(18998),l=s(23833),o=s(98885),a=s(27193),r=s(69429),h=s(47041),d=s(8828),c=s(36713),I=s(98359)
n._decorator.ccclass("RolandSaveBossTip")(i=class extends I.k{InitView(){super.InitView()}Destroy(){super.Destroy()}AddLis(){super.AddLis()}RemoveLis(){super.RemoveLis()}SetData(){
this.AddLis()
if(null==d.N.Inst_get().GetDataByTipsType(c.q.RolandSaveBoss)[0])return
r.v.ins.had_show_tip=!0
const t=l.a.getInst().getObjById(r.v.ins.bossId)
this.fatherView.descTxt.textSet(t.name),this.fatherView.baseItem.node.SetActive(!1),this.fatherView.optBtn.SetText(o.M.DealRichTextOutline("点击前往")),
this.fatherView.SetIconByAtlasAndName("pre_rytouxiang",t.headResources,.6)}OnCloseBtnHandle(){h.N.Inst_get().RolandSaveBossDeQueue()}OnOptBtnHandle(){a.w.ins.OpenPanel(),
h.N.Inst_get().RolandSaveBossDeQueue()}Clear(){this.RemoveLis(),super.Clear()}})},20544:(t,e,s)=>{
var i,n=s(18998),l=s(23833),o=s(98885),a=s(55552),r=s(40930),h=s(73581),d=s(67632),c=s(47041),I=s(8828),u=s(36713),p=s(98359)
n._decorator.ccclass("RolandValleyBossTip")(i=class extends p.k{InitView(){super.InitView()}Destroy(){super.Destroy()}AddLis(){super.AddLis()}RemoveLis(){super.RemoveLis()}
SetData(){this.AddLis()
if(null==I.N.Inst_get().GetDataByTipsType(u.q.RolandValleyBoss)[0])return
const t=d.n.Inst_get().RolandBossInfo_Get(),e=r.f.Inst_get().GetBossConfig(t.process),s=a.h.GetInst().GetSpwanItemById(e.spawnId),i=l.a.getInst().getObjById(s.objectKey)
this.fatherView.descTxt.textSet(i.name),this.fatherView.baseItem.node.SetActive(!1),this.fatherView.optBtn.SetText(o.M.DealRichTextOutline("点击前往")),
this.fatherView.SetIconByAtlasAndName("pre_rytouxiang",i.headResources,.6)}OnCloseBtnHandle(){c.N.Inst_get().RolandValleyBossDeQueue()}OnOptBtnHandle(){
h.o.Inst_get().OpenRolandAppearPanel(1),c.N.Inst_get().RolandValleyBossDeQueue()}Clear(){this.RemoveLis(),super.Clear()}})},57051:(t,e,s)=>{s.d(e,{c:()=>i})
class i{static GetIconStr(t){
return t==i.ATTACK_BORN?"ryditu_sp_0013":t==i.DEFENCE_BORN?"ryditu_sp_0012":t==i.FORBIDEN?"ryditu_sp_0005":t==i.ALTAR?"ryditu_sp_0011":t==i.BOSS?"ryditu_sp_0006":t==i.THRONE?"ryditu_sp_0008":t==i.NPC?"ryditu_sp_0004":t==i.TRANSPORT?"ryditu_sp_0007":t==i.DOOR?"ryditu_sp_0009":"ryditu_sp_0004"
}}i.ATTACK_BORN=1,i.DEFENCE_BORN=2,i.FORBIDEN=3,i.ALTAR=4,i.BOSS=5,i.THRONE=6,i.NPC=7,i.TRANSPORT=8,i.DOOR=9},31931:(t,e,s)=>{s.d(e,{f:()=>i})
class i{}i.CAN=1,i.LV_LIMIT=2,i.TRANSFOR_LIMIT=3,i.BOSS_LIMIT=4},523:(t,e,s)=>{s.d(e,{p:()=>i})
class i{}i.MONSTER_NORMAL="MONSTER_NORMAL",i.NPC="NPC",i.TRANSPORT="TRANSPORT",i.MONSTER_BOSS="MONSTER_BOSS",i.MONSTER_ELITE="MONSTER_ELITE",i.GATHER="GATHER",
i.MULTIPLE_EXP_POINT="MULTIPLE_EXP_POINT"},97943:(t,e,s)=>{s.d(e,{f:()=>i})
class i{}i.LineChange="LineChange",i.LineInfoUpdate="LineInfoUpdate",i.CloseSelectLine="CloseSelectLine",i.AddGoldMonster="AddGoldMonster",i.RemoveGoldMonster="RemvoeGoldMonster",
i.ReloadMap="ReloadMap",i.MapTaskChange="MapTaskChange",i.GetMapGoldMonster="GetMapGoldMonster",i.GetChannelGoldMonster="GetChannelGoldMonster",i.RadarItemClick="RadarItemClick",
i.TeamMemberPosition="TeamMemberPosition",i.CurrentMapItemClick="CurrentMapItemClick",i.CloseMonsterTip="CloseMonsterTip",i.UnlockMap="UnlockMap"},66246:(t,e,s)=>{s.d(e,{v:()=>i})
class i{}i.Normal=1,i.ManualClick=2,i.MultipleHang=3},6219:(t,e,s)=>{s.d(e,{p:()=>n})
var i=s(67075)
class n extends i.t{constructor(...t){super(...t),this.spawnId=0,this.cfgId=0,this.m_name=null,this.m_level=null,this.m_objLevel=0,this.m_type=null,this.info=null,
this.isSuggest=!1,this.miracleState=0,this.difficulty=-2,this.indicator=0}}},69611:(t,e,s)=>{s.d(e,{P:()=>i})
class i{constructor(){this.x=0,this.y=0,this.go=null,this.clazz=null}}},52313:(t,e,s)=>{s.d(e,{v:()=>i})
class i{constructor(){this.flag=0,this.type=null,this.playertransport=null,this.monsterId=0,this.name=""}Test1(){return!0}S_Test(){return!0}}},12970:(t,e,s)=>{s.d(e,{F:()=>b})
var i=s(38836),n=s(23833),l=s(98800),o=s(73136),a=s(2689),r=s(13687),h=s(16812),d=s(62370),c=s(98885),I=s(85602),u=s(38962),p=s(77477),_=s(24524),g=s(75439),m=s(55552),S=s(77697),f=s(17783),C=s(21334),T=s(19276),y=s(70415),A=s(62783),v=s(31931),D=s(97943)
class w{constructor(t,e,s,i){this.lineNum=0,this.personCount=0,this.teamLine=0,this.m_fluentCount=0,this.m_fullCount=0,this.lineIndex=0,this.lineNum=t,this.personCount=e,
this.teamLine=s
const n=c.M.Split(i,d.o.s_Arr_UNDER_CHAR_DOT)
this.m_fullCount=c.M.String2Int(n[0]),this.m_fluentCount=c.M.String2Int(n[1])}GetSymbol(){
return this.teamLine==this.lineNum?"xuanxian_icon_0001":this.personCount>=this.m_fullCount?"xuanxian_sp_0001":this.m_fluentCount<=this.personCount&&this.personCount<this.m_fullCount?"xuanxian_sp_0003":"xuanxian_sp_0002"
}GetState(){return this.personCount>=this.m_fullCount?2:this.m_fluentCount<=this.personCount&&this.personCount<this.m_fullCount?1:0}}class B{constructor(){this.cfg=null,
this.objCfg=null,this.x=0,this.y=0,this.map=0,this.line=0,this.objid=null}}class M{constructor(){this.cfg=null,this.objCfg=null,this.x=0,this.y=0,this.map=0,this.line=0}}
class b extends h.k{constructor(){super(!1,0),this.transfer_list=null,this.task_list=null,this.boss_list=null,this.gpMapid=0,this.transferMap=0,this.transferX=0,this.transferY=0,
this.GPDic=null,this.channelGoldenPoint=null,this.m_goldmonsterList=null,this.lastFindPathLink=null,this.lineList=null,this.recommendLineVo=null,this.curLine=0,this.isFlying=!1,
this.mapLockStatus=null,this.mapbossPassStatus=null,this.unplayUnlockEffectMaps=null,this.isClickRecommond=!0,this._degf_SortGoldCompareFunc=null,
this._degf_SortMiracleCompareFunc=null,this.recommand_plus_level=null,this.curWorldCfg=null,this.curUnLockBossMapId=0,this.flyItemMapId=0,this.unlockBossWinUnlockMapId=0,
this.leveltipsData=null,this.OpenEffMapId=null,this.isOpenByMultipleHang=void 0,this.GPDic=new u.X,this.m_goldmonsterList=new I.Z,this.lineList=new I.Z,this.mapLockStatus=new u.X,
this.mapbossPassStatus=new u.X,this._degf_SortGoldCompareFunc=(t,e)=>this.SortGoldCompareFunc(t,e),this._degf_SortMiracleCompareFunc=(t,e)=>this.SortMiracleCompareFunc(t,e),
this.recommand_plus_level=g.D.getInstance().GetIntValue("FIELD_RECOMMEND_LEVEL")}Transfer_list_get(){return this.transfer_list}Transfer_list_set(t){this.transfer_list=t}
Task_list_get(){return this.task_list}Task_list_set(t){this.task_list=t}Boss_list_get(){return this.boss_list}Boss_list_set(t){this.boss_list=t}GoldmonsterList_get(){
return this.m_goldmonsterList}GoldmonsterList_set(t){this.m_goldmonsterList=t}LastFindPathLink_get(){return this.lastFindPathLink}LastFindPathLink_set(t){this.lastFindPathLink=t}
GetNewOpenMapId(){}static getInst(){return null==b._inst&&(b._inst=new b),b._inst}GetGroupMaps(t){const e=new I.Z
if(null!=t&&""!=t.worldmap){const s=c.M.Split(t.worldmap,d.o.s_Arr_UNDER_CHAR_DOT)
let i=0
for(;i<s.count;){const t=c.M.String2Int(s[i]),n=C.p.Inst_get().GetMapById(t)
e.Add(n),i+=1}}else e.Add(t)
return e}IsUnplayUnlockMap(t){return null!=this.unplayUnlockEffectMaps&&this.unplayUnlockEffectMaps.IndexOf(t)>=0}RemoveUnplayUnlockMap(t){if(null!=this.unplayUnlockEffectMaps){
const e=this.unplayUnlockEffectMaps.IndexOf(t)
e>=0&&this.unplayUnlockEffectMaps.RemoveAt(e)}}UpdateLineInfo(t,e){this.lineList.Clear(),this.recommendLineVo=null
let s=99999
const n=C.p.Inst_get().GetMapById(r.b.Inst.currentMapId_get())
for(const[l,o]of(0,i.vy)(t)){const i=new w(l,t[l],e,n.fullCrowdedFluent)
this.lineList.Add(i),e>-1?e==l&&(this.recommendLineVo=i):i.personCount<s&&(this.recommendLineVo=i,s=i.personCount)}this.lineList.Sort(this.CreateDelegate(this.LineSort))
for(let t=0;t<=this.lineList.Count()-1;t++){this.lineList[t].lineIndex=t+1}this.RaiseEvent(D.f.LineInfoUpdate,null)}LineSort(t,e){
return t.lineNum>e.lineNum?1:t.lineNum<e.lineNum?-1:0}CurLine_get(){return this.curLine}CurLineShow_get(t){null==t&&(t=this.curLine)
for(let e=0;e<=this.lineList.Count()-1;e++){const s=this.lineList[e]
if(s.lineNum==t&&0!=s.lineIndex)return s.lineIndex}return t}CurLine_set(t){if(t!=this.curLine){this.curLine=t
for(const[t,e]of(0,i.V5)(this.GoldmonsterList_get()))e.line=this.curLine
this.RaiseEvent(D.f.LineChange,this.curLine)}}ChangeMap(){this.RaiseEvent(D.f.ReloadMap)}GetTransfer(t){return this.transfer_list=C.p.Inst_get().GetAllTransportInMap(t),
this.transfer_list}SetTaskList(t){this.task_list=t,this.RaiseEvent(D.f.MapTaskChange)}GetMapTask(t){const e=new I.Z,s=f.L.Inst_get().model.GetAllQuestes()
for(const[n,l]of(0,i.V5)(s)){const s=l.linkNpcId_get()
if(s>0){const i=S.f.Inst().getItemByIdRaw(s)
null!=i&&i.mapid==t&&e.Add(l)}}return e}GetMapBoss(t){return this.boss_list=T.C.Inst().GetBossesByMap(t),this.boss_list}SetChannelMonster(t){this.channelGoldenPoint=t,
this.RaiseEvent(D.f.GetChannelGoldMonster,null)}GetMapGoldPointByMapId(t){return this.GPDic.LuaDic_ContainsKey(t)?this.GPDic[t]:null}GetMapGoldMonster(){
const t=new I.Z,e=A.X.inst.CurrentMapId_get()
if(this.GPDic.LuaDic_ContainsKey(e)){const s=this.GPDic[e]
for(const[l,o]of(0,i.vy)(s.goldenPoints)){const i=s.goldenPoints[l]
let o=0
for(;o<i.goldenPoints.Count();){const s=new B,a=m.h.GetInst().GetSpwanItemById(i.goldenPoints[o].spawnkey),r=n.a.getInst().getObjById(a.objectKey)
s.cfg=a,s.objCfg=r,s.map=e,s.line=l,s.x=i.goldenPoints[o].x,s.y=i.goldenPoints[o].y,t.Add(s),o+=1}}}return t.Sort(this.SortGoldCompareFunc),t}GetMapMiracleMonster(t){null==t&&(t=0)
const e=new I.Z,s=m.h.GetInst().GetMiracleMapSpawnItems(t)
if(null!=s){let i=0
for(;i<s.Count();){const l=new M
l.cfg=s[i]
const o=n.a.getInst().getObjById(l.cfg.objectKey)
l.objCfg=o,l.map=t,l.line=0,l.x=l.cfg.x,l.y=l.cfg.y,e.Add(l),i+=1}}return e.Sort(this.SortMiracleCompareFunc),e}GetMiracleAreaType(t){let e=!1
return e=o.c.Instance_get().GetTerrainExtendXZ(t.x,t.z,4),e?4:(e=o.c.Instance_get().GetTerrainExtendXZ(t.x,t.z,5),e?5:(e=o.c.Instance_get().GetTerrainExtendXZ(t.x,t.z,6),e?6:-1))}
SortGoldCompareFunc(t,e){let s=0,i=0
return t.line==this.CurLine_get()&&(s+=3e5),e.line==this.CurLine_get()&&(i+=3e5),
t.line==e.line?t.objCfg.level==e.objCfg.level?t.objCfg.id+s-(e.objCfg.id+i):t.objCfg.level+s-(e.objCfg.level+i):t.line+s-(e.line+i)}SortMiracleCompareFunc(t,e){
return t.objCfg.level==e.objCfg.level?t.objCfg.id-e.objCfg.id:t.objCfg.level-e.objCfg.level}RemoveGoldMonster(t){this.RaiseEvent(D.f.RemoveGoldMonster,t)}SetMapMonster(t){
this.GPDic.LuaDic_AddOrSetItem(A.X.inst.CurrentMapId_get(),t),this.RaiseEvent(D.f.GetMapGoldMonster,null)}GetFirstLineGoldMonster(){const t=new I.Z,e=A.X.inst.CurrentMapId_get()
let s=1
if(e==r.b.Inst.currentMapId_get()&&(s=b.getInst().curLine),this.GPDic.LuaDic_ContainsKey(e)){const t=this.GPDic[e]
if(t.goldenPoints.LuaDic_ContainsKey(s)){const e=t.goldenPoints[s]
for(const[t,s]of(0,i.V5)(e.goldenPoints));}}return t}IsOpenGuideMap(t,e){if(null==this.OpenEffMapId)return!1
if(t==this.OpenEffMapId)return!0
if(null!=e&&e){const e=C.p.Inst_get().GetMapById(t)
if(null!=e.worldmapList)return e.worldmapList.Contains(this.OpenEffMapId)}return!1}IsOpenMap(t,e,s,i){if(null!=i&&i){let e=!1
return e=b.getInst().mapLockStatus.LuaDic_GetItem(t),null==e&&(e=!1),e}if(null==e&&(e=!1),null==s&&(s=!1),null==this.mapLockStatus||0==t)return!1
let n=!1
const l=C.p.Inst_get().GetMapById(t)
if(l.controllerType!=a.N.SCENE)return!0
let o=0
o=0!=l.relatedMapId?l.relatedMapId:l.id,n=this.mapLockStatus[o]
const r=C.p.Inst_get().GetLastMapIsOpen(t)
return s||r||(n=!1),e||!C.p.Inst_get().IsNeedBossChange(t)||this.CheckMapBossIsChallenge(t)||(n=!1),null==n&&(n=!1),n}CheckMapBossIsChallenge(t){return 1==this.mapbossPassStatus[t]
}ExistOpenMap(t,e){r.b.Inst.currentMapId_get()
const s=C.p.Inst_get().GetMapById(t)
let i=this.IsOpenMap(t,e)
if(i)return!0
if(null!=s){const t=c.M.Split(s.worldmap,d.o.s_Arr_UNDER_CHAR_DOT)
if(null!=t){let s=0
for(;s<t.count;){const n=c.M.String2Int(t[s])
if(i=this.IsOpenMap(n,e),i)return!0
s+=1}}}return!1}GetCanEnterMapByLvAndTransfer(t){const e=C.p.Inst_get().GetMapById(t)
return l.Y.Inst.PrimaryRoleInfo_get().Level_get()<e.minLevelLimit?v.f.LV_LIMIT:C.p.Inst_get().IsNeedBossChange(t)&&!this.CheckMapBossIsChallenge(t)?v.f.BOSS_LIMIT:v.f.CAN}
CheckHasMapNotChallengeBoss(){const t=C.p.Inst_get().GetMapSortList()
for(let e=0;e<=t.Count()-1;e++){const s=t[e]
if(this.GetCanEnterMapByLvAndTransfer(s)==v.f.BOSS_LIMIT)return!0}return!1}GetMapNotChallengeBoss(){const t=C.p.Inst_get().GetMapSortList()
for(let e=0;e<=t.Count()-1;e++){const s=t[e]
if(this.GetCanEnterMapByLvAndTransfer(s)==v.f.BOSS_LIMIT)return s}return 0}GetCanEnterCopyByLvAndTransfer(t){
const e=_.o.Inst().getItemById(t),s=e.rebirthLimit,i=l.Y.Inst.PrimaryRoleInfo_get()
if(s>0){if(i.rebirthLevel<s||i.Level_get()<e.minLevelLimit)return v.f.TRANSFOR_LIMIT}else if(l.Y.Inst.PrimaryRoleInfo_get().Level_get()<e.minLevelLimit)return v.f.LV_LIMIT
return v.f.CAN}GetRecommendMonsterId(){const t=this.GetRecommendTransVo()
return null!=t?t.objectId:0}GetRecommendTransVo(){return null}CheckRecommond(){}IsSuitMonsterId(t){
const e=l.Y.Inst.PrimaryRoleInfo_get().Level_get()+this.recommand_plus_level,s=this.GetPlayerMaxDef(),i=n.a.getInst().getObjById(t),o=y.i.Inst().getItemById(t)
return null!=o&&null!=i&&e>=i.level&&s>=o.defenseRec}GetRecommendTransIdByMonsterId(t,e){let s=0
const i=t.GetSameGroupMonsterIdsByMonsterId(e)
return 0==s&&(s=t.GetTransIdByMonsterId(i[0])),s}GetPlayerMaxDef(){let t=0
for(const[e,s]of(0,i.V5)(l.Y.Inst.primaryRoleInfoList)){const e=s
t<e.getAttribute(p.Z.Defense)&&(t=e.getAttribute(p.Z.Defense))}return t}ResetModel(){this.LastFindPathLink_set(null),this.isClickRecommond=!0,this.flyItemMapId=0}}b._inst=null,
b.YONG_ZHE_DA_LU=10001},62783:(t,e,s)=>{s.d(e,{X:()=>Se})
var i=s(32076),n=s(98800),l=s(91238),o=s(97461),a=s(13687),r=s(85602),h=s(79534),d=s(92679),c=s(91690),I=s(21267),u=s(12970),p=s(42292),_=s(71409),g=s(17409),m=s(49655),S=s(77546),f=s(86133),C=s(38045),T=s(23833),y=s(44139),A=s(96098),v=s(36241),D=s(73136),w=s(68662),B=s(2689),M=s(38935),b=s(5924),O=s(56937),R=s(18202),L=s(31222),G=s(5494),P=s(8334),E=s(52726),k=s(98789),N=s(98130),V=s(98885),x=s(94148),F=s(92984),U=s(20099),H=s(88911),j=s(74045),W=s(49067),Y=s(87923),q=s(29839),z=s(85770),Z=s(72800),X=s(92473),Q=s(89144),J=s(44802),$=s(96913),K=s(48933),tt=s(24524),et=s(9659),st=s(55552),it=s(70843),nt=s(29974),lt=s(65867),ot=s(92415),at=s(22662),rt=s(47552),ht=s(83900),dt=s(83836),ct=s(51704),It=s(61546),ut=s(29279),pt=s(61149),_t=s(54383),gt=s(41864),mt=s(86144),St=s(27193),ft=s(60647),Ct=s(13487),Tt=s(65550),yt=s(79878),At=s(17783),vt=s(89803),Dt=s(37151),wt=s(21334),Bt=s(12417),Mt=s(31931),bt=s(97943),Ot=s(66246),Rt=s(9986),Lt=s(6665),Gt=s(61911),Pt=s(99294),Et=s(9057),kt=s(93877),Nt=s(72005)
class Vt extends Et.x{constructor(){super(),this.btn=null,this.stateSp=null,this.lineLabel=null,this.countLabel=null,this.m_line=0,this._degf_OnBtnClick=null,
this._degf_OnBtnClick=(t,e)=>this.OnBtnClick(t,e)}InitView(){this.btn=new Pt.z,this.btn.setId(this.FatherId,this.FatherComponentID,1),this.stateSp=new Nt.w,
this.stateSp.setId(this.FatherId,this.FatherComponentID,2),this.lineLabel=new kt.Q,this.lineLabel.setId(this.FatherId,this.FatherComponentID,3),this.countLabel=new kt.Q,
this.countLabel.setId(this.FatherId,this.FatherComponentID,4)}SetData(t){yt.Y.RegLuaClick(this.btn,this._degf_OnBtnClick)
const e=t
this.m_line=e.lineNum,this.lineLabel.textSet(e.lineNum+(0,f.T)("线"))
const s=e.GetState()
0==s?this.countLabel.textSet((0,f.T)("[047104]流畅[-]")):1==s?this.countLabel.textSet((0,f.T)("[e2a66a]拥挤[-]")):2==s&&this.countLabel.textSet((0,f.T)("[de2524]爆满[-]")),
this.stateSp.spriteNameSet(e.GetSymbol())}OnBtnClick(t,e){Se.inst.changeLine(this.m_line),Se.inst.CloseChangeLinePanel()}Clear(){yt.Y.DelLuaClick(this.btn,this._degf_OnBtnClick)}
Destroy(){this.btn=null,this.stateSp=null,this.lineLabel=null,this.countLabel=null}}class xt extends Gt.f{constructor(){super(),this.grid=null,this.recommendCell=null,
this.closeBtn=null,this._degf_GetLinesHandler=null,this._degf_OnClose=null,this._degf_OnCreateCell=null,this._degf_GetLinesHandler=t=>this.GetLinesHandler(t),
this._degf_OnClose=(t,e)=>this.OnClose(t,e),this._degf_OnCreateCell=t=>this.OnCreateCell(t)}InitView(){this.grid=new Lt.A,this.grid.setId(this.FatherId,this.FatherComponentID,1),
this.recommendCell=new Vt,this.recommendCell.setBinderId(this.FatherId,this.FatherComponentID,2),this.closeBtn=new Rt.W,this.closeBtn.setId(this.FatherId,this.FatherComponentID,3),
this.grid.SetInitInfo("ui_topsmallmap_lineitem",this._degf_OnCreateCell)}OnCreateCell(t){const e=new Vt
return e.setId(t,null,0),e}OnAddToScene(){Se.inst.getMapLines(),this.AddOrDelEvent(!0)}AddOrDelEvent(t){t?(this.AddClickEvent(this.closeBtn,this._degf_OnClose),
u.F.getInst().AddEventHandler(bt.f.LineInfoUpdate,this._degf_GetLinesHandler)):(this.RemoveClickEvent(this.closeBtn,this._degf_OnClose),
u.F.getInst().RemoveEventHandler(bt.f.LineInfoUpdate,this._degf_GetLinesHandler))}GetLinesHandler(t){const e=u.F.getInst()
this.grid.data_set(e.lineList),null!=e.recommendLineVo?(this.recommendCell.node.SetActive(!0),this.recommendCell.SetData(e.recommendLineVo)):this.recommendCell.node.SetActive(!1)}
OnClose(t,e){Se.inst.CloseChangeLinePanel()}Clear(){this.grid.Clear(),this.recommendCell.Clear(),this.AddOrDelEvent(!1)}Destroy(){this.grid.Destroy(),this.grid=null,
this.recommendCell.Destroy(),this.recommendCell=null,this.closeBtn=null}}var Ft=s(32759),Ut=s(60130)
class Ht extends Gt.f{constructor(...t){super(...t),this.tweenPos=null,this.icon=null,this.mapname=null,this.mapId=null,this.mapCfg=null,this.delayId=null}InitView(){
super.InitView(),this.tweenPos=this.CreateComponent(Ft.c,1),this.icon=this.CreateComponent(Nt.w,2),this.mapname=this.CreateComponent(kt.Q,3)}OnAddToScene(){
this.mapId=u.F.getInst().flyItemMapId,this.mapCfg=wt.p.Inst_get().GetMapById(this.mapId),this.icon.spriteNameSet(this.mapCfg.senceUi),this.mapname.textSet(this.mapCfg.name),
this.delayId=b.C.Inst_get().SetInterval(this.CreateDelegate(this.StartToFly),200,1),this.tweenPos.AddEventHandler(this.CreateDelegate(this.Close))}StartToFly(){
this.tweenPos.SetFrom(h.P.zero_get())
let t=h.P.zero_get()
const e=L.N.inst.GetViewById(G.I.TopSmallMap)
null!=e&&(t=e.GetMapFlyPos(),t=Ut.O.WorldPosToLayoutLocalPosQuick(t,E.F.Effect),this.tweenPos.SetTo(t),h.P.Recyle(t),this.tweenPos.durationSet(.8),this.tweenPos.ResetToBeginning(),
this.tweenPos.PlayForward())}Clear(){null!=this.delayId&&b.C.Inst_get().ClearInterval(this.delayId),this.tweenPos.RemoveEventHandler(this.CreateDelegate(this.Close)),super.Clear()}
Destroy(){super.Destroy()}Close(){u.F.getInst().flyItemMapId=0,o.i.Inst.RaiseEvent(d.g.UPDATE_UNLOCK_BOSS_CHANLLENGE_INFO),Se.inst.OpenMapPanel(),L.N.inst.ClosePanel()}}
var jt=s(43662),Wt=s(26055),Yt=s(87722),qt=s(31546),zt=s(82737),Zt=s(9776),Xt=s(16261),Qt=s(75696),Jt=s(27122),$t=s(74768),Kt=s(47786),te=s(82039)
class ee extends Gt.f{constructor(...t){super(...t),this.bossName=null,this.bossTexture=null,this.blood=null,this.playerNum=null,this.dropGrid=null,this.descLabel=null,
this.bosstiredconsume=null,this.dropScrollview=null,this.searchForBossBtn=null,this.recordWidget=null,this.recordGrid=null,this.mask=null,this.attentionBtn=null,
this.selectSpt=null,this.attentionContainer=null,this.headIcon=null,this.noneObj=null,this.limitLabel=null,this.model=null,this.tModel=null,this.bossData=null,this.objectCfg=null,
this.boss=null}InitView(){super.InitView(),this.bossName=this.CreateComponent(kt.Q,1),this.bossTexture=this.CreateComponent(Xt.X,3),this.blood=this.CreateComponent(kt.Q,5),
this.playerNum=this.CreateComponent(kt.Q,6),this.dropGrid=this.CreateComponent(Lt.A,7),this.descLabel=this.CreateComponent(kt.Q,8),
this.bosstiredconsume=this.CreateComponent(kt.Q,10),this.dropScrollview=this.CreateComponent(Zt.h,11),this.searchForBossBtn=this.CreateComponent(Rt.W,12),
this.recordWidget=this.CreateComponent(Pt.z,13),this.recordGrid=this.CreateComponent(Lt.A,14),this.mask=this.CreateComponent(Pt.z,15),
this.attentionBtn=this.CreateComponent(Rt.W,16),this.selectSpt=this.CreateComponent(Pt.z,17),this.attentionContainer=this.CreateComponent(Pt.z,18),
this.headIcon=this.CreateComponent(Nt.w,19),this.noneObj=this.CreateComponent(Pt.z,20),this.limitLabel=this.CreateComponent(kt.Q,21),
this.dropGrid.SetInitInfo("ui_baseitem",null,Qt.j),this.dropGrid.OnReposition_set(this.CreateDelegate(this.ResetDropScrollView)),
this.recordGrid.SetInitInfo("ui_crossboss_recorditem_ry",null,$t.h),this.model=Q.I.Inst_get(),this.tModel=Bt._.Inst()}ResetDropScrollView(){this.dropScrollview.ResetPosition()}
Clear(){this.RemoveLis(),this.ClearBoss(),jt.M.Instance_get().DeactiveStage(ee.STAGE_ID,this.bossTexture.FatherId,this.bossTexture.ComponentId),super.Clear()}Destroy(){
super.Destroy()}AddLis(){this.m_handlerMgr.AddClickEvent(this.searchForBossBtn,this.CreateDelegate(this.OnEntetMap)),
this.m_handlerMgr.AddClickEvent(this.mask,this.CreateDelegate(this.OnClose)),this.m_handlerMgr.AddClickEvent(this.attentionBtn,this.CreateDelegate(this.OnAttentionClick)),
this.m_handlerMgr.AddEventMgr(d.g.UPDATE_ATTENTION,this.CreateDelegate(this.OnUpdateAttentionInfo))}RemoveLis(){}OnAddToScene(){this.RemoveLis(),this.AddLis(),this.UpdateView()}
UpdateView(){this.bossData=Q.I.Inst_get().selectBossData,this.objectCfg=T.a.getInst().getObjById(this.bossData.monsterId),
this.bossName.textSet(`${this.objectCfg.name}Lv.${this.objectCfg.level}`),this.headIcon.spriteNameSet(this.objectCfg.headResources),
this.blood.textSet(`${this.bossData.info.hpRate}%`),this.playerNum.textSet(this.bossData.info.fightNum)
const t=Kt.x.Inst().getItemById(11043004)
this.descLabel.textSet(t.sys_messsage),this.bosstiredconsume.textSet(this.objectCfg.rage),this.selectSpt.SetActive(this.tModel.attentionLis.IndexOf(this.bossData.monsterId,0)>=0)
const e=this.model.GetRewardListById(this.bossData.sortId)
if(this.dropGrid.data_set(e),this.ShowBoss(),this.bossData.info.killHistories.Count()>0?(this.noneObj.SetActive(!1),
this.bossData.info.killHistories.Sort(((t,e)=>e.time.ToNum()-t.time.ToNum())),this.recordGrid.data_set(this.bossData.info.killHistories)):this.noneObj.SetActive(!0),
Q.I.Inst_get().IsCrossBattleOpen())this.limitLabel.SetActive(!1),this.searchForBossBtn.SetActive(!0)
else{let t=`每日${this.model.closeTimeStr}-${this.model.openTimeStr}罗兰战场关闭，无法进入`
t=V.M.Replace(t,"次日",""),this.limitLabel.textSet(t),this.limitLabel.SetActive(!0),this.searchForBossBtn.SetActive(!1)}}ShowBoss(){jt.M.Instance_get().ActiveStage(ee.STAGE_ID)
const t=this.objectCfg
if(null!=t){const e=new Wt.O
this.ClearBoss(),this.boss=Jt.Q.Inst().GetObjectByName("MonsterCharacter",Yt._),this.boss.Info_set(e)
const s=new qt.O
s._displayID=t.displayId,s._world=jt.M.Instance_get().GetStageWorldType(ee.STAGE_ID),s._bNeedWaitAnime=!0,s.shiledType=zt.g.DT_NONE,this.boss.InitPhotoByInfo(t,s,0)
const i=jt.M.Instance_get().GetDisplayHeight(ee.STAGE_ID,0)
this.boss.MainRole_get().SetCastShadow(!0),this.boss.MainRole_get().SetShadowHeight(i),jt.M.Instance_get().SetDisplayObject(ee.STAGE_ID,this.boss.MainRole_get().handle,0),
jt.M.Instance_get().SetWorldRotation(ee.STAGE_ID,0,h.P.zero_get())
let n=t.scale/1e4
0==n&&(n=1),this.boss.SetSize(n),this.bossTexture.SetMainTextureByPhoto(ee.STAGE_ID),this.bossTexture.SetUVRect(0,0,1,1)}}ClearBoss(){null!=this.boss&&(this.boss.Destroy(),
this.boss=null)}OnClose(){L.N.inst.ClosePanel()}OnEntetMap(){const t=w.D.serverTime_get()-Q.I.Inst_get().lastExitTime
if(!X.R.Inst_get().IsInCrossBattle()&&t<Q.I.Inst_get().enterCD){const e=wt.p.Inst_get().GetMapById(this.model.crossMapId).name
Tt.y.inst.ClientSysMessage(11043016,new r.Z([Q.I.Inst_get().enterCD-t,e]))}else X.R.Inst_get().BossIsAlive(this.bossData)}OnCloseRecord(){this.recordWidget.SetActive(!1)}
OnAttentionClick(){const t=new te.m
t.bossId=this.objectCfg.id,this.selectSpt.activeInHierarchy?t.type=0:t.type=1,M.C.Inst.F_SendMsg(t)}OnUpdateAttentionInfo(){const t=this.objectCfg.id
this.selectSpt.SetActive(this.tModel.attentionLis.IndexOf(t,0)>=0)}}ee.STAGE_ID=143
var se=s(51347),ie=s(32953),ne=s(96531)
class le extends Gt.f{constructor(...t){super(...t),this.icon=null,this.nameLabel=null,this.timeLabel=null,this.delayId=null,this.mapId=null,this.mapCfg=null,this.repeatCount=null}
InitView(){super.InitView(),this.icon=this.CreateComponent(Nt.w,1),this.nameLabel=this.CreateComponent(kt.Q,2),this.timeLabel=this.CreateComponent(kt.Q,3)}Clear(){
this.RemoveFullScreenCollider(this.node,this.CreateDelegate(this.Close)),null!=this.delayId&&b.C.Inst_get().ClearInterval(this.delayId),super.Clear()}Destroy(){super.Destroy()}
OnAddToScene(){this.AddLis(),this.mapId=u.F.getInst().flyItemMapId,this.mapCfg=wt.p.Inst_get().GetMapById(this.mapId),this.icon.spriteNameSet(this.mapCfg.senceUi),
this.nameLabel.textSet(this.mapCfg.name),this.repeatCount=0,this.delayId=b.C.Inst_get().SetInterval(this.CreateDelegate(this.AutoClose),1e3,4)}AddLis(){
this.AddFullScreenCollider(this.node,this.CreateDelegate(this.Close))}AutoClose(){if((()=>(this.repeatCount+=1,this.repeatCount))()>=4)this.Close()
else{const t=4-this.repeatCount
this.timeLabel.textSet(`${V.M.IntToString(t)}秒后自动关闭`)}}Close(){Se.inst.OpenFlyMapItem(),L.N.inst.ClosePanel()}}var oe,ae,re,he,de,ce,Ie,ue=s(85986),pe=s(10909),_e=s(70415)
class ge extends Gt.f{constructor(...t){super(...t),this.transVo=null,this.acceesList=null,this.monsterId=0,this.grid_item=null,this.text_self_def=null,this.text_recommend=null,
this.img_weidacheng=null,this.btn_close=null,this.btn_go=null,this.text_tip=null}InitView(){super.InitView(),this.grid_item=this.CreateComponent(Lt.A,1),
this.text_self_def=this.CreateComponent(kt.Q,2),this.text_recommend=this.CreateComponent(kt.Q,3),this.img_weidacheng=this.CreateComponent(Nt.w,4),
this.btn_close=this.CreateComponent(Rt.W,5),this.btn_go=this.CreateComponent(Rt.W,6),this.text_tip=this.CreateComponent(kt.Q,7),
this.grid_item.SetInitInfo("ui_access_iconitem",null,pe.j)}SetData(t){this.transVo=t,this.monsterId=t.objectId,this.acceesList=T.a.inst.getObjById(this.monsterId).accessList}
OnAddToScene(){this.AddLis(),this.UpdatePanel()}Clear(){this.RemoveLis(),super.Clear(),this.grid_item.Clear()}Destroy(){super.Destroy(),this.grid_item.Destroy()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.btn_close,this.CreateDelegate(this.OnClickBtnClose)),this.m_handlerMgr.AddClickEvent(this.btn_go,this.CreateDelegate(this.OnClickBtnGo))}
RemoveLis(){this.m_handlerMgr.RemoveClickEvent(this.btn_close,this.CreateDelegate(this.OnClickBtnClose)),
this.m_handlerMgr.RemoveClickEvent(this.btn_go,this.CreateDelegate(this.OnClickBtnGo))}UpdatePanel(){this.grid_item.data_set(this.acceesList)
const t=_e.i.Inst().getItemById(this.monsterId).defenseRec
this.text_recommend.textSet(t)
const e=u.F.getInst().GetPlayerMaxDef()
e<t?(this.text_self_def.SetColor(Y.l.txtRedColor),this.img_weidacheng.node.SetActive(!0)):(this.text_self_def.SetColor(Y.l.txtGreenColor),this.img_weidacheng.node.SetActive(!1)),
this.text_self_def.textSet(e)}OnClickBtnGo(){Se.inst.CloseUpDefPanel()
const t=new h.P(this.transVo.targetX,this.transVo.targetY,0)
o.i.Inst.RaiseEvent(d.g.SMALL_MAP_MOVE_TO_MONSTER,t),h.P.Recyle(t)}OnClickBtnClose(){Se.inst.CloseUpDefPanel()}}function me(t,e,s,i,n){var l={}
return Object.keys(i).forEach((function(t){l[t]=i[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=s.slice().reverse().reduce((function(s,i){return i(t,e,s)||s}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let Se=(oe=(0,_.GH)(ot.k.SM_ChangeChannel),ae=(0,_.GH)(ot.k.SM_Get_MapChannel),re=(0,_.GH)(ot.k.SM_MapLockStatus),
he=(0,_.GH)(ot.k.SM_UnLockBossMap),de=(0,_.GH)(ot.k.SM_NewUnlockMap),Ie=class t{static get inst(){return t._inst||(t._inst=new t),t._inst}get topSmallMapPanel(){
return this._topSmallMapPanel=(0,g.Y)(m.o.TopSmallMapView),this._topSmallMapPanel}constructor(){this._topSmallMapPanel=null,this.topBigMapPanel=null,
this.SmallMapCurrentViewTreeSelect="",this.m_currentMapId=0,this.openType=0,this.lastChangeLineTime=0,this.m_changeLinePanel=null,this.monsterTipTransVo=null,
this.monsterTipPos=null,this.monsterTip=null,this.upDefPanel=null,this.IsSpecialOpen=!1,this.SpecialOpenId=0,this.TaskOpenMap=0,this.DefaultOpenMapId=0,
this.isAutoOpenBossChallengeView=!1,this.DefaultOpenSceneMapId=0,this.SpecialTreeId="",this.isOpenByMultipleHang=!1,this.NeedOpenMapAfterEnterMap=!1,this.SpecialOpenMonsterLevel=0,
this.SpecialOpenType=0,this.showMaxPass=!1,this._degf_CallChangeLineDestory=null,this._degf_CallDestory=null,this._degf_CallMapDestory=null,this._degf_ChangeLineHandler=null,
this._degf_ChangeMapProsComplete=null,this._degf_MapHandler=null,this._degf_OnArriveToTargetPos=null,this._degf_OnInterval=null,this._degf_SM_ChangeChannelHandler=null,
this._degf_SM_Get_MapChannelHandler=null,this._degf_SM_MapGoldenPointHandler=null,this._degf_SM_MapLockStatusHandler=null,this._degf_SM_NewUnlockMapHandler=null,
this._degf_TopMapHandler=null,this._degf_ExitGoldWarHandler=null,this.hasGuideText=null,this.unlockEffectList=null,this.ryWorldMapExpTipsView=null,this.WORD_MAP=null,
this.upDefTransVo=null,this._degf_CallChangeLineDestory=()=>this.CallChangeLineDestory(),this._degf_CallDestory=()=>this.CallDestory(),
this._degf_CallMapDestory=()=>this.CallMapDestory(),this._degf_ChangeLineHandler=t=>this.ChangeLineHandler(t),this._degf_ChangeMapProsComplete=t=>this.ChangeMapProsComplete(t),
this._degf_MapHandler=t=>this.MapHandler(t),this._degf_OnArriveToTargetPos=t=>this.OnArriveToTargetPos(t),this._degf_OnInterval=()=>this.OnInterval(),
this._degf_SM_ChangeChannelHandler=t=>this.SM_ChangeChannelHandler(t),this._degf_SM_Get_MapChannelHandler=t=>this.SM_Get_MapChannelHandler(t),
this._degf_SM_MapGoldenPointHandler=t=>this.SM_MapGoldenPointHandler(t),this._degf_SM_MapLockStatusHandler=t=>this.SM_MapLockStatusHandler(t),
this._degf_SM_NewUnlockMapHandler=t=>this.SM_NewUnlockMapHandler(t),this._degf_TopMapHandler=t=>this.TopMapHandler(t),this._degf_ExitGoldWarHandler=t=>this.ExitGoldWarHandler(t),
this.AddMsgPool(),o.i.Inst.AddEventHandler(d.g.EnterMap,(0,i.v)(this.DealEnterMap,this))}currentView_get(){return null!=this.topBigMapPanel?this.topBigMapPanel.sceneView:null}
worldView_get(){return null!=this.topBigMapPanel?this.topBigMapPanel.worldView:null}CurrentMapId_get(){
return null==this.m_currentMapId||0==this.m_currentMapId?a.b.Inst.currentMapId_get():this.m_currentMapId}CurrentMapId_set(t){this.m_currentMapId=t}AddMsgPool(){
I.u.Inst().AddEventHandler(c.Z.UpdateMapPassInfo,(0,i.v)(this.CreateOrClearNowMapChallengeBoss,this)),o.i.Inst.AddEventHandler(d.g.ROLANDSAVE_END,(0,
i.v)(this.OnRolandSaveEnd,this))}OpenPanel(){const t=new O.v
t.positionType=P.Z.eCustom,t.layerType=E.F.DefaultUI,t.ReLoginOrChangeRoleIsDestroy=!1,(0,g.Yp)(m.o.TopSmallMapView,t,this._degf_TopMapHandler)}OpenMapPanel(e,s,i,n,l,o){
if(null==e)if(q.p.inst.IsInCopy())e=t.SCENE_MAP
else{const s=u.F.getInst().unplayUnlockEffectMaps
e=u.F.getInst().CheckHasMapNotChallengeBoss()||null!=s&&s.Count()>0?t.WORD_MAP:t.SCENE_MAP}let r=a.b.Inst.currentMapId_get()
const h=a.b.Inst.GetCurMap(),d=u.F.getInst().GetMapNotChallengeBoss()
null==i&&(i=!1),this.showMaxPass=i,this.isAutoOpenBossChallengeView=l,this.DefaultOpenSceneMapId=0,this.DefaultOpenMapId=0,this.hasGuideText=o,null!=s?(r=s,
this.DefaultOpenSceneMapId=s):(null!=n?this.DefaultOpenMapId=n:h.controllerType!=B.N.SCENE&&h.controllerType!=B.N.ROLAND_CLIENT&&h.controllerType!=B.N.ROLAND_SERVER||0==d||(e=t.WORD_MAP,
this.DefaultOpenMapId=d),0!=this.DefaultOpenMapId&&(e=t.WORD_MAP))
const c=a.b.Inst.GetCurMap()
c.controllerType!=B.N.WORLD_BOSS?null==c||0!=c.smallMapName&&c.controllerType!=B.N.BATTLEFIELD?(this.openType=e,this._openMap()):Tt.y.inst.ClientStrMsg(at.r.SystemTipMessage,(0,
f.T)("当前地图无法打开")):Tt.y.inst.ClientStrMsg(at.r.SystemTipMessage,(0,f.T)("挑战世界BOSS中，无法打开"))}AddToTop(){(0,g.Yp)(m.o.TopSmallMapView)}OpenMapPanelByMansterSpawnId(e,s){
s=s||Ot.v.Normal
const i=a.b.Inst.currentMapId_get()
if(wt.p.Inst_get().GetMapById(i).controllerType==B.N.WORLD_BOSS)return void Tt.y.inst.ClientStrMsg(at.r.SystemTipMessage,(0,f.T)("挑战世界BOSS中，无法打开"))
const n=st.h.GetInst().GetSpwanItemById(e),l=T.a.getInst().getObjById(n.objectKey)
this.IsSpecialOpen=!0,this.SpecialOpenId=e,this.SpecialOpenMonsterLevel=l.level,s==Ot.v.MultipleHang?(u.F.getInst().isOpenByMultipleHang=!0,
this.SpecialTreeId=`${n.name} `):(u.F.getInst().isOpenByMultipleHang=!1,this.SpecialTreeId=n.name),V.M.String2Int(n.mapId)==i?this.openType=t.SCENE_MAP:this.openType=t.WORD_MAP,
this._openMap()}OpenWoldMapGuideByMapId(t){this.IsSpecialOpen=!0}OpenSceneMapByMansterSpawnId(e){const s=a.b.Inst.currentMapId_get()
if(wt.p.Inst_get().GetMapById(s).controllerType==B.N.WORLD_BOSS)return void Tt.y.inst.ClientStrMsg(at.r.SystemTipMessage,(0,f.T)("挑战世界BOSS中，无法打开"))
const i=st.h.GetInst().GetSpwanItemById(e)
this.IsSpecialOpen=!0,this.SpecialOpenId=e,u.F.getInst().isOpenByMultipleHang?this.SpecialTreeId=`${i.name} `:this.SpecialTreeId=i.name,this.openType=t.SCENE_MAP,this._openMap()}
OpenCurrentMapByMansterSpawnId(e){const s=a.b.Inst.currentMapId_get()
wt.p.Inst_get().GetMapById(s).controllerType!=B.N.WORLD_BOSS?(this.SpecialOpenId=(0,C.aI)(e),this.openType=t.SCENE_MAP,
this._openMap()):Tt.y.inst.ClientStrMsg(at.r.SystemTipMessage,(0,f.T)("挑战世界BOSS中，无法打开"))}ReqGoldMonsterInfos(){}SendPlayUnlockEffect(t){
null==this.unlockEffectList&&(this.unlockEffectList=new r.Z),this.unlockEffectList.Add(t),b.C.Inst_get().CallLater((0,i.v)(this.DalayReqPlayUnlockEffect,this))}
DalayReqPlayUnlockEffect(){null!=this.unlockEffectList&&(this.ReqPlayUnlockEffect(this.unlockEffectList),this.unlockEffectList=null)}ReqPlayUnlockEffect(t){const e=new lt.p
e.mapIds=t,M.C.Inst.F_SendMsg(e)}GotoTargetPos(t,e,s){const i=t
if(!D.c.Instance_get().CanArrive(i.x,i.z))return
if(e=null!=e,v._.getInst().endHang(),n.Y.isMapFindWay=!0,v._.getInst().openOrCloseStartIcon(),x.b.Inst_get().InteraptPath(i))return;(t=new r.Z).Add(e),t.Add(i.x),t.Add(i.z),
n.Y.Inst.PrimaryRole_get().gotoPoint(i,l.m.Point,s,t)
const o=h.P.zero_get()
n.Y.Inst.PrimaryRole_get().GetCurPos(o)
const a=h.P.zero_get()
a.x=i.x,a.z=i.z,u.F.getInst().LastFindPathLink_set(null),h.P.Recyle(a)}SM_MapGoldenPointHandler(t){const e=t
null!=e&&u.F.getInst().SetMapMonster(e)}_openMap(){U.V.SendClickData(H.p.Step_315000)
const t=new O.v
t.isShowMask=!0,t.isDefaultUITween=!0,(0,g.Yp)(G.I.eMap,t,this._degf_MapHandler)}OpenWorldMapExpTipView(){const t=new O.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.layerType=E.F.Alert,(0,g.Yp)(G.I.RyWorldMapExpTipsView,t)}CloseWorldMapExpPanel(){(0,g.sR)(G.I.RyWorldMapExpTipsView)}MapHandler(t){
this.topBigMapPanel=(0,g.Y)(G.I.eMap),this.ChangeMap()}CallMapDestory(){}CloseMapPanel(){this.NeedOpenMapAfterEnterMap||(u.F.getInst().isOpenByMultipleHang=!1),
t.inst.DefaultOpenMapId=0,this.CurrentMapId_set(0),(0,g.sR)(G.I.eMap),o.i.Inst.RaiseEvent(d.g.CHANGE_MAP)}GoToMap(t){
if(_t.k.Inst_get().isAttacked_get()||_t.k.Inst_get().isRolePkTime_get())return Tt.y.inst.ClientStrMsg(at.r.SystemTipMessage,(0,f.T)("当前处于PK状态下，禁止传送。")),Bt._.Inst().isSearch=!1,
void(ut.w.Inst_get().isSearch=!1)
if(!X.R.Inst_get().CanExitCrossBattle())return Bt._.Inst().isSearch=!1,void(ut.w.Inst_get().isSearch=!1)
const e=V.M.String2Int(t)
S.s.Info((0,f.T)(`请求切地图:${e}`)),rt.x.Instance.ChangeMap(e,this._degf_ChangeMapProsComplete,e)}ExitGoldWarHandler(t){J.J.Inst().ReqExitCrossServer()}ChangeMapProsComplete(t){
const e=N.GF.INT(t)
A.B.Inst.RequestCM_WorldTransport(e),this.CloseMapPanel()}ShowSubItem(t){this.topBigMapPanel||(this.topBigMapPanel=(0,g.Y)(G.I.eMap)),
null!=this.topBigMapPanel&&this.topBigMapPanel.isShow_get()&&null!=this.worldView_get()&&this.worldView_get().ShowSubItem(t)}ClosePanel(){L.N.inst.ClosePanel(this.topSmallMapPanel)
}TopMapHandler(t){this.ChangeMap()}GetRolandFlyIconPos(){
return null!=this.topSmallMapPanel&&this.topSmallMapPanel.node?this.topSmallMapPanel.mapPassBtn.transform.GetLocalPosition():h.P.zero_get()}CallDestory(){
R.g.DestroyUIObj(this.topSmallMapPanel)}changeLine(t,e){if(null==e&&(e=!1),A.B.Inst.IsTransportFly())Tt.y.inst.ClientStrMsg(at.r.SystemTipMessage,(0,f.T)("传送状态下无法进行该操作"))
else if(e)Tt.y.inst.ClientStrMsg(at.r.SystemTipMessage,(0,f.T)("跟随状态下无法进行该操作"))
else if(n.Y.Inst.PrimaryRoleInfo_get().CurLine_get()!=t&&w.D.serverTime_get()-this.lastChangeLineTime>1){this.lastChangeLineTime=w.D.serverTime_get()
const e=new it.w
e.channelId=t,n.Y.Inst.PrimaryRole_get().StopPathWithOutNoticeServer(),n.Y.Inst.PrimaryRole_get().ClearMoveParam(),n.Y.isMapFindWay=!1,yt.Y.isInTaskFindWay=!1,
v._.getInst().openOrCloseStartIcon(),M.C.Inst.F_SendMsg(e)}}getMapLines(){const t=new nt.D
M.C.Inst.F_SendMsg(t)}GotoByLinkStr(t,e){if(null==e&&(e=!1),u.F.getInst().LastFindPathLink_get()==t)return
const s=yt.Y.JoinValue(t)
let i=null
const o=N.GF.INT(s[1])
if(o==vt.d.KILL_MONSTER_VALUE?i=et.e.Inst_get().GetCfgById(N.GF.INT(s[4])):o==vt.d.MAP_TRANSPORTLINE_VALUE&&(i=et.e.Inst_get().GetCfgByMapAndPos(N.GF.INT(s[2]),s[4],s[5])),e){
A.B.Inst.CanTransport(i.id)&&(this.CloseMapPanel(),this.CloseMapPanel(),v._.getInst().endHang(),u.F.getInst().isFlying=!0,A.B.Inst.CM_FlyShoesTransportHandle(i.id))}else{
let e=h.P.zero_get()
if(o==vt.d.KILL_MONSTER_VALUE){if(e=new h.P(i.targetX,0,i.targetY).Clone(),a.b.Inst.currentMapId_get()==N.GF.INT(s[2])){v._.getInst().endHang()
const s=0
v._.getInst().ishang_get()||(n.Y.isMapFindWay=!0,v._.getInst().openOrCloseStartIcon()),
n.Y.Inst.PrimaryRole_get().gotoPoint(e,l.m.Point,this._degf_OnArriveToTargetPos,null,0,s)&&u.F.getInst().LastFindPathLink_set(t)}
}else if(o==vt.d.MAP_TRANSPORTLINE_VALUE)if(e=new h.P(s[4],0,s[5]).Clone(),
a.b.Inst.currentMapId_get()==N.GF.INT(s[2])&&N.GF.INT(s[3])==u.F.getInst().CurLine_get())v._.getInst().endHang(),v._.getInst().ishang_get()||(n.Y.isMapFindWay=!0,
v._.getInst().openOrCloseStartIcon()),
n.Y.Inst.PrimaryRole_get().gotoPoint(e,l.m.Point,this._degf_OnArriveToTargetPos,null,0,K.I.responseRadius-.2)&&u.F.getInst().LastFindPathLink_set(t)
else{const t=u.F.getInst()
t.transferMap=N.GF.INT(s[2]),t.transferX=N.GF.INT(e.x),t.transferY=N.GF.INT(e.z),this.CloseMapPanel(),this.CloseMapPanel(),
y.D.Inst.RequestCM_ChangeMapAndLine(N.GF.INT(s[2]),N.GF.INT(s[3]),e.x,e.z)}}}OnArriveToTargetPos(t){n.Y.isMapFindWay=!1,v._.getInst().openOrCloseStartIcon(),
v._.getInst().startHang()}ChangeMap(){null!=this.topSmallMapPanel&&this.topSmallMapPanel.node&&this.topSmallMapPanel.isShow_get()&&this.topSmallMapPanel.ChangeMap(),
null!=this.topBigMapPanel&&this.topBigMapPanel.isShow_get()&&null!=this.currentView_get()&&this.currentView_get().ChangeMap()}SetMenuActive(t){
null!=this.topSmallMapPanel&&this.topSmallMapPanel.node&&this.topSmallMapPanel.isShow_get()&&this.topSmallMapPanel.SetMenuActive(t)}SetWorldMenuActive(t){
null!=this.worldView_get()&&this.worldView_get().SetMenuActive(t)}CheckChangeMap(){
if(a.b.Inst.currentMapId_get()==u.F.getInst().transferMap&&0!=u.F.getInst().transferX&&0!=u.F.getInst().transferY){
const t=new h.P(u.F.getInst().transferX,0,u.F.getInst().transferY)
n.Y.Inst.PrimaryRole_get().gotoPoint(t,l.m.Point),u.F.getInst().transferMap=0,u.F.getInst().transferX=0,u.F.getInst().transferY=0}}BackToCurrentMap(){this.CloseMapPanel(),
this.OpenMapPanel()}SM_ChangeChannelHandler(t){const e=t
u.F.getInst().CurLine_set(e.channelId),n.Y.Inst.PrimaryRoleInfo_get().CurLine_set(e.channelId),a.b.Inst.SendEnterWorld()
const s=V.M.IntToString(u.F.getInst().CurLineShow_get(e.channelId)),i=new r.Z([s])
Tt.y.inst.ClientSysMessage(100535,i),pt.k.inst.clearAuotoPk(),o.i.Inst.RaiseEvent(d.g.CHANGE_LINE),b.C.Inst_get().SetInterval(this._degf_OnInterval,200,1)}OnInterval(){
F.j.Inst_get().model.OnEnterScene(),yt.Y.PlayEffect()}SM_Get_MapChannelHandler(t){const e=t
u.F.getInst().UpdateLineInfo(e.channels,e.teamLeaderAtChannelId)}SM_ChannelGoldenPointHandler(t){}SetViewLine(t){
null!=this.topSmallMapPanel&&this.topSmallMapPanel.node&&this.topSmallMapPanel.SetLineText(t)}EnterCopy(){
null!=this.topSmallMapPanel&&this.topSmallMapPanel.node&&this.topSmallMapPanel.radarView.ChangeMap()}ForceCloseForMapJudge(){
null!=this.topSmallMapPanel&&this.topSmallMapPanel.node&&this.topSmallMapPanel.node.SetActive(!1)}ForceOpenForMapJudge(){
null!=this.topSmallMapPanel&&this.topSmallMapPanel.node&&(this.topSmallMapPanel.node.SetActive(!0),this.topSmallMapPanel.ForcePlayAni())}OpenChangeLinePanel(){const t=new O.v
t.isShowMask=!0,t.isDefaultUITween=!0,L.N.inst.OpenById(G.I.eChangeLinePanel,this._degf_ChangeLineHandler,this._degf_CallChangeLineDestory,t)}ChangeLineHandler(t){
return null==this.m_changeLinePanel&&(this.m_changeLinePanel=new xt,this.m_changeLinePanel.setId(t,null,0)),this.m_changeLinePanel}CallChangeLineDestory(){
R.g.DestroyUIObj(this.m_changeLinePanel),this.m_changeLinePanel=null}CloseChangeLinePanel(){L.N.inst.CloseById(G.I.eChangeLinePanel)}SM_MapLockStatusHandler(t){
u.F.getInst().mapLockStatus=t.mapLockStatus,u.F.getInst().unplayUnlockEffectMaps=t.unPlayerMapIds,mt.a.Inst_get().canEnterCrossServer=t.canEnterCross,
St.w.ins.needEnterRoLand=t.needEnterRoLand,o.i.Inst.RaiseEvent(d.g.UNPLAY_UNLOCK_MAP_UPDATE),this.SendUnlockMap()}OnRolandSaveEnd(){
u.F.getInst().mapLockStatus.LuaDic_AddOrSetItem(20048,!0),u.F.getInst().unplayUnlockEffectMaps.Add(20048),mt.a.Inst_get().canEnterCrossServer=!0,
o.i.Inst.RaiseEvent(d.g.UNPLAY_UNLOCK_MAP_UPDATE),this.SendUnlockMap()}SM_UnLockBossMapHandle(t){ft.p.inst.SendClientLogicSetting(Ct.R.NOT_ENTER_NEW_MAP,t.mapId),
u.F.getInst().mapbossPassStatus.LuaDic_AddOrSetItem(t.mapId,!0),o.i.Inst.RaiseEvent(d.g.UPDATE_UNLOCK_BOSS_CHANLLENGE_INFO),ht.N.Inst().LoadDirector()}JudgeCanEnterMapHandler(t,e){
this.IsContinueGotoMap(t,!0)?this.GoToMap(t):e&&this.OpenMapPanel(this.WORD_MAP,null,null,t)}IsContinueGotoMap(e,s){const i=wt.p.Inst_get().GetMapById(e)
let n=0
n=0!=i.relatedMapId?i.relatedMapId:i.id
const l=u.F.getInst().GetCanEnterMapByLvAndTransfer(e)
if(!u.F.getInst().mapLockStatus[n]||l!=Mt.f.CAN){if(i.conditions.typevalues.Count()>0){let t=0
for(;t<i.conditions.typevalues.Count();){const e=i.conditions.typevalues[t]
if(e.type==$._.t_COMPLETE_QUEST){const t=At.L.Inst_get().model.GetTaskById(V.M.String2Int(e.value)),i=t.taskName_get()
if(!At.L.Inst_get().model.IsTaskCompleted(t.id_get())){if(s){const t=new r.Z([i])
Tt.y.inst.ClientSysMessage(106033,t)}return!1}}t+=1}}return s&&t.ShowLimitTip(l,i),!1}return!!A.B.Inst.ReachWingLimit(e)}static ShowLimitTip(t,e){if(t==Mt.f.TRANSFOR_LIMIT){
const t=e.transferJobLimitLevel
let s=""
const i=Dt.Q.model.GetMasterStartLevel()
s=e.minLevelLimit>i?`大师${(0,C.tw)(e.minLevelLimit-i)}`:gt.h.GetLevelStr(e.minLevelLimit)
const n=new r.Z([Y.l.GetChineseNum(t),s])
Tt.y.inst.ClientSysMessage(106039,n)}else if(t==Mt.f.LV_LIMIT){const t=new r.Z([gt.h.GetLevelStr2(e.minLevelLimit)])
Tt.y.inst.ClientSysMessage(106026,t)}else t==Mt.f.BOSS_LIMIT&&Tt.y.inst.ClientSysMessage(104344)}ShowPassMapTip(t){const e=new W.B
e.replaceParams.Add(t.res.mapName+t.res.name),e.cancelText=(0,f.T)("取 消"),e.confirmText=(0,f.T)("前往推关"),e.confirmHandle=this.OnGoPassMap,e.confirmParam=t,
e.infoId="MAPCHECKPOINT:NOTICE",j.t.Inst().Open(e)}OnGoPassMap(t){
null==I.u.inst.nowFightVo||a.b.Inst.currentMapId_get()!=I.u.inst.nowFightVo.res.mapId?ht.N.Inst().GotoKillMonsterOrBoss(t,null,!0):ht.N.Inst().GotoKillMonsterOrBoss(I.u.inst.nowFightVo)
}OpenMonsterTip(t,e){this.monsterTipTransVo=t,this.monsterTipPos=e.Clone()
const s=new O.v
s.layerType=E.F.Tip,s.positionType=k.$.eCustom,s.viewClass=ue.B,L.N.inst.OpenById(G.I.eMapGateTip,null,null,s)}CloseMonsterTip(){L.N.inst.CloseById(G.I.eMapGateTip)}
AutoOpenMultipleHang(){const e=t.inst.monsterTipTransVo
if(e){const t=e.spawnId
if(0!=t){const s=st.h.inst.GetSpwanItemById(t)
null!=s&&1==s.goldPoint&&It.X.Inst_get().IsOpen()&&It.X.Inst_get().multiHangState==dt.O.Off&&It.X.Inst_get().multiTime>0&&ct.j.inst.CM_MultiHangEnterHandle(e.spawnId)}
v._.getInst().startHang()}}OpenUpDefPanel(t){if(null!=this.upDefPanel&&this.upDefPanel.isShow_get())return
this.upDefTransVo=t
const e=new O.v
e.positionType=E.F.Alert,e.isShowMask=!0,L.N.inst.OpenById(G.I.eSmallUpDefPanel,this.OnUpDefPanelLoad,this.CallUpDefPanelDestory,e)}CloseUpDefPanel(){
L.N.inst.CloseById(G.I.eSmallUpDefPanel)}OnUpDefPanelLoad(t){return null==this.upDefPanel&&(this.upDefPanel=new ge),this.upDefPanel.SetData(this.upDefTransVo),
this.upDefPanel.setPrefabRootId(t),this.upDefPanel}CallUpDefPanelDestory(){null!=this.upDefPanel&&(R.g.DestroyUIObj(this.upDefPanel),this.upDefPanel=null),this.upDefTransVo=null}
SM_NewUnlockMapHandler(t){const e=t
if(null!=e.statusList){let t=0
for(;t<e.statusList.Count();)u.F.getInst().mapLockStatus[e.statusList[t]]=!0,t+=1
for(t=0,this.ReceiveUnlockEffectMaps(e.unplayerIds);t<e.unplayerIds.Count();)t+=1}}ReceiveUnlockEffectMaps(t){
t.Count()>0&&(null==u.F.getInst().unplayUnlockEffectMaps&&(u.F.getInst().unplayUnlockEffectMaps=new r.Z),u.F.getInst().unplayUnlockEffectMaps.AddRange(t),this.SendUnlockMap())}
SendUnlockMap(){q.p.inst.IsInCopy()||u.F.getInst().RaiseEvent(bt.f.UnlockMap)}NeedOpenMapAfterEnterMap_Set(t){this.NeedOpenMapAfterEnterMap=t}DealEnterMap(){
this.NeedOpenMapAfterEnterMap&&(this.IsSpecialOpen=!0,this.OpenMapPanel(t.SCENE_MAP)),this.CreateOrClearNowMapChallengeBoss(),this.CheckFlyItem(),
this.NeedOpenMapAfterEnterMap_Set(!1)}OpenBossChallengeView(t){u.F.getInst().curUnLockBossMapId=t
const e=new O.v
e.isShowMask=!0,e.isDefaultUITween=!0,e.layerType=E.F.Alert,e.viewClass=ie.a,L.N.inst.OpenById(G.I.MapUnlockBossChangeView,null,null,e)}OpenCrossBossChallengeView(t){
Q.I.Inst_get().selectBossData=t
const e=new O.v
e.isShowMask=!1,e.isDefaultUITween=!0,e.layerType=E.F.MainUI,e.viewClass=ee,L.N.inst.OpenById(G.I.MapCrossBossChallengeView,null,null,e)}CloseCrossBossChallengeView(){
L.N.inst.CloseById(G.I.MapCrossBossChallengeView)}CheckFlyItem(){if(0!=a.b.Inst.lastCopyMapId){const t=tt.o.Inst().getItemById(z.a.Inst.lastCopyId)
null!=t&&t.controllerType==Z.S.UnlockMapBoss&&(this.OpenMapUnlockView(),this.GotoUnlockMapHang())}}OpenFlyMapItem(){const t=new O.v
t.layerType=E.F.Tip,t.viewClass=Ht,L.N.inst.OpenById(G.I.MapUnlockFlyItem,null,null,t)}OpenMapUnlockView(){if(0!=u.F.getInst().flyItemMapId){const t=new O.v
t.layerType=E.F.MainUI,t.isShowMask=!0,t.isDefaultUITween=!0,t.viewClass=le,L.N.inst.OpenById(G.I.MapUnlockView,null,null,t)}}GotoUnlockMapHang(){
const t=u.F.getInst().unlockBossWinUnlockMapId
if(0!=t){const e=I.u.Inst().GetHighestGateByMap(t)
null!=e&&e.hasServer&&ht.N.Inst().GotoKillMonsterOrBoss(e,!1,null,null),u.F.getInst().unlockBossWinUnlockMapId=0}}OpenUnlockMapBossFbInfoView(){const t=new O.v
t.layerType=E.F.DefaultUI,t.viewClass=ne.V,(0,g.Yp)(G.I.UnlockMapBossFbView)}CloseUnlockMapBossFbInfoView(){(0,g.sR)(G.I.UnlockMapBossFbView)}CreateOrClearNowMapChallengeBoss(){}
OpenMapLevelAccessTip(t,e){u.F.getInst().leveltipsData=new r.Z([t,e])
const s=new O.v
s.isShowMask=!0,s.isDefaultUITween=!0,s.viewClass=se.t,e&&this.CloseWorldMapExpPanel(),L.N.inst.OpenById(G.I.MapLevelTips,null,null,s)}CloseMapLevelAccessTip(){
L.N.inst.CloseById(G.I.MapLevelTips)}},Ie._inst=null,Ie.WORD_MAP=0,Ie.SCENE_MAP=1,me(ce=Ie,"inst",[p.n],Object.getOwnPropertyDescriptor(ce,"inst"),ce),
me(ce.prototype,"SM_ChangeChannelHandler",[oe],Object.getOwnPropertyDescriptor(ce.prototype,"SM_ChangeChannelHandler"),ce.prototype),
me(ce.prototype,"SM_Get_MapChannelHandler",[ae],Object.getOwnPropertyDescriptor(ce.prototype,"SM_Get_MapChannelHandler"),ce.prototype),
me(ce.prototype,"SM_MapLockStatusHandler",[re],Object.getOwnPropertyDescriptor(ce.prototype,"SM_MapLockStatusHandler"),ce.prototype),
me(ce.prototype,"SM_UnLockBossMapHandle",[he],Object.getOwnPropertyDescriptor(ce.prototype,"SM_UnLockBossMapHandle"),ce.prototype),
me(ce.prototype,"SM_NewUnlockMapHandler",[de],Object.getOwnPropertyDescriptor(ce.prototype,"SM_NewUnlockMapHandler"),ce.prototype),ce)},60975:(t,e,s)=>{s.d(e,{p:()=>l})
var i=s(83908),n=s(86133)
class l extends((0,i.yk)()){constructor(...t){super(...t),this.m_cfg=null,this.isradar=!1}Cfg_get(){return this.m_cfg}Cfg_set(t,e){}InitView(){}GetTips(){let t=""
return t=this.m_cfg.name+(0,n.T)("1线"),t}}},72801:(t,e,s)=>{s.d(e,{r:()=>a})
var i=s(86133),n=s(93877),l=s(72005),o=s(32246)
class a extends o.o{constructor(...t){super(...t),this.name=null,this.m_goldMonster=null}GoldMonster_get(){return this.m_goldMonster}GoldMonster_set(t){this.m_goldMonster=t,
this.name.textSet(this.m_goldMonster.cfg.name),this.AddEvents()}InitView(){this.sp=new l.w,this.sp.setId(this.FatherId,this.FatherComponentID,1),this.name=new n.Q,
this.name.setId(this.FatherId,this.FatherComponentID,2)}GetTips(){let t=""
return t=`${this.m_goldMonster.cfg.name}（${this.m_goldMonster.line+(0,i.T)("线）")}`,t}}},81888:(t,e,s)=>{s.d(e,{D:()=>n})
var i=s(32246)
class n extends i.o{}},78205:(t,e,s)=>{s.d(e,{l:()=>l})
var i=s(99294),n=s(32246)
class l extends n.o{constructor(...t){super(...t),this.miss=null}InitView(){super.InitView(),this.miss=new i.z,this.miss.setId(this.FatherId,this.FatherComponentID,2)}}},
73482:(t,e,s)=>{s.d(e,{e:()=>o})
var i=s(77697),n=s(98580),l=s(32246)
class o extends l.o{constructor(...t){super(...t),this.m_cfg=null}Cfg_get(){return this.m_cfg}Cfg_set(t){this.m_cfg=t,this.AddEvents(),this.UpdateStatus()}UpdateStatus(){
null!=this.sp&&(this.Cfg_get().status_get()==n.B.CAN_ACCEPT||(this.Cfg_get().status_get(),n.B.FINISHED))}GetTips(){let t=`${this.Cfg_get().taskName_get()}:`,e=0
e=this.Cfg_get().status_get()==n.B.CAN_ACCEPT?this.Cfg_get().AcceptNpcId_get():this.Cfg_get().RewardNpcId_get()
return t+=i.f.Inst().getItemByIdRaw(e).name,t}}},87750:(t,e,s)=>{s.d(e,{c:()=>n})
var i=s(32246)
class n extends i.o{constructor(...t){super(...t),this.m_teamMemberId=null}TeamMemberId_get(){return this.m_teamMemberId}TeamMemberId_set(t){this.m_teamMemberId=t,this.AddEvents()}
}},63476:(t,e,s)=>{s.d(e,{Z:()=>l})
var i=s(93877),n=s(30849)
class l extends n.C{constructor(...t){super(...t),this.text=null,this.w=0,this.h=0,this.isradar=!1}InitView(){super.InitView(),this.text=new i.Q,
this.text.setId(this.FatherId,this.FatherComponentID,1)}}},39179:(t,e,s)=>{s.d(e,{r:()=>a})
var i=s(86133),n=s(66788),l=s(21334),o=s(32246)
class a extends o.o{constructor(...t){super(...t),this.m_cfg=null}Cfg_get(){return this.m_cfg}Cfg_set(t){this.m_cfg=t,this.AddEvents()}GetTips(){
const t=l.p.Inst_get().GetMapById(this.Cfg_get().targetMapId)
if(null==t)return n.Y.LogError(this.Cfg_get().targetMapId+(0,i.T)("找不到地图配置")),""
return t.name}}},20808:(t,e,s)=>{s.d(e,{X:()=>l})
var i=s(83908),n=s(6251)
class l extends((0,i.yk)()){InitView(){}SetData(t,e){n.d.LuaMakeGoGray(this.point.node,e)}}},64969:(t,e,s)=>{s.d(e,{C:()=>h})
var i=s(83908),n=s(57834),l=s(31922),o=s(97943),a=s(57051),r=s(12970)
class h extends((0,i.yk)()){constructor(...t){super(...t),this.isradar=!1,this.transVo=null,this.showMonsterTip=!1}InitView(){}AddEvents(){
n.i.Get(this.dituIcon.node).RegistonClick(this.CreateDelegate(this.ClickHandler))}RemoveEvents(){n.i.Get(this.dituIcon.node).RemoveonClick(this.CreateDelegate(this.ClickHandler))}
ClickHandler(t){r.F.getInst().RaiseEvent(o.f.CurrentMapItemClick,this.transVo),this.showMonsterTip}Clear(){this.RemoveEvents()}SetTitle(t,e,s){if(this.AddEvents(),this.transVo=s,
e==l.z.MapViewTreeGoldMonster)this.dituIcon.spriteNameSet("ditu_sp_0018")
else if(e==l.z.MapViewTreeMonster)this.dituIcon.spriteNameSet("ditu_sp_0018"),this.showMonsterTip=!0
else if(e==l.z.MapViewTreeNPC){const t=a.c.GetIconStr(a.c.NPC)
this.dituIcon.spriteNameSet(t)}else e==l.z.MapViewTreeTransNPC&&this.dituIcon.spriteNameSet("ditu_sp_0003")
this.dituIcon.node.SetActive(!0),this.lab_title.node.SetActive(!this.isradar),this.lab_title.textSet(t)}}},32246:(t,e,s)=>{s.d(e,{o:()=>o})
var i=s(83908),n=s(97943),l=s(12970)
class o extends((0,i.yk)()){constructor(...t){super(...t),this.w=0,this.h=0,this.isradar=!1}InitView(){}AddEvents(){}UpdateShow(){}ClickHandler(t){
l.F.getInst().RaiseEvent(n.f.CurrentMapItemClick,null)}GetTips(){return""}}},54695:(t,e,s)=>{var i,n=s(18998),l=s(83908)
const{ccclass:o,property:a}=n._decorator
o("WorldMapCloudEffectItem")(i=class extends((0,l.yk)()){InitView(){}SetEffectAlpha(t){0==t&&(t=.002)}SetBgAlpha(t){0==t&&(t=.002),this.bg.SetAlpha(255*t)}SetItemActive(t){
this.mat1.node.SetActive(t),this.mat2.node.SetActive(t),this.mat3.node.SetActive(t),this.bg.node.SetActive(t)}})},91118:(t,e,s)=>{
var i,n=s(18998),l=s(75507),o=s(83908),a=s(32076),r=s(96098),h=s(97461),d=s(68662),c=s(2689),I=s(13687),u=s(62370),p=s(5924),_=s(85682),g=s(18202),m=s(28192),S=s(98885),f=s(85602),C=s(73790),T=s(92679),y=s(87923),A=s(92473),v=s(55552),D=s(68637),w=s(83900),B=s(91690),M=s(21267),b=s(15821),O=s(41864),R=s(65550),L=s(21334),G=s(6251),P=s(62783),E=s(31931),k=s(12970)
const{ccclass:N,property:V}=n._decorator
N("WorldMapItem")(i=class extends((0,o.yk)()){constructor(...t){super(...t),this._m_handlerMgr=null,this.unlockEffect=null,this.mapId=0,this.ctrlId=0,this.mapProgressVo=null,
this.IsSpecialOpen=!1,this.taskOpen=!1,this.isOpenGuide=!1,this._degf_ClickHandler=null,this._degf_OnUnplayUpdate=null,this.cfg=null,this.isOpenMap=null,this.openEffTimerId=null,
this.showRewardMap=null}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=m.h.Get()),this._m_handlerMgr}_initBinder(){super._initBinder(),
this._degf_ClickHandler=(t,e)=>this.ClickHandler(t,e),this._degf_OnUnplayUpdate=t=>this.OnUnplayUpdate(t)}MapId_get(){return this.mapId}MapId_set(t){this.mapId=t,this.UpdateView()}
InitView(){this.titlebg.SetActive(!1),this.passObj.SetActive(!1),this.rewardBtn.SetActive(!1),this.guideText.node.SetActive(!1),this.lab_gates.node.SetActive(!1),
this.alpha.node.opacity=127.5,this.titlebg.SetActive(!1),this.effect.SetActive(!1),this.level.textSet(""),this.GuideSpTween.getComponent(C.a).isRepeatForever=!0}OnAddToScene(){
this.AddListeners()}Clear(){this.IsSpecialOpen=!1,this.taskOpen=!1,this.isOpenGuide=!1,this.RemoveListeners(),null!=this.unlockEffect&&(g.g.DestroyUIObj(this.unlockEffect),
this.unlockEffect=null)}AddListeners(){this.m_handlerMgr.AddClickEvent(this.node,this._degf_ClickHandler),
h.i.Inst.AddEventHandler(T.g.UNPLAY_UNLOCK_MAP_UPDATE,this._degf_OnUnplayUpdate),this.m_handlerMgr.AddClickEvent(this.rewardBtn,this.CreateDelegate(this.OnRewardBtn)),
M.u.Inst().AddEventHandler(B.Z.UpdateMapPassInfo,this.CreateDelegate(this.UpdateGate)),h.i.Inst.AddEventHandler(b.i.NEWBIE_MAP_BOTTOM_CITY_BTN,(0,a.v)(this.onExecNewbie,this)),
this.RegGuide()}RemoveListeners(){this.m_handlerMgr.RemoveClickEvent(this.node,this._degf_ClickHandler),
M.u.Inst().RemoveEventHandler(B.Z.UpdateMapPassInfo,this.CreateDelegate(this.UpdateGate)),h.i.Inst.RemoveEventHandler(T.g.UNPLAY_UNLOCK_MAP_UPDATE,this._degf_OnUnplayUpdate),
this.m_handlerMgr.RemoveClickEvent(this.rewardBtn,this.CreateDelegate(this.OnRewardBtn)),h.i.Inst.RemoveEventHandler(b.i.NEWBIE_MAP_BOTTOM_CITY_BTN,(0,
a.v)(this.onExecNewbie,this)),this.UnRegGuide()}onExecNewbie(t){if(this.mapId==t){const t=L.p.Inst_get().GetMapById(this.MapId_get())
if(null!=t){y.l.IsEmptyStr(t.mapQuest)
const e=k.F.getInst().IsOpenMap(t.id,!0),s=!y.l.IsEmptyStr(t.worldmap)
e&&s&&P.X.inst.ShowSubItem(this)}}}RegGuide(){D.c.Inst.RegGameObject(_.D.UI_MAP_ITEM_BTN,this.node,this.mapId)}UnRegGuide(){D.c.Inst.UnRegGameObject(_.D.UI_MAP_ITEM_BTN,this.mapId)
}CheckGuide(){y.l.CheckBtnClickTrigger(_.D.UI_MAP_ITEM_BTN,this.mapId),this.guideText.node.SetActive(!1)}OnUnplayUpdate(t){this.UpdateView()}ClickHandler(t,e){
const s=L.p.Inst_get().GetMapById(this.MapId_get())
if(this.CheckGuide(),A.R.Inst_get().CanExitCrossBattle()&&null!=s){const t=!y.l.IsEmptyStr(s.mapQuest),e=k.F.getInst().IsOpenMap(s.id,!0),i=!1,n=!y.l.IsEmptyStr(s.worldmap)
if(t){if(e)if(i);else if(n)P.X.inst.ShowSubItem()
else{const t=k.F.getInst().GetMapNotChallengeBoss(),e=I.b.Inst.GetCurMap()
if(this.IsCanOpenBossChallengeView(e)&&t==this.MapId_get())return void P.X.inst.OpenBossChallengeView(t)
this.IsSpecialOpen?P.X.inst.NeedOpenMapAfterEnterMap_Set(!0):P.X.inst.NeedOpenMapAfterEnterMap_Set(!1)
const s=M.u.Inst().GetHighestGateByMap(this.MapId_get())
null!=s?r.B.Inst.CM_FlyShoesTransportHandle(M.u.Inst().GetTransVoById(s.id).id,null,null,!0):P.X.inst.JudgeCanEnterMapHandler(this.MapId_get()),h.i.Inst.RaiseEvent(T.g.CHANGE_MAP),
P.X.inst.CloseMapPanel()}}else if(e)if(n)P.X.inst.ShowSubItem(this)
else{const t=k.F.getInst().GetMapNotChallengeBoss(),e=I.b.Inst.GetCurMap()
if(this.IsCanOpenBossChallengeView(e)&&t==this.MapId_get())return void P.X.inst.OpenBossChallengeView(t)
this.IsSpecialOpen?P.X.inst.NeedOpenMapAfterEnterMap_Set(!0):P.X.inst.NeedOpenMapAfterEnterMap_Set(!1)
const s=M.u.Inst().GetHighestGateByMap(this.MapId_get())
null!=s&&10001!=this.MapId_get()?r.B.Inst.CM_FlyShoesTransportHandle(M.u.Inst().GetTransVoById(s.id).id,null,null,!0):P.X.inst.JudgeCanEnterMapHandler(this.MapId_get()),
h.i.Inst.RaiseEvent(T.g.CHANGE_MAP)}else if(L.p.Inst_get().GetLastMapIsOpen(s.id))if(n)k.F.getInst().curWorldCfg=s,P.X.inst.OpenWorldMapExpTipView()
else{const t=new f.Z([O.h.GetLevelStr(this.cfg.minLevelLimit),s.name])
R.y.inst.ClientSysMessage(11030330,t),P.X.inst.OpenMapLevelAccessTip(this.cfg.id,!1)}else R.y.inst.ClientSysStrMsg("请先通关前一个地图的地图首领")}}IsCanOpenBossChallengeView(t){
return t.controllerType==c.N.SCENE||t.controllerType==c.N.ROLAND_CLIENT||t.controllerType==c.N.ROLAND_SERVER||t.controllerType==c.N.MULTIPLE_HANG}setLevelText(t){
this.level.textSet(O.h.GetLevelStr(t.minLevelLimit))}UpdateView(){const t=L.p.Inst_get().GetMapById(this.MapId_get())
if(this.cfg=t,this.isOpenMap=!1,this.isOpenGuide=!1,null!=t){this.mapSp.spriteNameSet("preload:/atlas/ditu/"+t.senceUi),d.D.IsIosShenhe()&&this.name.textSet(t.name),
this.setLevelText(t)
const e=L.p.Inst_get().GetLastMapIsOpen(this.MapId_get()),s=(k.F.getInst().GetCanEnterMapByLvAndTransfer(this.MapId_get()),E.f.BOSS_LIMIT,
k.F.getInst().IsOpenMap(this.MapId_get(),!0)&&e)
if(this.isOpenGuide=k.F.getInst().IsOpenGuideMap(this.MapId_get(),!0),this.isOpenMap=s,P.X.inst.IsSpecialOpen&&0!=P.X.inst.SpecialOpenId){
const e=v.h.GetInst().GetSpwanItemById(P.X.inst.SpecialOpenId),s=L.p.Inst_get().GetMapById(S.M.String2Int(e.mapId))
s.id==t.id||s.groupName==t.groupName&&""!=s.groupName?this.IsSpecialOpen=!0:this.IsSpecialOpen=!1
}else 0!=P.X.inst.DefaultOpenMapId?t.ContainMap(P.X.inst.DefaultOpenMapId)?this.taskOpen=!0:this.taskOpen=!1:0!=P.X.inst.TaskOpenMap&&(t.ContainMap(P.X.inst.TaskOpenMap)?this.taskOpen=!0:this.taskOpen=!1)
if(s||this.IsSpecialOpen||e?s&&k.F.getInst().IsUnplayUnlockMap(this.cfg.id)?this.ShowOpenEff():(this.lock.node.SetActive(!1),this.lockpic.node.SetActive(!1),
"罗兰城"==this.cfg.name&&(this.lockpic.node.SetActive(!0),this.lock.node.SetActive(!0))):(this.lock.node.SetActive(!1),this.lockpic.node.SetActive(!0)),
this.effect.SetActive(s||this.isOpenGuide),null!=this.unlockEffect&&(g.g.DestroyUIObj(this.unlockEffect),this.unlockEffect=null),
s||this.IsSpecialOpen||e?(this.alpha.node.opacity=255,this.titlebg.SetActive(!0)):(this.alpha.node.opacity=127.5,this.titlebg.SetActive(!1)),this.GuideSpTween.SetActive(!1),
this.guideText.node.SetActive(!1),(this.IsSpecialOpen||this.taskOpen||this.isOpenGuide)&&(this.GuideSpTween.SetActive(!0),P.X.inst.hasGuideText?(this.guideText.node.SetActive(!0),
this.guideSp.SetActive(!1)):(this.guideText.node.SetActive(!1),this.guideSp.SetActive(!0))),s);else if(this.IsSpecialOpen){this.SpecialLock.SetActive(!0),
G.d.LuaMakeGoGray(this.mapSp.node,!0)
const e=new f.Z([O.h.GetLevelStr2(this.cfg.minLevelLimit),t.name])
R.y.inst.ClientSysMessage(11030330,e)}else this.SpecialLock.SetActive(!1),G.d.LuaMakeGoGray(this.mapSp.node,!1)}else this.lockpic.node.SetActive(!1),this.effect.SetActive(!1),
null!=this.unlockEffect&&(g.g.DestroyUIObj(this.unlockEffect),this.unlockEffect=null)
this.UpdateGate()}ShowOpenEff(){this.openEffTimerId=p.C.Inst_get().SetInterval(this.CreateDelegate(this.DelayOpenShowEffect),500,1)}DelayOpenShowEffect(){
k.F.getInst().RemoveUnplayUnlockMap(this.cfg.id),P.X.inst.SendPlayUnlockEffect(this.cfg.id),this.lock.node.SetActive(!0),this.lockpic.node.SetActive(!1)}UpdateGate(){
this.titlebg.SetActive(!1),this.passObj.SetActive(!1),this.rewardBtn.SetActive(!1),this.lab_gates.node.SetActive(!1)
const t=L.p.Inst_get().GetMapById(this.mapId)
if(this.showRewardMap=null,null!=t&&this.isOpenMap){let e=!1,s=0,i=0
if(!y.l.IsEmptyStr(t.worldmap)){const n=S.M.Split(t.worldmap,u.o.s_Arr_UNDER_CHAR_DOT)
e=!0
for(let t=0;t<=n.Count()-1;t++){const l=S.M.String2Int(n[t]),o=M.u.Inst().GetMapPassProgressVoByMapId(l)
null!=o?(null==this.showRewardMap&&(this.showRewardMap=this.IsShowGateReward(l)),this.IsShowPassObj(l)||(e=!1),s+=o.nowLevel,i+=o.maxLevel):e=!1}}else{
const t=this.mapId,n=M.u.Inst().GetMapPassProgressVoByMapId(t)
null!=n?(this.showRewardMap=this.IsShowGateReward(t),e=!!this.IsShowPassObj(t),s=n.nowLevel,i=n.maxLevel):e=!1}this.rewardBtn.SetActive(!1),this.passObj.SetActive(e),
i>0&&!e?(this.lab_gates.node.SetActive(!0),this.lab_gates.textSet(`${s}/${i}`),this.titlebg.SetActive(!0)):e&&this.titlebg.SetActive(!0)}}IsShowGateReward(t){
const e=M.u.Inst().GetMapPassProgressVoByMapId(t)
if(null!=e){const s=e.GetNearRewardLevelCanGet(1)
if(null!=s)return M.u.Inst().GetMapPassVoByMapAndLevel(t,s).id}return null}IsShowPassObj(t){const e=M.u.Inst().GetMapPassProgressVoByMapId(t)
return!(null==e||!e.isPass)}OnRewardBtn(){null!=this.showRewardMap&&w.N.Inst().CM_RewardMapPassHandle(this.showRewardMap)}DelayShowEffect(){
const t=L.p.Inst_get().GetMapById(this.MapId_get()),e=k.F.getInst().IsOpenMap(this.MapId_get())&&!(!y.l.IsEmptyStr(t.mapQuest)&&k.F.getInst().IsUnplayUnlockMap(t.id))
this.effect.SetActive(e||this.isOpenGuide)}Unlock(){const t=l.o.getPrefab("ui_topsmallmap_worldunlockeffect");(0,n.instantiate)(t).setParent(this.node)}InMap(t){
if(this.MapId_get()==t)return!0
const e=L.p.Inst_get().GetMapById(this.MapId_get())
if(null!=e&&""!=e.worldmap){const s=S.M.Split(e.worldmap,u.o.s_Arr_UNDER_CHAR_DOT)
let i=0
for(;i<s.count;){if(S.M.String2Int(s[i])==t)return!0
i+=1}}return!1}})},9544:(t,e,s)=>{s.d(e,{d:()=>O})
var i,n=s(18998),l=s(83908),o=s(32076),a=s(96098),r=s(97461),h=s(2689),d=s(13687),c=s(85682),I=s(28192),u=s(98885),p=s(85602),_=s(92679),g=s(87923),m=s(55552),S=s(68637),f=s(83900),C=s(91690),T=s(21267),y=s(15821),A=s(41864),v=s(65550),D=s(21334),w=s(62783),B=s(12970)
const{ccclass:M,property:b}=n._decorator
let O=M("RyWorldMapExpTipsItem")(i=class extends((0,l.yk)()){constructor(...t){super(...t),this._m_handlerMgr=null,this.cfg=null,this.IsSpecialOpen=null,this.IsOpenGuide=null,
this.isOpen=null,this.isShowEff=null,this.showRewardMap=null}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=I.h.Get()),this._m_handlerMgr}InitView(){
this.passObj.SetActive(!1),this.rewardBtn.SetActive(!1),this.lab_gates.node.SetActive(!1)}SetData(t){if(this.cfg=t,this.AddLis(),w.X.inst.IsSpecialOpen&&0!=w.X.inst.SpecialOpenId){
const e=m.h.GetInst().GetSpwanItemById(w.X.inst.SpecialOpenId),s=D.p.Inst_get().GetMapById(u.M.String2Int(e.mapId))
s.id==t.id||s.groupName==t.groupName&&""!=s.groupName?this.IsSpecialOpen=!0:this.IsSpecialOpen=!1}else this.IsSpecialOpen=!1
this.IsOpenGuide=B.F.getInst().IsOpenGuideMap(this.cfg.id)
let e=!1
0!=w.X.inst.DefaultOpenMapId?this.cfg.id==w.X.inst.DefaultOpenMapId&&(e=!0):0!=w.X.inst.TaskOpenMap?this.cfg.id==w.X.inst.TaskOpenMap&&(e=!0):this.IsOpenGuide&&(e=!0),
e?(this.effect.SetActive(!0),w.X.inst.hasGuideText?(this.arrowNode.SetActive(!1),this.textNode.SetActive(!0)):(this.arrowNode.SetActive(!0),
this.textNode.SetActive(!1))):this.effect.SetActive(!1)
const s=B.F.getInst().IsOpenMap(this.cfg.id,!0,!0),i=!s,n=t.minLevelLimit,l=g.l.GetRuleDecimalValEx(t.standardExperience)
i?(this.nameLab.textSet(`[635B57]${t.name}[-]`),this.label.SetColorRGBA(99/255,91/255,87/255,1),this.expLab.textSet(`[635B57]${l}[-]`),this.enterbtn.node.SetActive(!1),
this.enterbtUnlockBoss.SetActive(!1),this.enterbtUnlockBoss2.SetActive(!1),this.lockbtn.SetActive(!0),
this.lvLab.textSet(`[962424]${A.h.GetLevelStr(n)}[-]`)):(this.enterbtn.node.SetActive(!1),this.enterbtUnlockBoss.SetActive(!1),this.enterbtUnlockBoss2.SetActive(!1),
this.nameLab.textSet(t.name),this.label.SetColorRGBA(68/255,60/255,56/255,1),this.lvLab.textSet(A.h.GetLevelStr(n)),this.expLab.textSet(l),
B.F.getInst().IsOpenMap(this.cfg.id)?this.enterbtn.node.SetActive(!0):D.p.Inst_get().GetLastMapIsOpen(this.cfg.id)?this.enterbtUnlockBoss.SetActive(!0):this.enterbtUnlockBoss2.SetActive(!0),
this.lockbtn.SetActive(!1)),this.UpdateGate(),this.isOpen=s,this.isShowEff=e}UpdateGate(){this.passObj.SetActive(!1),this.rewardBtn.SetActive(!1),this.lab_gates.node.SetActive(!1),
this.showRewardMap=null
if(B.F.getInst().ExistOpenMap(this.cfg.id,!0)){this.lvLab.textSet("")
let t=!1,e=0,s=0
const i=this.cfg.id,n=T.u.Inst().GetMapPassProgressVoByMapId(i)
null!=n?(this.showRewardMap=this.IsShowGateReward(i),this.IsShowPassObj(i)||(t=!1),e=n.nowLevel,s=n.maxLevel):t=!1,this.passObj.SetActive(t),
s>0&&!t&&(this.lab_gates.node.SetActive(!0),this.lab_gates.textSet(`${e}/${s}`))}}ClickLockHandler(){this.CheckGuide()
const t=new p.Z([A.h.GetLevelStr2(this.cfg.minLevelLimit),this.cfg.name])
v.y.inst.ClientSysMessage(11030330,t),w.X.inst.TaskOpenMap=0,w.X.inst.DefaultOpenMapId=0,B.F.getInst().OpenEffMapId=null,w.X.inst.OpenMapLevelAccessTip(this.cfg.id,!0)}
IsShowGateReward(t){const e=T.u.Inst().GetMapPassProgressVoByMapId(t)
if(null!=e){const s=e.GetNearRewardLevelCanGet(1)
if(null!=s)return T.u.Inst().GetMapPassVoByMapAndLevel(t,s).id}return null}IsShowPassObj(t){const e=T.u.Inst().GetMapPassProgressVoByMapId(t)
return!(null==e||!e.isPass)}OnRewardBtn(){null!=this.showRewardMap&&f.N.Inst().CM_RewardMapPassHandle(this.showRewardMap)}EnterHandler(t){if(this.CheckGuide(),
t.target==this.enterbtn.node||t.target==this.enterbtUnlockBoss){let t=0
if(w.X.inst.SpecialOpenId&&0!=w.X.inst.SpecialOpenId){const e=m.h.GetInst().GetSpwanItemById(w.X.inst.SpecialOpenId)
t=u.M.String2Int(e.mapId)}let e=!1
this.IsSpecialOpen&&0!=t&&this.cfg.id==t&&(e=!0)
const s=B.F.getInst().GetMapNotChallengeBoss(),i=d.b.Inst.GetCurMap()
if(this.IsCanOpenBossChallengeView(i)&&s==this.cfg.id)return void w.X.inst.OpenBossChallengeView(s)
e?(w.X.inst.OpenSceneMapByMansterSpawnId(w.X.inst.SpecialOpenId),w.X.inst.NeedOpenMapAfterEnterMap_Set(!0)):w.X.inst.NeedOpenMapAfterEnterMap_Set(!1)
const n=T.u.Inst().GetHighestGateByMap(this.cfg.id)
null!=n?(a.B.Inst.CM_FlyShoesTransportHandle(T.u.Inst().GetTransVoById(n.id).id,null,null,!0),w.X.inst.CloseMapPanel()):w.X.inst.JudgeCanEnterMapHandler(this.cfg.id),
r.i.Inst.RaiseEvent(_.g.CHANGE_MAP)}else t.target==this.enterbtUnlockBoss2&&v.y.inst.ClientSysStrMsg("请先通关前一个地图的地图首领")
w.X.inst.CloseWorldMapExpPanel()}AddLis(){T.u.Inst().AddEventHandler(C.Z.UpdateMapPassInfo,this.CreateDelegate(this.UpdateGate)),
this.m_handlerMgr.AddClickEvent(this.enterbtn,this.CreateDelegate(this.EnterHandler)),
this.m_handlerMgr.AddClickEvent(this.enterbtUnlockBoss,this.CreateDelegate(this.EnterHandler)),
this.m_handlerMgr.AddClickEvent(this.enterbtUnlockBoss2,this.CreateDelegate(this.EnterHandler)),
this.m_handlerMgr.AddClickEvent(this.lockbtn,this.CreateDelegate(this.ClickLockHandler)),this.m_handlerMgr.AddClickEvent(this.rewardBtn,this.CreateDelegate(this.OnRewardBtn)),
r.i.Inst.AddEventHandler(y.i.NEWBIE_MAP_BOTTOM_CITY_ONE,(0,o.v)(this.onExecNewbie,this)),this.RegGuide()}IsCanOpenBossChallengeView(t){
return t.controllerType==h.N.SCENE||t.controllerType==h.N.ROLAND_CLIENT||t.controllerType==h.N.ROLAND_SERVER||t.controllerType==h.N.MULTIPLE_HANG}RemoveLis(){
T.u.Inst().RemoveEventHandler(C.Z.UpdateMapPassInfo,this.CreateDelegate(this.UpdateGate)),this.m_handlerMgr.RemoveClickEvent(this.enterbtn,this.CreateDelegate(this.EnterHandler)),
this.m_handlerMgr.RemoveClickEvent(this.enterbtUnlockBoss,this.CreateDelegate(this.EnterHandler)),
this.m_handlerMgr.RemoveClickEvent(this.enterbtUnlockBoss2,this.CreateDelegate(this.EnterHandler)),r.i.Inst.RemoveEventHandler(y.i.NEWBIE_MAP_BOTTOM_CITY_ONE,(0,
o.v)(this.onExecNewbie,this)),this.UnRegGuide()}onExecNewbie(t){if(this.CheckGuide(),this.cfg.id==t){let t=0,e=!1
this.IsSpecialOpen&&0!=t&&this.cfg.id==t&&(e=!0)
const s=B.F.getInst().GetMapNotChallengeBoss(),i=d.b.Inst.GetCurMap()
if(this.IsCanOpenBossChallengeView(i)&&s==this.cfg.id)return void w.X.inst.OpenBossChallengeView(s)
e?(w.X.inst.OpenSceneMapByMansterSpawnId(w.X.inst.SpecialOpenId),w.X.inst.NeedOpenMapAfterEnterMap_Set(!0)):w.X.inst.NeedOpenMapAfterEnterMap_Set(!1)
const n=T.u.Inst().GetHighestGateByMap(this.cfg.id)
null!=n?(a.B.Inst.CM_FlyShoesTransportHandle(T.u.Inst().GetTransVoById(n.id).id,null,null,!0),w.X.inst.CloseMapPanel()):w.X.inst.JudgeCanEnterMapHandler(this.cfg.id),
r.i.Inst.RaiseEvent(_.g.CHANGE_MAP),w.X.inst.CloseWorldMapExpPanel()}}Clear(){this.RemoveLis()}RegGuide(){S.c.Inst.RegGameObject(c.D.UI_MAP_ITEM_SUB_BTN,this.node)}UnRegGuide(){
S.c.Inst.UnRegGameObject(c.D.UI_MAP_ITEM_SUB_BTN)}CheckGuide(){g.l.CheckBtnClickTrigger(c.D.UI_MAP_ITEM_SUB_BTN),w.X.inst.hasGuideText=!1,this.textNode.SetActive(!1)}Test1(){
return!0}S_Test(){return!0}})||i},57019:(t,e,s)=>{var i,n=s(6847),l=s(83908),o=s(46282),a=s(5494),r=s(43308),h=s(62783),d=s(12970),c=s(9544);(0,
n.s_)(a.I.RyWorldMapExpTipsView,o.Z.ui_topsmallmap_world_expview).register()(i=class extends((0,l.Ri)()){constructor(...t){super(...t),this.cfg=null}InitView(){
this.grid.SetInitInfo("ui_topsmallmap_world_expitem",null,c.d),this.grid.OnReposition_set(this.CreateDelegate(this.OnGridReposition))}OnAddToScene(){
this.cfg=d.F.getInst().curWorldCfg,this.nameLab.textSet(this.cfg.groupName)
const t=d.F.getInst().GetGroupMaps(this.cfg)
this.grid.data_set(t),this.scrollpanel.ResetPosition(),this.m_handlerMgr.AddClickEvent(this.closebtn,this.CreateDelegate(this.CloseHandler))}CloseHandler(){
h.X.inst.CloseWorldMapExpPanel()}OnGridReposition(){if(null!=this.grid.itemList){let t=null
for(let e=this.grid.itemList.Count()-1;e>=0;e+=-1){const s=this.grid.itemList[e]
if(s.isShowEff){t=s.node
break}s.isOpen&&null==t&&(t=s.node)}}}Clear(){super.Clear(),r._.Inst_get().CloseView()}Destroy(){}Test1(){return!0}S_Test(){return!0}})},32298:(t,e,s)=>{
var i,n,l=s(18998),o=s(75507),a=s(83908),r=s(82815),h=s(38836),d=s(38045),c=s(23833),I=s(98800),u=s(97960),p=s(11895),_=s(36241),g=s(50089),m=s(6700),S=s(73136),f=s(65530),C=s(2689),T=s(13687),y=s(62370),A=s(5924),v=s(66788),D=s(65733),w=s(57834),B=s(85682),M=s(18202),b=s(52726),O=s(28192),R=s(60130),L=s(35128),G=s(48712),P=s(3809),E=s(98130),k=s(98885),N=s(85602),V=s(38962),x=s(52212),F=s(79534),U=s(44758),H=s(8125),j=s(72627),W=s(94148),Y=s(65407),q=s(92679),z=s(31922),Z=s(87923),X=s(29839),Q=s(85770),J=s(48933),$=s(75439),K=s(9659),tt=s(7708),et=s(55552),st=s(68637),it=s(91690),nt=s(21267),lt=s(98504),ot=s(77697),at=s(98580),rt=s(63412),ht=s(21334),dt=s(19276),ct=s(73082),It=s(62783),ut=s(97943),pt=s(57051),_t=s(69611),gt=s(12970),mt=s(60975),St=s(72801),ft=s(81888),Ct=s(78205),Tt=s(73482),yt=s(87750),At=s(63476),vt=s(39179),Dt=s(20808),wt=s(64969),Bt=s(16315),Mt=s(9537),bt=s(9165)
const{ccclass:Ot,property:Rt}=l._decorator
Ot("AsuramWarMapView")((n=class t extends((0,a.Ri)()){constructor(...t){super(...t),this._m_handlerMgr=null,this.m_freshkey=0,this.realityHalfH=0,this.realityHalfW=0,
this.isradar=!1,this.m_halfW=0,this.m_halfH=0,this.m_showHalfW=465,this.m_showHalfH=300,this.m_textureSizeW=256,this.m_textureSizeH=256,this.m_SelfPos=null,this.pointArr=null,
this.dragIndex=0,this.scaleValue=1,this.pathArrx=null,this.pathArrz=null,this.pointDic=null,this.pointPool=null,this.endPoint=null,this.transferItems=null,this.reliveItems=null,
this.textItems=null,this.siegeBuildItems=null,this.bossItems=null,this.taskItems=null,this.teamItems=null,this.miracleItems=null,this.mapIcons=null,this.awBuffIconDic=null,
this.awBuffIcons=null,this.tmpPathList=null,this.curMapId=0,this.curCopy=0,this.lastseg=-1,this.IsFocusRole=!1,this.IsScaled=!1,this.IsScaling=!1,this.IsShowDefaultRecommend=!1,
this.textureIdRGB=0,this.textureIdAlpha=0,this.mapCfg=null,this.pointHidePos=null,this.wh=null,this.textureSizeX=0,this.textureSizeY=0,this.sizeScale=1,this.isOneLoad=!0,
this.PointItemPool=null,this.isSiegeBulidUpdate=!1,this.isNeedUpdatePoint="",this.isTextureLoaded=!1,this.teamPos=null,this.localEulerAngle=null,this.pathEndPos=null,this.depth=30,
this.firstUpdateTree=!0,this.transShowDict=null,this.leftPointX=0,this.leftPointY=0,this.monsterInfoShowDict=null,this.serverMonsterDic=null,
this.multipleHangPointInfoShowPool=null,this.smallMapGateConnetPointItemPool=null,this.uimapscale=1,this.transcfg=null,this.monsterItem=null,this.type=null,this.mapAngel=0,
this._degf_ClickHandler=null,this._degf_CurrentMapItemClickHandler=null,this._degf_DragCallBack=null,this._degf_InitMap=null,this._degf_LoadTexture=null,
this._degf_LoadTexture2=null,this._degf_OnArriveToTargetPos=null,this._degf_PlayerRoadsJoystickUpdateHandler=null,this._degf_PlayerRoadsUpdateHandler=null,
this._degf_RefreshRoleMap=null,this._degf_TaskChangeHandler=null,this._degf_TeamMemberPositionHandler=null,this._degf_UpdateSiegeBuildInfoHandler=null,this.transformes=null,
this.isShowByGate=null,this.clearMultipleHangPointList=null,this.backgroundoffsetX=null,this.backgroundoffsetY=null}get m_handlerMgr(){
return this._m_handlerMgr||(this._m_handlerMgr=O.h.Get()),this._m_handlerMgr}_initBinder(){super._initBinder(),this.m_SelfPos=new F.P,this.pointArr=new N.Z,this.pathArrx=new N.Z,
this.pathArrz=new N.Z,this.pointDic=new V.X,this.pointPool=new N.Z,this.transferItems=new N.Z,this.reliveItems=new N.Z,this.textItems=new N.Z,this.siegeBuildItems=new N.Z,
this.bossItems=new N.Z,this.taskItems=new N.Z,this.teamItems=new N.Z,this.miracleItems=new N.Z,this.mapIcons=new N.Z,this.awBuffIconDic=new V.X,this.awBuffIcons=new N.Z,
this.tmpPathList=new N.Z,this.pointHidePos=new F.P(3e3,3e3,0),this.PointItemPool=new N.Z,this.localEulerAngle=new F.P(0,0,0),this.pathEndPos=F.P.zero_get(),
this.transShowDict=new V.X,this.monsterInfoShowDict=new V.X,this.serverMonsterDic=new V.X,this.multipleHangPointInfoShowPool=new V.X,this.smallMapGateConnetPointItemPool=new V.X,
this._degf_ClickHandler=(t,e)=>this.ClickHandler(t,e),this._degf_CurrentMapItemClickHandler=t=>this.CurrentMapItemClickHandler(t),
this._degf_DragCallBack=(t,e)=>this.DragCallBack(t,e),this._degf_InitMap=t=>this.InitMap(),this._degf_LoadTexture=t=>this.LoadTexture(t),
this._degf_LoadTexture2=t=>this.LoadTexture(t),this._degf_OnArriveToTargetPos=t=>this.OnArriveToTargetPos(t),
this._degf_PlayerRoadsJoystickUpdateHandler=t=>this.PlayerRoadsJoystickUpdateHandler(t),this._degf_PlayerRoadsUpdateHandler=t=>this.PlayerRoadsUpdateHandler(t),
this._degf_RefreshRoleMap=()=>this.RefreshRoleMap(),this._degf_TaskChangeHandler=t=>this.TaskChangeHandler(t),
this._degf_TeamMemberPositionHandler=t=>this.TeamMemberPositionHandler(t),this._degf_UpdateSiegeBuildInfoHandler=t=>this.UpdateSiegeBuildInfoHandler(t)}__SubInitClass3(){}
InitView(){this.bg.SetActive(!1),this.transformes=new N.Z,this.transformes.Add(this.m_bossTransform),this.transformes.Add(this.m_TransferTransform),this.isShowByGate=!1}
OnAddToScene(){this.AddEvents(),this.InitMap()}ResetItems(){this.HidePointItem(),this.HideRelive(),this.HideSiegeBuild(),this.HideTask(),this.HideTeamMembers(),this.HideText(),
this.HideTransfer(),this._delAllPathPoint(),this.ResetServerIcon()}OnRemoveFromScene(){this.RemoveEvents()}ChangeMap(){
this.curMapId==this.GetMapId()&&this.curCopy==Q.a.Inst_get().currentCopyId||this.InitMap()}GetMapId(){return this.isradar?T.b.Inst.currentMapId_get():It.X.inst.CurrentMapId_get()}
OnSceneGuide(){}InitMap(){this.curMapId==this.GetMapId()&&this.curCopy==Q.a.Inst_get().currentCopyId||this.ResetItems(),this.curMapId=this.GetMapId(),
this.curMapId!=T.b.Inst.currentMapId_get()?this.m_selfComponentWidget.node.SetActive(!1):this.m_selfComponentWidget.node.SetActive(!0),this.curCopy=Q.a.Inst_get().currentCopyId,
this.mapCfg=ht.p.Inst_get().GetMapById(this.curMapId),this.isradar?this.mapAngel=45:this.mapCfg.controllerType==C.N.SCENE?this.mapAngel=0:this.mapAngel=45,this.isradar,
this.localEulerAngle.Set(0,0,-this.mapAngel),this.wh=k.M.Split(this.mapCfg.w_h,y.o.s_UNDER_CHAR),this.textureSizeX=k.M.String2Float(this.wh[0]),
this.textureSizeY=k.M.String2Float(this.wh[1]),this.sizeScale=k.M.String2Float(this.mapCfg.smallMapScale)
let t=`atlas_smallmap_${k.M.IntToString(this.mapCfg.smallMapName)}`
m.L.Instance_get().HasResourceByPath(`${t}_rgb`)||(t="atlas_smallmap_10001"),0!=this.textureIdRGB&&(M.g.DestroyUIById(this.textureIdRGB),this.textureIdRGB=0),
0!=this.textureIdAlpha&&(M.g.DestroyUIById(this.textureIdAlpha),this.textureIdAlpha=0),this.bg.SetActive(!0),this.bg.widthSet(R.O.GetUIWidth()),this.bg.heightSet(R.O.GetUIHeight())
}LoadTexture(t){this.textureIdRGB=t[0],this.textureIdAlpha=t[1],this.UITextureLoaded()}UpdateInfos(){this.isOneLoad=!0,this.UpdateSelfPos(),this.isradar&&(this.UpdateBoss(),
this.UpdateTransfer()),this.UpdateRelive(),this.UpdateTask(),this.UpdateSiegeBuildInfoHandler(null),this.UpdateText(),this.TeamMemberPositionHandler(null),this.UpdateServerInfos()}
UpdateServerInfos(){W.b.Inst_get().InAsuramMap()&&(this.UpdateAsuramObjes(),this.UpdateAsuramFixPoints())}UpdateAsuramObjes(){if(W.b.Inst_get().InAsuramMap()){
const t=W.b.Inst_get().asuramWarObjects
if(null!=t){-1!=M.g.GetResFindId("ui_topsmallmap_mapicon")&&this.UpdateServerMonsters(t)}}}HidePointItem(){const t=this.PointItemPool.Count()
let e=0
for(;e<t;)null!=this.PointItemPool[e]&&null!=this.PointItemPool[e].node&&this.PointItemPool[e].node.transform.SetLocalPosition(this.pointHidePos),e+=1}HideMonster(){
this.monsterInfoShowDict.LuaDic_Count()
for(const[t,e]of(0,h.vy)(this.monsterInfoShowDict)){const t=e
null!=t.node&&t.node.transform.SetLocalPosition(this.pointHidePos)}}HideMultipleHangPoint(){let t=this.multipleHangPointInfoShowPool.LuaDic_Count()
null==this.clearMultipleHangPointList?this.clearMultipleHangPointList=new N.Z:this.clearMultipleHangPointList.Clear()
for(const[t,e]of(0,h.vy)(this.multipleHangPointInfoShowPool)){const s=e
s.transVo.targetMapId!=this.curMapId?this.clearMultipleHangPointList.Add(t):null!=s.node&&s.node.transform.SetLocalPosition(this.pointHidePos)}
for(let t=0;t<=this.clearMultipleHangPointList.Count()-1;t++){const e=this.clearMultipleHangPointList[t],s=this.multipleHangPointInfoShowPool[e]
null!=s&&(s.Clear(),M.g.DestroyUIObj(s)),this.multipleHangPointInfoShowPool.LuaDic_Remove(e)}t=this.smallMapGateConnetPointItemPool.LuaDic_Count()
for(const[t,e]of(0,h.vy)(this.smallMapGateConnetPointItemPool)){const t=e
null!=t.node&&t.node.transform.SetLocalPosition(this.pointHidePos)}}UpdatePointList(t,e){if(null==e&&(e=!1),this.type==t&&!e)return
this.type=t
const s=this.PointItemPool.Count()
if(this.HidePointItem(),this.HideBoss(),this.HideMonster(),this.HideMultipleHangPoint(),this.HideTransfer(),this.HideSiegeBuild(),this.isSiegeBulidUpdate=!1,
!this.isTextureLoaded)return void(this.isNeedUpdatePoint=t)
const i=this.GetMapId(),n=tt.j.GetInst().GetCfgById(i)
null!=n&&(t==z.z.MapViewTreeNPC?(this.UpdateNpcPoint(n,s),this.SetActiveTransform(this.m_bossTransform)):t==z.z.MapViewTreeMonster?(this.SetActiveTransform(this.m_bossTransform),
this.UpdateMonsterPoint(n,s),this.UpdateBossPoint(n,s)):t==z.z.MapViewTreeBoss?(this.SetActiveTransform(this.m_bossTransform),
this.UpdateBossPoint(n,s)):t==z.z.MapViewTreeGoldMonster?this.UpdateGoldMonsterPoint(i,s):t==z.z.MapViewTreeMultipleExpPoint?(this.SetActiveTransform(this.m_bossTransform),
this.UpdateMultipleHangPoint(n,s)):t==z.z.MapViewTreeTransNPC?(this.SetActiveTransform(this.m_bossTransform),
this.UpdateTransferNpcPoint(n,s)):t==z.z.MapViewTreeElite?(this.SetActiveTransform(this.m_bossTransform),
this.UpdateEliteMonsterPoint(n,s)):t==z.z.MapViewTreeTransport?(this.SetActiveTransform(this.m_TransferTransform),this.UpdateTransfer(),
this.CloseMonsterArea()):t==z.z.RadarMapShowAll&&(this.UpdateNpcPoint(n,s),this.UpdateMonsterPoint(n,s),this.UpdateBossPoint(n,s),this.UpdateGoldMonsterPoint(i,s),
this.UpdateMultipleHangPoint(n,s),this.UpdateTransfer(),this.UpdateEliteMonsterPoint(n,s)))}UpdateNpcPoint(t,e){const s=t.GetNpcCoordArr()
if(null==s)return
let i=0
for(;i<s.count;){if(""!=s[i]&&null!=s[i]){const t=ot.f.Inst().getItemById(k.M.String2Int(s[i]))
if(null!=t){const s=I.Y.Inst.CheckNpcShowOrHide(t)
if(null!=t&&s){const s=this.ShowPointItem(e,i,t.x,t.y)
s.isradar=this.isradar,s.SetTitle(t.name,z.z.MapViewTreeNPC)}}}i+=1}}UpdateMonsterPoint(t,e){const s=t.arrMonster
if(null==s||0==s.count)return
let i=0
for(;i<s.count;){const t=s[i]
if(null!=t&&t.count>1){const e=K.e.Inst_get().GetCfgById(t[2])
if(null!=e){let t=this.monsterInfoShowDict.LuaDic_GetItem(e.id)
null==t&&(t=this.GetMonsterInfoItem(e,null)),e.id==It.X.inst.SpecialOpenId?t.SetIndicate(!0):t.SetIndicate(!1),
this.Adapt2RadarMapViewXYZ(e.targetX,0,e.targetY,t.node.transform,this.m_bossTransform,!0,-10),this.monsterInfoShowDict.LuaDic_AddOrSetItem(e.id,t)}}i+=1}}UpdateServerMonsters(t){
const e=W.b.Inst_get().smallmapShowList
for(let s=0;s<=t.Count()-1;s++){const i=et.h.inst.GetSpwanItemById(t[s].modelId)
c.a.getInst().getObjById(i.objectKey)
e.IndexOf(t[s].modelId,0)>-1&&this.UpdateServerMonsterPoint(t[s])}}GetExistKey(t,e){for(let s=0;s<=t.Count()-1;s++){if(e==W.b.Inst_get().GetBuffKey(t[s]))return!0}return!1}
UpdateServerMonsterPoint(t){const e=et.h.inst.GetSpwanItemById(t.modelId)
let s=this.serverMonsterDic.LuaDic_GetItem(t.modelId)
W.b.Inst_get().IsDynamic(e.id)
const i=W.b.Inst_get().IsLiveDynamic(e.id)
t.currHp.ToNum()<=0?null!=s&&(s.node.transform.SetLocalPosition(this.pointHidePos),this.mapIcons.Add(s),
this.serverMonsterDic.LuaDic_Remove(t.modelId)):(null==s&&(s=this.GetServerMonsterInfoItem()),
this.serverMonsterDic.LuaDic_ContainsKey(t.modelId)?this.isradar&&s.SetMonsterId(t.modelId,t.currHp,t.maxHp):(this.Adapt2RadarMapViewXYZ(e.x,0,e.y,s.node.transform,this.m_bossTransform,!0,-10),
this.serverMonsterDic.LuaDic_AddOrSetItem(t.modelId,s),i||(s.SetMonsterId(t.modelId,t.currHp,t.maxHp),j.i.Inst_get().IsAltar(t.modelId)&&(s.SetIconWH(46,63),s.SetIconPos(0,18)),
this.SetMapIconPos(t.modelId,W.b.Inst_get().GetPosKey(e.objectKey)))))}UpdateBuffIcon(t){const e=this.GetAsuramWarBuffItem(t)
if(e.SetData(t),W.b.Inst_get().IsSelfBuff(t[0].spawnId))e.SetActive(!1)
else{const s=W.b.Inst_get().GetAltarPos(t[0].spawnId)
this.Adapt2RadarMapViewXYZ(s[0],0,s[1],e.node.transform,this.m_bossTransform,!0,10),e.SetActive(!0)}}UpdateAsuramFixPoints(){
const t=$.D.getInstance().GetNumberArray("ASURAMWAR:BORN_ATK_CLIENT")
let e=pt.c.GetIconStr(pt.c.ATTACK_BORN),s=W.b.Inst_get().GetIndex()
this.UpdateAsuramFixPoint(s,e,t[0],t[1],"进攻方集合点"),W.b.Inst_get().copyType==W.b.RecoveryModel?this.SetMapIconPos(s,"ASURAMWAR:SMALLMAP_1_POS_1"):this.SetMapIconPos(s,"ASURAMWAR:SMALLMAP_2_POS_1"),
e=pt.c.GetIconStr(pt.c.FORBIDEN),this.UpdateAsuramFixPoint(W.b.Inst_get().GetIndex(),e,136,170,"封闭"),this.UpdateAsuramFixPoint(W.b.Inst_get().GetIndex(),e,42,78,"封闭"),
this.UpdateAsuramFixPoint(W.b.Inst_get().GetIndex(),e,73,31,"封闭"),e=pt.c.GetIconStr(pt.c.THRONE)
const i=$.D.getInstance().GetStringValue("ASURAMWAR:THRONE_NAME"),n=W.b.Inst_get().thrones[0],l=ct.N.Inst().getWallItemById(n)
if(null!=l){s=-1
let t=""
const n=W.b.Inst_get().throneVo
null==n||k.M.IsNullOrEmpty(n.nickName)||(t=k.M.Replace("{0}正在坐","{0}",n.nickName)),this.UpdateAsuramFixPoint(s,e,l.playerPosX,l.playerPosY,i,t),
W.b.Inst_get().copyType==W.b.RecoveryModel?this.SetMapIconPos(s,"ASURAMWAR:SMALLMAP_1_POS_8"):this.SetMapIconPos(s,"ASURAMWAR:SMALLMAP_2_POS_5")}W.b.Inst_get().ResetIndex()}
SetMapIconPos(t,e){if(null==e)return
const[s,i]=W.b.Inst_get().GetRadarPos(e)
this.SetMapIconXY(t,i[1],i[2],s[1],s[2],s[3],s[4],s[5],s[6])}SetMapIconXY(t,e,s,i,n,l,o,a,r){const h=this.GetMapIcon(t)
null!=h&&(h.SetIconPos(i,n),null!=e&&h.SetNameAlign(),null!=s&&h.SetExtraLAlign(s),null!=l&&h.SetNamePos(l,o),null!=a&&h.SetExtraPos(a,r))}SetMapNameXY(t,e,s){
const i=this.GetMapIcon(t)
null!=i&&i.SetNamePos(e,s)}GetMapIcon(t){for(const[e,s]of(0,h.vy)(this.serverMonsterDic))if(e==t)return s}UpdateAsuramFixPoint(t,e,s,i,n,l){null==l&&(l="")
let o=this.serverMonsterDic.LuaDic_GetItem(t)
null==o&&(o=this.GetServerMonsterInfoItem()),this.Adapt2RadarMapViewXYZ(s,0,i,o.node.transform,this.m_bossTransform,!0,-10),o.SetData(e,n,l),
this.serverMonsterDic.LuaDic_AddOrSetItem(t,o)}GetServerMonsterInfoItem(){let t=null
if(this.mapIcons.Count()>0)t=P.B.PopFront(this.mapIcons)
else{const e=o.o.getPrefab("ui_topsmallmap_mapicon")
t=(0,l.instantiate)(e).getCNode(bt.K)}return t.node.setParent(this.m_bossTransform.node),t}GetAsuramWarBuffItem(t){let e=null
const s=W.b.Inst_get().GetBuffKey(t)
if(this.awBuffIconDic.LuaDic_ContainsKey(s))e=this.awBuffIconDic[s]
else{if(this.awBuffIcons.Count()>0)e=P.B.PopFront(this.awBuffIcons)
else{const t=o.o.getPrefab("ui_asuramwar_bufficon")
e=(0,l.instantiate)(t).getCNode(Y.v)}this.awBuffIconDic.LuaDic_AddOrSetItem(s,e)}return e.node.setParent(this.m_bossTransform.node),e}UpdateMultipleHangPoint(t,e){
const s=t.arrMultipleExp
if(null==s||0==s.count)return
let i=0
for(;i<s.count;){const t=s[i]
if(null!=t&&t.count>1){const e=K.e.Inst_get().GetCfgById(t[2])
if(null!=e){let t=this.multipleHangPointInfoShowPool.LuaDic_GetItem(e.id)
if(null==t&&(t=this.GetGateInfoItem(e)),null==t.pos){const s=this.Adapt2RadarMapViewXYZ(e.targetX,0,e.targetY,t.node.transform,this.m_bossTransform,!1,0)
t.pos=new F.P(s.x,s.y,0)}t.node.transform.SetLocalPositionXYZ(t.pos.x,t.pos.y,0),
this.isradar?t.node.transform.SetLocalScaleXYZ(.7,.7,1):t.node.transform.SetLocalScaleXYZ(.8*this.uimapscale,.8*this.uimapscale,1),
this.multipleHangPointInfoShowPool.LuaDic_AddOrSetItem(e.id,t)}const s=nt.u.Inst().GetResBySpawnId(e.spawnId),i=new N.Z(s.connetPoint)
for(let t=0;t<=i.Count()-1;t++){const e=`${s.id}_${t}`,n=nt.u.Inst().GetMapPassVo(s.id)
let l=this.smallMapGateConnetPointItemPool.LuaDic_GetItem(e)
null==l&&(l=this.GetGatePointItem(e,!(n.state!=lt.s.LOCK))),this.Adapt2RadarMapViewXYZ(i[t][1],0,i[t][2],l.node.transform,this.m_bossTransform,!1,0),
this.isradar?l.node.transform.SetLocalScaleXYZ(1,1,1):l.node.transform.SetLocalScaleXYZ(this.uimapscale,this.uimapscale,1),
this.smallMapGateConnetPointItemPool.LuaDic_AddOrSetItem(e,l)}}i+=1}}UpdateGateListInfo(){const t=this.multipleHangPointInfoShowPool
for(const[e,s]of(0,h.V5)(t))s.UpdateState()}UpdateBossPoint(t,e){const s=t.GetDicBoss()
if(null==s||0==s.Count())return
T.b.Inst.GetCurMap()
let i=0
const n=this.bossItems.Count()
for(const[t,e]of(0,h.vy)(s)){const t=e
if(null!=t){c.a.getInst().getObjById(t.monsterId)
const e=K.e.Inst_get().GetCfgById((0,d.aI)(t.playertransport[0]))
if(null!=e){let s=null
0<n?s=this.bossItems[0]:(s=this.GetBossPrefab(),this.bossItems.Add(s)),this.Adapt2RadarMapViewXYZ(e.targetX,0,e.targetY,s.node.transform,this.m_bossTransform,0>=n),
s.isradar=this.isradar,s.Cfg_set(t,this.isradar),i+=1}}}}UpdateGoldMonsterPoint(t,e){const s=gt.F.getInst().GetMapGoldPointByMapId(t),i=I.Y.Inst.PrimaryRoleInfo_get().CurLine_get()
let n=null
if(null!=s){if(s.goldenPoints.LuaDic_ContainsKey(i)){n=s.goldenPoints[i]
let t=0
for(;t<n.goldenPoints.Count();){const s=n.goldenPoints[t]
if(null!=s){const i=this.ShowPointItem(e,t,s.x,s.y),n=et.h.GetInst().GetSpwanItemById(s.spawnkey)
i.SetTitle(n.name,z.z.MapViewTreeGoldMonster)}t+=1}}}}UpdateTransferNpcPoint(t,e){const s=t.GetTransNpcArr()
if(null==s)return
let i=0
for(;i<s.count;){if(""!=s[i]&&null!=s[i]){const t=ot.f.Inst().getItemById(k.M.String2Int(s[i])),n=c.a.getInst().getObjById(t.objectID)
if(null!=t){this.ShowPointItem(e,i,t.x,t.y).SetTitle(n.name,z.z.MapViewTreeTransNPC)}}i+=1}}UpdateEliteMonsterPoint(t,e){let s=0
const i=t.GetDicElite()
for(const[t,n]of(0,h.vy)(i)){const n=i[t],l=c.a.getInst().getObjById(t)
if(null!=l)for(const[t,i]of(0,h.V5)(n))if(i>0){const t=K.e.Inst_get().GetCfgById(i)
this.ShowPointItem(e,s,t.targetX,t.targetY).SetTitle(l.name,z.z.MapViewTreeElite,t),s+=1}}}ShowPointItem(t,e,s,i){let n=null,l=!1
return t>e?n=this.PointItemPool[e]:(n=this.CreatePointItem(),l=!0),this.Adapt2RadarMapViewXYZ(s,0,i,n.node.transform,this.m_bossTransform,l),n}CreatePointItem(){
const t=o.o.getPrefab("ui_topsmallmap_obj_item"),e=(0,l.instantiate)(t).getCNode(wt.C)
return this.PointItemPool.Add(e),e}UITextureLoaded(){this.isTextureLoaded=!0,this.firstUpdateTree=!0,this.UpdateMap(),this.UpdateInfos(),this.UpdateMapPos(),
this.isradar?this.UpdatePointList(z.z.RadarMapShowAll,!0):(""!=this.isNeedUpdatePoint?(this.UpdatePointList(this.isNeedUpdatePoint,!0),
this.isNeedUpdatePoint=""):this.UpdatePointList(this.type,!0),this.OnSceneGuide())}SetShowState(t,e){this.isShowByGate=t,e&&(this.UpdateMap(),this.UpdateMapPos())}UpdateMap(){
let e=0
e=this.GetMapId()
const s=this.background.GetBoundsSize(),i=k.M.Split(this.mapCfg.w_h,y.o.s_UNDER_CHAR)
this.m_textureSizeW=k.M.String2Float(i[0]),this.m_textureSizeH=k.M.String2Float(i[1])
let n=0,l=0
i.Count()>3?(n=k.M.String2Float(i[2]),l=k.M.String2Float(i[3])):(n=this.m_textureSizeW,l=this.m_textureSizeH)
let o=1,a=1
const r=Math.max(n,l)
let h=s.x
for(;r>0&&h<r;)h*=2
o=n/h,a=l/h,this.uimapscale=1
Math.max(this.m_textureSizeH,this.m_textureSizeW)
if(!this.isradar&&this.isShowByGate&&""!=this.mapCfg.smallMapEnlarge?this.uimapscale=k.M.String2Float(this.mapCfg.smallMapEnlarge):this.uimapscale=1,
this.isradar||([this.textureSizeX,this.textureSizeY,this.sizeScale,this.uimapscale]=this.CalMapSize(l,n,this.uimapscale)),
1!=this.uimapscale&&(this.m_textureSizeH=E.GF.RoundToInt(this.m_textureSizeH*this.uimapscale),this.m_textureSizeW=E.GF.RoundToInt(this.m_textureSizeW*this.uimapscale),
n=E.GF.RoundToInt(n*this.uimapscale),l=E.GF.RoundToInt(l*this.uimapscale)),this.background.widthSet(L.p.CeilToInt(n)),this.background.heightSet(L.p.CeilToInt(l)),
i.Count()>5?(J.I.calVec5.Set(k.M.String2Float(i[4])*this.uimapscale,k.M.String2Float(i[5])*this.uimapscale,0),this.background.node.transform.SetLocalPosition(J.I.calVec5),
this.backgroundoffsetX=J.I.calVec5.x,this.backgroundoffsetY=J.I.calVec5.y):(this.backgroundoffsetX=0,this.backgroundoffsetY=0,
this.background.node.transform.SetLocalPosition(F.P.zero_get())),this.m_halfW=E.GF.INT(.5*this.m_textureSizeW),this.m_halfH=E.GF.INT(.5*this.m_textureSizeH),
0==this.mapAngel?(this.realityHalfW=n/2,this.realityHalfH=l/2):(this.realityHalfW=E.GF.INT(n*t.FIX_ANGLE+l*t.FIX_ANGLE),this.realityHalfH=this.realityHalfW),
this.isradar)this.m_showHalfW=60,this.m_showHalfH=56
else{0!=this.dragIndex&&(p.L.Inst.UnregDrag(this.dragIndex),this.dragIndex=0)
let t=this.mapCfg
0!=t.relatedMapId&&(t=ht.p.Inst_get().GetMapById(t.relatedMapId)),this.RegDrag()}this.SetFocusRole(!0)
null!=I.Y.Inst.PrimaryRole_get()&&(this.isradar||this.PlayerRoadsUpdateHandler(I.Y.Inst.tempRoad))}DragCallBack(t,e){this.SetFocusRole(!1)}UpdateText(){this.HideText()
this.textItems.Count()}HideText(){let t=0
for(;t<this.textItems.Count();)null!=this.textItems[t]&&null!=this.textItems[t].node&&this.textItems[t].node.transform.SetLocalPosition(this.pointHidePos),t+=1}ClearText(){let t=0
for(;t<this.textItems.Count();)null!=this.textItems[t]&&null!=this.textItems[t].node&&M.g.DestroyUIObj(this.textItems[t]),t+=1
this.textItems.Clear()}GetTextUrl(){let t=""
return t="ui_topsmallmap_textitem","ui_topsmallmap_textitem"}GetTextPrefab(){const t=this.GetTextUrl(),e=o.o.getPrefab(t)
return(0,l.instantiate)(e).getCNode(At.Z)}UpdateRelive(){this.HideRelive()
this.reliveItems.Count()}HideRelive(){let t=0
for(;t<this.reliveItems.Count();)null!=this.reliveItems[t]&&null!=this.reliveItems[t].node&&this.reliveItems[t].node.transform.SetLocalPosition(this.pointHidePos),t+=1}
ClearRelive(){let t=0
for(;t<this.reliveItems.Count();)null!=this.reliveItems[t]&&null!=this.reliveItems[t].node&&M.g.DestroyUIObj(this.reliveItems[t]),t+=1
this.reliveItems.Clear()}GetReliveUrl(){let t=""
return t="ui_topsmallmap_relivepointitem","ui_topsmallmap_relivepointitem"}GetRelivePrefab(){const t=this.GetReliveUrl(),e=o.o.getPrefab(t),s=(0,l.instantiate)(e).getCNode(ft.D)
return s.UpdateShow(),s}UpdateTransfer(){let t=0,e=null
X.p.inst.IsInCopy()?e=ht.p.Inst_get().GetAllTransportInCopy(Q.a.Inst_get().currentCopyId):(t=this.GetMapId(),e=ht.p.Inst_get().GetAllTransportInMap(t))
const s=this.transferItems.Count()
let i=0,n=0
for(;n<e.Count();){let t=null
i<s?t=this.transferItems[i]:(t=this.GetTransferPrefab(),this.transferItems.Add(t)),
this.Adapt2RadarMapViewXYZ(e[n].belongPosX,0,e[n].belongPosY,t.node.transform,this.m_TransferTransform,i>=s),t.isradar=this.isradar,t.Cfg_set(e[n]),i+=1,n+=1}}ReqTeamMembers(){}
HideTransfer(){let t=0
for(;t<this.transferItems.Count();)null!=this.transferItems[t]&&null!=this.transferItems[t].node&&this.transferItems[t].node.transform.SetLocalPosition(this.pointHidePos),t+=1}
ClearTransfer(){let t=0
for(;t<this.transferItems.Count();)null!=this.transferItems[t]&&null!=this.transferItems[t].node&&M.g.DestroyUIObj(this.transferItems[t]),t+=1
this.transferItems.Clear()}GetTransferUrl(){let t=""
return t=this.isradar?"ui_topsmallmap_radartransferitem":"ui_topsmallmap_transferitem",t}GetTransferPrefab(){const t=this.GetTransferUrl(),e=o.o.getPrefab(t),s=(0,
l.instantiate)(e).getCNode(vt.r)
return s.UpdateShow(),s}UpdateTeamMembers(t){this.HideTeamMembers()
let e=null
const s=this.teamItems.Count()
let i=0,n=0
n=this.GetMapId()
let l=0
for(;l<t.memberPositions.Count();){if(e=t.memberPositions[l].objId,!e.Equal(I.Y.Inst.PlayerId_get())){let e=null
i<s?e=this.teamItems[i]:(e=this.GetTeamPrefab(),this.teamItems.Add(e)),this.Adapt2RadarMapViewXYZ(t.memberPositions[l].x,0,t.memberPositions[l].y,e.node.transform,this.m_selfTransform,i>=s,5),
e.isradar=this.isradar,e.TeamMemberId_set(t.memberPositions[l].objId),i+=1}l+=1}}ClearTeamMembers(){this.GetTeamUrl()
let t=0
for(;t<this.teamItems.Count();)null!=this.teamItems[t]&&null!=this.teamItems[t].node&&M.g.DestroyUIObj(this.teamItems[t]),t+=1
this.teamItems.Clear()}HideTeamMembers(){let t=0
for(;t<this.teamItems.Count();)null!=this.teamItems[t]&&null!=this.teamItems[t].node&&this.teamItems[t].node.transform.SetLocalPosition(this.pointHidePos),t+=1}GetTeamPrefab(){
const t=this.GetTeamUrl(),e=o.o.getPrefab(t),s=(0,l.instantiate)(e).getCNode(yt.c)
return s.UpdateShow(),s}GetTeamUrl(){let t=""
return t=(this.isradar,"ui_topsmallmap_teamitem"),t}UpdateBoss(){this.HideBoss()
let t=0
t=this.GetMapId()
let e=null
const s=Q.a.Inst_get().currentCopyId
if(s>0)this.curCopy=s,e=dt.C.Inst().GetBossesByCopy(s)
else if(e=dt.C.Inst().GetBossesByMap(t),e.Count()<=0){const s=et.h.GetInst().GetBossMapId(t)
e=dt.C.Inst().GetBossesByMap(s)}const i=this.bossItems.Count()
let n=0,l=0
for(;l<e.Count();){let t=null
n<i?t=this.bossItems[n]:(t=this.GetBossPrefab(),this.bossItems.Add(t)),this.Adapt2RadarMapViewXYZ(e[l].x_get(),0,e[l].y_get(),t.node.transform,this.m_bossTransform,n>=i),
t.isradar=this.isradar,t.Cfg_set(e[l],this.isradar),n+=1,l+=1}}HideBoss(){let t=0
for(;t<this.bossItems.Count();){if(null!=this.bossItems[t]&&null!=this.bossItems[t].node){this.bossItems[t].node.transform.SetLocalPosition(this.pointHidePos)}t+=1}}ClearBoss(){
this.GetBossUrl()
let t=0
for(;t<this.bossItems.Count();)null!=this.bossItems[t]&&null!=this.bossItems[t].node&&M.g.DestroyUIObj(this.bossItems[t]),t+=1
this.bossItems.Clear()}GetBossUrl(){let t=""
return t=this.isradar?"ui_topsmallmap_radarbossitem":"ui_topsmallmap_bossitem",t}GetBossPrefab(){const t=this.GetBossUrl(),e=o.o.getPrefab(t),s=(0,l.instantiate)(e).getCNode(mt.p)
return s.UpdateShow(),s}GetGoldMonsterUrl(){let t=""
return t=this.isradar?"ui_topsmallmap_radargoldmonsteritem":"ui_topsmallmap_goldmonsteritem",t}GetGoldMonsterPrefab(){const t=this.GetGoldMonsterUrl(),e=o.o.getPrefab(t),s=(0,
l.instantiate)(e).getCNode(St.r)
return s.UpdateShow(),s}UpdateTask(){this.HideTask()
let t=0
t=this.GetMapId()
const e=gt.F.getInst().GetMapTask(t)
let s=null
const i=this.taskItems.Count()
let n=0,l=0
for(;l<e.Count();){s=e[l]
let[t,o]=[0,0]
if(s.status_get()==at.B.CAN_ACCEPT?(t=s.AcceptNpcX_get(),o=s.AcceptNpcY_get()):s.resource_get().intersectionType==rt.U.INTERSECTION_NPC&&(t=s.RewardNpcX_get(),
o=s.RewardNpcY_get()),0!=t||0!=o){let e=null
n<i?e=this.taskItems[n]:(e=this.GetTaskPrefab(),this.taskItems.Add(e)),this.Adapt2RadarMapViewXYZ(t,0,o,e.node.transform,this.m_taskTransform,n>=i),e.isradar=this.isradar,
e.Cfg_set(s),n+=1}l+=1}N.Z.Recyle(e)}HideTask(){let t=0
for(;t<this.taskItems.Count();)null!=this.taskItems[t]&&null!=this.taskItems[t].node&&this.taskItems[t].node.transform.SetLocalPosition(this.pointHidePos),t+=1}ClearTask(){
this.GetTaskUrl()
let t=0
for(;t<this.taskItems.Count();)null!=this.taskItems[t]&&null!=this.taskItems[t].node&&M.g.DestroyUIObj(this.taskItems[t]),t+=1
this.taskItems.Clear()}GetTaskUrl(){let t=""
return t=(this.isradar,"ui_topsmallmap_radartaskitem"),t}GetTaskPrefab(){const t=this.GetTaskUrl(),e=o.o.getPrefab(t),s=(0,l.instantiate)(e).getCNode(Tt.e)
return s.UpdateShow(),s}ClearFreshInterva(){0!=this.m_freshkey&&(A.C.Inst_get().ClearInterval(this.m_freshkey),this.m_freshkey=0)}AddEvents(){this.ClearFreshInterva(),
this.m_freshkey=A.C.Inst_get().SetInterval(this._degf_RefreshRoleMap,30),w.i.Get(this.dragmap).RegistonClick(this._degf_ClickHandler),
this.m_handlerMgr.AddEventMgr(u.A.PlayerRoadJoystickUpdate,this._degf_PlayerRoadsJoystickUpdateHandler),
this.m_handlerMgr.AddEventMgr(u.A.PlayerRoadUpdate,this._degf_PlayerRoadsUpdateHandler),
gt.F.getInst().AddEventHandler(ut.f.TeamMemberPosition,this._degf_TeamMemberPositionHandler),
gt.F.getInst().AddEventHandler(ut.f.CurrentMapItemClick,this.CreateDelegate(this.CurrentMapItemClickHandler)),
gt.F.getInst().AddEventHandler(ut.f.MapTaskChange,this._degf_TaskChangeHandler),this.m_handlerMgr.AddEventMgr(q.g.SIEGE_STATUESTATE_UPDATE,this._degf_UpdateSiegeBuildInfoHandler),
W.b.Inst_get().AddEventHandler(W.b.STATUS_UDPATE,this.CreateDelegate(this.AsuramStatusUpdateHandler)),
this.isradar||(this.m_handlerMgr.AddEventMgr(q.g.SMALL_MAP_CLICK_MONSTER,this.CreateDelegate(this.OnClickMonsterIcon)),
this.m_handlerMgr.AddEventMgr(q.g.SMALL_MAP_MOVE_TO_MONSTER,this.CreateDelegate(this.OnMoveToMonster)),
this.m_handlerMgr.AddEventMgr(q.g.SMALL_MAP_TREE_CLICK_MONSTER,this.CreateDelegate(this.OnClickMapTree)),
this.m_handlerMgr.AddEventMgr(q.g.DYNAMIC_REGIST_CONTROLID,this.CreateDelegate(this.DynamicRegistControllerIdHandler))),
nt.u.Inst().AddEventHandler(it.Z.UpdateMapPassInfo,this.CreateDelegate(this.UpdateGateListInfo)),
I.Y.Inst.PrimaryRoleInfo_get().AddEventHandlerRoleGlobal(u.A.LevelUpdate,this.CreateDelegate(this.UpdateGateListInfo))}UpdateSiegeBuildInfoHandler(t){
this.isradar?this.UpdateSiegeBuildInfo():this.isOneLoad&&this.isSiegeBulidUpdate&&(this.isOneLoad=!1,this.UpdateSiegeBuildInfo())}DynamicRegistControllerIdHandler(t){
this.serverMonsterDic.LuaDic_ContainsKey(t[1])&&st.c.Inst.RegGameObject(t[0],this.serverMonsterDic[t[1]].node)}UnRegGuide(){st.c.Inst.UnRegGameObject(B.D.UI_ASURAMWAR_MAPGUIDE),
st.c.Inst.UnRegGameObject(B.D.UI_ASURAMWAR_MAPGUIDE_2)}AsuramStatusUpdateHandler(){0!=this.textureSizeX&&0!=this.m_halfW&&this.UpdateAsuramObjes()}UpdateSiegeBuildInfo(){
this.HideSiegeBuild()
this.siegeBuildItems.Count()}HideSiegeBuild(){let t=0
for(;t<this.siegeBuildItems.Count();)null!=this.siegeBuildItems[t]&&null!=this.siegeBuildItems[t].node&&this.siegeBuildItems[t].node.transform.SetLocalPosition(this.pointHidePos),
t+=1}ClearSiegeBuild(){let t=0
for(;t<this.siegeBuildItems.Count();)null!=this.siegeBuildItems[t]&&null!=this.siegeBuildItems[t].node&&M.g.DestroyUIObj(this.siegeBuildItems[t]),t+=1
this.siegeBuildItems.Clear()}GetSiegeBuildUrl(){let t=""
return t="ui_topsmallmap_siegebuilditem","ui_topsmallmap_siegebuilditem"}GetSiegeBuildPrefab(){const t=this.GetSiegeBuildUrl(),e=o.o.getPrefab(t),s=(0,
l.instantiate)(e).getCNode(Ct.l)
return s.UpdateShow(),s}ClickHandler(t,e){if(this.GetMapId()!=T.b.Inst.currentMapId_get())return
const s=I.Y.Inst.PrimaryRole_get()
null!=s.AISingleton_get()&&s.AISingleton_get().getSingletonType()==r.R.hang&&(_._.getInst().isclickmap=!0),this.GoPath(),gt.F.getInst().RaiseEvent(ut.f.CloseMonsterTip)}
CurrentMapItemClickHandler(t){this.isradar||null==t?this.GoPath():this.OpenMonsterArea(t)}RadarItemClickHandler(t){It.X.inst.OpenMapPanel()}GoPath(){
const t=F.P.zero_get(),e=H.T.GetMousePosition(),s=f.x.Instance_get().ScreenToWorldPointXYZ(e.x,e.y,e.z),i=H.T.WorldToLocalMatrixMultiplyPoint3x4(this.node,s)
t.x=(i.x/this.m_halfW+1)/2*(this.textureSizeX/this.sizeScale),t.z=(i.y/this.m_halfH+1)/2*(this.textureSizeY/this.sizeScale),
t.y=S.c.Instance_get().GetHeight(E.GF.INT(G.a.eTrueWorld),t.x,t.z),this.GotoTargetPos(t)}GoPathByTransPos(t,e){const s=F.P.zero_get()
s.x=t.x,s.z=t.y,s.y=S.c.Instance_get().GetHeight(E.GF.INT(G.a.eTrueWorld),s.x,s.z),this.GotoTargetPos(s,e),F.P.Recyle(s)}GotoTargetPos(t,e){
It.X.inst.GotoTargetPos(t,e,this._degf_OnArriveToTargetPos)}OnArriveToTargetPos(t){I.Y.isMapFindWay=!1,
null!=t&&t.count>2&&t[0]&&Z.l.CalFastCharToXZDisFast(I.Y.Inst.PrimaryRole_get(),t[1],t[2])<2&&_._.getInst().startHang()}IsInMiracleSpawnGroups(t){for(const[e,s]of(0,
h.V5)(this.miracleItems))if(s.node.activeSelf()){const e=s.SpawnCfg_get()
new x.F(t.x-e.x,t.z-e.y)}return null}TeamMemberPositionHandler(t){}RemoveEvents(){this.ClearFreshInterva(),w.i.Get(this.dragmap).RemoveonClick(this._degf_ClickHandler),
gt.F.getInst().RemoveEventHandler(ut.f.TeamMemberPosition,this._degf_TeamMemberPositionHandler),
gt.F.getInst().RemoveEventHandler(ut.f.CurrentMapItemClick,this.CreateDelegate(this.CurrentMapItemClickHandler)),
gt.F.getInst().RemoveEventHandler(ut.f.MapTaskChange,this._degf_TaskChangeHandler),
W.b.Inst_get().RemoveEventHandler(W.b.STATUS_UDPATE,this.CreateDelegate(this.AsuramStatusUpdateHandler)),
I.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandlerRoleGlobal(u.A.LevelUpdate,this.CreateDelegate(this.UpdateGateListInfo)),
nt.u.Inst().RemoveEventHandler(it.Z.UpdateMapPassInfo,this.CreateDelegate(this.UpdateGateListInfo))}TaskChangeHandler(t){this.UpdateTask()}RefreshRoleMap(){
null!=I.Y.Inst&&null!=I.Y.Inst.PrimaryRole_get()&&(this.UpdateSelfPos(),this.isradar&&(this.UpdateMapPos(),X.p.inst.IsInCopy()||this.UpdateGateShow()),
0!=this.pointArr.Count()&&this.updatePath())}Adapt2RadarMapViewXYZ(t,e,s,i,n,l,o,a){let r,h
return null==o&&(o=0),null==l&&(l=!0),r=E.GF.INT((2*t/(this.textureSizeX/this.sizeScale)-1)*this.m_halfW),h=E.GF.INT((2*s/(this.textureSizeY/this.sizeScale)-1)*this.m_halfH),
null!=i&&(l&&i.node.setParent(n.node),a||i.SetLocalPositionXYZ(r,h,0)),new F.P(r,h,0)}UpdateSelfPos(){if(null==I.Y.Inst.PrimaryRole_get())return
const[t,e,s]=I.Y.Inst.PrimaryRole_get().GetPosXYZ(),i=this.Adapt2RadarMapViewXYZ(t,e,s,this.m_selfComponent,this.m_selfTransform,!1)
this.m_SelfPos.Set(i.x,i.y,i.z),this.UpdateSelfDirection()}UpdateSelfDirection(){I.Y.Inst.PrimaryRole_get().GetDirection()}UpdateMapPos(){if(this.isradar){
const t=this.GetMapPosByRolePos()
this.node.transform.SetLocalPositionXYZ(t.x,t.y,t.z)}else if(this.node.transform.SetLocalPositionXYZ(0,0,0),this.curMapId!=T.b.Inst.currentMapId_get()){
const t=this.GetPosByHeightGate()
this.dragTarget.transform.SetLocalPositionXYZ(t.x,t.y,t.z)}else{const t=this.GetMapPosByRolePos()
this.dragTarget.transform.SetLocalPositionXYZ(t.x,t.y,t.z)}}UpdateGateShow(){let t=-1,e=0
const[s,i,n]=I.Y.Inst.PrimaryRole_get().GetPosXYZ()
for(const[i,l]of(0,h.V5)(this.multipleHangPointInfoShowPool)){const o=i,a=K.e.Inst_get().GetCfgById(o),r=a.targetX,h=a.targetY
if(null==l.pos){const t=this.Adapt2RadarMapViewXYZ(r,0,h,l.node.transform,this.m_bossTransform,!1,0,!0)
l.pos=new F.P(t.x,t.y)}const d=Z.l.FastDistanceXZ(s,n,r,h);(-1==t||d<t)&&(t=d,e=a.spawnId)}if(0!=e){const t=nt.u.Inst().GetResBySpawnId(e),[s,i,n]=nt.u.Inst().GetCloseVos(t.id)
for(const[t,e]of(0,h.vy)(this.multipleHangPointInfoShowPool)){const t=e
t.id!=s&&t.id!=i&&t.id!=n?null!=t.node&&t.node.transform.SetLocalPosition(this.pointHidePos):null!=t.pos?t.node.transform.SetLocalPositionXYZ(t.pos.x,t.pos.y,0):v.Y.LogError("不应该啊monsteritem.pos~=nil")
}}}GetMapPosByRolePos(){let[e,s,i]=[0,0,0]
if(this.realityHalfW<this.m_showHalfW&&this.realityHalfH<this.m_showHalfH)return new F.P(0,0,0)
let n=this.mapCfg
if(0!=n.relatedMapId&&(n=ht.p.Inst_get().GetMapById(n.relatedMapId)),!this.isradar&&!Z.l.IsEmptyStr(n.fixPosition)){const t=k.M.Split(n.fixPosition,k.M.s_SPAN_CHAR_DOT)
e=k.M.String2Float(t[0]),s=k.M.String2Float(t[1]),new F.P(e,s,i)}0==this.mapAngel?(e=Math.floor(this.m_SelfPos.x),
s=Math.floor(this.m_SelfPos.y)):(e=Math.floor(t.FIX_ANGLE*this.m_SelfPos.x-t.FIX_ANGLE*this.m_SelfPos.y),s=Math.floor(t.FIX_ANGLE*this.m_SelfPos.x+t.FIX_ANGLE*this.m_SelfPos.y))
const[l,o,a,r]=this.GetDragBoundXYZ()
let[h,d,c]=[0,0,0]
return this.isradar&&(h=20,d=-5),e=h-e,s=d-s,i=c-i,e>a&&(e=a),e<l&&(e=l),s>r&&(s=r),s<o&&(s=o),new F.P(e,s,i)}GetPosByHeightGate(){let[e,s,i]=[0,0,0]
this.realityHalfW<this.m_showHalfW&&this.realityHalfH<this.m_showHalfH&&new F.P(0,0,0)
let n=this.mapCfg
const l=nt.u.Inst().GetHighestGateByMap(n.id)
null==l&&new F.P(0,0,0),0!=n.relatedMapId&&(n=ht.p.Inst_get().GetMapById(n.relatedMapId))
const o=nt.u.Inst().GetTransVoById(l.id)
null==o&&new F.P(0,0,0)
const a=this.Adapt2RadarMapViewXYZ(o.targetX,0,o.targetY,null,this.m_bossTransform,!1,0,!0)
0==this.mapAngel?(e=Math.floor(a.x),s=Math.floor(a.y)):(e=Math.floor(t.FIX_ANGLE*a.x-t.FIX_ANGLE*a.y),s=Math.floor(t.FIX_ANGLE*a.x+t.FIX_ANGLE*a.y))
const[r,h,d,c]=this.GetDragBoundXYZ(),[I,u,p]=[0,0,0]
return e=I-e,s=u-s,i=p-i,e>d&&(e=d),e<r&&(e=r),s>c&&(s=c),s<h&&(s=h),new F.P(e,s,i)}_drawPath(t){this.SetFocusRole(!0),this.lastseg=-1,this._delAllPathPoint(),
this.pathArrx.Clear(),this.pathArrz.Clear(),this.pointArr.Clear()
const e=t.Count(),[s,i]=I.Y.Inst.PrimaryRole_get().GetPosXZ()
this.pathArrx.Add(s),this.pathArrz.Add(i)
let n=!1,l=0
for(;l<e;)this.pathArrx.Add(t[l].x),this.pathArrz.Add(t[l].z),l==e-1&&(n=!0,this.pathEndPos.Set(t[l].x,0,t[l].z)),
0==l?this._drawPathByBeginEnd(s,i,t[l].x,t[l].z,0,n):this._drawPathByBeginEnd(t[l-1].x,t[l-1].z,t[l].x,t[l].z,l,n),l+=1
this.pathtransform.SetActive(!1)}PlayerRoadsUpdateHandler(t){if(this.curMapId!=T.b.Inst.currentMapId_get())return void this._delAllPathPoint()
let e=null
null!=t&&(e=t),null!=e&&e.Count()>0?this._drawPath(e):this._delAllPathPoint()}PlayerRoadsJoystickUpdateHandler(t){this._delAllPathPoint()}_delAllPathPoint(){for(const[t,e]of(0,
h.vy)(this.pointDic))this.ClearPoints(this.pointDic[t],t)
this.pointDic.LuaDic_Clear()}ActiveAllPathPoint(){for(const[t,e]of(0,h.vy)(this.pointDic)){let e=0
for(;e<this.pointDic[t].Count();){!0||this.pointDic[t][e].go.transform.SetLocalPosition(this.pointHidePos),e+=1}}}_drawPathByBeginEnd(e,s,i,n,l,o){
this.pointDic.LuaDic_ContainsKey(l)||this.pointDic.LuaDic_AddOrSetItem(l,new N.Z)
const a=this.pointDic[l]
let r=Math.abs(e-i),h=Math.abs(s-n),d=L.p.CeilToInt(h/t.PATH_POINT_DIS)
r>h&&(d=L.p.CeilToInt(r/t.PATH_POINT_DIS)),r/=d,h/=d
let c=0,I=0,u=0,p=-1
e<i&&(p=1)
let _=-1
s<n&&(_=1)
let g=0,m=0,S=!1,f=null
for(;c<=d;)g=E.GF.INT(c*r),m=E.GF.INT(c*h),I=Math.abs(i-e)>=g?e+g*p:i,u=Math.abs(n-s)>=m?s+m*_:n,I==i&&u==n&&(S=!0),
f=c==d&&o&&S?this._drawPathPoint(I,u,!0):this._drawPathPoint(I,u,!1),a.Add(f),c+=1
S||(f=o?this._drawPathPoint(i,n,!0):this._drawPathPoint(i,n,!1),a.Add(f))}updatePath(){this.pathtransform.SetActive(!0)
let t=0
const[e,s]=I.Y.Inst.PrimaryRole_get().GetPosXZ()
let i=0
const n=this.pathArrx.Count()-1
if(this.pathArrx[n]==e&&s==this.pathArrz[n])i=n-1
else{let l=!1
for(t=Math.max(0,this.lastseg);t<n;){if(l=this.FindSeg(this.pathArrx[t],this.pathArrz[t],this.pathArrx[t+1],this.pathArrz[t+1],e,s),l){i=t,
l=this.FindSeg(this.pathArrx[t],this.pathArrz[t],this.pathArrx[t+1],this.pathArrz[t+1],e,s),this.lastseg=i
break}t+=1}}const l=Math.abs(e-this.pathArrx[i]),o=Math.abs(s-this.pathArrz[i])
this.ActiveAllPathPoint()
for(const[t,e]of(0,h.vy)(this.pointDic))if(t<i)this.ClearPoints(this.pointDic[t],t)
else if(t==i){let e=0,s=0
const i=this.pointDic[t],n=this.tmpPathList
n.Clear()
for(const[a,r]of(0,h.V5)(i)){e=Math.abs(r.x-this.pathArrx[t]),s=Math.abs(r.y-this.pathArrz[t])
e*e+s*s<=l*l+o*o&&n.Add(r)}for(const[t,e]of(0,h.V5)(n))i.Remove(e)
this.ClearPoints(n,-1)}}FindSeg(t,e,s,i,n,l){const o=Math.min(t,s),a=Math.max(t,s),r=Math.min(e,i),h=Math.max(e,i)
if(t==s){if(n==t&&l>=r&&l<=h)return!0}else if(e==i){if(l==i&&n>=o&&n<=a)return!0}else{if(n<o||n>a||l<r||l>h)return!1
const d=(i-e)/(s-t)*(n-t)+e
if(Math.abs(d-l)<1e-4)return!0}return!1}ClearPoints(t,e){0==e&&v.Y.Log(`key${e}`,D.C.LOG_GX)
let s=0
for(;s<t.Count();)t[s].go.transform.SetLocalPosition(this.pointHidePos),"ui_topsmallmap_point"==t[s].clazz?this.pointPool.Add(t[s].go):this.endPoint=t[s].go,s+=1
t.Clear()}isBetweenTwoNum(t,e,s){return e>s?t>=s&&t<=e:t>=e&&t<=s}OpenMonsterArea(t){this.IsScaling=!0
const e=this.GetCurSmallMapVo().GetMonsterIdByTransId(t.id)
c.a.getInst().getObjById(e)
this.transcfg=t
let s=this.monsterInfoShowDict.LuaDic_GetItem(t.id)
s=s||this.multipleHangPointInfoShowPool.LuaDic_GetItem(t.id),this.monsterItem=s,this.OpenMonsterTip()}SetRectPosByTransId(t,e,s){
const i=this.GetCurSmallMapVo().GetSameGroupTransIds(t)
if(null!=i)for(let t=0;t<=i.Count()-1;t++){const n=this.transShowDict.LuaDic_GetItem(i[t]).node.transform.GetLocalPosition().Clone(),l=this.Tex2Map(n)
l.x<e.x&&(e.x=l.x),l.x>s.x&&(s.x=l.x),l.y<e.y&&(e.y=l.y),l.y>s.y&&(s.y=l.y)}}ScaleToRect(t){this.scaleValue=t
const e=this.node.transform.GetLocalPosition()
this.tween_scale.SetFrom(e),this.tween_scale.SetToXYZ(this.scaleValue,this.scaleValue,1),this.tween_scale.enabled=!0,this.tween_scale.ResetToBeginning(),
this.tween_scale.PlayForward()}MoveToRect(t,e){this.SetFocusRole(!1)
const s=t.x,i=t.y,n=this.node.transform.GetLocalPosition()
this.tween_position.SetFrom(n),this.tween_position.AddEventHandler(this.CreateDelegate(this.OnScaleEnd)),this.tween_position.SetToXYZ(-(s-n.x)*e,-(i-n.y)*e,0),
this.tween_position.enabled=!0,this.tween_position.ResetToBeginning(),this.tween_position.PlayForward()}SetFocusRole(t){this.IsFocusRole=t}RegDrag(){this.UnRegDrag(),
Z.l.IsEmptyStr(this.mapCfg.fixPosition)}UnRegDrag(){0!=this.dragIndex&&(p.L.Inst.UnregDrag(this.dragIndex),this.dragIndex=0)}ScaleToOrign(){this.scaleValue=1
const t=this.node.transform.GetLocalPosition()
this.tween_scale.SetFrom(t),this.tween_scale.SetToXYZ(1,1,1),this.tween_scale.SetEnabled(!0),this.tween_scale.ResetToBeginning(),this.tween_scale.PlayForward()
const e=this.node.transform.GetLocalPosition()
this.tween_position.SetFrom(e)
const s=this.GetMapPosByRolePos(),i=this.dragTarget.transform.GetLocalPosition(),n=s.x-i.x,l=s.y-i.y
this.tween_position.AddEventHandler(this.CreateDelegate(this.OnScaleOrignEnd)),this.tween_position.SetToXYZ(n,l,0),this.tween_position.SetEnabled(!0),
this.tween_position.ResetToBeginning(),this.tween_position.PlayForward()}OnScaleEnd(){}OpenMonsterTip(){let t=this.monsterItem.node.transform.GetLocalPosition().clone()
t=this.Monster2Map(t)
const e=245,s=new F.P(t.x+40+150,t.y+50,0)
s.x+150>this.m_showHalfW&&(s.x=t.x-100-150),s.y+e>this.m_showHalfH&&(s.y=this.m_showHalfH-e),s.y-e<-this.m_showHalfH&&(s.y=-this.m_showHalfH+e+20),
It.X.inst.OpenMonsterTip(this.transcfg,s)}OnScaleOrignEnd(){this.tween_position.RemoveEventHandler(this.CreateDelegate(this.OnScaleOrignEnd))
const t=F.P.zero_get()
this.m_taskTransform.SetLocalPosition(t),this.m_goldmonsterTransform.SetLocalPosition(t),this.m_TransferTransform.SetLocalPosition(t),F.P.Recyle(t),this.RegDrag(),
this.monstertransform.SetActive(!1),this.IsScaling=!1}CloseMonsterArea(){}SetActiveTransform(t){for(const[e,s]of(0,
h.vy)(this.transformes))t==s?s.SetLocalPosition(F.P.zero_get()):s.SetLocalPosition(J.I.HIDE_POS)}ShowTransInfos(){
const t=this.GetMapId(),e=tt.j.GetInst().GetCfgById(t).GetMonsterCoord()
if(null==e||0==e.count)return
let s=0
for(;s<e.count;){const t=e[s]
if(null!=t&&t.count>1){const e=c.a.getInst().getObjById(t[0]),s=K.e.Inst_get().GetCfgById(t[1])
if(null!=e&&null!=s){
const e=this.transShowDict.LuaDic_GetItem(s.id).node.transform.GetLocalPosition().Clone(),i=this.node.transform.GetLocalPosition(e),n=this.monstertransform.transform.GetLocalPosition(i),l=this.IsInMapPanel(this.dragmap.transform.GetLocalPosition(i))
let o=this.monsterInfoShowDict.LuaDic_GetItem(s.id)
null!=o&&(o=this.multipleHangPointInfoShowPool.LuaDic_GetItem(s.id)),l?(null==o&&(o=this.GetMonsterInfoItem(s,n),this.monsterInfoShowDict.LuaDic_AddOrSetItem(s.id,o)),
o.node.transform.SetLocalPosition(n)):(o=this.monsterInfoShowDict.LuaDic_GetItem(t[1]),null!=o&&(o=this.multipleHangPointInfoShowPool.LuaDic_GetItem(t[1])),
null!=o&&o.node.transform.SetLocalPosition(J.I.HIDE_POS))}}s+=1}}OnMoveToMonster(t){this.GoPathByTransPos(t,!0)}OnClickMapTree(t){if(null==t||0==t)this.CloseMonsterArea()
else{this.m_taskTransform.SetLocalPosition(J.I.HIDE_POS),this.m_goldmonsterTransform.SetLocalPosition(J.I.HIDE_POS),this.m_TransferTransform.SetLocalPosition(J.I.HIDE_POS)
const e=this.GetCurSmallMapVo(),s=gt.F.getInst().GetRecommendTransIdByMonsterId(e,t),i=K.e.Inst_get().GetCfgById(s)
if(null!=this.transcfg&&this.transcfg.id==i.id)return
this.OpenMonsterArea(i)}}OnClickMonsterIcon(t){this.OpenMonsterArea(t)}GetMonsterInfoItem(t,e){const s=o.o.getPrefab("ui_topsmallmap_monsterinfo"),i=(0,
l.instantiate)(s).getCNode(Mt.m)
return i.node.setParent(this.m_bossTransform.node),i.SetData(t),i.HideNameandClick(this.isradar),i}GetGateInfoItem(t){const e=o.o.getPrefab("ui_topsmallmap_gate_info_ry"),s=(0,
l.instantiate)(e).getCNode(Bt.q)
return s.node.setParent(this.m_bossTransform.node),s.SetData(t,this.isradar),s}GetGatePointItem(t,e){const s=o.o.getPrefab("ui_topsmallmap_gate_conetpoint"),i=(0,
l.instantiate)(s).getCNode(Dt.X)
return i.node.setParent(this.m_bossTransform.node),i.SetData(t,e),i}IsInMapPanel(t){
return!this.IsScaling&&(!(t.x<-this.m_showHalfW-100)&&(!(t.x>this.m_showHalfW+100)&&(!(t.y<-this.m_showHalfH-100)&&!(t.y>this.m_showHalfH+100))))}TargetCoor2Map(t){
return t.x=(2*t.x/(this.textureSizeX/this.sizeScale)-1)*this.m_halfW,t.y=(2*t.y/(this.textureSizeY/this.sizeScale)-1)*this.m_halfH,t.x=E.GF.INT(t.x),t.y=E.GF.INT(t.y),t}Tex2Map(t){
return t=this.node.transform.GetLocalPosition(t),t=this.dragmap.transform.GetLocalPosition(t)}Monster2Map(t){return t=this.m_bossTransform.GetLocalPosition(t),
t=R.O.WorldPosToLayoutLocalPosQuick(t,b.F.MainUI)}GetDragBound(){const t=U.L.zero_get(),[e,s,i,n]=this.GetDragBoundXYZ()
return t.Set(e,s,i,n),t}GetDragBoundXYZ(){let[t,e,s,i]=[0,0,0,0]
return t=-(this.realityHalfW+this.backgroundoffsetX-this.m_showHalfW),e=-(this.realityHalfH+this.backgroundoffsetY-this.m_showHalfH),
s=this.realityHalfW-this.backgroundoffsetX-this.m_showHalfW,i=this.realityHalfH-this.backgroundoffsetY-this.m_showHalfH,t>=s&&(t=E.GF.INT32_MAX_VALUE_get(),
s=E.GF.INT32_MAX_VALUE_get()),e>i&&(e=E.GF.INT32_MAX_VALUE_get(),i=E.GF.INT32_MAX_VALUE_get()),this.realityHalfW<=this.m_showHalfW&&(t=0,s=0),
this.realityHalfH<=this.m_showHalfH&&(e=0,i=0),[t,e,s,i]}_drawPathPoint(t,e,s){let i=null,n=!1,a=""
a=s?this.isradar?"ui_topsmallmap_radarendpoint":"ui_topsmallmap_endpoint":"ui_topsmallmap_point"
if(s)if(null!=this.endPoint)i=this.endPoint
else{const t=o.o.getPrefab(a)
i=(0,l.instantiate)(t),i.transform.SetLocalPosition(this.pointHidePos),n=!0}else if(this.pointPool.Count()>0)i=P.B.PopFront(this.pointPool)
else{const t=o.o.getPrefab(a)
i=(0,l.instantiate)(t),i.transform.SetLocalPosition(this.pointHidePos),n=!0}if(null!=i){const s=new x.F
let l,o
s.x=t,s.y=e,this.pointArr.Add(s),l=(2*t/(this.textureSizeX/this.sizeScale)-1)*this.m_halfW,o=(2*e/(this.textureSizeY/this.sizeScale)-1)*this.m_halfH,
n&&i.setParent(this.pathtransform),i.transform.SetLocalPositionXYZ(l,o,0),this.isradar?J.I.calVec5.Set(1,1,1):J.I.calVec5.Set(this.uimapscale,this.uimapscale,1),
i.setScale(J.I.calVec5)}const r=new _t.P
return r.x=t,r.y=e,r.go=i,r.clazz=a,r}ResetServerIcon(){for(const[t,e]of(0,h.V5)(this.serverMonsterDic))null!=e&&(e.Clear(),M.g.DestroyUIObj(e))
this.serverMonsterDic.LuaDic_Clear()
for(const[t,e]of(0,h.vy)(this.mapIcons))null!=e&&(e.Clear(),M.g.DestroyUIObj(e))
this.mapIcons.Clear()
for(const[t,e]of(0,h.V5)(this.awBuffIconDic))null!=e&&(e.Clear(),M.g.DestroyUIObj(e))
this.awBuffIconDic.Clear()
for(const[t,e]of(0,h.V5)(this.awBuffIcons))null!=e&&(e.Clear(),M.g.DestroyUIObj(e))
this.awBuffIcons.Clear()}Clear(){if(this.type=null,this.isTextureLoaded=!1,this.isNeedUpdatePoint="",this.UnRegGuide(),this.ResetItems(),this.ClearFreshInterva(),
this.OnRemoveFromScene(),null!=this.clearMultipleHangPointList&&(this.clearMultipleHangPointList.Clear(),this.clearMultipleHangPointList=null),!this.isradar){
this.IsShowDefaultRecommend=!1
for(const[t,e]of(0,h.V5)(this.monsterInfoShowDict))null!=e&&(e.Clear(),M.g.DestroyUIObj(e))
this.monsterInfoShowDict.LuaDic_Clear()
for(const[t,e]of(0,h.vy)(this.serverMonsterDic))null!=e&&(e.Clear(),M.g.DestroyUIObj(e))
for(const[t,e]of(0,h.V5)(this.multipleHangPointInfoShowPool))null!=e&&(e.Clear(),M.g.DestroyUIObj(e))
this.multipleHangPointInfoShowPool.LuaDic_Clear()
for(const[t,e]of(0,h.V5)(this.smallMapGateConnetPointItemPool))null!=e&&(e.Clear(),M.g.DestroyUIObj(e))
this.smallMapGateConnetPointItemPool.LuaDic_Clear()
let t=0
for(;t<this.pointPool.Count();)M.g.DestroyUIObj(this.pointPool[t]),t+=1
this.pointPool.Clear(),null!=this.endPoint&&(M.g.DestroyUIObj(this.endPoint),this.endPoint=null)}0!=this.textureIdRGB&&(M.g.DestroyUIById(this.textureIdRGB),this.textureIdRGB=0),
0!=this.textureIdAlpha&&(M.g.DestroyUIById(this.textureIdAlpha),this.textureIdAlpha=0),null!=this.monsterItem&&(this.monsterItem=null),this.UnRegDrag()}CalMapSize(t,e,s){
let[i,n,l,o]=[this.textureSizeX,this.textureSizeY,this.sizeScale,s]
const a=g.t.GetUIWidth(),r=(g.t.GetUIHeight(),a/(e*s))
this.m_showHalfW=a/2
const h=k.M.Split(this.mapCfg.w_h,y.o.s_UNDER_CHAR)
return r>1&&(i=E.GF.INT(r*k.M.String2Float(h[0])),n=E.GF.INT(r*k.M.String2Float(h[1])),o=s*r,l*=r),[i,n,l,o]}Destroy(){let t=0
for(;t<this.PointItemPool.Count();)this.PointItemPool[t].Clear(),M.g.DestroyUIObj(this.PointItemPool[t]),this.PointItemPool[t]=null,t+=1
this.PointItemPool.Clear()
let e=0
for(;e<this.pointPool.Count();)M.g.DestroyUIObj(this.pointPool[e]),this.pointPool[e]=null,e+=1
this.pointPool.Clear()
for(const[t,e]of(0,h.V5)(this.pointDic)){let t=0
for(;t<e.Count();)null!=e[t].go&&M.g.DestroyUIObj(e[t].go),t+=1}this.pointDic.LuaDic_Clear(),null!=this.endPoint&&(M.g.DestroyUIObj(this.endPoint),this.endPoint=null),
this.ClearTask(),this.ClearBoss(),this.ClearTeamMembers(),this.ClearTransfer(),this.ClearRelive(),this.ClearSiegeBuild(),this.ClearText(),this.isShowByGate=!1}GetCurSmallMapVo(){
const t=this.GetMapId()
return tt.j.GetInst().GetCfgById(t)}},n.PATH_POINT_DIS=4,n.FIX_ANGLE=.707106,i=n))},51347:(t,e,s)=>{s.d(e,{t:()=>S})
var i,n=s(6847),l=s(83908),o=s(46282),a=s(98800),r=s(5494),h=s(85602),d=s(46899),c=s(6453),I=s(92679),u=s(41864),p=s(77486),_=s(21334),g=s(62783),m=s(12970)
let S=(0,n.s_)(r.I.MapLevelTips,o.Z.ui_smallmap_levep_tips_ry).register()(i=class extends((0,l.Ri)()){constructor(...t){super(...t),this.data=null}InitView(){super.InitView(),
this.wayGrid.SetInitInfo("ui_ry_forge_wayItem",null,p.Z)}Clear(){this.m_handlerMgr.RemoveEventMgr(I.g.ACCESS_ICON_CLICK,this.CreateDelegate(this.OnJustClose)),
this.m_handlerMgr.RemoveClickEvent(this.closeBtn,this.CreateDelegate(this.OnClose)),super.Clear()}Destroy(){super.Destroy()}OnAddToScene(){
this.m_handlerMgr.AddEventMgr(I.g.ACCESS_ICON_CLICK,this.CreateDelegate(this.OnJustClose)),this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.OnClose)),
this.data=m.F.getInst().leveltipsData
const t=this.data[0],e=_.p.Inst_get().GetMapById(t),s=a.Y.Inst.PrimaryRoleInfo_get().Level_get(),i=u.h.GetLevelStr(s),n=u.h.GetLevelStr(e.minLevelLimit)
this.tipsLabel.textSet(`[962424]${i}/${n}[-]可进入${e.name}`)
const l=d.m.FillDataList(new h.Z(e.levelAccess)),o=c.R.ins.GetShowAccessData(l)
this.wayGrid.data_set(o),this.wayGrid.node.x=0}OnClose(){if(this.data[1]){const t=this.data[0],e=_.p.Inst_get().GetParentMap(t),s=_.p.Inst_get().GetMapById(e)
m.F.getInst().curWorldCfg=s,g.X.inst.OpenWorldMapExpTipView()}g.X.inst.CloseMapLevelAccessTip()}OnJustClose(){g.X.inst.CloseMapPanel(),g.X.inst.CloseMapLevelAccessTip()}})||i},
54235:(t,e,s)=>{s.d(e,{C:()=>d})
var i=s(6665),n=s(61911),l=s(31222),o=s(5494),a=s(75696),r=s(21267),h=s(74657)
class d extends n.f{constructor(...t){super(...t),this.msggrid=null}InitView(){super.InitView(),this.msggrid=this.CreateComponent(i.A,1),
this.msggrid.SetInitInfo("ui_baseitem",null,a.j),this.AddFullScreenCollider(this.node,this.CreateDelegate(this.Close))}Clear(){this.msggrid.Clear(),super.Clear()}Destroy(){
this.RemoveFullScreenCollider(),this.msggrid.Destroy(),super.Destroy()}OnAddToScene(){const t=r.u.Inst().rewardTipsVo,e=h.A.GetReward(t.res.allPassReward).GetAllRewardList()
this.msggrid.data_set(e)}Close(){l.N.inst.CloseById(o.I.MapPassRewardTips)}}},32953:(t,e,s)=>{s.d(e,{a:()=>b})
var i,n,l=s(6847),o=s(83908),a=s(17409),r=s(46282),h=s(23833),d=s(26055),c=s(87722),I=s(50838),u=s(31546),p=s(97461),_=s(82737),g=s(31222),m=s(5494),S=s(27122),f=s(29839),C=s(24524),T=s(21267),y=s(15821),A=s(21334),v=s(62783),D=s(31931),w=s(12970),B=s(32697),M=s(20583)
let b=(0,l.s_)(m.I.MapUnlockBossChangeView,r.Z.ui_topsmallmap_bosschallenge_view).register()(((n=class extends((0,o.Ri)()){constructor(...t){super(...t),this.model=null,
this.mapPassVo=null,this.mapId=null,this.mapCfg=null,this.copyCfg=null,this.monsterId=null,this.objcfg=null,this.boss=null,this.displayUIAvatarModel=null}InitView(){
this.model=T.u.Inst(),this.mapPassVo=null,this.displayUIAvatarModel=new I.o,this.displayUIAvatarModel.SetTarget(this.bossTexture,!0)}Clear(){this.RemoveLis(),this.ClearBoss(),
this.bossEffect.SetActive(!1),super.Clear()}AddLis(){this.m_handlerMgr.AddClickEvent(this.btn_close,this.CreateDelegate(this.CloseThisPanel)),
this.m_handlerMgr.AddClickEvent(this.btn_ok,this.CreateDelegate(this.OnEntetCopy)),p.i.Inst.AddEventHandler(y.i.NEWBIE_MAP_BOTTOM_CHALLENGE,this.CreateDelegate(this.OnEntetCopy))}
RemoveLis(){p.i.Inst.RemoveEventHandler(y.i.NEWBIE_MAP_BOTTOM_CHALLENGE,this.CreateDelegate(this.OnEntetCopy))}OnAddToScene(){this.AddLis(),this.UpdateView()}UpdateView(){
this.bossEffect.SetActive(!0),this.mapId=w.F.getInst().curUnLockBossMapId,this.mapCfg=A.p.Inst_get().GetMapById(this.mapId),
w.F.getInst().GetCanEnterMapByLvAndTransfer(this.mapId)==D.f.BOSS_LIMIT&&0!=this.mapCfg.unlockBoss&&(this.copyCfg=C.o.Inst().getItemById(this.mapCfg.unlockBoss),
this.monsterId=this.copyCfg.bossShow,this.objcfg=h.a.getInst().getObjById(this.monsterId),this.bossName.textSet(this.objcfg.name),this.descShow.textSet(this.copyCfg.desc),
this.unlockMap.textSet(`${this.mapCfg.name}`),this.mapIcon.skin="preload:/atlas/ditu/"+this.mapCfg.senceUi,this.ShowBoss())}ShowBoss(){const t=this.objcfg
if(null!=t){const e=new d.O
this.ClearBoss(),this.boss=S.Q.Inst().GetObjectByName("MonsterCharacter",c._),this.boss.Info_set(e)
const s=new u.O
s._displayID=t.displayId,s._bNeedWaitAnime=!0,s.shiledType=_.g.DT_NONE,this.boss.InitPhotoByInfo(t,s,0)
let i=t.scale/1e4
0==i&&(i=1),this.boss.SetSize(i),this.ShowModel(t)}}ShowModel(t){const e=new u.O
e._displayID=t.displayId,e._bNeedWaitAnime=!0,e.shiledType=_.g.DT_NONE,this.displayUIAvatarModel.SetScale(.8,.8),this.displayUIAvatarModel.SetDir(4),
this.displayUIAvatarModel=M.x.inst.SetUIAvatarData(e,B.v.monster,this.displayUIAvatarModel)}ClearBoss(){null!=this.boss&&(this.boss.Destroy(),this.boss=null)}CloseThisPanel(){
g.N.inst.ClosePanel(m.I.MapUnlockBossChangeView)}OnEntetCopy(){f.p.inst.SendEnterCopy(this.copyCfg.id),v.X.inst.CloseMapPanel(),v.X.inst.CloseWorldMapExpPanel(),(0,
a.sR)(m.I.MapUnlockBossChangeView)}}).STAGE_ID=143,i=n))||i},96531:(t,e,s)=>{s.d(e,{V:()=>m})
var i,n=s(21370),l=s(6847),o=s(83908),a=s(49655),r=s(46282),h=s(86133),d=s(60130),c=s(98130),I=s(92679),u=s(87923),p=s(85770),_=s(21267),g=s(21334)
let m=(0,l.s_)(a.o.UnlockMapBossFbView,r.Z.ui_unlockboss_fb_info).layerSet(n.T.npcTalk).register()(i=class extends((0,o.Ri)()){constructor(...t){super(...t),this.model=null,
this.copyId=null,this.mapId=null}InitView(){super.InitView(),this.model=_.u.Inst()}OnAddToScene(){
if(this.m_handlerMgr.AddEventMgr(I.g.UPDATE_ANCHORS,this.CreateDelegate(this._OnUpdateAnchor)),this.copyId=p.a.Inst_get().currentCopyId,this.text_expUp.node.SetActive(!1),
this.text_exp.node.SetActive(!1),null!=this.copyId||0!=this.copyId){this.mapId=g.p.Inst_get().GetUnLockMapByCopyId(this.copyId)
const t=g.p.Inst_get().GetMapById(this.mapId)
this.ditu.skin="atlas/ditu"+t.senceUi,this.unlockMap.textSet(t.name)
const e=this.model.GetMapPassVoByMapAndLevel(this.mapId,1)
this.text_exp.node.SetActive(!0),this.text_exp.textSet(u.l.GetRuleDecimalVal(e.res.ExpRate)+(0,h.T)("/分"))
const s=e.res,i=_.u.Inst().nowFightVo
this.unlockMap.textSet(g.p.Inst_get().GetMapById(s.mapId).name)
let n=0
null!=i&&(n=c.GF.INT(s.ExpRate/i.res.ExpRate*100)/100),n>1?(this.text_expUp.textSet(100*n+"%"),this.text_expUp.node.SetActive(!0),this.text_exp.node.SetActive(!0),
this.text_exp.textSet(u.l.GetRuleDecimalVal(s.ExpRate)+(0,h.T)("/分"))):(this.text_expUp.node.SetActive(!1),this.text_exp.node.SetActive(!0),
this.text_exp.textSet(u.l.GetRuleDecimalVal(s.ExpRate)+(0,h.T)("/分")))}this._OnUpdateAnchor()}_OnUpdateAnchor(){d.O.SetAnchorPos(this.anchor,!0,!1,0,!1)}Clear(){super.Clear()}
Destroy(){super.destroy()}Test1(){return!0}S_Test(){return!0}})||i},39793:(t,e,s)=>{
var i=s(18998),n=s(75507),l=s(83908),o=s(82815),a=s(38836),r=s(38045),h=s(23833),d=s(98800),c=s(97960),I=s(11895),u=s(36241),p=s(50089),_=s(73136),g=s(2689),m=s(13687),S=s(62370),f=s(5924),C=s(66788),T=s(65733),y=s(57834),A=s(85682),v=s(18202),D=s(28192),w=s(35128),B=s(48712),M=s(3809),b=s(98130),O=s(98885),R=s(85602),L=s(38962),G=s(52212),P=s(79534),E=s(44758),k=s(72627),N=s(94148),V=s(65407),x=s(92679),F=s(31922),U=s(87923),H=s(29839),j=s(85770),W=s(92473),Y=s(89144),q=s(48933),z=s(75439),Z=s(9659),X=s(7708),Q=s(55552),J=s(68637),$=s(91690),K=s(21267),tt=s(98504),et=s(77697),st=s(98580),it=s(63412),nt=s(21334),lt=s(19276),ot=s(73082),at=s(62783),rt=s(97943),ht=s(57051),dt=s(69611),ct=s(12970),It=s(60975),ut=s(72801),pt=s(81888),_t=s(78205),gt=s(73482),mt=s(87750),St=s(63476),ft=s(39179),Ct=s(20808),Tt=s(64969),yt=s(68662),At=s(43133),vt=s(99294),Dt=s(93877),wt=s(72005),Bt=s(51868),Mt=s(12417),bt=s(6251)
class Ot extends Bt.${constructor(){super(),this.model=null,this.tModel=null,this.intervalId=-1,this.head=null,this.level=null,this.bossNameBg=null,this.bossName=null,
this.timeLabel=null,this.relive=null,this.boxCollider=null,this.double=null,this.info=null,this.numLabel=null,this.bossLvBg=null,this.bossData=null,this.isradar=null,
this.objectCfg=null,this.model=Y.I.Inst_get(),this.tModel=Mt._.Inst()}InitView(){super.InitView(),this.head=this.CreateComponent(wt.w,1),this.level=this.CreateComponent(Dt.Q,2),
this.bossNameBg=this.CreateComponent(wt.w,3),this.bossName=this.CreateComponent(Dt.Q,4),this.timeLabel=this.CreateComponent(Dt.Q,5),this.relive=this.CreateComponent(vt.z,6),
this.boxCollider=this.CreateComponent(At.V,7),this.double=this.CreateComponent(vt.z,8),this.info=this.CreateComponent(vt.z,9),this.numLabel=this.CreateComponent(Dt.Q,10),
this.bossLvBg=this.CreateComponent(wt.w,11)}SetData(t,e){this.AddLis(),this.bossData=t,this.isradar=e,this.objectCfg=Q.h.GetInst().GetObjResBySpawnId(t.crossCfg.spawnId),
this.UpdateItem()}UpdateItem(){if(this.head.spriteNameSet(this.objectCfg.headResources),this.double.SetActive(this.model.isDoubleTime),this.isradar)this.boxCollider.SetEnabled(!1),
this.info.SetActive(!1),this.numLabel.SetActive(!1),this.timeLabel.SetActive(!1),this.node.SetLocalScaleXYZ(.6,.6,.6)
else{this.boxCollider.SetEnabled(!0),this.info.SetActive(!0),this.timeLabel.SetActive(!0)
const t=h.a.inst.GetMonNameColor(this.objectCfg)
this.level.textSet(`Lv.${O.M.IntToString(this.objectCfg.level)}`),this.bossName.textSet(`${t}${this.objectCfg.name}[-]`),this.bossLvBg.widthSet(this.level.printedSize().x+15),
this.bossName.SetLocalPositionXYZ(-14-this.bossLvBg.width(),-26.3,0),this.bossNameBg.widthSet(this.bossLvBg.width()+this.bossName.printedSize().x+32),
this.info.SetLocalPositionXYZ(this.bossNameBg.width()/2,0,0),this.node.SetLocalScaleXYZ(1,1,1)}this.SetDieSp()}SetDieSp(){
-1==this.intervalId&&(this.intervalId=f.C.Inst_get().SetInterval(this.CreateDelegate(this.SetRevive),1e3)),this.SetRevive()}SetRevive(){
const t=this.bossData.info.refreshTime.ToNum()-yt.D.serverMSTime_get()
t<=0?(this.ClearInterval(),this.relive.SetActive(!1),this.isradar||(this.bossData.info.fightNum>0?(this.numLabel.textSet(`${this.bossData.info.fightNum}人`),
this.numLabel.SetActive(!0)):this.numLabel.SetActive(!1))):(this.relive.SetActive(!0),this.isradar||this.timeLabel.textSet(U.l.GetDateFormatEX(t/1e3)),this.numLabel.SetActive(!1))}
SetSpGray(t,e){t.GetGrayState()!=e&&bt.d.LuaMakeGoGray(t.node.FatherId,t.node.ComponentId,e,!0)}AddLis(){
this.m_handlerMgr.AddClickEvent(this.head,this.CreateDelegate(this.OnClickIcon))}RemoveLis(){}ClearInterval(){f.C.Inst_get().ClearInterval(this.intervalId),this.intervalId=-1}
OnClickIcon(){this.isradar||at.X.inst.OpenCrossBossChallengeView(this.bossData)}Clear(){this.RemoveLis(),this.ClearInterval(),super.Clear()}Destroy(){this.Clear(),super.Destroy()}}
var Rt,Lt,Gt=s(16315),Pt=s(9537),Et=s(9165)
const{ccclass:kt,property:Nt}=i._decorator
kt("RadarMapView")((Lt=class t extends((0,l.yk)()){constructor(...t){super(...t),this._m_handlerMgr=null,this.m_freshkey=0,this.realityHalfH=0,this.realityHalfW=0,this.isradar=!1,
this.m_halfW=0,this.m_halfH=0,this.m_showHalfW=605,this.m_showHalfH=360,this.m_textureSizeW=256,this.m_textureSizeH=256,this.m_SelfPos=null,this.pointArr=null,this.dragIndex=0,
this.scaleValue=1,this.pathArrx=null,this.pathArrz=null,this.pointDic=null,this.pointPool=null,this.endPoint=null,this.transferItems=null,this.reliveItems=null,this.textItems=null,
this.siegeBuildItems=null,this.bossItems=null,this.crossBossItems=null,this.taskItems=null,this.teamItems=null,this.miracleItems=null,this.mapIcons=null,this.awBuffIconDic=null,
this.awBuffIcons=null,this.tmpPathList=null,this.curMapId=0,this.curCopy=0,this.lastseg=-1,this.IsFocusRole=!1,this.IsScaled=!1,this.IsScaling=!1,this.IsShowDefaultRecommend=!1,
this.textureIdRGB=0,this.textureIdAlpha=0,this.mapCfg=null,this.pointHidePos=null,this.wh=null,this.textureSizeX=0,this.textureSizeY=0,this.sizeScale=1,this.isOneLoad=!0,
this.PointItemPool=null,this.isSiegeBulidUpdate=!1,this.isNeedUpdatePoint="",this.isTextureLoaded=!1,this.teamPos=null,this.localEulerAngle=null,this.pathEndPos=null,this.depth=30,
this.firstUpdateTree=!0,this.transShowDict=null,this.leftPointX=0,this.leftPointY=0,this.monsterInfoShowDict=null,this.serverMonsterDic=null,
this.multipleHangPointInfoShowPool=null,this.smallMapGateConnetPointItemPool=null,this.uimapscale=1,this.transcfg=null,this.monsterItem=null,this.type=null,this.mapAngel=0,
this._degf_ClickHandler=null,this._degf_CurrentMapItemClickHandler=null,this._degf_DragCallBack=null,this._degf_InitMap=null,this._degf_OnArriveToTargetPos=null,
this._degf_PlayerRoadsJoystickUpdateHandler=null,this._degf_PlayerRoadsUpdateHandler=null,this._degf_RefreshRoleMap=null,this._degf_TaskChangeHandler=null,
this._degf_TeamMemberPositionHandler=null,this._degf_UpdateSiegeBuildInfoHandler=null,this.itemroot=null,this.tween_scale=null,this.tween_position=null,this.monstertransform=null,
this.transformes=null,this.isShowByGate=null,this.clearMultipleHangPointList=null,this.backgroundoffsetX=null,this.backgroundoffsetY=null}get m_handlerMgr(){
return this._m_handlerMgr||(this._m_handlerMgr=D.h.Get()),this._m_handlerMgr}_initBinder(){super._initBinder(),this.m_SelfPos=new P.P,this.pointArr=new R.Z,this.pathArrx=new R.Z,
this.pathArrz=new R.Z,this.pointDic=new L.X,this.pointPool=new R.Z,this.transferItems=new R.Z,this.reliveItems=new R.Z,this.textItems=new R.Z,this.siegeBuildItems=new R.Z,
this.bossItems=new R.Z,this.crossBossItems=new R.Z,this.taskItems=new R.Z,this.teamItems=new R.Z,this.miracleItems=new R.Z,this.mapIcons=new R.Z,this.awBuffIconDic=new L.X,
this.awBuffIcons=new R.Z,this.tmpPathList=new R.Z,this.pointHidePos=new P.P(3e3,3e3,0),this.PointItemPool=new R.Z,this.localEulerAngle=new P.P(0,0,0),
this.pathEndPos=P.P.zero_get(),this.transShowDict=new L.X,this.monsterInfoShowDict=new L.X,this.serverMonsterDic=new L.X,this.multipleHangPointInfoShowPool=new L.X,
this.smallMapGateConnetPointItemPool=new L.X,this._degf_ClickHandler=t=>this.ClickHandler(t),this._degf_CurrentMapItemClickHandler=t=>this.CurrentMapItemClickHandler(t),
this._degf_DragCallBack=(t,e)=>this.DragCallBack(t,e),this._degf_InitMap=t=>this.InitMap(t),this._degf_OnArriveToTargetPos=t=>this.OnArriveToTargetPos(t),
this._degf_PlayerRoadsJoystickUpdateHandler=t=>this.PlayerRoadsJoystickUpdateHandler(t),this._degf_PlayerRoadsUpdateHandler=t=>this.PlayerRoadsUpdateHandler(t),
this._degf_RefreshRoleMap=()=>this.RefreshRoleMap(),this._degf_TaskChangeHandler=t=>this.TaskChangeHandler(t),
this._degf_TeamMemberPositionHandler=t=>this.TeamMemberPositionHandler(t),this._degf_UpdateSiegeBuildInfoHandler=t=>this.UpdateSiegeBuildInfoHandler(t)}__SubInitClass3(){}
InitView(){this.transformes=new R.Z,this.transformes.Add(this.m_bossTransform),this.transformes.Add(this.m_TransferTransform),this.isShowByGate=!1}OnAddToScene(){this.AddEvents(),
this.InitMap()}ResetItems(){this.HidePointItem(),this.HideRelive(),this.HideSiegeBuild(),this.HideTask(),this.HideTeamMembers(),this.HideText(),this.HideTransfer(),
this._delAllPathPoint(),this.ResetServerIcon()}OnRemoveFromScene(){this.RemoveEvents()}ChangeMap(){
this.curMapId==this.GetMapId()&&this.curCopy==j.a.Inst_get().currentCopyId||this.InitMap()}GetMapId(){if(this.isradar){const t=m.b.Inst.GetCurMap()
return null!=t&&t.controllerType==g.N.MULTIPLE_HANG?t.relatedMapId:at.X.inst.CurrentMapId_get()}return Y.I.Inst_get().isCrossBattleView?110001:at.X.inst.CurrentMapId_get()}
OnSceneGuide(){}InitMap(t){this.curMapId==this.GetMapId()&&this.curCopy==j.a.Inst_get().currentCopyId||this.ResetItems(),this.curMapId=this.GetMapId(),
this.curMapId!=m.b.Inst.currentMapId_get()?this.m_selfComponentWidget.node.SetActive(!1):this.m_selfComponentWidget.node.SetActive(!0),this.curCopy=j.a.Inst_get().currentCopyId,
this.mapCfg=nt.p.Inst_get().GetMapById(this.curMapId),
this.isradar?this.mapAngel=45:this.mapCfg.controllerType==g.N.SCENE||this.mapCfg.controllerType==g.N.MULTIPLE_HANG||this.mapCfg.controllerType==g.N.CROSS_BOSS_CLIENT||this.mapCfg.controllerType==g.N.ROLAND_CLIENT||this.mapCfg.controllerType==g.N.ROLAND_SERVER||this.mapCfg.controllerType==g.N.ROLAND_SAVE||this.mapCfg.controllerType==g.N.ROLAND_VALLEY?this.mapAngel=0:this.mapAngel=45,
this.isradar,this.localEulerAngle.Set(0,0,-this.mapAngel),this.wh=O.M.Split(this.mapCfg.w_h,S.o.s_UNDER_CHAR),this.textureSizeX=O.M.String2Float(this.wh[0]),
this.textureSizeY=O.M.String2Float(this.wh[1]),this.sizeScale=O.M.String2Float(this.mapCfg.smallMapScale)
let e=`atlas_smallmap_${O.M.IntToString(this.mapCfg.smallMapName)}_rgb.png`
0!=this.textureIdRGB&&(v.g.DestroyUIById(this.textureIdRGB),this.textureIdRGB=0),0!=this.textureIdAlpha&&(v.g.DestroyUIById(this.textureIdAlpha),this.textureIdAlpha=0),
this.background.skin="WEB:/smallMap/"+e,this.UITextureLoaded()}UpdateInfos(){this.isOneLoad=!0,this.UpdateSelfPos(),this.isradar&&(this.UpdateBoss(),this.UpdateTransfer()),
this.UpdateRelive(),this.UpdateTask(),this.UpdateSiegeBuildInfoHandler(null),this.UpdateText(),this.TeamMemberPositionHandler(null),this.UpdateServerInfos(),
this.UpdateCrossBattleInfos()}UpdateServerInfos(){N.b.Inst_get().InAsuramMap()&&(this.UpdateAsuramObjes(),this.UpdateAsuramFixPoints())}UpdateCrossBattleInfos(){
W.R.Inst_get().IsCrossBattle()?(this.m_handlerMgr.AddEventMgr(x.g.CROSS_BOSS_UPDATE,this.CreateDelegate(this.UpdateCrossBoss)),
W.R.Inst_get().CM_CrossBattleInfo()):(this.m_handlerMgr.RemoveEventMgr(x.g.CROSS_BOSS_UPDATE,this.CreateDelegate(this.UpdateCrossBoss)),this.ClearCrossBoss())}UpdateAsuramObjes(){
if(N.b.Inst_get().InAsuramMap()){const t=N.b.Inst_get().asuramWarObjects
if(null!=t){-1!=v.g.GetResFindId("ui_topsmallmap_mapicon")&&this.UpdateServerMonsters(t)}}}HidePointItem(){const t=this.PointItemPool.Count()
let e=0
for(;e<t;)null!=this.PointItemPool[e]&&null!=this.PointItemPool[e].node&&this.PointItemPool[e].node.transform.SetLocalPosition(this.pointHidePos),e+=1}HideMonster(){
this.monsterInfoShowDict.LuaDic_Count()
for(const[t,e]of(0,a.vy)(this.monsterInfoShowDict)){const t=e
null!=t.node&&t.node.transform.SetLocalPosition(this.pointHidePos)}}HideMultipleHangPoint(){let t=this.multipleHangPointInfoShowPool.LuaDic_Count()
null==this.clearMultipleHangPointList?this.clearMultipleHangPointList=new R.Z:this.clearMultipleHangPointList.Clear()
for(const[t,e]of(0,a.vy)(this.multipleHangPointInfoShowPool)){const s=e
s.transVo.targetMapId!=this.curMapId?this.clearMultipleHangPointList.Add(t):null!=s.node&&s.node.transform.SetLocalPosition(this.pointHidePos)}
for(let t=0;t<=this.clearMultipleHangPointList.Count()-1;t++){const e=this.clearMultipleHangPointList[t],s=this.multipleHangPointInfoShowPool[e]
null!=s&&(this.m_bossTransform.node.removeChild(s.node),s.node.visible=!1,s.Clear(),s.destroy(),v.g.DestroyUIObj(s)),this.multipleHangPointInfoShowPool.LuaDic_Remove(e)}
t=this.smallMapGateConnetPointItemPool.LuaDic_Count()
for(const[t,e]of(0,a.vy)(this.smallMapGateConnetPointItemPool)){const t=e
null!=t.node&&t.node.transform.SetLocalPosition(this.pointHidePos)}}UpdatePointList(t,e){if(null==e&&(e=!1),this.type==t&&!e)return
this.type=t
const s=this.PointItemPool.Count()
if(this.HidePointItem(),this.HideBoss(),this.HideMonster(),this.HideMultipleHangPoint(),this.HideTransfer(),this.HideSiegeBuild(),this.isSiegeBulidUpdate=!1,
!this.isTextureLoaded)return void(this.isNeedUpdatePoint=t)
const i=this.GetMapId(),n=X.j.GetInst().GetCfgById(i)
null!=n&&(t==F.z.MapViewTreeNPC?(this.UpdateNpcPoint(n,s),this.SetActiveTransform(this.m_bossTransform)):t==F.z.MapViewTreeMonster?(this.SetActiveTransform(this.m_bossTransform),
this.UpdateMonsterPoint(n,s),this.UpdateBossPoint(n,s)):t==F.z.MapViewTreeBoss?(this.SetActiveTransform(this.m_bossTransform),
this.UpdateBossPoint(n,s)):t==F.z.MapViewTreeGoldMonster?this.UpdateGoldMonsterPoint(i,s):t==F.z.MapViewTreeMultipleExpPoint?(this.SetActiveTransform(this.m_bossTransform),
this.UpdateMultipleHangPoint(n,s)):t==F.z.MapViewTreeTransNPC?(this.SetActiveTransform(this.m_bossTransform),
this.UpdateTransferNpcPoint(n,s)):t==F.z.MapViewTreeElite?(this.SetActiveTransform(this.m_bossTransform),
this.UpdateEliteMonsterPoint(n,s)):t==F.z.MapViewTreeTransport?(this.SetActiveTransform(this.m_TransferTransform),this.UpdateTransfer(),
this.CloseMonsterArea()):t==F.z.RadarMapShowAll&&(this.UpdateNpcPoint(n,s),this.UpdateMonsterPoint(n,s),this.UpdateBossPoint(n,s),this.UpdateGoldMonsterPoint(i,s),
this.UpdateMultipleHangPoint(n,s),this.UpdateTransfer(),this.UpdateEliteMonsterPoint(n,s)))}UpdateNpcPoint(t,e){const s=t.GetNpcCoordArr()
if(null==s)return
let i=0
for(;i<s.count;){if(""!=s[i]&&null!=s[i]){const t=et.f.Inst().getItemByIdRaw(O.M.String2Int(s[i]))
if(null!=t){const s=d.Y.Inst.CheckNpcShowOrHide(t)
if(null!=t&&s){const s=this.ShowPointItem(e,i,t.smallMapX,t.smallMapY)
s.isradar=this.isradar,s.SetTitle(t.name,F.z.MapViewTreeNPC)}}}i+=1}}UpdateMonsterPoint(t,e){const s=t.arrMonster
if(null==s||0==s.count)return
let i=0
for(;i<s.count;){const t=s[i]
if(null!=t&&t.count>1){const e=Z.e.Inst_get().GetCfgById(t[2])
if(null!=e){let t=this.monsterInfoShowDict.LuaDic_GetItem(e.id)
null==t&&(t=this.GetMonsterInfoItem(e,null)),e.id==at.X.inst.SpecialOpenId?t.SetIndicate(!0):t.SetIndicate(!1),
this.Adapt2RadarMapViewXYZ(e.targetX,0,e.targetY,t.node.transform,this.m_bossTransform,!0,-10),this.monsterInfoShowDict.LuaDic_AddOrSetItem(e.id,t)}}i+=1}}UpdateServerMonsters(t){
const e=N.b.Inst_get().smallmapShowList
for(let s=0;s<=t.Count()-1;s++){const i=Q.h.inst.GetSpwanItemById(t[s].modelId)
h.a.getInst().getObjById(i.objectKey)
e.IndexOf(t[s].modelId,0)>-1&&this.UpdateServerMonsterPoint(t[s])}}GetExistKey(t,e){for(let s=0;s<=t.Count()-1;s++){if(e==N.b.Inst_get().GetBuffKey(t[s]))return!0}return!1}
UpdateServerMonsterPoint(t){const e=Q.h.inst.GetSpwanItemById(t.modelId)
let s=this.serverMonsterDic.LuaDic_GetItem(t.modelId)
N.b.Inst_get().IsDynamic(e.id)
const i=N.b.Inst_get().IsLiveDynamic(e.id)
t.currHp.ToNum()<=0?null!=s&&(s.node.transform.SetLocalPosition(this.pointHidePos),this.mapIcons.Add(s),
this.serverMonsterDic.LuaDic_Remove(t.modelId)):(null==s&&(s=this.GetServerMonsterInfoItem()),
this.serverMonsterDic.LuaDic_ContainsKey(t.modelId)?this.isradar&&s.SetMonsterId(t.modelId,t.currHp,t.maxHp):(this.Adapt2RadarMapViewXYZ(e.x,0,e.y,s.node.transform,this.m_bossTransform,!0,-10),
this.serverMonsterDic.LuaDic_AddOrSetItem(t.modelId,s),i||(s.SetMonsterId(t.modelId,t.currHp,t.maxHp),k.i.Inst_get().IsAltar(t.modelId)&&(s.SetIconWH(46,63),s.SetIconPos(0,18)),
this.SetMapIconPos(t.modelId,N.b.Inst_get().GetPosKey(e.objectKey)))))}UpdateAsuramFixPoints(){const t=z.D.getInstance().GetNumberArray("ASURAMWAR:BORN_ATK_CLIENT")
let e=ht.c.GetIconStr(ht.c.ATTACK_BORN),s=N.b.Inst_get().GetIndex()
this.UpdateAsuramFixPoint(s,e,t[0],t[1],"进攻方集合点"),N.b.Inst_get().copyType==N.b.RecoveryModel?this.SetMapIconPos(s,"ASURAMWAR:SMALLMAP_1_POS_1"):this.SetMapIconPos(s,"ASURAMWAR:SMALLMAP_2_POS_1"),
e=ht.c.GetIconStr(ht.c.FORBIDEN),this.UpdateAsuramFixPoint(N.b.Inst_get().GetIndex(),e,136,170,"封闭"),this.UpdateAsuramFixPoint(N.b.Inst_get().GetIndex(),e,42,78,"封闭"),
this.UpdateAsuramFixPoint(N.b.Inst_get().GetIndex(),e,73,31,"封闭"),e=ht.c.GetIconStr(ht.c.THRONE)
const i=z.D.getInstance().GetStringValue("ASURAMWAR:THRONE_NAME"),n=N.b.Inst_get().thrones[0],l=ot.N.Inst().getWallItemById(n)
if(null!=l){s=-1
let t=""
const n=N.b.Inst_get().throneVo
null==n||O.M.IsNullOrEmpty(n.nickName)||(t=O.M.Replace("{0}正在坐","{0}",n.nickName)),this.UpdateAsuramFixPoint(s,e,l.playerPosX,l.playerPosY,i,t),
N.b.Inst_get().copyType==N.b.RecoveryModel?this.SetMapIconPos(s,"ASURAMWAR:SMALLMAP_1_POS_8"):this.SetMapIconPos(s,"ASURAMWAR:SMALLMAP_2_POS_5")}N.b.Inst_get().ResetIndex()}
UpdateBuffIcon(t){const e=this.GetAsuramWarBuffItem(t)
if(e.SetData(t),N.b.Inst_get().IsSelfBuff(t[0].spawnId))e.SetActive(!1)
else{const s=N.b.Inst_get().GetAltarPos(t[0].spawnId)
this.Adapt2RadarMapViewXYZ(s[0],0,s[1],e.node.transform,this.m_bossTransform,!0,10),e.SetActive(!0)}}GetAsuramWarBuffItem(t){let e=null
const s=N.b.Inst_get().GetBuffKey(t)
if(this.awBuffIconDic.LuaDic_ContainsKey(s))e=this.awBuffIconDic[s]
else{if(this.awBuffIcons.Count()>0)e=M.B.PopFront(this.awBuffIcons)
else{const t=n.o.getPrefab("ui_asuramwar_bufficon");(0,i.instantiate)(t).getCNode(V.v).node.setParent(this.m_bossTransform.node)}this.awBuffIconDic.LuaDic_AddOrSetItem(s,e)}
return e.node.SetParent(this.m_bossTransform.node),e}SetMapIconPos(t,e){if(null==e)return
const s=N.b.Inst_get().GetRadarPos(e)
let i=s[0],n=s[1]
this.SetMapIconXY(t,n[1],n[2],i[1],i[2],i[3],i[4],i[5],i[6])}SetMapIconXY(t,e,s,i,n,l,o,a,r){const h=this.GetMapIcon(t)
null!=h&&(h.SetIconPos(i,n),null!=e&&h.SetNameAlign(),null!=s&&h.SetExtraLAlign(s),null!=l&&h.SetNamePos(l,o),null!=a&&h.SetExtraPos(a,r))}SetMapNameXY(t,e,s){
const i=this.GetMapIcon(t)
null!=i&&i.SetNamePos(e,s)}GetMapIcon(t){for(const[e,s]of(0,a.vy)(this.serverMonsterDic))if(e==t)return s}UpdateAsuramFixPoint(t,e,s,i,n,l){null==l&&(l="")
let o=this.serverMonsterDic.LuaDic_GetItem(t)
null==o&&(o=this.GetServerMonsterInfoItem()),this.Adapt2RadarMapViewXYZ(s,0,i,o.node.transform,this.m_bossTransform,!0,-10),o.SetData(e,n,l),
this.serverMonsterDic.LuaDic_AddOrSetItem(t,o)}GetServerMonsterInfoItem(){let t=null
if(this.mapIcons.Count()>0)t=M.B.PopFront(this.mapIcons)
else{const e=n.o.getPrefab("ui_topsmallmap_mapicon")
t=(0,i.instantiate)(e).getCNode(Et.K)}return t.node.setParent(this.m_bossTransform.node),t}UpdateMultipleHangPoint(t,e){const s=t.arrMultipleExp
if(null==s||0==s.count)return
let i=0
for(;i<s.count;){const t=s[i]
if(null!=t&&t.count>1){const e=Z.e.Inst_get().GetCfgById(t[2]),s=K.u.Inst().GetResBySpawnId(e.spawnId)
if(s){const t=new R.Z(s.connetPoint)
for(let e=0;e<=t.Count()-1;e++){const i=`${s.id}_${e}`,n=K.u.Inst().GetMapPassVo(s.id)
let l=this.smallMapGateConnetPointItemPool.LuaDic_GetItem(i)
null==l&&(l=this.GetGatePointItem(i,!(n.state!=tt.s.LOCK))),this.Adapt2RadarMapViewXYZ(t[e][0],0,t[e][1],l.node.transform,this.m_bossTransform,!1,0),
this.isradar?l.node.setScale(1,1,1):l.node.setScale(this.uimapscale,this.uimapscale,1),this.smallMapGateConnetPointItemPool.LuaDic_AddOrSetItem(i,l)}}if(null!=e){
let t=this.multipleHangPointInfoShowPool.LuaDic_GetItem(e.id)
if(null==t&&(t=this.GetGateInfoItem(e)),null==t.pos){let s=this.Adapt2RadarMapViewXYZ(e.smallMapX,0,e.smallMapY,t.node.transform,this.m_bossTransform,!1,0)
t.pos=new P.P(s)}t.node.transform.SetLocalPositionXYZ(t.pos.x,t.pos.y,0),this.isradar?t.node.setScale(.7,.7,1):t.node.setScale(.8*this.uimapscale,.8*this.uimapscale,1),
this.multipleHangPointInfoShowPool.LuaDic_AddOrSetItem(e.id,t)}}i+=1}}UpdateGateListInfo(){const t=this.multipleHangPointInfoShowPool
for(const[e,s]of(0,a.V5)(t))s.UpdateState()}UpdateBossPoint(t,e){const s=t.GetDicBoss()
if(null==s||0==s.count)return
m.b.Inst.GetCurMap()
let i=0
const n=this.bossItems.Count()
for(const[t,e]of(0,a.vy)(s)){const t=e
if(null!=t){h.a.getInst().getObjById(t.monsterId)
const e=Z.e.Inst_get().GetCfgById((0,r.aI)(t.playertransport[0]))
if(null!=e){let s=null
0<n?s=this.bossItems[0]:(s=this.GetBossPrefab(),this.bossItems.Add(s)),this.Adapt2RadarMapViewXYZ(e.targetX,0,e.targetY,s.node.transform,this.m_bossTransform,0>=n),
s.isradar=this.isradar,s.Cfg_set(t,this.isradar),i+=1}}}}UpdateGoldMonsterPoint(t,e){const s=ct.F.getInst().GetMapGoldPointByMapId(t),i=d.Y.Inst.PrimaryRoleInfo_get().CurLine_get()
let n=null
if(null!=s){if(s.goldenPoints.LuaDic_ContainsKey(i)){n=s.goldenPoints[i]
let t=0
for(;t<n.goldenPoints.Count();){const s=n.goldenPoints[t]
if(null!=s){const i=this.ShowPointItem(e,t,s.x,s.y),n=Q.h.GetInst().GetSpwanItemById(s.spawnkey)
i.SetTitle(n.name,F.z.MapViewTreeGoldMonster)}t+=1}}}}UpdateTransferNpcPoint(t,e){const s=t.GetTransNpcArr()
if(null==s)return
let i=0
for(;i<s.count;){if(""!=s[i]&&null!=s[i]){const t=et.f.Inst().getItemByIdRaw(O.M.String2Int(s[i])),n=h.a.getInst().getObjById(t.objectID)
if(null!=t){this.ShowPointItem(e,i,t.smallMapX,t.smallMapY).SetTitle(n.name,F.z.MapViewTreeTransNPC)}}i+=1}}UpdateEliteMonsterPoint(t,e){let s=0
const i=t.GetDicElite()
for(const[t,n]of(0,a.vy)(i)){const n=i[t],l=h.a.getInst().getObjById(t)
if(null!=l)for(const[t,i]of(0,a.V5)(n))if(i>0){const t=Z.e.Inst_get().GetCfgById(i)
this.ShowPointItem(e,s,t.smallMapX,t.smallMapY).SetTitle(l.name,F.z.MapViewTreeElite,t),s+=1}}}ShowPointItem(t,e,s,i){let n=null,l=!1
return t>e?n=this.PointItemPool[e]:(n=this.CreatePointItem(),l=!0),this.Adapt2RadarMapViewXYZ(s,0,i,n.node.transform,this.m_bossTransform,l),n}CreatePointItem(){
const t=n.o.getPrefab("ui_topsmallmap_obj_item"),e=(0,i.instantiate)(t).getCNode(Tt.C)
return this.PointItemPool.Add(e),e}UITextureLoaded(){this.isTextureLoaded=!0,this.firstUpdateTree=!0,this.UpdateMap(),this.UpdateInfos(),this.UpdateMapPos(),
this.isradar?this.UpdatePointList(F.z.RadarMapShowAll,!0):(""!=this.isNeedUpdatePoint?(this.UpdatePointList(this.isNeedUpdatePoint,!0),
this.isNeedUpdatePoint=""):this.UpdatePointList(this.type,!0),this.OnSceneGuide())}SetShowState(t,e){this.isShowByGate=t,e&&(this.UpdateMap(),this.UpdateMapPos())}UpdateMap(){
let e=0
e=this.GetMapId()
const s=this.background.GetBoundsSize(),n=O.M.Split(this.mapCfg.w_h,S.o.s_UNDER_CHAR)
this.m_textureSizeW=O.M.String2Float(n[0]),this.m_textureSizeH=O.M.String2Float(n[1])
let l=0,o=0
n.Count()>3?(l=O.M.String2Float(n[2]),o=O.M.String2Float(n[3])):(l=this.m_textureSizeW,o=this.m_textureSizeH)
let a=1,r=1
const h=Math.max(l,o)
let c=s.x
for(;h>0&&c<h&&0!=c;)c*=2
a=l/c,r=o/c,this.uimapscale=1
const u=Math.max(this.m_textureSizeH,this.m_textureSizeW)
if(!this.isradar&&this.isShowByGate&&""!=this.mapCfg.smallMapEnlarge?this.uimapscale=O.M.String2Float(this.mapCfg.smallMapEnlarge):this.uimapscale=540/u,
this.isradar||([this.textureSizeX,this.textureSizeY,this.sizeScale,this.uimapscale]=this.CalMapSize(o,l,this.uimapscale)),
1!=this.uimapscale&&(this.m_textureSizeH=b.GF.RoundToInt(this.m_textureSizeH*this.uimapscale),this.m_textureSizeW=b.GF.RoundToInt(this.m_textureSizeW*this.uimapscale),
l=b.GF.RoundToInt(l*this.uimapscale),o=b.GF.RoundToInt(o*this.uimapscale)),this.background.widthSet(w.p.CeilToInt(l)),this.background.heightSet(w.p.CeilToInt(o)),
n.Count()>5?(q.I.calVec5.Set(O.M.String2Float(n[4])*this.uimapscale,O.M.String2Float(n[5])*this.uimapscale,0),this.background.node.transform.SetLocalPosition(q.I.calVec5),
this.backgroundoffsetX=q.I.calVec5.x,this.backgroundoffsetY=q.I.calVec5.y):(this.backgroundoffsetX=0,this.backgroundoffsetY=0,
this.background.node.transform.SetLocalPosition(P.P.zero_get())),this.m_halfW=b.GF.INT(.5*this.m_textureSizeW),this.m_halfH=b.GF.INT(.5*this.m_textureSizeH),
0==this.mapAngel?(this.realityHalfW=l/2,this.realityHalfH=o/2):(this.realityHalfW=b.GF.INT(l*t.FIX_ANGLE+o*t.FIX_ANGLE)/2,this.realityHalfH=this.realityHalfW),
Y.I.Inst_get().isCrossBattleView&&(this.m_showHalfH-=96),this.isradar)this.m_showHalfW=60,this.m_showHalfH=56
else{0!=this.dragIndex&&(I.L.Inst.UnregDrag(this.dragIndex),this.dragIndex=0)
let t=this.mapCfg
0!=t.relatedMapId&&(t=nt.p.Inst_get().GetMapById(t.relatedMapId)),this.RegDrag()}this.SetFocusRole(!0),this.node.eulerAngles=new i.math.Vec3(0,0,this.mapAngel)
null!=d.Y.Inst.PrimaryRole_get()&&(this.isradar||this.PlayerRoadsUpdateHandler(d.Y.Inst.tempRoad))}DragCallBack(t,e){this.SetFocusRole(!1)}UpdateText(){this.HideText()
this.textItems.Count()}HideText(){let t=0
for(;t<this.textItems.Count();)null!=this.textItems[t]&&null!=this.textItems[t].node&&this.textItems[t].node.transform.SetLocalPosition(this.pointHidePos),t+=1}ClearText(){let t=0
for(;t<this.textItems.Count();)null!=this.textItems[t]&&null!=this.textItems[t].node&&v.g.DestroyUIObj(this.textItems[t]),t+=1
this.textItems.Clear()}GetTextUrl(){let t=""
return t="ui_topsmallmap_textitem","ui_topsmallmap_textitem"}GetTextPrefab(){const t=this.GetTextUrl(),e=n.o.getPrefab(t)
return(0,i.instantiate)(e).getCNode(St.Z)}UpdateRelive(){this.HideRelive()
this.reliveItems.Count()}HideRelive(){let t=0
for(;t<this.reliveItems.Count();)null!=this.reliveItems[t]&&null!=this.reliveItems[t].node&&this.reliveItems[t].node.transform.SetLocalPosition(this.pointHidePos),t+=1}
ClearRelive(){let t=0
for(;t<this.reliveItems.Count();)null!=this.reliveItems[t]&&null!=this.reliveItems[t].node&&v.g.DestroyUIObj(this.reliveItems[t]),t+=1
this.reliveItems.Clear()}GetReliveUrl(){let t=""
return t="ui_topsmallmap_relivepointitem","ui_topsmallmap_relivepointitem"}GetRelivePrefab(){const t=this.GetReliveUrl(),e=n.o.getPrefab(t),s=(0,i.instantiate)(e).getCNode(pt.D)
return s.UpdateShow(),s}UpdateTransfer(){let t=0,e=null
H.p.inst.IsInCopy()?e=nt.p.Inst_get().GetAllTransportInCopy(j.a.Inst_get().currentCopyId):(t=this.GetMapId(),e=nt.p.Inst_get().GetAllTransportInMap(t))
const s=this.transferItems.Count()
let i=0,n=0
for(;n<e.Count();){let t=null
i<s?t=this.transferItems[i]:(t=this.GetTransferPrefab(),this.transferItems.Add(t)),
this.Adapt2RadarMapViewXYZ(e[n].belongPosX,0,e[n].belongPosY,t.node.transform,this.m_TransferTransform,i>=s),t.isradar=this.isradar,t.Cfg_set(e[n]),i+=1,n+=1}}ReqTeamMembers(){}
HideTransfer(){let t=0
for(;t<this.transferItems.Count();)null!=this.transferItems[t]&&null!=this.transferItems[t].node&&this.transferItems[t].node.transform.SetLocalPosition(this.pointHidePos),t+=1}
ClearTransfer(){let t=0
for(;t<this.transferItems.Count();)null!=this.transferItems[t]&&null!=this.transferItems[t].node&&v.g.DestroyUIObj(this.transferItems[t]),t+=1
this.transferItems.Clear()}GetTransferUrl(){let t=""
return t=this.isradar?"ui_topsmallmap_radartransferitem":"ui_topsmallmap_transferitem",t}GetTransferPrefab(){const t=this.GetTransferUrl(),e=n.o.getPrefab(t),s=(0,
i.instantiate)(e).getCNode(ft.r)
return s.UpdateShow(),s}UpdateTeamMembers(t){this.HideTeamMembers()
let e=null
const s=this.teamItems.Count()
let i=0,n=0
n=this.GetMapId()
let l=0
for(;l<t.memberPositions.Count();){if(e=t.memberPositions[l].objId,!e.Equal(d.Y.Inst.PlayerId_get())){let e=null
i<s?e=this.teamItems[i]:(e=this.GetTeamPrefab(),this.teamItems.Add(e)),this.Adapt2RadarMapViewXYZ(t.memberPositions[l].x,0,t.memberPositions[l].y,e.node.transform,this.m_selfTransform,i>=s,5),
e.isradar=this.isradar,e.TeamMemberId_set(t.memberPositions[l].objId),i+=1}l+=1}}ClearTeamMembers(){this.GetTeamUrl()
let t=0
for(;t<this.teamItems.Count();)null!=this.teamItems[t]&&null!=this.teamItems[t].node&&v.g.DestroyUIObj(this.teamItems[t]),t+=1
this.teamItems.Clear()}HideTeamMembers(){let t=0
for(;t<this.teamItems.Count();)null!=this.teamItems[t]&&null!=this.teamItems[t].node&&this.teamItems[t].node.transform.SetLocalPosition(this.pointHidePos),t+=1}GetTeamPrefab(){
const t=this.GetTeamUrl(),e=n.o.getPrefab(t),s=(0,i.instantiate)(e).getCNode(mt.c)
return s.UpdateShow(),s}GetTeamUrl(){let t=""
return t=(this.isradar,"ui_topsmallmap_teamitem"),t}UpdateBoss(){this.HideBoss()
let t=0
t=this.GetMapId()
let e=null
const s=j.a.Inst_get().currentCopyId
if(s>0)this.curCopy=s,e=lt.C.Inst().GetBossesByCopy(s)
else if(e=lt.C.Inst().GetBossesByMap(t),e.Count()<=0){const s=Q.h.GetInst().GetBossMapId(t)
e=lt.C.Inst().GetBossesByMap(s)}const i=this.bossItems.Count()
let n=0,l=0
for(;l<e.Count();){let t=null
n<i?t=this.bossItems[n]:(t=this.GetBossPrefab(),this.bossItems.Add(t)),this.Adapt2RadarMapViewXYZ(e[l].x_get(),0,e[l].y_get(),t.node.transform,this.m_bossTransform,n>=i),
t.isradar=this.isradar,t.Cfg_set(e[l],this.isradar),n+=1,l+=1}}UpdateCrossBoss(){const t=Y.I.Inst_get().GetCrossBossList(),e=this.crossBossItems.Count()
let s=0,i=0
for(;i<t.Count();){const n=Q.h.inst.GetSpwanItemById(t[i].crossCfg.spawnId)
let l=null
s<e?l=this.crossBossItems[s]:(l=this.GetCrossBossPrefab(),this.crossBossItems.Add(l)),this.Adapt2RadarMapViewXYZ(n.x,0,n.y,l.node.transform,this.m_bossTransform,s>=e),
l.isradar=this.isradar,l.SetData(t[i],this.isradar),s+=1,i+=1}}HideBoss(){let t=0
for(;t<this.bossItems.Count();){if(null!=this.bossItems[t]&&null!=this.bossItems[t].node){this.bossItems[t].node.transform.SetLocalPosition(this.pointHidePos)}t+=1}}ClearBoss(){
this.GetBossUrl()
let t=0
for(;t<this.bossItems.Count();)null!=this.bossItems[t]&&null!=this.bossItems[t].node&&v.g.DestroyUIObj(this.bossItems[t]),t+=1
this.bossItems.Clear()}GetBossUrl(){let t=""
return t=this.isradar?"ui_topsmallmap_radarbossitem":"ui_topsmallmap_bossitem",t}GetBossPrefab(){const t=this.GetBossUrl(),e=n.o.getPrefab(t)
return(0,i.instantiate)(e).getCNode(It.p)}ClearCrossBoss(){let t=0
for(;t<this.crossBossItems.Count();)null!=this.crossBossItems[t]&&null!=this.crossBossItems[t].node&&(this.crossBossItems[t].Clear(),v.g.DestroyUIObj(this.crossBossItems[t])),t+=1
this.crossBossItems.Clear()}GetCrossBossPrefab(){const t=n.o.getPrefab("ui_topsmallmap_crossbossitem_ry"),e=(0,i.instantiate)(t).getCNode(Ot)
return e.node.setParent(this.m_bossTransform.node),e}GetGoldMonsterUrl(){let t=""
return t=this.isradar?"ui_topsmallmap_radargoldmonsteritem":"ui_topsmallmap_goldmonsteritem",t}GetGoldMonsterPrefab(){const t=this.GetGoldMonsterUrl(),e=n.o.getPrefab(t),s=(0,
i.instantiate)(e).getCNode(ut.r)
return s.UpdateShow(),s}UpdateTask(){this.HideTask()
let t=0
t=this.GetMapId()
const e=ct.F.getInst().GetMapTask(t)
let s=null
const i=this.taskItems.Count()
let n=0,l=0
for(;l<e.Count();){s=e[l]
let[t,o]=[0,0]
if((s.status_get()==st.B.CAN_ACCEPT||s.resource_get().intersectionType==it.U.INTERSECTION_NPC)&&(t=s.NpcSmallMapX_get(),o=s.NpcSmallMapY_get()),0!=t||0!=o){let e=null
n<i?e=this.taskItems[n]:(e=this.GetTaskPrefab(),this.taskItems.Add(e)),this.Adapt2RadarMapViewXYZ(t,0,o,e.node.transform,this.m_taskTransform,n>=i),e.isradar=this.isradar,
e.Cfg_set(s),n+=1}l+=1}R.Z.Recyle(e)}HideTask(){let t=0
for(;t<this.taskItems.Count();)null!=this.taskItems[t]&&null!=this.taskItems[t].node&&this.taskItems[t].node.transform.SetLocalPosition(this.pointHidePos),t+=1}ClearTask(){
this.GetTaskUrl()
let t=0
for(;t<this.taskItems.Count();)null!=this.taskItems[t]&&null!=this.taskItems[t].node&&(this.taskItems[t].Clear(),v.g.DestroyUIObj(this.taskItems[t])),t+=1
this.taskItems.Clear()}GetTaskUrl(){let t=""
return t=(this.isradar,"ui_topsmallmap_radartaskitem"),t}GetTaskPrefab(){const t=this.GetTaskUrl(),e=n.o.getPrefab(t),s=(0,i.instantiate)(e).getCNode(gt.e)
return s.UpdateShow(),s}ClearFreshInterva(){0!=this.m_freshkey&&(f.C.Inst_get().ClearInterval(this.m_freshkey),this.m_freshkey=0)}AddEvents(){this.ClearFreshInterva(),
this.m_freshkey=f.C.Inst_get().SetInterval(this._degf_RefreshRoleMap,30),y.i.Get(this.dragmap).RegistonClick(this._degf_ClickHandler),
this.m_handlerMgr.AddEventMgr(c.A.PlayerRoadJoystickUpdate,this._degf_PlayerRoadsJoystickUpdateHandler),
this.m_handlerMgr.AddEventMgr(c.A.PlayerRoadUpdate,this._degf_PlayerRoadsUpdateHandler),
ct.F.getInst().AddEventHandler(rt.f.TeamMemberPosition,this._degf_TeamMemberPositionHandler),
ct.F.getInst().AddEventHandler(rt.f.CurrentMapItemClick,this.CreateDelegate(this.CurrentMapItemClickHandler)),
ct.F.getInst().AddEventHandler(rt.f.MapTaskChange,this._degf_TaskChangeHandler),this.m_handlerMgr.AddEventMgr(x.g.SIEGE_STATUESTATE_UPDATE,this._degf_UpdateSiegeBuildInfoHandler),
N.b.Inst_get().AddEventHandler(N.b.STATUS_UDPATE,this.CreateDelegate(this.AsuramStatusUpdateHandler)),
this.isradar||(this.m_handlerMgr.AddEventMgr(x.g.SMALL_MAP_CLICK_MONSTER,this.CreateDelegate(this.OnClickMonsterIcon)),
this.m_handlerMgr.AddEventMgr(x.g.SMALL_MAP_MOVE_TO_MONSTER,this.CreateDelegate(this.OnMoveToMonster)),
this.m_handlerMgr.AddEventMgr(x.g.SMALL_MAP_TREE_CLICK_MONSTER,this.CreateDelegate(this.OnClickMapTree)),
this.m_handlerMgr.AddEventMgr(x.g.DYNAMIC_REGIST_CONTROLID,this.CreateDelegate(this.DynamicRegistControllerIdHandler))),
K.u.Inst().AddEventHandler($.Z.UpdateMapPassInfo,this.CreateDelegate(this.UpdateGateListInfo)),
d.Y.Inst.PrimaryRoleInfo_get().AddEventHandlerRoleGlobal(c.A.LevelUpdate,this.CreateDelegate(this.UpdateGateListInfo))}RemoveEvents(){this.ClearFreshInterva(),
y.i.Get(this.dragmap).RemoveonClick(this._degf_ClickHandler),ct.F.getInst().RemoveEventHandler(rt.f.TeamMemberPosition,this._degf_TeamMemberPositionHandler),
ct.F.getInst().RemoveEventHandler(rt.f.CurrentMapItemClick,this.CreateDelegate(this.CurrentMapItemClickHandler)),
ct.F.getInst().RemoveEventHandler(rt.f.MapTaskChange,this._degf_TaskChangeHandler),
N.b.Inst_get().RemoveEventHandler(N.b.STATUS_UDPATE,this.CreateDelegate(this.AsuramStatusUpdateHandler)),
d.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandlerRoleGlobal(c.A.LevelUpdate,this.CreateDelegate(this.UpdateGateListInfo)),
K.u.Inst().RemoveEventHandler($.Z.UpdateMapPassInfo,this.CreateDelegate(this.UpdateGateListInfo)),
this.m_handlerMgr.RemoveEventMgr(c.A.PlayerRoadJoystickUpdate,this._degf_PlayerRoadsJoystickUpdateHandler),
this.m_handlerMgr.RemoveEventMgr(c.A.PlayerRoadUpdate,this._degf_PlayerRoadsUpdateHandler),
this.m_handlerMgr.RemoveEventMgr(x.g.SIEGE_STATUESTATE_UPDATE,this._degf_UpdateSiegeBuildInfoHandler),
this.isradar||(this.m_handlerMgr.RemoveEventMgr(x.g.SMALL_MAP_CLICK_MONSTER,this.CreateDelegate(this.OnClickMonsterIcon)),
this.m_handlerMgr.RemoveEventMgr(x.g.SMALL_MAP_MOVE_TO_MONSTER,this.CreateDelegate(this.OnMoveToMonster)),
this.m_handlerMgr.RemoveEventMgr(x.g.SMALL_MAP_TREE_CLICK_MONSTER,this.CreateDelegate(this.OnClickMapTree)),
this.m_handlerMgr.RemoveEventMgr(x.g.DYNAMIC_REGIST_CONTROLID,this.CreateDelegate(this.DynamicRegistControllerIdHandler)))}UpdateSiegeBuildInfoHandler(t){
this.isradar?this.UpdateSiegeBuildInfo():this.isOneLoad&&this.isSiegeBulidUpdate&&(this.isOneLoad=!1,this.UpdateSiegeBuildInfo())}DynamicRegistControllerIdHandler(t){
this.serverMonsterDic.LuaDic_ContainsKey(t[1])&&J.c.Inst.RegGameObject(t[0],this.serverMonsterDic[t[1]].node)}UnRegGuide(){J.c.Inst.UnRegGameObject(A.D.UI_ASURAMWAR_MAPGUIDE),
J.c.Inst.UnRegGameObject(A.D.UI_ASURAMWAR_MAPGUIDE_2)}AsuramStatusUpdateHandler(){0!=this.textureSizeX&&0!=this.m_halfW&&this.UpdateAsuramObjes()}UpdateSiegeBuildInfo(){
this.HideSiegeBuild()
this.siegeBuildItems.Count()}HideSiegeBuild(){let t=0
for(;t<this.siegeBuildItems.Count();)null!=this.siegeBuildItems[t]&&null!=this.siegeBuildItems[t].node&&this.siegeBuildItems[t].node.transform.SetLocalPosition(this.pointHidePos),
t+=1}ClearSiegeBuild(){let t=0
for(;t<this.siegeBuildItems.Count();)null!=this.siegeBuildItems[t]&&null!=this.siegeBuildItems[t].node&&v.g.DestroyUIObj(this.siegeBuildItems[t]),t+=1
this.siegeBuildItems.Clear()}GetSiegeBuildUrl(){let t=""
return t="ui_topsmallmap_siegebuilditem","ui_topsmallmap_siegebuilditem"}GetSiegeBuildPrefab(){const t=this.GetSiegeBuildUrl(),e=n.o.getPrefab(t),s=(0,
i.instantiate)(e).getCNode(_t.l)
return s.UpdateShow(),s}ClickHandler(t){if(this.GetMapId()!=m.b.Inst.currentMapId_get())return
if(Y.I.Inst_get().isCrossBattleView)return
const e=d.Y.Inst.PrimaryRole_get()
null!=e.AISingleton_get()&&e.AISingleton_get().getSingletonType()==o.R.hang&&(u._.getInst().isclickmap=!0)
let s=t.getUILocation(),n=this.node.transform.convertToNodeSpaceAR(new i.math.Vec3(s.x,s.y,0))
this.GoPath(n.x,n.y),ct.F.getInst().RaiseEvent(rt.f.CloseMonsterTip)}CurrentMapItemClickHandler(t){this.isradar||null==t?this.GoPath():this.OpenMonsterArea(t)}
RadarItemClickHandler(t){at.X.inst.OpenMapPanel()}GoPath(t,e){const s=P.P.zero_get()
s.x=(t/this.m_halfW+1)/2*(this.textureSizeX/this.sizeScale),s.z=(e/this.m_halfH+1)/2*(this.textureSizeY/this.sizeScale),
s.y=_.c.Instance_get().GetHeight(b.GF.INT(B.a.eTrueWorld),s.x,s.z),this.GotoTargetPos(s)}GoPathByTransPos(t,e){const s=P.P.zero_get()
s.x=t.x,s.z=t.y,s.y=_.c.Instance_get().GetHeight(b.GF.INT(B.a.eTrueWorld),s.x,s.z),this.GotoTargetPos(s,e),P.P.Recyle(s)}GotoTargetPos(t,e){
at.X.inst.GotoTargetPos(t,e,this._degf_OnArriveToTargetPos)}OnArriveToTargetPos(t){d.Y.isMapFindWay=!1,
null!=t&&t.count>2&&t[0]&&U.l.CalFastCharToXZDisFast(d.Y.Inst.PrimaryRole_get(),t[1],t[2])<2&&u._.getInst().startHang()}IsInMiracleSpawnGroups(t){for(const[e,s]of(0,
a.V5)(this.miracleItems))if(s.node.activeSelf()){const e=s.SpawnCfg_get()
new G.F(t.x-e.x,t.z-e.y)}return null}TeamMemberPositionHandler(t){}TaskChangeHandler(t){this.UpdateTask()}RefreshRoleMap(){
null!=d.Y.Inst&&null!=d.Y.Inst.PrimaryRole_get()&&(this.UpdateSelfPos(),this.isradar&&(this.UpdateMapPos(),H.p.inst.IsInCopy()||this.UpdateGateShow()),
0!=this.pointArr.Count()&&this.updatePath())}Adapt2RadarMapViewXYZ(t,e,s,i,n,l,o,a){null==o&&(o=0),null==l&&(l=!0)
let r=0,h=0
return r=(2*t/(this.textureSizeX/this.sizeScale)-1)*this.m_halfW,h=(2*s/(this.textureSizeY/this.sizeScale)-1)*this.m_halfH,null!=i&&(l&&i.node.setParent(n.node),
a||(i.SetLocalPositionXYZ(r,h,0),this.isradar,i.node.eulerAngles=this.localEulerAngle),i!=this.m_bossTransform&&this.m_selfComponent),new P.P(r,h,0)}UpdateSelfPos(){
if(null==d.Y.Inst.PrimaryRole_get())return
if(Y.I.Inst_get().isCrossBattleView)return
let[t,e,s]=this.getRoleUnityPos()
const i=this.Adapt2RadarMapViewXYZ(t,e,s,this.m_selfComponent,this.m_selfTransform,!1)
this.m_SelfPos.Set(i.x,i.y,i.z),this.UpdateSelfDirection()}getRoleUnityPos(){
let[t,e,s]=d.Y.Inst.PrimaryRole_get().GetPosXYZ(),i=U.l.CocosMapPos2UnityMapPos(this.mapCfg.engineName,t,s)
return t=i[0],s=i[1],[t,e,s]}UpdateSelfDirection(){const t=360-(d.Y.Inst.PrimaryRole_get().GetDirection()+315)
this.m_selfComponent.node.eulerAngles=new i.math.Vec3(0,0,t)}UpdateMapPos(){if(this.isradar){let t=this.GetMapPosByRolePos()
this.node.transform.SetLocalPositionXYZ(t.x,t.y,t.z)}else if(this.node.transform.SetLocalPositionXYZ(0,0,0),this.curMapId!=m.b.Inst.currentMapId_get()){
const t=nt.p.Inst_get().GetMapById(this.curMapId)
let[e,s,i]=this.GetPosByHeightGate()
t.controllerType==g.N.CROSS_BOSS_CLIENT&&(e=-this.background.node.transform.GetLocalPosition().x),this.dragTarget.transform.SetLocalPositionXYZ(e,0,i)}else{
let t=this.GetMapPosByRolePos()
this.dragTarget.transform.SetLocalPositionXYZ(t.x,0,t.z)}}UpdateGateShow(){let t=-1,e=0
const[s,i,n]=this.getRoleUnityPos()
for(const[i,l]of(0,a.V5)(this.multipleHangPointInfoShowPool)){const o=i,a=Z.e.Inst_get().GetCfgById(o),r=a.smallMapX,h=a.smallMapY
if(null==l.pos){const t=this.Adapt2RadarMapViewXYZ(r,0,h,l.node.transform,this.m_bossTransform,!1,0,!0)
l.pos=new P.P(t.x,t.y)}const d=U.l.FastDistanceXZ(s,n,r,h);(-1==t||d<t)&&(t=d,e=a.spawnId)}if(0!=e){const t=K.u.Inst().GetResBySpawnId(e)
if(t){const[e,s,i]=K.u.Inst().GetCloseVos(t.id)
for(const[t,n]of(0,a.vy)(this.multipleHangPointInfoShowPool)){const t=n
t.id!=e&&t.id!=s&&t.id!=i?null!=t.node&&t.node.transform.SetLocalPosition(this.pointHidePos):null!=t.pos?t.node.transform.SetLocalPositionXYZ(t.pos.x,t.pos.y,0):C.Y.LogError("不应该啊monsteritem.pos~=nil")
}}}}GetMapPosByRolePos(){let[e,s,i]=[0,0,0]
if(this.realityHalfW<this.m_showHalfW&&this.realityHalfH<this.m_showHalfH)return new P.P(0,0,0)
let n=this.mapCfg
if(0!=n.relatedMapId&&(n=nt.p.Inst_get().GetMapById(n.relatedMapId)),!this.isradar&&!this.isShowByGate&&!U.l.IsEmptyStr(n.fixPosition)){
const t=O.M.Split(n.fixPosition,O.M.s_SPAN_CHAR_DOT)
return e=O.M.String2Float(t[0]),s=O.M.String2Float(t[1]),new P.P(e,s,i)}0==this.mapAngel?(e=Math.floor(this.m_SelfPos.x),
s=Math.floor(this.m_SelfPos.y)):(e=Math.floor(t.FIX_ANGLE*this.m_SelfPos.x-t.FIX_ANGLE*this.m_SelfPos.y),s=Math.floor(t.FIX_ANGLE*this.m_SelfPos.x+t.FIX_ANGLE*this.m_SelfPos.y))
const[l,o,a,r]=this.GetDragBoundXYZ()
let[h,d,c]=[0,0,0]
return this.isradar&&(h=20,d=-5),e=h-e,s=d-s,i=c-i,e>a&&(e=a),e<l&&(e=l),s>r&&(s=r),s<o&&(s=o),new P.P(e,s,i)}GetPosByHeightGate(){let[e,s,i]=[0,0,0]
if(this.realityHalfW<this.m_showHalfW&&this.realityHalfH<this.m_showHalfH)return[0,0,0]
let n=this.mapCfg
const l=K.u.Inst().GetHighestGateByMap(n.id)
if(null==l)return[0,0,0]
0!=n.relatedMapId&&(n=nt.p.Inst_get().GetMapById(n.relatedMapId))
const o=K.u.Inst().GetTransVoById(l.id)
if(null==o)return[0,0,0]
const a=this.Adapt2RadarMapViewXYZ(o.targetX,0,o.targetY,null,this.m_bossTransform,!1,0,!0)
0==this.mapAngel?(e=Math.floor(a.x),s=Math.floor(a.y)):(e=Math.floor(t.FIX_ANGLE*a.x-t.FIX_ANGLE*a.y),s=Math.floor(t.FIX_ANGLE*a.x+t.FIX_ANGLE*a.y))
const[r,h,d,c]=this.GetDragBoundXYZ(),[I,u,p]=[0,0,0]
return e=I-e,s=u-s,i=p-i,e>d&&(e=d),e<r&&(e=r),s>c&&(s=c),s<h&&(s=h),[e,s,i]}_drawPath(t){this.SetFocusRole(!0),this.lastseg=-1,this._delAllPathPoint(),this.pathArrx.Clear(),
this.pathArrz.Clear(),this.pointArr.Clear()
const e=t.Count(),[s,i,n]=this.getRoleUnityPos()
this.pathArrx.Add(s),this.pathArrz.Add(n)
let l=!1,o=0
for(;o<e;)this.pathArrx.Add(t[o].x),this.pathArrz.Add(t[o].z),o==e-1&&(l=!0,this.pathEndPos.Set(t[o].x,0,t[o].z)),
0==o?this._drawPathByBeginEnd(s,n,t[o].x,t[o].z,0,l):this._drawPathByBeginEnd(t[o-1].x,t[o-1].z,t[o].x,t[o].z,o,l),o+=1
this.pathtransform.SetActive(!1)}PlayerRoadsUpdateHandler(t){if(this.curMapId!=m.b.Inst.currentMapId_get())return void this._delAllPathPoint()
if(Y.I.Inst_get().isCrossBattleView)return
let e=null
null!=t&&(e=t),null!=e&&e.Count()>0?this._drawPath(e):this._delAllPathPoint()}PlayerRoadsJoystickUpdateHandler(t){this._delAllPathPoint()}_delAllPathPoint(){for(const[t,e]of(0,
a.vy)(this.pointDic))this.ClearPoints(this.pointDic[t],t)
this.pointDic.LuaDic_Clear()}ActiveAllPathPoint(){for(const[t,e]of(0,a.vy)(this.pointDic)){let e=0
for(;e<this.pointDic[t].Count();){!0||this.pointDic[t][e].go.transform.SetLocalPosition(this.pointHidePos),e+=1}}}_drawPathByBeginEnd(e,s,i,n,l,o){
this.pointDic.LuaDic_ContainsKey(l)||this.pointDic.LuaDic_AddOrSetItem(l,new R.Z)
const a=this.pointDic[l]
let r=Math.abs(e-i),h=Math.abs(s-n),d=w.p.CeilToInt(h/t.PATH_POINT_DIS)
r>h&&(d=w.p.CeilToInt(r/t.PATH_POINT_DIS)),r/=d,h/=d
let c=0,I=0,u=0,p=-1
e<i&&(p=1)
let _=-1
s<n&&(_=1)
let g=0,m=0,S=!1,f=null
for(;c<=d;)g=b.GF.INT(c*r),m=b.GF.INT(c*h),I=Math.abs(i-e)>=g?e+g*p:i,u=Math.abs(n-s)>=m?s+m*_:n,I==i&&u==n&&(S=!0),
f=c==d&&o&&S?this._drawPathPoint(I,u,!0):this._drawPathPoint(I,u,!1),a.Add(f),c+=1
S||(f=o?this._drawPathPoint(i,n,!0):this._drawPathPoint(i,n,!1),a.Add(f))}updatePath(){this.pathtransform.SetActive(!0)
let t=0,[e,s,i]=d.Y.Inst.PrimaryRole_get().GetPosXYZ(),n=0
const l=this.pathArrx.Count()-1
if(this.pathArrx[l]==e&&i==this.pathArrz[l])n=l-1
else{let s=!1
for(t=Math.max(0,this.lastseg);t<l;){if(s=this.FindSeg(this.pathArrx[t],this.pathArrz[t],this.pathArrx[t+1],this.pathArrz[t+1],e,i),s){n=t,
s=this.FindSeg(this.pathArrx[t],this.pathArrz[t],this.pathArrx[t+1],this.pathArrz[t+1],e,i),this.lastseg=n
break}t+=1}}const o=Math.abs(e-this.pathArrx[n]),r=Math.abs(i-this.pathArrz[n])
this.ActiveAllPathPoint()
for(const[t,e]of(0,a.vy)(this.pointDic))if(t<n+1)this.ClearPoints(this.pointDic[t],t)
else if(t==n+1){let e=0,s=0
const i=this.pointDic[t],n=this.tmpPathList
n.Clear()
for(const[l,h]of(0,a.V5)(i)){e=Math.abs(h.x-this.pathArrx[t]),s=Math.abs(h.y-this.pathArrz[t])
e*e+s*s<=o*o+r*r&&n.Add(h)}for(const[t,e]of(0,a.V5)(n))i.Remove(e)
this.ClearPoints(n,-1)}}FindSeg(t,e,s,i,n,l){const o=Math.min(t,s),a=Math.max(t,s),r=Math.min(e,i),h=Math.max(e,i)
if(t==s){if(n==t&&l>=r&&l<=h)return!0}else if(e==i){if(l==i&&n>=o&&n<=a)return!0}else{if(n<o||n>a||l<r||l>h)return!1
const d=(i-e)/(s-t)*(n-t)+e
if(Math.abs(d-l)<1e-4)return!0}return!1}ClearPoints(t,e){0==e&&C.Y.Log(`key${e}`,T.C.LOG_GX)
let s=0
for(;s<t.Count();)t[s].go.transform.SetLocalPosition(this.pointHidePos),"ui_topsmallmap_point"==t[s].clazz?this.pointPool.Add(t[s].go):this.endPoint=t[s].go,s+=1
t.Clear()}isBetweenTwoNum(t,e,s){return e>s?t>=s&&t<=e:t>=e&&t<=s}OpenMonsterArea(t){this.IsScaling=!0
const e=this.GetCurSmallMapVo().GetMonsterIdByTransId(t.id)
h.a.getInst().getObjById(e)
this.transcfg=t
let s=this.monsterInfoShowDict?this.monsterInfoShowDict.LuaDic_GetItem(t.id):null
s=s||this.multipleHangPointInfoShowPool.LuaDic_GetItem(t.id),this.monsterItem=s,this.OpenMonsterTip()}SetRectPosByTransId(t,e,s){
const i=this.GetCurSmallMapVo().GetSameGroupTransIds(t)
if(null!=i)for(let t=0;t<=i.Count()-1;t++){const n=this.transShowDict.LuaDic_GetItem(i[t]).node.transform.GetLocalPosition().Clone(),l=this.Tex2Map(n)
l.x<e.x&&(e.x=l.x),l.x>s.x&&(s.x=l.x),l.y<e.y&&(e.y=l.y),l.y>s.y&&(s.y=l.y)}}ScaleToRect(t){this.scaleValue=t
const e=this.node.getScale()
this.tween_scale.SetFrom(e),this.tween_scale.SetToXYZ(this.scaleValue,this.scaleValue,1),this.tween_scale.SetEnabled(!0),this.tween_scale.ResetToBeginning(),
this.tween_scale.PlayForward()}MoveToRect(t,e){this.SetFocusRole(!1)
const s=t.x,i=t.y,n=this.node.transform.GetLocalPosition()
this.tween_position.SetFrom(n),this.tween_position.AddEventHandler(this.CreateDelegate(this.OnScaleEnd)),this.tween_position.SetToXYZ(-(s-n.x)*e,-(i-n.y)*e,0),
this.tween_position.SetEnabled(!0),this.tween_position.ResetToBeginning(),this.tween_position.PlayForward()}SetFocusRole(t){this.IsFocusRole=t}RegDrag(){this.UnRegDrag(),
U.l.IsEmptyStr(this.mapCfg.fixPosition)}UnRegDrag(){0!=this.dragIndex&&(I.L.Inst.UnregDrag(this.dragIndex),this.dragIndex=0)}ScaleToOrign(){this.scaleValue=1
const t=this.node.getScale()
this.tween_scale.SetFrom(t),this.tween_scale.SetToXYZ(1,1,1),this.tween_scale.SetEnabled(!0),this.tween_scale.ResetToBeginning(),this.tween_scale.PlayForward()
const e=this.node.transform.GetLocalPosition()
this.tween_position.SetFromXYZ(e.x,e.y,e.z)
const s=this.GetMapPosByRolePos(),i=this.dragTarget.transform.GetLocalPosition(),n=s.x-i.x,l=s.y-i.y
this.tween_position.AddEventHandler(this.CreateDelegate(this.OnScaleOrignEnd)),this.tween_position.SetToXYZ(n,l,0),this.tween_position.SetEnabled(!0),
this.tween_position.ResetToBeginning(),this.tween_position.PlayForward()}OnScaleEnd(){}OpenMonsterTip(){let t=this.monsterItem.node.transform.GetLocalPosition().clone()
t=this.Monster2Map(t)
const e=245,s=new P.P(t.x+40+150,t.y+50,0)
s.x+150>this.m_showHalfW&&(s.x=t.x-100-150),s.y+e>this.m_showHalfH&&(s.y=this.m_showHalfH-e),s.y-e<-this.m_showHalfH&&(s.y=-this.m_showHalfH+e+20),
at.X.inst.OpenMonsterTip(this.transcfg,s)}OnScaleOrignEnd(){this.tween_position.RemoveEventHandler(this.CreateDelegate(this.OnScaleOrignEnd))
const t=P.P.zero_get()
this.m_taskTransform.SetLocalPosition(t),this.m_goldmonsterTransform.SetLocalPosition(t),this.m_TransferTransform.SetLocalPosition(t),P.P.Recyle(t),this.RegDrag(),
this.monstertransform.SetActive(!1),this.IsScaling=!1}CloseMonsterArea(){}SetActiveTransform(t){for(const[e,s]of(0,
a.vy)(this.transformes))t==s?s.SetLocalPosition(P.P.zero_get()):s.SetLocalPosition(q.I.HIDE_POS)}ShowTransInfos(){
const t=this.GetMapId(),e=X.j.GetInst().GetCfgById(t).GetMonsterCoord()
if(null==e||0==e.count)return
let s=0
for(;s<e.count;){const t=e[s]
if(null!=t&&t.count>1){const e=h.a.getInst().getObjById(t[0]),s=Z.e.Inst_get().GetCfgById(t[1])
if(null!=e&&null!=s){const e=this.transShowDict.LuaDic_GetItem(s.id).node.transform.GetLocalPosition().Clone(),i=this.IsInMapPanel(e)
let n=this.monsterInfoShowDict.LuaDic_GetItem(s.id)
null!=n&&(n=this.multipleHangPointInfoShowPool.LuaDic_GetItem(s.id)),i?(null==n&&(n=this.GetMonsterInfoItem(s,e),this.monsterInfoShowDict.LuaDic_AddOrSetItem(s.id,n)),
n.node.transform.SetLocalPosition(e)):(n=this.monsterInfoShowDict.LuaDic_GetItem(t[1]),null!=n&&(n=this.multipleHangPointInfoShowPool.LuaDic_GetItem(t[1])),
null!=n&&n.node.transform.SetLocalPosition(q.I.HIDE_POS)),P.P.Recyle(e)}}s+=1}}OnMoveToMonster(t){this.GoPathByTransPos(t,!0)}OnClickMapTree(t){
if(null==t||0==t)this.CloseMonsterArea()
else{this.m_taskTransform.SetLocalPosition(q.I.HIDE_POS),this.m_goldmonsterTransform.SetLocalPosition(q.I.HIDE_POS),this.m_TransferTransform.SetLocalPosition(q.I.HIDE_POS)
const e=this.GetCurSmallMapVo(),s=ct.F.getInst().GetRecommendTransIdByMonsterId(e,t),i=Z.e.Inst_get().GetCfgById(s)
if(null!=this.transcfg&&this.transcfg.id==i.id)return
this.OpenMonsterArea(i)}}OnClickMonsterIcon(t){this.OpenMonsterArea(t)}GetMonsterInfoItem(t,e){const s=n.o.getPrefab("ui_topsmallmap_monsterinfo"),l=(0,
i.instantiate)(s).getCNode(Pt.m)
return l.node.setParent(this.m_bossTransform.node),l.SetData(t),l.HideNameandClick(this.isradar),l}GetGateInfoItem(t){const e=n.o.getPrefab("ui_topsmallmap_gate_info_ry"),s=(0,
i.instantiate)(e).getCNode(Gt.q)
return s.node.setParent(this.m_bossTransform.node),s.SetData(t,this.isradar),s}GetGatePointItem(t,e){const s=n.o.getPrefab("ui_topsmallmap_gate_conetpoint"),l=(0,
i.instantiate)(s).getCNode(Ct.X)
return l.node.setParent(this.m_bossTransform.node),l.SetData(t,e),l}IsInMapPanel(t){
return!this.IsScaling&&(!(t.x<-this.m_showHalfW-100)&&(!(t.x>this.m_showHalfW+100)&&(!(t.y<-this.m_showHalfH-100)&&!(t.y>this.m_showHalfH+100))))}TargetCoor2Map(t){
return t.x=(2*t.x/(this.textureSizeX/this.sizeScale)-1)*this.m_halfW,t.y=(2*t.y/(this.textureSizeY/this.sizeScale)-1)*this.m_halfH,t.x=b.GF.INT(t.x),t.y=b.GF.INT(t.y),t}Tex2Map(t){
return t}Monster2Map(t){return t}GetDragBound(){const t=E.L.zero_get(),[e,s,i,n]=this.GetDragBoundXYZ()
return t.Set(e,s,i,n),t}GetDragBoundXYZ(){let t,e,s,i
return t=-(this.realityHalfW+this.backgroundoffsetX-this.m_showHalfW),e=-(this.realityHalfH+this.backgroundoffsetY-this.m_showHalfH),
s=this.realityHalfW-this.backgroundoffsetX-this.m_showHalfW,i=this.realityHalfH-this.backgroundoffsetY-this.m_showHalfH,t>s&&(t=b.GF.INT32_MAX_VALUE_get(),
s=b.GF.INT32_MAX_VALUE_get()),e>i&&(e=b.GF.INT32_MAX_VALUE_get(),i=b.GF.INT32_MAX_VALUE_get()),[t,e,s,i]}_drawPathPoint(t,e,s){let l=null,o=!1,a=""
a=s?this.isradar?"ui_topsmallmap_radarendpoint":"ui_topsmallmap_endpoint":"ui_topsmallmap_point"
if(s)if(null!=this.endPoint)l=this.endPoint
else{const t=n.o.getPrefab(a),e=(0,i.instantiate)(t)
l=e,e.transform.SetLocalPosition(this.pointHidePos),o=!0}else if(this.pointPool.Count()>0)l=M.B.PopFront(this.pointPool)
else{const t=n.o.getPrefab(a),e=(0,i.instantiate)(t)
l=e,e.transform.SetLocalPosition(this.pointHidePos),o=!0}if(null!=l){let s=U.l.CocosMapPos2UnityMapPos(this.mapCfg.engineName,t,e),i=s[0],n=s[1]
const a=new G.F
let r,h
a.x=t,a.y=e,this.pointArr.Add(a),r=(2*i/(this.textureSizeX/this.sizeScale)-1)*this.m_halfW,h=(2*n/(this.textureSizeY/this.sizeScale)-1)*this.m_halfH,
o&&(l.setParent(this.pathtransform),l.transform.SetLocalPositionXYZ(0,0,0)),l.transform.SetLocalPositionXYZ(r,h,0),
this.isradar?q.I.calVec5.Set(1,1,1):q.I.calVec5.Set(this.uimapscale,this.uimapscale,1),l.setScale(q.I.calVec5)}const r=new dt.P
return r.x=t,r.y=e,r.go=l,r.clazz=a,r}ResetServerIcon(){for(const[t,e]of(0,a.V5)(this.serverMonsterDic))null!=e&&(e.Clear(),v.g.DestroyUIObj(e))
this.serverMonsterDic.LuaDic_Clear()
for(const[t,e]of(0,a.vy)(this.mapIcons))null!=e&&(e.Clear(),v.g.DestroyUIObj(e))
this.mapIcons.Clear()
for(const[t,e]of(0,a.V5)(this.awBuffIconDic))null!=e&&(e.Clear(),v.g.DestroyUIObj(e))
this.awBuffIconDic.Clear()
for(const[t,e]of(0,a.V5)(this.awBuffIcons))null!=e&&(e.Clear(),v.g.DestroyUIObj(e))
this.awBuffIcons.Clear()}Clear(){this.type=null,this.isTextureLoaded=!1,this.isNeedUpdatePoint="",this.UnRegGuide(),this.ResetItems(),this.ClearFreshInterva(),
this.OnRemoveFromScene(),null!=this.clearMultipleHangPointList&&(this.clearMultipleHangPointList.Clear(),this.clearMultipleHangPointList=null),this.ClearCrossBoss(),
this.isradar||(this.IsShowDefaultRecommend=!1)
for(const[t,e]of(0,a.V5)(this.monsterInfoShowDict))null!=e&&(e.destroy(),v.g.DestroyUIObj(e))
this.monsterInfoShowDict.LuaDic_Clear()
for(const[t,e]of(0,a.vy)(this.serverMonsterDic))null!=e&&(e.destroy(),v.g.DestroyUIObj(e))
for(const[t,e]of(0,a.V5)(this.smallMapGateConnetPointItemPool))null!=e&&(e.destroy(),v.g.DestroyUIObj(e))
this.smallMapGateConnetPointItemPool.LuaDic_Clear()
let t=0
for(;t<this.pointPool.Count();)v.g.DestroyUIObj(this.pointPool[t]),t+=1
this.pointPool.Clear(),null!=this.endPoint&&(v.g.DestroyUIObj(this.endPoint),this.endPoint=null)
for(const[t,e]of(0,a.V5)(this.multipleHangPointInfoShowPool))null!=e&&(e.Clear(),v.g.DestroyUIObj(e))
this.multipleHangPointInfoShowPool.LuaDic_Clear(),0!=this.textureIdRGB&&(v.g.DestroyUIById(this.textureIdRGB),this.textureIdRGB=0),
0!=this.textureIdAlpha&&(v.g.DestroyUIById(this.textureIdAlpha),this.textureIdAlpha=0),null!=this.monsterItem&&(this.monsterItem=null),this.UnRegDrag()}Destroy(){
this.isShowByGate=!1}GetCurSmallMapVo(){const t=this.GetMapId()
return X.j.GetInst().GetCfgById(t)}CalMapSize(t,e,s){let[i,n,l,o]=[this.textureSizeX,this.textureSizeY,this.sizeScale,s]
const a=p.t.GetUIWidth()-70,r=a/(e*s)
this.m_showHalfW=a/2
const h=O.M.Split(this.mapCfg.w_h,S.o.s_UNDER_CHAR)
return i=b.GF.INT(r*O.M.String2Float(h[0])),n=b.GF.INT(r*O.M.String2Float(h[1])),o=s*r,l*=r,[i,n,l,o]}},Lt.PATH_POINT_DIS=4,Lt.FIX_ANGLE=.707106,Rt=Lt))},32426:(t,e,s)=>{
var i=s(18998),n=s(83908),l=s(38836),o=s(86133),a=s(23833),r=s(98800),h=s(50089),d=s(67075),c=s(68662),I=s(2689),u=s(62370),p=s(5924),_=s(66788),g=s(48330),m=s(57834),S=s(85682),f=s(5494),C=s(28192),T=s(98130),y=s(98885),A=s(85602),v=s(52212),D=s(79534),w=s(94148),B=s(85430),M=s(84229),b=s(53905),O=s(84308),R=s(92679),L=s(31922),G=s(87923),P=s(65772),E=s(85770),k=s(92473),N=s(89144),V=s(48933),x=s(75439),F=s(7708),U=s(47786),H=s(83900),j=s(91690),W=s(21267),Y=s(77697),q=s(79878),z=s(89803),Z=s(84458),X=s(21334),Q=s(62783),J=s(31931),$=s(97943)
class K{constructor(){this.txt=null,this.linktxt=null,this.randomLinktxt=null}}
var tt=s(6219),et=s(12970),st=s(97461),it=s(36241),nt=s(43133),lt=s(99294),ot=s(92178),at=s(93877),rt=s(72005),ht=s(18202),dt=s(35128),ct=s(87048),It=s(55552),ut=s(37322),pt=s(17783),_t=s(98580),gt=s(70415),mt=s(43662),St=s(97960),ft=s(26055),Ct=s(87722),Tt=s(8889),yt=s(16261),At=s(30849),vt=s(27122)
class Dt extends At.C{constructor(){super(),this.labelName=null,this.labelLv=null,this.spBase=null,this.labelDesc=null,this.monsterTexture=null,this.panel=null,this.monster=null,
this._degf_BossInitHandler=null,this._degf_BossInitHandler=t=>this.BossInitHandler(t)}InitView(){super.InitView(),this.labelName=new at.Q,
this.labelName.setId(this.FatherId,this.FatherComponentID,1),this.labelLv=new at.Q,this.labelLv.setId(this.FatherId,this.FatherComponentID,2),this.spBase=new lt.z,
this.spBase.setId(this.FatherId,this.FatherComponentID,3),this.labelDesc=new at.Q,this.labelDesc.setId(this.FatherId,this.FatherComponentID,4),this.monsterTexture=new yt.X,
this.monsterTexture.setId(this.FatherId,this.FatherComponentID,5),this.panel=new Tt.$,this.panel.setId(this.FatherId,this.FatherComponentID,6)}Clear(){
null!=this.monster&&(this.monster.Destroy(),this.monster=null),mt.M.Instance_get().DeactiveStage(Dt.STAGE_ID,this.monsterTexture.FatherId,this.monsterTexture.ComponentId)}
InitMonsterView(t,e){let s=!1
const i=x.D.getInstance().getContent("MAP:BUILDING_BOSS_TIPS").getContent().arrayVal
let n=0
for(;n<i.count;){if(y.M.String2Int(i[n])==t){s=!0
break}n+=1}s?this.spBase.SetActive(!1):this.spBase.SetActive(!0)
const l=a.a.getInst().getObjById(t)
if(null!=l){this.labelName.textSet(l.name),this.labelLv.textSet(e),this.labelDesc.textSet(l.mapDesc)
const t=new ft.O
null==this.monster?(this.monster=vt.Q.Inst().GetObjectByName("MonsterCharacter",Ct._),this.monster.Info_set(t)):(this.monster.Destroy(),
this.monster=vt.Q.Inst().GetObjectByName("MonsterCharacter",Ct._),this.monster.Info_set(t)),mt.M.Instance_get().ActiveStage(Dt.STAGE_ID),this.monster.InitByCfg(l,Dt.STAGE_ID),
this.monster.setPosXYZ(l.v_Pos.x,l.v_Pos.y,l.v_Pos.z),this.monster.setDirectionXYZ(l.v_Rotate),this.monster.SetSize(l.mapScale),
this.monster.Info_get().AddEventHandler(St.A.MonsterInit,this._degf_BossInitHandler),this.monsterTexture.SetMainTextureByPhoto(Dt.STAGE_ID),this.monsterTexture.SetUVRect(0,0,1,1)}}
BossInitHandler(t){null!=this.monster&&this.monster.MainRole_get().DisableShadow()}}Dt.STAGE_ID=34
class wt extends ot.E{constructor(){super(),this.name=null,this.tween=null,this.suggest=null,this.level=null,this.goldMonsterTag=null,this.item=null,this.select=null,
this.dangerous=null,this.m_data=null,this.isShowTip=!1,this.longPress=null,this.tipView=null,this.offset=null,this.isDraging=!1,this.dragInterval=-1,this.findPathRandomIndex=null,
this._degf_OnClickHandler=null,this._degf_OnDragEnd=null,this._degf_OnDragStart=null,this._degf_OnPressHandler=null,this._degf_ResetDragState=null,this._degf_SelectItem=null,
this.hasTaskTip=null,this.headIcon=null,this.contexttxt=null,this.offset=new D.P(299,71,0),this._degf_OnClickHandler=()=>this.OnClickHandler(),
this._degf_OnDragEnd=(t,e)=>this.OnDragEnd(t,e),this._degf_OnDragStart=(t,e)=>this.OnDragStart(t,e),this._degf_OnPressHandler=(t,e)=>this.OnPressHandler(t,e),
this._degf_ResetDragState=()=>this.ResetDragState(),this._degf_SelectItem=t=>this.SelectItem(t)}InitView(){super.InitView(),this.name=new at.Q,
this.name.setId(this.FatherId,this.FatherComponentID,1),this.suggest=new lt.z,this.suggest.setId(this.FatherId,this.FatherComponentID,5),this.level=new at.Q,
this.level.setId(this.FatherId,this.FatherComponentID,7),this.goldMonsterTag=new lt.z,this.goldMonsterTag.setId(this.FatherId,this.FatherComponentID,8),this.item=new nt.V,
this.item.setId(this.FatherId,this.FatherComponentID,9),this.select=new rt.w,this.select.setId(this.FatherId,this.FatherComponentID,10),this.dangerous=new lt.z,
this.dangerous.setId(this.FatherId,this.FatherComponentID,11),this.hasTaskTip=this.CreateComponent(at.Q,13),this.headIcon=new rt.w,
this.headIcon.setId(this.FatherId,this.FatherComponentID,14),this.contexttxt=new at.Q,this.contexttxt.setId(this.FatherId,this.FatherComponentID,15),
this.longPress=new ut.c(this.item.node,this._degf_OnClickHandler,this._degf_OnPressHandler),this.suggest.SetActive(!1)}SetMyTreeData(t){super.SetMyTreeData(t),
this.findPathRandomIndex=new A.Z,this.m_data=t,this.isShowTip=!1,this.isDraging=!1,this.goldMonsterTag.SetActive(!1),this.select.node.SetActive(!1),
this.dangerous.SetActive(2==this.m_data.difficulty),this.hasTaskTip.node.SetActive(!1)
let e=`[fedea0]${this.m_data.name}[-]`,s=`[fedea0]${this.m_data.m_level}[-]`
if(t.m_type==L.z.MapViewTreeMultipleExpPoint||t.m_type==L.z.MapViewTreeBoss){const i=gt.i.Inst().getItemById(t.cfgId),n=et.F.getInst().GetPlayerMaxDef()
if(i.defenseRec>n)s=`[db0016]${this.m_data.m_level}[-]`,e=`[db0016]${this.m_data.name}[-]`
else{const i=pt.L.Inst_get().model.GetAllQuestes()
let n=!1
for(let e=0;e<=i.Count()-1;e++){const s=i[e]
if(s.isKillTask_get())for(let e=0;e<=s.tCTargetDefs_get().tCTargetDefs.Count()-1;e++){const i=s.tCTargetDefs_get().tCTargetDefs[e].param
if(s.status_get()==_t.B.ACCEPTED){if(i.monsterId>0&&i.monsterId==t.cfgId){n=!0
break}if(i.monsterGroupId>0){if(ct.$.Inst_get().GetGroupId(i.monsterGroupId).Contains(t.cfgId)){n=!0
break}}}}if(n)break}if(n&&(s=`[5fb470]${this.m_data.m_level}[-]`,e=`[5fb470]${this.m_data.name}[-]`),this.hasTaskTip.node.SetActive(n),
n&&Q.X.inst.IsSpecialOpen&&0!=Q.X.inst.SpecialOpenId){const t=It.h.GetInst().GetSpwanItemById(Q.X.inst.SpecialOpenId),i=a.a.getInst().getObjById(t.objectKey)
a.a.getInst().getObjById(t.objectKey).level>i.level&&(s=`[5fb470]${this.m_data.m_level}[-]`,e=`[5fb470]${this.m_data.name}[-]`)}}}
if(this.m_data.m_type==L.z.MapViewTreeBoss||this.m_data.m_type==L.z.MapViewTreeMonster||this.m_data.m_type==L.z.MapViewTreeGoldMonster||this.m_data.m_type==L.z.MapViewTreeMultipleExpPoint){
const t=a.a.getInst().getObjById(this.m_data.cfgId)
t&&this.headIcon.spriteNameSet(t.headResources),this.name.textSet(e),this.contexttxt.textSet(""),this.headIcon.node.SetActive(!0)}else this.name.textSet(""),
this.contexttxt.textSet(e),this.headIcon.node.SetActive(!1)
this.level.textSet(s),m.i.Get(this.item.node).RemoveonDragStart(this._degf_OnDragStart),m.i.Get(this.item.node).RemoveonDragEnd(this._degf_OnDragEnd),
m.i.Get(this.item.node).RegistonDragStart(this._degf_OnDragStart),m.i.Get(this.item.node).RegistonDragEnd(this._degf_OnDragEnd),this.RemoveLis(),this.AddLis()}AddLis(){
this.longPress.AddEvent(),st.i.Inst.AddEventHandler(R.g.SELECT_CURRENT_MAP_ITEM,this._degf_SelectItem)}RemoveLis(){this.longPress.Clear(),
st.i.Inst.RemoveEventHandler(R.g.SELECT_CURRENT_MAP_ITEM,this._degf_SelectItem)}SetSelected(t){t&&Q.X.inst.IsSpecialOpen&&this.OnClickHandler()}Destroy(){
m.i.Get(this.item.node).RemoveonDragStart(this._degf_OnDragStart),m.i.Get(this.item.node).RemoveonDragEnd(this._degf_OnDragEnd),this.RemoveLis(),
-1!=this.dragInterval&&(p.C.Inst_get().ClearInterval(this.dragInterval),this.dragInterval=-1),this.longPress.Destory(),null!=this.tipView&&(this.tipView.Clear(),
ht.g.DestroyUIObj(this.tipView)),this.name=null,this.item=null,this.tween=null,this.suggest=null,this.level=null,this.goldMonsterTag=null}OnDragStart(t,e){
-1!=this.dragInterval&&(p.C.Inst_get().ClearInterval(this.dragInterval),this.dragInterval=-1),this.isDraging=!0}OnDragEnd(t,e){
this.dragInterval=p.C.Inst_get().SetInterval(this._degf_ResetDragState,100,1)}ResetDragState(){this.isDraging=!1}OnClickHandler(){
if(st.i.Inst.RaiseEvent(R.g.SELECT_CURRENT_MAP_ITEM,this.m_data),this.isShowTip)this.CloseTips()
else if(this.m_data.m_type==L.z.MapViewTreeNPC)r.Y.Inst.GoToNpc(this.m_data.cfgId,!0),st.i.Inst.RaiseEvent(R.g.SMALL_MAP_TREE_CLICK_MONSTER),
et.F.getInst().RaiseEvent($.f.CloseMonsterTip)
else if(this.m_data.m_type==L.z.MapViewTreeTransNPC)r.Y.Inst.GoToNpc(this.m_data.cfgId,!0),st.i.Inst.RaiseEvent(R.g.SMALL_MAP_TREE_CLICK_MONSTER),
et.F.getInst().RaiseEvent($.f.CloseMonsterTip)
else if(this.m_data.m_type==L.z.MapViewTreeTransport)null!=this.m_data.info&&this.GotoTransport(this.m_data.info),st.i.Inst.RaiseEvent(R.g.SMALL_MAP_TREE_CLICK_MONSTER),
et.F.getInst().RaiseEvent($.f.CloseMonsterTip)
else if(this.m_data.m_type==L.z.MapViewTreeBoss)null!=this.m_data.info&&Q.X.inst.GotoByLinkStr(this.m_data.info.linktxt),st.i.Inst.RaiseEvent(R.g.SMALL_MAP_TREE_CLICK_MONSTER)
else{const t=this.m_data.info
if(null!=t&&0==this.isDraging){if(null!=t.linktxt);else if(null!=t.randomLinktxt&&t.randomLinktxt.count>0){let e=0
for(;e<t.randomLinktxt.count;){if(t.randomLinktxt[e]==et.F.getInst().LastFindPathLink_get())return
e+=1}t.randomLinktxt.count==this.findPathRandomIndex.Count()&&this.findPathRandomIndex.Clear()
let s=T.GF.INT(dt.p.RandomMax(t.randomLinktxt.count-.01))
if(this.findPathRandomIndex.Count()>0){let e=this.findPathRandomIndex.IndexOf(s,0)
for(;-1!=e;)s=T.GF.INT(dt.p.RandomMax(t.randomLinktxt.count-.01)),e=this.findPathRandomIndex.IndexOf(s,0)}this.findPathRandomIndex.Add(s)
t.randomLinktxt[s]}st.i.Inst.RaiseEvent(R.g.SMALL_MAP_TREE_CLICK_MONSTER,this.m_data.cfgId)}}}SelectItem(t){const e=t
this.m_data.id==e.id&&this.m_data.parentID==e.parentID&&this.m_data.info==e.info?this.select.node.SetActive(!0):this.select.node.SetActive(!1)}OnPressHandler(t,e){
this.m_data.m_type!=L.z.MapViewTreeMonster&&this.m_data.m_type!=L.z.MapViewTreeBoss&&this.m_data.m_type!=L.z.MapViewTreeTown&&this.m_data.m_type!=L.z.MapViewTreeStone&&this.m_data.m_type!=L.z.MapViewTreeDoor||(e&&0==this.isDraging?this.ShowTips(this.m_data.m_type):this.CloseTips())
}ShowTips(t){if(null!=a.a.getInst().getObjById(this.m_data.cfgId)){this.isShowTip=!0
let e=0
e=t==L.z.MapViewTreeBoss?ht.g.GetResFindId("ui_smallmapbosstip"):ht.g.GetResFindId("ui_smallmapmonstertip"),this.tipView=new Dt,this.tipView.setId(e,null,0),
this.tipView.InitMonsterView(this.m_data.cfgId,this.m_data.m_level),
this.tipView.node.transform.SetParent(Q.X.inst.currentView_get().rightPanel.FatherId,Q.X.inst.currentView_get().rightPanel.ComponentId),this.tipView.node.transform.ResetTransform()
const s=D.P.zero_get()
this.tipView.node.transform.SetLocalPosition(s),D.P.Recyle(s),this.tipView.panel.depthSet(Q.X.inst.currentView_get().scrollViewPanel.depth()+1)}else this.isShowTip=!1}CloseTips(){
this.isShowTip=!1,null!=this.tipView&&(this.tipView.Clear(),ht.g.DestroyUIObj(this.tipView))}GotoTransport(t){if(null!=t.randomLinktxt&&t.randomLinktxt.count>2){
const e=y.M.String2Float(t.randomLinktxt[0]),s=y.M.String2Float(t.randomLinktxt[1]),i=y.M.String2Float(t.randomLinktxt[2])
it._.getInst().endHang(),r.Y.Inst.PrimaryRole_get().gotoPointAndShowStr(new D.P(e,s,i))}}}var Bt=s(41864)
class Mt extends((0,n.yk)()){constructor(...t){super(...t),this.mapRes=null,this.mapId=null}InitView(){}SetData(t){const e=W.u.Inst().GetMapPassProgressVoByMapId(t)
this.mapRes=X.p.Inst_get().GetMapById(t),this.mapId=t
const s=et.F.getInst().IsOpenMap(this.mapId)
e.nowLevel==e.maxLevel?(this.passPic.SetActive(!0),this.statePic.node.SetActive(!0),this.lab_progress.textSet(""),this.name.textSet(`[C4B2A1]${this.mapRes.name}[-]`),
this.lockPic.SetActive(!1),this.SetItemClickGo(this.node)):s?(this.statePic.node.SetActive(!0),this.passPic.SetActive(!1),
this.lab_progress.textSet(`[C4B2A1]${Bt.h.GetLevelStr(e.nowLevel,"关")}/${Bt.h.GetLevelStr(e.maxLevel,"关")}[-]`),this.name.textSet(`[C4B2A1]${this.mapRes.name}[-]`),
this.lockPic.SetActive(!1),this.SetItemClickGo(this.node)):(this.statePic.node.SetActive(!1),this.passPic.SetActive(!1),
this.lab_progress.textSet(`[95968E]${Bt.h.GetLevelStr(this.mapRes.minLevelLimit)}[-]`),this.name.textSet(`[95968E]${this.mapRes.name}[-]`),this.lockPic.SetActive(!0))}SetSelect(t){
const e=t==this.mapId
this.select.SetActive(e)}}var bt,Ot,Rt=s(9986),Lt=s(9057)
class Gt extends Lt.x{constructor(...t){super(...t),this.lineName=null,this.itemBtn=null,this.background=null,this.vo=null,this.curIndex=null}InitView(){
this.lineName=this.CreateComponent(at.Q,1),this.itemBtn=this.CreateComponent(Rt.W,2),this.background=this.CreateComponent(lt.z,3)}SetData(t){this.vo=t,
null!=this.vo&&(this.curIndex=this.vo.lineNum,0!=this.vo.lineIndex?this.lineName.textSet(this.vo.lineIndex+(0,o.T)("线")):this.lineName.textSet(this.vo.lineNum+(0,o.T)("线")),
this.vo.lineNum==et.F.getInst().CurLine_get()?(this.SetSelect(!0),this.m_handlerMgr.RemoveClickEvent(this.node,this.CreateDelegate(this.clickHandler))):(this.SetSelect(!1),
this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.clickHandler))))}SetSelect(t){this.background.SetActive(t)}Clear(){super.Clear()}clickHandler(t,e){
Q.X.inst.changeLine(this.curIndex),et.F.getInst().RaiseEvent($.f.CloseSelectLine)}Destroy(){}}const{ccclass:Pt,property:Et}=i._decorator
Pt("SmallMapCurrentView")(((Ot=class extends((0,n.yk)()){constructor(...t){super(...t),this._m_handlerMgr=null,this.currSelectTreeTitle="",this.forceInitTreeInterval=-1,
this.treeTitle=null,this.closeLineInterval=-1,this.isLineClosing=!1,this._degf_CloseLine=null,this._degf_CreateItemHandler=null,this._degf_CreateTitleItemHandler=null,
this._degf_DelayForceInitTree=null,this._degf_GetMapGoldMonsterHandler=null,this._degf_OnGridReposition=null,this._degf_OnItemRefreshFun=null,this._degf_OnTreeItemChange=null,
this._degf_UpdateInfo=null,this._degf_closeLinesHandler=null,this._degf_onCloseLinesClick=null,this._degf_onShowBtnClick=null,this._degf_SortList=null,this.isShowMapList=null,
this.isClickLineBtn=null,this.mapState=null,this.mapId=null,this.titleSortArr=null,this.registerUIScId=null,this.registerUIId=null,this.tideTime=null,this.isDoubleTime=null,
this.tideInterval=null,this.isHaveMultipleNode=null,this.isHaveBossNode=null}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=C.h.Get()),this._m_handlerMgr}
_initBinder(){super._initBinder(),this.treeTitle=new A.Z,this._degf_CloseLine=()=>this.CloseLine(),this._degf_CreateItemHandler=t=>this.CreateItemHandler(t),
this._degf_CreateTitleItemHandler=t=>this.CreateTitleItemHandler(t),this._degf_DelayForceInitTree=()=>this.DelayForceInitTree(),
this._degf_GetMapGoldMonsterHandler=t=>this.GetMapGoldMonsterHandler(t),this._degf_OnGridReposition=()=>this.OnGridReposition(),
this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),this._degf_OnTreeItemChange=t=>this.OnTreeItemChange(t),this._degf_UpdateInfo=t=>this.UpdateInfo(),
this._degf_closeLinesHandler=t=>this.closeLinesHandler(t),this._degf_onCloseLinesClick=(t,e)=>this.onCloseLinesClick(t,e),this._degf_onShowBtnClick=(t,e)=>this.onShowBtnClick(t,e),
this._degf_SortList=(t,e)=>this.SortList(t,e)}InitView(){this.msggrid.SetInitInfo("ui_world_map_gate_item_ry",null,Mt,this.CreateDelegate(this.OnClickWorldMapGrid)),
this.msggrid.OnReposition_set(this.CreateDelegate(this.OnWorldMapGridReposition)),this.grid.SetInitInfo("ui_topsmallmap_currentmaplinemenuitem_ry",this._degf_OnItemRefreshFun),
this.grid.OnReposition_set(this._degf_OnGridReposition),this.isShowMapList=!1,this.isClickLineBtn=!1,this.mapState=0,this.UpdateAnchors()
const t=Q.X.inst.CurrentMapId_get()
X.p.Inst_get().GetMapById(t).dynamicChannel||0!=E.a.Inst_get().currentCopyId||Q.X.inst.getMapLines()
const e=W.u.Inst().GetMapPassProgressVoByMapId(t)
this.mapState=null==e?0:1}OnTreeItemChange(t){const e=t
null==e||e.id!=L.z.MapViewTreeNPC&&e.id!=L.z.MapViewTreeMonster&&e.id!=L.z.MapViewTreeGoldMonster&&e.id!=L.z.MapViewTreeMultipleExpPoint&&e.id!=L.z.MapViewTreeTransNPC&&e.id!=L.z.MapViewTreeTransport&&e.id!=L.z.MapViewTreeElite&&e.id!=L.z.MapViewTreeBoss||0==this.mapState&&(this.radarView.UpdatePointList(e.id),
this.currSelectTreeTitle=e.id,Q.X.inst.SmallMapCurrentViewTreeSelect=this.currSelectTreeTitle,this.scrollview.ResetPosition())}CreateTitleItemHandler(t){const e=new g.l
return e.setId(t,null,0),e}CreateItemHandler(t){const e=new wt
return e.setId(t,null,0),e}OnAddToScene(){0!=Q.X.inst.DefaultOpenSceneMapId?(this.mapId=Q.X.inst.DefaultOpenSceneMapId,
Q.X.inst.DefaultOpenSceneMapId=0):this.mapId=Q.X.inst.CurrentMapId_get()
const t=X.p.Inst_get().GetMapById(this.mapId)
t.controllerType==I.N.MULTIPLE_HANG&&(this.mapId=t.relatedMapId),Q.X.inst.CurrentMapId_set(this.mapId)
const e=W.u.Inst().GetMapPassProgressVoByMapId(this.mapId)
this.mapState=null==e?0:1
const s=D.P.zero_get()
this.scrollViewPanel.node.transform.SetLocalPosition(s),D.P.Recyle(s),w.b.Inst_get().InAsuramMap()?(this.radarView.dragmap.SetActive(!1),
this.ausramwarmappanel.dragmap.SetActive(!0),this.ausramwarmappanel.SetShowState(!0),this.ausramwarmappanel.OnAddToScene(),
this.bg.SetActive(!1)):(this.radarView.dragmap.SetActive(!0),this.ausramwarmappanel.dragmap.SetActive(!1),this.radarView.SetShowState(1==this.mapState),
this.radarView.OnAddToScene(),this.bg.SetActive(!0)),this.UpdateInfo(),this.RemoveLis(),this.AddLis(),Q.X.inst.ReqGoldMonsterInfos(),
this.forceInitTreeInterval=p.C.Inst_get().SetInterval(this._degf_DelayForceInitTree,300,1),
this.titleSortArr=y.M.Split(x.D.getInstance().getContent("SMALLMAP:TABLE_SORT").getContent().stringVal,";"),this.RegUIShow()}RegUIShow(){this.registerUIScId=S.D.NowMap,
this.registerUIId=f.I.eMap,null!=this.registerUIScId&&INS.uIShowShortCut.RegUIShowDic(this.registerUIScId,this.registerUIId)}UnRegUIShow(t){
null!=this.registerUIScId&&(INS.uIShowShortCut.UnRegUIShowDic(this.registerUIScId),null!=t&&t&&(this.registerUIScId=null))}UpdateAnchors(){const t=h.t.GetUIWidth()
h.t.GetUIHeight()
this.bg.widthSet(T.GF.INT((t-103)/1.15))}UpdateInfo(){const t=X.p.Inst_get().GetMapById(this.mapId)
1==this.mapState&&this.radarView.UpdatePointList(L.z.MapViewTreeMultipleExpPoint),this.UpdateChangeBtnState(),this.mapName.textSet(t.name),this.isLineClosing=!1,
this.lineList.SetActive(!1),this.HandleRightPanelShow(t),this.ShowGateInfo(),this.UpdateLineBtn(),w.b.Inst_get().InAsuramMap()&&this.btnPanel.SetActive(!1),this.UpdateCrossBoss()}
UpdateLineBtn(){let t=""
if(X.p.Inst_get().GetMapById(this.mapId).dynamicChannel||0!=E.a.Inst_get().currentCopyId?this.lineBtn.SetIsEnabled(!1):(et.F.getInst().CurLine_set(r.Y.Inst.PrimaryRoleInfo_get().CurLine_get()),
t+=et.F.getInst().CurLineShow_get()+(0,o.T)("线")),this.line.textSet(t),null!=this.mapId&&this.mapId>0){
X.p.Inst_get().GetMapById(this.mapId).maxChannelNum>1?this.lineBtn.SetActive(!0):this.lineBtn.SetActive(!1)}else this.lineBtn.SetActive(!0)}ChangeMap(){
const t=Q.X.inst.CurrentMapId_get()
this.mapId=t,this.isShowMapList=!1,this.radarView.ChangeMap(),Q.X.inst.CloseMonsterTip(),this.UpdateInfo()}HandleRightPanelShow(t){this.btnPanel.SetActive(!0),
this.rightPanel.SetActive(!1),V.I.calVec0.Set(0,0,0)}ShowGateInfo(){0==this.mapState?(this.gateRewardTip.SetActive(!1),
this.worldMapListObj.SetActive(!1)):1==this.mapState&&(this.isShowMapList?(this.worldMapListObj.SetActive(!0),this.msggrid.data_set(W.u.Inst().mapList),
this.worldMapList.ResetPosition()):this.worldMapListObj.SetActive(!1))}UpdateCrossBoss(){if(k.R.Inst_get().IsCrossBattle()){const t=U.x.Inst().getItemById(11043010)
this.tideDesc.textSet(t.sys_messsage),this.SetTideTimeTxt(),this.lineBtn.SetActive(!1),this.ryditu_bt_0030.SetActive(!1),this.worldMapListBtn.SetActive(!1),
this.mapName.node.SetLocalPositionXYZ(-29,15.8,0)}else{if(this.tide.SetActive(!1),this.ClearTideTime(),null!=this.mapId&&this.mapId>0){
X.p.Inst_get().GetMapById(this.mapId).maxChannelNum>1?this.lineBtn.SetActive(!0):this.lineBtn.SetActive(!1)}else this.lineBtn.SetActive(!1)
this.ryditu_bt_0030.SetActive(!0),this.worldMapListBtn.SetActive(!0)}}SetTideTimeTxt(){let t=N.I.Inst_get().GetDoubleTime()
this.tideTime=t[0],this.isDoubleTime=t[1],this.tide.SetActive(this.isDoubleTime),this.ClearTideTime(),
this.tideInterval=p.C.Inst_get().SetInterval(this.CreateDelegate(this.DoTideTimerInterval),1e3),this.DoTideTimerInterval()}DoTideTimerInterval(){
const t=this.tideTime-c.D.serverTime_get()
t>0?this.isDoubleTime?this.tideTimeLabel.textSet(`${G.l.GetDateFormatEX(t)}[FFFFFF]后结束[-]`):this.tideTimeLabel.textSet(`${G.l.GetDateFormatEX(t)}[FFFFFF]后开始[-]`):this.SetTideTimeTxt()
}ClearTideTime(){p.C.Inst_get().ClearInterval(this.tideInterval),this.tideInterval=-1}AddLis(){
et.F.getInst().AddEventHandler($.f.GetMapGoldMonster,this._degf_GetMapGoldMonsterHandler),this.m_handlerMgr.AddClickEvent(this.tree,this._degf_OnTreeItemChange),
et.F.getInst().AddEventHandler($.f.CloseSelectLine,this._degf_closeLinesHandler),m.i.Get(this.collider.node).RegistonClick(this._degf_onCloseLinesClick),
m.i.Get(this.lineBtn.node).RegistonClick(this._degf_onShowBtnClick),et.F.getInst().AddEventHandler($.f.LineChange,this._degf_UpdateInfo),
this.m_handlerMgr.AddClickEvent(this.worldMapListBtn,this.CreateDelegate(this.OnClick)),this.m_handlerMgr.AddClickEvent(this.gateRewardBtn,this.CreateDelegate(this.OnClick)),
this.m_handlerMgr.AddEventMgr(R.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors)),W.u.Inst().AddEventHandler(j.Z.UpdateMapPassInfo,this.CreateDelegate(this.ShowGateInfo)),
this.m_handlerMgr.AddClickEvent(this.gateBtn,this.CreateDelegate(this.OnClick)),this.m_handlerMgr.AddClickEvent(this.rightBtn,this.CreateDelegate(this.OnClick)),
this.m_handlerMgr.AddClickEvent(this.leftBtn,this.CreateDelegate(this.OnClick)),this.m_handlerMgr.AddClickEvent(this.tideBtn,this.CreateDelegate(this.OnClick)),
k.R.Inst_get().IsCrossBattle()&&this.m_handlerMgr.AddEventMgr(R.g.CROSS_BOSS_UPDATE,this.CreateDelegate(this.UpdateCrossBoss)),
et.F.getInst().AddEventHandler($.f.LineInfoUpdate,this.CreateDelegate(this.ShowLineList))}InitTree(){const t=new A.Z,e=new A.Z
this.treeTitle.Clear()
const s=F.j.GetInst().GetCfgById(this.mapId)
if(null!=s){let t=0
for(;t<s.GetListTagName().Count();){const e=s.GetListTagName()[t]
this.treeTitle.Add(e),t+=1}const i=et.F.getInst().GetRecommendMonsterId()
this.AddNpcNodeList(e),this.AddTransportNodeList(e),this.AddBossNodeList(e,i),this.AddEliteNodeList(e,i),this.AddGatherNodeList(e),this.AddMultipleExpNodeList(e),
e.Sort(this.SortList)}let i=null,n=0
if(null==this.treeTitle||0==this.treeTitle.Count())return void this.tree.SetData(t)
for(n=0,this.treeTitle.Sort(this.CreateDelegate(this.TitleSort));n<this.treeTitle.Count();)i=new d.t(0,this.treeTitle[n],"0",this.treeTitle[n],null),i.guideId=this.GetGuideId(n),
t.Add(i),n+=1
let l=0
for(;l<e.Count();)t.Add(e[l]),l+=1
null!=this.tree&&this.tree.SetData(t)}GetGuideId(t,e){if(0==t){if(null==e)return S.D.UI_MAP_BOSS_BTN}else if(1==t){if(null==e)return S.D.UI_MAP_GOLD_BTN
}else if(2==t);else if(3==t&&null==e)return S.D.UI_MAP_TRANFER_BTN
return null}TitleSort(t,e){const s=this.GetTitleSortIndex(t),i=this.GetTitleSortIndex(e)
return s<i?-1:s>i?1:0}DelayForceInitTree(){this.GetMapGoldMonsterHandler(null)}GetMapGoldMonsterHandler(t){
-1!=this.forceInitTreeInterval&&(p.C.Inst_get().ClearInterval(this.forceInitTreeInterval),this.forceInitTreeInterval=-1),this.InitTree(),
this.isHaveMultipleNode?(this.tree.SelectById(L.z.MapViewTreeMultipleExpPoint),Q.X.inst.IsSpecialOpen&&null!=Q.X.inst.SpecialTreeId&&(Q.X.inst.SpecialTreeId=null),
et.F.getInst().isOpenByMultipleHang&&this.tree.SelectById(L.z.MapViewTreeMultipleExpPoint)):this.isHaveBossNode?this.tree.SelectById(L.z.MapViewTreeBoss):this.tree.SelectById(L.z.MapViewTreeTransport)
}Activate(){}UpdateContainers(){}Deactivate(){this.ausramwarmappanel.Clear(),this.radarView.Clear(),this.RemoveLis(),this.msggrid.Clear(),this.isShowMapList=!1,
et.F.getInst().RaiseEvent($.f.CloseSelectLine),Q.X.inst.SmallMapCurrentViewTreeSelect="",-1!=this.closeLineInterval&&(p.C.Inst_get().ClearInterval(this.closeLineInterval),
this.closeLineInterval=-1),-1!=this.forceInitTreeInterval&&(p.C.Inst_get().ClearInterval(this.forceInitTreeInterval),this.forceInitTreeInterval=-1),
et.F.getInst().RaiseEvent($.f.CloseMonsterTip),this.UnRegUIShow()}Clear(){this.ClearTideTime(),this.grid.Clear(),this.msggrid.Clear(),this.Deactivate(),this.currSelectTreeTitle=""}
Destroy(){this.ClearTideTime(),this.titleSortArr=null}RemoveLis(){et.F.getInst().RemoveEventHandler($.f.GetMapGoldMonster,this._degf_GetMapGoldMonsterHandler),
this.m_handlerMgr.RemoveClickEvent(this.tree,this._degf_OnTreeItemChange),et.F.getInst().RemoveEventHandler($.f.CloseSelectLine,this._degf_closeLinesHandler),
m.i.Get(this.collider.node).RemoveonClick(this._degf_onCloseLinesClick),m.i.Get(this.lineBtn.node).RemoveonClick(this._degf_onShowBtnClick),
et.F.getInst().RemoveEventHandler($.f.LineChange,this._degf_UpdateInfo),et.F.getInst().RemoveEventHandler($.f.LineInfoUpdate,this.CreateDelegate(this.ShowLineList)),
this.m_handlerMgr.RemoveClickEvent(this.worldMapListBtn,this.CreateDelegate(this.OnClick)),this.m_handlerMgr.RemoveClickEvent(this.gateRewardBtn,this.CreateDelegate(this.OnClick)),
this.m_handlerMgr.RemoveClickEvent(this.gateBtn,this.CreateDelegate(this.OnClick)),this.m_handlerMgr.RemoveClickEvent(this.rightBtn,this.CreateDelegate(this.OnClick)),
this.m_handlerMgr.RemoveClickEvent(this.leftBtn,this.CreateDelegate(this.OnClick)),this.m_handlerMgr.RemoveClickEvent(this.tideBtn,this.CreateDelegate(this.OnClick)),
this.m_handlerMgr.RemoveEventMgr(R.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors)),
this.m_handlerMgr.RemoveEventMgr(R.g.CROSS_BOSS_UPDATE,this.CreateDelegate(this.UpdateCrossBoss)),
W.u.Inst().RemoveEventHandler(j.Z.UpdateMapPassInfo,this.CreateDelegate(this.ShowGateInfo))}AddTransportList(t){const e=this.mapId,s=F.j.GetInst().GetCfgById(e)
if(null==s)return _.Y.LogError((0,o.T)("SMALLMAPEx表里找不到")+e),!1
const i=s.GetTransNpcArr()
let n=null,l=0
for(;l<i.count;){const s=y.M.String2Int(i[l]),r=Y.f.Inst().getItemByIdRaw(s),h=a.a.getInst().getObjById(r.objectID)
if(null==r&&_.Y.LogError((0,o.T)("NPCRESOURCE 找不到NPC配置 id:")+s),null!=r){
const s=r.name,i=new A.Z([y.M.IntToString(Z.V.FIND_PATH),y.M.IntToString(z.d.TALK_VALUE),y.M.IntToString(e),y.M.IntToString(r.npcid)]),l=q.Y.JointStr(i)
n=new K,n.txt=s,n.linktxt=l
const o=new tt.p(0,h.name,L.z.MapViewTreeTransNPC,h.name)
o.cfgId=r.npcid,o.m_name=h.name,o.info=n,o.m_type=L.z.MapViewTreeTransNPC,o.m_level=`Lv.${h.level}`,t.Add(o)}l+=1}return i.count>0}AddNpcList(t){
const e=Q.X.inst.CurrentMapId_get(),s=F.j.GetInst().GetCfgById(e)
if(null==s)return _.Y.LogError((0,o.T)("SMALLMAPEx表里找不到")+e),!1
const i=s.GetNpcCoordArr()
let n=null,l=0
for(;l<i.count;){const s=y.M.String2Int(i[l]),a=Y.f.Inst().getItemByIdRaw(s)
null==a&&_.Y.LogError((0,o.T)("NPCRESOURCE 找不到NPC配置 id:")+s)
const h=r.Y.Inst.CheckNpcShowOrHide(a)
if(null!=a&&h){const s=a.name,i=new A.Z([y.M.IntToString(Z.V.FIND_PATH),y.M.IntToString(z.d.TALK_VALUE),y.M.IntToString(e),y.M.IntToString(a.npcid)]),l=q.Y.JointStr(i)
n=new K,n.txt=s,n.linktxt=l
const o=new tt.p(0,a.name,L.z.MapViewTreeNPC,a.name)
o.cfgId=a.npcid,o.m_name=a.name,o.info=n,o.m_type=L.z.MapViewTreeNPC,o.m_level="",t.Add(o)}l+=1}return i.count>0}AddMonsterList(t){
if(B.a.isInAllianceBossMap_get()&&!M.Q.Inst_get().bossModel.isBossOpen_get())return!1
const e=this.mapId,s=F.j.GetInst().GetCfgById(e)
if(null==s)return!1
const i=s.GetMonsterList()
if(null==i||0==i.count)return!1
const n=i.count
let l="",o="",r=null
const h=et.F.getInst().CurLine_get()
let d=null,c=0
for(;c<n;){if(null!=i[c]&&i[c].count>0){d=i[c]
const s=a.a.getInst().getObjById(y.M.String2Int(d[0]))
if(null!=s){const i=s.name,n=`Lv.${s.level}`
o=i,r=new K,r.txt=o,r.randomLinktxt=new A.Z
let a=1
for(;a<d.count;){const t=new A.Z([y.M.IntToString(Z.V.FIND_PATH),y.M.IntToString(z.d.KILL_MONSTER_VALUE),y.M.IntToString(e),y.M.IntToString(h),d[a]])
l=q.Y.JointStr(t),r.randomLinktxt[a-1]=l,a+=1}const c=new tt.p(0,r.txt,L.z.MapViewTreeMonster,r.txt)
c.cfgId=s.id,c.m_name=r.txt,c.info=r,c.m_type=L.z.MapViewTreeMonster,c.m_level=n,c.isSuggest=!1,t.Add(c)}}c+=1}return i.count>0}ConstructGoldMonster(t){
const e=et.F.getInst().GetMapGoldMonster(),s=e.Count()
let i="",n="",l=null,a=0
for(;a<s;){
const s=new A.Z([y.M.IntToString(Z.V.FIND_PATH),y.M.IntToString(z.d.MAP_TRANSPORTLINE_VALUE),y.M.IntToString(e[a].map),y.M.IntToString(e[a].line),y.M.FloatToString(e[a].x),y.M.FloatToString(e[a].y)])
i=q.Y.JointStr(s)
n=e[a].cfg.name,l=new K,l.txt=n,l.linktxt=i
const r=new tt.p(0,l.txt,L.z.MapViewTreeGoldMonster,l.txt)
r.cfgId=e[a].objCfg.id,r.m_name=l.txt,r.info=l,r.m_type=L.z.MapViewTreeGoldMonster,r.m_level=`Lv.${e[a].objCfg.level}`,
e[a].line!=et.F.getInst().CurLine_get()&&(r.m_name+=`(${e[a].line+(0,o.T)("线)")}`),r.isSuggest=!1,t.Add(r),a+=1}return s>0}closeLinesHandler(t){this.lineList.SetActive(!1)}
OnItemRefreshFun(t){return t[0].getCNode(Gt)}OnGridReposition(){const t=et.F.getInst().CurLineShow_get()
this.lineScrollView.ResetPosition(),t>0&&this.grid.itemList.Count()}OnWorldMapGridReposition(){const t=this.msggrid.itemList,e=t.Count()
for(let s=0;s<=e-1;s++)t[s].SetSelect(this.mapId)}OnClickWorldMapGrid(t,e,s){Q.X.inst.CurrentMapId_set(t.mapId),this.ChangeMap()}onShowBtnClick(t,e){
if(this.lineList.active)this.lineList.SetActive(!1)
else if(!this.isLineClosing){const t=this.mapId
X.p.Inst_get().GetMapById(t).dynamicChannel||0!=E.a.Inst_get().currentCopyId||(Q.X.inst.getMapLines(),this.isClickLineBtn=!0)}}onCloseLinesClick(t,e){
this.lineList.active&&(this.lineList.SetActive(!1),et.F.getInst().RaiseEvent($.f.CloseSelectLine),this.isLineClosing=!0,
this.closeLineInterval=p.C.Inst_get().SetInterval(this._degf_CloseLine,100,1))}CloseLine(){this.isLineClosing=!1,this.closeLineInterval=-1}ShowLineList(){if(this.isClickLineBtn){
const t=et.F.getInst().lineList
let e=t.Count()
e>7&&(e=7),e>1&&(this.lineList.SetActive(!0),this.linePanel.view.height=45*e+6,this.linePanel.clipOffsetSet(new v.F(0,0)),
this.linePanel.node.SetLocalPositionXYZ(-32.2,-211+T.GF.INT(45*e/2),0),this.grid.data_set(t),this.listBg.heightSet(45*e)),
7==e?this.lineBack.SetActive(!0):this.lineBack.SetActive(!1),this.isClickLineBtn=!1}this.UpdateLineBtn()}AddNpcNodeList(t){let e=new A.Z
const s=this.mapId,i=F.j.GetInst().GetCfgById(s)
null==i&&_.Y.LogError((0,o.T)("SMALLMAPEx表里找不到")+s),e=i.GetListNPCId()
let n=null,l=0
for(;l<e.Count();){const a=Y.f.Inst().getItemByIdRaw(e[l])
if(null==a)_.Y.LogError(u.o.Format((0,o.T)("smallmap地图id={0}中配置的npcid={1}在npcresource.csv 表中不存在"),i.mapId,e[l]))
else{const e=r.Y.Inst.CheckNpcShowOrHide(a)
if(null!=a&&e){const e=a.name,i=new A.Z([y.M.IntToString(Z.V.FIND_PATH),y.M.IntToString(z.d.TALK_VALUE),y.M.IntToString(s),y.M.IntToString(a.npcid)]),l=q.Y.JointStr(i)
n=new K,n.txt=e,n.linktxt=l
const o=new tt.p(0,a.name,L.z.MapViewTreeNPC,a.name)
o.cfgId=a.npcid,o.m_name=a.name,o.info=n,o.m_type=L.z.MapViewTreeNPC,o.m_level="",t.Add(o)}}l+=1}}AddTransportNodeList(t){let e=new A.Z
const s=this.mapId,i=F.j.GetInst().GetCfgById(s)
null==i&&_.Y.LogError((0,o.T)("SMALLMAPEx表里找不到")+s),e=i.GetListTransId()
let n=0
for(;n<e.Count();){const s=X.p.Inst_get().GetItemById(e[n])
if(null!=s){const e=new K
e.randomLinktxt=new A.Z([y.M.FloatToString(s.belongPosX),"0",y.M.FloatToString(s.belongPosY)])
const i=new tt.p(0,s.name,L.z.MapViewTreeTransport,s.name)
i.cfgId=s.id,i.m_name=s.name,i.info=e,i.m_type=L.z.MapViewTreeTransport,i.m_level="",t.Add(i)}n+=1}}AddMonsterNodeList(t,e){
if(B.a.isInAllianceBossMap_get()&&!M.Q.Inst_get().bossModel.isBossOpen_get())return
const s=this.mapId,i=F.j.GetInst().GetCfgById(s)
if(null==i)return
const n=i.GetArrMonster()
if(null==n||0==n.count)return
let l=0
for(;l<n.count;){const i=n[l]
if(null!=i&&i.count>2){const o=n[l][1],r=a.a.getInst().getObjById(o)
if(null!=r){const n=new K
n.txt=r.name,n.randomLinktxt=new A.Z
let l=2
for(;l<i.count;){
const t=new A.Z([y.M.IntToString(Z.V.FIND_PATH),y.M.IntToString(z.d.KILL_MONSTER_VALUE),y.M.IntToString(s),y.M.IntToString(et.F.getInst().CurLine_get()),y.M.IntToString(i[l])])
n.randomLinktxt[l-2]=q.Y.JointStr(t),l+=1}const o=new tt.p(0,n.txt,L.z.MapViewTreeMonster,n.txt)
if(o.cfgId=r.id,o.m_name=n.txt,o.info=n,o.m_type=L.z.MapViewTreeMonster,1==i[0]){const t=this.GetBossLevel(s,r.id);-1!=t&&(o.m_level=`Lv.${y.M.IntToString(t)}`,o.m_objLevel=t)
}else o.m_level=`Lv.${y.M.IntToString(r.level)}`,o.m_objLevel=r.level
o.isSuggest=0!=e&&o.cfgId==e,t.Add(o)}}l+=1}}AddBossNodeList(t,e){this.isHaveBossNode=!1
const s=this.mapId,i=F.j.GetInst().GetCfgById(this.mapId)
for(const[e,n]of(0,l.vy)(i.GetDicBoss())){const n=a.a.getInst().getObjById(e)
if(null!=n){const l=i.GetDicBoss()[e],o=l.playertransport
if(o.count>0){const e=new K
e.txt=n.name,e.randomLinktxt=new A.Z
const i=new A.Z([y.M.IntToString(Z.V.FIND_PATH),y.M.IntToString(z.d.KILL_MONSTER_VALUE),y.M.IntToString(s),y.M.IntToString(et.F.getInst().CurLine_get()),o[0]])
e.linktxt=q.Y.JointStr(i)
const a=new tt.p(0,e.txt,l.type,e.txt)
if(a.cfgId=n.id,a.m_name=e.txt,a.info=e,a.m_type=l.type,1==l.flag){const t=this.GetBossLevel(s,n.id);-1!=t&&(a.m_level=`Lv.${y.M.IntToString(t)}`,a.m_objLevel=t)
}else a.m_level=`Lv.${y.M.IntToString(n.level)}`,a.m_objLevel=n.level
a.isSuggest=!1,t.Add(a),this.isHaveBossNode=!0}}}}AddEliteNodeList(t,e){const s=this.mapId,i=F.j.GetInst().GetCfgById(s)
if(null==i)return
const n=i.GetArrElite()
if(null==n||0==n.count)return
let l=0
for(;l<n.count;){const e=n[l]
if(null!=e&&e.count>2){const i=n[l][1],o=a.a.getInst().getObjById(i)
if(null!=o){const i=new K
i.txt=o.name,i.randomLinktxt=new A.Z
let n=2
for(;n<e.count;){
const t=new A.Z([y.M.IntToString(Z.V.FIND_PATH),y.M.IntToString(z.d.KILL_MONSTER_VALUE),y.M.IntToString(s),y.M.IntToString(et.F.getInst().CurLine_get()),y.M.IntToString(e[n])])
i.randomLinktxt[n-2]=q.Y.JointStr(t),n+=1}const l=new tt.p(0,i.txt,L.z.MapViewTreeElite,i.txt)
if(l.cfgId=o.id,l.m_name=i.txt,l.info=i,l.m_type=L.z.MapViewTreeElite,1==e[0]){const t=this.GetBossLevel(s,o.id);-1!=t&&(l.m_level=`Lv.${y.M.IntToString(t)}`,l.m_objLevel=t)
}else l.m_level=`Lv.${y.M.IntToString(o.level)}`,l.m_objLevel=o.level
l.isSuggest=!1,t.Add(l)}}l+=1}}GetBossLevel(t,e){return-1}GetTitleSortIndex(t){return this.titleSortArr.IndexOf(t)}AddGatherNodeList(t){let e=new A.Z
const s=this.mapId,i=F.j.GetInst().GetCfgById(s)
null==i&&_.Y.LogError((0,o.T)("SMALLMAPEx表里找不到")+s),e=i.GetListGatherId()
let n=0
for(;n<e.Count();){const s=O.J.Inst().getItemById(e[n])
if(null!=s){const e=new K
e.randomLinktxt=new A.Z([y.M.FloatToString(s.x),"0",y.M.FloatToString(s.y)])
const i=new tt.p(0,s.name,L.z.MapViewTreeTransport,s.name)
i.cfgId=s.id,i.m_name=s.name,i.info=e,i.m_type=L.z.MapViewTreeTransport,i.m_level="",t.Add(i)}n+=1}}AddMultipleExpNodeList(t){if(this.isHaveMultipleNode=!1,
B.a.isInAllianceBossMap_get()&&!M.Q.Inst_get().bossModel.isBossOpen_get())return
const e=this.mapId,s=F.j.GetInst().GetCfgById(e)
if(null==s)return
const i=s.GetArrMultipleExp()
if(null==i||0==i.count)return
const n=et.F.getInst().GetRecommendMonsterId()
let l=0
for(;l<i.count;){const t=i[l]
if(null!=t&&t.count>2){const s=i[l][1],o=a.a.getInst().getObjById(s)
if(null!=o){const s=new K
s.txt=`${o.name} `,s.randomLinktxt=new A.Z
let i=2
for(;i<t.count;){
const n=new A.Z([y.M.IntToString(Z.V.FIND_PATH),y.M.IntToString(z.d.KILL_MONSTER_VALUE),y.M.IntToString(e),y.M.IntToString(et.F.getInst().CurLine_get()),y.M.IntToString(t[i])])
s.randomLinktxt[i-2]=q.Y.JointStr(n),i+=1}const l=new tt.p(0,s.txt,L.z.MapViewTreeMultipleExpPoint,s.txt)
if(l.cfgId=o.id,l.m_name=s.txt,l.guideId=S.D.UI_MAP_GLOD_ITEM,l.guideParam=o.id,l.info=s,l.m_type=L.z.MapViewTreeMultipleExpPoint,1==t[0]){const t=this.GetBossLevel(e,o.id)
;-1!=t&&(l.m_level=`Lv.${y.M.IntToString(t)}`,l.m_objLevel=t)}else l.m_level=`Lv.${y.M.IntToString(o.level)}`,l.m_objLevel=o.level
return et.F.getInst().IsSuitMonsterId(o.id)||(l.difficulty=3),l.isSuggest=0!=n&&l.cfgId==n,void(this.isHaveMultipleNode=!1)}}l+=1}}OnClick(t){if(t.target==this.gateRewardBtn.node){
const t=W.u.Inst().GetMapPassProgressVoByMapId(this.mapId),e=t.GetNearRewardLevelCanGet(1)
if(null!=e){const t=W.u.Inst().GetMapPassVoByMapAndLevel(this.mapId,e)
H.N.Inst().CM_RewardMapPassHandle(t.id)}else{const e=t.GetNearRewardLevelCanGet(2)
if(null!=e){const t=W.u.Inst().GetMapPassVoByMapAndLevel(this.mapId,e)
H.N.Inst().OpenMapPassRewardTips(t.id)}}}else if(t.target==this.worldMapListBtn.node)1==this.mapState&&(this.isShowMapList=!this.isShowMapList,this.UpdateInfo())
else if(t.target==this.gateBtn)this.mapState=1,this.radarView.SetShowState(!0,!0),this.UpdateInfo()
else if(t.target==this.leftBtn){const t=X.p.Inst_get().GetLastMap(this.mapId)
0!=t&&(Q.X.inst.CurrentMapId_set(t),this.ChangeMap())}else if(t.target==this.rightBtn){const t=X.p.Inst_get().GetNextMap(this.mapId)
0!=t&&(Q.X.inst.CurrentMapId_set(t),this.ChangeMap())}else if(t.target==this.tideBtn.node){const t=new b.w
t.position=new D.P(-446.3,256.9,0),t.width=450,t.infoId="CROSSBATTLE:TIPS2",P.Q.Inst_get().Open(t)}}UpdateChangeBtnState(){X.p.Inst_get().GetCanEnterMapMap()
const t=X.p.Inst_get().GetNextMap(this.mapId),e=X.p.Inst_get().GetLastMap(this.mapId)
0!=t&&et.F.getInst().GetCanEnterMapByLvAndTransfer(t)==J.f.CAN?this.rightBtn.SetActive(!0):this.rightBtn.SetActive(!1),0!=e?this.leftBtn.SetActive(!0):this.leftBtn.SetActive(!1)}
SortList(t,e){
return null!=t.m_objLevel&&null!=e.m_objLevel?t.m_objLevel<e.m_objLevel?-1:t.m_objLevel>e.m_objLevel?1:t.cfgId<e.cfgId?-1:t.cfgId>e.cfgId?1:0:null!=t.cfgId&&null!=e.cfgId?t.cfgId<e.cfgId?-1:t.cfgId>e.cfgId?1:0:0
}}).NoShowRightPanel=new A.Z(["ASURAM_WAR_1","ASURAM_WAR_2"]),bt=Ot))},16315:(t,e,s)=>{s.d(e,{q:()=>u})
var i=s(83908),n=s(98800),l=s(97461),o=s(28192),a=s(98885),r=s(92679),h=s(33314),d=s(21267),c=s(98504),I=s(62783)
class u extends((0,i.yk)()){constructor(...t){super(...t),this._m_handlerMgr=null,this.transVo=null,this.pos=null,this.isradar=null,this.spawnId=null,this.id=null,
this.isShowLv=null}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=o.h.Get()),this._m_handlerMgr}InitView(){}Clear(){this.RemoveLis()}Destroy(){}SetData(t,e){
this.RemoveLis(),this.AddLis(),this.pos=null,this.isradar=e,this.boxCollider.SetIsEnabled(!0)
I.X.inst.CurrentMapId_get()
this.transVo=t,this.spawnId=t.spawnId
const s=d.u.Inst().GetResBySpawnId(this.spawnId)
if(s){const t=d.u.Inst().GetMapPassVo(s.id)
this.id=t.id,this.UpdateView()}}AddLis(){this.m_handlerMgr.AddClickEvent(this.header_icon,this.CreateDelegate(this.OnClickIcon))}RemoveLis(){
this.m_handlerMgr.RemoveClickEvent(this.header_icon,this.CreateDelegate(this.OnClickIcon))}OnClickIcon(){l.i.Inst.RaiseEvent(r.g.SMALL_MAP_CLICK_MONSTER,this.transVo)}
HideNameandClick(t){t?(this.RemoveLis(),this.text_lv.node.SetActive(!1),this.text_bg.node.SetActive(!1),this.nowGateRolePos.SetActive(!1)):(this.RemoveLis(),this.AddLis(),
this.isShowLv&&(this.text_lv.node.SetActive(!0),this.text_bg.node.SetActive(!0)),this.boxCollider.SetIsEnabled(!0))}UpdateView(){const t=d.u.Inst().GetResBySpawnId(this.spawnId)
this.text_name.textSet(t.name),this.UpdateState()
const e=d.u.Inst().nowFightVo
if(null!=e&&e.res.spawnId==this.spawnId){let t=""
const e=n.Y.Inst.PrimaryRoleInfo_get().Job_get(),s=n.Y.Inst.PrimaryRoleInfo_get().Sex_get()
t=a.M.Replace(h.Z.GetMainUIJobIcon(e,s),"mbcommon","ditu"),this.gateRoleHead.spriteNameSet(t),this.nowGateRolePos.SetActive(!0),this.scheduleOnce((()=>{
this.node.parent.insertChild(this.node,this.node.parent.children.length-1)}))}else this.nowGateRolePos.SetActive(!1)
this.HideNameandClick(this.isradar)}UpdateState(){const t=d.u.Inst().GetResBySpawnId(this.spawnId),e=d.u.Inst().GetMapPassVo(t.id)
e.state==c.s.LOCK?this.header_icon.spriteNameSet("ryditu_sp_0040"):e.state==c.s.PASS?this.header_icon.spriteNameSet("ryditu_sp_0039"):e.state==c.s.FIGHT&&this.header_icon.spriteNameSet("ryditu_sp_0038")
const s=d.u.Inst().GetHighestGateByMap(t.mapId)
let i=0
null!=s&&(i=s.res.checkpoint),this.isShowLv=!this.isradar&&(i==t.checkpoint-1||i==t.checkpoint),this.isShowLv?(this.text_lv.node.SetActive(!0),this.text_bg.node.SetActive(!0),
n.Y.Inst.PrimaryRoleInfo_get().Level_get()>=t.unlockLevel?this.text_lv.textSet(`[E6DFD8]Lv.${t.unlockLevel}[-]`):this.text_lv.textSet(`[962424]Lv.${t.unlockLevel}[-]`)):(this.text_lv.node.SetActive(!1),
this.text_bg.node.SetActive(!1))}}},85986:(t,e,s)=>{s.d(e,{B:()=>B})
var i,n=s(6847),l=s(83908),o=s(17409),a=s(49655),r=s(46282),h=s(86133),d=s(5583),c=s(23833),I=s(96098),u=s(36241),p=s(13687),_=s(5494),g=s(98130),m=s(79534),S=s(75696),f=s(87923),C=s(7708),T=s(55552),y=s(21267),A=s(43308),v=s(62783),D=s(97943),w=s(12970)
let B=(0,n.s_)(a.o.eMapGateTip,r.Z.ui_topsmallmap_gate_info_tip).layerTip().waitPrefab(S.j.CompListPath).register()(i=class extends((0,l.Ri)()){constructor(...t){super(...t),
this.monsterVo=null,this.transVo=null,this.show_pos=null,this.mapPassVo=null,this.boss=null,this.interval=null}InitView(){this.grid_item.SetInitInfo("ui_baseitem",null,S.j),
this.monsterVo=null,this.transVo=null,this.show_pos=m.P.New(),this.mapPassVo=null,this.boss=null,this.interval=-1}OnAddToScene(){this.AddLis()
const t=v.X.inst.CurrentMapId_get(),e=C.j.GetInst().GetCfgById(t)
this.transVo=v.X.inst.monsterTipTransVo,this.monsterVo=c.a.getInst().getObjById(e.GetMonsterIdByTransId(this.transVo.id)),
this.mapPassVo=y.u.Inst().GetMapPassVoBySpawnId(this.transVo.spawnId),this.show_pos=v.X.inst.monsterTipPos,this.node.transform.SetLocalPosition(this.show_pos),this.UpdateTip()}
UpdateTip(){const t=this.mapPassVo.res
this.text_name.textSet(`${t.mapName}·${t.name}`),this.levelLabel.textSet(`LV.${t.unlockLevel}`),this.text_exp.textSet(f.l.GetRuleDecimalVal(t.ExpRate)+(0,h.T)("/分"))
const e=y.u.Inst().nowFightVo
this.mapPassVo.hasServer||1==this.mapPassVo.CanChallengeBoss()?(this.btn_go.node.SetActive(!0),this.btn_go.SetText("立即前往"),
this.cantGoTips.node.SetActive(!1)):(this.btn_go.node.SetActive(!1),this.cantGoTips.node.SetActive(!0),this.cantGoTips.textSet("挑战条件未达成"),this.text_expUp.node.SetActive(!1))
let s=0
null!=e&&(s=g.GF.INT(t.ExpRate/e.res.ExpRate*100)/100),s>1?(this.text_exp.node.SetLocalPositionXYZ(-101,-13,0),this.text_expUp.textSet((100*(s-1)).toFixed(0)+"%"),
this.text_expUp.node.SetActive(!0)):(this.text_exp.node.SetLocalPositionXYZ(-this.text_exp.width()/2,-13,0),this.text_expUp.node.SetActive(!1)),
f.l.DealRyMonIcon(this.monsterVo.headResources,this.monsterHead,this.monsterHeadry)
const i=d.L.GetRewardValuesConfig(t.hangReward)
if(null!=i){const t=i.GetItemList()
this.grid_item.data_set(t)}}AddLis(){this.m_handlerMgr.AddClickEvent(this.btn_go,this.CreateDelegate(this.OnClickBtnGo)),
this.m_handlerMgr.AddClickEvent(this.btnClose,this.CreateDelegate(this.OnClickBtnClose)),w.F.getInst().AddEventHandler(D.f.CloseMonsterTip,this.CreateDelegate(this.CloseTip))}
RemoveLis(){this.m_handlerMgr.RemoveClickEvent(this.btn_go,this.CreateDelegate(this.OnClickBtnGo)),
this.m_handlerMgr.RemoveClickEvent(this.btnClose,this.CreateDelegate(this.OnClickBtnClose)),w.F.getInst().RemoveEventHandler(D.f.CloseMonsterTip,this.CreateDelegate(this.CloseTip))
}Clear(){this.RemoveLis(),this.grid_item.Clear(),super.Clear()}OnClickBtnClose(){this.CloseTip()}OnClickBtnGo(){u._.getInst().endHang(),
1==this.mapPassVo.CanChallengeBoss()?I.B.Inst.CM_FlyShoesTransportHandle(this.mapPassVo.res.flyId,null,null,!1):(this.transVo.targetMapId,p.b.Inst.currentMapId_get(),
I.B.Inst.CM_FlyShoesTransportHandle(this.transVo.id,null,null,!0)),v.X.inst.CloseMapPanel()}FindPath(){
w.F.getInst().isOpenByMultipleHang&&1==T.h.inst.GetSpwanItemById(this.transVo.spawnId).goldPoint?A._.Inst_get().OnGoGuaji(this.transVo,v.X.inst.AutoOpenMultipleHang):A._.Inst_get().OnGoGuaji(this.transVo)
}CloseTip(){(0,o.sR)(_.I.eMapGateTip)}})||i},9537:(t,e,s)=>{s.d(e,{m:()=>_})
var i=s(23833),n=s(97461),l=s(43133),o=s(99294),a=s(93877),r=s(72005),h=s(30849),d=s(85602),c=s(79534),I=s(92679),u=s(7708),p=s(62783)
class _ extends h.C{constructor(...t){super(...t),this.monsterVo=null,this.transVo=null,this.star_list=null,this.con_icon=null,this.con_bottom=null,this.img_pk=null,
this.text_name=null,this.img_star_0=null,this.img_star_1=null,this.img_star_2=null,this.img_star_3=null,this.img_star_4=null,this.img_icon=null,this.indicate=null,
this.boxCollider=null}InitView(){super.InitView(),this.con_icon=this.CreateComponent(o.z,1),this.con_bottom=this.CreateComponent(o.z,2),this.img_pk=this.CreateComponent(r.w,7),
this.text_name=this.CreateComponent(a.Q,8),this.img_star_0=this.CreateComponent(r.w,9),this.img_star_1=this.CreateComponent(r.w,10),this.img_star_2=this.CreateComponent(r.w,11),
this.img_star_3=this.CreateComponent(r.w,12),this.img_star_4=this.CreateComponent(r.w,13),this.img_icon=this.CreateComponent(r.w,14),this.indicate=this.CreateComponent(o.z,18),
this.boxCollider=this.CreateComponent(l.V,19),this.star_list=new d.Z([this.img_star_0,this.img_star_1,this.img_star_2,this.img_star_3,this.img_star_4]),this.InitHandlerMgr(),
this.SetIndicate(!1)}SetData(t){this.AddLis(),this.boxCollider.SetEnabled(!0)
const e=p.X.inst.CurrentMapId_get(),s=u.j.GetInst().GetCfgById(e)
this.transVo=t,this.monsterVo=i.a.getInst().getObjById(s.GetMonsterIdByTransId(this.transVo.id)),this.con_icon.SetActive(!0),this.con_bottom.SetActive(!0),this.UpdateItem()}
HideNameandClick(t){this.text_name.node.SetActive(!t),t?(this.RemoveLis(),this.boxCollider.SetEnabled(!1)):(this.AddLis(),this.boxCollider.SetEnabled(!0))}SetSpawnData(t,e,s){
const n=i.a.inst.getObjById(t.objectKey)
if(null!=n){const t=Math.ceil(e.ToNum()/s.ToNum()*1e4)/100
this.text_name.textSet(`${n.name}${t}%`),this.boxCollider.SetEnabled(!1),this.con_bottom.SetActive(!0),this.con_icon.SetActive(!0)}}AddLis(){
this.m_handlerMgr.AddClickEvent(this.img_icon,this.CreateDelegate(this.OnClickIcon))}RemoveLis(){
this.m_handlerMgr.RemoveClickEvent(this.img_icon,this.CreateDelegate(this.OnClickIcon))}UpdateItem(){this.con_icon.transform.SetLocalScale(new c.P(1,1,1)),
this.text_name.textSet(`${this.monsterVo.name}lv.${this.monsterVo.level}`)}SetIndicate(t){null!=this.indicate&&this.indicate.SetActive(t)}OnClickIcon(){
n.i.Inst.RaiseEvent(I.g.SMALL_MAP_CLICK_MONSTER,this.transVo)}Clear(){super.Clear(),this.RemoveLis()}Destroy(){super.Destroy()}}_.STAGE_ID=115},94801:(t,e,s)=>{
var i,n=s(18998),l=s(83908),o=s(98800),a=s(11895),r=s(13687),h=s(41664),d=s(5924),c=s(57834),I=s(85682),u=s(5494),p=s(28192),_=s(60130),g=s(35128),m=s(98130),S=s(98885),f=s(85602),C=s(44758),T=s(92679),y=s(33314),A=s(85770),v=s(48933),D=s(21267),w=s(21334),B=s(62783),M=s(12970),b=s(38045),O=s(97461),R=s(99294),L=s(9986),G=s(9057),P=s(93877),E=s(37151)
class k extends G.x{constructor(){super(),this.m_map=null,this.levelLabel=null,this.btn=null,this.lockSp=null,this.infoObj=null,this.highlight=null,this.m_data=null,
this._degf_ClickHandler=null,this.GuideEff=null,this._degf_ClickHandler=(t,e)=>this.ClickHandler(t,e)}InitView(){super.InitView(),this.m_map=new P.Q,
this.m_map.setId(this.FatherId,this.FatherComponentID,1),this.levelLabel=new P.Q,this.levelLabel.setId(this.FatherId,this.FatherComponentID,2),this.btn=new L.W,
this.btn.setId(this.FatherId,this.FatherComponentID,3),this.lockSp=new R.z,this.lockSp.setId(this.FatherId,this.FatherComponentID,4),this.infoObj=new R.z,
this.infoObj.setId(this.FatherId,this.FatherComponentID,5),this.highlight=new R.z,this.highlight.setId(this.FatherId,this.FatherComponentID,6),
this.GuideEff=this.CreateComponent(R.z,7),this.GuideEff.SetActive(!1)}Destroy(){this.m_map=null,this.levelLabel=null,this.btn=null,this.lockSp=null,this.infoObj=null,
this.highlight=null}SetData(t){if(this.m_data=t,this.AddListeners(),null!=this.m_data){const t=!S.M.IsNullOrEmpty(this.m_data.mapName)
if(t){this.m_map.textSet(this.m_data.mapName)
const t=E.Q.model.GetMasterStartLevel()
this.m_data.minLevelLimit>t?this.levelLabel.textSet(`    ${(0,b.tw)(this.m_data.minLevelLimit-t)}`):this.levelLabel.textSet(`LV.${this.m_data.minLevelLimit}`)
const e=M.F.getInst().ExistOpenMap(this.m_data.mapId,!0)
this.lockSp.SetActive(!e)}this.infoObj.SetActive(t),B.X.inst.IsSpecialOpen?this.highlight.SetActive(!1):this.highlight.SetActive(this.m_data.mapId==r.b.Inst.GetCurMap().id),
this.GuideEff.SetActive(this.m_data.NeedGuide)}}Clear(){this.m_data=null,this.RemoveListeners()}AddListeners(){c.i.Get(this.btn.node).RegistonClick(this._degf_ClickHandler)}
RemoveListeners(){c.i.Get(this.btn.node).RemoveonClick(this._degf_ClickHandler)}ClickHandler(t,e){
this.m_data.NeedGuide?B.X.inst.NeedOpenMapAfterEnterMap_Set(!0):B.X.inst.NeedOpenMapAfterEnterMap_Set(!1),O.i.Inst.RaiseEvent(T.g.CHANGE_MAP),B.X.inst.SetWorldMenuActive(!1),
B.X.inst.JudgeCanEnterMapHandler(this.m_data.mapId)}}const{ccclass:N,property:V}=n._decorator
N("SmallMapWorldView")(i=class extends((0,l.yk)()){constructor(...t){super(...t),this._m_handlerMgr=null,this.items=null,this.interval=-1,this.unlockInterval=-1,
this.startCloudEffectInterval=-1,this.startCloudBgInterval=-1,this.delayCloudEffectInterval=-1,this.delayCloudBgInterval=-1,this.guideInterval=-1,this.cloudEffectAlpha=1,
this.cloudBgAlpha=1,this.dragIndex=0,this.textureWidth=1182,this._degf_ClearCloudBg=null,this._degf_ClearCloudEffect=null,this._degf_DelayClearCloudBg=null,
this._degf_DelayClearCloudEffect=null,this._degf_DelaySetHeadPanel=null,this._degf_OnItemRefreshFun=null,this._degf_OnMenuCloseHandler=null,this._degf_SortMapIds=null,
this._degf_UnlockMapEffect=null,this.registerUIScId=null,this.registerUIId=null}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=p.h.Get()),this._m_handlerMgr}
_initBinder(){super._initBinder(),this.items=new f.Z,this._degf_ClearCloudBg=(t,e)=>this.ClearCloudBg(t,e),this._degf_ClearCloudEffect=(t,e)=>this.ClearCloudEffect(t,e),
this._degf_DelayClearCloudBg=(t,e)=>this.DelayClearCloudBg(t,e),this._degf_DelayClearCloudEffect=(t,e)=>this.DelayClearCloudEffect(t,e),
this._degf_DelaySetHeadPanel=()=>this.DelaySetHeadPanel(),this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),this._degf_OnMenuCloseHandler=(t,e)=>this.OnMenuCloseHandler(t,e),
this._degf_SortMapIds=(t,e)=>this.SortMapIds(t,e),this._degf_UnlockMapEffect=(t,e)=>this.UnlockMapEffect(t,e)}InitView(){this.items.Add(this.item1),this.items.Add(this.item2),
this.items.Add(this.item3),this.items.Add(this.item4),this.items.Add(this.item5),this.items.Add(this.item6),this.items.Add(this.item7),this.items.Add(this.item8),
this.items.Add(this.item9),this.items.Add(this.item10),this.items.Add(this.item11),this.items.Add(this.item12),this.subMapList.SetActive(!1),
this.grid.SetInitInfo("ui_topsmallmap_worldmapsubitem",this._degf_OnItemRefreshFun),this.items.Add(this.item_13),this.items.Add(this.item_14),this.items.Add(this.item_15),
this.items.Add(this.item_roland),this.UpdateAnchors()}Destroy(){this.items.Clear()}OnAddToScene(){this.AddOrDelEvents(!0),this.SetCurrentJob(),this.SetMapId(),this.LocatePos()
let t=0
for(;t<this.items.Count();)this.items[t].OnAddToScene(),t+=1
this.UnlockMap(),this.SetDrag(),this.RegUIShow()}RegUIShow(){this.registerUIScId=I.D.WordMap,this.registerUIId=u.I.eMap,
null!=this.registerUIScId&&INS.uIShowShortCut.RegUIShowDic(this.registerUIScId,this.registerUIId)}UnRegUIShow(t){
null!=this.registerUIScId&&(INS.uIShowShortCut.UnRegUIShowDic(this.registerUIScId),null!=t&&t&&(this.registerUIScId=null))}UnlockMap(){}SortMapIds(t,e){
const s=w.p.Inst_get().GetMapById(t),i=w.p.Inst_get().GetMapById(e)
return s.minLevelLimit<i.minLevelLimit?1:s.minLevelLimit>i.minLevelLimit?-1:0}SendUnlockMapIds(t){const e=M.F.getInst().unplayUnlockEffectMaps
let s=""
if(null!=e&&e.Count()>0){if(0!=t){let i=!1,n=0
for(;n<e.Count();){if(e[n]==t){i=!0
break}n+=1}i||(e.Add(t),s+=` ${t}`)}B.X.inst.ReqPlayUnlockEffect(e),M.F.getInst().unplayUnlockEffectMaps=null}}UpdateWorldMapItem(t){let e=0
for(;e<this.items.Count();)this.items[e].MapId_get()==t&&this.items[e].UpdateView(),e+=1}UpdateAsuramStatus(){}SetCurrentJob(){
const t=o.Y.Inst.PrimaryRoleInfo_get().Job_get(),e=o.Y.Inst.PrimaryRoleInfo_get().Sex_get()
let s=""
s=S.M.Replace(y.Z.GetMainUIJobIcon(t,e),"mbcommon","ditu"),this.job.spriteNameSet(s)}Clear(){this.UnRegUIShow(),this.ClearInterval(),this.AddOrDelEvents(!1),
this.subMapList.SetActive(!1),M.F.getInst().OpenEffMapId=null
let t=0
for(;t<this.items.Count();)this.items[t].Clear(),t+=1
0!=this.dragIndex&&(a.L.Inst.UnregDrag(this.dragIndex),this.dragIndex=0),this.worldDragPointer.SetActive(!1)}AddOrDelEvents(t){
t?(c.i.Get(this.menuCloseBtn.node).RegistonClick(this._degf_OnMenuCloseHandler),c.i.Get(this.menuCollider.node).RegistonClick(this._degf_OnMenuCloseHandler),
c.i.Get(this.menuCollider.node).RegistonDragStart(this._degf_OnMenuCloseHandler),
this.m_handlerMgr.AddEventMgr(T.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors))):(c.i.Get(this.menuCloseBtn.node).RemoveonClick(this._degf_OnMenuCloseHandler),
c.i.Get(this.menuCollider.node).RemoveonClick(this._degf_OnMenuCloseHandler),c.i.Get(this.menuCollider.node).RemoveonDragStart(this._degf_OnMenuCloseHandler),
this.m_handlerMgr.RemoveEventMgr(T.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors)))}OnMenuCloseHandler(t,e){this.SetMenuActive(!1)}SetMapId(){r.b.Inst.currentMapId_get()
this.item1.MapId_set(10018),this.item2.MapId_set(10017),this.item3.MapId_set(10016),this.item4.MapId_set(10015),this.item5.MapId_set(10019),this.item6.MapId_set(10001),
this.item7.MapId_set(10003),this.item8.MapId_set(10002),this.item9.MapId_set(10006),this.item10.MapId_set(10014),this.item11.MapId_set(10013),this.item12.MapId_set(10025),
this.item_15.MapId_set(10020),this.item_roland.MapId_set(20048)}LocatePos(){d.C.Inst_get().ClearInterval(this.interval),this.selfPos.SetActive(!1)
let t=r.b.Inst.currentMapId_get()
if(t=D.u.Inst().GetMaxPassMapId(),0==A.a.Inst_get().curCopyType){
const e=this.GetWorldMapItem(t),s=!(B.X.inst.IsSpecialOpen||0!=B.X.inst.DefaultOpenMapId||null!=M.F.getInst().OpenEffMapId&&0!=M.F.getInst().OpenEffMapId)
null!=e&&s&&(this.selfPos.SetActive(!0),this.selfPos.setParent(e.headPos.node),this.interval=d.C.Inst_get().SetFrameLoop(this._degf_DelaySetHeadPanel,1,1))}}DelaySetHeadPanel(){
this.headPanel.SetActive(!1),this.headPanel.SetActive(!0)}SetMenuActive(t){this.subMapList.SetActive(t)}UpdateAnchors(){
const t=n.sys.getSafeAreaRect(),e=n.view.getVisibleSize().x,s=g.p.CeilToInt(720*e/1280)
this.bg.heightSet(s),this.bg.widthSet(e),v.I.calVec5.Set(-t.x/2,-s/2,0),this.bg.node.setPosition(v.I.calVec5),_.O.SetAnchorPos(this.mapBtnPanel,!1,!1,0,!1),
_.O.SetAnchorPos(this.rightAnchor,!1,!1,0,!1),_.O.SetAnchorPos(this.leftAnchor,!0,!1,0,!1,null,-t.x)}ShowSubItem(t){const e=t
if(null!=e){const t=w.p.Inst_get().GetMapById(e.MapId_get())
M.F.getInst().curWorldCfg=t,B.X.inst.OpenWorldMapExpTipView()}}OnItemRefreshFun(t){return t[0].getCNode(k)}GetWorldMapItem(t){let e=0
for(;e<this.items.Count();){const s=this.items[e]
if(s.InMap(t))return s
e+=1}return null}ClearInterval(){d.C.Inst_get().ClearInterval(this.unlockInterval),d.C.Inst_get().ClearInterval(this.startCloudEffectInterval),
d.C.Inst_get().ClearInterval(this.startCloudBgInterval),d.C.Inst_get().ClearInterval(this.delayCloudEffectInterval),d.C.Inst_get().ClearInterval(this.delayCloudBgInterval),
d.C.Inst_get().ClearInterval(this.guideInterval),d.C.Inst_get().ClearInterval(this.interval),this.unlockInterval=-1,this.startCloudEffectInterval=-1,this.startCloudBgInterval=-1,
this.delayCloudEffectInterval=-1,this.delayCloudBgInterval=-1,this.guideInterval=-1,this.interval=-1}TaskUnlockMap(t){null==t&&(t=0)
const e=t,s=this.GetWorldMapItem(e)
null!=s&&(this.ClearInterval(),this.cloudEffectAlpha=1,this.cloudBgAlpha=1,s.effect.SetActive(!1),
this.unlockInterval=d.C.Inst_get().SetIntervalForParm(this._degf_UnlockMapEffect,600,1,e))}UnlockMapEffect(t,e){const s=m.GF.INT(e)
this.GetWorldMapItem(s).Unlock(),this.startCloudEffectInterval=d.C.Inst_get().SetFrameLoopForParm(this._degf_ClearCloudEffect,5,1,s),
this.startCloudBgInterval=d.C.Inst_get().SetFrameLoopForParm(this._degf_ClearCloudBg,3,1,s),h.j.Inst.PlayByDivision("ui_mapUnlock")}ClearCloudEffect(t,e){const s=m.GF.INT(e)
this.GetWorldMapItem(s).DelayShowEffect(),this.delayCloudEffectInterval=d.C.Inst_get().SetFrameLoopForParm(this._degf_DelayClearCloudEffect,1,85,s)}ClearCloudBg(t,e){
const s=m.GF.INT(e)
this.delayCloudBgInterval=d.C.Inst_get().SetFrameLoopForParm(this._degf_DelayClearCloudBg,1,72,s)}DelayClearCloudEffect(t,e){const s=m.GF.INT(e)
this.GetWorldMapItem(s)
this.cloudEffectAlpha-=1/85}DelayClearCloudBg(t,e){const s=m.GF.INT(e)
this.GetWorldMapItem(s)
this.cloudBgAlpha-=1/72}SetDrag(){this.worldDragPointer.SetActive(!0)
const t=v.I.calVec0
t.x=0,t.y=0,t.z=0,this.dragTarget.transform.SetLocalPosition(t)
const e=C.L.zero_get()
e.x=561-this.textureWidth/2,e.y=0,e.z=this.textureWidth/2-561,e.w=0,0!=this.dragIndex&&a.L.Inst.UnregDrag(this.dragIndex),C.L.Recyle(e)}})},36041:(t,e,s)=>{
var i,n=s(18998),l=s(6847),o=s(83908),a=s(46282),r=s(98800),h=s(96098),d=s(97461),c=s(50089),I=s(68662),u=s(85682),p=s(31222),_=s(5494),g=s(60130),m=s(98885),S=s(82589),f=s(92679),C=s(87923),T=s(55552),y=s(68637),A=s(47552),v=s(62783),D=s(97943),w=s(12970)
;(0,l.s_)(_.I.eMap,a.Z.ui_topsmallmap_mainmap).waitPrefab(a.Z.ui_topsmallmap_currentmapinfoitem_t).waitPrefab(a.Z.ui_topsmallmap_currentmapinfoitem).register()(i=class extends((0,
o.Ri)()){constructor(...t){super(...t),this.isFirstOpen=!0,this.currentView=-1,this._degf_CloseHandler=null,this._degf_OnAnimationFinish=null,this._degf_OnSceneBtnClick=null,
this._degf_OnWorldBtnClick=null,this._degf_OpenWorldMap=null}_initBinder(){super._initBinder(),this._degf_CloseHandler=(t,e)=>this.CloseHandler(t,e),
this._degf_OnAnimationFinish=()=>this.OnAnimationFinish(),this._degf_OnSceneBtnClick=(t,e)=>this.OnSceneBtnClick(t,e),this._degf_OnWorldBtnClick=(t,e)=>this.OnWorldBtnClick(t,e),
this._degf_OpenWorldMap=t=>this.OpenWorldMap(t)}InitView(){this.worldMapBtn.node.SetActive(!I.D.IsFenBao()),this.worldView.SetActive(!1),this.sceneView.SetActive(!1),
this.pre_eff_map_change_01.SetActive(!0),this.pre_eff_map_change_02.SetActive(!0),this.pre_eff_map_change_03.SetActive(!1),this.UpdateAnchors(),
C.l.setComponentPosByNode(this.closeBtn.node,0,-80)}Destroy(){v.X.inst.IsSpecialOpen||(v.X.inst.SpecialOpenMonsterLevel=0),A.x.Instance.hasCallback=!1,v.X.inst.IsSpecialOpen=!1,
v.X.inst.SpecialOpenId=0,v.X.inst.SpecialTreeId=null}OnAddToScene(){if(this.AddLis(),v.X.inst.IsSpecialOpen&&v.X.inst.SpecialOpenId>0){
const t=T.h.GetInst().GetSpwanItemById(v.X.inst.SpecialOpenId)
v.X.inst.CurrentMapId_set(m.M.String2Int(t.mapId))}v.X.inst.IsSpecialOpen||(v.X.inst.SpecialOpenMonsterLevel=0),this.worldMapBtn.node.SetActive(!I.D.IsFenBao()),
this.currentView=-1,this.isFirstOpen=!0
const t=v.X.inst.openType
this.SelectTabHandler(t)
const e=w.F.getInst().GetMapNotChallengeBoss()
v.X.inst.isAutoOpenBossChallengeView&&v.X.inst.OpenBossChallengeView(e)}RegGuide(){this.UnRegGuide(),
this.worldMapBtn.node.active&&y.c.Inst.RegGameObject(u.D.UI_MAP_CURENT_BTN,this.worldMapBtn.node),
this.sceneMapBtn.node.active&&y.c.Inst.RegGameObject(u.D.UI_MAP_SCENE_BTN,this.sceneMapBtn.node)}UnRegGuide(){y.c.Inst.UnRegGameObject(u.D.UI_MAP_CURENT_BTN),
y.c.Inst.UnRegGameObject(u.D.UI_MAP_SCENE_BTN)}CheckGuide(){C.l.CheckBtnClickTrigger(u.D.UI_MAP_CURENT_BTN)}CheckGuide1(){C.l.CheckBtnClickTrigger(u.D.UI_MAP_SCENE_BTN)}Clear(){
this.UnRegGuide(),this.RemoveLis(),this.worldView.Clear(),this.sceneView.Clear(),!A.x.Instance.hasCallback&&h.B.Inst.isOpenMaskStart&&(r.Y.Inst.PrimaryRole_get().SetShow(!0),
p.N.inst.CloseById(_.I.MapTransportMask),h.B.Inst.isOpenMaskStart=!1)}AddLis(){this.AddClickEvent(this.closeBtn.node,this._degf_CloseHandler),
this.AddClickEvent(this.worldMapBtn.node,this._degf_OnWorldBtnClick),this.AddClickEvent(this.sceneMapBtn.node,this._degf_OnSceneBtnClick),
this.AddClickEvent(this.scrollviewCollider,this.CreateDelegate(this.CloseTips)),d.i.Inst.AddEventHandler(f.g.OPEN_WORLD_MAP,this._degf_OpenWorldMap),
this.AddClickEvent(this.colliderLayer,this.CreateDelegate(this.CloseTips)),this.m_handlerMgr.AddEventMgr(f.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors))}RemoveLis(){
this.RemoveClickEvent(this.closeBtn.node,this._degf_CloseHandler),this.RemoveClickEvent(this.worldMapBtn.node,this._degf_OnWorldBtnClick),
this.RemoveClickEvent(this.sceneMapBtn.node,this._degf_OnSceneBtnClick),this.RemoveClickEvent(this.scrollviewCollider,this.CreateDelegate(this.CloseTips)),
d.i.Inst.RemoveEventHandler(f.g.OPEN_WORLD_MAP,this._degf_OpenWorldMap),this.RemoveClickEvent(this.colliderLayer,this.CreateDelegate(this.CloseTips))}UpdateAnchors(){
const t=n.sys.getSafeAreaRect()
this.worldMapBg.widthSet(n.view.getVisibleSize().x),this.worldMapBg.node.position.set(-t.x/2,this.worldMapBg.node.position.y,this.worldMapBg.node.position.z),
g.O.SetAnchorPos(this.leftAnchor,!0,!1,0,!1),g.O.SetAnchorPos(this.rightAnchor,!1,!1,0,!1),g.O.SetAnchorPos(this.leftAnchor2,!0,!1,0,!1),
g.O.SetAnchorPos(this.rightAnchor2,!1,!1,0,!1)
const e=c.t.GetUIWidth()/1280
this.cloudEffect.setScale(e,e,1)}CloseHandler(t,e){v.X.inst.CloseMapPanel()}CloseTips(){w.F.getInst().RaiseEvent(D.f.CloseMonsterTip),
d.i.Inst.RaiseEvent(f.g.SMALL_MAP_CLOSE_MONSTER_TIP)}OnWorldBtnClick(t,e){v.X.inst.IsSpecialOpen=!1,v.X.inst.SpecialOpenId=0,v.X.inst.SpecialTreeId=null,
v.X.inst.CurrentMapId_set(0),this.SelectTabHandler(v.X.WORD_MAP),this.CheckGuide(),this.PlayEff()}OnSceneBtnClick(t,e){v.X.inst.IsSpecialOpen=!1,v.X.inst.SpecialOpenId=0,
v.X.inst.SpecialTreeId=null,v.X.inst.CurrentMapId_set(0),this.SelectTabHandler(v.X.SCENE_MAP),this.CheckGuide1(),this.PlayEff()}OnAnimationFinish(){}SelectTabHandler(t){
t!=this.currentView&&(t==v.X.SCENE_MAP?this.OpenSceneMap():this.OpenWorldMap(null)),this.RegGuide()}OpenSceneMap(){this.worldMapBg.node.SetActive(!0),this.sceneView.OnAddToScene(),
this.sceneView.node.SetActive(!0),this.worldView.Clear(),this.worldView.node.SetActive(!1),this.currentView=v.X.SCENE_MAP,this.isFirstOpen=!1,d.i.Inst.RaiseEvent(f.g.CHANGE_MAP)}
OpenWorldMap(t){I.D.IsFenBao()?this.OpenSceneMap():(v.X.inst.showMaxPass?this.sceneMapBtn.node.SetActive(!1):this.sceneMapBtn.node.SetActive(!0),this.worldMapBg.node.SetActive(!1),
this.sceneView.Deactivate(),this.sceneView.node.SetActive(!1),this.worldView.OnAddToScene(),this.worldView.node.SetActive(!0),this.currentView=v.X.WORD_MAP,this.isFirstOpen=!1)}
IsFirstPanel_Get(){return!0}PlayEff(){this.pre_eff_map_change_03.SetActive(!0),this.pre_eff_map_change_03.getComponent(S.J).replay(1)}})},9165:(t,e,s)=>{s.d(e,{K:()=>d})
var i=s(93877),n=s(72005),l=s(30849),o=s(98885),a=s(94148),r=s(48933),h=s(55552)
class d extends l.C{constructor(...t){super(...t),this.icon=null,this.namelab=null,this.bloodlab=null,this.w=0,this.h=0}InitView(){super.InitView(),
this.icon=this.CreateComponent(n.w,1),this.namelab=this.CreateComponent(i.Q,2),this.bloodlab=this.CreateComponent(i.Q,3)}AddLis(){}RemoveLis(){}Clear(){this.RemoveLis(),
super.Clear()}SetData(t,e,s){this.icon.spriteNameSet(t),this.namelab.textSet(e),null!=s&&this.bloodlab.textSet(s)}SetMonsterId(t,e,s){
const i=h.h.inst.GetSpwanItemById(t),n=i.objectKey
let l="ryditu_sp_0006"
if(a.b.Inst_get().InAsuramMap()){const r=a.b.Inst_get().GetAltarMapIcon(t)
l=o.M.IsNullOrEmpty(r)?a.b.Inst_get().GetMapIcon(n):r
let h=a.b.Inst_get().GetAltarName(t)
null==h&&(h=i.name)
const d=a.b.Inst_get().GetAltarExtra(t),c=Math.ceil(e.ToNum()/s.ToNum()*1e4)/100
this.bloodlab.textSet(a.b.Inst_get().GetMapIconStr(n,c)),this.SetData(l,h,d)}}SetIconWH(t,e){this.w!=t&&(this.icon.widthSet(t),this.w=t),this.h!=e&&(this.icon.heightSet(e),
this.h=e)}SetIconPos(t,e){r.I.calVec0.Set(t,e,0),this.icon.node.transform.SetLocalPosition(r.I.calVec0)}SetExtraPos(t,e){r.I.calVec0.Set(t,e,0),
this.bloodlab.node.transform.SetLocalPosition(r.I.calVec0)}SetNamePos(t,e){r.I.calVec0.Set(t,e,0),this.namelab.node.transform.SetLocalPosition(r.I.calVec0)}SetNameAlign(){}
SetExtraLAlign(t){this.bloodlab.pivotSet(t)}Destroy(){super.Destroy(),this.icon=null,this.namelab=null,this.bloodlab=null}Test1(){return!0}S_Test(){return!0}}},36197:(t,e,s)=>{
var i,n,l=s(18998),o=s(75507),a=s(6847),r=s(83908),h=s(49655),d=s(46282),c=s(86133),I=s(98800),u=s(97461),p=s(68662),_=s(2689),g=s(13687),m=s(5924),S=s(85682),f=s(49484),C=s(60130),T=s(98130),y=s(85602),A=s(94148),v=s(92679),D=s(87923),w=s(29839),B=s(85770),M=s(92473),b=s(48933),O=s(37648),R=s(55492),L=s(24524),G=s(75439),P=s(68637),E=s(83900),k=s(91690),N=s(21267),V=s(66988),x=s(9182),F=s(21334),U=s(62783),H=s(97943),j=s(12970)
;(0,
a.s_)(h.o.TopSmallMapView,d.Z.ui_topsmallmap_topmappanel).waitPrefab(d.Z.ui_topsmallmap_radartransferitem).waitPrefab(d.Z.ui_topsmallmap_obj_item).waitPrefab(d.Z.ui_maze_room_min_map).waitPrefab(d.Z.ui_topsmallmap_gate_info_ry).waitPrefab(d.Z.ui_topsmallmap_gate_conetpoint).waitPrefab(d.Z.ui_topsmallmap_point).waitPrefab(d.Z.ui_topsmallmap_radarendpoint).waitPrefab(d.Z.ui_topsmallmap_endpoint).waitPrefab(d.Z.ui_topsmallmap_radartaskitem).waitPrefab(d.Z.ui_topsmallmap_radarbossitem).waitPrefab(d.Z.ui_topsmallmap_bossitem).layerNav().register()(((n=class extends((0,
r.Ri)()){constructor(...t){super(...t),this.roleInfo=null,this.closeLineInterval=-1,this.isLineClosing=!1,this.isout=!1,this._degf_CloseLine=null,this._degf_OnItemRefreshFun=null,
this._degf_OpenCurrentMapHandler=null,this._degf_closeLinesHandler=null,this._degf_lineChangedHandler=null,this._degf_onCloseLinesClick=null,this._degf_onShowBtnClick=null,
this._degf_OnEnterMap=null,this.isOpengoldBtn=null,this.mapPassShowLevel=null,this.mazeView=null,this.ShowMap=null}_initBinder(){super._initBinder(),
this._degf_CloseLine=()=>this.CloseLine(),this._degf_OpenCurrentMapHandler=(t,e)=>this.OpenCurrentMapHandler(t,e),this._degf_closeLinesHandler=t=>this.closeLinesHandler(t),
this._degf_lineChangedHandler=t=>this.lineChangedHandler(t),this._degf_onCloseLinesClick=(t,e)=>this.onCloseLinesClick(t,e),
this._degf_onShowBtnClick=(t,e)=>this.onShowBtnClick(t,e),this._degf_OnEnterMap=()=>this.OnEnterMap()}InitView(){this.radarView.isradar=!0,
this.roleInfo=I.Y.Inst.PrimaryRoleInfo_get(),this.lineChangedHandler(null),this.isOpengoldBtn=!1,this.mapPassShowLevel=G.D.getInstance().GetIntValue("CHECKPOINT:SHOW_LEVEL"),
this.AddLis()}OnAddToScene(){C.O.SetAnchorPos(this.anchor,!1,!1,2,!1,!0),D.l.setComponentPosByNode(this.anchor,-30,0),D.l.setComponentPosByNode(this.rewardBtn,25,-40),
this.lineList.SetActive(!1),this.menuCollider.SetActive(!1),this.UpdaterewardBtn(),this.UpdateRewardBtnEff(),this.UpdateBossChanllengeInfo(),
this.isOpengoldBtn=O.P.Inst_get().IsFunctionOpened(R.x.GOLDSPAWN),f.p.Inst_get().EnterMap(g.b.Inst.currentMapId_get()),this.OnEnterMap()}OnEnterMap(){p.D.IsIosShenhe(!1)
let t=g.b.Inst.currentMapId_get(),e=F.p.Inst_get().GetMapById(t)
e.controllerType==_.N.SPACE_MAZE?(this.radarView.SetActive(!1),null==this.mazeView&&this.LoadMazeMinMapComplete()):(null!=this.mazeView&&(this.mazeView.Clear(),
this.mazeView.Destroy(),this.mazeView=null),this.radarView.SetActive(!0),this.radarView.OnAddToScene()),1==e.hideSmallMap?1==e.hideExit?(this.exitBtnView.Clear(),
this.exitBtnView.SetActive(!1),this.SetMapActive(!1)):(this.exitBtnView.OnAddToScene(),this.exitBtnView.SetActive(!0),this.SetMapActive(!1),
D.l.setComponentPosByNode(this.exitBtnView.node,0,-20)):(this.exitBtnView.Clear(),this.exitBtnView.SetActive(!1),this.SetMapActive(!0)),this.goldBtn.SetActive(!1),
this.ShowUnlockTips()}LoadMazeMinMapComplete(){const t=o.o.getPrefab("ui_maze_room_min_map"),e=(0,l.instantiate)(t)
this.mazeView=e.getCNode(x.I),this.mazeView.node.setParent(this.radarPanel),this.mazeView.node.transform.SetLocalPositionXYZ(-157,69,0),this.mazeView.SetMinMap(),
this.mazeView.OnAddToScene()}SetMapActive(t){let e=F.p.Inst_get().GetMapById(g.b.Inst.currentMapId_get())
t?(this.ShowMap=!0,this.UpdateMapBtn(),10001==e.id&&(u.i.Inst.AddEventHandler(v.g.GET_OUT_SAFE_AREA,this.CreateDelegate(this.UpdateMapBtn)),
u.i.Inst.AddEventHandler(v.g.GET_IN_SAFE_AREA,this.CreateDelegate(this.UpdateMapBtn)),
u.i.Inst.AddEventHandler(v.g.PLAYER_LEVELUP,this.CreateDelegate(this.UpdateMapBtn)))):(this.rewardBtn.SetActive(t),this.hasBossTips.SetActive(t),this.map.SetActive(t),
this.mapbtnSpBg.SetActive(!t),this.mapPassBtn.SetActive(t),this.ShowMap=!1,u.i.Inst.RemoveEventHandler(v.g.GET_IN_SAFE_AREA,this.CreateDelegate(this.UpdateMapBtn)),
u.i.Inst.RemoveEventHandler(v.g.GET_OUT_SAFE_AREA,this.CreateDelegate(this.UpdateMapBtn)),u.i.Inst.RemoveEventHandler(v.g.PLAYER_LEVELUP,this.CreateDelegate(this.UpdateMapBtn)))}
UpdateMapBtn(){let t=F.p.Inst_get().GetMapById(g.b.Inst.currentMapId_get())
this.ShowMap&&(10001==t.id?I.Y.Inst.PrimaryRole_get().isInSafeArea&&I.Y.Inst.PrimaryRoleInfo_get().Level_get()>=this.mapPassShowLevel?(this.mapPassBtn.SetActive(!0),
this.map.SetActive(!1),this.mapbtnSpBg.SetActive(!0),this.hasBossTips.SetActive(!1),this.UpdaterewardBtn()):(this.mapPassBtn.SetActive(!1),this.map.SetActive(!0),
this.mapbtnSpBg.SetActive(!1),this.UpdateBossChanllengeInfo(),this.UpdaterewardBtn()):(this.mapPassBtn.SetActive(!1),this.map.SetActive(!0),this.mapbtnSpBg.SetActive(!1),
this.UpdateBossChanllengeInfo(),this.UpdaterewardBtn(),u.i.Inst.RemoveEventHandler(v.g.GET_OUT_SAFE_AREA,this.CreateDelegate(this.UpdateMapBtn)),
u.i.Inst.RemoveEventHandler(v.g.GET_IN_SAFE_AREA,this.CreateDelegate(this.UpdateMapBtn))))}UpdateBossChanllengeInfo(){let t=g.b.Inst.currentMapId_get(),e=!1
F.p.Inst_get().GetMapById(t).controllerType==_.N.SCENE&&(e=!0),this.hasBossTips.SetActive(!1)}ShowUnlockTips(){
if(I.Y.Inst.PrimaryRoleInfo_get().Level_get()<G.D.getInstance().GetIntValue("CHANGEMAP:NOTICE"))this.tipContent.SetActive(!1)
else if(M.R.Inst_get().IsInCrossBattle())this.tipContent.SetActive(!1)
else if(w.p.inst.IsInCopy())this.tipContent.SetActive(!1)
else{j.F.getInst().CheckHasMapNotChallengeBoss()?this.tipContent.SetActive(!0):this.tipContent.SetActive(!1)}}CheckGoldSpawn(t){let e=0,s=!1
null==t?s=!0:e=T.GF.INT(t),(s||e==R.x.GOLDSPAWN)&&(this.isOpengoldBtn=O.P.Inst_get().IsFuncOrActivityOpened(R.x.GOLDSPAWN))}OnClickReward(){E.N.Inst().OpenMappassRewardView(),
D.l.CheckBtnClickTrigger(S.D.UI_MAIN_SMALL_MAP_REWARD_BTN)}Clear(){this.RemoveLis(),this.isout=!1,-1!=this.closeLineInterval&&(m.C.Inst_get().ClearInterval(this.closeLineInterval),
this.closeLineInterval=-1),null!=this.mazeView&&(this.mazeView.Clear(),this.mazeView.Destroy(),this.mazeView=null),this.radarView.Clear()}AddLis(){
this.AddClickEvent(this.map,this.CreateDelegate(this.OpenCurrentMapHandler)),this.AddClickEvent(this.mapPassBtn,this.CreateDelegate(this.mapPassHandler)),
this.AddClickEvent(this.menuCollider.node,this._degf_onCloseLinesClick),this.AddClickEvent(this.rewardBtn,this.CreateDelegate(this.OnClickReward)),
j.F.getInst().AddEventHandler(H.f.LineChange,this._degf_lineChangedHandler),j.F.getInst().AddEventHandler(H.f.CloseSelectLine,this._degf_closeLinesHandler),
j.F.getInst().AddEventHandler(H.f.UnlockMap,this.CreateDelegate(this.ShowUnlockTips)),this.m_handlerMgr.AddEventMgr(v.g.FUNCTION_OPEN,this.CreateDelegate(this.CheckGoldSpawn)),
this.m_handlerMgr.AddEventMgr(v.g.FUNCTION_INIT_COMPLETE,this.CreateDelegate(this.CheckGoldSpawn)),this.m_handlerMgr.AddEventMgr(v.g.EnterMap,this.CreateDelegate(this.OnEnterMap)),
this.m_handlerMgr.AddEventMgr(v.g.UPDATE_UNLOCK_BOSS_CHANLLENGE_INFO,this.CreateDelegate(this.UpdateBossChanllengeInfo)),
this.m_handlerMgr.AddEventMgr(v.g.CHOOSE_SETTING_UPDATE,this.CreateDelegate(this.UpdateBossChanllengeInfo)),
N.u.Inst().AddEventHandler(k.Z.UpdateGetRewardState,this.CreateDelegate(this.UpdateRewardBtnEff)),
this.m_handlerMgr.AddEventMgr(v.g.UITweenStateChanged,this.CreateDelegate(this.OnUITweenStateChanged)),
this.m_handlerMgr.AddEventMgr(v.g.FUNCTION_OPEN,this.CreateDelegate(this.UpdaterewardBtn)),
this.m_handlerMgr.AddEventMgr(v.g.FUNCTION_INIT,this.CreateDelegate(this.UpdaterewardBtn)),this.RegGuide()}RegGuide(){P.c.Inst.RegGameObject(S.D.UI_MAIN_SMALL_MAP,this.map),
P.c.Inst.RegGameObject(S.D.UI_MAIN_SMALL_MAP_REWARD_BTN,this.rewardBtn)}UnRegGuide(){P.c.Inst.UnRegGameObject(S.D.UI_MAIN_SMALL_MAP),
P.c.Inst.UnRegGameObject(S.D.UI_MAIN_SMALL_MAP_REWARD_BTN)}CheckGuide(){D.l.CheckBtnClickTrigger(S.D.UI_MAIN_SMALL_MAP)}RemoveLis(){
this.RemoveClickEvent(this.map,this.CreateDelegate(this.OpenCurrentMapHandler)),this.RemoveClickEvent(this.menuCollider.node,this._degf_onCloseLinesClick),
this.RemoveClickEvent(this.rewardBtn,this.CreateDelegate(this.OnClickReward)),j.F.getInst().RemoveEventHandler(H.f.LineChange,this._degf_lineChangedHandler),
j.F.getInst().RemoveEventHandler(H.f.CloseSelectLine,this._degf_closeLinesHandler),j.F.getInst().RemoveEventHandler(H.f.UnlockMap,this.CreateDelegate(this.ShowUnlockTips)),
u.i.Inst.RemoveEventHandler(v.g.FUNCTION_OPEN,this.CreateDelegate(this.CheckGoldSpawn)),
u.i.Inst.RemoveEventHandler(v.g.FUNCTION_INIT_COMPLETE,this.CreateDelegate(this.CheckGoldSpawn)),u.i.Inst.RemoveEventHandler(v.g.EnterMap,this.CreateDelegate(this.OnEnterMap)),
u.i.Inst.RemoveEventHandler(v.g.UPDATE_UNLOCK_BOSS_CHANLLENGE_INFO,this.CreateDelegate(this.UpdateBossChanllengeInfo)),
u.i.Inst.RemoveEventHandler(v.g.CHOOSE_SETTING_UPDATE,this.CreateDelegate(this.UpdateBossChanllengeInfo)),
N.u.Inst().RemoveEventHandler(k.Z.UpdateGetRewardState,this.CreateDelegate(this.UpdateRewardBtnEff)),
this.m_handlerMgr.RemoveEventMgr(v.g.UITweenStateChanged,this.CreateDelegate(this.OnUITweenStateChanged)),
u.i.Inst.RemoveEventHandler(v.g.FUNCTION_OPEN,this.CreateDelegate(this.UpdaterewardBtn)),u.i.Inst.RemoveEventHandler(v.g.FUNCTION_INIT,this.CreateDelegate(this.UpdaterewardBtn)),
u.i.Inst.RemoveEventHandler(v.g.GET_OUT_SAFE_AREA,this.CreateDelegate(this.UpdateMapBtn)),u.i.Inst.RemoveEventHandler(v.g.GET_IN_SAFE_AREA,this.CreateDelegate(this.UpdateMapBtn)),
this.UnRegGuide()}Destroy(){this.radarView.isradar=!0}ForcePlayAni(){this.OnUITweenStateChanged(this.isout,!0)}OnUITweenStateChanged(t,e){null==e&&(e=!1),
(this.isout!=t||e)&&(this.isout=t,this.node.visible=!t)}mapPassHandler(t,e){this.CheckGuide(),this.tipContent.activeInHierarchy&&this.tipContent.SetActive(!1),
U.X.inst.OpenMapPanel(U.X.WORD_MAP,null,!0)}OpenCurrentMapHandler(t,e){this.CheckGuide()
let s=F.p.Inst_get().GetMapById(g.b.Inst.currentMapId_get())
s.controllerType==_.N.SPACE_MAZE?V.G.Inst_get().OpenMapRoom():(this.tipContent.activeInHierarchy&&this.tipContent.SetActive(!1),
s.controllerType==_.N.CROSS_BOSS_CLIENT||s.controllerType==_.N.ROLAND_VALLEY?U.X.inst.OpenMapPanel(U.X.SCENE_MAP):U.X.inst.OpenMapPanel())}onShowBtnClick(t,e){
if(this.lineList.active)this.lineList.SetActive(!1),this.menuCollider.SetActive(!1)
else if(!this.isLineClosing){let t=g.b.Inst.currentMapId_get()
F.p.Inst_get().GetMapById(t).dynamicChannel||0!=B.a.Inst_get().currentCopyId||U.X.inst.OpenChangeLinePanel()}}onCloseLinesClick(t,e){
this.lineList.active&&(this.lineList.SetActive(!1),this.menuCollider.SetActive(!1),this.isLineClosing=!0,
this.closeLineInterval=m.C.Inst_get().SetInterval(this._degf_CloseLine,100,1))}CloseLine(){this.isLineClosing=!1,this.closeLineInterval=-1}SetMenuActive(t){
this.lineList.SetActive(t),this.menuCollider.SetActive(t)}lineChangedHandler(t){let e="",s=g.b.Inst.currentMapId_get(),i=F.p.Inst_get().GetMapById(s)
if(null!=i)if(e+=i.name,i.dynamicChannel||0!=B.a.Inst_get().currentCopyId?(b.I.calVec0.Set(10,85,0),
this.lineText.textSet(e)):(j.F.getInst().CurLine_set(I.Y.Inst.PrimaryRoleInfo_get().CurLine_get()),b.I.calVec0.Set(-20,85,0),this.lineText.textSet(e)),
w.p.inst.IsCopyInBloodTown())this.lineText.textSet((0,c.T)("血色城堡")+(L.o.Inst().getBloodLayerById(B.a.Inst_get().currentCopyId)+(0,c.T)("层")))
else if(w.p.inst.IsCopyInBeliel())this.lineText.textSet((0,c.T)("恶魔广场")+(L.o.Inst().getBelialLayerById(B.a.Inst_get().currentCopyId)+(0,c.T)("层")))
else if(A.b.Inst_get().InAsuramMap()){let t=A.b.Inst_get().GetMapName(e)
this.lineText.textSet(t)}}ChangeMap(){this.radarView.ChangeMap()}closeLinesHandler(t){this.lineList.SetActive(!1),this.menuCollider.SetActive(!1)}SetLineText(t){
let e="",s=g.b.Inst.currentMapId_get(),i=F.p.Inst_get().GetMapById(s)
null!=i&&(e+=i.name,i.dynamicChannel||0!=B.a.Inst_get().currentCopyId||j.F.getInst().CurLine_set(I.Y.Inst.PrimaryRoleInfo_get().CurLine_get()),this.lineText.textSet(e),
i.dynamicChannel||0!=B.a.Inst_get().currentCopyId?b.I.calVec0.Set(15,79,0):b.I.calVec0.Set(0,79,0),w.p.inst.IsCopyInBloodTown()?this.lineText.textSet((0,
c.T)("血色城堡")+(L.o.Inst().getBloodLayerById(B.a.Inst_get().currentCopyId)+(0,c.T)("层"))):w.p.inst.IsCopyInBeliel()&&this.lineText.textSet((0,
c.T)("恶魔广场")+(L.o.Inst().getBelialLayerById(B.a.Inst_get().currentCopyId)+(0,c.T)("层"))))}UpdaterewardBtn(){let t=g.b.Inst.currentMapId_get(),e=F.p.Inst_get().GetMapById(t),s=!1
e.controllerType!=_.N.SCENE&&e.controllerType!=_.N.ROLAND_SERVER&&e.controllerType!=_.N.ROLAND_CLIENT&&e.controllerType!=_.N.MULTIPLE_HANG||(s=!0),
s&&O.P.Inst_get().IsFunctionOpened(R.x.PASS_MAP_MAIN_BTN)?(this.rewardBtn.SetActive(!0),this.UpdateRewardBtnEff()):this.rewardBtn.SetActive(!1)}UpdateRewardBtnEff(){
N.u.Inst().hasRewardCanGet?this.rewardBtnEff.SetActive(!0):this.rewardBtnEff.SetActive(!1)}GetMapFlyPos(){return this.hasBossTips.transform.GetLocalPosition()}
}).showExitBtnArray=new y.Z(["DEMONPLAZA","BLOODTOWN","REDHOOD","REDHOODREADY","DRAGONSOULRUINS","ASURAMWAR","LOSTLAND","PERSONALBOSS","BOXGATHER","MIRACLEMAINLAND","MIRACLEMAINLAND_SCENE_COPY","MAPCOPY","ONEDRAGON","MEMORY","ASURAMQUEST","NORMAL_MIRACLE_TOWER_COPY","HARD_MIRACLE_TOWER_COPY","BRAVETRAILCOPY","WORLD_BOSS","WORLD_BOSS_NEWHAND","BATTLEFIELD","SKY_ILLUSION","CROSS_GOLD_BATTLE","CROSS_READY","KUNDUN_SEAL_COPY","SIXTH_TRANSFER","CROSS_ARENA_READY","ELEMENT_DUNGEON","SNOWBALL","GOLD_SPAWN","GOLD_SPAWN_SINGLE"]),
i=n))},78922:(t,e,s)=>{s.d(e,{f:()=>Ot})
var i=s(42292),n=s(71409),l=s(17409),o=s(32076),a=s(38836),r=s(86133),h=s(98800),d=s(97461),c=s(68662),I=s(70829),u=s(5924),p=s(84473),_=s(56937),g=s(31222),m=s(5494),S=s(52726),f=s(98885),C=s(85602),T=s(38962),y=s(79534),A=s(70850),v=s(63076),D=s(34135),w=s(99500),B=s(3859),M=s(76645),b=s(23628),O=s(92679),R=s(33314),L=s(87923),G=s(29839),P=s(37648),E=s(55492),k=s(33138),N=s(92415),V=s(45537),x=s(19983),F=s(49892),U=s(75961),H=s(63945),j=s(60647),W=s(13487),Y=s(96297),q=s(78485),z=s(5968),Z=s(65550),X=s(39043),Q=s(85942),J=s(37151)
class ${constructor(){this.itemId=0,this.num=0,this.time=null,this.isCross=!1}Test1(){return!0}S_Test(){return!0}}
var K,tt,et,st,it,nt,lt,ot,at,rt,ht,dt,ct,It=s(35091),ut=s(29001),pt=s(21979),_t=s(25705),gt=s(91322),mt=s(38935),St=s(18088),ft=s(84066),Ct=s(99365),Tt=s(37730),yt=s(40489),At=s(69759),vt=s(92039),Dt=s(89660),wt=s(96206),Bt=s(72911)
class Mt{constructor(){this.model=null,this.RegMsg(),this.model=It._.Inst_get()}RegMsg(){}HandleSort(t){if(0!=this.model.noticeitem)for(const[e,s]of(0,
a.vy)(t))s.itemId==this.model.noticeitem&&(t.Remove(s),t.Insert(0,s))}CM_QueryPrice(t,e=!1){null==e&&(e=this.model.crossserver)
const s=new vt.g
s.itemIds=t,s.isCross=e,mt.C.Inst.F_SendMsg(s)}CM_SellItem(t,e,s,i){null==i&&(i=this.model.crossserver)
const n=new Dt.W
n.num=e,n.objectId=t,n.curPrize=s,n.isCross=i,mt.C.Inst.F_SendMsg(n)}CM_SureFollowNotify(t){null==t&&(t=this.model.crossserver)
const e=new Bt.v
e.isCross=t,mt.C.Inst.F_SendMsg(e)}CM_MarketSellRecode(t){null==t&&(t=this.model.crossserver)
const e=new At.w
e.isCross=t,mt.C.Inst.F_SendMsg(e)}CM_MarketItemScreen(t,e,s,i,n){null==n&&(n=this.model.crossserver)
const l=new yt.m
l.screenId2Condition=t,l.startIndex=0,l.endIndex=200,l.sortType=i,l.isCross=n,mt.C.Inst.F_SendMsg(l)}CM_MarketItemFollow(t,e){null==e&&(e=this.model.crossserver)
const s=new Tt.Y
s.followItems=t,s.isCross=e,mt.C.Inst.F_SendMsg(s)}CM_MarketBuyRecode(t){null==t&&(t=this.model.crossserver)
const e=new Ct.x
e.isCross=t,mt.C.Inst.F_SendMsg(e)}CM_CancelMarketItemFollow(t,e){null==e&&(e=this.model.crossserver),
0!=this.model.noticeitem&&t.IndexOf(this.model.noticeitem)>-1&&Ot.Inst_Get().HandleNotOpenNotice()
const s=new ft.m
s.followItems=t,s.isCross=e,mt.C.Inst.F_SendMsg(s)}CM_BuyMarketItem(t,e,s,i){null==i&&(i=this.model.crossserver)
const n=new St.I
n.itemId=t,n.num=e,n.curPrize=s,n.isCross=i,mt.C.Inst.F_SendMsg(n)}CM_ServerMarketRecode(t,e){null==e&&(e=this.model.crossserver)
const s=new wt.C
s.type=t,s.isCross=e,mt.C.Inst.F_SendMsg(s)}Test1(){return!0}S_Test(){return!0}}function bt(t,e,s,i,n){var l={}
return Object.keys(i).forEach((function(t){l[t]=i[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=s.slice().reverse().reduce((function(s,i){return i(t,e,s)||s}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let Ot=(K=(0,n.GH)(N.k.SM_QueryMarketPriceRes),tt=(0,n.GH)(N.k.SM_MarketItemPriceChange),et=(0,
n.GH)(N.k.SM_ItemFollowNotify),st=(0,n.GH)(N.k.SM_BuyMarketItemSuccess),it=(0,n.GH)(N.k.SM_UpdateMarketItemInfo),nt=(0,n.GH)(N.k.SM_MarketInfo),lt=(0,n.GH)(N.k.SM_SellItemSuccess),
ot=(0,n.GH)(N.k.SM_MarketScreenResVo),at=(0,n.GH)(N.k.SM_MarketBuyRecode),rt=(0,n.GH)(N.k.SM_ServerMarketRecode),ht=(0,n.GH)(N.k.SM_MarketSellRecode),ct=class t{constructor(){
this.nethandler=null,this.model=null,this.buyTipPos=null,this.IsOpen=!1,this.notifyTimeId=0,this.nethandler=new Mt,this.model=It._.Inst_get(),this.buyTipPos=new y.P,this.AddLis(),
this.UpdateHaveSeen()}static Inst_Get(){return null==t.Inst&&(t.Inst=new t),t.Inst}AddLis(){d.i.Inst.AddEventHandler(O.g.PLAYER_LEVELUP,(0,o.v)(this.OnLevelUp,this)),
d.i.Inst.AddEventHandler(O.g.CHOOSE_SETTING_UPDATE,(0,o.v)(this.UpdateHaveSeen,this)),d.i.Inst.AddEventHandler(O.g.BAG_UPDATE,(0,o.v)(this.CheckOpenToMarketTip,this)),
d.i.Inst.AddEventHandler(O.g.MAP_LOGIN_LOAD_COMPELETE,(0,o.v)(this.CheckOpenToMarketTip,this)),d.i.Inst.AddEventHandler(V.z.HORSE_INFO_CHANGE,(0,
o.v)(this.CheckOpenToMarketTip,this)),d.i.Inst.AddEventHandler(O.g.FUNCTION_CLOSE,(0,o.v)(this.OnFunCloseHandler,this))}OpenBuyView(t,e=null){
if(null==e&&(e=It._.Inst_get().GetFunTypeByItemModelId(t)),!P.P.Inst_get().IsFunctionOpened(e))return void L.l.SetFunctionTip(e)
t&&(It._.Inst_get().findItemId=f.M.String2Int(t)),It._.Inst_get().openTabIndex=It._.BUYVIEW
const s=It._.Inst_get().GetTabByFunType(e)
Y.v.Inst_get().OpenStallView(s)}OpenSellView(t=null){const e=It._.Inst_get().GetFunTypeByItemModelId(t.modelId_get())
if(!P.P.Inst_get().IsFunctionOpened(e))return void L.l.SetFunctionTip(e)
It._.Inst_get().OpenSellItem=t,It._.Inst_get().openTabIndex=It._.SELLVIEW
const s=It._.Inst_get().GetTabByFunType(e)
Y.v.Inst_get().OpenStallView(s)}OpenLog(t){const e=new _.v
e.layerType=S.F.Alert,e.isShowMask=!0,e.viewClass=_t.B,It._.Inst_get().logType=t,(0,l.Yp)(m.I.TradingMarketLogPanel,e)}SendTradingMarketLog(t,e){
t==It._.BUY_LOG?e?this.nethandler.CM_MarketBuyRecode(null):this.nethandler.CM_ServerMarketRecode(1,null):e?this.nethandler.CM_MarketSellRecode(null):this.nethandler.CM_ServerMarketRecode(2,null)
}OpenBuyItem(t,e,s){It._.Inst_get().m_curSelectedDataId=s,It._.Inst_get().m_curSelectedData=t,It._.Inst_get().operationModel=e,this.CloseMarketBuyTip(),
d.i.Inst.AddEventHandler(O.g.TipsLoadCompelete,(0,o.v)(this.OpenMarketTip,this))}OpenMarketTip(t){this.OpenMarketMallBuyTip(It._.Inst_get().m_curSelectedData,H.x.BuyTipPos),
d.i.Inst.RemoveEventHandler(O.g.TipsLoadCompelete,(0,o.v)(this.OpenMarketTip,this))}OpenMarketMallBuyTip(t,e){this.model.m_curSelectedData=t,this.buyTipPos.x=e.x,
this.buyTipPos.y=e.y
const s=new _.v
s.layerType=S.F.Tip,s.viewClass=gt.X,(0,l.Yp)(m.I.TradingMarketOperation,s,null)}CloseMarketBuyTip(){(0,l.sR)(m.I.TradingMarketOperation)}OpenGetMarketItemTip(t){
if(!P.P.Inst_get().IsFunctionOpened(E.x.TRADING_MARKET))return
if(t.cfgData_get().itemType==B.q.RIDINGSOUL){const t=`${X.V.Inst_get().GetRolePrefix()}_${B.q.RIDINGSOUL}`
if(X.V.Inst_get().GetData(t))return
X.V.Inst_get().SetData(t,!0)}this.model.getItem=t
const e=g.N.inst.GetViewById(m.I.TradingMarketGetItemTipView)
if(e&&e.isShow_get());else{const t=new _.v
t.isShowMask=!0,t.layerType=S.F.Tip,t.viewClass=pt.Y,g.N.inst.OpenById(m.I.TradingMarketGetItemTipView,null,null,t)}}DequeueGetMarketItemTip(){const t=It._.Inst_get().itemQueue
t.Count()>0&&t.RemoveAt(0)}RemoveGetMarketItemTip(t){const e=It._.Inst_get().itemQueue
for(let s=0;s<=e.Count()-1;s++)if(e[s].modelId_get()==t){e.RemoveAt(s)
break}}CloseGetMarketItemTip(){g.N.inst.CloseById(m.I.TradingMarketGetItemTipView)}ShowTipsQueue(t){
const e=P.P.Inst_get().IsFunctionOpened(E.x.ROLAND_TRADINGMARKET),s=It._.Inst_get().itemQueue
for(const[i,n]of(0,a.vy)(t.updatePosDic)){const n=t.updatePosDic[i]
if(null!=n&&!M.t.IsBindState(n.state)){let t=!1
const i=k.f.Inst().getItemById(n.modelId)
if(i.marketSign==w.s.SKILLBOOK){if(It._.Inst_get().CanSell(n.modelId)){const e=i.GetRewardsSkillId()
t=!this.IsRoleNeed(e)}}else if(i.marketSign==w.s.ELEMENT_CARVE&&e&&It._.Inst_get().CanSell(n.modelId)){let e=!1
const s=i.Jobs_get()
for(const[t,i]of(0,a.V5)(h.Y.Inst.primaryRoleInfoList)){const t=i.Job_get()
if(b.b.IsWillJob(t,s)||b.b.IsWearJob(t,s)){e=!0
break}}t=!e}if(t){const t=new v.M(n.modelId,n)
let e=!1
for(let i=0;i<=s.Count()-1;i++)s[i].modelId_get()==n.modelId&&(s[i]=t,e=!0)
e||s.Add(t)}}}this.ShowGetTips()}IsRoleNeed(t){if(0==t)return!1
const e=h.Y.Inst.primaryRoleInfoList
for(let s=0;s<=e.Count();s++)if(null!=e[s]){const i=e[s]
let n=!1,l=0
for(const[e,s]of(0,a.V5)(i.Skills_get()))s.id==t&&(n=!0,l=s.level)
const o=I.j.Inst().GetSkillByIdLevel(t,l,!1)
if(l>=o.maxLevel)return!1
if(J.Q.cfg.GetJobVo(i.Job_get()).type==J.Q.cfg.GetJobVo(o.job).type){if(0==R.Z.GetJobBranch(i.Job_get()))return!0
if(R.Z.GetJobBranch(i.Job_get())==R.Z.GetJobBranch(o.job)||0==R.Z.GetJobBranch(o.job))return!0}}return!1}ShowGetTips(){if(!G.p.inst.IsInCopy()){const t=It._.Inst_get().itemQueue
t.Count()>0&&this.OpenGetMarketItemTip(t[0])}}ClearGetTips(){It._.Inst_get().itemQueue.Clear()}OpenNotice(){const t=(0,
r.T)("您关注的{0}上架了，快去看看吧"),e=new v.M(this.model.noticeitem),s=(this.model.IsRolandItemById(this.model.noticeitem),
this.model.GetNoticeFunType(this.model.noticeitem,null)),i=f.M.Replace(t,"{0}",e.GetNameStr(null,null,null)),n=new Q.N
n.showText=i,n.okhandler=(0,o.v)(this.HandleOpenNotice,this),n.objparams=s,n.cancelhandler=(0,o.v)(this.HandleNotOpenNotice,this),n.okText=(0,r.T)("查 看"),n.tipstype=2,
z.Z.Inst.OpenView(n)}ClearNoticeTips(){0!=this.model.noticeitem&&(this.model.noticeStack.Clear(),this.SendNotToNotify(),x.S.Inst_get().RemoveIcon(F.K.TRADINGMARKET_NOTICE))}
HandleOpenNotice(t){this.OpenBuyView(null,t)}SendNotToNotify(){0!=this.model.noticeitem&&this.nethandler.CM_SureFollowNotify(null)}HandleNotOpenNotice(){
this.model.noticeStack.RemoveAt(this.model.noticeStack.Count()-1),this.SendNotToNotify(),
this.model.noticeStack.Count()>0?(this.model.noticeitem=this.model.noticeStack[this.model.noticeStack.Count()-1].itemId,
this.model.noticeFunctype=this.model.GetNoticeFunType(this.model.noticeitem,this.model.noticeStack[this.model.noticeStack.Count()-1].isCross),
this.NoticeNew()):(this.model.noticeitem=0,x.S.Inst_get().RemoveIcon(F.K.TRADINGMARKET_NOTICE))}AddAttention(t){
this.model.IsFocused(t.itemId,null)?this.nethandler.CM_CancelMarketItemFollow(new C.Z([t.itemId]),null):this.nethandler.CM_MarketItemFollow(new C.Z([t.itemId]),null)}
AddAttionList(t,e){e?this.nethandler.CM_MarketItemFollow(t,null):this.nethandler.CM_CancelMarketItemFollow(t,null)}Search(t,e,s,i){
if(i==It._.FOCUS_SIGN)return void this.ReqAttention()
"0"==s&&(s=i)
let n=0
const l=f.M.String2Int(s)
if(l==It._.SKILLBOOK_SIGN||l==It._.SUIT_SIGN||l==It._.THREE_EXCELLENCE||l==It._.ELEMENT_CARVE){const t=this.model.itemmap[`${i}`]
null!=t&&(n=t.jobType/1e3)}this.SendSearchStallGoods(t,e,n,i)}SendSearchStallGoods(e,s,i,n){const l=this.model.itemmap[`${n}`]
this.model.screenId2Condition=new T.X
const o=f.M.String2Int(i)
if(this.model.screenId2Condition[t.JOB]=o<1||o>3?"":i,f.M.IsNullOrEmpty(l.itemSign)){l.itemSign=""
const t=this.model.GetTreeItem(this.model.GetViewType(l))
if(null!=t)for(let e=0;e<=t.count-1;e++)l.itemSign+=`,${t[e].itemSign}`}if(this.model.screenId2Condition[t.ITEMSIGN]=l.itemSign,this.model.screenId2Condition[t.NAME_FIX]="",
e)this.model.screenId2Condition[t.TRRANSFER]="",this.model.screenId2Condition[t.STAGE]="",this.model.screenId2Condition[t.EX]="",this.model.screenId2Condition[t.NAME]=""
else{const e=It._.Inst_get().menuSiftTypes
0==e[q.l.TRANSFER_TYPE]?this.model.screenId2Condition[t.TRRANSFER]="":this.model.screenId2Condition[t.TRRANSFER]=""+(e[q.l.TRANSFER_TYPE]-1),
this.model.screenId2Condition[t.STAGE]=this.CheckKind(e[q.l.STAGE_TYPE]),this.model.screenId2Condition[t.EX]=this.CheckKind(e[q.l.EX_TYPE]),this.model.screenId2Condition[t.NAME]=s,
l.itemSign==D.A.SKILLBOOK&&e[q.l.BOOK_TYPE]>0&&(this.model.screenId2Condition[t.NAME_FIX]=this.model.GetSkillBookName(e[q.l.BOOK_TYPE])),
f.M.IsNullOrEmpty(s)||(this.model.screenId2Condition[t.JOB]="",this.model.screenId2Condition[t.ITEM_SECOND_TYPE]="",this.model.screenId2Condition[t.STAGE]="",
this.model.screenId2Condition[t.EX]="")}this.ReqRefreshItems()}ReqRefreshItems(){if(null!=this.model.curTreeData&&this.model.curTreeData.id==It._.FOCUS_SIGN)this.ReqAttention()
else{const t=this.model.GetMarketItemList()
t.Count()>0?this.nethandler.CM_QueryPrice(t):It._.Inst_get().SetMarketScreenValue(t)}}OpenAttentionPanel(){const t=new _.v
t.isShowMask=!0,t.viewClass=ut.F,g.N.inst.OpenById(m.I.TradingMarketAttention,null,null,t)}CheckKind(t){return t<=0?"":`${t}`}GetBtnState(t){return t?p.D.eDisabled:p.D.eNormal}
BuyItem(t){const e=new v.M(t.itemId)
INS.itemTipManager.OpenTipView(e)}SetTrending(t,e,s){const i=this.model.GetTrendNum(s)
if(0==i)t.textSet(""),e.node.SetActive(!1)
else if(i>0){e.node.SetActive(!0),e.spriteNameSet("ryshichang_sp_0003")
const s=`[97322f]${f.M.ToFixed(100*i,0)}%[-]`
t.textSet(s)}else if(i<0){e.node.SetActive(!0),e.spriteNameSet("ryshichang_sp_0004")
const s=`[197514]${f.M.ToFixed(100*Math.abs(i),0)}%[-]`
t.textSet(s)}}SetTrendingEX(t,e,s){0==this.model.GetTrendNum(s)?(t.textSet(""),e.node.SetActive(!1)):this.SetTrending(t,e,s)}NoticeNew(){const t=new U.U(F.K.TRADINGMARKET_NOTICE)
x.S.Inst_get().AddIcon(t),x.S.Inst_get().UpdateCount(F.K.TRADINGMARKET_NOTICE,1)}ReqPrice(t,e){null==e&&(e=this.model.crossserver),this.nethandler.CM_QueryPrice(new C.Z([t]),e)}
ReqAttention(){It._.Inst_get().IsAttentionQuery=!0
const t=this.model.GetFollowItems(null)
t.Count()>0?this.nethandler.CM_QueryPrice(t,this.model.crossserver):It._.Inst_get().SetAttentionData(new C.Z)}UpdateHaveSeen(){
const t=j.p.inst.GetClientLogicSetting(W.R.TRADINGMARKET_IDS)
this.model.HandleClientSetting(t),this.model.HandleNewSign(),It._.Inst_get().RaiseEvent(It._.SEENLIST_UPDATE)}FollowTree(t){const e=this.model.GetTreeCfg(t),s=new C.Z
for(const[t,i]of(0,a.vy)(e))this.model.IsFocused(i.itemId,null)||s.Add(i.itemId)
0==s.Count()||this.nethandler.CM_MarketItemFollow(s,this.model.crossserver)}IsOpen_get(){return this.IsOpen}CancelFollowTree(t){const e=this.model.GetTreeCfg(t),s=new C.Z
for(const[t,i]of(0,a.vy)(e))this.model.IsFocused(i.itemId,null)&&s.Add(i.itemId)
0==s.Count()||this.nethandler.CM_CancelMarketItemFollow(s,null)}CheckItemNotify(){this.FocusItemDownTime()}FocusItemDownTime(){this.ClearNotifyTimer()
const t=c.D.serverMSTime_get()
let e=0
for(;e<this.model.noticeStack.Count();)if(0==this.model.noticeStack[e].num){
this.model.noticeStack[e].time.ToNum()+this.model.notifyDisappearTime<=t&&(this.model.noticeStack.RemoveAt(e),e-=1,e<0&&(e=0)),e+=1}this.CheckItemCallTime()}CheckItemCallTime(){
let t=0
for(let e=0;e<=this.model.noticeStack.Count()-1;e++)if(0==this.model.noticeStack[e].num){const s=this.model.noticeStack[e].time.ToNum();(0==t||s<t)&&(t=s)}
const e=t+this.model.notifyDisappearTime-c.D.serverMSTime_get()
e>0&&(this.notifyTimeId=u.C.Inst_get().SetInterval((0,o.v)(this.FocusItemDownTime,this),e)),this.HandleNoticeNew()}HandleNoticeNew(){
this.model.noticeStack.Count()<=0?(this.model.noticeitem=0,
x.S.Inst_get().RemoveIcon(F.K.TRADINGMARKET_NOTICE)):(this.model.noticeitem=this.model.noticeStack[this.model.noticeStack.Count()-1].itemId,
this.model.noticeFunctype=this.model.GetNoticeFunType(this.model.noticeitem,this.model.noticeStack[this.model.noticeStack.Count()-1].isCross),this.NoticeNew())}ClearNotifyTimer(){
this.notifyTimeId>-1&&(u.C.Inst_get().ClearInterval(this.notifyTimeId),this.notifyTimeId=-1)}OnLevelUp(){this.model.HandleNewSign()}OnFunCloseHandler(t){
t==E.x.ROLAND_TRADINGMARKET&&this.HandleCloseFun()}HandleCloseFun(){this.model.ClearCrossNotice(),this.HandleNoticeNew()}SignItems(t){this.AddSeenRange(t),
j.p.inst.SendClientLogicSetting(W.R.TRADINGMARKET_IDS,this.model.seenList)}AddSeenRange(t){for(let e=0;e<=t.Count()-1;e++){const s=f.M.String2Int(t[e])
;-1==this.model.seenList.IndexOf(s)&&this.model.seenList.Add(s)}}CheckOpenToMarketTip(){const t=It._.Inst_get().modelIdMap
for(const[e,s]of(0,a.vy)(t))if(1==s.sellNotice&&It._.Inst_get().IsOpenHorse(s.sellCond)&&!It._.Inst_get().showMarketRecordList.Contains(s.itemId)){
const t=A.g.Inst_get().GetItemsByModleID(s.itemId,null)
if(null!=t&&t.Count()>0){const e=t[0].baseData_get(),i=new v.M(e.cfgData_get().id)
i.serverData_set(e.serverData_get()),i.isForBag=!1,It._.Inst_get().showMarketRecordList.Add(s.itemId)
It._.Inst_get().itemQueue.Add(i),this.ShowGetTips()}}}SM_QueryMarketPriceResHandler(t){if(It._.Inst_get().m_lockSign=!1,
null==this.model.m_curSelectedData)null==this.model.getItem?this.model.IsAttentionQuery?It._.Inst_get().SetAttentionData(t.itemIdPriceInfo):It._.Inst_get().SetMarketScreenValue(t.itemIdPriceInfo):this.model.RaiseEvent(It._.GET_PRICE,t.itemIdPriceInfo[0])
else{this.model.HandleDatas(t.itemIdPriceInfo)
this.model.m_curSelectedData.itemId
const e=this.model.GetData(this.model.m_curSelectedData)
null!=e&&this.model.RaiseEvent(It._.GET_PRICE,e)}}SM_MarketItemPriceChangeHandler(e){Z.y.inst.ClientSysMessage(11041701),
null!=this.model.m_curSelectedData&&this.model.operationModel==It._.SELL_MODE?this.nethandler.CM_QueryPrice(new C.Z([this.model.m_curSelectedData.itemId])):t.Inst_Get().ReqRefreshItems()
}SM_ItemFollowNotifyHandler(e){const s=this.model.noticeStack
for(let t=s.Count()-1;t>=0;t+=-1)s[t].itemId==e.itemId&&s.RemoveAt(t)
const i=new $
i.itemId=e.itemId,i.time=e.time,i.num=e.num,i.isCross=e.isCross,s.Add(i),e.num>0?(this.model.noticeitem=e.itemId,this.model.noticeFunctype=e.isCross,
t.Inst_Get().NoticeNew()):t.Inst_Get().CheckItemNotify()}SM_BuyMarketItemSuccessHandler(t){INS.itemTipManager.CloseTipView()
const e=It._.Inst_get().resultScreen
if(e){for(let s=0;s<=e.Count()-1;s++)e[s].itemId==t.itemId&&(e[s].curCount=t.curCount)
It._.Inst_get().m_lockSign=!0,It._.Inst_get().RaiseEvent(O.g.RY_MARKET_GOOD_CHANGE)}}SM_UpdateMarketItemInfoHandler(t){INS.itemTipManager.CloseTipView()
const e=It._.Inst_get().resultScreen
if(e)for(let s=0;s<=e.Count()-1;s++)e[s].itemId==t.itemId&&(e[s].curCount=t.curCount,e[s].prize=t.price)
It._.Inst_get().m_lockSign=!0,It._.Inst_get().RaiseEvent(O.g.RY_MARKET_GOOD_CHANGE)}SM_MarketInfoHandler(t){
t.isCross?this.model.crossFollowItems=t.followItems:this.model.followitems=t.followItems,this.model.RaiseEvent(It._.FOLLOW_UPDATE,t.isCross)}SM_SellItemSuccessHandler(t){
INS.itemTipManager.CloseTipView()}SM_MarketScreenResVoHandler(t){It._.Inst_get().SetMarketScreenValue(t.resultScreen),It._.Inst_get().m_lockSign=!1}SM_MarketBuyRecodeHandler(t){
this.model.SetLog(t.buyRecodes),this.model.RaiseEvent(It._.RY_STALL_LOG_UPDATE)}SM_ServerMarketRecodeHandler(t){this.model.SetServerLog(t.sellRecodes),
this.model.RaiseEvent(It._.RY_STALL_LOG_UPDATE)}SM_MarketSellRecodeHandler(t){this.model.SetLog(t.sellRecodes),this.model.RaiseEvent(It._.RY_STALL_LOG_UPDATE)}},ct.JOB=1,
ct.ITEM_SECOND_TYPE=2,ct.STAGE=3,ct.EX=4,ct.NAME=5,ct.ITEMSIGN=6,ct.TRRANSFER=7,ct.NAME_FIX=8,ct.Inst=null,
bt(dt=ct,"Inst_Get",[i.Vx],Object.getOwnPropertyDescriptor(dt,"Inst_Get"),dt),
bt(dt.prototype,"SM_QueryMarketPriceResHandler",[K],Object.getOwnPropertyDescriptor(dt.prototype,"SM_QueryMarketPriceResHandler"),dt.prototype),
bt(dt.prototype,"SM_MarketItemPriceChangeHandler",[tt],Object.getOwnPropertyDescriptor(dt.prototype,"SM_MarketItemPriceChangeHandler"),dt.prototype),
bt(dt.prototype,"SM_ItemFollowNotifyHandler",[et],Object.getOwnPropertyDescriptor(dt.prototype,"SM_ItemFollowNotifyHandler"),dt.prototype),
bt(dt.prototype,"SM_BuyMarketItemSuccessHandler",[st],Object.getOwnPropertyDescriptor(dt.prototype,"SM_BuyMarketItemSuccessHandler"),dt.prototype),
bt(dt.prototype,"SM_UpdateMarketItemInfoHandler",[it],Object.getOwnPropertyDescriptor(dt.prototype,"SM_UpdateMarketItemInfoHandler"),dt.prototype),
bt(dt.prototype,"SM_MarketInfoHandler",[nt],Object.getOwnPropertyDescriptor(dt.prototype,"SM_MarketInfoHandler"),dt.prototype),
bt(dt.prototype,"SM_SellItemSuccessHandler",[lt],Object.getOwnPropertyDescriptor(dt.prototype,"SM_SellItemSuccessHandler"),dt.prototype),
bt(dt.prototype,"SM_MarketScreenResVoHandler",[ot],Object.getOwnPropertyDescriptor(dt.prototype,"SM_MarketScreenResVoHandler"),dt.prototype),
bt(dt.prototype,"SM_MarketBuyRecodeHandler",[at],Object.getOwnPropertyDescriptor(dt.prototype,"SM_MarketBuyRecodeHandler"),dt.prototype),
bt(dt.prototype,"SM_ServerMarketRecodeHandler",[rt],Object.getOwnPropertyDescriptor(dt.prototype,"SM_ServerMarketRecodeHandler"),dt.prototype),
bt(dt.prototype,"SM_MarketSellRecodeHandler",[ht],Object.getOwnPropertyDescriptor(dt.prototype,"SM_MarketSellRecodeHandler"),dt.prototype),dt)},35091:(t,e,s)=>{s.d(e,{_:()=>G})
var i=s(93984),n=s(38836),l=s(98800),o=s(2596),a=s(16812),r=s(70829),h=s(85682),d=s(35128),c=s(55360),I=s(98885),u=s(85602),p=s(38962),_=s(70850),g=s(99500),m=s(92679),S=s(33314),f=s(87923),C=s(37648),T=s(55492),y=s(75439),A=s(42534),v=s(33138),D=s(6383),w=s(92202),B=s(35259),M=s(19754),b=s(78485),O=s(95802),R=s(19519),L=s(78922)
class G extends a.k{constructor(){super(),this.menuSiftList=null,this.menuSiftTypes=null,this.curTreeData=null,this.openTabIndex=0,this.aucStartIndex=0,this.aucEndIndex=14,
this.titleList=null,this.sonDic=null,this.itemmap=null,this.treeDafaultData=null,this.logType=0,this.skillSigns=null,this.materalSigns=null,this.modelIdMap=null,
this.modelIdMapEx=null,this.resultScreen=null,this.aucAddVal=15,this.findIndex=-1,this.noticeitem=0,this.noticeStack=null,this.findItemId=0,this.getItem=null,this.itemQueue=null,
this.itemDic=null,this.noticeFunctype=0,this.select_item_tab=0,this.OpenSellItem=null,this.followitems=null,this.crossFollowItems=null,this.m_curSelectedData=null,
this.m_curSelectedDataId=null,this.operationModel=0,this.defaultTabIdx=0,this.screenId2Condition=null,this.m_lockSign=!1,this.IsAttentionQuery=!1,this.serverLogData=null,
this.notifyDisappearTime=null,this.seenList=null,this.titleContent=null,this.newSignBaseLevel=null,this.newSignBaseLevelCross=null,this.showMarketRecordList=null,
this.crossserver=!1,this.useInitSort=!1,this.newForFunDic=null,this.isClickPriceSort=null,this.type=null,this.logData=null,this.menuSiftTypes=new u.Z([0,0,0,0]),
this.titleList=new u.Z,this.sonDic=new p.X,this.itemmap=new p.X,this.treeDafaultData=new u.Z([null,null,null,null]),this.skillSigns=new u.Z,this.materalSigns=new u.Z,
this.modelIdMap=new p.X,this.modelIdMapEx=new p.X,this.resultScreen=new u.Z,this.noticeStack=new u.Z,this.itemQueue=new u.Z,this.itemDic=new p.X
let t=c.Y.Inst.GetOrCreateCsv(i.h.eTradingMarketLabelCsv)
this.itemmap=t.GetCsvMap()
let e=c.Y.Inst.GetOrCreateCsv(i.h.eMarketResource)
this.modelIdMap=e.GetCsvMap()
for(const[t,e]of(0,n.vy)(this.modelIdMap))this.modelIdMapEx.LuaDic_AddOrSetItem(e.itemId,e)
this.InitDic(),this.followitems=new u.Z,this.crossFollowItems=new u.Z,this.screenId2Condition=new p.X,
this.notifyDisappearTime=6e4*y.D.getInstance().GetIntValue("MARKET:STALL_NOTICE"),this.seenList=new u.Z,this.titleContent=new p.X,
this.newSignBaseLevel=y.D.getInstance().GetIntValue("MARKET:STALL_NEW_SIGN"),this.newSignBaseLevelCross=y.D.getInstance().GetIntValue("MARKET:STALL_NEW_SIGN_ROLAND"),
this.showMarketRecordList=new u.Z,this.newForFunDic=new p.X,this.newForFunDic[T.x.ROLAND_TRADINGMARKET]=!1,this.newForFunDic[T.x.TRADING_MARKET]=!1,this.HandleNewSign()}
static Inst_get(){return null==G._inst&&(G._inst=new G),G._inst}GetTreeData(t){const e=new u.Z,s=this.titleList
let i=null,l=0
null==t&&(t=this.crossserver)
let a=""
for(l=0;l<s.Count();){a="0",i=new o.y(0,s[l].id,a,s[l].firstTypeName,null,null)
const t=I.M.String2Int(s[l].id)
i.iconSpName=this.IconFromSign(t),i.guideId=h.D.UI_MARKET_ITEM,i.guideParam=I.M.String2Int(s[l].id),e.Add(i),l+=1}for(const[s,r]of(0,
n.V5)(this.sonDic))for(l=0;l<r.Count();)this.IsShowTitle(r[l],t)&&(a=`${s}`,i=new o.y(0,r[l].id,a,r[l].marketFirstName,null,null),i.guideId=h.D.UI_MARKET_ITEM,
i.guideParam=I.M.String2Int(r[l].id),e.Add(i)),l+=1
return this.FilterTreeTitleItem(e),e}FilterTreeTitleItem(t){let e=0
for(;e<=t.Count()-1;){if(I.M.String2Int(t[e].id)>2e4){this.HaveChild(t,t[e].id)||(t.RemoveAt(e),e-=1)}e+=1}}HaveChild(t,e){
for(let s=0;s<=t.Count()-1;s++)if(t[s].parentID==e)return!0
return!1}GetAttentionTreeData(){const t=new u.Z,e=this.titleList
let s=null,i=0
let l=""
for(i=0;i<e.Count();)1==e[i].isFocus&&(l="0",s=new o.y(0,e[i].id,l,e[i].firstTypeName,null,null),s.iconSpName=this.IconFromSign(I.M.String2Int(e[i].id)),
s.guideId=h.D.UI_MARKET_ITEM,s.guideParam=I.M.String2Int(e[i].id),t.Add(s)),i+=1
for(const[e,a]of(0,n.V5)(this.sonDic))for(i=0;i<a.Count();)1==a[i].isFocus&&this.IsShowTitle(a[i],null)&&(l=`${e}`,s=new o.y(0,a[i].id,l,a[i].marketFirstName,null,null),
s.guideId=h.D.UI_MARKET_ITEM,s.guideParam=I.M.String2Int(a[i].id),t.Add(s)),i+=1
return this.FilterTreeTitleItem(t),t}IconFromSign(t){let e=""
return e=t==G.SKILLBOOK_SIGN?"ryshichang_sp_0001":t==G.MATERIAL_SIGN?"ryshichang_sp_0002":1e4==t?"rybaitan_sp_0015":2e4==t?"rybaitan_sp_0020":t==G.SUIT_SIGN||t==G.THREE_EXCELLENCE?"ryshichang_sp_0011":t==G.ELEMENT_CARVE?"rybaitan_sp_0012":"",
e}GetTitleFirstChild(t){if(null==t){for(const[t,e]of(0,n.vy)(this.sonDic))return e[0]
return null}if(this.sonDic.LuaDic_ContainsKey(t))for(const[e,s]of(0,n.vy)(this.sonDic[t]))if(this.IsShowTitle(s,null))return s}GetTitleChild(t,e){
return this.sonDic.LuaDic_ContainsKey(t)?this.sonDic[t][e]:null}IsTreeTitle(t){for(const[e,s]of(0,n.vy)(this.titleList))if(s.id==t)return!0
return!1}InitDic(){let t=0
for(const[e,s]of(0,n.V5)(this.itemmap))if(t=I.M.String2Int(s.id),t%1e3==0)this.titleList.Add(s)
else{t=10*(t-t%1e3),this.HandleMarketSign(t,s.itemSign)
let e=null
this.sonDic.LuaDic_ContainsKey(t)?e=this.sonDic[t]:(e=new u.Z,this.sonDic.LuaDic_Add(t,e)),e.Add(s)}this.titleList.Sort(this.SonSortFunc)
for(const[t,e]of(0,n.V5)(this.sonDic))this.sonDic.LuaDic_IsNotNullValue(e)||e.Sort(this.SonSortFunc)}HandleMarketSign(t,e){
t==G.SKILLBOOK_SIGN?-1==this.skillSigns.IndexOf(e)&&this.skillSigns.Add(e):t==G.MATERIAL_SIGN&&-1==this.materalSigns.IndexOf(e)&&this.materalSigns.Add(e),
this.RaiseEvent(G.UPDATE_NEW_SIGN)}ResetMarketScreenSet(){const t=this.menuSiftTypes.count-1
for(let e=0;e<=t;e++)this.menuSiftTypes[e]=0
this.ResetAucIndex(),this.isClickPriceSort=0}ResetAucIndex(){this.aucStartIndex=0,this.aucEndIndex=14,this.resultScreen.Clear()}SonSortFunc(t,e){
return I.M.String2Int(t.typeIndex)-I.M.String2Int(e.typeIndex)}OnSortList(t,e){if(0==this.isClickPriceSort)return e.curCount-t.curCount
if(1==this.isClickPriceSort){if(t.prize==e.prize)return e.curCount-t.curCount
if(t.prize<e.prize)return 1
if(t.prize>e.prize)return-1}else if(2==this.isClickPriceSort){if(t.prize==e.prize)return e.curCount-t.curCount
if(t.prize<e.prize)return-1
if(t.prize>e.prize)return 1}}OnInitSortList(t,e){const s=t.curCount>=999,i=e.curCount>=999,n=e.curCount-t.curCount
return s&&!i?1:!s&&i?-1:0==n?t.itemId-e.itemId:n}PriceSortFunc(t,e){return I.M.String2Int(t.prize)-I.M.String2Int(e.prize)}SetMarketScreenValue(t){if(this.resultScreen=t,
this.useInitSort?this.resultScreen.Sort(this.CreateDelegate(this.OnInitSortList)):this.resultScreen.Sort(this.CreateDelegate(this.OnSortList)),
this.RaiseEvent(m.g.RY_MARKET_GOOD_CHANGE),null!=G.Inst_get().m_curSelectedData){G.Inst_get().m_curSelectedData.itemId
const t=G.Inst_get().GetData(G.Inst_get().m_curSelectedData)
null!=t&&G.Inst_get().RaiseEvent(G.GET_PRICE,t)}}SortMarketScreen(){this.resultScreen.Sort(this.CreateDelegate(this.OnSortList))}SetAttentionData(t){this.resultScreen.Clear(),
this.aucStartIndex=0,this.aucEndIndex=G.END_INDEX,this.resultScreen=t,this.resultScreen.Sort(this.CreateDelegate(this.OnSortList)),this.RaiseEvent(m.g.RY_MARKET_GOOD_CHANGE),
this.IsAttentionQuery=!1}GetSearchData(){return this.resultScreen}Type_set(t){this.type=t}Type_get(t){return this.type}GetDefualtTreeData(){if(0!=this.findItemId){
const t=v.f.Inst().getItemById(this.findItemId)
if(t.marketSign==g.s.SKILLBOOK){for(const[e,s]of(0,n.V5)(this.sonDic))if(e==G.SKILLBOOK_SIGN){let e=0
for(;e<s.Count();){if(s[e].jobType-s[e].jobType%1e3==t.job-t.job%1e3)return s[e]
e+=1}}return this.GetTitleChild(G.SKILLBOOK_SIGN,0)}return t.marketSign==g.s.WING?this.GetTitleChild(G.MATERIAL_SIGN,0):this.titleList[0]}
return 0!=this.noticeitem?this.titleList[1]:this.titleList[0]}GetMenuSelectStr(t){return this.GetMenuSiftName(t,this.menuSiftTypes[t])}InitMenuSiftList(t){let e="",s=null
if(this.menuSiftList=new u.Z,e=b.l.TYPE_ALL_DES[t],t==b.l.BOOK_TYPE){const i=this.menuSiftTypes[b.l.TRANSFER_TYPE]
if(e=this.GetMenuSiftName(t,0),s=this.GetRyStallMenuSiftData(t,0,e,this.CreateDelegate(this.RyStallMenuItemClick)),this.menuSiftList.Add(s),null!=this.curTreeData){
const n=I.M.String2Int(I.M.SubStringWithLen(this.curTreeData.id,3,1))
let l=null
l=0==i?this.GetAllSkillByJobkingAndTansfer(n,null):this.GetAllSkillByJobkingAndTansfer(n,i-1)
const o=l.count-1
for(let i=0;i<=o;i++){const n=l[i]
e=B.C.INSTANCE.GetSkillItemConsumeName(n),s=this.GetRyStallMenuSiftData(t,n.skillid,e,this.CreateDelegate(this.RyStallMenuItemClick)),this.menuSiftList.Add(s)}}
}else if(t==b.l.TRANSFER_TYPE){if(null!=this.curTreeData){const i=I.M.String2Int(I.M.SubStringWithLen(this.curTreeData.id,3,1)),n=b.l.TYPE_NUM[t]-1
for(let l=0;l<=n;l++){const n=this.GetAllSkillByJobkingAndTansfer(i,l-1);(0==l||n.Count()>0)&&(e=this.GetMenuSiftName(t,l),
s=this.GetRyStallMenuSiftData(t,l,e,this.CreateDelegate(this.RyStallMenuItemClick)),this.menuSiftList.Add(s))}}}else{const i=b.l.TYPE_NUM[t]-1
for(let n=0;n<=i;n++)e=this.GetMenuSiftName(t,n),s=this.GetRyStallMenuSiftData(t,n,e,this.CreateDelegate(this.RyStallMenuItemClick)),this.menuSiftList.Add(s)}}
GetAllSkillByJobkingAndTansfer(t,e){const s=new u.Z
for(const[i,n]of this.modelIdMap){const i=v.f.Inst().getItemById(n.itemId)
if(i.marketSign==g.s.SKILLBOOK){const l=Math.floor(i.job/1e3)
let o=!0
if(this.CanSell(n.itemId)?(l!=t||null!=e&&Math.floor(i.job%100/10)!=e)&&(o=!1):o=!1,o){const t=r.j.Inst().GetSkillCfgByItemId(n.itemId)
s.Add(t)}}}return s}GetMenuSiftName(t,e){if(0==e)return b.l.TYPE_ALL_DES[t]
let s=""
return t==b.l.BOOK_TYPE?s=this.GetSkillBookName(e):t==b.l.EX_TYPE?s=f.l.GetChineseNum2(e)+b.l.TYPE_DES[t]:(t==b.l.TRANSFER_TYPE&&(e-=1),s=f.l.getNumStr(e)+b.l.TYPE_DES[t]),s}
GetSkillBookName(t){const e=r.j.Inst().GetSkillById(t)
return B.C.INSTANCE.GetSkillItemConsumeName(e)}GetRyStallMenuSiftData(t,e,s,i){const n=new M.Q
return n.Type_set(t),n.Kind_set(e),n.ShowText_set(s),n.IsCurMenuType_set(this.IsCurMenuType(t,e)),n.Handler_set(i),n}IsCurMenuType(t,e){return this.menuSiftTypes[t]==e}
RyStallMenuItemClick(t,e){this.menuSiftTypes[t]=e,t==b.l.TRANSFER_TYPE&&(this.menuSiftTypes[b.l.BOOK_TYPE]=0),this.RaiseEvent(G.RY_STALL_MENU_ITEM_CLICK)}SetLog(t){this.logData=t,
this.logData.Sort(this.SortLog),this.RaiseEvent(G.RY_STALL_LOG_UPDATE)}SetServerLog(t){this.serverLogData=t,this.serverLogData.Sort(this.SortLog),
this.RaiseEvent(G.RY_STALL_LOG_UPDATE)}SortLog(t,e){return e.createTime.ToNum()-t.createTime.ToNum()}Log_Get(t){if(null==t&&(t=!1),t)return this.logData
const e=new u.Z
for(let t=0;t<=this.serverLogData.Count()-1;t++)this.CanBuy(this.serverLogData[t].itemId)&&e.Add(this.serverLogData[t])
return e}ClearLogData(t){this.logData=null}GetMarketSellLogList(t,e){const s=new u.Z
if(null==this.logData)return s
const i=20*(t-1)
let n=20*t-1
n>this.logData.recodeVo.count-1&&(n=this.logData.recodeVo.count-1)
for(let t=i;t<=n;t++)s.Add(this.logData.recodeVo[t])
return s}GetShowDataByMarketSign(t,e){return _.g.Inst_get().GetShowDataByMarketSign(t,e,null)}CanSell(t){const e=l.Y.Inst.PrimaryRoleInfo_get().Level_get(),s=this.GetMarketCfg(t)
if(null!=s){const t=this.InLevelRange(e,s.sellCond)
if(!t)return!1
const i=this.IsOpenHorse(s.sellCond)
return!!i&&!(!t||!i)}return!1}CanBuy(t){const e=l.Y.Inst.PrimaryRoleInfo_get().Level_get(),s=this.GetMarketCfg(t)
if(null!=s){const t=this.InLevelRange(e,s.buyCond)
if(!t)return!1
const i=this.IsOpenHorse(s.buyCond)
if(!i)return!1
if(t&&i)return!0}return!0}InLevelRange(t,e){const s=this.GetLevelConditionValue(e)
return t>=I.M.String2Int(s[0])&&t<=I.M.String2Int(s[1])}IsOpenHorse(t){const e=this.GetCondition(t,"ACTIVEHORSE")
if(null!=e){const t=I.M.String2Int(e.value),s=w.O.Inst_get().GetHorseData(t)
return!(null==s||!s.IsActive())}return!0}ItemCanTrade(t){return!!(this.CanSell(t.modelId_get())&&t.CanTrade()&&this.JudgeRolandById(t.modelId_get()))}GetTrendNum(t){
return(t.prize-t.lastDayPrice)/t.lastDayPrice}GetMarketCfg(t){return this.modelIdMapEx.LuaDic_GetItem(t)}GetRolandCfg(t){return null}IsFocused(t,e){
return this.GetFollowItems(e).IndexOf(t)>-1}GetFollowItems(t){return null==t&&(t=this.crossserver),t?this.crossFollowItems:this.followitems}GetTreeItem(t){return this.sonDic[t]}
GetViewType(t){return I.M.String2Int(t.id)}GetOneTreeTitleItem(t){const e=this.titleList.count-1
for(let s=0;s<=e;s++)if(this.titleList[s].id==t)return this.titleList[s]
return null}IsEquipType(t){return g.s.IsEquip(this.itemmap[`${t}`].itemSign)}IsWingType(t){return this.itemmap[`${t}`].itemSign==g.s.WING}IsBookType(t){
return this.itemmap[`${t}`].itemSign==g.s.SKILLBOOK}GetTreeCfg(t){t=I.M.String2Int(t)
const e=new u.Z
if(this.sonDic.LuaDic_ContainsKey(t))for(const[s,i]of(0,n.vy)(this.sonDic[t])){new u.Z([i.itemSign,i.jobType])
e.Add(i.itemSign)}else{t=I.M.IntToString(t)
const s=new u.Z([this.itemmap[t].itemSign,this.itemmap[t].jobType])
e.Add(s)}const s=new u.Z
for(const[t,i]of(0,n.vy)(e)){const t=this.GetAttentionList(i)
s.AddRange(t)}const i=e[0][0]
return i==g.s.SKILLBOOK?s.Sort(this.CreateDelegate(this.SortSkillBook)):i==g.s.SUIT||I.M.IndexOf(i,g.s.EQUIP)>-1?s.Sort(this.CreateDelegate(this.SortEquip)):i==g.s.ELEMENT_CARVE&&s.Sort(this.CreateDelegate(this.SortElementCarve)),
s}SortSkillBook(t,e){const s=r.j.Inst().GetSkillCfgByItemId(t.itemId),i=r.j.Inst().GetSkillCfgByItemId(e.itemId)
return r.j.Inst()._degf_compareSkillBook(s,i)}SortElementCarve(t,e){const s=v.f.Inst().getItemById(t.itemId),i=v.f.Inst().getItemById(e.itemId)
if(s.quality>i.quality)return 1
if(s.quality<i.quality)return-1
const n=S.Z.GetJobBranch(s.job),l=S.Z.GetJobBranch(i.job)
return n<l?-1:n>l?1:0}SortEquip(t,e){const s=v.f.Inst().getItemById(t.itemId),i=v.f.Inst().getItemById(e.itemId),n=s.job/1e3,l=i.job/1e3
if(n>l)return 1
if(n<l)return-1
if(s.equipStepLv>i.equipStepLv)return 1
if(s.equipStepLv<i.equipStepLv)return-1
const o=A.f.Inst().getItemById(t.itemId),a=A.f.Inst().getItemById(e.itemId)
let r=o.intPosition_get()
const h=f.l.getWearPosByPosition(r)
r=a.intPosition_get()
const d=f.l.getWearPosByPosition(r)
return h>d?1:h<d?-1:t.itemId-e.itemId}HandleDatas(t){for(const[e,s]of(0,n.vy)(t)){const t=this.GetData(s)
null!=t?(t.prize=s.prize,t.curCount=s.curCount,t.lastDayPrice=s.lastDayPrice):this.resultScreen.Add(s)}}GetData(t){for(const[e,s]of(0,
n.vy)(this.resultScreen))if(s.itemId==t.itemId)return s
return null}GetCostType(t){const e=this.GetMarketCfg(t)
return null!=e?e.currency:R.J.GOLD_DIAMOND_STR}GetMarketItemList(){const t=this.screenId2Condition,e=new u.Z
for(const[s,i]of(0,n.vy)(this.modelIdMap)){const s=v.f.Inst().getItemById(i.itemId),n=Math.floor(s.job/1e3)
let l=!0
this.CanBuy(i.itemId)&&this.JudgeCrossServerById(i.itemId)?""!=t[L.f.JOB]&&n!=I.M.String2Int(t[L.f.JOB])||""!=t[L.f.NAME_FIX]&&s.name!=t[L.f.NAME_FIX]?l=!1:""==t[L.f.ITEMSIGN]||I.M.Contains(t[L.f.ITEMSIGN],s.marketSign)?""!=t[L.f.TRRANSFER]&&Math.floor(s.job%100/10)!=I.M.String2Int(t[L.f.TRRANSFER])?l=!1:""==t[L.f.NAME]||I.M.Contains(s.name,t[L.f.NAME])||(l=!1):l=!1:l=!1,
l&&e.Add(i.itemId)}return e}GetShowItemList(t,e){const s=new u.Z
null==e&&(e=this.crossserver)
for(const[i,l]of(0,n.vy)(this.modelIdMap)){const i=v.f.Inst().getItemById(l.itemId),n=Math.floor(i.job/1e3)
let o=!0
e?this.IsRolandItem(l)||(o=!1):this.IsRolandItem(l)&&(o=!1),this.CanBuy(l.itemId)?0!=t.jobType&&n!=t.jobType/1e3?o=!1:I.M.Contains(t.itemSign,i.marketSign)||(o=!1):o=!1,
o&&s.Add(l.itemId)}return s}IsShowTitle(t,e){return this.GetShowItemList(t,e).Count()>0}GetAttentionList(t){const e=new u.Z
for(const[s,i]of(0,n.vy)(this.modelIdMap)){const s=v.f.Inst().getItemById(i.itemId),n=1e3*Math.floor(s.job/1e3)
if(this.CanBuy(i.itemId)&&this.JudgeCrossServer(i)&&s.marketSign==t[0]&&(t[1]==n||0==t[1])){const t=new D.c
t.itemId=i.itemId,e.Add(t)}}return e}JudgeMarketById(t){return this.modelIdMapEx.LuaDic_ContainsKey(t)?this.IsRolandItem(this.modelIdMapEx[t])?2:1:0}JudgeCrossServerById(t){
return!!this.modelIdMapEx.LuaDic_ContainsKey(t)&&this.JudgeCrossServer(this.modelIdMapEx[t])}JudgeRolandById(t){if(this.modelIdMapEx.LuaDic_ContainsKey(t)){
const e=C.P.Inst_get().IsFunctionOpened(T.x.ROLAND_TRADINGMARKET)
return!this.IsRolandItemById(t)||!!e}return!1}JudgeCrossServer(t){const e=this.IsRolandItem(t)
return!(!this.crossserver||!e)||!this.crossserver&&!e}IsRolandItemById(t){return!!this.modelIdMapEx.LuaDic_ContainsKey(t)&&this.IsRolandItem(this.modelIdMapEx[t])}IsRolandItem(t){
return 1==t.isRoland}IsAttentionedBySign(t){const e=this.GetTreeCfg(t)
for(const[t,s]of(0,n.vy)(e))if(!this.IsFocused(I.M.String2Int(s.itemId),null))return!1
return!0}ClearSelectedData(){this.m_curSelectedData=null,this.m_curSelectedDataId=null}GetLevelConditionValue(t){const e=this.GetCondition(t,"GTLevel")
if(null==e)return new u.Z([0,99999])
const s=e.value
return I.M.Split(s,",")}GetCondition(t,e){for(const[s,i]of(0,n.vy)(t))if(i.type==e)return i
return null}IsNewItem(t){v.f.Inst().getItemById(t),l.Y.Inst.m_primaryRoleInfo.Level_get()
const e=this.GetMarketCfg(t)
if(0==e.newTag)return!1
if(null!=e){const t=this.IsRolandItem(e)
if(this.UpBaseLevel(e.buyCond,t)){let t=this.GetSeenId(e)
if(-1==t)return!1
t=I.M.String2Int(t)
return-1==this.seenList.IndexOf(t)}return!1}}GetSeenId(t){if(0==t.newTag)return-1
if(2==t.newTag)return t.itemId
if(1==t.newTag){const e=v.f.Inst().getItemById(t.itemId)
for(const[t,s]of(0,n.vy)(this.sonDic))for(let t=0;t<=s.Count()-1;t++)if(s[t].itemSign==e.marketSign){const i=S.Z.GetJobType(e.job)
if(0==s[t].jobType||s[t].jobType/1e3==i)return s[t].id}}return-1}UpBaseLevel(t,e){null==e&&(e=!1)
const s=this.GetLevelConditionValue(t),i=e&&this.newSignBaseLevelCross||this.newSignBaseLevel
return I.M.String2Int(s[0])>=i}IsTitleNew(t){return 1==this.titleContent[t]}HandleNewSign(){this.titleContent.Clear()
for(const[t,e]of(0,n.vy)(this.newForFunDic))this.newForFunDic[t]=!1
for(const[t,e]of(0,n.vy)(this.modelIdMap))if(this.CanBuy(e.itemId)&&this.IsNewItem(e.itemId)){const t=v.f.Inst().getItemById(e.itemId),s=(this.GetMarketCfg(e.itemId),
1e3*d.p.FloorToInt(t.job/1e3)),i=this.GetSubTitle(t.marketSign,s)
this.titleContent[i]=!0
const n=I.M.IntToString(10*(i-i%1e3))
this.titleContent[n]=!0,this.IsRolandItemById(e.itemId)?this.newForFunDic[T.x.ROLAND_TRADINGMARKET]=!0:this.newForFunDic[T.x.TRADING_MARKET]=!0}this.RaiseEvent(G.UPDATE_NEW_SIGN)}
GetFunTypeByItemModelId(t){let e=T.x.TRADING_MARKET
return e=G.Inst_get().IsRolandItemById(t)?T.x.ROLAND_TRADINGMARKET:T.x.TRADING_MARKET,e}GetTabByFunType(t){
return t==T.x.TRADING_MARKET?O.U.TabMarketView:t==T.x.ROLAND_TRADINGMARKET?O.U.TabCrossServer:O.U.TabMarketView}ClearCrossNotice(){let t=0
for(;t<this.noticeStack.Count();)this.noticeStack[t].isCross&&(this.noticeStack.RemoveAt(t),t-=1),t+=1}SignItem(t){
2==this.GetMarketCfg(t).newTag&&L.f.Inst_Get().SignItems(new u.Z([t]))}SignTitle(t){const e=new u.Z
e.Add(t),e.Count()>0&&L.f.Inst_Get().SignItems(e)}GetSubTitle(t,e){for(const[s,i]of(0,n.vy)(this.itemmap))if(i.itemSign==t&&(0==i.jobType||e==i.jobType))return i.id
return 1e4}GetNoticeFunType(t,e){null==e&&(e=this.IsRolandItemById(t))
return e&&T.x.ROLAND_TRADINGMARKET||T.x.TRADING_MARKET}HandleClientSetting(t){this.seenList=new u.Z
const e=t.Count()
for(let s=0;s<=e-1;s++){const e=this.GetMarketCfg(t[s])
if(null!=e){const t=this.GetSeenId(e);-1!=t&&-1==this.seenList.IndexOf(t)&&this.seenList.Add(t)}else-1==this.seenList.IndexOf(t[s])&&this.seenList.Add(t[s])}}ResetData(){
this.ClearLogData(null),this.ClearSelectedData(),this.followitems=new u.Z,this.crossFollowItems=new u.Z,this.itemQueue.Clear(),this.noticeStack.Clear(),
this.showMarketRecordList.Clear()}}G.RY_STALL_LOG_UPDATE="RY_STALL_LOG_UPDATE",G.RY_STALL_MENU_ITEM_CLICK="RY_STALL_MENU_ITEM_CLICK",
G.RY_MARKET_GOOD_CHANGE="RY_MARKET_GOOD_CHANGE",G.SEENLIST_UPDATE="SEENLIST_UPDATE",G.FOLLOW_UPDATE="FOLLOW_UPDATE",G.OPEN_POP="OPEN_POP",G.UPDATE_NEW_SIGN="UPDATE_NEW_SIGN",
G.BUYVIEW=0,G.SELLVIEW=1,G.BUY_LOG=1,G.SELL_LOG=2,G.SKILLBOOK_SIGN=3e4,G.MATERIAL_SIGN=4e4,G.SUIT_SIGN=5e4,G.THREE_EXCELLENCE=6e4,G.ELEMENT_CARVE=7e4,G.FOCUS_SIGN="20000",
G.BUY_MODE=1,G.SELL_MODE=2,G.END_INDEX=14,G.GET_PRICE="GET_PRICE",G._inst=null},41632:(t,e,s)=>{s.d(e,{z:()=>I})
var i=s(18998),n=s(46282),l=s(36334),o=s(85602),a=s(96297),r=s(35091),h=s(1666),d=s(87455),c=s(87226)
class I extends c.d{InitView(){super.InitView(),this.tipBtn.node.position=new i.Vec3(209,326,0)}SubInitView(){this.iscross=!0
a.v.Inst_get().GetMainPanelFatherId()
this._subPanelDatas.Add(l.b.New(new o.Z([n.Z.ui_tradingmarket_buyview]),this.contentview,h.W)),
this._subPanelDatas.Add(l.b.New(new o.Z([n.Z.ui_tradingmarket_sellview]),this.contentview,d.i))}OnAddToScene(){r._.Inst_get().crossserver=!0,super.OnAddToScene()}GetTipId(){
return"MARKET:ROLAND_TIPS"}Clear(){r._.Inst_get().crossserver=!1,super.Clear()}Test1(){return!0}S_Test(){return!0}}},29001:(t,e,s)=>{s.d(e,{F:()=>f})
var i,n=s(6847),l=s(83908),o=s(46282),a=s(6508),r=s(31222),h=s(60130),d=s(98885),c=s(47786),I=s(78922),u=s(35091),p=s(5494),_=s(9057),g=s(63076),m=s(18152)
class S extends _.x{constructor(...t){super(...t),this.data=null}InitView(){super.InitView(),this.data=null}AddLis(){
u._.Inst_get().AddEventHandler(u._.FOLLOW_UPDATE,this.CreateDelegate(this.FollowUpdate)),this.m_handlerMgr.AddClickEvent(this.attentionbtn,this.CreateDelegate(this.AttentionClick))
}SetData(t){this.AddLis()
const e=new g.M(t.itemId)
e.IconType_Set(m.s.TRADINGMARKET_ICON_TYPE_2),e.iconExtraData=0,this.data=t,this.itemname.textSet(e.GetNameStr(!1,!1,"\n")),this.item.SetData(e)
const s=u._.Inst_get().IsFocused(t.itemId,null)
this.attentionbtn.SetValue(s)}RemoveLis(){u._.Inst_get().RemoveEventHandler(u._.FOLLOW_UPDATE,this.CreateDelegate(this.FollowUpdate))}AttentionClick(){
I.f.Inst_Get().AddAttention(this.data)}FollowUpdate(){const t=u._.Inst_get().IsFocused(this.data.itemId,null)
this.attentionbtn.SetValue(t)}Clear(){this.RemoveLis(),super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}}let f=(0,
n.s_)(p.I.TradingMarketAttention,o.Z.ui_tradingmarket_attentionpanel).register()(i=class extends((0,l.Ri)()){constructor(...t){super(...t),this.model=null,this.curData=null}
InitView(){super.InitView(),this.MyGrid.SetInitInfo("ui_tradingmarket_attentionitem",null,S),this.MyGrid.OnReposition_set(this.CreateDelegate(this.OnReposition)),this.InitTree(),
this.tiplab.textSet(c.x.Inst().getItemStrById(11041705))}OnReposition(){this.itemscrollview.ResetPosition()}gridRender(t){return new S(t[0])}InitTree(){if(null!=this.tree){
const t=u._.Inst_get().GetAttentionTreeData()
this.tree.SetSelectCallback(this.CreateDelegate(this.itemChangeHandler)),this.tree.SetData(t)}}CreateTreeItem(t){const e=new a.U
return e.setId(t,null,0),e}OnAddToScene(){this.AddLis(),this.model=u._.Inst_get(),
this.model.crossserver?this.curData=u._.Inst_get().GetTitleFirstChild(d.M.String2Int(this.tree.dataList[0].id)):this.curData=u._.Inst_get().GetTitleFirstChild(u._.SKILLBOOK_SIGN)}
AddLis(){this.m_handlerMgr.AddClickEvent(this.closebtn,this.CreateDelegate(this.PlayCloseTween)),
this.m_handlerMgr.AddClickEvent(this.attentionbtn,this.CreateDelegate(this.OnToggleChange)),
u._.Inst_get().AddEventHandler(u._.FOLLOW_UPDATE,this.CreateDelegate(this.OnFollowUpdate))}OnToggleChange(){const t=!this.attentionbtn.GetValue()
this.attentionbtn.SetValue(t),t?I.f.Inst_Get().FollowTree(this.curData.id):I.f.Inst_Get().CancelFollowTree(this.curData.id)}itemChangeHandler(t){this.curData=t
const e=u._.Inst_get().GetTreeCfg(this.curData.id)
this.MyGrid.data_set(e)
u._.Inst_get().IsAttentionedBySign(this.curData.id)
this.OnFollowUpdate()}RemoveLis(){u._.Inst_get().RemoveEventHandler(u._.FOLLOW_UPDATE,this.CreateDelegate(this.OnFollowUpdate))}PlayCloseTween(){
h.O.PlayNormalCloseTween(this.closebtn.node,this.CreateDelegate(this.OnCloseClick))}OnCloseClick(){r.N.inst.CloseById(p.I.TradingMarketAttention)}OnFollowUpdate(){
const t=u._.Inst_get().IsAttentionedBySign(this.curData.id)
this.attentionbtn.SetValue(t)}Clear(){this.RemoveLis(),super.Clear()}Destroy(){}Test1(){return!0}S_Test(){return!0}})||i},1666:(t,e,s)=>{s.d(e,{W:()=>A})
var i=s(18998),n=s(83908),l=s(86133),o=s(5924),a=s(61613),r=s(60130),h=s(85602),d=s(92679),c=s(78485),I=s(78922),u=s(35091),p=s(51868),_=s(85682),g=s(63076),m=s(67885),S=s(18152),f=s(87923),C=s(68637),T=s(19519)
class y extends((0,n.yk)()){constructor(...t){super(...t),this.data=null,this.basedata=null,this.index=void 0}InitView(){}SetData(t){if(null==t)return
this.AddEvent(),this.data=t
const e=a.v.GetAdaptionWidth(888,1168)
this.bg.widthSet(e),this.attentionBtn.node.x=e-76,this.goBtn.node.x=e-198,this.basedata=new g.M(this.data.itemId),this.basedata.isNoBagItemData=!0,
this.basedata.isShowRecommendIcon=!0,this.basedata.isForBag=!1,this.basedata.isCanOperate=!1,this.basedata.IconType_Set(S.s.TRADINGMARKET_ICON_TYPE_2)
let s=0
if(2==u._.Inst_get().GetMarketCfg(t.itemId).newTag){u._.Inst_get().IsNewItem(t.itemId)&&(s=1)}this.basedata.iconExtraData=s,this.item._enabledClickOpenTip=!1,
this.item._clickHandler=this.CreateDelegate(this.OnItemClick),this.item.SetData(this.basedata),this.itemname.textSet(this.basedata.GetNameStr(!1,!1,"\n")),
this.priceLab.textSet(t.prize.toString()),this.currencySp.spriteNameSet(T.J.GetCurrencyIconName(t.currencyType)),
t.curCount>99?this.sellnumlab.textSet("99+"):this.sellnumlab.textSet(t.curCount.toString())
const n=u._.Inst_get().IsFocused(t.itemId,!1)
this.attentionBtn.SetValue(n),I.f.Inst_Get().SetTrending(this.trendlab,this.trendicon,this.data)
const l=60+this.trendlab.width()+10
this.trendicon.node.position=new i.Vec3(l,1,0),this.HideEffect(),this.index==u._.Inst_get().findIndex&&this.PlayEffect()}AddEvent(){
this.goBtn.node.on(i.NodeEventType.TOUCH_END,this.CreateDelegate(this.GoToHandler)),this.attentionBtn.node.on(i.NodeEventType.TOUCH_END,this.CreateDelegate(this.OnAttentionClick)),
u._.Inst_get().AddEventHandler(u._.FOLLOW_UPDATE,this.CreateDelegate(this.FollowUpdate))}RemoveEvent(){
this.goBtn.node.off(i.NodeEventType.TOUCH_END,this.CreateDelegate(this.GoToHandler)),
this.attentionBtn.node.off(i.NodeEventType.TOUCH_END,this.CreateDelegate(this.OnAttentionClick)),
u._.Inst_get().RemoveEventHandler(u._.FOLLOW_UPDATE,this.CreateDelegate(this.FollowUpdate))}OnItemClick(){u._.Inst_get().SignItem(this.basedata.modelId_get()),
this.basedata.iconExtraData=0,this.item.RefreshComp(m.S.RIGHTUP_NEW),INS.itemTipManager.OpenTipView(this.basedata)}FollowUpdate(){
const t=u._.Inst_get().IsFocused(this.data.itemId,null)
this.attentionBtn.SetValue(t)}OnAttentionClick(){I.f.Inst_Get().AddAttention(this.data)}GoToHandler(){const t=new g.M(this.data.itemId)
t.isCanOperate=!1,I.f.Inst_Get().OpenBuyItem(this.data,u._.BUY_MODE,null),INS.itemTipManager.OpenTipView(t),this.HideEffect()}RegGuide(){
C.c.Inst.RegGameObject(_.D.UI_MARKET_GO_BTN,this.goBtn.node,this.index)}UnRegGuide(){C.c.Inst.UnRegGameObject(_.D.UI_MARKET_GO_BTN,this.index)}CheckGuide(){
f.l.CheckBtnClickTrigger(_.D.UI_MARKET_GO_BTN,this.index)}PlayEffect(){this.eff.SetActive(!0)}HideEffect(){this.eff.SetActive(!1)}Clear(){this.RemoveEvent(),this.HideEffect(),
u._.Inst_get().RemoveEventHandler(u._.FOLLOW_UPDATE,this.CreateDelegate(this.FollowUpdate))}Destroy(){}Test1(){return!0}S_Test(){return!0}}class A extends((0,n.pA)(p.$)()){
constructor(...t){super(...t),this.isSearchState=!1,this.isShowSearchList=!1,this.interval=-1,this.mainModel=null,this.oneShowDataList=null,this.delaySendTimer=null,
this.curBarVal=null,this.isUpdateBar=null,this.isPage=null,this.inited=null,this.curData=null,this.menuSiftTypes=null,this.isClickPriceSort=null}InitView(){super.InitView(),
this.grid.SetInitInfo("ui_tradingmask_buyitem",null,y),this.tree.SetSelectCallback(this.CreateDelegate(this.itemChangeHandler)),this.mainModel=u._.Inst_get(),
this.oneShowDataList=new h.Z,this.delaySendTimer=-1,this.curBarVal=0,this.isUpdateBar=!1,this.isPage=!0,r.O.SetAnchorPos(this.leftanchor,!0,!0,0,!0),
r.O.SetAnchorPos(this.rightanchor,!1,!0,0,!0),a.v.SetAdaptionPos(this.namelab,-251,-380,null),a.v.SetAdaptionPos(this.operatelab,314,480,null),
this.banner.widthSet(a.v.GetAdaptionWidth(888,1168)),this.bg1.widthSet(a.v.GetAdaptionWidth(700,972))
const t=a.v.GetAdaptionWidth(888,1168)
this.grid.cellWidthSet(t),this.itemScrollView.node.transform.width=t}gridRender(t){return new y(t[0])}InitTree(){this.tree.SetData(u._.Inst_get().GetTreeData(null)),
this.OnSeenListUpdate()}OnAttentionClick(){}SetData(t){super.SetData(t),this.inited=!1,this.inited||this.InitTree(),this.AddEvent(),this.exMenuView.InitData(c.l.EX_TYPE),
this.transferMenuView.InitData(c.l.TRANSFER_TYPE),this.bookMenuView.InitData(c.l.BOOK_TYPE),this.SetCurTreeData(),this.inited=!0}SetCurTreeData(){
0!=u._.Inst_get().noticeitem&&(u._.Inst_get().isClickPriceSort=0)}ResetGridData(){this.isUpdateBar=!0,this.itemList.SetLocalPositionXYZ(1e4,152,0)}AddEvent(){
this.m_handlerMgr.AddClickEvent(this.searchBtn,this.CreateDelegate(this.ClickSearchHandler)),
this.m_handlerMgr.AddClickEvent(this.highPricebtn,this.CreateDelegate(this.OnFocusClickHandler)),
this.m_handlerMgr.AddClickEvent(this.priceScreenlBtn,this.CreateDelegate(this.PriceScreenHandler)),
this.m_handlerMgr.AddClickEvent(this.mylogBtn,this.CreateDelegate(this.MyLogHandler)),
u._.Inst_get().AddEventHandler(u._.RY_STALL_MENU_ITEM_CLICK,this.CreateDelegate(this.MenuClickHander)),
u._.Inst_get().AddEventHandler(u._.RY_MARKET_GOOD_CHANGE,this.CreateDelegate(this.itemChangeUpdateHandler)),
u._.Inst_get().AddEventHandler(u._.SEENLIST_UPDATE,this.CreateDelegate(this.OnSeenListUpdate))}SearchLabChanged(){this.inited}RemoveEvent(){
u._.Inst_get().RemoveEventHandler(d.g.RY_STALL_MENU_ITEM_CLICK,this.CreateDelegate(this.MenuClickHander)),
u._.Inst_get().RemoveEventHandler(d.g.RY_MARKET_GOOD_CHANGE,this.CreateDelegate(this.itemChangeUpdateHandler)),
u._.Inst_get().RemoveEventHandler(u._.SEENLIST_UPDATE,this.CreateDelegate(this.OnSeenListUpdate)),this.UnRegGuide()}RegGuide(){}UnRegGuide(){}ReFreshHandler(){
this.mainModel.aucStartIndex=0,this.mainModel.aucEndIndex=14,this.SearchHandler(null)}PriceScreenHandler(){u._.Inst_get().isClickPriceSort=u._.Inst_get().isClickPriceSort+1,
u._.Inst_get().isClickPriceSort>2&&(u._.Inst_get().isClickPriceSort=0),this.UpdateSpriceScreen(),u._.Inst_get().SortMarketScreen(),this.grid.data_set(this.GetShowList()),
this.itemScrollView.content.transform.height=this.grid.cellHeight*this.grid.data_get().length}MyLogHandler(){I.f.Inst_Get().OpenLog(u._.BUY_LOG)}OnFocusClickHandler(){
I.f.Inst_Get().OpenAttentionPanel()}itemChangeHandler(t){const e=t
u._.Inst_get().curTreeData=e,this.curData!=e&&(this.curData=e,this.SetShowMenu(),this.isSearchState||this.SearchRestScreen(null),
this.curData.isParent()&&this.treeScrollView.scrollTo(new i.Vec2(0,1)),u._.Inst_get().SignTitle(e.id)),this.isSearchState=!1,this.searchlab.string=""}UpdateSpriceScreen(){
this.priceScreenSp.node.SetActive(2==u._.Inst_get().isClickPriceSort),this.priceScreenSp1.node.SetActive(1==u._.Inst_get().isClickPriceSort),
this.priceScreenSp2.node.SetActive(0==u._.Inst_get().isClickPriceSort)}itemChangeUpdateHandler(){const t=this.GetSearchData()
t.Count()>0?(this.itemList.SetLocalPositionXYZ(4,152,0),this.grid.data_set(this.GetShowList()),
this.itemScrollView.content.transform.height=this.grid.cellHeight*this.grid.data_get().length,this.mainModel.useInitSort=!1):this.itemList.SetLocalPositionXYZ(1e4,152,0),
this.noDataIcon.node.SetActive(null==t||0==t.count),this.curData.id==u._.FOCUS_SIGN?this.noDataIcon.textSet((0,l.T)("暂无关注物品")):this.noDataIcon.textSet((0,l.T)("暂无上架物品")),
this.mainModel.m_lockSign||(this.treeScrollView.scrollTo(new i.Vec2(0,1)),this.itemScrollView.scrollTo(0))}OnSeenListUpdate(){let t=u._.Inst_get().GetTreeData(null)
for(let e of t)if(e.isParent()){this.tree.GetTitleItem(e.id).node.getChildByName("newsp").SetActive(u._.Inst_get().IsTitleNew(e.id))}else{
this.tree.GetSubItem(e.id).node.getChildByName("newsp").SetActive(u._.Inst_get().IsTitleNew(e.id))}}GetSearchData(){return u._.Inst_get().GetSearchData()}OnDragStarted(){
this.isPage&&(this.ClearDelaySendTimerData(),this.curBarVal=0,this.delaySendTimer=o.C.Inst_get().SetFrameLoop(this.CreateDelegate(this.JudgeIsSendNextPage),1),
this.JudgeIsSendNextPage())}JudgeIsSendNextPage(){this.curBarVal,this.curBarVal=0}OnDragFinished(){this.isPage&&this.ClearDelaySendTimerData()}ClearDelaySendTimerData(){
o.C.Inst_get().ClearLoop(this.delaySendTimer),this.delaySendTimer=-1}SendUpdateItemList(){this.mainModel.aucEndIndex=this.mainModel.aucEndIndex+this.mainModel.aucAddVal,
this.mainModel.m_lockSign=!0,this.grid.data_set(this.GetShowList()),this.itemScrollView.content.transform.height=this.grid.cellHeight*this.grid.data_get().length}
GridOnReposition(){this.mainModel.findIndex>-1&&this.DelayUpdateScrollBar()}DelayUpdateScrollBar(){o.C.Inst_get().ClearInterval(this.interval)
this.itemScrollPanel.getComponent(i.UITransform).height}ClearData(){o.C.Inst_get().ClearInterval(this.interval),this.mainModel.isClickPriceSort=0,this.isSearchState=!1,
this.isShowSearchList=!1,this.RemoveEvent(),this.ClearDelaySendTimerData(),this.exMenuView.ClearData(),this.transferMenuView.ClearData(),this.bookMenuView.ClearData()}
MenuClickHander(t){I.f.Inst_Get().Search(!1,"",this.curData.parentID,this.curData.id)}SetShowMenu(){
null!=this.curData&&u._.Inst_get().IsBookType(this.curData.id)?(this.exMenuView.node.SetActive(!1),this.transferMenuView.node.SetActive(!0),
this.bookMenuView.node.SetActive(!0)):(this.exMenuView.node.SetActive(!1),this.bookMenuView.node.SetActive(!1),this.transferMenuView.node.SetActive(!1))}SearchRestScreen(t){
this.itemScrollBar.scrollTo(0),u._.Inst_get().ResetMarketScreenSet(),this.exMenuView.UpdateText(),this.transferMenuView.UpdateText(),this.bookMenuView.UpdateText(),
this.UpdateSpriceScreen(),I.f.Inst_Get().Search(!0,"",this.curData.parentID,this.curData.id)}SearchByTreeId(t){I.f.Inst_Get().Search(!0,"",this.curData.parentID,this.curData.id)}
ClickSearchHandler(t){this.SearchHandler(null)}SearchHandler(t){const e=this.searchlab.string
this.isSearchState=!0,this.isShowSearchList=!0,u._.Inst_get().ResetMarketScreenSet()
const s=this.GetDefaultTreedData()
this.tree.SelectById(s.id),I.f.Inst_Get().Search(!1,e,this.curData.parentID,this.curData.id)}GetDefaultTreedData(){return u._.Inst_get().GetDefualtTreeData()}GetShowList(){
this.mainModel.findIndex=-1
const t=this.GetSearchData()
if(0!=u._.Inst_get().findItemId)for(let t=0;t<=u._.Inst_get().resultScreen.Count()-1;t++)u._.Inst_get().resultScreen[t].itemId==u._.Inst_get().findItemId&&(u._.Inst_get().findItemId=0,
this.mainModel.findIndex=t)
if(0!=u._.Inst_get().noticeitem)for(let t=0;t<=u._.Inst_get().resultScreen.Count()-1;t++)u._.Inst_get().resultScreen[t].itemId==u._.Inst_get().noticeitem&&(I.f.Inst_Get().ClearNoticeTips(),
u._.Inst_get().noticeitem=0,this.mainModel.findIndex=t)
if(this.mainModel.findIndex>-1)for(;this.mainModel.aucEndIndex<this.mainModel.findIndex;)this.mainModel.aucEndIndex=this.mainModel.aucEndIndex+this.mainModel.aucAddVal
let e=this.mainModel.aucEndIndex+1
return e>t.Count()&&(e=t.Count()),t.GetRange(this.mainModel.aucStartIndex,e)}Clear(){super.Clear(),this.ClearDelaySendTimerData(),this.ClearData(),this.inited=!1,
null!=this.rytree&&this.rytree.Clear()}Destroy(){this.exMenuView.Destroy(),this.transferMenuView.Destroy(),this.bookMenuView.Destroy()}}},21979:(t,e,s)=>{s.d(e,{Y:()=>p})
var i,n=s(6847),l=s(83908),o=s(46282),a=s(31222),r=s(5494),h=s(75696),d=s(86209),c=s(19519),I=s(78922),u=s(35091)
let p=(0,n.s_)(r.I.TradingMarketGetItemTipView,o.Z.ui_tradingmarket_tipview).waitPrefab(h.j.CompListPath).register()(i=class extends((0,l.Ri)()){constructor(...t){super(...t),
this.getItem=null}InitView(){this.singlePriceLabel.textSet("0")}OnAddToScene(){this.AddOrRemoveLis(null),this.getItem=u._.Inst_get().getItem,this.ui_baseitem.SetData(this.getItem)
const t=u._.Inst_get().GetCostType(this.getItem.modelId_get()),e=c.J.GetCurrencyIconUrl(t)
this.currency.spriteNameSet(e),I.f.Inst_Get().ReqPrice(this.getItem.modelId_get(),u._.Inst_get().IsRolandItemById(this.getItem.modelId_get()))}AddOrRemoveLis(t){null==t&&(t=!0),
this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.CreateDelegate(this.OnCloseHandler))),
this.m_handlerMgr.AddClickEvent(this.leftButton,this.CreateDelegate(this.CreateDelegate(this.OnCloseHandler))),
this.m_handlerMgr.AddClickEvent(this.rightButton,this.CreateDelegate(this.CreateDelegate(this.OnGotoHandler))),
t?u._.Inst_get().AddEventHandler(u._.GET_PRICE,this.CreateDelegate(this.GetPriceHandler)):u._.Inst_get().RemoveEventHandler(u._.GET_PRICE,this.CreateDelegate(this.GetPriceHandler))
}GetPriceHandler(t){I.f.Inst_Get().SetTrendingEX(this.percentlab,this.trendicon,t)
const e=u._.Inst_get().GetMarketCfg(this.getItem.modelId_get()),s=Math.floor(t.prize*e.buyPriceRate/1e4)
this.singlePriceLabel.textSet(d.w.Instance.ConvertNumToString(s))}OnCloseHandler(){I.f.Inst_Get().CloseGetMarketItemTip(),I.f.Inst_Get().DequeueGetMarketItemTip(),
I.f.Inst_Get().ShowGetTips()}OnGotoHandler(){a.N.inst.ClearAllPanel(!0,!0,null,null),I.f.Inst_Get().OpenSellView(this.getItem),I.f.Inst_Get().CloseGetMarketItemTip(),
I.f.Inst_Get().ClearGetTips()}Clear(){u._.Inst_get().getItem=null,this.AddOrRemoveLis(!1),super.Clear()}Destroy(){}})||i},25705:(t,e,s)=>{s.d(e,{B:()=>C})
var i,n=s(18998),l=s(6847),o=s(83908),a=s(17409),r=s(46282),h=s(86133),d=s(5494),c=s(60130),I=s(85602),u=s(78922),p=s(35091),_=s(9057),g=s(63076),m=s(87923),S=s(19519)
class f extends _.x{InitView(){super.InitView()}AddLis(){}RemoveLis(){}Clear(){this.RemoveLis(),super.Clear()}SetData(t){const e=new g.M(t.itemId)
if(null!=t.transactionName){let e=""
e+=t.transactionName,this.playernamelab.textSet(e),this.pricecontainer.SetLocalPositionXYZ(80,4,0),this.playernamelab.node.SetLocalPositionXYZ(-110,12,0),
this.namelab.node.SetLocalPositionXYZ(-304,1,0)}else this.playernamelab.textSet(""),this.playernamelab.node.SetLocalPositionXYZ(-111,12,0),
this.namelab.node.SetLocalPositionXYZ(-284,1,0),this.pricecontainer.SetLocalPositionXYZ(80,4,0)
this.namelab.textSet(e.GetNameStr(null,null,"\n"))
let s=this.numlab.node.x
s=this.namelab.node.position.x+this.namelab.width()+2,this.numlab.textSet(` x${t.count}`),this.numlab.node.x=s,this.baseitem.SetData(e),
this.price.textSet(t.currencyCount.toString()),this.timelab.textSet(m.l.GetChineseDateTimeEx(t.createTime.ToNum(),null,!1,!0))
const i=S.J.GetCurrencyIconName(t.currencyType)
this.currencyicon.spriteNameSet(i)}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}}let C=(0,
l.s_)(d.I.TradingMarketLogPanel,r.Z.ui_tradingmarket_logpanel).register()(i=class extends((0,o.Ri)()){constructor(...t){super(...t),this.tab=0,this.crossserver=!1,
this.tabBtnList=null,this.model=null}InitView(){super.InitView(),this.tabBtnList=new I.Z,this.tabBtnList.Add(this.btn1),this.tabBtnList.Add(this.btn2),
this.MyGrid.SetInitInfo("ui_tradingmarket_logitem",null,f)}gridRender(t){return new f(t[0])}OnAddToScene(){this.AddLis(),this.model=p._.Inst_get(),
u.f.Inst_Get().SendTradingMarketLog(this.model.logType,!1),this.model.logType==p._.SELL_LOG?this.title.textSet((0,h.T)("市场出售")):this.title.textSet((0,h.T)("购买记录")),this.tab=0
const t=new I.Z
for(let e=0;e<=1;e++){const s=new I.Z
s[0]=e,0==e?this.model.logType==p._.SELL_LOG?s[1]=(0,h.T)("市场出售"):s[1]=(0,h.T)("市场购买"):this.model.logType==p._.SELL_LOG?s[1]=(0,h.T)("我的出售"):s[1]=(0,h.T)("我的购买"),t.Add(s)}
for(let e=0;e<=this.tabBtnList.Count()-1;e++)this.tabBtnList[e].SetData(t[e]),this.tabBtnList[e].clickHandler=this.CreateDelegate(this.OnTabSelect)
this.tabBtnList[this.tab].SetSelect(!0)}OnTabSelect(t){this.tab=t,u.f.Inst_Get().SendTradingMarketLog(this.model.logType,1==this.tab)}UpdatePanel(){
this.model.logType==p._.SELL_LOG?this.title.textSet((0,h.T)("我的出售")):this.title.textSet((0,h.T)("我的购买"))}AddLis(){
this.clostbtn.node.on(n.NodeEventType.TOUCH_END,this.CreateDelegate(this.PlayCloseTween)),p._.Inst_get().AddEventHandler(p._.RY_STALL_LOG_UPDATE,this.CreateDelegate(this.OnUpdate))
}RemoveLis(){this.clostbtn.node.off(n.NodeEventType.TOUCH_END,this.CreateDelegate(this.PlayCloseTween)),
p._.Inst_get().RemoveEventHandler(p._.RY_STALL_LOG_UPDATE,this.CreateDelegate(this.OnUpdate))}PlayCloseTween(){
c.O.PlayNormalCloseTween(this.clostbtn.node,this.CreateDelegate(this.OnCloseClick))}OnUpdate(){this.scrollview.scrollTo(new n.Vec2(0,1))
const t=this.model.Log_Get(1==this.tab)
this.MyGrid.data_set(t),this.scrollview.content.transform.height=97*t.length,null!=t&&t.Count()>0?this.nologIcon.node.SetActive(!1):(this.model.logType==p._.SELL_LOG?this.nologIcon.textSet("暂无出售记录"):this.nologIcon.textSet("暂无购买记录"),
this.nologIcon.node.SetActive(!0))}OnCloseClick(){(0,a.sR)(d.I.TradingMarketLogPanel)}Clear(){this.RemoveLis(),this.model.ClearLogData(),super.Clear()}Destroy(){}Test1(){return!0}
S_Test(){return!0}})||i},58408:(t,e,s)=>{var i,n=s(18998),l=s(57834),o=s(84501),a=s(92679),r=s(35091),h=s(9057)
class d extends h.x{constructor(...t){super(...t),this.curData=null}_initBinder(){super._initBinder(),this.TradingMarketMenuItem()}TradingMarketMenuItem(){}InitView(){
super.InitView(),this.curData=null}Clear(){if(super.Clear(),null!=this.itembtn){l.i.Get(this.itembtn.node).RemoveonClick(this.CreateDelegate(this.ClickHandler))}}Destroy(){
super.Destroy()}ClickHandler(t,e){null!=this.curData&&this.curData.CallBack()}SetData(t){null!=t&&(l.i.Get(this.itembtn.node).RegistonClick(this.CreateDelegate(this.ClickHandler)),
this.curData=t,this.splitGo.SetActive(!this.curData.IsFinalIndex_get()),this.curData.IsCurMenuType_get()?(this.text.string=`[E8C868]${this.curData.ShowText_get()}[-]`,
this.light.SetActive(!0)):(this.text.string=`[EBDFCE]${this.curData.ShowText_get()}[-]`,this.light.SetActive(!1)))}}
n._decorator.ccclass("TradingMarketMenuView")(i=class extends o.X{constructor(...t){super(...t),this._model=null,this.viewType=1,this._degf_ClickHanderOpen=void 0,
this._degf_ClickHanderClose=void 0,this._degf_ItemClickHander=void 0,this.type=null}_initBinder(){super._initBinder(),this._model=r._.Inst_get(),
this._degf_ClickHanderOpen=(t,e)=>this.ClickHander(!0),this._degf_ClickHanderClose=(t,e)=>this.ClickHander(!1),this._degf_ItemClickHander=t=>this.ItemClickHander(t)}InitView(){
super.InitView(),this.grid.SetInitInfo("ui_stall_market_menuitem_ry",null,d),this.type="Transfer",this.OnClose()}gridRender(t){return new d(t[0])}Clear(){this.grid.Clear()}
Destroy(){}InitData(t){this.viewType=null==t?1:t,this.AddOrRemoveLis(null),this.UpdateText(),this.InitItemState()}UpdateText(){
this.typeText.textSet(this._model.GetMenuSelectStr(this.viewType))}ClearData(){this.AddOrRemoveLis(!1),this.viewType=1}AddOrRemoveLis(t){null==t&&(t=!0),
t?(r._.Inst_get().AddEventHandler(a.g.RY_STALL_MENU_ITEM_CLICK,this._degf_ItemClickHander),r._.Inst_get().AddEventHandler(r._.OPEN_POP,this.CreateDelegate(this.PopHandler)),
l.i.Get(this.typeCloseBtn.node).RegistonClick(this._degf_ClickHanderClose),
l.i.Get(this.typeOpenBtn.node).RegistonClick(this._degf_ClickHanderOpen)):(r._.Inst_get().RemoveEventHandler(r._.OPEN_POP,this.CreateDelegate(this.PopHandler)),
r._.Inst_get().RemoveEventHandler(a.g.RY_STALL_MENU_ITEM_CLICK,this._degf_ItemClickHander),l.i.Get(this.typeCloseBtn.node).RemoveonClick(this._degf_ClickHanderClose),
l.i.Get(this.typeOpenBtn.node).RemoveonClick(this._degf_ClickHanderOpen))}PopHandler(t){this.viewType!=t&&this.OnClose()}ClickHander(t){
t?(r._.Inst_get().RaiseEvent(r._.OPEN_POP,this.viewType),this.scrollView.node.SetActive(!0),this.grid.data_set(this.GetTypeList(this.viewType)),this.grid.node.SetActive(!0),
this.bg.node.SetActive(!0),this.typeOpenBtn.node.SetActive(!1),this.typeCloseBtn.node.SetActive(!0)):this.OnClose()}OnClose(){this.scrollView.node.SetActive(!1),
this.grid.node.SetActive(!1),this.bg.node.SetActive(!1),this.typeOpenBtn.node.SetActive(!0),this.typeCloseBtn.node.SetActive(!1)}GetTransferList(){
return this._model.auctionMenuDataList}GetTypeList(){this._model.InitMenuSiftList(this.viewType)
return this._model.menuSiftList}ItemClickHander(t){this.InitItemState()}InitItemState(){this.grid.node.SetActive(!1),this.bg.node.SetActive(!1),this.typeOpenBtn.node.SetActive(!0),
this.typeCloseBtn.node.SetActive(!1),this.UpdateText()}})},91322:(t,e,s)=>{s.d(e,{X:()=>j})
var i,n=s(18998),l=s(21370),o=s(6847),a=s(83908),r=s(46282),h=s(86133),d=s(98800),c=s(97461),I=s(70829),u=s(57834),p=s(5494),_=s(98130),g=s(98885),m=s(85602),S=s(52212),f=s(79534),C=s(14772),T=s(84229),y=s(21554),A=s(70850),v=s(3859),D=s(69015),w=s(92679),B=s(74045),M=s(49067),b=s(93078),O=s(87923),R=s(86209),L=s(62849),G=s(26195),P=s(37828),E=s(33138),k=s(63945),N=s(8211),V=s(65550),x=s(39043),F=s(19519),U=s(78922),H=s(35091)
let j=(0,o.s_)(p.I.TradingMarketOperation,r.Z.ui_tradingmarket_operation).layerSet(l.T.tip).register()(i=class extends((0,a.Ri)()){constructor(...t){super(...t),this.data=null,
this.curBuyCount=1,this.nextPrice=0,this.currencyType=null,this.curPrice=0,this.curMoney=0,this.normalColor=null,this.disableColor=null,this._degf_AddHandler=null,
this._degf_OnAddButtonClick=null,this._degf_OnBuyButtonClick=null,this._degf_OnCloseHandler=null,this._degf_OnSubButtonClick=null,this._degf_SelectUseNumHandler=null,
this._degf_OnSetMaxBuyCountClick=null,this.maxBuyCount=0,this.curSellPrice=null,this.mode=null,this.tipIndex=null,this.waiting_price=null,this._degf_GotoBuy=null}_initBinder(){
super._initBinder(),this.normalColor=new n.Color(204,.796*255,195.84),this.disableColor=new n.Color(.8706*255,37.0005,36.006),this._degf_AddHandler=(t,e)=>this.AddHandler(t,e),
this._degf_OnAddButtonClick=(t,e)=>this.OnAddButtonClick(t,e),this._degf_OnBuyButtonClick=(t,e)=>this.OnBuyButtonClick(t,e),this._degf_OnCloseHandler=t=>this.OnCloseHandler(t),
this._degf_OnSubButtonClick=(t,e)=>this.OnSubButtonClick(t,e),this._degf_SelectUseNumHandler=(t,e)=>this.SelectUseNumHandler(t,e),this._degf_OnSetMaxBuyCountClick=()=>{
this.OnSetMaxBuyCount()}}InitView(){this.curSellPrice=0}OnAddToScene(){if(this.AddOrRemoveLis(null),this.mode=H._.Inst_get().operationModel,
this.data=H._.Inst_get().m_curSelectedData,null==this.data)return
this.currencyType=H._.Inst_get().GetCostType(this.data.itemId),this.curMoney=F.J.GetGold(d.Y.Inst.PrimaryRoleInfo_get(),this.currencyType)
const t=F.J.GetCurrencyIconUrl(this.currencyType)
this.currencyUp.spriteNameSet(t),this.currencyDown.spriteNameSet(t),this.mode==H._.BUY_MODE?(this.singlePriceLabel.textSet(R.w.Instance.ConvertNumToString(this.data.prize)),
U.f.Inst_Get().SetTrending(this.percentlab,this.trendicon,this.data),this.buyBtnLabel.textSet("购 买"),this.titlelab.textSet((0,h.T)("购买数量")),this.SetMaxBuyCount(),
this.SetBuyCount(1),this.tipIndex=this.AddToLayout()):(this.waiting_price=!0,U.f.Inst_Get().ReqPrice(this.data.itemId,null),this.singlePriceLabel.textSet("0"),
this.buyBtnLabel.textSet("出 售"),this.titlelab.textSet((0,h.T)("出售数量")),this.SetMaxSellCount(),this.SetBuyCount(this.data.curCount),this.tipIndex=this.AddToLayout())}AddToLayout(){
const[t,e]=[0,140.6],[s,i]=[325,267]
return D.g.Inst_get().AddTipByParam(null,D.g.HorizontalAlign.Right,D.g.VerticalAlign.Down,new S.F(t,e),new S.F(s,i))}SetBuyCount(t){if(0==this.data.curCount){
const e=O.l.SetStringColor(O.l.txtRedStr,g.M.IntToString(t))
this.countLabel.textSet(e)}else this.countLabel.textSet(g.M.IntToString(t))
this.curBuyCount=t
let e=0
e=this.mode==H._.SELL_MODE?this.curSellPrice:this.data.prize
const s=t*e
this.curPrice=s,this.mode==H._.BUY_MODE&&(this.curPrice<=this.curMoney?this.totallab.SetColor(this.normalColor):this.totallab.SetColor(this.disableColor)),
this.totallab.textSet(R.w.Instance.ConvertNumToString(this.curPrice))}SetMaxBuyCount(){let t=Math.floor(this.curMoney/this.data.prize)
t=Math.min(t,this.data.curCount),t=Math.min(t,99),t=Math.max(1,t),this.maxBuyCount=t}SetMaxSellCount(){this.maxBuyCount=this.data.curCount}OnSetMaxBuyCount(){
this.SetBuyCount(this.maxBuyCount)}AddOrRemoveLis(t){null==t&&(t=!0),t?(u.i.Get(this.addButton.node).RegistonClick(this._degf_OnAddButtonClick),
u.i.Get(this.leftButton.node).RegistonClick(this._degf_OnSubButtonClick),u.i.Get(this.buyBtn.node).RegistonClick(this._degf_OnBuyButtonClick),
u.i.Get(this.countLabel.node).RegistonClick(this._degf_SelectUseNumHandler),c.i.Inst.AddEventHandler(w.g.BASE_TIP_CLOSE,this._degf_OnCloseHandler),
this.m_handlerMgr.AddClickEvent(this.maxBtn.node,this.CreateDelegate(this.OnSetMaxBuyCount)),
H._.Inst_get().AddEventHandler(H._.GET_PRICE,this.CreateDelegate(this.GetPriceHandler))):(u.i.Get(this.addButton.node).RemoveonClick(this._degf_OnAddButtonClick),
u.i.Get(this.leftButton.node).RemoveonClick(this._degf_OnSubButtonClick),u.i.Get(this.buyBtn.node).RemoveonClick(this._degf_OnBuyButtonClick),
u.i.Get(this.countLabel.node).RemoveonClick(this._degf_SelectUseNumHandler),c.i.Inst.RemoveEventHandler(w.g.BASE_TIP_CLOSE,this._degf_OnCloseHandler),
H._.Inst_get().RemoveEventHandler(H._.GET_PRICE,this.CreateDelegate(this.GetPriceHandler)))}GetPriceHandler(t){this.data.prize=t.prize,this.data.lastDayPrice=t.lastDayPrice,
U.f.Inst_Get().SetTrending(this.percentlab,this.trendicon,this.data)
const e=H._.Inst_get().GetMarketCfg(this.data.itemId)
this.mode==H._.BUY_MODE?this.singlePriceLabel.textSet(R.w.Instance.ConvertNumToString(this.data.prize)):(this.curSellPrice=Math.floor(this.data.prize*e.buyPriceRate/1e4),
this.singlePriceLabel.textSet(R.w.Instance.ConvertNumToString(this.curSellPrice))),this.SetBuyCount(this.curBuyCount)}OnCloseHandler(t){U.f.Inst_Get().CloseMarketBuyTip()}
SelectUseNumHandler(t,e){
"HORSE_SHOW"==E.f.Inst().getItemById(this.data.itemId).sign?b.F.Instance_get().OpenView(new f.P(303,k.x.inst.buyTipPos.y-205,0),this._degf_AddHandler):b.F.Instance_get().OpenView(new f.P(363,k.x.inst.buyTipPos.y-205,0),this._degf_AddHandler)
}AddHandler(t,e){10==t?this.curBuyCount=1:e?this.curBuyCount=t:(this.curBuyCount*=10,this.curBuyCount+=t),this.curBuyCount<=0&&(this.curBuyCount=1),
this.curBuyCount=Math.min(this.curBuyCount,this.maxBuyCount),this.SetBuyCount(this.curBuyCount)}OnBuyButtonClick(t,e){this.CheckCanBuy()&&this.BuyHandle()}TrySell(t){
U.f.Inst_Get().RemoveGetMarketItemTip(this.data.itemId),
U.f.Inst_Get().nethandler.CM_SellItem(H._.Inst_get().m_curSelectedDataId,_.GF.INT(t),this.data.prize,H._.Inst_get().crossserver),U.f.Inst_Get().CloseMarketBuyTip(),
INS.itemTipManager.CloseTipView()}SendBuyHandler(t){
if(null!=this.data)if(this.mode==H._.BUY_MODE)U.f.Inst_Get().nethandler.CM_BuyMarketItem(this.data.itemId,_.GF.INT(t),this.data.prize,H._.Inst_get().crossserver)
else if(P.b.GetInst().GetEleCarveItemById(this.data.itemId)){if(H._.Inst_get().m_curSelectedDataId){const e=A.g.Inst_get().GetItemById(H._.Inst_get().m_curSelectedDataId)
if(e){const s=e.serverData_get()
if(s&&s.totalExp.ToNum()>0){const s=new M.B
s.infoId="ELEMENT_CARVE:TIPS3",s.cancelText="暂不出售",s.confirmText="立即重置",s.confirmHandle=()=>{L.A.GetInst().TryLevelReset(e.baseData_get(),!1)},
s.confirmParam=[this.data.itemId,this.data.prize,t,H._.Inst_get().m_curSelectedDataId],s.replaceParams.Add(e.baseData_get().GetNameStr(!1,null,null)),B.t.Inst().Open(s),
U.f.Inst_Get().CloseMarketBuyTip(),INS.itemTipManager.CloseTipView()}else this.TrySell(t)}}}else this.TrySell(t)}OnSubButtonClick(t,e){1==this.curBuyCount||(this.curBuyCount-=1,
this.SetBuyCount(this.curBuyCount))}OnAddButtonClick(t,e){-1!=this.maxBuyCount&&this.maxBuyCount<=this.curBuyCount||(this.curBuyCount+=1,this.SetBuyCount(this.curBuyCount))}
CheckCanBuy(){return!0}PopTip(t,e){const s=new M.B
s.infoId=t,s.replaceParams=e,s.cancelText=(0,h.T)("坚持购买"),s.cancelHandle=this._degf_GotoBuy,s.confirmText=(0,h.T)("放弃购买"),y.J.Inst_get().CloseTipView(),B.t.Inst().Open(s)}
GotoBuy(t){this.ReadData(),this.BuyHandle()}ReadData(){this.data=k.x.inst.m_curSelectedData,this.curBuyCount=N.N.GetInst().curBuyCount,this.curPrice=N.N.GetInst().curPrice,
this.curMoney=N.N.GetInst().curMoney}BuyHandle(){if(this.mode==H._.BUY_MODE){if(this.curPrice>this.curMoney)return V.y.inst.ClientStrMsg(null,"货币不足"),
U.f.Inst_Get().CloseMarketBuyTip(),void y.J.Inst_get().CloseTipView()
const t=E.f.Inst().getItemById(this.data.itemId)
if(null==t)return
if(t.itemType==v.q.EQUIPJEWEL||t.itemType==v.q.EQUIPJEWELSMELT||t.itemType==v.q.EQUIPJEWELMATERIAL){
if(G.j.Inst_get().emptySize_get()<1)return void V.y.inst.ClientSysMessage(102521)}else if(A.g.Inst_get().getBagEmptyGridNum()<1)return void V.y.inst.ClientSysMessage(101001)}
this.SendBuyHandler(this.curBuyCount)}CheckSkillBook(t){const e=this.data.Cfg_get().itemId
let s=null
const i=t.Rewards_get()
if(0!=i.typevalues.Count()){const t=i.typevalues[0].value,e=g.M.Split(t,":")
if(!O.l.IsEmptyStr(t)&&e.count>=1){const t=`${g.M.String2Int(e[0])}_1`
s=I.j.Inst().GetSkillByStrId(t)}}if(O.l.IsSkillLearnedByItemId(e)&&null!=s){const t=s.name,e="MALL:SKILLBOOK_BUY_CONFIRM3"
if(!x.V.Inst_get().GetData(x.V.Inst_get().GetRolePrefix()+e)){const s=new m.Z
return s.Add(t),this.PopTip(e,s),!1}}return!0}CheckExpandItem(){
if(A.g.Inst_get().bagSize_get()==A.g.Inst_get().maxBagSize_get()&&A.g.Inst_get().warehouseSize_get()==A.g.Inst_get().maxWarehouseSize_get()){
const t="BAG_AND_WAREHOUSE:UNLOCK_OVERFLOW"
if(!x.V.Inst_get().GetData(x.V.Inst_get().GetRolePrefix()+t)){const e=new m.Z
return this.PopTip(t,e),!1}}return!0}CheckAsuramRenameItem(){if(null==T.Q.Inst_get().AsuramData_get()){const t="RENAME:NOT_IN_ASURAM_NOTICE"
if(!x.V.Inst_get().GetData(x.V.Inst_get().GetRolePrefix()+t)){const e=new m.Z
return this.PopTip(t,e),!1}}const t=d.Y.Inst.PrimaryRoleInfo_get().AllianceJob_get()
if(t!=C.o.Leader&&t!=C.o.ViceLeader){const t="RENAME:ASURAM_JOB_NOTICE"
if(!x.V.Inst_get().GetData(x.V.Inst_get().GetRolePrefix()+t)){const e=new m.Z
return this.PopTip(t,e),!1}}return!0}Clear(){this.waiting_price=!1,b.F.Instance_get().CloseView(),null!=this.tipIndex&&(D.g.Inst_get().RemoveByTip(),this.tipIndex=null),
this.curBuyCount=1,this.curMoney=0,this.curSellPrice=0,this.AddOrRemoveLis(!1),H._.Inst_get().ClearSelectedData(),H._.Inst_get().operationModel=0,this.data=null,super.Clear()}
Destroy(){}})||i},87455:(t,e,s)=>{s.d(e,{i:()=>m})
var i=s(18998),n=s(83908),l=s(5924),o=s(51868),a=s(61613),r=s(85602),h=s(97415),d=s(18152),c=s(3859),I=s(92679),u=s(47786),p=s(6383),_=s(78922),g=s(35091)
class m extends((0,n.pA)(o.$)()){constructor(...t){super(...t),this.intervalId=-1,this.iscross=!1,this.itemcount=0,this.btn_tabs=null,this.bagShowGrid=null,this.model=null,
this.itemDataList=null}InitView(){super.InitView(),this.btn_tabs=new r.Z([this.btn_tab_0,this.btn_tab_1,this.btn_tab_2]),this.bagShowGrid=new h.H,
this.bagShowGrid.Init(this.con_grid,null,this.scrollview),this.bagShowGrid._enabledClickOpenTip=!1,
this.iscross?this.tiplab.textSet(u.x.Inst().getItemStrById(11041708)):this.tiplab.textSet(u.x.Inst().getItemStrById(11041704))}SetData(){
if(this.banner.widthSet(a.v.GetAdaptionWidth(970,1e3)),g._.Inst_get().select_item_tab=0,g._.Inst_get().crossserver?this.btn_tab_1.SetText("元素刻印"):this.btn_tab_1.SetText("技能书"),
this.AddLis(),this.bagShowGrid.ClickHandler=this.CreateDelegate(this.ClickItemHandler),this.UpdatePanel(!0),null!=this.model.OpenSellItem){
const t=this.GetItemById(this.model.OpenSellItem)
t>-1&&this.SetScrollBar(t)}}AddLis(){for(let t=0;t<=this.btn_tabs.Count()-1;t++)this.m_handlerMgr.AddClickEvent(this.btn_tabs[t],(()=>{this.OnClickBtnTab(t,null)}))
this.m_handlerMgr.AddEventMgr(I.g.BAG_UPDATE,this.CreateDelegate(this.DelayUpdatePanel)),this.m_handlerMgr.AddClickEvent(this.sellbtn,this.CreateDelegate(this.SellBtnClick))}
DelayUpdatePanel(){-1==this.intervalId&&(this.intervalId=l.C.Inst_get().SetInterval(this.CreateDelegate(this.UpdatePanel),100,1))}SellBtnClick(){
_.f.Inst_Get().OpenLog(g._.SELL_LOG)}UpdatePanel(t){null==t&&(t=!0),-1!=this.intervalId&&(l.C.Inst_get().ClearInterval(this.intervalId),this.intervalId=-1),
this.model=g._.Inst_get(),this.UpdateTab(t)}RemoveLis(){}SetScrollBar(t){null==t&&(t=0)
m.COLUMN_CNT,m.ROW_CNT
let e=t+1
const s=m.COLUMN_CNT
e%s!=0&&(e=e-e%s+s)
let i=this.itemcount
i%s!=0&&(i=i-i%s+s)
this.bagShowGrid.Update()}OnClickBtnTab(t,e){this.scrollview.scrollTo(new i.Vec2(0,1)),g._.Inst_get().select_item_tab=t,this.UpdateTab(!1)}UpdateTab(t){
for(let t=0;t<=this.btn_tabs.Count()-1;t++){let e=this.btn_tabs[t]
t==g._.Inst_get().select_item_tab?(e.target.getComponent(i.Sprite).spriteFrame=e.pressedSprite,
this.btn_tabs[t].interactable=!1):(e.target.getComponent(i.Sprite).spriteFrame=e.normalSprite,this.btn_tabs[t].interactable=!0)}let e=new r.Z
0==g._.Inst_get().select_item_tab?e=g._.Inst_get().GetShowDataByMarketSign(null,!0):1==g._.Inst_get().select_item_tab?e=g._.Inst_get().crossserver?g._.Inst_get().GetShowDataByMarketSign(new r.Z([c.q.elementCarve]),!0):g._.Inst_get().GetShowDataByMarketSign(this.model.skillSigns,!0):2==g._.Inst_get().select_item_tab&&(e=g._.Inst_get().GetShowDataByMarketSign(this.model.materalSigns,!0))
let s=0
this.itemDataList=new r.Z
for(let t=0;t<=e.Count()-1;t++){const i=e[t]
null!=i?(this.itemDataList.Add(i.baseData_get()),null!=i.baseData_get()&&(i.baseData_get().isCanOperate=!1,i.baseData_get().isEquipCompare=!1,
i.baseData_get().IconType_Set(d.s.TRADINGMARKET_ICON_TYPE),s+=1)):this.itemDataList.Add(null)}this.bagShowGrid.SetData(this.itemDataList)
let n=Math.floor(this.itemDataList.length/this.bagShowGrid.column_cnt)*(h.H.ITEM_SIZE+h.H.SPACE)
this.scrollview.content.transform.height=n,this.itemcount=this.itemDataList.Count()
const l=Math.ceil(this.itemcount/m.COLUMN_CNT)
this.grid_bg.heightSet(l*h.H.ITEM_SIZE)}GetItemById(t){
for(let e=0;e<=this.itemDataList.Count()-1;e++)if(this.itemDataList[e]&&this.itemDataList[e].serverData_get().id.Equal(t.serverData_get().id))return e
return 0}ClickItemHandler(t){const e=new p.c
e.itemId=t.modelId_get(),e.curCount=t.serverData_get().num,e.prize=0,_.f.Inst_Get().OpenBuyItem(e,g._.SELL_MODE,t.serverData_get().id),INS.itemTipManager.OpenTipView(t)}Clear(){
this.model.OpenSellItem=null,this.RemoveLis(),this.bagShowGrid.ResetDataStatus(),this.bagShowGrid.Clear(),super.Clear()}Destroy(){this.bagShowGrid.Destroy()}Test1(){return!0}
S_Test(){return!0}}m.COLUMN_CNT=8,m.ROW_CNT=8},5364:(t,e,s)=>{var i,n,l=s(18998),o=s(30849)
l._decorator.ccclass("TradingMarketTab")((n=class t extends o.C{constructor(...t){super(...t),this.index=null,this.clickHandler=null}InitView(){super.InitView(),
this.tip.SetActive(!1),this.tip2.SetActive(!1),this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.OnClickItem))}AddLis(){}RemoveLis(){}SetData(t){this.index=t[0],
this.selectlabel.textSet(t[1]),this.normallab.textSet(t[1]),this.SetSelect(!1)}OnClickItem(){this.SetSelect(!0)}SetSelect(e){e?(null!=t._selectItem&&t._selectItem.SetSelect(!1),
this.selected.SetActive(!0),this.normal.SetActive(!1),t._selectItem!=this&&null!=this.clickHandler&&this.clickHandler(this.index),t._selectItem=this):(this.selected.SetActive(!1),
this.normal.SetActive(!0))}Clear(){this.RemoveLis(),super.Clear()}Destroy(){null!=t._selectItem&&t._selectItem.SetSelect(!1),t._selectItem=null,this.clickHandler=null,
super.Destroy()}Test1(){return!0}S_Test(){return!0}},n._selectItem=null,i=n))},87226:(t,e,s)=>{s.d(e,{d:()=>C})
var i=s(83908),n=s(46282),l=s(36334),o=s(15518),a=s(72693),r=s(61613),h=s(60130),d=s(85602),c=s(79534),I=s(53905),u=s(88199),p=s(51322),_=s(65772),g=s(78922),m=s(35091),S=s(1666),f=s(87455)
class C extends((0,i.pA)(o.k)()){constructor(...t){super(...t),this._subPanelDatas=null,this.iscross=!1,this.buttons=null,this.tabsObj=null}_initBinder(){super._initBinder(),
this._subPanelDatas=new d.Z}InitView(){super.InitView(),this.SubInitView(),this.btnGrid.SetInitInfo(n.Z.ui_ry_right_tab,null,a.j,this.CreateDelegate(this._OnItemClick)),
this.btnGrid.OnReposition_set(this.CreateDelegate(this.OnGridReposition)),this.buttons=null,h.O.SetAnchorPos(this.tip,!0,!1,0,!1),h.O.SetAnchorPos(this.rightTrans,!1,!1,0,!1)}
SubInitView(){this.iscross=!1,this._subPanelDatas.Add(l.b.New(new d.Z([n.Z.ui_tradingmarket_buyview]),this.contentview,S.W)),
this._subPanelDatas.Add(l.b.New(new d.Z([n.Z.ui_tradingmarket_sellview]),this.contentview,f.i))}OnAddToScene(){super.OnAddToScene(),this.AddLis(),m._.Inst_get().useInitSort=!0
const t=new d.Z(["我要购买","我要出售"])
this.btnGrid.data_set(t)
const e=m._.Inst_get().openTabIndex
this.ShowSubView(e),this.UpdateSelected(),g.f.Inst_Get().IsOpen=!0}UpdateSelected(){const t=this.btnGrid.itemList
if(null!=t){const e=t.Count(),s=this._curShowIdx
for(let i=0;i<=e-1;i++){const e=t[i]
i!=s?e.SetSelect(!1):e.SetSelect(!0)}}}OnGridReposition(){if(null==this.tabsObj)return this.tabsObj=new p.G(this.btnGrid.itemList,C.tabIds,this.btnGrid,this.node,null,null,null),
void this.tabsObj.RefreshTab()
this.UpdateSelected()}InitTab(){}_OnItemClick(t){this._curShowIdx=t.node.getSiblingIndex(),this.ShowSubView(this._curShowIdx),this.UpdateSelected()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.tipBtn,this.CreateDelegate(this.OnTipClick))}RemoveLis(){}OnTipClick(t,e){const s=new I.w,i=r.v.GetHalfWOffset(-385,!1)
s.position=new c.P(i,320,0),s.width=450,s.infoId=this.GetTipId(),_.Q.Inst_get().Open(s)}GetTipId(){return"MARKET:TIPS"}Clear(){this.RemoveLis(),
m._.Inst_get().openTabIndex=m._.BUYVIEW,g.f.Inst_Get().IsOpen=!1,super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}}
C.tabIds=new d.Z([u.Z.RY_TRADINGMARKET_BUY,u.Z.RY_TRADINGMARKET_SELL])},29109:(t,e,s)=>{s.d(e,{I:()=>r})
var i=s(38836),n=s(85602),l=s(38962),o=s(33314),a=s(37151)
class r{static __StaticInit(){r.JOB_TREE_ROOT=r.CreateNode(0),r.CreateNode(1e3),r.CreateNode(1011),r.CreateNode(1021),r.CreateNode(1031),r.CreateNode(1012),r.CreateNode(1022),
r.CreateNode(1032),r.CreateNode(2e3),r.CreateNode(2012),r.CreateNode(2022),r.CreateNode(2032),r.CreateNode(2013),r.CreateNode(2023),r.CreateNode(2033),r.CreateNode(3e3),
r.CreateNode(3013),r.CreateNode(3023),r.CreateNode(3033),r.CreateNode(3012),r.CreateNode(3022),r.CreateNode(3032)}constructor(t=null){this.job=null,this.parent=null,
this.childs=null,this.branch_brothers=null,this.job=t,this.childs=new n.Z}static CreateNode(t){const e=new r
return e.job=t,r.JOB_NODE_DICT.LuaDic_AddOrSetItem(t,e),e}static InitLink(t){for(const[e,s]of(0,i.V5)(t)){const t=r.JOB_NODE_DICT.LuaDic_GetItem(s.job)
r.JOB_NODE_DICT.LuaDic_GetItem(s.needjob).AddChild(t)}}static GetChilds(t){return r.JOB_NODE_DICT.LuaDic_GetItem(t).GetAllChildJobs()}static GetParents(t){
return r.JOB_NODE_DICT.LuaDic_GetItem(t).GetAllParentJobs()}static GetDefaultBranch(t){const e=new n.Z,s=o.Z.GetJobBaseValue(t),i=o.Z.GetJobBranch(t),l=o.Z.GetJobTime(t)
for(const[n,a]of r.JOB_NODE_DICT)0==i&&0!=l?s==o.Z.GetJobBaseValue(a.job)&&o.Z.GetJobBranch(a.job)!=i&&o.Z.GetJobTime(a.job)==l&&e.Add(a.job):a.job==t&&e.Add(a.job)
return e}AddChild(t){this.childs.Add(t),t.parent=this}GetAllChildJobs(t=null){null==t&&(t=n.Z.TEMP_get()),-1==t.IndexOf(this.job)&&t.Add(this.job)
for(let e=0;e<=this.childs.Count()-1;e++){this.childs[e].GetAllChildJobs(t)}return t}GetAllParentJobs(t=null){return null==t&&(t=n.Z.TEMP_get()),
-1==t.IndexOf(this.job)&&t.Add(this.job),null!=this.parent&&this.parent.GetAllParentJobs(t),t}GetJobVo(){a.Q.cfg.GetJobVo(this.job)}}r.JOB_TREE_ROOT=null,r.JOB_NODE_DICT=new l.X,
r.__StaticInit()},37151:(t,e,s)=>{s.d(e,{Q:()=>ot})
var i=s(42292),n=s(71409),l=s(17409),o=s(32076),a=s(38836),r=s(86133),h=s(11210),d=s(98800),c=s(97461),I=s(38935),u=s(41664),p=s(5924),_=s(85682),g=s(56937),m=s(18202),S=s(31222),f=s(5494),C=s(28192),T=s(85602),y=s(92679),A=s(33314),v=s(74045),D=s(49067),w=s(87923),B=s(37648),M=s(55492),b=s(92415),O=s(26191),R=s(35796),L=s(5031),G=s(14792),P=s(62734),E=s(60647),k=s(13487),N=s(74492),V=s(79878),x=s(17783),F=s(98580),U=s(89803),H=s(85890),j=s(15398),W=s(99535),Y=s(93984),q=s(38045),z=s(55360),Z=s(98885),X=s(48916),Q=s(29109)
class J{constructor(){this.map_job=null,this.map_trans=null
const t=z.Y.Inst.GetOrCreateCsv(Y.h.eJobResource)
this.map_job=t.GetCsvMap()
const e=z.Y.Inst.GetOrCreateCsv(Y.h.eTransferResource)
this.map_trans=e.GetCsvMap(),Q.I.InitLink(this.map_trans)}GetJobVo(t){return this.map_job[t]}GetCompactName(t){return 1e3==t?"剑士":2e3==t?"法师":"弓手"}GetTransVo(t){
return this.map_trans[t]}GetJobVoByTypeTimesBranch(t,e,s){for(const[i,n]of(0,a.V5)(this.map_job)){const i=n
if(i.type==t&&i.time==e&&i.branch==s)return i}return null}GetTransVoByTypeTimesBranch(t,e,s){const i=this.GetJobVoByTypeTimesBranch(t,e,s)
return null==i?null:this.GetTransVo(i.id)}GetOtherBranchJobVo(t){const e=this.GetJobVo(t)
if(null==e)return null
for(const[t,s]of(0,a.V5)(this.map_job)){const t=s
if(t.type==e.type&&t.time==e.time&&0!=t.branch&&t.branch!=e.branch)return t}return null}GetTransVosByNeedJob(t){const e=new T.Z
for(const[s,i]of(0,a.V5)(this.map_trans)){const s=i
s.needjob==t&&e.Add(s)}return e.Sort(((t,e)=>{const s=this.GetJobVo(t.job),i=this.GetJobVo(e.job)
return X.t.JOB_DIR_BRANCH[s.type].IndexOf(s.branch)-X.t.JOB_DIR_BRANCH[i.type].IndexOf(i.branch)})),e}GetJobByParent(t){let e=null,s=0
for(const[i,n]of(0,a.V5)(this.map_trans)){const i=n
i.needjob==t&&(null==e&&(e=new T.Z),e.Add(i.job),s=i.job)}if(null!=e){const t=Z.M.SubStringWithLen((0,q.tw)(s),1,3)
e.Add((0,q.aI)(t))}return e}GetJobVoByTypeTimesDir(t,e,s){const i=X.t.JOB_DIR_BRANCH[t][s]
return this.GetJobVoByTypeTimesBranch(t,e,i)}}var $=s(16812)
class K extends $.k{constructor(...t){super(...t),this.select_player=null,this.direction=null,this.player_trans_info=null,this.leader_player=null,this.select_skill_id=0,
this.defaultPersonId=null}IsTransViewTask(t,e){const s=ot.ins.GetDoingTransByPlayerId(e)
if(null==s)return!1
for(const[e,i]of(0,a.V5)(s.questLinkList))if(i.questId==t)return!0
return!1}GetMasterStartLevel(){return 400}GetTransferDirection(t){if(null==this.direction)return 0
const e=this.direction.playerId2Direction.LuaDic_GetItem(t)
return null==e?0:e}GetTargetJob(t){const e=ot.cfg.GetJobVo(t.Job_get())
return 0==e.time?ot.cfg.GetJobVo(this.GetTransferDirection(t.Id_get())):ot.cfg.GetJobVoByTypeTimesBranch(e.type,e.time+1,e.branch)}HasTransedPlayer(){
for(let t=0;t<=d.Y.Inst.primaryRoleInfoList.Count()-1;t++)if(d.Y.Inst.primaryRoleInfoList[t].Job_get()%1e3!=0)return!0
return!1}}var tt,et,st,it,nt=s(32527)
function lt(t,e,s,i,n){var l={}
return Object.keys(i).forEach((function(t){l[t]=i[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=s.slice().reverse().reduce((function(s,i){return i(t,e,s)||s}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let ot=(tt=(0,n.GH)(b.k.SM_PlayerTransfer),et=(0,n.GH)(b.k.SM_TransferDirection),it=class t{static get ins(){
return this._ins||(this._ins=new t,this.model||(this.model=new K),this.cfg||(this.cfg=new J)),this._ins}constructor(){this.panel=null,this.get_skill_panel=null,this.timeId=0,
this.transJob=0,this.commitItemTask=null,this.red_light=!1,this.click_light=!1,this.m_handlerMgr=null,this.intervalLevel=null,this.model=null,this.cfg=null,this.tipVo=null,
this.InitHandlerMgr(),this.AddLis()}AddLis(){this.m_handlerMgr.AddEventMgr(y.g.FUNCTION_OPEN,(0,o.v)(this.OnFunctionOpen,this)),this.m_handlerMgr.AddEventMgr(y.g.FUNCTION_CLOSE,(0,
o.v)(this.OnFunctionClose,this)),this.m_handlerMgr.AddEventMgr(y.g.CHOOSE_SETTING_UPDATE,(0,o.v)(this.OnSettingUpdate,this)),this.m_handlerMgr.AddEventMgr(y.g.PLAYER_LEVELUP,(0,
o.v)(this.CheckUnlockTask,this)),x.L.Inst_get().model.AddEventHandler(j.M.INFORM_DO_UPDATA,(0,o.v)(this.OnUpdateTaskHandler,this)),
x.L.Inst_get().model.AddEventHandler(j.M.INFORM_DO_ADD,(0,o.v)(this.OnUpdateTaskHandler,this)),x.L.Inst_get().model.AddEventHandler(j.M.REMOVE_ONE_TASK,(0,
o.v)(this.OnRemoveTaskHandler,this))}OpenPanel(e){if(null!=this.panel&&this.panel.isShow_get())return
this.click_light=!1,this.IconShowLight_Set(),t.model.defaultPersonId=e
const s=new g.v
s.isShowMask=!0,s.isDefaultUITween=!0,s.viewClass=nt.F,(0,l.Yp)(f.I.eTransJobMainView,s)}ClosePanel(){S.N.inst.CloseById(f.I.eTransJobMainView)}CallComplete(t){
return null==this.panel&&(this.panel=new nt.F(null),this.panel.setId(t,null,0)),this.panel}CallDestory(){m.g.DestroyUIObj(this.panel),this.panel=null}OpenGetSkillPanel(t){
if(null!=this.get_skill_panel&&this.get_skill_panel.isShow_get())return
const e=new g.v
e.isShowMask=!0,this.transJob=t,S.N.inst.OpenById(f.I.eTransJobGetSkill,e)}OnFunctionOpen(t){t==M.x.NEW_FIRSTTRANSFER&&(this.SetPanelRedPoint(),this.CheckUnlockTask())}
OnFunctionClose(t){t==M.x.NEW_FIRSTTRANSFER&&E.p.inst.SendClientLogicSetting(k.R.CHANGE_JOB,0)}CheckUnlockTask(){null==this.intervalLevel&&p.C.Inst_get().SetInterval((0,
o.v)(this.OnLevelChange,this),50,1)}OnLevelChange(){if(B.P.Inst_get().IsFunctionOpened(M.x.NEW_FIRSTTRANSFER)){this.intervalLevel=null
for(let t=0;t<=d.Y.Inst.primaryRoleInfoList.Count()-1;t++){const e=d.Y.Inst.primaryRoleInfoList[t],s=this.GetDoingTransByPlayerId(e.Id_get())
if(null!=s){const t=x.L.Inst_get().model.GetCurChangeJobTaskByPlayer(e.Id_get())
if(null!=t&&null!=s&&e.Level_get()==t.resource_get().minLevel&&t.status_get()!=F.B.FINISHED&&s.needjob==e.Job_get()){P.f.Inst.SetState(G.t.CHANGE_JOB_OPENPANEL,!0),
this.click_light=!0,this.IconShowLight_Set()
break}}}this.CheckRedPoint()}}GetDoingTransByPlayerId(e){if(null==e)return null
const s=d.Y.Inst.GetPlayerInfoById(e)
if(null==s)return null
const i=t.cfg.GetJobVo(s.Job_get())
let n=null
if(0==i.time){if(null==t.model.GetTransferDirection(e))return null
n=t.cfg.GetTransVo(t.model.GetTransferDirection(e))}else n=t.cfg.GetTransVoByTypeTimesBranch(i.type,i.time+1,i.branch)
return n}IconShowLight_Set(){L.T.inst_get().model.UpdateFuncItemEffectState(M.x.NEW_FIRSTTRANSFER,this.red_light||this.click_light)}PlayDirector(){
N.g.Instance.PlayByGroupID(t.cfg.GetTransVo(t.model.player_trans_info.job).directorID,(0,o.v)(this.OnPlayStoryEnd,this)),u.j.Inst.PlayByDivision("TransferSuccess")}
OnPlayStoryEnd(){c.i.Inst.RaiseEvent(y.g.PLAYER_TRANSFER_JOB,t.model.player_trans_info.playerId),this.CM_TransferResetPoint(),this.OpenGetSkillPanel(t.model.player_trans_info.job),
t.model.leader_player=null}CM_TransferDirectionRq(t,e){const s=new O.R
s.direction=t,s.playerId=e,I.C.Inst.F_SendMsg(s)}CM_TransferResetPoint(){const e=new R.q
e.playerId=t.model.player_trans_info.playerId,I.C.Inst.F_SendMsg(e)}SM_PlayerTransferHander(e){t.model.player_trans_info=e
const s=d.Y.Inst.getRoleInfo(t.model.player_trans_info.playerId)
null!=s&&s.Job_set(t.model.player_trans_info.job),t.model.leader_player=null,t.model.player_trans_info.playerId.Equal(d.Y.Inst.primaryRoleInfoListBySortId[0].Id_get())||(t.model.leader_player=d.Y.Inst.primaryRoleInfoListBySortId[0].Id_get()),
p.C.Inst_get().SetInterval((0,o.v)(this.PlayDirector,this),20,1)}SM_TransferDirectionHandler(e){t.model.direction=e,c.i.Inst.RaiseEvent(y.g.PLAYER_TRANSFER_DIRECTION)}
OpenAddPointTip(t){const e=d.Y.Inst.GetPlayerInfoById(this.model.player_trans_info.playerId),s=this.cfg.GetJobVo(t),i=this.cfg.GetJobVo(A.Z.GetJobBaseValue(t))
if(null==this.tipVo){const t=new D.B
t.replaceParams.Add(w.l.getNumStr(e.createIdx+1)),t.replaceParams.Add(i.name),t.replaceParams.Add(s.name),t.isDoCancleInClose=!0,t.cancelText=(0,r.T)("暂时不去"),t.cancelHandle=(0,
o.v)(this.OnCancel,this),t.cancelParam=2,t.confirmText=(0,r.T)("前往加点"),t.confirmHandle=(0,o.v)(this.OnGoToAddPoint,this),t.confirmParam=e.createIdx,
t.infoId="BASEPOINT:TRANSFER_REWARD",this.tipVo=t}v.t.Inst().Open(this.tipVo),this.model.player_trans_info=null}OnGoToAddPoint(t){null!=this.tipVo&&(this.tipVo.cancelHandle=null,
this.tipVo.confirmHandle=null,this.tipVo=null),S.N.inst.OpenUIByShortCutIDWithPlayerId(_.D.AddAttrPoint,null,null,t)}OnCancel(){null!=this.tipVo&&(this.tipVo.cancelHandle=null,
this.tipVo.confirmHandle=null,this.tipVo=null)}InitHandlerMgr(){return null==this.m_handlerMgr&&(this.m_handlerMgr=C.h.Get()),this.m_handlerMgr}CommitHandler(t){
const e=h.i.Inst.GetCurSelect(f.I.eTransJobMainView),s=W.O.Inst_get().GetTaskById(t.resource_get().id,e.Id_get())
V.Y.SendToServer(s)}OnUpdateTaskHandler(t){if(!B.P.Inst_get().IsFunctionOpened(M.x.NEW_FIRSTTRANSFER))return
t.resource_get().type==H.U.CHANGE_JOB&&this.CheckRedPoint()}CheckRedPoint(){const t=new T.Z,e=W.O.Inst_get().GetTaskLisByType(H.U.CHANGE_JOB)
for(const[s,i]of(0,a.V5)(e)){const e=this.GetDoingTransByPlayerId(i.qVo.playerId)
if(null!=e&&e.questLinkCompleteList.Contains(i.id_get())&&i.tCTargetDefs_get().tCTargetDefs[0].type!=U.d.LEVEL&&i.status_get()==F.B.FINISHED){
const e=d.Y.Inst.GetCreateIdxById(i.qVo.playerId)
t.Contains(e)||t.Add(e)}}this.red_light=!1
for(let e=0;e<=d.Y.Inst.primaryRoleInfoList.Count()-1;e++)t.Contains(d.Y.Inst.primaryRoleInfoList[e].createIdx)?(P.f.Inst.SetState(G.t.CHANGE_JOB_FINISH_QUEST,!0,d.Y.Inst.primaryRoleInfoList[e].createIdx),
this.red_light=!0):P.f.Inst.SetState(G.t.CHANGE_JOB_FINISH_QUEST,!1,d.Y.Inst.primaryRoleInfoList[e].createIdx)
this.IconShowLight_Set()}OnRemoveTaskHandler(t){if(!B.P.Inst_get().IsFunctionOpened(M.x.NEW_FIRSTTRANSFER))return
t.resource_get().type==H.U.CHANGE_JOB&&(t.tCTargetDefs_get().tCTargetDefs[0].type==U.d.LEVEL?this.SetPanelRedPoint():this.CheckRedPoint())}OnSettingUpdate(){
const t=E.p.inst.GetClientLogicSetting(k.R.CHANGE_JOB)
0!=t&&null!=t||this.SetPanelRedPoint()}SetPanelRedPoint(){null!=this.panel&&this.panel.isShow_get()||(P.f.Inst.SetState(G.t.CHANGE_JOB_OPENPANEL,!0),this.click_light=!0,
this.IconShowLight_Set())}},it._ins=null,it.model=null,it.cfg=null,lt(st=it,"ins",[i.n],Object.getOwnPropertyDescriptor(st,"ins"),st),
lt(st.prototype,"SM_PlayerTransferHander",[tt],Object.getOwnPropertyDescriptor(st.prototype,"SM_PlayerTransferHander"),st.prototype),
lt(st.prototype,"SM_TransferDirectionHandler",[et],Object.getOwnPropertyDescriptor(st.prototype,"SM_TransferDirectionHandler"),st.prototype),st)},48916:(t,e,s)=>{s.d(e,{t:()=>l})
var i=s(86133),n=s(85602)
class l{static __StaticInit(){l.JOB_WARRIOR_DIR[l.DIR_1]=l.JOB_BRANCH_1,l.JOB_WARRIOR_DIR[l.DIR_2]=l.JOB_BRANCH_2,l.JOB_DIR_BRANCH[l.JOB_WARRIOR]=l.JOB_WARRIOR_DIR,
l.JOB_MAGIC_DIR[l.DIR_1]=l.JOB_BRANCH_2,l.JOB_MAGIC_DIR[l.DIR_2]=l.JOB_BRANCH_3,l.JOB_DIR_BRANCH[l.JOB_MAGIC]=l.JOB_MAGIC_DIR,l.JOB_ARCHER_DIR[l.DIR_1]=l.JOB_BRANCH_3,
l.JOB_ARCHER_DIR[l.DIR_2]=l.JOB_BRANCH_2,l.JOB_DIR_BRANCH[l.JOB_ARCHER]=l.JOB_ARCHER_DIR,l.JOB_BASE_NAME[l.JOB_WARRIOR]=(0,i.T)("战士"),l.JOB_BASE_NAME[l.JOB_MAGIC]=(0,i.T)("法师"),
l.JOB_BASE_NAME[l.JOB_ARCHER]=(0,i.T)("弓手")}}l.JOB_WARRIOR=1,l.JOB_MAGIC=2,l.JOB_ARCHER=3,l.JOB_BRANCH_1=1,l.JOB_BRANCH_2=2,l.JOB_BRANCH_3=3,l.DIR_1=1,l.DIR_2=2,
l.JOB_DIR_BRANCH=new n.Z,l.JOB_WARRIOR_DIR=new n.Z,l.JOB_MAGIC_DIR=new n.Z,l.JOB_ARCHER_DIR=new n.Z,l.JOB_BASE_NAME=new n.Z,l.__StaticInit()},55904:(t,e,s)=>{
var i,n=s(18998),l=s(83908)
n._decorator.ccclass("TransJobIcon")(i=class extends((0,l.zB)()){SetData(t){this.img_icon.spriteNameSet(t.jobIcon),this.img_bg.spriteNameSet(t.jobIconBg)}Clear(){super.Clear()}
Destroy(){super.Destroy()}})},32527:(t,e,s)=>{s.d(e,{F:()=>N})
var i,n=s(5494),l=s(6847),o=s(46282),a=s(77546),r=s(38836),h=s(86133),d=s(11210),c=s(98800),I=s(62370),u=s(36334),p=s(44255),_=s(85682),g=s(98885),m=s(85602),S=s(44518),f=s(92679),C=s(33314),T=s(87923),y=s(26348),A=s(43308),v=s(14792),D=s(62734),w=s(90560),B=s(60647),M=s(13487),b=s(65550),O=s(17783),R=s(98580),L=s(99535),G=s(37151),P=s(48916),E=s(76034),k=s(25877)
let N=(0,l.s_)(n.I.eTransJobMainView,o.Z.ui_ry_tabcommonpanel).tabsPrefab([o.Z.ui_transjob_view,o.Z.ui_transjob_select_view,o.Z.ui_transjob_branch_select,o.Z.ui_transjob_branch_select_skill,o.Z.ui_transjob_job_icon,o.Z.ui_transjob_view_skillitem,o.Z.ui_transjob_view_taskitem]).register()(i=class extends p.I{
InitView(){
super.InitView(),this._subPanelDatas.Add(u.b.New(new m.Z(["ui_transjob_select_view","ui_transjob_branch_select","ui_transjob_branch_select_skill","ui_transjob_job_icon"]),this,E.M)),
this._subPanelDatas.Add(u.b.New(new m.Z(["ui_transjob_view","ui_transjob_view_skillitem","ui_transjob_view_taskitem"]),this,k.o))}AddLis(){super.AddLis(),
this.m_handlerMgr.AddEventMgr(f.g.PLAYER_TRANSFER_DIRECTION,this.CreateDelegate(this._OnDirectionUpdate)),
this.m_handlerMgr.AddEventMgr(f.g.CHARACTER_TAB_CHANGED,this.CreateDelegate(this.UpdateRole)),
this.m_handlerMgr.AddEventMgr(f.g.ACCESS_ICON_CLICK,this.CreateDelegate(this.OnClickAccess)),
this.m_handlerMgr.AddEventMgr(f.g.STRENGTHEN_PANEL_CLOSE,this.CreateDelegate(this.OnCloseClick))}RemoveLis(){super.RemoveLis(),this.m_handlerMgr.Clear()}SetViewConfig(){
this.HandleOpenOperation(),this.titleLabel.textSet((0,h.T)("转职")),this.ui_charactertab.ClickChecker=this.OnCheckSelectRole,
this._SetCharacterTabData(!0,n.I.eTransJobMainView,v.t.CHANGE_JOB_FINISH_QUEST),this._SetTabData1(!1),this.SelectCharacter(this.GetDefualCharacter(),!0)}OnCheckSelectRole(t){
const e=c.Y.Inst.primaryRoleInfoList[t],s=G.Q.cfg.GetJobVo(e.Job_get())
let i=null
if(i=0==s.time?G.Q.cfg.GetTransVoByTypeTimesBranch(s.type,s.time+1,P.t.JOB_DIR_BRANCH[s.type][P.t.DIR_1]):G.Q.cfg.GetTransVoByTypeTimesBranch(s.type,s.time+1,s.branch),
null==i)return b.y.inst.ClientSysStrMsg((0,h.T)("该角色已完成转职任务")),!1
const n=L.O.Inst_get().HistoryFinishTaskDic.LuaDic_GetItem(e.createIdx)
if(null!=n)for(const[t,e]of(0,r.V5)(n))if(-1!=i.questLinkCompleteList.IndexOf(t)&&e>0)return!0
const l=O.L.Inst_get().model.GetCurChangeJobTaskByPlayer(e.Id_get())
return null!=l&&-1!=i.questLinkCompleteList.IndexOf(l.id_get())||(b.y.inst.ClientSysStrMsg((0,h.T)("该角色当前无转职任务")),!1)}_OnSelectCharacterBeforeUpdate(){this.UpdateRole()}
_OnSelectTab0BeforeUpdate(){this.UpdateTab0()}_OnDirectionUpdate(){this.UpdateRole()}Clear(){super.Clear(),this.RemoveLis(),A._.Inst_get().CloseView()}Destroy(){super.Destroy()}
OnCloseClick(){G.Q.ins.ClosePanel()}OnClickAccess(t){const e=S.F.ins.GetAccessById(t).TargetDefs_Get().tCTargetDefs[0].OpenUI_get()
g.M.IsNullOrEmpty(e)||g.M.String2Int(e)!=_.D.EquipEnhance||(w.U.Inst().defaultRoleIndex=d.i.Inst.GetCurSelect(n.I.eTransJobMainView).createIdx),
null!=y.Z.Inst().getItemById(t)&&0!=y.Z.Inst().getItemById(t).type3&&G.Q.ins.ClosePanel()}UpdateRole(){A._.Inst_get().CloseView()
const t=d.i.Inst.GetCurSelect(n.I.eTransJobMainView),e=G.Q.cfg.GetJobVo(t.Job_get()),s=I.o.Format((0,
h.T)("{0}{1}转"),G.Q.cfg.GetCompactName(C.Z.GetJobBaseValue(e.id)),T.l.GetChineseNum(e.time+1))
this._SetTabData0(!0,new m.Z([s])),this.SelectTab0(0,!0)}UpdateTab0(){
const t=d.i.Inst.GetCurSelect(n.I.eTransJobMainView),e=G.Q.cfg.GetJobVo(t.Job_get()),s=G.Q.model.GetTransferDirection(t.Id_get())
0==e.time&&0==s?this.ShowSubView(0):this.ShowSubView(1)}GetDefualCharacter(){if(null!=G.Q.model.defaultPersonId){const t=c.Y.Inst.GetCreateIdxById(G.Q.model.defaultPersonId)
if(G.Q.model.defaultPersonId=null,t>=0)return t}let t=-1
const e=c.Y.Inst.primaryRoleInfoList,s=new m.Z(e.Count())
for(let t=0;t<=e.Count()-1;t++){s[t]=e.Count()-t
const i=e[t],n=O.L.Inst_get().model.GetCurChangeJobTaskByPlayer(i.Id_get())
if(null!=n){n.status_get()==R.B.FINISHED&&(s[t]=s[t]+1e4)
const e=G.Q.cfg.GetTransVosByNeedJob(i.Job_get())
if(e.Count()>0){const i=e[0].questLinkCompleteList.IndexOf(n.id_get());-1!=i&&(s[t]=s[t]+10*(i+1))}else a.s.Info((0,h.T)(`未找到玩家转职方向,当前玩家职业:${i.Job_get()}`))}}let i=0
for(let e=0;e<=s.Count()-1;e++)s[e]>i&&(i=s[e],t=e)
return-1==t&&(t=0),t}HandleOpenOperation(){D.f.Inst.SetState(v.t.CHANGE_JOB_OPENPANEL,!1)
const t=B.p.inst.GetClientLogicSetting(M.R.CHANGE_JOB)
null!=t&&0!=t||B.p.inst.SendClientLogicSetting(M.R.CHANGE_JOB,1)}})||i},10305:(t,e,s)=>{var i,n=s(18998),l=s(70829),o=s(51868),a=s(85602),r=s(72835)
n._decorator.ccclass("TransJobSelectItem")(i=class extends o.${constructor(...t){super(...t),this.jobRes=null,this.skillItems=null,this.transferRes=null,this.skillgrid=null,
this.cnode=void 0}InitView(){
this.cnode=this.node.getCNode(),super.InitView(),this.skillItems=new a.Z([this.cnode.skillItem0,this.cnode.skillItem1,this.cnode.skillItem2,this.cnode.skillItem3])}SetData(t){
this.jobRes=t,this.transferRes=r.V.Inst_get().GetTransferItemById(t.id),this.SetItemClickGo(this.cnode.clickbg),this.cnode.text_job_name.textSet(t.name),
this.cnode.job_icon.SetData(t),this.cnode.text_desc.textSet(t.transferDesc)
for(let t=0;t<=this.skillItems.Count()-1;t++){const e=this.skillItems[t]
if(t>=this.transferRes.canLearnSkillsList.Count())e.node.SetActive(!1)
else{e.node.SetActive(!0)
const s=this.transferRes.canLearnSkillsList[t],i=l.j.Inst().GetSkillByStrId(`${s}_1`)
null==i?e.node.SetActive(!1):e.SetData(i)}}}SetSelect(t){this.cnode.selectObj.SetActive(t)}Clear(){super.Clear(),this.skillgrid=null}})},76034:(t,e,s)=>{s.d(e,{M:()=>S})
var i,n=s(18998),l=s(86133),o=s(11210),a=s(98800),r=s(62370),h=s(51868),d=s(5494),c=s(74045),I=s(49067),u=s(41864),p=s(65550),_=s(99535),g=s(37151),m=s(48916)
let S=n._decorator.ccclass("TransJobSelectView")(i=class extends h.${constructor(...t){super(...t),this._curSelect=0,this.tipVo=null,this._curPlayer=null,this.cnode=void 0}
InitView(){super.InitView(),this.cnode=this.node.getCNode()}SetData(){this.m_handlerMgr.AddClickEvent(this.cnode.selectbtn,this.CreateDelegate(this._OnSelectClick)),
this.cnode.select0.onClick=this.CreateDelegate(this._OnItemSelect),this.cnode.select1.onClick=this.CreateDelegate(this._OnItemSelect2),
this._curPlayer=o.i.Inst.GetCurSelect(d.I.eTransJobMainView)
for(let t=1;t<=2;t++){const e=this.GetJob(t)
1==t?this.cnode.select0.SetData(e):this.cnode.select1.SetData(e)}this.SetSelect(-1),this.CheckLevel()}SetSelect(t){this._curSelect=t,this.cnode.select0.SetSelect(0==t),
this.cnode.select1.SetSelect(1==t)}CheckLevel(){
const t=_.O.Inst_get().GetTaskById(g.Q.cfg.GetTransVosByNeedJob(this._curPlayer.Job_get())[0].questLinkCompleteList[0],this._curPlayer.Id_get())
a.Y.Inst.PrimaryRoleInfo_get().Level_get()<t.resource_get().minLevel?(this.cnode.selectbtn.node.SetActive(!1),this.cnode.text_desc.node.SetActive(!0),
this.cnode.text_desc.textSet(r.o.Format((0,l.T)("等级达到{0}开启转职任务"),u.h.GetLevelStr(t.resource_get().minLevel)))):(this.cnode.selectbtn.node.SetActive(!0),
this.cnode.text_desc.node.SetActive(!1))}_OnItemSelect(){this.SetSelect(0)}_OnItemSelect2(){this.SetSelect(1)}_OnSelectClick(){
if(-1!=this._curSelect)if(0==this._curPlayer.createIdx&&this._curPlayer.Job_get()%1e3==0&&0!=this._curSelect){
const t=g.Q.cfg.GetJobVoByTypeTimesDir(g.Q.cfg.GetJobVo(this._curPlayer.Job_get()).type,1,m.t.DIR_1)
if(null==this.tipVo){const e=new I.B
e.replaceParams.Add(t.name),e.replaceParams.Add(t.name),e.cancelText=(0,l.T)("坚持辅助"),e.cancelHandle=this.CreateDelegate(this.OnChooseDir),e.cancelParam=2,e.confirmText=(0,
l.T)("转为输出"),e.confirmHandle=this.CreateDelegate(this.OnChooseDir),e.confirmParam=1,e.infoId="TRANSFER:FRIENDLY_WARN",this.tipVo=e}c.t.Inst().Open(this.tipVo)
}else this.OnChooseDir(this._curSelect+1)
else p.y.inst.ClientSysStrMsg((0,l.T)("请选择转职方向"))}OnChooseDir(t){g.Q.ins.CM_TransferDirectionRq(this.GetJob(t).id,this._curPlayer.Id_get())}GetJob(t){
return g.Q.cfg.GetJobVoByTypeTimesDir(g.Q.cfg.GetJobVo(this._curPlayer.Job_get()).type,1,t)}Clear(){super.Clear(),this._curSelect=-1,
null!=this.tipVo&&(this.tipVo.cancelHandle=null,this.tipVo.confirmHandle=null,this.tipVo=null)}})||i},42120:(t,e,s)=>{s.d(e,{t:()=>d})
var i,n=s(18998),l=s(70829),o=s(9057),a=s(93877),r=s(72005),h=s(50394)
let d=n._decorator.ccclass("TransJobGetSkillIcon")(i=class extends o.x{constructor(...t){super(...t),this.skillVo=null,this.skill_icon=null,this.img_bg=null,
this.text_skill_name=null}InitView(){this.skill_icon=this.CreateComponentBinder(h.N,1),this.img_bg=this.CreateComponent(r.w,2),this.text_skill_name=this.CreateComponent(a.Q,3)}
SetData(t){this.AddLis(),this.skillVo=l.j.Inst().GetSkillByStrId(`${t}_1`),this.skill_icon.SetData(this.skillVo),this.text_skill_name.textSet(this.skillVo.name)}AddLis(){}
RemoveLis(){}Clear(){super.Clear(),this.skill_icon.Clear(),this.RemoveLis()}Destroy(){super.Destroy(),this.skill_icon.Destroy()}})||i},55986:(t,e,s)=>{
var i,n=s(18998),l=s(6847),o=s(83908),a=s(46282),r=s(31222),h=s(5494),d=s(37151),c=s(42120)
n._decorator.ccclass("TransJobGetSkillPanel")(i=(0,l.s_)(h.I.eTransJobGetSkill,a.Z.ui_transjob_getskill_panel).waitPrefab(a.Z.ui_transjob_getskill_icon).register()(i=class extends((0,
o.Ri)()){constructor(...t){super(...t),this.transVo=null}InitView(){super.InitView(),this.grid_skill.SetInitInfo("ui_transjob_getskill_icon",c.t)}AddLis(){
this.m_handlerMgr.AddClickEvent(this.btn_close,this.CreateDelegate(this.OnClickBtnClose)),this.m_handlerMgr.AddClickEvent(this.bg_close,this.CreateDelegate(this.OnClickBtnClose))}
RemoveLis(){this.m_handlerMgr.RemoveClickEvent(this.btn_close,this.CreateDelegate(this.OnClickBtnClose)),
this.m_handlerMgr.RemoveClickEvent(this.bg_close,this.CreateDelegate(this.OnClickBtnClose))}OnAddToScene(){this.AddLis(),this.UpdatePanel()}Clear(){super.Clear(),
this.grid_skill.Clear(),this.RemoveLis()}SetData(t){this.transVo=d.Q.cfg.GetTransVo(t)}UpdatePanel(){this.grid_skill.data_set(this.transVo.canLearnSkillsList)}OnClickBtnClose(){
1==d.Q.cfg.GetJobVo(this.transVo.job).time&&d.Q.ins.OpenAddPointTip(this.transVo.job),r.N.inst.CloseById(h.I.eTransJobGetSkill)}})||i)},93505:(t,e,s)=>{
var i,n=s(18998),l=s(83908),o=s(57834),a=s(18202),r=s(83540),h=s(52053)
n._decorator.ccclass("TransJobSelectSkillItem")(i=class extends((0,l.zB)()){constructor(...t){super(...t),this.skillCfg=null,this._listener=null,this._degf_clickHandler=null,
this.skillId=null}_initBinder(){this._degf_clickHandler=(t,e)=>this.clickHandler(t,e)}SetData(t){this.skillCfg=t,null==this._listener&&(this._listener=o.i.Get(this.skillIcon.node),
this._listener.RegistonClick(this._degf_clickHandler)),this.skillName.textSet(this.skillCfg.name),this.scheduleOnce,
a.g.SetItemIcon(this.skillIcon,this.skillCfg.skillicon,r.b.eSkill,!1),this.skillId=this.skillCfg.id}clickHandler(t,e){h.d.Inst_get().OpenSkillTips(this.skillCfg.skillid)}Clear(){
null!=this._listener&&this._listener.RemoveonClick(this._degf_clickHandler),super.Clear()}})},50394:(t,e,s)=>{s.d(e,{N:()=>r})
var i,n=s(18998),l=s(83908),o=s(72005),a=s(52053)
let r=n._decorator.ccclass("TransJobSkillIcon")(i=class extends((0,l.zB)()){constructor(...t){super(...t),this.skillVo=null,this.img_skill_icon=null}_initBinder(){
this.InitHandlerMgr()}InitView(){this.img_skill_icon=this.CreateComponent(o.w,1)}SetData(t){this.AddLis(),this.skillVo=t,this.img_skill_icon.spriteNameSet(this.skillVo.skillicon)}
AddLis(){this.m_handlerMgr.AddClickEvent(this.img_skill_icon,this.CreateDelegate(this.OnClickIcon))}RemoveLis(){
this.m_handlerMgr.RemoveClickEvent(this.img_skill_icon,this.CreateDelegate(this.OnClickIcon))}OnClickIcon(){a.d.Inst_get().OpenSkillTips(this.skillVo.skillid)}Clear(){
super.Clear(),this.RemoveLis()}Destroy(){super.Destroy()}})||i},25877:(t,e,s)=>{s.d(e,{o:()=>st})
var i,n,l=s(18998),o=s(34899),a=s(38836),r=s(86133),h=s(23833),d=s(11210),c=s(98800),I=s(87722),u=s(32697),p=s(20583),_=s(72574),g=s(31546),m=s(73206),S=s(62370),f=s(70829),C=s(51868),T=s(5494),y=s(61613),A=s(60130),v=s(48712),D=s(85602),w=s(70123),B=s(92679),M=s(74045),b=s(49067),O=s(87923),R=s(27122),L=s(82550),G=s(72652),P=s(2457),E=s(48933),k=s(43308),N=s(41864),V=s(14792),x=s(62734),F=s(78388),U=s(13465),H=s(50748),j=s(15007),W=s(65550),Y=s(27363),q=s(17783),z=s(98580),Z=s(89803),X=s(63412),Q=s(15398),J=s(99535),$=s(37151),K=s(48916),tt=s(40718),et=s(13699)
let st=l._decorator.ccclass("TransView")(((n=class extends C.${constructor(...t){super(...t),this._curPlayer=null,this.jobVo=null,this.transVo=null,this.m_player=null,
this.elementId=0,this.elementId1=0,this.elementId2=0,this.elementId3=0,this.elementId4=0,this.descTextList=null,this.descImgList=null,this.taskModel=null,this.m_target=null,
this.roleInfo=null,this.disinfo=null,this.elementId5=null,this.cnode=void 0,this.displayUIAvatarModel=void 0}InitView(){if(super.InitView(),this.cnode=this.node.getCNode(),
this.cnode.grid_skill.SetInitInfo("ui_transjob_view_skillitem",null,tt.n),this.cnode.grid_task.SetInitInfo("ui_transjob_view_taskitem",null,et.q),
this.descTextList=new D.Z([this.cnode.text_job_desc_0,this.cnode.text_job_desc_1,this.cnode.text_job_desc_2]),
this.descImgList=new D.Z([this.cnode.img_job_desc_0,this.cnode.img_job_desc_1,this.cnode.img_job_desc_2]),A.O.GetUIWidth()>=y.v.LONG_WIDTH_SIGN){
y.v.LayoutUIToX(this.cnode.left_obj,y.v.LAYOUT_LEFT),y.v.LayoutUIToX(this.cnode.right_obj,y.v.LAYOUT_RIGHT,75)
const t=A.O.GetUIWidth()-150-452,e=t-255-15
this.cnode.img_bg.widthSet(t),this.cnode.img_titile_bg.widthSet(t)
const s=e-this.cnode.skillDescScrollView.node.transform.width
this.cnode.skillDescScrollView.node.transform.width=e,this.cnode.skillDescWidget.node.x+=s/2,
this.cnode.panel_skill_show.SetLocalPositionXYZ(255+this.cnode.img_show_bg.width()/2,0,0),this.cnode.line.node.transform.width=e}
this.cnode.skillDescTable.SetInitInfo("ui_transjob_skill_descItem",null,j.l),this.cnode.skillDescTable.OnReposition_set(this.CreateDelegate(this.OnRepositonDesc))}
OnRepositonDesc(){this.cnode.skillDescScrollView.ResetPosition()}SetData(){if(this.taskModel=q.L.Inst_get().model,this.AddLis(),
this._curPlayer=d.i.Inst.GetCurSelect(T.I.eTransJobMainView),this.jobVo=this.GetJob(),null==this.jobVo)return
this.transVo=$.Q.cfg.GetTransVo(this.jobVo.id),$.Q.model.select_skill_id=this.transVo.canLearnSkillsList[0]
x.f.Inst.GetData(V.t.CHANGE_JOB_FINISH_QUEST)
this.m_handlerMgr.AddRedPointTipObj(V.t.CHANGE_JOB_FINISH_QUEST,this.cnode.redpoint,this._curPlayer.createIdx),this.UpdatePanel(),this.OnSelectSkill()}Clear(){
const t=x.f.Inst.GetData(V.t.CHANGE_JOB_FINISH_QUEST)
null!=this._curPlayer&&t.RemovetipObj(this.cnode.redpoint),super.Clear(),this.RemoveLis(),k._.Inst_get().CloseView(),$.Q.model.select_skill_id=0,
this.elementId>0&&(m.X.Inst.DeleteElement(this.elementId),m.X.Inst.DeleteElement(this.elementId1),m.X.Inst.DeleteElement(this.elementId2),m.X.Inst.DeleteElement(this.elementId3),
m.X.Inst.DeleteElement(this.elementId4)),this.ClearModel(),null!=this.m_target&&null!=this.m_target.MainRole_get()&&(this.m_target.Destroy(),this.m_target=null)}AddLis(){
this.m_handlerMgr.AddClickEvent(this.cnode.btn_turn,this.CreateDelegate(this.OnClickImgChange)),
this.m_handlerMgr.AddClickEvent(this.cnode.btn_go,this.CreateDelegate(this.OnClickBtnGo)),
this.m_handlerMgr.AddClickEvent(this.cnode.btn_lock,this.CreateDelegate(this.OnClickBtnLock)),
this.m_handlerMgr.AddEventMgr(B.g.PLAYER_TRANSFER_DIRECTION,this.CreateDelegate(this.DirectionChange)),
this.m_handlerMgr.AddEventMgr(B.g.TRANSFER_CLICK_SKILL,this.CreateDelegate(this.OnSelectSkill)),
this.taskModel.AddEventHandler(Q.M.REFRESH_MAIN_PANEL_LIST,this.CreateDelegate(this.UpdateTask))}RemoveLis(){
this.m_handlerMgr.RemoveClickEvent(this.cnode.btn_turn,this.CreateDelegate(this.OnClickImgChange)),
this.m_handlerMgr.RemoveClickEvent(this.cnode.btn_go,this.CreateDelegate(this.OnClickBtnGo)),
this.m_handlerMgr.RemoveClickEvent(this.cnode.btn_lock,this.CreateDelegate(this.OnClickBtnLock)),
this.m_handlerMgr.RemoveEventMgr(B.g.PLAYER_TRANSFER_DIRECTION,this.CreateDelegate(this.DirectionChange)),
this.m_handlerMgr.RemoveEventMgr(B.g.TRANSFER_CLICK_SKILL,this.CreateDelegate(this.OnSelectSkill)),
this.taskModel.RemoveEventHandler(Q.M.REFRESH_MAIN_PANEL_LIST,this.CreateDelegate(this.UpdateTask))}DirectionChange(){this.jobVo=this.GetJob(),
this.transVo=$.Q.cfg.GetTransVo(this.jobVo.id),this.UpdatePanel()}UpdatePanel(){this.UpdateJob(),this.UpdateTask(),this.UpdateSkill()}UpdateJob(){
this.cnode.ui_transjob_job_icon.SetData(this.jobVo),this.cnode.text_job_name.textSet(this.jobVo.name)
for(let t=0;t<=this.descTextList.Count()-1;t++)t<this.transVo.unlockDescList.Count()?(this.descTextList[t].textSet(this.transVo.unlockDescList[t]),
this.descImgList[t].node.SetActive(!0)):(this.descTextList[t].textSet(""),this.descImgList[t].node.SetActive(!1))
this.cnode.btn_turn.node.SetActive(1==this.jobVo.time)}UpdateTask(){this.cnode.grid_task.data_set(this.transVo.questLinkList),this.UpdateBtnGo()
const t=J.O.Inst_get().GetTaskById(this.transVo.questLinkList[0].questId,this._curPlayer.Id_get())
c.Y.Inst.PrimaryRoleInfo_get().Level_get()<t.resource_get().minLevel?(this.cnode.panel_lock.node.SetActive(!0),this.cnode.btn_lock.node.SetActive(!0),
this.cnode.text_lock.textSet(S.o.Format((0,r.T)("等级达到{0}开启转职任务"),N.h.GetLevelStr(t.resource_get().minLevel))),
this.cnode.btn_go.node.SetActive(!1)):(this.cnode.panel_lock.node.SetActive(!1),this.cnode.btn_lock.node.SetActive(!1),this.cnode.btn_go.node.SetActive(!0))}UpdateBtnGo(){
const t=this.GetGoState(),e=t[0]
let s=t[1]
null==s&&(s=this.taskModel.GetCurChangeJobTaskByPlayer(this._curPlayer.Id_get())),1==e?this.cnode.text_go.textSet((0,r.T)("前往升级")):2==e?this.cnode.text_go.textSet((0,
r.T)("立即前往")):3==e?s.resource_get().intersectionType==X.U.INTERSECTION_NPC?this.cnode.text_go.textSet((0,r.T)("前往提交")):this.cnode.text_go.textSet((0,
r.T)("完成任务")):4==e?this.cnode.text_go.textSet((0,r.T)("前往转职")):5==e?this.cnode.text_go.textSet((0,
r.T)("前往对话")):6==e&&(s.resource_get().intersectionType==X.U.INTERSECTION_NPC?this.cnode.text_go.textSet((0,r.T)("前往提交")):this.cnode.text_go.textSet((0,r.T)("提交金币")))}GetGoState(){
let t=!1,e=!1,s=!1,i=!1
let n=!1,l=0,o=null
const a=this._curPlayer.Id_get()
for(let l=0;l<=this.transVo.questLinkList.Count()-1;l++){const r=this.transVo.questLinkList[l],h=this.taskModel.GetConfig(r.questId,a)
if(this.taskModel.IsTaskCompleted(h.id_get(),a)&&h.id_get()==this.transVo.questLinkList.LastItem().questId){i=!0,o=null
break}if(h.status_get()==z.B.FINISHED&&!this.taskModel.IsTaskCompleted(h.id_get(),a)){o=h,h.tCTargetDefs_get().tCTargetDefs[0].type==Z.d.CURRENCY_BACK?n=!0:s=!0
break}if(h.status_get()==z.B.ACCEPTED){this._curPlayer.Level_get()<h.resource_get().minLevel?t=!0:e=!0,o=h
break}this._curPlayer.Level_get()<h.resource_get().minLevel&&(t=!0,o=h)}return n?l=6:i?l=4:s?l=3:e?l=2:t&&(l=1),new D.Z([l,o])}UpdateSkill(){
this.cnode.grid_skill.data_set(this.transVo.canLearnSkillsList)}OnSelectSkill(){if(0==$.Q.model.select_skill_id)return
const t=f.j.Inst().GetSkillByStrId(`${$.Q.model.select_skill_id}_1`)
this.cnode.text_skill_desc.textSet(t.desc),this.UpdateSkillInfo()}UpdateSkillInfo(){this.roleInfo=d.i.Inst.GetCurShowPlayerInfo()
const t=new D.Z,e=$.Q.model.select_skill_id,s=f.j.Inst().GetSkillByIdLevel(e,0),i=new U.N
i.type=U.N.Type_SkillDesc,i.paddingY=2,i.grayColor="[8E8986]",i.skillId=e,i.roleInfo=this.roleInfo,i.skillLv=0,this.cnode.skillNameLabel.textSet(s.name),t.Add(i)
for(let i=1;i<=s.maxRealLevel;i++){const s=new U.N
s.type=U.N.Type_LevelDesc2,s.paddingY=10,s.grayColor="[8E8986]",s.skillId=e,s.skillLv=0,s.roleInfo=this.roleInfo,s.descSkillLv=i,s.isShowLine=!1,t.Add(s)}let n=null
null!=n&&t.Add(n)
let l=null
const o=F.r.Inst().GetItemBySkillIdAndLevel(e,0),a=H.m.Inst().GetSkillPracticeLvById(this.roleInfo.Id_get(),s.skillid)
null!=o&&0!=o.lv&&(l=new U.N,l.type=U.N.Type_PracticeSkillDesc,l.realSkillInfo=a,l.paddingY=10,l.grayColor="[8E8986]",l.skillId=e,l.isShowLine=!0,t.Add(l)),
this.cnode.skillDescScrollView.ResetPosition(),this.cnode.skillDescTable.data_set(t),this.cnode.skillDescScrollView.scrollToBottom(),this.cnode.skillDescScrollView.scrollToTop()}
OnClickImgChange(){if(0==this._curPlayer.createIdx&&this._curPlayer.Job_get()%1e3==0&&K.t.JOB_DIR_BRANCH[this.jobVo.type][K.t.DIR_1]==this.jobVo.branch){const t=new b.B
t.replaceParams.Add(this.jobVo.name),t.replaceParams.Add(this.jobVo.name),t.cancelText=(0,r.T)("转为辅助"),t.cancelHandle=this.CreateDelegate(this.OnChooseDir),
t.cancelParam=$.Q.cfg.GetOtherBranchJobVo(this.jobVo.id).id,t.confirmText=(0,r.T)("坚持输出"),t.infoId="TRANSFER:FRIENDLY_WARN",M.t.Inst().Open(t)
}else this.OnChooseDir($.Q.cfg.GetOtherBranchJobVo(this.jobVo.id).id)}OnClickBtnGo(){const t=this.GetGoState(),e=t[0]
let s=t[1]
if(null==s&&(s=this.taskModel.GetCurChangeJobTaskByPlayer(this._curPlayer.Id_get())),1==e)L.P.Inst_get().Open(G.X.EXP)
else if(2==e){const e=this.GetStageVoByTaskId(t[1].id_get())
e.access.Count()>0?(E.I.calVec0.Set(0,0,0),w.W.ins.OpenAccessByData(e.access)):(O.l.CheckTrigger(P.u.COND_TYPE_TASK_CLICK_VAL,s.id_get(),0),Y.Y.inst.GotoTrigger(s),
$.Q.ins.ClosePanel())}else 3==e||6==e?s.resource_get().intersectionType==X.U.INTERSECTION_NPC?(Y.Y.inst.GotoTrigger(s),
$.Q.ins.ClosePanel()):$.Q.ins.CommitHandler(s):4!=e&&5!=e||(O.l.CheckTrigger(P.u.COND_TYPE_TASK_CLICK_VAL,s.id_get(),0),Y.Y.inst.GotoTrigger(s),$.Q.ins.ClosePanel())}
OnClickBtnLock(){W.y.inst.ClientSysStrMsg((0,r.T)("任务未解锁"))}OnChooseDir(t){$.Q.ins.CM_TransferDirectionRq(t,this._curPlayer.Id_get())}GetJob(){
return $.Q.model.GetTargetJob(this._curPlayer)}GetStageVoByTaskId(t){for(const[e,s]of(0,a.V5)(this.transVo.questLinkList))if(s.questId==t)return s
return null}InitTarget(){if(null!=this.m_target)return
const t=h.a.getInst().getObjById(10001004),e=new g.O
e._displayID=t.displayId,e._world=v.a.eSmallPhotoWorld,e._bNeedWaitAnime=!0,e._bDefaultShow=!1,this.m_target=R.Q.Inst().GetObjectByName("MonsterCharacter",I._),
this.m_target.initEnd=this.CreateDelegate(this.InitEndTarget),this.m_target.InitPhotoByInfo(t,e,0),this.m_target.isShowAni=!0}ShowModel(){
this.roleInfo=d.i.Inst.GetCurShowPlayerInfo(),this.displayUIAvatarModel=p.x.inst.SetUIAvatarData(this.roleInfo,u.v.role,this.displayUIAvatarModel||null)}ClearModel(){}
ResetRolePos(){this.PlaySkillEff()}InitEndTarget(){this.m_target.MainRole_get().SetPosXYZ(2.28,0,8),this.m_target.MainRole_get().SetShow(!1)}PlaySkillEff(){
const t=f.j.Inst().GetSkillByStrId(`${$.Q.model.select_skill_id}_1`)
this.displayUIAvatarModel.SetAct(_.Bv.Stand),t.creatorType!=o.z.PASSIVE&&this.displayUIAvatarModel.SetAct(_.Bv.Skill)}}).STAGE_ID=117,i=n))||i},40718:(t,e,s)=>{s.d(e,{n:()=>I})
var i,n=s(18998),l=s(83908),o=s(34899),a=s(97461),r=s(70829),h=s(9057),d=s(92679),c=s(37151)
let I=n._decorator.ccclass("TransViewSkillItem")(i=class extends((0,l.pA)(h.x)()){constructor(...t){super(...t),this.skill_id=0}InitView(){super.InitView(),this.InitHandlerMgr()}
SetData(t){this.AddLis(),this.skill_id=t,this.skill_item.SetData(`${this.skill_id}_1`),this.skill_item.SetLabel(""),this.skill_item.ShowTag(!0,o.z.PASSIVE),this.UpdateSelect()}
AddLis(){this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.OnClick)),this.m_handlerMgr.AddEventMgr(d.g.TRANSFER_CLICK_SKILL,this.CreateDelegate(this.UpdateSelect))
}RemoveLis(){this.m_handlerMgr.RemoveClickEvent(this.node,this.CreateDelegate(this.OnClick)),
this.m_handlerMgr.RemoveEventMgr(d.g.TRANSFER_CLICK_SKILL,this.CreateDelegate(this.UpdateSelect))}Clear(){super.Clear(),this.skill_item.Clear(),this.RemoveLis()}Destroy(){
super.Destroy()}UpdateSelect(){const t=c.Q.model.select_skill_id==this.skill_id
this.img_select.node.SetActive(t)
const e=r.j.Inst().GetSkillByStrId(`${this.skill_id}_1`)
t?this.text_skill_name.textSet(`[A86447]${e.name}[-]`):this.text_skill_name.textSet(`[635345]${e.name}[-]`)}OnClick(){
c.Q.model.select_skill_id!=this.skill_id&&(c.Q.model.select_skill_id=this.skill_id,a.i.Inst.RaiseEvent(d.g.TRANSFER_CLICK_SKILL))}})||i},13699:(t,e,s)=>{s.d(e,{q:()=>A})
var i,n=s(18998),l=s(83908),o=s(86133),a=s(11210),r=s(98800),h=s(62370),d=s(9057),c=s(18202),I=s(5494),u=s(83540),p=s(98885),_=s(70123),g=s(70093),m=s(87923),S=s(48933),f=s(41864),C=s(17783),T=s(98580),y=s(37151)
let A=n._decorator.ccclass("TransViewTaskItem")(i=class extends((0,l.pA)(d.x)()){constructor(...t){super(...t),this.stageVo=null,this.taskVo=null,this.resPath="atlas/common/"}
_initBinder(){this.InitHandlerMgr()}InitView(){super.InitView()}SetData(t){this.AddLis(),this.stageVo=t,
this.taskVo=C.L.Inst_get().model.GetConfig(this.stageVo.questId,a.i.Inst.GetCurSelect(I.I.eTransJobMainView).Id_get()),this.img_icon.spriteNameSet(this.stageVo.icon),
this.UpdateTask()}AddLis(){this.m_handlerMgr.AddClickEvent(this.btn_get,this.CreateDelegate(this.OnClickBtnGet)),
this.m_handlerMgr.AddClickEvent(this.img_item,this.CreateDelegate(this.OnClickImgItem)),
this.m_handlerMgr.AddClickEvent(this.text_item_name,this.CreateDelegate(this.OnClickImgItem))}RemoveLis(){}UpdateTask(){
const t=a.i.Inst.GetCurSelect(I.I.eTransJobMainView),e=y.Q.model.GetTargetJob(t),s=y.Q.cfg.GetTransVo(e.id)
this.img_finish.node.SetActive(C.L.Inst_get().model.IsTaskCompleted(this.taskVo.id_get(),t.Id_get())),
this.taskVo.status_get()==T.B.ACCEPTED?this.btn_get.node.SetActive(!0):this.btn_get.node.SetActive(!1)
const i=s.questLinkList[s.questLinkList.IndexOf(this.stageVo)-1]
if(null!=i&&!C.L.Inst_get().model.IsTaskCompleted(i.questId,t.Id_get())||C.L.Inst_get().model.IsTaskCompleted(this.taskVo.id_get(),t.Id_get())?this.img_bg.spriteNameSet(this.resPath+"rycommon_sp_0127"):this.img_bg.spriteNameSet(this.resPath+"rycommon_sp_0128"),
null!=this.taskVo.completeConsumsInfo_get()&&this.taskVo.completeConsumsInfo_get().GetItemList().Count()>0){this.text_name.SetActive(!1),this.img_item.SetActive(!0)
const t=this.taskVo.completeConsumsInfo_get().GetItemList()[0]
c.g.SetItemIcon(this.img_item,t.cfgData_get().icon,u.b.eItem,n.Sprite.SizeMode.CUSTOM),this.text_item_name.textSet(t.GetItemNameStr(!1)),
this.text_shangjiao.textSet(p.M.Replace(this.stageVo.desc,"{0}",""))}else this.text_name.SetActive(!0),this.img_item.SetActive(!1),this.text_name.textSet(this.stageVo.desc)
if(r.Y.Inst.PrimaryRoleInfo_get().Level_get()<this.taskVo.resource_get().minLevel)this.text_state.textSet(h.o.Format((0,
o.T)("{0}开启任务"),f.h.GetLevelStr(this.taskVo.resource_get().minLevel))),this.text_state.SetColor(m.l.GetColorByHexStr("972323"))
else{const e=this.taskVo.tCTargetDefs_get().tCTargetDefs[0].value
let s=0
C.L.Inst_get().model.IsTaskCompleted(this.taskVo.id_get(),t.Id_get())?s=e:null!=this.taskVo.qVo&&(s=this.taskVo.qVo.targets[0].value_get()),s>e&&(s=e),
0==s&&this.taskVo.status_get()!=T.B.ACCEPTED?(this.text_state.textSet((0,o.T)("需完成前置任务")),
this.text_state.SetColor(m.l.GetColorByHexStr("972323"))):(this.text_state.textSet(h.o.Format((0,o.T)("{0}/{1}"),m.l.GetRuleDecimalVal(s),m.l.GetRuleDecimalVal(e))),
s>=e?this.text_state.SetColor(m.l.GetColorByHexStr("25642f")):this.text_state.SetColor(m.l.GetColorByHexStr("972323")))}}Clear(){super.Clear(),this.RemoveLis()}Destroy(){
super.Destroy()}OnClickBtnGet(){S.I.calVec0.Set(0,0,0),this.stageVo.access&&this.stageVo.access.Count()>0&&_.W.ins.OpenAccessByData(this.stageVo.access)}OnClickImgItem(){
const t=this.taskVo.completeConsumsInfo_get().GetItemList()[0]
null!=t&&(t.btnType=g.p.GetWay,INS.itemTipManager.OpenTipView(t))}})||i},32942:(t,e,s)=>{s.d(e,{G:()=>r})
var i=s(86133),n=s(98800),l=s(66788),o=s(75321),a=s(33314)
class r{static GetRealEquipEnum(t){
return t==r.HAT?o.C.PART_HAT:t==r.CLOTHES?o.C.PART_CLOTHES:t==r.GLOVES?o.C.PART_GLOVES:t==r.PANTS?o.C.PART_PANTS:t==r.BOOTS?o.C.PART_BOOTS:t==r.MAINWEAPON?o.C.PART_WEAPON_LEFT:t==r.SUBWEAPON?o.C.PART_WEAPON_RIGHT:t==r.NECKLACE?o.C.PART_NECKLACE:t==r.LEFTRING?o.C.PART_RINGS_LEFT:t==r.RIGHTRING?o.C.PART_RINGS_RIGHT:t==r.WING?o.C.PART_WINGS:t==r.GUARD?o.C.PART_GUARD:t==r.ASURAMFLAG?o.C.PART_ASURAMFLAG:(l.Y.LogError((0,
i.T)("找不到装备部位为：")+(t+(0,i.T)("的对应真实部位Index！！！"))),0)}static GetPartDescByType(t){return t==r.HAT?(0,i.T)("头盔"):t==r.CLOTHES?(0,i.T)("胸甲"):t==r.GLOVES?(0,i.T)("护手"):t==r.PANTS?(0,
i.T)("护腿"):t==r.BOOTS?(0,i.T)("鞋子"):t==r.MAINWEAPON?(0,i.T)("主手"):t==r.SUBWEAPON?(0,i.T)("副手"):t==r.LEFTRING?(0,i.T)("左戒指"):t==r.RIGHTRING?(0,i.T)("右戒指"):t==r.NECKLACE?(0,
i.T)("项链"):t==r.WING?(0,i.T)("翅膀"):t==r.GUARD?(0,i.T)("守护"):t==r.ASURAMFLAG?(0,i.T)("战盟旗帜"):(l.Y.LogError((0,i.T)("找不到装备部位为：")+(t+(0,i.T)("的对应名称！！！"))),"")}GetEquipTypeByType(t){
const e=a.Z.GetJobKind(n.Y.Inst.PrimaryRoleInfo_get().Job_get())
return t==r.HAT?"HAT":t==r.CLOTHES?"CLOTHES":t==r.GLOVES?"GLOVES":t==r.PANTS?"PANTS":t==r.BOOTS?"BOOTS":t==r.NECKLACE?"NECKLACE":t==r.LEFTRING?"LEFTRING":t==r.RIGHTRING?"RIGHTRING":t==r.WING?"WING":t==r.GUARD?"GUARD":t==r.ASURAMFLAG?"ASURAMFLAG":t==r.MAINWEAPON?1==e?"SINGLEWEAPON":"MAINWEAPON":t==r.SUBWEAPON?1==e?"SINGLEWEAPON":"SUBWEAPON":(l.Y.LogError((0,
i.T)("找不到装备部位为：")+(t+(0,i.T)("的对应类型！！！"))),"")}GetEquipPartTypeByType(t){
return"HAT"==t?r.HAT:"CLOTHES"==t?r.CLOTHES:"GLOVES"==t?r.GLOVES:"PANTS"==t?r.PANTS:"BOOTS"==t?r.BOOTS:"MAINWEAPON"==t||"SINGLEWEAPON"==t?r.MAINWEAPON:"SUBWEAPON"==t?r.SUBWEAPON:"NECKLACE"==t?r.NECKLACE:"LEFTRING"==t?r.LEFTRING:"RIGHTRING"==t?r.RIGHTRING:"WING"==t?r.WING:"GUARD"==t?r.GUARD:"ASURAMFLAG"==t?r.ASURAMFLAG:(l.Y.LogError((0,
i.T)("找不到装备部位为：")+(t+(0,i.T)("的对应类型！！！"))),r.HAT)}GetEquipTypeByTypeFormatWeapon(t){a.Z.GetJobKind(n.Y.Inst.PrimaryRoleInfo_get().Job_get())
return t==r.HAT?"HAT":t==r.CLOTHES?"CLOTHES":t==r.GLOVES?"GLOVES":t==r.PANTS?"PANTS":t==r.BOOTS?"BOOTS":t==r.NECKLACE?"NECKLACE":t==r.LEFTRING?"LEFTRING":t==r.RIGHTRING?"RIGHTRING":t==r.WING?"WING":t==r.GUARD?"GUARD":t==r.ASURAMFLAG?"FLAG":t==r.MAINWEAPON?"WEAPON":t==r.SUBWEAPON?"SUBWEAPON":(l.Y.LogError((0,
i.T)("找不到装备部位为：")+(t+(0,i.T)("的对应类型！！！"))),"")}}r.MAINWEAPON=0,r.SUBWEAPON=1,r.HAT=2,r.CLOTHES=3,r.GLOVES=4,r.PANTS=5,r.BOOTS=6,r.NECKLACE=7,r.LEFTRING=8,r.RIGHTRING=9,r.WING=10,
r.GUARD=11,r.ASURAMFLAG=12},21334:(t,e,s)=>{s.d(e,{p:()=>T})
var i,n,l,o=s(42292),a=s(93984),r=s(38836),h=s(86133),d=s(13687),c=s(66788),I=s(49484),u=s(55360),p=s(98885),_=s(85602),g=s(38962),m=s(56084),S=s(31931),f=s(12970),C=s(48644)
let T=(0,o.gK)("TransportMapModel")((l=class t{constructor(){this._mapDic=null,this._maxLvMiracleMap=null,this._transportDic=null,this._relationDic=null,this.container=null,
this.minPathLen=0,this.parentMapDic=null,this.sortMapList=null,this.unlockMapCopyDic=null,this.container=new _.Z}static Inst_get(){return null==t.m_inst&&(t.m_inst=new t),t.m_inst}
MaxLvMiracleMap_get(){return this._maxLvMiracleMap}GetMapById(t){if(null==this._mapDic){const t=u.Y.Inst.GetOrCreateCsv(a.h.eMapResource)
this._mapDic=t.GetCsvMap()}return this._mapDic.LuaDic_ContainsKey(t)?this._mapDic[t]:(0!=t&&c.Y.LogError((0,h.T)("地图表Mapresouece的id：")+(t+(0,h.T)("找不到"))),null)}GetParentMap(t){
if(null==this.parentMapDic){this.parentMapDic=new g.X
for(const[t,e]of(0,r.V5)(this._mapDic))if(!p.M.IsNullOrEmpty(e.worldmap)){const t=p.M.Split(e.worldmap,"_")
for(let s=0;s<=t.Count()-1;s++)this.parentMapDic.LuaDic_AddOrSetItem(p.M.String2Int(t[s]),e.id)}}return this.parentMapDic[t]}GetMapSortList(){if(null==this.sortMapList){
if(this.sortMapList=new _.Z,null==this._mapDic){const t=u.Y.Inst.GetOrCreateCsv(a.h.eMapResource)
this._mapDic=t.GetCsvMap()}for(const[t,e]of(0,r.V5)(this._mapDic))0!=e.openSort&&this.sortMapList.Add(e.id)
this.sortMapList.Sort(((t,e)=>this._mapDic[t].openSort<this._mapDic[e].openSort?-1:this._mapDic[t].openSort>this._mapDic[e].openSort?1:0))}return this.sortMapList}
GetUnLockMapByCopyId(t){if(null==this.unlockMapCopyDic){if(this.unlockMapCopyDic=new g.X,null==this._mapDic){const t=u.Y.Inst.GetOrCreateCsv(a.h.eMapResource)
this._mapDic=t.GetCsvMap()}for(const[t,e]of(0,r.V5)(this._mapDic))0!=e.unlockBoss&&this.unlockMapCopyDic.LuaDic_AddOrSetItem(e.unlockBoss,e.id)}
return this.unlockMapCopyDic.LuaDic_ContainsKey(t)?this.unlockMapCopyDic[t]:0}GetLastMapIsOpen(t){if(null!=this.GetMapById(t)){const e=this.GetMapSortList(),s=_.Z.IndexOf(e,t)
if(s<=0)return!0
const i=e[s-1]
if(f.F.getInst().GetCanEnterMapByLvAndTransfer(i)==S.f.CAN)return!0}return!1}GetLastMap(t){if(null!=this.GetMapById(t)){const e=this.GetMapSortList(),s=_.Z.IndexOf(e,t)
if(s<=0)return 0
return e[s-1]}return 0}GetNextMap(t){if(null!=this.GetMapById(t)){const e=this.GetMapSortList(),s=_.Z.IndexOf(e,t)
if(s<0||s>=e.Count()-1)return 0
return e[s+1]}return 0}GetNowHightMap(){const t=this.GetMapSortList()
let e=0
for(let s=0;s<=t.Count()-1;s++)if(null!=t[s]){const i=t[s]
f.F.getInst().GetCanEnterMapByLvAndTransfer(i)==S.f.CAN&&(e=i)}return e}IsNeedBossChange(t){return 0!=this.GetMapById(t).unlockBoss}GetCanEnterMapMap(){this._maxLvMiracleMap=null
for(const[t,e]of(0,r.V5)(this._mapDic)){let t=e.id
0!=e.relatedMapId&&(t=e.relatedMapId)
let s=!1
s=f.F.getInst().mapLockStatus.LuaDic_GetItem(t),null==s&&(s=!1),s&&("MIRACLEMAINLAND"!=e.controllerType&&"MIRACLEMAINLAND_SCENE_COPY"!=e.controllerType||(null==this._maxLvMiracleMap||e.minLevelLimit>this._maxLvMiracleMap.minLevelLimit)&&(this._maxLvMiracleMap=e))
}}GetMapIdsByUIType(t){const e=new _.Z
if(t==I.p.SHOW_ACTIVITY_ICON)for(const[t,s]of(0,r.V5)(this._mapDic)){s.btnIsOutInCopy&&e.Add(p.M.IntToString(s.id))}else for(const[s,i]of(0,r.V5)(this._mapDic)){const s=i
s.hideElementsList.Count()>0&&s.hideElementsList.Contains(t)&&e.Add(p.M.IntToString(i.id))}return e.GetLuaToArray()}GetBuffsById(t){
return this._mapDic.LuaDic_ContainsKey(t)?this._mapDic[t].hideBuffsList:null}GetBanTeamResult(){const t=new _.Z
for(const[e,s]of(0,r.V5)(this._mapDic))s.banTeam&&t.Add(s.id)
return t}GetBanBeatBackResult(){const t=new _.Z
for(const[e,s]of(0,r.V5)(this._mapDic))s.banBeatBack&&t.Add(s.id)
return t}GetMapIdsByControllerType(t){const e=new _.Z
for(const[s,i]of(0,r.V5)(this._mapDic))i.controllerType==t&&e.Add(i.id)
return e}transportDic_get(){if(null==this._transportDic){const t=u.Y.Inst.GetOrCreateCsv(a.h.eTransportresource)
this._transportDic=t.GetCsvMap()}return this._transportDic}GetTransportCfg(t){return this.transportDic_get(),
this._transportDic.LuaDic_ContainsKey(t)?this._transportDic.LuaDic_GetItem(t):null}GetAllTransportInMap(t){const e=new _.Z
for(const[s,i]of(0,r.V5)(this.transportDic_get()))i.type!=C.F.MapToMap&&i.type!=C.F.MapToCopy||i.belongMapId!=t||e.Add(i)
return e}GetAllTransportInCopy(t){const e=new _.Z
for(const[s,i]of(0,r.V5)(this.transportDic_get()))i.type==C.F.CopyToMap&&i.belongCopyId==t&&e.Add(i)
return e}InitMapRelation(){if(null==this._relationDic){this._relationDic=new g.X
let t=null
for(const[e,s]of(0,r.V5)(this.transportDic_get()))s.type==C.F.MapToMap&&(this._relationDic.LuaDic_ContainsKey(s.belongMapId)||(t=new _.Z,
this._relationDic.LuaDic_AddOrSetItem(s.belongMapId,t)),t=this._relationDic[s.belongMapId],t.Add(s))}}GetMapTransports(t){
return this._relationDic.LuaDic_ContainsKey(t)?null:this._relationDic[t]}GetTransports(t,e){if(null==e&&(e=0),0==e&&(e=d.b.Inst.currentMapId_get()),e==t)return null
if(this.InitMapRelation(),!this._relationDic.LuaDic_ContainsKey(e))return null
let s=this._relationDic[e]
for(const[e,i]of(0,r.V5)(s))if(i.targetMapId==t)return s=new _.Z,s.Add(i),s
this.minPathLen=999
let i=0
for(;i<s.Count();){const e=new _.Z
this.FindConfigs(s[i],t,e),i+=1}if(0==this.container.Count())return null
let n=this.container[0]
for(const[t,e]of(0,r.V5)(this.container))e.Count()<n.Count()&&(n=e)
return this.container.Clear(),n}FindConfigs(t,e,s){const i=s.count-1
for(let e=0;e<=i;e++)if(s[e].targetMapId==t.targetMapId)return void s.Clear()
if(s.Add(t),s.count>this.minPathLen)return void s.Clear()
const n=this._relationDic[t.targetMapId],l=n.Count()
if(1==l)return void s.Clear()
let o=null,a=0
for(;a<l;){if(o=n[a],o.targetMapId!=t.belongMapId){if(o.targetMapId==e)return s.Add(o),this.container.Add(s),void(999==this.minPathLen&&(this.minPathLen=s.count))
const t=this.CloneList(s)
this.FindConfigs(o,e,t)}a+=1}}CloneList(t){const e=new _.Z,s=t.Count()
let i=0
for(;i<s;)e.Add(t[i]),i+=1
return e}GetElementLimit(t,e){const s=this.GetMapById(t)
return e==m.s.High?s.highGroupLimit:e==m.s.Medium?s.mediumGroupLimit:s.lowGroupLimit}GetItemById(t){
return null!=this.transportDic_get()&&this.transportDic_get().LuaDic_ContainsKey(t)?this.transportDic_get()[t]:null}},l.PLAYER_MIN_DISTANCE=2,l.m_inst=null,y=n=l,A="Inst_get",
v=[o.Vx],D=Object.getOwnPropertyDescriptor(n,"Inst_get"),w=n,B={},Object.keys(D).forEach((function(t){B[t]=D[t]})),B.enumerable=!!B.enumerable,B.configurable=!!B.configurable,
("value"in B||B.initializer)&&(B.writable=!0),B=v.slice().reverse().reduce((function(t,e){return e(y,A,t)||t}),B),
w&&void 0!==B.initializer&&(B.value=B.initializer?B.initializer.call(w):void 0,B.initializer=void 0),void 0===B.initializer&&(Object.defineProperty(y,A,B),B=null),i=n))||i
var y,A,v,D,w,B},48644:(t,e,s)=>{s.d(e,{F:()=>i})
class i{}i.MapToMap=1,i.MapToCopy=2,i.CopyToMap=3},75517:(t,e,s)=>{s.d(e,{W:()=>i})
class i{constructor(){this.view=null,this._degf_CallComplete=null,this._degf_CallDestory=null,this._degf_CallComplete=t=>this.CallComplete(t),
this._degf_CallDestory=()=>this.CallDestory()}static inst_get(){return null==i._inst&&(i._inst=new i),i._inst}OpenView(t,e){if(null!=this.view&&this.view.isShow_get())return
const s=new UIOpenParam
s.layerType=LayerType.Tip,UIShowMgr.inst.OpenById(eUIComponentID.eTransportReadyPanel,this._degf_CallComplete,this._degf_CallDestory,s)}CallComplete(t){
return null==this.view&&(this.view=new TransportReadyView,this.view.setId(t,null,0)),this.view}CallDestory(){UIResMgr.DestroyUIObj(this.view),this.view=null}CloseView(){}}
i._inst=null},96102:(t,e,s)=>{s.d(e,{B:()=>l})
var i=s(5468),n=s(79534)
class l{constructor(){this.linkStr=i.E.s_Empty,this.reduceDistance=0,this.mapId=0,this.targetPos=null,this.transportCfg=null,this.npcCfg=null,this.gatherCfg=null,
this.targetPos=n.P.zero_get()}}},67020:(t,e,s)=>{s.d(e,{Y:()=>i})
class i{}i.TipsFitDis=412},682:(t,e,s)=>{s.d(e,{x:()=>p})
var i=s(17409),n=s(97461),l=s(41664),o=s(56937),a=s(18202),r=s(31222),h=s(5494),d=s(52726),c=s(92679),I=s(23765),u=s(54053)
class p{constructor(){this.view=null,this._degf_CallDestory=null,this._degf_Complete=null,this._degf_CallDestory=()=>this.CallDestory(),this._degf_Complete=t=>this.Complete(t)}
static Inst_get(){return null==p._inst&&(p._inst=new p),p._inst}OpenView(){if(!I.W.Inst_get().IsSpecialTaskViewOpen()){if(this.view=(0,i.Y)(h.I.PandoraRewardShowPanel),
this.view)this.view.UpdateView()
else{const t=new o.v
t.isShowMask=!0,t.layerType=d.F.Tip,r.N.inst.OpenById(h.I.PandoraRewardShowPanel,this._degf_Complete,this._degf_CallDestory,t)}l.j.Inst.PlayByDivision("ui_chestOpen")}}Complete(t){
return null==this.view&&(this.view=new u.L(null),this.view.setId(t,null,0)),this.view}CallDestory(){a.g.DestroyUIObj(this.view),this.view=null}CloseView(){(0,
i.qJ)(h.I.PandoraRewardShowPanel)&&((0,i.sR)(h.I.PandoraRewardShowPanel),n.i.Inst.RaiseEvent(c.g.CHECK_PANDORABOX_CLOSE_GUIDE),n.i.Inst.RaiseEvent(c.g.STOP_PANDORABOX_QUICKUSE),
this.view=null)}}p._inst=null},39963:(t,e,s)=>{s.d(e,{R:()=>Z})
var i=s(97461),n=s(57647),l=s(68662),o=s(66788),a=s(56937),r=s(18202),h=s(31222),d=s(5494),c=s(52726),I=s(21554),u=s(92679),p=s(87923),_=s(38836),g=s(86133),m=s(98800),S=s(50089),f=s(5924),C=s(99294),T=s(6665),y=s(9776),A=s(93877),v=s(8889),D=s(72005),w=s(13113),B=s(61911),M=s(83540),b=s(78300),O=s(35128),R=s(98130),L=s(98885),G=s(85602),P=s(52212),E=s(79534),k=s(44758),N=s(63076),V=s(59686),x=s(75696),F=s(48933),U=s(37648),H=s(72835),j=s(34402),W=s(48481),Y=s(67020),q=s(41347)
class z extends B.f{constructor(){super(),this.tip=null,this.bg=null,this.icon=null,this.name=null,this.scrollView=null,this.root=null,this.grid1=null,this.level=null,
this.vipTip=null,this.vip=null,this.timeTip=null,this.time=null,this.desc=null,this.rewards=null,this.timeObj=null,this.descObj=null,this.rewardsObj=null,this.scrollPanel=null,
this.scrollBack=null,this.payTip=null,this.payTypeSp=null,this.payLabel=null,this.itemType=null,this.conditionObj=null,this.qualityBg=null,this.jobTip=null,this.jobLabel=null,
this.lockObj=null,this.levelTip=null,this.qualityAnimOne=null,this.qualityAnimTwo=null,this.qualityAnimThree=null,this.qualityAnimFour=null,this.qualityAnimFive=null,
this.qualityAnimSix=null,this.qualityAnimList=null,this.noBtnPanelSize=null,this.hasBtnPanelSize=null,this.btnObjPos=null,this.m_bgWidth=412,this.bgHeight=592,this.btnShowCnt=0,
this.bgOffset=0,this.normalColor="[ffefe1]",this.activeColor="[ffefe1]",this.inactiveColor="[fe2e2d]",this._leftTimeIntervalId=-1,this._lefttime=0,this.itemData=null,
this.m_pos=null,this._degf_ClickTipsCallback=null,this._degf_CreateRewardItem=null,this._degf_LeftTimeChange=null,this._degf_OnMask=null,this._degf_RefreshRewardItem=null,
this.qualityAnimList=new G.Z,this.noBtnPanelSize=new k.L(0,-37,395,442),this.hasBtnPanelSize=new k.L(0,0,395,367),this.btnObjPos=new E.P(0,-252,0),this.m_pos=new E.P,
this._degf_ClickTipsCallback=t=>this.ClickTipsCallback(t),this._degf_CreateRewardItem=t=>this.CreateRewardItem(t),this._degf_LeftTimeChange=()=>this.LeftTimeChange(),
this._degf_OnMask=(t,e)=>this.OnMask(t,e),this._degf_RefreshRewardItem=()=>this.RefreshRewardItem()}BgOffset_get(){return this.bgOffset}BgOffset_set(t){
if(this.bgOffset=t<-340?-340:t>0?0:t,this.bg.heightSet(R.GF.INT(this.bgHeight+this.bgOffset)),null!=this.itemData&&1==this.itemData.tag){let t=this.m_pos.y
t+=.5*this.bgOffset
const e=new E.P(this.m_pos.x,t,this.m_pos.z)
this.node.transform.SetLocalPosition(e),E.P.Recyle(e)}}InitView(){this.tip=new C.z,this.tip.setId(this.FatherId,this.FatherComponentID,1),this.bg=new D.w,
this.bg.setId(this.FatherId,this.FatherComponentID,2),this.icon=new D.w,this.icon.setId(this.FatherId,this.FatherComponentID,3),this.name=new A.Q,
this.name.setId(this.FatherId,this.FatherComponentID,4),this.scrollView=new y.h,this.scrollView.setId(this.FatherId,this.FatherComponentID,5),this.root=new C.z,
this.root.setId(this.FatherId,this.FatherComponentID,6),this.grid1=new T.A,this.grid1.setId(this.FatherId,this.FatherComponentID,7),this.level=new A.Q,
this.level.setId(this.FatherId,this.FatherComponentID,8),this.vipTip=new C.z,this.vipTip.setId(this.FatherId,this.FatherComponentID,9),this.vip=new A.Q,
this.vip.setId(this.FatherId,this.FatherComponentID,10),this.timeTip=new C.z,this.timeTip.setId(this.FatherId,this.FatherComponentID,11),this.time=new A.Q,
this.time.setId(this.FatherId,this.FatherComponentID,12),this.desc=new A.Q,this.desc.setId(this.FatherId,this.FatherComponentID,13),this.rewards=new T.A,
this.rewards.setId(this.FatherId,this.FatherComponentID,14),this.rewards.SetInitInfo("ui_baseitem",this._degf_CreateRewardItem),
this.rewards.OnReposition_set(this._degf_RefreshRewardItem),this.timeObj=new C.z,this.timeObj.setId(this.FatherId,this.FatherComponentID,15),this.descObj=new C.z,
this.descObj.setId(this.FatherId,this.FatherComponentID,16),this.rewardsObj=new C.z,this.rewardsObj.setId(this.FatherId,this.FatherComponentID,17),this.scrollPanel=new v.$,
this.scrollPanel.setId(this.FatherId,this.FatherComponentID,18),this.scrollBack=new w.T,this.scrollBack.setId(this.FatherId,this.FatherComponentID,19),this.payTip=new C.z,
this.payTip.setId(this.FatherId,this.FatherComponentID,20),this.payTypeSp=new D.w,this.payTypeSp.setId(this.FatherId,this.FatherComponentID,21),this.payLabel=new A.Q,
this.payLabel.setId(this.FatherId,this.FatherComponentID,22),this.itemType=new A.Q,this.itemType.setId(this.FatherId,this.FatherComponentID,23),this.conditionObj=new C.z,
this.conditionObj.setId(this.FatherId,this.FatherComponentID,24),this.qualityBg=new D.w,this.qualityBg.setId(this.FatherId,this.FatherComponentID,25),this.jobTip=new C.z,
this.jobTip.setId(this.FatherId,this.FatherComponentID,26),this.jobLabel=new A.Q,this.jobLabel.setId(this.FatherId,this.FatherComponentID,27),this.lockObj=new C.z,
this.lockObj.setId(this.FatherId,this.FatherComponentID,28),this.levelTip=new C.z,this.levelTip.setId(this.FatherId,this.FatherComponentID,29),this.qualityAnimOne=new C.z,
this.qualityAnimOne.setId(this.FatherId,this.FatherComponentID,30),this.qualityAnimTwo=new C.z,this.qualityAnimTwo.setId(this.FatherId,this.FatherComponentID,31),
this.qualityAnimThree=new C.z,this.qualityAnimThree.setId(this.FatherId,this.FatherComponentID,32),this.qualityAnimFour=new C.z,
this.qualityAnimFour.setId(this.FatherId,this.FatherComponentID,33),this.qualityAnimFive=new C.z,this.qualityAnimFive.setId(this.FatherId,this.FatherComponentID,34),
this.qualityAnimSix=new C.z,this.qualityAnimSix.setId(this.FatherId,this.FatherComponentID,35),this.qualityAnimList.Add(null),this.qualityAnimList.Add(this.qualityAnimOne),
this.qualityAnimList.Add(this.qualityAnimTwo),this.qualityAnimList.Add(this.qualityAnimThree),this.qualityAnimList.Add(this.qualityAnimFour),
this.qualityAnimList.Add(this.qualityAnimFive),this.qualityAnimList.Add(this.qualityAnimSix),this.DestoryPanelLevel=B.f.DestoryLevel0}OnAddToScene(){this.AddListeners(),
this.UpdateView()}Clear(){this.RemoveListeners(),f.C.Inst_get().ClearInterval(this._leftTimeIntervalId),this._leftTimeIntervalId=-1}Destroy(){this.tip=null,this.bg=null,
this.icon=null,this.name=null,this.scrollView=null,this.root=null,this.grid1.Destroy(),this.grid1=null,this.level=null,this.vipTip=null,this.vip=null,this.timeTip=null,
this.time=null,this.desc=null,this.rewards.Destroy(),this.rewards=null,this.timeObj=null,this.descObj=null,this.rewardsObj=null,this.scrollPanel=null,this.scrollBack=null,
this.payTip=null,this.payTypeSp=null,this.payLabel=null,this.itemType=null,this.conditionObj=null,this.qualityBg=null,this.lockObj=null
let t=0
for(;t<this.qualityAnimList.Count();)this.qualityAnimList[t]=null,t+=1
this.qualityAnimList.Clear(),this.qualityAnimList=null}SetQualityAnim(t){let e=1
for(;e<this.qualityAnimList.Count();)this.qualityAnimList[e].SetActive(!1),e+=1
0!=t&&t<this.qualityAnimList.Count()&&this.qualityAnimList[t].SetActive(!0)}AddListeners(){this.AddFullScreenCollider(this.node,this._degf_OnMask,this._degf_OnMask)}
RemoveListeners(){this.RemoveFullScreenCollider()}OnMask(t,e){Z.Inst_get().CloseView()}GetTipPosition(t,e){const s=new P.F(.5,.5),i=s-t
let n=null
return n=null!=e?e.Clone():E.P.zero_get(),n.x+=i.x*this.m_bgWidth,n.y+=i.y*this.bgHeight,P.F.Recycle(s),P.F.Recycle(i),n}UpdateView(){this.btnShowCnt=0,this.tip.SetActive(!0),
this.itemData=Z.Inst_get().itemData,this.OnFullScreenColliderInit()
let t=null
this.itemData.tipPosType==V.l.Default?(t=this.GetTipPosition(this.itemData.anchor,this.itemData.tipsPos),
this.node.transform.SetLocalPosition(t)):(t=this.GetTipPosition(this.itemData.anchor,I.J.Inst_get().GetTipPosition(this.itemData.tipPosType)),
this.node.transform.SetLocalPosition(t)),this.node.transform.SetLocalPosition(t),E.P.Recyle(t),this.m_pos=this.node.transform.GetLocalPosition().Clone(),
r.g.SetItemIcon(this.icon.FatherId,this.icon.ComponentId,this.itemData.cfgData_get().icon,M.b.eItem,!1)
const e=`${this.GetNameStr(this.itemData.Quality_get())}${this.itemData.cfgData_get().name}[-]`
this.name.textSet(e),this.itemType.textSet(this.itemData.cfgData_get().describeType),this.qualityBg.spriteNameSet(p.l.GetQulityBgName(this.itemData.Quality_get())),
this.lockObj.SetActive(this.itemData.IsBind())
const s=this.itemData.cfgData_get().job
this.jobTip.SetActive(0!=s)
let i=""
if(0!=s){i=H.V.Inst_get().JobRelationDict[m.Y.Inst.PrimaryRoleInfo_get().Job_get()].Contains(s)?`[FFEFE1FF]${p.l.getJobStr(s)}[-]`:`[E02C2CFF]${p.l.getJobStr(s)}[-]`,
this.jobLabel.textSet(i)}const n=m.Y.Inst.PrimaryRoleInfo_get().Level_get(),o=this.itemData.cfgData_get().level
this.levelTip.SetActive(0!=o)
let a=L.M.IntToString(o)
a=n>=o?L.M.Replace("[FFEFE1FF]{0}[-]","{0}",a):L.M.Replace("[E02C2CFF]{0}[-]","{0}",a),this.level.textSet(a)
const h=q.i.Inst_get().GetVipLimit(this.itemData.cfgData_get().Conditions_get())
if(0==h)this.vipTip.SetActive(!1)
else{this.vipTip.SetActive(!0)
const t=m.Y.Inst.PrimaryRoleInfo_get().VipLevel_get()
let e=L.M.IntToString(h)
e=t>=h?L.M.Replace("[FFEFE1FF]{0}[-]","{0}",e):L.M.Replace("[E02C2CFF]{0}[-]","{0}",e),this.vip.textSet(e)}this.timeObj.SetActive(!1),this.time.textSet("")
let d=null
if(null!=this.itemData.serverData_get()){const t=this.itemData.cfgData_get()
if(null==this.itemData.serverData_get().deprecatedTime||this.itemData.serverData_get().deprecatedTime.Equal(F.I.zeroLong))d=`${this.normalColor}${(0,g.T)("有效时间 ")}[-]`,
"0"==t.validTime||L.M.Contains(t.validTime,":")?(this.time.textSet(""),this.timeObj.SetActive(!1)):(this.timeObj.SetActive(!0),
d+=`${this.activeColor}${p.l.GetDateFormat(L.M.String2Double(t.validTime))}[-]`,this.time.textSet(d))
else if("0"!=t.validTime&&L.M.Contains(t.validTime,":"))this.time.textSet(""),this.timeObj.SetActive(!1)
else{this.timeObj.SetActive(!0)
let t=this.itemData.serverData_get().deprecatedTime.ToNum()/1e3-l.D.serverTime_get()
t=O.p.CeilToInt(t),d=`${this.normalColor}${(0,g.T)("剩余使用时长 ")}[-]`,t>0?(this._lefttime=t,d+=`${this.activeColor}${p.l.GetDateFormat(this._lefttime)}[-]`,
this._leftTimeIntervalId=f.C.Inst_get().SetInterval(this._degf_LeftTimeChange,1e3)):d=`${this.inactiveColor}${(0,g.T)("该物品已失效")}[-]`,this.time.textSet(d)}}
this.SetQualityAnim(this.itemData.Quality_get())
j.$.Inst().getItemById(this.itemData.cfgData_get().id)
const c=q.i.Inst_get().GetCfgResIcon(this.itemData.cfgData_get().id)
this.payTypeSp.spriteNameSet(c)
const u=q.i.Inst_get().GetCfgResNum(this.itemData.cfgData_get().id)
this.payLabel.textSet(L.M.DoubleToString(u)),this.payTip.SetActive(R.GF.INT(u)>0),
this.conditionObj.SetActive(this.jobTip.activeSelf()||this.levelTip.activeSelf()||this.vipTip.activeSelf()||this.payTip.activeSelf()),this.grid1.Reposition()
const _=q.i.Inst_get().GetItemDesc(this.itemData.cfgData_get())
this.desc.textSet(_)
const S=this.GetRewardItemData(this.itemData.cfgData_get().id)
0==S.Count()?(this.rewardsObj.SetActive(!1),this.Relayout()):(this.rewardsObj.SetActive(!0),this.rewards.data_set(S))}LeftTimeChange(){let t=`${this.normalColor}${(0,
g.T)("剩余使用时长 ")}[-]`
this._lefttime-=1,this._lefttime<1?(t=`${this.inactiveColor}${(0,g.T)("该物品已失效")}[-]`,f.C.Inst_get().ClearInterval(this._leftTimeIntervalId),
this._leftTimeIntervalId=-1):t+=`${this.activeColor}${p.l.GetDateFormat(this._lefttime)}[-]`,this.time.textSet(t)}RefreshRewardItem(){this.Relayout()}CreateRewardItem(t){
const e=new x.j
return e.setId(t,null,0),e.SetIconSize(50,50),e.SetBgSize(56,56),e}GetRewardItemData(t){const e=new G.Z,s=j.$.Inst().GetShowRewards(t)
for(const[t,i]of(0,_.V5)(s)){const t=i.GetModelId()
if(U.P.Inst_get().IsFunOpenByItemId(t)){const t=new W.t
t.modelId=i.GetModelId(),t.state=i.GetIsBind(),0==i.num?t.num=1:t.num=i.num
const s=new N.M(t.modelId)
s.serverData_set(t),s.isCanOperate=!1,s.isShowAccess=!1,s.isEquipCompare=!1,s.tipPosSetHandler=this._degf_ClickTipsCallback,0!=i.showId&&s.SetEquipAttrShowId(i.showId),e.Add(s)}}
return e}ClickTipsCallback(t){const e=this.node.transform.GetLocalPosition(),s=this.bg.width(),i=S.t.GetAdaptWidth()/2,n=e.x+s/2+Y.Y.TipsFitDis
let l=0
null==t.cfgData_get()||"PANDORA"!=t.cfgData_get().itemType&&"VIPPANDORA"!=t.cfgData_get().itemType?n<=i?(l=e.x+s/2,t.anchor=new P.F(0,.5)):(l=e.x-s/2,
t.anchor=new P.F(1,.5)):l=n<=i?e.x+s:e.x-s,t.tipsPos=new E.P(l,e.y,0)}Relayout(){let t=0
const e=E.P.zero_get()
let s=E.P.zero_get(),i=!0
t=this.timeObj.GetBoundsSize().y,t>.1&&(E.P.Recyle(s),s=this.timeObj.transform.GetLocalPosition(),e.x=s.x,i&&(e.y=0),this.timeObj.transform.SetLocalPosition(e),e.y-=t,i=!1),
t=this.conditionObj.GetBoundsSize().y,t>.1&&(E.P.Recyle(s),s=this.conditionObj.transform.GetLocalPosition(),e.x=s.x,e.y-=15,i?e.y=0:e.y+=4,
this.conditionObj.transform.SetLocalPosition(e),e.y-=t,i=!1,this.payTip.activeSelf()&&(e.y+=6)),t=this.descObj.GetBoundsSize().y,t>.1&&(E.P.Recyle(s),
s=this.descObj.transform.GetLocalPosition(),e.x=s.x,e.y-=15,i?e.y=0:e.y+=4,this.descObj.transform.SetLocalPosition(e),e.y-=t,i=!1),t=this.rewardsObj.GetBoundsSize().y,
t>.1&&(E.P.Recyle(s),s=this.rewardsObj.transform.GetLocalPosition(),e.x=s.x,e.y-=8,i&&(e.y=0),this.rewardsObj.transform.SetLocalPosition(e),e.y-=t,i=!1),E.P.Recyle(e),
E.P.Recyle(s),this.AdjustTipSize()}CalculateBgSize(){let t=1.5
t+=this.root.GetBoundsSize().y,this.btnShowCnt>0?this.BgOffset_set(t-this.hasBtnPanelSize.w):this.BgOffset_set(t-this.noBtnPanelSize.w)}AdjustTipSize(){this.CalculateBgSize()
const t=this.scrollBack.node.transform.GetLocalPosition()
if(0==this.btnShowCnt){const e=new k.L(this.noBtnPanelSize.x,this.noBtnPanelSize.y,this.noBtnPanelSize.z,this.noBtnPanelSize.w)
e.y-=this.BgOffset_get()/2,e.w+=this.BgOffset_get(),this.scrollPanel.baseClipRegionSet(e),this.scrollBack.heightSet(R.GF.INT(e.w)),t.y=e.y}else{
const e=new k.L(this.hasBtnPanelSize.x,this.hasBtnPanelSize.y,this.hasBtnPanelSize.z,this.hasBtnPanelSize.w)
e.y-=this.BgOffset_get()/2,e.w+=this.BgOffset_get(),this.scrollPanel.baseClipRegionSet(e),this.scrollBack.heightSet(R.GF.INT(e.w)),t.y=e.y}const e=E.P.zero_get()
this.scrollPanel.node.transform.SetLocalPosition(e),E.P.Recyle(e),this.scrollPanel.clipOffsetSet(b.V.TEMP_VECTOR2D_get()),this.scrollBack.node.transform.SetLocalPosition(t),
E.P.Recyle(t),this.scrollView.ResetPosition()}GetNameStr(t){return L.M.s_LEFT_M_K_CHAR+(p.l.getColorStrByQuality(t)+L.M.s_RIGHT_M_K_CHAR)}OnFullScreenColliderInit(){
null!=this.itemData&&(this.itemData.isForBag||this.itemData.isMarketItem)?(h.N.inst.SetFullScreenColliderMask(this.node.FatherId,!0),
h.N.inst.SetFullScreenColliderThrough(this.node.FatherId,!1)):(h.N.inst.SetFullScreenColliderMask(this.node.FatherId,!1),
h.N.inst.SetFullScreenColliderThrough(this.node.FatherId,!0))}}class Z{constructor(){this.itemData=null,this.view=null,this._degf_CallDestory=null,this._degf_Complete=null,
this._degf_EditorQuickAddItem=null,this._degf_SendEditorQuickAddItem=null,this._degf_CallDestory=()=>this.CallDestory(),this._degf_Complete=t=>this.Complete(t),
this._degf_EditorQuickAddItem=t=>this.EditorQuickAddItem(t),this._degf_SendEditorQuickAddItem=t=>this.SendEditorQuickAddItem(t)}static Inst_get(){
return null==Z._inst&&(Z._inst=new Z,i.i.Inst.AddEventHandler("QuickAddItemOnlyEditor1",Z._inst._degf_EditorQuickAddItem),
i.i.Inst.AddEventHandler("SendQuickAddItemOnlyEditor",Z._inst._degf_SendEditorQuickAddItem)),Z._inst}OpenView(t){if(this.itemData=t,this.EditorQuickAddItem(null),
null!=this.view&&this.view.isShow_get())this.view.UpdateView()
else{null!=this.view&&(i.i.Inst.RaiseEvent(u.g.TipsLoadCompelete),this.view.node.SetActive(!0))
const t=new a.v
t.layerType=c.F.Tip,h.N.inst.OpenById(d.I.PandoraTipsInfoPanel,this._degf_Complete,this._degf_CallDestory,t),I.J.Inst_get().ForceCloseTipView()}}EditorQuickAddItem(t){
l.D.IsEditor&&(null!=this.itemData?n.R.LuaCallCSEventString("QuickAddItemOnlyEditorBack",this.itemData._cfgData.name):n.R.LuaCallCSEventString("QuickAddItemOnlyEditorBack",null))}
SendEditorQuickAddItem(t){if(l.D.IsEditor){const e=t
if(null!=this.itemData){const t=`addItem ${this.itemData._modelId} ${e}`
o.Y.LogGMInEditor(t),p.l.sendGMComand(t)}}}Complete(t){return null==this.view&&(this.view=new z,this.view.setId(t,null,0)),i.i.Inst.RaiseEvent(u.g.TipsLoadCompelete),this.view}
CallDestory(){r.g.DestroyUIObj(this.view),this.view=null,this.itemData=null}CloseView(){null!=this.view&&this.view.isShow_get()&&(i.i.Inst.RaiseEvent(u.g.CLICK_CLOSEIP),
h.N.inst.CloseById(d.I.PandoraTipsInfoPanel),this.itemData=null)}}Z._inst=null},99327:(t,e,s)=>{s.d(e,{a:()=>_})
var i=s(97461),n=s(57647),l=s(68662),o=s(66788),a=s(56937),r=s(18202),h=s(31222),d=s(5494),c=s(52726),I=s(21554),u=s(92679),p=s(87923)
class _{constructor(){this.itemData=null,this.view=null,this._degf_CallDestory=null,this._degf_Complete=null,this._degf_EditorQuickAddItem=null,
this._degf_SendEditorQuickAddItem=null,this._degf_CallDestory=()=>this.CallDestory(),this._degf_Complete=t=>this.Complete(t),
this._degf_EditorQuickAddItem=t=>this.EditorQuickAddItem(t),this._degf_SendEditorQuickAddItem=t=>this.SendEditorQuickAddItem(t)}static Inst_get(){
return null==_._inst&&(_._inst=new _),_._inst}OpenView(t){if(this.itemData=t,this.EditorQuickAddItem(null),null!=this.view&&this.view.isShow_get())this.view.UpdateView()
else{null!=this.view&&(i.i.Inst.RaiseEvent(u.g.TipsLoadCompelete),this.view.node.SetActive(!0))
const t=new a.v
t.layerType=c.F.Tip,h.N.inst.OpenById(d.I.PandoraVipTipsInfoPanel,null,null,t,this._degf_Complete),I.J.Inst_get().ForceCloseTipView()}}Complete(t){
return i.i.Inst.RaiseEvent(u.g.TipsLoadCompelete),this.view}EditorQuickAddItem(t){
l.D.IsEditor&&(null!=this.itemData?n.R.LuaCallCSEventString("QuickAddItemOnlyEditorBack",this.itemData._cfgData.name):n.R.LuaCallCSEventString("QuickAddItemOnlyEditorBack",null))}
SendEditorQuickAddItem(t){if(l.D.IsEditor){const e=t
if(null!=this.itemData){const t=`addItem ${this.itemData._modelId} ${e}`
o.Y.LogGMInEditor(t),p.l.sendGMComand(t)}}}CallDestory(){r.g.DestroyUIObj(this.view),this.view=null,this.itemData=null}CloseView(){
null!=this.view&&this.view.isShow_get()&&(i.i.Inst.RaiseEvent(u.g.CLICK_CLOSEIP),h.N.inst.CloseById(d.I.PandoraVipTipsInfoPanel),this.itemData=null)}}_._inst=null},70531:(t,e,s)=>{
s.d(e,{R:()=>ot})
var i,n,l,o,a,r,h=s(42292),d=s(71409),c=s(17409),I=s(49655),u=s(32076),p=s(38836),_=s(86133),g=s(38045),m=s(98800),S=s(97461),f=s(56937),C=s(18202),T=s(31222),y=s(5494),A=s(52726),v=s(98885),D=s(38962),w=s(21554),B=s(70850),M=s(18152),b=s(75380),O=s(92679),R=s(31922),L=s(74045),G=s(49067),P=s(34402),E=s(47786),k=s(22662),N=s(33828),V=s(52513),x=s(65550),F=s(85942),U=s(19519),H=s(41347),j=s(9986),W=s(6665),Y=s(78287),q=s(93877),z=s(72005),Z=s(61911),X=s(85602),Q=s(63076),J=s(75696),$=s(87923),K=s(33138),tt=s(48481),et=s(7601),st=s(31896)
class it extends Z.f{constructor(...t){super(...t),this.openBtn=null,this.grid=null,this.icon=null,this.desc=null,this.btnTxt=null,this.closeBtn=null,this.bar=null,
this.rechargeCfg=null}InitView(){super.InitView(),this.openBtn=this.CreateComponent(j.W,1),this.grid=this.CreateComponent(W.A,2),this.icon=this.CreateComponent(z.w,3),
this.desc=this.CreateComponent(q.Q,4),this.btnTxt=this.CreateComponent(q.Q,5),this.closeBtn=this.CreateComponent(j.W,6),this.bar=this.CreateComponent(Y._,7),
this.isExclusionPanel=!0,this.grid.SetInitInfo("ui_baseitem",null,J.j)}OnAddToScene(){this.AddLis(),this.UpdateView()}UpdateView(){
const t=nt.Inst_get().itemData,e=t.serverData_get().modelId,s=K.f.Inst().getItemById(t.serverData_get().modelId)
if(this.rechargeCfg=V.O.Inst().GetConfigByTreasureId(e),null!=this.rechargeCfg&&null!=this.rechargeCfg){const t=et.W.Inst.GetCurSystem(),e=this.rechargeCfg.platformCurrency[t]
this.btnTxt.textSet(`${e}元开启`)}if(null!=s){const t=$.l.getColorStrByQuality(s.Quality_get())
this.desc.textSet(`开启[${t}]${s.name}[-]获得以下奖励`)
const i=this.GetRewardItemData(e)
this.grid.data_set(i),this.bar.SetValue(.5)}}Clear(){this.RemoveLis()}Destroy(){}AddLis(){this.AddClickEvent(this.openBtn,this.CreateDelegate(this.OnOpenBtnHandle)),
this.AddClickEvent(this.closeBtn,this.CreateDelegate(this.OnCloseView))}RemoveLis(){this.RemoveClickEvent(this.openBtn,this.CreateDelegate(this.OnOpenBtnHandle)),
this.RemoveClickEvent(this.closeBtn,this.CreateDelegate(this.OnCloseView))}OnCloseView(){nt.Inst_get().CloseView()}OnOpenBtnHandle(){
null!=this.rechargeCfg&&st.t.inst.Buy(this.rechargeCfg,null),this.OnCloseView()}GetRewardItemData(t){const e=new X.Z,s=P.$.Inst().GetRewardList(t)
for(const[t,i]of(0,p.V5)(s)){const t=new tt.t
t.modelId=i.itemId,0==i.num?t.num=1:t.num=i.num
const s=new Q.M(i.itemId,t)
e.Add(s)}return e}}class nt{constructor(){this.itemData=null,this.view=null,this._degf_CallDestory=null,this._degf_Complete=null,this._degf_CallDestory=()=>this.CallDestory(),
this._degf_Complete=t=>this.Complete(t)}static Inst_get(){return null==nt._inst&&(nt._inst=new nt),nt._inst}OpenView(t){if(this.itemData=t,
null!=this.view&&this.view.isShow_get())return void this.view.UpdateView()
null!=this.view&&this.view.node.SetActive(!0)
const e=new f.v
e.layerType=A.F.MainUI,e.isShowMask=!1,T.N.inst.OpenById(y.I.PandoraRechargePanel,this._degf_Complete,this._degf_CallDestory,e)}Complete(t){
return null==this.view&&(this.view=new it,this.view.setId(t,null,0)),this.view}CallDestory(){C.g.DestroyUIObj(this.view),this.view=null}CloseView(){
null!=this.view&&this.view.isShow_get()&&T.N.inst.CloseById(y.I.PandoraRechargePanel)}}function lt(t,e,s,i,n){var l={}
return Object.keys(i).forEach((function(t){l[t]=i[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=s.slice().reverse().reduce((function(s,i){return i(t,e,s)||s}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}nt._inst=null
let ot=(i=(0,h.gK)("GameSys.RyPandoraTipsControl"),n=(0,d.GH)("QuickAddItemOnlyEditor3"),l=(0,d.GH)("SendQuickAddItemOnlyEditor"),i((r=class t{constructor(){this.itemData=null,
this.pandoraShowData=null,this.bagItemData=null,this.view=null,this._degf_CallDestory=null,this._degf_Complete=null,this._degf_EditorQuickAddItem=null,
this._degf_SendEditorQuickAddItem=null,this.selectItemData=null,this._degf_CallDestory=()=>this.CallDestory(),this._degf_Complete=t=>this.Complete(t),
this._degf_EditorQuickAddItem=t=>this.EditorQuickAddItem(t),this._degf_SendEditorQuickAddItem=t=>this.SendEditorQuickAddItem(t)}static Inst_get(){
return null==t._inst&&(t._inst=new t),t._inst}DebugIsUseNew(){return!0}GetTipHeight(){return this.view.GetTipHeight()}GetTipArchePosXY(){return this.view.GetCompArchePosXY()}
OpenView(t,e=null,s=null){
if(!(0,c.Y)(I.o.PandoraSelectPanel)&&null!=t.serverData_get()&&null!=B.g.Inst_get().GetItemById(t.serverData_get().id)&&null==this.selectItemData&&P.$.Inst().getItemById(t.cfgData_get().id).optionalNum>0)return void this.OpenPandoraSelectPanel(t)
if(null!=this.view&&this.view._isPanelActive)return
null!=this.view&&(this.view.node.active=!0),null==s&&(s=!0),this.itemData=t,this.bagItemData=e,this.EditorQuickAddItem(null)
let i=new f.v
i.layerType=A.F.Tip,i.isShowMask=s,(0,c.Yp)(I.o.RyPandoraTipsView,i,(0,u.v)(this.Complete,this)),null!=this.view&&S.i.Inst.RaiseEvent(O.g.TipsLoadCompelete)}Complete(t=0){
return S.i.Inst.RaiseEvent(O.g.TipsLoadCompelete,y.I.RyPandoraTipsPanel),this.view}CallDestory(){C.g.DestroyUIObj(this.view),this.view=null,this.itemData=null}CloseView(){(0,
c.sR)(I.o.RyPandoraTipsView),(0,d.bG)(O.g.CLICK_CLOSEIP),S.i.Inst.RaiseEvent(O.g.BASE_TIP_CLOSE),this.itemData=null,this.view=null}EditorQuickAddItem(t){}
SendEditorQuickAddItem(t){}PandoraShowChildTips(t,e){this.view=(0,c.Y)(I.o.RyPandoraTipsView),null!=this.view&&this.view.ShowContainTips(t,e)}OpenPandoraSelectPanel(t){
this.selectItemData=t
const e=new f.v
e.layerType=A.F.Tip,e.isShowMask=!0,e.viewClass=b.K,(0,c.Yp)(y.I.PandoraSelectPanel,e)}OpenPandora(e){
if(null!=V.O.Inst().GetConfigByTreasureId(e.modelId_get()))return nt.Inst_get().OpenView(e),void t.Inst_get().CloseView()
let s=P.$.Inst().getItemById(e.modelId_get())
if(null!=s&&e.cfgData_get().hasOpenUIId()&&null!=s&&s.throwType&&null!=e){if(m.Y.Inst.PrimaryRole_get().Terraintype_get()!=R.z.TerrainTypeSafe)x.y.inst.ClientSysMessage(11042301)
else{const s=B.g.Inst_get().GetItemById(e.serverData_get().id)
w.J.Inst_get().UseItem(s.baseData_get()),w.J.Inst_get().closeBag(),t.Inst_get().CloseView()}return}
const i=e.cfgData_get().id,n=P.$.Inst().GetOptionalNum(i),l=H.i.Inst_get().selectRewardList
if(s=P.$.Inst().getItemById(i),l.Count()<n){const t=n-l.Count(),e=E.x.Inst().getItemById(101507),s=v.M.Replace(e.sys_messsage,"{0}",v.M.IntToString(t))
return void x.y.inst.ClientStrMsg(k.r.SystemTipMessage,s)}if(1==s.funtionType||2==s.funtionType||4==s.funtionType){
const n=P.$.Inst().GetRewardList(i),o=H.i.Inst_get().GetRecommondGroup(i)
let a=0,r=!0
for(let t=0;t<=l.Count()-1;t++){const e=l[t]-1
null!=o&&o.Contains(n[e].id)?a+=1:r=!1}if(!(null==o||a>=o.Count()||r)){const i=new F.N
return 1==s.funtionType?i.showText=(0,_.T)("您选择的装备不是推荐装备，是否确定选择"):2==s.funtionType?i.showText=(0,_.T)("您选择的技能书为非推荐技能，是否确定选择"):4==s.funtionType&&(i.showText=(0,
_.T)("您选择的装备不是推荐装备，是否确定选择")),i.okhandler=()=>{this.OpenItem(e),INS.itemTipManager.CloseTipView(),t.Inst_get().CloseView()},i.tipstype=2,void x.y.inst.OpenCommonMessageTips(i)}}
const o=e.cfgData_get().Consums_get().costs
if(o.Count()>0){const t=o[0],s=(0,g.aI)(t.subvalue)*H.i.Inst_get().GetAllNum()
if(s>U.J.GetGold(m.Y.Inst.PrimaryRoleInfo_get(),t.subtype))t.subtype==U.J.GOLD_DIAMOND_STR?N.Y.Inst_get().OpenTip(this.OnOpenDiamondTip):x.y.inst.ClientSysMessage(100501)
else{const i=P.$.Inst().GetShowRewards(e.cfgData_get().id),n=new G.B
n.confirmHandle=()=>{this.OpenItem(e)},n.infoId="BAG:DIAMOND_GIFT"
let l="{"
for(let t=0;t<=i.Count()-1;t++)0!=t&&(l+=","),l+=`${i[t].GetModelId()}:${i[t].num}`
l+="}",n.showNum=!0,n.replaceParams.Add(`[CURRENCY:${t.subtype}]`),n.replaceParams.Add(`${s}`),n.replaceParams.Add(l),L.t.Inst().Open(n)}}else this.OpenItem(e)
INS.itemTipManager.CloseTipView(),t.Inst_get().CloseView()}OpenItem(t){const e=H.i.Inst_get().selectRewardNumDict
let s=""
for(const[t,i]of(0,p.V5)(e))for(let e=1;e<=i;e++)""==s?s=v.M.IntToString(t):s+=`,${v.M.IntToString(t)}`
const i=new D.X
i.LuaDic_AddOrSetItem("optionals",s),0==t.cfgData_get().batch?w.J.Inst_get().CM_UseItemReq(t.serverData_get().id,1,null,null,!1,null):null!=t.serverData_get()&&1==t.serverData_get().num?w.J.Inst_get().CM_UseItemReq(t.serverData_get().id,1,i,null,!1,null):P.$.Inst().IsChoosePandora(t.cfgData_get().id)?w.J.Inst_get().CM_UseItemReq(t.serverData_get().id,H.i.Inst_get().GetAllNum(),i,null,!1,null):(B.g.Inst_get().batchUseParams=i,
B.g.Inst_get().CloneSelectItemData(t),B.g.Inst_get().curSelectItemData.IconType_Set(M.s.BASE_ICON_TYPE),w.J.Inst_get().OpenBatchAlert()),T.N.inst.CloseById(y.I.PandoraSelectPanel)}
OnOpenDiamondTip(t){N.Y.Inst_get().OkHandler(null)}},r._inst=null,lt(a=r,"Inst_get",[h.Vx],Object.getOwnPropertyDescriptor(a,"Inst_get"),a),
lt(a.prototype,"EditorQuickAddItem",[n],Object.getOwnPropertyDescriptor(a.prototype,"EditorQuickAddItem"),a.prototype),
lt(a.prototype,"SendEditorQuickAddItem",[l],Object.getOwnPropertyDescriptor(a.prototype,"SendEditorQuickAddItem"),a.prototype),o=a))||o)},41347:(t,e,s)=>{s.d(e,{i:()=>O})
var i=s(85602),n=s(87923),l=s(98800),o=s(62370),a=s(98885),r=s(33138),h=s(34402),d=s(19519),c=s(70850),I=s(23628),u=s(42534),p=s(63076),_=s(37648),g=s(55492),m=s(92679),S=s(77546),f=s(38836),C=s(86133),T=s(97461),y=s(68662),A=s(70829),v=s(35128),D=s(38962),w=s(48933),B=s(47653),M=s(35048),b=s(50748)
class O{constructor(){this.selectRewardList=null,this.selectRewardNumDict=null,this.selectingGroupId=0,this.useData=null,this.guardData=null,this.selectRewardList=new i.Z,
this.selectRewardNumDict=new D.X}static Inst_get(){return null==O._inst&&(O._inst=new O),O._inst}GetLeftTimeTips(t){let e=null
if(null==t.serverData_get().deprecatedTime||t.serverData_get().deprecatedTime.Equal(w.I.zeroLong))e=this.GetLeftTimeTips2(t.baseData_get())
else{let s=t.serverData_get().deprecatedTime.ToNum()/1e3-y.D.serverTime_get()
if(s=v.p.CeilToInt(s),s>0){const i=t.baseData_get().cfgData_get().validTime
a.M.Contains(i,":")?e=a.M.Replace("[FFEFE1FF]{0}[-]","{0}",i):(e=n.l.GetDateFormat(s,null,null,null),e=a.M.Replace("[FFEFE1FF]{0}[-]","{0}",e))}else e=(0,C.T)("该物品已失效"),
e=a.M.Replace("[E02C2CFF]{0}[-]","{0}",e)}return e}GetLeftTimeTips2(t){let e=null
const s=t.cfgData_get().validTime
if(n.l.IsEmptyStr(s)||"0"==s)e=""
else if(a.M.Contains(s,":"))e=a.M.Replace("[FFEFE1FF]{0}[-]","{0}",s)
else{const t=a.M.String2Double(s)
e=n.l.GetDateFormat(t,null,null,null),e=a.M.Replace("[FFEFE1FF]{0}[-]","{0}",e)}return e}GetItemDesc(t){let e=a.M.Replace(t.describe,"\\n","\n")
const s=h.$.Inst().getItemById(t.id)
if(s.minNum==s.maxNum)e=a.M.Replace(e,"{0}",a.M.IntToString(s.minNum))
else{const t=`${a.M.IntToString(s.minNum)}-${a.M.IntToString(s.maxNum)}`
e=a.M.Replace(e,"{0}",t)}return e}GetVipLimit(t){let e=0
const s=t.typevalues
if(null!=s)for(const[t,i]of(0,f.V5)(s))if("VIPLevelGT"==i.valueType){e=i.valueNum
break}return e}GetCfgResIcon(t){const e=r.f.Inst().getItemById(t)
if(null!=e&&0!=e.Consums_get().costs.Count()){const t=e.Consums_get().costs[0],s=a.M.Split(t.value,o.o.s_Arr_UNDER_COLON)
return d.J.GetCurrencyIconUrl(s[0])}return""}GetCfgResNum(t){const e=r.f.Inst().getItemById(t)
if(null!=e&&0!=e.Consums_get().costs.Count()){const t=e.Consums_get().costs[0],s=a.M.Split(t.value,o.o.s_Arr_UNDER_COLON)
return a.M.String2Double(s[1])}return 0}GetPlayerResNum(t){const e=r.f.Inst().getItemById(t)
if(null!=e&&0!=e.Consums_get().costs.Count()){const t=e.Consums_get().costs[0],s=a.M.Split(t.value,o.o.s_Arr_UNDER_COLON)
return d.J.GetGold(l.Y.Inst.PrimaryRoleInfo_get(),s[0])}return 0}RewardHasAngelEq(t){if(null==t||null==t.itemList)return!1
for(const[e,s]of(0,f.V5)(t.itemList)){const t=u.f.Inst().tryGetItemById(s.modelId)
if(null!=t&&t.IsAngelEquip())return!0}return!1}GetRecommondSuitGroupIds(t){const e=h.$.Inst().GetRewardList(t),s=new i.Z
for(let t=0;t<=e.Count()-1;t++){const i=e[t],n=i.GetModelId()
let o=0
const a=r.f.Inst().getItemById(n).Jobs_get()
for(const[t,e]of(0,f.V5)(l.Y.Inst.primaryRoleInfoList))I.b.IsRecommendJob(e.Job_get(),a)&&(o+=1)
if(0==o);else{let t=c.g.Inst_get().GetItemNum(n),e=!1
if(t>=o)e=!0
else{t+=l.Y.Inst.GetAllEquipmentNumByModelId(n),t>=o&&(e=!0)}e||s.Add(i)}}const n=new i.Z
let o=0
for(let t=0;t<=s.Count()-1;t++){const e=s[t],i=e.GetModelId(),a=u.f.Inst().getItemById(i).suitId
let r=0
for(const[t,e]of(0,f.V5)(l.Y.Inst.primaryRoleInfoList))if(e.GetEquipmentNumByModelId(i)>0);else for(const[t,s]of(0,f.vy)(e.AllStageEquipments_get())){
const s=e.GetSuitActivatedCount(t,a)
s>r&&(r=s)}r>o?(n.Clear(),n.Add(e.id),o=r):(r==o||0==n.Count())&&n.Add(e.id)}return n.Count()==e.Count()?null:n}GetRecommondSkillBookGroupIds(t){
const e=h.$.Inst().GetRewardList(t),s=h.$.Inst().getItemById(t),n=new i.Z
let o=1e3,a=0
for(let t=0;t<=e.Count()-1;t++){const i=e[t],r=new p.M(i.GetModelId());(1!=s.jobLimit||I.b.IsRecommendJobForAllRole(r))&&(a+=1)
const h=r.cfgData_get().GetRewardsSkillId()
for(const[t,e]of(0,f.V5)(l.Y.Inst.primaryRoleInfoList))if(b.m.Inst().CanLearnSkill(A.j.Inst().GetSkillById(h),e)&&null==b.m.Inst().GetSkillByStudyDic(h,e))o>0&&n.Clear(),o=0,
n.Add(i.id)
else if(o>0)for(const[t,s]of(0,f.V5)(e.Skills_get()))s.id==h&&(s.level<o?(o=s.level,n.Clear(),n.Add(i.id)):s.level==o&&n.Add(i.id))}return n.Count()==a?null:n}
GetRecommondDivineGroupIds(t){const e=h.$.Inst().GetRewardList(t)
let s=new i.Z
if(!_.P.inst.IsFunctionOpened(g.x.DIVINE))return s
let n=1e5
for(let t=0;t<=e.Count()-1;t++){const i=e[t],l=i.GetModelId(),o=M.j.Inst.GetDivineByItemId(l)
if(null!=o){const t=B.x.Inst().GetHoleInfoByDivineIdAndLocId(o.divineId,o.locId)
null==t?n=0:t.holeStage<n?(n=t.holeStage,s.Clear(),s.Add(i.id)):t.holeStage==n&&s.Add(i.id)}else S.s.Info(`找不到该道具${l}对应的圣物`)}return s.Count()==e.Count()?(s.Clear(),s=null,null):s}
GetRecommondEquipGroupIds(t){const e=h.$.Inst().GetRewardList(t),s=new i.Z
for(let t=0;t<=e.Count()-1;t++){const i=e[t],n=i.GetModelId(),l=new p.M(n,null),[o,a]=I.b.GetUpColumnAndPosForAllRole(l,!1)
a>0&&s.Add(i.id)}return s.Count()==e.Count()?null:s}GetRecommondGroup(t){const e=h.$.Inst().getItemById(t)
return null==e?null:1==e.funtionType?this.GetRecommondSuitGroupIds(t):2==e.funtionType?this.GetRecommondSkillBookGroupIds(t):3==e.funtionType?this.GetRecommondDivineGroupIds(t):4==e.funtionType?this.GetRecommondEquipGroupIds(t):null
}AddSelect(t,e){0!=e?(this.selectRewardList.Contains(t)||this.selectRewardList.Add(t),this.selectRewardNumDict.LuaDic_AddOrSetItem(t,e),
T.i.Inst.RaiseEvent(m.g.RY_PANDORA_SELECT_NUM_CHANGE,t)):this.RemoveSelect(t)}RemoveSelect(t){this.selectRewardList.Remove(t),this.selectRewardNumDict.LuaDic_Remove(t),
T.i.Inst.RaiseEvent(m.g.RY_PANDORA_SELECT_NUM_CHANGE,t)}ClearSelect(){this.selectRewardList.Clear(),this.selectRewardNumDict.Clear(),
T.i.Inst.RaiseEvent(m.g.RY_PANDORA_SELECT_NUM_CHANGE)}GetAllNum(t=null){let e=0
for(const[s,i]of(0,f.V5)(this.selectRewardNumDict))null!=t&&t==s||(e+=i)
return e}GetSelectNum(t){return this.selectRewardNumDict.LuaDic_ContainsKey(t)?this.selectRewardNumDict.LuaDic_GetItem(t):0}}O._inst=null},8816:(t,e,s)=>{s.d(e,{O:()=>i})
class i{constructor(){this.bag=null,this.tipsItemData=null,this.group=0,this.isRecommond=!1,this.gray=!1,this.enable_click=!0,this.needJobLimit=!1}}},54053:(t,e,s)=>{s.d(e,{L:()=>N
})
var i,n=s(18998),l=s(75507),o=s(6847),a=s(83908),r=s(17409),h=s(46282),d=s(38836),c=s(86133),I=s(38045),u=s(41664),p=s(5924),_=s(5494),g=s(98885),m=s(85602),S=s(38962),f=s(1240),C=s(21554),T=s(70850),y=s(63076),A=s(15033),v=s(75696),D=s(30834),w=s(85751),B=s(33138),M=s(34402),b=s(48481),O=s(72208),R=s(18161),L=s(11162),G=s(52513),P=s(19519),E=s(682),k=s(41347)
let N=(0,o.s_)(_.I.PandoraRewardShowPanel,h.Z.ui_pandora_rewardshowpanel).register()(i=class extends((0,a.pA)(D.n)()){constructor(...t){super(...t),this.rewardEffectList=null,
this.rewardTimeId=0,this.rewardIndex=-1,this.canScroll=!1,this.scrollLocalPos=null,this.scrollWorldPos=null,this.delayExecutor=null,this._degf_ClickTipsCallback=null,
this._degf_HandleRewardTimer=null,this._degf_OnClose=null,this._degf_OnOpen=null,this._degf_OnPay=null,this._degf_OnRewardEffect1End=null,this._degf_OnRewardEffect2End=null,
this._degf_OnRewardEffect3End=null,this._degf_OnRewardEffect4End=null,this._degf_OnRewardEffect5End=null,this._degf_OnRewardEffect6End=null,this._degf_OnRewardEffect7End=null,
this._degf_OnRewardEffect8End=null,this._degf_SetGridCallback=null,this._degf_OnLightEffectEnd=null}InitView(){this.rewards.SetInitInfo("ui_baseitem",null,v.j),
this.rewards.OnReposition_set(this.CreateDelegate(this.SetGridCallback)),this.rewardEffectList=new m.Z,this.rewardEffectList.Add(this.effReward1),
this.rewardEffectList.Add(this.effReward2),this.rewardEffectList.Add(this.effReward3),this.rewardEffectList.Add(this.effReward4),this.rewardEffectList.Add(this.effReward5),
this.rewardEffectList.Add(this.effReward6),this.rewardEffectList.Add(this.effReward7),this.rewardEffectList.Add(this.effReward8)}OnAddToScene(){this.AddListeners(),
this.UpdateView(),u.j.Inst.PlayByDivision("Pandora")}Clear(){k.i.Inst_get().useData=null,k.i.Inst_get().guardData=null,this.RemoveListeners(),this.StopRewardTimer(),
this.effLight1.SetActive(!1),this.effLight2.SetActive(!1),this.StopRewardEffect()}Destroy(){this.rewards.Destroy(),this.rewardEffectList.Clear(),this.rewardEffectList=null}
AddListeners(){this.close2.node.on(n.NodeEventType.TOUCH_END,this.OnClose,this),this.m_handlerMgr.AddClickEvent(this.open,this.CreateDelegate(this.OnOpen)),
this.m_handlerMgr.AddClickEvent(this.pay,this.CreateDelegate(this.OnPay)),(0,r.D1)(this,this.CreateDelegate(this.OnClose))}RemoveListeners(){
this.close2.node.off(n.NodeEventType.TOUCH_END,this.OnClose,this),this.RemoveClickEvent(this.pay,this._degf_OnPay),(0,r.Rt)(this)}OnOpen(t,e){const s=k.i.Inst_get().useData
if(null!=s){const t=T.g.Inst_get().GetItemByModleID(s.itemModelId)
if(null==t)return
const e=new S.X
e.LuaDic_AddOrSetItem("optionals",""),C.J.Inst_get().CM_UseItemReq(t.serverData_get().Id_get(),1,e,null,!1)}}OnPay(t,e){const s=k.i.Inst_get().useData
if(null!=s){const t=T.g.Inst_get().GetItemByModleID(s.itemModelId)
if(k.i.Inst_get().GetPlayerResNum(t.baseData_get().cfgData_get().id)>=k.i.Inst_get().GetCfgResNum(t.baseData_get().cfgData_get().id)){const e=new S.X
e.LuaDic_AddOrSetItem("optionals",""),C.J.Inst_get().CM_UseItemReq(t.serverData_get().id,1,e,null,!1)}else L.O.Inst_get().Open(1)}}OnClose(t,e){E.x.Inst_get().CloseView()}
UpdateView(){this.effLight2.SetActive(!1),this.effLight2.SetActive(!0),this.effLight1.SetActive(!1),this.effLight1.SetActive(!0),this.lightPanel.SetActive(!1),
this.lightPanel.SetActive(!0),this.UpdateReward()
const t=k.i.Inst_get().useData
if(null!=t){const e=B.f.Inst().getItemById(t.itemModelId),s=new y.M(t.itemModelId),i=(t.leftNum,M.$.Inst().getItemById(t.itemModelId))
let n=""
const l=G.O.Inst().GetConfigByTreasureId(e.id)
if(null==e||null==i)this.pay.node.SetActive(!1),this.open.node.SetActive(!1),this.close2.node.SetActive(!0)
else if(1==e.batch||0!=i.optionalNum||null!=l)this.pay.node.SetActive(!1),this.open.node.SetActive(!1),this.close2.node.SetActive(!0)
else if(t.leftNum>0&&(n=s.GetNameStr(null,null,null),n=g.M.Replace((0,c.T)("{0}剩余个数："),"{0}",n),n+=g.M.Replace(`${w.u.GreenColorStr2}{0}[-]`,"{0}",g.M.IntToString(t.leftNum))),
this.open.node.SetActive(0!=t.leftNum&&0==e.Consums_get().costs.Count()),this.pay.node.SetActive(0!=t.leftNum&&0!=e.Consums_get().costs.Count()),
this.close2.node.SetActive(0==t.leftNum),0!=e.Consums_get().costs.Count()){const t=k.i.Inst_get().GetCfgResIcon(e.id)
this.payIcon.spriteNameSet(t)
const s=k.i.Inst_get().GetCfgResNum(e.id)
this.payNum.textSet(g.M.DoubleToString(s))}this.LeftNum.textSet(n)}}UpdateReward(){this.StopRewardTimer(),this.StopRewardEffect()
const t=new m.Z,e=k.i.Inst_get().useData
if(null!=e){if(null!=e.rewards&&null!=e.rewards.rewards)for(const[s,i]of(0,d.V5)(e.rewards.rewards)){if((0,I.t2)(i,R.e)){
const e=i,s=this.createBagItemData(e.itemModelId,e.num,this._degf_ClickTipsCallback)
t.Add(s)}if((0,I.t2)(i,O.L)){const e=i,s=P.J.GetItemID(e.type),n=e.num.ToNum(),l=this.createBagItemData(s,n,this._degf_ClickTipsCallback)
t.Add(l)}}if(null!=e.itemList)for(const[s,i]of(0,d.V5)(e.itemList)){const e=this.GetBagItemData(i)
t.Add(e)}}else{const e=k.i.Inst_get().guardData
if(null!=e)for(const[s,i]of(0,d.vy)(e.rewards)){const i=new b.t
i.modelId=s,i.num=e.rewards[s]
const n=new y.M(i.modelId,i)
t.Add(n)}this.pay.node.SetActive(!1),this.open.node.SetActive(!1)}this.rewards.data_set(t)}createBagItemData(t,e,s){let i=null
const n=T.g.Inst_get().GetItemByModleID(t)
if(null!=n&&n.baseData_get().BagItemType_get()==A.r.Equip){i=n.serverData_get().Clone()}else i=new b.t,i.modelId=t,i.num=e
return this.GetBagItemData(i)}GetBagItemData(t){const e=new f.Y
return e.serverData_set(t),e.baseData_get().isCanOperate=!1,e.baseData_get().isEquipCompare=!1,e.baseData_get().tipPosSetHandler=this._degf_ClickTipsCallback,e}CreateRewardItem(t){
const e=l.o.getPrefab("ui_baseitem")
return(0,n.instantiate)(e).getCNode(v.j)}SetGridCallback(){
for(var t=0;t<this.rewards.itemList.length;t++)this.rewards.itemList[t].node.x=(this.rewards.node.transform.width-this.rewards.cellWidth*this.rewards.itemList.length)/2+t*this.rewards.cellWidth
}ClickTipsCallback(t){}StartRewardTimer(){this.rewardIndex=0,this.rewardTimeId=p.C.Inst_get().SetInterval(this._degf_HandleRewardTimer,200),this.HandleRewardTimer()}
StopRewardTimer(){0!=this.rewardTimeId&&(p.C.Inst_get().ClearInterval(this.rewardTimeId),this.rewardTimeId=0),this.rewardIndex=-1}HandleRewardTimer(){
u.j.Inst.PlayByDivision("PandoraSingle")
let t=this.rewards.itemList[this.rewardIndex]
t.SetActive(!0),this.PlayRewardEffect(this.rewardIndex)
const e=this.rewards.itemList.Count(),s=this.rewardEffectList.Count()
if(this.rewardIndex+=1,this.rewardIndex==e||this.rewardIndex==s){for(;this.rewardIndex<e;)t=this.rewards.itemList[this.rewardIndex],t.SetActive(!0),this.rewardIndex+=1
this.StopRewardTimer()}}PlayLightEffect(t){}PlayRewardEffect(t){}StopRewardEffect(){}OnRewardEffect1End(){this.OnRewardEffectEnd(0)}OnRewardEffect2End(){this.OnRewardEffectEnd(1)}
OnRewardEffect3End(){this.OnRewardEffectEnd(2)}OnRewardEffect4End(){this.OnRewardEffectEnd(3)}OnRewardEffect5End(){this.OnRewardEffectEnd(4)}OnRewardEffect6End(){
this.OnRewardEffectEnd(5)}OnRewardEffect7End(){this.OnRewardEffectEnd(6)}OnRewardEffect8End(){this.OnRewardEffectEnd(7)}OnRewardEffectEnd(t){
this.rewardEffectList[t].node.SetActive(!1)
const e=this.rewards.itemList.Count(),s=this.rewardEffectList.Count();(t+=1)!=e&&t!=s||(this.scrollView.enabled=this.canScroll)}})||i},4127:(t,e,s)=>{s.d(e,{x:()=>p})
var i=s(83908),n=s(38836),l=s(86133),o=s(98800),a=s(62370),r=s(9057),h=s(60130),d=s(18152),c=s(92679),I=s(33314),u=s(41347)
class p extends((0,i.pA)(r.x)()){constructor(...t){super(...t),this.data=null,this.needOpen=!0}InitView(){super.InitView()}Clear(){super.Clear(),
this.ui_baseitem.ClickHandler_Set(null)}Destroy(){super.Destroy()}SetData(t){if(this.AddListeners(),this.data=t,this.data.bag.iconType=d.s.BASE_ICON_TYPE_64_64,
this.ui_baseitem.icon_height=66,this.ui_baseitem.icon_width=66,this.ui_baseitem.quality_width=66,this.ui_baseitem.quality_height=66,this.ui_baseitem.SetIconSize(66,66),
this.ui_baseitem.SetBgSize(66,66),this.ui_baseitem.SetData(this.data.bag),this.ui_baseitem.EnabledClickOpenTip(!1),this.UpdateNum(),this.UpdateSelect(),this.needOpen=!0,
this.data.needJobLimit){this.needOpen=!1
for(const[t,e]of(0,n.V5)(o.Y.Inst.primaryRoleList))if(I.Z.GetJobBaseValue(e.Roleinfo_get().job)==I.Z.GetJobBaseValue(this.data.bag.cfgData_get().job)){this.needOpen=!0
break}}this.needOpen?h.O.makeGoGray(this.node,!1):h.O.makeGoGray(this.node,!0),this.data.isRecommond?this.recommondPic.SetActive(!0):this.recommondPic.SetActive(!1),
this.text_name.textSet(this.data.bag.GetItemNameStr())}AddListeners(){this.m_handlerMgr.AddEventMgr(c.g.RY_PANDORA_SELECT_CHANGE,this.CreateDelegate(this.UpdateSelect))}
UpdateNum(){const t=u.i.Inst_get().GetSelectNum(this.data.group)
if(0==t)this.text_num.textSet(""),this.text_name.node.SetActive(!0)
else{if(!this.data.enable_click)return
this.text_num.textSet(a.o.Format((0,l.T)("已选:{0}"),t)),this.text_name.node.SetActive(!1)}}UpdateSelect(){
this.data.enable_click?this.img_select.node.SetActive(this.data.group==u.i.Inst_get().selectingGroupId&&null!=this.data.tipsItemData&&this.data.tipsItemData==INS.ryPandoraTipsControl.itemData):this.img_select.node.SetActive(!1)
}}},19276:(t,e,s)=>{s.d(e,{C:()=>g})
var i=s(93984),n=s(38836),l=s(86133),o=s(66788),a=s(55360),r=s(85602),h=s(38962),d=s(23833),c=s(62370),I=s(98885),u=s(24524),p=s(55552)
class _{constructor(t){this.m_info=null,this.m_resource=null,this.m_objCfg=null,this.m_copyCfg=null,this.recomLvList=null,this.m_info=t}resource_get(){
return null==this.m_resource&&(this.m_resource=p.h.GetInst().GetSpwanItemById(this.m_info.spawnId)),this.m_resource}ObjCfg_get(){if(null==this.m_objCfg){const t=this.resource_get()
this.m_objCfg=d.a.getInst().getObjById(t.objectKey)}return this.m_objCfg}copyCfg_get(){return null==this.m_copyCfg&&(this.m_copyCfg=u.o.Inst().getItemById(this.m_info.copyid)),
this.m_copyCfg}id_get(){return this.m_info.id}type_get(){return this.m_info.type}monsterId_get(){return this.m_info.monsterId}name_get(){return this.m_info.name}desc_get(){
return this.m_info.desc}mapId_get(){return null!=this.resource_get()?I.M.String2Int(this.resource_get().mapId):0}normalMapId_get(){
return I.M.String2Int(this.resource_get().sceneId)}copyid_get(){return this.m_info.copyid}x_get(){return this.resource_get().x}y_get(){return this.resource_get().y}roleNum_get(){
return this.m_info.roleNum}levelDiplay_get(){return this.m_info.levelDiplay}drop_get(){return this.m_info.drop}extraDrop_get(){return this.m_info.extraDropp}switchedLine_get(){
return this.m_info.switchedLine}recommandnum_get(){return this.m_info.recommandnum}showDrop_get(){return this.m_info.showDrop}dropDesc_get(){return this.m_info.dropDesc}
autoHang_get(){return this.m_info.autoHang}NearPos_get(){return this.m_info.nearPos}FightPos_get(){return this.m_info.fightPos}TransportID_get(){return this.m_info.transportId}
GetPos(){const t=new r.Z,e=this.m_info.position,s=I.M.Split(e,c.o.s_UNDER_CHAR),i=I.M.String2Float(s[0]),n=I.M.String2Float(s[1]),l=I.M.String2Float(s[2])
return t.Add(i),t.Add(n),t.Add(l),t}GetRotate(){
const t=new r.Z,e=this.m_info.rotation,s=I.M.Split(e,c.o.s_UNDER_CHAR),i=I.M.String2Float(s[0]),n=I.M.String2Float(s[1]),l=I.M.String2Float(s[2])
return t.Add(i),t.Add(n-180),t.Add(l),t}GetScale(){return this.m_info.scale}quality_get(){return this.m_info.quality}GetRecommendLvArea(){if(null==this.recomLvList){
this.recomLvList=new r.Z
let t=I.M.Replace(this.m_info.recommendLevel,I.M.s_LEFT_M_K_CHAR_REPLACE,"")
t=I.M.Replace(t,"]","")
const e=I.M.Split(t,I.M.s_SPAN_CHAR)
if(null!=e){let t=0
for(;t<e.count;){const s=I.M.String2Double(e[t])
this.recomLvList.Add(s),t+=1}}}return this.recomLvList}highestLv_get(){return this.m_info.bestEquipStepLv}equipPos_get(){return this.m_info.bestEquipPosition}}class g{
constructor(){this.BossInfoMap=null,this.WorldBossInfoMap=null,this.VipBossInfoMap=null,this.BossInfoMap=new h.X,this.WorldBossInfoMap=new h.X,this.VipBossInfoMap=new h.X
const t=a.Y.Inst.GetOrCreateCsv(i.h.eBossInfo).GetCsvMap()
for(const[e,s]of(0,n.V5)(t))this.BossInfoMap.LuaDic_AddOrSetItem(s.id,new _(s)),2==s.type&&this.WorldBossInfoMap.LuaDic_AddOrSetItem(s.monsterId,new _(s)),
1==s.type&&this.VipBossInfoMap.LuaDic_AddOrSetItem(s.id,new _(s))}static Inst(){return null==g._inst&&(g._inst=new g),g._inst}getItemById(t){
return this.BossInfoMap.LuaDic_ContainsKey(t)?this.BossInfoMap[t]:null}getWorldBossItemByBossId(t){
return this.WorldBossInfoMap.LuaDic_ContainsKey(t)?this.WorldBossInfoMap[t]:(o.Y.LogError((0,l.T)("bossinfo表中世界boss中找不到这个ID")+t),null)}GetItemByMonsterId(t){for(const[e,s]of(0,
n.V5)(this.BossInfoMap))if(s.monsterId_get()==t)return s
return null}GetItemByBossId(t){for(const[e,s]of(0,n.V5)(this.BossInfoMap))if(s.id_get()==t)return s
return null}GetIdByMonsterId(t){const e=this.GetItemByMonsterId(t)
return null==e?0:e.id_get()}GetItemByType(t){const e=new r.Z
for(const[s,i]of(0,n.V5)(this.BossInfoMap))i.type_get()==t&&e.Add(i)
return e}GetBossesByMap(t){const e=new r.Z
for(const[s,i]of(0,n.V5)(this.BossInfoMap))i.mapId_get()==t&&e.Add(i)
return e}GetBossesByCopy(t){const e=new r.Z
for(const[s,i]of(0,n.V5)(this.BossInfoMap))i.copyid_get()==t&&e.Add(i)
return e}GetBossesByCopyNewHand(t){const e=new r.Z
for(const[s,i]of(0,n.V5)(this.BossInfoMap))i.monsterId_get()==t&&e.Add(i)
return e}GetTabById(t){for(const[e,s]of(0,n.V5)(this.BossInfoMap))if(s.monsterId_get()==t)return s.type_get()
return 0}GetTabByBossId(t){return this.getItemById(t).type_get()}GetTab1Count(){let t=0
for(const[e,s]of(0,n.vy)(this.BossInfoMap))1==this.getItemById(e).type_get()&&(t+=1)
return t}GetTab2Count(){let t=0
for(const[e,s]of(0,n.vy)(this.BossInfoMap))2==this.getItemById(e).type_get()&&(t+=1)
return t}GetPosById(t){let e=0
return e=1==this.getItemById(t).type_get()?t-1:t-this.GetTab1Count()-1,e}GetBossIdbyEquipId(t){const e=new r.Z
for(const[s,i]of(0,n.V5)(this.BossInfoMap))i.equipPos_get()==t&&e.Add(i.id_get())
return e}GetBossIdByCopy(t){for(const[e,s]of(0,n.V5)(this.BossInfoMap))if(s.copyid_get()==t)return s.id_get()
return 0}GetBossInfo(t){const e=a.Y.Inst.GetOrCreateCsv(i.h.eBossInfo).GetCsvMap()
for(const[s,i]of(0,n.vy)(e))if(i.id==t)return i}}g._inst=null},26223:(t,e,s)=>{s.d(e,{x:()=>R})
var i=s(32076),n=s(86133),l=s(38045),o=s(23833),a=s(98800),r=s(97461),h=s(68662),d=s(5494),c=s(98130),I=s(98885),u=s(92679),p=s(77477),_=s(74045),g=s(39879),m=s(49067),S=s(41670),f=s(29839),C=s(75439),T=s(22662),y=s(65550),A=s(39043),v=s(21334),D=s(22046),w=s(77344),B=s(12417),M=s(19276),b=s(70415),O=s(88934)
class R{constructor(){this.bossHomeTip=null,this.wbRuleTip=null,this.nbRuleTip=null,this.vbRuleTip=null,this.kbRuleTip=null,this.bossBattleTip=null,this._degf_CallDestoryTip=null,
this._degf_CallKbTipDestory=null,this._degf_CallNbTipDestory=null,this._degf_CallTipDestory=null,this._degf_CallVbTipDestory=null,this._degf_CallWbTipDestory=null,
this._degf_CheckBossLevel=null,this._degf_CheckPosUnlock=null,this._degf_GotoBoss=null,this._degf_OnTipLoaded=null,this._degf_OpenChapter=null,this._degf_ShowKbTipHandler=null,
this._degf_ShowNbTipHandler=null,this._degf_ShowTipHandler=null,this._degf_ShowTipHigherBoss=null,this._degf_ShowTipHigherLayer=null,this._degf_ShowVbTipHandler=null,
this._degf_ShowWbTipHandler=null,this._degf_CallDestoryTip=()=>this.CallDestoryTip(),this._degf_CallKbTipDestory=()=>this.CallKbTipDestory(),
this._degf_CallNbTipDestory=()=>this.CallNbTipDestory(),this._degf_CallTipDestory=()=>this.CallTipDestory(),this._degf_CallVbTipDestory=()=>this.CallVbTipDestory(),
this._degf_CallWbTipDestory=()=>this.CallWbTipDestory(),this._degf_CheckBossLevel=t=>this.CheckBossLevel(t),this._degf_CheckPosUnlock=t=>this.CheckPosUnlock(t),
this._degf_GotoBoss=t=>this.GotoBoss(t),this._degf_OnTipLoaded=t=>this.OnTipLoaded(t),this._degf_OpenChapter=t=>this.OpenChapter(t),
this._degf_ShowKbTipHandler=t=>this.ShowKbTipHandler(t),this._degf_ShowNbTipHandler=t=>this.ShowNbTipHandler(t),this._degf_ShowTipHandler=t=>this.ShowTipHandler(t),
this._degf_ShowTipHigherBoss=t=>this.ShowTipHigherBoss(t),this._degf_ShowTipHigherLayer=t=>this.ShowTipHigherLayer(t),this._degf_ShowVbTipHandler=t=>this.ShowVbTipHandler(t),
this._degf_ShowWbTipHandler=t=>this.ShowWbTipHandler(t)}static Inst_get(){return null==R.inst&&(R.inst=new R),R.inst}OpenTip(){const t=new UIOpenParam
t.layerType=LayerType.Alert,t.isShowMask=!0,t.isSelfTween=!1,UIShowMgr.inst.OpenById(d.I.BossHomeTipPanel,this._degf_ShowTipHandler,this._degf_CallTipDestory,t)}CloseTip(){
UIShowMgr.inst.CloseById(d.I.BossHomeTipPanel)}ShowTipHandler(t){return null==this.bossHomeTip&&(this.bossHomeTip=new BossHomeTipView,this.bossHomeTip.setId(t,null,0)),
this.bossHomeTip}CallTipDestory(){UIResMgr.DestroyUIObj(this.bossHomeTip),this.bossHomeTip=null}OpenWbTip(){const t=new UIOpenParam
t.layerType=LayerType.Alert,UIShowMgr.inst.OpenById(d.I.WorldBossRulePanel,this._degf_ShowWbTipHandler,this._degf_CallWbTipDestory,t)}CloseWbTip(){
UIShowMgr.inst.CloseById(d.I.WorldBossRulePanel)}ShowWbTipHandler(t){return null==this.wbRuleTip&&(this.wbRuleTip=new WorldBossRuleTipView,this.wbRuleTip.setId(t,null,0)),
this.wbRuleTip}CallWbTipDestory(){UIResMgr.DestroyUIObj(this.wbRuleTip),this.wbRuleTip=null}OpenNbTip(){const t=new UIOpenParam
t.layerType=LayerType.Alert,UIShowMgr.inst.OpenById(d.I.NeutrolBossRulePanel,this._degf_ShowNbTipHandler,this._degf_CallNbTipDestory,t)}CloseNbTip(){
UIShowMgr.inst.CloseById(d.I.NeutrolBossRulePanel)}ShowNbTipHandler(t){return null==this.nbRuleTip&&(this.nbRuleTip=new NeutrolBossRuleTipView,this.nbRuleTip.setId(t,null,0)),
this.nbRuleTip}CallNbTipDestory(){UIResMgr.DestroyUIObj(this.nbRuleTip),this.nbRuleTip=null}OpenVbTip(){const t=new UIOpenParam
t.layerType=LayerType.Alert,UIShowMgr.inst.OpenById(d.I.VipBossRulePanel,this._degf_ShowVbTipHandler,this._degf_CallVbTipDestory,t)}CloseVbTip(){
UIShowMgr.inst.CloseById(d.I.VipBossRulePanel)}ShowVbTipHandler(t){return null==this.vbRuleTip&&(this.vbRuleTip=new VipBossRuleTipView,this.vbRuleTip.setId(t,null,0)),
this.vbRuleTip}CallVbTipDestory(){UIResMgr.DestroyUIObj(this.vbRuleTip),this.vbRuleTip=null}OpenKbTip(){const t=new UIOpenParam
t.layerType=LayerType.Alert,UIShowMgr.inst.OpenById(d.I.KarimaBossRulePanel,this._degf_ShowKbTipHandler,this._degf_CallKbTipDestory,t)}CloseKbTip(){
UIShowMgr.inst.CloseById(d.I.KarimaBossRulePanel)}ShowKbTipHandler(t){return null==this.kbRuleTip&&(this.kbRuleTip=new KarimaBossRuleTipView,this.kbRuleTip.setId(t,null,0)),
this.kbRuleTip}CallKbTipDestory(){UIResMgr.DestroyUIObj(this.kbRuleTip),this.kbRuleTip=null}OpenBossBattleTip(){const t=new UIOpenParam
t.layerType=LayerType.Tip,t.isShowMask=!0,UIShowMgr.inst.OpenById(d.I.eBuyBattleBossHintPanel,this._degf_OnTipLoaded,this._degf_CallDestoryTip,t)}CloseBBossTip(){
UIShowMgr.inst.CloseById(d.I.eBuyBattleBossHintPanel)}OnTipLoaded(t){return null==this.bossBattleTip&&(this.bossBattleTip=new BuyBossBattleTipView,
this.bossBattleTip.setId(t,null,0)),this.bossBattleTip}CallDestoryTip(){null!=this.bossBattleTip&&(UIResMgr.DestroyUIObj(this.bossBattleTip),this.bossBattleTip=null)}
OnConfirmBuy(){const t=new CM_BuyBossTired
t.tiredType=1,t.times=1,SocketManager.Inst.F_SendMsg(t)}RetrieveTiredValue(t){const e=C.D.getInstance().getContent("BOSSINFO:BOSS_TIRED_ITEM").getContent().GetIntArray()
t==D.l.WORLDBOSS?S.B.GetInst().RetrieveValueByItemNew(e[w.K.WORLDBOSS-1],t):t==D.l.ANCIENTBOSS?S.B.GetInst().UseRetrieveValueItemNew(e[w.K.ANCIENTBOSS-1],t):t==D.l.CROSSBOSS&&S.B.GetInst().UseRetrieveValueItemNew(e[w.K.CROSSBOSS-1],t)
}BossIsAlive(t){if(null!=t&&null!=t.info){if(t.info.refreshTime.ToNum()-h.D.serverMSTime_get()<=0)this.GotoBoss(t)
else if(t.type==D.l.WORLDBOSS){const e=o.a.getInst().getObjById(t.monsterId).name+(0,n.T)("复活中，无法进入")
y.y.inst.ClientStrMsg(T.r.SystemTipMessage,e)}else{const e="BOSS:DIE_TIPS"
if(A.V.Inst_get().GetData(A.V.Inst_get().GetRolePrefix()+e))this.GotoBoss(t)
else{const s=o.a.getInst().getObjById(t.monsterId),i=`${s.name}（${I.M.IntToString(s.level)+(0,n.T)("级）")}`,l=(g.L.Inst().getItemById(e),new m.B)
l.infoId=e,l.replaceParams.Add(i),l.cancelText=(0,n.T)("仍旧前往"),l.cancelHandle=this._degf_GotoBoss,l.cancelParam=t,l.confirmText=(0,n.T)("取消"),l.cancelDontClose=!0,
_.t.Inst().Open(l)}}}}CheckBossLevel(t){const e=t
if(null!=e){const t=o.a.getInst().getObjById(e.monsterId)
let s=null
if(e.hadEnter&&(s=B._.Inst().GetBossByLevel(e.type)),null!=s){const i=o.a.getInst().getObjById(s.monsterId)
if(null!=i)if(t.level>=i.level)this.CheckPosUnlock(e)
else{const t="BOSS:BETTER_ADVISE"
if(A.V.Inst_get().GetData(A.V.Inst_get().GetRolePrefix()+t))this.CheckPosUnlock(e)
else{const l=`${i.name}（${I.M.IntToString(i.level)+(0,n.T)("级）")}`,o=(g.L.Inst().getItemById(t),new m.B)
o.infoId=t,o.replaceParams.Add(l),o.cancelText=(0,n.T)("坚持前往"),o.cancelHandle=this._degf_CheckPosUnlock,o.cancelParam=e,o.confirmHandle=this._degf_ShowTipHigherBoss,
o.confirmParam=s,o.cancelDontClose=!0,_.t.Inst().Open(o)}}}else this.CheckPosUnlock(e)}}CheckPosUnlock(t){const e=t,s="BOSS:DEFENSE_LACK"
if(A.V.Inst_get().GetData(A.V.Inst_get().GetRolePrefix()+s))this.BossIsAlive(e)
else{const t=b.i.Inst().getItemById(e.monsterId).defenseRec
if(a.Y.Inst.PrimaryRoleInfo_get().getAttribute(p.Z.Defense)<t){const o=(0,l.tw)(t),a=new m.B
a.cancelText=(0,n.T)("坚持前往"),a.cancelHandle=(0,i.v)(this.BossIsAlive,this),a.cancelParam=e,a.confirmText=(0,n.T)("确定"),a.infoId=s,a.replaceParams.Add(o),a.cancelDontClose=!0,
_.t.Inst().Open(a)}else this.BossIsAlive(e)}}ShowTipHigherBoss(t){const e=t
r.i.Inst.RaiseEvent(u.g.SELECT_BOSS_EFFECT,e.sortId)}GotoBoss(t){_.t.Inst().Close()
const e=t,s=M.C.Inst().GetItemByMonsterId(e.monsterId).copyid_get()
e.type==D.l.WORLDBOSS&&s>0?f.p.inst.SendEnterCopy(s,!1,B._.Inst().worldBossMultipleBossLevel):f.p.inst.IsInCopy()?y.y.inst.ClientStrMsg(T.r.SystemTipMessage,"正在副本中"):O.$.Inst().Transport(e.sortId,e)
}OpenChapter(t){O.$.Inst().Close()}CheckBossLayer(t){const e=t
if(null!=e){const t=M.C.Inst().getItemById(e.sortId).mapId_get(),s=B._.Inst().GetMaxLayer()
if(0!=s&&t!=s){const t="BOSS:BETTER_ADVISE_2"
if(A.V.Inst_get().GetData(A.V.Inst_get().GetRolePrefix()+t))this.CheckPosUnlock(e)
else{const i=v.p.Inst_get().GetMapById(s).name,l=(g.L.Inst().getItemById(t),new m.B)
l.infoId=t,l.replaceParams.Add(i),l.cancelText=(0,n.T)("仍旧前往"),l.cancelHandle=this._degf_GotoBoss,l.cancelParam=e,l.confirmHandle=this._degf_ShowTipHigherLayer,l.confirmParam=s,
_.t.Inst().Open(l)}}else this.CheckPosUnlock(e)}}ShowTipHigherLayer(t){const e=c.GF.INT(t)
r.i.Inst.RaiseEvent(u.g.SELECT_ABLAYER_EFFECT,e)}}R.inst=null},33065:(t,e,s)=>{s.d(e,{x:()=>gt})
var i=s(38836),n=s(98800),l=s(42292),o=s(71409),a=s(97461),r=s(2689),h=s(13687),d=s(38935),c=s(41664),I=s(56937),u=s(31222),p=s(5494),_=s(52726),g=s(995),m=s(98789),S=s(94148),f=s(85430),C=s(30627),T=s(92679),y=s(29839),A=s(92473),v=s(73865),D=s(92415),w=s(12723),B=s(3213),M=s(18998),b=s(75507),O=s(32076),R=s(22107),L=s(84229),G=s(96964),P=s(96713),E=s(73581),k=s(69429),N=s(9478),V=s(21334),x=s(20193),F=s(99294),U=s(67330),H=s(3522),j=s(61911)
class W extends j.f{constructor(){super(),this.finsheffect=null,this.pareff1=null,this.pareff2=null,this.finshtxteff=null,this.effectLayer=null,this._degf_AnimEnd=null,
this._degf_AnimEnd=()=>this.AnimEnd()}InitView(){super.InitView(),this.finsheffect=new H.k,this.finsheffect.setId(this.FatherId,this.FatherComponentID,1),this.pareff1=new F.z,
this.pareff1.setId(this.FatherId,this.FatherComponentID,3),this.pareff2=new F.z,this.pareff2.setId(this.FatherId,this.FatherComponentID,4),this.finshtxteff=new H.k,
this.finshtxteff.setId(this.FatherId,this.FatherComponentID,5),this.effectLayer=new U.b(this.node)}playEffect(){this.finsheffect.SetResetOnPlay(!0),this.finsheffect.Play(!0,!1),
this.finsheffect.AddEventHandler(this._degf_AnimEnd),this.pareff1.SetActive(!1),this.pareff2.SetActive(!1),this.pareff1.SetActive(!0),this.pareff2.SetActive(!0),
this.finshtxteff.SetResetOnPlay(!0),this.finshtxteff.Play(!0,!1)}OnAddToScene(){this.playEffect()}AnimEnd(){this.finsheffect.RemoveEventHandler(this._degf_AnimEnd),
this.effectLayer.UpdateRenders(),gt.Inst_get().CloseFinshEffectView()}Clear(){this.removeLis()}addLis(){}removeLis(){}ClearData(){this.Clear()}Destroy(){this.finsheffect.Destroy(),
this.finsheffect=null,this.finshtxteff.Destroy(),this.finshtxteff=null,this.effectLayer=null}}
var Y=s(81110),q=s(17279),z=s(17409),Z=s(57121),X=s(18202),Q=s(87717),J=s(5924),$=s(85602),K=s(79534),tt=s(16812),et=s(32759),st=s(30849)
class it extends st.C{constructor(){super(),this.flyEff=null,this.tween=null,this.boom=null,this.startVec=null,this.endVec=null,this._degf_OnIconFlyFinished=null,
this.notifier=null,this.startVec=K.P.zero_get(),this.endVec=K.P.zero_get(),this._degf_OnIconFlyFinished=()=>this.OnIconFlyFinished()}InitView(){super.InitView(),
this.flyEff=new F.z,this.flyEff.setId(this.FatherId,this.FatherComponentID,1),this.tween=new et.c,this.tween.setId(this.FatherId,this.FatherComponentID,2),this.boom=new F.z,
this.boom.setId(this.FatherId,this.FatherComponentID,3),this.notifier=new tt.k}Clear(){this.m_Destroyed||this.tween.RemoveEventHandler(this._degf_OnIconFlyFinished)}Destroy(){
this.Clear(),this.flyEff=null,this.tween=null,this.boom=null}Play(t,e){this.startVec=t.Clone(),this.endVec=e.Clone(),this.boom.SetActive(!1),this.flyEff.SetActive(!0),
this.tween.AddEventHandler(this._degf_OnIconFlyFinished),this.tween.SetFrom(t),this.tween.SetTo(e),this.tween.durationSet(1.5),this.tween.SetEnabled(!0),
this.tween.ResetToBeginning(),this.tween.PlayForward()}OnIconFlyFinished(){this.tween.RemoveEventHandler(this._degf_OnIconFlyFinished),
this.notifier.RaiseEvent(T.g.FLY_EFFECT_TWEEN_END,this),this.flyEff.SetActive(!1),this.boom.transform.SetLocalPosition(this.endVec),this.boom.SetActive(!1)}}class nt extends j.f{
constructor(){super(),this.effectContainer=null,this.needPickDic=null,this.flyItems=null,this.intervalId=-1,this._degf_AutoClose=null,this.flyItems=new $.Z,
this._degf_AutoClose=()=>this.AutoClose()}InitView(){super.InitView(),this.effectContainer=new F.z,this.effectContainer.setId(this.FatherId,this.FatherComponentID,1)}
OnAddToScene(){super.OnAddToScene()
const t=x.D.Inst_get().dropVecList
let e=0
for(;e<t.Count();){const s=this.GetEffectItem()
this.flyItems.Add(s),s.node.transform.SetParent(this.effectContainer.transform.FatherId,this.effectContainer.transform.ComponentId),s.node.transform.ResetTransform()
const i=t[e],n=K.P.zero_get()
s.Play(i,n),e+=1}this.intervalId=J.C.Inst_get().SetInterval(this._degf_AutoClose,2500,1)}GetEffectItem(){const t=X.g.GetResFindId("ui_treasure_worldboss_flyitem_ry"),e=new it
return e.setId(t,null,0),e}AutoClose(){gt.Inst_get().CloseGoblinFlyEffectView()}Clear(){super.Clear(),J.C.Inst_get().ClearInterval(this.intervalId),this.intervalId=-1}Destroy(){
super.Destroy()
for(const[t,e]of(0,i.V5)(this.flyItems))e.Destroy()
this.flyItems.Clear()}}class lt extends j.f{constructor(){super(),this.effectContainer=null,this.needPickDic=null,this.flyItems=null,this.intervalId=-1,this._degf_AutoClose=null,
this.flyItems=new $.Z,this._degf_AutoClose=()=>this.AutoClose()}InitView(){super.InitView(),this.effectContainer=new F.z,
this.effectContainer.setId(this.FatherId,this.FatherComponentID,1)}OnAddToScene(){super.OnAddToScene()
const t=x.D.Inst_get().dropVecList
let e=0
for(;e<t.Count();){const s=this.GetEffectItem()
this.flyItems.Add(s),s.node.transform.SetParent(this.effectContainer.transform.FatherId,this.effectContainer.transform.ComponentId),s.node.transform.ResetTransform()
const i=this.effectContainer.transform.InverseTransformPoint(t[e]),n=K.P.zero_get()
s.Play(i,n),e+=1}this.intervalId=J.C.Inst_get().SetInterval(this._degf_AutoClose,2500,1)}GetEffectItem(){const t=X.g.GetResFindId("ui_treasure_worldboss_flyitem_ry"),e=new it
return e.setId(t,null,0),e}AutoClose(){gt.Inst_get().CloseFlyEffectView()
null!=x.D.Inst_get().rewards&&gt.Inst_get().OpenNormalSuccessView()}Clear(){super.Clear(),J.C.Inst_get().ClearInterval(this.intervalId),this.intervalId=-1}Destroy(){super.Destroy()
for(const[t,e]of(0,i.V5)(this.flyItems))X.g.DestroyUIObj(e),e.Destroy()
this.flyItems.Clear()}}var ot,at,rt,ht,dt,ct,It=s(14955),ut=s(19276),pt=s(88934)
function _t(t,e,s,i,n){var l={}
return Object.keys(i).forEach((function(t){l[t]=i[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=s.slice().reverse().reduce((function(s,i){return i(t,e,s)||s}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let gt=(ot=(0,o.GH)(D.k.SM_AssistStatus),at=(0,o.GH)(D.k.SM_BossTeamsDamageList),rt=(0,
o.GH)(D.k.SM_WorldBossSettlement),ht=(0,o.GH)(D.k.SM_BossEncourage),ct=class t{constructor(){this.bModel=null,this.memberDmgView=null,this.normalSuccessView=null,
this.flyEffectView=null,this.goblinflyEffectView=null,this.assistDamageView=null,this.assistSuccView=null,this.isForAsuramTask=!1,this._degf_CallDestoryFlyEffectView=null,
this._degf_CallDestoryMemberDmgView=null,this._degf_CallDestoryNormalSuccessView=null,this._degf_OnFlyEffectViewLoaded=null,this._degf_OnMemberDmgViewLoaded=null,
this._degf_OnNormalSuccessViewLoaded=null,this._degf_SM_AssistStatusHandler=null,this._degf_SM_BeginPickUpDropHandle=null,this._degf_SM_BossTeamsDamageListHandle=null,
this._degf_SM_WorldBossSettlementHandle=null,this._degf_ShowAssistHandler=null,this._degf_DestroyAssistPanel=null,this._degf_OnAssistSuccessViewLoaded=null,
this._degf_CallDestoryAssistSuccessView=null,this._degf_FinshEffectCallDestory=null,this._degf_FinshEffectComplete=null,this._degf_OnGoblinFlyEffectViewLoaded=null,
this._degf_CallDestoryGoblinFlyEffectView=null,this.bShowBossList=null,this.finsheffectview=null,this.rolandSaveMemberDamageView=null,this.testmsg=null,
this._degf_CallDestoryFlyEffectView=()=>this.CallDestoryFlyEffectView(),this._degf_CallDestoryMemberDmgView=()=>this.CallDestoryMemberDmgView(),
this._degf_CallDestoryNormalSuccessView=()=>this.CallDestoryNormalSuccessView(),this._degf_OnFlyEffectViewLoaded=t=>this.OnFlyEffectViewLoaded(t),
this._degf_OnMemberDmgViewLoaded=t=>this.OnMemberDmgViewLoaded(t),this._degf_OnNormalSuccessViewLoaded=t=>this.OnNormalSuccessViewLoaded(),
this._degf_SM_AssistStatusHandler=t=>this.SM_AssistStatusHandler(t),this._degf_SM_BeginPickUpDropHandle=t=>this.SM_BeginPickUpDropHandle(t),
this._degf_SM_BossTeamsDamageListHandle=t=>this.SM_BossTeamsDamageListHandle(t),this._degf_SM_WorldBossSettlementHandle=t=>this.SM_WorldBossSettlementHandle(t),
this._degf_ShowAssistHandler=t=>this.ShowAssistDamageHandler(),this._degf_OnAssistSuccessViewLoaded=t=>this.OnAssistSuccessViewLoaded(),
this._degf_CallDestoryAssistSuccessView=()=>this.CallDestoryAssistSuccessView(),this._degf_FinshEffectCallDestory=()=>this.FinshEffectCallDestory(),
this._degf_FinshEffectComplete=t=>this.FinshEffectComplete(t),this._degf_OnGoblinFlyEffectViewLoaded=t=>this.OnGoblinFlyEffectViewLoaded(t),
this._degf_CallDestoryGoblinFlyEffectView=t=>this.CallDestoryGoblinFlyEffectView(),this.Reg(),this.bModel=x.D.Inst_get()}static Inst_get(){return null==t.inst&&(t.inst=new t),
t.inst}Reg(){}OpenMemberDmgView(t){if(h.b.Inst.GetCurMap().controllerType!=r.N.SCENE)if(this.bShowBossList=t||!1,null==this.memberDmgView){const t=new I.v
t.layerType=_.F.DefaultUI,t.positionType=m.$.eCustom,t.aniDir=g.K.Left,u.N.inst.OpenById(p.I.BossMemberDamagePanel,this._degf_OnMemberDmgViewLoaded,this._degf_CallDestoryMemberDmgView,t,(0,
O.v)(this.OnMemberDmgViewLoaded,this))}else this.memberDmgView.SetShowBossList(this.bShowBossList),this.bShowBossList&&this.bModel.ClearTeamRankData(),
this.memberDmgView.RefreshItems()}IsShowingBossList(){return this.memberDmgView.IsShowingBossList()}ResetFocusBossListView(){
this.memberDmgView&&this.memberDmgView.FocusBossListView(!1)}CloseMemberDmgView(){this.bModel.bossId=null,this.bModel.ClearTeamRankData(),
u.N.inst.CloseById(p.I.BossMemberDamagePanel)}OnMemberDmgViewLoaded(t){P.n.Inst_get().InitCommonRightView(t)
const e=P.n.inst.commonRightView
if(null==this.memberDmgView){const t=b.o.getPrefab("ui_bossassistpanel"),s=(0,M.instantiate)(t)
this.memberDmgView=s.getCNode(q.b),s.setParent(e.moveContainer),e.InitTeamTipType(0),
e.SetData(this.memberDmgView.node,null,this.memberDmgView.teamBtn,this.memberDmgView.taskBtn,this.memberDmgView.bgBtn,this.memberDmgView.teamColider,this.memberDmgView.taskColider,this.memberDmgView.taskSymbol,this.memberDmgView.teamSymbol),
this.memberDmgView.OnAddToScene(),e.AddToScene()}}CallDestoryMemberDmgView(){this.memberDmgView&&(this.memberDmgView.Clear(),this.memberDmgView.Destroy(),
P.n.inst.DestroyCommonRightView()),this.memberDmgView=null}OpenAssistDamageView(){var t=(0,z.Y)(p.I.AssistDamageRankPanel)
if(null==t){const t=new I.v
t.layerType=_.F.DefaultUI,t.aniDir=g.K.Left,(0,z.Yp)(p.I.AssistDamageRankPanel,t)}else t.RefreshItems()}CloseAssistDamage(){null!=(0,
z.Y)(p.I.AssistDamageRankPanel)&&u.N.inst.CloseById(p.I.AssistDamageRankPanel)}HideAssistDamageHeadIcon(){var t=(0,z.Y)(p.I.AssistDamageRankPanel)
t&&t.HideHeadIcon()}CheckAssistDamageOpen(){var t=(0,z.Y)(p.I.AssistDamageRankPanel)
return null!=t&&t.isShow_get()}OpenNormalSuccessView(){const t=V.p.Inst_get().GetMapById(h.b.Inst.currentMapId_get())
if(t.controllerType==r.N.WORLD_BOSS||t.controllerType==r.N.WORLD_BOSS_NEWHAND)if(null!=this.normalSuccessView&&this.normalSuccessView.isShow_get()?x.D.Inst_get().hasRush=!0:x.D.Inst_get().hasRush=!1,
null!=this.normalSuccessView&&this.normalSuccessView.isShow_get())this.normalSuccessView.Clear(),this.normalSuccessView.OnAddToScene()
else{const t=new I.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!0,t.layerType=_.F.Alert,u.N.inst.OpenById(p.I.WorldBossNormalSuccessPanel,this._degf_OnNormalSuccessViewLoaded,this._degf_CallDestoryNormalSuccessView,t,(0,
O.v)(this.OnNormalSuccessViewLoaded,this))}}OnNormalSuccessViewLoaded(){if(null==this.normalSuccessView){const t=b.o.getPrefab("ui_treasure_worldboss_normalsuccessview"),e=(0,
M.instantiate)(t)
this.normalSuccessView=e.getCNode(It.z)}}CallDestoryNormalSuccessView(){null!=this.normalSuccessView&&(X.g.DestroyUIObj(this.normalSuccessView),this.normalSuccessView=null)}
CloseNormalSuccessView(){u.N.inst.CloseById(p.I.WorldBossNormalSuccessPanel)}OpenAssistSuccessView(){P.n.inst.CloseConflictView(),P.n.inst.CloseCopyInspireView()
const t=new I.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!0,u.N.inst.OpenById(p.I.WorldBossAssistSuccessPanel,this._degf_OnAssistSuccessViewLoaded,this._degf_CallDestoryAssistSuccessView,t,(0,
O.v)(this.OnAssistSuccessViewLoaded,this))}OnAssistSuccessViewLoaded(){if(null==this.assistSuccView){const t=b.o.getPrefab("ui_bossassist_successpanel"),e=(0,M.instantiate)(t)
this.assistSuccView=e.getCNode(Y.m)}}CallDestoryAssistSuccessView(){null!=this.assistSuccView&&(X.g.DestroyUIObj(this.assistSuccView),this.assistSuccView=null)}
CloseAssistSuccessView(){u.N.inst.CloseById(p.I.WorldBossAssistSuccessPanel)}OpenFinshEffectView(){this.CloseFinshEffectView()
const t=new I.v
t.layerType=_.F.Tip,u.N.inst.OpenById(p.I.AssistFinshEffect,this._degf_FinshEffectComplete,this._degf_FinshEffectCallDestory,t)}FinshEffectComplete(t){
return null==this.finsheffectview&&(this.finsheffectview=new W,this.finsheffectview.setId(t,null,0)),this.finsheffectview}FinshEffectCallDestory(){
X.g.DestroyUIObj(this.finsheffectview),this.finsheffectview=null}CloseFinshEffectView(){
null!=this.finsheffectview&&this.finsheffectview.isShow_get()&&u.N.inst.CloseById(p.I.AssistFinshEffect)}OpenFlyEffectView(){const t=new I.v
t.layerType=_.F.Effect,u.N.inst.OpenById(p.I.WorldBossFlyEffectPanel,this._degf_OnFlyEffectViewLoaded,this._degf_CallDestoryFlyEffectView,t)}OnFlyEffectViewLoaded(t){
return null==this.flyEffectView&&(this.flyEffectView=new lt,this.flyEffectView.setId(t,null,0)),this.flyEffectView}CallDestoryFlyEffectView(){
null!=this.flyEffectView&&(X.g.DestroyUIObj(this.flyEffectView),this.flyEffectView=null)}CloseFlyEffectView(){u.N.inst.CloseById(p.I.WorldBossFlyEffectPanel)}
OpenGoblinFlyEffectView(){const t=new I.v
t.layerType=_.F.Effect,u.N.inst.OpenById(p.I.WorldBossFlyEffectPanel,this._degf_OnGoblinFlyEffectViewLoaded,this._degf_CallDestoryGoblinFlyEffectView,t)}
OnGoblinFlyEffectViewLoaded(t){return null==this.goblinflyEffectView&&(this.goblinflyEffectView=new nt,this.goblinflyEffectView.setId(t,null,0)),this.goblinflyEffectView}
CallDestoryGoblinFlyEffectView(){null!=this.goblinflyEffectView&&(X.g.DestroyUIObj(this.goblinflyEffectView),this.goblinflyEffectView=null)}CloseGoblinFlyEffectView(){
u.N.inst.CloseById(p.I.WorldBossFlyEffectPanel)}CM_BossMemberDamageReq(t){}CM_BossTeamsDamageReq(t){const e=new B.x
e.monsterId=t,d.C.Inst.F_SendMsg(e)}TestGoto(){const t=ut.C.Inst().GetIdByMonsterId(310018001)
pt.$.Inst().FindWay(t)}RefreshDamageView(){null!=this.memberDmgView&&this.memberDmgView.RefreshItems()
var t=(0,z.Y)(p.I.AssistDamageRankPanel)
null!=t&&t.RefreshItems(),null!=this.rolandSaveMemberDamageView&&this.rolandSaveMemberDamageView.RefreshItems()}SM_AssistStatusHandler(t){const e=t
if(n.Y.Inst.PrimaryRoleInfo_get().AccountIndex_get()==e.account)if(0==e.show){const t=this.bModel.assistedId,s=this.bModel.assistvo
this.bModel.assistedId=null,this.bModel.assistvo=null,a.i.Inst.RaiseEvent(T.g.BossAssistState),e.clear?(n.Y.Inst.PrimaryRole_get().StopPathing(),
this.CloseAssistDamage()):(this.bModel.assistedId=t,this.bModel.assistvo=s),this.RefreshDamageView()}else a.i.Inst.RaiseEvent(T.g.BossAssistState)
else this.bModel.AddAssistStatus(e),a.i.Inst.RaiseEvent(T.g.BossAssistState),this.RefreshDamageView()}SM_BossMemberDamageListHandle(t){}TestData(t){const e=this.testmsg
if(null!=e.records&&e.records.Count()>0){const s=e.records[0]
e.records.Clear()
let i=0
for(;i<t;)e.records.Add(s.CopyData(i)),i+=1}this.BossTeamsDamageListDeal(e)}SM_BossTeamsDamageListHandle(t){this.testmsg=t,
this.bModel.blockdamagelist||this.BossTeamsDamageListDeal(t)}BossTeamsDamageListDeal(t){if(0==h.b.Inst.currentMapId_get())return
const e=V.p.Inst_get().GetMapById(h.b.Inst.currentMapId_get())
if(e.controllerType==r.N.SCENE||e.controllerType==r.N.SPACE_MAZE)return
const s=null==this.bModel.bossId,i=t
let n=null==this.bModel.bossId||!this.bModel.bossId.Equal(i.bossId)
n=n&&this.bModel.IsBossEncourge(i.bossId),this.bModel.bossId=i.bossId,this.bModel.UpdateTeamRankData(i),s&&v.y.Inst.UpdateBtns(h.b.Inst.currentMapId_get(),!0),
n&&this.CM_BossEncourgeInfo(this.bModel.bossId),
G.o.getInstance().InKarima()?G.o.getInstance().HandleDamageListHandler():f.a.isInAllianceBossMap_get()?L.Q.Inst_get().bossModel.memberRank_set(i):S.b.Inst_get().InAsuramMap()?Q.L.Inst_get().HandleDamageListHandler():E.o.Inst_get().IsInRolandValley()?E.o.Inst_get().HandleDamageListHandler():k.v.ins.IsInRolandSaveCommon()?this.OpenRolandSaveMemberDmgView():(this.OpenMemberDmgView(),
this.OpenAssistDamageView()),A.R.Inst_get().IsInCrossBattle()&&R.N.inst_get().OpenAlertPanel(),y.p.inst.IsInCopy(),a.i.Inst.RaiseEvent(T.g.BOSS_DAMAGE_BOSSID_UPDATE)}
SM_WorldBossSettlementHandle(t){x.D.Inst_get().rewards=t
const e=V.p.Inst_get().GetMapById(h.b.Inst.currentMapId_get())
e.controllerType!=r.N.WORLD_BOSS&&e.controllerType!=r.N.WORLD_BOSS_NEWHAND||null!=this.flyEffectView&&this.flyEffectView.isShow_get()||this.OpenNormalSuccessView()}
CM_BossEncourgeInfo(t){const e=new w.q
e.objId=t,d.C.Inst.F_SendMsg(e)}SM_BossEncourageHandler(t){x.D.Inst_get().encourageTypeTimes=t.encourageTypeTimes,x.D.Inst_get().encourageMap=t.encourageMap,
x.D.Inst_get().encourageBossId=t.bossId
for(const[e,s]of(0,i.vy)(t.encourageMap))P.n.inst.ShowInspire(Number(e),t.encourageMap[e])
P.n.inst.ShowInspireTimes(t.encourageTypeTimes)
const e=v.y.Inst.GetInspireBtnView()
null!=e&&e.InitExtraLabel(),P.n.inst.PlayResultAnim(t.result),c.j.Inst.PlayByDivision("Applause")}SM_BeginPickUpDropHandle(t){Z.M.Inst.hasNeedPick_get()&&this.OpenFlyEffectView()}
CloseAfterLeave(){this.CloseNormalSuccessView(),this.CloseFlyEffectView(),this.CloseMemberDmgView(),this.CloseAssistDamage(),this.CloseRolandSaveMemberDmgView(),C.t.Inst().Close()}
OpenRolandSaveMemberDmgView(){if(null==this.rolandSaveMemberDamageView){const t=new I.v
t.layerType=_.F.DefaultUI,t.positionType=m.$.eCustom,t.aniDir=g.K.Left,u.N.inst.OpenById(p.I.RolandSaveMemberDamagePanel,this.CreateDelegate(this.OnRolandSaveMemberoaded),this.CreateDelegate(this.CallRolandSaveMemberDmgViewDestory),t)
}else this.rolandSaveMemberDamageView.RefreshItems()}CloseRolandSaveMemberDmgView(){this.bModel.bossId=null,this.bModel.ClearTeamRankData(),
u.N.inst.CloseById(p.I.RolandSaveMemberDamagePanel)}OnRolandSaveMemberoaded(t){P.n.inst.InitCommonRightView(t)
const e=P.n.inst.commonRightView
if(null==this.memberDmgView){const s=X.g.GetResFindId("ui_rolandsave_copy_bossassistpanel")
this.rolandSaveMemberDamageView=new N.t,this.rolandSaveMemberDamageView.setId(s,null,0),
this.rolandSaveMemberDamageView.node.transform.SetParent(e.moveContainer.FatherId,e.moveContainer.ComponentId),this.rolandSaveMemberDamageView.OnAddToScene(),
u.N.inst.SetChildDepth(t,s),
e.InitTeamTipType(0),e.SetData(this.rolandSaveMemberDamageView.myDamageContainer,this.rolandSaveMemberDamageView.teamContainer,this.rolandSaveMemberDamageView.teamBtn,this.rolandSaveMemberDamageView.taskBtn,this.rolandSaveMemberDamageView.bgBtn,this.rolandSaveMemberDamageView.teamColider,this.rolandSaveMemberDamageView.taskColider,this.rolandSaveMemberDamageView.taskSymbol,this.rolandSaveMemberDamageView.teamSymbol),
e.AddToScene()}return e}CallRolandSaveMemberDmgViewDestory(){null!=this.rolandSaveMemberDamageView&&(this.rolandSaveMemberDamageView.Clear(),
this.rolandSaveMemberDamageView.Destroy(),X.g.DestroyUIObj(this.rolandSaveMemberDamageView),P.n.inst.DestroyCommonRightView(),this.rolandSaveMemberDamageView=null)}},ct.inst=null,
_t(dt=ct,"Inst_get",[l.n],Object.getOwnPropertyDescriptor(dt,"Inst_get"),dt),
_t(dt.prototype,"SM_AssistStatusHandler",[ot],Object.getOwnPropertyDescriptor(dt.prototype,"SM_AssistStatusHandler"),dt.prototype),
_t(dt.prototype,"SM_BossTeamsDamageListHandle",[at],Object.getOwnPropertyDescriptor(dt.prototype,"SM_BossTeamsDamageListHandle"),dt.prototype),
_t(dt.prototype,"SM_WorldBossSettlementHandle",[rt],Object.getOwnPropertyDescriptor(dt.prototype,"SM_WorldBossSettlementHandle"),dt.prototype),
_t(dt.prototype,"SM_BossEncourageHandler",[ht],Object.getOwnPropertyDescriptor(dt.prototype,"SM_BossEncourageHandler"),dt.prototype),dt)},66837:(t,e,s)=>{s.d(e,{x:()=>I})
var i,n,l=s(42292),o=s(56937),a=s(18202),r=s(31222),h=s(5494),d=s(52726),c=s(42650)
let I=(0,l.wT)("GameSys.DamageTipControl")((n=class t{static get inst(){return t._inst||(t._inst=new t),t._inst}constructor(){this.view=null,this._degf_CallDestoryTip=null,
this._degf_OnTipLoaded=null,this._degf_CallDestoryTip=()=>this.CallDestoryTip(),this._degf_OnTipLoaded=t=>this.OnTipLoaded(t)}static Inst_get(){
return null==t._inst&&(t._inst=new t),t._inst}Open(){const t=new o.v
t.layerType=d.F.Tip,r.N.inst.OpenById(h.I.BossMemberDamageTip,this._degf_OnTipLoaded,this._degf_CallDestoryTip,t)}OnTipLoaded(t){return null==this.view&&(this.view=new c.n,
this.view.setId(t,null,0)),this.view}CallDestoryTip(){null!=this.view&&(a.g.DestroyUIObj(this.view),this.view=null)}Close(){r.N.inst.CloseById(h.I.BossMemberDamageTip)}},
n._inst=null,i=n))||i},70415:(t,e,s)=>{s.d(e,{i:()=>r})
var i=s(93984),n=s(86133),l=s(66788),o=s(55360),a=s(38962)
class r{constructor(){this.monsterAttrMap=null,this.monsterAttrMap=new a.X
const t=o.Y.Inst.GetOrCreateCsv(i.h.eMonsterAttr)
this.monsterAttrMap=t.GetCsvMap()}static Inst(){return null==r._inst&&(r._inst=new r),r._inst}getItemById(t){
return this.monsterAttrMap.LuaDic_ContainsKey(t)?this.monsterAttrMap[t]:(l.Y.LogError((0,n.T)("monsterattrbutereource表id:")+(t+(0,n.T)("找不到！"))),null)}}r._inst=null},
88934:(t,e,s)=>{s.d(e,{$:()=>ss})
var i=s(35803),n=s(71453),l=s(18753),o=s(18998),a=s(75507),r=s(42292),h=s(71409),d=s(17409),c=s(77546),I=s(32076),u=s(38836),p=s(86133),_=s(98800),g=s(97461),m=s(30621),S=s(38935),f=s(56937),C=s(31222),T=s(5494),y=s(52726),A=s(85602),v=s(79534),D=s(21554),w=s(92679),B=s(33314),M=s(74045),b=s(49067),O=s(87923),R=s(37648),L=s(55492),G=s(92415),P=s(57411),E=s(47149),k=s(5334),N=s(68277),V=s(65550),x=s(47041),F=s(31931),U=s(21334),H=s(96098),j=s(91238),W=s(36241),Y=s(19176),q=s(2689),z=s(13687),Z=s(66788),X=s(18202),Q=s(49484),J=s(98885),$=s(29839),K=s(48933),tt=s(73865),et=s(9659),st=s(55552),it=s(96713),nt=s(39043),lt=s(62783),ot=s(12970),at=s(15771),rt=s(20193),ht=s(22046),dt=s(77344),ct=s(12417),It=s(23833),ut=s(5924),pt=s(57834),_t=s(85682),gt=s(98130),mt=s(53905),St=s(65772),ft=s(41864),Ct=s(5968),Tt=s(19276),yt=s(26223),At=s(84473),vt=s(99294),Dt=s(9986),wt=s(9057),Bt=s(37009),Mt=s(93877),bt=s(72005),Ot=s(88653),Rt=s(37151)
class Lt extends wt.x{constructor(){super(),this.lockSp=null,this.levelLb=null,this.mapNameLb=null,this.selectItem=null,this.btn=null,this.tipEff=null,this.mapName="",
this.levelStr="",this._mapId=0,this.isLocked=!1,this.mapRes=null,this._tModel=null,this._degf_OnItemClick=null,this._degf_OnLayerSelectEff=null,this._degf_OnLayerSelected=null,
this.lbl1=null,this.lbl2=null,this.mark2=null,this.mark1=null,this.lbl3=null,this._degf_OnItemClick=(t,e)=>this.OnItemClick(t,e),
this._degf_OnLayerSelectEff=t=>this.OnLayerSelectEff(t),this._degf_OnLayerSelected=t=>this.OnLayerSelected(t)}mapId_get(){return this._mapId}mapId_set(t){this._mapId=t}InitView(){
this.lockSp=new vt.z,this.lockSp.setId(this.FatherId,this.FatherComponentID,1),this.levelLb=new Mt.Q,this.levelLb.setId(this.FatherId,this.FatherComponentID,2),
this.mapNameLb=new Mt.Q,this.mapNameLb.setId(this.FatherId,this.FatherComponentID,3),this.selectItem=new Bt.l,this.selectItem.setId(this.FatherId,this.FatherComponentID,4),
this.btn=new Dt.W,this.btn.setId(this.FatherId,this.FatherComponentID,5),this.tipEff=new vt.z,this.tipEff.setId(this.FatherId,this.FatherComponentID,6),this.lbl1=new Mt.Q,
this.lbl1.setId(this.FatherId,this.FatherComponentID,7),this.lbl2=new Mt.Q,this.lbl2.setId(this.FatherId,this.FatherComponentID,8),this.mark2=new bt.w,
this.mark2.setId(this.FatherId,this.FatherComponentID,9),this.mark1=new bt.w,this.mark1.setId(this.FatherId,this.FatherComponentID,10),this.lbl3=new Mt.Q,
this.lbl3.setId(this.FatherId,this.FatherComponentID,11),this._tModel=ct._.Inst()}SetData(t){if(this.AddLis(),this.mapId_set(gt.GF.INT(t)),
this.mapRes=U.p.Inst_get().GetMapById(this.mapId_get()),null!=this.mapRes){const t=this.mapRes.minLevelLimit
let e=0
const s=this._tModel.GetAbMapLayers()
let i=0
for(;i<s.Count()-1;){if(s[i]==this.mapId_get()){const t=s[i+1],n=U.p.Inst_get().GetMapById(t)
null!=n&&(e=n.minLevelLimit)
break}i+=1}this.mapName=this.mapRes.name,this.levelStr=`Lv.${J.M.IntToString(t)}-${J.M.IntToString(e-1)}`
const n=Rt.Q.model.GetMasterStartLevel(),l=t,o=e-1
let a=0
this.lbl1.node.SetActive(!0),l>n?(this.lbl2.textSet(`    ${l-n}-`),a=1,this.mark1.node.SetActive(!0)):(this.lbl2.textSet(`${l}-`),this.mark1.node.SetActive(!1)),
this.lbl2.UpdateAnchors(),this.mark1.UpdateAnchors(),o>n?(a=1,this.lbl3.textSet("    "+(o-n)),this.mark2.node.SetActive(!0)):(this.lbl3.textSet(`${o}`),
this.mark2.node.SetActive(!1)),this.lbl3.UpdateAnchors(),this.mark2.UpdateAnchors()
const r=new v.P
0==a?(r.Set(-37,-9,0),this.lbl1.node.transform.SetLocalPosition(r)):(r.Set(-52,-9,0),this.lbl1.node.transform.SetLocalPosition(r)),v.P.Recyle(r),
this.isLocked=ot.F.getInst().GetCanEnterMapByLvAndTransfer(this.mapId_get())!=F.f.CAN,this.lockSp.SetActive(this.isLocked),this.UpdateStateObj(0),
this.isLocked&&(this.levelStr=this.GetLimitTrans()+(0,p.T)("解锁"),this.levelLb.node.SetActive(!0),this.lbl1.node.SetActive(!1),this.UpdateStateObj(2)),
this.mapId_get()==Tt.C.Inst().getItemById(this._tModel.curAbSortId).mapId_get()&&(this.UpdateStateObj(1),this.levelLb.node.SetActive(!1),this.lbl1.node.SetActive(!0)),
this.tipEff.SetActive(!1)}}AddLis(){pt.i.Get(this.btn.node).RegistonClick(this._degf_OnItemClick),g.i.Inst.AddEventHandler(w.g.ABossLayerSelected,this._degf_OnLayerSelected),
g.i.Inst.AddEventHandler(w.g.SELECT_ABLAYER_EFFECT,this._degf_OnLayerSelectEff)}RemoveLis(){pt.i.Get(this.btn.node).RemoveonClick(this._degf_OnItemClick),
g.i.Inst.RemoveEventHandler(w.g.ABossLayerSelected,this._degf_OnLayerSelected),g.i.Inst.RemoveEventHandler(w.g.SELECT_ABLAYER_EFFECT,this._degf_OnLayerSelectEff)}OnItemClick(t,e){
if(this.tipEff.SetActive(!1),this.isLocked){const t=new A.Z([this.GetLimitTrans(),this.mapRes.name])
V.y.inst.ClientSysMessage(111014,t)}else this.selectItem.OnSelect(),g.i.Inst.RaiseEvent(w.g.ABossLayerSelected,this.mapId_get())}OnLayerSelected(t){
gt.GF.INT(t)==this.mapId_get()?this.UpdateStateObj(1):(this.UpdateStateObj(0),this.isLocked=ot.F.getInst().GetCanEnterMapByLvAndTransfer(this.mapId_get())!=F.f.CAN,
this.isLocked&&this.UpdateStateObj(2))}Clear(){this.RemoveLis()}UpdateStateObj(t){let e=""
0==t?(this.btn.SetState(At.D.eNormal,!0),this.btn.SetIsEnabled(!0),e="[ceccc5]"):1==t?(this.btn.SetState(At.D.eDisabled,!0),this.btn.SetIsEnabled(!1),
e="[f4e2b3]"):2==t&&(e="[8e8279]"),this.mapNameLb.textSet(`${e}${this.mapName}[-]`),this.levelLb.textSet(`${e}${this.levelStr}[-]`),this.SetLbl1Color(t)}SetLbl1Color(t){
let e="",s=null
0==t?(e="[ceccc5]",s=Lt.Color0):1==t?(e="[f4e2b3]",s=Lt.Color1):2==t&&(e="[8e8279]",s=Lt.Color2),this.lbl1.SetColor(s),this.lbl2.SetColor(s),this.lbl3.SetColor(s)}
OnLayerSelectEff(t){gt.GF.INT(t)==this.mapId_get()?this.tipEff.SetActive(!0):this.tipEff.SetActive(!1)}GetLimitTrans(){let t=""
return null!=this.mapRes&&0!=this.mapRes.transferJobLimitLevel&&(t=B.Z.GetJobNameByTransfor(this.mapRes.transferJobLimitLevel)),t}}Lt.Color0=new Ot.I(206/255,.8,197/255,1),
Lt.Color1=new Ot.I(244/255,226/255,179/255,1),Lt.Color2=new Ot.I(142/255,130/255,121/255,1)
s(22267)
var Gt=s(83908),Pt=s(32697),Et=s(20583),kt=s(31546),Nt=s(50089),Vt=s(68662),xt=s(82737),Ft=s(60130),Ut=s(35128),Ht=s(75439),jt=s(38501),Wt=s(82039),Yt=s(31896),qt=s(14792),zt=s(62734),Zt=s(60647),Xt=s(13487),Qt=s(75517),Jt=s(61911),$t=s(24087),Kt=s(86258)
class te extends((0,Gt.zB)()){constructor(...t){super(...t),this.clickHandler=null,this.cfg=null,this.enabledshow=!0}InitView(){super.InitView(),this.select.SetActive(!1),
this.lockLabel.node.SetActive(!1)}SetData(t){this.cfg=t
const e=at.U.inst.model.level_get()
if(this.enabledshow=e>=t.level,this.nameLabel.textSet(`${O.l.GetChineseNum(t.multipleBoss)}倍挑战`),e<t.level){this.lockLabel.node.SetActive(!0),
this.lockLabel.textSet(`V${t.level}开启`)
const e=new Ot.I(.588,.5607,.529)
this.nameLabel.SetColor(e),this.lockLabel.SetColor(e)}this.m_handlerMgr.AddClickEvent(this.node,this.CreateDelegate(this.OnClickItem)),
this.SetSelect(ct._.Inst().worldBossMultipleBossLevel==t.multipleBoss)}OnClickItem(){this.enabledshow&&(this.SetSelect(!0),null!=this.clickHandler&&this.clickHandler(this.cfg))}
SetSelect(t){t?(null!=te._selectItem&&te._selectItem.SetSelect(!1),te._selectItem=this,this.select.SetActive(!0)):this.select.SetActive(!1)}Clear(){super.Clear()}Destroy(){
null!=te._selectItem&&te._selectItem.SetSelect(!1),te._selectItem=null,this.clickHandler=null,super.Destroy()}Test1(){return!0}S_Test(){return!0}}te._selectItem=null
class ee extends((0,Gt.pA)(Jt.f)()){constructor(...t){super(...t),this.tModel=null,this.rInfo=null,this.dragAmount=0,this.sortId=0,this.cfg=null,this.objRes=null,
this.intervalId2=-1,this.scrollIntervalId=-1,this.timer=-1,this.copyId=0,this.boss=null,this.rotateIndex=-1,this.lastIndex=0,this._degf_OnAddClick=null,
this._degf_OnAttentionClick=null,this._degf_OnExtraRewardClick=null,this._degf_OnItemRefreshFun=null,this._degf_OnRewardRefreshFun=null,this._degf_OnSearchClick=null,
this._degf_OnTipClick=null,this._degf_OnUpdateTiredInfo=null,this._degf_OnUpdateAttentionInfo=null,this._degf_RecoverTimeCount=null,this._degf_handle=null,
this._degf_ResetDropScrollView=null,this._degf_OnRareDropClick=null,this._degf_OnDragFinished=null,this._degf_DragingMoving=null,this._degf_OnShowSelectTimesClick=null,
this._degf_OnHideSelectTimeClick=null,this.displayUIAvatarModel=null,this.tempTimes=null,this.initPosX=null,this.initPosXOpen=null,this.initScrollWidth=null,
this.showItemWidth=null,this.itemWidth=null,this.registerUIScId=null,this.registerUIId=null,this.bossRage=null,this.lastMonId=null,this.stage=null,this.isDragClick=!1,
this.isDragClick2=!1}_initBinder(){super._initBinder(),this._degf_OnAddClick=(t,e)=>this.OnAddClick(t,e),this._degf_OnAttentionClick=(t,e)=>this.OnAttentionClick(),
this._degf_OnExtraRewardClick=(t,e)=>this.OnExtraRewardClick(t,e),this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),
this._degf_OnRewardRefreshFun=t=>this.OnRewardRefreshFun(t),this._degf_OnSearchClick=(t,e)=>this.OnSearchClick(t,e),this._degf_OnTipClick=(t,e)=>this.OnTipClick(t,e),
this._degf_OnUpdateTiredInfo=t=>this.OnUpdateTiredInfo(t),this._degf_OnUpdateAttentionInfo=t=>this.OnUpdateAttentionInfo(t),this._degf_RecoverTimeCount=()=>this.RecoverTimeCount(),
this._degf_handle=()=>this.handle(),this._degf_ResetDropScrollView=()=>this.ResetDropScrollView(),this._degf_OnRareDropClick=(t,e)=>this.OnRareDropClick(t,e),
this._degf_OnDragFinished=()=>this.OnDragFinished(),this._degf_DragingMoving=()=>this.OnDragingMoving(),this._degf_OnShowSelectTimesClick=()=>{this.OnShowSelectClick()},
this._degf_OnHideSelectTimeClick=()=>{this.OnHideSelectClick()}}InitView(){super.InitView(),this.ancientBossEffect.node.active=!1,this.gridContainer.SetActive(!1),
this.dropGrid.SetInitInfo("ui_treasure_bossdropitem_big",this._degf_OnRewardRefreshFun,$t.j),this.dropGrid.OnReposition_set(this._degf_ResetDropScrollView),
this.bossTable.SetInitInfo("ui_treasure_wbossitem_ry",this._degf_OnItemRefreshFun,Kt.c,this.CreateDelegate(this.OnDragClick)),this.bossTable.OnReposition_set(this._degf_handle),
this.tModel=ct._.Inst(),this.rInfo=_.Y.Inst.PrimaryRoleInfo_get(),this.tempTimes=ct._.Inst().WorldBossTired_get(),this.initPosXOpen=this.table.node.position.x,
this.initPosX=this.initPosXOpen,this.initScrollWidth=this.bossScrollPanel.node.transform.width,this.showItemWidth=this.bossBg.node.transform.width+34,this.itemWidth=250,
this.registerUIScId=_t.D.Boss,this.registerUIId=T.I.TreasurePanel,this.selectGrid.SetInitInfo("ui_select_dun_times_item",this.CreateDelegate(this.OnCreateItem)),
this.UpdateAnchors()}OnDragClick(){this.isDragClick=!0,this.isDragClick2=!0}UpdateAnchors(){Ft.O.SetAnchorPos(this.leftAnchor,!0,!1,0,!1),
Ft.O.SetAnchorPos(this.rightAnchor,!1,!1,0,!1)}ShowVIPTimesInfo(){let t=Zt.p.inst.GetClientLogicSetting(Xt.R.BOSS_TIMES)
0==t&&(t=1),ct._.Inst().worldBossMultipleBossLevel=t,this.timesContainer.SetActive(!0),
this.currentSelectTimesLabel.textSet(`${O.l.GetChineseNum(ct._.Inst().worldBossMultipleBossLevel)}倍挑战`)
const e=jt.f.Inst().GetMultipleBossList()
this.selectGrid.data_set(e),this.ShowCost()}OnShowSelectClick(){const t=!this.gridContainer.active
if(this.gridContainer.SetActive(t),t){if(this.arrowTips.eulerAngles=new o.Vec3(0,0,0),ct._.Inst().isShowMultipleRed){
const t=at.U.inst.model.level_get(),e=jt.f.Inst().getItemById(t)
Yt.t.inst.CM_RedPointClickHandle(qt.t.WORLD_BOSS_MULTIPLE+e.multipleBoss,!0),ct._.Inst().isShowMultipleRed=!1,zt.f.Inst.SetState(qt.t.WORLD_BOSS_MULTIPLE,!1),
this.multipleRedPoint.SetActive(!1)}}else this.arrowTips.eulerAngles=new o.Vec3(0,0,180)}OnHideSelectClick(){this.OnShowSelectClick()}OnCreateItem(t){const e=t[0].getCNode(te)
return e.clickHandler=this.CreateDelegate(this.OnSelectTimesItem),e}ShowCost(){this.bosstiredconsume.textSet((this.bossRage*ct._.Inst().worldBossMultipleBossLevel).toString()),
1==ct._.Inst().worldBossMultipleBossLevel?(this.gotoLabel.textSet("挑战(        )"),
this.costContainer.transform.SetLocalPositionXYZ(0,0,0)):(this.gotoLabel.textSet(`${O.l.GetChineseNum(ct._.Inst().worldBossMultipleBossLevel)}倍挑战(        )`),
this.costContainer.transform.SetLocalPositionXYZ(22,0,0))
const t=this.bosstiredconsume.node.transform.GetLocalPosition(),e=this.tiredSp2.node.transform.GetLocalPosition()
e.x=this.bosstiredconsume.width()+t.x+10,this.tiredSp2.node.transform.SetLocalPosition(e)}OnSelectTimesItem(t){Zt.p.inst.SendClientLogicSetting(Xt.R.BOSS_TIMES,t.multipleBoss),
this.currentSelectTimesLabel.textSet(`${O.l.GetChineseNum(t.multipleBoss)}倍挑战`),ct._.Inst().worldBossMultipleBossLevel=t.multipleBoss,this.OnShowSelectClick(),this.ShowCost()}
Clear(){this.RemoveLis(),this.bossShowItem.Clear(),ut.C.Inst_get().ClearInterval(this.intervalId2),ut.C.Inst_get().ClearInterval(this.scrollIntervalId),this.ClearRecoverTime(),
this.ClearBoss(),this.lastMonId=null,this.tModel.isOpenAddTip=!1,-1!=this.rotateIndex&&(this.rotateIndex=-1)}Destroy(){super.Destroy()}OnAddToScene(){this.stage=ee.STAGE_ID,
this.bossBg2.spriteNameSet("ryworldboss_sp_0037"),this.multipleRedPoint.SetActive(ct._.Inst().isShowMultipleRed),this.node.SetActive(!0),this.RemoveLis(),this.AddLis(),
0==ct._.Inst().hasShowAni&&(ct._.Inst().hasShowAni=!0),this.SetData(),this.tModel.isFirstInWBoss||(this.ChangeScrollPosByIndex(this.lastIndex),
this.bossScrollView.scrollTo(this.lastIndex))}AddLis(){pt.i.Get(this.attentionBtn.node).RegistonClick(this._degf_OnAttentionClick),
pt.i.Get(this.addBtn).RegistonClick(this._degf_OnAddClick),pt.i.Get(this.addBtn2).RegistonClick(this._degf_OnAddClick),
pt.i.Get(this.searchForBossBtn).RegistonClick(this._degf_OnSearchClick),pt.i.Get(this.tipBtn).RegistonClick(this._degf_OnTipClick),
pt.i.Get(this.rareDropBtn).RegistonClick(this._degf_OnRareDropClick),pt.i.Get(this.extraBtn.node).RegistonClick(this._degf_OnExtraRewardClick),
pt.i.Get(this.showSelect.node).RegistonClick(this._degf_OnShowSelectTimesClick),pt.i.Get(this.selectCollision).RegistonClick(this._degf_OnHideSelectTimeClick),
this.m_handlerMgr.AddEventMgr(w.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors)),g.i.Inst.AddEventHandler(w.g.WORLD_BOSS_TIRED_UPDATE,this._degf_OnUpdateTiredInfo),
g.i.Inst.AddEventHandler(w.g.UPDATE_ATTENTION,this._degf_OnUpdateAttentionInfo),this.bossScrollView.RegistonDragFinished(this._degf_OnDragFinished),
this.bossScrollView.RegistonDragingMoving(this._degf_DragingMoving)}RemoveLis(){pt.i.Get(this.attentionBtn.node).RemoveonClick(this._degf_OnAttentionClick),
pt.i.Get(this.addBtn).RemoveonClick(this._degf_OnAddClick),pt.i.Get(this.addBtn2).RemoveonClick(this._degf_OnAddClick),
pt.i.Get(this.searchForBossBtn).RemoveonClick(this._degf_OnSearchClick),pt.i.Get(this.tipBtn).RemoveonClick(this._degf_OnTipClick),
pt.i.Get(this.rareDropBtn).RemoveonClick(this._degf_OnRareDropClick),pt.i.Get(this.extraBtn.node).RemoveonClick(this._degf_OnExtraRewardClick),
pt.i.Get(this.showSelect.node).RemoveonClick(this._degf_OnShowSelectTimesClick),pt.i.Get(this.selectCollision).RemoveonClick(this._degf_OnHideSelectTimeClick),
g.i.Inst.RemoveEventHandler(w.g.WORLD_BOSS_TIRED_UPDATE,this._degf_OnUpdateTiredInfo),g.i.Inst.RemoveEventHandler(w.g.UPDATE_ATTENTION,this._degf_OnUpdateAttentionInfo)}
RegGuide(){}UnRegGuide(){this.sortId}CheckGuide(){O.l.CheckBtnClickTrigger(_t.D.UI_BOSS_CHANGEL_BTN,this.sortId)}CheckGuide2(){
O.l.CheckBtnClickTrigger(_t.D.UI_BOSS_ADD_V_BTN,this.sortId)}CheckGuide3(){O.l.CheckBtnClickTrigger(_t.D.UI_BOSS_FOLLOWL_BTN,this.sortId)}OnExtraRewardClick(t,e){
ss.inst.OpenRewardInfo()}OnTipClick(t,e){const s=new mt.w
s.position=new v.P(-385,320,0),s.width=450,s.infoId="BOSS：WORLDBOSS_TIPS1",St.Q.Inst_get().Open(s)}OnRewardRefreshFun(t){return t[0].getCNode($t.j)}OnItemRefreshFun(t){
return t[0].getCNode(Kt.c)}OnBossItemLoadComplete(){this.intervalId2=ut.C.Inst_get().SetInterval(this._degf_handle,300,1)}handle(){
this.tModel.isFirstInWBoss&&(this.tModel.isFirstInWBoss=!1,this.AdaptScreenSize(),this.ChangeScrollPosByIndex(this.lastIndex))}ResetDropScrollView(){
this.dropScrollView.ResetPosition()}OnRareDropClick(t,e){ss.inst.OpenDropTip()}OnAttentionClick(){this.CheckGuide3()
const t=new Wt.m
t.bossId=this.cfg.monsterId_get(),this.selectSpt.activeInHierarchy?t.type=0:t.type=1,S.C.Inst.F_SendMsg(t)}RefreshBossGrid(){const t=new A.Z,e=this.tModel.GetWbShowData()
for(const[s,i]of(0,u.V5)(e))t.Add(i)
this.dragAmount=this.tModel.GetDragAmount(t.Count(),this.tModel.wbDefaultIndex,ct._.BOSS_NUM_PER_PAGE,2),this.bossTable.data_set(t)}RefreshDropGrid(){
const t=this.tModel.GetRewardLis(this.sortId,null)
t.Count()>0?(this.dropObj.SetActive(!0),this.dropGrid.data_set(t)):this.dropObj.SetActive(!1)}SetData(){this.UnRegGuide(),this.sortId=this.tModel.curWbSortId,this.RegGuide(),
this.cfg=Tt.C.Inst().getItemById(this.sortId),this.tModel.hasBossGridRefresh||(this.RefreshBossGrid(),this.tModel.hasBossGridRefresh=!0),this.RefreshDropGrid()
const t=this.cfg.monsterId_get()
this.objRes=It.a.getInst().getObjById(t),this.copyId=this.cfg.copyid_get(),this.bossRage=this.objRes.rage
const e=this.GetCurBossData()
ct._.Inst().hadEnterBossId
e.hadEnter?e.isFighting?(this.btnContent1.SetActive(!1),this.btnContent2.SetActive(!1),this.btnContent3.SetActive(!0),
this.timesContainer.SetActive(!1)):(this.btnContent1.SetActive(!0),this.btnContent2.SetActive(!1),this.btnContent3.SetActive(!1),
this.ShowVIPTimesInfo()):(this.btnContent1.SetActive(!1),this.btnContent2.SetActive(!0),this.gotoLabel2.textSet("挑  战  ([047104]                  [-])"),
this.btnContent3.SetActive(!1),this.timesContainer.SetActive(!1),ct._.Inst().worldBossMultipleBossLevel=1),this.bossName.textSet(`${this.cfg.name_get()} Lv.${this.objRes.level}`),
this.playerName.textSet(this.tModel.GetLastKillInfo(t)),this.attentionContainer.SetActive(this.tModel.canAttentionLis.IndexOf(t,0)>=0),
this.selectSpt.SetActive(this.tModel.attentionLis.IndexOf(t,0)>=0),this.SetTiredStr(),this.UpdateTimeCountInfo(),this.InitBossView(this.cfg)}SearchForBoss(){
const t=this.GetCurBossData()
if(t.hadEnter&&!t.isFighting){if(ct._.Inst().WorldBossTired_get()<this.bossRage*ct._.Inst().worldBossMultipleBossLevel)return void this.OnAddClick()}
this.cfg.copyid_get()>0?this.tModel.BossLimitHandle(this.cfg.copyid_get(),null)||this.CheckBossAlive():this.tModel.NormalMapLimitHandle(this.cfg.mapId_get())||this.CheckBossAlive()
}GetCurBossData(){const t=this.tModel.GetWbShowData()
let e=0
for(;e<t.Count();){if(t[e].sortId==this.tModel.curWbSortId)return t[e]
e+=1}return null}Handle(t){ss.Inst().Transport(this.tModel.curWbSortId,null)}OnAddClick(t,e){this.CheckGuide2(),this.tModel.isOpenAddTip=!0,
yt.x.Inst_get().RetrieveTiredValue(this.cfg.type_get())}GetRecoverCount(){const t=Ht.D.getInstance().getContent("BOSSTIRED:RECOVER_VALUE").getContent().GetIntArray()
let e=null
return e=this.cfg.type_get()==ht.l.WORLDBOSS?t[dt.K.WORLDBOSS-1]:t[dt.K.ANCIENTBOSS-1],e}UpdateTimeCountInfo(){let t
t=this.cfg.type_get()==ht.l.WORLDBOSS?ct._.Inst().bossTiredRevoverDelayTime:ct._.Inst().ancientBossTiredRevoverDelayTime,t<0?(this.tiredTable.node.SetActive(!1),
this.addBtn2.SetActive(!0),this.ClearRecoverTime()):-1==this.timer&&(this.timer=ut.C.Inst_get().SetInterval(this._degf_RecoverTimeCount,1e3),this.RecoverTimeCount())}
RecoverTimeCount(){let t
t=this.cfg.type_get()==ht.l.WORLDBOSS?ct._.Inst().bossTiredRevoverDelayTime:ct._.Inst().ancientBossTiredRevoverDelayTime
const e=t-Vt.D.serverTime_get()
if(gt.GF.INT(e)+5>0){this.tiredTable.node.SetActive(!0),this.addBtn2.SetActive(!1)
const t=this.GetRecoverCount()
gt.GF.INT(e)<0?this.recoverCountTime.textSet(`[047104]0秒[-][4B3C2F]后恢复[-][D1D1D1]${t}[-]`):this.recoverCountTime.textSet(`[047104]${O.l.GetDateFormat(e)}[-][4B3C2F]后恢复[-][D1D1D1]${t}[-]`),
this.tiredTable.Reposition()}else this.ClearRecoverTime(),this.tiredTable.node.SetActive(!1),this.addBtn2.SetActive(!0),this.recoverCountTime2.textSet("[4B3C2F]体力    已满[-]")}
SetTiredStr(){const t=at.U.inst.model.GetPanelResVO(at.U.inst.model.level_get()).GetSpecialBossPower(this.cfg.type_get())
let e=null,s=null,i=null
this.cfg.type_get()==ht.l.WORLDBOSS?(this.effectball.SetActive(!0),this.effectball2.SetActive(!1),s=this.ballBottomEff,i=this.ballLineEff,
e=ct._.Inst().WorldBossTired_get()):(this.effectball.SetActive(!1),this.effectball2.SetActive(!0),s=this.ballBottomEff2,i=this.ballLineEff2,e=ct._.Inst().AncientBossTired_get())
const n=`${e}/${t}`
if(this.battleNum.textSet(n),e<=0)return s.SetActive(!1),void i.SetActive(!1)
s.SetActive(!0)
let l=Ut.p.Clamp01(e/t)
l>.99||l<.001?i.SetActive(!1):i.SetActive(!0),l<.05&&(l=.05)
const o=this.ballLineEff.transform.GetLocalPosition()
o.y=70*(-.5+l),i.transform.SetLocalPosition(o)
const a=Math.sqrt(1-(l-.5)*(l-.5)*4),r=new v.P(a,a,a)
v.P.Recyle(r),1==this.tModel.isOpenAddTip&&this.OnAddClick()}ClearRecoverTime(){ut.C.Inst_get().ClearInterval(this.timer),this.timer=-1}CheckBossAlive(){
const t=this.tModel.GetWbShowData()
let e=0
for(;e<t.Count();){if(t[e].sortId==this.tModel.curWbSortId){yt.x.Inst_get().CheckBossLevel(this.tModel.GetWbShowData()[e])
break}e+=1}}InitBossView(t){if(this.lastMonId!=t.monsterId_get()){this.PlayEffect()
const e=It.a.getInst().getObjById(t.monsterId_get())
if(null!=e){this.ClearBoss()
const s=new kt.O
s._displayID=e.displayId,s._bNeedWaitAnime=!0,s.shiledType=xt.g.DT_NONE
t.GetPos(),t.GetRotate()
this.displayUIAvatarModel?this.displayUIAvatarModel=Et.x.inst.SetUIAvatarData(s,Pt.v.monster,this.displayUIAvatarModel):(this.displayUIAvatarModel=Et.x.inst.SetUIAvatarData(s,Pt.v.monster),
this.displayUIAvatarModel.SetTarget(this.bossTexture,!0),this.bossTexture.position=new o.Vec3(-15,-60,0)),this.UpdateDisplayConfig()}}this.UpdateDisplayIndex(t)}
UpdateDisplayConfig(){this.displayUIAvatarModel.SetScale(.8,.8),this.displayUIAvatarModel.SetDir(4),this.displayUIAvatarModel.UpdateUIAvatar()}UpdateDisplayIndex(t){
const e=this.GeShowData()
let s=0
for(;s<e.Count();)e[s].monsterId==t.monsterId_get()&&(this.bossShowItem.SetData(e[s]),this.lastIndex=s),s+=1
this.lastMonId=t.monsterId_get()}GeShowData(){return ct._.Inst().GetWbShowData()}PlayEffect(){this.worldBossEffect.SetActive(!0),this.worldBossEffect.replay(),
this.tweenScale.ResetToBeginning(),this.tweenScale.PlayForward(),this.tweenAlpha.ResetToBeginning(),this.tweenAlpha.PlayForward()}ClearBoss(){}OnSearchClick(t,e){
null!=Qt.W.inst_get().view||H.B.Inst.isOpenMaskStart||(this.CheckGuide(),this.SearchForBoss())}OnUpdateTiredInfo(t){this.UpdateTimeCountInfo(),this.SetTiredStr()}
OnUpdateAttentionInfo(t){const e=this.cfg.monsterId_get()
this.selectSpt.SetActive(this.tModel.attentionLis.IndexOf(e,0)>=0)}OnUpdateSearchBtn(t){this.searchForBossBtn.SetActive(t)}OnDragingMoving(){
const t=this.table.node.position,e=this.initPosX-t.x>0&&this.initPosX-t.x||0
let s=Math.floor((e+this.itemWidth/2)/this.itemWidth)
if(null!=this.bossTable.itemList&&(s=s>this.bossTable.itemList.Count()-1&&this.bossTable.itemList.Count()-1||s,this.lastIndex!=s)){this.lastIndex=s
const t=this.bossTable.itemList
for(let e=0;e<=t.Count()-1;e++)null!=t[e]&&e==s&&(this.tModel.curWbSortId=t[e].bossData.sortId,this.SetData())
this.bossTable.Reposition()}}OnDragFinished(){const t=this.table.node.position,e=this.initPosX-t.x>0&&this.initPosX-t.x||0
let s=Math.floor((e+this.itemWidth/2)/this.itemWidth)
s=s>this.bossTable.itemList.Count()-1&&this.bossTable.itemList.Count()-1||s,this.lastIndex=s,this.ChangeScrollPosByIndex(this.lastIndex)}ChangeScrollPosByIndex(t){
const e=this.table.node.position
e.set(this.initPosX-this.itemWidth*t-20,e.y,e.z),this.isDragClick&&(this.bossScrollView.scrollTo(t),this.isDragClick=!1)}AdaptScreenSize(){const t=Nt.t.GetUIWidth()-25
this.bossScrollPanel.node.transform.width=t-10
const e=this.bossScrollView.content.getComponent(o.Layout)
e.paddingLeft=(t-this.showItemWidth)/2,e.paddingRight=(t-this.showItemWidth)/2
const s=(t-this.initScrollWidth)/2
this.table.node.transform.GetLocalPosition()
this.initPosX=this.initPosXOpen-s,this.table.node.transform.SetLocalPosition(this.initPosX)
let i=this.leftBg.width()
i+=s,this.leftBg.widthSet(i-5),this.rightBg.widthSet(i-10)
let n=this.leftBg2.width()
n+=s,this.leftBg2.widthSet(n),this.rightBg2.widthSet(n),this.cfg.type_get()==ht.l.ANCIENTBOSS&&(this.dropScrollPanel.node.transform.width=this.dropScrollPanel.node.transform.width+84)
}}ee.STAGE_ID=71
class se extends ee{constructor(...t){super(...t),this.tModel=null,this.rInfo=null,this.sortId=0,this.cfg=null,this.objRes=null,this.boss=null,this.rotateIndex=-1,this.lastIndex=0,
this._degf_CancleHandle=null,this._degf_OnLayerRefreshFun=null,this._degf_OnLayerSelect=null,this._degf_StillGo=null,this._degf_handle=null,this._degf_OnLayerBtnUpClick=null,
this._degf_OnLayerBtnDownClick=null,this._degf_OnDragFinished=null,this._degf_DragingMoving=null,this.abMapLayers=null,this.curSelIdx=null,this.clickItemed=!1}_initBinder(){
super._initBinder(),this._degf_CancleHandle=t=>this.CancleHandle(t),this._degf_OnLayerRefreshFun=t=>this.OnLayerRefreshFun(t),this._degf_OnLayerSelect=t=>this.OnLayerSelect(t),
this._degf_StillGo=t=>this.StillGo(t),this._degf_handle=()=>this.handle(),this._degf_OnLayerBtnUpClick=(t,e)=>this.OnLayerBtnUpClick(),
this._degf_OnLayerBtnDownClick=(t,e)=>this.OnLayerBtnDownClick(),this._degf_OnDragFinished=()=>this.OnDragFinished(),this._degf_DragingMoving=()=>this.OnDragingMoving()}InitView(){
super.InitView(),this.registerUIScId=_t.D.AncientBoss,this.registerUIId=T.I.TreasurePanel}OnAddToScene(){this.stage=se.STAGE_ID,
this.bossBg2.spriteNameSet("atlas/worldboss/ryworldboss_sp_0036"),this.tiredSp1.spriteNameSet("atlas/worldboss/ryworldboss_sp_0056"),
this.tiredSp2.spriteNameSet("atlas/worldboss/ryworldboss_sp_0056"),this.tiredSp3.spriteNameSet("atlas/worldboss/ryworldboss_sp_0056"),this.extraBtn.node.SetActive(!1),
this.node.SetActive(!0),this.ancientboss_title.SetActive(!0),this.RemoveLis(),this.AddLis(),
this.m_handlerMgr.AddClickEvent(this.layerBtnUp,this.CreateDelegate(this.OnLayerBtnUpClick)),
this.m_handlerMgr.AddClickEvent(this.layerBtnDown,this.CreateDelegate(this.OnLayerBtnDownClick)),0==ct._.Inst().hasShowAni&&(ct._.Inst().hasShowAni=!0),this.SetData(),
this.tModel.isFirstInABoss||(this.clickItemed=!0,ut.C.Inst_get().SetInterval(this.CreateDelegate(this.ChangeScrollPosByIndex),700,1))}AddLis(){
pt.i.Get(this.attentionBtn.node).RegistonClick(this._degf_OnAttentionClick),pt.i.Get(this.addBtn).RegistonClick(this._degf_OnAddClick),
pt.i.Get(this.addBtn2).RegistonClick(this._degf_OnAddClick),pt.i.Get(this.searchForBossBtn).RegistonClick(this._degf_OnSearchClick),
pt.i.Get(this.tipBtn).RegistonClick(this._degf_OnTipClick),pt.i.Get(this.rareDropBtn).RegistonClick(this._degf_OnRareDropClick),
pt.i.Get(this.extraBtn.node).RegistonClick(this._degf_OnExtraRewardClick),pt.i.Get(this.showSelect.node).RegistonClick(this._degf_OnShowSelectTimesClick),
pt.i.Get(this.selectCollision).RegistonClick(this._degf_OnHideSelectTimeClick),this.m_handlerMgr.AddEventMgr(w.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors)),
g.i.Inst.AddEventHandler(w.g.WORLD_BOSS_TIRED_UPDATE,this._degf_OnUpdateTiredInfo),g.i.Inst.AddEventHandler(w.g.UPDATE_ATTENTION,this._degf_OnUpdateAttentionInfo),
this.bossScrollView.RegistonDragFinished(this._degf_OnDragFinished),this.bossScrollView.RegistonDragingMoving(this._degf_DragingMoving)}RemoveLis(){
pt.i.Get(this.attentionBtn.node).RemoveonClick(this._degf_OnAttentionClick),pt.i.Get(this.addBtn).RemoveonClick(this._degf_OnAddClick),
pt.i.Get(this.addBtn2).RemoveonClick(this._degf_OnAddClick),pt.i.Get(this.searchForBossBtn).RemoveonClick(this._degf_OnSearchClick),
pt.i.Get(this.tipBtn).RemoveonClick(this._degf_OnTipClick),pt.i.Get(this.rareDropBtn).RemoveonClick(this._degf_OnRareDropClick),
pt.i.Get(this.extraBtn.node).RemoveonClick(this._degf_OnExtraRewardClick),pt.i.Get(this.showSelect.node).RemoveonClick(this._degf_OnShowSelectTimesClick),
pt.i.Get(this.selectCollision).RemoveonClick(this._degf_OnHideSelectTimeClick),g.i.Inst.RemoveEventHandler(w.g.WORLD_BOSS_TIRED_UPDATE,this._degf_OnUpdateTiredInfo),
g.i.Inst.RemoveEventHandler(w.g.UPDATE_ATTENTION,this._degf_OnUpdateAttentionInfo)}RegGuide(){}RegGuide2(){}UnRegGuide2(){}UnRegGuide(){}CheckGuide(){
O.l.CheckBtnClickTrigger(_t.D.UI_BOSS_GLOD_CHANEAL_BTN,this.sortId)}CheckGuide2(){O.l.CheckBtnClickTrigger(_t.D.UI_BOSS_GLOD_FOLLOW_BTN,this.sortId)}CheckGuideL(){
O.l.CheckBtnClickTrigger(_t.D.UI_BOSS_GLOD_L_BTN,this.sortId)}CheckGuideR(){O.l.CheckBtnClickTrigger(_t.D.UI_BOSS_GLOD_R_BTN,this.sortId)}OnTipClick(t,e){const s=new mt.w
s.position=new v.P(-385,320,0),s.width=450,s.infoId="BOSS：WORLDBOSS_TIPS2",St.Q.Inst_get().Open(s)}handle(){this.tModel.isFirstInABoss&&(this.tModel.isFirstInABoss=!1,
this.AdaptScreenSize(),this.ChangeScrollPosByIndex(this.lastIndex))}RefreshBossGrid(){const t=new A.Z,e=this.tModel.GetAbShowData()
for(const[s,i]of(0,u.V5)(e))t.Add(i)
this.bossTable.data_set(t)}SetData(){if(this.UnRegGuide(),this.sortId=this.tModel.curAbSortId,this.RegGuide(),this.cfg=Tt.C.Inst().getItemById(this.sortId),
this.DoRefreshBossGrid(Tt.C.Inst().getItemById(this.sortId).mapId_get()),null==this.cfg)return
const t=this.cfg.monsterId_get()
this.objRes=It.a.getInst().getObjById(t),this.bossRage=this.objRes.rage,this.bosstiredconsume.textSet(this.bossRage),this.tModel.hasBossGridRefresh||(this.InitLayerInfo(),
this.bossTable.Clear(),this.tModel.hasBossGridRefresh=!0),this.RefreshDropGrid(),this.attentionContainer.SetActive(this.tModel.canAttentionLis.IndexOf(t,0)>=0),
this.selectSpt.SetActive(this.tModel.attentionLis.IndexOf(t,0)>=0),this.SetTiredStr(),this.UpdateTimeCountInfo(),this.InitBossView(this.cfg)
let e=!1;-1!=this.objRes.dropDecayLevel&&(e=this.rInfo.Level_get()-this.objRes.level>=this.objRes.dropDecayLevel),
this.bossName.textSet(`${this.cfg.name_get()} Lv.${this.objRes.level}`),this.playerName.textSet(this.tModel.GetLastKillInfo(t))}SearchForBoss(){const t=this.GetCurBossData()
yt.x.Inst_get().CheckBossLayer(t)}CancleHandle(t){Ct.Z.Inst.ClosePanel()}StillGo(t){ss.Inst().Transport(this.tModel.curAbSortId,null)}CheckBossAlive(){
const t=this.tModel.GetAbShowData()
let e=0
for(;e<t.Count();){if(t[e].sortId==this.tModel.curAbSortId){yt.x.Inst_get().BossIsAlive(this.tModel.GetAbShowData()[e])
break}e+=1}}Clear(){this.UnRegGuide2(),this.RemoveLis(),super.Clear()}InitBossView(t){super.InitBossView(t)}GeShowData(){const t=Tt.C.Inst().getItemById(this.sortId).mapId_get()
return this.tModel.GetAbShowDataByLayer(t)}PlayEffect(){this.ancientBossEffect.SetActive(!1),this.ancientBossEffect.SetActive(!0)}OnLayerRefreshFun(t){const e=new Lt
return e.setId(t,null,0),e}RefreshLayerGrid(){}InitLayerInfo(){this.abMapLayers=this.tModel.GetAbMapLayers()
const t=this.tModel.GetCurAbSortIdMapId()
let e=0
for(;e<this.abMapLayers.Count();){if(this.abMapLayers[e]==t){this.curSelIdx=e
break}e+=1}null!=this.curSelIdx?this.curSelIdx<0?Z.Y.LogError(`中立boss地图没有配置：${t}`):this.RefreshLayerInfo(this.curSelIdx):Z.Y.LogError(`中立boss地图没有配置：${t}`)}RefreshLayerInfo(t){
this.curSelIdx=t,this.UpdateButtonState()
const e=this.abMapLayers[this.curSelIdx],s=U.p.Inst_get().GetMapById(e)
if(null==s)return void Z.Y.LogError(`中立boss地图不存在：${e}`)
const i=s.minLevelLimit
let n=0
if(this.curSelIdx+1<this.abMapLayers.Count()){const t=this.abMapLayers[this.curSelIdx+1],e=U.p.Inst_get().GetMapById(t)
null!=e?n=e.minLevelLimit:Z.Y.LogError(`中立boss地图没有配置：${t}`)}if(n>0){let t=J.M.Replace(" (Lv.{0}-{1})","{0}",i+"")
t=J.M.Replace(t,"{1}",n-1+""),this.layerName.textSet(s.name+t)}else this.layerName.textSet(s.name)}OnLayerBtnDownClick(){const t=this.curSelIdx-1
this.CheckEnter(t),this.CheckGuideL()}OnLayerBtnUpClick(){const t=this.curSelIdx+1
this.CheckEnter(t),this.CheckGuideR()}UpdateButtonState(){return this.curSelIdx<=0?(this.layerBtnDown.node.SetActive(!1),
void(this.curSelIdx>=this.abMapLayers.Count()-1?this.layerBtnUp.node.SetActive(!1):this.layerBtnUp.node.SetActive(!0))):this.curSelIdx>=this.abMapLayers.Count()-1?(this.layerBtnUp.node.SetActive(!1),
void this.layerBtnDown.node.SetActive(!0)):(this.layerBtnUp.node.SetActive(!0),this.layerBtnDown.node.SetActive(!0),void this.RegGuide2())}CheckEnter(t){
if(t>=this.abMapLayers.Count())return
if(t<0)return
const e=this.abMapLayers[t],s=U.p.Inst_get().GetMapById(e)
if(ot.F.getInst().GetCanEnterMapByLvAndTransfer(e)!=F.f.CAN){const t=new A.Z([ft.h.GetLevelStr(s.minLevelLimit)])
V.y.inst.ClientSysMessage(111014,t)}else this.OnLayerSelect(e),this.RefreshLayerInfo(t)}GetLimitTrans(t){let e=""
return null!=t&&0!=t.transferJobLimitLevel&&(e=B.Z.GetJobNameByTransfor(t.transferJobLimitLevel)),e}OnLayerSelect(t){const e=gt.GF.INT(t)
ot.F.getInst().GetCanEnterMapByLvAndTransfer(e)==F.f.CAN&&(this.tModel.UpdateABossSelectIdByLayer(e),this.DoRefreshBossGrid(e))}GetCurBossData(){const t=this.tModel.GetAbShowData()
let e=0
for(;e<t.Count();){if(t[e].sortId==this.tModel.curAbSortId)return t[e]
e+=1}return null}DoRefreshBossGrid(t){const e=new A.Z,s=this.tModel.GetAbShowDataByLayer(t)
if(null!=s&&s.Count()>0)for(const[t,i]of(0,u.V5)(s))e.Add(i)
this.bossTable.data_set(e)}OnDragingMoving(){if(this.clickItemed)return
const t=this.table.node.position,e=this.initPosX-t.x>0&&this.initPosX-t.x||0
let s=Math.floor((e+this.itemWidth/2)/this.itemWidth)
if(null!=this.bossTable.itemList&&(s=s>this.bossTable.itemList.Count()-1&&this.bossTable.itemList.Count()-1||s,this.lastIndex!=s)){this.lastIndex=s
const t=this.bossTable.itemList
for(let e=0;e<=t.Count()-1;e++)e==s&&(this.tModel.curAbSortId=t[e].bossData.sortId,this.SetData())
this.bossTable.Reposition()}}OnDragFinished(){if(this.clickItemed)return void(this.clickItemed=!1)
const t=this.table.node.position,e=this.initPosX-t.x>0&&this.initPosX-t.x||0
let s=Math.floor((e+this.itemWidth/2)/this.itemWidth)
null!=this.bossTable.itemList&&(s=s>this.bossTable.itemList.Count()-1&&this.bossTable.itemList.Count()-1||s,this.lastIndex=s,this.ChangeScrollPosByIndex(this.lastIndex))}
ChangeScrollPosByIndex(t){null==t&&(t=this.lastIndex)
const e=this.table.node.position
e.set(this.initPosX-this.itemWidth*t-20,e.y,e.z),this.table.node.position=e
const s=this.bossTable.itemList
for(let t=0;t<=s.Count()-1;t++);this.bossTable.Reposition()}}se.STAGE_ID=147
var ie=s(63611),ne=s(6665),le=s(78287),oe=s(30849),ae=s(24524),re=s(6251)
class he extends wt.x{constructor(){super(),this.head=null,this.name=null,this.effect=null,this.deadSpt=null,this.stateSp=null,this.levelBg=null,this.level=null,this.nameBg=null,
this.tipEff=null,this.tModel=null,this.rInfo=null,this.bossData=null,this.cfg=null,this.objRes=null,this.isSelect=!1,this.intervalId=-1,this.bossLevel=-1,this.headState=-1,
this._degf_OnBossSelect=null,this._degf_OnBossSelectEff=null,this._degf_OnItemClick=null,this._degf_SetRefreshTime=null,this._degf_OnBossSelect=t=>this.OnBossSelect(t),
this._degf_OnBossSelectEff=t=>this.OnBossSelectEff(t),this._degf_OnItemClick=(t,e)=>this.OnItemClick(t,e),this._degf_SetRefreshTime=()=>this.SetRefreshTime()}InitView(){
this.head=new bt.w,this.head.setId(this.FatherId,this.FatherComponentID,1),this.name=new Mt.Q,this.name.setId(this.FatherId,this.FatherComponentID,2),this.effect=new bt.w,
this.effect.setId(this.FatherId,this.FatherComponentID,3),this.deadSpt=new bt.w,this.deadSpt.setId(this.FatherId,this.FatherComponentID,4),this.stateSp=new bt.w,
this.stateSp.setId(this.FatherId,this.FatherComponentID,5),this.levelBg=new bt.w,this.levelBg.setId(this.FatherId,this.FatherComponentID,6),this.level=new Mt.Q,
this.level.setId(this.FatherId,this.FatherComponentID,7),this.nameBg=new bt.w,this.nameBg.setId(this.FatherId,this.FatherComponentID,8),this.tipEff=new vt.z,
this.tipEff.setId(this.FatherId,this.FatherComponentID,9),this.tModel=ct._.Inst(),this.rInfo=_.Y.Inst.PrimaryRoleInfo_get()}Clear(){this.RemoveLis(),
ut.C.Inst_get().ClearInterval(this.intervalId)}Destroy(){this.head=null,this.name=null,this.effect=null,this.deadSpt=null,this.objRes=null}AddLis(){
pt.i.Get(this.node).RegistonClick(this._degf_OnItemClick),g.i.Inst.AddEventHandler(w.g.BOSS_SELECT,this._degf_OnBossSelect),
g.i.Inst.AddEventHandler(w.g.SELECT_BOSS_EFFECT,this._degf_OnBossSelectEff)}RemoveLis(){pt.i.Get(this.node).RemoveonClick(this._degf_OnItemClick),
g.i.Inst.RemoveEventHandler(w.g.BOSS_SELECT,this._degf_OnBossSelect),g.i.Inst.RemoveEventHandler(w.g.SELECT_BOSS_EFFECT,this._degf_OnBossSelectEff)}OnItemClick(t,e){
this.tipEff.SetActive(!1),g.i.Inst.RaiseEvent(w.g.BOSS_SELECT,this.bossData)}OnBossSelect(t){const e=t
this.isSelect=e.monsterId==this.bossData.monsterId,this.effect.node.SetActive(this.isSelect)
let s=this.cfg.name_get()
this.isSelect?(s=`[f4e2b3]${s}[-]`,this.level.textSet(`[f4e2b3]Lv.${this.bossLevel}[-]`)):e.type==ht.l.VIPBOSS?(s=`[ceccc5]${s}[-]`,
this.level.textSet(`[ceccc5]Lv.${this.bossLevel}[-]`)):s=`[B8ABA2]${s}[-]`,this.name.textSet(s)}SetData(t){this.tipEff.SetActive(!1),this.AddLis()
const e=t
if(this.bossData=e,this.cfg=Tt.C.Inst().getItemById(e.sortId),this.objRes=It.a.getInst().getObjById(e.monsterId),this.head.spriteNameSet(this.objRes.headResources),
this.deadSpt.node.SetActive(!1),this.bossLevel=-1,this.tModel.sIds.IndexOf(e.sortId,0)<0&&this.tModel.vipsIds.IndexOf(e.sortId,0)<0){
e.info.refreshTime.ToNum()-Vt.D.serverMSTime_get()<=0?(this.deadSpt.node.SetActive(!1),
re.d.LuaMakeGoGray(this.head.node.FatherId,this.head.node.ComponentId,!1,!0)):(this.deadSpt.node.SetActive(!0),
re.d.LuaMakeGoGray(this.head.node.FatherId,this.head.node.ComponentId,!0,!0),this.intervalId=ut.C.Inst_get().SetInterval(this._degf_SetRefreshTime,1e3),this.SetRefreshTime())}
e.type==ht.l.WORLDBOSS&&(this.isSelect=e.sortId==this.tModel.curWbSortId),e.type==ht.l.NEUTROLBOSS&&(this.isSelect=e.sortId==this.tModel.curNbSortId),
e.type==ht.l.VIPBOSS&&(this.isSelect=e.sortId==this.tModel.curVbSortId),e.type==ht.l.ANCIENTBOSS&&(this.isSelect=e.sortId==this.tModel.curAbSortId),
this.effect.node.SetActive(this.isSelect)
let s=this.cfg.name_get()
s=this.isSelect?`[f4e2b3]${s}[-]`:this.tModel.viewType==ht.l.VIPBOSS?`[ceccc5]${s}[-]`:`[B8ABA2]${s}[-]`,this.name.textSet(s),
this.tModel.viewType==ht.l.VIPBOSS?this.bossLevel=ae.o.Inst().getItemById(this.cfg.copyid_get()).minLevelLimit:this.bossLevel=this.objRes.level,
this.isSelect?this.level.textSet(`[f4e2b3]Lv.${this.bossLevel}[-]`):this.level.textSet(`[ceccc5]Lv.${this.bossLevel}[-]`),this.UpdateSpState(),this.UpdateStateSp()}UpdateStateSp(){
this.tModel.viewType==ht.l.VIPBOSS?(this.headState=this.tModel.vbBossState[this.bossData.sortId],
0==this.headState?this.stateSp.node.SetActive(!1):1==this.headState?(this.stateSp.node.SetActive(!0),this.stateSp.spriteNameSet(he.freeSp)):(this.stateSp.node.SetActive(!0),
this.stateSp.spriteNameSet(he.recommandSp))):this.stateSp.node.SetActive(!1)}UpdateSpState(){if(this.level.node.SetActive(!0),this.levelBg.node.SetActive(!0),
this.nameBg.node.SetActive(!0),this.tModel.viewType==ht.l.VIPBOSS){const t=_.Y.Inst.PrimaryRoleInfo_get().Level_get(),e=this.bossLevel>t
this.SetSpGray(this.head,e),this.SetSpGray(this.levelBg,e),this.SetSpGray(this.nameBg,e),re.d.LuaMakeGoGray(this.name.node.FatherId,this.name.node.ComponentId,e,!0),
re.d.LuaMakeGoGray(this.level.node.FatherId,this.level.node.ComponentId,e,!0)}let t=!1
this.tModel.viewType==ht.l.VIPBOSS&&(t=!0),this.stateSp.node.SetActive(t)}SetSpGray(t,e){re.d.LuaMakeGoGray(t.node.FatherId,t.node.ComponentId,e,!0)}SetRefreshTime(){
this.bossData.info.refreshTime.ToNum()-Vt.D.serverMSTime_get()<=0&&(this.deadSpt.node.SetActive(!1),re.d.LuaMakeGoGray(this.head.node.FatherId,this.head.node.ComponentId,!1,!0),
ut.C.Inst_get().ClearInterval(this.intervalId))}OnBossSelectEff(t){gt.GF.INT(t)==this.bossData.sortId?this.tipEff.SetActive(!0):this.tipEff.SetActive(!1)}}he.freeSp="boss_sp_0023",
he.recommandSp="boss_sp_0024"
class de extends wt.x{constructor(){super(),this.selectBg=null,this.floorNum=null,this.floor=0,this.tModel=null,this._degf_OnFloorSelect=null,this._degf_OnItemClick=null,
this._degf_OnFloorSelect=t=>this.OnFloorSelect(t),this._degf_OnItemClick=(t,e)=>this.OnItemClick(t,e)}InitView(){super.InitView(),this.selectBg=new bt.w,
this.selectBg.setId(this.FatherId,this.FatherComponentID,1),this.floorNum=new Mt.Q,this.floorNum.setId(this.FatherId,this.FatherComponentID,2),this.tModel=ct._.Inst()}SetData(t){
super.SetData(t),this.AddLis(),this.floor=gt.GF.INT(t)
let e=this.GetFloorStr(this.floor)
e=this.floor==this.tModel.curFloor?`[F4E2B3]${e}[-]`:`[B8ABA2]${e}[-]`,this.floorNum.textSet(e),this.selectBg.node.SetActive(this.floor==this.tModel.curFloor)}Clear(){
super.Clear(),this.RemoveLis()}Destroy(){super.Destroy(),this.selectBg=null,this.floorNum=null}AddLis(){pt.i.Get(this.node).RegistonClick(this._degf_OnItemClick),
g.i.Inst.AddEventHandler(w.g.FLOOR_SELECT,this._degf_OnFloorSelect)}RemoveLis(){pt.i.Get(this.node).RemoveonClick(this._degf_OnItemClick),
g.i.Inst.RemoveEventHandler(w.g.FLOOR_SELECT,this._degf_OnFloorSelect)}OnItemClick(t,e){g.i.Inst.RaiseEvent(w.g.FLOOR_SELECT,this.floor)}OnFloorSelect(t){
this.selectBg.node.SetActive(this.floor==gt.GF.INT(t))}GetFloorStr(t){let e=""
return 1==t?e=(0,p.T)("第一层"):2==t?e=(0,p.T)("第二层"):3==t?e=(0,p.T)("第三层"):4==t?e=(0,p.T)("第四层"):5==t?e=(0,p.T)("第五层"):6==t&&(e=(0,p.T)("第六层")),e}}class ce extends oe.C{
constructor(){super(),this.bossName=null,this.bossLevel=null,this.refreshTime=null,this.killInfo=null,this.dropObj=null,this.extraDropObj=null,this.dropGrid=null,
this.extraDropGrid=null,this.tipBtn=null,this.tipLabel=null,this.bossGrid=null,this.leftBtn=null,this.rightBtn=null,this.floorGrid=null,this.upBtn=null,this.downBtn=null,
this.attentionBtn=null,this.selectSpt=null,this.floorScrollBar=null,this.bossScrollBar=null,this.bossDetailContainer=null,this.attentionContainer=null,this.dropBar=null,
this.extraDropBar=null,this.highestLv=null,this.tModel=null,this.bossDragAmount=0,this.floorDragAmount=0,this.sortId=0,this.cfg=null,this.objRes=null,this.serverData=null,
this.intervalId=-1,this.intervalId2=-1,this.floorScrollIntervalId=-1,this.bossScrollIntervalId=-1,this._degf_Handle=null,this._degf_OnAttentionClick=null,
this._degf_OnBossItemLoadComplete=null,this._degf_OnFloorRefreshFun=null,this._degf_OnItemRefreshFun=null,this._degf_OnRewardRefreshFun=null,this._degf_OnTipBtnClick=null,
this._degf_SetRefreshTime=null,this._degf_UpdateBossArrow=null,this._degf_UpdateFloorArrow=null,this._degf_Handle=()=>this.Handle(),
this._degf_OnAttentionClick=(t,e)=>this.OnAttentionClick(t,e),this._degf_OnBossItemLoadComplete=()=>this.OnBossItemLoadComplete(),
this._degf_OnFloorRefreshFun=t=>this.OnFloorRefreshFun(t),this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),this._degf_OnRewardRefreshFun=t=>this.OnRewardRefreshFun(t),
this._degf_OnTipBtnClick=(t,e)=>this.OnTipBtnClick(t,e),this._degf_SetRefreshTime=()=>this.SetRefreshTime(),this._degf_UpdateBossArrow=()=>this.UpdateBossArrow(),
this._degf_UpdateFloorArrow=()=>this.UpdateFloorArrow()}InitView(){super.InitView(),this.bossName=new Mt.Q,this.bossName.setId(this.FatherId,this.FatherComponentID,1),
this.bossLevel=new Mt.Q,this.bossLevel.setId(this.FatherId,this.FatherComponentID,2),this.refreshTime=new Mt.Q,this.refreshTime.setId(this.FatherId,this.FatherComponentID,3),
this.killInfo=new Mt.Q,this.killInfo.setId(this.FatherId,this.FatherComponentID,4),this.dropObj=new vt.z,this.dropObj.setId(this.FatherId,this.FatherComponentID,5),
this.extraDropObj=new vt.z,this.extraDropObj.setId(this.FatherId,this.FatherComponentID,6),this.dropGrid=new ne.A,this.dropGrid.setId(this.FatherId,this.FatherComponentID,7),
this.extraDropGrid=new ne.A,this.extraDropGrid.setId(this.FatherId,this.FatherComponentID,8),this.tipBtn=new Dt.W,this.tipBtn.setId(this.FatherId,this.FatherComponentID,9),
this.tipLabel=new Mt.Q,this.tipLabel.setId(this.FatherId,this.FatherComponentID,10),this.bossGrid=new ne.A,this.bossGrid.setId(this.FatherId,this.FatherComponentID,12),
this.leftBtn=new Dt.W,this.leftBtn.setId(this.FatherId,this.FatherComponentID,13),this.rightBtn=new Dt.W,this.rightBtn.setId(this.FatherId,this.FatherComponentID,14),
this.floorGrid=new ne.A,this.floorGrid.setId(this.FatherId,this.FatherComponentID,16),this.upBtn=new Dt.W,this.upBtn.setId(this.FatherId,this.FatherComponentID,17),
this.downBtn=new Dt.W,this.downBtn.setId(this.FatherId,this.FatherComponentID,18),this.attentionBtn=new Dt.W,this.attentionBtn.setId(this.FatherId,this.FatherComponentID,19),
this.selectSpt=new vt.z,this.selectSpt.setId(this.FatherId,this.FatherComponentID,20),this.floorScrollBar=new le._,
this.floorScrollBar.setId(this.FatherId,this.FatherComponentID,21),this.bossScrollBar=new le._,this.bossScrollBar.setId(this.FatherId,this.FatherComponentID,22),
this.bossDetailContainer=new vt.z,this.bossDetailContainer.setId(this.FatherId,this.FatherComponentID,23),this.attentionContainer=new vt.z,
this.attentionContainer.setId(this.FatherId,this.FatherComponentID,24),this.dropBar=new le._,this.dropBar.setId(this.FatherId,this.FatherComponentID,25),this.extraDropBar=new le._,
this.extraDropBar.setId(this.FatherId,this.FatherComponentID,26),this.highestLv=new Mt.Q,this.highestLv.setId(this.FatherId,this.FatherComponentID,27),
this.dropGrid.SetInitInfo("ui_treasure_bossdropitem_big",this._degf_OnRewardRefreshFun),
this.extraDropGrid.SetInitInfo("ui_treasure_bossdropitem_big",this._degf_OnRewardRefreshFun),this.bossGrid.SetInitInfo("ui_treasure_bossbtn",this._degf_OnItemRefreshFun),
this.floorGrid.SetInitInfo("ui_treasure_flooritem",this._degf_OnFloorRefreshFun),this.bossGrid.OnReposition_set(this._degf_OnBossItemLoadComplete),this.tModel=ct._.Inst()}
OnRewardRefreshFun(t){const e=new $t.j
return e.setId(t,null,0),e}OnItemRefreshFun(t){const e=new he
return e.setId(t,null,0),e}OnFloorRefreshFun(t){const e=new de
return e.setId(t,null,0),e}OnBossItemLoadComplete(){this.intervalId2=ut.C.Inst_get().SetInterval(this._degf_Handle,100,1)}Handle(){this.bossScrollBar.SetValue(this.bossDragAmount)}
UpdateFloorArrow(){let t=!1,e=!1
this.floorGrid.data_get().Count()>4?0==this.floorScrollBar.GetValue()?(t=!1,e=!0):this.floorScrollBar.GetValue()>.99?(t=!0,e=!1):(t=!0,e=!0):(t=!1,e=!1),
this.upBtn.node.activeInHierarchy!=t&&this.upBtn.node.SetActive(t),this.downBtn.node.activeInHierarchy!=e&&this.downBtn.node.SetActive(e)}UpdateBossArrow(){let t=!1,e=!1
this.bossGrid.data_get().Count()>3?0==this.bossScrollBar.GetValue()?(t=!0,e=!1):this.bossScrollBar.GetValue()>.99?(t=!1,e=!0):(t=!0,e=!0):(t=!1,e=!1),
this.rightBtn.node.activeInHierarchy!=t&&this.rightBtn.node.SetActive(t),this.leftBtn.node.activeInHierarchy!=e&&this.leftBtn.node.SetActive(e)}Clear(){this.RemoveLis(),
ut.C.Inst_get().ClearInterval(this.intervalId),ut.C.Inst_get().ClearInterval(this.intervalId2),ut.C.Inst_get().ClearInterval(this.floorScrollIntervalId),
ut.C.Inst_get().ClearInterval(this.bossScrollIntervalId)}Destroy(){this.dropGrid.Destroy(),this.extraDropGrid.Destroy(),this.bossGrid.Destroy(),this.floorGrid.Destroy(),
this.bossName=null,this.bossLevel=null,this.refreshTime=null,this.killInfo=null,this.dropObj=null,this.extraDropObj=null,this.dropGrid=null,this.extraDropGrid=null,
this.tipBtn=null,this.tipLabel=null,this.bossGrid=null,this.leftBtn=null,this.rightBtn=null,this.floorGrid=null,this.upBtn=null,this.downBtn=null,this.attentionBtn=null,
this.selectSpt=null,this.floorScrollBar=null,this.bossScrollBar=null,this.bossDetailContainer=null,this.attentionContainer=null,this.dropBar=null,this.extraDropBar=null}
OnAddToScene(){this.AddLis(),this.SetData()}AddLis(){pt.i.Get(this.tipBtn.node).RegistonClick(this._degf_OnTipBtnClick),
pt.i.Get(this.attentionBtn.node).RegistonClick(this._degf_OnAttentionClick),this.floorScrollIntervalId=ut.C.Inst_get().SetInterval(this._degf_UpdateFloorArrow,100,-1),
this.bossScrollIntervalId=ut.C.Inst_get().SetInterval(this._degf_UpdateBossArrow,100,-1)}RemoveLis(){pt.i.Get(this.tipBtn.node).RemoveonClick(this._degf_OnTipBtnClick),
pt.i.Get(this.attentionBtn.node).RemoveonClick(this._degf_OnAttentionClick)}OnTipBtnClick(t,e){yt.x.Inst_get().OpenNbTip()}OnAttentionClick(t,e){
this.selectSpt.SetActive(!this.selectSpt.activeInHierarchy)
const s=new Wt.m
s.bossId=this.cfg.monsterId_get(),this.selectSpt.activeInHierarchy?s.type=1:s.type=0,S.C.Inst.F_SendMsg(s)}RefreshBossGrid(){
const t=new A.Z,e=this.tModel.GetNbShowDataByFloor(this.tModel.curFloor)
for(const[s,i]of(0,u.V5)(e))t.Add(i)
this.bossDragAmount=this.tModel.GetDragAmount(t.Count(),this.tModel.nbDefaultIndex,ct._.NEUTROL_BOSS_NUM_PER_PAGE),this.bossGrid.data_set(t)}RefreshFloorGrid(){
const t=new A.Z,e=ct._.Inst().neutrolBossCount
let s=1
for(;s<=e;)t.Add(s),s+=1
this.floorDragAmount=this.tModel.GetDragAmount(6,this.tModel.curFloor-1,ct._.FLOOR_NUM_PER_PAGE),this.floorGrid.data_set(t)}RefreshDropGrid(){this.dropBar.SetValue(0),
this.extraDropBar.SetValue(0)
const t=this.tModel.GetRewardLis(this.sortId)
t.Count()>0?(this.dropObj.SetActive(!0),this.dropGrid.data_set(t)):this.dropObj.SetActive(!1)}SetRefreshTime(){}SetData(){this.sortId=this.tModel.curNbSortId,
this.tModel.hasBossGridRefresh||(this.RefreshBossGrid(),this.tModel.hasBossGridRefresh=!0),this.RefreshFloorGrid(),this.RefreshDropGrid(),
this.cfg=Tt.C.Inst().getItemById(this.sortId),this.objRes=It.a.getInst().getObjById(this.cfg.monsterId_get()),ut.C.Inst_get().ClearInterval(this.intervalId),
this.objRes.objectType==ie.b.MONSTER_BOSS?(this.bossDetailContainer.SetActive(!0),this.serverData=this.tModel.AllBossInfo_get()[this.cfg.monsterId_get()],this.SetRefreshTime(),
this.intervalId=ut.C.Inst_get().SetInterval(this._degf_SetRefreshTime,1e3,-1),
this.killInfo.textSet(this.tModel.GetLastKillInfo(this.cfg.monsterId_get()))):(this.bossDetailContainer.SetActive(!1),this.refreshTime.textSet(""),this.killInfo.textSet("")),
this.bossName.textSet(this.cfg.name_get()),this.bossLevel.textSet(this.objRes.level+(0,p.T)("级")),
this.attentionContainer.SetActive(this.tModel.canAttentionLis.IndexOf(this.cfg.monsterId_get(),0)>=0),
this.selectSpt.SetActive(this.tModel.attentionLis.IndexOf(this.cfg.monsterId_get(),0)>=0),this.highestLv.textSet((0,
p.T)("最高掉落[e2a66a]")+(O.l.getEquiplvStr(this.cfg.highestLv_get())+(0,p.T)("[-]装备"))),this.highestLv.node.SetActive(1!=this.cfg.highestLv_get())}SearchForBoss(){
at.U.inst.model.effectiveLevel_get()}EnterBossHomeReq(t){}}
var Ie=s(43662),ue=s(26055),pe=s(87722),_e=s(50838),ge=s(28192),me=s(80156),Se=s(47681),fe=s(27122),Ce=s(41670),Te=s(85770),ye=s(72800),Ae=s(47786),ve=s(68637),De=s(19519),we=s(21729)
class Be extends((0,Gt.yk)()){constructor(...t){super(...t),this.head=null,this.effect=null,this.stateSp=null,this.level=null,this.okGo=null,this.tModel=null,this.bossData=null,
this.cfg=null,this.objRes=null,this.headState=-1,this.levelStr=null,this._degf_OnBossSelect=null,this._degf_OnItemClick=null,this._degf_TimeChange=null,this.time=-1,
this._lefttimeintervalId=-1,this.offsetlist=new A.Z([85,20,0,23,100,220,230])}_initBinder(){super._initBinder(),this._degf_OnBossSelect=t=>this.OnBossSelect(t),
this._degf_OnItemClick=(t,e)=>this.OnItemClick(t,e),this._degf_TimeChange=()=>this.UpdateTimeHnader()}InitView(){this.tModel=ct._.Inst()}Clear(){this.RemoveLis(),this.ClearTimer()}
Destroy(){this.effect=null,this.level=null}AddLis(){pt.i.Get(this.content.node).RegistonClick(this._degf_OnItemClick),
g.i.Inst.AddEventHandler(w.g.BOSS_SELECT,this._degf_OnBossSelect)}RemoveLis(){pt.i.Get(this.content.node).RemoveonClick(this._degf_OnItemClick),
g.i.Inst.RemoveEventHandler(w.g.BOSS_SELECT,this._degf_OnBossSelect)}OnItemClick(t,e){g.i.Inst.RaiseEvent(w.g.BOSS_SELECT,this.bossData)}OnBossSelect(t){
t.monsterId==this.bossData.monsterId?this.SetSelect(!0):this.SetSelect(!1)}SetSelect(t){this.selectbg.SetActive(t),this.lockbg.SetActive(!t),
this.selectbg.skin="atlas/worldboss/ryworldboss_sp_0065",1==t?this.icon.node.transform.setContentSize(124,118):this.icon.node.transform.setContentSize(105,99)}SetIndex(t,e,s){
const i=we.N.Lerp(this.offsetlist[t],this.offsetlist[e],s)
K.I.calVec0.Set(i,0,0),this.content.node.SetLocalPositionXYZ(i,0,0)}SetData(t){this.AddLis()
const e=t
this.bossData=e,this.cfg=Tt.C.Inst().getItemById(e.sortId),this.objRes=It.a.getInst().getObjById(e.monsterId),this.icon.spriteNameSet("atlas/touxiang/"+this.objRes.headResources),
null!=this.bossData.info?this.deadicon.SetActive(this.bossData.info.refreshTime.ToNum()-Vt.D.serverMSTime_get()>0):this.deadicon.SetActive(!1),this.UpdateStateObj()}SetSpGray(t,e){
re.d.LuaMakeGoGray(t.node,e)}UpdateStateObj(){const t=ae.o.Inst().getItemById(this.cfg.copyid_get()),e=this.cfg.name_get()
this.namelab.textSet(e),this.viplevel.textSet(`V ${t.GetVipLimit()}`),this.SetSelect(this.bossData.sortId==this.tModel.curVbSortId),this.UpdateDes()
const s=t.GetVipLimit(),i=at.U.inst.model.level_get()
s>i?re.d.LuaMakeGoGray(this.viparea,!0):re.d.LuaMakeGoGray(this.viparea,!1)
const n=_.Y.Inst.m_primaryRoleInfo.Level_get(),l=t.GetLvConditionLimit()
s>i||l>n?(this.lockicon.node.SetActive(!0),this.lockbg.node.SetActive(!0),re.d.LuaMakeGoGray(this.icon.node,!0)):(this.lockicon.node.SetActive(!1),this.lockbg.node.SetActive(!1),
re.d.LuaMakeGoGray(this.icon.node,!1)),l>n?this.statuslab.textSet(J.M.Replace((0,p.T)("{0}级开启"),"{0}",l.toString())):this.UpdateTime()}UpdateDes(){
const t=ae.o.Inst().getItemById(this.cfg.copyid_get())
let e=this.bossData.isLocked
this.bossData.isLocked,t.GetVipLimit()
null!=this.bossData.info&&this.bossData.IsVipDie()&&(e=!0)
let s=null
s="[ceccc5]"
const i=`${this.objRes.level}级`
this.levellab.textSet(`[ceccc5]${i}[-]`),this.levelBg.widthSet(this.levellab.width()+40)}UpdateTime(){this.ClearTimer(),
null!=this.bossData.info&&this.bossData.IsVipDie()?(this._lefttimeintervalId=ut.C.Inst_get().SetInterval(this._degf_TimeChange,1e3),
this.time=(this.bossData.info.refreshTime.ToNum()-Vt.D.serverMSTime_get())/1e3+1,this.UpdateTimeHnader()):this.statuslab.textSet("")}ClearTimer(){
ut.C.Inst_get().ClearInterval(this._lefttimeintervalId),this._lefttimeintervalId=-1}UpdateTimeHnader(){if(this.time<=0)return this.statuslab.textSet(""),this.ClearTimer(),
void this.UpdateDes()
this.time-=1
let t=Ae.x.Inst().getItemStrById(111026)
t=J.M.Replace(t,"{0}","")
const e=O.l.GetDateFormat(this.time)
this.statuslab.textSet(e+t)}}class Me extends((0,Gt.Ri)()){constructor(...t){super(...t),this._m_handlerMgr=null,this.copyType=0,this.showBossList=null,this.initPosY=null,
this.initScrollHeight=null,this.itemHeight=null,this.itemoffsets=null,this.tModel=null,this.copyRes=null,this.vipLimitTeplate=null,this.levelLimitTeplate=null,this.time=null,
this.registerUIScId=null,this.registerUIId=null,this.curBossData=null,this.cfg=null,this.scrollIndex=null,this.sortId=null,this.totalPassTimes=null,this.costdemand=null,
this.bossScrollBar=null,this.dragAmount=null,this._lefttimeintervalId=null,this.lastMonId=null,this.boss=null,this.rotateIndex=null,this.selectedIndex=null,
this.displayUIAvatarModel=void 0}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=ge.h.Get()),this._m_handlerMgr}__SubInitClass3(){}InitView(){
this.dropGrid.SetInitInfo("ui_treasure_bossdropitem_big",this.CreateDelegate(this.OnRewardRefreshFun)),
this.bossTable.SetInitInfo("ui_treasure_vbossitem_small",this.CreateDelegate(this.CreateItemHandler)),this.bossTable.OnReposition_set(this.CreateDelegate(this.OnReposition)),
this.initPosY=this.bossScrollView.content.transform.GetLocalPosition().y,this.initScrollHeight=this.bossScrollPanel.content.transform.height,this.itemHeight=120,
this.itemoffsets=new A.Z([25,0,25,50,65]),this.tModel=ct._.Inst(),this.copyRes=null,this.vipLimitTeplate=(0,p.T)("1.VIP{0}"),this.levelLimitTeplate=(0,p.T)("2.等级到达{0}"),
this.time=0,this.InitTabName(),this.registerUIScId=_t.D.VipBoss,this.registerUIId=T.I.TreasurePanel,
this.m_handlerMgr.AddClickEvent(this.leftBtn1.node,this.CreateDelegate(this.OnLeftBtnClick)),
this.m_handlerMgr.AddClickEvent(this.leftBtn2.node,this.CreateDelegate(this.OnLeftBtnClick)),
this.m_handlerMgr.AddClickEvent(this.leftBtn3.node,this.CreateDelegate(this.OnLeftBtnClick)),Ft.O.SetAnchorPos(this.leftAnchor,!0,!1,0,!1),this.displayUIAvatarModel=new _e.o,
this.displayUIAvatarModel.SetTarget(this.bossTexture.getComponent(Se.s),!0),this.displayUIAvatarModel.setUpDragNode(this.bossTexture.node)}InitTabName(){
let t=ae.o.Inst().getItemByCopyType(ye.S.VipBoss1),e=t.GetVipLimit(),s=U.p.Inst_get().GetMapIdsByControllerType(q.N.VIP_BOSS_1),i=U.p.Inst_get().GetMapById(s[0])
this.leftBtn1.SetData(e,i),t=ae.o.Inst().getItemByCopyType(ye.S.VipBoss2),e=t.GetVipLimit(),s=U.p.Inst_get().GetMapIdsByControllerType(q.N.VIP_BOSS_2),
i=U.p.Inst_get().GetMapById(s[0]),this.leftBtn2.SetData(e,i),t=ae.o.Inst().getItemByCopyType(ye.S.VipBoss3),e=t.GetVipLimit(),
s=U.p.Inst_get().GetMapIdsByControllerType(q.N.VIP_BOSS_3),i=U.p.Inst_get().GetMapById(s[0]),this.leftBtn3.SetData(e,i)}BossSelectHandler(t){const e=t
this.curBossData=e,this.cfg=Tt.C.Inst().getItemById(this.curBossData.sortId),this.scrollIndex=this.GetIndex(),this.ChangeScrollPosByIndex(this.scrollIndex),this.SetData()}
OnAddToScene(){this.RemoveLis(),this.AddLis(),i.D.Inst_get().redPointNumSpecial>0&&Yt.t.inst.CM_RedPointClickHandle(qt.t.VIP_BOSS_SPECIAL,!0)
const t=this.tModel.CalFixVipBossSortId()
this.node.SetActive(!0),t?(this.tModel.curVbSortId=this.tModel.calVBossData.sortId,this.cfg=Tt.C.Inst().GetItemByBossId(this.tModel.curVbSortId),
this.copyRes=ae.o.Inst().getItemById(this.cfg.copyid_get()),this.SelectCopyType(this.copyRes.controllerType)):(this.SelectCopyType(ye.S.VipBoss1),this.SetCurVbSortId(),
this.cfg=Tt.C.Inst().GetItemByBossId(this.tModel.curVbSortId),this.copyRes=ae.o.Inst().getItemById(this.cfg.copyid_get())),this.UnRegGuide(),this.sortId=this.tModel.curVbSortId,
this.RegGuide(),this.scrollIndex=this.GetIndex()
let e=110*this.showBossList.length
this.bossScrollView.content.transform.height=e,this.bossTable.data_set(this.showBossList),this.SetData(),this.OnReposition(),this.scheduleOnce(this.OnReposition.bind(this),1)}
GetIndex(){const t=this.showBossList
let e=0
for(let s=0;s<=t.Count()-1;s++)t[s].sortId==this.cfg.id_get()&&(e=s)
const s=t.Count()
return e<3?e=0==e?-1:0:e+2>=s?e=e==s-1?s-4:s-5:e-=2,e}AddLis(){this.m_handlerMgr.AddClickEvent(this.searchForBossBtn,this.CreateDelegate(this.EnterCopyClick)),
this.m_handlerMgr.AddClickEvent(this.addBtn,this.CreateDelegate(this.OnAddClick)),this.m_handlerMgr.AddClickEvent(this.tipBtn,this.CreateDelegate(this.OnTipClick)),
this.m_handlerMgr.AddClickEvent(this.rareDropBtn,this.CreateDelegate(this.OnRareDropClick)),
this.m_handlerMgr.AddEventMgr(w.g.COPYRECORD_UPDATE,this.CreateDelegate(this.UpdateTimes)),
this.m_handlerMgr.AddEventMgr(w.g.CLICK_REDPOINTINFO_UPDTAE,this.CreateDelegate(this.SetRedPoint)),
this.bossScrollView.RegistonDragingMoving(this.CreateDelegate(this.OnDragingMoving)),g.i.Inst.AddEventHandler(w.g.BOSS_SELECT,this.CreateDelegate(this.BossSelectHandler))}
RemoveLis(){this.m_handlerMgr.RemoveClickEvent(this.searchForBossBtn,this.CreateDelegate(this.EnterCopyClick)),
this.m_handlerMgr.RemoveClickEvent(this.addBtn,this.CreateDelegate(this.OnAddClick)),this.m_handlerMgr.RemoveClickEvent(this.tipBtn,this.CreateDelegate(this.OnTipClick)),
this.m_handlerMgr.RemoveClickEvent(this.rareDropBtn,this.CreateDelegate(this.OnRareDropClick)),
this.m_handlerMgr.RemoveEventMgr(w.g.COPYRECORD_UPDATE,this.CreateDelegate(this.UpdateTimes)),
this.m_handlerMgr.RemoveEventMgr(w.g.CLICK_REDPOINTINFO_UPDTAE,this.CreateDelegate(this.SetRedPoint)),
this.bossScrollView.RemoveonDragMoving(this.CreateDelegate(this.OnDragingMoving)),g.i.Inst.RemoveEventHandler(w.g.BOSS_SELECT,this.CreateDelegate(this.BossSelectHandler)),
this.UnRegGuide()}RegGuide(){ve.c.Inst.RegGameObject(_t.D.UI_BOSS_VIP_CHANEAL_BTN,this.searchForBossBtn.node,this.sortId),
ve.c.Inst.RegGameObject(_t.D.UI_BOSS_VIP_ADD_BTN,this.addBtn.node,this.sortId)}UnRegGuide(){null!=this.sortId&&(ve.c.Inst.UnRegGameObject(_t.D.UI_BOSS_VIP_CHANEAL_BTN,this.sortId),
ve.c.Inst.UnRegGameObject(_t.D.UI_BOSS_VIP_ADD_BTN,this.sortId),this.sortId=null)}CheckGuide(){O.l.CheckBtnClickTrigger(_t.D.UI_BOSS_VIP_CHANEAL_BTN,this.sortId)}CheckGuide2(){
O.l.CheckBtnClickTrigger(_t.D.UI_BOSS_VIP_ADD_BTN,this.sortId)}CreateItemHandler(t){return t[0].getCNode(Be)}OnRewardRefreshFun(t){return t[0].getCNode($t.j)}EnterCopyClick(){
null!=Qt.W.inst_get().view||H.B.Inst.isOpenMaskStart||this.SearchForBoss()}SearchForBoss(){if(null==this.curBossData)return void V.y.inst.ClientStrMsg(2,(0,p.T)("副本数据异常"))
const t=this.copyRes.GetVipLimit(),e=at.U.inst.model.level_get()
if(_.Y.Inst.IsLevelFix(this.copyRes.GetLvConditionLimit())&&e<t)return void this.GotoVipConfirm()
if(this.tModel.BossLimitHandle(this.cfg.copyid_get(),!0))return
const s=Te.a.Inst_get().GetCopyRecByKey(this.copyRes.controllerType)
null!=s&&(s.todayEnterHistory<this.totalPassTimes?this.time>0?V.y.inst.ClientStrMsg(2,(0,
p.T)("副本冷却中，无法挑战！")):0!=this.costdemand?this.CostConfirm():this.ReqEnterVipBoss():Ce.B.GetInst().AddTimes(this.copyRes.id))}ReqEnterVipBoss(){const t=this.cfg.copyid_get()
$.p.inst.SendEnterCopy(t)}GotoVip(){C.N.inst.OpenUIByShortCutID(_t.D.Vip)}SetSelect(){null!=this.tModel.calVBossData&&(this.tModel.curVbSortId=this.tModel.calVBossData.sortId,
g.i.Inst.RaiseEvent(w.g.BOSS_SELECT,this.tModel.calVBossData),this.bossScrollBar.SetValue(this.tModel.GetCenterRate()))}OnRareDropClick(t,e){ss.inst.OpenDropTip()}OnTipClick(){
const t=new mt.w
t.position=new v.P(-385,320,0),t.width=480,t.infoId="BOSS：VIPBOSS",St.Q.Inst_get().Open(t)}OnLeftBtnClick(t){const e=this.tModel.CalFixVipBossSortId()
this.copyType=0,t.target==this.leftBtn1.node?this.copyType=ye.S.VipBoss1:t.target==this.leftBtn2.node?this.copyType=ye.S.VipBoss2:t.target==this.leftBtn3.node&&(this.copyType=ye.S.VipBoss3),
this.SelectCopyType(this.copyType)
let s=!1
if(e){let t=0
for(;t<this.showBossList.Count();){if(this.showBossList[t].sortId==this.tModel.calVBossData.sortId){this.tModel.curVbSortId=this.tModel.calVBossData.sortId,s=!0
break}t+=1}}s||this.SetCurVbSortId(),this.cfg=Tt.C.Inst().GetItemByBossId(this.tModel.curVbSortId),this.copyRes=ae.o.Inst().getItemById(this.cfg.copyid_get()),
this.scrollIndex=this.GetIndex(),this.SetData()
let i=110*this.showBossList.length
this.bossScrollView.content.transform.height=i,this.bossTable.data_set(this.showBossList)}SetCurVbSortId(){const t=_.Y.Inst.PrimaryRoleInfo_get().Level_get()
let e=this.showBossList[0].sortId,s=0
for(;s<this.showBossList.Count();){const i=Tt.C.Inst().GetItemByBossId(this.showBossList[s].sortId)
t>=ae.o.Inst().getItemById(i.copyid_get()).GetLvConditionLimit()&&(e=this.showBossList[s].sortId),s+=1}this.tModel.curVbSortId=e}SelectCopyType(t){this.copyType=t,
t==ye.S.VipBoss1?(this.leftBtn1.SetSelect(!0),this.bossBg2.spriteNameSet("ryworldboss_sp_0050")):t==ye.S.VipBoss2?(this.leftBtn2.SetSelect(!0),
this.bossBg2.spriteNameSet("ryworldboss_sp_0051")):t==ye.S.VipBoss3&&(this.leftBtn3.SetSelect(!0),this.bossBg2.spriteNameSet("ryworldboss_sp_0052")),this.RefreshBossGrid()}
OnAddClick(t,e){Ce.B.GetInst().AddTimes(this.copyRes.id),this.CheckGuide2()}RefreshBossGrid(){const t=new A.Z,e=this.tModel.vbData
for(const[s,i]of(0,u.V5)(e)){ae.o.Inst().getItemById(i.copyId).controllerType==this.copyType&&t.Add(i)}this.dragAmount=this.tModel.GetCenterRate(),this.showBossList=t}UpdateTip(){
let t=""
const e=this.copyRes.EnterConsumesValue_get()
let s=!1
if(this.costdemand=0,null==e||null!=e.copyResourceAttr&&0==e.copyResourceAttr.Count()||null!=e.copyResourceAttrEX&&0==e.copyResourceAttrEX.Count())t=(0,p.T)("挑 战"),
this.demandicon.SetActive(!1)
else{this.demandicon.SetActive(!0)
const i=e.copyResourceAttrEX[0].value
let n=parseInt(J.M.Split(i,":")[1])
this.costdemand=n
const l=De.J.GetGold(_.Y.Inst.PrimaryRoleInfo_get(),De.J.GOLD_DIAMOND)
t=O.l.Substitute((0,p.T)("挑战（{0}    ）"),new A.Z([n])),n>l&&(t=O.l.Substitute((0,p.T)("挑战（[D43D3D]{0}[-]    ）"),new A.Z([n]))),s=!0}if(this.btnlab.textSet(t),s){
const t=this.demandicon.transform.GetLocalPosition(),e=this.btnlab.width()/2
t.x=e-30,this.demandicon.transform.SetLocalPosition(t)}}UpdateConditionOrRelive(){
const t=_.Y.Inst.IsLevelFix(this.copyRes.GetLvConditionLimit())&&at.U.inst.model.level_get()>=this.copyRes.GetVipLimit()
if(t)this.limitarea.SetActive(!1)
else{this.limitarea.SetActive(!0)
const t=this.copyRes.GetVipLimit(),e=at.U.inst.model.level_get()
let s=J.M.Replace(this.vipLimitTeplate,"{0}",t)
s=t>e?`[ba3f3d]${s}[-]`:`[DEC080]${s}[-]`,this.viplimit.textSet(s)
const i=this.copyRes.GetLvConditionLimit(),n=_.Y.Inst.PrimaryRoleInfo_get().Level_get()
let l=J.M.Replace(this.levelLimitTeplate,"{0}",ft.h.GetLevelStr(i))
l=i>n?`[ba3f3d]${l}[-]`:`[DEC080]${l}[-]`,this.levellimit.textSet(l)}t?(this.UpdateReliveTime(),this.lockarea.SetActive(!1),
this.nameBg.SetLocalPositionXYZ(0,-142.6,0)):(this.nameBg.SetLocalPositionXYZ(0,-161,0),this.relivetime.node.SetActive(!1),this.lockarea.SetActive(!0),this.ClearTimer())}
UpdateReliveTime(){this.ClearTimer(),null!=this.curBossData.info?(this._lefttimeintervalId=ut.C.Inst_get().SetInterval(this.CreateDelegate(this.UpdateTimeHandler),1e3),
this.time=(this.curBossData.info.refreshTime.ToNum()-Vt.D.serverMSTime_get())/1e3+1,this.UpdateTimeHandler()):this.relivetime.textSet(`[047104]${(0,p.T)("已解锁")}[-]`)}ClearTimer(){
ut.C.Inst_get().ClearInterval(this._lefttimeintervalId),this._lefttimeintervalId=-1}UpdateTimeHandler(){if(this.time<=0)return this.relivetime.textSet(`[047104]${(0,
p.T)("已解锁")}[-]`),void this.ClearTimer()
this.time-=1
let t=Ae.x.Inst().getItemStrById(111026)
const e=O.l.GetDateFormat(this.time)
t=J.M.Replace(t,"{0}",e),this.relivetime.textSet(`${O.l.txtRedStr2}${t}[-]`)}SetData(){this.curBossData=this.tModel.GetBossDataById(this.cfg.id_get()),this.UpdateBossView(),
this.UpdateTip(),this.UpdateConditionOrRelive(),this.UpdateDrop(),this.UpdateTimes()}UpdateBossView(t){if(this.copyRes=ae.o.Inst().getItemById(this.cfg.copyid_get()),
null==t&&(t=this.cfg),this.lastMonId!=t.monsterId_get()){this.PlayEffect(),Ie.M.Instance_get().ActiveStage(Me.STAGE_ID)
const e=It.a.getInst().getObjById(t.monsterId_get())
if(null!=e){this.bossName.textSet(`${this.cfg.name_get()} Lv.${e.level}`)
const s=new ue.O
this.ClearBoss(),this.boss=fe.Q.Inst().GetObjectByName("MonsterCharacter",pe._),this.boss.Info_set(s)
const i=new kt.O
i._displayID=e.displayId,i._world=Ie.M.Instance_get().GetStageWorldType(Me.STAGE_ID),i._bNeedWaitAnime=!0,i.shiledType=xt.g.DT_NONE
t.GetPos()
const n=t.GetRotate()
Ie.M.Instance_get().SetWorldRotation(Me.STAGE_ID,0,new v.P(n[0],n[1],n[2])),this.displayUIAvatarModel.SetScale(.8,.8),this.displayUIAvatarModel.SetDir(4),
Et.x.inst.SetUIAvatarData(i,Pt.v.monster,this.displayUIAvatarModel)}}this.lastMonId=t.monsterId_get()}ClearBoss(){null!=this.boss&&(this.boss.Destroy(),this.boss=null)}
PlayEffect(){this.worldBossEffect.SetActive(!1),this.worldBossEffect.SetActive(!0),this.tweenScale.getComponent(me.E).ResetToBeginning(),
this.tweenScale.getComponent(me.E).PlayForward(),this.tweenAlpha.ResetToBeginning(),this.tweenAlpha.PlayForward()}UpdateDrop(){const t=this.tModel.GetRewardLis(this.cfg.id_get())
t.Count()>0?(this.dropObj.SetActive(!0),this.dropGrid.data_set(t)):this.dropObj.SetActive(!1)}UpdateTimes(){
this.totalPassTimes=Te.a.Inst_get().GetCopyFreeNum(this.copyRes.controllerType)||0
let t=""
const e=Te.a.Inst_get().GetCopyRecByKey(this.copyRes.controllerType)
if(null!=e){const s=e.todayBuyTimes
this.totalPassTimes+=s
const i=e.todayEnterHistory
i>=this.totalPassTimes?t+=`[de2524]0/${this.totalPassTimes}[-]`:t+=`${J.M.IntToString(this.totalPassTimes-i)}/${this.totalPassTimes}`}else t+=`0/${this.totalPassTimes}`
this.battleNum.textSet(t)
const s=this.GetCanBuyTimes(this.copyRes.controllerType)
this.addtimesbtn.node.SetActive(0!=s),this.leftBtn1.UpdateRedPoint(i.D.Inst_get().redPointNum1>0),this.leftBtn2.UpdateRedPoint(i.D.Inst_get().redPointNum2>0),
this.leftBtn3.UpdateRedPoint(i.D.Inst_get().redPointNum3>0)}GetCanBuyTimes(t){const e=at.U.inst.model.vipRes_get().vipbossBuy
for(const[s,i]of(0,u.vy)(e))if(i.type==t){const t=i.value
return new A.Z(t).Count()}}SetRedPoint(){i.D.Inst_get().SetRedPoint(),this.leftBtn1.UpdateRedPoint(i.D.Inst_get().redPointNum1>0),
this.leftBtn2.UpdateRedPoint(i.D.Inst_get().redPointNum2>0),this.leftBtn3.UpdateRedPoint(i.D.Inst_get().redPointNum3>0)}OnDragingMoving(){this.DoScroll()}CalcScroll(){
const t=this.bossScrollView.content.transform.GetLocalPosition().y-this.initPosY
return Math.floor((-t+this.itemHeight/2)/this.itemHeight)}OnDragFinished(t){this.selectedIndex=this.CalcScroll(),
this.selectedIndex>this.showBossList.Count()-1&&(this.selectedIndex=this.showBossList.Count()-1),this.selectedIndex<0&&(this.selectedIndex=0),
this.curBossData=this.showBossList[this.selectedIndex],this.tModel.calVBossData=this.curBossData,this.cfg=Tt.C.Inst().GetItemByBossId(this.curBossData.sortId),
g.i.Inst.RaiseEvent(w.g.BOSS_SELECT,this.tModel.calVBossData),this.DoScroll(),this.SetData()}ChangeScrollPosByIndex(t){if(null!=this.bossScrollView){
const e=this.bossScrollView.content.transform.GetLocalPosition()
e.y=this.itemHeight*t,this.bossScrollView.content.SetLocalPositionXYZ(e.x,e.y,e.z),this.DoScroll()}}DoScroll(){
const t=(this.bossScrollView.content.transform.GetLocalPosition().y-this.initPosY)/this.itemHeight,e=this.bossTable.itemList
for(let s=0;s<=e.Count()-1;s++){let i=s-t
if(i<0){i=-i
const t=i-Math.floor(i)
e[s].SetIndex(0,5,t)}else{const t=Math.floor(i),n=i-t,l=t+1
e[s].SetIndex(t,l,n)}}}CostConfirm(){if(nt.V.Inst_get().GetData(nt.V.Inst_get().GetRolePrefix()+"BOSS:PERSONAL_CONFIRM_LEVEL_UP"))this.ReqEnterVipBoss()
else{const t=new b.B
t.infoId="COPY:VIPBOSS_ENTER_TIP",t.replaceParams.Add(this.costdemand),t.replaceParams.Add(this.copyRes.name),t.needCheckBox=!0,
t.checkChanged=this.CreateDelegate(this.NoMentionHandler),t.confirmHandle=this.CreateDelegate(this.ReqEnterVipBoss),M.t.Inst().Open(t)}}GotoVipConfirm(){const t=new b.B
t.infoId="VIPBOSS:VIP_NOTICE",t.replaceParams.Add(this.copyRes.vipLimitMin),t.confirmText="前往激活",t.confirmHandle=this.CreateDelegate(this.GotoVip),M.t.Inst().Open(t)}
NoMentionHandler(t){nt.V.Inst_get().SetData(nt.V.Inst_get().GetRolePrefix()+"BOSS:PERSONAL_CONFIRM_LEVEL_UP",t)}OnReposition(){this.ChangeScrollPosByIndex(this.scrollIndex)}
Clear(){this.boss,this.ClearBoss(),this.lastMonId=null,this.RemoveLis(),this.node.SetActive(!1),super.Clear()}SetColdTimer(){}Destroy(){super.destroy()}Test1(){return!0}S_Test(){
return!0}}Me.STAGE_ID=70
var be=s(70650),Oe=s(9776),Re=s(30267),Le=s(16261),Ge=s(13113),Pe=s(60706),Ee=s(44210),ke=s(90912),Ne=s(47023),Ve=s(33828),xe=s(85942),Fe=s(35042)
class Ue extends oe.C{constructor(){super(),this.bossName=null,this.dropObj=null,this.bossGrid=null,this.bossScrollBar=null,this.dropScrollview=null,this.dropGrid=null,
this.timer=null,this.battleNum=null,this.bossTexture=null,this.lightEff=null,this.tip=null,this.searchForBossBtn=null,this.gotoLabel=null,this.lockSp=null,this.tipLabel=null,
this.addBtn=null,this.battleObj=null,this.bossScrollView=null,this.rTMask=null,this.ExplainTips=null,this.tModel=null,this.copyBaseModel=null,this.dragAmount=0,this.sortId=0,
this.cfgRes=null,this.objRes=null,this.copyRes=null,this.intervalId=-1,this.bossScrollIntervalId=-1,this.totalPassTimes=0,this.coldInterval=-1,this.coldTime=-1,this.diamondNum=0,
this.residueTimer=0,this.serverTime=0,this.waitTime=0,this.boss=null,this.dimandCost=0,this._degf_CheckPosUnlock_VIPBoss=null,this._degf_GotoCopy=null,this._degf_Handle=null,
this._degf_HandleColdTime=null,this._degf_IsClickOk=null,this._degf_OnAddClick=null,this._degf_OnClearColdBtnClick=null,this._degf_OnItemRefreshFun=null,
this._degf_OnRewardRefreshFun=null,this._degf_OnSearchClick=null,this._degf_OnUpdateCopyInfo=null,this._degf_ReqEnterVipBoss=null,this._degf_OnDescTipBtnClick=null,
this._degf_OnBossSelect=null,this.lvlab=null,this.tablel=null,this.roleRotateController=null,this.curBossData=null,this.roleRotateIndex=null,
this._degf_CheckPosUnlock_VIPBoss=t=>this.CheckPosUnlock_VIPBoss(t),this._degf_GotoCopy=t=>this.GotoCopy(t),this._degf_Handle=()=>this.Handle(),
this._degf_HandleColdTime=()=>this.HandleColdTime(),this._degf_IsClickOk=t=>this.IsClickOk(t),this._degf_OnAddClick=(t,e)=>this.OnAddClick(t,e),
this._degf_OnClearColdBtnClick=(t,e)=>this.OnClearColdBtnClick(t,e),this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),
this._degf_OnRewardRefreshFun=t=>this.OnRewardRefreshFun(t),this._degf_OnSearchClick=(t,e)=>this.OnSearchClick(t,e),this._degf_OnUpdateCopyInfo=t=>this.OnUpdateCopyInfo(t),
this._degf_ReqEnterVipBoss=t=>this.ReqEnterVipBoss(t),this._degf_OnDescTipBtnClick=t=>this.OnDescTipBtnClick(t),this._degf_OnBossSelect=t=>this.OnBossSelect(t)}InitView(){
this.bossName=this.CreateComponent(Mt.Q,1),this.dropObj=this.CreateComponent(vt.z,4),this.bossGrid=this.CreateComponent(ne.A,11),this.bossScrollBar=this.CreateComponent(le._,14),
this.dropScrollview=this.CreateComponent(Oe.h,15),this.dropGrid=this.CreateComponent(ne.A,6),this.battleNum=this.CreateComponent(Mt.Q,22),
this.bossTexture=this.CreateComponent(Le.X,33),this.lightEff=this.CreateComponent(vt.z,35),this.tip=this.CreateComponent(vt.z,36),
this.searchForBossBtn=this.CreateComponent(vt.z,37),this.gotoLabel=this.CreateComponent(Mt.Q,38),this.tipLabel=this.CreateComponent(Mt.Q,40),
this.addBtn=this.CreateComponent(vt.z,41),this.battleObj=this.CreateComponent(vt.z,42),this.bossScrollView=this.CreateComponent(Oe.h,43),this.rTMask=this.CreateComponent(vt.z,44),
this.ExplainTips=this.CreateComponentBinder(Pe.M,45),this.lvlab=this.CreateComponent(Mt.Q,46),this.tablel=this.CreateComponent(Re.V,47),
this.roleRotateController=this.CreateComponent(Ge.T,48),this.dropGrid.SetInitInfo("ui_treasure_bossdropitem_big",this._degf_OnRewardRefreshFun),
this.bossGrid.SetInitInfo("ui_treasure_vbossitem",this._degf_OnItemRefreshFun),this.bossGrid.OnReposition_set(this._degf_Handle),this.tModel=ct._.Inst(),
this.copyBaseModel=Te.a.Inst_get()}Clear(){this.bossGrid.Clear(),this.dropGrid.Clear(),this.ClearBoss(),
Ie.M.Instance_get().DeactiveStage(Ue.STAGE_ID,this.bossTexture.FatherId,this.bossTexture.ComponentId),this.rTMask.SetActive(!1),ut.C.Inst_get().ClearInterval(this.intervalId),
ut.C.Inst_get().ClearInterval(this.bossScrollIntervalId),ut.C.Inst_get().ClearInterval(this.coldInterval),this.tModel.hasBossGridRefresh=!1,this.ExplainTips.Clear(),
this.RemoveLis(),this.ClearTimer()}Destroy(){this.dropGrid.Destroy(),this.bossGrid.Destroy(),this.bossName=null,this.dropObj=null,this.bossGrid=null,this.bossScrollBar=null,
this.dropScrollview=null,this.dropGrid=null,this.battleNum=null,this.bossTexture=null,this.lightEff=null,this.tip=null,this.searchForBossBtn=null,this.gotoLabel=null,
this.ExplainTips.Destroy(),this.ExplainTips=null}OnAddToScene(){this.rTMask.SetActive(!0),this.AddLis(),this.tModel.CalFixVipBossSortId(),
null!=this.tModel.calVBossData&&(this.tModel.curVbSortId=this.tModel.calVBossData.sortId),this.tModel.hasBossGridRefresh||(this.RefreshBossGrid(),
this.tModel.hasBossGridRefresh=!0),this.SetData(),this.InitExplainTips()}InitExplainTips(){const t=new mt.w
t.position=new v.P(290,-197,0),t.width=400,t.infoId="BOSS：VIPBOSS",t.anchor=3,this.ExplainTips.SetData(t)}AddLis(){
pt.i.Get(this.searchForBossBtn).RegistonClick(this._degf_OnSearchClick),pt.i.Get(this.addBtn).RegistonClick(this._degf_OnAddClick),
Ee.w.GetInst().AddEventHandler(ke.s.COPY_INFO_UPDATE,this._degf_OnUpdateCopyInfo),g.i.Inst.AddEventHandler(w.g.BOSS_SELECT,this._degf_OnBossSelect)}RemoveLis(){
pt.i.Get(this.searchForBossBtn).RemoveonClick(this._degf_OnSearchClick),pt.i.Get(this.addBtn).RemoveonClick(this._degf_OnAddClick),
Ee.w.GetInst().RemoveEventHandler(ke.s.COPY_INFO_UPDATE,this._degf_OnUpdateCopyInfo),g.i.Inst.RemoveEventHandler(w.g.BOSS_SELECT,this._degf_OnBossSelect)}OnClearColdBtnClick(t,e){
this.ClearCDFunc()}ClearCDFunc(){this.residueTimer*=1e3
const t=this.residueTimer
if(this.residueTimer%6e4==0?this.residueTimer=gt.GF.INT(t/6e4):this.residueTimer=gt.GF.INT(t/6e4)+1,0==this.copyBaseModel.waitTime)return void Z.Y.LogError((0,
p.T)("服务端发的等待时间有问题！"))
const e=gt.GF.INT(this.copyRes.clearCost/(this.copyBaseModel.waitTime/6e4))
this.diamondNum=e*this.residueTimer
const s=Ae.x.Inst().getItemById(Fe.X.ClearCoolTimer),i=J.M.DoubleToString(this.diamondNum),n=new A.Z([i]),l=new xe.N
l.showText=O.l.Substitute(s.sys_messsage,n),l.okhandler=this._degf_IsClickOk,l.tipstype=2,V.y.inst.OpenCommonMessageTips(l)}IsClickOk(t){
ae.o.Inst().getItemById(Te.a.Inst_get().currentCopyId)
if(this.diamondNum>De.J.GetGold(_.Y.Inst.PrimaryRoleInfo_get(),De.J.GOLD_DIAMOND))V.y.inst.closeCommonMessageTips(),Ve.Y.Inst_get().Open()
else{const t=new Ne.t
t.copyId=this.cfgRes.copyid_get(),S.C.Inst.F_SendMsg(t)}}SetColdTimer(){ut.C.Inst_get().ClearInterval(this.coldInterval),this.coldInterval=-1,this.coldTime=-1,
this.SetClearObjActive(!1),ss.inst.updateRedPoint()}OnRewardRefreshFun(t){const e=new $t.j
return e.setId(t,null,0),e}OnItemRefreshFun(t){const e=new Be
return e.setId(t,null,0),e}Handle(){this.tModel.isFirstInVBoss&&(this.tModel.isFirstInVBoss=!1),this.bossScrollView.ResetPosition(),this.bossScrollBar.SetValue(this.dragAmount)}
OnBossItemLoadComplete(){this.intervalId=ut.C.Inst_get().SetInterval(this._degf_Handle,100,1)}RefreshBossGrid(){const t=new A.Z,e=this.tModel.vbData
for(const[s,i]of(0,u.V5)(e))t.Add(i)
this.dragAmount=this.tModel.GetCenterRate(),this.bossGrid.data_set(t)}RefreshDropGrid(){this.dropScrollview.ResetPosition()
const t=this.tModel.GetRewardLis(this.sortId)
t.Count()>0?(this.dropObj.SetActive(!0),this.dropGrid.data_set(t)):this.dropObj.SetActive(!1)}SetData(){this.sortId=this.tModel.curVbSortId,this.RefreshDropGrid(),
this.cfgRes=Tt.C.Inst().getItemById(this.sortId),this.objRes=It.a.getInst().getObjById(this.cfgRes.monsterId_get()),this.copyRes=ae.o.Inst().getItemById(this.cfgRes.copyid_get()),
this.diamondNum=this.copyRes.clearCost,this.bossName.textSet(this.cfgRes.name_get()),this.lvlab.textSet(`(Lv.${this.objRes.level})`),this.InitBossView(this.cfgRes),
this.tip.SetActive(!1),this.tModel.IsFreeForFirstIn(this.tModel.curVbSortId)&&(this.tipLabel.textSet((0,p.T)("首次进入不消耗次数")),this.tip.SetActive(!0)),
this.curBossData=this.tModel.GetBossDataById(this.sortId),this.UpdateTip(),this.tablel.CallReposition(),this.SetPassTime(),this.coldTime=-1,this.UpdateTime()}UpdateTip(){
if(this.tipLabel.textSet(""),this.curBossData.isLocked){let t=Ae.x.Inst().getItemStrById(111031)
_.Y.Inst.IsVipFix(this.copyRes.GetVipLimit())?_.Y.Inst.IsLevelFix(this.copyRes.GetLvConditionLimit())||(t=Ae.x.Inst().getItemStrById(111030)+t):t=Ae.x.Inst().getItemStrById(111029)+t,
this.gotoLabel.textSet(Ae.x.Inst().getItemStrById(111032)),this.tipLabel.textSet(t),re.d.LuaMakeGoGray(this.searchForBossBtn.FatherId,this.searchForBossBtn.ComponentId,!0,!0)
}else this.curBossData.IsCanEnter()?(this.gotoLabel.textSet("立即挑战"),
re.d.LuaMakeGoGray(this.searchForBossBtn.FatherId,this.searchForBossBtn.ComponentId,!1,!0)):(this.gotoLabel.textSet(`前往V${_.Y.Inst.PrimaryRoleInfo_get().VipLevel_get()}专属BOSS`),
re.d.LuaMakeGoGray(this.searchForBossBtn.FatherId,this.searchForBossBtn.ComponentId,!1,!0))}UpdateTime(){this.ClearTimer(),
null!=this.curBossData.info&&this.curBossData.IsVipDie()&&(this.gotoLabel.textSet("暂未复活"),this.coldInterval=ut.C.Inst_get().SetInterval(this._degf_HandleColdTime,1e3),
this.coldTime=(this.curBossData.info.refreshTime.ToNum()-Vt.D.serverMSTime_get())/1e3+1,this.residueTimer=this.coldTime,this.HandleColdTime())}ClearTimer(){
ut.C.Inst_get().ClearInterval(this.coldInterval),this.coldInterval=-1}HandleColdTime(){if(this.coldTime<=0)return this.UpdateTip(),void this.ClearTimer()
this.coldTime-=1,this.residueTimer=this.coldTime
let t=Ae.x.Inst().getItemStrById(111026)
t=J.M.Replace(t,"{0}","")
const e=O.l.GetDateFormat(this.coldTime)
this.tipLabel.textSet(e+t)}SetSelect(){null!=this.tModel.calVBossData&&(this.tModel.curVbSortId=this.tModel.calVBossData.sortId,
g.i.Inst.RaiseEvent(w.g.BOSS_SELECT,this.tModel.calVBossData),this.bossScrollBar.SetValue(this.tModel.GetCenterRate()))}SearchForBoss(){
if(null==this.curBossData)return void V.y.inst.ClientStrMsg(2,(0,p.T)("副本数据异常"))
if(this.tModel.BossLimitHandle(this.cfgRes.copyid_get(),!0))return void this.SetSelect()
const t=this.copyBaseModel.GetCopyRecByKey(ye.S.VipBoss)
null!=t&&(t.todayWinHistory<=this.totalPassTimes?this.coldTime>0?V.y.inst.ClientStrMsg(2,(0,p.T)("副本冷却中，无法挑战！")):this.ReqEnterVipBoss():Ce.B.GetInst().AddTimes(this.copyRes.id))}
OnTipViewSureHandler(t){this.tModel.isShowCommonTip=!t}OnConsumeDiamondOk(t){
De.J.GetGold(_.Y.Inst.PrimaryRoleInfo_get(),De.J.GOLD_DIAMOND)>=this.dimandCost?this.CheckPosUnlock_VIPBoss(this.tModel.GetBossDataById(this.sortId)):Ve.Y.Inst_get().Open()}
ReqEnterVipBoss(){const t=this.cfgRes.copyid_get()
$.p.inst.SendEnterCopy(t)}GotoCopy(t){ss.Inst().Close()}InitBossView(t){Ie.M.Instance_get().ActiveStage(Ue.STAGE_ID)
const e=It.a.getInst().getObjById(t.monsterId_get())
if(null!=e){const s=new ue.O
this.ClearBoss(),this.boss=fe.Q.Inst().GetObjectByName("MonsterCharacter",pe._),this.boss.Info_set(s)
const i=new kt.O
i._displayID=e.displayId,i._world=Ie.M.Instance_get().GetStageWorldType(Ue.STAGE_ID),i._bNeedWaitAnime=!0,i.shiledType=xt.g.DT_NONE
const n=t.GetPos(),l=t.GetRotate()
this.boss.InitPhotoByInfo(e,i,n[1]),Ie.M.Instance_get().SetDisplayObject(Ue.STAGE_ID,this.boss.MainRole_get().handle,0),
Ie.M.Instance_get().SetWorldRotation(Ue.STAGE_ID,0,new v.P(l[0],l[1],l[2])),this.boss.setPosXYZ(n[0],n[1],n[2]),this.boss.SetSize(t.GetScale()),
this.bossTexture.SetMainTextureByPhoto(Ue.STAGE_ID),this.bossTexture.SetUVRect(0,0,1,1),null!=this.roleRotateIndex&&be.e.GetInst().UnregDrag(this.roleRotateIndex),
this.roleRotateIndex=be.e.GetInst().RegDrag(this.roleRotateController.node,this.boss.MainRole_get())}}ClearBoss(){
null!=this.boss&&(null!=this.roleRotateIndex&&(be.e.GetInst().UnregDrag(this.roleRotateIndex),this.roleRotateIndex=null),this.boss.Destroy(),this.boss=null)}OnSearchClick(t,e){
null!=Qt.W.inst_get().view||H.B.Inst.isOpenMaskStart||this.SearchForBoss()}OnAddClick(t,e){Ce.B.GetInst().AddTimes(this.copyRes.id)}OnUpdateCopyInfo(t){this.SetPassTime()}
SetPassTime(){this.totalPassTimes=this.copyBaseModel.GetCopyFreeNum(ye.S.VipBoss)
let t=""
const e=this.copyBaseModel.GetCopyRecByKey(ye.S.VipBoss)
if(null!=e){const s=e.todayBuyTimes
this.totalPassTimes+=s
const i=e.todayWinHistory
i>=this.totalPassTimes?t+=`[de2524]0/${this.totalPassTimes}[-]`:t+=`${J.M.IntToString(this.totalPassTimes-i)}/${this.totalPassTimes}`}else t+=`0/${this.totalPassTimes}`
this.battleNum.textSet(t)}OnBossSelect(t){const e=t
this.tModel.curVbSortId=e.sortId,this.SetData()}}Ue.STAGE_ID=70
var He,je,We,Ye,qe,ze,Ze,Xe,Qe,Je,$e,Ke=s(66696),ts=s(33065)
function es(t,e,s,i,n){var l={}
return Object.keys(i).forEach((function(t){l[t]=i[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=s.slice().reverse().reduce((function(s,i){return i(t,e,s)||s}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let ss=(He=(0,h.GH)(G.k.SM_BossDead),je=(0,h.GH)(G.k.SM_BossInfoUpdate),We=(0,h.GH)(G.k.SM_WorldBossQueryPlayerNum),
Ye=(0,h.GH)(G.k.SM_RemoveBossDamageRank),qe=(0,h.GH)(G.k.SM_BossInfo),ze=(0,h.GH)(G.k.SM_RareDropHistories),Ze=(0,h.GH)(G.k.SM_BossAttention),Xe=(0,
h.GH)(G.k.SM_BossRefreshForecast),Qe=(0,h.GH)(G.k.SM_BossTiredUpdate),$e=class t{static get inst(){return t._inst||(t._inst=new t),t._inst}get treasurePanel(){return(0,
d.Y)(T.I.TreasurePanel)}get dropView(){return this._dropView=(0,d.Y)(T.I.BossDropPanel),this._dropView}constructor(){this.topUseDefaultTab=!1,this.extraRewardInfo=null,
this.isWaitingChangeLine=!1,this.wbView=null,this.wbViewContainer=null,this.nbView=null,this.nbViewContainer=null,this.vbView=null,this.vbViewContainer=null,this.abView=null,
this.abViewContainer=null,this._dropView=null,this.karimaView=null,this.vipView=null,this.vipViewContainer=null,this._degf_CallDestory=null,this._degf_CallInfoDestroy=null,
this._degf_CallTipDestory=null,this._degf_FindWayAfterChangeLine=null,this._degf_LeaveMiracleMainLandReq=null,this._degf_LoadAbViewComplete=null,this._degf_LoadNbViewComplete=null,
this._degf_LoadVbViewComplete=null,this._degf_LoadWbViewComplete=null,this._degf_OnArriveBoss=null,this._degf_OnArriveFightPos=null,this._degf_SM_BossAttentionHandle=null,
this._degf_SM_BossInfoHandle=null,this._degf_SM_BossDeadHandle=null,this._degf_SM_BossInfoUpdateHandle=null,this._degf_SM_WorldBossQueryPlayerNumHandle=null,
this._degf_SM_RemoveBossDamageRankHandle=null,this._degf_SM_BossRefreshForecastHandle=null,this._degf_SM_KarimaCursePointHandler=null,this._degf_SM_KarimaInfoHandler=null,
this._degf_SM_LeaveKarimaHandler=null,this._degf_SM_RareDropHistoriesHandle=null,this._degf_SM_SelectBossHandler=null,this._degf_ShowHandler=null,this._degf_ShowInfoHandler=null,
this._degf_ShowTipHandler=null,this._degf_updateRedPoint=null,this._degf_SM_BossTiredUpdateHandler=null,this.wbViewShow=null,this.abViewShow=null,this.karimaViewShow=null,
this.karimaViewContainer=null,this.vipViewShow=null,this._degf_CallDestory=()=>this.CallDestory(),this._degf_CallInfoDestroy=()=>this.CallInfoDestroy(),
this._degf_FindWayAfterChangeLine=t=>this.FindWayAfterChangeLine(t),this._degf_LeaveMiracleMainLandReq=t=>this.LeaveMiracleMainLandReq(t),
this._degf_LoadAbViewComplete=t=>this.LoadAbViewComplete(t),this._degf_LoadNbViewComplete=t=>this.LoadNbViewComplete(t),this._degf_LoadVbViewComplete=t=>this.LoadVbViewComplete(t),
this._degf_LoadWbViewComplete=t=>this.LoadWbViewComplete(t),this._degf_OnArriveBoss=t=>this.OnArriveBoss(t),this._degf_OnArriveFightPos=t=>this.OnArriveFightPos(t),
this._degf_SM_BossAttentionHandle=t=>this.SM_BossAttentionHandle(t),this._degf_SM_BossInfoHandle=t=>this.SM_BossInfoHandle(t),
this._degf_SM_BossDeadHandle=t=>this.SM_BossDeadHandle(t),this._degf_SM_BossInfoUpdateHandle=t=>this.SM_BossInfoUpdateHandle(t),
this._degf_SM_WorldBossQueryPlayerNumHandle=t=>this.SM_WorldBossQueryPlayerNumHandle(t),this._degf_SM_RemoveBossDamageRankHandle=t=>this.SM_RemoveBossDamageRankHandle(t),
this._degf_SM_BossRefreshForecastHandle=t=>this.SM_BossRefreshForecastHandle(t),this._degf_SM_KarimaCursePointHandler=t=>this.SM_KarimaCursePointHandler(t),
this._degf_SM_KarimaInfoHandler=t=>this.SM_KarimaInfoHandler(t),this._degf_SM_LeaveKarimaHandler=t=>this.SM_LeaveKarimaHandler(t),
this._degf_SM_RareDropHistoriesHandle=t=>this.SM_RareDropHistoriesHandle(t),this._degf_SM_SelectBossHandler=t=>this.SM_SelectBossHandler(t),
this._degf_ShowHandler=t=>this.ShowHandler(t),this._degf_ShowInfoHandler=t=>this.ShowInfoHandler(t),this._degf_updateRedPoint=()=>this.updateRedPoint(),
this._degf_SM_BossTiredUpdateHandler=t=>this.SM_BossTiredUpdateHandler(t),this.AddLis()}static Inst(){return t.inst}DefaultOpen(){if(this.topUseDefaultTab=!0,
R.P.Inst_get().IsFunctionOpened(L.x.BOSS)){const t=new f.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!1,C.N.inst.OpenById(T.I.TreasurePanel,this._degf_ShowHandler,this._degf_CallDestory,t)}else O.l.SetFunctionTip(L.x.BOSS)}
OpenById(t){if(null==t&&(t=0),ct._.Inst().settingSortId=t,0==t)return void this.DefaultOpen()
const e=Tt.C.Inst().getItemById(t)
if(e.type_get()==ht.l.ANCIENTBOSS){const t=U.p.Inst_get().GetMapById(e.mapId_get())
if(null!=t&&ot.F.getInst().GetCanEnterMapByLvAndTransfer(e.mapId_get())!=F.f.CAN){const e=B.Z.GetJobNameByTransfor(t.transferJobLimitLevel),s=new A.Z([e,t.name])
return void V.y.inst.ClientSysMessage(111014,s)}}ct._.Inst().viewType=e.type_get()
const s=this.GetFuncIdByViewType(ct._.Inst().viewType)
if(R.P.Inst_get().IsFuncOrActivityOpened(s)||-1==s){if(null!=this.treasurePanel)return void this.treasurePanel.OnAddToScene()
const t=new f.v
t.layerType=y.F.Alert,t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!1,C.N.inst.OpenById(T.I.TreasurePanel,this._degf_ShowHandler,this._degf_CallDestory,t)
}else O.l.SetFunctionTip(s)}OpenByType(t,e=null){null==e&&(e=0)
const s=this.GetFuncIdByViewType(t)
if(R.P.Inst_get().IsFuncOrActivityOpened(s)||-1==s){if(ct._.Inst().viewType=t,ct._.Inst().settingSortId=e,null!=this.treasurePanel)return void this.treasurePanel.OnAddToScene()
const s=new f.v
s.isShowMask=!0,s.isDefaultUITween=!0,s.isSelfTween=!1,C.N.inst.OpenById(T.I.TreasurePanel,this._degf_ShowHandler,this._degf_CallDestory,s)}else O.l.SetFunctionTip(s)}
OpenByMonsterId(t){const e=Tt.C.Inst().GetItemByMonsterId(t)
null!=e?this.OpenById(e.id_get()):Z.Y.LogError((0,p.T)("BOSS表中找不到对应monsterId的条目"))}GetFuncIdByViewType(t){
return t==ht.l.WORLDBOSS?L.x.WORLD_BOSS:t==ht.l.NEUTROLBOSS?L.x.NEUTROL_BOSS:t==ht.l.VIPBOSS?L.x.PERSONAL_BOSS:t==ht.l.KARIMABOSS?L.x.KARIMA:t==ht.l.ANCIENTBOSS?L.x.ANCIENT_BOSS:L.x.BOSS
}Close(){(0,d.sR)(T.I.TreasurePanel),this.CloseDropView(),V.y.inst.closeCommonMessageTips()}ShowHandler(t){return this.treasurePanel}CallDestory(){}OpenRewardInfo(){
if(null==this.extraRewardInfo||!this.extraRewardInfo.isShow_get()){const t=new f.v
t.layerType=y.F.Alert,t.isShowMask=!0,t.isDefaultUITween=!0,C.N.inst.OpenById(T.I.WorldBossExtraRewardPanel,this._degf_ShowInfoHandler,this._degf_CallInfoDestroy,t)}}
ShowInfoHandler(t){return null==this.extraRewardInfo&&(this.extraRewardInfo=new Ke.Y,this.extraRewardInfo.setId(t,null,0)),this.extraRewardInfo}CallInfoDestroy(){
X.g.DestroyUIObj(this.extraRewardInfo),this.extraRewardInfo=null}CloseRewardInfo(){C.N.inst.CloseById(T.I.WorldBossExtraRewardPanel),D.J.Inst_get().CloseTipView()}AddLis(){
g.i.Inst.AddEventHandler(w.g.CHANGE_LINE,this._degf_FindWayAfterChangeLine),g.i.Inst.AddEventHandler(w.g.FUNCTION_OPEN,(0,I.v)(this.FunctionOpenHandler,this)),
g.i.Inst.AddEventHandler(w.g.PLAYER_LEVELUP,(0,I.v)(this.LevelUpHandler,this)),g.i.Inst.AddEventHandler(w.g.VIP_UPDATE,(0,I.v)(this.VipUpHandler,this))}CM_WorldBossSettleNow(){
const t=new N.U
S.C.Inst.F_SendMsg(t)}SM_BossDeadHandle(t){if(null!=this.treasurePanel){const t=new P.M
S.C.Inst.F_SendMsg(t)}}SM_BossInfoUpdateHandle(t){if(null==t.bossInfo)return
const e=m.R.serverMSTime_get()
t.bossInfo.refreshTime.ToNum()<e?c.s.Info(`SM_BossInfoUpdate, refreshTime = ${t.bossInfo.refreshTime.ToString()}, serverMSTime = ${e}, refreshTime < serverMSTime`):c.s.Info(`SM_BossInfoUpdate, refreshTime = ${t.bossInfo.refreshTime.ToString()}, serverMSTime = ${e}, refreshTime >= serverMSTime`)
ct._.Inst().UpdateOneBossInfo(t)
const s=ts.x.Inst_get()
null!=s&&null!=s.memberDmgView&&s.memberDmgView.RefreshBossListItem()}CM_WorldBossQueryPlayerNum(t){const e=new k.r
e.bossId=t,S.C.Inst.F_SendMsg(e)}SM_WorldBossQueryPlayerNumHandle(t){ct._.Inst().worldBossPlayerNum=t.num,g.i.Inst.RaiseEvent(w.g.UPDATE_BOSS_PLAYERNUM)}
SM_RemoveBossDamageRankHandle(t){if(rt.D.Inst_get().ClearCurBossId(),!$.p.inst.IsInCopy()){null!=rt.D.Inst_get().encourageBossId&&(rt.D.Inst_get().encourageMap=null)
z.b.Inst.GetCurMap().controllerType==q.N.BATTLEFIELD&&(tt.y.Inst.UpdateBtns(z.b.Inst.currentMapId_get(),!0),it.n.inst.CloseCopyInspireView(),
ts.x.Inst_get().ResetFocusBossListView(),ts.x.Inst_get().OpenMemberDmgView(!0)),null==rt.D.Inst_get().assistedId&&ts.x.Inst_get().CloseAssistDamage()}}SM_BossInfoHandle(t){
const e=ct._.Inst()
e.AllBossInfo_set(t.bossInfos),e.SetAttentionLis(t.attentions),e.SetVipBossPassRecord(t.vipBossPassRecord),e.SetEnterLis(t.hadEnterBossId),e.SetFightingLis(t.fightingBossIds),
e.CheckWbRedPoint(),this.treasurePanel&&(0==e.settingSortId?this.treasurePanel.BossInfoHandle():this.treasurePanel.BossInfoHandleBySetting()),
e.isBossAttentionReq&&null!=e.refreshInfo&&(e.isBossAttentionReq=!1,x.N.Inst_get().BossRefreshTipEnQueue(ct._.Inst().refreshInfo.bossId))}FunctionOpenHandler(t){
if(t==L.x.WORLD_BOSS){ct._.Inst().CheckWbRedPoint()}else t==L.x.PERSONAL_BOSS&&i.D.Inst_get().SetRedPoint()}LevelUpHandler(){ct._.Inst().CheckWbRedPoint()}VipUpHandler(){
i.D.Inst_get().SetRedPoint(),ct._.Inst().CheckWbMultipleRedPoint(),n.x.getInstance().CheckKarimaMultipleRedPoint()}SM_RareDropHistoriesHandle(t){ct._.Inst().dropMsg=t
let e=this.dropView
null!=e&&e.node&&e.DropInfoHandle()}SM_BossAttentionHandle(t){if(ct._.Inst().UpdateAttention(t),1==t.type){const t=new b.B
t.infoId="BOSS:ATTENTION_NOTICE",t.tipstype=1,M.t.Inst().Open(t)}g.i.Inst.RaiseEvent(w.g.UPDATE_ATTENTION)}SM_BossRefreshForecastHandle(t){ct._.Inst().isBossAttentionReq=!0,
ct._.Inst().refreshInfo=t
ct._.Inst()
if(z.b.Inst.GetCurMap().hideElementsList.Contains(Q.p.BOSSTIPFATHER))return void(ct._.Inst().isBossAttentionReq=!1)
const e=new P.M
S.C.Inst.F_SendMsg(e)}SM_KarimaCursePointHandler(t){}SM_KarimaInfoHandler(t){}SM_LeaveKarimaHandler(t){}GetMainPanelId(){return 0}SearchForBoss(t){
t==ht.l.WORLDBOSS?null!=this.wbView&&this.wbView.SearchForBoss():t==ht.l.NEUTROLBOSS?null!=this.nbView&&this.nbView.SearchForBoss():t==ht.l.VIPBOSS?null!=this.vbView&&this.vbView.SearchForBoss():t==ht.l.ANCIENTBOSS&&null!=this.abView&&this.abView.SearchForBoss()
}Transport(e,s){let i=!1
null!=s&&(i=s.type==ht.l.WORLDBOSS),ct._.Inst().searchBossId=e
const n=Tt.C.Inst().getItemById(e)
let l=i&&n.normalMapId_get()||n.mapId_get()
0==l&&(l=n.mapId_get())
const o=U.p.Inst_get().GetMapById(l),a=v.P.zero_get()
_.Y.Inst.PrimaryRole_get().GetCurPos(a)
let r=null
if(null!=s&&(i||s.type==ht.l.ANCIENTBOSS)){
1==at.U.inst.model.GetPanelResVO(at.U.inst.model.level_get()).res.bossTransfer&&(r=et.e.Inst_get().GetCfgByMonsterIdAndType(3,s.monsterId))}
null==r&&(r=n.NearPos_get()>0?et.e.Inst_get().GetCfgById(n.NearPos_get()):et.e.Inst_get().GetCfgByFixShoesBeeline(l,n.x_get(),n.y_get()))
const h=new v.P(n.x_get(),a.y,n.y_get())
if(o.id==z.b.Inst.currentMapId_get()){const t=v.P.Distance(a,h)
let s=1e3,i=0
null!=r&&(s=v.P.Distance(h,new v.P(r.targetX,a.y,r.targetY)),i=v.P.Distance(a,new v.P(r.targetX,a.y,r.targetY))),
t>s&&i>ct._.Inst().FindRoadDistance_get()&&null!=r?(ct._.Inst().isSearch=!0,H.B.Inst.OpenTransportMask(H.B.TYPE_FLY,r.id)):this.FindWay(e)
}else _.Y.Inst.PrimaryRole_get().StopPathWithOutNoticeServer(),ct._.Inst().isSearch=!0,null!=r?H.B.Inst.OpenTransportMask(H.B.TYPE_FLY,r.id):H.B.Inst.RequestCM_WorldTransport(l)
C.N.inst.CloseAllExclusivePanel(),t.Inst().Close()}OnTransportFinished(){ct._.Inst().isSearch=!1,this.FindWay(ct._.Inst().searchBossId)}FindWay(t){ct._.Inst().searchBossId=t
const e=Tt.C.Inst().getItemById(t)
if(e.switchedLine_get()&&1!=_.Y.Inst.PrimaryRoleInfo_get().CurLine_get())lt.X.inst.changeLine(1,null),this.isWaitingChangeLine=!0
else{W._.getInst().endHang(),Y.S.getInst().ClearLastAttackTarget()
const t=new v.P(e.x_get(),0,e.y_get())
e.type_get(),ht.l.WORLDBOSS,_.Y.Inst.PrimaryRole_get().gotoPoint(t,j.m.eRole,this._degf_OnArriveBoss,null,0,K.I.responseRadius)}}FindWayAfterChangeLine(t){
if(this.isWaitingChangeLine){W._.getInst().endHang()
const t=Tt.C.Inst().getItemById(ct._.Inst().searchBossId),e=new v.P(t.x_get(),0,t.y_get())
_.Y.Inst.PrimaryRole_get().gotoPoint(e,j.m.eRole,this._degf_OnArriveBoss,null,0,K.I.responseRadius)}}OnArriveBoss(t){const e=Tt.C.Inst().getItemById(ct._.Inst().searchBossId)
null!=e&&1==e.autoHang_get()&&W._.getInst().startHang()}OnArriveFightPos(t){W._.getInst().startHang()}updateRedPoint(){}IsInWorldBossCopy(){
const t=U.p.Inst_get().GetMapById(z.b.Inst.currentMapId_get())
return t.controllerType==q.N.WORLD_BOSS||t.controllerType==q.N.WORLD_BOSS_NEWHAND}CheckVipBoss(t){const e=ct._.Inst().VipBossInfo,s=ct._.Inst().vbBossState
let i=0,n=0
for(const[t,s]of(0,u.vy)(e))i+=1
for(const[t,e]of(0,u.vy)(s))n+=1
0!=i&&0==n&&ct._.Inst().UpdateVipBossSelectId()
let l=!1
for(const[t,e]of(0,u.V5)(s))if(1==e){l=!0
break}return l}InitWbViewData(t){if(this.wbViewShow=!0,null==this.wbView){this.wbViewContainer=t
const e=a.o.getPrefab("ui_treasure_wbview_ry")
this.LoadWbViewComplete((0,o.instantiate)(e))}else this.wbView.OnAddToScene()}LoadWbViewComplete(t){this.wbView=t.getCNode(ee),this.wbView.node.setParent(this.wbViewContainer),
this.wbViewShow?this.wbView.OnAddToScene():this.wbView.SetActive(!1)}ClearWbViewData(){this.wbViewShow=!1,null!=this.wbView&&this.wbView.SetActive(!1)}DestroyWbView(){
null!=this.wbView&&(this.wbView.Destroy(),this.wbView=null)}InitNbViewData(t){null==this.nbView?(this.nbViewContainer=t,
X.g.LoadOne("ui_treasure_neutrolbossview",this._degf_LoadNbViewComplete)):this.nbView.OnAddToScene()}LoadNbViewComplete(t){const e=t[0]
this.nbView=new ce,this.nbView.setId(e,null,0),this.nbView.node.transform.SetParent(this.nbViewContainer.FatherId,this.nbViewContainer.ComponentId),
C.N.inst.SetChildDepth(this.GetMainPanelId(),e),this.nbView.OnAddToScene()}ClearNbViewData(){null!=this.nbView&&this.nbView.Clear()}DestroyNbView(){
null!=this.nbView?(this.nbView.Clear(),this.nbView.Destroy(),X.g.DestroyUIObj(this.nbView),this.nbView=null):X.g.Unload(this._degf_LoadNbViewComplete)}InitVbViewData(t){
null==this.vbView?(this.vbViewContainer=t,X.g.LoadOne("ui_treasure_vbview",this._degf_LoadVbViewComplete)):this.vbView.OnAddToScene()}LoadVbViewComplete(t){const e=t[0]
this.vbView=new Ue,this.vbView.setId(e,null,0),this.vbView.node.transform.SetParent(this.vbViewContainer.FatherId,this.vbViewContainer.ComponentId),
C.N.inst.SetChildDepth(this.GetMainPanelId(),e),this.vbView.OnAddToScene()}ClearVbViewData(){null!=this.vbView&&this.vbView.Clear()}DestroyVbView(){
null!=this.vbView?(this.vbView.Clear(),this.vbView.Destroy(),X.g.DestroyUIObj(this.vbView),this.vbView=null):X.g.Unload(this._degf_LoadVbViewComplete)}InitAbViewData(t){
if(this.abViewShow=!0,null==this.abView){this.abViewContainer=t
const e=a.o.getPrefab("ui_treasure_wbview_ry")
this.LoadAbViewComplete((0,o.instantiate)(e))}else this.abView.OnAddToScene()}LoadAbViewComplete(t){this.abView=t.getCNode(se),this.abView.node.setParent(this.abViewContainer),
this.abViewShow?this.abView.OnAddToScene():this.abView.node.SetActive(!1)}ClearAbViewData(){this.abViewShow=!1,null!=this.abView&&this.abView.node.SetActive(!1)}DestroyAbView(){
null!=this.abView&&(this.abView.Destroy(),this.abView=null)}InitKarimaViewData(t){if(this.karimaViewShow=!0,null==this.karimaView){this.karimaViewContainer=t
const e=a.o.getPrefab("ui_treasure_karima_ry")
this.LoadKarimaComplete((0,o.instantiate)(e))}else this.karimaView.OnAddToScene()}LoadKarimaComplete(t){this.karimaView=t.getCNode(l.L),
this.karimaView.node.setParent(this.karimaViewContainer),this.karimaViewShow?this.karimaView.OnAddToScene():this.karimaView.SetActive(!1)}ClearKarimaData(){this.karimaViewShow=!1,
this.karimaView&&this.karimaView.Clear()}DestroyKarimaView(){null!=this.karimaView&&(this.karimaView=null)}InitVipViewData(t){if(this.vipViewShow=!0,null==this.vipView){
this.vipViewContainer=t
const e=a.o.getPrefab("ui_treasure_dunview_ry")
this.LoadVipViewComplete((0,o.instantiate)(e))}else this.vipView.OnAddToScene()}LoadVipViewComplete(t){this.vipView=t.getCNode(Me),
this.vipView.node.setParent(this.vipViewContainer),this.vipViewShow?this.vipView.OnAddToScene():this.vipView.SetActive(!1)}ClearVipData(){this.vipViewShow=!1,
this.vipView&&this.vipView.Clear()}DestroyVipView(){this.vipViewShow=!1,null!=this.vipView&&(this.vipView=null)}OpenDropTip(){const t=new f.v
t.layerType=y.F.Alert,t.isShowMask=!0,(0,d.Yp)(T.I.BossDropPanel,t)}SendMsgSortId(){}SM_SelectBossHandler(t){}SM_BossTiredUpdateHandler(t){for(const[e,s]of(0,
u.V5)(t.bossTiredInfoVos))s.type==dt.K.WORLDBOSS?ct._.Inst().BossTiredInfo_set(s):s.type==dt.K.ANCIENTBOSS?ct._.Inst().AncientBossTired_set(s):s.type==dt.K.CROSSBOSS&&ct._.Inst().CrossBossTired_set(s)
}CloseForCleanData(){C.N.inst.CloseById(T.I.TreasurePanel),this.CloseDropView(),V.y.inst.closeCommonMessageTips()}CloseDropView(){(0,d.sR)(T.I.BossDropPanel)}OpenExitABossLand(t){
const e="BOSS:BATTLEFIELD_QUIT"
if(nt.V.Inst_get().GetData(nt.V.Inst_get().GetRolePrefix()+e)||t)this.LeaveMiracleMainLandReq(null)
else{const t=new b.B
t.infoId=e,t.confirmHandle=this._degf_LeaveMiracleMainLandReq,M.t.Inst().Open(t)}}LeaveMiracleMainLandReq(t){const e=new E.H
S.C.Inst.F_SendMsg(e)}BossInfoReq(){const t=new P.M
S.C.Inst.F_SendMsg(t)}CanChallengeAB(t){const e=Tt.C.Inst().getItemById(t)
if(e){if(null!=U.p.Inst_get().GetMapById(e.mapId_get())&&ot.F.getInst().GetCanEnterMapByLvAndTransfer(e.mapId_get())==F.f.CAN)return!0}return!1}TransportForSpawnGroup(t){
const e=st.h.GetInst().GetSpwanItemById(t),s=J.M.String2Int(e.mapId),i=U.p.Inst_get().GetMapById(s),n=v.P.zero_get()
_.Y.Inst.PrimaryRole_get().GetCurPos(n),i.id==z.b.Inst.currentMapId_get()?this.FindWayForSpawnGroup(t):(ct._.Inst().searchSpawnId=t,
_.Y.Inst.PrimaryRole_get().StopPathWithOutNoticeServer(),H.B.Inst.RequestCM_WorldTransport(s))}OnTransportFinishedForSpawnGroup(){
this.FindWayForSpawnGroup(ct._.Inst().searchSpawnId),ct._.Inst().searchSpawnId=0}FindWayForSpawnGroup(t){W._.getInst().endHang(),Y.S.getInst().ClearLastAttackTarget()
const e=st.h.GetInst().GetSpwanItemById(t),s=new v.P(e.x,0,e.y)
_.Y.Inst.PrimaryRole_get().gotoPoint(s,j.m.eRole,(0,I.v)(this.OnArriveSpawnGroup,this),null,0,K.I.responseRadius)}OnArriveSpawnGroup(){W._.getInst().startHang()}},$e._inst=null,
es(Je=$e,"inst",[r.n],Object.getOwnPropertyDescriptor(Je,"inst"),Je),
es(Je.prototype,"SM_BossDeadHandle",[He],Object.getOwnPropertyDescriptor(Je.prototype,"SM_BossDeadHandle"),Je.prototype),
es(Je.prototype,"SM_BossInfoUpdateHandle",[je],Object.getOwnPropertyDescriptor(Je.prototype,"SM_BossInfoUpdateHandle"),Je.prototype),
es(Je.prototype,"SM_WorldBossQueryPlayerNumHandle",[We],Object.getOwnPropertyDescriptor(Je.prototype,"SM_WorldBossQueryPlayerNumHandle"),Je.prototype),
es(Je.prototype,"SM_RemoveBossDamageRankHandle",[Ye],Object.getOwnPropertyDescriptor(Je.prototype,"SM_RemoveBossDamageRankHandle"),Je.prototype),
es(Je.prototype,"SM_BossInfoHandle",[qe],Object.getOwnPropertyDescriptor(Je.prototype,"SM_BossInfoHandle"),Je.prototype),
es(Je.prototype,"SM_RareDropHistoriesHandle",[ze],Object.getOwnPropertyDescriptor(Je.prototype,"SM_RareDropHistoriesHandle"),Je.prototype),
es(Je.prototype,"SM_BossAttentionHandle",[Ze],Object.getOwnPropertyDescriptor(Je.prototype,"SM_BossAttentionHandle"),Je.prototype),
es(Je.prototype,"SM_BossRefreshForecastHandle",[Xe],Object.getOwnPropertyDescriptor(Je.prototype,"SM_BossRefreshForecastHandle"),Je.prototype),
es(Je.prototype,"SM_BossTiredUpdateHandler",[Qe],Object.getOwnPropertyDescriptor(Je.prototype,"SM_BossTiredUpdateHandler"),Je.prototype),Je)},29756:(t,e,s)=>{s.d(e,{f:()=>a})
var i=s(86133),n=s(62370),l=s(64444),o=s(47786)
class a{constructor(){this.state=1,this.content="",this.contentState=-1,this.parent=null}getContent(){
return(-1==this.contentState||this.state!=this.contentState)&&(this.content=a.getText(this.parent),this.contentState=this.state),this.content}IsOutofData(){return 2==this.state}
static getText(t){const e=o.x.Inst().getItemById(t.i18info.i18nId).sys_messsage,s=n.o.NumToString(l.B.BOSS_ASSIST,0)
let a=""
a=t.getAssistLink().IsOutofData()?`[url=${s+(0,i.T)("][047104][立即前往][-][/url]")}`:`[url=${s+(0,i.T)("][8E8279][已过期][-][/url]")}`
return e+a}}},35216:(t,e,s)=>{s.d(e,{C:()=>i})
class i{constructor(){this.sendPlayerName=null,this.bossName=null,this.bossLevel=0,this.friPoint=0,this.bossRecommPower=null,this.playerId=null,this.bossId=null,this.bossKey=0,
this.assistCfgId=0,this.assistId=0,this.account=null}parseFromChat(t){}}},20193:(t,e,s)=>{s.d(e,{D:()=>S})
var i=s(93984),n=s(38836),l=s(98800),o=s(97461),a=s(38935),r=s(95721),h=s(55360),d=s(98130),c=s(98885),I=s(85602),u=s(38962),p=s(92679),_=s(87923),g=s(45136)
class m{constructor(t,e){this.dmgType=0,this.vo=null,this.index=0,this.coulddrag=!1,this.dmgType=t,this.vo=e}CopyData(){const t=new m
return t.dmgType=this.dmgType,t.vo=this.vo,t}}class S{constructor(){this.bossId=null,this.teamRankData=null,this.assistRankData=null,this.myDamage=null,this.myDamageRank=0,
this.assistedId=null,this.friendCount=0,this.assistMsgInfo=null,this.assistedState=!1,this.assistPersonInfo=null,this.assistMap=null,this.rewards=null,this.hasRush=!1,
this.dropVecList=null,this.assistvo=null,this.assistsuccdata=null,this.assisttbossKey=0,this.asuramAssistData=null,this.attackRoleAfterPkModelChange=!1,this.blockdamagelist=!1,
this.isHideAssistHeadIcon=!1,this.predictRank=0,this.fightTime=0,this.deadTime=0,this.encourageTypeTimes=null,this.encourageMap=null,this.encourageBossId=null,
this.bossEncourageMap=null,this.teamRankData=new I.Z,this.assistRankData=new I.Z,this.myDamage=r.o.New(),this.assistMap=new u.X,this.dropVecList=new I.Z}static Inst_get(){
return null==S.inst&&(S.inst=new S),S.inst}GetTeamRankData(){return this.teamRankData}ClearTeamRankData(){null!=this.teamRankData&&this.teamRankData.Clear(),this.myDamage=null}
GetAssistRankData(){return this.assistRankData}UpdateTeamRankData(t){this.teamRankData=new I.Z
l.Y.Inst.PrimaryRoleInfo_get()
if(this.assistPersonInfo=null,this.myDamage=null,this.myDamageRank=0,this.predictRank=t.predickRank,null!=t.records&&t.records.Count()>0){const e=this.DamageSort(t.records)
let s=0
for(;s<e.Count();){const t=new m(1,e[s])
t.index=s,this.teamRankData.Add(t),this.isAssistOther()&&t.vo.id.Equal(this.assistedId)&&(this.assistPersonInfo=t),
0==this.myDamageRank&&l.Y.Inst.IsMultiPlayer(t.vo.id)&&(this.myDamageRank=s+1),s+=1}this.myDamage=t.meDamage}if(this.assistRankData=new I.Z,
null!=t.assistDamages&&t.assistDamages.Count()>0){const e=2,s=this.DamageSort(t.assistDamages)
let i=0
for(;i<s.Count();){const t=new m(e,s[i])
t.index=i,this.assistRankData.Add(t),i+=1}}}GetFirstOneDamage(){if(this.teamRankData.Count()>0){return this.teamRankData[0].vo.damage.ToNum()}return 0}GetAssistFirstOneDamage(){
if(null!=this.assistRankData&&this.assistRankData.Count()>0){return this.assistRankData[0].vo.damage.ToNum()}return 0}UpdateMemberRankData(t){}DamageSort(t){let e=0
for(;e<t.Count()-1;){let s=e+1
for(;s<t.Count();){if(t[e].damage.ToNum()<=t[s].damage.ToNum()){const i=t[e]
t[e]=t[s],t[s]=i}s+=1}e+=1}return t}GetMostDmgIndex(t){let e=0,s=0
for(;s<t.Count();)t[s].damage.ToNum()>t[e].damage.ToNum()&&(e=s),s+=1
return e}GetDamagePersonNum(t){let e=0,s=0
for(;s<t.Count();)t[s].damage.ToNum()>0&&(e+=1),s+=1
return e}ShowDamageRank(){const t=ConfigManager.getInstance().getContent("BOSS:DPSRANKMAP").getContent().stringVal,e=c.M.Split(t,c.M.s_SPAN_CHAR),s=new I.Z
let i=0
for(;i<e.count;){const t=c.M.String2Int(e[i])
s.Add(t),i+=1}return s.IndexOf(GameMapManager.Inst.currentMapId_get(),0)>=0}GetDamageStr(t){let e=""
return e=t.ToNum()>1e5?d.GF.INT(t.ToNum()/1e4)+gettextRy("万"):_.l.GetLusuoLongStr(t,1),e}ResetModel(){this.bossId=null,this.assistedId=null,this.assistMap.LuaDic_Clear(),
this.assistedState=!1,this.assistPersonInfo=null,this.encourageTypeTimes=null,this.encourageMap=null,this.encourageBossId=null,this.dropVecList.Clear(),this.fightTime=0,
this.deadTime=0}isInAssistState(){return!!this.SomeoneAssistMe()||!!this.isAssistOther()}isAssistOther(){return null!=this.assistedId&&0!=this.assistedId.ToNum()}MeAssistHe(t){
return null!=this.assistedId&&0!=this.assistedId.ToNum()&&!!this.assistedId.Equal(t)}SomeoneAssistMe(){return this.assistedState}AssistMe(t){
if(l.Y.Inst.PrimaryRoleInfo_get().Id_get().Equal(t))return Debuger.LogError("error self could not assist herself"),!1
const e=this.assistMapContains(t)
return null!=e&&!!this.assistMap[e]}SetAssisted(t){this.assistedId=t}GetAssisted(){return this.assistedId}SetAssistedVo(t){this.assistvo=t}AddAssistStatus(t){if(null==t)return
if(null==t.account)return
const e=this.assistMapContains(t.account)
null!=e?this.assistMap[e]=t.show:this.assistMap.LuaDic_AddOrSetItem(t.account,t.show)}assistMapContains(t){if(this.assistMap)for(const[e,s]of(0,
n.vy)(this.assistMap))if(e==t)return e
return null}testMap(){const t=r.o.FromNumber(20),e=new u.X
e.LuaDic_AddOrSetItem(t,!0)
const s=r.o.FromNumber(20)
e.LuaDic_ContainsKey(s)&&Debuger.LogError("the same key in testmap")}ClearAssistStatus(){this.assistedId=null,this.assistvo=null,l.Y.Inst.PrimaryRole_get().StopPathing(),
HangControl.getInst().endHang()}CancelAssist(){const t=new CM_QuitAssistStatus
a.C.Inst.F_SendMsg(t)}AssistOther(t){const e=new g.r
e.assistId=t,a.C.Inst.F_SendMsg(e)}SetFriendCount(t){this.friendCount=t}IsCurBoss(t){return!(null==this.bossId||!this.bossId.Equal(t))}ClearCurBossId(){this.bossId=null,
o.i.Inst.RaiseEvent(p.g.BOSS_DAMAGE_BOSSID_UPDATE)}IsBossEncourge(t){if(null==this.bossEncourageMap){const t=h.Y.Inst.GetOrCreateCsv(i.h.eBossencourageResource)
this.bossEncourageMap=t.GetCsvMap()}const e=l.Y.Inst.getBossById(t)
return null!=e&&null!=e.Cfg_get()&&this.bossEncourageMap.LuaDic_ContainsKey(e.Cfg_get().id)}}S.inst=null},97483:(t,e,s)=>{s.d(e,{g:()=>l})
var i=s(98800),n=s(68662)
class l{constructor(t,e,s,i,n,l,o){this.type=0,this.sortId=0,this.monsterId=0,this.attention=!1,this.info=null,this.isLocked=!1,this.canEnter=!1,this.copyId=0,this.index=0,
this.hadEnter=null,this.isFighting=null,null==n&&(n=!1),null==l&&(l=!1),null==o&&(o=!1),this.type=t,this.sortId=e,this.monsterId=s,this.info=i,this.attention=n,this.hadEnter=l,
this.isFighting=o}IsVipFix(){}IsVipDie(){if(null==this.info)return!1
const t=n.D.serverMSTime_get()
return this.info.refreshTime.ToNum()>t}IsCanEnter(){if(this.isLocked)return!1
return CopyResourceCfgManager.Inst().getItemById(this.copyId).IsVipFix(i.Y.Inst.PrimaryRoleInfo_get().VipLevel_get())}IslvFix(){}}},22046:(t,e,s)=>{s.d(e,{l:()=>i})
class i{}i.VIPBOSS=1,i.WORLDBOSS=2,i.NEUTROLBOSS=3,i.KARIMABOSS=4,i.ANCIENTBOSS=5,i.CROSSBOSS=1001},77344:(t,e,s)=>{s.d(e,{K:()=>i})
class i{}i.WORLDBOSS=1,i.ANCIENTBOSS=2,i.CROSSBOSS=3},19618:(t,e,s)=>{s.d(e,{G:()=>i})
class i{constructor(){this.ownerIds=null,this.bossId=null}}},12417:(t,e,s)=>{s.d(e,{_:()=>nt})
var i=s(38836),n=s(86133),l=s(23833),o=s(98800),a=s(97461),r=s(90419),h=s(50089),d=s(68662),c=s(62370),I=s(5924),u=s(66788),p=s(98130),_=s(98885),g=s(85602),m=s(38962),S=s(79534),f=s(63076),C=s(92679),T=s(33314),y=s(74045),A=s(39879),v=s(49067),D=s(87923),w=s(94650),B=s(41670),M=s(29839),b=s(85770),O=s(72800),R=s(35803),L=s(37648),G=s(55492),P=s(24524),E=s(75439),k=s(38501),N=s(48481),V=s(99828),x=s(31896),F=s(14792),U=s(62734),H=s(5968),j=s(65550),W=s(39043),Y=s(85942),q=s(28359),z=s(31931),Z=s(12970),X=s(21334),Q=s(15771),J=s(71893),$=s(19276),K=s(26223),tt=s(88934),et=s(97483),st=s(22046)
class it{constructor(t,e){this.type=0,this.info=null,this.type=t,this.info=e}}class nt{constructor(){this.isSearch=!1,this.WorldBossInfo=null,this.NeutrolBossInfo=null,
this.VipBossInfo=null,this.AncientBossInfo=null,this.vipsIds=null,this.normalDropList=null,this.rareDropList=null,this.CurrentDropInfoCount=0,this.attentionLis=null,
this.hadEnterBossId=null,this.fightingBossIds=null,this.FloorData=null,this.canAttentionLis=null,this.neutrolBossMapIds=null,this.sIds=null,this.isAccessOpen=!1,this.openTab=0,
this.curWbSortId=0,this.curNbSortId=0,this.curVbSortId=0,this.curAbSortId=0,this.curFloor=1,this.DROP_LEVEL_LIMIT=0,this.WORLDBOSS_TIREDVALUE_MAX=0,
this.NEUTROLBOSS_TIREDVALUE_MAX=0,this.FestivalBOSS_TIREDVALUE_MAX=0,this.viewType=0,this.refreshBossId=0,this.searchBossId=0,this.searchSpawnId=0,this.settingSortId=0,
this.vipBossId=0,this.recommendParam=0,this.bossIdQueue=null,this.isBossAttentionReq=!1,this.refreshInfo=null,this.wbDefaultIndex=0,this.nbDefaultIndex=0,this.vbDefaultIndex=0,
this.karimaDefaultIndex=0,this.calVBossData=null,this.calVBIndex=-1,this.abDefaultIndex=0,this.hasBossGridRefresh=!1,this.isShowCommonTip=!0,this.isPassCopy=!1,
this.bossId4PassCopy=0,this.dropMsg=null,this.dicSelectBossIds=null,this.isAddHint=!1,this.isFirstInVBoss=!0,this.isFirstInWBoss=!0,this.isFirstInABoss=!0,
this.listUnlockedBoss=null,this.dicAbLayer=null,this.dicAbSortId=null,this.listAbLayer=null,this.allBossInfo=null,this.bossId=0,this.dicDrop=null,this.dicExtraDrop=null,
this.findRoadDistance=0,this.findRoadDistance2=0,this.vbData=null,this.vbBossState=null,this.allVbData=null,this.vipBossPassRecord=null,this.neutrolBossCount=0,this.hasShowAni=!1,
this.StillGoId=0,this.worldBossMultipleBossLevel=1,this.worldBossTired=0,this.hasRecoverNum=0,this.hasBuy=0,this.bossTiredRevoverDelayTime=-1,this.hasDailyReward=null,
this.ancientBossTired=0,this.ancientHasRecoverNum=0,this.ancientHasBuy=0,this.ancientBossTiredRevoverDelayTime=-1,this.ancientHasDailyReward=null,this.crossBossTired=0,
this.crossHasRecoverNum=0,this.crossHasBuy=0,this.crossBossTiredRevoverDelayTime=-1,this.crossHasDailyReward=null,this.isOpenAddTip=!1,this.worldBossPlayerNum=0,
this.isShowMultipleRed=!1,this._degf_CancleHandle=null,this._degf_CheckPosUnlock_VIPBoss=null,this._degf_GotoCopy=null,this._degf_ReqEnterVipBoss=null,
this._degf_SortDataByBossID=null,this._degf_StillGo=null,this.WorldBossInfo=new m.X,this.NeutrolBossInfo=new m.X,this.VipBossInfo=new m.X,this.AncientBossInfo=new m.X,
this.vipsIds=new g.Z,this.normalDropList=new g.Z,this.rareDropList=new g.Z,this.attentionLis=new g.Z,this.hadEnterBossId=new g.Z,this.fightingBossIds=new g.Z,
this.FloorData=new g.Z,this.canAttentionLis=new g.Z,this.neutrolBossMapIds=new g.Z,this.sIds=new g.Z,this.bossIdQueue=new g.Z,this.dicSelectBossIds=new m.X,
this.listUnlockedBoss=new g.Z,this.dicAbLayer=new m.X,this.dicAbSortId=new m.X,this.listAbLayer=new g.Z,this.dicDrop=new m.X,this.dicExtraDrop=new m.X,this.vbData=new g.Z,
this.vbBossState=new m.X,this.allVbData=new g.Z,this._degf_CancleHandle=t=>this.CancleHandle(t),this._degf_CheckPosUnlock_VIPBoss=t=>this.CheckPosUnlock_VIPBoss(t),
this._degf_GotoCopy=t=>this.GotoCopy(t),this._degf_ReqEnterVipBoss=t=>this.ReqEnterVipBoss(t),this._degf_SortDataByBossID=(t,e)=>this.SortDataByBossID(t,e),
this._degf_StillGo=t=>this.StillGo(t),this.GetConfigValue(),this.InitAbLayerData()}static Inst(){return null==nt._inst&&(nt._inst=new nt),nt._inst}getColorStrByQuality(t){
return nt.qualityColorStrs[t-1]}AllBossInfo_get(){return this.allBossInfo}SetVipBossPassRecord(t){this.vipBossPassRecord=t}CalVipBossPassRecord(t){if(null==t)return
let e=0
for(;e<this.allVbData.Count();){const s=this.allVbData[e],i=s.monsterId,n=s.copyId
t.LuaDic_ContainsKey(n)?(this.VipBossInfo.LuaDic_ContainsKey(i)&&null!=this.VipBossInfo[i]||(s.m_info=new V.N,this.VipBossInfo[i]=new V.N),this.VipBossInfo[i].refreshTime=t[n],
s.info=this.VipBossInfo[i]):(this.VipBossInfo[i]=null,s.info=null),e+=1}}UpdateOneBossInfo(t){this.allBossInfo&&(this.allBossInfo[t.bossId]=t.bossInfo)}AllBossInfo_set(t){
this.allBossInfo=t,this.WorldBossInfo.LuaDic_Clear(),this.NeutrolBossInfo.LuaDic_Clear(),this.VipBossInfo.LuaDic_Clear(),this.AncientBossInfo.LuaDic_Clear(),this.vipsIds.Clear()
let e=0
for(const[t,s]of(0,i.vy)(this.allBossInfo))e=$.C.Inst().GetTabById(t),e==st.l.WORLDBOSS&&this.WorldBossInfo.LuaDic_AddOrSetItem(t,this.allBossInfo[t]),
e==st.l.NEUTROLBOSS&&this.NeutrolBossInfo.LuaDic_AddOrSetItem(t,this.allBossInfo[t]),e==st.l.VIPBOSS&&(this.VipBossInfo.LuaDic_AddOrSetItem(t,this.allBossInfo[t]),
this.vipsIds.Add($.C.Inst().GetItemByMonsterId(t).id_get())),e==st.l.ANCIENTBOSS&&this.AncientBossInfo.LuaDic_AddOrSetItem(t,this.allBossInfo[t])
const s=$.C.Inst().GetItemByType(st.l.VIPBOSS)
let n=0
for(;n<s.Count();)this.VipBossInfo.LuaDic_AddOrSetItem(s[n].monsterId_get(),null),this.vipsIds.Add(s[n].id_get()),n+=1
I.C.Inst_get().SetInterval(tt.$.inst._degf_updateRedPoint,1e3,5),null!=this.listAbLayer&&this.listAbLayer.Count()>0&&this.AbLayerDataHandle(this.listAbLayer)}DropValues_get(){
let t=null
if(0!=this.bossId){if(this.dicDrop.LuaDic_ContainsKey(this.bossId))return this.dicDrop[this.bossId]
const e=$.C.Inst().getItemById(this.bossId).drop_get()
if(null!=e){const s=r.d.parseJsonObjectWithFix(e,"rewardValues")
t=h.t.decode(s,q.h),t.Parse(),this.dicDrop.LuaDic_AddOrSetItem(this.bossId,t)}}return t}ExtraDropValues_get(){let t=null
if(0!=this.bossId){if(this.dicExtraDrop.LuaDic_ContainsKey(this.bossId))return this.dicExtraDrop[this.bossId]
const e=$.C.Inst().getItemById(this.bossId).extraDrop_get()
if(null!=e){const s=r.d.parseJsonObjectWithFix(e,"rewardValues")
t=h.t.decode(s,q.h),t.Parse(),this.dicExtraDrop.LuaDic_AddOrSetItem(this.bossId,t)}}return t}FindRoadDistance_get(){if(0==this.findRoadDistance){
const t=E.D.getInstance().getContent("FINDROAD:DISTANCE").getContent()
this.findRoadDistance=_.M.String2Int(t.stringVal)}return this.findRoadDistance}FindRoadDistance2_get(){return this.findRoadDistance2}SetAttentionLis(t){this.attentionLis.Clear()
let e=0
for(;e<t.count;)this.attentionLis.Add(t[e]),e+=1}UpdateAttention(t){1==t.type?this.attentionLis.Add(t.bossId):this.attentionLis.Remove(t.bossId)}SetEnterLis(t){
this.hadEnterBossId=t}SetFightingLis(t){this.fightingBossIds=t}GetWbShowData(){const t=new g.Z
for(const[e,s]of(0,i.vy)(this.WorldBossInfo)){const s=$.C.Inst().GetItemByMonsterId(e)
if(null!=s&&s.levelDiplay_get()<=o.Y.Inst.PrimaryRoleInfo_get().Level_get()){
const i=this.attentionLis.IndexOf(e,0)>=0,n=this.hadEnterBossId.IndexOf(e,0)>=0,l=this.fightingBossIds.IndexOf(e,0)>=0,o=new et.g(st.l.WORLDBOSS,s.id_get(),e,this.WorldBossInfo[e],i,n,l)
t.Add(o)}}return this.SortDataBySId(t),t}CheckWbRedPoint(){let t=!1
for(const[e,s]of(0,i.vy)(this.WorldBossInfo)){const i=$.C.Inst().GetItemByMonsterId(e)
if(null!=i&&i.levelDiplay_get()<=o.Y.Inst.PrimaryRoleInfo_get().Level_get()){let n=0
const l=i.copyid_get()
if(n=l>0?Z.F.getInst().GetCanEnterCopyByLvAndTransfer(l):Z.F.getInst().GetCanEnterMapByLvAndTransfer(i.mapId_get()),n==z.f.CAN&&!(s.refreshTime.ToNum()-d.D.serverMSTime_get()>0)){
this.hadEnterBossId.IndexOf(e,0)>=0||(t=!0)}}}U.f.Inst.SetState(F.t.WORLD_BOSS_FREE,t)}CheckWbMultipleRedPoint(){const t=Q.U.inst.model.level_get(),e=k.f.Inst().getItemById(t)
e.multipleBoss>1&&!x.t.inst.IsHasClick(F.t.WORLD_BOSS_MULTIPLE+e.multipleBoss)?this.isShowMultipleRed=!0:this.isShowMultipleRed=!1,
U.f.Inst.SetState(F.t.WORLD_BOSS_MULTIPLE,this.isShowMultipleRed)}GetVbShowData(){new g.Z
this.allVbData.Clear(),this.listUnlockedBoss.Clear()
for(const[t,e]of(0,i.vy)(this.VipBossInfo)){
const e=$.C.Inst().GetItemByMonsterId(t),s=P.o.Inst().getItemById(e.copyid_get()),i=this.attentionLis.IndexOf(t,0)>=0,n=new et.g(st.l.VIPBOSS,e.id_get(),t,this.VipBossInfo[t],i)
n.copyId=s.id,this.IsUnlock(s)?(n.isLocked=!0,this.listUnlockedBoss.Add(n)):n.isLocked=!1,this.allVbData.Add(n)}return this.listUnlockedBoss.Sort(this._degf_SortDataByBossID),
this.allVbData.Sort(this._degf_SortDataByBossID),this.CalVipBossPassRecord(this.vipBossPassRecord),this.allVbData}GetKarimaShowData(){new g.Z
this.allVbData.Clear(),this.listUnlockedBoss.Clear()
for(const[t,e]of(0,i.vy)(this.VipBossInfo)){
const e=$.C.Inst().GetItemByMonsterId(t),s=P.o.Inst().getItemById(e.copyid_get()),i=this.attentionLis.IndexOf(t,0)>=0,n=new et.g(st.l.VIPBOSS,e.id_get(),t,this.VipBossInfo[t],i)
n.copyId=s.id,this.IsUnlock(s)?(n.isLocked=!1,this.listUnlockedBoss.Add(n)):n.isLocked=!0,this.allVbData.Add(n)}return this.listUnlockedBoss.Sort(this._degf_SortDataByBossID),
this.allVbData.Sort(this._degf_SortDataByBossID),this.CalVipBossPassRecord(this.vipBossPassRecord),this.allVbData}GetNbShowDataByFloor(t){
const e=new g.Z,s=this.GetNbShowData(),i=this.GetMapIdByFloor(t)
let n=0
for(;n<s.Count();){const t=s[n]
$.C.Inst().GetItemByMonsterId(t.monsterId).mapId_get()==i&&e.Add(t),n+=1}return this.SortDataBySId(e),e}GetNbShowData(){const t=new g.Z
let e=null,s=null
for(const[n,l]of(0,i.vy)(this.NeutrolBossInfo))if(s=$.C.Inst().GetItemByMonsterId(n),s.levelDiplay_get()<=o.Y.Inst.PrimaryRoleInfo_get().Level_get()){
const i=this.attentionLis.IndexOf(n,0)>=0
e=new et.g(st.l.NEUTROLBOSS,s.id_get(),n,this.NeutrolBossInfo[n],i),t.Add(e)}return this.SortDataBySId(t),t}GetAbShowData(){const t=new g.Z
for(const[e,s]of(0,i.vy)(this.AncientBossInfo)){const s=$.C.Inst().GetItemByMonsterId(e)
if(s.levelDiplay_get()<=o.Y.Inst.PrimaryRoleInfo_get().Level_get()){const i=this.attentionLis.IndexOf(e,0)>=0,n=new et.g(st.l.ANCIENTBOSS,s.id_get(),e,this.AncientBossInfo[e],i)
t.Add(n)}}return this.SortDataBySId(t),t}GetMapIdByFloor(t){return 0}GetFloorDataByMapId(t){return null}GetFloorDataByFloor(t){return null}SortDataBySId(t){if(t.Count()>0){let e=0
for(;e<t.Count()-1;){let s=e+1
for(;s<t.Count();){if(t[e].sortId>t[s].sortId){let i=new et.g(0,0,0,null)
i=t[e],t[e]=t[s],t[s]=i}s+=1}e+=1}}}SortDataByBossID(t,e){return t.sortId-e.sortId}ResetSelectId(){this.UpdateWorldBossSelectId(),this.UpdateVipBossSelectId(),
this.UpdateAncientBossSelectId()}GetRecommendBoss(t){const e=o.Y.Inst.PrimaryRoleInfo_get().Level_get()
let s=t.Count()-1
for(;s>=0;){const i=t[s],n=$.C.Inst().getItemById(i.sortId),l=n.GetRecommendLvArea()
if(e>=l[0]&&e<=l[1]){let t=!1
if(t=n.type_get()!=st.l.WORLDBOSS||Z.F.getInst().IsOpenMap(n.mapId_get()),t)return s}s-=1}return-1}GetFreeVIPBoss(){let t=-1,e=0
for(;e<this.listUnlockedBoss.Count();){const s=this.listUnlockedBoss[e].sortId
if(1==this.vbBossState[s]){t=e
break}e+=1}return t}UpdateWorldBossSelectId(){this.isFirstInWBoss&&(this.curWbSortId=this.GetBossId4WBAB(st.l.WORLDBOSS))
const t=this.GetWbShowData()
let e=0
for(;e<t.Count();){if(t[e].sortId==this.curWbSortId){this.wbDefaultIndex=e
break}e+=1}}UpdateFloorSelect(){const t=this.GetNbShowData(),e=this.GetRecommendBoss(t)
if(e<0)return
const s=t[e].sortId,i=$.C.Inst().getItemById(s),n=this.GetFloorDataByMapId(i.mapId_get())
this.curFloor=n.floor,this.UpdateFloorSelectByFloor(this.curFloor)}UpdateFloorSelectByFloor(t){const e=this.GetNbShowDataByFloor(t)
this.nbDefaultIndex=this.GetRecommendBoss(e),this.curNbSortId=e[this.nbDefaultIndex].sortId}UpdateVipBossSelectId(){
L.P.Inst_get().IsFunctionOpened(G.x.PERSONAL_BOSS)&&(this.vbData=this.GetVbShowData(),this.vbBossState.LuaDic_Clear(),this.CalFixVipBossSortId(),
null!=this.calVBossData&&(this.curVbSortId=this.calVBossData.sortId))}GetVipBossState(t,e,s){let i=!1
return P.o.Inst().getItemById(t.copyid_get()).isFirstPassConsumeNum&&!s.isLocked&&(null!=R.D.Inst_get().passedBossList&&R.D.Inst_get().passedBossList.Contains(t.copyid_get())||(i=!0)),
i||e?!i&&e?2:i&&!e||i&&e?1:0:0}GetBossDataById(t){let e=null
for(const[s,n]of(0,i.V5)(this.vbData))if(n.sortId==t){e=n
break}return e}GetBossDataByCopyId(t){let e=null
for(const[s,n]of(0,i.V5)(this.vbData))if(e=n,e.copyId==t)return e
return null}GetRecommndVipBoss(){if(this.listUnlockedBoss.Count()>0){return this.listUnlockedBoss[this.listUnlockedBoss.Count()-1]}return null}IsFreeForFirstIn(t){
return 1==this.vbBossState[t]}UpdateAncientBossSelectId(){this.isFirstInABoss&&(this.curAbSortId=this.GetBossId4WBAB(st.l.ANCIENTBOSS)),
this.abDefaultIndex=this.GetCurIndexByLayer()}UpdateCurKarimaSelectId(){}GetDropData(){const t=new g.Z
if(null!=this.dropMsg){let e=null,s=this.dropMsg.stickRareDrops.Count()-1
for(;s>=0;)e=new it(1,this.dropMsg.stickRareDrops[s]),t.Add(e),s-=1
let i=this.dropMsg.normalRareDrops.Count()-1
for(;i>=0;)e=new it(2,this.dropMsg.normalRareDrops[i]),t.Add(e),i-=1}return t}GetConfigValue(){const t=E.D.getInstance().getContent("BOSSINFO:ATTENTION_LIST").getContent().arrayVal
for(const[e,s]of(0,i.V5)(t))this.canAttentionLis.Add(_.M.String2Int(s))
const e=E.D.getInstance().getContent("BOSS:RECOMMENDPARA")
this.recommendParam=_.M.String2Int(e.getContent().stringVal)}GetBossTiredMax(){let t=E.D.getInstance().getContent("BOSSINFO:BOSS_TIRED_LIMIT").getContent().stringVal
t=_.M.Replace(t,_.M.s_LEFT_B_K_CHAR,""),t=_.M.Replace(t,_.M.s_RIGHT_B_K_CHAR,"")
const e=_.M.Split(t,_.M.s_SPAN_CHAR),s=_.M.Split(e[0],c.o.s_UNDER_COLON)
this.WORLDBOSS_TIREDVALUE_MAX=_.M.String2Int(s[1])
const i=_.M.Split(e[1],c.o.s_UNDER_COLON)
this.NEUTROLBOSS_TIREDVALUE_MAX=_.M.String2Int(i[1])
const n=_.M.Split(e[3],c.o.s_UNDER_COLON)
this.FestivalBOSS_TIREDVALUE_MAX=_.M.String2Int(n[1])}GetConfigLis(t){const e=new g.Z
let s=t.getContent().stringVal
s=_.M.Replace(s,_.M.s_LEFT_B_K_CHAR,""),s=_.M.Replace(s,_.M.s_RIGHT_B_K_CHAR,"")
const i=_.M.Split(s,_.M.s_SPAN_CHAR_DOT)
let n=0
for(;n<i.count;){const t=_.M.Split(i[n],c.o.s_Arr_UNDER_COLON),s=_.M.String2Int(t[1])
e.Add(s),n+=1}return e}GetFreeBossMapLevel(t){return 0}GetDemandsByStr(t){const e=new g.Z
let s=_.M.Replace(t,_.M.s_LEFT_M_K_CHAR_REPLACE,"")
s=_.M.Replace(s,_.M.s_RIGHT_M_K_CHAR_REPLACE,"")
const n=_.M.Split(s,_.M.s_Arr_SPAN_CHAR_DOT)
for(const[t,s]of(0,i.V5)(n))e.Add(_.M.String2Int(s))
return e}isInBossHome(){return!1}GetMax(t){let e=0,s=0
if(null!=t&&t.Count()>0){let i=0
for(;i<t.Count();){const n=$.C.Inst().getItemById(t[i]),o=l.a.getInst().getObjById(n.monsterId_get())
o.level>e&&(e=o.level,s=t[i]),i+=1}}return s}GetDefaultIndex(t){let e=0,s=0
if(null!=t&&t.Count()>0){let i=0
for(;i<t.Count();){const n=$.C.Inst().getItemById(t[i]),o=l.a.getInst().getObjById(n.monsterId_get())
o.level>e&&(e=o.level,s=i),i+=1}}return s}GetDragAmount(t,e,s,i){return null==i&&(i=0),t<=s?0:t-e<=s-i?1:(e-i)/(t-s)}isNeutrolBossMap(t){return!1}GetRewardLis(t,e){null==e&&(e=!1)
const s=new g.Z,i=$.C.Inst().getItemById(t)
this.bossId=t
let n=null
if(n=e?this.ExtraDropValues_get():this.DropValues_get(),null!=n&&null!=n.rewardValues&&n.rewardValues.Count()>0){const t=n.rewardValues
let e=0
for(;e<t.Count();){if(null!=t[e]){const n=T.Z.GetJobBaseValue(o.Y.Inst.PrimaryRoleInfo_get().Job_get()),l=t[e],a=l.baseItem_get().modelId_get()
if(L.P.Inst_get().IsFunOpenByItemId(a))if(null!=l.job){if(_.M.String2Int(l.job)==n){const t=new N.t
t.num=l.secondValue_get()
const e=new f.M(l.firstValue_get(),t)
e.isForBag=!1,e.isEquipCompare=!1,e.SetEquipAttrShowId(l.showid),e.showtag=l.showtag,i.type_get()!=st.l.WORLDBOSS&&i.type_get()!=st.l.ANCIENTBOSS||(e.tipsPos=new S.P(-175,0,0)),
s.Add(e)}}else{const t=new N.t
t.num=l.secondValue_get()
const e=new f.M(l.firstValue_get(),t)
e.isForBag=!1,e.isEquipCompare=!1,e.SetEquipAttrShowId(l.showid),e.showtag=l.showtag,i.type_get()!=st.l.WORLDBOSS&&i.type_get()!=st.l.ANCIENTBOSS||(e.tipsPos=new S.P(-175,0,0)),
s.Add(e)}else u.Y.LogError(`bossinfo.csv 表中配置的掉落奖励道具id 在 itemresource.csv 中不存在。${a}`)}e+=1}}return s}IsRecommended(t){const e=$.C.Inst().getItemById(t)
return w.h.GetPlayerDieSecs(e.monsterId_get())>w.h.GetBossDiesSecs(e.monsterId_get())}GetDateFormat(t){let e=""
const s=p.GF.INT(t/86400)
s>0&&(e+=s+(0,n.T)("天"),t%=86400)
const i=p.GF.INT(t/3600)
i>0&&(e+=i+(0,n.T)("小时"),t%=3600)
const l=p.GF.INT(t/60)
return l>0&&(e+=l+(0,n.T)("分"),t%=60),t>0&&(e+=p.GF.INT(t)+(0,n.T)("秒")),e}GetLastKillInfo(t){let e=""
const s=this.AllBossInfo_get()[t].killHistories
if(0==s.Count())e=(0,n.T)("暂无")
else{let t=s[0].time.ToNum(),i=0,n=0,l=1
for(;l<s.Count();)i=s[l].time.ToNum(),i>t&&(t=i,n=l),l+=1
e=s[n].playerName}return e}GetFloorStr(t){let e=""
return 1==t?e=(0,n.T)("第一层"):2==t?e=(0,n.T)("第二层"):3==t?e=(0,n.T)("第三层"):4==t?e=(0,n.T)("第四层"):5==t?e=(0,n.T)("第五层"):6==t&&(e=(0,n.T)("第六层")),e}ResetModel(){
this.bossIdQueue.Clear(),this.hasShowAni=!1,this.isBossAttentionReq=!1,this.dicSelectBossIds.LuaDic_Clear(),this.isSearch=!1,this.searchBossId=0,this.searchSpawnId=0,
this.worldBossTired=0,this.ancientBossTired=0,this.isShowMultipleRed=!1}GetBossId4WBAB(t){let e=null
return e=t==st.l.WORLDBOSS?this.GetWbShowData():this.GetAbShowDataByLayer(this.GetMaxLayer()),this.GetSortIdByLevel(e,t)}GetBossByLevel(t){
const e=o.Y.Inst.PrimaryRoleInfo_get().Level_get()
let s=null
t==st.l.WORLDBOSS?s=this.GetAliveBoss(this.GetWbShowData()):t==st.l.ANCIENTBOSS&&(s=this.GetAliveBoss(this.GetAbShowData()))
const i=new g.Z
let n=0
for(;n<s.Count();){const e=$.C.Inst().getItemById(s[n].sortId)
if(null!=e){let l=0
if(t==st.l.WORLDBOSS){const t=e.copyid_get()
l=t>0?Z.F.getInst().GetCanEnterCopyByLvAndTransfer(t):Z.F.getInst().GetCanEnterMapByLvAndTransfer(e.mapId_get())}else l=Z.F.getInst().GetCanEnterMapByLvAndTransfer(e.mapId_get())
l==z.f.CAN&&i.Add(s[n])}n+=1}let a=i.Count()-1
for(;a>=0;){if(l.a.getInst().getObjById(i[a].monsterId).level<=e)return i[a]
a-=1}return null}GetAliveBoss(t){const e=new g.Z
for(const[s,n]of(0,i.V5)(t))if(null!=n&&null!=n.info){n.info.refreshTime.ToNum()-d.D.serverMSTime_get()<=0&&e.Add(n)}return e}ClearFirstInBossView(){this.isFirstInVBoss=!0,
this.isFirstInWBoss=!0,this.isFirstInABoss=!0}InitAbLayerData(){const t=E.D.getInstance().getContent("MAP:BATTLE_FIELD_IDS").getContent().arrayVal
let e=0
for(;e<t.count;)this.listAbLayer.Add(_.M.String2Int(t[e])),e+=1}GetAbMapLayers(){return this.listAbLayer}AbLayerDataHandle(t){this.dicAbLayer.LuaDic_Clear()
for(const[e,s]of(0,i.vy)(this.AncientBossInfo)){const s=$.C.Inst().GetItemByMonsterId(e)
if(t.Contains(s.mapId_get())){let t=null
if(s.levelDiplay_get()<=o.Y.Inst.PrimaryRoleInfo_get().Level_get()){const i=this.attentionLis.IndexOf(e,0)>=0
t=new et.g(st.l.ANCIENTBOSS,s.id_get(),e,this.AncientBossInfo[e],i)}if(this.dicAbLayer.LuaDic_ContainsKey(s.mapId_get()))null!=t&&this.dicAbLayer[s.mapId_get()].Add(t)
else if(null!=t){const e=new g.Z
e.Add(t),this.dicAbLayer.LuaDic_AddOrSetItem(s.mapId_get(),e)}}}for(const[t,e]of(0,i.vy)(this.dicAbLayer)){this.SortDataBySId(this.dicAbLayer[t])
const e=this.GetSortIdByLevel(this.dicAbLayer[t],st.l.ANCIENTBOSS)
this.dicAbSortId.LuaDic_AddOrSetItem(t,e)}}GetAbShowDataByLayer(t){let e=null
return e=this.dicAbLayer.LuaDic_GetItem(t),e}GetCurAbSortIdMapId(){if(0==this.curAbSortId)return-1
const t=$.C.Inst().getItemById(this.curAbSortId)
return null==t?-1:t.mapId_get()}UpdateABossSelectIdByLayer(t){const e=this.GetCurAbSortIdMapId();-1!=e&&(e!=t?(this.curAbSortId=this.dicAbSortId[t],
this.abDefaultIndex=this.GetCurIndexByLayer(),a.i.Inst.RaiseEvent(C.g.BOSS_SELECT,this.GetCurABossData())):this.dicAbSortId[t]=this.curAbSortId)}GetSortIdByLevel(t,e){
const s=o.Y.Inst.PrimaryRoleInfo_get().Level_get()
if(null==t||0==t.Count())return 0
let i=t.Count()-1
for(;i>=0;){const e=$.C.Inst().getItemById(t[i].sortId).GetRecommendLvArea()
if(s>=e[0]&&s<=e[1])return t[i].sortId
i-=1}return t[0].sortId}GetCurABossData(){const t=this.GetAbShowData()
let e=0
for(;e<t.Count();){if(t[e].sortId==this.curAbSortId)return t[e]
e+=1}return null}GetCurIndexByLayer(){const t=this.GetCurAbSortIdMapId()
if(-1==t)return-1
const e=this.GetAbShowDataByLayer(t)
if(null!=e&&e.Count()>0){let t=0
for(;t<e.Count();){if(e[t].sortId==this.curAbSortId)return t
t+=1}}return-1}GetMaxLayer(){let t=0,e=0
for(const[s,n]of(0,i.V5)(this.listAbLayer)){const s=X.p.Inst_get().GetMapById(n)
null!=s&&t<s.minLevelLimit&&Z.F.getInst().GetCanEnterMapByLvAndTransfer(n)==z.f.CAN&&(t=s.minLevelLimit,e=n)}return e}WorldBossGoTo(t,e){if(!this.BossLimitHandle(t)){
const t=this.GetWbShowData()
let s=0
for(;s<t.Count();){if(t[s].sortId==e.id_get()){K.x.Inst_get().BossIsAlive(t[s])
break}s+=1}}}VIPBossGoTo(t,e){const s=P.o.Inst().getItemById(t),i=$.C.Inst().getItemById(e)
if(this.BossLimitHandle(i.copyid_get()))return
let l=s.winTimes
const o=b.a.Inst_get().GetCopyRecByKey(O.S.VipBoss)
if(null!=o){l=l+o.todayBuyTimes+o.todayItemTimes}if(null!=o){let t=-1
const a=b.a.Inst_get().copyCoolTimeDic
if(a.LuaDic_ContainsKey(O.S.VipBoss)){const e=b.a.Inst_get().copyRecordDic[O.S.VipBoss],s=a[O.S.VipBoss],i=(e.lastCopyId,b.a.Inst_get().waitTime),n=d.D.serverMSTime_get()-s
if(n>=i);else{let e=p.GF.INT(n)
e=i-e,t=e/1e3}}o.todayWinHistory<l||this.IsFreeForFirstIn(i.id_get())?t>0?j.y.inst.ClientStrMsg(2,(0,n.T)("副本冷却中，无法挑战！")):this.ShowCommonTipView(e):B.B.GetInst().AddTimes(s.id)}}
ShowCommonTipView(t){
const e=this.GetBossDataById(this.curVbSortId),s="BOSS:PERSONAL_CONFIRM_LEVEL_UP",i=$.C.Inst().getItemById(t),l=W.V.Inst_get().GetData(W.V.Inst_get().GetRolePrefix()+s)
if(0!=this.vbBossState[this.curVbSortId]||l)this.CheckPosUnlock_VIPBoss(e)
else{const t=`${nt.qualityStr3}${i.name_get()}(${P.o.Inst().getItemById(i.copyid_get()).minLevelLimit+(0,n.T)("级)")}`,l=(A.L.Inst().getItemById(s),new v.B)
l.infoId=s,l.replaceParams.Add(t),l.confirmParam=e,l.confirmHandle=this._degf_CheckPosUnlock_VIPBoss,y.t.Inst().Open(l)}}CheckPosUnlock_VIPBoss(t){y.t.Inst().Close()
const e=t
if(null!=e&&null!=$.C.Inst().getItemById(e.sortId)){$.C.Inst().getItemById(e.sortId).equipPos_get()}}ReqEnterVipBoss(t){const e=t,s=$.C.Inst().GetItemByMonsterId(e.monsterId)
tt.$.Inst().Close()
const i=s.copyid_get()
M.p.inst.SendEnterCopy(i)}AncientBossGoTo(t,e){const s=new et.g(st.l.ANCIENTBOSS,e.id_get(),e.monsterId_get(),null,!1)
if(o.Y.Inst.PrimaryRoleInfo_get().NeutrolBossTired_get()>0)K.x.Inst_get().CheckBossLayer(s)
else{this.StillGoId=s.sortId
const t=new Y.N
t.showText=(0,n.T)("今日挑战次数已用完，无法对BOSS造成伤害\n是否仍要前往？"),t.okText=(0,n.T)("取消"),t.okhandler=this._degf_CancleHandle,t.tipstype=2,t.cancelText=(0,n.T)("仍旧前往"),
t.cancelhandler=this._degf_StillGo,j.y.inst.OpenCommonMessageTips(t)}}CancleHandle(t){this.StillGoId=0,H.Z.Inst.ClosePanel()}StillGo(t){tt.$.Inst().Transport(this.StillGoId),
this.StillGoId=0}GotoCopy(t){tt.$.Inst().Close()}BossGoTo(t){const e=$.C.Inst().GetItemByMonsterId(t)
$.C.Inst().GetTabById(t)==st.l.WORLDBOSS?this.WorldBossGoTo(e.copyid_get(),e):this.AncientBossGoTo(e.copyid_get(),e)}IsUnlock(t){const e=Q.U.inst.model.level_get()
return o.Y.Inst.IsLevelFix(t.GetLvConditionLimit())&&e>=t.GetVipLimit()}IsFixEnter(t){
return o.Y.Inst.IsLevelFix(t.GetLvConditionLimit())&&t.IsVipFix(o.Y.Inst.PrimaryRoleInfo_get().VipLevel_get())}NormalMapLimitHandle(t){const e=X.p.Inst_get().GetMapById(t)
return!o.Y.Inst.IsLevelFix(e.minLevelLimit)&&(j.y.inst.ClientSysMessage(111032),!0)}BossLimitHandle(t,e){null==e&&(e=!1)
const s=P.o.Inst().getItemById(t)
if(!this.IsUnlock(s))return e&&this.CalFixVipBossSortId(),j.y.inst.ClientSysMessage(111032),!0
if(!this.IsFixEnter(s))return e&&this.CalFixVipBossSortId(),j.y.inst.ClientSysMessage(111033),!0
if(nt.Inst().IsVipBossCopy(s.controllerType)){const t=this.GetBossDataByCopyId(s.copyId)
if(null!=t&&null!=t.info&&t.info.refreshTime.ToNum()-d.D.serverMSTime_get()>0)return j.y.inst.ClientSysMessage(111028),!0}return!1}GetCenterRate(){
return D.l.GalScollToGridRate(561,88,this.calVBossData.index,this.vbData.count,!0,!0)}GalCenterRate(){const t=56.1/88/2,e=this.vbData.count
if(this.calVBossData.index<t)return 0
if(this.calVBossData.index+t>e)return 1
return(1*this.calVBossData.index-t)/this.vbData.count}CalFixVipBossSortId(){this.calVBossData=null
let t=0,e=0,s=null
this.calVBIndex=-1
let n=0
for(const[l,o]of(0,i.V5)(this.vbData)){s=o
const i=P.o.Inst().getItemById(s.copyId)
let l=0,a=b.a.Inst_get().GetCopyFreeNum(i.controllerType)
const r=b.a.Inst_get().GetCopyRecByKey(i.controllerType)
if(null!=r){a+=r.todayBuyTimes
const t=r.todayEnterHistory
a-t>0&&(l=a-t)}this.GetCanVip(i)&&l>0&&(i.GetVipLimit()>e||i.GetVipLimit()==e&&i.GetLvConditionLimit()>t)&&(e=i.GetVipLimit(),t=i.GetLvConditionLimit(),this.calVBossData=s,
this.calVBossData.index=n),n+=1}let l=!0
return null==this.calVBossData&&(l=!1,this.calVBossData=this.vbData[0]),l}GetCanVip(t){
return o.Y.Inst.IsLevelFix(t.GetLvConditionLimit())&&o.Y.Inst.PrimaryRoleInfo_get().VipLevel_get()>=t.GetVipLimit()}IsVipBossCopy(t){
return t==O.S.VipBoss1||t==O.S.VipBoss2||t==O.S.VipBoss3}BossTiredRevoverNumToday_get(t){return t==st.l.WORLDBOSS?this.hasRecoverNum:this.ancientHasRecoverNum}WorldBossTired_get(){
return this.worldBossTired}BossTiredHasBuyNumToday_get(t){return t==st.l.WORLDBOSS?this.hasBuy:this.ancientHasBuy}HasDailyReward_get(){return this.hasDailyReward}
BossTiredInfo_set(t){this.worldBossTired=t.stamina,this.hasRecoverNum=t.hasRecoverNum,this.hasBuy=t.hasBuy,this.hasDailyReward=t.hasDailyReward,J.u.Inst_get().DailyTiredInfo_set(),
t.delayTime<0?this.bossTiredRevoverDelayTime=-1:this.bossTiredRevoverDelayTime=t.delayTime+d.D.serverTime_get(),a.i.Inst.RaiseEvent(C.g.WORLD_BOSS_TIRED_UPDATE)}
AncientBossTired_get(){return this.ancientBossTired}AncientBossTired_set(t){this.ancientBossTired=t.stamina,this.ancientHasRecoverNum=t.hasRecoverNum,this.ancientHasBuy=t.hasBuy,
this.ancientHasDailyReward=t.hasDailyReward,t.delayTime<0?this.ancientBossTiredRevoverDelayTime=-1:this.ancientBossTiredRevoverDelayTime=t.delayTime+d.D.serverTime_get(),
a.i.Inst.RaiseEvent(C.g.WORLD_BOSS_TIRED_UPDATE)}CrossBossTired_get(){return this.crossBossTired}CrossBossTired_set(t){this.crossBossTired=t.stamina,
this.crossHasRecoverNum=t.hasRecoverNum,this.crossHasBuy=t.hasBuy,this.crossHasDailyReward=t.hasDailyReward,
t.delayTime<0?this.crossBossTiredRevoverDelayTime=-1:this.crossBossTiredRevoverDelayTime=t.delayTime+d.D.serverTime_get(),a.i.Inst.RaiseEvent(C.g.CROSS_BOSS_TIRED_UPDATE)}}
nt._inst=null,nt.qualityStr0="[bbb5ab]",nt.qualityStr1="[61acf2]",nt.qualityStr2="[c67bff]",nt.qualityStr3="[ff6600]",nt.qualityStr4="[f64746]",
nt.qualityColorStrs=new g.Z([nt.qualityStr0,nt.qualityStr1,nt.qualityStr2,nt.qualityStr3,nt.qualityStr4]),nt.BOSS_NUM_PER_PAGE=5,nt.NEUTROL_BOSS_NUM_PER_PAGE=3,
nt.FLOOR_NUM_PER_PAGE=4},34923:(t,e,s)=>{s.d(e,{y:()=>S})
var i,n=s(18998),l=s(83908),o=s(23833),a=s(96098),r=s(68662),h=s(5924),d=s(9057),c=s(98885),I=s(87923),u=s(75517),p=s(21334),_=s(19276),g=s(26223),m=s(12417)
let S=n._decorator.ccclass("AncientBossListItem")(i=class extends((0,l.pA)(d.x)()){constructor(...t){super(...t),this.lvOk=!1,this._degf_OnSearchClick=null,
this._degf_SetRevive=null,this.tModel=null,this.intervalId=null,this.bossIdx=null,this.bossData=null,this.cfg=null,this.objRes=null,this.mapRes=null}_initBinder(){
super._initBinder(),this._degf_OnSearchClick=(t,e)=>this.OnSearchClick(t,e),this._degf_SetRevive=()=>this.SetRevive()}InitView(){this.tModel=m._.Inst(),this.intervalId=-1}
OnSearchClick(t,e){if(null!=u.W.inst_get().view||a.B.Inst.isOpenMaskStart)return
const s=this.tModel.GetAbShowData()[this.bossIdx]
g.x.Inst_get().CheckPosUnlock(s)}SetData(t){this.m_handlerMgr.AddClickEvent(this.gotoBtn,this.CreateDelegate(this.OnSearchClick))
const e=t
this.bossData=e,this.cfg=_.C.Inst().getItemById(e.sortId),this.objRes=o.a.getInst().getObjById(e.monsterId),this.mapRes=p.p.Inst_get().GetMapById(this.cfg.mapId_get()),
this.bossIdx=0
const s=this.tModel.GetAbShowData()
let i=0
for(;i<s.Count();){if(s[i].sortId==this.bossData.sortId){this.bossIdx=i
break}i+=1}this.SetBossInfo()}SetBossInfo(){let t=""
this.tModel.AllBossInfo_get()[this.cfg.monsterId_get()].refreshTime.ToNum()-r.D.serverMSTime_get()<=0?(this.gotoBtn.node.SetActive(!0),this.reviveTime.node.SetActive(!1),
t="[CECCC5]"):(this.gotoBtn.node.SetActive(!1),this.reviveTime.node.SetActive(!0),t="[8E8279]",
-1==this.intervalId&&(this.intervalId=h.C.Inst_get().SetInterval(this._degf_SetRevive,1e3),this.SetRevive())),
this.bossName.textSet(`${t}【${c.M.IntToString(this.objRes.level)}级】${this.objRes.name}[-]`)}SetRevive(){let t=""
const e=this.tModel.AllBossInfo_get()[this.cfg.monsterId_get()].refreshTime.ToNum()-r.D.serverMSTime_get()
e<=0?(this.ClearInterval(),this.SetBossInfo()):t=I.l.GetDateFormatEX(e/1e3,!0),this.reviveTime.textSet(t)}ClearInterval(){h.C.Inst_get().ClearInterval(this.intervalId),
this.intervalId=-1}Clear(){this.ClearInterval()}Destroy(){}})||i},2042:(t,e,s)=>{
var i,n=s(13687),l=s(57834),o=s(60130),a=s(20193),r=s(27610),h=s(21370),d=s(6847),c=s(83908),I=s(46282),u=s(36241),p=s(2689),_=s(5494),g=s(33314),m=s(92473),S=s(89144),f=s(19276),C=s(88934)
;(0,d.s_)(_.I.AssistDamageRankPanel,I.Z.ui_bossassist_assisting).layerSet(h.T.nav).register()(i=class extends((0,c.Ri)()){constructor(...t){super(...t),
this._degf_OnMemberDamageItemRefreshFun=null,this._degf_OnCloseClick=null,this._degf_OnGotoClick=null,this.bModel=null}_initBinder(){super._initBinder(),
this._degf_OnCloseClick=(t,e)=>this.OnCloseClick(t,e),this._degf_OnGotoClick=(t,e)=>this.OnGotoClick(t,e)}InitView(){super.InitView(),this.bModel=a.D.Inst_get(),
this.assistGrid.SetInitInfo("ui_bossassist_item2",null,r.X),o.O.SetAnchorPos(this.anchor,!1,!0,0)}Clear(){a.D.Inst_get().isHideAssistHeadIcon=!1,this.RemoveLis()}Destroy(){}
AddLis(){l.i.Get(this.closeBtn.node).RegistonClick(this._degf_OnCloseClick),l.i.Get(this.gotoBtn.node).RegistonClick(this._degf_OnGotoClick)}RemoveLis(){
l.i.Get(this.closeBtn.node).RemoveonClick(this._degf_OnCloseClick),l.i.Get(this.gotoBtn.node).RemoveonClick(this._degf_OnGotoClick)}OnAddToScene(){this.AddLis(),this.RefreshItems()
}RefreshItems(){if(this.assistdamage.SetActive(!1),null==this.bModel.assistedId){this.assisting.SetActive(!1)
const t=this.bModel.GetAssistRankData()
t.Count()>0&&(this.assistdamage.SetActive(!0),this.assistGrid.data_set(t))}else a.D.Inst_get().isHideAssistHeadIcon||(this.assisting.SetActive(!0),this.UpdataAssistPlayer())}
UpdataAssistPlayer(){const t=this.bModel.assistvo
null!=t&&(this.name.textSet(t.name),this.headIcon.spriteNameSet(g.Z.GetJobIcon(t.job,t.sex,!0)))}OnCloseClick(t,e){this.HideHeadIcon()}HideHeadIcon(t,e){
a.D.Inst_get().isHideAssistHeadIcon=!0,this.assisting.SetActive(!1)}OnGotoClick(t,e){const s=n.b.Inst.GetCurMap()
if(s.controllerType==p.N.WORLD_BOSS||s.controllerType==p.N.WORLD_BOSS_NEWHAND)u._.getInst().startHang()
else if(s.controllerType==p.N.BATTLEFIELD){const t=f.C.Inst().GetIdByMonsterId(this.bModel.assisttbossKey)
C.$.Inst().FindWay(t)}else if(s.controllerType==p.N.CROSS_BOSS_CLIENT){const t=S.I.Inst_get().GetCrossBossData(this.bModel.assisttbossKey)
t&&m.R.Inst_get().FindWay(t.sortId)}else if(s.controllerType==p.N.SCENE){const t=f.C.Inst().GetIdByMonsterId(this.bModel.assisttbossKey)
C.$.Inst().FindWay(t)}else u._.getInst().startHang()}})},81110:(t,e,s)=>{s.d(e,{m:()=>F})
var i,n=s(6847),l=s(83908),o=s(46282),a=s(86133),r=s(38045),h=s(98800),d=s(50089),c=s(62370),I=s(5924),u=s(57834),p=s(61911),_=s(5494),g=s(60130),m=s(98885),S=s(85602),f=s(11658),C=s(77796),T=s(84229),y=s(90496),A=s(1240),v=s(70850),D=s(15033),w=s(75696),B=s(28287),M=s(33314),b=s(87923),O=s(29839),R=s(48481),L=s(72208),G=s(18161),P=s(69967),E=s(5031),k=s(23296),N=s(8038),V=s(33065),x=s(20193)
let F=(0,n.s_)(_.I.WorldBossAssistSuccessPanel,o.Z.ui_bossassist_successpanel).register()(i=class extends((0,l.pA)(p.f)()){constructor(...t){super(...t),this.time=10,
this.intervalId=-1,this._degf_OnItemRefreshFun=null,this._degf_SetCountdown=null,this._degf_ExitCopyHandler=null}_initBinder(){super._initBinder(),
this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),this._degf_SetCountdown=()=>this.SetCountdown(),this._degf_ExitCopyHandler=(t,e)=>this.ExitCopyHandler(t,e)}
ShowCurrencyBar_get(){return B._.Hide}InitView(){super.InitView(),this.isExclusionPanel=!0,this.isKillAllExcluded=!0,this.myuigrid.SetInitInfo("ui_baseitem",null,w.j),
this.OtherTip.node.SetActive(!1),this.bgSp.widthSet(d.t.GetUIWidth()),g.O.SetAnchorPos(this.leftAnchor,!0,!1,0,!1),g.O.SetAnchorPos(this.rightAnchor,!1,!1,0,!1)}
OnItemRefreshFun(t){}OnAddToScene(){super.OnAddToScene(),this.UpdateView(),this.addLis(),E.T.inst_get().control.CloseBuffListPanel()}addLis(){
u.i.Get(this.leaveBtn.node).RegistonClick(this._degf_ExitCopyHandler)}RemoveLis(){u.i.Get(this.leaveBtn.node).RemoveonClick(this._degf_ExitCopyHandler)}UpdateView(){const t=new S.Z
let e=null,s=T.Q.Inst_get().BossReputationLimit_get(),i=C.v.Inst_get().bossTodayReputation
if(V.x.Inst_get().isForAsuramTask){e=(0,a.T)("成功协助战盟成员[e2a66a]")+(y.c.Inst.palyerName+(0,a.T)("[-]通关任务副本")),this.OtherTip.node.SetActive(!0)
const s=""
this.OtherTip.textSet(s)
const i=y.c.Inst.copyRewards
if(null!=i){const e=i.rewards
if(null!=e&&e.Count()>0){this.OtherTip.node.SetActive(!1)
let s=h.Y.Inst.PrimaryRoleInfo_get().Job_get()
s=M.Z.GetJobBaseValue(s)
let i=0
for(;i<e.Count();){const n=new N.x,l=e[i]
if((0,r.t2)(l,G.e)){const e=l
n.type=k.E.Item,n.value=e.itemModelId+(c.o.s_UNDER_COLON+e.num),e.valueInfo.LuaDic_ContainsKey("job")&&(n.job=e.valueInfo.job),
e.valueInfo.LuaDic_ContainsKey("showid")&&(n.showid=m.M.String2Int(e.valueInfo.showid)),n.jobValue_get()!=M.Z.NONE&&n.jobValue_get()!=s||(n.Parse(),
t.Add(n.bagItem_get().baseData_get()))}else if((0,r.t2)(l,P.A)){const e=l
n.type=k.E.EXP,n.value=b.l.GetLusuoLongStr(e.value,null),n.Parse(),t.Add(n.expitem_get())}else if((0,r.t2)(l,L.L)){const e=l
n.type=k.E.Currency,n.value=e.type+(c.o.s_UNDER_COLON+b.l.GetLusuoLongStr(e.num,null)),n.Parse(),t.Add(n.currencyItem_get())}i+=1}}}}else{this.OtherTip.node.SetActive(!1)
const n=x.D.Inst_get().assistsuccdata
if(null!=n&&null!=n.assistReward&&null!=n.assistReward.rewards){let e=0
for(;e<n.assistReward.rewards.Count();){const s=new N.x,i=new L.L
i.type=n.assistReward.rewards[e].type,i.num=n.assistReward.rewards[e].num,s.type=k.E.Currency,s.value=i.type+(c.o.s_UNDER_COLON+b.l.GetLusuoLongStr(i.num,null)),s.Parse(),
t.Add(s.currencyItem_get()),e+=1}}const l=C.v.Inst_get().GetAssistRes(n.assistCogId)
null!=l&&(l.assistType==f.i.ASURAM_QUEST_COPY?e=(0,a.T)("成功协助战盟成员[e2a66a]")+(n.assistederName+(0,
a.T)("[-]通关任务副本")):l.assistType==f.i.eAllianceTaskHandInItem?(s=T.Q.Inst_get().HandInItemReputationLimit_get(),i=C.v.Inst_get().itemTodayReputation,e=(0,
a.T)("成功协助战盟成员")+(n.assistederName+(0,a.T)("击败首领"))):e=l.assistType==f.i.eRebirthBoss?(0,a.T)("成功协助战盟成员")+(n.assistederName+(0,a.T)("击败转生首领")):(0,
a.T)("成功协助战盟成员")+(n.assistederName+(0,a.T)("击败首领")))}i>=s?(e+="\n今日协助贡献已达上限，无法获得奖励",this.myuigrid.data_set(null)):this.myuigrid.data_set(t),this.tipLbl.textSet(e),this.time=10,
this.SetCountdown(),this.intervalId=I.C.Inst_get().SetInterval(this._degf_SetCountdown,1e3,-1)}GetRewardItemData(t){let e=null
const s=v.g.Inst_get().GetItemByModleID(t.itemModelId)
if(null!=s&&s.baseData_get().BagItemType_get()==D.r.Equip){e=s.serverData_get().Clone()}else e=new R.t,e.modelId=t.itemModelId,e.num=t.num
const i=new A.Y
return i.serverData_set(e),i.baseData_get().isCanOperate=!1,i.baseData_get().isEquipCompare=!1,i}SetCountdown(){this.btntxt.textSet(`${(0,a.T)("确定")}（${this.time}）`),this.time-=1,
this.time<0&&(I.C.Inst_get().ClearInterval(this.intervalId),O.p.inst.IsInCopy()&&O.p.inst.ExitCopy(),V.x.Inst_get().CloseAssistSuccessView())}Clear(){super.Clear(),
I.C.Inst_get().ClearInterval(this.intervalId),this.RemoveLis(),V.x.Inst_get().isForAsuramTask=!1,y.c.Inst.copyRewards=null}ExitCopyHandler(t,e){
I.C.Inst_get().ClearInterval(this.intervalId),O.p.inst.ExitCopy(),V.x.Inst_get().CloseAssistSuccessView()}Destroy(){this.myuigrid.Destroy(),super.Destroy()}DoHide(){super.DoHide()}
DoReShow(){super.DoReShow()}})||i},24087:(t,e,s)=>{s.d(e,{j:()=>d})
var i,n=s(18998),l=s(83908),o=s(98885),a=s(87923)
const{ccclass:r,property:h}=n._decorator
let d=r("BossDropItem")(i=class extends((0,l.yk)()){InitView(){super.InitView()}SetData(t){
null==t||null==t.cfgData_get()||o.M.IsNullOrEmpty(t.cfgData_get().itemType)||"EQUIPMENT"!=t.cfgData_get().itemType||1==t.cfgData_get().equipStepLv?this.stepLvGO.SetActive(!1):(this.stepLvGO.SetActive(!0),
this.stepLv.textSet(`${a.l.getNumStr(t.cfgData_get().equipStepLv)}阶`)),0!=t.showtag?(this.tag.SetActive(!0),
1==t.showtag?this.tag.spriteNameSet("ryworldboss_sp_0046"):2==t.showtag?this.tag.spriteNameSet("ryworldboss_sp_0045"):3==t.showtag&&this.tag.spriteNameSet("ryworldboss_sp_0047")):this.tag.SetActive(!1),
this.ui_baseitem.SetData(t)}Clear(){this.ui_baseitem.Clear()}Destroy(){this.ui_baseitem.Destroy()}})||i},8621:(t,e,s)=>{
var i,n=s(6847),l=s(83908),o=s(46282),a=s(38836),r=s(50089),h=s(38935),d=s(5494),c=s(98130),I=s(85602),u=s(79534),p=s(92679),_=s(89144),g=s(43294),m=s(88934),S=s(12417),f=s(46233)
;(0,n.s_)(d.I.BossDropPanel,o.Z.ui_treasure_dropview).waitPrefab(o.Z.ui_treasure_dropinfo).register()(i=class extends((0,l.Ri)()){constructor(...t){super(...t),
this._degf_OnClose=null,this._degf_OnDropinfoRefreshFun=null}_initBinder(){super._initBinder(),this._degf_OnClose=(t,e)=>this.OnClose(t,e),
this._degf_OnDropinfoRefreshFun=t=>this.OnDropinfoRefreshFun(t)}InitView(){super.InitView(),this.msgGrid.SetInitInfo("ui_treasure_dropinfo",this._degf_OnDropinfoRefreshFun),
this.msgGrid.OnReposition_set(this.CreateDelegate(this.OnRepositon))}OnDropinfoRefreshFun(t){return t[0].getCNode(f.Y)}Clear(){
this.m_handlerMgr.RemoveClickEvent(this.closeBtn,this.CreateDelegate(this.OnClose)),super.Clear()}OnAddToScene(){super.OnAddToScene(),
this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.OnClose)),this.blogTip.SetActive(!1),this.noBlogTip.SetActive(!1)
const t=c.GF.INT(r.t.GetAdaptHeight())/720
this.collider.setScale(new u.P(1,t,1)),_.I.Inst_get().isCrossBattleView?this.UpdateCrossBossDropInfo():this.RareDropReq(),
this.m_handlerMgr.AddEventMgr(p.g.ACCESS_ICON_CLICK,this.CreateDelegate(this.OnClose))}UpdateCrossBossDropInfo(){const t=new I.Z,e=_.I.Inst_get().GetDropData()
for(const[s,i]of(0,a.V5)(e))t.Add(i)
this.msgGrid.data_set(t),this.blogTip.SetActive(t.Count()>0),this.noBlogTip.SetActive(0==t.Count())}RareDropReq(){const t=new g.y
h.C.Inst.F_SendMsg(t)}DropInfoHandle(){const t=new I.Z,e=S._.Inst().GetDropData()
for(const[s,i]of(0,a.V5)(e))t.Add(i)
this.msgGrid.data_set(t),this.blogTip.SetActive(t.Count()>0),this.noBlogTip.SetActive(0==t.Count())}OnRepositon(){this.scrollView.ResetPosition()}OnClose(t,e){
m.$.Inst().CloseDropView()}})},19592:(t,e,s)=>{
var i,n=s(18998),l=s(86133),o=s(23833),a=s(98800),r=s(68662),h=s(13687),d=s(5924),c=s(98130),I=s(98885),u=s(87923),p=s(92473),_=s(89144),g=s(33275),m=s(65550),S=s(85942),f=s(47041),C=s(98359),T=s(19276),y=s(88934),A=s(22046),v=s(12417)
n._decorator.ccclass("BossRefreshView")(i=class extends C.k{constructor(){super(),this.tModel=null,this.rInfo=null,this.cfg=null,this.objRes=null,this.secs=0,this.intervalId=-1,
this.intervalId2=-1,this._degf_CloseTip=null,this._degf_CountDown=null,this._degf_Handle=null,this.intervalId1=null,this._degf_CloseTip=()=>this.CloseTip(),
this._degf_CountDown=()=>this.CountDown(),this._degf_Handle=t=>this.Handle(t)}InitView(){super.InitView(),this.rInfo=a.Y.Inst.PrimaryRoleInfo_get(),this.tModel=v._.Inst()}Clear(){
d.C.Inst_get().ClearInterval(this.intervalId),this.intervalId=-1,this.ClearCloseTip(),this.RemoveLis(),super.Clear()}Destroy(){super.Destroy()}AddLis(){super.AddLis()}RemoveLis(){
super.RemoveLis()}OnCloseBtnHandle(){d.C.Inst_get().ClearInterval(this.intervalId),this.intervalId=-1,this.ClearCloseTip(),f.N.Inst_get().BossRefreshTipDeQueue()}OnOptBtnHandle(){
if(null==this.cfg){const t=_.I.Inst_get().GetCrossBossData(this.tModel.refreshBossId)
if(t){const e=t.info
c.GF.INT(.001*e.refreshTime.ToNum()-r.D.serverTime_get())<=0?p.R.Inst_get().GotoBoss(t):p.R.Inst_get().OpenRootView(g.E.CROSS_BOSS,this.tModel.refreshBossId)}return}let t=null
h.b.Inst.currentMapId_get()!=this.cfg.mapId_get()?y.$.Inst().OpenById(this.cfg.id_get()):this.cfg.type_get()==A.l.WORLDBOSS&&(0==v._.Inst().WorldBossTired_get()?(t=new S.N,
t.showText=(0,l.T)("您当前的疲劳值已满，无法对BOSS之家的怪物造成伤害，是否确认前往？"),t.okhandler=this._degf_Handle,t.tipstype=2,t.okText=(0,l.T)("确定"),
m.y.inst.OpenCommonMessageTips(t)):y.$.Inst().Transport(this.cfg.id_get())),d.C.Inst_get().ClearInterval(this.intervalId),this.ClearCloseTip(),this.intervalId=-1,
f.N.Inst_get().BossRefreshTipDeQueue()}Handle(t){y.$.Inst().Transport(this.cfg.id_get())}SetData(){let t
if(this.AddLis(),this.cfg=T.C.Inst().GetItemByMonsterId(this.tModel.refreshBossId),this.objRes=o.a.getInst().getObjById(this.tModel.refreshBossId),
this.fatherView.descTxt.textSet(`[DBA968]${this.objRes.name}[-]`),this.fatherView.baseItem.node.SetActive(!1),this.fatherView.optBtn.SetText(I.M.DealRichTextOutline("点击前往")),
this.fatherView.SetIconByAtlasAndName("touxiang",this.objRes.headResources,.6,null,!0),null==this.cfg){const e=_.I.Inst_get().GetCrossBossData(this.tModel.refreshBossId)
e&&(t=e.info,this.secs=c.GF.INT(.001*t.refreshTime.ToNum()-r.D.serverTime_get()))}else t=this.tModel.AllBossInfo_get()[this.objRes.id],
this.secs=c.GF.INT(.001*t.refreshTime.ToNum()-r.D.serverTime_get())
null!=t?(this.secs=c.GF.INT(.001*t.refreshTime.ToNum()-r.D.serverTime_get()),this.secs<=0?this.CloseTip():(this.CountDown(),d.C.Inst_get().ClearInterval(this.intervalId),
this.intervalId=d.C.Inst_get().SetInterval(this._degf_CountDown,1e3))):this.CloseTip()}CloseTip(){f.N.Inst_get().BossRefreshTipDeQueue()}CountDown(){
let t=u.l.OneDataFormat2(this.secs)
""!=t&&(t=`[FF4B58](${t})[-]`),this.fatherView.descTxt.textSet(`[DBA968]${this.objRes.name}[-]${t}`),this.secs-=1,this.secs<0&&(d.C.Inst_get().ClearInterval(this.intervalId),
this.intervalId=-1,this.ClearCloseTip(),this.intervalId1=d.C.Inst_get().SetInterval(this._degf_CloseTip,1e4,1))}ClearCloseTip(){
null!=this.intervalId1&&-1!=this.intervalId1&&d.C.Inst_get().ClearInterval(this.intervalId1)}})},12648:(t,e,s)=>{s.d(e,{I:()=>u})
var i=s(83908),n=s(38836),l=s(86133),o=s(23833),a=s(68404),r=s(68662),h=s(98130),d=s(88653),c=s(73581),I=s(19276)
class u extends((0,i.pA)(a.B)()){constructor(...t){super(...t),this.tomb=null,this.switchLine=!1}Tomb_get(){return this.tomb}Tomb_set(t){this.tomb=t,this.SetHead(),
this._setHeadRenderByCharacter(t)}InitView(){super.InitView(),this.OnAddToScene()}Destory(){super.Destory()}SetHead(){if(null!=this.Tomb_get()){
o.a.getInst().getObjById(this.tomb.bossId)
let t=null
for(const[e,s]of(0,n.vy)(I.C.Inst().BossInfoMap))if(t=I.C.Inst().BossInfoMap[e],t.monsterId_get()==this.tomb.bossId){this.switchLine=t.switchedLine_get(),
this.tomb.switchLine=this.switchLine
break}this.UpdateName(),this.UpdateUIPos()}}UpdateName(){this.nameLabel.textSet(this.tomb.BossName)}UpdateRefreshTime(){o.a.getInst().getObjById(this.tomb.bossId)
const t=h.GF.INT(.001*this.tomb.refreshTime.ToNum()-r.D.serverTime_get())
this.SetRefreshTime(this.refreshTime,t)}SetRefreshTime(t,e){if(e<0)t.textSet((0,l.T)("已刷新")),t.SetColor(new d.I(27/255,236/255,28/255,1))
else if(e<60)c.o.Inst_get().IsInRolandValley()?t.textSet((0,l.T)(`${e}秒后刷新`)):t.textSet((0,l.T)("1分钟内刷新")),t.SetColor(new d.I(27/255,236/255,28/255,1))
else{const s=h.GF.INT(e/60+1)
this.switchLine,t.textSet(s+(0,l.T)("分钟后刷新")),t.SetColor(new d.I(212/255,52/255,36/255,1))}}UpdateUIPos(){this._SetPosByCharacter(this.tomb)}}},1809:(t,e,s)=>{s.d(e,{g:()=>_})
var i,n=s(18998),l=s(83908),o=s(96098),a=s(68662),r=s(5924),h=s(9057),d=s(98885),c=s(87923),I=s(92473),u=s(55552),p=s(75517)
let _=n._decorator.ccclass("CrossBossListItem")(i=class extends((0,l.pA)(h.x)()){constructor(...t){super(...t),this.lvOk=!1,this.intervalId=-1,this.bossData=null,this.cfg=null,
this.objRes=null}InitView(){super.InitView()}OnSearchClick(t,e){null!=p.W.inst_get().view||o.B.Inst.isOpenMaskStart||I.R.Inst_get().BossIsAlive(this.bossData)}SetData(t){
this.m_handlerMgr.AddClickEvent(this.gotoBtn,this.CreateDelegate(this.CreateDelegate(this.OnSearchClick)))
const e=t
this.bossData=e,this.cfg=e.crossCfg,this.objRes=u.h.GetInst().GetObjResBySpawnId(e.crossCfg.spawnId),this.SetBossInfo()}SetBossInfo(){let t=""
this.bossData.info.refreshTime.ToNum()-a.D.serverMSTime_get()<=0?(this.gotoBtn.node.SetActive(!0),this.reviveTime.node.SetActive(!1),t="[CECCC5]"):(this.gotoBtn.node.SetActive(!1),
this.reviveTime.node.SetActive(!0),t="[8E8279]",-1==this.intervalId&&(this.intervalId=r.C.Inst_get().SetInterval(this.CreateDelegate(this.SetRevive),1e3),this.SetRevive())),
this.bossName.textSet(`${t}【${d.M.IntToString(this.objRes.level)}级】${this.objRes.name}[-]`)}SetRevive(){let t=""
const e=this.bossData.info.refreshTime.ToNum()-a.D.serverMSTime_get()
e<=0?(this.ClearInterval(),this.SetBossInfo()):t=c.l.GetDateFormatEX(e/1e3,!0),this.reviveTime.textSet(t)}ClearInterval(){r.C.Inst_get().ClearInterval(this.intervalId),
this.intervalId=-1}Clear(){this.ClearInterval(),super.Clear()}Destroy(){}Test1(){return!0}S_Test(){return!0}})||i},42650:(t,e,s)=>{s.d(e,{n:()=>T})
var i,n=s(6847),l=s(83908),o=s(46282),a=s(86133),r=s(38045),h=s(98800),d=s(61911),c=s(5494),I=s(98885),u=s(31192),p=s(77796),_=s(75696),g=s(67885),m=s(87923),S=s(74657),f=s(66837),C=s(20193)
let T=(0,n.s_)(c.I.BossMemberDamageTip,o.Z.ui_bossassisttip).waitPrefab(g.S.modulePathList).register()(i=class extends((0,l.pA)(d.f)()){constructor(...t){super(...t),
this.model=null,this.info=null,this.isAsuramTask=!1,this._degf_OnBoxClick=null,this._degf_OnEnsureBtnClick=null,this._degf_OnRewardItemRefreshFun=null}_initBinder(){
super._initBinder(),this._degf_OnBoxClick=(t,e)=>this.OnBoxClick(t,e),this._degf_OnEnsureBtnClick=(t,e)=>this.OnEnsureBtnClick(t,e),
this._degf_OnRewardItemRefreshFun=t=>this.OnRewardItemRefreshFun(t)}InitView(){super.InitView(),this.myGrid.SetInitInfo("ui_baseitem",null,_.j),this.model=C.D.Inst_get()}
OnRewardItemRefreshFun(t){}OnAddToScene(){if(this.AddLis(),this.rewardScrollView.SetActive(!1),null!=this.model.asuramAssistData){this.isAsuramTask=!0,this.item.node.SetActive(!1)
const t=C.D.Inst_get().asuramAssistData
this.detailLbl.textSet(t.txt1),this.rewardScrollView.SetActive(!0),this.myGrid.data_set(t.modelItems),this.txtLabel2.node.SetActive(!0),this.txtLabel2.textSet(t.txt2)}else{
if(this.info=this.model.assistMsgInfo,null==this.info)return
let t=(0,a.T)("[0f66c8]{0}[-]正在攻击首领[047104]{1}[-]\n协助成功可获得以下奖励：")
const e=this.info.sendPlayerName,s=this.info.bossName,i=this.info.bossRecommPower.ToNum()
h.Y.Inst.PrimaryRoleInfo_get().TotalBattleScore_get()<i?this.warnMes.textSet(m.l.SubstituteEx2("推荐战力：{0}，当前可能比较危险）",(0,r.tw)(i))):this.warnMes.textSet(""),t=I.M.Replace(t,"{0}",e),
t=I.M.Replace(t,"{1}",s),this.detailLbl.textSet(t),this.item.node.SetActive(!1),this.rewardScrollView.SetActive(!0)
const n=p.v.Inst_get().GetAssistRes(this.info.assistCfgId)
if(n){const t=S.A.GetReward(n.assistReward)
this.myGrid.data_set(t.GetRewardBaseItemList())}}}AddLis(){this.m_handlerMgr.AddClickEvent(this.closeBtn.node,this.CreateDelegate(this.OnBoxClick)),
this.m_handlerMgr.AddClickEvent(this.cancleBtn.node,this.CreateDelegate(this.OnBoxClick)),
this.m_handlerMgr.AddClickEvent(this.helpBtn.node,this.CreateDelegate(this.OnEnsureBtnClick))}RemoveLis(){}OnEnsureBtnClick(t,e){
this.isAsuramTask?this.JugeEnterTeam():(this.model.AssistOther(this.info.assistId),f.x.Inst_get().Close(),u.d.Inst_get().CloseAssistBasePanel())}JugeEnterTeam(){
C.D.Inst_get().asuramAssistData.teamId,h.Y.Inst.PrimaryRoleInfo_get()
f.x.Inst_get().Close()}okHandler(t){}OnBoxClick(t,e){f.x.Inst_get().Close()}Clear(){this.RemoveLis(),C.D.Inst_get().asuramAssistData=null,super.Clear()}Destroy(){
this.myGrid.Destroy(),super.Destroy()}})||i},46233:(t,e,s)=>{s.d(e,{Y:()=>T})
var i,n=s(18998),l=s(83908),o=s(86133),a=s(9057),r=s(57834),h=s(98885),d=s(85602),c=s(21554),I=s(63076),u=s(87923),p=s(48933),_=s(33138),g=s(47786),m=s(19276),S=s(12417)
const{ccclass:f,property:C}=n._decorator
let T=f("DropInfoSet")(i=class extends((0,l.pA)(a.x)()){constructor(...t){super(...t),this.itemId=0,this.serverData=null,this.tModel=null,this._degf_OnItemClick=null}_initBinder(){
super._initBinder(),this._degf_OnItemClick=(t,e)=>this.OnItemClick(t,e)}InitView(){super.InitView(),this.tModel=S._.Inst()}AddLis(){
r.i.Get(this.item.node).RegistonClick(this._degf_OnItemClick)}RemoveLis(){r.i.Get(this.item.node).RemoveonClick(this._degf_OnItemClick)}SetData(t){const e=t
this.AddLis(),this.time.textSet(u.l.GetDateTime2(e.info.time.ToNum())),1==e.type?this.topSprite.node.SetActive(!0):this.topSprite.node.SetActive(!1),this.SetInfoText(e.info),
this.SetInfoItem(e.info)}OnItemClick(t,e){const s=new I.M(this.itemId,this.serverData)
s.isCanOperate=!1,s.isEquipCompare=!1,c.J.Inst_get().OpenTipView(s)}Clear(){this.RemoveLis()}Destroy(){}SetInfoText(t){const e=m.C.Inst().GetItemByMonsterId(t.modelId)
let s=1
null!=e&&(s=e.quality_get())
let i=null
if(111021==t.i18nld||111022==t.i18nld){this.item.node.SetActive(!1)
const e=g.x.Inst().getItemById(t.i18nld),s=u.l.SetGodMasterPrefix(t.param[3],null,null,t.item.equipRes),n=new d.Z([t.param[1],t.param[2],s])
i=u.l.Substitute(e.sys_messsage,n)}else this.item.node.SetActive(!0),i="[8C4F00][url=player]",i+=t.param[1],i+=(0,o.T)("[/url][-] 在"),i+=t.param[2],i+=`${(0,o.T)("击败")}【`,
i+=t.param[3],i+=(0,o.T)("】获得")
i=h.M.TransRichTextHref(i),this.info.textSet(i)}SetInfoItem(t){if(111021==t.i18nld||111022==t.i18nld)this.item.node.SetActive(!1)
else{this.item.node.SetActive(!0),this.itemId=h.M.String2Int(t.param[4]),this.serverData=t.item,this.item.textSet(`【${_.f.Inst().getItemById(this.itemId).name}】`)
_.f.Inst().getItemById(this.itemId)
const e=new I.M(this.itemId,this.serverData)
e.isCanOperate=!1,e.isEquipCompare=!1
const s=u.l.GetQuality(e)
this.item.SetColor(u.l.getColorByQuality(s)),p.I.calVec0.Set(this.info.node.transform.GetLocalPosition().x+this.info.width(),this.info.node.transform.GetLocalPosition().y,0),
this.item.node.transform.SetLocalPosition(p.I.calVec0)}}})||i},27610:(t,e,s)=>{s.d(e,{X:()=>O})
var i,n=s(18998),l=s(83908),o=s(86133),a=s(38045),r=s(98800),h=s(28475),d=s(97461),c=s(36241),I=s(68662),u=s(62370),p=s(5924),_=s(9057),g=s(57834),m=s(88653),S=s(94148),f=s(77796),C=s(92984),T=s(92679),y=s(87923),A=s(61149),v=s(71822),D=s(8776),w=s(88883),B=s(54383),M=s(65550),b=s(20193)
let O=n._decorator.ccclass("MemberDamageItem")(i=class extends((0,l.pA)(_.x)()){constructor(...t){super(...t),this.bModel=null,this.dmgData=null,this.whiteColor=null,
this.tipEmergeIntervalId=-1,this.startTime=0,this.targetRole=null,this.greenColor=null,this._degf_OnBtnClick=null,this._degfOnBoxClick_=null,this._degfOnToAttackClick_=null,
this._degfOnAttackingClick_=null,this._degfOnRevengeClick_=null,this._degfOnAttackedListUpdate_=null,this._degf_OnPkStageUpdate=null,this._degf_OnPkModelUpdate=null,
this._degf_ShowOrHideRevengeTip=null,this.hidePk=!1,this.width=null}_initBinder(){super._initBinder(),this.whiteColor=new m.I,this.greenColor=new m.I,
this._degf_OnBtnClick=(t,e)=>this.OnBtnClick(t,e),this._degfOnBoxClick_=(t,e)=>this.OnBoxClick(t,e),this._degfOnToAttackClick_=(t,e)=>this.OnToAttackClick(t,e),
this._degfOnAttackingClick_=(t,e)=>this.OnAttackingClick(t,e),this._degfOnRevengeClick_=(t,e)=>this.OnRevengeClick(t,e),
this._degfOnAttackedListUpdate_=t=>this.OnAttackedListUpdate(t),this._degf_OnPkStageUpdate=t=>this.OnPkStageUpdate(t),this._degf_OnPkModelUpdate=t=>this.OnPkModelUpdate(t),
this._degf_ShowOrHideRevengeTip=()=>this.ShowOrHideRevengeTip()}InitView(){super.InitView(),this.bModel=b.D.Inst_get(),this.greenColor=new m.I(52/255,200/255,83/255).Clone(),
this.whiteColor=new m.I(225/255,214/255,196/255).Clone(),this.width=this.bg.width()}Clear(){this.removeLis()}Destroy(){this.ResetTimer()}addLis(){
g.i.Get(this.btnAssist.node).RegistonClick(this._degf_OnBtnClick),g.i.Get(this.boxcoll.node).RegistonClick(this._degfOnBoxClick_),
g.i.Get(this.toAttackBtn.node).RegistonClick(this._degfOnToAttackClick_),g.i.Get(this.attackingBtn).RegistonClick(this._degfOnAttackingClick_),
g.i.Get(this.revengeBtn).RegistonClick(this._degfOnRevengeClick_),d.i.Inst.AddEventHandler(T.g.ATTACKED_LIST_UPDATE,this._degfOnAttackedListUpdate_),
d.i.Inst.AddEventHandler(T.g.PKMODEL_UPDATE,this._degf_OnPkModelUpdate),B.k.Inst_get().AddEventHandler(D.C.PK_STATE_CHANGE,this._degf_OnPkStageUpdate)}removeLis(){
g.i.Get(this.btnAssist.node).RemoveonClick(this._degf_OnBtnClick),g.i.Get(this.boxcoll.node).RemoveonClick(this._degfOnBoxClick_),
g.i.Get(this.toAttackBtn.node).RemoveonClick(this._degfOnToAttackClick_),g.i.Get(this.attackingBtn).RemoveonClick(this._degfOnAttackingClick_),
g.i.Get(this.revengeBtn).RemoveonClick(this._degfOnRevengeClick_),B.k.Inst_get().RemoveEventHandler(D.C.PK_STATE_CHANGE,this._degf_OnPkStageUpdate),
d.i.Inst.RemoveEventHandler(T.g.PKMODEL_UPDATE,this._degf_OnPkModelUpdate),d.i.Inst.RemoveEventHandler(T.g.ATTACKED_LIST_UPDATE,this._degfOnAttackedListUpdate_)}OnBtnClick(t,e){
if(this.bModel.isAssistOther())r.Y.Inst.PrimaryRole_get().StopPathing(),c._.getInst().endHang(),this.bModel.CancelAssist()
else if(0==this.dmgData.vo.type){const t=f.v.Inst_get().GetAssistId(this.dmgData.vo.id)
this.bModel.AssistOther(t)}}OnBoxClick(t,e){}OnToAttackClick(t,e){this.OnAttackingClick()}OnAttackOne(t){if(null==t)return void M.y.inst.ClientSysStrMsg((0,o.T)("目标不在视野范围，无法选中"))
if(t.Isdead_get())return void M.y.inst.ClientSysMessage(105016)
const e=r.Y.Inst.PrimaryRole_get().GetPos(),s=t.GetPos()
;(s.x-e.x)*(s.x-e.x)+(s.z-e.z)*(s.z-e.z)>r.Y.Inst.SelectMaxDis_get()*r.Y.Inst.SelectMaxDis_get()?M.y.inst.ClientSysMessage(111020):t.Roleinfo_get().isHaveAlliance_get()&&r.Y.Inst.PrimaryRoleInfo_get().isHaveAlliance_get()&&t.Roleinfo_get().AsuramId_get().Equal(r.Y.Inst.PrimaryRoleInfo_get().AsuramId_get())?B.k.Inst_get().pkModel==w.j.PEACE_MODEL?M.y.inst.ClientSysStrMsg((0,
o.T)("和平模式下无法攻击同盟玩家")):B.k.Inst_get().pkModel==w.j.GUILD_MODEL?M.y.inst.ClientSysStrMsg((0,
o.T)("强制模式下无法攻击同盟玩家")):B.k.Inst_get().pkModel==w.j.SLAUGHTER_MODEL&&(M.y.inst.ClientSysStrMsg((0,o.T)("请注意，您正在攻击同战盟的玩家")),
r.Y.Inst.attackRole(t,null)):this.ChangeModelAndAttack(t,w.j.GUILD_MODEL)}OnAttackingClick(t,e){if(this.badge.active)return void M.y.inst.ClientSysMessage(11043019)
if(C.j.Inst_get().model.HasRolandBadgeBuff(r.Y.Inst.PlayerId_get()))return void M.y.inst.ClientSysMessage(11043020)
let s=r.Y.Inst.CurTarget_get();(0,a.t2)(s,h.u)||(s=null)
let i=null
i=0==this.dmgData.vo.type?this.dmgData.vo.id:this.dmgData.vo.teamroleid
const n=s,l=r.Y.Inst.getRoleById(i)
if(null==s?s=l:null==l||s==l||null!=n.Roleinfo_get()&&!n.Roleinfo_get().leaderId.Equal(l.Roleinfo_get().leaderId)||(s=l),s){if(s.Isdead_get()&&null!=s.Roleinfo_get()){
const t=r.Y.Inst.GetRolesByAccountIndex(s.Roleinfo_get().accountindex)
for(let e=0;e<=t.count-1;e++)if(!t[e].Isdead_get()){s=t[e]
break}}this.OnAttackOne(s)}}OnRevengeClick(t,e){let s=null
if(0==this.dmgData.vo.type)s=this.dmgData.vo.id
else{const t=A.k.inst.attackedList
let e=t.count-1
for(;e>=0;){const i=t[e]._attacker.GetGameId()
let n=0
for(;n<this.dmgData.vo.memberIds.count;){const t=this.dmgData.vo.memberIds[n]
if(t.Equal(i)){s=t
break}n+=1}if(null!=s)break
e-=1}}if(null!=s){let t=r.Y.Inst.getRoleById(s)
if(t.Isdead_get()&&null!=t.Roleinfo_get()){const e=r.Y.Inst.GetRolesByAccountIndex(t.Roleinfo_get().accountindex)
for(let s=0;s<=e.count-1;s++)if(!e[s].Isdead_get()){t=e[s]
break}}if(null==t)return void M.y.inst.ClientSysStrMsg((0,o.T)("目标不在视野范围，无法选中"))
if(t.Isdead_get())return void M.y.inst.ClientSysMessage(105016)
const e=r.Y.Inst.PrimaryRole_get().GetPos(),i=t.GetPos()
if((i.x-e.x)*(i.x-e.x)+(i.z-e.z)*(i.z-e.z)>r.Y.Inst.SelectMaxDis_get()*r.Y.Inst.SelectMaxDis_get())return void M.y.inst.ClientSysMessage(111020)
const n=(0,a.Z)(t,h.u)
n.Roleinfo_get().isHaveAlliance_get()&&r.Y.Inst.PrimaryRoleInfo_get().isHaveAlliance_get()&&n.Roleinfo_get().AsuramId_get().Equal(r.Y.Inst.PrimaryRoleInfo_get().AsuramId_get())?this.ChangeModelAndAttack(t,w.j.SLAUGHTER_MODEL):this.ChangeModelAndAttack(t,w.j.GUILD_MODEL)
}}ChangeModelAndAttack(t,e){B.k.Inst_get().pkModel==e?r.Y.Inst.attackRole(t):(this.targetRole=t,this.bModel.attackRoleAfterPkModelChange=!0,v.g.Inst.CM_ChangeSurvivalModeReq(e))}
OnAttackedListUpdate(t){this.SetAttackAndRevenge()}OnPkStageUpdate(t){this.SetAttackAndRevenge()}OnPkModelUpdate(t){
this.bModel.attackRoleAfterPkModelChange&&null!=this.targetRole&&(r.Y.Inst.attackRole(this.targetRole),this.bModel.attackRoleAfterPkModelChange=!1)}SetRankLbl(){if(this.index<3){
const t=`ryworldboss_sp_00${Number(u.o.NumToString(1+this.index,0))+25}`
this.rankicon.spriteNameSet(t),this.rankicon.node.SetActive(!0),this.rankLbl.node.SetActive(!1)}else this.rankLbl.textSet(u.o.NumToString(this.index+1,0)),
this.rankLbl.node.SetActive(!0),this.rankicon.node.SetActive(!1)}SetData(t){this.index=this.node.__index,this.addLis(),this.dmgData=t,this.nameLbl.textSet(this.dmgData.vo.name),
this.dmgData.coulddrag?this.boxcoll.enabled=!0:this.boxcoll.enabled=!1,this.SetRankLbl(),this.SetAllyMark(),this.setNameColor(),this.SetProgressBg(),this.SetBadgeMark(),
this.SetAttackAndRevenge()}SetAttackAndRevenge(){const t=r.Y.Inst.CurTarget_get()
if(0==this.dmgData.vo.type)if(r.Y.Inst.IsMultiPrimaryId(this.dmgData.vo.id)||S.b.Inst_get().InAsuramMap()||this.hidePk)this.attackingBtn.SetActive(!1),
this.revengeBtn.SetActive(!1),this.toAttackBtn.SetActive(!1),this.ResetTimer()
else{if(this.badge.active||C.j.Inst_get().model.HasRolandBadgeBuff(r.Y.Inst.PlayerId_get()))return this.attackingBtn.SetActive(!1),this.revengeBtn.SetActive(!1),
this.toAttackBtn.SetActive(!0),this.toAttackSp1.SetActive(!1),this.toAttackSp2.SetActive(!0),void this.ResetTimer()
const e=(0,a.Z)(t,h.u)
null!=e&&this.dmgData.vo.name==e.Roleinfo_get().Name_get()?(this.toAttackBtn.SetActive(!1),this.attackingBtn.SetActive(!0),this.revengeBtn.SetActive(!1),
this.ResetTimer()):B.k.Inst_get().IsExistPkList(this.dmgData.vo.id)?(this.toAttackBtn.SetActive(!1),this.attackingBtn.SetActive(!1),
this.revengeBtn.activeInHierarchy||this.SetTimer(),this.revengeBtn.SetActive(!0)):(this.attackingBtn.SetActive(!1),this.revengeBtn.SetActive(!1),this.toAttackBtn.SetActive(!0),
this.toAttackSp1.SetActive(!0),this.toAttackSp2.SetActive(!1),this.ResetTimer())
}else if(1==this.dmgData.vo.type)if(this.hidePk||r.Y.Inst.PrimaryRoleInfo_get().isHaveTeam_get()&&r.Y.Inst.PrimaryRoleInfo_get().teamId_get().Equal(this.dmgData.vo.id))this.attackingBtn.SetActive(!1),
this.revengeBtn.SetActive(!1),this.toAttackBtn.SetActive(!1),this.ResetTimer()
else{let e=!1,s=!1,i=0
for(;i<this.dmgData.vo.memberIds.count;){const n=this.dmgData.vo.memberIds[i]
A.k.inst.IsAttacker(n)&&(e=!0),null!=t&&n.Equal(t.GetGameId())&&(s=!0),i+=1}s?(this.attackingBtn.SetActive(!0),this.revengeBtn.SetActive(!1),this.toAttackBtn.SetActive(!1),
this.ResetTimer()):e?(this.attackingBtn.SetActive(!1),this.revengeBtn.activeInHierarchy||this.SetTimer(),this.revengeBtn.SetActive(!0),
this.toAttackBtn.SetActive(!1)):(this.attackingBtn.SetActive(!1),this.revengeBtn.SetActive(!1),this.toAttackBtn.SetActive(!0),this.ResetTimer())}}SetTimer(){this.ResetTimer(),
this.startTime=I.D.serverTime_get(),this.tipEmergeIntervalId=p.C.Inst_get().SetInterval(this._degf_ShowOrHideRevengeTip,1e3,-1),this.revengeTip.SetActive(!0),
0==this.dmgData.vo.type?this.revengeTipContent.textSet((0,o.T)("有玩家攻击你，立即反击")):this.revengeTipContent.textSet((0,o.T)("有队伍攻击你，立即反击"))}ResetTimer(){this.revengeTip.SetActive(!1),
p.C.Inst_get().ClearInterval(this.tipEmergeIntervalId),this.tipEmergeIntervalId=-1}ShowOrHideRevengeTip(){(I.D.serverTime_get()-this.startTime)%5<=3?(this.revengeTip.SetActive(!0),
0==this.dmgData.vo.type?this.revengeTipContent.textSet((0,o.T)("有玩家攻击你，立即反击")):this.revengeTipContent.textSet((0,o.T)("有队伍攻击你，立即反击"))):this.revengeTip.SetActive(!1)}SetAllyMark(){
if(1==this.dmgData.vo.type)this.ally.SetActive(!1)
else{const t=r.Y.Inst.PrimaryRoleInfo_get()
r.Y.Inst.IsMultiPrimaryId(this.dmgData.vo.id)?this.ally.SetActive(!1):t.isHaveAlliance_get()&&t.AsuramId_get().Equal(this.dmgData.vo.asuramId)?this.ally.SetActive(!0):this.ally.SetActive(!1)
}}SetBadgeMark(){C.j.Inst_get().model.HasRolandBadgeBuff(this.dmgData.vo.id)?(this.badge.SetActive(!0),this.toAttackSp1.SetActive(!1),
this.toAttackSp2.SetActive(!0)):(this.badge.SetActive(!1),this.toAttackSp1.SetActive(!0),this.toAttackSp2.SetActive(!1))}SetAssistBtn(){
if(1==this.dmgData.vo.type)return void this.btnAssist.node.SetActive(!1)
const t=r.Y.Inst.PrimaryRoleInfo_get()
t.Id_get().Equal(this.dmgData.vo.id)?this.btnAssist.node.SetActive(!1):t.isHaveAlliance_get()&&t.AsuramId_get().Equal(this.dmgData.vo.asuramId)?this.bModel.SomeoneAssistMe()?this.btnAssist.node.SetActive(!1):this.bModel.isAssistOther()&&(this.bModel.MeAssistHe(this.dmgData.vo.id)?(this.btnAssist.node.SetActive(!0),
this.btnAssist.normalSpriteSet("mainui_bt_0076")):this.btnAssist.node.SetActive(!1)):this.btnAssist.node.SetActive(!1)}SetProgressBg(){const t=this.dmgData.vo.damage.ToNum()
if(0==this.dmgData.index)this.bg.widthSet(this.width)
else{let e
e=2==this.dmgData.dmgType?this.bModel.GetAssistFirstOneDamage():this.bModel.GetFirstOneDamage()
const s=t/e
this.bg.widthSet(s*this.width)}this.damageLbl.textSet(y.l.GetRuleDecimalValByFloorToInt(t,1))}setNameColor(){const t=r.Y.Inst.PrimaryRoleInfo_get()
if(1==this.dmgData.vo.type){if(t.isHaveTeam_get()&&t.teamId_get().Equal(this.dmgData.vo.id))return this.nameLbl.SetColor(this.greenColor),
void this.bg.spriteNameSet("ryworldboss_sp_0031")
if(this.bModel.isAssistOther()&&this.bModel.MeAssistHe(this.dmgData.vo.teamroleid))return this.nameLbl.SetColor(this.greenColor),void this.bg.spriteNameSet("ryworldboss_sp_0031")}
if(0==this.dmgData.vo.type){if(r.Y.Inst.IsMultiPrimaryId(this.dmgData.vo.id))return this.nameLbl.SetColor(this.greenColor),void this.bg.spriteNameSet("ryworldboss_sp_0031")
if(this.bModel.isAssistOther()&&this.bModel.assistedId.Equal(this.dmgData.vo.id))return this.nameLbl.SetColor(this.greenColor),void this.bg.spriteNameSet("ryworldboss_sp_0031")}
this.bg.spriteNameSet("ryworldboss_sp_0032"),this.nameLbl.SetColor(this.whiteColor)}})||i},17279:(t,e,s)=>{s.d(e,{b:()=>z})
var i,n=s(18998),l=s(83908),o=s(93984),a=s(32076),r=s(38836),h=s(86133),d=s(98800),c=s(57121),I=s(97960),u=s(97461),p=s(98958),_=s(2689),g=s(13687),m=s(5924),S=s(76544),f=s(57834),C=s(95721),T=s(85602),y=s(52212),A=s(79534),v=s(67585),D=s(19471),w=s(11658),B=s(77796),M=s(75696),b=s(92679),O=s(87923),R=s(89144),L=s(37648),G=s(55492),P=s(47786),E=s(96713),k=s(65550),N=s(19276),V=s(88934),x=s(20193),F=s(22046),U=s(12417),H=s(33065),j=s(34923),W=s(24087),Y=s(1809),q=s(27610)
let z=n._decorator.ccclass("MemberDamageView")(i=class extends((0,l.Ri)()){constructor(...t){super(...t),this.tModel=null,this.bModel=null,this.intervalId=-1,this.limit=1e4,
this.countDown=0,this.showui=!1,this._degf_CountDownFun=null,this._degf_OnAskForHelp=null,this._degf_OnBossListItemRefreshFun=null,this._degf_OnTipBtnClick=null,
this._degf_OnTipMaskClick=null,this._degf_TeamUpdate=null,this._degf_AsuramIdChange=null,this._degf_FunctionOpen=null,this._degf_OnUpdateTiredInfo=null,
this._degf_OnBossRemove=null,this._degf_CheckDropDelete=null,this._degf_OnRewardRefreshFun=null,this._degf_OnRefreshAssitData=null,this.vec2Zero=null,this.resetpos=null,
this.lastValue=null,this.lastCount=null,this.delayExecutor=null,this._degf_RefresFunItem=null,this.funUpdateBar=null,this.myProgressBarWidth=null,this.bUpdateTiredInfoDirty=null,
this.curBossTiredConsume=null,this.rInfo=null,this.roleInfo=null,this.bAncientBoss=null,this.HadAskHelp=null,this.bForceBossList=null,this.bShowBossList=null,
this.roleTiredVal=null,this.hasOnShow=!1}_initBinder(){super._initBinder(),this._degf_OnAskForHelp=(t,e)=>this.OnAskForHelp(t,e),
this._degf_OnTipBtnClick=(t,e)=>this.OnTipBtnClick(t,e),this._degf_OnTipMaskClick=(t,e)=>this.OnTipMaskClick(t,e),this._degf_TeamUpdate=t=>this.TeamUpdate(t),
this._degf_AsuramIdChange=t=>this.AsuramIdChange(t),this._degf_FunctionOpen=t=>this.FunctionOpen(),this._degf_OnUpdateTiredInfo=t=>this.UpdateTiredInfo(t),
this._degf_OnBossRemove=t=>this.OnBossRemove(t),this._degf_CheckDropDelete=t=>this.CheckDropDelete(),this._degf_OnRewardRefreshFun=t=>this.OnRewardRefreshFun(t),
this._degf_OnRefreshAssitData=t=>this.UpdateAskBtnShow()}InitView(){super.InitView(),this.vec2Zero=new y.F(0,0),this.resetpos=new A.P(-102,99,0),this.lastValue=0,this.lastCount=0,
this.delayExecutor=new S.p,this.bModel=x.D.Inst_get(),this.damageGrid.SetInitInfo("ui_bossassist_item",null,q.X),this.grid2.SetInitInfo("ui_bossassist_item",null,q.X),
this._degf_RefresFunItem=()=>this.RefresFunItem(),this.damageGrid.OnReposition_set(this._degf_RefresFunItem),this.funUpdateBar=()=>this.UpdateBar(),
this.extraRewardGrid.SetInitInfo("ui_treasure_bossdropitem_big",null,W.j),this.rewardGrid.SetInitInfo("ui_treasure_bossdropitem_big",null,W.j),
this.crossBossRewardGrid.SetInitInfo("ui_baseitem",null,M.j),this.extraRewardGrid.OnReposition_set((0,a.v)(this.ResetPos,this)),this.rewardGrid.OnReposition_set((0,
a.v)(this.ResetPos,this)),this.crossBossRewardGrid.OnReposition_set((0,a.v)(this.ResetPos,this)),this.myProgressBarWidth=this.myPercent.width(),this.bUpdateTiredInfoDirty=!0,
this.curBossTiredConsume="",this.rInfo=d.Y.Inst.PrimaryRoleInfo_get(),this.tModel=U._.Inst(),this.scrollpanel2.SetIsEnabled(!1),this.ancientBossGrid.OnReposition_set((0,
a.v)(this.ResetPos,this))}ResetPos(){this.scrollView3.ResetPosition(),this.scrollView4.ResetPosition(),this.scrollpanelAncient.ResetPosition()}RefreshBossListItem(){
if(null==this.ancientBossGrid)return
let t=null
const e=g.b.Inst.GetCurMap()
if(e.controllerType==_.N.CROSS_BOSS_CLIENT){const t=R.I.Inst_get().GetCrossBossList()
return void this.ancientBossGrid.data_set(t)}if(e.controllerType==_.N.BATTLEFIELD)t=e.id
else{const e=N.C.Inst().getItemById(this.tModel.curAbSortId)
if(null==e)return
t=e.mapId_get()}const s=new T.Z,i=this.tModel.GetAbShowDataByLayer(t)
if(null!=i&&i.Count()>0)for(const[t,e]of(0,r.V5)(i))s.Add(e)
e.controllerType!=_.N.BATTLEFIELD&&e.controllerType!=_.N.CROSS_BOSS_CLIENT||this.ancientBossGrid.data_set(s)}RefresFunItem(){this.delayExecutor.Invoke(this.funUpdateBar,20)}
UpdateBar(){this.AdjustPos(this.damageGrid.data_get())}AdjustPos(t){let e=t.Count()
e=10;-1*this.scrollpanel.clipOffset().y>320&&(this.scrollView.node.transform.SetLocalPosition(this.resetpos),this.scrollView.ResetPosition())}ClearInterval(){
0!=this.intervalId&&(m.C.Inst_get().ClearInterval(this.intervalId),this.intervalId=0)}OnRewardRefreshFun(t){}Clear(){this.RemoveLis(),this.ClearInterval(),
this.delayExecutor.Clear(),this.damageGrid.Clear(),this.grid2.Clear(),null!=E.n.inst.commonRightView&&E.n.inst.commonRightView.Clear(),super.Clear(),
H.x.Inst_get().memberDmgView=null}Destroy(){}AddLis(){f.i.Get(this.tipBtn.node).RegistonClick(this._degf_OnTipBtnClick),
f.i.Get(this.btnAsk.node).RegistonClick(this._degf_OnAskForHelp),f.i.Get(this.tipMask).RegistonClick(this._degf_OnTipMaskClick),
f.i.Get(this.closeTipsBtn).RegistonClick(this._degf_OnTipMaskClick),u.i.Inst.AddEventHandler(b.g.WORLD_BOSS_TIRED_UPDATE,this._degf_OnUpdateTiredInfo),
u.i.Inst.AddEventHandler(b.g.CROSS_BOSS_TIRED_UPDATE,this._degf_OnUpdateTiredInfo),u.i.Inst.AddEventHandler(b.g.CHECK_PANDORABOX_CLOSE_GUIDE,this._degf_CheckDropDelete),
u.i.Inst.AddEventHandler(b.g.BOSS_DAMAGE_BOSSID_UPDATE,this._degf_OnRefreshAssitData),u.i.Inst.AddEventHandler(b.g.FUNCTION_OPEN,this._degf_FunctionOpen),
B.v.Inst_get().AddEventHandler(D.R.ASSIST_DATA_ADD,this._degf_OnRefreshAssitData),B.v.Inst_get().AddEventHandler(D.R.ASSIST_DATA_REMOVE,this._degf_OnRefreshAssitData),
this.AddRoleLis()}AddRoleLis(){this.RemoveRoleLis(),this.roleInfo=d.Y.Inst.PrimaryRoleInfo_get(),
null!=this.roleInfo&&(this.roleInfo.AddEventHandler(I.A.TeamUpdate,this._degf_TeamUpdate),this.roleInfo.AddEventHandler(I.A.AsuramIdUpdate,this._degf_AsuramIdChange))}
RemoveRoleLis(){null!=this.roleInfo&&(this.roleInfo.RemoveEventHandler(I.A.TeamUpdate,this._degf_TeamUpdate),
this.roleInfo.RemoveEventHandler(I.A.AsuramIdUpdate,this._degf_AsuramIdChange),this.roleInfo=null)}RemoveLis(){this.RemoveRoleLis(),
f.i.Get(this.tipBtn.node).RemoveonClick(this._degf_OnTipBtnClick),f.i.Get(this.btnAsk.node).RemoveonClick(this._degf_OnAskForHelp),
f.i.Get(this.tipMask).RemoveonClick(this._degf_OnTipMaskClick),f.i.Get(this.closeTipsBtn).RemoveonClick(this._degf_OnTipMaskClick),
u.i.Inst.RemoveEventHandler(b.g.WORLD_BOSS_TIRED_UPDATE,this._degf_OnUpdateTiredInfo),u.i.Inst.RemoveEventHandler(b.g.CROSS_BOSS_TIRED_UPDATE,this._degf_OnUpdateTiredInfo),
u.i.Inst.RemoveEventHandler(b.g.CHECK_PANDORABOX_CLOSE_GUIDE,this._degf_CheckDropDelete),u.i.Inst.RemoveEventHandler(b.g.BOSS_DAMAGE_BOSSID_UPDATE,this._degf_OnRefreshAssitData),
u.i.Inst.RemoveEventHandler(b.g.FUNCTION_OPEN,this._degf_FunctionOpen),B.v.Inst_get().RemoveEventHandler(D.R.ASSIST_DATA_ADD,this._degf_OnRefreshAssitData),
B.v.Inst_get().RemoveEventHandler(D.R.ASSIST_DATA_REMOVE,this._degf_OnRefreshAssitData)}TeamUpdate(t){}AsuramIdChange(t){this.UpdateBtns()}FunctionOpen(){this.UpdateBtns()}
UpdateBtns(){const t=g.b.Inst.GetCurMapControllerType()
if(t==_.N.WORLD_BOSS||t==_.N.WORLD_BOSS_NEWHAND){this.bg1.SetActive(!1),this.bg2.SetActive(!0),this.tired_consume.SetActive(!1),this.btnAsk.node.SetActive(!1),
this.tipBtn.node.SetActive(!0)
const t=this.tipBtn.node.position
t.set(0,t.y,t.z),this.tipBtn.node.position=t,this.rewardTip.textSet(p.V.Inst().getStr(11008,o.h.eLangResource))}else{if(t==_.N.CROSS_BOSS_CLIENT){this.crossRewardTip.SetActive(!0),
this.extraRewardTip.SetActive(!1)
const t=P.x.Inst().getItemById(11043011)
this.crossRewardTip.textSet(t.sys_messsage)}else this.crossRewardTip.SetActive(!1),this.extraRewardTip.SetActive(!0),
this.rewardTip.textSet(p.V.Inst().getStr(11009,o.h.eLangResource))
if(L.P.Inst_get().IsFuncOrActivityOpened(G.x.ASURAM_BOSS_ASSIST)&&t!=_.N.CROSS_BOSS_CLIENT){this.btnAsk.node.SetActive(!0),this.tipBtn.node.SetActive(!0)
const t=this.tipBtn.node.getPosition()
t.x=70,this.tipBtn.node.setPosition(t)}else{this.btnAsk.node.SetActive(!1),this.tipBtn.node.SetActive(!0)
const t=this.tipBtn.node.getPosition()
t.x=0,this.tipBtn.node.setPosition(t)}this.bg1.SetActive(!0),this.bg2.SetActive(!1),this.tired_consume.SetActive(!0),this.disableAskObj.SetActive(!1),
this.enableAskObj.SetActive(!0),this.UpdateAskBtnShow()}t==_.N.BATTLEFIELD?(this.tiredSp.spriteNameSet("atlas/worldboss/ryworldboss_sp_0056"),
this.ancientBossGrid.SetInitInfo("ui_ancient_bosslist_item",null,j.y),this.bAncientBoss=!0,this.RefreshBossListItem(),
this.m_handlerMgr.AddEventMgr(b.g.BOSS_REMOVE,this._degf_OnBossRemove)):t==_.N.CROSS_BOSS_CLIENT?(this.tiredSp.spriteNameSet("atlas/luolanzhanchang/luolanzhanchang_sp_0002"),
this.ancientBossGrid.SetInitInfo("ui_ancient_bosslist_item",null,Y.g),this.bAncientBoss=!0,this.RefreshBossListItem(),
this.m_handlerMgr.AddEventMgr(b.g.BOSS_REMOVE,this._degf_OnBossRemove)):(this.tiredSp.spriteNameSet("atlas/worldboss/ryworldboss_sp_0004"),this.ancientBossGrid.node.SetActive(!1),
this.bAncientBoss=!1)}OnAskForHelp(t,e){if(this.HadAskHelp)return
if(d.Y.Inst.PrimaryRoleInfo_get().isHaveAlliance_get())if(null!=this.bModel.bossId){let t=0
const e=d.Y.Inst.getBossById(this.bModel.bossId)
null!=e&&null!=e.Cfg_get()&&(t=e.Cfg_get().id)
let s=1
const i=N.C.Inst().GetItemByMonsterId(t)
i?i.type_get()==F.l.WORLDBOSS?s=w.i.eWorldBoss:i.type_get()==F.l.ANCIENTBOSS&&(s=w.i.eAncientBoss):s=w.i.eCrossBoss,v.M.inst.Req_ReqAssist(s,this.bModel.bossId.ToString())
}else x.D.Inst_get().isAssistOther()&&k.y.inst.ClientSysMessage(432006)
else k.y.inst.ClientSysStrMsg(P.x.Inst().getItemStrById(114100))}OnTipMaskClick(t,e){this.tipPanel.node.SetActive(!1)}OnBtnTopClick(t,e){this.RefreshItems()}OnTipBtnClick(t,e){
this.tipPanel.node.SetActive(!0)
let s=null
const i=g.b.Inst.GetCurMapControllerType()
if(i==_.N.WORLD_BOSS||i==_.N.WORLD_BOSS_NEWHAND){s=this.tModel.curWbSortId,this.rewardLabel.textSet(p.V.Inst().getStr(11008,o.h.eLangResource)),this.desc2.node.SetActive(!0)
const t=this.tModel.GetRewardLis(s,!0)
this.extraRewardGrid.data_set(t)
const e=this.tModel.GetRewardLis(s,!1)
this.rewardGrid.data_set(e),this.tipBg.heightSet(358)}else if(i==_.N.BATTLEFIELD){s=this.tModel.curAbSortId,this.rewardLabel.textSet(p.V.Inst().getStr(11009,o.h.eLangResource))
const t=this.tModel.GetRewardLis(s,!1)
this.extraRewardGrid.data_set(t),this.desc2.node.SetActive(!1),this.rewardGrid.data_set(null),this.tipBg.heightSet(234)}else if(i==_.N.CROSS_BOSS_CLIENT){
s=R.I.Inst_get().searchBossId,this.rewardLabel.textSet(p.V.Inst().getStr(11009,o.h.eLangResource))
const t=R.I.Inst_get().GetRewardListById(s)
this.crossBossRewardGrid.data_set(t),this.desc2.node.SetActive(!1),this.rewardGrid.data_set(null),this.tipBg.heightSet(234)}}OnAddToScene(){this.hasOnShow=!0,this.RemoveLis(),
this.AddLis(),this.tipPanel.node.SetActive(!1),this.UpdateBtns(),this.SetShowBossList(H.x.Inst_get().bShowBossList),this.RefreshItems()}OnBossRemove(t){
if(this.bAncientBoss&&null!=t){this.RefreshBossListItem()}}UpdateAskBtnShow(){if(d.Y.Inst.PrimaryRoleInfo_get().isHaveTeam_get())this.btnAsk.node.SetActive(!1)
else if(this.btnAsk.node.active){let t=!1
this.bModel.bossId&&!x.D.Inst_get().isAssistOther()?(t=B.v.Inst_get().HasAskAssistBoss(this.bModel.bossId),this.effect.SetActive(!t)):this.effect.SetActive(!1),
this.btnAsk.SetText(t&&(0,h.T)("已求助")||(0,h.T)("战盟求助")),this.HadAskHelp=t}}SetDragList(t,e){if(null==t)return
let s=0,i=null
for(;s<t.Count();)i=t[s],i.coulddrag=e,s+=1}RefreshAncientBossListItems(){this.bModel.GetTeamRankData()}RefreshItems(){const t=this.bModel.GetTeamRankData()
this.AdjustPos(t),t.Count()<4?this.SetDragList(t,!1):this.SetDragList(t,!0)
const e=g.b.Inst.GetCurMapControllerType()
e==_.N.WORLD_BOSS||e==_.N.WORLD_BOSS_NEWHAND?this.grid2.data_set(t):this.damageGrid.data_set(t),this.name.textSet((0,h.T)("我的伤害"))
const s=this.bModel.GetFirstOneDamage()
let i=0,n=0
this.bModel.isAssistOther()&&null!=this.bModel.assistPersonInfo?null==this.bModel.myDamage?(this.myDamage.textSet("0"),
this.myPercent.SetActive(!1)):(i=this.bModel.myDamage.ToNum(),this.myDamage.textSet(O.l.GetRuleDecimalValByFloorToInt(i,1,null)),0==s?this.myPercent.SetActive(!1):(n=i/s,
this.myPercent.widthSet(n*this.myProgressBarWidth),this.myPercent.SetActive(!0))):null==this.bModel.myDamage?(this.myDamage.textSet("0"),
this.myPercent.SetActive(!1)):(i=this.bModel.myDamage.ToNum(),this.myDamage.textSet(O.l.GetRuleDecimalValByFloorToInt(i,1,null)),n=i/s,
this.myPercent.widthSet(n*this.myProgressBarWidth),this.myPercent.SetActive(!0)),this.UpdateTiredInfo(null)}CheckDropDelete(){const t=g.b.Inst.GetCurMapControllerType()
if(t==_.N.WORLD_BOSS||t==_.N.WORLD_BOSS_NEWHAND){if(c.M.Inst.needPickDic.LuaDic_Count()>0)return
V.$.inst.CM_WorldBossSettleNow()}}FocusBossListView(t){this.bForceBossList=t}SetShowBossList(t){this.bForceBossList&&!t||(this.bShowBossList=t,this.bUpdateTiredInfoDirty=!0,
this.assistinfo.SetActive(!t),this.ancientBossInfo.SetActive(t),this.hasOnShow&&(this.bShowBossList?(this.title.textSet("剩余体力："),this.UpdateTiredInfo(),
this.RefreshBossListItem()):this.bForceBossList||(this.title.textSet("消耗体力："),this.UpdateTiredInfo())))}IsShowingBossList(){return this.bShowBossList}UpdateTiredInfo(t){
const e=g.b.Inst.GetCurMapControllerType()
if(1==this.bUpdateTiredInfoDirty||null!=t){let t=""
if(e==_.N.BATTLEFIELD?this.roleTiredVal=U._.Inst().AncientBossTired_get():e==_.N.WORLD_BOSS_NEWHAND||e==_.N.WORLD_BOSS?this.roleTiredVal=U._.Inst().WorldBossTired_get():this.roleTiredVal=U._.Inst().CrossBossTired_get(),
this.bShowBossList)t=this.roleTiredVal
else if(!C.o.IsNullOrZero(this.bModel.bossId)){const e=d.Y.Inst.getBossById(this.bModel.bossId)
null!=e&&null!=e.Cfg_get()?this.curBossTiredConsume=e.Cfg_get().rage:this.curBossTiredConsume=0,t=`${this.curBossTiredConsume}/${this.roleTiredVal}`}this.tiredVal.textSet(t)}}})||i
},76902:(t,e,s)=>{s.d(e,{k:()=>O})
var i=s(86133),n=s(25236),l=s(98800),o=s(36241),a=s(50089),r=s(5924),h=s(66788),d=s(99294),c=s(9986),I=s(6665),u=s(93877),p=s(8889),_=s(72005),g=s(61911),m=s(60130),S=s(98885),f=s(75696),C=s(30627),T=s(26753),y=s(93078),A=s(85751),v=s(97503),D=s(85770),w=s(72800),B=s(24524),M=s(96713),b=s(5031)
class O extends g.f{constructor(...t){super(...t),this.exitbtn=null,this.exitlab=null,this.scrollview=null,this.grid=null,this.roleImage=null,this.bgSp=null,this.leftAnchor=null,
this.rightAnchor=null,this.scrollPanel=null,this.desc=null,this.leftObj=null,this.rightObj=null,this.scrollPanelWidth=null,this.cellWidth=null,this.exitimer=null,
this.hasClickRush=null,this.exitTime=null}RefreshItems(){const t=D.a.Inst_get().copyRewardList
if(t){const e=t
D.a.Inst_get().sortReward(e),this.grid.data_set(e)}else{const t=B.o.Inst().getItemById(D.a.Inst_get().currentCopyId).getSuccessRewardItemList()
this.grid.data_set(t)}}InitView(){super.InitView(),this.exitbtn=this.CreateComponent(c.W,1),this.exitlab=this.CreateComponent(u.Q,2),this.scrollview=this.CreateComponent(d.z,3),
this.grid=this.CreateComponent(I.A,4),this.roleImage=this.CreateComponent(_.w,5),this.bgSp=this.CreateComponent(_.w,6),this.leftAnchor=this.CreateComponent(d.z,7),
this.rightAnchor=this.CreateComponent(d.z,8),this.scrollPanel=this.CreateComponent(p.$,9),this.grid.SetInitInfo("ui_baseitem",this.CreateDelegate(this.OnItemRefreshFun)),
this.grid.OnReposition_set(this.CreateDelegate(this.OnReposition)),this.scrollPanelWidth=this.scrollPanel.width(),this.cellWidth=this.grid.cellWidth(),(0,
n.S)("self.scrollPanelWidth = ",this.scrollPanelWidth,this.cellWidth),this.bgSp.widthSet(a.t.GetUIWidth()),m.O.SetAnchorPos(this.leftAnchor,!0,!1,0,!1),
m.O.SetAnchorPos(this.rightAnchor,!1,!1,0,!1),this.leftObj=this.FindComponent(d.z,"bg/midAnchor/rycommon_sp_0126",!0),this.leftObj.SetName("leftSp"),
this.rightObj=this.FindComponent(d.z,"bg/midAnchor/rycommon_sp_0126",!0),this.rightObj.SetName("rightSp"),this.desc=this.FindComponent(u.Q,"layer-auto10",!0)}OnItemRefreshFun(t){
const e=new f.j
return e.setId(t,null,0),e}OnReposition(t){const e=this.grid.itemList.Count(),s=this.grid.node.GetLocalPosition()
let i=this.cellWidth*e/2
i>this.scrollPanelWidth/2&&(i=this.scrollPanelWidth/2),s.x-=i,this.grid.node.SetLocalPosition(s)}OnAddToScene(){super.OnAddToScene(),this.exitimer=-1,
o._.getInst().endPlayerHang(l.Y.Inst.PrimaryRole_get()),this.hasClickRush=!1,this.addLis(),this.RefreshItems(),this.FuckProcess(),b.T.inst_get().control.CloseBuffListPanel(),
y.F.Instance_get().CloseView(),v.f.inst_get().hasEndOpen=!0,T.d.Inst_get().controller.CloseHornPanel(),this.AutoExit(),
this.m_handlerMgr.AddClickEvent(this.exitbtn,this.CreateDelegate(this.ExitCopyHandler))}FuckProcess(){if(D.a.Inst_get().curCopyType==w.S.SpringCattle){
const t=C.t.Inst().GetBoxCount()
if(this.desc.supportEncodingSet(!0),this.desc.textSet(`恭喜成功通关副本，获得了${A.u.GreenColorStr2}${t}[-]个宝箱，已为您自动开启宝箱奖励`),this.desc.SetLocalPositionXYZ(-88,43,0),
this.leftObj.SetLocalPositionXYZ(-100,34,0),this.rightObj.SetLocalPositionXYZ(543,34,0),D.a.Inst_get().isNewRecord){
const t=this.FindComponent(_.w,"bg/rightAnchor/ryresult_sp_0017",!0).InstantiateComponent(_.w)
t&&(t.SetLocalPositionXYZ(-473,105,0),t.SetItemIconByAtlas("ryresult_sp_0024","pre_ryresult",!0),t.SetLocalScaleXYZ(.8,.8,1))}}}addLis(){}AutoExit(){if(-1==this.exitimer){
const t=B.o.Inst().getItemById(D.a.Inst_get().currentCopyId)
null==t?(this.exitTime=0,h.Y.LogError((0,i.T)("没有找到当前副本id：")+(D.a.Inst_get().currentCopyId+(0,i.T)("的副本配置")))):this.exitTime=t.escTime,this.ClearTimer(),
this.exitimer=r.C.Inst_get().SetInterval(this.CreateDelegate(this.UpdateTimerHandler),1e3),this.UpdateTimerHandler()}}ClearTimer(){
this.exitimer>=0&&r.C.Inst_get().ClearInterval(this.exitimer),this.exitimer=-1}UpdateTimerHandler(){this.exitTime-=1
const t=S.M.Replace((0,i.T)("确定({0}S)"),"{0}",this.exitTime)
this.exitlab.textSet(t),this.exitTime<=0&&this.ExitCopyHandler()}ExitCopyHandler(){D.a.Inst_get().ExitCopy(),M.n.inst.CloseCommonSuccessView()}Clear(){this.ClearTimer(),
this.exitimer=-1,this.grid.Clear(),super.Clear()}Destroy(){super.Destroy(),this.exitbtn=null,this.exitlab=null,this.scrollview=null,this.grid=null,this.roleImage=null,
this.bgSp=null,this.leftAnchor=null,this.rightAnchor=null,this.scrollPanel=null}Test1(){return!0}S_Test(){return!0}}},2229:(t,e,s)=>{
var i,n,l=s(6847),o=s(46282),a=s(40053),r=s(38935),h=s(80037),d=s(44255),c=s(85682),I=s(5494),u=s(98130),p=s(85602),_=s(38962),g=s(92679),m=s(28287),S=s(88199),f=s(57411),C=s(96964),T=s(14792),y=s(19276),A=s(88934),v=s(22046),D=s(12417)
;(0,
l.s_)(I.I.TreasurePanel,o.Z.ui_ry_tabcommonpanel).tabsPrefab(o.Z.ui_treasure_wbview_ry,0).tabsPrefab(o.Z.ui_treasure_karima_ry,2).tabsPrefab(o.Z.ui_treasure_dunview_ry,3).waitPrefab(a.Z.BaseItem_ry_basePrefabs).register()((n=class t extends d.I{
constructor(...t){super(...t),this.model=null,this.currentShowType=null}static __StaticInit(){t.typeMap=new _.X,t.typeMap.LuaDic_AddOrSetItem(0,v.l.WORLDBOSS),
t.typeMap.LuaDic_AddOrSetItem(1,v.l.ANCIENTBOSS),t.typeMap.LuaDic_AddOrSetItem(2,v.l.KARIMABOSS),t.typeMap.LuaDic_AddOrSetItem(3,v.l.VIPBOSS),
t.tabIds=new p.Z([S.Z.BOSS_WORLDBOSS,S.Z.BOSS_ANCIENTBOSS,S.Z.BOSS_KARIMABOSS,S.Z.BOSS_VIPBOSS])}_initBinder(){super._initBinder(),this.model=D._.Inst(),t.typeMap||t.__StaticInit()
}ShowCurrencyBar_get(){return m._.ShowAll}DoHide(){A.$.Inst().CloseDropView(),super.DoHide()}InitViewEx(){this.titleLabel.textSet("世界首领")}OnAddToScene(){super.OnAddToScene(),
this.BossInfoReq()}SetViewConfig(){this._SetCharacterTabData(!1),this.tabIds=t.tabIds
const e=new p.Z([c.D.UI_BOSS_WORLD_TAB,c.D.UI_BOSS_GLOD_TAB,c.D.UI_BOSS_KLM_TAB,c.D.UI_BOSS_VIPBOSS_TAB])
this._SetTabData0(!0,new p.Z(["世界首领","黄金首领","卡利玛神庙","特权首领"]),new p.Z([T.t.WORLD_BOSS,T.t.ERROR,T.t.KARIMA_BOSS,T.t.VIP_BOSS]),null,null,null,null,null,null,e),this._SetTabData1(!1)
}_OnClickBottomItem(t,e,s){const i=this.bottomTabGrid.itemList.IndexOf(t)
this.model.ResetSelectId(),this.SelectTab0(i,!0)}_OnSelectTab0BeforeUpdate(){
0==this.selectTabIdx0?this.model.viewType=v.l.WORLDBOSS:1==this.selectTabIdx0?this.model.viewType=v.l.ANCIENTBOSS:2==this.selectTabIdx0?this.model.viewType=v.l.KARIMABOSS:3==this.selectTabIdx0&&(this.model.viewType=v.l.VIPBOSS),
this.RefreshView()}OnCloseClick(){A.$.Inst().Close()}AddLis(){super.AddLis(),this.m_handlerMgr.AddEventMgr(g.g.BOSS_SELECT,this.CreateDelegate(this.OnBossSelect)),
this.m_handlerMgr.AddEventMgr(g.g.FLOOR_SELECT,this.CreateDelegate(this.OnFloorSelect)),
this.m_handlerMgr.AddEventMgr(g.g.ABossLayerSelected,this.CreateDelegate(this.OnLayerSelected))}Clear(){this.model.hasBossGridRefresh=!1,this.model.hasShowAni=!1,
this.model.viewType=-1,A.$.inst.ClearWbViewData(),A.$.inst.ClearAbViewData(),A.$.inst.ClearKarimaData(),A.$.inst.ClearVipData(),h.j.Inst_get().StopStandSound(),
this.model.isPassCopy=!1,A.$.inst.CloseDropView(),this.model.ClearFirstInBossView(),super.Clear()}Destroy(){this.model.ClearFirstInBossView(),A.$.inst.DestroyWbView(),
A.$.inst.DestroyAbView(),A.$.inst.DestroyKarimaView(),A.$.inst.DestroyVipView(),super.Destroy()}ShowViewByType(t){null==t&&(t=!1)
let e=0
e=this.model.viewType,this.currentShowType!=e&&(this.model.hasBossGridRefresh=!1,this.currentShowType=e),e==v.l.WORLDBOSS?(A.$.inst.ClearAbViewData(),A.$.inst.ClearKarimaData(),
A.$.inst.ClearVipData(),A.$.inst.InitWbViewData(this.midTrans.node),this.titleLabel.textSet("世界首领")):e==v.l.VIPBOSS?(A.$.inst.ClearWbViewData(),A.$.inst.ClearAbViewData(),
A.$.inst.ClearKarimaData(),A.$.inst.InitVipViewData(this.midTrans.node),this.titleLabel.textSet("特权首领")):e==v.l.ANCIENTBOSS?(A.$.inst.ClearWbViewData(),A.$.inst.ClearKarimaData(),
A.$.inst.ClearVipData(),A.$.inst.InitAbViewData(this.midTrans.node),this.titleLabel.textSet("黄金首领")):e==v.l.KARIMABOSS&&(A.$.inst.ClearWbViewData(),A.$.inst.ClearAbViewData(),
A.$.inst.ClearVipData(),A.$.inst.InitKarimaViewData(this.midTrans.node),this.titleLabel.textSet("卡利玛神庙"))}OnFloorSelect(t){this.model.curFloor=u.GF.INT(t),
0==this.model.settingSortId&&this.model.UpdateFloorSelectByFloor(this.model.curFloor),this.model.hasBossGridRefresh=!1,this.RefreshView()}OnBossSelect(t){const e=t
if(e.type==v.l.WORLDBOSS)this.model.curWbSortId=e.sortId
else if(e.type==v.l.NEUTROLBOSS)this.model.curNbSortId=e.sortId
else{if(e.type==v.l.VIPBOSS)return null
e.type==v.l.ANCIENTBOSS&&(this.model.curAbSortId=e.sortId)}this.RefreshView()}BossInfoReq(){const t=new f.M
r.C.Inst.F_SendMsg(t)}BossInfoHandle(){this.model.ResetSelectId()
let e=0
this.model.viewType==v.l.WORLDBOSS?e=0:this.model.viewType==v.l.ANCIENTBOSS?e=1:this.model.viewType==v.l.KARIMABOSS?e=2:this.model.viewType==v.l.VIPBOSS&&(e=3),
e=this.GetRedTabIndex(e,this.tab0RedPointList),this.model.viewType=t.typeMap[e],this.SelectTab0(e,!1)}BossInfoHandleBySetting(){
const t=y.C.Inst().getItemById(this.model.settingSortId)
if(this.model.viewType=t.type_get(),t.type_get()==v.l.NEUTROLBOSS);else if(t.type_get()==v.l.WORLDBOSS){this.model.curWbSortId=this.model.settingSortId
const t=D._.Inst().GetWbShowData()
let e=0
for(;e<t.Count();)t[e].sortId==this.model.curWbSortId&&(this.model.wbDefaultIndex=e),e+=1
}else t.type_get()==v.l.VIPBOSS?this.model.curVbSortId=this.model.settingSortId:t.type_get()==v.l.ANCIENTBOSS&&(this.model.curAbSortId=this.model.settingSortId)
this.model.viewType==v.l.WORLDBOSS?this.SelectTab0(0,!1):this.model.viewType==v.l.ANCIENTBOSS&&this.SelectTab0(1,!1),this.model.settingSortId=0}RefreshView(t){null==t&&(t=!1),
this.ShowViewByType(t)
const e=this.GetIdByViewType(this.model.viewType),s=y.C.Inst().getItemById(e)
null!=s&&h.j.Inst_get().PlayStandSound(s.monsterId_get())}GetIdByViewType(t){if(t==v.l.WORLDBOSS)return this.model.curWbSortId
if(t==v.l.NEUTROLBOSS)return this.model.curNbSortId
if(t==v.l.VIPBOSS)return this.model.curVbSortId
if(t==v.l.ANCIENTBOSS)return this.model.curAbSortId
if(t==v.l.KARIMABOSS){const t=C.o.getInstance().GetRecommendBoss(null)
return null!=t?t.id_get():0}return 0}OnLayerSelected(t){this.RefreshView()}},n.typeMap=null,n.tabIds=null,i=n))},46873:(t,e,s)=>{s.d(e,{L:()=>n})
var i=s(61911)
class n extends i.f{constructor(...t){super(...t),this.exitbtn=null,this.promotebtn=null,this.scrollview=null,this.grid=null,this.autoExit=null,this.exitcopygraybtn=null,
this._degf_OnCreateAccessItem=null,this.timer=null,this.exitTime=null,this.exitEnable=null,this.delayCopyBtn=null,this.exitBtn=null,this.exitStr=null,this.exitlab=null}}},
52512:(t,e,s)=>{
var i,n=s(6847),l=s(83908),o=s(46282),a=s(86133),r=s(98800),h=s(36241),d=s(50089),c=s(5924),I=s(66788),u=s(5494),p=s(98885),_=s(85602),g=s(63076),m=s(15033),S=s(75696),f=s(26753),C=s(93078),T=s(97503),y=s(85770),A=s(95236),v=s(35803),D=s(24524),w=s(5031)
;(0,n.s_)(u.I.eVipBossSuccessPanel,o.Z.ui_rydunboss_successpanel).waitPrefab(S.j.CompListPath).hideMainUI().register()(i=class extends((0,l.Ri)()){constructor(...t){super(...t),
this.msg=null,this.scrollPanelWidth=null,this.cellWidth=null,this.exitimer=null,this._model=null,this.hasClickRush=null,this.exitTime=null}RefreshItems(){
const t=this.msg.items,e=new _.Z
let s=0
for(;s<t.Count();){const i=t[s],n=new g.M(i.modelId)
if(n.serverData_set(i),n.serverData_get().num=i.num,n.count=i.num,n.BagItemType_get()==m.r.Equip){null!=i&&0!=i.suitId&&(n.isShowSuit=!0)}n.isCanOperate=!1,e.Add(n),s+=1}
y.a.Inst_get().sortReward(e),this.grid.data_set(e),this.scrollview.ResetPosition()}InitView(){this.grid.SetInitInfo("ui_baseitem",this.CreateDelegate(this.OnItemRefreshFun)),
this.scrollPanelWidth=this.scrollPanel.node.transform.width,this.cellWidth=this.grid.cellWidth,this.bgSp.widthSet(d.t.GetUIWidth())}OnItemRefreshFun(t){return t[0].getCNode(S.j)}
OnAddToScene(){super.OnAddToScene(),this.exitimer=-1,h._.getInst().endPlayerHang(r.Y.Inst.PrimaryRole_get()),this._model=v.D.Inst_get(),this.msg=this._model.settlement,
this.hasClickRush=!1,this.addLis(),this.RefreshItems(),w.T.inst_get().control.CloseBuffListPanel(),C.F.Instance_get().CloseView(),T.f.inst_get().hasEndOpen=!0,
f.d.Inst_get().controller.CloseHornPanel(),this.AutoExit(),this.m_handlerMgr.AddClickEvent(this.exitbtn,this.CreateDelegate(this.ExitCopyHandler))}addLis(){}AutoExit(){
if(-1==this.exitimer){const t=D.o.Inst().getItemById(y.a.Inst_get().currentCopyId)
null==t?(this.exitTime=0,I.Y.LogError((0,a.T)("没有找到当前副本id：")+(y.a.Inst_get().currentCopyId+(0,a.T)("的副本配置")))):this.exitTime=t.escTime,this.ClearTimer(),
this.exitimer=c.C.Inst_get().SetInterval(this.CreateDelegate(this.UpdateTimerHandler),1e3),this.UpdateTimerHandler()}}ClearTimer(){
this.exitimer>=0&&c.C.Inst_get().ClearInterval(this.exitimer),this.exitimer=-1}UpdateTimerHandler(){this.exitTime-=1
const t=p.M.Replace((0,a.T)("确定({0}S)"),"{0}",this.exitTime)
this.exitlab.textSet(t),this.exitTime<=0&&this.ExitCopyHandler()}ExitCopyHandler(){y.a.Inst_get().ExitCopy(),A.C.Inst_get().CloseSuccessPanel()}Clear(){this.ClearTimer(),
this.exitimer=-1,this.grid.Clear(),super.Clear()}Destroy(){super.destroy()}Test1(){return!0}S_Test(){return!0}})},40050:(t,e,s)=>{
var i,n,l=s(18998),o=s(83908),a=s(2689),r=s(87923),h=s(72800),d=s(35803),c=s(31896),I=s(14792)
const{ccclass:u,property:p}=l._decorator
u("RyVipBossTabBtn")((n=class t extends((0,o.yk)()){constructor(...t){super(...t),this.mapRes=null}InitView(){}SetData(t,e){this.mapRes=e,this.viplevel.textSet(`V${t}`),
this.namelab.textSet(e.name)}UpdateRedPoint(t){this.redPoint.SetActive(t)}SetSelect(e){e?(t._selectItem!=this&&(null!=t._selectItem&&t._selectItem.SetSelect(!1),
this.selectbg.SetActive(!0),this.namelab.SetColor(r.l.GetColorByHexStr("FFE9B3")),
this.mapRes.controllerType==a.N.VIP_BOSS_1?c.t.inst.IsHasClick(I.t.VIP_BOSS+h.S.VipBoss1)||d.D.Inst_get().redPointNum1>0&&c.t.inst.CM_RedPointClickHandle(I.t.VIP_BOSS+h.S.VipBoss1):this.mapRes.controllerType==a.N.VIP_BOSS_2?c.t.inst.IsHasClick(I.t.VIP_BOSS+h.S.VipBoss2)||d.D.Inst_get().redPointNum2>0&&c.t.inst.CM_RedPointClickHandle(I.t.VIP_BOSS+h.S.VipBoss2):this.mapRes.controllerType==a.N.VIP_BOSS_3&&(c.t.inst.IsHasClick(I.t.VIP_BOSS+h.S.VipBoss3)||d.D.Inst_get().redPointNum3>0&&c.t.inst.CM_RedPointClickHandle(I.t.VIP_BOSS+h.S.VipBoss3))),
t._selectItem=this):(this.selectbg.SetActive(!1),this.namelab.SetColor(r.l.GetColorByHexStr("4E4336")))}Clear(){}Destroy(){t._selectItem=null,super.destroy()}Test1(){return!0}
S_Test(){return!0}},n._selectItem=null,i=n))},66696:(t,e,s)=>{s.d(e,{Y:()=>_})
var i,n=s(34565),l=s(6847),o=s(83908),a=s(46282),r=s(40053),h=s(93984),d=s(98958),c=s(5494),I=s(88934),u=s(12417),p=s(24087)
let _=(0,l.s_)(c.I.WorldBossExtraRewardPanel,a.Z.ui_treasure_worldboss_extrarewardinfo_ry).waitPrefab(a.Z.ui_treasure_bossdropitem_big).waitPrefab(r.Z.BaseItem_ry_basePrefabs).register()(i=class extends((0,
o.pA)(n.I)()){constructor(...t){super(...t),this.tModel=null,this._degf_OnConfirmClick=null,this._degf_OnRewardRefreshFun=null}_initBinder(){super._initBinder(),
this._degf_OnConfirmClick=(t,e)=>this.OnConfirmClick(t,e),this._degf_OnRewardRefreshFun=t=>this.OnRewardRefreshFun(t)}InitView(){super.InitView(),
this.extraRewardGrid.SetInitInfo("ui_treasure_bossdropitem_big",this._degf_OnRewardRefreshFun),this.extraRewardGrid.OnReposition_set(this.CreateDelegate(this.CallReposition)),
this.tModel=u._.Inst()}CallReposition(){this.extraScrollView.ResetPosition()}IsForceCloseByGoAccess(){return!0}OnRewardRefreshFun(t){return t[0].getCNode(p.j)}Clear(){
this.RemoveLis(),super.Clear()}Destroy(){}AddLis(){this.AddClickEvent(this.confirmBtn.node,this._degf_OnConfirmClick)}RemoveLis(){
this.RemoveClickEvent(this.confirmBtn.node,this._degf_OnConfirmClick)}OnConfirmClick(t,e){I.$.inst.CloseRewardInfo()}OnAddToScene(){super.OnAddToScene(),this.AddLis()
const t=this.tModel.curWbSortId,e=this.tModel.GetRewardLis(t,!0)
this.extraRewardGrid.data_set(e),this.desc.textSet(d.V.Inst().getStr(11008,h.h.eLangResource))}})||i},86258:(t,e,s)=>{s.d(e,{c:()=>M})
var i,n=s(23833),l=s(98800),o=s(97960),a=s(97461),r=s(68662),h=s(5924),d=s(57834),c=s(85682),I=s(98885),u=s(92679),p=s(85751),_=s(87923),g=s(24524),m=s(41864),S=s(31931),f=s(12970),C=s(21334),T=s(19276),y=s(88934),A=s(22046),v=s(12417),D=s(18998),w=s(83908),B=s(6251)
let M=D._decorator.ccclass("WorldBossItem")(i=class extends((0,w.zB)()){constructor(...t){super(...t),this.tModel=null,this.bossData=null,this.cfg=null,this.objRes=null,
this.intervalId=-1,this.mapRes=null,this.lvOk=!1,this.playerNumInterval=-1,this._degf_LevelUpdateHandler=null,this._degf_OnBossSelect=null,this._degf_OnBossSelectEff=null,
this._degf_OnItemClick=null,this._degf_SetRevive=null,this._degf_UpdateJobHandler=null,this.numtbl=null,this.isSmallItem=null,this.sortId=null}_initBinder(){super._initBinder(),
this._degf_LevelUpdateHandler=t=>this.LevelUpdateHandler(t),this._degf_OnBossSelect=t=>this.OnBossSelect(t),this._degf_OnBossSelectEff=t=>this.OnBossSelectEff(t),
this._degf_OnItemClick=(t,e)=>this.OnItemClick(t,e),this._degf_SetRevive=()=>this.SetRevive(),this._degf_UpdateJobHandler=t=>this.UpdateJobHandler(t)}InitView(){
this.tModel=v._.Inst(),this.numtbl=["一","二","三","四","五","六","七","八","九"],this.isSmallItem=null!=this.bossName}Clear(){this.RemoveLis(),this.ClearInterval(),
h.C.Inst_get().ClearInterval(this.playerNumInterval)}Destroy(){}AddLis(){this.m_handlerMgr.AddClickEvent(this.node,this._degf_OnItemClick),
a.i.Inst.AddEventHandler(u.g.BOSS_SELECT,this._degf_OnBossSelect),a.i.Inst.AddEventHandler(u.g.SELECT_BOSS_EFFECT,this._degf_OnBossSelectEff),
l.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(o.A.LevelUpdate,this._degf_LevelUpdateHandler),
l.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(o.A.JobUpdate,this._degf_UpdateJobHandler),
this.cfg.type_get()!=A.l.WORLDBOSS||this.isSmallItem||(a.i.Inst.AddEventHandler(u.g.UPDATE_BOSS_PLAYERNUM,this._degf_LevelUpdateHandler),
h.C.Inst_get().ClearInterval(this.playerNumInterval),this.playerNumInterval=h.C.Inst_get().SetInterval(this.CreateDelegate(this.OnPlayerNumTimer),1e3,-1),this.OnPlayerNumTimer())}
OnPlayerNumTimer(){y.$.inst.CM_WorldBossQueryPlayerNum(this.cfg.monsterId_get())}RemoveLis(){d.i.Get(this.node).RemoveonClick(this._degf_OnItemClick),
a.i.Inst.RemoveEventHandler(u.g.BOSS_SELECT,this._degf_OnBossSelect),a.i.Inst.RemoveEventHandler(u.g.SELECT_BOSS_EFFECT,this._degf_OnBossSelectEff),
l.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(o.A.LevelUpdate,this._degf_LevelUpdateHandler),
l.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(o.A.JobUpdate,this._degf_UpdateJobHandler),a.i.Inst.RemoveEventHandler(u.g.UPDATE_BOSS_PLAYERNUM,this._degf_LevelUpdateHandler),
this.UnRegGuide()}RegGuide(){}UnRegGuide(){}CheckGuide(){_.l.CheckBtnClickTrigger(c.D.UI_BOSS_ITEM_ICON,this.sortId)}UpdateJobHandler(t){this.LevelUpdate()}LevelUpdateHandler(t){
this.LevelUpdate()}SetWidth(t){t>300?this.widget.node.SetAlpha(0):this.widget.node.SetAlpha(1),this.widget.node.transform.width=t}OnItemClick(t,e){
a.i.Inst.RaiseEvent(u.g.BOSS_SELECT,this.bossData),this.CheckGuide()}OnBossSelect(t){}SetData(t){this.suffix.node.SetActive(!1)
const e=t
this.bossData=e,this.UnRegGuide(),this.sortId=e.sortId,this.RegGuide(),this.cfg=T.C.Inst().getItemById(e.sortId),this.objRes=n.a.getInst().getObjById(e.monsterId),
this.mapRes=C.p.Inst_get().GetMapById(this.cfg.mapId_get()),this.head.spriteNameSet(this.objRes.headResources),this.RemoveLis(),this.AddLis(),this.LevelUpdate()}LevelUpdate(){
if(null!=this.locksp){if(null!=this.cfg){let t=0
if(this.cfg.type_get()==A.l.WORLDBOSS){const e=this.cfg.copyid_get()
t=e>0?f.F.getInst().GetCanEnterCopyByLvAndTransfer(e):f.F.getInst().GetCanEnterMapByLvAndTransfer(this.cfg.mapId_get()),this.redPoint&&this.redPoint.SetActive(!1)
}else t=f.F.getInst().GetCanEnterMapByLvAndTransfer(this.cfg.mapId_get())
if(t==S.f.CAN)this.locksp.SetActive(!1),this.SetDieSp(!0)
else{this.locksp.SetActive(!0)
let t=0
if(this.cfg.type_get()==A.l.WORLDBOSS){if(this.cfg.copyid_get()>0){t=g.o.Inst().getItemById(this.cfg.copyid_get()).minLevelLimit}else t=this.mapRes.minLevelLimit
}else t=this.mapRes.minLevelLimit
this.suffix.textSet(`${m.h.GetLevelStr(t)}解锁`),this.suffix.node.SetActive(!0),this.SetDieSp(!1),this.isSmallItem?(this.bossName&&this.bossName.node.SetActive(!1),
this.bossNameBg.node.SetActive(!1),this.level.node.SetActive(!1)):(this.locksp.SetActive(!1),a.i.Inst.RaiseEvent(u.g.BOSS_SET_SEARCH_BTN,!1))}}this.UpdateHeadGray()}}
UpdateHeadGray(){let t=0
if(this.cfg.type_get()==A.l.WORLDBOSS){const e=this.cfg.copyid_get()
t=e>0?f.F.getInst().GetCanEnterCopyByLvAndTransfer(e):f.F.getInst().GetCanEnterMapByLvAndTransfer(this.cfg.mapId_get())
}else t=f.F.getInst().GetCanEnterMapByLvAndTransfer(this.cfg.mapId_get())
this.tModel.AllBossInfo_get()[this.cfg.monsterId_get()].refreshTime.ToNum()-r.D.serverMSTime_get()>0||t!=S.f.CAN?this.SetSpGray(this.head,!0):this.SetSpGray(this.head,!1)}
SetSpGray(t,e){B.d.LuaMakeGoGray(t.node,e)}SetRevive(){let t=""
const e=this.tModel.AllBossInfo_get()[this.cfg.monsterId_get()].refreshTime.ToNum()-r.D.serverMSTime_get()
e<=0?(this.ClearInterval(),this.cfg.type_get()!=A.l.WORLDBOSS||this.isSmallItem?this.suffix.node.SetActive(!1):(this.suffix.textSet(`${p.u.BrightGreenColorStr2}争夺人数：${v._.Inst().worldBossPlayerNum}[-]`),
this.suffix.node.SetActive(!0)),this.SetWordByDie(!1),this.isSmallItem?(this.bossName&&this.bossName.node.SetActive(!0),this.bossNameBg.node.SetActive(!0),
this.level.node.SetActive(!0)):a.i.Inst.RaiseEvent(u.g.BOSS_SET_SEARCH_BTN,!0),
this.redPoint&&this.cfg.type_get()==A.l.WORLDBOSS&&this.redPoint.SetActive(!this.bossData.hadEnter)):(this.suffix.node.SetActive(!0),t=`复活:${_.l.GetDateFormat(e/1e3)}`,
this.SetWordByDie(!0),this.isSmallItem?(this.bossName&&this.bossName.node.SetActive(!1),this.bossNameBg.node.SetActive(!1),
this.level.node.SetActive(!1)):a.i.Inst.RaiseEvent(u.g.BOSS_SET_SEARCH_BTN,!1),this.suffix.textSet(t)),this.UpdateHeadGray()}OnBossSelectEff(t){}ClearInterval(){
h.C.Inst_get().ClearInterval(this.intervalId),this.intervalId=-1}SetDieSp(t){t?(-1==this.intervalId&&(this.intervalId=h.C.Inst_get().SetInterval(this._degf_SetRevive,1e3)),
this.SetRevive()):(this.ClearInterval(),this.SetWordByDie(!1))}SetWordByDie(t){let e=""
e=t?"[8E8279]":"[CECCC5]"
const s=I.M.IntToString(this.objRes.level)
this.level.textSet(s),this.isSmallItem&&this.bossName.textSet(this.objRes.name)}})||i},14955:(t,e,s)=>{s.d(e,{z:()=>P})
var i,n=s(86133),l=s(98800),o=s(50089),a=s(5924),r=s(98885),h=s(85602),d=s(1240),c=s(70850),I=s(75363),u=s(75696),p=s(23628),_=s(71143),g=s(29839),m=s(85770),S=s(44498),f=s(37648),C=s(55492),T=s(24524),y=s(75439),A=s(65550),v=s(15771),D=s(33065),w=s(20193),B=s(12417),M=s(6847),b=s(83908),O=s(46282),R=s(32076),L=s(5494),G=s(67885)
let P=(0,M.s_)(L.I.WorldBossNormalSuccessPanel,O.Z.ui_treasure_worldboss_normalsuccessview).waitPrefab(G.S.modulePathList).register()(i=class extends((0,b.Ri)()){constructor(...t){
super(...t),this.time=10,this.intervalId=-1,this.rushState=0,this.copyType=0,this.leftCount=0,this.hasClickRush=!1,this._degf_OnConfirmClick=null,this._degf_OnGridReposition=null,
this._degf_OnGridReposition2=null,this._degf_OnGridReposition3=null,this._degf_OnItemInit=null,this._degf_SetCountdown=null,this._degf_SetScrollBar=null,
this._degf_SetScrollBar2=null,this._degf_SetScrollBar3=null,this._degf_OnClickRushBtnClick=null,this.isExclusionPanel=!0,this.isKillAllExcluded=!0}_initBinder(){
super._initBinder(),this._degf_OnConfirmClick=(t,e)=>this.OnConfirmClick(t,e),this._degf_OnGridReposition=()=>this.OnGridReposition(),
this._degf_OnGridReposition2=()=>this.OnGridReposition2(),this._degf_OnGridReposition3=()=>this.OnGridReposition3(),this._degf_OnItemInit=t=>this.OnItemInit(t),
this._degf_SetCountdown=()=>this.SetCountdown(),this._degf_SetScrollBar=()=>this.SetScrollBar(),this._degf_SetScrollBar2=()=>this.SetScrollBar2(),
this._degf_SetScrollBar3=()=>this.SetScrollBar3(),this._degf_OnClickRushBtnClick=(t,e)=>this.OnClickRushBtn(t,e)}InitView(){super.InitView(),this.isExclusionPanel=!0,
this.isKillAllExcluded=!0,this.rewardGrid.SetInitInfo("ui_baseitem",this._degf_OnItemInit),this.rewardGrid.OnReposition_set(this._degf_OnGridReposition),
this.rewardGrid2.SetInitInfo("ui_baseitem",this._degf_OnItemInit),this.rewardGrid2.OnReposition_set(this._degf_OnGridReposition2),
this.rewardGrid3.SetInitInfo("ui_baseitem",this._degf_OnItemInit),this.rewardGrid3.OnReposition_set(this._degf_OnGridReposition3),this.bgSp.widthSet(o.t.GetUIWidth())}
OnItemInit(t){return t[0].getCNode(u.j)}Clear(){super.Clear(),this.RemoveLis(),a.C.Inst_get().ClearInterval(this.intervalId),this.intervalId=-1,this.hasClickRush=!1}Destroy(){}
AddLis(){this.AddClickEvent(this.confirmBtn.node,this._degf_OnConfirmClick),this.AddClickEvent(this.normalConfirmBtn.node,this._degf_OnConfirmClick),
this.AddClickEvent(this.quickPassBtn.node,this._degf_OnClickRushBtnClick)}RemoveLis(){this.RemoveClickEvent(this.confirmBtn.node,this._degf_OnConfirmClick),
this.RemoveClickEvent(this.normalConfirmBtn.node,this._degf_OnConfirmClick),this.RemoveClickEvent(this.quickPassBtn.node,this._degf_OnClickRushBtnClick)}OnConfirmClick(t,e){
g.p.inst.ExitCopy(),D.x.Inst_get().CloseNormalSuccessView()}OnAddToScene(){super.OnAddToScene(),this.AddLis()
const t=w.D.Inst_get().rewards,e=new h.Z,s=l.Y.Inst.PrimaryRoleInfo_get()
let i=0
for(;i<t.normalRewards.Count();){const n=new d.Y
if(n.serverData_set(t.normalRewards[i]),n.baseData_get().isCanOperate=!1,n.baseData_get().isEquipCompare=!1,n.baseData_get().isEquip_get()){
const t=_.i.CanUseForTargetJob(s.Job_get(),n.baseData_get().cfgData_get().job)
n.cacheDressState=_.i.EquipScoreCompare(s,n.baseData_get()),t||(n.cacheDressState=-1),n.cacheScroe=S.I.Score(n.baseData_get(),s.Job_get()),
n.cacheIsTakeOn=p.b.IsRecommendForRole(s,n.baseData_get())}e.Add(n),i+=1}if(e.Sort((0,R.v)(c.g.Inst_get().SortBossResultFunc,c.g.Inst_get())),
0==t.extraRewards.Count())this.normal.SetActive(!0),this.extra.SetActive(!1),this.rewardGrid.data_set(e)
else{this.normal.SetActive(!1),this.extra.SetActive(!0)
const i=new h.Z
let n=0
for(;n<t.extraRewards.Count();){const e=new d.Y
if(e.serverData_set(t.extraRewards[n]),e.baseData_get().isCanOperate=!1,e.baseData_get().isEquipCompare=!1,e.baseData_get().isEquip_get()){
const t=_.i.CanUseForTargetJob(s.Job_get(),e.baseData_get().cfgData_get().job)
e.cacheDressState=_.i.EquipScoreCompare(s,e.baseData_get()),t||(e.cacheDressState=-1),e.cacheScroe=S.I.Score(e.baseData_get(),s.Job_get()),
e.cacheIsTakeOn=p.b.IsRecommendForRole(s,e.baseData_get())}i.Add(e),n+=1}i.Sort((0,R.v)(c.g.Inst_get().SortBossResultFunc,c.g.Inst_get())),this.rewardGrid2.data_set(e),
this.rewardGrid3.data_set(i)}I.Y.Inst_get().forceColumn=0,this.hasClickRush=!1,this.time=15,this.SetCountdown(),
this.intervalId=a.C.Inst_get().SetInterval(this._degf_SetCountdown,1e3,-1),this.SetQuickPassInfo()}SetCountdown(){this.confirmBtn.SetText(`${(0,n.T)("确定")}（${this.time+(0,
n.T)("秒）")}`),this.normalConfirmBtn.SetText(`${(0,n.T)("确定")}（${this.time+(0,n.T)("秒）")}`),this.time-=1,this.time<0&&(a.C.Inst_get().ClearInterval(this.intervalId),
g.p.inst.ExitCopy(),D.x.Inst_get().CloseNormalSuccessView())}SetQuickPassInfo(){const t=T.o.Inst().getItemById(m.a.Inst_get().currentCopyId)
if(null==t)return
this.copyType=t.controllerType
const e=t.rushReward
if(w.D.Inst_get().hasRush||w.D.Inst_get().rewards.isNewHand||0==e||!f.P.Inst_get().IsFunctionOpened(C.x.WORLDBOSS_RUSH))return this.normalConfirmBtn.node.SetActive(!0),
this.confirmBtn.node.SetActive(!1),this.quickPassBtn.node.SetActive(!1),this.quickPassTip.SetActive(!1),this.noCopyTime.node.SetActive(!1),void this.vipDemand.node.SetActive(!1)
this.normalConfirmBtn.node.SetActive(!1),this.confirmBtn.node.SetActive(!0),this.quickPassBtn.node.SetActive(!0),this.rushState=0,this.leftCount=0,
this.leftCount=B._.Inst().WorldBossTired_get()
y.D.getInstance().GetIntValue("BOSSTIRED:DAILY_RECOVER_TIME")
v.U.inst.model.effectiveLevel_get()<e?(this.noCopyTime.node.SetActive(!1),this.quickPassTip.SetActive(!1),this.vipDemand.node.SetActive(!0),this.vipDemand.textSet(`VIP${e+(0,
n.T)("开启该功能")}`),this.rushState=1):this.leftCount>0?(this.noCopyTime.node.SetActive(!1),this.quickPassTip.SetActive(!0),this.vipDemand.node.SetActive(!1),
this.rushState=2):(this.noCopyTime.node.SetActive(!0),this.noCopyTime.textSet((0,n.T)("本日挑战次数已耗尽")),this.quickPassTip.SetActive(!1),this.vipDemand.node.SetActive(!1),
this.rushState=4)}OnClickRushBtn(t,e){if(!this.hasClickRush){const t=T.o.Inst().getItemById(m.a.Inst_get().currentCopyId)
if(this.SetQuickPassInfo(),3==this.rushState||4==this.rushState)A.y.inst.ClientSysMessage(10510002)
else if(1==this.rushState){const e=new h.Z([r.M.IntToString(t.rushReward)])
A.y.inst.ClientSysMessage(10510001,e)}else this.hasClickRush=!0}}OnGridReposition(){a.C.Inst_get().CallLater(this._degf_SetScrollBar)}OnGridReposition2(){
a.C.Inst_get().CallLater(this._degf_SetScrollBar2)}OnGridReposition3(){a.C.Inst_get().CallLater(this._degf_SetScrollBar3)}SetScrollBar(){this.scrollBar.ResetPosition(),
this.rewardGrid&&(this.rewardGrid.data_get().Count()>6?this.scrollBar.scrollToPercentHorizontal(0,0,!0):this.scrollBar.scrollToPercentHorizontal(.5,0,!0))}SetScrollBar2(){
this.scrollBar2.ResetPosition(),
this.rewardGrid2&&(this.rewardGrid2.data_get().Count()>6?this.scrollBar2.scrollToPercentHorizontal(0,0,!0):this.scrollBar2.scrollToPercentHorizontal(.5,0,!0))}SetScrollBar3(){
this.scrollBar3.ResetPosition(),
this.rewardGrid3&&(this.rewardGrid3.data_get().Count()>6?this.scrollBar3.scrollToPercentHorizontal(0,0,!0):this.scrollBar3.scrollToPercentHorizontal(.5,0,!0))}})||i},
89887:(t,e,s)=>{s.d(e,{e:()=>D})
var i=s(77546),n=s(98800),l=s(56937),o=s(18202),a=s(31222),r=s(5494),h=s(52726),d=s(85602),c=s(38836),I=s(9986),u=s(6665),p=s(61911),_=s(86133),g=s(68662),m=s(9057),S=s(57834),f=s(93877),C=s(98885),T=s(22662),y=s(65550)
class A extends m.x{constructor(){super(),this.logNameLabel=null,this.upLoadBtn=null,this.fullName=null,this.lastUpTime=0,this._degf_UpLoadHandler=null,
this._degf_UpLoadHandler=(t,e)=>this.UpLoadHandler(t,e)}InitView(){super.InitView(),this.logNameLabel=new f.Q,this.logNameLabel.setId(this.FatherId,this.FatherComponentID,1),
this.upLoadBtn=new I.W,this.upLoadBtn.setId(this.FatherId,this.FatherComponentID,2),this.AddLis()}SetData(t){this.fullName=t
const e=C.M.Split(this.fullName,C.M.s_Arr_B_SLASH_DOT),s=C.M.Split(e[e.Count()-1],C.M.s_Arr_F_SLASH_DOT),i=s[s.Count()-1]
this.logNameLabel.textSet(i)}UpLoadHandler(t,e){const s=g.D.clientMSTime_get()
s-this.lastUpTime<3e4||(this.lastUpTime=s,D.UpLoadLog(this.fullName),y.y.inst.ClientStrMsg(T.r.SystemTipMessage,(0,_.T)("游戏日志上传成功")))}AddLis(){
S.i.Get(this.upLoadBtn.node).RegistonClick(this._degf_UpLoadHandler)}RemoveLis(){S.i.Get(this.upLoadBtn.node).RemoveonClick(this._degf_UpLoadHandler)}Clear(){this.RemoveLis()}
Destroy(){this.logNameLabel=null,this.upLoadBtn=null,this.fullName=null}}class v extends p.f{constructor(){super(),this.closeBtn=null,this.grid=null,this._degf_OnCloseClick=null,
this._degf_OnItemRefreshFun=null,this._degf_OnCloseClick=(t,e)=>this.OnCloseClick(t,e),this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t)}InitView(){super.InitView(),
this.closeBtn=new I.W,this.closeBtn.setId(this.FatherId,this.FatherComponentID,1),this.grid=new u.A,this.grid.setId(this.FatherId,this.FatherComponentID,2),
this.grid.SetInitInfo("ui_upLoadLogItem",this._degf_OnItemRefreshFun)}OnItemRefreshFun(t){const e=new A
return e.setId(t,null,0),e}OnAddToScene(){super.OnAddToScene(),this.AddLis(),this.SetData()}SetData(){const t=new d.Z
for(const[e,s]of(0,c.V5)(D.Inst().voList))null!=s&&""!=s&&t.Add(s)
t.Count()>0&&this.grid.data_set(t)}Clear(){super.Clear(),this.RemoveLis()}Destroy(){this.closeBtn=null,this.grid=null}AddLis(){
this.AddClickEvent(this.closeBtn,this._degf_OnCloseClick)}RemoveLis(){this.RemoveClickEvent(this.closeBtn,this._degf_OnCloseClick)}OnCloseClick(t,e){D.Inst().Close()}}class D{
constructor(){this.voList=null,this.view=null,this._degf_CallDestroy=null,this._degf_ShowHandler=null,this._degf_CallDestroy=()=>this.CallDestroy(),
this._degf_ShowHandler=t=>this.ShowHandler(t)}static Inst(){return null==D.inst&&(D.inst=new D),D.inst}OpenUpLoadLogView(t){if(null==D.Inst().view||!D.Inst().view.isShow_get()){
D.Inst().voList=new d.Z(t.ToArray().ToTable())
const e=new l.v
e.layerType=h.F.Tip,e.isShowMask=!0,a.N.inst.OpenById(r.I.eUpLoadLogView,D.Inst()._degf_ShowHandler,D.Inst()._degf_CallDestroy,e)}}OpenUpLoadLogView2(){
if(null==D.Inst().view||!D.Inst().view.isShow_get()){const t=new d.Z,e=i.s.GetLogFiles(),s=e.Count
for(let i=0;i<=s-1;i++)t.Add(e[i].FullName)
D.Inst().voList=t
const n=new l.v
n.layerType=h.F.Tip,n.isShowMask=!0,a.N.inst.OpenById(r.I.eUpLoadLogView,D.Inst()._degf_ShowHandler,D.Inst()._degf_CallDestroy,n)}}UploadNearsLog(){
const t=i.s.GetLogFiles(),e=t.Count
if(e<=0)return!1
let s=t[e-1]
return s=s.FullName,D.UpLoadLog(s),!0}static UpLoadLog(t){let e="",s=""
const i=n.Y.Inst.PrimaryRoleInfo_get(!0)
null!=i&&(e=i.Id_get().ToString(),s=i.Name_get()),LogCatch.Instance.SetPlayerID(e),LogCatch.Instance.SetPlayerName(s),LogCatch.Instance.SendPlayerLog(t)}ShowHandler(t){
return null==this.view&&(this.view=new v,this.view.setId(t,null,0)),this.view}CallDestroy(){o.g.DestroyUIObj(this.view),this.view=null}Close(){
a.N.inst.CloseById(r.I.eUpLoadLogView)}}D.inst=null},91037:(t,e,s)=>{s.d(e,{Z:()=>I})
var i,n=s(42292),l=s(38836),o=s(25236),a=s(38045),r=s(87676),h=s(66788),d=s(60069),c=s(12338)
let I=(0,n.Y_)("FunctionUtil")(i=class t{static CheckDelegateTarget(e,s){if(null==e)return!1
null==s&&(s="")
const i=t._GetSelfUpValue(e)
if(null!=i&&"table"==typeof i)if((0,a.t2)(i,d.r)){const n=i,l=n.GetInternalCallBacks()
if(null!=l){for(const[e,s]of l){if(0==t.CheckDelegateTarget(s))return!1}return!0}let o=!1
if(c.K.IsDestroyed(i)&&(o=!0),o)return h.Y.LogError(`${s}Destroy 或者关闭 后没移除干净回调！${t.FunctionToString(e)}\n 在Clear()方法中移除 \n所在资源:${PrefabBinderBridge.GetResNameByFatherId(n.FatherId)}\n${t.ToSelfStr(i)}`),
!1}else if((0,a.t2)(i,r.t)){if(!(0,a.t2)(i,INS.Player)){const n=i
if(n.IsDestroyed())return 0!=n.isRecycle||(h.Y.LogError(`${s}场景元素 Destroy 后没移除干净回调！ ${t.FunctionToString(e)}\n 在Destroy()方法中移除\n${t.ToSelfStr(i)}`),!1)}}else{
if(null!=i.__GetInternalComponents){const n=i.__GetInternalComponents()
let o=!0
for(const[t,e]of(0,l.X)(n))if(c.K.IsDestroyed(e)){o=!1
break}if(!o){let o="",a=5
for(const[e,s]of(0,l.X)(n))if(c.K.IsDestroyed(s)&&(o+=`${t.ToSelfStr(s)}\n`),a-=1,a<=0)break
return h.Y.LogError(`${s}实例 Destroy 后没移除干净回调！${t.FunctionToString(e)}\n 在Destroy()方法中移除\n${t.ToSelfStr(i)}\n包含的组件:\n${o}`),!1}}
if(null!=i.IsDestroyed&&i.IsDestroyed())return h.Y.LogError(`${s}实例 Destroy 后没移除干净回调！ ${t.FunctionToString(e)}\n 在Destroy()方法中移除\n${t.ToSelfStr(i)}`),!1}return!0}
static ToSelfStr(t){return null!=t.GetTypeName?t.GetTypeName():null!=t._class_type_?t._class_type_._type_full_name_:""}static _GetSelfUpValue(e){return t._GetUpValue(e,"self")}
static _GetUpValue(t,e){for(let s=1;s<=Math.huge;s++){const[i,n]=debug.getupvalue(t,s)
if(null==i)break
if(i==e)return n}return null}static FunctionToString(e){const s=t._GetUpValue(e,"funcFromSelf")
null!=s&&(e=s)
const i=debug.getinfo(e)
return`function src:${i.short_src}:${i.linedefined}`}CalCostTime(t,e){const s=os.clock()
e()
const i=os.clock()-s
return(0,o.S)(string.format("%s cost time  : %.4f",t,i)),i}})||i},12338:(t,e,s)=>{s.d(e,{K:()=>q})
var i=s(38836),n=s(38045),l=s(96617),o=s(5924),a=s(66788),r=s(99294),h=s(86290),d=s(30849),c=s(85602),I=s(38962)
let u=null,p=null,_=null,g=null,m=null,S=null,f=null,C=null,T=null,y=null,A=null,v=null,D=null,w=null,B=null,M=null,b=null,O=null,R=null,L=null,G=null,P=null,E=null,k=null,N=null,V=null,x=null,F=null,U=null,H=null,j=null,W=null,Y=null
class q{static __StaticInit(){u=table.insert,p=table.sort,_=table.remove,g=c.Z.new,m=c.Z.Add,S=c.Z.AddRang,f=c.Z.Clear,C=c.Z.Contains,T=c.Z.Insert,y=c.Z.InsertRange,A=c.Z.Remove,
v=c.Z.RemoveAt,D=c.Z.IndexOf,w=c.Z.Count,B=c.Z.Length,M=c.Z.RemoveRange,b=c.Z.GetRange,O=c.Z.Pop,R=c.Z.Reverse,L=c.Z.Sort,G=I.X.new,P=I.X.LuaDic_Add,E=I.X.LuaDic_SetItem,
k=I.X.LuaDic_IsNullValue,N=I.X.LuaDic_GetItem,V=I.X.LuaDic_Count,x=I.X.LuaDic_ContainsKey,F=I.X.LuaDic_AddOrSetItem,U=I.X.LuaDic_Keys,H=I.X.LuaDic_Values,j=I.X.LuaDic_Clear,
W=I.X.LuaDic_ContainsValue,Y=I.X.LuaDic_Remove}GetGameObjectName(t,e){return GameObjectUtilBridge.GetGameObjectName(t,e)}IsDestroyed(t){if(null==t)return!0
const e=PrefabBinderBridge.HasBinder(t.FatherId)
let s=e
if((0,n.t2)(t,d.C)){const i=t
if(i.IsRootPrefab())return s=0==i.IsDestroyed(),s!=e&&a.Y.LogError(`${t.GetTypeName()} 和CS层binder销毁状态不一致， 存在状态->CS层：${(0,n.tw)(e)} Lua:${(0,n.tw)(s)}`),0==e}return 0==e}
IsNotNil(t){return null!=t&&t.IsCompoentExist()}GetTransformParent(t){const e=GameObjectUtilBridge.GetTransformParent(t.FatherId,t.ComponentId)
if(e<=0)return null
const s=new h.G
return s.SetIdExternal(t.FatherId,e),s.InitGameObject(null),s}GetComponentInParrentPrefabBinder(t,e,s){
const i=GameObjectUtilBridge.GetComponentInParentPrefabBinder(t.FatherId,t.ComponentId,e,s)
if(i<=0)return null
const n=new r.z
return n.SetIdExternal(t.FatherId,i),n}IsParentCheckSafe(t,e,s){return s=s||!0,GameObjectUtilBridge.IsParentCheckSafe(t.FatherId,t.ComponentId,e.FatherId,e.ComponentId,s)}
SetBtnSp(t,e,s,i,n,o,r,h){l.A.IsEmptyStr(s)?a.Y.LogError("图集名称为空"):l.A.IsEmptyStr(i)?a.Y.LogError("查找 按钮三态图片，正常态图片为空"):null!=t?(t.HighlightedSpriteSet(s,n),t.PressedSpriteSet(s,o),
t.DisabledSpriteSet(s,r)):null!=e&&e.SetSpriteIcon(s,i)}IsParent(t,e,s){return s=s||!0,GameObjectUtilBridge.IsParent(t.FatherId,t.ComponentId,e.FatherId,e.ComponentId,s)}
CallClickToBtn(t,e){e=e||!0,GameObjectUtilBridge.CallClickToBtn(t.FatherId,t.ComponentId,e)}SetTextText(t,e){for(let e=1;e<=t.Count();e++)null!=t[e]&&t[e].SetText()}
SetBtnEnable(t,e,s,i){s=s||!0,i=i||!0,t.SetIsEnabled(e),s&&GameObjectUtilBridge.makeGoGray(t.FatherId,t.ComponentId,!e,!0,i)}SetGoGray(t,e,s,i){s=s||!1,i=i||!0,
GameObjectUtilBridge.makeGoGray(t.FatherId,t.ComponentId,e,s,i)}ResetPositionScrollView(t,e){GameObjectUtilBridge.ResetPositionScrollView(t.FatherId,t.ComponentId),
e&&o.C.Inst_get().SetFrameLoopForParm(q._ResetPostionFrame,10,10,t)}static _ResetPostionFrame(t,e){null!=e&&q.ResetPositionScrollView(e)}ResetAnchor(t){
0!=t.activeSelf()&&GameObjectUtilBridge.ResetAnchor(t.FatherId,t.ComponentId)}SetGameObjectActiveAtIdx(t,e){for(let s=0;s<=t.Count();s++)null!=t[s]&&t[s].SetActive(s==e)}
SetGameObjectActiveByCount(t,e){for(let s=0;s<=t.Count();s++)null!=t[s]&&t[s].SetActive(s<e)}SetActiveObjsParams(t,...e){const s=[...e]
q.SetActiveObjs(t,s)}static SetActiveObjs(t,e){for(const[s,n]of(0,i.vy)(e))null!=n&&GameObjectBridge.SetActive(n.FatherId,n.ComponentId,t)}GetPath(t){
return GameObjectUtilBridge.GetPathLua(t.FatherId,t.ComponentId)}SetParentToOtherObj(t,e){
GameObjectUtilBridge.SetParentToOtherObj(t.FatherId,t.ComponentId,e.FatherId,e.ComponentId)}}},67642:(t,e,s)=>{s.d(e,{S:()=>i})
class i{static CreateTableArr(t,e){null==e&&(e=!1)
const s=[]
for(let i=0;i<t;i++)s[i]=e
return s}}function n(t){return e=>{null==e&&(e=!1)
const s=[]
for(let i=0;i<t;i++)s[i]=e
return s}}i.CreateTableArr0=n(0),i.CreateTableArr1=n(1),i.CreateTableArr2=n(2),i.CreateTableArr3=n(3),i.CreateTableArr4=n(4),i.CreateTableArr5=n(5),i.CreateTableArr6=n(6),
i.CreateTableArr7=n(7),i.CreateTableArr8=n(8),i.CreateTableArr9=n(9),i.CreateTableArr10=n(10),i.CreateTableArr11=n(11),i.CreateTableArr12=n(12),i.CreateTableArr13=n(13),
i.CreateTableArr14=n(14),i.CreateTableArr15=n(15),i.CreateTableArr16=n(16),i.CreateTableArr17=n(17),i.CreateTableArr18=n(18),i.CreateTableArr19=n(19),i.CreateTableArr20=n(20),
i.CreateTableArr21=n(21),i.CreateTableArr22=n(22),i.CreateTableArr23=n(23),i.CreateTableArr24=n(24),i.CreateTableArr25=n(25),i.CreateTableArr26=n(26),i.CreateTableArr27=n(27),
i.CreateTableArr28=n(28),i.CreateTableArr29=n(29),i.CreateTableArr30=n(30),i.CreateTableArr31=n(31),i.CreateTableArr32=n(32),i.CreateTableArr33=n(33),i.CreateTableArr34=n(34),
i.CreateTableArr35=n(35),i.CreateTableArr36=n(36),i.CreateTableArr37=n(37),i.CreateTableArr38=n(38),i.CreateTableArr39=n(39),i.CreateTableArr40=n(40),i.CreateTableArr41=n(41),
i.CreateTableArr42=n(42),i.CreateTableArr43=n(43),i.CreateTableArr44=n(44),i.CreateTableArr45=n(45),i.CreateTableArr46=n(46),i.CreateTableArr47=n(47),i.CreateTableArr48=n(48),
i.CreateTableArr49=n(49),i.CreateTableArr50=n(50),i.CreateTableArr51=n(51),i.CreateTableArr52=n(52),i.CreateTableArr53=n(53),i.CreateTableArr54=n(54),i.CreateTableArr55=n(55),
i.CreateTableArr56=n(56),i.CreateTableArr57=n(57),i.CreateTableArr58=n(58),i.CreateTableArr59=n(59),i.CreateTableArr60=n(60),i.CreateTableArr61=n(61),i.CreateTableArr62=n(62),
i.CreateTableArr63=n(63),i.CreateTableArr64=n(64),i.CreateTableArr65=n(65),i.CreateTableArr66=n(66),i.CreateTableArr67=n(67),i.CreateTableArr68=n(68),i.CreateTableArr69=n(69),
i.CreateTableArr70=n(70),i.CreateTableArr71=n(71),i.CreateTableArr72=n(72),i.CreateTableArr73=n(73),i.CreateTableArr74=n(74),i.CreateTableArr75=n(75),i.CreateTableArr76=n(76),
i.CreateTableArr77=n(77),i.CreateTableArr78=n(78),i.CreateTableArr79=n(79),i.CreateTableArr80=n(80),i.CreateTableArr81=n(81),i.CreateTableArr82=n(82),i.CreateTableArr83=n(83),
i.CreateTableArr84=n(84),i.CreateTableArr85=n(85),i.CreateTableArr86=n(86),i.CreateTableArr87=n(87),i.CreateTableArr88=n(88),i.CreateTableArr89=n(89),i.CreateTableArr90=n(90),
i.CreateTableArr91=n(91),i.CreateTableArr92=n(92),i.CreateTableArr93=n(93),i.CreateTableArr94=n(94),i.CreateTableArr95=n(95),i.CreateTableArr96=n(96),i.CreateTableArr97=n(97),
i.CreateTableArr98=n(98),i.CreateTableArr99=n(99),i.CreateTableArr100=n(100),i.CreateTableArr101=n(101),i.CreateTableArr102=n(102),i.CreateTableArr103=n(103),
i.CreateTableArr104=n(104),i.CreateTableArr105=n(105),i.CreateTableArr106=n(106),i.CreateTableArr107=n(107),i.CreateTableArr108=n(108),i.CreateTableArr109=n(109),
i.CreateTableArr110=n(110),i.CreateTableArr111=n(111),i.CreateTableArr112=n(112),i.CreateTableArr113=n(113),i.CreateTableArr114=n(114),i.CreateTableArr115=n(115),
i.CreateTableArr116=n(116),i.CreateTableArr117=n(117),i.CreateTableArr118=n(118),i.CreateTableArr119=n(119),i.CreateTableArr120=n(120),i.CreateTableArr121=n(121),
i.CreateTableArr122=n(122),i.CreateTableArr123=n(123),i.CreateTableArr124=n(124),i.CreateTableArr125=n(125),i.CreateTableArr126=n(126),i.CreateTableArr127=n(127),
i.CreateTableArr128=n(128),i.CreateTableArr129=n(129),i.CreateTableArr130=n(130),i.CreateTableArr131=n(131),i.CreateTableArr132=n(132),i.CreateTableArr133=n(133),
i.CreateTableArr134=n(134),i.CreateTableArr135=n(135),i.CreateTableArr136=n(136),i.CreateTableArr137=n(137),i.CreateTableArr138=n(138),i.CreateTableArr139=n(139),
i.CreateTableArr140=n(140),i.CreateTableArr141=n(141),i.CreateTableArr142=n(142),i.CreateTableArr143=n(143),i.CreateTableArr144=n(144),i.CreateTableArr145=n(145),
i.CreateTableArr146=n(146),i.CreateTableArr147=n(147),i.CreateTableArr148=n(148),i.CreateTableArr149=n(149),i.CreateTableArr150=n(150),i.CreateTableArr151=n(151),
i.CreateTableArr152=n(152),i.CreateTableArr153=n(153),i.CreateTableArr154=n(154),i.CreateTableArr155=n(155),i.CreateTableArr156=n(156),i.CreateTableArr157=n(157),
i.CreateTableArr158=n(158),i.CreateTableArr159=n(159),i.CreateTableArr160=n(160),i.CreateTableArr161=n(161),i.CreateTableArr162=n(162),i.CreateTableArr163=n(163),
i.CreateTableArr164=n(164),i.CreateTableArr165=n(165),i.CreateTableArr166=n(166),i.CreateTableArr167=n(167),i.CreateTableArr168=n(168),i.CreateTableArr169=n(169),
i.CreateTableArr170=n(170),i.CreateTableArr171=n(171),i.CreateTableArr172=n(172),i.CreateTableArr173=n(173),i.CreateTableArr174=n(174),i.CreateTableArr175=n(175),
i.CreateTableArr176=n(176),i.CreateTableArr177=n(177),i.CreateTableArr178=n(178),i.CreateTableArr179=n(179),i.CreateTableArr180=n(180),i.CreateTableArr181=n(181),
i.CreateTableArr182=n(182),i.CreateTableArr183=n(183),i.CreateTableArr184=n(184),i.CreateTableArr185=n(185),i.CreateTableArr186=n(186),i.CreateTableArr187=n(187),
i.CreateTableArr188=n(188),i.CreateTableArr189=n(189),i.CreateTableArr190=n(190),i.CreateTableArr191=n(191),i.CreateTableArr192=n(192),i.CreateTableArr193=n(193),
i.CreateTableArr194=n(194),i.CreateTableArr195=n(195),i.CreateTableArr196=n(196),i.CreateTableArr197=n(197),i.CreateTableArr198=n(198),i.CreateTableArr199=n(199),
i.CreateTableArr200=n(200),i.CreateTableArr201=n(201),i.CreateTableArr202=n(202),i.CreateTableArr203=n(203),i.CreateTableArr204=n(204),i.CreateTableArr205=n(205),
i.CreateTableArr206=n(206),i.CreateTableArr207=n(207),i.CreateTableArr208=n(208),i.CreateTableArr209=n(209),i.CreateTableArr210=n(210),i.CreateTableArr211=n(211),
i.CreateTableArr212=n(212),i.CreateTableArr213=n(213),i.CreateTableArr214=n(214),i.CreateTableArr215=n(215),i.CreateTableArr216=n(216),i.CreateTableArr217=n(217),
i.CreateTableArr218=n(218),i.CreateTableArr219=n(219),i.CreateTableArr220=n(220),i.CreateTableArr221=n(221),i.CreateTableArr222=n(222),i.CreateTableArr223=n(223),
i.CreateTableArr224=n(224),i.CreateTableArr225=n(225),i.CreateTableArr226=n(226),i.CreateTableArr227=n(227),i.CreateTableArr228=n(228),i.CreateTableArr229=n(229),
i.CreateTableArr230=n(230),i.CreateTableArr231=n(231),i.CreateTableArr232=n(232),i.CreateTableArr233=n(233),i.CreateTableArr234=n(234),i.CreateTableArr235=n(235),
i.CreateTableArr236=n(236),i.CreateTableArr237=n(237),i.CreateTableArr238=n(238),i.CreateTableArr239=n(239),i.CreateTableArr240=n(240),i.CreateTableArr241=n(241),
i.CreateTableArr242=n(242),i.CreateTableArr243=n(243),i.CreateTableArr244=n(244),i.CreateTableArr245=n(245),i.CreateTableArr246=n(246),i.CreateTableArr247=n(247),
i.CreateTableArr248=n(248),i.CreateTableArr249=n(249),i.CreateTableArr250=n(250),i.CreateTableArr251=n(251),i.CreateTableArr252=n(252),i.CreateTableArr253=n(253),
i.CreateTableArr254=n(254),i.CreateTableArr255=n(255),i.CreateTableArr512=n(512),i.CreateTableArr1024=n(1024),i.CreateTableArr2048=n(2048),i.CreateTableArr4096=n(4096)},
24772:(t,e,s)=>{s.d(e,{C:()=>U})
var i=s(38836),n=s(85602),l=s(38962),o=s(30143),a=s(17838)
let r=null,h=null,d=null,c=null,I=null,u=null,p=null,_=null,g=null,m=null,S=null,f=null,C=null,T=null,y=null,A=null,v=null,D=null,w=null,B=null,M=null,b=null,O=null,R=null,L=null,G=null,P=null,E=null,k=null,N=null,V=null,x=null,F=null
class U{static __StaticInit(){r=table.insert,h=table.sort,d=table.remove,c=n.Z.new,I=n.Z.Add,u=n.Z.AddRang,p=n.Z.Clear,_=n.Z.Contains,g=n.Z.Insert,m=n.Z.InsertRange,S=n.Z.Remove,
f=n.Z.RemoveAt,C=n.Z.IndexOf,T=n.Z.Count,y=n.Z.Length,A=n.Z.RemoveRange,v=n.Z.GetRange,D=n.Z.Pop,w=n.Z.Reverse,B=n.Z.Sort,M=l.X.new,b=l.X.LuaDic_Add,O=l.X.LuaDic_SetItem,
R=l.X.LuaDic_IsNullValue,L=l.X.LuaDic_GetItem,G=l.X.LuaDic_Count,P=l.X.LuaDic_ContainsKey,E=l.X.LuaDic_AddOrSetItem,k=l.X.LuaDic_Keys,N=l.X.LuaDic_Values,V=l.X.LuaDic_Clear,
x=l.X.LuaDic_ContainsValue,F=l.X.LuaDic_Remove}Test1(){return!0}static CreateBaseJsonClass(t,e){let s=e,i=null
if(null!=t){if(null==s){let e=t.__type
null==e&&(e=t.type),s=U.GetClassByType(e),i=new s}else i=new s
null!=i&&U.FillJsonData(i,t,!0)}return i}static CreateBaseJsonClassFast(t,e,s){let n=null,l=null
if(null!=t){let o=t.__type
if(null==o&&(o=t.type),null==o)return l
if(n=e(o),l=_SetClassToTable(t,n,!1),null!=s&&s(t,o,n),null!=l)for(const[n,l]of(0,i.X)(t))"table"==typeof l&&U.CreateBaseJsonClassFast(l,e,s)}return l}
static CreateBaseJsonBy__GetFieldType(t,e,s){const i=t
if(null==e)return i
let l=null
if(e==n.Z){l=new n.Z
for(let t=0;t<i.length;t++){const e=new s
a.g.FillJsonData(e,i[t],!0),l.Add(e)}}else l=new e,a.g.FillJsonData(l,i,!0)
return l}static FillJsonData(t,e,s){null==s&&(s=!0)
for(const[n,l]of(0,i.X)(e))s&&"table"==typeof l?(null==t[n]&&(t[n]={}),U.FillJsonData(t[n],l,s)):t[n]=l}static GetClassByType(t){let e=null
return"CommandUseItem"==t&&(e=o.N),e}}},81266:(t,e,s)=>{s.d(e,{E:()=>r})
var i=s(38836),n=s(75327)
let l=null,o=null,a=null
class r{static __StaticInit(){l={__mode:"k"},o={__mode:"v"},a={__mode:"kv"}}Count(t){let e=0
for(const[s,n]of(0,i.X)(t))e+=1
return e}IsArrayTable(t){const e=t.length
let s=1
for(const[e,n]of(0,i.X)(t)){if(e!=s)return!1
s+=1}return s==e+1}ClearTable(t){for(const[e,s]of(0,i.X)(t))t[e]=null}static CloneTable(t,e,s){null==s&&(s=!0)
for(const[n,l]of(0,i.X)(e))s&&"table"==typeof l&&"_class_type_"!=n&&"_class_type_meta_cache_"!=n?(null==t[n]&&(t[n]={}),r.CloneTable(t[n],l,s)):t[n]=l}GetKeys(t){const e={}
for(const[s,n]of(0,i.X)(t))table.insert(e,s)
return e}static CreateTableRepeat(t,e){const s={}
for(let i=1;i<=e;i++)s[i]=t
return s}HasValue(t){for(const[e,s]of(0,i.X)(t))return!0
return!1}GetValueDefault(t,e,s){const i=t[e]
return null==i?s:i}GetValue(t,e,s,i,l,o,a,r,h,d){let c=t
return null==e?((0,n.vU)("p1 cannot be nil"),null):(c=c[e],null==s||null==c?c:(c=c[s],null==i||null==c?c:(c=c[i],null==l||null==c?c:(c=c[l],null==o||null==c?c:(c=c[o],
null==a||null==c?c:(c=c[a],null==r||null==c?c:(c=c[r],null==h||null==c?c:(c=c[h],null==d||null==c||(c=c[d]),c))))))))}GetValue1(t,e){let s=t
return s=s[e],s}static GetValue2(t,e,s){let i=t
return i=i[e],null==i||(i=i[s]),i}GetValue3(t,e,s,i){let n=t
return n=n[e],null==n?n:(n=n[s],null==n||(n=n[i]),n)}GetValue4(t,e,s,i,n){let l=t
return l=l[e],null==l?l:(l=l[s],null==l?l:(l=l[i],null==l||(l=l[n]),l))}GetValue5(t,e,s,i,n,l){let o=t
return o=o[e],null==o?o:(o=o[s],null==o?o:(o=o[i],null==o?o:(o=o[n],null==o||(o=o[l]),o)))}GetValue6(t,e,s,i,n,l,o){let a=t
return a=a[e],null==a?a:(a=a[s],null==a?a:(a=a[i],null==a?a:(a=a[n],null==a?a:(a=a[l],null==a||(a=a[o]),a))))}static SetValue(t,e,s,i,l,o,a,r,h,d,c,I){let u=t
if(null!=i)return null==l?(u[i]=e,!0):(s&&null==u[i]&&(u[i]={}),u=u[i],null!=u&&(null==o?(u[l]=e,!0):(s&&null==u[l]&&(u[l]={}),u=u[l],null!=u&&(null==a?(u[o]=e,
!0):(s&&null==u[o]&&(u[o]={}),u=u[o],null!=u&&(null==r?(u[a]=e,!0):(s&&null==u[a]&&(u[a]={}),u=u[a],null!=u&&(null==h?(u[r]=e,!0):(s&&null==u[r]&&(u[r]={}),u=u[r],
null!=u&&(null==d?(u[h]=e,!0):(s&&null==u[h]&&(u[h]={}),u=u[h],null!=u&&(null==c?(u[d]=e,!0):(s&&null==u[d]&&(u[d]={}),u=u[d],null!=u&&(null==I?(u[c]=e,
!0):(s&&null==u[c]&&(u[c]={}),u=u[c],null!=u&&(u[I]=e,!0))))))))))))))));(0,n.vU)("p1 cannot be nil")}static CreateWeakTable(t,e){let s=l
return e&&(s=t?a:o),{}}}},50679:(t,e,s)=>{s.d(e,{V:()=>I})
var i=s(66788),n=s(30849),l=s(18202),o=s(31222),a=s(60130),r=s(85602)
let h=null,d=null,c=null
class I{static __StaticInit(){h=table.insert,d=table.sort,c=table.remove}constructor(){this.uiLoaded=null,this.show=!0,this.localPos=null,this.loadedParams=null,this.curGo=null,
this.goParent=null,this.resName=null,this.uiFatherId=0,this.panelParent=null,this.resComp=null,this.pathList=null,this.isLoading=!1,this.def__OnLoadComplete=null,
this.localEuler=null,this.localScale=null,this.curGO=null,this.def__OnLoadComplete=t=>{this._OnLoadComplete(t)}}CreateByIdx(t,e,s,i,n,l,o){const a=this.pathList[t]
this.CreateByName(a,e,s,i,n,l,o)}CreateByName(t,e,s,n,o,a,h){if(null==a&&(a=0),null!=t&&""!=t){if(this.resName==t){if(null!=this.curGo)return this._UpdateCurGo(),
void(null!=s&&s(this.curGo.FatherId,n))
if(this.isLoading)return
i.Y.LogError("不应该运行到这里")}if(this.isLoading)i.Y.LogError("加载时不能切换加载另一个")
else if(this.Clear(),this.resName=t,this.uiLoaded=s,this.loadedParams=n,this.goParent=e,this.uiFatherId=a,this.panelParent=o,l.g.IsResLoaded(t)){
const e=l.g.GetResFindId(t),s=new r.Z([e])
this._OnLoadComplete(s)}else{const e=new r.Z([t])
this.isLoading=!0,l.g.LoadPaths(e,this.def__OnLoadComplete)}}else this.Clear()}SetUIData(t,e,s,i,n,l,o,a){null==o&&(o=0),this.show=t,this.resName=e,this.uiLoaded=i,
this.loadedParams=n,this.goParent=s,this.uiFatherId=o,this.panelParent=l,t&&this.SetActive(t)}_UpdateCurGo(){
null!=this.curGo&&(null!=this.localPos&&this.curGo.SetLocalPosition(this.localPos),this.localEuler&&this.curGo.SetLocalEulerAngles(this.localEuler),
this.localScale&&this.curGo.SetLocalScale(this.localScale),this.curGo.node.SetActive(this.show))}SetLocalPosition(t){this.localPos=t,
null!=this.curGo&&null!=this.localPos&&this.curGo.SetLocalPosition(this.localPos)}SetLocalEulerAngles(t){this.localEuler=t,
null!=this.curGo&&this.localEuler&&this.curGo.SetLocalEulerAngles(this.localEuler)}SetLocalScale(t){this.localScale=t,
null!=this.curGo&&this.localScale&&this.curGo.SetLocalScale(this.localScale)}SetActive(t){if(this.show=t,null!=this.curGo)this.curGo.node.SetActive(this.show)
else if(this.show&&null!=this.resName&&""!=this.resName){if(this.isLoading)return
const t=new r.Z([this.resName])
this.isLoading=!0,l.g.LoadPaths(t,this.def__OnLoadComplete)}}_OnLoadComplete(t){const e=t[0],s=new n.C
if(s.setPrefabRootId(e),null!=this.panelParent?(a.O.AddUIEffectSortOrderBind(s.node,!0),
a.O.UIEffectSortOrderAddChild(this.goParent,s.node)):s.node.transform.SetParent(this.goParent.FatherId,this.goParent.ComponentId,!0),
this.uiFatherId>0&&o.N.inst.SetChildDepth(this.uiFatherId,e),(null==this.curGo||!this.curGo.EqualId(s))&&(null!=this.curGO&&this.curGo.EqualId(s),this.curGo=s,this._UpdateCurGo(),
this.isLoading=!1,null!=this.uiLoaded)){const t=this.uiLoaded,s=this.loadedParams
this.uiLoaded=null,this.loadedParams=null,t(e,s)}}Clear(){null!=this.curGo&&(this.curGo.Clear(),this.curGo.Destroy(),l.g.DestroyUIObj(this.curGo),this.curGo=null),
l.g.Unload(this.def__OnLoadComplete),this.loadedParams=null,this.uiLoaded=null,this.goParent=null,this.resName=null,this.isLoading=!1}Destroy(){this.Clear()}}}}])
