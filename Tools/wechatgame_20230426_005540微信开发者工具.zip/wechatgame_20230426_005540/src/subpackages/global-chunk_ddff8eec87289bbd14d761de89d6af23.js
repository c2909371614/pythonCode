"use strict";(globalThis.webpackChunkProject=globalThis.webpackChunkProject||[]).push([[253],{83234:(t,e,i)=>{
var s,n,l=i(18998),a=i(83908),o=i(86133),r=i(5924),h=i(66788),d=i(98130),c=i(85602),_=i(88653)
class u{constructor(){this.curHpBar=0,this.curHp=0,this.curPercent=0,this.tempHpBar=0,this.tempHp=0,this.tempPercent=0,this.eachHp=0,this.offset=0,this.tempStartHp=0}
SetData(t,e,i,s,n,l){this.curHpBar=t,this.curHp=e,this.tempHpBar=i,this.tempHp=s,this.tempStartHp=s,this.eachHp=n,this.offset=l,
this.curPercent=(this.curHp-(this.curHpBar-1)*this.eachHp)/this.eachHp,this.tempPercent=(this.tempHp-(this.tempHpBar-1)*this.eachHp)/this.eachHp}UpdateVO(t){
this.tempHp=this.tempStartHp-this.offset*t,this.tempHpBar=d.GF.INT(this.tempHp/this.eachHp)+1,this.tempPercent=(this.tempHp-(this.tempHpBar-1)*this.eachHp)/this.eachHp}}
l._decorator.ccclass("BossHpBar")(((n=class extends((0,a.zB)()){constructor(...t){super(...t),this.eachHp=0,this.m_curHp=0,this.maxHp=0,this.maxBarNum=0,this.tempHp=0,
this.isInAnime=!1,this.hpColor=null,this.fixTimes=16,this.intervalId=-1,this.curTimes=0,this.hpVo=null,this._degf_UpdateHpBar=null}_initBinder(){super._initBinder(),
this.hpColor=new c.Z(["rymainui_sp_0029","rymainui_sp_0061","rymainui_sp_0062","rymainui_sp_0063","rymainui_sp_0064"]),this._degf_UpdateHpBar=()=>this.UpdateHpBar()}InitView(){}
Destroy(){}Clear(){this.isInAnime=!1,r.C.Inst_get().ClearInterval(this.intervalId)}Init(t,e,i){this.m_curHp=t,this.maxHp=e,this.maxBarNum=i,this.eachHp=e/i
let s=0
s=this.m_curHp==this.maxHp?this.maxBarNum:d.GF.INT(this.m_curHp/this.eachHp)+1
const n=(this.m_curHp-(s-1)*this.eachHp)/this.eachHp
this.InitHpBar(s,n)}Refresh(t,e){if(e>this.maxHp&&h.Y.Log((0,o.T)("当前血量大于最大血量")),t==e)return
this.isInAnime?this.tempHp=this.hpVo.tempHp:this.tempHp=t
const i=d.GF.INT(e/this.eachHp)+1,s=d.GF.INT(this.tempHp/this.eachHp)+1,n=(this.tempHp-e)/this.fixTimes
null==this.hpVo&&(this.hpVo=new u),this.hpVo.SetData(i,e,s,this.tempHp,this.eachHp,n),r.C.Inst_get().ClearInterval(this.intervalId),this.curTimes=0,this.isInAnime=!0,
this.intervalId=r.C.Inst_get().SetInterval(this._degf_UpdateHpBar,30,this.fixTimes)}InitHpBar(t,e){this.barNumLabel.textSet(`X${t}`),
1==t?this.bottomSpt.SetColor(new _.I(0,0,0,0)):(this.bottomSpt.SetColor(new _.I(1,1,1,1)),this.bottomSpt.spriteNameSet(this.hpColor[(t-2)%5],"mainui")),
this.topSpt.spriteNameSet(this.hpColor[(t-1)%5],"mainui"),this.tempSpt.spriteNameSet(this.hpColor[(t-1)%5],"mainui"),this.topPanel.progress=e,this.tempPanel.progress=e}
UpdateHpBar(){this.curTimes+=1,this.hpVo.UpdateVO(this.curTimes),this.barNumLabel.textSet(`X${this.hpVo.tempHpBar}`),
1==this.hpVo.tempHpBar?this.bottomSpt.SetColor(new _.I(0,0,0,0)):(this.bottomSpt.SetColor(new _.I(1,1,1,1)),
this.bottomSpt.spriteNameSet(this.hpColor[(this.hpVo.tempHpBar-2)%5],"mainui")),this.hpVo.curHpBar==this.hpVo.tempHpBar?(this.topSpt.SetColor(new _.I(1,1,1,1)),
this.topSpt.spriteNameSet(this.hpColor[(this.hpVo.curHpBar-1)%5],"mainui"),this.topPanel.progress=this.hpVo.curPercent):this.topSpt.SetColor(new _.I(0,0,0,0)),
this.tempSpt.spriteNameSet(this.hpColor[(this.hpVo.tempHpBar-1)%5],"mainui"),this.tempPanel.progress=this.hpVo.tempPercent,
this.curTimes==this.fixTimes&&(r.C.Inst_get().ClearInterval(this.intervalId),this.curTimes=0,this.isInAnime=!1,this.InitHpBar(this.hpVo.curHpBar,this.hpVo.curPercent))}
}).BAR_LENGTH=308,s=n))},30627:(t,e,i)=>{i.d(e,{t:()=>v})
var s=i(17409),n=i(49655),l=i(98800),a=i(97461),o=i(50089),r=i(5924),h=i(56937),d=i(31222),c=i(5494),_=i(52726),u=i(98789),I=i(35128),m=i(98130),g=i(52212),p=i(85430),C=i(92679),S=i(85770),f=i(72800),T=i(11740),y=i(59136),A=i(26768),D=i(30635),E=i(59625)
class v{get BossPanel(){return(0,s.Y)(c.I.BossStatus)}constructor(){this.model=null,this.buffPanel=null,this.removePanelDelayIntervalId=-1,this.shakeCD=0,
this._degf_BuffShowHandler=null,this._degf_CallBuffDestory=null,this._degf_CallDestory=null,this._degf_Close=null,this._degf_ShowHandler=null,
this._degf_BuffShowHandler=t=>this.BuffShowHandler(t),this._degf_CallBuffDestory=()=>this.CallBuffDestory(),this._degf_CallDestory=()=>this.CallDestory(),
this._degf_Close=()=>this.DelayCloseHandler(),this._degf_ShowHandler=t=>this.ShowHandler(t),this.model=E.o.Inst_get()}static Inst(){return null==v.inst&&(v.inst=new v),v.inst}
Open(){if(!p.a.isInDoubleBossMap_get())if(this.ClearTimer(),D.Y.Inst().CloseTargetHead(),a.i.Inst.RaiseEvent(C.g.OnBloodBarOpen,null,5),(0,s.qJ)(c.I.BossStatus))(0,
s.Y)(c.I.BossStatus).SetData()
else{(new h.v).layerType=_.F.MiracleUIEffect,(0,s.Yp)(c.I.BossStatus)}}TestDamageBar(){this.BossPanel.TestDamageBar()}ClearData(){null!=this.BossPanel&&this.BossPanel.Clear()}
CallDestory(){UIResMgr.DestroyUIObj(this.BossPanel),this.BossPanel=null}closeByBossId(t){null!=this.model.objId&&t.Equal(this.model.objId)&&this.DelayClose()}ClearTimer(){
null!=this.removePanelDelayIntervalId&&(r.C.Inst_get().ClearInterval(this.removePanelDelayIntervalId),this.removePanelDelayIntervalId=null)}DelayClose(){
r.C.Inst_get().ClearInterval(this.removePanelDelayIntervalId),this.removePanelDelayIntervalId=r.C.Inst_get().SetInterval(this._degf_Close,1e3,1)}DelayCloseHandler(){let t=null
null!=this.model.objId&&(t=l.Y.Inst.getMonsterById(this.model.objId)),null!=t&&!t.isdead&&t.isBoss()||this.Close()}Close(){
p.a.isInAllianceBossMap_get()||null!=this.BossPanel&&(E.o.Inst_get().isBossHpBarShow=!1,a.i.Inst.RaiseEvent(C.g.BossHpBarOpenOrClose),
a.i.Inst.RaiseEvent(C.g.OnBloodBarClose,null,5),(0,s.sR)(n.o.BossStatus),this.CloseBuffPanel())}isShow(){return null!=this.BossPanel&&this.BossPanel.isShow_get()}ForceClose(){
if(null!=this.BossPanel){if(y.c.ins.boss_alive)return
this.ClearTimer(),E.o.Inst_get().isBossHpBarShow=!1,a.i.Inst.RaiseEvent(C.g.BossHpBarOpenOrClose),a.i.Inst.RaiseEvent(C.g.OnBloodBarClose,null,5),
d.N.inst.ClosePanel(this.BossPanel),this.CloseBuffPanel()}}ResetPanel(){d.N.inst.ClosePanel(this.BossPanel),d.N.inst.ClosePanel(this.buffPanel),
r.C.Inst_get().ClearInterval(this.removePanelDelayIntervalId)}ShowHandler(t){}OpenBuffPanel(){const t=new h.v
t.positionType=u.$.eCustom
const e=o.t.GetUIHeight()
t.pos=new g.F(52,e/2-100).Clone(),t.layerType=_.F.NpcTalkUI,(0,s.Yp)(c.I.BossBuffPanel)}CloseBuffPanel(){(0,s.sR)(c.I.BossBuffPanel)}CallBuffDestory(){}BuffShowHandler(t){}
TriggerShakeBossHeadUI(t){if(null==this.BossPanel)return
if(m.GF.Timer_get()<this.shakeCD)return
const e=t.bloodBlockArr[0],i=t.bloodBlockArr[1]
t.bloodBlockArr[2]
I.p.RandomMinMax(1,1e4)<=e&&(this.BossPanel.PlayEffect(),this.shakeCD=m.GF.Timer_get()+i/1e3)}UpdateHpBar(t){a.i.Inst.RaiseEvent(C.g.BossHpBarUpdata),
null!=this.BossPanel&&null!=t&&null!=E.o.Inst_get().info&&E.o.Inst_get().info.id.Equal(t.id)&&this.BossPanel.BossHpUpdate(t)}UpdateDamageBar(t){let e=(0,s.Y)(n.o.BossStatus)
if(null==e)return
S.a.Inst_get().curCopyType==f.S.SpringCattle?null!=E.o.Inst_get().info&&e.UpdateDamageBar(t):A.$.GetInst().IsInRolandDefenseMap()&&null!=E.o.Inst_get().info&&e.UpdateDamageBar(t)}
GetDamageStageList(){
return S.a.Inst_get().curCopyType==f.S.SpringCattle?RySpringFestivalControl.Inst_get().GetDamageBoxList():A.$.GetInst().IsInRolandDefenseMap()?RolandDefenseCfgMgr.GetInst().GetDamageStageList():void 0
}IsShowDamageBarBottomPanel(){return S.a.Inst_get().curCopyType!=f.S.SpringCattle}GetInitDamage(){
return A.$.GetInst().IsInRolandDefenseMap()&&A.$.GetInst().BossAllDamage&&(E.o.Inst_get().bossDamage=A.$.GetInst().BossAllDamage.damage.ToNum()),E.o.Inst_get().bossDamage||0}
GetDamageRate(){return S.a.Inst_get().curCopyType==f.S.SpringCattle?E.o.Inst_get().info?E.o.Inst_get().info.MaxHp_get()/1e8:1:(A.$.GetInst().IsInRolandDefenseMap(),1)}
GetDamageMax(){return S.a.Inst_get().curCopyType==f.S.SpringCattle?1e8:A.$.GetInst().IsInRolandDefenseMap()?RolandDefenseCfgMgr.GetInst().GetDamageStageList().LastItem():1}
ShowDamageBar(){return S.a.Inst_get().curCopyType==f.S.SpringCattle||!!A.$.GetInst().IsInRolandDefenseMap()}GetBoxCount(t){if(S.a.Inst_get().curCopyType==f.S.SpringCattle){
const[e,i]=RySpringFestivalControl.Inst_get().GetDamageBoxList()
t||(t=T.K.Inst_get().SpringCattleCopyStage_get())
let s=0
for(let e=0;e<=t-1;e++)s+=i[e]
return s}return 0}GetBoxPos(){if(null!=this.BossPanel)return null!=E.o.Inst_get().info?this.BossPanel.GetBoxPos():void 0}UpdateBoxCount(t){
null!=this.BossPanel&&null!=E.o.Inst_get().info&&this.BossPanel.UpdateBoxInfo(t)}UpdateRDBox(){null!=this.BossPanel&&null!=E.o.Inst_get().info&&this.BossPanel.UpdateRDReWard()}}
v.inst=null},59625:(t,e,i)=>{i.d(e,{o:()=>l})
var s=i(85602),n=i(30627)
class l{constructor(){this.hpcolor=null,this.boss=null,this.info=null,this.objId=null,this.switchBoss=!1,this.isBossHpBarShow=!1,this.bossDamage=0,
this.hpcolor=new s.Z(["COLOR_START","COLOR_MID1","COLOR_MID2","COLOR_MID3","COLOR_END"])}static Inst_get(){return null==l.inst&&(l.inst=new l),l.inst}CheckSetBossEmpty(t){
t==this.boss&&(this.boss=null,this.info=null,n.t.Inst().ForceClose())}InitModel(t,e,i){n.t.Inst().ClearData(),null!=this.objId&&(this.switchBoss=!this.objId.Equal(i)),this.boss=t,
this.info=e,this.objId=i}ResetModel(){this.boss=null,this.info=null,this.objId=null,this.switchBoss=!1,this.isBossHpBarShow=!1}SetBossDamage(t){this.bossDamage=t,
n.t.Inst().UpdateDamageBar(t)}}l.inst=null,l.BAR_LENGTH=250,l.BAR_START_X=0,l.BAR_START_Y=0},42894:(t,e,i)=>{
var s,n,l=i(21370),a=i(6847),o=i(83908),r=i(46282),h=i(86133),d=i(25236),c=i(23833),_=i(98800),u=i(97461),I=i(5924),m=i(76544),g=i(98885),p=i(61911),C=i(5494),S=i(60130),f=i(98130),T=i(84229),y=i(67885),A=i(92984),D=i(42975),E=i(92679),v=i(87923),w=i(75439),R=i(30627),P=i(26768),O=i(69429),L=i(30635),B=i(4880),b=i(59625)
;(0,a.s_)(C.I.BossStatus,r.Z.ui_boss_bosspanel_ry).waitPrefab(y.S.modulePathList).layerSet(l.T.nav).register()(((n=class extends((0,o.pA)(p.f)()){constructor(...t){super(...t),
this.bossRes=null,this.model=null,this.bossModel=null,this.m_isTimeBloodBoss=!1,this.m_isUpdateAllianceBoss=!1,this.m_maxHp=0,this.m_bloodNum=0,this.m_allianceBossTimeId=0,
this.m_curAllianceBossHp=0,this.closeIntervalId=-1,this.m_vo=null,this.showDamageBar=!1,this.isout=!1,this._degf_ClickBuffItem=null,this._degf_Close=null,
this._degf_OnBuffClick=null,this._degf_OnBuffItemClick=null,this._degf_OnBuffRefreshFun=null,this._degf_UpdateAllianceBossBlood=null,this._degf_UpdateBuffList=null,
this.funSelectEnd=null,this.m_timerId=null,this.tempCur=null,this.delayExecutor=null,this.delayTimeMs=null,this.cachBoxCount=null}_initBinder(){super._initBinder(),
this._degf_ClickBuffItem=t=>this.ClickBuffItem(t),this._degf_Close=()=>this.Close(),this._degf_OnBuffClick=(t,e)=>this.OnBuffClick(t,e),
this._degf_OnBuffItemClick=(t,e)=>this.OnBuffItemClick(t,e),this._degf_OnBuffRefreshFun=t=>this.OnBuffRefreshFun(t),
this._degf_UpdateAllianceBossBlood=()=>this.UpdateAllianceBossBlood(),this._degf_UpdateBuffList=t=>this.UpdateBuffList(t)}InitView(){super.InitView(),
this.ui_mainview_buffcell.node.SetActive(!1),this.model=b.o.Inst_get(),this.buffGrid.SetInitInfo("ui_buff_grid",this._degf_OnBuffRefreshFun,B.I),
this.buffCollider.node.SetActive(!1),this.bossModel=T.Q.Inst_get().bossModel,this.m_isTimeBloodBoss=this.isTimeBloodBoss(),this.ui_mainview_buffcell.isBgShow=!0,
this.funSelectEnd=()=>this.SelectEnd()}OnBuffRefreshFun(t){return t[0].getCNode(B.I)}OnAddToScene(){this.showDamageBar=R.t.Inst().ShowDamageBar(),
this.springCattleBox.SetActive(!1),this.SetData(),this.UpdateAnchors(),this.model.isBossHpBarShow=!0,u.i.Inst.RaiseEvent(E.g.BossHpBarOpenOrClose),this.Addlis(),
-1!=this.m_timerId&&I.C.Inst_get().ClearInterval(this.m_timerId),this.showDamageBar||(this.m_timerId=I.C.Inst_get().SetInterval(this.CreateDelegate(this.QueryBossHP),1e3,-1))}
QueryBossHP(){null!=L.Y.Inst().targetHeadPanel&&_.Y.Inst.CM_QueryTargetHPRq(this.model.objId)}UpdateDamageBar(t){
this.damageBarWidget.Refresh(this.damageBarWidget.DamageVo.curHp,t),this.SetDamageValue(t,this.damageBarWidget.GetCurrentBarMaxDamage())}UpdateAnchors(){
S.O.SetAnchorPos(this.anchor.node.transform,null,!1,2,!1)}SetData(){if(A.j.Inst_get().model.bossId_set(this.model.objId),
null==this.model.boss||null==this.model.boss.Info_get())return
this.bossRes=this.model.boss.Cfg_get()
const t=c.a.inst.GetMonNameColor(this.bossRes)
let e=g.M.DealRichTextOutline(this.bossRes.name)
this.boss_name.textSet(`${t}${e}[-]`),v.l.DealRyMonIcon(this.bossRes.headResources,this.head,this.headRy)
let i=this.bossRes.level
null!=this.model.boss&&(i=this.model.boss.Info_get().level),e=g.M.DealRichTextOutline(i+(0,h.T)("级")),this.boss_level.textSet(t+e+"[-]"),
this.boss_level.node.SetLocalPositionXYZ(this.boss_name.node.position.x+this.boss_name.textWidth+6,this.boss_level.node.position.y,0),this.UpdateGoldWarAngerLab(),
this.cursePoint.node.SetActive(!1)
const s=_.Y.Inst.getBossById(this.model.objId)
if(null==s)return
let n=this.bossRes.hpNum
const l=s.Info_get().MaxHp_get()
0==this.bossRes.hpNum&&(n=1),this.m_bloodNum=n
let a=s.Info_get().CurrentHp_get()
if(this.m_isTimeBloodBoss){const t=this.bossModel.GetBloodPercent()
this.bossModel.frontPercent=t,a=t*s.Info_get().MaxHp_get(),this.m_curAllianceBossHp=a,this.m_maxHp=l}if(this.showDamageBar){
const t=R.t.Inst().GetInitDamage(),e=R.t.Inst().GetDamageMax()
this.damageBarWidget.SetActive(!0),this.hpBar.SetActive(!1),this.damageBarWidget.Init(t,e),this.SetDamageValue(t,this.damageBarWidget.GetCurrentBarMaxDamage()),
P.$.GetInst().IsInRolandDefenseMap()?this.UpdateRDReWard():this.UpdateBoxInfo(R.t.Inst().GetBoxCount(null)),
R.t.Inst().IsShowDamageBarBottomPanel()?(this.damageBarWidget.bottomPanel.SetActive(!0),
this.damageBarWidget.barNumLabel.SetActive(!0)):(this.damageBarWidget.bottomPanel.SetActive(!1),this.damageBarWidget.barNumLabel.SetActive(!1))
}else this.damageBarWidget.SetActive(!1),this.hpBar.SetActive(!0),this.hpBar.Init(a,l,n),this.SetHpPercent(a,l)
0==s.Info_get().CurrentHp_get()&&(I.C.Inst_get().ClearInterval(this.closeIntervalId),this.closeIntervalId=I.C.Inst_get().SetInterval(this._degf_Close,1e3,1)),
1==this.bossRes.isChosen&&this.OnSelect(),this.isout||this.OnUITweenStateChanged(!1,!0)}UpdateGoldWarAngerLab(){this.angerLab.node.SetActive(!1)}SetHpPercent(t,e){
null==this.tempCur&&(this.tempCur=f.GF.INT32_MAX_VALUE_get()),this.tempCur<t&&(0,d.S)(t.toString()),this.tempCur=t,this.hpPercentLabel.textSet(this.getHpPercentStr(t,e))}
SetDamageValue(t,e){const i=R.t.Inst().GetDamageRate()
t*=i,e*=i,t=v.l.GetRuleDecimalVal(t,2),e=v.l.GetRuleDecimalVal(e,2),this.hpPercentLabel.textSet(`${t}/${e}`)}getHpPercentStr(t,e){if(e==t)return"100%"
return`${(t/e*100).toFixed(2)}%`}isTimeBloodBoss(){return!1}Close(){R.t.Inst().Close()}Addlis(){this.AddClickEvent(this.buffCollider,this._degf_OnBuffClick),
this.AddClickEvent(this.clickObj,this.CreateDelegate(this.ClickHandler)),this.m_isUpdateAllianceBoss=!1,
null!=this.model.boss&&null!=this.model.boss.Info_get()&&this.isTimeBloodBoss()&&(this.m_isUpdateAllianceBoss=!0,
this.m_allianceBossTimeId>0&&I.C.Inst_get().ClearInterval(this.m_allianceBossTimeId),this.m_allianceBossTimeId=I.C.Inst_get().SetInterval(this._degf_UpdateAllianceBossBlood,1e3),
this.UpdateAllianceBossBlood()),A.j.Inst_get().model.AddEventHandler(D.E.UPDATE_BUFF_VIEW,this._degf_UpdateBuffList),
u.i.Inst.AddEventHandler(E.g.CLICK_ARENABUFF,this._degf_ClickBuffItem),this.m_handlerMgr.AddEventMgr(E.g.UITweenStateChanged,this.CreateDelegate(this.OnUITweenStateChanged)),
this.m_handlerMgr.AddEventMgr(E.g.FuncOpenViewOpenChange,this.CreateDelegate(this.FuncOpenViewOpenChangeHandle))}ClickHandler(t){
O.v.ins&&null!=this.bossRes&&O.v.ins.IsBoss(this.bossRes.id)&&O.v.ins.GotoBoss()}FuncOpenViewOpenChangeHandle(t){t?(this.anchor.opacity=0,
u.i.Inst.RaiseEvent(E.g.OnBloodBarClose,null,5)):(this.anchor.opacity=255,u.i.Inst.RaiseEvent(E.g.OnBloodBarOpen,null,5))}UpdateAllianceBossBlood(){this.DoChangeBlood(!0)}
DoChangeBlood(t){const e=T.Q.Inst_get().bossModel,i=this.m_maxHp*e.frontPercent,s=e.GetBloodPercent()
e.frontPercent=s,this.m_curAllianceBossHp=this.m_maxHp*s,this.HpDecreaseHandle(i,this.m_curAllianceBossHp,this.m_maxHp)}RemoveLis(){
this.RemoveClickEvent(this.buffCollider,this._degf_OnBuffClick),A.j.Inst_get().model.RemoveEventHandler(D.E.UPDATE_BUFF_VIEW,this._degf_UpdateBuffList),
this.m_allianceBossTimeId>0&&I.C.Inst_get().ClearInterval(this.m_allianceBossTimeId),this.m_allianceBossTimeId=-1,
u.i.Inst.RemoveEventHandler(E.g.CLICK_ARENABUFF,this._degf_ClickBuffItem),this.m_handlerMgr.RemoveEventMgr(E.g.UITweenStateChanged,this.CreateDelegate(this.OnUITweenStateChanged)),
this.RemoveClickEvent(this.clickObj,this.CreateDelegate(this.ClickHandler))}ForcePlayAni(){this.OnUITweenStateChanged(this.isout,!0)}OnUITweenStateChanged(t,e){null==e&&(e=!1),
(this.isout!=t||e)&&(this.isout=t,this.node.visible=!t)}ClickBuffItem(t){this.m_vo=t,this.model.objId.Equal(this.m_vo.owner)&&(this.ui_mainview_buffcell.node.SetActive(!0),
this.ui_mainview_buffcell.SetData(this.m_vo),this.AddFullScreenCollider(this.node,this._degf_OnBuffItemClick,null,!1))}OnBuffItemClick(t,e){this.RemoveFullScreenCollider(null),
this.ui_mainview_buffcell.Clear(),this.ui_mainview_buffcell.node.SetActive(!1),this.m_vo=null}UpdateBuffList(t){const e=A.j.Inst_get().model.GetBossBuffList()
this.buffGrid.data_set(e),null!=this.m_vo&&null==A.j.Inst_get().model.IsHaveBuff(this.m_vo.owner,this.m_vo.buffRes_get().id)&&this.OnBuffItemClick(0,0)}OnBuffClick(t,e){
R.t.Inst().OpenBuffPanel()}BossHpUpdate(t){if(this.m_isUpdateAllianceBoss)return void this.DoChangeBlood(!1)
const e=t
null!=e&&(this.HpDecreaseHandle(e.lastHp,e.CurrentHp_get(),e.MaxHp_get()),0==e.CurrentHp_get()&&(I.C.Inst_get().ClearInterval(this.closeIntervalId),
this.closeIntervalId=I.C.Inst_get().SetInterval(this._degf_Close,1e3,1)))}HpDecreaseHandle(t,e,i){this.showDamageBar||(t-e>0?(this.hpBar.Refresh(t,e),
this.SetHpPercent(e,i)):t-e<0&&this.SetData())}PlayEffect(){}OnSelect(){this.pre_eff_objectchoose_001.SetActive(!0),this.pre_eff_objectchoose_002.SetActive(!1),
null==this.delayExecutor&&(this.delayExecutor=new m.p,this.delayTimeMs=w.D.getInstance().GetNumberValue("OBJECT:CHOOSE_SPARK_TIME")),this.delayExecutor.Clear(),
this.delayExecutor.Invoke(this.funSelectEnd,this.delayTimeMs)}SelectEnd(){this.pre_eff_objectchoose_001.SetActive(!1),this.pre_eff_objectchoose_002.SetActive(!0),
this.delayExecutor.Clear()}UpdateRDReWard(){P.$.GetInst().BossAllDamage}UpdateBoxInfo(t){this.cachBoxCount!=t&&(this.cachBoxCount=t,
this.springCattleBox.active||this.springCattleBox.SetActive(!0),this.boxCount.textSet(`x${t}`))}GetBoxPos(){return this.springCattleBox.getPosition()}Clear(){this.hpBar.Clear(),
this.buffGrid.Clear(),this.ui_mainview_buffcell.Clear(),this.RemoveLis(),this.model.ResetModel(),this.m_vo=null,this.isout=!1,I.C.Inst_get().ClearInterval(this.closeIntervalId),
this.closeIntervalId=-1,I.C.Inst_get().ClearInterval(this.m_timerId),this.m_timerId=-1,super.Clear()}Destroy(){this.Clear(),this.hpBar.Destroy(),this.buffGrid.destroy(),
this.pre_eff_objectchoose_001.SetActive(!1),this.pre_eff_objectchoose_002.SetActive(!1),null!=this.delayExecutor&&this.delayExecutor.Clear()}}).isInited=!1,s=n))},40207:(t,e,i)=>{
var s,n,l=i(18998),a=i(83908),o=i(5924),r=i(93877),h=i(8889),d=i(72005),c=i(85602),_=i(88653),u=i(52212),I=i(30627)
class m{constructor(){this.curHpBar=0,this.curHp=0,this.curPercent=0,this.curBarMaxHp=0,this.tempHpBar=0,this.tempHp=0,this.tempPercent=0,this.offset=0,this.tempStartHp=0,
this.damageStageList=null}SetData(t,e,i){this.curHp=t,this.tempHp=e,this.tempStartHp=e,this.offset=i,[this.tempHpBar,this.tempPercent]=this.GetBarIndex(e),
[this.curHpBar,this.curPercent,this.curBarMaxHp]=this.GetBarIndex(t)}UpdateVO(t){this.tempHp=this.tempStartHp+this.offset*t,
[this.tempHpBar,this.tempPercent]=this.GetBarIndex(this.tempHp)}GetBarIndex(t){this.damageStageList||(this.damageStageList=I.t.Inst().GetDamageStageList())
let e=1
for(let i=1;i<=this.damageStageList.Count();i++)if(e=i,t<=this.damageStageList[i-1]){const e=this.damageStageList[i-1]-(this.damageStageList[i-2]||0)
return[i,1-(this.damageStageList[i-1]-t)/e,this.damageStageList[i-1]]}return[e,1]}}l._decorator.ccclass("RyBossDamageBar")((n=class t extends((0,a.zB)()){constructor(){super(),
this.eachDamage=0,this.m_curDamage=0,this.maxDamage=0,this.maxBarNum=0,this.tempDamage=0,this.isInAnime=!1,this.DamageColor=null,this.fixTimes=5,this.intervalId=-1,this.curTimes=0,
this.DamageVo=null,this._degf_UpdateDamageBar=null,this.topSpt=null,this.tempSpt=null,this.bottomSpt=null,this.topPanel=null,this.tempPanel=null,this.bottomPanel=null,
this.barNumLabel=null,this.DamageColor=new c.Z(["rymainui_sp_0029","rymainui_sp_0061","rymainui_sp_0062","rymainui_sp_0063","rymainui_sp_0064"]),
this._degf_UpdateDamageBar=()=>this.UpdateDamageBar()}InitView(){super.InitView(),this.topSpt=new d.w,this.topSpt.setId(this.FatherId,this.FatherComponentID,1),
this.tempSpt=new d.w,this.tempSpt.setId(this.FatherId,this.FatherComponentID,2),this.bottomSpt=new d.w,this.bottomSpt.setId(this.FatherId,this.FatherComponentID,3),
this.topPanel=new h.$,this.topPanel.setId(this.FatherId,this.FatherComponentID,4),this.tempPanel=new h.$,this.tempPanel.setId(this.FatherId,this.FatherComponentID,5),
this.bottomPanel=new h.$,this.bottomPanel.setId(this.FatherId,this.FatherComponentID,6),this.barNumLabel=new r.Q,this.barNumLabel.setId(this.FatherId,this.FatherComponentID,7)}
Clear(){super.Clear(),this.isInAnime=!1,o.C.Inst_get().ClearInterval(this.intervalId)}Destroy(){super.Destroy(),this.topSpt=null,this.tempSpt=null,this.bottomSpt=null,
this.topPanel=null,this.tempPanel=null,this.bottomPanel=null,this.barNumLabel=null}Init(t,e){this.m_curDamage=t,this.maxDamage=e,this.DamageVo=new m,this.DamageVo.SetData(t,t,0),
this.RefreshUI()}GetCurrentBarPercent(){return this.DamageVo.curPercent}GetCurrentBarMaxDamage(){return this.DamageVo.curBarMaxHp}RefreshUI(){if(this.DamageVo){
const e=this.DamageVo.curHpBar,i=this.DamageVo.curPercent
1==e?this.bottomSpt.SetColor(new _.I(0,0,0,0)):(this.bottomSpt.SetColor(new _.I(1,1,1,1)),this.bottomSpt.spriteNameSet(this.DamageColor[(e-2)%5])),
this.topSpt.SetColor(new _.I(1,1,1,1)),this.topSpt.spriteNameSet(this.DamageColor[(e-1)%5]),this.tempSpt.spriteNameSet(this.DamageColor[(e-1)%5]),
this.topPanel.clipOffsetSet(new u.F(-(1-i)*t.BAR_LENGTH,0)),this.tempPanel.clipOffsetSet(new u.F(-(1-i)*t.BAR_LENGTH,0)),this.barNumLabel.textSet(`X${this.DamageVo.curHpBar}`)}}
Refresh(t,e){if(e>this.maxDamage&&(e=this.maxDamage),!(t>=e)&&this.DamageVo){let i=t
this.isInAnime&&(i=this.DamageVo.tempHp)
const s=(e-i)/this.fixTimes
this.DamageVo.SetData(e,i,s),o.C.Inst_get().ClearInterval(this.intervalId),this.curTimes=0,this.isInAnime=!0,
this.intervalId=o.C.Inst_get().SetInterval(this._degf_UpdateDamageBar,30,this.fixTimes)}}UpdateDamageBar(){this.curTimes+=1,this.DamageVo.UpdateVO(this.curTimes),
this.barNumLabel.textSet(`X${this.DamageVo.tempHpBar}`),1==this.DamageVo.tempHpBar?this.bottomSpt.SetColor(new _.I(0,0,0,0)):(this.bottomSpt.SetColor(new _.I(1,1,1,1)),
this.bottomSpt.spriteNameSet(this.DamageColor[(this.DamageVo.tempHpBar-2)%5])),this.topSpt.SetColor(new _.I(0,0,0,0)),
this.tempSpt.spriteNameSet(this.DamageColor[(this.DamageVo.tempHpBar-1)%5]),this.tempPanel.clipOffsetSet(new u.F(-(1-this.DamageVo.tempPercent)*t.BAR_LENGTH,0)),
this.curTimes==this.fixTimes&&(o.C.Inst_get().ClearInterval(this.intervalId),this.curTimes=0,this.isInAnime=!1,this.DamageVo.SetData(this.DamageVo.curHp,this.DamageVo.curHp,0),
this.RefreshUI())}Test1(){return!0}S_Test(){return!0}},n.BAR_LENGTH=308,s=n))},27964:(t,e,i)=>{i.d(e,{Q:()=>f})
var s,n,l,a,o=i(42292),r=i(71409),h=i(97461),d=i(38935),c=i(85602),_=i(63076),u=i(92679),I=i(68506),m=i(24594),g=i(95165),p=i(92415),C=i(47520)
function S(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let f=(s=(0,r.GH)(p.k.SM_BountyInfo),n=(0,r.GH)(p.k.SM_GainAllBountyReward),a=class t{constructor(){this.RegMsg()}
static GetInst(){return null==t.inst&&(t.inst=new t),t.inst}RegMsg(){}SM_BountyInfoHandler(t){null!=t&&(C.s.GetInst().SetMsg(t),
C.s.GetInst().CanFastFinsh()&&h.i.Inst.RaiseEvent(u.g.GAMEGM_BountyTaskUpdate,null,5))}SM_GainAllBountyRewardHandler(t){if(t){const e=t.andReward,i=new c.Z
if(null!=e&&null!=e.rewards)for(let t=0;t<=e.rewards.Count()-1;t++){const s=_.M.wrapReward(e.rewards[t])
i.Add(s),t+=1}i.Sort(this.SortFunc)
const s=new m.V
s.rewardLis=i,I.Z.Inst_get().Open(s),h.i.Inst.RaiseEvent(u.g.GAMEGM_BountyTaskUpdate,null,5)}}SortFunc(t,e){const[i,s]=[t.Quality_get(),e.Quality_get()]
return i!=s?s-i:t.cfgData_get().sort-e.cfgData_get().sort}ReqBountyTask(){const t=new g._
d.C.Inst.F_SendMsg(t)}},a.inst=null,S(l=a,"GetInst",[o.Vx],Object.getOwnPropertyDescriptor(l,"GetInst"),l),
S(l.prototype,"SM_BountyInfoHandler",[s],Object.getOwnPropertyDescriptor(l.prototype,"SM_BountyInfoHandler"),l.prototype),
S(l.prototype,"SM_GainAllBountyRewardHandler",[n],Object.getOwnPropertyDescriptor(l.prototype,"SM_GainAllBountyRewardHandler"),l.prototype),l)},47520:(t,e,i)=>{i.d(e,{s:()=>u})
var s=i(16812),n=i(37648),l=i(55492),a=i(75439),o=i(56542),r=i(34843),h=i(14792),d=i(62734),c=i(15398),_=i(99535)
class u extends s.k{constructor(){super(),this.curRound=0,this.curLink=0,this.NowTasktype=0,this.copystate=0,this.copyTalkNpcId=0,this.chat_exitdis=3
const t=a.D.getInstance().GetIntValue("MANUAL:ROLE_OPEN")
t>=3&&(this.chat_exitdis=t)}static GetInst(){return null==u.inst&&(u.inst=new u),u.inst}ReSetModel(){this.curRound=0,this.curLink=0,this.NowTasktype=0}SetMsg(t){if(null!=t){
if(this.curRound=t.round,
this.curLink=t.link,this.NowTasktype=t.NowTasktype,this.CanFastFinsh()&&this.curRound<=this.GetMaxRoundorLink(0))return void d.f.Inst.SetState(h.t.GAMEGM_BOUNTYTASK,!0)
d.f.Inst.SetState(h.t.GAMEGM_BOUNTYTASK,!1),_.O.Inst_get().RaiseEvent(c.M.TASK_TOP_CHANGE)}}GetMaxRoundorLink(t){const e=a.D.getInstance().GetIntArray("BOUNTY:BASE_NUM")
return null==e||e.Count()<2?0:0==t?e[t]+r.v.Inst_get().GetFuncHasRecoveredCount(l.x.BOUNTYTASK):e[t]}GetCurRound(){const t=this.GetMaxRoundorLink(0)
return this.curRound>=t?t:this.curRound}GetCurLink(){const t=this.GetMaxRoundorLink(1)
return this.curLink>=t-1?t-1:this.curLink}CanFastFinsh(){
return!!n.P.Inst_get().IsFunctionOpened(l.x.BOUNTYTASK)&&(!!n.P.Inst_get().IsFunctionOpened(l.x.GAME_GM)&&(!!o.S.ins.IsUnlock(8)&&!!n.P.Inst_get().IsFunctionOpened(l.x.BOUNTYTASK_CROSS)))
}}u.inst=null},92984:(t,e,i)=>{i.d(e,{j:()=>d})
var s,n,l,a=i(42292),o=i(16812),r=i(42975),h=i(65029)
let d=(0,a.gK)("GameSys.BuffViewManager")((l=class t extends o.k{constructor(){super(),this.model=null,this.buffMgr=null,this.model=new r.E,this.buffMgr=h.Q.Inst_get(),
this.buffMgr.model=this.model}static Inst_get(){return null==t._mInst&&(t._mInst=new t),t._mInst}hasBuff(t,e,i){return!1}hasBuffByEffectId(t,e,i){return!1}},l._mInst=null,c=n=l,
_="Inst_get",u=[a.Vx],I=Object.getOwnPropertyDescriptor(n,"Inst_get"),m=n,g={},Object.keys(I).forEach((function(t){g[t]=I[t]})),g.enumerable=!!g.enumerable,
g.configurable=!!g.configurable,("value"in g||g.initializer)&&(g.writable=!0),g=u.slice().reverse().reduce((function(t,e){return e(c,_,t)||t}),g),
m&&void 0!==g.initializer&&(g.value=g.initializer?g.initializer.call(m):void 0,g.initializer=void 0),void 0===g.initializer&&(Object.defineProperty(c,_,g),g=null),s=n))||s
var c,_,u,I,m,g},65029:(t,e,i)=>{i.d(e,{Q:()=>V})
var s=i(42292),n=i(71409),l=i(77546),a=i(98800),o=i(97461),r=i(98885),h=i(92679),d=i(92415),c=i(22662),_=i(65550),u=i(86133),I=i(38045),m=i(73206),g=i(98958),p=i(68662),C=i(62370),S=i(66788),f=i(95721),T=i(98130),y=i(85602),A=i(75439),D=i(41864),E=i(92984)
class v{constructor(){this.openEffectHandler=0,this.cycleEffectHanlder=0,this.openEndCycleEffectHandler=0}}class w{constructor(t,e,i){this.owner=null,this.senderID=null,
this.vo=null,this.values=null,this.isFromAdd=!1,this.sortId=w._selfSortId,this.openEndCharacter=null,this._mBuffRes=null,this.changeColorRGB=null,this.effKey=null,
this.lastAiType=0,this.isUnAttckAbleBuff=!1,this.canNotAttackBuff=!1,this.effParam=null,this.endEffKey=null,this.cycleEffKey=null,this.effParam=new v,this.vo=e,this.owner=t,
this.senderID=e.sender,this.values=e.values,this.isFromAdd=i,w._selfSortId+=1,this.effKey=this.buffRes_get().id+(C.o.s_UNDER_CHAR+this.owner.ToNum()),
this.isUnAttckAbleBuff=E.j.Inst_get().model.IsUnAttackedableBuff(this.buffRes_get()),this.canNotAttackBuff=E.j.Inst_get().model.IsSHIELDBuff(this.buffRes_get()),
-1!=this.buffRes_get().duration||E.j.Inst_get().model.IsSpecialDurationBuff(this.buffRes_get().id)||(this.vo.isPerpetual=!0)}GetDes(){if(null!=this.values){
if("WorldLevelExp"==this.buffRes_get().type){const t=r.M.String2Int(this.values[0])
if(t>0&&(this.values[0]=D.h.GetLevelStr(t)),0==r.M.String2Int(this.values[2])){
const t=E.j.Inst_get().model.GetBuffResById(A.D.getInstance().GetIntValue("WORLDLEVEL:WORLDLEVEL_NOBUFF_ID"))
return g.V.Inst().replaceLangParam(t.desc,this.values)}}return g.V.Inst().replaceLangParam(this.buffRes_get().desc,this.values)}return this.buffRes_get().desc}GetCycleEffKey(){
return null==this.cycleEffKey&&this._mBuffRes.cycleEffect>0&&(this.cycleEffKey=(0,I.tw)(this._mBuffRes.cycleEffect)+((0,I.tw)(this.owner.low_get())+(0,
I.tw)(this.owner.high_get()))),this.cycleEffKey}GetEndEffKey(){return null==this.endEffKey&&this._mBuffRes.openEndCycleEffect>0&&(this.endEffKey=(0,
I.tw)(this._mBuffRes.openEndCycleEffect)+((0,I.tw)(this.owner.low_get())+(0,I.tw)(this.owner.high_get()))),this.endEffKey}RemoveEff(t){if(this.buffRes_get().cycleEffect>0){
const e=this.GetCycleEffKey()
t.RemoveByeffId(e)}if(this.buffRes_get().openEndCycleEffect>0){const e=this.GetEndEffKey()
t.RemoveByeffId(e)}}DelEff(t){this.effParam.openEffectHandler>0&&(m.X.Inst.DeleteElement(this.effParam.openEffectHandler),this.effParam.openEffectHandler=0),
this.effParam.cycleEffectHanlder>0&&(m.X.Inst.DeleteElement(this.effParam.cycleEffectHanlder),
null!=t&&t.m_effParamsID.LuaDic_ContainsKey(this.effParam.cycleEffectHanlder)&&t.m_effParamsID.LuaDic_Remove(this.effParam.cycleEffectHanlder),this.effParam.cycleEffectHanlder=0),
this.effParam.openEndCycleEffectHandler>0&&(m.X.Inst.DeleteElement(this.effParam.openEndCycleEffectHandler),this.effParam.openEndCycleEffectHandler=0)}GetColorParam(){}
EqualId(t,e,i,s){return this.vo.originId.Equal(f.o.ZERO)?this.owner.Equal(t)&&this.vo.id==i:this.vo.gid.Equal(s)}Equal(t,e,i,s){return this.vo.gid.Equal(s)}ShowCanNotAttackTips(){
E.j.Inst_get().model.IsSHIELDBuff(this.buffRes_get())&&_.y.inst.ClientSysMessage(105081)}ForceEqual(t,e){return this.owner.Equal(t)&&this.vo.id==e}OriginalEqual(t,e,i){
return this.vo.originId.Equal(f.o.ZERO)?this.owner.Equal(t)&&this.vo.id==i:this.owner.Equal(t)&&this.vo.originId.Equal(e)&&this.vo.id==i}EqualByEffectID(t,e,i){
return this.vo.originId.Equal(f.o.ZERO)?this.owner.Equal(t)&&this._mBuffRes.cycleEffect==i:this.owner.Equal(t)&&this.vo.originId.Equal(e)&&this._mBuffRes.cycleEffect==i}
IsUseBuff(t,e){return this.owner.Equal(t)&&this.vo.id==e}IsUseGroupBuff(t,e){return this.owner.Equal(t)&&this._mBuffRes.coverGroup==e}IsUseTypeBuff(t,e){
const i=E.j.Inst_get().model.GetBuffResById(this.vo.id)
return this.owner.Equal(t)&&i.type==e}remainTime_get(){return T.GF.INT(.001*(this.vo.useEndTime_get()-p.D.serverMSTime_get()-960))+1}showName_get(){
return this.vo.showLayer<=1?this.buffRes_get().name:this.buffRes_get().name+(this.vo.showLayer+(0,u.T)("层"))}buffRes_get(){
if(null==this._mBuffRes&&(this._mBuffRes=E.j.Inst_get().model.GetBuffResById(this.vo.id),null!=this._mBuffRes&&!r.M.IsNullOrEmpty(this._mBuffRes.changeColor))){
const t=r.M.Split(this._mBuffRes.changeColor,C.o.s_UNDER_CHAR)
3!=t.count&&S.Y.LogError((0,u.T)("BUFFRESOURCE 配置有误，请检查changeColor字段 id:")+this.vo.id),this.changeColorRGB=new y.Z
let e=0
for(;e<t.count;)this.changeColorRGB[e]=r.M.String2Float(t[e]),e+=1}return this._mBuffRes}}w._selfSortId=0
var R,P,O,L,B,b,M,G,H,N,k=i(37318)
function U(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let V=(R=(0,n.GH)(d.k.SM_UpdateSkillBuffEvaluate),P=(0,n.GH)(d.k.SM_WorldLevel),O=(0,n.GH)(d.k.SM_OtherBuff),L=(0,
n.GH)(d.k.SM_AddBuff),B=(0,n.GH)(d.k.SM_RemoveBuff),b=(0,n.GH)(d.k.SM_UpdateBuff),M=(0,n.GH)(d.k.SM_Buffs),G=(0,n.GH)(d.k.SM_UpdateBuffValue),N=class t{constructor(){
this.model=null}static Inst_get(){return null==t._Inst&&(t._Inst=new t),t._Inst}RegisterMsg(){}SM_UpdateSkillBuffEvaluateHandler(t){const e=t
null!=e&&(this.model.buffGroup=e.buffGroup,this.model.skillEffectGroup=e.skillEffectGroup,o.i.Inst.RaiseEvent(h.g.HANG_BUFF_UPDATE))}SM_WorldLevelHandler(t){const e=t
null!=e&&(this.model.worldLevel=e.worldLevel,o.i.Inst.RaiseEvent(h.g.WORLDLEVEL_UPDATE))}RoleBuildCompleted(t){}InitHadBuff(t,e){if(null!=t&&t.count>0){this.RegisterMsg()
let i=null,s=0
for(;s<t.count;)i=t[s],null==this.model.IsHaveSameBuff(e,i.originId,i.id,i.gid)&&this.model.AddBuff(new w(e,i,!1)),s+=1}}AddScenePlayerBuff(t,e){if(null!=e&&e.count>0){
E.j.Inst_get().model.RemoveSceneBuffByPId(t),this.RegisterMsg()
let i=0
for(;i<e.count;)this.model.AddBuff(new w(t,e[i],!1)),i+=1}}SM_OtherBuffHandler(t){const e=t.buffVO
this.model.AddBuff(new w(e.owner,e,!0))}SM_AddBuffHandler(t){const e=t,i=new w(e.owner,e.vo,!0)
i.senderID=e.senderID
const s=a.Y.Inst.PrimaryRoleInfo_get().Id_get()
if(!r.M.IsNullOrEmpty(i.buffRes_get().prompt)){let t=!0
null!=this.model.IsHaveBuff(s,e.vo.id)&&1==i.buffRes_get().mustShowPromt&&(t=!1),t&&s.Equal(e.owner)&&i.vo.prompt&&_.y.inst.ClientStrMsg(c.r.BuffTip,i.buffRes_get().prompt)}
const n=this.model.IsHaveBuff(s,e.vo.id)
this.model.AddBuff(i),null==n&&k.m.Inst_get().OpenGetBuffView(i),223!=e.vo.id&&201!=e.vo.id||l.s.Info(`${e.owner.ToString()} buffid ${e.vo.id} 被添加`)}SM_RemoveBuffHandler(t){
const e=t
this.model.RemoveBuff(e.owner,e.originId,e.id,e.gid)}SM_UpdateBuffHandler(t){const e=t
this.model.UpdateBuffVo(e)}SM_BuffsHandler(t){const e=t,i=e.vos
let s=0
for(;s<i.count;)this.model.AddBuff(new w(e.owner,i[s],!1)),s+=1}SM_UpdateBuffValueHandler(t){const e=t
this.model.UpdateBuffValue(e)}},N._Inst=null,U(H=N,"Inst_get",[s.n],Object.getOwnPropertyDescriptor(H,"Inst_get"),H),
U(H.prototype,"SM_UpdateSkillBuffEvaluateHandler",[R],Object.getOwnPropertyDescriptor(H.prototype,"SM_UpdateSkillBuffEvaluateHandler"),H.prototype),
U(H.prototype,"SM_WorldLevelHandler",[P],Object.getOwnPropertyDescriptor(H.prototype,"SM_WorldLevelHandler"),H.prototype),
U(H.prototype,"SM_OtherBuffHandler",[O],Object.getOwnPropertyDescriptor(H.prototype,"SM_OtherBuffHandler"),H.prototype),
U(H.prototype,"SM_AddBuffHandler",[L],Object.getOwnPropertyDescriptor(H.prototype,"SM_AddBuffHandler"),H.prototype),
U(H.prototype,"SM_RemoveBuffHandler",[B],Object.getOwnPropertyDescriptor(H.prototype,"SM_RemoveBuffHandler"),H.prototype),
U(H.prototype,"SM_UpdateBuffHandler",[b],Object.getOwnPropertyDescriptor(H.prototype,"SM_UpdateBuffHandler"),H.prototype),
U(H.prototype,"SM_BuffsHandler",[M],Object.getOwnPropertyDescriptor(H.prototype,"SM_BuffsHandler"),H.prototype),
U(H.prototype,"SM_UpdateBuffValueHandler",[G],Object.getOwnPropertyDescriptor(H.prototype,"SM_UpdateBuffValueHandler"),H.prototype),H)},37318:(t,e,i)=>{i.d(e,{m:()=>C})
var s=i(17409),n=i(49655),l=i(56937),a=i(18202),o=i(31222),r=i(5494),h=i(98789),d=i(75439),c=i(60647),_=i(13487),u=i(9986),I=i(93877),m=i(61911),g=i(92984)
class p extends m.f{constructor(...t){super(...t),this.desc=null,this.confirmBtn=null,this.confirmLbl=null,this.rateTxt=null}InitView(){super.InitView(),
this.desc=this.CreateComponent(I.Q,1),this.confirmBtn=this.CreateComponent(u.W,2),this.confirmLbl=this.CreateComponent(I.Q,3),this.rateTxt=this.CreateComponent(I.Q,4)}
OnAddToScene(){this.AddLis(),this.UpdateView()}UpdateView(){const t=C.Inst_get().buffVo.buffRes_get(),e=g.j.Inst_get().model.GetBuffRate(t.id)/100+"%"
this.rateTxt.node.SetActive(!1),this.desc.textSet(`恭喜您激活永久经验加成Buff,\n打怪基础经验加成提升${e}!`)}Clear(){super.Clear(),this.RemoveLis()}Destroy(){}AddLis(){
this.AddClickEvent(this.confirmBtn,this.CreateDelegate(this.OnCloseView)),this.AddFullScreenCollider(this.node,this.CreateDelegate(this.OnCloseView))}RemoveLis(){
this.RemoveClickEvent(this.confirmBtn,this.CreateDelegate(this.OnCloseView)),this.RemoveFullScreenCollider(this.node,this.CreateDelegate(this.OnCloseView))}OnCloseView(){
C.Inst_get().CloseGetBuffView()}}class C{constructor(){this.showBuffIdLis=null,this.buffVo=null,this.getBuffView=null}static Inst_get(){return null==C.inst&&(C.inst=new C),C.inst}
Open(){const t=new l.v
t.positionType=h.$.eLeft,(0,s.Yp)(n.o.BufferMainView,t)}OpenGetBuffView(t){
if(null==this.showBuffIdLis&&(this.showBuffIdLis=d.D.getInstance().GetIntArray("ONLINE:MEDICINE_BUFFIDS4")),!this.showBuffIdLis.Contains(t.vo.id))return
if(0==c.p.inst.GetClientLogicSetting(_.R.EXP_BUFF_ACTIVE))return
if(c.p.inst.SendClientLogicSetting(_.R.EXP_BUFF_ACTIVE,0,!1),this.buffVo=t,null!=this.getBuffView)return void this.getBuffView.UpdateView()
const e=new l.v
e.isShowMask=!0,o.N.inst.OpenById(r.I.GetBuffView,this.CreateDelegate(this.OnLoadedGetBuffComplete),this.CreateDelegate(this.OnDestroyGetBuffView),e)}OnLoadedGetBuffComplete(t){
return this.getBuffView=new p,this.getBuffView.setPrefabRootId(t),this.getBuffView}CloseGetBuffView(){null!=this.getBuffView&&(o.N.inst.ClosePanel(this.getBuffView),
this.getBuffView=null)}OnDestroyGetBuffView(){a.g.DestroyUIObj(this.getBuffView),this.getBuffView=null}}C.inst=null},13898:(t,e,i)=>{i.d(e,{Q:()=>a})
var s=i(62370),n=i(85602),l=i(17838)
class a{constructor(){this.job=null,this.hpRate=null,this.jobs=null,this.hpRateMax=null,this.needSort=!1,this._degf_SortPlayerOn=null,this._degf_SortMonsterOn=null}
CheckPlayerFix(t){return!(null!=this.jobs&&this.jobs.count>0)||(0==this.jobs[0]||this.jobs.Contains(t.job))}CheckMonsterFix(t){return!0}SortRoleList(t){
t.Sort(this._degf_SortPlayerOn)}SortMonsterList(t){t.Sort(this._degf_SortMonsterOn)}SortPlayerOn(t,e){if(null!=this.hpRateMax){
const i=t.Roleinfo_get().currentHp/t.Roleinfo_get().MaxHp_get(),s=e.Roleinfo_get().currentHp/e.Roleinfo_get().MaxHp_get()
return i>s&&this.hpRateMax||i<s&&!this.hpRateMax?-1:i==s?0:1}return 0}SortMonsterOn(t,e){if(null!=this.hpRateMax){
const i=t.Info_get().currentHp/t.Info_get().maxHp,s=e.Info_get().currentHp/e.Info_get().maxHp
return i>s&&this.hpRateMax||i<s&&!this.hpRateMax?-1:i==s?0:1}return 0}FillData(t){this.job=t.job,null!=this.job&&(this.jobs=s.o.GetIntArr(this.job,"_")),
null!=t.hpRate&&(this.hpRateMax="MAX"==t.hpRate,this.needSort=!0),this._degf_SortPlayerOn=(t,e)=>this.SortPlayerOn(t,e),this._degf_SortMonsterOn=(t,e)=>this.SortMonsterOn(t,e)}
__GetFieldType(t){if("jobs"==t)return[n.Z,"int"]}static CreateFromJson(t){const e=new a
return l.g.FillJsonData(e,t,!0),null!=e.job&&(e.jobs=s.o.GetIntArr(e.job,"_")),null!=t.hpRate&&(e.hpRateMax="MAX"==t.hpRate,e.needSort=!0),
e._degf_SortPlayerOn=(t,i)=>e.SortPlayerOn(t,i),e._degf_SortMonsterOn=(t,i)=>e.SortMonsterOn(t,i),e}}},42975:(t,e,i)=>{i.d(e,{E:()=>V})
var s=i(21892),n=i(93984),l=i(38836),a=i(86133),o=i(38045),r=i(98800),h=i(24873),d=i(93701),c=i(4926),_=i(97461),u=i(50089),I=i(54967),m=i(62370),g=i(45549),p=i(5924),C=i(66788),S=i(55360),f=i(98130),T=i(98885),y=i(85602),A=i(38962),D=i(70850),E=i(92679),v=i(87923),w=i(92473),R=i(75439),P=i(33138),O=i(94409),L=i(78967),B=i(92984),b=i(58087)
class M{constructor(t){this.idList=null,this.colorStr=null,this.changeColorRGB=null,this.idList=new y.Z,this.colorStr=t.buffRes_get().changeColor,
this.changeColorRGB=t.changeColorRGB}static GetInst(t){if(M._pool.Count()>0){const e=M._pool[0]
return e.colorStr=t.buffRes_get().changeColor,e.changeColorRGB=t.changeColorRGB,e.idList.Clear(),M._pool.RemoveAt(0),e}return new M(t)}Clear(){M._pool.Add(this)}
IsContainByForDic(t){let e=0
for(;e<this.idList.count;){if(t.LuaDic_ContainsKey(this.idList[e]))return!0
e+=1}return!1}}M._pool=new y.Z
var G=i(68662)
class H{constructor(){this.showCount=null,this.handlerId=null,this.effId=null,this.endTime=null,this.effIdKey=null,this.BuffEffInfo()}static GetInst(){if(H._pool.Count()>0){
const t=H._pool[0]
return H._pool.RemoveAt(0),t}return new H}Clear(){this.showCount=0,this.handlerId=0,this.effId=0,this.endTime=0,H._pool.Add(this)}isEnd(){
return f.GF.INT(.001*(this.endTime-G.D.serverMSTime_get()-960))+1<0}UpdateEndTime(t){t>this.endTime&&(this.endTime=t),this.showCount+=1}BuffEffInfo(){this.showCount=0,
this.handlerId=0,this.effIdKey=0,this.endTime=0}}H._pool=new y.Z
class N{constructor(){this._degf_OnAction=null,this.bDic=null,this.removeList=null,this._degf_OnAction=()=>this.OnAction(),this.bDic=new A.X,this.removeList=new y.Z,
p.C.Inst_get().SetInterval(this._degf_OnAction,3e3)}OnAction(){this.removeList.Clear()
for(const[t,e]of(0,l.V5)(this.bDic)){const e=this.bDic[t]
e.isEnd()&&(d.a.ins.DeleteEffShowById(e.handlerId),this.removeList.Add(t),e.Clear())}const t=this.removeList.count
let e=0
for(;e<t;)this.bDic.LuaDic_Remove(this.removeList[e]),e+=1}IsHasEff(t){return this.bDic.LuaDic_ContainsKey(t)}AddEffInfo(t,e,i){const s=H.GetInst()
s.effIdKey=t,s.handlerId=e,s.endTime=i.vo.useEndTime_get(),this.bDic.LuaDic_AddOrSetItem(t,s)}UpdateHandlerId(t,e,i){const s=this.bDic[t]
null!=s.handlerId&&s.handlerId>0&&null!=i&&i&&d.a.ins.DeleteEffShowById(s.handlerId),s.handlerId=e}UpdateEndTime(t,e){this.bDic[t].UpdateEndTime(e)}ReduceShowCount(t){
const e=this.bDic[t]
null!=e&&(e.showCount-=1)}RemoveByeffId(t){if(this.IsHasEff(t)){const e=this.bDic[t]
e.showCount-=1,e.showCount<=0&&(d.a.ins.DeleteEffShowById(e.handlerId),this.bDic.LuaDic_Remove(t),e.Clear())}}}N.inst=null
class k{}k.GOD="GOD",k.Teleport="Teleport",k.WE_SHIELD="WE_SHIELD",k.SHEN_DUN_FANG_YU="SHEN_DUN_FANG_YU",k.PVP_BAN="PVP_BAN"
class U{constructor(){this.skillList=null,this.skillBuffDic=null,this.skillList=new y.Z,this.skillBuffDic=new A.X}}class V extends I.g{constructor(){super(),
this.m_effParamsID=null,this.dicTotalList=null,this._mMap=null,this.worldLevel=0,this._isHaveEnterScene=!1,this._bossShowId=null,this.buffGroup=null,this.skillEffectGroup=null,
this.buffAction=null,this.buffActionCls=null,this._buffsColorDic=null,this.m_mergeList=null,this.m_effParams=null,this.hideBufferIdsDic=null,this.isChecked=!1,
this.isPKSpecialSkillConfigInitialized=!1,this.pkSpecialSkillDic=null,this.pkSpecialSkillChangeDic=null,this.effHandlerMgr=null,this.gIdEffDic=null,this.arenaRewardBuffIndex=0,
this.UnAttackedBuffIds=null,this._degf_OnPlayCompleted=null,this._degf_PlayEndEffect=null,this._degf_PlayFrameLoop=null,this._degf_SortList=null,this._degf_UpdateAction=null,
this._degf_EnemySort=null,this._degf_SelfSort=null,this.m_effParamsID=new A.X,this.dicTotalList=new b.y,this.buffAction=new A.X,this.buffActionCls=new A.X,
this._buffsColorDic=new A.X,this.m_mergeList=new A.X,this.m_effParams=new A.X,this.pkSpecialSkillDic=new A.X,this.pkSpecialSkillChangeDic=new A.X,this.effHandlerMgr=new N,
this.gIdEffDic=new A.X,this.UnAttackedBuffIds=new y.Z,this._degf_OnPlayCompleted=t=>this.OnPlayCompleted(t),this._degf_PlayEndEffect=(t,e)=>this.PlayEndEffect(t,e),
this._degf_PlayFrameLoop=(t,e)=>this.PlayFrameLoop(t,e),this._degf_SortList=(t,e)=>this.SortList(t,e),this._degf_UpdateAction=()=>this.UpdateAction(),
this._degf_EnemySort=(t,e)=>this.EnemySort(t,e),this._degf_SelfSort=(t,e)=>this.SelfSort(t,e)}RegiestAction(){}Reset(){if(null!=this.dicTotalList)for(const[t,e]of(0,
l.vy)(this.dicTotalList)){const e=this.dicTotalList.LuaDic_GetItem(t)
if(null!=e){let i=0
for(;i<e.Count();)this.DeleteEffect(e[i]),i+=1
this.ClogBUFFBug2(t)}}this.dicTotalList.LuaDic_Clear(),this._buffsColorDic.LuaDic_Clear(),this._bossShowId=null,this.IsChecked_Set(!1),this.arenaRewardBuffIndex=0}
AddBuffDoAction(t){const e=t.buffRes_get().type
let i=null
if(this.buffAction.LuaDic_ContainsKey(e)){i=this.buffAction.LuaDic_GetItem(e)
const s=i.count-1
for(let e=0;e<=s;e++){const s=i[e]
if(s.IsOwn(t.owner))return s.AddBuff(t),void this.RaiseEvent(V.ADD_BUFF_VIEW,t)}}if(this.buffActionCls.LuaDic_ContainsKey(e)){const s=new(this.buffActionCls.LuaDic_GetItem(e))
s.AddBuff(t),null==i&&(i=new y.Z,this.buffAction.LuaDic_AddOrSetItem(e,i)),i.Add(s)}this.RaiseEvent(V.ADD_BUFF_VIEW,t)}RemoveBuffDoAction(t){const e=t.buffRes_get().type
if(this.buffAction.LuaDic_ContainsKey(e)){const i=this.buffAction.LuaDic_GetItem(e),s=i.count-1
for(let e=0;e<=s;e++){const s=i[e]
if(s.IsOwn(t.owner)){s.RemoveBuff(t)
break}}}this.RaiseEvent(V.REMOVE_BUFF_VIEW,t)}IsHaveCoverBuff(t,e){if(null==e&&(e=!1),t>0){const i=this.GetBuffResById(t)
if(null!=i){const s=i.coverGroup
if(null!=r.Y.Inst.PlayerId_get()){const i=r.Y.Inst.PlayerId_get().ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(i)){let n=0
for(;n<this.dicTotalList.LuaDic_GetItem(i).Count();){const l=this.dicTotalList.LuaDic_GetItem(i)[n]
if(e){if(l.buffRes_get().coverGroup==s)return!0}else if(l.buffRes_get().id!=t&&l.buffRes_get().coverGroup==s)return!0
n+=1}}}}}return!1}GetBuffRate(t){let e=0
const i=this.GetBuffResById(t)
if(null!=i){const t=u.t.decode(i.value,s.J)
v.l.IsEmptyStr(t.rate)||(e=T.M.String2Float(t.rate))}return e}GetExeBuff(t){const e=r.Y.Inst.PlayerId_get()
if(null!=e){const i=e.ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(i)){let e=0
for(;e<this.dicTotalList.LuaDic_GetItem(i).Count();){const s=this.dicTotalList.LuaDic_GetItem(i)[e]
if(s.buffRes_get().coverGroup==t&&!s.vo.isStop)return s
e+=1}}}return null}IsNotUseExpMedicine(){const t=R.D.getInstance().GetIntValue("COPY:EFFICIENCY_LEVEL"),e=r.Y.Inst.PrimaryRoleInfo_get().Level_get()
let i=!1
if(e<t)for(const[t,e]of(0,l.V5)(L.M.Inst_get().expMediceneIdArr)){const t=T.M.String2Int(e)
if(D.g.Inst_get().GetItemNum(t)>0){i=!0
break}}if(e<t&&!i)return!1
if(!this.isChecked){this.isChecked=!0
for(const[t,e]of(0,l.V5)(L.M.Inst_get().coverGroups))if(null==this.GetExeBuff(e))return!0}return!1}IsHaveHigherExpMedicine(){let t=null
for(const[e,i]of(0,l.V5)(L.M.Inst_get().coverGroups))if(t=this.GetExeBuff(i),null!=t&&this.CompareBuffsByCoverGroup(i,t.buffRes_get().id))return!0
return!1}CompareBuffsByCoverGroup(t,e){const i=new y.Z
for(const[s,n]of(0,l.V5)(this.map_get()))n.coverGroup==t&&n.id!=e&&i.Add(n)
for(const[t,s]of(0,l.V5)(i))if(this.GetBuffRate(s.id)>this.GetBuffRate(e)){const t=P.f.Inst().GetItemIdByBuffId(s.id)
if(D.g.Inst_get().GetItemNum(t)>0)return!0}return!1}OnEnterScene(){this._isHaveEnterScene=!0
for(const[t,e]of(0,l.vy)(this.dicTotalList)){const e=this.dicTotalList.LuaDic_GetItem(t)
if(null!=e){let t=e.Count()-1
for(;t>=0;)this.AddEffect(e[t]),t-=1}}this.NoticeUpdate()}AddBuff(t){if(null!=t.owner){const e=t.owner.ToKey()
this.dicTotalList.LuaDic_ContainsKey(e)||this.dicTotalList.LuaDic_AddOrSetItem(e,new y.Z),
1==t.buffRes_get().relationType||9==t.buffRes_get().relationType||10==t.buffRes_get().relationType?(this.AddMergeBuff(t),
this.mergeBuff(this.dicTotalList.LuaDic_GetItem(e),t,t.buffRes_get().relationType)):this.dicTotalList.LuaDic_GetItem(e).Add(t)}this.AddEffect(t),this.NoticeUpdate(),
this.AddBuffDoAction(t),this.JudgeChangeQusetBuffIfo(t.owner,t.buffRes_get().type),_.i.Inst.RaiseEvent(E.g.ADD_BUFF,t),O.p.inst.DealMircaleBuffAddOrDel(t.vo.id),this.OnBuffAdd(t)}
AddMergeBuff(t){const e=t.owner.ToKey()
this.m_mergeList.LuaDic_ContainsKey(e)||this.m_mergeList.LuaDic_AddOrSetItem(e,new y.Z),this.m_mergeList[e].Add(t)}RemoveMergeBuff(t,e,i,s){if(null!=t){const n=t.ToKey()
if(this.m_mergeList.LuaDic_ContainsKey(n)){const l=this.m_mergeList[n]
let a=l.Count()-1
for(;a>=0;){if(l[a].Equal(t,e,i,s)){const o=l[a]
l.RemoveAt(a)
let r=!1
for(let n=0;n<=l.Count()-1;n++)l[n].EqualId(t,e,i,s)&&(r=!0)
return r||this.DeleteEffect(o),0==l.Count()?this.m_mergeList.LuaDic_Remove(n):this.ReduceShowCount(o),o}a-=1}}}return null}ReduceShowCount(t){if(t.buffRes_get().cycleEffect>0){
const e=t.GetCycleEffKey()
this.effHandlerMgr.ReduceShowCount(e)}if(t.buffRes_get().openEndCycleEffect>0){const e=t.GetEndEffKey()
this.effHandlerMgr.ReduceShowCount(e)}}ForceMove(t,e){if(null!=t){const i=t.ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(i)){16==e&&r.Y.Inst.PrimaryRoleInfo_get().m_id.Equal(t)&&C.Y.Log(`buff移除：${e}`)
const s=B.j.Inst_get().model.GetBuffResById(e)
let n=null,l=null
if((9==s.relationType||1==s.relationType)&&this.m_mergeList.LuaDic_ContainsKey(i)){n=this.m_mergeList[i]
let s=n.Count()-1
for(;s>=0;){if(n[s].ForceEqual(t,e)){const t=n[s]
n.RemoveAt(s),l=t,0==n.Count()&&(this.DeleteEffect(t),this.m_mergeList.LuaDic_Remove(i))}s-=1}}n=this.dicTotalList.LuaDic_GetItem(i)
let a=n.Count()-1
for(;a>=0;){if(n[a].ForceEqual(t,e)){const t=n[a]
this.DeleteEffect(t),n.RemoveAt(a),this.RemoveBuffDoAction(t),l=t
break}a-=1}null!=l&&(p.C.Inst_get().SetIntervalForParm(this._degf_PlayEndEffect,60,1,l),this.NoticeUpdate(),this.JudgeChangeQusetBuffIfo(t,l.buffRes_get().type))}}}
IsNeedMerge(t,e,i,s){if(v.l.IsEmptyStr(t.coverGroup)&&v.l.IsEmptyStr(i.coverGroup))return t.id==i.id
if(t.originType!=i.originType)return!1
if(0==t.originType&&0==i.originType){if(t.id==i.id)return!0
if(t.coverGroup==i.coverGroup)return!0}else if(1==t.originType&&1==i.originType&&e==s){if(t.id==i.id)return!0
if(t.coverGroup==i.coverGroup)return!0}return!1}mergeBuff(t,e,i){let s=0,n=null,l=-1
const a=e.buffRes_get(),o=e.owner.ToKey()
let r=null,h=null
if(this.m_mergeList.LuaDic_ContainsKey(o)&&(h=this.m_mergeList[o]),null!=h){let t=h.Count()-1
for(;t>=0;){if(r=h[t],this.IsNeedMerge(r.buffRes_get(),r.owner.ToKey(),a,o))if(10!=i&&(s+=r.vo.layer),null==n)n=r,l=n.vo.useEndTime_get()
else{const t=r.vo.useEndTime_get()
t>l&&(n=r,l=t)}t-=1}}let d=t.Count()-1
for(;d>=0;){const e=t[d]
this.IsNeedMerge(e.buffRes_get(),e.owner.ToKey(),a,o)&&(this.ClogBUFFBug(e.buffRes_get().id,e.owner),this.DeleteColorEffect(e),t.RemoveAt(d),this.RemoveBuffDoAction(e)),d-=1}
null!=n&&(10!=i&&(n.vo.showLayer=s),t.Add(n),this.ClogBUFFBug3(n.buffRes_get().id,n.owner))}JudgeChangeQusetBuffIfo(t,e){const i=r.Y.Inst.getRoleById(t)
null!=i&&e==V.TYPE_SHAPESHIFT&&(i.SetIsChangeEquipModel(),i.isPrimary&&_.i.Inst.RaiseEvent(E.g.CHANGEQUEST_MODEL_UPDATE))}RemoveBuff(t,e,i,s){
if(16==i&&r.Y.Inst.PrimaryRoleInfo_get().m_id.Equal(t)&&C.Y.Log(`buff移除：${i}`),null!=t){const n=t.ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(n)){let l=null
const a=this.dicTotalList.LuaDic_GetItem(n),o=B.j.Inst_get().model.GetBuffResById(i)
if(9==o.relationType||1==o.relationType)l=this.RemoveMergeBuff(t,e,i,s),null!=l&&this.mergeBuff(a,l)
else{let n=a.Count()-1
for(;n>=0;){if(a[n].Equal(t,e,i,s)){const t=a[n]
this.ClogBUFFBug(i,e),this.DeleteEffect(t),a.RemoveAt(n),this.RemoveBuffDoAction(t),l=t
break}n-=1}}0==a.Count()&&this.dicTotalList.LuaDic_Remove(n),null!=l&&(p.C.Inst_get().SetIntervalForParm(this._degf_PlayEndEffect,60,1,l),this.NoticeUpdate(),
this.JudgeChangeQusetBuffIfo(t,l.buffRes_get().type))}O.p.inst.DealMircaleBuffAddOrDel(i)}_.i.Inst.RaiseEvent(E.g.REMOVE_BUFF,i),this.OnBuffRemove(i,t)}RemoveSceneBuffByPId(t){
let e=!1
if(null!=t){const i=t.ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(i)){const t=this.dicTotalList.LuaDic_GetItem(i)
let s=t.Count()-1
for(;s>=0;)this.DeleteEffect(t[s]),this.ClogBUFFBug(t[s].vo.id,i),this.dicTotalList.LuaDic_GetItem(i).RemoveAt(s),e=!0,s-=1}}e&&this.NoticeUpdate()}UpdateRoleBuff(t,e){let i=null
if(null!=t){const s=t.ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(s)){const n=this.dicTotalList.LuaDic_GetItem(s)
let l=n.Count()-1
for(;l>=0;)i=n[l],i.owner.Equal(t)&&(i.isFromAdd=!1,this.AddEffect(i,e)),l-=1}}}PlayEndEffect(t,e){const i=e
if(null!=i.buffRes_get()&&i.buffRes_get().endEffect>0){const t=r.Y.Inst.getCharacterById(i.owner)
if(null!=t){const e=t,[s,n,l]=t.GetPosXYZ()
this.ThisPlayElementXYZ(t,i.buffRes_get().endEffect,e,e,s,n,l,s,n,l)}}}AddEffect(t,e){if(!this._isHaveEnterScene)return
if(null==e&&(e=r.Y.Inst.getCharacterById(t.owner)),null==e)return
const i=t.buffRes_get().changeColor
if(!T.M.IsNullOrEmpty(i)){let s=this._buffsColorDic.LuaDic_GetItem(t.owner.ToKey())
null==s&&(s=new A.X,this._buffsColorDic.LuaDic_AddOrSetItem(t.owner.ToKey(),s))
let n=null
s.LuaDic_ContainsKey(i)?n=s[i]:(n=M.GetInst(t),s.LuaDic_AddOrSetItem(n.colorStr,n)),n.idList.Add(t.buffRes_get().id),this.UpdateBuffColor(t.owner,s,e)}const s=e
let[n,l,a]=e.GetPosXYZ()
this.gIdEffDic.LuaDic_ContainsKey(t.vo.gid)?t.isFromAdd=!1:this.gIdEffDic.LuaDic_AddOrSetItem(t.vo.gid,1)
let o,h=null,[d,c,_]=[0,0,0]
h=null!=t.senderID?r.Y.Inst.getCharacterById(t.senderID):e,null!=h?(o=h,[d,c,_]=h.GetPosXYZ()):(o=s,d=n,c=l,_=a),null!=t.vo.effectX&&(d=t.vo.effectX,_=t.vo.effectY,n=t.vo.effectX,
a=t.vo.effectY),t.buffRes_get().openEffect>0&&t.isFromAdd&&g.x.GetInst().isSkillHideByPrimary(e)&&(t.buffRes_get().openEndCycleEffect>0?(t.openEndCharacter=e,
this.ThisPlayElementXYZ(e,t.buffRes_get().openEffect,o,s,d,c,_,n,l,a,0,this._degf_OnPlayCompleted)):this.ThisPlayElementXYZ(e,t.buffRes_get().openEffect,o,s,d,c,_,n,l,a))
const u=t.buffRes_get().cycleEffect
if(u>0){const i=t.GetCycleEffKey()
if(this.effHandlerMgr.IsHasEff(i)){if(!t.isFromAdd){const t=this.ThisPlayElementXYZ(e,u,o,s,d,c,_,n,l,a)
this.effHandlerMgr.UpdateHandlerId(i,t,!0)}}else{const r=this.ThisPlayElementXYZ(e,u,o,s,d,c,_,n,l,a)
this.effHandlerMgr.AddEffInfo(i,r,t)}this.effHandlerMgr.UpdateEndTime(i,t.vo.useEndTime_get())}if(t.isFromAdd){const e=t.buffRes_get().openSound
v.l.IsEmptyStr(e)}else{const i=t.buffRes_get().openEndCycleEffect
if(i>0){const r=t.GetEndEffKey(),h=this.ThisPlayElementXYZ(e,i,o,s,d,c,_,n,l,a)
this.effHandlerMgr.IsHasEff(r)?this.effHandlerMgr.UpdateHandlerId(r,h):(this.effHandlerMgr.AddEffInfo(r,h,t),this.effHandlerMgr.UpdateEndTime(r,t.vo.useEndTime_get()))}}}
OnPlayCompleted(t){let e=null
for(const[i,s]of(0,l.vy)(this.dicTotalList)){const s=this.dicTotalList.LuaDic_GetItem(i)
if(null!=s){let i=s.Count()-1
for(;i>=0;){if(e=s[i],e.buffRes_get().openEffect==t._uElementCombineID){p.C.Inst_get().SetFrameLoopForParm(this._degf_PlayFrameLoop,1,1,e)
break}i-=1}}}}PlayFrameLoop(t,e){const i=e,s=r.Y.Inst.getRoleById(i.owner)
if(null==s)return
const n=s.GetHandle(),[l,a,o]=s.GetPosXYZ(),h=i.GetEndEffKey(),d=this.ThisPlayElementXYZ(i.openEndCharacter,i.buffRes_get().openEndCycleEffect,n,n,l,a,o,l,a,o)
this.effHandlerMgr.IsHasEff(h)||this.effHandlerMgr.AddEffInfo(h,d,i),this.effHandlerMgr.UpdateEndTime(h,i.vo.useEndTime_get()),i.openEndCharacter=null}DeleteEffect(t){
this.gIdEffDic.LuaDic_ContainsKey(t.vo.gid)&&this.gIdEffDic.LuaDic_Remove(t.vo.gid),t.RemoveEff(this.effHandlerMgr),this.DeleteColorEffect(t)}DeleteColorEffect(t){
if(null!=t.changeColorRGB){const e=this._buffsColorDic.LuaDic_GetItem(t.owner.ToKey())
if(null!=e){const i=t.buffRes_get().changeColor
if(e.LuaDic_ContainsKey(i)){e[i].Clear(),e.LuaDic_Remove(i)}}this.UpdateBuffColor(t.owner,e,null)}}UpdateBuffColorByRole(t,e){if(null==t)return
const i=this._buffsColorDic.LuaDic_GetItem(t.ToKey())
this.UpdateBuffColor(t,i,e)}ForceCancelBuffColor(t){this.hideBufferIdsDic=new b.y
let e=0
for(;e<t.Count();)this.hideBufferIdsDic.LuaDic_AddOrSetItem(t[e],!0),e+=1
const i=r.Y.RoleDic
for(const[t,e]of(0,l.vy)(i)){const e=this._buffsColorDic.LuaDic_GetItem(t)
this.UpdateBuffColor(t,e,i[t])}}ForceResumeBuffColor(){this.hideBufferIdsDic=null
const t=r.Y.RoleDic
for(const[e,i]of(0,l.vy)(t)){const i=this._buffsColorDic.LuaDic_GetItem(e)
this.UpdateBuffColor(e,i,t[e])}}GetTargetBuff(t,e){let i=null
for(const[s,n]of(0,l.V5)(e))if(n.buffRes_get().id==t){i=n
break}return i}GetNotHideBuff(t){for(const[e,i]of(0,l.vy)(t)){if(null==this.hideBufferIdsDic)return i
if(!i.IsContainByForDic(this.hideBufferIdsDic))return i}return null}UpdateBuffColor(t,e,i){if(null==i&&(i=r.Y.Inst.getCharacterById(t)),null!=i)if(null!=e&&e.LuaDic_Count()>0){
let t=1,s=1,n=1
const l=this.GetNotHideBuff(e)
null!=l&&(t=l.changeColorRGB[0],s=l.changeColorRGB[1],n=l.changeColorRGB[2]),i.SetVecColor(t,s,n,!0),i.SetAttachDisplayColor(t,s,n,h.J.WING)}else i.ResetColor(!0),
i.SetAttachDisplayColor(1,1,1,h.J.WING)}UpdateBuffValue(t){if(null!=t){const e=t.owner.ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(e)){const i=this.dicTotalList.LuaDic_GetItem(e)
let s=i.Count()-1
for(;s>=0;){if(i[s].Equal(t.owner,t.originId,t.id,t.gid)){i[s].values=t.values,this.NoticeUpdate()
break}s-=1}}}}UpdateBuffVo(t){if(null!=t.owner){const e=t.owner.ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(e)){const i=this.dicTotalList.LuaDic_GetItem(e)
let s=i.Count()-1
for(;s>=0;){if(i[s].Equal(t.owner,t.senderID,t.vo.id,t.gid)){i[s].vo=t.vo
break}s-=1}}}}map_get(){if(null==this._mMap){const t=S.Y.Inst.GetOrCreateCsv(n.h.eBuffresource)
this._mMap=t.GetCsvMap()}return this._mMap}GetBuffResById(t){if(this.map_get().LuaDic_ContainsKey(t))return this.map_get()[t]
const e=(0,a.T)("无此buffId:")+(t+(0,a.T)(",请检查"))
return C.Y.LogError(e),null}bossId_set(t){this._bossShowId=t,this.NoticeUpdate()}NoticeUpdate(){this._isHaveEnterScene&&p.C.Inst_get().CallLater(this._degf_UpdateAction)}
GetBossBuffList(){const t=new y.Z
if(null!=this._bossShowId&&null!=this._bossShowId){const e=this._bossShowId.ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(e)){const i=this.dicTotalList.LuaDic_GetItem(e)
let s=i.Count()-1
for(;s>=0;)i[s].buffRes_get().isMainUI&&t.Add(i[s]),s-=1}}t.Sort(this._degf_SortList)
let e=t.Count()-1
for(;e>5;)t.RemoveAt(e),e-=1
return t}SortList(t,e){const i=t,s=e
return i.buffRes_get().sort<s.buffRes_get().sort?-1:i.buffRes_get().sort>s.buffRes_get().sort?1:i.sortId>s.sortId?-1:i.sortId<s.sortId?1:0}IsHaveSameBuff(t,e,i,s){if(null!=t){
const n=t.ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(n)){const l=this.dicTotalList.LuaDic_GetItem(n)
let a=l.Count()-1
for(;a>=0;){if(l[a].Equal(t,e,i,s))return l[a]
a-=1}}}return null}IsHaveSameOriginBuff(t,e,i){if(null!=t){const s=t.ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(s)){const n=this.dicTotalList.LuaDic_GetItem(s)
let l=n.Count()-1
for(;l>=0;){if(n[l].OriginalEqual(t,e,i))return n[l]
l-=1}}}return null}IsHaveSameOriginBuffByEffectID(t,e,i){if(null!=t){const s=t.ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(s)){const n=this.dicTotalList.LuaDic_GetItem(s)
let l=n.Count()-1
for(;l>=0;){if(n[l].EqualByEffectID(t,e,i))return n[l]
l-=1}}}return null}getSelfBuffByType(t){let e=null
if(null!=r.Y.Inst.PlayerId_get()){const i=r.Y.Inst.PlayerId_get().ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(i)){let s=this.dicTotalList.LuaDic_GetItem(i).Count()-1
for(;s>=0;){if(e=this.dicTotalList.LuaDic_GetItem(i)[s],null!=e&&null!=e.buffRes_get()&&e.buffRes_get().type==t)return e
s-=1}}}return null}getBuffByType(t,e){let i=null
if(null!=e){const s=e.ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(s)){let e=this.dicTotalList.LuaDic_GetItem(s).Count()-1
for(;e>=0;){if(i=this.dicTotalList.LuaDic_GetItem(s)[e],null!=i&&null!=i.buffRes_get()&&i.buffRes_get().type==t)return i
e-=1}}}return null}UpdateAction(){this.RaiseEvent(V.UPDATE_BUFF_VIEW)}getBuffsByPlayerId(t){const e=new y.Z
if(null!=t){const i=t.ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(i)){const t=this.dicTotalList.LuaDic_GetItem(i)
let s=t.Count()-1
for(;s>=0;)-1!=t[s].buffRes_get().sort&&e.Add(t[s]),s-=1}}return e.Sort(this._degf_SortList),e}CheckHasBuff(t,e){const i=t.ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(i)){const t=this.dicTotalList[i],s=t.Count()-1
for(let i=0;i<=s;i++){if(t[i].vo.id==e)return!0}}}GetMainViewBuffList(t,e){const i=new y.Z
if(null==e&&(e=!1),null!=t){const s=t.ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(s)){const t=this.dicTotalList.LuaDic_GetItem(s)
let n=t.Count()-1
for(;n>=0;)t[n].buffRes_get().isMainUI&&-1!=t[n].buffRes_get().sort&&(e?0==t[n].buffRes_get().importantMark&&i.Add(t[n]):i.Add(t[n])),n-=1}}i.Sort(this._degf_SortList)
let s=i.Count()-1
for(;s>5;)i.RemoveAt(s),s-=1
return i}ThisPlayElementXYZ(t,e,i,s,n,l,a,o,r,h,_,u){if(null==_&&(_=0),null!=t&&t.isShow_get()){let t=new c.E
return t.SetCfg(e),t.source=i,t.target=s,t.effRole=s,t.SetPoint(o,h),d.a.ins.showEffectByData(t)}return 0}IsHaveBuff(t,e){if(null!=t){const i=t.ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(i)){const s=this.dicTotalList.LuaDic_GetItem(i)
let n=s.Count()-1
for(;n>=0;){if(s[n].IsUseBuff(t,e))return s[n]
n-=1}}}return null}IsHaveMedicineExpAddBuff(t){if(null!=t){const e=t.ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(e)){const i=this.dicTotalList.LuaDic_GetItem(e)
let s=i.Count()-1
for(;s>=0;){if(i[s].IsUseTypeBuff(t,"MedicineExpAdd"))return i[s]
s-=1}}}return null}IsHaveShapeShiftBuff(t){if(null!=t){const e=t.ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(e)){const t=this.dicTotalList.LuaDic_GetItem(e)
let i=t.Count()-1
for(;i>=0;){if(t[i].buffRes_get().type==V.TYPE_SHAPESHIFT)return t[i]
i-=1}}}return null}IsHaveGroupBuff(t,e){if(null!=t){const i=t.ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(i)){const s=this.dicTotalList.LuaDic_GetItem(i)
let n=s.Count()-1
for(;n>=0;){if(s[n].IsUseGroupBuff(t,e))return s[n]
n-=1}}}return null}GetGroupBuffValue(t,e){let i=0
if(null!=t){const s=t.ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(s)){const n=this.dicTotalList.LuaDic_GetItem(s)
let l=n.Count()-1
for(;l>=0;)n[l].IsUseGroupBuff(t,e)&&(i+=n[l].vo.evaluationValue.ToKey()),l-=1}}return i}IsSpecialDurationBuff(t){return B.j.Inst_get().model.GetBuffResById(t).type==V.RedNameType}
IsChecked_Set(t){this.isChecked=t}GetImportantBuffs(t){const e=new y.Z,i=t.ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(i)){const t=this.dicTotalList.LuaDic_GetItem(i),s=t.Count()
let n=0
for(;n<s;){const i=t[n]
1==i.buffRes_get().importantMark&&e.Add(i),n+=1}}return e}GetEnemyBuffs(t){const e=new y.Z,i=t.ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(i)){const t=this.dicTotalList.LuaDic_GetItem(i)
t.Sort(this._degf_EnemySort)
const s=t.Count()
let n=0
for(;n<s;){const i=t[n]
if(i.buffRes_get().enemyMark>0&&e.Add(i),n+=1,n>4)break}}return e}GetDebuffs(t){const e=new y.Z,i=t.ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(i)){const t=this.dicTotalList.LuaDic_GetItem(i),s=t.Count()
t.Sort(this._degf_SelfSort)
let n=0
for(;n<s;){const i=t[n]
i.buffRes_get().selfMark>0&&e.Add(i),n+=1}}return e}EnemySort(t,e){const i=t,s=e
return i.buffRes_get().enemyMark>s.buffRes_get().enemyMark?-1:i.buffRes_get().enemyMark<s.buffRes_get().enemyMark?1:0}SelfSort(t,e){const i=t,s=e
return i.buffRes_get().selfMark>s.buffRes_get().selfMark?-1:i.buffRes_get().selfMark<s.buffRes_get().selfMark?1:0}InitPKSpecialSkillConfig(){let t=1
for(;t<=3;){const e=R.D.getInstance().getContent(`PKMODEL:${t}00_SKILL`)
let i=null
null!=e&&(i=e.m_content.stringVal)
let s=0
if(T.M.IsNullOrEmpty(i))C.Y.LogError(`${(0,a.T)("未读取到技能替换字段！表名:")}configvalue${(0,a.T)(" 字段名:")}PKMODEL:${t}00_SKILL`)
else{const e=new U,n=T.M.Split(i,T.M.s_CCD_CHAR)
for(;s<n.count;){const t=T.M.Split(n[s],m.o.s_UNDER_CHAR),i=T.M.String2Int(t[0])
e.skillList.Add(i)
const l=new y.Z
for(let e=1;e<=t.count-1;e++){const i=T.M.String2Int(t[e])
l.Add(i)}e.skillBuffDic.LuaDic_AddOrSetItem(i,l),s+=1}this.pkSpecialSkillDic.LuaDic_AddOrSetItem(t,e)}t+=1}this.isPKSpecialSkillConfigInitialized=!0}GetPKSpecialSkillList(){
const t=f.GF.INT(r.Y.Inst.PrimaryRoleInfo_get().Job_get()/1e3)
return this.isPKSpecialSkillConfigInitialized||this.InitPKSpecialSkillConfig(),this.pkSpecialSkillDic.LuaDic_ContainsKey(t)?this.pkSpecialSkillDic.LuaDic_GetItem(t):null}
GetBuffListBySkillId(t){const e=B.j.Inst_get().model.GetPKSpecialSkillList()
return null!=e&&e.skillBuffDic.LuaDic_ContainsKey(t)?e.skillBuffDic[t]:null}GetPKSpecialSkillChange(t){
return this.isPKSpecialSkillConfigInitialized||this.InitPKSpecialSkillConfig(),
this.pkSpecialSkillChangeDic.LuaDic_ContainsKey(t)?this.pkSpecialSkillChangeDic.LuaDic_GetItem(t):null}IsUnAttackedableBuff(t){
return t.type==k.GOD||(t.type==k.Teleport||!(t.type!=k.PVP_BAN||!w.R.Inst_get().IsInCrossBattle()))}IsSHIELDBuff(t){return t.type==k.WE_SHIELD||t.type==k.SHEN_DUN_FANG_YU}
IsRolandBadge(t){return!!w.R.Inst_get().IsInCrossBattle()&&t.type==k.PVP_BAN}HasRolandBadgeBuff(t){if(null==t)return!1
if(!w.R.Inst_get().IsInCrossBattle())return!1
const e=t.ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(e)){const t=this.dicTotalList.LuaDic_GetItem(e),i=t.Count()-1
for(let e=0;e<=i;e++){const i=t[e]
if(this.IsRolandBadge(i.buffRes_get()))return!0}}return!1}HasCanNotAttackBuff(t,e){if(null==t)return!1
const i=t.ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(i)){const t=this.dicTotalList.LuaDic_GetItem(i),s=t.Count()-1
for(let i=0;i<=s;i++){const s=t[i]
if(s.canNotAttackBuff)return null!=e&&e&&s.ShowCanNotAttackTips(),!0}}return!1}HasUnAttackedableBuff(t){if(null==t)return!1
const e=t.ToKey()
if(this.dicTotalList.LuaDic_ContainsKey(e)){const t=this.dicTotalList.LuaDic_GetItem(e),i=t.Count()-1
for(let e=0;e<=i;e++){if(t[e].isUnAttckAbleBuff)return!0}}return!1}OnBuffAdd(t){if("HIDE"==t.buffRes_get().type){const e=r.Y.Inst.getRoleById(t.owner)
if(e){if(e.SetHide(!0),r.Y.Inst.IsMultiPlayer(t.owner)){let e
e=r.Y.Inst.primaryRole.GetGameId()==t.owner?`Hide 主角 ${t.owner.ToString()}`:`Hide 小弟 ${t.owner.ToString()}`,console.log(e)}}else if(r.Y.Inst.IsMultiPlayer(owner)){
const e=`OnBuffAdd 找不到角色。${t.owner.ToString()}`
console.log(e)}}}OnBuffRemove(t,e){if("HIDE"==B.j.Inst_get().model.GetBuffResById(t).type){const t=r.Y.Inst.getRoleById(e)
if(t){if(t.SetHide(!1),r.Y.Inst.IsMultiPlayer(e)){let t
t=r.Y.Inst.primaryRole.GetGameId()==e?`UnHide 主角 ${e.ToString()}`:`UnHide 小弟 ${e.ToString()}`,console.log(t)}}else if(r.Y.Inst.IsMultiPlayer(e)){
let t=`OnBuffRemove 找不到角色。${e.ToString()}`
const i=r.Y.Inst.primaryRoleList
t=`${t}\n主角信息：${(0,o.tw)(i.count)}\n`
for(let e=0;e<=i.Count()-1;e++){const s=i[e].GetGameId()
t+=`${s.ToString()} l = ${s.low_get()} h = ${s.high_get()}\n`}console.log(t)}}}ClogBUFFBug(t,e){
223!=t&&201!=t||null==r.Y.Inst.GetMultiPlayerInfo(e)||console.trace(`${e.toString()}  buff ${t} 被移除`)}ClogBUFFBug2(t){
null!=r.Y.Inst.PrimaryRoleInfo_get()&&null!=r.Y.Inst.GetMultiPlayerInfo(t)&&C.Y.Log("buff重置",!0)}ClogBUFFBug3(t,e){
223!=t&&201!=t||null==r.Y.Inst.GetMultiPlayerInfo(e)||console.log(`${e.toString()}  buff ${t} 被添加回来`)}}V.TYPE_NIGHT="Night",V.TYPE_SHAPESHIFT="ShapeShift",
V.UPDATE_BUFF_VIEW="update_buff_view",V.ADD_BUFF_VIEW="add_buff_view",V.REMOVE_BUFF_VIEW="remove_buff_view",V.CHECK_REMOVE_BUFF="CHECK_REMOVE_BUFF",V.IsLog=!1,V.RedNameBId=16,
V.RedNameType="RedName"},59214:(t,e,i)=>{i.d(e,{$:()=>d})
var s=i(8786),n=i(50089),l=i(98885),a=i(3158),o=i(38962),r=i(13898)
class h extends a.V{constructor(...t){super(...t),this.buffTargetType=null,this.targetType=null}parse(){
null!=this.targetType&&l.M.Length(this.targetType)>2&&(null!=h.targetTypeDic[this.targetType]?this.buffTargetType=h.targetTypeDic[this.targetType]:(this.buffTargetType=n.t.decode(this.targetType,r.Q),
h.targetTypeDic[this.targetType]=this.buffTargetType)),this.targetType=null}static ClearTempMap(){h.targetTypeDic=null}}h.targetTypeDic=o.X.new()
class d extends s.e{static CreateCSVEx(){return new d}getNewCSVItem(){return new h}_Load(){super._Load(),h.ClearTempMap()}ReLoadFunc(t){super.ReLoadFunc(t),t.parse()}IsSrcType(){
return!1}}},4880:(t,e,i)=>{i.d(e,{I:()=>_})
var s=i(18998),n=i(83908),l=i(97461),a=i(5924),o=i(18202),r=i(83540),h=i(98885),d=i(92679),c=i(92984)
class _ extends((0,n.yk)()){constructor(...t){super(...t),this._intervalId=-1,this._vo=null,this._isAlphaUp=!1,this._degf_ChangeAlpha=null,this._degf_OnInterval=null,
this._degf_clickHandler=null}_initBinder(){super._initBinder(),this._degf_ChangeAlpha=()=>this.ChangeAlpha(),this._degf_OnInterval=()=>this.OnInterval(),
this._degf_clickHandler=(t,e)=>this.clickHandler(t,e),this.getComponent(s.BlockInputEvents)||this.addComponent(s.BlockInputEvents)}InitView(){super.InitView()}SetData(t){
this._vo=t,o.g.SetItemIcon(this.sp,this._vo.buffRes_get().icon,r.b.eBuff,!1)
let e=""
this._vo.vo.showLayer>1&&(e=h.M.IntToString(this._vo.vo.showLayer)),this.countLabel.textSet(e),
(this._vo.buffRes_get().duration>0||c.j.Inst_get().model.IsSpecialDurationBuff(this._vo.buffRes_get().id))&&this._intervalId<0&&(this._intervalId=a.C.Inst_get().SetInterval(this._degf_OnInterval,1e3))
}OnInterval(){this._vo.remainTime_get()<=10&&(a.C.Inst_get().ClearInterval(this._intervalId),this._intervalId=a.C.Inst_get().SetInterval(this._degf_ChangeAlpha,50))}ChangeAlpha(){
let t=this.sp.GetAlpha()
this._isAlphaUp?(t+=.05,t>=1&&(this._isAlphaUp=!1)):(t-=.05,t<=.5&&(this._isAlphaUp=!0)),this.sp.SetAlpha(t)}Clear(){this._vo=null,this.sp&&this.sp.SetAlpha(1),
a.C.Inst_get().ClearInterval(this._intervalId),this._intervalId=-1}clickHandler(t,e){l.i.Inst.RaiseEvent(d.g.CLICK_ARENABUFF,this._vo)}Destroy(){super.destroy(),this._vo=null}}},
18798:(t,e,i)=>{i.d(e,{p:()=>m})
var s,n=i(18998),l=i(83908),a=i(68662),o=i(5924),r=i(18202),h=i(83540),d=i(98130),c=i(98885),_=i(87923)
const{ccclass:u,property:I}=n._decorator
let m=u("BufferItem")(s=class extends((0,l.yk)()){constructor(...t){super(...t),this.remainTime=null,this.timeId=null,this.useEndTime=null}InitView(){this.remainTime=0,
this.timeId=-1}SetData(t){this.ClearLoop()
const e=t,i=e.buffRes_get()
r.g.SetItemIcon(this.icon,i.icon,h.b.eBuff),this.bufferNameLabel.textSet(i.name),this.descLabel.textSet(c.M.Replace(e.GetDes(),"{0}",e.vo.showLayer.toString())),
e.vo.isStop?this.timeLabel.textSet("已暂停"):-1==i.duration?this.timeLabel.textSet("永久"):(this.useEndTime=e.vo.useEndTime_get(),
this.remainTime=d.GF.RoundToInt((this.useEndTime-a.D.serverMSTime_get())/1e3),this.ClearLoop(),this.timeId=o.C.Inst_get().SetInterval(this.CreateDelegate(this._loopTime),100),
this.UpdateTime(this.remainTime)),
1==parseInt(i.relievebyMark)||3==parseInt(i.relievebyMark)?this.typeBg.spriteNameSet("rymainui_sp_0067"):2!=parseInt(i.relievebyMark)&&4!=parseInt(i.relievebyMark)||this.typeBg.spriteNameSet("rymainui_sp_0066"),
i.layer>0?this.layer.textSet(e.vo.showLayer.toString()):this.layer.textSet("")}UpdateTime(t){this.timeLabel.textSet(_.l.GetDateFormatEX(t,!0,!0))}_loopTime(){
this.remainTime=d.GF.RoundToInt((this.useEndTime-a.D.serverMSTime_get())/1e3),this.remainTime<0?this.ClearLoop():this.UpdateTime(this.remainTime)}ClearLoop(){
o.C.Inst_get().ClearInterval(this.timeId),this.timeId=-1}Clear(){this.ClearLoop()}Test1(){return!0}S_Test(){return!0}})||s},75145:(t,e,i)=>{
var s,n=i(6847),l=i(83908),a=i(17409),o=i(49655),r=i(46282),h=i(77546),d=i(98800),c=i(5494),_=i(60130),u=i(85602),I=i(38962),m=i(92984),g=i(42975),p=i(18798);(0,
n.s_)(o.o.BufferMainView,r.Z.ui_buff_mainview).waitPrefab(r.Z.ui_charactertab).register()(s=class t extends((0,l.Ri)()){constructor(...t){super(...t),this._bufferDict=null,
this._commonBufferList=null,this._selectType=1,this._currentSelectRoleInfo=null,this.defaultSelectRoleTab=-1}_initBinder(){super._initBinder(),this._bufferDict=new I.X,
this._commonBufferList=new u.Z}InitView(){this.grid.SetInitInfo("ui_buffer_item",null,p.p),this.m_handlerMgr.AddClickEvent(this.btn_close.node,this.CreateDelegate(this.Close)),
this.m_handlerMgr.AddClickEvent(this.btnRoleBuffer.node,this.CreateDelegate(this.OnClickRoleBtn)),
this.m_handlerMgr.AddClickEvent(this.btnCommonBtn.node,this.CreateDelegate(this.OnClickCommonBtn)),
m.j.Inst_get().model.AddEventHandler(g.E.UPDATE_BUFF_VIEW,this.CreateDelegate(this.UpdateBufferList)),this.ui_charactertab.SetData(c.I.BufferMainView),
this.ui_charactertab.onChanged=this.CreateDelegate(this.OnSelectRole)}OnAddToScene(){const t=d.Y.Inst.primaryRoleInfoList
for(let e=0;e<=t.Count()-1;e++)if(null!=t[e]){let i=m.j.Inst_get().model.IsHaveBuff(t[e].Id_get(),223)
i?h.s.Info(`${t[e].Id_get().ToString()}  buff 223 存在`):h.s.Info(`${t[e].Id_get().ToString()}buff 223 不存在`),i=m.j.Inst_get().model.IsHaveBuff(t[e].Id_get(),201),
i?h.s.Info(`${t[e].Id_get().ToString()}  buff 201 存在`):h.s.Info(`${t[e].Id_get().ToString()}buff 201 不存在`)}this.UpdateBufferData(),
this.defaultSelectRoleTab>=0?(this.OnClickRoleBtn(),this.ui_charactertab.SetCurSelectIdx(this.defaultSelectRoleTab,!0,!0)):(this.OnClickCommonBtn(),
this.ui_charactertab.SetCurSelectIdx(-1,!0,!0))}UpdateBufferList(){this.UpdateBufferData(),this.ShowBuffer()}UpdateBufferData(){const e=d.Y.Inst.primaryRoleInfoList
let i=null,s=null,n=null
this._bufferDict.Clear(),this._commonBufferList.Clear()
const l=new u.Z
for(let a=0;a<=e.Count()-1;a++){i=e[a],s=m.j.Inst_get().model.getBuffsByPlayerId(i.Id_get()),n=new u.Z
let o=null
for(let t=0;t<=s.Count()-1;t++){o=s[t]
const e=o.buffRes_get()
null!=e.icon&&""!=e.icon&&(2==e.showType?(n.Add(o),this.defaultSelectRoleTab<0&&(this.defaultSelectRoleTab=a)):1!=e.showType||l.Contains(e.id)||(l.Add(e.id),
this._commonBufferList.Add(o)))}n.Sort(t.Sort),this._bufferDict.LuaDic_AddOrSetItem(i.Id_get(),n)}this._commonBufferList.Sort(t.Sort)}OnSelectRole(t){this._currentSelectRoleInfo=t,
this.UpdateBufferList()}OnClickRoleBtn(){this.ChangeBtn(!0),this._selectType=1,this.ShowBuffer(),this.ui_charactertab.SetCurSelectIdx(this.defaultSelectRoleTab,!0,!0)}
OnClickCommonBtn(){this.ChangeBtn(!1),this._selectType=2,this.UpdateBufferList(),this.ui_charactertab.SetCurSelectIdx(-1,!0,!0)}ChangeBtn(t){
this.rycommon_normal1.node.SetActive(!t),this.rycommon_select1.node.SetActive(t),this.rycommon_normal2.node.SetActive(t),this.rycommon_select2.node.SetActive(!t),
_.O.makeGoGray(this.ui_charactertab.node,!t),this.ui_charactertab.SetEnabledClick(t)}ShowBuffer(){let t=null
2==this._selectType?t=this._commonBufferList:null!=this._currentSelectRoleInfo&&(t=this._bufferDict.LuaDic_GetItem(this._currentSelectRoleInfo.Id_get())),
null!=t?(t.Count()>0?this.emptyTip.node.SetActive(!1):this.emptyTip.node.SetActive(!0),this.grid.data_set(t)):(this.emptyTip.node.SetActive(!0),this.grid.data_set(null))}
static Sort(t,e){const i=t.buffRes_get(),s=e.buffRes_get()
return i.relievebyMark==s.relievebyMark?i.sort-s.sort:2==parseInt(i.relievebyMark)||4==parseInt(i.relievebyMark)?-1:2==parseInt(s.relievebyMark)||4==parseInt(s.relievebyMark)?1:i.sort-s.sort
}Close(){(0,a.sR)(o.o.BufferMainView)}Clear(){this.defaultSelectRoleTab=-1,m.j.Inst_get().model.RemoveEventHandler(g.E.UPDATE_BUFF_VIEW,this.CreateDelegate(this.UpdateBufferList)),
super.Clear()}})},53905:(t,e,i)=>{i.d(e,{w:()=>l})
var s=i(52726),n=i(85602)
class l{constructor(){this.position=null,this.width=0,this.infoId=null,this.replaceParams=null,this.contents=null,this.layer=s.F.Tip,this.callback=null,this.anchor=0,
this.addContents=null,this.singlelinemode=!1,this.height=void 0,this.replaceParams=new n.Z,this.contents=new n.Z,this.addContents=new n.Z}}},65249:(t,e,i)=>{i.d(e,{o:()=>s})
class s{constructor(){this.isPoint=!0,this.content=null,this.labelWidth=0}}},59756:(t,e,i)=>{i.d(e,{q:()=>r})
var s,n=i(18998),l=i(83908),a=i(79534),o=i(84501)
let r=n._decorator.ccclass("CaptionCommTipsItem")(s=class extends((0,l.pA)(o.X)()){SetData(t){const e=t,i=new a.P
let s=0
e.isPoint?(this.sprite.node.SetActive(!0),i.Set(22,0,0),s=e.labelWidth-22):(this.sprite.node.SetActive(!1),i.Set(0,0,0),s=e.labelWidth),this.tipsDesc.maxWidth=s,
this.tipsDesc.node.transform.SetLocalPosition(i),a.P.Recyle(i),this.tipsDesc.textSet(e.content),this.node.transform.height=this.tipsDesc.textHeight}})||s},870:(t,e,i)=>{i.d(e,{
_:()=>r})
var s,n=i(18998),l=i(83908),a=i(79534),o=i(84501)
let r=n._decorator.ccclass("CaptionCommTipsItem2")(s=class extends((0,l.pA)(o.X)()){SetData(t){const e=t,i=new a.P
let s=0
e.isPoint?(this.sprite.node.SetActive(!0),i.Set(22,0,0),s=e.labelWidth-22):(this.sprite.node.SetActive(!1),i.Set(0,0,0),s=e.labelWidth),
this.tipsDesc.node.transform.SetLocalPosition(i),a.P.Recyle(i),this.tipsDesc.textSet(e.content),this.node.transform.height=this.tipsDesc.textHeight,
e.isPoint?this.node.transform.width=this.tipsDesc.textWidth+22:this.node.transform.width=this.tipsDesc.textWidth}Test1(){return!0}S_Test(){return!0}})||s},60706:(t,e,i)=>{i.d(e,{
M:()=>o})
var s,n=i(18998),l=i(83908),a=i(65772)
let o=n._decorator.ccclass("CaptionCommTipsView")(s=class extends((0,l.Ri)()){constructor(...t){super(...t),this.tipView=null,this.infoVo=null,this._degf_Open=null}InitView(){
this.ui_tip_commtipsview&&(this.tipView=this.ui_tip_commtipsview,this.tipView.SetActive(!1))}SetData(t){this.infoVo=t}UpdateData(){
null!=this.infoVo&&this.tipView.SetData(this.infoVo)}Open(){a.Q.Inst_get().Open(this.infoVo)}AddLis(){}RemoveLis(){}Clear(){this.RemoveLis(),
null!=this.tipView&&this.tipView.Clear()}Destroy(){}})||s},86399:(t,e,i)=>{i.d(e,{Y:()=>Tt})
var s=i(42292),n=i(71409),l=i(98800),a=i(88956),o=i(5430),r=i(36241),h=i(38935),d=i(56937),c=i(31222),_=i(5494),u=i(38962),I=i(33314),m=i(87923),g=i(37648),p=i(55492),C=i(75439),S=i(93504),f=i(92415),T=i(5727),y=i(65550),A=i(16812),D=i(70829),E=i(98885),v=i(85602),w=i(39879),R=i(72835)
class P extends A.k{constructor(...t){super(...t),this.curPlayerId=null,this.curJob=0,this.curBranch=0,this.playerinfo=null,this.resPlayerid=null,this.resJob=0,this.oldJob=0}
static Inst_get(){return null==P.Inst&&(P.Inst=new P),P.Inst}IsGetRes(){return 0!=this.resJob}GetSkillList(t){
const e=R.V.Inst_get().GetJobItemById(t),i=E.M.SubStringWithEnd(e.canLearnSkills,1,e.canLearnSkills.len()-1),s=E.M.Split(i,","),n=new v.Z
for(let t=0;t<=s.Count()-1;t++){const e=D.j.Inst().GetSkillByStrId(s[t])
n.Add(e)}return n}GetDesArr(){const t=w.L.Inst().getItemById("CHANGEJOB:TIPS2").text
return E.M.Split(t,"\n")}Test1(){return!0}S_Test(){return!0}}P.CHANGE_COMPLETE="CHANGE_COMPLETE",P.Inst=null
var O=i(13687),L=i(43133),B=i(99294),b=i(6665),M=i(93877),G=i(72005),H=i(61911),N=i(79534),k=i(21554),U=i(70850),V=i(86770),x=i(53905),F=i(23628),q=i(74045),Y=i(49067),W=i(65772),j=i(55774),Z=i(5968),X=i(85942),K=i(37151)
class $ extends H.f{constructor(...t){super(...t),this.closebtn=null,this.select1=null,this.select2=null,this.des=null,this.biblityicon=null,this.confirmbtn=null,
this.jobicon1=null,this.jobicon2=null,this.jobname1=null,this.jobname2=null,this.grid=null,this.collider1=null,this.collider2=null,this.tip=null,this.curSelectedCfg=null,
this.model=null,this.curBranch=null,this.curJob=null,this.playerInfo=null,this.select1Cfg=null,this.select2Cfg=null,this.curSelected=null}InitView(){super.InitView(),
this.closebtn=this.CreateComponent(G.w,1),this.select1=this.CreateComponent(B.z,2),this.select2=this.CreateComponent(B.z,3),this.des=this.CreateComponent(M.Q,4),
this.biblityicon=this.CreateComponent(G.w,5),this.confirmbtn=this.CreateComponent(L.V,6),this.jobicon1=this.CreateComponent(G.w,7),this.jobicon2=this.CreateComponent(G.w,8),
this.jobname1=this.CreateComponent(M.Q,9),this.jobname2=this.CreateComponent(M.Q,10),this.grid=this.CreateComponent(b.A,11),this.collider1=this.CreateComponent(L.V,12),
this.collider2=this.CreateComponent(L.V,13),this.tip=this.CreateComponent(L.V,14),this.grid.SetInitInfo("ui_ry_skill_common_item",null,j.M)}OnAddToScene(){this.AddLis(),
this.model=P.Inst_get(),this.curBranch=0,this.curJob=P.Inst_get().curJob,this.playerInfo=P.Inst_get().playerinfo
const t=I.Z.GetJobTime(this.playerInfo.Job_get())
this.select1Cfg=K.Q.cfg.GetJobVoByTypeTimesDir(this.curJob,t,1),this.select2Cfg=K.Q.cfg.GetJobVoByTypeTimesDir(this.curJob,t,2),
this.CheckJob(this.select1Cfg)?this.curSelected=1:this.curSelected=2,this.HandleSelectedJob()}HandleSelectedJob(){
1==this.curSelected?this.curSelectedCfg=this.select1Cfg:this.curSelectedCfg=this.select2Cfg,this.UpdatePanel()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.closebtn,this.CreateDelegate(this.OnCloseClick)),this.m_handlerMgr.AddClickEvent(this.collider1,this.CreateDelegate(this.OnSelected1)),
this.m_handlerMgr.AddClickEvent(this.collider2,this.CreateDelegate(this.OnSelected2)),this.m_handlerMgr.AddClickEvent(this.confirmbtn,this.CreateDelegate(this.OnConfirm)),
this.m_handlerMgr.AddClickEvent(this.tip,this.CreateDelegate(this.TipClick))}TipClick(){const t=new x.w
t.position=new N.P(-190,60,0),t.width=450,t.infoId="CHANGEJOB:TIPS",W.Q.Inst_get().Open(t)}OnCloseClick(){c.N.inst.CloseById(_.I.ChangeJobDetailPanel)}UpdatePanel(){
this.biblityicon.spriteNameSet(this.curSelectedCfg.attrFiveImg),this.des.textSet(this.curSelectedCfg.transferDesc),this.jobname1.textSet(this.select1Cfg.name),
this.jobname2.textSet(this.select2Cfg.name),this.select1.SetActive(1==this.curSelected),this.select2.SetActive(2==this.curSelected),
1==this.curSelected?(this.jobicon1.spriteNameSet(this.select1Cfg.jobIcon),
this.jobicon2.spriteNameSet(`${this.select2Cfg.jobIcon}_gray`)):(this.jobicon1.spriteNameSet(`${this.select1Cfg.jobIcon}_gray`),
this.jobicon2.spriteNameSet(this.select2Cfg.jobIcon))
const t=this.model.GetSkillList(this.curSelectedCfg.id)
this.grid.data_set(t)}OnSelected1(){this.CheckJob(this.select1Cfg)?(this.curSelected=1,this.HandleSelectedJob()):y.y.inst.ClientSysMessage(11041903)}OnSelected2(){
this.CheckJob(this.select2Cfg)?(this.curSelected=2,this.HandleSelectedJob()):y.y.inst.ClientSysMessage(11041903)}CheckJob(t){return t.id!=this.playerInfo.job}AreaDesion(){
const t=O.b.Inst.currentMapId_get();-1!=Tt.Inst_get().mapids.IndexOf(t)&&l.Y.Inst.primaryRole.IsInSafeArea()?this.WearEquip():y.y.inst.ClientSysMessage(11041906)}WearEquip(){
if(F.b.BagIsWearForRole(this.playerInfo)){const t=new Y.B
t.infoId="CHANGEJOB:TIPS1",t.tipstype=2,t.maskAlpha=.8,t.confirmText=_T("前往穿戴"),t.cancelText=_T("直接转换职业"),t.confirmHandle=this.CreateDelegate(this.OnWearEquip),
t.cancelHandle=this.CreateDelegate(this.OnConfirmOk),q.t.Inst().Open(t)}else this.OnConfirmOk()}OnConfirm(){this.AreaDesion()}OnWearEquip(){U.g.Inst_get().viewBagType=V.D.equipTab,
k.J.Inst_get().openOrClose(V.D.equipTab),Tt.Inst_get().CloseChangeJobPanel()}OnConfirmOk(){const t=w.L.Inst().getItemById("CHANGEJOB:TIPS3").text,e=new X.N
e.showText=t,e.tipstype=2,e.maskAlpha=.8,e.okhandler=this.CreateDelegate(this.OnConfirmComplete),Z.Z.Inst.OpenView(e)}OnConfirmComplete(){
Tt.Inst_get().ChangeJob(this.model.playerinfo.m_id,this.curSelectedCfg.type,this.curSelectedCfg.branch)}RemoveLis(){}Clear(){this.RemoveLis(),super.Clear()}Destroy(){
super.Destroy(),this.closebtn=null,this.select1=null,this.select2=null,this.des=null,this.biblityicon=null,this.confirmbtn=null,this.jobicon1=null,this.jobicon2=null,
this.jobname1=null,this.jobname2=null,this.grid=null,this.collider1=null,this.collider2=null,this.tip=null}Test1(){return!0}S_Test(){return!0}}var J=i(68662),z=i(5924)
class Q extends H.f{constructor(...t){super(...t),this.cusor=null,this.progresssp=null,this.time=null,this.timeId=null,this.oldtime=null,this.proPos=null}InitView(){
super.InitView(),this.cusor=this.CreateComponent(B.z,1),this.progresssp=this.CreateComponent(G.w,2),this.time=C.D.getInstance().GetIntValue("JOBCHANGE:TIME"),this.timeId=-1}
OnAddToScene(){this.AddLis(),this.ClearTimer(),this.oldtime=J.D.serverMSTime_get(),this.timeId=z.C.Inst_get().SetInterval(this.CreateDelegate(this.UpdateTime),200),
this.proPos=this.progresssp.GetLocalPosition()}UpdateTime(){let t=(J.D.serverMSTime_get()-this.oldtime)/this.time
P.Inst_get().IsGetRes()||t>=.9&&(t=.9),this.progresssp.widthSet(t*Q.WIDTH),this.proPos.x=t*Q.WIDTH-Q.HALF_WIDTH,this.cusor.SetLocalPosition(this.proPos),
t>=1&&(c.N.inst.CloseById(_.I.ChangeJobEffectPanel),Tt.Inst_get().OpenResPanel(),this.ClearTimer())}ClearTimer(){this.timeId>-1&&(z.C.Inst_get().ClearInterval(this.timeId),
this.timeId=-1)}AddLis(){}RemoveLis(){}Clear(){this.RemoveLis(),this.ClearTimer(),super.Clear()}Destroy(){super.Destroy(),this.cusor=null,this.progresssp=null}Test1(){return!0}
S_Test(){return!0}}Q.WIDTH=330,Q.HALF_WIDTH=165
var tt=i(22948),et=i(97461),it=i(13113),st=i(85682),nt=i(61613),lt=i(60130),at=i(52212),ot=i(44758),rt=i(92679),ht=i(28613),dt=i(68637),ct=i(60647),_t=i(13487)
class ut extends H.f{constructor(...t){super(...t),this.closebtn=null,this.ui_charactertab=null,this.leftTrans=null,this.img_bg=null,this.title_obj=null,this.archer_obj=null,
this.sword_obj=null,this.magic_obj=null,this.clickcarea=null,this.clickjarea=null,this.playerid=null,this.job_icon_list=null,this.selectCid=null,this.player=null,
this.needCharacterTab=null}InitView(){super.InitView(),this.closebtn=this.CreateComponent(G.w,1),this.ui_charactertab=this.CreateComponentBinder(tt.s,5),
this.leftTrans=this.CreateComponent(B.z,6),this.img_bg=this.CreateComponent(G.w,7),this.title_obj=this.CreateComponent(B.z,8),this.archer_obj=this.CreateComponent(it.T,9),
this.sword_obj=this.CreateComponent(it.T,10),this.magic_obj=this.CreateComponent(it.T,11),this.clickcarea=this.CreateComponent(L.V,12),this.clickjarea=this.CreateComponent(L.V,13),
this.job_icon_list=new v.Z([this.archer_obj,this.sword_obj,this.magic_obj])}OnAddToScene(){this.AddLis(),this._SetCharacterTabData(!0,_.I.ChangeJobMainPanel),this.selectCid=-1,
this.UpdateAnchors(),this.RegGuide()
0==ct.p.inst.GetClientLogicSetting(_t.R.CHANGE_JOB_CARD)&&(et.i.Inst.RaiseEvent(rt.g.GUIDE_EVENT,ht.e.FIRST_OPEN_CHANGEJOBCARD),
ct.p.inst.SendClientLogicSetting(_t.R.CHANGE_JOB_CARD,1))}RegGuide(){dt.c.Inst.RegGameObject(st.D.UI_CHANGEJOBCARD_CHARACTERAREA,this.clickcarea.node),
dt.c.Inst.RegGameObject(st.D.UI_CHANGEJOBCARD_JOBAREA,this.clickjarea.node)}UnRegGuide(){dt.c.Inst.UnRegGameObject(st.D.UI_CHANGEJOBCARD_CHARACTERAREA),
dt.c.Inst.UnRegGameObject(st.D.UI_CHANGEJOBCARD_JOBAREA)}_OnCharacterTabChange(){this.SelectCharacter(this.ui_charactertab.GetCurPlayerInfo().createIdx,!0)}UpdateAnchors(){
const t=new ot.L(0,0,lt.O.GetUIWidth(),lt.O.GetUIHeight()),e=new at.F(0,-35)
nt.v.AdaptUIToRect(this.leftTrans,nt.v.LAYOUT_LEFT,t,!1,e),nt.v.AdaptUIToRect(this.title_obj,nt.v.LAYOUT_CENTER_TOP,t,!1),ot.L.Recyle(t),at.F.Recycle(e),
this.img_bg.widthSet(lt.O.GetUIWidth())
new v.Z
for(let t=0;t<=this.job_icon_list.Count()-1;t++){const e=398-lt.O.GetUIWidth()/2+(lt.O.GetUIWidth()-273-118-250)/2*t
this.job_icon_list[t].node.transform.SetLocalPositionXYZ(e,-33,0)}const i=nt.v.GetAdaptionWidth(1070,1300)
this.clickjarea.sizeSet(new at.F(i,527)),this.closebtn.node.transform.SetLocalPositionXYZ(lt.O.GetUIWidth()/2-51,lt.O.GetUIHeight()/2-74,0)}_SetCharacterTabData(t,e,i,s){
null!=this.ui_charactertab&&(t?(this.ui_charactertab.node.SetActive(!0),this.ui_charactertab.SetData(e),this.ui_charactertab.SetRedPointId(i),
this.ui_charactertab.onChanged=this.CreateDelegate(this._OnCharacterTabChange)):this.ui_charactertab.node.SetActive(!1))}SelectCharacter(t,e){
this.player=this.ui_charactertab.GetCurPlayerInfo(),
this.selectCid=t,this.needCharacterTab&&(this.ui_charactertab.node.activeSelf()&&this.ui_charactertab.SetCurSelectIdx(this.selectCid,!0,!1),this._OnSelectCharacterBeforeUpdate())}
AddLis(){this.m_handlerMgr.AddClickEvent(this.closebtn,this.CreateDelegate(this.CloseClick)),this.m_handlerMgr.AddClickEvent(this.sword_obj,this.CreateDelegate(this.OnSwordClick)),
this.m_handlerMgr.AddClickEvent(this.magic_obj,this.CreateDelegate(this.OnMagicClick)),this.m_handlerMgr.AddClickEvent(this.archer_obj,this.CreateDelegate(this.OnArcherClick))}
CloseClick(){c.N.inst.CloseById(_.I.ChangeJobMainPanel)}OnSwordClick(){this.CheckSelect()&&Tt.Inst_get().OpenBranchPanel(this.player,1)}OnMagicClick(){
this.CheckSelect()&&Tt.Inst_get().OpenBranchPanel(this.player,2)}OnArcherClick(){this.CheckSelect()&&Tt.Inst_get().OpenBranchPanel(this.player,3)}CheckSelect(){
return this.selectCid>-1||(y.y.inst.ClientSysMessage(11041406),!1)}RemoveLis(){this.UnRegGuide()}Clear(){this.RemoveLis(),super.Clear()}Destroy(){super.Destroy(),
this.closebtn=null,this.ui_charactertab=null,this.leftTrans=null,this.img_bg=null,this.title_obj=null,this.archer_obj=null,this.sword_obj=null,this.magic_obj=null,
this.clickcarea=null,this.clickjarea=null}}ut.GUIDE_ID1=180001,ut.GUIDE_ID2=180002
var It,mt,gt,pt,Ct=i(47786)
class St extends H.f{constructor(...t){super(...t),this.confirmtbn=null,this.job1=null,this.job2=null,this.job3=null,this.title=null,this.lab1=null,this.lab2=null,this.lab3=null,
this.lab4=null,this.lab5=null,this.lab6=null,this.strArr=null,this.labArr=null,this.template=null,this.timeId=null,this.model=null,this.index=null}InitView(){super.InitView(),
this.confirmtbn=this.CreateComponent(L.V,1),this.job1=this.CreateComponent(B.z,2),this.job2=this.CreateComponent(B.z,3),this.job3=this.CreateComponent(B.z,4),
this.title=this.CreateComponent(M.Q,5),this.lab1=this.CreateComponent(M.Q,6),this.lab2=this.CreateComponent(M.Q,7),this.lab3=this.CreateComponent(M.Q,8),
this.lab4=this.CreateComponent(M.Q,9),this.lab5=this.CreateComponent(M.Q,10),this.lab6=this.CreateComponent(M.Q,11),this.labArr=new v.Z,this.labArr.Add(this.lab1),
this.labArr.Add(this.lab2),this.labArr.Add(this.lab3),this.labArr.Add(this.lab4),this.labArr.Add(this.lab6),this.labArr.Add(this.lab5),
this.template=Ct.x.Inst().getItemStrById(11041401),this.timeId=-1}OnAddToScene(){this.AddLis(),this.model=P.Inst_get()
const t=Math.floor(this.model.resJob/1e3)
this.job1.SetActive(1==t),this.job2.SetActive(2==t),this.job3.SetActive(3==t),this.strArr=P.Inst_get().GetDesArr()
const e=K.Q.cfg.GetJobVo(this.model.resJob),i=K.Q.cfg.GetJobVo(this.model.oldJob),s="[8c4f00]{0}[-]",n=E.M.Replace(s,"{0}",i.name),l=E.M.Replace(s,"{0}",e.name),a=m.l.Substitute(this.template,new v.Z([n,l]))
this.title.textSet(a),this.ClearTimerId(),this.timeId=z.C.Inst_get().SetInterval(this.CreateDelegate(this.StartLoop),500),this.index=0}AddLis(){
this.m_handlerMgr.AddClickEvent(this.confirmtbn,this.CreateDelegate(this.OnAddClick))}StartLoop(){this.labArr[this.index].textSet(this.strArr[this.index]),this.index+=1,
this.index>this.strArr.Count()-1&&this.ClearTimerId()}RemoveLis(){}OnAddClick(){c.N.inst.OpenUIByShortCutID(st.D.AddAttrPoint),c.N.inst.CloseById(_.I.ChangeJobResPanel)}
ClearTimerId(){this.timeId>-1&&(z.C.Inst_get().ClearInterval(this.timeId),this.timeId=-1)}Clear(){this.RemoveLis(),this.ClearTimerId(),super.Clear()}Destroy(){super.Destroy(),
this.confirmtbn=null,this.job1=null,this.job2=null,this.job3=null,this.title=null,this.lab1=null,this.lab2=null,this.lab3=null,this.lab4=null,this.lab5=null,this.lab6=null}Test1(){
return!0}S_Test(){return!0}}function ft(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let Tt=(It=(0,n.GH)(f.k.SM_JobChange),mt=(0,n.GH)(f.k.SM_JobChangeDetailInfo),pt=class t{constructor(){
this.model=null,this.changeComplete=!1,this.mapids=null,this.RegisterMsg(),this.model=P.Inst_get(),this.mapids=C.D.getInstance().GetIntArray("JOBCHANGE:MAPID")}static Inst_get(){
return null==t.Inst&&(t.Inst=new t),t.Inst}RegisterMsg(){}SM_JobChangeHandler(t){this.model.resJob=t.job,this.model.resPlayerid=t.playerId,this.OpenWaitingPanel()}ChangeJob(t,e,i){
r._.getInst().endHang(),l.Y.Inst.PrimaryRole_get().StopPathing(),this.model.oldJob=this.model.playerinfo.Job_get()
const s=new S.w
s.baseJob=e,s.playerId=t,s.branch=i,h.C.Inst.F_SendMsg(s),c.N.inst.CloseById(_.I.ChangeJobDetailPanel),c.N.inst.CloseById(_.I.ChangeJobMainPanel)}SM_JobChangeDetailInfoHandler(t){
this.model.changeComplete=!0,T.X.Inst_get().ResetModel()
const e=t.playerDetailInfo,i=l.Y.Inst.primaryRoleInfoList
let s=0
for(let e=0;e<=i.Count()-1;e++)if(i[e].m_id.Equal(t.playerDetailInfo.id)){s=e
break}const n=e.id
let r=l.Y.Inst.GetMultiPlayerInfo(n)
null==r&&(r=new a.r),r.Fashions_set(new u.X),l.Y.Inst._PreSetPlayerInfo(r,!1),r.ParseSingleDetailMsg(t.playerDetailInfo,s),l.Y.Inst._AddToMultiPrimaryInfoList(r),
l.Y.RoleInfoDic.LuaDic_AddOrSetItem(r.Id_get(),r),o.Y.UpdateModelDataByFacadeSetting(r,e.equipStorage.voSetting),r=l.Y.Inst.GetMultiPlayerInfo(n),
r.CopyDataFromPrimaryInfo(l.Y.Inst.m_primaryRoleInfo),l.Y.Inst.AddPrimaryRole(),l.Y.Inst.AddMultiPrimaryRole(),this.model.RaiseEvent(P.CHANGE_COMPLETE)}OpenPanel(){
if(!g.P.Inst_get().IsFunctionOpened(p.x.CHANGE_JOB))return void m.l.SetFunctionTip(p.x.CHANGE_JOB)
c.N.inst.CloseById(_.I.eBagPanel)
const t=new d.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!1,t.maskAlpha=.8,t.viewClass=ut,c.N.inst.OpenById(_.I.ChangeJobMainPanel,null,null,t)}OpenBranchPanel(t,e){
if(I.Z.GetJobTime(t.Job_get())<1)return void y.y.inst.ClientSysMessage(11041904)
if(this.model.playerinfo=t,this.model.curJob=e,!g.P.Inst_get().IsFunctionOpened(p.x.CHANGE_JOB))return void m.l.SetFunctionTip(p.x.CHANGE_JOB)
const i=new d.v
i.isShowMask=!0,i.viewClass=$,i.maskAlpha=.8,c.N.inst.OpenById(_.I.ChangeJobDetailPanel,null,null,i)}OpenWaitingPanel(){const t=new d.v
t.isShowMask=!0,t.viewClass=Q,t.maskAlpha=.8,c.N.inst.OpenById(_.I.ChangeJobEffectPanel,null,null,t)}OpenResPanel(){const t=new d.v
t.isShowMask=!0,t.viewClass=St,t.maskAlpha=.8,c.N.inst.OpenById(_.I.ChangeJobResPanel,null,null,t)}hehe(){this.model.resJob=1011,this.model.oldJob=1012,this.OpenResPanel()}
CloseChangeJobPanel(){c.N.inst.CloseById(_.I.ChangeJobMainPanel),c.N.inst.CloseById(_.I.ChangeJobDetailPanel)}Test1(){return!0}S_Test(){return!0}},pt.Inst=null,
ft(gt=pt,"Inst_get",[s.n],Object.getOwnPropertyDescriptor(gt,"Inst_get"),gt),
ft(gt.prototype,"SM_JobChangeHandler",[It],Object.getOwnPropertyDescriptor(gt.prototype,"SM_JobChangeHandler"),gt.prototype),
ft(gt.prototype,"SM_JobChangeDetailInfoHandler",[mt],Object.getOwnPropertyDescriptor(gt.prototype,"SM_JobChangeDetailInfoHandler"),gt.prototype),gt)},56131:(t,e,i)=>{i.d(e,{F:()=>T
})
var s=i(17409),n=i(98800),l=i(68662),a=i(38935),o=i(56937),r=i(31222),h=i(5494),d=i(14772),c=i(21554),_=i(70850),u=i(74045),I=i(49067),m=i(75439),g=i(6322),p=i(74457),C=i(65550),S=i(39043),f=i(13994)
class T{constructor(){this.view=null,this._degf_CallDestory=null,this._degf_ShowHandler=null,this._degf_confirmChangeHdl=null,this._degf_CallDestory=()=>this.CallDestory(),
this._degf_ShowHandler=t=>this.ShowHandler(t),this._degf_confirmChangeHdl=t=>this.confirmChangeHdl(t)}static Inst_get(){return null==T._Inst&&(T._Inst=new T),T._Inst}
OpenChangeNameView(){const t=new o.v
t.isShowMask=!0,t.isDefaultUITween=!0,(0,s.Yp)(h.I.eChangeNamePanel,t)}ShowHandler(t){return this.view}CallDestory(){}ClosePanel(){r.N.inst.CloseById(h.I.eChangeNamePanel)}
PreCheckChange(){const t=f.I.inst.type,e=l.D.serverMSTime_get()
if(1==t){const t=m.D.getInstance().GetIntValue("RENAME:PLAYER_CD")
if(e-f.I.inst.lastReRoleTime<60*t*60*1e3)return C.y.inst.ClientSysMessage(438001),!1}if(2==t){
if(!n.Y.Inst.PrimaryRoleInfo_get().isHaveAlliance_get())return C.y.inst.ClientSysMessage(114058),!1
const t=n.Y.Inst.PrimaryRoleInfo_get().AllianceJob_get()
if(t!=d.o.Leader&&t!=d.o.ViceLeader)return C.y.inst.ClientSysMessage(438003),!1}return!0}HandleChangeName(){const t=f.I.inst
let e=0
if(1==t.type?e=m.D.getInstance().GetIntValue("PLAYER:RENAME_ITEM"):2==t.type&&(e=m.D.getInstance().GetIntValue("ASURAM:RENAME_ITEM")),
_.g.Inst_get().GetItemNum(e)<1)c.J.Inst_get().OpenTipViewById(e)
else{let e="",i=""
1==t.type?(e="RENAME:PLAYER_NOTICE",i=m.D.getInstance().GetStringValue("RENAME:PLAYER_CD")):2==t.type&&(e="RENAME:ASURAM_NOTICE",
i=m.D.getInstance().GetStringValue("RENAME:ASURAM_CD"))
if(S.V.Inst_get().GetData(S.V.Inst_get().GetRolePrefix()+e))this.confirmChangeHdl(null)
else{const s=new I.B
s.infoId=e,s.replaceParams.Add(i),s.replaceParams.Add(t.name),s.confirmHandle=this._degf_confirmChangeHdl,u.t.Inst().Open(s)}}}SendChangeName(t){let e=null
1==f.I.inst.type?(e=new p.p,e.newName=f.I.inst.name,e.second=t):2==f.I.inst.type&&(e=new g.P,e.newName=f.I.inst.name,e.first=!t),null!=e&&a.C.Inst.F_SendMsg(e)}confirmChangeHdl(t){
this.SendChangeName(!0)}ChangeNameSuccess(){if(1==f.I.inst.type)for(let t=0;t<=n.Y.Inst.primaryRoleInfoList.Count()-1;t++){n.Y.Inst.primaryRoleInfoList[t].Name_set(f.I.inst.name)
}else f.I.inst.type}}T._Inst=null},13994:(t,e,i)=>{i.d(e,{I:()=>n})
var s=i(75439)
class n{static get inst(){return n._inst||(n._inst=new n),n._inst}constructor(){this.type=-1,this.lastReRoleTime=0,this.name="",this.lastReAsuramTime=0,this.cfgCdTime_Role=null,
this.cfgCdTime_Asuram=null,this.cfgItemId_Role=null,this.cfgItemId_Asuram=null,this.cfgCdTime_Role=s.D.getInstance().GetIntValue("RENAME:PLAYER_CD"),
this.cfgCdTime_Asuram=s.D.getInstance().GetIntValue("RENAME:ASURAM_CD"),this.cfgItemId_Role=s.D.getInstance().GetIntValue("PLAYER:RENAME_ITEM"),
this.cfgItemId_Asuram=s.D.getInstance().GetIntValue("ASURAM:RENAME_ITEM")}ResetData(){this.type=-1,this.lastReRoleTime=0,this.name="",this.lastReAsuramTime=0}}n._inst=void 0},
952:(t,e,i)=>{
var s,n=i(6847),l=i(83908),a=i(49655),o=i(46282),r=i(40053),h=i(86133),d=i(97461),c=i(57834),_=i(21554),u=i(70850),I=i(63076),m=i(92679),g=i(75439),p=i(22662),C=i(65550),S=i(56131),f=i(13994)
;(0,n.s_)(a.o.eChangeNamePanel,o.Z.ui_changename_view).waitPrefab(r.Z.BaseItem_ry_basePrefabs).layerTip().register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),
this.model=null,this.itemId=0,this._degf_OnCloseBtnClick=null,this._degf_OnOkBtnClick=null,this._degf_OnBagUpdate=null}_initBinder(){
this._degf_OnCloseBtnClick=(t,e)=>this.OnCloseBtnClick(t,e),this._degf_OnOkBtnClick=(t,e)=>this.OnOkBtnClick(t,e),this._degf_OnBagUpdate=t=>this.OnBagUpdate(t)}InitView(){
super.InitView(),this.addLis(),this.model=f.I.inst,this.inputName.SetInputFilter()}OnAddToScene(){this.InitBaseItem(),this.InitHintLabel(),2==this.model.type||this.model.type}
addLis(){c.i.Get(this.btnClose).RegistonClick(this._degf_OnCloseBtnClick),c.i.Get(this.btnCancel).RegistonClick(this._degf_OnCloseBtnClick),
c.i.Get(this.btnOK).RegistonClick(this._degf_OnOkBtnClick),d.i.Inst.AddEventHandler(m.g.BAG_UPDATE,this._degf_OnBagUpdate)}removeLis(){
d.i.Inst.RemoveEventHandler(m.g.BAG_UPDATE,this._degf_OnBagUpdate)}OnCloseBtnClick(t,e){S.F.Inst_get().ClosePanel()}Destroy(){this.removeLis(),
this.baseItem&&this.baseItem.Destroy()}OnOkBtnClick(t,e){this.CheckName()&&(this.model.name=this.inputName.GetText(),S.F.Inst_get().SendChangeName(!1))}InitBaseItem(){
1==this.model.type?this.itemId=g.D.getInstance().GetIntValue("PLAYER:RENAME_ITEM"):2==this.model.type&&(this.itemId=g.D.getInstance().GetIntValue("ASURAM:RENAME_ITEM"))
const t=new I.M(this.itemId,null)
t.needNum=1,this.baseItem.SetData(t),this.baseItem.node.SetActive(!0)}CheckName(){let t=g.D.getInstance().GetIntValue("PLAYER:RENAME_ITEM")
if(2==this.model.type&&(t=g.D.getInstance().GetIntValue("ASURAM:RENAME_ITEM")),u.g.Inst_get().GetItemNum(t)<1&&_.J.Inst_get().OpenTipViewById(t),1==this.model.type){
const t=this.inputName.GetText()
if(""==t)return C.y.inst.ClientStrMsg(p.r.SystemTipMessage,(0,h.T)("请输入角色名")),!1
const e=this.GetLen(t)
if(e>10||e<2)return C.y.inst.ClientStrMsg(p.r.SystemTipMessage,(0,h.T)("名字长度为2-5个字")),!1}else if(2==this.model.type){const t=this.inputName.GetText()
if(""==t)return C.y.inst.ClientStrMsg(p.r.SystemTipMessage,(0,h.T)("请输入战盟名")),!1
const e=this.GetLen(t)
if(e>12||e<2)return C.y.inst.ClientStrMsg(p.r.SystemTipMessage,(0,h.T)("名字长度为2-6个字")),!1}return!0}InitHintLabel(){1==this.model.type?this.nameLabel.textSet((0,
h.T)("点击输入名字")):2==this.model.type&&this.nameLabel.textSet((0,h.T)("请输入战盟名称"))}OnBagUpdate(t){this.InitBaseItem()}GetLen(t){const e=t.length
let i=0,s=0
for(;s<e;){const e=t.charCodeAt(s)
let n=2
e>0&&e<=127?n=1:e>=192&&e<=223?n=2:e>=224&&e<=239?n=3:e>=240&&e<=247&&(n=4),s+=1,i+=1==n?1:2}return i}})},78592:(t,e,i)=>{i.d(e,{l:()=>ot})
var s=i(42292),n=i(71409),l=i(17409),a=i(38836),o=i(86133),r=i(98800),h=i(97461),d=i(38935),c=i(56937),_=i(18202),u=i(31222),I=i(98885),m=i(85602),g=i(56131),p=i(13994),C=i(92679),S=i(54130),f=i(51965),T=i(74045),y=i(39879),A=i(87923),D=i(2457),E=i(37648),v=i(55492),w=i(92415),R=i(22662),P=i(15831),O=i(9964),L=i(19983),B=i(49892),b=i(75961),M=i(14792),G=i(62734),H=i(97869),N=i(5968),k=i(65550),U=i(85942),V=i(84141),x=i(58158),F=i(3579),q=i(54151)
class Y{}Y.INACTIVE=0,Y.ACTIVE_LIGHT_NOSHOW=1,Y.ACTIVE_LIGHT_SHOW=2,Y.ACTIVE_NOLIGHT_SHOW=3,Y.ACTIVE_NOLIGHT_NOSHOW=4
var W,j,Z,X,K,$,J,z,Q,tt,et,it,st,nt=i(49655),lt=i(50894)
function at(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let ot=(W=(0,n.GH)(w.k.SM_ObtainTitleMessage),j=(0,n.GH)(w.k.SM_TitleIdShow),Z=(0,n.GH)(w.k.SM_LightTitle),X=(0,
n.GH)(w.k.SM_SwitchTitleVO),K=(0,n.GH)(w.k.SM_LoginTitleUpdate),$=(0,n.GH)(w.k.SM_ObtainTitle),J=(0,n.GH)(w.k.SM_TitleOvertimeInfo),z=(0,n.GH)(w.k.SM_TitleNotify),Q=(0,
n.GH)(w.k.SM_TitleGrade),tt=(0,n.GH)(w.k.SM_PlayerRename),et=(0,n.GH)(w.k.SM_AsuramRename),st=class t{get topView(){return this._topView||(this._topView=(0,
l.Y)(nt.o.CharacterTopView)),this._topView}constructor(){this._topView=null,this.model=null,this.topUseDefaultTab=!1,this.CharacterViewDefaultTab=!1,this.curRoleUseDefaultTab=!1,
this.infoUseDefaultTab=!1,this.skillUseDefaultTab=!0,this.fashionUseDefaultTab=!1,this.baseData=null,this.openGodBlessView=!1,this.registerError=null,this._degf_CallDestory=null,
this._degf_ExpireTipCancelHandle=null,this._degf_ExpireTipOkHandle=null,this._degf_ObtainTitleTipOkHandle=null,this._degf_OnSpecialTipConfirm=null,
this._degf_SM_LightTitleHandle=null,this._degf_SM_LoginTitleUpdateHandle=null,this._degf_SM_ObtainTitleHandle=null,this._degf_SM_ObtainTitleMessageHandler=null,
this._degf_SM_SwitchTitleVOHandle=null,this._degf_SM_TitleIdShowHandle=null,this._degf_SM_TitleNotifyHandle=null,this._degf_SM_TitleOvertimeInfoHandle=null,
this._degf_ShowHandler=null,this._degf_UpdateSpecialTip=null,this._degf_SM_TitleGradeHandler=null,this._degf_SM_PlayerRenameHandler=null,this._degf_SM_AsuramRenameHandler=null,
this.registerError=new H.$,this._degf_CallDestory=()=>this.CallDestory(),this._degf_ExpireTipCancelHandle=t=>this.ExpireTipCancelHandle(t),
this._degf_ExpireTipOkHandle=t=>this.ExpireTipOkHandle(t),this._degf_ObtainTitleTipOkHandle=t=>this.ObtainTitleTipOkHandle(t),
this._degf_OnSpecialTipConfirm=t=>this.OnSpecialTipConfirm(t),this._degf_SM_LightTitleHandle=t=>this.SM_LightTitleHandle(t),
this._degf_SM_LoginTitleUpdateHandle=t=>this.SM_LoginTitleUpdateHandle(t),this._degf_SM_ObtainTitleHandle=t=>this.SM_ObtainTitleHandle(t),
this._degf_SM_ObtainTitleMessageHandler=t=>this.SM_ObtainTitleMessageHandler(t),this._degf_SM_SwitchTitleVOHandle=t=>this.SM_SwitchTitleVOHandle(t),
this._degf_SM_TitleIdShowHandle=t=>this.SM_TitleIdShowHandle(t),this._degf_SM_TitleNotifyHandle=t=>this.SM_TitleNotifyHandle(t),
this._degf_SM_TitleOvertimeInfoHandle=t=>this.SM_TitleOvertimeInfoHandle(t),this._degf_UpdateSpecialTip=t=>this.UpdateSpecialTip(t),
this._degf_SM_TitleGradeHandler=t=>this.SM_TitleGradeHandle(t),this._degf_SM_PlayerRenameHandler=t=>this.SM_PlayerRenameHandle(t),
this._degf_SM_AsuramRenameHandler=t=>this.SM_AsuramRenameHandle(t),this.model=q.Y.Inst_get()}static Inst(){return null==t.inst&&(t.inst=new t),t.inst}
OpenByParam(t,e,i,s=null,n=null){null==t&&(t=!1),this.curRoleUseDefaultTab=!1,t&&(null!=e&&(this.topUseDefaultTab=t,x.U.Inst_get().topViewType=e),
null!=i&&(this.CharacterViewDefaultTab=t,x.U.Inst_get().characterViewType=i),null!=s&&(this.curRoleUseDefaultTab=!0,x.U.Inst_get().curSelectIdx=s),this.fashionUseDefaultTab=t)
const l=this.GetFuncIdByViewType()
E.P.Inst_get().IsFunctionOpened(l)||-1==l?this.OpenPanel():A.l.SetFunctionTip(l),this.baseData=n}Open(t,e){if(null==t&&(t=!1),this.topUseDefaultTab=t,this.infoUseDefaultTab=t,
this.fashionUseDefaultTab=t,this.curRoleUseDefaultTab=null!=e,x.U.Inst_get().curSelectIdx=null!=e?e:-1,t)this.OpenPanel()
else{const t=this.GetFuncIdByViewType()
E.P.Inst_get().IsFunctionOpened(t)||-1==t?this.OpenPanel():A.l.SetFunctionTip(t)}}OpenPanel(){const t=new c.v
t.isShowMask=!0,t.isDefaultUITween=!0,u.N.inst.OpenById(nt.o.CharacterTopView,this._degf_ShowHandler,this._degf_CallDestory,t),this.baseData=null}GetFuncIdByViewType(){
if(x.U.Inst_get().topViewType==S.Q.Normal){if(x.U.Inst_get().characterViewType==f.f.Normal)return-1
if(x.U.Inst_get().characterViewType==f.f.AddAttrs)return-1
if(x.U.Inst_get().characterViewType==f.f.TITLE)return v.x.TITLE
if(x.U.Inst_get().characterViewType==f.f.SURFACE_FASHION)return v.x.FASHION}return-1}CallDestory(){_.g.DestroyUIObj(this.topView)}Close(){(0,l.sR)(nt.o.CharacterTopView)}AddLis(){}
SM_ObtainTitleMessageHandler(t){const e=t
null!=e&&(this.model.specialId=e,this.model.specialList.Add(e),this.AddSpecialTitleNotice())}AddSpecialTitleNotice(){const t=new b.U(B.K.ICON_TIPS_SPECIAL_TITLE)
L.S.Inst_get().AddIcon(t)
const e=q.Y.Inst_get().specialList
L.S.Inst_get().UpdateCount(B.K.ICON_TIPS_MAIL,e.Count())}SM_TitleIdShowHandle(t){const e=t
lt.k.inst.TitleShowHandle(e)}SM_LightTitleHandle(t){const e=t
lt.k.inst.TitleLightHandle(e),e.isLight&&k.y.inst.ClientSysMessage(170010)}SM_SwitchTitleVOHandle(t){const e=t
lt.k.inst.TitleSwitchHandle(e),e.isShow&&k.y.inst.ClientSysMessage(170009)}SM_LoginTitleUpdateHandle(t){const e=t,i=new m.Z
for(const[t,s]of(0,a.V5)(e.titles))s.stateType!=Y.INACTIVE&&(i.Add(s),s.stateType!=Y.ACTIVE_LIGHT_SHOW&&s.stateType!=Y.ACTIVE_NOLIGHT_SHOW||(q.Y.Inst_get().showTitleId=s.titleId,
r.Y.Inst.PrimaryRoleInfo_get().TitleId_set(s.titleId)),s.stateType!=Y.ACTIVE_LIGHT_NOSHOW&&s.stateType!=Y.ACTIVE_LIGHT_SHOW||q.Y.Inst_get().useAttrTitleId_set(s.titleId))
0!=e.titles.Count()&&G.f.Inst.SetState(M.t.ATTRIBUTE_TITLE,0==q.Y.Inst_get().useAttrTitleId_get()),q.Y.Inst_get().Titles_set(i)}SM_ObtainTitleHandle(t){const e=t
if(1==e.historyCnt&&A.l.CheckTrigger(D.u.FIRST_TITLE_VAL,e.historyCnt),q.Y.Inst_get().newGetTitleId=e.titleId,q.Y.Inst_get().isContained(e.titleId))q.Y.Inst_get().RefreshTitles(e)
else{q.Y.Inst_get().AddTitle(e)
const t=F.W.Inst().getItemById(e.titleId)
if(20==t.getType){const t=new U.N
t.showText=(0,o.T)("您获得新的称号，快去看看吧！"),t.okText=(0,o.T)("确定"),t.titleText=(0,o.T)("提示"),t.tipstype=1,t.btnColorType=2,t.okhandler=this._degf_ObtainTitleTipOkHandle,
k.y.inst.OpenCommonMessageTips(t)}else 10==t.getType&&(x.U.Inst_get().topViewType=S.Q.Normal,x.U.Inst_get().characterViewType=f.f.TITLE,this.Open())}
G.f.Inst.SetState(M.t.ATTRIBUTE_TITLE,0==q.Y.Inst_get().useAttrTitleId_get())}SM_TitleOvertimeInfoHandle(t){const e=t
this.model.ExpireId_set(e.titleId)
const i=new b.U(B.K.ICON_TIPS_TITLE_EXPIRE)
L.S.Inst_get().AddIcon(i)}SM_TitleNotifyHandle(t){const e=t
r.Y.Inst.getRoleById(e.playerId).Roleinfo_get().TitleId_set(e.titleId)}ObtainTitleTipOkHandle(t){x.U.Inst_get().topViewType=S.Q.Normal,x.U.Inst_get().characterViewType=f.f.TITLE,
this.Open()}ExpireTipHandle(){const t=this.model.expireList,e=t.Count(),i=t[e-1],s=F.W.Inst().getItemById(i)
this.model.expireList.Remove(i)
const n=new U.N
n.showText=(0,o.T)("您的称号[e2a66a]")+(s.name+(0,o.T)("[-]已过期")),n.okText=(0,o.T)("确定"),n.titleText=(0,o.T)("提示"),n.tipstype=1,n.btnColorType=2,
n.okhandler=this._degf_ExpireTipOkHandle,n.cancelhandler=this._degf_ExpireTipCancelHandle,n.checkhandler=this._degf_ExpireTipCancelHandle,k.y.inst.OpenCommonMessageTips(n)}
ExpireTipOkHandle(t){this.ExpireTipCancelHandle(!0)}ExpireTipCancelHandle(t){
0==this.model.expireList.Count()?L.S.Inst_get().RemoveIcon(B.K.ICON_TIPS_TITLE_EXPIRE):L.S.Inst_get().UpdateCount("ICON_TIPS_TITLE_EXPIRE",this.model.expireList.Count())}
GetTopViewFatherId(){return null!=this.topView?this.topView.FatherId:0}ClickSpecialIcon(){
const t=F.W.Inst().getItemById(this.model.specialId.titleId).CommonnoticeId,e=y.L.Inst().getItemById(t)
if(q.Y.Inst_get().specialList.Remove(this.model.specialId),null!=e){const t=new U.N
if(t.titleText=e.title,t.tipstype=2,40001==this.model.specialId.titleId){let i=V.E.New(this.model.specialId.endTime.ToNum()),s=A.l.AddFrontZeroFromNum(2,i.month_get()+1)+(0,
o.T)("月")
s+=A.l.AddFrontZeroFromNum(2,i.date_get())+(0,o.T)("日"),V.E.Recycle(i),i=null,t.showText=I.M.Replace(e.text,"{0}",s)}else t.showText=e.text
t.okhandler=this._degf_OnSpecialTipConfirm,t.cancelhandler=this._degf_UpdateSpecialTip,k.y.inst.OpenCommonMessageTips(t)}}OnSpecialTipConfirm(t){
if(q.Y.Inst_get().TitleOwned_get().Contains(this.model.specialId.titleId)){const t=new O.o
t.titleId=this.model.specialId.titleId,t.isShow=!0,d.C.Inst.F_SendMsg(t)
const e=new P.t
e.titleId=q.Y.Inst_get().specialId.titleId
const i=F.W.Inst().getItemById(this.model.useAttrTitleId_get()),s=F.W.Inst().getItemById(this.model.specialId.titleId)
;(0==q.Y.Inst_get().useAttrTitleId_get()||s.wearGrade>i.wearGrade)&&(e.isLight=!0,d.C.Inst.F_SendMsg(e)),k.y.inst.ClientSysMessage(170007)}else k.y.inst.ClientSysMessage(170008)
this.UpdateSpecialTip(!0)}UpdateSpecialTip(t){0==q.Y.Inst_get().specialList.Count()?(L.S.Inst_get().RemoveIcon(B.K.ICON_TIPS_SPECIAL_TITLE),
q.Y.Inst_get().specialId=null):(N.Z.Inst.ClosePanel(),q.Y.Inst_get().specialId=this.model.specialList[0],this.ClickSpecialIcon(),
L.S.Inst_get().UpdateCount("ICON_TIPS_SPECIAL_TITLE",this.model.expireList.Count()))}SM_TitleGradeHandle(t){const e=t
q.Y.Inst_get().titleScore=e.titleScore,h.i.Inst.RaiseEvent(C.g.TITLE_SCORE_UPDATE)}SM_PlayerRenameHandle(t){const e=t
p.I.inst.lastReRoleTime=e.lastRename.ToNum(),this.DoRenameHandle(e.code,e.second)}DoRenameHandle(t,e){
this.registerError.error.LuaDic_ContainsKey(t)&&k.y.inst.ClientStrMsg(R.r.SystemTipMessage,this.registerError.error[t]),0==t&&(e?(T.t.Inst().Close(),g.F.Inst_get().ClosePanel(),
g.F.Inst_get().ChangeNameSuccess()):g.F.Inst_get().HandleChangeName())}SM_AsuramRenameHandle(t){const e=t
p.I.inst.lastReAsuramTime=e.lastRenameTime.ToNum(),this.DoRenameHandle(e.status,!e.first)}SetCharacterTabActvie(t){}SetRedPointId(t){
null!=this.topView&&this.topView.node&&this.topView.SetRedPointId(t)}},st.inst=null,at(it=st,"Inst",[s.n],Object.getOwnPropertyDescriptor(it,"Inst"),it),
at(it.prototype,"SM_ObtainTitleMessageHandler",[W],Object.getOwnPropertyDescriptor(it.prototype,"SM_ObtainTitleMessageHandler"),it.prototype),
at(it.prototype,"SM_TitleIdShowHandle",[j],Object.getOwnPropertyDescriptor(it.prototype,"SM_TitleIdShowHandle"),it.prototype),
at(it.prototype,"SM_LightTitleHandle",[Z],Object.getOwnPropertyDescriptor(it.prototype,"SM_LightTitleHandle"),it.prototype),
at(it.prototype,"SM_SwitchTitleVOHandle",[X],Object.getOwnPropertyDescriptor(it.prototype,"SM_SwitchTitleVOHandle"),it.prototype),
at(it.prototype,"SM_LoginTitleUpdateHandle",[K],Object.getOwnPropertyDescriptor(it.prototype,"SM_LoginTitleUpdateHandle"),it.prototype),
at(it.prototype,"SM_ObtainTitleHandle",[$],Object.getOwnPropertyDescriptor(it.prototype,"SM_ObtainTitleHandle"),it.prototype),
at(it.prototype,"SM_TitleOvertimeInfoHandle",[J],Object.getOwnPropertyDescriptor(it.prototype,"SM_TitleOvertimeInfoHandle"),it.prototype),
at(it.prototype,"SM_TitleNotifyHandle",[z],Object.getOwnPropertyDescriptor(it.prototype,"SM_TitleNotifyHandle"),it.prototype),
at(it.prototype,"SM_TitleGradeHandle",[Q],Object.getOwnPropertyDescriptor(it.prototype,"SM_TitleGradeHandle"),it.prototype),
at(it.prototype,"SM_PlayerRenameHandle",[tt],Object.getOwnPropertyDescriptor(it.prototype,"SM_PlayerRenameHandle"),it.prototype),
at(it.prototype,"SM_AsuramRenameHandle",[et],Object.getOwnPropertyDescriptor(it.prototype,"SM_AsuramRenameHandle"),it.prototype),it)},50894:(t,e,i)=>{i.d(e,{k:()=>p})
var s=i(18998),n=i(75507),l=i(98800),a=i(97960),o=i(97461),r=i(56937),h=i(18202),d=i(31222),c=i(5494),_=i(52726),u=i(92679),I=i(58158),m=i(54151),g=i(76466)
class p{static get inst(){return p._inst||(p._inst=new p),p._inst}constructor(){this.characterView=null,this.fightStageView=null,this.cModel=null,this.characterContainer=null,
this.baseInfoContainer=null,this.correctContainer=null,this.fightStageContainer=null,this.titleContainer=null,this.soulPanel=null,this.bagitem=null,
this._degf_BattleScoreUpdate=null,this._degf_CallSoulDestory=null,this._degf_OnOpenSoulPanel=null,this._degf_OnfightStageLoadComplete=null,this._degf_DestoryTipsPanel=null,
this._degf_ShowTipsHandler=null,this._degf_BattleScoreUpdate=t=>this.BattleScoreUpdate(t),this._degf_CallSoulDestory=()=>this.CallSoulDestory(),
this._degf_OnOpenSoulPanel=t=>this.OnOpenSoulPanel(t),this._degf_OnfightStageLoadComplete=t=>this.OnfightStageLoadComplete(t),this.cModel=I.U.Inst_get()}AddLis(){
const t=l.Y.Inst.primaryRoleInfoList
for(let e=0;e<=t.Count()-1;e++){t[e].AddEventHandler(a.A.BattleScoreUpdate,this._degf_BattleScoreUpdate)}}RemoveLis(){const t=l.Y.Inst.primaryRoleInfoList
for(let e=0;e<=t.Count()-1;e++){t[e].RemoveEventHandler(a.A.BattleScoreUpdate,this._degf_BattleScoreUpdate)}}ShowUpFightStageEffect(){this.characterView}BattleScoreUpdate(t){
this.characterView&&this.characterView.UpdateEquipScoreHandler()}GetFSName(t,e){return t}GetNoColorFSName(t,e){return t}PlayFightEffect(t){}InitCharacterViewData(t){
null==this.characterView||null==this.characterView.node?(this.characterContainer=t,this.OnCharacterViewLoadComplete("ui_characterui_characterview")):this.characterView.InitData()}
OnCharacterViewLoadComplete(t){const e=n.o.getPrefab(t),i=(0,s.instantiate)(e)
this.characterContainer.addChild(i),this.characterView=i.getCNode(g.b),this.characterView.InitData()}ClearCharacterViewData(){
null!=this.characterView&&this.characterView.node&&(this.characterView.node.SetActive(!1),this.characterView.ClearData())}DestroyCharacterView(){
null!=this.characterView&&(this.characterView=null,this.characterContainer=null)}SetAttribute(t){o.i.Inst.RaiseEvent(u.g.SET_ADDPOINT_ATT,t)}InitFightStageViewData(t){}
OnfightStageLoadComplete(t){}ClearFightStageViewData(){null!=this.fightStageView&&this.fightStageView.ClearViewData()}DestroyFightStageView(){
null!=this.fightStageView?(this.fightStageView.ClearViewData(),this.fightStageView.DestroyViewData(),h.g.DestroyUIObj(this.fightStageView),
this.fightStageView=null):h.g.Unload(this._degf_OnfightStageLoadComplete)}TitleShowHandle(t){o.i.Inst.RaiseEvent(u.g.TITLE_SHOW_UPDATE,t)}TitleSwitchHandle(t){
t.isShow?(m.Y.Inst_get().showTitleId=t.titleId,l.Y.Inst.PrimaryRoleInfo_get().TitleId_set(t.titleId)):(m.Y.Inst_get().showTitleId=0,l.Y.Inst.PrimaryRoleInfo_get().TitleId_set(0)),
o.i.Inst.RaiseEvent(u.g.TITLE_SWITCH,t)}TitleLightHandle(t){t.isLight?m.Y.Inst_get().useAttrTitleId_set(t.titleId):m.Y.Inst_get().useAttrTitleId_set(0),
o.i.Inst.RaiseEvent(u.g.TITLE_LIGHT,t)}SetEffectOnHead(t){o.i.Inst.RaiseEvent(u.g.TITLE_PREVIEW,t)}OpenSoulPanel(t){this.bagitem=t
const e=new r.v
e.isShowMask=!0,e.layerType=_.F.Alert,d.N.inst.OpenById(c.I.eSoulPanel,this._degf_OnOpenSoulPanel,this._degf_CallSoulDestory,e)}OnOpenSoulPanel(t){return this.soulPanel}
CallSoulDestory(){h.g.DestroyUIObj(this.soulPanel),this.soulPanel=null}CloseSoulPanel(){d.N.inst.CloseById(c.I.eSoulPanel)}}p._inst=null},14897:(t,e,i)=>{i.d(e,{L:()=>c})
var s=i(17409),n=i(97461),l=i(56937),a=i(18202),o=i(31222),r=i(5494),h=i(52726),d=i(92679)
class c{constructor(){this.view=null,this.totalTipView=null,this.tipView=null,this.clickTitleId=0,this.isForVipPanel=!1,this.tipData=null,this.bagData=null,
this.titleItemTipPanel=null,this._degf_CallDestroy=null,this._degf_CallTipDestroy=null,this._degf_ShowHandler=null,this._degf_TipShowHandler=null,
this._degf_ShowItemTipHandler=null,this._degf_CallItemTipDestroy=null,this._degf_CallDestroy=()=>this.CallDestroy(),this._degf_CallTipDestroy=()=>this.CallTipDestroy(),
this._degf_ShowHandler=t=>this.ShowHandler(t),this._degf_TipShowHandler=t=>this.TipShowHandler(t),this._degf_ShowItemTipHandler=t=>this.ShowItemTipHandler(t),
this._degf_CallItemTipDestroy=()=>this.CallItemTipDestroy()}static Inst(){return null==c.inst&&(c.inst=new c),c.inst}OpenItemTip(t,e=null){this.tipData=t,this.bagData=e
const i=new l.v
i.layerType=h.F.Tip,i.isShowMask=!0,o.N.inst.OpenById(r.I.eTitleItemTip,this._degf_ShowItemTipHandler,this._degf_CallItemTipDestroy,i)}ShowItemTipHandler(t){
return n.i.Inst.RaiseEvent(d.g.TipsLoadCompelete),this.titleItemTipPanel}CallItemTipDestroy(){a.g.DestroyUIObj(this.titleItemTipPanel),this.titleItemTipPanel=null,
this.tipData=null,this.bagData=null}CloseItemTip(){(0,s.sR)(r.I.eTitleItemTip),n.i.Inst.RaiseEvent(d.g.CLICK_CLOSEIP)}Open(){const t=new l.v
t.isShowMask=!0,t.isDefaultUITween=!0,(0,s.Yp)(r.I.TitleTotalTip)}ShowHandler(t){return this.totalTipView}CallDestroy(){a.g.DestroyUIObj(this.totalTipView),this.totalTipView=null}
Close(){(0,s.sR)(r.I.TitleTotalTip)}OpenTip(t){const e=new l.v
e.isShowMask=!0,e.isDefaultUITween=!0,e.layerType=h.F.Tip,(0,s.Yp)(r.I.TitleTip)}TipShowHandler(t){return this.tipView}CallTipDestroy(){a.g.DestroyUIObj(this.tipView),
this.tipView=null}CloseTip(){(0,s.sR)(r.I.TitleTip)}}c.inst=null},58158:(t,e,i)=>{i.d(e,{U:()=>a})
var s=i(98800),n=i(54130),l=i(51965)
class a{constructor(){this.preIndex=0,this._topViewType=void 0,this.subTopViewType=null,this.characterViewType=null,this.isFirstTotalScore=!0,this.isMasterTalentOpen=!1,
this.curSelectIdx=-1,this.AniPlayEnd=!1}get topViewType(){return this._topViewType}set topViewType(t){this._topViewType=t}static Inst_get(){return null==a.inst&&(a.inst=new a,
a.inst.initData()),a.inst}initData(){this.topViewType=n.Q.Normal,this.characterViewType=l.f.Normal}Reset(){this.preIndex=0,this.topViewType=null,this.characterViewType=null,
this.isFirstTotalScore=!0,this.curSelectIdx=0,this.AniPlayEnd=!1}GetCurRoleInfo(){return s.Y.Inst.GetMultiPlayerInfoByCreateIdx(this.curSelectIdx)}}
a.MAINUI_ANIMATION_COMPLETE="MAINUI_ANIMATION_COMPLETE",a.inst=null,a.AttrIntruction_Special=3},95097:(t,e,i)=>{i.d(e,{S:()=>n})
var s=i(98130)
class n{constructor(t,e){this._index=0,this._equipmentEx=null,this._index=t,this._equipmentEx=e}GetColumn(){return s.GF.INT(this._index/100)}GetPos(){return this._index%100}}},
23628:(t,e,i)=>{i.d(e,{b:()=>tt})
var s=i(38836),n=i(86133),l=i(98800),a=i(97461),o=i(26034),r=i(68662),h=i(62370),d=i(95721),c=i(35128),_=i(98130),u=i(98885),I=i(85602),m=i(38962),g=i(51262),p=i(84485),C=i(70850),S=i(45538),f=i(75363),T=i(59918),y=i(3859),A=i(92679),D=i(77477),E=i(33314),v=i(74045),w=i(49067),R=i(87923),P=i(44498),O=i(29714),L=i(30754),B=i(75439),b=i(42534),M=i(68561),G=i(47786),H=i(41864),N=i(10153),k=i(5968),U=i(65550),V=i(85942),x=i(35042),F=i(32942),q=i(29109),Y=i(37151),W=i(48916),j=i(75321),Z=i(95097),X=i(71143),K=i(97331)
let $=null,J=null,z=null,Q=null
class tt{static __StaticInit(){$=new I.Z,J=new m.X,z=new m.X,Q=new m.X,tt.noExcellenceEquipList=new I.Z}static IsWearForAllRole(t){for(const[e,i]of(0,
s.V5)(l.Y.Inst.primaryRoleInfoList))if(tt.IsWearForRole(i,t))return!0
return!1}static IsWearForRole(t,e,i=!0){
return!(null!=e.serverData_get().deprecatedTime&&!e.serverData_get().deprecatedTime.Equal(d.o.ZERO)&&e.serverData_get().deprecatedTime.ToNum()<r.D.serverMSTime_get())&&(!!tt.IsTakeOnLevel(t.Level_get(),e.cfgData_get().level,!1)&&(!!tt.IsAttrCanTakeOnTips(t,e,!1)&&(!(i&&!tt.IsTakeOnColumn(t,e,!1))&&(!tt.IsHasSameSuitEquip(t,e)&&tt.GetUpScoreForRole(t,e)>0))))
}BagIsWearForRole(t){
for(let e=0;e<=C.g.Inst_get().GetBagDataList().Count()-1;e++)if(null!=C.g.Inst_get().GetBagDataList()[e]&&null!=C.g.Inst_get().GetBagDataList()[e].baseData_get()&&null!=C.g.Inst_get().GetBagDataList()[e].baseData_get().cfgEquipData_get()&&tt.IsWearForRole(t,C.g.Inst_get().GetBagDataList()[e].baseData_get()))return!0
return!1}static IsRecommendForAllRole(t){for(const[e,i]of(0,s.V5)(l.Y.Inst.primaryRoleInfoList))if(tt.IsRecommendForRole(i,t))return!0
return!1}static IsRecommendForRole(t,e){
return!(!tt.IsWillJob(t.Job_get(),e.cfgData_get().Jobs_get())&&!tt.IsWearJob(t.Job_get(),e.cfgData_get().Jobs_get()))&&(!tt.IsHasSameSuitEquip(t,e)&&tt.GetUpScoreForRole(t,e,!1)>0)
}IsWillRecommendForAllRole(t){for(const[e,i]of(0,s.V5)(l.Y.Inst.primaryRoleInfoList))if(tt.IsWillRecommendForRole(i,t))return!0
return!1}static IsWillRecommendForRole(t,e){if(!tt.IsWillJob(t.Job_get(),e.cfgData_get().Jobs_get()))return!1
for(let i=0;i<=e.cfgEquipData_get().equipColumnsList_get().Count()-1;i++)if(t.GetUnlockByColumn(e.cfgEquipData_get().equipColumnsList_get()[i]))return!1
return!0}IsUnRecommendForAllRole(t){for(const[e,i]of(0,s.V5)(l.Y.Inst.primaryRoleInfoList))if(!tt.IsUnRecommendForRole(i,t))return!1
return!0}static IsUnRecommendForRole(t,e){return!tt.IsWillJob(t.Job_get(),e.cfgData_get().Jobs_get())||!tt.IsWearForRole(t,e)}static GetUpScoreForRole(t=null,e=null,i=null){
return tt.GetUpScore(t,e,i)}static GetUpScore(t=null,e=null,i=null){if(e.cfgData_get().itemType==y.q.ELEMENT)return 0
const s=tt.GetUpPosScoreDictForRole(t,e,i)
if(0==s.LuaDic_Count())return 0
let n=_.GF.INT32_MIN_VALUE_get()
for(const[t,e]of s)e>n&&(n=e)
return n}static GetUpColumnAndPos(t=null,e=null,i=null,s=null){const n=tt.GetUpPosScoreDictForRole(t,e,i,s)
if(0==n.LuaDic_Count())return[0,0]
const l=new I.Z
for(const[t,e]of n)l.Add(new I.Z([t,e]))
l.Sort(tt.SortByColumnAndPos)
let a=0,o=0
for(let t=0;t<=l.Count()-1;t++){const e=l[t][1]
e>a&&(a=e,o=l[t][0])}if(e.equipRes_get().suitId>0){const i=_.GF.INT(o/100),s=tt.GetSuitCountUpBestCol(t,e.modelId_get(),i)
if(s!=i)for(let t=0;t<=l.Count()-1;t++){const e=l[t][1],i=_.GF.INT(l[t][0]/100)
e==a&&s==i&&(o=l[t][0])}}return[o,a]}static GetUpColumnAndPosForAllRole(t,e,i){let s=-1,n=0,a=0
for(let o=0;o<=l.Y.Inst.primaryRoleInfoList.Count()-1;o++){const[r,h]=tt.GetUpColumnAndPos(l.Y.Inst.primaryRoleInfoList[o],t,e,i)
h>a&&(a=h,s=o,n=r)}return[s,n]}static GetUpPosFromColumn(t,e,i){const s=tt.GetUpPosScoreDictForRole(t,e,!0,i)
if(0==s.LuaDic_Count())return e.cfgEquipData_get().wearPosition_get()
const n=new I.Z
for(const[t,e]of s)n.Add(new I.Z([t,e]))
n.Sort(tt.SortByColumnAndPos)
let l=_.GF.INT32_MIN_VALUE_get(),a=e.cfgEquipData_get().wearPosition_get()
for(let t=0;t<=n.Count()-1;t++){const e=n[t][1]
e>l&&(l=e,a=n[t][0]%100)}return a}static SortByColumnAndPos(t,e){return t[0]-e[0]}static GetSuitCountUpBestCol(t,e,i){const n=b.f.Inst().getItemById(e)
if(null==n||0==n.suitId)return-1
const l=n.suitId
let a=0,o=1
if(null==i)i=1
else{const e=t.GetEquipmentsByColumn(i)
if(null!=e){const t=e.equipmentsGet(2)
let i=0
if(null!=t){for(let e=0;e<=t.Count()-1;e++){const s=t[e]
null!=s&&s.suitId==l&&(i+=1)}a=i}}}o=i
for(const[e,i]of(0,s.vy)(t.AllStageEquipments_get()))if(i.unlockColumn){const t=i.equipmentsGet(2)
let s=0
if(null!=t){for(let e=0;e<=t.Count()-1;e++){const i=t[e]
null!=i&&i.suitId==l&&(s+=1)}a<s&&(a=s,o=e)}}return o}static GetUpPosScoreDictForRole(t=null,e=null,i=null,n=null){
if(!tt.IsRecommendJob(t.Job_get(),e.cfgData_get().Jobs_get()))return J
null==i&&(i=!0)
const l=tt.GetPosByType(t,e.cfgEquipData_get().equipType),a=P.I.Score(e,t.Job_get(),t)
z.Clear()
const o=z
Q.Clear()
const r=Q
let h=null
h=null
for(let s=0;s<=l.Count()-1;s++){const d=l[s],c=e.cfgEquipData_get()
let _=null
if(null!=n&&0!=n?($.Clear(),$.Add(n),_=$):_=c.equipColumnsList_get(),c.suitId>0){const e=c.equipColumnsList_get()
for(let i=0;i<=e.Count()-1;i++){const s=e[i],n=t.GetSuitEquipmentByColumnAndPos(s,d)
if(null!=n){const t=n.GetEquipRes().id
r.LuaDic_ContainsKey(t)?r.LuaDic_GetItem(t).Add(100*s+d):r.LuaDic_AddOrSetItem(t,new I.Z([100*s+d]))}}}for(let s=0;s<=_.Count()-1;s++){const n=_[s]
if(-1!=f.Y.Inst_get().GetEquipcolumnresourceById(n).locationList.IndexOf(d)&&(!i||t.GetUnlockByColumn(n))){let i=null
i=c.suitId>0?t.GetSuitEquipmentByColumnAndPos(n,d):t.GetEquipmentByColumnAndPos(n,d)
let s=0
if(null==i)s=a
else{0==i.GetEquipRes().uniqueType||o.LuaDic_ContainsKey(i.GetEquipRes().uniqueType)||o.LuaDic_AddOrSetItem(i.GetEquipRes().uniqueType,100*n+d)
const l=P.I.GetEquipSocre(i,null,t.Job_get(),!1,t,e.equipInfo_get())
s=i.GetEquipRes().equipType==e.cfgEquipData_get().equipType||0!=e.cfgEquipData_get().isAngelWeapon||0!=i.GetEquipRes().isAngelWeapon?a-l:tt.IsPosRecommendType(t,d,e.cfgEquipData_get().equipType)&&!tt.IsPosRecommendType(t,d,i.GetEquipRes().equipType)?a:-l
}null==h&&(h=new m.X),h.LuaDic_AddOrSetItem(100*n+d,s)}}}if(0!=e.cfgEquipData_get().uniqueType&&o.LuaDic_ContainsKey(e.cfgEquipData_get().uniqueType)){
const t=o.LuaDic_GetItem(e.cfgEquipData_get().uniqueType),i=h.LuaDic_GetItem(t)
null==h&&(h=new m.X),h.Clear(),h.LuaDic_AddOrSetItem(t,i)}if(e.cfgEquipData_get().suitId>0&&r.LuaDic_ContainsKey(e.cfgEquipData_get().id)){
const t=r.LuaDic_GetItem(e.cfgEquipData_get().id),i=new m.X
for(const[e,n]of(0,s.V5)(h)){const s=e%100,l=t.Count()
let a=!0
for(let e=0;e<=l-1;e++){s==t[e]%100&&(a=!1)}a&&i.LuaDic_AddOrSetItem(e,n)}null!=h&&(h.Clear(),h=null),h=i}return null==h?J:h}static IsPosRecommendType(t,e,i){
if(e!=j.C.PART_WEAPON_RIGHT||E.Z.IsMagician(t.Job_get())||E.Z.IsArcher(t.Job_get()))return e==R.l.getWearPosByPosition(j.C.GetEquipEnum(i))
return Y.Q.cfg.GetJobVo(t.Job_get()).branch==W.t.JOB_BRANCH_2?j.C.GetEquipEnum(i)==j.C.SUBWEAPON:j.C.GetEquipEnum(i)==j.C.SINGLEWEAPON}IsPosFixType(t,e,i){
return e!=j.C.PART_WEAPON_RIGHT||E.Z.IsMagician(t.Job_get())||E.Z.IsArcher(t.Job_get())?e==R.l.getWearPosByPosition(j.C.GetEquipEnum(i)):j.C.GetEquipEnum(i)==j.C.SINGLEWEAPON}
static GetPosByType(t,e){const i=I.Z.TEMP_get()
return i.Add(R.l.getWearPosByPosition(j.C.GetEquipEnum(e))),E.Z.IsSwordman(t.Job_get())&&j.C.GetEquipEnum(e)==j.C.SINGLEWEAPON&&i.Add(j.C.PART_WEAPON_RIGHT),
j.C.GetEquipEnum(e)==j.C.RINGS&&i.Add(j.C.PART_RINGS_RIGHT),i}HadEquipSameType(t,e){const i=e.cfgEquipData_get().equipColumnsList_get()
for(let n=0;n<=i.Count()-1;n++){const l=tt.GetPosByType(t,e.cfgEquipData_get().equipType)
for(const[a,o]of(0,s.V5)(l)){const s=t.GetWearEquipByColumnAndPos(i[n],o)
if(null!=s&&0!=s.GetEquipRes().uniqueType&&s.GetEquipRes().uniqueType==e.cfgEquipData_get().uniqueType)return!0}}return!1}static HadWearPosByColumn(t,e,i){
const n=tt.GetPosByType(t,e.cfgEquipData_get().equipType)
for(const[e,l]of(0,s.V5)(n))if(t.GetUnlockByColumnAndPos(i,l))return!0
return!1}static IsRecommendJobForAllRole(t){for(const[e,i]of(0,s.V5)(l.Y.Inst.primaryRoleInfoList)){t.cfgData_get().Jobs_get()
if(tt.IsRecommendJob(i.Job_get(),t.cfgData_get().Jobs_get()))return!0}return!1}static IsRecommendJob(t,e){return tt.IsWillJob(t,e)||tt.IsWearJob(t,e)}IsWillJobForAllRole(t){
for(const[e,i]of(0,s.V5)(l.Y.Inst.primaryRoleInfoList))if(tt.IsWillJob(i.Job_get(),t.cfgData_get().Jobs_get()))return!0
return!1}static IsWillJob(t,e){if(null==e||0==e.Count())return!0
const i=q.I.GetChilds(t)
for(const[t,n]of(0,s.V5)(i))for(const[t,i]of(0,s.V5)(e))if(n==i)return!0
return!1}IsWearJobForAllRole(t){for(const[e,i]of(0,s.V5)(l.Y.Inst.primaryRoleInfoList))if(tt.IsWearJob(i.Job_get(),t.cfgData_get().Jobs_get()))return!0
return!1}static IsWearJob(t,e){if(null==e||0==e.Count())return!0
const i=q.I.GetParents(t)
for(const[t,n]of(0,s.V5)(i))for(const[t,i]of(0,s.V5)(e))if(n==i)return!0
return!1}static IsEquipEqual(t,e){if(t.modelId!=e.modelId)return!1
if(t.ExcellenceCount_get()!=e.ExcellenceCount_get())return!1
if(0==t.ExcellenceCount_get())return!0
for(const[i,n]of(0,s.V5)(t.exellectAttrs.attributeDatas))if(e.GetExcellenceAttrVal(n.type)!=n.value)return!1
return!0}GetWearEquipByModelId(t){for(let e=0;e<=l.Y.Inst.primaryRoleInfoList.Count()-1;e++){const i=l.Y.Inst.primaryRoleInfoList[e]
if(null!=i&&i.HasEquipmentById(t))return!0}return!1}IsTakeOnSex(t,e,i){return 0==e||e==t||(i&&U.y.inst.ClientSysMessage(x.X.Unconformity_Sex),!1)}static IsTakeOnJob(t,e,i){
return!!tt.IsWearJob(t,e)||(i&&U.y.inst.ClientSysMessage(x.X.Unconformity_Pro),!1)}static IsTakeOnLevel(t,e,i){return null==i&&(i=!1),
!(t<e)||(i&&U.y.inst.ClientSysMessage(x.X.Unconformity_Level),!1)}static IsTakeOnColumn(t,e,i){null==i&&(i=!1)
let s=-1
const l=f.Y.Inst_get().GetEquipColIdList(t,0)
for(let i=l.Count()-1;i>=0;i+=-1)if(-1!=e.cfgEquipData_get().equipColumnsList_get().IndexOf(l[i])&&(s=l[i],tt.IsTakeOnPos(t,e,l[i],!1)))return!0
return i&&(-1==s?U.y.inst.ClientSysStrMsg(h.o.Format((0,n.T)("{0}装备栏未开启"),f.Y.Inst_get().GetEquipcolumnresourceById(e.cfgEquipData_get().equipColumnsList_get()[0]).name)):tt.IsTakeOnPos(t,e,s,i)),
!1}static IsHasSameSuitEquip(t,e){const i=e.cfgEquipData_get()
if(i.suitId>0){const s=f.Y.Inst_get().GetEquipColIdList(t,0),n=tt.GetPosByType(t,e.cfgEquipData_get().equipType)
let l=!0
for(let e=0;e<=n.Count()-1;e++){const a=n[e]
let o=!1
for(let e=s.Count()-1;e>=0;e+=-1){const n=s[e]
if(t.GetUnlockByColumnAndPos(n,a)){const e=t.GetSuitEquipmentByColumnAndPos(n,a)
if(null!=e&&e.modelId==i.id){o=!1
break}o=!0}}if(o){l=!1
break}}return l}return!1}static IsTakeOnPos(t,e,i,s){const l=tt.GetPosByType(t,e.cfgEquipData_get().equipType),o=new g.H
let r=-1
for(let e=0;e<=l.Count()-1;e++){const s=l[e]
if(t.GetUnlockByColumnAndPos(i,s))return!0
0!=e?o.Append(","):r=s,o.Append(F.G.GetPartDescByType(s))}return s&&(U.y.inst.ClientSysStrMsg(h.o.Format((0,n.T)("{0} 装备位未开启"),o.ToString())),
a.i.Inst.RaiseEvent(A.g.EQUIP_POS_LOCK_TIP,[i,r,t.createIdx])),!1}static IsAttrCanTakeOnTips(t,e,i=null,s=null,n=null,l=null,a=null){null==i&&(i=!0)
let o=tt.GetEquipAttrLimit(e),r=o[0],h=o[1],d=o[2],c=o[3]
if(0==r&&0==h&&0==d&&0==c)return I.Z.Recyle(o),!0
let _=tt.GetEquipAttrDiff(t,o),u=_[0],m=_[1],g=_[2],p=_[3]
I.Z.Recyle(_),I.Z.Recyle(o)
let C=u+m+g+p
return 0==C||(i?(tt.CheckEquipBaseAtrrFixTips(e,t,s,n,l,a),!1):!(C>t.RemainBasePoint_get()))}static CheckEquipBaseAtrrFixTips(t,e,i,s,l,a){let o=""
const r=t.cfgEquipData_get(),d=t.cfgData_get(),c="[FFEFE1]",u="[FB2704]"
if(null!=d&&(d.itemType==y.q.EQUIPJEWEL||d.itemType==y.q.EQUIPJEWELSMELT))return o
const m=new I.Z([(0,n.T)("力量要求 "),(0,n.T)("敏捷要求 "),(0,n.T)("体力要求 "),(0,n.T)("智力要求 ")]),g=new I.Z([0,0,0,0]),p=new I.Z([r.strengthLimit+g[0],r.agilityLimit+g[1],r.vitalityLimit+g[2],r.intelligenceLimit+g[3]]),C=new I.Z([0,0,0,0]),S=new I.Z(4)
S[0]=_.GF.INT(e.Attributes_get()[_.GF.INT(D.Z.Strength)]),S[1]=_.GF.INT(e.Attributes_get()[_.GF.INT(D.Z.Agility)]),S[2]=_.GF.INT(e.Attributes_get()[_.GF.INT(D.Z.Vitality)]),
S[3]=_.GF.INT(e.Attributes_get()[_.GF.INT(D.Z.Intelligence)])
let f=!0,T=0,A=0
for(;T<4;){if(p[T]>0){let t=`${c}${m[T]}[-]`,e=""
S[T]<p[T]?(t+=u,C[T]=p[T]-S[T],A+=C[T],e=u+((0,n.T)(" (还需")+(p[T]-S[T]+(0,n.T)("点)[-]"))),f=!1):t+=c,t+=`${S[T]}[-]${c}${h.o.s_F_SLASH_ONE}${p[T]}[-]${e}`,o+=`${t}\n`}T+=1}
const E=new w.B
if(null==l&&(l=new I.Z),E.infoId="EQUIP:WEAR_ATRRTIP",f||A<=e.RemainBasePoint_get()){const s=B.D.getInstance().GetIntValue("NEW_HAND:ADD_POINT_AND_WEAR")
e.Level_get()>s?(E.confirmText=(0,n.T)("点击加点"),o+=`当前剩余属性点数${R.l.greenColorStr}足够[-],是否立即前往分配？`):(o+=`当前剩余属性点数${R.l.greenColorStr}足够[-],是否立即分配并穿戴？`,E.confirmText=(0,n.T)("立即加点")),
tt.selfEquipColumnAndPos=tt.GetOkEquipColumnPos(e,t),E.confirmHandle=i,l.Add(C)}else{const t=K.n.Inst_get().GetUpLvByNeedPint(e,A-e.RemainBasePoint_get(),C)
o+=-1==t?"当前职业已无法获得足够的点数，请先转职":-2==t?G.x.Inst().getItemById(11020383).sys_messsage:`再升${R.l.greenColorStr}${H.h.GetLevelStr(t)}[-]可以获得足够的点数`,E.confirmHandle=s,E.confirmText=(0,
n.T)("确定")}a&&(E.topContent=a),E.replaceParams=new I.Z,E.replaceParams.Add(o),E.confirmParam=l,v.t.Inst().Open(E)}static IsOpenSuitFuseView(t,e,i,s){const n=e.serverData_get()
if(n.suitId>0){const l=t.GetEquipmentByColumnAndPos(i,s),a=t.GetSuitEquipmentByColumnAndPos(i,s)
if(null!=l&&null==a)return tt.IsHasSameSuitEquip(t,e)?(U.y.inst.ClientSysMessage(330003),!0):(N.J.Inst().OpenSuitFuseView(l,n,t,n,l.Column_Get(),l.Pos_Get()),!0)}else{
const e=t.GetEquipmentByColumnAndPos(i,s),l=t.GetSuitEquipmentByColumnAndPos(i,s)
if(null==e&&null!=l)return N.J.Inst().OpenSuitFuseView(n,l,t,n,l.Column_Get(),l.Pos_Get()),!0}return!1}SetEquipRoleAndPos(t,e){tt.rInfo=t,tt.equipColumnAndPos=e}GetEquipColumn(){
return _.GF.INT(tt.equipColumnAndPos/100)}GetEquipPos(){return tt.equipColumnAndPos%100}GetEquipRoleInfo(){return tt.rInfo}static GetOkEquipColumnPos(t,e){let i=0
const s=e.cfgEquipData_get().equipType
let n=null,l=0
tt.noExcellenceEquipList.Clear()
const a=tt.GetAllCanTakeOnPosList(t,e)
if(0!=a.Count()){if(s==T.R.SUB_WEAPON){for(i=0;i<a.Count();){if(l=a[i].GetColumn(),n=t.GetEquipmentsByColumn(l),
(!f.Y.Inst_get().IsEquipPosUnlock(l,i,t)||null==n.equipmentsGet()[0])&&null==a[i]._equipmentEx)return a[i]._index
i+=1}let e=!1
for(i=0;i<a.Count();)e=!1,l=a[i].GetColumn(),n=t.GetEquipmentsByColumn(l),null!=n.equipmentsGet()[0]&&n.equipmentsGet()[0].GetEquipRes().equipType==T.R.DOUBLE_WEAPON&&(e=!0),
e||tt.noExcellenceEquipList.Add(a[i]),i+=1
if(0==tt.noExcellenceEquipList.Count())return tt.isEquipBaseSort=!1,a.Sort(tt.EquipScoreSort),a[0]._index
for(a.Clear(),i=0;i<tt.noExcellenceEquipList.Count();)a.Add(tt.noExcellenceEquipList[i]),i+=1
tt.noExcellenceEquipList.Clear()}else if(s==T.R.DOUBLE_WEAPON)for(i=0;i<a.Count();){if(l=a[i].GetColumn(),n=t.AllStageEquipments_get()[l],
(!f.Y.Inst_get().IsEquipPosUnlock(l,i,t)||null==n.equipmentsGet()[1])&&null==a[i]._equipmentEx)return a[i]._index
i+=1}if(0!=a.Count()){for(i=0;i<a.Count();){if(null==a[i]._equipmentEx)return a[i]._index
i+=1}return tt.isEquipBaseSort=!1,a.Sort(tt.EquipScoreSort),a[0]._index}}return I.Z.Recyle(a),0}static GetAllCanTakeOnPosList(t,e){
const i=new I.Z,s=e.cfgEquipData_get().equipColumnsList_get()
for(let n=0;n<=s.Count()-1;n++){const l=s[n]
let a=null
a=t.GetEquipmentsByColumn(l)
const o=tt.GetPosByType(t,e.cfgEquipData_get().equipType)
for(let t=0;t<=o.Count()-1;t++){const e=o[t]
i.Add(new Z.S(100*l+e,a.equipmentsGet()[e]))}}const n=e.cfgEquipData_get().uniqueType
if(n>0){let t=0
for(;t<i.Count();){if(null!=i[t]._equipmentEx&&i[t]._equipmentEx.GetEquipRes().uniqueType==n){const e=i[t]
i.Clear(),i.Add(e)}t+=1}}return i}CompareEquip(t,e,i){
const s=t.Job_get(),l=e.serverData_get(),a=P.I.GetSocreValueByEquipment(l,s,!0),o=t.GetWearEquipByColumnAndPos(tt.GetSelfEquipColumn(),tt.GetSelfEquipPos())
if(null!=o){let t=0
if(t=P.I.GetSocreValueByEquipment(o,s,!0),a<t&&i){const t=new V.N
t.isShowMask=!0,t.showText=(0,n.T)("要穿戴的装备评分低于当前穿戴的装备，是否替换？"),t.okhandler=X.i.SendCheckStarTransferTabHandler,t.objparams=tt.GetSelfEquipColumn(),t.tipstype=2,k.Z.Inst.OpenView(t)}
return a-t}return a}CheckNowHaveEquip(t,e,i){const s=e.GetEquipmentsByColumn(i)
let n=!0
const l=tt.GetPosByType(e,t.cfgEquipData_get().equipType)
for(let t=0;t<=l.Count()-1;t++){const e=l[t]
if(null==s.equipmentsGet()[e]){n=!1
break}}return n}static GetSelfEquipColumn(){return _.GF.INT(tt.selfEquipColumnAndPos/100)}static GetSelfEquipPos(){return tt.selfEquipColumnAndPos%100}static IsTimeOut(t){
if(null==t||null==t.deprecatedTime||0==t.deprecatedTime.ToNum())return!1
let e=t.deprecatedTime.ToNum()/1e3-r.D.serverTime_get()
return e=c.p.CeilToInt(e),e<=0}static GetEquipAttrLimit(t){const e=new I.Z([0,0,0,0])
return e[0]+=t.cfgEquipData_get().strengthLimit,e[1]+=t.cfgEquipData_get().vitalityLimit,e[2]+=t.cfgEquipData_get().intelligenceLimit,e[3]+=t.cfgEquipData_get().agilityLimit,e}
static GetAllEquipAttrDiff(t,e,i){const n=new I.Z([0,0,0,0])
null==i&&(i=new I.Z([0,0,0,0]))
const l=t.Attributes_get()
n[0]=l[_.GF.INT(D.Z.Strength)],n[1]=l[_.GF.INT(D.Z.Agility)],n[2]=l[_.GF.INT(D.Z.Vitality)],n[3]=l[_.GF.INT(D.Z.Intelligence)]
let a=e
const o=t.allStageEquipments
if(null!=o)for(const[e,l]of(0,s.vy)(o)){const s=o[e]
if(s.unlockColumn&&(a=tt.GetTypeEquipmentDiff(t,a,s,e,1,n,i),a=tt.GetTypeEquipmentDiff(t,a,s,e,2,n,i)),0==a)break}return[i,a]}static GetTypeEquipmentDiff(t,e,i,s,n,l,a){let o=e,r=0
const h=i.equipmentsGet(n).Count()
for(;r<h;){let e=null
if(e=1==n?t.GetEquipmentByColumnAndPos(s,r):t.GetSuitEquipmentByColumnAndPos(s,r),null!=e){const t=e.GetEquipRes()
null!=t&&(o=tt.CalTypeEquipmentOneAttrDiff(a,l,t.strengthLimit,0,o),o=tt.CalTypeEquipmentOneAttrDiff(a,l,t.agilityLimit,1,o),
o=tt.CalTypeEquipmentOneAttrDiff(a,l,t.vitalityLimit,2,o),o=tt.CalTypeEquipmentOneAttrDiff(a,l,t.intelligenceLimit,3,o))}if(0==o)break
r+=1}return o}static CalTypeEquipmentOneAttrDiff(t,e,i,s,n){const l=i-e[s]-t[s]
return l>0&&(l<n?(t[s]=t[s]+l,n-=l):(t[s]=t[s]+n,n=0)),n}static GetEquipAttrDiff(t,e,i=!1){const s=new I.Z([0,0,0,0])
if(i){const i=p.X.Inst_get()
s[0]=_.GF.INT(tt.IsTakeOnAtr(t.Attributes_get()[_.GF.INT(D.Z.Strength)]+i.strengthAddPoint,e[0])),
s[1]=_.GF.INT(tt.IsTakeOnAtr(t.Attributes_get()[_.GF.INT(D.Z.Vitality)]+i.vitalityAddPoint,e[1])),
s[2]=_.GF.INT(tt.IsTakeOnAtr(t.Attributes_get()[_.GF.INT(D.Z.Intelligence)]+i.intelligenceAddPoint,e[2])),
s[3]=_.GF.INT(tt.IsTakeOnAtr(t.Attributes_get()[_.GF.INT(D.Z.Agility)]+i.agilityAddoint,e[3]))}else s[0]=_.GF.INT(tt.IsTakeOnAtr(t.Attributes_get()[_.GF.INT(D.Z.Strength)],e[0])),
s[1]=_.GF.INT(tt.IsTakeOnAtr(t.Attributes_get()[_.GF.INT(D.Z.Vitality)],e[1])),s[2]=_.GF.INT(tt.IsTakeOnAtr(t.Attributes_get()[_.GF.INT(D.Z.Intelligence)],e[2])),
s[3]=_.GF.INT(tt.IsTakeOnAtr(t.Attributes_get()[_.GF.INT(D.Z.Agility)],e[3]))
return s}static IsTakeOnAtr(t,e){return null==t&&(t=0),null==e&&(e=0),t>=e?0:e-t}static EquipScoreSort(t,e){let i=0,s=0
const n=l.Y.Inst.PrimaryRoleInfo_get().Job_get()
return tt.isEquipBaseSort?(i=P.I.GetSocreValueByEquipment(t._equipmentEx,n,!0),s=P.I.GetSocreValueByEquipment(e._equipmentEx,n,!0)):(i=P.I.GetSocreValueByEquipment(t._equipmentEx,n,!1),
s=P.I.GetSocreValueByEquipment(e._equipmentEx,n,!1)),t._equipmentEx.IsMasterEquip()&&(i+=1e8),e._equipmentEx.IsMasterEquip()&&(s+=1e8),
i>s?1:i<s?-1:t._index>e._index?1:t._index<e._index?-1:0}static GetNameStr(t,e,i,s,n){null==i&&(i=!1)
const a=t.equipInfo_get(),o=t.cfgData_get(),r=t.serverData_get()
null==e&&(e=l.Y.Inst.GetMultiPlayerInfoByCreateIdx(0))
let h=null
if(null!=r&&0==r.GetEquipRes().suitId&&tt.IsEquipWare(t)){const t=r.Column_Get(),i=r.Pos_Get()
h=O.C.Inst_get().GetSuitResInWearByColAndPos(e,t,i)}const d=R.l.SetEquipName(a,o,r,h,!0,!0,t.previewNextEquipNum,null,null,null,i,s,n)
let c=d[0]
const _=M.X.Inst_get().GetEquipSuitProperty(r,a),I=M.X.Inst_get().IsSpecialRing(r,a),m=M.X.Inst_get().GetEquipExcellenceCount(r,a)
if(_>0||I||m>0){const t=B.D.getInstance().GetIntValue("TIPS:MAX_NUM_WORDS")
let e=d[2]
if(!(u.M.IndexOf(c,u.M.s_NN_CHAR)>=0)&&u.M.Length(e)>t){c=u.M.ReplaceOne(c,u.M.s_SPACE_CHAR,u.M.s_NN_CHAR),e=u.M.ReplaceOne(e,u.M.s_SPACE_CHAR,u.M.s_CCD_CHAR)
const i=u.M.Split(e,u.M.s_CCD_CHAR)
i.Count()>=2&&(e=i[1],u.M.Length(e)>t&&(c=u.M.ReplaceOne(c,u.M.s_SPACE_CHAR,u.M.s_NN_CHAR),c=u.M.ReplaceOne(c,u.M.s_NN_CHAR,u.M.s_SPACE_CHAR)))}}return c}static IsEquipWare(t){
let e=!1
const i=t.serverData_get()
if(null!=i){const s=t.GetRoleInfo(),[n,l]=s.GetEquipmentColAndPosById(i.id)
0!=n&&(e=!0)}return e}static IsAngelEquipSkillReplace(t,e,i,s,n){if(s!=S._.POS_WEAPON&&s!=S._.POS_SUBWEAPON)return!1
const[l,a]=L._.Inst_get().GetAngelSkill(t)
if(0==l)return!1
let r=0
if(e.equipRes_get().IsAngelEquip()){if(!(L._.Inst_get().GetAngelEquipLevel(e)<a))return!1
r=1}else{const e=t.GetEquipmentByColumnAndPos(i,s)
if(null==e)return!1
if(!b.f.Inst().getItemById(e.modelId).IsAngelEquip())return!1
r=0}const h=new w.B
return h.tipstype=2,h.confirmText=(0,o._T)("放弃替换"),h.cancelText=(0,o._T)("确认替换"),h.confirmHandle=null,h.cancelHandle=n,h.cancelParam=new I.Z([t,e,i,s]),
0==r?h.infoId="ANGLEEQUIP:CHANGE_TIPS1":1==r&&(h.infoId="ANGLEEQUIP:CHANGE_TIPS2"),v.t.Inst().Open(h),!0}static GetExcellenceBgName(t){
return 3==t?"rycommon_sp_0192":4==t?"rycommon_sp_0201":5==t||6==t?"rycommon_sp_0193":"rycommon_sp_0191"}}tt.selfEquipColumnAndPos=null,tt.rInfo=null,tt.equipColumnAndPos=null,
tt.noExcellenceEquipList=null,tt.isEquipBaseSort=null,tt.ins=null,tt.__StaticInit()},71143:(t,e,i)=>{i.d(e,{i:()=>A})
var s=i(38836),n=i(86133),l=i(98800),a=i(38935),o=i(98130),r=i(85602),h=i(38962),d=i(84485),c=i(21554),_=i(63076),u=i(75363),I=i(59918),m=i(77477),g=i(87923),p=i(72835),C=i(44498),S=i(59844),f=i(65550),T=i(35042),y=i(95097)
class A{GetEquipComposeTarget(t){return 0}IsSomeOneTakeOn(t,e,i,s,n){if(null==e||null==e.cfgData_get())return!1
if(A.IsTimeOut(e.serverData_get()))return!1
null==t&&(t=l.Y.Inst.PrimaryRoleInfo_get())
const a=l.Y.Inst.primaryRoleInfoList,o=new r.Z
let h=a.count,d=null,c=0,_=!1
for(A.addEnoughPointRInfo=null;c<h;){const t=a[c]
if(A.IsTakeOnSex(t,e,s)){_=!0
const l=A.GuardAwakeJudged(t,e,i,s,n)
null==l?A.IsAttrCanTakeOnTips(t,e,!1,!0,!1,!0)&&o.Add(t):null==d&&(d=l)}c+=1}if(!_)return!1
if(null!=d)return A.GuardAwakeTip(d),!1
const u=o.count
if(0==u)for(c=0;c<h;){null!=a[c]&&o.Add(a[c]),c+=1}for(c=0,h=o.count;c<h;){const t=o[c]
A.IsTakeOnPro(t.Job_get(),e.cfgData_get().Jobs_get(),!1)?c+=1:(o.Remove(t),h-=1)}if(0==h)return A.IsTakeOnPro(t.Job_get(),e.cfgData_get().Jobs_get(),!0),!1
for(t=o[0],c=0;c<h;){const t=o[c]
A.IsTakeOnLevel(t.Level_get(),e.cfgData_get().level,!1)?c+=1:(o.Remove(t),h-=1)}if(h=o.count,0==h)return A.IsTakeOnLevel(t.Level_get(),e.cfgData_get().Jobs_get(),!0),!1
if(0==u)return null!=A.addEnoughPointRInfo?(t=A.addEnoughPointRInfo,A.addEnoughPointRInfo=null,A.CheckEquipBaseAtrrFixTips(e,t)):A.CheckEquipBaseAtrrFixTips(e,o[0]),!1
for(A.ClearCacheData(),c=0;c<h;){const t=o[c]
A.CheckPosIsFix(t,e,i,s,n)?c+=1:(o.Remove(t),h-=1)}return h=o.count,0==h?null!=A.equipPosRes?(A.ShowUnLockAlert(A.equipPosRes),!1):(-1!=A.targetColumnsCache&&(A.handler=i,
A.nextLockColumnAndPos=A.nextLockColumnAndPosCache,A.targetColumns=A.targetColumnsCache,A.equipColumnAndPos=A.equipColumnAndPos,A.equipOnHandler=null,A.equipOnHandler=i,
A.rInfo=A.rInfoCache,-2==A.nextLockColumnAndPosCache?A.CheckSameSmeltIsMax(A.targetColumns):A.CheckComposeGroup(A.targetColumns)),!1):(A.rInfo=o[0],
A.equipColumnAndPos=A.selfEquipColumnAndPos,e.cfgData_get().playerIdx=A.rInfo.createIdx,!0)}static ClearCacheData(){A.equipPosRes=null,A.equipColumnAndPosCache=-1,
A.targetColumnsCache=-1,A.nextLockColumnAndPosCache=-1,A.targetIsTakeOnCache=!1,A.handler=null,A.rInfoCache=null,A.selfEquipColumnAndPosChache=null}static CheckPosIsFix(t,e,i,s,n){
let l=!1
const a=t.GetWearEquipByColumnAndPos(A.GetSelfEquipColumn(),A.GetSelfEquipPos())
null!=a&&a.GetEquipRes().guardType==e.cfgEquipData_get().guardType&&e.cfgEquipData_get().guardType>0&&(l=!0)
const o=A.CurSelectTabIsTakeOn(e,t,l)
return!o&&0!=A.selfEquipColumnAndPos&&A.IsAttrCanTakeOnTips(t,e,!1)?(A.targetColumn=A.GetSelfEquipColumn(),A.targetIsTakeOn=A.TargetTabIsTakeOn(e,t,1,l),
A.nextLockColumnAndPos=A.GetNextLockTakeOnPos(t,e,l),A.equipColumnAndPos=A.selfEquipColumnAndPos,A.equipOnHandler=null,A.equipOnHandler=i,A.rInfo=t,
-1==A.nextLockColumnAndPosCache&&(A.equipColumnAndPosCache=A.equipColumnAndPos,A.targetColumnsCache=A.targetColumns,A.nextLockColumnAndPosCache=A.nextLockColumnAndPos,
A.targetIsTakeOnCache=A.targetIsTakeOn,
A.rInfoCache=A.rInfo),!1):c.J.Inst_get().BagEquipIsShow()&&o&&0!=A.selfEquipColumnAndPos&&A.IsAttrCanTakeOnTips(t,e,!1)?(A.targetColumn=A.GetSelfEquipColumn(),
A.equipColumnAndPos=A.selfEquipColumnAndPos,-2!=A.nextLockColumnAndPosCache&&(A.equipColumnAndPosCache=A.equipColumnAndPos,A.targetColumnsCache=A.targetColumns,
A.nextLockColumnAndPosCache=-2,A.rInfoCache=A.rInfo),!1):0==A.selfEquipColumnAndPos?(A.equipPosRes=equipPosRes,
!1):(null==A.selfEquipColumnAndPosChache&&(A.selfEquipColumnAndPosChache=A.selfEquipColumnAndPos),!0)}static GuardAwakeJudged(t,e,i,s,n){if(!A.isGuardAwakeJudged){
const[l,a]=ComposeresourceCfgManager.Inst().GetGuardAwakeTipId(e.cfgData_get())
if(l>0){A.isGuardAwakeJudged=!0
const o=new TakenOnParam(t,e,i,s,n)
return o.targetId=l,o.resultObj=a,o}}return null}CheckAllTakeOn(t){const e=l.Y.Inst.primaryRoleInfoList,i=e.count
let s=0
for(A.addEnoughPointRInfo=null;s<i;){const i=e[s]
if(A.IsTakeOn(i,t,null,!1,!1))return!0
s+=1}return!1}IsBetterEquipToWear(t,e,i){const s=t.modelId,n=ItemCfgManager.Inst().getItemById(s)
if(!A.IsTakeOnPro(i.Job_get(),n.Jobs_get(),!1))return 0
if(!A.IsTakeOnLevel(i.Level_get(),n.level,!1))return 0
if(EquipHelper.IsTimeOut(t))return 0
const l=new _.M(t.modelId,t)
return A.EquipCompareScoreUp(i,l,!1)}CheckAllScoreUp(t){const e=l.Y.Inst.primaryRoleInfoList,i=e.count
let s=0
for(A.addEnoughPointRInfo=null;s<i;){const i=e[s]
if(A.IsBetterEquipToWear(t,!0,i)>0)return!0
s+=1}return!1}static IsTakeOn(t,e,i,s,n,l){
return!!A.IsTakeOnByProLevelSex(t,e,i,s,n)&&((e.equipRes_get().equipType==I.R.GUARD||!A.IsTimeOut(e.serverData_get()))&&A.DoIsTakeOn(t,e,i,s,n,l))}
static IsTakeOnByProLevelSex(t,e,i,s,n){return null==n&&(n=!0),null==s&&(s=!0),s&&c.J.Inst_get().CloseTipView(),A.selfEquipColumnAndPos=0,A.curData=e,
null!=e&&null!=e.cfgData_get()&&null!=t&&(!!A.IsTakeOnPro(t.Job_get(),e.cfgData_get().Jobs_get(),s)&&(!!A.IsTakeOnLevel(t.Level_get(),e.cfgData_get().level,s)&&!!A.IsTakeOnSex(t,e,s)))
}IsFixBaseJob(t,e){const i=JobKeyUtil.GetJobBaseValue(t)
for(const[t,n]of(0,s.V5)(e))if(i==JobKeyUtil.GetJobBaseValue(n))return!0
return!1}static GuardAwakeTip(t){A.curData.serverData_get()
const e=new InfoTipVo
e.infoId="EQUIP:GUARD_COMPOSE",e.tipstype=2,e.confirmHandle=A.GotoComposeUI,e.confirmText=(0,n.T)("立即前往"),e.confirmParam=[t.targetId,t.resultObj],
e.cancelHandle=A.OnGuardAwakeCancel,e.cancelParam=t,e.cancelText=(0,n.T)("直接穿戴"),e.showNum=!0,e.replaceParams.Add(A.GetItemNameColor(t.resultObj.awakeCoreMaterialId)),
e.replaceParams.Add(A.GetItemNameColor(t.resultObj.awakeCoreMaterialId)),e.replaceParams.Add(t.resultObj.awakeResultId),
e.replaceParams.Add(A.GetItemNameColor(t.resultObj.awakeResultId)),InfoTipControl.Inst().Open(e)}static OnGuardAwakeCancel(t){
return A.DoIsTakeOn(t.roleInfo,t.baseData,t.handler,t.isShowTip,t.isAttTip)}static DoIsTakeOn(t,e,i,s,n,l){if(A.selfEquipColumnAndPos=A.GetOkEquipColumnPos(t,e),s){
const s=!1,n=A.CurSelectTabIsTakeOn(e,t,s)
if(!n&&0!=A.selfEquipColumnAndPos&&A.IsAttrCanTakeOnTips(t,e,!1))return A.targetColumn=A.GetSelfEquipColumn(),A.targetIsTakeOn=A.TargetTabIsTakeOn(e,t,1,s),
A.nextLockColumnAndPos=A.GetNextLockTakeOnPos(t,e,s),A.equipColumnAndPos=A.selfEquipColumnAndPos,A.equipOnHandler=null,A.equipOnHandler=i,A.rInfo=t,
A.CheckComposeGroup(A.targetColumn),!1
if(c.J.Inst_get().BagEquipIsShow()&&n&&0!=A.selfEquipColumnAndPos&&A.IsAttrCanTakeOnTips(t,e,!1))return A.targetColumn=A.GetSelfEquipColumn(),
A.equipColumnAndPos=A.selfEquipColumnAndPos,A.equipOnHandler=null,A.equipOnHandler=i,A.rInfo=t,A.CheckSameSmeltIsMax(A.targetColumn),!1
A.selfEquipColumnAndPos}return 0!=A.selfEquipColumnAndPos&&(!!A.IsAttrCanTakeOnTips(t,e,s,n,null,null,i,l)&&(A.SendEquipNeedAttrPoint(t,e,s,n),
s&&(A.equipColumnAndPos=A.selfEquipColumnAndPos),!0))}CheckEquipColumn(t){let e="",i=!1
if(A.targetIsTakeOn||0==A.nextLockColumnAndPos)if(e="EQUIP:TIPS_WEAR",i=CommonRemindModel.Inst_get().GetData(CommonRemindModel.Inst_get().GetRolePrefix()+e),
A.targetColumn!=A.rInfo.CurEquipColumn_get())if(i)A.OkChangeEquipTabHandler(t)
else{c.J.Inst_get().CloseTipView()
const i=new InfoTipVo
i.infoId=e,i.replaceParams.Add(""),i.confirmParam=t,i.confirmHandle=A.OkChangeEquipTabHandler,InfoTipControl.Inst().Open(i)}else A.OkChangeEquipTabHandler(t)
else A.nextLockColumnAndPos>0&&(e="EQUIP:UNLOCK_WEAR_DOUBLE",i=CommonRemindModel.Inst_get().GetData(CommonRemindModel.Inst_get().GetRolePrefix()+e),
i?A.OkChangeEquipTabHandler(t):c.J.Inst_get().CloseTipView())}static ShowUnLockAlert(t){c.J.Inst_get().CloseTipView()
const e=EquipPosEnum.GetPosNumByStr(t.positionType)
l.Y.Inst.PrimaryRoleInfo_get().GetEquipmentsByColumn(t.equipColumn),u.Y.Inst_get().GetEquipPosUnLockState(t.equipColumn,e)}OnUnLockAlertHandler(t){}OpenHandle(t){}
static OkChangeEquipTabHandler(t){{
const e=l.Y.Inst.PrimaryRoleInfo_get().Job_get(),i=l.Y.Inst.PrimaryRoleInfo_get().GetWearEquipByColumnAndPos(A.GetSelfEquipColumn(),A.GetSelfEquipPos()),s=A.curData.serverData_get()
if(null!=i&&!i.IsAngelEquip()&&null!=s&&s.IsAngelEquip())return void A.SendCheckStarTransferTabHandler(t)
if(null!=i&&!i.IsMasterEquip()&&null!=s&&s.IsMasterEquip()&&!s.IsGodEquip())return void A.SendCheckMasterCompoundTabHandler(t)
if(null!=i){const s=A.curData.serverData_get()
let l=0,a=0
if(l=C.I.GetSocreValueByEquipment(s,e,!0),a=C.I.GetSocreValueByEquipment(i,e,!0),s.Quality_get()>i.Quality_get())return void A.SendCheckStarTransferTabHandler(t)
if(s.Quality_get()<i.Quality_get()){c.J.Inst_get().CloseTipView()
const e=new CommonTipVo
return e.isShowMask=!0,e.showText=(0,n.T)("要穿戴的装备品质低于当前穿戴的装备，是否替换？"),e.okhandler=A.SendCheckStarTransferTabHandler,e.objparams=t,e.tipstype=2,
void CommonHintController.Inst.OpenView(e)}if(l<a){c.J.Inst_get().CloseTipView()
const e=new CommonTipVo
return e.isShowMask=!0,e.showText=(0,n.T)("要穿戴的装备评分低于当前穿戴的装备，是否替换？"),e.okhandler=A.SendCheckStarTransferTabHandler,e.objparams=t,e.tipstype=2,
void CommonHintController.Inst.OpenView(e)}}A.SendCheckStarTransferTabHandler(t)}}static SendCheckStarTransferTabHandler(t){A.CheckSameSmeltIsMax(t)}
static SendCheckMasterCompoundTabHandler(t){A.CheckSameSmeltIsMax(t)}static CheckSameSmeltIsMax(t){}static CheckComposeGroup(t){
const e=l.Y.Inst.PrimaryRoleInfo_get().GetWearEquipByColumnAndPos(A.GetSelfEquipColumn(),A.GetSelfEquipPos()),i=A.curData.serverData_get()
if(null!=e&&e.modelId!=i.modelId&&i.GetEquipRes().guardType>0){0==A.GetEquipComposeTarget(i.modelId)&&A.CheckEquipColumn(t)}else A.CheckEquipColumn(t)}static GotoComposeUI(t){
const e=t[1],i=ComposeresourceCfgManager.Inst().getItemById(e)
null!=i&&UIJumpTransmitMgr.Inst_get().JumpToRyCompoundPanel(i.composeTabs,e)}OkSendChangeEquipTabHandler(t){}SendChangeEquipTabHandler(t){
null!=A.equipOnHandler&&(A.equipOnHandler(),l.Y.Inst.PrimaryRoleInfo_get().CurEquipColumn_set(o.GF.INT(t)),LuaEventMgr.Inst.RaiseEvent(CommonEventType.BagSelectEquipColumn))}
getNameColor(t){const e=t.GetItemRes()
let i=g.l.getEquipQuality(t,t.GetEquipInfo());-1==i&&(i=e.Quality_get())
g.l.getQualityImgByQuality(i)
const s=EquipmentStarManager.Inst_get().IsEquipHasLucky(t),n=EquipmentStarManager.Inst_get().GetEquipExcellenceCount(t,t.GetEquipInfo()),l=EquipmentStarManager.Inst_get().GetEquipStarLevel(t,t.GetEquipInfo()),a=EquipmentStarManager.Inst_get().GetEquipEnhanceLevel(t,t.GetEquipInfo()),o=EquipmentStarManager.Inst_get().GetEquipSuitProperty(t,t.GetEquipInfo()),r=EquipmentStarManager.Inst_get().IsSpecialRing(t,t.GetEquipInfo()),h=EquipmentStarManager.Inst_get().GetEquipGodType(t,t.GetEquipInfo()),d=ConfigManager.getInstance().GetIntValue("TIPS:MAX_NUM_WORDS"),c=g.l.SetEquipName(t.GetEquipInfo(),e,t,null,!0,!0,0)
let _=c[0]
const u=c[2];(o>0||r)&&StringProxy.Length(u)>d&&(_=StringProxy.ReplaceOne(_,StringProxy.s_SPACE_CHAR,StringProxy.s_NN_CHAR))
const I=`${StringProxy.s_LEFT_M_K_CHAR_DOT}${g.l.getColorStrByQuality(i)}${StringProxy.s_RIGHT_M_K_CHAR_DOT}${_}[-]`
return n>=0&&!r?`${StringProxy.s_LEFT_M_K_CHAR_DOT}${g.l.getColorStrByQuality(g.l.GetEquipQualityColor(n,l,s,a,o,h))}${StringProxy.s_RIGHT_M_K_CHAR_DOT}${_}[-]`:I}
static GetItemNameColor(t){const e=ItemCfgManager.Inst().getItemById(t)
let i=e.name
const s=e.Quality_get()
let n=`${StringProxy.s_LEFT_M_K_CHAR_DOT}${g.l.getColorStrByQuality(s)}${StringProxy.s_RIGHT_M_K_CHAR_DOT}${i}[-]`
if("EQUIPMENT"==e.itemType){const l=EquipCfgManager.Inst().getItemById(t)
let a=null
const o=e.ExcellenceNum,r=e.starExcellence
let h=0
const d=!1,c=0
l.suitId>0&&(a=EquipSuitCfgManager.Inst().getSuitById(l.suitId),h=a.suitProperty)
const _=ConfigManager.getInstance().GetIntValue("TIPS:MAX_NUM_WORDS"),u=g.l.SetEquipNameWithoutServerItem(e,l,!0,!0)
i=u[0]
const I=u[2]
return(h>0||d)&&StringProxy.Length(I)>_&&(i=StringProxy.ReplaceOne(i,StringProxy.s_SPACE_CHAR,StringProxy.s_NN_CHAR)),
n=`${StringProxy.s_LEFT_M_K_CHAR_DOT}${g.l.getColorStrByQuality(s)}${StringProxy.s_RIGHT_M_K_CHAR_DOT}${i}[-]`,
o>=0&&!d?`${StringProxy.s_LEFT_M_K_CHAR_DOT}${g.l.getColorStrByQuality(g.l.GetEquipQualityColor(o,r,!1,0,h,c))}${StringProxy.s_RIGHT_M_K_CHAR_DOT}${i}[-]`:n}return n}
static CurSelectTabIsTakeOn(t,e,i){let s=!1
const n=g.l.getWearPosByPosition(t.cfgEquipData_get().intPosition_get()),l=t.cfgEquipData_get().equipType
if(i)return!1
if(t.cfgEquipData_get().isOkEquipColumn(e.CurEquipColumn_get())){const i=e.GetEquipmentsByColumn(0)
if(s=A.IsMorePosEquip(t,i,l,n),u.Y.Inst_get().IsEquipPosUnlock(e.CurEquipColumn_get(),n)&&null==i.equipmentsGet()[n])return A.selfEquipColumnAndPos=100*e.CurEquipColumn_get()+n,!0
if(s&&u.Y.Inst_get().IsEquipPosUnlock(e.CurEquipColumn_get(),n+1)&&null==i.equipmentsGet()[n+1])return A.selfEquipColumnAndPos=100*e.CurEquipColumn_get()+n+1,!0}return!1}
static TargetTabIsTakeOn(t,e,i,s){let n=!1
const l=g.l.getWearPosByPosition(t.cfgEquipData_get().intPosition_get()),a=t.cfgEquipData_get().equipType
if(s)return!0
if(t.cfgEquipData_get().isOkEquipColumn(i)){const s=e.GetEquipmentsByColumn()
if(n=A.IsMorePosEquip(t,s,a,l),u.Y.Inst_get().IsEquipPosUnlock(i,l)&&null==s.equipmentsGet()[l])return A.selfEquipColumnAndPos=100*i+l,!0
if(n&&u.Y.Inst_get().IsEquipPosUnlock(i,l+1)&&null==s.equipmentsGet()[l+1])return A.selfEquipColumnAndPos=100*i+l+1,!0}return!1}static GetSelfEquipColumn(){
return o.GF.INT(A.selfEquipColumnAndPos/100)}static GetSelfEquipPos(){return A.selfEquipColumnAndPos%100}GetSelfEquipColumnByNum(t){return o.GF.INT(t/100)}GetSelfEquipPosByNum(t){
return t%100}GetEquipColumn(){return A.equipColumnAndPos/100}GetEquipPos(){return A.equipColumnAndPos%100}static GetOkEquipColumnPos(t,e){let i=0
const s=e.cfgEquipData_get().equipType
let n=null,l=0
A.noExcellenceEquipList.Clear()
const a=A.GetAllCanTakeOnPosList(t,e)
if(0!=a.Count()){if(s==I.R.SUB_WEAPON){for(i=0;i<a.Count();){if(l=a[i].GetColumn(),n=t.GetEquipmentsByColumn(),
(!u.Y.Inst_get().IsEquipPosUnlock(l,0)||null==n.equipmentsGet()[0])&&null==a[i]._equipmentEx)return a[i]._index
i+=1}let e=!1
for(i=0;i<a.Count();)e=!1,l=a[i].GetColumn(),n=t.GetEquipmentsByColumn(),null!=n.equipmentsGet()[0]&&n.equipmentsGet()[0].GetEquipRes().equipType==I.R.DOUBLE_WEAPON&&(e=!0),
e||A.noExcellenceEquipList.Add(a[i]),i+=1
if(0==A.noExcellenceEquipList.Count())return A.isEquipBaseSort=!1,a.Sort(A.EquipScoreSort),a[0]._index
for(a.Clear(),i=0;i<A.noExcellenceEquipList.Count();)a.Add(A.noExcellenceEquipList[i]),i+=1
A.noExcellenceEquipList.Clear()}else if(s==I.R.SUB_WEAPON)for(i=0;i<a.Count();){if(l=a[i].GetColumn(),n=t.AllStageEquipments_get()[l],
(!u.Y.Inst_get().IsEquipPosUnlock(l,1)||null==n.equipmentsGet()[1])&&null==a[i]._equipmentEx)return a[i]._index
i+=1}if(0!=a.Count()){for(i=0;i<a.Count();){if(null==a[i]._equipmentEx)return a[i]._index
i+=1}
for(A.noExcellenceEquipList.Clear(),i=0;i<a.Count();)0==a[i]._equipmentEx.suitId&&0==a[i]._equipmentEx.masterId&&0==C.I.GetExeAttrsNum(a[i]._equipmentEx)&&A.noExcellenceEquipList.Add(a[i]),
i+=1
if(0==A.noExcellenceEquipList.Count()){if(A.isEquipBaseSort=!0,a.Sort(A.EquipScoreSort),2==a.Count()&&c.J.getInstance().compareItemData){const t=c.J.getInstance().compareItemData
for(i=0;i<a.Count();){a[i]
if(t.serverData_get().id==a[i]._equipmentEx.id)return a[i]._index
i+=1}}return a[0]._index}return A.isEquipBaseSort=!1,A.noExcellenceEquipList.Sort(A.EquipScoreSort),A.noExcellenceEquipList[0]._index}}return r.Z.Recyle(a),0}
static GetAllCanTakeOnPosList(t,e,i){const s=new r.Z,n=g.l.getWearPosByPosition(e.cfgEquipData_get().intPosition_get()),l=e.cfgEquipData_get().equipType
let a=null,o=!1
return a=t.GetEquipmentsByColumn(),o=A.IsMorePosEquip(e,a,l,n),s.Add(new y.S(100+n,a.equipmentsGet()[n])),o&&s.Add(new y.S(100+n+1,a.equipmentsGet()[n+1])),s}
static GetNextLockTakeOnPos(t,e,i){return 0}GetNextLockTakeOnPos2(t,e,i){const s=e.cfgEquipData_get().equipColumnsList_get()
let n=0
const l=e.cfgEquipData_get().equipType,a=g.l.getWearPosByPosition(e.cfgEquipData_get().intPosition_get())
let o=0
for(;o<s.Count();){let t=!1,e=0
for(;e<i.Count();){if(l==I.R.SINGLE_WEAPON||l==I.R.RINGS){if(s[o]==i[e].GetColumn()&&u.Y.Inst_get().IsEquipPosUnlock(s[o],a)&&u.Y.Inst_get().IsEquipPosUnlock(s[o],a+1)){t=!0
break}}else if(s[o]==i[e].GetColumn()){t=!0
break}e+=1}if(!t){n=100*s[o]+a,l!=I.R.SINGLE_WEAPON&&l!=I.R.RINGS||u.Y.Inst_get().IsEquipPosUnlock(s[o],a)&&!u.Y.Inst_get().IsEquipPosUnlock(s[o],a+1)&&(n=100*s[o]+a+1)
break}o+=1}return r.Z.Recyle(i),n}static GetAllNoOpen(t,e){const i=g.l.getWearPosByPosition(e.cfgEquipData_get().intPosition_get()),s=e.cfgEquipData_get().equipColumnsList_get()
let n=0
for(n=0;n<s.Count();){if(t.AllStageEquipments_get().LuaDic_ContainsKey(s[n])&&u.Y.Inst_get().IsEquipPosUnlock(s[n],i,l.Y.Inst.PrimaryRoleInfo_get()))return!1
n+=1}return!0}static IsMorePosEquip(t,e,i,s){let n=!1
return i==I.R.RINGS?n=!0:i==I.R.SINGLE_WEAPON&&(n=!0,null!=e.equipmentsGet()[s]&&(n=e.equipmentsGet()[s].GetEquipRes().equipType!=I.R.DOUBLE_WEAPON)),n}static EquipScoreSort(t,e){
let i=0,s=0
const n=l.Y.Inst.PrimaryRoleInfo_get().Job_get()
return A.isEquipBaseSort?(i=C.I.GetSocreValueByEquipment(t._equipmentEx,n,!0),s=C.I.GetSocreValueByEquipment(e._equipmentEx,n,!0)):(i=C.I.GetSocreValueByEquipment(t._equipmentEx,n,!1),
s=C.I.GetSocreValueByEquipment(e._equipmentEx,n,!1)),t._equipmentEx.IsMasterEquip()&&(i+=1e8),e._equipmentEx.IsMasterEquip()&&(s+=1e8),
i>s?1:i<s?-1:t._index>e._index?1:t._index<e._index?-1:0}GetUpScoreForRole(){}CheckColumnCanTakeEquip(t,e){e.cfgEquipData_get().equipColumnsList_get()
const i=A.GetAllCanTakeOnPosList(t,e)
let s=null,n=null,l=0
const a=t.Job_get()
if(i.Count()>0){let t=0
for(;t<i.Count();){if(null==i[t]._equipmentEx)(null==s||i[t]._index<s._index)&&(s=i[t])
else{const s=e.serverData_get()
if(A.showRecommendIconByTwoData(s,i[t]._equipmentEx)){const s=C.I.Score(e,a)
null==n?(n=i[t],l=s):s<l&&(n=i[t])}}t+=1}}return null!=s?s.GetColumn():null!=n?n.GetColumn():-1}static showRecommendIconByTwoData(t,e){
if(null==t||null==e)return Debuger.LogError((0,n.T)("传入比较的装备不能为空")),!1
const i=t.Quality_get(),s=e.Quality_get()
if(i!=s)return i>s
if(t.IsMasterEquip()&&!e.IsMasterEquip()&&t.GetEquipRes().equipType==e.GetEquipRes().equipType&&t.GetEquipRes().jobBranch==e.GetEquipRes().jobBranch)return!0
const a=l.Y.Inst.PrimaryRoleInfo_get().Job_get(),o=C.I.GetSocreValueByEquipment(t,a,!1),r=C.I.GetSocreValueByEquipment(t,a,!0),h=C.I.GetSocreValueByEquipment(e,a,!1),d=C.I.GetSocreValueByEquipment(e,a,!0)
return A.IsExcllentEquip(t)&&A.IsExcllentEquip(e)?t.GetEquipRes().equipType==I.R.SINGLE_WEAPON&&e.GetEquipRes().equipType==I.R.DOUBLE_WEAPON?r>=d:r>d:t.GetEquipRes().equipType==I.R.SINGLE_WEAPON&&e.GetEquipRes().equipType==I.R.DOUBLE_WEAPON?o>=h:o>h
}static IsExcllentEquip(t){return null!=t&&null!=t.exellectAttrs&&null!=t.exellectAttrs.attributes&&0!=t.exellectAttrs.attributes.Count()}static EquipScoreCompare(t,e,i){
null==i&&(i=!0)
let s=0
const n=A.GetAllCanTakeOnPosList(t,e,i)
if(0!=n.Count()){for(s=0;s<n.Count();){if(null==n[s]._equipmentEx)return 1
s+=1}for(s=0;s<n.Count();){const t=e.serverData_get()
if(A.showRecommendIconByTwoData(t,n[s]._equipmentEx))return 1
s+=1}}return A.GetAllNoOpen(t,e)?1:-1}IsEquipBetter(t,e,i){null==i&&(i=!0)
let s=0
const n=A.GetAllCanTakeOnPosList(t,e,i)
if(0!=n.Count()){for(s=0;s<n.Count();){if(null==n[s]._equipmentEx)return!0
s+=1}for(s=0;s<n.Count();){const t=e.serverData_get()
if(A.showRecommendIconByTwoData(t,n[s]._equipmentEx))return!0
s+=1}}return!1}static EquipCompareScoreUp(t,e,i){null==i&&(i=!0)
let s=0
const n=A.GetAllCanTakeOnPosList(t,e,i)
if(0!=n.Count()){e.serverData_get()
const i=C.I.Score(e,t.Job_get())
let l=0
for(;l<n.Count();){if(null==n[l]._equipmentEx)return i
const e=i-C.I.GetEquipmentScoreValue(n[l]._equipmentEx,t.Job_get())
e>s&&(s=e),l+=1}}return s}static EquipScoreCompareByScore(t,e,i,s){null==s&&(s=!0)
let n=0
const l=A.GetAllCanTakeOnPosList(t,e,s)
if(0!=l.Count()){for(n=0;n<l.Count();){if(null==l[n]._equipmentEx)return 1
n+=1}for(n=0;n<l.Count();){if(i>C.I.GetEquipmentScoreValue(l[n]._equipmentEx,t.Job_get()))return 1
n+=1}}return A.GetAllNoOpen(t,e)?1:-1}static CanUseForTargetJob(t,e){if(0==e)return!0
let i=!1
const s=o.GF.INT(t/1e3),n=(o.GF.INT(t/10%100),t%10),l=o.GF.INT(e/1e3),a=(o.GF.INT(e/10%10),e%10)
return s==l?0!=n&&0!=a&&a!=n||(i=!0):i=!1,i}GetCanUsePlayerInfoByJob(t){if(null==t)return null
for(let e=0;e<=l.Y.Inst.primaryRoleInfoList.Count()-1;e++){const i=l.Y.Inst.primaryRoleInfoList[e]
if(A.IsTakeOnPro(i.Job_get(),t.cfgData_get().Jobs_get(),!1)&&A.IsTakeOnLevel(i.Level_get(),t.cfgData_get().level,!1))return i}return null}static GetCanUsePlayerInfoByOnlyJob(t){
if(null==t)return null
for(let e=0;e<=l.Y.Inst.primaryRoleInfoList.Count()-1;e++){const i=l.Y.Inst.primaryRoleInfoList[e]
if(A.IsTakeOnPro(i.Job_get(),t.cfgData_get().Jobs_get(),!1))return i}return null}static HadTargetJobRole(t){for(let e=0;e<=l.Y.Inst.primaryRoleInfoList.Count()-1;e++){
const i=l.Y.Inst.primaryRoleInfoList[e]
if(p.V.Inst_get().JobRelationDict[i.Job_get()].Contains(t))return!0}return!1}HadTargetJobsRole(t){for(const[e,i]of(0,s.V5)(t))if(this.HadTargetJobRole(i))return!0
return!1}static IsTakeOnPro(t,e,i){if(null==i&&(i=!0),null==e||0==e.Count())return!0
let s=!1,n=0
for(;n<e.Count();){if(p.V.Inst_get().JobRelationDict[t].Contains(e[n])){s=!0
break}n+=1}return!!s||(i&&f.y.inst.ClientSysMessage(T.X.Unconformity_Pro),!1)}static IsTakeOnLevel(t,e,i){return null==i&&(i=!0),
!(t<e)||(i&&f.y.inst.ClientSysMessage(T.X.Unconformity_Level),!1)}static IsTakeOnSex(t,e,i){if(null==i&&(i=!0),null==e.cfgEquipData_get())return!1
const s=e.cfgEquipData_get().sex
return 0==s||s==t.Sex_get()||(i&&f.y.inst.ClientSysMessage(T.X.Unconformity_Sex),!1)}static IsTimeOut(t){if(null==t.deprecatedTime||0==t.deprecatedTime.ToNum())return!1
let e=t.deprecatedTime.ToNum()/1e3-LuaGlobal.serverTime_get()
return e=MathEx.CeilToInt(e),e<=0}static GetEquipAttrLimit(t){const e=new r.Z([0,0,0,0])
return e[0]+=t.cfgEquipData_get().strengthLimit,e[1]+=t.cfgEquipData_get().vitalityLimit,e[2]+=t.cfgEquipData_get().intelligenceLimit,e[3]+=t.cfgEquipData_get().agilityLimit,e}
static GetEquipAttrDiff(t,e,i=null){null==i&&(i=!1)
const s=new r.Z([0,0,0,0])
if(i){const i=d.X.Inst_get()
s[0]=o.GF.INT(A.IsTakeOnAtr(t.Attributes_get()[o.GF.INT(m.Z.Strength)]+i.strengthAddPoint,e[0])),
s[1]=o.GF.INT(A.IsTakeOnAtr(t.Attributes_get()[o.GF.INT(m.Z.Vitality)]+i.vitalityAddPoint,e[1])),
s[2]=o.GF.INT(A.IsTakeOnAtr(t.Attributes_get()[o.GF.INT(m.Z.Intelligence)]+i.intelligenceAddPoint,e[2])),
s[3]=o.GF.INT(A.IsTakeOnAtr(t.Attributes_get()[o.GF.INT(m.Z.Agility)]+i.agilityAddoint,e[3]))}else s[0]=o.GF.INT(A.IsTakeOnAtr(t.Attributes_get()[o.GF.INT(m.Z.Strength)],e[0])),
s[1]=o.GF.INT(A.IsTakeOnAtr(t.Attributes_get()[o.GF.INT(m.Z.Vitality)],e[1])),s[2]=o.GF.INT(A.IsTakeOnAtr(t.Attributes_get()[o.GF.INT(m.Z.Intelligence)],e[2])),
s[3]=o.GF.INT(A.IsTakeOnAtr(t.Attributes_get()[o.GF.INT(m.Z.Agility)],e[3]))
return s}static GetEquipAttrTotalDiff(t,e,i){null==i&&(i=!1)
const s=A.GetEquipAttrLimit(e),n=A.GetEquipAttrDiff(t,s,i),l=n[0]+n[1]+n[2]+n[3]
return r.Z.Recyle(n),r.Z.Recyle(s),l}CanTakeOnByAllotAttr(t,e){return 0==A.GetEquipAttrTotalDiff(t,e,!0)}static CanTakeOnByRemainPoint(t,e){const i=A.GetEquipAttrTotalDiff(t,e,!1)
return t.RemainBasePoint_get()>=i}IsAttrCanTakeOn(t,e,i){null==i&&(i=!0)
const s=A.GetEquipAttrLimit(e),l=s[0],a=s[1],o=s[2],h=s[3]
if(0==l&&0==a&&0==o&&0==h)return r.Z.Recyle(s),!0
const _=A.GetEquipAttrDiff(t,s),u=_[0],I=_[1],g=_[2],p=_[3]
r.Z.Recyle(_),r.Z.Recyle(s)
const C=u+I+g+p
if(0==C)return!0
const S=d.X.Inst_get()
if(i){if(C>t.RemainBasePoint_get())return u>0?f.y.inst.ClientStrMsg(eSystemPosEnum.SystemTipMessage,(0,
n.T)("力量属性不足，无法穿戴该装备")):I>0?f.y.inst.ClientStrMsg(eSystemPosEnum.SystemTipMessage,(0,n.T)("体力属性不足，无法穿戴该装备")):g>0?f.y.inst.ClientStrMsg(eSystemPosEnum.SystemTipMessage,(0,
n.T)("智力属性不足，无法穿戴该装备")):p>0&&f.y.inst.ClientStrMsg(eSystemPosEnum.SystemTipMessage,(0,n.T)("敏捷属性不足，无法穿戴该装备")),!1
let e=!0,i=""
if(t.getAttribute(m.Z.Strength)+S.strengthAddPoint<l&&(i+=(0,n.T)("，力量"),e=!1),t.getAttribute(m.Z.Agility)+S.agilityAddoint<h&&(i+=(0,n.T)("，敏捷"),e=!1),
t.getAttribute(m.Z.Vitality)+S.vitalityAddPoint<a&&(i+=(0,n.T)("，体力"),e=!1),t.getAttribute(m.Z.Intelligence)+S.intelligenceAddPoint<o&&(i+=(0,n.T)("，智力"),e=!1),!e){const t=(0,
n.T)("无法穿戴该装备")+(i+(0,n.T)("为不足的属性"))
return f.y.inst.ClientStrMsg(eSystemPosEnum.SystemTipMessage,t),AddPointTipControl.Inst_get().PlayGuideAllotEff(),!1}
const s=new r.Z([S.strengthAddPoint,S.agilityAddoint,S.vitalityAddPoint,S.intelligenceAddPoint])
return A.SendAddAttr(s),c.J.Inst_get().CloseTipView(),!0}return!1}static SendEquipNeedAttrPoint(t,e,i,s){null==s&&(s=!0),null==i&&(i=!0)
const n=A.GetEquipAttrLimit(e)
if(0==n[0]&&0==n[1]&&0==n[2]&&0==n[3])return
const l=A.GetEquipAttrDiff(t,n),a=l[0]+l[1]+l[2]+l[3]
if(r.Z.Recyle(l),r.Z.Recyle(n),0!=a&&i&&s){const t=d.X.Inst_get(),e=new r.Z([t.strengthAddPoint,t.agilityAddoint,t.vitalityAddPoint,t.intelligenceAddPoint])
A.SendAddAttr(e),c.J.Inst_get().CloseTipView()}}static IsAttrCanTakeOnTips(t,e,i,s,n,l,a,o){null==s&&(s=!0),null==i&&(i=!0),null==n&&(n=!1),null==l&&(l=!1)
const h=A.GetEquipAttrLimit(e),c=h[0],_=h[1],u=h[2],I=h[3]
if(0==c&&0==_&&0==u&&0==I)return r.Z.Recyle(h),!0
const m=A.GetEquipAttrDiff(t,h),g=m[0],p=m[1],C=m[2],S=m[3]
r.Z.Recyle(m),r.Z.Recyle(h)
const f=g+p+C+S
if(0==f)return!0
d.X.Inst_get()
if(s||n){if(f>t.RemainBasePoint_get())return i&&A.CheckEquipBaseAtrrFixTips(e,t),!1
i&&s&&A.CheckEquipBaseAtrrFixTips(e,t,null,null,a,o),l&&null==A.addEnoughPointRInfo&&(A.addEnoughPointRInfo=t)}return!(!n||f>t.RemainBasePoint_get())}GetFourAttrs(t){
const e=EquipCfgManager.Inst().getItemById(t),i=new r.Z(4)
return i[0]=e.strengthLimit,i[1]=e.agilityLimit,i[2]=e.vitalityLimit,i[3]=e.intelligenceLimit,i}static SendAddAttr(t,e){if(null!=t){const i=new S.z
i.playerId=e,i.attrToPoint=new h.X,i.attrToPoint.declareKeyNumber(),i.attrToPoint.LuaDic_AddOrSetItem(o.GF.INT(m.Z.Strength),t[0]),
i.attrToPoint.LuaDic_AddOrSetItem(o.GF.INT(m.Z.Agility),t[1]),i.attrToPoint.LuaDic_AddOrSetItem(o.GF.INT(m.Z.Vitality),t[2]),
i.attrToPoint.LuaDic_AddOrSetItem(o.GF.INT(m.Z.Intelligence),t[3]),a.C.Inst.F_SendMsg(i)}}static IsTakeOnAtr(t,e){return t>=e?0:e-t}static IsPackNum(t){
return!(t<=0)||(f.y.inst.ClientSysMessage(T.X.UnNumPack),!1)}static CheckEquipBaseAtrrFixTips(t,e,i,s,l,a){let h=""
null==s&&(s=!0),null==i&&(i=!0)
new r.Z
const d=t.serverData_get(),_=t.cfgEquipData_get(),u=t.cfgData_get(),I="[FFEFE1]",p="[FB2704]"
if(null!=u&&(u.itemType==ItemType.EQUIPJEWEL||u.itemType==ItemType.EQUIPJEWELSMELT))return h
u.Conditions_get().typevalues
const C=new r.Z([(0,n.T)("力量要求 "),(0,n.T)("敏捷要求 "),(0,n.T)("体力要求 "),(0,n.T)("智力要求 ")]),S=new r.Z([0,0,0,0])
let f=d.Enhancelevel_get(),T=0,y=0,D=0
const E=t.equipInfo_get()
null!=E&&null!=E.EquipShowConfig_get()&&(f=E.EquipShowConfig_get().enhanceLv,T=E.EquipShowConfig_get().excellenceData.Count()+E.EquipShowConfig_get().randomExcellence.Count(),
y=E.EquipShowConfig_get().suitId,D=0)
const v=new r.Z([_.strengthLimit+S[0],_.agilityLimit+S[1],_.vitalityLimit+S[2],_.intelligenceLimit+S[3]]),w=new r.Z([0,0,0,0]),R=new r.Z(4)
R[0]=o.GF.INT(e.Attributes_get()[o.GF.INT(m.Z.Strength)]),R[1]=o.GF.INT(e.Attributes_get()[o.GF.INT(m.Z.Agility)]),R[2]=o.GF.INT(e.Attributes_get()[o.GF.INT(m.Z.Vitality)]),
R[3]=o.GF.INT(e.Attributes_get()[o.GF.INT(m.Z.Intelligence)])
const P=RecommAddAttrModel.Inst_get().GetRecommAttrValListByRole(1,e)
let O=!0,L=0,B=0,b=!0
for(;L<4;){if(v[L]>0){let t=`${I}${C[L]}[-]`,e=""
R[L]<v[L]?(t+=p,w[L]=v[L]-R[L],B+=w[L],e=p+((0,n.T)(" (还需")+(v[L]-R[L]+(0,n.T)("点)[-]"))),O=!1,P[L]<w[L]&&(b=!1)):t+=I,
t+=`${R[L]}[-]${I}${GameStringProxy.s_F_SLASH_ONE}${v[L]}[-]${e}`,h+=`${t}\n`}L+=1}const M=new InfoTipVo,G=new r.Z
if(G.Add(e),M.infoId="EQUIP:WEAR_ATRRTIP",O||B<=e.RemainBasePoint_get()){const t=ConfigManager.getInstance().GetIntValue("NEW_HAND:ADD_POINT_AND_WEAR")
if(e.Level_get()>t?(M.confirmText=(0,n.T)("点击加点"),h+=`当前剩余属性点数${g.l.greenColorStr}足够[-],是否立即前往分配？`):(h+=`当前剩余属性点数${g.l.greenColorStr}足够[-],是否立即分配并穿戴？`,M.confirmText=(0,
n.T)("立即加点")),M.confirmHandle=A.OnAddAttrHandler,G.Add(w),a){const t=BagModel.Inst_get().GetItemByIndex(a)
G.Add(t)}else l&&G.Add({handler:l})}else{const t=RecommAddAttrModel.Inst_get().GetUpLvByNeedPint(e,B-e.RemainBasePoint_get(),w)
h+=-1==t?"当前职业已无法获得足够的点数，请先转职":-2==t?SystemTipsCfgManager.Inst().getItemById(11020383).sys_messsage:`再升${g.l.greenColorStr}${t}[-]级可以获得足够的点数)`,M.confirmHandle=A.OnAddExpHandler,
M.confirmText=(0,n.T)("确定")}M.replaceParams=new r.Z,M.replaceParams.Add(h),M.confirmParam=G,c.J.Inst_get().CloseTipView(),InfoTipControl.Inst().Open(M)}static OnAddAttrHandler(t){
const e=t[0],i=ConfigManager.getInstance().GetIntValue("NEW_HAND:ADD_POINT_AND_WEAR")
if(e.Level_get()>i)d.X.Inst_get().waitAddPoint=t[1],CharacterTopControl.Inst().OpenByParam(!0,CharacterUIMenu.Normal,CharacterUISubMenu.AddAttrs,e.createIdx)
else{const i=t[2]
if(i)if(i.handler)i.handler()
else{const s=i,n=e.Id_get(),a=l.Y.Inst.GetMultiPlayerInfo(n)
A.CurSelectTabIsTakeOn(s.baseData_get(),a,!1),A.equipColumnAndPos=A.selfEquipColumnAndPos
const o=A.GetEquipPos(),r=s.serverData_get()
if(null!=a.GetEquipmentByPos(o)){A.SendAddAttr(t[1],n)
const[e,i]=a.GetEquipmentColAndPosById(r.id)
return void c.J.Inst_get().OpenEquipTipsInBagByRInfo(r.id,a,e)}d.X.Inst_get().strengthAddPoint=t[1][0],d.X.Inst_get().agilityAddoint=t[1][1],
d.X.Inst_get().vitalityAddPoint=t[1][2],d.X.Inst_get().intelligenceAddPoint=t[1][3],BagModel.Inst_get().CloneSelectItemData(i,!0),c.J.Inst_get().RequestAddPointAndTakeOn(n)}}}
static OnAddExpHandler(t){BecomeStrongerMainControl.Inst_get().Open(StrongerTabType.EXP)}IsEquipedOn(t,e){const i=new r.Z
if(i.Add(!1),i.Add(-1),null!=e&&null!=e.id&&null!=t)for(const[n,l]of(0,s.vy)(t.AllStageEquipments_get())){const s=t.AllStageEquipments_get()[n]
if(null!=s&&null!=s.equipmentsGet()){let t=0
for(;t<s.equipmentsGet().Count();){if(null!=s.equipmentsGet()[t]&&s.equipmentsGet()[t].id.Equal(e.id)){i[0]=!0,i[1]=n
break}t+=1}}}return i}}A.selfEquipColumnAndPos=0,A.equipOnHandler=null,A.curData=null,A.equipColumnAndPos=0,A.targetColumn=0,A.targetIsTakeOn=!1,A.nextLockColumnAndPos=0,
A.addEnoughPointRInfo=null,A.equipColumnAndPosCache=-1,A.targetColumnsCache=-1,A.nextLockColumnAndPosCache=-1,A.targetIsTakeOnCache=!1,A.rInfoCache=null,
A.selfEquipColumnAndPosChache=null,A.rInfo=null,A.equipPosRes=null,A.composeGroupDict=null,A.composeMap=null,A.CurEquipColumn=0,A.starTransferdata=null,A.isEquipBaseSort=!0,
A.noExcellenceEquipList=new r.Z,A.handler=null,A.targetColumns=null,A.isGuardAwakeJudged=null},97331:(t,e,i)=>{i.d(e,{n:()=>T})
var s=i(86133),n=i(11210),l=i(98800),a=i(61033),o=i(62370),r=i(5494),h=i(35128),d=i(98885),c=i(85602),_=i(38962),u=i(77477),I=i(75439),m=i(10509),g=i(77191),p=i(35259),C=i(58158),S=i(23628),f=i(26778)
class T{constructor(){this.notAddPointLevel=0,this.jobTypeDic=null,this.curSelectType=0,this.recommList=null,this.showRecommLevel=0,this.recommList=new c.Z([0,0,0,0])}
static Inst_get(){return null==T.inst&&(T.inst=new T),T.inst}NotAddPointLevel_get(){if(0==this.notAddPointLevel){
const t=I.D.getInstance().getContent("ATTRIBUTE:NOT_ADD_LEVEL").getContent()
this.notAddPointLevel=d.M.String2Int(t.stringVal)}return this.notAddPointLevel}ShowRecommLevel_get(){if(0==this.showRecommLevel){
const t=I.D.getInstance().getContent("ATTRIBUTE:RECOMMEND_UI_LEVEL").getContent()
this.showRecommLevel=d.M.String2Int(t.stringVal)}return this.showRecommLevel}JobTypeDic_Get(){if(null==this.jobTypeDic){this.jobTypeDic=new _.X
const t=I.D.getInstance().getContent("ATTRIBUTE:RECOMMEND_TYPE"),e=d.M.Split(t.getContent().stringVal,d.M.s_CCD_CHAR_DOT)
let i=0
for(;i<e.count;){const t=d.M.Split(e[i],o.o.s_UNDER_CHAR),s=d.M.String2Int(t[0]),n=d.M.String2Int(t[1])
this.jobTypeDic.LuaDic_Add(s,n),i+=1}}return this.jobTypeDic}GetDefaultRecommType(t){return 0}GetRecommAttrValList(t=null){const e=n.i.Inst.GetCurSelect(r.I.CharacterUIPanel)
return this.GetRecommAttrValListByRoleEx(t,e)}GetRecommAttrValListByRoleEx(t,e,i=null,s=null){if(null==i&&(i=e.RemainBasePoint_get()),0==i)return new c.Z([0,0,0,0])
let n
if([n,i]=p.C.INSTANCE.CheckAllSkillNeedAttrPoint(e,i),i<=0)return n
if([n,i]=S.b.GetAllEquipAttrDiff(e,i,n),0==i)return n
const l=this.GetRecommAttrValListByRole(t,e,i,s,n)
if(null!=n)for(let t=0;t<=3;t++)null!=n[t]&&(l[t]=l[t]+n[t])
return l}GetRecommAttrValListByRole(t,e,i,s,n=null){null==i&&(i=e.RemainBasePoint_get()),null==s&&(s=e.Level_get()),s>400&&(s=400)
const l=f.q.Inst().GetItemByLevelAndJob(s,e.Job_get()),a=this.GetStandardAttrValList(t,s,e.Job_get()),r=new c.Z([0,0,0,0]),h=d.M.Split(l.preference,o.o.s_UNDER_CHAR),_=new c.Z([d.M.String2Int(h[0]),d.M.String2Int(h[1]),d.M.String2Int(h[2]),d.M.String2Int(h[3])])
let u=0
for(;u<_.count;){const t=_[u]-1
let s=e.getAttribute(this.GetAttriKey(_[u]))
null!=n&&(s+=n[t]),s>=a[t]?r[t]=0:i>=a[t]-s?r[t]=a[t]-s:r[t]=i,i-=r[t],u+=1}return i>0&&(r[_[0]-1]=r[_[0]-1]+i),r}GetUpLvByNeedPint(t,e,i){let s=-1
const n=I.D.getInstance().GetIntValue("ATTRIBUTE:NOT_ADD_LEVEL"),a=l.Y.Inst.PrimaryRoleInfo_get().Level_get()
let o=!1,r=t.Level_get()
const h=g.g.ins.GetVoByRebirthLevel(0).gtlevelList[1]
if(r>=h)return-2
if(a<=n){let l=!1,a=t.RemainBasePoint_get(),h=null
for(;r+=1,h=m.L.Inst().getItemById(r),a+=h.point,null!=h;){const h=this.GetRecommAttrValListByRole(null,t,a,r)
l=!0
for(let t=0;t<=i.Count()-1;t++)if(i[t]>0&&h[t]<i[t]){l=!1
break}if(l){o=!0
break}if(s==n){e-=a
break}}}return o||(r+=this._CalculationNeedPointLevel(t,e,r)),s=r-t.Level_get(),0==s?-1:s>=h?-2:s}_CalculationNeedPointLevel(t,e,i){let s=0,n=0
for(;;){i+=1
const t=m.L.Inst().getItemById(i)
if(null==t)break
if(s+=t.point,n+=1,e<=s)break}return n}GetAttriKey(t){return 1==t?u.Z.Strength:2==t?u.Z.Agility:3==t?u.Z.Vitality:4==t?u.Z.Intelligence:void 0}GetAttrIdx(t){
return t==u.Z.Strength?0:t==u.Z.Agility?1:t==u.Z.Vitality?2:t==u.Z.Intelligence?3:void 0}GetAttrName(t){return t==u.Z.Strength?(0,s.T)("力量"):t==u.Z.Vitality?(0,
s.T)("体力"):t==u.Z.Agility?(0,s.T)("敏捷"):t==u.Z.Intelligence?(0,s.T)("智力"):""}GetStandardAttrValList(t,e,i){if(null==i){
i=l.Y.Inst.GetMultPlayerInfos()[C.U.Inst_get().curSelectIdx].Job_get()}if(0==i)return null
const s=f.q.Inst().GetResListByJobAndType(i),n=a.l.GetInst().GetPlayerInitial(i),o=new c.Z([n.strength,n.agile,n.vitality,n.intelligence])
let r=0
for(;r<s.count;){const t=s[r],n=d.M.SubStringWithLen(t.level,1,t.level.length-2),l=d.M.Split(n,d.M.s_SPAN_CHAR_DOT),a=d.M.String2Int(l[0])
let c=d.M.String2Int(l[1]),_=0
e>=a&&(e<c&&(c=e),_=1!=a?m.L.Inst().GetAllPointByLevelAndJob(a-1,c,i):m.L.Inst().GetAllPointByLevelAndJob(a,c,i)),
0!=_&&(1==t.strengthRoundup?o[0]+=h.p.CeilToInt(_*(t.strengthRatio/1e4)):o[0]+=h.p.FloorToInt(_*(t.strengthRatio/1e4)),
1==t.agilityRoundup?o[1]+=h.p.CeilToInt(_*(t.agilityRatio/1e4)):o[1]+=h.p.FloorToInt(_*(t.agilityRatio/1e4)),
1==t.spRoundup?o[2]+=h.p.CeilToInt(_*(t.spRatio/1e4)):o[2]+=h.p.FloorToInt(_*(t.spRatio/1e4)),
1==t.intelligenceRoundup?o[3]+=h.p.CeilToInt(_*(t.intelligenceRatio/1e4)):o[3]+=h.p.FloorToInt(_*(t.intelligenceRatio/1e4))),r+=1}return o}GetTotalPoint(){
const t=l.Y.Inst.GetMultiPlayerInfoByCreateIdx(0),e=t.getAttribute(u.Z.Strength),i=t.getAttribute(u.Z.Agility),s=t.getAttribute(u.Z.Vitality),n=t.getAttribute(u.Z.Intelligence)
return t.RemainBasePoint_get()+e+i+s+n}}T.inst=null},26778:(t,e,i)=>{i.d(e,{q:()=>h})
var s=i(93984),n=i(38836),l=i(55360),a=i(98885),o=i(85602),r=i(38962)
class h{constructor(){this.rMap=null,this.rMapSortLv=null,this._degf_OnSort=null,this.rMap=new r.X,this.rMapSortLv=new r.X
const t=l.Y.Inst.GetOrCreateCsv(s.h.eRecommAttr)
this.rMap=t.GetCsvMap(),this._degf_OnSort=(t,e)=>this.OnSort(t,e)}static Inst(){return null==h._inst&&(h._inst=new h),h._inst}GetItemById(t){return this.rMap[t]}
GetResListByJobAndType(t){const e=new o.Z
for(const[i,s]of(0,n.V5)(this.rMap))s.job==t&&e.Add(s)
return e}GetItemByLevelAndJob(t,e){t>400&&(t=400)
for(const[i,s]of(0,n.V5)(this.rMap))if(s.job==e){
const e=a.M.SubStringWithLen(s.level,1,s.level.length-2),i=a.M.Split(e,a.M.s_SPAN_CHAR_DOT),n=a.M.String2Int(i[0]),l=a.M.String2Int(i[1])
if(n<=t&&t<=l)return s}return null}OnSort(t,e){
const i=a.M.SubStringWithLen(t.level,1,t.level.length-2),s=a.M.Split(i,a.M.s_SPAN_CHAR_DOT),n=a.M.String2Int(s[0]),l=a.M.SubStringWithLen(e.level,1,e.level.length-2),o=a.M.Split(l,a.M.s_SPAN_CHAR_DOT)
return n>a.M.String2Int(o[0])?1:-1}}h._inst=null},3579:(t,e,i)=>{i.d(e,{W:()=>r})
var s=i(93984),n=i(38836),l=i(55360),a=i(85602),o=i(38962)
class r{constructor(){this.TitleMap=null,this.TitleMap=new o.X
const t=l.Y.Inst.GetOrCreateCsv(s.h.eTitle)
this.TitleMap=t.GetCsvMap()}static Inst(){return null==r._inst&&(r._inst=new r),r._inst}getItemById(t){return this.TitleMap.LuaDic_ContainsKey(t)?this.TitleMap[t]:null}
GetTitleByItemId(t){new a.Z
for(const[e,i]of(0,n.V5)(this.TitleMap))if(10==i.getType&&i.value==t)return i
return null}}r._inst=null},54151:(t,e,i)=>{i.d(e,{Y:()=>p})
var s,n,l,a=i(42292),o=i(71409),r=i(38836),h=i(98800),d=i(85602),c=i(92415),_=i(90099),u=i(14792),I=i(62734),m=i(3579)
function g(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let p=(s=(0,o.GH)(c.k.SM_TitleIdShow),l=class t{constructor(){this.titles=null,this.sortTitles=null,
this.showIdLis=null,this.firstitemid=0,this.titleOwned=null,this.showTitleId=0,this._useAttrTitleId=0,this.isTabChange=!0,this.clickId=0,this.expireList=null,this.specialList=null,
this.expireId=0,this.specialId=null,this.newGetTitleId=-1,this.titleScore=0,this.firstGet=!0,this.sortTitles=new d.Z,this.showIdLis=new d.Z,this.titleOwned=new d.Z,
this.expireList=new d.Z,this.specialList=new d.Z}static Inst_get(){return null==t.inst&&(t.inst=new t),t.inst}GetSortTitles(){const t=m.W.Inst().TitleMap
this.sortTitles.Clear()
for(const[e,i]of(0,r.vy)(t))this.showIdLis.IndexOf(e,0)>=0&&this.sortTitles.Add(t[e])
let e=null,i=0
for(;i<this.sortTitles.Count()-1;){let t=i+1
for(;t<this.sortTitles.Count();)this.titleOwned.IndexOf(this.sortTitles[t].id,0)>=0&&this.titleOwned.IndexOf(this.sortTitles[i].id,0)<0?(e=this.sortTitles[i],
this.sortTitles[i]=this.sortTitles[t],
this.sortTitles[t]=e):this.titleOwned.IndexOf(this.sortTitles[t].id,0)>=0&&this.titleOwned.IndexOf(this.sortTitles[i].id,0)>=0?this.sortTitles[t].sort>this.sortTitles[i].sort&&(e=this.sortTitles[i],
this.sortTitles[i]=this.sortTitles[t],
this.sortTitles[t]=e):this.titleOwned.IndexOf(this.sortTitles[t].id,0)<0&&this.titleOwned.IndexOf(this.sortTitles[i].id,0)<0&&this.sortTitles[t].sort>this.sortTitles[i].sort&&(e=this.sortTitles[i],
this.sortTitles[i]=this.sortTitles[t],this.sortTitles[t]=e),t+=1
i+=1}const s=new d.Z
let n=0
for(;n<this.sortTitles.Count();)s.Add(this.sortTitles[n].id),n+=1
return this.firstitemid=this.sortTitles[0].id,s}Titles_get(){return this.titles}Titles_set(t){this.titles=t
const e=new d.Z
for(const[t,i]of(0,r.V5)(this.titles))e.Add(i.titleId)
this.TitleOwned_set(e)}TitleOwned_get(){return this.titleOwned}TitleOwned_set(t){this.titleOwned=t}useAttrTitleId_get(){return this._useAttrTitleId}useAttrTitleId_set(t){
this._useAttrTitleId=t,I.f.Inst.SetState(u.t.ATTRIBUTE_TITLE,0==this._useAttrTitleId)}ResetData(){this.showTitleId=0,this._useAttrTitleId=0,this.specialId=null,
this.specialList.Clear()}ExpireId_get(){return this.expireId}ExpireId_set(t){this.expireId=t,this.expireList.Add(this.expireId),this.RemoveTitle(this.expireId),
this.expireId==this.showTitleId&&(this.showTitleId=0,h.Y.Inst.PrimaryRoleInfo_get().TitleId_set(0)),this.expireId==this.useAttrTitleId_get()&&this.useAttrTitleId_set(0)}
isContained(t){return!!this.TitleOwned_get().Contains(t)}RefreshTitles(t){for(const[e,i]of(0,r.V5)(this.Titles_get()))if(i.titleId==t.titleId){i.deprecatedTime=t.deprecatedTime
break}}AddTitle(t){const e=new _.D
e.titleId=t.titleId,e.deprecatedTime=t.deprecatedTime
const i=new d.Z
i.Add(e)
for(const[t,e]of(0,r.V5)(this.Titles_get()))i.Add(e)
this.Titles_set(i)}TitleShowIdHandle(t){this.showIdLis=t.showTitles}RemoveTitle(t){if(0!=t&&null!=this.Titles_get()){const e=new d.Z
for(const[i,s]of(0,r.V5)(this.Titles_get()))s.titleId!=t&&e.Add(s)
this.Titles_set(e)}}GetTitleById(t){for(const[e,i]of(0,r.V5)(this.Titles_get()))if(i.titleId==t)return i
return null}},l.inst=null,g(n=l,"Inst_get",[a.Vx],Object.getOwnPropertyDescriptor(n,"Inst_get"),n),
g(n.prototype,"TitleShowIdHandle",[s],Object.getOwnPropertyDescriptor(n.prototype,"TitleShowIdHandle"),n.prototype),n)},75321:(t,e,i)=>{i.d(e,{C:()=>l})
var s=i(86133),n=i(38962)
class l{static __StaticInit(){l.ALL_EQUIP_TYPE_DATA[l.SINGLEWEAPON]=[l.PART_WEAPON_LEFT,(0,s.T)("单手武器"),(0,s.T)("武器")],l.ALL_EQUIP_TYPE_DATA[l.DOUBLEWEAPON]=[l.PART_WEAPON_LEFT,(0,
s.T)("双手武器"),(0,s.T)("武器")],l.ALL_EQUIP_TYPE_DATA[l.MAINWEAPON]=[l.PART_WEAPON_LEFT,(0,s.T)("主手武器"),(0,s.T)("武器")],l.ALL_EQUIP_TYPE_DATA[l.SUBWEAPON]=[l.PART_WEAPON_RIGHT,(0,
s.T)("副手武器"),(0,s.T)("武器")],l.ALL_EQUIP_TYPE_DATA[l.HAT]=[l.PART_HAT,(0,s.T)("头盔"),(0,s.T)("头盔")],l.ALL_EQUIP_TYPE_DATA[l.CLOTHES]=[l.PART_CLOTHES,(0,s.T)("胸甲"),(0,s.T)("胸甲")],
l.ALL_EQUIP_TYPE_DATA[l.GLOVES]=[l.PART_GLOVES,(0,s.T)("护手"),(0,s.T)("护手")],l.ALL_EQUIP_TYPE_DATA[l.PANTS]=[l.PART_PANTS,(0,s.T)("护腿"),(0,s.T)("护腿")],
l.ALL_EQUIP_TYPE_DATA[l.BOOTS]=[l.PART_BOOTS,(0,s.T)("鞋子"),(0,s.T)("鞋子")],l.ALL_EQUIP_TYPE_DATA[l.NECKLACE]=[l.PART_NECKLACE,(0,s.T)("项链"),(0,s.T)("项链")],
l.ALL_EQUIP_TYPE_DATA[l.RINGS]=[l.PART_RINGS_LEFT,(0,s.T)("戒指"),(0,s.T)("戒指")],l.ALL_EQUIP_TYPE_DATA[l.WINGS]=[l.PART_WINGS,(0,s.T)("翅膀"),(0,s.T)("翅膀")],
l.ALL_EQUIP_TYPE_DATA[l.GUARD]=[l.PART_GUARD,(0,s.T)("守护"),(0,s.T)("守护")],l.ALL_EQUIP_TYPE_DATA[l.ASURAFLAG]=[l.PART_ASURAMFLAG,(0,s.T)("战盟旗帜"),(0,s.T)("战盟旗帜")],
l.ALL_EQUIP_TYPE_DATA[l.ANGELWEAPON]=[l.PART_ANGELWEAPON,(0,s.T)("大天使武器"),(0,s.T)("大天使武器")],l.ALL_EQUIP_TYPE_DATA[l.ANGELCLOTHES]=[l.PART_ANGELCLOTHES,(0,s.T)("大天使铠甲"),(0,
s.T)("大天使铠甲")],l.ALL_PART_DATA[l.PART_WEAPON_LEFT]=[l.MAINWEAPON,(0,s.T)("主武器")],l.ALL_PART_DATA[l.PART_WEAPON_RIGHT]=[l.SUBWEAPON,(0,s.T)("副武器")],
l.ALL_PART_DATA[l.PART_HAT]=[l.HAT,(0,s.T)("头盔")],l.ALL_PART_DATA[l.PART_CLOTHES]=[l.CLOTHES,(0,s.T)("胸甲")],l.ALL_PART_DATA[l.PART_GLOVES]=[l.GLOVES,(0,s.T)("护手")],
l.ALL_PART_DATA[l.PART_PANTS]=[l.PANTS,(0,s.T)("护腿")],l.ALL_PART_DATA[l.PART_BOOTS]=[l.BOOTS,(0,s.T)("鞋子")],l.ALL_PART_DATA[l.PART_NECKLACE]=[l.NECKLACE,(0,s.T)("项链")],
l.ALL_PART_DATA[l.PART_RINGS_LEFT]=[l.RINGS,(0,s.T)("戒指")],l.ALL_PART_DATA[l.PART_RINGS_RIGHT]=[l.RINGS,(0,s.T)("戒指")],l.ALL_PART_DATA[l.PART_WINGS]=[l.WINGS,(0,s.T)("翅膀")],
l.ALL_PART_DATA[l.PART_GUARD]=[l.GUARD,(0,s.T)("守护")],l.ALL_PART_DATA[l.PART_ASURAMFLAG]=[l.ASURAFLAG,(0,s.T)("战盟旗帜")],l.ALL_PART_DATA[l.PART_ANGELWEAPON]=[l.ANGELWEAPON,(0,
s.T)("大天使武器")],l.ALL_PART_DATA[l.PART_ANGELCLOTHES]=[l.ANGELCLOTHES,(0,s.T)("大天使铠甲")]}static GetEquipEnum(t){return null==l.equipDefine&&(l.equipDefine=new n.X,
l.SetEquipKey("SINGLEWEAPON",0),l.SetEquipKey("DOUBLEWEAPON",1),l.SetEquipKey("MAINWEAPON",2),l.SetEquipKey("SUBWEAPON",3),l.SetEquipKey("HAT",4),l.SetEquipKey("CLOTHES",5),
l.SetEquipKey("GLOVES",6),l.SetEquipKey("PANTS",7),l.SetEquipKey("BOOTS",8),l.SetEquipKey("NECKLACE",9),l.SetEquipKey("RINGS",10),l.SetEquipKey("WINGS",11),
l.SetEquipKey("GUARD",12),l.SetEquipKey("ASURAMFLAG",13),l.SetEquipKey("ANGELWEAPON",14),l.SetEquipKey("ANGELCLOTHES",15),l.SetEquipKey("ANGEL_MAINWEAPON",2),
l.SetEquipKey("ANGEL_SUBWEAPON",3)),l.equipDefine.LuaDic_ContainsKey(t)?l.equipDefine.LuaDic_GetItem(t):-1}static SetEquipKey(t,e){l.equipDefine.LuaDic_AddOrSetItem(t,e)}}
l.equipDefine=null,l.SINGLEWEAPON=0,l.DOUBLEWEAPON=1,l.MAINWEAPON=2,l.SUBWEAPON=3,l.HAT=4,l.CLOTHES=5,l.GLOVES=6,l.PANTS=7,l.BOOTS=8,l.NECKLACE=9,l.RINGS=10,l.WINGS=11,l.GUARD=12,
l.ASURAFLAG=13,l.ANGELWEAPON=14,l.ANGELCLOTHES=15,l.EQUIP_TYPE_MIN=0,l.EQUIP_TYPE_MAX=15,l.PART_WEAPON_LEFT=0,l.PART_WEAPON_RIGHT=1,l.PART_HAT=2,l.PART_CLOTHES=3,l.PART_GLOVES=4,
l.PART_PANTS=5,l.PART_BOOTS=6,l.PART_NECKLACE=7,l.PART_RINGS_LEFT=8,l.PART_RINGS_RIGHT=9,l.PART_WINGS=10,l.PART_GUARD=11,l.PART_ASURAMFLAG=12,l.PART_ANGELWEAPON=13,
l.PART_ANGELCLOTHES=14,l.PART_MIN=0,l.PART_MAX=14,l.ALL_EQUIP_TYPE_DATA={},l.ALL_PART_DATA={},l.__StaticInit()},39745:(t,e,i)=>{i.d(e,{o:()=>p})
var s=i(61033),n=i(35128),l=i(98885),a=i(85602),o=i(38962),r=i(84485),h=i(77477),d=i(33314),c=i(17407),_=i(72835),u=i(17783),I=i(29109),m=i(37151),g=i(55793)
class p{constructor(){this.curAttrIntructionType=g.y.AttrIntruction_First}static Inst_get(){return null==p.inst&&(p.inst=new p),p.inst}Reset(){
this.curAttrIntructionType=g.y.AttrIntruction_First}GetLevelRangeTotalPoint(t,e){_.V.Inst_get().GetJobNode(e)
const i=I.I.GetParents(e),n=new a.Z
for(let t=0;t<=i.Count()-1;t++){const e=i[t]
if(e>0){let t=1
if(d.Z.GetJobTime(e)>0){const i=m.Q.cfg.GetTransVo(e).questCondition
t=u.L.Inst_get().model.GetConfig(i).resource_get().minLevel}n.Add(new a.Z([t,e]))}}let l=0,o=t
n.Sort(((t,e)=>t[0]<e[0]?-1:t[0]>e[0]?1:0))
for(let i=n.Count()-1;i>=0;i+=-1){const a=n[i][0],r=n[i][1]
if(t>=a&&e>=r){const t=o-a
l+=s.l.GetInst().GetPlayerInitial(r).levelOfPoint*t,o=a}}return l+=this.GetBornPoint(e),l}GetBornPoint(t){const e=s.l.GetInst().GetPlayerInitial(t)
return e.strength+e.agile+e.vitality+e.intelligence}GetPointDicByType(t,e,i){const s=new a.Z,n=c.X.Inst().minLevelList
for(let l=0;l<=n.Count()-1;l++)if(t>=n[l][0]){const t=c.X.Inst().GetItemByJobAndType(e,i,n[l][0])
let o=0
o=this.GetLevelRangeTotalPoint(n[l][1],e),s.Add(new a.Z([o,t]))}return s}GetAttrValueByNowTotalPoint(t,e,i,s,n){const a=this.GetPointDicByType(i,s,n),r=new o.X
let d=e
if(0==d){for(let e=0;e<=t.Count()-1;e++)r[t[e]]=[0,0]
return r}for(let i=0;i<=a.Count()-1;i++){const s=a[i][0],n=a[i][1]
if(d>0){let i=0
d-s>=0?(i=s/e,d-=s):(i=d/e,d=0)
for(let e=0;e<=t.Count()-1;e++){const s=t[e]
let a=0,o=0
if(s==h.Z.Attack_Max?(a=l.M.String2Double(n.attack_Min),o=l.M.String2Double(n.attack_Max)):s==h.Z.AttackSpeed?(a=l.M.String2Double(n.attackSpeed1),
o=l.M.String2Double(n.attackSpeed2)):s==h.Z.SkillAdd?(a=l.M.String2Double(n.skillAdd1),o=l.M.String2Double(n.skillAdd2)):s==h.Z.SkillDamageDown?(a=l.M.String2Double(n.skillDown1),
o=l.M.String2Double(n.skillDown2)):s==h.Z.hitFix?(a=l.M.String2Double(n.hitFix1),
o=l.M.String2Double(n.hitFix2)):s==h.Z.Defense?a=l.M.String2Double(n.defense):s==h.Z.DodgeRate?a=l.M.String2Double(n.dodgeRate):s==h.Z.HitRate?a=l.M.String2Double(n.hitRate):s==h.Z.MaxHp&&(a=l.M.String2Double(n.maxHp)),
r.LuaDic_ContainsKey(s)){const t=r[s]
r[s]=[a*i+t[1],o*i+t[2]]}else r[s]=[a*i,o*i]}}}return r}GetValByattrTypeAndRate(t,e,i,s,l,a){let o="",d=0,c=0,_=0,u=0,I=!1
const m="[047104]"
return e==h.Z.Attack_Max?(d=n.p.FloorToInt(l*s),c=n.p.FloorToInt(a*s),_=n.p.FloorToInt((s+i)*l)-d,u=n.p.FloorToInt((s+i)*a)-c,o=0==_?`${d}`:`${d} +${m}${_}[-]`,
o+=0==u?`-${c}`:`-${c} +${m}${u}[-]`):(e==h.Z.AttackSpeed?(d=n.p.RoundToInt((s*l)**a),_=n.p.RoundToInt(((s+i)*l)**a)-d):e==h.Z.SkillAdd?(d=n.p.FloorToInt((s*l)**a)/100,
_=n.p.FloorToInt(((s+i)*l)**a)/100-d,I=!0):e==h.Z.SkillDamageDown||e==h.Z.hitFix?(d=n.p.FloorToInt((s*l)**a)/100,d=n.p.Min(d,.8),_=n.p.FloorToInt(((s+i)*l)**a)/100,_=n.p.Min(_,.8),
_-=d,I=!0):e!=h.Z.Defense&&e!=h.Z.DodgeRate&&e!=h.Z.HitRate&&e!=h.Z.MaxHp||(e==h.Z.HitRate&&(s+=t.Attributes_get()[h.Z.Agility],i+=r.X.Inst_get().GetAddPoint(h.Z.Agility)),
d=n.p.FloorToInt(s*l),
_=n.p.FloorToInt((i+s)*l)-d),o=0==_?I?`${n.p.RoundToInt(100*d)}%`:`${n.p.RoundToInt(d)}`:I?`${n.p.RoundToInt(100*d)}% +${m}${n.p.RoundToInt(100*_)}%[-]`:`${n.p.RoundToInt(d)} +${m}${n.p.RoundToInt(_)}[-]`),
o}}p.inst=null},54798:(t,e,i)=>{i.d(e,{N:()=>V})
var s,n=i(18998),l=i(83908),a=i(32076),o=i(11210),r=i(98800),h=i(97960),d=i(97461),c=i(5924),_=i(85682),u=i(31222),I=i(5494),m=i(98130),g=i(98885),p=i(85602),C=i(79534),S=i(84485),f=i(21554),T=i(53905),y=i(92679),A=i(77477),D=i(74045),E=i(49067),v=i(87923),w=i(65772),R=i(37648),P=i(55492),O=i(75439),L=i(41864),B=i(14792),b=i(62734),M=i(65550),G=i(35042),H=i(58158),N=i(71143),k=i(97331)
const{ccclass:U}=n._decorator
let V=U("CharacterAddAttrView")(s=class extends((0,l.Ri)()){constructor(t){super(t),this.strength=0,this.agility=0,this.phyPower=0,this.intelligence=0,this.remianPointNum=0,
this.addRecommendResult=null,this.curRoleInfo=null,this.attrClickType=0,this.curGetNum=0,this.baseAttrAddOtherAttrDic=null,this.gotoInterval=-1,this._degf_AttrAddHandler=null,
this._degf_OnClickVipTag=null,this._degf_OnClickVipTip=null,this._degf_OnConsumeDiamondOk=null,this._degf_OnFruitBtn=null,this._degf_OnRedPointUpdate=null,
this._degf_OnResetBtnClick=null,this._degf_OnSureClick=null,this._degf_agilityChangeHandler=null,this._degf_intelligenceChangeHandler=null,this._degf_phyPowerChangeHandler=null,
this._degf_recommendAddNumCallBack=null,this._degf_strengthChangeHandler=null,this._degf_OnRecommSelect=null,this._degf_StopEff=null,this.recommondBtnGrey=null,
this.addRecommendResult=new p.Z,this._degf_AttrAddHandler=(t,e)=>this.AttrAddHandler(t,e),this._degf_OnClickVipTag=(t,e)=>this.OnClickVipTag(t,e),
this._degf_OnConsumeDiamondOk=t=>this.OnConsumeDiamondOk(t),this._degf_OnFruitBtn=(t,e)=>this.OnFruitBtn(t,e),this._degf_OnRedPointUpdate=(t,e)=>this.OnRedPointUpdate(t,e),
this._degf_OnResetBtnClick=(t,e)=>this.OnResetBtnClick(),this._degf_OnSureClick=t=>this.OnSureClick(t),this._degf_agilityChangeHandler=t=>this.agilityChangeHandler(t),
this._degf_intelligenceChangeHandler=t=>this.intelligenceChangeHandler(t),this._degf_phyPowerChangeHandler=t=>this.phyPowerChangeHandler(t),
this._degf_strengthChangeHandler=t=>this.strengthChangeHandler(t),this._degf_OnRecommSelect=t=>this.OnRecommSelect(t)}InitView(){this.SetData(),this.addNumBtn.node.SetActive(!0),
this.addnumgraybtn.node.SetActive(!1)}SetData(){this.InitData()}InitData(){this.RefreshView()}UpdateAnchors(){}RefreshView(){this.addpointview.OnAddToScene(),this.InitUIData()}
UpdateBtnState(){if(null!=this.curRoleInfo){const t=this.curRoleInfo.RemainBasePoint_get()>0&&S.X.Inst_get().GetAllAddPoint()
this.addNumBtn.node&&(this.addNumBtn.node.active=t,this.addnumgraybtn.node.active=!t)
const e=this.curRoleInfo.RemainBasePoint_get()-S.X.Inst_get().GetAllAddPointNum()
b.f.Inst.SetState(B.t.RECOMMAND_ATTRIBUTE_ADD,e>0,null)}this.ChangeRecommondBtnState()}InitUIData(){this.removeLis(),this.addLis(),
this.curRoleInfo=o.i.Inst.GetCurSelect(I.I.CharacterUIPanel),this.RemainBasePointUpdate(this.curRoleInfo.RemainBasePoint_get())
const t=k.n.Inst_get().GetTotalPoint(),e=g.M.IntToString(t)
this.totalCount.string=e
const i=R.P.Inst_get().IsFunctionOpened(P.x.FRUIT)
this.fruitBtn.SetActive(i),this.OnRedPointUpdate(null,null),this.initAttribute()}ChangeRecommondBtnState(){null!=S.X.Inst_get().waitAddPoint?(this.recommondBtnGrey=!0,
this.recommendAddNumBtn&&(this.recommendAddNumBtn.enabled=!1,this.addPointTip.SetActive(!1))):this.recommendAddNumBtn&&(this.recommendAddNumBtn.enabled=!0)}OpenViewEff(){
H.U.Inst_get().isMasterTalentOpen&&(H.U.Inst_get().isMasterTalentOpen=!1,this.gotoInterval=c.C.Inst_get().SetInterval(this._degf_StopEff,1170,1))}StopEff(){this.guideEff}
ClearData(){c.C.Inst_get().ClearInterval(this.gotoInterval),this.gotoInterval=-1,this.removeLis(),this.addpointview.Clear()}Clear(){this.ClearData()}addLis(){
d.i.Inst.AddEventHandler(y.g.RECOMMEND_ATTR_SELECT,this._degf_OnRecommSelect),this.m_handlerMgr.AddClickEvent(this.recommendAddNumBtn,this.CreateDelegate(this.OnRecommClick)),
this.m_handlerMgr.AddClickEvent(this.addNumBtn,this.CreateDelegate(this.AddNumBtnHandler)),this.m_handlerMgr.AddClickEvent(this.vipTag,this.CreateDelegate(this.OnClickVipTag)),
this.m_handlerMgr.AddClickEvent(this.resetBtn,this.CreateDelegate(this.OnResetBtnClick)),this.m_handlerMgr.AddClickEvent(this.fruitBtn,this.CreateDelegate(this.OnFruitBtn)),
b.f.Inst.AddCallback(B.t.ADD_FRUIT,this._degf_OnRedPointUpdate),b.f.Inst.AddCallback(B.t.RECOMMAND_ATTRIBUTE_ADD,this._degf_OnRedPointUpdate)
const t=r.Y.Inst.primaryRoleInfoList
for(let e=0;e<=t.Count()-1;e++){const i=t[e]
i.AddEventHandler(h.A.AttributesUpdate,(0,a.v)(this.AttributeUpdateHandler,this)),i.AddEventHandler(h.A.RemainBasePointUpdate,(0,a.v)(this.RemainBasePointUpdateHandler,this)),
i.AddEventHandler(h.A.AllBasePointUpdate,(0,a.v)(this.AllBasePointUpdateHandler,this)),i.AddEventHandler(h.A.RemainBasePointUpdate,(0,a.v)(this.ResetModelData,this))}
d.i.Inst.AddEventHandler(y.g.ADDPOINT_TIP_POINT_UPDATE,(0,a.v)(this.UpdateBtnState,this)),d.i.Inst.AddEventHandler(y.g.SET_ADDPOINT_ATT,(0,a.v)(this.SetAttribute,this))}
removeLis(){d.i.Inst.RemoveEventHandler(y.g.RECOMMEND_ATTR_SELECT,this._degf_OnRecommSelect),
this.m_handlerMgr.RemoveClickEvent(this.recommendAddNumBtn,this.CreateDelegate(this.OnRecommClick)),
this.m_handlerMgr.RemoveClickEvent(this.addNumBtn,this.CreateDelegate(this.AddNumBtnHandler)),
this.m_handlerMgr.RemoveClickEvent(this.resetBtn,this.CreateDelegate(this.OnResetBtnClick)),this.m_handlerMgr.RemoveClickEvent(this.fruitBtn,this.CreateDelegate(this.OnFruitBtn)),
b.f.Inst.RemoveCallback(B.t.ADD_FRUIT,this._degf_OnRedPointUpdate),b.f.Inst.RemoveCallback(B.t.RECOMMAND_ATTRIBUTE_ADD,this._degf_OnRedPointUpdate)
const t=r.Y.Inst.primaryRoleInfoList
for(let e=0;e<=t.Count()-1;e++){const i=t[e]
i.RemoveEventHandler(h.A.AttributesUpdate,(0,a.v)(this.AttributeUpdateHandler,this)),i.RemoveEventHandler(h.A.RemainBasePointUpdate,(0,
a.v)(this.RemainBasePointUpdateHandler,this)),i.RemoveEventHandler(h.A.AllBasePointUpdate,(0,a.v)(this.AllBasePointUpdateHandler,this)),
i.RemoveEventHandler(h.A.RemainBasePointUpdate,(0,a.v)(this.ResetModelData,this))}d.i.Inst.RemoveEventHandler(y.g.ADDPOINT_TIP_POINT_UPDATE,(0,a.v)(this.UpdateBtnState,this)),
d.i.Inst.RemoveEventHandler(y.g.SET_ADDPOINT_ATT,(0,a.v)(this.SetAttribute,this))}RegGuide(){}UnRegGuide(){}AllBasePointUpdateHandler(t){
const e=t,i=o.i.Inst.GetCurSelect(I.I.CharacterUIPanel)
null!=i&&i.m_id.Equal(e.m_id)&&this.AllBasePointUpdate(e)}RemainBasePointUpdateHandler(t){const e=t,i=o.i.Inst.GetCurSelect(I.I.CharacterUIPanel)
null!=i&&i.m_id.Equal(e.m_id)&&this.RemainBasePointUpdate(e.RemainBasePoint_get())}AttributeUpdateHandler(t){const e=t,i=o.i.Inst.GetCurSelect(I.I.CharacterUIPanel)
null!=i&&i.m_id.Equal(e.m_id)&&0==S.X.Inst_get().startOperation&&(this.UpdateAttr(e),this.addpointview&&this.addpointview.UpdateTotalHandler(null),
this.AllBasePointUpdateHandler(e))}UpdateLeft(){const t=k.n.Inst_get().GetTotalPoint(),e=g.M.IntToString(t)
this.totalCount.string=e}OnSureClick(t){O.D.getInstance().GetIntValue("POINT:CLEAR_ITEM")
S.X.Inst_get().startOperation=!1,f.J.Inst_get().CM_ReimbursePointRep(this.curRoleInfo.m_id)}OnConsumeDiamondOk(t=null){S.X.Inst_get().startOperation=!1,
f.J.Inst_get().CM_ReimbursePointRep(this.curRoleInfo.m_id)}OnConsumeDiamondOk2(t){}OnResetBtnClick(){const t=O.D.getInstance().GetIntValue("ADD_POINT:FREE_RESET")
if(this.curRoleInfo.Level_get()<t){const e=new E.B
return e.infoId="ADDPOINT:FREE_RESET",e.confirmHandle=this._degf_OnConsumeDiamondOk,e.replaceParams.Add(L.h.GetLevelStr2(t)),e.replaceParams.Add(1),void D.t.Inst().Open(e)}
const e=new E.B
e.infoId="BASEPOINT:PAY_NOTICE",e.confirmHandle=this._degf_OnSureClick,e.confirmParam=e,D.t.Inst().Open(e)}OnRedPointUpdate(t,e){const i=b.f.Inst.GetData(B.t.ADD_FRUIT)
if(this.fruitPoint&&(this.fruitPoint.SetActive(i.show),!this.recommondBtnGrey)){const t=b.f.Inst.GetData(B.t.RECOMMAND_ATTRIBUTE_ADD)
this.addPointTip.SetActive(t.show)}}OnFruitBtn(t,e){u.N.inst.OpenUIByShortCutID(_.D.Fruit),v.l.CheckBtnClickTrigger(_.D.UI_ROLE_ATTR_ADD_FRUIT_BTN)}OnClickVipTag(t,e){
const i=new T.w
i.position=new C.P(-120,210,0),i.width=400,i.height=230,i.infoId="ATTRIBUTE:TIPS",w.Q.Inst_get().Open(i)}AttrAddHandler(t,e){
10==t?this.curGetNum=0:e?this.curGetNum=t:(this.curGetNum*=10,this.curGetNum+=t),this.curGetNum<0&&(this.curGetNum=0),
this.curGetNum>this.curRoleInfo.RemainBasePoint_get()&&(this.curGetNum=this.curRoleInfo.RemainBasePoint_get())}strengthChangeHandler(t){const e=t-this.strength
if(this.strength=t,this.remianPointNum-=e,this.remianPointNum<0){const t=0-this.remianPointNum
this.remianPointNum+=t,this.strength-=t}this.RemainBasePointUpdate(this.remianPointNum),this.AddAttributeChange(this.curRoleInfo,1)}agilityChangeHandler(t){const e=t-this.agility
if(this.agility=t,this.remianPointNum-=e,this.remianPointNum<0){const t=0-this.remianPointNum
this.remianPointNum+=t,this.agility-=t}this.RemainBasePointUpdate(this.remianPointNum),this.AddAttributeChange(this.curRoleInfo,2)}phyPowerChangeHandler(t){const e=t-this.phyPower
if(this.phyPower=t,this.remianPointNum-=e,this.remianPointNum<0){const t=0-this.remianPointNum
this.remianPointNum+=t,this.phyPower-=t}this.RemainBasePointUpdate(this.remianPointNum),this.AddAttributeChange(this.curRoleInfo,3)}intelligenceChangeHandler(t){
const e=t-this.intelligence
if(this.intelligence=t,this.remianPointNum-=e,this.remianPointNum<0){const t=0-this.remianPointNum
this.remianPointNum+=t,this.intelligence-=t}this.RemainBasePointUpdate(this.remianPointNum),this.AddAttributeChange(this.curRoleInfo,4)}OnRecommClick(t,e){
this.curRoleInfo.RemainBasePoint_get()<=0?M.y.inst.ClientSysMessage(G.X.UnAttr):(k.n.Inst_get().recommList=k.n.Inst_get().GetRecommAttrValList(),this.OnRecommSelect())}
OnRecommSelect(t=null){this.addRecommendResult=k.n.Inst_get().recommList,S.X.Inst_get().startOperation=!0,this.addpointview.SetRecommend(this.addRecommendResult)}sendAddPoint(t){
N.i.SendAddAttr(this.addRecommendResult,t)}addRecommdPoint(t,e,i,s,n){let l=0
return 0==i||(l=m.GF.INT(t/s)*i,n<e?n+l>e&&(l=e-n):l=0),l}addRecommdRemainPoint(t,e,i,s,n,l){let a=0,o=0,r=0
return 0==i||n>=e||n+l>=e||(o=t/s*i,a=t%s,a<=0?o=0:a<=i?o<e?(r=e-o,r>=a||(a=r),o=a):o=0:o<e?(r=e-o,o=r>=i?i:i=r):o=0,0!=o&&n+l+o>e&&(o=e-n)),o}SetAttribute(t=null){
if(!this.curRoleInfo||!this.addpointview)return
const e=this.curRoleInfo.Job_get()
let i=0
t==A.Z.Strength&&(i=this.addpointview.strengthItem.curPoint,this.ChangeAttr(1,i,10*e+1,this.curRoleInfo)),t==A.Z.Agility&&(i=this.addpointview.agilityItem.curPoint,
this.ChangeAttr(3,i,10*e+3,this.curRoleInfo)),t==A.Z.Vitality&&(i=this.addpointview.vitalityItem.curPoint,this.ChangeAttr(2,i,10*e+2,this.curRoleInfo)),
t==A.Z.Intelligence&&(i=this.addpointview.intelligenceItem.curPoint,this.ChangeAttr(4,i,10*e+4,this.curRoleInfo))}AddAttributeChange(t,e){const i=t.Job_get()
1==e&&this.ChangeAttr(1,this.strength,10*i+1,t),2==e&&this.ChangeAttr(3,this.agility,10*i+3,t),3==e&&this.ChangeAttr(2,this.phyPower,10*i+2,t),
4==e&&this.ChangeAttr(4,this.intelligence,10*i+4,t)}ChangeAttr(t,e,i,s){}UpdateAttr(t){}RemainBasePointUpdate(t){this.remainCount&&(this.remainCount.string=g.M.IntToString(t),
this.remianPointNum=t,this.remianPointNum>0?(this.remainCount.string=`[F4E2B3]${t}[-]`,this.remainCount.color=new n.Color(226,166,106)):(this.remainCount.textSet("[DE2524]0[-]"),
this.remainCount.color=new n.Color(222,37,36)),this.UpdateBtnState())}AllBasePointUpdate(t){if(null!=t){const t=k.n.Inst_get().GetTotalPoint(),e=g.M.IntToString(t)
this.totalCount&&(this.totalCount.string=e),this.addpointview&&this.addpointview.UpdateTotalHandler()}}AddNumBtnHandler(t,e){const i=S.X.Inst_get()
this.addRecommendResult[0]=i.strengthAddPoint,this.addRecommendResult[1]=i.agilityAddoint,this.addRecommendResult[2]=i.vitalityAddPoint,
this.addRecommendResult[3]=i.intelligenceAddPoint,
0==this.addRecommendResult[0]&&0==this.addRecommendResult[1]&&0==this.addRecommendResult[2]&&0==this.addRecommendResult[3]||this.sendAddPoint(this.curRoleInfo.m_id)}
ResetModelData(){S.X.Inst_get().ResetData()}InitAddNum(){this.strength=0,this.agility=0,this.phyPower=0,this.intelligence=0}SetInputCtrlMaxVal(t){}initAttribute(){
this.SetAttribute(A.Z.Strength),this.SetAttribute(A.Z.Agility),this.SetAttribute(A.Z.Vitality),this.SetAttribute(A.Z.Intelligence)}Destroy(){this.addpointview.Destroy()}
onDestroy(){console.log("CharacterAddAttrView Destroy")}})||s},15907:(t,e,i)=>{
var s,n=i(18998),l=i(83908),a=i(32076),o=i(11210),r=i(97960),h=i(97461),d=i(5924),c=i(5494),_=i(98885),u=i(33854),I=i(79996),m=i(84485),g=i(75237),p=i(21554),C=i(92679),S=i(77477),f=i(60917),T=i(35259),y=i(50894),A=i(58158),D=i(71143)
n._decorator.ccclass("CharacterAddPointView")(s=class extends((0,l.yk)()){constructor(t){super(t),this.aModel=null,this._degf_AttributeUpdate=null,
this._degf_UpdateTotalHandler=null,this.roleInfo=null,this.bubbletimerId=null,this._degf_UpdateCurRemainPoint=null,this._degf_AttributeUpdate=t=>this.AttributeUpdate(t),
this._degf_UpdateTotalHandler=t=>this.UpdateTotalHandler(t),this._degf_UpdateCurRemainPoint=t=>this.UpdateCurRemainPoint(t)}InitView(){this.strengthItem.InitType(S.Z.Strength,1),
this.agilityItem.InitType(S.Z.Agility,2),this.vitalityItem.InitType(S.Z.Vitality,3),this.intelligenceItem.InitType(S.Z.Intelligence,4),this.aModel=m.X.Inst_get()}OnAddToScene(){
this.RemoveLis(),this.roleInfo=o.i.Inst.GetCurSelect(c.I.CharacterUIPanel),A.U.Inst_get().curSelectIdx=this.roleInfo.createIdx,this.AddLis(),this.aModel.ResetData(),
this.aModel.UpdateTotalPoint(this.roleInfo),this.UpdateView(),this.ItemsInit(),this.initItemsPosition()}ShowBubbleObj(){this.HideBubbleObj(!0)}ClearShowTime(){
-1!=this.bubbletimerId&&(d.C.Inst_get().ClearInterval(this.bubbletimerId),this.bubbletimerId=-1)}HideBubbleObj(t){this.agilityItem.HandleBubbleObj(t),
this.strengthItem.HandleBubbleObj(t),this.vitalityItem.HandleBubbleObj(t),this.intelligenceItem.HandleBubbleObj(t)}Clear(){this.RemoveLis()}Destroy(){}AddLis(){this.RemoveLis(),
this.roleInfo.AddEventHandler(r.A.AttributesUpdate,this._degf_AttributeUpdate),this.roleInfo.AddEventHandler(r.A.RemainBasePointUpdate,(0,a.v)(this.UpdateTotalHandler,this)),
h.i.Inst.AddEventHandler(C.g.ADDPOINT_TIP_POINT_UPDATE,this._degf_UpdateCurRemainPoint)}RemoveLis(){
null!=this.roleInfo&&(this.roleInfo.RemoveEventHandler(r.A.AttributesUpdate,this._degf_AttributeUpdate),this.roleInfo.RemoveEventHandler(r.A.RemainBasePointUpdate,(0,
a.v)(this.UpdateTotalHandler,this))),h.i.Inst.RemoveEventHandler(C.g.ADDPOINT_TIP_POINT_UPDATE,this._degf_UpdateCurRemainPoint)}AttributeUpdate(t){if(u.t.Inst_get().wearByAloat){
u.t.Inst_get().wearByAloat=!1
const t=p.J.Inst_get().GetEquipTipItemData()
if(null!=t){if(D.i.CanTakeOnByRemainPoint(this.roleInfo,t.baseData_get())){const e=new I.F
e.tipType=g.A.WearEquip,e.ItemData_set(t.baseData_get()),u.t.Inst_get().OpenTip(e)}else p.J.Inst_get().CloseTipView()}else{const t=T.C.INSTANCE.addPointSkill
if(null!=t){const e=new f.P
T.C.INSTANCE.CheckSkillPointUseVaildity(t,null,e)
const i=new I.F,s=_.M.String2Int(e.extend),n=this.roleInfo.RemainBasePoint_get()
e.intType==S.Z.Strength?i.strengthNeedPoint=e.value-s:e.intType==S.Z.Vitality?i.vitalityNeedPoint=e.value-s:e.intType==S.Z.Agility?i.agilityNeedPoint=e.value-s:e.intType==S.Z.Intelligence&&(i.intelligenceNeedPoint=e.value-s),
n>=i.strengthNeedPoint+i.vitalityNeedPoint+i.agilityNeedPoint+i.intelligenceNeedPoint?(i.tipType=g.A.Skill,
u.t.Inst_get().OpenTip(i)):h.i.Inst.RaiseEvent(C.g.ADDPOINT_TIP_SKILL_CLICK)}}}}UpdateTotalHandler(t=null){this.aModel.UpdateTotalPoint(this.roleInfo),this.UpdateView(),
this.strengthItem.SetData(),this.agilityItem.SetData(),this.vitalityItem.SetData(),this.intelligenceItem.SetData()}UpdateView(){this.SetDesc()}ItemsInit(){
this.strengthItem.InitData(this.roleInfo),this.agilityItem.InitData(this.roleInfo),this.vitalityItem.InitData(this.roleInfo),this.intelligenceItem.InitData(this.roleInfo)}
GetTotalAdd(){return this.strengthItem.curPoint+this.agilityItem.curPoint+this.vitalityItem.curPoint+this.intelligenceItem.curPoint}SetRecommend(t){if(m.X.Inst_get().IsAddByTips){
let e=m.X.Inst_get().curRemainPoint
e>0&&(e>=t[0]-this.strengthItem.curPoint?(this.strengthItem.curPoint=t[0],e-=t[0]-this.strengthItem.curPoint):(this.strengthItem.curPoint=this.strengthItem.curPoint+e,e=0)),
e>0&&(e>=t[1]-this.agilityItem.curPoint?(this.agilityItem.curPoint=t[1],e-=t[1]-this.agilityItem.curPoint):(this.agilityItem.curPoint=this.agilityItem.curPoint+e,e=0)),
e>0&&(e>=t[2]-this.vitalityItem.curPoint?(this.vitalityItem.curPoint=t[2],e-=t[2]-this.vitalityItem.curPoint):(this.vitalityItem.curPoint=this.vitalityItem.curPoint+e,e=0)),
e>0&&(e>=t[3]-this.intelligenceItem.curPoint?(this.intelligenceItem.curPoint=t[3],
e-=t[3]-this.intelligenceItem.curPoint):(this.intelligenceItem.curPoint=this.intelligenceItem.curPoint+e,e=0))}else this.strengthItem.curPoint=t[0],this.agilityItem.curPoint=t[1],
this.vitalityItem.curPoint=t[2],this.intelligenceItem.curPoint=t[3]
this.strengthItem.SetCurPoint(),this.agilityItem.SetCurPoint(),this.vitalityItem.SetCurPoint(),this.intelligenceItem.SetCurPoint(),y.k.inst.SetAttribute(S.Z.Strength),
y.k.inst.SetAttribute(S.Z.Agility),y.k.inst.SetAttribute(S.Z.Vitality),y.k.inst.SetAttribute(S.Z.Intelligence)}UpdateCurRemainPoint(t){if(null==this.aModel)return
const e=this.aModel.curRemainPoint
this.aModel.UpdateRemainPoint(),this.aModel.curRemainPoint>0?this.remainPoint.textSet(`[F4E2B3]${this.aModel.curRemainPoint}[-]`):this.remainPoint.textSet("[DE2524]0[-]"),
(0==e&&this.aModel.curRemainPoint>0||e>0&&0==this.aModel.curRemainPoint)&&(this.strengthItem.ShowBtn(),this.agilityItem.ShowBtn(),this.vitalityItem.ShowBtn(),
this.intelligenceItem.ShowBtn()),null!=t&&(this.strengthItem.OnPointUpdate(t),this.agilityItem.OnPointUpdate(t),this.vitalityItem.OnPointUpdate(t),
this.intelligenceItem.OnPointUpdate(t))}initItemsPosition(){this.Container.node.setPosition(-283,150)}SetDesc(){}})},35894:(t,e,i)=>{
var s,n,l=i(18998),a=i(83908),o=i(86133),r=i(11895),h=i(97461),d=i(70181),c=i(85682),_=i(98130),u=i(98885),I=i(85602),m=i(88653),g=i(44758),p=i(73851),C=i(84485),S=i(92679),f=i(77477),T=i(48933),y=i(17407),A=i(37322),D=i(6251),E=i(50894),v=i(97331),w=i(39745)
l._decorator.ccclass("CharacterPointItem")(((n=class extends((0,a.yk)()){constructor(t){super(t),this.curPoint=0,this.aModel=null,this.attrType=0,this.rInfo=null,this.dragIndex=-1,
this.touchTapOrHold=0,this.dragBarVec4=null,this.leftEndX=-96,this.dragLength=164,this.rightEndX=0,this.addBtnActive=!0,this.grayGoActive=!1,this.lackPointNum=0,
this.fullProcessVal=0,this.hasRegistGuide=!1,this.addpress=null,this.removepress=null,this.showAddBtn=!0,this._degf_AddPressHandler=null,this._degf_DragCallBack=null,
this._degf_OnAddClick=null,this._degf_OnBarPress=null,this._degf_OnPointUpdate=null,this._degf_OnRemoveClick=null,this._degf_OnWidgetPress=null,this._degf_RemovePressHandler=null,
this.attrNumlabs=null,this.attrNameLabs=null,this.specialColor=null,this.guidAddId=null,this.guidSubId=null,this.type=null,this.endY=null,this.attrs=null,this.attrRates=null,
this.dragMgr=null,this.isDraging=!1,this.ChildrenPos=new Map([["dragareaPos","231, -30"],["attrPos","0, -50"]]),this.dragBarVec4=new g.L,
this._degf_AddPressHandler=()=>this.AddPressHandler(),this._degf_DragCallBack=(t,e)=>this.DragCallBack(t,e),this._degf_OnAddClick=(t,e)=>this.OnAddClick(t,e),
this._degf_OnBarPress=(t,e)=>this.OnBarPress(t,e),this._degf_OnPointUpdate=t=>this.OnPointUpdate(t),this._degf_OnRemoveClick=(t,e)=>this.OnRemoveClick(t,e),
this._degf_OnWidgetPress=(t,e)=>this.OnWidgetPress(t,e),this._degf_RemovePressHandler=()=>this.RemovePressHandler()}InitView(){this.attrNumlabs=new I.Z,this.attrNameLabs=new I.Z,
this.attrNumlabs.Add(this.attrNumlab0),this.attrNumlabs.Add(this.attrNumlab1),this.attrNumlabs.Add(this.attrNumlab2),this.attrNumlabs.Add(this.attrNumlab3),
this.attrNameLabs.Add(this.attrNameLab0),this.attrNameLabs.Add(this.attrNameLab1),this.attrNameLabs.Add(this.attrNameLab2),this.attrNameLabs.Add(this.attrNameLab3),
this.initChildrenPosition(),this.specialColor="[8C4F00]",this.aModel=C.X.Inst_get(),this.addpress=new A.c(this.addBtn.node,null,null,null,this._degf_AddPressHandler),
this.removepress=new A.c(this.removeBtn.node,null,null,null,this._degf_RemovePressHandler)}AddPressHandler(){this.aModel.curRemainPoint>0&&(this.curPoint+=1,this.SetCurPoint())}
RemovePressHandler(){this.curPoint-=1,this.curPoint<0&&(this.curPoint=0),this.SetCurPoint()}SetProcessBarVal(t){this.processBar.node.getComponent(l.UITransform).width=187*t,
this.processBar.node.active=t>0}Clear(){}Destroy(){}AddLis(){this.addpress.AddEvent(),this.removepress.AddEvent(),
this.addBtn.node.on(l.NodeEventType.TOUCH_END,this._degf_OnAddClick,this,!1),this.removeBtn.node.on(l.NodeEventType.TOUCH_END,this._degf_OnRemoveClick,this,!1),
this.dragWidget.on(l.NodeEventType.TOUCH_START,this._degf_OnWidgetPress,this),this.dragBar.on(l.NodeEventType.TOUCH_START,this._degf_OnBarPress,this)}RemoveLis(){
this.addpress.RemoveEvent(),this.removepress.RemoveEvent()}RegGuide(){}UnRegGuide(){}GetAddGuideId(t){
return t==f.Z.Strength?c.D.UI_ROLE_ATTR_ADD_STR_BTN:t==f.Z.Agility?c.D.UI_ROLE_ATTR_ADD_AG_BTN:t==f.Z.Vitality?c.D.UI_ROLE_ATTR_ADD_VI_BTN:t==f.Z.Intelligence?c.D.UI_ROLE_ATTR_ADD_IN_BTN:void 0
}GetSubGuideId(t){
return t==f.Z.Strength?c.D.UI_ROLE_ATTR_SUB_STR_BTN:t==f.Z.Agility?c.D.UI_ROLE_ATTR_SUB_AG_BTN:t==f.Z.Vitality?c.D.UI_ROLE_ATTR_SUB_VI_BTN:t==f.Z.Intelligence?c.D.UI_ROLE_ATTR_SUB_IN_BTN:void 0
}InitType(t,e){this.attrType=t,this.type=e,this.guidAddId=this.GetAddGuideId(t),this.guidSubId=this.GetSubGuideId(t)}InitData(t){this.rInfo=t,this.AddLis(),
this.curPoint=C.X.Inst_get().GetDefaultPoint(this.type),this.SetAddPointData(),this.initAtrrList(),this.ChangeAttr(),this.SetData()}SetAddPointData(){
this.curPoint<0&&(this.curPoint=0),this.aModel.UpdateAddPoint(this.attrType,this.curPoint),this.removeBtn&&0==this.curPoint?(this.removeBtn.node.getComponent(p.G).enabled=!1,
D.d.LuaMakeGoGray(this.removeBtn.node,!0)):this.removeBtn&&(this.removeBtn.node.getComponent(p.G).enabled=!0,D.d.LuaMakeGoGray(this.removeBtn.node,!1))}SetCurPoint(){
this.curPoint>this.fullProcessVal&&(this.curPoint=0),this.SetAddPointData(),this.UpdatePoint()
let t=this.leftEndX
0!=this.fullProcessVal&&(t=this.leftEndX+this.dragLength*this.curPoint/this.fullProcessVal),
t<this.leftEndX?t=this.leftEndX:t>this.leftEndX+this.dragLength&&(t=this.leftEndX+this.dragLength)
const e=new l.Vec3(t,0,0)
this.dragBar.setPosition(e)
let i=1*(t-this.leftEndX)/this.dragLength
i<0?i=0:i>1&&(i=1),this.SetProcessBarVal(i)}SetData(){this.ShowBtn(),this.bubbleLabel.textSet("0"),this.lackPointNum=this.GetLackPoint(),this.hasRegistGuide=!1,
this.fullProcessVal=this.aModel.totalRemainPoint,this.attrEnoughObj.active=!1,this.attrLackObj.active=!1,
this.curAttrVal.string=u.M.DoubleToString(this.rInfo.getAttribute(this.attrType)),this.rightEndX=this.leftEndX,this.curPoint=this.aModel.GetAddPoint(this.attrType)
let t=0
0!=this.fullProcessVal&&(t=this.curPoint/this.fullProcessVal,this.rightEndX=this.leftEndX+this.aModel.curRemainPoint/this.fullProcessVal*this.dragLength)
const e=new l.Vec3(this.leftEndX+t*this.dragLength,0,0)
this.dragBar.setPosition(e),this.UpdateProcess(this.curPoint,t),this.dragMgr=new r.L,
this.dragMgr.SetUpDrag(this.dragBar,this._degf_DragCallBack,this.CreateDelegate(this.DragCallBackEnd))}OnPointUpdate(t){this.ChangeAttr()}GetLackPoint(){return 0}SetCurValColor(){}
ShowBtn(){this.showAddBtn=this.aModel.curRemainPoint>0,this.addBtn&&this.addBtn.node&&(this.showAddBtn?(this.addBtn.node.getComponent(p.G).enabled=!0,
D.d.LuaMakeGoGray(this.addBtn.node,!1)):(this.addBtn.node.getComponent(p.G).enabled=!1,D.d.LuaMakeGoGray(this.addBtn.node,!0)))}OnAddClick(t,e){this.aModel.startOperation=!0,
this.aModel.curRemainPoint>0&&(this.curPoint+=1,this.SetCurPoint()),E.k.inst.SetAttribute(this.attrType)}OnRemoveClick(t,e){this.aModel.startOperation=!0,
this.curPoint>0&&(this.curPoint-=1,this.SetCurPoint())}OnBarPress(t,e){this.aModel.startOperation=!0}OnWidgetPress(t,e){
if(this.aModel.curRemainPoint<=0&&this.fullProcessVal<=0)return
this.dragBar.transform.GetLocalPosition()
let i=new l.Vec2
t.getLocation(i),this.aModel.startOperation=!0
const s=d._.ConvertToNodeSpace2(new l.Vec3(i.x,i.y,0),this.dragWidget)
s.x=s.x-this.dragBar.transform.width/2
let n=0
this.rightEndX=this.leftEndX+(this.aModel.curRemainPoint+this.curPoint)/this.fullProcessVal*this.dragLength,n=s.x<this.leftEndX?this.leftEndX:s.x>this.rightEndX?this.rightEndX:s.x,
T.I.calVec0.Set(n,this.endY,0),this.dragBar.transform.SetLocalPosition(T.I.calVec0),this.UpdateData(),
console.log("OnWidgetPress:","this.leftEndX:",this.leftEndX,"this.rightEndX:",this.rightEndX,"posX:",n,"this.dragLength:",this.dragLength,"touchLocation:",i)}DragCallBack(t,e){
if(this.aModel.curRemainPoint<=0&&this.fullProcessVal<=0)return
this.isDraging=!0
this.dragBar.transform.GetLocalPosition()
const i=d._.ConvertToNodeSpace2(new l.Vec3(this.dragMgr.touchLocation.x,this.dragMgr.touchLocation.y,0),this.dragWidget)
i.x=i.x-this.dragBar.transform.width/2,this.rightEndX=this.leftEndX+(this.aModel.curRemainPoint+this.curPoint)/this.fullProcessVal*this.dragLength,
i.x<this.leftEndX?i.x=this.leftEndX:i.x>this.rightEndX?i.x=this.rightEndX:i.x=i.x,T.I.calVec0.Set(i.x,this.endY,0),this.dragBar.transform.SetLocalPosition(T.I.calVec0),
this.UpdateData()}DragCallBackEnd(){this.isDraging=!1}UpdateData(){const t=this.dragBar.getPosition().x
let e=1*(t-this.leftEndX)/this.dragLength,i=0
i=(t-this.rightEndX)*(t-this.rightEndX)<1?this.curPoint+this.aModel.curRemainPoint:this.fullProcessVal*e,
i-this.curPoint>this.aModel.curRemainPoint&&(i=this.curPoint+this.aModel.curRemainPoint),e=i/this.fullProcessVal,this.UpdateProcess(i,e)}UpdateProcess(t,e){t=_.GF.INT(t),
this.SetProcessBarVal(e),this.UpdateArrowState(this.curPoint,t),this.curPoint=t,this.SetAddPointData(),this.UpdatePoint()}UpdateArrowState(t,e){
this.lackPointNum>0&&(t<this.lackPointNum&&e>=this.lackPointNum?(this.attrEnoughObj.active=!0,
this.attrLackObj.active=!1):t>=this.lackPointNum&&e<this.lackPointNum&&(this.attrEnoughObj.active=!1,this.attrLackObj.active=!0,this.hasRegistGuide||(this.hasRegistGuide=!0)))}
UpdatePoint(){this.SetCurValColor(),this.curAttrVal.string=u.M.DoubleToString(this.curPoint+this.rInfo.getAttribute(this.attrType)),
this.bubbleLabel.textSet(u.M.IntToString(this.curPoint)),this.HandleBubbleObj(!0),this.lackPointNum>this.curPoint&&this.lackPoint.textSet((0,
o.T)("还差")+(this.lackPointNum-this.curPoint+(0,o.T)("点"))),h.i.Inst.RaiseEvent(S.g.ADDPOINT_TIP_POINT_UPDATE,this.attrType)}HandleBubbleObj(t){
t&&this.curPoint>0?this.bubbleObj.active=!0:this.bubbleObj.active=!1}initAtrrList(){this.attrs=new I.Z,this.attrRates=new I.Z
const t=y.X.Inst().GetItemByJobAndType(this.rInfo.Job_get(),this.attrType,1)
u.M.String2Double(t.maxHp)>0&&(this.attrs.Add(f.Z.MaxHp),this.attrRates.Add(u.M.String2Double(t.maxHp))),
(u.M.String2Double(t.attack_Max)>0||u.M.String2Double(t.attack_Min)>0)&&(this.attrs.Add(f.Z.Attack_Max),this.attrRates.Add(u.M.String2Double(t.attack_Max))),
u.M.String2Double(t.defense)>0&&(this.attrs.Add(f.Z.Defense),this.attrRates.Add(u.M.String2Double(t.defense))),
u.M.String2Double(t.hitRate)>0&&this.attrType!=f.Z.Agility&&(this.attrs.Add(f.Z.HitRate),this.attrRates.Add(u.M.String2Double(t.hitRate))),
u.M.String2Double(t.dodgeRate)>0&&(this.attrs.Add(f.Z.DodgeRate),this.attrRates.Add(u.M.String2Double(t.dodgeRate))),
(u.M.String2Double(t.attackSpeed1)>0||u.M.String2Double(t.attackSpeed2)>0)&&(this.attrs.Add(f.Z.AttackSpeed),this.attrRates.Add(u.M.String2Double(t.attackSpeed1))),
(u.M.String2Double(t.skillAdd1)>0||u.M.String2Double(t.skillAdd2)>0)&&(this.attrs.Add(f.Z.SkillAdd),this.attrRates.Add(u.M.String2Double(t.SkillAdd))),
(u.M.String2Double(t.skillDown1)>0||u.M.String2Double(t.skillDown2)>0)&&(this.attrs.Add(f.Z.SkillDamageDown),this.attrRates.Add(u.M.String2Double(t.skillDown1))),
(u.M.String2Double(t.hitFix1)>0||u.M.String2Double(t.hitFix2)>0)&&(this.attrs.Add(f.Z.hitFix),this.attrRates.Add(u.M.String2Double(t.hitFix1)))
for(let t=0;t<=this.attrNumlabs.count-1;t++){let e=!1
if(t<this.attrs.count){this.attrNameLabs[t].maxWidth=0,this.attrNumlabs[t].maxWidth=0,this.attrNumlabs[t].node.active=!0,this.attrNameLabs[t].node.active=!0
const i=this.attrs[t]
i==f.Z.AttackSpeed?(this.attrNameLabs[t].string=`${this.specialColor}攻击速度[-]`,e=!0):i==f.Z.SkillAdd?(this.attrNameLabs[t].string=`${this.specialColor}技能伤害增加[-]`,
e=!0):i==f.Z.Attack_Max?this.attrNameLabs[t].string="攻击力":i==f.Z.MaxHp?this.attrNameLabs[t].string="生命值":i==f.Z.Defense?this.attrNameLabs[t].string="防御力":i==f.Z.SkillDamageDown?(this.attrNameLabs[t].string=`${this.specialColor}技能伤害减少[-]`,
e=!0):i==f.Z.hitFix?(this.attrNameLabs[t].string=`${this.specialColor}攻击命中率[-]`,
e=!0):i==f.Z.HitRate?this.attrNameLabs[t].string="攻击成功率":i==f.Z.DodgeRate&&(this.attrNameLabs[t].string="防御成功率")}else this.attrNumlabs[t].node.active=!1,
this.attrNameLabs[t].node.active=!1}this.attrbg.getComponent(l.UITransform).height=22*this.attrs.count+4,this.node.getComponent(l.UITransform).height=22*this.attrs.count+50}
ChangeAttr(){if(null==this.rInfo)return
const t=this.rInfo.Job_get(),e=v.n.Inst_get().GetTotalPoint()-this.aModel.curRemainPoint,i=w.o.Inst_get().GetAttrValueByNowTotalPoint(this.attrs,e,this.rInfo.Level_get(),t,this.attrType)
for(let t=0;t<=this.attrs.count-1;t++){const e=this.attrs[t]
if(!i||!i[e])continue
const s=this.rInfo.Attributes_get()[this.attrType],n=w.o.Inst_get().GetValByattrTypeAndRate(this.rInfo,e,this.curPoint,s,i[e][0],i[e][1])
this.attrNumlabs[t].string=n,w.o.Inst_get().GetValByattrTypeAndRate(this.rInfo,e,this.curPoint,s,i[e][0],i[e][1]),this.attrNumlabs[t].maxWidth=0}}initChildrenPosition(){
this.SetItemPositionByStr(this.node.getChildByName("dragarea"),this.ChildrenPos.get("dragareaPos")),
this.SetItemPositionByStr(this.node.getChildByName("attr"),this.ChildrenPos.get("attrPos"))}SetItemPositionByStr(t,e){if(!e||e.length<=0)return
const i=null==e?void 0:e.split(",",2),s=[Number(i[0]),Number(i[1])]
t.setPosition(s[0],s[1])}ShowStrTipHandler(t){}}).greenColor=new m.I(155/255,128/255,107/255,1),n.yellowColor=new m.I(88/255,237/255,88/255,1),s=n))},13833:(t,e,i)=>{
var s=i(18998),n=i(39470),l=i(6847),a=i(17409),o=i(49655),r=i(46282),h=i(40053),d=i(86133),c=i(98800),_=i(97461),u=i(36334),I=i(44255),m=i(85682),g=i(5494),p=i(60130),C=i(85602),S=i(84485),f=i(56131),T=i(92679),y=i(54130),A=i(51965),D=i(55490),E=i(47653),v=i(27747),w=i(9738),R=i(55492),P=i(16189),O=i(92202),L=i(12488),B=i(27129),b=i(14792),M=i(35259),G=i(67605),H=i(78592),N=i(50894),k=i(58158),U=i(18202),V=i(31222),x=i(38836),F=i(97960),q=i(9986),Y=i(6665),W=i(9776),j=i(61911),Z=i(33833),X=i(55793),K=i(39745),$=i(62370),J=i(66788),z=i(9057),Q=i(93877),tt=i(98130),et=i(98885),it=i(77477),st=i(87923)
class nt extends z.x{constructor(...t){super(...t),this.attrName=null,this.attrVal=null,this.attrDesc=null,this.curData=null}InitView(){this.attrName=new Q.Q,
this.attrName.setId(this.FatherId,this.FatherComponentID,1),this.attrVal=new Q.Q,this.attrVal.setId(this.FatherId,this.FatherComponentID,2),this.attrDesc=new Q.Q,
this.attrDesc.setId(this.FatherId,this.FatherComponentID,3),super.InitView()}SetData(t){if(null==t)return
this.curData=t,this.attrName.textSet(et.M.s_LEFT_M_K_CHAR+(this.curData.name+et.M.s_RIGHT_M_K_CHAR)),this.attrDesc.textSet(this.curData.info)
const e=c.Y.Inst.PrimaryRoleInfo_get()
let i=""
if(e.Attributes_get().LuaDic_ContainsKey(this.curData.id)){if(1==this.curData.valueType)if(this.curData.id==it.Z.Treatment){
const t=e.Attributes_get()[it.Z.PhyAttack_Max],s=e.Attributes_get()[it.Z.PhyAttack_Min]
i=st.l.GetRuleDecimalVal((t+s)/2)
}else i=this.curData.id==tt.GF.INT(it.Z.PhyAttack_Max)||this.curData.id==tt.GF.INT(it.Z.PhyAttack_Min)?st.l.GetRuleDecimalVal(e.Attributes_get()[this.curData.id]):`${e.Attributes_get()[this.curData.id]}`
else i=2==this.curData.valueType?st.l.GetPrecentDecimalVal(e.Attributes_get()[this.curData.id],100,2)+$.o.s_UNDER_PERCENT:e.Attributes_get()[this.curData.id]+$.o.s_UNDER_PERCENT
this.attrVal.textSet(i)}else J.Y.Log((0,d.T)("attributeresource表中没有这个属性ID：")+this.curData.id)}Clear(){}Destroy(){this.attrName=null,this.attrVal=null,this.attrDesc=null}}
class lt extends j.f{constructor(){super(),this.closeBtn=null,this.yijishuxing=null,this.jichushuxing=null,this.teshushuxing=null,this.itemScrollView=null,this.itemGrid=null,
this.model=null,this._degf_AttributeUpdate=null,this._degf_BaseClickHandler=null,this._degf_CloseHandler=null,this._degf_CreateItemHandler=null,this._degf_FirstClickHandler=null,
this._degf_TeShuClickHandler=null,this._degf_UpdateOnReposition=null,this._degf_AttributeUpdate=t=>this.AttributeUpdate(t),
this._degf_BaseClickHandler=(t,e)=>this.BaseClickHandler(t,e),this._degf_CloseHandler=(t,e)=>this.CloseHandler(t,e),this._degf_CreateItemHandler=t=>this.CreateItemHandler(t),
this._degf_FirstClickHandler=(t,e)=>this.FirstClickHandler(t,e),this._degf_TeShuClickHandler=(t,e)=>this.TeShuClickHandler(t,e),
this._degf_UpdateOnReposition=()=>this.UpdateOnReposition()}InitView(){this.closeBtn=new q.W,this.closeBtn.setId(this.FatherId,this.FatherComponentID,1),this.yijishuxing=new q.W,
this.yijishuxing.setId(this.FatherId,this.FatherComponentID,2),this.jichushuxing=new q.W,this.jichushuxing.setId(this.FatherId,this.FatherComponentID,3),this.teshushuxing=new q.W,
this.teshushuxing.setId(this.FatherId,this.FatherComponentID,4),this.itemScrollView=new W.h,this.itemScrollView.setId(this.FatherId,this.FatherComponentID,5),this.itemGrid=new Y.A,
this.itemGrid.setId(this.FatherId,this.FatherComponentID,6),this.itemGrid.SetInitInfo("ui_characterui_attrintructionitem",this._degf_CreateItemHandler),
this.itemGrid.OnReposition_set(this._degf_UpdateOnReposition),this.model=K.o.Inst_get(),super.InitView()}UpdateOnReposition(){}CreateItemHandler(t){const e=new nt
return e.setId(t,null,0),e}OnAddToScene(){this.AddLis(),this.ShowDataByType()}Clear(){this.RemoveLis(),this.model.curAttrIntructionType=X.y.AttrIntruction_First}SetData(){
const t=c.Y.Inst.PrimaryRoleInfo_get(),e=new C.Z,i=Z.X.Inst().getCanShowItemListByType(this.model.curAttrIntructionType)
if(null!=i&&0!=i.Count())for(const[s,n]of(0,x.V5)(i))t.JudgeShowEnable(n.id)&&e.Add(n)
this.itemGrid.data_set(e)}ShowDataByType(){this.OpenBtnState(),this.itemScrollView.SetDragAmount(0,0,!0),
this.model.curAttrIntructionType==X.y.AttrIntruction_First?this.yijishuxing.SetIsEnabled(!1):this.model.curAttrIntructionType==X.y.AttrIntruction_Base?this.jichushuxing.SetIsEnabled(!1):this.model.curAttrIntructionType==X.y.AttrIntruction_Special&&this.teshushuxing.SetIsEnabled(!1),
this.SetData()}OpenBtnState(){this.yijishuxing.SetIsEnabled(!0),this.jichushuxing.SetIsEnabled(!0),this.teshushuxing.SetIsEnabled(!0)}AddLis(){
this.AddClickEvent(this.closeBtn,this._degf_CloseHandler),this.AddClickEvent(this.yijishuxing,this._degf_FirstClickHandler),
this.AddClickEvent(this.jichushuxing,this._degf_BaseClickHandler),this.AddClickEvent(this.teshushuxing,this._degf_TeShuClickHandler),
c.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(F.A.AttributesUpdate,this._degf_AttributeUpdate)}AttributeUpdate(t){this.SetData()}TeShuClickHandler(t,e){
this.model.curAttrIntructionType!=X.y.AttrIntruction_Special&&(this.model.curAttrIntructionType=X.y.AttrIntruction_Special,this.ShowDataByType())}BaseClickHandler(t,e){
this.model.curAttrIntructionType!=X.y.AttrIntruction_Base&&(this.model.curAttrIntructionType=X.y.AttrIntruction_Base,this.ShowDataByType())}FirstClickHandler(t,e){
this.model.curAttrIntructionType!=X.y.AttrIntruction_First&&(this.model.curAttrIntructionType=X.y.AttrIntruction_First,this.ShowDataByType())}CloseHandler(t,e){at.inst.Close()}
RemoveLis(){this.RemoveClickEvent(this.closeBtn,this._degf_CloseHandler),this.RemoveClickEvent(this.yijishuxing,this._degf_FirstClickHandler),
this.RemoveClickEvent(this.jichushuxing,this._degf_BaseClickHandler),this.RemoveClickEvent(this.teshushuxing,this._degf_TeShuClickHandler),
c.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(F.A.AttributesUpdate,this._degf_AttributeUpdate)}Destroy(){this.itemGrid.Destroy(),this.closeBtn=null,this.yijishuxing=null,
this.jichushuxing=null,this.teshushuxing=null,this.itemScrollView=null,this.itemGrid=null}}class at{constructor(){this.mainView=null,this._degf_DestroyPanel=null,
this._degf_InitPanel=null,this._degf_DestroyPanel=()=>this.DestroyPanel(),this._degf_InitPanel=t=>this.InitPanel(t)}Open(){
V.N.inst.OpenById(g.I.AttrIntructionPanel,this._degf_InitPanel,this._degf_DestroyPanel)}InitPanel(t){return null==this.mainView&&(this.mainView=new lt,
this.mainView.setId(t,null,0)),this.mainView}DestroyPanel(){U.g.DestroyUIObj(this.mainView),this.mainView=null}Close(){null!=this.mainView&&V.N.inst.ClosePanel(this.mainView)}}
at.inst=null
var ot,rt=i(54798),ht=i(32080)
;(0,l.s_)(o.o.CharacterTopView,r.Z.ui_ry_tabcommonpanel).tabsPrefab(h.Z.Character_Prefabs,y.Q.Normal).tabsPrefab(h.Z.Character_horse_Prefabs,y.Q.HORSE).tabsPrefab(h.Z.Character_divine_Prefabs,y.Q.DIVINE).tabsPrefab(h.Z.Character_gem_Prefabs,y.Q.GEM).waitPrefab(h.Z.BaseItem_ry_basePrefabs).waitPrefab(h.Z.CharacterTopView_basePrefabs).hideMainUI().register()(ot=class extends I.I{
constructor(...t){super(...t),this.cModel=null,this.info=null,this.tabsObj=null,this.contentview=null,this.isDafaultSelect=null}_initBinder(){super._initBinder()}InitView(){
super.InitView(),this.contentview=this,this.isExclusionPanel=!0,this.cModel=k.U.Inst_get(),this.info=c.Y.Inst.PrimaryRoleInfo_get(),this.InitData(),this.addList()}UpdateView(){
if(this._subPanelDatas&&this._subPanelDatas.length)for(let t=0;t<this._subPanelDatas.length;t++)this._subPanelDatas[t].view&&this._subPanelDatas[t].view.UpdateView&&this._subPanelDatas[t].view.UpdateView()
}InitTab(){}addList(){this.closeBtn.node.on(s.NodeEventType.TOUCH_END,this.fun_CloseClickHandler,this)}OnAddToScene(){super.OnAddToScene(),
H.l.Inst().curRoleUseDefaultTab?this.cModel.curSelectIdx=k.U.Inst_get().curSelectIdx:-1!=this.selectCid&&(this.cModel.curSelectIdx=this.selectCid),
this.m_handlerMgr.AddEventMgr(T.g.TabCommonOpenAniEnd,this.CreateDelegate(this.OnPanelAniEnd)),this.SetDafaultTabs()}InitData(){this.rightTrans.node.active=!1}SetDafaultTabs(){
let t=k.U.Inst_get().topViewType||0
this.isDafaultSelect=!0,this.isDafaultSelect=!1,this.SelectTab0(t)}SetViewConfig(){
this._SetTabData0(!0,new C.Z(["角 色","坐 骑","圣 物","宝 石"]),new C.Z([b.t.CHARACTER_ATTRIBUTE,b.t.HORSE,b.t.DIVINE,b.t.GEM]),null,null,null,new C.Z([R.x.ROLE,R.x.Horse,R.x.DIVINE,R.x.GEM]),null,null,new C.Z([m.D.UI_ROLE_ATTR_TAB,m.D.UI_ROLE_HORSE_TAB,m.D.UI_ROLE_DIVINE_TAB,m.D.UI_ROLE_MEDAL_TAB])),
this.InitSubDatas(),this.ui_charactertab.onChanged=this.CreateDelegate(this._OnCharacterTabChange)}_OnCharacterTabChange(){S.X.Inst_get().waitAddPoint=null,
super._OnCharacterTabChange()}_OnSelectCharacterBeforeUpdate(){this.HideAllView(),
this.selectTabIdx0==y.Q.Normal||-1==this.selectTabIdx0?(k.U.Inst_get().curSelectIdx=this.selectCid,
this.SelectTab1(k.U.Inst_get().characterViewType)):(this.selectTabIdx0==y.Q.HORSE||this.selectTabIdx0==y.Q.GEM)&&this.SelectTab1()}HandleOpenSelectCharacter(){
this.selectTabIdx0!=y.Q.Normal&&-1!=this.selectTabIdx0||(this.selectTabIdx1==A.f.Normal?this._SetCharacterTabData(!0,g.I.CharacterUIPanel,b.t.CHARACTER_ATTRIBUTE,!0):this.selectTabIdx1==A.f.AddAttrs?this._SetCharacterTabData(!0,g.I.CharacterUIPanel,b.t.ATTRIBUTE_ADD,!0):this.selectTabIdx1==A.f.TITLE?this._SetCharacterTabData(!1,g.I.CharacterUIPanel,b.t.ATTRIBUTE_TITLE,!1):this.selectTabIdx1==A.f.SURFACE_FASHION&&this._SetCharacterTabData(!0,g.I.CharacterUIPanel,b.t.CHARACTER_FASHION,!0),
this.SelectCharacter(this.cModel.curSelectIdx,!1,!1))}InitSubDatas(){let t=new C.Z
t.Add(u.b.New(new C.Z([r.Z.ui_characterui_baseinfoui]),this,n.x)),t.Add(u.b.New(new C.Z([r.Z.ui_characterui_correctui]),this,rt.N)),
t.Add(u.b.New(new C.Z([r.Z.ui_character_titleview]),this,ht.V)),t.Add(u.b.New(new C.Z([r.Z.ui_surface_fashionview_ry]),this,G.D)),this.AddSubPanelDatas(y.Q.Normal,t),t=new C.Z,
t.Add(u.b.New(new C.Z([r.Z.ui_horse_mainview,r.Z.ui_horse_item]),this,L.I)),
t.Add(u.b.New(new C.Z([r.Z.ui_horse_ridingview,r.Z.ui_horse_riding_item,r.Z.ui_horse_riding_itemGroup]),this,B.z)),this.AddSubPanelDatas(y.Q.HORSE,t),t=new C.Z,
t.Add(u.b.New(new C.Z([r.Z.ui_divine_panel,r.Z.ui_divine_eff2,r.Z.ui_divine_eff3,r.Z.ui_divine_eff4]),this,w.E)),t.Add(u.b.New(new C.Z([r.Z.ui_divine_code_view]),this,v.d)),
this.AddSubPanelDatas(y.Q.DIVINE,t),
t=new C.Z,t.Add(u.b.New(new C.Z([r.Z.ui_gem_view,r.Z.ui_baseitem,r.Z.ui_gem_part_item,r.Z.ui_gem_preview_item,r.Z.ui_gem_attr_item,r.Z.ui_gem_hole_min_item]),this,P.N)),
this.AddSubPanelDatas(y.Q.GEM,t)}_OnSelectTab0BeforeUpdate(t,e){this.HideAllView(),this._subPanelDatas=this.SwitchSubPanelDatasInDic(this.selectTabIdx0)
let i=!1
if(this.rightTrans.node.active=!0,this.selectTabIdx0!=y.Q.Normal&&(S.X.Inst_get().waitAddPoint=null),this.selectTabIdx0==y.Q.Normal){i=!0,this.titleLabel.textSet("角 色")
const t=new C.Z([(0,d.T)("基 础"),(0,d.T)("加 点"),(0,d.T)("称 号"),(0,d.T)("时 装")]),e=new C.Z([m.D.UI_ROLE_ATTR_BASE_TAB,m.D.UI_ROLE_ATTR_ADD_TAB,m.D.UI_ROLE_ATTR_TITLE_TAB,m.D.UI_ROLE_ATTR_SURFACE_TAB]),s=new C.Z([b.t.ERROR,b.t.ATTRIBUTE_ADD_ROOT,b.t.ATTRIBUTE_TITLE,b.t.CHARACTER_FASHION])
this._SetTabData1(!0,t,s,new C.Z([null,null,R.x.TITLE,R.x.FASHION]),null,e)
const n=p.O.GetSelectedIndex(k.U.Inst_get().characterViewType,s,this.tab1FunIds)
"加 点"!=t[n]&&(S.X.Inst_get().waitAddPoint=null),this.SelectTab1(n,!0)}else{if(this.selectTabIdx0==y.Q.HORSE){this.rightTrans.node.active=!0,this.SetCharacterTabVisible(!1),
this.titleLabel.textSet("坐 骑")
const t=new C.Z(["基础","幻形","骑术"])
return this._SetTabData1(!0,t,new C.Z([b.t.HORSE_BASE,b.t.HORSE_UNREAL,b.t.HORSE_RIDING]),new C.Z([null,null,R.x.HORSE_RIDING])),
void(k.U.Inst_get().subTopViewType==y.Q.HORSE_UNREAL?this.SelectTab1(1,!0):k.U.Inst_get().subTopViewType==y.Q.HORSE_RIDING?this.SelectTab1(2,!0):this.SelectTab1(-1,!0))}
if(this.selectTabIdx0==y.Q.DIVINE){this.rightTrans.node.active=!0,this.SetCharacterTabVisible(!1),this.titleLabel.textSet("圣 物")
const t=new C.Z(["基础","核心"]),e=new C.Z([b.t.DIVINE_BASE,b.t.DIVINE_CODE]),i=new C.Z([R.x.DIVINE,R.x.DIVINE_CODE])
this._SetTabData1(!0,t,e,i)
const s=p.O.GetSelectedIndex(null,e,i)
this.SelectTab1(s,!0)}else if(this.selectTabIdx0==y.Q.GEM){this.rightTrans.node.active=!0,this._SetCharacterTabData(!0,g.I.CharacterUIPanel,b.t.GEM,!0),
this.SelectCharacter(null,!0),this.titleLabel.textSet("宝 石")
const t=new C.Z(["镶 嵌"])
this._SetTabData1(!0,t,new C.Z([b.t.GEM_EMBED])),this.SelectTab1(0,!0)}}}_OnSelectTab1BeforeUpdate(t){if(this.HandleOpenSelectCharacter(),
this.selectTabIdx0==y.Q.Normal&&(k.U.Inst_get().characterViewType=this.selectTabIdx1,
this.selectTabIdx1==A.f.SURFACE_FASHION?N.k.inst.ClearCharacterViewData():N.k.inst.InitCharacterViewData(this.subwidget.node)),
this.selectTabIdx0==y.Q.HORSE)2==this.selectTabIdx1?this.ShowSubView(1):(0==this.selectTabIdx1?O.O.Inst_get().currentSelectType=1:O.O.Inst_get().currentSelectType=2,
this.ShowSubView(0))
else if(this.selectTabIdx0==y.Q.DIVINE){if(this.selectTabIdx1==E.x.S_DIVIE_BASE_VIEW_IDX){const t=E.x.Inst().GetDefaultSelectId()
E.x.Inst().SetSelectDivineId(t,!0)
const e=E.x.Inst().GetDefaultLocId(t)
E.x.Inst().SetSelectLocId(e,!0)}else{const t=D.X.Inst().GetDefaultSelectId()
E.x.Inst().SetSelectDivineId(t,!0)
const e=D.X.Inst().GetDefaultLocId(t)
D.X.Inst().SetSelectCodeLocId(e,!0)}E.x.Inst().selectTabIdx=this.selectTabIdx1,this.ShowSubView(this.selectTabIdx1)}else this.ShowSubView(this.selectTabIdx1)}HideAllView(){
N.k.inst.ClearCharacterViewData()}SetCharacterTabVisible(t){this.ui_charactertab.node.SetActive(t),t&&0==this.ui_charactertab.uiId&&this.ui_charactertab.SetData(this.uiId_get())}
OnCloseClick(){}Clear(){super.Clear(),f.F.Inst_get().ClosePanel(),this.DestroySubPanelDatas(),N.k.inst.ClearCharacterViewData(),this.cModel.characterViewType=null,
this.cModel.topViewType=null,M.C.INSTANCE.isopen=!1,k.U.Inst_get().AniPlayEnd=!1,S.X.Inst_get().waitAddPoint=null,this.RemoveLis()}Destroy(){}DoReShow(){super.DoReShow()}DoHide(){
super.DoHide(),at.inst.Close()}SetRedPointId(t){this.ui_charactertab&&this.ui_charactertab.SetRedPointId(t)}OnPanelAniEnd(t){
t==g.I.CharacterUIPanel&&(this.m_handlerMgr.RemoveEventMgr(T.g.TabCommonOpenAniEnd,this.CreateDelegate(this.OnPanelAniEnd)),k.U.Inst_get().AniPlayEnd=!0,
_.i.Inst.RaiseEvent(k.U.MAINUI_ANIMATION_COMPLETE))}fun_CloseClickHandler(){(0,a.sR)(o.o.CharacterTopView)}})},55793:(t,e,i)=>{i.d(e,{y:()=>s})
class s{}s.AttrIntruction_First=1,s.AttrIntruction_Base=2,s.AttrIntruction_Special=3},76466:(t,e,i)=>{i.d(e,{b:()=>D})
var s,n,l=i(18998),a=i(72574),o=i(83908),r=i(46282),h=i(11210),d=i(98800),c=i(97960),_=i(32697),u=i(20583),I=i(97461),m=i(6700),g=i(5494),p=i(98885),C=i(85602),S=i(92679),f=i(88199),T=i(50894),y=i(3579),A=i(50838)
let D=l._decorator.ccclass("CharacterUIView")(((n=class extends((0,o.Ri)()){constructor(...t){super(...t),this.baseinfouiWidget=null,this.correctWidget=null,this.baseinfoBtn=null,
this.correctBtn=null,this.fightstageBtn=null,this.titleBtn=null,this.fsRedPoint=null,this.correctPoint=null,this.titlePointObj=null,this._turnTimerId=0,this.cModel=null,
this.rInfo=null,this.roleRotateIndex=0,this.m_player=null,this.mPlayerAngle=0,this.tabsObj=null,this._degf_InitModel=null,this._degf_OnAEvent=null,
this._degf_ChangeLeaderClick=null,this._degf_UpdateEquipScoreHandler=null,this._degf_UpdateTitleScore=null,this._degf_LeaderChanged=null,this._enumList=null,this.tabs=null,
this.selectTabIdx1=null,this.displayUIAvatarModel=null,this.characterTabView=null}InitView(){this.displayUIAvatarModel=new A.o,
this.displayUIAvatarModel.SetTarget(this.roleUIAvatar,!0),this.displayUIAvatarModel.SetDir(4),this.displayUIAvatarModel.SetScale(1,1),
this.displayUIAvatarModel.SetAct(a.Bv.FightIdle)}InitTabs(){this.rightTabGrid.node.SetActive(!0)}SetData(){this.InitData()}InitData(){null!=this.rInfo&&this.removeLis(),
this.node.active=!0,this.rInfo=h.i.Inst.GetCurSelect(g.I.CharacterUIPanel),T.k.inst.AddLis(),T.k.inst.characterView=this,this.addLis(),this.ShowViewByType(),this.SetLeftView()}
SetLeftView(){this.SetEffectOnHead(d.Y.Inst.PrimaryRoleInfo_get().TitleId_get()),this.ShowModel()}SetEffectOnHead(t){if(0==t)this.CommonTitleItem.SetActive(!1)
else{this.CommonTitleItem.SetActive(!0)
let e=y.W.Inst().getItemById(t)
this.CommonTitleItem.SetData(e)}}ShowViewByType(){this.UpdateTitleScore(null),this.UpdateEquipScoreHandler(null)}HideView(){}addLis(){
this.rInfo.AddEventHandler(c.A.BattleScoreUpdate,this.CreateDelegate(this.UpdateEquipScoreHandler)),
this.rInfo.AddEventHandler(c.A.UpdateFashionList,this.CreateDelegate(this.ShowModel)),this.rInfo.AddEventHandler(c.A.EquipFacadeUpdate,this.CreateDelegate(this.ShowModel)),
this.m_handlerMgr.AddEventMgr(S.g.TITLE_PREVIEW,this.CreateDelegate(this.SetEffectOnHead)),
this.m_handlerMgr.AddEventMgr(S.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors)),I.i.Inst.AddEventHandler(S.g.TITLE_SCORE_UPDATE,this._degf_UpdateTitleScore),
I.i.Inst.AddEventHandler(S.g.PRIMARY_ROLE_CHANGED,this._degf_LeaderChanged)}removeLis(){
this.rInfo.RemoveEventHandler(c.A.BattleScoreUpdate,this.CreateDelegate(this.UpdateEquipScoreHandler)),
this.rInfo.RemoveEventHandler(c.A.UpdateFashionList,this.CreateDelegate(this.ShowModel)),this.rInfo.RemoveEventHandler(c.A.EquipFacadeUpdate,this.CreateDelegate(this.ShowModel)),
this.m_handlerMgr.RemoveEventMgr(S.g.TITLE_PREVIEW,this.CreateDelegate(this.SetEffectOnHead)),I.i.Inst.RemoveEventHandler(S.g.TITLE_SCORE_UPDATE,this._degf_UpdateTitleScore),
I.i.Inst.RemoveEventHandler(S.g.PRIMARY_ROLE_CHANGED,this._degf_LeaderChanged),this.m_player}UpdateAnchors(){}UpdateEquipScoreHandler(t){
this.equipScore.textSet(p.M.IntToString(this.rInfo.BattleScore_get()))}ShowModel(){this.characterTabView&&this.characterTabView.UpdateInfoByCharacterMgr(),
this.rInfo=h.i.Inst.GetCurSelect(g.I.CharacterUIPanel),u.x.inst.SetUIAvatarData(this.rInfo,_.v.role,this.displayUIAvatarModel)}ClearRole(){}InitModel(t){
const e=this.m_player.GetShowWeaponAni(!1)
return this.m_player.MainRole_get().PassEvent(e,this._degf_OnAEvent),[null,null]}OnAEvent(){if(null!=this.m_player&&null!=this.m_player.MainRole_get()){
const t=this.m_player.GetAERootClip()
this.m_player.MainRole_get().PassEvent(t)}}OnRepositionRight(){}TabbtnSelected(){}_UpdateTableSelect1(){this.TabbtnSelected()
const t=this.tabs.LuaDic_Count()
for(let e=0;e<=t-1;e++){const t=this.tabs[e]
e!=this.selectTabIdx1?t.SetSelect(!1):t.SetSelect(!0)}}_OnClickRightItem(t,e,i){}ClearData(){this.rInfo&&(this.removeLis(),T.k.inst.RemoveLis())}Clear(){this.ClearData()}
Destroy(){}UpdateTitleScore(t){}LeaderChanged(){m.L.Instance_get().SetVIPObject(d.Y.Inst.PrimaryRole_get().GetHandle())}}).STAGE_ID=27,
n.tabIds=new C.Z([f.Z.CHARACTER_PROPERTY_BASE,f.Z.CHARACTER_PROPERTY_ADDPOINT,f.Z.CHARACTER_PROPERTY_TITLE]),
n.AllCharacterCompPath=[r.Z.ui_characterui_detailinfoitem_new,r.Z.ui_ry_right_tab,r.Z.ui_characterui_baseinfoui],s=n))||s},80799:(t,e,i)=>{
var s=i(18998),n=i(83908),l=i(38214),a=i(9057),o=i(18202),r=i(83540)
class h{}h.Static=1,h.Dynamic=2,h.JointDynamic=3
var d,c=i(3579)
const{ccclass:_}=s._decorator
_("CommonTitleItem_ry")(d=class extends((0,n.pA)(a.x)()){constructor(...t){super(...t),this.data=null,this.titleId=null,this.titleRender=null,this.resPath="atlas/chenghao/"}
InitView(){super.InitView()}Clear(){super.Clear()}Destroy(){super.Destroy()}Inititem(t){const e=c.W.Inst().getItemById(this.titleId)
e&&this.SetData(e)}SetData(t){t&&(this.data=t),this.UpdateView()}UpdateView(){if(!this.data)return
const t=l.Q.Instance.pid
this.data.pidLis.Count()>0&&!this.data.pidLis.Contains(t)?this.SetActive(!1):this.SetActive(!0),this.data.showType==h.Static?(this.StaticSp.SetActive(!0),
this.DynamicSp.SetActive(!1),this.JointDynamicObj.SetActive(!1),o.g.SetItemIcon(this.StaticSp,this.data.icon,r.b.eTitle,!1),
this.StaticSp.node.transform.SetLocalPositionXYZ(0,this.data.offset,0)):this.data.showType==h.Dynamic?(this.StaticSp.SetActive(!1),this.DynamicSp.SetActive(!0),
this.DynamicSp.prefix=1,this.JointDynamicObj.SetActive(!1),this.DynamicSp.path=this.data.showEffect,this.DynamicSp.play(),
this.DynamicSp.node.transform.SetLocalPositionXYZ(0,this.data.offset,0)):this.data.showType==h.JointDynamic&&(this.StaticSp.SetActive(!1),this.DynamicSp.SetActive(!1),
this.JointDynamicObj.SetActive(!0),this.JointDynamicBg.spriteNameSet(this.data.baseboard),this.JointDynamicName.spriteNameSet(this.data.word),
this.DynamicSp.SetItemIconByAtlas(this.data.icon,this.data.atlasName,!0),this.JointDynamicObj.SetLocalPositionXYZ(0,this.data.offset,0))}})},87081:(t,e,i)=>{i.d(e,{x:()=>l})
var s=i(83908),n=i(9057)
class l extends((0,s.pA)(n.x)()){constructor(...t){super(...t),this.infoData=null}InitView(){super.InitView()}SetData(t){null!=t&&(this.infoData=t,
this.txtAttrName.textSet(this.infoData.AttrName_get()),this.txtAttrVal.textSet(this.infoData.AttrVal_get()),this.spBg.SetActive(this.index%2==0))}Destroy(){}}},73583:(t,e,i)=>{
i.d(e,{E:()=>s})
class s{constructor(){this.attrName="",this.attrVal=""}AttrName_get(){return this.attrName}AttrName_set(t){this.attrName=t}AttrVal_get(){return this.attrVal}AttrVal_set(t){
this.attrVal=t}}},81269:(t,e,i)=>{i.d(e,{$:()=>a})
var s=i(83908),n=i(9057),l=i(87923)
class a extends((0,s.pA)(n.x)()){constructor(...t){super(...t),this.isItemTip=!1}InitView(){super.InitView()}Destroy(){super.Destroy()}SetData(t){
const e=t,i=`[c4b2a1]${l.l.getAttrStrWithoutSign(e.intType)}[-]   [5fb470]+${l.l.getAttrValueStr(e.intType,e.value)}[-]`
this.attLb.textSet(i)}}},92606:(t,e,i)=>{
var s,n=i(6847),l=i(83908),a=i(17409),o=i(46282),r=i(40053),h=i(5494),d=i(52212),c=i(84635),_=i(69015),u=i(67471),I=i(30834),m=i(14897),g=i(3579);(0,
n.s_)(h.I.eTitleItemTip,o.Z.ui_bag_titletippanel).waitPrefab(r.Z.RyTipCompFactory_AllTipCompPath).waitPrefab(o.Z.ui_bag_leftpart).waitPrefab(o.Z.ui_ry_common_titleitem).layerTip().register()(s=class extends((0,
l.pA)(I.n)()){constructor(...t){super(...t),this.data=null,this.tipIndex=null}InitView(){this.ui_tiproot.InitListByCompType(c.o.ITEM_TIP_ROOT_VIEW),(0,
a.D1)(this,this.CreateDelegate(this.CloseTip))}OnAddToScene(){_.g.Inst_get().ClearTip(),this.data=m.L.Inst().tipData
const t=this.data.cfgData_get(),e=new u.c(this.data)
this.ui_tiproot.SetData(e)
const i=g.W.Inst().getItemById(t.GetRewardsTitleId())
this.SetLayout(),this.ui_tiproot.OnReposition_set(this.CreateDelegate(this.SetLayout)),this.leftpart.SetData(i)}SetLayout(){
var t=this.GetCompArchePosXY()[0],e=this.GetCompArchePosXY()[1]
const[i,s]=[this.GetTipWidth(),this.GetTipHeight()]
null!=this.tipIndex?_.g.Inst_get().RefreshTipPos(this.tipIndex,new d.F(t,e),new d.F(i,s)):this.tipIndex=_.g.Inst_get().AddTipByParam(null,null,null,new d.F(t,e),new d.F(i,s))}
GetCompArchePosXY(){return this.ui_tiproot.GetCompArchePosXY()}GetTipHeight(){return this.ui_tiproot.GetCompHeight()}GetTipWidth(){return this.ui_tiproot.GetCompWidth()}CloseTip(){
m.L.Inst().CloseItemTip()}Clear(){_.g.Inst_get().ClearTip(),this.leftpart.ClearData(),(0,a.Rt)(this),super.Clear()}Destroy(){this.leftpart.Destroy(),super.Destroy()}})},
33864:(t,e,i)=>{
var s,n,l=i(18998),a=i(83908),o=i(43662),r=i(98800),h=i(65227),d=i(28475),c=i(32697),_=i(20583),u=i(45404),I=i(50838),m=i(31546),g=i(70650),p=i(82737),C=i(85602),S=i(33314),f=i(27122),T=i(87791)
l._decorator.ccclass("TitleTipLeftPart")((n=class t extends((0,a.Ri)()){constructor(...t){super(...t),this.m_horse=null,this.curCfg=null,this.roleRotateIndex=0,this.rInfo=null,
this.m_player=null,this.mPlayerAngle=0,this.roleList=null,this.currentSelectRoleIndex=-1,this._degf_InitModel=null,this._degf_OnAEvent=null,this.displayUIAvatarModel=null,
this.tipIndex=null}InitView(){this.roleList=new C.Z,this._degf_InitModel=t=>this.InitModel(t),this._degf_OnAEvent=()=>this.OnAEvent(),this.displayUIAvatarModel=new I.o,
this.displayUIAvatarModel.SetTarget(this.uiAvatar,!0),this.displayUIAvatarModel.setUpDragNode(this.texture.node),
this.m_handlerMgr.AddClickEvent(this.nexBtn,this.CreateDelegate(this.NextRole)),this.m_handlerMgr.AddClickEvent(this.prevBtn,this.CreateDelegate(this.PrevRole))}SetData(t){
this.curCfg=t,this.battlescorevalue.textSet(this.curCfg.wearGrade+""),this.nameTxt.textSet(this.curCfg.name),this.CommonTitleItem.SetData(t)
const e=r.Y.Inst.primaryRole.Roleinfo_get()
this.SetModel(e),this.roleList.Add(r.Y.Inst.primaryRole.Roleinfo_get())
const i=r.Y.Inst.primaryRoleInfoList
for(let t=0;t<=i.Count()-1;t++)i[t].isPrimary||this.roleList.Add(i[t])
this.SelectRole(0),this.SetLayout()}SelectRole(t){if(this.currentSelectRoleIndex==t)return
this.currentSelectRoleIndex=t
const e=this.roleList[t]
this.SetModel(e)
const i=this.roleList.Count()
1==i?(this.prevBtn.node.SetActive(!1),this.nexBtn.node.SetActive(!1)):0==t?(this.prevBtn.node.SetActive(!1),this.nexBtn.node.SetActive(!0)):t==i-1?(this.prevBtn.node.SetActive(!0),
this.nexBtn.node.SetActive(!1)):(this.prevBtn.node.SetActive(!0),this.nexBtn.node.SetActive(!0))}NextRole(){let t=this.currentSelectRoleIndex+1
t=Math.min(t,this.roleList.Count()-1),this.SelectRole(t)}PrevRole(){let t=this.currentSelectRoleIndex-1
t=Math.max(t,0),this.SelectRole(t)}ShowRole(e){this.DestroyPlayerModel(),o.M.Instance_get().ActiveStage(t.STAGE_ID)
const i=new m.O
i._displayID=S.Z.GetDisplayId(e),i._world=o.M.Instance_get().GetStageWorldType(t.STAGE_ID),i._vPos.Set(0,0),
null==this.m_player&&(this.m_player=f.Q.Inst().GetObjectByName("Role",d.u)),this.m_player.ShowRide_set(!1),this.m_player.wingstand=!0,this.m_player.forceClipId=h.o.stand,
this.m_player.isShowAni=!0,this.m_player.initEnd=this._degf_InitModel,this.m_player.initByDisinfo(e,i,!0),this.m_player.SetRolePosXYZ(0,0,0),
this.m_player.SetDirection(this.mPlayerAngle),this.m_player.MainRole_get().DisableShadow(),this.m_player.SetSize(1.3),
u.n.Instance_get().SetDisplayObject(t.STAGE_ID,this.m_player.MainRole_get().handle,0),this.texture.SetMainTextureByPhoto(t.STAGE_ID),
null!=this.m_player&&(g.e.GetInst().UnregDrag(this.roleRotateIndex),this.roleRotateIndex=g.e.GetInst().RegDrag(this.rolerotategrid.node,this.m_player.MainRole_get()))}SetModel(t){
let e=S.Z.GetDisplayId(t)
var i=c.v.monster
const s=new m.O
s._displayID=e,s._world=o.M.Instance_get().GetStageWorldType(T.A.STAGE_ID),s._bNeedWaitAnime=!0,s.shiledType=p.g.DT_NONE,
this.displayUIAvatarModel=_.x.inst.SetUIAvatarData(s,i,this.displayUIAvatarModel)}InitModel(t){const e=this.m_player.GetShowWeaponAni(!1)
this.m_player.MainRole_get().PassEvent(e.toString(),this._degf_OnAEvent)}OnAEvent(){if(null!=this.m_player&&null!=this.m_player.MainRole_get()){
const t=this.m_player.GetAERootClip()
this.m_player.MainRole_get().PassEvent(t.toString())}}removeLis(){null!=this.m_player&&g.e.GetInst().UnregDrag(this.roleRotateIndex)}DestroyPlayerModel(){
null!=this.m_player&&null!=this.m_player.MainRole_get()&&(this.m_player.Destroy(),this.m_player=null)}SetLayout(){}GetTipHeight(){return 499}GetTipWidth(){return 334}
GetCompArchePosXY(){return[-337.5,282]}ClearData(){this.removeLis(),this.DestroyPlayerModel()}},n.STAGE_ID=85,s=n))},17782:(t,e,i)=>{
var s,n=i(6847),l=i(83908),a=i(17409),o=i(49655),r=i(46282),h=i(38836),d=i(86133),c=i(68662),_=i(98130),u=i(85602),I=i(14897),m=i(3579),g=i(54151),p=i(81269);(0,
n.s_)(o.o.TitleTip,r.Z.ui_character_newtitletipview).waitPrefab(r.Z.ui_character_newtitleattritem).layerTip().register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),
this.titleId=0,this.preTitleId=0,this.effectId=0,this._degf_OnClose=null,this._degf_OnTitleAttrInit=null,this._degf_TableReposition=null}_initBinder(){super._initBinder(),
this._degf_OnClose=(t,e)=>this.OnClose(t,e),this._degf_OnTitleAttrInit=t=>this.OnTitleAttrInit(t),this._degf_TableReposition=()=>this.TableReposition()}InitView(){super.InitView(),
(0,a.D1)(this,this.CreateDelegate(this.Close)),this.lightAttrGrid.SetInitInfo("ui_character_newtitleattritem",this._degf_OnTitleAttrInit),
this.equipAttrGrid.SetInitInfo("ui_character_newtitleattritem",this._degf_OnTitleAttrInit),this.lightAttrGrid.OnReposition_set(this._degf_TableReposition),
this.equipAttrGrid.OnReposition_set(this._degf_TableReposition)}OnAddToScene(){this.SetData(g.Y.Inst_get().clickId)}OnDragStart(){}Clear(){this.lightAttrGrid.Clear(),
this.equipAttrGrid.Clear(),this.preTitleId=0,this.titleId=0}OnClose(t,e){I.L.Inst().CloseTip()}Close(){I.L.Inst().CloseTip()}Destroy(){}OnTitleAttrInit(t){
const e=t[0].getCNode(p.$)
return e.setId(t[2],null,0),e}SetData(t){this.titleId=t,this.SetValidTime(this.titleId)
const e=m.W.Inst().getItemById(this.titleId)
this.obtainLb.textSet(e.desc),this.CommonTitleItem.SetData(e)
const i=e.wearAttrs.attrs,s=e.activeAttrs.attrs,n=new u.Z,l=new u.Z
let a=0
for(;a<i.Count();)n.Add(i[a]),a+=1
this.equipAttrGrid.data_set(n),this.equipAttrGrid.AjustContentSize(),this.equipAttrGrid.node.transform.height=30*n.length
let o=0
for(;o<s.Count();)l.Add(s[o]),o+=1
this.lightAttrGrid.data_set(l),this.lightAttrGrid.AjustContentSize(),this.lightAttrGrid.node.transform.height=30*l.length
const r=28*(i.Count()+s.Count())
this.bg.heightSet(306+r)}GetValueByAttrs(t,e){for(const[i,s]of(0,h.V5)(t))if(s.intType==e)return s.value
return 0}SetValidTime(t){const e=m.W.Inst().getItemById(this.titleId)
if(g.Y.Inst_get().TitleOwned_get().IndexOf(t,0)<0)this.lastTimeLb.textSet((0,d.T)("[de2524]未获得[-]"))
else if(-1==e.validTime)this.lastTimeLb.textSet((0,d.T)("[57EA57]永久[-]"))
else{const e=g.Y.Inst_get().GetTitleById(t),i=_.GF.INT(.001*e.deprecatedTime.ToNum()-c.D.serverTime_get())
if(i>86400){const t=_.GF.INT(i/86400)
this.lastTimeLb.textSet((0,d.T)("剩余时间:")+(t+(0,d.T)("天")))}else{const t=_.GF.INT(i/3600+1)
this.lastTimeLb.textSet((0,d.T)("剩余时间:")+(t+(0,d.T)("小时")))}}}TableReposition(){}})},23459:(t,e,i)=>{
var s,n=i(6847),l=i(83908),a=i(17409),o=i(46282),r=i(38836),h=i(86133),d=i(5494),c=i(85602),_=i(14897),u=i(3579),I=i(54151),m=i(81269);(0,
n.s_)(d.I.TitleTotalTip,o.Z.ui_character_newtotaltip).waitPrefab(o.Z.ui_character_newtitleattritem).layerTip().register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),
this._degf_OnClose=null,this._degf_OnTitleAttrInit=null}_initBinder(){super._initBinder(),this._degf_OnClose=(t,e)=>this.OnClose(t,e),
this._degf_OnTitleAttrInit=t=>this.OnTitleAttrInit(t)}InitView(){super.InitView(),(0,a.D1)(this,this.CreateDelegate(this.Close)),
this.titleGrid.SetInitInfo("ui_character_newtitleattritem",this._degf_OnTitleAttrInit)}Clear(){}Destroy(){}OnClose(t,e){_.L.Inst().Close()}Close(){_.L.Inst().Close()}
OnTitleAttrInit(t){const e=t[0].getCNode(m.$)
return e.setId(t[2],null,0),e}OnAddToScene(){this.SetData()}SetData(){const t=new c.Z,e=I.Y.Inst_get().TitleOwned_get(),i=I.Y.Inst_get().useAttrTitleId_get()
let s=null,n=0
for(;n<e.Count();){s=u.W.Inst().getItemById(e[n])
for(const[e,i]of(0,r.V5)(s.activeAttrs.attrs))this.RefreshDataLis(t,i)
n+=1}if(0!=i){s=u.W.Inst().getItemById(i)
for(const[e,i]of(0,r.V5)(s.wearAttrs.attrs))this.RefreshDataLis(t,i)}this.activeNum.textSet((0,h.T)("当前已点亮[5fb470]")+(e.Count()+(0,h.T)("[-]个称号，获得属性加成")))
const l=new c.Z
let a=0
for(;a<t.Count();)l.Add(t[a]),a+=1
this.titleGrid.data_set(l),this.bg.heightSet(99+25*t.Count())}RefreshDataLis(t,e){let i=!1,s=0
for(;s<t.Count();)t[s].intType==e.intType&&(t[s].value=t[s].value+e.value,i=!0),s+=1
i||t.Add(e.Clone())}})},32080:(t,e,i)=>{i.d(e,{V:()=>w})
var s,n=i(18998),l=i(83908),a=i(38935),o=i(85682),r=i(92679),h=i(87923),d=i(57079),c=i(14792),_=i(78592),u=i(50894),I=i(14897),m=i(54151),g=i(97461),p=i(9057),C=i(57834),S=i(98130),f=i(15831),T=i(9964),y=i(65550),A=i(6251),D=i(3579)
class E extends((0,l.pA)(p.x)()){constructor(...t){super(...t),this.titleId=0,this.model=null,this.isFirstShowNewSp=!1,this._degf_OnEquipClick=null,this._degf_OnItemClick=null,
this._degf_OnUseAttrClick=null,this._degf_RefreshSelectState=null}_initBinder(){super._initBinder(),this._degf_OnEquipClick=(t,e)=>this.OnEquipClick(t,e),
this._degf_OnItemClick=(t,e)=>this.OnItemClick(t,e),this._degf_OnUseAttrClick=(t,e)=>this.OnUseAttrClick(t,e),this._degf_RefreshSelectState=t=>this.RefreshSelectState(t)}
InitView(){super.InitView()}SetData(t){this.model=m.Y.Inst_get(),this.titleId=S.GF.INT(t),this.RemoveLis(),this.AddLis()
const e=D.W.Inst().getItemById(this.titleId)
this.CommonTitleItem.SetData(e),this.equipClickBg.node.SetActive(this.titleId==this.model.showTitleId),
this.useAttrClickBg.node.SetActive(this.titleId==this.model.useAttrTitleId_get()),this.selectBg.node.SetActive(!1)
const i=this.model.TitleOwned_get().IndexOf(this.titleId,0)<0
A.d.LuaMakeGoGray(this.CommonTitleItem.node,i)
const s=this.titleId==this.model.newGetTitleId
this.newSpr.SetActive(!1),s&&(this.model.newGetTitleId=-1,this.isFirstShowNewSp=!0,this.OnItemClick(0,0))}AddLis(){C.i.Get(this.bg.node).RegistonClick(this._degf_OnItemClick),
C.i.Get(this.equipBtn.node).RegistonClick(this._degf_OnEquipClick),C.i.Get(this.useAttrBtn.node).RegistonClick(this._degf_OnUseAttrClick),
g.i.Inst.AddEventHandler(r.g.TITLE_CLICK,this._degf_RefreshSelectState),this.RegGuide()}RemoveLis(){C.i.Get(this.bg.node).RemoveonClick(this._degf_OnItemClick),
C.i.Get(this.equipBtn.node).RemoveonClick(this._degf_OnEquipClick),C.i.Get(this.useAttrBtn.node).RemoveonClick(this._degf_OnUseAttrClick),
g.i.Inst.RemoveEventHandler(r.g.TITLE_CLICK,this._degf_RefreshSelectState),this.UnRegGuide()}RegGuide(){}UnRegGuide(){}RefreshSelectState(t){
this.selectBg.node.SetActive(this.titleId==m.Y.Inst_get().clickId),this.titleId,m.Y.Inst_get().clickId}OnItemClick(t,e){m.Y.Inst_get().clickId=this.titleId,I.L.Inst().OpenTip(),
g.i.Inst.RaiseEvent(r.g.TITLE_CLICK),u.k.inst.SetEffectOnHead(this.titleId),this.isFirstShowNewSp?(this.isFirstShowNewSp=!1,this.newSpr.SetActive(!0)):this.newSpr.SetActive(!1)}
OnEquipClick(t,e){if(h.l.CheckBtnClickTrigger(o.D.UI_ROLE_ATTR_TITLE_SHOW_BTN,this.titleId),this.model.TitleOwned_get().IndexOf(this.titleId,0)>=0){let t=null
this.titleId==this.model.showTitleId?(t=new T.o,t.titleId=this.titleId,t.isShow=!1,a.C.Inst.F_SendMsg(t)):(t=new T.o,t.titleId=this.titleId,t.isShow=!0,a.C.Inst.F_SendMsg(t))
}else y.y.inst.ClientSysMessage(170012)}OnUseAttrClick(t,e){let i=null
h.l.CheckBtnClickTrigger(o.D.UI_ROLE_ATTR_TITLE_USE_BTN,this.titleId),this.model.TitleOwned_get().IndexOf(this.titleId,0)>=0?this.titleId==this.model.useAttrTitleId_get()?(i=new f.t,
i.titleId=this.titleId,i.isLight=!1,a.C.Inst.F_SendMsg(i)):(i=new f.t,i.titleId=this.titleId,i.isLight=!0,a.C.Inst.F_SendMsg(i)):y.y.inst.ClientSysMessage(170011)}Clear(){
this.RemoveLis()}Destroy(){}}const{ccclass:v}=n._decorator
let w=v("TitleView")(s=class extends((0,l.Ri)()){constructor(t){super(t),this.hasInit=!1,this._degf_OnItemRefreshFun=null,this._degf_OnTotalTipClick=null,this.anchor=null,
this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),this._degf_OnTotalTipClick=(t,e)=>this.OnTotalTipClick(t,e)}InitView(){super.InitView(),
this.titleGrid.SetInitInfo("ui_character_titleitem",this.CreateDelegate(this.onReposition),E),this.titleGrid.OnReposition_set(this.CreateDelegate(this.onReposition))}
onReposition(){this.titleGrid.Reposition(),this.scrollView.ResetPosition()}OnItemRefreshFun(t){const e=t[0].getCNode(E)
return e.setId(t[2],null,0),e}OnAddToScene(){_.l.inst.SetRedPointId(c.t.ATTRIBUTE_TITLE),this.AddLis(),this.ShowTitleReq()}ShowTitleReq(){const t=new d.R
a.C.Inst.F_SendMsg(t)}SetData(){this.OnAddToScene(),this._OnUpdateAnchor()}_OnUpdateAnchor(){}UpdateGirdData(){this.titleGrid.Clear(),
this.titleGrid.data_set(m.Y.Inst_get().GetSortTitles())}AddLis(){this.totalTipBtn.node.on(n.NodeEventType.TOUCH_END,this._degf_OnTotalTipClick),
this.m_handlerMgr.AddEventMgr(r.g.TITLE_SHOW_UPDATE,this.CreateDelegate(this.TitleShowIdHandle)),
this.m_handlerMgr.AddEventMgr(r.g.TITLE_SWITCH,this.CreateDelegate(this.TitleSwitchHandle)),
this.m_handlerMgr.AddEventMgr(r.g.TITLE_LIGHT,this.CreateDelegate(this.TitleLightHandle)),
this.m_handlerMgr.AddEventMgr(r.g.UPDATE_ANCHORS,this.CreateDelegate(this._OnUpdateAnchor))}RemoveLis(){
this.totalTipBtn.node.off(n.NodeEventType.TOUCH_END,this._degf_OnTotalTipClick),this.m_handlerMgr.RemoveEventMgr(r.g.TITLE_SHOW_UPDATE,this.CreateDelegate(this.TitleShowIdHandle)),
this.m_handlerMgr.RemoveEventMgr(r.g.TITLE_SWITCH,this.CreateDelegate(this.TitleSwitchHandle)),
this.m_handlerMgr.RemoveEventMgr(r.g.TITLE_LIGHT,this.CreateDelegate(this.TitleLightHandle)),
this.m_handlerMgr.RemoveEventMgr(r.g.UPDATE_ANCHORS,this.CreateDelegate(this._OnUpdateAnchor))}OnTotalTipClick(t,e){h.l.CheckBtnClickTrigger(o.D.UI_ROLE_ATTR_TITLE_LOOK_BTN),
I.L.Inst().Open()}TitleLightHandle(t){this.UpdateGirdData()}TitleSwitchHandle(t){t.isShow?u.k.inst.SetEffectOnHead(t.titleId):u.k.inst.SetEffectOnHead(0),this.UpdateGirdData()}
TitleShowIdHandle(t){m.Y.Inst_get().showIdLis=t.showTitles,this.UpdateGirdData()}Clear(){this.RemoveLis(),
0==m.Y.Inst_get().showTitleId?u.k.inst.SetEffectOnHead(0):u.k.inst.SetEffectOnHead(m.Y.Inst_get().showTitleId)}Destroy(){}})||s},14143:(t,e,i)=>{i.d(e,{L:()=>s})
class s{static GetChannel(t){return 0==t?s.TOTAL:1==t?s.SYSTEM:2==t?s.WORLD:3==t?s.ALLIANCE:4==t?s.CROSS_SERVER:5==t?s.STALL:-1}static IsSystem(t){
return t==s.SYSTEM||t==s.INVITE_TEAM||t==s.NOTICE}}s.TOTAL=-1,s.WORLD=0,s.NEARBY=1,s.TEAM=2,s.ALLIANCE=3,s.LEGION=4,s.PRIVATE=5,s.HORN=6,s.CROSS_SERVER=7,s.STALL=8,s.SYSTEM=100,
s.INVITE_TEAM=101,s.NOTICE=102,s.MAIL=500,s.VOICE_WORLD=1e3,s.VOICE_TEAM=1002,s.VOICE_ALLIANCE=1003},16459:(t,e,i)=>{i.d(e,{F:()=>s})
var s={UPDATE_CHAT:"update_chat",SELECT_FACE:"select_face",SELECT_HORN_FACE:"select_horn_face",SEND_ITEM_TO_CHAT:"send_item_to_chat",RETURN_QUERY_ACCOUNT:"return_query_account",
SELECT_CHAT_MENU_ITEM:"select_chat_menu_item",CLICK_NAME_LINK:"click_name_link",CLICK_PRIVATE_LIST_CELL:"click_private_list_cell",SHOW_HORN_MESSAGE:"SHOW_HORN_MESSAGE",
SELECT_ONE_PRIVATE_PLAYER:"SELECT_ONE_PRIVATE_PLAYER",UPDATE_PRIVATE_ONLINE_STATUS:"UPDATE_PRIVATE_ONLINE_STATUS",QUERY_CHAT_HEAD_INFO:"QUERY_CHAT_HEAD_INFO",
UPDATE_PRIVATE_NAME_BTN:"UPDATE_PRIVATE_NAME_BTN",SHOW_ONE_SIMPLE_NOTICE:"SHOW_ONE_SIMPLE_NOTICE",CHANGE_SHOW_CHANNEL:"CHANGE_SHOW_CHANNEL",
SEND_CHAT_ASURAM_I18:"SEND_CHAT_ASURAM_I18",SEND_CHAT_ASURAM_ASSIST_I18:"SEND_CHAT_ASURAM_ASSIST_I18",SEND_CHAT_ASURAM_GOBLIN_ASSIST_I18:"SEND_CHAT_ASURAM_GOBLIN_ASSIST_I18"}},
64444:(t,e,i)=>{i.d(e,{B:()=>s})
var s={PLAYER:3,ITEM:4,GUARD:5,ASURAM_INVITE:8,POINT:100,TEAM:101,UI_OPEN:102,TASK:103,ASURAM_BOSS:104,RED_PACKET:105,VIRTUAL_ITEM:106,ALLIANCE_ENTRUST_HOME:107,BOSS_ASSIST:108,
MINE_ASSIST:109,Goblin_Position:110,STALL_AD_ITEM:111,STALL_AD_STALLNAME:112,ALLIANCE_ASSIST:113,SHOW_EQUIP:114,ALLIANCE_HOME:115}},83388:(t,e,i)=>{i.d(e,{z:()=>s})
var s={CHAT:0,PERSON:1,MAIL:2}},26753:(t,e,i)=>{i.d(e,{d:()=>gt})
var s=i(13612),n=i(17409),l=i(38836),a=i(98800),o=i(97461),r=i(85682),h=i(56937),d=i(18202),c=i(31222),_=i(5494),u=i(52726),I=i(98789),m=i(95721),g=i(98885),p=i(85602),C=i(79534),S=i(85430),f=i(43076),T=i(92679),y=i(57940),A=i(94826),D=i(37648),E=i(55492),v=i(84632),w=i(14792),R=i(62734),P=i(14143),O=i(16459),L=i(83388)
class B{constructor(t,e,i){this.type=0,this.index=0,this.content=null,this.type=t,this.index=e,this.content=i}}B.MENU_PRIVATE=1,B.MENU_PLAYER_LINK=2
var b=i(64290),M=i(86133),G=i(38045),H=i(9986),N=i(69029),k=i(93877),U=i(61911),V=i(87923),x=i(22662),F=i(65550)
class q extends U.f{constructor(){super(),this.sureBtn=null,this.cancelBtn=null,this.closelBtn=null,this.input=null,this.m_valueStr=null,this.m_price=0,this.m_monetType=null,
this._degf_OnBtnClick=null,this._degf_OnConsumeDiamondOk=null,this._degf_OnLayerMaskShow=null,this.returnLabel=null,this._degf_OnBtnClick=(t,e)=>this.OnBtnClick(t,e),
this._degf_OnConsumeDiamondOk=t=>this.OnConsumeDiamondOk(t),this._degf_OnLayerMaskShow=t=>this.OnLayerMaskShow(t)}InitView(){this.sureBtn=new H.W,
this.sureBtn.setId(this.FatherId,this.FatherComponentID,1),this.cancelBtn=new H.W,this.cancelBtn.setId(this.FatherId,this.FatherComponentID,2),this.closelBtn=new H.W,
this.closelBtn.setId(this.FatherId,this.FatherComponentID,3),this.input=new N.z,this.input.setId(this.FatherId,this.FatherComponentID,4),this.returnLabel=new k.Q,
this.returnLabel.setId(this.FatherId,this.FatherComponentID,5)}OnAddToScene(){this.AddOrDelEvent(!0)}AddOrDelEvent(t){t?(this.AddClickEvent(this.sureBtn,this._degf_OnBtnClick),
this.AddClickEvent(this.cancelBtn,this._degf_OnBtnClick),this.AddClickEvent(this.closelBtn,this._degf_OnBtnClick),
o.i.Inst.AddEventHandler(T.g.SHOW_MASK_LAYER,this._degf_OnLayerMaskShow)):(this.RemoveClickEvent(this.sureBtn,this._degf_OnBtnClick),
this.RemoveClickEvent(this.cancelBtn,this._degf_OnBtnClick),this.RemoveClickEvent(this.closelBtn,this._degf_OnBtnClick),
o.i.Inst.RemoveEventHandler(T.g.SHOW_MASK_LAYER,this._degf_OnLayerMaskShow))}OnLayerMaskShow(t){gt.Inst_get().controller.CloseHornPanel()}OnBtnClick(t,e){
if(t==this.sureBtn.ComponentId){if(this.m_valueStr=this.input.GetText(),V.l.IsEmptyStr(this.m_valueStr))return void F.y.inst.ClientStrMsg(x.r.SystemTipMessage,(0,M.T)("请输入发送内容"))
const t=this.m_valueStr,e=load(t)
if(null==e)return void F.y.inst.ClientStrMsg(x.r.SystemTipMessage,(0,M.T)("输入代码有错"))
const i=e()
null!=i&&this.returnLabel.textSet((0,G.tw)(i)),F.y.inst.ClientStrMsg(x.r.SystemTipMessage,(0,M.T)("执行完毕"))
}else(t==this.cancelBtn.ComponentId||t==this.closelBtn.ComponentId)&&this.Close()}Close(){gt.Inst_get().controller.CallDebugDestory()}Clear(){this.AddOrDelEvent(!1)}Destroy(){
this.sureBtn=null,this.cancelBtn=null,this.closelBtn=null,this.input=null}}var Y=i(70850),W=i(74045),j=i(39879),Z=i(49067),X=i(35037),K=i(33828),$=i(39043),J=i(19519),z=i(98407)
class Q extends U.f{constructor(){super(),this.sureBtn=null,this.cancelBtn=null,this.closelBtn=null,this.input=null,this.costLabel=null,this.m_valueStr=null,this.m_price=0,
this.m_monetType=null,this._degf_OnBagUpdate=null,this._degf_OnBtnClick=null,this._degf_OnConsumeDiamondOk=null,this._degf_OnLayerMaskShow=null,
this._degf_OnBagUpdate=t=>this.OnBagUpdate(t),this._degf_OnBtnClick=(t,e)=>this.OnBtnClick(t,e),this._degf_OnConsumeDiamondOk=t=>this.OnConsumeDiamondOk(t),
this._degf_OnLayerMaskShow=t=>this.OnLayerMaskShow(t)}InitView(){this.sureBtn=new H.W,this.sureBtn.setId(this.FatherId,this.FatherComponentID,1),this.cancelBtn=new H.W,
this.cancelBtn.setId(this.FatherId,this.FatherComponentID,2),this.closelBtn=new H.W,this.closelBtn.setId(this.FatherId,this.FatherComponentID,3),this.input=new N.z,
this.input.setId(this.FatherId,this.FatherComponentID,4),this.costLabel=new k.Q,this.costLabel.setId(this.FatherId,this.FatherComponentID,5)}OnAddToScene(){
this.input.SetCharacterLimit(100),this.AddOrDelEvent(!0),this.OnBagUpdate(null)}AddOrDelEvent(t){t?(this.AddClickEvent(this.sureBtn,this._degf_OnBtnClick),
this.AddClickEvent(this.cancelBtn,this._degf_OnBtnClick),this.AddClickEvent(this.closelBtn,this._degf_OnBtnClick),o.i.Inst.AddEventHandler(T.g.BAG_UPDATE,this._degf_OnBagUpdate),
o.i.Inst.AddEventHandler(T.g.SHOW_MASK_LAYER,this._degf_OnLayerMaskShow)):(this.RemoveClickEvent(this.sureBtn,this._degf_OnBtnClick),
this.RemoveClickEvent(this.cancelBtn,this._degf_OnBtnClick),this.RemoveClickEvent(this.closelBtn,this._degf_OnBtnClick),
o.i.Inst.RemoveEventHandler(T.g.BAG_UPDATE,this._degf_OnBagUpdate),o.i.Inst.RemoveEventHandler(T.g.SHOW_MASK_LAYER,this._degf_OnLayerMaskShow))}OnLayerMaskShow(t){
gt.Inst_get().controller.CloseHornPanel()}OnBagUpdate(t){const e=Y.g.Inst_get().GetItemNum(s.k.HORN_ITEM_ID)
let i=g.M.IntToString(e)
e<1?i=V.l.SetStringColor(V.l.txtRedStr,i):e>999&&(i="999"),this.costLabel.textSet(`${i}/1`)}OnBtnClick(t,e){if(t==this.sureBtn.ComponentId){if(this.m_valueStr=this.input.GetText(),
V.l.IsEmptyStr(this.m_valueStr))return void F.y.inst.ClientStrMsg(x.r.SystemTipMessage,(0,M.T)("请输入发送内容"))
if(!gt.Inst_get().model.channelModel.IsCanSend(P.L.HORN))return
if(Y.g.Inst_get().GetItemNum(s.k.HORN_ITEM_ID)<1){const t=X.L.GetInst().GetCfgByItemId(s.k.HORN_ITEM_ID),e=X.L.GetInst().GetCfgById(t.id)
this.m_monetType=e.consums.costs[0].subtype,this.m_price=g.M.String2Int(e.consums.costs[0].subvalue)
const i="CHAT:DIAMOND_FOR_HORN"
if($.V.Inst_get().GetData($.V.Inst_get().GetRolePrefix()+i))this.OnConsumeDiamondOk(null)
else{j.L.Inst().getItemById(i)
const t=new Z.B
t.isJudgeSafeLock=!0,t.infoId=i,t.confirmHandle=this._degf_OnConsumeDiamondOk,t.layer=u.F.Tip,t.replaceParams.Add("1"),t.replaceParams.Add(e.consums.costs[0].subvalue),
W.t.Inst().Open(t)}return}z.C.SendToHorn(P.L.HORN,this.m_valueStr,this.m_valueStr,null),this.Close()
}else(t==this.cancelBtn.ComponentId||t==this.closelBtn.ComponentId)&&this.Close()}Close(){gt.Inst_get().controller.CloseHornPanel()}OnConsumeDiamondOk(t){
J.J.IsMoneyEnough(this.m_monetType,this.m_price)?z.C.SendToHorn(P.L.HORN,this.m_valueStr,this.m_valueStr,null):K.Y.Inst_get().Open(),this.Close()}Clear(){this.AddOrDelEvent(!1)}
Destroy(){this.sureBtn=null,this.cancelBtn=null,this.closelBtn=null,this.input=null,this.costLabel=null}}var tt=i(6665),et=i(75696),it=i(4586),st=i(79878),nt=i(17783),lt=i(98580)
class at extends U.f{constructor(){super(),this.taskNameTxt=null,this.targetTxt=null,this.describeTxt=null,this.rewardGrid=null,this.m_curConfig=null,this.m_asuramCfg=null,
this.m_extendId=0,this._degf_OnFullClick=null,this._degf_OnGetRewardItem=null,this._degf_OnFullClick=(t,e)=>this.OnFullClick(t,e),
this._degf_OnGetRewardItem=t=>this.OnGetRewardItem(t)}InitView(){this.taskNameTxt=new k.Q,this.taskNameTxt.setId(this.FatherId,this.FatherComponentID,1),this.targetTxt=new k.Q,
this.targetTxt.setId(this.FatherId,this.FatherComponentID,2),this.describeTxt=new k.Q,this.describeTxt.setId(this.FatherId,this.FatherComponentID,3),this.rewardGrid=new tt.A,
this.rewardGrid.setId(this.FatherId,this.FatherComponentID,4),this.rewardGrid.SetInitInfo("ui_baseitem",this._degf_OnGetRewardItem)}OnGetRewardItem(t){const e=new et.j
return e.setId(t,null,0),e}OnAddToScene(){const t=gt.Inst_get().controller.tId
this.m_curConfig=nt.L.Inst_get().model.GetTaskById(t),this.m_extendId=gt.Inst_get().controller.extendId
const e=this.m_curConfig.status_get()
this.m_curConfig.status_set(lt.B.ACCEPTED),this.taskNameTxt.textSet(it.G.CutColorStr(this.m_curConfig.taskName_get())),
this.rewardGrid.data_set(this.m_curConfig.GetAllRewardList(!1)),this.SetDetailTxt(),this.AddFullScreenCollider(this.node,this._degf_OnFullClick),this.m_curConfig.status_set(e)}
SetDetailTxt(){let t=null
t=this.GetLinkInfo(this.m_curConfig,this.m_extendId)
let e=""
null!=t.txtStr&&(e+=t.txtStr),null!=t.progresStr&&(e+=`（${t.progresStr}）`),t.Clear(),this.targetTxt.textSet(it.G.CutColorStr(e))}GetLinkInfo(t,e){let i=""
i=t.resource_get().underwayText
return st.Y.SetDetailInfo(t,i)}OnFullClick(t,e){c.N.inst.CloseById(_.I.eChatTaskDetailPanel)}Clear(){this.m_curConfig=null,this.RemoveFullScreenCollider()}Destroy(){
this.taskNameTxt=null,this.targetTxt=null,this.describeTxt=null,this.rewardGrid.Destroy(),this.rewardGrid=null}}var ot=i(50018),rt=i(5924),ht=i(84193),dt=i(72005),ct=i(98130)
class _t extends U.f{constructor(){super(),this.chatLabel=null,this.faceLabel=null,this.bgSp=null,this.m_vo=null,this.m_timerId=0,this._degf_DoShow=null,
this._degf_OnReceiveNotice=null,this._degf_DoShow=()=>this.DoShow(),this._degf_OnReceiveNotice=t=>this.OnReceiveNotice(t)}InitView(){this.chatLabel=new k.Q,
this.chatLabel.setId(this.FatherId,this.FatherComponentID,1),this.faceLabel=new ht.n,this.faceLabel.setId(this.FatherId,this.FatherComponentID,2),this.bgSp=new dt.w,
this.bgSp.setId(this.FatherId,this.FatherComponentID,3),this.bgSp.node.SetActive(!1),A.C.Inst_get().RegisterObj(y.k.simpleNotice,this.node)}OnAddToScene(){this.AddOrDelEvent(!0),
this.faceLabel.SetTxt("")}AddOrDelEvent(t){
t?gt.Inst_get().model.AddEventHandler(O.F.SHOW_ONE_SIMPLE_NOTICE,this._degf_OnReceiveNotice):gt.Inst_get().model.RemoveEventHandler(O.F.SHOW_ONE_SIMPLE_NOTICE,this._degf_OnReceiveNotice)
}OnReceiveNotice(t){const e=t
null!=this.m_vo?(this.m_vo.isSystemMsg?e.isSystemMsg&&(this.m_vo=e):this.m_vo=e,this.ShowContent()):(this.m_vo=e,this.ShowContent())}ShowContent(){
this.m_timerId>0&&rt.C.Inst_get().ClearInterval(this.m_timerId),this.faceLabel.Clear(),this.faceLabel.SetTxt(this.m_vo.noticeStr)
const t=this.chatLabel.printedSize().x
this.bgSp.widthSet(ct.GF.INT(t+140))
const e=this.chatLabel.node.transform.GetLocalPosition()
e.x=.5*-t,this.chatLabel.node.transform.SetLocalPosition(e),C.P.Recyle(e),this.m_timerId=rt.C.Inst_get().SetInterval(this._degf_DoShow,4e3,1),this.bgSp.node.SetActive(!0)}DoShow(){
this.faceLabel.Clear(),this.faceLabel.SetTxt(""),this.bgSp.widthSet(2),this.m_vo=null,this.m_timerId=0,this.bgSp.node.SetActive(!1)}Clear(){this.AddOrDelEvent(!1),
this.m_timerId>0&&rt.C.Inst_get().ClearInterval(this.m_timerId),A.C.Inst_get().UnregisterObj(y.k.simpleNotice)}Destroy(){this.chatLabel=null,this.faceLabel.Clear(),
this.faceLabel.Destory(),this.faceLabel=null,this.bgSp=null}}var ut=i(49655)
class It{constructor(){this.m_showPanel=null,this.m_mainPanel=null,this.IsOpenMail=!1,this.m_channel=-1,this.openTxt=null,this.type=-1,this.m_simplePanel=null,this.m_copyTip=null,
this.copyTipShowStr=null,this.m_hornPanel=null,this.m_taskPanel=null,this.tId=0,this.extendId=0,this.roundStep=0,this.m_voicePanel=null,this.relateTran=null,this.sendChannel=0,
this.isShowPanel=!1,this.microIndex=0,this.isChannelTab=!1,this.debugPanel=null,this._degf_CallCoptTipDestory=null,this._degf_CallDestory=null,this._degf_CallHornDestory=null,
this._degf_CallMainDestory=null,this._degf_CallSimpleDestory=null,this._degf_CallTaskDestory=null,this._degf_CallVoiceDestory=null,this._degf_OnCoptTipShowComplete=null,
this._degf_OnHornShowComplete=null,this._degf_OnMainPanelShowComplete=null,this._degf_OnShowComplete=null,this._degf_OnSimpleShowComplete=null,this._degf_OnTaskShowComplete=null,
this._degf_OnVoiceShowComplete=null,this._degf_OnDebugShowComplete=null,this._degf_CallDebugDestory=null,this.m_privateSenderId=null,this.searchPlayerPanel=null,
this._degf_CallCoptTipDestory=()=>this.CallCoptTipDestory(),this._degf_CallDestory=()=>this.CallDestory(),this._degf_CallHornDestory=()=>this.CallHornDestory(),
this._degf_CallMainDestory=()=>this.CallMainDestory(),this._degf_CallSimpleDestory=()=>this.CallSimpleDestory(),this._degf_CallTaskDestory=()=>this.CallTaskDestory(),
this._degf_CallVoiceDestory=()=>this.CallVoiceDestory(),this._degf_OnCoptTipShowComplete=t=>this.OnCoptTipShowComplete(t),
this._degf_OnHornShowComplete=t=>this.OnHornShowComplete(t),this._degf_OnMainPanelShowComplete=t=>{},this._degf_OnShowComplete=t=>{},
this._degf_OnSimpleShowComplete=t=>this.OnSimpleShowComplete(t),this._degf_OnTaskShowComplete=t=>this.OnTaskShowComplete(t),
this._degf_OnVoiceShowComplete=t=>this.OnVoiceShowComplete(t),this._degf_OnDebugShowComplete=t=>this.OnDebugShowComplete(t),this._degf_CallDebugDestory=()=>this.CallDebugDestory()}
SendToPrivate(t){const e=new B(B.MENU_PRIVATE,0,t)
gt.Inst_get().model.RaiseEvent(O.F.SELECT_CHAT_MENU_ITEM,e)}DealLinkStr(t,e,i){let s="[key][/key]",n=0
for(const[a,o]of(0,l.vy)(t))g.M.IndexOf(i,a,0)>-1&&(s=`[key]${n}[/key]`,i=g.M.ReplaceSlow(i,a,s),e.LuaDic_AddOrSetItem(s,t[a]),n+=1)
if(n>0){for(const[t,s]of(0,l.vy)(e))i=g.M.ReplaceSlow(i,t,e[t])
e.LuaDic_Clear()}return i}ForceCloseForMapJudge(t){null!=this.m_showPanel&&(null==t&&(t=!1),t||this.m_showPanel.node.SetActive(!1))}CloseBuffTip(){
null!=this.m_showPanel&&this.m_showPanel.CloseBuffTip()}ForceOpenForMapJudge(){null!=this.m_showPanel&&(0,n.qJ)(ut.o.ChatShowPanel)&&(this.m_showPanel.node.SetActive(!0),
this.m_showPanel.DoRefresh(!0),this.m_showPanel.ChangeMicroBtn(!1))}OpenPanel(){const t=new h.v
t.positionType=I.$.eCustom,t.layerType=u.F.DefaultUI,t.ReLoginOrChangeRoleIsDestroy=!1,(0,n.Yp)(ut.o.eChatShowPanel,t)}showPanel_get(){return this.m_showPanel}IsCanCrossServer(){
return D.P.Inst_get().IsFunctionOpened(E.x.CROSS_CHAT)}CallDestory(){d.g.DestroyUIObj(this.m_showPanel),this.m_showPanel=null}ChangeChatShowState(t){
null!=this.m_showPanel&&this.m_showPanel.ChangeState(t)}CheckShowPanelRedDot(){null!=this.m_showPanel&&this.m_showPanel.CheckRedShow()}ShowPopupTxt(t){
null!=this.m_showPanel&&this.m_showPanel.ShowPopupTxt(t)}HideAlliancePopup(){null!=this.m_showPanel&&this.m_showPanel.HideAlliancePopup()}ChatMainPanel_get(){return(0,
n.Y)(ut.o.eChatMainPanel)}PrivateChat(t,e,i,s,n){const l=gt.Inst_get().model.privateModel
null==s&&(s=1e3),null==n&&(n=0),l.PrivateChatParm_senderID=e,l.PrivateChatParm_senderName=t,l.PrivateChatParm_receiverIsOnline=i,l.PrivateChatParm_job=s,l.PrivateChatParm_sex=n,
null!=this.m_mainPanel&&this.m_mainPanel.isShow_get()?this.ChatMainPanel_get().ChangeToPrivateChat(t,e,i,s,n):this.OpenMainPanel(!1,!0,null)}PrivateChatRoleInfo(t,e){
const i=t.mainroleId_get(),s=a.Y.Inst.getRoleInfo(i)
null!=s?this.PrivateChat(s.Name_get(),s.Id_get(),e,s.Job_get(),s.Sex_get()):m.o.IsNullOrZero(i)?this.PrivateChat(t.Name_get(),t.Id_get(),e,t.Job_get(),t.Sex_get()):this.PrivateChat(t.Name_get(),i,e,t.Job_get(),t.Sex_get())
}PrivateChatDefault(){const t=gt.Inst_get().model.privateModel.GetPrivateModes()
let e=null,i=!1,s=0
for(;s<t.Count();){if(e=t[s],e.hasNew){i=!0,this.PrivateChat(e.m_name,e.m_objId,e.receiverIsOnline,e.job,e.sex)
break}s+=1}i||this.OpenMainPanel(!1,!0,null)}OpenByChannel(t,e){gt.Inst_get().controller.type=L.z.CHAT,gt.Inst_get().controller.m_channel=t,gt.Inst_get().controller.openTxt=e,
gt.Inst_get().controller.IsOpenMail=!1,gt.Inst_get().model.privateModel.isNeedOpenPrivateChat=!1,this.RealOpen()}OpenByUIID(t){let e=-1
t==r.D.ChatChannelTotal?e=P.L.TOTAL:t==r.D.ChatChannelSystem?e=P.L.SYSTEM:t==r.D.ChatChannelWorld?e=P.L.WORLD:t==r.D.ChatChannelNearby?e=P.L.NEARBY:t==r.D.ChatChannelTeam?e=P.L.TEAM:t==r.D.ChatChannelAlliance&&(e=P.L.ALLIANCE),
gt.Inst_get().controller.m_channel=e,this.OpenMainPanel(null,null,null)}OpenMainPanel(t,e=null,i=null){if(null==i&&(i=!1),null==e&&(e=!1),null==t&&(t=!1),!t&&!e){
const t=R.f.Inst.GetData(w.t.CHAT_TEAM),i=R.f.Inst.GetData(w.t.CHAT_ASURAM)
if(t&&t.show)gt.Inst_get().controller.type=L.z.CHAT,gt.Inst_get().controller.m_channel=P.L.TEAM
else if(i&&i.show)gt.Inst_get().controller.type=L.z.CHAT,gt.Inst_get().controller.m_channel=P.L.ALLIANCE
else{const t=gt.Inst_get().model.privateModel.GetPrivateModes()
let i=null,s=0
for(;s<t.Count();){if((s!=gt.Inst_get().model.m_curPriNameIndex||gt.Inst_get().model.curChannel!=P.L.PRIVATE)&&(i=t[s],i.hasNew)){gt.Inst_get().controller.type=L.z.PERSON,
gt.Inst_get().model.curChannel=P.L.PRIVATE,gt.Inst_get().model.privateModel.PrivateChatParm_senderName=null,e=!0
break}s+=1}}}if(S.a.isInAllianceBossMap_get()&&f.w.Inst_get().checkInActivity()&&(gt.Inst_get().controller.type=L.z.CHAT,gt.Inst_get().controller.m_channel=P.L.ALLIANCE),
t&&(gt.Inst_get().controller.type=L.z.MAIL),gt.Inst_get().model.privateModel.isNeedOpenPrivateChat=e,this.IsOpenMail=t,
this.IsOpenMail&&null!=this.m_mainPanel&&this.m_mainPanel.isShow_get()&&!i)return void this.m_mainPanel.OpenMail()
if(null!=this.m_mainPanel&&this.m_mainPanel.isShow_get()&&!i)return void this.m_mainPanel.CloseTween()
new p.Z([u.F.Tip,u.F.Msg])
this.RealOpen()}RealOpen(){const t=new h.v
t.layerType=u.F.Alert,t.isDefaultUITween=!0,t.isSelfTween=!1,t.ReLoginOrChangeRoleIsDestroy=!1,(0,n.Yp)(ut.o.eChatMainPanel,t)}CloseMainPanelByTween(){
null!=this.m_mainPanel&&this.m_mainPanel.isShow_get()&&this.m_mainPanel.CloseTween()}OnMainPanelShowComplete(t){return null==this.m_mainPanel&&((0,n.Yp)(ut.o.eChatMainPanel,null),
this.m_mainPanel=(0,n.Y)(ut.o.eChatMainPanel)),this.m_mainPanel}CallMainDestory(){v.R.GetInst().CloseMailDetailPanel(),v.R.GetInst().CloseMailMainPanel(),this.m_mainPanel=null}
CloseMainPanel(){v.R.GetInst().CloseMailDetailPanel(),v.R.GetInst().detailView=null,v.R.GetInst().CloseMailMainPanel(),v.R.GetInst().mainView=null,(0,n.Y)(ut.o.eChatMainPanel)&&(0,
n.sR)(ut.o.eChatMainPanel)}DealSimpleNoticePanel(t,e){
t.param_get().isShowMask&&t.param_get().layerType==u.F.MainUI&&(e?gt.Inst_get().controller.OpenSimplePanel(t):gt.Inst_get().controller.CloseSimplePanel(),
o.i.Inst.RaiseEvent(T.g.SHOW_MASK_LAYER,e))}OpenSimplePanel(t){if(t.uId==_.I.eDialoguePanel)return
null!=this.m_simplePanel&&A.C.Inst_get().SetActiveById(y.k.simpleNotice,!0,null)
const e=new h.v
e.positionType=I.$.eCustom,e.layerType=u.F.Tip,c.N.inst.OpenById(_.I.ChatSimplePanelId,this._degf_OnSimpleShowComplete,this._degf_CallSimpleDestory,e)}OnSimpleShowComplete(t){
return null==this.m_simplePanel&&(this.m_simplePanel=new _t,this.m_simplePanel.setId(t,null,0)),this.m_simplePanel}CallSimpleDestory(){d.g.DestroyUIObj(this.m_simplePanel),
this.m_simplePanel=null}CloseSimplePanel(){null!=this.m_simplePanel&&A.C.Inst_get().SetActiveById(y.k.simpleNotice,!1,null)}ResetSimplePanel(){
null!=this.m_simplePanel&&c.N.inst.CloseById(_.I.ChatSimplePanelId)}OpenCopyTip(t,e){if(this.copyTipShowStr=e,null==this.m_copyTip){const e=new h.v
e.positionType=I.$.eCustom,e.layerType=u.F.Tip,e.pos=t,(0,n.Yp)(ut.o.ChatCopyTipId,e)}else this.m_copyTip.node.transform.SetLocalPosition(t)}OnCoptTipShowComplete(t){
return null==this.m_copyTip&&(this.m_copyTip=new b.l,this.m_copyTip.setId(t,null,0)),this.m_copyTip}CallCoptTipDestory(){d.g.DestroyUIObj(this.m_copyTip),this.m_copyTip=null}
CloseCopyTip(){null!=this.m_copyTip&&(this.copyTipShowStr=null,(0,n.sR)(_.I.ChatCopyTipId),this.m_copyTip=null)}OpenHornPanel(){if(null==this.m_hornPanel){const t=new h.v
t.isShowMask=!0,t.isSelfTween=!1,t.layerType=u.F.Tip,c.N.inst.OpenById(_.I.eChatHornPanel,this._degf_OnHornShowComplete,this._degf_CallHornDestory,t)}}OnHornShowComplete(t){
return null==this.m_hornPanel&&(this.m_hornPanel=new Q,this.m_hornPanel.setId(t,null,0)),this.m_hornPanel}CallHornDestory(){d.g.DestroyUIObj(this.m_hornPanel),this.m_hornPanel=null
}CloseHornPanel(){c.N.inst.CloseById(_.I.eChatHornPanel)}OpenTaskPanel(t,e,i){if(this.tId=t,this.extendId=e,this.roundStep=i,null==this.m_taskPanel){const t=new h.v
t.isSelfTween=!1,t.layerType=u.F.Tip,c.N.inst.OpenById(_.I.eChatTaskDetailPanel,this._degf_OnTaskShowComplete,this._degf_CallTaskDestory,t)}}OnTaskShowComplete(t){
return null==this.m_taskPanel&&(this.m_taskPanel=new at,this.m_taskPanel.setId(t,null,0)),this.m_taskPanel}CloseTaskDetailPanel(){c.N.inst.CloseById(_.I.eChatTaskDetailPanel)}
CallTaskDestory(){d.g.DestroyUIObj(this.m_taskPanel),this.m_taskPanel=null}OpenVoicePanel(t,e,i,s,l){if(null==i&&(i=!1),this.sendChannel=t,this.isShowPanel=i,this.relateTran=e,
this.microIndex=s,this.m_privateSenderId=l,null==this.m_voicePanel){const t=new h.v
t.isSelfTween=!1,t.layerType=u.F.Tip,(0,n.Yp)(ut.o.eChatVoicePanel,t)}}CloseVoicePanel(){null!=this.m_voicePanel&&(this.m_voicePanel.DealSend(),
c.N.inst.CloseById(_.I.eChatVoicePanel))}OnVoiceShowComplete(t){return null==this.m_voicePanel&&(this.m_voicePanel=new ot.f,this.m_voicePanel.setId(t,null,0)),this.m_voicePanel}
CallVoiceDestory(){d.g.DestroyUIObj(this.m_voicePanel),this.m_voicePanel=null}OpenDebug(){if(null==this.debugPanel){const t=new h.v
t.isShowMask=!0,t.isSelfTween=!1,t.layerType=u.F.Tip,c.N.inst.OpenById(_.I.eChatDebug,this._degf_OnDebugShowComplete,this._degf_CallDebugDestory,t)}}OnDebugShowComplete(t){
if(null==this.debugPanel){this.debugPanel=new q,this.debugPanel.setId(t,null,0)}return this.debugPanel}CallDebugDestory(){d.g.DestroyUIObj(this.debugPanel),this.debugPanel=null}
CloseDebugPanel(){c.N.inst.CloseById(_.I.eChatDebug)}OpenSearchPanel(){if(null==this.debugPanel){const t=new h.v
t.isShowMask=!0,t.isSelfTween=!1,t.layerType=u.F.Tip,(0,n.Yp)(ut.o.RySearchPlayerPanel,t)}}CallSearchDestory(){d.g.DestroyUIObj(this.searchPlayerPanel),this.searchPlayerPanel=null}
CloseSearchPanel(){(0,n.sR)(ut.o.RySearchPlayerPanel)}GetChatTipPosition(){return this.m_showPanel?this.m_showPanel.iconTipsPosition:C.P.zero_get()}IsChannelTab(){
return this.isChannelTab}GetBagPosition(){return this.m_showPanel?this.m_showPanel.iconTipsPosition:C.P.zero_get()}RefreshPrivateBtnSelectStatus(){
let t=this.m_mainPanel.personNameGrid.itemList,e=gt.Inst_get().model.privateModel.GetCurPrivateList()
for(let i=0;i<t.Count();i++)t[i].m_info.m_objId==e.m_objId?t[i].SetBgStatus(!0):t[i].SetBgStatus(!1)}}var mt=i(68323)
class gt{constructor(){this.model=null,this.controller=null,this.mgr=null,this.model=new s.k,this.controller=new It,this.mgr=mt.e.GetInst()}static Inst_get(){
return null==gt._mInst&&(gt._mInst=new gt),gt._mInst}}gt._mInst=null},68323:(t,e,i)=>{i.d(e,{e:()=>H})
var s,n,l,a,o,r,h,d=i(42292),c=i(71409),_=i(86133),u=i(98800),I=i(38935),m=i(66788),g=i(95721),p=i(98885),C=i(38962),S=i(72739),f=i(70012),T=i(40331),y=i(80881),A=i(58077),D=i(17210),E=i(700),v=i(58458),w=i(92415),R=i(95802),P=i(6719),O=i(65550),L=i(14143),B=i(16459),b=i(37949),M=i(26753)
function G(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let H=(s=(0,c.GH)(w.k.SM_ScanPlayerOtherBaseInfoResult),n=(0,c.GH)(w.k.SM_ShowAccount),l=(0,c.GH)(w.k.SM_Chat),a=(0,
c.GH)(w.k.SM_CrossChat),o=(0,c.GH)(w.k.SM_ChatVoice),h=class t{static GetInst(){return null==t._inst&&(t._inst=new t),t._inst}constructor(){this.m_model=null,this.m_handlers=null,
this.m_mainHandlers=null,this._degf_SM_ChatHandler=null,this._degf_SM_CrossChatHandler=null,this._degf_SM_ChatVoiceHandler=null,this._degf_SM_ScanPlayerOtherBaseInfoHandler=null,
this._degf_SM_ShowAccountHandler=null,this.sendTime=null,this.isworld=null,this.m_handlers=new C.X,this.m_mainHandlers=new C.X,this._degf_SM_ChatHandler=t=>this.SM_ChatHandler(t),
this._degf_SM_CrossChatHandler=t=>this.SM_CrossChatHandler(t),this._degf_SM_ChatVoiceHandler=t=>this.SM_ChatVoiceHandler(t),
this._degf_SM_ScanPlayerOtherBaseInfoHandler=t=>this.SM_ScanPlayerOtherBaseInfoHandler(t),this._degf_SM_ShowAccountHandler=t=>this.SM_ShowAccountHandler(t)}RegisterMsg(){}
SM_ScanPlayerOtherBaseInfoHandler(t){const e=t
M.d.Inst_get().model.RaiseEvent(B.F.QUERY_CHAT_HEAD_INFO,e)}SM_ShowAccountHandler(t){const e=t
M.d.Inst_get().model.DealNameQuery(e.infos)}SM_ChatHandler(t){const e=t,i=b.$.GetInst(e)
i.isSystemInfo=L.L.IsSystem(i.smChat.channelId),M.d.Inst_get().model.AddChat(i,null)}SM_CrossChatHandler(t){u.Y.Inst.PrimaryRoleInfo_get().ServerName_get(),
u.Y.Inst.PrimaryRoleInfo_get()
const e=t,i=e.chatVOS
let s=0
for(;s<i.count;){const t=new v.O
t.channelId=e.channelId
const n=i[s]
t.content=n.content,t.content=M.d.Inst_get().model.SetContentColor(t.content,t.channelId),t.content2=n.content,
t.content2=M.d.Inst_get().model.SetContentColor(t.content,t.channelId),t.sender=n.sender,t.infos=n.infos,t.recevierName=e.recevierName,t.recevierId=e.receiverId,
t.receiverIsOnline=!0,n.sender.IsMe()&&(t.sender.name=t.sender.name),t.serverId=n.serverId,this.sendTime=0,this.isworld=!1
const l=b.$.GetInst(t)
l.isSystemInfo=L.L.IsSystem(l.smChat.channelId),M.d.Inst_get().model.AddChat(l,null),s+=1}}SM_ChatVoiceHandler(t){const e=t
if(null==e.sender)return void m.Y.LogError((0,_.T)("语音SM_ChatVoice的发送者为空，需要服务端看"))
e.sender.IsMe()&&O.y.inst.ClientStrMsg(null,"语音发送成功")
const i=new v.O
i.sender=e.sender,i.channelId=e.channelId,i.recevierId=e.recevierId,i.voiceUrl=e.voiceUrl,i.voiceContent=e.voiceMsg,i.recordTime=e.recoredTime,i.receiverIsOnline=!0,
i.sendTime=e.createTime.ToNum(),i.isRead=e.isRead
const s=b.$.GetInst(i)
s.isVoiceHeard=!1,s.isSystemInfo=!1,M.d.Inst_get().model.AddChat(s,null)}RegisterSetVoiceContent(t,e){this.m_handlers.LuaDic_AddOrSetItem(t,e)}RemoveRegVoiceContent(t){
this.m_handlers.LuaDic_Remove(t)}updateChatInfo(t,e){M.d.Inst_get().model.updateChatInfo(t,e)}GetDyChatCellInfo(t,e){return M.d.Inst_get().model.GetDyChatCellInfo(t,e)}
RegisterSetVoiceContentForMian(t,e){this.m_mainHandlers.LuaDic_AddOrSetItem(t,e)}RemoveRegVoiceContentForMian(t){this.m_mainHandlers.LuaDic_Remove(t)}
RequestCM_PublicChat(t,e,i,s,n){null==n&&(n=0)
const l=new T.z
l.channelId=t,l.content=i,l.param=s,l.trumptNum=n,I.C.Inst.F_SendMsg(l),t!=L.L.HORN&&M.d.Inst_get().model.historyModel.AddHistoryChat(e,i,s)}RequestCM_ReadAsuramMsg(){
const t=new y.f
I.C.Inst.F_SendMsg(t)}RequestCM_PrivateChat(t,e,i,s){const n=new f.S
n.content=i,n.receiver=t,n.param=s,I.C.Inst.F_SendMsg(n),M.d.Inst_get().model.historyModel.AddHistoryChat(e,i,s)}RequestCM_ShowAccount(t){const e=new D.N
e.accountName=t,I.C.Inst.F_SendMsg(e)}RequestCM_ScanPlayerOtherBaseInfo(t){const e=new A.T
e.scanPlayerId=t,I.C.Inst.F_SendMsg(e)}SendStallItemChat(t){
p.M.IsNullOrEmpty(t)||-1!=p.M.IndexOf(t,P.p.STALL_ITEM_KEY,0)?O.y.inst.ClientSysMessage(100566):null!=R.U.Inst_get().chatItemId?(-1!=p.M.IndexOf(t,R.U.Inst_get().chatItemStr,0)?(t=p.M.ReplaceSlow(t,R.U.Inst_get().chatItemStr,P.p.STALL_ITEM_KEY),
this.SendStallChat(0,R.U.Inst_get().chatItemId,t)):O.y.inst.ClientSysStrMsg("请选择广告商品"),R.U.Inst_get().ClearAdChat()):O.y.inst.ClientSysStrMsg("请选择广告商品")}SendStallChat(t,e,i){
const s=new E.K
s.i18=t,null==e&&(e=g.o.ZERO),null==i&&(i=""),s.guid=e,s.content=i,I.C.Inst.F_SendMsg(s)}SendCloseChat(t){const e=new S.A
e.receiverId=t,I.C.Inst.F_SendMsg(e)}},h._inst=null,G(r=h,"GetInst",[d.n],Object.getOwnPropertyDescriptor(r,"GetInst"),r),
G(r.prototype,"SM_ScanPlayerOtherBaseInfoHandler",[s],Object.getOwnPropertyDescriptor(r.prototype,"SM_ScanPlayerOtherBaseInfoHandler"),r.prototype),
G(r.prototype,"SM_ShowAccountHandler",[n],Object.getOwnPropertyDescriptor(r.prototype,"SM_ShowAccountHandler"),r.prototype),
G(r.prototype,"SM_ChatHandler",[l],Object.getOwnPropertyDescriptor(r.prototype,"SM_ChatHandler"),r.prototype),
G(r.prototype,"SM_CrossChatHandler",[a],Object.getOwnPropertyDescriptor(r.prototype,"SM_CrossChatHandler"),r.prototype),
G(r.prototype,"SM_ChatVoiceHandler",[o],Object.getOwnPropertyDescriptor(r.prototype,"SM_ChatVoiceHandler"),r.prototype),r)},83171:(t,e,i)=>{i.d(e,{d:()=>I})
var s=i(86133),n=i(31222),l=i(85602),a=i(87923),o=i(47786),r=i(19983),h=i(49892),d=i(75961),c=i(65550),_=i(85942),u=i(14143)
class I{constructor(){this.m_tVo=null,this.n_clickNotices=null,this._degf_OnCancelHandler=null,this._degf_OnHandler=null,this.n_clickNotices=new l.Z,
this._degf_OnCancelHandler=t=>this.OnCancelHandler(t),this._degf_OnHandler=t=>this.OnHandler(t)}static Inst_get(){return null==I.m_inst&&(I.m_inst=new I),I.m_inst}DealNotiece(t){
t.smChat.channelId==u.L.NOTICE&&(t.isOpenTipImmediately?(this.n_clickNotices.Insert(0,t),this.OpenNotice()):(null==this.m_tVo&&(this.m_tVo=new d.U(h.K.ICON_TIPS_TEMP_NOTICE),
r.S.Inst_get().AddIcon(this.m_tVo)),this.n_clickNotices.Add(t),r.S.Inst_get().UpdateCount(h.K.ICON_TIPS_TEMP_NOTICE,this.n_clickNotices.Count())))}OpenNotice(){
const t=this.n_clickNotices[0]
this.n_clickNotices.RemoveAt(0)
const e=o.x.Inst().getItemById(t.smChat.tag),i=new _.N
i.showText=t.m_i18Context,i.titleText=(0,s.T)("消息"),t.isTipWithClose?i.tipstype=2:i.tipstype=1,0!=e.ui2&&(i.tipstype=2),i.btnColorType=2,a.l.IsEmptyStr(e.tips)||(i.okText=e.tips),
a.l.IsEmptyStr(e.tips2)||(i.cancelText=e.tips2),i.objparams=t,i.cancelObjparams=t,i.okBtnWidth=126,i.isShowCloseBtn=!1,i.isShowMask=!1,i.okhandler=this._degf_OnHandler,
i.beforecancelhandler=this._degf_OnCancelHandler,c.y.inst.OpenCommonMessageTips(i)
const n=this.n_clickNotices.Count()
0==n?(this.m_tVo=null,r.S.Inst_get().RemoveIcon(h.K.ICON_TIPS_TEMP_NOTICE)):r.S.Inst_get().UpdateCount(h.K.ICON_TIPS_TEMP_NOTICE,n)}OnHandler(t){
const e=t,i=o.x.Inst().getItemById(e.smChat.tag)
0!=i.ui&&n.N.inst.OpenUIByShortCutID(i.ui)}OnCancelHandler(t){const e=t,i=o.x.Inst().getItemById(e.smChat.tag)
0!=i.ui2&&n.N.inst.OpenUIByShortCutID(i.ui2)}}I.m_inst=null},98407:(t,e,i)=>{i.d(e,{C:()=>W})
var s=i(75439),n=i(65550),l=i(95721),a=i(98130),o=i(98885),r=i(85602),h=i(38962),d=i(17409),c=i(49655),_=i(86133),u=i(98800),I=i(13687),m=i(62370),g=i(31222),p=i(79534),C=i(8125),S=i(85430),f=i(80486),T=i(73287),y=i(1240),A=i(21554),D=i(70850),E=i(63076),v=i(87923),w=i(24928),R=i(96297),P=i(44744),O=i(62783),L=i(12970),B=i(21334),b=i(19276),M=i(14143),G=i(64444),H=i(13612),N=i(26753)
let k=null,U=null,V=null,x=0,F=0,q=null,Y=null
class W{static __StaticInit(){U=new h.X,U.LuaDic_Add(G.B.ITEM,(t=>{W.ITEMHandler(t)})),U.LuaDic_Add(G.B.VIRTUAL_ITEM,(t=>{W.VIRTUAL_ITEMHandler(t)})),U.LuaDic_Add(G.B.GUARD,(t=>{
W.GUARDHandler(t)})),U.LuaDic_Add(G.B.PLAYER,(t=>{W.PLAYERHandler(t)})),U.LuaDic_Add(G.B.ASURAM_INVITE,(t=>{W.ASURAM_INVITEHandler(t)})),U.LuaDic_Add(G.B.POINT,(t=>{
W.POINTHandler(t)})),U.LuaDic_Add(G.B.TEAM,(t=>{W.TEAMHandler(t)})),U.LuaDic_Add(G.B.UI_OPEN,(t=>{W.UI_OPENHandler(t)})),U.LuaDic_Add(G.B.ALLIANCE_ENTRUST_HOME,(t=>{
W.ALLIANCE_ENTRUST_HOMEHandler(t)})),U.LuaDic_Add(G.B.TASK,(t=>{W.TASKHandler(t)})),U.LuaDic_Add(G.B.ASURAM_BOSS,(t=>{W.ASURAM_BOSSHandler(t)})),U.LuaDic_Add(G.B.BOSS_ASSIST,(t=>{
W.BOSS_ASSISTHandler(t)})),U.LuaDic_Add(G.B.STALL_AD_STALLNAME,(t=>{W.STALL_AD_STALLNAMEHandler(t)})),U.LuaDic_Add(G.B.STALL_AD_ITEM,(t=>{W.STALL_AD_ITEMHandler(t)})),
U.LuaDic_Add(G.B.ALLIANCE_ASSIST,(t=>{W.ALLIANCE_ASSISTHandler(t)})),U.LuaDic_Add(G.B.SHOW_EQUIP,(t=>{W.SHOW_EQUIP(t)})),U.LuaDic_Add(G.B.ALLIANCE_HOME,(t=>{
this.ALLIANCE_HOMEHandler(t)}))}static OnTxtClick(t,e,i){if(null==U&&this.__StaticInit(),!(0,d.Y)(c.o.eChatMainPanel)){if((0,d.Y)(c.o.ChatShowPanel).isScrollIng)return
return N.d.Inst_get().controller.m_channel=N.d.Inst_get().model.curShowPanelChannel,void N.d.Inst_get().controller.OpenMainPanel(null,null,null)}
k=null!=e.fullLinkStr?e.fullLinkStr:m.o.GetUrlAtPositionVec3(new p.P(C.T.touchLocation.x,C.T.touchLocation.y,0),t),v.l.IsEmptyStr(k)||(q=o.M.Split(k,m.o.s_Arr_UNDER_CHAR_DOT),
Y=o.M.String2Int(q[0]),U.LuaDic_ContainsKey(Y)&&U[Y](e))}static IsShowItemTipByI18nItemInfo(t,e){if(e.Equal(t.id)){const e=new E.M(t.itemModelId,null)
if(e.isEquip_get())if(null==t.isClientMsg||0==t.isClientMsg)null!=t.item?n.y.inst.ShowItemTipForChat(t.item):n.y.inst.QueryItem(t.id)
else{let i=null
const s=u.Y.Inst.PrimaryRoleInfo_get().GetEquipmentById(t.id)
null!=s?(i=new y.Y,i.serverData_set(s)):i=D.g.Inst_get().GetItemById(t.id),null==i&&(i=D.g.Inst_get().GetHouseItemById(t.id)),null!=i&&(e.serverData_set(i.serverData_get()),
e.isCanOperate=!1,e.isEquipCompare=!1,e.isShowAddPointTip=!1,A.J.Inst_get().ShowItemTip(e))}else{if("VIPPANDORA"==e.cfgData_get().itemType){const t=new w.E
t.todayUseTimes=0,t.useTime=0,e.serverData_set(t)}A.J.Inst_get().ShowItemTip(e)}return!0}return!1}static IsShowItemTipByI18nEquipAndSuitEquipInfo(t,e,i){
if((e.Equal(l.o.ZERO)&&null==t.equipment||null!=t.equipment&&e.Equal(t.equipment.id))&&(i.Equal(l.o.ZERO)&&null==t.suitEquipment||null!=t.suitEquipment&&i.Equal(t.suitEquipment.id))){
if(null==t.isClientMsg||0==t.isClientMsg)null==t.equipment?n.y.inst.QueryItem(t.suitEquipment.id):null==t.suitEquipment?n.y.inst.QueryItem(t.equipment.id):n.y.inst.QueryTwoEq(e,i)
else{let s=null,n=null,l=null
null==t.equipment?n=u.Y.Inst.PrimaryRoleInfo_get().GetEquipmentById(i):null==t.suitEquipment?n=u.Y.Inst.PrimaryRoleInfo_get().GetEquipmentById(e):(n=u.Y.Inst.PrimaryRoleInfo_get().GetEquipmentById(e),
l=u.Y.Inst.PrimaryRoleInfo_get().GetEquipmentById(i)),null!=n&&(s=new E.M,s.serverData_set(n),s.showSuitEq=l),null!=s&&(s.isCanOperate=!1,s.isEquipCompare=!1,
s.isShowAddPointTip=!1,A.J.Inst_get().ShowItemTip(s))}return!0}return!1}OnPlayerIdLinkClick(t,e){
if(k=t.GetUrlAtPositionVec3(LuaUICameraBridgeManager.Instance_get().LastWorldPosition()),!v.l.IsEmptyStr(k)&&(q=o.M.Split(k,m.o.s_Arr_UNDER_CHAR_DOT),Y=o.M.String2Int(q[0]),
Y==G.B.PLAYER)){u.Y.Inst.PrimaryRoleInfo_get().Id_get().Equal(e)||P.Z.Inst().Open(e,null,null,null)}}static OnPathMoveEnd(t){const e=a.GF.INT(t[0])
O.X.inst.changeLine(e,null)}static GetUnreadStr(t){return t<99?(0,_.T)("未读消息 ")+(t+(0,_.T)(" 条")):(0,_.T)("未读消息 99+ 条")}static GetMainBtnIndex(t){
return t==M.L.TOTAL?0:t==M.L.SYSTEM?1:t==M.L.WORLD?2:t==M.L.ALLIANCE?3:t==M.L.CROSS_SERVER?4:t==M.L.STALL?5:0}static SendToHorn(t,e,i,s){
if(0==D.g.Inst_get().GetItemNum(H.k.HORN_ITEM_ID))return N.d.Inst_get().mgr.RequestCM_PublicChat(t,e,i,s,1),void W.OnSendHorn()
N.d.Inst_get().mgr.RequestCM_PublicChat(t,e,i,s,null),W.OnSendHorn()}static OnSendHorn(){n.y.inst.ClientStrMsg(null,"喇叭发送成功")}GetHornShowTime(){if(-1==W.hornShowTime){
const t=s.D.getInstance().getContent("CHAT:TRUPMPT_SHOW_TIME")
W.hornShowTime=1e3*o.M.String2Int(t.getContent().stringVal)}return W.hornShowTime}static ITEMHandler(t){x=o.M.String2UInt(q[1]),F=o.M.String2UInt(q[2]),V=l.o.New(x,F)
const e=t.smChat.infos
if(null!=e&&e.Count()>0){let t=0
for(;t<e.Count();){const i=e[t]
if(null!=i.id&&this.IsShowItemTipByI18nItemInfo(i,V))return
t+=1}}}static VIRTUAL_ITEMHandler(t){const e=o.M.String2Int(q[1]),i=new E.M(e,null)
A.J.Inst_get().ShowItemTip(i)}static GUARDHandler(t){x=o.M.String2UInt(q[1]),F=o.M.String2UInt(q[2]),V=l.o.New(x,F),n.y.inst.QueryGuardItem(V)}static PLAYERHandler(t){
x=o.M.String2UInt(q[1]),F=o.M.String2UInt(q[2]),V=l.o.New(x,F)
u.Y.Inst.PrimaryRoleInfo_get().Id_get().Equal(V)||P.Z.Inst().Open(V,null,null,null)}static ASURAM_INVITEHandler(t){3==q.count&&(x=o.M.String2UInt(q[1]),F=o.M.String2UInt(q[2]),
V=l.o.New(x,F),f.K.Inst().ApplyIntoAsuramReq(V))}static POINTHandler(t){const e=o.M.String2Int(q[1]),i=B.p.Inst_get().GetMapById(e)
if(null!=i&&"ASURAM_SCENE"==i.controllerType)return void T.l.Inst().GotoAsuramNpc()
const s=new p.P(o.M.String2Float(q[2]),0,o.M.String2Float(q[3]))
let l=0
const a=L.F.getInst().CurLine_get(),h=o.M.String2Int(q[4])
if(q.count>5&&(l=o.M.String2Int(q[5])),0!=l){const t=b.C.Inst().GetItemByMonsterId(l)
null!=t?e==I.b.Inst.currentMapId_get()||t.type_get():n.y.inst.ClientSysStrMsg((0,_.T)("BOSS不存在！！！"))}else if(a==h)u.Y.Inst.PrimaryRole_get().gotoPoint(s,0,null,null,e)
else{const t=new r.Z([h])
u.Y.Inst.PrimaryRole_get().gotoPoint(s,0,W.OnPathMoveEnd,t,e)}}static TEAMHandler(t){l.o.New(o.M.String2UInt(q[1]),o.M.String2UInt(q[2])),o.M.String2Int(q[3]),
l.o.New(o.M.String2UInt(q[4]),o.M.String2UInt(q[5]))
W.guildid=0,q.count>=7&&(W.guildid=o.M.String2Int(q[6]))
u.Y.Inst.PrimaryRoleInfo_get()}static UI_OPENHandler(t){N.d.Inst_get().controller.CloseMainPanel()
const e=o.M.String2Int(q[1])
g.N.inst.OpenUIByShortCutID(e)}static ALLIANCE_ENTRUST_HOMEHandler(t){}static TASKHandler(t){const e=o.M.String2Int(q[1])
let i=0,s=0
q.count>2&&(i=o.M.String2Int(q[2]),s=o.M.String2Int(q[3])),N.d.Inst_get().controller.OpenTaskPanel(e,i,s)}static ASURAM_BOSSHandler(t){S.a.GotoJudge()}
static STALL_AD_STALLNAMEHandler(t){let e=q[1]
for(let t=2;t<=q.count-1;t++)""!=q[t]&&(e+=m.o.s_Arr_UNDER_CHAR_DOT+q[t])
N.d.Inst_get().controller.CloseMainPanel(),R.v.Inst_get().OpenStallMarketView(),R.v.Inst_get().OpenPlayerStallView(e,null)}static STALL_AD_ITEMHandler(t){x=o.M.String2UInt(q[1]),
F=o.M.String2UInt(q[2]),V=l.o.New(x,F)
let e=q[3]
for(let t=4;t<=q.count-1;t++)""!=q[t]&&(e+=m.o.s_Arr_UNDER_CHAR_DOT+q[t])
N.d.Inst_get().controller.CloseMainPanel(),R.v.Inst_get().OpenStallMarketView(),R.v.Inst_get().OpenPlayerStallView(e,V)}static ALLIANCE_ASSISTHandler(t){}
static ALLIANCE_HOMEHandler(t){}static SHOW_EQUIP(t){x=o.M.String2UInt(q[1]),F=o.M.String2UInt(q[2])
const e=o.M.String2UInt(q[3]),i=o.M.String2UInt(q[4])
V=l.o.New(x,F)
const s=l.o.New(e,i),n=t.smChat.infos
if(null!=n&&n.Count()>0){let t=0
for(;t<n.Count();){const e=n[t]
if((e.equipment||e.suitEquipment)&&W.IsShowItemTipByI18nEquipAndSuitEquipInfo(e,V,s))return
t+=1}}}static BOSS_ASSISTHandler(t){}}W.hornShowTime=-1,W.guildid=0},27047:(t,e,i)=>{i.d(e,{w:()=>nt})
var s=i(56937),n=i(18202),l=i(31222),a=i(5494),o=i(37648),r=i(55492),h=i(86133),d=i(5924),c=i(99294),_=i(9986),u=i(78287),I=i(9776),m=i(30267),g=i(86290),p=i(83207),C=i(69029),S=i(93877),f=i(61911),T=i(98885),y=i(85602),A=i(38962),D=i(15033),E=i(28287),v=i(87923),w=i(75755),R=i(22662),P=i(14792),O=i(62734),L=i(65550),B=i(26753),b=i(14143),M=i(16459),G=i(64444),H=i(13612),N=i(69688),k=i(38836),U=i(98800),V=i(97960),x=i(97461),F=i(43133),q=i(6665),Y=i(36437),W=i(57834),j=i(30849),Z=i(52212),X=i(79534),K=i(44758),$=i(70850),J=i(63076),z=i(75696),Q=i(92679),tt=i(90866),et=i(98899)
class it extends j.C{constructor(){super(),this.popupPanel=null,this.popupTab=null,this.faceGrid=null,this.itemGrid=null,this.closeCollider=null,this.m_tabIndex=0,
this.mainPanel=null,this.m_model=null,this.crossPanel=null,this._degf_OnCloseBtn=null,this._degf_OnCreateFace=null,this._degf_OnCreateItem=null,this._degf_OnCreateTask=null,
this._degf_OnItemRefresh=null,this._degf_OnTabSelected=null,this._degf_bagUpdateHandler=null,this._degf_OnCloseBtn=(t,e)=>this.OnCloseBtn(t,e),
this._degf_OnCreateFace=t=>this.OnCreateFace(t),this._degf_OnCreateItem=t=>this.OnCreateItem(t),this._degf_OnCreateTask=t=>this.OnCreateTask(t),
this._degf_OnItemRefresh=()=>this.OnItemRefresh(),this._degf_OnTabSelected=t=>this.OnTabSelected(t),this._degf_bagUpdateHandler=t=>this.bagUpdateHandler(t)}InitView(){
this.popupPanel=new c.z,this.popupPanel.setId(this.FatherId,this.FatherComponentID,1),this.popupTab=new Y.K,this.popupTab.setId(this.FatherId,this.FatherComponentID,2),
this.faceGrid=new q.A,this.faceGrid.setId(this.FatherId,this.FatherComponentID,3),this.itemGrid=new q.A,this.itemGrid.setId(this.FatherId,this.FatherComponentID,4),
this.closeCollider=new F.V,this.closeCollider.setId(this.FatherId,this.FatherComponentID,5),this.m_model=B.d.Inst_get().model,
this.popupTab.SetSelectHandler(this._degf_OnTabSelected),this.popupTab.SetSelectIndex(0),this.faceGrid.SetInitInfo("UI_Chat_Face",this._degf_OnCreateFace),
this.faceGrid.data_set(this.m_model.GetFaceList(!1)),this.itemGrid.SetInitInfo("ui_baseitem",this._degf_OnCreateItem)}OnCreateTask(t){const e=new et.v
return e.setId(t,null,0),e}OnCreateFace(t){const e=new tt.l
return e.tag=it.CHAT_POPUP_CELL,e.setId(t,null,0),e}OnCreateItem(t){const e=new z.j
return e.setId(t,null,0),e}OnTabSelected(t){this.m_tabIndex=t,this.Update()}Update(){1==this.m_tabIndex&&this.UpdateItemData()}UpdateItemData(){
d.C.Inst_get().CallLater(this._degf_OnItemRefresh)}OnItemRefresh(){const t=$.g.Inst_get().GetAllItem(),e=U.Y.Inst.PrimaryRoleInfo_get().AllStageEquipments_get()
for(const[i,s]of(0,k.vy)(e)){const s=e[i]
let n=0
for(;n<s.equipmentsGet().Count();){const e=s.equipmentsGet()[n]
if(null!=e){const i=new J.M
i.serverData_set(e),t.Add(i)}n+=1}}this.itemGrid.data_set(t)}ChangeShowPopup(){const t=this.popupPanel.activeSelf()
this.popupPanel.SetActive(!t),this.crossPanel.SetInputY(!t),t?this.AddOrDelEvent(!1):(this.AddOrDelEvent(!0),this.Update())}ClosePop(){
this.popupPanel.activeSelf()&&this.ChangeShowPopup()}SetUpContentY(t){
const e=this.mainPanel.contentPanel.transform.GetLocalPosition(),i=this.mainPanel.horncontainer.horncontainer.transform.GetLocalPosition()
let s=null
s=this.mainPanel.m_isQuest?this.mainPanel.scrollPanelQuestTimeSize:this.mainPanel.scrollPanelSize
const n=new K.L(s.x,s.y,s.z,s.w),l=n.w-this.mainPanel.chatTable.node.GetBoundsSize().y
let a=!1,o=0
this.mainPanel.chatScrollview.RemoveSpringPanel(),l<0&&(a=!0),i.y=-615,t?(e.y=315,n.y+=e.y/2,n.w-=e.y):e.y=0,this.mainPanel.contentPanel.transform.SetLocalPosition(e),
this.mainPanel.horncontainer.horncontainer.transform.SetLocalPosition(i+e),this.mainPanel.chatScrollviewPanel.baseClipRegionSet(n),this.mainPanel.curScrollPanelSize=n
const r=new X.P
if(t){a?o=315:(o=this.mainPanel.chatTable.node.GetBoundsSize().y-n.w,o<0&&(o=0))
const t=this.mainPanel.chatScrollviewPanel.node.transform.GetLocalPosition(),e=this.mainPanel.chatScrollviewPanel.clipOffset()
t.y<0?(r.Set(t.x),this.mainPanel.chatScrollviewPanel.node.transform.SetLocalPosition(r),r.Set(e.x),
this.mainPanel.chatScrollviewPanel.clipOffsetSet(new Z.F(e.x,0))):a&&t.y>-l&&(r.Set(t.x,-l),this.mainPanel.chatScrollviewPanel.node.transform.SetLocalPosition(r),r.Set(e.x,l),
this.mainPanel.chatScrollviewPanel.clipOffsetSet(r))}else a?o=-315:(o=0,this.mainPanel.chatScrollview.ResetPosition())
r.Set(0,o),this.mainPanel.chatScrollview.MoveRelative(r),X.P.Recyle(r)}AddOrDelEvent(t){const e=W.i.Get(this.closeCollider.node)
t?(x.i.Inst.AddEventHandler(Q.g.BAG_UPDATE,this._degf_bagUpdateHandler),U.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(V.A.EquipmentsUpdate,this._degf_bagUpdateHandler),
e.RegistonClick(this._degf_OnCloseBtn)):(x.i.Inst.RemoveEventHandler(Q.g.BAG_UPDATE,this._degf_bagUpdateHandler),
U.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(V.A.EquipmentsUpdate,this._degf_bagUpdateHandler),e.RemoveonClick(this._degf_OnCloseBtn))}OnCloseBtn(t,e){this.ChangeShowPopup()}
bagUpdateHandler(t){1==this.popupTab.GetSelectIndex()&&this.UpdateItemData()}Destory(){this.popupPanel=null,this.popupTab.Destory(),this.popupTab=null,this.faceGrid.Destroy(),
this.faceGrid=null,this.itemGrid.Destroy(),this.itemGrid=null,this.mainPanel=null,this.m_model=null,this.closeCollider=null}}it.CHAT_POPUP_CELL="chat_popup_cell"
class st extends f.f{constructor(){super(),this.m_paramList=null,this.linkDic=null,this.m_tempKeyDic=null,this.m_isDraging=!1,this.curBarValue=1,this.callTimerId=0,this.setdata=!1,
this._degf_OnBtnClick=null,this._degf_OnChatUpdate=null,this._degf_CreateSystemCell=null,this._degf_OnFullClick=null,this._degf_OnSelectFace=null,this._degf_OnShowItem=null,
this._degf_OnTableResponstion=null,this._degf_OnDragFinished=null,this._degf_OnDragStarted=null,this._degf_OnCallLater=null,this._degf_RefresList=null,this.closeBtn=null,
this.chatTable1=null,this.sendLabel=null,this.FatherCompo=null,this.sendbtn=null,this.facebtn=null,this.popupPanel=null,this.inputLabel=null,this.haveInputWidget=null,
this.contentBg1=null,this.contentBg2=null,this.chatTable2=null,this.chatScrollviewbar1=null,this.chatScrollviewbar2=null,this.chatScrollview1=null,this.chatScrollview2=null,
this.m_model=null,this.m_controller=null,this.nowTable=null,this.nowScrollBar=null,this.nowScrollView=null,this.isInputUp=null,this.m_isTableResponstion=null,
this.m_tempFaceStr=null,this.m_frontFaceStr=null,this.m_paramList=new y.Z,this.linkDic=new A.X,this.m_tempKeyDic=new A.X,this._degf_OnBtnClick=(t,e)=>this.OnBtnClick(t,e),
this._degf_OnChatUpdate=t=>this.OnChatUpdate(t),this._degf_CreateSystemCell=t=>this.CreateSystemCell(t),this._degf_OnFullClick=(t,e)=>this.OnFullClick(t,e),
this._degf_OnSelectFace=t=>this.OnSelectFace(t),this._degf_OnShowItem=t=>this.OnShowItem(t),this._degf_OnTableResponstion=()=>this.OnTableResponstion(),
this._degf_OnDragFinished=()=>this.OnDragFinished(),this._degf_OnDragStarted=()=>this.OnDragStarted(),this._degf_OnCallLater=()=>this.OnCallLater(),
this._degf_RefresList=()=>this.RefresList()}ShowCurrencyBar_get(){return E._.Hide}InitView(){this.isExclusionPanel=!0,this.closeBtn=new _.W,
this.closeBtn.setId(this.FatherId,this.FatherComponentID,1),this.chatTable1=new m.V,this.chatTable1.setId(this.FatherId,this.FatherComponentID,2),this.sendLabel=new S.Q,
this.sendLabel.setId(this.FatherId,this.FatherCompo,3),this.sendbtn=new p.s,this.sendbtn.setId(this.FatherId,this.FatherComponentID,4),this.facebtn=new p.s,
this.facebtn.setId(this.FatherId,this.FatherComponentID,5),this.popupPanel=new it,this.popupPanel.setBinderId(this.FatherId,this.FatherComponentID,6),this.inputLabel=new C.z,
this.inputLabel.setId(this.FatherId,this.FatherComponentID,7),this.haveInputWidget=new g.G,this.haveInputWidget.setId(this.FatherId,this.FatherComponentID,8),
this.contentBg1=new c.z,this.contentBg1.setId(this.FatherId,this.FatherComponentID,9),this.contentBg2=new c.z,this.contentBg2.setId(this.FatherId,this.FatherComponentID,10),
this.chatTable2=new m.V,this.chatTable2.setId(this.FatherId,this.FatherComponentID,11),this.chatScrollviewbar1=new u._,
this.chatScrollviewbar1.setId(this.FatherId,this.FatherComponentID,12),this.chatScrollviewbar2=new u._,this.chatScrollviewbar2.setId(this.FatherId,this.FatherComponentID,13),
this.chatScrollview1=new I.h,this.chatScrollview1.setId(this.FatherId,this.FatherComponentID,14),this.chatScrollview2=new I.h,
this.chatScrollview2.setId(this.FatherId,this.FatherComponentID,15),this.popupPanel.crossPanel=this,
this.chatTable1.SetInitInfo("ui_chat_crosstotalcell",this._degf_CreateSystemCell),this.chatTable2.SetInitInfo("ui_chat_crosstotalcell",this._degf_CreateSystemCell),
this.chatTable1.OnReposition_set(this._degf_OnTableResponstion),this.chatTable2.OnReposition_set(this._degf_OnTableResponstion),this.m_model=B.d.Inst_get().model,
this.m_controller=B.d.Inst_get().controller,this.nowTable=this.chatTable1,this.nowScrollBar=this.chatScrollviewbar1,this.nowScrollView=this.chatScrollview1,this.isInputUp=!1}
CreateSystemCell(t){const e=new N.D
return e.isCrossChat=!0,e.setId(t,null,0),e}OnTableResponstion(){0==this.callTimerId&&(this.callTimerId=d.C.Inst_get().SetInterval(this._degf_OnCallLater,100,1))}OnCallLater(){
if(this.setdata){this.setdata=!1
const t=this.nowTable.data_get()
this.nowTable.GetYOffset()<88*t.count&&this.nowTable.Reposition()}this.callTimerId=0,this.m_isTableResponstion=!0,
null==this.nowTable||this.m_isDraging||(this.isInputUp?this.nowScrollBar.SetValue(1):null==this.nowTable.data_get()||0==this.nowTable.data_get().Count()||this.curBarValue<.05?this.nowScrollBar.SetValue(0):this.curBarValue>.97&&this.nowScrollBar.SetValue(1))
}OnAddToScene(){this.AddLis(),O.f.Inst.SetState(P.t.CHAT_CROSS_SERVER,!1),d.C.Inst_get().CallLater(this._degf_RefresList)}RefresList(){this.SetList()}Clear(){this.RemoveLis(),
this.ClearInput(),this.curBarValue=1,this.nowScrollBar.SetValue(1)}AddLis(){this.AddClickEvent(this.closeBtn,this._degf_OnBtnClick),
this.AddClickEvent(this.sendbtn,this._degf_OnBtnClick),this.AddClickEvent(this.facebtn,this._degf_OnBtnClick),this.m_model.AddEventHandler(M.F.UPDATE_CHAT,this._degf_OnChatUpdate),
this.m_model.AddEventHandler(M.F.SELECT_FACE,this._degf_OnSelectFace),this.m_model.AddEventHandler(M.F.SEND_ITEM_TO_CHAT,this._degf_OnShowItem),
this.chatScrollview1.RegistonDragStarted(this._degf_OnDragStarted),this.chatScrollview1.RegistonDragFinished(this._degf_OnDragFinished)}RemoveLis(){
this.RemoveClickEvent(this.closeBtn,this._degf_OnBtnClick),this.RemoveClickEvent(this.sendbtn,this._degf_OnBtnClick),this.RemoveClickEvent(this.facebtn,this._degf_OnBtnClick),
this.m_model.RemoveEventHandler(M.F.UPDATE_CHAT,this._degf_OnChatUpdate),this.m_model.RemoveEventHandler(M.F.SELECT_FACE,this._degf_OnSelectFace),
this.m_model.RemoveEventHandler(M.F.SEND_ITEM_TO_CHAT,this._degf_OnShowItem),this.chatScrollview1.RemoveonDragStarted(this._degf_OnDragStarted),
this.chatScrollview1.RemoveonDragFinished(this._degf_OnDragFinished)}OnChatUpdate(t){this.m_model.isMainTagChanged(b.L.CROSS_SERVER)&&this.SetList()}SetList(){
const t=this.m_model.GetShowList(b.L.CROSS_SERVER)
this.setdata=!0,this.nowTable.data_set(t)}OnBtnClick(t,e){this.closeBtn.ComponentId==t?(this.nowScrollBar.SetValue(1),
l.N.inst.CloseById(a.I.eCrossChat)):this.sendbtn.ComponentId==t?this.SendToServer():this.facebtn.ComponentId==t&&(this.popupPanel.ChangeShowPopup(),
this.AddFullScreenCollider(this.popupPanel,this._degf_OnFullClick))}SendToServer(){const t=this.inputLabel.GetValue()
if(v.l.IsEmptyStr(t))return void L.y.inst.ClientStrMsg(R.r.SystemTipMessage,(0,h.T)("请输入发送内容"))
if(!this.m_model.channelModel.IsCanSend(b.L.CROSS_SERVER,t))return
const e=this.m_controller.DealLinkStr(this.linkDic,this.m_tempKeyDic,t)
B.d.Inst_get().mgr.RequestCM_PublicChat(b.L.CROSS_SERVER,t,e,this.m_paramList),this.ClearInput()}OnFullClick(t,e){this.RemoveFullScreenCollider(),this.popupPanel.ChangeShowPopup()}
SetInputY(t){const e=this.haveInputWidget.GetLocalPosition()
let i=!0
this.curBarValue=1,this.isInputUp=t,t?(e.y=80,this.nowTable=this.chatTable2,this.nowScrollBar=this.chatScrollviewbar2,this.nowScrollView=this.chatScrollview2,i=!1):(e.y=-198,
this.nowTable=this.chatTable1,this.nowScrollBar=this.chatScrollviewbar1,this.nowScrollView=this.chatScrollview1),this.contentBg1.SetActive(i),this.contentBg2.SetActive(!i),
this.SetList(),this.haveInputWidget.SetLocalPosition(e)}Destroy(){this.closeBtn=null,this.chatTable1.Destroy(),this.chatTable1=null,this.sendLabel=null,this.sendbtn=null,
this.facebtn=null,this.popupPanel.Destory(),this.popupPanel=null,this.inputLabel=null,this.haveInputWidget=null,this.contentBg1=null,this.contentBg2=null,this.chatTable2.Destroy(),
this.chatTable2=null,this.chatScrollviewbar1=null,this.chatScrollviewbar2=null,this.chatScrollview1=null,this.chatScrollview2=null}OnSelectFace(t){
this.m_tempFaceStr=this.inputLabel.GetValue()
const e=`#${t}`
this.AddLinkStrToInput(e)}OnShowItem(t){const e=t,i=e.serverData_get().id,s=`${G.B.ITEM}_${i.low_get()}_${i.high_get()}`,n=v.l.GetQuality(e.baseData_get())
let l=null,a=null
if(e.baseData_get().BagItemType_get()==D.r.Equip){const t=v.l.SetEquipName(e.baseData_get().equipInfo_get(),e.baseData_get().cfgData_get(),e.serverData_get(),null,!1)
a=t[0],l=t[2]}else l=v.l.getColorStrByQuality(n),a=e.baseData_get().cfgData_get().name
const o=v.l.SetStringColor(l,T.M.s_LEFT_M_K_CHAR+(a+T.M.s_RIGHT_M_K_CHAR))
let r=v.l.SetLinkStr(a,s,l,!0)
this.AddLinkStrToInput(o)&&(r+=" ",this.linkDic.LuaDic_AddOrSetItem(o,r),this.AddParam(G.B.ITEM,i))}AddParam(t,e){const i=new w.o
i.type=t,i.pId=e,this.m_paramList.Add(i)}AddLinkStrToInput(t){const e=this.inputLabel.GetValue()+t
return!(UIUtilBridge.CalculateTextValidLength(e)>H.k.INPUT_MAX)&&(this.inputLabel.SetValue(e),!0)}OnDragStarted(){this.m_isDraging=!0}OnDragFinished(){this.m_isDraging=!1,
this.curBarValue=this.nowScrollBar.GetValue()}ClearInput(){this.m_frontFaceStr=null,this.linkDic.LuaDic_Clear(),this.m_paramList.Clear(),this.inputLabel.SetValue("")}}class nt{
constructor(){this.panel=null,this._degf_CallDestory=null,this._degf_Complete=null,this.view=null,this._degf_CallDestory=()=>this.CallDestory(),
this._degf_Complete=t=>this.Complete(t)}static Inst_get(){return null==nt.inst&&(nt.inst=new nt),nt.inst}OpenView(){if(null!=this.view&&this.view.isShow_get())return
const t=new s.v
t.isShowMask=!0,l.N.inst.OpenById(a.I.eCrossChat,this._degf_Complete,this._degf_CallDestory,t)}Complete(t){return null==this.panel&&(this.panel=new st,this.panel.setId(t,null,0)),
this.panel}CallDestory(){n.g.DestroyUIObj(this.panel),this.panel=null}IsPanelOpen(){return!(null==this.panel||!this.panel.isShow_get())}IsShowCrossServer(){
return o.P.Inst_get().IsFunctionOpened(r.x.CROSS_CHAT)}}nt.inst=null},81433:(t,e,i)=>{i.d(e,{J:()=>C})
i(38836)
var s=i(65530),n=i(66788),l=i(98130),a=i(98885),o=i(85602),r=i(38962),h=i(87923),d=i(92662),c=i(63076),_=i(48481),u=i(18919)
class I extends u.a{constructor(...t){super(...t),this.linkId=null,this.linkType=null,this.luaBehaviour=null}BeginExecute(){}}class m extends I{constructor(...t){super(...t),
this.modelId=null,this.id=null,this.bagdata=null,this.isEquipCompare=!1}BeginExecute(){const t=this.bagdata
if(null==t){const t=new _.t
t.modelId=this.modelId,t.id=this.id
const e=new c.M(this.modelId,t)
INS.itemTipManager.OpenTipView(e)}else INS.itemTipManager.OpenTipView(t.baseData_get())
return!0}}class g extends I{constructor(...t){super(...t),this.playerId=null}BeginExecute(){return null!=this.playerId&&TargetPlayerInfoControl.Inst().Open(this.playerId),!0}}
let p=null
class C{static __StaticInit(){p={[C.RY_ITEM_LINK_TYPE]:m,[C.RY_PLAYER_LINK_TYPE]:g}}ClearData(t){C.RY_ITEM_LINK_TYPE=0,C.ryLinkDataDic=new r.X,C.AutoId=0,C.Id_Pools=new o.Z}
GetNewLinkData(t,e,i){null==e&&n.Y.LogError("gameObject 为 空")
const s=d.u.CreateClassNewFast(t)
return null!=s&&(s.type=t,s.linkId=C.GetLinkId(),s.luaBehaviour=e,C.ryLinkDataDic.LuaDic_AddOrSetItem(s.linkId,s)),[s,C.GetLinkStr(s.linkId,i)]}CheckAllLinkData(){0}
static GetLinkId(t){if(C.AutoId<l.GF.INT32_MAX_VALUE_get())return C.AutoId+=1,C.AutoId
const e=C.Id_Pools[C.Id_Pools.count-1]
return C.Id_Pools.RemoveAt(M.Id_Pools.count-1),e}RemoveLinkData(t){C.AutoId==l.GF.INT32_MAX_VALUE_get()&&C.Id_Pools.Add(t),C.ryLinkDataDic.LuaDic_Remove(t)}ClearLinkData(t){
null!=t&&C.RemoveLinkData(t.linkId)}OnCommonClick(t,e,i){null==i&&(i=t.GetUrlAtPositionVec3(s.x.Instance_get().LastWorldPosition())),
h.l.IsEmptyStr(i)||C.ExcuteLink(a.M.String2Int(i))}static ExcuteLink(t,e){if(C.ryLinkDataDic.LuaDic_ContainsKey(t)){C.ryLinkDataDic[t].Execute(e)}}static GetLinkStr(t,e){
return`[url=${t}]${e}[/url]`}}C.RY_ITEM_LINK_TYPE=0,C.RY_PLAYER_LINK_TYPE=1,C.ryLinkDataDic=new r.X,C.AutoId=0,C.Id_Pools=new o.Z,C.GetTypeName=null},80928:(t,e,i)=>{i.d(e,{v:()=>I
})
var s=i(96617),n=i(50089),l=i(50600),a=i(26753),o=i(95721),r=i(98130),h=i(52777),d=i(58458),c=i(14143),_=i(37949)
class u{constructor(){this.speakTxt=null,this.txt=null,this.sendId_hign=0,this.sendId_low=0,this.sendName=null,this.job=0,this.sex=0,this.recevierId_hign=0,this.recevierId_low=0,
this.recevierName=null,this.sendTime=0,this.accountIndex=""}FillData(t){this.speakTxt=r.GF.LuaJsonToString(t.speakTxt),this.txt=r.GF.LuaJsonToString(t.txt),
this.sendId_hign=r.GF.LuaJsonToNumber(t.sendId_hign),this.sendId_low=r.GF.LuaJsonToNumber(t.sendId_low),this.sendName=r.GF.LuaJsonToString(t.sendName),
this.job=r.GF.LuaJsonToNumber(t.job),this.sex=r.GF.LuaJsonToNumber(t.sex),this.recevierId_hign=r.GF.LuaJsonToNumber(t.recevierId_hign),
this.recevierId_low=r.GF.LuaJsonToNumber(t.recevierId_low),this.recevierName=r.GF.LuaJsonToString(t.recevierName),this.sendTime=r.GF.LuaJsonToNumber(t.sendTime),
this.accountIndex=r.GF.LuaJsonToString(t.accountIndex)}static FromChatCellInfo(t){const e=new u
return e.speakTxt=t.speakTxt_get(),e.txt=t.txt_get(null),e.sendId_hign=t.smChat.sender.objId.high_get(),e.sendId_low=t.smChat.sender.objId.low_get(),
e.sendName=t.smChat.sender.name,e.job=t.smChat.sender.job,e.sex=t.smChat.sender.sex,e.accountIndex=t.smChat.sender.accountIndex,e.recevierId_hign=t.smChat.recevierId.high_get(),
e.recevierId_low=t.smChat.recevierId.low_get(),e.recevierName=t.smChat.recevierName,e.sendTime=t.smChat.sendTime,e}ToChatCellInfo(){const t=new d.O
t.sender=new h.C,t.sender.objId=o.o.New(this.sendId_low,this.sendId_hign),t.sender.name=this.sendName,t.sender.sex=this.sex,t.sender.job=this.job,
t.sender.accountIndex=this.accountIndex,t.recevierId=o.o.New(this.recevierId_low,this.recevierId_hign),t.recevierName=this.recevierName,t.sendTime=this.sendTime
const e=_.$.GetInst(t)
return e.smChat.channelId=c.L.PRIVATE,e.SetSpeakTxt(this.speakTxt,this.txt),e}}class I{AddChannelCache(t,e,i,s){const n=`setting_chat_${t.ToLongStr()}`,a=`${e},${i},${s}`
l.a.inst.SetValue(n,a)}GetChannelCache(t){const e=`setting_chat_${t.ToLongStr()}`
let i=l.a.inst.ReadValue(e)
return null!=i&&""!=i||(i="31,0,0"),i}LoadCache(t,e,i){s.A.LusuoLongToUIntList(t).GetLuaToArray(),s.A.LusuoLongToUIntList(e).GetLuaToArray()}AddCache(t){let e=null,i=null,l=null
t.isSelfChat_get()?(e=t.smChat.sender.objId,l=t.smChat.sender.accountIndex,i=t.smChat.recevierId):(e=t.smChat.recevierId,i=t.smChat.sender.objId,l=t.smChat.sender.accountIndex),
this.LoadCache(e,i,l)
const a=u.FromChatCellInfo(t)
n.t.encode(a),s.A.LusuoLongToUIntList(e).GetLuaToArray(),s.A.LusuoLongToUIntList(i).GetLuaToArray()}AddPrivateByJson(t){const e=n.t.decode(t,u).ToChatCellInfo()
a.d.Inst_get().model.privateModel.AddPrivateInfo(e,!1)}DeleteCache(t,e){s.A.LusuoLongToUIntList(t).GetLuaToArray(),s.A.LusuoLongToUIntList(e).GetLuaToArray()}}I.Inst=new I},
37949:(t,e,i)=>{i.d(e,{$:()=>_})
var s=i(98885),n=i(85602),l=i(87923),a=i(67595),o=i(6719),r=i(65550),h=i(26753),d=i(14143),c=i(64444)
class _{constructor(t){this.extradata=null,this.smChat=null,this.m_i18Context=null,this.m_txt=null,this.m_txt2=null,this.m_speakTxt=null,this.nameStr=null,this.isVoiceHeard=!1,
this.isShowTimeSpan=!1,this.isSystemInfo=!1,this.forceSystemInfo=!1,this.fullLinkStr=null,this.channelId=null,this.isOpenTipImmediately=!1,this.isTipWithClose=!1,
this.isCorrect=null,this.isTop1=null,this.smChat=t,this.channelId=this.smChat.channelId}static GetInst(t){if(_._pool.Count()>0){const e=_._pool[0]
return e.m_txt=null,e.m_txt2=null,e.fullLinkStr=null,e.smChat=t,_._pool.RemoveAt(0),e}return new _(t)}speakTxt_get(){this.txt_get(null)
return this.m_speakTxt}isVoice_get(){return null!=this.smChat&&null!=this.smChat.voiceUrl}SetSpeakTxt(t,e){this.m_speakTxt=t,this.m_txt=e,this.m_txt2=e}isSelfChat_get(){
return-1!=this.smChat.sender.job&&this.smChat.sender.IsMe()}GetMedelIcon(){const t=this.smChat.sender
return null!=t&&t.medalLv>0?a.v.Inst_get().GetMedalIcon(t.medalLv):[null,null]}txt_get(t){if(null==this.smChat.content&&(this.smChat.content=""),
null==this.smChat.content2&&(this.smChat.content2=""),null==t&&(t=!1),null==this.m_txt||null==this.m_txt2||null!=this.extradata&&this.extradata.dynamic){const e=this.smChat.sender
if(null!=this.extradata&&(this.m_txt=o.p.GetResultText(this.smChat.content,this.ChangeListToArr(this.smChat.infos),this.smChat.channelId,this.smChat.tag,this.extradata,1),
this.m_txt2=o.p.GetResultText(this.smChat.content2,this.ChangeListToArr(this.smChat.infos),this.smChat.channelId,this.smChat.tag,this.extradata,1,!0),
this.fullLinkStr=r.y.inst.fullLinkStr,this.smChat.content=this.m_txt,this.smChat.content2=this.m_txt2),
this.smChat.isworld)this.m_txt=o.p.GetResultText(this.smChat.content,this.ChangeListToArr(this.smChat.infos),this.smChat.channelId,1),
this.m_txt2=o.p.GetResultText(this.smChat.content2,this.ChangeListToArr(this.smChat.infos),this.smChat.channelId,1,!0),this.fullLinkStr=r.y.inst.fullLinkStr,
this.smChat.content=this.m_txt,this.smChat.content2=this.m_txt2
else if(-1==e.job)this.m_txt=this.smChat.content,this.m_txt2=this.smChat.content2
else if(this.isSelfChat_get())if(this.smChat.channelId==d.L.HORN)this.smChat.sender.gmLevel>0?this.nameStr=t?`${this.GetNameStr("[FF4B58][GM][-]我")}：`:`${this.GetNameStr("[962424][GM][-]我")}：`:this.nameStr=`${this.GetNameStr("我")}：`,
this.m_txt=this.smChat.content,this.m_txt2=this.smChat.content2
else if(this.smChat.channelId==d.L.PRIVATE){s.M.IntToString(c.B.PLAYER)
let t="",e=""
this.smChat.sender.gmLevel>0?(t=`${this.GetNameStr("[962424][GM][-]我")}：`,e=`${this.GetNameStr("[FF4B58][GM][-]我")}：`):(t=`${this.GetNameStr("我")}：`,e=`${this.GetNameStr("我")}：`),
this.m_txt=t+this.smChat.content,this.m_txt2=e+this.smChat.content2}else{let t="",e=""
this.smChat.sender.gmLevel>0?(t=`${this.GetNameStr("[962424][GM][-]我")}：`,e=`${this.GetNameStr("[FF4B58][GM][-]我")}：`):(t=`${this.GetNameStr("我")}：`,e=`${this.GetNameStr("我")}：`),
this.m_txt=t+this.smChat.content,this.m_txt2=e+this.smChat.content2}else{
let i=`${c.B.PLAYER}_${e.objId.low_get()}_${e.objId.high_get()}`,s=`${c.B.PLAYER}_${e.objId.low_get()}_${e.objId.high_get()}`
this.smChat.channelId==d.L.HORN?(this.nameStr="",this.smChat.sender.gmLevel>0?this.nameStr=t?`${this.GetNameStr(`[FF4B58][GM][-]${this.smChat.sender.name}`)}：`:`${this.GetNameStr(`[962424][GM][-]${this.smChat.sender.name}`)}：`:this.nameStr=`${this.GetNameStr(this.smChat.sender.name)}：`,
this.m_txt=this.smChat.content,this.m_txt2=this.smChat.content2):(this.smChat.channelId,d.L.PRIVATE,
this.smChat.sender.gmLevel>0?(i=l.l.SetNameLinkStr(`[962424][GM][-]${e.name}`,i,this.GetNameColor(),!1),
s=l.l.SetNameLinkStr(`[FF4B58][GM][-]${e.name}`,s,this.GetNameColor(),!1)):(i=l.l.SetNameLinkStr(e.name,i,this.GetNameColor(),!1),
s=l.l.SetNameLinkStr(e.name,s,this.GetNameColor(),!1)),this.m_txt=`${i}:${this.smChat.content}`,this.m_txt2=`${s}:${this.smChat.content2}`)}this.m_speakTxt=this.smChat.content}
return this.smChat.channelId==d.L.STALL&&(this.nameStr=`${this.GetNameStr("[交易]")}:`,
this.m_txt=o.p.GetResultText(this.smChat.content,this.ChangeListToArr(this.smChat.infos),this.smChat.channelId,1),
this.m_txt2=o.p.GetResultText(this.smChat.content2,this.ChangeListToArr(this.smChat.infos),this.smChat.channelId,1),this.fullLinkStr=r.y.inst.fullLinkStr,
this.smChat.content=this.m_txt,this.smChat.content2=this.m_txt2,this.m_speakTxt=this.m_txt),t?this.m_txt2:this.m_txt}GetNameStr(t){
const e=this.channelId,i=h.d.Inst_get().model.channelColorDic[e]
return null!=i&&(t=l.l.SetStringColor(i,t)),t}GetNameColor(){const t=this.channelId
return h.d.Inst_get().model.channelColorDic[t]}txt_set(t){this.m_txt=t}simpleTxt_get(){return`${this.GetChannelName()} ${this.txt_get(null)}`}GetChannelName(){
return h.d.Inst_get().model.GetChannelName(this.smChat.channelId)}ChangeListToArr(t){const e=t.Count(),i=new n.Z(e)
let s=0
for(;s<e;)i[s]=t[s],s+=1
return i}Clear(){this.m_txt=null,this.isShowTimeSpan=!1,this.fullLinkStr=null,null!=this.smChat&&this.smChat.voiceUrl}}_._pool=new n.Z,_.NAME_LINK_COLOR="0f66c8",
_.NAME_UNLINK_COLOR="8a5000"},83040:(t,e,i)=>{i.d(e,{W:()=>n})
var s=i(29756)
class n{constructor(){this.type=0,this.id=null,this.state=0,this.name=null,this.roleid=null,this.accountIndex=null,this.job=0,this.sex=0,this.vipLevel=0,this.param=null,
this.i18info=null,this.infoEx=null,this.dynamic=!0,this.account=null}getMineLink(){}getAssistLink(){if(null==this.infoEx){const t=new s.f
t.parent=this,this.infoEx=t}return this.infoEx}}},38903:(t,e,i)=>{i.d(e,{E:()=>s})
class s{}s.RedPacket=1,s.MineAssist=2,s.BossAssist=3},13612:(t,e,i)=>{i.d(e,{k:()=>it})
var s=i(38836),n=i(86133),l=i(38045),a=i(98800),o=i(13687),r=i(54967),h=i(62370),d=i(5924),c=i(95721),_=i(98130),u=i(98885),I=i(85602),m=i(72785),g=i(38962),p=i(62346),C=i(43076),S=i(87923),f=i(37648),T=i(55492),y=i(75439),A=i(33138),D=i(47786),E=i(52777),v=i(58458),w=i(10562),R=i(79124),P=i(14792),O=i(62734),L=i(12970),B=i(21334),b=i(83171),M=i(14143),G=i(16459),H=i(64444),N=i(37949),k=i(93984),U=i(55360),V=i(22662),x=i(65550),F=i(90419),q=i(50089),Y=i(63456),W=i(68662)
class j{constructor(t){this.res=null,this.openLevel=0,this.m_frontSendTime=-1e4,this.res=t,this.Parse()}Parse(){
const t=F.d.parseJsonObjectWithFix(this.res.senderCondDefs,"costs"),e=q.t.decode(t,Y.d)
this.openLevel=u.M.String2Int(e.costs[0].value),e.costs=null}isLevelEnough(){return a.Y.Inst.PrimaryRoleInfo_get().Level_get()>=this.openLevel}isDuringCd(t){
const e=W.D.serverMSTime_get()
let i=this.res.cd
return t&&(i*=2),e-this.m_frontSendTime<i||(this.m_frontSendTime=e,!1)}}class Z{constructor(){this.m_dic=null,this.frontStr=null}Init(){
const t=U.Y.Inst.GetOrCreateCsv(k.h.eChannelResource).GetCsvMap()
this.m_dic=new g.X
let e=0
for(const[i,n]of(0,s.V5)(t)){const t=new j(n)
e=this.GetChannel(n.scope),this.m_dic.LuaDic_AddOrSetItem(e,t)}}GetChannel(t){
return"WORLD"==t?M.L.WORLD:"NEARBY"==t?M.L.NEARBY:"TEAM"==t?M.L.TEAM:"ALLIANCE"==t?M.L.ALLIANCE:"LEGION"==t?M.L.LEGION:"PRIVATE"==t?M.L.PRIVATE:"STALL"==t?M.L.STALL:"CROSS"==t?M.L.CROSS_SERVER:M.L.HORN
}IsCanSend(t,e,i,s){null==s&&(s=!0),null==i&&(i=!0)
const l=this.m_dic[t]
if(!l.isLevelEnough()){if(i){const t=S.l.SetStringColor(S.l.txtGreenStr,u.M.IntToString(l.openLevel))+((0,n.T)("级开启")+(l.res.name+(0,n.T)("频道")))
x.y.inst.ClientStrMsg(V.r.SystemTipMessage,t)}return!1}if(s){let i=!1
if(t==M.L.CROSS_SERVER&&e==this.frontStr&&(i=!0),l.isDuringCd(i))return x.y.inst.ClientStrMsg(V.r.SystemTipMessage,(0,n.T)("发言过快，请休息一下吧")),!1
this.frontStr=e}return!0}}class X{constructor(){this.channel=M.L.TOTAL,this.model=null,this._degf_ResetLater=null,this._degf_ResetLater=()=>this.ResetLater()}list_get(){
return this.model.getDefaultShowList(this.channel)}channelName_get(){return this.model.GetChannelNTxt(this.channel)}isShow_get(){return this.model.curShowPanelChannel==this.channel
}isNeedChangeCount_get(){return this.channel==this.model.curShowPanelChannel}isNeedRefresh_get(){return this.isNeedChangeCount_get()&&this.model.isChannelInfoChanged(this.channel)}
ResetChanged(){this.model.ResetShowTagsChanged(this.channel)}GetPageCount(){return this.model.defaultShowCount}ChangeShowCount(t,e){this.model.UpdatePageCount(t,e)}}var K=i(38903)
class ${constructor(t,e,i){this.showStr=null,this.content=null,this.param=null,this.param=new I.Z,this.SetPara(t,e,i)}static GetInst(t,e,i){if($._pool.Count()>0){let s=$._pool[0]
return $._pool.RemoveAt(0),s?(s.SetPara(t,e,i),s):(s=new $(t,e,i),s)}return new $(t,e,i)}SetPara(t,e,i){if(this.showStr=t,this.content=e,null!=i){let t=0
for(;t<i.Count();)this.param.Add(i[t]),t+=1}}CopyToParam(t){for(const[e,i]of(0,s.V5)(this.param))t.Add(i)}Clear(){this.content=null,this.param.Clear(),$._pool.Add()}}
$._pool=new I.Z
class J{constructor(t){this.HISTORY_COUNT=10,this.m_model=null,this.m_sendHistoryList=null,this.m_receiveHistoryList=null,this.m_hisDic=null,this.m_sendHistoryList=new I.Z,
this.m_receiveHistoryList=new I.Z,this.m_hisDic=new g.X,this.m_model=t}AddReceiveSelfHistory(t){if(t.isSelfChat_get()){if(this.m_receiveHistoryList.Count()==this.HISTORY_COUNT){
this.m_receiveHistoryList[0]
this.m_receiveHistoryList.RemoveAt(0)}this.m_receiveHistoryList.Add(t)}}AddHistoryChat(t,e,i){let s=null
this.m_sendHistoryList.Count()==this.HISTORY_COUNT&&(s=this.m_sendHistoryList[0],this.m_sendHistoryList.RemoveAt(0),this.m_hisDic.LuaDic_Remove(s.content),s.Clear()),
s=$.GetInst(t,e,i),this.m_sendHistoryList.Add(s),this.m_hisDic.LuaDic_AddOrSetItem(e,s)}GetSelfReceiveHistory(){return this.m_receiveHistoryList}GetHistoryModel(t){
return this.m_hisDic.LuaDic_ContainsKey(t)?this.m_hisDic[t]:null}GetHistoryChatStr(t){return this.m_sendHistoryList.Count()>t?this.m_sendHistoryList[t]:null}GetHistoryMaxIndex(){
return this.m_sendHistoryList.Count()>this.HISTORY_COUNT?this.HISTORY_COUNT:this.m_sendHistoryList.Count()}}class z{constructor(){this.index=0,this.name=null,this.level=0,
this.id=null}}class Q{constructor(t,e,i,s){this.m_objId=null,this.m_accountIndex=null,this.m_objValue=0,this.m_name=null,this.hasNew=!1,this.receiverIsOnline=!0,this.m_list=null,
this.LastSendTime=0,this.sortValue=0,this.isSelfMsg=!1,this.job=0,this.sex=0,this.m_accountIndex=s,this.m_list=new I.Z,this.m_objId=t,this.m_objValue=t.ToNum(),this.m_name=e,
this.isSelfMsg=i,this.sortValue=Q.NewSortIndex()}GetSortValue(){return this.LastSendTime}static NewSortIndex(){const t=Q.sort_index
return Q.sort_index+=1,t}AddSortValue(){this.sortValue=Q.NewSortIndex()}AddItem(t){this.m_list.Add(t),this.m_list.Count()>it.MAX_NUM&&this.m_list.RemoveAt(0)}dispose(){
this.m_list.Clear(),this.m_list=null}}Q.sort_index=0
class tt{constructor(t){this.m_cModel=null,this.isNeedOpenPrivateChat=!1,this.PrivateChatParm_senderName="",this.PrivateChatParm_senderID=null,
this.PrivateChatParm_receiverIsOnline=!0,this.PrivateChatParm_job=0,this.PrivateChatParm_sex=0,this.m_privateDic=null,this.m_privateModels=null,this.hasNewPrivateModel=!1,
this.m_showPrivatePId=null,this._degf_OnPrivateSortFun=null,this.m_privateDic=new g.X,this.m_privateModels=new I.Z,this._degf_OnPrivateSortFun=(t,e)=>this.OnPrivateSortFun(t,e),
this.m_cModel=t}Reset(){this.m_privateModels.Clear(),this.m_privateDic.LuaDic_Clear()}AddPrivateInfo(t,e){if(t.smChat.channelId==M.L.PRIVATE){const i=t.smChat
let s=null,n=null
const l=null
let a=!1
t.isSelfChat_get()?(s=i.recevierId,n=i.recevierName,a=!0):(s=i.sender.objId,n=i.sender.name),this.hasNewPrivateModel=!1
let o=null
const r=s.ToKey()
if(this.m_privateDic.LuaDic_ContainsKey(r)?(o=this.m_privateDic[r],null!=n&&(o.m_name=n)):(e&&0==i.isRead&&(this.hasNewPrivateModel=!0),o=new Q(s,n,a,l),o.job=i.sender.job,
o.sex=i.sender.sex,this.m_privateDic.LuaDic_AddOrSetItem(r,o)),e&&(o.receiverIsOnline=i.receiverIsOnline,a||0==t.smChat.isRead&&(o.hasNew=!0)),0!=o.LastSendTime){
const e=i.sendTime-o.LastSendTime
t.isShowTimeSpan=e>86400}o.LastSendTime=i.sendTime,o.AddItem(t),this.m_cModel.RaiseEvent(G.F.UPDATE_PRIVATE_NAME_BTN,o)}}GetPrivateModes(){this.m_privateModels.Clear()
for(const[t,e]of(0,s.V5)(this.m_privateDic))this.m_privateModels.Add(e)
return this.m_privateModels.Sort(this.OnPrivateSortFun),this.m_privateModels}OnPrivateSortFun(t,e){const i=t,s=e
return s.GetSortValue()==i.GetSortValue()?0:s.GetSortValue()>i.GetSortValue()?1:-1}AddVirtualPrivateModel(t,e,i,s,n){this.hasNewPrivateModel=!0
let l=null
l=this.m_privateDic.LuaDic_GetItem(t.ToKey()),null==l?(l=new Q(t,e,!1,null),l.receiverIsOnline=i,l.job=s,l.sex=n,this.m_privateDic.LuaDic_AddOrSetItem(t.ToKey(),l)):(l.job=s,
l.sex=n,l.AddSortValue(),null!=e&&(l.m_name=e)),this.m_cModel.RaiseEvent(G.F.UPDATE_PRIVATE_NAME_BTN,l)}GetPrivateNameIndex(t){let e=null,i=this.m_privateModels.Count()-1
for(;i>-1;){if(e=this.m_privateModels[i],e.m_objId.Equal(t))return i
i-=1}return-1}SetShowPrivateId(t){this.m_showPrivatePId=t}GetCurPrivateList(){if(null!=this.m_showPrivatePId){const t=this.m_showPrivatePId.ToKey()
if(this.m_privateDic.LuaDic_ContainsKey(t))return this.m_privateDic[t]}return null}DelPrivatePlayer(t){this.m_privateDic[t.ToKey()].dispose(),
this.m_privateDic.LuaDic_Remove(t.ToKey())}UpdateOnLineInfo(t){const e=t.playerId.ToKey()
if(this.m_privateDic.LuaDic_ContainsKey(e)){const i=this.m_privateDic[e]
i.receiverIsOnline=0==t.offlineTime.ToNum(),this.m_cModel.RaiseEvent(G.F.UPDATE_PRIVATE_ONLINE_STATUS,i)}}}class et{constructor(t,e){this.isSystemMsg=!1,this.noticeStr=null,
this.isSystemMsg=t,this.noticeStr=e}}class it extends r.g{constructor(){super(),this.m_totalList=null,this.m_defaultTotalList=null,this.curChannel=-2,this.m_hornList=null,
this.m_channelDic=null,this.m_defaultChannelDic=null,this.m_channelName=null,this.m_cNameTxt=null,this.m_channelNoSawNum=null,this.m_scrollChannelItems=null,
this.curShowPanelChannel=M.L.SYSTEM,this.settingShowChannelDic=null,this.m_showChannelDic=null,this.m_showChannelArray=null,this.m_channels=null,this.privateModel=null,
this.historyModel=null,this.channelModel=null,this.m_curPriNameIndex=-1,this.defaultContentColor=null,this.m_isHasNew=!1,this._hornId=-1,this.showChangedChannel=null,
this.mainChangedChannel=null,this.defaultShowCount=it.DEFAULT_SHOW_MIN,this.m_isPageSmallShow=!1,this.pageShowHeight=it.MIN_SHOW_SIZE,this.FACE_LENGTH_CONST=null,
this.curHeadClickInfo=null,this.autoPlayVoiceQueue=null,this.autoPlayVoiceDict=null,this.channelColorDic=null,this.channelIconDic=null,this.currentPlayVoiceMapId=0,
this.waitToPlayVoiceMapId=0,this._degf_NameSort=null,this._degf_OnAction=null,this._degf_OnHornTimer=null,this._degf_SendChatTeamRedPointInfo=null,this.recordMin=null,
this.recordMax=null,this.levelIntercept=null,this.CopyDelayTime=null,this.channelTabSkin=void 0,this.m_hornList=new I.Z,this.m_channelDic=new g.X,this.m_defaultChannelDic=new g.X,
this.m_channelName=new g.X,this.m_cNameTxt=new g.X,this.m_channelNoSawNum=new g.X,this.m_scrollChannelItems=new I.Z,this.settingShowChannelDic=new g.X,
this.m_showChannelDic=new g.X,this.m_showChannelArray=new I.Z([M.L.TOTAL,M.L.SYSTEM,M.L.WORLD,M.L.ALLIANCE,M.L.CROSS_SERVER]),
this.m_channels=new I.Z([M.L.TOTAL,M.L.WORLD,M.L.INVITE_TEAM,M.L.TEAM,M.L.LEGION,M.L.ALLIANCE,M.L.CROSS_SERVER,M.L.PRIVATE,M.L.HORN,M.L.SYSTEM,M.L.NOTICE,M.L.NEARBY,M.L.MAIL,M.L.STALL]),
this.defaultContentColor=new I.Z(["ebebeb","ceccc5"]),this.showChangedChannel=new g.X,this.mainChangedChannel=new g.X,
this.FACE_LENGTH_CONST=new I.Z([8,2,12,2,4,5,2,2,4,2,4,2,8,4,13,3,10,10,8,6,9,4,10,4,11,6,5,8,2,9]),this.autoPlayVoiceQueue=new I.Z,this.autoPlayVoiceDict=new g.X,
this.channelColorDic=new g.X,this.channelIconDic=new g.X,this._degf_NameSort=(t,e)=>this.NameSort(t,e),this._degf_OnAction=()=>this.OnAction(),
this._degf_OnHornTimer=()=>this.OnHornTimer(),this._degf_SendChatTeamRedPointInfo=()=>this.SendChatTeamRedPointInfo()
const t=new I.Z(["c0a974","5e9fdb","74d0c4","8ccb8c","3ed966","4cbfa1","656ff5","b561bf","edba1e","b68462","9369e9","c2965d","bd7d73","a1cad1"]),e=new I.Z([(0,n.T)("综合"),(0,
n.T)("世界"),(0,n.T)("组队"),(0,n.T)("队伍"),(0,n.T)("军团"),(0,n.T)("战盟"),(0,n.T)("跨服"),(0,n.T)("私聊"),(0,n.T)("喇叭"),(0,n.T)("系统"),(0,n.T)("消息"),(0,n.T)("附近"),(0,n.T)("邮箱"),(0,
n.T)("交易")]),i=new I.Z(["rymainui_sp_0125","rymainui_sp_0121","rymainui_sp_0126","rymainui_sp_0109","rymainui_sp_0127","rymainui_sp_0120","rymainui_sp_0128","rymainui_sp_0123","rymainui_sp_0108","rymainui_sp_0106","rymainui_sp_0129","rymainui_sp_0107","rymainui_sp_0130","rymainui_sp_0131"])
this.channelTabSkin=new I.Z([["ryliaotian_sp_0018","ryliaotian_sp_0017"],["ryliaotian_sp_0020","ryliaotian_sp_0019"],["ryliaotian_sp_0022","ryliaotian_sp_0021"],["ryliaotian_sp_0024","ryliaotian_sp_0023"],["ryliaotian_sp_0026","ryliaotian_sp_0025"],["ryliaotian_sp_0026","ryliaotian_sp_0025"]])
let s=0
for(;s<this.m_channels.count;){this.m_channelDic.LuaDic_AddOrSetItem(this.m_channels[s],new I.Z),this.m_defaultChannelDic.LuaDic_AddOrSetItem(this.m_channels[s],new I.Z),
this.m_channelNoSawNum.LuaDic_AddOrSetItem(this.m_channels[s],0)
const n=S.l.SetStringColor(t[s],e[s])
this.m_channelName.LuaDic_AddOrSetItem(this.m_channels[s],n),this.m_cNameTxt.LuaDic_AddOrSetItem(this.m_channels[s],e[s]),
this.showChangedChannel.LuaDic_AddOrSetItem(this.m_channels[s],!0),this.channelColorDic.LuaDic_AddOrSetItem(this.m_channels[s],t[s]),
this.channelIconDic.LuaDic_AddOrSetItem(this.m_channels[s],i[s]),s+=1}this.m_totalList=this.m_channelDic[M.L.TOTAL],this.m_defaultTotalList=this.m_defaultChannelDic[M.L.TOTAL]
let l=0
for(;l<this.m_showChannelArray.count;){this.settingShowChannelDic.LuaDic_AddOrSetItem(this.m_showChannelArray[l],!0)
const t=new X
t.model=this,t.channel=this.m_showChannelArray[l],this.m_showChannelDic.LuaDic_AddOrSetItem(this.m_showChannelArray[l],t),l+=1}
this.m_showChannelDic.LuaDic_Remove(M.L.CROSS_SERVER),this.privateModel=new tt(this),this.historyModel=new J(this),this.channelModel=new Z,this.channelModel.Init(),
d.C.Inst_get().SetInterval(this._degf_OnAction,300),this.recordMin=y.D.getInstance().GetIntValue("VOICERECORD_MIN"),this.recordMax=y.D.getInstance().GetIntValue("VOICERECORD_MAX"),
this.levelIntercept=new g.X
const a=y.D.getInstance().GetStringArray("CHAT:PICKUPINFORMATION")
for(let t=0;t<=a.Count()-1;t++){const e=u.M.Split(a[t],"_")
this.levelIntercept.LuaDic_AddOrSetItem(u.M.String2Int(e[0]),u.M.String2Int(e[1]))}const o=y.D.getInstance().GetIntValue("CHAT_COPY_TIME")
this.CopyDelayTime=0==o?2e3:o}IsChannelShow(t){if(M.L.TOTAL==t)return!0
return this.settingShowChannelDic[t]}GetScrollChannels(){this.m_scrollChannelItems.Clear()
let t=0
const e=this.m_showChannelArray.count,i=a.Y.Inst.PrimaryRoleInfo_get().isHaveAlliance_get()
let s=0
for(;s<e;)t=this.m_showChannelArray[s],this.m_showChannelDic.LuaDic_ContainsKey(t)&&this.settingShowChannelDic[t]&&(t!=M.L.ALLIANCE||i)&&this.m_scrollChannelItems.Add(this.m_showChannelDic[t]),
s+=1
return this.m_scrollChannelItems}SetContentColor(t,e){return S.l.SetStringColor("453D3A",t)}SetCurShowChannel(t){const e=this.m_scrollChannelItems[t]
this.curShowPanelChannel=e.channel}GetShowList(t){return this.m_channelDic.LuaDic_ContainsKey(t)?this.m_channelDic[t]:(m.c.DebugError(`m_channelDic can not contain key = ${t}`),
null)}getDefaultShowList(t){return this.m_defaultChannelDic[t]}DelChatsByChannel(t){let e=this.m_channelDic[t]
e.Clear(),e=this.m_defaultChannelDic[t],e.Clear()
let i=null,s=this.m_totalList.Count()-1
for(;s>-1;)i=this.m_totalList[s],i.channelId==t&&this.m_totalList.RemoveAt(s),s-=1
for(s=this.m_defaultTotalList.Count()-1;s>-1;)i=this.m_defaultTotalList[s],i.channelId==t&&this.m_defaultTotalList.RemoveAt(s),s-=1
this.CallUpdate()}AddChat(t,e){if(null==e&&(e=!0),t.smChat.channelId==M.L.HORN&&(this.m_hornList.Add(t),d.C.Inst_get().ClearInterval(this._hornId),
this._hornId=d.C.Inst_get().SetInterval(this._degf_OnHornTimer,1e4),this.OnHornTimer()),t.smChat.channelId==M.L.ALLIANCE){
if(!a.Y.Inst.PrimaryRoleInfo_get().isHaveAlliance_get())return
const e=C.w.Inst_get().curstage_get(),i=C.w.Inst_get().isWaitState;(e!=p.o.eQuestioning||i)&&(t.isCorrect="none",t.isTop1=!1)}t.smChat.channelId==M.L.PRIVATE&&t.isVoice_get(),
this.m_isHasNew=!0,this.privateModel.AddPrivateInfo(t,!0),this.SendHubble(t),b.d.Inst_get().DealNotiece(t),this.SendSimpleNotice(t.isSystemInfo,t),this.CalaCount(t),
this.StoreInfo(t,e)}SendSimpleNotice(t,e){if(e.smChat.channelId==M.L.NOTICE||e.smChat.channelId==M.L.CROSS_SERVER)return
let i=!0
if((!t&&this.curShowPanelChannel!=M.L.TOTAL&&e.smChat.channelId!=this.curShowPanelChannel||e.smChat.channelId==M.L.SYSTEM)&&(i=!1),i){const i=new et(t,e.simpleTxt_get())
this.RaiseEvent(G.F.SHOW_ONE_SIMPLE_NOTICE,i)}}CalaCount(t){let e=this.m_channelNoSawNum[t.smChat.channelId]
e+=1,this.m_channelNoSawNum[t.smChat.channelId]=e}GetNoSawCount(t){return this.m_channelNoSawNum[t]}ResetNoSawCount(){for(const[t,e]of(0,
s.V5)(this.m_channels))this.m_channelNoSawNum[e]=0}SendHubble(t){t.smChat.sender.job}StoreInfo(t,e){null==e&&(e=!1)
let i=t.smChat.channelId
i==M.L.HORN&&(i=M.L.WORLD),i!=M.L.CROSS_SERVER&&i!=M.L.PRIVATE&&e&&(this.m_totalList.Add(t),this.m_defaultTotalList.Add(t))
const s=this.m_channelDic[i]
s.Add(t),this.DelChat(s,!0,i)
const n=this.m_defaultChannelDic[i]
n.Add(t),this.DelDefaultChat(n),i!=M.L.CROSS_SERVER&&(this.DelChat(this.m_totalList,!1,M.L.TOTAL),this.DelDefaultChat(this.m_defaultTotalList),
this.showChangedChannel[M.L.TOTAL]=!0,this.mainChangedChannel[M.L.TOTAL]=!0),this.showChangedChannel[i]=!0,this.mainChangedChannel[i]=!0,
t.isSelfChat_get()||(i==M.L.TEAM?d.C.Inst_get().SetInterval(this._degf_SendChatTeamRedPointInfo,200,1):i==M.L.ALLIANCE?O.f.Inst.SetState(P.t.CHAT_ASURAM,!0):i==M.L.CROSS_SERVER&&O.f.Inst.SetState(P.t.CHAT_CROSS_SERVER,!0))
}SendChatTeamRedPointInfo(){const t=a.Y.Inst.PrimaryRoleInfo_get().isHaveTeam_get()
O.f.Inst.SetState(P.t.CHAT_TEAM,t)}GetDyChatCellInfo(t,e){let i=null,s=0
const n=this.m_channelDic[e]
for(s=0;s<n.Count();){if(i=n[s],null!=i.extradata&&i.extradata.id.Equal(t))return i
s+=1}return i}ChangeExtraData(t,e){2!=e.type&&(e.type!=K.E.BossAssist?t.extradata=e:t.extradata.getAssistLink().state=2)}updateChatInfo(t,e){let i=null,s=null,n=0
for(n=0;n<this.m_totalList.Count();)s=this.m_totalList[n],null!=s.extradata&&s.extradata.id.Equal(t)&&(i=s,this.ChangeExtraData(s,e)),n+=1
for(n=0;n<this.m_defaultTotalList.Count();)s=this.m_defaultTotalList[n],null!=s.extradata&&s.extradata.id.Equal(t)&&(i=s,this.ChangeExtraData(s,e)),n+=1
if(null!=s){const i=s.smChat.channelId,l=this.m_channelDic[i],a=this.m_defaultChannelDic[i]
for(n=0;n<l.Count();)s=l[n],null!=s.extradata&&s.extradata.id.Equal(t)&&this.ChangeExtraData(s,e),n+=1
for(n=0;n<a.Count();)s=a[n],null!=s.extradata&&s.extradata.id.Equal(t)&&this.ChangeExtraData(s,e),n+=1}this.CallUpdate()}ChangeExpired(t){
const e=D.x.Inst().getItemById(t.smChat.tag),i=t.txt_get(null),s=u.M.Replace(i,e.tips3,(0,n.T)("已过期")),l=u.M.Replace(s,"047104","8E8279")
t.txt_set(l)}isChannelInfoChanged(t){return this.showChangedChannel[t]}isMainTagChanged(t){return this.mainChangedChannel[t]}SetCurChannelChanged(){
this.showChangedChannel[this.curChannel]=!0,this.mainChangedChannel[this.curChannel]=!0}ResetShowTagsChanged(t){this.showChangedChannel[t]=!1}ResetMainTagsChanged(t){
this.mainChangedChannel[t]=!1}CallUpdate(){this.RaiseEvent(G.F.UPDATE_CHAT,!0)}OnAction(){this.m_isHasNew&&(this.m_isHasNew=!1,this.RaiseEvent(G.F.UPDATE_CHAT,!0))}OnHornTimer(){
if(0==this.m_hornList.Count())d.C.Inst_get().ClearInterval(this._hornId),this._hornId=-1
else{const t=this.m_hornList[0]
this.m_hornList.RemoveAt(0),this.RaiseEvent(G.F.SHOW_HORN_MESSAGE,t)}}AddTipChat(t,e,i,s,n,l,a,o,r,h,d){null==a&&(a=!1),null==l&&(l=!1),null==r&&(r=!1),null==h&&(h=!1)
const _=this.LevelIntercept(i,s)
l=l&&!_
const u=new v.O
if(u.tag=i,u.sender=new E.C,u.sender.job=-1,u.channelId=t,u.content=e,u.content2=d,u.sender.objId=c.o.ZERO,u.sender.name="",null!=s){const t=new I.Z
let e=0
for(;e<s.count;)t.Add(s[e]),e+=1
u.infos=t}const m=N.$.GetInst(u)
return null!=o?(m.forceSystemInfo=!1,m.isSystemInfo=!1,u.sender.job=o.job,u.sender.objId=o.roleid,u.sender.name=o.name,u.sender.sex=o.sex,u.sender.vipLevel=o.vipLevel,
u.sender.showVip=!0,u.sender.accountIndex=o.accountIndex):(m.forceSystemInfo=a,m.isSystemInfo=!0),m.m_i18Context=n,m.extradata=o,m.isOpenTipImmediately=r,m.isTipWithClose=h,
this.AddChat(m,l),m}CloneInfo(t,e){}IsCanCrossServer(){return f.P.Inst_get().IsFunctionOpened(T.x.CROSS_CHAT)}DelChat(t,e,i){let s=it.MAX_NUM
if(i==M.L.CROSS_SERVER&&(s=it.CROSS_MAX_NUM),t.Count()>s){const i=t[0]
t.RemoveAt(0),e&&i.Clear()}}UpdatePageCount(t,e){if(e||(t+=1),this.defaultShowCount>t){this.defaultShowCount=t
const e=this.m_defaultChannelDic[this.curShowPanelChannel]
let i=e.Count()-t
for(;i>0;)e.RemoveAt(0),i-=1}else this.defaultShowCount=it.DEFAULT_SHOW_MAX,this.m_isPageSmallShow&&(this.defaultShowCount=it.DEFAULT_SHOW_MIN),this.defaultShowCount=t,
this.FullShowCount(this.curShowPanelChannel,this.defaultShowCount)}FullShowCount(t,e){const i=this.m_defaultChannelDic[t]
i.Clear()
const s=this.m_channelDic[t]
let n=0
const l=s.Count()
l>e&&(n=l-e)
let a=n
for(;a<l;)i.Add(s[a]),a+=1}UpdateDefaultCount(t){if(this.m_isPageSmallShow=t,this.defaultShowCount=it.DEFAULT_SHOW_MAX,this.pageShowHeight=it.PK_SHOW_SIZE,t){
this.defaultShowCount=it.DEFAULT_SHOW_MIN,this.pageShowHeight=it.MIN_SHOW_SIZE
for(const[t,e]of(0,s.V5)(this.m_defaultChannelDic)){let t=e.Count()
for(;t>it.DEFAULT_SHOW_MIN;)e.RemoveAt(0),t-=1}}else for(const[t,e]of(0,s.vy)(this.m_defaultChannelDic))this.FullShowCount(t,it.DEFAULT_SHOW_MAX)}DelDefaultChat(t){
t.Count()>this.defaultShowCount&&t.RemoveAt(0)}GetFaceList(t){const e=new I.Z
let i=0
for(;i<24;)t?e.Add(i+it.FACE_HORN_VALUE):e.Add(i),i+=1
return e}GetFaceEnd(t){return 100*t+this.FACE_LENGTH_CONST[t]}GetChannelName(t){return this.m_channelName[t]}GetChannelNTxt(t){return this.m_cNameTxt[t]}GetPointLinkStr(){
const t=new I.Z(2),e=a.Y.Inst.PrimaryRole_get().GetPos()
e.x=_.GF.INT(e.x),e.z=_.GF.INT(e.z)
const i=h.o.s_UNDER_CHAR,s=B.p.Inst_get().GetMapById(o.b.Inst.currentMapId_get()),l=L.F.getInst().CurLine_get(),r=H.B.POINT+(i+(s.id+(i+(e.x+(i+(e.z+(i+l)))))))
let d=s.name
return d+=`${l}${(0,n.T)("线")}${u.M.s_LEFT_S_K_CHAR}${e.x}:${e.z+u.M.s_RIGHT_S_K_CHAR}`,t[0]=S.l.SetStringColor(S.l.txtGreenStr,(0,n.T)("[我的位置]")),
t[1]=it.USE_POS+S.l.SetLinkStr(d,r,S.l.txtGreenStr,!0),t}DealNameQuery(t){const e=new I.Z
let i=null,n=0
const l=a.Y.Inst.PlayerId_get()
for(const[a,o]of(0,s.vy)(t))if(!a.Equal(l)){i=new z,i.index=(()=>{const t=n
return n+=1,t})(),i.id=a
const s=t[a],l=u.M.Split(s,h.o.s_Arr_UNDER_CHAR_DOT)
i.name=l[0],i.level=u.M.String2Int(l[1]),e.Add(i)}e.sort(this.NameSort),this.RaiseEvent(G.F.RETURN_QUERY_ACCOUNT,e)}NameSort(t,e){const i=t,s=e
return i.level>s.level?-1:i.level<s.level?1:0}LevelIntercept(t,e){if(null==e)return!1
const i=e.Count()
for(let t=0;t<=i-1;t++)if((0,l.t2)(e[t],R.o)){const i=e[t]
if("金币"==i.str)return!0
if("钻石"==i.str)return!0}if(100575==t)for(let t=0;t<=e.Count()-1;t++)if((0,l.t2)(e[t],w.F)){
const t=e[0],i=a.Y.Inst.m_primaryRoleInfo.Level_get(),n=A.f.Inst().getItemById(t.item.modelId)
if(0==n.pickNotify)return!0
for(const[t,e]of(0,s.vy)(this.levelIntercept))if(i>=t&&n.quality<=e)return!0}return!1}Reset(){this.m_curPriNameIndex=-1,this.m_totalList.Clear(),this.m_hornList.Clear()
for(const[t,e]of(0,s.vy)(this.m_defaultChannelDic))this.m_defaultChannelDic[t].Clear()
for(const[t,e]of(0,s.vy)(this.m_channelDic))this.m_channelDic[t].Clear()
this.privateModel.Reset(),this.autoPlayVoiceQueue.Clear(),this.autoPlayVoiceDict.LuaDic_Clear(),this.currentPlayVoiceMapId=0,this.waitToPlayVoiceMapId=0}}it.WARN_TIP_SHOW_KEY="",
it.HORN_ITEM_ID=10702,it.FACE_FRAME=10,it.MAX_NUM=50,it.CROSS_MAX_NUM=25,it.INPUT_MAX=50,it.DEFAULT_SHOW_MAX=9,it.DEFAULT_SHOW_MIN=5,it.MIN_SHOW_SIZE=96,it.MAX_SHOW_SIZE=230,
it.PK_SHOW_SIZE=96,it.FACE_HORN_VALUE=1e3,it.USE_POS="&PS*"},8664:(t,e,i)=>{var s,n=i(18998),l=i(83908),a=i(86133),o=i(5924),r=i(61911),h=i(79534),d=i(87923),c=i(53075)
n._decorator.ccclass("AlliQuestionPanel")(s=class extends((0,l.pA)(r.f)()){constructor(...t){super(...t),this.m_playLabel=null,this.curcfg=null,this._lefttimeintervalId=-1,
this._lefttime=0,this.totaltime=0,this._lefttimeintervalId2=-1,this._lefttime2=0,this._degf_TimeChange=null,this._degf_TimeChange2=null,this._degf_plyeOpenffect=null,
this._degf_plyeSlffect=null}_initBinder(){super._initBinder(),this._degf_TimeChange=()=>this.TimeChange(),this._degf_TimeChange2=()=>this.TimeChange2(),
this._degf_plyeOpenffect=()=>this.plyeOpenffect(),this._degf_plyeSlffect=()=>this.plyeSlffect()}InitView(){this.isExclusionPanel=!1,this.isKillAllExcluded=!0,
this.DestoryPanelLevel=r.f.DestoryLevel4,this.m_playLabel=new c.a(this.dialoglabel,null)}OnAddToScene(){this.AddOrDelEvent(!0),this.resetshow(),this.resetdata(),this.showInfo(!0),
this.questionopeneffect.node.SetActive(!1),o.C.Inst_get().SetFrameLoop(this._degf_plyeOpenffect,5,1),o.C.Inst_get().SetFrameLoop(this._degf_plyeSlffect,10,1)}resetshow(){
this.txteffect.node.SetActive(!1),this.daduieffect.node.SetActive(!1)}resetdata(){}plyeOpenffect(){this.questionopeneffect.node.SetActive(!0)}plyeSlffect(){}plyeOkffect(){
this.txteffect.node.SetActive(!0),this.daduieffect.node.SetActive(!0)}showQuestion(t,e){}PlayEndHandler(){}showInfo(t){}showLeftTime(t){this._lefttime=t
const e=d.l.GetDateFormatEX(this._lefttime,!1)
this.timeTxt.textSet(e+(0,a.T)("后进入下一题")),this.lefttimenext.textSet(e+(0,a.T)("秒后进入下一题")),-1!=this._lefttimeintervalId&&(o.C.Inst_get().ClearInterval(this._lefttimeintervalId),
this._lefttimeintervalId=-1),this._lefttimeintervalId=o.C.Inst_get().SetInterval(this._degf_TimeChange,1e3)}TimeChange(){let t=""
this._lefttime-=1,this._lefttime<1&&(o.C.Inst_get().ClearInterval(this._lefttimeintervalId),this._lefttimeintervalId=-1),t=d.l.GetDateFormatEX(this._lefttime,!1)
const e=h.P.zero_get()
e.Set(this._lefttime/this.totaltime,1,1),this.slider.node.setScale(e),this.timeTxt.textSet(t+(0,a.T)("后进入下一题")),this.lefttimenext.textSet(t+(0,a.T)("秒后进入下一题"))}showLeftOpenTime(t){
this._lefttime2=t
const e=d.l.GetDateFormatEX(this._lefttime2,!1)
this.nostartTxt.textSet(e+(0,a.T)("后活动开始")),-1!=this._lefttimeintervalId2&&(o.C.Inst_get().ClearInterval(this._lefttimeintervalId2),this._lefttimeintervalId2=-1),
this._lefttimeintervalId2=o.C.Inst_get().SetInterval(this._degf_TimeChange2,1e3)}TimeChange2(){let t=""
this._lefttime2-=1,this._lefttime2<1&&(o.C.Inst_get().ClearInterval(this._lefttimeintervalId2),this._lefttimeintervalId2=-1),t=d.l.GetDateFormatEX(this._lefttime2,!1),
this.nostartTxt.textSet(t+(0,a.T)("后活动开始"))}AddOrDelEvent(t){}calcurscore(){this.curcfg}Clear(){this.AddOrDelEvent(!1),this.m_playLabel.StopAndFull(),
o.C.Inst_get().ClearInterval(this._lefttimeintervalId),this._lefttimeintervalId=-1,o.C.Inst_get().ClearInterval(this._lefttimeintervalId2),this._lefttimeintervalId2=-1}DoHide(){
super.DoHide()}Destroy(){this.m_playLabel=null}})},19381:(t,e,i)=>{i.d(e,{$:()=>F})
var s=i(18998),n=i(83908),l=i(86133),a=i(98885),o=i(87923),r=i(26753),h=i(98407),d=i(14143),c=i(64444),_=i(37949),u=i(28192),I=i(52212),m=i(38836),g=i(98800),p=i(97960),C=i(97461),S=i(5924),f=i(43133),T=i(99294),y=i(9986),A=i(6665),D=i(36437),E=i(57834),v=i(30849),w=i(79534),R=i(44758),P=i(70850),O=i(63076),L=i(75696),B=i(92679),b=i(79878),M=i(17783),G=i(16459),H=i(90866),N=i(98899)
class k extends v.C{constructor(){super(),this.popupPanel=null,this.popupTab=null,this.faceGrid=null,this.itemGrid=null,this.taskGrid=null,this.closeCollider=null,
this.collider2=null,this.collider3=null,this.posBtn=null,this.m_tabIndex=0,this.mainPanel=null,this.m_model=null,this.m_posTimer=-1,this._degf_OnChatUpdate=null,
this._degf_OnCloseBtn=null,this._degf_OnCreateFace=null,this._degf_OnCreateItem=null,this._degf_OnCreateTask=null,this._degf_OnGOBtn=null,this._degf_OnItemRefresh=null,
this._degf_OnTabSelected=null,this._degf_bagUpdateHandler=null,this.faceDel=null,this._degf_OnChatUpdate=t=>this.OnChatUpdate(t),this._degf_OnCloseBtn=(t,e)=>this.OnCloseBtn(t,e),
this._degf_OnCreateFace=t=>this.OnCreateFace(t),this._degf_OnCreateItem=t=>this.OnCreateItem(t),this._degf_OnCreateTask=t=>this.OnCreateTask(t),
this._degf_OnGOBtn=(t,e)=>this.OnGOBtn(t,e),this._degf_OnItemRefresh=()=>this.OnItemRefresh(),this._degf_OnTabSelected=t=>this.OnTabSelected(t),
this._degf_bagUpdateHandler=t=>this.bagUpdateHandler(t)}InitView(){this.popupPanel=new T.z,this.popupPanel.setId(this.FatherId,this.FatherComponentID,1),this.popupTab=new D.K,
this.popupTab.setId(this.FatherId,this.FatherComponentID,2),this.faceGrid=new A.A,this.faceGrid.setId(this.FatherId,this.FatherComponentID,3),this.itemGrid=new A.A,
this.itemGrid.setId(this.FatherId,this.FatherComponentID,4),this.taskGrid=new A.A,this.taskGrid.setId(this.FatherId,this.FatherComponentID,5),this.closeCollider=new f.V,
this.closeCollider.setId(this.FatherId,this.FatherComponentID,8),this.collider2=new f.V,this.collider2.setId(this.FatherId,this.FatherComponentID,9),this.collider3=new f.V,
this.collider3.setId(this.FatherId,this.FatherComponentID,10),this.posBtn=new T.z,this.posBtn.setId(this.FatherId,this.FatherComponentID,11),
this.faceDel=this.CreateComponent(y.W,12),this.m_model=r.d.Inst_get().model,this.popupTab.SetSelectHandler(this._degf_OnTabSelected),this.popupTab.SetSelectIndex(0),
this.faceGrid.SetInitInfo("UI_Chat_Face",this._degf_OnCreateFace),this.faceGrid.data_set(this.m_model.GetFaceList(!1)),
this.itemGrid.SetInitInfo("ui_baseitem",this._degf_OnCreateItem),this.taskGrid.SetInitInfo("ui_chat_taskcell",this._degf_OnCreateTask)}OnCreateTask(t){const e=new N.v
return e.setId(t,null,0),e}OnCreateFace(t){const e=new H.l
return e.tag=k.CHAT_POPUP_CELL,e.setId(t,null,0),e}OnCreateItem(t){const e=new L.j
return e.setId(t,null,0),e}OnTabSelected(t){this.m_tabIndex=t,this.Update()}Update(){S.C.Inst_get().ClearInterval(this.m_posTimer),this.m_posTimer=-1,
1==this.m_tabIndex?this.taskGrid.data_set(M.L.Inst_get().model.GetChatList()):2==this.m_tabIndex&&this.UpdateItemData()}UpdateItemData(){
S.C.Inst_get().CallLater(this._degf_OnItemRefresh)}OnItemRefresh(){const t=P.g.Inst_get().GetAllItem(),e=g.Y.Inst.PrimaryRoleInfo_get().AllStageEquipments_get()
for(const[i,s]of(0,m.vy)(e)){const s=e[i]
let n=0
for(;n<s.equipmentsGet().Count();){const e=s.equipmentsGet()[n]
if(null!=e){const i=new O.M
i.serverData_set(e),t.Add(i)}n+=1}}this.itemGrid.data_set(t)}ChangeShowPopup(){const t=this.popupPanel.activeSelf()
this.popupPanel.SetActive(!t),t?this.AddOrDelEvent(!1):(this.AddOrDelEvent(!0),this.Update())}ClosePop(){this.popupPanel.activeSelf()&&(this.ChangeShowPopup(),
this.SetUpContentY(!1))}SetUpContentY(t){const e=this.mainPanel.contentPanel.transform.GetLocalPosition(),i=this.mainPanel.horncontainer.horncontainer.transform.GetLocalPosition()
let s=null
s=this.mainPanel.m_isQuest?this.mainPanel.scrollPanelQuestTimeSize:this.mainPanel.scrollPanelSize
const n=new R.L(s.x,s.y,s.z,s.w),l=n.w-this.mainPanel.chatTable.node.GetBoundsSize().y
let a=!1,o=0
this.mainPanel.chatScrollview.RemoveSpringPanel(),l<0&&(a=!0),i.y=-615,t?(e.y=315,n.y+=e.y/2,n.w-=e.y):e.y=0,this.mainPanel.contentPanel.transform.SetLocalPosition(e),
this.mainPanel.horncontainer.horncontainer.transform.SetLocalPosition(i+e),this.mainPanel.chatScrollviewPanel.baseClipRegionSet(n),this.mainPanel.curScrollPanelSize=n
const r=new w.P
if(t){a?o=315:(o=this.mainPanel.chatTable.node.GetBoundsSize().y-n.w,o<0&&(o=0))
const t=this.mainPanel.chatScrollviewPanel.node.transform.GetLocalPosition(),e=this.mainPanel.chatScrollviewPanel.clipOffset()
t.y<0?(r.Set(t.x),this.mainPanel.chatScrollviewPanel.node.transform.SetLocalPosition(r),r.Set(e.x),
this.mainPanel.chatScrollviewPanel.clipOffsetSet(new I.F(e.x,0))):a&&t.y>-l&&(r.Set(t.x,-l),this.mainPanel.chatScrollviewPanel.node.transform.SetLocalPosition(r),r.Set(e.x,l),
this.mainPanel.chatScrollviewPanel.clipOffsetSet(r))}else a?o=-315:(o=0,this.mainPanel.chatScrollview.ResetPosition())
r.Set(0,o),this.mainPanel.chatScrollview.MoveRelative(r),w.P.Recyle(r)}AddOrDelEvent(t){
const e=E.i.Get(this.closeCollider.node),i=E.i.Get(this.collider2.node),s=E.i.Get(this.collider3.node)
this.InitHandlerMgr(),t?(C.i.Inst.AddEventHandler(B.g.BAG_UPDATE,this._degf_bagUpdateHandler),
g.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(p.A.EquipmentsUpdate,this._degf_bagUpdateHandler),this.m_model.AddEventHandler(G.F.UPDATE_CHAT,this._degf_OnChatUpdate),
e.RegistonClick(this._degf_OnCloseBtn),i.RegistonClick(this._degf_OnCloseBtn),s.RegistonClick(this._degf_OnCloseBtn),
this.m_handlerMgr.AddClickEvent(this.faceDel,this.CreateDelegate(this.OnFaceDel)),b.Y.RegLuaClick(this.posBtn,this._degf_OnGOBtn)):(this.m_handlerMgr.Clear(),
C.i.Inst.RemoveEventHandler(B.g.BAG_UPDATE,this._degf_bagUpdateHandler),g.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(p.A.EquipmentsUpdate,this._degf_bagUpdateHandler),
S.C.Inst_get().ClearInterval(this.m_posTimer),this.m_posTimer=-1,this.m_model.RemoveEventHandler(G.F.UPDATE_CHAT,this._degf_OnChatUpdate),e.RemoveonClick(this._degf_OnCloseBtn),
i.RemoveonClick(this._degf_OnCloseBtn),s.RemoveonClick(this._degf_OnCloseBtn),b.Y.DelLuaClick(this.posBtn,this._degf_OnGOBtn))}OnFaceDel(){this.mainPanel.OnFaceDel()}
OnCloseBtn(t,e){this.ChangeShowPopup()}OnChatUpdate(t){this.m_tabIndex}bagUpdateHandler(t){1==this.popupTab.GetSelectIndex()&&this.UpdateItemData()}OnGOBtn(t,e){
this.mainPanel.ClearInput()
const i=this.m_model.GetPointLinkStr()
if(this.mainPanel.AddLinkStrToInput(i[0])){const t=i[1]
this.mainPanel.linkDic.LuaDic_AddOrSetItem(i[0],t)}}Destory(){this.popupTab.RemoveSelectHandler(this._degf_OnTabSelected),this.popupPanel=null,this.popupTab.Destory(),
this.popupTab=null,this.faceGrid.Destroy(),this.faceGrid=null,this.itemGrid.Destroy(),this.itemGrid=null,this.taskGrid.Destroy(),this.taskGrid=null,this.mainPanel=null,
this.m_model=null,this.closeCollider=null,this.collider2=null,this.collider3=null,this.posBtn=null}}k.CHAT_POPUP_CELL="chat_popup_cell"
var U,V,x=i(24499)
let F=s._decorator.ccclass("ChatCell")((V=class t extends((0,n.yk)()){constructor(...t){super(...t),this.m_useHeight=0,this.m_info=null,this.ismain=!1,this._degf_OnTxtClick=null,
this.tag=void 0,this._m_handlerMgr=null}_initBinder(){this._degf_OnTxtClick=(t,e)=>this.OnTxtClick(t,e)}get m_handlerMgr(){
return this._m_handlerMgr||(this._m_handlerMgr=u.h.Get()),this._m_handlerMgr}InitView(){
this.tag==x.c.CHAT_BOTTOM_SHOW_CELL?this.chatLabel.widthSet(305):this.tag==k.CHAT_POPUP_CELL&&this.chatLabel.widthSet(406)}SetData(t){if(this.m_info=t,
this.m_info.isVoice_get())this.SetVoiceTxt()
else{const t=this.m_info.txt_get(this.ismain)
this.SetTxt(t)}this.m_handlerMgr.AddClickEvent(this.chatLabel.node,this._degf_OnTxtClick),
this.m_info.forceSystemInfo&&(this.tag==x.c.CHAT_BOTTOM_SHOW_CELL&&r.d.Inst_get().model.curShowPanelChannel==d.L.TOTAL||r.d.Inst_get().model.curChannel==d.L.TOTAL)?this.channelLabel.textSet((0,
l.T)("[b68462]系统[-]")):this.channelLabel.textSet(this.m_info.GetChannelName()),this.m_useHeight=this.chatLabel.height(),this.m_useHeight+=10,this.container.height=this.m_useHeight
const e=new I.F(this.faceLabel.width(),this.faceLabel.height())
this.collider.widthSet(e.x),this.collider.heightSet(e.y),e.x/=2,e.y/=-2}SetTxt(t){this.faceLabel.node.transform.SetLocalPositionXYZ(46,-2,0),
this.faceLabel.textSet(a.M.TransRichTextHref(t))}SetVoiceTxt(){const t=this.m_info.smChat.voiceContent
this.ShowVoice(t)}ShowVoice(e){if(this.m_info.isSelfChat_get())e=this.GetNameStr("我")+(t.USE_VOC+e)
else{let i=a.M.IntToString(c.B.PLAYER)
i=o.l.SetNameLinkStr(this.m_info.smChat.sender.name,i,null,!0),i=o.l.SetStringColor(_.$.NAME_LINK_COLOR,i+t.USE_VOC),e=this.GetNameStr(i)+e}this.SetTxt(e)
const i=new I.F(this.faceLabel.width(),this.faceLabel.height())
this.collider.widthSet(i.x),this.collider.heightSet(i.y),i.x/=2,i.y/=-2}GetNameStr(t){const e=this.m_info.channelId,i=r.d.Inst_get().model.channelColorDic[e]
return null!=i&&(t=o.l.SetStringColor(i,t)),t}OnTxtClick(t,e){if(this.tag==k.CHAT_POPUP_CELL){const t=r.d.Inst_get().model.historyModel.GetHistoryModel(this.m_info.smChat.content)
null!=t&&r.d.Inst_get().controller.ChatMainPanel_get().ShowHistory(t)}else h.C.OnTxtClick(this.chatLabel,this.m_info,this.tag)}cellHeight_get(){return this.m_useHeight}Clear(){
this.m_info=null,null!=this.chatLabel&&this.m_handlerMgr.RemoveClickEvent(this.chatLabel.node,this._degf_OnTxtClick)}Destroy(){}},V.VOICE_TAG="@space$",V.USE_VOC="$VE*",U=V))||U},
90866:(t,e,i)=>{i.d(e,{l:()=>d})
var s=i(83908),n=i(28192),l=i(98130),a=i(26753),o=i(16459),r=i(13612),h=i(98885)
class d extends((0,s.yk)()){constructor(...t){super(...t),this.indexValue=0,this.m_sendTag=null,this._degf_OnFaceClick=null,this._m_handlerMgr=null}_initBinder(){
super._initBinder(),this._degf_OnFaceClick=(t,e)=>this.OnFaceClick(t,e)}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=n.h.Get()),this._m_handlerMgr}InitView(){}
SetData(t){let e=l.GF.INT(t)
this.indexValue=e,e>=r.k.FACE_HORN_VALUE&&(e-=r.k.FACE_HORN_VALUE)
let i=""
const s=e+1
i=e<10?`0${e}`:h.M.IntToString(e),this.m_sendTag=s<10?`0${s}`:h.M.IntToString(s)
a.d.Inst_get().model.GetFaceEnd(e)
this.sprite.skin=`WEB:/icon/face/f${i}01.png`,this.m_handlerMgr.AddClickEvent(this.sprite,this.CreateDelegate(this.OnFaceClick)),this.sprite.heightSet(48),this.sprite.widthSet(48),
this.sprite.name=d.FACE_SPRITE_NAME
this.effect.anim=["f00","f01","f02","f03","f04","f05","f06","f07","f08","f09","f10","f11","f12","f13","f14","f15","f16","f17","f18","f19","f20","f21","f22","f23","f24","f25","f26","f27","f28","f29"][e]
}OnFaceClick(t,e){a.d.Inst_get().model.RaiseEvent(o.F.SELECT_FACE,this.m_sendTag)}ResetClickEvent(){
this.m_handlerMgr.AddClickEvent(this.sprite,this.CreateDelegate(this.OnFaceClick))}Clear(){this.m_handlerMgr.RemoveClickEvent(this.sprite,this.CreateDelegate(this.OnFaceClick))}
Destroy(){}}d.FACE_SPRITE_NAME="faceItem"},43263:(t,e,i)=>{i.d(e,{X:()=>o})
var s,n=i(18998),l=i(83908),a=i(26753)
let o=n._decorator.ccclass("ButtonExtendsSkinView")(s=class extends((0,l.Ri)()){constructor(...t){super(...t),this.normalSkin=null,this.disableSkin=null,this.index=void 0}
InitView(){super.InitView(),this.normalSkin=null,this.disableSkin=null}SetSelect(t,e){var i=t?1:0,s=t?"ryliaotian_bt_0003":"ryliaotian_bt_0004"
this.extraskin.skin="atlas/liaotian/"+a.d.Inst_get().model.channelTabSkin[e][i],this.channelBtn.skin="atlas/liaotian/"+s}Clear(){super.Clear()}SetDisable(){
this.extraskin.spriteNameSet(this.disableSkin)}SetNormal(){this.extraskin.spriteNameSet(this.normalSkin)}Destroy(){super.destroy()}Test1(){return!0}S_Test(){return!0}})||s},
94533:(t,e,i)=>{var s,n=i(18998),l=i(83908),a=i(86133),o=i(98800),r=i(97461),h=i(98130),d=i(85602),c=i(79534),_=i(92984),u=i(54415),I=i(92679),m=i(85638),g=i(24239),p=i(49894)
n._decorator.ccclass("ChatBuffContainer")(s=class extends((0,l.yk)()){constructor(...t){super(...t),this.gridNilData=null,this._degf_GetEnemyBuffItem=null,
this._degf_GetPKBuffItem=null,this._degf_OnCollectSliderUpdate=null,this.buffModel=null}_initBinder(){this.gridNilData=new d.Z,
this._degf_GetEnemyBuffItem=t=>this.GetEnemyBuffItem(t),this._degf_GetPKBuffItem=t=>this.GetPKBuffItem(t),this._degf_OnCollectSliderUpdate=t=>this.OnCollectSliderUpdate(t)}
InitView(){this.enemyBuffGrid.SetInitInfo("ui_mainview_pkenemybuff",null,m.w),this.debuffGrid.SetInitInfo("ui_mainview_pkbuffitem",null,p.o),this.buffModel=_.j.Inst_get().model}
GetEnemyBuffItem(t){const e=new m.w
return e.setId(t,null,0),e}GetPKBuffItem(t){const e=new g.w
return e.isDebuff=!0,e.setId(t,null,0),e}ShowTip(t,e,i,s){if(1==e){const e=this.debuffDetail.node.transform.GetLocalPosition()
this.debuffDetail.node.SetActive(!0),this.debuffDetail.SetData(t),e.x=i-16,e.y=10+this.debuffDetail.bgHei,this.debuffDetail.node.transform.SetLocalPosition(e),c.P.Recyle(e)
}else 2==e&&(this.enemydetail.node.SetActive(!0),this.enemydetail.SetData(t))}CloseTip(){this.debuffDetail.node.SetActive(!1),this.enemydetail.node.SetActive(!1),
this.debuffDetail.Clear(),this.enemydetail.Clear()}Clear(){this.RemoveLis(),this.enemyBuffGrid.data_set(this.gridNilData),this.debuffGrid.data_set(this.gridNilData)}AddLis(){
r.i.Inst.AddEventHandler(I.g.COLLECT_SLIDER_UPDATE,this._degf_OnCollectSliderUpdate)}RemoveLis(){
r.i.Inst.RemoveEventHandler(I.g.COLLECT_SLIDER_UPDATE,this._degf_OnCollectSliderUpdate)}OnCollectSliderUpdate(t){if(1==h.GF.INT(t))this.debuffObj.SetActive(!1)
else{const t=o.Y.Inst.PrimaryRoleInfo_get().Id_get()
this.buffModel.GetDebuffs(t).count>0&&this.debuffObj.SetActive(!0)}}UpdateBuff(){this.AddLis(),this.UpdateEnemyBuff()
const t=o.Y.Inst.PrimaryRoleInfo_get().Id_get(),e=this.buffModel.GetDebuffs(t)
if(e.count>0){const t=u.k.Inst_get().m_collectUI;(null==t||t.node.activeInHierarchy)&&this.debuffObj.SetActive(!0),this.debuffGrid.data_set(e)
const i=(0,a.T)("您被")+(e[0].buffRes_get().buffName+(0,a.T)("了"))
this.debuffDesc.textSet(i)}else this.debuffObj.SetActive(!1),this.debuffDetail.node.SetActive(!1)}UpdateEnemyBuff(){const t=o.Y.Inst.CurTarget_get()
if(null!=t&&null!=t.objId){const e=this.buffModel.GetEnemyBuffs(t.objId)
0==e.count&&this.enemydetail.node.SetActive(!1),this.enemyBuffGrid.data_set(e)}else this.enemyBuffGrid.data_set(this.gridNilData),this.enemydetail.node.SetActive(!1)}})},
64290:(t,e,i)=>{i.d(e,{l:()=>_})
var s,n=i(6847),l=i(83908),a=i(17409),o=i(49655),r=i(46282),h=i(28192),d=i(26753),c=i(27047)
let _=(0,n.s_)(o.o.ChatCopyTipId,r.Z.ui_chat_copytip).register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),this._degf_OnColiderClose=null,
this._degf_OnTipClick=null,this._m_handlerMgr=null}_initBinder(){super._initBinder(),this._degf_OnColiderClose=(t,e)=>this.OnColiderClose(t,e),
this._degf_OnTipClick=(t,e)=>this.OnTipClick(t,e)}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=h.h.Get()),this._m_handlerMgr}InitView(){}OnAddToScene(){
this.AddOrDelEvent(!0),d.d.Inst_get().controller.m_copyTip=this}AddOrDelEvent(t){t?(this.AddClickEvent(this.bg,this._degf_OnTipClick),(0,
a.D1)(this,this.CreateDelegate(this.OnColiderClose))):this.RemoveClickEvent(this.bg,this._degf_OnTipClick)}OnColiderClose(t,e){d.d.Inst_get().controller.CloseCopyTip()}
OnTipClick(t,e){const i=d.d.Inst_get().controller
c.w.Inst_get().IsPanelOpen()?c.w.Inst_get().panel.inputLabel.SetSymbolStr(i.copyTipShowStr):i.ChatMainPanel_get().ShowFromTip(i.copyTipShowStr),i.CloseCopyTip()}Clear(){
this.AddOrDelEvent(!1)}Destroy(){}})||s},89543:(t,e,i)=>{var s,n,l=i(18998),a=i(83908),o=i(26753),r=i(90866)
l._decorator.ccclass("ChatFaceView")(((n=class extends((0,a.Ri)()){constructor(...t){super(...t),this.m_model=null}InitView(){super.InitView(),this.m_model=o.d.Inst_get().model,
this.faceGrid.SetInitInfo("ui_rychat_face",null,r.l),this.faceGrid.data_set(this.m_model.GetFaceList(!1))}ResetClickEvent(){const t=this.faceGrid.itemList.Count()
for(let e=0;e<=t-1;e++)this.faceGrid.itemList[e].ResetClickEvent()}CloseHandler(){this.HandleClick(!1)}HandleClick(t){let e
null==t?(e=this.node.active,e=!e):e=t,e&&this.ResetClickEvent(),this.node.SetActive(e),this.m_handlerMgr.AddClickEvent(this.collider,this.CreateDelegate(this.CloseHandler))}
Clear(){super.Clear(),this.m_handlerMgr.RemoveClickEvent(this.collider,this.CreateDelegate(this.CloseHandler))}Destroy(){this.faceGrid.destroy(),super.destroy()}
}).CHAT_POPUP_CELL=null,s=n))},55104:(t,e,i)=>{var s,n,l=i(18998),a=i(83908),o=i(5924),r=i(98130),h=i(79534),d=i(98407)
l._decorator.ccclass("ChatHornBinder")((n=class t extends((0,a.yk)()){constructor(...t){super(...t),this._moveTimerId=-1,this.m_labelVec=null,this.m_endX=0,this.m_showTimerId=-1,
this._info=null,this.isForMainPanel=!1,this.m_isNoSawShow=!1,this.m_isHornShow=!1,this.m_maxWidth=0,this.isPlay=!1,this.frontXPos=-1,this.m_panelMoveTemp=0,this.m_useMaskW=0,
this._degf_OnTimerInterval=null,this._degf_OnTxtClick=null,this._degf_ShowFinish=null}_initBinder(){super._initBinder(),this.m_labelVec=new h.P,
this._degf_OnTimerInterval=()=>this.OnTimerInterval(),this._degf_OnTxtClick=(t,e)=>this.OnTxtClick(t,e),this._degf_ShowFinish=()=>this.ShowFinish()}InitView(){
this.m_maxWidth=t.SHOW_MASK_WIDTH}InitForMainPanel(){this.m_maxWidth=t.MASK_WIDTH,this.isForMainPanel=!0,this.noSawPanel.SetActive(!1),this.SetShow(!1)}SetShow(t){
t?this.horncontainer.SetActive(!0):(this.horncontainer.SetActive(!1),this.ShowFinish())}SetXPos(t,e){if(this.frontXPos!=t){this.frontXPos=t
const e=this.horncontainer.transform.GetLocalPosition()
e.x=t,this.horncontainer.transform.SetLocalPosition(e),h.P.Recyle(e)}}SetNoSawShow(t){this.m_isNoSawShow!=t&&(this.m_isNoSawShow=t,this.DealBg())}DealBg(){if(this.isForMainPanel){
let t=!1,e=0,i=-24
if(this.m_isHornShow&&(e+=66,i=42,t=!0),this.m_isNoSawShow){e+=40
const s=this.noSawPanel.transform.GetLocalPosition()
s.y=i,this.noSawPanel.transform.SetLocalPosition(s),h.P.Recyle(s),t=!0}this.hornWidget.SetActive(this.m_isHornShow),this.noSawPanel.SetActive(this.m_isNoSawShow),
this.horncontainer.SetActive(t)}}SetData(t){this.m_isHornShow=!0,this.isPlay=!0,this.SetShow(!0),this._info=t,this.faceLabel.textSet(this._info.txt_get(null)),
this.namelabel.textSet(this._info.nameStr),this.SetVipShow(),this.SetMove(),this.DealBg()}SetVipShow(){const t=this.namelabel.node.transform.GetLocalPosition()
t.x=52
this._info.smChat.sender.vipLevel
this.m_useMaskW=this.m_maxWidth
this.m_panelMoveTemp=0
const e=r.GF.INT(this.namelabel.fontSize)-12
this.m_useMaskW-=e,this.m_panelMoveTemp+=.5*e,h.P.Recyle(t)}SetMove(){const t=r.GF.INT(this.namelabel.fontSize),e=this.showMask.node.transform.GetLocalPosition()
e.x=this.namelabel.node.transform.GetLocalPosition().x+t,this._info.smChat.sender.vipLevel>0&&this._info.smChat.sender.showVip&&(e.x-=20),e.x-=this.m_panelMoveTemp+10,
this.showMask.node.transform.SetLocalPosition(e),h.P.Recyle(e),this.animation.SetActive(!0),this.m_showTimerId>-1&&o.C.Inst_get().ClearInterval(this.m_showTimerId),
this._moveTimerId>-1&&o.C.Inst_get().ClearInterval(this._moveTimerId),this._moveTimerId=o.C.Inst_get().ClearInterval(this._moveTimerId),
this.m_labelVec=this.label.node.transform.GetLocalPosition()
const i=this.label.fontSize
this.m_endX=this.m_useMaskW-i,this.m_endX<0?(this.m_endX-=100,this.m_labelVec.x=this.m_maxWidth,
this._moveTimerId=o.C.Inst_get().SetInterval(this._degf_OnTimerInterval,40)):(this.m_labelVec.x=28,this.isForMainPanel&&(this.m_labelVec.x=21)),
this.m_labelVec.x=this.m_labelVec.x+(this.m_panelMoveTemp+3),this.label.node.transform.SetLocalPosition(this.m_labelVec)}OnTimerInterval(){this.m_labelVec.x=this.m_labelVec.x-3,
this.m_labelVec.x<=this.m_endX&&(this.m_labelVec.x=this.m_maxWidth,this._degf_ShowFinish()),this.label.node.transform.SetLocalPosition(this.m_labelVec)}OnTxtClick(t,e){
d.C.OnTxtClick(this.label,this._info,null)}SetYPos(t){const e=this.horncontainer.transform.GetLocalPosition()
e.y=t,this.horncontainer.transform.SetLocalPosition(e),h.P.Recyle(e)}ShowFinish(){this.animation.SetActive(!1),this.namelabel.textSet(""),
o.C.Inst_get().ClearInterval(this._moveTimerId),this.isForMainPanel?(this.m_isHornShow=!1,this.DealBg()):this.horncontainer.SetActive(!1),this.isPlay=!1}Destory(){
this.m_showTimerId>-1&&o.C.Inst_get().ClearInterval(this.m_showTimerId),o.C.Inst_get().ClearInterval(this._moveTimerId)}},n.MASK_WIDTH=454,n.SHOW_MASK_WIDTH=324,s=n))},
7182:(t,e,i)=>{
var s,n,l=i(18998),a=i(6847),o=i(83908),r=i(46282),h=i(38836),d=i(86133),c=i(38045),_=i(98800),u=i(97960),I=i(97461),m=i(50089),g=i(65829),p=i(68662),C=i(5924),S=i(66788),f=i(52726),T=i(60130),y=i(95721),A=i(98130),D=i(98885),E=i(85602),v=i(38962),w=i(79534),R=i(44758),P=i(85430),O=i(43076),L=i(15033),B=i(67885),b=i(92679),M=i(87923),G=i(48933),H=i(73341),N=i(21987),k=i(37648),U=i(55492),V=i(75755),x=i(22662),F=i(84632),q=i(90181),Y=i(44644),W=i(51576),j=i(14792),Z=i(62734),X=i(86144),K=i(96297),$=i(95802),J=i(65550),z=i(619),Q=i(26753),tt=i(14143),et=i(16459),it=i(64444),st=i(83388),nt=i(80928),lt=i(13612),at=i(49655),ot=i(28192),rt=i(80486),ht=i(98407),dt=i(43263),ct=i(38314),_t=i(66999),ut=i(69688)
;(0,
a.s_)(at.o.eChatMainPanel,r.Z.ui_rychat_mainpanel).waitPrefab(r.Z.ui_mail_detail).waitPrefab(r.Z.ui_mail_main).waitPrefab(r.Z.ui_mail_rewarditem).waitPrefab(B.S.modulePathList).waitPrefab(r.Z.ui_rychat_face).waitPrefab(r.Z.ui_chat_totalcell).waitPrefab(r.Z.ui_chat_cell).hideMainUI().hideNPCLayerUI().register()(((n=class extends((0,
o.Ri)()){constructor(...t){super(...t),this.btnSprite0=null,this.btnSprite1=null,this.btnSprite2=null,this.btnSprite3=null,this.btnSprite4=null,this.btnSprite5=null,
this.teamRedDot=null,this.m_moveTween=null,this.m_model=null,this.m_privateModel=null,this.m_mgr=null,this.m_paramList=null,this.linkDic=null,this.m_tempKeyDic=null,
this.m_controller=null,this.m_primaryRoleInfo=null,this.isInit=!1,this.btnList=null,this.skinList=null,this.m_btnSpPahts=null,this.m_moveValue=null,this.voiceCallbackId=0,
this.m_isSystemShow=!1,this.m_channelSelcetIndex=-1,this.m_btnSprite=null,this.m_frontBgStr=null,this.openTxt=null,this.m_isFirst=!0,this.m_frontFaceStr=null,
this.m_tempFaceStr=null,this.m_isDraging=!1,this.m_runTime=0,this.m_isTableResponstion=!0,this.boundPanelRatio=0,this.lastScrollBarVal=0,this.m_scrollValue=0,this.m_callId=-1,
this.m_isBack=!0,this.m_isMove=!1,this.m_isFirstMoveOut=!0,this.m_privateSenderName=null,this.m_privateSenderId=null,this.showNotOnlineIntervalId=-1,this.m_closeType=0,
this.scrollPanelSize=null,this.scrollPanelQuestTimeSize=null,this.curScrollPanelSize=null,this.m_isQuest=!1,this.curBarValue=0,this._scrollToEndDelayTimeId=0,this.faceCollider=!1,
this.isPrivate=!1,this.isPrivateCalled=!1,this._degf_AsuramIdUpdate=null,this._degf_CallScrollValue=null,this._degf_CloseOtherPanel=null,this._degf_CreatePrivateNameCell=null,
this._degf_CreateSystemCell=null,this._degf_FinishHandler=null,this._degf_OnBtnClick=null,this._degf_OnChannelSelect=null,this._degf_OnChatUpdate=null,
this._degf_OnDragFinished=null,this._degf_OnDragStarted=null,this._degf_OnFullclick=null,this._degf_OnHornShow=null,this._degf_OnInputChanged=null,
this._degf_OnNameGridReposition=null,this._degf_OnPressVoiceBtn=null,this._degf_OnPressVoiceBtnNow=null,this._degf_OnPrivateBtnUpdate=null,this._degf_OnSelectFace=null,
this._degf_OnSendVoice=null,this._degf_OnShowItem=null,this._degf_OnTableResponstion=null,this._degf_OnTypeSelect=null,this._degf_ResetNotOnLineObj=null,this._degf_SetFaceStr=null,
this._degf_SetPrivateList=null,this._degf_TeamUpdate=null,this._degf_UpdateAsuramRedPoint=null,this._degf_UpdateMailCount=null,this._degf_UpdateMailRedPoint=null,
this._degf_UpdatePrivateOnlineStaus=null,this._degf_UpdateTeamRedPoint=null,this._degf_UpdateAnchors=null,this._degf_StopPlayVoice=null,this._degf_PlayVoiceSuccess=null,
this._degf_OnPrivateCallLater=null,this._degf_CloseThisPanel=null,this.btnSkin0=null,this.btnSkin1=null,this.btnSkin2=null,this.btnSkin3=null,this.btnSkin4=null,this.btnSkin5=null,
this.IsAdStallState=null,this.m_primaryRoleInfo0=null,this.stallTimer=null,this.m_privateJob=null,this._degf_OnRoleClick=null,this.typeTabList=null,this.curSelectIdx=-1,
this.ClickChecker=null,this.channelTabList=null,this.curSelectChannelTabIdx=-1,this.offsetY=0,this._m_handlerMgr=null,this.m_callId1=void 0}get m_handlerMgr(){
return this._m_handlerMgr||(this._m_handlerMgr=ot.h.Get()),this._m_handlerMgr}_initBinder(){super._initBinder(),this.m_paramList=new E.Z,this.linkDic=new v.X,
this.m_tempKeyDic=new v.X,this.btnList=new E.Z,this.skinList=new E.Z,this.scrollPanelSize=new R.L(245,-301,490,602),this.scrollPanelQuestTimeSize=new R.L(272,-188,536,369),
this._degf_AsuramIdUpdate=t=>this.AsuramIdUpdate(t),this._degf_CallScrollValue=()=>this.CallScrollValue(),this._degf_CloseOtherPanel=()=>this.CloseOtherPanel(),
this._degf_CreatePrivateNameCell=t=>{},this._degf_CreateSystemCell=t=>this.CreateSystemCell(t),this._degf_FinishHandler=()=>this.FinishHandler(),
this._degf_OnBtnClick=(t,e)=>this.OnBtnClick(t,e),this._degf_OnChannelSelect=t=>this.OnChannelSelect(t),this._degf_OnChatUpdate=t=>this.OnChatUpdate(t),
this._degf_OnDragFinished=()=>this.OnDragFinished(),this._degf_OnDragStarted=()=>this.OnDragStarted(),this._degf_OnFullclick=(t,e)=>this.OnFullclick(t,e),
this._degf_OnHornShow=t=>this.OnHornShow(t),this._degf_OnInputChanged=()=>this.OnInputChanged(),this._degf_OnNameGridReposition=()=>this.OnNameGridReposition(),
this._degf_OnPressVoiceBtn=(t,e)=>this.OnPressVoiceBtn(t,e),this._degf_OnPressVoiceBtnNow=(t,e)=>this.OnPressVoiceBtnNow(t,e),
this._degf_OnPrivateBtnUpdate=t=>this.OnPrivateBtnUpdate(t),this._degf_OnSelectFace=t=>this.OnSelectFace(t),this._degf_OnSendVoice=()=>this.OnSendVoice(),
this._degf_OnShowItem=t=>this.OnShowItem(t),this._degf_OnTableResponstion=()=>this.OnTableResponstion(),this._degf_OnTypeSelect=t=>this.OnTypeSelect(t),
this._degf_ResetNotOnLineObj=()=>this.ResetNotOnLineObj(),this._degf_SetFaceStr=()=>this.SetFaceStr(),this._degf_SetPrivateList=t=>this.SetPrivateList(t),
this._degf_TeamUpdate=t=>this.TeamUpdate(t),this._degf_UpdateAsuramRedPoint=(t,e)=>this.UpdateAsuramRedPoint(t,e),this._degf_UpdateMailCount=t=>this.UpdateMailCount(t),
this._degf_UpdateMailRedPoint=(t,e)=>this.UpdateMailRedPoint(t,e),this._degf_UpdatePrivateOnlineStaus=t=>this.UpdatePrivateOnlineStaus(t),
this._degf_UpdateTeamRedPoint=(t,e)=>this.UpdateTeamRedPoint(t,e),this._degf_UpdateAnchors=t=>this.UpdateAnchors(t),this._degf_StopPlayVoice=t=>this.StopPlayVoice(t),
this._degf_PlayVoiceSuccess=t=>this.PlayVoiceSuccess(t),this._degf_OnPrivateCallLater=()=>this.OnPrivateCallLater(),this._degf_CloseThisPanel=()=>this.closeThisPanel()}InitView(){
this.btnList.Add(this.channel0),this.btnList.Add(this.channel1),this.btnList.Add(this.channel2),this.btnList.Add(this.channel3),this.btnList.Add(this.channel4),
this.btnList.Add(this.stallonbtn),this.skinList.Add(this.btnSkin0),this.skinList.Add(this.btnSkin1),this.skinList.Add(this.btnSkin2),this.skinList.Add(this.btnSkin3),
this.skinList.Add(this.btnSkin4),this.skinList.Add(this.btnSkin5),this.horncontainer.InitForMainPanel(),this.m_model=Q.d.Inst_get().model,
this.chatTable.SetInitInfo("ui_chat_totalcell",null,ut.D),this.chatTable.OnReposition_set(this._degf_OnTableResponstion),this.InitChannelTab(),this.InitTypeTab(),
this.personNameGrid.SetInitInfo("ui_chat_privateBtn",null,ct.r),this.m_privateModel=this.m_model.privateModel,this.m_mgr=Q.d.Inst_get().mgr,
this.m_controller=Q.d.Inst_get().controller,this.m_moveTween=new z.m,this.privateRedTip.SetActive(!1),this.m_moveValue=this.GetMoveValue(),this.keyIcon.node.SetActive(!1),
this.mailCnt.node.SetActive(!1),this.SetScreenBg(),this.channel4.node.SetActive(!1),this.IsAdStallState=!1,
null==Q.d.Inst_get().controller.m_mainPanel&&(Q.d.Inst_get().controller.m_mainPanel=this)}InitChannelTab(){
this.channelTabList=new E.Z([this.channel0,this.channel1,this.channel2,this.channel3,this.channel4])
for(let t=0;t<this.channelTabList.Count();t++)this.channelTabList[t].index=t,this.channelTabList[t].node.on(l.NodeEventType.TOUCH_END,this._OnChannelTabClick,this,!1,[this.channelTabList[t]])
}_OnChannelTabClick(t){(0,c.t2)(t,dt.X)&&t.index!=this.curSelectChannelTabIdx&&this.SetCurChannelSelectIdx(t.index,!0,!0)}SetCurChannelSelectIdx(t,e,i){
(e||t!=this.curSelectChannelTabIdx)&&(null==e&&(e=!1),null==i&&(i=!0),this.curSelectChannelTabIdx=t,this._OnChannelItemReposition(),
this._degf_OnChannelSelect(this.curSelectChannelTabIdx))}_OnChannelItemReposition(){for(let t=0;t<=this.channelTabList.Count()-1;t++){
this.channelTabList[t].SetSelect(t==this.curSelectChannelTabIdx,t)}}InitTypeTab(){this.typeTabList=new E.Z([this.channelbtn,this.personbtn,this.mailbtn])
for(let t=0;t<this.typeTabList.Count();t++)this.typeTabList[t].index=t,this.typeTabList[t].node.on(l.NodeEventType.TOUCH_END,this._OnTabClick,this,!1,[this.typeTabList[t]])}
_OnTabClick(t){(0,c.t2)(t,_t.j)&&t.index!=this.curSelectIdx&&(null==this.ClickChecker||this.ClickChecker(t.index))&&this.SetCurSelectIdx(t.index,!0,!0)}SetCurSelectIdx(t,e,i){
(e||t!=this.curSelectIdx)&&(null==e&&(e=!1),null==i&&(i=!0),this.curSelectIdx=t,this._OnRoleItemReposition(),this._degf_OnTypeSelect(this.curSelectIdx))}_OnRoleItemReposition(){
for(let t=0;t<=this.typeTabList.Count()-1;t++){this.typeTabList[t].SetSelect(t==this.curSelectIdx)}}SetScreenBg(){this.screenBg.heightSet(A.GF.INT(m.t.GetUIHeight())+100)}
OnNameGridReposition(){if(null==this.m_model&&S.Y.LogError("m_model为空"),this.m_model.m_curPriNameIndex>-1){
this.m_model.m_curPriNameIndex>this.personNameGrid.itemList.Count()-1&&S.Y.LogError(`索引溢出${this.m_model.m_curPriNameIndex}itemcount:${this.personNameGrid.itemList.Count()}`)
const t=this.personNameGrid.itemList[this.m_model.m_curPriNameIndex]
null!=t?t.SetEnabled():S.Y.LogError("AS 失败")}this.chatScrollview.ResetPosition(),this.m_model.curChannel==tt.L.PRIVATE&&Q.d.Inst_get().controller.RefreshPrivateBtnSelectStatus()}
CreateSystemCell(t){return null}OnChannelSelect(t){if(-1==(t=this.GetShowChannel(t)))return
;(tt.L.GetChannel(this.m_model.curChannel)==tt.L.ALLIANCE&&tt.L.GetChannel(t)!=tt.L.ALLIANCE||tt.L.GetChannel(this.m_model.curChannel)!=tt.L.ALLIANCE&&tt.L.GetChannel(t)==tt.L.ALLIANCE)&&this.m_mgr.RequestCM_ReadAsuramMsg(),
this.m_channelSelcetIndex=t,this.m_model.curChannel=tt.L.GetChannel(this.m_channelSelcetIndex)
const e=this.IsSystemShow()
this.SetTableShow(e),this.isInit&&(F.R.GetInst().ShowOrHidePanel(!1),this.upContent.SetActive(!0)),this.OnChangeTab(),this.isInit=!0}GetShowChannel(t){const e=tt.L.GetChannel(t)
if(!Q.d.Inst_get().model.IsChannelShow(e)){t=-1
const e=new E.Z
e.Add(tt.L.TOTAL),e.Add(tt.L.SYSTEM),e.Add(tt.L.WORLD),e.Add(tt.L.ALLIANCE)
for(let i=0;i<=e.Count()-1;i++)if(Q.d.Inst_get().model.IsChannelShow(e[i])){t=i
break}}return t}OnTypeSelect(t){if(null==this.inputLabel)return
this.m_model.autoPlayVoiceQueue.Clear(),this.m_model.autoPlayVoiceDict.LuaDic_Clear(),this.m_model.currentPlayVoiceMapId=0,this.m_model.waitToPlayVoiceMapId=0,
this.inputLabel.string="",this.searchFriendBtn.node.SetActive(!1),this.hornBtn.node.SetActive(!1),this.FriendBtn.node.SetActive(!1)
let e=!1,i=!0,s=!1
if(this.question.node.SetActive(!1),0!=t&&this.m_model.curChannel==tt.L.ALLIANCE&&this.m_mgr.RequestCM_ReadAsuramMsg(),this.SetPrivateObj(!1),this.mailbg.SetActive(!1),0==t){
if(-1==this.m_channelSelcetIndex&&(this.m_channelSelcetIndex=0),this.m_channelSelcetIndex=this.GetShowChannel(this.m_channelSelcetIndex),-1==this.m_channelSelcetIndex)return
Q.d.Inst_get().model.privateModel.isNeedOpenPrivateChat=!1,Q.d.Inst_get().controller.IsOpenMail=!1,this.m_model.curChannel=tt.L.GetChannel(this.m_channelSelcetIndex),
this.m_privateSenderName=null,this.m_model.curChannel==tt.L.STALL?(this.noInpuTxt.textSet("仅能发送商品广告"),
this.IsAdStallState=null!=$.U.Inst_get().chatItemId):(this.noInpuTxt.textSet("该频道不能发言，请切换至其他频道！"),this.IsAdStallState&&(this.IsAdStallState=!1,$.U.Inst_get().ClearAdChat())),
this.channelTab.node.SetActive(!0),this.privateBtns.SetActive(!1),this.bg1.SetActive(!0),e=this.IsSystemShow(),this.SetTableShow(e),i=!1,this.checkAllianceQuestion()
}else 1==t?(Q.d.Inst_get().model.privateModel.isNeedOpenPrivateChat=!0,Q.d.Inst_get().controller.IsOpenMail=!1,this.m_model.curChannel=tt.L.PRIVATE,
this.channelTab.node.SetActive(!1),this.privateBtns.SetActive(!0),this.searchFriendBtn.node.SetActive(!0),this.SetTableShow(!1),this.OnChangeTab(),F.R.GetInst().ClosePanel(),
this.m_isSystemShow=!1,i=!1,s=!0,this.SetPrivateObj(!0)):2==t&&(Q.d.Inst_get().model.privateModel.isNeedOpenPrivateChat=!1,Q.d.Inst_get().controller.IsOpenMail=!0,
this.m_model.curChannel=tt.L.MAIL,F.R.GetInst().OpenPanel(),this.channelTab.node.SetActive(!1),this.privateBtns.SetActive(!1),this.mailbg.SetActive(!0))
if(!i&&!s)if(F.R.GetInst().ClosePanel(),Q.d.Inst_get().controller.m_channel>-1){const t=ht.C.GetMainBtnIndex(Q.d.Inst_get().controller.m_channel)
Q.d.Inst_get().controller.m_channel=-1,this.SetCurChannelSelectIdx(t,!0,null),this.openTxt=Q.d.Inst_get().controller.openTxt
}else-1==this.curSelectChannelTabIdx&&0==t?this.SetCurChannelSelectIdx(0,null,null):(0==t&&this.m_model.curChannel==tt.L.ALLIANCE&&this.m_mgr.RequestCM_ReadAsuramMsg(),
this.OnChangeTab())}checkAllianceQuestion(){this.question.node.SetActive(!1),this.m_model.curChannel==tt.L.ALLIANCE&&P.a.isInAllianceBossMap_get()&&O.w.Inst_get().checkInActivity()
}SetQuestionTimeSize(){if(this.question.node.active&&0==this.m_isQuest)return this.curScrollPanelSize=this.scrollPanelQuestTimeSize,G.I.calVec0.Set(0,-275,0),
this.chatOffset.SetLocalPosition(G.I.calVec0),this.m_isQuest=!0,this.CallUpdate(),!0
if(0==this.question.node.active&&1==this.m_isQuest){this.curScrollPanelSize=this.scrollPanelSize
const t=w.P.zero_get()
return this.chatOffset.SetLocalPosition(t),w.P.Recyle(t),this.m_isQuest=!1,this.CallUpdate(),!0}return!1}updateQuestion(){}closeQuestion(){
null!=this.question&&(this.question.node.SetActive(!1),this.SetQuestionTimeSize())}IsSystemShow(){
return this.m_model.curChannel==tt.L.STALL?!this.IsAdStallState:this.m_model.curChannel==tt.L.SYSTEM||this.m_model.curChannel==tt.L.NOTICE||this.m_model.curChannel==tt.L.INVITE_TEAM||this.m_model.curChannel==tt.L.TOTAL
}SetTableShow(t){this.m_isSystemShow!=t&&(this.m_isSystemShow=t,this.noInpuTxt.node.SetActive(this.m_isSystemShow),this.noInputSp.SetActive(!1),
this.m_isSystemShow&&this.noInpuTxt.textSet((0,d.T)("该频道不能发言，请切换至其他频道")),this.haveInputWidget.SetActive(!this.m_isSystemShow))}OpenMail(){this.SetCurSelectIdx(2,!0,!0)}
OnAddToScene(){this.m_primaryRoleInfo=_.Y.Inst.PrimaryRoleInfo_get(),this.m_primaryRoleInfo0=_.Y.Inst.GetMultiPlayerInfoByCreateIdx(0),this.AddOrDelEvent(!0),
this.SetPressObjShow(!1),Z.f.Inst.SetState(j.t.MAIL,q.x.GetInst().UnreadNum_get()>0),this.UpdateMailRedPoint(j.t.MAIL,q.x.GetInst().UnreadNum_get()>0),this.UpdateMailCount(null)
Z.f.Inst.GetData(j.t.CHAT_ASURAM)
this.CheckChannelRedDot(),this.UpdateChannelTabActive(),this.curScrollPanelSize=this.scrollPanelSize
const t=this.m_privateModel.GetPrivateModes()
let e=null,i=0
const s=Q.d.Inst_get().controller
for(;i<t.Count();)i==this.m_model.m_curPriNameIndex&&this.m_model.curChannel==tt.L.PRIVATE||(e=t[i],e.hasNew&&this.privateRedTip.SetActive(!0)),i+=1
if(this.question.node.SetActive(!1),this.m_privateModel.isNeedOpenPrivateChat)this.ChangeToPrivateChat(this.m_privateModel.PrivateChatParm_senderName,this.m_privateModel.PrivateChatParm_senderID,this.m_privateModel.PrivateChatParm_receiverIsOnline,this.m_privateModel.PrivateChatParm_job,this.m_privateModel.PrivateChatParm_sex)
else{if(s.IsOpenMail)this.OpenMail()
else if(this.m_isFirst)this.m_isSystemShow=!1,this.SetCurSelectIdx(0,null,null)
else if(0==this.curSelectIdx||s.type==st.z.CHAT){0==this.curSelectIdx&&(this.bg1.SetActive(!0),this.mailbg.SetActive(!1)),this.checkAllianceQuestion(),
s.type==st.z.CHAT&&(this.SetCurSelectIdx(0,null,null),s.type=-1)
const t=ht.C.GetMainBtnIndex(s.m_channel)
s.m_channel=-1,this.SetCurChannelSelectIdx(t,!0,null),null!=s.openTxt&&(this.inputLabel.string=s.openTxt,s.openTxt=null)}else s.m_channel=-1
this.m_isFirst=!1}C.C.Inst_get().SetInterval(this._degf_CloseOtherPanel,50,1)}UpdateChannelTabActive(){
const t=this.m_primaryRoleInfo.isHaveAlliance_get(),e=X.a.Inst_get().canEnterCrossServer
this.crossServerChannelBtn.node.SetActive(e),this.stallonbtn.node.SetActive(K.v.Inst_get().IsFunctionOpen()),
this.channel0.node.SetActive(Q.d.Inst_get().model.IsChannelShow(tt.L.TOTAL)),this.channel1.node.SetActive(Q.d.Inst_get().model.IsChannelShow(tt.L.SYSTEM)),
this.channel2.node.SetActive(Q.d.Inst_get().model.IsChannelShow(tt.L.WORLD)),this.channel3.node.SetActive(t&&Q.d.Inst_get().model.IsChannelShow(tt.L.ALLIANCE))}SetPressObjShow(t){
this.pressObj.SetActive(t),this.unPressObj.SetActive(!t)}CloseOtherPanel(){H.F.Inst_get().control.ForceClose()}AddOrDelEvent(t){
t?(this.chatTable.OnReposition_set(this._degf_OnTableResponstion),this.m_handlerMgr.AddClickEvent(this.sendbtn,this.CreateDelegate(this.OnBtnClick)),
this.m_handlerMgr.AddClickEvent(this.facebtn,this.CreateDelegate(this.OnBtnClick)),this.m_handlerMgr.AddClickEvent(this.noTeamBtn,this.CreateDelegate(this.OnBtnClick)),
this.m_handlerMgr.AddClickEvent(this.noAllianceBtn,this.CreateDelegate(this.OnBtnClick)),this.m_handlerMgr.AddClickEvent(this.noSawPanel,this.CreateDelegate(this.OnBtnClick)),
this.m_handlerMgr.AddClickEvent(this.hornBtn,this.CreateDelegate(this.OnBtnClick)),this.m_handlerMgr.AddClickEvent(this.playVoiceBtn,this.CreateDelegate(this.OnBtnClick)),
this.m_handlerMgr.AddClickEvent(this.voiceIcon,this.CreateDelegate(this.OnBtnClick)),this.m_handlerMgr.AddClickEvent(this.keyIcon,this.CreateDelegate(this.OnBtnClick)),
this.m_handlerMgr.AddClickEvent(this.searchFriendBtn,this.CreateDelegate(this.OnBtnClick)),this.m_handlerMgr.AddClickEvent(this.FriendBtn,this.CreateDelegate(this.OnBtnClick)),
this.m_handlerMgr.AddPressEvent(this.voiceBtn,this.CreateDelegate(this.OnPressVoiceBtn)),
this.m_handlerMgr.AddPressEvent(this.voicePressnBtn,this.CreateDelegate(this.OnPressVoiceBtnNow)),
this.m_handlerMgr.AddPressEvent(this.stallbtn,this.CreateDelegate(this.OnClickStall)),this.inputLabel.node.on(l.EditBox.EventType.TEXT_CHANGED,this._degf_OnInputChanged,this),
this.m_model.AddEventHandler(et.F.UPDATE_CHAT,this._degf_OnChatUpdate),this.m_model.AddEventHandler(et.F.UPDATE_PRIVATE_NAME_BTN,this._degf_OnPrivateBtnUpdate),
I.i.Inst.AddEventHandler(b.g.MAIL_CNT_UPDATE,this._degf_UpdateMailCount),I.i.Inst.AddEventHandler(b.g.UPDATE_ANCHORS,this._degf_UpdateAnchors),
this.chatScrollview.RegistonDragBegan(this._degf_OnDragStarted),this.chatScrollview.RegistonDragFinished(this._degf_OnDragFinished),
this.m_model.AddEventHandler(et.F.SELECT_FACE,this._degf_OnSelectFace),this.m_model.AddEventHandler(et.F.SEND_ITEM_TO_CHAT,this._degf_OnShowItem),
this.m_model.AddEventHandler(et.F.SELECT_ONE_PRIVATE_PLAYER,this._degf_SetPrivateList),
this.m_model.AddEventHandler(et.F.UPDATE_PRIVATE_ONLINE_STATUS,this._degf_UpdatePrivateOnlineStaus),this.m_model.AddEventHandler(et.F.SHOW_HORN_MESSAGE,this._degf_OnHornShow),
_.Y.Inst.PrimaryRoleInfo_get().AddEventHandlerRoleGlobal(u.A.AsuramIdUpdate,this._degf_AsuramIdUpdate),
_.Y.Inst.PrimaryRoleInfo_get().AddEventHandlerRoleGlobal(u.A.TeamUpdate,this._degf_TeamUpdate),I.i.Inst.AddEventHandler("StopPlayVoice",this._degf_StopPlayVoice),
I.i.Inst.AddEventHandler("PlayVoiceSuccess",this._degf_PlayVoiceSuccess),$.U.Inst_get().AddEventHandler(b.g.RY_STALL_CHAT_CD_TIME,this.CreateDelegate(this.ClearStallCDTime)),
this.AddOnVoiceCallback(),this.m_handlerMgr.AddEventMgr(b.g.ACCESS_ICON_CLICK,this.CreateDelegate(this.OnAccessClick)),
this.m_handlerMgr.AddClickEvent(this.closeBtn,this._degf_CloseThisPanel),
this.m_handlerMgr.AddClickEvent(this.closeImg,this._degf_CloseThisPanel)):(this.m_handlerMgr.RemoveClickEvent(this.closeBtn,this._degf_CloseThisPanel),
this.m_handlerMgr.RemoveClickEvent(this.closeImg,this._degf_CloseThisPanel),this.m_handlerMgr.Clear(),
this.inputLabel.node.off(l.EditBox.EventType.TEXT_CHANGED,this._degf_OnInputChanged,this),this.m_model.RemoveEventHandler(et.F.UPDATE_CHAT,this._degf_OnChatUpdate),
this.m_model.RemoveEventHandler(et.F.UPDATE_PRIVATE_NAME_BTN,this._degf_OnPrivateBtnUpdate),I.i.Inst.RemoveEventHandler(b.g.MAIL_CNT_UPDATE,this._degf_UpdateMailCount),
I.i.Inst.RemoveEventHandler(b.g.UPDATE_ANCHORS,this._degf_UpdateAnchors),this.m_model.RemoveEventHandler(et.F.SELECT_FACE,this._degf_OnSelectFace),
this.m_model.RemoveEventHandler(et.F.SEND_ITEM_TO_CHAT,this._degf_OnShowItem),this.m_model.RemoveEventHandler(et.F.SELECT_ONE_PRIVATE_PLAYER,this._degf_SetPrivateList),
this.m_model.RemoveEventHandler(et.F.UPDATE_PRIVATE_ONLINE_STATUS,this._degf_UpdatePrivateOnlineStaus),
this.m_model.RemoveEventHandler(et.F.SHOW_HORN_MESSAGE,this._degf_OnHornShow),
_.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandlerRoleGlobal(u.A.AsuramIdUpdate,this._degf_AsuramIdUpdate),
_.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandlerRoleGlobal(u.A.TeamUpdate,this._degf_TeamUpdate),I.i.Inst.RemoveEventHandler("StopPlayVoice",this._degf_StopPlayVoice),
I.i.Inst.RemoveEventHandler("PlayVoiceSuccess",this._degf_PlayVoiceSuccess),$.U.Inst_get().RemoveEventHandler(b.g.RY_STALL_CHAT_CD_TIME,this.CreateDelegate(this.ClearStallCDTime)),
this.chatScrollview.RemoveonDragFinished(this._degf_OnDragFinished),this.chatScrollview.RemoveonDragBegan(this._degf_OnDragStarted),this.chatTable.Clear(),
this.RemoveOnVoiceCallback())}OnAccessClick(){Q.d.Inst_get().controller.CloseMainPanel()}UpdateAnchors(t){T.O.SetAnchorPos(this.anchor,!0,!1,0,!1)}CheckStallCDTime(){
const t=$.U.Inst_get().chatTime
this.m_model.curChannel==tt.L.STALL&&null!=t&&t>0?null==this.stallTimer&&(this.stallTimer=C.C.Inst_get().SetInterval(this.CreateDelegate(this.UpdateStallCDTime),1e3),
this.UpdateStallCDTime()):this.ClearStallCDTime()}ClearStallCDTime(){null!=this.stallTimer&&(C.C.Inst_get().ClearInterval(this.stallTimer),this.stallTimer=null,
this.sendbtnLabel.textSet("发送"))}UpdateStallCDTime(){const t=$.U.Inst_get().chatTime
if(this.m_model.curChannel==tt.L.STALL&&null!=t&&t>0){const e=t-p.D.serverTime_get()
e>0?this.sendbtnLabel.textSet(`发送（${M.l.GetTimeInHMS(e,!0)})`):this.ClearStallCDTime()}}PlayVoiceSuccess(t){this.m_model.waitToPlayVoiceMapId=0,this.m_model.currentPlayVoiceMapId=t
}StopPlayVoice(t){if(this.m_model.currentPlayVoiceMapId==t&&0==this.m_model.waitToPlayVoiceMapId&&this.m_model.autoPlayVoiceQueue.Count()>0){let e=-1,i=-1,s=0
for(;s<this.m_model.autoPlayVoiceQueue.Count();){const n=this.m_model.autoPlayVoiceQueue[s]
if(n==t)e=s
else if(-1==i&&n>t){if(this.m_model.autoPlayVoiceDict[n].isVoiceHeard)break
i=s}if(-1!=i)break
s+=1}if(-1!=e&&-1!=i){const t=this.m_model.autoPlayVoiceQueue[i]
this.m_model.autoPlayVoiceDict[t].isVoiceHeard=!0,g.X.Inst_get().PlayVoiceByUrl(t)}else this.m_model.currentPlayVoiceMapId=0,this.m_model.waitToPlayVoiceMapId=0}}
UpdateAsuramRedPoint(t,e){}UpdateMailRedPoint(t,e){null!=this.mailRedDot&&(this.mailRedDot.SetActive(e),this.mailCnt.textSet(D.M.IntToString(q.x.GetInst().UnreadNum_get())))}
UpdateTeamRedPoint(t,e){}OnInputChanged(){this.m_frontFaceStr=null}TeamUpdate(t){this.m_model.curChannel==tt.L.TEAM&&this.OnChangeTab()}AsuramIdUpdate(t){
this.m_model.curChannel==tt.L.ALLIANCE&&this.OnChangeTab()}OnHornShow(t){const e=t
this.horncontainer.SetData(e)}SetPrivateList(t){const e=t
this.SetPrivateInfoByModel(e,null)}CheckChannelRedDot(){if(null!=this.channelRedTip){let t=!1
this.asuramRedDot.SetActive(!1),t||this.asuramRedDot.active&&(t=!0),this.channelRedTip.SetActive(t)}}UpdateMailCount(t){
this.mailCnt.textSet(D.M.IntToString(q.x.GetInst().UnreadNum_get()))}OnSelectFace(t){this.m_tempFaceStr=this.inputLabel.string
const e=`#${t}`
this.AddLinkStrToInput(e),C.C.Inst_get().SetFrameLoop(this._degf_SetFaceStr,2,1)}SetFaceStr(){this.m_frontFaceStr=this.m_tempFaceStr}OnShowItem(t){
const e=t,i=e.serverData_get().id,s=`${it.B.ITEM}_${i.low_get()}_${i.high_get()}`,n=M.l.GetQuality(e.baseData_get())
let l=null,a=null
if(e.baseData_get().BagItemType_get()==L.r.Equip){const t=M.l.SetEquipName(e.baseData_get().equipInfo_get(),e.baseData_get().cfgData_get(),null)
a=t[0],l=t[2]}else l=M.l.getColorStrByQuality(n),a=e.baseData_get().cfgData_get().name
const o=M.l.SetStringColor(l,D.M.s_LEFT_M_K_CHAR+(a+D.M.s_RIGHT_M_K_CHAR))
let r=M.l.SetLinkStr(a,s,l,!0)
this.AddLinkStrToInput(o)&&(r+=" ",this.linkDic.LuaDic_AddOrSetItem(o,r),this.AddParam(it.B.ITEM,i))}AddParam(t,e){const i=new V.o
i.type=t,i.pId=e,this.m_paramList.Add(i)}OnChangeTab(){if(this.m_model.autoPlayVoiceQueue.Clear(),this.m_model.autoPlayVoiceDict.LuaDic_Clear(),
this.m_model.currentPlayVoiceMapId=0,this.m_model.waitToPlayVoiceMapId=0,this.noTeamBtn.node.SetActive(!1),this.noAllianceBtn.node.SetActive(!1),this.question.node.SetActive(!1),
this.hornBtn.node.SetActive(!1),this.FriendBtn.node.SetActive(!1),this.searchFriendBtn.node.SetActive(!1),this.SetNotOnLineObj(!1),
Q.d.Inst_get().controller.isChannelTab=0==this.curSelectIdx,this.UpdateVoicon(),this.m_model.curChannel==tt.L.STALL?(this.noInpuTxt.textSet("仅能发送商品广告"),
this.stallbtn.node.SetActive(!0),this.IsAdStallState=null!=$.U.Inst_get().chatItemId,this.CheckStallCDTime()):(this.ClearStallCDTime(),this.noInpuTxt.textSet("该频道不能发言，请切换至其他频道！"),
this.stallbtn.node.SetActive(!1),this.IsAdStallState&&(this.IsAdStallState=!1,$.U.Inst_get().ClearAdChat())),
!this.m_isSystemShow||this.IsAdStallState)if(this.noInpuTxt.node.SetActive(!1),this.haveInputWidget.SetActive(!0),
this.m_model.curChannel==tt.L.PRIVATE)this.channelTab.node.SetActive(!1),this.InitPrivateNameInfo(!1),this.hornBtn.node.SetActive(!1),this.FriendBtn.node.SetActive(!1),
this.searchFriendBtn.node.SetActive(!0)
else{let t=(0,d.T)("请输入聊天内容")
null!=this.openTxt&&(t=this.openTxt),this.m_model.curChannel!=tt.L.TEAM||this.m_primaryRoleInfo.isHaveTeam_get()||(this.noTeamBtn.node.SetActive(!0),
this.noInpuTxt.node.SetActive(!0),this.noInpuTxt.textSet((0,d.T)("加入队伍后才能发言！")),this.haveInputWidget.SetActive(!1),this.m_model.DelChatsByChannel(tt.L.TEAM),
Z.f.Inst.SetState(j.t.CHAT_TEAM,!1)),this.m_model.curChannel!=tt.L.ALLIANCE||this.m_primaryRoleInfo.isHaveAlliance_get()?this.m_model.curChannel==tt.L.HORN?t=(0,
d.T)(" 该频道一次消耗1个喇叭"):this.m_model.curChannel==tt.L.ALLIANCE&&this.checkAllianceQuestion():(this.noAllianceBtn.node.SetActive(!0),this.noInpuTxt.node.SetActive(!0),
this.noInpuTxt.textSet((0,d.T)("加入战盟后才能发言！")),this.haveInputWidget.SetActive(!1),this.m_model.DelChatsByChannel(tt.L.ALLIANCE),Z.f.Inst.SetState(j.t.CHAT_ASURAM,!1))}
this.hornBtn.node.SetActive(!1),0==this.curSelectIdx&&k.P.Inst_get().IsFunctionOpened(U.x.FRIEND)||this.FriendBtn.node.SetActive(!1),this.m_isDraging=!1,
this.chatScrollview.dragEffect=0,this.SetQuestionTimeSize()||this.CallUpdate(),this.openTxt=null}OnDragStarted(){this.m_isDraging=!0,
this._scrollToEndDelayTimeId=this.m_handlerMgr.ClearInterval(this._scrollToEndDelayTimeId)}OnDragFinished(){this.m_isDraging=!1,this.GetCurBarValue(null),
this.curBarValue>.98&&(this.horncontainer.SetNoSawShow(!1),this.m_model.ResetNoSawCount()),
this._scrollToEndDelayTimeId=this.m_handlerMgr.ClearInterval(this._scrollToEndDelayTimeId),
this._scrollToEndDelayTimeId=this.m_handlerMgr.SetInterval(this.CreateDelegate(this._ScrollToEndDelay),5e3,1)}_ScrollToEndDelay(){this.m_model.ResetNoSawCount(),
this.SetScrollValue(1),this.CallUpdate()}GetCurBarValue(t){return this.chatScrollview.vertical?(null==t&&(t=this.chatTable.node.transform.contentSize.y-this.curScrollPanelSize.w),
this.curBarValue=this.chatScrollview.node.transform.GetLocalPosition().y/t,this.curBarValue<0&&(this.curBarValue=0),this.curBarValue>1&&(this.curBarValue=1)):this.curBarValue=0,
this.curBarValue}OnChatUpdate(t){this.m_model.isMainTagChanged(this.m_model.curChannel)&&(0==this.SetQuestionTimeSize()&&this.CallUpdate(),
this.m_model.ResetMainTagsChanged(this.m_model.curChannel))}CallUpdate(){this.m_isTableResponstion&&this.UpateAction()}UpateAction(){if(null==this.chatTable)return
let t=null
if(this.m_model.curChannel==tt.L.MAIL||this.m_model.curChannel==tt.L.PRIVATE?this.channelTab.node.SetActive(!1):this.channelTab.node.SetActive(!0),
this.m_model.curChannel==tt.L.PRIVATE?this.privateBtns.SetActive(!0):this.privateBtns.SetActive(!1),this.m_model.curChannel==tt.L.PRIVATE){this.channelTab.node.SetActive(!1)
const e=this.m_privateModel.GetCurPrivateList()
null!=e&&(t=e.m_list,this.SetNotOnLineObj(!e.receiverIsOnline))}else t=this.m_model.GetShowList(this.m_model.curChannel),
this.m_model.curChannel==tt.L.TEAM?Z.f.Inst.SetState(j.t.CHAT_TEAM,!1):this.m_model.curChannel==tt.L.ALLIANCE&&Z.f.Inst.SetState(j.t.CHAT_ASURAM,!1)
null!=t&&t.Count()>0&&(this.m_isTableResponstion=!1),this.lastScrollBarVal=this.GetCurBarValue(null),this.chatTable.data_set(t),this.CalContentSize()}OnTableResponstion(){
this.horncontainer.SetNoSawShow(!1),this.m_isTableResponstion=!0
if(null!=this.chatTable.data_get()&&0!=this.chatTable.data_get().Count()&&this.IsOverClip())if(0==this.lastScrollBarVal&&this.boundPanelRatio>1||this.lastScrollBarVal>0&&this.lastScrollBarVal<.98){
const t=this.m_model.GetNoSawCount(this.m_model.curChannel)
t>0?(this.horncontainer.SetNoSawShow(!0),this.noSawTxt.textSet(ht.C.GetUnreadStr(t)),this.GetCurBarValue(null),this.chatScrollview.dragEffect=2):this.SetScrollValue(1)
}else this.m_model.ResetNoSawCount(),this.SetScrollValue(1)
else this.m_model.ResetNoSawCount(),this.SetScrollValue(0)
this.SetQuestionTimeSize()}SetScrollValue(t){}UpdateContentPos(){this.content&&this.content.transform.SetLocalPosition(new w.P(this.content.x,this.offsetY,0))}CallScrollValue(){
this.chatScrollview.dragEffect=2}IsOverClip(){return this.chatTable.node.transform.contentSize.y>this.curScrollPanelSize.w}InitPrivateNameInfo(t){
const e=this.m_privateModel.GetPrivateModes()
if(e.Count()>0){this.personNameGrid.data_set(e),this.personNameGrid.OnReposition_set(this._degf_OnNameGridReposition),this.m_model.m_curPriNameIndex=0
let i=e[0]
if(null!=this.m_privateSenderId)for(let t=0;t<=e.Count()-1;t++){const s=e[t]
if(s.m_objId.Equal(this.m_privateSenderId)){i=s
break}}i.hasNew=!1,k.P.Inst_get().IsFunctionOpened(U.x.FRIEND)&&N.N.Inst_get().ReqSearchFriendByID(i.m_objId,!0),this.SetPrivateInfoByModel(i,t)
}else this.m_privateModel.SetShowPrivateId(null)}SetPrivateInfoByModel(t,e){null==e&&(e=!0),
e&&this.m_model.curChannel==tt.L.PRIVATE&&(nt.v.Inst.LoadCache(this.m_primaryRoleInfo0.Id_get(),t.m_objId,null),this.chatTable.data_set(t.m_list),this.CalContentSize()),
this.m_privateSenderName=t.m_name,this.m_privateSenderId=t.m_objId,this.m_privateModel.SetShowPrivateId(this.m_privateSenderId),
this.m_privateModel.PrivateChatParm_senderID=t.m_objId,this.m_privateModel.PrivateChatParm_senderName=t.m_name,
this.m_privateModel.PrivateChatParm_receiverIsOnline=t.receiverIsOnline,this.m_privateModel.PrivateChatParm_job=t.job,this.SetNotOnLineObj(!t.receiverIsOnline),
this.m_model.m_curPriNameIndex=this.m_privateModel.GetPrivateNameIndex(this.m_privateSenderId),this.CheckPrivateRedTip()}CalContentSize(){
const t=this.chatTable.node.transform.height
this.content.transform.height=t,t>602&&(this.content.position=new w.P(0,t-602,0))}CheckPrivateRedTip(){const t=this.m_privateModel.GetPrivateModes()
let e=null,i=!1,s=0
for(;s<t.Count();)t[s].m_objId.Equal(this.m_privateSenderId)&&this.m_model.curChannel==tt.L.PRIVATE||(e=t[s],e.hasNew&&(i=!0)),s+=1
this.privateRedTip.SetActive(i)}UpdatePrivateOnlineStaus(t){const e=t
e.m_name==this.m_privateSenderName&&this.SetNotOnLineObj(!e.receiverIsOnline)}AddLinkStrToInput(t){const e=this.inputLabel.string+t
return!(e.length>lt.k.INPUT_MAX)&&(this.inputLabel.string=e,!0)}SetChatContentState(t){this.upContent.SetActive(t),
t?this.m_channelSelcetIndex>=0&&this.m_channelSelcetIndex<this.btnList.Count()&&this.btnList[this.m_channelSelcetIndex].SetIsEnabled(!1):this.m_channelSelcetIndex>=0&&this.m_channelSelcetIndex<this.btnList.Count()&&this.btnList[this.m_channelSelcetIndex].SetIsEnabled(!0)
}OnBtnClick(t,e){if(this.facebtn.node.name!=t.currentTarget.name&&this.ResetFacePanelStataus(),this.sendbtn.node.name==t.currentTarget.name){const t=this.inputLabel.string
if((0,d.T)("发送日志"),M.l.IsEmptyStr(t))return void J.y.inst.ClientStrMsg(x.r.SystemTipMessage,(0,d.T)("请输入发送内容"))
if(!this.m_model.channelModel.IsCanSend(this.m_model.curChannel,t,null,null))return
const e=this.m_controller.DealLinkStr(this.linkDic,this.m_tempKeyDic,t)
if(this.m_model.curChannel==tt.L.PRIVATE){if(null==this.m_privateSenderName)return void J.y.inst.ClientStrMsg(x.r.SystemTipMessage,(0,d.T)("当前没有私聊玩家"))
this.m_mgr.RequestCM_PrivateChat(this.m_privateSenderId,t,e,this.m_paramList)
}else this.m_model.curChannel==tt.L.STALL?this.m_mgr.SendStallItemChat(t):this.m_model.curChannel==tt.L.HORN?ht.C.SendToHorn(this.m_model.curChannel,t,e,this.m_paramList):this.m_mgr.RequestCM_PublicChat(this.m_model.curChannel,t,e,this.m_paramList,null)
this.ClearInput()
}else this.facebtn.node.name==t.currentTarget.name?this.facepanel.HandleClick(null):this.noAllianceBtn.node.name==t.currentTarget.name?rt.K.Inst().Open():this.closeBtn.node.name==t.currentTarget.name?this.CloseTween():this.noSawPanel.node.name==t.currentTarget.name?this._ScrollToEndDelay():this.hornBtn.node.name==t.currentTarget.name||this.playVoiceBtn.node.name==t.currentTarget.name||(this.voiceIcon.node.name==t.currentTarget.name?(this.inputview.SetActive(!1),
this.keyIcon.node.SetActive(!0)):this.keyIcon.node.name==t.currentTarget.name?(this.inputview.SetActive(!0),
this.keyIcon.node.SetActive(!1)):this.searchFriendBtn.node.name==t.currentTarget.name?this.m_controller.OpenSearchPanel():this.FriendBtn.node.name==t.currentTarget.name&&(N.N.Inst_get().OpenFriendPanel(),
this.CloseTween()))}OnFaceDel(){const t=this.inputLabel.string
if(null==t||""==t)return
let e=D.M.IndexOf(t,"#f",0)
for(;e>=0;){const i=D.M.IndexOf(t,"#f",e+1)
if(i<0)break
e=i}if(e<0)return
const i=D.M.SubStringWithEnd(t,0,e)
this.inputLabel.string=i}ClearInput(){this.m_frontFaceStr=null,this.linkDic.LuaDic_Clear(),this.m_paramList.Clear(),this.inputLabel.string=""}ClosePrivateItem(t){
if(null!=this.m_privateSenderId&&this.m_privateSenderId.Equal(t))this.m_privateModel.DelPrivatePlayer(this.m_privateSenderId),this.m_privateSenderId=null,
this.m_privateSenderName=null,this.m_model.m_curPriNameIndex=-1,this.OnChangeTab()
else{this.m_model.m_curPriNameIndex=this.m_model.m_curPriNameIndex-1,this.m_privateModel.DelPrivatePlayer(t),this.OnChangeTab()
const e=this.m_privateModel.GetPrivateModes()
this.personNameGrid.data_set(e)}}CloseTween(){}ShowTween(){this.m_isMove||(this.m_isMove=!0,this.m_isBack=!1,
this.m_moveTween.SetLuaParam(this.mainPanel,this.m_moveValue[1],this.m_moveValue[0],this._degf_FinishHandler,!1),this.m_moveTween.StartTween())}GetMoveValue(){return null}
FinishHandler(){this.m_isMove=!1,this.m_isBack||(this.m_isFirstMoveOut||this.UpateAction(),this.m_isFirstMoveOut=!1,this.OnPrivateCallLater(),this.isPrivateCalled=!0)}
closeThisPanel(){this.m_controller.CloseMainPanel()}OnFullclick(t,e){this.CloseTween()}ChangeToPrivateChat(t,e,i,s,n){this.m_privateSenderName=t,this.m_privateJob=s,
this.m_privateSenderId=e,this.m_privateModel.SetShowPrivateId(this.m_privateSenderId),this.m_privateModel.PrivateChatParm_job=s,this.m_privateModel.PrivateChatParm_sex=n,
this.SetNotOnLineObj(!i),this.m_model.m_curPriNameIndex=this.m_privateModel.GetPrivateNameIndex(this.m_privateSenderId),this.m_isSystemShow=!0,
null!=e&&this.m_privateModel.AddVirtualPrivateModel(e,t,i,s,n),this.SetCurSelectIdx(1,null,null)}OnPrivateBtnUpdate(t){let e=null
if(this.m_privateModel.hasNewPrivateModel){const e=this.m_privateModel.GetPrivateModes()
return null!=this.m_privateSenderId&&(this.m_model.m_curPriNameIndex=this.m_privateModel.GetPrivateNameIndex(this.m_privateSenderId)),this.personNameGrid.data_set(e),
void this.SetPrivateInfoByModel(t,null)}if(e=t,this.m_model.curChannel==tt.L.PRIVATE&&null!=this.m_privateSenderId){
if(this.m_privateSenderId.Equal(e.m_objId))return void(e.hasNew=!1)
const t=this.personNameGrid.itemList
for(const[i,s]of(0,h.V5)(t))if(s.UpdateNewInfo(e.m_objId))break}this.CheckPrivateRedTip()}ShowHistory(t){null!=t&&(this.inputLabel.string=t.showStr,
this.linkDic.LuaDic_AddOrSetItem(t.showStr,t.content),this.m_paramList.Clear(),t.CopyToParam(this.m_paramList))}ShowFromTip(t){this.inputLabel.string=t}OnClickStall(t){
this.CloseTween()}OnPressVoiceBtnNow(t,e){
this.m_model.curChannel!=tt.L.PRIVATE||null!=this.m_privateSenderId?(e?this.m_controller.OpenVoicePanel(this.m_model.curChannel,this.voicePressnBtn.node.transform,null,null,null):this.m_controller.CloseVoicePanel(),
this.SetPressObjShow(e)):e&&J.y.inst.ClientStrMsg(x.r.SystemTipMessage,(0,d.T)("当前没有私聊玩家"))}OnPressVoiceBtn(t,e){if(e){let t=0
this.m_model.curChannel==tt.L.PRIVATE?0==this.m_privateModel.PrivateChatParm_senderID.Equal(y.o.ZERO)&&(t=g.X.Inst_get().StartRecord(this.voiceCallbackId,this.m_model.curChannel,0,this.m_privateModel.PrivateChatParm_senderID)):t=g.X.Inst_get().StartRecord(this.voiceCallbackId,this.m_model.curChannel,0,null)
}else g.X.Inst_get().StopRecord(!0)}SetNotOnLineObj(t){C.C.Inst_get().ClearInterval(this.showNotOnlineIntervalId),t?(this.privateNotOnlinePanel.SetActive(!0),
C.C.Inst_get().SetInterval(this._degf_ResetNotOnLineObj,3e3,1)):this.privateNotOnlinePanel.SetActive(!1)}ResetNotOnLineObj(){
null!=this.privateNotOnlinePanel&&this.privateNotOnlinePanel.SetActive(!1)}AddOnVoiceCallback(){}RemoveOnVoiceCallback(){this.voiceCallbackId}OnSendVoice(){S.Y.Log("send")}
DoHide(){this.m_closeType=this.curSelectIdx,this.m_model.autoPlayVoiceQueue.Clear(),this.m_model.autoPlayVoiceDict.LuaDic_Clear(),this.m_model.currentPlayVoiceMapId=0,
this.m_model.waitToPlayVoiceMapId=0}DoReShow(){const t=new E.Z([f.F.Tip,f.F.Msg])
Y.T.inst.PhotoHideLayerState_set(W.N.ChatPanleType,!1,t)}Clear(){this.m_model.curChannel==tt.L.ALLIANCE&&this.m_mgr.RequestCM_ReadAsuramMsg(),this.ClearStallCDTime(),
$.U.Inst_get().ClearAdChat(),this.m_closeType=this.curSelectIdx,this.AddOrDelEvent(!1),this.ResetFacePanelStataus(),this.m_privateSenderName=null,this.m_privateSenderId=null,
Q.d.Inst_get().controller.CheckShowPanelRedDot(),C.C.Inst_get().ClearInterval(this.showNotOnlineIntervalId),this.SetCurSelectIdx(0,null,null),
null!=this.question&&this.question.node.SetActive(!1),this.curScrollPanelSize=this.scrollPanelSize
const t=w.P.zero_get()
this.chatOffset.SetLocalPosition(t),w.P.Recyle(t),this.m_isQuest=!1,C.C.Inst_get().ClearInterval(this.m_callId),this.m_model.autoPlayVoiceQueue.Clear(),
this.m_model.autoPlayVoiceDict.LuaDic_Clear(),this.m_model.currentPlayVoiceMapId=0,this.m_model.waitToPlayVoiceMapId=0,this.isPrivateCalled=!1}ResetFacePanelStataus(){
this.facepanel.HandleClick(!1)}Destroy(){this.channelTab.destroy(),this.typeTab.destroy(),this.chatTable.destroy(),this.personNameGrid.destroy(),this.horncontainer.destroy(),
Q.d.Inst_get().controller._degf_CallMainDestory()}SetPrivateObj(t){this.isPrivate=t,this.isPrivateCalled&&C.C.Inst_get().CallLater(this._degf_OnPrivateCallLater)}UpdateVoicon(){
this.m_model.curChannel==tt.L.STALL?(this.voiceIconSprite.enabled=!1,this.voiceIcon.enabled=!1):this.voiceIcon.enabled=!0}OnPrivateCallLater(){this.voiceIcon.enabled=!0,
this.m_model.curChannel==tt.L.STALL?(this.voiceIconSprite.enabled=!1,this.voiceIcon.enabled=!1,G.I.calVec0.Set(7,0,0)):(this.voiceIconSprite.enabled=!0,this.voiceIcon.enabled=!0,
G.I.calVec0.Set(47,0,0))}}).SUITID="suitId",s=n))},79335:(t,e,i)=>{var s,n=i(18998),l=i(83908),a=i(86133),o=i(68662),r=i(98130),h=i(37322),d=i(26753),c=i(14143)
n._decorator.ccclass("ChatMicroItem")(s=class extends((0,l.yk)()){constructor(...t){super(...t),this.m_pressCom=null,this.channel=0,this._degf_OnClick=null,
this._degf_OnPressed=null,this.index=void 0}_initBinder(){super._initBinder(),this._degf_OnClick=()=>this.OnClick(),this._degf_OnPressed=(t,e)=>this.OnPressed(t,e)}InitView(){
this.m_pressCom=new h.c(this.btn.node,this._degf_OnClick,this._degf_OnPressed),this.m_pressCom.needcheckMove=!1,this.m_pressCom.delayTime=400,this.bLine.SetActive(!1),
o.D.UpdateLabelAtOtherPackage(this.label,"mainText")}SetData(t){this.channel=r.GF.INT(t)
let e=(0,a.T)("世界")
this.channel==c.L.ALLIANCE?e=(0,a.T)("战盟"):this.channel==c.L.TEAM&&(e=(0,a.T)("队伍")),this.label.textSet(e)
let i=!0
d.d.Inst_get().controller.showPanel_get()&&this.index==d.d.Inst_get().controller.showPanel_get().microLen-1&&(i=!1),this.m_pressCom.AddEvent()}OnClick(){}OnPressed(t,e){
if(this.pressBg.SetActive(e),e){if(!d.d.Inst_get().model.channelModel.IsCanSend(this.channel,null,null,null))return void d.d.Inst_get().controller.CloseVoicePanel()
d.d.Inst_get().controller.OpenVoicePanel(this.channel,this.node.transform,!0,this.index,null)}else d.d.Inst_get().controller.CloseVoicePanel()}Clear(){this.m_pressCom.RemoveEvent()
}Destroy(){this.m_pressCom.Destory(),this.m_pressCom=null}})},49413:(t,e,i)=>{
var s=i(18998),n=i(83908),l=i(97461),a=i(68662),o=i(5924),r=i(57834),h=i(98130),d=i(98885),c=i(79534),_=i(8125),u=i(33314),I=i(87923),m=i(38501),g=i(37322),p=i(44744),C=i(79878),S=i(26753),f=i(98407),T=i(14143),y=i(13612)
class A{}A.State1=1,A.State2=2,A.State3=3,A.State4=4
var D,E=i(19381),v=i(28192)
s._decorator.ccclass("ChatPersonCell")(D=class extends((0,n.yk)()){constructor(...t){super(...t),this.m_info=null,this.luaHead=null,this.m_pressComp=null,this.m_useTween=null,
this.m_curIcon=null,this.m_isOtherShow=!1,this.m_nameLabel=null,this.m_vipSp=null,this.m_faceLabel=null,this.m_tween=!1,this.m_contextlabel=null,this.m_sprite=null,
this.m_channelLabel=null,this.isCrossChat=!1,this._degf_FrameHandler=null,this._degf_LongPressHandler=null,this._degf_MoveEndHandler=null,this._degf_OnBgClick=null,
this._degf_OnHeadClick=null,this._degf_OnRedPacketClick=null,this._degf_OnTxtClick=null,this._degf_PlayVoiceSuccess=null,this._degf_StopPlayVoice=null,this.specialWMax=null,
this.maxW1=null,this.maxW2=null,this.maxW3=null,this.sepecialWMin=null,this.isChannelTab=null,this.bubbleId=null,this.tag=null,this.channelSp=null,this.callTimer1=void 0,
this._m_handlerMgr=null}_initBinder(){super._initBinder(),this._degf_FrameHandler=()=>this.FrameHandler(),this._degf_LongPressHandler=(t,e)=>this.LongPressHandler(t,e),
this._degf_MoveEndHandler=()=>this.MoveEndHandler(),this._degf_OnBgClick=(t,e)=>this.OnBgClick(t,e),this._degf_OnHeadClick=(t,e)=>this.OnHeadClick(t,e),
this._degf_OnRedPacketClick=(t,e)=>this.OnRedPacketClick(t,e),this._degf_OnTxtClick=()=>this.OnTxtClick(),this._degf_PlayVoiceSuccess=t=>this.PlayVoiceSuccess(t),
this._degf_StopPlayVoice=t=>this.StopPlayVoice(t)}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=v.h.Get()),this._m_handlerMgr}InitView(){
this.timeLine.node.SetActive(!1),this.otherVipSp.node.SetActive(!1),this.selfVipSp.node.SetActive(!1),this.leftredpacket.node.SetActive(!1),this.specialWMax=336,this.maxW1=326,
this.maxW2=322,this.maxW3=300,this.isCrossChat&&(this.maxW1=700,this.maxW2=696,this.maxW3=678,this.specialWMax=720),this.sepecialWMin=108,this.isChannelTab=!1}SetData(t){
this.m_info=t,this.m_isOtherShow=!1
let e="atlas_head_ms000"
const i=this.otherLabelbg.node.transform.GetLocalPosition()
let s=this.m_info.smChat.sender.nowHeadFrameId
this.bubbleId=this.m_info.smChat.sender.nowBubbleId,0==s&&(s=1),0==this.bubbleId&&(this.bubbleId=2),-1==this.m_info.smChat.sender.job?(this.m_isOtherShow=!0,
i.y=-2):this.m_info.isSelfChat_get()||(this.m_isOtherShow=!0,i.y=-29,e=u.Z.GetJobIcon(this.m_info.smChat.sender.job,this.m_info.smChat.sender.sex,!1)),
this.m_isOtherShow?(this.otherLabelbg.node.transform.SetLocalPosition(i),this.otherWidget.SetActive(!0),this.selfWidget.SetActive(!1),
this.m_info.smChat.sender.gmLevel>0?this.otherNameLabel.textSet(`[962424][GM][-]${this.m_info.smChat.sender.name}`):this.otherNameLabel.textSet(this.m_info.smChat.sender.name),
this.m_nameLabel=this.otherNameLabel,this.m_nameLabel.widthSet(134),this.otherHeadSp.skin=e,this.m_contextlabel=this.ohterChatLabel,this.m_contextlabel.widthSet(this.maxW3),
this.m_sprite=this.otherLabelbg,this.luaHead=this.otherHeadSp.node,this.m_handlerMgr.AddClickEvent(this.luaHead,this._degf_OnHeadClick),this.m_curIcon=this.otherVoiceIcon,
this.m_vipSp=this.otherVipSp,this.SetVoiceTxt(this.otherChatFaceLabel,!1),this.m_channelLabel=this.otherChannelLabel,
this.channelSp=this.otherChanneSp):(this.otherWidget.SetActive(!1),this.selfWidget.SetActive(!0),
this.m_info.smChat.sender.gmLevel>0?this.selfNameLabel.textSet(`[962424][GM][-]${this.m_info.smChat.sender.name}`):this.selfNameLabel.textSet(this.m_info.smChat.sender.name),
this.m_nameLabel=this.selfNameLabel,this.m_nameLabel.widthSet(134),this.m_contextlabel=this.selfChatLabel,
this.selfHeadSp.skin=u.Z.GetJobIcon(this.m_info.smChat.sender.job,this.m_info.smChat.sender.sex,!1),this.m_contextlabel.widthSet(this.maxW3),this.m_sprite=this.selfLabelbg,
this.m_curIcon=this.selfVoiceIcon,this.m_vipSp=this.selfVipSp,this.SetVoiceTxt(this.selfChatFaceLabel,!0),this.m_channelLabel=this.selfChannelLabel,
this.channelSp=this.selfChanneSp),this.SetBubble(),c.P.Recyle(i),r.i.Get(this.leftredpacket.node).RegistonClick(this._degf_OnRedPacketClick),
l.i.Inst.AddEventHandler("PlayVoiceSuccess",this._degf_PlayVoiceSuccess),l.i.Inst.AddEventHandler("StopPlayVoice",this._degf_StopPlayVoice),
this.m_info.isVoice_get()?this.m_handlerMgr.AddClickEvent(this.m_sprite,this._degf_OnBgClick):(this.m_pressComp=new g.c(this.m_contextlabel.node,this.CreateDelegate(this.OnTxtClick),this.CreateDelegate(this.LongPressHandler)),
this.m_pressComp.delayTime=S.d.Inst_get().model.CopyDelayTime,this.m_pressComp.AddEvent()),this.m_tween=!1,this.CalcSize(),this.ShowVIPSimbol(),this.ShowRedPacketSimbol()}
ShowRedPacketSimbol(){if(this.leftredpacket.node.SetActive(!1),null!=this.m_info.extradata&&1==this.m_info.extradata.type){
const t=this.m_sprite.node.transform.GetLocalPosition(),e=c.P.zero_get()
this.m_info.isSelfChat_get()?this.selfChatFaceLabel.lineCount()>1?e.Set(t.x-this.m_sprite.width()-25,t.y-30,0):e.Set(t.x-this.m_sprite.width()-25,t.y-30+7,0):(this.selfChatFaceLabel.lineCount()>1?e.Set(t.x+this.m_sprite.width()+25,t.y-30,0):e.Set(t.x+this.m_sprite.width()+25,t.y-30+7,0),
this.leftredpacket.node.SetActive(!0),this.leftredpacket.node.transform.SetLocalPosition(e)),c.P.Recyle(e),
this.m_info.extradata.state==A.State1?this.leftredpacket.spriteNameSet("f3201"):this.leftredpacket.spriteNameSet("f3301")}}ShowVIPSimbol(){let t=this.m_info.smChat.sender.vipLevel
const e=this.m_nameLabel.node.transform.GetLocalPosition(),i=this.m_vipSp.node.transform.GetLocalPosition()
let s=!1,n=0,l=!1
this.isChannelTab&&(this.m_isOtherShow&&this.m_info.channelId!=T.L.CROSS_SERVER?(n=70,l=!0):l=!1),t=this.m_info.smChat.sender.vipLevel
const a=m.f.Inst().getItemById(t)
this.m_info.channelId==T.L.CROSS_SERVER||I.l.IsEmptyStr(a.vipShow)?(s=!1,this.m_vipSp.node.SetActive(!1)):(s=!0,this.m_vipSp.node.SetActive(!0),
this.m_vipSp.skin="atlas/mainui/"+a.vipShow),this.m_channelLabel.textSet(this.m_info.GetChannelName()),this.channelSp.node.SetActive(l),this.m_isOtherShow?(e.x=66+n,s&&(e.x=87+n,
i.x=70+n)):(e.x=-66-n,s&&(e.x=-87-n,i.x=-70-n)),this.m_vipSp.node.transform.SetLocalPosition(i),this.m_nameLabel.node.transform.SetLocalPosition(e),c.P.Recyle(e)}isShowVip(t){
return t>0&&this.m_info.smChat.sender.showVip}SetVoiceTxt(t,e){if(this.m_info.isVoice_get()){const e=this.m_info.smChat.voiceContent
this.m_faceLabel=t,this.SetConent(this.m_faceLabel,e)}else{let i=this.m_info.speakTxt_get()
i=d.M.TransRichTextHref(i),t.textSet(i),e?(this.selfCollider.widthSet=t.width,this.selfCollider.heightSet=t.height,
this.selfCollider.node.position=new c.P(t.width()/2,-t.height()/2,0)):(this.otherCollider.widthSet=t.width,this.otherCollider.heightSet=t.height,
this.otherCollider.node.position=new c.P(t.width()/2,-t.height()/2))}}SetConent(t,e){
this.m_info.isVoice_get()?t.textSet(e):this.m_isOtherShow?t.textSet(`  ${e}`):t.textSet(`${e}  `),this.CalcSize()}OnBgClick(t,e){this.m_curIcon.PlayVoice()}FrameHandler(){
this.m_tween||(this.m_tween=!0)}MoveEndHandler(){this.m_tween=!1}LongPressHandler(t,e){let i=null
_.T.touchLocation,i=_.T.GetRelateMousePoint(S.d.Inst_get().controller.ChatMainPanel_get().mainpanelgo),i.x+=60,i.y+=20,this.m_sprite.color=new s.math.Color(226,166,106)
let n=d.M.ReplaceSlow(this.m_info.smChat.content,y.k.USE_POS,"")
n=d.M.Replace(n,E.$.USE_VOC,""),S.d.Inst_get().controller.OpenCopyTip(i,n),c.P.Recyle(i)}OnTxtClick(){f.C.OnTxtClick(this.m_contextlabel,this.m_info,this.tag),
this.m_sprite.color=new s.math.Color(255,255,255),this.m_tween=!1}CalcSize(){if(!this.timeLine)return
this.timeLine.node.SetActive(this.m_info.isShowTimeSpan)
let t=0
this.m_info.isShowTimeSpan&&(this.lab_timeLine.textSet(I.l.GetChineseDateTimeEx(a.D.serverMSTime_get(),null,null,null)),t=this.timeLine.height)
let e=this.otherWidget.transform.GetLocalPosition()
e.y=-t,this.otherWidget.transform.SetLocalPosition(e),c.P.Recyle(e),e=this.selfWidget.transform.GetLocalPosition(),e.y=-t,this.selfWidget.transform.SetLocalPosition(e),
c.P.Recyle(e),e=this.m_contextlabel.node.transform.GetLocalPosition()
let i=0
e.y=-9,this.m_info.isVoice_get()&&(e.y=-45,i=33),this.m_curIcon.node.SetActive(this.m_info.isVoice_get())
let s=this.m_contextlabel.textWidth
0==s&&(null!=this.callTimer1?(o.C.Inst_get().Remove(this.callTimer1),this.callTimer1=null):this.callTimer1=o.C.Inst_get().CallLater(this.CreateDelegate(this.CalcSize)))
const n=h.GF.INT(this.m_contextlabel.height())
if(this.m_info.isVoice_get()){s=this.m_curIcon.SetData(this.m_info,this.m_isOtherShow)}s>this.maxW1&&(s=this.maxW1)
const l=this.m_sprite.node.transform.GetLocalPosition()
s+=28,this.m_sprite.widthSet(s),this.m_curIcon.SetRedPointPos(s)
let r=0
if(r=this.m_info.isVoice_get()?39:n+14+i,this.m_sprite.heightSet(r),this.dragWidget.height=r+16+t,this.m_info.isSelfChat_get()){new c.P(-this.maxW2,-9)
if(this.selfChatFaceLabel.lineCount()>1)this.m_sprite.widthSet(this.maxW1),e.x=this.maxW2
else{const t=this.m_contextlabel.textWidth
e.x=Math.abs(this.maxW3-t-this.maxW2)}}else e.x=23
this.m_contextlabel.node.transform.SetLocalPosition(e),c.P.Recyle(e),l.y=-29,this.m_sprite.node.transform.SetLocalPosition(l),this.node.transform.height=this.m_sprite.height()+50}
OnHeadClick(t,e){this.m_info.channelId,T.L.CROSS_SERVER,p.Z.Inst().Open(this.m_info.smChat.sender.objId,null,null,null)}OnRedPacketClick(t,e){}PlayVoiceSuccess(t){
this.m_info.isVoice_get()&&this.m_info.smChat.voiceUrl==t&&null!=this.m_curIcon&&this.m_curIcon.SetPlayState(!0)}StopPlayVoice(t){
this.m_info.isVoice_get()&&this.m_info.smChat.voiceUrl==t&&null!=this.m_curIcon&&this.m_curIcon.SetPlayState(!1)}Clear(){this.m_faceLabel=null,
null!=this.luaHead&&this.m_handlerMgr.RemoveClickEvent(this.luaHead,this._degf_OnHeadClick),
this.m_info&&this.m_info.isVoice_get()&&C.Y.DelLuaClick(this.m_sprite.node,this._degf_OnBgClick),null!=this.m_pressComp&&(this.m_pressComp.Clear(),this.m_pressComp.Destory(),
this.m_pressComp=null),this.otherVoiceIcon.Clear(),this.selfVoiceIcon.Clear(),r.i.Get(this.leftredpacket.node).RemoveonClick(this._degf_OnRedPacketClick),
l.i.Inst.RemoveEventHandler("PlayVoiceSuccess",this._degf_PlayVoiceSuccess),l.i.Inst.RemoveEventHandler("StopPlayVoice",this._degf_StopPlayVoice)}Destroy(){
this.otherChatFaceLabel.destroy(),this.selfChatFaceLabel.destroy(),this.m_info=null,this.luaHead=null,this.m_curIcon=null,this.m_useTween=null,this.m_nameLabel=null,
this.m_vipSp=null}IsSpecialBubble(){return 2!=this.bubbleId}SetBubble(){const t=c.P.zero_get()
this.IsSpecialBubble()&&(t.y=-17,this.m_contextlabel.widthSet(this.specialWMax-36-28)),this.m_curIcon.node.transform.SetLocalPosition(t)}})},38314:(t,e,i)=>{i.d(e,{r:()=>u})
var s,n,l=i(18998),a=i(83908),o=i(28192),r=i(33314),h=i(21987),d=i(79878),c=i(26753),_=i(16459)
let u=l._decorator.ccclass("ChatPersonNameCell")((n=class t extends((0,a.yk)()){constructor(...t){super(...t),this.m_info=null,this._degf_OnBtnClick=null,
this._degf_OnCloseBtn=null,this._m_handlerMgr=null}_initBinder(){super._initBinder(),this._degf_OnBtnClick=(t,e)=>this.OnBtnClick(t,e),
this._degf_OnCloseBtn=(t,e)=>this.OnCloseBtn(t,e)}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=o.h.Get()),this._m_handlerMgr}InitView(){}SetData(t){
this.m_info=t,this.tipbg.SetActive(this.m_info.hasNew),this.label.textSet(this.m_info.m_name)
const e=r.Z.GetJobIcon(this.m_info.job,this.m_info.sex,!1)
this.headIcon.spriteNameSet(e),this.m_handlerMgr.AddClickEvent(this.btn,this.CreateDelegate(this.OnBtnClick)),d.Y.RegLuaClick(this.closebtn.node,this._degf_OnCloseBtn)}
SetEnabled(){null!=t.selectedCell&&t.selectedCell.btn.SetIsEnabled(!0),t.selectedCell=this,t.selectedCell.btn.SetIsEnabled(!1),this.m_info.hasNew=!1,
this.tipbg.SetActive(this.m_info.hasNew)}UpdateNewInfo(t){return!!this.m_info.m_objId.Equal(t)&&(this.tipbg.SetActive(this.m_info.hasNew),!0)}OnBtnClick(t,e){
c.d.Inst_get().model.RaiseEvent(_.F.SELECT_ONE_PRIVATE_PLAYER,this.m_info),this.m_info.hasNew=!1,this.tipbg.SetActive(this.m_info.hasNew),this.SetEnabled(),
c.d.Inst_get().controller.RefreshPrivateBtnSelectStatus(),h.N.Inst_get().ReqSearchFriendByID(this.m_info.m_objId,!0)}OnCloseBtn(t,e){
c.d.Inst_get().controller.ChatMainPanel_get().ClosePrivateItem(this.m_info.m_objId),c.d.Inst_get().mgr.SendCloseChat(this.m_info.m_objId)}Clear(){
d.Y.DelLuaClick(this.closebtn.node,this._degf_OnCloseBtn)}Destroy(){t.selectedCell=null,this.m_info=null}SetBgStatus(t){
this.bg.skin=t?"atlas/liaotian/ryliaotian_bt_0003":"atlas/liaotian/ryliaotian_bt_0004"}},n.selectedCell=null,s=n))||s},18449:(t,e,i)=>{
var s,n=i(6847),l=i(83908),a=i(17409),o=i(49655),r=i(46282),h=i(86133),d=i(98800),c=i(66788),_=i(98130),u=i(85602),I=i(82803),m=i(87923),g=i(21987),p=i(50077),C=i(24315),S=i(22662),f=i(65550),T=i(33314),y=i(41864),A=i(28192)
class D extends((0,l.yk)()){constructor(...t){super(...t),this._vo=null,this._m_handlerMgr=null}InitView(){super.InitView()}OnBoxClick(){g.N.Inst_get().OpenOperationPanel(this._vo)
}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=A.h.Get()),this._m_handlerMgr}SetData(t){
if(this.m_handlerMgr.AddClickEvent(this.ui_rychat_searchplayeritem,this.CreateDelegate(this.OnBoxClick)),this._vo=t,null==this._vo)return
this.rolename.textSet(this._vo.m_vo.name)
const e=T.Z.GetJobIcon(this._vo.m_vo.job,this._vo.m_vo.sex,!1)
this.spr_headIcon.spriteNameSet(e),this.level.textSet(y.h.GetLevelStr(this._vo.m_vo.level))}Clear(){}Destroy(){super.destroy()}Test1(){return!0}S_Test(){return!0}}(0,
n.s_)(o.o.RySearchPlayerPanel,r.Z.ui_rychat_searchplayerpanel).waitPrefab(r.Z.ui_rychat_searchplayeritem).register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),
this.lastSearchTime=null,this.dataList=null,this.searchType=null}InitView(){super.InitView(),this.grid.SetInitInfo("ui_rychat_searchplayeritem",null,D)}OnAddToScene(){
this.AddLis(),this.ResetStatus()}ResetStatus(){this.lab_listNone.node.SetActive(!1)}AddLis(){
this.m_handlerMgr.AddClickEvent(this.closebtn,this.CreateDelegate(this.CloseBtnHandler)),this.m_handlerMgr.AddClickEvent(this.btn_search,this.CreateDelegate(this.OnSeachClick)),
p.C.Inst_get().AddEventHandler(p.C.eFriendSearchList,this.CreateDelegate(this.OnSearchListHandler))}RemoveLis(){
p.C.Inst_get().RemoveEventHandler(p.C.eFriendSearchList,this.CreateDelegate(this.OnSearchListHandler))}CloseBtnHandler(){(0,a.sR)(o.o.RySearchPlayerPanel)}OnSeachClick(t,e){
const i=this.ipt_roleName.string
m.l.IsEmptyStr(i)?f.y.inst.ClientStrMsg(S.r.SystemTipMessage,(0,h.T)("请输入要搜索的玩家名称")):(this.scrollview.ResetPosition(),g.N.Inst_get().ResetSearchFriend(),
g.N.Inst_get().SearchFriend(i))}UpdateRankData(){_.GF.Timer_get()<this.lastSearchTime?c.Y.Log((0,h.T)("太频繁")):(g.N.Inst_get().SearchFriendNexPage(),
this.lastSearchTime=_.GF.Timer_get()+1)}OnSearchListHandler(t){const e=t,i=this.grid
this.dataList=new u.Z
let s=0
for(;s<e.Count();)e[s].playerId.Equal(d.Y.Inst.PrimaryRoleInfo_get().Id_get())||this.dataList.Add(new C.O(0==this.searchType&&I.u.SearchList||I.u.SearchChatList,e[s])),s+=1
i.data_set(this.dataList),this.lab_listNone.node.SetActive(0==this.dataList.Count())}Clear(){super.Clear()}Destroy(){this.RemoveLis(),g.N.Inst_get().ResetSearchFriend(),
this.grid.destroy(),super.destroy()}Test1(){return!0}S_Test(){return!0}})},24499:(t,e,i)=>{i.d(e,{c:()=>Q})
var s=i(6847),n=i(83908),l=i(17409),a=i(49655),o=i(46282),r=i(38836),h=i(97960),d=i(97461),c=i(2689),_=i(13687),u=i(5924),I=i(85682),m=i(49484),g=i(60130),p=i(85602),C=i(79534),S=i(31192),f=i(14345),T=i(61076),y=i(77796),A=i(92679),D=i(87923),E=i(37648),v=i(55492),w=i(68637),R=i(19983),P=i(14792),O=i(62734),L=i(57553),B=i(619),b=i(14143),M=i(16459),G=i(98800),H=i(28192),N=i(98130),k=i(70850),U=i(49892),V=i(75961),x=i(26753),F=i(27047),q=i(13612),Y=i(9057),W=i(72005)
class j extends Y.x{constructor(...t){super(...t),this.sprite=null}InitView(){this.sprite=new W.w,this.sprite.setId(this.FatherId,this.FatherComponentID,1)}SetData(t){let e=""
e=t.isShow_get()?"mainui_sp_0005":"mainui_sp_0006",this.sprite.spriteNameSet(e),this.sprite.MakePixelPerfect()}Destroy(){this.sprite=null}}var Z,X,K=i(18998),$=i(86133),J=i(19381)
class z extends((0,n.yk)()){constructor(...t){super(...t),this.m_vo=null,this.checkTimerId=0,this._degf_CreateCell=null,this._degf_OnBgClick=null,this._degf_OnTableReposition=null,
this._degf_CheckTablePos=null,this.startX=0,this.startY=0,this.offsetx=0,this.offsetY=void 0,this.statusScrolling=!1,this.offsetRowArr=[0,-370,-740,-1110],this._m_handlerMgr=null}
_initBinder(){super._initBinder(),this._degf_CreateCell=t=>this.CreateCell(t),this._degf_OnBgClick=(t,e)=>this.OnBgClick(t,e),
this._degf_OnTableReposition=()=>this.OnTableReposition(),this._degf_CheckTablePos=()=>this.CheckTablePos()}get m_handlerMgr(){
return this._m_handlerMgr||(this._m_handlerMgr=H.h.Get()),this._m_handlerMgr}InitView(){this.table.SetInitInfo("ui_chat_cell",null,J.$),
this.table.OnReposition_set(this._degf_OnTableReposition),this.Label.node.SetActive(!0)}OnTableReposition(){if(this.m_vo.isNeedChangeCount_get()){let t=!1
const e=this.table.itemList,i=this.m_vo.GetPageCount()
i==q.k.DEFAULT_SHOW_MIN?i>=q.k.DEFAULT_SHOW_MIN&&(t=!0):i>=q.k.DEFAULT_SHOW_MAX&&(t=!0),e&&this.m_vo.ChangeShowCount(e.count,t)}
0==this.checkTimerId&&(this.checkTimerId=u.C.Inst_get().SetInterval(this._degf_CheckTablePos,3e3,1))}CheckTablePos(){let[t,e,i]=this.table.node.transform.GetLocalPositionXYZ()
4!=t&&(t=4,this.table.node.transform.SetLocalPositionXYZ(t,e,i)),u.C.Inst_get().Remove(this._degf_CheckTablePos),this.checkTimerId=0}CreateCell(t){return null}SetData(t){
this.scrollComp.enabled=!1,this.m_vo=t,this.DoRefreshView(!0),this.m_handlerMgr.AddClickEvent(this.content.node,this._degf_OnBgClick),
this.node.on(K.NodeEventType.TOUCH_MOVE,this.CreateDelegate(this.onMouseMoved),this),this.node.on(K.NodeEventType.TOUCH_START,this.CreateDelegate(this.recordStartX),this),
this.node.on(K.NodeEventType.TOUCH_END,this.CreateDelegate(this.onMouseEnd),this),this.Label.node.on(K.NodeEventType.TOUCH_MOVE,this.CreateDelegate(this.onMouseMoved),this),
this.Label.node.on(K.NodeEventType.TOUCH_START,this.CreateDelegate(this.recordStartX),this),this.Label.node.on(K.NodeEventType.TOUCH_END,this.CreateDelegate(this.onMouseEnd),this),
this.Label.textSet(this.m_vo.channelName_get()+(0,$.T)("频道内暂无消息"))}recordStartX(t){this.startX=t.getLocation().x,this.startY=t.getLocation().y}onMouseMoved(t){
if(!this.statusScrolling){(0,l.Y)(a.o.ChatShowPanel).SetScrollingStatus(!0)}this.statusScrolling=!0,this.offsetx=Math.abs(this.startX-t.getLocation().x),
this.offsetY=Math.abs(this.startY-t.getLocation().y),this.offsetx>=10&&(this.scrollComp.enabled=!1)}onMouseEnd(t){let e=1e9,i=0,s=0,n=(0,l.Y)(a.o.ChatShowPanel)
for(let t=0;t<this.offsetRowArr.length;t++)s=Math.abs(n.rowContent.node.GetLocalPositionXYZ()[0]-this.offsetRowArr[t]),e>=s&&(e=s,i=t)
n.rowContent.SetLocalPositionXYZ(this.offsetRowArr[i],n.rowContent.node.GetLocalPositionXYZ[1],0),this.statusScrolling=!1,n.isScrollIng&&n.SetScrollingStatus(this.statusScrolling)}
DoRefreshView(t){if(t||this.m_vo.isNeedRefresh_get()){const t=this.m_vo.list_get()
this.table.data_set(t)
const e=t.Count()>0
this.Label.node.SetActive(!e),this.m_vo.ResetChanged()}}SetLabelY(t){let e=64
t&&(e=64)
const i=this.Label.node.transform.GetLocalPosition()
i.y=e,this.Label.node.transform.SetLocalPosition(i),C.P.Recyle(i)}OnBgClick(t,e){this.statusScrolling||(x.d.Inst_get().controller.m_channel=this.m_vo.channel,
x.d.Inst_get().controller.OpenMainPanel(null,null,null))}Clear(){this.node.off(K.NodeEventType.TOUCH_MOVE,this.onMouseMoved,this),
this.node.off(K.NodeEventType.TOUCH_START,this.recordStartX,this),this.node.off(K.NodeEventType.TOUCH_END,this.onMouseEnd,this),
this.Label.node.off(K.NodeEventType.TOUCH_MOVE,this.onMouseMoved,this),this.Label.node.off(K.NodeEventType.TOUCH_START,this.recordStartX,this),
this.Label.node.off(K.NodeEventType.TOUCH_END,this.onMouseEnd,this),this.m_handlerMgr.RemoveClickEvent(this.content.node,this._degf_OnBgClick)}Destroy(){this.table.destroy()}}
let Q=(0,s.s_)(a.o.ChatShowPanel,o.Z.ui_chat_showpanel).layerNav().waitPrefab(o.Z.ui_chat_showchannelitem).waitPrefab(o.Z.ui_chat_channelflag).register()((X=class t extends((0,
n.Ri)()){constructor(...t){super(...t),this.cnode=null,this._degf_OnGOClick=null,this._degf_CallSend=null,this._degf_CreateCell=null,this._degf_CreateFlagCell=null,
this._degf_CreateMicroItem=null,this._degf_ExecuteAction=null,this._degf_FinishHandler=null,this._degf_OnChatDown=null,this._degf_OnChatUpdate=null,this._degf_OnDragFinished=null,
this._degf_OnDragStarted=null,this._degf_OnFullClick=null,this._degf_OnHornShow=null,this._degf_OnLayerMaskShow=null,this._degf_OnPrivateBtnUpdate=null,
this._degf_OnRoleInfoChanged=null,this._degf_OnTableReposition=null,this._degf_SetMoveState=null,this._degf_ShowAsuramTipInfo=null,this._degf_UpdateRedPoint=null,
this._degf_UpdateShowChannel=null,this._degf_UpdateAnchors=null,this._degf_UpdateBuffList=null,this._degf_OnBuffTipFullclick=null,this._degf_OnSelectTargetUpdate=null,
this._degf_OnPosTweenFinished=null,this._degf_bagUpdateHandler=null,this._degf_CallChangeState=null,this.m_hasMicroBtnShow=!1,this.m_startX=0,this.m_endX=0,this.m_isMoveing=!1,
this.m_useX=0,this.m_channleCount=0,this.m_moveIndex=0,this.microLen=0,this.m_isMicroListOut=!1,this.m_clickMicroChannel=-1,this.m_isMin=!0,this.microIndex=0,this.gridList=null,
this.isTipGrid=!1,this.isPKView=!1,this.isPosTweenPlaying=!1,this.isTweenEndCall=!1,this.tweenEndX=0,this._updateMicroBtnTimeId=0,this.cur_helpType=0,this.isJust=!1,this.isout=!1,
this.iconTipsPos=null,this.bagPos=null,this.iini=null,this.m_model=null,this.m_controller=null,this.m_posTween=null,this.isScrollIng=!1,this._m_handlerMgr=null}get m_handlerMgr(){
return this._m_handlerMgr||(this._m_handlerMgr=H.h.Get()),this._m_handlerMgr}_initBinder(){super._initBinder(),this._degf_OnGOClick=(t,e)=>this.OnGOClick(t,e),
this._degf_CallSend=()=>this.CallSend(),this._degf_CreateCell=t=>{},this._degf_CreateFlagCell=t=>{},this._degf_CreateMicroItem=t=>{},
this._degf_ExecuteAction=()=>this.ExecuteAction(),this._degf_FinishHandler=()=>this.FinishHandler(),this._degf_OnChatDown=t=>this.OnChatDown(t),
this._degf_OnChatUpdate=t=>this.OnChatUpdate(t),this._degf_OnDragFinished=()=>this.OnDragFinished(),this._degf_OnDragStarted=()=>this.OnDragStarted(),
this._degf_OnFullClick=(t,e)=>this.OnFullClick(t,e),this._degf_OnHornShow=t=>this.OnHornShow(t),this._degf_OnLayerMaskShow=t=>this.OnLayerMaskShow(t),
this._degf_OnPrivateBtnUpdate=t=>this.OnPrivateBtnUpdate(t),this._degf_OnRoleInfoChanged=t=>this.OnRoleInfoChanged(t),this._degf_OnTableReposition=()=>this.OnTableReposition(),
this._degf_SetMoveState=()=>this.SetMoveState(),this._degf_ShowAsuramTipInfo=t=>this.ShowAsuramTipInfo(t),this._degf_UpdateRedPoint=(t,e)=>this.UpdateRedPoint(t,e),
this._degf_UpdateShowChannel=t=>this.UpdateShowChannel(t),this._degf_UpdateAnchors=t=>this.UpdateAnchors(t),this._degf_UpdateBuffList=t=>this.UpdateBuffList(t),
this._degf_OnBuffTipFullclick=(t,e)=>this.OnBuffTipFullclick(t,e),this._degf_OnSelectTargetUpdate=t=>this.OnSelectTargetUpdate(t),
this._degf_OnPosTweenFinished=()=>this.OnPosTweenFinished(),this._degf_bagUpdateHandler=t=>this.bagUpdateHandler(t),this._degf_CallChangeState=()=>this.CallChangeState()}
InitView(){this.cnode=this.node.getCNode(),this.isPKView=!1,this.m_model=x.d.Inst_get().model,this.UpdateAnchors(),this.buffContainerObj&&this.buffContainerObj.SetActive(!1),
this.grid.SetInitInfo&&(this.grid.SetInitInfo("ui_chat_showchannelitem",null,z),this.grid.OnReposition_set(this._degf_OnTableReposition),
this.flagContainer.SetInitInfo("ui_chat_channelflag",null,j),this.horncontainer.SetShow(!1),this.m_posTween=new B.m,this.m_controller=x.d.Inst_get().controller,
this.microStateBtn.SetActive(!0),this.settingBtn.SetActive(!1)),x.d.Inst_get().controller.m_showPanel=this}ChangeState(t){this.isPKView=t,
u.C.Inst_get().CallLater(this._degf_CallChangeState)}CallChangeState(){this.isTweenEndCall
if(this.isTweenEndCall=!1,this.isPosTweenPlaying)return
let t=new C.P,e=this.microitemObj.node.transform.GetLocalPosition(),i=this.microStateBtn.node.transform.GetLocalPosition(),s=this.redTip.transform.GetLocalPosition()
t.x=0,t.y=324,e.x=-50.8,e.y=-41.8,i.x=-57,i.y=57
if(this.m_isMin=!0,this.isPKView);else if(this.tweenEndX>0){let t=new C.P(this.tweenEndX,324,0)
t.Set(0,324,0),C.P.Recyle(t),this.tweenEndX=0}this.tipGrid.SetActive(this.isTipGrid),this.isTipGrid&&this.SetTipShow(),this.microitemObj.node.SetLocalPositionXYZ(e.x,e.y,e.z),
this.microStateBtn.node.SetLocalPositionXYZ(i.x,i.y,i.z),this.redTip.transform.SetLocalPosition(s),C.P.Recyle(t),C.P.Recyle(e),C.P.Recyle(i),C.P.Recyle(s),
this.linesp.heightSet(118),this.ChangeSize(),this.DealBuff()}DealBuff(){if(!this.isPKView)return this.OnBuffTipFullclick(null,null),this.buffContainer.Clear(),
void this.buffContainerObj.SetActive(!1)
this.buffContainerObj.SetActive(!0),this.buffContainer.UpdateBuff()}UpdateBuffList(t){this.isPKView&&this.buffContainer.UpdateBuff()}OnSelectTargetUpdate(t){
this.isPKView&&this.buffContainer.UpdateEnemyBuff()}OnDragStarted(){this.m_isMoveing||(this.m_startX=this.scrollview.node.x)}OnDragFinished(){
this.m_isMoveing||(this.m_endX=this.scrollview.node.x,this.ChangeScrollPos())}SetChannelForce(e){let i=x.d.Inst_get().model.curShowPanelChannel
if(i==e)return
let s=-1,n=-1,l=this.gridList.count-1
for(let t=0;t<=l;t++)this.gridList[t].channel==i&&(s=t),this.gridList[t].channel==e&&(n=t)
if(-1==n)return
let a=n-s
this.m_startX=this.scrollview.node.x,this.m_endX=this.m_startX-a*t.MOVE_X,this.ChangeScrollPos()}ChangeScrollPos(){let e=!0
this.m_useX=this.m_startX
let i=this.m_endX-this.m_startX
if(i<20&&i>-20)this.m_useX=this.m_startX,e=!1
else if(this.m_isMoveing=!0,i<0)if(this.m_moveIndex==this.m_channleCount-1)this.m_useX=-(this.m_channleCount-1)*t.MOVE_X
else{let e=-(N.GF.INT((i+18)/t.MOVE_X)-1)
this.m_moveIndex=this.m_moveIndex+e,this.m_moveIndex>this.m_channleCount-1&&(this.m_moveIndex=this.m_channleCount-1),this.m_useX=-this.m_moveIndex*t.MOVE_X
}else if(0==this.m_startX)this.m_useX=0,this.m_moveIndex=0
else{let e=N.GF.INT((i-18)/t.MOVE_X)+1
e>this.m_moveIndex&&(e=this.m_moveIndex),this.m_moveIndex=this.m_moveIndex-e,this.m_useX=-this.m_moveIndex*t.MOVE_X}
if(e)this.m_posTween.SetLuaParam(this.scrollview.node,N.GF.INT(this.m_endX),N.GF.INT(this.m_useX),this._degf_FinishHandler,!1,this._degf_ExecuteAction),
this.m_posTween.StartTween(),u.C.Inst_get().SetFrameLoop(this._degf_SetMoveState,12,1)
else{let t=this.scrollview.node.getPosition()
t.x=this.m_useX,this.scrollview.node.SetLocalPositionXYZ(t.x,t.y,t.z),C.P.Recyle(t)}}SetMoveState(){this.m_isMoveing=!1}ExecuteAction(){this.m_posTween.moveValues,
this.m_posTween.callTag}SetClipX(t,e){}AddOrDelEvent(t){let e=G.Y.Inst.PrimaryRoleInfo_get()
t?(this.m_handlerMgr.AddClickEvent(this.bg,this._degf_OnGOClick),this.m_handlerMgr.AddClickEvent(this.scrollview.node,this._degf_OnGOClick),
this.scrollview.RegistonDragBegan(this._degf_OnDragStarted),this.scrollview.RegistonDragFinished(this._degf_OnDragFinished),
this.m_handlerMgr.AddClickEvent(this.settingBtn,this._degf_OnGOClick),this.m_handlerMgr.AddClickEvent(this.bg,this._degf_OnGOClick),
this.m_handlerMgr.AddClickEvent(this.microStateBtn,this._degf_OnGOClick),this.m_handlerMgr.AddClickEvent(this.allianceInfoTip,this._degf_OnGOClick),
this.m_handlerMgr.AddClickEvent(this.crossServerTip,this._degf_OnGOClick),this.m_handlerMgr.AddClickEvent(this.alliancePopup,this._degf_OnGOClick),
this.m_handlerMgr.AddClickEvent(this.helpTip.node,this._degf_OnGOClick),this.m_handlerMgr.AddClickEvent(this.helpPopup.node,this._degf_OnGOClick),
this.m_handlerMgr.AddClickEvent(this.bagBtn,this._degf_OnGOClick),this.m_handlerMgr.AddClickEvent(this.SettingBtn,this._degf_OnGOClick),
this.m_model.AddEventHandler(M.F.SHOW_HORN_MESSAGE,this._degf_OnHornShow),this.m_model.AddEventHandler(M.F.UPDATE_CHAT,this._degf_OnChatUpdate),
this.m_model.AddEventHandler(M.F.CHANGE_SHOW_CHANNEL,this._degf_UpdateShowChannel),d.i.Inst.AddEventHandler(A.g.SHOW_MASK_LAYER,this._degf_OnLayerMaskShow),
d.i.Inst.AddEventHandler(A.g.ALLIANCE_BASEINFO_UPDATE,this.CreateDelegate(this._OnAllianceUpdate)),d.i.Inst.AddEventHandler(A.g.UPDATE_ANCHORS,this._degf_UpdateAnchors),
e.AddEventHandler(h.A.AsuramIdUpdate,this._degf_OnRoleInfoChanged),e.AddEventHandler(h.A.TeamUpdate,this._degf_OnRoleInfoChanged),
e.AddEventHandler(h.A.LevelUpdate,this._degf_OnRoleInfoChanged),d.i.Inst.AddEventHandler(A.g.FUNCTION_OPEN,this._degf_OnRoleInfoChanged),
O.f.Inst.AddCallback(P.t.CHAT_TEAM,this._degf_UpdateRedPoint),O.f.Inst.AddCallback(P.t.CHAT_ASURAM,this._degf_UpdateRedPoint),
O.f.Inst.AddCallback(P.t.CHAT_CROSS_SERVER,this._degf_UpdateRedPoint),O.f.Inst.AddCallback(P.t.FRIEND,this._degf_UpdateRedPoint),
O.f.Inst.AddCallback(P.t.SETUP,this._degf_UpdateRedPoint),O.f.Inst.AddCallback(P.t.RYALLIANCE_CHUANGONGASSIT,this._degf_UpdateRedPoint),
O.f.Inst.AddCallback(P.t.RYALLIANCE_BOSSASSIT,this._degf_UpdateRedPoint),O.f.Inst.AddCallback(P.t.RYALLIANCE_ITEMASSIT,this._degf_UpdateRedPoint),
this.m_model.AddEventHandler(M.F.UPDATE_PRIVATE_NAME_BTN,this._degf_OnPrivateBtnUpdate),this.m_model.AddEventHandler(M.F.SEND_CHAT_ASURAM_I18,this._degf_ShowAsuramTipInfo),
d.i.Inst.AddEventHandler(A.g.SELECT_TARGET_CHANGE,this._degf_OnSelectTargetUpdate),d.i.Inst.AddEventHandler(A.g.BAG_UPDATE,this._degf_bagUpdateHandler),
d.i.Inst.AddEventHandler(A.g.MAP_LOGIN_LOAD_COMPELETE,this._degf_OnRoleInfoChanged),
this.m_handlerMgr.AddEventMgr(A.g.UITweenStateChanged,this.CreateDelegate(this.OnUITweenStateChanged)),
this.RegGuide()):(this.m_handlerMgr.RemoveClickEvent(self.bg,self._degf_OnGOClick),this.m_handlerMgr.RemoveClickEvent(self.allianceInfoTip,self._degf_OnGOClick),
this.m_handlerMgr.RemoveClickEvent(this.scrollview.node,this._degf_OnGOClick),this.scrollview.RemoveonDragBegan(this._degf_OnDragStarted),
this.scrollview.RemoveonDragFinished(this._degf_OnDragFinished),this.m_handlerMgr.RemoveClickEvent(this.settingBtn,this._degf_OnGOClick),
this.m_handlerMgr.RemoveClickEvent(this.bg,this._degf_OnGOClick),this.m_handlerMgr.RemoveClickEvent(this.microStateBtn,this._degf_OnGOClick),
this.m_handlerMgr.RemoveClickEvent(this.allianceInfoTip,this._degf_OnGOClick),this.m_handlerMgr.RemoveClickEvent(this.crossServerTip,this._degf_OnGOClick),
this.m_handlerMgr.RemoveClickEvent(this.alliancePopup,this._degf_OnGOClick),this.m_handlerMgr.RemoveClickEvent(this.helpTip,this._degf_OnGOClick),
this.m_handlerMgr.RemoveClickEvent(this.helpPopup,this._degf_OnGOClick),this.m_handlerMgr.RemoveClickEvent(this.bagBtn,this._degf_OnGOClick),
this.m_model.RemoveEventHandler(M.F.SHOW_HORN_MESSAGE,this._degf_OnHornShow),this.m_model.RemoveEventHandler(M.F.UPDATE_CHAT,this._degf_OnChatUpdate),
this.m_model.RemoveEventHandler(M.F.CHANGE_SHOW_CHANNEL,this._degf_UpdateShowChannel),d.i.Inst.RemoveEventHandler(A.g.UPDATE_ANCHORS,this.iini),
d.i.Inst.RemoveEventHandler(A.g.SHOW_MASK_LAYER,this._degf_OnLayerMaskShow),d.i.Inst.RemoveEventHandler(A.g.ALLIANCE_BASEINFO_UPDATE,this.CreateDelegate(this._OnAllianceUpdate)),
e.RemoveEventHandler(h.A.AsuramIdUpdate,this._degf_OnRoleInfoChanged),e.RemoveEventHandler(h.A.TeamUpdate,this._degf_OnRoleInfoChanged),
e.RemoveEventHandler(h.A.LevelUpdate,this._degf_OnRoleInfoChanged),d.i.Inst.AddEventHandler(A.g.FUNCTION_OPEN,this._degf_OnRoleInfoChanged),
O.f.Inst.RemoveCallback(P.t.CHAT_TEAM,this._degf_UpdateRedPoint),O.f.Inst.RemoveCallback(P.t.CHAT_ASURAM,this._degf_UpdateRedPoint),
O.f.Inst.RemoveCallback(P.t.CHAT_CROSS_SERVER,this._degf_UpdateRedPoint),O.f.Inst.RemoveCallback(P.t.FRIEND,this._degf_UpdateRedPoint),
O.f.Inst.RemoveCallback(P.t.SETUP,this._degf_UpdateRedPoint),O.f.Inst.RemoveCallback(P.t.RYALLIANCE_CHUANGONGASSIT,this._degf_UpdateRedPoint),
O.f.Inst.RemoveCallback(P.t.RYALLIANCE_BOSSASSIT,this._degf_UpdateRedPoint),O.f.Inst.RemoveCallback(P.t.RYALLIANCE_ITEMASSIT,this._degf_UpdateRedPoint),
this.m_model.RemoveEventHandler(M.F.UPDATE_PRIVATE_NAME_BTN,this._degf_OnPrivateBtnUpdate),this.m_model.RemoveEventHandler(M.F.SEND_CHAT_ASURAM_I18,this._degf_ShowAsuramTipInfo),
d.i.Inst.RemoveEventHandler(A.g.SELECT_TARGET_CHANGE,this._degf_OnSelectTargetUpdate),d.i.Inst.RemoveEventHandler(A.g.BAG_UPDATE,this._degf_bagUpdateHandler),
d.i.Inst.RemoveEventHandler(A.g.MAP_LOGIN_LOAD_COMPELETE,this._degf_OnRoleInfoChanged),
this.m_handlerMgr.RemoveEventMgr(A.g.UITweenStateChanged,this.CreateDelegate(this.OnUITweenStateChanged)),this.m_handlerMgr.Clear(),this.UnRegGuide())}OnUITweenStateChanged(t,e){
null==e&&(e=!1),(this.isout!=t||e)&&(this.isout=t,this.node.visible=!t)}RegGuide(){w.c.Inst.RegGameObject(I.D.UI_MAIN_HELP_BTN,this.helpTip.node)}UnRegGuide(){
w.c.Inst.UnRegGameObject(I.D.UI_MAIN_HELP_BTN)}CheckGuide(){D.l.CheckBtnClickTrigger(I.D.UI_MAIN_HELP_BTN)}OnPosTweenFinished(){this.isPosTweenPlaying=!1,
this.isPKView?this.buffContainer.enemyBuffGrid.node.SetActive(!0):(this.isTweenEndCall=!0,this.ChangeState(!1))}UpdateAnchors(t){g.O.SetAnchorPos(this.anchor,!0,!0,-2,!1)}
ShowAsuramTipInfo(t){if(G.Y.Inst.PrimaryRoleInfo_get().isHaveAlliance_get()){let e=t
this.ShowPopupTxt(e)}}RefreshAllianceAssitRedpoint(){if(G.Y.Inst.PrimaryRoleInfo_get().isHaveAlliance_get()){let t=O.f.Inst.GetData(P.t.RYALLIANCE_CHUANGONGASSIT)
if(t.show)return void this.ShowHelpPopupByType(f.J.ChuanGongAssit)
if(t=O.f.Inst.GetData(P.t.RYALLIANCE_BOSSASSIT),t.show)return void this.ShowHelpPopupByType(f.J.BossAssist)
if(t=O.f.Inst.GetData(P.t.RYALLIANCE_ITEMASSIT),t.show)return void this.ShowHelpPopupByType(f.J.ItemAssit)}this.NewHideHelpPopup(null)}HideAlliancePopup(){
this.popupPanel.SetActive(!1)}NewHideHelpPopup(t){this.helpPopupPanel.SetActive(!1),this.helpRedTip.SetActive(!1)}ShowPopupTxt(t){this.popupPanel.SetActive(!0),
this.popupTxt.textSet(t),this.alliancePopup.widthSet(N.GF.INT(this.popupTxt.textWidth)+18)}ShowHelpPopupByType(t){let e,i
t==f.J.ChuanGongAssit?(e="传功协助",i="atlas/mainui/rymainui_sp_0173"):t==f.J.BossAssist?(e="BOSS协助",i="atlas/mainui/rymainui_sp_0172"):(e="材料协助",i="atlas/mainui/rymainui_sp_0171"),
this.helpRedTip.SetActive(!1),this.helpPopupPanel.SetActive(!0),this.helpPopupTxt.textSet(e),this.helpPopupTxt.updateRenderer(),
this.helpPopup.widthSet(N.GF.INT(this.helpPopupTxt.node.transform.width)+18),this.helpPopup.spriteNameSet(i)}OnPrivateBtnUpdate(t){this.CheckRedShow()}CheckRedShow(){
this.crossServerRedTip.SetActive(!1)
let t=null
t=O.f.Inst.GetData(P.t.SETUP),null!=this.settingBtntip&&this.settingBtntip.SetActive(t.show),t=O.f.Inst.GetData(P.t.CHAT_CROSS_SERVER),
t.show&&(F.w.Inst_get().IsPanelOpen()||this.crossServerRedTip.SetActive(!0)),this.RefreshAllianceAssitRedpoint()
let e=O.f.Inst.GetData(P.t.CHAT_ASURAM)
this.allianceRedTip.SetActive(!1),e.show?this.allianceRedTip.SetActive(!0):this.popupPanel.SetActive(!1)
let i=this.m_model.privateModel.GetPrivateModes(),s=null,n=!1,l=0,a=0
for(;l<i.Count();)s=i[l],s.hasNew&&(n=!0,a+=1),l+=1
if(this.redTip.SetActive(!1),n){let t=new V.U(U.K.ICON_TIPS_CHAT_PRIVATE)
R.S.Inst_get().AddIcon(t),R.S.Inst_get().UpdateCount(U.K.ICON_TIPS_CHAT_PRIVATE,a)}else R.S.Inst_get().RemoveIcon(U.K.ICON_TIPS_CHAT_PRIVATE)}UpdateRedPoint(t,e){
this.CheckRedShow()}OnRoleInfoChanged(t){this.ChangeMicroBtn(!1)}OnLayerMaskShow(t){t||this.DoRefresh(!0)}OnHornShow(t){if(this.isPKView)return
let e=t
this.horncontainer.SetData(e),this.CallSend(),this.m_isMin}OnGOClick(t,e){
t.target.name==this.settingBtn.name||(t.target.name==this.bg.node.name?(x.d.Inst_get().controller.m_channel=x.d.Inst_get().model.curShowPanelChannel,
x.d.Inst_get().controller.OpenMainPanel(null,null,null)):t.target.name==this.microStateBtn.node.name?this.ChangeMicroBtn(!0):t.target.name==this.allianceInfoTip.node.name||t.target.name==this.alliancePopup.node.name?(x.d.Inst_get().controller.m_channel=b.L.ALLIANCE,
x.d.Inst_get().controller.OpenMainPanel(null,null,null)):t.target.name==this.crossServerTip.node.name?F.w.Inst_get().OpenView():t.currentTarget.name==this.helpTip.node.name||t.currentTarget.name==this.helpPopup.node.name?(this.CheckGuide(),
T.$.Inst_get().useDefaultTab=!0,S.d.Inst_get().OpenAssistBasePanel()):t.target.name==this.bagBtn.node.name?(0,
l.Yp)(a.o.BagView):t.target.name==this.SettingBtn.node.name?L._.Inst.OpenMainPanel(!0):(t.target.name,this.scrollPanel.node.name))}ChangeMicroBtn(t){
let e=G.Y.Inst.PrimaryRoleInfo_get(),i=new p.Z,s=!1,n=-141
e.isHaveAlliance_get()&&(i.Add(b.L.ALLIANCE),s=!0,n=-91),e.isHaveTeam_get(),i.Add(b.L.WORLD)
let l=i.count
t&&(this.microIndex=this.microIndex+1),this.microIndex>=l&&(this.microIndex=0)
let a=i[this.microIndex]
this.microitem.SetData(a)
let o=!0
1==l&&(o=!1),this.microStateBtn.SetActive(o),this.isTipGrid=s,this.tipGrid.SetActive(s),s&&this.SetTipShow(),this.horncontainer.SetYPos(n)}ChangeMicroState(){
let t=G.Y.Inst.PrimaryRoleInfo_get(),e=new p.Z,i=!0,s=!1,n=new C.P
if(t.isHaveAlliance_get()&&(s=!0),s=!1,this.m_isMicroListOut){i=!1
let s=!0;-1!=this.m_clickMicroChannel&&(this.m_clickMicroChannel==b.L.ALLIANCE?t.isHaveAlliance_get()&&(i=!0,s=!1,e.Add(b.L.WORLD),t.isHaveTeam_get()&&e.Add(b.L.TEAM),
e.Add(b.L.ALLIANCE)):this.m_clickMicroChannel==b.L.TEAM?t.isHaveTeam_get()&&(i=!0,s=!1,e.Add(b.L.WORLD),t.isHaveAlliance_get()&&e.Add(b.L.ALLIANCE),
e.Add(b.L.TEAM)):this.m_clickMicroChannel==b.L.WORLD&&(s=!1,t.isHaveTeam_get()&&(i=!0,e.Add(b.L.TEAM)),t.isHaveAlliance_get()&&(i=!0,e.Add(b.L.ALLIANCE)),e.Add(b.L.WORLD))),
s&&(this.m_clickMicroChannel=-1,e.Add(b.L.WORLD),t.isHaveTeam_get()&&(i=!0,e.Add(b.L.TEAM)),t.isHaveAlliance_get()&&(i=!0,e.Add(b.L.ALLIANCE))),n=new C.P(0,0,180).Clone()}else{
let s=!0;-1!=this.m_clickMicroChannel&&(this.m_clickMicroChannel==b.L.TEAM?t.isHaveTeam_get()&&(e.Add(this.m_clickMicroChannel),
s=!1):this.m_clickMicroChannel==b.L.ALLIANCE?t.isHaveAlliance_get()&&(e.Add(this.m_clickMicroChannel),s=!1):this.m_clickMicroChannel==b.L.WORLD?(e.Add(b.L.WORLD),s=!1,
t.isHaveTeam_get()||t.isHaveAlliance_get()||(i=!1)):this.m_clickMicroChannel=-1),
s&&(t.isHaveAlliance_get()?e.Add(b.L.ALLIANCE):t.isHaveTeam_get()?e.Add(b.L.WORLD):(e.Add(b.L.WORLD),i=!1)),n=new C.P(0,0,0).Clone()}this.helpTip.SetActive(s),
this.tipGrid.Reposition(),s||this.NewHideHelpPopup(null),C.P.Recyle(n),this.microLen=e.Count()
let l=68*e.Count()+16
if(this.microBg.heightSet(l),i){let t=new C.P(0,l-10,0)
this.microStateBtn.node.SetLocalPositionXYZ(t.x,t.y,t.z),C.P.Recyle(t)}let a=-10,o=!0;(e.Count()>1||s)&&(o=!1,a=44),this.horncontainer.SetXPos(a,o),
this.crossServerTip.node.SetActive(F.w.Inst_get().IsShowCrossServer()),this.crossServerTip.node.SetActive(!1)}OnFullClick(t,e){this.m_isMicroListOut=!1,this.m_clickMicroChannel=-1}
CloleMicroByClick(t){this.m_clickMicroChannel=t,this.m_isMicroListOut=!1}OnChatDown(t){
t&&this.m_isMin&&this.horncontainer.isPlay&&u.C.Inst_get().SetInterval(this._degf_CallSend,500,1)}CallSend(){d.i.Inst.RaiseEvent(A.g.OPERATION_DOWN,!0)}ChangeSize(){let t=-38,e=0
this.m_isMin?e=q.k.MIN_SHOW_SIZE:(t=-123,e=q.k.PK_SHOW_SIZE),this.m_hasMicroBtnShow&&!this.isPKView||(t-=50),this.bg.heightSet(e+5)
let i=this.scrollPanel.clipOffset(),s=this.grid.node.position
s.y=-e-14,this.grid.node.SetLocalPositionXYZ(s.x,s.y,s.z),C.P.Recyle(s),this.scrollPanel.clipOffsetSet(i)
let n=this.scrollview.node.position
n.x=this.m_useX,n.y=e,this.scrollview.node.SetLocalPositionXYZ(n.x,n.y,n.z),C.P.Recyle(n),this.OnTableReposition(),this.horncontainer.SetYPos(t),
this.m_model.UpdateDefaultCount(this.m_isMin),this.DoRefresh(!0),this.SetTipShow()}SetTipShow(){
let t=G.Y.Inst.PrimaryRoleInfo_get().isHaveAlliance_get(),e=E.P.Inst_get().IsFuncOrActivityOpened(v.x.ASURAM_BOSS_ASSIST)||E.P.Inst_get().IsFuncOrActivityOpened(v.x.ASURAM_CHUANGONG)||E.P.Inst_get().IsFuncOrActivityOpened(v.x.ASURAM_ITEM_ASSIST),i="",s=_.b.Inst.GetCurMap()
null!=s&&(i=s.controllerType,i!=c.N.WORLD_BOSS_NEWHAND&&t&&e?this.helpTip.node.SetActive(!0):this.helpTip.node.SetActive(!1),this.crossServerTip.node.SetActive(!1),
this.tipGrid.Reposition())}OnTableReposition(){this.SetContentLabelY(),this.SetScrollValue()}FinishHandler(){this.m_isMoveing=!1,this.SetClipX(-this.m_useX,!1),
this.m_model.SetCurShowChannel(this.m_moveIndex),this.DoRefresh(!1),this.flagContainer.node.SetActive(!1)}SetScrollValue(){if(0==this.grid.data_get().Count())return
this.m_moveIndex>=this.m_channleCount&&(this.m_moveIndex=0),this.m_model.SetCurShowChannel(this.m_moveIndex),this.m_useX=-this.m_moveIndex*t.MOVE_X
let e=this.scrollview.node.transform.GetLocalPosition()
e.x=this.m_useX,this.scrollview.node.transform.SetLocalPosition(e),this.SetClipX(-this.m_useX,!1),C.P.Recyle(e)}SetContentLabelY(){let t=this.grid.itemList
if(t)for(const[e,i]of(0,r.V5)(t))i.SetLabelY(!this.m_isMin)}OnAddToScene(){this.AddOrDelEvent(!0),this.iconTipsPos=this.iconTipsPosition.getPosition,
this.bagPos=this.bagPosition.getPosition,this.AddOrDelEvent(!0),this.DoRefresh(!1),m.p.Inst_get().EnterMap(_.b.Inst.currentMapId_get()),this.UpdateShowChannel(null),
this.OnRoleInfoChanged(null),this.ChangeSize(),this.CheckRedShow(),y.v.Inst_get().GetChatI18N(),this.UpdateAnchors(null),this.ChangeMicroBtn(!1),
this.m_handlerMgr.ClearInterval(this._updateMicroBtnTimeId),this._updateMicroBtnTimeId=this.m_handlerMgr.SetInterval(this.CreateDelegate(this.UpdateMicroBtnDelay),1e3,10),
d.i.Inst.AddEventHandler(A.g.MAP_LOAD_COMPELETE,this.CreateDelegate(this.HandleEnterMap)),this.HandleEnterMap()}UpdateMicroBtnDelay(){this.ChangeMicroBtn(!1)}_OnAllianceUpdate(){
let t=G.Y.Inst.PrimaryRoleInfo_get().isHaveAlliance_get(),e=!1
if(null!=this.gridList)for(const[t,i]of(0,r.V5)(this.gridList))if(i.channel==b.L.ALLIANCE){e=!0
break}t!=e&&this.UpdateShowChannel(null),this.ChangeMicroBtn(!1),this.allianceInfoTip.node.SetActive(t),this.tipGrid.Reposition()}UpdateShowChannel(t){
let e=this.m_model.GetScrollChannels()
this.gridList=e,this.grid.data_set(e),this.rowContent.width=370*e.count,this.m_channleCount=e.Count(),this.flagContainer.node.SetActive(!1)}OnChatUpdate(t){let e=t
this.DoRefresh(e)}DoRefresh(t){let e=this.grid.itemList
if(e)for(let i=0;i<e.count;i++)e[i].DoRefreshView(t)}HandleEnterMap(){let t=_.b.Inst.GetCurMap()
null!=t&&t.hideElementsList.IndexOf(m.p.Setting_ICON),this.SettingBtn.SetActive(!1)}SetDebuffTip(t,e,i,s){this.buffContainer.ShowTip(t,e,i,s)}OnBuffTipFullclick(t,e){
this.buffContainer.CloseTip()}bagUpdateHandler(t){let e=k.g.Inst_get().emptySize_get()
this.bagRedTip.SetActive(0==e)}CloseBuffTip(){null!=this.buffContainer&&this.buffContainer.CloseTip()}Clear(){this.isout=!1,this.AddOrDelEvent(!1)}Destroy(){
this.m_posTween.Destroy(),this.grid.destroy(),this.flagContainer.destroy()}ResetPanel(){this.redTip.SetActive(!1)}SetScrollingStatus(t){this.isScrollIng=t}},
X.CHAT_BOTTOM_SHOW_CELL="chat_bottom_show_cell",X.MOVE_X=438,Z=X))||Z},66999:(t,e,i)=>{i.d(e,{j:()=>o})
var s,n=i(18998),l=i(30849),a=i(38844)
let o=n._decorator.ccclass("ChatTabRightItem")(s=class extends l.C{constructor(...t){super(...t),this.isSelect=!1,this.cachRedpointShow=!1,this.img_bg=null,this.redPoint=null,
this.index=0,this.data=null,this.wordColor=void 0}InitView(){this.img_bg=this.node.getComponent(a.E)
let t=this.node.getChildByName("name")
t&&(this.wordColor=t.getComponent(n.Label)),this.img_bg&&(this.redPoint=this.node.getChildByName("ryliaotian_sp_0016"))}SetData(t){this.RemoveLis(),this.data=t,
this.SetItemClickGo(this.node),this.AddLis()}AddLis(){}RemoveLis(){}UnRegGuide(){}InternalSetRedPoint(t){null!=this.redPoint&&(this.redPoint.active=t)}SetRedPoint(t){
this.cachRedpointShow=t,this.InternalSetRedPoint(t)}SetSelect(t){this.isSelect=t,this.UpdateLevel()}UpdateLevel(){
this.isSelect?(this.wordColor&&(this.wordColor.color=n.math.color("#60473F")),
this.img_bg.skin="atlas/liaotian/ryliaotian_bt_0009"):(this.wordColor&&(this.wordColor.color=n.math.color("#A69886")),this.img_bg.skin="atlas/liaotian/ryliaotian_bt_0010")}
Clear(){}})||s},98899:(t,e,i)=>{i.d(e,{v:()=>u})
var s=i(62370),n=i(99294),l=i(9057),a=i(93877),o=i(98885),r=i(87923),h=i(4586),d=i(79878),c=i(26753),_=i(64444)
class u extends l.x{constructor(){super(),this.label=null,this.cell=null,this.m_config=null,this._degf_OnCellClick=null,this._degf_OnCellClick=(t,e)=>this.OnCellClick(t,e)}
InitView(){this.label=new a.Q,this.label.setId(this.FatherId,this.FatherComponentID,1),this.cell=new n.z,this.cell.setId(this.FatherId,this.FatherComponentID,2)}SetData(t){
this.m_config=t
const e=`${d.Y.GetTypeNameWithoutColor(this.m_config.type_get())}-${h.G.CutColorStr(this.m_config.taskName_get())}`
this.label.textSet(e),d.Y.RegLuaClick(this.cell,this._degf_OnCellClick)}OnCellClick(t,e){let i=o.M.s_LEFT_M_K_CHAR+(this.label.text()+o.M.s_RIGHT_M_K_CHAR)
const n=i
i=r.l.SetStringColor(r.l.txtGreenStr,i)
const l=c.d.Inst_get().controller.ChatMainPanel_get()
if(l.ClearInput(),l.AddLinkStrToInput(i)){const t=s.o.s_UNDER_CHAR,e=_.B.TASK+(t+this.m_config.id_get()),a=r.l.SetLinkStr(n,e,r.l.txtGreenStr,!1)
l.linkDic.LuaDic_AddOrSetItem(i,a)}}Clear(){d.Y.DelLuaClick(this.cell,this._degf_OnCellClick),this.m_config=null}Destroy(){this.label=null,this.cell=null}}},69688:(t,e,i)=>{i.d(e,{
D:()=>r})
var s,n=i(18998),l=i(83908),a=i(9057),o=i(26753)
let r=n._decorator.ccclass("ChatTotalCell")(s=class extends((0,l.pA)(a.x)()){constructor(...t){super(...t),this.m_cell=null,this.isCrossChat=!1}InitView(){}SetData(t){
this.node.SetLocalPositionXYZ(0,this.node.position.y,0)
const e=t
e.isSystemInfo?this.m_cell=this.systemCell:(this.m_cell=this.personCell,this.m_cell.isChannelTab=o.d.Inst_get().controller.IsChannelTab()),
this.systemCell.node.SetActive(this.m_cell==this.systemCell),this.personCell.node.SetActive(this.m_cell==this.personCell),
this.worldchatcell.node.SetActive(this.m_cell==this.worldchatcell),this.m_cell.SetData(e),this.node.transform.height=this.m_cell.node.height+2}Clear(){
null!=this.m_cell&&this.m_cell.Clear()}Destroy(){null!=this.systemCell&&this.systemCell.destroy(),null!=this.personCell&&this.personCell.destroy(),this.m_cell=null}})||s},
96464:(t,e,i)=>{var s,n=i(18998),l=i(83908),a=i(65829),o=i(98885),r=i(79534),h=i(845),d=i(26753)
n._decorator.ccclass("ChatVoiceIcon")(s=class extends((0,l.zB)()){constructor(...t){super(...t),this.m_info=null}InitView(){}SetData(t,e){this.m_info=t,
this.timeLabel.textSet(`${o.M.IntToString(t.smChat.recordTime)}s`)
let i=40*t.smChat.recordTime
if(i<160?i=160:i>305&&(i=306),this.redPoint.SetActive(!t.isVoiceHeard),this.m_info.smChat.sender.IsMe()&&this.redPoint.SetActive(!1),
a.X.Inst_get().IsVoicePlaying(t.smChat.voiceUrl)?this.SetPlayState(!0):this.SetPlayState(!1),!t.isVoiceHeard){const t=this.redPoint.transform.GetLocalPosition()
t.x=12+i,this.redPoint.transform.SetLocalPosition(t),r.P.Recyle(t)}
return!this.m_info.isVoiceHeard&&h.g.Inst_get().IsAutoPlayVoice(t.smChat.channelId)&&(this.m_info.smChat.sender.IsMe()||(d.d.Inst_get().model.autoPlayVoiceDict.LuaDic_ContainsKey(this.m_info.smChat.voiceUrl)||(d.d.Inst_get().model.autoPlayVoiceQueue.Add(this.m_info.smChat.voiceUrl),
d.d.Inst_get().model.autoPlayVoiceDict.LuaDic_AddOrSetItem(this.m_info.smChat.voiceUrl,this.m_info)),
a.X.Inst_get().IsAnyVoicePlaying()||0!=d.d.Inst_get().model.waitToPlayVoiceMapId||this.PlayVoice())),46+i}SetRedPointPos(t){const e=this.redPoint.transform.GetLocalPosition()
e.x=t,this.redPoint.transform.SetLocalPosition(e)}PlayVoice(){this.m_info.isVoiceHeard=!0,a.X.Inst_get().PlayVoiceByUrl(this.m_info.smChat.voiceUrl),this.redPoint.SetActive(!1)}
SetPlayState(t){this.voiceIcon.SetActive(!t),this.voiceEffect.SetActive(t),1==t&&this.redPoint.SetActive(!1)}Clear(){this.m_info=null}Destory(){}})},50018:(t,e,i)=>{i.d(e,{f:()=>v
})
var s,n=i(6847),l=i(83908),a=i(49655),o=i(46282),r=i(86133),h=i(75309),d=i(65829),c=i(51696),_=i(47640),u=i(5924),I=i(60130),m=i(95721),g=i(98130),p=i(85602),C=i(79534),S=i(87923),f=i(22662),T=i(845),y=i(65550),A=i(79878),D=i(26753),E=i(14143)
let v=(0,n.s_)(a.o.eChatVoicePanel,o.Z.ui_chat_voice).register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),this.m_speakers=null,this.relateTran=null,
this.m_timerId=0,this.m_startX=255,this.m_isSpeaker=!0,this.m_sendChannel=0,this.m_isShowPanel=!1,this.voiceCallbackId=0,this.m_privateModel=null,this.m_startResult=0,
this.m_isUseRecord=!1,this.m_recordTimerId=0,this.m_volumeTimerId=0,this.m_microIndex=0,this.m_startY=0,this._degf_CalcMousePos=null,this._degf_OnBgClick=null,
this._degf_OnSendVoice=null,this._degf_SetUseRecord=null,this._degf_UpdateVolume=null,this._degf_OnFullclick=null}_initBinder(){super._initBinder(),
this._degf_CalcMousePos=()=>this.CalcMousePos(),this._degf_OnBgClick=(t,e)=>this.OnBgClick(t,e),this._degf_OnSendVoice=()=>this.OnSendVoice(),
this._degf_SetUseRecord=()=>this.SetUseRecord(),this._degf_UpdateVolume=()=>this.UpdateVolume(),this._degf_UpdateVolume=()=>this.UpdateVolume(),
this._degf_OnFullclick=(t,e)=>this.OnFullclick(t,e)}InitView(){
this.m_speakers=new p.Z([this.speakerSimbol0,this.speakerSimbol1,this.speakerSimbol2,this.speakerSimbol3,this.speakerSimbol4]),
this.m_isShowPanel=D.d.Inst_get().controller.isShowPanel,this.m_microIndex=D.d.Inst_get().controller.microIndex,this.relateTran=D.d.Inst_get().controller.relateTran,
this.m_sendChannel=D.d.Inst_get().controller.sendChannel,this.m_privateModel=D.d.Inst_get().model.privateModel}OnAddToScene(){this.AddOnVoiceCallback()
const t=I.O.GetRelateMousePiont(this.relateTran)
this.m_startY=t.y,this.m_timerId=u.C.Inst_get().SetInterval(this._degf_CalcMousePos,200),this.CalcMousePos(),this.SetPos(),this.SetState(),this.StartVoice(),this.DelBgm(!0)}
OnFullclick(t,e){D.d.Inst_get().controller.CloseVoicePanel()}DelBgm(t){if(t)_.y.Inst_get().SoundSetGroupMute(c.G.BACKGROUND_SOUND_GROUP,!0),
_.y.Inst_get().SoundSetGroupMute(c.G.EFFECT2D_SOUND_GROUP,!0),_.y.Inst_get().SoundSetGroupMute(c.G.DEFAULT_SOUND_GROUP,!0)
else{const t=T.g.Inst_get().systemModel.systemSetting_get()
_.y.Inst_get().SoundSetGroupMute(c.G.BACKGROUND_SOUND_GROUP,!t.autoMusic),_.y.Inst_get().SoundSetGroupMute(c.G.EFFECT2D_SOUND_GROUP,!t.autoSound),
_.y.Inst_get().SoundSetGroupMute(c.G.DEFAULT_SOUND_GROUP,!t.autoSound)}}SetPos(){const t=this.container.GetLocalPosition()
t.x=-270,this.m_isShowPanel&&(t.x=0),this.container.SetLocalPosition(t),C.P.Recyle(t)}StartVoice(){let t=!0
if(this.m_isUseRecord=!1,this.m_sendChannel==E.L.PRIVATE?0==this.m_privateModel.PrivateChatParm_senderID.Equal(m.o.ZERO)&&(this.m_startResult=d.X.Inst_get().StartRecord(this.voiceCallbackId,this.m_sendChannel,0,this.m_privateModel.PrivateChatParm_senderID)):this.m_startResult=d.X.Inst_get().StartRecord(this.voiceCallbackId,this.m_sendChannel,0),
0!=this.m_startResult){t=!1
let e=null;(1==this.m_startResult||2==this.m_startResult)&&(e=(0,r.T)("尚未获得麦克风权限，无法录音")),S.l.IsEmptyStr(e)||y.y.inst.ClientStrMsg(f.r.SystemTipMessage,e)
}else u.C.Inst_get().ClearLoop(this.m_recordTimerId),this.m_recordTimerId=u.C.Inst_get().SetInterval(this._degf_SetUseRecord,1e3,1),
u.C.Inst_get().ClearInterval(this.m_volumeTimerId),this.m_volumeTimerId=u.C.Inst_get().SetInterval(this._degf_UpdateVolume,300)
this.loadContainer.SetActive(t)}UpdateVolume(){if(0==this.m_volumeTimerId)return
let t=0
const e=d.X.Inst_get().GetVolume()
e>80?t=5:e>60?t=4:e>40?t=3:e>20?t=2:e>0&&(t=1)
let i=0
for(;i<5;)this.m_speakers[i].SetActive(i<t),i+=1}SetUseRecord(){this.m_isUseRecord=!0,this.m_recordTimerId=-1}AddOnVoiceCallback(){
this.voiceCallbackId=h.n.AddCallBackOnVoiceDelegate(this._degf_OnSendVoice),A.Y.RegLuaClick(this.maskBg,this._degf_OnBgClick)}RemoveOnVoiceCallback(){
0!=this.voiceCallbackId&&h.n.RemoveCallBackOnVoiceDelegate(this.voiceCallbackId),A.Y.DelLuaClick(this.maskBg,this._degf_OnBgClick)}OnBgClick(t,e){
D.d.Inst_get().controller.CloseVoicePanel()}OnSendVoice(){D.d.Inst_get().controller.CloseVoicePanel()}DealSend(){let t=this.m_isSpeaker
if(t){const e=g.GF.MTimer_get(),i=D.d.Inst_get().model.recordMin
e-d.X.Inst_get().lastRecordTime<1e3*i&&(y.y.inst.ClientSysMessage(112018,new p.Z([i])),t=!1)}t&&(0==this.m_startResult&&this.m_isUseRecord||(t=!1)),d.X.Inst_get().StopRecord(t),
this.m_isUseRecord=!1}CalcMousePos(){if(0==this.m_timerId)return
const t=I.O.GetRelateMousePiont(this.relateTran)
let e=t.x-this.m_startX
e<0&&(e=-e)
let i=!0
if(this.m_isShowPanel){t.y-this.m_startY>200&&(i=!1)}else(t.y>200||e>600)&&(i=!1)
i!=this.m_isSpeaker&&(this.m_isSpeaker=i,this.SetState())}SetState(){this.voiceContainer.SetActive(this.m_isSpeaker),this.returnContainer.SetActive(!this.m_isSpeaker)}Clear(){
this.DelBgm(!1),u.C.Inst_get().ClearLoop(this.m_recordTimerId),this.RemoveOnVoiceCallback(),u.C.Inst_get().ClearInterval(this.m_timerId),this.m_timerId=0,
u.C.Inst_get().ClearInterval(this.m_volumeTimerId),this.m_volumeTimerId=0}Destroy(){this.m_speakers=null,this.relateTran=null,this.m_privateModel=null}})||s},4603:(t,e,i)=>{
var s,n,l=i(18998),a=i(83908),o=i(86133),r=i(97461),h=i(65829),d=i(60130),c=i(98885),_=i(79534),u=i(87923),I=i(37322),m=i(845),g=i(44744),p=i(63563),C=i(26753),S=i(98407),f=i(27047),T=i(14143),y=i(13612),A=i(19381)
l._decorator.ccclass("SingleWorldChatCell")((n=class t extends((0,a.zB)()){constructor(...t){super(...t),this.maxW1=null,this.labelMaxW=null,this.voiceContentMaxW=null,
this.labelGap=null,this.voiceLabelLeftGap=null,this.titleW=null,this.m_info=null,this.m_isOtherShow=null,this.bubbleId=null,this.m_pressComp=null,this.m_tween=null,
this.m_useTween=null,this.tag=null}InitView(){super.InitView(),this.maxW1=410,this.labelMaxW=380,this.voiceContentMaxW=0,this.labelGap=20,this.voiceLabelLeftGap=17,this.titleW=0}
SetData(e){this.m_info=e,this.m_isOtherShow=!1,this.bubbleId=this.m_info.smChat.sender.nowBubbleId,this.channelLabel.textSet(this.m_info.GetChannelName()),this.m_isOtherShow=!0,
-1==this.m_info.smChat.sender.job?this.nameLabel.textSet(""):this.m_info.isSelfChat_get()?this.m_info.smChat.sender.gmLevel>0?this.nameLabel.textSet((0,
o.T)("[962424][GM][-]我:")):this.nameLabel.textSet((0,
o.T)("我:")):this.m_info.smChat.sender.gmLevel>0?this.nameLabel.textSet(`[962424][GM][-]${this.m_info.smChat.sender.name}:`):this.nameLabel.textSet(`${this.m_info.smChat.sender.name}:`)
const[i,s]=this.m_info.GetMedelIcon()
null!=i?(this.medelsp.node.SetActive(!0),this.medelsp.spriteNameSet(i),this.medellabel.textSet(s)):this.medelsp.node.SetActive(!1),this.InitHandlerMgr(),
this.m_handlerMgr.AddClickEvent(this.nameLabel,this.CreateDelegate(this.NameClickHandler)),r.i.Inst.AddEventHandler("PlayVoiceSuccess",this.CreateDelegate(this.PlayVoiceSuccess)),
r.i.Inst.AddEventHandler("StopPlayVoice",this.CreateDelegate(this.StopPlayVoice)),
this.m_info.isVoice_get()?this.m_handlerMgr.AddClickEvent(this.labelbg,this.CreateDelegate(this.OnBgClick)):(this.m_pressComp=new I.c(this.chatLabel.node,this.CreateDelegate(this.OnTxtClick),this.CreateDelegate(this.LongPressHandler)),
this.m_pressComp.AddEvent(),this.m_pressComp.frameHandler=this.CreateDelegate(this.FrameHandler),this.m_pressComp.moveEndHandler=this.CreateDelegate(this.MoveEndHandler)),
this.m_tween=!1
const n=p.m.Inst().GetVipHeadSpriteName(this.m_info.smChat.sender.vipLevel)
u.l.IsEmptyStr(n)?this.vipsp.node.SetActive(!1):(this.vipsp.node.SetActive(!0),this.vipsp.spriteNameSet(n))
const l=this.CalcSize(),a=this.titleW/t.SingleEmptyTxtW
let h=" "
for(let t=0;t<=a-1;t++)h+=" "
let d=this.m_info.speakTxt_get()
d=h+d,this.SetContent(d,l)}NameClickHandler(t,e){g.Z.Inst().Open(this.m_info.smChat.sender.objId,null,null,null)}OnBgClick(t,e){this.PlayVoice()}LongPressHandler(t,e){if(e){
let t=null
f.w.Inst_get().IsPanelOpen()||(t=d.O.GetRelateMousePiont(C.d.Inst_get().controller.ChatMainPanel_get().node.transform)),t.x-=50,t.y+=20
let e=c.M.ReplaceSlow(this.m_info.smChat.content,y.k.USE_POS,"")
e=c.M.Replace(e,A.$.USE_VOC,""),C.d.Inst_get().controller.OpenCopyTip(t,e),_.P.Recyle(t)}else this.m_useTween.PlayReverse(),this.m_tween=!1}OnTxtClick(){
S.C.OnTxtClick(this.chatLabel,this.m_info,this.tag),this.m_tween=!1}SetVoiceData(){this.redPoint.SetActive(!this.m_info.isVoiceHeard),
this.m_info.smChat.sender.IsMe()&&this.redPoint.SetActive(!1),h.X.Inst_get().IsVoicePlaying(this.m_info.smChat.voiceUrl)?this.SetPlayState(!0):this.SetPlayState(!1),
this.timeLabel.textSet(`${c.M.IntToString(this.m_info.smChat.recordTime)}s`),
!this.m_info.isVoiceHeard&&m.g.Inst_get().IsAutoPlayVoice(this.m_info.smChat.channelId)&&(this.m_info.smChat.sender.IsMe()||(C.d.Inst_get().model.autoPlayVoiceDict.LuaDic_ContainsKey(this.m_info.smChat.voiceUrl)||(C.d.Inst_get().model.autoPlayVoiceQueue.Add(this.m_info.smChat.voiceUrl),
C.d.Inst_get().model.autoPlayVoiceDict.LuaDic_AddOrSetItem(this.m_info.smChat.voiceUrl,this.m_info)),
h.X.Inst_get().IsAnyVoicePlaying()||0!=C.d.Inst_get().model.waitToPlayVoiceMapId||this.m_info.smChat.channelId==T.L.PRIVATE||this.PlayVoice()))
let t=40*this.m_info.smChat.recordTime
return t<160?t=160:t>this.voiceContentMaxW&&(t=this.voiceContentMaxW),t+this.labelGap}PlayVoiceSuccess(t){
this.m_info.isVoice_get()&&this.m_info.smChat.voiceUrl==t&&null!=this.voiceicon&&this.SetPlayState(!0)}StopPlayVoice(t){
this.m_info.isVoice_get()&&this.m_info.smChat.voiceUrl==t&&null!=this.voiceicon&&this.SetPlayState(!1)}FrameHandler(){this.m_tween||(this.m_tween=!0)}MoveEndHandler(){
this.m_tween=!1}SetContent(t,e){this.labelMaxW=this.maxW1-e,this.voiceContentMaxW=this.labelMaxW-this.labelGap,
this.m_info.isVoice_get()?this.SetVoiceContent():(this.labelbg.node.SetActive(!1),this.chatfaceLabel.node.SetActive(!0),this.chatfaceLabel.textSet(t))}SetVoiceContent(){
this.labelbg.node.SetActive(!0)
const t=this.m_info.smChat.voiceContent
this.chatfaceLabel.node.SetActive(!1),this.chatLabel.widthSet(this.labelMaxW)
const e=this.SetVoiceData()
if(this.labelbg.widthSet(e),this.voicelabel.widthSet(this.voiceContentMaxW),u.l.IsEmptyStr(t)?this.voicelabel.node.SetActive(!1):(this.voicelabel.node.SetActive(!0),
this.voicelabel.textSet(t)),this.chatfaceLabel.textSet(""),!this.m_info.isVoiceHeard){const t=this.redPoint.transform.GetLocalPosition()
t.x=this.labelbg.width(),this.redPoint.transform.SetLocalPosition(t),_.P.Recyle(t)}}PlayVoice(){this.m_info.isVoiceHeard=!0,
h.X.Inst_get().PlayVoiceByUrl(this.m_info.smChat.voiceUrl),this.redPoint.SetActive(!1)}SetPlayState(t){this.voiceIcon.SetActive(!t),this.voiceEffect.SetActive(t),
1==t&&this.redPoint.SetActive(!1)}CalcSize(){const e=this.chatLabel.node.transform.GetLocalPosition()
let i=0
if(e.y=-9,this.m_info.isVoice_get()&&(e.y=-45,i=33),this.voiceicon.SetActive(this.m_info.isVoice_get()),this.m_info.isVoice_get()){const t=this.SetVoiceData()
this.labelbg.widthSet(t)}const s=this.nameLabel.node.transform.GetLocalPosition()
let n=t.InitOffsetW
if(this.vipsp.node.active&&(n+=30),null!=this.m_info.GetMedelIcon()){const t=this.medelsp.node.transform.GetLocalPosition()
t.x=n+37,this.medelsp.node.transform.SetLocalPosition(t),n+=74}return this.nameLabel.node.transform.SetLocalPositionXYZ(n,s.y,s.z),s.x=n+this.nameLabel.width(),this.titleW=s.x-48,
s.x+=2,this.labelbg.node.transform.SetLocalPosition(s),s.x-t.InitOffsetW}Clear(){super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}},n.SingleEmptyTxtW=5.5,
n.InitOffsetW=48,s=n))},50277:(t,e,i)=>{var s,n=i(18998),l=i(83908),a=i(48933)
n._decorator.ccclass("WorldChatCell")(s=class extends((0,l.zB)()){constructor(...t){super(...t),this.m_info=null}InitView(){super.InitView()}SetData(t){this.m_info=t
let e=null
this.otherWidget.SetData(t),this.otherWidget.node.SetActive(!0),this.selfWidget.node.SetActive(!1),e=this.otherWidget.node.transform.contentSize,a.I.cal2Vec0.Set(e.x,e.y),
this.dragwidget.width=a.I.cal2Vec0.x,this.dragwidget.height=a.I.cal2Vec0.y,a.I.cal2Vec0.Set(e.x/2,-e.y/2)}Clear(){super.Clear(),this.selfWidget.Clear(),this.otherWidget.Clear()}
Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}})},20099:(t,e,i)=>{i.d(e,{V:()=>o})
var s=i(86133),n=i(66788),l=i(98130),a=i(85602)
class o{SendData_Get(){return new a.Z}static SetIsSendToBSD(t){}static ContainLastClicks(t,e,...i){return!1}static GetLastClick(t,e,i,s,n,l){return 0}CutLastClick(){
const t=l.GF.MTimer_get()
for(;o.s_lastClickId.Count()>60;){const[e,i]=[o.s_lastClickId[0],o.s_lastClickId[1]]
if(!(t-i>18e4))break
o.s_lastClickId.RemoveRange(0,2)}}static SendClickData(t){}static SendLogData(t){}static SendRecvData(t){}static OnResponse(t){"1"==t?n.Y.Log((0,
s.T)("Send ClickStream OK")):n.Y.Log((0,s.T)("Send ClickStream Fail"))}}o.s_lastClickId=new a.Z,o.s_curClickListType=0},88911:(t,e,i)=>{i.d(e,{p:()=>s})
class s{}s.Step_1=1,s.Step_100000=1e5,s.Step_110000=11e4,s.Step_110001=110001,s.Step_110100=110100,s.Step_110200=110200,s.Step_110300=110300,s.Step_119999=119999,
s.Step_120000=12e4,s.Step_120001=120001,s.Step_120100=120100,s.Step_120200=120200,s.Step_120300=120300,s.Step_129999=129999,s.Step_130000=13e4,s.Step_130001=130001,
s.Step_139999=139999,s.Step_140000=14e4,s.Step_140001=140001,s.Step_149999=149999,s.Step_150000=15e4,s.Step_150001=150001,s.Step_150100=150100,s.Step_150200=150200,
s.Step_150300=150300,s.Step_159999=159999,s.Step_160000=16e4,s.Step_160001=160001,s.Step_160100=160100,s.Step_160200=160200,s.Step_160300=160300,s.Step_169999=169999,
s.Step_170000=17e4,s.Step_170001=170001,s.Step_170100=170100,s.Step_170200=170200,s.Step_179999=179999,s.Step_180000=18e4,s.Step_180001=180001,s.Step_189999=189999,
s.Step_190000=19e4,s.Step_190001=190001,s.Step_190100=190100,s.Step_190200=190200,s.Step_190300=190300,s.Step_199999=199999,s.Step_200000=2e5,s.Step_200001=200001,
s.Step_200100=200100,s.Step_200200=200200,s.Step_209999=209999,s.Step_210000=21e4,s.Step_210001=210001,s.Step_219999=219999,s.Step_1120000=112e4,s.Step_1120001=1120001,
s.Step_1129999=1129999,s.Step_1130000=113e4,s.Step_1130001=1130001,s.Step_1139999=1139999,s.Step_1140000=114e4,s.Step_1140001=1140001,s.Step_1140100=1140100,s.Step_1140200=1140200,
s.Step_1140300=1140300,s.Step_1149999=1149999,s.Step_1150000=115e4,s.Step_1150001=1150001,s.Step_1150100=1150100,s.Step_1150200=1150200,s.Step_1150999=1159999,
s.Step_1151301=1160001,s.Step_1151100=1160100,s.Step_1151200=1160200,s.Step_1151999=1169999,s.Step_260000=26e4,s.Step_260001=260001,s.Step_260002=260002,s.Step_260003=260003,
s.Step_260010=260010,s.Step_260020=260020,s.Step_260100=260100,s.Step_260101=260101,s.Step_261001=261001,s.Step_261010=261010,s.Step_261020=261020,s.Step_262000=262e3,
s.Step_262900=262900,s.Step_262910=262910,s.Step_262920=262920,s.Step_263000=263e3,s.Step_263010=263010,s.Step_263020=263020,s.Step_263030=263030,s.Step_264000=264e3,
s.Step_267000=267e3,s.Step_267100=267100,s.Step_267200=267200,s.Step_267300=267300,s.Step_267400=267400,s.Step_311000=311e3,s.Step_312000=312e3,s.Step_312100=312100,
s.Step_312200=312200,s.Step_312300=312300,s.Step_312400=312400,s.Step_312500=312500,s.Step_312600=312600,s.Step_313000=313e3,s.Step_314000=314e3,s.Step_315000=315e3,
s.Step_4101010=4101010,s.Step_4101020=4101020,s.Step_4101030=4101030,s.Step_4101040=4101040,s.Step_4101070=4101070,s.Step_4101080=4101080,s.Step_4101100=4101100,
s.Step_4101110=4101110,s.Step_4101112=4101112,s.Step_4101114=4101114,s.Step_4101116=4101116,s.Step_4101130=4101130,s.Step_4101140=4101140,s.Step_4101150=4101150,
s.Step_4101152=4101152,s.Step_4101154=4101154,s.Step_4101156=4101156,s.Step_4101160=4101160,s.Step_4101170=4101170,s.Step_4101180=4101180,s.Step_4101190=4101190,
s.Step_4101200=4101200,s.Step_4101202=4101202,s.Step_4101204=4101204,s.Step_4101206=4101206,s.Step_4101210=4101210,s.Step_4101220=4101220,s.Step_4101222=4101222,
s.Step_4101224=4101224,s.Step_4101226=4101226,s.Step_4102010=4102010,s.Step_4102020=4102020,s.Step_4102030=4102030,s.Step_4102040=4102040,s.Step_4102050=4102050,
s.Step_4102060=4102060,s.Step_4102070=4102070,s.Step_4102080=4102080,s.Step_4102090=4102090,s.Step_4102100=4102100,s.Step_4102110=4102110,s.Step_4102120=4102120,
s.Step_4102130=4102130,s.Step_4102140=4102140,s.Step_4102150=4102150,s.Step_4102160=4102160,s.Step_4103010=4103010,s.Step_4103020=4103020,s.Step_4103030=4103030,
s.Step_4103040=4103040,s.Step_4103060=4103060,s.Step_4103070=4103070,s.Step_4103080=4103080,s.Step_4103090=4103090,s.Step_4103100=4103100,s.Step_4103110=4103110,
s.Step_4103120=4103120,s.Step_4104010=4104010,s.Step_4104020=4104020,s.Step_4104030=4104030,s.Step_4104040=4104040,s.Step_4104060=4104060,s.Step_4104070=4104070,
s.Step_4104080=4104080,s.Step_4104090=4104090,s.Step_4104091=4104091,s.Step_4104100=4104100,s.Step_4105030=4105030,s.Step_4105040=4105040,s.Step_4105050=4105050,
s.Step_4105060=4105060,s.Step_4105080=4105080,s.Step_4105090=4105090,s.Step_4105100=4105100,s.Step_4105110=4105110,s.Step_4105150=4105150,s.Step_4105180=4105180,
s.Step_4105181=4105181,s.Step_4105182=4105182,s.Step_4105190=4105190,s.Step_4106020=4106020,s.Step_4106030=4106030,s.Step_4106050=4106050,s.Step_4106060=4106060,
s.Step_4106070=4106070,s.Step_4106072=4106072,s.Step_4106080=4106080,s.Step_4106110=4106110,s.Step_4106130=4106130,s.Step_4106140=4106140,s.Step_4107010=4107010,
s.Step_4107020=4107020,s.Step_4107030=4107030,s.Step_4107040=4107040,s.Step_4107050=4107050,s.Step_4107060=4107060,s.Step_4107062=4107062,s.Step_4107064=4107064,
s.Step_4107066=4107066,s.Step_4107080=4107080,s.Step_4107090=4107090,s.Step_41107100=4110710,s.Step_4107110=4107110,s.Step_4107120=4107120,s.Step_4107130=4107130,
s.Step_4107140=4107140,s.Step_4107150=4107150,s.Step_4107160=4107160,s.Step_4107170=4107170,s.Step_4109010=4109010,s.Step_4030000=403e4,s.Step_4030001=4030001,
s.Step_4030002=4030002,s.Step_4030003=4030003,s.Step_4030004=4030004,s.Step_4030005=4030005,s.Step_4030006=4030006,s.Step_4030007=4030007,s.Step_4030008=4030008,
s.Step_4030009=4030009,s.Step_4031000=4031e3,s.Step_4031001=4031001,s.Step_4031002=4031002,s.Step_4031003=4031003,s.Step_4031004=4031004,s.Step_4031005=4031005,
s.Step_4031006=4031006,s.Step_4031007=4031007,s.Step_4031008=4031008,s.Step_4031009=4031009,s.Step_4032000=4032e3,s.Step_4032001=4032001,s.Step_4032002=4032002,
s.Step_4032003=4032003,s.Step_4032004=4032004,s.Step_4032005=4032005,s.Step_4032006=4032006,s.Step_4032007=4032007,s.Step_4032008=4032008,s.Step_4032009=4032009},84308:(t,e,i)=>{
i.d(e,{J:()=>_})
var s=i(93984),n=i(38836),l=i(86133),a=i(66788),o=i(35128),r=i(55360),h=i(98130),d=i(85602),c=i(38962)
class _{constructor(){this.gathermap=null,this.gatherGroupList=null,this.gatherGroupList=new c.X
const t=r.Y.Inst.GetOrCreateCsv(s.h.eCollect)
this.gathermap=t.GetCsvMap(),this.parse()}static Inst(){return null==_._inst&&(_._inst=new _),_._inst}parse(){this.gatherGroupList.Clear()
for(const[t,e]of(0,n.V5)(this.gathermap)){let t=this.gatherGroupList.LuaDic_GetItem(e.groupId)
null==t&&(t=new d.Z),t.Contains(e.id)||t.Add(e.id),this.gatherGroupList.LuaDic_AddOrSetItem(e.groupId,t)}}getItemById(t){let e=null
return e=this.gathermap.LuaDic_GetItem(t),null==e&&a.Y.LogError((0,l.T)("GATHERABLERESOURCE表找不到Id为")+(t+(0,l.T)("的项"))),e}GetItemByGroupId(t){const e=this.GetItemListByGroupId(t)
if(null!=e&&e.Count()>0){const t=h.GF.INT(o.p.RandomMax(e.Count()))
return this.getItemById(e[t])}return a.Y.LogError((0,l.T)("GATHERABLERESOURCE表找不到GroupId为")+(t+(0,l.T)("的项"))),null}GetItemListByGroupId(t){
return this.gatherGroupList.LuaDic_ContainsKey(t)?this.gatherGroupList[t]:null}}_._inst=null},54415:(t,e,i)=>{i.d(e,{k:()=>it})
var s,n,l,a,o,r,h,d,c=i(42292),_=i(71409),u=i(17409),I=i(77546),m=i(32076),g=i(86133),p=i(98800),C=i(57121),S=i(96098),f=i(91238),T=i(89549),y=i(62265),A=i(73206),D=i(20738),E=i(97461),v=i(68662),w=i(38935),R=i(62370),P=i(95417),O=i(5924),L=i(56937),B=i(18202),b=i(5494),M=i(52726),G=i(98789),H=i(98885),N=i(38962),k=i(79534),U=i(92679),V=i(31922),x=i(85770),F=i(72800),q=i(50571),Y=i(42896),W=i(92415),j=i(32691),Z=i(82949),X=i(40312),K=i(92916),$=i(67632),J=i(47963),z=i(79878),Q=i(98580),tt=i(84308)
function et(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let it=(s=(0,_.GH)(W.k.SM_OpenTreasure),n=(0,_.GH)(W.k.SM_GatherableInfo),l=(0,_.GH)(W.k.SM_GatherStart),a=(0,
_.GH)(W.k.SM_GatherEnd),o=(0,_.GH)(W.k.SM_GatherBreak),r=(0,_.GH)(W.k.SM_GatherStatus),d=class t{constructor(){this.m_collectUI=null,this.m_collectBtn=null,this.m_ch=null,
this.isopen=!1,this.m_collectId=null,this._istaskcollect=!1,this.isOpenCollectBtn=!1,this.canopen=!0,this.intervalId=-1,this.gatherFlyId=0,this.isAsuramWarReturn=!1,
this.currentCollectId=null,this.m_collectGameId=null,this.ICompleteCollectId=null,this.gatherid=0,this._degf_AutoCollect=null,this._degf_CallDestory=null,
this._degf_SM_GatherBreakHandler=null,this._degf_SM_GatherEndHandler=null,this._degf_SM_GatherStartHandler=null,this._degf_SM_GatherStatusHandler=null,
this._degf_SM_GatherableInfoHandler=null,this._degf_SM_OpenTreasureHandler=null,this._degf_ShowlComplete=null,this._degf_resetcanopen=null,this.autoCollect=null,
this.autoCollectId=null,this._degf_AutoCollect=()=>this.AutoCollect(),this._degf_CallDestory=()=>this.CallDestory(),
this._degf_SM_GatherBreakHandler=t=>this.SM_GatherBreakHandler(t),this._degf_SM_GatherEndHandler=t=>this.SM_GatherEndHandler(t),
this._degf_SM_GatherStartHandler=t=>this.SM_GatherStartHandler(t),this._degf_SM_GatherStatusHandler=t=>this.SM_GatherStatusHandler(t),
this._degf_SM_GatherableInfoHandler=t=>this.SM_GatherableInfoHandler(t),this._degf_SM_OpenTreasureHandler=t=>this.SM_OpenTreasureHandler(t),
this._degf_ShowlComplete=t=>this.ShowlComplete(t),this._degf_resetcanopen=()=>this.resetcanopen()}static Inst_get(){return null==t._Inst&&(t._Inst=new t),t._Inst}
registeProtocol(){}openOrClose(t){if(this.m_ch=t,this.isopen=!0,P.U.Inst.ResetStateAndCloseSceneTouchView(),x.a.Inst_get().curCopyType!=F.S.RedFortress){if(null!=t){
const e=t.Cfg_get()
e&&e.id==X.B.BaoZang_BaoXiang_ID&&Z.R.Inst_get().OpenCollctRewardIcon()}if(null==this.m_collectUI||0==this.m_collectUI.isShow_get()){const t=new L.v
t.positionType=G.$.eCustom,t.layerType=M.F.DefaultUI,(0,u.Yp)(b.I.eCollectSliderUI,t,this._degf_ShowlComplete),null!=this.m_collectUI&&this.loaded(this.m_collectUI)
}else this.loaded(this.m_collectUI)
this.closeCollectHandBtnUI()}}CallDestory(){B.g.DestroyUIObj(this.m_collectUI),this.m_collectUI=null}ShowlComplete(t){return this.m_collectUI||(this.m_collectUI=(0,
u.Y)(b.I.eCollectSliderUI)),this.m_collectUI.startGather(this.m_ch),this.m_collectUI.refreshStartGather(this.m_ch),this.m_collectUI}closeCollectSliderUI(){this.gatherFlyId=0,
null!=this.m_collectUI&&this.isopen&&((0,u.sR)(b.I.eCollectSliderUI),this.m_collectUI=null,E.i.Inst.RaiseEvent(U.g.COLLECT_SLIDER_UPDATE,0)),this.isopen=!1}SwitchToPk(){
null!=this.m_collectUI&&this.m_collectUI.node.activeInHierarchy&&this.m_collectUI.SwitchToPk()}SwitchToNormal(){
null!=this.m_collectUI&&this.m_collectUI.node.activeInHierarchy&&this.m_collectUI.SwitchToNormal()}loaded(t){this.m_collectUI=t,
null!=this.m_collectUI&&this.m_collectUI.startGather(this.m_ch)}OpenCollectBtnForBox(t){}openCollectBtn(t,e,i){if(null==e&&(e=!1),null==i&&(i=!1),
this.m_collectGameId==t.GetGameId()&&this.autoCollect||(this.autoCollect=i),i||this.canopen||e){
if(null!=t.Cfg_get()&&$.n.Inst_get().IsEmptyAutoGotoCollect(t.Cfg_get().id))return this.autoCollect=!1,p.Y.Inst.CurTarget_get()==t&&this.closeCollectHandBtnUI(),!1
e&&(this.canopen=!1,-1!=this.intervalId&&O.C.Inst_get().ClearInterval(this.intervalId),this.intervalId=O.C.Inst_get().SetInterval(this._degf_resetcanopen,1e3,1)),
this._istaskcollect=e,null!=this.m_collectBtn&&this.isOpenCollectBtn||this.isopen?(this.autoCollect||e&&!this.isopen)&&(this.isOpenCollectBtn=!0,this.m_collectId=t,
this.m_collectGameId=t.GetGameId(),this.m_collectBtn.currentCollectId=this.m_collectId,this.m_collectBtn.InitShow()):(this.isOpenCollectBtn=!0,this.m_collectId=t,
this.m_collectGameId=t.GetGameId(),P.U.Inst.ResetStateAndCloseSceneTouchView(),null!=this.m_collectBtn&&(this.m_collectBtn.currentCollectId=this.m_collectId,
this.m_collectBtn.InitShow()))}}resetcanopen(){this.canopen=!0,this.intervalId=-1}CallHandBtnDestory(){B.g.DestroyUIObj(this.m_collectBtn),this.m_collectBtn=null}
closeCollectHandBtnUI(){null!=this.m_collectBtn&&this.isOpenCollectBtn&&(this.isOpenCollectBtn=!1,this.m_collectBtn.node.SetActive(!1),this.m_collectBtn.Clear())}IsShowCollect(){
return this.isOpenCollectBtn}CM_GatherStartReq(e,i,s=null){if(t.Inst_get().autoCollect=!1,this.currentCollectId&&this.currentCollectId.Equal(e))return
null==s&&(s=!0),s&&p.Y.Inst.PrimaryRole_get().StopPathing(),j.C.Inst_get().SendAllRoleHorseDressOrOff(!1)
const n=new Y.D
n.objId=e,n.gatherId=i,n.playerId=p.Y.Inst.PrimaryRoleInfo_get().Id_get(),w.C.Inst.F_SendMsg(n)}CM_GatherBreakReq(){t.Inst_get().autoCollect=!1
const e=new q.E
w.C.Inst.F_SendMsg(e)}CM_BoxLevelupReq(){}SM_OpenTreasureHandler(t){const e=p.Y.Inst.getCollectById(t.objectId)
null!=e&&e.ChangeToOpen()}TestOpenBox(){const t=p.Y.CollectDic
for(const[e,i]of Vpairs(t))i.ChangeToOpen()}SM_GatherableInfoHandler(t){const e=t
p.Y.Inst.CreateCollect(e)
p.Y.Inst.PrimaryRole_get().CurrentMachineState_get()!=T.k.Gather?(v.D.IsDebugCollect()&&I.s.Info("SM_GatherableInfoHandler timer is start"),E.i.Inst.RaiseEvent(U.g.ADD_COLLECT),
O.C.Inst_get().SetInterval(this._degf_AutoCollect,300,1)):v.D.IsDebugCollect()&&I.s.Info("SM_GatherableInfoHandler state is Gather")}AutoCollect(){
const t=J.c.Inst_get().CanCollection(),e=p.Y.Inst.PrimaryRole_get().CurrentMachineState_get()
if(v.D.IsDebugCollect()&&t&&T.k.Gather,t&&e!=T.k.Gather){v.D.IsDebugCollect()
const t=J.c.Inst_get().autoTask_get()
null!=t&&t.status_get()==Q.B.ACCEPTED&&z.Y.GetLinkInfo(t),J.c.Inst_get().AutoTask()}}FakeGatherStartHandler(t){this.SM_GatherStartHandler(t)}SM_GatherStartHandler(e){
const i=e,s=p.Y.Inst.getRoleById(i.playerId),n=p.Y.Inst.getCollectById(i.objId),l=C.M.Inst.getDropById(i.objId)
s.isPrimary&&(this.currentCollectId=i.objId)
let a=0,o=0
if(null!=n&&null!=n.Cfg_get()&&""!=n.Cfg_get().effect){const t=H.M.Split(n.Cfg_get().effect,H.M.s_CCD_CHAR_DOT)
let e=0
for(;e<t.count;){const i=H.M.Split(t[e],R.o.s_Arr_UNDER_LINE),s=H.M.String2Int(i[0]),n=H.M.String2Int(i[1])
1==s&&(a=n),2==s&&(o=n),e+=1}}if(s.isPrimary)null!=n&&(n.m_endTime=i.codeTime,n.m_collectingPlayers=i.collectingPlayers,n.startGather(),
n.Cfg_get().showBar?this.openOrClose(n):this.closeCollectHandBtnUI()),null!=l&&(l.m_endTime=i.codeTime,l.m_collectingPlayers=i.collectingPlayers,l.startGather(),
l.Cfg_get().showBar?this.openOrClose(l):this.closeCollectHandBtnUI())
else{const t=k.P.zero_get()
null!=n&&(n.GetCurPos(t),s.rotateTo(t),s.ChangeToGather(n.Cfg_get().action)),null!=l&&(l.GetCurPos(t),s.rotateTo(t),s.ChangeToGather(l.Cfg_get().action)),k.P.Recyle(t)}
const r=k.P.zero_get()
if(0!=a&&null!=s){const e=s.GetPos()
t.rolegatheridDic.LuaDic_ContainsKey(s.objId)||(this.gatherid=A.X.Inst.PlayElement(a,s.GetHandle(),0,e,r),t.rolegatheridDic.LuaDic_AddOrSetItem(s.objId,this.gatherid))}
if(0!=o&&null!=n){const e=n.GetPos()
t.collectgatheridDic.LuaDic_ContainsKey(n.objId)||(this.gatherid=A.X.Inst.PlayElement(o,n.GetHandle(),0,e,r),t.collectgatheridDic.LuaDic_AddOrSetItem(n.objId,this.gatherid))}
if(0!=o&&null!=l){const e=l.GetPos()
t.collectgatheridDic.LuaDic_ContainsKey(l.objId)||(this.gatherid=A.X.Inst.PlayElement(o,l.GetHandle(),0,e,r),t.collectgatheridDic.LuaDic_AddOrSetItem(l.objId,this.gatherid))}
k.P.Recyle(r)}SM_GatherEndHandler(e){v.D.IsDebugCollect()&&I.s.Info("SM_GatherEndHandler..."),this.isAsuramWarReturn=!1
const i=e,s=p.Y.Inst.getRoleById(i.playerId),n=p.Y.Inst.getCollectById(i.objId),l=C.M.Inst.getDropById(i.objId)
if(null==s)return void(v.D.IsDebugCollect()&&I.s.Info("SM_GatherEndHandler role is nil"))
if(s.isPrimary){
if(this.currentCollectId=null,this.gatherFlyId>0||null!=n&&(n.Cfg_get().flyId>0||20009007==n.Cfg_get().id))return 0==this.gatherFlyId&&(null!=n&&n.Cfg_get().flyId>0&&(this.gatherFlyId=n.Cfg_get().flyId),
null!=n&&20009007==n.Cfg_get().id&&(this.isAsuramWarReturn=!0)),
!this.isAsuramWarReturn||s.Terraintype_get()!=V.z.TerrainTypeDragonTower&&s.Terraintype_get()!=V.z.TerrainTypeSafe?S.B.Inst.OpenTransportMask(S.B.TYPE_FLY,this.gatherFlyId):s.ChangeToStand(!0),
this.closeCollectSliderUI(),void(v.D.IsDebugCollect()&&I.s.Info((0,g.T)("SM_GatherEndHandler 攻城战龙塔区域不能回城")))
null!=n&&n.gatherBreak(),null!=l&&l.gatherBreak(),this.closeCollectSliderUI(),v.D.IsDebugCollect()&&I.s.Info("SM_GatherEndHandler timer is start"),
O.C.Inst_get().SetInterval(this._degf_AutoCollect,300,1)}let a=0
a=t.rolegatheridDic.LuaDic_GetItem(s.objId),null==a&&(a=0),0!=a&&(D.h.Instance_get().DeleteElementCombine(a),t.rolegatheridDic.LuaDic_Remove(s.objId))
let o=0
o=t.collectgatheridDic.LuaDic_GetItem(i.objId),null==o&&(o=0),0!=o&&(D.h.Instance_get().DeleteElementCombine(o),t.collectgatheridDic.LuaDic_Remove(n.objId)),
i.playerId.Equal(p.Y.Inst.PrimaryRole_get().objId)&&(E.i.Inst.RaiseEvent(U.g.REMOVE_COLLECT,n),K.q.Inst_get().CheckGuideCollect())}SM_GatherBreakHandler(t){
const e=t,i=p.Y.Inst.getRoleById(e.playerId)
null!=i&&this.DoBreakCollect(i,e.objId)}DoBreakCollect(e,i){const s=p.Y.Inst.getCollectById(i)
e.isPrimary&&(null!=s&&s.gatherBreak(),this.closeCollectSliderUI(),null!=this.m_collectUI&&this.m_collectUI.gatherBreak()),
e.isPrimary&&e.CurrentMachineState_get()!=T.k.Gather||e.ChangeToStand(!0)
const n=t.rolegatheridDic.LuaDic_GetItem(e.objId)
null!=n&&(D.h.Instance_get().DeleteElementCombine(n),t.rolegatheridDic.LuaDic_Remove(e.objId))
let l=0
l=t.collectgatheridDic.LuaDic_GetItem(i),null==l&&(l=0),0!=l&&(D.h.Instance_get().DeleteElementCombine(l),t.collectgatheridDic.LuaDic_Remove(i)),
e.isPrimary&&(this.currentCollectId=null)}SM_GatherStatusHandler(t){const e=t,i=p.Y.Inst.getCollectById(e.objId)
null!=i&&(i.m_state=e.state,i.updateState())}ChangeCollectCharacter(t){null!=this.m_collectUI&&(this.m_collectUI.collect_set(t),this.m_collectUI.SetData())}
isGatheringUnupgradedBox(){return!1}isGatheringUpgradedBox(){return!1}AutoGotoCollect(t){this.autoCollectId=t,this.autoCollectId>0&&this.CheckCollect()}CheckCollect(){
const e=tt.J.Inst().getItemById(this.autoCollectId)
let i=null
if(i=p.Y.Inst.GetTargetCollectByCfgId(e.id),null!=i){const e=i.GetPos()
if(k.P.Distance(p.Y.Inst.PrimaryRole_get().GetPos(),e)<=i.Cfg_get().distance)p.Y.Inst.PrimaryRole_get().rotateTo(e),t.Inst_get().openCollectBtn(i,null,!0)
else{null!=this.m_collectId&&this.closeCollectHandBtnUI()
const t=p.Y.Inst.PrimaryRole_get(),s=y.jq.pathFindPoint(e,t.GetPos(),i.Cfg_get().distance-1)
p.Y.Inst.PrimaryRole_get().goByPositions(s,(0,m.v)(this.FindTargetCallBack,this))}}else{const t=new k.P(e.x,0,e.y)
p.Y.Inst.PrimaryRole_get().gotoPoint(t,f.m.Collect,(0,m.v)(this.FindTargetCallBack,this),null,e.mapId)}}FindTargetCallBack(){
const e=tt.J.Inst().getItemById(this.autoCollectId),i=p.Y.Inst.GetTargetCollectByCfgId(e.id)
if(null!=i){const e=i.GetPos()
k.P.Distance(p.Y.Inst.PrimaryRole_get().GetPos(),e)<=i.Cfg_get().distance&&(p.Y.Inst.PrimaryRole_get().rotateTo(e),p.Y.Inst.CurTarget_set(i),t.Inst_get().openCollectBtn(i,null,!0))
}}},d._Inst=null,d.rolegatheridDic=new N.X,d.collectgatheridDic=new N.X,et(h=d,"Inst_get",[c.n],Object.getOwnPropertyDescriptor(h,"Inst_get"),h),
et(h.prototype,"SM_OpenTreasureHandler",[s],Object.getOwnPropertyDescriptor(h.prototype,"SM_OpenTreasureHandler"),h.prototype),
et(h.prototype,"SM_GatherableInfoHandler",[n],Object.getOwnPropertyDescriptor(h.prototype,"SM_GatherableInfoHandler"),h.prototype),
et(h.prototype,"FakeGatherStartHandler",[l],Object.getOwnPropertyDescriptor(h.prototype,"FakeGatherStartHandler"),h.prototype),
et(h.prototype,"SM_GatherEndHandler",[a],Object.getOwnPropertyDescriptor(h.prototype,"SM_GatherEndHandler"),h.prototype),
et(h.prototype,"SM_GatherBreakHandler",[o],Object.getOwnPropertyDescriptor(h.prototype,"SM_GatherBreakHandler"),h.prototype),
et(h.prototype,"SM_GatherStatusHandler",[r],Object.getOwnPropertyDescriptor(h.prototype,"SM_GatherStatusHandler"),h.prototype),h)},62342:(t,e,i)=>{
var s,n=i(18998),l=i(83908),a=i(5924),o=i(61911),r=i(85682),h=i(98885),d=i(87923),c=i(68637),_=i(82949),u=i(40312),I=i(66988),m=i(65180),g=i(17783),p=i(75517),C=i(54415)
const{ccclass:S}=n._decorator
S("CollectBtn")(s=class extends((0,l.pA)(o.f)()){constructor(...t){super(...t),this.currentCollectId=null,this._lefttimeintervalId=-1,this._lefttime=0,this._totaltime=0,
this._degf_StartGather=null,this._degf_TimeChange=null,this.delayTimerId=null}_initBinder(){super._initBinder(),this._degf_StartGather=(t,e)=>this.StartGather(t,e),
this._degf_TimeChange=()=>this.TimeChange()}InitShow(){
C.k.Inst_get()._istaskcollect&&null!=this.currentCollectId&&null!=this.currentCollectId.Cfg_get()&&this.currentCollectId.Cfg_get().autoGatherTime<=0?(this.node.SetActive(!1),
C.k.Inst_get().autoCollect=!1):this.node.SetActive(!0),this.ClearDelayCollect(),
null!=this.des&&null!=this.currentCollectId&&null!=this.currentCollectId.Cfg_get()&&(this.des.textSet(this.currentCollectId.Cfg_get().showDesc),
this.hand.spriteNameSet(this.currentCollectId.Cfg_get().gatherTouchIcon)),-1!=this._lefttimeintervalId&&a.C.Inst_get().ClearInterval(this._lefttimeintervalId),
this._lefttimeintervalId=-1,this.moveimg.node.SetActive(!1),C.k.Inst_get()._istaskcollect&&(this.showTime(),C.k.Inst_get()._istaskcollect=!1),this.ani.ResetToBeginning(),
this.ani.Play(),null!=this.currentCollectId.Cfg_get()&&this.currentCollectId.Cfg_get().flyId>0&&(C.k.Inst_get().gatherFlyId=this.currentCollectId.Cfg_get().flyId),
this.node.active&&140==this.currentCollectId.Cfg_get().groupId?u.B.Inst_get().isAutoCollectJigsaw&&_.R.Inst_get().GetColloctId()==this.currentCollectId.Cfg_get().id&&(this.delayTimerId=a.C.Inst_get().SetInterval(this.CreateDelegate(this.DelayCollect),500,1)):C.k.Inst_get().autoCollect&&this.StartGather()
}ClearDelayCollect(){null!=this.delayTimerId&&(a.C.Inst_get().ClearInterval(this.delayTimerId),this.delayTimerId=null)}DelayCollect(){this.delayTimerId=null,
this.node.active&&null!=this.currentCollectId&&null!=this.currentCollectId.Cfg_get()&&140==this.currentCollectId.Cfg_get().groupId&&u.B.Inst_get().isAutoCollectJigsaw&&this.StartGather()
}AddLis(){this.hand.node.on(n.NodeEventType.TOUCH_END,this._degf_StartGather),this.RegGuide()}RemoveLis(){this.UnRegGuide()}RegGuide(){
null!=this.currentCollectId&&c.c.Inst.RegGameObject(r.D.UI_MAIN_COLLECT_BTN,this.hand.node,this.currentCollectId.Cfg_get().id)}UnRegGuide(){
null!=this.currentCollectId&&c.c.Inst.UnRegGameObject(r.D.UI_MAIN_COLLECT_BTN,this.currentCollectId.Cfg_get().id)}CheckGuide(){
if(null!=this.currentCollectId)if(I.G.Inst_get().IsInMazeCopy()){const t=m.e.Inst_get().currentRoomId
d.l.CheckBtnClickTrigger(r.D.MAZE_COPY_TIME_SPACE_ROOM_COLLECT,t)}else d.l.CheckBtnClickTrigger(r.D.UI_MAIN_COLLECT_BTN,this.currentCollectId.Cfg_get().id)}StartGather(t,e){
this.CheckGuide(),p.W.inst_get().CloseView(),this.SetGatherId(),C.k.Inst_get().CM_GatherStartReq(this.currentCollectId.GetGameId(),this.currentCollectId.Cfg_get().id),
a.C.Inst_get().ClearInterval(this._lefttimeintervalId),this._lefttimeintervalId=-1,
null!=t&&this.node.active&&140==this.currentCollectId.Cfg_get().groupId&&u.B.Inst_get().SetAutoCollectJigsaw(!0)}SetGatherId(){
0==C.k.Inst_get().gatherFlyId&&g.L.Inst_get().model.SetNearGaterFlyId()}Update(){}showTime(){let t=this.currentCollectId.Cfg_get().autoGatherTime
if(t/=1e3,t>0){this._lefttime=t,this._totaltime=t,this._lefttimeintervalId<0&&(this._lefttimeintervalId=a.C.Inst_get().SetInterval(this._degf_TimeChange,100))
h.M.ToFixed(t,1)
this.des.textSet(this.currentCollectId.Cfg_get().showDesc)}else if(a.C.Inst_get().ClearInterval(this._lefttimeintervalId),this._lefttimeintervalId=-1,
null!=this.currentCollectId&&null!=this.currentCollectId.Cfg_get()){
if(this.node.active&&140==this.currentCollectId.Cfg_get().groupId&&u.B.Inst_get().isAutoCollectJigsaw&&_.R.Inst_get().GetColloctId()!=this.currentCollectId.Cfg_get().id)return
this.SetGatherId(),C.k.Inst_get().CM_GatherStartReq(this.currentCollectId.GetGameId(),this.currentCollectId.Cfg_get().id)}}TimeChange(){if(this._lefttime-=.1,
this._lefttime<.1)a.C.Inst_get().ClearInterval(this._lefttimeintervalId),this._lefttimeintervalId=-1,
null!=this.currentCollectId&&null!=this.currentCollectId.Cfg_get()&&(this.SetGatherId(),
C.k.Inst_get().CM_GatherStartReq(this.currentCollectId.GetGameId(),this.currentCollectId.Cfg_get().id))
else if(null!=this.currentCollectId&&null!=this.currentCollectId.Cfg_get()){h.M.ToFixed(this._lefttime,1)
this.des.textSet(this.currentCollectId.Cfg_get().showDesc)}}Clear(){C.k.Inst_get().autoCollect=!1,a.C.Inst_get().ClearInterval(this._lefttimeintervalId),this._lefttimeintervalId=-1
}Destroy(){this.Clear(),this.RemoveLis()}OnAddToScene(){this.AddLis()}})},80459:(t,e,i)=>{i.d(e,{o:()=>L})
var s=i(82815),n=i(32076),l=i(98800),a=i(65227),o=i(84581),r=i(58935),h=i(89549),d=i(55039),c=i(21697),_=i(45404),u=i(94954),I=i(35907),m=i(31546),g=i(17733),p=i(73206),C=i(97461),S=i(36241),f=i(82737),T=i(19833),y=i(18202),A=i(98130),D=i(98885),E=i(16175),v=i(79534),w=i(92679),R=i(27122),P=i(22625),O=i(26363)
class L extends c.s{constructor(){super(),this.m_bloodsheet=null,this.maze_head=null,this.uiloaded=!1,this.m_state=!1,this.m_endTime=null,this.m_collectingPlayers=0,
this.isUpdateBox=!1,this.m_cfg=null,this.m_isAddSigeEvent=!1,this.m_siegeEffName=null,this.m_siegeState=-1,this.effectHandleId=0,this.displayObj=null,this.m_isopen=!1,
this._degf_InitBloodSheet=null,this._degf_OnInit=null,this._degf_UpdateFixHandler=null,this.pox=0,this.poz=0,this._degf_InitBloodSheet=t=>this.InitBloodSheet(t),
this._degf_OnInit=t=>this.OnInit(t),this._degf_UpdateFixHandler=t=>this.UpdateFixHandler(t)}Cfg_get(){return this.m_cfg}Cfg_set(t){this.m_cfg=t}InitByCfg(t){const e=new m.O
e._fDir=45*t.degree,e._displayID=t.resourceId,e._vPos.Set(t.x,t.y),e.shiledType=f.g.DT_NPC_COLLECT_TRANSPORT
const i=_.n.Instance_get().CreateDisplayObject(e,this.objId,-1,T.X.COLLECTCHARACTER,this._degf_OnInit,null,this._degf_OnMoveEnd)
return this.MainRole_set(new I.M(i)),this.m_worldtype=e._world,this.roletype=o.s.gatherable,this.Cfg_set(t),this.MainRole_get().IsInited()&&this.OnInit(this.MainRole_get()),
this.InitStateMachine(),this.SetSiegeFixState(),this.updateOpenState(),this.HideSomeCollectModel(),!0}InitByInfo(t,e){if(null==e)return!1
this.objId=t.objId,this.m_state=t.state,this.m_isopen=t.open
const i=new m.O
if(i._fDir=d.W.transHeading2UnityDir(t.heading),i._displayID=e.resourceId,0==i._displayID)return!1
i._vPos.Set(t.x,t.y),i.shiledType=f.g.DT_NPC_COLLECT_TRANSPORT
const s=_.n.Instance_get().CreateDisplayObject(i,this.objId,-1,T.X.COLLECTCHARACTER,this._degf_OnInit,null,this._degf_OnMoveEnd)
return this.MainRole_set(new I.M(s)),this.m_worldtype=i._world,this.roletype=o.s.gatherable,this.Cfg_set(e),this.MainRole_get().IsInited()&&this.OnInit(this.MainRole_get()),
this.SetDefaultWeightIndex(g.I.COLLECT_OR_DROP),this.InitStateMachine(),this.SetSiegeFixState(),this.updateOpenState(),this.HideSomeCollectModel(),!0}HideSomeCollectModel(){
if(this.m_cfg&&140==this.m_cfg.groupId){const t=this.MainRole_get()
t&&t.SetShow(!1)}}SetSiegeFixState(){}UpdateFixHandler(t){this.DetachEff()}DetachEff(){
null!=this.m_siegeEffName&&null!=this.MainRole_get()&&(this.MainRole_get().DetachObject(A.GF.INT(E.d.eEffect3),this.m_siegeEffName),this.m_siegeEffName=null)}SetSelected(t){
super.SetSelected(t)}isRedFortressBox_get(){return!1}AddEffect(){let t=this.Cfg_get().gatherableEffect
if(t>1){2==t?t=103021e3:3==t?t=103021100:4==t&&(t=103021200)
let e=null
const i=this.MainRole_get().GetDisplayHandle(),s=v.P.zero_get()
this.MainRole_get().GetPosValue(s)
const n=v.P.zero_get()
e=p.X.Inst.ConstuctSkillLocation(t,i,0,s,n),v.P.Recyle(s),v.P.Recyle(n),e._ImportElementCombine=!0,e._bOffsetStage=!0,e._eOffsetWorldType=A.GF.INT(this.Worldtype_get()),
this.effectHandleId=p.X.Inst.PlaySkillLocation(e,null)}}GetGameId(){return this.objId}LoadBloodSheet(){
null!=this.m_cfg.canSeeConditions&&-1!=D.M.IndexOf(this.m_cfg.canSeeConditions,"AT_SPACE_MAZE_GATHER_EVENT")?null==this.maze_head?y.g.LoadOne("ui/characterui/ui_maze_collect_head",this._degf_InitBloodSheet):this.maze_head.SetData(this):(this.m_bloodsheet=r.W.inst.GetHead(r.W.COLLECT_HEAD),
null!=this.m_bloodsheet?this.m_bloodsheet.collect_set(this):y.g.LoadOne(r.W.COLLECT_HEAD,this._degf_InitBloodSheet))}InitBloodSheet(t){t[0]
null!=this.m_cfg.canSeeConditions&&-1!=D.M.IndexOf(this.m_cfg.canSeeConditions,"AT_SPACE_MAZE_GATHER_EVENT")?(this.maze_head=t.getOrAddComponent(P.F),
__$LaunchLogicBridge._initBinderObject(this.maze_head),this.maze_head.Reshow(),this.maze_head.SetData(this)):(this.m_bloodsheet=t.getOrAddComponent(O._),
__$LaunchLogicBridge._initBinderObject(this.m_bloodsheet),this.m_bloodsheet.Reshow(),this.m_bloodsheet.collect_set(this)),this.updateState()}updateState(){
null!=this.m_bloodsheet&&this.m_bloodsheet.updateState(this.m_state),this.MainRole_get().SetAttachVisible(A.GF.INT(E.d.eBuff),"pre_eff_caiji01",this.m_state),
this.MainRole_get().SetAttachVisible(A.GF.INT(E.d.eBuff),"pre_eff_caiji02",this.m_state),this.MainRole_get().SetAttachVisible(A.GF.INT(E.d.eBuff),"pre_eff_caiji03",this.m_state),
this.MainRole_get().SetAttachVisible(A.GF.INT(E.d.eEffect),"pre_eff_caiji01",this.m_state),
this.MainRole_get().SetAttachVisible(A.GF.INT(E.d.eEffect),"pre_eff_caiji02",this.m_state),
this.MainRole_get().SetAttachVisible(A.GF.INT(E.d.eEffect),"pre_eff_caiji03",this.m_state)}UpdateTime(t,e){null!=this.Statemachine_get()&&this.Statemachine_get().AniUpdate()}
updateOpenState(){this.m_isopen&&this.MainRole_get().PassEvent(a.o.dead.toString())}ChangeToOpen(){this.m_isopen=!0,this.MainRole_get().PassEvent(a.o.open.toString(),(0,
n.v)(this.updateOpenState,this))}PrepareRender(){null!=this.m_bloodsheet&&this.m_bloodsheet.updateRenderVisible()&&this.m_bloodsheet.UpdateUIPos(),
null!=this.maze_head&&this.maze_head.updateRenderVisible()&&this.maze_head.UpdateUIPos()}startGather(){const t=v.P.zero_get()
this.GetCurPos(t),l.Y.Inst.PrimaryRole_get().rotateTo(t),v.P.Recyle(t),l.Y.Inst.PrimaryRole_get().ChangeToGather(this.Cfg_get().action),
S._.getInst().GetHangType()!=s.R.copyAi&&S._.getInst().endHang()}gatherBreak(){
l.Y.Inst.PrimaryRole_get().CurrentMachineState_get()==h.k.Gather&&l.Y.Inst.PrimaryRole_get().ChangeToStand(!0)}isAttackedable(){return!1}OnInit(t){null!=t&&(super.OnInit(t),
this.displayObj=t,null!=this.MainRole_get()&&(this.MainRole_get().SetAttachVisible(A.GF.INT(E.d.eBuff),"pre_eff_caiji01",this.m_state),
this.MainRole_get().SetAttachVisible(A.GF.INT(E.d.eBuff),"pre_eff_caiji02",this.m_state),this.MainRole_get().SetAttachVisible(A.GF.INT(E.d.eBuff),"pre_eff_caiji03",this.m_state),
this.MainRole_get().SetAttachVisible(A.GF.INT(E.d.eEffect),"pre_eff_caiji01",this.m_state),
this.MainRole_get().SetAttachVisible(A.GF.INT(E.d.eEffect),"pre_eff_caiji02",this.m_state),
this.MainRole_get().SetAttachVisible(A.GF.INT(E.d.eEffect),"pre_eff_caiji03",this.m_state)),this.AddEffect(),this.uiloaded||(this.uiloaded=!0,this.LoadBloodSheet()),
this.SetDefaultWeightIndex(g.I.COLLECT_OR_DROP),this.SetPickWeightForTask(),this.SetSiegeFixState(),this.updateOpenState(),this.HideSomeCollectModel())}destroyBloodSheet(){
null!=this.maze_head&&(this.maze_head.Clear(),this.maze_head.Destroy(),this.maze_head=null),null!=this.m_bloodsheet?(r.W.inst.RecyleHeadUI(this.m_bloodsheet,r.W.COLLECT_HEAD),
this.m_bloodsheet=null):y.g.Unload(this._degf_InitBloodSheet)}Destroy(){this.ExcuteDestory(),R.Q.Inst().Recycle("CollectCharacter",this)}OnTimerAction(){this.ExcuteDestory()}
SetPickWeightForTask(){const t=u.e.inst_get().taskGatherId
null!=this.Cfg_get()&&(this.Cfg_get().id==t?this.SetNowWeightIndex(g.I.TASK_TARGET):this.ResetWeight())}ExcuteDestory(){
0!=this.effectHandleId&&p.X.Inst.DeleteElement(this.effectHandleId),this.m_isAddSigeEvent&&C.i.Inst.RemoveEventHandler(w.g.SIEGE_STATUESTATE_UPDATE,this._degf_UpdateFixHandler),
this.DetachEff(),this.effectHandleId=0,this.m_cfg=null,this.displayObj=null,this.destroyBloodSheet(),super.Destroy()}}},26363:(t,e,i)=>{i.d(e,{_:()=>o})
var s=i(83908),n=i(68404),l=i(73206),a=i(85751)
class o extends((0,s.pA)(n.B)()){constructor(...t){super(...t),this.m_collect=null,this.jpkqHandleId=0,this.kcjHandleId=0}collect_get(){return this.m_collect}collect_set(t){
this.m_collect=t,this.UpdateName(),this.UpdateUIPos(),this._setHeadRenderByCharacter(t)}InitView(){super.InitView(),this.OnAddToScene()}UpdateName(){
if(null!=this.collect_get()&&null!=this.collect_get().Cfg_get())if(this.collect_get().m_state){this.label.textSet(this.GetNameText())
const t=this.collect_get().Cfg_get().gatherableEffect
this.label.SetColor(a.u.getColorByQuality(t)),this.PlayCjAnimByType()}else this.label.textSet(""),this.ClearCjAnim()}PlayCjAnimByType(){this.ClearCjAnim()
this.collect_get().Cfg_get().id
const t=this.collect_get().GetPos()
t.y=t.y}GetHandle(){return null==this.collect_get().MainRole_get()?0:this.collect_get().MainRole_get().GetDisplayHandle()}ClearCjAnim(){
0!=this.jpkqHandleId&&(l.X.Inst.DeleteElement(this.jpkqHandleId),this.jpkqHandleId=0),0!=this.kcjHandleId&&(l.X.Inst.DeleteElement(this.kcjHandleId),this.kcjHandleId=0)}
updateState(t){if(null!=this.collect_get()&&this.collect_get().m_state){this.label.textSet(this.GetNameText())
const t=this.collect_get().Cfg_get().gatherableEffect
this.label.SetColor(a.u.getColorByQuality(t))}else this.label.textSet("")}GetNameText(){const t=this.collect_get().Cfg_get().name
return this.collect_get().Cfg_get().showName?t:""}UpdateUIPos(){this._SetPosByCharacter(this.m_collect)}Clear(){super.Clear(),this.ClearCjAnim()}Destory(){super.Destory()}}
o.jpkqElementId=103026e3,o.kcjElementId=103025900},89029:(t,e,i)=>{
var s,n=i(6847),l=i(83908),a=i(46282),o=i(97461),r=i(68662),h=i(5924),d=i(5494),c=i(98885),_=i(85602),u=i(79534),I=i(92679),m=i(87923),g=i(88010);(0,
n.s_)(d.I.eCollectSliderUI,a.Z.ui_collect_slider_head).register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),this.m_collect=null,this.sentence=null,
this._lefttimeintervalId=-1,this._totaltime=0,this.preTimer=0,this.curTimer=0,this.passTimer=0,this._degf_TimeChange=null}_initBinder(){super._initBinder(),
this._degf_TimeChange=()=>this.TimeChange()}collect_get(){return this.m_collect}collect_set(t){this.m_collect=t}InitView(){
null!=this.collect_get()&&this.refreshStartGather(this.collect_get())}AddLis(){}RemoveLis(){}SetData(){this.hand.spriteNameSet(this.m_collect.Cfg_get().gatherTouchIcon)}
UpdateName(){}UpdateBloodSheetValue(){}startGather(t){this.collect_set(t)}refreshStartGather(t){if(!this.node)return
if(this.collect_set(t),this.AddLis(),this.SetData(),this.sentence=m.l.SubstituteEx(this.collect_get().Cfg_get().desc,new _.Z([c.M.IntToString(this.collect_get().m_collectingPlayers)])),
null!=this.collect_get()&&(this.UpdateName(),this.UpdateBloodSheetValue()),null==this.collect_get().m_endTime)return
this.ClearIntervals()
const e=this.collect_get().m_endTime.ToNum()
this._totaltime=e,this._totaltime>0?(this.preTimer=r.D.serverMSTime_get(),this._lefttimeintervalId<0&&(this._lefttimeintervalId=h.C.Inst_get().SetInterval(this._degf_TimeChange,50)),
this.TimeChange()):this.gatherBreak(),g.F.Inst_get().isInPkUI?this.SwitchToPk():this.SwitchToNormal()
const i=this.collect_get().Cfg_get()
if(i&&140==i.groupId){const[t,e,i]=this.namelabel.node.transform.GetLocalPositionXYZ()
this.icon.node.SetActive(!0),this.icon.node.transform.SetLocalPositionXYZ(t-this.namelabel.width()/2-10,-222,0)}else this.icon.node.SetActive(!1)
o.i.Inst.RaiseEvent(I.g.COLLECT_SLIDER_UPDATE,1)}SwitchToPk(){const t=new u.P(0,-388,0)
this.gather.transform.SetLocalPosition(t),u.P.Recyle(t)}SwitchToNormal(){const t=new u.P(0,-400,0)
this.gather.transform.SetLocalPosition(t),u.P.Recyle(t)}TimeChange(){if(this.curTimer=r.D.serverMSTime_get(),this.passTimer=this.curTimer-this.preTimer,
this.passTimer>=this._totaltime)this.ClearIntervals()
else{const t=this.passTimer/this._totaltime
this.slidercontent.node.transform.width=376*t
const e=c.M.ToFixed((this._totaltime-this.passTimer)/1e3,1)
this.namelabel.textSet(`${this.sentence}(${e})...`)}}ClearIntervals(){m.l.ClearIntervals(this._lefttimeintervalId),this._lefttimeintervalId=-1}gatherBreak(){
null!=this.namelabel&&(null!=this.collect_get()&&null!=this.collect_get().Cfg_get()&&this.namelabel.textSet(this.sentence),this.ClearIntervals())}Update(){}Clear(){
this.RemoveLis(),this.ClearIntervals()}Destroy(){}OnAddToScene(){}})},65772:(t,e,i)=>{i.d(e,{Q:()=>d})
var s,n,l=i(42292),a=i(17409),o=i(56937),r=i(18202),h=i(5494)
let d=(0,l.wT)("GameSys.CommTextTipsControl")((n=class t{static get inst(){return null==t._inst&&(t._inst=new t),t._inst}constructor(){this.view=null,this.infoVo=null,
this._degf_CallMainPanelDestory=null,this._degf_mainShowHandler=null,this._degf_CallMainPanelDestory=()=>this.CallMainPanelDestory(),
this._degf_mainShowHandler=t=>this.mainShowHandler(t)}static Inst_get(){return null==t.inst&&(t._inst=new t),t.inst}Open(t){this.infoVo=t
const e=new o.v
e.layerType=t.layer,e.viewClass=null,(0,a.Yp)(h.I.eCommTextTipPanel,e)}CallMainPanelDestory(){r.g.DestroyUIObj(this.view),this.view=null}mainShowHandler(t){return this.view}
Close(){(0,a.sR)(h.I.eCommTextTipPanel)}},n._inst=null,s=n))||s},8802:(t,e,i)=>{
var s,n=i(18998),l=i(6847),a=i(83908),o=i(46282),r=i(38836),h=i(62370),d=i(5924),c=i(5494),_=i(98885),u=i(85602),I=i(79534),m=i(65249),g=i(59756),p=i(870),C=i(87923),S=i(75439),f=i(7098),T=i(65772)
n._decorator.ccclass("CommTextTipsView")(s=(0,l.s_)(c.I.eCommTextTipPanel,o.Z.ui_tip_commtipsview).layerTip().register()(s=class extends((0,a.Ri)()){constructor(...t){super(...t),
this.infoVo=null,this._degf_OnItemRefreshFun=null,this._degf_Close=null,this._degf_OnReposition=null,this._degf_OnReposition2=null,this.intervalId=null,this.intervalId2=null,
this.TransformPos=null}_initBinder(){this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),this._degf_Close=t=>this.clickClose(),this._degf_OnReposition=()=>this.OnReposition(),
this._degf_OnReposition2=()=>this.OnReposition2()}InitView(){super.InitView(),this.tipBg.node.SetActive(!1),
this.tipsTable.SetInitInfo("ui_tip_captiontipsitem",this.CreateDelegate(this.OnItemRefreshFun),g.q),
this.tipsTable2.SetInitInfo("ui_tip_captiontipsitem2",this.CreateDelegate(this.OnItemRefreshFun2),p._),this.tipsTable.OnReposition_set(this._degf_OnReposition),
this.tipsTable2.OnReposition_set(this._degf_OnReposition),this.intervalId=0,this.intervalId2=0,this.TransformPos=this.node.transform.GetLocalPosition()}OnItemRefreshFun(t){
return new g.q(this.node)}OnItemRefreshFun2(t){return new p._(this.node)}OnAddToScene(){null!=T.Q.Inst_get().infoVo&&(this.infoVo=T.Q.Inst_get().infoVo),this.AddLis(),
this.SetData(this.infoVo),this.SetPos()}SetData(t){if(null!=t&&(this.infoVo=t),null==this.infoVo)return
const e=new u.Z
let i=null
if(null!=this.infoVo.infoId){i=f.A.Inst_get().GetContentById(this.infoVo.infoId),null==i&&(i=S.D.getInstance().GetStringValue(this.infoVo.infoId+""))
let t=0
for(;t<this.infoVo.replaceParams.Count();)i=_.M.Replace(i,_.M.s_LEFT_B_K_CHAR+(t+_.M.s_RIGHT_B_K_CHAR),this.infoVo.replaceParams[t]),t+=1
const s=_.M.Split(i,_.M.s_F_SLASH_DOT)
let n=null,l=0
for(;l<s.count;){n=_.M.Split(s[l],h.o.s_UNDER_CHAR)
const t=new m.o
n.Count()>1?("0"==n[0]?t.isPoint=!1:"1"==n[0]&&(t.isPoint=!0),n[1]=C.l.ReplaceAllAByB(n[1],"&","/"),t.content=n[1]):(n[0]=C.l.ReplaceAllAByB(n[0],"&","/"),t.content=n[0]),
0==t.labelWidth&&(t.labelWidth=this.infoVo.width-40),e.Add(t),l+=1}if(this.infoVo.addContents)for(const[t,i]of(0,
r.V5)(this.infoVo.addContents))0==i.labelWidth&&(i.labelWidth=this.infoVo.width-40),e.Add(i)}else for(const[t,i]of(0,
r.V5)(this.infoVo.contents))0==i.labelWidth&&(i.labelWidth=this.infoVo.width-40),e.Add(i)
this.infoVo.singlelinemode?(this.tipsTable.data_set(null),this.tipsTable2.data_set(e)):(this.tipsTable2.data_set(null),this.tipsTable.data_set(e))}SetPos(){
this.node.transform.SetLocalPosition(new I.P(1e4,0,0)),this.infoVo.position}SetBgSize(){this.node.SetActive(!0)
let t=null,e=0,i=0,s=0
if(this.infoVo.singlelinemode)for(const i in this.tipsTable2.node.children)this.tipsTable2.node.children[i].getChildByName("tipsDesc").getComponent(n.RichText).textWidth>e&&(e=this.tipsTable2.node.children[i].getChildByName("tipsDesc").getComponent(n.RichText).textWidth),
this.tipsTable2.node.children[i].y<s&&(s=this.tipsTable2.node.children[i].y),t=this.tipsTable2.node.children[i].transform.GetBoundsSize()
else for(const l in this.tipsTable.node.children)this.tipsTable.node.children[l].getChildByName("tipsDesc").getComponent(n.RichText).textWidth>e&&(e=this.tipsTable.node.children[l].getChildByName("tipsDesc").getComponent(n.RichText).textWidth),
this.tipsTable.node.children[l].transform.height=this.tipsTable.node.children[l].getChildByName("tipsDesc").getComponent(n.RichText).height()+10,
i+=this.tipsTable.node.children[l].transform.height,this.tipsTable.node.children[l].y<s&&(s=this.tipsTable.node.children[l].y),
t=this.tipsTable.node.children[l].transform.GetBoundsSize()
e=this.infoVo.width||e,this.infoVo.singlelinemode?this.tipsTable2.updateTableWidthAndHeight():this.tipsTable.updateTableWidthAndHeight()
let l=0,a=0
this.infoVo.singlelinemode?(l=this.tipsTable2.node.transform.width,a=this.tipsTable2.node.transform.height):(l=this.tipsTable.node.transform.width,
a=this.tipsTable.node.transform.height)
let o=this.TransformPos
null!=this.infoVo.position&&(o=this.infoVo.position.Clone()),1==this.infoVo.anchor?o.y+=a:2==this.infoVo.anchor?o.x-=l:3==this.infoVo.anchor&&(o.x-=l,o.y+=a),
this.node.transform.SetLocalPosition(o),
this.tipBg.node.SetActive(!0),this.infoVo.singlelinemode?this.tipBg.node.transform.setContentSize(l+40,a+40):(this.tipBg.node.transform.setContentSize(l+40,a+40),
this.SetBgSizeByInfoVo())}OnReposition(){this.intervalId>0&&d.C.Inst_get().ClearInterval(this.intervalId),this.tipsTable.Reposition(),
this.intervalId=d.C.Inst_get().SetFrameLoop(this.CreateDelegate(this.SetBgSize),2,1)}OnReposition2(){this.intervalId>0&&d.C.Inst_get().ClearInterval(this.intervalId),
this.intervalId=d.C.Inst_get().SetFrameLoop(this.CreateDelegate(this.SetBgSize),2,1)}clickClose(){T.Q.Inst_get().Close(),null!=this.infoVo.callback&&this.infoVo.callback()}
AddLis(){this.AddClickEvent(this.tipMask.node,this._degf_Close)}SetBgSizeByInfoVo(){this.infoVo.width=this.infoVo.width||400,
this.infoVo.width&&this.infoVo.width>10&&(this.tipBg.node.transform.width=this.infoVo.width),
this.infoVo.height&&this.infoVo.height>10&&(this.tipBg.node.transform.height=this.infoVo.height)}RemoveLis(){}Clear(){
this.intervalId>0&&d.C.Inst_get().ClearInterval(this.intervalId),this.intervalId2>0&&d.C.Inst_get().ClearInterval(this.intervalId2),this.RemoveLis(),this.tipsTable.Clear(),
super.Clear()}})||s)},8013:(t,e,i)=>{i.d(e,{u:()=>A})
var s,n,l=i(18998),a=i(6847),o=i(83908),r=i(46282),h=i(86133),d=i(6700),c=i(13687),_=i(41664),u=i(66788),I=i(61911),m=i(5494),g=i(2372),p=i(87923),C=i(85770),S=i(24524),f=i(93997),T=i(21334),y=i(88934)
let A=(0,a.s_)(m.I.eCopyEntrancePanel,r.Z.ui_ry_copyentrance_panel).register()((n=class t extends((0,o.pA)(I.f)()){constructor(...t){super(...t),this.progressFunId=0,
this.interval2=0,this.progressOffset=0,this.sliderTime=3e3,this.quickTime=150,this.progressUpValue=0,this.progressQuickUpValue=0,this.isLoadMap=!1,this.isLoadMapComplete=!1}
InitView(){super.InitView()
const t=l.sys.getSafeAreaRect()
let e=this.node.getChildByName("bgContainer")
e.position.set(-t.x/2,e.position.y,e.position.z),this.bg.widthSet(l.view.getVisibleSize().x+10),this.bg.heightSet(l.view.getVisibleSize().y+10)}Clear(){this.isLoadMapComplete=!1,
this.isLoadMap=!1,f.p.inst.mapLoadingType=3,this.ClearUIProgressFun(),this.ClearForceCloseTimer(),this.RemoveLis(),super.Clear()}Destroy(){super.Destroy()}AddLis(){}RemoveLis(){}
OnAddToScene(){if(this.eff1.node.SetActive(!1),this.eff2.node.SetActive(!1),f.p.inst.isStopShow)return void f.p.inst.CloseLoading()
const e=S.o.Inst().getItemById(C.a.Inst_get().currentCopyId)
null==e||p.l.IsEmptyStr(e.copyName)?this.name.textSet(f.p.inst.copyEnterNameSpStr):this.name.textSet(e.copyName),this.AddLis(),y.$.Inst().Close()
let i=T.p.Inst_get().GetMapById(c.b.Inst.currentMapId_get()).loadingTimee
i<0&&(i=0),this.sliderTime=.82*i,this.quickTime=.18*i,this.sliderTime>-1e-6&&this.sliderTime<1e-6?(this.progressUpValue=g.p.MAX_VALUE_get(),
this.progressQuickUpValue=this.progressUpValue):(this.progressUpValue=1/(this.sliderTime/t.sliderInterval),this.progressQuickUpValue=2*this.progressUpValue),this.PlayStartAni(),
this.ClearForceCloseTimer(),this.OnStart(),this.interval2=this.m_handlerMgr.SetInterval(this.CreateDelegate(this.ForceClosePorgress),1e4,1),_.j.Inst.PlayByDivision("EnterCopy")}
OnPlayEnd(){this.isLoadMap&&f.p.inst.CloseCopyPanel()}PlayStartAni(){this.eff1.node.SetActive(!0)}PlayEndAni(){
this.m_handlerMgr.SetFrameLoop(this.CreateDelegate(this.OnPlayEnd),50,1)}OnStart(){d.L.Instance_get().CloseRender(),f.p.inst.GotoShowHandler(),this.ClearUIProgressFun(),
this.FakeUIProgress(),this.progressFunId=this.m_handlerMgr.SetInterval(this.CreateDelegate(this.FakeUIProgress),t.sliderInterval)}ForceClosePorgress(){u.Y.LogWarning((0,
h.T)("当前要转场的地图：")+(c.b.Inst.currentMapId_get()+(0,h.T)("加载时间大于10秒，强行关闭加载界面"))),this.m_handlerMgr.SetFrameLoop(this.CreateDelegate(this.ProgressLoadCompelete),1,1),
this.LoadMapComplete(),this.isLoadMap=!0,this.progressOffset=1,this.ClearUIProgressFun(),this.interval2=0}FakeUIProgress(){this.isLoadMap||c.b.Inst.IsReady()?(this.isLoadMap=!0,
this.progressOffset+=this.progressQuickUpValue):(this.progressOffset+=this.progressUpValue,this.progressOffset>.98&&(this.progressOffset=.98)),
this.progressOffset>=1&&(this.m_handlerMgr.SetFrameLoop(this.CreateDelegate(this.ProgressLoadCompelete),1,1),this.LoadMapComplete(),this.progressOffset=1,this.ClearUIProgressFun(),
this.ClearForceCloseTimer())}ProgressLoadCompelete(){this.ClearUIProgressFun(),this.PlayEndAni(),_.j.Inst.PlayByDivision("EnterCopyEnd"),d.L.Instance_get().OpenRender()}
LoadMapComplete(){this.isLoadMapComplete||(this.isLoadMapComplete=!0)}ClearUIProgressFun(){
0!=this.progressFunId&&(this.progressFunId=this.m_handlerMgr.ClearInterval(this.progressFunId))}ClearForceCloseTimer(){
0!=this.interval2&&(this.interval2=this.m_handlerMgr.ClearInterval(this.interval2))}},n.sliderInterval=50,s=n))||s},86605:(t,e,i)=>{i.d(e,{z:()=>C})
var s=i(17409),n=i(98800),l=i(13687),a=i(16812),o=i(56937),r=i(31222),h=i(5494),d=i(52726),c=i(87923),_=i(37648),u=i(55492),I=i(24524),m=i(65550),g=i(21334),p=i(72800)
class C extends a.k{constructor(...t){super(...t),this.curCopyID=null,this.isOpening=null,this.fatherWidget=null,this.defaultCopyId=null}get view(){return(0,s.Y)(h.I.BelialPanel)}
get resultView(){return(0,s.Y)(h.I.BelialResultPanel)}static Inst_get(){return null==C.inst&&(C.inst=new C),C.inst}OpenView(t){
if(_.P.Inst_get().IsFunctionOpened(u.x.DEMON_SQUARE))if(this.SetDefaultCopyId(),0!=this.curCopyID)if(this.isOpening=!0,null!=this.view)this.view.OnAddToScene()
else{this.fatherWidget=t
const e=new o.v;(0,s.Yp)(h.I.BelialPanel,e,this.CreateDelegate(this.OnViewLoaded))}else m.y.inst.ClientSysStrMsg("当前副本无关卡满足解锁条件")
else c.l.SetFunctionTip(u.x.DEMON_SQUARE)}SetDefaultCopyId(){this.curCopyID=0
const t=p.S.Belial,e=n.Y.Inst.PrimaryRoleInfo_get().Level_get()
let i=null
i=I.o.Inst().getItemByTypeLevel(t,e)
const s=I.o.Inst().allBelielCopy
for(let t=0;t<=s.Count()-1;t++){const i=s[t]
if(0==i.isLvOrcheckpoint)e>=i.minLevelLimit&&e<=i.maxLevelLimit&&i.hierarchy>-1&&(this.curCopyID=i.id)
else if(1==i.isLvOrcheckpoint){const t=i.GetCheckPointCon()
null!=t&&t.CheckCondition()&&i.hierarchy>-1&&(this.curCopyID=i.id)}}this.defaultCopyId=this.curCopyID}GetCurrentCopyId(){return this.curCopyID}SetCurrentCopyId(t){
null!=t&&(this.curCopyID=t)}ClearView(){this.CloseView()}CloseView(){(0,s.sR)(h.I.BelialPanel),this.isOpening=!1}OnViewLoaded(t){this.view.OnAddToScene()}OpenResultView(){
if(null!=this.resultView&&this.resultView.isShow_get())return
const t=new o.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.layerType=d.F.Tip,(0,s.Yp)(h.I.BelialResultPanel,t,this.CreateDelegate(this.OnResultViewLoaded))}CloseResultView(){
r.N.inst.ClosePanel(this.resultView)}OnResultViewLoaded(t){return this.resultView,this.resultView}OnResultViewDestroy(){(0,s.sR)(h.I.BelialResultPanel)}SetEnterNum(t,e){
this.view&&this.view.SetEnterNum(t,e)}isInDemonPlazaBossMap_get(){const t=l.b.Inst.currentMapId_get(),e=g.p.Inst_get().GetMapById(t)
return null!=e&&"DEMONPLAZA"==e.controllerType}Reset(){this.curCopyID=0}}C.inst=null},54490:(t,e,i)=>{i.d(e,{s:()=>T})
var s,n=i(18998),l=i(83908),a=i(38045),o=i(98800),r=i(97461),h=i(9057),d=i(57834),c=i(85602),_=i(92679),u=i(87923),I=i(2457),m=i(24524),g=i(91690),p=i(21267),C=i(20296),S=i(65550),f=i(86605)
let T=n._decorator.ccclass("BelialItem")(s=class extends((0,l.pA)(h.x)()){constructor(...t){super(...t),this.data=null,this._degf_clickHandler=null,this.hasSelect=null}
_initBinder(){super._initBinder(),this._degf_clickHandler=(t,e)=>this.OnClickHandler(t,e)}InitView(){super.InitView()}AddLis(){
r.i.Inst.AddEventHandler(_.g.COPY_ITEM_SELECT_BELIAL,this.CreateDelegate(this.SelectHandler)),
p.u.Inst().AddEventHandler(g.Z.UpdateMapPassInfo,this.CreateDelegate(this.RefreshBtnTxt)),d.i.Get(this.noSelectBtn.node).RegistonClick(this._degf_clickHandler)}RemoveLis(){
r.i.Inst.RemoveEventHandler(_.g.COPY_ITEM_SELECT_BELIAL,this.CreateDelegate(this.SelectHandler)),
p.u.Inst().RemoveEventHandler(g.Z.UpdateMapPassInfo,this.CreateDelegate(this.RefreshBtnTxt)),d.i.Get(this.noSelectBtn.node).RemoveonClick(this._degf_clickHandler)}
OnClickHandler(t,e){if(t.target==this.noSelectBtn.node&&null!=this.data)if(0==this.data.isLvOrcheckpoint){const t=o.Y.Inst.PrimaryRoleInfo_get().Level_get()
t>=this.data.minLevelLimit&&t<=this.data.maxLevelLimit?(f.z.Inst_get().SetCurrentCopyId(this.data.id),this.RefreshPanel(),
r.i.Inst.RaiseEvent(_.g.COPY_ITEM_SELECT_BELIAL)):t>this.data.maxLevelLimit?S.y.inst.ClientSysMessage(11030503):S.y.inst.ClientSysMessage(11030502)
}else if(1==this.data.isLvOrcheckpoint){const t=this.data.GetCheckPointCon()
if(null!=t)if(t.CheckCondition())f.z.Inst_get().SetCurrentCopyId(this.data.id),this.RefreshPanel(),r.i.Inst.RaiseEvent(_.g.COPY_ITEM_SELECT_BELIAL)
else if(t.intType==I.u.ACC_CHECKPOINT){const e=t.intValue,i=new c.Z
i.Add((0,a.tw)(e)),S.y.inst.ClientSysMessage(100613,i)}else if(t.intType==I.u.PASS_CHECKPOINT){const e=t.value,i=C.C.GetInst().csvEx.GetItemById(e),s=i.mapName,n=i.name,l=new c.Z
l.Add(s+n),S.y.inst.ClientSysMessage(100614,l)}}}SelectHandler(){this.RefreshPanel()}SetData(t){this.data=t,null!=this.data&&(this.RefreshPanel(),this.AddLis())}RefreshBtnTxt(){
this.lock.SetActive(!1)
const t=o.Y.Inst.PrimaryRoleInfo_get().Level_get()
let e=`第${m.o.Inst().getBelialLayerById(this.data.id)}广场[-]`
const i=f.z.Inst_get().GetCurrentCopyId()
let s="",n=""
const l=this.data.GetCheckPointCon()
if(null!=l&&!l.CheckCondition()){if(l.intType==I.u.ACC_CHECKPOINT){const t=l.intValue
n=`[EFBE72]推关数:[FF0000]${p.u.Inst().totalPassNum}[-]/${t}[-]`}else if(l.intType==I.u.PASS_CHECKPOINT){const t=l.value,e=C.C.GetInst().csvEx.GetItemById(t)
n=`通关${e.mapName}${e.name}开启`}this.lock.SetActive(!0)}0!=i&&this.data.id==i?(e=`[FBEDB2]${e}[-]`,
this.data.minLevelLimit<=t&&(s=`[EFBE72](${this.data.minLevelLimit}-${this.data.maxLevelLimit}级)[-]`)):(e=`[AD8D5B]${e}[-]`,
this.data.minLevelLimit>t&&(s=`[EFBE72](${this.data.minLevelLimit}级开启)[-]`)),1==this.data.isLvOrcheckpoint?""!=n&&(e+=`\n${n}`):0==this.data.isLvOrcheckpoint&&""!=s&&(e+=`\n${s}`),
this.btnTxt.textSet(e)}RefreshPanel(){const t=f.z.Inst_get().GetCurrentCopyId()
0!=t&&this.data.id==t?(this.hasSelect=!0,this.hasSelectBtn.node.SetActive(!0),this.noSelectBtn.node.SetActive(!1)):(this.hasSelect=!1,this.hasSelectBtn.node.SetActive(!1),
this.noSelectBtn.node.SetActive(!0)),this.RefreshBtnTxt()}GetNumStr(t){const e=(0,a.tw)(t)
let i=""
for(let t=0;t<=e.length;t++)t>0&&(i+="十"),i+=u.l.GetChineseNum((0,a.aI)(e.substring(t,t)))
return i}Clear(){this.RemoveLis(),this.data=null}Destroy(){}})||s},8079:(t,e,i)=>{
var s,n=i(6847),l=i(83908),a=i(49655),o=i(46282),r=i(98800),h=i(97461),d=i(68662),c=i(13687),_=i(38935),u=i(62370),I=i(5924),m=i(57834),g=i(31222),p=i(5494),C=i(60130),S=i(98885),f=i(85602),T=i(21554),y=i(70850),A=i(63076),D=i(70093),E=i(75696),v=i(92679),w=i(1003),R=i(55661),P=i(13476),O=i(24524),L=i(33138),B=i(22365),b=i(34843),M=i(65550),G=i(35042),H=i(74657),N=i(21334),k=i(15771),U=i(41670),V=i(29839),x=i(85770),F=i(72800),q=i(86605),Y=i(54490)
;(0,n.s_)(a.o.BelialPanel,o.Z.ui_belialsquare_view).register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),this._degf_CloseClickHandler=null,
this._degf_EnterClickHandler=null,this._degf_IncreaseTimeClickHandler=null,this._degf_BagUpdateHandler=null,this._degf_TimeUpdateHandler=null,this._degf_Cooling=null,
this._degf_OnCreateRewardItem=null,this._degf_OnCreateLayerItem=null,this.curCopyID=null,this.intervalId=null,this.index=null,this.timerOne=null,this.itemModelId=null,
this.needItemNum=null,this.curCopyType=null,this.copyType=null,this.leftCount=null,this.showLeftNum=null,this.serverTimer=null,this.totalTime=null,this.residueTimer=null}
_initBinder(){super._initBinder(),this._degf_CloseClickHandler=()=>{this.CloseBtnHandler()},this._degf_EnterClickHandler=()=>{this.EnterBtnHandler()},
this._degf_IncreaseTimeClickHandler=()=>{this.IncreaseTimeBtnHandler()},this._degf_BagUpdateHandler=()=>{this.BagUpdateHandler()},this._degf_TimeUpdateHandler=()=>{
this.RefreshTime()},this._degf_Cooling=()=>this.Cooling(),this._degf_OnCreateRewardItem=t=>this.OnCreateRewardItem(t),this._degf_OnCreateLayerItem=t=>this.OnCreateLayerItem(t)}
InitView(){super.InitView(),this.layerGrid.SetInitInfo("ui_belialsquare_item",null,Y.s),this.grid.SetInitInfo("ui_baseitem",this._degf_OnCreateRewardItem)}OnAddToScene(){
this.node.SetActive(!0),C.O.SetAnchorPos(this.widget,!1,!0,-2),C.O.SetAnchorPos(this.leftUpWidget.node.transform,!0,!0,2),this.AddLis(),this.SetData(F.S.Belial),this.RefreshLayer()
}RefreshReward(){const t=O.o.Inst().getItemById(this.curCopyID),e=new f.Z,i=t.ShowRewardValue_get()
for(let t=0;t<=i.Count()-1;t++)if(null!=i[t]){const s=H.A.GetReward(i[t])
if(null!=s){const t=s.GetAllRewardList()
t.Count()>0&&e.AddRange(t)}}this.grid.data_set(e)}OnCreateRewardItem(t){return t[0].getCNode(E.j)}RefreshLayer(){const t=O.o.Inst().allBelielCopy
this.layerGrid.data_set(t),this.SetScrollBarLayer()}SetScrollBarLayer(){null!=this.intervalId&&I.C.Inst_get().ClearLoop(this.intervalId),
this.intervalId=I.C.Inst_get().SetFrameLoop(this.CreateDelegate(this.ScrollBarLayer),5,1)}ScrollBarLayer(){const t=this.GetPercent()
this.layerGrid.scrollTo(Math.ceil(t*this.layerGrid.array.length))}GetPercent(){const t=O.o.Inst().allBelielCopy,e=O.o.Inst().getBelialLayerById(this.curCopyID),i=t.Count()
return e<=1?0:e>i-1?1:(80*(e-2)+25)/(80*(i-1)-250+50+8)}OnCreateLayerItem(t){return t[0].getCNode(Y.s)}Clear(){this.node.SetActive(!1),this.RemoveLis(),this.grid.Clear(),
this.layerGrid.Clear(),this.index=0,I.C.Inst_get().ClearInterval(this.timerOne),this.timerOne=-1,null!=this.intervalId&&I.C.Inst_get().ClearInterval(this.intervalId),super.Clear()}
AddLis(){m.i.Get(this.enterBtn).RegistonClick(this._degf_EnterClickHandler),m.i.Get(this.closeBtn).RegistonClick(this.CreateDelegate(this.CloseBtnHandler)),
m.i.Get(this.increaseTimeBtn).RegistonClick(this._degf_IncreaseTimeClickHandler),h.i.Inst.AddEventHandler(v.g.BAG_UPDATE,this._degf_BagUpdateHandler),
h.i.Inst.AddEventHandler(v.g.COPYRECORD_UPDATE,this._degf_TimeUpdateHandler),h.i.Inst.AddEventHandler(v.g.COPY_ITEM_SELECT_BELIAL,this.CreateDelegate(this.SelectHandler))}
RemoveLis(){m.i.Get(this.enterBtn).RemoveonClick(this._degf_EnterClickHandler),m.i.Get(this.closeBtn).RemoveonClick(this.CreateDelegate(this.CloseBtnHandler)),
m.i.Get(this.increaseTimeBtn).RemoveonClick(this._degf_IncreaseTimeClickHandler),h.i.Inst.RemoveEventHandler(v.g.BAG_UPDATE,this._degf_BagUpdateHandler),
h.i.Inst.RemoveEventHandler(v.g.COPYRECORD_UPDATE,this._degf_TimeUpdateHandler),h.i.Inst.RemoveEventHandler(v.g.COPY_ITEM_SELECT_BELIAL,this.CreateDelegate(this.SelectHandler))}
CloseBtnHandler(){g.N.inst.CloseById(p.I.eDialoguePanel)}EnterBtnHandler(){
if(q.z.Inst_get().defaultCopyId!=q.z.Inst_get().curCopyID)return M.y.inst.ClientSysStrMsg("请前往挑战更高层数的副本"),q.z.Inst_get().SetCurrentCopyId(q.z.Inst_get().defaultCopyId),
void h.i.Inst.RaiseEvent(v.g.COPY_ITEM_SELECT_BELIAL)
this.CheckCanEnter()&&this.SendEnterCopy()}SelectHandler(){this.curCopyID=q.z.Inst_get().GetCurrentCopyId(),this.RefreshPanel(),this.SetScrollBarLayer()}IncreaseTimeBtnHandler(){
U.B.GetInst().AddTimes(this.curCopyID)}BagUpdateHandler(){if(null==this.itemModelId)return
const t=y.g.Inst_get().GetItemNum(this.itemModelId)
let e=null
e=new A.M(this.itemModelId),e.btnType=D.p.GetWay
let i=""
i=t>=this.needItemNum?`[CBCBCB]${t}[-]/${this.needItemNum}`:`[de2524]${t}[-]/${this.needItemNum}`,e.SpecialNumStr=i,this.consumeItem.SetData(e)}SetData(t){this.curCopyType=t,
this.curCopyID=q.z.Inst_get().GetCurrentCopyId(),this.RefreshPanel()}RefreshPanel(){this.node&&(this.RefreshItem(),this.RefreshTime(),this.SetTimer(),this.RefreshReward())}
RefreshTime(){V.p.inst.UpdateTimeAndCount(this.curCopyID)}SetEnterNum(t,e){const i=O.o.Inst().getItemById(this.curCopyID)
this.copyType=i.controllerType
const s=k.U.inst.model.GetCopyAddCount(this.copyType),n=b.v.Inst_get().GetCopyHasRecoveredCount(this.copyType)
this.leftCount=s-e
let l=0
const a=x.a.Inst_get().GetCopyRecByKey(this.copyType)
null!=a&&(l=a.todayItemTimes),this.showLeftNum=t+n+e+l,this.showLeftNum>0?this.remainTimeLbl.textSet(`今日剩余：[ffffff]${S.M.IntToString(this.showLeftNum)}[-]/${i.challengesTimes+n+e+l}`):(this.showLeftNum=0,
this.remainTimeLbl.textSet(`今日剩余：[ff0000]${S.M.IntToString(this.showLeftNum)}[-]/${i.challengesTimes+n+e+l}`))}RefreshItem(){let t=0,e=0
const i=O.o.Inst().getItemById(this.curCopyID).GetAttrValEX(w.U.Item)
if(S.M.Contains(i,":")){const s=S.M.Split(i,u.o.s_Arr_UNDER_COLON)
t=S.M.String2Int(s[0]),e=S.M.String2Int(s[1])}else t=S.M.String2Int(i),e=0
y.g.Inst_get().getItemresource(t)
this.needItemNum=e,this.itemModelId=t,this.consumeItem.SetIconSize(40,40),this.consumeItem.SetBgSize(44,44),this.BagUpdateHandler()}CheckCanEnter(){
if(r.Y.Inst.PrimaryRole_get().Isdead_get())return!1
const t=c.b.Inst.currentMapId_get()
if(N.p.Inst_get().GetMapById(t).senceType==R.S.CopyMap)return M.y.inst.ClientSysMessage(G.X.InCopy),!1
if(0==this.showLeftNum)return this.IncreaseTimeBtnHandler(),M.y.inst.ClientSysMessage(107006),!1
const e=O.o.Inst().getItemById(this.curCopyID)
return this.IsItem(e.controllerType)}IsItem(t){const e=x.a.Inst_get().copyRecordDic
let i=null
if(e.LuaDic_ContainsKey(t)){const s=e[t]
i=O.o.Inst().getItemById(s.lastCopyId)}null==i&&(i=O.o.Inst().getItemByCopyType(t))
const s=i.GetAttrValEX(w.U.Item),n=S.M.Split(s,u.o.s_Arr_UNDER_COLON),l=S.M.String2Int(n[0]),a=S.M.String2Int(n[1]),o=y.g.Inst_get().GetItemNum(l),r=a-o
if(0==o){const t=L.f.Inst().getItemById(l),e=new f.Z([t.name])
M.y.inst.ClientSysMessage(11030501,e)}return!(r>0)||(T.J.Inst_get().OpenTipViewById(l),!1)}SetTimer(){this.timerOne=-1
const t=x.a.Inst_get().copyCoolTimeDic,e=x.a.Inst_get().copyRecordDic
let i=null
if(e.LuaDic_ContainsKey(this.curCopyType)){const t=e[this.curCopyType]
i=O.o.Inst().getItemById(t.lastCopyId)}let s=!1
if(t.LuaDic_ContainsKey(this.curCopyType))if(null!=i){const e=r.Y.Inst.PrimaryRoleInfo_get().Level_get()
if(null==i.cdLevel&&(i.cdLevel=0),e>=i.cdLevel)s=!0
else{this.serverTimer=t[this.curCopyType],this.totalTime=i.waitTime
let e=d.D.serverMSTime_get()-this.serverTimer
e<0&&(e=0),e>this.totalTime?s=!0:this.residueTimer=this.totalTime-e}}else s=!0
else s=!0
s?this.TimeAnimClear():(this.cdLbl.textSet(Math.floor(this.residueTimer/1e3).toString()),this.cdLbl.node.SetActive(!0),this.enterBtn.SetActive(!1),
-1==this.timerOne&&(this.timerOne=I.C.Inst_get().SetInterval(this._degf_Cooling,200)))}Cooling(){const t=d.D.serverMSTime_get()-this.serverTimer
this.residueTimer=this.totalTime-t,t>this.totalTime&&(this.residueTimer=0,this.TimeAnimClear()),this.cdLbl.textSet(`冷却中(${Math.floor(this.residueTimer/1e3)})`)}TimeAnimClear(){
this.index=0,I.C.Inst_get().ClearInterval(this.timerOne),this.timerOne=-1,this.cdLbl.node.SetActive(!1),this.enterBtn.SetActive(!0)}SendEnterCopy(){const t=new B.w
t.copyId=this.curCopyID,P.E.Instance.HasCopyId(t.copyId,"SendEnterCopy2")&&(O.o.Inst().saveid=this.curCopyID,_.C.Inst.F_SendMsg(t))}})},40162:(t,e,i)=>{i.d(e,{v:()=>c})
var s,n,l=i(5494),a=i(42292),o=i(17409),r=i(5924),h=i(56937),d=i(31222)
let c=(n=class t{static Inst_get(){return t.inst||(t.inst=new t),t.inst}get defeatView(){return(0,o.Y)(l.I.CopyDefeatPanel)}constructor(){this.defeatCloseCool=-1,
this._degf_CallDestory=null,this._degf_ShowHandler=null,this._degf_CallDestory=()=>this.CallDestory(),this._degf_ShowHandler=t=>this.ShowHandler(t)}OpenPanel(){const t=new h.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!0,(0,o.Yp)(l.I.CopyDefeatPanel,t,this._degf_ShowHandler)}ShowHandler(t){return this.defeatView}CallDestory(){(0,
o.sR)(l.I.CopyDefeatPanel)}ClosePanel(){null!=this.defeatView?this.CallDestory():d.N.inst.UnLoading(l.I.CopyDefeatPanel)}ClearDefeatColl(){
r.C.Inst_get().ClearInterval(this.defeatCloseCool),this.defeatCloseCool=-1}SetAutoExit(){this.defeatView.AutoExit()}},n.inst=null,_=s=n,u="Inst_get",I=[a.n],
m=Object.getOwnPropertyDescriptor(s,"Inst_get"),g=s,p={},Object.keys(m).forEach((function(t){p[t]=m[t]})),p.enumerable=!!p.enumerable,p.configurable=!!p.configurable,
("value"in p||p.initializer)&&(p.writable=!0),p=I.slice().reverse().reduce((function(t,e){return e(_,u,t)||t}),p),
g&&void 0!==p.initializer&&(p.value=p.initializer?p.initializer.call(g):void 0,p.initializer=void 0),void 0===p.initializer&&(Object.defineProperty(_,u,p),p=null),s)
var _,u,I,m,g,p},91420:(t,e,i)=>{
var s,n=i(6847),l=i(83908),a=i(49655),o=i(46282),r=i(93984),h=i(86133),d=i(98800),c=i(97461),_=i(98958),u=i(50089),I=i(62370),m=i(5924),g=i(57834),p=i(60130),C=i(98885),S=i(85602),f=i(70123),T=i(92679),y=i(87923),A=i(24524),D=i(75439),E=i(26348),v=i(71842),w=i(14187),R=i(5031),P=i(43308),O=i(95406),L=i(62783),B=i(29839),b=i(97503),M=i(85770),G=i(72800),H=i(40162)
;(0,n.s_)(a.o.CopyDefeatPanel,o.Z.ui_copybaseui_defeatpanel).waitPrefab(o.Z.ui_access_iconitem).register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),
this.exitTime=0,this.timer=-1,this.exitStr="",this.animTimer=-1,this.animFrameCount=0,this._degf_AddBattleHandler=null,this._degf_ExitCopyAnim=null,this._degf_ExitCopyHandler=null,
this._degf_PlayAnimHandler=null,this._degf_OnAccessClick=null,this._degf_OnCreateAccessItem=null,this.exitEnable=null,this.startExitTimerid=null}_initBinder(){super._initBinder(),
this._degf_AddBattleHandler=(t,e)=>this.AddBattleHandler(t,e),this._degf_ExitCopyAnim=()=>this.ExitCopyAnim(),this._degf_ExitCopyHandler=(t,e)=>this.ExitCopyHandler(t,e),
this._degf_PlayAnimHandler=()=>this.PlayAnimHandler(),this._degf_OnAccessClick=t=>this.OnAccessClick(t)}InitView(){super.InitView(),this.isExclusionPanel=!0,
this.isKillAllExcluded=!0,this.autoExit.textSet((0,h.T)("离开副本")),null!=this.grid&&(this._degf_OnCreateAccessItem=t=>this.OnCreateAccessItem(t),
this.grid.SetInitInfo("ui_access_copydefeat_icon",this._degf_OnCreateAccessItem)),this.bgSp.widthSet(u.t.GetUIWidth()),p.O.SetAnchorPos(this.leftAnchor,!0,!1,0,!1),
p.O.SetAnchorPos(this.rightAnchor,!1,!1,0,!1),this.exitEnable=!0,this.startExitTimerid=-1}OnCreateAccessItem(t){return t[0].getCNode(v.o)}OnAddToScene(){
this.addBattleBtn.node.SetActive(!1)
const t=A.o.Inst().getItemById(M.a.Inst_get().currentCopyId)
if(null!=t){this.exitTime=t.escTime
d.Y.Inst.m_primaryRoleInfo.Level_get()<M.a.Inst_get().defeatDenyClose?(this.exitEnable=!1,this.ClearStartExitTimer(),this.StartExitTimer(),this.exitcopygraybtn.node.SetActive(!0),
this.exitBtn.node.SetActive(!1)):(this.exitStr=_.V.Inst().getStr(10300,r.h.eLangResource),this.AutoExit()),t.controllerType==G.S.Memory&&this.btnGrid.Reposition()}
R.T.inst_get().control.CloseBuffListPanel(),P._.Inst_get().CloseView(),L.X.inst.CloseChangeLinePanel(),b.f.inst_get().hasEndOpen=!0,this.addLis(),this.ShowStrengWay()}
ShowStrengWay(){let t=new S.Z
const e=A.o.Inst().getItemById(M.a.Inst_get().currentCopyId)
if(null!=e&&null!=e.failAccess){const i=new S.Z(e.failAccess)
for(let e=0;e<=i.Count()-1;e++){const s=i[e]
E.Z.Inst().IsFunOpen(s)&&t.Add(s)}}else{let e=D.D.getInstance().GetStringValue("COPY:ACCESS_TO_STRENGTH")
e=C.M.Replace(e,C.M.s_LEFT_B_K_CHAR_DOT,I.o.s_BLANK_CHAR),e=C.M.Replace(e,C.M.s_RIGHT_B_K_CHAR_DOT,I.o.s_BLANK_CHAR),t=y.l.getIntValByExcelArray(e)}
t.Sort(this.CreateDelegate(this.SortAccess))
const i=new S.Z
for(let e=0;e<=t.Count()-1;e++){const s=new S.Z
s.Add(t[e]),0==e&&f.W.ins.IsRecommandedById(t[e])||f.W.ins.IsCfgRecommanded(t[e])?s.Add(!0):s.Add(!1),i.Add(s)}null!=this.grid&&this.grid.data_set(i)}SortAccess(t,e){
return f.W.ins.SortCopyDefeatAccess(t,e)}ClearStartExitTimer(){-1!=this.startExitTimerid&&(m.C.Inst_get().ClearInterval(this.startExitTimerid),this.startExitTimerid=-1)}
StartExitTimer(){this.startExitTimerid=m.C.Inst_get().SetInterval(this.CreateDelegate(this.AutoExit),M.a.Inst_get().defeatDelayClose)}Clear(){this.removeLis(),
m.C.Inst_get().ClearInterval(this.timer),this.timer=-1,this.grid.Clear(),this.ClearAnimData(),this.ClearStartExitTimer(),super.Clear()}StartAnimTimer(){
-1==this.animTimer&&(this.animTimer=m.C.Inst_get().SetFrameLoop(this._degf_PlayAnimHandler,1,8))}PlayAnimHandler(){this.animFrameCount+=1,
6==this.animFrameCount?this.lightAnim.node.SetActive(!0):8==this.animFrameCount&&(this.loopAnim.SetActive(!0),this.ClearAnimData())}ClearAnimData(){
m.C.Inst_get().ClearLoop(this.animTimer),this.animTimer=-1,this.animFrameCount=0}addLis(){g.i.Get(this.exitBtn.node).RegistonClick(this._degf_ExitCopyHandler),
g.i.Get(this.addBattleBtn.node).RegistonClick(this._degf_AddBattleHandler),c.i.Inst.AddEventHandler(T.g.ACCESS_ICON_CLICK,this._degf_OnAccessClick),
this.m_handlerMgr.AddClickEvent(this.exitcopygraybtn,this.CreateDelegate(this.DelayBtnClick)),this.grid.OnReposition_set(this.CreateDelegate(this.ItemReposition))}ItemReposition(){
this.grid.node.transform.SetLocalPositionXYZ(0,0,0),this.tab.Reposition()}DelayBtnClick(){}AddBattleHandler(t,e){this.ExitCopyHandler(0,0),w.u.Inst_Get().tryOpenPanel=!1}
OnAccessClick(t){B.p.inst.IsInCopy()&&(O.j.accessIdAfterCopy=t,w.u.Inst_Get().tryOpenPanel=!1,this.ExitCopyHandler())}ExitCopyHandler(t,e){m.C.Inst_get().ClearInterval(this.timer),
this.timer=-1,M.a.Inst_get().ExitCopy(),H.v.inst.ClosePanel()}removeLis(){c.i.Inst.RemoveEventHandler(T.g.ACCESS_ICON_CLICK,this._degf_OnAccessClick),
g.i.Get(this.exitBtn.node).RemoveonClick(this._degf_ExitCopyHandler),g.i.Get(this.addBattleBtn.node).RemoveonClick(this._degf_AddBattleHandler),this.grid.OnReposition_set(null)}
AutoExit(){-1==this.timer&&(this.exitEnable=!0,this.exitcopygraybtn.node.SetActive(!1),this.exitBtn.node.SetActive(!0),
this.timer=m.C.Inst_get().SetInterval(this._degf_ExitCopyAnim,1e3),this.autoExit.textSet(`${(0,h.T)("离开副本(")}${this.exitTime})`))}ExitCopyAnim(){this.exitTime-=1,
this.autoExit.textSet(`${(0,h.T)("离开副本(")}${this.exitTime})`),this.exitTime<=0&&(m.C.Inst_get().ClearInterval(this.timer),this.timer=-1,this.autoExit.textSet((0,h.T)("离开副本")),
this.ExitCopyHandler())}Destroy(){this.grid.Destroy()}})},11158:(t,e,i)=>{i.d(e,{p:()=>d})
var s,n,l=i(56937),a=i(31222),o=i(5494),r=i(72800),h=i(42292)
let d=(n=class t{static Inst_get(){return t.inst||(t.inst=new t),t.inst}constructor(){this.successView=null,this._degf_DestroySuccessView=null,this._degf_ShowHandler=null,
this._degf_DestroySuccessView=()=>this.DestroySuccessView(),this._degf_ShowHandler=t=>this.ShowHandler(t)}OpenPanel(t,e,i){BloodSuccessModel.Inst_get().currentCopyId=t
const s=BloodSuccessModel.Inst_get().copySuccessTime,n=BloodSuccessModel.Inst_get().copySuccessReward
null!=i&&(s.LuaDic_ContainsKey(t)?s[t]=e:s.LuaDic_AddOrSetItem(t,e),n.LuaDic_ContainsKey(t)?n[t]=i:n.LuaDic_AddOrSetItem(t,i)),this.OpenSuccessView()}OpenSuccessView(){
const t=new l.v
t.isShowMask=!0,t.isDefaultUITween=!0,a.N.inst.OpenById(o.I.CopySuccessPanel,this._degf_ShowHandler,this._degf_DestroySuccessView,t)}ShowHandler(t){
return null==this.successView&&(this.successView=new BloodSuccessView,this.successView.setId(t,null,0)),this.successView}ClosePanel(){
null!=this.successView?a.N.inst.ClosePanel(this.successView):a.N.inst.UnLoading(o.I.CopySuccessPanel)}DestroySuccessView(){UIResMgr.DestroyUIObj(this.successView),
this.successView=null}SetData(){if(null!=this.successView){const t=CopyResourceCfgManager.Inst().getItemById(CopyBaseModel.Inst_get().currentCopyId)
null!=t&&t.controllerType==r.S.BloodTown?this.successView.SetSuccessTime(BloodSuccessModel.Inst_get().copySuccessTime[BloodSuccessModel.Inst_get().currentCopyId]):null!=t&&t.controllerType==r.S.Belial&&this.successView.SetSuccessTimeAndPinjia(BloodSuccessModel.Inst_get().copySuccessTime[BloodSuccessModel.Inst_get().currentCopyId],BloodSuccessModel.Inst_get().evaluateLevel,BloodSuccessModel.Inst_get().displayExp,BloodSuccessModel.Inst_get().killMonsterNum,BloodSuccessModel.Inst_get().historyTopExp),
this.successView.SetData(BloodSuccessModel.Inst_get().copySuccessReward[BloodSuccessModel.Inst_get().currentCopyId])}}},n.inst=null,c=s=n,_="Inst_get",u=[h.n],
I=Object.getOwnPropertyDescriptor(s,"Inst_get"),m=s,g={},Object.keys(I).forEach((function(t){g[t]=I[t]})),g.enumerable=!!g.enumerable,g.configurable=!!g.configurable,
("value"in g||g.initializer)&&(g.writable=!0),g=u.slice().reverse().reduce((function(t,e){return e(c,_,t)||t}),g),
m&&void 0!==g.initializer&&(g.value=g.initializer?g.initializer.call(m):void 0,g.initializer=void 0),void 0===g.initializer&&(Object.defineProperty(c,_,g),g=null),s)
var c,_,u,I,m,g},1046:(t,e,i)=>{i.d(e,{N:()=>z})
var s=i(46282),n=i(38045),l=i(98800),a=i(97461),o=i(16812),r=i(38935),h=i(62370),d=i(18202),c=i(98885),_=i(85602),u=i(21554),I=i(70850),m=i(92679),g=i(1003),p=i(55661),C=i(87923),S=i(2457),f=i(13476),T=i(37648),y=i(55492),A=i(24524),D=i(33138),E=i(22365),v=i(20296),w=i(65550),R=i(35042),P=i(21334),O=i(85770),L=i(72800),B=i(83908),b=i(68662),M=i(5924),G=i(57834),H=i(31222),N=i(5494),k=i(60130),U=i(63076),V=i(70093),x=i(34843),F=i(74657),q=i(15771),Y=i(41670),W=i(29839),j=i(70478),Z=i(75696),X=i(9057),K=i(21267)
class $ extends((0,B.pA)(X.x)()){constructor(...t){super(...t),this.data=null,this._degf_clickHandler=null,this.hasSelect=null}_initBinder(){super._initBinder(),
this._degf_clickHandler=(t,e)=>this.OnClickHandler(t,e)}InitView(){super.InitView()}AddLis(){
a.i.Inst.AddEventHandler(m.g.COPY_ITEM_SELECT_BLOODTOWN,this.CreateDelegate(this.SelectHandler)),G.i.Get(this.noSelectBtn.node).RegistonClick(this._degf_clickHandler)}RemoveLis(){
a.i.Inst.RemoveEventHandler(m.g.COPY_ITEM_SELECT_BLOODTOWN,this.CreateDelegate(this.SelectHandler)),G.i.Get(this.noSelectBtn.node).RemoveonClick(this._degf_clickHandler)}
RefreshBtnTxt(){this.lock.SetActive(!1)
const t=l.Y.Inst.PrimaryRoleInfo_get().Level_get()
let e=`第${A.o.Inst().getBloodLayerById(this.data.id)}城堡[-]`
const i=z.Inst_get().GetCurrentCopyId()
let s="",n=""
const a=this.data.GetCheckPointCon()
if(null!=a&&!a.CheckCondition()){if(a.intType==S.u.ACC_CHECKPOINT){const t=a.intValue
n=`推关数:[FF0000]${K.u.Inst().totalPassNum}[-]/${t}`}else if(a.intType==S.u.PASS_CHECKPOINT){const t=a.value,e=v.C.GetInst().csvEx.GetItemById(t)
n=`通关${e.mapName}${e.name}开启`}this.lock.SetActive(!0)}0!=i&&this.data.id==i?(e=`[FBEDB2]${e}[-]`,
this.data.minLevelLimit<=t&&(s=`[EFBE72](${this.data.minLevelLimit}-${this.data.maxLevelLimit}级)[-]`)):(e=`[AD8D5B]${e}[-]`,
this.data.minLevelLimit>t&&(s=`[EFBE72](${this.data.minLevelLimit}级开启)[-]`)),1==this.data.isLvOrcheckpoint?""!=n&&(e+=`\n${n}`):0==this.data.isLvOrcheckpoint&&""!=s&&(e+=`\n${s}`),
this.btnTxt.textSet(e)}OnClickHandler(t,e){if(null!=this.data)if(0==this.data.isLvOrcheckpoint){
l.Y.Inst.PrimaryRoleInfo_get().Level_get()<this.data.minLevelLimit?w.y.inst.ClientSysMessage(11030502):(z.Inst_get().SetCurrentCopyId(this.data.id),this.RefreshPanel(),
a.i.Inst.RaiseEvent(m.g.COPY_ITEM_SELECT_BLOODTOWN))}else if(1==this.data.isLvOrcheckpoint){const t=this.data.GetCheckPointCon()
if(t.CheckCondition())z.Inst_get().SetCurrentCopyId(this.data.id),this.RefreshPanel(),a.i.Inst.RaiseEvent(m.g.COPY_ITEM_SELECT_BLOODTOWN)
else if(t.intType==S.u.ACC_CHECKPOINT){const e=t.intValue,i=new _.Z
i.Add((0,n.tw)(e)),w.y.inst.ClientSysMessage(100613,i)}else if(t.intType==S.u.PASS_CHECKPOINT){const e=t.value,i=v.C.GetInst().csvEx.GetItemById(e),s=i.mapName,n=i.name,l=new _.Z
l.Add(s+n),w.y.inst.ClientSysMessage(100614,l)}}}SelectHandler(){this.RefreshPanel(),this.hasSelect}SetData(t){this.data=t,null!=this.data&&(this.RefreshPanel(),this.AddLis())}
RefreshPanel(){const t=z.Inst_get().GetCurrentCopyId()
0!=t&&this.data.id==t?(this.hasSelect=!0,this.hasSelectBtn.node.SetActive(!0),this.noSelectBtn.node.SetActive(!1)):(this.hasSelect=!1,this.hasSelectBtn.node.SetActive(!1),
this.noSelectBtn.node.SetActive(!0)),this.RefreshBtnTxt()}Clear(){this.RemoveLis(),this.data=null}Destroy(){}}class J extends((0,B.Ri)()){constructor(...t){super(...t),
this._degf_EnterClickHandler=null,this._degf_IncreaseTimeClickHandler=null,this._degf_BagUpdateHandler=null,this._degf_TimeUpdateHandler=null,this._degf_Cooling=null,
this._degf_OnCreateRewardItem=null,this._degf_EnterHandlerOk=null,this._degf_EnterSenlectHandlerOk=null,this.curCopyID=null,this.intervalId=null,this.index=null,this.timerOne=null,
this.showLeftNum=null,this.itemModelId=null,this.needItemNum=null,this.curCopyType=null,this.copyType=null,this.leftCount=null,this.serverTimer=null,this.totalTime=null,
this.residueTimer=null}_initBinder(){super._initBinder(),this._degf_EnterClickHandler=()=>{this.EnterBtnHandler()},this._degf_IncreaseTimeClickHandler=()=>{
this.IncreaseTimeBtnHandler()},this._degf_BagUpdateHandler=()=>{this.BagUpdateHandler()},this._degf_TimeUpdateHandler=()=>{this.RefreshTime()},
this._degf_Cooling=()=>this.Cooling(),this._degf_EnterHandlerOk=()=>this.SendEnterCopy(),this._degf_EnterSenlectHandlerOk=()=>this.SetRecommondCopy()}InitView(){super.InitView(),
this.layerGrid.SetInitInfo("ui_copypanel_bloodtown_item",null,$),this.grid.SetInitInfo("ui_baseitem",null,Z.j),this.grid.OnReposition_set(this.CreateDelegate(this.Resposition2))}
Resposition2(){this.ScrollView2.ResetPosition()}OnAddToScene(){this.node.SetActive(!0),k.O.SetAnchorPos(this.rightDownWidget.node,!1,!0,-2),
k.O.SetAnchorPos(this.leftUpWidget.node,!0,!0,2),k.O.SetAnchorPos(this.rightUpWidget.node,!1,!0,2),this.AddLis(),this.SetData(L.S.BloodTown),this.RefreshLayer(),
this.updateGradeHint()}RefreshReward(){const t=A.o.Inst().getItemById(this.curCopyID),e=new _.Z,i=t.ShowRewardValue_get()
for(let t=0;t<=i.Count()-1;t++)if(null!=i[t]){const s=F.A.GetReward(i[t])
if(null!=s){const t=s.GetAllRewardList()
t.Count()>0&&e.AddRange(t)}}this.grid.data_set(e)}RefreshLayer(){const t=A.o.Inst().allBloodCopy
this.layerGrid.data_set(t),this.SetScrollBarLayer()}SetScrollBarLayer(){null!=this.intervalId&&M.C.Inst_get().ClearLoop(this.intervalId),
this.intervalId=M.C.Inst_get().SetFrameLoop(this.CreateDelegate(this.ScrollBarLayer),5,1)}ScrollBarLayer(){const t=this.GetPercent()
this.layerGrid.scrollTo(Math.ceil(t*this.layerGrid.array.length))}GetPercent(){const t=A.o.Inst().allBloodCopy,e=A.o.Inst().getBloodLayerById(this.curCopyID),i=t.Count()
return e<=1?0:e>i-1?1:(80*(e-2)+25)/(80*(i-1)-250+50+8)}Clear(){this.node.SetActive(!1),this.RemoveLis(),this.grid.Clear(),this.layerGrid.Clear(),this.index=0,
M.C.Inst_get().ClearInterval(this.timerOne),this.timerOne=-1,null!=this.intervalId&&M.C.Inst_get().ClearInterval(this.intervalId),super.Clear()}Destroy(){this.grid.Destroy()}
AddLis(){G.i.Get(this.enterBtn).RegistonClick(this._degf_EnterClickHandler),G.i.Get(this.increaseTimeBtn).RegistonClick(this._degf_IncreaseTimeClickHandler),
G.i.Get(this.rankBtn).RegistonClick(this.CreateDelegate(this.ClickRankHandler)),G.i.Get(this.closeBtn).RegistonClick(this.CreateDelegate(this.CloseBtnHandler)),
G.i.Get(this.cdBtn).RegistonClick(this.CreateDelegate(this.CdBtnHandler)),a.i.Inst.AddEventHandler(m.g.BAG_UPDATE,this._degf_BagUpdateHandler),
a.i.Inst.AddEventHandler(m.g.COPYRECORD_UPDATE,this._degf_TimeUpdateHandler),a.i.Inst.AddEventHandler(m.g.COPY_ITEM_SELECT_BLOODTOWN,this.CreateDelegate(this.SelectHandler)),
a.i.Inst.AddEventHandler(m.g.PLAYER_LEVELUP,this.CreateDelegate(this.LevelUpHandler))}RemoveLis(){G.i.Get(this.enterBtn).RemoveonClick(this._degf_EnterClickHandler),
G.i.Get(this.increaseTimeBtn).RemoveonClick(this._degf_IncreaseTimeClickHandler),G.i.Get(this.rankBtn).RemoveonClick(this.CreateDelegate(this.ClickRankHandler)),
G.i.Get(this.closeBtn).RemoveonClick(this.CreateDelegate(this.CloseBtnHandler)),G.i.Get(this.cdBtn).RemoveonClick(this.CreateDelegate(this.CdBtnHandler)),
a.i.Inst.RemoveEventHandler(m.g.BAG_UPDATE,this._degf_BagUpdateHandler),a.i.Inst.RemoveEventHandler(m.g.COPYRECORD_UPDATE,this._degf_TimeUpdateHandler),
a.i.Inst.RemoveEventHandler(m.g.COPY_ITEM_SELECT_BLOODTOWN,this.CreateDelegate(this.SelectHandler)),
a.i.Inst.RemoveEventHandler(m.g.PLAYER_LEVELUP,this.CreateDelegate(this.LevelUpHandler))}CdBtnHandler(){w.y.inst.ClientSysMessage(107008)}SetRecommondCopy(){
z.Inst_get().SetDefaultCopyId(),a.i.Inst.RaiseEvent(m.g.COPY_ITEM_SELECT_BLOODTOWN)}ClickRankHandler(){j._.GetInst().OpenBloodRankPanel()}LevelUpHandler(){this.updateGradeHint()}
CloseBtnHandler(){H.N.inst.CloseById(N.I.eDialoguePanel)}EnterBtnHandler(){return z.Inst_get().defaultCopyId!=z.Inst_get().curCopyID?(w.y.inst.ClientSysStrMsg("请前往挑战更高层数的副本"),
z.Inst_get().SetCurrentCopyId(z.Inst_get().defaultCopyId),void a.i.Inst.RaiseEvent(m.g.COPY_ITEM_SELECT_BLOODTOWN)):0==this.showLeftNum?(Y.B.GetInst().AddTimes(this.curCopyID),
void w.y.inst.ClientSysMessage(107006)):void(z.Inst_get().CheckCanEnter(this.curCopyID)&&z.Inst_get().SendEnterCopy(this.curCopyID))}SelectHandler(){
this.curCopyID=z.Inst_get().GetCurrentCopyId(),this.RefreshPanel(),this.SetScrollBarLayer()}IncreaseTimeBtnHandler(){Y.B.GetInst().AddTimes(this.curCopyID)}BagUpdateHandler(t){
if(null==this.itemModelId)return
const e=I.g.Inst_get().GetItemNum(this.itemModelId)
let i=null
i=new U.M(this.itemModelId),i.btnType=V.p.GetWay
let s=""
s=e>=this.needItemNum?`[CBCBCB]${e}[-]/${this.needItemNum}`:`[de2524]${e}[-]/${this.needItemNum}`,i.SpecialNumStr=s,this.consumeItem.SetData(i)}updateGradeHint(){}SetData(t){
this.curCopyType=t,this.curCopyID=z.Inst_get().GetCurrentCopyId(),this.RefreshPanel()}RefreshPanel(){this.RefreshItem(),this.RefreshTime(),this.SetTimer(),this.RefreshReward()}
RefreshTime(){W.p.inst.UpdateTimeAndCount(this.curCopyID)}SetEnterNum(t,e){const i=A.o.Inst().getItemById(this.curCopyID)
this.copyType=i.controllerType
const s=q.U.inst.model.GetCopyAddCount(this.copyType),n=x.v.Inst_get().GetCopyHasRecoveredCount(this.copyType)
this.leftCount=s-e
let l=0
const a=O.a.Inst_get().GetCopyRecByKey(this.copyType)
null!=a&&(l=a.todayItemTimes),this.showLeftNum=t+n+e+l,this.showLeftNum>0?this.remainTimeLbl.textSet(`剩余次数：[ffffff]${c.M.IntToString(this.showLeftNum)}[-]/${i.challengesTimes+n+e+l}`):this.remainTimeLbl.textSet(`剩余次数：[ff0000]${c.M.IntToString(this.showLeftNum)}[-]/${i.challengesTimes+n+e+l}`)
}RefreshItem(){let t=0,e=0
const i=A.o.Inst().getItemById(this.curCopyID).GetAttrValEX(g.U.Item)
if(c.M.Contains(i,":")){const s=c.M.Split(i,h.o.s_Arr_UNDER_COLON)
t=c.M.String2Int(s[0]),e=c.M.String2Int(s[1])}else t=c.M.String2Int(i),e=0
this.needItemNum=e,this.itemModelId=t,this.consumeItem.SetIconSize(40,40),this.consumeItem.SetBgSize(44,44),this.BagUpdateHandler()}CheckCanEnter(){
if(l.Y.Inst.PrimaryRole_get().Isdead_get())return!1
const t=l.Y.Inst.PrimaryRoleInfo_get()
if(P.p.Inst_get().GetMapById(t.MapId_get()).senceType==p.S.CopyMap)return w.y.inst.ClientSysMessage(R.X.InCopy),!1
if(0==this.showLeftNum)return Y.B.GetInst().AddTimes(this.curCopyID),w.y.inst.ClientSysMessage(107006),!1
const e=A.o.Inst().getItemById(this.curCopyID)
return this.IsItem(e.controllerType)}IsItem(t){const e=O.a.Inst_get().copyRecordDic
let i=null
if(e.LuaDic_ContainsKey(t)){const s=e[t]
i=A.o.Inst().getItemById(s.lastCopyId)}null==i&&(i=A.o.Inst().getItemByCopyType(t))
const s=i.GetAttrValEX(g.U.Item),n=c.M.Split(s,h.o.s_Arr_UNDER_COLON),l=c.M.String2Int(n[0]),a=c.M.String2Int(n[1]),o=I.g.Inst_get().GetItemNum(l),r=a-o
if(0==o){const t=D.f.Inst().getItemById(l),e=new _.Z([t.name])
w.y.inst.ClientSysMessage(11030501,e)}return!(r>0)||(u.J.Inst_get().OpenTipViewById(l),!1)}SetTimer(){this.timerOne=-1
const t=O.a.Inst_get().copyCoolTimeDic,e=O.a.Inst_get().copyRecordDic
let i=null
if(e.LuaDic_ContainsKey(this.curCopyType)){const t=e[this.curCopyType]
i=A.o.Inst().getItemById(t.lastCopyId)}let s=!1
if(t.LuaDic_ContainsKey(this.curCopyType))if(null!=i){const e=l.Y.Inst.PrimaryRoleInfo_get().Level_get()
if(null==i.cdLevel&&(i.cdLevel=0),e>=i.cdLevel)s=!0
else{this.serverTimer=t[this.curCopyType],this.totalTime=i.waitTime
let e=b.D.serverMSTime_get()-this.serverTimer
e<0&&(e=0),e>this.totalTime?s=!0:this.residueTimer=this.totalTime-e}}else s=!0
else s=!0
s?this.TimeAnimClear():(this.cdLbl.textSet(Math.floor(this.residueTimer/1e3).toString()),this.cdLbl.node.SetActive(!0),this.enterBtn.SetActive(!1),
-1==this.timerOne&&(this.timerOne=M.C.Inst_get().SetInterval(this._degf_Cooling,200)))}Cooling(){const t=b.D.serverMSTime_get()-this.serverTimer
this.residueTimer=this.totalTime-t,t>this.totalTime&&(this.residueTimer=0,this.TimeAnimClear()),this.cdLbl.textSet(`冷却中(${Math.floor(this.residueTimer/1e3)})`)}TimeAnimClear(){
this.index=0,M.C.Inst_get().ClearInterval(this.timerOne),this.timerOne=-1,this.cdLbl.node.SetActive(!1),this.enterBtn.SetActive(!0)}SendEnterCopy(){const t=new E.w
if(t.copyId=this.curCopyID,!f.E.Instance.HasCopyId(t.copyId,"SendEnterCopy2"))return
const e=A.o.Inst().getItemById(this.curCopyID)
if(l.Y.Inst.PrimaryRoleInfo_get().Level_get()>e.maxLevelLimit)return w.y.inst.ClientSysMessage(115515),z.Inst_get().SetDefaultCopyId(),
void a.i.Inst.RaiseEvent(m.g.COPY_ITEM_SELECT_BLOODTOWN)
A.o.Inst().saveid=this.curCopyID,r.C.Inst.F_SendMsg(t)}}class z extends o.k{constructor(...t){super(...t),this.view=null,this.curCopyID=0,this.defaultCopyId=0,this.isOpening=null,
this.fatherWidget=null,this.resultView=null}static Inst_get(){return null==z.inst&&(z.inst=new z),z.inst}OpenView(t){
T.P.Inst_get().IsFunctionOpened(y.x.BLOOD_CASTLE)?(this.SetDefaultCopyId(),0!=this.curCopyID?(this.isOpening=!0,null!=this.view?this.view.OnAddToScene():(this.fatherWidget=t,
d.g.LoadOne(s.Z.ui_copypanel_bloodtown,this.CreateDelegate(this.OnViewLoaded),J))):w.y.inst.ClientSysStrMsg("当前副本无关卡满足解锁条件")):C.l.SetFunctionTip(y.x.BLOOD_CASTLE)}
SetDefaultCopyId(){this.curCopyID=0,this.defaultCopyId=0
const t=L.S.BloodTown,e=l.Y.Inst.PrimaryRoleInfo_get().Level_get()
let i=null
i=A.o.Inst().getItemByTypeLevel(t,e)
const s=A.o.Inst().allBloodCopy
for(let t=0;t<=s.Count()-1;t++){const i=s[t]
if(0==i.isLvOrcheckpoint)e>=i.minLevelLimit&&e<=i.maxLevelLimit&&i.hierarchy>-1&&(this.curCopyID=i.id)
else if(1==i.isLvOrcheckpoint){const t=i.GetCheckPointCon()
null!=t&&t.CheckCondition()&&(this.curCopyID=i.id)}}this.defaultCopyId=this.curCopyID}GetCurrentCopyId(){return this.curCopyID}SetCurrentCopyId(t){null!=t&&(this.curCopyID=t)}
CheckCanEnter(t){if(l.Y.Inst.PrimaryRole_get().Isdead_get())return!1
const e=l.Y.Inst.PrimaryRoleInfo_get()
if(P.p.Inst_get().GetMapById(e.MapId_get()).senceType==p.S.CopyMap)return w.y.inst.ClientSysMessage(R.X.InCopy),!1
const i=A.o.Inst().getItemById(this.curCopyID)
return this.IsItem(i.controllerType)}IsItem(t){const e=O.a.Inst_get().copyRecordDic
let i=null
if(e.LuaDic_ContainsKey(t)){const s=e[t]
i=A.o.Inst().getItemById(s.lastCopyId)}null==i&&(i=A.o.Inst().getItemByCopyType(t))
const s=i.GetAttrValEX(g.U.Item),n=c.M.Split(s,h.o.s_Arr_UNDER_COLON),l=c.M.String2Int(n[0]),a=c.M.String2Int(n[1]),o=I.g.Inst_get().GetItemNum(l),r=a-o
if(0==o){const t=D.f.Inst().getItemById(l),e=new _.Z([t.name])
w.y.inst.ClientSysMessage(11030501,e)}return!(r>0)||(u.J.Inst_get().OpenTipViewById(l),!1)}SendEnterCopy(t){const e=new E.w
if(e.copyId=t,!f.E.Instance.HasCopyId(e.copyId,"SendEnterCopy2"))return
const i=A.o.Inst().getItemById(t)
if(0==i.isLvOrcheckpoint){if(l.Y.Inst.PrimaryRoleInfo_get().Level_get()>i.maxLevelLimit)return w.y.inst.ClientSysMessage(115515),z.Inst_get().SetDefaultCopyId(),
void a.i.Inst.RaiseEvent(m.g.COPY_ITEM_SELECT_BLOODTOWN)}else if(1==i.isLvOrcheckpoint){const t=A.o.Inst().getItemById(this.curCopyID).GetCheckPointCon()
if(!t.CheckCondition()){if(t.intType==S.u.ACC_CHECKPOINT){const e=t.intValue,i=new _.Z
i.Add((0,n.tw)(e)),w.y.inst.ClientSysMessage(100613,i)}else if(t.intType==S.u.PASS_CHECKPOINT){const e=t.value,i=v.C.GetInst().csvEx.GetItemById(e)
let s=i.mapName
const n=i.name,l=new _.Z
s+=n,l.Add(s),w.y.inst.ClientSysMessage(100614,l)}return}}A.o.Inst().saveid=t,r.C.Inst.F_SendMsg(e)}ClearView(){this.view&&this.view.Clear()}CloseView(){
null!=this.view?this.view=null:d.g.Unload(this.CreateDelegate(this.OnViewLoaded)),this.isOpening=!1}OnViewLoaded(t){this.view=t.getComponent(J),
this.fatherWidget.addChild(this.view.node),this.fatherWidget.SetActive(this.isOpening),this.view.OnAddToScene()}SetEnterNum(t,e){this.view&&this.view.SetEnterNum(t,e)}Reset(){
this.view=null,this.resultView=null,this.curCopyID=0}}z.inst=null},97503:(t,e,i)=>{i.d(e,{f:()=>_})
var s=i(3433),n=i(5924),l=i(70850),a=i(47786),o=i(22662),r=i(65550),h=i(12417),d=i(29839),c=i(85770)
class _{constructor(){this.hasBossDie=!1,this.hasPickUp=!1,this.hasEndOpen=!1,this._timerId=0,this._degf_TimerHandle=null,this._degf_TimerHandle=()=>this.TimerHandle()}
static inst_get(){return null==_._inst&&(_._inst=new _),_._inst}ResetData(){this.hasBossDie=!1,this.hasPickUp=!1,this.hasEndOpen=!1,this.StopTimer()}CheckBagFull(){
if(!s.c.Inst_get().IsMapLoaded_get())return
const t=d.p.inst.IsInCopy(),e=c.a.Inst_get().curCopyType
if(!t||!h._.Inst().IsVipBossCopy(e))return
const i=l.g.Inst_get().emptySize_get()
this.hasBossDie&&!this.hasEndOpen&&0==i?this.StartTimer():this.StopTimer()}StartTimer(){0==this._timerId&&(this._timerId=n.C.Inst_get().SetInterval(this._degf_TimerHandle,2e3,-1),
this.TimerHandle())}StopTimer(){0!=this._timerId&&(n.C.Inst_get().ClearInterval(this._timerId),this._timerId=0)}TimerHandle(){const t=a.x.Inst().getItemById(111011)
null!=t&&r.y.inst.ClientStrMsg(o.r.SystemTipMessage,t.sys_messsage)}}_._inst=null},98606:(t,e,i)=>{i.d(e,{R:()=>T})
var s,n=i(6847),l=i(83908),a=i(46282),o=i(38836),r=i(38045),h=i(66788),d=i(61911),c=i(5494),_=i(98885),u=i(85602),I=i(79534),m=i(75696),g=i(67885),p=i(74657),C=i(78417),S=i(84708),f=i(8006)
let T=(0,n.s_)(c.I.RyAllianceCopyBeginFireView,a.Z.ui_alliancecopy_beginfire_ry).waitPrefab(a.Z.ui_alliancecopy_headitem).waitPrefab(g.S.modulePathList).register()(s=class extends((0,
l.pA)(d.f)()){InitView(){super.InitView(),this.MyGrid.SetInitInfo("ui_alliancecopy_headitem",null,f.P),this.rewardGrid.SetInitInfo("ui_baseitem",null,m.j)}OnAddToScene(){
const t=S.H.Inst_get().SubmitFirePlayers_get(),e=t.playerMessages,i=t.fireLevel,s=t.upRate,n={},l=new u.Z
let a
for(const[t,i]of(0,o.V5)(e))a=i,n[a.playerId.ToNum()]||(l.Add(i),n[a.playerId.ToNum()]=!0)
this.MyGrid.data_set(l),this.m_handlerMgr.AddClickEvent(this.closeBtn.node,this.CreateDelegate(this.OnCloseClick)),this.rewardObj.SetActive(!1)
let d=""
const c=C.L.GetInst().GetFireItemCfg(i)
if(c){if(d+=`今日点燃[8c4f00]${c.name}[-]火堆`,!_.M.IsNullOrEmpty(c.fireReward)){this.rewardObj.SetActive(!0)
const t=p.A.GetReward(c.fireReward).GetRewardItemList()
this.rewardGrid.data_set(t),this.closeBtn.node.transform.SetLocalPosition(new I.P(0,-178,0))}}else h.Y.LogError(`取不到火种数据:${(0,r.tw)(i)}`)
d+=`,${`全战盟享受[047104]${Math.floor(s/100)}%[-]烤火经验加成`}`,this.description.textSet(d)}OnCloseClick(){C.L.GetInst().CloseBeginFireItemView()}Clear(){super.Clear()}Destroy(){
super.Destroy()}Test1(){return!0}S_Test(){return!0}})||s},96103:(t,e,i)=>{i.d(e,{R:()=>B})
var s=i(18998),n=i(83908),l=i(46282),a=i(38836),o=i(86133),r=i(98800),h=i(68662),d=i(62370),c=i(5924),_=i(66788),u=i(9057),I=i(31222),m=i(5494),g=i(98885),p=i(70850),C=i(75696),S=i(92679),f=i(85751),T=i(87923),y=i(33138),A=i(47786),D=i(22662),E=i(65550),v=i(74657),w=i(78417)
class R{constructor(){this.topContent=null,this.bottomContent=null,this.itemId=0,this.confirmHandle=null}}var P,O=i(84708),L=i(18202)
let B=s._decorator.ccclass("RyAllianceCopyFireItemView")(P=class extends((0,n.pA)(u.x)()){constructor(...t){super(...t),
this.IconList=["ryshengyan_sp_0009","ryshengyan_sp_0010","ryshengyan_sp_0011"],this.CdSpriteNameTable={0:"rymainui_nb_0050",1:"rymainui_nb_0041",2:"rymainui_nb_0042",
3:"rymainui_nb_0043",4:"rymainui_nb_0044",5:"rymainui_nb_0045",6:"rymainui_nb_0046",7:"rymainui_nb_0047",8:"rymainui_nb_0048",9:"rymainui_nb_0049"},this.Config=null,this.ID=0,
this.NeedNum=0,this.UpNum=0,this.BroadCastTimer=null,this.BroadCastCdSecond=0,this.BroadCastCdSecondMax=10,this._degf_OnRealSubmitFireItem=null,this._degf_OnCloseSubmitPanel=null,
this.curNum=null}static __StaticInit(){}InitView(){this._degf_OnRealSubmitFireItem=t=>this.RealReqSubmit(),this._degf_OnCloseSubmitPanel=t=>this.CloseSubmitPanel(),
this.rewardItemGrid.SetInitInfo("ui_baseitem",null,C.j),this.rewardItemGrid.OnReposition_set(this.CreateDelegate(this.ReSetRewardItem))}SetData(t){this.Config=t,this.ID=t.id,
this.NeedNum=t.needNum
const e=t.fireValue,i=`${Math.floor(e/100)}%`,s=this.IconList[this.ID-1]
this.itemIcon.spriteNameSet("atlas/shengyan/"+s),this.addRate.textSet(`+ ${i}`),this.name.textSet(t.name),this.Refresh(),this.RefreshFireAward(),
this.m_handlerMgr.AddClickEvent(this.submitBtn.node,this.CreateDelegate(this.OnSubmitClick)),
this.m_handlerMgr.AddClickEvent(this.openItemBtn,this.CreateDelegate(this.OpenItemTip)),this.m_handlerMgr.AddClickEvent(this.broacastBtn,this.CreateDelegate(this.BroadCastClick)),
this.m_handlerMgr.AddEventMgr(S.g.RYALLIANCE_FIREOH,this.CreateDelegate(this.OnSumitFireItemSuccess))}BroadCastClick(){if(this.BroadCastCdSecond>0)return
w.L.GetInst().ReqCM_InviteFireItem(this.ID)
const t=(0,o.T)("已召集盟友提交火种")
E.y.inst.ClientStrMsg(D.r.SystemTipMessage,t),this.BroadCastCdSecond=this.BroadCastCdSecondMax,this.RefreshBroadCastTimer()}OpenItemTip(){
INS.itemTipManager.OpenTipViewById(this.Config.itemId)}CloseSubmitPanel(){w.L.GetInst().CloseSubmitFireItemView()}RealReqSubmit(){w.L.GetInst().SubmitFireItemReq(this.ID)}
OnSubmitClick(){if(O.H.Inst_get().SubmitFireOpen&&!O.H.Inst_get().BornFireOpen)if(this.UpNum>=this.Config.numMax){const t=(0,o.T)("已达上限，无法提交")
E.y.inst.ClientStrMsg(D.r.SystemTipMessage,t)}else{if(1==this.Config.isWarning){const t=new R
let e=A.x.Inst().getItemById(114212)
const i=y.f.Inst().getItemById(this.Config.itemId),s=i.Quality_get(),n=`[${f.u.getColorStrByQuality(s)}]`,l=`${n}${this.Config.name}[-]`,a=`[047104]${this.Config.needNum}[-]`,r=`${n}${i.name}[-]`,h=d.o.Format(e.sys_messsage,l,a,r)
let c=(0,o.T)("(收集进度:{0})")
const _=`${this.UpNum>=this.NeedNum?"[047104]":"[962424]"}${this.UpNum}[-]/${this.NeedNum}`
return c=d.o.Format(c,_),t.topContent=h,t.bottomContent=c,t.itemId=this.Config.itemId,t.confirmHandle=this.CreateDelegate(this.RealReqSubmit),
O.H.Inst_get().ConfirmSubmitFireVo_set(t),void w.L.GetInst().OpenRyAllianceCopySubmitFireConfirmView()}this.RealReqSubmit()}else{const t=(0,o.T)("提交时间已过，无法提交")
E.y.inst.ClientStrMsg(D.r.SystemTipMessage,t)}}SetSubmitFireBroadcast(t){O.H.Inst_get().SubmitFireBroadcast_set(t)}RefreshFireAward(){
const t=this.Config.fireValue,e=`${Math.floor(t/100)}%`,i=this.IconList[this.ID-1]
if(this.addRate.textSet(`+ ${e}`),this.itemIcon.spriteNameSet("atlas/shengyan/"+i),this.name.textSet(this.Config.name),this.submitReward.SetActive(!1),
g.M.IsNullOrEmpty(this.Config.fireReward))this.addGrid.node.SetLocalPositionXYZ(455,212,0)
else{const t=this.Config.fireReward,e=v.A.GetReward(t)
this.rewardItemGrid.data_set(e.GetRewardBaseItemList()),this.submitReward.SetActive(!0),this.addGrid.node.SetLocalPositionXYZ(455,220,0)}this.addGrid.Reposition()}RefreshBtn(t){
const e=this.Config.canCommit,i=h.D.weekDay_get()
let s
for(const[t,n]of(0,a.O6)(e)){if(n==i){s=null
break}{const t=T.l.getWeekNumStr(n)
s?s+=`、${t}`:s=`周${t}`}}if(this.broacastBtn.SetActive(!1),this.NotShowSubmit.SetActive(!1),this.submitBtn.SetActive(!1),s)this.NotShowSubmit.textSet(`此火种只能在${s}提交`),
this.NotShowSubmit.SetActive(!0)
else if(this.submitBtn.SetActive(!0),O.H.Inst_get().SubmitFireOpen&&!O.H.Inst_get().BornFireOpen&&this.UpNum<this.Config.numMax){this.normalSubmit.SetActive(!0),
this.disableSubmit.SetActive(!1)
const e=this.UpNum/this.NeedNum,i=p.g.Inst_get().GetItemNum(this.Config.itemId)
if(1==this.Config.isWarning&&e<1)if(i>0)this.broacastBtn.SetActive(!0)
else if(t){const e=t.playerIds
for(const[t,i]of(0,a.V5)(e))if(r.Y.Inst.GetMultiPlayer(i)){this.broacastBtn.SetActive(!0)
break}}}else this.normalSubmit.SetActive(!1),this.disableSubmit.SetActive(!0)
this.btnGrid.Reposition(),this.RefreshBroadCastTimer()}Refresh(){let t
const e=O.H.Inst_get().FireInfoMsg_get()
if(e)for(const[i,s]of(0,a.V5)(e.fireVos)){const e=s
if(e.level==this.ID){t=e
break}}let i=0
t&&(i=t.upNum)
const s=i/this.NeedNum,n=i<this.NeedNum&&`${i}/${this.NeedNum}`||"已点燃"
this.percentIcon.fillRange=s,this.percent.textSet(n),this.UpNum=i,this.RefreshBtn(t)}OnSumitFireItemSuccess(t){const e=t[3]
if(e==this.ID){_.Y.Log(`OnSumitFireItemSuccess, id:${e}`)
const t=I.N.inst.GetViewById(m.I.RyAllianceCopySubmitFireView)
t&&t.BeginMoveEff(this.submitBtn.node.transform.GetLocalPosition())}}ClearBroadcastTimer(){this.BroadCastTimer&&(c.C.Inst_get().ClearInterval(this.BroadCastTimer),
this.BroadCastTimer=null)}RefreshBroadCastTimer(){this.broacastBtn.active||(this.BroadCastCdSecond=0),
this.BroadCastCdSecond>0&&(this.BroadCastTimer||(this.BroadCastTimer=c.C.Inst_get().SetInterval(this.CreateDelegate(this.CountDownTimer),1e3,-1))),this.RefreshBroadcastCd()}
CountDownTimer(){this.BroadCastCdSecond-=1,this.BroadCastCdSecond<=0&&this.ClearBroadcastTimer(),this.RefreshBroadcastCd()}GetCdSpriteName(t){return t<0?t=0:t>9&&(t=9),
this.CdSpriteNameTable[t]}RefreshBroadcastCd(){if(this.BroadCastCdSecond<=0)this.broacastCd.textSet(""),this.normalbroadcast.SetActive(!0),this.disablebroadcast.SetActive(!1),
this.btnGrid.node.SetLocalPositionXYZ(461,127,0)
else{const t=Math.ceil(this.BroadCastCdSecond)
this.broacastCd.textSet(`[5FB470]${t}秒[-]后恢复召集`),this.normalbroadcast.SetActive(!1),this.disablebroadcast.SetActive(!0),this.btnGrid.node.SetLocalPositionXYZ(461,137,0)}}
ReSetRewardItem(){const t=this.rewardItemGrid.itemList
if(t)for(let e=0;e<=t.Count()-1;e++)t[e].quality_width=54,t[e].quality_height=54,t[e].SetIconSize(52,52),t[e].SetBgSize(54,54)}CreateRewardItem(t){
const e=L.g.LoadScriptPrefab(l.Z.ui_baseitem,C.j,(t=>{}),this.rewardItemGrid.node)
return e.quality_width=54,e.quality_height=54,e.SetIconSize(52,52),e.SetBgSize(54,54),e}Clear(){super.Clear(),this.ClearBroadcastTimer()}Destroy(){super.Destroy()}Test1(){return!0}
S_Test(){return!0}})||P},8006:(t,e,i)=>{i.d(e,{P:()=>r})
var s,n=i(18998),l=i(83908),a=i(9057),o=i(33314)
let r=n._decorator.ccclass("RyAllianceCopyHeadItem")(s=class extends((0,l.pA)(a.x)()){InitView(){super.InitView()}SetData(t){this.name.textSet(t.name),
this.icon.spriteNameSet(o.Z.GetMainUIJobIcon(t.job,t.sex))}Clear(){super.Clear()}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}})||s},2129:(t,e,i)=>{i.d(e,{U:()=>u})
var s,n=i(6847),l=i(83908),a=i(46282),o=i(61911),r=i(5494),h=i(63076),d=i(67885),c=i(78417),_=i(84708)
let u=(0,n.s_)(r.I.RyAllianceCopySubmitFireConfirmView,a.Z.ui_alliancecopy_submitfire_confirm).waitPrefab(d.S.modulePathList).register()(s=class extends((0,l.pA)(o.f)()){
constructor(...t){super(...t),this.data=null}InitView(){super.InitView()}OnAddToScene(){const t=_.H.Inst_get().SubmitFireBroadcast_get()
this.data=_.H.Inst_get().ConfirmSubmitFireVo_get(),this.topLabel.textSet(this.data.topContent),this.bottomLabel.textSet(this.data.bottomContent),this.select.node.SetActive(t)
const e=new h.M(this.data.itemId)
this.item.SetData(e),this.m_handlerMgr.AddClickEvent(this.selectbg.node,this.CreateDelegate(this.SelectHandler)),
this.m_handlerMgr.AddClickEvent(this.closeBtn.node,this.CreateDelegate(this.OnClose)),this.m_handlerMgr.AddClickEvent(this.confirmBtn.node,this.CreateDelegate(this.OnClose)),
this.m_handlerMgr.AddClickEvent(this.cancelBtn.node,this.CreateDelegate(this.OnConfirm)),_.H.Inst_get().ConfirmSubmitFireVo_set(null)}OnClose(){
c.L.GetInst().CloseRyAllianceCopySubmitFireConfirmView()}OnConfirm(){this.data.confirmHandle&&this.data.confirmHandle(),this.OnClose()}SelectHandler(t,e){
const i=_.H.Inst_get().SubmitFireBroadcast_get()
this.select.node.SetActive(!i),_.H.Inst_get().SubmitFireBroadcast_set(!i)}Clear(){super.Clear(),this.data=null}Destroy(){super.Destroy()}Test1(){return!0}S_Test(){return!0}})||s},
25773:(t,e,i)=>{i.d(e,{u:()=>O})
var s,n=i(21370),l=i(6847),a=i(83908),o=i(46282),r=i(38836),h=i(98800),d=i(65393),c=i(97461),_=i(95417),u=i(5924),I=i(66788),m=i(61911),g=i(5494),p=i(60130),C=i(85602),S=i(79534),f=i(67885),T=i(18152),y=i(92679),A=i(73423),D=i(87923),E=i(75439),v=i(74657),w=i(78417),R=i(84708),P=i(96103)
let O=(0,l.s_)(g.I.RyAllianceCopySubmitFireView,o.Z.ui_alliancecopy_submitfire_ry).waitPrefab(o.Z.ui_copybaseui_fireitem).waitPrefab(f.S.modulePathList).register()(s=class extends((0,
a.pA)(m.f)()){constructor(...t){super(...t),this.UpdateTimer=null,this.MoveCameraTimer=null,this.MoveStartPos=null,this.MoveEndPos=null,this.MoveDirection=null,this.MovePercent=0,
this.OldShowRole=null,this.OldShowRoleTitle=null,this.OldLookAtPosBias=null,this.OldLookAtAngle=null,this.OldDistance=null,this.moveEffTimer=null,this.notUpdateExpAddRate=!1,
this.getAwardState=0}static __StaticInit(){}_initBinder(){super._initBinder(),this.MoveStartPos=new S.P(0,0,0),this.MoveEndPos=new S.P(0,0,0),this.MoveDirection=new S.P(0,0,0)}
IsFirstPanel_Get(){return!0}InitView(){super.InitView(),this.grid.SetInitInfo("ui_copybaseui_fireitem",null,P.R,null),
this.grid.OnReposition_set(this.CreateDelegate(this.FireItemLoadFinish)),this.ui_baseitem.EnabledClickOpenTip(!1)}OnAddToScene(){p.O.SetLayerVisible(n.T.nav,!1),
this.ClearUpdateTimer(),this.ClearMoveCameraTimer(),this.ClearMoveEffTimer(),this.notUpdateExpAddRate=!1
const t=w.L.GetInst().BoreFireObjForMoveCamID
if(t){const e=d.e.Inst_get().GetCharacterObj(t)
if(e){h.Y.Inst.PrimaryRole_get().GetCurPos(this.MoveStartPos),e.GetCurPos(this.MoveEndPos),this.MoveDirection=this.MoveEndPos-this.MoveStartPos,this.MovePercent=0,
this.OldLookAtPosBias=new S.P(0,0,0),this.MoveCamera(),this.MoveCameraTimer=u.C.Inst_get().SetInterval(this.CreateDelegate(this.MoveCamera),30,-1),h.Y.Inst.m_isRoleShow,
h.Y.Inst.otherTitleShow_get()}}this.InitFireItemList(),this.m_handlerMgr.AddClickEvent(this.closeBtn.node,this.CreateDelegate(this.CloseClick)),
this.m_handlerMgr.AddClickEvent(this.getAwardBtn,this.CreateDelegate(this.ClickGetAward)),
this.m_handlerMgr.AddEventMgr(y.g.RYALLIANCE_REFRESHFIREMSG,this.CreateDelegate(this.RefreshFireItemList)),
this.m_handlerMgr.AddEventMgr(y.g.RYALLIANCE_REFRESHEXP,this.CreateDelegate(this.RefreshFireInfo)),
this.m_handlerMgr.AddEventMgr(y.g.RYALLIANCE_GET_FIRSTSUBMITAWARD,this.CreateDelegate(this.RefreshGetAwardObj)),
this.UpdateTimer=u.C.Inst_get().SetInterval(this.CreateDelegate(this.RefreshLeftTime),1e3,-1),this.RefreshLeftTime(),this.RefreshGetAwardObj(),
p.O.SetAnchorPos(this.rightTrans,!1,!0,0),p.O.SetAnchorPos(this.leftTrans,!0,!1,0),c.i.Inst.RaiseEvent(y.g.RYALLIANCE_SHOWHIDE_SUBMITPANEL,!0)}FireItemLoadFinish(){}
RefreshGetAwardObj(){this.getAwardState=0
if(R.H.Inst_get().SubmitFireAwardIsGot_get())this.getAwardState=2
else{const t=R.H.Inst_get().FireInfoMsg_get()
if(t)for(const[e,i]of(0,r.V5)(t.fireVos)){const t=i.playerIds
for(const[e,i]of(0,r.V5)(t))if(h.Y.Inst.GetMultiPlayer(i)){this.getAwardState=1
break}if(1==this.getAwardState)break}}this.normal.SetActive(!1),this.canGet.SetActive(!1),this.hadGot.SetActive(!1),
2==this.getAwardState?this.hadGot.SetActive(!0):1==this.getAwardState?this.canGet.SetActive(!0):this.normal.SetActive(!0)
if(!this.ui_baseitem.GetBaseItemData()){const t=E.D.getInstance().GetStringValue("ASURAM_PARTY_SUBMIT_REWARD"),e=v.A.GetReward(t).GetRewardBaseItemList()[0]
e.IconType_Set(T.s.BASE_ICON_TYPE_64_64),this.ui_baseitem.SetData(e)}}SortFireItemList(t,e){return t.id<e.id?1:t.id>e.id?-1:0}InitFireItemList(){
const t=w.L.GetInst().GetFireItemMap(),e=new C.Z
for(const[i,s]of(0,r.V5)(t))e.Add(s)
e.Sort(this.SortFireItemList),this.grid.data_set(e),this.RefreshFireInfo(),this.scrollView.ResetPosition()}RefreshFireItemList(){for(const[t,e]of(0,r.V5)(this.grid.itemList)){
e.Refresh()}this.RefreshFireInfo(),this.RefreshGetAwardObj()}RefreshFireInfo(){if(!this.notUpdateExpAddRate){
const t=R.H.Inst_get().GetBorningFireVo(),e=R.H.Inst_get().FireAllExp_get()
let i=0
i=R.H.Inst_get().ClientAddExpRate_get()
let s="未点燃"
if(t){s=w.L.GetInst().GetFireItemCfg(t.level).name,e&&(i=e.upRate)}const n=`${Math.floor(i/100)}%`
this.expAddRate.textSet(n),this.fireName.textSet(s),this.expRateIcon.SetActive(!1),this.expRateIcon.SetActive(!0)}}RefreshLeftTime(){let t
if(R.H.Inst_get().BornFireOpen){let e=R.H.Inst_get().BornFireLeftTime_get()
e<0&&(e=0,this.ClearUpdateTimer()),e=Math.floor(e+.5),t=D.l.GetDateFormatEX(e),this.leftTimeTxt.textSet("烤火剩余时间:")}else{let e=R.H.Inst_get().SubmitFireLeftTime_get()
e=Math.floor(e+.5),t=D.l.GetDateFormatEX(e),this.leftTimeTxt.textSet("提交剩余时间:")}this.leftTime.textSet(t)}MoveCamera(){this.MovePercent+=.3,this.MovePercent>=1&&(this.MovePercent=1,
this.ClearMoveCameraTimer()),this.MoveEndPos.x=this.MoveStartPos.x+this.MoveDirection.x*this.MovePercent,
this.MoveEndPos.y=this.MoveStartPos.y+this.MoveDirection.y*this.MovePercent,this.MoveEndPos.z=this.MoveStartPos.z+this.MoveDirection.z*this.MovePercent
const t=w.L.GetInst().BoreFireObjForMoveCamID
if(t){const e=d.e.Inst_get().GetCharacterObj(t)
e&&e.setPosXYZ(this.MoveEndPos.x,this.MoveEndPos.y,this.MoveEndPos.z)}}ClickGetAward(){if(0==this.getAwardState){const t=this.ui_baseitem.GetBaseItemData()
t&&INS.itemTipManager.OpenTipView(t)}else 1==this.getAwardState&&(I.Y.Log("getAward"),w.L.GetInst().ReqCM_GetFireReward())}CloseClick(){w.L.GetInst().CloseSubmitFireItemView()}
ClearUpdateTimer(){this.UpdateTimer&&(u.C.Inst_get().ClearInterval(this.UpdateTimer),this.UpdateTimer=null)}ClearMoveCameraTimer(){
this.MoveCameraTimer&&(u.C.Inst_get().ClearInterval(this.MoveCameraTimer),this.MoveCameraTimer=null)}ClearMoveEffTimer(){
this.moveEffTimer&&(u.C.Inst_get().ClearInterval(this.moveEffTimer),this.moveEffTimer=null)}BeginMoveEff(t){this.notUpdateExpAddRate=!0,this.ClearMoveEffTimer()
const e=this.expAddRate.node.transform.GetLocalPosition()
A.B.Inst().PlayEffect("ui_ry_flow_point_eff",t,e,.3,500),A.B.Inst().PlayEffect("ui_ry_flow_point_eff",t,e,.3,500),A.B.Inst().PlayEffect("ui_ry_flow_point_eff",t,e,.3,500),
this.moveEffTimer=u.C.Inst_get().SetInterval(this.CreateDelegate(this.OnMoveEffEnd),300,1)}OnMoveEffEnd(){this.notUpdateExpAddRate=!1,this.RefreshFireInfo()}Clear(){
p.O.SetLayerVisible(n.T.nav,!0),super.Clear(),_.U.Inst.ResetStateAndCloseSceneTouchView(),this.OldShowRole&&h.Y.Inst.SetShowCharacter(!0),
this.OldShowRoleTitle&&h.Y.Inst.SetTitileHide(!0),this.OldLookAtPosBias,this.OldLookAtAngle,this.OldDistance,this.ClearUpdateTimer(),this.ClearMoveEffTimer(),this.OldShowRole=null,
this.OldShowRoleTitle=null,w.L.GetInst().CloseRyAllianceCopySubmitFireConfirmView(),c.i.Inst.RaiseEvent(y.g.RYALLIANCE_SHOWHIDE_SUBMITPANEL,!1)}Destroy(){super.Destroy(),
this.ClearUpdateTimer()}Test1(){return!0}S_Test(){return!0}})||s},95236:(t,e,i)=>{i.d(e,{C:()=>_})
var s=i(17409),n=i(56937),l=i(18202),a=i(31222),o=i(5494),r=i(52726),h=i(52212),d=i(31192),c=i(46873)
class _{get successPanel(){return this._successPanel||(this._successPanel=(0,s.Y)(o.I.eVipBossSuccessPanel)),this._successPanel}constructor(){this.commonRightView=null,
this._successPanel=null,this.isLoadingReduceScoreView=!1,this.topTimerPos=null,this.reduceScoreView=null,this._degf_ReduceScoreShowHandler=null,
this._degf_ReduceScoreDestoryHandler=null,this.defeatPanel=null,this.topTimerPos=new h.F(0,130),this.AddLis()}static Inst_get(){return null==_.inst&&(_.inst=new _),_.inst}
AddLis(){}OpenReduceSocreView(){if(null==this.reduceScoreView){(new n.v).isShowMask=!1,
a.N.inst.OpenById(o.I.VipBossReduceScorePanel,this._degf_ReduceScoreShowHandler,this._degf_ReduceScoreDestoryHandler)}else this.reduceScoreView.OnAddToScene()}
CloseReduceSocreView(){null!=this.reduceScoreView&&a.N.inst.ClosePanel(this.reduceScoreView)}SetReduceSocreTime(t){
null!=this.reduceScoreView?this.reduceScoreView.SetTime(t):this.OpenReduceSocreView()}OpenSuccessPanel(){
if(null!=this.successPanel&&this.successPanel.isShow_get())this.successPanel.node.SetActive(!1),this.successPanel.Clear(),this.successPanel.node.SetActive(!0),
this.successPanel.hasRush=!0,this.successPanel.OnAddToScene()
else{const t=new n.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!0,t.layerType=r.F.Alert,(0,s.Yp)(o.I.eVipBossSuccessPanel)}d.d.Inst_get().CloseAssistBasePanel()}OpenDefeatPanel(){
if(null!=this.defeatPanel&&this.defeatPanel.isShow_get())this.defeatPanel.node.SetActive(!1),this.defeatPanel.Clear(),this.defeatPanel.node.SetActive(!0),
this.defeatPanel.hasRush=!0,this.defeatPanel.OnAddToScene()
else{const t=new n.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!0,t.layerType=r.F.Alert,a.N.inst.OpenById(o.I.VipBossDefeatPanel,this.CreateDelegate(this.DefeatShowHandler),this.CreateDelegate(this.DestoryDefeatHandler),t)
}d.d.Inst_get().CloseAssistBasePanel()}DefeatShowHandler(t){return this.defeatPanel=new c.L,this.defeatPanel.setId(t,null,0),this.defeatPanel}DestoryDefeatHandler(){
null!=this.defeatPanel&&(l.g.DestroyUIObj(this.defeatPanel),this.defeatPanel=null)}CloseDefeatPanel(){
null!=this.defeatPanel?a.N.inst.ClosePanel(this.defeatPanel):a.N.inst.UnLoading(o.I.VipBossDefeatPanel)}successDestroyHandler(){
null!=this.successPanel&&l.g.DestroyUIObj(this.successPanel)}CloseSuccessPanel(){(0,s.sR)(o.I.eVipBossSuccessPanel)}GetEvaluateStr(t){let e="C"
return 0==t?e="SSS":1==t?e="SS":2==t?e="S":3==t?e="A":4==t?e="B":5==t&&(e="C"),e}}_.inst=null},35803:(t,e,i)=>{i.d(e,{D:()=>E})
var s=i(98800),n=i(90419),l=i(50089),a=i(68662),o=i(16812),r=i(98130),h=i(98885),d=i(85602),c=i(38962),_=i(63076),u=i(37648),I=i(55492),m=i(24524),g=i(48481),p=i(31896),C=i(14792),S=i(62734),f=i(28359),T=i(19276),y=i(15771),A=i(85770),D=i(72800)
class E extends o.k{constructor(){super(!1,0),this.m_evaluateVo=null,this.settlement=null,this.IsNewStage=!1,this.stage=0,this.curStageStartTime=0,this.evaluateTimes=null,
this.passedBossList=null,this.passedBossList1=null,this.passedBossList2=null,this.passedBossList3=null,this.bossId=0,this.dicShowDrop=null,this.redPointNumSpecial=0,
this.redPointNum1=0,this.redPointNum2=0,this.redPointNum3=0,this.dicShowDrop=new c.X}static Inst_get(){return null==E.inst&&(E.inst=new E),E.inst}
SM_PersonalBossSettlementHandler(t){this.settlement=t}UpdateEvaluate(t){E.Inst_get().m_evaluateVo=t,this.IsNewStage=!1,this.curStageStartTime=a.D.serverMSTime_get(),
this.stage=t.evaluateLevel,this.ParseCfg(),this.RaiseEvent(E.EVALUATE_UPDATE,t)}ParseCfg(){const t=m.o.Inst().getItemById(A.a.Inst_get().currentCopyId)
null!=t&&(this.evaluateTimes=t.PassEvaluateValue_get().intValue.GetLuaToArray())}GetCurTargetS(){return this.evaluateTimes[this.stage]}ShowDropValues_get(){let t=null
if(0!=this.bossId){if(this.dicShowDrop.LuaDic_ContainsKey(this.bossId))return this.dicShowDrop[this.bossId]
const e=T.C.Inst().getItemById(this.bossId).showDrop_get()
if(null!=e){const i=n.d.parseJsonObjectWithFix(e,"rewardValues")
t=l.t.decode(i,f.h),t.Parse(),this.dicShowDrop.LuaDic_AddOrSetItem(this.bossId,t)}}return t}GetRewardLis(t){const e=new d.Z
if(this.bossId=t,null!=this.ShowDropValues_get()&&null!=this.ShowDropValues_get().rewardValues&&this.ShowDropValues_get().rewardValues.Count()>0){
const t=this.ShowDropValues_get().rewardValues
let i=0
for(;i<t.Count();){if(null!=t[i]){const n=1e3*r.GF.INT(s.Y.Inst.PrimaryRoleInfo_get().Job_get()/1e3),l=t[i]
if(null!=l.job){if(h.M.String2Int(l.job)==n){const t=new g.t
t.num=l.secondValue_get()
const i=new _.M(l.firstValue_get(),t)
i.isForBag=!1,i.SetEquipAttrShowId(l.showid),i.isCanOperate=!1,i.isEquipCompare=!1,e.Add(i)}}else{const t=new g.t
t.num=l.secondValue_get()
const i=new _.M(l.firstValue_get(),t)
i.isForBag=!1,i.SetEquipAttrShowId(l.showid),i.isCanOperate=!1,i.isEquipCompare=!1,e.Add(i)}}i+=1}}return e}SetRedPoint(){let t=0
this.redPointNumSpecial=this.GetRedPointSpecial(),this.redPointNum1=this.GetRedPointByType(D.S.VipBoss1),this.redPointNum2=this.GetRedPointByType(D.S.VipBoss2),
this.redPointNum3=this.GetRedPointByType(D.S.VipBoss3),t=this.redPointNumSpecial+this.redPointNum1+this.redPointNum2+this.redPointNum3,
t>0?S.f.Inst.SetState(C.t.VIP_BOSS,!0):S.f.Inst.SetState(C.t.VIP_BOSS,!1)}GetRedPointByType(t){let e=0,i=A.a.Inst_get().GetCopyFreeNum(t)
const n=A.a.Inst_get().GetCopyRecByKey(t)
if(null!=n){const l=m.o.Inst().getItemByCopyType(t)
if(s.Y.Inst.IsLevelFix(l.GetLvConditionLimit())&&y.U.inst.model.level_get()>=l.GetVipLimit()){const s=l.EnterConsumesValue_get()
if(null==s||null!=s.copyResourceAttr&&0==s.copyResourceAttr.Count()||null!=s.copyResourceAttrEX&&0==s.copyResourceAttrEX.Count()){i+=n.todayBuyTimes
n.todayEnterHistory<i&&(e=1)}else{if(!p.t.inst.IsHasClick(C.t.VIP_BOSS+t)){i+=n.todayBuyTimes
n.todayEnterHistory<i&&(e=1)}}}}return e}GetRedPointSpecial(){let t=0
return u.P.Inst_get().IsFunctionOpened(I.x.PERSONAL_BOSS)&&!p.t.inst.IsHasClick(C.t.VIP_BOSS_SPECIAL)&&(t=1),t}}E.inst=null,E.EVALUATE_UPDATE="EVALUATE_UPDATE"},31390:(t,e,i)=>{
i.d(e,{u:()=>r})
var s=i(90603),n=i(93984),l=i(38836),a=i(55360),o=i(85602)
class r{constructor(){this.copyguajimap=null
const t=a.Y.Inst.GetOrCreateCsv(n.h.eCopyguaji)
this.copyguajimap=t.GetCsvMap()}static Inst(){return null==r._inst&&(r._inst=new r),r._inst}getItemById(t){let e=null
return e=this.copyguajimap.LuaDic_GetItem(t),e}GetShunxuItemsByCopyId(t){const e=new o.Z
for(const[i,s]of(0,l.V5)(this.copyguajimap))s.copyId==t&&1==s.aiType&&e.Add(s)
return e}GetEventItemsByCopyId(t){const e=new o.Z
for(const[i,s]of(0,l.V5)(this.copyguajimap))s.copyId==t&&2==s.aiType&&e.Add(s)
return e}GetStartItemByList(t){let e=0
for(;e<t.Count();){if(t[e].conditon==s.g.COPY_START)return t[e]
e+=1}return null}GetEndItemByList(t){let e=0
for(;e<t.Count();){if(t[e].conditon==s.g.COPY_END||t[e].conditon==s.g.COPY_ENDTIME)return t[e]
e+=1}return null}GetEndExitItemByList(t){let e=0
for(;e<t.Count();){if(t[e].conditon==s.g.COPY_ENDESCTIME)return t[e]
e+=1}return null}GetStageItemsByList(t){const e=new o.Z
let i=0
for(;i<t.Count();){t[i].conditonList[0]==s.g.COPY_STAGE&&e.Add(t[i]),i+=1}return e}GetCurStageItemByList(t,e,i){null==i&&(i="")
let s=0
for(;s<t.Count();){const n=t[s].conditonList
if(""!=i){if(n[1]==e&&n[2]==i)return t[s]}else if(n[1]==e)return t[s]
s+=1}return null}}r._inst=null},41670:(t,e,i)=>{i.d(e,{B:()=>j})
var s=i(32076),n=i(86133),l=i(38045),a=i(98800),o=i(97461),r=i(38935),h=i(85682),d=i(31222),c=i(98130),_=i(98885),u=i(79534),I=i(93353),m=i(21554),g=i(70850),p=i(92679),C=i(74045),S=i(49067),f=i(87923),T=i(24524),y=i(33138),A=i(35037),D=i(20641),E=i(38501),v=i(50870),w=i(22662),R=i(8211),P=i(43308),O=i(60647),L=i(13487),B=i(65550),b=i(61280),M=i(33828),G=i(39043),H=i(85942),N=i(19519),k=i(26223),U=i(22046),V=i(77344),x=i(12417),F=i(15771),q=i(42877),Y=i(72800),W=i(29839)
class j{constructor(){this.cfg=null,this.price=0,this._degf_RequestBuy=null,this._degf_RequestUseItem=null,this._degf_RequestUseItemByID=null,this._degf_OnOpenDiamondTip=null,
this._degf_RequestBuyTired=null,this._degf_RequestBuyTiredNew=null,this.bossTabType=null,this.vo=null,this.buyModelId=null,this.buyCopyType=null,
this._degf_RequestBuy=t=>this.RequestBuy(t),this._degf_RequestUseItem=t=>this.RequestUseItem(t),this._degf_RequestUseItemByID=t=>this.RequestUseItemByID(t),
this._degf_OnOpenDiamondTip=t=>this.OnOpenDiamondTip(t),this._degf_RequestBuyTired=t=>this.RequestBuyTired(t),this._degf_RequestBuyTiredNew=t=>this.RequestBuyTiredNew(t)}
static GetInst(){return null==j._inst&&(j._inst=new j),j._inst}RetrieveValueByItem(t){}RetrieveValueByItemNew(t,e){this.cfg=null
if(null!=g.g.Inst_get().GetItemByModleID(t))this.UseRetrieveValueItemNew(t,e)
else{const i=y.f.Inst().getItemById(t),s=F.U.inst.model.level_get(),n=E.f.Inst().GetMaxVipLevel()
let l=null
l=e==U.l.WORLDBOSS?E.f.Inst().getItemById(s).bossTiredBuy1:E.f.Inst().getItemById(s).bossTiredBuy2
const a=x._.Inst().BossTiredHasBuyNumToday_get(e),o=l.length-a
let r=0,h=0,d=null
for(let t=s;t<=n;t++)if(d=e==U.l.WORLDBOSS?E.f.Inst().getItemById(t).bossTiredBuy1:E.f.Inst().getItemById(t).bossTiredBuy2,d.length>l.length){r=d.length-l.length,h=t
break}const c=0==r
o>0?this.ShowTipBuyTiredNew(i,o,a,l,e):this.ShowTipCannotBuyTired(i,c,r,h)}}ShowTipCannotBuyTired(t,e,i,l){
const a=e?"BOSS:TIRED_CONSUME4":"BOSS:TIRED_CONSUME3",o=f.l.getColorStrByQuality(t.Quality_get()),r=new S.B
r.infoId=a,r.isCancelForCheckBox=!0,r.replaceParams.Add(`[${o}]${t.name}[-]`),r.replaceParams.Add(_.M.IntToString(t.id)),r.replaceParams.Add(1),e?(r.confirmHandle=null,
r.confirmParam=null,r.confirmText=(0,n.T)("确 定"),r.dontClose=!1):(r.replaceParams.Add(l),r.replaceParams.Add(i),r.confirmHandle=(0,s.v)(this.GotoVIP,this),r.confirmParam=l,
r.confirmText=(0,n.T)("提升VIP"),r.dontClose=!1),C.t.Inst().Open(r)}ShowTipBuyTired(t,e){
const i=f.l.getColorStrByQuality(t.Quality_get()),s=A.L.GetInst().GetCfgByItemId(t.id),n=A.L.GetInst().GetCfgById(s.id)
this.price=_.M.String2Int(n.consums.costs[0].subvalue)
const a=new S.B
a.infoId="BOSS:TIRED_CONSUME2",a.isCancelForCheckBox=!0,a.confirmParam=s.id,a.confirmHandle=this._degf_RequestBuyTired,a.replaceParams.Add(`[${i}]${t.name}[-]`),
a.replaceParams.Add(this.price),a.replaceParams.Add(_.M.IntToString(t.id)),a.replaceParams.Add("1"),a.replaceParams.Add((0,l.tw)(e)),C.t.Inst().Open(a)}
ShowTipBuyTiredNew(t,e,i,s,n){const l=f.l.getColorStrByQuality(t.Quality_get())
this.price=s[i]
const a=new S.B
a.infoId="BOSS:TIRED_CONSUME2",a.isCancelForCheckBox=!0,a.confirmHandle=this._degf_RequestBuyTiredNew,a.confirmParam=n,a.dontClose=!0,a.replaceParams.Add(`[${l}]${t.name}[-]`),
a.replaceParams.Add(this.price),a.replaceParams.Add(_.M.IntToString(t.id)),a.replaceParams.Add("1"),a.replaceParams.Add(e.toString()),C.t.Inst().Open(a)}
UseRetrieveValueItemNew(t,e){this.bossTabType=e
const i=y.f.Inst().getItemById(t)
let s="",n=""
null!=i&&(s=i.name,n=f.l.getColorStrByQuality(i.Quality_get()))
const l="BOSS:TIRED_CONSUME"
if(G.V.Inst_get().GetData(G.V.Inst_get().GetRolePrefix()+l)){const e=g.g.Inst_get().GetItemByModleID(t)
null!=e&&this.RequestUseItem(e)}else{const e=i.Rewards_get().typevalues[0].value,a=_.M.Split(e,"_")[1],o=new S.B
o.infoId=l,o.confirmParam=t,o.confirmHandle=this._degf_RequestUseItemByID,o.isCancelForCheckBox=!0,o.dontClose=!0,o.replaceParams.Add(`[${n}]${s}[-]`),o.replaceParams.Add(a),
o.replaceParams.Add(_.M.IntToString(t)),o.replaceParams.Add("1"),C.t.Inst().Open(o)}}AddTimes(t){if(this.cfg=T.o.Inst().getItemById(t),this.vo=null,
this.cfg.controllerType!=Y.S.KUNDUN_SEAL){const t=this.cfg.addEnterTimes,e=g.g.Inst_get().GetItemByModleID(t)
null!=e?this.ShowEnoughItemsTip(e):this.ShowBuyVIPTip(t)}else this.ShowBuyNoVIPTip()}ShowEnoughItemsTip(t){const e=y.f.Inst().getItemById(t.baseData_get().modelId_get())
let i="",n=""
null!=e&&(i=e.name,n=f.l.getColorStrByQuality(t.baseData_get().Quality_get()))
const l="COPY:ENTER_TIMES_CONSUME"
let a=G.V.Inst_get().GetData(G.V.Inst_get().GetRolePrefix()+l)
if(this.cfg.controllerType==Y.S.Belial&&(a=1==O.p.inst.GetClientLogicSetting(L.R.BelialConsumeItem)),a)this.RequestUseItem(t)
else{const e=new S.B
e.infoId=l,e.replaceParams.Add("1"),e.replaceParams.Add(`[${n}]${i}[-]`),e.replaceParams.Add("1"),e.replaceParams.Add(_.M.IntToString(t.baseData_get().modelId_get())),
e.replaceParams.Add("1"),e.confirmParam=t,e.confirmHandle=this._degf_RequestUseItem,e.checkChanged=(0,s.v)(this.SetNotRemindConsumeItem,this),C.t.Inst().Open(e)}}ShowBuyNoVIPTip(){
const t=this.cfg.controllerType
if(q.U.Inst_get().GetLeftCount(t)>0);else{const t=new H.N
t.showText=(0,n.T)("今日购买已达上限！"),t.tipstype=1,B.y.inst.OpenCommonMessageTips(t)}}ShowBuyExVIPTip(){const t=this.cfg.controllerType,e=q.U.Inst_get().GetLeftCount(t)
if(e>0){const i=F.U.inst.model.GetCopyAddCount(t),s=i-e,n=F.U.inst.model.GetCopyPrice(t,s),l=new S.B
if(l.replaceParams.Add(`${f.l.greenColorStr}${n}[-]`),t==Y.S.Arena)return void I.g.Inst_get().OpenArenaBuyNumView(e)
const[a,o]=F.U.inst.model.GetUpVipBossCopyBuyNum(t)
l.infoId="VIPBOSS:BUY_NOTICE",l.replaceParams.Add(`${f.l.greenColorStr}${e}[-]`),o>i?l.replaceParams.Add(`，升到VIP[047104]${a}[-]可额外购买[047104]${o}[-]次`):l.replaceParams.Add(""),
this.price=n,l.confirmParam=t,l.confirmHandle=this._degf_RequestBuy,C.t.Inst().Open(l)}else{if(t==Y.S.Arena){const[e,i]=q.U.Inst_get().GetUpVipBuy(t)
if(e>0)return void I.g.Inst_get().OpenArenaBuyNumView(0,i)}B.y.inst.ClientSysMessage(111023)}}ShowBuyVIPTip(t){const e=null!=this.cfg&&this.cfg.controllerType||null
x._.Inst().IsVipBossCopy(e)||e==Y.S.Arena?this.ShowBuyExVIPTip():0!=t&&(q.U.Inst_get().GetLeftCount(e)>0?this.BuyTip(t,e):F.U.inst.model.NeedUpVipForCopy(e)?this.BuyTipExtra(t,e):this.BuyTipLimit(t,e))
}BuyTip(t,e){const i=y.f.Inst().getItemById(t)
let s="",n="",l=""
l="COPY:ENTER_TIMES_CONSUME_BUY"
let a=q.U.Inst_get().nowPrice
if(0==a){const e=D.f.getInst().GetShopByItemId(t)
null!=e&&(a=e.price)}null!=i&&(s=i.name,n=f.l.getColorStrByQuality(i.Quality_get())),this.price=a
if(G.V.Inst_get().GetData(G.V.Inst_get().GetRolePrefix()+l))this.RequestBuy(e)
else{const i=new S.B
i.infoId=l,i.replaceParams.Add(`[${n}]${s}[-]`),i.replaceParams.Add(_.M.IntToString(a)),i.replaceParams.Add(_.M.IntToString(t)),i.replaceParams.Add("1"),
i.replaceParams.Add(_.M.IntToString(F.U.inst.model.level_get())),i.replaceParams.Add(_.M.IntToString(q.U.Inst_get().GetLeftCount(e))),i.confirmParam=e,
i.confirmHandle=this._degf_RequestBuy,i.dontClose=!0,this.vo=i,this.buyModelId=t,this.buyCopyType=e,C.t.Inst().Open(i)}}UpdateVipBuyInfo(){
if(null!=this.vo&&null!=C.t.Inst().view&&C.t.Inst().view.isShow_get()&&null!=C.t.Inst().tipVo&&C.t.Inst().tipVo.infoId==this.vo.infoId){
this.vo.replaceParams.RemoveAt(this.vo.replaceParams.Count()-1)
const t=q.U.Inst_get().GetLeftCount(this.buyCopyType)
if(this.vo.replaceParams.Add(_.M.IntToString(t)),0==t)F.U.inst.model.NeedUpVipForCopy(this.buyCopyType)?this.BuyTipExtra(this.buyModelId,this.buyCopyType):this.BuyTipLimit(this.buyModelId,this.buyCopyType)
else{let t=q.U.Inst_get().nowPrice
if(0==t){const e=D.f.getInst().GetShopByItemId(this.buyModelId)
null!=e&&(t=e.price)}this.vo.replaceParams[1]=t,C.t.Inst().tipVo=this.vo,o.i.Inst.RaiseEvent(p.g.UPDATE_INFO_TIP_VIEW)}}}BuyTipExtra(t,e){const i=y.f.Inst().getItemById(t)
let n="",l=""
null!=i&&(n=i.name,l=f.l.getColorStrByQuality(i.Quality_get()))
let a=""
a="COPY:ENTER_TIMES_CONSUME_BUY_VIP"
const o=F.U.inst.model
let r=q.U.Inst_get().nowPrice
if(0==r){const e=D.f.getInst().GetShopByItemId(t)
null!=e&&(r=e.price)}null!=i&&(n=i.name,l=f.l.getColorStrByQuality(i.Quality_get())),this.price=r
if(G.V.Inst_get().GetData(G.V.Inst_get().GetRolePrefix()+a))this.RequestBuy(e)
else{const i=new S.B
i.infoId=a,i.replaceParams.Add(`[${l}]${n}[-]`),i.replaceParams.Add(_.M.IntToString(r)),i.replaceParams.Add(_.M.IntToString(t)),i.replaceParams.Add("1"),
i.replaceParams.Add(_.M.IntToString(o.canHigherLv)),i.replaceParams.Add(_.M.IntToString(o.GetCopyAddHigher(e)-o.GetCopyAddCount(e))),i.tipstype=1,i.confirmParam=e,
i.confirmText="前往提升",i.confirmHandle=(0,s.v)(this.OpenVipPanel,this),C.t.Inst().Open(i)}}OpenVipPanel(){F.U.inst.controller.OpenPanel(!1,.5)}BuyTipLimit(t,e){
const i=y.f.Inst().getItemById(t)
let s="",n="",l=""
l="COPY:ENTER_TIMES_CONSUME_BUY_LIMIT"
let a=q.U.Inst_get().nowPrice
if(0==a){const e=D.f.getInst().GetShopByItemId(t)
null!=e&&(a=e.price)}null!=i&&(s=i.name,n=f.l.getColorStrByQuality(i.Quality_get())),this.price=a
if(G.V.Inst_get().GetData(G.V.Inst_get().GetRolePrefix()+l))this.RequestBuy(e)
else{const i=new S.B
i.infoId=l,i.replaceParams.Add(`[${n}]${s}[-]`),i.replaceParams.Add(_.M.IntToString(a)),i.replaceParams.Add(_.M.IntToString(t)),i.replaceParams.Add("1"),i.confirmParam=e,
i.confirmHandle=this._degf_RequestBuy,C.t.Inst().Open(i)}}RequestBuyTired(t){if(N.J.GetGold(a.Y.Inst.PrimaryRoleInfo_get(),N.J.GOLD_DIAMOND)>=this.price){R.N.GetInst().buyNum=1
const e=new v.H
e.buyNum=1,e.mallId=t,e.autoUse=!0,r.C.Inst.F_SendMsg(e)}else M.Y.Inst_get().OpenTip(this._degf_OnOpenDiamondTip)}RequestBuyTiredNew(t){
if(N.J.GetGold(a.Y.Inst.PrimaryRoleInfo_get(),N.J.GOLD_DIAMOND)>=this.price){const e=new b._
t==U.l.WORLDBOSS?e.type=V.K.WORLDBOSS:e.type=V.K.ANCIENTBOSS,r.C.Inst.F_SendMsg(e)}else M.Y.Inst_get().OpenTip(this._degf_OnOpenDiamondTip)}RequestBuy(t){const e=c.GF.INT(t)
e==Y.S.KUNDUN_SEAL?a.Y.Inst.PrimaryRoleInfo_get().Sonsign_Score_get()>=this.price?W.p.inst.RequestCM_CopyBuyTimes(e,1):P._.Inst_get().OpenByCurrency(N.J.ScoreStr,u.P.zero_get()):N.J.GetGold(a.Y.Inst.PrimaryRoleInfo_get(),N.J.GOLD_DIAMOND)>=this.price?e==Y.S.WORLDBOSS?k.x.Inst_get().OnConfirmBuy():W.p.inst.RequestCM_CopyBuyTimes(e,1):M.Y.Inst_get().OpenTip(this._degf_OnOpenDiamondTip)
}RequestUseItem(t){if(null!=t){const e=t
m.J.Inst_get().UseItem(e.baseData_get())}else B.y.inst.ClientStrMsg(w.r.SystemTipMessage,"无可使用道具")}RequestUseItemByID(t){const e=g.g.Inst_get().GetItemByModleID(t)
null!=e?m.J.Inst_get().UseItem(e.baseData_get()):this.bossTabType==U.l.WORLDBOSS?m.J.Inst_get().OpenTipViewById(t):B.y.inst.ClientSysMessage(101005)}GotoVIP(t){
d.N.inst.OpenUIByShortCutIDOpenUI(`${h.D.Vip};${t}`)}SetNotRemindConsumeItem(t){this.cfg.controllerType==Y.S.Belial&&O.p.inst.SendClientLogicSetting(L.R.BelialConsumeItem,t?1:0)}
OnOpenDiamondTip(t){M.Y.Inst_get().OkHandler(null)}}j._inst=null},29839:(t,e,i)=>{i.d(e,{p:()=>xs})
var s=i(82815),n=i(18045),l=i(36276),a=i(52880),o=i(38836),r=i(86133),h=i(71409),d=i(98800),c=i(96098),_=i(97461),u=i(36241),I=i(6700),m=i(68662),g=i(2689),p=i(13687),C=i(38935),S=i(41664),f=i(5924),T=i(98885),y=i(85602),A=i(72785),D=i(38962),E=i(13407),v=i(85430),w=i(80160),R=i(84229),P=i(21554),O=i(55661),L=i(87923),B=i(2457),b=i(73341),M=i(73865),G=i(24524),H=i(47786),N=i(92415),k=i(64629),U=i(89748),V=i(68637),x=i(96964),F=i(46352),q=i(14187),Y=i(96713),W=i(59136),j=i(5246),Z=i(65550),X=i(35042),K=i(33542),$=i(54918),J=i(72795),z=i(47041),Q=i(62783),tt=i(12970),et=i(21334),it=i(33065),st=i(88934),nt=i(20193),lt=i(12417),at=i(85942)
class ot{constructor(){this.copyId=-1,this._degf_DoSingleMatch=null,this._degf_DoTeamMatch=null,this._degf_DoSingleMatch=t=>this.DoSingleMatch(t),
this._degf_DoTeamMatch=t=>this.DoTeamMatch(t)}static Inst_get(){return null==ot._inst&&(ot._inst=new ot),ot._inst}TeamMatch(t){this.copyId=t,this.DoTeamMatch(null)}DoTeamMatch(t){}
SingleMatch(t){this.copyId=t
const e=new at.N
e.titleText=(0,r.T)("提示"),e.showText=(0,r.T)("单人挑战难度较大，若组队前往将享有掉率加成\n是否选择组队匹配？"),e.cancelText=(0,r.T)("单人前往"),e.okText=(0,r.T)("组队匹配"),e.tipstype=2,e.btnColorType=2,
e.cancelhandler=this._degf_DoSingleMatch,e.okhandler=this._degf_DoTeamMatch,Z.y.inst.OpenCommonMessageTips(e)}DoSingleMatch(t){t&&xs.inst.SendEnterCopy(this.copyId)}}ot._inst=null
var rt=i(97503),ht=i(85770),dt=i(72800),ct=i(44210),_t=i(42292),ut=i(77546),It=i(59377),mt=i(73206),gt=i(66788),pt=i(85682),Ct=i(56937),St=i(18202),ft=i(31222),Tt=i(49484),yt=i(98789),At=i(95721),Dt=i(15965),Et=i(94148),vt=i(22107),wt=i(93353),Rt=i(29795),Pt=i(63076),Ot=i(47520),Lt=i(22878),Bt=i(92679),bt=i(31922),Mt=i(90034),Gt=i(40821),Ht=i(70391),Nt=i(66345),kt=i(59265),Ut=i(48481),Vt=i(79534),xt=i(73423),Ft=i(54095),qt=i(50526),Yt=i(42983),Wt=i(22365),jt=i(85465),Zt=i(6071),Xt=i(94409),Kt=i(98537),$t=i(71881),Jt=i(40312),zt=i(78967),Qt=i(83900),te=i(21267),ee=i(94075),ie=i(51704),se=i(61149),ne=i(34843),le=i(52420),ae=i(50890),oe=i(57553),re=i(57651),he=i(99535),de=i(84587),ce=i(15771),_e=i(86605),ue=i(40162)
class Ie{constructor(){this.copySuccessTime=null,this.copySuccessReward=null,this.currentCopyId=0,this.evaluateLevel=0,this.displayExp=null,this.killMonsterNum=0,
this.historyTopExp=null,this.copySuccessTime=new D.X,this.copySuccessReward=new D.X}static Inst_get(){return null==Ie._Inst&&(Ie._Inst=new Ie),Ie._Inst}Reset(){
null!=this.copySuccessTime&&this.copySuccessTime.LuaDic_Clear(),null!=this.copySuccessReward&&this.copySuccessReward.LuaDic_Clear()}}Ie._Inst=null
var me=i(1046),ge=i(56632),pe=i(83496),Ce=i(90912),Se=i(84708),fe=i(9986),Te=i(93877),ye=i(61911),Ae=i(99294),De=i(9057),Ee=i(57834),ve=i(8889),we=i(72005),Re=i(60130),Pe=i(88653),Oe=i(33314)
class Le extends De.x{constructor(){super(),this.jobpic=null,this.label1=null,this.label2=null,this.confirmtxt=null,this.leader=null,this.okspi=null,this.matching=null,
this.confirmingtxt=null,this.confirfail=null,this.effconfirm=null,this.effconfirming=null,this.okkanimation=null,this.offlineanimation=null,this._info=null,this._listener=null,
this._degf_updateOnline=null,this._degf_updateOnline=t=>this.updateOnline(t)}info_get(){return this._info}InitView(){super.InitView(),this.jobpic=new we.w,
this.jobpic.setId(this.FatherId,this.FatherComponentID,1),this.label1=new Te.Q,this.label1.setId(this.FatherId,this.FatherComponentID,2),this.label2=new Te.Q,
this.label2.setId(this.FatherId,this.FatherComponentID,3),this.confirmtxt=new Te.Q,this.confirmtxt.setId(this.FatherId,this.FatherComponentID,4),this.leader=new Ae.z,
this.leader.setId(this.FatherId,this.FatherComponentID,5),this.okspi=new Ae.z,this.okspi.setId(this.FatherId,this.FatherComponentID,6),this.matching=new Ae.z,
this.matching.setId(this.FatherId,this.FatherComponentID,7),this.confirmingtxt=new Te.Q,this.confirmingtxt.setId(this.FatherId,this.FatherComponentID,8),this.confirfail=new Ae.z,
this.confirfail.setId(this.FatherId,this.FatherComponentID,9),this.effconfirm=new ve.$,this.effconfirm.setId(this.FatherId,this.FatherComponentID,10),this.effconfirming=new ve.$,
this.effconfirming.setId(this.FatherId,this.FatherComponentID,11),this._listener=new Ee.i}SetData(t){this._info=t
const e=t
null!=this._info?(this.label1.textSet(e.name),this.label2.textSet(`${e.level}`),this.jobpic.spriteNameSet(Oe.Z.GetJobIcon(e.job,e.sex,!1)),
e.entercopystate?(this.leader.SetActive(!1),this.okspi.SetActive(!0),this.matching.SetActive(!1)):(this.leader.SetActive(!1),this.okspi.SetActive(!1),this.matching.SetActive(!0)),
1==e.onlineStatus?this.jobpic.SetColor(new Pe.I(1,1,1,1)):this.jobpic.SetColor(new Pe.I(.227,.227,.227,1)),this.jobpic.node.SetActive(!0),this.confirfail.SetActive(!1),
Re.O.AddUIEffectSortOrderBind(this.effconfirm.node),Re.O.AddUIEffectSortOrderBind(this.effconfirming.node)):(this._listener=null,this.label1.textSet(""),
this.label1.SetColor(new Pe.I(.892,.682,.353,1)),this.label2.textSet(""),this.leader.SetActive(!1),this.matching.SetActive(!1),this.jobpic.node.SetActive(!1),
this.okspi.SetActive(!1),this.confirfail.SetActive(!1))}updateOnline(t){
1==this._info.onlineStatus?this.jobpic.SetColor(new Pe.I(1,1,1,1)):this.jobpic.SetColor(new Pe.I(.227,.227,.227,1))}SetOk(){this._info.entercopystate?(this.okspi.SetActive(!0),
this.matching.SetActive(!1),this.confirfail.SetActive(!1)):(this.okspi.SetActive(!1),this.matching.SetActive(!1),this.confirfail.SetActive(!0))}Clear(){}Destroy(){}}
class Be extends ye.f{constructor(){super(),this.closeBtn=null,this.copyname=null,this.item1=null,this.item2=null,this.item3=null,this.copyId=0,this.mapId=0,this.isMap=!1,
this.itemarr=null,this._degf_closeHandler=null,this.tipLabel=null,this._degf_closeHandler=(t,e)=>this.closeHandler(t,e)}InitView(){super.InitView(),this.closeBtn=new fe.W,
this.closeBtn.setId(this.FatherId,this.FatherComponentID,1),this.copyname=new Te.Q,this.copyname.setId(this.FatherId,this.FatherComponentID,2),this.item1=new Le,
this.item1.setBinderId(this.FatherId,this.FatherComponentID,3),this.item2=new Le,this.item2.setBinderId(this.FatherId,this.FatherComponentID,4),this.item3=new Le,
this.item3.setBinderId(this.FatherId,this.FatherComponentID,5),this.tipLabel=new Te.Q,this.tipLabel.setId(this.FatherId,this.FatherComponentID,6),this.itemarr=new y.Z,
this.itemarr.Add(this.item1),this.itemarr.Add(this.item2),this.itemarr.Add(this.item3),this.tipLabel.node.SetActive(!1),this.addListeners()}OnAddToScene(){this.addListeners(),
this.updateData()}addListeners(){this.AddClickEvent(this.closeBtn,this._degf_closeHandler)}removeListeners(){this.RemoveClickEvent(this.closeBtn,this._degf_closeHandler)}
updateData(){if(this.isMap){const t=et.p.Inst_get().GetMapById(this.mapId).name
this.copyname.textSet(t)}else{let t=""
const e=G.o.Inst().getItemById(this.copyId)
t=e.controllerType==dt.S.Belial?e.name+((0,r.T)("第")+(G.o.Inst().getBelialLayerById(this.copyId)+((0,r.T)("层(")+(e.minLevelLimit+((0,r.T)("级-")+(e.maxLevelLimit+(0,
r.T)("级)"))))))):e.controllerType==dt.S.BloodTown?e.name+((0,r.T)("第")+(G.o.Inst().getBloodLayerById(this.copyId)+((0,r.T)("层(")+(e.minLevelLimit+((0,
r.T)("级-")+(e.maxLevelLimit+(0,r.T)("级)"))))))):(e.controllerType,dt.S.AsuramTaskCopy,e.name),this.copyname.textSet(t)}}updateState(t){}closeHandler(t,e){null==e&&(e=0),
null==t&&(t=0),0==t&&0==e||xs.inst.CM_DealTeamCopyOp(!1),ft.N.inst.ClosePanel()}Clear(){}Destroy(){}}var be=i(35803),Me=i(41670),Ge=i(70478),He=i(38045),Ne=i(81562),ke=i(19176)
let Ue=null,Ve=null,xe=null,Fe=null,qe=null,Ye=null,We=null,je=null,Ze=null,Xe=null,Ke=null,$e=null,Je=null,ze=null,Qe=null,ti=null,ei=null,ii=null,si=null,ni=null,li=null,ai=null,oi=null,ri=null,hi=null,di=null,ci=null,_i=null,ui=null,Ii=null,mi=null,gi=null,pi=null
class Ci{static __StaticInit(){Ue=table.insert,Ve=table.sort,xe=table.remove,Fe=y.Z.new,qe=y.Z.Add,Ye=y.Z.AddRang,We=y.Z.Clear,je=y.Z.Contains,Ze=y.Z.Insert,Xe=y.Z.InsertRange,
Ke=y.Z.Remove,$e=y.Z.RemoveAt,Je=y.Z.IndexOf,ze=y.Z.Count,Qe=y.Z.Length,ti=y.Z.RemoveRange,ei=y.Z.GetRange,ii=y.Z.Pop,si=y.Z.Reverse,ni=y.Z.Sort,li=D.X.new,ai=D.X.LuaDic_Add,
oi=D.X.LuaDic_SetItem,ri=D.X.LuaDic_IsnilValue,hi=D.X.LuaDic_GetItem,di=D.X.LuaDic_Count,ci=D.X.LuaDic_ContainsKey,_i=D.X.LuaDic_AddOrSetItem,ui=D.X.LuaDic_Keys,
Ii=D.X.LuaDic_Values,mi=D.X.LuaDic_Clear,gi=D.X.LuaDic_ContainsValue,pi=D.X.LuaDic_Remove}constructor(){this.copyType=0,this.copyId=0,this.copyRes=null,this.entered=!1,
this.rewardData=null,this._mgr=null,this.needShowCopyTitle=!1,this.successPanelType=0,this._def__OnLoadedMap=null,this.copyTimeId=null,this._def__OnLoadedMap=t=>{
this._OnLoadedMap()}}_Mgr_set(t){this._mgr=t}Init(){return!0}ReadyControl(){this.entered=!1}UnReadyControl(){this.entered=!1}OnEnterTimeEnd(){}SM_EnterCopyHandle(t){
const e=this._mgr
null!=e.cur&&e.cur.entered&&e.cur.ClearCopy(),t.copyId==this.copyId||(0!=this.copyId&&gt.Y.LogError(`SM_EnterCopyHandle 准备的和服务返回的copyid不一样 copyId: ${this.copyId} serverCopyId:${t.copyId}`),
e.ClearCopy(),e.ReadyCopyControl(t.copyId),null==e.cur)?0==this.entered&&(this.EnterCopy(),this.entered=!0):e.cur.SM_EnterCopyHandle(t)}EnterCopy(){}SM_EndEnterCopyHandle(t){
gt.Y.Log("end enter copy")
const e=t
this.copyTimeId=e.time,null!=e&&(0==this.entered&&(this.EnterCopy(),this.entered=!0),this.EndEnterCopy())}EndEnterCopy(){
0==ke.S.getInst().InHang&&this.AutoHang()&&u._.getInst().startHang()}SM_CopyRewardHandle(t){const e=t
if(e.startTime!=ht.a.Inst.serverCopyTimeId)return
this.rewardData=e
1==e.finishStatus?this.OpenSuccessPanel():2==e.finishStatus&&this.OpenFailPanel(),this.CopyReward(),_.i.Inst.RaiseEvent(Bt.g.COPY_END)}CopyReward(){}ClearCopy(){
gt.Y.Log("clear copy"),ht.a.Inst.isPause=!1,this.entered&&(this.entered=!1,this.copyId=0,this.ClearCopyNow())}ClearCopyNow(){}SM_EndCopyHandle(t){this.EndCopy()}EndCopy(){}
SM_LeaveCopyHandle(t){gt.Y.Log("leave copy"),t.copyId==this.copyId&&(this.LeaveCopy(),this._mgr.ClearCopy())}CM_ExitCopy(){this.LeaveCopy(),this._mgr.ClearCopy()}LeaveCopy(){
_.i.Inst.AddEventHandler(Bt.g.MAP_LOAD_COMPELETE,this._def__OnLoadedMap)}_OnLoadedMap(){_.i.Inst.RemoveEventHandler(Bt.g.MAP_LOAD_COMPELETE,this._def__OnLoadedMap),
this.OnLeaveCopyToMap()}OnLeaveCopyToMap(){}IsInCopy(){return this.entered}AutoHang(){return null==this.copyRes||this.copyRes.helperOpen}OpenExitPanel(){}OpenPanel(){}
ClosePanel(){}OpenLoadingPanel(){this.needShowCopyTitle&&CopyBaseUIControl.Inst.OpenLoadingPanel()}OpenSuccessPanel(){
0==this.successPanelType?BloodSuccessControl.inst.OpenPanel(ht.a.Inst.serverCopyId,ht.a.Inst.copySuccessTime,ht.a.Inst.copySuccessReward):1==this.successPanelType&&CopyBaseUIControl.inst.OpenSuccessPanelNoEvaluate(this.rewardData)
}OpenFailPanel(){BloodDefeatControl.inst.penPanel()}}class Si extends Ci{Init(){return!0}EnterCopy(){super.EnterCopy()}EndEnterCopy(){super.EndEnterCopy(),
xs.inst.enterTimerDic.LuaDic_AddOrSetItem(this.copyRes.controllerType,this.copyTimeId.ToNum())}CopyReward(){super.CopyReward()}ClearCopyNow(){}EndCopy(){super.EndCopy()}
OnLeaveCopyToMap(){super.OnLeaveCopyToMap(),W.c.ins.ClearCopyFight(),Ne.P.ins.ClearCopyFight()}OpenPanel(){gt.Y.Log("进入转生boss副本OpenPanel")}ClosePanel(){
gt.Y.Log("离开转生boss副本ClosePanel")}OpenSuccessPanel(){W.c.ins.OpenBossSucPanel()}OpenFailPanel(){W.c.ins.OpenBossFailPanel()}}var fi=i(57411)
let Ti,yi=null,Ai=null,Di=null,Ei=null,vi=null,wi=null,Ri=null,Pi=null,Oi=null,Li=null,Bi=null,bi=null,Mi=null,Gi=null,Hi=null,Ni=null,ki=null,Ui=null,Vi=null,xi=null,Fi=null,qi=null,Yi=null,Wi=null,ji=null,Zi=null,Xi=null,Ki=null,$i=null,Ji=null,zi=null,Qi=null,ts=null
class es extends Ci{static __StaticInit(){yi=table.insert,Ai=table.sort,Di=table.remove,Ei=y.Z.new,vi=y.Z.Add,wi=y.Z.AddRang,Ri=y.Z.Clear,Pi=y.Z.Contains,Oi=y.Z.Insert,
Li=y.Z.InsertRange,Bi=y.Z.Remove,bi=y.Z.RemoveAt,Mi=y.Z.IndexOf,Gi=y.Z.Count,Hi=y.Z.Length,Ni=y.Z.RemoveRange,ki=y.Z.GetRange,Ui=y.Z.Pop,Vi=y.Z.Reverse,xi=y.Z.Sort,Fi=D.X.new,
qi=D.X.LuaDic_Add,Yi=D.X.LuaDic_SetItem,Wi=D.X.LuaDic_IsnilValue,ji=D.X.LuaDic_GetItem,Zi=D.X.LuaDic_Count,Xi=D.X.LuaDic_ContainsKey,Ki=D.X.LuaDic_AddOrSetItem,$i=D.X.LuaDic_Keys,
Ji=D.X.LuaDic_Values,zi=D.X.LuaDic_Clear,Qi=D.X.LuaDic_ContainsValue,ts=D.X.LuaDic_Remove}constructor(){super(),this._degf_EnterWufengEndHandler=null,this.exitElementId=null,
this._degf_EnterWufengEndHandler=t=>this.EnterWufengEndHandler(t)}EnterWufengEndHandler(t){ft.N.inst.RemoveAllSingleDirectionAnimOnce(),
0!=this.exitElementId&&(mt.X.Inst.DeleteElement(this.exitElementId),this.exitElementId=0)}Init(){return!0}EnterCopy(){super.EnterCopy(),nt.D.Inst_get().dropVecList.Clear(),
nt.D.Inst_get().rewards=null,ht.a.Inst_get().CopyIsAutoHang(),L.l.CheckTrigger(B.u.COND_TYPE_ENTER_COPY_BY_TYPE_VAL,1)
const t=new fi.M
C.C.Inst.F_SendMsg(t)}EndEnterCopy(){super.EndEnterCopy()}CopyReward(){super.CopyReward()}ClearCopyNow(){super.ClearCopyNow(),nt.D.Inst_get().dropVecList.Clear(),
nt.D.Inst_get().rewards=null,it.x.Inst_get().CloseAfterLeave(),u._.getInst().startHang(!1)}EndCopy(){super.EndCopy()}OnLeaveCopyToMap(){super.OnLeaveCopyToMap()}OpenPanel(){}
ClosePanel(){}OpenSuccessPanel(){}OpenFailPanel(){}Test1(){return!0}S_Test(){return!0}}class is{static __StaticInit(){Ti=D.X.LuaDic_GetItem}constructor(){this._copyControls=null,
this.cur=null,this._copyControls=new D.X}InitAllControl(){this._copyControls.LuaDic_AddOrSetItem(dt.S.WORLDBOSS,new es),
this._copyControls.LuaDic_AddOrSetItem(dt.S.WORLDBOSS_NEW,new es),this._copyControls.LuaDic_AddOrSetItem(dt.S.REBIRTH_BOSS,new Si)
for(const[t,e]of(0,o.V5)(this._copyControls)){const t=e
t._Mgr_set(this),t.Init()}}HasCur(){return null!=this.cur}HasCopyControl(t){return this._copyControls.LuaDic_ContainsKey(t)}ReadyCopyControl(t){gt.Y.Log(`ReadyCopyControl ${t}`)
const e=G.o.Inst().getItemById(t)
if(null!=this.cur){if(this.cur.copyId==t)return
gt.Y.Log(`ReadyCopyControl error 新请求copyId：${t} 当前的:${this.cur.copyId}`),this.ClearCopy()}this.cur=this._InitCopyControl(e.groupId),null!=this.cur&&(this.cur.copyId=t,
this.cur.copyRes=e,this.cur.ReadyControl())}ClearCopy(){gt.Y.Log(`ClearCopy ${null!=this.cur&&(0,He.tw)(this.cur.copyId)||"nil"}`),null!=this.cur&&(this.cur.ClearCopy(),
this.cur=null)}_InitCopyControl(t){return Ti(this._copyControls,t)}GetController(t){return this._InitCopyControl(t)}Test1(){return!0}S_Test(){return!0}}is.Inst=null,
is.__StaticInit()
var ss,ns,ls,as,os,rs,hs,ds,cs,_s,us,Is,ms,gs,ps,Cs,Ss,fs,Ts,ys,As,Ds,Es,vs,ws,Rs,Ps,Os,Ls,Bs,bs,Ms,Gs,Hs,Ns,ks,Us=i(78417)
function Vs(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let xs=(ss=(0,_t.gK)("CopyBaseControl"),ns=(0,h.GH)(N.k.SM_CopyUpdateEndTime),ls=(0,
h.GH)(N.k.SM_OxNewYearBossSettlement),as=(0,h.GH)(N.k.SM_RobotCopySettlement),os=(0,h.GH)(N.k.SM_FireAllExp),rs=(0,h.GH)(N.k.SM_SubmitFirePlayers),hs=(0,
h.GH)(N.k.SM_SubmitFireItem),ds=(0,h.GH)(N.k.Sm_FireInfo),cs=(0,h.GH)(N.k.SM_SingleMonsterPanel),_s=(0,h.GH)(N.k.SM_PersonalBossSettlement),us=(0,h.GH)(N.k.SM_LostAbyssCopyEnd),
Is=(0,h.GH)(N.k.SM_ClientStopHang),ms=(0,h.GH)(N.k.SM_AutoEnterCopyError),gs=(0,h.GH)(N.k.SM_EndCopy),ps=(0,h.GH)(N.k.SM_EvaluateLevelUpdate),Cs=(0,
h.GH)(N.k.SM_BloodtownRewardInfo),Ss=(0,h.GH)(N.k.SM_CopyClearCD),fs=(0,h.GH)(N.k.SM_DemonlazaInfo),Ts=(0,h.GH)(N.k.SM_DemolazaItems),ys=(0,h.GH)(N.k.SM_DemolazaData),As=(0,
h.GH)(N.k.SM_CopySweep),Ds=(0,h.GH)(N.k.SM_CopyNotice),Es=(0,h.GH)(N.k.SM_CopyEncourage),vs=(0,h.GH)(N.k.SM_UpdateCopyRecords),ws=(0,h.GH)(N.k.SM_DynamicBlockRound),Rs=(0,
h.GH)(N.k.SM_CopyRound),Ps=(0,h.GH)(N.k.SM_CopyTarget),Os=(0,h.GH)(N.k.SM_CopyReward),Ls=(0,h.GH)(N.k.SM_EnterCopy),Bs=(0,h.GH)(N.k.SM_EnterCopyFail),bs=(0,
h.GH)(N.k.SM_EndEnterCopy),Ms=(0,h.GH)(N.k.SM_LeaveCopy),Gs=(0,h.GH)(N.k.SM_SceneBoxVO),ss((ks=class t{static get inst(){return t._inst||(t._inst=new t),t._inst}constructor(){
this.bloodTownView=null,this.belialView=null,this.dreamlandView=null,this.copyteamenter=null,this.recordDic=null,this.enterTimerDic=null,this.checkTriggerInterval=-1,
this.checkTriggerCopyId=0,this.checkTriggerCopyGroupId=0,this.curstage=0,this.curchildstage="",this.curround=0,this.lastStage=-1,this.copyReward=null,this.isUse=!1,
this.useSkillId=0,this.exitElementId=0,this.teamcopyid=0,this.teamMapId=0,this.isMap=!1,this.teamleftTime=0,this.areaCheckTimerId=-1,this._copyRuntimeMgr=void 0,
this._degf_CallDestory=null,this._degf_EnterCopyReq=null,this._degf_EnterWufengEndHandler=null,this._degf_OnArenaOverUp=null,this._degf_OnCheckTriggerGuide=null,
this._degf_SM_BloodtownRewardInfoHandler=null,this._degf_SM_ClientStopHangHandler=null,this._degf_SM_CopyClearCDHandle=null,this._degf_SM_CopyEncourageHandle=null,
this._degf_SM_CopyRewardHandle=null,this._degf_SM_CopyRoundHandler=null,this._degf_SM_CopySweepHandle=null,this._degf_SM_CopyTargetHandle=null,
this._degf_SM_DemonlazaInfoHandler=null,this._degf_SM_DemolazaItemsHandler=null,this._degf_SM_DemolazaDataHandler=null,this._degf_SM_DynamicBlockRoundHandle=null,
this._degf_SM_EndCopyHandle=null,this._degf_SM_EndEnterCopyHandle=null,this._degf_SM_EnterCopyHandle=null,this._degf_SM_EnterCopyFailHandle=null,
this._degf_SM_EvaluateLevelUpdateHandler=null,this._degf_SM_LeaveCopyHandle=null,this._degf_SM_PersonalBossSettlementHandler=null,this._degf_SM_LostAbyssCopyEnd=null,
this._degf_SM_SceneBoxVOHandle=null,this._degf_SM_CopyNoticeHandler=null,this._degf_SM_UpdateCopyRecordsHandle=null,this._degf_ShowlTeamApplyComplete=null,
this._degf_HandleAreaCheck=null,this._degf_KundunSealCopyRewardHandler=null,this.updateRecordList=null,this.rounds=null,this._degf_CallDestory=()=>this.CallDestory(),
this._degf_EnterCopyReq=t=>this.EnterCopyReq(t),this._degf_EnterWufengEndHandler=t=>this.EnterWufengEndHandler(t),this._degf_OnArenaOverUp=()=>this.OnArenaOverUp(),
this._degf_OnCheckTriggerGuide=()=>this.OnCheckTriggerGuide(),this._degf_SM_BloodtownRewardInfoHandler=t=>this.SM_BloodtownRewardInfoHandler(t),
this._degf_SM_ClientStopHangHandler=t=>this.SM_ClientStopHangHandler(t),this._degf_SM_CopyClearCDHandle=t=>this.SM_CopyClearCDHandle(t),
this._degf_SM_CopyEncourageHandle=t=>this.SM_CopyEncourageHandle(t),this._degf_SM_CopyRewardHandle=t=>this.SM_CopyRewardHandle(t),
this._degf_SM_CopyRoundHandler=t=>this.SM_CopyRoundHandler(t),this._degf_SM_CopySweepHandle=t=>this.SM_CopySweepHandle(t),
this._degf_SM_CopyTargetHandle=t=>this.SM_CopyTargetHandle(t),this._degf_SM_DemonlazaInfoHandler=t=>this.SM_DemonlazaInfoHandler(t),
this._degf_SM_DemolazaItemsHandler=t=>this.SM_DemolazaItemsHandler(t),this._degf_SM_DemolazaDataHandler=t=>this.SM_DemolazaDataHandler(t),
this._degf_SM_DynamicBlockRoundHandle=t=>this.SM_DynamicBlockRoundHandle(t),this._degf_SM_EndCopyHandle=t=>this.SM_EndCopyHandle(t),
this._degf_SM_EndEnterCopyHandle=t=>this.SM_EndEnterCopyHandle(t),this._degf_SM_EnterCopyHandle=t=>this.SM_EnterCopyHandle(t),
this._degf_SM_EnterCopyFailHandle=t=>this.SM_EnterCopyFailHandle(),this._degf_SM_EvaluateLevelUpdateHandler=t=>this.SM_EvaluateLevelUpdateHandler(t),
this._degf_SM_LeaveCopyHandle=t=>this.SM_LeaveCopyHandle(t),this._degf_SM_PersonalBossSettlementHandler=t=>this.SM_PersonalBossSettlementHandler(t),
this._degf_SM_LostAbyssCopyEnd=t=>this.SM_LostAbyssCopyEnd(t),this._degf_SM_SceneBoxVOHandle=t=>this.SM_SceneBoxVOHandle(t),
this._degf_SM_CopyNoticeHandler=t=>this.SM_CopyNoticeHandler(t),this._degf_SM_UpdateCopyRecordsHandle=t=>this.SM_UpdateCopyRecordsHandle(t),
this._degf_ShowlTeamApplyComplete=t=>this.ShowlTeamApplyComplete(t),this._degf_HandleAreaCheck=()=>this.HandleAreaCheck(),
this._degf_KundunSealCopyRewardHandler=t=>this.KundunSealCopyRewardHandler(t),this.recordDic=ht.a.Inst_get().copyRecordDic,this.enterTimerDic=ht.a.Inst_get().copyEnterTimer,
this.updateRecordList=new y.Z,this.addLis(),is.Inst=new is,this._copyRuntimeMgr=is.Inst,this._copyRuntimeMgr.InitAllControl()}GetCopyStartTime(t){
return this.enterTimerDic.LuaDic_ContainsKey(t)?this.enterTimerDic[t]:0}RequestCM_CopyBuyTimes(t,e){const i=new qt.b
i.copyType=t,e<=0&&(e=1),i.times=e,C.C.Inst.F_SendMsg(i),gt.Y.LogWarning(`调试打印：购买type ${t} times ${e}`)}CM_CopySweep(t,e){const i=new Yt.i
i.copyId=t,i.sweepTimes=e,C.C.Inst.F_SendMsg(i)}addLis(){Ge._.GetInst().RegMsg()}SM_CopyUpdateEndTimeHandle(t){ht.a.Inst_get().exiTimer=t.endTime,
At.o.IsNullOrZero(t.endTime)||(ht.a.Inst_get().soonEndTime=t.endTime.ToNum()),_.i.Inst.RaiseEvent(Bt.g.COPY_UPDATE_END_TIME)}SM_OxNewYearBossSettlementHandle(t){const e=t
if(null!=e){const t=new y.Z,i=e.andReward.rewards
for(let e=0;e<=i.count-1;e++){const s=Pt.M.wrapReward(i[e])
t.Add(s)}ht.a.Inst_get().copyEndState=1,ht.a.Inst_get().copyRewardList=t,ht.a.Inst_get().isNewRecord=e.newRecord,Y.n.inst.OpenSuccessOrDefeatPanel()}}
SM_RobotCopySettlementHandle(t){const e=t
null!=e&&(ht.a.Inst_get().copyEndState=e.win?1:2,ht.a.Inst_get().copyRewardList=null,Y.n.inst.OpenSuccessOrDefeatPanel())}SM_LostAbyssReliveShowEffect(t){
q.u.Inst_Get().isvipdided=!0,F.o.Inst_Get().UpdateBattleBuff(!0)}SM_FireAllExpHandle(t){const e=t
Se.H.Inst_get().FireAllExp_set(e),_.i.Inst.RaiseEvent(Bt.g.RYALLIANCE_REFRESHEXP)}SM_SubmitFirePlayersHandle(t){const e=t
Se.H.Inst_get().SubmitFirePlayers_set(e),Us.L.GetInst().CloseSubmitFireItemView(),Us.L.GetInst().OpenBeginFireItemView()}SM_AsuramActivityEndHandle(t){const e=t.type
if(1==e)Se.H.Inst_get().SubmitFireEndTime_set(-1),Se.H.Inst_get().BornFireEndTime_set(-1),I.L.Instance_get().ClearDynamicBlock()
else if(2==e){const t=p.b.Inst.currentMapId_get()
Se.H.Inst_get().ChuanGongEndTime_set(-1),M.y.Inst.UpdateBtns(t)}else 3==e&&Se.H.Inst_get().SubmitFireEndTime_set(-1)
1==e&&(Us.L.GetInst().CloseSubmitFireItemView(),re.i.ins.OpenMainUI(),re.i.ins.OpenTaskTempView(),Y.n.inst.CloseRyAllianceCopyBornFireView()),
Us.L.GetInst().RefreshBornFireClientObj()}SM_AsuramActivityOpenHandle(t){const e=t,i=e.type,s=e.endTime
let n
if(1==i)Se.H.Inst_get().BornFireEndTime_set(s),n=!0
else if(2==i){const t=p.b.Inst.currentMapId_get()
Se.H.Inst_get().ChuanGongEndTime_set(s),M.y.Inst.UpdateBtns(t)}else 3==i&&(Se.H.Inst_get().SubmitFireEndTime_set(s),n=!0)
s-m.D.serverTime_get()<0&&gt.Y.LogError(`SM_AsuramActivityOpenHandle type:${i} leftTime:${s-m.D.serverTime_get()}`)
const l=p.b.Inst.currentMapId_get()
"ASURAM_SCENE"==et.p.Inst_get().GetMapById(l).controllerType&&Us.L.GetInst().IsBornFireActivityOpen()&&(re.i.ins.CloseMainUI(),re.i.ins.CloseTaskTempView(),
Y.n.inst.OpenRyAllianceCopyBornFireView()),Us.L.GetInst().RefreshBornFireClientObj()}SM_SubmitFireItemHandle(t){const e=t
Us.L.GetInst().FireOh(e.resourceId)}Sm_FireInfoHandle(t){const e=t
Se.H.Inst_get().FireInfoMsg_set(e),Us.L.GetInst().RefreshBornFireClientObj(),_.i.Inst.RaiseEvent(Bt.g.RYALLIANCE_REFRESHFIREMSG),_.i.Inst.RaiseEvent(Bt.g.RYALLIANCE_REFRESHEXP)}
SM_SingleMonsterPanelHandle(t){const e=t
A.c.DebugLog((0,r.T)("打开副本成功或失败面板")),null!=e&&(e.win?ht.a.Inst_get().copyEndState=1:ht.a.Inst_get().copyEndState=2,Dt.V.Inst_Get().SM_SingleMonsterPanel=e,
Y.n.inst.OpenSuccessOrDefeatPanel())}KundunSealCopyRewardHandler(t){}SM_PersonalBossSettlementHandler(t){const e=t
A.c.DebugLog((0,r.T)("打开副本成功或失败面板")),null!=e&&(ht.a.Inst_get().copyEndState=e.finishStatus,be.D.Inst_get().SM_PersonalBossSettlementHandler(e),Y.n.inst.OpenSuccessOrDefeatPanel(),
ht.a.Inst_get().waitTime=e.cdWaitTime)}SM_LostAbyssCopyEnd(t){const e=t
A.c.DebugLog((0,r.T)("打开副本成功或失败面板")),null!=e&&(ht.a.Inst_get().copyEndState=e.finishStatus,q.u.Inst_Get().SM_LostAbyssCopyEnd(e),Y.n.inst.OpenSuccessOrDefeatPanel(),
q.u.Inst_Get().isvipdided=!1,F.o.Inst_Get().UpdateBattleBuff(!1))}SM_ClientStopHangHandler(t){u._.getInst().endHang()}SM_AutoEnterCopyErrorHandle(t){
It.M.Inst_get().SetCoolTimer(t.copyId)}SM_EndCopyHandle(t){const e=t
e.isWin?S.j.Inst.PlayByDivision("CopyWin"):(S.j.Inst.PlayByDivision("CopyFailure"),Zt.T.ins.Pause_Set(!0),Jt.B.Inst_get().SetAutoCollectJigsaw(!1)),M.y.Inst.ClearCopyExitTime(),
Y.n.inst.CloseNoRecoverPanel(),Y.n.inst.CloseSoonEndTimeView()
const i=G.o.Inst().getItemById(ht.a.Inst_get().currentCopyId)
null!=i&&(e.isWin||null==i.failAccess||i.controllerType!=dt.S.Exorcism&&i.controllerType!=dt.S.Crime&&ue.v.inst.OpenPanel(),
null!=i&&i.controllerType!=dt.S.Plot&&i.controllerType!=dt.S.eMap&&(this.checkTriggerCopyId=ht.a.Inst_get().currentCopyId,this.checkTriggerCopyGroupId=i.groupId,
this.checkTriggerInterval=f.C.Inst_get().SetInterval(this._degf_OnCheckTriggerGuide,i.endTime,1)),
i.controllerType==dt.S.Plot&&3==i.plotType?e.isWin?Ot.s.GetInst().copystate=2:Ot.s.GetInst().copystate=1:Ot.s.GetInst().copystate=0,
i.controllerType==dt.S.RolandDefend1&&e.isWin&&ae.h.GetInst().OpenCopySuccess1(),i.controllerType==dt.S.UnlockMapBoss&&(e.isWin?(ht.a.Inst_get().copyEndState=1,
tt.F.getInst().flyItemMapId=0,tt.F.getInst().unlockBossWinUnlockMapId=et.p.Inst_get().GetUnLockMapByCopyId(i.id)):(ht.a.Inst_get().copyEndState=2,tt.F.getInst().flyItemMapId=0)),
i.controllerType==dt.S.MapPassBoss&&(e.isWin||te.u.Inst().SetAutoPass(!1,null),Qt.N.Inst().CloseMapPassAlertView()),$t.P.Inst.CheckTrigger(bt.z.COND_TYPE_PASS_COPY,i.id),
this.ClosePanelAfterCopyEnd())}ClosePanelAfterCopyEnd(){Y.n.inst.ClosePanelAfterCopyEnd()}OnCheckTriggerGuide(){
L.l.CheckTrigger(B.u.COND_TYPE_CopyResult_VAL,this.checkTriggerCopyId),L.l.CheckTrigger(B.u.COND_TYPE_CopyResult_BY_GROUP_VAL,this.checkTriggerCopyGroupId)}SendEnterCopy(t,e,i){
if(!this.IsCopyFix(t))return
if(x.o.getInstance().InKarima())return void Z.y.inst.ClientSysMessage(10300012)
null==i&&(i=1),null==e&&(e=!1)
const s=new Wt.w
s.copyId=t,s.multiple=i,s.slot=e,this.EnterCopyReq(s)}EnterCopyReq(t){const e=t
C.C.Inst.F_SendMsg(e)}IsCopyFix(t){let e=!0
const i=G.o.Inst().getItemById(t)
let s=H.x.Inst().getItemStrById(111031)
const n=i.GetVipLimit(),l=i.GetLvConditionLimit()
if(d.Y.Inst.IsVipFix(n)){if(!d.Y.Inst.IsLevelFix(l)){let t=H.x.Inst().getItemStrById(111030)
const i=T.M.s_LEFT_B_K_CHAR+(T.M.IntToString(0)+T.M.s_RIGHT_B_K_CHAR_DOT)
t=T.M.Replace(t,i,l.toString()),s=t+s,Z.y.inst.ClientSysStrMsg(s),e=!1}}else{let t=H.x.Inst().getItemStrById(111029)
const i=T.M.s_LEFT_B_K_CHAR+(T.M.IntToString(0)+T.M.s_RIGHT_B_K_CHAR_DOT)
t=T.M.Replace(t,i,n.toString()),s=t+s,Z.y.inst.ClientSysStrMsg(s),e=!1}return e}SendSweepCopy(t,e){const i=new Yt.i
i.copyId=t,i.sweepTimes=e,C.C.Inst.F_SendMsg(i)}SM_EvaluateLevelUpdateHandler(t){const e=t
null!=e&&(ct.w.GetInst().HandleEvaluate(e),be.D.Inst_get().UpdateEvaluate(e),q.u.Inst_Get().UpdateEvaluate(e))}SM_BloodtownRewardInfoHandler(t){const e=t
A.c.DebugLog((0,r.T)("打开副本成功或失败面板")),null!=e&&(ct.w.GetInst().HandleStageRewards(e),ht.a.Inst_get().copyEndState=e.finishStatus,Y.n.inst.OpenSuccessOrDefeatPanel())}
SM_CopyClearCDHandle(t){const e=t
e.ignoreNotify||Z.y.inst.ClientSysMessage(107028)
const i=G.o.Inst().getItemById(e.copyId)
if(null==i)return
const s=ht.a.Inst_get().copyCoolTimeDic
s.LuaDic_ContainsKey(i.controllerType)&&s.LuaDic_Remove(i.controllerType),this.SetCoolTimer(i.controllerType,!0)}SM_DemonlazaInfoHandler(t){ge.E.Inst_get().msgdata=t
const e=Y.n.inst.copyBelialUIView
null!=e&&e.Refresh()}SM_DemolazaItemsHandler(t){ge.E.Inst_get().itemMsgData=t
const e=Y.n.inst.copyBelialUIView
null!=e&&e.Refresh()}SM_DemolazaDataHandler(t){ge.E.Inst_get().data=t,null!=ge.E.Inst_get().data&&(ge.E.Inst_get().curGetExp=ge.E.Inst_get().data.killMonsterExp.ToNum())
const e=Y.n.inst.copyBelialUIView
null!=e&&e.Refresh()}SM_CopySweepHandle(t){const e=t,i=G.o.Inst().getItemById(e.copyId)
if(null==i)return
if(!this.recordDic.LuaDic_ContainsKey(i.controllerType))return
const s=this.recordDic[i.controllerType]
null==s.sweepMap&&(s.sweepMap=new D.X)
const n=s.sweepMap
n.LuaDic_ContainsKey(e.copyId)?n[e.copyId]=e.times:n.LuaDic_AddOrSetItem(e.copyId,e.times),ht.a.Inst_get().sweepDoubleDic.LuaDic_AddOrSetItem(e.copyId,e.doubleTime),
_.i.Inst.RaiseEvent(Bt.g.COPYSWEEP_SUCCESS,e.copyId)}CM_ApplyTeamCopyOp(t,e){}CM_DealTeamCopyOp(t){}SM_CopyNoticeHandler(t){const e=t
Lt.C.inst.JudgeOpenViewById(e.noticeId)}TeamFailHandler(t){new y.Z(0)}CM_CopyEncourage(t,e,i){const s=new k.a
s.copyId=t,s.type=e,s.num=null==i?1:i,C.C.Inst.F_SendMsg(s)}CM_BossEncourage(t,e){ht.a.Inst_get().encourageBossId=t
const i=new Ft.H
i.objId=t,i.type=e,C.C.Inst.F_SendMsg(i)}SM_CopyEncourageHandle(t){if(0==t.result)return void Z.y.inst.ClientSysMessage(X.X.EncourgeDefeat)
ht.a.Inst_get().encourageTypeTimes=t.encourageTypeTimes,ht.a.Inst_get().encourageMap=t.encourageMap
for(const[e,i]of(0,o.vy)(t.encourageMap))Y.n.inst.ShowInspire(e,t.encourageMap[e])
Y.n.inst.ShowInspireTimes(t.encourageTypeTimes)
const e=M.y.Inst.GetInspireBtnView()
null!=e&&e.InitExtraLabel(),Y.n.inst.PlayResultAnim(t.result),S.j.Inst.PlayByDivision("Applause")}SM_UpdateCopyRecordsHandle(t){const e=t
if(this.updateRecordList.Clear(),null==e.records);else{for(const[t,i]of(0,o.vy)(e.records))this.updateRecordList.Add(t),this.SetCopyRecord(t,e.records[t],!1)
ct.w.GetInst().RaiseEvent(Ce.s.COPY_INFO_UPDATE),_.i.Inst.RaiseEvent(Bt.g.COPYRECORD_UPDATE,this.updateRecordList)}}SetCopyRecord(t,e,i){let s=null
if(this.recordDic.LuaDic_ContainsKey(t)){const i=this.recordDic[t]
if(this.recordDic[t]=e,null!=i){if(i.todayBuyTimes!=e.todayBuyTimes&&t!=dt.S.Arena){s=G.o.Inst().getItemByCopyType(t)
const e=new y.Z
e.Add(s.name),Z.y.inst.ClientSysMessage(11030504,e),Me.B.GetInst().UpdateVipBuyInfo()}
if(t==dt.S.Crime&&e.maxCopyId>i.maxCopyId&&!le.T.ins.new_unlock_copy_ids.Contains(e.maxCopyId)){const t=G.o.Inst().getItemByPreId(e.maxCopyId)
null!=t&&le.T.ins.new_unlock_copy_ids.Add(t.id)}}}else this.recordDic.LuaDic_AddOrSetItem(t,e)
if(t==dt.S.VipBoss1)be.D.Inst_get().SetRedPoint()
else if(t==dt.S.VipBoss2)be.D.Inst_get().SetRedPoint()
else if(t==dt.S.VipBoss3)be.D.Inst_get().SetRedPoint()
else if(t==dt.S.KUNDUN_SEAL);else if(t==dt.S.LostAbyss){const t=e
null!=t&&q.u.Inst_Get().serverData_set(t)}if(s=G.o.Inst().getItemById(e.lastCopyId),null!=s){const i=e.lastEnterTime.ToNum()
this.SetCopyTime(t,i)}null!=i&&i&&ct.w.GetInst().RaiseEvent(Ce.s.COPY_INFO_UPDATE)}UpdateTodayBuyTime(t,e){
this.recordDic.LuaDic_ContainsKey(t)&&(this.recordDic[t].todayBuyTimes=e),ct.w.GetInst().RaiseEvent(Ce.s.COPY_INFO_UPDATE,t)}checkInCool(t){let e=!1
for(const[i,s]of(0,o.vy)(this.recordDic))if(t==i){const t=G.o.Inst().getItemById(this.recordDic[i].lastCopyId),s=ht.a.Inst_get().copyCoolTimeDic,n=s.LuaDic_ContainsKey(i)
if(null==t||!n)return!1
{let e,n
n=s[i],e=t.waitTime
let l=m.D.serverMSTime_get()-n
if(l<0&&(l=0),l>e)return!1}e=!0
break}return!!e}SM_DynamicBlockRoundHandle(t){const e=t
I.L.Instance_get().ClearDynamicBlock(),this.rounds=e.rounds
let i=0
for(;i<e.rounds.count;)I.L.Instance_get().UseDynamicBlock(e.rounds[i]),i+=1
this.HandleDaynaimcBound()}HandleDaynaimcBound(){Et.b.Inst_get().InAsuramMap()&&Et.b.Inst_get().SetRounds(this.rounds),
ht.a.Inst_get().serverCopyType==dt.S.Maze&&(this.rounds.count>0?ee.u.Inst_get().ShowLightPillar():ee.u.Inst_get().RemoveLightPillar()),
ht.a.Inst_get().serverCopyType==dt.S.Arena&&(this.rounds.count>0?Rt.v.Inst_get().CreateFlagObject():Rt.v.Inst_get().ClearFlagObject())}SM_CopyRoundHandler(t){const e=t
this.curround=e.round}SM_CopyTargetHandle(t){const e=t,i=G.o.Inst().getItemById(e.copyId)
i.controllerType==dt.S.BloodTown&&ct.w.GetInst().HandleTargets(e)
const s=i.controllerType
this.HandleTargetsState(e),s==dt.S.AsuramTaskCopy&&Y.n.inst.UpdateAsuramTaskCopyTraceView(e.list),s==dt.S.RyAllianceTask&&Y.n.inst.UpdateRyAllianceTaskCopyTraceView(e),
s==dt.S.JigsawBoss&&Y.n.inst.UpdateRyAllianceTaskCopyTraceView(e),s==dt.S.LostAbyss&&F.o.Inst_Get().UpdateBattlePorss(e)}HandleTargetsState(t){const e=this.curstage
for(const[e,i]of(0,o.vy)(t.list)){const i=t.list[e]
this.curstage=i.keyName,0==i.keyName&&(this.curstage=1,console.error((0,r.T)("副本阶段数据异常，不应该为0")))}e==this.curstage&&0!=this.curstage||_.i.Inst.RaiseEvent(Bt.g.COPY_STAGE_UPDATE),
this.HandleMultipleHangPlot(this.curstage)}HandleMultipleHangPlot(t){
"PLOT"==et.p.Inst_get().GetMapById(p.b.Inst.currentMapId_get()).controllerType&&(1==t?(ie.j.inst.SetPlotSpawnId(),ie.j.inst.CreateElement(),
ie.j.inst.OpenPlotHangUpLister()):(ie.j.inst.ClearElement(),ie.j.inst.ClosePlotHangUpLister()))}SM_CopyRewardHandle(t){const e=t
A.c.DebugLog((0,r.T)("打开副本成功或失败面板")),this.copyReward=e,ht.a.Inst_get().sm_copyReward=e,ht.a.Inst_get().copyEndState=e.finishStatus,
2==ht.a.Inst_get().copyEndState&&(Zt.T.ins.Pause_Set(!0),Jt.B.Inst_get().SetAutoCollectJigsaw(!1)),ht.a.Inst_get().copySuccessTime=e.time,
null!=e.rewardList&&null!=e.rewardList.rewards&&(ht.a.Inst_get().copySuccessReward=e.rewardList.rewards),Ie.Inst_get().evaluateLevel=e.evaluateLevel,
Ie.Inst_get().displayExp=e.displayExp,Ie.Inst_get().killMonsterNum=e.killMonsterNum,Ie.Inst_get().historyTopExp=e.historyTopExp
const i=ht.a.Inst_get().serverCopyType
this._copyRuntimeMgr.GetController(i)?this._copyRuntimeMgr.GetController(i).SM_CopyRewardHandle(e):this.IsDealBelialResult()||this.IsDealSkyResult()||Y.n.inst.OpenSuccessOrDefeatPanel()
}IsDealBelialResult(){const t=G.o.Inst().getItemById(this.copyReward.copyId)
return u._.getInst().endHang(),t.controllerType==dt.S.Belial&&(_e.z.Inst_get().OpenResultView(),Xt.p.inst.ResetData(),Y.n.inst.CloseSoonEndTimeView(),
Y.n.inst.CloseCopyBelielExpPanel(),Y.n.inst.CloseCopyBelialUIView(),Gt.p.Inst_get().Close(),!0)}IsDealSkyResult(){const t=G.o.Inst().getItemById(this.copyReward.copyId)
return u._.getInst().endHang(),t.controllerType==dt.S.SKY_ILLUSION&&(Ge._.GetInst().OpenSuccessPanel(dt.S.SKY_ILLUSION),Xt.p.inst.ResetData(),Y.n.inst.CloseSoonEndTimeView(),
E.C.Inst.CloseScoreView(),Y.n.inst.CloseCopySkylandUIView(),!0)}SM_EnterCopyHandle(e){ht.a.Inst_get().currentCopyId=e.copyId,ht.a.Inst_get().serverCopyId=e.copyId,
ht.a.Inst_get().lastCopyId=e.copyId,ht.a.Inst_get().isShowTopBtn=!0,ht.a.Inst_get().inspireValShow.LuaDic_Clear(),ht.a.Inst_get().copyEndState=0,
ht.a.Inst_get().multiple=e.multiple,ht.a.Inst.exiTimer=null,V.c.Inst.ClearSpecialTimes(),rt.f.inst_get().ResetData()
const i=G.o.Inst().getItemById(e.copyId)
if(ht.a.Inst_get().curCopyType=i.controllerType,ht.a.Inst_get().serverCopyType=i.controllerType,Q.X.inst.SetViewLine(e.channelId),Q.X.inst.EnterCopy(),j.N.Inst_get().needOpen=!1,
b.F.Inst_get().control.ForceClose(),u._.getInst().endHang(),a.o.Inst_get().enterCopy(),K.X.Inst().TargetRole_set(null),
L.l.CheckTrigger(B.u.COND_TYPE_ENTER_COPY_BEFORE_NO_LOADING_VAL,ht.a.Inst_get().currentCopyId),l.X.hasEnd=!1,
this._copyRuntimeMgr.GetController(i.controllerType))return this._copyRuntimeMgr.GetController(i.controllerType).SM_EnterCopyHandle(e),t.inst.ClosePanel(i.controllerType),
void c.B.Inst.AddTransportToScene()
if(i.controllerType==dt.S.Plot&&3==i.plotType){const t=he.O.Inst_get().nowConfig_get()
Ot.s.GetInst().copyTalkNpcId=null!=t?t.linkNpcId_get():0}else Ot.s.GetInst().copyTalkNpcId=0
const s=i.controllerType
if(s==dt.S.Plot||s==dt.S.eMap||dt.S.AsuramWar,s==dt.S.BloodTown&&ct.w.GetInst().CheckMapInfo(),
s==ht.a.Inst_get().juqingCopyId)return J.w.Inst_get().GetCopyId()==e.copyId&&de.T.Inst_get().OpenView(e.copyId),Kt.q.Inst_get().isBackRole=!0,
d.Y.Inst.PrimaryRole_get().StopPathWithOutNoticeServer(),void e.copyId
s==dt.S.AsuramWar?(se.k.inst.openfanji=!1,Z.y.inst.SetRiAndLaPanelState(!1)):s==dt.S.LostAbyss?q.u.Inst_Get().boss_alive=!0:s==dt.S.Arena?wt.g.Inst_get().DealArenaEnter():Y.n.Inst_get().OpenCopyPanel(),
s!=dt.S.WORLDBOSS&&s!=dt.S.WORLDBOSS_NEW||(nt.D.Inst_get().dropVecList.Clear(),nt.D.Inst_get().rewards=null,ht.a.Inst_get().CopyIsAutoHang(null),
it.x.Inst_get().OpenMemberDmgView(),
it.x.Inst_get().OpenAssistDamageView()),s==dt.S.SKY_ILLUSION&&(this.areaCheckTimerId=f.C.Inst_get().SetInterval(this._degf_HandleAreaCheck,1e3)),dt.S.RyAllianceTask,
t.inst.ClosePanel(i.controllerType),c.B.Inst.AddTransportToScene(),_.i.Inst.RaiseEvent(Bt.g.COPY_ENTER),L.l.CheckTrigger(B.u.COND_TYPE_ENTER_COPY_BY_TYPE_VAL,i.controllerType),
L.l.CheckTrigger(B.u.COND_TYPE_ENTER_COPY_VAL,i.id),L.l.CheckTrigger(B.u.COND_TYPE_ENTER_COPY_BY_GROUP_VAL,i.groupId)}SM_EnterCopyFailHandle(){Dt.V.Inst_Get().TaskID=0,
console.log((ht.a.Inst_get().currentCopyId,ht.a.Inst_get().currentCopyId))}SM_EndEnterCopyHandle(t){Ht.d.Inst_get().CloseBadgeEffView(),Ht.d.Inst_get().CloseRankRewardView(),
Mt.s.Inst_get().CloseDailyPanel(),st.$.Inst().Close()
const e=t
if(A.c.DebugLog((0,r.T)("进入副本")),null==e)return
const i=G.o.Inst().getItemById(e.copyId)
if(null==i)return
null!=te.u.Inst().mapPassResultVo&&(te.u.Inst().mapPassResultVo.activeGuide=!1,i.controllerType==dt.S.MapPassBoss&&(te.u.Inst().isClickAcccess=!1)),
_.i.Inst.RaiseEvent(Bt.g.COPY_ENTEREND),ht.a.Inst_get().currentCopyId=e.copyId,ht.a.Inst_get().curCopyType=i.controllerType,ht.a.Inst_get().serverCopyId=e.copyId,
ht.a.Inst_get().serverCopyType=i.controllerType,ht.a.Inst_get().lastCopyId=e.copyId
const s=i.controllerType
if(s!=dt.S.MapPassBoss&&s!=dt.S.Plot||xt.B.Inst().PlayEffect("ui_mappass_enter_eff",Vt.P.zero_get(),Vt.P.zero_get(),3,3e3),s==dt.S.Exorcism&&Nt.W.Inst_get().DealEnterCopy(),
Lt.C.Inst_Get().CloseNPCTipView(),Lt.C.Inst_Get().CloseCommonTipView(),ht.a.Inst_get().CopyIsAutoHang(null),this.HandleDaynaimcBound(),
L.l.CheckTrigger(B.u.COND_TYPE_ENTER_COPY_VAL,e.copyId),L.l.CheckTrigger(B.u.COND_TYPE_ENTER_COPY_BY_TYPE_VAL,1),
this._copyRuntimeMgr.GetController(i.controllerType))return this._copyRuntimeMgr.GetController(i.controllerType).SM_EndEnterCopyHandle(e),
void Tt.p.Inst_get().EnterMap(p.b.Inst.currentMapId_get())
this.checkExp(s),s==dt.S.BloodTown&&ct.w.GetInst().EnterMap(),this.enterTimerDic.LuaDic_ContainsKey(i.controllerType)?this.enterTimerDic[i.controllerType]=e.time.ToNum():this.enterTimerDic.LuaDic_AddOrSetItem(i.controllerType,e.time.ToNum()),
ut.s.Info(`<color=#00ff00>copy id:${e.copyId} startTime:${e.time.ToNum()}serverTime:${m.D.serverMSTime_get()}offsetTime${e.time.ToNum()-m.D.serverMSTime_get()} preTime:${i.preTime} </color>`),
s==dt.S.PEAK_CROSS_ARENA||s==dt.S.NORMAL_CROSS_ARENA?ht.a.Inst_get().isArenaTip=!0:ht.a.Inst_get().isArenaTip=!1,
s==dt.S.AsuramWar_1||s==dt.S.AsuramWar_2||(i.preTime>0?(Y.n.inst.OpenEnterCopyTimerPanel(),
this.IsInArenaCopy()&&wt.g.Inst_get().CheckUseArenaHang()):Y.n.inst.SetData(ht.a.Inst_get().currentCopyId)),lt._.Inst().IsVipBossCopy(s)&&Y.n.inst.OpenCopyLoadingPanel(),
v.a.isInAllianceBossMap_get()&&oe._.Inst.DelayRefreshPlayerHideOption(),_.i.Inst.RaiseEvent(Bt.g.COPY_ENTERTIMEUDPDATE,e.copyId),
Tt.p.Inst_get().EnterMap(p.b.Inst.currentMapId_get())}OpenCopyPanel(t,e){null==e&&(e=!1)
const i=G.o.Inst().getItemByCopyType(t)
e&&p.b.Inst.currentMapId_get()==T.M.String2Int(i.mapId)||(ht.a.Inst_get().curCopyType=t,
null==this._copyRuntimeMgr.GetController(t)?lt._.Inst().IsVipBossCopy(t)?Y.n.inst.OpenCopyLoadingPanel():t==dt.S.Arena&&ft.N.inst.OpenUIByShortCutID(pt.D.Arena):this._copyRuntimeMgr.GetController(t).OpenPanel())
}SetCopyTime(t,e){const i=ht.a.Inst_get().copyCoolTimeDic
i.LuaDic_ContainsKey(t)?i[t]=e:i.LuaDic_AddOrSetItem(t,e)}checkExp(t){let e=!1
if(t==dt.S.Belial){const t=zt.M.Inst_get().GetExpSkillIdAndMallId()
if(this.isUse=!1,null!=t&&0!=t.Count()){this.useSkillId=t[0]
const i=d.Y.Inst.PrimaryRoleInfo_get().Skills_get()
let s=!1,n=0
for(;n<t.Count();){const e=d.Y.Inst.PrimaryRoleInfo_get().Level_get()
if(s=!i.LuaDic_ContainsKey(t[n])&&e>=t[n+2],n+=2,s)break
n+=1}e=s}}}SetJuQingCopyBox(t,e){return!1}SM_LeaveCopyHandle(t){const e=ht.a.Inst_get().serverCopyType
e==dt.S.Arena?wt.g.Inst_get().DealArenaExit():e==dt.S.MapPassBoss?Qt.N.Inst().CloseAll():e==dt.S.Exorcism?Nt.W.Inst_get().DealExitCopy():e==dt.S.BloodTown||e==dt.S.Belial?Xt.p.inst.ResetData():e==dt.S.RolandDefend1?Y.n.inst.CloseRolandRepairCrackCopyView():e==dt.S.RolandDefend2&&Y.n.inst.CloseRolandDefenseCopy2View(),
ht.a.Inst.exiTimer=null,A.c.DebugLog((0,r.T)("离开副本")),ht.a.Inst_get().serverCopyId=0,ht.a.Inst_get().serverCopyType=0,d.Y.Inst.m_curSpecielTarget=null,
ht.a.Inst_get().lastCopyId=t.copyId
const i=G.o.Inst().getItemById(t.copyId)
if(null==i)return void A.c.DebugLog((0,r.T)("离开副本时副本数据为空"))
rt.f.inst_get().ResetData(),M.y.Inst.ClearCopyExitTime(),Y.n.inst.CloseSuccessOrDefeatePanel(),d.Y.Inst.SetOperateState(!0)
const s=M.y.Inst.GetSlowBtnView()
if(null!=s&&s.Clear(),this._copyRuntimeMgr.GetController(i.controllerType))return void this._copyRuntimeMgr.GetController(i.controllerType).SM_LeaveCopyHandle(t)
null!=R.Q.Inst_get().bossModel&&(R.Q.Inst_get().bossModel.hasSmallMonster=!1),w.x.inst.closeTransferPanel(),w.x.inst.otherRolerId=null,
L.l.CheckTrigger(B.u.COND_LEAVE_ANY_COPY_VAL,1)
const n=i.controllerType
lt._.Inst().IsVipBossCopy(n)&&this.SetCopyRecord(n,t.copyRecord),dt.S.eCommonMiracle,n==dt.S.AllianceHome&&(ht.a.Inst_get().currentCopyId=0),
n!=dt.S.WORLDBOSS&&n!=dt.S.WORLDBOSS_NEW||(nt.D.Inst_get().dropVecList.Clear(),nt.D.Inst_get().rewards=null,it.x.Inst_get().CloseAfterLeave()),
n==dt.S.AllianceBoss1||n==dt.S.AllianceBoss2||n==dt.S.AllianceBoss3||dt.S.AllianceBoss4,n==dt.S.SKY_ILLUSION&&(-1!=this.areaCheckTimerId&&(pe.R.Inst_get().IsMonsterHalf_set(!1),
f.C.Inst_get().ClearInterval(this.areaCheckTimerId),this.areaCheckTimerId=-1),pe.R.Inst_get().Clear()),dt.S.MineRob,dt.S.KUNDUN_SEAL,
n==dt.S.NORMAL_CROSS_ARENA&&p.b.Inst.autoOpenUIIDs.Add(pt.D.NormalCrossArena),n==dt.S.RyAllianceTask&&(Dt.V.Inst_Get().TaskID=0),q.u.Inst_Get().isvipdided=!1,
n==dt.S.AllianceHome&&Us.L.GetInst().DestroyFireClientObj()}ClearCopyDataInLeave(){Y.n.inst.CloseSoonEndTimeView()
const t=G.o.Inst().getItemById(ht.a.Inst_get().currentCopyId)
if(null==t)return
const e=t.controllerType
if(this.curstage=0,this.curchildstage="",this.curround=0,a.o.Inst_get().leaveCopy(),ot.Inst_get().copyId=-1,ht.a.Inst_get().curCopyType=0,ct.w.GetInst().Reset(),
p.b.Inst.SetLogicCheckEx=null,f.C.Inst_get().ClearInterval(this.checkTriggerInterval),this.checkTriggerInterval=-1,V.c.Inst.ClearTimer(),ht.a.Inst_get().isStartExitCopy=!1,
ct.w.GetInst().stage=1,d.Y.Inst.PrimaryRole_get().StopPathWithOutNoticeServer(),d.Y.Inst.PrimaryRole_get().ChangeToStand(),u._.getInst().endHang(),st.$.inst.updateRedPoint(),
ht.a.Inst_get().encourageTypeTimes=null,ht.a.Inst_get().encourageMap=null,j.N.Inst_get().needOpen=!0,P.J.Inst_get().CloseTipView(),d.Y.Inst.ResetMouseDownTime(),
ht.a.Inst_get().ClearDelayHangTimer(),n.R.getInst().removeAI(d.Y.Inst.PrimaryRole_get(),s.R.teamPlayer),I.L.Instance_get().ClearDynamicBlock(),
$.Q.Inst_get().IsOpenSpecialTaskViewCopy(e)||($.Q.Inst_get().isCommonCopyLeave=!0),0!=ht.a.Inst_get().currentCopyId){const t=G.o.Inst().getItemById(ht.a.Inst_get().currentCopyId)
null!=t&&t.checkNotice&&z.N.Inst_get().ShowTipsAfterStronger()}if(ct.w.GetInst().isOpenedDialoguePanel=!1,J.w.Inst_get().GetCopyId()==t.id&&de.T.Inst_get().CloseView(),
e==dt.S.AsuramWar?(se.k.inst.openfanji=!0,
Z.y.inst.SetRiAndLaPanelState(!0),d.Y.Inst.PrimaryRole_get().UpdateRedFortressTitle(!1)):e==dt.S.Belial?ge.E.Inst_get().reset():e==dt.S.RedFortress?d.Y.Inst.PrimaryRole_get().ChangePlayerModel():e==dt.S.AllianceHome?vt.N.inst_get().OnLeaveScene():e==dt.S.eFirstMiracle||e==dt.S.eCommonMiracle||e==dt.S.musTowerHard||dt.S.musTowerNormal,
e==ht.a.Inst_get().juqingCopyId)return ie.j.inst.ClosePlotHangUpLister(),ie.j.inst.ClearElement(),J.w.Inst_get().GetCopyId()==t.id&&de.T.Inst_get().CloseView(),
void(ht.a.Inst_get().currentCopyId=0)
ht.a.Inst_get().currentCopyId=0,ht.a.Inst_get().serverCopyId=0,ht.a.Inst_get().serverCopyType=0,ht.a.Inst_get().gainItemLis.Clear(),W.c.ins.boss_alive=!1,
q.u.Inst_Get().boss_alive=!1,E.C.Inst.CloseScoreView(),F.o.Inst_Get().CloseBattlePanel()}OnArenaOverUp(){}ResetCopyPanel(){this.ClearCopyDataInLeave()}EnterWufengEndHandler(t){
ft.N.inst.RemoveAllSingleDirectionAnimOnce(),0!=this.exitElementId&&(mt.X.Inst.DeleteElement(this.exitElementId),this.exitElementId=0)}SM_SceneBoxVOHandle(t){const e=t.vo.records
if(this.updateRecordList.Clear(),null!=e)for(const[t,i]of(0,o.vy)(e))this.updateRecordList.Add(t),this.SetCopyRecord(t,e[t],!1)
_.i.Inst.RaiseEvent(Bt.g.COPYRECORD_UPDATE,this.updateRecordList),kt.t.Inst_get().InitRedState()}ExitCopy(){const t=new jt.P
C.C.Inst.F_SendMsg(t)}IsInArenaCopy(){return ht.a.Inst_get().serverCopyType==dt.S.Arena}IsInMapPassBossCopy(){return ht.a.Inst_get().serverCopyType==dt.S.MapPassBoss}IsInCopy(){
const t=et.p.Inst_get().GetMapById(p.b.Inst.currentMapId_get())
return null!=t&&(t.controllerType==g.N.WORLD_BOSS||t.controllerType==g.N.WORLD_BOSS_NEWHAND||(t.controllerType==g.N.ROLAND_NEST||(null!=t&&t.senceType==O.S.CopyMap||"ASURAM_SCENE"==t.controllerType&&R.Q.Inst_get().ServerIsInCopy())))
}IsCopyByMapID(t){const e=et.p.Inst_get().GetMapById(t)
return null!=e&&e.senceType==O.S.CopyMap}IsSameMapByMapID(t){const e=d.Y.Inst.PrimaryRoleInfo_get()
return null!=e&&e.MapId_get()==t}IsCopyInBloodTown(){return ht.a.Inst_get().curCopyType==dt.S.BloodTown&&0!=ht.a.Inst_get().currentCopyId}IsCopyInBeliel(){
return ht.a.Inst_get().curCopyType==dt.S.Belial&&0!=ht.a.Inst_get().currentCopyId}IsCopyInSky(){
return ht.a.Inst_get().curCopyType==dt.S.SKY_ILLUSION&&0!=ht.a.Inst_get().currentCopyId}OpenPanel(t){gt.Y.LogError("废弃接口")}ShowCopy(t){
t==dt.S.BloodTown?this.bloodTownView.OnAddToScene():t==dt.S.SKY_ILLUSION&&this.dreamlandView.OnAddToScene()}UpdateTimeAndCount(t){let e=0
const i=G.o.Inst().getItemById(t)
if(null==i)return
let s=0
this.recordDic.LuaDic_ContainsKey(i.controllerType)&&(e=this.recordDic[i.controllerType].todayEnterHistory,s=this.recordDic[i.controllerType].todayBuyTimes),
this.SetCoolTimer(i.controllerType),this.SetEnterCount(i.controllerType,i.challengesTimes-e,s)}GetLeftCount(t,e){null==e&&(e=!1)
const i=G.o.Inst().getItemsByCopyType(t)
if(i.Count()>0){const s=i[0]
let n=0,l=0
this.recordDic.LuaDic_ContainsKey(s.controllerType)&&(l=this.recordDic[s.controllerType].todayEnterHistory,n=this.recordDic[s.controllerType].todayBuyTimes)
const a=s.challengesTimes-l,o=ce.U.inst.model.GetCopyAddCount(t),r=ne.v.Inst_get().GetCopyHasRecoveredCount(t)
return e?o-n:a+r+n}return 0}ClosePanel(t){this._copyRuntimeMgr.GetController(t)&&this._copyRuntimeMgr.GetController(t).ClosePanel()}SetEnterCount(t,e,i){
t==dt.S.BloodTown?me.N.Inst_get().SetEnterNum(e,i):t==dt.S.SKY_ILLUSION?null!=this.dreamlandView&&this.dreamlandView.SetEnterNum(e,i):t==dt.S.Belial&&_e.z.Inst_get().SetEnterNum(e,i)
}GetEnterCountRemain(t){let e=0,i=0
const s=G.o.Inst().getItemById(t)
return this.recordDic.LuaDic_ContainsKey(s.controllerType)&&(e=this.recordDic[s.controllerType].todayEnterHistory),i+=s.challengesTimes-e,i+=0,i}SetCoolTimer(t,e){null==e&&(e=!1),
t==dt.S.BloodTown?null!=this.bloodTownView&&this.bloodTownView.SetTimer(t,e):t==dt.S.SKY_ILLUSION?null!=this.dreamlandView&&this.dreamlandView.SetTimer(t,e):lt._.Inst().IsVipBossCopy(t)&&null!=st.$.Inst().vipView&&st.$.Inst().vipView.SetColdTimer()
}openTeamEnter(t,e,i){t?this.teamMapId=e:this.teamcopyid=e,this.isMap=t,this.teamleftTime=i
{const t=new Ct.v
t.positionType=yt.$.eCenter,t.isShowMask=!0,t.isSelfTween=!1}null!=this.copyteamenter&&(t?(this.copyteamenter.mapId=e,this.copyteamenter.isMap=t):(this.copyteamenter.copyId=e,
this.copyteamenter.isMap=t))}CanEnterPersonBoss(){let t=!1
const e=ht.a.Inst_get().copyRecordDic
return e.LuaDic_ContainsKey(dt.S.VipBoss1)||e.LuaDic_ContainsKey(dt.S.VipBoss2)||e.LuaDic_ContainsKey(dt.S.VipBoss3)?(ht.a.Inst_get().copyRecordDic[dt.S.VipBoss1].todayEnterHistory<3&&(t=!0),
ht.a.Inst_get().copyRecordDic[dt.S.VipBoss2].todayEnterHistory<3&&(t=!0),ht.a.Inst_get().copyRecordDic[dt.S.VipBoss3].todayEnterHistory<3&&(t=!0)):t=!0,t}CallDestory(){
St.g.DestroyUIObj(this.copyteamenter),this.copyteamenter=null}ShowlTeamApplyComplete(t){return null==this.copyteamenter&&(this.copyteamenter=new Be,
this.copyteamenter.isMap=this.isMap,this.isMap?this.copyteamenter.mapId=this.teamMapId:this.copyteamenter.copyId=this.teamcopyid,this.copyteamenter.setId(t,null,0)),
this.copyteamenter}GetCopyRecordById(t){if(null!=this.recordDic){const e=G.o.Inst().getItemById(t)
if(this.recordDic.LuaDic_ContainsKey(e.controllerType))return this.recordDic[e.controllerType]}return null}GetCopyRecordByCopyType(t){if(null!=this.recordDic){
if(this.recordDic.LuaDic_ContainsKey(t))return this.recordDic[t]}return null}IsCopyCanHang(){const t=G.o.Inst().getItemById(ht.a.Inst_get().currentCopyId)
return null==t||t.helperOpen}CommonEnterCopy(t,e){this.SendEnterCopy(e)}SendSlowDown(){}HandleAreaCheck(){d.Y.Inst.HandleAreaCheck()}Test1(){const t=new U.k
t.win=!1,t.win=!0,t.rewardItems=new y.Z
const e=new Ut.t
e.modelId=51003,e.num=1,t.rewardItems.Add(e),this.SM_RobotCopySettlementHandle(t)}},ks._inst=null,Vs(Ns=ks,"inst",[_t.n],Object.getOwnPropertyDescriptor(Ns,"inst"),Ns),
Vs(Ns.prototype,"SM_CopyUpdateEndTimeHandle",[ns],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_CopyUpdateEndTimeHandle"),Ns.prototype),
Vs(Ns.prototype,"SM_OxNewYearBossSettlementHandle",[ls],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_OxNewYearBossSettlementHandle"),Ns.prototype),
Vs(Ns.prototype,"SM_RobotCopySettlementHandle",[as],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_RobotCopySettlementHandle"),Ns.prototype),
Vs(Ns.prototype,"SM_FireAllExpHandle",[os],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_FireAllExpHandle"),Ns.prototype),
Vs(Ns.prototype,"SM_SubmitFirePlayersHandle",[rs],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_SubmitFirePlayersHandle"),Ns.prototype),
Vs(Ns.prototype,"SM_SubmitFireItemHandle",[hs],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_SubmitFireItemHandle"),Ns.prototype),
Vs(Ns.prototype,"Sm_FireInfoHandle",[ds],Object.getOwnPropertyDescriptor(Ns.prototype,"Sm_FireInfoHandle"),Ns.prototype),
Vs(Ns.prototype,"SM_SingleMonsterPanelHandle",[cs],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_SingleMonsterPanelHandle"),Ns.prototype),
Vs(Ns.prototype,"SM_PersonalBossSettlementHandler",[_s],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_PersonalBossSettlementHandler"),Ns.prototype),
Vs(Ns.prototype,"SM_LostAbyssCopyEnd",[us],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_LostAbyssCopyEnd"),Ns.prototype),
Vs(Ns.prototype,"SM_ClientStopHangHandler",[Is],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_ClientStopHangHandler"),Ns.prototype),
Vs(Ns.prototype,"SM_AutoEnterCopyErrorHandle",[ms],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_AutoEnterCopyErrorHandle"),Ns.prototype),
Vs(Ns.prototype,"SM_EndCopyHandle",[gs],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_EndCopyHandle"),Ns.prototype),
Vs(Ns.prototype,"SM_EvaluateLevelUpdateHandler",[ps],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_EvaluateLevelUpdateHandler"),Ns.prototype),
Vs(Ns.prototype,"SM_BloodtownRewardInfoHandler",[Cs],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_BloodtownRewardInfoHandler"),Ns.prototype),
Vs(Ns.prototype,"SM_CopyClearCDHandle",[Ss],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_CopyClearCDHandle"),Ns.prototype),
Vs(Ns.prototype,"SM_DemonlazaInfoHandler",[fs],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_DemonlazaInfoHandler"),Ns.prototype),
Vs(Ns.prototype,"SM_DemolazaItemsHandler",[Ts],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_DemolazaItemsHandler"),Ns.prototype),
Vs(Ns.prototype,"SM_DemolazaDataHandler",[ys],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_DemolazaDataHandler"),Ns.prototype),
Vs(Ns.prototype,"SM_CopySweepHandle",[As],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_CopySweepHandle"),Ns.prototype),
Vs(Ns.prototype,"SM_CopyNoticeHandler",[Ds],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_CopyNoticeHandler"),Ns.prototype),
Vs(Ns.prototype,"SM_CopyEncourageHandle",[Es],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_CopyEncourageHandle"),Ns.prototype),
Vs(Ns.prototype,"SM_UpdateCopyRecordsHandle",[vs],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_UpdateCopyRecordsHandle"),Ns.prototype),
Vs(Ns.prototype,"SM_DynamicBlockRoundHandle",[ws],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_DynamicBlockRoundHandle"),Ns.prototype),
Vs(Ns.prototype,"SM_CopyRoundHandler",[Rs],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_CopyRoundHandler"),Ns.prototype),
Vs(Ns.prototype,"SM_CopyTargetHandle",[Ps],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_CopyTargetHandle"),Ns.prototype),
Vs(Ns.prototype,"SM_CopyRewardHandle",[Os],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_CopyRewardHandle"),Ns.prototype),
Vs(Ns.prototype,"SM_EnterCopyHandle",[Ls],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_EnterCopyHandle"),Ns.prototype),
Vs(Ns.prototype,"SM_EnterCopyFailHandle",[Bs],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_EnterCopyFailHandle"),Ns.prototype),
Vs(Ns.prototype,"SM_EndEnterCopyHandle",[bs],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_EndEnterCopyHandle"),Ns.prototype),
Vs(Ns.prototype,"SM_LeaveCopyHandle",[Ms],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_LeaveCopyHandle"),Ns.prototype),
Vs(Ns.prototype,"SM_SceneBoxVOHandle",[Gs],Object.getOwnPropertyDescriptor(Ns.prototype,"SM_SceneBoxVOHandle"),Ns.prototype),Hs=Ns))||Hs)},70478:(t,e,i)=>{i.d(e,{_:()=>v})
var s,n,l,a,o=i(98958),r=i(38935),h=i(56937),d=i(31222),c=i(5494),_=i(52726),u=i(79534),I=i(47786),m=i(86447),g=i(94409),p=i(96713),C=i(1046),S=i(85770),f=i(44210),T=i(42292),y=i(71409),A=i(17409),D=i(92415)
function E(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let v=(s=(0,y.GH)(D.k.SM_BloodTownRank),n=(0,y.GH)(D.k.SM_BloodTownDate),a=class t{get rankView(){return(0,
A.Y)(c.I.BloodTownRankPanel)}get resultView(){}constructor(){this._successPanel=null,this._evaluateView=null,this._stonePanel=null,this._model=null,this.stageTipView=null,
this.m_flyEffect=null,this.startGO=null,this.moveType=1,this.id=100,this.frompos=null,this.controllerType=0,this._degf_CallDestory=null,this._degf_CallEffectDestory=null,
this._degf_CallEvaluatePanelDestory=null,this._degf_CallStageTipsDestory=null,this._degf_CallStoneDestory=null,this._degf_OnEffectComplete=null,this._degf_ShowEvaluateHandler=null,
this._degf_ShowHandler=null,this._degf_ShowStageTipsHandler=null,this._degf_ShowlStoneComplete=null,this._degf_CallRankDestroy=null,this._degf_ShowResultHandler=null,
this._degf_CallResultDestroy=null,this.frompos=new u.P,this._degf_CallDestory=()=>this.CallDestory(),this._degf_CallEffectDestory=()=>this.CallEffectDestory(),
this._degf_CallEvaluatePanelDestory=()=>this.CallEvaluatePanelDestory(),this._degf_CallStageTipsDestory=()=>this.CallStageTipsDestory(),
this._degf_CallStoneDestory=()=>this.CallStoneDestory(),this._degf_OnEffectComplete=t=>this.OnEffectComplete(t),this._degf_ShowEvaluateHandler=t=>this.ShowEvaluateHandler(t),
this._degf_ShowHandler=t=>this.ShowHandler(t),this._degf_ShowStageTipsHandler=t=>this.ShowStageTipsHandler(t),this._degf_ShowlStoneComplete=t=>this.ShowlStoneComplete(t),
this._degf_CallRankDestroy=t=>this.CallRankDestroy(),this._degf_ShowResultHandler=t=>this.ShowResultHandler(t),this._degf_CallResultDestroy=t=>this.CallResultDestroy()}
static GetInst(){return null==t._inst&&(t._inst=new t),t._inst}RegMsg(){this._model=f.w.GetInst()}openOrCloseItemStonePanel(){
d.N.inst.OpenById(c.I.eBloodTownItemStonePanel,this._degf_ShowlStoneComplete,this._degf_CallStoneDestory)}ShowlStoneComplete(t){
return null==this._stonePanel&&(this._stonePanel=new BloodTownItemStonePanel,this._stonePanel.setId(t,null,0)),this._stonePanel}CallStoneDestory(){
UIResMgr.DestroyUIObj(this._stonePanel),this._stonePanel=null}CloseStone(){null!=this._stonePanel&&d.N.inst.ClosePanel(this._stonePanel)}updataStone(){
null!=this._stonePanel&&this._stonePanel.isShow_get()&&this._stonePanel.updateData()}OpenEffect(t,e,i,s){if(this.startGO=t,this.moveType=e,this.id=i,this.frompos=s.Clone(),
null!=this.m_flyEffect&&this.m_flyEffect.isShow_get()){const t=UIResMgr.GetResFindId("ui_copybaseui_bloodtown_flyeffect"),e=new BloodFlyEffectPanel
e.setId(t,null,0),e.node.transform.SetParent(this.m_flyEffect.FatherId,this.m_flyEffect.ComponentId),d.N.inst.SetChildDepth(this.m_flyEffect.FatherId,t),e.Play(!0)}else{
const t=new h.v
t.layerType=_.F.DefaultUI,t.ReLoginOrChangeRoleIsDestroy=!1,d.N.inst.OpenById(c.I.eBloodTownItemStoneFlyPanel,this._degf_OnEffectComplete,this._degf_CallEffectDestory,t)}}
OnEffectComplete(t){return null==this.m_flyEffect&&(this.m_flyEffect=new BloodFlyEffectPanel,this.m_flyEffect.setId(t,null,0)),this.m_flyEffect}CallEffectDestory(){
UIResMgr.DestroyUIObj(this.m_flyEffect),this.m_flyEffect=null}CloseEffect(){null!=this.m_flyEffect&&d.N.inst.ClosePanel(this.m_flyEffect)}OpenSuccessPanel(t){
if(this.controllerType=t,p.n.inst.CloseConflictView(),null!=this._successPanel&&this._successPanel.isShow_get())this._successPanel.node.SetActive(!1),this._successPanel.Clear(),
this._successPanel.node.SetActive(!0),this._successPanel.hasRush=!0,this._successPanel.OnAddToScene()
else{const t=new h.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!0,d.N.inst.OpenById(c.I.BloodTownSuccessPanel,this._degf_ShowHandler,this._degf_CallDestory,t)}}ShowHandler(t){
return null==this._successPanel&&(this._successPanel=new CopyBloodTownSuccessPanel,this._successPanel.setId(t,null,0)),this._successPanel}CallDestory(){
UIResMgr.DestroyUIObj(this._successPanel),this._successPanel=null}CloseSuccessPanel(){
null!=this._successPanel?d.N.inst.ClosePanel(this._successPanel):d.N.inst.UnLoading(c.I.BloodTownSuccessPanel)}OpenEvaluatePanel(){
if(null==this._evaluateView||0==this._evaluateView.isShow_get()){const t=new h.v
t.positionType=LuaPositionType.eCustom,t.aniDir=LuaDirectionType.Right,t.layerType=_.F.DefaultUI,
d.N.inst.OpenById(c.I.BloodTownEvaluatePanel,this._degf_ShowEvaluateHandler,this._degf_CallEvaluatePanelDestory,t)}}ShowEvaluateHandler(t){
return null==this._evaluateView&&(this._evaluateView=new CopyBloodTownEvaluateView,this._evaluateView.setId(t,null,0)),this._evaluateView}CloseEvaluatePanel(){
null!=this._evaluateView&&d.N.inst.ClosePanel(this._evaluateView)}CallEvaluatePanelDestory(){UIResMgr.DestroyUIObj(this._evaluateView),this._evaluateView=null}GetTargetDescribe(){
return this.GetHoldTargetDescribe()}GetHoldTargetDescribe(){let t=""
const e=this._model.GetCurTask()
if(null==e)return t
const i=e.value,s=this._model.progress
return 1==this._model.stage?(t=I.x.Inst().getItemStrById(115502),t=o.V.Inst().replaceLangParamThree(t,i,s,i)):2==this._model.stage?(t=I.x.Inst().getItemStrById(115505),
t=o.V.Inst().replaceLangParamOne(t,s)):3==this._model.stage?(t=I.x.Inst().getItemStrById(115506),
t=o.V.Inst().replaceLangParamTwo(t,s,i)):4==this._model.stage?(t=I.x.Inst().getItemStrById(115507),
t=o.V.Inst().replaceLangParamOne(t,s)):5==this._model.stage?(t=I.x.Inst().getItemStrById(115508),
t=o.V.Inst().replaceLangParamOne(t,s)):6==this._model.stage?t=I.x.Inst().getItemStrById(115510):7==this._model.stage&&(t=I.x.Inst().getItemStrById(115511),
t=o.V.Inst().replaceLangParamOne(t,s)),t}ReqBackItem(){const t=this._model.GetCurTask().paramAttributes[0],e=new CM_CopyGiveBackItem
e.itemmodelId=t,e.num=1,r.C.Inst.F_SendMsg(e),HangControl.getInst().endHang()}CloseStageTipsView(){null!=this.stageTipView&&d.N.inst.ClosePanel(this.stageTipView)}OpenStageTip(t){
if(null==t&&(t=0),f.w.GetInst().showType=t,null==this.stageTipView||0==this.stageTipView.isShow_get()){u.P.zero_get().y=94,
d.N.inst.OpenById(c.I.eBloodTownStageTipView,this._degf_ShowStageTipsHandler,this._degf_CallStageTipsDestory)}}ShowStageTipsHandler(t){
return null==this.stageTipView&&(this.stageTipView=new BloodTownStageTipView,this.stageTipView.setId(t,null,0)),this.stageTipView}CallStageTipsDestory(){
UIResMgr.DestroyUIObj(this.stageTipView),this.stageTipView=null}AddGray(t){return o.V.Inst().getStr2(10032,0,t)}AddGreen(t){return o.V.Inst().getStr2(10031,0,t)}
Req_BloodTownRank(){const t=new m.c
t.copyId=C.N.Inst_get().GetCurrentCopyId(),r.C.Inst.F_SendMsg(t)}SM_BloodTownRankHandler(t){f.w.GetInst().rankInfos=t,this.UpdateRankInfo()}SM_BloodTownDateHandler(t){
f.w.GetInst().bloodTownData=t,null!=p.n.inst.copyBloodTownTracePanel&&p.n.inst.copyBloodTownTracePanel.UpdateScore(),S.a.Inst_get().gainItemLis=t.dropItems,
null!=p.n.inst.copyGainView&&p.n.inst.copyGainView.RefreshReward()}UpdateRankInfo(){null!=this.rankView&&this.rankView.UpdateRankInfo()}OpenBloodRankPanel(t){
if(null!=this.rankView)return void this.rankView.OnAddToScene()
this.Req_BloodTownRank()
const e=new h.v
e.layerType=_.F.Alert,e.isShowMask=!0,d.N.inst.OpenById(c.I.BloodTownRankPanel,null,null,e)}OpenBloodResultPanel(t){if(g.p.inst.ResetData(),this.controllerType=t,
null!=this.resultView)return void this.resultView.OnAddToScene()
const e=new h.v
e.isShowMask=!0,e.isDefaultUITween=!0,e.isSelfTween=!0,e.layerType=_.F.Tip,d.N.inst.OpenById(c.I.BloodTownResultPanel,null,null,e)}CloseResultView(){
d.N.inst.CloseById(c.I.BloodTownResultPanel)}ShowResultHandler(t){return null==this.resultView&&(this.resultView=new RyCopyBloodTownResultPanel,this.resultView.setId(t,null,0)),
this.resultView}CallResultDestroy(){UIResMgr.DestroyUIObj(this.resultView),this.resultView=null}},a._inst=null,
E(l=a,"GetInst",[T.n],Object.getOwnPropertyDescriptor(l,"GetInst"),l),
E(l.prototype,"SM_BloodTownRankHandler",[s],Object.getOwnPropertyDescriptor(l.prototype,"SM_BloodTownRankHandler"),l.prototype),
E(l.prototype,"SM_BloodTownDateHandler",[n],Object.getOwnPropertyDescriptor(l.prototype,"SM_BloodTownDateHandler"),l.prototype),l)},78417:(t,e,i)=>{i.d(e,{L:()=>Lt})
var s,n,l,a,o,r,h,d,c,_,u,I,m=i(42292),g=i(71409),p=i(17409),C=i(93984),S=i(38045),f=i(65393),T=i(78752),y=i(91238),A=i(73136),D=i(5924),E=i(56937),v=i(5494),w=i(52726),R=i(95721),P=i(55360),O=i(85602),L=i(79534),B=i(32076),b=i(38836),M=i(86133),G=i(98800),H=i(61646),N=i(73206),k=i(97461),U=i(36241),V=i(13687),x=i(38935),F=i(62370),q=i(66788),Y=i(31222),W=i(98789),j=i(98885),Z=i(31192),X=i(80486),K=i(43076),$=i(50560),J=i(26376),z=i(11816),Q=i(26753),tt=i(14143),et=i(92679),it=i(85751),st=i(87923),nt=i(48933),lt=i(37648),at=i(55492),ot=i(33138),rt=i(47786),ht=i(75256),dt=i(80226),ct=i(22326),_t=i(46467),ut=i(48952),It=i(47324),mt=i(66479),gt=i(92415),pt=i(22662),Ct=i(53931),St=i(73814),ft=i(65550),Tt=i(21334),yt=i(85770),At=i(72800),Dt=i(84708),Et=i(98606),vt=i(2129),wt=i(25773),Rt=i(29839)
function Pt(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let Ot=null,Lt=(s=(0,g.GH)(gt.k.SM_GetFireReward),n=(0,g.GH)(gt.k.SM_EndPass),l=(0,g.GH)(gt.k.SM_StartThinking),
a=(0,g.GH)(gt.k.SM_StartPass),o=(0,g.GH)(gt.k.SM_OpenInvitePanel),r=(0,g.GH)(gt.k.SM_InvitePass),h=(0,g.GH)(gt.k.SM_DealInvitePass),d=(0,g.GH)(gt.k.SM_AllianceAnswerRank),c=(0,
g.GH)(gt.k.SM_AllianceAnswerStage),_=(0,g.GH)(gt.k.SM_AllianceAnswerSucc),I=class t{static __StaticInit(){Ot=Math.abs}constructor(){this.BornFireObjID=null,
this.BoreFireObjForMoveCamID=null,this.BornFireDisplayID=null,this.BornFirePos=null,this.NeedChuanGongToPlayerId=null,this.InviterPos=null,this.TmpInviterId=null,
this.MoveToInviterTimerId=null,this.RecordTimerCallCount=0,this.ChuanGongElementIdList={},this.EndMapInviteChuanGongPlayId=null,this.OnEnterAllianceHander=null,
this.OnEnterAllianceHanderParam=null,this.map=null,this._degf_TimerMoveToInviterHandle=null,this._degf_PlayElementComplete=null,this.BornFirePos=new L.P(40.1,0,40),
this.InviterPos=new L.P(0,0,0)
const t=P.Y.Inst.GetOrCreateCsv(C.h.eAsuramPartyResourceCsv)
this.map=t.GetCsvMap(),this.AddLis()}static GetInst(){return null==t._inst&&(t._inst=new t),t._inst}AddLis(){this._degf_TimerMoveToInviterHandle=(0,
B.v)(this.TimerMoveToInviter,this),this._degf_PlayElementComplete=(0,B.v)(this.PlayElementComplete,this)}SM_GetFireRewardHandle(t){const e=t
Dt.H.Inst_get().SubmitFireAwardIsGot_set(e.isGetReward)}SM_EndPassHandle(t){const e=t
Dt.H.Inst_get().IsShowDouble_set(e.isDouble),this.CloseRyAllianceCopyChuanGongView(),q.Y.Log("停止传功"),
"-1"!=e.playerId.ToString()?this.EndChuanGongActionAndElement(e.playerId,G.Y.Inst.PrimaryRole_get().Roleinfo_get().Id_get()):this.PlayChuanGoneElement(G.Y.Inst.PrimaryRole_get().Roleinfo_get().Id_get(),H.k.CHUANGONG_END)
}SM_StartThinkingHandle(t){const e=t
U._.getInst().endHang()
G.Y.Inst.PrimaryRole_get().StopPathingByForce(!0),U._.getInst().CloseStartIcon(),Dt.H.Inst_get().BeChuanGongLeftCount_set(e.bePassTime),
Dt.H.Inst_get().ChuanGongLeftCount_set(e.passTime),Dt.H.Inst_get().IsChuanGongNotMinXiang_set(!1),this.OpenRyAllianceCopyChuanGongView(),this.ClearChuanGongElement(),
this.PlayChuanGoneElement(G.Y.Inst.PrimaryRole_get().Roleinfo_get().Id_get(),H.k.CHUANGONG_START)}SM_StartPassHandle(t){q.Y.Log("开始传功")
const e=t
U._.getInst().endHang()
const i=G.Y.Inst.PrimaryRole_get()
U._.getInst().CloseStartIcon(),i.StopPathingByForce(!0),Dt.H.Inst_get().BeChuanGongLeftCount_set(e.bePassTime),Dt.H.Inst_get().ChuanGongLeftCount_set(e.passTime),
Dt.H.Inst_get().IsChuanGongNotMinXiang_set(!0),this.OpenRyAllianceCopyChuanGongView(),this.ClearChuanGongElement(),
this.StartChuanGongActionAndElement(e.playerId,G.Y.Inst.PrimaryRole_get().Roleinfo_get().Id_get())}SM_OpenInvitePanelHandle(t){const e=t
Dt.H.Inst_get().InviteChuanGongMsg_set(e),Dt.H.Inst_get().IsShowDouble_set(e.isDouble),Dt.H.Inst_get().BeChuanGongLeftCount_set(e.bePassTime),
Dt.H.Inst_get().ChuanGongLeftCount_set(e.passTime)}SM_InvitePassHandle(t){const e=t,i=(0,M.T)("已成功发送邀请")
ft.y.inst.ClientStrMsg(pt.r.SystemTipMessage,i),X.K.Inst().SetInvitedPlayerId(e.playerId),k.i.Inst.RaiseEvent(et.g.ALLIANCE_SUCCESS_INVITE)}SM_DealInvitePassHandle(t){const e=t
let i=!1
G.Y.Inst.GetMultiPlayer(e.playerId)&&(i=!0),i?(this.NeedChuanGongToPlayerId=null,this.IsInAllianceScene()||this.EnterRyAllianceScene()):(this.NeedChuanGongToPlayerId=e.playerId,
this.IsInAllianceScene()?this.ProcessMoveToInviterChuanGong():this.EnterRyAllianceScene()),Z.d.Inst_get().CloseAssistBasePanel()}ReqCM_DealInvitePass(t){const e=new ht.I
e.playerId=t,e.agree=!0,x.C.Inst.F_SendMsg(e)
let i=!1
const s=Dt.H.Inst_get().InviteChuanGongMsg_get()
if(s){const e=s.playerMessages
for(const[s,n]of(0,b.V5)(e)){if(n.playerId==t){e.Remove(n),i=!0
break}}}i&&Dt.H.Inst_get().InviteChuanGongMsg_set(s)}ReqCM_InvitePass(t){const e=new _t.v
e.playerId=t,x.C.Inst.F_SendMsg(e)}ReqCM_OpenInvitePanel(){const t=new ut.q
x.C.Inst.F_SendMsg(t)}ReqCM_StartPass(t){const e=new It.G
e.playerId=t,x.C.Inst.F_SendMsg(e)}ReqCM_StartThinking(){const t=new mt.x
x.C.Inst.F_SendMsg(t)}ReqCM_InviteFireItem(t){const e=new ct.K
e.resourceId=t,x.C.Inst.F_SendMsg(e)}ReqCM_GetFireReward(){const t=new dt.O
x.C.Inst.F_SendMsg(t)}SM_AllianceAnswerRank(t){K.w.Inst_get().rank_set(t)}SM_AllianceAnswerStage(t){K.w.Inst_get().info_set(t)}SM_AllianceAnswerSucc(t){
K.w.Inst_get().SM_AllianceAnswerSuccHandler(t)}GetFireItemMap(){return this.map}GetFireItemCfg(t){if(this.map.LuaDic_ContainsKey(t))return this.map[t]}IsBornFireActivityOpen(){
let t=Dt.H.Inst_get().BornFireOpen
return!!t||(t=Dt.H.Inst_get().SubmitFireOpen,!!t)}IsChuanGongActivityOpen(){return Dt.H.Inst_get().ChuanGongOpen}RefreshActivityTipShowHide(){}OpenSubmitFireItemView(){
Y.N.inst.ClearAllPanel(!0,!0,v.I.RyAllianceCopyBornFireView,null)
const t=new E.v
t.layerType=w.F.MainUI,t.isDefaultUITween=!0,t.isShowMask=!0,t.maskAlpha=1e-4,t.viewClass=wt.u,Y.N.inst.OpenById(v.I.RyAllianceCopySubmitFireView,null,null,t)}
CloseSubmitFireItemView(){Y.N.inst.CloseById(v.I.RyAllianceCopySubmitFireView)}OpenQuestionView(){if(!lt.P.Inst_get().IsFunctionOpened(at.x.ASURAM_BORNFIRE))return
if(yt.a.Inst_get().curCopyType==At.S.AllianceHome){const t=new E.v
t.layerType=w.F.MainUI,t.positionType=W.$.eCustom,t.isShowMask=!0,t.isDefaultUITween=!0,t.isSelfTween=!1,t.viewClass=$.T,Y.N.inst.OpenById(v.I.AlliQuestionView,null,null,t)}}
CloseQuestionView(){Y.N.inst.CloseById(v.I.AlliQuestionView)}OpenBeginFireItemView(){const t=new E.v
t.isShowMask=!0,t.layerType=w.F.MainUI,t.isDefaultUITween=!0,t.viewClass=Et.R,Y.N.inst.OpenById(v.I.RyAllianceCopyBeginFireView,null,null,t)}CloseBeginFireItemView(){
Y.N.inst.CloseById(v.I.RyAllianceCopyBeginFireView)}OpenChuanGongView(){const t=new E.v
t.isShowMask=!0,t.layerType=w.F.MainUI,t.viewClass=J.n,Y.N.inst.OpenById(v.I.RyAllianceChuanGongView,null,null,t)}CloseChuanGongView(){(0,p.sR)(v.I.RyAllianceChuanGongView)}
OpenMinXiangView(){const t=new E.v
t.isShowMask=!0,t.layerType=w.F.MainUI,t.viewClass=z.j,Y.N.inst.OpenById(v.I.RyAllianceMinXiangView,null,null,t)}CloseMinXiangView(){(0,p.sR)(v.I.RyAllianceMinXiangView)}
OpenRyAllianceCopyChuanGongView(){const t=Y.N.inst.GetViewById(v.I.RyAllianceCopyChuanGongView)
if(t)return void t.OnAddToScene()
const e=new E.v
e.layerType=w.F.DefaultUI,e.viewClass=St.T,Y.N.inst.OpenById(v.I.RyAllianceCopyChuanGongView,null,null,e)}CloseRyAllianceCopyChuanGongView(){
Y.N.inst.CloseById(v.I.RyAllianceCopyChuanGongView)}OpenRyAllianceCopySubmitFireConfirmView(){const t=Y.N.inst.GetViewById(v.I.RyAllianceCopySubmitFireConfirmView)
if(t)return void t.OnAddToScene()
const e=new E.v
e.layerType=w.F.MainUI,e.viewClass=vt.U,Y.N.inst.OpenById(v.I.RyAllianceCopySubmitFireConfirmView,null,null,e)}CloseRyAllianceCopySubmitFireConfirmView(){
Y.N.inst.CloseById(v.I.RyAllianceCopySubmitFireConfirmView)}CloseCopyUI(t){if(t){const e=Tt.p.Inst_get().GetMapById(t)
if(e&&"ASURAM_SCENE"!=e.controllerType)return}this.CloseRyAllianceCopyChuanGongView(),this.ClearChuanGongElement(),this.ClearMoveToInviterTimer()}EnterRyAllianceScene(t=null){
this.EndMapInviteChuanGongPlayId=t,Rt.p.inst.CommonEnterCopy("copyId",1e4)}EnterRyAllianceSceneWithHander(t,e){this.OnEnterAllianceHander=t,this.OnEnterAllianceHanderParam=e,
Rt.p.inst.CommonEnterCopy("copyId",1e4)}SubmitFireItemReq(t){const e=new Ct.u
e.resourceId=t,x.C.Inst.F_SendMsg(e)}FireOh(t){if(this.BornFireObjID&&this.BornFireDisplayID){const e=H.k.TRANSPORT_MAP_START
k.i.Inst.RaiseEvent(et.g.RYALLIANCE_FIREOH,[this.BornFireObjID,e,t])}}BroacastSubmitSuccess(t){const e=this.GetFireItemCfg(t)
if(e&&1==e.isWarning&&Dt.H.Inst_get().SubmitFireBroadcast_get()){const i=Dt.H.Inst_get().FireInfoMsg_get()
let s=0
if(i)for(const[e,n]of(0,b.V5)(i.fireVos)){const e=n
if(e.level==t){s=e.upNum
break}}const n=e.needNum-s-1
if(n<0)return
const l=0==n?114221:114213,a=rt.x.Inst().getItemById(l),o=ot.f.Inst().getItemById(e.itemId),r=2,h=`[${it.u.getColorStrByQuality(r)}]`,d=`${h}${o.name}[-]`,c=`${h}${e.name}[-]`,_=`${Math.floor(e.fireValue/100)}%`
let u
0==n?(u=F.o.Format(a.sys_messsage,d,c),u=j.M.ReplaceSlow(u,"{2}",_)):(u=F.o.Format(a.sys_messsage,d,`${n}`,c),u=j.M.ReplaceSlow(u,"{3}",_)),
Q.d.Inst_get().mgr.RequestCM_PublicChat(tt.L.ALLIANCE,u,u,new O.Z,null)}}ClearChuanGongElement(){for(const[t,e]of(0,b.X)(this.ChuanGongElementIdList))e&&N.X.Inst.DeleteElement(e)
this.ChuanGongElementIdList={}}StartChuanGongActionAndElement(t,e){const i=G.Y.Inst.getRoleById(t),s=G.Y.Inst.getRoleById(e)
i&&s&&(i.PlayTransferEffect(s),s.PlayTransferEffect(i),i.rotateTo(s.GetPos()),s.rotateTo(i.GetPos()))}EndChuanGongActionAndElement(t,e){
const i=G.Y.Inst.getRoleById(t),s=G.Y.Inst.getRoleById(e)
i&&s&&(i.PlayTransferEndEffect(s),s.PlayTransferEndEffect(i))}PlayChuanGoneElement(t,e){const i=G.Y.Inst.getRoleById(t)
if(i){this.ChuanGongElementIdList[t]&&N.X.Inst.DeleteElement(this.ChuanGongElementIdList[t]),i.GetCurPos(nt.I.calVec0)
const s=L.P.zero_get(),n=N.X.Inst.PlayElement(e,i.GetHandle(),0,nt.I.calVec0,s,0,this._degf_PlayElementComplete)
this.ChuanGongElementIdList[t]=n}}PlayElementComplete(t){this.ClearChuanGongElement()}TimerMoveToInviter(){let t=!0
if(this.RecordTimerCallCount+=1,this.TmpInviterId&&this.RecordTimerCallCount<=60){const e=G.Y.Inst.getRoleById(R.o.FromNumber(this.TmpInviterId))
if(e){const t=G.Y.Inst.PrimaryRole_get()
e.GetCurPos(nt.I.calVec0),t.GetCurPos(nt.I.calVec1),[nt.I.calVec2.x,nt.I.calVec2.z]=[nt.I.calVec1.x,nt.I.calVec1.z],nt.I.calVec1.Sub(nt.I.calVec0)
const i=nt.I.calVec1.x*nt.I.calVec1.x+nt.I.calVec1.z*nt.I.calVec1.z
if(i<=4&&i>=1)this.ClearMoveToInviterTimer(),t.StopPathingByForce(!0),this.ReqCM_StartPass(this.TmpInviterId),this.TmpInviterId=null
else{const e=nt.I.calVec0.Sub(nt.I.calVec2)
let i
e.y=0,e.SqrMagnitude()>1e-4&&(i=st.l.GetPosBetweenTwoPos(nt.I.calVec0,nt.I.calVec2,1.5,1.5),i=i.add(nt.I.calVec2)),i&&A.c.Instance_get().CanArrive(i.x,i.z)||(i=nt.I.calVec2,i.y=0,
[i.x,i.y,i.z]=st.l.GetRandomPosCanArriveByRing(nt.I.calVec0,1,1.9,null)),t.gotoPoint(i,y.m.Point,null,null,null),this.InviterPos.x=i.x,this.InviterPos.z=i.z}
}else this.RecordTimerCallCount>5&&(t=!1)}else t=!1
t||(q.Y.LogWarning("inviter dispear, assert chuangong"),this.ClearMoveToInviterTimer())}IsInAllianceScene(){const t=V.b.Inst.currentMapId_get(),e=Tt.p.Inst_get().GetMapById(t)
return!(!e||"ASURAM_SCENE"!=e.controllerType)}ClearMoveToInviterTimer(){this.InviterPos.x=0,this.InviterPos.z=0,
this.MoveToInviterTimerId&&(D.C.Inst_get().ClearInterval(this.MoveToInviterTimerId),this.MoveToInviterTimerId=null)}TestProcessMoveToInviterChuanGong(){for(const[t,e]of(0,
b.V5)(G.Y.RoleInfoDic))if(!G.Y.Inst.GetMultiPlayer(e.Id_get()))return this.NeedChuanGongToPlayerId=e.Id_get(),void this.ProcessMoveToInviterChuanGong()}
ProcessMoveToInviterChuanGong(){this.ClearMoveToInviterTimer(),this.NeedChuanGongToPlayerId&&(this.TmpInviterId=this.NeedChuanGongToPlayerId.ToNum(),this.RecordTimerCallCount=0,
this.MoveToInviterTimerId=D.C.Inst_get().SetInterval(this._degf_TimerMoveToInviterHandle,1e3,-1)),this.NeedChuanGongToPlayerId=null}ProcessEndMapInviteChuanGong(){
this.EndMapInviteChuanGongPlayId&&(this.ReqCM_InvitePass(this.EndMapInviteChuanGongPlayId),this.EndMapInviteChuanGongPlayId=null)}ProcessEnterAllianceHander(){
this.OnEnterAllianceHander&&(this.OnEnterAllianceHander(this.OnEnterAllianceHanderParam),this.OnEnterAllianceHander=null,this.OnEnterAllianceHanderParam=null)}
OnEnterAllianceScene(){this.RefreshBornFireClientObj(),this.ProcessMoveToInviterChuanGong(),this.ProcessEndMapInviteChuanGong(),this.ProcessEnterAllianceHander()}
CheckCanExitCopy(t){if(Y.N.inst.IsViewShowing(v.I.RyAllianceCopyChuanGongView)){const t=(0,M.T)("正在传功，无法退出副本")
return ft.y.inst.ClientStrMsg(pt.r.SystemTipMessage,t),!1}return p.qJ,!0}IsChuanGongIng(){
return!!Y.N.inst.IsViewShowing(v.I.RyAllianceCopyChuanGongView)||(!!(this.MoveToInviterTimerId&&this.MoveToInviterTimerId>0)||void 0)}RefreshBornFireClientObj(){
if(!this.IsInAllianceScene())return void this.DestroyFireClientObj()
if(yt.a.Inst_get().curCopyType!=At.S.AllianceHome)return void this.DestroyFireClientObj()
let t=208000100
if(this.IsBornFireActivityOpen()){const e=Dt.H.Inst_get().GetBorningFireVo()
if(e){t=this.map[e.level].modelId}}this.BornFireDisplayID!=t&&(this.DestroyFireClientObj(),q.Y.Log(`RefreshBornFireClientObj newDisplayID:${(0,S.tw)(t)}`),
t&&t>0&&(this.BornFireObjID=f.e.Inst_get().AddObj(T.M.BoneFire,t,this.BornFirePos.x,this.BornFirePos.z,0,6.5,.5),
this.BoreFireObjForMoveCamID=f.e.Inst_get().AddObj(T.M.Common,t,this.BornFirePos.x,this.BornFirePos.z,0,1e-4,1e-4)),this.BornFireDisplayID=t,this.BornFireDisplayID=t)}
DestroyFireClientObj(){this.BornFireObjID&&(f.e.Inst_get().RemoveObj(this.BornFireObjID),f.e.Inst_get().RemoveObj(this.BoreFireObjForMoveCamID),this.BornFireObjID=null,
this.BoreFireObjForMoveCamID=null,this.BornFireDisplayID=null)}},I._inst=null,Pt(u=I,"GetInst",[m.n],Object.getOwnPropertyDescriptor(u,"GetInst"),u),
Pt(u.prototype,"SM_GetFireRewardHandle",[s],Object.getOwnPropertyDescriptor(u.prototype,"SM_GetFireRewardHandle"),u.prototype),
Pt(u.prototype,"SM_EndPassHandle",[n],Object.getOwnPropertyDescriptor(u.prototype,"SM_EndPassHandle"),u.prototype),
Pt(u.prototype,"SM_StartThinkingHandle",[l],Object.getOwnPropertyDescriptor(u.prototype,"SM_StartThinkingHandle"),u.prototype),
Pt(u.prototype,"SM_StartPassHandle",[a],Object.getOwnPropertyDescriptor(u.prototype,"SM_StartPassHandle"),u.prototype),
Pt(u.prototype,"SM_OpenInvitePanelHandle",[o],Object.getOwnPropertyDescriptor(u.prototype,"SM_OpenInvitePanelHandle"),u.prototype),
Pt(u.prototype,"SM_InvitePassHandle",[r],Object.getOwnPropertyDescriptor(u.prototype,"SM_InvitePassHandle"),u.prototype),
Pt(u.prototype,"SM_DealInvitePassHandle",[h],Object.getOwnPropertyDescriptor(u.prototype,"SM_DealInvitePassHandle"),u.prototype),
Pt(u.prototype,"SM_AllianceAnswerRank",[d],Object.getOwnPropertyDescriptor(u.prototype,"SM_AllianceAnswerRank"),u.prototype),
Pt(u.prototype,"SM_AllianceAnswerStage",[c],Object.getOwnPropertyDescriptor(u.prototype,"SM_AllianceAnswerStage"),u.prototype),
Pt(u.prototype,"SM_AllianceAnswerSucc",[_],Object.getOwnPropertyDescriptor(u.prototype,"SM_AllianceAnswerSucc"),u.prototype),u)},83075:(t,e,i)=>{i.d(e,{R:()=>n})
var s=i(79534)
class n{static get inst(){return n._inst||(n._inst=new n),n._inst}constructor(){this.copyExpBtnView=null,this.copyInspireBtnView=null,this.controllBtnView=null,this.panelPos=null,
this.inspireControllerType=0,this._degf_DestroyCopyControlBtnView=null,this._degf_DestroyCopyExpBtnView=null,this._degf_DestroyCopyInspireBtnView=null,
this._degf_ShowCopyControlBtnViewHandler=null,this._degf_ShowCopyExpBtnViewHandler=null,this._degf_ShowCopyInspireBtnViewHandler=null,this.panelPos=new s.P,
this._degf_DestroyCopyControlBtnView=()=>this.DestroyCopyControlBtnView(),this._degf_DestroyCopyExpBtnView=()=>this.DestroyCopyExpBtnView(),
this._degf_DestroyCopyInspireBtnView=()=>this.DestroyCopyInspireBtnView(),this._degf_ShowCopyControlBtnViewHandler=t=>this.ShowCopyControlBtnViewHandler(t),
this._degf_ShowCopyExpBtnViewHandler=t=>this.ShowCopyExpBtnViewHandler(t),this._degf_ShowCopyInspireBtnViewHandler=t=>this.ShowCopyInspireBtnViewHandler(t),
this.panelPos=new s.P(204,118,0).Clone()}OpenCopyControlBtnView(t){if(null==t&&(t=0),
(t!=eCopyEnum.AllianceHome||AllianceModel.Inst_get().bossModel.isBossOpen_get())&&(null==this.controllBtnView||0==this.controllBtnView.isShow_get())){const t=new UIOpenParam
t.positionType=LuaPositionType.eCustom,t.aniDir=LuaDirectionType.Up,t.isSelfTween=!1,t.layerType=LayerType.DefaultUI,
UIShowMgr.inst.OpenById(eUIComponentID.CopyControlBtnPanel,this._degf_ShowCopyControlBtnViewHandler,this._degf_DestroyCopyControlBtnView,t)}}DestroyCopyControlBtnView(){
UIResMgr.DestroyUIObj(this.controllBtnView),this.controllBtnView=null}ShowCopyControlBtnViewHandler(t){
return null==this.controllBtnView&&(this.controllBtnView=new CopyControlBtnView,this.controllBtnView.setId(t,null,0)),this.controllBtnView}CloseCopyControlBtnView(){
null!=this.controllBtnView&&UIShowMgr.inst.ClosePanel(this.controllBtnView)}OpenCopyExpBtnView(){if(null==this.copyExpBtnView||0==this.copyExpBtnView.isShow_get()){
const t=new UIOpenParam
t.positionType=LuaPositionType.eCustom,t.aniDir=LuaDirectionType.Up,UIShowMgr.inst.OpenById(eUIComponentID.CopyExpBtnPanel,this._degf_ShowCopyExpBtnViewHandler,this._degf_DestroyCopyExpBtnView,t)
}}DestroyCopyExpBtnView(){UIResMgr.DestroyUIObj(this.copyExpBtnView),this.copyExpBtnView=null}ShowCopyExpBtnViewHandler(t){
return null==this.copyExpBtnView&&(this.copyExpBtnView=new CopyExpBtnView,this.copyExpBtnView.setId(t,null,0)),this.copyExpBtnView}CloseCopyExpBtnView(){
null!=this.copyExpBtnView&&UIShowMgr.inst.CloseById(eUIComponentID.CopyExpBtnPanel)}OpenCopyInspireBtnView(t){if(this.inspireControllerType=t,
null==this.copyInspireBtnView||0==this.copyInspireBtnView.isShow_get()){const t=new UIOpenParam
t.positionType=LuaPositionType.eCustom,t.aniDir=LuaDirectionType.Up,UIShowMgr.inst.OpenById(eUIComponentID.CopyInspireBtnPanel,this._degf_ShowCopyInspireBtnViewHandler,this._degf_DestroyCopyInspireBtnView,t)
}}DestroyCopyInspireBtnView(){UIResMgr.DestroyUIObj(this.copyInspireBtnView),this.copyInspireBtnView=null}ShowCopyInspireBtnViewHandler(t){
return null==this.copyInspireBtnView&&(this.copyInspireBtnView=new CopyInspireBtnView,this.copyInspireBtnView.setId(t,null,0)),this.copyInspireBtnView}CloseCopyInspireBtnView(){
null!=this.copyInspireBtnView&&UIShowMgr.inst.CloseById(eUIComponentID.CopyInspireBtnPanel)}SetInspireAndExpBtnState(){
null!=this.copyInspireBtnView&&this.copyInspireBtnView.setActive(),null!=this.copyExpBtnView&&this.copyExpBtnView.setActive()}}n._inst=null},84333:(t,e,i)=>{i.d(e,{s:()=>n})
var s=i(16812)
class n extends s.k{constructor(...t){super(...t),this.msglist=null}static GetInst(){return null==n._inst&&(n._inst=new n),n._inst}SetMsg(t){this.msglist=t}}n._inst=null},
15206:(t,e,i)=>{i.d(e,{B:()=>h})
var s=i(38836),n=i(98130),l=i(85602),a=i(98885)
class o{constructor(){this.key=null,this.type=null,this.param=null,this.value=null,this.paramAttributes=null}Parse(){let t="",e=null
t=this.param.ITEMID,null==t&&(t=this.param.MONSTERID),e=a.M.Split(t,a.M.s_Arr_CCD_CHAR_DOT),this.paramAttributes=new l.Z
let i=0
for(;i<e.count;)this.paramAttributes[i]=a.M.String2Int(e[i]),i+=1}}class r{constructor(){this.ITEMID=null,this.MONSTERID=null,this.LEVEL=0}}class h{constructor(){this.targets=null}
FillData(t){this.targets=new l.Z
const e=new l.Z(t.targets)
let i=0
for(;i<e.Count();){const t=e[i],s=new o
s.key=n.GF.LuaJsonToString(t.key),s.type=n.GF.LuaJsonToString(t.type),s.value=n.GF.LuaJsonToString(t.value),null!=t.param?(s.param=new r,
s.param.ITEMID=n.GF.LuaJsonToString(t.param.ITEMID),s.param.MONSTERID=n.GF.LuaJsonToString(t.param.MONSTERID)):s.param=null,this.targets.Add(s),i+=1}}Parse(){
if(null!=this.targets)for(const[t,e]of(0,s.V5)(this.targets))e.Parse()}}},42877:(t,e,i)=>{i.d(e,{U:()=>r})
var s=i(98800),n=i(98885),l=i(15771),a=i(85770),o=i(72800)
class r{constructor(){this.nowPrice=0}static Inst_get(){return null==r._Inst&&(r._Inst=new r),r._Inst}GetLeftCount(t){let e=0,i=0
if(t==o.S.WORLDBOSS)i=s.Y.Inst.PrimaryRoleInfo_get().BuyTimes_get()
else{const e=a.a.Inst_get().copyRecordDic
e.LuaDic_ContainsKey(t)&&(i=e[t].todayBuyTimes)}this.nowPrice=0
const r=l.U.inst.model.GetCopyAddCount(t)
if(e=r-i,r>0){const t=l.U.inst.model.nowPriceList
if(null!=t){let e=i
i>=t.count&&(e=t.count-1),this.nowPrice=n.M.String2Int(t[e])}}return e}GetUpVipBuy(t){let e=0
if(t==o.S.WORLDBOSS)e=s.Y.Inst.PrimaryRoleInfo_get().BuyTimes_get()
else{const i=a.a.Inst_get().copyRecordDic
i.LuaDic_ContainsKey(t)&&(e=i[t].todayBuyTimes)}this.nowPrice=0
const i=l.U.inst.model.GetCopyAddCount(t)
for(let e=l.U.inst.model.level_get()+1;e<=l.U.inst.model.MAX_LEVEL;e++){const s=l.U.inst.model.GetPanelResVO(e)
if(null!=s){const e=s.GetCopyAddCount(t)
if(e>i)return[e-i,s.nowPriceList[i]]}}return[0,0]}isVipExtraBuy(t){return t==o.S.LoseSecrets||t==o.S.Belial||t==o.S.BloodTown||t==o.S.Arena||t==o.S.SKY_ILLUSION||t==o.S.LostAbyss}}
r._Inst=null},85770:(t,e,i)=>{i.d(e,{a:()=>H})
var s,n,l,a=i(42292),o=i(86133),r=i(98800),h=i(97461),d=i(36241),c=i(68662),_=i(38935),u=i(62370),I=i(5924),m=i(95721),g=i(98885),p=i(85602),C=i(38962),S=i(84229),f=i(93353),T=i(92679),y=i(87923),A=i(37927),D=i(37648),E=i(55492),v=i(24524),w=i(75439),R=i(68561),P=i(85465),O=i(34843),L=i(15771),B=i(29839),b=i(83075),M=i(44210),G=i(72800)
let H=(0,a.gK)("GameSys.CopyBaseModel")((l=class t{constructor(){this.CopyViewType=1,this.inspireShow=null,this.inspireValShow=null,this.copyCoolTimeDic=null,
this.copyRecordDic=null,this.currentCopyId=0,this.gainItemLis=null,this.curCopyType=0,this.serverCopyId=0,this.lastCopyId=0,this.serverCopyType=0,this.copyEnterTimer=null,
this.copyEndState=0,this.copySuccessTime=0,this.copySuccessReward=null,this.sm_copyReward=null,this.copySuccessFirstReward=null,this.juqingCopyId=4,this.CopyRecoverCountDic=null,
this.encourageTypeTimes=null,this.encourageMap=null,this.isInEnterTime=!1,this.isShowTopBtn=!0,this.isStartExitCopy=!1,this.isCopyTip=!0,this.isSiegeTip=!1,this.isArenaTip=!1,
this.isSiegeEndTip=!1,this.soonEndTime=0,this.exiTimer=null,this.preEnterTimer=5,this.autoTimer=-1,this.waitTime=0,this.copySweepVo=null,this.copyRewardList=null,
this.sweepDoubleDic=null,this.multiple=0,this.IsAssistOther=!1,this.isNewRecord=!1,this._degf_DelayHangHandler=null,this._degf_RevertCompare=null,this.uiCopyId=-1,
this.defeatDenyClose=null,this.defeatDelayClose=null,this.readyExitCopy=null,this.encourageBossId=null,this.hasEnterLuolan=null,this.gainItemLis=new p.Z,
this.sweepDoubleDic=new C.X,this._degf_DelayHangHandler=()=>this.DelayHangHandler(),this._degf_RevertCompare=(t,e)=>this.RevertCompare(t,e),this.inspireShow=new C.X,
this.inspireShow.LuaDic_AddOrSetItem(3001,(0,o.T)("PVE伤害增加")),this.inspireShow.LuaDic_AddOrSetItem(3011,(0,o.T)("生命提升")),this.inspireShow.LuaDic_AddOrSetItem(40,(0,o.T)("鼓舞 防御 ")),
this.inspireShow.LuaDic_AddOrSetItem(200203,(0,o.T)("攻击力提升")),this.copyRecordDic=new C.X,this.copyEnterTimer=new C.X,this.copySuccessReward=new p.Z,
this.copySuccessFirstReward=new p.Z,this.CopyRecoverCountDic=new C.X,this.copyCoolTimeDic=new C.X,this.inspireValShow=new C.X,
this.defeatDenyClose=w.D.getInstance().GetIntValue("COPY:GENERALFAILLIMT"),this.defeatDelayClose=w.D.getInstance().GetIntValue("COPY:GENERALFAILTIEM")}static Inst_get(){
return null==t.Inst&&(t.Inst=new t),t.Inst}GetUICopyId(){return this.uiCopyId}SetUICopyId(t,e){this.uiCopyId=t,(null==e||e)&&h.i.Inst.RaiseEvent(T.g.COPY_ITEM_ID_SELECT,t)}
ExitCopy(){const t=new P.P
this.readyExitCopy=!0,this.copyRewardList=null,_.C.Inst.F_SendMsg(t)}Reset(){null!=this.copyCoolTimeDic&&this.copyCoolTimeDic.LuaDic_Clear(),this.CopyViewType=1,
null!=this.copyRecordDic&&this.copyRecordDic.LuaDic_Clear(),this.exiTimer=null,this.currentCopyId=0,this.gainItemLis.Clear(),this.curCopyType=0,this.serverCopyId=0,
this.serverCopyType=0,null!=this.copyEnterTimer&&this.copyEnterTimer.LuaDic_Clear(),this.copyEndState=0,this.copySuccessTime=0,
null!=this.copySuccessReward&&this.copySuccessReward.Clear(),null!=this.copySuccessFirstReward&&this.copySuccessFirstReward.Clear(),this.soonEndTime=0,this.juqingCopyId=4,
this.encourageTypeTimes=null,this.encourageMap=null,this.isStartExitCopy=!1,this.isShowTopBtn=!0,this.isCopyTip=!0,this.isSiegeEndTip=!1,this.isSiegeTip=!1,this.isArenaTip=!1,
this.lastCopyId=0,this.encourageBossId=null,this.hasEnterLuolan=!1,this.IsAssistOther=!1,this.sweepDoubleDic.Clear()}IsHaveCopyInspireCount(){
const t=v.o.Inst().getItemById(this.currentCopyId)
if(null==t)return!1
if(r.Y.Inst.PrimaryRoleInfo_get().Gold_get()<t.encourageGoldCost)return!1
if(null==this.encourageTypeTimes)return!0
let e=0,i=0
e=this.encourageTypeTimes.LuaDic_GetItem(1),null==e&&(e=0),i=this.encourageTypeTimes.LuaDic_GetItem(2),null==i&&(i=0)
return e+i<t.encourageDiamondNum&&e<t.encourageGoldNum}IsHaveCoinInspirCount(){let t=!0
return t=b.R.inst.inspireControllerType==G.S.AllianceHome?S.Q.Inst_get().bossModel.IsHaveInspirCountInAlliance():this.IsHaveCopyInspireCount(),t}GetEndTime(t){
const e=v.o.Inst().getItemById(t)
return null==e?0:this.copyEnterTimer.LuaDic_ContainsKey(e.controllerType)?this.copyEnterTimer[e.controllerType]+1e3*e.overTime:0}GetOkStartTime(t){const e=v.o.Inst().getItemById(t)
return null==e?0:this.copyEnterTimer.LuaDic_ContainsKey(e.controllerType)?this.copyEnterTimer[e.controllerType]:0}AddCopyRecoverCount(t,e){
this.CopyRecoverCountDic.LuaDic_ContainsKey(t)?this.CopyRecoverCountDic[t]=this.CopyRecoverCountDic[t]+e:this.CopyRecoverCountDic.LuaDic_AddOrSetItem(t,e)}IsHasCopyFuncOpen(){
let t=!1
return D.P.Inst_get().IsFunctionOpened(E.x.DEMON_SQUARE)?(t=!0,this.CopyViewType=A.i.BelielTab):D.P.Inst_get().IsFunctionOpened(E.x.BLOOD_CASTLE)?(t=!0,
this.CopyViewType=A.i.BloodTownTab):D.P.Inst_get().IsFunctionOpened(E.x.DREAM_LAND)&&(t=!0,this.CopyViewType=A.i.DreamlandTab),t}CopyIsAutoHang(t){if(null==t&&(t=!1),
B.p.inst.IsInCopy()){const e=v.o.Inst().getItemById(this.currentCopyId)
if(null==e)return
let i=""
if(i=t?e.reliveAutoHang:e.autoHang,"0"==i)return
const s=g.M.Split(i,u.o.s_UNDER_CHAR)
if(null!=s&&2==s.count){if(1==g.M.String2Int(s[0]))if("0"!=s[1]){const t=1e3*g.M.String2Int(s[1])
this.ClearDelayHangTimer(),this.autoTimer=I.C.Inst_get().SetInterval(this._degf_DelayHangHandler,t,1)}else d._.getInst().startHang()}}}getDelayHangTime(){
const t=v.o.Inst().getItemById(this.currentCopyId)
if(null==t)return 0
const e=t.autoHang
if("0"==e)return 0
const i=g.M.Split(e,u.o.s_UNDER_CHAR)
if(null!=i&&2==i.count){if(1==g.M.String2Int(i[0])&&"0"!=i[1]){return 1e3*g.M.String2Int(i[1])}}return 0}DelayHangHandler(){this.ClearDelayHangTimer(),d._.getInst().startHang()}
ClearDelayHangTimer(){I.C.Inst_get().ClearInterval(this.autoTimer),this.autoTimer=-1,f.g.Inst_get().ClearArenaHangTimer()}IsInPlotOrMapCopy(){
const t=v.o.Inst().getItemById(this.currentCopyId)
return null!=t&&(t.controllerType==G.S.Plot||t.controllerType==G.S.eMap)}getBloodTownLayerIconNameByLevel(t){let e=""
return 0==t?e="xuesechengbao_nb_0010":1==t?e="xuesechengbao_nb_0001":2==t?e="xuesechengbao_nb_0002":3==t?e="xuesechengbao_nb_0003":4==t?e="xuesechengbao_nb_0004":5==t?e="xuesechengbao_nb_0005":6==t?e="xuesechengbao_nb_0006":7==t?e="xuesechengbao_nb_0007":8==t?e="xuesechengbao_nb_0008":9==t&&(e="xuesechengbao_nb_0009"),
e}GetCopyIconByType(){let t=""
return this.curCopyType==G.S.BloodTown?t="ryhongdongicon2_sp_0008":this.curCopyType==G.S.Belial?t="ryhongdongicon2_sp_0009":(this.curCopyType==G.S.WORLDBOSS||this.curCopyType==G.S.WORLDBOSS_NEW||this.curCopyType==G.S.SKY_ILLUSION)&&(t="ryhongdongicon2_sp_0017"),
t}sortReward(t){null!=t&&(t.Count()<2||t.Sort(this._degf_RevertCompare))}RevertCompare(t,e){return-1*this.CompareItem1(t,e)}CompareItem1(t,e){const i=t,s=t
if(null==i&&null==s)return 0
if(null!=i){const t=e
return this.CompareItem2(i,t)}const n=e
return null==n?1:this.CompareItem2(s.baseData_get(),n.baseData_get())}CompareItem2(t,e){const i=y.l.isAngelEquip(t)
if(i!=y.l.isAngelEquip(e))return i?1:-1
const s=y.l.GetQualitySortValue(t),n=y.l.GetQualitySortValue(e)
if(s!=n)return s-n
if(t.isEquip_get()!=e.isEquip_get())return t.isEquip_get()?1:-1
const l=0!=t.AuctionState_get(),a=0!=e.AuctionState_get()
if(l&&!a)return-1
if(!l&&a)return 1
const o=y.l.GetItemValidTime(t),r=y.l.GetItemValidTime(e)
if(o!=r)return-1*(o-r)
if(0==t.isEquip_get()){if(t.cfgData_get().sort!=e.cfgData_get().sort)return t.cfgData_get().sort-e.cfgData_get().sort}else{
const i=R.X.Inst_get().GetEquipStar(t),s=R.X.Inst_get().GetEquipStar(e)
if(i!=s)return i-s
const n=y.l.GetEquipSortValue(t.equipInfo_get().Config_get().intPosition_get()),l=y.l.GetEquipSortValue(e.equipInfo_get().Config_get().intPosition_get())
if(n!=l)return n-l
const a=t.cfgData_get().job,o=e.cfgData_get().job
if(a!=o)return-1*(a-o)}return 0}CompareCopySucItem(t,e){if(t.rare!=e.rare)return t.rare?1:-1
const i=t.baseData_get(),s=e.baseData_get(),n=y.l.GetQualitySortValue(i),l=y.l.GetQualitySortValue(s)
if(n!=l)return n-l
const a=i.cfgData_get().IsSkillItem()
if(a!=s.cfgData_get().IsSkillItem())return a?1:-1
if(i.isEquip_get()!=s.isEquip_get())return i.isEquip_get()?1:-1
const o=y.l.GetItemValidTime(i),r=y.l.GetItemValidTime(s)
if(o!=r)return-1*(o-r)
if(0==i.isEquip_get()){if(i.cfgData_get().sort!=s.cfgData_get().sort)return i.cfgData_get().sort-s.cfgData_get().sort}else{
const t=R.X.Inst_get().GetEquipStar(i),e=R.X.Inst_get().GetEquipStar(s)
if(t!=e)return t-e
const n=y.l.GetEquipSortValue(i.equipInfo_get().Config_get().intPosition_get()),l=y.l.GetEquipSortValue(s.equipInfo_get().Config_get().intPosition_get())
if(n!=l)return n-l
const a=i.cfgData_get().job,o=s.cfgData_get().job
if(a!=o)return-1*(a-o)}return 0}GetCopyRecByKey(t){return null==this.copyRecordDic?null:this.copyRecordDic.LuaDic_ContainsKey(t)?this.copyRecordDic[t]:null}GetCurCopyRes(){
if(this.currentCopyId>0){return v.o.Inst().getItemById(this.currentCopyId)}return null}GetCopyPreTime(){if(this.currentCopyId<=0)return 0
const t=v.o.Inst().getItemById(this.currentCopyId),e=this.copyEnterTimer
let i=0
if(!e.LuaDic_ContainsKey(t.controllerType))return 0
i=e[t.controllerType]
const s=c.D.serverMSTime_get()-i
return 1e3*t.preTime-s}IsInCopyPreTime(){return this.GetCopyPreTime()>0}GetCopyLeftTimeExpectPre(){if(this.currentCopyId<=0)return-1
const e=v.o.Inst().getItemById(this.currentCopyId)
if(null==e)return-1
const i=c.D.serverMSTime_get(),s=t.Inst_get().GetOkStartTime(this.currentCopyId)
if(!m.o.IsNullOrZero(this.exiTimer)){const t=this.exiTimer.ToNum()
return i>=s?t-i:t-s}this.copyEnterTimer
let n=1e3*e.overTime
if(e.controllerType==G.S.BloodTown&&(n+=M.w.GetInst().GetNeedAddExTime()),i<s)return n
return n-(i-s)}GetCopyLeftTime(){if(this.currentCopyId<=0)return-1
if(!m.o.IsNullOrZero(this.exiTimer)){return this.exiTimer.ToNum()-c.D.serverMSTime_get()}const t=v.o.Inst().getItemById(this.currentCopyId)
if(null==t)return-1
const e=this.copyEnterTimer
let i=1e3*t.overTime
t.controllerType==G.S.BloodTown&&(i+=M.w.GetInst().GetNeedAddExTime())
let s=0
if(!e.LuaDic_ContainsKey(t.controllerType)||t.controllerType==G.S.RedFortressWaitingRoom)return-1
s=e[t.controllerType]
return i-(c.D.serverMSTime_get()-s)}GetCopyFreeNum(t){return L.U.inst.model.GetCopyFreeNum(t)}GetLastEnterItmes(t){const e=v.o.Inst().getItemByCopyType(t),i=this.GetCopyRecByKey(t)
return e.challengesTimes-i.todayEnterHistory+O.v.Inst_get().GetCopyHasRecoveredCount(t)+i.todayBuyTimes+i.todayItemTimes}},l.Inst=null,N=n=l,k="Inst_get",U=[a.Vx],
V=Object.getOwnPropertyDescriptor(n,"Inst_get"),x=n,F={},Object.keys(V).forEach((function(t){F[t]=V[t]})),F.enumerable=!!F.enumerable,F.configurable=!!F.configurable,
("value"in F||F.initializer)&&(F.writable=!0),F=U.slice().reverse().reduce((function(t,e){return e(N,k,t)||t}),F),
x&&void 0!==F.initializer&&(F.value=F.initializer?F.initializer.call(x):void 0,F.initializer=void 0),void 0===F.initializer&&(Object.defineProperty(N,k,F),F=null),s=n))||s
var N,k,U,V,x,F},56632:(t,e,i)=>{i.d(e,{E:()=>s})
class s{constructor(){this.clickIndex=1,this.hasUse1=!1,this.hasUse2=!1,this.hasUse3=!1,this.hasUse4=!1,this.hasUse5=!1,this.msgdata=null,this.itemMsgData=null,this.data=null,
this.curGetExp=0}static Inst_get(){return null==s._Inst&&(s._Inst=new s),s._Inst}reset(){s.Inst_get().hasUse1=!1,s.Inst_get().hasUse2=!1,s.Inst_get().hasUse3=!1,
s.Inst_get().hasUse4=!1,s.Inst_get().hasUse5=!1,this.curGetExp=0}}s._Inst=null},44210:(t,e,i)=>{i.d(e,{w:()=>O})
var s=i(93984),n=i(38836),l=i(98800),a=i(61646),o=i(93701),r=i(4926),h=i(97461),d=i(36241),c=i(98958),_=i(73136),u=i(68662),I=i(13687),m=i(16812),g=i(38935),p=i(5924),C=i(55360),S=i(98885),f=i(85602),T=i(38962),y=i(92679),A=i(87923),D=i(24524),E=i(75439),v=i(2197),w=i(29839),R=i(85770),P=i(90912)
class O extends m.k{constructor(){super(!1,0),this.npcId=100046,this.swordId=10710,this.stage=0,this.progress=0,this.evaluate=0,this.copyTargets=null,this.rewardMsg=null,
this.IsNewStage=!1,this.curStageStartTime=0,this.teamScore=0,this.allianceScore=0,this.evaluateScores=null,this.firstroundStage=0,this.evaluateSecond=0,this.isSuccess=!1,
this.showType=0,this.isOpenedDialoguePanel=!1,this.firstStageTargetList=null,this.dropItems=null,this.currentEffectId=0,this.hasSet=!1,this.lastCopyId_ForCalculateItemId=0,
this.advanceDropItemId=0,this._degf_SetBloodTownCopyBox=null,this._degf_StartHang=null,this.rankInfos=null,this.bloodTownData=null,this.copyroundCfgMap=null,
this.killMonsterDic=null,this.addExTime=null,this._degf_SetBloodTownCopyBox=(t,e)=>this.SetBloodTownCopyBox(t,e),this._degf_StartHang=()=>this.StartHang()
const t=C.Y.Inst.GetOrCreateCsv(s.h.eCopyroundresourceCsv)
null!=t&&(this.copyroundCfgMap=t.GetCsvMap()),this.killMonsterDic=new T.X,this.GetCopyRandKillMonsterList(2000201)}static GetInst(){return null==O._inst&&(O._inst=new O),O._inst}
GetCopyRandKillMonsterList(t){if(this.killMonsterDic.LuaDic_ContainsKey(t))return this.killMonsterDic[t]
const e=new f.Z
for(const[i,s]of(0,n.V5)(this.copyroundCfgMap)){const i=s
if(i.copyId==t)if(i.type==O.KILL_MONSTER){const t=S.M.Split(i.params,"_")
e[i.roundId-1]=S.M.String2Int(t[1])}else e[i.roundId-1]=0}const i=new f.Z
let s=0,l=0
for(let t=0;t<=e.count-1;t++)e[t]>0&&(i[l]=s+e[t],s=i[l],l+=1)
return this.killMonsterDic.LuaDic_Add(t,i),i}GetChildStageKillMonsterNum(t,e){const i=this.GetCopyRandKillMonsterList(t)
return i.count>=e?i[e-1]:0}InBeforeAttackDoorStage(){return w.p.inst.IsCopyInBloodTown()&&w.p.inst.curstage<O.DOOR_STAGE}IsDoor(t){return t==O.DOOR_ID}SetNpcTopUI(t){
const e=l.Y.Inst.getNpcById(this.npcId)
if(0!=this.currentEffectId&&o.a.ins.DeleteEffShowById(this.currentEffectId),null!=e&&w.p.inst.IsInCopy()&&0==t){const t=e.GetPos()
e.GetHandle()
let i=new r.E
i.source=e,i.target=e,i.effRole=e,i.speedRate=4.7,this.stage==O.STAGE_NUM?i.SetCfg(a.k.CAN_REWARD_TASK):i.SetCfg(a.k.UNFINISH_TASK),i.SetPoint(t.x,t.z+1.5),
this.currentEffectId=o.a.ins.showEffectByData(i)}}ParseCfg(){const t=D.o.Inst().getItemById(R.a.Inst_get().currentCopyId)
null!=t&&(this.copyTargets=t.CopyTargetsVal_get())}GetNeedAddExTime(){return null==this.addExTime&&(this.addExTime=E.D.getInstance().GetIntValue("BLOODTOWN:DALAY_CLOSE_TIME")),
this.IsInAddExTimeStage()?1e3*this.addExTime:0}IsInAddExTimeStage(){return!!w.p.inst.IsCopyInBloodTown()&&w.p.inst.curstage==O.STAGE_NUM}GetCurTask(){this.ParseCfg()
for(const[t,e]of(0,n.V5)(this.copyTargets.targets))if(S.M.String2Int(e.key)==this.stage)return e
return null}HandleEvaluate(t){this.IsNewStage=!1,this.evaluate=t.evaluateLevel,this.evaluateSecond=t.evaluateLevelEndSeconds,this.curStageStartTime=u.D.serverMSTime_get(),
this.RaiseEvent(P.s.EVALUATE_UPDATE,t)}HandleStageRewards(t){this.rewardMsg=t}GetRwardItemList(){if(null!=this.rewardMsg){return A.l.GetBagItemListByAb(this.rewardMsg.items)}
return null}GetTeamScore(){return 0}EnterMap(){this.firstroundStage=0}GetAllianceScore(){return 0}GetTotalScore(){let t=0
if(null!=this.rewardMsg){t=this.GetTeamScore()+this.GetAllianceScore()}return t}HandleTargets(t){let e=0
const i=w.p.inst.curstage,s=i
let l=`oldstage：${i}，stage：`
for(const[i,s]of(0,n.V5)(t.list)){const t=s
this.stage=t.keyName,l+=`${this.stage}_`,w.p.inst.curstage=this.stage,0==t.value&&(this.IsNewStage=!0),this.progress=t.value
const i=this.GetCurTask()
if(e=S.M.String2Int(i.value),this.progress>=e&&(this.stage<O.STAGE_NUM?(this.progress=0,this.stage+=1,w.p.inst.curstage=this.stage,l+=`|${this.stage}|_`,this.IsNewStage=!0,
this.ChangeStage()):this.RaiseEvent(P.s.COMPLETE,null),this.CheckMapInfo()),1==this.stage){let e=0
for(this.firstStageTargetList=this.GetCopyRandKillMonsterList(R.a.Inst_get().currentCopyId);e<this.firstStageTargetList.Count();){if(t.value<this.firstStageTargetList[e]){
w.p.inst.curchildstage=`${e+1}`,l+=`,curchildstage:${w.p.inst.curchildstage}。`
break}e+=1}}else w.p.inst.curchildstage=""}if(w.p.inst.curstage==O.STAGE_NUM&&s==O.STAGE_NUM-1&&this.SetNpcTopUI(0),this.RaiseEvent(P.s.PROGRESS_UPDATE,null),
7==w.p.inst.curstage&&!this.hasSet){const t=E.D.getInstance().GetIntValue("COPY:BLOOD_AUTO_HANG_DELAY")
p.C.Inst_get().SetInterval(this._degf_StartHang,t,1),this.hasSet=!0}7!=w.p.inst.curstage&&(this.hasSet=!1),7==w.p.inst.curstage&&(this.StartHang(),
p.C.Inst_get().SetInterval(this._degf_StartHang,50,1)),0!=i&&w.p.inst.curstage!=i&&h.i.Inst.RaiseEvent(y.g.COPY_STAGE_UPDATE_REAL)}StartHang(){
w.p.inst.IsCopyInBloodTown()&&d._.getInst().startHang()}ChangeStage(){}ExitModel(){this.firstroundStage=0}Reset(){this.IsNewStage=!0,this.stage=1,this.progress=0,this.evaluate=0}
CheckMapInfo(){this.stage>4?I.b.Inst.SetLogicCheckEx=null:I.b.Inst.SetLogicCheckEx=this._degf_SetBloodTownCopyBox}SetBloodTownCopyBox(t,e){
return!_.c.Instance_get().GetTerrainExtendXZ(t,e,4)}GetNpcDialogue(t){let e=""
return this.stage!=O.STAGE_NUM?t:(e=c.V.Inst().getStr2(10030),e)}SendEndMessage(){const t=new v.Q
t.itemmodelId=this.swordId,t.num=1,g.C.Inst.F_SendMsg(t)}}O._inst=null,O.COPY_TYPE=2,O.STAGE_NUM=7,O.DOOR_STAGE=2,O.DOOR_ID=320002017,O.KILL_MONSTER="KILL_MONSTER"},
83496:(t,e,i)=>{i.d(e,{R:()=>a})
var s=i(73865),n=i(24524),l=i(85770)
class a{constructor(){this.msgdata=null,this.isAutoUsing=!1,this.isColdingSlow=!1,this.settleData=null,this.coldEndTime=-1,this.nextRoundExistBoss=!1,this.immediatelyNotice=!1,
this.nextRound=!1,this.buffPrice=0,this.buffId=0,this.buffColdTime=0,this.addBuffData=null,this.curSkyCopyId=0,this.isGuideSlow=!0,this.isMonsterHalf=!1,this.InitConfigData()}
static Inst_get(){return null==a._Inst&&(a._Inst=new a),a._Inst}Clear(){this.msgdata=null,this.IsAutoUsing_set(!1),this.isColdingSlow=!1,this.isGuideSlow=!0,
this.IsMonsterHalf_set(!1)}CountEvaluate(t){const e=n.o.Inst().getItemById(l.a.Inst_get().currentCopyId).EvaluateTimesVal_get()
let i=5,s=0
for(;s<e.Count();){if(t>=e[s]){i=s
break}s+=1}return i}InitConfigData(){}IsAutoUsing_get(){return this.isAutoUsing}IsAutoUsing_set(t){this.isAutoUsing=t
const e=s.y.Inst.GetSlowBtnView()
null!=e&&e.SetAutoText()}IsMonsterHalf_set(t){this.isMonsterHalf=t
const e=a.Inst_get().GetLeftSlowTimes()
if(this.isMonsterHalf&&!this.isColdingSlow&&!this.IsAutoUsing_get()&&e>0){const t=s.y.Inst.GetSlowBtnView()
null!=t&&t.ShowWaveAnim()}else{const t=s.y.Inst.GetSlowBtnView()
null!=t&&t.StopWaveAnim()}this.isMonsterHalf&&!this.isColdingSlow&&this.IsAutoUsing_get()}GetLeftSlowTimes(){let t=0
return null!=this.addBuffData&&(t=this.addBuffData.leftBuffTimes),t}}a._Inst=null},84708:(t,e,i)=>{i.d(e,{H:()=>I})
var s=i(38836),n=i(98800),l=i(97461),a=i(68662),o=i(16812),r=i(92679),h=i(37648),d=i(55492),c=i(14792),_=i(62734),u=i(78417)
class I extends o.k{constructor(...t){super(...t),this.FireInfoMsg=null,this.SubmitFireEndTime=-1,this.BornFireEndTime=-1,this.ChuanGongEndTime=-1,this.BorningFireIndex=null,
this.SubmitFireOpen=!1,this.BornFireOpen=!1,this.ChuanGongOpen=!1,this.FireAllExp=null,this.SubmitFirePlayers=null,this.InviteChuanGongMsg=null,this.ChuanGongLeftCount=0,
this.BeChuanGongLeftCount=0,this.IsChuanGongNotMinXiang=!0,this.ClientAddExpRate=0,this.submitFireBroadcast=!0,this.confirmSubmitFireVo=null,this.submitFireAwardIsGot=!1,
this.isShowDouble=!1,this.ChuanGongOpenRemindKey="ChuanGongOpenRemindKey"}static Inst_get(){return null==I._Inst&&(I._Inst=new I),I._Inst}ResetModel(){
u.L.GetInst().DestroyFireClientObj(),_.f.Inst.SetState(c.t.RYALLIANCE_CHUANGONGASSIT,!1),this.isShowDouble=!1}FireInfoMsg_set(t){if(this.FireInfoMsg=t,this.BorningFireIndex=null,
t){const t=this.FireInfoMsg.fireVos
let e,i=0
for(const[n,l]of(0,s.V5)(t)){const t=l
t.fire&&(!e||t.level>e)&&(this.BorningFireIndex=i,e=t.level),i+=1}}this.ClientAddExpRate=this.CalculteAddExpRate()}ClientAddExpRate_get(){return this.ClientAddExpRate}
CalculteAddExpRate(){if(this.FireInfoMsg&&this.FireInfoMsg.fireVos){const t=this.FireInfoMsg.fireVos
let e=0,i=0,n=0,l=0
for(const[a,o]of(0,s.V5)(t)){const t=o,s=u.L.GetInst().GetFireItemCfg(t.level)
i+=s.singleValue*t.upNum,l=s.singleMax,t.fire&&n<s.fireValue&&(n=s.fireValue),e+=1}return i>l&&(i=l),n+i}return 0}FireInfoMsg_get(){return this.FireInfoMsg}GetBorningFireVo(){
if(null!=this.BorningFireIndex)return this.FireInfoMsg.fireVos[this.BorningFireIndex]}SubmitFireEndTime_set(t){this.SubmitFireEndTime=t,
this.SubmitFireOpen=this.SubmitFireLeftTime_get()>0}SubmitFireLeftTime_get(){const t=a.D.serverTime_get()
return this.SubmitFireEndTime>0&&this.SubmitFireEndTime>=t?this.SubmitFireEndTime-t:-1}BornFireEndTime_set(t){this.BornFireEndTime=t,
this.BornFireOpen=this.BornFireLeftTime_get()>0,this.BornFireOpen||this.SubmitFireOpen||(this.submitFireAwardIsGot=!1)}BornFireLeftTime_get(){const t=a.D.serverTime_get()
return this.BornFireEndTime>0&&this.BornFireEndTime>=t?this.BornFireEndTime-t:-1}ChuanGongEndTime_set(t){this.ChuanGongEndTime=t,this.ChuanGongOpen=this.ChuanGongLeftTime_get()>0,
this.RefreshChuanGongCanAcceptRedpoint()}RefreshChuanGongCanAcceptRedpoint(){
const t=h.P.Inst_get().IsFunctionOpened(d.x.ASURAM_CHUANGONG),e=n.Y.Inst.PrimaryRoleInfo_get().isHaveAlliance_get()
let i=!1
t&&e&&this.ChuanGongOpen&&(this.InviteChuanGongMsg?this.BeChuanGongLeftCount>0&&(i=!0):i=!0),_.f.Inst.SetState(c.t.ALLIANCE_CHUANGONG_CAN_ACCEPT,i)}ChuanGongLeftTime_get(){
const t=a.D.serverTime_get()
return this.ChuanGongEndTime>0&&this.ChuanGongEndTime>=t?this.ChuanGongEndTime-t:-1}FireAllExp_set(t){this.FireAllExp=t}FireAllExp_get(){return this.FireAllExp}
SubmitFirePlayers_set(t){this.SubmitFirePlayers=t}SubmitFirePlayers_get(){return this.SubmitFirePlayers}InviteChuanGongMsg_set(t){let e=!1
if(this.InviteChuanGongMsg!=t&&t&&t.playerMessages.Count()>0)if(this.InviteChuanGongMsg)if(this.InviteChuanGongMsg.playerMessages.Count()<t.playerMessages.Count())e=!0
else{const i={},n={}
for(const[e,n]of(0,s.V5)(t.playerMessages)){i[n.playerId.ToString()]=!0}for(const[t,e]of(0,s.V5)(this.InviteChuanGongMsg.playerMessages)){n[e.playerId.ToString()]=!0}
for(const[t,l]of(0,s.vy)(i))if(!n[t]){e=!0
break}}else e=!0
this.InviteChuanGongMsg=t,t&&l.i.Inst.RaiseEvent(r.g.RYALLIANCE_CHUANGONGINVITE),e&&_.f.Inst.SetState(c.t.RYALLIANCE_CHUANGONGASSIT,!0)}IsShowDouble_get(){return this.isShowDouble}
IsShowDouble_set(t){this.isShowDouble=t,l.i.Inst.RaiseEvent(r.g.RYALLIANCE_CHUANGONGDOUBLE)}InviteChuanGongMsg_get(){return this.InviteChuanGongMsg}ChuanGongLeftCount_set(t){
this.ChuanGongLeftCount=t}ChuanGongLeftCount_get(){return this.ChuanGongLeftCount}BeChuanGongLeftCount_set(t){this.BeChuanGongLeftCount=t,this.RefreshChuanGongCanAcceptRedpoint()}
BeChuanGongLeftCount_get(){return this.BeChuanGongLeftCount}IsChuanGongNotMinXiang_set(t){this.IsChuanGongNotMinXiang=t}IsChuanGongNotMinXiang_get(){
return this.IsChuanGongNotMinXiang}HasInvitePlayer(t){const e=this.InviteChuanGongMsg&&this.InviteChuanGongMsg.hasInviteList
return!(!e||!e.Contains(t))}SubmitFireBroadcast_set(t){this.submitFireBroadcast=t}SubmitFireBroadcast_get(){return this.submitFireBroadcast}ConfirmSubmitFireVo_set(t){
this.confirmSubmitFireVo=t}ConfirmSubmitFireVo_get(){return this.confirmSubmitFireVo}SubmitFireAwardIsGot_set(t){this.submitFireAwardIsGot=t,
l.i.Inst.RaiseEvent(r.g.RYALLIANCE_GET_FIRSTSUBMITAWARD)}SubmitFireAwardIsGot_get(){return this.submitFireAwardIsGot}Test1(){return!0}S_Test(){return!0}}I._Inst=null},
90912:(t,e,i)=>{i.d(e,{s:()=>s})
var s={EVALUATE_UPDATE:"EVALUATE_UPDATE",STAGE_UPDATE:"STAGE_UPDATE",PROGRESS_UPDATE:"PROGRESS_UPDATE",COMPLETE:"COMPLETE",COPY_INFO_UPDATE:"COPY_INFO_UPDATE"}},72800:(t,e,i)=>{
i.d(e,{S:()=>s})
var s={BloodTown:2,Belial:3,Plot:4,RedFortress:6,AsuramWar:7,Arena:8,AllianceHome:9,LoseSecrets:10,VipBoss:11,REBIRTH_BOSS:12,AgainstQuestCopyType:14,Memory:15,AsuramTaskCopy:16,
eFirstMiracle:19,eCommonMiracle:21,musTowerNormal:22,musTowerHard:23,WORLDBOSS:24,MineRob:25,LostAbyss:26,WORLDBOSS_NEW:27,SKY_ILLUSION:29,KUNDUN_SEAL:33,SIX_TRANSFER:34,
ELEMENTAL_DUNGEON:35,PEAK_CROSS_ARENA:39,NORMAL_CROSS_ARENA:40,RyAllianceTask:48,AllianceBoss1:50,AllianceBoss2:51,AllianceBoss3:52,AllianceBoss4:53,AsuramWar_1:55,AsuramWar_2:56,
VipBoss1:57,VipBoss2:58,VipBoss3:59,MapPassBoss:61,UnlockMapBoss:62,Exorcism:63,Maze:65,Crime:68,JigsawBoss:69,SpringCattle:70,RolandDefend1:81,RolandDefend2:1024}},
41030:(t,e,i)=>{i.d(e,{S:()=>m})
var s=i(5924),n=i(99294),l=i(32759),a=i(72005),o=i(61911),r=i(18202),h=i(83540),d=i(60130),c=i(79534),_=i(33138),u=i(5031),I=i(70478)
class m extends o.f{constructor(){super(),this.flyEff=null,this.tween=null,this.boom=null,this.ui_flybagItem=null,this.needdestory=!1,this.m_cell=null,this.m_moveType=1,
this.m_endPos=null,this.m_isPlaying=!1,this._degf_OnCallLater=null,this._degf_OnIconFlyFinished=null,this.m_endPos=new c.P,this._degf_OnCallLater=()=>this.OnCallLater(),
this._degf_OnIconFlyFinished=()=>this.OnIconFlyFinished()}InitView(){this.flyEff=new n.z,this.flyEff.setId(this.FatherId,this.FatherComponentID,1),this.tween=new l.c,
this.tween.setId(this.FatherId,this.FatherComponentID,2),this.boom=new n.z,this.boom.setId(this.FatherId,this.FatherComponentID,3),this.ui_flybagItem=new a.w,
this.ui_flybagItem.setId(this.FatherId,this.FatherComponentID,4)}OnAddToScene(){this.Play()}Play(t){null==t&&(t=!1),this.needdestory=t
const e=_.f.Inst().getItemById(I._.GetInst().id)
r.g.SetItemIcon(this.FatherId,this.ui_flybagItem.ComponentId,e.icon,h.b.eItem,!1),this.node.SetActive(!0),this.m_isPlaying=!0,this.m_cell=I._.GetInst().startGO,
this.m_moveType=I._.GetInst().moveType,this.flyEff.SetActive(!1),this.flyEff.transform.SetParent(this.FatherId,this.ComponentId,!1)
let i=this.flyEff.transform.GetLocalPosition()
d.O.AddUIEffectSortOrderBind(this.node),i.x+=120,i.y-=25,i=this.node.transform.InverseTransformPoint(I._.GetInst().frompos).Clone(),this.boom.SetActive(!1),
this.flyEff.SetActive(!0),this.tween.AddEventHandler(this._degf_OnIconFlyFinished),this.tween.SetFrom(i),this.m_endPos=this.GetEndPos().Clone(),this.tween.SetTo(this.m_endPos),
this.tween.durationSet(.7),this.tween.SetEnabled(!0),this.tween.ResetToBeginning(),this.tween.PlayForward()}OnIconFlyFinished(){this.flyEff.SetActive(!1),
this.boom.transform.SetLocalPosition(this.m_endPos),this.boom.SetActive(!1),this.boom.SetActive(!0),this.m_isPlaying=!1,
this.needdestory?s.C.Inst_get().SetInterval(this._degf_OnCallLater,700,1):r.g.SetItemIcon(this.FatherId,this.ui_flybagItem.ComponentId,"icon_empty",h.b.eItem,!1)}OnCallLater(){
this.m_isPlaying||(this.Destroy(),r.g.DestroyUIById(this.FatherId))}GetEndPos(){let t=c.P.zero_get(),e=c.P.zero_get()
return this.m_moveType==m.MARKET_TYPE?(e=u.T.inst_get().control.GetMarketWorldPos().Clone(),
t=this.node.transform.InverseTransformPoint(e).Clone()):this.m_moveType==m.BAG_TYPE&&(e=u.T.inst_get().control.GetBagWorldPos().Clone(),
t=this.node.transform.InverseTransformPoint(e).Clone()),this.m_moveType==m.Daily_Type?(e=u.T.inst_get().control.mainViewPanel.GetDailyWorldPos().Clone(),
t=this.node.transform.InverseTransformPoint(e).Clone()):this.m_moveType==m.Boss_Type?(e=u.T.inst_get().control.mainViewPanel.GetBossWorldPos().Clone(),
t=this.node.transform.InverseTransformPoint(e).Clone()):this.m_moveType==m.Welfare_Type&&(e=u.T.inst_get().control.mainViewPanel.GetFuliWorldPos().Clone(),
t=this.node.transform.InverseTransformPoint(e).Clone()),this.m_moveType==m.More_Type?(e=u.T.inst_get().control.mainViewPanel.GetMoreWorldPos().Clone(),
t=this.node.transform.InverseTransformPoint(e).Clone()):this.m_moveType==m.Grow_Type?(e=u.T.inst_get().control.mainViewPanel.GetGrowWorldPos().Clone(),
t=this.node.transform.InverseTransformPoint(e).Clone()):this.m_moveType==m.Character_Type?(e=u.T.inst_get().control.mainViewPanel.GetHeadWorldPos().Clone(),
t=this.node.transform.InverseTransformPoint(e).Clone()):this.m_moveType==m.BloodTown_Gem_Type&&(e=u.T.inst_get().control.mainViewPanel.GetItemBagPos().Clone(),
t=this.node.transform.InverseTransformPoint(e).Clone()),t}Clear(){null!=this.tween&&this.tween.RemoveEventHandler(this._degf_OnIconFlyFinished)}Destroy(){
null!=this.tween&&(this.tween.RemoveEventHandler(this._degf_OnIconFlyFinished),this.tween=null)}}m.FIRE_TYPE=1,m.MARKET_TYPE=2,m.BAG_TYPE=3,m.Daily_Type=4,m.Boss_Type=5,
m.Welfare_Type=6,m.More_Type=7,m.Grow_Type=8,m.Character_Type=9,m.BloodTown_Gem_Type=10},62941:(t,e,i)=>{i.d(e,{p:()=>g})
var s=i(6700),n=i(5924),l=i(99294),a=i(3522),o=i(72005),r=i(61911),h=i(98130),d=i(85602),c=i(48933),_=i(96713),u=i(12417),I=i(85770),m=i(72800)
class g extends r.f{constructor(){super(),this.upComp=null,this.downComp=null,this.upBackGround=null,this.downBackGround=null,this.ani=null,this.zi0=null,this.zi1=null,
this.zi2=null,this.zi3=null,this.nameSps=null,this.closeTimeKey=0,this._degf_HandleShowComplete=null,this._degf_HandleShowComplete=()=>this.HandleShowComplete()}InitView(){
this.upComp=new l.z,this.upComp.setId(this.FatherId,this.FatherComponentID,1),this.downComp=new l.z,this.downComp.setId(this.FatherId,this.FatherComponentID,2),
this.upBackGround=new o.w,this.upBackGround.setId(this.FatherId,this.FatherComponentID,3),this.downBackGround=new o.w,
this.downBackGround.setId(this.FatherId,this.FatherComponentID,4),this.ani=new a.k,this.ani.setId(this.FatherId,this.FatherComponentID,5),this.zi0=new o.w,
this.zi0.setId(this.FatherId,this.FatherComponentID,6),this.zi1=new o.w,this.zi1.setId(this.FatherId,this.FatherComponentID,7),this.zi2=new o.w,
this.zi2.setId(this.FatherId,this.FatherComponentID,8),this.zi3=new o.w,this.zi3.setId(this.FatherId,this.FatherComponentID,9),
this.nameSps=new d.Z([this.zi0,this.zi1,this.zi2,this.zi3]),super.InitView()}OnAddToScene(){this.SetNameTxt()
const t=c.I.cal2Vec0
s.L.Instance_get().GetScreenSize(t),this.upBackGround.widthSet(h.GF.INT(t.x)),this.upBackGround.heightSet(h.GF.INT(t.y)),this.downBackGround.widthSet(h.GF.INT(t.x)),
this.downBackGround.heightSet(h.GF.INT(t.y)),n.C.Inst_get().ClearInterval(this.closeTimeKey),this.closeTimeKey=n.C.Inst_get().SetInterval(this._degf_HandleShowComplete,4e3),
this.ani.SetResetOnPlay(!0),this.ani.Play(!0,!1)}SetNameTxt(){const t=I.a.Inst_get().curCopyType
let e=null
t==m.S.BloodTown?e=new d.Z(["atlas_loading_0006","atlas_loading_0007","atlas_loading_0008","atlas_loading_0009"]):t==m.S.RedFortress?e=new d.Z(["atlas_loading_00010","atlas_loading_00011","atlas_loading_00012","atlas_loading_00013"]):t==m.S.Belial||t==m.S.Arena||t==m.S.LoseSecrets?e=new d.Z(["atlas_loading_00014","atlas_loading_00015","atlas_loading_00016","atlas_loading_00017"]):u._.Inst().IsVipBossCopy(copy)&&(e=new d.Z(["atlas_loading_0006","atlas_loading_0007","atlas_loading_0008","atlas_loading_0009"]))
let i=null,s=0
for(;s<this.nameSps.count;)i=this.nameSps[s],null!=i&&i.spriteNameSet(e[s]),s+=1}HandleShowComplete(){n.C.Inst_get().ClearInterval(this.closeTimeKey),_.n.inst.CloseBtLoading()}
Clear(){}Destroy(){this.upComp=null,this.downComp=null,this.upBackGround=null,this.downBackGround=null,this.ani=null,this.zi0=null,this.zi1=null,this.zi2=null,this.zi3=null}}},
60776:(t,e,i)=>{i.d(e,{C:()=>r})
var s,n=i(18998),l=i(83908),a=i(9057),o=i(87923)
let r=n._decorator.ccclass("BloodTownRankItem")(s=class extends((0,l.pA)(a.x)()){InitView(){super.InitView()}SetData(t){null!=t?(0==t.rank?(this.noSortObj.SetActive(!0),
this.sortLab.textSet(""),this.playerNameLab.textSet(""),this.killNumLab.textSet(""),this.scoreLab.textSet(""),this.timeLab.textSet("")):(this.noSortObj.SetActive(!1),
this.sortLab.textSet(t.rank.toString()),this.timeLab.textSet(o.l.GetYMDTime(t.time.ToNum())),this.playerNameLab.textSet(t.name),
this.killNumLab.textSet(t.killMasterCount.toString()),this.scoreLab.textSet(t.maxScore.toString())),this.firstGo.SetActive(1==t.rank),this.secondGo.SetActive(2==t.rank),
this.threeGo.SetActive(3==t.rank)):(this.noSortObj.SetActive(!0),this.sortLab.textSet(""),this.playerNameLab.textSet(""),this.killNumLab.textSet(""),this.scoreLab.textSet(""),
this.timeLab.textSet(""))}Clear(){super.Clear()}Destroy(){}SetBgVisible(t){this.bg.SetActive(t)}Test1(){return!0}S_Test(){return!0}})||s},19883:(t,e,i)=>{
var s,n=i(6847),l=i(83908),a=i(46282),o=i(31222),r=i(5494),h=i(24524),d=i(1046),c=i(44210),_=i(60776);(0,
n.s_)(r.I.BloodTownRankPanel,a.Z.ui_copypanel_bloodtown_rankview_ry).register()(s=class extends((0,l.Ri)()){InitView(){super.InitView(),
this.ranklistgrid.SetInitInfo("ui_copypanel_bloodtown_rankitem_ry",null,_.C)}OnAddToScene(){super.OnAddToScene(),this.UpdateRankInfo(),
this.AddClickEvent(this.closebtn,this.CreateDelegate(this.CloseHandler))
const t=h.o.Inst().getItemById(d.N.Inst_get().GetCurrentCopyId())
if(null!=t){let e=t.name
t.hierarchy>0&&(e+=`第${t.hierarchy}层`),this.titleLab.textSet(e)}}UpdateRankInfo(){
null!=c.w.GetInst().rankInfos&&(c.w.GetInst().rankInfos.rankVoList.Sort(this.CreateDelegate(this.SortOn)),this.ranklistgrid.data_set(c.w.GetInst().rankInfos.rankVoList),
c.w.GetInst().rankInfos.rankVoList.count>0?(this.emptyObj.SetActive(!1),this.myRankItem.SetData(c.w.GetInst().rankInfos.selfRankVo),this.myRankItem.node.SetActive(!0),
this.myRankItem.SetBgVisible(!1)):(this.emptyObj.SetActive(!0),this.myRankItem.node.SetActive(!1)))}SortOn(t,e){return t.rank-e.rank}Clear(){super.Clear(),
this.RemoveClickEvent(this.closebtn,this.CreateDelegate(this.CloseHandler))}Destroy(){}CloseHandler(){o.N.inst.CloseById(r.I.BloodTownRankPanel)}})},14228:(t,e,i)=>{
var s,n=i(6847),l=i(46282),a=i(83908),o=i(68662),r=i(13687),h=i(5924),d=i(5494),c=i(95721),_=i(98130),u=i(92679),I=i(87923),m=i(65379),g=i(24524),p=i(96713),C=i(85770),S=i(72800)
;(0,n.s_)(d.I.CopySoonEndTimePanel,l.Z.ui_copybaseui_copysoonendtime).register()(s=class extends((0,a.Ri)()){constructor(...t){super(...t),this.timer=-1,this.exitTimer=0,
this.preTimer=0,this.maxLeftTime=0,this._degf_StartExit=null}_initBinder(){super._initBinder(),this._degf_StartExit=()=>this.StartExit()}InitView(){}OnAddToScene(){
this.copyEndTip.node.SetActive(!C.a.Inst_get().isSiegeEndTip),m.C.Inst_get().IsCopyEnd=!1,this.siegeEndTip.SetActive(C.a.Inst_get().isSiegeEndTip),
this.exitTimer=C.a.Inst_get().soonEndTime
const t=g.o.Inst().getItemById(C.a.Inst_get().currentCopyId)
null!=t?(this.maxLeftTime=1e3*t.overTime,t.controllerType==S.S.Plot&&3==t.plotType?this.copyEndTip.textSet("挑战剩余倒计时"):this.copyEndTip.textSet("副本结束倒计时")):(this.copyEndTip.textSet("副本结束倒计时"),
this.maxLeftTime=_.GF.INT32_MAX_VALUE_get()),this.UpdateExitTimer(),this.m_handlerMgr.AddEventMgr(u.g.COPY_UPDATE_END_TIME,this.CreateDelegate(this.UpdateExitTimer)),
this.StartTimeHandler(),this.ResetPos()}ResetPos(){r.b.Inst.GetCurMapControllerType()}StartTimeHandler(){h.C.Inst_get().ClearInterval(this.timer),this.timer=-1,
this.preTimer=o.D.serverMSTime_get(),-1==this.timer&&(this.timer=h.C.Inst_get().SetInterval(this._degf_StartExit,50),this.StartExit())}UpdateExitTimer(){
const t=C.a.Inst_get().exiTimer
c.o.IsNullOrZero(t)||(this.exitTimer=t.ToNum(),this.maxLeftTime=this.exitTimer-o.D.serverMSTime_get())}StartExit(){if(!this.node)return
const t=o.D.serverMSTime_get(),e=this.exitTimer-t
e<=0?(this.time.textSet("00:00:00"),this.EndTime()):e>this.maxLeftTime?this.timehide.SetActive(!1):(this.timehide.SetActive(!0),this.ResetPos(),
this.time.textSet(I.l.GetMSRadomEnd2(e)))}EndTime(){this.exitTimer=0,h.C.Inst_get().ClearInterval(this.timer),this.timer=-1,p.n.inst.CloseSoonEndTimeView()}Clear(){this.EndTime(),
C.a.Inst_get().isSiegeEndTip=!1}Destroy(){}})},52295:(t,e,i)=>{i.d(e,{W:()=>c})
var s=i(5924),n=i(93877),l=i(8889),a=i(61911),o=i(31222),r=i(5494),h=i(87923),d=i(85770)
class c extends a.f{constructor(...t){super(...t),this.time=null,this.alpha=null,this.timer=null,this.exitTimer=null}InitView(){super.InitView(),
this.time=this.CreateComponent(n.Q,1),this.alpha=this.CreateComponent(l.$,2),this.timer=-1}AddLis(){}RemoveLis(){}OnAddToScene(){this.ClearTimer(),
-1==this.timer&&(this.timer=s.C.Inst_get().SetInterval(this.CreateDelegate(this.ExecuteTimer),50))}ClearTimer(){this.timer>=0&&s.C.Inst_get().ClearInterval(this.timer),
this.timer=-1}ExecuteTimer(){if(this.exitTimer=d.a.Inst.GetCopyLeftTime(),this.timer<0)return this.ClearTimer(),void o.N.inst.CloseById(r.I.RyDunBossTimer)
const t=h.l.GetMSRadomEnd2(this.exitTimer)
this.SetCopyTimer(t)}SetCopyTimer(t){this.time.textSet(t),""!=t?this.alpha.SetAlpha(1):this.alpha.SetAlpha(.002)}Clear(){this.RemoveLis(),this.ClearTimer(),super.Clear()}Destroy(){
super.Destroy(),this.time=null,this.alpha=null}Test1(){return!0}S_Test(){return!0}}},7660:(t,e,i)=>{i.d(e,{U:()=>l})
var s=i(17409),n=i(49655)
class l{static __StaticInit(){}constructor(){}static Inst(){return null==l.inst&&(l.inst=new l),l.inst}OpenCreateroleview_Ry(){(0,s.Yp)(n.o.Createroleview_Ry)}
CloseCreateroleview_Ry(){(0,s.qJ)(n.o.Createroleview_Ry)&&(0,s.sR)(n.o.Createroleview_Ry)}OnCreateroleview_RyLoad(t){}OnCreateroleview_RyDestroy(){}}l.inst=null},32858:(t,e,i)=>{
var s,n=i(18998),l=i(85688),a=i(21370),o=i(6847),r=i(83908),h=i(46282),d=i(77546),c=i(32076),_=i(86133),u=i(12480),I=i(97461),m=i(68662),g=i(41664),p=i(28192),C=i(60130),S=i(35128),f=i(98130),T=i(98885),y=i(13235),A=i(73790),D=i(33314),E=i(87888),v=i(75439),w=i(22662),R=i(93997),P=i(15821),O=i(99276),L=i(65550),B=i(49655)
;(0,o.s_)(B.o.Createroleview_Ry,h.Z.ui_create_role_view_ry).register()(s=class extends((0,r.Ri)()){constructor(...t){super(...t),this.haverole=!1,this.isDiyName=!1,this.isFirst=!0,
this.lastKey=-1,this.endtime=0,this.soundkey=0,this._m_handlerMgr=null}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=p.h.Get()),this._m_handlerMgr}InitView(){
super.InitView(),m.D.isCloud&&this.btn_back.SetActive(!1)}OnAddToScene(){__$LaunchLogicBridge._shutdownLaunchLayer(l.n.ins.getLayer(a.T.panel)),this.isFirst=!0,
this.AddorRemoveLis(!0),this.UpdateAnchor()
const t=f.GF.INT(S.p.RandomMax(2.99999)),e=D.Z.BASE_JOB[t]
O.J.getInst().profession=e,this.SelectJob(e),this.OnRandomClick()}AddorRemoveLis(t=!1){t?(this.m_handlerMgr.AddClickEvent(this.saber,this.CreateDelegate(this.OnChangeSelectJob)),
this.m_handlerMgr.AddClickEvent(this.caster,this.CreateDelegate(this.OnChangeSelectJob)),this.m_handlerMgr.AddClickEvent(this.archer,this.CreateDelegate(this.OnChangeSelectJob)),
this.m_handlerMgr.AddClickEvent(this.random,this.CreateDelegate(this.OnRandomClick)),this.m_handlerMgr.AddClickEvent(this.nameinput,this.CreateDelegate(this.OnRoleNameClick)),
this.m_handlerMgr.AddClickEvent(this.btn_create,this.CreateDelegate(this.OnCreateRoleClick)),I.i.Inst.AddEventHandler(P.i.NEWBIE_CREATE_ROLE,(0,
c.v)(this.OnCreateRoleClick,this))):(this.m_handlerMgr.RemoveClickEvent(this.saber,this.CreateDelegate(this.OnChangeSelectJob)),
this.m_handlerMgr.RemoveClickEvent(this.caster,this.CreateDelegate(this.OnChangeSelectJob)),
this.m_handlerMgr.RemoveClickEvent(this.archer,this.CreateDelegate(this.OnChangeSelectJob)),this.m_handlerMgr.RemoveClickEvent(this.random,this.CreateDelegate(this.OnRandomClick)),
this.m_handlerMgr.RemoveClickEvent(this.nameinput,this.CreateDelegate(this.OnRoleNameClick)),
this.m_handlerMgr.RemoveClickEvent(this.btn_create,this.CreateDelegate(this.OnCreateRoleClick)),I.i.Inst.RemoveEventHandler(P.i.NEWBIE_CREATE_ROLE,(0,
c.v)(this.OnCreateRoleClick,this)))}UpdateAnchor(){C.O.SetAnchorPos(this.left,!0,!0,0),C.O.SetAnchorPos(this.right,!1,!1,0),
this.left.getComponent(A.a).SetFrom(new n.Vec3(C.O.UIScreenLeft-400,0,0)),this.left.getComponent(A.a).SetTo(new n.Vec3(C.O.UIScreenLeft,0,0)),
this.right.getComponent(A.a).SetFrom(new n.Vec3(C.O.UIScreenRight+400,0,0)),this.right.getComponent(A.a).SetTo(new n.Vec3(C.O.UIScreenRight,0,0))}Back(){
0==this.endtime&&u.y.Instance.RaiseEvent(u.y.eStateChange,u.y.eLoginState)}OnRandomClick(){const t=O.J.getInst().m_sex,e=u.y.Instance.GetRandomName(t)
this.nameinput.string=e}OnRoleNameClick(){this.isDiyName=!0}OnCreateRoleClick(){const t=this.nameinput.string
if(""==t||t.length<=0)return void L.y.inst.ClientStrMsg(w.r.SystemTipMessage,(0,_.T)("为角色起个名字吧"))
const e=this.GetLen(t)
if(e>10||e<2)return void L.y.inst.ClientStrMsg(w.r.SystemTipMessage,(0,_.T)("名字长度为2-5个字"))
O.J.getInst().name=t
const i=O.J.getInst().profession,s=O.J.getInst().m_sex
R.p.inst.mapLoadingType=2,O.J.getInst().SendCreateRole(i,t,s)}GetLen(t){const e=t.length
let i=0,s=0
for(;s<e;){const e=T.M.Byte(t,s)
32!=e&&(i+=e>127||94==e?2:1,s++)}return i}OnChangeSelectJob(t){
this.saber.node.name==t.target.name?this.SelectJob(D.Z.BASE_SWORDMAN):this.caster.node.name==t.target.name?this.SelectJob(D.Z.BASE_MAGICIAN):this.archer.node.name==t.target.name&&this.SelectJob(D.Z.BASE_ARCHER)
}SelectJob(t){this.min.visible=this.right.visible=!1
let e=E.$.Male
t==D.Z.BASE_SWORDMAN?this.saber.node.getComponent(n.Toggle).isChecked=!0:t==D.Z.BASE_MAGICIAN?this.caster.node.getComponent(n.Toggle).isChecked=!0:t==D.Z.BASE_ARCHER&&(this.archer.node.getComponent(n.Toggle).isChecked=!0,
e=E.$.Female),O.J.getInst().m_sex=e,O.J.getInst().profession=t,this.SelectRole(t),this.isDiyName||this.OnRandomClick()}SelectRole(t){this.setright(t),
this.lastKey!=t&&0!=t&&(this.lastKey=t,this.PlayViewEffectHide(),d.s.Info(`创角选中  ${t}`)),this.PlayTween()}PlaySound(t){0!=this.soundkey&&g.j.Inst.StopByKey(this.soundkey,!0),
t==D.Z.BASE_SWORDMAN?this.soundkey=g.j.Inst.PlayBySoundId(70101):t==D.Z.BASE_MAGICIAN?this.soundkey=g.j.Inst.PlayBySoundId(70102):t==D.Z.BASE_ARCHER&&(this.soundkey=g.j.Inst.PlayBySoundId(70103))
}PlayViewEffectHide(){0!=this.endtime&&(this.endtime=this.m_handlerMgr.ClearInterval(this.endtime))
const t=v.D.getInstance().GetIntValue("CREATEROLE:TIME")
this.endtime=this.m_handlerMgr.SetInterval(this.CreateDelegate(this.endPlay),t,1),this.isFirst,this.isFirst=!1}endPlay(){this.endtime=this.m_handlerMgr.ClearInterval(this.endtime)}
setright(t){let e=null
if(t==D.Z.BASE_SWORDMAN){const t=v.D.getInstance().GetStringValue("CREATEROLE:SM1")
e=T.M.Split(t,T.M.s_SPAN_CHAR_DOT)}else if(t==D.Z.BASE_MAGICIAN){const t=v.D.getInstance().GetStringValue("CREATEROLE:MG1")
e=T.M.Split(t,T.M.s_SPAN_CHAR_DOT)}else if(t==D.Z.BASE_ARCHER){const t=v.D.getInstance().GetStringValue("CREATEROLE:AC1")
e=T.M.Split(t,T.M.s_SPAN_CHAR_DOT)}if(null!=e&&e.Count()>=3){const i=[[6,.5],[-5,8],[0,-17]][t/1e3-1]
this.jobMainSp.spriteNameSet("preload:/atlas/chuangjue/"+e[0]),this.jobradar.spriteNameSet("preload:/atlas/chuangjue/"+e[1]),
this.jobradar.node.transform.SetLocalPositionXYZ(i[0],i[1],0),this.jobMainLab.textSet(e[2])
let s=["18","19","20"][t/1e3-1]
this.role.skin="preload:/images/chuangjue/rychuangjue_sp_00"+s}}Clear(){this.AddorRemoveLis(),this.endtime=this.m_handlerMgr.ClearInterval(this.endtime),super.Clear()}Destroy(){
super.destroy()}PlayTween(){this.min.visible=this.right.visible=!0,this.min.getComponent(A.a).PlayForward(),this.right.getComponent(A.a).PlayForward(),
this.left.getComponent(A.a).PlayForward(),this.min.getComponent(y.h).PlayForward(),this.right.getComponent(y.h).PlayForward()}})},92473:(t,e,i)=>{i.d(e,{R:()=>M})
var s=i(32076),n=i(86133),l=i(23833),a=i(68662),o=i(2689),r=i(13687),h=i(5924),d=i(56937),c=i(31222),_=i(5494),u=i(52726),I=i(995),m=i(98789),g=i(98885),p=i(85602),C=i(79534),S=i(96609),f=i(89144),T=i(50089),y=i(99294),A=i(93877),D=i(3522),E=i(13113),v=i(61911),w=i(60130),R=i(92679),P=i(85751),O=i(87923),L=i(47786),B=i(12417)
class b extends v.f{constructor(){super(),this.anchor=null,this.Ani=null,this.tideTimeLabel=null,this.tideDoubleTimes=null,this.effect=null,this.headIcon=null,this.tideEffect=null,
this.mask=null,this.flyEffect=null,this.effectLabel=null,this.blessEffect=null,this.tModel=null,this.model=null,this.tideTime=null,this.isDoubleTime=null,this.tideInterval=null,
this.effectInterval=null,this.tModel=B._.Inst(),this.model=f.I.Inst_get()}InitView(){super.InitView(),this.anchor=this.CreateComponent(E.T,1),this.Ani=this.CreateComponent(D.k,2),
this.tideTimeLabel=this.CreateComponent(A.Q,3),this.tideDoubleTimes=this.CreateComponent(A.Q,4),this.effect=this.CreateComponent(y.z,5),this.headIcon=this.CreateComponent(y.z,6),
this.tideEffect=this.CreateComponent(y.z,7),this.mask=this.CreateComponent(y.z,8),this.flyEffect=this.CreateComponent(y.z,9),this.effectLabel=this.CreateComponent(A.Q,10),
this.blessEffect=this.CreateComponent(y.z,11),w.O.SetAnchorPos(this.anchor,!0,!0,0,!1)}OnAddToScene(){this.RemoveLis(),this.AddLis(),M.Inst_get().CM_CrossBattleInfo()}UpdateView(){
[this.tideTime,this.isDoubleTime]=this.model.GetDoubleTime(),this.UpdateState(),this.SetTideTimeTxt()}OnClickMask(){}SetTideTimeTxt(){this.ClearTideTimer(),
this.tideInterval=h.C.Inst_get().SetInterval(this.CreateDelegate(this.DoTideTimerInterval),1e3),this.DoTideTimerInterval()}UpdateState(){this.tideDoubleTimes.SetActive(!1),
this.effect.SetActive(this.isDoubleTime),this.isDoubleTime&&this.model.showEnterEffect&&(this.model.showEnterEffect=!1,this.tideEffect.SetActive(!0),this.anchor.SetActive(!1),
this.ClearEffectTimer(),this.effectInterval=h.C.Inst_get().SetInterval(this.CreateDelegate(this.DoEffectTimerInterval),2500,1))}DoEffectTimerInterval(){
this.effectLabel.SetActive(!1),this.mask.SetActive(!1),this.flyEffect.SetLocalScaleXYZ(T.t.GetUIWidth()/1280,1,1),this.flyEffect.SetActive(!0),this.ClearEffectTimer(),
this.effectInterval=h.C.Inst_get().SetInterval(this.CreateDelegate(this.DoFlyTimerInterval),1100,1)}DoFlyTimerInterval(){this.anchor.SetActive(!0)}DoTideTimerInterval(){
const t=this.tideTime-a.D.serverTime_get()
if(t>0)if(this.isDoubleTime){const e=L.x.Inst().getItemById(11043003)
this.tideTimeLabel.textSet(g.M.Replace(e.sys_messsage,"{0}",`${P.u.BrightGreenColorStr2}${O.l.GetDateFormatEX(t)}[-]`))}else{const e=L.x.Inst().getItemById(11043002)
this.tideTimeLabel.textSet(g.M.Replace(e.sys_messsage,"{0}",`${P.u.BrightGreenColorStr2}${O.l.GetDateFormatEX(t)}[-]`))
}else[this.tideTime,this.isDoubleTime]=this.model.GetDoubleTime(),this.UpdateState()}ClearTideTimer(){h.C.Inst_get().ClearInterval(this.tideInterval),this.tideInterval=-1}
ClearEffectTimer(){h.C.Inst_get().ClearInterval(this.effectInterval),this.effectInterval=-1}AddLis(){
this.m_handlerMgr.AddEventMgr(R.g.CROSS_BOSS_UPDATE,this.CreateDelegate(this.UpdateView)),this.m_handlerMgr.AddClickEvent(this.mask,this.CreateDelegate(this.OnClickMask))}
RemoveLis(){}Clear(){this.RemoveLis(),this.ClearTideTimer(),this.ClearEffectTimer(),super.Clear()}Destroy(){super.Destroy(),this.anchor=null,this.Ani=null,this.tideTimeLabel=null,
this.tideDoubleTimes=null,this.effect=null,this.headIcon=null,this.tideEffect=null,this.mask=null,this.flyEffect=null,this.effectLabel=null,this.blessEffect=null}}class M{
constructor(){this.model=null,this.interval=-1,this.RegistMsg(),this.model=f.I.Inst_get(),this.StartInterval()}static Inst_get(){return null==M.inst&&(M.inst=new M),M.inst}
StartInterval(){-1!=this.interval&&h.C.Inst_get().ClearInterval(this.interval),this.interval=h.C.Inst_get().SetInterval((0,s.v)(this.HandleTime,this),1e3,-1)}HandleTime(){
f.I.Inst_get().IsCrossBattleUnlock()&&f.I.Inst_get().GetDoubleTime()}RegistMsg(){}OpenRootView(t,e=null){
if(!f.I.Inst_get().IsCrossBattleUnlock())return void M.Inst_get().CM_CrossBattleInfo()
this.model.viewType=t||-1,f.I.Inst_get().selectMonsterId=e
const i=new d.v
i.positionType=m.$.eCustom,i.isShowMask=!0,i.isDefaultUITween=!0,i.isSelfTween=!0,i.viewClass=CrossBattleRootView,c.N.inst.OpenById(_.I.CrossBattleRootView,null,null,i)}
CloseRootView(){c.N.inst.CloseById(_.I.CrossBattleRootView)}OpenBossStatusView(){const t=new d.v
t.layerType=u.F.Photograph,t.positionType=m.$.eCustom,t.aniDir=I.K.Left,t.viewClass=b,c.N.inst.OpenById(_.I.CrossBossStatusView,null,null,t)}CloseBossStatusView(){
c.N.inst.CloseById(_.I.CrossBossStatusView)}OpenUseBadgeView(){const t=new d.v
t.layerType=u.F.Alert,t.isShowMask=!0,t.viewClass=CrossBossUseBadgeView,c.N.inst.OpenById(_.I.CrossBossUseBadgeView,null,null,t)}CloseUseBadgeView(){
c.N.inst.CloseById(_.I.CrossBossUseBadgeView)}CM_CrossBattleInfo(){const t=new S.M
SocketManager.Inst.F_SendMsg(t)}SM_CrossBattleInfoHandler(t){f.I.Inst_get().HandleBossInfo(t)
const e=DamageRankControl.Inst_get()
null!=e&&null!=e.memberDmgView&&e.memberDmgView.RefreshBossListItem()}SM_CrossBattleUpdateHandler(t){f.I.Inst_get().UpdateBossInfo(t)
const e=DamageRankControl.Inst_get()
null!=e&&null!=e.memberDmgView&&e.memberDmgView.RefreshBossListItem()}SM_CrossBattleDoubleTimeHandler(t){f.I.Inst_get().UpdateDoubleTime(t)}BossIsAlive(t){
if(null!=t&&null!=t.info){if(t.info.refreshTime.ToNum()-a.D.serverMSTime_get()<=0)this.GotoBoss(t)
else{const e="BOSS:DIE_TIPS"
if(CommonRemindModel.Inst_get().GetData(CommonRemindModel.Inst_get().GetRolePrefix()+e))this.GotoBoss(t)
else{const i=l.a.getInst().getObjById(t.monsterId),a=`${i.name}（${g.M.IntToString(i.level)+(0,n.T)("级）")}`,o=new InfoTipVo
o.infoId=e,o.replaceParams.Add(a),o.cancelText=(0,n.T)("仍旧前往"),o.cancelHandle=(0,s.v)(this.GotoBoss,this),o.cancelParam=t,o.confirmText=(0,n.T)("取消"),o.cancelDontClose=!0,
InfoTipControl.Inst().Open(o)}}}else this.GotoBoss(t)}GotoBoss(t){InfoTipControl.Inst().Close(),TopSmallMapControl.inst.CloseCrossBossChallengeView(),
TopSmallMapControl.inst.CloseMapPanel(),
this.CloseRootView(),CopyBaseControl.inst.IsInCopy()?SystemTipsControl.inst.ClientStrMsg(eSystemPosEnum.SystemTipMessage,"正在副本中"):this.Transport(t.sortId)}Transport(t){
f.I.Inst_get().searchBossId=t
const e=f.I.Inst_get().GetItemById(t),i=SpawnGroupResourceCfgManager.GetInst().GetSpwanItemById(e.spawnId),s=g.M.String2Int(i.mapId),n=TransportMapModel.Inst_get().GetMapById(s),l=C.P.zero_get()
CharacterMgr.Inst.PrimaryRole_get().GetCurPos(l),n.id==r.b.Inst.currentMapId_get()?this.FindWay(t):(CharacterMgr.Inst.PrimaryRole_get().StopPathWithOutNoticeServer(),
f.I.Inst_get().isSearch=!0,TransportMapMgr.Inst.RequestCM_WorldTransport(s))}OnTransportFinished(){f.I.Inst_get().isSearch=!1,this.FindWay(f.I.Inst_get().searchBossId)}FindWay(t){
HangControl.getInst().endHang(),HangModel.getInst().ClearLastAttackTarget()
const e=f.I.Inst_get().GetItemById(t),i=SpawnGroupResourceCfgManager.GetInst().GetSpwanItemById(e.spawnId),n=new C.P(i.x,0,i.y)
CharacterMgr.Inst.PrimaryRole_get().gotoPoint(n,eFindPathType.eRole,(0,s.v)(this.OnArriveBoss),null,0,LuaGlobalData.responseRadius)}OnArriveBoss(){HangControl.getInst().startHang()
}IsCrossBattle(){let t=!1
return this.IsInCrossBattle()&&(t=!0),this.model.isCrossBattleView&&(t=!0),t}IsInCrossBattle(){let t=!1
const e=r.b.Inst.GetCurMap()
return e&&e.controllerType==o.N.CROSS_BOSS_CLIENT&&(t=!0),t}CanExitCrossBattle(){if(this.IsInCrossBattle()){
const t=this.model.boss_hit_quip_cd,e=t-(a.D.serverTime_get()-BossDamageModel.Inst_get().fightTime)
if(e>0)return a.D.serverTime_get()-BossDamageModel.Inst_get().deadTime<=t||(SystemTipsControl.inst.ClientSysMessage(11043015,new p.Z([`${e}`])),!1)}return!0}}M.inst=null},
89144:(t,e,i)=>{i.d(e,{I:()=>a})
var s=i(16812),n=i(86144)
class l extends s.k{constructor(t,e,i,s){super(),this.sortId=0,this.monsterId=0,this.info=null,this.crossCfg=null,this.sortId=t,this.monsterId=e,this.info=i,this.crossCfg=s}
Test1(){return!0}S_Test(){return!0}}class a extends s.k{constructor(){super(),this.isSearch=!1,this.searchBossId=0,this.viewType=-1,this.isCrossBattleView=!1,this.serverInfo=null,
this.crossBattleMap=null,this.crossBossDic=null,this.crossBossList=null,this.selectBossData=null,this.selectMonsterId=null,this.tideTime=0,this.isDoubleTime=!1,
this.showEnterEffect=!0,this.showBadgeBtnEffect=!0,this.isCrossBattleUnlock=!1,this.crossMapId=null,this.lastExitTime=0,this.badgeModelId=10828,this.maxDoubleTimes=null,
this.enterCD=null,this.boss_hit_quip_cd=null,this.doubleTimeList=null,this.closeTimeStr=null,this.openTimeStr=null,this.closeHour=null,this.openHour=null}static Inst_get(){
return null==a.inst&&(a.inst=new a),a.inst}ResetData(){this.viewType=-1,this.isSearch=!1,this.searchBossId=0,this.isCrossBattleView=!1,this.serverInfo=null,this.isDoubleTime=!1,
this.showEnterEffect=!0,this.showBadgeBtnEffect=!0,this.isCrossBattleUnlock=!1,this.crossBossDic.LuaDic_Clear(),this.crossBossList.Clear(),this.GetDoubleTime()}GetItemById(t){
return this.crossBattleMap[t]}GetIdByMonsterId(t){for(const[e,i]of Vpairs(this.crossBattleMap)){
if(SpawnGroupResourceCfgManager.GetInst().GetObjResBySpawnId(i.spawnId).id==t)return i.id}return null}GetRewardListById(t){const e=this.GetItemById(t)
if(e){return CfgGlobal.GetRewardValuesConfig(e.rewardShow).GetFuncLimitItemList()}return new CList}GetCrossBossList(){return this.crossBossList}GetCrossBossData(t){
return this.crossBossDic.LuaDic_GetItem(t)}IsCrossBattleOpen(){let t
const e=this.closeHour,i=this.openHour,s=DateNow.ServerDate_get().hours_get()
return t=s<e||s>=i,t}SetUnlockState(t){this.isCrossBattleUnlock=t,FuncOpenControl.Inst.UpdateView()}IsCrossBattleUnlock(){n.a.Inst_get().canEnterCrossServer
return this.isCrossBattleUnlock}GetDoubleTime(){let t=0,e=!1
const i=Date.New(LuaGlobal.serverMSTime_get()),s=3600*i.hours_get()+60*i.minutes_get()+i.seconds_get(),n=this.GetCurDoubleTime(i)
if(null==n){let n=this.GetNextDoubleTime(i)
null==n?(n=this.GetNextDayDoubleTime(),t=LuaGlobal.serverTime_get()+(86400-s)+n.beginTimeStamp):t=LuaGlobal.serverTime_get()+(n.beginTimeStamp-s),e=!1
}else t=LuaGlobal.serverTime_get()+(n.endTimeStamp-s),e=!!this.IsCrossBattleUnlock()
let l=!1
return this.isDoubleTime!=e&&(e&&CrossBattleControl.Inst_get().IsCrossBattle()&&CrossBattleControl.Inst_get().CM_CrossBattleInfo(),l=!0),Date.Recycle(i),this.tideTime=t,
this.isDoubleTime=e,l&&FuncOpenControl.Inst.UpdateView(),[t,e]}GetCurDoubleTime(t){for(let e=0;e<=this.doubleTimeList.Count()-1;e++){
const i=this.doubleTimeList[e],s=3600*t.hours_get()+60*t.minutes_get()+t.seconds_get()
if(s>=i.beginTimeStamp&&s<=i.endTimeStamp)return i}}GetNextDoubleTime(t){for(let e=0;e<=this.doubleTimeList.Count()-1;e++){const i=this.doubleTimeList[e]
if(3600*t.hours_get()+60*t.minutes_get()+t.seconds_get()<i.beginTimeStamp)return i}}GetNextDayDoubleTime(){return this.doubleTimeList[0]}GetDropData(){const t=new CList
if(null!=this.serverInfo){let e=null,i=this.serverInfo.stickRareDrops.Count()-1
for(;i>=0;)e=new RareDropData(1,this.serverInfo.stickRareDrops[i]),t.Add(e),i-=1
let s=this.serverInfo.normalRareDrops.Count()-1
for(;s>=0;)e=new RareDropData(2,this.serverInfo.normalRareDrops[s]),t.Add(e),s-=1}return t}HandleBossInfo(t){this.serverInfo=t
for(let e=0;e<=t.crossBossInfos.Count()-1;e++)if(this.crossBossDic.LuaDic_ContainsKey(t.crossBossInfos[e].bossKey))this.crossBossDic[t.crossBossInfos[e].bossKey].info=t.crossBossInfos[e]
else for(const[i,s]of Kpairs(this.crossBattleMap)){const s=SpawnGroupResourceCfgManager.GetInst().GetObjResBySpawnId(this.crossBattleMap[i].spawnId)
if(s.id==t.crossBossInfos[e].bossKey){const n=new l(i,s.id,t.crossBossInfos[e],this.crossBattleMap[i])
this.crossBossDic[t.crossBossInfos[e].bossKey]=n,this.crossBossList.Add(n)}if(null==this.crossMapId){
const t=SpawnGroupResourceCfgManager.GetInst().GetSpwanItemById(this.crossBattleMap[i].spawnId)
this.crossMapId=StringProxy.String2Int(t.mapId)}}this.crossBossList.Sort(((t,e)=>t.sortId-e.sortId)),this.SetUnlockState(!0),
LuaEventMgr.Inst.RaiseEvent(CommonEventType.CROSS_BOSS_UPDATE)}UpdateBossInfo(t){
this.crossBossDic.LuaDic_ContainsKey(t.crossBossInfo.bossKey)&&(this.crossBossDic[t.crossBossInfo.bossKey].info=t.crossBossInfo),
LuaEventMgr.Inst.RaiseEvent(CommonEventType.CROSS_BOSS_UPDATE)}UpdateDoubleTime(t){this.serverInfo&&(this.serverInfo.doubleTime=t.useTime,this.GetDoubleTime(),
LuaEventMgr.Inst.RaiseEvent(CommonEventType.CROSS_BOSS_UPDATE))}HandleRedPoint(){RedPointManager.Inst.SetState(RedPointId.CROSS_BOSS,!1)}}a.inst=null},33275:(t,e,i)=>{i.d(e,{
E:()=>s})
class s{}s.CROSS_BOSS=0,s.CRIME=1},74768:(t,e,i)=>{i.d(e,{h:()=>a})
var s=i(9057),n=i(93877),l=i(87923)
class a extends s.x{constructor(...t){super(...t),this.time=null,this.name=null}InitView(){super.InitView(),this.time=this.CreateComponent(n.Q,1),
this.name=this.CreateComponent(n.Q,2)}SetData(t){this.name.textSet(t.playerName),this.time.textSet(l.l.GetDateTimeInHMS(t.time.ToNum()))}Clear(){super.Clear()}Destroy(){
super.Destroy(),this.time=null,this.name=null}Test1(){return!0}S_Test(){return!0}}},44802:(t,e,i)=>{i.d(e,{J:()=>s})
class s{constructor(){this.RegisteProtocol()}static Inst(){return null==s._Inst&&(s._Inst=new s),s._Inst}RegisteProtocol(){}ReqCrossServerInfo(t){}ReqExitCrossServer(){}
ResetData(){this.DestroyAll()}DestroyAll(){}}s._Inst=null},69442:(t,e,i)=>{i.d(e,{_:()=>v})
var s=i(17409),n=i(49655),l=i(97461),a=i(56937),o=i(18202),r=i(31222),h=i(5494),d=i(98789),c=i(85602),_=i(52212),u=i(79534),I=i(92679),m=i(28287),g=i(90034),p=i(61249),C=i(31896),S=i(43308),f=i(19519),T=i(52726),y=i(98800)
class A{constructor(t,e=null,i=-1){this.m_type=null,this.AddBtnClickCallback=null,this.showAddBtn=!1,this.itemId=null,this.m_type=t,this.AddBtnClickCallback=e,
this.showAddBtn=null!=e,this.itemId=i}CheckShow(){if(this.m_type==f.J.GOLD_DIAMOND_LIMIT_STR){const t=f.J.TypeConvertToInt(this.m_type)
return f.J.GetGold(y.Y.Inst.PrimaryRoleInfo_get(),t,!1)>0}return!0}}var D=i(33320),E=i(86209)
class v{static get Instance(){return this._Instance||(this._Instance=new v),this._Instance}constructor(){this.currencyBarUI=null,this.isShow=!1,this.panelLayerType=0,
this.PanelStack=null,this._degf_CallDestoryCurrencyView=null,this._degf_CloseView=null,this._degf_OnAddClickCallBack=null,this._degf_OpenView=null,
this._degf_ShowCurrencyViewHandler=null,this.RefCount=null,this.PanelStack=new c.Z,this._degf_CallDestoryCurrencyView=()=>this.CallDestoryCurrencyView(),
this._degf_CloseView=t=>this.CloseView(t),this._degf_OnAddClickCallBack=t=>this.OnAddClickCallBack(t),this._degf_OpenView=t=>this.OpenView(t),
this._degf_ShowCurrencyViewHandler=t=>this.ShowCurrencyViewHandler(t)}Init(){this.panelLayerType=T.F.Alert
const t=new A(f.J.GOLD_DIAMOND_STR,this._degf_OnAddClickCallBack),e=new A(f.J.GOLD_DIAMOND_LIMIT_STR,this._degf_OnAddClickCallBack),i=new A(f.J.GOLD_STR,this._degf_OnAddClickCallBack),s=new A(f.J.HonourStr,this._degf_OnAddClickCallBack),n=new A(f.J.SkillPointStr,this._degf_OnAddClickCallBack),a=new A(f.J.LotteryDragonStr),o=new A(f.J.LotteryItemStr),r=new A(f.J.ReputationStr,this._degf_OnAddClickCallBack),h=new A(f.J.AsuramFundStr,this._degf_OnAddClickCallBack),d=new A(f.J.AsuramMaterialStr,this._degf_OnAddClickCallBack),_=new A(f.J.ASURAM_TOKEN_STR,this._degf_OnAddClickCallBack),u=new A(f.J.TREASURE_ID_ITEM_STR),g=new A(f.J.GUOQINGMALL_ID_ITEM_STR),p=new A(f.J.BAIRIMALL_ID_ITEM_STR),C=new A(f.J.HONOUR_POINT_STR),S=new A(f.J.SHUANGDANMALL_ITEM_STR),y=new A(f.J.HONOR_MANUAL_POINT,this._degf_OnAddClickCallBack),D=new A(f.J.FORTUNE_POINT,this._degf_OnAddClickCallBack),v=new A(f.J.MAYA_HUNT_COUPON,this._degf_OnAddClickCallBack),w=new A(f.J.MAYA_HUNT_SCORE),R=new A(f.J.TREASURES,this._degf_OnAddClickCallBack),P=new c.Z([i,e,t]),O=new c.Z([i,e,t]),L=new c.Z([i,e,t]),B=new c.Z([i,e,t]),b=new c.Z([e,t,o,a]),M=new c.Z([o,a]),G=new c.Z([i,e,t,s]),H=new c.Z([i,e,t,n]),N=new c.Z([i,s]),k=new c.Z([i,e,t,r]),U=new c.Z([r,h,d]),V=new c.Z([e,t,_]),x=new c.Z([r,_]),F=new c.Z([e,t,r,_]),q=new c.Z([e,t,u]),Y=new c.Z([h,d]),W=new c.Z([i,g]),j=new c.Z([i,p]),Z=new c.Z([e,t,C]),X=new c.Z([i,S]),K=new c.Z([i,e,t,y]),$=new c.Z([e,t,D]),J=new c.Z([i,e,t,v]),z=new c.Z([i,e,t,w]),Q=new c.Z([i,e,t,R]),tt=new c.Z([e,t]),et=E.w.Instance.itemsDic
et.LuaDic_AddOrSetItem(m._.Hide,new c.Z),et.LuaDic_AddOrSetItem(m._.ShowAll,P),et.LuaDic_AddOrSetItem(m._.ShowSome,O),et.LuaDic_AddOrSetItem(m._.ShowGold_Score_BindDia,L),
et.LuaDic_AddOrSetItem(m._.ShowGold_Dia_BindDia,B),et.LuaDic_AddOrSetItem(m._.ShowGold_Dia_Lottery,b),et.LuaDic_AddOrSetItem(m._.ShowScore_Lottery,M),
et.LuaDic_AddOrSetItem(m._.ShowGold_Dia_Honour,G),et.LuaDic_AddOrSetItem(m._.ShowGold_Dia_SkillPoint,H),et.LuaDic_AddOrSetItem(m._.ShowGold_Score_Honour,N),
et.LuaDic_AddOrSetItem(m._.ShowGold_Dia_Reputation,k),et.LuaDic_AddOrSetItem(m._.ShowReputation_Fund_Material,U),et.LuaDic_AddOrSetItem(m._.ShowDia_Score_Token,V),
et.LuaDic_AddOrSetItem(m._.ShowScore_Reputation_Token,x),et.LuaDic_AddOrSetItem(m._.ShowDia_Reputation_Token,F),et.LuaDic_AddOrSetItem(m._.ShowDia_Score_Trea,q),
et.LuaDic_AddOrSetItem(m._.ShowFund_Material,Y),et.LuaDic_AddOrSetItem(m._.ShowGold_Score_Guoqing,W),et.LuaDic_AddOrSetItem(m._.ShowGold_Score_Bairi,j),
et.LuaDic_AddOrSetItem(m._.ShowHonour_Diamond_Bairi,Z),et.LuaDic_AddOrSetItem(m._.ShowGold_Score_Shuangdan,X),et.LuaDic_AddOrSetItem(m._.ShowGold_Dia_HonourShopPoint,K),
et.LuaDic_AddOrSetItem(m._.ShowDia_FortunePoint,$),et.LuaDic_AddOrSetItem(m._.ShowGOLD_Dia_MAYAHUNTCOUPON,J),et.LuaDic_AddOrSetItem(m._.ShowGOLD_Dia_MAYAHUNTSCORE,z),
et.LuaDic_AddOrSetItem(m._.ShowGOLD_GLOD_MARKET,Q),et.LuaDic_AddOrSetItem(m._.ShowDia,tt),l.i.Inst.AddEventHandler(I.g.OpenCurrencyBarView,this._degf_OpenView),
l.i.Inst.AddEventHandler(I.g.CloseCurrencyBarView,this._degf_CloseView)}OpenView(t){const[e,i]=[t[0],t[1]],n=e,l=n.ShowCurrencyBar_get()
E.w.Instance.ResetType(l),E.w.Instance.AddDeepth(i,(0,s.C8)(n))
let o=new a.v
o.layerType=this.panelLayerType,o.positionType=d.$.eTop,o.pos=new _.F(0,20).Clone(),(0,s.Yp)(h.I.CurrencyBar,o),this.isShow=!0}ForecOpenView(){
if(this.PanelStack.count<=0||0==this.RefCount)return
const t=new a.v
t.layerType=this.panelLayerType,t.positionType=d.$.eTop,t.pos=new _.F(0,20).Clone(),this.isShow=!0,
r.N.inst.OpenById(h.I.CurrencyBar,this._degf_ShowCurrencyViewHandler,this._degf_CallDestoryCurrencyView,t,!0)}CloseView(t){if(E.w.Instance.RemoveDeepth(t),
0==(t=E.w.Instance.GetMaxDeepthUid()))(0,s.sR)(n.o.CurrencyBar)
else{const e=(0,s.Y)(t)
if(null!=e){const t=e.ShowCurrencyBar_get()
E.w.Instance.ResetType(t)}else(0,s.sR)(n.o.CurrencyBar)}}ShowCurrencyViewHandler(t){return null==this.currencyBarUI&&(this.currencyBarUI=new D.o,
this.currencyBarUI.setId(t,null,0)),this.currencyBarUI}CallDestoryCurrencyView(){o.g.DestroyUIObj(this.currencyBarUI),this.currencyBarUI=null}OnAddClickCallBack(t){
if(t.m_type==f.J.ScoreStr||t.m_type==f.J.GOLD_STR||t.m_type==f.J.GOLD_DIAMOND_LIMIT_STR||t.m_type==f.J.HonourStr||t.m_type==f.J.SkillPointStror||t.m_type==f.J.ReputationStr||t.m_type==f.J.ASURAM_TOKEN_STR||t.m_type==f.J.AsuramFundStr||t.m_type==f.J.AsuramMaterialStr||t.m_type==f.J.MAYA_HUNT_COUPON||t.m_type==f.J.TREASURES){
const e=u.P.zero_get()
S._.Inst_get().OpenByCurrency(t.m_type,e)
}else t.m_type==f.J.GOLD_DIAMOND_STR?C.t.inst.CommonRechargeHandle():t.m_type==f.J.HONOR_MANUAL_POINT?g.s.Inst_get().Open():t.m_type==f.J.FORTUNE_POINT?p.p.Inst_get().OpenView():-1!=t.itemId&&S._.Inst_get().OpenByItem(t.itemId)
}GetCurrencyPanelDepth(){return null!=this.currencyBarUI?this.currencyBarUI.GetPanelDepth():0}GetCurrencyBarUIPosByType(t){
return null!=this.currencyBarUI?this.currencyBarUI.GetPosByType(t):u.P.zero_get()}}v._Instance=new v},33320:(t,e,i)=>{i.d(e,{o:()=>x})
var s,n,l,a,o,r,h=i(18998),d=i(75507),c=i(71409),_=i(34565),u=i(6847),I=i(46282),m=i(98800),g=i(97960),p=i(97461),C=i(85602),S=i(79534),f=i(92679),T=i(28287),y=i(87923),A=i(27354),D=i(86577),E=i(69559),v=i(89373),w=i(5494),R=i(5924),P=i(30849),O=i(18202),L=i(83540),B=i(95721),b=i(98885),M=i(38844),G=i(70850),H=i(33138),N=i(19519),k=i(86209)
class U extends P.C{constructor(...t){super(...t),this.lab_value=null,this.spr_icon=null,this.btn_add=null,this.ani_charge=null,this.ani_light=null,this.lightAnimTimer=-1,
this.waveEndTimer=-1,this.waveCount=0,this._vo=null,this.lastCurrency=0,this.isPlayingCurrencyAnim=!1,this.interval=-1,this._degf_EndChargeAnimHnadler=null,
this._degf_PlayDiamondAnimHandler=null,this._degf_PlayLightAnimHandler=null,this._degf_PlayWaveAnimHandler=null,this.btn_icon=null,this.item_img=null,this.initVal=null}InitView(){
this.btn_add=this.node.getChildByPath("move_node/btn_add"),this.btn_icon=this.node.getChildByPath("move_node/spr_icon"),
this.spr_icon=this.node.getChildByPath("move_node/spr_icon/sp_img").getComponent(M.E),this.item_img=this.node.getChildByPath("move_node/spr_icon/item_img").getComponent(M.E),
this.lab_value=this.node.getChildByPath("move_node/lab_num").getComponent(h.Label),this.initVal=!1,this.lastCurrency=N.J.GetGold(m.Y.Inst.PrimaryRoleInfo_get(),N.J.GOLD_DIAMOND,!1)
}EndChargeAnimHnadler(){
this._vo.m_type==N.J.ScoreStr||this._vo.m_type==N.J.GOLD_DIAMOND_STR||this._vo.m_type==N.J.GOLD_DIAMOND_LIMIT_STR||(this.lab_value.string=k.w.Instance.GetStrValByType(this._vo.m_type),
this.CheckHideShow())}PlayDiamondAnimHandler(t){const e=t
this._vo.m_type==e&&(this.ClearAniDatas(),this.EndChargeAnimHnadler(null),this.waveEndTimer=R.C.Inst_get().SetInterval(this._degf_PlayWaveAnimHandler,140,4),
this.PlayWaveAnimHandler(),this.lightAnimTimer=R.C.Inst_get().SetInterval(this._degf_PlayLightAnimHandler,170,2),this.PlayLightAnimHandler(),this.SetCurrencyValAnim())}
SetCurrencyValAnim(){const t=N.J.TypeConvertToInt(this._vo.m_type)
B.o.FromNumber(this.lastCurrency),B.o.FromNumber(N.J.GetGold(m.Y.Inst.PrimaryRoleInfo_get(),t,!1))
this.lab_value.string=k.w.Instance.GetStrValByType(this._vo.m_type),this.lastCurrency=N.J.GetGold(m.Y.Inst.PrimaryRoleInfo_get(),t,!1),this.isPlayingCurrencyAnim=!0}
CloseAnimProtect(){this.isPlayingCurrencyAnim=!1,this.CheckHideShow()}CheckHideShow(){const t=this.node.active
if(this._vo.m_type==N.J.GOLD_DIAMOND_LIMIT_STR){const e=N.J.TypeConvertToInt(this._vo.m_type),i=N.J.GetGold(m.Y.Inst.PrimaryRoleInfo_get(),e,!1),s=i>0
return this.node.active=i>0,t!=s}return!1}PlayWaveAnimHandler(){this.waveCount+=1,4==this.waveCount||5==this.waveCount&&this.ClearWaveTime()}PlayLightAnimHandler(){}
ClearLightAnimTimer(){R.C.Inst_get().ClearInterval(this.lightAnimTimer),this.lightAnimTimer=-1}ClearWaveTime(){R.C.Inst_get().ClearInterval(this.waveEndTimer),this.waveEndTimer=-1,
this.waveCount=0}OnAddClick(t,e){null!=this._vo&&null!=this._vo.AddBtnClickCallback&&this._vo.AddBtnClickCallback(this._vo)}OnIconClick(t,e){
if(null!=this._vo)if(-1!=this._vo.itemId)INS.itemTipManager.OpenTipViewById(this._vo.itemId)
else{const t=N.J.GetItemID(this._vo.m_type)
INS.itemTipManager.OpenTipViewById(t)}}AddLis(){this.btn_add.on(h.NodeEventType.TOUCH_END,this.OnAddClick,this,!1),
this.btn_icon.on(h.NodeEventType.TOUCH_END,this.OnIconClick,this,!1),this.m_handlerMgr.AddEventMgr(f.g.CURRENCY_CHARGE_WAVEANIM,this.CreateDelegate(this.PlayDiamondAnimHandler)),
this.m_handlerMgr.AddEventMgr(f.g.CURRENCY_CHARGE_WAVEANIMEND,this.CreateDelegate(this.EndChargeAnimHnadler))}RemoveLis(){
this.m_handlerMgr.RemoveEventMgr(f.g.CURRENCY_CHARGE_WAVEANIM,this.CreateDelegate(this.PlayDiamondAnimHandler)),
this.m_handlerMgr.RemoveEventMgr(f.g.CURRENCY_CHARGE_WAVEANIMEND,this.CreateDelegate(this.EndChargeAnimHnadler))}Clear(){this.RemoveLis(),this.ClearAniDatas(),
R.C.Inst_get().ClearInterval(this.interval),this.interval=-1}Destroy(){this.ani_charge=null,this.ani_light=null}SetData(t){this._vo=t,this.AddLis(),
this.btn_add.active=this._vo.showAddBtn,this._vo.m_type==N.J.GOLD_DIAMOND_STR&&MiniPlatController.isTiShen()&&this.btn_add.SetActive(!1),
-1!=this._vo.itemId?(this.item_img.node.active=!0,
this.spr_icon.node.active=!1,O.g.SetItemIcon(this.item_img,H.f.Inst().getItemById(this._vo.itemId).icon,L.b.eItem,!1)):(this.item_img.node.active=!1,this.spr_icon.node.active=!0)
const e=this.spr_icon.skin,i=N.J.GetCurrencyIconUrl(this._vo.m_type)
if(this.spr_icon.skin=i,this.spr_icon.node.transform.width=32,this.spr_icon.node.transform.height=32,
this._vo.m_type==N.J.GOLD_DIAMOND_STR||this._vo.m_type==N.J.GOLD_DIAMOND_LIMIT_STR){const t=N.J.TypeConvertToInt(this._vo.m_type),i=N.J.GetGold(m.Y.Inst.PrimaryRoleInfo_get(),t,!1)
b.M.IsNullOrEmpty(e)||e!=N.J.GetCurrencyIconUrl(this._vo.m_type)?(this.initVal=!0,this.lab_value.string=k.w.Instance.GetStrValByType(this._vo.m_type),
this.lastCurrency=i):this.initVal||(this.initVal=!0,this.lab_value.string=k.w.Instance.GetStrValByType(this._vo.m_type)),
k.w.Instance.initVal||this._vo.m_type!=N.J.GOLD_DIAMOND_STR||(k.w.Instance.initVal=!0,this.lab_value.string=k.w.Instance.GetStrValByType(this._vo.m_type),this.lastCurrency=i,
this.isPlayingCurrencyAnim=!1),i<this.lastCurrency&&(this.lab_value.string=k.w.Instance.GetStrValByType(this._vo.m_type),this.lastCurrency=i),
this.initVal&&t==N.J.GOLD_DIAMOND_LIMIT&&(this.initVal=null!=k.w.Instance.timeLimitedCurrencyMap),
i>this.lastCurrency&&this.isPlayingCurrencyAnim?this.SetCurrencyValAnim():this.CheckHideShow()}else if(-1!=this._vo.itemId){const t=G.g.Inst_get().GetItemNum(this._vo.itemId)
this.lab_value.string=k.w.Instance.ConvertNumToString(t)}else this.lab_value.string=k.w.Instance.GetStrValByType(this._vo.m_type)}ClearAniDatas(){this.ClearWaveTime(),
this.ClearLightAnimTimer()}}function V(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let x=(s=(0,u.s_)(w.I.CurrencyBar,I.Z.ui_comm_currency_bar).waitPrefab(I.Z.ui_comm_currency_item).register(),n=(0,
c.GH)(g.A.GoldUpdate),l=(0,c.GH)(g.A.Gold_DiamondUpdate),s(((r=class extends _.I{constructor(...t){super(...t),this.grid=null,this.ui_comm_currency_bar=null,this.ItemList=null,
this._degf_OnCurrencyUpdate=null,this._degf_OnDataUpdate=null,this.anchor=null}_initBinder(){super._initBinder(),this.ItemList=new C.Z,
this._degf_OnCurrencyUpdate=t=>this.OnCurrencyUpdate(t),this._degf_OnDataUpdate=t=>this.OnDataUpdate(t)}InitView(){
this.grid=this.node.getChildByPath("anchor/grid").getComponent(h.Layout),this.anchor=this.node.getChildByName("anchor"),y.l.setComponentPosByNode(this.grid.node,-200,-15)}
onPanelAdded(){k.w.Instance.initVal=!1,m.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(g.A.GoldUpdate,this._degf_OnDataUpdate),
m.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(g.A.Gold_DiamondUpdate,this._degf_OnDataUpdate),D.T.Inst_get().AddEventHandler(A.F.UPDATE_INFO,this._degf_OnDataUpdate),
v.X.Inst_get().AddEventHandler(E.E.EXCHANGE_SUCCESS,this._degf_OnDataUpdate),m.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(g.A.Bind_DiamondUpdate,this._degf_OnDataUpdate),
m.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(g.A.Score_NumUpdate,this._degf_OnDataUpdate),
m.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(g.A.Skill_PointUpdate,this._degf_OnDataUpdate),
m.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(g.A.HonourUpdate,this._degf_OnDataUpdate),m.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(g.A.AsuramIdUpdate,this._degf_OnDataUpdate),
m.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(g.A.ReputationUpdate,this._degf_OnDataUpdate),
m.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(g.A.AsuramTokenUpdate,this._degf_OnDataUpdate),
m.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(g.A.HonourShopPointUpdate,this._degf_OnDataUpdate),
m.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(g.A.TreasureUpdate,this._degf_OnDataUpdate),p.i.Inst.AddEventHandler(f.g.ALLIANCE_CONTRIBUTE_UPDATE,this._degf_OnDataUpdate),
p.i.Inst.AddEventHandler(f.g.LONGLINNUM_UPDATE,this._degf_OnDataUpdate),p.i.Inst.AddEventHandler(f.g.ASURAM_TECHMONEY_UPDATE,this._degf_OnDataUpdate),
p.i.Inst.AddEventHandler(f.g.ASURAM_MATERIAL_UPDATE,this._degf_OnDataUpdate),p.i.Inst.AddEventHandler(f.g.Gold_Diamond_Limit_Update,this._degf_OnDataUpdate),
p.i.Inst.AddEventHandler(f.g.BAG_UPDATE,this._degf_OnDataUpdate),p.i.Inst.AddEventHandler(f.g.CURRENCY_BAR_DEEPTH,this.CreateDelegate(this.UpdateDeepth)),
p.i.Inst.AddEventHandler(f.g.CURRENCY_BAR_TYPE,this._degf_OnCurrencyUpdate),p.i.Inst.AddEventHandler(f.g.CURRENCY_CHARGE_WAVEANIMBEFORE,this.CreateDelegate(this.WaveAnimBefore)),
k.w.Instance.AddEventHandler(k.w.eUpdateCurrency,this._degf_OnCurrencyUpdate),
null!=k.w.Instance.showItems?this.OnDataUpdate():this.OnCurrencyUpdate(T._.ShowGold_Dia_HonourShopPoint),(0,c.bG)(f.g.CURRENCY_BAR_INITED),(0,c.bG)(f.g.CURRENCY_LAYER_UPDATE),
p.i.Inst.RaiseEvent(f.g.CURRENCY_BAR_INITED),p.i.Inst.RaiseEvent(f.g.CURRENCY_LAYER_UPDATE)}OnDataUpdate(t=null){const e=this.ItemList?this.ItemList.Count():0
for(let t=0;t<=e-1;t++)this.ItemList[t].node.active=!1,this.ItemList[t].Clear()
const i=k.w.Instance.showItems
if(null!=i&&i.length>0)for(let t=0;t<=i.length-1;t++){let s=null
s=t<=e-1?this.ItemList[t]:this.OnGridItem(),s&&(s.node.active=!0,s.SetData(i[t]))}this.UpdateDeepth()}OnDiamondUpdate(t=null){this.OnDataUpdate(t)}deepCopyObj(t){var e
e=t instanceof Array?[]:{}
for(let s in t){var i=t[s]
"object"!=typeof i&&"function"!=typeof i||(i=this.deepCopyObj(i)),e[s]=i}return e}WaveAnimBefore(t){let e=!1
const i=k.w.Instance.showItems
if(null!=i&&i.Count()>0)for(let t=0;t<=i.Count()-1;t++)if(t<=this.ItemList.Count()-1){if(this.ItemList[t].CheckHideShow()){e=!0
break}}}OnCurrencyUpdate(t){this.OnDataUpdate()}UpdateDeepth(){}Clear(){D.T.Inst_get().RemoveEventHandler(A.F.UPDATE_INFO,this._degf_OnDataUpdate),
v.X.Inst_get().RemoveEventHandler(E.E.EXCHANGE_SUCCESS,this._degf_OnDataUpdate),m.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(g.A.GoldUpdate,this._degf_OnDataUpdate),
m.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(g.A.Gold_DiamondUpdate,this._degf_OnDataUpdate),
m.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(g.A.Bind_DiamondUpdate,this._degf_OnDataUpdate),
m.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(g.A.Score_NumUpdate,this._degf_OnDataUpdate),
m.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(g.A.Skill_PointUpdate,this._degf_OnDataUpdate),
m.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(g.A.HonourUpdate,this._degf_OnDataUpdate),
m.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(g.A.AsuramIdUpdate,this._degf_OnDataUpdate),
m.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(g.A.ReputationUpdate,this._degf_OnDataUpdate),
m.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(g.A.AsuramTokenUpdate,this._degf_OnDataUpdate),
m.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(g.A.HonourShopPointUpdate,this._degf_OnDataUpdate),
m.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(g.A.TreasureUpdate,this._degf_OnDataUpdate),p.i.Inst.RemoveEventHandler(f.g.ALLIANCE_CONTRIBUTE_UPDATE,this._degf_OnDataUpdate),
p.i.Inst.RemoveEventHandler(f.g.LONGLINNUM_UPDATE,this._degf_OnDataUpdate),p.i.Inst.RemoveEventHandler(f.g.ASURAM_TECHMONEY_UPDATE,this._degf_OnDataUpdate),
p.i.Inst.RemoveEventHandler(f.g.ASURAM_MATERIAL_UPDATE,this._degf_OnDataUpdate),p.i.Inst.RemoveEventHandler(f.g.BAG_UPDATE,this._degf_OnDataUpdate),
p.i.Inst.RemoveEventHandler(f.g.CURRENCY_BAR_DEEPTH,this.CreateDelegate(this.UpdateDeepth)),p.i.Inst.RemoveEventHandler(f.g.CURRENCY_BAR_TYPE,this._degf_OnCurrencyUpdate),
p.i.Inst.RemoveEventHandler(f.g.Gold_Diamond_Limit_Update,this._degf_OnDataUpdate),
p.i.Inst.RemoveEventHandler(f.g.CURRENCY_CHARGE_WAVEANIMBEFORE,this.CreateDelegate(this.WaveAnimBefore)),
k.w.Instance.RemoveEventHandler(k.w.eUpdateCurrency,this._degf_OnCurrencyUpdate)
for(let t=0;t<=this.ItemList.Count()-1;t++)this.ItemList[t].Clear()}GetPosByType(t){
if(null!=this.ItemList&&this.ItemList.Count()>0)for(let e=0;e<=this.ItemList.Count();e++)if(null!=this.ItemList[e]._vo&&this.ItemList[e]._vo.m_type==t)return this.ItemList[e].btn_icon.position
return S.P.zero_get()}GetFlyPosByType(t){
if(null!=this.ItemList&&this.ItemList.Count()>0)for(let e=0;e<=this.ItemList.Count();e++)if(null!=this.ItemList[e]._vo&&this.ItemList[e]._vo.m_type==t)return this.ItemList[e].item_img.node.transform.TransformPoint(this.ItemList[e].item_img.node.position)
return S.P.zero_get()}GetPanelDepth(){return this.ui_comm_currency_bar.depth()}OnGridItem(){const t=d.o.getPrefab("ui_comm_currency_item")
if(null==t)return null
const e=(0,h.instantiate)(t)
if(!e)return null
const i=e.getCNode(U)
return this.grid.node.addChild(e),this.ItemList.Add(i),i}Destroy(){}}).DestoryLevel0=null,
V((o=r).prototype,"OnDataUpdate",[n],Object.getOwnPropertyDescriptor(o.prototype,"OnDataUpdate"),o.prototype),
V(o.prototype,"OnDiamondUpdate",[l],Object.getOwnPropertyDescriptor(o.prototype,"OnDiamondUpdate"),o.prototype),a=o))||a)},86209:(t,e,i)=>{i.d(e,{w:()=>b})
var s,n,l=i(42292),a=i(93984),o=i(38836),r=i(86133),h=i(98800),d=i(97960),c=i(97461),_=i(98958),u=i(68662),I=i(54967),m=i(62370),g=i(31222),p=i(5494),C=i(35128),S=i(55360),f=i(98885),T=i(85602),y=i(38962),A=i(34334),D=i(92679),E=i(28287),v=i(85751),w=i(87923),R=i(37648),P=i(55492),O=i(20886),L=i(19519),B=i(58087)
let b=(n=class t extends I.g{static get Instance(){return t._instance||(t._instance=new t),t._instance}constructor(){super(),this.itemsDic=null,this.showItems=null,
this.showRechargeEff=!1,this.diamondEffType=1,this.currencyTweenTypes=null,this.initVal=!1,this.deepthsDict=null,this.addDiamondLimitNum=null,this.addDiamondLimitTime=null,
this.initLimit=!1,this.diamond_Limit=0,this.noticeList=null,this.noticeSoonList=null,this.timeLimitedCurrencyMap=null,this.timelimitedCsvMap=null,this.itemsDic=new y.X,
this.showItems=new T.Z,this.currencyTweenTypes=new T.Z,this.deepthsDict=new B.y,this.noticeList=new T.Z,this.noticeSoonList=new T.Z
const t=S.Y.Inst.GetOrCreateCsv(a.h.eTimelimitedcurrencyresourceCsv)
this.timelimitedCsvMap=t.GetCsvMap()}GetStrValByType(t){const e=L.J.GetGold(h.Y.Inst.PrimaryRoleInfo_get(),t,!1)
return this.ConvertNumToString(e)}DiaCurrencyNumDes(t){if(t==L.J.GOLD_DIAMOND||t==L.J.GOLD_DIAMOND_STR){
const e=L.J.GetGold(h.Y.Inst.PrimaryRoleInfo_get(),t,!1),i=L.J.GetGold(h.Y.Inst.PrimaryRoleInfo_get(),L.J.GOLD_DIAMOND_LIMIT,!1)
return i>0?this.ConvertNumToString(e)+v.u.GetColorString(v.u.BrightGreenColorStr2,`+(${this.ConvertNumToString(i)})`):this.ConvertNumToString(e)}
const e=L.J.GetGold(h.Y.Inst.PrimaryRoleInfo_get(),t,!1)
return this.ConvertNumToString(e)}ConvertNumToString(t){let e=""
return t<0&&(e="-",t=Math.abs(t)),t<1e5?e+=m.o.NumToString(t,2,1):t<1e8?(t/=1e4,e+=m.o.NumToString(t,2,1)+(0,r.T)("万")):(t/=1e8,e+=m.o.NumToString(t,2,1)+(0,r.T)("亿")),e}
ConvertNumToUnitize(t){return t>=0&&t<1e4?f.M.DoubleToString(t):t<1e8?(t/=1e4,C.p.CeilToInt(t)+(0,r.T)("万")):t>=1e8?(t/=1e8,C.p.CeilToInt(t)+(0,r.T)("亿")):""}
Gold_Diamond_Limit_set(t,e){let i=0,s=0,n=0
const l=null!=this.timeLimitedCurrencyMap
if(l&&null!=e){
for(const[e,i]of(0,o.V5)(t))null==i||null==i.num?this.timeLimitedCurrencyMap.LuaDic_Remove(e):l&&this.timeLimitedCurrencyMap.LuaDic_ContainsKey(e)?null!=i.num?(s<=0&&(s=i.num.ToNum()-this.timeLimitedCurrencyMap[e].num.ToNum(),
n=i.expiredTime.ToNum()),this.timeLimitedCurrencyMap[e]=i):this.timeLimitedCurrencyMap.LuaDic_Remove(e):(this.timeLimitedCurrencyMap.LuaDic_AddOrSetItem(e,i),
s<=0&&(s=i.num.ToNum(),n=i.expiredTime.ToNum()))
if(e&&s>0){A.O.Inst().OpenDiamondLimitGetRewardPanel(s,n)
g.N.inst.IsViewShowing(p.I.CurrencyBar)&&A.O.Inst().OpenDiamondGetEffect(L.J.GOLD_DIAMOND_LIMIT)}}else this.timeLimitedCurrencyMap=t
for(const[t,e]of(0,o.V5)(this.timeLimitedCurrencyMap))null==e?this.timeLimitedCurrencyMap.LuaDic_Remove(t):null!=e.num?i+=e.num.ToNum():this.timeLimitedCurrencyMap.LuaDic_Remove(t)
this.diamond_Limit=i,c.i.Inst.RaiseEvent(D.g.Gold_Diamond_Limit_Update),null!=h.Y.Inst.PrimaryRoleInfo_get()&&h.Y.Inst.PrimaryRoleInfo_get().RaiseEvent(d.A.Gold_DiamondUpdate)}
Gold_Diamond_Limit_get(){return this.diamond_Limit}IsLimitDiamond(t){return O.v.DIAMOND_LIMIT_ID==t}GetLimitDiamondDes(){let t=""
if(this.diamond_Limit>0){const e=this.GetTimeLess()
e>0&&(t+=_.V.Inst().replaceLangParamOne("将于[DBA968]{0}[-] 后失效",w.l.GetDateFormat(e/1e3,null,!1,!1)))}return t}GetTimeLess(){let t=null
for(const[e,i]of(0,o.V5)(this.timeLimitedCurrencyMap))(null==t||i.expiredTime.ToNum()<t)&&(t=i.expiredTime.ToNum())
return null!=t?t-u.D.serverMSTime_get():0}AddNoticeData(t){this.noticeList.Add(t),this.ReCordNoticeSoonData(t)}AddNoticeSoonData(t){this.noticeSoonList.Add(t)}GetNoticeData(){
return this.noticeList.count>0?[this.noticeList[0],!0]:this.noticeSoonList.count>0?[this.noticeSoonList[0],!1]:null}ReCordNoticeData(t){let e=this.noticeList.count-1
for(;e>=0;){if(t.id==this.noticeList[e].id){this.noticeList.RemoveAt(e)
break}e-=1}this.ReCordNoticeSoonData(t),this.CheckCloseIcon()}ReCordNoticeSoonData(t){let e=this.noticeSoonList.count-1
for(;e>=0;){if(t.id==this.noticeSoonList[e].id){this.noticeSoonList.RemoveAt(e)
break}e-=1}}CheckCloseIcon(){0==this.noticeSoonList.count&&0==this.noticeList.count?A.O.Inst().CloseDiamondLimitNoticeIcon():A.O.Inst().OpenDiamondLimitNoticeIcon()}
ConvertNumFloor(t){return t>=0&&t<1e4?f.M.DoubleToString(t):t<1e8?(t/=1e4,C.p.FloorToInt(t)+(0,r.T)("万")):t>=1e8?(t/=1e8,C.p.FloorToInt(t)+(0,r.T)("亿")):""}GetTimeLimitResBtId(t){
return this.timelimitedCsvMap[t]}ResetData(){this.timeLimitedCurrencyMap=null,this.diamond_Limit=0}ResetType(t){
t==E._.ShowGold_Dia_HonourShopPoint&&(t=R.P.Inst_get().IsFunctionOpened(P.x.DAILY)?E._.ShowGold_Dia_HonourShopPoint:E._.ShowGold_Score_BindDia),
this.showItems=this.itemsDic.LuaDic_GetItem(t)?this.itemsDic.LuaDic_GetItem(t).concat():null,this.showItems&&this.showItems.reverse(),c.i.Inst.RaiseEvent(D.g.CURRENCY_BAR_TYPE,t)}
AddTweenCurrecyType(t){return!this.currencyTweenTypes.Contains(t)&&(this.currencyTweenTypes.Add(t),!0)}GeTweenCurrecyType(){
return this.currencyTweenTypes.count>0?this.currencyTweenTypes[0]:null}GetNextTweenCurrecyType(t){return this.currencyTweenTypes.Remove(t),
this.currencyTweenTypes.count>0?this.currencyTweenTypes[0]:null}AddDeepth(t,e){-1!=e&&(this.deepthsDict.LuaDic_AddOrSetItem(t,e),c.i.Inst.RaiseEvent(D.g.CURRENCY_BAR_DEEPTH))}
RemoveDeepth(t){this.deepthsDict.LuaDic_Remove(t),c.i.Inst.RaiseEvent(D.g.CURRENCY_BAR_DEEPTH)}GetMaxDeepthUid(){let t,e=0
for(const[i,s]of(0,o.V5)(this.deepthsDict))s>e&&(e=s,t=i)
return t||0}},n.eUpdateCurrency="eUpdateCurrency",n._instance=null,M=s=n,G="Instance",H=[l.n],N=Object.getOwnPropertyDescriptor(s,"Instance"),k=s,U={},
Object.keys(N).forEach((function(t){U[t]=N[t]})),U.enumerable=!!U.enumerable,U.configurable=!!U.configurable,("value"in U||U.initializer)&&(U.writable=!0),
U=H.slice().reverse().reduce((function(t,e){return e(M,G,t)||t}),U),k&&void 0!==U.initializer&&(U.value=U.initializer?U.initializer.call(k):void 0,U.initializer=void 0),
void 0===U.initializer&&(Object.defineProperty(M,G,U),U=null),s)
var M,G,H,N,k,U},59732:(t,e,i)=>{i.d(e,{T:()=>d})
var s=i(38935),n=i(18202),l=i(31222),a=i(67170),o=i(5336),r=i(13224),h=i(60186)
class d{constructor(){this.mainView=null,this.welfareContainer=null}static Inst_Get(){return null==d.Inst&&(d.Inst=new d),d.Inst}ReqGetDailyRechargeReward(t){const e=new o.R
e.resourceId=t,s.C.Inst.F_SendMsg(e)}ReqGetDailyRechargeFreeReward(){const t=new a.a
s.C.Inst.F_SendMsg(t)}Open(t){null==this.mainView?(this.welfareContainer=t,n.g.LoadOne("ui_dailyrecharge_view",this.CreateDelegate(this.OnLoadManiView))):this.mainView.SetData()}
OnLoadManiView(t){const e=t[0]
this.mainView=new h.y,this.mainView.setId(e,null,0),this.mainView.node.transform.SetParent(this.welfareContainer.FatherId,this.welfareContainer.ComponentId),
l.N.inst.SetChildDepth(r.w.Inst_Get().GetMainPanelId(),e),this.mainView.SetData(),this.welfareContainer=null}Close(){null!=this.mainView&&this.mainView.Clear()}OnDestroyMainView(){
null!=this.mainView?(this.mainView.Clear(),this.mainView.Destroy(),n.g.DestroyUIObj(this.mainView),this.mainView=null):n.g.Unload(this.OnLoadManiView)}}d.Inst=null},
17232:(t,e,i)=>{i.d(e,{u:()=>r})
var s=i(93984),n=i(38836),l=i(55360),a=i(85602),o=i(38962)
class r{constructor(){this._map=null,this.roundMap=null,this.roundShowRewardMap=null
const t=l.Y.Inst.GetOrCreateCsv(s.h.DailyRechargeResource)
this._map=t.GetCsvMap(),this.roundMap=new o.X,this.roundShowRewardMap=new o.X
for(const[t,e]of(0,n.V5)(this._map))e.showReward&&""!=e.showReward&&this.roundShowRewardMap.LuaDic_AddOrSetItem(e.round,e.showReward),
this.roundMap[e.round]||(this.roundMap[e.round]=new a.Z),this.roundMap[e.round].Add(e)}static Inst_Get(){return null==r.Inst&&(r.Inst=new r),r.Inst}GetDailyRechargeCfg(t){
return this._map[t]}GetShowRewardId(t){return this.roundShowRewardMap[t]}GetAllCfg(){return this._map}GetRoundAllCfg(t){return this.roundMap[t]?this.roundMap[t]:new o.X}}
r.Inst=null},14744:(t,e,i)=>{i.d(e,{b:()=>s})
class s{}s.Update="DailyRechargeUpdate",s.Type2=2,s.Type3=3},9186:(t,e,i)=>{i.d(e,{i:()=>h})
var s=i(38836),n=i(16812),l=i(14792),a=i(62734),o=i(17232),r=i(14744)
class h extends n.k{constructor(...t){super(...t),this.DailyRechargeInfo=null,this.ShowGoToBtnId=null}static Inst_Get(){return null==h.Inst&&(h.Inst=new h),h.Inst}ResetModel(){
this.DailyRechargeInfo=null,this.ShowGoToBtnId=null}DailyRechargeInfoSet(t){const e=this.GetRound()
this.DailyRechargeInfo=t
let i=this.ExistAndCanGet()
a.f.Inst.SetState(l.t.DAILY_RECHARGE_HASREWARD,i),i=this.FreeAwardCanGet_Get(),a.f.Inst.SetState(l.t.DAILY_RECHARGE_FREE,i)
const s=this.GetRound()
this.RaiseEvent(r.b.Update,e!=s)}GetRound(){if(this.DailyRechargeInfo)return this.DailyRechargeInfo.curRound}GetRechargeDayCount(){
return this.DailyRechargeInfo?this.DailyRechargeInfo.rechargeDayCount:0}GetTodayHadRecharge(){return!!this.DailyRechargeInfo&&this.DailyRechargeInfo.hadRecharged}IsRewardCanGet(t){
if(this.DailyRechargeInfo){if(1==this.DailyRechargeInfo.rewardMap[t])return!0}}IsRewardGot(t){if(this.DailyRechargeInfo){if(2==this.DailyRechargeInfo.rewardMap[t])return!0}}
ExistAndCanGet(){const t=this.GetRound()
if(t){const e=o.u.Inst_Get().GetRoundAllCfg(t)
for(const[t,i]of(0,s.V5)(e))if(this.IsRewardCanGet(i.id))return!0}return!1}IsAllRewardGot(){const t=this.GetRound()
if(t){const e=o.u.Inst_Get().GetRoundAllCfg(t)
for(const[t,i]of(0,s.V5)(e))if(!this.IsRewardGot(i.id))return!1
return!0}}FreeAwardCanGet_Get(){return!(!this.DailyRechargeInfo||this.DailyRechargeInfo.hadGainFree)}Test1(){return!0}S_Test(){return!0}}h.Inst=null},60186:(t,e,i)=>{i.d(e,{y:()=>S
})
var s=i(83908),n=i(38836),l=i(28192),a=i(85602),o=i(79534),r=i(75696),h=i(53905),d=i(65772),c=i(74657),_=i(59732),u=i(17232),I=i(14744),m=i(9186),g=i(91897),p=i(11162)
class C extends((0,s.zB)()){constructor(...t){super(...t),this.ID=0,this.resPath="atlas/common/"}InitView(){this.grid.SetInitInfo("ui_baseitem",null,r.j)}SetData(t){this.ID=t
const e=u.u.Inst_Get().GetDailyRechargeCfg(t),i=m.i.Inst_Get().IsRewardGot(t),s=m.i.Inst_Get().IsRewardCanGet(t),l=m.i.Inst_Get().GetRechargeDayCount(),a=m.i.Inst_Get().GetTodayHadRecharge()
this.dayLabel.textSet(`第${e.rechargeDay}天`),this.hasReceive.SetActive(!1),this.gotoBtn.SetActive(!1),this.receiveBtn.node.SetActive(!1),this.noReach.SetActive(!1),
this.bg.spriteNameSet(this.resPath+"rycommon_sp_0128"),i?(this.hasReceive.SetActive(!0),
this.bg.spriteNameSet(this.resPath+"rycommon_sp_0127")):s?this.receiveBtn.node.SetActive(!0):l+1==e.rechargeDay?a?(this.noReachTxt.textSet("明日开启"),
this.noReach.SetActive(!0)):this.gotoBtn.SetActive(!0):(this.noReachTxt.textSet("未开启"),this.noReach.SetActive(!0))
const o=c.A.GetReward(e.rewardId).GetJobLimitItemList()
for(const[t,e]of(0,n.V5)(o))e.isShowBind=!1
this.grid.data_set(o),this.m_handlerMgr.AddClickEvent(this.receiveBtn,this.CreateDelegate(this.ReceiveClick)),
this.m_handlerMgr.AddClickEvent(this.gotoBtn,this.CreateDelegate(this.GoToClick))}GoToClick(){g.v.Inst_get().ChargeIntercept()||p.O.Inst_get().Open(1,2,1)}ReceiveClick(){
_.T.Inst_Get().ReqGetDailyRechargeReward(this.ID)}Clear(){}Destroy(){}Test1(){return!0}S_Test(){return!0}}class S extends((0,s.Ri)()){constructor(...t){super(...t),this.model=null,
this._m_handlerMgr=null}get m_handlerMgr(){return this._m_handlerMgr||(this._m_handlerMgr=l.h.Get()),this._m_handlerMgr}InitView(){
this.rewardGrid.SetInitInfo("ui_baseitem",null,r.j),this.grid.SetInitInfo("ui_dailyrecharge_item",null,C),this.model=m.i.Inst_Get()}SetData(){this.RefreshLeft(),
this.RefreshRight(),this.RefreshFree(),this.m_handlerMgr.AddClickEvent(this.tipBtn,this.CreateDelegate(this.ClickTipBtn)),
this.m_handlerMgr.AddClickEvent(this.getFreeAwardBtn,this.CreateDelegate(this.ClickGetFreeAward)),this.AddRemoveEvent(!0)}AddRemoveEvent(t){
t?this.model.AddEventHandler(I.b.Update,this.CreateDelegate(this.Refresh)):this.model.RemoveEventHandler(I.b.Update,this.CreateDelegate(this.Refresh))}RefreshFree(){
const t=this.model.FreeAwardCanGet_Get()
this.canGetAward.SetActive(t),this.hadGotAward.SetActive(!t)}Refresh(t){t&&this.RefreshLeft(),this.RefreshRight(),this.RefreshFree()}RefreshLeft(){
const t=this.model.GetRound(),e=u.u.Inst_Get().GetShowRewardId(t),i=c.A.GetReward(e).GetJobLimitItemList()
for(const[t,e]of(0,n.V5)(i))e.isShowBind=!1
this.rewardGrid.data_set(i)}SortItem(t,e){
const i=u.u.Inst_Get().GetDailyRechargeCfg(t),s=u.u.Inst_Get().GetDailyRechargeCfg(e),n=this.model.IsRewardGot(i.id),l=this.model.IsRewardGot(s.id)
if(!n&&l)return-1
if(n&&!l)return 1
const a=this.model.IsRewardCanGet(i.id),o=this.model.IsRewardCanGet(s.id)
return a&&!o?-1:!a&&o?1:i.rechargeDay-s.rechargeDay}RefreshRight(){const t=this.model.GetRound(),e=new a.Z,i=u.u.Inst_Get().GetRoundAllCfg(t)
for(const[t,s]of(0,n.V5)(i))e.Add(s.id)
e.Sort(this.CreateDelegate(this.SortItem)),this.grid.data_set(e),this.allReceive.SetActive(this.model.IsAllRewardGot())}ClickTipBtn(){const t=new h.w
t.position=new o.P(-86,266,0),t.width=450,t.height=170,t.infoId="DAILYRECHARGE:TIPS",d.Q.Inst_get().Open(t)}ClickGetFreeAward(){_.T.Inst_Get().ReqGetDailyRechargeFreeReward()}
Clear(){this.AddRemoveEvent(!1),this.node.SetActive(!1)}Destroy(){}Test1(){return!0}S_Test(){return!0}}},47058:(t,e,i)=>{i.d(e,{M:()=>z})
var s=i(86133),n=i(98800),l=i(97960),a=i(97461),o=i(70829),r=i(99294),h=i(9986),d=i(6665),c=i(9776),_=i(32759),u=i(93877),I=i(3522),m=i(72005),g=i(61911),p=i(98885),C=i(85602),S=i(72785),f=i(79534),T=i(1240),y=i(70850),A=i(99864),D=i(63076),E=i(92984),v=i(92679),w=i(13526),R=i(87923),P=i(48481),O=i(96713),L=i(78967),B=i(63945),b=i(95895),M=i(8211),G=i(64501),H=i(35259),N=i(19519),k=i(21892),U=i(93984),V=i(98958),x=i(50089),F=i(68662),q=i(62370),Y=i(5924),W=i(9057),j=i(57834),Z=i(98130),X=i(76645),K=i(33828)
class $ extends W.x{constructor(){super(),this.label_name=null,this.label_des=null,this.item=null,this.use=null,this.buyBtn=null,this.useing=null,this.price=null,
this.currencyIcon=null,this.recommIcon=null,this._listener=null,this.model=null,this.timer=-1,this.endTime=0,this.descStr="",this.id=0,this.expItemData=null,this.priceVal=0,
this.mallID=0,this._degf_BuyHandler=null,this._degf_OnOperateClick=null,this._degf_SendBuyHandler=null,this._degf_TimerHandler=null,this.model=E.j.Inst_get().model,
this._degf_BuyHandler=(t,e)=>this.BuyHandler(t,e),this._degf_OnOperateClick=(t,e)=>this.OnOperateClick(t,e),this._degf_SendBuyHandler=t=>this.SendBuyHandler(t),
this._degf_TimerHandler=()=>this.TimerHandler()}InitView(){super.InitView(),this.label_name=new u.Q,this.label_name.setId(this.FatherId,this.FatherComponentID,1),
this.label_des=new u.Q,this.label_des.setId(this.FatherId,this.FatherComponentID,2),this.item=new A.P,this.item.setBinderId(this.FatherId,this.FatherComponentID,3),
this.use=new h.W,this.use.setId(this.FatherId,this.FatherComponentID,4),this.buyBtn=new h.W,this.buyBtn.setId(this.FatherId,this.FatherComponentID,5),this.useing=new r.z,
this.useing.setId(this.FatherId,this.FatherComponentID,6),this.price=new u.Q,this.price.setId(this.FatherId,this.FatherComponentID,7),this.currencyIcon=new m.w,
this.currencyIcon.setId(this.FatherId,this.FatherComponentID,8),this.recommIcon=new r.z,this.recommIcon.setId(this.FatherId,this.FatherComponentID,9),this.AddListeners()}
SetData(t){if(this.ClearTimer(),this.expItemData=t,this.item.SetData(this.expItemData.itemData.baseData_get()),this.id=this.expItemData.itemData.serverData_get().modelId,
this.label_name.textSet(this.expItemData.itemData.baseData_get().cfgData_get().name),this.descStr=this.expItemData.buffRes.desc,null!=this.expItemData.mallData){
const t=p.M.Replace(this.expItemData.mallData.Cfg_get().consums.costs[0].subvalue,p.M.s_SPAN_CHAR,""),e=p.M.String2Int(t)
this.priceVal=1*e,this.mallID=this.expItemData.mallData.mallid,this.price.textSet(p.M.IntToString(this.priceVal)),
this.expItemData.mallData.Cfg_get().labelId==b.g.SCORE?this.currencyIcon.spriteNameSet(N.J.GetCurrencyIconUrl(N.J.ScoreStr)):this.currencyIcon.spriteNameSet(N.J.GetCurrencyIconUrl(N.J.GOLD_DIAMOND_STR))
}if(null!=this.expItemData.buff)this.endTime=Z.GF.INT(1e-4*this.expItemData.buff.vo.useEndTime_get()),
F.D.serverTime_get()<this.endTime&&(this.timer=Y.C.Inst_get().SetInterval(this._degf_TimerHandler,1e3),this.TimerHandler())
else{const t=this.expItemData.itemData.baseData_get().cfgData_get().Rewards_get()
if(null!=t){const e=p.M.String2Int(t.typevalues[0].value),i=E.j.Inst_get().model.GetBuffResById(e)
if(null!=i){const t=new C.Z
t.Add(R.l.GetTimeText(Z.GF.INT(i.duration/6e4)))
const e=x.t.decode(i.value,k.J)
if(null!=e){const i=p.M.IntToString(p.M.String2Int(e.rate)/100)+q.o.s_UNDER_PERCENT
t.Add(i),this.label_des.textSet(V.V.Inst().getStr(10812,U.h.eLangResource,t))}}}}this.buyBtn.node.SetActive(1==this.expItemData.type),
this.use.node.SetActive(0==this.expItemData.type),this.useing.SetActive(2==this.expItemData.type),this.recommIcon.SetActive(this.expItemData.isFirst)}TimerHandler(){
const t=this.endTime-F.D.serverTime_get()
t<0?(this.ClearTimer(),this.label_des.textSet(this.descStr)):this.label_des.textSet((0,s.T)("剩余时间：")+R.l.GetDateFormatEX(t))}ClearTimer(){Y.C.Inst_get().ClearInterval(this.timer),
this.timer=-1}AddListeners(){j.i.Get(this.use.node).RegistonClick(this._degf_OnOperateClick),j.i.Get(this.buyBtn.node).RegistonClick(this._degf_BuyHandler)}BuyHandler(t,e){
if(null!=this.expItemData.mallData){if(this.expItemData.mallData.Cfg_get().labelId!=b.g.SCORE){
if(this.priceVal>N.J.GetGold(n.Y.Inst.PrimaryRoleInfo_get(),N.J.GOLD_DIAMOND))return void K.Y.Inst_get().Open()
}else if(this.priceVal>n.Y.Inst.PrimaryRoleInfo_get().Sonsign_Score_get())return void N.J.JudgeConsumeScore(this.priceVal,this._degf_SendBuyHandler,this.mallID)
this.SendBuyHandler(this.mallID)}}SendBuyHandler(t){B.x.inst.ReqBuyMallItem(Z.GF.INT(t),1)}OnOperateClick(t,e){let i=y.g.Inst_get().GetBindItemByModleID(this.id)
L.M.Inst_get().useExpItemId=this.id,null==i?(i=y.g.Inst_get().GetItemByModleID(this.id),
null!=i&&null!=i.baseData_get()&&X.t.Inst_get().UseItem(1,i.baseData_get().modelId_get())):null!=i&&null!=i.baseData_get()&&X.t.Inst_get().UseItem(1,i.baseData_get().modelId_get())
}Clear(){this.ClearTimer()}Destroy(){j.i.Get(this.use.node).RemoveonClick(this._degf_OnOperateClick),j.i.Get(this.buyBtn.node).RemoveonClick(this._degf_BuyHandler),
this.label_name=null,this.label_des=null,this.item.Destroy(),this.item=null,this.use=null,this.buyBtn=null,this.useing=null,this.price=null,this.currencyIcon=null,
this.recommIcon=null}}class J{constructor(){this.type=0,this.buffRes=null,this.buff=null,this.itemData=null,this.mallData=null,this.isFirst=!1}}class z extends g.f{constructor(){
super(),this._Grid=null,this.btnclose=null,this.scroll=null,this.skillGo=null,this.skillPrice=null,this.skillBuyBtn=null,this.skillItem=null,this.skillName=null,this.buyAnim=null,
this.buyFlyAnim=null,this.buyBoomAnim=null,this.buyLightAnim=null,this.useAnim=null,this.useLightAnim=null,this.lookLightAnim=null,this.skillCostIcon=null,this.m_itemData=null,
this.mallID=0,this.m_price=0,this.isUse=!1,this.useSkillId=0,this._degf_NoHandler=null,this._degf_OnItemRefreshFun=null,this._degf_OnViewUpdate=null,
this._degf_PlayBuyAnimHandler=null,this._degf_PlayUseAnimHandler=null,this._degf_SkillBuyHandler=null,this._degf_UpdateSkillView=null,this._degf_closeHandler=null,
this._degf_setData=null,this._degf_NoHandler=(t,e)=>this.NoHandler(t,e),this._degf_OnItemRefreshFun=t=>this.OnItemRefreshFun(t),this._degf_OnViewUpdate=t=>this.OnViewUpdate(t),
this._degf_PlayBuyAnimHandler=t=>this.PlayBuyAnimHandler(t),this._degf_PlayUseAnimHandler=t=>this.PlayUseAnimHandler(t),this._degf_SkillBuyHandler=(t,e)=>this.SkillBuyHandler(t,e),
this._degf_UpdateSkillView=t=>this.UpdateSkillView(t),this._degf_closeHandler=(t,e)=>this.closeHandler(t,e),this._degf_setData=t=>this.setData(t)}InitView(){super.InitView(),
this._Grid=new d.A,this._Grid.setId(this.FatherId,null,1),this._Grid.SetInitInfo("ui_copybaseui_belielexp_item",this._degf_OnItemRefreshFun),this.btnclose=new h.W,
this.btnclose.setId(this.FatherId,this.FatherComponentID,2),this.scroll=new c.h,this.scroll.setId(this.FatherId,this.FatherComponentID,3),this.skillGo=new r.z,
this.skillGo.setId(this.FatherId,this.FatherComponentID,4),this.skillPrice=new u.Q,this.skillPrice.setId(this.FatherId,this.FatherComponentID,5),this.skillBuyBtn=new h.W,
this.skillBuyBtn.setId(this.FatherId,this.FatherComponentID,6),this.skillItem=new A.P,this.skillItem.setBinderId(this.FatherId,this.FatherComponentID,7),this.skillName=new u.Q,
this.skillName.setId(this.FatherId,this.FatherComponentID,8),this.buyAnim=new I.k,this.buyAnim.setId(this.FatherId,this.FatherComponentID,9),this.buyFlyAnim=new _.c,
this.buyFlyAnim.setId(this.FatherId,this.FatherComponentID,10),this.buyBoomAnim=new I.k,this.buyBoomAnim.setId(this.FatherId,this.FatherComponentID,11),this.buyLightAnim=new I.k,
this.buyLightAnim.setId(this.FatherId,this.FatherComponentID,12),this.useAnim=new I.k,this.useAnim.setId(this.FatherId,this.FatherComponentID,13),this.useLightAnim=new I.k,
this.useLightAnim.setId(this.FatherId,this.FatherComponentID,14),this.lookLightAnim=new r.z,this.lookLightAnim.setId(this.FatherId,this.FatherComponentID,15),
this.skillCostIcon=new m.w,this.skillCostIcon.setId(this.FatherId,this.FatherComponentID,16),this.AddListeners()}OnItemRefreshFun(t){const e=new $
return e.setId(t,null,0),e}AddListeners(){a.i.Inst.AddEventHandler(v.g.BAG_UPDATE,this._degf_setData),a.i.Inst.AddEventHandler(v.g.SKILL_UPDATE,this._degf_UpdateSkillView),
a.i.Inst.AddEventHandler(v.g.COPYEXPPANEL_BUYSUCCESS_SKILL,this._degf_PlayBuyAnimHandler),a.i.Inst.AddEventHandler(v.g.COPYEXPPANEL_USESUCCESS_ITEM,this._degf_PlayUseAnimHandler),
this.AddClickEvent(this.btnclose,this._degf_closeHandler),this.AddClickEvent(this.skillBuyBtn,this._degf_SkillBuyHandler),
n.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(l.A.Gold_DiamondUpdate,this._degf_OnViewUpdate),a.i.Inst.AddEventHandler(v.g.BAG_UPDATE,this._degf_OnViewUpdate),
n.Y.Inst.PrimaryRoleInfo_get().AddEventHandler(l.A.Score_NumUpdate,this._degf_OnViewUpdate),this.AddFullScreenCollider(this.node,this._degf_NoHandler,null,!1)}NoHandler(t,e){}
OnViewUpdate(t){this.UpdateView(),this.UpdateSkillView(null)}closeHandler(t,e){O.n.inst.CloseCopyBelielExpPanel()}OnAddToScene(){this.scroll.SetDragAmount(0,0,!0),
this.UpdateView(),this.UpdateSkillView(null)}setData(t){this.UpdateView()}UpdateSkillView(t){const e=L.M.Inst_get().GetExpSkillIdAndMallId()
if(this.isUse=!1,null!=e&&0!=e.Count()){this.useSkillId=e[0]
const t=n.Y.Inst.PrimaryRoleInfo_get().Skills_get()
let i=!1,l=0
for(;l<e.Count();){const s=n.Y.Inst.PrimaryRoleInfo_get().Level_get()
if(i=!t.LuaDic_ContainsKey(e[l])&&s>=e[l+2],this.useSkillId=e[l],this.mallID=e[l+1],l+=2,i)break
l+=1}if(i){const t=M.N.GetInst().GetInfo(this.mallID)
null!=t&&null!=t.Cfg_get()||S.c.DebugError(this.mallID+(0,s.T)("这个商城ID在mallresource表中没有"))
const e=y.g.Inst_get().GetItemNum(t.Cfg_get().itemId),i=new P.t
i.modelId=t.Cfg_get().itemId,this.m_itemData=new D.M(t.Cfg_get().itemId,i),this.m_itemData.isCanOperate=!1,this.m_itemData.isEquipCompare=!1,this.m_itemData.isShowAccess=!1,
this.m_itemData.tipsPos=new f.P(-90,0,0),this.skillItem.SetData(this.m_itemData)
const l=o.j.Inst().GetSkillById(this.useSkillId)
this.skillName.textSet(R.l.GetQualityColorStr(R.l.GetQuality(this.m_itemData),l.name))
const a=p.M.Replace(t.Cfg_get().consums.costs[0].subvalue,p.M.s_SPAN_CHAR,""),r=p.M.String2Int(a)
return this.m_price=1*r,this.skillBuyBtn.SetText((0,s.T)("购买")),this.skillPrice.node.SetActive(!0),
this.skillCostIcon.spriteNameSet(N.J.GetCurrencyIconUrl(t.Cfg_get().consums.costs[0].subtype)),
this.m_price>N.J.GetGold(n.Y.Inst.PrimaryRoleInfo_get(),N.J.GOLD_DIAMOND)?this.skillPrice.textSet(`[ff0000]${p.M.IntToString(this.m_price)}[-]`):this.skillPrice.textSet(p.M.IntToString(this.m_price)),
e>0&&(this.skillPrice.node.SetActive(!1),this.skillBuyBtn.SetText((0,s.T)("使用")),this.isUse=!0,this.lookLightAnim.SetActive(!0)),void this.skillGo.SetActive(!0)}}
this.skillGo.SetActive(!1),this.lookLightAnim.SetActive(!1),this.HideBuyAnim()}UpdateView(){const t=new C.Z,e=L.M.Inst_get().expMediceneIdArr
let i=0,s=0,l=0,a=null,o=null,r=null,h=null,d=null,c=null,_=null,u=!0,I=0
for(;I<e.count;)h=new J,u=!0,s=p.M.String2Int(e[I]),i=y.g.Inst_get().GetItemNum(s),o=y.g.Inst_get().getItemresource(s),d=new T.Y,c=new P.t,c.modelId=o.id,d.serverData_set(c),
d.serverData_get().num=i,d.baseData_get().isShowZeroNum=!0,d.baseData_get().isShowRecommendIcon=!1,d.baseData_get().isNoBagItemData=!0,d.baseData_get().tipsPos=new f.P(-200,0,0),
h.itemData=d,l=p.M.String2Int(o.Rewards_get().typevalues[0].value),_=E.j.Inst_get().model.GetBuffResById(l),h.buffRes=_,h.type=0,
a=E.j.Inst_get().model.IsHaveBuff(n.Y.Inst.PrimaryRoleInfo_get().Id_get(),l),h.buff=a,h.isFirst=0==I,null==a?0==i&&(h.type=1,r=this.GetOkMallData(s),h.mallData=r,
null==r&&(u=!1)):h.type=2,u&&t.Add(h),I+=1
this._Grid.data_set(t)}GetOkMallData(t){const e=M.N.GetInst().GetInfoListByItemId(t)
if(null==e)return null
let i=0
for(i=0;i<e.Count();){if(e[i].Cfg_get().labelId==b.g.WEEK_LIMITED&&e[i].Cfg_get().perBuyLimit-e[i].Lastnum_get()>0)return e[i]
i+=1}let s=0,l=""
for(i=0;i<e.Count();){if(l=p.M.Replace(e[i].Cfg_get().consums.costs[0].subvalue,p.M.s_SPAN_CHAR,""),s=p.M.String2Int(l),
e[i].Cfg_get().labelId==b.g.SCORE&&n.Y.Inst.PrimaryRoleInfo_get().Sonsign_Score_get()>=s)return e[i]
i+=1}for(i=0;i<e.Count();){if(e[i].Cfg_get().labelId!=b.g.SCORE&&e[i].Cfg_get().labelId!=b.g.WEEK_LIMITED)return e[i]
i+=1}for(i=0;i<e.Count();){if(e[i].Cfg_get().labelId==b.g.SCORE)return e[i]
i+=1}return null}HideBuyAnim(){this.buyAnim.node.SetActive(!1),this.buyBoomAnim.node.SetActive(!1),this.buyFlyAnim.node.SetActive(!1),this.buyLightAnim.node.SetActive(!1)}
HideUseAnim(){this.useAnim.node.SetActive(!1),this.useLightAnim.node.SetActive(!1)}Clear(){this.HideBuyAnim(),this.HideUseAnim(),L.M.Inst_get().buyMallId=0,
L.M.Inst_get().useExpItemId=0}RemoveLis(){a.i.Inst.RemoveEventHandler(v.g.BAG_UPDATE,this._degf_setData),a.i.Inst.RemoveEventHandler(v.g.SKILL_UPDATE,this._degf_UpdateSkillView),
a.i.Inst.RemoveEventHandler(v.g.COPYEXPPANEL_BUYSUCCESS_SKILL,this._degf_PlayBuyAnimHandler),
a.i.Inst.RemoveEventHandler(v.g.COPYEXPPANEL_USESUCCESS_ITEM,this._degf_PlayUseAnimHandler),this.RemoveClickEvent(this.btnclose,this._degf_closeHandler),
this.RemoveClickEvent(this.skillBuyBtn,this._degf_SkillBuyHandler),n.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(l.A.Gold_DiamondUpdate,this._degf_OnViewUpdate),
a.i.Inst.RemoveEventHandler(v.g.BAG_UPDATE,this._degf_OnViewUpdate),n.Y.Inst.PrimaryRoleInfo_get().RemoveEventHandler(l.A.Score_NumUpdate,this._degf_OnViewUpdate),
this.RemoveFullScreenCollider(this.FatherId)}PlayUseAnimHandler(t){this.useAnim.node.SetActive(!0),this.useAnim.SetResetOnPlay(!0),this.useAnim.Play(!0,!1),
this.useLightAnim.node.SetActive(!0),this.useLightAnim.SetResetOnPlay(!0),this.useLightAnim.Play(!0,!1)}PlayBuyAnimHandler(t){this.buyAnim.node.SetActive(!0),
this.buyAnim.SetResetOnPlay(!0),this.buyAnim.Play(!0,!1),this.buyBoomAnim.node.SetActive(!0),this.buyBoomAnim.SetResetOnPlay(!0),this.buyBoomAnim.Play(!0,!1),
this.buyFlyAnim.node.SetActive(!0),this.buyFlyAnim.ResetToBeginning(),this.buyFlyAnim.Play()}SkillBuyHandler(t,e){
if(null!=this.m_itemData)if(this.isUse)this.lookLightAnim.SetActive(!1),H.C.INSTANCE.curShowChildView=w.c.ProSkill,H.C.INSTANCE.pre_select_skillid=this.useSkillId,
G.B.inst.OpenSkillPanel()
else{if(this.m_price>N.J.GetGold(n.Y.Inst.PrimaryRoleInfo_get(),N.J.GOLD_DIAMOND))return void N.J.OpenSupplyCurrencyViewByType(N.J.GOLD_DIAMOND)
L.M.Inst_get().buyMallId=this.mallID,B.x.inst.ReqBuyMallItem(this.mallID,1)}}Destroy(){this._Grid.Destroy(),this.skillItem.Destroy(),this.RemoveLis(),this.btnclose=null,
this.scroll=null,this.skillGo=null,this.skillPrice=null,this.skillBuyBtn=null,this.skillItem=null,this.skillName=null,this.buyAnim=null,this.buyFlyAnim=null,this.buyBoomAnim=null,
this.buyLightAnim=null,this.useAnim=null,this.useLightAnim=null,this.lookLightAnim=null}}},65973:(t,e,i)=>{i.d(e,{U:()=>r})
var s=i(5924),n=i(93877),l=i(8889),a=i(61911),o=i(31222)
class r extends a.f{constructor(){super(),this.timer=null,this.alpha=null,this._degf_OnCallLater=null,this._degf_OnCallLater=()=>this.OnCallLater()}InitView(){super.InitView(),
this.timer=new n.Q,this.timer.setId(this.FatherId,this.FatherComponentID,1),this.alpha=new l.$,this.alpha.setId(this.FatherId,this.FatherComponentID,2)}OnAddToScene(){
this.alpha.SetAlpha(1),this.addLis(),s.C.Inst_get().SetInterval(this._degf_OnCallLater,3e3,1)}OnCallLater(){o.N.inst.ClosePanel()}addLis(){}removeLis(){}Clear(){this.removeLis()}
Destroy(){}}},58097:(t,e,i)=>{var s,n=i(6847),l=i(83908),a=i(46282),o=i(97461),r=i(5924),h=i(5494),d=i(92679),c=i(29839),_=i(44210);(0,
n.s_)(h.I.CopyBloodTownLeftTimePanel,a.Z.ui_copybase_bloodtown_lefttime).register()(s=class extends((0,l.Ri)()){constructor(...t){super(...t),this.tweenId=null}InitView(){
super.InitView()}OnAddToScene(){this.alpha.opacity=.51,this.banner.node.SetActive(!1),this.bannerBg.SetActive(!1),this.bannerEff.node.SetActive(!1),this.addLis(),
this.UpdateStage(),c.p.inst.curstage==_.w.STAGE_NUM-1?this.bannerTxt.SetActive(!0):this.bannerTxt.SetActive(!1)}addLis(){
o.i.Inst.AddEventHandler(d.g.COPY_STAGE_UPDATE,this.CreateDelegate(this.UpdateStage)),o.i.Inst.AddEventHandler(d.g.COPY_STAGE_UPDATE_REAL,this.CreateDelegate(this.ChangeStage))}
removeLis(){o.i.Inst.RemoveEventHandler(d.g.COPY_STAGE_UPDATE,this.CreateDelegate(this.UpdateStage)),
o.i.Inst.RemoveEventHandler(d.g.COPY_STAGE_UPDATE_REAL,this.CreateDelegate(this.ChangeStage))}ChangeStage(){c.p.inst.curstage==_.w.STAGE_NUM-1?(this.bannerEff.node.SetActive(!0),
this.bannerEff.play(),
this.bannerBg.SetActive(!0),this.tweenId=r.C.Inst_get().SetInterval(this.CreateDelegate(this.TweenEnd),1500,1)):c.p.inst.curstage==_.w.STAGE_NUM&&(this.bannerTxt.SetActive(!1),
this.banner.node.SetActive(!1))}TweenPlay(){this.bannerBg.SetActive(!1)}ClearTween(){null!=this.tweenId&&(r.C.Inst_get().ClearInterval(this.tweenId),this.tweenId=null)}TweenEnd(){
this.banner.node.SetActive(!1),this.bannerTxt.SetActive(!0)}Clear(){this.removeLis(),this.ClearTween()}UpdateStage(){
_.w.GetInst().IsInAddExTimeStage()?(this.leftTimeObj.SetActive(!1),this.endTimeObj.SetActive(!0)):(this.leftTimeObj.SetActive(!0),this.endTimeObj.SetActive(!1))}SetCopyTimer(t){
this.time.textSet(t),this.alpha.opacity=""!=t?255:.51}Destroy(){}})},85001:(t,e,i)=>{
var s,n=i(6847),l=i(83908),a=i(49655),o=i(46282),r=i(85602),h=i(63076),d=i(75696),c=i(85770),_=i(96713);(0,
n.s_)(a.o.CopyGain,o.Z.ui_copybase_gainview).register()(s=class extends((0,l.Ri)()){InitView(){super.InitView(),this.grid.SetInitInfo("ui_baseitem",null,d.j)}OnAddToScene(){
this.AddLis(),this.RefreshReward()}RefreshReward(){const t=new r.Z
if(null!=c.a.Inst_get().gainItemLis)for(let e=0;e<=c.a.Inst_get().gainItemLis.Count()-1;e++){const i=c.a.Inst_get().gainItemLis[e]
if(i&&i.modelId){const e=new h.M(i.modelId)
e.serverData_set(i),e.isShowAccess=!1,t.Add(e)}}this.hasReward.SetActive(!1),this.noReward.SetActive(!1),null!=t&&t.Count()>0?(this.hasReward.SetActive(!0),
this.grid.data_set(t)):this.noReward.SetActive(!0)}AddLis(){this.AddClickEvent(this.closeBtn,this.CreateDelegate(this.OnCloseBtn)),
this.AddClickEvent(this.closeBtn2,this.CreateDelegate(this.OnCloseBtn))}RemoveLis(){this.RemoveClickEvent(this.closeBtn,this.CreateDelegate(this.OnCloseBtn)),
this.RemoveClickEvent(this.closeBtn2,this.CreateDelegate(this.OnCloseBtn))}OnCloseBtn(){_.n.inst.CloseCopyGainView()}Clear(){this.RemoveLis(),this.grid.Clear()}Destroy(){}})},
98673:(t,e,i)=>{
var s,n=i(6847),l=i(83908),a=i(46282),o=i(93984),r=i(38836),h=i(86133),d=i(98800),c=i(5494),_=i(31222),u=i(55360),I=i(98885),m=i(85602),g=i(38962),p=i(59625),C=i(92984),S=i(85751),f=i(29839),T=i(85770),y=i(72800),A=i(86209),D=i(34565),E=i(17409),v=i(73865),w=i(24524),R=i(33828),P=i(19519),O=i(19276),L=i(20193)
;(0,n.s_)(c.I.CopyInspire,a.Z.ui_copybaseui_inspirepanel).register()(s=class extends((0,l.pA)(D.I)()){constructor(...t){super(...t),this.showTipArr=null,this.inspireMsg=null,
this.index=0,this._degf_CurrenceyUpdate=null,this._degf_DiamondInspireHandle=null,this._degf_GoldInspireHandle=null,this._degf_NoHandler=null,this._degf_closeHandler=null,
this.bossId=null,this.goldcurrency=null,this.coinCostcurrency=null,this.goldCostContainer=null,this.diamondCostContainer=null,this.copyId=null,this.res=null}_initBinder(){
super._initBinder(),this._degf_CurrenceyUpdate=t=>this.CurrenceyUpdate(t),this._degf_DiamondInspireHandle=(t,e)=>this.DiamondInspireHandle(t,e),
this._degf_GoldInspireHandle=(t,e)=>this.GoldInspireHandle(t,e),this._degf_NoHandler=(t,e)=>this.NoHandler(t,e),this._degf_closeHandler=(t,e)=>this.closeHandler(t,e),
this.bossId=L.D.Inst_get().bossId}InitView(){super.InitView(),this.showTipArr=new m.Z,this.showTipArr.Add(this.addone)}OnAddToScene(){if(this.copyId=T.a.Inst_get().currentCopyId,
this.bossId=L.D.Inst_get().bossId,null==this.bossId&&(this.bossId=p.o.Inst_get().objId),this.copyId>0)this.res=w.o.Inst().getItemById(this.copyId)
else{const t=u.Y.Inst.GetOrCreateCsv(o.h.eBossencourageResource).GetCsvMap(),e=d.Y.Inst.getBossById(this.bossId)
null!=e&&null!=e.Cfg_get()&&(this.res=t.LuaDic_GetItem(e.Cfg_get().id),0==this.res.encourageGoldCost&&(this.goldinspire.SetActive(!1),this.goldCostContainer.SetActive(!1),
this.diamondinspire.node.SetLocalPositionXYZ(0,-70,0),this.diamondCostContainer.SetLocalPositionXYZ(0,-114,0)))}if(this.inspireMsg=new g.X,this.index=-1,null!=this.showTipArr){
let t=0
for(;t<this.showTipArr.Count();)this.showTipArr[t].textSet(""),t+=1}this.showTipArr[0].textSet((0,h.T)("[de2524]尚未鼓舞[-]")),this.InitExtraLabel(),this.setCount(),this.removeLis(),
this.addLis(),this.ShowCopyIconAndName()}ShowCopyIconAndName(){
if(null!=this.res&&null!=this.coin&&null!=this.gold)if(this.copyId>0)if(this.copyIcon.spriteNameSet(T.a.Inst_get().GetCopyIconByType(),"huodongicon2"),
this.res.controllerType==y.S.WORLDBOSS){const t=O.C.Inst().GetBossesByCopy(this.copyId)
this.copyName.textSet(t[0].name_get())}else if(this.res.controllerType==y.S.WORLDBOSS_NEW){const t=O.C.Inst().GetItemByMonsterId(d.Y.Inst.bossId)
t&&this.copyName.textSet(t.name_get())}else this.copyName.textSet(this.res.name)
else{this.copyIcon.spriteNameSet("ryhongdongicon2_sp_0017","huodongicon2")
const t=d.Y.Inst.getBossById(this.bossId)
null!=t&&null!=t.Cfg_get()&&this.copyName.textSet(t.Cfg_get().name)}}setCount(){if(null==this.res)return
if(null==this.coin)return
if(null==this.gold)return
null!=T.a.Inst_get().encourageTypeTimes&&this.ShowInspireTime(T.a.Inst_get().encourageTypeTimes)
const t=T.a.Inst_get().multiple
let e=!1
this.copyId>0&&(e=this.res.controllerType==y.S.WORLDBOSS&&t>1)
const i=A.w.Instance.ConvertNumToString(this.res.encourageGoldCost)
d.Y.Inst.PrimaryRoleInfo_get().Gold_get()<this.res.encourageGoldCost?this.coin.SetColor(S.u.RedColor):this.coin.SetColor(S.u.WhiteColor),
e?this.coin.textSet(`${i} x${t}`):this.coin.textSet(i)
let s=""
P.J.GetGold(d.Y.Inst.PrimaryRoleInfo_get(),P.J.GOLD_DIAMOND)<this.res.encourageDiamondCost?this.gold.SetColor(S.u.RedColor):this.gold.SetColor(S.u.WhiteColor),
s=e?`${this.res.encourageDiamondCost} x${t}`:this.res.encourageDiamondCost,this.gold.textSet(s)}InitExtraLabel(){let t=null
if(0!=T.a.Inst_get().currentCopyId){if(null==T.a.Inst_get().encourageMap)return
t=T.a.Inst_get().encourageMap}else{if(null==L.D.Inst_get().encourageMap)return
t=L.D.Inst_get().encourageMap}const e=T.a.Inst_get().inspireShow
let i=0,s=""
for(const[n,l]of(0,r.vy)(t))e.LuaDic_ContainsKey(n)&&(i=t[n],200203==n?s+=e[n]+500*i:(i*=10,
s+=100==i?`${e[n]}${i}%${I.M.s_LEFT_S_K_CHAR}MAX${I.M.s_RIGHT_S_K_CHAR}\n`:`${e[n]}${i}%\n`))
""!=s&&this.showTipArr[0].textSet(s)}addLis(){null!=this.goldinspire&&this.AddClickEvent(this.goldinspire.node,this._degf_GoldInspireHandle),
null!=this.diamondinspire&&this.AddClickEvent(this.diamondinspire.node,this._degf_DiamondInspireHandle),this.AddClickEvent(this.CloseBtn.node,this._degf_closeHandler),(0,
E.D1)(this,this._degf_NoHandler),d.Y.Inst.PrimaryRoleInfo_get().addCurrenceyLis(this._degf_CurrenceyUpdate),this.RegGuide()}NoHandler(t,e){}CurrenceyUpdate(t){this.setCount()}
RegGuide(){}closeHandler(t,e){_.N.inst.ClosePanel(c.I.CopyInspire)}ShowInspireMsg(t,e){const i=10*e,s=(C.j.Inst_get().model.GetBuffResById(t),
T.a.Inst_get().inspireShow),n=T.a.Inst_get().inspireValShow
if(n.LuaDic_AddOrSetItem(t,i),this.inspireMsg.LuaDic_ContainsKey(t))s.LuaDic_ContainsKey(t)&&(200203==t?this.showTipArr[this.inspireMsg[t]].textSet(s[t]+500*e):100==i?this.showTipArr[this.inspireMsg[t]].textSet(`${s[t]}${i}%${I.M.s_LEFT_S_K_CHAR}MAX${I.M.s_RIGHT_S_K_CHAR}`):this.showTipArr[this.inspireMsg[t]].textSet(`${s[t]}${i}%`))
else{if(this.index+=1,null==this.showTipArr)return
this.inspireMsg.LuaDic_AddOrSetItem(t,this.index),s.LuaDic_ContainsKey(t)&&(200203==t?this.showTipArr[this.inspireMsg[t]].textSet(s[t]+500*e):this.showTipArr[this.index].textSet(`${s[t]}${i}%`))
}let l=""
if(null!=n){let t=0
for(const[e,i]of(0,r.V5)(n))t+=i
l=`+${t}%`}const a=v.y.Inst.GetInspireBtnView()
null!=a&&a.showText(l)}ShowInspireTime(t){}DiamondInspireHandle(t,e){if(null==this.res)return
if(null==this.coin)return
if(null==this.gold)return
this.res.encourageDiamondCost>P.J.GetGold(d.Y.Inst.PrimaryRoleInfo_get(),P.J.GOLD_DIAMOND)?R.Y.Inst_get().Open():this.copyId>0?f.p.inst.CM_CopyEncourage(this.copyId,2):null!=this.bossId&&(T.a.Inst_get().encourageBossId=this.bossId,
f.p.inst.CM_BossEncourage(this.bossId,2))}GoldInspireHandle(t,e){this.copyId>0?f.p.inst.CM_CopyEncourage(this.copyId,1):null!=this.bossId&&f.p.inst.CM_BossEncourage(this.bossId,1)}
InspireCount(){let t=0
if(null!=T.a.Inst_get().encourageTypeTimes)for(const[e,i]of(0,r.V5)(T.a.Inst_get().encourageTypeTimes))t+=i
return t}removeLis(){null!=this.goldinspire&&this.RemoveClickEvent(this.goldinspire.node,this._degf_GoldInspireHandle),
null!=this.diamondinspire&&this.RemoveClickEvent(this.diamondinspire.node,this._degf_DiamondInspireHandle),
d.Y.Inst.PrimaryRoleInfo_get().removeCurrencyLis(this._degf_CurrenceyUpdate),this.RemoveClickEvent(this.CloseBtn.node,this._degf_closeHandler),(0,E.Rt)(this),this.UnRegGuide()}
UnRegGuide(){}PlaySuccessAnim(){this.HideAnim(1),this.successAnim.SetActive(!0),this.successAnim2.SetActive(!0),this.successLightAnim.SetActive(!0),
this.sucIconLightAnim.SetActive(!0)}PlayDefeatAnim(){this.HideAnim(2),this.defeatAnim.node.SetActive(!0),this.defeatLightAnim.SetActive(!0),this.defeatIconLightAnim.SetActive(!0)}
HideAnim(t){null==t&&(t=3),2!=t&&3!=t||(this.successAnim.SetActive(!1),this.successAnim2.SetActive(!1),this.successLightAnim.SetActive(!1),this.sucIconLightAnim.SetActive(!1)),
1!=t&&3!=t||(this.defeatAnim.node.SetActive(!1),this.defeatLightAnim.SetActive(!1),this.defeatIconLightAnim.SetActive(!1))}Clear(){this.removeLis(),this.HideAnim(),super.Clear()}
Destroy(){}})},89145:(t,e,i)=>{i.d(e,{W:()=>d})
var s=i(68662),n=i(5924),l=i(93877),a=i(61911),o=i(87923),r=i(85770),h=i(24524)
class d extends a.f{constructor(){super(),this.timer=null,this.animTime=0,this.totalTime=0,this.serverTime=0,this.residueTimer=0,this._degf_AnimTimer=null,
this._degf_AnimTimer=()=>this.AnimTimer()}InitView(){super.InitView(),this.animTime=-1,this.timer=new l.Q,this.timer.setId(this.FatherId,this.FatherComponentID,1),
this.SetCopyTimer(r.a.Inst_get().currentCopyId)}OnAddToScene(){this.addLis()}addLis(){}removeLis(){}Clear(){this.removeLis(),this.ClearAnim()}SetCopyTimer(t){this.ClearAnim()
const e=h.o.Inst().getItemById(t)
if(null==e||null==this.timer)return
const i=r.a.Inst_get().copyEnterTimer
if(this.totalTime=1e3*e.overTime,!i.LuaDic_ContainsKey(e.controllerType))return
this.serverTime=i[e.controllerType]
const l=s.D.serverMSTime_get()-this.serverTime
l>this.totalTime||(this.residueTimer=this.totalTime-l,this.node.SetActive(!0),this.timer.textSet(o.l.GetDateFormatEXX(this.residueTimer)),
-1==this.animTime&&(this.animTime=n.C.Inst_get().SetInterval(this._degf_AnimTimer,200)))}ClearAnim(){n.C.Inst_get().ClearInterval(this.animTime),this.animTime=-1,this.totalTime=0,
this.serverTime=0,this.residueTimer=0}AnimTimer(){const t=s.D.serverMSTime_get()-this.serverTime
this.residueTimer=this.totalTime-t,t>this.totalTime&&(this.residueTimer=0,this.ClearAnim()),this.timer.textSet(o.l.GetDateFormatEXX(this.residueTimer))}Destroy(){}}},
63683:(t,e,i)=>{i.d(e,{N:()=>m})
var s=i(5924),n=i(99294),l=i(9986),a=i(6665),o=i(93877),r=i(61911),h=i(75696),d=i(92679),c=i(29839),_=i(85770),u=i(24524),I=i(96713)
class m extends r.f{constructor(...t){super(...t),this.sweepTimes=0,this.isFinish=!1,this.closeBtn=null,this.confirmBtn=null,this.cancelBtn=null,this.topLabel=null,this.grid=null,
this.sweepWidget=null,this.rewardLabelFinish=null,this.plusBtn=null,this.minusBtn=null,this.countLabel=null,this.confirmbtnFinish=null,this.gridFinish=null,
this.toplabelFinish=null,this.midLabelFinish=null,this.finishWidget=null,this.copySweepVo=null,this.copyRes=null,this.exitimer=null}InitView(){super.InitView(),
this.closeBtn=this.CreateComponent(l.W,1),this.confirmBtn=this.CreateComponent(l.W,2),this.cancelBtn=this.CreateComponent(l.W,3),this.topLabel=this.CreateComponent(o.Q,4),
this.grid=this.CreateComponent(a.A,5),this.sweepWidget=this.CreateComponent(n.z,8),this.rewardLabelFinish=this.CreateComponent(o.Q,9),this.plusBtn=this.CreateComponent(l.W,10),
this.minusBtn=this.CreateComponent(l.W,11),this.countLabel=this.CreateComponent(o.Q,12),this.confirmbtnFinish=this.CreateComponent(l.W,13),
this.gridFinish=this.CreateComponent(a.A,14),this.toplabelFinish=this.CreateComponent(o.Q,15),this.midLabelFinish=this.CreateComponent(o.Q,16),
this.finishWidget=this.CreateComponent(n.z,17),this.grid.SetInitInfo("ui_baseitem",null,h.j),this.gridFinish.SetInitInfo("ui_baseitem",null,h.j)}OnAddToScene(){
this.copySweepVo=_.a.Inst_get().copySweepVo,this.m_handlerMgr.AddClickEvent(this.confirmBtn,this.CreateDelegate(this._OnRequestSweep)),
this.m_handlerMgr.AddClickEvent(this.plusBtn,this.CreateDelegate(this._OnPlusClick)),this.m_handlerMgr.AddClickEvent(this.minusBtn,this.CreateDelegate(this._OnMinusClick)),
this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this._OnCloseClick)),this.m_handlerMgr.AddClickEvent(this.cancelBtn,this.CreateDelegate(this._OnCloseClick)),
this.m_handlerMgr.AddClickEvent(this.confirmbtnFinish,this.CreateDelegate(this._OnCloseClick)),
this.m_handlerMgr.AddEventMgr(d.g.COPYSWEEP_SUCCESS,this.CreateDelegate(this._OnSweepSuccess)),this.UpdateView()}UpdateView(){this.sweepWidget.SetActive(!0),
this.finishWidget.SetActive(!1),this.copyRes=u.o.Inst().getItemById(this.copySweepVo.copyId),this.topLabel.textSet(`${this.copySweepVo.stageName}扫荡奖励`),
this.sweepTimes=this.copySweepVo.showLeftNum,this.countLabel.textSet(this.sweepTimes),this.UpdateReward()}_OnRequestSweep(){
this.sweepTimes>0&&c.p.inst.CM_CopySweep(this.copySweepVo.copyId,this.sweepTimes)}_OnPlusClick(){this.sweepTimes<this.copySweepVo.showLeftNum?(this.sweepTimes+=1,
this.countLabel.textSet(this.sweepTimes),this.UpdateReward()):this.copySweepVo.addTimesFunc&&this.copySweepVo.addTimesFunc()}_OnMinusClick(){this.sweepTimes>1&&(this.sweepTimes-=1,
this.countLabel.textSet(this.sweepTimes),this.UpdateReward())}_OnCloseClick(){I.n.inst.CloseCopySweepView()}_OnSweepSuccess(){this.isFinish=!0,this.sweepWidget.SetActive(!1),
this.finishWidget.SetActive(!0),this.toplabelFinish.textSet(`扫荡关卡:${this.copySweepVo.stageName}`),this.midLabelFinish.textSet(`扫荡次数:${this.sweepTimes}次`),
this.gridFinish.data_set(this.copySweepVo.showRewardList)}UpdateReward(){let t=0
for(;t<this.copySweepVo.showRewardList.Count();){const e=this.copySweepVo.showRewardList[t].count
e>0&&(this.copySweepVo.showRewardList[t].SpecialNumStr=e*this.sweepTimes),t+=1}this.grid.data_set(this.copySweepVo.showRewardList)}Clear(){
s.C.Inst_get().ClearInterval(this.exitimer),this.exitimer=-1,super.Clear()}Destroy(){this.grid.Destroy(),this.gridFinish.Destroy(),this.closeBtn=null,this.confirmBtn=null,
this.cancelBtn=null,this.topLabel=null,this.grid=null,this.sweepWidget=null,this.rewardLabelFinish=null,this.plusBtn=null,this.minusBtn=null,this.countLabel=null,
this.confirmbtnFinish=null,this.gridFinish=null,this.toplabelFinish=null,this.midLabelFinish=null,this.finishWidget=null,super.Destroy()}}},37927:(t,e,i)=>{i.d(e,{i:()=>s})
class s{}s.BelielTab=0,s.BloodTownTab=1,s.LoseTab=2,s.BraveTab=4,s.DreamlandTab=5},57991:(t,e,i)=>{i.d(e,{P:()=>r})
var s=i(17409),n=i(56937),l=i(18202),a=i(31222),o=i(5494)
class r{constructor(){this.view=null,this._degf_CallTableDestory=null,this._degf_OnTableLoadComplte=null,this._degf_CallTableDestory=()=>this.OnViewDestroy(),
this._degf_OnTableLoadComplte=t=>this.OnViewLoadComplete(t)}static Inst_get(){return null==r._inst&&(r._inst=new r),r._inst}OpenTablePanel(){const t=new n.v
t.isShowMask=!0,t.isDefaultUITween=!0,(0,s.Yp)(o.I.VitalityCalendarTablePanel,t)}OnViewLoadComplete(t){}OnViewDestroy(){l.g.DestroyUIObj(this.view),this.view=null}HideClickTip(){
null!=this.view&&this.view.ClearClickTip()}CloseTablePanel(){a.N.inst.CloseById(o.I.VitalityCalendarTablePanel)}}r._inst=null},82550:(t,e,i)=>{i.d(e,{P:()=>c})
var s=i(17409),n=i(97461),l=i(56937),a=i(18202),o=i(31222),r=i(5494),h=i(92679),d=i(61265)
class c{constructor(){this.view=null,this.defaultTabIdx=null,this._degf_OnDestroyHandler=null,this._degf_OnViewLoadComplete=null}static Inst_get(){
return null==c._Inst&&(c._Inst=new c),c._Inst}Open(t){if(this.defaultTabIdx=t,null==this.view){const t=new l.v
t.isShowMask=!0,t.isDefaultUITween=!0,t.viewClass=d.$,(0,s.Yp)(r.I.BecomeStrongerMainView,t)}}CloseView(t){null==t&&(t=!0),t||n.i.Inst.RaiseEvent(h.g.STRENGTHEN_PANEL_CLOSE),
o.N.inst.CloseById(r.I.BecomeStrongerMainView)}OnDestroyHandler(t){a.g.DestroyUIObj(this.view),this.view=null}}c._Inst=null},90034:(t,e,i)=>{i.d(e,{s:()=>M})
var s,n,l,a,o,r,h,d=i(42292),c=i(71409),_=i(17409),u=i(38836),I=i(86133),m=i(97461),g=i(38935),p=i(56937),C=i(31222),S=i(5494),f=i(52726),T=i(52212),y=i(93353),A=i(92679),D=i(37648),E=i(55492),v=i(60495),w=i(92415),R=i(22662),P=i(14792),O=i(62734),L=i(65550),B=i(27001)
function b(t,e,i,s,n){var l={}
return Object.keys(s).forEach((function(t){l[t]=s[t]})),l.enumerable=!!l.enumerable,l.configurable=!!l.configurable,("value"in l||l.initializer)&&(l.writable=!0),
l=i.slice().reverse().reduce((function(i,s){return s(t,e,i)||i}),l),n&&void 0!==l.initializer&&(l.value=l.initializer?l.initializer.call(n):void 0,l.initializer=void 0),
void 0===l.initializer&&(Object.defineProperty(t,e,l),l=null),l}let M=(s=(0,c.GH)(w.k.SM_VitalityUpdate),n=(0,c.GH)(w.k.SM_SingleVitalityReward),l=(0,
c.GH)(w.k.SM_HonorManualTodayPoint),a=(0,c.GH)(w.k.SM_ShowVitality),o=(0,c.GH)(w.k.SM_RewardInfo),h=class t{constructor(){this.DailyView=null,this.DailyTaskTips=null,
this.DailyGetAwawdView=null,this._degf_SM_VitalityUpdateHandle=null,this._degf_SM_ShowVitalityHandle=null,this._degf_SM_SingleVitalityReward=null,
this._degf_SM_HonorManualTodayPoint=null,this._degf_SM_RewardInfoHandle=null,this._degf_OnDestroyTaskInfoView=null,
this._degf_SM_VitalityUpdateHandle=t=>this.SM_VitalityUpdateHandle(t),this._degf_SM_ShowVitalityHandle=t=>this.SM_ShowVitalityHandle(t),
this._degf_SM_SingleVitalityReward=t=>this.SM_SingleVitalityReward(t),this._degf_SM_HonorManualTodayPoint=t=>this.SM_HonorManualTodayPointHandle(t),
this._degf_SM_RewardInfoHandle=t=>this.SM_RewardInfoHandle(t),this._degf_OnDestroyTaskInfoView=t=>this.OnDestroyTaskInfoView(),this.RegisterProtocol()}static Inst_get(){
return null==t._Inst&&(t._Inst=new t),t._Inst}Open(t,e=null,i=null){if(D.P.Inst_get().IsFunctionOpened(E.x.ARENA)&&y.g.Inst_get().SendArenaOpenPanel(),
B.q.GetInst().FatherDefaultTab=t,B.q.GetInst().DailyTaskDefaultTab=e,null!=i&&(B.q.GetInst().targetId=i),
null!=this.DailyView&&this.DailyView.isShow_get())this.DailyView.UpdatePanel()
else{const t=new p.v
t.isShowMask=!0,t.isDefaultUITween=!0,(0,_.Yp)(S.I.RYDailyPanel,t)}}ShowDailyTaskInfoView(t,e,i){i=i||T.F.zero_get()
const s=(0,_.Y)(S.I.DailyTaskInfo)
if(null==s){const s=new p.v
s.isShowMask=!1,s.isDefaultUITween=!1,s.layerType=f.F.Tip,B.q._inst.setCalenderInfo(t,e,i),(0,_.Yp)(S.I.DailyTaskInfo,s)}else s.node.SetLocalPositionXYZ(i.x,i.y,0),s.SetData(e,t)}
OpenAwawrdView(){if(null!=this.DailyGetAwawdView)this.DailyGetAwawdView.OnAddToScene()
else{const t=new p.v
t.isShowMask=!0,(0,_.Yp)(S.I.RYDailyGetAwardView,t)}}CloseGetAwardView(){(0,_.sR)(S.I.RYDailyGetAwardView)}CM_VitalityReceiveRewardHandle(t){const e=new v.D
e.vitalityRewardId=t,g.C.Inst.F_SendMsg(e)}SM_VitalityUpdateHandle(t){const e=t.vo,i=B.q.GetInst().GetDailyTaskDataById(e.id)
null!=i&&(i.remainTimes=t.vo.remainTimes,i.inReward=t.vo.inReward,i.otherParam=t.vo.otherParam,i.CanRewardTimes=t.vo.CanRewardTimes,m.i.Inst.RaiseEvent(A.g.DAILY_UPDATAITEM,e.id)),
this.UpdateRedPoint(!0)}SM_SingleVitalityReward(t){if(null==t||0==t.vitalityId)return
t.vitalityId}SM_HonorManualTodayPointHandle(t){const e=t
e&&B.q.GetInst().UpdateReceiveVitalityNum(e.honorManualPointToday)}SM_ShowVitalityHandle(t){const e=t
B.q.GetInst().AddReceiveDailyData(e.vos),B.q.GetInst().AddReceiveActiveReward(e.cfgIds,e.rewards),this.UpdateRedPoint()}SM_RewardInfoHandle(t){const e=t
if(!e.success)return void L.y.inst.ClientStrMsg(R.r.SystemTipMessage,(0,I.T)("奖励领取失败"))
B.q.GetInst().GetRewardDataById(e.rewardId).received=e.success,m.i.Inst.RaiseEvent(A.g.ReciveVitalityActivityReward,e.rewardId),
B.q.GetInst().UpdateReceiveVitalityNum(B.q.GetInst().GetTotalVitalityNum(),!1)}RegisterProtocol(){}UpdateRedPoint(t){null==t&&(t=!1)
let e=!1,i=!1
const s=B.q.GetInst().GetDailyTaskDataList()
for(const[n,l]of(0,u.V5)(s))l.inReward>0&&(l.cfgData&&1==l.cfgData.activityType&&(e=!0),l.cfgData&&2==l.cfgData.activityType&&(i=!0)),
l.isInRedPointLevel()&&!t&&l.remainTimes>0&&l.cfgData&&1==l.cfgData.activityType&&(e=!0)
O.f.Inst.SetState(P.t.DAILY_Task_Item,e),O.f.Inst.SetState(P.t.DAILY_TimeTask_Item,i)}ClearDailyViewData(){C.N.inst.CloseById(S.I.DailyTaskInfo)}DestroyDailyView(){
C.N.inst.CloseById(S.I.DailyTaskInfo)}DestroyGetAwawdView(){C.N.inst.CloseById(S.I.DailyTaskInfo)}CloseDailyPanel(){C.N.inst.CloseById(S.I.RYDailyPanel)}},h._Inst=null,
b(r=h,"Inst_get",[d.n],Object.getOwnPropertyDescriptor(r,"Inst_get"),r),
b(r.prototype,"SM_VitalityUpdateHandle",[s],Object.getOwnPropertyDescriptor(r.prototype,"SM_VitalityUpdateHandle"),r.prototype),
b(r.prototype,"SM_SingleVitalityReward",[n],Object.getOwnPropertyDescriptor(r.prototype,"SM_SingleVitalityReward"),r.prototype),
b(r.prototype,"SM_HonorManualTodayPointHandle",[l],Object.getOwnPropertyDescriptor(r.prototype,"SM_HonorManualTodayPointHandle"),r.prototype),
b(r.prototype,"SM_ShowVitalityHandle",[a],Object.getOwnPropertyDescriptor(r.prototype,"SM_ShowVitalityHandle"),r.prototype),
b(r.prototype,"SM_RewardInfoHandle",[o],Object.getOwnPropertyDescriptor(r.prototype,"SM_RewardInfoHandle"),r.prototype),r)},80740:(t,e,i)=>{i.d(e,{F:()=>s})
class s{}s.DailyTask=0,s.ArenaCopy=1,s.DailyCopy=2,s.Exorcism=3,s.Recover=4},77038:(t,e,i)=>{i.d(e,{X:()=>s})
class s{}s.ERROR=0,s.RECEIVED=1,s.UNRECEIVE=2,s.RECEIVE=3},10429:(t,e,i)=>{i.d(e,{W:()=>s})
class s{}s.Daily=0,s.TimeTask=1,s.Challenge=2,s.ArenaCopy=0,s.LostAbyss=0,s.Recover=0,s.Exorcism=0},9773:(t,e,i)=>{i.d(e,{c:()=>s})
class s{}s.Daily_COMPLETE=1,s.Daily_UN_OPEN=2,s.Daily_OPEN_CanNotDo=3,s.Daily_OPEN_CanNotBuyDoHaveVital=4,s.Daily_OPEN_CanBuyDoNoVital=5,s.Daily_OPEN_CanBuyDo=6,
s.Daily_OPEN_CanDoNoVital=7,s.Daily_OPEN_CanDo=8,s.Daily_CANGET=9,s.Time_Un_Open=1,s.Time_Open_CanNotDoToday=2,s.Time_Open_FinshDoToday=3,s.Time_Open_CanDoToday=4,
s.Time_Open_DoingToday=5},70371:(t,e,i)=>{i.d(e,{W:()=>s})
class s{}s.ERROR=0,s.DATE_NOT_ENOUGH=1,s.LEVEL_NOT_ENOUGH=2,s.JOB_NOT_ENOUGH=3,s.NOT_BEGIN=4,s.FIVE_MINUTES_LATER_BEGIN=5,s.BEGIN=6,s.FIVE_MINUTES_LATER_END=7,s.END=8,
s.ENROLLING=9,s.NOT_BEGIN_ENROLL=10,s.ENROLLED=11},72652:(t,e,i)=>{i.d(e,{X:()=>s})
class s{}s.EQUIP=3,s.EXP=2,s.MONEY=1},27001:(t,e,i)=>{i.d(e,{q:()=>v})
var s=i(38836),n=i(86133),l=i(98800),a=i(97461),o=i(16812),r=i(66788),h=i(85602),d=i(38962),c=i(92679),_=i(87923),u=i(2457),I=i(5188),m=i(38693),g=i(14792),p=i(62734),C=i(17783),S=i(98580),f=i(85890),T=i(80740),y=i(77038),A=i(10429)
class D{constructor(){this.cfgData=null,this.received=!1}GetState(){
return this.received?y.X.RECEIVED:v.GetInst().GetTotalVitalityNum()>=this.cfgData.vitality?y.X.RECEIVE:y.X.UNRECEIVE}}var E=i(83010)
class v extends o.k{constructor(){super(),this.dailyTaskDataDict=null,this.dailyActiveRewardDataDict=null,this.totalVitalityNum=0,this.FatherCurTab=T.F.DailyTask,
this.FatherDefaultTab=T.F.DailyTask,this.DailyTaskCurTab=A.W.Daily,this.DailyTaskDefaultTab=A.W.Daily,this.targetId=-1,this.calenderInfo=null,this.type=null,this.pos=null,
this.dailyTaskDataDict=new d.X,this.dailyActiveRewardDataDict=new d.X}static GetInst(){return null==v._inst&&(v._inst=new v),v._inst}GetDailyTaskDataByType(t){
const e=new h.Z,i=this.dailyTaskDataDict.LuaDic_Values()
for(const[n,a]of(0,s.V5)(i)){if(null==a.cfgData)break
if(a.cfgData.activityType==t)if(_.l.IsEmptyStr(a.cfgData.showLevel))e.Add(a)
else{const t=l.Y.Inst.PrimaryRoleInfo_get().Level_get()
t>=a.cfgData.minShowLevel&&t<=a.cfgData.maxShowLevel&&e.Add(a)}}return e}GetDailyTaskDataList(){return this.dailyTaskDataDict.LuaDic_Values()}GetDailyTaskDataById(t){let e=null
return e=this.dailyTaskDataDict.LuaDic_GetItem(t),null!=e?e:(r.Y.LogError((0,n.T)("找不到活跃度数据：找后端")+t),null)}GetTotalVitalityNum(){return this.totalVitalityNum}GetCalenderInfo(){
return this.calenderInfo}GetType(){return this.type}GetPos(){return this.pos}setCalenderInfo(t,e,i){this.calenderInfo=t,this.type=e,this.pos=i}AddReceiveDailyData(t){
this.dailyTaskDataDict.LuaDic_Clear()
for(const[e,i]of(0,s.V5)(t)){const t=new E.x
t.cfgData=m.O.GetInst().GetCfgById(i.id),null==t.cfgData&&r.Y.LogError(`VITALITYRESOURCE id没有配置  ${i.id}`),t.otherParam=i.otherParam,t.remainTimes=i.remainTimes,
t.inReward=i.inReward,t.CanRewardTimes=i.CanRewardTimes,this.dailyTaskDataDict.LuaDic_Add(i.id,t)}}AddReceiveActiveReward(t,e){const i=I.Q.Inst().getAllItemByIds(t)
if(null!=i){this.dailyActiveRewardDataDict.LuaDic_Clear()
for(const[t,n]of(0,s.V5)(i)){const t=new D
t.cfgData=n,t.received=e.Contains(n.id),this.dailyActiveRewardDataDict.LuaDic_Add(n.id,t)}}}GetRewardList(){const t=this.dailyActiveRewardDataDict.LuaDic_Values()
return t.Sort(v.sort),t}static sort(t,e){return t.cfgData.id-e.cfgData.id}GetRewardDataById(t){return this.dailyActiveRewardDataDict.LuaDic_GetItem(t)}
HasVitalityRewardByVitality(t){for(const[e,i]of(0,s.V5)(this.dailyActiveRewardDataDict))if(i.vitality==t)return i.GetState()==y.X.RECEIVE
return!1}HasVitalityReward(t){const e=this.GetRewardDataById(t)
return null!=e&&e.GetState()==y.X.RECEIVE}UpdateReceiveVitalityNum(t,e=!0){this.totalVitalityNum=t,e&&a.i.Inst.RaiseEvent(c.g.DAILY_UPDATAVALUE)
let i=!1
for(const[t,e]of(0,s.V5)(this.dailyActiveRewardDataDict))if(e.GetState()==y.X.RECEIVE)return i=!0,p.f.Inst.SetState(g.t.DAILY_GETAWARD,!0),
void _.l.CheckTrigger(u.u.LIVENESS_VAL,e.cfgData.vitality)
p.f.Inst.SetState(g.t.DAILY_GETAWARD,i)}UpdateRedPoint(){const t=C.L.Inst_get().model.GetTaskLisByType(f.U.MANUAL)
let e=!1
if(t&&t.Count()>0)for(const[i,n]of(0,s.V5)(t))n.status_get()==S.B.FINISHED&&(e=!0,p.f.Inst.SetState(g.t.MANUAL_CHALLENGE,!0))
p.f.Inst.SetState(g.t.MANUAL_CHALLENGE,e)}ReSetModel(){this.dailyTaskDataDict.Clear(),this.dailyActiveRewardDataDict.Clear(),this.totalVitalityNum=0,this.DailyTaskCurTab=A.W.Daily,
this.DailyTaskDefaultTab=A.W.Daily}}v._inst=null,v.clickCalendarItemEvent="clickCalendarItemEvent"},83010:(t,e,i)=>{i.d(e,{x:()=>u})
var s=i(38045),n=i(98800),l=i(68662),a=i(98885),o=i(33314),r=i(87923),h=i(37648),d=i(9773),c=i(70371),_=i(46963)
class u{constructor(){this.cfgData=null,this.remainTimes=0,this.CanRewardTimes=0,this.inReward=0,this.otherParam=null}TimeDailyGetState(){
if(-1!=this.GetUnOpenType())return d.c.Time_Un_Open
const t=_.E.GetInst().GetLimitActivityStateByVitality(this.cfgData.id)
return t==c.W.DATE_NOT_ENOUGH?d.c.Time_Open_CanNotDoToday:t==c.W.NOT_BEGIN?d.c.Time_Open_CanDoToday:t==c.W.END?d.c.Time_Open_FinshDoToday:t==c.W.BEGIN?d.c.Time_Open_DoingToday:void 0
}DailyGetState(){if(1==this.cfgData.claimType&&this.inReward>0)return d.c.Daily_CANGET
return-1!=this.GetUnOpenType()?d.c.Daily_UN_OPEN:this.CanRewardTimes>0&&this.remainTimes>0?d.c.Daily_OPEN_CanDo:this.CanRewardTimes<=0&&this.remainTimes>0?d.c.Daily_OPEN_CanDoNoVital:this.CanRewardTimes>0&&this.remainTimes<=0?_.E.GetInst().CheckVitalityCanBuy(this.cfgData.id)?d.c.Daily_OPEN_CanBuyDo:d.c.Daily_OPEN_CanNotBuyDoHaveVital:this.CanRewardTimes<=0&&this.remainTimes<=0?_.E.GetInst().CheckVitalityCanBuy(this.cfgData.id)?d.c.Daily_OPEN_CanBuyDoNoVital:d.c.Daily_OPEN_CanNotDo:d.c.Daily_COMPLETE
}GetUnOpenType(){const t=this.cfgData
if(0==t.functionID)return-1
if(!h.P.Inst_get().IsFunctionOpened(t.functionID))return 1
if(!r.l.IsEmptyStr(t.showLevel)){const e=a.M.Split(t.showLevel,"_"),i=(0,s.aI)(e[0]),l=(0,s.aI)(e[1]),o=n.Y.Inst.PrimaryRoleInfo_get().Level_get()
if(o<i||o>l)return 4}if(t.isAsuram&&!n.Y.Inst.PrimaryRoleInfo_get().isHaveAlliance_get())return 2
if(0!=t.transferLimit&&null!=t.transferLimit){const e=o.Z.GetJobIdTime(n.Y.Inst.PrimaryRoleInfo_get().Job_get())
if(t.transferLimit>e)return 3}return-1}HasRemainTime(){return!1}isInRedPointLevel(){if(null==this.cfgData)return!1
if(!r.l.IsEmptyStr(this.cfgData.redPointLevel)){const t=a.M.Split(this.cfgData.redPointLevel,"_"),e=(0,s.aI)(t[0]),i=(0,s.aI)(t[1]),l=n.Y.Inst.PrimaryRoleInfo_get().Level_get()
if(l>=e&&l<=i)return!0}return!1}GetActivityContent(){let t="",e="",i=""
return t=this.GetActivityTimeDes(),1==this.cfgData.activityType?e="[DBDBDB]日常活动[-]":2==this.cfgData.activityType&&(e="[DBDBDB]限时活动[-]"),
i=r.l.GetFunctionTip(this.cfgData.functionID),i=a.M.Replace(i,this.cfgData.name,""),[t,e,i]}GetActivityTimeDes(){
return u.GetWeekAndTimeDes(this.cfgData.week,this.cfgData.time,this.cfgData.date,this.cfgData.SpecialDateInfo)}static GetWeekAndTimeDes(t,e,i,n){let o="[DBDBDB]"
const h=l.D.serverOpenDay_get()
if(_.E.openDay>=h&&n.Count()>0&&!r.l.IsEmptyStr(n[0])){o+="开服第"
for(let t=0;t<=n.Count()-1;t++)t>0&&(o+="、"),o+=n[t]
if(o+="天,",""==t&&""==e)o+="\n之后全天"
else{const e=a.M.Split(t,"_")
if(7==e.count)o+="\n之后每天"
else{o+="\n之后周"
let t=null
for(let i=0;i<=e.count-1;i++)t=(0,s.aI)(e[i]),i>0&&(o+="、"),o+=u._getChineseNum(t)}}}else if(""==t&&""==e)o=`${o}全天`
else{const e=a.M.Split(t,"_")
if(7==e.count)o+="每天"
else{o+="周"
let t=null
for(let i=0;i<=e.count-1;i++)t=(0,s.aI)(e[i]),i>0&&(o=`${o}、`),o+=u._getChineseNum(t)}}return""!=e&&(""!=o&&(o+="\n"),o+=a.M.Replace(e,"|"," - "),o=a.M.Replace(o,";","\n")),
`${o}开启[-]`}static _getChineseNum(t){return 1==t?"一":2==t?"二":3==t?"三":4==t?"四":5==t?"五":6==t?"六":7==t?"日":""}_GetTimeHoursAndMin(t){const e=a.M.LastIndexOf(t,":")
return a.M.SubStringWithLen(t,0,e)}}},46963:(t,e,i)=>{i.d(e,{E:()=>T})
var s=i(86133),n=i(38045),l=i(98800),a=i(68662),o=i(16812),r=i(62370),h=i(98885),d=i(67420),c=i(94148),_=i(87923),u=i(85770),I=i(72800),m=i(55492),g=i(75439),p=i(38693),C=i(84141),S=i(15771),f=i(70371)
class T extends o.k{static __StaticInit(){}constructor(){super(),T.openDay=g.D.getInstance().GetIntValue("DAILY:SERVER_OPEN")}static GetInst(){
return null==T._inst&&(T._inst=new T),T._inst}GetLimitActivityStateByActivity(t){let e=null
if(e=d.m.Inst().getActivityEXById(t),null==e)return f.W.ERROR
if(a.D.serverOpenDay_get()<e.cfg.kaifu)return f.W.DATE_NOT_ENOUGH
if(l.Y.Inst.PrimaryRoleInfo_get().Level_get()<e.cfg.level)return f.W.LEVEL_NOT_ENOUGH
if(!e.m_weekInfo.Contains((0,n.tw)(a.D.weekDay_get())))return f.W.DATE_NOT_ENOUGH
if(T.GetLeftBeginTime(e.beginSignTimeValue)>0)return f.W.NOT_BEGIN_ENROLL
if(T.GetLeftEndTime(e.endSignTimeValue)>0)return f.W.ENROLLING
if(T.GetLeftBeginTime(e.beginTimeValue)>0)return f.W.NOT_BEGIN_ENROLL
const i=e.endTimeValue
return T.GetLeftEndTime(i)>0?f.W.BEGIN:f.W.END}GetLimitActivityStateByVitality(t,e,i){e=e||0
let s=null
if(s=p.O.GetInst().GetCfgById(t),null==s)return f.W.ERROR
if(s.functionID==m.x.ASURAM_WAR){const t=Math.floor((c.b.Inst_get().warBeginTime-a.D.serverMSTime_get())/1e3)+1
return t<72e3?t>=0?f.W.NOT_BEGIN:f.W.BEGIN:f.W.DATE_NOT_ENOUGH}const l=a.D.serverOpenDay_get()
if(l<s.date||l<e)return f.W.DATE_NOT_ENOUGH
if(!_.l.IsEmptyStr(s.specialdate)&&l<=h.M.String2Int(s.SpecialDateInfo[s.SpecialDateInfo.Count()-1])&&l<=T.openDay){if(!s.SpecialDateInfo.Contains((0,
n.tw)(l)))return f.W.DATE_NOT_ENOUGH
if(T.GetLeftBeginTime(T.GetCfgTime(s.time,-1,i))>0)return f.W.NOT_BEGIN
const t=T.GetCfgTime(s.time,1,i)
return T.GetLeftEndTime(t)>0?f.W.BEGIN:f.W.END}if(!s.m_weekInfo.Contains((0,n.tw)(a.D.weekDay_get())))return f.W.DATE_NOT_ENOUGH
if(T.GetLeftBeginTime(T.GetCfgTime(s.time,-1,i))>0)return f.W.NOT_BEGIN
const o=T.GetCfgTime(s.time,1,i)
return T.GetLeftEndTime(o)>0?f.W.BEGIN:f.W.END}static GetBeginTimeByStr(t){const e=h.M.Split(t,r.o.s_Arr_UNDER_COLON)
let i=3600*h.M.String2Int(e[0])
return i+=60*h.M.String2Int(e[1]),i}static GetCfgTime(t,e,i){const s=h.M.Split(t,h.M.s_CCD_CHAR_DOT)
let n=null,l=null,a=null,o=null,d=0
for(let t=0;t<=s.Count()-1;t++)if(n=h.M.Split(s[t],r.o.s_Arr_UNDER_LINE),a=T.GetBeginTimeByStr(n[0]),l=h.M.Split(n[1],r.o.s_Arr_UNDER_COLON),o=3600*h.M.String2Int(l[0]),
o+=60*h.M.String2Int(l[1]),null!=l[2]&&(o+=h.M.String2Int(l[2])),d=t,null!=i){if(o>=3600*i.hours_get())break}else if(o>=T.GetTodayTime())break
return-1==e?a:1==e?o:d}static GetLeftBeginTime(t){return t-T.GetTodayTime()}static GetLeftEndTime(t){return t-T.GetTodayTime()}static GetTodayTime(){
let t=C.E.New(a.D.serverMSTime_get()),e=3600*t.getHours()
return e+=60*t.getMinutes(),e+=t.getSeconds(),t=null,e}IsLimitActivityOpen(t){return t!=f.W.DATE_NOT_ENOUGH&&t!=f.W.LEVEL_NOT_ENOUGH&&t!=f.W.JOB_NOT_ENOUGH}IsLimitActivityBegin(t){
return t==f.W.BEGIN||t==f.W.FIVE_MINUTES_LATER_END}IsClickOpenState(t){return t==f.W.BEGIN||t==f.W.FIVE_MINUTES_LATER_END||t==f.W.FIVE_MINUTES_LATER_BEGIN}IsLimitActivityEnd(t){
return t==f.W.END}GetCopyTypeByFunctionId(t){return t==m.x.DEMON_SQUARE?I.S.Belial:t==m.x.BLOOD_CASTLE?I.S.BloodTown:t==m.x.PERSONAL_BOSS?I.S.VipBoss:0}CheckVitalityCanBuy(t){
let e=!1
const i=p.O.GetInst().GetCfgById(t)
let s=null
const n=T.GetInst().GetCopyTypeByFunctionId(i.functionID)
if(s=u.a.Inst_get().copyRecordDic[n],null!=s&&null!=s){S.U.inst.model.GetCopyAddCount(n)-s.todayBuyTimes>0&&(e=!0)}return e}GetPreWeekStr(t,e){e=e||0
let i=""
const n=a.D.serverOpenDay_get()
if(n<e)return i=e-n+"天后",i
if(!h.M.IsNullOrEmpty(t.week)||n<=T.openDay){if(n<=T.openDay&&t.date>1){if(t.SpecialDateInfo.Count()>0&&!_.l.IsEmptyStr(t.SpecialDateInfo[0])){
if(n>h.M.String2Int(t.SpecialDateInfo[t.SpecialDateInfo.Count()-1]))return""
for(let e=0;e<=t.SpecialDateInfo.Count()-1;e++)if(n<=h.M.String2Int(t.SpecialDateInfo[e]))return i=t.SpecialDateInfo[e]-n+"天后",i}if(n<t.date)return i=(0,s.T)("开服第"),
i+=T.GetDayStr(t.date+"",!1),i+=(0,s.T)("天"),i}"1_2_3_4_5_6_7"==t.week?i=(0,s.T)("每天"):(i=(0,s.T)("周"),i+=T.GetDayStr(t.week,!0))}return i}static GetDayStr(t,e){let i="",s=0,n=""
if(!e)return n=_.l.getNumStr(Number(t)),n
const l=h.M.Split(t,r.o.s_Arr_UNDER_CHAR_DOT)
let a=0
for(;a<l.count;){const t=l[a]
s=h.M.String2Int(t),n=_.l.getWeekNumStr(s),i+=n,a<l.count-1&&(i+="、"),a+=1}return i}}T._inst=null,T.openDay=7},42660:(t,e,i)=>{i.d(e,{f:()=>r})
var s,n=i(18998),l=i(83908),a=i(9057),o=i(85976)
let r=n._decorator.ccclass("ActivityCalendarItem")(s=class extends((0,l.pA)(a.x)()){constructor(...t){super(...t),this.beginBg=null,this.cellClickCall=null,
this._degf_OnCreateItem=null}InitView(){super.InitView(),this.grid.SetInitInfo("ui_vitality_calendar_itemcell",null,o.e,this.cellClickCall)}SetData(t){const e=t
this.name.textSet(e.timeStr),this.grid.data_set(e.list),this.bg.node.SetActive(t.index%2!=0)}SetOnCellClick(t){this.cellClickCall=t}})||s},85976:(t,e,i)=>{i.d(e,{e:()=>u})
var s,n=i(18998),l=i(83908),a=i(68662),o=i(9057),r=i(31222),h=i(37648),d=i(57991),c=i(46963),_=i(27001)
let u=n._decorator.ccclass("ActivityCalendarItemCell")(s=class extends((0,l.pA)(o.x)()){constructor(...t){super(...t),this.m_data=null,this.m_isBegin=!1,this.cellClickCall=null,
this._degf_OnState=null}InitView(){super.InitView(),this._degf_OnState=(t,e)=>this.OnState(t,e)}SetData(t){if(this.m_isBegin=!1,this.beginBg.SetActive(!1),null!=t)if(this.m_data=t,
null==this.m_data.res)this.name.textSet("-")
else{this.name.textSet(this.m_data.res.cfg.name),this.m_handlerMgr.AddClickEvent(this.bg.node,this.CreateDelegate(this.OnState))
const t=c.E.GetInst().GetLimitActivityStateByActivity(this.m_data.res.cfg.id)
this.m_isBegin=c.E.GetInst().IsLimitActivityBegin(t)}else this.name.textSet("-")}OnState(t,e){if(this.m_data.day!=a.D.weekDay_get())return void this.showTip()
const i=this.m_data.res.cfg.functionId
if(0!=h.P.Inst_get().IsFunctionOpened(i)){if(this.m_data.res.cfg.ui>0){if(this.m_isBegin)return r.N.inst.OpenUIByShortCutID(this.m_data.res.cfg.ui),
void d.P.Inst_get().CloseTablePanel()
const t=c.E.GetLeftBeginTime(this.m_data.res.beginTimeValue),e=this.m_data.res.cfg.advanceTime
if(t>0&&t<e)return r.N.inst.OpenUIByShortCutID(this.m_data.res.cfg.ui),void d.P.Inst_get().CloseTablePanel()}this.showTip()}else this.showTip()}showTip(){
_.q._inst.RaiseEvent(_.q.clickCalendarItemEvent,this)}SetOnCellClick(t){this.cellClickCall=t}Clear(){
this.m_handlerMgr.RemoveClickEvent(this.node,this.CreateDelegate(this.OnState)),this.cellClickCall=null,super.Clear()}})||s},23167:(t,e,i)=>{
var s,n=i(18998),l=i(6847),a=i(83908),o=i(46282),r=i(68662),h=i(61911),d=i(5494),c=i(52212),_=i(79534),u=i(67420),I=i(57991),m=i(90034),g=i(27001),p=i(42660);(0,
l.s_)(d.I.VitalityCalendarTablePanel,o.Z.ui_activity_calendar_mainview).register()(s=class extends((0,a.pA)(h.f)()){InitView(){this.ClearClickTip(),
this.tableBody.SetInitInfo("ui_vitality_calendar_item_ry",null,p.f)}OnAddToScene(){this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.OnCloseBtn)),
g.q._inst.AddEventHandler(g.q.clickCalendarItemEvent,this.CreateDelegate(this.OnCellClick)),u.m.Inst().InitTimeInfo(),this.tableBody.data_set(u.m.Inst().calenderList)
const t=r.D.weekDay_get(),e=this.bg_current_active.node.transform.GetLocalPosition(),i=113*t-450-6,s=new _.P(i,e.y,e.z)
this.bg_current_active.node.transform.SetLocalPosition(s)}OnCellClick(t){this.clickItembg.node.SetActive(!0)
const e=t.node.transform.convertToWorldSpaceAR(new n.Vec3(0,0,0)),i=this.node.transform.convertToNodeSpaceAR(e),s=new _.P(i.x+12,i.y,i.z)
this.clickItembg.node.setPosition(s)
const l=c.F.zero_get()
t.m_data.day<=3?l.x=180:l.x=-300,m.s.Inst_get().ShowDailyTaskInfoView(t.m_data,1,l)}ClearClickTip(){this.clickItembg.node.SetActive(!1)}OnCloseBtn(t,e){
I.P.Inst_get().CloseTablePanel()}Clear(){g.q._inst.RemoveEventHandler(g.q.clickCalendarItemEvent,this.CreateDelegate(this.OnCellClick)),
this.m_handlerMgr.RemoveClickEvent(this.closeBtn,this.CreateDelegate(this.OnCloseBtn))}})},33938:(t,e,i)=>{i.d(e,{D:()=>T})
var s,n=i(18998),l=i(83908),a=i(86133),o=i(98800),r=i(9057),h=i(85682),d=i(31222),c=i(80486),_=i(84229),u=i(87851),I=i(38693),m=i(77697),g=i(64501),p=i(65550),C=i(62783),S=i(12970),f=i(82550)
let T=n._decorator.ccclass("BecomeStrongerItem")(s=class extends((0,l.pA)(r.x)()){constructor(...t){super(...t),this.data=null,this.resPath="atlas/huodongicon2/"}InitView(){
super.InitView(),this.InitHandlerMgr()}SetData(t){this.data=t,this.activityName.textSet((0,a.T)(this.data.name)),this.acvityDesc.textSet((0,a.T)(this.data.desc)),
this.activityIcon.spriteNameSet(this.resPath+(0,a.T)(this.data.icon)),this.finshSp.node.SetActive(!1),this.goBtn.node.SetActive(!0),
this.m_handlerMgr.RemoveClickEvent(this.goBtn,this.CreateDelegate(this.OnClick)),this.m_handlerMgr.AddClickEvent(this.goBtn,this.CreateDelegate(this.OnClick))}OnClick(t,e){
const i=I.O.GetInst().GetCfgById(this.data.VitalityId)
if(null!=i&&i.isAsuram&&!o.Y.Inst.PrimaryRoleInfo_get().isHaveAlliance_get()&&(p.y.inst.ClientSysStrMsg("加入战盟开启"),_.Q.Inst_get().defaultMainTabIndex=u.t.ASURAM,c.K.Inst().Open()),
-1!=this.data.ui){
if(0!=this.data.ui)d.N.inst.OpenUIByShortCutID(this.data.ui)&&(this.data.ui==h.D.DAILY_PANEL||this.data.ui==h.D.DAILY_PANEL_TIMETASK||this.data.ui==h.D.LOST_ABYSS?f.P.Inst_get().CloseView(!0):f.P.Inst_get().CloseView(!1))
else if(0!=this.data.npc){const t=m.f.Inst().getItemById(this.data.npc)
t&&(t.GOToNpc(),f.P.Inst_get().CloseView(!1))}}else{g.B.inst.CloseSkillPanel()
const t=S.F.getInst().GetRecommendTransVo()
t&&(C.X.inst.OpenMapPanelByMansterSpawnId(t.spawnId),f.P.Inst_get().CloseView(!1))}}Clear(){this.data=null,super.Clear()}})||s},61265:(t,e,i)=>{i.d(e,{$:()=>f})
var s,n=i(18998),l=i(6847),a=i(83908),o=i(49655),r=i(46282),h=i(98800),d=i(85682),c=i(98885),_=i(85602),u=i(87923),I=i(37648),m=i(68637),g=i(72082),p=i(82550),C=i(72652),S=i(33938)
let f=(0,l.s_)(o.o.BecomeStrongerMainView,r.Z.ui_becomestronger_mainview).register()(s=class extends((0,a.Ri)()){constructor(...t){super(...t),this.nowTabIndex=C.X.MONEY,
this.tabList=null,this.LableList=null,this.guideIds=null}InitView(){super.InitView(),this.tabList=new _.Z(0),this.tabList.Add(this.tab1),this.tabList.Add(this.tab2),
this.tabList.Add(this.tab3),this.LableList=new _.Z(0),this.LableList.Add(this.label1),this.LableList.Add(this.label2),this.LableList.Add(this.label3),
this.guideIds=new _.Z([d.D.UI_STRENG_EQ_BTN,d.D.UI_STRENG_EXP_BTN,d.D.UI_STRENG_GOLD_BTN]),this.grid.SetInitInfo("ui_becomestronger_item",this.OnStrongItem),
this.grid.OnReposition_set(this.CreateDelegate(this.OnReposition))}OnAddToScene(){this.AddListener(),
null!=p.P.Inst_get().defaultTabIdx&&(this.nowTabIndex=p.P.Inst_get().defaultTabIdx,p.P.Inst_get().defaultTabIdx=null),this.UpdateTabState()
const t=g.F.Inst().GetListByTab(this.nowTabIndex),e=h.Y.Inst.PrimaryRoleInfo_get().Level_get(),i=new _.Z
for(let s=0;s<=t.Count()-1;s++){const n=t[s],l=c.M.Split(n.showLevel,"_"),a=c.M.String2Int(l[0]),o=c.M.String2Int(l[1]),r=n.funtionId
a<=e&&e<o&&(0!=r?I.P.Inst_get().IsFunctionOpened(r)&&i.Add(n):i.Add(n))}const s=g.F.Inst().GetFatherTabLis()
for(let t=0;t<=s.Count()-1;t++)this.LableList[t].textSet(s[t].tabName)
i.Sort(this.CreateDelegate(this.OnSortList)),this.grid.data_set(i)}UpdateTabState(){this.tab1.node.getChildByName("mbcommon_sp_0085").SetActive(!1),
this.tab1.node.getChildByName("mbcommon_sp_0085 (1)").SetActive(!0),this.tab2.node.getChildByName("mbcommon_sp_0085").SetActive(!1),
this.tab2.node.getChildByName("mbcommon_sp_0085 (1)").SetActive(!0),this.tab3.node.getChildByName("mbcommon_sp_0085").SetActive(!1),
this.tab3.node.getChildByName("mbcommon_sp_0085 (1)").SetActive(!0),this.label1.color=this.label2.color=this.label3.color=new n.Color(166,152,134,255),
1==this.nowTabIndex?(this.tab1.node.getChildByName("mbcommon_sp_0085").SetActive(!0),this.tab1.node.getChildByName("mbcommon_sp_0085 (1)").SetActive(!1),
this.label1.color=new n.Color(96,71,63,255)):2==this.nowTabIndex?(this.tab2.node.getChildByName("mbcommon_sp_0085").SetActive(!0),
this.tab2.node.getChildByName("mbcommon_sp_0085 (1)").SetActive(!1),this.label2.color=new n.Color(96,71,63,255)):(this.tab3.node.getChildByName("mbcommon_sp_0085").SetActive(!0),
this.tab3.node.getChildByName("mbcommon_sp_0085 (1)").SetActive(!1),this.label3.color=new n.Color(96,71,63,255))}OnReposition(){this.contentScrollView.ResetPosition(),
this.contentScrollView.scrollToTop(.01)}RegGuide(){for(let t=0;t<=this.tabList.count;t++)m.c.Inst.RegGameObject(this.guideIds[t],this.tabList[t].node)}UnRegGuide(){
for(let t=0;t<=this.guideIds.count;t++)m.c.Inst.UnRegGameObject(this.guideIds[t])}CheckGuide(t){t<this.guideIds.count&&u.l.CheckBtnClickTrigger(this.guideIds[t])}OnSortList(t,e){
return t.priority>e.priority?1:t.priority<e.priority?-1:0}OnStrongItem(t){return t[0].getCNode(S.D)}OnClose(t,e){p.P.Inst_get().CloseView(null)}Clear(){this.RemoveListener(),
this.tabGrid.Clear(),this.tabList.Clear(),super.Clear()}Destroy(){this.grid.Clear(),this.tabList=null}OnClickTab(t){let e=Number(t.currentTarget._name.split("tab")[1])
this.CheckGuide(e),this.nowTabIndex=e
for(let e=0;e<=this.tabList.Count()-1;e++)if(this.tabList[e].node._name==t.target._name){this.CheckGuide(e),this.nowTabIndex=e+1
break}this.OnAddToScene()}AddListener(){this.m_handlerMgr.AddClickEvent(this.closeBtn.node,this.CreateDelegate(this.OnClose))
for(let t=0;t<=this.tabList.Count()-1;t++)this.m_handlerMgr.AddClickEvent(this.tabList[t],this.CreateDelegate(this.OnClickTab))}RemoveListener(){}})||s},84938:(t,e,i)=>{i.d(e,{
p:()=>g})
var s,n=i(18998),l=i(83908),a=i(9057),o=i(85682),r=i(85602),h=i(75696),d=i(87923),c=i(37648),_=i(55492),u=i(68637),I=i(90034),m=i(77038)
let g=n._decorator.ccclass("DailyGetAwawdItem")(s=class extends((0,l.pA)(a.x)()){constructor(...t){super(...t),this.data=null,this.guideParam=null}InitView(){super.InitView(),
this.MyGrid.SetInitInfo("ui_baseitem",null,h.j)}Clear(){super.Clear(),this.RemoveLis()}SetData(t){if(this.data=t,null==this.data)return
this.RemoveLis(),this.AddLis(),this.lab.textSet(`今日累计活跃度达到[047104]${this.data.cfgData.vitality}[-]点`)
const e=this.data.GetState()
e==m.X.RECEIVE?(this.bg.spriteNameSet("rycommon_sp_0128"),this.GoBtn.node.SetActive(!0),this.cantget.SetActive(!1),
this.finish.SetActive(!1)):e==m.X.UNRECEIVE?(this.bg.spriteNameSet("rycommon_sp_0128"),this.GoBtn.node.SetActive(!1),this.cantget.SetActive(!0),
this.finish.SetActive(!1)):(this.bg.spriteNameSet("rycommon_sp_0127"),this.GoBtn.node.SetActive(!1),this.cantget.SetActive(!1),this.finish.SetActive(!0)),this.RegGuide()
const i=this.data.cfgData.rewards.GetItemList()
if(c.P.Inst_get().IsFunctionOpened(_.x.ANGEL_FIGHT_TOKEN))this.MyGrid.data_set(i)
else{const t=new r.Z
for(let e=0;e<=i.Count()-1;e++)10214!=i[e].modelId_get()&&t.Add(i[e])
this.MyGrid.data_set(t)}}AddLis(){this.m_handlerMgr.AddClickEvent(this.GoBtn,this.CreateDelegate(this.onGetClick))}RemoveLis(){this.m_handlerMgr.Clear(),this.UnRegGuide()}
RegGuide(){this.UnRegGuide(),this.GoBtn.node.active&&null!=this.data&&this.data.cfgData.vitality&&(this.guideParam=this.data.cfgData.id,
u.c.Inst.RegGameObject(o.D.UI_DAILY_REWARD_BTN,this.GoBtn.node,this.guideParam))}UnRegGuide(){
null!=this.guideParam&&(u.c.Inst.UnRegGameObject(o.D.UI_DAILY_REWARD_BTN,this.guideParam),this.guideParam=null)}CheckGuide(){
null!=this.guideParam&&d.l.CheckBtnClickTrigger(o.D.UI_DAILY_REWARD_BTN,this.guideParam)}onGetClick(){null!=this.data&&this.data.GetState()==m.X.RECEIVE&&(this.CheckGuide(),
I.s.Inst_get().CM_VitalityReceiveRewardHandle(this.data.cfgData.id))}})||s},88206:(t,e,i)=>{
var s,n=i(6847),l=i(83908),a=i(46282),o=i(61911),r=i(5494),h=i(92679),d=i(90034),c=i(27001),_=i(84938);(0,
n.s_)(r.I.RYDailyGetAwardView,a.Z.ui_daily_GetRewardView).register()(s=class t extends((0,l.pA)(o.f)()){constructor(...t){super(...t),this.sliderFullWidth=698}InitView(){
super.InitView(),this.MyGrid.SetInitInfo("ui_daily_GetRewardItem",null,_.p)}Clear(){super.Clear(),this.RemoveLis()}OnAddToScene(){this.AddLis(),this.updataView()}AddLis(){
this.m_handlerMgr.AddClickEvent(this.closeBtn,this.CreateDelegate(this.OnClose)),this.m_handlerMgr.AddEventMgr(h.g.DAILY_UPDATAVALUE,this.CreateDelegate(this.updataView)),
this.m_handlerMgr.AddEventMgr(h.g.ReciveVitalityActivityReward,this.CreateDelegate(this.updataGrid))}RemoveLis(){
this.m_handlerMgr.RemoveClickEvent(this.closeBtn,this.CreateDelegate(this.OnClose)),this.m_handlerMgr.RemoveEventMgr(h.g.DAILY_UPDATAVALUE,this.CreateDelegate(this.updataView)),
this.m_handlerMgr.RemoveEventMgr(h.g.ReciveVitalityActivityReward,this.CreateDelegate(this.updataGrid))}updataView(){this.updataGrid(),this.updataBottomView()}updataGrid(){
const e=c.q.GetInst().GetRewardList()
e.Sort(t.Sort),this.MyGrid.data_set(e),this.ScrollView.ResetPosition(),this.MyGrid.Reposition()}updataBottomView(){const t=c.q.GetInst().GetRewardList()
let e=300
t&&t.Count()>0&&(e=t.LastItem().cfgData.vitality),this.ExpSlider.DoF_SetValueEx(c.q.GetInst().GetTotalVitalityNum(),e),
this.value.textSet(`${c.q.GetInst().GetTotalVitalityNum()}/${e}`),this.sliderProgress.node.transform.width=this.sliderFullWidth*Math.min(1,c.q.GetInst().GetTotalVitalityNum()/e)}
OnClose(){d.s.Inst_get().CloseGetAwardView()}static Sort(t,e){const i=t.GetState()
return e.GetState()==i?t.cfgData.id-e.cfgData.id:e.GetState()-t.GetState()}})},52946:(t,e,i)=>{
var s,n=i(18998),l=i(6847),a=i(83908),o=i(46282),r=i(86133),h=i(90419),d=i(50089),c=i(61911),_=i(5494),u=i(75696),I=i(87923),m=i(55492),g=i(28359),p=i(27001)
n._decorator.ccclass("DailyTaskInfo")(s=(0,l.s_)(_.I.DailyTaskInfo,o.Z.ui_daily_task_info).layerTip().register()(s=class extends((0,a.pA)(c.f)()){constructor(...t){super(...t),
this.Repath="atlas/huodongicon2/"}InitView(){super.InitView(),this.rewardListGrid.SetInitInfo("ui_baseitem",null,u.j)}OnAddToScene(){
const t=p.q._inst.GetType(),e=p.q._inst.GetCalenderInfo(),i=p.q._inst.GetPos()
this.node.SetLocalPositionXYZ(i.x,i.y,0),t&&e&&this.SetData(t,e)}SetData(t,e){this.node.SetActive(!0),1==t?this.ShowCalendarTask(e):this.ShowDailyTask(e),
this.fathertab.Reposition(),this.DesScroll.ResetPosition(),this.rewardListScrollView.ResetPosition(),this.AddListener()}ShowCalendarTask(t){
this.remainValueLabel.node.SetActive(!1),this.activeValueLabel.node.SetActive(!1),this.nameLabel.node.SetLocalPositionXYZ(34,11,0)
const e=t.res.cfg
this.activityIcon.spriteNameSet(this.Repath+e.tipsIcon),this.nameLabel.textSet(e.name)
let i="",s="",n="";[i,s,n]=t.GetActivityContent(),I.l.IsEmptyStr(i)?this.timeDes.SetActive(!1):(this.timeDes.SetActive(!0),this.timeDes.textSet("活动时间: "+i)),
I.l.IsEmptyStr(s)?this.type.SetActive(!1):(this.type.SetActive(!0),this.typeDes.textSet(s),this.type.transform.height=this.typeDes.node.transform.height),
I.l.IsEmptyStr(n)?this.level.SetActive(!1):(this.level.SetActive(!0),this.levelDes.textSet(n),this.level.transform.height=this.levelDes.node.transform.height),
this.destable.Reposition(),this.taskDesLabel.textSet(e.desc)
const l=h.d.parseJsonObjectWithFix(e.rewards+"","rewardValues"),a=d.t.decode(l,g.h)
a.Parse(),this.rewardListGrid.data_set(a.GetItemList()),this.rewardListScrollView.ResetPosition()}ShowDailyTask(t){this.remainValueLabel.node.SetActive(!0),
this.activeValueLabel.node.SetActive(!0),this.nameLabel.node.SetLocalPositionXYZ(34,35,0)
const e=t.cfgData
if(this.activityIcon.spriteNameSet(this.Repath+e.tipsIcon),this.nameLabel.textSet(e.name),0==e.vitalityLimit?this.remainValueLabel.textSet((0,
r.T)("[DBDBDB]不限次数[-]")):e.functionID==m.x.WORLD_BOSS||e.functionID==m.x.ANCIENT_BOSS?this.remainValueLabel.textSet(`${(0,
r.T)("剩余体力: [DBDBDB]")}${t.remainTimes}[-]`):this.remainValueLabel.textSet(`${(0,r.T)("剩余次数: [DBDBDB]")}${t.remainTimes}[-]`),e.vitalityLimit&&e.honorExp){
this.activeValueLabel.node.SetActive(!0)
p.q.GetInst().GetTotalVitalityNum()
this.activeValueLabel.textSet(`${(0,r.T)("活跃度: [DBDBDB]")}${e.honorExp}点/次[-]`)}else this.activeValueLabel.node.SetActive(!1)
let i="",s="",n="";[i,s,n]=t.GetActivityContent(),I.l.IsEmptyStr(i)?this.timeDes.SetActive(!1):(this.timeDes.SetActive(!0),this.timeDes.textSet("活动时间: "+i)),
I.l.IsEmptyStr(s)?this.type.SetActive(!1):(this.type.SetActive(!0),this.typeDes.textSet(s)),I.l.IsEmptyStr(n)?this.level.SetActive(!1):(this.level.SetActive(!0),
this.levelDes.textSet(n)),this.destable.Reposition(),this.taskDesLabel.textSet(t.cfgData.desc)
const l=h.d.parseJsonObjectWithFix(t.cfgData.rewards+"","rewardValues"),a=d.t.decode(l,g.h)
a.Parse(),this.rewardListGrid.data_set(a.GetItemList()),this.rewardListScrollView.ResetPosition()}OnClickMaskHandler(t){t.preventSwallow=!0,this.node.SetActive(!1),
t.preventSwallow=!0}Clear(){this.m_handlerMgr.RemoveClickEvent(this.mask,this.CreateDelegate(this.OnClickMaskHandler)),super.Clear()}AddListener(){
this.m_handlerMgr.AddClickEvent(this.mask,this.CreateDelegate(this.OnClickMaskHandler))}})||s)},76076:(t,e,i)=>{i.d(e,{$:()=>at})
var s,n=i(18998),l=i(83908),a=i(86133),o=i(98800),r=i(68662),h=i(38935),d=i(62370),c=i(66788),_=i(9057),u=i(85682),I=i(31222),m=i(60130),g=i(98885),p=i(52212),C=i(77399),S=i(94148),f=i(85430),T=i(21554),y=i(70093),A=i(59686),D=i(47520),E=i(92679),v=i(87923),w=i(41670),R=i(29839),P=i(78417),O=i(85770),L=i(72800),B=i(55492),b=i(24524),M=i(66196),G=i(39652),H=i(22662),N=i(60128),k=i(56955),U=i(68637),V=i(89427),x=i(61546),F=i(77697),q=i(34843),Y=i(65550),W=i(27363),j=i(79878),Z=i(98580),X=i(85890),K=i(99535),$=i(62783),J=i(12970),z=i(12417),Q=i(84141),tt=i(15771),et=i(90034),it=i(10429),st=i(70371),nt=i(27001),lt=i(46963)
let at=n._decorator.ccclass("DailyTaskItem")(s=class extends((0,l.pA)(_.x)()){constructor(...t){super(...t),this.itemtype=it.W.Daily,this.data=null,this.serverTimer=0,
this.totalTime=0,this.residueTimer=0,this.timerOne=0,this.GoType=0,this._degf_Cooling=null,this.guideId=null,this.guideParam=null,this.resPath="atlas/manual/"}InitView(){
super.InitView(),this._degf_Cooling=()=>this.Cooling()}SetData(t){if(this.itemtype=nt.q.GetInst().DailyTaskCurTab,
(this.itemtype==it.W.Daily||this.itemtype==it.W.TimeTask||this.itemtype==it.W.Challenge)&&(this.data=t),null==this.data)return c.Y.LogError("data 为空"),void this.RemoveListener()
this.AddListener(),this.itemtype==it.W.Daily?this.SetDailyData():this.itemtype==it.W.TimeTask?this.SetTimeTaskData():this.itemtype==it.W.Challenge&&this.SetChallengeData(),
this.UpdateDoubleTxt()}SetDailyData(){const t=this.data
if(t.cfgData.honorExp<=0?(this.honour.node.SetActive(!1),this.honourSp.node.SetActive(!1)):(this.honour.node.SetActive(!0),this.honourSp.node.SetActive(!0)),
this.GoBtn.normalSpriteSet("rycommon_bt_0023"),this.taskbg.spriteNameSet(this.resPath+t.cfgData.icon),this.awardRedtips.SetActive(!1),
0==t.cfgData.vitalityLimit?this.dec.textSet("剩余次数:[13b512]无限[-]"):t.remainTimes>0?this.dec.textSet(`剩余次数:[13b512]${t.remainTimes}[-]`):this.dec.textSet("剩余次数:[D43E3E]0[-]"),
this.title.textSet(t.cfgData.name),this.cooldown.node.SetActive(!1),v.l.IsEmptyStr(t.cfgData.typeIcon))this.Specialsp1.node.SetActive(!1),this.Specialsp2.node.SetActive(!1)
else{const e=g.M.Split(t.cfgData.typeIcon,g.M.s_CCD_CHAR_DOT)
null!=e[0]?(this.Specialsp1.spriteNameSet(this.resPath+e[0]),this.Specialsp1.node.SetActive(!0)):this.Specialsp1.node.SetActive(!1),
null!=e[1]?(this.Specialsp2.spriteNameSet(this.resPath+e[1]),this.Specialsp2.node.SetActive(!0)):this.Specialsp2.node.SetActive(!1)}const e=t.GetUnOpenType()
;-1!=e?(this.honour.textSet(t.cfgData.honorExp+""),this.dec.node.SetActive(!1),this.lockobj.SetActive(!0),this.unlockbg.SetActive(!0),this.GoBtn.node.SetActive(!1),
this.finishbg.SetActive(!1),
1==e?this.locklab.textSet(`[D43E3E]${v.l.GetFunctionTip(t.cfgData.functionID)}[-]`):2==e?this.locklab.textSet("[D43E3E]加入战盟开启[-]"):3==e?this.locklab.textSet(`[D43E3E]${v.l.getNumStr(t.cfgData.transferLimit)}转开启[-]`):4==e?this.locklab.textSet("[D43E3E]等级未满足条件[-]"):this.locklab.textSet("[D43E3E]未满足条件[-]")):(t.CanRewardTimes<=0?this.honour.textSet("0"):this.honour.textSet(t.cfgData.honorExp+""),
this.dec.node.SetActive(!0),this.lockobj.SetActive(!1),this.GoBtn.node.SetActive(!0),this.GoBtn.SetIsEnabled(!0),this.unlockbg.SetActive(!1),this.cooldown.node.SetActive(!1),
this.SetCoolDown(),1==t.cfgData.claimType&&t.inReward>0?(this.awardRedtips.SetActive(!0),this.GoBtnLab.textSet("领奖"),this.GoType=6,this.finishbg.SetActive(!1),
this.unlockbg.SetActive(!1)):t.remainTimes<=0?(t.CanRewardTimes<=0&&!lt.E.GetInst().CheckVitalityCanBuy(t.cfgData.id)?(this.finishbg.SetActive(!0),
this.unlockbg.SetActive(!0)):(this.finishbg.SetActive(!1),this.unlockbg.SetActive(!1)),1==t.cfgData.goBottom&&(this.GoBtnLab.textSet("前往"),this.GoType=1),
1==t.cfgData.showBottom&&(this.GoBtnLab.textSet("购买次数"),this.GoType=2),0==t.cfgData.goBottom&&0==t.cfgData.showBottom&&this.GoBtn.node.SetActive(!1)):(this.GoBtnLab.textSet("前往"),
this.GoType=1,this.finishbg.SetActive(!1))),t.cfgData.functionID!=B.x.WORLD_BOSS&&t.cfgData.functionID!=B.x.ANCIENT_BOSS||this.UpdataBoss(),
21==t.cfgData.vitalityType&&this.MARKET_GOLDSpShow(),27==t.cfgData.vitalityType&&this.LoadInGame(),
t.cfgData.id==nt.q.GetInst().targetId?this.effect_btn.SetActive(!0):this.effect_btn.SetActive(!1)}SetTimeTaskData(){const t=this.data
if(2!=t.cfgData.activityType)return
if(t.cfgData.honorExp<=0?(this.honour.node.SetActive(!1),this.honourSp.node.SetActive(!1)):(this.honour.node.SetActive(!0),this.honourSp.node.SetActive(!0)),
t.CanRewardTimes<=0?this.honour.textSet("0"):this.honour.textSet(t.cfgData.honorExp+""),v.l.IsEmptyStr(t.cfgData.typeIcon))this.Specialsp1.node.SetActive(!1),
this.Specialsp2.node.SetActive(!1)
else{const e=g.M.Split(t.cfgData.typeIcon,g.M.s_CCD_CHAR_DOT)
null!=e[0]?(this.Specialsp1.spriteNameSet(this.resPath+e[0]),this.Specialsp1.node.SetActive(!0)):this.Specialsp1.node.SetActive(!1),
null!=e[1]?(this.Specialsp2.spriteNameSet(this.resPath+e[1]),this.Specialsp2.node.SetActive(!0)):this.Specialsp2.node.SetActive(!1)}this.GoBtn.normalSpriteSet("rycommon_bt_0023"),
this.awardRedtips.SetActive(!1),this.taskbg.spriteNameSet(this.resPath+t.cfgData.icon),this.title.textSet(t.cfgData.name),this.honour.textSet(t.cfgData.honorExp+""),
this.cooldown.node.SetActive(!1),this.finishbg.SetActive(!1),this.lockobj.SetActive(!1),this.unlockbg.SetActive(!1)
const e=t.GetUnOpenType()
if(-1!=e)this.dec.node.SetActive(!1),this.lockobj.SetActive(!0),this.unlockbg.SetActive(!0),this.GoBtn.node.SetActive(!1),this.finishbg.SetActive(!1),
1==e?this.locklab.textSet(`[D43E3E]${v.l.GetFunctionTip(t.cfgData.functionID)}[-]`):2==e?this.locklab.textSet("[D43E3E]加入战盟开启[-]"):3==e?this.locklab.textSet(`[D43E3E]${v.l.getNumStr(t.cfgData.transferLimit)}转开启[-]`):4==e?this.locklab.textSet("[D43E3E]等级未满足条件[-]"):this.locklab.textSet("[D43E3E]未满足条件[-]")
else{let e=null,i=0
if(t.cfgData.timeLimitId>0){const s=C.x.Inst_get().GetTimeLimitRes(t.cfgData.timeLimitId)
let n=r.D.serverOpenTime_get()
n+=3600*s.firstOpen
let l=!1;[i,l]=C.x.Inst_get().GetCloseOpenDay(t.cfgData.timeLimitId),l&&(e=Q.E.New(1e3*n))}const s=lt.E.GetInst().GetLimitActivityStateByVitality(t.cfgData.id,i,e)
if(s==st.W.DATE_NOT_ENOUGH){let s=`${lt.E.GetInst().GetPreWeekStr(t.cfgData,i)} `
if(!g.M.IsNullOrEmpty(t.cfgData.time)){const i=lt.E.GetCfgTime(t.cfgData.time,0,e),n=g.M.Split(t.cfgData.time,g.M.s_CCD_CHAR_DOT)
s+=`${g.M.Replace(n[i],"|"," - ")}开启`}s=`[D43E3E]${s}[-]`,this.dec.node.SetActive(!0),this.dec.textSet(s),this.unlockbg.SetActive(!0),this.GoBtn.node.SetActive(!1)
}else if(s==st.W.NOT_BEGIN||s==st.W.FIVE_MINUTES_LATER_BEGIN){let i=""
if(!g.M.IsNullOrEmpty(t.cfgData.time)){const s=lt.E.GetCfgTime(t.cfgData.time,0,e),n=g.M.Split(t.cfgData.time,g.M.s_CCD_CHAR_DOT)
i+=`${g.M.Replace(n[s],"|"," - ")}开启`}this.dec.node.SetActive(!0),this.dec.textSet(i),this.unlockbg.SetActive(!0),this.GoBtn.node.SetActive(!0),this.GoBtn.SetIsEnabled(!0),
this.GoBtnLab.textSet("前往"),this.GoType=1}else if(s==st.W.BEGIN)this.unlockbg.SetActive(!1),this.GoBtn.node.SetActive(!0),this.GoBtn.SetIsEnabled(!0),this.GoBtnLab.textSet("前往"),
this.GoType=1,this.cooldown.node.SetActive(!1),this.SetCoolDown(),this.dec.node.SetActive(!0),this.dec.textSet("[13b512]活动进行中[-]"),
t.remainTimes<=0&&0!=t.cfgData.vitalityLimit?(1==t.cfgData.goBottom&&(this.GoBtnLab.textSet("前往"),this.GoType=1),1==t.cfgData.showBottom&&(this.GoBtnLab.textSet("购买次数"),
this.GoType=2),0==t.cfgData.goBottom&&0==t.cfgData.showBottom&&(this.finishbg.SetActive(!0),this.unlockbg.SetActive(!0),
this.GoBtn.node.SetActive(!1))):(this.GoBtnLab.textSet("前往"),this.GoType=1,this.finishbg.SetActive(!1))
else if(s==st.W.END)this.dec.node.SetActive(!0),this.dec.textSet("[D43E3E]活动已结束[-]"),this.unlockbg.SetActive(!0),this.GoBtn.node.SetActive(!1),
t.remainTimes<=0&&0!=t.cfgData.vitalityLimit?this.finishbg.SetActive(!0):this.finishbg.SetActive(!1)
else{if(this.dec.node.SetActive(!0),t.cfgData.isAsuram&&!o.Y.Inst.PrimaryRoleInfo_get().isHaveAlliance_get())this.dec.textSet("[D43E3E]加入战盟开启[-]")
else{const e=v.l.GetFunctionTip(t.cfgData.functionID)
""!=e&&this.dec.textSet(`[D43E3E]${e}[-]`)}this.unlockbg.SetActive(!0),this.GoBtn.node.SetActive(!1)}t.cfgData.functionID==B.x.ASURAM_WAR&&this.UpdateAsuramWar(s)}
1==t.cfgData.claimType&&t.inReward>0&&(this.GoBtn.node.SetActive(!0),this.GoBtn.SetIsEnabled(!0),this.GoBtnLab.textSet("领奖"),this.GoType=6),
t.cfgData.id==nt.q.GetInst().targetId?this.effect_btn.SetActive(!0):this.effect_btn.SetActive(!1)}SetChallengeData(){const t=this.data,e=M.w.Inst().getItemById(t.id_get())
e&&(e.award<=0?(this.honour.node.SetActive(!1),this.honourSp.node.SetActive(!1)):(this.honour.node.SetActive(!0),this.honourSp.node.SetActive(!0)),this.awardRedtips.SetActive(!1),
this.lockobj.SetActive(!1),this.GoBtn.SetIsEnabled(!0),this.title.textSet(e.typeName),this.taskbg.spriteNameSet(e.typeIcon),this.dec.node.SetActive(!0),
this.honour.textSet(e.award+""),this.Specialsp1.node.SetActive(!1),this.Specialsp2.node.SetActive(!1),this.cooldown.node.SetActive(!1),
t.status_get()==Z.B.ACCEPTED?(this.dec.textSet(g.M.Replace(e.targetDes,"{0}",`[cc8f5a]${t.qVo.targets[0].value_get()}[-]/${t.tCTargetDefs_get().tCTargetDefs[0].value}`)),
this.GoBtn.normalSpriteSet("rycommon_bt_0023"),this.GoBtn.node.SetActive(!0),this.GoBtnLab.textSet("前往"),this.GoType=3,this.finishbg.SetActive(!1),
this.unlockbg.SetActive(!1)):t.status_get()==Z.B.FINISHED?(this.dec.textSet(g.M.Replace(e.targetDes,"{0}",`[13b512]${t.tCTargetDefs_get().tCTargetDefs[0].value}/${t.tCTargetDefs_get().tCTargetDefs[0].value}[-]`)),
this.GoBtn.normalSpriteSet("rycommon_bt_0024"),this.GoBtn.node.SetActive(!0),this.GoBtnLab.textSet("领奖"),this.GoType=4,this.finishbg.SetActive(!1),this.unlockbg.SetActive(!1),
this.awardRedtips.SetActive(!0)):(this.dec.textSet(g.M.Replace(e.targetDes,"{0}",`[13b512]${t.tCTargetDefs_get().tCTargetDefs[0].value}/${t.tCTargetDefs_get().tCTargetDefs[0].value}[-]`)),
this.GoBtn.normalSpriteSet("rycommon_bt_0023"),this.GoBtn.node.SetActive(!1),this.finishbg.SetActive(!0),this.unlockbg.SetActive(!0)))}SetCoolDown(){const t=this.data
t.cfgData.functionID==B.x.DEMON_SQUARE?this.SetTimer(L.S.Belial):t.cfgData.functionID==B.x.BLOOD_CASTLE?this.SetTimer(L.S.BloodTown):t.cfgData.functionID==B.x.PERSONAL_BOSS?this.SetTimer(L.S.VipBoss):(this.cooldown.node.SetActive(!1),
this.GoBtn.SetIsEnabled(!0))}SetTimer(t){const e=O.a.Inst_get().copyCoolTimeDic,i=O.a.Inst_get().copyRecordDic
let s=!1,n=null
if(i.LuaDic_ContainsKey(t)){const e=i[t]
n=b.o.Inst().getItemById(e.lastCopyId)}if(e.LuaDic_ContainsKey(t))if(null!=n){this.serverTimer=e[t],this.totalTime=n.waitTime
let i=r.D.serverMSTime_get()-this.serverTimer
i<0&&(i=0),i>this.totalTime?s=!0:this.residueTimer=this.totalTime-i}else s=!0
else s=!0
s?this.TimeAnimClear():(this.cooldown.node.SetActive(!0),this.GoBtn.SetIsEnabled(!1),this.dec.node.SetActive(!1),this.cooldown.textSet((0,
a.T)(`[D43E3E]冷却中: ${v.l.GetDateFormatEX(this.residueTimer/1e3,!1)}[-]`)),0==this.timerOne&&(this.timerOne=this.m_handlerMgr.SetInterval(this._degf_Cooling,500)))}Cooling(){
const t=r.D.serverMSTime_get()-this.serverTimer
this.residueTimer=this.totalTime-t,t>this.totalTime?(this.residueTimer=0,this.TimeAnimClear(),this.SetData(this.data)):this.cooldown.textSet(`${(0,
a.T)("[D43E3E]冷却中: ")}${v.l.GetDateFormatEX(this.residueTimer/1e3,!1)}[-]`)}TimeAnimClear(){this.cooldown.node.SetActive(!1),this.GoBtn.SetIsEnabled(!0),
0!=this.timerOne&&(this.timerOne=this.m_handlerMgr.ClearInterval(this.timerOne))}onClick1(){
if(nt.q.GetInst().DailyTaskCurTab==it.W.Daily||nt.q.GetInst().DailyTaskCurTab==it.W.TimeTask){const t=this.index%3,e=p.F.zero_get(),i=(m.O.GetUIWidth()-1280)/2
1==t?e.x=200:2==t?e.x=-130+i:0==t&&(e.x=-170-i),et.s.Inst_get().ShowDailyTaskInfoView(this.data,2,e)}}OnClickGoToBtn(){if(this.CheckGuide(),1==this.GoType){
const t=this.data,e=t.cfgData
if(0==e.linkType)return
if(291==t.cfgData.functionID)return void this.OnBountyTaskClick()
if(2==e.linkType){const e=F.f.Inst().getItemByIdNew(g.M.String2Int(t.cfgData.linkParam))
return void(e&&(e.GOToNpc(),et.s.Inst_get().CloseDailyPanel()))}if(3==e.linkType)return et.s.Inst_get().CloseDailyPanel(),
void $.X.inst.OpenMapPanelByMansterSpawnId(J.F.getInst().GetRecommendTransVo().spawnId)
if(4==e.linkType)return void $.X.inst.GoToMap(e.linkParam)
if(5==e.linkType)return void this.GotoAllianceMap()
if(I.N.inst.OpenUIByShortCutIDStr(e.linkParam)){const t=g.M.String2Int(g.M.Split(e.linkParam,g.M.s_CCD_CHAR)[0])
t==u.D.DAILY_PANEL_TIMETASK||t==u.D.DAILY_PANEL||t==u.D.Arena||t==u.D.EXORCISM_MAIN||u.D.LOST_ABYSS}}else if(2==this.GoType){
const t=this.data,e=lt.E.GetInst().GetCopyTypeByFunctionId(t.cfgData.functionID)
let i=null
const s=tt.U.inst.model.GetCopyAddCount(e)
if(i=O.a.Inst_get().copyRecordDic.LuaDic_GetItem(e),null==i)return void c.Y.LogError((0,a.T)("副本类型：")+(e+(0,a.T)("找不到记录")))
if(e==L.S.BloodTown||e==L.S.Belial||e==L.S.SKY_ILLUSION||z._.Inst().IsVipBossCopy(e))return void w.B.GetInst().AddTimes(i.lastCopyId)
const n=s-i.todayBuyTimes
tt.U.inst.controller.OpenBuyPanel(n,e)}else if(3==this.GoType){const t=this.data
if(R.p.inst.IsInCopy())return void Y.y.inst.ClientStrMsg(H.r.SystemTipMessage,"正在副本中")
t&&t.status_get()==Z.B.ACCEPTED&&V.X.DOGo(t)}else if(4==this.GoType){const t=this.data
t.isClickReward_get()&&j.Y.SendToServer(t)}else 5==this.GoType?T.J.Inst_get().OpenTipViewById(x.X.Inst_get().itemId,A.l.GetWay,y.p.GetWay):6==this.GoType&&this.OnClickGetBtn()}
UpdataBoss(){const t=this.data
t.remainTimes>0?this.dec.textSet(`剩余体力:[13b512]${t.remainTimes}[-]`):this.dec.textSet("剩余体力:[D43E3E]0[-]")}MARKET_GOLDSpShow(){
const t=this.data,e=g.M.Split(t.cfgData.vitalityPurpose,d.o.s_Arr_UNDER_LINE)
if(null==e[1])return
const i=g.M.String2Int(e[1])
let s=g.M.String2Int(t.otherParam);(null==s||s<0)&&(s=0),s>=i&&(s=i),this.dec.textSet(`已购买：${s}/${i}`),t.CanRewardTimes<=0&&this.dec.node.SetActive(!1)}LoadInGame(){
this.dec.node.SetActive(!1)}UpdateAsuramWar(t){const e=this.data
if(S.b.Inst_get().warBeginTime>0){const i=Math.floor((S.b.Inst_get().warBeginTime-r.D.serverMSTime_get())/1e3)+1
if(i>0){const s=g.M.Split(e.cfgData.time,g.M.s_CCD_CHAR_DOT),n=g.M.Replace(s[0],"|"," - ")
if(t==st.W.DATE_NOT_ENOUGH)if(i>=72e3){const t=Math.floor(i/72e3)
this.dec.textSet(`[D43E3E]${t}天后${n}开启[-]`)}else{const t=v.l.GetDateFormat(i,!0)
this.dec.textSet(`[D43E3E]${t}后${n}开启[-]`)}else t==st.W.NOT_BEGIN&&this.dec.textSet(`${n}开启`)}}else c.Y.LogError("AsuramWarModel warBeginTime 为空")}OnBountyTaskClick(){
const t=this.data
if(D.s.GetInst().CanFastFinsh())N.t.ins.OpenPanel(k.g.TAB_AUTO,null,null)
else if(D.s.GetInst().GetCurLink()>0){const t=K.O.Inst_get().GetDoingTaskByType(X.U.BountyTask)
null!=t&&(et.s.Inst_get().CloseDailyPanel(),W.Y.inst.GotoTrigger(t))}else{const e=F.f.Inst().getItemById(g.M.String2Int(t.cfgData.linkParam))
e&&(e.GOToNpc(),et.s.Inst_get().CloseDailyPanel())}}GoToViphandler(t){tt.U.inst.controller.OpenPanel()}OnClickGetBtn(){const t=this.data,e=new G.X
e.vitalityId=t.cfgData.id,h.C.Inst.F_SendMsg(e)}AddListener(){this.m_handlerMgr.AddClickEvent(this.btnInfo,this.CreateDelegate(this.onClick1)),
this.m_handlerMgr.AddClickEvent(this.GoBtn,this.CreateDelegate(this.OnClickGoToBtn)),
this.itemtype==it.W.Daily||this.itemtype==it.W.TimeTask?this.m_handlerMgr.AddEventMgr(E.g.DAILY_UPDATAITEM,this.CreateDelegate(this.UpdataItem)):this.itemtype==it.W.Challenge&&this.m_handlerMgr.AddEventMgr(E.g.MANUAL_UPDATYACHALLENGEITEM,this.CreateDelegate(this.UpdataTaskItem)),
this.m_handlerMgr.AddEventMgr(E.g.RECOVER_DOUBLE_UPDATE,this.CreateDelegate(this.UpdateDoubleTxt)),this.RegGuide()}RemoveListener(){
this.timerOne=this.m_handlerMgr.ClearInterval(this.timerOne),this.m_handlerMgr.Clear(),this.UnRegGuide()}UpdateDoubleTxt(){const t=this.data
this.doubleTxt.textSet(q.v.Inst_get().GetDoubleRewardStr(t.cfgData.functionID))}GetGuideId(){if(this.guideId=null,this.guideParam=null,
null!=this.data)if(this.itemtype==it.W.Daily||this.itemtype==it.W.TimeTask){const t=this.data
this.guideId=u.D.UI_DAILY_GOTO_BTN,this.guideParam=t.cfgData.id}else if(this.itemtype==it.W.Challenge){const t=this.data
this.guideId=u.D.UI_DAILY_GOTO_BTN,this.guideParam=t.resource_get().id}}RegGuide(){this.UnRegGuide(),this.GetGuideId(),
null!=this.guideId&&U.c.Inst.RegGameObject(this.guideId,this.GoBtn.node,this.guideParam)}UnRegGuide(){
null!=this.guideId&&(U.c.Inst.UnRegGameObject(this.guideId,this.guideParam,!0),this.guideId=null)}CheckGuide(){
null!=this.guideId&&v.l.CheckBtnClickTrigger(this.guideId,this.guideParam)}UpdataTaskItem(t){const e=this.data
null!=t&&t.id_get()==e.id_get()&&this.SetData(t)}UpdataItem(t){const e=this.data
null!=t&&t==e.cfgData.id&&this.SetData(nt.q.GetInst().GetDailyTaskDataById(e.cfgData.id))}GotoAllianceMap(){f.a.isInAllianceMap_get()?Y.y.inst.ClientStrMsg(H.r.SystemTipMessage,(0,
a.T)("已在战盟领地内了")):P.L.GetInst().EnterRyAllianceScene()}Clear(){this.RemoveListener(),this.data=null,this.GoType=0,this.serverTimer=0,this.totalTime=0,super.Clear()}Destroy(){
super.Destroy()}})||s},28397:(t,e,i)=>{
var s,n=i(6847),l=i(83908),a=i(46282),o=i(97461),r=i(36334),h=i(44255),d=i(85682),c=i(5494),_=i(60130),u=i(98885),I=i(85602),m=i(79534),g=i(44518),p=i(93353),C=i(66419),S=i(53905),f=i(92679),T=i(28287),y=i(65772),A=i(86209),D=i(21725),E=i(55492),v=i(51954),w=i(76787),R=i(14792),P=i(90034),O=i(80740),L=i(10429),B=i(27001),b=i(18998),M=i(86133),G=i(5924),H=i(72693),N=i(31222),k=i(61613),U=i(35128),V=i(87923),x=i(37648),F=i(68637),q=i(62734),Y=i(17783),W=i(85890),j=i(57991),Z=i(82550),X=i(9773),K=i(46963),$=i(76076)
class J extends((0,l.Ri)()){constructor(...t){super(...t),this._tabName=null,this.tabGuideIds=null,this._tabRedPointIds=null,this._tabFuncIds=null,this.scrollInterval=null,
this.sliderFullWidth=700}InitView(){super.InitView(),this.MyGrid.SetInitInfo("ui_daily_taskItem",null,$.$),
this.rightTabGrid.SetInitInfo("ui_ry_right_tab",null,H.j,this.CreateDelegate(this._OnClickRightItem)),
this.rightTabGrid.OnReposition_set(this.CreateDelegate(this.OnRepositionRight)),this._tabName=new I.Z(["日 常","限 时","挑 战"]),
this.tabGuideIds=new I.Z([d.D.UI_DAILY_BASE_TAB,d.D.UI_DAILY_LIMIT_TAB,null]),this._tabRedPointIds=new I.Z([R.t.DAILY_Task,R.t.DAILY_TimeTask,R.t.MANUAL_CHALLENGE]),
this._tabFuncIds=new I.Z([E.x.DAILY,E.x.TIMEACTIVITY,E.x.MANUAL])}Clear(){super.Clear(),this.RemoveLis(),
null!=this.scrollInterval&&(G.C.Inst_get().ClearInterval(this.scrollInterval),this.scrollInterval=null),B.q.GetInst().targetId=-1}Destroy(){}AddLis(){
this.m_handlerMgr.AddClickEvent(this.activeBtn,this.CreateDelegate(this.OnClickActiveBtn)),this.m_handlerMgr.AddClickEvent(this.powerBtn,this.CreateDelegate(this.OnClickPowerBtn)),
this.m_handlerMgr.AddClickEvent(this.gotoshop,this.CreateDelegate(this.OnClickGotoShopBtn)),
this.m_handlerMgr.AddClickEvent(this.goaward,this.CreateDelegate(this.OnClickGoAWardBtn)),
o.i.Inst.AddEventHandler(f.g.DAILY_UPDATAVALUE,this.CreateDelegate(this.UpdataBottomView)),
o.i.Inst.AddEventHandler(f.g.MANUAL_UPDATYACHALLENGE,this.CreateDelegate(this.UpdataChallengeGrid)),
o.i.Inst.AddEventHandler(f.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors)),o.i.Inst.AddEventHandler(f.g.GUIDE_START,this.CreateDelegate(this.ScrollToGuide)),
q.f.Inst.AddCallback(R.t.DAILY_GETAWARD,this.CreateDelegate(this.UpdateGetAwardRedPoint)),this.RegGuide()}RegGuide(){
F.c.Inst.RegGameObject(d.D.UI_DAILY_CHANGE_BTN,this.gotoshop.node),F.c.Inst.RegGameObject(d.D.UI_DAILY_REWARD_FIX_BTN,this.goaward.node),
F.c.Inst.RegGameObject(d.D.UI_DAILY_WEEK_BTN,this.activeBtn.node),F.c.Inst.RegGameObject(d.D.UI_DAILY_STRENG_BTN,this.powerBtn.node)}UnRegGuide(){
F.c.Inst.UnRegGameObject(d.D.UI_DAILY_CHANGE_BTN),F.c.Inst.UnRegGameObject(d.D.UI_DAILY_REWARD_FIX_BTN),F.c.Inst.UnRegGameObject(d.D.UI_DAILY_WEEK_BTN),
F.c.Inst.UnRegGameObject(d.D.UI_DAILY_STRENG_BTN)}CheckGuide(){V.l.CheckBtnClickTrigger(d.D.UI_DAILY_CHANGE_BTN)}CheckGuide1(){V.l.CheckBtnClickTrigger(d.D.UI_DAILY_REWARD_FIX_BTN)
}CheckGuide2(){V.l.CheckBtnClickTrigger(d.D.UI_DAILY_WEEK_BTN)}CheckGuide3(){V.l.CheckBtnClickTrigger(d.D.UI_DAILY_STRENG_BTN)}RemoveLis(){
q.f.Inst.RemoveCallback(R.t.DAILY_GETAWARD,this.CreateDelegate(this.UpdateGetAwardRedPoint)),
o.i.Inst.RemoveEventHandler(f.g.DAILY_UPDATAVALUE,this.CreateDelegate(this.UpdataBottomView)),
o.i.Inst.RemoveEventHandler(f.g.MANUAL_UPDATYACHALLENGE,this.CreateDelegate(this.UpdataChallengeGrid)),
o.i.Inst.RemoveEventHandler(f.g.UPDATE_ANCHORS,this.CreateDelegate(this.UpdateAnchors)),o.i.Inst.RemoveEventHandler(f.g.GUIDE_START,this.CreateDelegate(this.ScrollToGuide)),
this.m_handlerMgr.Clear(),this.UnRegGuide()}UpdateGetAwardRedPoint(t,e){this.node&&(this.awardRedtips.SetActive(e),this.goawardEff.SetActive(e))}UpdataChallengeGrid(){
B.q.GetInst().DailyTaskCurTab==L.W.Challenge&&this.UpdataGrid(L.W.Challenge)}SetData(){q.f.Inst.SetState(R.t.DAILY_Task_Item,!1),P.s.Inst_get().UpdateRedPoint(!0),
this.UpdateAnchors(),this.AddLis(),this.activeBtn.node.SetActive(x.P.Inst_get().IsFunctionOpened(E.x.BECOME_STRONGER))
const t=q.f.Inst.GetData(R.t.DAILY_GETAWARD)
t&&t.show&&(this.awardRedtips.SetActive(t.show),this.goawardEff.SetActive(t.show)),this.gotoshop.node.SetActive(x.P.Inst_get().IsFunctionOpened(E.x.HONOUR_SHOP)),
this.rightTabGrid.data_set(this._tabName),this.UpdataGrid(null),this.UpdataBottomView(),
B.q.GetInst().targetId>0&&null==this.scrollInterval&&(this.scrollInterval=G.C.Inst_get().SetInterval(this.CreateDelegate(this.ScrollToTarget),100,1))}ScrollToGuide(t){
null!=B.q.GetInst().targetId&&-1!=B.q.GetInst().targetId||t.controlId==d.D.UI_DAILY_GOTO_BTN&&null!=t.controlParam&&this.ScrollToTargetId(t.controlParam,!0)}ScrollToTargetId(t,e){
const i=this.MyGrid.data_get(),s=i.Count()
let n=-1
for(let e=0;e<=s-1;e++)if(i[e].cfgData.id==t){n=e
break}if(e){const t=V.l.GalScollToGridRate(450,250,U.p.FloorToInt(n/3),U.p.CeilToInt(s/3),!0,null)
this.ScrollView.scrollTo(new b.Vec2(0,1-t))}else if(n<6)this.sliderProgress.node.transform.width=0,this.ScrollView.scrollTo(new b.Vec2(0,1))
else if(s<6)this.sliderProgress.node.transform.width=this.sliderFullWidth,this.ScrollView.scrollTo(new b.Vec2(0,0))
else if(n+3>=s)this.sliderProgress.node.transform.width=this.sliderFullWidth,this.ScrollView.scrollTo(new b.Vec2(0,1))
else{const t=(n-3)/(s-6)
this.sliderProgress.node.transform.width=this.sliderFullWidth*Math.min(1,t),this.ScrollView.scrollTo(new b.Vec2(0,1-t))}}ScrollToTarget(){
this.ScrollToTargetId(B.q.GetInst().targetId,!1)}UpdataGrid(t){t=t||B.q.GetInst().DailyTaskDefaultTab,B.q.GetInst().DailyTaskCurTab=t
let e=null
t==L.W.Daily?(e=B.q.GetInst().GetDailyTaskDataByType(1),e.Sort(this.SortTaskList)):t==L.W.TimeTask?(e=B.q.GetInst().GetDailyTaskDataByType(2),
e.Sort(this.SortTimeTaskList)):t==L.W.Challenge&&(e=Y.L.Inst_get().model.GetTaskLisByType(W.U.MANUAL,!0)),this.MyGrid.data_set(e),this.ScrollView.ResetPosition(),
this.MyGrid.Reposition(),this.UpdataBottomView()}UpdataBottomView(){const t=B.q.GetInst().GetRewardList()
let e=300
t&&t.Count()>0&&(e=t.LastItem().cfgData.vitality)
const i=B.q.GetInst().GetTotalVitalityNum()
B.q.GetInst().DailyTaskCurTab==L.W.Challenge?(this.ExpSlider.node.SetActive(!1),this.goaward.node.SetActive(!1)):(this.ExpSlider.node.SetActive(!0),
this.goaward.node.SetActive(!0)),this.honourvalue.textSet((0,M.T)(`${i}/${e}`)),this.sliderProgress.node.transform.width=this.sliderFullWidth*Math.min(1,i/e)}OnClickActiveBtn(){
this.CheckGuide2(),j.P.Inst_get().OpenTablePanel()}OnClickPowerBtn(){this.CheckGuide3(),Z.P.Inst_get().Open()}OnClickGotoShopBtn(){this.CheckGuide(),
P.s.Inst_get().CloseDailyPanel(),N.N.inst.OpenUIByShortCutID(d.D.HONOUR_SHOP)}OnClickGoAWardBtn(){this.CheckGuide1(),P.s.Inst_get().OpenAwawrdView()}_OnClickRightItem(t,e,i){
const s=this.rightTabGrid.itemList.IndexOf(t)
s!=B.q.GetInst().DailyTaskCurTab&&(this.UpdataGrid(s),this._UpdateTableSelect1())}OnRepositionRight(){const t=this.rightTabGrid.itemList.Count()
for(let e=0;e<=t-1;e++){const t=this.rightTabGrid.itemList[e]
let i=0
null!=this._tabRedPointIds&&this._tabRedPointIds.Count()>e&&(i=this._tabRedPointIds[e]),t.SetRedPointId(i),t.SetGuideId(this.tabGuideIds[e]),
null!=this._tabFuncIds&&this._tabFuncIds.Count()>e&&t.SetFunId(this._tabFuncIds[e])}this._UpdateTableSelect1()}_UpdateTableSelect1(){const t=this.rightTabGrid.itemList.Count()
for(let e=0;e<=t-1;e++){const t=this.rightTabGrid.itemList[e]
e!=B.q.GetInst().DailyTaskCurTab?t.SetSelect(!1):t.SetSelect(!0)}}SortRewardByState(t,e){return t.cfgData.vitality-e.cfgData.vitality}SortTaskList(t,e){
const i=t.DailyGetState(),s=e.DailyGetState()
return i==s?t.cfgData.sort-e.cfgData.sort:s-i}SortTimeTaskList(t,e){const i=t.TimeDailyGetState(),s=e.TimeDailyGetState()
return i==s?i==X.c.Time_Open_CanDoToday||i==X.c.Time_Open_FinshDoToday?K.E.GetCfgTime(t.cfgData.time,-1,null)-K.E.GetCfgTime(e.cfgData.time,-1,null):t.cfgData.sort-e.cfgData.sort:s-i
}UpdateAnchors(){const t=_.O.GetUIWidth()
_.O.SetAnchorPos(this.rightTrans,!1,!0,0),_.O.SetAnchorPos(this.leftTrans,!0,!0,0),this.line.widthSet(k.v.GetAdaptionWidth(1144,1284)),
k.v.SetAdaptionPos(this.ScrollView.node,-604,-748),k.v.SetAdaptionPos(this.ExpSlider.node,-5,-45),this.ScrollViewPanel.node.transform.setContentSize(1129+t-1280,450),
this.MyGrid.cellWidthSet((1129+t-1280-56)/3)}}
(0,n.s_)(c.I.RYDailyPanel,a.Z.ui_daily_panel).tabsPrefab(a.Z.ui_daily_TaskView,O.F.DailyTask).tabsPrefab(a.Z.ui_arena_detail_view_ry,O.F.ArenaCopy).tabsPrefab(a.Z.ui_lostabyssview_ry,O.F.DailyCopy).tabsPrefab(a.Z.ui_exorcism_main_view,O.F.Exorcism).tabsPrefab(a.Z.ui_recover_panel,O.F.Recover).waitPrefab(a.Z.ui_ry_tabcommonpanel_nocharacter).register()(s=class extends((0,
l.pA)(h.I)()){InitView(){super.InitView(),this.InitSubDatas()}InitSubDatas(){let t=new I.Z
t.Add(r.b.New(new I.Z(["ui_daily_TaskView"]),this.DailyTaskContainer,J)),this.AddSubPanelDatas(O.F.DailyTask,t),t=new I.Z,
t.Add(r.b.New(new I.Z(["ui_arena_detail_view_ry"]),this.ArenaContainer,C.o)),this.AddSubPanelDatas(O.F.ArenaCopy,t),t=new I.Z,
t.Add(r.b.New(new I.Z(["ui_lostabyssview_ry"]),this.DailyCopyContainer,v.E)),this.AddSubPanelDatas(O.F.DailyCopy,t),t=new I.Z,
t.Add(r.b.New(new I.Z(["ui_exorcism_main_view"]),this.ExorcismContainer,D.w)),this.AddSubPanelDatas(O.F.Exorcism,t),t=new I.Z,
t.Add(r.b.New(new I.Z(["ui_recover_panel"]),this.RecoverContainer,w.w)),this.AddSubPanelDatas(O.F.Recover,t)}OnAddToScene(){super.OnAddToScene(),this.UpdatePanel()}UpdatePanel(){
B.q.GetInst().FatherDefaultTab=_.O.GetSelectedIndex(B.q.GetInst().FatherDefaultTab,this.tab0RedPointList)
const t=B.q.GetInst().FatherDefaultTab,e=B.q.GetInst().DailyTaskDefaultTab
t==O.F.DailyTask?B.q.GetInst().DailyTaskDefaultTab=e||L.W.Daily:t==O.F.ArenaCopy?B.q.GetInst().DailyTaskDefaultTab=e||L.W.ArenaCopy:t==O.F.DailyCopy?B.q.GetInst().DailyTaskDefaultTab=e||L.W.LostAbyss:t==O.F.Exorcism?B.q.GetInst().DailyTaskDefaultTab=e||L.W.Exorcism:t==O.F.Recover?B.q.GetInst().DailyTaskDefaultTab=e||L.W.Recover:B.q.GetInst().DailyTaskDefaultTab=e||L.W.Daily,
this.SelectTab0(t,!0)}_OnSelectTab0BeforeUpdate(t){let e=T._.ShowGold_Dia_BindDia
this._subPanelDatas=this.SwitchSubPanelDatasInDic(this.selectTabIdx0),this.tipbtn.node.transform.SetLocalPositionXYZ(-460,325,0),super._OnSelectTab0BeforeUpdate(),
this.selectTabIdx0==O.F.DailyTask?(this._SetTabData1(!1),this.titleLabel.textSet("日 常"),this.rightBg1.SetActive(!1),this.rightBg2.SetActive(!0),this.tipbtn.node.SetActive(!1),
this.SelectTab1(0,null)):this.selectTabIdx0==O.F.ArenaCopy?(this._SetTabData1(!1),this.titleLabel.textSet("竞技场"),this.rightBg1.SetActive(!0),this.rightBg2.SetActive(!1),
this.tipbtn.node.SetActive(!0),this.SelectTab1(0,null),t&&p.g.Inst_get().SendArenaOpenPanel(),
e=T._.ShowGold_Dia_Honour):this.selectTabIdx0==O.F.DailyCopy?(this._SetTabData1(!0,new I.Z(["失落深渊"])),this.titleLabel.textSet("失落深渊"),this.rightBg1.SetActive(!1),
this.rightBg2.SetActive(!0),this.tipbtn.node.SetActive(!1),this.SelectTab1(0,null)):this.selectTabIdx0==O.F.Exorcism?(this._SetTabData1(!1),this.titleLabel.textSet("除魔试炼"),
this.rightBg1.SetActive(!0),this.rightBg2.SetActive(!1),this.tipbtn.node.transform.SetLocalPositionXYZ(-430,325,0),this.tipbtn.node.SetActive(!0),
this.SelectTab1(0,null)):this.selectTabIdx0==O.F.Recover&&(this._SetTabData1(!0,new I.Z(["资源追回"])),this.titleLabel.textSet("资源追回"),this.rightBg1.SetActive(!1),
this.rightBg2.SetActive(!0),this.tipbtn.node.SetActive(!1),this.SelectTab1(0,null)),A.w.Instance.ResetType(e)}SelectTab1(t,e){super.SelectTab1(t,e)}_OnSelectTab1BeforeUpdate(t){
super._OnSelectTab1BeforeUpdate(t),
this.selectTabIdx0==O.F.DailyTask||this.selectTabIdx0==O.F.ArenaCopy?this.ShowSubView(this.selectTabIdx1):this.selectTabIdx0==O.F.DailyCopy||this.selectTabIdx0==O.F.Exorcism||(this.selectTabIdx0,
O.F.Recover,this.ShowSubView(this.selectTabIdx1))}AddLis(){super.AddLis(),this.closed.AddEventHandler(this.CreateDelegate(this.OnCloseClick)),
o.i.Inst.AddEventHandler(f.g.STRENGTHEN_PANEL_CLOSE,this.CreateDelegate(this.OnCloseClick)),o.i.Inst.AddEventHandler(f.g.ACCESS_ICON_CLICK,this.CreateDelegate(this.OnAccessClose))}
SetViewConfig(){
this._SetTabData0(!0,new I.Z(["日 常","竞技场","失落深渊","除魔试炼","资源追回"]),new I.Z([R.t.DAILY_Task_View,R.t.DAILY_AREN_VIEW,R.t.DAILY_COPY_VIEW,R.t.EXORCISM,R.t.RECOVER]),null,null,null,new I.Z([E.x.DAILY,E.x.ARENA,E.x.DAILY_COPY_RY,E.x.Exorcism,E.x.RECOVER]),null,null,new I.Z([d.D.UI_DAILY_TAB,null,d.D.UI_DAILY_COPY_TAB,d.D.UI_WELF_RECOVER])),
this._SetTabData1(!1),this._SetCharacterTabData(!1),this.m_handlerMgr.AddClickEvent(this.tipbtn,this.CreateDelegate(this.OnTipClick))}OnTipClick(){const t=new S.w
t.width=450,this.selectTabIdx0==O.F.Exorcism?(t.position=new m.P(-451.1,303.2,0),t.infoId="DEMONTRIAL:TIPS"):(t.position=new m.P(-459,325,0),t.infoId="ARENA:TIPS"),
y.Q.Inst_get().Open(t)}ShowCurrencyBar_get(){return T._.ShowGold_Dia_BindDia}Clear(){o.i.Inst.RemoveEventHandler(f.g.STRENGTHEN_PANEL_CLOSE,this.CreateDelegate(this.OnCloseClick)),
o.i.Inst.RemoveEventHandler(f.g.ACCESS_ICON_CLICK,this.CreateDelegate(this.OnAccessClose)),this.m_handlerMgr.Clear(),super.Clear()}Destroy(){super.Destroy()}OnCloseClick(){
P.s.Inst_get().CloseDailyPanel()}OnAccessClose(t){if(null==t)return
const e=g.F.ins.GetAccessById(t).TargetDefs_Get().tCTargetDefs[0].OpenUI_get()
if(null!=e){const t=u.M.String2Int(e)
if(t==d.D.DAILY_PANEL||t==d.D.DAILY_PANEL_TIMETASK||t==d.D.LOST_ABYSS)return}P.s.Inst_get().CloseDailyPanel()}})}}])
